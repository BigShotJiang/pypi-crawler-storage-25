from axis_synome.spec.asc.entities.networks import Network
from axis_synome.spec.asc.entities.protocol_sets import Protocol
from axis_synome.spec.asc.entities.tokens import Token
from axis_synome.spec_support.evm_address import EvmAddress
from axis_synome.spec_support.validated_dataclass import validated_dataclass


@validated_dataclass
class Asset:
    token: Token
    network: Network
    protocol: Protocol
    address: EvmAddress
    underlying_asset: Token
    underlying_asset_address: EvmAddress
    underlying_asset_source: str
    source: str | None = None
