from enum import Enum
from typing import Annotated

from pydantic import Field

from axis_synome.spec.asc.entities.assets import Asset
from axis_synome.spec.asc.entities.assets_by_prime import ASSETS_BY_PRIME, PrimeName
from axis_synome.spec.asc.entities.networks import Network
from axis_synome.spec.asc.entities.protocol_sets import Protocol
from axis_synome.spec_support.validated_dataclass import validated_dataclass


@validated_dataclass
class PrimeAgentData:
    """A Sky Star Agent (prime) that controls a stablecoin system."""

    name: Annotated[str, Field(min_length=1)]  # e.g., "Spark"
    assets: list[Asset]

    psm_protocols: set[Protocol]
    networks: set[Network]
    alm_proxy: Protocol | None = None
    allocation_buffer_protocol: Protocol | None = None
    max_pct_latent_asc: Annotated[float, Field(ge=0.0, le=0.25)] = 0.25

    asc_exempt: bool = False
    min_pct_asc_of_collateral: Annotated[float, Field(ge=0.0, le=1.0)] = 0.05


class PrimeAgent(Enum):
    """All Sky Star Agents (primes)."""

    SPARK = PrimeAgentData(
        name=PrimeName.SPARK,
        assets=ASSETS_BY_PRIME.get(PrimeName.SPARK, []),
        psm_protocols={Protocol.LITE_PSM, Protocol.PSM3},
        networks={
            Network.ARBITRUM,
            Network.AVALANCHE,
            Network.BASE,
            Network.ETHEREUM_MAINNET,
        },
    )
    GROVE = PrimeAgentData(
        name=PrimeName.GROVE,
        assets=ASSETS_BY_PRIME.get(PrimeName.GROVE, []),
        psm_protocols={Protocol.PSM3},
        networks={
            Network.ARBITRUM,
            Network.AVALANCHE,
            Network.BASE,
            Network.ETHEREUM_MAINNET,
            Network.PLASMA,
        },
    )
    KEEL = PrimeAgentData(
        name=PrimeName.KEEL, asc_exempt=True, assets=[], psm_protocols=set(), networks=set()
    )
    SKYBASE = PrimeAgentData(
        name=PrimeName.SKYBASE,
        assets=ASSETS_BY_PRIME.get(PrimeName.SKYBASE, []),
        psm_protocols=set(),
        networks=set(),
    )
    PATTERN = PrimeAgentData(
        name=PrimeName.PATTERN,
        assets=ASSETS_BY_PRIME.get(PrimeName.PATTERN, []),
        psm_protocols=set(),
        networks=set(),
    )
    LAUNCH_AGENT_6 = PrimeAgentData(
        name=PrimeName.LAUNCH_AGENT_6,
        assets=ASSETS_BY_PRIME.get(PrimeName.LAUNCH_AGENT_6, []),
        psm_protocols=set(),
        networks=set(),
    )
    LAUNCH_AGENT_7 = PrimeAgentData(
        name=PrimeName.LAUNCH_AGENT_7,
        assets=ASSETS_BY_PRIME.get(PrimeName.LAUNCH_AGENT_7, []),
        psm_protocols=set(),
        networks=set(),
    )


class EligiblePrimeAgentASC(Enum):
    """Enumeration of prime agents eligible for ASC calculations.

    Excludes primes that are ASC-exempt (e.g., Keel).
    """

    SPARK = PrimeAgent.SPARK.value
    GROVE = PrimeAgent.GROVE.value
    SKYBASE = PrimeAgent.SKYBASE.value
    PATTERN = PrimeAgent.PATTERN.value
    LAUNCH_AGENT_6 = PrimeAgent.LAUNCH_AGENT_6.value
    LAUNCH_AGENT_7 = PrimeAgent.LAUNCH_AGENT_7.value
