from enum import Enum


class Protocol(Enum):
    # PSM
    LITE_PSM = "LitePSM"
    PSM3 = "PSM3"
    # Lending
    SPARKLEND = "SparkLend"
    SPARKLEND_PROTOCOL = "SparkLend Protocol"
    SPARK_SAVINGS_PROTOCOL = "Spark Savings Protocol"
    AAVE = "Aave"
    AAVE_CORE = "Aave Core"
    AAVE_CORE_V3 = "Aave Core V3"
    AAVE_PRIME = "Aave Prime"
    AAVE_HORIZON = "Aave Horizon"
    AAVE_V3 = "Aave V3"
    MORPHO = "Morpho"
    MORPHO_BLUE_ERC4626_VAULT = "Morpho Blue erc4626 Vault"
    MAPLE = "Maple"
    KAMINO = "Kamino"
    # Pools
    CURVE = "Curve"
    UNISWAP = "Uniswap"
    GUNI = "GUNI"
    # Real-world asset / structured credit
    CENTRIFUGE = "Centrifuge"
    BLACKROCK = "BlackRock"
    SECURITIZE = "Securitize"
    SUPERSTATE = "Superstate"
    # Stablecoin issuers / protocols
    ETHENA = "Ethena"
    ETHENA_PROTOCOL = "Ethena Protocol"
    AGORA_AUSD = "Agora aUSD"
    RIPPLE = "Ripple"
    ARKIS = "Arkis"
    FLUID_FINANCE_ERC4626_VAULT = "Fluid Finance erc4626 Vault"
    GROVE_STEAKHOUSE_AUSD_MORPHO_VAULT = "Grove x Steakhouse aUSD Morpho Vault"
    GROVE_STEAKHOUSE_USDC_HIGH_YIELD_VAULT_V2 = "Grove x Steakhouse USDC High Yield Vault V2"
    STEAKHOUSE_PYUSD_MORPHO_VAULT = "Steakhouse pyUSD Morpho Vault"


# PSM (Peg Stability Module)
# L1 PSM: directly on Ethereum mainnet.
L1_PSM_PROTOCOLS = {Protocol.LITE_PSM}

# L2 PSM: cross-chain peg-stability modules.
L2_PSM_PROTOCOLS = {Protocol.PSM3}

# Lending
LENDING_PROTOCOLS = {
    Protocol.SPARKLEND,
    Protocol.AAVE,
    Protocol.MORPHO,
    Protocol.SPARKLEND_PROTOCOL,
    Protocol.SPARK_SAVINGS_PROTOCOL,
    Protocol.AAVE_PRIME,
    Protocol.AAVE_CORE,
    Protocol.AAVE_HORIZON,
    Protocol.KAMINO,
    Protocol.MAPLE,
}

POOL_PROTOCOLS = {Protocol.CURVE, Protocol.UNISWAP}

GUNI_PROTOCOLS = {Protocol.GUNI}

GUNI_RESTING_FEE_TIERS = {0.0001, 0.0005}
