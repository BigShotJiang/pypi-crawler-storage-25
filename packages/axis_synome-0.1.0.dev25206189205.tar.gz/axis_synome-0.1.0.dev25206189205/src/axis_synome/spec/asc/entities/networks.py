from enum import Enum


class Network(Enum):
    ETHEREUM_MAINNET = "Ethereum Mainnet"
    BASE = "Base"
    ARBITRUM = "Arbitrum"
    OPTIMISM = "Optimism"
    UNICHAIN = "Unichain"
    AVALANCHE = "Avalanche"
    PLASMA = "Plasma"


# L2 networks: all networks that are not Ethereum mainnet.
L2_NETWORKS = {Network.BASE, Network.ARBITRUM, Network.OPTIMISM, Network.UNICHAIN}
