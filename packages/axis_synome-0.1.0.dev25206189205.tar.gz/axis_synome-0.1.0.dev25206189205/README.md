# axis-synome

A Python framework for defining and validating financial specifications, with a focus on DeFi primitives and risk calculations. Includes:

- **ASC Specifications** — Actively Stabilizing Capital entities (assets, tokens, networks, protocols) and formulas (collateral ratios, incentives, resting/latent ASC)
- **Spec Validator** — Flake8 plugin for enforcing Python subset constraints on spec files
- **Metadata & Utilities** — Support for spec documentation and validated dataclasses

## Installation

Install from PyPI:

```bash
pip install axis-synome
```

Or install from a private registry:

```bash
pip install axis-synome --index-url https://npm.pkg.github.com/archon-research
```

## Usage

### ASC Entities

```python
from axis_synome.spec.asc.entities import primes, tokens, networks, protocol_sets
```

### ASC Formulas

```python
from axis_synome.spec.asc.formulas import asc, asc_collateral_ratio, asc_incentive
```

### Spec Validation

```python
from axis_synome.spec_validator import validate_file

validate_file("my_spec.py")
```

Or use as a flake8 plugin:

```bash
flake8 --select=AXS your_spec.py
```

## About

`axis-synome` is a specification framework for defining financial and risk calculations in DeFi, with emphasis on formalized, auditable spec files.

For more information on writing specifications, see [WRITING_SPECS.md](WRITING_SPECS.md).

## Requirements

- Python >= 3.11
- pydantic >= 2.0.0
