# SPDX-License-Identifier: Apache-2.0
"""Autonomy enhancement modules for role contracts, loops, and scoring."""

from .adaptive_budget import AutonomyBudgetEngine, AutonomyBudgetSnapshot
from .loop import AGMCycleResult, AGMStep, AGMStepInput, AGMStepOutput, AutonomyLoop, AutonomyLoopResult, run_agm_cycle, run_self_check_loop
from .mutation_scaffold import MutationCandidate, rank_mutation_candidates
from .reward_learning import (
    GuardedPromotionPolicy,
    LearningProfileRegistry,
    OfflinePolicyEvaluator,
    RewardOutcomeIngestor,
    RewardSchema,
)
from .roles import AgentRoleSpec, SandboxPermission, default_role_specs
from .scoreboard import build_scoreboard_views

__all__ = [
    "AgentRoleSpec",
    "AutonomyBudgetEngine",
    "AutonomyBudgetSnapshot",
    "AGMCycleResult",
    "AGMStep",
    "AGMStepInput",
    "AGMStepOutput",
    # Phase 19 — stateful loop with persistent IntelligenceRouter
    "AutonomyLoop",
    "AutonomyLoopResult",
    "GuardedPromotionPolicy",
    "LearningProfileRegistry",
    "MutationCandidate",
    "OfflinePolicyEvaluator",
    "RewardOutcomeIngestor",
    "RewardSchema",
    "SandboxPermission",
    "build_scoreboard_views",
    "default_role_specs",
    "rank_mutation_candidates",
    "run_agm_cycle",
    "run_self_check_loop",
]
