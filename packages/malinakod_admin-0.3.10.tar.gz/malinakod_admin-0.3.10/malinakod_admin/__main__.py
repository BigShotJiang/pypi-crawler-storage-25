"""Позволяет запускать `python -m malinakod_admin` (без зависимости от PATH)."""

from .tui import run

if __name__ == "__main__":
    run()
