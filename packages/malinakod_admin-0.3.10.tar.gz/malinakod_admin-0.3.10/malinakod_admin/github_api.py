"""GitHub Contents API для админских операций.

Поддерживает:
- Создание папки клиента (через создание .gitkeep файлов в подпапках)
- Список клиентов
- Загрузку файла в произвольный путь
- Чтение файла
"""

from __future__ import annotations

import base64
import time
from dataclasses import dataclass

import httpx

GITHUB_API = "https://api.github.com"


@dataclass
class ClientInfo:
    client_id: str
    has_manifest: bool
    last_modified: str | None = None


class GitHubAdmin:
    def __init__(
        self,
        token: str,
        repo_owner: str,
        repo_name: str,
        branch: str = "main",
    ) -> None:
        self.token = token
        self.repo_owner = repo_owner
        self.repo_name = repo_name
        self.branch = branch

    def _headers(self) -> dict[str, str]:
        return {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {self.token}",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    def _api_url(self, path: str) -> str:
        return (
            f"{GITHUB_API}/repos/{self.repo_owner}/{self.repo_name}/contents/{path}"
        )

    def whoami(self) -> str | None:
        """Проверяет PAT, возвращает username или None."""
        try:
            with httpx.Client(headers=self._headers()) as c:
                r = c.get(f"{GITHUB_API}/user", timeout=15.0)
                if r.status_code == 200:
                    return r.json().get("login")
                self._last_auth_error = (
                    f"HTTP {r.status_code}: {r.json().get('message', r.text[:200])}"
                )
        except httpx.HTTPError as exc:
            self._last_auth_error = f"Сетевая ошибка: {exc}"
        return None

    @property
    def last_auth_error(self) -> str:
        return getattr(self, "_last_auth_error", "неизвестная ошибка")

    def repo_exists(self) -> bool:
        try:
            with httpx.Client(headers=self._headers()) as c:
                r = c.get(
                    f"{GITHUB_API}/repos/{self.repo_owner}/{self.repo_name}",
                    timeout=15.0,
                )
                return r.status_code == 200
        except httpx.HTTPError:
            return False

    def put_file(
        self,
        client: httpx.Client,
        path: str,
        content: bytes,
        message: str,
    ) -> bool:
        """Создаёт или обновляет файл по пути."""
        url = self._api_url(path)
        # Получаем текущий sha если файл существует.
        sha = None
        r = client.get(url, params={"ref": self.branch}, timeout=15.0)
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, dict):
                sha = data.get("sha")

        body: dict[str, object] = {
            "message": message,
            "content": base64.b64encode(content).decode("ascii"),
            "branch": self.branch,
        }
        if sha:
            body["sha"] = sha
        r2 = client.put(url, json=body, timeout=30.0)
        return r2.status_code in (200, 201)

    def get_file(
        self, client: httpx.Client, path: str
    ) -> bytes | None:
        url = self._api_url(path)
        r = client.get(url, params={"ref": self.branch}, timeout=30.0)
        if r.status_code == 404:
            return None
        if r.status_code != 200:
            return None
        data = r.json()
        if isinstance(data, dict) and data.get("encoding") == "base64":
            return base64.b64decode(data["content"])
        return None

    def list_dir(
        self, client: httpx.Client, path: str
    ) -> list[dict]:
        url = self._api_url(path)
        r = client.get(url, params={"ref": self.branch}, timeout=30.0)
        if r.status_code != 200:
            return []
        data = r.json()
        return data if isinstance(data, list) else []

    def create_client_folder(self, client_id: str) -> bool:
        """Создаёт структуру папок для нового клиента."""
        with httpx.Client(headers=self._headers()) as c:
            base = f"clients/{client_id}"
            ts = int(time.time())
            ok = True
            # README с описанием папки
            readme = (
                f"# Клиент {client_id}\n\n"
                f"Создан: {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(ts))} UTC\n\n"
                "## Структура\n\n"
                "- `manifest.json` — описание сервисов которые клиент должен запустить\n"
                "- `files/` — код, бинарники, конфиги\n"
                "- `commands/` — команды от админа на исполнение\n"
                "- `output/` — результаты исполнения команд\n\n"
                "## Загрузка файлов\n\n"
                "Перетащите файлы прямо в браузер в нужную подпапку, "
                "GitHub сделает коммит автоматически. Клиент подхватит "
                "изменения в течение 30 секунд.\n"
            )
            ok &= self.put_file(
                c, f"{base}/README.md", readme.encode("utf-8"), f"init client {client_id}"
            )
            # Заглушки в подпапках чтобы они существовали в гите.
            for sub in ("files", "commands", "output"):
                ok &= self.put_file(
                    c,
                    f"{base}/{sub}/.gitkeep",
                    b"",
                    f"init {sub}/ for {client_id}",
                )
            # Пустой manifest по умолчанию.
            manifest = '{\n  "services": []\n}\n'
            ok &= self.put_file(
                c,
                f"{base}/manifest.json",
                manifest.encode("utf-8"),
                f"init manifest for {client_id}",
            )
            return ok

    def list_clients(self) -> list[ClientInfo]:
        """Сканирует /clients/ и возвращает список ID."""
        result: list[ClientInfo] = []
        with httpx.Client(headers=self._headers()) as c:
            entries = self.list_dir(c, "clients")
            for e in entries:
                if e.get("type") == "dir":
                    cid = e["name"]
                    # Проверяем наличие manifest.json
                    manifest_url = self._api_url(f"clients/{cid}/manifest.json")
                    rm = c.get(manifest_url, params={"ref": self.branch}, timeout=10.0)
                    has_manifest = rm.status_code == 200
                    result.append(ClientInfo(client_id=cid, has_manifest=has_manifest))
        return result

    def fetch_status(self, client_id: str) -> dict | None:
        """Если клиент пишет heartbeat в status.json, читает его."""
        with httpx.Client(headers=self._headers()) as c:
            data = self.get_file(c, f"clients/{client_id}/status.json")
        if not data:
            return None
        try:
            import json as _json

            return _json.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            return None

    def fetch_manifest(self, client_id: str) -> dict | None:
        """Читает clients/<id>/manifest.json как dict, или None если нет."""
        with httpx.Client(headers=self._headers()) as c:
            data = self.get_file(c, f"clients/{client_id}/manifest.json")
        if not data:
            return None
        try:
            import json as _json

            return _json.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            return None

    def send_command(self, client_id: str, command: str) -> str:
        """Кладёт shell-команду в clients/<id>/commands/, возвращает имя файла."""
        ts = int(time.time())
        name = f"cmd_{ts}.txt"
        with httpx.Client(headers=self._headers()) as c:
            self.put_file(
                c,
                f"clients/{client_id}/commands/{name}",
                command.encode("utf-8"),
                f"admin command for {client_id}",
            )
        return name

    def fetch_output(self, client_id: str, cmd_name: str) -> str | None:
        """Пытается прочитать output/<имя>.log."""
        log_name = cmd_name.replace(".txt", ".log")
        with httpx.Client(headers=self._headers()) as c:
            data = self.get_file(c, f"clients/{client_id}/output/{log_name}")
        if data is None:
            return None
        return data.decode("utf-8", errors="replace")

    # --- деплой проектов ---
    _IGNORE_PATTERNS = {
        ".git", ".github", ".idea", ".vscode", "__pycache__", "node_modules",
        "venv", ".venv", "env", ".env", ".pytest_cache", ".mypy_cache",
        ".ruff_cache", "dist", "build", ".tox", ".eggs",
    }
    _IGNORE_EXTS = {".pyc", ".pyo", ".log", ".swp", ".tmp"}

    _DOT_ALLOWLIST = {".gitkeep", ".gitignore", ".env.example", ".gitattributes"}

    def _should_skip(self, name: str) -> bool:
        if name in self._IGNORE_PATTERNS:
            return True
        if name.startswith(".") and name not in self._DOT_ALLOWLIST:
            return True
        for ext in self._IGNORE_EXTS:
            if name.endswith(ext):
                return True
        return False

    def upload_directory(
        self,
        client_id: str,
        local_path: str,
        target_subpath: str,
        progress_cb: object | None = None,
    ) -> tuple[int, int, list[str]]:
        """Рекурсивно загружает локальную папку в clients/<id>/files/<target_subpath>/.

        Возвращает (uploaded, total, errors).
        progress_cb(current, total, filename) — опциональный колбэк прогресса.
        """
        from pathlib import Path

        root = Path(local_path).expanduser().resolve()
        if not root.is_dir():
            return (0, 0, [f"Папка не найдена: {root}"])

        files_to_upload: list[tuple[Path, str]] = []
        for f in root.rglob("*"):
            if not f.is_file():
                continue
            rel_parts = f.relative_to(root).parts
            if any(self._should_skip(p) for p in rel_parts):
                continue
            rel = "/".join(rel_parts)
            files_to_upload.append((f, rel))

        total = len(files_to_upload)
        uploaded = 0
        errors: list[str] = []
        target_subpath = target_subpath.strip("/")
        base = f"clients/{client_id}/files"
        if target_subpath:
            base = f"{base}/{target_subpath}"

        with httpx.Client(headers=self._headers()) as c:
            for idx, (local_file, rel) in enumerate(files_to_upload, start=1):
                if progress_cb is not None:
                    try:
                        progress_cb(idx, total, rel)  # type: ignore[misc]
                    except Exception:  # noqa: BLE001
                        pass
                try:
                    content = local_file.read_bytes()
                except OSError as exc:
                    errors.append(f"{rel}: {exc}")
                    continue
                ok = self.put_file(c, f"{base}/{rel}", content, f"deploy {target_subpath}/{rel}")
                if ok:
                    uploaded += 1
                else:
                    errors.append(f"{rel}: upload failed")

        return (uploaded, total, errors)

    def update_manifest(
        self,
        client_id: str,
        service: dict,
        replace: bool = True,
    ) -> tuple[bool, str]:
        """Добавляет/обновляет один сервис в manifest.json клиента.

        Если replace=True (default) — заменяет сервис с тем же name.
        Возвращает (ok, message).
        """
        import json as _json

        path = f"clients/{client_id}/manifest.json"
        with httpx.Client(headers=self._headers()) as c:
            raw = self.get_file(c, path)
            manifest: dict
            if raw is None:
                manifest = {"services": []}
            else:
                try:
                    manifest = _json.loads(raw.decode("utf-8"))
                except (UnicodeDecodeError, ValueError):
                    manifest = {"services": []}

            services = manifest.get("services", [])
            if not isinstance(services, list):
                services = []

            new_name = service.get("name")
            if not new_name:
                return (False, "У сервиса нет name")

            if replace:
                services = [s for s in services if s.get("name") != new_name]
            services.append(service)
            manifest["services"] = services

            content = _json.dumps(manifest, indent=2, ensure_ascii=False).encode("utf-8")
            ok = self.put_file(c, path, content, f"deploy: update manifest service '{new_name}'")
            return (ok, f"manifest.json обновлён ({len(services)} сервисов)")

    def remove_service_from_manifest(
        self, client_id: str, service_name: str
    ) -> tuple[bool, str]:
        """Удаляет сервис по имени из manifest.json."""
        import json as _json

        path = f"clients/{client_id}/manifest.json"
        with httpx.Client(headers=self._headers()) as c:
            raw = self.get_file(c, path)
            if raw is None:
                return (False, "manifest.json не найден")
            try:
                manifest = _json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, ValueError):
                return (False, "manifest.json не парсится")
            services = manifest.get("services", [])
            if not isinstance(services, list):
                return (False, "services не список")
            new_services = [s for s in services if s.get("name") != service_name]
            if len(new_services) == len(services):
                return (False, f"Сервис '{service_name}' не найден")
            manifest["services"] = new_services
            content = _json.dumps(manifest, indent=2, ensure_ascii=False).encode("utf-8")
            ok = self.put_file(c, path, content, f"deploy: remove service '{service_name}'")
            return (ok, f"Сервис '{service_name}' удалён ({len(new_services)} осталось)")
