"""Генерация лицензионных ключей формата MLNK-XXXXX-...

Совместимо с парсером в `malinakod.core.license`.

Короткий формат (v2):
    MLNK-S-XXXXX-XXXXX-...
        ^
        маркер "short"
Полезная нагрузка — бинарно упакованные (client_id_b32, download_token_bytes),
base32 + HMAC-SHA256 (4 байта).

Длинный формат (v1, back-compat):
    MLNK-XXXXX-XXXXX-...
Тот же формат что в 0.1.0-0.2.x: gzip(JSON) + HMAC.
"""

from __future__ import annotations

import base64
import gzip
import hashlib
import hmac
import json
import secrets
import time
from dataclasses import asdict, dataclass, field

PREFIX = "MLNK"
BLOCK_LEN = 5
SHORT_MARKER = "S"  # Короткий формат

# Общий секрет должен совпадать с DEFAULT_SECRET в malinakod.core.license.
# Клиент валидирует ключ этим же секретом, иначе подпись не сойдётся.
SHARED_LICENSE_SECRET = b"malinakod-studio-shared-license-secret-v1"


@dataclass
class LicensePayload:
    client_id: str
    client_name: str
    expires: str  # YYYY-MM
    features: list[str] = field(default_factory=list)
    machine_id: str | None = None
    issued_at: int = field(default_factory=lambda: int(time.time()))
    agent_secret: str | None = None
    download_token: str | None = None  # GitHub PAT для синка из репо релизов

    def to_json(self) -> str:
        return json.dumps(asdict(self), separators=(",", ":"), sort_keys=True)


def _b32_encode(data: bytes) -> str:
    return base64.b32encode(data).decode("ascii").rstrip("=")


def _format_blocks(s: str, marker: str | None = None) -> str:
    blocks = [s[i : i + BLOCK_LEN] for i in range(0, len(s), BLOCK_LEN)]
    parts = [PREFIX]
    if marker:
        parts.append(marker)
    parts.extend(blocks)
    return "-".join(parts)


def generate_license(payload: LicensePayload, secret: bytes = SHARED_LICENSE_SECRET) -> str:
    """Старый длинный формат (gzip + JSON). Оставлен для тестов и back-compat."""
    raw = gzip.compress(payload.to_json().encode("utf-8"), mtime=0)
    sig = hmac.new(secret, raw, hashlib.sha256).digest()[:8]
    body = _b32_encode(raw + sig)
    return _format_blocks(body)


def generate_license_short(
    client_id: str,
    download_token: str,
    secret: bytes = SHARED_LICENSE_SECRET,
) -> str:
    """Короткий формат: только client_id + PAT + 4-байтовая подпись.

    Ключ выходит ~80-120 символов (зависит от длины PAT: classic 40 / fine-grained 93).
    """
    cid = client_id.encode("utf-8")
    tok = download_token.encode("utf-8")
    if len(cid) > 255 or len(tok) > 255:
        raise ValueError("client_id or download_token too long")
    # Формат: [1B cid_len][cid][1B tok_len][tok]
    raw = bytes([len(cid)]) + cid + bytes([len(tok)]) + tok
    sig = hmac.new(secret, raw, hashlib.sha256).digest()[:4]
    body = _b32_encode(raw + sig)
    return _format_blocks(body, marker=SHORT_MARKER)


def generate_client_id() -> str:
    """Короткий ID клиента вида `mlk_AbC1`."""
    return "mlk_" + secrets.token_urlsafe(6)


def generate_agent_secret() -> str:
    return secrets.token_hex(16)
