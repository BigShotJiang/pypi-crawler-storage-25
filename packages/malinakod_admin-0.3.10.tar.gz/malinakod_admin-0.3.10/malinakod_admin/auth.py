"""Хранилище админских настроек: мастер-пароль + GitHub PAT + license-secret.

Хранится в `~/.malinakod-admin/vault.json` зашифрованно (Fernet, ключ из PBKDF2 пароля).
"""

from __future__ import annotations

import base64
import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

VAULT_DIR = Path(os.environ.get("MALINAKOD_ADMIN_HOME", str(Path.home() / ".malinakod-admin")))
VAULT_PATH = VAULT_DIR / "vault.json"

KDF_ITERATIONS = 200_000


@dataclass
class AdminConfig:
    github_pat: str = ""
    license_secret: str = ""
    repo_owner: str = "Medenchi"
    repo_name: str = "Malinacode-releases"
    branch: str = "main"
    issued_keys: list[dict] = field(default_factory=list)


def _derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=KDF_ITERATIONS,
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8")))


def vault_exists() -> bool:
    return VAULT_PATH.exists()


def init_vault(password: str, config: AdminConfig) -> None:
    """Создаёт новое зашифрованное хранилище."""
    VAULT_DIR.mkdir(parents=True, exist_ok=True)
    salt = os.urandom(16)
    key = _derive_key(password, salt)
    f = Fernet(key)
    payload = json.dumps(asdict(config)).encode("utf-8")
    token = f.encrypt(payload)
    VAULT_PATH.write_bytes(salt + b"::" + token)
    try:
        os.chmod(VAULT_PATH, 0o600)
    except OSError:
        pass


def load_vault(password: str) -> AdminConfig:
    """Расшифровывает и загружает конфиг. Бросает ValueError при неверном пароле."""
    if not VAULT_PATH.exists():
        raise ValueError("Хранилище не инициализировано")
    raw = VAULT_PATH.read_bytes()
    sep = raw.find(b"::")
    if sep == -1:
        raise ValueError("Повреждённое хранилище")
    salt = raw[:sep]
    token = raw[sep + 2 :]
    key = _derive_key(password, salt)
    f = Fernet(key)
    try:
        decrypted = f.decrypt(token)
    except InvalidToken as exc:
        raise ValueError("Неверный пароль") from exc
    data = json.loads(decrypted.decode("utf-8"))
    return AdminConfig(**data)


def save_vault(password: str, config: AdminConfig) -> None:
    """Перешифровывает и сохраняет конфиг с тем же или новым паролем."""
    init_vault(password, config)
