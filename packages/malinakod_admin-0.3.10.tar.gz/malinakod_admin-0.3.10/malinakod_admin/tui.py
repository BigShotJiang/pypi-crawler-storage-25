"""TUI MalinaKod Admin — единственная точка входа для студии.

Запуск: `malinakod-admin`
Полностью menu-driven, без CLI-команд.
"""

from __future__ import annotations

import platform
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path

import httpx
import questionary
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

from . import __version__
from .auth import AdminConfig, init_vault, load_vault, save_vault, vault_exists
from .github_api import GitHubAdmin
from .license_gen import (
    SHARED_LICENSE_SECRET,
    generate_client_id,
    generate_license_short,
)

console = Console()


QSTYLE = questionary.Style(
    [
        ("qmark", "fg:#ff3366 bold"),
        ("question", "bold"),
        ("answer", "fg:#ff3366 bold"),
        ("pointer", "fg:#ff3366 bold"),
        ("highlighted", "fg:#ff3366 bold"),
        ("selected", "fg:#ffffff bg:#ff3366"),
        ("separator", "fg:#666666"),
        ("instruction", "fg:#888888"),
    ]
)


BANNER = r"""
[bold #ff3366] __  __       _ _              _  __         _    _    [/]
[bold #ff3366]|  \/  | __ _| (_)_ __   __ _| |/ /___   __| |  / \   __| |_ __ ___ (_)_ __  [/]
[bold #ff3366]| |\/| |/ _` | | | '_ \ / _` | ' // _ \ / _` | / _ \ / _` | '_ ` _ \| | '_ \ [/]
[bold #ff3366]| |  | | (_| | | | | | | (_| | . \ (_) | (_| |/ ___ \ (_| | | | | | | | | | |[/]
[bold #ff3366]|_|  |_|\__,_|_|_|_| |_|\__,_|_|\_\___/ \__,_/_/   \_\__,_|_| |_| |_|_|_| |_|[/]
"""


def _press_enter(message: str = "Нажмите Enter чтобы вернуться в меню") -> None:
    questionary.press_any_key_to_continue(message=message, style=QSTYLE).ask()


def print_banner() -> None:
    console.clear()
    console.print(BANNER)
    console.print(
        f"[dim]Студия MalinaKod · admin v{__version__}[/]\n"
    )


# --- Setup при первом запуске ---
def _setup_vault() -> tuple[str, AdminConfig] | None:
    print_banner()
    console.print(
        Panel(
            "Это первый запуск [bold]malinakod-admin[/].\n\n"
            "Сейчас мы создадим зашифрованное хранилище для ваших настроек "
            "(GitHub PAT, мастер-секрет лицензий, реестр клиентов).\n\n"
            "Хранилище будет лежать в [cyan]~/.malinakod-admin/vault.json[/] "
            "и шифроваться [bold]мастер-паролем[/], который вы сейчас придумаете.",
            title="Setup",
            border_style="#ff3366",
        )
    )
    while True:
        password = Prompt.ask("[bold]Придумайте мастер-пароль[/]", password=True)
        if len(password) < 6:
            console.print("[red]Пароль должен быть не короче 6 символов[/]")
            continue
        confirm = Prompt.ask("[bold]Повторите пароль[/]", password=True)
        if password != confirm:
            console.print("[red]Пароли не совпадают[/]")
            continue
        break

    console.print()
    console.print(
        Panel(
            "Теперь введите [bold]GitHub Personal Access Token (Fine-grained)[/] "
            "со следующими правами:\n\n"
            "  • Repository access: [cyan]Medenchi/Malinacode-releases[/] (Only select repositories)\n"
            "  • Permissions → Repository permissions → [cyan]Contents: Read and write[/]\n\n"
            "Создать токен можно тут: https://github.com/settings/personal-access-tokens/new",
            title="GitHub PAT",
            border_style="#ff3366",
        )
    )
    pat = Prompt.ask("[bold]GitHub PAT[/]").strip()

    repo_owner = Prompt.ask("Owner репозитория", default="Medenchi")
    repo_name = Prompt.ask("Имя репозитория", default="Malinacode-releases")

    # Секрет для подписи лицензий общий и зашит в пакетах
    # (malinakod-admin и malinakod используют SHARED_LICENSE_SECRET)
    license_secret = SHARED_LICENSE_SECRET.decode("utf-8")

    config = AdminConfig(
        github_pat=pat,
        license_secret=license_secret,
        repo_owner=repo_owner,
        repo_name=repo_name,
    )

    # Проверим PAT
    api = GitHubAdmin(pat, repo_owner, repo_name)
    console.print()
    console.print("[dim]Проверяю GitHub PAT...[/]")
    user = api.whoami()
    if not user:
        console.print(f"[red]PAT не работает: {api.last_auth_error}[/]")
        if not questionary.confirm("Сохранить всё равно?", default=False, style=QSTYLE).ask():
            return None
    else:
        console.print(f"[green]✓ Авторизован как [bold]{user}[/][/]")
        if not api.repo_exists():
            console.print(
                f"[yellow]! Репо [bold]{repo_owner}/{repo_name}[/] недоступно через этот PAT. "
                "Создайте его или измените PAT.[/]"
            )

    init_vault(password, config)
    console.print("[green]✓ Хранилище создано: ~/.malinakod-admin/vault.json[/]\n")
    time.sleep(1.5)
    return password, config


def _login() -> tuple[str, AdminConfig] | None:
    print_banner()
    for attempt in range(3):
        password = Prompt.ask("[bold]Мастер-пароль[/]", password=True)
        try:
            config = load_vault(password)
            return password, config
        except ValueError as exc:
            console.print(f"[red]✗ {exc}[/]")
            if attempt < 2:
                console.print(f"[dim]Осталось попыток: {2 - attempt}[/]")
    console.print("[red]Слишком много неверных попыток. Выход.[/]")
    return None


# --- Экраны ---
def screen_clients(api: GitHubAdmin, config: AdminConfig) -> None:
    console.print("\n[dim]Загружаю список клиентов...[/]")
    try:
        clients = api.list_clients()
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка GitHub API: {exc}[/]")
        _press_enter()
        return

    if not clients:
        console.print("[yellow]Пока нет клиентов. Создайте первого через меню.[/]")
        _press_enter()
        return

    table = Table(title="Клиенты", border_style="#ff3366")
    table.add_column("ID", style="cyan")
    table.add_column("Имя", style="bold")
    table.add_column("Manifest")
    table.add_column("Heartbeat")

    issued = {item["client_id"]: item for item in config.issued_keys}

    for c in clients:
        meta = issued.get(c.client_id, {})
        name = meta.get("client_name", "[dim]не зарегистрирован локально[/]")
        manifest_marker = "[green]✓[/]" if c.has_manifest else "[red]✗[/]"
        # Лёгкий пинг heartbeat — есть ли status.json
        hb_marker = "[dim]?[/]"
        try:
            st = api.fetch_status(c.client_id)
            if isinstance(st, dict) and st.get("heartbeat_at"):
                ago = int(time.time()) - int(st.get("heartbeat_at", 0))
                if ago < 120:
                    hb_marker = f"[green]онлайн ({ago}с)[/]"
                elif ago < 600:
                    hb_marker = f"[yellow]{ago // 60}м[/]"
                else:
                    hb_marker = f"[red]{ago // 60}м[/]"
        except Exception:  # noqa: BLE001
            pass
        table.add_row(c.client_id, name, manifest_marker, hb_marker)
    console.print(table)
    _press_enter()


def screen_new_client(
    api: GitHubAdmin, config: AdminConfig, password: str
) -> None:
    console.print()
    name = Prompt.ask("[bold]Имя клиента[/]")

    cid = generate_client_id()

    console.print(f"[dim]Создаю папку [cyan]clients/{cid}/[/] на GitHub...[/]")
    try:
        ok = api.create_client_folder(cid)
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка GitHub API: {exc}[/]")
        _press_enter()
        return
    if not ok:
        console.print("[yellow]! Папка создана не полностью. Проверьте репо вручную.[/]")

    # Короткий формат: client_id + PAT + HMAC (общий секрет зашит в обоих пакетах)
    # Короткий формат не несёт expires/machine_id — ключи бессрочные и не привязаны к машине
    key = generate_license_short(cid, config.github_pat, SHARED_LICENSE_SECRET)

    config.issued_keys.append(
        {
            "client_id": cid,
            "client_name": name,
            "issued_at": int(time.time()),
        }
    )
    save_vault(password, config)

    # Сохраняем ключ в файл для удобства
    key_dir = Path.home() / ".malinakod-admin" / "clients" / cid
    key_dir.mkdir(parents=True, exist_ok=True)
    key_path = key_dir / "key.txt"
    key_path.write_text(key + "\n", encoding="utf-8")

    # Информация в панели
    console.print()
    console.print(
        Panel(
            f"[bold]Клиент создан:[/] [cyan]{cid}[/]\n\n"
            f"[dim]Клиент должен будет:[/]\n"
            f"  1. Установить пакет: [cyan]pip install malinakod[/]\n"
            f"  2. Запустить: [cyan]python -m malinakod[/]\n"
            f"  3. Вставить ключ при первом запуске\n\n"
            f"[bold]Папка клиента в репо:[/]\n"
            f"https://github.com/{config.repo_owner}/{config.repo_name}/tree/{config.branch}/clients/{cid}\n\n"
            f"[bold]Ключ также сохранён в:[/]\n"
            f"[cyan]{key_path}[/]",
            title="Новый клиент",
            border_style="#ff3366",
        )
    )
    # Печатаем ключ ПЛОСКИМ текстом вне панели — чтобы копировался чисто
    console.print()
    console.print(f"[bold green]Ключ ({len(key)} символов) — выделите и скопируйте строку ниже:[/]")
    console.print()
    print(key)  # plain print без Rich форматирования
    console.print()
    _press_enter()


def screen_open_client_folder(api: GitHubAdmin, config: AdminConfig) -> None:
    try:
        clients = api.list_clients()
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка: {exc}[/]")
        _press_enter()
        return
    if not clients:
        console.print("[yellow]Нет клиентов[/]")
        _press_enter()
        return
    choice = questionary.select(
        "Выберите клиента:",
        choices=[c.client_id for c in clients] + ["— Назад —"],
        style=QSTYLE,
    ).ask()
    if not choice or choice == "— Назад —":
        return
    url = (
        f"https://github.com/{config.repo_owner}/{config.repo_name}"
        f"/tree/{config.branch}/clients/{choice}"
    )
    console.print(f"[green]Открываю:[/] [cyan]{url}[/]")
    try:
        webbrowser.open(url)
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Не удалось открыть браузер: {exc}[/]")
    _press_enter()


def screen_send_command(api: GitHubAdmin, config: AdminConfig) -> None:
    try:
        clients = api.list_clients()
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка: {exc}[/]")
        _press_enter()
        return
    if not clients:
        console.print("[yellow]Нет клиентов[/]")
        _press_enter()
        return

    cid = questionary.select(
        "Кому послать команду:",
        choices=[c.client_id for c in clients] + ["— Назад —"],
        style=QSTYLE,
    ).ask()
    if not cid or cid == "— Назад —":
        return

    cmd = Prompt.ask("[bold]Команда (shell)[/]")
    if not cmd.strip():
        return

    try:
        name = api.send_command(cid, cmd)
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка отправки: {exc}[/]")
        _press_enter()
        return
    console.print(f"[green]✓ Команда отправлена: [cyan]{name}[/]")
    console.print(
        "[dim]Клиент подхватит её в течение 30 секунд и положит результат в output/.[/]"
    )

    if questionary.confirm("Подождать ответа? (макс 90 сек)", default=True, style=QSTYLE).ask():
        deadline = time.time() + 90
        while time.time() < deadline:
            try:
                output = api.fetch_output(cid, name)
            except Exception:  # noqa: BLE001
                output = None
            if output is not None:
                console.print(Panel(output, title=f"Ответ от {cid}", border_style="green"))
                _press_enter()
                return
            time.sleep(5)
        console.print("[yellow]Ответ не получен за 90 сек. Проверьте output/ позже.[/]")
    _press_enter()


def _wait_for_output(
    api: GitHubAdmin,
    client_id: str,
    cmd_name: str,
    timeout_sec: int = 120,
    poll_sec: int = 5,
) -> str | None:
    """Ждёт ответ клиента, возвращает stdout+stderr или None по таймауту."""
    deadline = time.time() + timeout_sec
    while time.time() < deadline:
        try:
            output = api.fetch_output(client_id, cmd_name)
        except Exception:  # noqa: BLE001
            output = None
        if output is not None:
            return output
        time.sleep(poll_sec)
    return None


def screen_view_logs(api: GitHubAdmin) -> None:
    """Показать логи сервиса с клиента (через send_command под капотом)."""
    section_title("📜 Логи сервиса клиента")
    console.print(
        "[dim]Тянем последние строки лога с клиента через GitHub. "
        "Клиент подцепит запрос за 5–30 секунд.[/]\n"
    )
    try:
        clients = api.list_clients()
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка: {exc}[/]")
        _press_enter()
        return
    if not clients:
        console.print("[yellow]Нет клиентов[/]")
        _press_enter()
        return

    cid = questionary.select(
        "Клиент:",
        choices=[c.client_id for c in clients] + ["— Назад —"],
        style=QSTYLE,
    ).ask()
    if not cid or cid == "— Назад —":
        return

    # Берём список сервисов из manifest чтобы предложить выбор.
    services: list[str] = []
    try:
        manifest = api.fetch_manifest(cid)
        if isinstance(manifest, dict):
            mlist = manifest.get("services", [])
            if isinstance(mlist, list):
                for s in mlist:
                    if isinstance(s, dict) and s.get("name"):
                        services.append(str(s["name"]))
    except Exception:  # noqa: BLE001
        pass

    if services:
        service = questionary.select(
            "Сервис:",
            choices=[*services, "✏️  Ввести имя вручную", "— Назад —"],
            style=QSTYLE,
        ).ask()
        if not service or service == "— Назад —":
            return
        if service.startswith("✏️"):
            service = Prompt.ask("[bold]Имя сервиса[/]").strip()
            if not service:
                return
    else:
        console.print(
            "[yellow]Manifest пуст — введите имя сервиса вручную (как назвали при деплое).[/]"
        )
        service = Prompt.ask("[bold]Имя сервиса[/]").strip()
        if not service:
            return

    lines = Prompt.ask("[bold]Сколько последних строк[/]", default="100")
    try:
        n_lines = max(1, min(2000, int(lines)))
    except ValueError:
        n_lines = 100

    # Кросс-платформенный one-liner: ищет ~/.malinakod/*/logs/<service>.log
    # и печатает последние N строк (через splitlines + срез).
    py_cmd = (
        f"python -c \"from pathlib import Path; "
        f"root=Path.home()/'.malinakod'; "
        f"hits=list(root.glob('*/logs/{service}.log')); "
        f"print('NOT FOUND: ' + str(root) + '/<client>/logs/{service}.log') "
        f"if not hits else "
        f"print('\\n'.join(hits[0].read_text(encoding='utf-8',errors='replace').splitlines()[-{n_lines}:]))\""
    )

    console.print(f"[dim]Отправляю запрос логов для [cyan]{service}[/]...[/]")
    try:
        cmd_name = api.send_command(cid, py_cmd)
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка отправки: {exc}[/]")
        _press_enter()
        return

    console.print("[dim]Ждём ответ клиента (до 90 сек)...[/]")
    output = _wait_for_output(api, cid, cmd_name, timeout_sec=90, poll_sec=5)
    if output is None:
        console.print(
            "[yellow]Ответ не получен за 90с. Возможно клиент офлайн или "
            "интервал sync длиннее 30с. Попробуйте позже через '💻 Послать команду'.[/]"
        )
        _press_enter()
        return

    body = output.strip() or "[пусто — лог существует, но без строк]"
    if "NOT FOUND" in body and not body.startswith("NOT FOUND"):
        # Это просто упоминание в логе — не путаем со статусом ошибки.
        pass
    console.print(
        Panel(
            body,
            title=f"📜 {service} (последние {n_lines} строк, клиент {cid})",
            border_style="green" if not body.startswith("NOT FOUND") else "yellow",
        )
    )
    _press_enter()


# Safe-update PowerShell скрипт для Windows.
# Логика: capture old → pip upgrade → smoke-test нового кода в subprocess →
# если smoke упал → откат pip; старый процесс продолжает работать.
# Если smoke OK → конфигурим auto-restart task → /End → /Run.
_WINDOWS_SAFE_UPDATE_PS = r"""
$ErrorActionPreference = 'Continue'
function Log($msg) { Write-Output "[malinakod-update] $msg" }
Log "Starting safe update flow"

$oldVer = ''
try {
    $oldVer = (& python -m pip show malinakod 2>$null | Select-String '^Version:' | ForEach-Object { ($_ -split ':')[1].Trim() })
} catch { $oldVer = '' }
if (-not $oldVer) { $oldVer = '' }
Log "Current version: '$oldVer'"

Log "Running pip install --upgrade malinakod ..."
& python -m pip install --upgrade malinakod 2>&1 | ForEach-Object { Log $_ }
if ($LASTEXITCODE -ne 0) {
    Log "PIP_FAILED exit=$LASTEXITCODE"
    Log "Old process untouched. UPDATE_ABORTED_PIP_FAILED"
    exit 1
}

$newVer = ''
try {
    $newVer = (& python -m pip show malinakod 2>$null | Select-String '^Version:' | ForEach-Object { ($_ -split ':')[1].Trim() })
} catch { $newVer = '' }
if (-not $newVer) { $newVer = '' }
Log "New version: '$newVer'"

if ($oldVer -and ($oldVer -eq $newVer)) {
    Log "Already at $newVer (no upgrade needed)."
    Log "UPDATED_OK $newVer (no change)"
    exit 0
}

Log "Smoke-testing $newVer in subprocess (old process is still alive) ..."
$smokeCode = "import malinakod; from malinakod.tui import run; from malinakod.core.orchestrator import Orchestrator; from malinakod.core.heartbeat import Heartbeat; from malinakod.core.sync import GitHubSync; from malinakod.core.command_runner import CommandRunner; print('SMOKE_OK')"
$smokeOut = & python -c $smokeCode 2>&1 | Out-String
Log "Smoke output: $($smokeOut.Trim())"

if ($smokeOut -notmatch 'SMOKE_OK') {
    Log "SMOKE FAILED — old process kept running, NOT restarting task."
    if ($oldVer) {
        Log "Rolling pip back to $oldVer ..."
        & python -m pip install --force-reinstall "malinakod==$oldVer" 2>&1 | ForEach-Object { Log $_ }
        Log "UPDATE_ABORTED_ROLLBACK_OK from $newVer back to $oldVer (old process kept running)"
    } else {
        Log "Cannot rollback (no old version captured). Task NOT restarted; in-memory old code keeps running until reboot."
        Log "UPDATE_ABORTED_NO_ROLLBACK"
    }
    exit 1
}

try {
    $task = Get-ScheduledTask -TaskName MalinaKod -ErrorAction Stop
    $task.Settings.RestartCount = 3
    $task.Settings.RestartInterval = 'PT1M'
    Set-ScheduledTask -TaskName MalinaKod -InputObject $task | Out-Null
    Log "Auto-restart configured (3 retries x 1 min)."
} catch {
    Log "WARN: failed to configure auto-restart on task: $($_.Exception.Message)"
}

Log "Restarting MalinaKod scheduled task ..."
schtasks /End /TN MalinaKod 2>&1 | ForEach-Object { Log $_ }
Start-Sleep -Seconds 2
schtasks /Run /TN MalinaKod 2>&1 | ForEach-Object { Log $_ }
Log "UPDATED_OK $oldVer -> $newVer"
exit 0
""".strip()


_LINUX_SAFE_UPDATE_SH = r"""
set +e
log() { echo "[malinakod-update] $*"; }
log "Starting safe update flow"

old_ver=$(python3 -m pip show malinakod 2>/dev/null | awk '/^Version:/{print $2}')
log "Current: ${old_ver:-<none>}"

python3 -m pip install --upgrade --user malinakod 2>&1
pip_rc=$?
if [ $pip_rc -ne 0 ]; then
    log "PIP_FAILED rc=$pip_rc — old process untouched."
    log "UPDATE_ABORTED_PIP_FAILED"
    exit 1
fi

new_ver=$(python3 -m pip show malinakod 2>/dev/null | awk '/^Version:/{print $2}')
log "New: ${new_ver:-<none>}"

if [ -n "$old_ver" ] && [ "$old_ver" = "$new_ver" ]; then
    log "UPDATED_OK $new_ver (no change)"
    exit 0
fi

log "Smoke-testing $new_ver (old process kept alive)..."
SMOKE=$(python3 -c 'import malinakod; from malinakod.tui import run; from malinakod.core.orchestrator import Orchestrator; from malinakod.core.heartbeat import Heartbeat; from malinakod.core.sync import GitHubSync; from malinakod.core.command_runner import CommandRunner; print("SMOKE_OK")' 2>&1)
log "Smoke: $SMOKE"
if ! echo "$SMOKE" | grep -q SMOKE_OK; then
    log "SMOKE FAILED — NOT restarting service."
    if [ -n "$old_ver" ]; then
        python3 -m pip install --force-reinstall --user "malinakod==$old_ver" 2>&1
        log "UPDATE_ABORTED_ROLLBACK_OK from $new_ver back to $old_ver"
    else
        log "UPDATE_ABORTED_NO_ROLLBACK"
    fi
    exit 1
fi

systemctl --user restart malinakod 2>&1 || systemctl restart malinakod 2>&1 || true
log "UPDATED_OK $old_ver -> $new_ver"
""".strip()


def _build_windows_update_cmd() -> str:
    """Кодируем PowerShell-скрипт в base64 (UTF-16-LE) → -EncodedCommand."""
    import base64
    encoded = base64.b64encode(
        _WINDOWS_SAFE_UPDATE_PS.encode("utf-16-le")
    ).decode("ascii")
    return f"powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand {encoded}"


def _build_linux_update_cmd() -> str:
    """base64 + bash чтобы избежать проблем с экранированием."""
    import base64
    encoded = base64.b64encode(_LINUX_SAFE_UPDATE_SH.encode("utf-8")).decode("ascii")
    return f"echo {encoded} | base64 -d | bash"


def screen_update_client(api: GitHubAdmin) -> None:
    """Безопасное обновление malinakod на клиенте.

    Старый процесс остаётся жив пока новая версия не пройдёт smoke-test.
    Если smoke упал — pip откатывается на старую версию, scheduled task
    не трогается (старый процесс продолжает работать с уже-загруженным
    в память кодом).
    """
    section_title("🔄 Обновить malinakod на клиенте (safe-update)")
    console.print(
        "[dim]Алгоритм:\n"
        "  1. Запоминаем текущую версию pip\n"
        "  2. pip install --upgrade malinakod  ([bold]старый процесс жив[/])\n"
        "  3. Smoke-test новых модулей в subprocess\n"
        "  4. Если smoke упал → откат pip → старый процесс продолжает работать\n"
        "  5. Если smoke OK → конфигурим auto-restart task → перезапуск\n"
        "[/]"
    )
    try:
        clients = api.list_clients()
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка: {exc}[/]")
        _press_enter()
        return
    if not clients:
        console.print("[yellow]Нет клиентов[/]")
        _press_enter()
        return

    cid = questionary.select(
        "Клиент:",
        choices=[c.client_id for c in clients] + ["— Назад —"],
        style=QSTYLE,
    ).ask()
    if not cid or cid == "— Назад —":
        return

    os_name = ""
    try:
        st = api.fetch_status(cid)
        if isinstance(st, dict):
            os_name = str(st.get("os", "")).lower()
    except Exception:  # noqa: BLE001
        pass
    is_windows = "windows" in os_name
    is_unix = ("linux" in os_name) or ("darwin" in os_name)

    if is_windows:
        update_cmd = _build_windows_update_cmd()
        target_label = "Windows (Scheduled Task: MalinaKod, safe-update)"
    elif is_unix:
        update_cmd = _build_linux_update_cmd()
        target_label = "Linux/macOS (systemd, safe-update)"
    else:
        console.print(
            "[yellow]ОС клиента не определена (нет heartbeat). "
            "Использую Windows-команду по умолчанию.[/]"
        )
        update_cmd = _build_windows_update_cmd()
        target_label = "Windows (по умолчанию, safe-update)"

    console.print(
        Panel(
            f"Целевой клиент: [cyan]{cid}[/]\n"
            f"Платформа: [cyan]{target_label}[/]\n\n"
            f"[dim]Команда отправляется как base64-encoded скрипт "
            f"({len(update_cmd)} символов в shell-командной строке).[/]",
            title="План обновления (safe)",
            border_style="#ff3366",
        )
    )

    if not questionary.confirm(
        "Запустить безопасное обновление?", default=True, style=QSTYLE
    ).ask():
        return

    try:
        cmd_name = api.send_command(cid, update_cmd)
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка отправки: {exc}[/]")
        _press_enter()
        return

    console.print(
        f"[green]✓ Команда отправлена ({cmd_name}).[/] "
        "[dim]Жду ответ от клиента (до 4 минут — pip + smoke + рестарт)...[/]"
    )
    output = _wait_for_output(api, cid, cmd_name, timeout_sec=240, poll_sec=10)
    if output is None:
        console.print(
            "[yellow]Ответ не получен за 4 минуты.[/]\n"
            "[dim]Возможные причины: клиент офлайн / pip качает медленно / "
            "сеть. Старый процесс должен продолжать работать (он не закрывался "
            "пока не было SMOKE_OK). Проверьте '📊 Статус' через 1-2 минуты.[/]"
        )
        _press_enter()
        return

    body = output.strip()
    success = "UPDATED_OK" in body and "ABORTED" not in body
    aborted_safe = "ABORTED_ROLLBACK_OK" in body or "ABORTED_PIP_FAILED" in body
    aborted_unsafe = "ABORTED_NO_ROLLBACK" in body

    if success:
        title = f"✓ Обновление завершено — {cid}"
        border = "green"
    elif aborted_safe:
        title = f"↩ Откат — старый процесс жив — {cid}"
        border = "yellow"
    elif aborted_unsafe:
        title = f"⚠ Обновление прервано БЕЗ отката — {cid}"
        border = "red"
    else:
        title = f"✗ Неопределённый результат — {cid}"
        border = "red"

    console.print(Panel(body or "[нет вывода]", title=title, border_style=border))

    if success:
        console.print(
            "[dim]Heartbeat должен обновиться в течение 1 минуты с новой версией. "
            "Auto-restart на Scheduled Task настроен (3 попытки × 1 мин).[/]"
        )
    elif aborted_safe:
        console.print(
            "[dim]Это безопасный исход: pip откатился на предыдущую версию, "
            "старый процесс никогда не закрывался, всё продолжает работать. "
            "Изучите вывод выше — там видно почему smoke упал.[/]"
        )
    elif aborted_unsafe:
        console.print(
            "[red dim]ВНИМАНИЕ: новая версия установилась, но smoke-test упал, "
            "и откатиться не получилось (не удалось определить старую версию). "
            "Старый процесс пока работает на коде в памяти, но при следующем "
            "ребуте может не запуститься. Срочно зайдите по SSH/Tailscale "
            "и установите вручную старую версию или подняйте новую.[/]"
        )
    _press_enter()


def screen_deploy_project(api: GitHubAdmin, config: AdminConfig) -> None:
    """Развернуть локальную папку с проектом на клиенте.

    Workflow:
    1. Выбрать клиента
    2. Указать путь к локальной папке
    3. Указать команду запуска
    4. Опционально: имя сервиса, порт
    5. Загрузить файлы + обновить manifest.json
    """
    section_panel = Panel(
        "Деплой локальной папки с проектом на клиента.\n"
        "После деплоя клиент через ~30с скачает файлы и запустит указанную команду.\n"
        "Проект может содержать любое количество файлов и подпапок.",
        title="📦 Деплой проекта",
        border_style="#ff3366",
    )
    console.print(section_panel)

    try:
        clients = api.list_clients()
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка: {exc}[/]")
        _press_enter()
        return
    if not clients:
        console.print("[yellow]Нет клиентов. Сначала создай клиента.[/]")
        _press_enter()
        return

    # Меню выбора действия (deploy / list / remove)
    while True:
        action = questionary.select(
            "Что сделать:",
            choices=[
                "🚀  Залить новый проект на клиента",
                "📋  Посмотреть что задеплоено у клиента",
                "🗑  Удалить сервис из manifest клиента",
                "— Назад —",
            ],
            style=QSTYLE,
        ).ask()
        if not action or action == "— Назад —":
            return

        cid = questionary.select(
            "Клиент:",
            choices=[c.client_id for c in clients] + ["— Назад —"],
            style=QSTYLE,
        ).ask()
        if not cid or cid == "— Назад —":
            continue

        if action.startswith("🚀"):
            _deploy_new_project(api, cid)
        elif action.startswith("📋"):
            _show_client_manifest(api, cid)
        elif action.startswith("🗑"):
            _remove_service_from_client(api, cid)


def _deploy_new_project(api: GitHubAdmin, client_id: str) -> None:
    """Заливка одного проекта (папка + run-команда + manifest entry)."""
    console.print()
    console.print(f"[bold]Деплой на клиента:[/] [cyan]{client_id}[/]")
    console.print()

    # Папка проекта
    while True:
        folder = Prompt.ask(
            "[bold]Локальная папка с проектом[/] (полный путь)"
        ).strip()
        if not folder:
            console.print("[yellow]Путь пустой, повтори или Ctrl+C[/]")
            continue
        path = Path(folder).expanduser().resolve()
        if not path.is_dir():
            console.print(f"[red]Не папка или не существует: {path}[/]")
            continue
        break

    # Имя сервиса
    default_name = path.name.replace(" ", "_").lower()
    service_name = Prompt.ask(
        "[bold]Имя сервиса[/] (используется для пути в files/ и в manifest)",
        default=default_name,
    ).strip()
    if not service_name:
        console.print("[yellow]Отменено[/]")
        return

    # Команда запуска
    console.print()
    console.print(
        Panel(
            "[bold]Команда запуска[/] — что именно вызвать когда клиент скачает файлы.\n\n"
            "Примеры:\n"
            "  [cyan]python app.py[/]\n"
            "  [cyan]python -m mypackage[/]\n"
            "  [cyan]node server.js[/]\n"
            "  [cyan]./run.sh[/] (для Linux-клиентов)\n\n"
            "Команда запускается из папки проекта (cwd = files/" + service_name + "/).\n"
            "Если у проекта нет single entry-point, заверни запуск в start.sh / start.ps1.",
            title="Run command",
            border_style="cyan",
        )
    )
    run_cmd = Prompt.ask("[bold]Команда[/]").strip()
    if not run_cmd:
        console.print("[yellow]Команда пустая, отменяю[/]")
        return

    # Порт (опционально)
    port_str = Prompt.ask(
        "[bold]Порт[/] (опционально, для отображения)",
        default="",
    ).strip()
    port: int | None = None
    if port_str:
        try:
            port = int(port_str)
        except ValueError:
            console.print("[yellow]Порт не число, игнорирую[/]")

    visible_answer = questionary.confirm(
        "Видимый сервис? (отображается в TUI клиента и в админке)",
        default=True,
        style=QSTYLE,
    ).ask()
    if visible_answer is None:
        # Ctrl+C на этом промпте — отменяем весь деплой, чтобы не записать
        # `"visible": null` в manifest (на клиенте это превратится в hidden-сервис).
        console.print("[yellow]Отменено[/]")
        return
    visible = bool(visible_answer)

    # Подсчёт файлов для предупреждения
    file_count = sum(1 for _ in path.rglob("*") if _.is_file())

    console.print()
    console.print(
        Panel(
            f"[bold]Клиент:[/] {client_id}\n"
            f"[bold]Локальная папка:[/] {path}\n"
            f"[bold]Файлов в папке (примерно):[/] {file_count}\n"
            f"[bold]Имя сервиса:[/] {service_name}\n"
            f"[bold]Команда:[/] {run_cmd}\n"
            f"[bold]Порт:[/] {port if port else '—'}\n"
            f"[bold]Visible:[/] {'да' if visible else 'нет'}\n\n"
            f"[bold]Файлы будут загружены в:[/]\n"
            f"  clients/{client_id}/files/{service_name}/\n\n"
            f"[bold]manifest.json[/] будет обновлён (добавится/перезапишется сервис '{service_name}').",
            title="Подтверди деплой",
            border_style="#ff3366",
        )
    )

    if not questionary.confirm("Загружаем?", default=True, style=QSTYLE).ask():
        console.print("[yellow]Отменено[/]")
        return

    # --- Заливка ---
    console.print()
    console.print("[bold]Загружаю файлы (по одному через GitHub API)...[/]")

    def _progress(idx: int, total: int, name: str) -> None:
        console.print(f"  [{idx}/{total}] [cyan]{name}[/]")

    try:
        uploaded, total, errors = api.upload_directory(
            client_id=client_id,
            local_path=str(path),
            target_subpath=service_name,
            progress_cb=_progress,
        )
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка заливки: {exc}[/]")
        _press_enter()
        return

    console.print()
    if errors:
        console.print(f"[yellow]Частичный успех: {uploaded}/{total} файлов загружено[/]")
        for err in errors[:10]:
            console.print(f"  [red]✗[/] {err}")
        if len(errors) > 10:
            console.print(f"  [red]... и ещё {len(errors) - 10} ошибок[/]")
    else:
        console.print(f"[green]✓ Все {uploaded} файлов загружены[/]")

    if uploaded == 0:
        console.print("[red]Ничего не залилось — manifest не обновляю.[/]")
        _press_enter()
        return

    # --- Обновляем manifest ---
    console.print("[bold]Обновляю manifest.json...[/]")
    service: dict = {
        "name": service_name,
        "run": run_cmd,
        "cwd": service_name,
        "visible": visible,
    }
    if port is not None:
        service["port"] = port

    try:
        ok, msg = api.update_manifest(client_id, service, replace=True)
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка обновления manifest: {exc}[/]")
        _press_enter()
        return

    if ok:
        console.print(f"[green]✓ {msg}[/]")
        console.print()
        console.print(
            Panel(
                "Клиент через ~30 секунд:\n"
                f"  1. Скачает файлы в [cyan]~/.malinakod/repo/clients/{client_id}/files/{service_name}/[/]\n"
                f"  2. Прочитает обновлённый [cyan]manifest.json[/]\n"
                f"  3. Запустит: [cyan]{run_cmd}[/]\n"
                f"  4. Зашлёт PID в heartbeat — увидишь его в [bold]📊 Статус[/]\n\n"
                "Если что-то пойдёт не так — смотри логи в "
                f"[cyan]~/.malinakod/logs/{service_name}.log[/] на клиенте "
                "(или через [bold]💻 Послать команду[/]).",
                title="✓ Деплой завершён",
                border_style="green",
            )
        )
        # Сразу показываем что сейчас в manifest клиента, чтобы было видно
        # что новый сервис реально записался. Сетевые ошибки тут не должны
        # ронять success-экран — деплой уже прошёл.
        console.print()
        section_title("Сейчас в manifest этого клиента")
        try:
            _print_manifest_services(api, client_id)
        except Exception as exc:  # noqa: BLE001
            console.print(
                f"[dim]Не удалось прочитать manifest для отображения: {exc}[/]"
            )
        # Опционально — статус (если клиент уже отвечает).
        try:
            status = api.fetch_status(client_id)
        except Exception:  # noqa: BLE001
            status = None
        if status:
            console.print()
            section_title(f"Текущий статус клиента {client_id}")
            try:
                _render_client_status(status, client_id, api)
            except Exception as exc:  # noqa: BLE001
                console.print(
                    f"[dim]Не удалось отрендерить статус: {exc}[/]"
                )
            console.print(
                "[dim]Сервис в статусе появится через ~30-60с после того как "
                "клиент подцепит manifest.[/]"
            )
    else:
        console.print(f"[red]✗ {msg}[/]")

    _press_enter()


def section_title(text: str) -> None:
    console.print(f"[bold #ff3366]── {text} ──[/]")


def _print_manifest_services(api: GitHubAdmin, client_id: str) -> None:
    """Внутренний рендер сервисов из manifest без _press_enter."""
    manifest = api.fetch_manifest(client_id)
    if manifest is None:
        console.print(f"[yellow]manifest.json не найден у {client_id}[/]")
        return
    services = manifest.get("services", []) if isinstance(manifest, dict) else []
    if not services:
        console.print(f"[yellow]У {client_id} нет деплойнутых сервисов[/]")
        return
    table = Table(show_header=True, border_style="#ff3366")
    table.add_column("Имя", style="cyan")
    table.add_column("Команда", style="white")
    table.add_column("cwd", style="dim")
    table.add_column("Порт", justify="right")
    table.add_column("Visible", justify="center")
    for s in services:
        if not isinstance(s, dict):
            continue
        table.add_row(
            str(s.get("name", "—")),
            str(s.get("run", "—")),
            str(s.get("cwd", "—")),
            str(s.get("port", "—")) if s.get("port") else "—",
            "✓" if s.get("visible", True) else "—",
        )
    console.print(table)


def _show_client_manifest(api: GitHubAdmin, client_id: str) -> None:
    """Показать manifest.json клиента (отдельный экран меню)."""
    section_title(f"Сервисы клиента {client_id}")
    _print_manifest_services(api, client_id)
    _press_enter()


def _remove_service_from_client(api: GitHubAdmin, client_id: str) -> None:
    """Убрать один сервис из manifest клиента (файлы оставляем)."""
    import json as _json

    with httpx.Client(headers=api._headers()) as c:  # noqa: SLF001
        raw = api.get_file(c, f"clients/{client_id}/manifest.json")
    if raw is None:
        console.print(f"[yellow]manifest.json не найден у {client_id}[/]")
        _press_enter()
        return
    try:
        manifest = _json.loads(raw.decode("utf-8"))
    except Exception:  # noqa: BLE001
        console.print("[red]manifest не парсится[/]")
        _press_enter()
        return
    services = manifest.get("services", []) if isinstance(manifest, dict) else []
    names = [s.get("name") for s in services if isinstance(s, dict) and s.get("name")]
    if not names:
        console.print(f"[yellow]У {client_id} нет сервисов в manifest[/]")
        _press_enter()
        return

    target = questionary.select(
        "Какой сервис убрать?",
        choices=[*[str(n) for n in names], "— Отмена —"],
        style=QSTYLE,
    ).ask()
    if not target or target == "— Отмена —":
        return

    if not questionary.confirm(
        f"Точно удалить '{target}' из manifest? (Файлы в files/ останутся, но клиент остановит сервис.)",
        default=False,
        style=QSTYLE,
    ).ask():
        return

    try:
        ok, msg = api.remove_service_from_manifest(client_id, target)
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка: {exc}[/]")
        _press_enter()
        return

    if ok:
        console.print(f"[green]✓ {msg}[/]")
    else:
        console.print(f"[red]✗ {msg}[/]")
    _press_enter()


def screen_view_status(api: GitHubAdmin) -> None:
    try:
        clients = api.list_clients()
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка: {exc}[/]")
        _press_enter()
        return
    if not clients:
        console.print("[yellow]Нет клиентов[/]")
        _press_enter()
        return
    cid = questionary.select(
        "Клиент:",
        choices=[c.client_id for c in clients] + ["— Назад —"],
        style=QSTYLE,
    ).ask()
    if not cid or cid == "— Назад —":
        return
    status = api.fetch_status(cid)
    if not status:
        console.print(
            f"[yellow]У клиента {cid} нет status.json. "
            "Возможно клиент ещё не запускался или не пишет heartbeat.[/]"
        )
        _press_enter()
        return

    _render_client_status(status, cid, api)
    _press_enter()


def _g(d: object, *path: str, default: str = "—") -> str:
    """Безопасно достаёт вложенный ключ из dict-tree."""
    cur: object = d
    for key in path:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(key)
        if cur is None:
            return default
    return str(cur)


def _render_client_status(status: dict, cid: str, api: GitHubAdmin) -> None:
    """Красиво печатает status.json клиента: машина + сервисы + tailscale.

    Если клиент >= 0.4.3 — публикует полное `hardware` поле, рендерим расширенно
    (CPU модель, GPU, материнка, все диски, сетевые адаптеры, права юзера).
    Старые клиенты — flat поля, рендерим как раньше.
    """
    last_heartbeat = status.get("heartbeat_at")
    hb_age = ""
    if isinstance(last_heartbeat, int):
        ts = datetime.fromtimestamp(last_heartbeat, tz=timezone.utc)
        ago = (datetime.now(tz=timezone.utc) - ts).total_seconds()
        if ago < 90:
            hb_age = f"[green]({int(ago)}с назад)[/]"
        elif ago < 600:
            hb_age = f"[yellow]({int(ago // 60)}м {int(ago % 60)}с назад)[/]"
        else:
            hb_age = f"[red]({int(ago // 60)}м назад — клиент не отвечает)[/]"
        hb_str = ts.strftime("%Y-%m-%d %H:%M:%S UTC")
    else:
        hb_str = "—"

    hw = status.get("hardware") if isinstance(status.get("hardware"), dict) else None

    # --- Машина: общая инфа ---
    info_table = Table(show_header=False, border_style="#ff3366", padding=(0, 1))
    info_table.add_column("k", style="bold")
    info_table.add_column("v", style="cyan")
    info_table.add_row("Client ID", cid)
    info_table.add_row("Hostname", str(status.get("hostname", "—")))
    os_str = str(status.get("os", "—"))
    if hw:
        bitness = _g(hw, "os", "bitness")
        if bitness != "—":
            os_str += f" ({bitness})"
    info_table.add_row("OS", os_str)
    if hw:
        info_table.add_row("OS version", _g(hw, "os", "version"))

    user_str = str(status.get("os_user", "—"))
    if hw:
        is_admin = _g(hw, "user", "is_admin")
        if is_admin == "True":
            user_str += "  [green](admin)[/]"
        elif is_admin == "False":
            user_str += "  [dim](обычный)[/]"
    info_table.add_row("OS user", user_str)
    info_table.add_row("IP", str(status.get("ip", "—")))
    if hw:
        info_table.add_row("Uptime", _g(hw, "uptime"))
        info_table.add_row("Python", _g(hw, "os", "python"))

    cpu_str = (
        f"{status.get('cpu_cores', '?')} ядер ({status.get('cpu_load', '?')}%)"
    )
    if hw:
        model = _g(hw, "cpu", "model")
        if model != "—":
            cores_p = _g(hw, "cpu", "cores_physical")
            cpu_str = f"{model}\n  {cores_p} физ / {status.get('cpu_cores', '?')} лог ядер ({status.get('cpu_load', '?')}%)"
    info_table.add_row("CPU", cpu_str)

    info_table.add_row(
        "RAM",
        f"{status.get('ram_free', '?')} свободно из {status.get('ram_total', '?')}",
    )
    info_table.add_row(
        "Диск (root)",
        f"{status.get('disk_free', '?')} свободно из {status.get('disk_total', '?')}",
    )
    info_table.add_row("Heartbeat", f"{hb_str} {hb_age}".strip())
    console.print(info_table)

    # --- Расширенная инфа: GPU, материнка, все диски, сетевые адаптеры ---
    if hw:
        gpus = hw.get("gpus")
        if isinstance(gpus, list) and gpus:
            console.print()
            console.print("[bold]Видеокарты:[/]")
            for g in gpus:
                console.print(f"  [cyan]{g}[/]")

        mb = hw.get("motherboard")
        if isinstance(mb, dict) and (
            mb.get("manufacturer", "—") != "—" or mb.get("product", "—") != "—"
        ):
            console.print()
            console.print(
                f"[bold]Материнка:[/] [cyan]{mb.get('manufacturer', '—')} "
                f"{mb.get('product', '—')}[/]"
            )

        disks = hw.get("disks")
        if isinstance(disks, list) and len(disks) > 1:
            console.print()
            disk_table = Table(title=f"Диски ({len(disks)})", border_style="#ff3366")
            disk_table.add_column("Устройство", style="bold")
            disk_table.add_column("Mount", style="cyan")
            disk_table.add_column("ФС")
            disk_table.add_column("Всего")
            disk_table.add_column("Свободно")
            disk_table.add_column("%")
            for d in disks:
                if not isinstance(d, dict):
                    continue
                disk_table.add_row(
                    str(d.get("device", "—")),
                    str(d.get("mountpoint", "—")),
                    str(d.get("fstype", "—")),
                    str(d.get("total_human", "—")),
                    str(d.get("free_human", "—")),
                    f"{d.get('percent', '?')}%",
                )
            console.print(disk_table)

        adapters_obj = (
            hw.get("network", {}).get("adapters")
            if isinstance(hw.get("network"), dict)
            else None
        )
        if isinstance(adapters_obj, list) and adapters_obj:
            console.print()
            ad_table = Table(title="Сетевые адаптеры", border_style="#ff3366")
            ad_table.add_column("Имя", style="bold")
            ad_table.add_column("IPv4", style="cyan")
            ad_table.add_column("MAC")
            ad_table.add_column("Статус")
            for a in adapters_obj:
                if not isinstance(a, dict):
                    continue
                up = "[green]up[/]" if a.get("up") else "[dim]down[/]"
                ad_table.add_row(
                    str(a.get("name", "—")),
                    str(a.get("ipv4", "—")),
                    str(a.get("mac", "—")),
                    up,
                )
            console.print(ad_table)

    # Сервисы (приоритет — то ради чего этот экран)
    services = status.get("services") or []
    console.print()
    if not isinstance(services, list) or not services:
        # Пусто — может быть клиент не получил manifest ещё.
        # Подскажем что есть в manifest на стороне репо.
        console.print("[bold]Сервисы:[/] [yellow]ни одного запущенного[/]")
        try:
            mf = api.fetch_manifest(cid)
        except Exception:  # noqa: BLE001
            mf = None
        if (
            isinstance(mf, dict)
            and isinstance(mf.get("services"), list)
            and mf["services"]
        ):
            console.print(
                "  [dim]В manifest.json для этого клиента "
                f"объявлено сервисов: {len(mf['services'])}.[/]"
            )
            console.print(
                "  [dim]Если клиент не запустил их — обнови malinakod до 0.4.2 "
                "и перезапусти scheduled task / комп.[/]"
            )
        else:
            console.print(
                "  [dim]И в manifest.json пусто. "
                "Залей проект через 📦 Деплой проекта.[/]"
            )
    else:
        svc_table = Table(
            title=f"Сервисы ({len(services)})",
            show_header=True,
            border_style="#ff3366",
        )
        svc_table.add_column("Имя", style="bold")
        svc_table.add_column("Статус", style="cyan")
        svc_table.add_column("PID")
        svc_table.add_column("Порт")
        svc_table.add_column("Uptime")
        svc_table.add_column("CPU")
        svc_table.add_column("RAM")
        svc_table.add_column("Видим")
        for s in services:
            if not isinstance(s, dict):
                continue
            running = s.get("running")
            status_str = "[green]running[/]" if running else "[red]stopped[/]"
            svc_table.add_row(
                str(s.get("name", "—")),
                status_str,
                str(s.get("pid", "—")),
                str(s.get("port", "—") or "—"),
                str(s.get("uptime", "—")),
                f"{s.get('cpu', '?')}%",
                str(s.get("ram", "—")),
                "✓" if s.get("visible", True) else "—",
            )
        console.print(svc_table)

    # --- Remote access: Tailscale / RDP / RustDesk ---
    console.print()
    ts_info = status.get("tailscale")
    if ts_info:
        if ts_info.get("available"):
            console.print(
                f"[bold]Tailscale:[/] [green]{ts_info.get('ipv4')}[/] "
                f"({ts_info.get('hostname') or '?'})"
            )
        else:
            console.print(
                f"[bold]Tailscale:[/] [yellow]не настроен[/] "
                f"({ts_info.get('error') or '—'})"
            )

    rdp_info = status.get("rdp")
    if isinstance(rdp_info, dict):
        rdp_on = rdp_info.get("enabled")
        if rdp_on:
            console.print("[bold]RDP:[/] [green]включён[/]")
        else:
            console.print("[bold]RDP:[/] [dim]выключен[/]")

    rd = status.get("rustdesk")
    if isinstance(rd, dict) and rd.get("installed"):
        console.print(
            f"[bold]RustDesk:[/] [green]ID {rd.get('id', '?')}[/] "
            f"(v{rd.get('version', '?')}, service-mode)"
        )
    elif isinstance(rd, dict):
        console.print("[bold]RustDesk:[/] [dim]не установлен[/]")


def screen_settings(
    config: AdminConfig, password: str
) -> tuple[str, GitHubAdmin | None]:
    """Возвращает (возможно новый) пароль и обновлённый api если репо/PAT сменены."""
    new_api: GitHubAdmin | None = None
    while True:
        action = questionary.select(
            "Настройки:",
            choices=[
                "Сменить пароль",
                "Сменить GitHub PAT",
                "Сменить репозиторий",
                "— Назад —",
            ],
            style=QSTYLE,
        ).ask()
        if not action or action == "— Назад —":
            return password, new_api

        if action == "Сменить пароль":
            new_pw = Prompt.ask("[bold]Новый пароль[/]", password=True)
            confirm = Prompt.ask("[bold]Повторите[/]", password=True)
            if new_pw != confirm:
                console.print("[red]Не совпадают[/]")
                continue
            save_vault(new_pw, config)
            console.print("[green]✓ Пароль сменён[/]")
            password = new_pw
            time.sleep(1.5)

        elif action == "Сменить GitHub PAT":
            new_pat = Prompt.ask("[bold]Новый PAT[/]").strip()
            if not new_pat:
                console.print("[yellow]Пустой ввод, отмена[/]")
                continue
            console.print(f"[dim]Длина токена: {len(new_pat)} символов, начинается с: {new_pat[:10]}...[/]")
            api = GitHubAdmin(
                token=new_pat,
                repo_owner=config.repo_owner,
                repo_name=config.repo_name,
                branch=config.branch,
            )
            user = api.whoami()
            if not user:
                console.print(f"[red]PAT не работает: {api.last_auth_error}[/]")
                continue
            console.print(f"[green]✓ Авторизован как {user}[/]")
            config.github_pat = new_pat
            save_vault(password, config)
            new_api = api
            time.sleep(1.5)

        elif action == "Сменить репозиторий":
            owner = Prompt.ask("Owner", default=config.repo_owner)
            name = Prompt.ask("Имя", default=config.repo_name)
            config.repo_owner = owner
            config.repo_name = name
            save_vault(password, config)
            new_api = GitHubAdmin(
                token=config.github_pat,
                repo_owner=config.repo_owner,
                repo_name=config.repo_name,
                branch=config.branch,
            )
            console.print(
                f"[green]✓ Сохранено[/] — текущий репо: "
                f"[cyan]{config.repo_owner}/{config.repo_name}[/]"
            )
            time.sleep(1.5)


def screen_ssh_to_client(api: GitHubAdmin, config: AdminConfig) -> None:
    """SSH к клиенту через Tailscale: читает IP из heartbeat и запускает ssh.

    Требует чтобы (а) клиент был в той же Tailscale-сети и (б) на клиенте был
    запущен OpenSSH-сервер на 22 порту. Подсказки по установке — в README.
    """
    import shlex
    import shutil as _sh
    import subprocess as _sp

    console.print(Panel("SSH к клиенту", border_style="#ff3366"))
    try:
        clients = api.list_clients()
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка: {exc}[/]")
        _press_enter()
        return
    if not clients:
        console.print("[yellow]Нет клиентов[/]")
        _press_enter()
        return
    cid = questionary.select(
        "Клиент:",
        choices=[c.client_id for c in clients] + ["— Назад —"],
        style=QSTYLE,
    ).ask()
    if not cid or cid == "— Назад —":
        return

    status = api.fetch_status(cid)
    if not status:
        console.print(
            f"[yellow]У клиента {cid} нет status.json. "
            "Запустите клиент хотя бы раз, чтобы он отправил heartbeat.[/]"
        )
        _press_enter()
        return

    ts_info = status.get("tailscale", {}) or {}
    ts_ip = ts_info.get("ipv4")
    if not ts_ip or not ts_info.get("available"):
        err = ts_info.get("error") or "Tailscale не настроен на клиенте"
        console.print(
            f"[red]Невозможно подключиться по SSH:[/] {err}\n\n"
            "[yellow]Что сделать клиенту:[/]\n"
            "  1. Установить Tailscale: https://tailscale.com/download\n"
            "  2. Залогиниться (`tailscale up`)\n"
            "  3. Включить OpenSSH-сервер на Windows (см. README)\n"
            "  4. Перезапустить malinakod — heartbeat обновится"
        )
        _press_enter()
        return

    if not _sh.which("ssh"):
        console.print(
            "[red]SSH-клиент не найден на этой машине.[/]\n"
            "  Windows 10+: Settings → Apps → Optional features → OpenSSH Client\n"
            "  macOS/Linux: предустановлен"
        )
        _press_enter()
        return

    # Также нужен Tailscale на студии — иначе IP клиента недоступен
    studio_ts = _sh.which("tailscale")
    if not studio_ts and platform.system() == "Windows":
        studio_ts = (
            r"C:\Program Files\Tailscale\tailscale.exe"
            if Path(r"C:\Program Files\Tailscale\tailscale.exe").exists()
            else None
        )
    if not studio_ts:
        console.print(
            "[red]Tailscale не установлен на этой машине (студия).[/]\n"
            "  Скачайте: https://tailscale.com/download\n"
            "  И залогиньтесь под тем же аккаунтом что клиент."
        )
        _press_enter()
        return

    # Берём OS-юзера из heartbeat (publish'ит клиент через getpass.getuser());
    # fallback на 'Administrator' для Windows, иначе 'user'.
    default_user = status.get("os_user") or (
        "Administrator" if "windows" in (status.get("os", "") or "").lower() else "user"
    )
    user = Prompt.ask("[bold]SSH-юзер на клиенте[/]", default=default_user)

    cmd = ["ssh", f"{user}@{ts_ip}"]
    console.print(
        f"\n[dim]Запускаю:[/] [cyan]{' '.join(shlex.quote(c) for c in cmd)}[/]\n"
    )
    try:
        _sp.run(cmd, check=False)
    except KeyboardInterrupt:
        pass
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка SSH: {exc}[/]")
    _press_enter()


def screen_rdp_to_client(api: GitHubAdmin, config: AdminConfig) -> None:
    """Подключение к клиенту по RDP (через Tailscale IP + mstsc)."""
    import subprocess as _sp

    console.print(Panel("🖥 RDP к клиенту", border_style="#ff3366"))
    try:
        clients = api.list_clients()
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка: {exc}[/]")
        _press_enter()
        return
    if not clients:
        console.print("[yellow]Нет клиентов[/]")
        _press_enter()
        return
    cid = questionary.select(
        "Клиент:",
        choices=[c.client_id for c in clients] + ["— Назад —"],
        style=QSTYLE,
    ).ask()
    if not cid or cid == "— Назад —":
        return

    status = api.fetch_status(cid)
    if not status:
        console.print("[yellow]У клиента нет status.json (heartbeat не приходил).[/]")
        _press_enter()
        return

    # Проверяем RDP-статус из heartbeat
    rdp_info = status.get("rdp")
    if isinstance(rdp_info, dict) and not rdp_info.get("enabled"):
        console.print(
            "[yellow]RDP на клиенте выключен. "
            "Переустановите клиента актуальным install_client.ps1 "
            "для включения RDP.[/]"
        )
        _press_enter()
        return

    # IP: предпочитаем Tailscale, fallback на обычный IP
    ts_info = status.get("tailscale", {}) or {}
    ip = ts_info.get("ipv4") or status.get("ip")
    if not ip:
        console.print("[red]Не удалось определить IP клиента[/]")
        _press_enter()
        return

    default_user = status.get("os_user") or "Administrator"

    console.print(f"[dim]IP клиента: [cyan]{ip}[/][/]")
    console.print(f"[dim]Пользователь по умолчанию: [cyan]{default_user}[/][/]")
    console.print()

    if platform.system() == "Windows":
        # На Windows запускаем mstsc напрямую
        cmd_line = f"mstsc /v:{ip}"
        console.print(f"[dim]Запускаю:[/] [cyan]{cmd_line}[/]")
        try:
            _sp.Popen(["mstsc", f"/v:{ip}"])
            console.print("[green]Окно mstsc открыто[/]")
        except FileNotFoundError:
            console.print(
                "[red]mstsc.exe не найден. Убедитесь что RDP-клиент установлен.[/]"
            )
        except Exception as exc:  # noqa: BLE001
            console.print(f"[red]Ошибка запуска mstsc: {exc}[/]")
    else:
        # На macOS/Linux показываем инструкцию
        console.print(
            "[bold]Для подключения используйте RDP-клиент:[/]\n\n"
            f"  [cyan]IP: {ip}:3389[/]\n"
            f"  [cyan]Пользователь: {default_user}[/]\n\n"
            "[dim]Рекомендуемые клиенты:[/]\n"
            "  macOS: Microsoft Remote Desktop (App Store)\n"
            "  Linux: remmina, freerdp (xfreerdp /v:{ip} /u:{user})"
        )

    _press_enter()


def screen_rustdesk_client(api: GitHubAdmin) -> None:
    """Показать RustDesk ID + пароль клиента (из heartbeat)."""
    console.print(Panel("🪟 RustDesk к клиенту", border_style="#ff3366"))
    try:
        clients = api.list_clients()
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Ошибка: {exc}[/]")
        _press_enter()
        return
    if not clients:
        console.print("[yellow]Нет клиентов[/]")
        _press_enter()
        return
    cid = questionary.select(
        "Клиент:",
        choices=[c.client_id for c in clients] + ["— Назад —"],
        style=QSTYLE,
    ).ask()
    if not cid or cid == "— Назад —":
        return

    status = api.fetch_status(cid)
    if not status:
        console.print("[yellow]У клиента нет status.json (heartbeat не приходил).[/]")
        _press_enter()
        return

    rd = status.get("rustdesk")
    if not isinstance(rd, dict) or not rd.get("installed"):
        console.print(
            "[yellow]RustDesk не установлен на клиенте.[/]\n"
            "[dim]Переустановите клиента актуальным install_client.ps1 "
            "для установки RustDesk в service-mode.[/]"
        )
        _press_enter()
        return

    rd_id = rd.get("id") or "—"
    rd_pass = rd.get("password") or "—"
    rd_ver = rd.get("version") or "?"

    table = Table(
        title=f"RustDesk — {cid}", show_header=False, border_style="#ff3366", padding=(0, 1)
    )
    table.add_column(style="bold")
    table.add_column(style="cyan")
    table.add_row("ID", rd_id)
    table.add_row("Пароль", rd_pass)
    table.add_row("Версия", rd_ver)
    table.add_row("Режим", "[green]service-mode (SYSTEM)[/]")
    console.print(table)

    console.print()
    console.print(
        "[bold]Как подключиться:[/]\n"
        f"  1. Откройте RustDesk на своём компьютере (скачать: [cyan]https://rustdesk.com[/])\n"
        f"  2. Введите ID: [bold cyan]{rd_id}[/]\n"
        f"  3. Нажмите 'Connect', введите пароль: [bold cyan]{rd_pass}[/]\n\n"
        "[dim]Service-mode = работает как SYSTEM: UAC не блокирует, "
        "можно открывать окна с правами администратора.[/]"
    )
    _press_enter()


# --- Главный цикл ---
def main_menu(api: GitHubAdmin, config: AdminConfig, password: str) -> None:
    while True:
        print_banner()
        console.print(
            Panel(
                f"Репо: [cyan]{config.repo_owner}/{config.repo_name}[/]  |  "
                f"Клиентов выдано: [bold]{len(config.issued_keys)}[/]",
                border_style="#ff3366",
            )
        )

        action = questionary.select(
            "Меню:",
            choices=[
                "👥  Клиенты",
                "➕  Создать клиента",
                "📦  Деплой проекта на клиента",
                "📂  Открыть папку клиента в GitHub",
                "📊  Статус клиента (heartbeat)",
                "💻  Послать команду клиенту",
                "📜  Логи сервиса клиента",
                "🔄  Обновить malinakod на клиенте",
                "🔌  SSH к клиенту (через Tailscale)",
                "🖥️   RDP к клиенту (через Tailscale)",
                "🪟  RustDesk к клиенту",
                "⚙️   Настройки",
                "❌  Выход",
            ],
            style=QSTYLE,
        ).ask()

        if action is None or action.startswith("❌"):
            return

        if action.startswith("👥"):
            screen_clients(api, config)
        elif action.startswith("➕"):
            screen_new_client(api, config, password)
        elif action.startswith("📦"):
            screen_deploy_project(api, config)
        elif action.startswith("📂"):
            screen_open_client_folder(api, config)
        elif action.startswith("📊"):
            screen_view_status(api)
        elif action.startswith("💻"):
            screen_send_command(api, config)
        elif action.startswith("📜"):
            screen_view_logs(api)
        elif action.startswith("🔄"):
            screen_update_client(api)
        elif action.startswith("🔌"):
            screen_ssh_to_client(api, config)
        elif action.startswith("🖥"):
            screen_rdp_to_client(api, config)
        elif action.startswith("🪟"):
            screen_rustdesk_client(api)
        elif action.startswith("⚙️"):
            password, maybe_new_api = screen_settings(config, password)
            if maybe_new_api is not None:
                api = maybe_new_api


def run() -> None:
    """Точка входа `malinakod-admin`."""
    try:
        if not vault_exists():
            result = _setup_vault()
            if result is None:
                return
            password, config = result
        else:
            result = _login()
            if result is None:
                return
            password, config = result

        api = GitHubAdmin(
            token=config.github_pat,
            repo_owner=config.repo_owner,
            repo_name=config.repo_name,
            branch=config.branch,
        )
        main_menu(api, config, password)
    except KeyboardInterrupt:
        console.print()
        console.print("[yellow]Прервано пользователем[/]")
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Неожиданная ошибка: {exc}[/]")
        raise


if __name__ == "__main__":
    run()
