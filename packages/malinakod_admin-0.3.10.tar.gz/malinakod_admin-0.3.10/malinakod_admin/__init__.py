"""MalinaKod Admin — TUI студии для управления клиентами."""

__version__ = "0.3.10"
__author__ = "MalinaKod Studio"
