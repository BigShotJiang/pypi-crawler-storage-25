from __future__ import annotations

from syrtis_python_client.entity.abstract_api_entity import AbstractApiEntity


class Session(AbstractApiEntity):
    @classmethod
    def get_entity_name(cls) -> str:
        return "session"
