"""ewan-kb-server — Query server for ewankb knowledge bases."""
__version__ = "0.2.0"
