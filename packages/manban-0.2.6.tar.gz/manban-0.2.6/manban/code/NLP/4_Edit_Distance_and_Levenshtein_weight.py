#1. Edit distance between strings s1 and s2

def edit_distance(s1, s2): 
    n, m = len(s1), len(s2) 
    dp = [[0] * (m + 1) for _ in range(n + 1)] 
    for i in range(n + 1): 
        dp[i][0] = i 
    for j in range(m + 1): 
        dp[0][j] = j 
    for i in range(1, n + 1): 
        for j in range(1, m + 1): 
            cost = 0 if s1[i-1] == s2[j-1] else 1 
            dp[i][j] = min( 
                dp[i-1][j] + 1,        # delete 
                dp[i][j-1] + 1,        # insert 
                dp[i-1][j-1] + cost    # replace 
            ) 
    return dp[n][m] 
 
# Wrapper to print result 
def print_edit_distance(s1, s2): 
    dist = edit_distance(s1, s2) 
    print("s1:",s1) 
    print("s2:",s2) 
    print(f"edit distance: {dist}") 
 
# Example usage: 
print_edit_distance("CHARACTERIZATION", "NATIONALIZATION")


#2. Levenshtein weighted edit distance between strings s1 and s2 
 
def weighted_edit_distance(s1, s2, w_ins=1, w_del=1, w_sub=lambda a, b: 0 if a == b else 1): 
    n, m = len(s1), len(s2) 
    dp = [[0] * (m + 1) for _ in range(n + 1)] 
 
    # Initialize first row/column 
    for i in range(n + 1): 
        dp[i][0] = i * w_del 
    for j in range(m + 1): 
        dp[0][j] = j * w_ins 
 
    # Fill matrix 
    for i in range(1, n + 1): 
        for j in range(1, m + 1): 
            dp[i][j] = min( 
                dp[i-1][j] + w_del,                        # delete 
                dp[i][j-1] + w_ins,                        # insert 
                dp[i-1][j-1] + w_sub(s1[i-1], s2[j-1])     # substitute 
            ) 
    return dp 
def print_weighted_distance(s1, s2, w_ins=1, w_del=1, w_sub=lambda a, b: 0 if a == b else 1): 
    dp = weighted_edit_distance(s1, s2, w_ins, w_del, w_sub) 
 
    print("s1:", s1) 
    print("s2:", s2) 
    print("\nWeighted Levenshtein distance:", dp[len(s1)][len(s2)], "\n") 
 
    # Print DP matrix nicely 
    print("DP Matrix:") 
    print("    ", "  ".join(["_"] + list(s2))) 
 
    for i, row in enumerate(dp): 
        if i == 0: 
            prefix = "_" 
        else: 
            prefix = s1[i-1] 
        print(prefix, row) 
 
# Example usage: 
print_weighted_distance("CHARACTERIZATION", "NATIONALIZATION")




#3. Two sentences are given. Compute the edit distance at the word level:  
#Sentence 1: I love natural language processing 
#Sentence 2: I enjoy learning language processing

def edit_distance_words(s1, s2): 
    words1 = s1.split() 
    words2 = s2.split() 
    n, m = len(words1), len(words2) 
 
    dp = [[0] * (m + 1) for _ in range(n + 1)] 
 
    for i in range(n + 1): 
 
        dp[i][0] = i 
    for j in range(m + 1): 
        dp[0][j] = j 
 
    for i in range(1, n + 1): 
        for j in range(1, m + 1): 
            cost = 0 if words1[i-1] == words2[j-1] else 1 
            dp[i][j] = min( 
                dp[i-1][j] + 1,        # delete a word 
                dp[i][j-1] + 1,        # insert a word 
                dp[i-1][j-1] + cost    # substitute a word 
            ) 
    return dp[n][m] 
 
s1 = "I love natural language processing" 
s2 = "I enjoy learning language processing" 
 
print("s1:",s1) 
print("s2:",s2) 
print("Word-level edit distance:", edit_distance_words(s1, s2)) 
