import re 
 
text = "Hello, my name is John Doe! I am learning Python, and it's fun 2 much." 
 
# 1. Regular Expression for detecting words (ignoring punctuation) 
word_pattern = r'\b\w+\b' 
words = re.findall(word_pattern, text) 
print("Words:", words) 
 
# 2. Regular Expression for detecting specific word patterns (e.g., words starting with 'P') 
pattern_start_with_p = r'\bP\w*\b' 
p_words = re.findall(pattern_start_with_p, text) 
print("Words starting with 'P':", p_words) 
 
# 3. Tokenizing text based on spaces and punctuation 
tokens = re.split(r'(\W+)', text) 
print("Tokens:", [token.strip() for token in tokens if token.strip()]) 
 
# 4. Regular Expression for detecting numbers 
number_pattern = r'\b\d+\b' 
numbers = re.findall(number_pattern, text) 
print("Numbers:", numbers) 
 
# Course text parsing 
text = """101   COM   Computers 205   MAT   Mathematics 189   ENG    English""" 
 
print(re.findall('[0-9]+', text)) 
print(re.findall('[A-Z]{3}', text)) 
print(re.findall('[A-Za-z]{4,}', text)) 
 
course_pattern = r'([0-9]+)\s*([A-Z]{3})\s*([A-Za-z]{4,})' 
print(re.findall(course_pattern, text))

# "Cool" example
cool_text = "Super Cool Coool cooool col"
print(re.findall(r'Co+l', cool_text)) 
 
# Word boundary example
toys_text = "play toy broke toys"
print(re.findall(r'\btoy\b', toys_text)) 
 
# Email extraction 
emails = """zuck26@facebook.com 
page33@google.com 
jeff42@amazon.com""" 
 
pattern = r'(\w+)@([A-Z0-9]+)\.([A-Z]{2,4})' 
print(re.findall(pattern, emails, re.IGNORECASE)) 
 
# Cleaning tweet 
tweet = '''Good advice! RT @TheNextWeb:  
What I would do differently if I was learning to code today  
http://t.co/lbwej0pxOd cc: @garybernhardt #rstats''' 
 
def clean_tweet(tweet): 
    tweet = re.sub(r'http\S+\s*', '', tweet)      # remove URLs 
    tweet = re.sub(r'RT|cc', '', tweet)           # remove RT and cc 
    tweet = re.sub(r'#\S+', '', tweet)            # remove hashtags 
    tweet = re.sub(r'@\S+', '', tweet)            # remove mentions 
    tweet = re.sub(r'[%s]' % re.escape(r"""!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~"""), '', tweet)
    tweet = re.sub(r'\s+', ' ', tweet)            # remove extra whitespace 
    return tweet.strip()
 
print(clean_tweet(tweet))
