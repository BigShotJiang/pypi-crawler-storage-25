#Rule Based Chatbot
import random
# Define a list of possible intents and responses
responses = {
    "greeting": ["Hello!", "Hi there!", "Hey! How can I help you?"],
    "goodbye": ["Goodbye!", "See you later!", "Take care!"],
    "default": ["I'm sorry, I didn't understand that.", "Can you please clarify?"],
}
def get_intent(user_input):
    # A simple intent classification (for demonstration purposes)
    user_input = user_input.lower()
    if "hello" in user_input or "hi" in user_input:
        return "greeting"
    elif "bye" in user_input:
        return "goodbye"
    else:
        return "default"
def chatbot_response(user_input):
    intent = get_intent(user_input)
    return random.choice(responses[intent])
# Simulate a conversation with the chatbot
print("Chatbot: Hello! How can I assist you today?")
while True:
    user_input = input("You: ")
    if "bye" in user_input.lower():
        print("Chatbot:", chatbot_response(user_input))
        break
    print("Chatbot:", chatbot_response(user_input))
