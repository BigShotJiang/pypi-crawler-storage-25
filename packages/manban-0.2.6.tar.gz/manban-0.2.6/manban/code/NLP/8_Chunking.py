#pip install html5lib
import re
import requests
from bs4 import BeautifulSoup
from collections import Counter
from pprint import pprint

import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.tag import pos_tag
from nltk.chunk import ne_chunk, RegexpParser

import spacy
from spacy import displacy
import en_core_web_sm


nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('averaged_perceptron_tagger')
nltk.download('averaged_perceptron_tagger_eng')
nltk.download('maxent_ne_chunker')
nltk.download('maxent_ne_chunker_tab')
nltk.download('words')


# --- 1. Basic NLP & Noun Phrase Chunking ---
ex = 'European authorities fined Google a record $5.1 billion on Wednesday for abusing its power in the mobile phone market and ordered the company to alter its practices'

def preprocess(sent):
    return pos_tag(word_tokenize(sent))

sent = preprocess(ex)
cp = RegexpParser('NP: {<DT>?<JJ>*<NN>}')
cs = cp.parse(sent)
print("Regex Parsed:\n", cs)


# --- 2. NLTK Named Entity Recognition (NER) ---
ne_tree = ne_chunk(sent)
print("\nNER Tree:\n", ne_tree)


# --- 3. SpaCy Named Entity Recognition ---
nlp = en_core_web_sm.load()
doc = nlp(ex)
print("\nSpaCy Entities:")
pprint([(X.text, X.label_) for X in doc.ents])
print("\nSpaCy Tokens:")
pprint([(X.text, X.ent_iob_, X.ent_type_) for X in doc])


# --- 4. Web Scraping & SpaCy Visualization ---
def url_to_string(url):
    res = requests.get(url)
    soup = BeautifulSoup(res.text, 'html5lib')
    for script in soup(["script", "style", 'aside']):
        script.extract()
    return " ".join(re.split(r'[\n\t]+', soup.get_text()))

ny_bb = url_to_string('https://www.nytimes.com/')
article = nlp(ny_bb)

print("\nNYT Total Entities:", len(article.ents))
print("Label Frequencies:", Counter([x.label_ for x in article.ents]))
print("Top 4 Entities:", Counter([x.text for x in article.ents]).most_common(4))

sentences = list(article.sents)


# --- 5. Custom Chunking Example (Ramayana) ---
sample_text_1 = """Rama killed Ravana to save Sita from Lanka.The legend of the Ramayan is the most popular Indian epic.A lot of movies and serials have already been shot in several languages here in India based on the Ramayana."""

chunkParser_vb = RegexpParser(r"""VB: {}""")
for i in sent_tokenize(sample_text_1):
    chunked = chunkParser_vb.parse(pos_tag(word_tokenize(i)))


# --- 6. Custom Chunking Example (Coding Ninja) ---
sample_text_2 = "I am a coding ninja, and I am the best in coding."

chunkParser_ninja = RegexpParser(r"""Chunk: {<RB.?>*<VB.?>*<NNP>+<NN>?}""")
for i in sent_tokenize(sample_text_2):
    tagged_words = pos_tag(word_tokenize(i))
    print(tagged_words)
    chunked = chunkParser_ninja.parse(tagged_words)



# --- 7. Chinking Example (Pre-tagged Sentence) ---
sentence_tags = [
    ("the", "DT"), ("book", "NN"), ("has","VBZ"), ("many","JJ"), ("chapters","NNS")
]

chunker = RegexpParser(r'''
    NP:{<DT><NN.*><.*>*<NN.*>}
    }<VB.*>{
''')
Output = chunker.parse(sentence_tags)



# --- 8. Complex Grammar Chunking Example ---
sentence_fox = "The quick brown fox jumps over the lazy dog."
tagged_fox = pos_tag(word_tokenize(sentence_fox))

grammar = """
  NP: {<DT>?<JJ>*<NN>}  # Noun phrase
  VP: {<VB.*>}          # Verb phrase
  PP: {<IN><NP>}        # Prepositional phrase
"""

chunk_parser_fox = RegexpParser(grammar)
chunked_fox = chunk_parser_fox.parse(tagged_fox)

print("\nChunked Output (Fox):")
print(chunked_fox)
chunked_fox.pretty_print()


#Visulizatins
print("\n\nopen in browser: http://127.0.0.1:5000")
#4
if len(sentences) > 40:
    print("\nSentence 40:", sentences[40])
    displacy.serve(nlp(str(sentences[40])), style='dep')
    displacy.serve(nlp(str(sentences[20])), style='dep', options={'distance': 80})
#5
displacy.serve(nlp(sample_text_1), style='dep', options={'distance': 80})
#6
displacy.serve(nlp(sample_text_2), style='dep', options={'distance': 100})
#7
displacy.serve(nlp(str(Output)), style='dep', options={'distance': 100})


