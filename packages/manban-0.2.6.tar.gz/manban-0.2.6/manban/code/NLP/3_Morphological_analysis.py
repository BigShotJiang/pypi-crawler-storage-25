import nltk 
from nltk.stem import PorterStemmer, WordNetLemmatizer 
from nltk.corpus import wordnet 
from nltk.tag import RegexpTagger 
from nltk.tokenize import word_tokenize 
import re 
import spacy

# 1. STEMMING (PorterStemmer) 
 
stemmer = PorterStemmer() 
 
words = ["running", "runner", "runs", "easily", "happier", "better"] 
stemmed_words = [stemmer.stem(word) for word in words] 
 
print("Stemming:", stemmed_words) 

 
# 2. LEMMATIZATION (WordNet) 

nltk.download('wordnet') 
nltk.download('omw-1.4') 
 
lemmatizer = WordNetLemmatizer() 
 
lemmatized_words = [lemmatizer.lemmatize(word, pos=wordnet.VERB) for word in words] 
 
print("Lemmatization:", lemmatized_words) 
 
  
# 3. REGEX TAGGING 
 
nltk.download('punkt') 
nltk.download('punkt_tab') 
 
sentence = "The cats were running quickly." 
tokens = word_tokenize(sentence) 
 
patterns = [ 
    (r'.*ing$', 'VB'), 
    (r'.*ly$', 'RB'), 
    (r'.*es$', 'NNS'), 
] 
 
tagger = RegexpTagger(patterns) 
tagged = tagger.tag(tokens) 
 
print("Regex Tagged Tokens:", tagged) 

 
# 4. WORDNET – SYNSETS 
 
synsets = wordnet.synsets("running") 
if synsets: 
    print("First synset lemmas:", synsets[0].lemmas()) 
else: 
    print("No synsets found.") 
 


# 5. SUFFIX EXTRACTION 
 
def extract_suffixes(word): 
    suffixes = ['ing', 'ed', 'ly', 's'] 
    for suffix in suffixes: 
        if word.endswith(suffix): 
            return suffix 
    return None 
 
words_suffix = ["running", "played", "unhappy", "cats", "jump"] 
suffixes = [extract_suffixes(word) for word in words_suffix] 
 
print("Suffixes:", suffixes) 

 

# 6. PREFIX EXTRACTION 
 
def extract_prefixes(word): 
    prefixes = ['un', 're', 'pre', 'dis'] 
    for prefix in prefixes: 
        if word.startswith(prefix): 
            return prefix 
    return None 
 
words_prefix = ["running", "redo", "unhappy", "dislike", "prepaid", "happy"] 
prefixes = [extract_prefixes(word) for word in words_prefix] 
 
print("Prefixes:", prefixes) 
 


# 7. COMPOUND WORD SPLITTING 

compound_words = ['sunflower', 'basketball', 'football', 'notebook', 'toothbrush'] 
common_words = ['sun', 'flower', 'basket', 'ball', 'foot', 'book', 'tooth', 'brush'] 
 
def split_compound_word(word, components): 
    for component in components: 
        if word.startswith(component): 
            remaining = word[len(component):] 
            if remaining in components: 
                return component, remaining 
    return (word,) 
 
split_results = {word: split_compound_word(word, common_words) for word in compound_words} 
 
print("Compound Word Splits:", split_results) 
 


# 8. SPACY – COMPOUND DEPENDENCY DETECTION 

nlp = spacy.load("en_core_web_sm") 
 
text = "The football players were practicing on the basketball court." 
doc = nlp(text) 
 
print("\nSpaCy Compound Words:") 
9 
 
for token in doc: 
    if token.dep_ == "compound": 
        print(f"{token.text} -> Head: {token.head.text}") 
 
 
 
# 9. SPACY-BASED MORPHOLOGICAL ANALYSIS (Replacing Polyglot) 
 
words_morph = ["preprocessing", "processor", "invaluable", "thankful", "crossed"] 
 
print("\nSpaCy Morphological Features:") 
for w in words_morph: 
    token = nlp(w)[0] 
    print(f"{w:<15} -> {token.morph}") 
 
# Simple rule-based morpheme splitter (prefix/suffix) 
prefixes = ["pre", "un", "in", "re"] 
suffixes = ["ing", "ed", "ful", "less", "able", "ed", "ed", "ed"] 
 
def split_morphemes(word): 
    for p in prefixes: 
        if word.startswith(p): 
            return (p, word[len(p):]) 
    for s in suffixes: 
        if word.endswith(s): 
            return (word[:-len(s)], s) 
    return (word,) 
 
print("\nRule-Based Morpheme Splitting:") 
for w in words_morph: 
    print(f"{w:<15} -> {split_morphemes(w)}") 
 
# 10. SPACY POS TAGGING (Replacing Polyglot POS Tags) 
 
sentence = "We will meet at eight o'clock on Thursday morning." 
doc = nlp(sentence) 
 
print("\nSpaCy POS Tags:") 
for token in doc: 
    print(f"{token.text:<15} {token.pos_:<10} {token.tag_}") 
