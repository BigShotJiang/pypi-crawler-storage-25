#Chatbot with Simple Dialog System
import random 
import re 
 
# Define some basic responses 
greetings = ['hi', 'hello', 'hey', 'hola'] 
responses = { 
    'how are you': 'I am doing well, thank you!', 
    'what is your name': 'I am a simple chatbot!', 
    'bye': 'Goodbye! Have a great day!', 
    'default': "I'm not sure how to respond to that. Can you ask something else?" 
} 
 
def greet(user_input): 
    if any(greeting in user_input.lower() for greeting in greetings): 
        return random.choice(['Hello!', 'Hi there!', 'Hey!']) 
    return None 
 
# Function to handle the chatbot's responses 
def get_response(user_input): 
    user_input = user_input.lower() 
 
    greeting_response = greet(user_input) 
    if greeting_response: 
        return greeting_response 
 
    for key, value in responses.items(): 
        if key in user_input: 
            return value 
 
    return responses['default'] 
37 
 
 
# Main function for the chatbot dialog 
def chatbot(): 
    print("Chatbot: Hi! How can I help you today? Type 'bye' to exit.") 
 
    while True: 
        user_input = input("You: ") 
 
        if user_input.lower() == 'bye': 
            print("Chatbot: Goodbye! Have a great day!") 
            break 
 
        response = get_response(user_input) 
 
        print("Chatbot:", response) 
 
if __name__ == "__main__": 
    chatbot()
