import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.probability import FreqDist
from nltk.corpus import stopwords
import matplotlib.pyplot as plt

nltk.download("punkt")
nltk.download("punkt_tab")
nltk.download("stopwords")

text = """On a windy Tuesday afternoon, a turquoise robot carrying three slightly 
bruised mangoes wandered past an old library. It hummed an off-key tune as if 
trying to remember the chorus of a forgotten song while tiny holographic notes 
flickered around its metal head."""

tokenized_sent = sent_tokenize(text)
print(tokenized_sent)

tokenized_word = word_tokenize(text)
print(tokenized_word)

freq_dist = FreqDist(tokenized_word)
print(freq_dist)
freq_dist.most_common(5)

# Improved Visualization
plt.figure(figsize=(12, 6))
freq_dist.plot(30, cumulative=False)

plt.title("Top 30 Word Frequency Distribution", fontsize=14)
plt.xlabel("Words", fontsize=12)
plt.ylabel("Frequency", fontsize=12)
plt.xticks(rotation=45)
plt.grid(axis='y', linestyle='--', alpha=0.7)

plt.tight_layout()
plt.show()

stop_words = set(stopwords.words("english"))
print(stop_words)

filtered_words = []
for word in tokenized_word:
    if word not in stop_words:
        filtered_words.append(word)

print("Tokenized Words:", tokenized_word)
print("Filtered Words:", filtered_words)
