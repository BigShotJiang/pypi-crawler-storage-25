from __future__ import annotations

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from inspire import config as config_module
from inspire.cli.main import main as cli_main
from inspire.platform.web.browser_api import FullFreeNodeCount, GPUAvailability


_WS_DEFAULT = "ws-00000000-0000-0000-0000-0000000000aa"


class _Session:
    workspace_id = _WS_DEFAULT
    all_workspace_ids = [_WS_DEFAULT]
    all_workspace_names = {_WS_DEFAULT: "Default WS"}


def _patch_config(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    cfg = config_module.Config(
        username="user",
        password="pass",
        base_url="https://qz.sii.edu.cn",
        log_cache_dir=str(tmp_path / "logs"),
    )
    monkeypatch.setattr(
        config_module.Config,
        "from_files_and_env",
        classmethod(lambda cls, **kwargs: (cfg, {})),
    )


def test_resources_nodes_filters_and_returns_json_recommendation(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    _patch_config(monkeypatch, tmp_path)

    from inspire.cli.commands.resources import resources_nodes as nodes_module

    monkeypatch.setattr(nodes_module, "get_web_session", lambda: _Session())
    monkeypatch.setattr(
        nodes_module.browser_api_module,
        "get_accurate_resource_availability",
        lambda **_: [
            GPUAvailability(
                group_id="cg-11111111-1111-1111-1111-111111111111",
                group_name="H200-2号机房",
                gpu_type="NVIDIA_H200",
                total_gpus=64,
                used_gpus=16,
                available_gpus=48,
                low_priority_gpus=0,
                workspace_id=_WS_DEFAULT,
                workspace_name="Default WS",
            ),
            GPUAvailability(
                group_id="cg-22222222-2222-2222-2222-222222222222",
                group_name="H200-1号机房",
                gpu_type="NVIDIA_H200",
                total_gpus=64,
                used_gpus=56,
                available_gpus=8,
                low_priority_gpus=0,
                workspace_id=_WS_DEFAULT,
                workspace_name="Default WS",
            ),
        ],
    )
    monkeypatch.setattr(
        nodes_module.browser_api_module,
        "get_full_free_node_counts",
        lambda group_ids, gpu_per_node: [
            FullFreeNodeCount(
                group_id="cg-11111111-1111-1111-1111-111111111111",
                group_name="H200-2号机房",
                gpu_per_node=gpu_per_node,
                total_nodes=8,
                ready_nodes=8,
                full_free_nodes=6,
            ),
            FullFreeNodeCount(
                group_id="cg-22222222-2222-2222-2222-222222222222",
                group_name="H200-1号机房",
                gpu_per_node=gpu_per_node,
                total_nodes=8,
                ready_nodes=8,
                full_free_nodes=1,
            ),
        ],
    )

    result = CliRunner().invoke(
        cli_main,
        [
            "--json",
            "resources",
            "nodes",
            "--workspace",
            "Default WS",
            "--min-full-free-nodes",
            "2",
        ],
    )

    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    data = payload["data"]
    assert [row["group_name"] for row in data["groups"]] == ["H200-2号机房"]
    assert data["recommendation"]["group_name"] == "H200-2号机房"
    assert data["recommendation"]["full_free_nodes"] == 6
    assert data["min_full_free_nodes"] == 2


def test_resources_nodes_human_scrubs_raw_ids(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    _patch_config(monkeypatch, tmp_path)

    from inspire.cli.commands.resources import resources_nodes as nodes_module

    raw_group_id = "cg-11111111-1111-1111-1111-111111111111"
    monkeypatch.setattr(nodes_module, "get_web_session", lambda: _Session())
    monkeypatch.setattr(
        nodes_module.browser_api_module,
        "get_accurate_resource_availability",
        lambda **_: [
            GPUAvailability(
                group_id=raw_group_id,
                group_name=f"H200 {raw_group_id}",
                gpu_type="NVIDIA_H200",
                total_gpus=64,
                used_gpus=16,
                available_gpus=48,
                low_priority_gpus=0,
                workspace_id=_WS_DEFAULT,
                workspace_name="Default WS",
            )
        ],
    )
    monkeypatch.setattr(
        nodes_module.browser_api_module,
        "get_full_free_node_counts",
        lambda group_ids, gpu_per_node: [
            FullFreeNodeCount(
                group_id=raw_group_id,
                group_name=f"H200 {raw_group_id}",
                gpu_per_node=gpu_per_node,
                total_nodes=8,
                ready_nodes=8,
                full_free_nodes=6,
            )
        ],
    )

    result = CliRunner().invoke(
        cli_main,
        ["resources", "nodes", "--workspace", "Default WS", "--min-full-free-nodes", "2"],
    )

    assert result.exit_code == 0, result.output
    assert raw_group_id not in result.output
    assert "<raw-id>" in result.output
    assert "Recommended:" in result.output
