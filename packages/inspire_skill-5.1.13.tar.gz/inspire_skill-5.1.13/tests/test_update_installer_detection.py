"""Regression test for `inspire update` installer detection.

Background: a v3.0.1 user reported that `inspire update` refused to
auto-upgrade with "this build isn't managed by uv tool / pipx", even
though their install was a textbook `uv tool install` at
``~/.local/share/uv/tools/inspire-skill/``.

Root cause: the detector previously did
``Path(sys.executable).resolve()``. The ``.resolve()`` follows the
venv's ``bin/python`` symlink through to the underlying interpreter
binary — for uv tool installs that lives at
``~/.local/share/uv/python/cpython-3.x.x-.../bin/python3``, which has
"uv" in its parts but **not** "tools". Detection fell to None, the
auto-upgrade refused, the user had to reinstall manually.

Fix: probe ``sys.prefix`` (the venv root) directly. Don't resolve.

These tests pin the detector against the literal layouts that uv tool
and pipx use, so any future regression that re-introduces resolve() or
otherwise scrubs the venv segment will fail here.
"""

from __future__ import annotations

import importlib
import subprocess
import sys
from pathlib import Path

import pytest

from inspire.cli.commands.update import (
    _detect_installer,
    _is_local_requirement,
    _parse_uv_tool_list,
    _scan_stale_skill_patterns,
    _upgrade_cli,
)

update_module = importlib.import_module("inspire.cli.commands.update")


@pytest.mark.parametrize(
    "prefix, expected",
    [
        # uv tool install — the layout that triggered the bug report.
        ("/Users/vagrant/.local/share/uv/tools/inspire-skill", "uv"),
        # uv tool install on Linux user dir.
        ("/home/alice/.local/share/uv/tools/inspire-skill", "uv"),
        # pipx — symmetric layout.
        ("/Users/vagrant/.local/share/pipx/venvs/inspire-skill", "pipx"),
        ("/home/alice/.local/share/pipx/venvs/inspire-skill", "pipx"),
        # Unmanaged local venv. Must return None so update.py reports the
        # official installer as the recovery path, not the `uv tool` branch.
        ("/Users/zillionx/InspireSkill/cli/.venv", None),
        # System Python — also None.
        ("/usr/local", None),
        ("/opt/homebrew", None),
        # Edge: a path that contains "uv" or "tools" alone is NOT enough
        # — both segments must be present for "uv" to match. Same for
        # pipx (needs both "pipx" and "venvs").
        ("/Users/x/uv/random/dir", None),
        ("/Users/x/tools/something", None),
        ("/Users/x/pipx/random/dir", None),
        ("/Users/x/venvs/something", None),
    ],
)
def test_detect_installer_from_prefix(
    prefix: str,
    expected: str | None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(sys, "prefix", prefix)
    assert _detect_installer() == expected


def test_upgrade_cli_retries_pypi_network_errors_with_mirrors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[tuple[list[str], str | None]] = []

    def fake_run(cmd, check, env, text, stdout, stderr):
        calls.append((cmd, None if env is None else env.get("UV_DEFAULT_INDEX")))
        if len(calls) == 1:
            return subprocess.CompletedProcess(
                cmd,
                1,
                stdout="Resolving dependencies...\n",
                stderr=(
                    "error: Failed to fetch: `https://pypi.org/simple/inspire-skill/`\n"
                    "  Caused by: operation timed out\n"
                ),
            )
        return subprocess.CompletedProcess(cmd, 0, stdout="upgraded\n", stderr="")

    monkeypatch.setattr(sys, "prefix", "/Users/vagrant/.local/share/uv/tools/inspire-skill")
    monkeypatch.setattr(update_module.subprocess, "run", fake_run)

    assert _upgrade_cli(silent=True) is True
    assert calls == [
        (["uv", "tool", "install", "--force", "--refresh", "inspire-skill"], None),
        (
            ["uv", "tool", "install", "--force", "--refresh", "inspire-skill"],
            "https://pypi.tuna.tsinghua.edu.cn/simple",
        ),
    ]


def test_upgrade_cli_does_not_retry_non_network_errors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []

    def fake_run(cmd, check, env, text, stdout, stderr):
        calls.append(cmd)
        return subprocess.CompletedProcess(
            cmd,
            2,
            stdout="",
            stderr="error: unrecognized option '--bad-flag'\n",
        )

    monkeypatch.setattr(sys, "prefix", "/Users/vagrant/.local/share/pipx/venvs/inspire-skill")
    monkeypatch.setattr(update_module.subprocess, "run", fake_run)

    assert _upgrade_cli(silent=True) is False
    assert calls == [["pipx", "upgrade", "inspire-skill"]]


def test_upgrade_cli_from_repo_venv_updates_global_uv_tool(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []

    def fake_run(cmd, check, env, text, stdout, stderr):
        calls.append(cmd)
        return subprocess.CompletedProcess(cmd, 0, stdout="installed\n", stderr="")

    monkeypatch.setattr(sys, "prefix", "/Users/zillionx/InspireSkill/cli/.venv")
    monkeypatch.setattr(
        update_module,
        "_uv_tool_info",
        lambda: update_module.UvToolInfo(
            version="4.1.0",
            required="file:///Users/zillionx/InspireSkill/cli",
            env_path="/Users/zillionx/.local/share/uv/tools/inspire-skill",
            executable_path="/Users/zillionx/.local/bin/inspire",
        ),
    )
    monkeypatch.setattr(update_module.subprocess, "run", fake_run)

    assert _upgrade_cli(silent=True) is True
    assert calls == [["uv", "tool", "install", "--force", "--refresh", "inspire-skill"]]


def test_parse_uv_tool_list_captures_local_source_and_executable() -> None:
    info = _parse_uv_tool_list(
        "inspire-skill v4.1.1 [required: file:///Users/zillionx/InspireSkill/cli] "
        "(/Users/zillionx/.local/share/uv/tools/inspire-skill)\n"
        "- inspire (/Users/zillionx/.local/bin/inspire)\n"
    )

    assert info is not None
    assert info.version == "4.1.1"
    assert info.required == "file:///Users/zillionx/InspireSkill/cli"
    assert info.env_path == "/Users/zillionx/.local/share/uv/tools/inspire-skill"
    assert info.executable_path == "/Users/zillionx/.local/bin/inspire"
    assert _is_local_requirement(info.required)


def test_stale_skill_patterns_detect_legacy_target_dir(tmp_path: Path) -> None:
    (tmp_path / "SKILL.md").write_text(
        "Run INSPIRE_TARGET_DIR=/root/labwork inspire notebook exec ...\n",
        encoding="utf-8",
    )

    errors = _scan_stale_skill_patterns(tmp_path)

    assert errors
    assert "INSPIRE_TARGET_DIR" in errors[0]


def test_global_audit_prefers_uv_tool_executable_over_repo_venv_path(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []

    monkeypatch.setattr(
        update_module,
        "_uv_tool_info",
        lambda: update_module.UvToolInfo(
            version="4.1.1",
            required=None,
            env_path="/Users/zillionx/.local/share/uv/tools/inspire-skill",
            executable_path="/Users/zillionx/.local/bin/inspire",
        ),
    )
    monkeypatch.setattr(update_module.shutil, "which", lambda _name: "/repo/.venv/bin/inspire")

    def fake_run(cmd, check, env, text, stdout, stderr):
        calls.append(cmd)
        return subprocess.CompletedProcess(cmd, 0, stdout="inspire, version 4.1.1\n", stderr="")

    monkeypatch.setattr(update_module.subprocess, "run", fake_run)

    ok, actual = update_module._audit_global_cli(expected_version="4.1.1", silent=True)

    assert ok is True
    assert actual == "4.1.1"
    assert calls == [["/Users/zillionx/.local/bin/inspire", "--version"]]
