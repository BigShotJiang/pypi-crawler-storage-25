from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
import trafilatura
from piki_rag.common.exception import WebScrappingException
from playwright.sync_api import sync_playwright
from playwright_stealth import Stealth
from .common import Extractor


class DefaultWebExtractor(Extractor):

    def __init__(self, timeout: int = 30000):
        self.timeout = timeout
        self._executor = ThreadPoolExecutor()

    def is_extractable(self, path: str) -> bool:
        return path and urlparse(path).scheme in ["http", "https"]

    def _extract_in_thread(self, path: str) -> str:
        with sync_playwright() as p:
            browser = p.chromium.launch(
                headless=True,
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--no-sandbox",
                    "--disable-setuid-sandbox",
                    "--disable-dev-shm-usage",
                ],
            )
            context = browser.new_context(
                viewport={"width": 1920, "height": 1080},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            )
            page = None
            try:
                page = context.new_page()
                Stealth().apply_stealth_sync(page)
                page.goto(path, timeout=self.timeout, wait_until="domcontentloaded")
                try:
                    page.wait_for_load_state(
                        "networkidle", timeout=min(self.timeout, 10000)
                    )
                except Exception:
                    page.wait_for_timeout(2000)
                page.wait_for_timeout(1000)
                html = page.content()
                text = trafilatura.extract(
                    html,
                    include_comments=False,
                    include_tables=True,
                )
                if not text:
                    raise WebScrappingException(f"Текст для ресурса {path} не найден")
                return text
            except WebScrappingException:
                raise
            except Exception as e:
                raise WebScrappingException(
                    f"Ошибка при извлечении {path}: {str(e)}"
                ) from e
            finally:
                if page:
                    page.close()
                context.close()
                browser.close()

    def extract(self, path: str) -> str:
        future = self._executor.submit(self._extract_in_thread, path)
        return future.result()

    def __del__(self):
        self._executor.shutdown(wait=False)
