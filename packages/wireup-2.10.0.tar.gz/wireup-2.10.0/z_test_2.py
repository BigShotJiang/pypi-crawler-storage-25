import collections.abc
import typing

_collection_normalization_map = {list: typing.Sequence, collections.abc.Sequence: typing.Sequence}
T = typing.TypeVar("T")


def ensure_sequence_type_is_normalized(typ: typing.Type[T]) -> typing.Type[T]:
    origin = typing.get_origin(typ)
    arg = typing.get_args(typ)

    if origin in _collection_normalization_map:
        return _collection_normalization_map[origin][arg[0]]

    return typ


print(typing.get_origin(typing.Sequence[int]))
print(hash(typing.Sequence[int]), hash(collections.abc.Sequence[int]))
