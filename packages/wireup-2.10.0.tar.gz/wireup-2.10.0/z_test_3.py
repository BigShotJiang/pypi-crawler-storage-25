import collections.abc
import typing


def normalize(typ: typing.Type[typing.Any]) -> typing.Any:
    origin = typing.get_origin(typ)
    args = typing.get_args(typ)

    if origin in (list, tuple, collections.abc.Sequence, typing.Sequence):
        return ("sequence", args[0])

    if origin in (dict, collections.abc.Mapping, typing.Mapping):
        return ("mapping", args[0], args[1])

    return typ


print(normalize(collections.abc.Sequence[int]) == normalize(list[int]))
print(normalize(typing.Sequence[int]) == normalize(list[int]))


def tuple_test(f: typing.Tuple[int]):
    for item in f:
        typing.reveal_type(item)
