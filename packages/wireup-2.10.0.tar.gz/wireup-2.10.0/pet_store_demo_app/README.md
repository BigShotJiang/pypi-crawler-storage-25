Run the demo app with:

```bash
uvicorn pet_store_demo_app.main:app --reload
```

Run the Flask variant with:

```bash
uv run flask --app pet_store_demo_app.flask_main run --debug
```

Endpoints:

- `/pets` returns an injected catalog payload
- `/pets/{pet_id}/adopt` returns an injected adoption preview
- `/owners/{owner_id}` returns an injected owner payload
- `/db-session` returns a scoped SQLAlchemy-style session payload
- `/whoami` returns a scoped auth payload built from the FastAPI request
- `/_wireup` returns the full-page Cytoscape renderer
