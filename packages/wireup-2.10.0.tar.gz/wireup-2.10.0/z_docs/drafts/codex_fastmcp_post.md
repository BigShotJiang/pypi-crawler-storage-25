## Wireup + FastMCP: one validated service graph for MCP tools, FastAPI routes, and workers

I maintain [Wireup](https://github.com/maldoinc/wireup), a type-driven DI library for Python.

I recently added a dedicated FastMCP integration, and the part I think is most useful is not just "DI in tool
handlers", but being able to use the same service graph across:

- FastMCP tools
- FastAPI / Starlette routes
- workers
- CLI commands
- scripts

That means your MCP server does not need its own parallel wiring story.

With Wireup, FastMCP tools can resolve dependencies directly from the container, while the container validates the graph
at startup. Missing dependencies, cycles, lifetime mismatches, and config errors fail early instead of showing up when a
tool is first called.

Standalone FastMCP example:

```python
from fastmcp import FastMCP
import wireup
import wireup.integration.fastmcp
from wireup import Injected
from wireup.integration.fastmcp import inject


mcp = FastMCP("MCP Server")


@mcp.tool
@inject
async def greet(greeter: Injected[GreeterService]) -> str:
    return greeter.greet("World")


container = wireup.create_async_container(injectables=[services])
wireup.integration.fastmcp.setup(container, mcp)
```

What Wireup brings here:

- direct injection into `@mcp.tool` handlers
- startup graph validation
- explicit lifetimes and lifecycle-managed resources
- reuse of the same service layer outside the MCP server

The other useful part is composition.

If you are already running FastAPI or Starlette, FastMCP does not need to become a separate island. Wireup supports
FastMCP mounted under FastAPI/Starlette, so one application can serve both MCP tools and regular HTTP routes while
sharing the same dependency graph.

That has been the nicest part of the integration for me: the MCP side is not treated as a special case with its own DI
mechanics.

Docs:
https://maldoinc.github.io/wireup/latest/integrations/fastmcp/

Repo:
https://github.com/maldoinc/wireup

Happy to answer questions, especially from anyone trying to avoid duplicating service wiring between an MCP server and
the rest of their app.
