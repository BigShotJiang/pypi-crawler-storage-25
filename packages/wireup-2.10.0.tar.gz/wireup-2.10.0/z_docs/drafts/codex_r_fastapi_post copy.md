## Wireup for FastAPI now supports DI in background tasks

Hi /r/fastapi,

I built [Wireup](https://github.com/maldoinc/wireup), a DI library for Python, and I recently improved the FastAPI
integration. The new feature I think FastAPI users will care about most is `WireupTask`.

It lets you inject dependencies into FastAPI background task callbacks.
Each task gets its own scope, separate from the request and other tasks, so it gets fresh scoped services like DB
sessions, transactions, or request-local state while still sharing app-wide singletons where appropriate.

I wanted this for FastAPI apps that use background tasks for work that still needs DI and cleanup, while keeping the
same services usable outside HTTP too, like in CLIs and workers.


**Here's what it looks like: Full Example**

```python
from fastapi import BackgroundTasks, FastAPI
import wireup
import wireup.integration.fastapi
from wireup import Injected, injectable
from wireup.integration.fastapi import WireupTask


@injectable
class GreeterService:
    def greet(self, name: str) -> str:
        return f"Hello, {name}!"


def write_greeting(name: str, greeter: Injected[GreeterService]) -> None:
    print(greeter.greet(name))


@app.post("/enqueue")
async def enqueue(
    name: str,
    tasks: BackgroundTasks,
    wireup_task: Injected[WireupTask],
):
    tasks.add_task(wireup_task(write_greeting), name)
    return {"ok": True}


container = wireup.create_async_container(injectables=[GreeterService])
app = FastAPI()
wireup.integration.fastapi.setup(container, app)
```

Wireup also covers request-time injection, class-based handlers, testing, request/websocket context in services, and
moving over from `Depends` one piece at a time.

FastAPI's DI works well for request-time dependencies, but app-wide services often end up managed through `app.state`
and `@lru_cache`. Wireup lets you define those lifetimes in one place: app-wide (`singleton`), per-request (`scoped`),
and always-fresh (`transient`).

It also validates the dependency graph at startup, so missing dependencies, cycles, lifetime mismatches, and config
errors fail early instead of raising on first resolution.

If you're already using `Depends`, there is also a migration guide showing how to keep FastAPI for request parsing,
responses, and auth, and move just your services over incrementally.

I also benchmarked it against FastAPI `Depends` in a FastAPI + Uvicorn request benchmark. On the current median run,
Wireup is about **2.79x** faster in the per-request injection workload and about **2.15x** faster in the
singleton-resolution workload. I don't think DI benchmarks should be the main reason to pick a library, but I know
people will ask, so I included the full methodology and benchmark code below.

Background tasks:
https://maldoinc.github.io/wireup/latest/integrations/fastapi/background_tasks/

FastAPI integration docs:
https://maldoinc.github.io/wireup/latest/integrations/fastapi/

Migration guide from `Depends`:
https://maldoinc.github.io/wireup/latest/migrate_to_wireup/fastapi_depends/

Benchmarks:
https://maldoinc.github.io/wireup/latest/benchmarks/

Repo:
https://github.com/maldoinc/wireup

Curious how you're handling background tasks and DI in your FastAPI apps, and whether isolated task scopes would be useful in your setup.
