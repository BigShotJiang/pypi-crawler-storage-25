Implement Tic Tac Toe
LRU cache
Rate limiter
Moving average window
Order book simulation

---


These are the **most common HRT-style problems** reported across interviews and prep groups for the **30-minute coding screen**. They are not necessarily the exact questions, but **the patterns repeat heavily**. If you can implement these quickly and cleanly, you're very well prepared for that round.

I grouped them by **pattern**, because HRT tends to test **implementation fluency**, not obscure algorithms.

---

# 1. Sliding Window / Streaming Stats

Very common in trading systems.

### Example

```
Design a moving average.

class MovingAverage:
    def __init__(self, window_size):
    def next(val) -> float
```

Return the average of the last **k values**.

Expected solution:

* queue / deque
* running sum

Complexity:

```
O(1) per operation
```

Variants:

* moving median (heap)
* moving max/min
* time-window instead of fixed window

---

# 2. LRU Cache

This appears constantly in finance interviews.

### Problem

```
Implement an LRU cache with O(1) operations.

get(key)
put(key, value)
```

Expected structure:

```
hashmap
+
doubly linked list
```

Key signals they look for:

* eviction logic
* pointer manipulation
* clean structure

---

# 3. Order Book / Trade Matching (simplified)

Very HRT-style.

### Problem

Implement a simple order book.

Example input:

```
BUY 100 @ 10
SELL 50 @ 9
SELL 40 @ 10
```

Expected behavior:

* match buy/sell orders
* track remaining quantities

Typical structures:

```
max heap for bids
min heap for asks
```

They want to see:

```
clean modeling of state
```

---

# 4. Tic-Tac-Toe Engine

Reported several times in HRT interviews.

### Problem

Implement a TicTacToe game.

```
move(row, col, player) -> winner
```

Goal:

* detect winner efficiently

Naive solution:

```
O(n²)
```

Better solution:

```
row counts
column counts
diagonal counts
```

Time:

```
O(1) per move
```

This tests **state modeling**.

---

# 5. Log Aggregator

Very common in infra-heavy firms.

### Example

Given logs:

```
timestamp user_id action
```

Compute something like:

```
top k users
rate of events
rolling counts
```

Typical structures:

```
hashmap
heap
deque
```

---

# 6. Rate Limiter

Classic systems-style implementation.

Example API:

```
allow_request(user_id, timestamp)
```

Limit:

```
100 requests per minute
```

Possible solutions:

```
sliding window
token bucket
leaky bucket
```

They usually accept:

```
deque of timestamps
```

---

# 7. Union Find

Mentioned multiple times in reports.

Example problem:

```
Detect cycles in a graph
or
number of connected components
```

Expected structure:

```
union by rank
path compression
```

But usually **simple usage**, not deep graph theory.

---

# 8. Two Pointer / Hash Map Problems

Typical examples:

### Two Sum

```
find two numbers that sum to target
```

### Longest substring without repeating characters

```
sliding window + set
```

### Top K Frequent

```
hashmap + heap
```

These are **LeetCode medium tier**.

---

# What HRT Interviewers Actually Watch

They are watching **coding style more than trick algorithms**.

Strong signals:

```
clear variable names
clean structure
correct edge cases
```

Weak signals:

```
overly clever code
messy logic
```

---

# A Very Common Interview Flow

Typical HRT 30-minute coding round looks like this:

```
0–2 min   explain problem
2–5 min   candidate proposes approach
5–22 min  coding
22–27 min testing + edge cases
27–30 min improvements
```

---

# Edge Cases They Often Ask

Expect questions like:

```
What if input is empty?
What about duplicates?
What if memory is limited?
```

Sometimes:

```
How would this scale?
```

---

# One Important Pattern

HRT strongly prefers **implementation-heavy questions** over puzzle questions.

So you’re more likely to see something like:

```
implement a data structure
simulate a system
```

than something like:

```
hard dynamic programming puzzle
```

---

# What Makes Candidates Pass This Round

Successful candidates usually:

1. **Choose a correct approach quickly**
2. **Write clean code fast**
3. **Narrate while coding**
4. **Test their solution**

Most failures happen because people:

```
overthink
or
run out of time
```

---

# Final Tip (Important)

Because the round is **30 minutes**, interviewers often choose problems with **~40–50 lines of code**.

That’s the sweet spot.

Problems requiring **200 lines** or heavy design usually appear in the **superday programming task**, not the first screen.
