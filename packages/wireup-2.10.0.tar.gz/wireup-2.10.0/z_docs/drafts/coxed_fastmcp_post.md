## Wireup + FastMCP: dependency injection for MCP tools with startup graph validation

I maintain [Wireup](https://github.com/maldoinc/wireup), a type-driven DI library for Python.

If you are building MCP servers with FastMCP, Wireup has a dedicated integration:
https://maldoinc.github.io/wireup/latest/integrations/fastmcp/

What you get:

- dependency injection directly in `@mcp.tool` handlers
- startup graph validation (missing deps, cycles, lifetime mismatches, missing config fail at startup) so you can catch wiring errors before they happen in production
- explicit lifetimes and lifecycle-managed resources
- same service graph reusable across FastMCP, FastAPI, workers, CLI, and scripts
- works with FastMCP and FastAPI/Starlette at the same time when you mount `mcp.http_app(...)`

Standalone FastMCP example:

```python
import wireup
import wireup.integration.fastmcp
from fastmcp import FastMCP
from wireup import Injected
from wireup.integration.fastmcp import inject

mcp = FastMCP("MCP Server")


@mcp.tool
@inject
async def greet(greeter: Injected[GreeterService]) -> str:
    return greeter.greet("World")


container = wireup.create_async_container(injectables=[services])
wireup.integration.fastmcp.setup(container, mcp)
```

If you also run workers or CLIs, the same service graph can be reused in Celery and Typer among others.

Also supported:

- `FastMCP.from_fastapi(app=...)` with Wireup FastAPI integration
- mounted `mcp.http_app(...)` under Starlette/FastAPI with parent framework integration, so the same DI setup can serve both FastMCP tools and regular web routes in one app

Docs:
https://maldoinc.github.io/wireup/latest/integrations/fastmcp/

Repo:
https://github.com/maldoinc/wireup
