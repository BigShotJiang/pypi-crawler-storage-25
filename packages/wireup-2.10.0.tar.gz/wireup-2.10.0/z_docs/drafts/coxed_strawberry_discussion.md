# Show and Tell: Wireup DI for Strawberry apps (FastAPI, Starlette, and Django)

I maintain [Wireup](https://github.com/maldoinc/wireup), a DI library for Python.

If you are using Strawberry, Wireup works by integrating with the framework Strawberry runs on:

- FastAPI integration
- Starlette integration
- Django integration

Strawberry docs in Wireup:
https://maldoinc.github.io/wireup/latest/integrations/strawberry/

Why this is useful:

- fail-fast startup validation of dependency graphs
- explicit lifetimes for request-scoped and shared services
- resolver-level dependency injection via `@inject`
- reusable service graph across API, workers, and scripts

What resolver injection looks like:

```python
import strawberry
from wireup import Injected
from wireup.integration.fastapi import inject


@strawberry.type
class Query:
    @strawberry.field
    @inject
    def hello(self, greeter: Injected[GreeterService]) -> str:
        return greeter.greet("World")
```

Same `GreeterService`, reused in Typer and Celery:

```python
# Typer
import typer
from wireup import Injected

cli = typer.Typer()


@cli.command()
def greet(name: str, greeter: Injected[GreeterService]) -> None:
    typer.echo(greeter.greet(name))
```

```python
# Celery
from wireup import Injected
from wireup.integration.celery import inject


@celery_app.task
@inject
def greet_task(name: str, greeter: Injected[GreeterService]) -> str:
    return greeter.greet(name)
```

Typer integration:
https://maldoinc.github.io/wireup/latest/integrations/typer/

Celery integration:
https://maldoinc.github.io/wireup/latest/integrations/celery/

You can also inject into Strawberry resolvers with the host framework's `inject` decorator and request context types.

Full integration docs:
https://maldoinc.github.io/wireup/latest/integrations/strawberry/

Repo:
https://github.com/maldoinc/wireup

Happy to answer questions.
