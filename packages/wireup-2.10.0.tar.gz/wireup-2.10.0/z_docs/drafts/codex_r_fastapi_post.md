## Wireup for FastAPI now supports DI in background tasks

Hi /r/fastapi,

I maintain [Wireup](https://github.com/maldoinc/wireup), a type-driven DI library for Python, and I recently improved the FastAPI
integration. The part I think is most useful for FastAPI is `WireupTask`, a small wrapper that makes background task
functions DI-aware.

It lets you inject dependencies into FastAPI background task callbacks.
Each task gets its own scope, separate from the request and other tasks, so it gets fresh scoped services like DB
sessions and transactions, while still sharing app-wide singletons where appropriate.

I wanted this for background task code that still needs DI and cleanup, without manually rebuilding services or passing
extra objects down from the request. You can also use the same services outside HTTP, like in CLIs and workers.

Example:

    from fastapi import BackgroundTasks, FastAPI
    import wireup
    import wireup.integration.fastapi
    from wireup import Injected, injectable
    from wireup.integration.fastapi import WireupTask

    # Create a wireup container and FastAPI app as usual.
    container = wireup.create_async_container(injectables=[GreeterService])

    # Define an injectable
    @injectable
    class GreeterService:
        def greet(self, name: str) -> str:
            return f"Hello, {name}!"


    # Background task functions can now have injected dependencies.
    # `Injected[T]` is like `Depends`, but resolved by Wireup's container.
    def write_greeting(name: str, greeter: Injected[GreeterService]) -> None:
        print(greeter.greet(name))


    app = FastAPI()

    # Regular route handler.
    @app.post("/enqueue")
    async def enqueue(
        name: str,
        tasks: BackgroundTasks,
        wireup_task: Injected[WireupTask],
    ):
        tasks.add_task(wireup_task(write_greeting), name)
        return {"ok": True}


    # Set up the integration after creating the app and container.
    wireup.integration.fastapi.setup(container, app)

Wireup also supports injection in route handlers and elsewhere in the request path, testing, and request/websocket
context in services. You can adopt it incrementally alongside `Depends`.

You can also define app-wide (`singleton`), per-request (`scoped`), and always-fresh (`transient`) services in one
place, with startup validation for missing deps, cycles, lifetime mismatches, and config errors.

If you're already using `Depends`, I also wrote a migration guide for moving over one service at a time.

I also included benchmarks vs FastAPI `Depends`, with the methodology and benchmark code in the docs.

Background tasks:
https://maldoinc.github.io/wireup/latest/integrations/fastapi/background_tasks/

FastAPI integration docs:
https://maldoinc.github.io/wireup/latest/integrations/fastapi/

Migration guide from `Depends`:
https://maldoinc.github.io/wireup/latest/migrate_to_wireup/fastapi_depends/

Benchmarks:
https://maldoinc.github.io/wireup/latest/benchmarks/

Repo:
https://github.com/maldoinc/wireup

If you use background tasks in FastAPI, are you currently passing DB sessions and similar services down manually?
