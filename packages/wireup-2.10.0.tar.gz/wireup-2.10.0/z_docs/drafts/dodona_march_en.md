The Evidence of Ancient Authors and Epigraphic Testimonies Makes the Location of Dodona in the Carakovista Valley Unsustainable

Kujtim Mateli, Tirana Albania

Abstract
This study critically re-examines the traditional identification of Dodona with the archaeological
site in the Carakovista valley, a thesis consolidated in modern historiography since the end of the
nineteenth century after the excavations of Konstantin Karapanos. By systematically integrating
ancient literary sources, topographical analysis, epigraphic evidence, and archaeological data, the
study tests the consistency of this identification against three fundamental criteria: textual
coherence, geographical reality, and chronological continuity.

Ancient authors describe Dodona as an oracular center situated on the slope of Mount Tomar,
near the Dodon River (Selis), in Upper Epirus and on the borders with Illyria, with a long
historical continuity. The analysis shows that these topographical and geographical elements do
not correspond to the reality of Carakovista, which lies in central Epirus and presents an
archaeological lifespan limited mainly to the Hellenistic period.

The epigraphic material from Carakovista shows that Zeus Naios and Dione were worshipped
there, while Zeus Dodonaios is mentioned in only one inscription. The lead tablets reflect
consultative practices, clearly distinguishing this center from the historical oracle of Dodona. The
topographical, cultic, and chronological mismatch makes the identification of Carakovista with
Dodona methodologically unsustainable.

The study argues that Carakovista should be understood as a political and religious center of
Hellenistic Epirus, connected with the Epirote Alliance and the Koinon of Epirus, and that its
identification with Dodona represents a historiographical consensus that requires critical
methodological re-evaluation.

1. Introduction
Dodona occupies a central place in the religious, cultural, and political history of the ancient
world. Mentioned as early as Homeric epic and continuously documented by the most important
Greek and Roman authors, it represents not only the oldest oracle of Zeus, but also a key point
for understanding the relations between Epirus, Illyria, and the Hellenic world. Yet despite its
extraordinary importance, the exact location of Dodona remains one of the most problematic and
least critically re-examined issues in modern historiography.

Since the end of the nineteenth century, the identification of Dodona with the archaeological site
in the Carakovista valley has been widely accepted in scholarly literature, mainly on the basis of
Konstantin Karapanos’ excavations and the interpretation of the epigraphic material discovered
there. [1] This identification gradually solidified into a historiographical consensus, which was
reproduced in later studies without a systematic verification of its consistency with the sources of
antiquity. As a result, Carakovista was accepted de facto as Dodona, while early objections and
obvious inconsistencies were left at the margins of scholarly debate.

This study proceeds from the premise that such an identification cannot be considered valid
without full agreement among three fundamental criteria: the literary testimonies of ancient
authors, topographical and geographical reality, and archaeological and epigraphic evidence. Any
substantial discrepancy at one of these levels calls the identification into question, whereas a
systematic discrepancy at all three levels renders it untenable.

Ancient authors repeatedly describe Dodona as situated on the slope of Mount Tomar (Tmar), [2]
near the Dodon River (Selis), [3] in Upper Epirus [4] and on the borders with Illyria. [5] These
elements do not appear as incidental details, but as constituent parts of Dodona’s topographical
identity. In this sense, topography is not neutral, but functional and theologically charged.

In complete contrast to this description, the archaeological site claimed as Dodona in the
Carakovista valley presents an entirely different reality: it is not located on the slope of Mount
Oliçka, but on the hills of Kozmiras, at an elevation of 30 m above the valley; [6] it has no
identifiable river confirmed by the terrain where the archaeological site is located; it lies in the
middle of Epirus; [7] and it is archaeologically documented only for a limited period of about two
centuries. [8] This discrepancy has produced a continuing tension between textual sources and
archaeological interpretation, a tension that this study aims to analyze and resolve.

The purpose of this article is to critically re-examine the identification of Dodona with
Carakovista by integrating ancient literary sources, epigraphic testimonies, topographical
analysis, and archaeological data. Through this integrated approach, the study seeks to
demonstrate that Carakovista does not represent the Dodona of ancient authors, but rather a
distinct political and religious center of Hellenistic Epirus, connected with the local cult of Zeus
Naios [9] and with the institutions of the Epirote Alliance and Koinon. [10]

In this framework, the article does not aim merely to relocate a geographical site, but to correct a
historiographical paradigm that has directly affected the interpretation of ancient Epirus,
Epirote-Illyrian relations, and the role of Dodona in the Mediterranean world. Reconsidering this
identification opens the way to a more accurate understanding of the ethno-topographical map of
the region and the actual functioning of cults and institutions in ancient Epirus.

2. Materials and Methods
To investigate the location of Dodona and to evaluate claims linking it with the Carakovista
valley, this study uses a combination of ancient historical sources, nineteenth-century
geographical literature, and modern archaeological findings. The methodological approach is
multi-dimensional, following a chronological and comparative order that allows inconsistencies to
be identified and historical arguments to be verified.

2.1 Eighteenth- and nineteenth-century authors sought Dodona according to the testimonies of ancient authors
The principal sources for this study are the works of Strabo, Solinus, Hesiod, Pindar, Aeschylus,
Sophocles, Pausanias, and others, who provide detailed descriptions of Dodona, including its
position on Mount Tomar and near the Dodon River. Strabo places Dodona in the land of
Molossia, on Mount Tomar, and confirms the existence of an important oracle of Zeus
Dodonaios. Solinus reinforces this location, emphasizing the elevation and religious importance of
the city.

Besides ancient authors, the study also considers scholars of the eighteenth and nineteenth
centuries:

1. Dodona is located on the slope of Mount Tomar
Panajotis Aravantinos (Panayiotis Arabantinos), in his book Pragmateia peri Dodonis, Ioannina
1862, citing ancient authors (Στράβ. Η' 7, Ευστάθ. Η' 9), says: Dodona is located on the slope of
Mount Tomar. [11]
Samuel Butler, relying on the geographer Strabo, says: “Mount Tmarus, or Tomarus, we know
from Strabo was precisely the mountain on which Dodona stood,” while citing the other
geographer, Solinus, he says: “Dodona was high on Mount Tmarus.” [12]

2. Dodona is located near the Dodon River
The oracle of Dodona was located beside the Dodon River, which lay within the territory where
Dodona was situated. Panajotis Aravantinos (Panayiotis Arabantinos), in his book Pragmateia
peri Dodonis, Ioannina 1862, citing ancient authors Didymos Z' 7, H'10, Eustath. Z' 12, H'11,
says that the Dodon River or Selis flowed near the oracle, which lay within the territory where
Dodona was located. [13]

3. Dodona is located in northern Epirus
Jean-Jacques Barthélemy, relying on ancient authors, places Dodona in northern Epirus. [14]

In contrast to this position of eighteenth- and nineteenth-century authors, who sought Dodona on
the basis of ancient testimonies, Konstantin Karapanos declared that he had discovered Dodona in
the Carakovista valley. [15] His declaration was certified by a French scientific institution, but
the identification of Carakovista as Dodona remained contested.

2.2 Opposition to the localization of Dodona in the Carakovista valley
The location of Dodona in the Carakovista valley was opposed by prominent nineteenth-century
scholars, including Zoto Mollosi and Sami Frashëri.

Zoto Mollosi did not accept the Carakovista valley as the location of Dodona: “These do not
satisfy any modern Greek writer, except some superficial foreign writers who did not visit this
place and did not study the soil of Epirus.” [16]

Sami Frashëri: Mr. Karapano of Arta presents that, after certain excavations and archaeological
finds discovered between Ioannina and Arta, Dodona must be there and has also published some
brochures on this; but this place does not match the characteristics reported to us by Homer, the
historians, and the other ancient poets. [17]

The French archaeological mission had declared that Dodona was not located in the surroundings
of Ioannina, some years before Karapanos declared that Dodona was in Carakovista. The French
archaeological mission made this declaration after visiting these archaeological sites around
Ioannina for a long period and finding that none of them corresponded to the testimonies of
ancient authors. [18]

Even the very claimant of Dodona in the Carakovista valley, Konstantin Karapanos, at the
beginning of his book Dodone et ses ruins, Paris 1878, declared:

“The temple of Dodona, despite all its fame, was until now almost unknown. The Greek and
Latin authors provide us with very incomplete information, insufficient either to give us an idea
of what it was or to indicate the exact place of its location. Epigraphic or figurative monuments
connected with this temple, which would have served either to compensate for the silence of
ancient authors or to complete their information, are likewise lacking.” [19]

With this statement Karapanos confirms that the sources of ancient authors did not correspond to
the Carakovista valley. Thus all nineteenth-century authors, relying on the sources of ancient
authors, did not accept Carakovista as the location of Dodona. Yet after conducting excavations
there, Karapanos declared it to be the city of Dodona, although no inscription mentioned it as the
city of Dodona. Karapanos himself, speaking of the documents of the Epirote institutions that
were located in the temple, names the temple of Carakovista by its attribute Naios (Jupiter
Naios), [20] whereas in Dodona, according to ancient sources, Zeus Dodonen (Dodonean) was
worshipped.

2.3 The topography of Dodona according to ancient authors
Ancient authors place Dodona on the slope of Mount Tomar, the oracle near the Dodon River,
which flowed by the city of Dodona, while Dodona’s geographical position was in northern
Epirus, in the land of Molossia, on the borders of Illyrian Atintania, or on the border between
Epirus and Illyria.

1. Dodona on the slope of Mount Tomar
The study analyzes the topographical problem of Dodona by placing it on Mount Tomar. Three
important ancient authors who lived when Dodona existed, Strabo, Solinus, and Hesychius,
testified about Dodona and its temple.
Strabo (in the first century AD) says that Dodona was in the land of Molossia, on Mount Tomar
or Tmar (both names were used), where the temple was also located. [21]
Solinus places Dodona on the body of Mount Tomar, [22] and Hesychius also places Dodona on
Mount Tomar. [23]
All three authors provided precise descriptions and leave no room for interpretation. It is a true
mountain located in the land of Molossia.

2. The presence of the Dodon River (Selis) near the oracle
An essential element of Dodona is the sacred river, called by ancient authors by the name Dodon.
Some ancient authors, among whom we may mention Didymos and Eustathius, speak of the
Dodon River flowing near the oracle of Dodona: Didymos Z' 7, H'10, Eustath. Z' 12, H'11. [24]
Stephanus of Byzantium says that the Dodon River is a river of Epirus, at Dodona. [25]
This river flowing near Dodona, attested by three authors, was not a secondary element. In the
ancient world, the presence of water was an integral part of religious cults, especially in ancient
Pelasgian sanctuaries.

3. Geographical position: Dodona is located in Upper Epirus or in northern Epirus
Another fundamental criterion is Dodona’s position within Upper Epirus. Polybius and other
authors clearly distinguish Upper Epirus from Lower Epirus, placing Dodona in the northern and
interior part of Epirote territory. He testifies that Dodona was in Upper Epirus: “the army entered
the upper part of Epirus ... and when it reached the sacred place of Dodona, it burned the porticos
of the temple, destroyed many of the offerings, and overthrew the walls of the sanctuary.” [26]
This geographical designation is of great importance. Upper Epirus included mountainous
territories with direct connections to southern Illyria. These very characteristics correspond to the
Homeric descriptions of Dodona as a cold and remote place.

The Carakovista valley lies in the middle of Epirus, southwest of Ioannina, naturally connected
with Lower Epirus. Placing Dodona in this zone creates a direct conflict with the geographical
division of Epirus described by ancient authors.

Other ancient authors who wrote about Dodona also placed it in northern Epirus. This explains
why the topography given by ancient authors is not that of the Carakovista valley, but of one of
the northern locations of Epirus. Scylax placed it on the borders of Illyrian Atintania, whose
territory extended along the right bank of the Aos River. [27] The most precise testimonies for
the location of Dodona come from the archives of the Roman Empire, where Dodona was on the
borders of Illyrian Atintania and in the land of Molossia, while Mount Tomar of Dodona was a
shared mountain of Atintania and Molossia, or a shared mountain of Illyria and Epirus. [28] Thus
the data of ancient authors place Dodona on the border dividing Illyria from Epirus.

2.4 Climate and the Homeric description
Homer describes Dodona as a place with a harsh climate and cold land. This description is not
metaphorical, but geographical. The climate of Upper Epirus, with cold winters and mountainous
relief, fully corresponds to this description. [29]
The commentator on Homer’s Iliad, designated D, commenting on the verses in Book 16, line
233 and following, tells us that Dodona is a place of the Hyperboreans. [30]
This testimony corresponds to that of other authors that Dodona was located on the frontier line
between Epirus and Illyria. With these testimonies, there can be no doubt that Dodona was in
northern Epirus, on its border with Illyria.

2.5 Cultural and religious analysis
This study takes into account the cultural and religious differences between historical Dodona and
the city of Carakovista. In Dodona, Zeus Dodonen (Dodonaios) was worshipped, whereas in
Carakovista Zeus Naios was worshipped. This difference is significant, because it indicates a
different civic and religious identity, confirming that the city of Carakovista cannot represent
Dodona. In this context, the analysis includes comparison with other cities of Epirus and Illyria,
such as:
- Butrint: Zeus Soter. [31]
- Kassope: Zeus Soter. [32]
- Byllis: Zeus Tropeos. [33]
- Mavrora (Olympé): Zeus Megistos. [34]
- Passaron: Zeus Ario. [35]
- Amantia: Zeus Boulaios. [36]
- Carakovista: Zeus Naio. [37]
demonstrating that every city had its own local deity, making the correct identification of Dodona
a methodological requirement.

2.6 The longevity of Dodona
Dodona is mentioned as early as the time of the Trojan War as a famous sanctuary, to which the
main heroes of that war turned: Achilles addressed it from the battlefield at Troy, [38] while
Odysseus went to Dodona to consult the oracle. [39] Aeneas of the Trojan Dardanians also went
to Dodona before departing for Italy, receiving the blessing of the deity. [40] Dodona was famous
for its temple and oracle. All levels of society turned to it, from shepherds to those who worked
the land, even the kings of Epirus themselves: Pyrrhus of Epirus went there [41] and Alexander
the Molossian. [42]

The important ancient authors who wrote about Dodona gave it the epithet Pelasgian, making
clear that Dodona’s ethnic affiliation was Pelasgian. They provided important evidence about its
geographical position in northern Epirus, its topography, and its role in the society of the time.
Such authors include Hesiod and Sophocles, Aeschylus and Pindar, Pseudo-Scylax and
Pseudo-Scymnus, Hecataeus of Miletus and Dionysius of Halicarnassus, Ephorus and Polybius,
Strabo and Cassius Dio, Livy and Solinus, down to the end of the fourth century AD, when
Dodona was destroyed by the Roman emperor Theodosius I. Dodona even continued to exist after
its extinction as a pagan sanctuary, as an important episcopal center of Old Epirus, and in the
sixth century AD it is mentioned as one of the cities of Old Epirus. [43]

Thus Dodona has a lifespan of around 2,000 years, attested from before the Trojan War until its
extinction as an episcopal center. However, from Karapanos, Evangelides, and Dakaris to today’s
archaeologists, the construction of the sacred place is dated to the fourth century BC:
“Modern Description: ....The first signs of building activity date to the early fourth century BC,
when the first small temple of Zeus and three Ionic stoas were erected. The enclosure of the
Dodona acropolis, further north, dates to the same period.” [44]

The absence of epigraphic evidence from the Trojan War (12th century) to the fourth century BC,
as well as from the Roman and Christian periods (2nd century BC-6th century AD), which is
confirmed by archaeological excavations at Carakovista from Carapanos to the present, requires
serious examination of the identification of this city of Carakovista.

2.7 Archaeological analysis
Archaeological finds play a decisive role in this study. The analysis includes the materials
discovered by Karapanos, Evangjelides, and Dakaris, checking every inscription that might be
linked to Dodona. The results show that there is no inscription or reference identifying the city of
Carakovista with Dodona. On the contrary, the finds are connected with the cult of Zeus Naios,
which was a specific attribute of this city and not of Dodona.

1. Carakovista as the seat of Epirote institutions
The historical analysis of these finds also shows the absence of discoveries from prehistory down
to the fifth century BC, proving that the city was not a continuous settlement during the archaic
periods, when Dodona had great religious and political influence. Archaeological discoveries show
that Carakovista was a center of the Epirote Institutions during the fourth-second centuries BC,
which means that this city was created to serve as the seat of the Institutions of Epirus.

Konstantin Karapanos wrote that in the city of the Carakovista valley there were found:
“Inscriptions and fragments of inscriptions on copper and bronze plates reaching up to half a
millimeter in thickness. Among these inscriptions are decrees of the Assembly of the Epirotes,
issued during the reign of the Aeacids and others after the extinction of this monarchy, dealing
with proxeny, rights granted to cities in Epirus, contracts of purchase, the manumission of slaves,
etc.” [45] There are several dozen decrees of the Epirote Assembly placed in Planche
(XXVII-XXXIII), which show that important decisions of the Epirote Institutions were taken in
this city of the Carakovista valley. [46]

The archaeologist Sotiros Dakaris defines the period of existence of the Epirote Institutions linked
to the decrees issued by them: center of the Epirote Alliance (343/2 to 234/3) and later the
Koinon of Epirus (234/3 to 168). [47]

2. Carakovista worshipped Zeus Naio and Dione
In the category IV inscriptions found in the Carakovista valley, dedications were addressed to
Zeus Naios, while only one inscription was dedicated to Zeus Dodonen, which came from the
island of Zakynthos. The family that sent this offering had been proxenoi of the Molossians for 30
generations, from the time of Cassandra of Troy. [48]

The inscriptions of the sixth category, discovered by Karapanos, Evangelides, and Dakaris,
consist of 38 readable tablets. Herbert William Parke summarizes and interprets them in his book
The Oracles of Zeus: Dodona, Olympia, Ammon. All these tablets contain questions addressed to
Zeus Naios and Dione, but no oracular response is found, proving that the questions were
addressed to the sanctuary of the temple and not to an oracle. [49]

A particular example is question no. 18: “God. For good fortune. Does the god give an oracle to
Phainylos to work at his ancestral trade, to be a fisherman, and he will fare better and more
well?” [50] This case clearly demonstrates that the sanctuary did not provide oracular responses,
but advice on practical matters and daily life.

This material shows that the principal deity worshipped at Carakovista was Zeus Naios and
Dione, while only one particular case was connected with Zeus Dodoneen. This shows that the
city of Carakovista had its own distinct local cult, distinguishable from Dodona.

Main conclusions:
1. Carakovista is not the Dodona of ancient history, but a local center of the cult of Zeus Naios.
2. A single inscription addressed to Zeus Dodoneen does not alter this conclusion; it represents a
special historical connection of one family with the Molossians.
3. The public and private requests show a practical function of the sanctuary within the
community, and not the activity of an oracle.
4. Comparison with ancient literature and modern studies shows that Dodona was located in
northern Epirus, on Mount Tomar, and not in the Carakovista valley.

This chapter reinforces the thesis that the historical and archaeological identification of Dodona
must be based on the combination of ancient historical and literary sources, inscriptions, and
topographical analysis, rather than on a partial interpretation of local finds.

2.8 Methodology of source integration
To ensure a consistent approach, this study integrates three types of sources: historical,
geographical, and archaeological. Every claim about the location of Dodona must satisfy all three
criteria: consistency with ancient texts, topographical correspondence, and archaeological
evidence. This approach helps identify inconsistencies and avoid the errors that occurred in the
nineteenth century. Comparative analysis of nineteenth-century sources with ancient sources also
makes it possible to understand why later authors erred concerning the location of Dodona and
how these mistakes affected the interpretation of other tribes and cities of Epirus.

3. Results
The integrated analysis of ancient literary sources, epigraphic testimonies, topography, and
archaeological material produces a series of consistent results that directly challenge the
identification of Dodona with the Carakovista valley and require a fundamental revision of this
historiographical consensus.

3.1 Historical and geographical evidence
Analysis of the works of Strabo, Solinus, and Pseudo-Scylax clearly shows that Dodona was
located in northern Epirus, in the land of Molossia and on Mount Tomar. Strabo places the city
and temple of Dodona on the mountain slope, providing a suitable setting for the cult of Zeus
Dodonaios. Solinus reinforces this location, calling Dodona a city raised in elevation, an
important factor in its sanctity. Stephanus of Byzantium, Eustathius, and Didymus place the
oracle beside the Dodon River, which excludes the Carakovista valley as the location of Dodona,
because there neither the river exists nor archaeological ruins on the slope of Mount Oliçka that
could be claimed as the Tomar of antiquity.

Comparison with nineteenth-century literature, including Aravantinos and the French
Archaeological Mission, shows that the scholars of this period likewise placed Dodona on Mount
Tomar and beside the Dodon River, rejecting the connection with Carakovista. This historical
standard is necessary for identifying inconsistencies in the claimed location southwest of Ioannina.

3.2 The systematic mismatch between ancient sources and Carakovista
The first and clearest result is that no ancient author describes Dodona in a topography that
matches the Carakovista valley. All the major authors, from Homer to Strabo and Polybius,
Solinus and Pseudo-Scylax, Eustathius and Stephanus of Byzantium, Matthias Katicic, etc., place
Dodona:
- on the slope of a true mountain (Tomar/Tmaros),
- near a river called Dodon (Selis),
- in Upper Epirus, on the borders with Illyria or Atintania.

1. In the Carakovista valley, on the southwestern side of the valley, lies Mount Oliçka. If the
ruins of a city were situated on the slope of this mountain, one might have a claim. However, the
ruins of the city lie on the opposite side of the valley, at an elevation of 30 meters, on the hills of
Kozmiras. [51] The geographical position of the ruins claimed as Dodona does not correspond to
the testimonies of ancient authors who place Dodona on the slope of a mountain called Tomar.
[52]
2. One of the key elements determining the location of Dodona is the Dodon River. According to
ancient sources, this river flowed beside the city and the oracle. In the Carakovista valley no such
river exists, which makes the identification of this place as Dodona impossible. [53]
3. Ancient authors place Dodona in northern Epirus, also called Upper Epirus, on the borders of
Illyria, whereas Carakovista, where Dodona is claimed to be, lies in the middle of Epirus. This
testimony is sufficient to say that Carakovista is not the location of Dodona. [54]

3.3 Dodona had a lifespan of about 2,000 years. In Carakovista the city’s lifespan has archaeological evidence for about two centuries (175 years)
The excavations carried out by Karapanos, Evangjelides, and Dakaris show that there is no
inscription connected with the city of Dodona in Carakovista. [55] Archaeological finds show
that the city worshipped Zeus Naios, a local deity with no connection to Zeus Dodonaios.

The absence of finds from prehistory down to the fifth century BC shows that the city was not a
continuous settlement during the periods when Dodona had great influence from the Trojan War,
12th century BC, as mentioned in Homer’s two works, the Iliad and the Odyssey. [56] Hesiod
(7th century BC) places Dodona at the end of the plain of Hellopia, [57] and so do other authors
after him.

From the twelfth century to the fifth century BC there are seven centuries of Dodona’s existence,
for which no evidence is found in the Carakovista valley to justify this period. There are abundant
finds there proving the existence of this city, which worshipped Zeus Naio, from the middle of
the fourth century (343) to the second century (168). After the Roman conquest in 168 BC,
Dodona continued until the fourth century AD, when the Pelasgian sanctuary was destroyed by
Theodosius I. After being destroyed as a Pelasgian sanctuary in the fifth-sixth centuries, it
became an episcopal center in Old Epirus. Thus from the second century BC to the sixth century
AD there are eight centuries of Dodona’s existence, yet no inscription from this period has been
found in the Carakovista valley. Academician Kristo Frashëri, writing about the Council of
Ephesus in AD 431, states that in the acts of the Council of Ephesus preserved in the Vatican
archive, Dodona was represented by Bishop Theodor. (Acta Conciliorum Oecumenicorum.
Concilium Universale Ephesenum. Edidit Edvardus Schwrtz. Acta graeca. Pars altera. Collectio
Vaticana 33 80. Berolini et Lipsiae 1927, p. 55, 57). [58]

In Carakovista there is archaeological evidence for only two centuries, whereas ancient authors
document the existence of Dodona beginning with the Trojan War and continuing into the fifth
century AD with the Council of Ephesus and later into the sixth century AD as a city in Old
Epirus. [59]

In almost every century Dodona is attested by the most important authors who wrote about its
history and geography. If we also include commentators on the works of ancient authors and less
well-known writers who nevertheless gave very important testimonies about Dodona, then we may
say that Dodona clearly demonstrates its continuity across nearly two millennia. These testimonies
show Dodona’s active existence in the life of contemporary society, from kings and famous
warriors who shaped ancient history down to ordinary individuals seeking to know their fate. The
results show an irreconcilable contrast between:
- Dodona’s lifespan of about 2,000 years,
- and Carakovista’s existence of about 200 years.

This fact alone, even without the other arguments, is sufficient to exclude the identification of
Carakovista as Pelasgian Dodona.

3.4 Archaeological finds at the Carakovista site claimed as Dodona
In the Carakovista valley a large number of archaeological finds were discovered, which
Konstantin Karapanos organized into 17 categories. Not all of these categories contain
inscriptions. The answer to whether this archaeological site of Carakovista is or is not Dodona is
found only in the inscriptions. Therefore all archaeological finds that contain inscriptions have
been carefully examined, and I present them here in summarized form.

1. In the archaeological finds of the fourth category there are 24 different ex-votos, some of them
complete and some fragmentary. One of them was dedicated to Zeus Dodoneen, another to the
goddess Aphrodite, and the others to Zeus Naios, as well as to Zeus Naio and Dione. All these
inscriptions are in Planche XXII-XXVI. [60]

2. The inscriptions of the sixth category, discovered by Karapanos, Evangelides, and Dakaris,
consist of 38 readable tablets. Herbert William Parke summarizes and interprets them in his book
The Oracles of Zeus: Dodona, Olympia, Ammon. [61] All these tablets contain questions
addressed to Zeus Naios and Dione, but no oracular answers are found, proving that the questions
were directed to the sanctuary of the temple and not to an oracle. They are divided into two
groups: public-interest questions, 9 tablets, and private-interest questions, 28.

In all readable inscriptions, the deity’s epithet was:
1. In the inscriptions of the fourth category:
- Zeus Dodoneen: only one inscription is addressed to Zeus Dodonen, sent by Agathon, an
inhabitant of the island of Zakynthos, representing a long family tradition of proxenoi of the
Molossians for 30 generations.
- Zeus Naios / Naios: the epithet Naio-Naios appears in the gifts brought to this sanctuary by
various donors.
- Only one inscription is addressed to the goddess Aphrodite.

2. In the inscriptions of the sixth category:
- Zeus Naio-Naios and Dione. All the inscriptions are addressed to Zeus Naio-Naios and Dione in
all public and private questions.

This clearly shows that the city worshipped primarily Zeus Naios, while the mention of Zeus
Dodoneen has a historical and ritual character, reflecting one particular family’s connection with
the sanctuary of Dodona. Most of the private requests show that citizens used the sanctuary as a
place for divine consultation, following the tradition of personal connection with the deity and the
temple, not as a formal oracle.

Karapanos and his supporters claimed that the questions in Carakovista were addressed to the
oracle, calling the god Zeus Naios. But comparison with archaeological finds and older literature
shows that this was a temple sanctuary and did not constitute an oracle equal to Dodona.

The strongest testimony is that of the priest of the temple at Carakovista, who in a legal process
represented Zeus Naios, [62] whereas in Dodona the priest of the chief god was that of Zeus
Dodonen, showing a clear differentiation of cults.

That there was no oracle at Carakovista, but a temple, is confirmed by comparison with other
cities of Epirus and Illyria. These cities honored the deity with their own epithet:
- Byllis: Zeus Tropeos. [63]
- Mavrora (Olympé): Zeus Megistos. [64]
- Passaron: Zeus Ario. [65]
- Amantia: Zeus Boulaios. [66]
- Carakovista: Zeus Naio. [67]
- Dodona: Zeus Dodonen (also Dodonaios, Dodonean), according to the sources of ancient
authors:
Pausanias: Zeus Dodonaios. [68]
Strabo: Zeus Dodonaios. [69]
Livy: Jupiter Dodonean. [70]

It is clear that in Carakovista there was a temple serving this city, but also individuals and cities
from the Epirote area and beyond, because temples were open to anyone who wished to make an
offering to the deity or seek counsel from him.

3.5 Epigraphic results: the absence of Zeus Dodonaios
The full analysis of the inscriptions discovered in Carakovista shows that:
- the dominant cult is that of Zeus Naios and Dione,
- Zeus Dodonaios does not appear as the central deity,
- a single inscription, originating from outside the territory (Zakynthos), mentions Zeus
Dodonaios and is not organically connected with the city.

This result is decisive, because in the ancient world the epithet of a deity was a territorial and
political identity, not a secondary detail. A city that does not worship Zeus Dodonaios cannot be
identified as Dodona.

3.6 Analysis of the formula and nature of the requests
Most of the questions began with the formula “God, for good fortune...,” showing that this was
not an oracular response, but a request addressed to the temple for counsel and divine support.
The clearest example is question no. 18: “God. For good fortune. Does the god give an oracle to
Phainylos to work at his ancestral trade, to be a fisherman, and he will fare better and more
well?” [71]

All the questions addressed to the temple at Carakovista show that people turned to it to obtain
approval or advice for the action they were about to undertake. At an oracle, people went to learn
their fate in the future or, if things had gone badly for them, the reasons why. Thus the questions
addressed to the temple were different from those addressed to the oracle. This request no. 18
shows that Phainylos went to the temple, which is why he asks whether they could give him an
oracle. The question he asked sought an oracular answer. He wanted to know what his future
would be after taking up his ancestral craft. Since he asks whether the god could give him an
oracle, this means that Carakovista did not produce oracles and that this sanctuary has no
connection with the oracle of Dodona.

Conclusions from the archaeological finds and historical sources
The results show that:
1. The city of Carakovista does not match topographically the Dodona of ancient authors; the
river is absent and the location is not on the slope of a mountain, but on a low hill 30 meters high,
in the hills of Kozmiras.
2. The inscriptions confirm that the city’s sanctuary was dedicated mainly to Zeus Naios and did
not represent the oracle of Dodona.
3. A single inscription with the epithet Dodoneen reflects a historical family connection and does
not alter the local character of the cult.
4. Most importantly, Carakovista lies in the middle of Epirus, whereas the sources of antiquity
place Dodona at the northern edge of Epirus, on the border with Illyria.

In summary, the finds suggest a local cult of Zeus Naios, with a consultative and supportive
function for citizens, clearly distinct from the cults of Dodona and its historical oracle.

3.7 The city of Carakovista was the seat of the Epirote institutions
Archaeological finds proved that this city was the seat of the Epirote Institutions. Several dozen
decrees placed by Karapanos in Planche (XXVII-XXXIII) show that important decisions of the
Epirote Institutions were taken in this city in the Carakovista valley. [72]

Archaeologists have determined the period of existence of the Epirote Institutions linked with the
decrees issued by them: the Epirote Alliance (343/2 to 234/3) and later the Koinon of Epirus
(234/3 to 168 BC). [73]

Those elected according to the regions of Epirus exercised their function in the Bouleuterion,
whose operation required a permanent administration, from which arose the need to build
dwellings for them, as well as for workers such as merchants, builders, maintenance staff, etc. A
small city of 3.5 ha was created, only as large as the needs for buildings serving the Epirote
Institutions required. [74] To meet the religious needs of the inhabitants of this city, a temple was
created with the special epithet Naio, whose lifespan is equal to that of the Epirote institutions
(343-168 BC), as attested by the archaeological finds of Carakovista. This is also accepted by the
archaeologist Pierre Cabanes. Indeed, starting from the small dimensions of the acropolis, 3.5 ha,
only as large as a neighborhood in the cities of Epirus and Illyria, he questions the existence of
Dodona in Carakovista. Hence his intervention: “As for Dodona, you have always correctly dated
the first constructions of the sanctuary to around the middle of the 4th century; what is surprising
about Dodona is the very small size of the acropolis, of the city, much smaller than all the other
cities you have mentioned.” [75]

The archaeological and epigraphic material shows that Carakovista functioned:
- as the seat of the Epirote institutions,
- as the place of meetings of the Epirote Alliance (343/2 to 234/3 BC),
- as the place of meetings of the Koinon of Epirus (234/3 to 168 BC),
- during a limited period (4th-2nd centuries BC), which is precisely the lifespan of the city of
Carakovista.

There is no evidence for continuous religious activity from the archaic period onward, as required
for Dodona, which is documented from the Homeric age. The results of the historical,
topographical, and archaeological analysis show clearly that the Carakovista valley cannot be
identified as the location of Dodona. Identifying Dodona in Carakovista not only conflicts with
archaeological and cultic evidence, but also distorts the ethno-topographical framework of ancient
Epirus.

Carakovista’s urban structure clearly indicates a political center, not an archaic sanctuary. The
presence of the bouleuterion, [76] public institutions, and a gigantic theater, among the largest,
with a capacity of 17,000 spectators [77] shows that the city was intended for:
- assembly meetings,
- political decision-making,
- public and representative activities.

This study clearly shows that Carakovista was not Dodona. It represents an important city of the
Hellenistic period, organized as a political and administrative center of Epirus.

Ancient sources place Dodona in the territory of the Molossians, on Mount Tomar, far to the
north of the presumed site of Carakovista. Scylax specifies it by placing it in the valley of the Aos
River, on the borders of Illyrian Atintania. [78] The above results impose a critical discussion of
the way the historiographical consensus around Carakovista was formed and of its consequences
for studies on Epirus and Illyria.

4. Discussion
The results presented above require a profound re-examination of the traditional paradigm that
identifies the Carakovista valley with the Dodona of ancient sources. Their discussion is intended
not simply to refute a consolidated hypothesis, but to clarify the methodological criteria on which
the identification of an oracular center of pan-Epirote and wider significance must be based.

4.1 The convergence of ancient sources and the topographical criterion
One of the most significant results of this study is the extraordinary convergence of ancient
sources concerning the location of Dodona. From Homer to late antique authors, Dodona is
repeatedly described as:
- located on a mountainside (Tomar/Tmaros), [79]
- near a river named Dodon, [80]
- in Upper Epirus, on the borders with Illyria. [81]

In ancient geography, especially in authors such as Strabo and Pseudo-Scylax, topographical
description is functional and orienting. Therefore the systematic mismatch of Carakovista with
these criteria, the absence of the river, the position on the edge of the valley in the hills of
Kozmiras and not on the slope of Mount Oliçka, which might be claimed as Tomar, as well as its
location in the middle of Epirus, are not secondary details, but a structural counterargument
against the identification with Dodona.

4.2 The methodological problem of the Karapanos paradigm
Discussion of the results brings to light that the identification of Carakovista with Dodona was
built on a series of problematic methodological shifts. First, one observes a selectivity in the use
of ancient sources, in which topographical descriptions are minimized or relativized in favor of
monumental finds. Beginning with Karapanos’ supporters, members of the institute that certified
Carakovista as the location of Dodona, the sources of ancient authors were set aside; Carakovista
was taken for granted as Dodona, even though no epigraphic find was discovered to prove it as
the city of Dodona. [82]

Second, the epithet Naios was interpreted as a functional synonym of Zeus Dodonaios, beginning
with Karapanos and his supporters, scholars and historians, down to the archaeologists who
carried out the excavations at Carakovista: Evagjelides and Dakaris, [83] while ignoring the fact
that in the ancient world a deity’s epithet served as a sign of local and political identity. The
epigraphic results clearly show that in Carakovista we are dealing with a local cult of Zeus Naios,
comparable to other forms of Zeus with local epithets in the cities of Epirus and Illyria. Equating
this cult with the oracle of Dodona represents a disregard of the fundamental distinction between a
civic temple and a pan-Epirote oracular center.

4.3 Local temple versus pan-Epirote oracle
One of the most important contributions of the results is the clear distinction between the function
of the temple at Carakovista and that of the oracle of Dodona. The analysis of the question tablets
shows that the requests are directed to the deity for counsel and support, not for oracular
pronouncement in the strict sense of the term. [84]

The formulas used, and the absence of oracular responses, place this sanctuary within the
tradition of local advisory cults, widespread in Epirus and Illyria. At Dodona, by contrast, the
oracle is explicitly mentioned by ancient sources as a prophetic institution of broad authority,
consulted by kings, cities, and individuals from across the known ancient world. [85]

4.4 Longevity as a criterion of identification
Another decisive aspect of the discussion concerns chronology. Dodona is continuously
documented for almost 2,000 years, from the Homeric age to late antiquity. [86] In complete
contrast, Carakovista presents archaeological evidence for a lifespan of about two centuries,
closely linked to the functioning of Epirote institutions. [87]

This chronological mismatch cannot be explained by accidental archaeological gaps. Historians,
geographers, and archaeologists, as well as encyclopedias of global authority, have pointed out
the absence of Dodona in Carakovista. From the Trojan War (12th century BC) to the fourth
century BC, there are around eight centuries for which there is no epigraphic find nor any
building connected with it: “The topographical and architectural results are disappointing, and
show either that the site always retained its primitive simplicity, or else that whatever buildings
once existed have been very completely destroyed.” [88]

This absence of archaeological finds proves that Carakovista is not the location of Dodona,
because Dionysius of Halicarnassus states that in his own time, offerings dedicated by Aeneas of
Troy to the oracle were preserved at Dodona: “and after dedicating to the god various Trojan
offerings, including bronze mixing bowls, some of which are still in existence and by their
inscriptions, which are very ancient, show by whom they were given.” [89] For Trojan offerings
to have been preserved for about eleven centuries, from the Trojan War to the time of Dionysius
of Halicarnassus (1st century BC), there must have been not only buildings in which the offerings
were kept, but also buildings for the priests and even inns for those who came to inquire about
their fate. If Carakovista had been Dodona, many archaeological and epigraphic testimonies
would have been found there, including the Trojan offerings attested by Dionysius of
Halicarnassus.

During the Roman Empire, the temple and oracle of Dodona did not lose their importance.
Pausanias says: “Among the sights of Thesprotia are a sanctuary of Zeus at Dodona and an oak
sacred to the god.” [90]

Yet in the Carakovista valley epigraphic finds indicating the existence of Dodona during the
Roman period are completely lacking. In the fifth century, historical sources present Dodona as an
important episcopal center in Old Epirus, where several bishops are mentioned: Theodor,
Philotheos, Uranios, and Julian (Θεόδωρος, Φιλόθεος, Ουρανός, Ιουλιανός). [91] Theodor
represented Dodona as bishop at the Council of Ephesus in 431, while Philotheos did so at the
Council of Chalcedon in 451. Yet no epigraphic find related to Christian Dodona was found in
the Carakovista valley. This absence of epigraphic evidence makes the existence of Dodona in the
Carakovista valley unsustainable.

Karapanos, who first carried out excavations in Carakovista, did not produce any epigraphic
evidence for the period when Dodona was an episcopal center, nor for the Roman imperial period.
In Carakovista there is epigraphic evidence for only two centuries of lifespan (4th-2nd centuries
BC), but in none of it is the name of the city of Dodona found. There Zeus Naios was worshipped,
a special epithet which every city of Epirus and Illyria had in the temple of its own city dedicated
to Zeus. A center with the religious and political weight of Dodona would have left continuous
material and epigraphic traces, especially for the periods when literary sources attest intense
oracular activity.

4.5 Carakovista as an institutional Epirote seat
The results convincingly show that Carakovista functioned as the seat of the Epirote institutions
during the period of the Alliance and the Koinon of Epirus. [92] The presence of decrees, the
council house (bouleuterion), and the urban infrastructure reinforces this interpretation. [93] The
temple of Zeus Naios served the religious needs of an administrative and political community, not
the pan-Epirote oracular function.

In Carakovista, alongside Zeus Naios, Zeus Buleos (Bouleus) was also worshipped. [94] If this
city had been Dodona, then alongside Zeus Buleos, Zeus Dodoneos would have been worshipped,
as the deity of the city of Dodona, not Zeus Naios. The absence of Zeus Dodoneos in the
bouleuterion makes the claim that this city of Carakovista is Dodona untenable: “The cult of Zeus
Boulaios found on inscription at temple of Dodone and Amantia also belongs to public cults.
More specifically, at the council house (bouleuterion) of Dodone a rectangular altar found with an
engraved inscription, dedicated to Zeus Naios, Dione and Zeus Boulaios.” [95]

This interpretation is fully consistent with the archaeological, epigraphic, and historical data and
explains coherently why Carakovista displays developed urbanization but a marked absence of the
oracular elements that characterize the Dodona of ancient sources.

4.6 Historiographical implications
The discussion of the results shows that the identification of Carakovista with Dodona has had
wide consequences for reconstructing the history of Epirus and Illyria. This identification has
artificially shifted Dodona southward, distorting the ethno-topographical borders of Upper Epirus
and its relations with Illyria.

Revising this consensus is not merely a local archaeological issue, but a necessary step in
restoring coherence between ancient sources, material data, and historiographical interpretation.

Conclusion
This study has undertaken a systematic re-examination of the traditional identification of Dodona
with the Carakovista valley, treating this question not as an isolated problem of localization, but
as a methodological and historiographical knot with broad consequences for the interpretation of
ancient Epirus. The integrated analysis of ancient literary sources, topographical data,
archaeological material, and epigraphic evidence has consistently shown that this identification
does not withstand critical multidisciplinary verification.

The results have demonstrated that the descriptions of Dodona in ancient sources are
extraordinarily coherent and repeated over time. Dodona appears as an oracular center situated on
a mountain slope, near the Dodon River, in Upper Epirus, on the borders with Illyria and the
territory of the Molossians. These elements are not literary figures or poetic conventions, but
geographical and cultural indicators that serve real orientation. None of these criteria corresponds
to the topography of the Carakovista valley, which lies in central Epirus, without a corresponding
river and without any relation to Mount Tomar.

Epigraphic analysis has been decisive for clarifying the cultic nature of the Carakovista site. The
inscriptions show that the dominant cult was that of Zeus Naios and Dione, a local form of Zeus,
comparable to other civic cults in Epirus and Illyria. The almost complete absence of the epithet
Zeus Dodonaios, and its appearance only in a single isolated inscription originating outside the
territory, excludes the identification of this city as Dodona. In the ancient world, the epithet of a
deity was not an accidental element, but a marker of the territorial, political, and ritual identity of
the cult.

Equally significant is the analysis of the lead tablets, which have traditionally been interpreted as
evidence of an active oracle. Study of the formula, content, and function of these questions shows
that they belong to practices of divine consultation within the framework of a local temple, not an
oracular institution in the strict sense of the term. The absence of oracular answers and the
personal or administrative nature of the questions reinforce this conclusion and clearly distinguish
the sanctuary of Carakovista from the historical oracle of Dodona.

One of the strongest arguments of this study concerns chronology. Dodona is documented in
literary and historical sources for a period of nearly two millennia, from the Homeric age to late
antiquity and the early Christian period. In complete contrast, Carakovista presents a limited
archaeological lifespan of about two centuries, closely linked to the functioning of the Alliance
and Koinon of Epirus. This chronological mismatch is insurmountable and excludes every attempt
to equate two historically and functionally different realities.

The results clearly show that Carakovista functioned as the seat of the Epirote institutions and as
an administrative-political center with a local temple, built to meet the religious needs of an urban
and institutional community. This interpretation explains coherently the urbanization,
monumentality, and concentration of political decrees on this site, without requiring speculative
hypotheses about a “functional evolution” of Dodona from archaic sanctuary into Hellenistic city.

From a historiographical perspective, this study shows that the modern consensus on Carakovista
was built on a methodological displacement, in which ancient sources were subordinated to the
interpretation of archaeological material instead of serving as a criterion of verification. This
process has distorted the ethno-topographical framework of Epirus by shifting Dodona southward
and weakening its historical connections with Upper Epirus and the Illyrian borderlands.

The main aim of this article is to demonstrate that the identification of Dodona with Carakovista is
not scientifically sustainable and that any serious localization of Dodona must rigorously satisfy
the criteria established by ancient sources, epigraphy, and chronology.

In conclusion, this study proposes a return to a critical and integrative method in studies on
ancient Epirus. Only by respecting the independence and coherence of the different categories of
evidence can artificial identifications be avoided and a more accurate understanding of the
religious and political geography of the ancient world be restored. The case of Dodona represents
a meaningful example of how an early consensus, accepted without continuous verification, can
shape the interpretation of history for decades, and at the same time how a methodological
re-examination can open the way to a deeper and more reliable understanding of the past.

1. Constantin Carapanos, Dodonë et ses ruins, Vol 1 and 2, (Paris 1878).
2. Strabo, Geographica, trans. H. L. Jones (Cambridge, MA: Harvard University Press, 1924)
7.7.11.
3. Didymos Z` 7, H`10, Eustath. Z` 12, H`11”, in Panagiotis Arabantinos, Pragmateia peri
Dodonis (Ioannina, 1862) 37.
4. Polybius, The Histories, translated by William Roger Paton, (Loeb Classical Library 1922)
4.67.1–5
5. Matthias-Petrus Katancic, “Orbis antiques ex tabula itineraria, quae Theodosi I
Imperatoris et...”, Vol.1, Evropa, (Latin Edition, Mawman 1824) 636.
6. Constantin Carapanos, Dodonë et ses ruins, Vol 1 (Paris 1878) 10.
7. Constantin Carapanos, Dodonë et ses ruins, Vol 1 (Paris 1878) 7.
8. Sotiros Dakaris, Organisation politique et urbanistique de la ville dans l`Epir antique, in
“L`Ylliri meridionale et l`Epir dans l`Atiquite I”, Actes du colloque de Clermont-Ferrand
(Adosa1987) 75.
9. Herbert William Parke, The oracles of Zeus: Dodona, Olympia, Ammon, (Havard University
Press, 1967) 259-273.
10. Constantin Carapanos, Dodonë et ses ruins, Vol 1 (Paris 1878) 48.
11. Panagiotis Arabantinos, Pragmateia peri Dodonis (Ioannina, 1862) 37.
12. Samuel Butler, D.D. The oracle of Dodona; in Thomas Smart Hughes, Travels in Sicily,
Greece and Albania, Volume 1, (London, J. Mawman 1820) 526.
13. Panagiotis Arabantinos Pragmateia peri Dodonis (Ioannina), 1862) 37.
14. Jean-Jacques Barthélemy, Voyage du Jeune Anacharsis en Grèce dans le milieu du
quatrième siècle avant l’ère vulgaire, vol. III (Paris, 1790) 383.
15. Constantin Carapanos, Dodonë et ses ruins, Vol 1 dhe 2, (Paris 1878)
16. Zoto Molosi, Ηπειρωτικαί μελέται Vol 4, (Αθήναις1887) 207.
17. Sami Frashëri, Encikopedia, (Kamus-ül Alam), vol. III, (Istanbul 1898) 2172.
18.The memoirs of Ismail Kemal Bey, by Story, Sommerville, (London 1920) 25.
19. Constantin Carapanos, Dodonë et ses ruins, (Paris 1878) 1.
20. Constantin Carapanos, Dodonë et ses ruins, (Paris 1878) 48.
21. Strabo, Geographica, trans. H. L. Jones (Cambridge, MA: Harvard University Press, 1924)
7.7.11.
22. Solinus, Collectanea Rerum Memorabilium, VII.3.
23. Hesychius of Alexandria, Lexicon, s.v. Τόμαρος (Tomaros).
24.Didymus, Eustathus, fragmente in Panagiotis Arabantinos, Pragmateia peri Dodonis
(Ioannina, 1862) 37.
25. Stephanus of Byzantium, Ethnica, s.v Dodona
26. Polybius, The Histories, translated by William Roger Paton, (Loeb Classical Library 1922)
4.67.1–5
27. Pseudo-Scylax, Periplus, 26, translation by Brady Kiesling (2015)
28. Matthias-Petrus Katancic, Orbis antiques ex tabula itineraria, quae Theodosi I
Imperatoris et..., Vol.1, Evropa, (Latin Edition, Mawman 1824) 636.
29. Homer, Iliad, trans. A. T. Murray, (Cambridge, MA: Harvard University Press, London
1924) 16.233–235.
30. D-Scholia to Homer, Iliad 16.233, in Mythical Stories in the D-Scholia to Homer’s Iliad,
trans. R. Scott Smith et al. ( 2023).
31. Chryseis Tzouvara-Souli, Common cults in Epirus and Albania, in “L`Ylliri meridionale et
l`Epir dans l`Atiquite-II, Clermont-Ferrand (MAFEA 1993) 74.
32.Sotiros Dakaris, Organisation politique et urbanistique de la ville dans l`Epir antique, in
“L`Ylliri meridionale et l`Epir dans l`Atiquite I (Adosa 1987) 73.
33. Neritan Ceka, Mbishkrime byline, Iliria 2 (1987) 84.
34. Aleksandra Mano & Burhan Dautaj, Një mbishkrim nga Olympe e Ilirisë, Iliria 2 (1984) 112.
35. Plutarch, Pyrrhus, translation by. Bernadotte Perrin. (Cambridge, MA. Harvard University
Press, London 1920) 5.2.
36.Skënder Anamali, “Amantia,” Iliria 2 (1972) 81; Chryseis Tzouvara-Souli, Common cults in
Epirus and Albania, in “L`Ylliri meridionale et l`Epir dans l`Atiquite-II, Clermont-Ferrand
(MAFEA 1993) 74.
37.Constantin Carapanos, Dodonë et ses ruins, (Paris 1878) 48.
38. Homer, Iliada, book. XVI, v. 231-238.
39. Homer, Odisea, book. XIV, v. 327-330.
40. Dionysius of Halicarnassus, Roman antiquities, 1.51.1.
41. Dionis Cassii, Historia Romana, fragmenta, 40.4 .
42. Strabo, Geography, 6.1.5.
43. Hierocles, Synecdemus, 651.5.
44. Dodona (Ioannina) in ToposText.
45. Constantin Carapanos, Dodonë et ses ruins, Vol 1, (Paris 1878) 48-49.
46. Constantin Carapanos, Dodonë et ses ruins, Vol 1, (Paris 1878) 49-68.
47. Sotiros Dakaris Organisation politique et urbanistique de la ville dans l`Epir antique, in
“L`Ylliri meridionale et l`Epir dans l`Atiquite I (Adosa 1987) 75.
48. Constantin Carapanos, Dodonë et ses ruins, Vol 1, (Paris 1878) 39-40.
49. Herbert William Parke “The oracles of Zeus: Dodona, Olympia, Ammon, (Havard University
Press, 1967) 259-273.
50. Herbert William Parke “The oracles of Zeus: Dodona, Olympia, Ammon, (Havard University
Press, 1967) 269.
51. Constantin Carapanos, Dodonë et ses ruins, Vol 1, (Paris 1878)10.
52. Strabo, Geography book 7.7.11. ; Hesychius of Alexandria, Lexicon, s.v. Τόμαρος (Tomaros)
53.Didymus, Eustath, fragmente in Panagiotis Arabantinos, Pragmateia peri Dodonis (Ioannina,
1862) 37.
54. Polybius, The Histories, translated by William Roger Paton, (Loeb Classical Library 1922)
4.67.1–5.
55. Carapanos, Constantin, Dodone et ses ruins, Vol 1, (Paris 1878)1- 175.
56. Homer, Iliad, 16. 233–235; Homer Odisea, 14. 327-330.
57. Hesiod, fragment 97, in Hesiod: The Poems and Fragments, ed. and trans. M. L. West
(Oxford: Oxford University Press, 1988); Scholia on Sophocles, Trachiniae 1167.
58. Kristo Frashëri, Gazeta Shqiptare, 17 nëntor 2010.
59. Hierocles, Synecdemus, 651.5.
60. Constantin Carapanos, Dodonë et ses ruins, Vol 1 (Paris 1878) 39- 48.; Constantin
Carapanos, Dodonë et ses ruins, Vol 2 (Paris 1878) planch. XXII-XXVI.
61. Herbert William Parke “The oracles of Zeus: Dodona, Olympia, Ammon, (Havard University
Press, 1967) 259-273.
62. Constantin Carapanos, Dodonë et ses ruins, Vol 1, (Paris 1878) 50.
63. Neritan Ceka, Mbishkrime byline, Iliria 2 (1987) 84.
64. Aleksandra Mano & Burhan Dautaj, Një mbishkrim nga Olympe e Ilirisë, Iliria 2 (1984) 112.
65. Plutarch, Pyrrhus 5.2.
66. Skënder Anamali, “Amantia,” Iliria 2 (1972) 81.
67. Constantin Carapanos, Dodone e ses ruins, (Paris 1878) 48.
68. Pausanias, Description of Greece 1. 13. 3.
69. Strabo, Geography 5. 2. 4.
70. Titus Livius (Livy), The History of Rome, 8. 24.
71. Herbert William Parke “The oracles of Zeus: Dodona, Olympia, Ammon, (Havard University
Press, 1967) 269.
72. Constantin Carapanos, Dodonë et ses ruins, Vol 1, (Paris 1878) 48-68.
73 Sotiros Dakaris, Organisation politique et urbanistique de la ville dans l`Epir antique, in
“L`Ylliri meridionale et l`Epir dans l`Atiquite I”, Actes du colloque de Clermont-Ferrand
(Adosa1987) 75.
74. Sotirios Dakaris, Dodona, (Athens 1998) 34.
75. Pierre Cabanes, Intervention, in Sotiros Dakaris, Organisation politique et urbanistique de la
ville dans l`Epir antique, in “L`Ylliri meridionale et l`Epir dans l`Atiquite I”, Actes du colloque
de Clermont-Ferrand, (Adosa1987) 80.
76. Sotirios Dakaris, Dodona, (Athens 1998) 20.
77. Sotirios Dakaris, Dodona, (Athens 1998) 30.
78. Pseudo-Scylax, Periplus, 26.
79. Strabo, Geographica, 7.7.11; Solinus, Collectanea Rerum Mirabilium, 7.3.
80. Eustathius, commentary on Homer, Z 12, H 11, in P. Aravantinos, Pragmateia peri Dodonis
(Ioannina, 1862) 37.
81. Pseudo-Scylax, Periplus, 26; Matthias-Petrus Katancic, Orbis antiques ex tabula
itineraria, quae Theodosi I Imperatoris et..., Vol.1, Evropa, (Mawman 1824) 636.
82. 82. M. le Baron de Witte, Description des statuettes...; M.E. Egger, Commentaire de six
inscriptions...; M. Leon Heuzey, Observations sur quelques objects..., in Constantin Carapanos,
Dodonë et ses ruins, Vol 1, (Paris 1878) 177- 240
83. Sotirios Dakaris, Dodona, (Athens 1998) 8.
84. Herbert William Parke “The oracles of Zeus: Dodona, Olympia, Ammon, (Havard University
Press, 1967) 259-273.
85. Homeri Odisea, 14. 327-330; Dionis Kasi ( Dionis Cassii) Historia Romana, fragmenta,
40.4.
86 Homeri Iliada 2. 748-750; Hierocles, Synecdemus, 651.5.
87. Sotiros Dakaris, Organisation politique et urbanistique de la ville dans l`Epir antique, in
“L`Ylliri meridionale et l`Epir dans l`Atiquite I”, Actes du colloque de Clermont-Ferrand
(Adosa1987) 75.
88. Encyclopedia Britanica, Vol.8, Dodona, (1911) 372.
89. Dionysius Halicarnassus 1. 51.1.
90. Pausanias, Description of Greece translation by W.H.S. Jones, (Cambridge, MA, Harvard
University Press; London, 1918) 1.17.5.
91. Constantin Carapanos, Dodone et ses ruines (Paris, 1878) 173.
92. Constantin Carapanos, Dodonë et ses ruins, Vol 1, (Paris 1878) 48-68.
93. Sotirios Dakaris, Dodona, (Athens 1998) 20-22; David Sacks, Oswyn Murray, A Dictionary
of the Ancient Greek World. Dodona, (Oxford University Press.1995). 115.
94. Sotirios Dakaris, Dodona, (Athens 1998) 21.
95. Chryseis Tzouvara-Souli, Common cults in Epirus and Albania, in “L`Ylliri meridionale et
l`Epir dans l`Atiquite-II, Clermont-Ferrand, (MAFEA, 1993) 73.
