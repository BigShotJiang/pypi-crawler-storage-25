## Summary
Introduce first-class support for externally supplied and owned scoped dependencies via:

1. `enter_scope(provided={...})` (public API)
2. `Provided[T]` annotation (public API)

This enables partial graph sharing across child scopes while preserving isolation for the rest of the scope graph.

---

## Motivation
Advanced workflows need to:

- create a child scope from root,
- reuse a small set of already-created objects (for example request DB session, request context),
- keep all other scoped/transient dependencies isolated in the child scope.

Today this exists through private seeding behavior, but not as a stable public contract.

---

## Proposed API

### Scope creation
```python
async with container.enter_scope(
    provided={
        Request: request,
        qualified(DbSession, "readonly"): readonly_session,
    }
) as scope:
    ...
```

- `provided` is keyword-only.
- Supported keys:
  - `Type`
  - qualified key helper (`qualified(Type, qualifier)`) or equivalent tuple form.

### Dependency annotation
```python
from wireup import Provided
from typing_extensions import Annotated
from wireup import Inject

def handler(
    req: Provided[Request],
    ro_db: Annotated[Provided[DbSession], Inject(qualifier="readonly")],
): ...
```

Semantics:
- `Provided[T]` must resolve from scope `provided` values.
- Wireup never creates `Provided[...]` values via factories.
- Missing value fails at runtime with a dedicated error.


### `inject_from_container` Interaction

`Provided[...]` should behave like any other Wireup injectable from the perspective of `inject_from_container`.

- Existing dependency discovery for injection annotations remains unchanged.
- `Provided[...]` parameters are still detected as injectable dependencies.
- Resolution semantics differ only at runtime:
  - inside a scope with `provided={...}`: values resolve normally.
  - if missing: fail with `MissingProvidedDependencyError`.
- `Provided[...]` is treated as a scoped dependency.

This means `inject_from_container` does not need a separate “provided mode.” It continues to use current injection detection and wrapper generation paths, while `Provided[...]` is enforced by normal container resolution behavior.

For request-time reuse scenarios, this composes naturally with:

```python
@wireup.inject_from_container(
    container,
    scoped_container_supplier=get_request_container,
)
def fn(dep: Provided[MyType]) -> None:
    ...
```

In this case, `Provided[...]` is read from the active scoped container the supplier returns.


---

## Important Semantics

### Scoped-only contract
`Provided[...]` is for scoped resolution only.

- Valid: scoped/transient paths resolved inside a scope.
- Invalid: singleton construction requiring `Provided[...]` (must error clearly).

### Runtime contract (not startup-presence validated)
Presence of `Provided[...]` values cannot be fully validated at container startup.

- Startup can validate graph/type metadata.
- Actual value presence is the responsibility of the code creating the scope (`enter_scope(provided=...)`).

### Ownership / cleanup
Provided values are externally owned.

- Child scope must not dispose/close provided values.
- Provider is fully responsible for cleanup/lifetime.

---

## Relationship to `wireup.instance(...)`
This feature is complementary to bootstrap-time instance registration:

- `wireup.instance(...)`: externally owned singleton-style registration at container creation.
- `Provided[...]` + `enter_scope(provided=...)`: externally supplied values at scope runtime for partial graph sharing.

---

## Error UX
Add dedicated error for missing provided values, e.g.:

- `MissingProvidedDependencyError(type=DbSession, qualifier="readonly")`

Error should include:
- missing key,
- current target being resolved,
- guidance to pass value via `enter_scope(provided=...)`.

---

### Additional Context: Autofac Parallels

This proposal aligns with established DI patterns from Autofac:

- Autofac supports child scopes (`BeginLifetimeScope(...)`) and per-scope instance registration (`RegisterInstance(...)`).
- Externally supplied values can be marked as externally owned (`ExternallyOwned()`), so the container does not dispose them.
- Missing dependencies are typically detected at resolve-time, not as full startup graph validation.

In Wireup terms, `enter_scope(provided=...)` + `Provided[T]` is a Pythonic equivalent:
- provide selected externally created values at child-scope creation,
- resolve the rest of the graph normally,
- keep ownership of provided instances with the caller.

## Implementation Notes (internal)
A practical internal approach is to represent `Provided[...]` via scoped “erroring factories” so existing registry/compiler/lifetime validation machinery is reused.

---

## Acceptance Criteria
- [ ] Public `enter_scope(*, provided=...)` on sync and async containers.
- [ ] `Provided[T]` annotation added.
- [ ] `Provided` + qualifier composition supported.
- [ ] Scoped-only behavior enforced with clear errors.
- [ ] Missing provided values fail fast with dedicated actionable error.
- [ ] Provided values are never cleaned up by child scope.
- [ ] Docs include:
  - partial graph sharing pattern,
  - ownership caveats,
  - runtime contract caveat.
- [ ] Tests cover sync/async, qualifiers, missing values, lifecycle/cleanup behavior, and lifetime rule enforcement.
