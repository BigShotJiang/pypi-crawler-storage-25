# Wireup Mapping Collection Injection API

This note evaluates a mapping-style collection injection feature for Wireup, grounded in Wireup's actual qualifier model and informed by how other DI systems handle collection and keyed injection.

The main question is:

- if Wireup adds mapping collection injection, should it include the `None`-qualified binding when one exists?

After revisiting the semantics carefully, I think the answer is yes.

## Executive Summary

Recommended public API:

- keep `collections.abc.Sequence[T]` as the canonical "all implementations" collection type
- add `collections.abc.Mapping[Hashable, T]` as the canonical keyed collection type
- keys should be the actual qualifier values
- if a `None`-qualified binding exists, it should appear under `None`
- do not introduce a sentinel such as `DEFAULT`
- do not add a separate `default=True` concept

Recommended semantics:

- plain `T` is sugar for `Annotated[T, Inject(qualifier=None)]`
- `Sequence[T]` means all bindings for `T`
- `Mapping[Hashable, T]` means all bindings for `T`, keyed by qualifier

That gives Wireup one consistent model instead of a "real semantics plus special collection rule" split.

## The Key Clarification

The most important clarification is this:

- Wireup does not require a `None`-qualified binding to exist
- users can qualify every implementation if they want
- plain `T` works only when a `None`-qualified binding exists
- omitting `qualifier=` is API sugar, not a distinct registration category

That means the `None` binding is not a special object from the container's point of view. It is just one binding in the qualifier space, with the ergonomic benefit that plain `T` can target it.

Once that is true, excluding it from a qualifier-keyed collection becomes hard to justify.

## Wireup's Real Model

The cleanest description of Wireup's semantics is:

- qualifiers are the identity space for bindings
- qualifiers can be any hashable value
- `None` is one valid qualifier value
- plain `T` is shorthand for requesting the `None`-qualified binding

So these should all be understood as part of the same model:

```python
Annotated[Cache, Inject(qualifier="redis")]
Annotated[Cache, Inject(qualifier=CacheType.REDIS)]
Annotated[Cache, Inject(qualifier=None)]
Cache  # sugar for qualifier=None
```

That framing matters because it makes the mapping decision much simpler:

- if the map is keyed by qualifier, the `None`-qualified binding belongs in it
- if it does not appear, the map is no longer a full keyed view of the binding set

## The Semantic Goal

Wireup should avoid an API where the public collection type suggests one thing but runtime behavior quietly does another.

This is especially important here, because the user can reasonably infer that:

```python
Mapping[Hashable, T]
```

means:

- "give me the `T` bindings, keyed by qualifier"

If one real qualifier is omitted, that inference becomes false.

So the most truthful public contract is:

- `Sequence[T]` = all `T` bindings
- `Mapping[Hashable, T]` = the same set, but keyed by qualifier

## Recommendation In Concrete API Terms

Recommended collection type:

```python
from collections.abc import Hashable, Mapping

handlers: Mapping[Hashable, Handler]
```

Recommended behavior:

- include every registered binding for `T`
- use the exact qualifier values as keys
- include `None` if a `None`-qualified binding exists
- preserve qualifier uniqueness
- keep registration order for iteration if order is exposed

Example:

```python
@injectable(as_type=Cache)
class InMemoryCache: ...


@injectable(as_type=Cache, qualifier="redis")
class RedisCache: ...


@injectable
class CacheRegistry:
    def __init__(self, caches: Mapping[Hashable, Cache]) -> None:
        self.caches = caches
```

The resulting mapping should be equivalent to:

```python
{
    None: InMemoryCache(...),
    "redis": RedisCache(...),
}
```

If there is no `None`-qualified binding, there should simply be no `None` key.

## Why `Mapping[Hashable, T]` Is The Right Shape

Wireup already teaches that qualifiers are not limited to strings. Users can use enums and other hashable values.

That means the public keyed collection type should directly reflect the actual qualifier model:

- it should use the real qualifier values as keys
- it should support enums, ints, bools, classes, and other hashable keys naturally
- it should avoid inventing a parallel naming system
- it should make it clear that key identity is whatever qualifier identity is

This is one of those cases where honesty matters more than prettiness.

## Include `None` vs Exclude `None`

This is the real decision.

### Option A: Include `None`

Meaning:

- `Mapping[Hashable, T]` contains every binding for `T`, keyed by qualifier
- if the `None`-qualified binding exists, it appears under `None`

Pros:

- semantically pure
- no hidden omission
- matches the actual qualifier model exactly
- symmetric with `Sequence[T]`
- easier to explain: "all bindings keyed by qualifier"
- better for introspection, tooling, and debugging because the map is complete
- avoids a special rule that users have to memorize

Cons:

- `mapping[None]` is a little awkward to look at
- some users may initially read `None` as "special framework value" rather than "the `None` qualifier"
- iterating keys can feel slightly less tidy if some users mostly think in explicitly named variants

### Option B: Exclude `None`

Meaning:

- `Mapping[Hashable, T]` contains only explicitly-qualified bindings
- the `None` binding, if present, is omitted

Pros:

- cleaner-looking iteration for users who want explicit variants only
- avoids the mild aesthetic weirdness of `mapping[None]`
- can feel convenient for "show me the named alternatives" use cases

Cons:

- the map is no longer complete
- one real binding is omitted arbitrarily
- the omission is hard to justify if `None` is truly just another qualifier
- creates a semantic split between container truth and collection truth
- forces an extra rule into the docs
- makes the collection type look exhaustive while actually being filtered

## The Alternative: Separate `default=True`

There is one design where excluding the `None` case would feel much more coherent:

```python
@injectable(as_type=Cache, qualifier="redis", default=True)
class RedisCache: ...
```

In that model:

- `qualifier` answers "what key identifies this binding?"
- `default=True` answers "what should plain `T` resolve to?"

That separates identity from selection policy.

Under such a model, a qualifier-keyed map could more plausibly exclude "the default" because default would no longer be encoded as `None`. It would be orthogonal metadata attached to one binding.

So this is the strongest version of the argument for excluding the `None` case: make default-ness a separate concept entirely.

## Why I Still Would Not Add `default=True`

Even though `default=True` would make exclusion more defensible, it does not look like a good trade for Wireup.

Wireup's API appeal comes from being relatively small, coherent, and powerful without a large pile of markers. Compared to many DI libraries, it feels minimal while still covering the real use cases.

Adding `default=True` pushes in the opposite direction. It creates a second axis of meaning where one concept already does the job:

- qualifier identity
- plus a separate "selected as default" marker

That might make one edge of collection injection look smoother, but it makes the whole model larger.

It also opens a lot of policy and validation questions:

- does everything need `@injectable(default=True)` if plain `T` should work?
- if only one implementation exists, is it automatically inferred as default?
- if yes, what happens when a second implementation is later added?
- if no, why did direct `T` injection stop working until a marker was added?
- can a qualified binding be the default?
- can an unqualified binding be non-default?
- can there be zero defaults?
- can there be more than one default?
- what error should users get if several implementations exist but no default is marked?

That is a lot of extra machinery for a fairly modest payoff.

And the actual payoff is not very large. The main thing `default=True` really buys is avoiding the slight awkwardness of `mapping[None]` and allowing "qualified but also default" without using `None` as the direct-injection target.

Those are real differences, but they do not feel important enough to justify the additional API surface, docs burden, and validation rules.

So the question becomes:

- more machinery for what actual gain?

I do not think there is enough gain.

Using `None` as the default remains the better design because it keeps the model smaller and more coherent:

- one axis, not two
- no extra marker
- no extra inference rules
- no extra validation concept
- plain `T` works exactly when a `None` binding exists
- keyed collections can faithfully reflect the real qualifier space

In other words, `default=True` mostly solves the cosmetic discomfort of `None` appearing in a map, but at the cost of making the whole DI model more complicated.

That is a bad trade.

## Why I Recommend Including `None`

The strongest reason is that exclusion would be arbitrary.

If the model is:

- all bindings are identified by qualifier
- `None` is one qualifier
- a `None`-qualified binding may or may not exist
- plain `T` is just sugar for requesting that binding

then there is no principled reason for a qualifier-keyed map to hide it.

Excluding `None` would create this shape:

- `Sequence[T]` contains all bindings
- `Mapping[Hashable, T]` contains all bindings except one
- plain `T` is sugar for the omitted one

That is exactly the sort of "API suggests one thing, runtime means another" mismatch Wireup should avoid.

Including `None` gives a much simpler story:

- `Sequence[T]` = all bindings
- `Mapping[Hashable, T]` = all bindings keyed by qualifier
- plain `T` = request the `None` key directly, via sugar

That is clean enough that the mild awkwardness of `mapping[None]` feels like a small price to pay.

## Why A Sentinel Like `DEFAULT` Is Still A Bad Idea

Even if `None` is slightly awkward, a sentinel would be worse.

Reasons:

- it invents a new public concept that is not part of the real qualifier model
- it makes the keyspace artificial
- it teaches users that the map is not actually keyed by qualifiers, but by "qualifiers plus a special library token"
- it separates plain `T` from the actual qualifier identity the container uses

If `None` is the qualifier, the map should show `None`.

## Cross-Ecosystem Comparison

The comparison is useful, but the answer still has to come from Wireup's own semantics.

### Spring

Spring supports map injection keyed by bean name. That works because bean names are a first-class part of Spring's identity model.

This is not the right model for Wireup. Wireup's identity concept is qualifier values, not bean names.

Source:  
https://docs.spring.io/spring-framework/reference/core/beans/annotation-config/autowired.html

### ASP.NET Core

Standard .NET DI gives a useful reference point for separating:

- single resolution
- `IEnumerable<T>` for all registrations
- keyed resolution as a distinct concept

It is less useful as a direct template for map injection, because standard .NET does not really expose a canonical keyed collection injection API equivalent to the one under discussion here.

Source:  
https://learn.microsoft.com/en-us/aspnet/core/fundamentals/dependency-injection

### Autofac

Autofac is a much closer comparison. It treats keyed services as an explicit identity space and supports non-string keys. That is a much better conceptual match for Wireup than Spring's bean-name map.

The important lesson here is not to copy Autofac mechanically, but to notice the shared premise:

- keyed services are keyed by the actual identity values, not by an invented parallel naming scheme

Source:  
https://docs.autofac.org/en/latest/advanced/keyed-services.html

### Guice and Dagger

Guice and Dagger also reinforce a helpful general pattern:

- collection injection and keyed multibindings are separate concepts
- keyed maps are typed by their actual keys
- uniqueness matters

That is directionally consistent with Wireup using a real qualifier-keyed mapping instead of stringifying qualifiers or inventing pseudo-keys.

Sources:  
https://github.com/google/guice/wiki/Multibindings  
https://google.github.io/guice/api-docs/3.0/javadoc/com/google/inject/multibindings/MapBinder.html  
https://dagger.dev/dev-guide/multibindings.html

### Dependency Injector

Dependency Injector's explicit `Dict` provider is another reminder that Python DI does not require string keys for dict-like dependency structures. Non-string keys are normal when the model calls for them.

Source:  
https://python-dependency-injector.ets-labs.org/providers/dict.html

## The Cleanest User Story

I think this is the best public explanation Wireup can offer:

- use `T` when you want the `None`-qualified binding
- use `Annotated[T, Inject(qualifier=q)]` when you want a specific qualifier
- use `Sequence[T]` when you want every binding for `T`
- use `Mapping[Hashable, T]` when you want every binding for `T`, keyed by qualifier

That story has no special exceptions.

It also scales nicely to the "all implementations are qualified" case:

- plain `T` fails because there is no `None` binding
- `Sequence[T]` still works
- `Mapping[Hashable, T]` still works

That is exactly what users would expect from a consistent qualifier model.

It also avoids a particularly weird split where:

- direct `T` injection stops working when there is no `None`-qualified implementation
- but the keyed collection would still arbitrarily hide the `None` case when it does exist

Including `None` keeps those behaviors aligned. If the `None` binding exists, it is visible everywhere it should be visible. If it does not exist, plain `T` fails and the keyed collection has no `None` key.

That is simple and trustworthy.

## Why This Fits Wireup's Design Taste

One of Wireup's strengths is that its API surface is relatively small and coherent without a large number of markers or special cases. It is not necessarily tiny, but compared to many DI libraries it is fairly minimal while still being powerful.

That is worth protecting.

A lot of DI systems slowly lose their clarity by accreting just one more marker:

- one for named services
- one for primary/default
- one for qualifiers
- one for collection groups
- one for special selection behavior

Wireup should resist that unless the new concept unlocks something truly valuable.

Here, a faithful `Mapping[Hashable, T]` keyed by real qualifiers preserves the minimal core:

- `@injectable`
- `as_type=...`
- `qualifier=...`
- `Inject(...)`
- collection injection through normal Python collection ABCs

That is a strong shape. Users can keep most of the model in their head.

Adding `default=True`, sentinels, or exclusion rules would make the feature matrix look more polished in one corner while making the overall system less crisp.

Sometimes a slightly awkward edge is a sign that the abstraction is honest. Trying to sand it away with extra API often makes the whole thing worse.

So the design principle here is:

- prefer one small coherent model over a smoother-looking feature matrix

For this feature, that points to:

- no `default=True`
- no sentinel
- no exclusion rule for `None`
- just `Mapping[Hashable, T]` keyed by actual qualifiers

## Suggested Documentation Language

If this feature is added, the docs should say it plainly:

> Use `collections.abc.Sequence[T]` to inject all bindings for `T`.
> Use `collections.abc.Mapping[Hashable, T]` to inject all bindings for `T`, keyed by qualifier.
> Plain `T` is shorthand for the `None` qualifier, so if a `None`-qualified binding exists it appears in the mapping under `None`.

That is slightly blunt, but it is very hard to misunderstand.

## Final Recommendation

I recommend that Wireup adopt:

```python
collections.abc.Mapping[Hashable, T]
```

with these semantics:

- it contains all bindings for `T`
- keys are the exact qualifier values
- it includes the `None` key when a `None`-qualified binding exists
- it excludes nothing
- it does not use a sentinel
- it does not add a separate default marker

This gives Wireup one unified model:

- qualifier space is the real identity space
- plain `T` is sugar for `qualifier=None`
- `Sequence[T]` is the all-bindings view
- `Mapping[Hashable, T]` is the keyed all-bindings view

That is the design I would ship.
