# Config / Qualified type sugar

Question: should Wireup support this API shape:

```python
foo: Config[str, "db.host"]
redis_cache: Qualified[Cache, "redis"]
```

instead of the current:

```python
from typing import Annotated

foo: Annotated[str, Inject(config="db.host")]
redis_cache: Annotated[Cache, Inject(qualifier="redis")]
```

## Short answer

It looks nicer, and it is implementable as runtime sugar, but it is probably worse as the primary public API.

## Why it is feasible

Wireup already discovers injection metadata by unwrapping `Annotated[...]` layers and collecting `InjectableType` metadata from them.

That means `Config[...]` and `Qualified[...]` can be implemented as desugaring helpers:

```python
class Config:
    def __class_getitem__(cls, params):
        typ, key = params
        return Annotated[typ, Inject(config=key)]


class Qualified:
    def __class_getitem__(cls, params):
        typ, qualifier = params
        return Annotated[typ, Inject(qualifier=qualifier)]
```

In other words, the runtime/container model does not need to change much. This is mostly API sugar.

## What is better about it

- Shorter syntax.
- Reads semantically at a glance.
- Makes the common cases feel more first-class than `Inject(...)`.
- Avoids repeating `Annotated[..., Inject(...)]` for config and qualifiers.

## What is worse about it

- It pushes against Python's typing model.
- `Config[str, "db.host"]` uses a value-looking argument where users expect type arguments.
- Type checkers do not like the bare string form.
- The type-checker-friendly version would likely be:

```python
foo: Config[str, Literal["db.host"]]
```

and that is harder to read than the current API.

- Dynamic keys/qualifiers become awkward. `Inject(config=key)` is explicit and honest about being runtime metadata.
- It creates a second public syntax for the same concept, which increases docs, examples, support burden, and migration surface.

## Important practical finding

Runtime behavior is easy to prototype.

Type-checking is the real problem:

- `Config[str, "db.host"]` is not a normal generic use in the eyes of static type checkers.
- Mypy rejects the bare string form.
- Even if runtime desugaring works, editor and checker support would likely feel inconsistent.

## Recommendation

Do not replace the current API with this shape.

Possible paths:

1. Keep the current API as the canonical one.
2. Optionally add `Config[...]` / `Qualified[...]` as experimental runtime sugar only.
3. Prefer a more type-checker-friendly cleanup if we want nicer names, for example:

```python
foo: Annotated[str, Config("db.host")]
redis_cache: Annotated[Cache, Qualified("redis")]
```

That keeps `Annotated[...]` as the type-system boundary while making the metadata names more readable.

## Current opinion

`Config[str, "db.host"]` and `Qualified[Cache, "redis"]` are attractive on first read, but they likely trade away too much type-system clarity for the amount of ergonomic gain they provide.

Good experimental sugar, weak primary API.
