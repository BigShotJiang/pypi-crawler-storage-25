## `wrap_with_dependencies`

Idea for a small helper that lets normal Python decorators receive Wireup-managed dependencies when the wrapped
function is executed by Wireup.

### Core idea

The helper would be used inside a decorator and would behave similarly to `functools.wraps`, but it would also patch the
wrapper signature so Wireup can see:

- the original function parameters
- the extra injected parameters declared on the wrapper

Example:

```python
def log_duration(fn):
    @wrap_with_dependencies(fn)
    async def wrapped(
        *args,
        ctx: Injected[RequestContext],
        logger: Injected[Logger],
        **kwargs,
    ):
        start = time.perf_counter()
        try:
            return await fn(*args, **kwargs)
        finally:
            logger.info("done", extra={"request_id": ctx.request_id})

    return wrapped
```

### Important constraint

Wrapper-added parameters must not reuse names already present on the callable being wrapped.

That means:

- collisions with original function parameters are an error
- collisions with parameters introduced by an earlier decorator are also an error

This keeps stacking simple. The helper does not need special logic for decorator stacks. It only needs to compare the
current callable signature with the wrapper signature and reject overlapping names.

### Why this is interesting

- Keeps cross-cutting concerns in normal Python decorators.
- Lets decorators become DI-aware without introducing a Wireup-specific decorator DSL.
- Works anywhere Wireup is already responsible for injecting dependencies.
- Keeps decorators more unit-testable than framework-specific injection decorators that depend on request-local state.

### Positioning

This should stay a small advanced utility, not the start of a larger decorator/AOP feature set.

Good framing:

- normal decorators that can receive injected dependencies
- useful for logging, metrics, auth, feature flags, and similar wrappers
- only meaningful when Wireup is invoking the wrapped function

Bad framing:

- Wireup now owns cross-cutting concerns
- built-in transactional/cached/logged decorators
- a general-purpose interceptor system

### Comparison with framework-specific decorators

Framework decorators like `@inject` in some integrations usually depend on an active scoped container or request-local
state. That often makes them harder to unit test outside the framework runtime.

This idea is different:

- the decorator remains normal Python
- it only becomes DI-aware when Wireup is actually calling the function
- on non-Wireup functions it should behave like a normal wrapper and not try to do anything special
