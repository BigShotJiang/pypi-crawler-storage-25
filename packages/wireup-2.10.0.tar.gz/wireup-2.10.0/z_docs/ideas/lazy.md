## Summary
Introduce first-class lazy dependency wrappers via:

1. `Lazy[T]`
2. `AsyncLazy[T]`

Potentially backed by a more fundamental typed-provider abstraction:

3. `Provider[T]`
4. `AsyncProvider[T]`

These wrappers defer resolution until first use while preserving the lifetime and scope semantics of the wrapped
dependency `T`.

The main target is orchestration-style code that depends on many possible handlers/controllers/services but only uses
one or a few of them for a given request.

---

## Motivation
Today Wireup eagerly resolves all annotated dependencies before invoking:

- injected functions and handlers
- injectable class constructors
- injectable factories

That is usually the right default, but it is wasteful for branchy consumers such as:

```python
class Orchestrator:
    def __init__(
        self,
        c1: Provider[Controller1],
        c2: Provider[Controller2],
        c3: Provider[Controller3],
    ) -> None:
        self.c1 = c1
        self.c2 = c2
        self.c3 = c3

    async def handle(self, payload: Payload) -> None:
        match payload.kind:
            case "a":
                await self.c1().handle(payload)
            case "b":
                await self.c2().handle(payload)
            case "c":
                await self.c3().handle(payload)
```

Without laziness, constructing `Orchestrator` would also construct `Controller1`, `Controller2`, and `Controller3`
even when only one branch is used.

---

## Proposed API

### Possible layering
There are two plausible public shapes:

1. expose `Lazy[T]` / `AsyncLazy[T]` directly as first-class primitives
2. expose `Provider[T]` / `AsyncProvider[T]` as the primitive, and define lazy wrappers on top

The second option may be cleaner if open generics land first.

### Public types
```python
from wireup import AsyncLazy, AsyncProvider, Injected, Lazy, Provider
```

```python
class Provider[T]:
    def get(self) -> T: ...


class AsyncProvider[T]:
    async def get(self) -> T: ...


class Lazy[T]:
    def get(self) -> T: ...


class AsyncLazy[T]:
    async def get(self) -> T: ...
```

### Example
```python
class Orchestrator:
    def __init__(
        self,
        controller_1: Injected[Lazy[Controller1]],
        controller_2: Injected[AsyncLazy[Controller2]],
    ) -> None:
        self._controller_1 = controller_1
        self._controller_2 = controller_2

    async def process_payload(self, payload: Payload) -> None:
        if payload.type == "type_1":
            await self._controller_1.get().handle(payload)
        elif payload.type == "type_2":
            await (await self._controller_2.get()).handle(payload)
```

Notes:

- `Provider[T]` / `AsyncProvider[T]` defer resolution but do not add memoization.
- `Lazy[T]` is for sync resolution.
- `AsyncLazy[T]` is for async resolution.
- Plain `Injected[T]` keeps current eager behavior.

### Provider-first alternative
If providers become the primitive, then lazy can be layered on top:

```python
class Lazy[T]:
    def __init__(self, provider: Provider[T]) -> None:
        self._provider = provider

    def get(self) -> T:
        return self._provider.get()
```

```python
class AsyncLazy[T]:
    def __init__(self, provider: AsyncProvider[T]) -> None:
        self._provider = provider

    async def get(self) -> T:
        return await self._provider.get()
```

This makes `Provider[T]` the true container-level abstraction and lets `Lazy[T]` stay a small user-facing wrapper.

---

## Why `get()` Instead Of A Proxy
The lazy wrapper should be explicit rather than pretending to be `T`.

Recommended shape:

- `Lazy[T].get() -> T`
- `AsyncLazy[T].get() -> Awaitable[T]`

Reasons:

- It makes the deferred work obvious at the call site.
- It avoids magic attribute access, implicit initialization, and confusing debugging behavior.
- It keeps async ergonomics straightforward.
- It preserves a clean type distinction between the wrapper and the wrapped dependency.

Avoid:

- transparent proxy behavior
- implicit `.__getattr__` forwarding
- `.value` as the primary API

`.value` looks too much like a cheap field read. `.get()` signals that resolution work may happen.

---

## Key Semantic Requirement
Deferred resolution must change initialization timing only.

It must not change:

- the lifetime semantics of `T`
- the scope in which `T` is resolved
- whether `T` is valid in a given dependency graph

This is the most important design constraint.

### Resolution context
`Provider[T]`, `AsyncProvider[T]`, `Lazy[T]`, and `AsyncLazy[T]` should resolve against the current scoped container
instance they were created with.

This gives the right behavior automatically:

- singleton `T`: the scoped container looks up from root and returns the singleton
- scoped `T`: the current scope owns and caches the instance
- transient `T`: the current scope resolves a new instance each time according to normal transient rules

### Provider semantics
`Provider[T]` and `AsyncProvider[T]` should not cache independently of the container.

If the provider cached on its own:

- `Provider[TransientDep]` would stop behaving like a transient
- the provider would introduce new lifetime semantics not present in the container

Instead, `get()` should delegate to normal container resolution every time, and the container's lifetime rules decide
whether the same instance or a new one is returned.

This means:

- singleton stays singleton
- scoped stays scoped
- transient stays transient

### Lazy memoization policy
If `Lazy[T]` is layered on top of `Provider[T]`, there are two valid designs:

1. `Lazy[T]` is just a naming/ergonomics wrapper around `Provider[T]` and does not memoize
2. `Lazy[T]` memoizes only when doing so does not violate lifetime semantics

The second option is tricky because wrapper-level memoization can easily distort transient behavior.

For that reason, the safest first version is:

- `Provider[T]` / `AsyncProvider[T]` are the core primitive
- `Lazy[T]` / `AsyncLazy[T]` are either aliases or very thin wrappers with the same no-extra-caching semantics

If true memoizing lazy behavior is still wanted later, it should be designed explicitly with careful lifetime rules.

---

## Validation Rules
Wireup should fail early and clearly when lazy wrappers are used incorrectly.

### Factory shape validation
- `Provider[T]` is valid only when `T` is produced synchronously.
- `AsyncProvider[T]` is valid only when `T` is produced asynchronously.
- `Lazy[T]` is valid only when `T` is produced synchronously.
- `AsyncLazy[T]` is valid only when `T` is produced asynchronously.

This should be checked during registry validation, not deferred to runtime.

Examples:

- `Lazy[Foo]` where `Foo` is created by an async factory: startup error
- `AsyncLazy[Foo]` where `Foo` is created by a sync factory: startup error
- `Provider[Foo]` where `Foo` is created by an async factory: startup error
- `AsyncProvider[Foo]` where `Foo` is created by a sync factory: startup error

Being strict here keeps the API simple:

- `Provider[T]` and `Lazy[T]` mean sync resolution
- `AsyncProvider[T]` and `AsyncLazy[T]` mean async resolution

### Lifetime validation
Lifetime validation should treat `Provider[T]`, `AsyncProvider[T]`, `Lazy[T]`, and `AsyncLazy[T]` exactly as if the
dependency were `T`.

Examples:

- singleton depending on `Lazy[ScopedDep]`: invalid
- singleton depending on `AsyncLazy[TransientDep]`: invalid
- singleton depending on `Provider[ScopedDep]`: invalid
- singleton depending on `AsyncProvider[TransientDep]`: invalid

This preserves current Wireup guarantees that a singleton may only depend on singletons.

### Scope mismatch behavior
Root-container resolution rules remain unchanged.

Examples:

- resolving `Lazy[ScopedDep]` from a root-only context should fail when `get()` is called
- injecting `Lazy[ScopedDep]` into a function that already required a scope should work normally

---

## Open Generics Relationship
Open generics may be the cleanest way to implement typed providers, and providers may in turn be the cleanest way to
implement lazy access.

### Strongest generic use case
`Provider[T]` and `AsyncProvider[T]` are a particularly strong fit for open generics:

- they are ordinary typed wrappers around "resolve `T` later"
- they do not need special public syntax
- they map naturally to a generic registration story

Once providers exist, `Lazy[T]` may be implementable as normal Python on top of them.

### What open generics help with
They allow `Provider[T]`, `AsyncProvider[T]`, `Lazy[T]`, and `AsyncLazy[T]` to be expressed as ordinary DI
abstractions rather than new `Inject(...)` syntax or dedicated annotation flags.

That is good because:

- the API stays explicit in the type system
- `Lazy[T]` reads like a normal dependency
- the same machinery may later support other generic wrappers

### What open generics do not solve on their own
Even if `Provider[T]` is an open generic registration, the container still needs to:

- create the wrapper bound to the current scope/container
- validate the wrapped dependency `T`
- preserve `T`'s lifetime semantics

That means open generics can remove lazy-specific surface syntax without fully removing runtime/container involvement.

A better framing is:

- open generics provide the registration and typing model
- provider objects provide the user-facing deferred-resolution abstraction
- container/runtime support preserves correctness

---

## Internal Representation Options

### Option A: special-case `Lazy` and `AsyncLazy`
Teach type analysis, validation, and resolution about these two wrappers directly.

Pros:

- likely the smallest path to shipping the feature
- easy to keep validation precise
- no dependency on a broader open-generics implementation

Cons:

- introduces a one-off special feature
- less reusable if more generic wrappers appear later

### Option B: provider-first via open generics
Treat `Provider[T]` and `AsyncProvider[T]` as open generic registrations backed by synthetic factories, and layer lazy
wrappers on top.

Pros:

- cleaner long-term architecture
- better story for future wrappers
- `Provider[T]` maps naturally to existing DI patterns in other ecosystems
- `Lazy[T]` may become ordinary Python rather than a container primitive

Cons:

- blocked on open generics work
- still needs runtime support for scope binding and validation
- true memoizing lazy semantics remain a separate design choice

### Recommendation
If lazy resolution is wanted before open generics ship, special-case it first.

If open generics are landing soon, strongly consider making `Provider[T]` / `AsyncProvider[T]` the real primitive and
defining `Lazy[T]` in terms of that.

---

## Implementation Sketch
This section assumes the current Wireup internals:

- parameter parsing in `wireup.ioc.util.param_get_annotation`
- dependency metadata in `wireup.ioc.types.AnnotatedParameter`
- injectable dependency discovery in `wireup.ioc.dependency_introspection`
- validation in `wireup.ioc.registry_validation`
- eager function injection codegen in `wireup._wrapper_compiler`
- eager injectable factory compilation in `wireup.ioc.factory_compiler`

### 1. Add public wrapper types
Introduce:

- `Provider`
- `AsyncProvider`
- optionally `Lazy`
- optionally `AsyncLazy`

as generic public classes exported from `wireup.__init__`.

The most flexible version is provider-first.

Example internal shape:

```python
class Provider[T]:
    def __init__(self, getter: Callable[[], T]) -> None:
        self._getter = getter

    def get(self) -> T:
        return self._getter()


class AsyncProvider[T]:
    def __init__(self, getter: Callable[[], Awaitable[T]]) -> None:
        self._getter = getter

    async def get(self) -> T:
        return await self._getter()
```

`Lazy` and `AsyncLazy` can then wrap providers if still desired.

### 2. Extend type analysis
Teach type analysis to detect:

- plain dependency `T`
- provider dependency `Provider[T]`
- async-provider dependency `AsyncProvider[T]`
- lazy dependency `Lazy[T]`
- async-lazy dependency `AsyncLazy[T]`

The wrapped inner type `T` should become the effective dependency key for lifetime and registry validation.

This could be represented in `AnnotatedParameter` as:

```python
is_lazy: bool
is_async_lazy: bool
```

or a single mode enum.

### 3. Dependency introspection
Constructor/factory dependency discovery should record lazy metadata without treating the wrapper type itself as the
dependency to validate.

That means the container should understand:

- parameter type is `Lazy[Foo]`
- actual target dependency is `Foo`
- resolution mode is lazy-sync

### 4. Validation
Validation should:

- verify `Foo` exists
- verify `Lazy` vs `AsyncLazy` matches the asyncness of `Foo`'s factory
- apply lifetime validation against `Foo`, not against the wrapper

This likely means updating:

- `assert_dependency_exists(...)`
- `assert_lifetime_valid(...)`
- cycle/path checks where relevant

### 5. Function injection codegen
Current wrapper compilation eagerly resolves all dependencies before calling the target.

For deferred parameters, it should instead inject a wrapper object bound to `scope`.

Conceptually:

```python
kwargs["svc"] = Provider(lambda: scope._synchronous_get(Service))
kwargs["async_svc"] = AsyncProvider(lambda: scope.get(AsyncService))
```

When container-specific optimizations are available, the generated wrapper can still use precompiled factories.

Example:

```python
kwargs["svc"] = Provider(lambda: _wireup_singleton_factories[obj_id].factory(scope))
```

If `Lazy` remains a public type, it can be produced either directly or by wrapping the provider.

The key difference is that resolution moves inside the provider/lazy wrapper instead of happening eagerly inside
generated code.

### 6. Injectable factory compilation
Class construction and injectable factory execution must support lazy dependencies too.

Today compiled factories eagerly construct dependency kwargs before calling the underlying constructor/factory.

For deferred dependencies, compiled factories should instead pass wrapper instances that resolve against the current
container argument.

Conceptually:

```python
instance = ORIGINAL_FACTORY(
    controller=Provider(lambda: factories[controller_obj_id].factory(container))
)
```

This is necessary for the orchestrator use case, because the orchestrator itself is typically created as an injectable,
not only as an injected function argument.

### 7. Error messages
Add explicit errors for:

- using `Lazy[T]` for an async-produced `T`
- using `AsyncLazy[T]` for a sync-produced `T`
- invalid lifetime relationships involving lazy wrappers

Error text should explain that laziness defers resolution but does not relax lifetime or scope rules.

---

## Example Validation Matrix

| Consumer dependency          | `T` factory | Valid | Notes |
| ---------------------------- | ----------- | ----- | ----- |
| `Injected[T]`                | sync        | yes   | current behavior |
| `Injected[T]`                | async       | yes   | current behavior where allowed |
| `Injected[Provider[T]]`      | sync        | yes   | deferred sync resolution |
| `Injected[Provider[T]]`      | async       | no    | wrong wrapper kind |
| `Injected[AsyncProvider[T]]` | sync        | no    | wrong wrapper kind |
| `Injected[AsyncProvider[T]]` | async       | yes   | deferred async resolution |
| `Injected[Lazy[T]]`          | sync        | yes   | if exposed directly |
| `Injected[Lazy[T]]`          | async       | no    | wrong wrapper kind |
| `Injected[AsyncLazy[T]]`     | sync        | no    | wrong wrapper kind |
| `Injected[AsyncLazy[T]]`     | async       | yes   | if exposed directly |

---

## Acceptance Criteria
- [ ] Public `Provider[T]` and `AsyncProvider[T]` APIs added, or a documented decision to special-case lazy directly.
- [ ] Public `Lazy[T]` and `AsyncLazy[T]` APIs added if they remain part of the public surface.
- [ ] Explicit `.get()` API used instead of proxy behavior.
- [ ] Deferred-resolution wrappers resolve against the current scope/container they were created with.
- [ ] `Provider[T]` / `AsyncProvider[T]` do not add memoization beyond normal container lifetime behavior.
- [ ] Deferred-resolution wrappers are supported in both function injection and injectable constructors/factories.
- [ ] Startup validation rejects wrapper/factory asyncness mismatches.
- [ ] Lifetime validation for provider/lazy wrappers matches the wrapped dependency `T`.
- [ ] Error messages explain that deferred resolution changes timing, not scope or lifetime semantics.
- [ ] Tests cover singleton/scoped/transient behavior, async mismatch errors, qualifiers, and orchestrator-style usage.
