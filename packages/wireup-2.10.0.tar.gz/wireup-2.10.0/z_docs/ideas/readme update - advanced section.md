## Advanced Wiring

Wireup supports several advanced injection patterns for complex scenarios:

- **`Provider[T]` / `AsyncProvider[T]`** — Lazy/deferred resolution. Useful for expensive dependencies, optional branches, or breaking circular dependencies.
- **`Sequence[T]`** — Inject all registered implementations of `T` in registration order.
- **`Mapping[Hashable, T]`** — Inject all implementations keyed by qualifier (`None` for the default/unqualified implementation).
- **Container self-injection** — Depend on the container itself when you need dynamic resolution.
- **Scoped container injection** — Scoped/transient dependencies can inject the active scoped container directly.
- **Explicit scope seeding** — Pass pre-built instances into a new scope at creation time. Covers fan-out, sub-request isolation, and hierarchical tenancy without arbitrary nesting.

Wireup uses isolated scopes with explicit context sharing. The three lifetimes plus scope seeding cover fan-out, sub-request isolation, and hierarchical tenancy — without the complexity of arbitrary nesting. See [Scopes](docs/scopes.md) for details.