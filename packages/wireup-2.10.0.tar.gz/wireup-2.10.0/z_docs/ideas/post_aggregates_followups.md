# Post-Aggregates Follow-Ups

This note captures the main feature ideas that felt genuinely useful while discussing the new container self-injection
work. The goal is not to do these now, but to have a clean list to revisit after aggregates land.

## Suggested Priority

### 1. Typed providers / lazy access

Likely the strongest missing "advanced container" feature after aggregates.

Useful shapes:

- `Provider[T]`
- `Lazy[T]`
- possibly `Callable[[], T]` as sugar or an internal equivalent

What they solve:

- defer creation of expensive dependencies until actually needed
- inject "how to get T later" instead of injecting the whole container
- allow runtime/conditional access without falling back to service-locator patterns
- make infra helpers narrower and more type-directed than `AsyncContainer` / `SyncContainer`

Suggested implementation direction:

- implement using synthetic factories in [registry.py](/home/aldo/Projects/wireup/wireup/ioc/registry.py), similar to
  other derived registrations already handled there
- `Provider[T]` should respect normal Wireup lifetime semantics:
  - singleton => same object
  - scoped => current scoped object
  - transient => fresh object per access
- `Lazy[T]` should probably be a thin memoizing wrapper around `Provider[T]`

Important constraint:

- do not let providers become a loophole that bypasses lifetime rules. A singleton depending on
  `Provider[ScopedThing]` should be an intentional decision, not an accidental way around scope validation.

Patterns already exist elsewhere:

- `dependency_injector` (Python):
  - explicit provider system
  - `Factory`, `Singleton`, `Callable`
  - provider delegation via `.provider`
- Spring:
  - `ObjectFactory<T>`
  - `ObjectProvider<T>`
- Guice / JSR-330:
  - `Provider<T>`
- Dagger:
  - `Provider<T>`
  - `Lazy<T>`
  - assisted factories for runtime-parameter cases

Rough conceptual mapping:

- `Provider[T]` => resolve `T` later, respecting container lifetime semantics
- `Lazy[T]` => resolve `T` later and memoize the first resolved value
- `Factory[T]` => usually implies "produce on demand", often most natural for transient-like objects

For Wireup specifically, `Provider[T]` still feels like the best primary abstraction because it matches lifetimes
cleanly. `Factory[T]` can be layered on top later if a stronger "fresh instance" semantic is useful.

### 2. Scoped self-injection

Root self-injection landed well. The natural follow-up is scoped self-injection:

- `Injected[wireup.ScopedSyncContainer]`
- `Injected[wireup.ScopedAsyncContainer]`

Why it is useful:

- avoids framework-specific accessors, request state, or `ContextVar` plumbing
- makes fan-out and child-scope creation easier from already-running scoped code
- complements the documented context-sharing pattern in
  [lifetimes_and_scopes.md](/home/aldo/Projects/wireup/docs/pages/lifetimes_and_scopes.md)

Expected behavior:

- injectable only inside an active scope
- behaves like a scoped dependency
- unavailable from the root container

Related issue:

- [#115](https://github.com/maldoinc/wireup/issues/115)

### 3. Graph introspection / visualization

This is not just "nice to have". It becomes more valuable as Wireup gains more advanced composition features.

What it helps with:

- understanding large graphs
- debugging missing or surprising dependencies
- architecture review / onboarding
- documentation generation

Likely good minimal output:

- Mermaid generation first
- possibly a CLI helper or utility function

Related issue:

- [#59](https://github.com/maldoinc/wireup/issues/59)

## Worth Doing, But Lower Priority

### Collection injection / multibinding

Allow requesting all implementations of an interface/protocol, likely via collection types.

Typical use cases:

- plugin pipelines
- validators
- enrichers
- event handlers
- strategy lists

This is one of the most recognizable "advanced container" features from other ecosystems.

Related issue:

- [#23](https://github.com/maldoinc/wireup/issues/23)

### More integrations

Useful, but ecosystem reach is secondary to core container features:

- Temporal
- gRPC
- Litestar

Related issues:

- [#101](https://github.com/maldoinc/wireup/issues/101)
- [#81](https://github.com/maldoinc/wireup/issues/81)
- [#37](https://github.com/maldoinc/wireup/issues/37)

## Things That Probably Do Not Need Urgent Attention

### Full nested scopes

The current direction in
[lifetimes_and_scopes.md](/home/aldo/Projects/wireup/docs/pages/lifetimes_and_scopes.md) is good:

- intentionally avoid full hierarchical inherited scopes
- use isolated child scopes plus explicit context sharing

This seems to cover most practical use cases while keeping the API predictable.

### More "magic" registration

Wireup's strength is that advanced behavior is available without making the public API noisy. New features should
ideally continue following that pattern.

## If Choosing Only Three After Aggregates

1. Typed providers / lazy access
2. Scoped self-injection
3. Graph introspection / visualization

These seem like the highest-signal additions for both actual usefulness and "this container is simple but powerful"
perception.
