# Wireup Nested Scopes — Design Document

## Overview

This document proposes adding support for **arbitrarily nested scopes** to Wireup. The goal is to allow
a tree of scoped containers where each node inherits from its parent, enabling patterns like:

```
root container
 └── request scope          (HTTP request)
      ├── task scope 1      (parallel subtask)
      ├── task scope 2
      └── task scope 3
```

The design is inspired by Autofac's `InstancePerMatchingLifetimeScope` but adapted to Wireup's API
and philosophy: minimal surface area, explicit over implicit, and full backwards compatibility.

---

## Goals

- Arbitrary nesting depth: a scoped container can itself spawn child scoped containers.
- Tagged scopes: a dependency can declare which named scope boundary it belongs to, and resolution
  walks up the ancestor chain to find or create the instance there.
- Untagged `scoped` lifetime continues to work exactly as today — one instance per scope, always
  fresh. No behaviour change for existing code.
- Both sync and async containers supported identically.
- Locking behaviour (`concurrent_scoped_access`) unchanged — opt-in at container creation time.

---

## Non-Goals

- Scope-level policies ("everything in this scope defaults to X lifetime").
- Cross-branch scope sharing (sibling scopes cannot see each other's instances).
- Lazy scope tag validation at build time (resolve-time errors are acceptable and consistent with
  Autofac's approach).

---

## New Concepts

### Scope Tags

A scope tag is an arbitrary string identifier attached to a scope at creation time:

```python
with container.enter_scope(tag="request") as request_scope:
    async with request_scope.enter_scope() as task_scope:  # no tag
        ...
```

Tags are optional. An untagged scope behaves exactly as today.

### `scope_tag` on `@injectable`

A dependency can declare that it belongs to a named scope boundary:

```python
@injectable(lifetime="scoped", scope_tag="request")
class UserContext: ...
```

When resolved from any scope in the tree, Wireup walks up the ancestor chain and creates (or reuses)
the instance at the **nearest ancestor whose tag matches**. If no matching ancestor is found,
a `ScopeTagNotFoundError` is raised at resolve time.

Dependencies with no `scope_tag` continue to behave as today: one fresh instance per the scope
they are resolved from.

---

## API Changes

### `ScopedContainer.enter_scope()`

Currently `enter_scope()` is only available on the root container. It is now also available on
`ScopedContainer`, accepting the same optional `tag` argument:

```python
# Sync
with container.enter_scope(tag="request") as request_scope:
    with request_scope.enter_scope() as task_scope:
        svc = task_scope.get(MyService)

# Async
async with container.enter_scope(tag="request") as request_scope:
    async with request_scope.enter_scope() as task_scope:
        svc = await task_scope.get(MyService)
```

The child scope holds a reference to its parent. This reference is used only for resolution
walk-up; it does not affect cleanup.

### `@injectable` decorator

`scope_tag` is a new optional keyword argument. It is only valid when `lifetime="scoped"`:

```python
@injectable(lifetime="scoped", scope_tag="request")
class DbTransaction: ...
```

Specifying `scope_tag` on a non-scoped lifetime raises `ValueError` at decoration time.

---

## Resolution Algorithm

When `scope.get(T)` is called:

1. Determine the registration for `T`.
2. **If `lifetime="singleton"`**: resolve from root as today.
3. **If `lifetime="transient"`**: create a new instance in the current scope as today.
4. **If `lifetime="scoped"` and no `scope_tag`**: resolve from the current scope as today
   (one instance per scope, fresh per scope). No change to existing behaviour.
5. **If `lifetime="scoped"` and `scope_tag` is set**:
   a. Walk up the ancestor chain (current scope → parent → grandparent → … → root).
   b. Find the nearest scope whose `tag` matches `scope_tag`.
   c. If found: create the instance there if not already present, then return it. All further
      resolutions of `T` from any descendant of that scope return the same instance.
   d. If not found: raise `ScopeTagNotFoundError(dep=T, required_tag="request")`.

Step 5c means that **two sibling task scopes resolving a `scope_tag="request"` dependency will
always get the same instance**, because both walk up to the shared request scope.

### Dependency resolution during step 5c

When creating an instance at an ancestor scope, any dependencies of that instance are also resolved
starting from that ancestor scope (not the original child scope). This mirrors Autofac's behaviour
and prevents a parent-scoped object from accidentally holding a reference to a child-scoped object.

---

## Cleanup

Cleanup order follows scope closure order, innermost first:

```
task_scope closes   → transients and untagged scoped deps owned by task_scope are cleaned up
request_scope closes → deps created at request_scope (including tagged ones) are cleaned up
container closes    → singletons cleaned up
```

A tagged dependency created at `request_scope` during resolution from `task_scope` is **owned by
`request_scope`**. It is cleaned up when `request_scope` closes, not when `task_scope` closes.
This is the natural and correct behaviour: the instance outlives the task but not the request.

---

## Lifetime Dependency Rules (updated)

The existing rules are unchanged. One addition for `scope_tag`:

- A `scope_tag="X"` dependency can only depend on singletons, config, and other `scope_tag="X"`
  or `scope_tag` of an ancestor scope. It **cannot** depend on an untagged `scoped` or `transient`
  dependency, because those would be resolved in the child scope, creating a lifetime mismatch.
  This is validated at resolve time (and optionally at build time if the scope tree is known ahead
  of time).

---

## Error Cases

| Situation                                           | Error                                     |
| --------------------------------------------------- | ----------------------------------------- |
| `scope_tag` on non-scoped lifetime                  | `ValueError` at decoration time           |
| `scope_tag="X"` dep resolved with no `"X"` ancestor | `ScopeTagNotFoundError` at resolve time   |
| `scope_tag` dep depends on a shorter-lived dep      | `LifetimeMismatchError` at resolve time   |
| `enter_scope()` called on a closed scope            | `ScopeClosedError` (already exists today) |

---

## Full Example

```python
@injectable  # singleton
class AppConfig: ...

@injectable(lifetime="scoped", scope_tag="request")
class UserContext:
    def __init__(self, config: AppConfig): ...

@injectable(lifetime="scoped", scope_tag="request")
class DbConnection:
    def __init__(self, config: AppConfig): ...

@injectable(lifetime="scoped")  # untagged: one per scope as today
class TaskLogger:
    def __init__(self, user: UserContext): ...  # resolves user from "request" ancestor

@injectable(lifetime="transient")
class WorkItem:
    def __init__(self, logger: TaskLogger, db: DbConnection): ...


# --- runtime ---

container = wireup.create_async_container(
    injectables=[AppConfig, UserContext, DbConnection, TaskLogger, WorkItem],
    concurrent_scoped_access=True,  # request scope shared across tasks
)

async with container.enter_scope(tag="request") as request_scope:
    async with asyncio.TaskGroup() as tg:
        for _ in range(10):
            async with request_scope.enter_scope() as task_scope:
                tg.create_task(run_task(task_scope))


async def run_task(scope):
    item = await scope.get(WorkItem)
    # UserContext  → resolved at request_scope, shared across all tasks
    # DbConnection → resolved at request_scope, shared across all tasks
    # TaskLogger   → resolved at task_scope, isolated per task
    # WorkItem     → transient, new instance per .get() call
    await item.run()
```

---

## Internal Implementation Notes

### `ScopedContainer` changes

- Add `_parent: Optional[ScopedContainer]` field.
- Add `_tag: Optional[str]` field.
- Add `enter_scope(tag=None)` method that returns a new `ScopedContainer` with `_parent=self`.
- Modify `get()` / `_resolve()` to check `scope_tag` on the registration and invoke the walk-up
  logic when present.

### Walk-up helper

```python
def _find_scope_for_tag(self, tag: str) -> "ScopedContainer":
    current = self
    while current is not None:
        if current._tag == tag:
            return current
        current = current._parent
    raise ScopeTagNotFoundError(tag)
```

### Instance storage

Tagged instances are stored in the `_instances` dict of the **owning scope** (the ancestor that
matched), not the resolving scope. This is the only change to instance storage logic.

### `concurrent_scoped_access`

No change to the existing locking model. If `concurrent_scoped_access=True`, the existing lock
covers all instance creation including the walk-up path, since instance creation always happens
in a specific scope's `_instances` dict which is protected by that scope's lock.

---

## Alternatives Considered

### `inherit=True` flag instead of tags

A simpler `inherit=True` on `@injectable` would make a dep walk up and reuse any ancestor's
instance. Rejected because it leaves "which ancestor?" ambiguous — two sibling task scopes
that both resolve an `inherit=True` dep before the parent does would each create their own
instance, which is likely a bug. Tags make the boundary explicit and fail loudly if misconfigured.

### New named lifetimes (`"request"`, `"task"`)

Hardcodes domain concepts into the framework. Doesn't generalise. Rejected.

### Scope-level default lifetime

Allow `enter_scope(default_lifetime="scoped")` to pin all deps resolved in that scope. More
powerful but significantly more complex and harder to reason about. Out of scope for v1.

---

## Open Questions

1. **Build-time validation**: If the full scope tree is known at startup (e.g. a web framework
   integration where "request" is always a child of root), should Wireup validate `scope_tag`
   references at container build time? This would catch misconfigurations earlier but requires
   scope topology to be registered explicitly.

2. **Multiple tags per scope**: Should a scope be allowed to have multiple tags
   (`enter_scope(tags=["request", "tenant"])`)? Probably not needed for v1.

3. **Web framework integrations**: FastAPI/Flask integrations currently create a scope per request
   automatically. They should pass `tag="request"` (or a configurable tag) when doing so. This
   is a small change but needs coordination across integrations.

4. **Depth limit**: Should there be a configurable or hard limit on nesting depth to catch
   accidental infinite scope trees? Probably not needed — the GC will handle it and it's an
   unlikely mistake.