# Wireup 2026 Growth + SEO Plan (Resume File)

## Goal
- Reach **1,000 GitHub stars by December 31, 2026**.

## Baseline (as of 2026-02-25)
- Stars: **355**
- Gap to goal: **645**
- Required pace: ~**65 stars/month** (~2.1/day)

## Milestones
- 2026-03-31: 430
- 2026-04-30: 500
- 2026-05-31: 580
- 2026-06-30: 650
- 2026-07-31: 720
- 2026-08-31: 790
- 2026-09-30: 850
- 2026-10-31: 910
- 2026-11-30: 960
- 2026-12-31: 1000+

## Workstreams
### 1) Conversion Surface
- Tighten README top section around value prop + social proof + frameworks.
- Keep clear CTA to star after value is shown.
- Keep docs homepage crisp and keyword-aligned.

### 2) SEO Content
- Keep metadata per-page (not global tags everywhere).
- Benchmark page on benchmark branch:
  - H1
  - heading keyword tuning
  - improved alt text
  - `search.boost: 2`
- Add comparison pages:
  - Wireup vs Dependency Injector
  - Wireup vs FastAPI Depends
  - Wireup vs Dishka

### 3) Distribution Cadence
- 2 community posts per week (Discord/Reddit/social).
- 1 technical content post per week (examples, migration snippet, benchmark insight).
- Release post for every meaningful release.

### 4) Credibility Assets
- Example repos:
  - Django + DRF
  - Django Ninja
  - FastAPI
- Migration guides for top competitor libs.

## Metrics to Track Weekly
- Total stars
- 7-day star velocity
- GitHub repo visits
- Top referral sources
- Star conversion rate (stars / visits)

## Current Status (Checked)
- [x] Enabled MkDocs `meta` plugin in `docs/mkdocs.yml`
- [x] Added global docs description via `docs/pages/.meta.yml`
- [x] Switched from global tags to per-page tags
- [x] Removed tags from API reference pages (`docs/pages/class/*`)
- [ ] Ship benchmark-page SEO updates on benchmark branch
- [ ] Add comparison docs pages
- [ ] README conversion pass
- [ ] Weekly KPI review loop

## Immediate Next 2 Weeks
1. Merge benchmark branch with SEO updates.
2. Publish benchmark announcement post (Django + ArjanCodes follow-up thread).
3. Create first comparison page (`Wireup vs Dependency Injector`).
4. Add one framework example repo (Django + DRF first).
5. Review weekly KPI numbers and adjust posting cadence.

## Resume Instructions
- Start each session by updating:
  - Current stars
  - Stars gained in last 7 days
  - Which tasks in "Current Status" were completed
- Then execute the top unchecked item with highest expected impact.
