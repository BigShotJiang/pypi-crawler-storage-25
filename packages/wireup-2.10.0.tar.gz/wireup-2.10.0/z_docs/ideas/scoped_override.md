# Scoped Overrides

This note scopes out a possible future `scope.override` feature for Wireup.

The idea is not to replace the current root-level `container.override`, but to add a scope-local version that applies
only to one active scope. The primary motivation is testing and request-scoped behavior, where the current root-bound
override model is often "good enough", but has a few sharp edges once scoped caching enters the picture.

## Why consider this

Wireup's current override model is rooted at the container:

- `container.override.injectable(...)` changes what future resolutions produce.
- It does not rebuild already-created singleton or scoped objects.
- It naturally applies to the whole container, because it works by swapping compiled factories on the shared compiler.

That model is coherent and useful, especially for tests that:

- create a fresh app/container per test,
- apply overrides before the first resolution of the object under test,
- or only need to replace direct dependencies / transient consumers.

The pain starts when a test or runtime flow already has an active scope and wants an override that is local to that
scope only.

## The problem it would solve

Today there is a mismatch between where overrides live and where scoped objects live:

- overrides live on the root container,
- scoped caches live on individual scope containers.

That creates a few awkward cases:

### 1. Root override is broader than intended

If a test wants to replace a dependency only for one request / one scope, the current API still uses:

```python
with container.override.injectable(CurrentUser, FakeUser(...)):
    ...
```

That override is attached to the root container, even if the intent is only "for this request scope".

### 2. Active scoped graphs are not naturally isolated

If a scoped consumer was already created, overriding one of its dependencies does not rebuild it:

```python
with container.enter_scope() as scope:
    svc = scope.get(RequestService)  # cached in this scope

    with container.override.injectable(CurrentUser, FakeUser(...)):
        scope.get(CurrentUser)    # can reflect the override
        scope.get(RequestService) # still returns the already-created RequestService
```

This is acceptable under the current override model, but it means the override story is strongest before the first
resolution in a scope and weaker afterwards.

### 3. Root override is awkward for request-scoped testing

The current recommended testing story is still good:

- reuse the production wiring entry point,
- create a fresh app/container per test,
- apply root overrides before the first resolution.

But there are realistic test shapes where a scope-local override would be easier to reason about:

- request-scope integration tests that already have a live request container,
- tests that intentionally resolve some scoped setup first, then want alternate dependencies for later work in that
  same request,
- concurrent tests / background work where root-wide override breadth feels too global.

## What such a feature could look like

The simplest public API would mirror today's override manager:

```python
with container.enter_scope() as scope:
    with scope.override.injectable(CurrentUser, FakeUser(id="test-user")):
        service = scope.get(RequestService)
```

And for async:

```python
async with container.enter_scope() as scope:
    with scope.override.injectable(CurrentUser, FakeUser(id="test-user")):
        service = await scope.get(RequestService)
```

Likely additional methods:

- `scope.override.injectables(...)`
- `scope.override.set(...)`
- `scope.override.delete(...)`
- `scope.override.clear()`

This would ideally feel like the existing API, but scoped to one active scope instance.

## Expected semantics

The strongest version of this idea is not "retroactively mutate everything in the scope". That would be too magical
and expensive.

The more realistic and consistent semantics would be:

- scope overrides only affect future resolutions through that scope,
- they do not rebuild already-created scoped consumers automatically,
- they do not affect sibling scopes,
- they do not affect the root container outside the scope,
- they stack naturally with root overrides.

Suggested precedence:

1. scope-local override
2. root/container override
3. normal compiled factory resolution

That gives a clean model:

- root override = broad test / app-level override
- scope override = narrower override for one active request / unit of work / scope

## What it improves for users

### Better testing ergonomics for scoped code

This is the main value.

Current story:

- create a fresh app/container,
- override on the root,
- make sure the override is applied before the object under test is first resolved.

Possible future story with `scope.override`:

- create the real app/container as usual,
- open a real scope,
- apply an override that is explicitly scoped to that request / unit of work,
- assert behavior without touching other scopes.

That feels especially natural for:

- request-scoped web tests,
- service-layer tests for `scoped` dependencies,
- tests involving multiple scopes from the same root container.

### More honest lifetime boundaries

Users already think in terms of lifetime boundaries:

- singleton = app-wide
- scoped = request / unit-of-work
- transient = per-resolution

`scope.override` would line up with that mental model better than a root-wide override when the dependency in question is
fundamentally request-local.

### Clearer isolation story

Today, the answer to "can I override just for this scope?" is effectively "not really; use the root override carefully".

A scope-local API would make the answer explicit and much easier to document.

## What it would not solve

Even with `scope.override`, some things should probably remain true:

- if `RequestService` was already instantiated in the scope, `scope.override.injectable(CurrentUser, ...)` should not
  silently rebuild it,
- if a singleton was already instantiated, scope override should not be allowed to mutate that singleton graph,
- this should not become a hidden dependency graph invalidation engine.

So this feature would improve locality and developer ergonomics much more than it would change the fundamental
"future resolutions only" rule.

## Collection injection angle

This idea came up while discussing collection injection and override behavior.

The current root override model can invalidate synthetic singleton collection caches because those caches live at the
root. It cannot naturally invalidate already-materialized scoped collection values, because those caches live on the
individual scope container.

`scope.override` would not automatically make collection invalidation "perfect", but it would give Wireup a more honest
place to hang scope-local behavior in the future if we ever wanted collection-specific improvements there.

Even without special collection logic, `scope.override` would make the overall story cleaner:

- root override = root-level behavior
- scope override = scope-level behavior

## Testing stories this would help

These are the concrete user stories that make this feature feel worthwhile.

### Story 1: request-scoped fake current user

```python
async with container.enter_scope() as scope:
    with scope.override.injectable(CurrentUser, FakeUser(id="alice")):
        service = await scope.get(ProfileService)
        assert await service.get_profile_name() == "alice"
```

This keeps the fake user local to the scope instead of attaching it to the root container.

### Story 2: reuse one root container, vary behavior per scope

```python
with container.enter_scope() as admin_scope:
    with admin_scope.override.injectable(CurrentUser, AdminUser()):
        assert admin_scope.get(PermissionService).is_admin()

with container.enter_scope() as guest_scope:
    with guest_scope.override.injectable(CurrentUser, GuestUser()):
        assert not guest_scope.get(PermissionService).is_admin()
```

This is much easier to reason about than a shared root override if two scopes should see different values.

### Story 3: integration tests with request-time setup

If a framework integration already exposes a request-scoped container, `scope.override` could make it easier to test
request-specific behavior without reaching back out to the app root or recreating the whole app just to vary one
scoped dependency.

## Implementation concerns

This feature is not just a small wrapper on top of the current override manager.

The main technical reason is that today's compiled factories close over the compiler-level `factories` mapping. That is
exactly what makes root-wide override easy: replacing a compiled factory on the shared compiler affects all future
resolutions automatically.

That same architecture makes scope-local override harder:

- mutating the shared scoped compiler would leak the override to every scope,
- per-scope overrides need some form of per-container lookup or factory indirection,
- dependency resolution inside generated factories likely needs to consult container-local state rather than only the
  shared compiler mapping.

This suggests that implementing `scope.override` likely requires some deeper compiler/runtime plumbing change, not just
an extra manager object.

## Possible implementation directions

### Option A: per-container override lookup

Change generated factory code so dependency lookups go through container state instead of only the shared `factories`
mapping.

This is likely the cleanest long-term shape, because it allows:

- root override lookup,
- scope-local override lookup,
- and normal compiled factories,

to be resolved in one place with a clear precedence order.

### Option B: per-scope factory overlays

Give each active scope an overlay mapping for compiled factories and teach generated code to use that overlay.

This could work, but it still likely needs generated code changes, because current compiled factories capture the
compiler's factory dictionary directly.

### Option C: keep current architecture and do not pursue this

This remains a valid choice if the cost is too high relative to the testing improvement.

The current guidance already works reasonably well:

- prefer fresh app/container per test,
- apply root overrides before first resolution,
- use conditional registration for build-time replacement.

## Recommendation

This feels like a legitimate future feature, especially for testing and request-scoped ergonomics, but not something to
rush into casually.

The strongest case for it is:

- better scope-local test ergonomics,
- better isolation story for request-scoped behavior,
- and a cleaner mental model than "use the root override carefully".

The strongest argument against it is implementation weight:

- current compiler architecture is optimized around shared factory tables,
- and scope-local override likely needs a non-trivial change to how compiled dependency lookups work.

My current takeaway:

- good idea,
- worth revisiting if scoped testing pain keeps coming up,
- but should be treated as a proper design feature, not a quick patch.

