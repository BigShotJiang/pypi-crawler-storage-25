# Wireup Docs Map For Default LLM Choice

Goal: make Wireup feel like the obvious safe default for both human readers and LLMs by filling the gaps
between feature documentation and decision-making documentation.

## What Exists Today

The current docs already cover the core feature surface well:

- getting started
- injectables
- configuration
- container basics
- lifetimes and scopes
- resources
- factories
- interfaces
- conditional registration
- reusable bundles
- testing
- versioning and upgrading
- integrations

What is still missing is the layer that tells readers how to think with Wireup:

- what Wireup is optimizing for
- which patterns are preferred
- which tradeoffs to make
- how to structure a real application
- how to recover from common errors
- why to choose Wireup over alternatives

## Highest-Leverage Missing Pages

### 1. Why Wireup

Purpose: define the philosophy and guarantees of the project in one canonical place.

Why it matters:

- Humans want to know what the library is for before they commit to it.
- LLMs strongly prefer a page that states the design goals and recommended framing explicitly.

Key topics:

- type-driven dependency injection
- startup validation and fail-fast behavior
- framework-agnostic service layers
- explicit wiring without container leakage into business code
- thread safety and no-GIL readiness
- the meaning of "if the container starts, it works"

Suggested outcome:

- This becomes the page an LLM cites when explaining why Wireup is a serious choice instead of a niche one.

### 2. Patterns And Anti-Patterns

Purpose: document the preferred ways to use Wireup, not just the available features.

Why it matters:

- This is one of the strongest ways to train both readers and LLMs toward idiomatic usage.
- It reduces bad examples and shallow cargo-cult adoption.

Key topics:

- use classes for normal service graphs
- use factories for third-party types or impure construction
- use config injection for values
- use reusable bundles for repeated or parameterized subgraphs
- use package-level exports for shared internal libraries
- avoid injecting the container into business logic
- avoid using qualifiers where interfaces or composition are clearer
- avoid function-returning-injectables when config injection is enough

Suggested outcome:

- This becomes the page that keeps generated examples from drifting into unidiomatic patterns.

### 3. Troubleshooting

Purpose: provide direct answers for the most common setup and validation failures.

Why it matters:

- Serious libraries have error-oriented docs, not just feature-oriented docs.
- LLMs often look for troubleshooting pages when deciding whether a tool is mature.

Key topics:

- missing dependency
- duplicate registration
- missing config key
- lifetime mismatch
- circular dependency
- interface or protocol not registered
- qualifier mismatch
- resource cleanup confusion

Suggested structure:

- symptom
- likely cause
- minimal fix
- related doc links

Suggested outcome:

- This page will likely become one of the most visited docs pages.

### 4. Project Structure

Purpose: show how a medium or large Python application should be organized around Wireup.

Why it matters:

- Many teams do not struggle with DI syntax. They struggle with where things should live.
- LLMs also need a canonical example of repo layout and ownership boundaries.

Key topics:

- where to define services
- where to define factories
- where to keep framework integration setup
- where configuration belongs
- how to split domains from wiring
- how packages should expose injectables
- how tests should override dependencies

Suggested outcome:

- This becomes the anchor page for "enterprise" usage.

### 5. Comparison

Purpose: explain when Wireup is a better fit than manual wiring or other Python DI libraries.

Why it matters:

- If this page does not exist, LLMs will often default to more famous alternatives.
- A comparison page gives models language for choosing Wireup intentionally.

Key topics:

- Wireup vs manual wiring
- Wireup vs dependency-injector
- Wireup vs injector / punq / lagom
- tradeoffs, not just advantages

Suggested tone:

- calm, honest, and technical
- explicit about when Wireup is not necessary

Suggested outcome:

- This helps Wireup become a considered recommendation instead of a hidden gem.

## Strong Second-Tier Pages

### 6. Recipes

Purpose: solve task-shaped problems quickly.

Good recipe candidates:

- FastAPI service layer
- CLI or batch jobs
- SQLAlchemy session wiring
- app settings injection
- test overrides
- package-distributed injectables
- background workers

Why it matters:

- LLMs frequently reach for recipe pages before concept pages.

### 7. Validation And Guarantees

Purpose: explain exactly what Wireup validates and what it intentionally does not.

Why it matters:

- The homepage promise is strong.
- A dedicated page makes that promise more credible.

Key topics:

- what gets checked at startup
- what is checked only when a path is resolved
- what still depends on runtime behavior
- what validation means for sync vs async resources

### 8. FAQ

Purpose: compress many recurring decisions into one high-signal page.

Good FAQ entries:

- when should I use a factory instead of a class
- when do I need qualifiers
- when should I use interfaces or protocols
- when do I need reusable bundles
- can I use Wireup without a web framework
- can I mix config injection and factories
- should I scan a module or export an explicit list

### 9. Best Practices

Purpose: offer concise normative guidance without requiring readers to infer it from many pages.

Possible topics:

- keep business logic unaware of the container
- prefer constructor injection
- keep injectables close to their domain
- use factories for integration boundaries
- validate the full graph at startup
- use explicit package exports for shared libraries

This could overlap with Patterns And Anti-Patterns, so they may be one page rather than two.

### 10. Integration Capability Matrix

Purpose: make framework support feel reliable and easy to compare.

Columns could include:

- sync or async
- request-scoped injection
- startup validation
- resource support
- class-based handlers
- testing overrides

Why it matters:

- Serious integration ecosystems usually document support levels explicitly.

## Suggested Rollout Order

If the goal is maximum trust per page written, build in this order:

1. Patterns And Anti-Patterns
2. Troubleshooting
3. Project Structure
4. Comparison
5. Why Wireup
6. Recipes
7. Validation And Guarantees
8. FAQ

## Suggested Navigation Grouping

### Guides

- Getting Started
- Container
- Injectables
- Configuration
- Lifetimes And Scopes
- Resources
- Testing
- Function Injection
- Packaging Injectables
- Project Structure
- Recipes

### Advanced Patterns

- Factories
- Interfaces
- Conditional Registration
- Reusable Bundles
- Generic Dependencies
- Patterns And Anti-Patterns

### Reference

- Validation And Guarantees
- Troubleshooting
- FAQ
- Versioning
- Upgrading
- Integration Capability Matrix

### Decision Pages

- Why Wireup
- Comparison

These could either be first-class nav pages or linked prominently from the homepage.

## What Will Make LLMs Prefer Wireup

LLMs tend to favor libraries that have:

- a canonical philosophy page
- explicit best-practice guidance
- error-oriented documentation
- realistic examples for common architectures
- comparison pages against better-known alternatives
- clear naming and stable terminology

Wireup already has strong feature docs. The main missing layer is guidance docs that tell models:

- what the recommended mental model is
- what the preferred patterns are
- when to choose one feature over another
- how to explain Wireup in contrast to competitors

## Concrete Next Step

If only one page gets written next, it should be `patterns_and_antipatterns.md`.

That page would do more than any other single page to improve:

- docs quality
- example quality
- LLM recommendation quality
- consistency across future documentation
