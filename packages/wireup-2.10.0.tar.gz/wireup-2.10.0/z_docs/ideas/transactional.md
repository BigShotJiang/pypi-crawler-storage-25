# Wireup Transactional Design Notes (FastAPI-first)

## Goal
Design a Spring-style transactional unit-of-work experience for Wireup with top-tier developer experience in FastAPI, while staying aligned with Wireup's existing scope/lifetime model.

## Why this exists
Wireup already provides strong primitives:
- request/scoped lifetimes,
- cleanup-aware generator factories,
- request container access in FastAPI via `get_request_container`.

What is missing is ergonomic transaction boundary management so users do not manually duplicate `begin/commit/rollback` patterns in every service method.

## Core stance
- The **real transaction** is owned by SQLAlchemy `Session` / `AsyncSession`.
- Wireup adds a **transaction boundary orchestration layer**.
- This is an integration feature, not a core container lifetime change.

## Scope and packaging decisions
- Backend target: **SQLAlchemy first**.
- FastAPI DX: **first-class**.
- Package location: **new optional integration package** (`wireup.integration.sqlalchemy`) plus FastAPI aliases.
- Adoption mode: **experimental first**.

## API direction

### Backend-level (integration/sqlalchemy)
- `transactional(...)` decorator
- `unit_of_work(...)` context manager
- `async_unit_of_work(...)` async context manager

### FastAPI DX alias
- `wireup.integration.fastapi.transactional`
- `wireup.integration.fastapi.unit_of_work` (async-focused)

Canonical FastAPI usage should be:

```python
from wireup.integration.fastapi import transactional

@transactional
async def fn(...):
    ...
```

### Minimal options (v1)
- `db=`: selects qualified session (DX alias for Wireup qualifier)
- `read_only=False` by default

No large Spring option matrix in v1.

## Transaction semantics (v1)

### Propagation
- **REQUIRED only**:
  - If an active tx exists in current request/scope call stack: join it.
  - Otherwise: open a new tx.

### Ownership
- If this layer opened tx: it owns commit/rollback.
- If joined existing tx: it does not commit/rollback.

### Error policy
- Rollback on **any exception**.
- Re-raise original exception.

### Success policy
- `read_only=False`: commit (if owner).
- `read_only=True`: rollback on success (if owner), i.e. no commit.

## FastAPI-specific DX decisions
- Support both service-layer and route-layer usage.
- Must work in custom route decorators/middleware paths too.
- Require `middleware_mode=True` for transactional decorators in FastAPI integration.
- Enforce misconfiguration as **startup error** (fail fast), not delayed runtime surprise.
- FastAPI-specific decorator is **async-first** and request-context bound.

## Request context behavior
- Request-context only in v1 for FastAPI alias.
- If called out of request context, raise clear `WireupError` with guidance.

## Two-transactions-in-one-request behavior

### Sequential boundaries
If one request executes two separate top-level transactional methods, it gets two sequential transactions:
1. method A starts tx A, ends tx A,
2. method B starts tx B, ends tx B.

### Nested boundaries
If transactional method calls another transactional method in same scope:
- inner joins outer (REQUIRED),
- outer owns final commit/rollback,
- not two independent transactions.

## "Where is the actual transaction?"
- On SQLAlchemy session (`AsyncSession` in FastAPI path).
- Orchestration layer checks transaction state (`in_transaction()` style) and decides join vs begin.

## How users insert records
Users continue writing normal SQLAlchemy code:
- `session.add(entity)`
- optional `await session.flush()` for generated IDs
- no manual commit if `@transactional` owns boundary

So Wireup changes *boundary handling*, not ORM CRUD APIs.

## Typical user example (FastAPI)

```python
from collections.abc import AsyncIterator

from fastapi import FastAPI
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

import wireup
from wireup import Injected, injectable
import wireup.integration.fastapi as wireup_fastapi
from wireup.integration.fastapi import transactional

engine = create_async_engine("postgresql+asyncpg://user:pass@localhost/app")
SessionLocal = async_sessionmaker(engine, expire_on_commit=False)

@injectable(lifetime="scoped")
async def db_session_factory() -> AsyncIterator[AsyncSession]:
    async with SessionLocal() as session:
        yield session

@injectable(lifetime="scoped")
class UserService:
    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    @transactional
    async def create_user(self, email: str) -> dict:
        # self.db.add(...)
        # await self.db.flush()
        return {"email": email}

app = FastAPI()

@app.post("/users")
async def create_user(email: str, service: Injected[UserService]):
    return await service.create_user(email)

container = wireup.create_async_container(
    injectables=[db_session_factory, UserService, wireup_fastapi],
)
wireup_fastapi.setup(container, app, middleware_mode=True)
```

## Planned constraints for v1
- No `REQUIRES_NEW`.
- No isolation-level matrix.
- No broad Spring parity knobs (`rollback_for`, `no_rollback_for`, etc.) initially.
- Keep API small and obvious.

## Planned test scenarios
1. Commit on success when decorator owns tx.
2. Rollback on exception when decorator owns tx.
3. Nested transactional calls do not double-commit.
4. `read_only=True` rolls back-on-success.
5. Qualified session resolution via `db=`.
6. Startup fail when transactional usage + `middleware_mode=False`.
7. Works in custom decorators with `middleware_mode=True`.
8. Request-context error is explicit and actionable.
9. Explicit context manager API matches decorator semantics.

## Tradeoff summary
Pros:
- Major boilerplate reduction for transaction boundaries.
- Clear service-level intent.
- Safer default commit/rollback behavior.
- Aligns with existing Wireup scope model.

Cons:
- New integration surface to maintain.
- Must communicate request-context and middleware constraints clearly.
- Some users may expect full Spring semantics immediately.

## Bottom line
This feature is valuable if kept focused:
- FastAPI async-first,
- SQLAlchemy-first,
- REQUIRED semantics,
- minimal options,
- clear docs + fail-fast guardrails.

That delivers high DX without overcomplicating Wireup core.
