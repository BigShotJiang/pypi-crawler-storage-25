# Collection Injection

When you register multiple implementations of the same type, Wireup can inject them as a collection.

Wireup provides two canonical collection forms:

- `collections.abc.Sequence[T]` for all implementations in registration order
- `collections.abc.Mapping[Hashable, T]` for all implementations keyed by qualifier

These collection types are meant to reflect Wireup's actual registration model directly:

- qualifiers can be any hashable value
- `None` is a real qualifier value
- plain `T` is shorthand for `Annotated[T, Inject(qualifier=None)]`

That means Wireup does not treat the `None`-qualified implementation as a separate category. It is just one implementation in the qualifier space, with the benefit that plain `T` can target it directly.

## Sequence Injection

Use `collections.abc.Sequence[T]` to inject all implementations of `T`.

```python
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Protocol

from wireup import injectable


class Cache(Protocol):
    def source(self) -> str: ...


@injectable(as_type=Cache)
class InMemoryCache:
    def source(self) -> str:
        return "memory"


@injectable(as_type=Cache, qualifier="redis")
class RedisCache:
    def source(self) -> str:
        return "redis"


@injectable
@dataclass
class CacheReporter:
    caches: Sequence[Cache]
```

`Sequence[T]` contains all registered implementations of `T` in registration order.

In the example above, `caches` will contain:

```python
(InMemoryCache(...), RedisCache(...))
```

If every implementation is qualified, `Sequence[T]` still works the same way.

## Mapping Injection

Use `collections.abc.Mapping[Hashable, T]` to inject all implementations of `T`, keyed by qualifier.

```python
from collections.abc import Hashable, Mapping
from dataclasses import dataclass
from typing import Protocol

from wireup import injectable


class Cache(Protocol):
    def source(self) -> str: ...


@injectable(as_type=Cache)
class InMemoryCache:
    def source(self) -> str:
        return "memory"


@injectable(as_type=Cache, qualifier="redis")
class RedisCache:
    def source(self) -> str:
        return "redis"


@injectable
@dataclass
class CacheRegistry:
    caches: Mapping[Hashable, Cache]
```

In the example above, `caches` will contain:

```python
{
    None: InMemoryCache(...),
    "redis": RedisCache(...),
}
```

Wireup includes the `None` key when a `None`-qualified implementation exists.

This is intentional. `Mapping[Hashable, T]` is the full keyed view of the binding set, not a filtered view of only explicitly-qualified implementations.

If no `None`-qualified implementation exists, the mapping simply does not contain a `None` key.

## Plain `T` Is Shorthand For The `None` Qualifier

Direct injection of `T` is shorthand for requesting the `None`-qualified implementation.

These mean the same thing:

```python
from typing import Annotated

from wireup import Inject


cache: Cache
explicit_cache: Annotated[Cache, Inject(qualifier=None)]
```

This also means:

- plain `T` only works when a `None`-qualified implementation exists
- users can qualify every implementation if they want
- the `None`-qualified implementation is not required

For example:

```python
@injectable(as_type=Cache, qualifier="memory")
class InMemoryCache: ...


@injectable(as_type=Cache, qualifier="redis")
class RedisCache: ...
```

In this case:

- `Sequence[Cache]` works
- `Mapping[Hashable, Cache]` works
- plain `Cache` does not, because there is no `None`-qualified implementation

## Why Mapping Includes `None`

The intent of mapping injection is:

- "give me all implementations keyed by qualifier"

Wireup registers implementations by qualifier, and `None` is one valid qualifier value. Omitting `qualifier=` is only shorthand for using `None`.

That means:

- if the map is keyed by qualifier, the `None`-qualified implementation belongs in it
- if it does not appear, the map is no longer a full keyed view of the binding set

Including `None` keeps the collection story consistent:

- `Sequence[T]` means all implementations
- `Mapping[Hashable, T]` means the same set, keyed by qualifier

`caches[None]` can read a little awkwardly at first, but that is a smaller cost than turning the mapping into a filtered view with a special rule.

## Qualifiers Can Be More Than Strings

Mapping injection uses the real qualifier values as keys. Qualifiers are not limited to strings.

For example, enums work naturally:

```python
from collections.abc import Hashable, Mapping
from enum import StrEnum
from typing import Protocol

from wireup import injectable


class CacheType(StrEnum):
    MEMORY = "memory"
    REDIS = "redis"


class Cache(Protocol):
    def source(self) -> str: ...


@injectable(as_type=Cache, qualifier=CacheType.MEMORY)
class InMemoryCache:
    def source(self) -> str:
        return "memory"


@injectable(as_type=Cache, qualifier=CacheType.REDIS)
class RedisCache:
    def source(self) -> str:
        return "redis"


@injectable
class CacheRegistry:
    def __init__(self, caches: Mapping[Hashable, Cache]) -> None:
        self.caches = caches
```

The resulting mapping uses the enum values themselves as keys.

## Deriving Custom Collection Views

Wireup provides canonical collection views. If your application wants a narrower or reshaped view, derive it as a normal injectable.

For example, if you want a filtered list that excludes the implementation plain `T` resolves to:

```python
from __future__ import annotations

from collections.abc import Sequence
from typing import TypeVar

from wireup import SyncContainer, injectable

T = TypeVar("T")


def make_filtered_sequence_factory(interface: type[T]):
    @injectable(as_type=list[interface])  # type: ignore[valid-type]
    def filtered_sequence(container: SyncContainer) -> list[T]:
        default_item = container.get(interface)
        items = container.get(Sequence[interface])  # type: ignore[valid-type]
        return [item for item in items if item is not default_item]

    return filtered_sequence
```

And if you want a mapping without the `None` key:

```python
from __future__ import annotations

from collections.abc import Hashable, Mapping
from typing import TypeVar

from wireup import SyncContainer, injectable

T = TypeVar("T")


def make_filtered_mapping_factory(interface: type[T]):
    @injectable(as_type=dict[Hashable, interface])  # type: ignore[valid-type]
    def filtered_mapping(container: SyncContainer) -> dict[Hashable, T]:
        items = container.get(Mapping[Hashable, interface])  # type: ignore[valid-type]
        return {k: v for k, v in items.items() if k is not None}

    return filtered_mapping
```

This keeps Wireup's built-in collection semantics simple and complete, while still letting applications define domain-specific collection shapes where needed.

## Summary

Use:

- `Sequence[T]` for all implementations in registration order
- `Mapping[Hashable, T]` for all implementations keyed by qualifier

And remember:

- plain `T` is shorthand for `qualifier=None`
- `None` is a real qualifier value
- mapping injection includes `None` when a `None`-qualified implementation exists
- if you want a filtered or transformed collection, derive it as an ordinary injectable
