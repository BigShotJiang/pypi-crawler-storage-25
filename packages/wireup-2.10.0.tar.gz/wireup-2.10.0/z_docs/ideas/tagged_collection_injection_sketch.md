# Wireup Tagged Collection Injection Sketch

This note sketches what a tagging feature could look like in Wireup, with a focus on one specific use case:

- inject all implementations of `T` that belong to some tag

The goal is to make this feel like a natural extension of Wireup's current model, not the start of a second DI system layered on top of the first one.

## Executive Summary

My recommendation:

- keep qualifiers and tags as separate concepts
- use tags only for grouping, not identity
- make tagging orthogonal to `as_type` and `qualifier`
- support tagged collection injection first, not tagged single-resolution
- express tag selection through `Inject(tag=...)` on collection types
- let tagged collections reuse the same canonical collection shapes:
  - `Sequence[T]`
  - `Mapping[Hashable, T]`

Suggested public API:

```python
@injectable(as_type=Handler, tags={"payments", "async"})
class StripeHandler: ...


@injectable(as_type=Handler, tags={"payments"})
class PaypalHandler: ...


@injectable
class PaymentsProcessor:
    def __init__(
        self,
        handlers: Annotated[Sequence[Handler], Inject(tag="payments")],
    ) -> None:
        self.handlers = handlers
```

And for keyed lookup:

```python
@injectable
class HandlerRegistry:
    def __init__(
        self,
        handlers: Annotated[Mapping[Hashable, Handler], Inject(tag="payments")],
    ) -> None:
        self.handlers = handlers
```

That gives Wireup:

- one identity mechanism: qualifiers
- one grouping mechanism: tags
- one collection story: sequence for all values, mapping for keyed values

## What Problem Tags Solve

Qualifiers answer:

- which exact implementation do I want?

Tags answer:

- which subset of implementations do I want to treat as a group?

Those are different problems.

Qualifiers are a good fit for:

- choosing one implementation
- keyed lookup
- direct runtime selection

Tags are a good fit for:

- pipelines
- plugin groups
- feature-specific handler sets
- "all exporters for telemetry"
- "all validators for signup"
- "all post-processors for this workflow"

Trying to use qualifiers for that grouping works poorly, because qualifiers are unique identity values, not membership labels.

## Design Goal

The feature should preserve Wireup's existing strengths:

- small API surface
- low concept count
- type-driven usage
- few magic markers
- new collection-like features implemented as synthetic derived registrations instead of special container behavior

So the bar should be:

- add one small concept that solves a real grouping problem
- do not add a large sub-language for filtering
- do not make tags compete with qualifiers

## Proposed Registration API

Add an optional `tags` argument to `@injectable`:

```python
@injectable(as_type=Handler, tags={"payments", "async"})
class StripeHandler: ...
```

Suggested semantics:

- `tags` is an unordered set of tag values
- an implementation can have zero, one, or many tags
- tags are metadata on the registration
- tags do not participate in identity
- tags do not affect plain `T` resolution
- tags do not affect qualifier uniqueness rules

I would make `tags` accept `Collection[Hashable]`, with one practical restriction:

- `None` should not be allowed as a tag value

Why accept hashables instead of strings only:

- it is consistent with Wireup's existing "not string-only unless there is a strong reason" style
- enums become natural tag values
- it avoids inventing a second arbitrary restriction where the library does not need one

Why disallow `None`:

- `None` already carries meaning in qualifier discussions
- tags are presence/absence metadata, not default-selection state
- avoiding `None` here keeps the system easier to explain

## Proposed Injection API

I would not add a new wrapper type for this.

The smallest coherent shape is:

```python
Annotated[Sequence[T], Inject(tag="payments")]
Annotated[Mapping[Hashable, T], Inject(tag="payments")]
```

That fits Wireup's existing style:

- `Inject(qualifier=...)` refines which binding to use
- `Inject(tag=...)` refines which collection subset to inject

So the collection target remains a normal Python collection ABC, and the Wireup-specific part stays in `Inject(...)`.

Example:

```python
from collections.abc import Sequence
from typing import Annotated, Protocol

from wireup import Inject, injectable


class Handler(Protocol):
    def handle(self) -> None: ...


@injectable(as_type=Handler, tags={"payments"})
class StripeHandler: ...


@injectable(as_type=Handler, tags={"payments"})
class PaypalHandler: ...


@injectable(as_type=Handler, tags={"analytics"})
class MixpanelHandler: ...


@injectable
class PaymentsProcessor:
    def __init__(
        self,
        handlers: Annotated[Sequence[Handler], Inject(tag="payments")],
    ) -> None:
        self.handlers = handlers
```

`handlers` should contain only `StripeHandler` and `PaypalHandler`.

## Sequence Semantics

```python
handlers: Annotated[Sequence[Handler], Inject(tag="payments")]
```

Meaning:

- give me all `Handler` implementations tagged with `"payments"`

Suggested behavior:

- preserve registration order within the matching subset
- include both `None`-qualified and explicitly-qualified implementations if they match the tag
- if nothing matches, inject an empty sequence

That last rule is important.

For collection injection, empty is usually the right semantic. It keeps the feature usable for plugin-style extension points where a tag group may legitimately be absent.

## Mapping Semantics

```python
handlers: Annotated[Mapping[Hashable, Handler], Inject(tag="payments")]
```

Meaning:

- give me all `Handler` implementations tagged with `"payments"`, keyed by qualifier

Suggested behavior:

- include the exact qualifier values as keys
- include `None` when a matching `None`-qualified implementation exists
- preserve the same include-`None` rule as untagged mapping injection
- if nothing matches, inject an empty mapping

That keeps the mental model simple:

- untagged `Mapping[Hashable, T]` = all bindings for `T`
- tagged `Mapping[Hashable, T]` = all bindings for `T` that have tag `X`

Same collection shape, same key semantics, just filtered by tag membership.

## Why `Inject(tag=...)` Should Be Collection-Only At First

I would keep the first version narrow:

- tags can filter collections
- tags do not become a new single-binding resolution mode

In other words:

- good: `Annotated[Sequence[T], Inject(tag="x")]`
- good: `Annotated[Mapping[Hashable, T], Inject(tag="x")]`
- not for v1: `Annotated[T, Inject(tag="x")]`

Why:

- `Annotated[T, Inject(tag="x")]` asks tags to do identity work
- that overlaps with qualifiers
- if multiple implementations share the same tag, a single-resolution API becomes ambiguous immediately

You could define additional rules such as:

- tag must match exactly one implementation
- or tag + qualifier can be combined

But that adds a lot of policy quickly.

For v1, tags should stay about grouping, not selecting one implementation.

## Combining Tags And Qualifiers

This should be supported naturally for collection injection.

Example registrations:

```python
@injectable(as_type=Cache, tags={"all"})
class MemoryCache: ...


@injectable(as_type=Cache, qualifier="redis", tags={"all", "distributed"})
class RedisCache: ...
```

Then:

- `Sequence[Cache]` gives both
- `Annotated[Sequence[Cache], Inject(tag="distributed")]` gives only `RedisCache`
- `Mapping[Hashable, Cache]` gives `{None: MemoryCache(...), "redis": RedisCache(...)}`
- `Annotated[Mapping[Hashable, Cache], Inject(tag="distributed")]` gives `{"redis": RedisCache(...)}`

That is exactly the kind of orthogonality Wireup should want.

## Multiple Tags

An implementation should be allowed to have multiple tags:

```python
@injectable(as_type=Exporter, tags={"telemetry", "async", "critical"})
class SentryExporter: ...
```

This is important because tags are most useful as overlapping groups, not just one namespace of mutually-exclusive labels.

I would keep matching semantics simple:

- `Inject(tag="telemetry")` means membership in that one tag

I would not add boolean tag expressions for v1:

- no `all_of`
- no `any_of`
- no `exclude`
- no query language

Those can always be built later if real pressure appears, but they are not needed to make tagging valuable.

## Empty Collections vs Errors

I strongly prefer empty collections over errors when a tag matches nothing.

Why:

- tagged collection injection is naturally group-oriented
- group-oriented APIs are often optional by design
- an empty collection composes well in plugin, pipeline, and hook systems

If a user wants to require at least one tagged implementation, that is better expressed in application code:

```python
if not handlers:
    raise RuntimeError("At least one payments handler must be registered")
```

That keeps the framework primitive simple.

## Should Tags Be A New Public Marker Type?

I do not think so.

Avoid shapes like:

- `Tagged[T, "payments"]`
- `Sequence[Tagged[T, "payments"]]`
- `Tag("payments")` in the type itself

Those create more surface area and a more exotic mental model.

Wireup already has a good place for injection-specific refinements:

- `Inject(...)`

So use it.

## How This Fits The Synthetic Factory Model

This feature fits Wireup's synthetic-factory direction very well.

The interesting part is that tags do not need to become special resolution behavior in the container core. They can be treated as metadata on registrations, and tagged collections can be synthesized from the base binding set just like other derived shapes.

Conceptually:

- base registrations remain the source of truth
- Wireup synthesizes `Sequence[T]`
- Wireup synthesizes `Mapping[Hashable, T]`
- Wireup could also synthesize tagged views of those collections

That is a strong fit with the current architecture because it means:

- the container does not need new bespoke lookup semantics for every feature
- the compiler does not need to know about tags as a whole new concept everywhere
- derived shapes stay composable

This is probably the most compelling argument for doing tagging in Wireup at all: it can be added in a way that looks like "one more derived collection view" rather than "one more DI mode."

## A Possible Internal Model

This is not an implementation plan, just a shape sketch.

The registry could conceptually track, per binding:

- type
- qualifier
- tags

Then collection synthesis could build:

- `Sequence[T]`
- `Mapping[Hashable, T]`
- tagged subsets of either, driven by an injection annotation like `Inject(tag="payments")`

I would strongly prefer:

- synthesizing on demand for tagged collection requests

over:

- pre-registering every `(type, tag)` collection variant eagerly

Why:

- tags can multiply combinations
- eager synthetic registration for all tags is unnecessary work
- on-demand tagged collection synthesis better reflects that tag selection is a filtered view, not a first-class root registration key in the same way plain `Sequence[T]` is

That said, the external API does not depend on whether the synthesis is eager or lazy.

## Examples

### Plugin group

```python
class StartupHook(Protocol):
    def run(self) -> None: ...


@injectable(as_type=StartupHook, tags={"startup"})
class WarmCacheHook: ...


@injectable(as_type=StartupHook, tags={"startup"})
class LoadModelsHook: ...


@injectable
class StartupRunner:
    def __init__(
        self,
        hooks: Annotated[Sequence[StartupHook], Inject(tag="startup")],
    ) -> None:
        self.hooks = hooks
```

### Keyed tagged group

```python
class Cache(Protocol):
    def source(self) -> str: ...


@injectable(as_type=Cache, tags={"all"})
class MemoryCache: ...


@injectable(as_type=Cache, qualifier="redis", tags={"all", "distributed"})
class RedisCache: ...


@injectable
class DistributedCacheRegistry:
    def __init__(
        self,
        caches: Annotated[Mapping[Hashable, Cache], Inject(tag="distributed")],
    ) -> None:
        self.caches = caches
```

The mapping should contain:

```python
{"redis": RedisCache(...)}
```

## Why This Is Better Than Overloading Qualifiers

Without tags, users may try to encode grouping into qualifiers:

- `"payments/stripe"`
- `"payments/paypal"`
- `"analytics/mixpanel"`

That works poorly because:

- qualifiers are unique identities
- grouping becomes string parsing by convention
- the framework cannot understand the grouping directly

Tags solve that cleanly:

- qualifiers keep doing identity work
- tags do grouping work

That separation of responsibilities is worth having.

## Why This Should Stay Small

It would be easy to let tagging sprawl into:

- tag query languages
- single-resolution tag selection
- tag priorities
- include/exclude filters
- default tags
- tag inheritance

I would avoid all of that at first.

The minimal useful feature is:

- attach tags to registrations
- inject all members of one tag as a sequence or mapping

That is enough to unlock a real class of use cases without diluting Wireup's minimalism.

## Suggested Documentation Language

If this feature is implemented, the docs could introduce it like this:

> Use tags when you want to group multiple implementations without making the tag part of their identity.
> Inject `Annotated[Sequence[T], Inject(tag="x")]` to receive all `T` implementations tagged with `"x"`.
> Inject `Annotated[Mapping[Hashable, T], Inject(tag="x")]` to receive the same set keyed by qualifier.

That is short and clear.

## Final Recommendation

I would design tagging in Wireup like this:

- `@injectable(..., tags={...})`
- `Annotated[Sequence[T], Inject(tag=...)]`
- `Annotated[Mapping[Hashable, T], Inject(tag=...)]`

with these semantics:

- tags are grouping metadata, not identity
- qualifiers remain the only binding identity mechanism
- tag filtering applies only to collections in v1
- empty tagged collections are valid
- mapping keeps the same qualifier-key semantics, including `None` when present
- no extra tag query language for v1

That feels like the smallest useful feature that still fits Wireup's design taste.
