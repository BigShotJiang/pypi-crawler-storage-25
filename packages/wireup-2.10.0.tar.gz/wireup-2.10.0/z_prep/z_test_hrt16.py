from collections import defaultdict
from typing import List, Tuple, Union

Event = Union[
    Tuple[str, str, int],  # ("ADD", user_id, score)
    Tuple[str, int],  # ("TOP", k)
]


class Leaderboard:
    def __init__(self):
        self.top_k_heap = []
        self.rest_heap = []
        self.score_map = defaultdict(int)

    def add(self, user_id: str, score: int) -> None:
        self.score_map[user_id] += score

    def top(self, k: int) -> int:
        # TODO
        return 0


def run(events: List[Event]) -> List[int]:
    lb = Leaderboard()
    res = []

    for event in events:
        if event[0] == "ADD":
            _, user_id, score = event
            lb.add(user_id, score)
        else:  # TOP
            _, k = event
            res.append(lb.top(k))

    return res


events = [
    ("ADD", "alice", 10),
    ("ADD", "bob", 5),
    ("ADD", "alice", 3),
    ("TOP", 2),
    ("ADD", "charlie", 20),
    ("TOP", 2),
]

print(run(events))  # expected: [18, 33]
