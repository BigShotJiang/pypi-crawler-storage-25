from collections import Counter, defaultdict


class Solution:
    def minWindow(self, s: str, t: str) -> str:
        left = 0
        satisfied = set()
        current = defaultdict(int)
        t_counter = Counter(t)
        required_counter = len(t_counter)
        best_index = None
        best_len = len(s)

        for right, rchar in enumerate(s):
            if rchar not in t_counter:
                continue

            current[rchar] += 1
            if current[rchar] >= t_counter[rchar]:
                satisfied.add(rchar)

                while len(satisfied) == required_counter:
                    curr_len = right - left + 1

                    if curr_len < best_len:
                        best_len = curr_len
                        best_index = left, right

                    # Check if we can continue shrinking
                    can_shrink = (s[left] not in current) or (current[s[left]] > t_counter[s[left]])

                    if not can_shrink:
                        break

                    if s[left] in current:
                        current[s[left]] -= 1
                        if current[s[left]] < t_counter[s[left]]:
                            satisfied.remove(s[left])

                    left += 1

        return s[best_index[0] : best_index[1] + 1] if best_index else ""


print(Solution().minWindow("ADOBECODEBANC", "ABC"))
print(Solution().minWindow("A", "AA"))
