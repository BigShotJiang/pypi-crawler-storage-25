"""
Concurrency Problem (Hudson River Trading – HRT)
o Implement a multi-threaded producer-consumer model where producers add tasks
to a queue and consumers execute them asynchronously.
"""

from concurrent.futures import ThreadPoolExecutor
from typing import Self


class Consumer:
    def __init__(self) -> None:
        self._free = True

    @property
    def is_free(self) -> bool:
        return self._free

    def __enter__(self) -> Self:
        self._free = False

        return self

    def __exit__(self, *args: object) -> None:
        self._free = True


class Broker:
    def __init__(self) -> None:
        self.consumers = []

    def register_consumer(self, consumer: Consumer) -> None:
        self.consumers.append(consumer)

    def submit_job(self, job_id: int) -> None:
        self.consumers[0].submit_job(job_id)


def create_producer() -> None:
    pass


def create_consumer() -> None:
    pass


with ThreadPoolExecutor(max_workers=10):
    pool.submit()
