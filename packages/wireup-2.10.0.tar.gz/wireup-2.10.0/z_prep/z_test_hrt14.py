def min_subarray_len(target: int, nums: list[int]) -> int:
    """
    Given an array of positive integers nums and a positive integer target,
    return the minimal length of a contiguous subarray of which the sum ≥ target.
    If no such subarray exists, return 0.
    """
    left = 0
    best = float("inf")
    current = 0

    for right, num in enumerate(nums):
        current += num

        while current >= target:
            best = min(best, right - left + 1)
            current -= nums[left]
            left += 1

    return 0 if best == float("inf") else best


# Sample tests
assert min_subarray_len(7, [2, 3, 1, 2, 4, 3]) == 2  # [4,3]
assert min_subarray_len(4, [1, 4, 4]) == 1
assert min_subarray_len(11, [1, 1, 1, 1, 1, 1, 1]) == 0


def subarray_sum(nums: list[int], k: int) -> int:
    """
    Given an integer array nums and an integer k,
    return the total number of subarrays whose sum equals k.
    """


# Sample tests
assert subarray_sum([1, 1, 1], 2) == 2
assert subarray_sum([1, 2, 3], 3) == 2  # [1,2], [3]
assert subarray_sum([1, -1, 0], 0) == 3
