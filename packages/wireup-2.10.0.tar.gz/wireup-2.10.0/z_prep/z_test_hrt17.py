# Functional Programming Challenge (Jane St)
# Write a function that takes a list of numbers and returns a list of running averages


from typing import Iterator


def running_avg(nums: list[int]) -> Iterator[float]:
    running_sum = 0

    for index, num in enumerate(nums, start=1):
        running_sum += num
        yield running_sum / index


for num in running_avg([1, 2, 3]):
    print(num)
