from collections import deque
from typing import List


def max_sliding_window(nums: List[int], k: int) -> List[int]:
    res = []
    dq = deque()

    for idx, num in enumerate(nums):
        while dq and idx - dq[0] >= k:
            dq.popleft()

        while dq and num > nums[dq[-1]]:
            dq.pop()

        dq.append(idx)

        if idx >= k - 1:
            res.append(nums[dq[0]])

    return res


# Sample tests
print(max_sliding_window([1, 3, -1, -3, 5, 3, 6, 7], 3))
assert max_sliding_window([1, 3, -1, -3, 5, 3, 6, 7], 3) == [3, 3, 5, 5, 6, 7]
assert max_sliding_window([1], 1) == [1]
assert max_sliding_window([9, 11], 2) == [11]
assert max_sliding_window([4, -2], 2) == [4]

print(max_sliding_window([7, 2, 4], 2))
assert max_sliding_window([7, 2, 4], 2) == [7, 4]
