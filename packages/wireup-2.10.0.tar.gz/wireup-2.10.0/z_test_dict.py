a = {"foo": object()}

b = dict(a)

b["bar"] = "foo"


print(a, b)
print(a["foo"] is b["foo"])
