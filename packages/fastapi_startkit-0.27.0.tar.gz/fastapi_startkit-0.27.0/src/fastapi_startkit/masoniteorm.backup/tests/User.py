"""User Model"""

from fastapi_startkit.masoniteorm.models import Model


class User(Model):
    """User Model"""

    __fillable__ = ["name", "email", "password"]

    __connection__ = "t"

    __auth__ = "email"

    @property
    def meta(self):
        return 1
