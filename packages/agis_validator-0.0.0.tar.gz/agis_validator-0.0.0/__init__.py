# -*- coding: utf-8 -*-
"""agis-validator modules."""