type ProjectsListResponse = {
  projectsList: string[];
};

type ValidateProjectRepositoryResponse = {
  isValid: boolean;
  repositoryUrls?: string[];
};

export { ProjectsListResponse, ValidateProjectRepositoryResponse };
