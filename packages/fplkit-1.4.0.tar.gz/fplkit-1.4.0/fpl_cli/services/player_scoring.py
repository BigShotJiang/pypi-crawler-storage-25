"""Centralised player scoring engine.

All scoring formulas live here: quality baseline, target, differential,
waiver, captain, and bench. Agents build PlayerEvaluation objects and
delegate scoring to this module.
"""

from __future__ import annotations

import asyncio
import dataclasses
import functools
from collections.abc import Mapping
from math import inf
from typing import TYPE_CHECKING, Any, Literal, cast, overload

if TYPE_CHECKING:
    from fpl_cli.api.core_insights import MatchRecord
    from fpl_cli.models.player import Player
    from fpl_cli.models.types import CaptainCandidate, FixtureDetail
    from fpl_cli.services.fixture_predictions import PredictionLookup
    from fpl_cli.services.player_prior import PlayerPrior
    from fpl_cli.services.team_ratings import TeamRatingsService


# ---------------------------------------------------------------------------
# Weight types
# ---------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True)
class StatWeight:
    """A (multiplier, cap) pair for a single scoring component."""

    multiplier: float
    cap: float = inf


@dataclasses.dataclass(frozen=True)
class QualityWeights:
    """Weight configuration for the shared player quality baseline.

    Each field is a StatWeight(multiplier, cap) controlling how that
    stat contributes to the quality score. Agents define their own
    module-level instances with different weights.
    """

    npxg: StatWeight
    xg_chain: StatWeight
    xgi_fallback: StatWeight
    form: StatWeight
    ppg: StatWeight
    dc_per_90: StatWeight = dataclasses.field(default_factory=lambda: StatWeight(0, 0))
    penalty_xg: StatWeight = dataclasses.field(default_factory=lambda: StatWeight(0, 0))
    gk_saves_per_90: StatWeight = dataclasses.field(default_factory=lambda: StatWeight(0, 0))
    gk_xgc_quality: StatWeight = dataclasses.field(default_factory=lambda: StatWeight(0, 0))
    gk_cs_rate: StatWeight = dataclasses.field(default_factory=lambda: StatWeight(0, 0))

    @functools.lru_cache(maxsize=None)
    def without_xgi(self) -> QualityWeights:
        """Return a copy with xGI-family weights zeroed and DC/90 activated (for DEF)."""
        zero = StatWeight(0, 0)
        return dataclasses.replace(
            self,
            npxg=zero,
            xg_chain=zero,
            xgi_fallback=zero,
            dc_per_90=StatWeight(0.5, 2),
            penalty_xg=zero,
            gk_saves_per_90=zero,
            gk_xgc_quality=zero,
            gk_cs_rate=zero,
        )

    @functools.lru_cache(maxsize=None)
    def for_gk(self) -> QualityWeights:
        """Return a copy with GK-specific signals activated (for GK scoring path).

        Zeroes: xGI family, dc_per_90, penalty_xg.
        Activates: gk_saves_per_90, gk_xgc_quality, gk_cs_rate.
        Preserves: form, ppg from the parent instance.
        """
        zero = StatWeight(0, 0)
        return dataclasses.replace(
            self,
            npxg=zero,
            xg_chain=zero,
            xgi_fallback=zero,
            dc_per_90=zero,
            penalty_xg=zero,
            gk_saves_per_90=StatWeight(1.5, 6),
            gk_xgc_quality=StatWeight(3.0, 3.5),
            # Halved 2026-04-10: was (8.0, 4.0) - a Phase 1 placeholder that
            # put 50%-CS GKs within 0.8pt of the cap, crowding out xGI signals.
            # At mult=4 the theoretical cap is unchanged (min(1.0*4, 4)=4) so
            # ceiling constants stay valid; only sub-cap contributions drop.
            gk_cs_rate=StatWeight(4.0, 4.0),
        )


# ---------------------------------------------------------------------------
# Weight configurations (moved from agent modules)
# ---------------------------------------------------------------------------

TARGET_QUALITY_WEIGHTS = QualityWeights(
    npxg=StatWeight(10, 8),
    xg_chain=StatWeight(2, 3),
    xgi_fallback=StatWeight(10, 10),
    form=StatWeight(1.0, 5),
    ppg=StatWeight(0.5, 4),
    dc_per_90=StatWeight(0, 0),
    penalty_xg=StatWeight(8, 3),
)

DIFFERENTIAL_QUALITY_WEIGHTS = QualityWeights(
    npxg=StatWeight(10, 8),
    xg_chain=StatWeight(2, 3),
    xgi_fallback=StatWeight(10, 10),
    form=StatWeight(1.3, 7),
    ppg=StatWeight(0.5, 4),
    dc_per_90=StatWeight(0, 0),
    penalty_xg=StatWeight(8, 3),
)

WAIVER_QUALITY_WEIGHTS = QualityWeights(
    npxg=StatWeight(5),
    xg_chain=StatWeight(2, 3),
    xgi_fallback=StatWeight(5),
    form=StatWeight(1.3, 7),
    ppg=StatWeight(0.6, 4.8),
    dc_per_90=StatWeight(0, 0),
    penalty_xg=StatWeight(8, 3),
)

GW_SELECTION_WEIGHTS = QualityWeights(
    npxg=StatWeight(5, 10),
    xg_chain=StatWeight(0, 0),
    xgi_fallback=StatWeight(5, 10),
    form=StatWeight(1.5, 10),
    ppg=StatWeight(0, 0),
    dc_per_90=StatWeight(0, 0),
    penalty_xg=StatWeight(8, 3),
)

VALUE_QUALITY_WEIGHTS = QualityWeights(
    npxg=StatWeight(10, 8),
    xg_chain=StatWeight(1, 2),
    xgi_fallback=StatWeight(10, 10),
    form=StatWeight(1.3, 7),
    ppg=StatWeight(0.8, 5),
    dc_per_90=StatWeight(0, 0),
    penalty_xg=StatWeight(8, 3),
)

# Position multiplier: adjusts ceiling for per-game scoring potential (captain + bench)
Position = Literal["GK", "DEF", "MID", "FWD"]

POSITION_SCORE_MULTIPLIER: dict[str, float] = {
    "FWD": 1.0,
    "MID": 1.0,
    "DEF": 0.85,
    "GK": 0.7,
}


def _as_position(value: str) -> Position:
    """Narrow an enum-derived position string to the Position literal.

    Raises ValueError on unknown values (e.g. the "???" fallback from
    Player.position_name when the FPL enum is out of sync). Callers
    passing a known PlayerPosition-derived string should never trip this.
    """
    if value not in POSITION_SCORE_MULTIPLIER:
        raise ValueError(f"Unknown position: {value!r}")
    return cast(Position, value)


def _position_from_element_type(element_type: int) -> Position:
    """Resolve FPL element_type to Position literal, raising on unknown values.

    Single choke point shared by build_player_evaluation, squad_allocator, and
    player_prior so every PlayerPosition.value -> Position conversion raises
    ValueError (not KeyError) uniformly.
    """
    from fpl_cli.models.player import POSITION_MAP

    raw = POSITION_MAP.get(element_type)
    if raw is None:
        raise ValueError(f"Unknown FPL element_type {element_type!r} has no position mapping")
    return _as_position(raw)


ATTACKING_POSITIONS: frozenset[str] = frozenset({"MID", "FWD"})


# ---------------------------------------------------------------------------
# Normalisation ceilings (SGW theoretical max, MID/FWD path)
# ---------------------------------------------------------------------------

# Captain: (matchup 8*2.0 + form min(7.5*1.5,10)*1.38 + xGI ~3.5 + pen ~1.2)
#   * pos 1.0 * mins 1.0 + home 1.0 + cv_lineup 0.375
CAPTAIN_CEILING_SGW = 34.2
# Target: npxg 8 + xg_chain 3 + form 5*1.38 + ppg 4 + penalty 3 + matchup 6 + cv_target 0.75
TARGET_CEILING = 31.7
# Differential: npxg 8 + xg_chain 3 + form 7*1.38 + ppg 4 + penalty 3 + ownership 5 + matchup 6 + cv_diff 0.375
DIFFERENTIAL_CEILING = 39.1
# Waiver: quality ~25.7 (form 7*1.38) + matchup 6 + position 5 + cv_target 0.75 = 37.5
WAIVER_CEILING = 37.5
# Bench: core ~32.8 + cv_lineup 0.375 + coverage 2 + set-piece 0.5 + floor 0.75 + inv 0.375 = 36.8
BENCH_CEILING = 36.8
# Starting XI: core ~32.8 + cv_lineup 0.375, no bench bonuses
STARTING_XI_CEILING = 33.2
# Value: npxg 8 + xg_chain 2 + form 7*1.38 + ppg 5 + penalty 3 = 27.7 theoretical
# Practical ceiling ~24.3 (elite MID scores ~20 raw). Validated: Salah-tier -> 87-92/100
VALUE_CEILING = 24.3

# Non-quality bonus caps used when deriving ceiling constants. Keep in sync
# with _matchup_bonus, the ownership bonus in _calculate_quality_based_raw,
# and the position-need bonus in calculate_waiver_score.
_MATCHUP_MAX = 6.0           # matchup_avg_3gw max 8.0 * 0.75 * mins_factor 1.0
_OWNERSHIP_MAX = 5.0         # (semi_differential_threshold 15 - 0) / divisor 3
_POSITION_NEED_MAX = 5.0     # calculate_waiver_score empty-slot bonus
# Form multipliers applied inside calculate_player_quality_score. The ATK
# path gets form_trajectory_max(1.2) * xgi_sustainability_max(1.15) = 1.38;
# GK/DEF paths get form_trajectory_max only because compute_xgi_sustainability
# returns 1.0 for non-ATK positions. The ATK form ceiling is hand-rolled into
# the TARGET/DIFFERENTIAL/VALUE constants above (see the `form N*1.38` terms);
# _NON_ATK_FORM_MAX is used by _gk_quality_cap and _def_quality_cap below.
_NON_ATK_FORM_MAX = 1.2

# Consistency bonus headroom — added inside _calculate_quality_based_raw.
# cv_xgi_percentile in [0,1] × magnitude × 0.5 = max bonus. Value family
# skips _calculate_quality_based_raw entirely and takes no consistency term.
_CONSISTENCY_MAX_TARGET = 0.75   # (1.0 - 0.5) * CONSISTENCY_CV_TARGET (1.5)
_CONSISTENCY_MAX_DIFF = 0.375    # (1.0 - 0.5) * CONSISTENCY_CV_DIFF (0.75)
_CONSISTENCY_MAX_WAIVER = 0.75   # waiver uses CONSISTENCY_CV_TARGET too


def _gk_quality_cap(weights: QualityWeights) -> float:
    """Theoretical max of calculate_player_quality_score on the GK path.

    Derived from weight caps, pre-attenuation. Matches the signal set
    evaluated inside calculate_player_quality_score when weights.for_gk()
    is used: saves, xgc, cs, form (trajectory only — xgi_sustainability
    is always 1.0 for GK, see compute_xgi_sustainability), ppg.
    """
    gk = weights.for_gk()
    return (
        gk.gk_saves_per_90.cap
        + gk.gk_xgc_quality.cap
        + gk.gk_cs_rate.cap
        + gk.form.cap * _NON_ATK_FORM_MAX
        + gk.ppg.cap
    )


def _def_quality_cap(weights: QualityWeights) -> float:
    """Theoretical max of calculate_player_quality_score on the DEF path.

    Matches the signal set under weights.without_xgi(): form (trajectory
    only — xgi_sustainability is always 1.0 for DEF), ppg, and
    dc_per_90. xGI family, GK components and penalty_xg are zeroed by
    without_xgi().
    """
    defw = weights.without_xgi()
    return (
        defw.form.cap * _NON_ATK_FORM_MAX
        + defw.ppg.cap
        + defw.dc_per_90.cap
    )


# Position-specific ceilings — derived at import so a weight change
# auto-propagates. Quality components attenuated by
# POSITION_SCORE_MULTIPLIER[position]; matchup, ownership and
# position-need bonuses are added un-attenuated. Drift is guarded
# empirically by TestCeilingValidationBands (elite-player bounds).
_GK_MULT = POSITION_SCORE_MULTIPLIER["GK"]
_DEF_MULT = POSITION_SCORE_MULTIPLIER["DEF"]
# Ownership-family ceilings include _CONSISTENCY_MAX_* headroom so a top-pool
# player with high cv_xgi_percentile does not overflow the ceiling and get
# silently clamped to 100 (losing the consistency signal's discrimination).
# MID/FWD TARGET_CEILING / DIFFERENTIAL_CEILING / WAIVER_CEILING already bake
# this in (see the cv_* terms in their derivation comments above); GK and DEF
# must add it explicitly because their caps are computed programmatically.
GK_TARGET_CEILING = (
    _gk_quality_cap(TARGET_QUALITY_WEIGHTS) * _GK_MULT + _MATCHUP_MAX + _CONSISTENCY_MAX_TARGET
)
GK_DIFFERENTIAL_CEILING = (
    _gk_quality_cap(DIFFERENTIAL_QUALITY_WEIGHTS) * _GK_MULT
    + _OWNERSHIP_MAX + _MATCHUP_MAX + _CONSISTENCY_MAX_DIFF
)
GK_WAIVER_CEILING = (
    _gk_quality_cap(WAIVER_QUALITY_WEIGHTS) * _GK_MULT
    + _MATCHUP_MAX + _POSITION_NEED_MAX + _CONSISTENCY_MAX_WAIVER
)
# Value family has no matchup or consistency — compute_quality_value skips
# _calculate_quality_based_raw entirely.
GK_VALUE_CEILING = _gk_quality_cap(VALUE_QUALITY_WEIGHTS) * _GK_MULT

# DEF ceilings: derived from without_xgi() caps, not MID-anchored ceilings.
# Replaces the former _position_ceiling("DEF", ...) scaling which produced a
# mathematical no-op on the VALUE family (both numerator and denominator
# scaled by 0.85) and a MID-anchored ceiling on target/diff/waiver that
# compressed real DEF pools into a narrow upper band.
DEF_TARGET_CEILING = (
    _def_quality_cap(TARGET_QUALITY_WEIGHTS) * _DEF_MULT + _MATCHUP_MAX + _CONSISTENCY_MAX_TARGET
)
DEF_DIFFERENTIAL_CEILING = (
    _def_quality_cap(DIFFERENTIAL_QUALITY_WEIGHTS) * _DEF_MULT
    + _OWNERSHIP_MAX + _MATCHUP_MAX + _CONSISTENCY_MAX_DIFF
)
DEF_WAIVER_CEILING = (
    _def_quality_cap(WAIVER_QUALITY_WEIGHTS) * _DEF_MULT
    + _MATCHUP_MAX + _POSITION_NEED_MAX + _CONSISTENCY_MAX_WAIVER
)
DEF_VALUE_CEILING = _def_quality_cap(VALUE_QUALITY_WEIGHTS) * _DEF_MULT

# ---------------------------------------------------------------------------
# Consistency scoring magnitudes (Phase 2)
# ---------------------------------------------------------------------------
# All enter as additive bonuses: (signal - 0.5) * magnitude.
# Phase-in: linear ramp from GW6 (0%) to GW10 (100%).

CONSISTENCY_CV_TARGET = 1.5       # target/waiver: cv_xgi_percentile
CONSISTENCY_CV_LINEUP = 0.75      # captain/bench/lineup tiebreaker
CONSISTENCY_CV_DIFF = 0.75        # differential: inverted (0.5 - cv)
CONSISTENCY_FLOOR_BENCH = 1.5     # bench: floor_percentile
CONSISTENCY_INV_BENCH = 0.75      # bench: involvement_rate

# Phase-in window: no effect at GW5 or earlier, full effect at GW10+
CONSISTENCY_PHASE_IN_START = 5
CONSISTENCY_PHASE_IN_END = 10


def _consistency_phase(gw: int) -> float:
    """Linear phase-in factor for consistency bonuses (0.0 at GW5, 1.0 at GW10+)."""
    window = CONSISTENCY_PHASE_IN_END - CONSISTENCY_PHASE_IN_START
    return min(1.0, max(0.0, (gw - CONSISTENCY_PHASE_IN_START) / window))


# Valid formations: (DEF, MID, FWD). GK always 1.
# Ordered from most attacking to most defensive for deterministic tiebreaking.
VALID_FORMATIONS: list[tuple[int, int, int]] = [
    (3, 4, 3),
    (3, 5, 2),
    (4, 3, 3),
    (4, 4, 2),
    (4, 5, 1),
    (5, 3, 2),
    (5, 4, 1),
]

# Max PL gameweeks in a season (caps derived appearances)
MAX_GAMEWEEKS = 38

# FDR thresholds for fixture difficulty classification
FDR_EASY = 2.5
FDR_MEDIUM = 3.5

# Default FDR mode used by all scoring agents (difference = team+opponent axis)
FDR_MODE = "difference"


# ---------------------------------------------------------------------------
# ScoringContext - shared data preparation infrastructure
# ---------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True)
class ScoringContext:
    """Pre-fetched data shared across player scoring within a single agent run.

    Agents build one context per run, then pass it to helper functions
    (build_fixture_matchups, compute_aggregate_matchup) for per-player work.
    """

    team_map: dict[int, Any]  # team_id -> Team model
    team_fixture_map: dict[int, list[dict[str, Any]]]  # team_id -> [{fixture, is_home}]
    ratings_service: TeamRatingsService

    # Optional enrichments (None when not requested)
    team_form_by_id: dict[int, dict[str, Any]] | None = None
    understat_lookup: dict[int, dict[str, Any]] | None = None
    gw_fixture_maps: list[dict[int, list[dict[str, Any]]]] | None = None
    next_gw_id: int | None = None
    prediction_lookup: PredictionLookup | None = None


async def build_scoring_context(
    *,
    teams: list[Any],
    fixtures: list[Any],
    ratings_service: Any,
    next_gw_id: int,
    all_fixtures: list[Any] | None = None,
    include_team_form: bool = False,
    understat_lookup: dict[int, dict[str, Any]] | None = None,
    prediction_lookup: PredictionLookup | None = None,
    team_map: dict[int, Any] | None = None,
) -> ScoringContext:
    """Build shared scoring context from pre-fetched data.

    Args:
        teams: List of Team models from FPL API.
        fixtures: Next-GW fixtures (used for team_fixture_map).
        ratings_service: TeamRatingsService instance.
        next_gw_id: Next gameweek ID.
        all_fixtures: All fixtures (needed for 3-GW matchup window).
        include_team_form: Whether to compute team form (needed for matchup scores).
        understat_lookup: Pre-built understat lookup (agent-owned, passed in).
        prediction_lookup: Pre-built fixture prediction lookup from
            build_prediction_lookup (gw -> team_id -> (type, multiplier)).
        team_map: Pre-built team_id -> Team map. Built internally if not provided.
    """
    from fpl_cli.services.matchup import build_gw_fixture_maps, build_team_fixture_map

    if team_map is None:
        team_map = {t.id: t for t in teams}
    team_fixture_map = build_team_fixture_map(fixtures)

    team_form_by_id: dict[int, dict[str, Any]] | None = None
    if include_team_form:
        from fpl_cli.services.team_form import calculate_team_form

        team_form_list = calculate_team_form(all_fixtures or fixtures, teams)
        team_form_by_id = {tf["team_id"]: tf for tf in team_form_list}

    gw_fixture_maps = None
    if all_fixtures is not None:
        gw_fixture_maps = build_gw_fixture_maps(all_fixtures, next_gw_id)

    return ScoringContext(
        team_map=team_map,
        team_fixture_map=team_fixture_map,
        ratings_service=ratings_service,
        team_form_by_id=team_form_by_id,
        understat_lookup=understat_lookup,
        gw_fixture_maps=gw_fixture_maps,
        next_gw_id=next_gw_id,
        prediction_lookup=prediction_lookup,
    )


_UNDERSTAT_FIELDS = ("npxG_per_90", "xGChain_per_90", "penalty_xG_per_90")


async def build_understat_by_player_id(
    all_players: list[Player],
    team_map: dict[int, Any],
    *,
    fields: tuple[str, ...] = _UNDERSTAT_FIELDS,
) -> dict[int, dict[str, float]]:
    """Build {player_id: {field: value}} from Understat for all players.

    Wraps fetch_understat_lookup with the standard Player-model adapter
    and field extraction. Returns only players with at least one matched field.
    """
    from fpl_cli.agents.common import fetch_understat_lookup

    us_adapter = [
        {
            "player_name": p.web_name,
            "position": p.position_name,
            "minutes": p.minutes,
            "_team_id": p.team_id,
        }
        for p in all_players
    ]
    us_lookup = await fetch_understat_lookup(
        us_adapter,
        lambda p: (team_map.get(p["_team_id"]).name  # type: ignore[union-attr]
                   if team_map.get(p["_team_id"]) else None),
    )
    result: dict[int, dict[str, float]] = {}
    for i, us_match in us_lookup.items():
        pid = all_players[i].id
        data: dict[str, float] = {}
        for key in fields:
            val = us_match.get(key)
            if val is not None:
                data[key] = val
        if data:
            result[pid] = data
    return result


@dataclasses.dataclass(frozen=True)
class ConsistencySignals:
    """Per-player consistency signal values (Phase 1: display only)."""

    cv_xgi_percentile: float = 0.5
    blank_rate: float | None = None
    floor_percentile: float = 0.5
    involvement_rate: float | None = None
    gk_consistency_percentile: float = 0.5


NEUTRAL_SIGNALS = ConsistencySignals()


@dataclasses.dataclass(frozen=True)
class ScoringData:
    """Pre-fetched base data shared across all scoring agents.

    Returned by ``prepare_scoring_data`` to replace the duplicated
    fetch-then-build blocks in each agent's ``run()`` method.
    """

    teams: list[Any]
    team_map: dict[int, Any]
    all_fixtures: list[Any]
    next_gw_fixtures: list[Any]
    next_gw_id: int
    next_gw: dict[str, Any] | None  # raw dict from get_next_gameweek
    scoring_ctx: ScoringContext
    ratings_service: TeamRatingsService

    # Optional - populated when include_players / include_understat /
    # include_history / include_prior / include_match_data is True
    players: list[Player] | None = None
    understat_lookup: dict[int, dict[str, float]] | None = None
    player_histories: dict[int, list[dict[str, Any]]] | None = None
    player_priors: dict[int, PlayerPrior] | None = None
    match_records: dict[int, list[MatchRecord]] | None = None
    adjusted_npxg_lookup: dict[int, float] | None = None
    consistency_lookup: dict[int, ConsistencySignals] | None = None


async def prepare_scoring_data(
    client: Any,
    *,
    include_players: bool = False,
    include_understat: bool = False,
    include_history: bool = False,
    include_prior: bool = False,
    include_match_data: bool = False,
) -> ScoringData:
    """Fetch common base data and build a ScoringContext.

    Consolidates the 5+ API calls and ScoringContext construction that
    every scoring agent duplicates.  Agent-specific data (draft players,
    custom Understat fields) stays agent-owned.

    Args:
        client: FPLClient instance for API calls.
        include_players: Fetch all players via ``get_players()``.
        include_understat: Build understat lookup (requires include_players).
        include_history: Fetch per-GW history for players with minutes > 0.
        include_prior: Generate Bayesian player priors (requires include_players).
        include_match_data: Fetch Core-Insights match-level CSVs and compute the
            fixture-adjusted npxG lookup (requires include_players).

    Raises:
        ValueError: If include_understat or include_prior is True but include_players is False.
    """
    if include_understat and not include_players:
        msg = "include_understat requires include_players"
        raise ValueError(msg)
    if include_prior and not include_players:
        msg = "include_prior requires include_players"
        raise ValueError(msg)

    from fpl_cli.services.team_ratings import TeamRatingsService

    teams = await client.get_teams()
    all_fixtures = await client.get_fixtures()
    next_gw = await client.get_next_gameweek()
    next_gw_id = next_gw["id"] if next_gw else 38

    next_gw_fixtures = [f for f in all_fixtures if f.gameweek == next_gw_id] if next_gw else []

    ratings_service = TeamRatingsService()
    await ratings_service.ensure_fresh(client)

    # Build fixture prediction lookup before ScoringContext (frozen dataclass)
    from fpl_cli.services.fixture_predictions import (
        FixturePredictionsService,
        build_prediction_lookup,
    )

    team_map = {t.id: t for t in teams}
    fps = FixturePredictionsService()
    prediction_lookup = build_prediction_lookup(fps, team_map, min_gw=next_gw_id)

    scoring_ctx = await build_scoring_context(
        teams=teams,
        fixtures=next_gw_fixtures,
        ratings_service=ratings_service,
        next_gw_id=next_gw_id,
        all_fixtures=all_fixtures,
        include_team_form=True,
        prediction_lookup=prediction_lookup,
        team_map=team_map,
    )

    players: list[Player] | None = None
    understat_lookup: dict[int, dict[str, float]] | None = None

    if include_players:
        players = await client.get_players()

    if include_understat and players is not None:
        understat_lookup = await build_understat_by_player_id(
            players, scoring_ctx.team_map,
        )

    player_histories: dict[int, list[dict[str, Any]]] | None = None

    if include_history:
        history_players = players if players is not None else await client.get_players()
        candidates = [p for p in history_players if p.minutes > 0]

        player_histories = {}
        batch_size = 50
        for i in range(0, len(candidates), batch_size):
            batch = candidates[i : i + batch_size]
            tasks = [client.get_player_detail(p.id) for p in batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for p, result in zip(batch, results):
                if isinstance(result, dict):
                    player_histories[p.id] = result.get("history", [])

    player_priors: dict[int, PlayerPrior] | None = None

    if include_prior and players is not None:
        try:
            from fpl_cli.api.historical import make_historical_provider
            from fpl_cli.services.player_prior import generate_player_prior, load_cached_priors

            cached = load_cached_priors(next_gw_id)
            if cached is not None:
                player_priors = cached
            else:
                from fpl_cli.season import season_label
                from fpl_cli.services.player_prior import _save_prior_cache

                async with make_historical_provider() as historical:
                    profiles = await historical.get_all_player_histories()
                player_priors = generate_player_prior(profiles, players, next_gw_id)
                _save_prior_cache(player_priors, season_label(), next_gw_id)
        except Exception:  # noqa: BLE001 — graceful degradation: vaastav unavailable
            import logging

            logging.getLogger(__name__).warning(
                "Failed to generate player priors", exc_info=True,
            )

    match_records: dict[int, list[MatchRecord]] | None = None
    adjusted_npxg_lookup: dict[int, float] | None = None
    consistency_lookup: dict[int, ConsistencySignals] | None = None

    if include_match_data and players is not None:
        match_records = await fetch_match_records(next_gw_id)
        if match_records:
            median_elo = compute_median_elo(match_records)
            adjusted_npxg_lookup = build_adjusted_npxg_lookup(
                match_records, next_gw_id, median_elo,
            )
            position_map = {p.id: p.position_name for p in players}
            consistency_lookup = build_consistency_lookup(
                match_records, player_histories, position_map,
                next_gw_id, median_elo,
            )

    return ScoringData(
        teams=teams,
        team_map=scoring_ctx.team_map,
        all_fixtures=all_fixtures,
        next_gw_fixtures=next_gw_fixtures,
        next_gw_id=next_gw_id,
        next_gw=next_gw,
        scoring_ctx=scoring_ctx,
        ratings_service=ratings_service,
        players=players,
        understat_lookup=understat_lookup,
        player_histories=player_histories,
        player_priors=player_priors,
        match_records=match_records,
        adjusted_npxg_lookup=adjusted_npxg_lookup,
        consistency_lookup=consistency_lookup,
    )


# ---------------------------------------------------------------------------
# View-building helpers (use ScoringContext)
# ---------------------------------------------------------------------------


def build_fixture_matchups(
    player_team_id: int,
    position: str,
    context: ScoringContext,
) -> list[FixtureMatchup]:
    """Build per-fixture FixtureMatchup objects from shared context.

    Uses positional FDR (not avg_overall_fdr) and computes matchup scores
    when team form is available.
    """
    from fpl_cli.services.matchup import calculate_matchup_score

    fixtures = context.team_fixture_map.get(player_team_id, [])
    if not fixtures:
        return []

    player_team = context.team_map.get(player_team_id)
    player_team_form = (
        context.team_form_by_id.get(player_team_id, {})
        if context.team_form_by_id
        else {}
    )

    matchups: list[FixtureMatchup] = []
    for f_data in fixtures:
        fixture = f_data["fixture"]
        is_home = f_data["is_home"]
        opponent_id = fixture.away_team_id if is_home else fixture.home_team_id
        opponent = context.team_map.get(opponent_id)

        opponent_short = opponent.short_name if opponent else "???"
        team_short = player_team.short_name if player_team else ""
        venue = "home" if is_home else "away"

        # Positional FDR (falls back to 4.0 inside ratings_service)
        opponent_fdr = context.ratings_service.get_positional_fdr(
            position=position,
            team=team_short,
            opponent=opponent_short,
            venue=venue,
            mode=FDR_MODE,
        )

        # Matchup score from team form (requires both teams' form data)
        opponent_form = (
            context.team_form_by_id.get(opponent_id, {})
            if context.team_form_by_id
            else {}
        )
        if player_team_form and opponent_form:
            matchup = calculate_matchup_score(
                player_team_form, opponent_form, position, is_home,
            )
        else:
            matchup = {"matchup_score": 5.0}

        matchups.append(FixtureMatchup(
            opponent_short=opponent_short,
            is_home=is_home,
            opponent_fdr=opponent_fdr,
            matchup_score=matchup["matchup_score"],
            matchup_breakdown=matchup,
        ))

    return matchups


def compute_aggregate_matchup(
    team_id: int,
    position: str,
    context: ScoringContext,
    *,
    matchup_cache: dict[tuple[int, str], float] | None = None,
) -> tuple[float | None, float | None]:
    """Compute aggregate matchup data: (matchup_avg_3gw, positional_fdr).

    Used by stats/waiver agents that need scalar matchup values rather than
    per-fixture FixtureMatchup objects.

    matchup_cache is updated in-place when provided (team+position dedup).
    """
    from fpl_cli.services.matchup import compute_3gw_matchup

    matchup_avg_3gw: float | None = None
    positional_fdr: float | None = None

    # 3-GW weighted matchup
    if context.gw_fixture_maps is not None and context.team_form_by_id is not None:
        cache_key = (team_id, position)
        if matchup_cache is not None and cache_key in matchup_cache:
            matchup_avg_3gw = matchup_cache[cache_key]
        else:
            val = compute_3gw_matchup(
                team_id=team_id,
                all_fixtures=[],  # Not used when gw_fixture_maps provided
                next_gw_id=context.next_gw_id or 38,
                team_form_by_id=context.team_form_by_id,
                position=position,
                gw_fixture_maps=context.gw_fixture_maps,
                predictions=context.prediction_lookup,
            )
            matchup_avg_3gw = round(val, 2)
            if matchup_cache is not None:
                matchup_cache[cache_key] = matchup_avg_3gw

    # Positional FDR from first next-GW fixture
    fixtures = context.team_fixture_map.get(team_id, [])
    if fixtures:
        f_data = fixtures[0]
        fixture = f_data["fixture"]
        is_home = f_data["is_home"]
        opp_id = fixture.away_team_id if is_home else fixture.home_team_id
        opp_team = context.team_map.get(opp_id)
        player_team = context.team_map.get(team_id)

        if opp_team and player_team:
            positional_fdr = round(
                context.ratings_service.get_positional_fdr(
                    position=position,
                    team=player_team.short_name,
                    opponent=opp_team.short_name,
                    venue="home" if is_home else "away",
                    mode=FDR_MODE,
                ),
                1,
            )

    return matchup_avg_3gw, positional_fdr


# ---------------------------------------------------------------------------
# Shared scoring functions
# ---------------------------------------------------------------------------


def calculate_player_quality_score(
    player: Mapping[str, Any],
    weights: QualityWeights,
    mins_factor: float = 1.0,
    *,
    position: Position | None = None,
) -> float:
    """Shared baseline quality score from form, PPG, and xGI/npxG.

    Pure computation - does not round. Callers add context-specific
    adjustments and handle rounding themselves.

    mins_factor scales per-90 attacking components (npxG, xGChain, xGI
    fallback, penalty_xG) to discount inflated rates from low-minutes
    players. Form, ppg, dc_per_90, and GK signals (saves, xgc_quality,
    cs_rate) are unscaled. When *position* is supplied the final score
    is attenuated by POSITION_SCORE_MULTIPLIER[position]. Default None
    is for formula unit tests that pass naked dicts without a position.
    """
    per90 = 0.0

    npxg = player.get("npxG_per_90")
    if npxg is not None:
        per90 += min(npxg * weights.npxg.multiplier, weights.npxg.cap)
        xg_chain = player.get("xGChain_per_90") or 0
        per90 += min(xg_chain * weights.xg_chain.multiplier, weights.xg_chain.cap)
    else:
        xgi = player.get("xGI_per_90", 0) or 0
        per90 += min(xgi * weights.xgi_fallback.multiplier, weights.xgi_fallback.cap)

    if weights.penalty_xg.multiplier > 0:
        pen = player.get("penalty_xG_per_90") or 0
        per90 += min(pen * weights.penalty_xg.multiplier, weights.penalty_xg.cap)

    score = per90 * mins_factor

    form_trajectory = player.get("form_trajectory", 1.0)
    xgi_sustainability = player.get("xgi_sustainability", 1.0)
    capped_form = min(player.get("form", 0) * weights.form.multiplier, weights.form.cap)
    score += capped_form * form_trajectory * xgi_sustainability
    score += min(player.get("ppg", 0) * weights.ppg.multiplier, weights.ppg.cap)

    if weights.dc_per_90.multiplier > 0:
        dc = player.get("dc_per_90", 0) or 0
        score += min(dc * weights.dc_per_90.multiplier, weights.dc_per_90.cap)

    if weights.gk_saves_per_90.multiplier > 0:
        sv = player.get("gk_saves_per_90", 0) or 0
        score += min(sv * weights.gk_saves_per_90.multiplier, weights.gk_saves_per_90.cap)

    if weights.gk_xgc_quality.multiplier > 0:
        xgc_q = player.get("gk_xgc_quality", 0) or 0
        score += min(xgc_q * weights.gk_xgc_quality.multiplier, weights.gk_xgc_quality.cap)

    if weights.gk_cs_rate.multiplier > 0:
        cs = player.get("gk_cs_rate", 0) or 0
        score += min(cs * weights.gk_cs_rate.multiplier, weights.gk_cs_rate.cap)

    if position is not None:
        score *= POSITION_SCORE_MULTIPLIER[position]

    return score


def calculate_mins_factor(
    minutes: int,
    appearances: int,
    next_gw_id: int,
) -> float:
    """Minutes-per-appearance factor for rotation risk.

    Returns 1.0 for nailed starters, <1.0 for rotation-prone players,
    0.0 for players with no appearances. Disabled before GW5.
    """
    if next_gw_id <= 5:
        return 1.0
    if appearances <= 0:
        return 0.0
    return min(minutes / (appearances * 80), 1.0)


def _qualifying_window(
    history: list[dict[str, Any]], current_gw: int, size: int = 7,
) -> list[dict[str, Any]]:
    """Recent qualifying GWs: minutes > 0, within 12-GW lookback, most recent *size*."""
    cutoff = current_gw - 12
    qualifying = [
        h
        for h in history
        if h.get("minutes", 0) > 0 and h.get("round", 0) > cutoff
    ]
    qualifying.sort(key=lambda h: h["round"])
    return qualifying[-size:]


def compute_form_trajectory(history: list[dict[str, Any]], current_gw: int) -> float:
    """Trend multiplier from recent gameweek points history.

    Returns a value in [0.8, 1.2] reflecting whether a player is on an
    upward or downward trajectory.  Median-filters outliers (drops highest
    and lowest) to resist one-off hauls / blanks.

    Returns 1.0 (neutral) when fewer than 4 qualifying GWs are available.
    """
    qualifying = _qualifying_window(history, current_gw)

    if len(qualifying) < 4:
        return 1.0

    points = [h.get("total_points", 0) for h in qualifying]

    # Median filter: drop one instance of the max and one of the min.
    # When ties exist, remove the instance closest to the centre of
    # the window (least chronologically informative) to preserve
    # slope signal from edge positions.
    filtered = list(points)
    for target in (max(filtered), min(filtered)):
        centre = (len(filtered) - 1) / 2
        indices = [i for i, v in enumerate(filtered) if v == target]
        drop = min(indices, key=lambda i: abs(i - centre))
        filtered.pop(drop)

    n = len(filtered)
    if n < 2:
        return 1.0

    # Least-squares linear regression
    x_vals = list(range(n))
    x_mean = sum(x_vals) / n
    y_mean = sum(filtered) / n

    numerator = sum((x - x_mean) * (y - y_mean) for x, y in zip(x_vals, filtered))
    denominator = sum((x - x_mean) ** 2 for x in x_vals)

    if denominator == 0:
        return 1.0

    slope = numerator / denominator

    # Clamped linear interpolation to [0.8, 1.2]
    # Neutral at slope=0; rising > 0, falling < 0
    if slope <= -1.5:
        return 0.8
    if slope <= 0.0:
        # -1.5 -> 0.8, 0.0 -> 1.0
        return 0.8 + (slope + 1.5) / 1.5 * 0.2
    if slope <= 2.0:
        # 0.0 -> 1.0, 2.0 -> 1.2
        return 1.0 + slope / 2.0 * 0.2
    return 1.2


def compute_xgi_sustainability(
    history: list[dict[str, Any]], current_gw: int, position: str
) -> tuple[float, float]:
    """Rolling-window xGI sustainability multiplier for ATK players.

    Computes per-match GI-xGI divergence over recent qualifying GWs and maps
    it to a bounded multiplier in [0.85, 1.15].  Positive divergence (GI > xGI)
    indicates overperformance -> regression risk -> multiplier < 1.0.  Negative
    divergence (GI < xGI) indicates underperformance -> upside -> multiplier > 1.0.

    Returns (multiplier, raw_divergence_per_match).  Returns (1.0, 0.0) for
    DEF/GK positions or when fewer than 4 qualifying GWs are available.

    Unlike compute_form_trajectory, no median filtering is applied: the hauls
    that constitute overperformance are the most informative data points.
    """
    if position not in ATTACKING_POSITIONS:
        return 1.0, 0.0

    qualifying = _qualifying_window(history, current_gw)

    if len(qualifying) < 4:
        return 1.0, 0.0

    divergences = [
        (h.get("goals_scored", 0) + h.get("assists", 0))
        - (float(h.get("expected_goals", 0) or 0) + float(h.get("expected_assists", 0) or 0))
        for h in qualifying
    ]
    avg_divergence = sum(divergences) / len(divergences)

    # Linear interpolation: divergence=0 -> 1.0, divergence=±0.3 -> 0.85/1.15
    raw_mult = 1.0 - (avg_divergence / 0.3) * 0.15
    multiplier = max(0.85, min(1.15, raw_mult))

    return multiplier, avg_divergence


# ---------------------------------------------------------------------------
# Consistency signal computation
# ---------------------------------------------------------------------------

_CONSISTENCY_MIN_MATCHES = 6


def compute_median_elo(
    match_records: dict[int, list[MatchRecord]],
) -> float:
    """Median opponent Elo across all match records, or 1700.0 if empty."""
    import statistics

    all_elos = [
        r["opponent_elo"]
        for records in match_records.values()
        for r in records
    ]
    return statistics.median(all_elos) if all_elos else 1700.0


def _elo_adjusted_xgis(
    window: list[MatchRecord], median_elo: float,
) -> list[float]:
    """Elo-adjusted xGI values for each match in the window."""
    adjusted: list[float] = []
    for m in window:
        opp_elo = m.get("opponent_elo", median_elo)
        if opp_elo <= 0:
            opp_elo = median_elo
        factor = max(0.80, min(1.25, median_elo / opp_elo))
        adjusted.append((m.get("xg", 0.0) + m.get("xa", 0.0)) * factor)
    return adjusted


_CONSISTENCY_MIN_MINUTES = 60


def _match_record_window(
    match_records: list[MatchRecord], current_gw: int, size: int = 7,
) -> list[MatchRecord]:
    """Recent qualifying match records: minutes >= 60, within 12-GW lookback, most recent *size*.

    The 60-minute threshold excludes cameo appearances whose low xGI
    reflects limited playing time rather than output inconsistency.
    Aligns with FPL's meaningful-appearance boundary.
    """
    cutoff = current_gw - 12
    qualifying = [
        m for m in match_records
        if m.get("minutes_played", 0) >= _CONSISTENCY_MIN_MINUTES
        and m.get("gameweek", 0) > cutoff
    ]
    qualifying.sort(key=lambda m: m["gameweek"])
    return qualifying[-size:]


def compute_cv_xgi(
    match_records: list[MatchRecord],
    current_gw: int,
    median_elo: float,
) -> float | None:
    """CV of Elo-adjusted xGI over rolling window.

    Returns None when fewer than 6 qualifying matches or mean xGI is zero.
    """
    import statistics

    window = _match_record_window(match_records, current_gw)
    if len(window) < _CONSISTENCY_MIN_MATCHES:
        return None

    adjusted_xgis = _elo_adjusted_xgis(window, median_elo)

    mean = statistics.mean(adjusted_xgis)
    if mean == 0:
        return None

    return statistics.stdev(adjusted_xgis) / mean


def compute_cv_xgi_fallback(
    history: list[dict[str, Any]], current_gw: int,
) -> float | None:
    """CV of raw xGI from FPL API history (no Elo adjustment).

    Fallback for players without Core-Insights match records.
    """
    import statistics

    qualifying = _qualifying_window(history, current_gw)
    if len(qualifying) < _CONSISTENCY_MIN_MATCHES:
        return None

    xgis = [
        float(h.get("expected_goals", 0) or 0)
        + float(h.get("expected_assists", 0) or 0)
        for h in qualifying
    ]

    mean = statistics.mean(xgis)
    if mean == 0:
        return None

    return statistics.stdev(xgis) / mean


def compute_blank_rate(
    history: list[dict[str, Any]], current_gw: int,
) -> float | None:
    """Fraction of qualifying matches with total_points <= 2 (appearance only).

    Always from FPL API history. Returns None when fewer than 6 qualifying GWs.
    """
    qualifying = _qualifying_window(history, current_gw)
    if len(qualifying) < _CONSISTENCY_MIN_MATCHES:
        return None

    blanks = sum(1 for h in qualifying if h.get("total_points", 0) <= 2)
    return blanks / len(qualifying)


def compute_floor_xgi(
    match_records: list[MatchRecord],
    current_gw: int,
    median_elo: float,
) -> float | None:
    """25th percentile of Elo-adjusted per-match xGI.

    Returns None when fewer than 6 qualifying matches.
    """
    window = _match_record_window(match_records, current_gw)
    if len(window) < _CONSISTENCY_MIN_MATCHES:
        return None

    adjusted_xgis = sorted(_elo_adjusted_xgis(window, median_elo))
    idx = (len(adjusted_xgis) - 1) * 0.25
    lower = int(idx)
    frac = idx - lower
    if lower + 1 < len(adjusted_xgis):
        return adjusted_xgis[lower] * (1 - frac) + adjusted_xgis[lower + 1] * frac
    return adjusted_xgis[lower]


def compute_floor_xgi_fallback(
    history: list[dict[str, Any]], current_gw: int,
) -> float | None:
    """25th percentile of raw xGI from FPL API history."""
    qualifying = _qualifying_window(history, current_gw)
    if len(qualifying) < _CONSISTENCY_MIN_MATCHES:
        return None

    xgis = sorted(
        float(h.get("expected_goals", 0) or 0)
        + float(h.get("expected_assists", 0) or 0)
        for h in qualifying
    )

    idx = (len(xgis) - 1) * 0.25
    lower = int(idx)
    frac = idx - lower
    if lower + 1 < len(xgis):
        return xgis[lower] * (1 - frac) + xgis[lower + 1] * frac
    return xgis[lower]


def compute_involvement_rate(
    match_records: list[MatchRecord] | None,
    history: list[dict[str, Any]],
    current_gw: int,
    position: str,
) -> float | None:
    """Position-specific involvement rate over rolling window.

    ATK (FWD/MID): Core-Insights only. Involved = shots >= 1 OR chances >= 1
        OR opposition box touches >= 3.
    DEF: Primary Core-Insights (CBIT + tackles >= 6), fallback FPL API.
    GK: Returns None (handled by compute_gk_consistency).
    """
    if position == "GK":
        return None

    if position in ATTACKING_POSITIONS:
        if not match_records:
            return None
        window = _match_record_window(match_records, current_gw)
        if len(window) < _CONSISTENCY_MIN_MATCHES:
            return None
        involved = sum(
            1
            for m in window
            if (
                m.get("total_shots", 0) >= 1
                or m.get("chances_created", 0) >= 1
                or m.get("touches_opposition_box", 0) >= 3
            )
        )
        return involved / len(window)

    # DEF
    if match_records:
        window = _match_record_window(match_records, current_gw)
        if len(window) >= _CONSISTENCY_MIN_MATCHES:
            involved = sum(
                1
                for m in window
                if (
                    m.get("clearances", 0)
                    + m.get("blocks", 0)
                    + m.get("interceptions", 0)
                    + m.get("tackles_won", 0)
                ) >= 6
            )
            return involved / len(window)

    # DEF fallback: FPL API history
    qualifying = _qualifying_window(history, current_gw)
    if len(qualifying) < _CONSISTENCY_MIN_MATCHES:
        return None

    involved = sum(
        1
        for h in qualifying
        if (
            int(h.get("clearances_blocks_interceptions", 0) or 0)
            + int(h.get("tackles", 0) or 0)
        ) >= 6
    )
    return involved / len(qualifying)


def compute_gk_consistency(
    match_records: list[MatchRecord],
    current_gw: int,
) -> float | None:
    """CV of saves per 90 from Core-Insights match data.

    Returns None when fewer than 6 qualifying matches.
    """
    import statistics

    window = _match_record_window(match_records, current_gw)
    if len(window) < _CONSISTENCY_MIN_MATCHES:
        return None

    saves_per_90: list[float] = []
    for m in window:
        minutes = m.get("minutes_played", 0)
        if minutes == 0:
            continue
        saves_per_90.append(m.get("saves", 0) / (minutes / 90))

    if len(saves_per_90) < _CONSISTENCY_MIN_MATCHES:
        return None

    mean = statistics.mean(saves_per_90)
    if mean == 0:
        return None

    return statistics.stdev(saves_per_90) / mean


_MIN_PERCENTILE_POOL = 15


def _assign_percentile_ranks(
    values: dict[int, float], *, invert: bool = False,
) -> dict[int, float]:
    """Convert raw values to percentile ranks with average-rank tie handling.

    When *invert* is True, lower raw values get higher percentiles
    (used for CV where low = consistent = good).
    """
    if len(values) < _MIN_PERCENTILE_POOL:
        return {pid: 0.5 for pid in values}

    sorted_items = sorted(values.items(), key=lambda x: x[1])
    n = len(sorted_items)

    # Assign ordinal ranks, then average ties
    ordinal: dict[int, int] = {}
    for rank, (pid, _) in enumerate(sorted_items):
        ordinal[pid] = rank

    # Group by value to handle ties
    by_value: dict[float, list[int]] = {}
    for pid, val in sorted_items:
        by_value.setdefault(val, []).append(pid)

    avg_ranks: dict[int, float] = {}
    for pids in by_value.values():
        avg = sum(ordinal[p] for p in pids) / len(pids)
        for p in pids:
            avg_ranks[p] = avg

    result: dict[int, float] = {}
    for pid in values:
        pct = avg_ranks[pid] / (n - 1) if n > 1 else 0.5
        result[pid] = (1.0 - pct) if invert else pct

    return result


def build_consistency_lookup(
    match_records: dict[int, list[MatchRecord]] | None,
    player_histories: dict[int, list[dict[str, Any]]] | None,
    positions: dict[int, str],
    current_gw: int,
    median_elo: float,
) -> dict[int, ConsistencySignals]:
    """Build per-player consistency signals with position-relative percentiles.

    Two-phase: (1) compute raw per-player values, (2) batch percentile
    conversion within position groups. Players with < 6 qualifying matches
    are excluded from the percentile pool and absent from the result
    (callers use NEUTRAL_SIGNALS default).
    """
    mr = match_records or {}
    ph = player_histories or {}
    all_pids = set(mr.keys()) | set(ph.keys())

    # Phase 1: raw per-player values
    raw_cvs: dict[int, float] = {}
    raw_floors: dict[int, float] = {}
    raw_blank_rates: dict[int, float] = {}
    raw_involvement: dict[int, float] = {}
    raw_gk_cv: dict[int, float] = {}

    for pid in all_pids:
        pos = positions.get(pid, "???")
        records = mr.get(pid)
        history = ph.get(pid, [])

        # CV-xGI: primary from match records, fallback from FPL API
        cv = None
        if records:
            cv = compute_cv_xgi(records, current_gw, median_elo)
        if cv is None and history:
            cv = compute_cv_xgi_fallback(history, current_gw)
        if cv is not None:
            raw_cvs[pid] = cv

        # Blank rate: always from FPL API history
        br = compute_blank_rate(history, current_gw) if history else None
        if br is not None:
            raw_blank_rates[pid] = br

        # Floor: primary from match records, fallback from FPL API
        floor = None
        if records:
            floor = compute_floor_xgi(records, current_gw, median_elo)
        if floor is None and history:
            floor = compute_floor_xgi_fallback(history, current_gw)
        if floor is not None:
            raw_floors[pid] = floor

        # Involvement rate
        inv = compute_involvement_rate(records, history, current_gw, pos)
        if inv is not None:
            raw_involvement[pid] = inv

        # GK consistency
        if pos == "GK" and records:
            gk_cv = compute_gk_consistency(records, current_gw)
            if gk_cv is not None:
                raw_gk_cv[pid] = gk_cv

    # Phase 2: percentile conversion by position group
    pos_groups: dict[str, dict[int, float]] = {}
    for pid, cv in raw_cvs.items():
        pos = positions.get(pid, "???")
        pos_groups.setdefault(pos, {})[pid] = cv

    cv_percentiles: dict[int, float] = {}
    for group in pos_groups.values():
        cv_percentiles.update(_assign_percentile_ranks(group, invert=True))

    # Floor percentiles by position (higher floor = higher percentile)
    floor_pos_groups: dict[str, dict[int, float]] = {}
    for pid, floor in raw_floors.items():
        pos = positions.get(pid, "???")
        floor_pos_groups.setdefault(pos, {})[pid] = floor

    floor_percentiles: dict[int, float] = {}
    for group in floor_pos_groups.values():
        floor_percentiles.update(_assign_percentile_ranks(group, invert=False))

    # GK consistency percentiles (single group)
    gk_percentiles = _assign_percentile_ranks(raw_gk_cv, invert=True)

    # Assemble ConsistencySignals per player
    result: dict[int, ConsistencySignals] = {}
    qualifying_pids = set(cv_percentiles.keys()) | set(raw_blank_rates.keys()) | set(
        floor_percentiles.keys()
    ) | set(raw_involvement.keys()) | set(gk_percentiles.keys())

    for pid in qualifying_pids:
        result[pid] = ConsistencySignals(
            cv_xgi_percentile=cv_percentiles.get(pid, 0.5),
            blank_rate=raw_blank_rates.get(pid),
            floor_percentile=floor_percentiles.get(pid, 0.5),
            involvement_rate=raw_involvement.get(pid),
            gk_consistency_percentile=gk_percentiles.get(pid, 0.5),
        )

    return result


async def fetch_match_records(
    current_gw: int,
) -> dict[int, list[MatchRecord]] | None:
    """Fetch Core-Insights match-level CSVs and return raw records.

    Owns the CoreInsightsClient lifecycle. Returns None on any failure
    (graceful degradation). Callers use the records to build derived
    lookups (adjusted npxG, consistency signals).
    """
    try:
        from fpl_cli.api.core_insights import CoreInsightsClient, make_core_insights_fetcher

        async with CoreInsightsClient(make_core_insights_fetcher()) as ci_client:
            all_match_records = await ci_client.get_match_stats(current_gw)

        return all_match_records or None
    except Exception:  # noqa: BLE001 — graceful degradation: CI match data unavailable
        import logging

        logging.getLogger(__name__).warning(
            "Failed to fetch match records", exc_info=True,
        )
        return None


def build_npxg_lookup_from_records(
    all_match_records: dict[int, list[MatchRecord]],
    current_gw: int,
) -> dict[int, float]:
    """Build adjusted npxG lookup from pre-fetched match records.

    Computes median Elo from the records, then delegates to
    ``build_adjusted_npxg_lookup``.
    """
    median_elo = compute_median_elo(all_match_records)
    return build_adjusted_npxg_lookup(all_match_records, current_gw, median_elo)


def compute_adjusted_npxg(
    match_records: list[MatchRecord],
    current_gw: int,
    median_elo: float,
) -> float | None:
    """Opponent-adjusted npxG/90 over a rolling 7-match/12-GW window.

    Normalises each match's xG by the opponent's Elo relative to the league
    median. Factor capped at [0.80, 1.25] to limit early-season noise.
    npxG per match = xg - (penalties_scored + penalties_missed) * 0.76.

    Returns None when fewer than 4 qualifying matches (same threshold as
    form_trajectory), triggering fallback to raw Understat npxG_per_90.
    """
    cutoff = current_gw - 12
    qualifying = [
        m for m in match_records
        if m.get("minutes_played", 0) > 0 and m.get("gameweek", 0) > cutoff
    ]
    qualifying.sort(key=lambda m: m["gameweek"])
    window = qualifying[-7:]

    if len(window) < 4:
        return None

    total_adjusted = 0.0
    total_minutes = 0

    for m in window:
        opp_elo = m.get("opponent_elo", median_elo)
        if opp_elo <= 0:
            opp_elo = median_elo
        factor = max(0.80, min(1.25, median_elo / opp_elo))

        xg = m.get("xg", 0.0)
        penalties = m.get("penalties_scored", 0) + m.get("penalties_missed", 0)
        npxg = xg - penalties * 0.76
        total_adjusted += npxg * factor
        total_minutes += m.get("minutes_played", 0)

    if total_minutes == 0:
        return None

    return total_adjusted / (total_minutes / 90)


def build_adjusted_npxg_lookup(
    all_match_records: dict[int, list[MatchRecord]],
    current_gw: int,
    median_elo: float,
) -> dict[int, float]:
    """Build per-player adjusted npxG/90 lookup from season match data.

    Returns dict keyed by FPL element_id. Players with insufficient data
    (< 4 qualifying matches) are absent; callers fall back to raw npxG_per_90.
    """
    result: dict[int, float] = {}
    for player_id, records in all_match_records.items():
        value = compute_adjusted_npxg(records, current_gw, median_elo)
        if value is not None:
            result[player_id] = value
    return result


def apply_adjusted_npxg(
    enrichment: dict[str, Any],
    player_id: int,
    lookup: dict[int, float] | None,
) -> None:
    """Override npxG_per_90 in enrichment with fixture-adjusted value.

    Always sets raw_npxG_per_90 from enrichment (callers must ensure
    npxG_per_90 is present before calling).
    Overrides npxG_per_90 with adjusted value when player_id is in lookup.
    """
    enrichment["raw_npxG_per_90"] = enrichment.get("npxG_per_90")
    if lookup and player_id in lookup:
        enrichment["npxG_per_90"] = lookup[player_id]


def apply_consistency(
    enrichment: dict[str, Any],
    player_id: int,
    lookup: dict[int, ConsistencySignals] | None,
) -> None:
    """Inject consistency signal fields into enrichment dict."""
    if not lookup:
        return
    signals = lookup.get(player_id)
    if signals is None:
        return
    enrichment["cv_xgi_percentile"] = signals.cv_xgi_percentile
    enrichment["blank_rate"] = signals.blank_rate
    enrichment["floor_percentile"] = signals.floor_percentile
    enrichment["involvement_rate"] = signals.involvement_rate
    enrichment["gk_consistency_percentile"] = signals.gk_consistency_percentile


def normalise_score(raw: float, ceiling: float) -> int:
    """Normalise a raw score to 0-100 against a ceiling."""
    return min(round(raw / ceiling * 100), 100)


def build_scoring_enrichment(
    player: Any,
    us_match: dict[str, Any],
    team_short: str,
    gw_history: list[dict[str, Any]] | None,
    next_gw_id: int,
    *,
    consistency_lookup: dict[int, ConsistencySignals] | None = None,
) -> dict[str, Any]:
    """Build the enrichment dict shared by quality and single-GW scoring paths."""
    # Strip understat's "position" (e.g. "F M S") — its taxonomy differs from FPL's
    # and would otherwise shadow Player.position in build_player_evaluation.
    enrichment: dict[str, Any] = {"team_short": team_short, **us_match}
    enrichment.pop("position", None)
    minutes_safe = max(player.minutes, 1)
    enrichment["xGI_per_90"] = (
        (player.expected_goals + player.expected_assists) / minutes_safe * 90
    )
    enrichment["dc_per_90"] = player.defensive_contribution_per_90
    if player.position_name == "GK":
        # Sample-size ramp: per-90 rates are noisy below ~5 full games.
        # Consistent with waiver availability ramp (minutes / 450).
        sample_ramp = min(player.minutes / 450, 1.0)
        enrichment["gk_saves_per_90"] = player.saves_per_90 * sample_ramp
        if player.minutes > 0:
            xgc_per_90 = (player.expected_goals_conceded / player.minutes) * 90
            enrichment["gk_xgc_quality"] = max(0.0, 2.0 - xgc_per_90) * sample_ramp
        else:
            enrichment["gk_xgc_quality"] = 0.0
        enrichment["gk_cs_rate"] = (player.clean_sheets / max(player.appearances, 1)) * sample_ramp

    if gw_history:
        enrichment["form_trajectory"] = compute_form_trajectory(gw_history, next_gw_id)
        sustainability, divergence = compute_xgi_sustainability(
            gw_history, next_gw_id, player.position_name
        )
        enrichment["xgi_sustainability"] = sustainability
        enrichment["xgi_divergence"] = divergence

    if consistency_lookup:
        apply_consistency(enrichment, int(getattr(player, "id", 0)), consistency_lookup)

    return enrichment


_OWNERSHIP_CEILINGS: dict[tuple[str, str], float] = {
    ("target", "GK"): GK_TARGET_CEILING,
    ("target", "DEF"): DEF_TARGET_CEILING,
    ("differential", "GK"): GK_DIFFERENTIAL_CEILING,
    ("differential", "DEF"): DEF_DIFFERENTIAL_CEILING,
    ("waiver", "GK"): GK_WAIVER_CEILING,
    ("waiver", "DEF"): DEF_WAIVER_CEILING,
}
_OWNERSHIP_BASE_CEILINGS: dict[str, float] = {
    "target": TARGET_CEILING,
    "differential": DIFFERENTIAL_CEILING,
    "waiver": WAIVER_CEILING,
}


def _ownership_ceiling_for(family: Literal["target", "differential", "waiver"], position: Position) -> float:
    return _OWNERSHIP_CEILINGS.get((family, position), _OWNERSHIP_BASE_CEILINGS[family])


def _value_weights_and_ceiling(position: Position) -> tuple[QualityWeights, float]:
    """Select VALUE_QUALITY_WEIGHTS variant and ceiling for a position."""
    if position == "GK":
        return VALUE_QUALITY_WEIGHTS.for_gk(), GK_VALUE_CEILING
    if position == "DEF":
        return VALUE_QUALITY_WEIGHTS.without_xgi(), DEF_VALUE_CEILING
    return VALUE_QUALITY_WEIGHTS, VALUE_CEILING


def pick_display_ceiling(position: Position, horizon: int) -> float:
    """Position + horizon aware ceiling for `fpl allocate` display normalisation.

    Two-column model downstream:

    - horizon=1 → ``single_gw_score``. Uses ``STARTING_XI_CEILING`` as a
      cross-position anchor (intentional). DEFs/GKs land lower than MIDs/FWDs
      for the same real-world quality; use ``raw_quality`` for position-agnostic
      ranking in the single-GW context.
    - horizon >= 2 → ``quality_score``. Routes to VALUE-family ceilings via
      ``_value_weights_and_ceiling``, matching ``fpl player`` / ``fpl stats
      --value`` / ``fpl transfer-eval`` for cross-command consistency.
    """
    if horizon <= 1:
        return STARTING_XI_CEILING
    _, ceiling = _value_weights_and_ceiling(position)
    return ceiling


@overload
def compute_quality_value(
    player: Any,
    us_match: dict[str, Any],
    next_gw_id: int,
    *,
    team_short: str = ...,
    gw_history: list[dict[str, Any]] | None = ...,
    raw: Literal[False] = ...,
    consistency_lookup: dict[int, ConsistencySignals] | None = ...,
) -> tuple[int, float | None]: ...


@overload
def compute_quality_value(
    player: Any,
    us_match: dict[str, Any],
    next_gw_id: int,
    *,
    team_short: str = ...,
    gw_history: list[dict[str, Any]] | None = ...,
    raw: Literal[True],
    consistency_lookup: dict[int, ConsistencySignals] | None = ...,
) -> float: ...


def compute_quality_value(
    player: Any,
    us_match: dict[str, Any],
    next_gw_id: int,
    *,
    team_short: str = "???",
    gw_history: list[dict[str, Any]] | None = None,
    raw: bool = False,
    consistency_lookup: dict[int, ConsistencySignals] | None = None,
) -> tuple[int, float | None] | float:
    """Compute quality_score and quality_per_m for a single player.

    Shared by ``fpl player``, ``fpl stats --value``, and the squad
    allocator. Callers handle data fetching; this function owns
    enrichment assembly and scoring.

    When *raw* is True, returns the unrounded float quality score
    (for the ILP solver which needs full precision).

    Returns:
        Default: (quality_score 0-100, quality_per_m or None if price is 0)
        raw=True: raw quality float
    """
    enrichment = build_scoring_enrichment(
        player, us_match, team_short, gw_history, next_gw_id,
        consistency_lookup=consistency_lookup,
    )

    evaluation, _ = build_player_evaluation(player, enrichment=enrichment)
    q_dict = evaluation.as_quality_dict()
    weights, value_ceiling = _value_weights_and_ceiling(player.position_name)
    mins_factor = calculate_mins_factor(player.minutes, player.appearances, next_gw_id)
    raw_score = calculate_player_quality_score(
        q_dict, weights, mins_factor, position=_as_position(player.position_name),
    )
    if raw:
        return raw_score
    q_score = normalise_score(raw_score, value_ceiling)
    quality_per_m = round(q_score / player.price, 1) if player.price > 0 else None
    return q_score, quality_per_m


def compute_rolling_pts_per_m(
    history: list[dict[str, Any]],
    price: float,
    window: int = 5,
) -> tuple[float | None, int | None]:
    """Rolling points per million from recent fixture history.

    Args:
        history: Player element-summary history entries (one per fixture).
        price: Raw price in £0.1m units (e.g. 100 = £10.0m).
        window: Number of qualifying fixtures to consider.

    Returns:
        (rolling_pts_per_m, fixture_count) — both None when fewer than 3
        qualifying fixtures or price <= 0.
    """
    if price <= 0:
        return None, None

    qualifying = [
        h for h in history
        if h.get("minutes", 0) > 0
    ]
    qualifying.sort(key=lambda h: (-h.get("round", 0), -h.get("fixture", 0)))
    qualifying = qualifying[:window]

    if len(qualifying) < 3:
        return None, None

    n = len(qualifying)
    total_pts = sum(h.get("total_points", 0) for h in qualifying)
    price_m = price / 10
    return round(total_pts / n / price_m, 2), n


def shrink_scores(
    scores: list[tuple[int, float, Position]],
    prior_map: dict[int, PlayerPrior] | None,
    current_gw: int,
    cutoff_gw: int,
) -> list[tuple[int, float, Position]]:
    """Apply confidence-weighted shrinkage toward position means.

    Args:
        scores: List of (player_id, score, position) tuples.
        prior_map: player_id -> PlayerPrior (or None to skip shrinkage).
        current_gw: Current gameweek number.
        cutoff_gw: GW at/after which shrinkage is disabled.

    Returns:
        List of (player_id, adjusted_score, position) in the same order.
    """
    if not scores or prior_map is None or current_gw >= cutoff_gw:
        return scores

    # Collect confidence per player (default 1.0 = no shrinkage)
    confidences: dict[int, float] = {}
    for pid, _, _ in scores:
        prior = prior_map.get(pid)
        confidences[pid] = prior.confidence if prior is not None else 1.0

    # Pass 1: confidence-weighted position means
    pos_weighted_sum: dict[str, float] = {}
    pos_weight_total: dict[str, float] = {}
    for pid, score, position in scores:
        conf = confidences[pid]
        pos_weighted_sum[position] = pos_weighted_sum.get(position, 0.0) + conf * score
        pos_weight_total[position] = pos_weight_total.get(position, 0.0) + conf

    pos_mean: dict[str, float] = {}
    for pos in pos_weighted_sum:
        total = pos_weight_total[pos]
        pos_mean[pos] = pos_weighted_sum[pos] / total if total > 0 else 0.0

    # Pass 2: shrink each score toward its position mean
    result: list[tuple[int, float, Position]] = []
    for pid, score, position in scores:
        mean = pos_mean.get(position, score)
        conf = confidences[pid]
        adjusted = mean + conf * (score - mean)
        result.append((pid, adjusted, position))

    return result


def apply_shrinkage(
    scored_items: list[dict[str, Any]],
    score_field: str,
    prior_map: dict[int, PlayerPrior] | None,
    current_gw: int,
) -> None:
    """Apply early-season shrinkage to scored dicts in place.

    Extracts (id, score, position) from each dict, runs shrink_scores,
    and writes adjusted scores back. Agents call this instead of
    manually wiring the extract-shrink-writeback loop.
    """
    from fpl_cli.services.player_prior import CUTOFF_GW

    tuples = [
        (item["id"], float(item[score_field]), item["position"])
        for item in scored_items
    ]
    shrunk = shrink_scores(tuples, prior_map, current_gw, CUTOFF_GW)
    for item, (_, adj_score, _) in zip(scored_items, shrunk):
        item[score_field] = round(adj_score)


# ---------------------------------------------------------------------------
# Evaluation types
# ---------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True)
class FixtureMatchup:
    """Pre-resolved fixture data for a single fixture within a gameweek."""

    opponent_short: str
    is_home: bool
    opponent_fdr: float
    matchup_score: float
    matchup_breakdown: dict[str, Any] | None = None


@dataclasses.dataclass(frozen=True)
class PlayerEvaluation:
    """Scoring-relevant data for a single player. Immutable.

    All fields that scoring functions read for arithmetic live here.
    Display-only fields live in PlayerIdentity.
    """

    # Quality baseline inputs (keys match calculate_player_quality_score dict interface)
    form: float
    ppg: float
    xgi_per_90: float
    npxg_per_90: float | None
    xg_chain_per_90: float | None
    dc_per_90: float
    penalty_xg_per_90: float | None

    # Minutes risk (scorers derive mins_factor from these via calculate_mins_factor)
    minutes: int
    appearances: int

    # Position (for without_xgi gate and position multiplier)
    position: Position

    # Fixture data
    fixture_matchups: list[FixtureMatchup]
    matchup_avg_3gw: float | None = None
    positional_fdr: float | None = None

    # Regression inputs
    gi_minus_xgi: float = 0.0

    # Ownership (differential scoring)
    ownership: float = 0.0

    # Availability
    status: str = "a"
    chance_of_playing: int | None = None

    # Team context (waiver stacking)
    team_id: int = 0
    team_short: str = ""

    # Set pieces
    penalties_order: int | None = None
    corners_and_indirect_freekicks_order: int | None = None
    direct_freekicks_order: int | None = None

    # Form trajectory (multiplier on form contribution: 0.8=falling, 1.0=stable, 1.2=rising)
    form_trajectory: float = 1.0

    # Bayesian prior confidence (1.0=trust current data fully, <1.0=shrink toward position mean)
    prior_confidence: float = 1.0

    # xGI sustainability (multiplier on form contribution: <1.0=overperforming regression risk,
    # 1.0=at rate, >1.0=underperforming regression upside). ATK only; DEF/GK default to 1.0.
    xgi_sustainability: float = 1.0

    # GK-specific signals (zero for non-GKs; weight gate ensures zero contribution)
    gk_saves_per_90: float = 0.0
    gk_xgc_quality: float = 0.0
    gk_cs_rate: float = 0.0

    # Original Understat npxG/90 before fixture adjustment (None when no Understat data)
    raw_npxg_per_90: float | None = None

    # Consistency signals
    cv_xgi_percentile: float = 0.5
    blank_rate: float | None = None
    floor_percentile: float = 0.5
    involvement_rate: float | None = None
    gk_consistency_percentile: float = 0.5

    def as_quality_dict(self) -> dict[str, Any]:
        """Return a dict of evaluation fields for quality scoring and display."""
        return {
            "npxG_per_90": self.npxg_per_90,
            "xGChain_per_90": self.xg_chain_per_90,
            "xGI_per_90": self.xgi_per_90,
            "form": self.form,
            "ppg": self.ppg,
            "dc_per_90": self.dc_per_90,
            "penalty_xG_per_90": self.penalty_xg_per_90,
            "form_trajectory": self.form_trajectory,
            "prior_confidence": self.prior_confidence,
            "xgi_sustainability": self.xgi_sustainability,
            "gk_saves_per_90": self.gk_saves_per_90,
            "gk_xgc_quality": self.gk_xgc_quality,
            "gk_cs_rate": self.gk_cs_rate,
            "cv_xgi_percentile": self.cv_xgi_percentile,
            "floor_percentile": self.floor_percentile,
            "involvement_rate": self.involvement_rate,
            "gk_consistency_percentile": self.gk_consistency_percentile,
        }


@dataclasses.dataclass(frozen=True)
class PlayerIdentity:
    """Display-only fields passed through to scoring output dicts.

    No scoring function reads these for arithmetic.
    """

    id: int
    web_name: str
    team_short: str
    position_name: str
    price: float
    ownership: float
    expected_goals: float = 0.0
    expected_assists: float = 0.0
    points_per_game: float = 0.0


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def _extract_status(val: Any) -> str:
    """Convert a PlayerStatus enum or string to its single-char status code."""
    from fpl_cli.models.player import PlayerStatus

    if isinstance(val, PlayerStatus):
        return val.value
    return str(val)


def build_player_evaluation(
    player: Player | Mapping[str, Any],
    *,
    enrichment: dict[str, Any] | None = None,
    fixture_matchups: list[FixtureMatchup] | None = None,
    matchup_avg_3gw: float | None = None,
    positional_fdr: float | None = None,
) -> tuple[PlayerEvaluation, PlayerIdentity]:
    """Build evaluation and identity from a Player model or enriched dict.

    Normalises both input shapes to the same field set. When *enrichment*
    is provided its keys overlay the base player data.
    """
    # Unified accessor: try attribute first (Player model), fall back to dict
    def _get(key: str, default: Any = None) -> Any:
        if enrichment and key in enrichment:
            return enrichment[key]
        if hasattr(player, key):
            return getattr(player, key)
        if isinstance(player, Mapping):
            return player.get(key, default)
        return default

    minutes = _get("minutes", 0)
    appearances = _get("appearances", 0)

    # Position: Player model stores as enum, dicts store as string
    position_raw = _get("position")
    position: Position
    if hasattr(position_raw, "value"):
        position = _position_from_element_type(position_raw.value)
    else:
        position = _as_position(str(position_raw) if position_raw else "")

    # Position name for identity (same as position for dicts, computed for model)
    position_name = _get("position_name") or position

    # Build evaluation
    evaluation = PlayerEvaluation(
        form=float(_get("form", 0)),
        ppg=float(_get("ppg") if _get("ppg") is not None else _get("points_per_game", 0)),
        xgi_per_90=float(_get("xGI_per_90", 0) or 0),
        npxg_per_90=_get("npxG_per_90"),
        xg_chain_per_90=_get("xGChain_per_90"),
        dc_per_90=float(_get("dc_per_90", 0) or 0),
        penalty_xg_per_90=_get("penalty_xG_per_90"),
        minutes=minutes,
        appearances=appearances,
        position=position,
        fixture_matchups=fixture_matchups or [],
        matchup_avg_3gw=matchup_avg_3gw,
        positional_fdr=positional_fdr,
        gi_minus_xgi=float(_get("GI_minus_xGI", 0) or 0),
        ownership=float(_get("ownership", 0) or _get("selected_by_percent", 0) or 0),
        status=_extract_status(_get("status", "a")),
        chance_of_playing=_get("chance_of_playing") or _get("chance_of_playing_next_round"),
        team_id=int(_get("team_id", 0)),
        team_short=str(_get("team_short", "")),
        penalties_order=_get("penalties_order"),
        corners_and_indirect_freekicks_order=_get("corners_and_indirect_freekicks_order"),
        direct_freekicks_order=_get("direct_freekicks_order"),
        form_trajectory=float(_get("form_trajectory", 1.0) or 1.0),
        prior_confidence=float(_get("prior_confidence", 1.0) or 1.0),
        xgi_sustainability=float(_get("xgi_sustainability", 1.0) or 1.0),
        gk_saves_per_90=float(_get("gk_saves_per_90", 0.0) or 0.0),
        gk_xgc_quality=float(_get("gk_xgc_quality", 0.0) or 0.0),
        gk_cs_rate=float(_get("gk_cs_rate", 0.0) or 0.0),
        raw_npxg_per_90=_get("raw_npxG_per_90"),
        cv_xgi_percentile=float(_get("cv_xgi_percentile", 0.5) or 0.5),
        blank_rate=_get("blank_rate"),
        floor_percentile=float(_get("floor_percentile", 0.5) or 0.5),
        involvement_rate=_get("involvement_rate"),
        gk_consistency_percentile=float(_get("gk_consistency_percentile", 0.5) or 0.5),
    )

    # Build identity
    identity = PlayerIdentity(
        id=int(_get("id", 0)),
        web_name=str(_get("web_name", "")),
        team_short=str(_get("team_short", "")),
        position_name=position_name,
        price=float(_get("price", 0)),
        ownership=float(_get("ownership", 0) or _get("selected_by_percent", 0) or 0),
        expected_goals=float(_get("expected_goals", 0)),
        expected_assists=float(_get("expected_assists", 0)),
        points_per_game=float(_get("ppg", 0) or _get("points_per_game", 0)),
    )

    return evaluation, identity


# ---------------------------------------------------------------------------
# Shared scoring helpers
# ---------------------------------------------------------------------------


def per_90_rates(
    evaluation: PlayerEvaluation, identity: PlayerIdentity,
) -> tuple[float, float]:
    """Derive xG and xA per-90 from season totals. Used by all single-GW consumers."""
    minutes_safe = max(evaluation.minutes, 1)
    return (
        (identity.expected_goals / minutes_safe) * 90,
        (identity.expected_assists / minutes_safe) * 90,
    )


def _matchup_bonus(matchup_avg_3gw: float | None, mins_factor: float) -> float:
    """Ownership-family matchup: 3-GW scalar average, weight 0.75, rotation-discounted.

    Parallel to ``calculate_single_gw_core``'s ``matchup_weight`` param which
    serves the same role for per-fixture data (captain 2.0, bench 1.5).
    """
    return (matchup_avg_3gw or 0.0) * 0.75 * mins_factor


def _calculate_quality_based_raw(
    evaluation: PlayerEvaluation,
    *,
    weights: QualityWeights,
    next_gw_id: int,
    ownership_config: dict[str, float] | None = None,
    mins_factor_override: float | None = None,
    differential: bool = False,
) -> float:
    """Raw ownership-family score before normalisation.

    Computes: quality baseline + ownership bonus + matchup bonus +
    consistency bonus + availability penalty. Returns un-normalised float
    so callers can add formula-specific adjustments before normalising.

    *mins_factor_override*: when set, replaces the standard
    ``calculate_mins_factor`` result for both quality score and matchup
    bonus. Used by waiver scoring which applies a stricter combined
    availability factor (season commitment in draft format).

    *differential*: when True, inverts the consistency bonus direction
    (volatile players score higher).
    """
    if evaluation.position in ATTACKING_POSITIONS:
        effective_weights = weights
    elif evaluation.position == "GK":
        effective_weights = weights.for_gk()
    else:
        effective_weights = weights.without_xgi()
    mins_factor = (
        mins_factor_override
        if mins_factor_override is not None
        else calculate_mins_factor(
            evaluation.minutes, evaluation.appearances, next_gw_id,
        )
    )

    score = calculate_player_quality_score(
        evaluation.as_quality_dict(),
        effective_weights,
        mins_factor,
        position=evaluation.position,
    )

    # Ownership bonus (differential only)
    if ownership_config is not None:
        score += max(
            0,
            (ownership_config["threshold"] - evaluation.ownership)
            / ownership_config["divisor"],
        )

    score += _matchup_bonus(evaluation.matchup_avg_3gw, mins_factor)

    # Consistency bonus (additive, phase-in GW6-10)
    phase = _consistency_phase(next_gw_id)
    if phase > 0:
        cv = evaluation.cv_xgi_percentile
        if differential:
            score += (0.5 - cv) * CONSISTENCY_CV_DIFF * phase
        else:
            score += (cv - 0.5) * CONSISTENCY_CV_TARGET * phase

    # Availability penalty
    if evaluation.status != "a" and evaluation.chance_of_playing is not None and evaluation.chance_of_playing < 75:
        score -= 3

    return score


def _calculate_quality_based_score(
    evaluation: PlayerEvaluation,
    *,
    weights: QualityWeights,
    ceiling: float,
    next_gw_id: int,
    ownership_config: dict[str, float] | None = None,
    differential: bool = False,
) -> int:
    """Shared scoring logic for target, differential, and (via raw) waiver.

    Thin wrapper: delegates to ``_calculate_quality_based_raw`` then normalises.
    """
    raw = _calculate_quality_based_raw(
        evaluation,
        weights=weights,
        next_gw_id=next_gw_id,
        ownership_config=ownership_config,
        differential=differential,
    )
    return normalise_score(raw, ceiling)


# ---------------------------------------------------------------------------
# Scoring formulas
# ---------------------------------------------------------------------------


def calculate_target_score(
    evaluation: PlayerEvaluation,
    *,
    next_gw_id: int,
) -> int:
    """Calculate a target score (pure performance, no ownership bias)."""
    ceiling = _ownership_ceiling_for("target", evaluation.position)
    return _calculate_quality_based_score(
        evaluation,
        weights=TARGET_QUALITY_WEIGHTS,
        ceiling=ceiling,
        next_gw_id=next_gw_id,
    )


def calculate_differential_score(
    evaluation: PlayerEvaluation,
    *,
    semi_differential_threshold: float,
    next_gw_id: int,
) -> int:
    """Calculate a differential score for a player."""
    ceiling = _ownership_ceiling_for("differential", evaluation.position)
    return _calculate_quality_based_score(
        evaluation,
        weights=DIFFERENTIAL_QUALITY_WEIGHTS,
        ceiling=ceiling,
        next_gw_id=next_gw_id,
        ownership_config={
            "threshold": semi_differential_threshold,
            "divisor": 3,
        },
        differential=True,
    )


def calculate_waiver_score(
    evaluation: PlayerEvaluation,
    *,
    squad_by_position: dict[str, list],
    team_counts: dict[str, int] | None = None,
    next_gw_id: int,
) -> int:
    """Calculate a waiver priority score for a player.

    Delegates shared flow (quality baseline, regression, matchup,
    availability) to ``_calculate_quality_based_raw`` with a bespoke
    combined_mins_factor (availability * per_appearance) that is
    stricter than the standard mins_factor - draft waivers are a
    season commitment so absolute playing time matters.

    Position-need and team-stacking adjustments are waiver-specific
    and applied to the raw score before normalisation.
    """
    # Combined minutes factor: per_appearance * availability (waiver-specific)
    per_appearance = calculate_mins_factor(
        evaluation.minutes, evaluation.appearances, next_gw_id,
    )
    if next_gw_id <= 5:
        combined_mins_factor = 1.0
    elif evaluation.appearances > 0:
        availability = min(evaluation.minutes / 450, 1.0)
        combined_mins_factor = availability * per_appearance
    else:
        combined_mins_factor = 0.0

    score = _calculate_quality_based_raw(
        evaluation,
        weights=WAIVER_QUALITY_WEIGHTS,
        next_gw_id=next_gw_id,
        mins_factor_override=combined_mins_factor,
    )

    # Position need bonus
    if evaluation.position in squad_by_position:
        position_players = squad_by_position[evaluation.position]
        if position_players:
            avg_form = sum(p.get("form", 0) for p in position_players) / len(position_players)
            if avg_form < 3:
                score += 3
        else:
            score += 5

    # Team stacking penalty
    if team_counts:
        current_count = team_counts.get(evaluation.team_short, 0)
        if current_count >= 3:
            score -= 5
        elif current_count == 2:
            score -= 2

    waiver_ceiling = _ownership_ceiling_for("waiver", evaluation.position)
    return normalise_score(score, waiver_ceiling)


# ---------------------------------------------------------------------------
# Single-GW core (shared by captain + bench)
# ---------------------------------------------------------------------------


def calculate_single_gw_core(
    evaluation: PlayerEvaluation,
    weights: QualityWeights,
    fixture_matchups: list[FixtureMatchup],
    *,
    matchup_weight: float,
    next_gw_id: int,
    xg_per_90: float = 0.0,
    xa_per_90: float = 0.0,
) -> float:
    """Core single-gameweek score shared by captain and bench scoring.

    Computes matchup contribution, form, xGI, penalty score, applies
    position multiplier and mins_factor, then adds home bonus.

    Args:
        matchup_weight: Per-fixture matchup multiplier (captain 2.0,
            bench 1.5). Parallel to ``_matchup_bonus``'s hardcoded 0.75
            which serves the same role for the ownership family's scalar
            3-GW average.
        xg_per_90: FPL-derived xG per 90 (from identity.expected_goals).
        xa_per_90: FPL-derived xA per 90 (from identity.expected_assists).

    Returns a raw (un-normalised) float score.
    """
    if not fixture_matchups:
        return 0.0

    fixture_count = len(fixture_matchups)

    # Sum matchup scores across fixtures (DGW sums, not averages)
    matchup_total = sum(
        (fm.matchup_breakdown or {}).get("matchup_score", fm.matchup_score)
        for fm in fixture_matchups
    )

    # Form score (capped via weights, then scaled by trajectory and xGI sustainability)
    form_score = (
        min(evaluation.form * weights.form.multiplier, weights.form.cap)
        * evaluation.form_trajectory
        * evaluation.xgi_sustainability
    )

    # xGI score: prefer npxG when available (strips penalty noise)
    if evaluation.npxg_per_90 is not None:
        xgi_score = min((evaluation.npxg_per_90 + xa_per_90) * weights.npxg.multiplier, weights.npxg.cap)
    else:
        xgi_per_90_fallback = xg_per_90 + xa_per_90
        xgi_score = min(xgi_per_90_fallback * weights.xgi_fallback.multiplier, weights.xgi_fallback.cap)

    # Scale xGI by fixture count for DGW
    xgi_score *= fixture_count

    # Penalty xG score via StatWeight (per-90, scales with mins_factor)
    pen_raw = (evaluation.penalty_xg_per_90 or 0) * weights.penalty_xg.multiplier
    penalty_score = min(pen_raw, weights.penalty_xg.cap)

    # Minutes factor
    mins_factor = calculate_mins_factor(evaluation.minutes, evaluation.appearances, next_gw_id)

    # Ceiling components with position multiplier
    pos_mult = POSITION_SCORE_MULTIPLIER.get(evaluation.position, 1.0)
    ceiling_score = (
        matchup_total * matchup_weight +
        form_score +
        xgi_score * 1.0 +
        penalty_score
    ) * pos_mult * mins_factor

    # Flat bonuses (not affected by position multiplier)
    home_bonus = 1.0 if any(fm.is_home for fm in fixture_matchups) else 0.0

    # Consistency tiebreaker (additive, phase-in GW6-10)
    phase = _consistency_phase(next_gw_id)
    consistency_bonus = 0.0
    if phase > 0:
        consistency_bonus = (evaluation.cv_xgi_percentile - 0.5) * CONSISTENCY_CV_LINEUP * phase

    return ceiling_score + home_bonus + consistency_bonus


def calculate_captain_score(
    evaluation: PlayerEvaluation,
    identity: PlayerIdentity,
    *,
    next_gw_id: int,
) -> CaptainCandidate | None:
    """Score a player as a captain candidate.

    Returns a CaptainCandidate TypedDict (score + reasons + display data),
    or None if the player has no fixtures this gameweek.
    """
    if not evaluation.fixture_matchups:
        return None  # Blank gameweek

    fixture_count = len(evaluation.fixture_matchups)

    # Build fixture details for display and FDR calculation
    fixture_details: list[FixtureDetail] = []
    total_fdr = 0.0
    matchup_scores: list[dict[str, Any]] = []

    for fm in evaluation.fixture_matchups:
        fixture_details.append({
            "opponent": fm.opponent_short,
            "is_home": fm.is_home,
            "fdr": fm.opponent_fdr,
        })
        total_fdr += fm.opponent_fdr
        if fm.matchup_breakdown:
            matchup_scores.append(fm.matchup_breakdown)
        else:
            matchup_scores.append({"matchup_score": fm.matchup_score})

    avg_fdr = total_fdr / fixture_count

    # Matchup total for display
    matchup_total = sum(
        m.get("matchup_score", fm.matchup_score)
        for m, fm in zip(matchup_scores, evaluation.fixture_matchups)
    )

    xg_per_90, xa_per_90 = per_90_rates(evaluation, identity)

    # Delegate to shared core (captain uses matchup_weight=2.0)
    captain_score_raw = calculate_single_gw_core(
        evaluation,
        GW_SELECTION_WEIGHTS,
        evaluation.fixture_matchups,
        matchup_weight=2.0,
        next_gw_id=next_gw_id,
        xg_per_90=xg_per_90,
        xa_per_90=xa_per_90,
    )

    # pen_bonus for display (derived from StatWeight, not flat conditional)
    w = GW_SELECTION_WEIGHTS
    pen_raw = (evaluation.penalty_xg_per_90 or 0) * w.penalty_xg.multiplier
    penalty_score = min(pen_raw, w.penalty_xg.cap)
    mins_factor = calculate_mins_factor(evaluation.minutes, evaluation.appearances, next_gw_id)
    pen_bonus = round(penalty_score * mins_factor, 2)

    # Normalise to 0-100: SGW-based ceiling so DGW advantage shows naturally
    captain_score = normalise_score(captain_score_raw, CAPTAIN_CEILING_SGW)

    # Generate reasoning from ALL fixture matchups
    reasons: list[str] = []
    for matchup in matchup_scores:
        if matchup.get("reasoning"):
            reasons.extend(matchup["reasoning"])

    if avg_fdr <= FDR_EASY:
        reasons.append(f"Excellent FDR ({avg_fdr:.1f})")
    elif avg_fdr <= FDR_MEDIUM:
        reasons.append(f"Good FDR ({avg_fdr:.1f})")

    if fixture_count > 1:
        reasons.append(f"Double gameweek ({fixture_count} games)")

    if evaluation.form >= 6:
        reasons.append(f"In great form ({evaluation.form})")
    elif evaluation.form >= 4:
        reasons.append(f"In decent form ({evaluation.form})")

    xgi_per_90 = xg_per_90 + xa_per_90
    if xgi_per_90 >= 0.6:
        reasons.append(f"High xGI ({xgi_per_90:.2f}/90)")
    elif xg_per_90 >= 0.5:
        reasons.append(f"High xG ({xg_per_90:.2f}/90)")
    elif xa_per_90 >= 0.3:
        reasons.append(f"High xA ({xa_per_90:.2f}/90)")

    if any(fm.is_home for fm in evaluation.fixture_matchups):
        reasons.append("Playing at home")

    if evaluation.penalties_order == 1:
        reasons.append("Primary penalty taker")

    # Availability warning
    if evaluation.status != "a" and evaluation.chance_of_playing is not None:
        reasons.append(f"Flagged ({evaluation.chance_of_playing}% chance)")

    # Blank rate reason (display only)
    if evaluation.blank_rate is not None:
        if evaluation.blank_rate >= 0.6:
            reasons.append(f"Blanks in {evaluation.blank_rate:.0%} of recent matches")
        elif evaluation.blank_rate <= 0.15:
            reasons.append(f"Returns in {1 - evaluation.blank_rate:.0%} of recent matches")

    primary = matchup_scores[0] if matchup_scores else {}
    result: CaptainCandidate = {
        "id": identity.id,
        "player_name": identity.web_name,
        "team_short": identity.team_short,
        "position": identity.position_name,
        "price": identity.price,
        "ownership": identity.ownership,
        "form": evaluation.form,
        "ppg": identity.points_per_game,
        "xG": round(identity.expected_goals, 2),
        "xA": round(identity.expected_assists, 2),
        "xGI": round(identity.expected_goals + identity.expected_assists, 2),
        "xG_per_90": round(xg_per_90, 2),
        "xA_per_90": round(xa_per_90, 2),
        "xGI_per_90": round(xgi_per_90, 2),
        "fixtures": fixture_details,
        "fixture_count": fixture_count,
        "avg_fdr": round(avg_fdr, 2),
        "matchup_score": round(matchup_total, 2),
        "attack_matchup": round(float(primary.get("attack_matchup", 5.0)), 2),
        "defence_matchup": round(float(primary.get("defence_matchup", 5.0)), 2),
        "form_differential": round(float(primary.get("form_differential", 0.0)), 2),
        "position_differential": round(float(primary.get("position_differential", 0.0)), 2),
        "pen_bonus": pen_bonus,
        "captain_score": captain_score,
        "captain_score_raw": round(captain_score_raw, 2),
        "cv_xgi_percentile": evaluation.cv_xgi_percentile,
        "reasons": reasons,
    }
    if evaluation.raw_npxg_per_90 is not None:
        result["raw_npxg_per_90"] = round(evaluation.raw_npxg_per_90, 4)
        if (evaluation.npxg_per_90 is not None
                and evaluation.npxg_per_90 != evaluation.raw_npxg_per_90):
            result["adjusted_npxg_per_90"] = round(evaluation.npxg_per_90, 4)
    return result




def calculate_bench_score(
    evaluation: PlayerEvaluation,
    identity: PlayerIdentity,
    *,
    availability_risks: list[dict[str, Any]],
    next_gw_id: int,
) -> dict[str, Any]:
    """Score a bench player for priority ordering.

    Uses the shared single-GW core (matchup + form + xGI + penalty +
    position multiplier + mins_factor + home bonus) then adds
    bench-specific bonuses on top.

    Returns a display dict with priority_score (normalised 0-100 int),
    priority_score_raw (un-normalised float), reasons, and metadata.
    """
    reasons: list[str] = []

    xg_per_90, xa_per_90 = per_90_rates(evaluation, identity)

    # Core score via shared engine (bench uses matchup_weight=1.5)
    score = calculate_single_gw_core(
        evaluation,
        GW_SELECTION_WEIGHTS,
        evaluation.fixture_matchups,
        matchup_weight=1.5,
        next_gw_id=next_gw_id,
        xg_per_90=xg_per_90,
        xa_per_90=xa_per_90,
    )

    # --- Bench-specific bonuses (outside core) ---

    # Boost for covering a risky starter at the same position
    position_at_risk = any(
        r["position"] == evaluation.position and r["risk_level"] >= 2
        for r in availability_risks
    )
    if position_at_risk:
        score += 2
        reasons.append("Covers risky starter")

    # Availability check
    if evaluation.status != "a":
        if evaluation.chance_of_playing is not None:
            if evaluation.chance_of_playing < 50:
                score -= 5
                reasons.append(f"Doubt ({evaluation.chance_of_playing}%)")
        else:
            score -= 3
            reasons.append("Availability doubt")

    # Set-piece taker micro-bonus (tiebreaker)
    if evaluation.penalties_order == 1:
        score += 0.5
        reasons.append("Primary penalty taker")
    elif (
        evaluation.corners_and_indirect_freekicks_order is not None
        or evaluation.direct_freekicks_order is not None
    ):
        score += 0.25
        reasons.append("Set-piece taker")

    # Consistency bonus: floor + involvement (additive, phase-in GW6-10)
    phase = _consistency_phase(next_gw_id)
    if phase > 0:
        score += (evaluation.floor_percentile - 0.5) * CONSISTENCY_FLOOR_BENCH * phase
        if evaluation.involvement_rate is not None:
            score += (evaluation.involvement_rate - 0.5) * CONSISTENCY_INV_BENCH * phase

    if evaluation.floor_percentile >= 0.7:
        reasons.append("Consistent performer")
    elif evaluation.floor_percentile <= 0.3:
        reasons.append("Volatile output")

    raw_score = round(score, 2)
    return {
        "id": identity.id,
        "name": identity.web_name,
        "team": identity.team_short,
        "position": identity.position_name,
        "price": identity.price,
        "form": evaluation.form,
        "ppg": identity.points_per_game,
        "priority_score": normalise_score(score, BENCH_CEILING),
        "priority_score_raw": raw_score,
        "reasons": reasons if reasons else ["Standard bench option"],
    }


def calculate_lineup_score(
    evaluation: PlayerEvaluation,
    identity: PlayerIdentity,
    *,
    next_gw_id: int,
) -> dict[str, Any]:
    """Score a squad player for starting XI selection.

    Uses the shared single-GW core (matchup_weight=1.5, same as bench)
    then applies lineup-specific tiered availability penalties.  Unlike
    bench scoring, availability is gated on ``chance_of_playing`` directly
    regardless of status — any doubt signal matters for starting decisions.

    Returns a display dict with lineup_score (normalised 0-100 int),
    lineup_score_raw (un-normalised float), excluded flag, reasons, and
    metadata.
    """
    reasons: list[str] = []

    xg_per_90, xa_per_90 = per_90_rates(evaluation, identity)

    # Core score via shared engine (lineup uses matchup_weight=1.5)
    score = calculate_single_gw_core(
        evaluation,
        GW_SELECTION_WEIGHTS,
        evaluation.fixture_matchups,
        matchup_weight=1.5,
        next_gw_id=next_gw_id,
        xg_per_90=xg_per_90,
        xa_per_90=xa_per_90,
    )

    # --- Lineup-specific availability adjustment ---
    # Gates on chance_of_playing directly (forward-looking FPL flag),
    # not status-first like bench. Any doubt signal matters for starting.
    excluded = False
    exclusion_reason: str | None = None
    cop = evaluation.chance_of_playing

    if cop is not None:
        if cop < 50:
            excluded = True
            exclusion_reason = f"Low availability ({cop}%)"
            reasons.append(f"Excluded ({cop}% chance)")
        elif cop < 75:
            score -= 3
            reasons.append(f"Availability doubt ({cop}%)")
        elif cop < 100:
            score -= 1
            reasons.append(f"Minor doubt ({cop}%)")

    raw_score = round(score, 2)
    return {
        "id": identity.id,
        "name": identity.web_name,
        "team": identity.team_short,
        "position": identity.position_name,
        "price": identity.price,
        "form": evaluation.form,
        "ppg": identity.points_per_game,
        "lineup_score": normalise_score(score, STARTING_XI_CEILING),
        "lineup_score_raw": raw_score,
        "excluded": excluded,
        "exclusion_reason": exclusion_reason,
        "positional_fdr": evaluation.positional_fdr,
        "reasons": reasons if reasons else ["Available"],
    }


def select_starting_xi(
    scored_players: list[dict[str, Any]],
    *,
    team_fixtures: dict[str, dict[str, float]] | None = None,
) -> dict[str, Any]:
    """Select optimal starting XI from 15 scored squad players.

    Brute-force over 7 valid formations, picking top N per position,
    applying team exposure penalties. Deterministic: tied formations
    resolve to the most attacking option (fewest DEF).

    Args:
        scored_players: Output of calculate_lineup_score() for 15 players.
        team_fixtures: Optional {team_short: {"atk_fdr": float, "def_fdr": float}}
            for team exposure penalty. If None, no exposure penalty applied.

    Returns dict with starting_xi, bench, formation, total_score,
    team_exposure_penalties.
    """
    # Separate by position
    by_pos: dict[str, list[dict[str, Any]]] = {"GK": [], "DEF": [], "MID": [], "FWD": []}
    for p in scored_players:
        by_pos.setdefault(p["position"], []).append(p)

    # Sort each position by raw score descending, ID tiebreaker (deterministic)
    for pos in by_pos:
        by_pos[pos] = sorted(by_pos[pos], key=lambda x: (-x["lineup_score_raw"], x["id"]))

    # Partition excluded players (hard floor <50%) - they go to bench
    available: dict[str, list[dict[str, Any]]] = {}
    excluded: list[dict[str, Any]] = []
    for pos, players in by_pos.items():
        available[pos] = []
        for p in players:
            if p["excluded"]:
                excluded.append(p)
            else:
                available[pos].append(p)

    # GK: always exactly 1 starter (best available)
    gk_starter = available["GK"][0] if available["GK"] else None

    best_formation = None
    best_xi: list[dict[str, Any]] = []
    best_total = -1.0
    best_penalties: list[dict[str, Any]] = []

    for def_n, mid_n, fwd_n in VALID_FORMATIONS:
        # Check we have enough available players per position
        if len(available["DEF"]) < def_n or len(available["MID"]) < mid_n or len(available["FWD"]) < fwd_n:
            continue

        picks = {
            "DEF": available["DEF"][:def_n],
            "MID": available["MID"][:mid_n],
            "FWD": available["FWD"][:fwd_n],
        }
        outfield = picks["DEF"] + picks["MID"] + picks["FWD"]
        formation_total = sum(p["lineup_score_raw"] for p in outfield)
        if gk_starter:
            formation_total += gk_starter["lineup_score_raw"]

        # Team exposure penalty
        penalties: list[dict[str, Any]] = []
        if team_fixtures:
            team_counts: dict[str, list[dict[str, Any]]] = {}
            xi_players = ([gk_starter] if gk_starter else []) + outfield
            for p in xi_players:
                team_counts.setdefault(p["team"], []).append(p)

            for team_short, team_players in team_counts.items():
                if len(team_players) < 2:
                    continue
                tf = team_fixtures.get(team_short, {})
                for p in team_players[1:]:
                    # ATK FDR for MID/FWD, DEF FDR for GK/DEF
                    if p["position"] in ("MID", "FWD"):
                        fdr = tf.get("atk_fdr", 0.0)
                    else:
                        fdr = tf.get("def_fdr", 0.0)
                    if fdr >= 5.0:
                        formation_total -= 2
                        penalties.append({
                            "team": team_short,
                            "player": p["name"],
                            "fdr": fdr,
                            "penalty": -2,
                        })

        if formation_total > best_total:
            best_total = formation_total
            best_formation = f"{def_n}-{mid_n}-{fwd_n}"
            best_xi = ([gk_starter] if gk_starter else []) + outfield
            best_penalties = penalties

    # Bench: everyone not in the XI
    xi_ids = {p["id"] for p in best_xi}
    bench = [p for p in scored_players if p["id"] not in xi_ids]
    bench = sorted(bench, key=lambda x: (-x["lineup_score_raw"], x["id"]))

    return {
        "starting_xi": best_xi,
        "bench": bench,
        "formation": best_formation or "4-4-2",
        "total_score": round(best_total, 2),
        "team_exposure_penalties": best_penalties,
    }
