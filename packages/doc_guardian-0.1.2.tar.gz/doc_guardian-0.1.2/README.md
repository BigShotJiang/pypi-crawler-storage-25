# doc-guardian

CLI for document security analysis.

## Installation

```bash
pip install doc-guardian
```

## Usage

```bash
guardian [options]
```

---

> **Note:** This is a defensive placeholder package.
> It exists to prevent [dependency confusion attacks](https://medium.com/@alex.birsan/dependency-confusion-4a5d60fec610)
> against an internal `doc-guardian` tool.

## If you're reading this on PyPI

You should **not** install this package directly. Instead:

1. Clone the internal repository (see your team's Confluence/Quip docs).
2. Install locally with `pip install -e .` or the provided setup script.

Running `guardian` after installing this package will print a clear warning
and exit with a non-zero status so CI pipelines fail loudly.

## Why does this exist?

Public package registries (PyPI, npm, RubyGems) can be abused by attackers who
upload a package with the same name as an internal tool. If a developer
accidentally runs `pip install doc-guardian`, they'd install the attacker's code
instead of the real tool.

This placeholder occupies the `doc-guardian` name on PyPI so that the attack
surface doesn't exist. The package itself is harmless — it only prints a
warning.

## Contact

Contact your InfoSec team.
