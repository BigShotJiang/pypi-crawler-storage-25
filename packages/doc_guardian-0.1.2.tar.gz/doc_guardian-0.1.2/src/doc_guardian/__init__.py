"""
doc-guardian — defensive placeholder package.

If you installed this via `pip install doc-guardian`, you installed
the wrong thing. See the warning printed by the CLI.
"""
