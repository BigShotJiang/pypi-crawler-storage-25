import sys


_BANNER = """
╔══════════════════════════════════════════════════════════════════╗
║                     ⚠  WRONG INSTALLATION  ⚠                    ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║  You installed the PUBLIC PyPI placeholder for doc-guardian.     ║
║                                                                  ║
║  This package is NOT the real tool. You are NOT compromised —    ║
║  this is a safety net to catch accidental `pip install` usage.   ║
║                                                                  ║
║  What to do:                                                     ║
║    1. Run:  pip uninstall doc-guardian                           ║
║    2. Clone the internal repo and install locally instead.       ║
║    3. If you're unsure, contact your InfoSec team.               ║
║                                                                  ║
║  Contact:  your InfoSec team                                     ║
╚══════════════════════════════════════════════════════════════════╝
"""


def main() -> None:
    print(_BANNER, file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    main()
