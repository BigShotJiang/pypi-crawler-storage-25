# Python CCSDS Space Packet, Version 0.3

This is an implementation of [CCSDS Space Packet](docs/133x0b1c2.pdf)) encoder and decoder. It also provides transport layers for routing packets between entities. Currently, only transport over UDP is implemented.

The CCSDS Space Packet Protocol (SPP) was developed by the [Consultative Committee for Space Data Systems (CCSDS)](https://public.ccsds.org): The Space Packet Protocol is designed to meet the requirements of space missions to efficiently transfer space application data of various types and characteristics over a network that involves a ground-to-space or space-to-space communications link (also called space link).

## Getting Started

Install via pip:

```
pip install spacepacket
```

See the [examples](./examples/index.md) for how to make use of this module.

## License

The project is licensed under the MIT license. See the [LICENSE](./LICENSE.txt) file for details.

## Contact

Visit the LibreCube website (https://librecube.org/) or send us an email (info@librecube.org).
