from .constants import SequenceFlags


class SpacePacketProtocolEntity:
    def __init__(self, transport):
        self.transport = transport
        self.transport.indication = self._pdu_received

    def request(self, packet):
        if self.transport:
            self.transport.request(packet.encode())

    def indication(self, packet):
        # to be overwritten by higher layer user
        pass

    def _pdu_received(self, pdu):
        packet = SpacePacket.decode(pdu)
        self.indication(packet)


class SpacePacket:
    def __init__(
        self,
        # packet primary header
        packet_type,
        apid,
        packet_sequence_count,
        packet_sec_hdr_flag=False,
        sequence_flags=SequenceFlags.UNSEGMENTED,
        packet_version=0,  # the current and only version is 0
        # packet data field
        packet_data_field=None,
    ):
        self.packet_type = packet_type
        self.packet_sec_hdr_flag = packet_sec_hdr_flag
        self.apid = apid
        self.packet_sequence_count = packet_sequence_count
        self.sequence_flags = sequence_flags
        self.packet_version = packet_version

        if packet_data_field is None:
            self.packet_data_field = bytearray()
            self.packet_data_length = 0
        else:
            self.packet_data_field = packet_data_field
            self.packet_data_length = len(self.packet_data_field) - 1

    def __repr__(self) -> str:
        return (
            "SpacePacket("
            f"packet_type={self.packet_type}, "
            f"apid={self.apid}, "
            f"packet_sequence_count={self.packet_sequence_count},"
            f"packet_data_field={self.packet_data_field},"
        )

    def encode(self) -> bytes:

        # re-calculate packet data length, in case it has changed
        self.packet_data_length = len(self.packet_data_field) - 1

        databytes = bytes(
            [
                (self.packet_version << 5)
                +
                # packet identification
                (self.packet_type << 4)
                + (self.packet_sec_hdr_flag << 3)
                + (self.apid >> 8),
                (self.apid & 0xFF),
                # packet sequence control
                (self.sequence_flags << 6) + (self.packet_sequence_count >> 8),
                (self.packet_sequence_count & 0xFF),
                # packet data length
                (self.packet_data_length >> 8),
                (self.packet_data_length & 0xFF),
            ]
        )

        databytes += self.packet_data_field
        return databytes

    @classmethod
    def decode(cls, pdu):
        packet_type = (pdu[0] >> 4) & 0x01
        packet_sec_hdr_flag = (pdu[0] >> 3) & 0x01
        apid = ((pdu[0] & 0x07) << 8) + pdu[1]
        sequence_flags = pdu[2] >> 6
        packet_sequence_count = ((pdu[2] & 0x3F) << 8) + pdu[3]
        packet_version = pdu[0] >> 5
        packet_data_length = (pdu[4] << 8) + pdu[5] + 1
        packet_data_field = pdu[6:]

        if packet_data_length != len(packet_data_field):
            raise ValueError("Packet data length mismatch")

        return cls(
            packet_type=packet_type,
            apid=apid,
            packet_sequence_count=packet_sequence_count,
            packet_sec_hdr_flag=packet_sec_hdr_flag,
            sequence_flags=sequence_flags,
            packet_version=packet_version,
            packet_data_field=packet_data_field,
        )
