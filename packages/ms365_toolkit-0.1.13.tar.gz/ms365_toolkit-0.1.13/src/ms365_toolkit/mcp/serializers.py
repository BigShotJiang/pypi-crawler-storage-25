from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

_EMAIL_SUMMARY_PREVIEW_LIMIT = 300
_TEAMS_MESSAGE_PREVIEW_LIMIT = 500
_TEAMS_SEARCH_SUMMARY_LIMIT = 500

if TYPE_CHECKING:
    from collections.abc import Sequence

    from ms365_toolkit.models.calendar import (
        Attendee,
        CalendarEvent,
        ExtractedMeetingTranscript,
        MeetingActionItem,
        MeetingAiInsight,
        MeetingMentionEvent,
        MeetingNotePoint,
        MeetingTranscript,
    )
    from ms365_toolkit.models.email import (
        AttachmentInfo,
        EmailAttachment,
        EmailDraft,
        EmailMessage,
        ExtractedAttachment,
    )
    from ms365_toolkit.models.teams import (
        ChannelSummary,
        ExtractedTeamsFile,
        TeamsChat,
        TeamsMessage,
        TeamsMessageAttachment,
        TeamsMessageSearchHit,
        TeamsParticipant,
        TeamsReplyPage,
        TeamsSender,
        TeamsThread,
        TeamSummary,
    )


def isoformat_utc(value: datetime) -> str:
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def isoformat_utc_or_none(value: datetime | None) -> str | None:
    if value is None:
        return None
    return isoformat_utc(value)


def serialize_email(message: EmailMessage) -> dict[str, Any]:
    return {
        "id": message.id,
        "subject": message.subject,
        "sender": message.sender,
        "to": list(message.to),
        "cc": list(message.cc),
        "bcc": list(message.bcc),
        "body_preview": message.body_preview,
        "body_content": message.body_content,
        "received_at": isoformat_utc(message.received_at),
        "is_read": message.is_read,
        "is_flagged": message.is_flagged,
        "importance": message.importance,
        "has_attachments": message.has_attachments,
        "attachments": [serialize_attachment(item) for item in message.attachments],
        "conversation_id": message.conversation_id,
        "folder_id": message.folder_id,
    }


def serialize_email_summary(message: EmailMessage) -> dict[str, Any]:
    return {
        "id": message.id,
        "subject": message.subject,
        "sender": message.sender,
        "body_preview": _truncate_text(message.body_preview, _EMAIL_SUMMARY_PREVIEW_LIMIT),
        "received_at": isoformat_utc(message.received_at),
        "is_read": message.is_read,
        "importance": message.importance,
        "has_attachments": message.has_attachments,
    }


def serialize_email_draft(draft: EmailDraft) -> dict[str, Any]:
    return {
        "draft_id": draft.draft_id,
        "content_hash": draft.content_hash,
        "to": list(draft.to),
        "cc": list(draft.cc),
        "bcc": list(draft.bcc),
        "subject": draft.subject,
        "body": draft.body,
        "attachments": [serialize_attachment(item) for item in draft.attachments],
        "reply_to": list(draft.reply_to),
        "importance": draft.importance,
        "created_at": isoformat_utc(draft.created_at),
    }


def serialize_attachment(attachment: AttachmentInfo) -> dict[str, Any]:
    return {
        "name": attachment.name,
        "content_type": attachment.content_type,
        "size": attachment.size,
        "sha256": attachment.sha256,
        "is_reference": attachment.is_reference,
    }


def serialize_email_attachment(attachment: EmailAttachment) -> dict[str, Any]:
    return {
        "id": attachment.id,
        "name": attachment.name,
        "content_type": attachment.content_type,
        "size": attachment.size,
        "is_inline": attachment.is_inline,
        "is_reference": attachment.is_reference,
        "odata_type": attachment.odata_type,
    }


def serialize_extracted_attachment(result: ExtractedAttachment) -> dict[str, Any]:
    return {
        "attachment": serialize_email_attachment(result.attachment),
        "format": result.format,
        "text_content": result.text_content,
        "is_truncated": result.is_truncated,
        "warnings": list(result.warnings),
    }


def serialize_event(event: CalendarEvent) -> dict[str, Any]:
    return {
        "id": event.id,
        "subject": event.subject,
        "start": isoformat_utc(event.start),
        "end": isoformat_utc(event.end),
        "timezone": event.timezone,
        "location": event.location,
        "body_content": event.body_content,
        "attendees": [serialize_attendee(item) for item in event.attendees],
        "is_online_meeting": event.is_online_meeting,
        "is_cancelled": event.is_cancelled,
        "importance": event.importance,
        "categories": list(event.categories),
        "recurrence": event.recurrence,
        "organizer": event.organizer,
        "response_status": event.response_status,
        "calendar_id": event.calendar_id,
        "join_url": event.join_url,
        "ical_uid": event.ical_uid,
    }


def serialize_event_summary(event: CalendarEvent) -> dict[str, Any]:
    return {
        "id": event.id,
        "subject": event.subject,
        "start": isoformat_utc(event.start),
        "end": isoformat_utc(event.end),
        "timezone": event.timezone,
        "location": event.location,
        "is_online_meeting": event.is_online_meeting,
        "is_cancelled": event.is_cancelled,
        "importance": event.importance,
        "categories": list(event.categories),
        "organizer": event.organizer,
        "response_status": event.response_status,
        "calendar_id": event.calendar_id,
        "join_url": event.join_url,
        "ical_uid": event.ical_uid,
        "attendee_count": len(event.attendees),
    }


def serialize_attendee(attendee: Attendee) -> dict[str, Any]:
    return {
        "email": attendee.email,
        "name": attendee.name,
        "response": attendee.response,
        "type": attendee.type,
    }


def serialize_windows(windows: Sequence[tuple[datetime, datetime]]) -> list[dict[str, Any]]:
    serialized: list[dict[str, Any]] = []
    for start, end in windows:
        serialized.append(
            {
                "start": isoformat_utc(start),
                "end": isoformat_utc(end),
                "duration_minutes": int((end - start).total_seconds() // 60),
            }
        )
    return serialized


def _truncate_text(value: str, max_chars: int) -> str:
    if len(value) <= max_chars:
        return value
    return value[: max_chars - 1].rstrip() + "..."


def serialize_chat(chat: TeamsChat) -> dict[str, Any]:
    return {
        "id": chat.id,
        "topic": chat.topic,
        "display_label": chat.display_label,
        "chat_type": chat.chat_type,
        "created_at": isoformat_utc_or_none(chat.created_at),
        "last_updated_at": isoformat_utc_or_none(chat.last_updated_at),
        "last_message_read_at": isoformat_utc_or_none(chat.last_message_read_at),
        "web_url": chat.web_url,
        "is_hidden": chat.is_hidden,
        "is_hidden_for_all_members": chat.is_hidden_for_all_members,
        "other_participants": [
            serialize_teams_participant(item) for item in chat.other_participants
        ],
    }


def serialize_chat_summary(chat: TeamsChat) -> dict[str, Any]:
    return {
        "id": chat.id,
        "topic": chat.topic,
        "display_label": chat.display_label,
        "chat_type": chat.chat_type,
        "created_at": isoformat_utc_or_none(chat.created_at),
        "last_updated_at": isoformat_utc_or_none(chat.last_updated_at),
        "web_url": chat.web_url,
        "is_hidden": chat.is_hidden,
        "other_participant_count": len(chat.other_participants),
    }


def serialize_team(team: TeamSummary) -> dict[str, Any]:
    return {
        "id": team.id,
        "display_name": team.display_name,
        "description": team.description,
        "is_archived": team.is_archived,
        "tenant_id": team.tenant_id,
    }


def serialize_channel(channel: ChannelSummary) -> dict[str, Any]:
    return {
        "id": channel.id,
        "display_name": channel.display_name,
        "description": channel.description,
        "membership_type": channel.membership_type,
        "web_url": channel.web_url,
    }


def serialize_teams_sender(sender: TeamsSender) -> dict[str, Any]:
    return {
        "display_name": sender.display_name,
        "email": sender.email,
        "user_id": sender.user_id,
        "kind": sender.kind,
    }


def serialize_teams_participant(participant: TeamsParticipant) -> dict[str, Any]:
    return {
        "display_name": participant.display_name,
        "email": participant.email,
        "user_id": participant.user_id,
    }


def serialize_teams_message(message: TeamsMessage) -> dict[str, Any]:
    return {
        "id": message.id,
        "body_content": message.body_content,
        "content_type": message.content_type,
        "created_at": isoformat_utc_or_none(message.created_at),
        "last_modified_at": isoformat_utc_or_none(message.last_modified_at),
        "last_edited_at": isoformat_utc_or_none(message.last_edited_at),
        "deleted_at": isoformat_utc_or_none(message.deleted_at),
        "subject": message.subject,
        "summary": message.summary,
        "importance": message.importance,
        "message_type": message.message_type,
        "reply_to_id": message.reply_to_id,
        "reply_count": message.reply_count,
        "web_url": message.web_url,
        "chat_id": message.chat_id,
        "team_id": message.team_id,
        "channel_id": message.channel_id,
        "sender": serialize_teams_sender(message.sender),
        "attachments": [serialize_teams_attachment(item) for item in message.attachments],
    }


def serialize_teams_message_summary(message: TeamsMessage) -> dict[str, Any]:
    return {
        "id": message.id,
        "body_preview": _truncate_text(message.body_content, _TEAMS_MESSAGE_PREVIEW_LIMIT),
        "content_type": message.content_type,
        "created_at": isoformat_utc_or_none(message.created_at),
        "subject": message.subject,
        "summary": message.summary,
        "importance": message.importance,
        "message_type": message.message_type,
        "reply_to_id": message.reply_to_id,
        "reply_count": message.reply_count,
        "web_url": message.web_url,
        "chat_id": message.chat_id,
        "team_id": message.team_id,
        "channel_id": message.channel_id,
        "sender": serialize_teams_sender(message.sender),
        "attachment_count": len(message.attachments),
    }


def serialize_teams_message_search_hit(hit: TeamsMessageSearchHit) -> dict[str, Any]:
    return {
        "id": hit.id,
        "summary": hit.summary,
        "created_at": isoformat_utc_or_none(hit.created_at),
        "last_modified_at": isoformat_utc_or_none(hit.last_modified_at),
        "subject": hit.subject,
        "importance": hit.importance,
        "web_url": hit.web_url,
        "chat_id": hit.chat_id,
        "team_id": hit.team_id,
        "channel_id": hit.channel_id,
        "sender_name": hit.sender_name,
        "sender_email": hit.sender_email,
        "location_kind": hit.location_kind,
    }


def serialize_teams_message_search_hit_summary(hit: TeamsMessageSearchHit) -> dict[str, Any]:
    return {
        "id": hit.id,
        "summary": _truncate_text(hit.summary, _TEAMS_SEARCH_SUMMARY_LIMIT),
        "created_at": isoformat_utc_or_none(hit.created_at),
        "subject": hit.subject,
        "importance": hit.importance,
        "web_url": hit.web_url,
        "chat_id": hit.chat_id,
        "team_id": hit.team_id,
        "channel_id": hit.channel_id,
        "sender_name": hit.sender_name,
        "sender_email": hit.sender_email,
        "location_kind": hit.location_kind,
    }


def serialize_teams_reply_page(page: TeamsReplyPage) -> dict[str, Any]:
    return {
        "replies": [serialize_teams_message(item) for item in page.replies],
        "has_more_replies": page.has_more_replies,
    }


def serialize_teams_thread(thread: TeamsThread) -> dict[str, Any]:
    return {
        "root_message": serialize_teams_message(thread.root_message),
        "replies": [serialize_teams_message(item) for item in thread.replies],
        "has_more_replies": thread.has_more_replies,
    }


def serialize_teams_attachment(attachment: TeamsMessageAttachment) -> dict[str, Any]:
    return {
        "id": attachment.id,
        "name": attachment.name,
        "content_type": attachment.content_type,
        "content_url": attachment.content_url,
        "thumbnail_url": attachment.thumbnail_url,
        "teams_app_id": attachment.teams_app_id,
    }


def serialize_extracted_teams_file(result: ExtractedTeamsFile) -> dict[str, Any]:
    return {
        "attachment": serialize_teams_attachment(result.attachment),
        "format": result.format,
        "text_content": result.text_content,
        "is_truncated": result.is_truncated,
        "warnings": list(result.warnings),
    }


def serialize_meeting_transcript(transcript: MeetingTranscript) -> dict[str, Any]:
    return {
        "id": transcript.id,
        "meeting_id": transcript.meeting_id,
        "call_id": transcript.call_id,
        "created_at": isoformat_utc(transcript.created_at),
        "end_at": isoformat_utc(transcript.end_at),
        "content_correlation_id": transcript.content_correlation_id,
        "transcript_content_url": transcript.transcript_content_url,
        "organizer_user_id": transcript.organizer_user_id,
        "organizer_display_name": transcript.organizer_display_name,
        "organizer_tenant_id": transcript.organizer_tenant_id,
    }


def serialize_extracted_meeting_transcript(result: ExtractedMeetingTranscript) -> dict[str, Any]:
    return {
        "transcript": serialize_meeting_transcript(result.transcript),
        "format": result.format,
        "text_content": result.text_content,
        "is_truncated": result.is_truncated,
        "warnings": list(result.warnings),
    }


def serialize_meeting_ai_insight(insight: MeetingAiInsight) -> dict[str, Any]:
    return {
        "id": insight.id,
        "call_id": insight.call_id,
        "content_correlation_id": insight.content_correlation_id,
        "created_at": isoformat_utc(insight.created_at),
        "end_at": isoformat_utc(insight.end_at),
        "meeting_notes": [serialize_meeting_note(item) for item in insight.meeting_notes],
        "action_items": [
            serialize_meeting_action_item(item) for item in insight.action_items
        ],
        "mention_events": [
            serialize_meeting_mention_event(item) for item in insight.mention_events
        ],
    }


def serialize_meeting_note(note: MeetingNotePoint) -> dict[str, Any]:
    return {
        "title": note.title,
        "text": note.text,
        "subpoints": [serialize_meeting_note(item) for item in note.subpoints],
    }


def serialize_meeting_action_item(item: MeetingActionItem) -> dict[str, Any]:
    return {
        "title": item.title,
        "text": item.text,
        "owner_display_name": item.owner_display_name,
    }


def serialize_meeting_mention_event(event: MeetingMentionEvent) -> dict[str, Any]:
    return {
        "event_at": isoformat_utc(event.event_at),
        "speaker_name": event.speaker_name,
        "speaker_user_id": event.speaker_user_id,
        "transcript_utterance": event.transcript_utterance,
    }
