from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from math import ceil
from time import perf_counter
from typing import Any, TypedDict

from ms365_toolkit import __version__
from ms365_toolkit.config.loader import get_profile_dir


class ResultMetrics(TypedDict):
    result_size_chars: int | None
    result_item_count: int | None
    truncated: bool | None


@dataclass(frozen=True)
class UsageEvent:
    profile: str
    surface: str
    name: str
    version: str
    duration_ms: int
    success: bool
    timestamp: datetime
    error_type: str | None = None
    error_code: str | None = None
    write_intent: bool = False
    result_size_chars: int | None = None
    result_item_count: int | None = None
    truncated: bool | None = None


@dataclass
class UsageLogger:
    path: os.PathLike[str] | str
    max_bytes: int = 10 * 1024 * 1024
    backup_count: int = 5

    @classmethod
    def for_profile(cls, profile: str) -> UsageLogger:
        return cls(get_profile_dir(profile) / "usage" / "events.jsonl")

    def __post_init__(self) -> None:
        self.path = os.fspath(self.path)
        os.makedirs(os.path.dirname(self.path), mode=0o700, exist_ok=True)

    def log(self, event: UsageEvent) -> None:
        payload = _event_payload(event)
        encoded = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
        self._rotate_if_needed(len(encoded) + 1)
        fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        try:
            os.write(fd, encoded + b"\n")
        finally:
            os.close(fd)
        os.chmod(self.path, 0o600)

    def _rotate_if_needed(self, incoming_bytes: int) -> None:
        if not os.path.exists(self.path):
            return
        if os.path.getsize(self.path) + incoming_bytes <= self.max_bytes:
            return
        oldest = f"{self.path}.{self.backup_count}"
        if os.path.exists(oldest):
            os.unlink(oldest)
        for index in range(self.backup_count - 1, 0, -1):
            source = f"{self.path}.{index}"
            target = f"{self.path}.{index + 1}"
            if os.path.exists(source):
                os.replace(source, target)
        os.replace(self.path, f"{self.path}.1")


def usage_start() -> float:
    return perf_counter()


def duration_ms(start: float) -> int:
    return max(0, int((perf_counter() - start) * 1000))


def build_usage_event(
    *,
    profile: str,
    surface: str,
    name: str,
    start: float,
    success: bool,
    error_type: str | None = None,
    error_code: str | None = None,
    write_intent: bool = False,
    result: Any = None,
) -> UsageEvent:
    result_metrics = _result_metrics(result)
    return UsageEvent(
        profile=profile,
        surface=surface,
        name=name,
        version=__version__,
        duration_ms=duration_ms(start),
        success=success,
        timestamp=datetime.now(UTC),
        error_type=error_type,
        error_code=error_code,
        write_intent=write_intent,
        result_size_chars=result_metrics["result_size_chars"],
        result_item_count=result_metrics["result_item_count"],
        truncated=result_metrics["truncated"],
    )


def read_usage_events(
    profile: str,
    *,
    days: int,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    cutoff = (now or datetime.now(UTC)) - timedelta(days=days)
    events: list[dict[str, Any]] = []
    for path in _usage_event_paths(profile):
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                try:
                    payload = json.loads(line)
                    timestamp = _parse_timestamp(payload.get("timestamp"))
                except (json.JSONDecodeError, TypeError, ValueError):
                    continue
                if timestamp >= cutoff:
                    events.append(payload)
    return sorted(events, key=lambda item: str(item.get("timestamp", "")))


def summarize_usage(events: list[dict[str, Any]]) -> dict[str, Any]:
    durations = [_int_value(item.get("duration_ms")) for item in events]
    failures = [item for item in events if not bool(item.get("success"))]
    versions: dict[str, int] = {}
    for event in events:
        version = event.get("version")
        if isinstance(version, str) and version:
            versions[version] = versions.get(version, 0) + 1
    return {
        "total_events": len(events),
        "successes": len(events) - len(failures),
        "failures": len(failures),
        "failure_rate": (len(failures) / len(events)) if events else 0.0,
        "avg_duration_ms": _average(durations),
        "p95_duration_ms": _percentile(durations, 95),
        "truncated_count": sum(1 for item in events if bool(item.get("truncated"))),
        "total_mcp_result_chars": sum(
            _int_value(item.get("result_size_chars"))
            for item in events
            if item.get("surface") == "mcp"
        ),
        "versions": dict(sorted(versions.items())),
    }


def summarize_tools(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for event in events:
        key = f"{event.get('surface', 'unknown')}:{event.get('name', 'unknown')}"
        grouped.setdefault(key, []).append(event)
    summaries: list[dict[str, Any]] = []
    for key, items in sorted(grouped.items()):
        durations = [_int_value(item.get("duration_ms")) for item in items]
        failures = [item for item in items if not bool(item.get("success"))]
        summaries.append(
            {
                "name": key,
                "count": len(items),
                "failures": len(failures),
                "avg_duration_ms": _average(durations),
                "p95_duration_ms": _percentile(durations, 95),
                "max_result_chars": max(
                    (_int_value(item.get("result_size_chars")) for item in items),
                    default=0,
                ),
                "truncated_count": sum(1 for item in items if bool(item.get("truncated"))),
            }
        )
    return summaries


def summarize_slow(events: list[dict[str, Any]], *, limit: int) -> list[dict[str, Any]]:
    if limit <= 0:
        raise ValueError("limit must be a positive integer")
    rows: list[dict[str, Any]] = []
    for event in events:
        rows.append(
            {
                "timestamp": str(event.get("timestamp", "")),
                "name": f"{event.get('surface', 'unknown')}:{event.get('name', 'unknown')}",
                "duration_ms": _int_value(event.get("duration_ms")),
                "result_size_chars": _int_value(event.get("result_size_chars")),
                "result_item_count": _int_value(event.get("result_item_count")),
                "truncated": bool(event.get("truncated")),
                "success": bool(event.get("success")),
            }
        )
    rows.sort(
        key=lambda item: (
            item["duration_ms"],
            item["result_size_chars"],
            item["timestamp"],
        ),
        reverse=True,
    )
    return rows[:limit]


def summarize_errors(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for event in events:
        if bool(event.get("success")):
            continue
        key = (str(event.get("error_type") or "UnknownError"), str(event.get("error_code") or ""))
        grouped.setdefault(key, []).append(event)
    summaries: list[dict[str, Any]] = []
    for (error_type, error_code), items in sorted(grouped.items()):
        names = sorted(
            {f"{item.get('surface', 'unknown')}:{item.get('name', 'unknown')}" for item in items}
        )
        summaries.append(
            {
                "error_type": error_type,
                "error_code": error_code,
                "count": len(items),
                "latest_timestamp": max(str(item.get("timestamp", "")) for item in items),
                "names": names,
            }
        )
    return summaries


def _event_payload(event: UsageEvent) -> dict[str, Any]:
    payload = {
        "timestamp": event.timestamp.astimezone(UTC).isoformat().replace("+00:00", "Z"),
        "profile": event.profile,
        "surface": event.surface,
        "name": event.name,
        "version": event.version,
        "duration_ms": event.duration_ms,
        "success": event.success,
        "error_type": event.error_type,
        "error_code": event.error_code,
        "write_intent": event.write_intent,
        "result_size_chars": event.result_size_chars,
        "result_item_count": event.result_item_count,
        "truncated": event.truncated,
    }
    return {key: value for key, value in payload.items() if value is not None}


def _usage_event_paths(profile: str) -> list[str]:
    path = os.fspath(UsageLogger.for_profile(profile).path)
    return [path, *(f"{path}.{index}" for index in range(1, 6))]


def _result_metrics(result: Any) -> ResultMetrics:
    if result is None:
        return {"result_size_chars": None, "result_item_count": None, "truncated": None}
    size = len(json.dumps(result, default=str, separators=(",", ":"), ensure_ascii=False))
    item_count = None
    truncated = None
    if isinstance(result, dict):
        truncated = bool(result.get("truncated")) if "truncated" in result else None
        for value in result.values():
            if isinstance(value, list):
                item_count = len(value)
                break
    return {
        "result_size_chars": size,
        "result_item_count": item_count,
        "truncated": truncated,
    }


def _parse_timestamp(value: Any) -> datetime:
    if not isinstance(value, str):
        raise ValueError("timestamp must be a string")
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def _int_value(value: Any) -> int:
    return value if isinstance(value, int) and not isinstance(value, bool) else 0


def _average(values: list[int]) -> int:
    if not values:
        return 0
    return int(sum(values) / len(values))


def _percentile(values: list[int], percentile: int) -> int:
    if not values:
        return 0
    sorted_values = sorted(values)
    index = max(0, ceil((percentile / 100) * len(sorted_values)) - 1)
    return sorted_values[index]
