from __future__ import annotations

from typing import TYPE_CHECKING

from ms365_toolkit.usage import (
    read_usage_events,
    summarize_errors,
    summarize_slow,
    summarize_tools,
    summarize_usage,
)

if TYPE_CHECKING:
    from argparse import Namespace

    from ms365_toolkit.config.loader import ToolkitConfig


def usage_summary_command(args: Namespace, config: ToolkitConfig) -> int:
    events = read_usage_events(config.profile, days=_days(args))
    summary = summarize_usage(events)
    print(f"Events: {summary['total_events']}")
    print(f"Successes: {summary['successes']}")
    print(f"Failures: {summary['failures']}")
    print(f"Failure rate: {summary['failure_rate']:.1%}")
    print(f"Average duration: {summary['avg_duration_ms']}ms")
    print(f"P95 duration: {summary['p95_duration_ms']}ms")
    print(f"Truncated responses: {summary['truncated_count']}")
    print(f"MCP result chars: {summary['total_mcp_result_chars']}")
    versions = summary["versions"]
    if versions:
        print(
            "Versions: "
            + ", ".join(f"{version}={count}" for version, count in versions.items())
        )
    return 0


def usage_tools_command(args: Namespace, config: ToolkitConfig) -> int:
    rows = summarize_tools(read_usage_events(config.profile, days=_days(args)))
    if not rows:
        print("No usage events found.")
        return 0
    for row in rows:
        print(
            f"{row['name']} count={row['count']} failures={row['failures']} "
            f"avg={row['avg_duration_ms']}ms p95={row['p95_duration_ms']}ms "
            f"max_chars={row['max_result_chars']} truncated={row['truncated_count']}"
        )
    return 0


def usage_slow_command(args: Namespace, config: ToolkitConfig) -> int:
    rows = summarize_slow(read_usage_events(config.profile, days=_days(args)), limit=_top(args))
    if not rows:
        print("No usage events found.")
        return 0
    for row in rows:
        print(
            f"{row['timestamp']} {row['name']} duration={row['duration_ms']}ms "
            f"chars={row['result_size_chars']} items={row['result_item_count']} "
            f"truncated={row['truncated']} success={row['success']}"
        )
    return 0


def usage_errors_command(args: Namespace, config: ToolkitConfig) -> int:
    rows = summarize_errors(read_usage_events(config.profile, days=_days(args)))
    if not rows:
        print("No usage errors found.")
        return 0
    for row in rows:
        code = f" code={row['error_code']}" if row["error_code"] else ""
        names = ",".join(row["names"])
        print(
            f"{row['error_type']}{code} count={row['count']} "
            f"latest={row['latest_timestamp']} tools={names}"
        )
    return 0


def _days(args: Namespace) -> int:
    days = int(args.days)
    if days <= 0:
        raise ValueError("days must be a positive integer")
    return days


def _top(args: Namespace) -> int:
    top = int(args.top)
    if top <= 0:
        raise ValueError("top must be a positive integer")
    return top
