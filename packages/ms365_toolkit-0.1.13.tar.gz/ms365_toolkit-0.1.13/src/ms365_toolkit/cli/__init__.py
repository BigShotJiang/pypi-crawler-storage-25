from __future__ import annotations

import argparse
from typing import TYPE_CHECKING

from ms365_toolkit.cli.auth import login_command, revoke_write_command, status_command
from ms365_toolkit.cli.inbox import inbox_command
from ms365_toolkit.cli.labeling import (
    export_label_candidates_command,
    label_thread_command,
    review_label_candidates_command,
)
from ms365_toolkit.cli.labeling_web import launch_label_ui_command
from ms365_toolkit.cli.read_tools import (
    download_email_attachments_command,
    download_teams_message_files_command,
    list_channel_messages_command,
    list_channel_replies_command,
    list_channels_command,
    list_chat_messages_command,
    list_chats_command,
    list_email_attachments_command,
    list_events_command,
    list_meeting_transcripts_command,
    list_teams_command,
    list_teams_message_files_command,
    morning_brief_command,
    read_channel_message_command,
    read_channel_thread_command,
    read_chat_message_command,
    read_email_attachment_command,
    read_email_command,
    read_meeting_notes_command,
    read_meeting_transcript_command,
    read_teams_message_file_command,
    search_channel_messages_command,
    search_chat_messages_command,
    search_chats_command,
    search_emails_command,
    search_local_mail_index_command,
    search_teams_messages_command,
    sync_mail_index_command,
    triage_inbox_command,
)
from ms365_toolkit.cli.usage import (
    usage_errors_command,
    usage_slow_command,
    usage_summary_command,
    usage_tools_command,
)
from ms365_toolkit.cli.versioning import doctor_command, version_command
from ms365_toolkit.cli.write_tools import (
    create_email_draft_command,
    create_reply_draft_command,
    send_email_draft_command,
)
from ms365_toolkit.client.exceptions import GraphAPIError, SafetyDeniedError
from ms365_toolkit.config.loader import load_config
from ms365_toolkit.usage import UsageLogger, build_usage_event, usage_start

if TYPE_CHECKING:
    from collections.abc import Sequence


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    if not hasattr(args, "handler"):
        parser.print_help()
        return 1
    start = usage_start()
    name = _usage_command_name(args)
    write_intent = _is_write_intent(args, name)
    if args.command in {"doctor", "revoke-write", "version"}:
        return _run_cli_handler(
            args,
            start=start,
            name=name,
            write_intent=write_intent,
            handler=lambda: int(args.handler(args)),
        )
    return _run_cli_handler(
        args,
        start=start,
        name=name,
        write_intent=write_intent,
        handler=lambda: int(args.handler(args, load_config(profile=args.profile))),
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ms365-toolkit")
    parser.add_argument("--profile", default="default")
    subparsers = parser.add_subparsers(dest="command")

    version_parser = subparsers.add_parser("version")
    version_parser.add_argument("--check", action="store_true")
    version_parser.set_defaults(handler=version_command)

    doctor_parser = subparsers.add_parser("doctor")
    doctor_parser.set_defaults(handler=doctor_command)

    auth_parser = subparsers.add_parser("auth")
    auth_subparsers = auth_parser.add_subparsers(dest="auth_command")

    login_parser = auth_subparsers.add_parser("login")
    login_parser.add_argument("--write", action="store_true")
    login_parser.add_argument("--teams-channel-messages", action="store_true")
    login_parser.add_argument("--teams-files", action="store_true")
    login_parser.add_argument("--meeting-transcripts", action="store_true")
    login_parser.add_argument("--meeting-notes", action="store_true")
    login_parser.add_argument("--insecure-env-write", action="store_true")
    login_parser.set_defaults(handler=login_command)

    status_parser = auth_subparsers.add_parser("status")
    status_parser.add_argument("--write", action="store_true")
    status_parser.set_defaults(handler=status_command)

    revoke_parser = auth_subparsers.add_parser("revoke-write")
    revoke_parser.set_defaults(handler=revoke_write_command, command="revoke-write")

    inbox_parser = subparsers.add_parser("inbox")
    inbox_parser.add_argument("--top", type=int, default=10)
    inbox_parser.add_argument("--filter", choices=("focused", "all"), default="all")
    inbox_parser.set_defaults(handler=inbox_command)

    search_parser = subparsers.add_parser("search-emails")
    search_parser.add_argument("query")
    search_parser.add_argument("--top", type=int, default=10)
    search_parser.add_argument("--filter", choices=("focused", "all"), default="all")
    search_parser.set_defaults(handler=search_emails_command)

    sync_index_parser = subparsers.add_parser("sync-mail-index")
    sync_index_parser.add_argument("--batch-size", type=int, default=100)
    sync_index_parser.add_argument("--max-pages", type=int, default=10)
    sync_index_parser.set_defaults(handler=sync_mail_index_command)

    search_local_parser = subparsers.add_parser("search-local-mail")
    search_local_parser.add_argument("query")
    search_local_parser.add_argument("--top", type=int, default=10)
    search_local_parser.set_defaults(handler=search_local_mail_index_command)

    export_labels_parser = subparsers.add_parser("export-label-candidates")
    export_labels_parser.add_argument("--top", type=int, default=20)
    export_labels_parser.add_argument("--sync-index", action="store_true")
    export_labels_parser.add_argument("--max-pages", type=int, default=5)
    export_labels_parser.set_defaults(handler=export_label_candidates_command)

    review_labels_parser = subparsers.add_parser("review-label-candidates")
    review_labels_parser.add_argument("--top", type=int, default=10)
    review_labels_parser.add_argument(
        "--status",
        choices=("unlabeled", "labeled", "all"),
        default="unlabeled",
    )
    review_labels_parser.add_argument("--thread-id")
    review_labels_parser.set_defaults(handler=review_label_candidates_command)

    label_ui_parser = subparsers.add_parser("label-ui")
    label_ui_parser.add_argument("--host", default="127.0.0.1")
    label_ui_parser.add_argument("--port", type=int, default=8765)
    label_ui_parser.add_argument("--no-open", action="store_true")
    label_ui_parser.set_defaults(handler=launch_label_ui_command)

    label_thread_parser = subparsers.add_parser("label-thread")
    label_thread_parser.add_argument("thread_id")
    label_thread_parser.add_argument(
        "--thread-class",
        required=True,
        choices=(
            "approval_request",
            "decision_request",
            "incident_or_risk",
            "contract_or_renewal",
            "strategic_update",
            "status_update",
            "fyi_noise",
        ),
    )
    label_thread_parser.add_argument(
        "--action-needed",
        required=True,
        choices=("yes", "no", "unclear"),
    )
    label_thread_parser.add_argument(
        "--urgency",
        required=True,
        choices=("high", "medium", "low"),
    )
    label_thread_parser.add_argument(
        "--acted-by-you",
        required=True,
        choices=("replied", "forwarded", "ignored", "archived", "unknown"),
    )
    label_thread_parser.add_argument("--confidence", required=True, type=float)
    label_thread_parser.add_argument("--notes")
    label_thread_parser.set_defaults(handler=label_thread_command)

    triage_parser = subparsers.add_parser("triage-inbox")
    triage_parser.add_argument("--top", type=int, default=15)
    triage_parser.add_argument("--limit", type=int, default=5)
    triage_parser.add_argument("--sync-index", action="store_true")
    triage_parser.add_argument("--max-pages", type=int, default=5)
    triage_parser.set_defaults(handler=triage_inbox_command)

    read_email_parser = subparsers.add_parser("read-email")
    read_email_parser.add_argument("message_id")
    read_email_parser.set_defaults(handler=read_email_command)

    create_email_draft_parser = subparsers.add_parser("create-email-draft")
    create_email_draft_parser.add_argument("--to", nargs="+", required=True)
    create_email_draft_parser.add_argument("--cc", nargs="+")
    create_email_draft_parser.add_argument("--bcc", nargs="+")
    create_email_draft_parser.add_argument("--reply-to", nargs="+")
    create_email_draft_parser.add_argument("--subject", required=True)
    create_email_draft_body_group = create_email_draft_parser.add_mutually_exclusive_group(
        required=True
    )
    create_email_draft_body_group.add_argument("--body")
    create_email_draft_body_group.add_argument("--body-file")
    create_email_draft_parser.add_argument(
        "--importance",
        choices=("low", "normal", "high"),
        default="normal",
    )
    create_email_draft_parser.set_defaults(handler=create_email_draft_command)

    create_reply_draft_parser = subparsers.add_parser("create-reply-draft")
    create_reply_draft_parser.add_argument("message_id")
    create_reply_draft_body_group = create_reply_draft_parser.add_mutually_exclusive_group(
        required=True
    )
    create_reply_draft_body_group.add_argument("--body")
    create_reply_draft_body_group.add_argument("--body-file")
    create_reply_draft_parser.add_argument("--importance", choices=("low", "normal", "high"))
    create_reply_draft_parser.set_defaults(handler=create_reply_draft_command)

    send_email_draft_parser = subparsers.add_parser("send-email-draft")
    send_email_draft_parser.add_argument("draft_id")
    send_email_draft_parser.add_argument("content_hash")
    send_email_draft_parser.set_defaults(handler=send_email_draft_command)

    usage_parser = subparsers.add_parser("usage")
    usage_subparsers = usage_parser.add_subparsers(dest="usage_command")
    usage_summary_parser = usage_subparsers.add_parser("summary")
    usage_summary_parser.add_argument("--days", type=int, default=7)
    usage_summary_parser.set_defaults(handler=usage_summary_command)
    usage_tools_parser = usage_subparsers.add_parser("tools")
    usage_tools_parser.add_argument("--days", type=int, default=7)
    usage_tools_parser.set_defaults(handler=usage_tools_command)
    usage_errors_parser = usage_subparsers.add_parser("errors")
    usage_errors_parser.add_argument("--days", type=int, default=7)
    usage_errors_parser.set_defaults(handler=usage_errors_command)
    usage_slow_parser = usage_subparsers.add_parser("slow")
    usage_slow_parser.add_argument("--days", type=int, default=7)
    usage_slow_parser.add_argument("--top", type=int, default=10)
    usage_slow_parser.set_defaults(handler=usage_slow_command)

    list_email_attachments_parser = subparsers.add_parser("list-email-attachments")
    list_email_attachments_parser.add_argument("message_id")
    list_email_attachments_parser.add_argument("--include-inline", action="store_true")
    list_email_attachments_parser.set_defaults(handler=list_email_attachments_command)

    read_email_attachment_parser = subparsers.add_parser("read-email-attachment")
    read_email_attachment_parser.add_argument("message_id")
    read_email_attachment_parser.add_argument("attachment_id")
    read_email_attachment_parser.add_argument("--max-chars", type=int, default=50_000)
    read_email_attachment_parser.set_defaults(handler=read_email_attachment_command)

    download_attachments_parser = subparsers.add_parser("download-email-attachments")
    download_attachments_parser.add_argument("message_id")
    download_attachments_parser.add_argument("--output-dir", default=".")
    download_attachments_parser.add_argument("--include-inline", action="store_true")
    download_attachments_parser.add_argument("--attachment-id", action="append")
    download_attachments_parser.add_argument("--extensions", nargs="+")
    download_attachments_parser.set_defaults(handler=download_email_attachments_command)

    list_teams_message_files_parser = subparsers.add_parser("list-teams-message-files")
    list_teams_message_files_parser.add_argument("message_id")
    list_teams_message_files_parser.add_argument("--chat-id")
    list_teams_message_files_parser.add_argument("--team-id")
    list_teams_message_files_parser.add_argument("--channel-id")
    list_teams_message_files_parser.set_defaults(handler=list_teams_message_files_command)

    read_teams_message_file_parser = subparsers.add_parser("read-teams-message-file")
    read_teams_message_file_parser.add_argument("message_id")
    read_teams_message_file_parser.add_argument("attachment_id")
    read_teams_message_file_parser.add_argument("--chat-id")
    read_teams_message_file_parser.add_argument("--team-id")
    read_teams_message_file_parser.add_argument("--channel-id")
    read_teams_message_file_parser.add_argument("--max-chars", type=int, default=50_000)
    read_teams_message_file_parser.set_defaults(handler=read_teams_message_file_command)

    download_teams_message_files_parser = subparsers.add_parser("download-teams-message-files")
    download_teams_message_files_parser.add_argument("message_id")
    download_teams_message_files_parser.add_argument("--chat-id")
    download_teams_message_files_parser.add_argument("--team-id")
    download_teams_message_files_parser.add_argument("--channel-id")
    download_teams_message_files_parser.add_argument("--output-dir", default=".")
    download_teams_message_files_parser.add_argument("--attachment-id", action="append")
    download_teams_message_files_parser.add_argument("--extensions", nargs="+")
    download_teams_message_files_parser.set_defaults(handler=download_teams_message_files_command)

    list_events_parser = subparsers.add_parser("list-events")
    list_events_parser.add_argument("--hours", type=int, default=8)
    list_events_parser.set_defaults(handler=list_events_command)

    list_meeting_transcripts_parser = subparsers.add_parser("list-meeting-transcripts")
    list_meeting_transcripts_parser.add_argument("--event-id")
    list_meeting_transcripts_parser.add_argument("--join-web-url")
    list_meeting_transcripts_parser.add_argument("--online-meeting-id")
    list_meeting_transcripts_parser.add_argument("--top", type=int, default=10)
    list_meeting_transcripts_parser.set_defaults(handler=list_meeting_transcripts_command)

    read_meeting_transcript_parser = subparsers.add_parser("read-meeting-transcript")
    read_meeting_transcript_parser.add_argument("--event-id")
    read_meeting_transcript_parser.add_argument("--join-web-url")
    read_meeting_transcript_parser.add_argument("--online-meeting-id")
    read_meeting_transcript_parser.add_argument("--transcript-id")
    read_meeting_transcript_parser.add_argument("--max-chars", type=int, default=50_000)
    read_meeting_transcript_parser.set_defaults(handler=read_meeting_transcript_command)

    read_meeting_notes_parser = subparsers.add_parser("read-meeting-notes")
    read_meeting_notes_parser.add_argument("--event-id")
    read_meeting_notes_parser.add_argument("--join-web-url")
    read_meeting_notes_parser.add_argument("--online-meeting-id")
    read_meeting_notes_parser.add_argument("--ai-insight-id")
    read_meeting_notes_parser.set_defaults(handler=read_meeting_notes_command)

    list_chats_parser = subparsers.add_parser("list-chats")
    list_chats_parser.add_argument("--top", type=int, default=25)
    list_chats_parser.set_defaults(handler=list_chats_command)

    search_chats_parser = subparsers.add_parser("search-chats")
    search_chats_parser.add_argument("query")
    search_chats_parser.add_argument("--top", type=int, default=10)
    search_chats_parser.set_defaults(handler=search_chats_command)

    list_chat_messages_parser = subparsers.add_parser("list-chat-messages")
    list_chat_messages_parser.add_argument("chat_id")
    list_chat_messages_parser.add_argument("--top", type=int, default=25)
    list_chat_messages_parser.set_defaults(handler=list_chat_messages_command)

    search_chat_messages_parser = subparsers.add_parser("search-chat-messages")
    search_chat_messages_parser.add_argument("chat_id")
    search_chat_messages_parser.add_argument("query")
    search_chat_messages_parser.add_argument("--top", type=int, default=10)
    search_chat_messages_parser.set_defaults(handler=search_chat_messages_command)

    search_teams_messages_parser = subparsers.add_parser("search-teams-messages")
    search_teams_messages_parser.add_argument("query")
    search_teams_messages_parser.add_argument("--top", type=int, default=10)
    search_teams_messages_parser.set_defaults(handler=search_teams_messages_command)

    read_chat_message_parser = subparsers.add_parser("read-chat-message")
    read_chat_message_parser.add_argument("chat_id")
    read_chat_message_parser.add_argument("message_id")
    read_chat_message_parser.set_defaults(handler=read_chat_message_command)

    list_teams_parser = subparsers.add_parser("list-teams")
    list_teams_parser.set_defaults(handler=list_teams_command)

    list_channels_parser = subparsers.add_parser("list-channels")
    list_channels_parser.add_argument("team_id")
    list_channels_parser.set_defaults(handler=list_channels_command)

    list_channel_messages_parser = subparsers.add_parser("list-channel-messages")
    list_channel_messages_parser.add_argument("team_id")
    list_channel_messages_parser.add_argument("channel_id")
    list_channel_messages_parser.add_argument("--top", type=int, default=25)
    list_channel_messages_parser.set_defaults(handler=list_channel_messages_command)

    search_channel_messages_parser = subparsers.add_parser("search-channel-messages")
    search_channel_messages_parser.add_argument("team_id")
    search_channel_messages_parser.add_argument("channel_id")
    search_channel_messages_parser.add_argument("query")
    search_channel_messages_parser.add_argument("--top", type=int, default=10)
    search_channel_messages_parser.set_defaults(handler=search_channel_messages_command)

    list_channel_replies_parser = subparsers.add_parser("list-channel-replies")
    list_channel_replies_parser.add_argument("team_id")
    list_channel_replies_parser.add_argument("channel_id")
    list_channel_replies_parser.add_argument("message_id")
    list_channel_replies_parser.add_argument("--top", type=int, default=25)
    list_channel_replies_parser.set_defaults(handler=list_channel_replies_command)

    read_channel_message_parser = subparsers.add_parser("read-channel-message")
    read_channel_message_parser.add_argument("team_id")
    read_channel_message_parser.add_argument("channel_id")
    read_channel_message_parser.add_argument("message_id")
    read_channel_message_parser.set_defaults(handler=read_channel_message_command)

    read_channel_thread_parser = subparsers.add_parser("read-channel-thread")
    read_channel_thread_parser.add_argument("team_id")
    read_channel_thread_parser.add_argument("channel_id")
    read_channel_thread_parser.add_argument("message_id")
    read_channel_thread_parser.add_argument("--top", type=int, default=25)
    read_channel_thread_parser.set_defaults(handler=read_channel_thread_command)

    morning_brief_parser = subparsers.add_parser("morning-brief")
    morning_brief_parser.add_argument("--top", type=int, default=10)
    morning_brief_parser.set_defaults(handler=morning_brief_command)

    return parser


def _run_cli_handler(
    args: argparse.Namespace,
    *,
    start: float,
    name: str,
    write_intent: bool,
    handler,
) -> int:
    try:
        exit_code = handler()
    except Exception as exc:
        UsageLogger.for_profile(args.profile).log(
            build_usage_event(
                profile=args.profile,
                surface="cli",
                name=name,
                start=start,
                success=False,
                error_type=type(exc).__name__,
                error_code=_cli_error_code(exc),
                write_intent=write_intent,
            )
        )
        raise
    UsageLogger.for_profile(args.profile).log(
        build_usage_event(
            profile=args.profile,
            surface="cli",
            name=name,
            start=start,
            success=exit_code == 0,
            error_type=None if exit_code == 0 else "ExitCode",
            error_code=None if exit_code == 0 else str(exit_code),
            write_intent=write_intent,
        )
    )
    return exit_code


def _usage_command_name(args: argparse.Namespace) -> str:
    if getattr(args, "auth_command", None):
        return f"auth:{args.auth_command}"
    if getattr(args, "usage_command", None):
        return f"usage:{args.usage_command}"
    return str(args.command)


def _is_write_intent(args: argparse.Namespace, name: str) -> bool:
    if name == "auth:login" and bool(getattr(args, "write", False)):
        return True
    return name in {
        "create-email-draft",
        "create-reply-draft",
        "send-email-draft",
    }


def _cli_error_code(exc: Exception) -> str | None:
    if isinstance(exc, GraphAPIError):
        return f"{exc.status_code}:{exc.error_code}"
    if isinstance(exc, SafetyDeniedError):
        return exc.reason
    return None
