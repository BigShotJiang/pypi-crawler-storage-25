from __future__ import annotations

from typing import TYPE_CHECKING

from ms365_toolkit import __version__
from ms365_toolkit.config.loader import get_config_path, get_profile_dir, load_config
from ms365_toolkit.version_status import ToolkitVersionStatus, get_toolkit_status

if TYPE_CHECKING:
    from argparse import Namespace


def version_command(args: Namespace) -> int:
    if not bool(args.check):
        print(__version__)
        return 0

    status = get_toolkit_status(args.profile)
    _print_version_status(status)
    if status.is_stale is True:
        return 10
    if status.is_stale is None:
        return 1
    return 0


def doctor_command(args: Namespace) -> int:
    status = get_toolkit_status(args.profile)
    print(f"Profile: {args.profile}")
    print(f"Profile path: {get_profile_dir(args.profile)}")
    print(f"Config path: {get_config_path(args.profile)}")
    _print_config_status(args.profile)
    _print_version_status(status)
    print(f"Cache path: {status.cache_path}")
    if status.update_commands:
        print("Update commands:")
        for name, command in status.update_commands.items():
            print(f"{name}: {command}")
    return 0 if status.is_stale is not None else 1


def _print_config_status(profile: str) -> None:
    try:
        load_config(profile=profile)
    except FileNotFoundError:
        print("Config: missing")
    except OSError as exc:
        print(f"Config: unreadable ({exc})")
    except ValueError as exc:
        print(f"Config: invalid ({exc})")
    else:
        print("Config: valid")


def _print_version_status(status: ToolkitVersionStatus) -> None:
    state = _state_label(status)
    print(f"Version: {status.version}")
    print(f"Status: {state}")
    print(f"Source: {status.source}")
    if status.checked_at is not None:
        print(f"Checked at: {status.checked_at}")
    for package in status.packages:
        latest = package.latest_version or "unknown"
        package_state = _package_state_label(package.is_stale)
        print(
            f"{package.package}: current={package.current_version} "
            f"latest={latest} {package_state}"
        )
        if package.error is not None:
            print(f"{package.package} check error: {package.error}")
    if status.check_error is not None:
        print(f"Check error: {status.check_error}")


def _state_label(status: ToolkitVersionStatus) -> str:
    if status.is_stale is True:
        return "stale"
    if status.is_stale is False:
        return "current"
    return "unknown"


def _package_state_label(value: bool | None) -> str:
    if value is True:
        return "stale"
    if value is False:
        return "current"
    return "unknown"
