# Changelog

## 0.1.13 - 2026-04-18

- Added `offset` continuation support to compact MCP list/search tools so callers can page through results after `max_chars` truncation.
- Added `next_offset` and warnings to truncated compact MCP responses.
- Kept full read/detail tools unchanged.

## 0.1.12 - 2026-04-18

- Added compact MCP response budgets for Teams and calendar list/search tools to reduce token pressure.
- Added `ms365-toolkit usage slow` to identify slow tools and large MCP responses from local usage analytics.
- Kept full read/detail tools unchanged so agents can fetch complete records after summary discovery.

## 0.1.11 - 2026-04-18

- Added local-only usage analytics for CLI and MCP calls, including durations, success/failure counts, result-size metrics, truncation counts, and observed toolkit versions.
- Added `ms365-toolkit version`, `ms365-toolkit version --check`, and `ms365-toolkit doctor` for explicit stale-version detection and update guidance.
- Added MCP `get_toolkit_status` for Codex/Claude sessions to inspect installed and latest toolkit versions.
- Added opt-in cache-only MCP startup stale warnings via `MS365_TOOLKIT_WARN_STALE=1`.
- Documented `ms365-toolkit-mcp@latest` as the recommended MCP registration path and kept pinned registration as a reproducible fallback.
- Clarified that existing pinned Codex/Claude registrations should be rerun with `@latest` and active sessions restarted.
