from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from io import BytesIO
from typing import TYPE_CHECKING, Any
from urllib.error import HTTPError
from urllib.parse import parse_qs, urlsplit

from docx import Document
from openpyxl import Workbook
from pptx import Presentation

from ms365_toolkit.client.email import EmailClient
from ms365_toolkit.client.exceptions import SafetyDeniedError
from ms365_toolkit.client.graph import GraphClient
from ms365_toolkit.config.loader import load_config, write_config_text
from ms365_toolkit.safety.audit import AuditLogger
from ms365_toolkit.safety.gate import ConfiguredSafetyGate, SafetyResult
from ms365_toolkit.safety.rate_limiter import RateLimiter

if TYPE_CHECKING:
    from pathlib import Path


def test_list_inbox_uses_focused_filter_then_falls_back(tmp_path: Path) -> None:
    calls: list[dict[str, Any]] = []
    responses = iter(
        [
            {"value": []},
            {"value": [_message_item("msg-1")]},
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        calls.append({"url": req.full_url})
        return _response(next(responses))

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    messages = client.list_inbox(mailbox_filter="focused", top=5)

    assert len(messages) == 1
    assert "inferenceClassification+eq+'focused'" in calls[0]["url"]
    assert len(calls) == 2


def test_read_email_maps_graph_payload_to_email_message(tmp_path: Path) -> None:
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(_message_item("msg-1")),
        )
    )

    message = client.read_email("msg-1")

    assert message.id == "msg-1"
    assert message.sender == "sender@example.com"
    assert message.to == ("to@example.com",)
    assert message.body_content == "<untrusted-email-content>Hello world</untrusted-email-content>"
    assert message.received_at == datetime(2026, 3, 12, 15, 0, tzinfo=UTC)
    assert message.is_flagged is True
    assert message.attachments[0].name == "report.txt"
    assert message.attachments[0].sha256 == hashlib.sha256(b"i\xb7").hexdigest()


def test_download_attachments_fetches_bytes_and_skips_reference_attachments(tmp_path: Path) -> None:
    calls: list[str] = []
    responses = iter(
        [
            {
                "value": [
                    {
                        "id": "att-1",
                        "name": "report.txt",
                        "contentType": "text/plain",
                        "size": 10,
                        "@odata.type": "#microsoft.graph.fileAttachment",
                    },
                    {
                        "id": "att-2",
                        "name": "shared.docx",
                        "contentType": (
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        ),
                        "size": 0,
                        "@odata.type": "#microsoft.graph.referenceAttachment",
                    },
                ]
            },
            {
                "id": "att-1",
                "name": "report.txt",
                "contentType": "text/plain",
                "size": 10,
                "@odata.type": "#microsoft.graph.fileAttachment",
            },
            b"hello",
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        payload = next(responses)
        if isinstance(payload, bytes):
            return _bytes_response(payload)
        return _response(payload)

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    attachments = client.download_attachments("msg-1")

    assert [item.name for item in attachments] == ["report.txt"]
    assert attachments[0].content == b"hello"
    assert (
        calls[0]
        == "https://graph.microsoft.com/v1.0/me/messages/msg-1/attachments?$top=100"
    )
    assert (
        calls[1]
        == "https://graph.microsoft.com/v1.0/me/messages/msg-1/attachments/att-1"
    )
    assert (
        calls[2]
        == "https://graph.microsoft.com/v1.0/me/messages/msg-1/attachments/att-1/$value"
    )


def test_download_attachments_uses_inline_content_bytes_when_available(tmp_path: Path) -> None:
    calls: list[str] = []

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        if len(calls) == 1:
            return _response(
                {
                    "value": [
                        {
                            "id": "att-1",
                            "name": "report.txt",
                            "contentType": "text/plain",
                            "size": 10,
                            "contentBytes": "aGVsbG8=",
                            "@odata.type": "#microsoft.graph.fileAttachment",
                        }
                    ]
                }
            )
        return _response(
            {
                "id": "att-1",
                "name": "report.txt",
                "contentType": "text/plain",
                "size": 10,
                "contentBytes": "aGVsbG8=",
                "@odata.type": "#microsoft.graph.fileAttachment",
            }
        )

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    attachments = client.download_attachments("msg-1")

    assert len(attachments) == 1
    assert attachments[0].content == b"hello"
    assert calls == [
        "https://graph.microsoft.com/v1.0/me/messages/msg-1/attachments?$top=100",
        "https://graph.microsoft.com/v1.0/me/messages/msg-1/attachments/att-1",
    ]


def test_list_attachments_returns_file_metadata_and_skips_inline_by_default(tmp_path: Path) -> None:
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {
                    "value": [
                        _attachment_item_payload(
                            attachment_id="att-1",
                            name="report.docx",
                            content_type=(
                                "application/vnd.openxmlformats-officedocument."
                                "wordprocessingml.document"
                            ),
                            size=120,
                        ),
                        _attachment_item_payload(
                            attachment_id="att-2",
                            name="inline.pdf",
                            content_type="application/pdf",
                            size=80,
                            is_inline=True,
                        ),
                    ]
                }
            ),
        )
    )

    attachments = client.list_attachments("msg-1")

    assert [(item.id, item.name) for item in attachments] == [("att-1", "report.docx")]


def test_download_attachment_fetches_single_attachment_by_id(tmp_path: Path) -> None:
    calls: list[str] = []

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        if req.full_url.endswith("/$value"):
            return _bytes_response(b"report body")
        return _response(
            _attachment_item_payload(
                attachment_id="att-1",
                name="report.docx",
                content_type="application/pdf",
                size=11,
            )
        )

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    attachment = client.download_attachment("msg-1", "att-1")

    assert attachment.name == "report.docx"
    assert attachment.content == b"report body"
    assert calls == [
        "https://graph.microsoft.com/v1.0/me/messages/msg-1/attachments/att-1",
        "https://graph.microsoft.com/v1.0/me/messages/msg-1/attachments/att-1/$value",
    ]


def test_read_attachment_text_extracts_docx_content(tmp_path: Path) -> None:
    payload = _attachment_item_payload(
        attachment_id="att-1",
        name="brief.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        size=128,
        content=_docx_bytes(),
    )
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(payload),
        )
    )

    extracted = client.read_attachment_text("msg-1", "att-1")

    assert extracted.format == "docx"
    assert "Quarterly review" in extracted.text_content
    assert "Owner\tStatus" in extracted.text_content


def test_read_attachment_text_extracts_xlsx_content(tmp_path: Path) -> None:
    payload = _attachment_item_payload(
        attachment_id="att-1",
        name="brief.xlsx",
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        size=128,
        content=_xlsx_bytes(),
    )
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(payload),
        )
    )

    extracted = client.read_attachment_text("msg-1", "att-1")

    assert extracted.format == "xlsx"
    assert "[Sheet Summary]" in extracted.text_content
    assert "Owner\tStatus" in extracted.text_content
    assert "Alyssa\tReady" in extracted.text_content


def test_read_attachment_text_extracts_pptx_content(tmp_path: Path) -> None:
    payload = _attachment_item_payload(
        attachment_id="att-1",
        name="brief.pptx",
        content_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        size=128,
        content=_pptx_bytes(),
    )
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(payload),
        )
    )

    extracted = client.read_attachment_text("msg-1", "att-1")

    assert extracted.format == "pptx"
    assert "[Slide 1]" in extracted.text_content
    assert "Renewal status" in extracted.text_content
    assert "Need legal sign-off" in extracted.text_content


def test_read_attachment_text_extracts_pdf_content(tmp_path: Path) -> None:
    payload = _attachment_item_payload(
        attachment_id="att-1",
        name="brief.pdf",
        content_type="application/pdf",
        size=128,
        content=_pdf_bytes("Renewal Summary"),
    )
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(payload),
        )
    )

    extracted = client.read_attachment_text("msg-1", "att-1")

    assert extracted.format == "pdf"
    assert "[Page 1]" in extracted.text_content
    assert "Renewal Summary" in extracted.text_content


def test_read_attachment_text_marks_truncation(tmp_path: Path) -> None:
    payload = _attachment_item_payload(
        attachment_id="att-1",
        name="brief.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        size=128,
        content=_docx_bytes(),
    )
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(payload),
        )
    )

    extracted = client.read_attachment_text("msg-1", "att-1", max_chars=12)

    assert extracted.is_truncated is True
    assert extracted.warnings == ("Content truncated to 12 characters.",)


def test_read_attachment_text_rejects_unsupported_formats(tmp_path: Path) -> None:
    payload = _attachment_item_payload(
        attachment_id="att-1",
        name="brief.txt",
        content_type="text/plain",
        size=8,
        content=b"hello",
    )
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(payload),
        )
    )

    try:
        client.read_attachment_text("msg-1", "att-1")
    except ValueError as exc:
        assert "not supported" in str(exc)
    else:
        raise AssertionError("expected unsupported attachment format to raise ValueError")


def test_search_emails_builds_filter_query(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        captured["headers"] = dict(req.headers)
        return _response({"value": []})

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    client.search_emails("board", mailbox_filter="focused")

    assert "$search=%22board%22" in captured["url"]
    assert captured["headers"]["Consistencylevel"] == "eventual"


def test_search_emails_strips_surrounding_quotes_before_building_search(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    client.search_emails('"board review"')

    assert "$search=%22board+review%22" in captured["url"]


def test_search_emails_retries_with_plain_search_for_position_zero_parse_error(
    tmp_path: Path,
) -> None:
    calls: list[str] = []

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        if len(calls) == 1:
            raise HTTPError(
                url=req.full_url,
                code=400,
                msg="Bad Request",
                hdrs=None,
                fp=_response(
                    {
                        "error": {
                            "code": "BadRequest",
                            "message": "An identifier was expected at position 0.",
                        }
                    }
                ),
            )
        return _response({"value": [_message_item("msg-1")]})

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    messages = client.search_emails('"RE: EOS AWS EDP Renewal"')

    assert len(messages) == 1
    assert "$search=%22RE:+EOS+AWS+EDP+Renewal%22" in calls[0]
    assert "$search=RE:+EOS+AWS+EDP+Renewal" in calls[1]


def test_search_emails_fallback_escapes_odata_quotes(tmp_path: Path) -> None:
    calls: list[str] = []

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        if len(calls) == 1:
            raise HTTPError(
                url=req.full_url,
                code=400,
                msg="Bad Request",
                hdrs=None,
                fp=_response(
                    {
                        "error": {
                            "code": "Request_UnsupportedQuery",
                            "message": "The property does not support filtering.",
                        }
                    }
                ),
            )
        return _response({"value": []})

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    client.search_emails("o'brien")

    assert "contains(subject,'o''brien')" in calls[1]


def test_list_inbox_summary_only_uses_select_and_omits_body_content(tmp_path: Path) -> None:
    captured: dict[str, str] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": [_message_item("msg-1", include_body=False)]})

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    messages = client.list_inbox(top=5, skip=2, summary_only=True)

    query = parse_qs(urlsplit(captured["url"]).query)
    assert query["$top"] == ["5"]
    assert query["$skip"] == ["2"]
    assert query["$select"] == [
        (
            "id,subject,from,bodyPreview,receivedDateTime,isRead,importance,hasAttachments"
        )
    ]
    assert messages[0].body_content == ""


def test_search_emails_summary_only_uses_requested_top_and_select(tmp_path: Path) -> None:
    captured: dict[str, str] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": [_message_item("msg-1", include_body=False)]})

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    client.search_emails("board", top=7, summary_only=True)

    query = parse_qs(urlsplit(captured["url"]).query)
    assert query["$search"] == ['"board"']
    assert query["$top"] == ["7"]
    assert query["$select"] == [
        "id,subject,from,bodyPreview,receivedDateTime,isRead,importance,hasAttachments"
    ]


def test_read_conversation_thread_builds_conversation_filter_query(tmp_path: Path) -> None:
    captured: dict[str, str] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": [_message_item("msg-1")]})

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    messages = client.read_conversation_thread("conv-1", top=4)

    query = parse_qs(urlsplit(captured["url"]).query)
    assert query["$filter"] == ["conversationId eq 'conv-1'"]
    assert query["$orderby"] == ["receivedDateTime asc"]
    assert query["$top"] == ["4"]
    assert len(messages) == 1


def test_list_folders_returns_folder_summaries(tmp_path: Path) -> None:
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {"value": [{"id": "folder-1", "displayName": "Archive"}]}
            ),
        )
    )

    assert client.list_folders() == [{"id": "folder-1", "display_name": "Archive"}]


def test_delta_sync_returns_messages_removed_ids_and_links(tmp_path: Path) -> None:
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {
                    "value": [
                        _message_item("msg-1"),
                        {"id": "msg-2", "@removed": {"reason": "deleted"}},
                    ],
                    "@odata.deltaLink": "https://delta-link",
                }
            ),
        )
    )

    result = client.delta_sync(top=25)

    assert [message.id for message in result.messages] == ["msg-1"]
    assert result.removed_ids == ["msg-2"]
    assert result.delta_link == "https://delta-link"


def test_create_email_draft_posts_message_and_returns_hashed_draft(tmp_path: Path) -> None:
    calls: list[dict[str, Any]] = []

    def transport(req: Any, timeout: float) -> Any:
        calls.append(
            {
                "url": req.full_url,
                "body": req.data.decode("utf-8") if req.data else "",
                "method": req.get_method(),
            }
        )
        return _response(_draft_item("draft-1"))

    config = _config(tmp_path)
    client = EmailClient(
        GraphClient(config=config, token="token", transport=transport),
        safety_gate=_gate(tmp_path, config),
    )

    draft = client.create_email_draft(
        to=("to@example.com",),
        cc=("cc@example.com",),
        subject="Hello",
        body="<p>Hello</p>",
        importance="high",
    )

    assert draft.draft_id == "draft-1"
    assert draft.content_hash
    assert calls == [
        {
            "url": "https://graph.microsoft.com/v1.0/me/messages",
            "body": (
                '{"subject": "Hello", "importance": "high", "body": {"contentType": "html", '
                '"content": "<p>Hello</p>"}, "toRecipients": [{"emailAddress": {"address": '
                '"to@example.com"}}], "ccRecipients": [{"emailAddress": {"address": '
                '"cc@example.com"}}]}'
            ),
            "method": "POST",
        }
    ]


def test_create_reply_draft_uses_reply_to_recipients_before_mutation(tmp_path: Path) -> None:
    calls: list[dict[str, Any]] = []
    responses = iter(
        [
            _message_item("msg-1", reply_to=("reply@example.com",)),
            _draft_item("draft-1", to=("reply@example.com",)),
            {},
            _draft_item("draft-1", to=("reply@example.com",), body="<p>Reply</p>"),
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        calls.append(
            {
                "url": req.full_url,
                "body": req.data.decode("utf-8") if req.data else "",
                "method": req.get_method(),
            }
        )
        return _response(next(responses))

    config = _config(tmp_path)
    client = EmailClient(
        GraphClient(config=config, token="token", transport=transport),
        safety_gate=_gate(tmp_path, config),
    )

    draft = client.create_reply_draft("msg-1", body="<p>Reply</p>")

    assert draft.to == ("reply@example.com",)
    assert calls == [
        {
            "url": "https://graph.microsoft.com/v1.0/me/messages/msg-1",
            "body": "",
            "method": "GET",
        },
        {
            "url": "https://graph.microsoft.com/v1.0/me/messages/msg-1/createReply",
            "body": "",
            "method": "POST",
        },
        {
            "url": "https://graph.microsoft.com/v1.0/me/messages/draft-1",
            "body": '{"body": {"contentType": "html", "content": "<p>Reply</p>"}}',
            "method": "PATCH",
        },
        {
            "url": "https://graph.microsoft.com/v1.0/me/messages/draft-1",
            "body": "",
            "method": "GET",
        },
    ]


def test_create_reply_draft_strips_message_id_before_graph_calls(tmp_path: Path) -> None:
    calls: list[str] = []
    responses = iter(
        [
            _message_item("msg-1", reply_to=("reply@example.com",)),
            _draft_item("draft-1", to=("reply@example.com",)),
            {},
            _draft_item("draft-1", to=("reply@example.com",), body="<p>Reply</p>"),
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        return _response(next(responses))

    config = _config(tmp_path)
    client = EmailClient(
        GraphClient(config=config, token="token", transport=transport),
        safety_gate=_gate(tmp_path, config),
    )

    client.create_reply_draft(" msg-1 ", body="<p>Reply</p>")

    assert calls == [
        "https://graph.microsoft.com/v1.0/me/messages/msg-1",
        "https://graph.microsoft.com/v1.0/me/messages/msg-1/createReply",
        "https://graph.microsoft.com/v1.0/me/messages/draft-1",
        "https://graph.microsoft.com/v1.0/me/messages/draft-1",
    ]


def test_send_email_draft_posts_send_when_hash_matches(tmp_path: Path) -> None:
    calls: list[dict[str, Any]] = []
    draft_item = _draft_item("draft-1")

    def transport(req: Any, timeout: float) -> Any:
        calls.append({"url": req.full_url, "method": req.get_method()})
        if req.full_url.endswith("/send"):
            return _response({})
        return _response(draft_item)

    config = _config(tmp_path)
    client = EmailClient(
        GraphClient(config=config, token="token", transport=transport),
        safety_gate=_gate(tmp_path, config),
    )
    draft = client._draft_from_item(draft_item)

    client.send_email_draft("draft-1", content_hash=draft.content_hash)

    assert calls == [
        {"url": "https://graph.microsoft.com/v1.0/me/messages/draft-1", "method": "GET"},
        {"url": "https://graph.microsoft.com/v1.0/me/messages/draft-1/send", "method": "POST"},
    ]


def test_send_email_draft_denies_hash_mismatch(tmp_path: Path) -> None:
    config = _config(tmp_path)
    client = EmailClient(
        GraphClient(
            config=config,
            token="token",
            transport=lambda req, timeout: _response(_draft_item("draft-1")),
        ),
        safety_gate=_gate(tmp_path, config),
    )

    try:
        client.send_email_draft("draft-1", content_hash="stale-hash")
    except SafetyDeniedError as exc:
        assert exc.reason == "hash_mismatch"
    else:
        raise AssertionError("expected send_email_draft to deny mismatched hash")


def test_send_email_draft_strips_inputs_before_send(tmp_path: Path) -> None:
    calls: list[dict[str, str]] = []
    draft_item = _draft_item("draft-1")

    def transport(req: Any, timeout: float) -> Any:
        calls.append({"url": req.full_url, "method": req.get_method()})
        if req.full_url.endswith("/send"):
            return _response({})
        return _response(draft_item)

    config = _config(tmp_path)
    client = EmailClient(
        GraphClient(config=config, token="token", transport=transport),
        safety_gate=_gate(tmp_path, config),
    )
    draft = client._draft_from_item(draft_item)

    client.send_email_draft(" draft-1 ", content_hash=f" {draft.content_hash} ")

    assert calls == [
        {"url": "https://graph.microsoft.com/v1.0/me/messages/draft-1", "method": "GET"},
        {"url": "https://graph.microsoft.com/v1.0/me/messages/draft-1/send", "method": "POST"},
    ]


def test_send_email_draft_denies_when_dialog_cancelled(tmp_path: Path) -> None:
    config = _config(tmp_path)
    client = EmailClient(
        GraphClient(
            config=config,
            token="token",
            transport=lambda req, timeout: _response(_draft_item("draft-1")),
        ),
        safety_gate=_gate(
            tmp_path,
            config,
            dialog=lambda preview: SafetyResult(False, "dialog_cancelled"),
        ),
    )
    draft = client._draft_from_item(_draft_item("draft-1"))

    try:
        client.send_email_draft("draft-1", content_hash=draft.content_hash)
    except SafetyDeniedError as exc:
        assert exc.reason == "dialog_cancelled"
    else:
        raise AssertionError("expected send_email_draft to deny cancelled dialog")


def test_create_email_draft_rejects_shared_mailbox_mode(tmp_path: Path) -> None:
    config = _config(tmp_path, endpoint="users", user_principal_name="shared@example.com")
    client = EmailClient(
        GraphClient(
            config=config,
            token="token",
            transport=lambda req, timeout: _response(_draft_item("draft-1")),
        ),
        safety_gate=_gate(tmp_path, config),
    )

    try:
        client.create_email_draft(
            to=("to@example.com",),
            subject="Hello",
            body="<p>Hello</p>",
        )
    except SafetyDeniedError as exc:
        assert exc.reason == "unsupported_endpoint"
    else:
        raise AssertionError("expected create_email_draft to reject shared mailbox mode")


class _FakeResponse:
    def __init__(self, payload: dict[str, Any], status: int = 200) -> None:
        import json

        self._payload = json.dumps(payload).encode("utf-8")
        self.status = status

    def __enter__(self) -> _FakeResponse:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None

    def read(self) -> bytes:
        return self._payload

    def close(self) -> None:
        return None


class _FakeBytesResponse:
    def __init__(self, payload: bytes, status: int = 200) -> None:
        self._payload = payload
        self.status = status

    def __enter__(self) -> _FakeBytesResponse:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None

    def read(self) -> bytes:
        return self._payload

    def close(self) -> None:
        return None


def _response(payload: dict[str, Any], status: int = 200) -> _FakeResponse:
    return _FakeResponse(payload, status)


def _bytes_response(payload: bytes, status: int = 200) -> _FakeBytesResponse:
    return _FakeBytesResponse(payload, status)


def _message_item(
    message_id: str,
    *,
    reply_to: tuple[str, ...] = (),
    include_body: bool = True,
) -> dict[str, Any]:
    payload = {
        "id": message_id,
        "subject": "Hello",
        "from": {"emailAddress": {"address": "sender@example.com"}},
        "toRecipients": [{"emailAddress": {"address": "to@example.com"}}],
        "ccRecipients": [],
        "bccRecipients": [],
        "replyTo": [{"emailAddress": {"address": value}} for value in reply_to],
        "bodyPreview": "Hello world",
        "receivedDateTime": "2026-03-12T15:00:00Z",
        "isRead": False,
        "flag": {"flagStatus": "flagged"},
        "importance": "high",
        "hasAttachments": True,
        "conversationId": "conv-1",
        "parentFolderId": "folder-1",
    }
    if include_body:
        payload["body"] = {"content": "<p>Hello <strong>world</strong></p>"}
        payload["attachments"] = [
            {
                "name": "report.txt",
                "contentType": "text/plain",
                "size": 10,
                "contentBytes": "abc=",
                "@odata.type": "#microsoft.graph.fileAttachment",
            }
        ]
    return payload


def _draft_item(
    draft_id: str,
    *,
    to: tuple[str, ...] = ("to@example.com",),
    cc: tuple[str, ...] = (),
    bcc: tuple[str, ...] = (),
    reply_to: tuple[str, ...] = (),
    subject: str = "Hello",
    body: str = "<p>Hello</p>",
    importance: str = "high",
) -> dict[str, Any]:
    return {
        "id": draft_id,
        "toRecipients": [{"emailAddress": {"address": value}} for value in to],
        "ccRecipients": [{"emailAddress": {"address": value}} for value in cc],
        "bccRecipients": [{"emailAddress": {"address": value}} for value in bcc],
        "replyTo": [{"emailAddress": {"address": value}} for value in reply_to],
        "subject": subject,
        "body": {"contentType": "html", "content": body},
        "attachments": [],
        "importance": importance,
        "createdDateTime": "2026-03-12T15:00:00Z",
    }


def _attachment_item_payload(
    *,
    attachment_id: str,
    name: str,
    content_type: str,
    size: int,
    content: bytes | None = None,
    is_inline: bool = False,
) -> dict[str, Any]:
    payload = {
        "id": attachment_id,
        "name": name,
        "contentType": content_type,
        "size": size,
        "isInline": is_inline,
        "@odata.type": "#microsoft.graph.fileAttachment",
    }
    if content is not None:
        import base64

        payload["contentBytes"] = base64.b64encode(content).decode("ascii")
    return payload


def _docx_bytes() -> bytes:
    buffer = BytesIO()
    document = Document()
    document.add_paragraph("Quarterly review")
    table = document.add_table(rows=2, cols=2)
    table.rows[0].cells[0].text = "Owner"
    table.rows[0].cells[1].text = "Status"
    table.rows[1].cells[0].text = "Alyssa"
    table.rows[1].cells[1].text = "Ready"
    document.save(buffer)
    return buffer.getvalue()


def _xlsx_bytes() -> bytes:
    buffer = BytesIO()
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "Summary"
    worksheet.append(["Owner", "Status"])
    worksheet.append(["Alyssa", "Ready"])
    workbook.save(buffer)
    return buffer.getvalue()


def _pptx_bytes() -> bytes:
    buffer = BytesIO()
    presentation = Presentation()
    slide = presentation.slides.add_slide(presentation.slide_layouts[1])
    slide.shapes.title.text = "Renewal status"
    slide.placeholders[1].text = "Need legal sign-off"
    presentation.save(buffer)
    return buffer.getvalue()


def _pdf_bytes(text: str) -> bytes:
    stream = f"BT\n/F1 18 Tf\n72 100 Td\n({text}) Tj\nET".encode()
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        (
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 200] "
            b"/Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>"
        ),
        f"<< /Length {len(stream)} >>\nstream\n".encode() + stream + b"\nendstream",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    output = bytearray(b"%PDF-1.4\n")
    offsets = [0]
    for index, obj in enumerate(objects, start=1):
        offsets.append(len(output))
        output.extend(f"{index} 0 obj\n".encode())
        output.extend(obj)
        output.extend(b"\nendobj\n")
    startxref = len(output)
    output.extend(f"xref\n0 {len(objects) + 1}\n".encode())
    output.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        output.extend(f"{offset:010d} 00000 n \n".encode())
    output.extend(
        (
            f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
            f"startxref\n{startxref}\n%%EOF"
        ).encode()
    )
    return bytes(output)


def _config(
    tmp_path: Path,
    *,
    endpoint: str = "me",
    user_principal_name: str = "",
) -> Any:
    config_path = tmp_path / "default" / "config.toml"
    content = f"""
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "{endpoint}"
user_principal_name = "{user_principal_name}"
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = []
domains = []

[intelligence]
critical_keywords = []
noise_keywords = []
action_keywords = []
""".strip()
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)


def _gate(
    tmp_path: Path,
    config: Any,
    *,
    dialog: Any | None = None,
) -> ConfiguredSafetyGate:
    return ConfiguredSafetyGate(
        config=config,
        rate_limiter=RateLimiter(
            profile="default",
            rate_limits=config.safety.rate_limits,
            path=tmp_path / "rate_limits.sqlite3",
        ),
        audit_logger=AuditLogger(path=tmp_path / "audit.jsonl"),
        dialog=dialog or (lambda preview: SafetyResult(True, "dialog_skipped")),
    )
