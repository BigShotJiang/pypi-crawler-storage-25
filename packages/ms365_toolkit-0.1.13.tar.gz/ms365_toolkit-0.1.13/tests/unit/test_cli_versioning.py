from __future__ import annotations

from typing import Any

from ms365_toolkit import __version__
from ms365_toolkit.cli import main
from ms365_toolkit.version_status import PackageVersionStatus, ToolkitVersionStatus


def test_version_command_prints_installed_version_without_config(monkeypatch, capsys) -> None:
    _patch_usage_logger(monkeypatch)

    def fail_load_config(profile: str) -> object:
        raise AssertionError("version must not preload config")

    monkeypatch.setattr("ms365_toolkit.cli.load_config", fail_load_config)

    exit_code = main(["version"])

    assert exit_code == 0
    assert capsys.readouterr().out.strip() == __version__


def test_version_check_returns_stale_exit_code(monkeypatch, capsys) -> None:
    _patch_usage_logger(monkeypatch)
    monkeypatch.setattr(
        "ms365_toolkit.cli.versioning.get_toolkit_status",
        lambda profile: _status(is_stale=True),
    )

    exit_code = main(["version", "--check"])

    assert exit_code == 10
    assert "Status: stale" in capsys.readouterr().out


def test_doctor_reports_missing_config_and_update_commands(
    tmp_path,
    monkeypatch,
    capsys,
) -> None:
    _patch_usage_logger(monkeypatch)
    monkeypatch.setattr(
        "ms365_toolkit.cli.versioning.get_toolkit_status",
        lambda profile: _status(is_stale=True),
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.versioning.get_profile_dir",
        lambda profile: tmp_path / profile,
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.versioning.get_config_path",
        lambda profile: tmp_path / profile / "config.toml",
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.versioning.load_config",
        lambda profile: (_ for _ in ()).throw(FileNotFoundError()),
    )

    exit_code = main(["doctor"])

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "Config: missing" in output
    assert "Update commands:" in output
    assert "claude mcp add" in output


def _status(*, is_stale: bool | None) -> ToolkitVersionStatus:
    return ToolkitVersionStatus(
        version=__version__,
        is_stale=is_stale,
        source="live",
        checked_at="2026-04-18T00:00:00Z",
        cache_path="/tmp/latest_version.json",
        packages=(
            PackageVersionStatus(
                package="ms365-toolkit",
                current_version=__version__,
                latest_version="999.0.0" if is_stale else __version__,
                is_stale=is_stale,
            ),
            PackageVersionStatus(
                package="ms365-toolkit-mcp",
                current_version=__version__,
                latest_version="999.0.0" if is_stale else __version__,
                is_stale=is_stale,
            ),
        ),
        update_commands={"codex": "codex mcp add ...", "claude": "claude mcp add ..."}
        if is_stale
        else {},
    )


def _patch_usage_logger(monkeypatch) -> None:
    class FakeLogger:
        def log(self, event: Any) -> None:
            pass

    monkeypatch.setattr("ms365_toolkit.cli.UsageLogger.for_profile", lambda profile: FakeLogger())
