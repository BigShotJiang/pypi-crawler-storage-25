from __future__ import annotations

import stat
from pathlib import Path

from ms365_toolkit import __version__
from ms365_toolkit.version_status import (
    get_toolkit_status,
    read_cached_toolkit_status,
    stale_warning_from_cache,
    version_status_cache_path,
)


def test_get_toolkit_status_marks_stale_and_writes_private_cache(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.version_status.get_profile_dir",
        lambda profile: tmp_path / profile,
    )

    def fake_fetch(package: str, *, timeout: float) -> str:
        return "999.0.0"

    monkeypatch.setattr("ms365_toolkit.version_status.fetch_latest_package_version", fake_fetch)

    status = get_toolkit_status("default")

    assert status.version == __version__
    assert status.is_stale is True
    assert status.source == "live"
    assert status.update_commands["codex"].startswith("codex mcp add ms365")
    assert "ms365-toolkit-mcp@latest" in status.update_commands["codex"]
    assert "ms365-toolkit-mcp==" not in status.update_commands["codex"]
    assert "UV_CACHE_DIR=/tmp/ms365-toolkit-uv-cache" in status.update_commands["codex"]
    assert "ms365-toolkit-mcp@latest" in status.update_commands["claude"]
    assert "ms365-toolkit-mcp==" not in status.update_commands["claude"]
    assert "UV_TOOL_DIR=/tmp/ms365-toolkit-uv-tools" in status.update_commands["claude"]
    cache_path = Path(version_status_cache_path("default"))
    assert stat.S_IMODE(cache_path.stat().st_mode) == 0o600
    assert read_cached_toolkit_status("default") is not None
    assert stale_warning_from_cache("default") is not None


def test_get_toolkit_status_falls_back_to_cache_when_live_check_fails(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.version_status.get_profile_dir",
        lambda profile: tmp_path / profile,
    )

    def fake_fetch(package: str, *, timeout: float) -> str:
        return __version__

    monkeypatch.setattr("ms365_toolkit.version_status.fetch_latest_package_version", fake_fetch)
    get_toolkit_status("default")

    def failing_fetch(package: str, *, timeout: float) -> str:
        raise OSError("offline")

    monkeypatch.setattr("ms365_toolkit.version_status.fetch_latest_package_version", failing_fetch)

    status = get_toolkit_status("default")

    assert status.source == "cache"
    assert status.is_stale is False
    assert status.check_error is not None
    assert "offline" in status.check_error


def test_get_toolkit_status_can_skip_latest_check(monkeypatch) -> None:
    def failing_fetch(package: str, *, timeout: float) -> str:
        raise AssertionError("fetch should not be called")

    monkeypatch.setattr("ms365_toolkit.version_status.fetch_latest_package_version", failing_fetch)

    status = get_toolkit_status("default", include_latest=False)

    assert status.source == "installed"
    assert status.is_stale is None
    assert all(package.latest_version is None for package in status.packages)
