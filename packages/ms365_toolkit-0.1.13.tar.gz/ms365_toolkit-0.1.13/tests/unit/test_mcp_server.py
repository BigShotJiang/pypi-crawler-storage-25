from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

import pytest
from fastmcp.exceptions import ToolError

from ms365_toolkit.client.exceptions import AuthenticationError
from ms365_toolkit.mcp import create_server
from ms365_toolkit.mcp.__main__ import main
from ms365_toolkit.models.calendar import (
    Attendee,
    CalendarEvent,
    ExtractedMeetingTranscript,
    MeetingActionItem,
    MeetingAiInsight,
    MeetingMentionEvent,
    MeetingNotePoint,
    MeetingTranscript,
)
from ms365_toolkit.models.email import (
    EmailAttachment,
    EmailDraft,
    EmailMessage,
    ExtractedAttachment,
)
from ms365_toolkit.models.teams import (
    ChannelSummary,
    ExtractedTeamsFile,
    TeamsChat,
    TeamsMessage,
    TeamsMessageAttachment,
    TeamsMessageSearchHit,
    TeamsParticipant,
    TeamsReplyPage,
    TeamsSender,
    TeamsThread,
    TeamSummary,
)
from ms365_toolkit.version_status import PackageVersionStatus, ToolkitVersionStatus

_MAX_CHARS_TOO_SMALL_WARNING = "max_chars is too small to include one item; increase max_chars."


@pytest.mark.asyncio
async def test_create_server_registers_expected_tool_names() -> None:
    server = create_server(runtime=_FakeRuntime())

    tools = await server.list_tools()

    assert [tool.name for tool in tools] == [
        "get_toolkit_status",
        "list_inbox",
        "search_emails",
        "read_email",
        "read_conversation_thread",
        "list_email_attachments",
        "read_email_attachment",
        "create_email_draft",
        "create_reply_draft",
        "send_email_draft",
        "list_teams_message_files",
        "read_teams_message_file",
        "list_folders",
        "list_events",
        "get_event",
        "list_meeting_transcripts",
        "read_meeting_transcript",
        "read_meeting_notes",
        "search_events",
        "list_calendars",
        "find_free_slots",
        "list_chats",
        "search_chats",
        "list_chat_messages",
        "search_chat_messages",
        "search_teams_messages",
        "read_chat_message",
        "list_teams",
        "list_channels",
        "list_channel_messages",
        "search_channel_messages",
        "list_channel_replies",
        "read_channel_message",
        "read_channel_thread",
    ]


@pytest.mark.asyncio
async def test_get_toolkit_status_returns_structured_content(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    status = ToolkitVersionStatus(
        version="0.1.10",
        is_stale=False,
        source="installed",
        checked_at=None,
        cache_path="/tmp/latest_version.json",
        packages=(
            PackageVersionStatus(
                package="ms365-toolkit",
                current_version="0.1.10",
                latest_version=None,
                is_stale=None,
            ),
        ),
        update_commands={},
    )
    monkeypatch.setattr(
        "ms365_toolkit.mcp.tools.build_toolkit_status",
        lambda profile, include_latest=True: status,
    )

    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("get_toolkit_status", {"include_latest": False})

    assert result.structured_content == {
        "version": "0.1.10",
        "is_stale": False,
        "source": "installed",
        "checked_at": None,
        "cache_path": "/tmp/latest_version.json",
        "packages": [
            {
                "package": "ms365-toolkit",
                "current_version": "0.1.10",
                "latest_version": None,
                "is_stale": None,
            }
        ],
        "update_commands": {},
    }


@pytest.mark.asyncio
async def test_list_inbox_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("list_inbox", {"mailbox_filter": "all", "top": 5})

    assert result.structured_content == {
        "messages": [
            {
                "id": "msg-1",
                "subject": "Hello",
                "sender": "sender@example.com",
                "body_preview": "Preview",
                "received_at": "2026-04-03T12:00:00Z",
                "is_read": False,
                "importance": "high",
                "has_attachments": False,
            }
        ],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_search_emails_returns_truncated_message_summaries() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("search_emails", {"query": "hello", "top": 10})

    assert result.structured_content == {
        "messages": [
            {
                "id": "msg-1",
                "subject": "Hello",
                "sender": "sender@example.com",
                "body_preview": "Preview",
                "received_at": "2026-04-03T12:00:00Z",
                "is_read": False,
                "importance": "high",
                "has_attachments": False,
            }
        ],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_mcp_tool_logs_usage_event(monkeypatch: pytest.MonkeyPatch) -> None:
    events: list[Any] = []

    class FakeLogger:
        def log(self, event: Any) -> None:
            events.append(event)

    monkeypatch.setattr(
        "ms365_toolkit.mcp.tools.UsageLogger.for_profile",
        lambda profile: FakeLogger(),
    )

    @dataclass
    class RuntimeWithProfile(_FakeRuntime):
        profile: str = "default"

    server = create_server(runtime=RuntimeWithProfile())

    await server.call_tool("list_inbox", {"mailbox_filter": "all", "top": 5})

    assert len(events) == 1
    assert events[0].profile == "default"
    assert events[0].surface == "mcp"
    assert events[0].name == "list_inbox"
    assert events[0].success is True
    assert events[0].result_item_count == 1
    assert events[0].write_intent is False


@pytest.mark.asyncio
async def test_list_inbox_respects_max_chars_budget() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_inbox",
        {"mailbox_filter": "all", "top": 5, "max_chars": 120},
    )

    assert result.structured_content == {
        "messages": [],
        "truncated": True,
        "next_offset": None,
        "warnings": [_MAX_CHARS_TOO_SMALL_WARNING],
    }


@pytest.mark.asyncio
async def test_list_inbox_offset_overrides_skip() -> None:
    email_client = _FakeEmailClient()
    server = create_server(runtime=_FakeRuntime(email=email_client))

    await server.call_tool(
        "list_inbox",
        {"mailbox_filter": "all", "top": 5, "skip": 9, "offset": 2},
    )

    assert email_client.list_inbox_calls[-1]["skip"] == 2


@pytest.mark.asyncio
async def test_search_emails_fetches_offset_candidate_pool() -> None:
    email_client = _FakeEmailClient()
    server = create_server(runtime=_FakeRuntime(email=email_client))

    await server.call_tool("search_emails", {"query": "hello", "top": 5, "offset": 2})

    assert email_client.search_calls[-1]["top"] == 7


@pytest.mark.asyncio
async def test_list_chat_messages_returns_next_offset_when_budget_truncates() -> None:
    first = _teams_message()
    second = _teams_message(message_id="teams-msg-2", body_content="Second Teams message")
    first_payload = _teams_message_summary_payload()
    max_chars = (
        len(
            json.dumps(
                {"messages": [first_payload], "truncated": False},
                separators=(",", ":"),
                ensure_ascii=False,
            )
        )
        + 10
    )
    server = create_server(runtime=_FakeRuntime(teams=_FakeTeamsClient(messages=[first, second])))

    result = await server.call_tool(
        "list_chat_messages",
        {"chat_id": "chat-1", "top": 2, "max_chars": max_chars},
    )

    assert result.structured_content == {
        "messages": [first_payload],
        "truncated": True,
        "next_offset": 1,
    }


@pytest.mark.asyncio
async def test_list_chat_messages_offset_returns_next_item_without_duplication() -> None:
    teams_client = _FakeTeamsClient(
        messages=[
            _teams_message(),
            _teams_message(message_id="teams-msg-2", body_content="Second Teams message"),
        ]
    )
    server = create_server(runtime=_FakeRuntime(teams=teams_client))

    result = await server.call_tool(
        "list_chat_messages",
        {"chat_id": "chat-1", "top": 2, "offset": 1},
    )

    assert result.structured_content == {
        "messages": [
            _teams_message_summary_payload(
                message_id="teams-msg-2",
                body_preview="Second Teams message",
                summary="Second Teams message",
            )
        ],
        "truncated": False,
    }
    assert teams_client.list_chat_messages_calls[-1]["top"] == 3


@pytest.mark.asyncio
async def test_list_chat_messages_rejects_negative_offset() -> None:
    server = create_server(runtime=_FakeRuntime())

    with pytest.raises(ToolError, match="offset must be zero or greater"):
        await server.call_tool("list_chat_messages", {"chat_id": "chat-1", "offset": -1})


@pytest.mark.asyncio
async def test_read_conversation_thread_returns_full_messages() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "read_conversation_thread",
        {"conversation_id": "conversation-1", "top": 25},
    )

    assert result.structured_content == {
        "conversation_id": "conversation-1",
        "messages": [
            {
                "id": "msg-1",
                "subject": "Hello",
                "sender": "sender@example.com",
                "to": ["to@example.com"],
                "cc": [],
                "bcc": [],
                "body_preview": "Preview",
                "body_content": "<untrusted-email-content>Hello</untrusted-email-content>",
                "received_at": "2026-04-03T12:00:00Z",
                "is_read": False,
                "is_flagged": True,
                "importance": "high",
                "has_attachments": False,
                "attachments": [],
                "conversation_id": "conversation-1",
                "folder_id": "folder-1",
            }
        ],
    }


@pytest.mark.asyncio
async def test_list_email_attachments_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_email_attachments",
        {"message_id": "msg-1", "include_inline": False},
    )

    assert result.structured_content == {
        "attachments": [
            {
                "id": "att-1",
                "name": "brief.docx",
                "content_type": (
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                ),
                "size": 128,
                "is_inline": False,
                "is_reference": False,
                "odata_type": "#microsoft.graph.fileAttachment",
            }
        ]
    }


@pytest.mark.asyncio
async def test_read_email_attachment_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "read_email_attachment",
        {"message_id": "msg-1", "attachment_id": "att-1", "max_chars": 50000},
    )

    assert result.structured_content == {
        "attachment": {
            "id": "att-1",
            "name": "brief.docx",
            "content_type": (
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            ),
            "size": 128,
            "is_inline": False,
            "is_reference": False,
            "odata_type": "#microsoft.graph.fileAttachment",
        },
        "format": "docx",
        "text_content": "Quarterly review",
        "is_truncated": False,
        "warnings": [],
    }


@pytest.mark.asyncio
async def test_create_email_draft_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "create_email_draft",
        {
            "to": ["to@example.com"],
            "subject": "Hello",
            "body": "<p>Hello</p>",
            "importance": "high",
        },
    )

    assert result.structured_content == {
        "draft_id": "draft-1",
        "content_hash": "hash-1",
        "to": ["to@example.com"],
        "cc": [],
        "bcc": [],
        "subject": "Hello",
        "body": "<p>Hello</p>",
        "attachments": [],
        "reply_to": [],
        "importance": "high",
        "created_at": "2026-04-03T12:00:00Z",
    }


@pytest.mark.asyncio
async def test_create_reply_draft_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "create_reply_draft",
        {"message_id": " msg-1 ", "body": "<p>Reply</p>"},
    )

    assert result.structured_content == {
        "draft_id": "draft-1",
        "content_hash": "hash-1",
        "to": ["to@example.com"],
        "cc": [],
        "bcc": [],
        "subject": "Hello",
        "body": "<p>Hello</p>",
        "attachments": [],
        "reply_to": [],
        "importance": "high",
        "created_at": "2026-04-03T12:00:00Z",
    }


@pytest.mark.asyncio
async def test_send_email_draft_returns_confirmation() -> None:
    runtime = _FakeRuntime()
    server = create_server(runtime=runtime)

    result = await server.call_tool(
        "send_email_draft",
        {"draft_id": " draft-1 ", "content_hash": " hash-1 "},
    )

    assert result.structured_content == {"status": "sent", "draft_id": "draft-1"}
    assert runtime.sent_drafts == [("draft-1", "hash-1")]


@pytest.mark.asyncio
async def test_list_teams_message_files_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_teams_message_files",
        {"message_id": "msg-1", "chat_id": "chat-1"},
    )

    assert result.structured_content == {
        "attachments": [
            {
                "id": "teams-att-1",
                "name": "brief.docx",
                "content_type": "reference",
                "content_url": "https://contoso.sharepoint.com/:w:/r/brief.docx",
                "thumbnail_url": "",
                "teams_app_id": "",
            }
        ]
    }


@pytest.mark.asyncio
async def test_read_teams_message_file_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "read_teams_message_file",
        {
            "message_id": "msg-1",
            "attachment_id": "teams-att-1",
            "chat_id": "chat-1",
            "max_chars": 50000,
        },
    )

    assert result.structured_content == {
        "attachment": {
            "id": "teams-att-1",
            "name": "brief.docx",
            "content_type": "reference",
            "content_url": "https://contoso.sharepoint.com/:w:/r/brief.docx",
            "thumbnail_url": "",
            "teams_app_id": "",
        },
        "format": "docx",
        "text_content": "Quarterly review",
        "is_truncated": False,
        "warnings": [],
    }


@pytest.mark.asyncio
async def test_list_events_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_events",
        {"start": "2026-04-03T09:00:00Z", "end": "2026-04-03T10:00:00Z"},
    )

    assert result.structured_content == {
        "events": [
            {
                "id": "event-1",
                "subject": "Planning",
                "start": "2026-04-03T09:00:00Z",
                "end": "2026-04-03T09:30:00Z",
                "timezone": "UTC",
                "location": "Room A",
                "is_online_meeting": False,
                "is_cancelled": False,
                "importance": "normal",
                "categories": ["Work"],
                "organizer": "owner@example.com",
                "response_status": "accepted",
                "calendar_id": "calendar-1",
                "join_url": "https://teams.microsoft.com/l/meetup-join/meeting-1",
                "ical_uid": "ical-1",
                "attendee_count": 1,
            }
        ],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_list_events_respects_max_chars_budget() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_events",
        {
            "start": "2026-04-03T09:00:00Z",
            "end": "2026-04-03T10:00:00Z",
            "max_chars": 80,
        },
    )

    assert result.structured_content == {
        "events": [],
        "truncated": True,
        "next_offset": None,
        "warnings": [_MAX_CHARS_TOO_SMALL_WARNING],
    }


@pytest.mark.asyncio
async def test_list_meeting_transcripts_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_meeting_transcripts",
        {"event_id": "event-1", "top": 10},
    )

    assert result.structured_content == {
        "transcripts": [
            {
                "id": "transcript-1",
                "meeting_id": "meeting-1",
                "call_id": "call-1",
                "created_at": "2026-04-03T12:00:00Z",
                "end_at": "2026-04-03T12:30:00Z",
                "content_correlation_id": "corr-1",
                "transcript_content_url": "https://graph.microsoft.com/v1.0/transcripts/1/content",
                "organizer_user_id": "user-1",
                "organizer_display_name": "Owner",
                "organizer_tenant_id": "tenant-1",
            }
        ]
    }


@pytest.mark.asyncio
async def test_read_meeting_transcript_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "read_meeting_transcript",
        {"event_id": "event-1", "max_chars": 50000},
    )

    assert result.structured_content == {
        "transcript": {
            "id": "transcript-1",
            "meeting_id": "meeting-1",
            "call_id": "call-1",
            "created_at": "2026-04-03T12:00:00Z",
            "end_at": "2026-04-03T12:30:00Z",
            "content_correlation_id": "corr-1",
            "transcript_content_url": "https://graph.microsoft.com/v1.0/transcripts/1/content",
            "organizer_user_id": "user-1",
            "organizer_display_name": "Owner",
            "organizer_tenant_id": "tenant-1",
        },
        "format": "vtt",
        "text_content": "Speaker One: Hello team",
        "is_truncated": False,
        "warnings": [],
    }


@pytest.mark.asyncio
async def test_read_meeting_notes_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("read_meeting_notes", {"event_id": "event-1"})

    assert result.structured_content == {
        "id": "insight-1",
        "call_id": "call-1",
        "content_correlation_id": "corr-1",
        "created_at": "2026-04-03T12:31:00Z",
        "end_at": "2026-04-03T12:30:00Z",
        "meeting_notes": [
            {
                "title": "Launch planning",
                "text": "Reviewed the launch checklist.",
                "subpoints": [
                    {
                        "title": "Dependencies",
                        "text": "Finalize legal review.",
                        "subpoints": [],
                    }
                ],
            }
        ],
        "action_items": [
            {
                "title": "Finalize timeline",
                "text": "Lock the ship date.",
                "owner_display_name": "Bella Smith",
            }
        ],
        "mention_events": [
            {
                "event_at": "2026-04-03T12:15:00Z",
                "speaker_name": "John Smith",
                "speaker_user_id": "user-2",
                "transcript_utterance": "John Smith owns the launch deck.",
            }
        ],
    }


@pytest.mark.asyncio
async def test_find_free_slots_returns_open_windows_after_ignores() -> None:
    runtime = _FakeRuntime(
        graph_response={
            "value": [
                {
                    "scheduleItems": [
                        {
                            "status": "busy",
                            "subject": "Lunch",
                            "start": {"dateTime": "2026-04-03T12:00:00Z"},
                            "end": {"dateTime": "2026-04-03T12:30:00Z"},
                        },
                        {
                            "status": "busy",
                            "subject": "Planning",
                            "start": {"dateTime": "2026-04-03T13:00:00Z"},
                            "end": {"dateTime": "2026-04-03T14:00:00Z"},
                        },
                    ]
                },
                {
                    "scheduleItems": [
                        {
                            "status": "tentative",
                            "subject": "Workout",
                            "start": {"dateTime": "2026-04-03T12:30:00Z"},
                            "end": {"dateTime": "2026-04-03T13:00:00Z"},
                        },
                        {
                            "status": "oof",
                            "subject": "OOO",
                            "start": {"dateTime": "2026-04-03T14:30:00Z"},
                            "end": {"dateTime": "2026-04-03T15:00:00Z"},
                        },
                    ]
                },
            ]
        }
    )
    server = create_server(runtime=runtime)

    result = await server.call_tool(
        "find_free_slots",
        {
            "attendees": ["a@example.com", "b@example.com"],
            "start": "2026-04-03T12:00:00Z",
            "end": "2026-04-03T16:00:00Z",
            "duration_minutes": 30,
            "ignore_subject_terms": ["lunch", "workout"],
        },
    )

    assert result.structured_content == {
        "windows": [
            {
                "start": "2026-04-03T12:00:00Z",
                "end": "2026-04-03T13:00:00Z",
                "duration_minutes": 60,
            },
            {
                "start": "2026-04-03T14:00:00Z",
                "end": "2026-04-03T14:30:00Z",
                "duration_minutes": 30,
            },
            {
                "start": "2026-04-03T15:00:00Z",
                "end": "2026-04-03T16:00:00Z",
                "duration_minutes": 60,
            },
        ]
    }
    assert runtime.graph_calls[0]["body"]["availabilityViewInterval"] == 30


@pytest.mark.asyncio
async def test_list_chats_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("list_chats", {"top": 5})

    assert result.structured_content == {
        "chats": [
            {
                "id": "chat-1",
                "topic": "Madeline",
                "display_label": "Madeline",
                "chat_type": "oneOnOne",
                "created_at": "2026-04-03T12:00:00Z",
                "last_updated_at": "2026-04-03T12:05:00Z",
                "web_url": "",
                "is_hidden": False,
                "other_participant_count": 1,
            }
        ],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_search_chats_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("search_chats", {"query": "madeline", "top": 5})

    assert result.structured_content == {
        "chats": [
            {
                "id": "chat-1",
                "topic": "Madeline",
                "display_label": "Madeline",
                "chat_type": "oneOnOne",
                "created_at": "2026-04-03T12:00:00Z",
                "last_updated_at": "2026-04-03T12:05:00Z",
                "web_url": "",
                "is_hidden": False,
                "other_participant_count": 1,
            }
        ],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_list_chat_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("list_chat_messages", {"chat_id": "chat-1", "top": 5})

    assert result.structured_content == {
        "messages": [_teams_message_summary_payload()],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_search_chat_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "search_chat_messages",
        {"chat_id": "chat-1", "query": "reply", "top": 5},
    )

    assert result.structured_content == {
        "messages": [_reply_summary_payload()],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_list_channel_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_channel_messages",
        {"team_id": "team-1", "channel_id": "channel-1", "top": 5},
    )

    assert result.structured_content == {
        "messages": [_teams_message_summary_payload()],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_list_channel_messages_respects_max_chars_budget() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_channel_messages",
        {"team_id": "team-1", "channel_id": "channel-1", "top": 5, "max_chars": 80},
    )

    assert result.structured_content == {
        "messages": [],
        "truncated": True,
        "next_offset": None,
        "warnings": [_MAX_CHARS_TOO_SMALL_WARNING],
    }


@pytest.mark.asyncio
async def test_search_teams_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "search_teams_messages",
        {"query": "cost center", "top": 5},
    )

    assert result.structured_content == {
        "messages": [
            {
                "id": "search-hit-1",
                "summary": "...cost center...",
                "created_at": "2026-04-03T12:09:00Z",
                "subject": "",
                "importance": "normal",
                "web_url": "https://teams.microsoft.com/l/message/1",
                "chat_id": "",
                "team_id": "team-1",
                "channel_id": "channel-1",
                "sender_name": "Kamal, Sara",
                "sender_email": "sara@example.com",
                "location_kind": "channel",
            }
        ],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_search_channel_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "search_channel_messages",
        {"team_id": "team-1", "channel_id": "channel-1", "query": "hello", "top": 5},
    )

    assert result.structured_content == {
        "messages": [_teams_message_summary_payload()],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_list_channel_replies_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_channel_replies",
        {"team_id": "team-1", "channel_id": "channel-1", "message_id": "root-1", "top": 5},
    )

    assert result.structured_content == {
        "replies": [_reply_summary_payload()],
        "truncated": False,
        "has_more_replies": True,
    }


@pytest.mark.asyncio
async def test_read_channel_thread_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "read_channel_thread",
        {"team_id": "team-1", "channel_id": "channel-1", "message_id": "root-1", "top": 5},
    )

    assert result.structured_content == {
        "root_message": {
            "id": "teams-msg-1",
            "body_content": "Hello from Teams",
            "content_type": "text",
            "created_at": "2026-04-03T12:07:00Z",
            "last_modified_at": "2026-04-03T12:07:00Z",
            "last_edited_at": "2026-04-03T12:08:00Z",
            "deleted_at": None,
            "subject": "",
            "summary": "Hello from Teams",
            "importance": "normal",
            "message_type": "message",
            "reply_to_id": "",
            "reply_count": 2,
            "web_url": "",
            "chat_id": "chat-1",
            "team_id": "team-1",
            "channel_id": "channel-1",
            "sender": {
                "display_name": "Sender",
                "email": "sender@example.com",
                "user_id": "user-1",
                "kind": "user",
            },
            "attachments": [
                {
                    "id": "teams-att-1",
                    "name": "brief.docx",
                    "content_type": "reference",
                    "content_url": "https://contoso.sharepoint.com/:w:/r/brief.docx",
                    "thumbnail_url": "",
                    "teams_app_id": "",
                }
            ],
        },
        "replies": [
            {
                "id": "reply-1",
                "body_content": "Reply body",
                "content_type": "text",
                "created_at": "2026-04-03T12:06:00Z",
                "last_modified_at": "2026-04-03T12:06:00Z",
                "last_edited_at": None,
                "deleted_at": None,
                "subject": "",
                "summary": "Reply body",
                "importance": "normal",
                "message_type": "message",
                "reply_to_id": "root-1",
                "reply_count": 0,
                "web_url": "",
                "chat_id": "",
                "team_id": "team-1",
                "channel_id": "channel-1",
                "sender": {
                    "display_name": "Responder",
                    "email": "responder@example.com",
                    "user_id": "user-2",
                    "kind": "user",
                },
                "attachments": [],
            }
        ],
        "has_more_replies": True,
    }


@pytest.mark.asyncio
async def test_tool_maps_authentication_failures_to_runtime_error() -> None:
    server = create_server(runtime=_FailingRuntime())

    with pytest.raises(ToolError, match="Authentication failed"):
        await server.call_tool("list_folders", {})


def test_mcp_main_supports_help() -> None:
    with pytest.raises(SystemExit) as exc_info:
        main(["--help"])
    assert exc_info.value.code == 0


def test_mcp_server_can_warn_from_cached_stale_status(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("MS365_TOOLKIT_WARN_STALE", "1")
    monkeypatch.setattr(
        "ms365_toolkit.mcp.server.stale_warning_from_cache",
        lambda profile: f"stale warning for {profile}",
    )

    @dataclass
    class RuntimeWithProfile(_FakeRuntime):
        profile: str = "default"

    create_server(runtime=RuntimeWithProfile())

    assert "stale warning for default" in capsys.readouterr().err


@dataclass
class _FakeRuntime:
    graph_response: dict[str, Any] | None = None
    graph_calls: list[dict[str, Any]] = field(default_factory=list)
    sent_drafts: list[tuple[str, str]] = field(default_factory=list)
    email: _FakeEmailClient | None = None
    calendar: _FakeCalendarClient | None = None
    teams: _FakeTeamsClient | None = None

    def email_client(self, *, write: bool = False) -> _FakeEmailClient:
        if self.email is None:
            self.email = _FakeEmailClient(self.sent_drafts)
        return self.email

    def calendar_client(
        self,
        *,
        include_meeting_transcripts: bool = False,
        include_meeting_notes: bool = False,
    ) -> _FakeCalendarClient:
        if self.calendar is None:
            self.calendar = _FakeCalendarClient()
        return self.calendar

    def teams_client(
        self,
        *,
        include_channel_messages: bool = False,
        include_files: bool = False,
    ) -> _FakeTeamsClient:
        if self.teams is None:
            self.teams = _FakeTeamsClient()
        return self.teams

    def graph_client(self) -> _FakeGraphClient:
        return _FakeGraphClient(self.graph_response or {"value": []}, self.graph_calls)


class _FailingRuntime(_FakeRuntime):
    def email_client(self, *, write: bool = False) -> _FakeEmailClient:
        raise AuthenticationError("missing token")


class _FakeGraphClient:
    def __init__(self, response: dict[str, Any], calls: list[dict[str, Any]]) -> None:
        self._response = response
        self._calls = calls

    def post(self, path: str, *, body: dict[str, Any]) -> dict[str, Any]:
        self._calls.append({"path": path, "body": body})
        return self._response


class _FakeEmailClient:
    def __init__(self, sent_drafts: list[tuple[str, str]] | None = None) -> None:
        self._sent_drafts = sent_drafts if sent_drafts is not None else []
        self.list_inbox_calls: list[dict[str, Any]] = []
        self.search_calls: list[dict[str, Any]] = []

    def list_inbox(
        self,
        *,
        mailbox_filter: str | None,
        top: int,
        skip: int,
        summary_only: bool = False,
    ) -> list[EmailMessage]:
        self.list_inbox_calls.append(
            {
                "mailbox_filter": mailbox_filter,
                "top": top,
                "skip": skip,
                "summary_only": summary_only,
            }
        )
        return [_message()]

    def search_emails(
        self,
        query: str,
        mailbox_filter: str | None = None,
        *,
        top: int = 25,
        summary_only: bool = False,
    ) -> list[EmailMessage]:
        self.search_calls.append(
            {
                "query": query,
                "mailbox_filter": mailbox_filter,
                "top": top,
                "summary_only": summary_only,
            }
        )
        return [_message()]

    def read_email(self, message_id: str) -> EmailMessage:
        return _message()

    def read_conversation_thread(
        self,
        conversation_id: str,
        *,
        top: int = 100,
    ) -> list[EmailMessage]:
        return [_message()]

    def list_attachments(
        self,
        message_id: str,
        *,
        include_inline: bool = False,
    ) -> list[EmailAttachment]:
        return [_attachment()]

    def read_attachment_text(
        self,
        message_id: str,
        attachment_id: str,
        *,
        max_chars: int = 50_000,
    ) -> ExtractedAttachment:
        return ExtractedAttachment(
            attachment=_attachment(),
            format="docx",
            text_content="Quarterly review",
            is_truncated=False,
            warnings=(),
        )

    def list_folders(self) -> list[dict[str, str]]:
        return [{"id": "folder-1", "display_name": "Archive"}]

    def create_email_draft(
        self,
        *,
        to: tuple[str, ...],
        cc: tuple[str, ...] = (),
        bcc: tuple[str, ...] = (),
        subject: str,
        body: str,
        reply_to: tuple[str, ...] = (),
        importance: str = "normal",
    ) -> EmailDraft:
        return _draft(importance=importance)

    def create_reply_draft(
        self,
        message_id: str,
        *,
        body: str,
        importance: str | None = None,
    ) -> EmailDraft:
        return _draft(importance=importance or "high")

    def send_email_draft(self, draft_id: str, *, content_hash: str) -> None:
        self._sent_drafts.append((draft_id, content_hash))


class _FakeCalendarClient:
    def list_events(
        self,
        *,
        start: datetime,
        end: datetime,
        calendar_id: str | None = None,
        calendar_filter: str | None = None,
    ) -> list[CalendarEvent]:
        return [_event()]

    def get_event(self, event_id: str) -> CalendarEvent:
        return _event()

    def list_meeting_transcripts(
        self,
        *,
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        top: int = 25,
    ) -> list[MeetingTranscript]:
        return [_meeting_transcript()]

    def read_meeting_transcript(
        self,
        *,
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        transcript_id: str | None = None,
        max_chars: int = 50_000,
    ) -> ExtractedMeetingTranscript:
        return ExtractedMeetingTranscript(
            transcript=_meeting_transcript(),
            format="vtt",
            text_content="Speaker One: Hello team",
            is_truncated=False,
            warnings=(),
        )

    def read_meeting_ai_insight(
        self,
        *,
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        ai_insight_id: str | None = None,
    ) -> MeetingAiInsight:
        return _meeting_ai_insight()

    def search_events(
        self,
        *,
        query: str,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[CalendarEvent]:
        return [_event()]

    def list_calendars(self) -> list[dict[str, str]]:
        return [{"id": "calendar-1", "name": "Primary"}]


class _FakeTeamsClient:
    def __init__(
        self,
        *,
        chats: list[TeamsChat] | None = None,
        messages: list[TeamsMessage] | None = None,
        chat_search_messages: list[TeamsMessage] | None = None,
        channel_messages: list[TeamsMessage] | None = None,
        channel_search_messages: list[TeamsMessage] | None = None,
        replies: tuple[TeamsMessage, ...] | None = None,
        search_hits: list[TeamsMessageSearchHit] | None = None,
    ) -> None:
        self.chats = chats if chats is not None else [_chat()]
        self.messages = messages if messages is not None else [_teams_message()]
        self.chat_search_messages = (
            chat_search_messages if chat_search_messages is not None else [_reply()]
        )
        self.channel_messages = (
            channel_messages if channel_messages is not None else [_teams_message()]
        )
        self.channel_search_messages = (
            channel_search_messages if channel_search_messages is not None else [_teams_message()]
        )
        self.replies = replies if replies is not None else (_reply(),)
        self.search_hits = search_hits if search_hits is not None else [_search_hit()]
        self.list_chat_messages_calls: list[dict[str, Any]] = []
        self.search_teams_messages_calls: list[dict[str, Any]] = []

    def list_chats(self, *, top: int = 25) -> list[TeamsChat]:
        return self.chats

    def search_chats(self, query: str, *, top: int = 10) -> list[TeamsChat]:
        return self.chats

    def list_chat_messages(self, chat_id: str, *, top: int = 25) -> list[TeamsMessage]:
        self.list_chat_messages_calls.append({"chat_id": chat_id, "top": top})
        return self.messages

    def search_chat_messages(
        self,
        chat_id: str,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessage]:
        return self.chat_search_messages

    def search_teams_messages(
        self,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessageSearchHit]:
        self.search_teams_messages_calls.append({"query": query, "top": top})
        return self.search_hits

    def get_chat_message(self, chat_id: str, message_id: str) -> TeamsMessage:
        return _teams_message()

    def list_message_attachments(
        self,
        *,
        message_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
    ) -> list[TeamsMessageAttachment]:
        return [_teams_attachment()]

    def read_message_attachment_text(
        self,
        *,
        message_id: str,
        attachment_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
        max_chars: int = 50_000,
    ) -> ExtractedTeamsFile:
        return ExtractedTeamsFile(
            attachment=_teams_attachment(),
            format="docx",
            text_content="Quarterly review",
            is_truncated=False,
            warnings=(),
        )

    def list_teams(self) -> list[TeamSummary]:
        return [
            TeamSummary(
                id="team-1",
                display_name="Ops",
                description="",
                is_archived=False,
                tenant_id="tenant-1",
            )
        ]

    def list_channels(self, team_id: str) -> list[ChannelSummary]:
        return [
            ChannelSummary(
                id="channel-1",
                display_name="General",
                description="",
                membership_type="standard",
                web_url="",
            )
        ]

    def list_channel_messages(
        self,
        team_id: str,
        channel_id: str,
        *,
        top: int = 25,
    ) -> list[TeamsMessage]:
        return self.channel_messages

    def search_channel_messages(
        self,
        team_id: str,
        channel_id: str,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessage]:
        return self.channel_search_messages

    def list_channel_replies(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        *,
        top: int = 25,
    ) -> TeamsReplyPage:
        return TeamsReplyPage(replies=self.replies, has_more_replies=True)

    def get_channel_message(self, team_id: str, channel_id: str, message_id: str) -> TeamsMessage:
        return _teams_message()

    def read_channel_thread(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        *,
        replies_top: int = 25,
    ) -> TeamsThread:
        return TeamsThread(
            root_message=_teams_message(),
            replies=(_reply(),),
            has_more_replies=True,
        )


def _message(
    *,
    message_id: str = "msg-1",
    subject: str = "Hello",
    body_preview: str = "Preview",
    body_content: str = "<untrusted-email-content>Hello</untrusted-email-content>",
) -> EmailMessage:
    return EmailMessage(
        id=message_id,
        subject=subject,
        sender="sender@example.com",
        to=("to@example.com",),
        cc=(),
        bcc=(),
        body_preview=body_preview,
        body_content=body_content,
        received_at=datetime(2026, 4, 3, 12, 0, tzinfo=UTC),
        is_read=False,
        is_flagged=True,
        importance="high",
        has_attachments=False,
        attachments=(),
        conversation_id="conversation-1",
        folder_id="folder-1",
    )


def _attachment() -> EmailAttachment:
    return EmailAttachment(
        id="att-1",
        name="brief.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        size=128,
        is_inline=False,
        is_reference=False,
        odata_type="#microsoft.graph.fileAttachment",
    )


def _draft(*, importance: str = "high") -> EmailDraft:
    return EmailDraft(
        draft_id="draft-1",
        content_hash="hash-1",
        to=("to@example.com",),
        cc=(),
        bcc=(),
        subject="Hello",
        body="<p>Hello</p>",
        attachments=(),
        reply_to=(),
        importance=importance,
        created_at=datetime(2026, 4, 3, 12, 0, tzinfo=UTC),
    )


def _event() -> CalendarEvent:
    return CalendarEvent(
        id="event-1",
        subject="Planning",
        start=datetime(2026, 4, 3, 9, 0, tzinfo=UTC),
        end=datetime(2026, 4, 3, 9, 30, tzinfo=UTC),
        timezone="UTC",
        location="Room A",
        body_content="Agenda",
        attendees=(
            Attendee(
                email="person@example.com",
                name="Person",
                response="accepted",
                type="required",
            ),
        ),
        is_online_meeting=False,
        is_cancelled=False,
        importance="normal",
        categories=("Work",),
        recurrence=None,
        organizer="owner@example.com",
        response_status="accepted",
        calendar_id="calendar-1",
        join_url="https://teams.microsoft.com/l/meetup-join/meeting-1",
        ical_uid="ical-1",
    )


def _chat() -> TeamsChat:
    return TeamsChat(
        id="chat-1",
        topic="Madeline",
        display_label="Madeline",
        chat_type="oneOnOne",
        created_at=datetime(2026, 4, 3, 12, 0, tzinfo=UTC),
        last_updated_at=datetime(2026, 4, 3, 12, 5, tzinfo=UTC),
        last_message_read_at=datetime(2026, 4, 3, 12, 6, tzinfo=UTC),
        web_url="",
        is_hidden=False,
        is_hidden_for_all_members=False,
        other_participants=(
            TeamsParticipant(
                display_name="Madeline",
                email="madeline@example.com",
                user_id="user-2",
            ),
        ),
    )


def _teams_message(
    *,
    message_id: str = "teams-msg-1",
    body_content: str = "Hello from Teams",
) -> TeamsMessage:
    return TeamsMessage(
        id=message_id,
        body_content=body_content,
        content_type="text",
        created_at=datetime(2026, 4, 3, 12, 7, tzinfo=UTC),
        last_modified_at=datetime(2026, 4, 3, 12, 7, tzinfo=UTC),
        last_edited_at=datetime(2026, 4, 3, 12, 8, tzinfo=UTC),
        deleted_at=None,
        subject="",
        summary=body_content,
        importance="normal",
        message_type="message",
        reply_to_id="",
        reply_count=2,
        web_url="",
        chat_id="chat-1",
        team_id="team-1",
        channel_id="channel-1",
        sender=TeamsSender(
            display_name="Sender",
            email="sender@example.com",
            user_id="user-1",
            kind="user",
        ),
        attachments=(_teams_attachment(),),
    )


def _teams_message_summary_payload(
    *,
    message_id: str = "teams-msg-1",
    body_preview: str = "Hello from Teams",
    summary: str = "Hello from Teams",
) -> dict[str, Any]:
    return {
        "id": message_id,
        "body_preview": body_preview,
        "content_type": "text",
        "created_at": "2026-04-03T12:07:00Z",
        "subject": "",
        "summary": summary,
        "importance": "normal",
        "message_type": "message",
        "reply_to_id": "",
        "reply_count": 2,
        "web_url": "",
        "chat_id": "chat-1",
        "team_id": "team-1",
        "channel_id": "channel-1",
        "sender": {
            "display_name": "Sender",
            "email": "sender@example.com",
            "user_id": "user-1",
            "kind": "user",
        },
        "attachment_count": 1,
    }


def _reply() -> TeamsMessage:
    return TeamsMessage(
        id="reply-1",
        body_content="Reply body",
        content_type="text",
        created_at=datetime(2026, 4, 3, 12, 6, tzinfo=UTC),
        last_modified_at=datetime(2026, 4, 3, 12, 6, tzinfo=UTC),
        last_edited_at=None,
        deleted_at=None,
        subject="",
        summary="Reply body",
        importance="normal",
        message_type="message",
        reply_to_id="root-1",
        reply_count=0,
        web_url="",
        chat_id="",
        team_id="team-1",
        channel_id="channel-1",
        sender=TeamsSender(
            display_name="Responder",
            email="responder@example.com",
            user_id="user-2",
            kind="user",
        ),
    )


def _search_hit() -> TeamsMessageSearchHit:
    return TeamsMessageSearchHit(
        id="search-hit-1",
        summary="...cost center...",
        created_at=datetime(2026, 4, 3, 12, 9, tzinfo=UTC),
        last_modified_at=datetime(2026, 4, 3, 12, 10, tzinfo=UTC),
        subject="",
        importance="normal",
        web_url="https://teams.microsoft.com/l/message/1",
        chat_id="",
        team_id="team-1",
        channel_id="channel-1",
        sender_name="Kamal, Sara",
        sender_email="sara@example.com",
        location_kind="channel",
    )


def _reply_summary_payload() -> dict[str, Any]:
    return {
        "id": "reply-1",
        "body_preview": "Reply body",
        "content_type": "text",
        "created_at": "2026-04-03T12:06:00Z",
        "subject": "",
        "summary": "Reply body",
        "importance": "normal",
        "message_type": "message",
        "reply_to_id": "root-1",
        "reply_count": 0,
        "web_url": "",
        "chat_id": "",
        "team_id": "team-1",
        "channel_id": "channel-1",
        "sender": {
            "display_name": "Responder",
            "email": "responder@example.com",
            "user_id": "user-2",
            "kind": "user",
        },
        "attachment_count": 0,
    }


def _teams_attachment() -> TeamsMessageAttachment:
    return TeamsMessageAttachment(
        id="teams-att-1",
        name="brief.docx",
        content_type="reference",
        content_url="https://contoso.sharepoint.com/:w:/r/brief.docx",
        thumbnail_url="",
        teams_app_id="",
    )


def _meeting_transcript() -> MeetingTranscript:
    return MeetingTranscript(
        id="transcript-1",
        meeting_id="meeting-1",
        call_id="call-1",
        created_at=datetime(2026, 4, 3, 12, 0, tzinfo=UTC),
        end_at=datetime(2026, 4, 3, 12, 30, tzinfo=UTC),
        content_correlation_id="corr-1",
        transcript_content_url="https://graph.microsoft.com/v1.0/transcripts/1/content",
        organizer_user_id="user-1",
        organizer_display_name="Owner",
        organizer_tenant_id="tenant-1",
    )


def _meeting_ai_insight() -> MeetingAiInsight:
    return MeetingAiInsight(
        id="insight-1",
        call_id="call-1",
        content_correlation_id="corr-1",
        created_at=datetime(2026, 4, 3, 12, 31, tzinfo=UTC),
        end_at=datetime(2026, 4, 3, 12, 30, tzinfo=UTC),
        meeting_notes=(
            MeetingNotePoint(
                title="Launch planning",
                text="Reviewed the launch checklist.",
                subpoints=(MeetingNotePoint(title="Dependencies", text="Finalize legal review."),),
            ),
        ),
        action_items=(
            MeetingActionItem(
                title="Finalize timeline",
                text="Lock the ship date.",
                owner_display_name="Bella Smith",
            ),
        ),
        mention_events=(
            MeetingMentionEvent(
                event_at=datetime(2026, 4, 3, 12, 15, tzinfo=UTC),
                speaker_name="John Smith",
                speaker_user_id="user-2",
                transcript_utterance="John Smith owns the launch deck.",
            ),
        ),
    )
