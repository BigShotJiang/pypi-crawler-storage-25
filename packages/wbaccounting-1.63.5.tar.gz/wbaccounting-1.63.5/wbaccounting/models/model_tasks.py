from contextlib import suppress
from datetime import date

from celery import shared_task
from django.utils.module_loading import import_string
from wbcore.contrib.directory.models import Entry
from wbcore.workers import Queue

from wbaccounting.generators.base import generate_booking_entries


@shared_task(queue=Queue.DEFAULT.value)
def submit_invoices_as_task(ids: list[int]):
    from wbaccounting.models import Invoice

    invoices = Invoice.objects.filter(id__in=ids)
    for invoice in invoices:
        invoice.submit()
        invoice.save()


@shared_task(queue=Queue.DEFAULT.value)
def approve_invoices_as_task(ids: list[int]):
    from wbaccounting.models import Invoice

    invoices = Invoice.objects.filter(id__in=ids)
    for invoice in invoices:
        invoice.approve()
        invoice.save()


@shared_task(queue=Queue.DEFAULT.value)
def pay_invoices_as_task(ids: list[int]):
    from wbaccounting.models import Invoice

    invoices = Invoice.objects.filter(id__in=ids)
    for invoice in invoices:
        invoice.pay()
        invoice.save()


@shared_task(queue=Queue.DEFAULT.value)
def refresh_invoice_document_as_task(invoice_id):
    from wbaccounting.models import Invoice

    invoice = Invoice.objects.get(id=invoice_id)
    invoice.refresh_invoice_document()


@shared_task(queue=Queue.DEFAULT.value)
def generate_booking_entries_as_task(
    func: str, from_date: date, to_date: date, counterparty_id: int, booking_date: date
):
    with suppress(ImportError):
        generator = import_string(func)
        counterparty = Entry.all_objects.get(id=counterparty_id)
        generate_booking_entries(generator, from_date, to_date, counterparty, booking_date)
