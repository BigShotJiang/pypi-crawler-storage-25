from decimal import Decimal

import factory
from wbaccounting.factories import (
    BookingEntryFactory,
    EntryAccountingInformationFactory,
    InvoiceFactory,
    InvoiceTypeFactory,
    LocalCurrencyTransactionFactory,
    TransactionFactory,
)
from wbaccounting.factories.booking_entry import BookingEntryTypeFactory
from wbaccounting.factories.entry_accounting_information import VatFactory, EntryAccountingFactory
from wbcore.contrib.authentication.factories import (
    SuperUserFactory,
    UserActivityFactory,
)
from wbcore.contrib.currency.factories import CurrencyFactory, CurrencyFXRatesFactory
from wbcore.contrib.directory.factories import (
    BankingContactFactory,
    EntryFactory,
    PersonFactory, CompanyFactory, CustomerStatusFactory, CompanyTypeFactory,
)
from wbcrm.factories import (
    ProductFactory, AccountFactory
)
from wbcore.tests.conftest import *

register(VatFactory)
register(BookingEntryTypeFactory)
register(BookingEntryFactory)
register(InvoiceFactory)
register(InvoiceTypeFactory)
register(EntryAccountingInformationFactory)
register(EntryAccountingFactory)

register(TransactionFactory)
register(TransactionFactory, "transaction_no_value_date", value_date=None)
register(
    TransactionFactory,
    "transaction_fx",
    fx_rate=factory.Faker("pydecimal", min_value=Decimal(0.1), max_value=Decimal(0.9)),
)
register(LocalCurrencyTransactionFactory, "transaction_local_ccy")
register(
    LocalCurrencyTransactionFactory,
    "transaction_local_ccy_fx",
    fx_rate=factory.Faker("pydecimal", min_value=Decimal(0.1), max_value=Decimal(0.9)),
)


register(CurrencyFactory)
register(CurrencyFXRatesFactory)

register(EntryFactory)
register(UserFactory)
register(PersonFactory)
register(CompanyFactory)
register(CompanyTypeFactory)
register(CustomerStatusFactory)
register(SuperUserFactory)
register(UserActivityFactory)
register(BankingContactFactory)
register(ProductFactory)
register(AccountFactory)

pre_migrate.connect(app_pre_migration, sender=apps.get_app_config("wbaccounting"))


@pytest.fixture
def booking_entries(request, booking_entry_factory):
    return [booking_entry_factory.create() for _ in range(request.param)]
