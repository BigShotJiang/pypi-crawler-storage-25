from wbcore.metadata.configs import display as dp
from wbcore.metadata.configs.display.view_config import DisplayViewConfig


class BookingEntryDisplayConfig(DisplayViewConfig):
    def get_list_display(self) -> dp.ListDisplay:
        _counterparty_fields = [dp.Field(key="counterparty", label="Counterparty")]
        _common_fields = [
            dp.Field(
                key=None,
                label="Product",
                open_by_default=False,
                children=[
                    dp.Field(key="product", label="Product", width=325),
                    dp.Field(key="type", label="Type", width=250),
                    dp.Field(key="account", label="Account", width=250, show="open"),
                ],
            ),
            dp.Field(
                key=None,
                label="Date",
                open_by_default=False,
                children=[
                    dp.Field(key="period", label="Period", width=250),
                    dp.Field(key="booking_date", label="Book. Date", width=100),
                    dp.Field(key="reference_date", label="Ref. Date", width=100, show="open"),
                    dp.Field(key="payment_date", label="Payment. Date", width=100, show="open"),
                ],
            ),
            dp.Field(
                key=None,
                label="Value",
                open_by_default=False,
                children=[
                    dp.Field(key="gross_value", label="Gross", width=100),
                    dp.Field(key="net_value", label="Net", width=100),
                    dp.Field(key="vat", label="VAT", width=100, show="open"),
                    dp.Field(key="quantity", label="Quantity", width=100, show="open"),
                ],
            ),
            dp.Field(
                key=None,
                label="Invoice Value",
                open_by_default=False,
                children=[
                    dp.Field(key="invoice_fx_rate", label="FX", width=100),
                    dp.Field(key="invoice_gross_value", label="Gross", width=100, show="open"),
                    dp.Field(key="invoice_net_value", label="Net", width=100, show="open"),
                ],
            ),
        ]
        _invoice_fields = [dp.Field(key="invoice", label="Invoice", width=325)]

        if "invoice_id" in self.view.kwargs:
            return dp.ListDisplay(fields=_common_fields)

        if "entry_accounting_information_id" in self.view.kwargs:
            return dp.ListDisplay(fields=[*_common_fields, *_invoice_fields])

        return dp.ListDisplay(fields=[*_counterparty_fields, *_common_fields, *_invoice_fields])

    def get_instance_display(self) -> dp.Display:
        return dp.Display(
            pages=[
                dp.Page(
                    layouts={
                        dp.default(): dp.Layout(
                            grid_template_areas=[
                                ["title", "title", "title", "title"],
                                ["product", "product", "type", "type"],
                                ["counterparty", "counterparty", "period", "period"],
                                ["booking_date", "reference_date", "due_date", "payment_date"],
                                ["currency", "vat", "gross_value", "net_value"],
                                ["invoice_currency", "invoice_fx_rate", "invoice_gross_value", "invoice_net_value"],
                                ["invoice", "invoice", "account", "account"],
                            ],
                            grid_template_columns=[
                                "200px",
                                "200px",
                                "200px",
                                "200px",
                            ],
                        )
                    }
                )
            ]
        )
