import httpx
from guardianhub import get_logger
from guardianhub.clients.langfuse.manager import LangfuseManager
from guardianhub.config.settings import CoreSettings


logger = get_logger(__name__)

class VaultManager:
    def __init__(self, core_settings: CoreSettings):
        self.settings = core_settings
        self.client = httpx.Client(
            base_url=self.settings.endpoints.VAULT_MANAGER_URL,
            timeout=120.0
        )

    def populate_session_tenant(self, tenant_secrets: dict):
        """
        Reads tenant-specific directories from Vault and populates
        the SDK settings for the current session.
        """

        try:
            # 2. Read from Vault via Service API
            logger.info(f"[VaultManager] Response VT001 ======> {tenant_secrets}")

            # 3. Dynamic Injection into Endpoints or Credentials
            # We update the 'endpoints' and 'credentials' specifically
            for key, value in tenant_secrets.items():
                if hasattr(self.settings.endpoints, key):
                    setattr(self.settings.endpoints, key, value)

                # Also inject into credentials vault
                setattr(self.settings.credentials, key.upper(), value)

            logger.info(f"Successfully populated settings for tenant: {tenant_secrets}")
            LangfuseManager.reset()

        except httpx.HTTPStatusError as e:
            logger.error(f"Failed to fetch secrets for tenant {tenant_secrets} from Vault service:")
            raise
        except Exception as e:
            logger.error(f"Failed to fetch secrets for tenant {tenant_secrets} from Vault: {e}")
            raise