from __future__ import annotations

import numpy as np

from turboquant_llm import TurboQuantCompressor, TurboQuantConfig


def test_compress_roundtrip_first_stage_small_dim() -> None:
    dim = 16
    rng = np.random.default_rng(42)
    x = rng.standard_normal((4, dim))
    cfg = TurboQuantConfig(bits_main=8, qjl_projection_dim=0, seed=0)
    comp = TurboQuantCompressor(dim, cfg)
    batch = comp.compress(x)
    x_hat = comp.reconstruct_first_stage(batch)
    err = np.linalg.norm(x - x_hat) / (np.linalg.norm(x) + 1e-8)
    assert err < 0.15


def test_qjl_signs_shape() -> None:
    dim = 32
    k = 12
    x = np.random.default_rng(0).standard_normal((2, 3, dim))
    cfg = TurboQuantConfig(bits_main=4, qjl_projection_dim=k, seed=1)
    comp = TurboQuantCompressor(dim, cfg)
    b = comp.compress(x)
    assert b.qjl_signs is not None
    assert b.qjl_signs.shape == (2, 3, k)
