from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TurboQuantConfig:
    """Hyperparameters for the reference compressor (aligned with the public TurboQuant narrative).

    - ``bits_main``: scalar quantization after rotation (e.g. 3–4 for strong compression).
    - ``qjl_bits``: extra sign bits from the JL projection of the *residual* (QJL-style stage).
    """

    bits_main: int = 4
    qjl_projection_dim: int = 64
    seed: int = 0

    def __post_init__(self) -> None:
        if self.bits_main < 1:
            raise ValueError("bits_main must be >= 1")
        if self.qjl_projection_dim < 0:
            raise ValueError("qjl_projection_dim must be >= 0")
