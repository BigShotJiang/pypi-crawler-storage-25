from __future__ import annotations

import numpy as np


def quantize_global(
    x: np.ndarray,
    *,
    bits: int,
) -> tuple[np.ndarray, float, float, float]:
    """Min/max uniform quantization over all elements of ``x``.

    Integer codes are in ``[0, 2**bits - 1]``. Reconstruction:
    ``x_hat = amin + codes * scale``.
    """
    if bits < 1:
        raise ValueError("bits must be >= 1")
    n_levels = 2**bits
    eps = 1e-8
    amin = float(np.min(x))
    amax = float(np.max(x))
    if amax - amin < eps:
        scale = 1.0
        codes = np.zeros(x.shape, dtype=np.int64)
        return codes, scale, amin, amax
    scale = (amax - amin) / (n_levels - 1)
    codes = np.rint((x - amin) / scale).clip(0, n_levels - 1).astype(np.int64)
    return codes, scale, amin, amax


def dequantize_global(codes: np.ndarray, scale: float, amin: float, amax: float) -> np.ndarray:
    _ = amax  # kept for API symmetry / future per-channel max
    return amin + codes.astype(np.float64) * scale
