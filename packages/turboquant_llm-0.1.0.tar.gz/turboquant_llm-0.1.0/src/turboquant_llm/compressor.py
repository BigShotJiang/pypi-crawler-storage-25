from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from turboquant_llm.config import TurboQuantConfig
from turboquant_llm.rotation import random_orthogonal_matrix
from turboquant_llm.scalar_quant import dequantize_global, quantize_global


@dataclass
class CompressedBatch:
    """Compressed representation for a batch of row vectors ``x`` with shape ``(n, dim)``."""

    # Stage 1: rotated + scalar-quantized
    codes_main: np.ndarray
    scale_main: float
    amin_main: float
    amax_main: float
    # Stage 2: QJL signs on residual (columns are projection dimensions)
    qjl_signs: np.ndarray | None
    # Fixed per compressor instance (not stored per batch in a real system — kept for round-trip tests)
    rotation: np.ndarray
    jl_matrix: np.ndarray


class TurboQuantCompressor:
    """Reference TurboQuant-style pipeline: rotate → scalar quantize → 1-bit JL signs on residual.

    This is intended for experiments and API design, not a drop-in production KV kernel.
    Shapes: ``x`` is ``(..., dim)``; the last dimension must match ``dim``.
    """

    def __init__(self, dim: int, config: TurboQuantConfig | None = None) -> None:
        if dim < 2:
            raise ValueError("dim must be >= 2")
        self.dim = dim
        self.config = config or TurboQuantConfig()
        rng = np.random.default_rng(self.config.seed)
        self._R = random_orthogonal_matrix(dim, rng)
        k = self.config.qjl_projection_dim
        if k > 0:
            # Typical JL scaling: entries ~ N(0, 1/dim)
            self._J = rng.standard_normal((k, dim)) / np.sqrt(dim)
        else:
            self._J = np.zeros((0, dim), dtype=np.float64)

    @property
    def rotation(self) -> np.ndarray:
        return self._R

    @property
    def jl_matrix(self) -> np.ndarray:
        return self._J

    def compress(self, x: np.ndarray) -> CompressedBatch:
        x = np.asarray(x, dtype=np.float64)
        if x.shape[-1] != self.dim:
            raise ValueError(f"last dimension must be {self.dim}, got {x.shape[-1]}")
        flat = x.reshape(-1, self.dim)
        # Row vectors: x_rot = x @ R (maps through orthonormal columns of R)
        xr = flat @ self._R

        codes, sc, lo, hi = quantize_global(xr, bits=self.config.bits_main)
        recon = dequantize_global(codes, sc, lo, hi)
        residual = xr - recon

        if self._J.shape[0] == 0:
            signs = None
        else:
            # (n, k) — store 1-bit signs of JL projection of residual rows
            proj = residual @ self._J.T
            signs = (proj >= 0).astype(np.uint8)

        return CompressedBatch(
            codes_main=codes.reshape(x.shape),
            scale_main=sc,
            amin_main=lo,
            amax_main=hi,
            qjl_signs=signs.reshape(x.shape[:-1] + (self._J.shape[0],)) if signs is not None else None,
            rotation=self._R,
            jl_matrix=self._J,
        )

    def reconstruct_first_stage(self, batch: CompressedBatch) -> np.ndarray:
        """Reconstruct after rotation + inverse quant (ignores QJL residual)."""
        recon_flat = dequantize_global(
            batch.codes_main.reshape(-1, self.dim),
            batch.scale_main,
            batch.amin_main,
            batch.amax_main,
        )
        xr_hat = recon_flat
        x_hat = xr_hat @ self._R.T
        return x_hat.reshape(batch.codes_main.shape)
