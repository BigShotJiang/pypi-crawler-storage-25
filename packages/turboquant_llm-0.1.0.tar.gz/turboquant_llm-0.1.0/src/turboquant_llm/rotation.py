from __future__ import annotations

import numpy as np


def random_orthogonal_matrix(dim: int, rng: np.random.Generator) -> np.ndarray:
    """Haar-random orthogonal matrix via QR (columns orthonormal). Shape (dim, dim)."""
    a = rng.standard_normal((dim, dim))
    q, _ = np.linalg.qr(a, mode="complete")
    # QR is unique up to sign; stabilize column signs for reproducibility across platforms
    s = np.sign(np.diag(q))
    s[s == 0] = 1.0
    q = q * s
    return q.astype(np.float64, copy=False)
