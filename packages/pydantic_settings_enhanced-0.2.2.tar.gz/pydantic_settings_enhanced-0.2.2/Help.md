```cmd
git clone git@github.com:brookzhcn/pydantic_settings_enhanced.git
```

### publish step

```cmd
uv version 0.2.0 
uv build
uv publish -t $(cat pypi.tok)
```