from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    TomlConfigSettingsSource,
)
from typing import Tuple, Type, Any, ClassVar
import os
from pathlib import Path
import inspect
import logging
from pydantic_settings.sources import PathType


class PydanticSettingsEnhancedError(Exception):
    pass


class TomlConfigDirSettingsSource(TomlConfigSettingsSource):
    # 自动解析嵌目录
    def _read_files(self, files: PathType | None, deep_merge: bool = False) -> dict[str, Any]:
        new_files = []
        dirs = []
        for file in files:
            # print("file:", file)
            if isinstance(file, Path) and file.is_dir():
                # print("日志目录", file)
                dirs.append(file)
            else:
                new_files.append(file)

        data = super()._read_files(new_files, deep_merge)

        for d in dirs:
            # print("dir:", d.name)
            dmap = {}
            for sub_file in d.iterdir():
                if sub_file.is_file() and sub_file.suffix == ".toml":
                    dmap[sub_file.stem] = self._read_file(sub_file)
                    logging.debug("loading file:", sub_file.stem)
            data[d.name] = dmap
        # print("vars:", vars['terminals'])
        return data


class TomlBaseSettings(BaseSettings):
    debug: bool = True
    # ======================
    # 类变量（不会读取环境变量）
    # ======================
    CONFIG_DIR_NAME: ClassVar[str] = "confd"
    SHARED_CONFIG_FILENAME: ClassVar[str] = 'shared'
    # development | staging | production
    SERVER_ENV: ClassVar[str] = 'development'
    SERVER_ENV_NAME: ClassVar[str] = "SERVER_ENV"

    @classmethod
    def settings_customise_sources(
            cls,
            settings_cls: Type[BaseSettings],
            init_settings: PydanticBaseSettingsSource,
            env_settings: PydanticBaseSettingsSource,
            dotenv_settings: PydanticBaseSettingsSource,
            file_secret_settings: PydanticBaseSettingsSource,
    ) -> Tuple[PydanticBaseSettingsSource, ...]:
        cls.load_server_env()
        toml_file = cls.get_config_files()
        return (TomlConfigDirSettingsSource(settings_cls, toml_file),)

    @classmethod
    def load_server_env(cls):
        current_env = os.getenv(cls.SERVER_ENV_NAME, None)
        if current_env is not None and current_env != cls.SERVER_ENV:
            logging.info('loading server env var:', current_env)
            cls.SERVER_ENV = current_env

    @classmethod
    def get_config_files(cls) -> list[Path]:
        environment = cls.SERVER_ENV
        logging.info(f'current env: {environment}')
        # Get the module where the class is defined
        module = inspect.getmodule(cls)
        # Get the absolute file path of the module
        confd = Path(module.__file__).parent / cls.CONFIG_DIR_NAME
        if not Path.exists(confd):
            raise PydanticSettingsEnhancedError(f"{confd} should be created")

        files = []
        shared_config_file = confd / f"{cls.SHARED_CONFIG_FILENAME}.toml"
        if shared_config_file.exists():
            files.append(shared_config_file)
        env_config_file = confd / f"{environment}.toml"
        if env_config_file.exists():
            files.append(env_config_file)

        # scan sub dirs
        for sub_file in confd.iterdir():
            if sub_file.is_dir():
                logging.info('add sub dir:', sub_file)
                files.append(sub_file)
        return files
