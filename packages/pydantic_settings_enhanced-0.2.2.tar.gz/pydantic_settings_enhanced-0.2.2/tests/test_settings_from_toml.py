from pydantic import BaseModel
from pathlib import Path
from pydantic_settings_enhanced import TomlBaseSettings
import logging
import os


class TerminalConfig(BaseModel):
    id: str
    name: str
    host: str
    description: str = ""


class MyTestTomlBaseSettings(TomlBaseSettings):
    terminals: dict[str, TerminalConfig]
    logging_root: Path


def test_settings_from_toml():
    settings = MyTestTomlBaseSettings()
    logging.debug(f"Settings debug: {settings.debug}")
    assert settings.debug is True
    settings.SERVER_ENV == 'development'


def test_settings_from_stage():
    os.environ["SERVER_ENV"] = "staging"
    settings = MyTestTomlBaseSettings()
    logging.debug(f"Settings debug: {settings.debug}")
    assert settings.SERVER_ENV == "staging"
    assert settings.debug is False


def test_settings_from_sub_dir():
    os.environ["SERVER_ENV"] = "staging"
    settings = MyTestTomlBaseSettings()
    logging.debug(f"Settings debug: {settings.debug}")
    assert settings.terminals['demo1'].id == "demo1"


def test_path_settings():
    settings = MyTestTomlBaseSettings()
    assert isinstance(settings.logging_root, Path)
    print(settings.logging_root)
