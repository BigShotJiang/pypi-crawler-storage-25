### usage
- make a dir named confd in current working directory
- put a dev.toml in confd
- change env in production: `export SERVER_ENV='production'`
- create your own config file

```python
from pydantic_settings_enhanced import TomlBaseSettings

class TestTomlBaseSettings(TomlBaseSettings):
    debug: bool = False
```