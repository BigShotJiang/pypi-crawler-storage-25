from games import _2DGame, get_color

if __name__ == "__main__":
    game = _2DGame(800, 600, "Meu Jogo OpenGL")
    colors = get_color()
    
    # Criar um retângulo que o usuário pode controlar
    player = game.draw_rectangle(400, 300, 50, 50, colors['neon_blue'])
    
    def update():
        if game.pressed('d'): player[0] += 5
        if game.pressed('a'): player[0] -= 5
        if game.pressed('w'): player[1] += 5
        if game.pressed('s'): player[1] -= 5

    game.animation = update
    game.run()