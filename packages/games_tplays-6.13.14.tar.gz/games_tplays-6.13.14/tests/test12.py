from games import *
from games import __version__

cor = get_color()

class Jogo(_2DGame):
    def __init__(self):
        self.ícone = path('faviconTest12.png') # self.ícone = url('https://mario.nintendo.com/static/fd723b2893d4d2b39ef71bfdb4e3329c/93f4f/mario-background.png')

        super().__init__(800, 600, 'O meu jogo', self.ícone, False)

        self.bgColor = cor['cyan'] # self.bgColor = RGBA(green=255, blue=255)

        self.playerConf = {
            'pos': (800/2-40/2, 600/2-60/2),
            'size': (40, 60),
            'color': cor['red'], # 'color': RGBA(red=255),
            'speed': 5
        }

        self.player = self.draw_rectangle(self.playerConf['pos'][0], self.playerConf['pos'][1],
                                          self.playerConf['size'][0], self.playerConf['size'][1],
                                          self.playerConf['color'], layer=2)
        
        self.draw_image(self.ícone, 50, 50, 150, 200, rotation=40)
        
    def animation(self):
        if self.pressed('w'): self.player[self.Y['RECTANGLES']] += self.playerConf['speed']
        if self.pressed('a'): self.player[self.X['RECTANGLES']] -= self.playerConf['speed']
        if self.pressed('s'): self.player[self.Y['RECTANGLES']] -= self.playerConf['speed']
        if self.pressed('d'): self.player[self.X['RECTANGLES']] += self.playerConf['speed']

        if self.clicked('esc'): self.close()

if VERSION >= (4,11,14):
    Jogo().run()
else:
    print(f'O jogo é inválido para a versão {__version__}')