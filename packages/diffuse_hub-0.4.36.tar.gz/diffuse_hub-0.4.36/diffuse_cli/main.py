from __future__ import annotations

import asyncio
import json
import mimetypes
import os
import subprocess
import sys
import tempfile
import time
from hashlib import sha256
from pathlib import Path

import httpx
import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)
from rich.table import Table
from rich.tree import Tree
from tenacity import retry, stop_after_attempt, wait_exponential


CONTEXT_SETTINGS = {"help_option_names": ["-h", "--help"]}
PAGE_SIZE = 15

API_DEFAULT = "https://hub.diffuse.science"
CONFIG_DIR = Path.home() / ".diffuse"
CONFIG_FILE = CONFIG_DIR / "config.json"
UPDATE_CHECK_FILE = CONFIG_DIR / "last_update_check.json"
UPDATE_CHECK_INTERVAL = 86400

ENV_URLS = {
    "local": "http://127.0.0.1:8000",
    "prod": "https://hub.diffuse.science",
}


def _version_callback(value: bool) -> None:
    if value:
        from . import __version__

        typer.echo(f"diffuse {__version__.__version__}")
        raise typer.Exit()


def _guess_content_type(path: Path) -> str:
    """Guess MIME type from file extension, defaulting to application/octet-stream."""
    mime_type, _ = mimetypes.guess_type(str(path))
    return mime_type or "application/octet-stream"


app = typer.Typer(
    help="Diffuse CLI — manage experiments, metadata, and artifacts from your terminal.\n\n"
    "Connects to production (https://hub.diffuse.science) by default.\n"
    "To use other environments: diffuse config env --list",
    no_args_is_help=True,
    context_settings=CONTEXT_SETTINGS,
)

auth_app = typer.Typer(
    help="Authentication commands", context_settings=CONTEXT_SETTINGS
)
metadata_app = typer.Typer(
    help="Metadata management commands", context_settings=CONTEXT_SETTINGS
)
config_app = typer.Typer(
    help="CLI configuration commands", context_settings=CONTEXT_SETTINGS
)
artifacts_app = typer.Typer(
    help="Artifact management commands (M:N operations)",
    context_settings=CONTEXT_SETTINGS,
)
relationships_app = typer.Typer(
    help="Experiment relationship commands",
    context_settings=CONTEXT_SETTINGS,
)
fields_app = typer.Typer(
    help="Manage metadata field definitions (admin)",
    context_settings=CONTEXT_SETTINGS,
)
types_app = typer.Typer(
    help="Manage experiment types (admin)",
    context_settings=CONTEXT_SETTINGS,
)
collections_app = typer.Typer(
    help="Artifact collection management commands",
    context_settings=CONTEXT_SETTINGS,
)
governance_app = typer.Typer(
    help="Governance task management",
    context_settings=CONTEXT_SETTINGS,
)
flow_app = typer.Typer(
    help="Run experiment jobs (sampleworks, waterflow K8s flows)",
    context_settings=CONTEXT_SETTINGS,
)
keys_app = typer.Typer(help="API key management", context_settings=CONTEXT_SETTINGS)

app.add_typer(auth_app, name="auth")
app.add_typer(metadata_app, name="metadata")
app.add_typer(config_app, name="config")
app.add_typer(artifacts_app, name="artifacts")
app.add_typer(collections_app, name="collections")
app.add_typer(relationships_app, name="relationships")
app.add_typer(fields_app, name="fields")
app.add_typer(types_app, name="types")
app.add_typer(governance_app, name="governance")
app.add_typer(flow_app, name="run")
app.add_typer(keys_app, name="keys")

console = Console()


def get_local_version() -> str:
    from . import __version__

    return __version__.__version__


def get_server_version(api_url: str) -> str | None:
    try:
        response = httpx.get(
            f"{api_url.rstrip('/')}/api/version",
            timeout=3,
        )
        if response.status_code == 200:
            data = response.json()
            return data.get("version")
    except (httpx.HTTPError, Exception):
        pass
    return None


def should_check_for_updates() -> bool:
    if not UPDATE_CHECK_FILE.exists():
        return True
    try:
        data = json.loads(UPDATE_CHECK_FILE.read_text())
        last_check = data.get("last_check", 0)
        return (time.time() - last_check) > UPDATE_CHECK_INTERVAL
    except (json.JSONDecodeError, OSError):
        return True


def save_update_check() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    UPDATE_CHECK_FILE.write_text(json.dumps({"last_check": time.time()}))


def check_for_updates() -> None:
    force_check = os.getenv("DIFFUSE_FORCE_UPDATE_CHECK") == "1"

    if not force_check and not should_check_for_updates():
        return

    local_version = get_local_version()
    api_url = get_api_base(None)
    server_version = get_server_version(api_url)

    if not server_version:
        save_update_check()
        return

    def parse_version(v: str) -> tuple[int, ...]:
        return tuple(int(x) for x in v.split("."))

    try:
        local_parts = parse_version(local_version)
        server_parts = parse_version(server_version)
        cli_outdated = local_parts[:2] < server_parts[:2]
    except ValueError:
        cli_outdated = False

    if cli_outdated:
        message = (
            f"A new version of the Diffuse CLI is available!\n\n"
            f"  Local version:  [dim]{local_version}[/dim]\n"
            f"  Latest version: [bold]{server_version}[/bold]\n\n"
            f"Upgrade with:\n"
            f"  [cyan]uv tool upgrade diffuse-hub[/cyan]"
        )
        panel = Panel(
            message, title="Update Available", border_style="yellow", padding=(1, 2)
        )
        console.print()
        console.print(panel)
        console.print()

    save_update_check()


def get_api_base(server: str | None) -> str:
    if server:
        return server
    env_var = os.getenv("DIFFUSE_API_URL")
    if env_var:
        return env_var
    env_name = os.getenv("DIFFUSE_ENV")
    if env_name and env_name in ENV_URLS:
        return ENV_URLS[env_name]
    config = load_config()
    if api_url := config.get("api_url"):
        return api_url
    return API_DEFAULT


def get_github_client_id(api_url: str) -> str:
    """Fetch GitHub OAuth client ID from server."""
    try:
        response = httpx.get(f"{api_url.rstrip('/')}/auth/client-id", timeout=5)
        response.raise_for_status()
        return response.json()["client_id"]
    except httpx.HTTPError as exc:
        typer.secho(
            f"Failed to get client ID from {api_url}: {exc}", fg=typer.colors.RED
        )
        raise typer.Exit(code=1) from exc


def get_auth_headers() -> dict[str, str]:
    config = load_config()
    if api_key := os.environ.get("DIFFUSE_API_KEY"):
        return {"Authorization": f"Bearer {api_key}"}
    if api_key := config.get("api_key"):
        return {"Authorization": f"Bearer {api_key}"}
    if token := config.get("github_token"):
        return {"Authorization": f"Bearer {token}"}
    return {}


def _resolve_external_prefix(
    api: str,
    headers: dict[str, str],
    bucket_name: str,
    prefix: str,
) -> list[str]:
    """Recursively resolve all S3 keys under a prefix in an external bucket."""
    typer.echo(f"Listing files under prefix '{prefix}'...")
    params: dict[str, str] = {"prefix": prefix}
    try:
        response = httpx.get(
            f"{api.rstrip('/')}/api/external-buckets/{bucket_name}",
            headers=headers,
            params=params,
            timeout=60,
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to list bucket: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    listing = response.json()
    resolved_keys = [obj["key"] for obj in listing.get("objects", [])]

    sub_prefixes = listing.get("prefixes", [])
    while sub_prefixes:
        next_prefix = sub_prefixes.pop(0)
        try:
            sub_resp = httpx.get(
                f"{api.rstrip('/')}/api/external-buckets/{bucket_name}",
                headers=headers,
                params={"prefix": next_prefix},
                timeout=60,
            )
            sub_resp.raise_for_status()
            sub_listing = sub_resp.json()
            resolved_keys.extend(obj["key"] for obj in sub_listing.get("objects", []))
            sub_prefixes.extend(sub_listing.get("prefixes", []))
        except httpx.HTTPError:
            typer.secho(
                f"Warning: failed to list sub-prefix '{next_prefix}'",
                fg=typer.colors.YELLOW,
            )

    if resolved_keys:
        typer.echo(f"Found {len(resolved_keys)} file(s)")
    return resolved_keys


def load_config() -> dict[str, str]:
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def save_config(config: dict[str, str]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))
    CONFIG_FILE.chmod(0o600)


def format_output(data, format: str) -> str:
    if format == "json":
        return json.dumps(data, indent=2)
    elif format == "yaml":
        try:
            import yaml

            return yaml.dump(data, default_flow_style=False)
        except ImportError:
            typer.secho(
                "YAML output requires PyYAML. Install with: uv add pyyaml",
                fg=typer.colors.RED,
            )
            raise typer.Exit(code=1)
    return str(data)


def render_experiment_tree(experiments: list, title: str = "Experiments") -> Tree:
    """Render experiments as a rich Tree."""
    tree = Tree(f"[bold]{title}[/bold]")
    for exp in experiments:
        display_id = exp.get("display_id") or exp.get("id", "")[:8]
        exp_title = exp.get("title", "Untitled")
        public = (
            "[green]public[/green]" if exp.get("is_public") else "[dim]private[/dim]"
        )
        branch = tree.add(f"[cyan]{display_id}[/cyan] {exp_title} {public}")
        if exp.get("summary"):
            branch.add(f"[dim]{exp.get('summary')}[/dim]")
        if exp.get("updated_at"):
            branch.add(f"[dim]Updated: {exp.get('updated_at')[:10]}[/dim]")
        if exp.get("tags"):
            branch.add(f"Tags: {', '.join(exp['tags'])}")
    return tree


def render_experiment_detail_tree(exp: dict) -> Tree:
    """Render a single experiment's details as a tree."""
    display_id = exp.get("display_id") or exp.get("id", "")[:8]
    tree = Tree(
        f"[bold cyan]{display_id}[/bold cyan] [bold]{exp.get('title', 'Untitled')}[/bold]"
    )
    if exp.get("summary"):
        tree.add(f"[dim]{exp.get('summary')}[/dim]")
    info = tree.add("[bold]Info[/bold]")
    info.add(f"ID: [cyan]{exp.get('id', '')}[/cyan]")
    info.add(
        f"Public: {'[green]Yes[/green]' if exp.get('is_public') else '[dim]No[/dim]'}"
    )
    info.add(f"Updated: {exp.get('updated_at', 'N/A')}")
    if exp.get("tags"):
        info.add(f"Tags: {', '.join(exp['tags'])}")
    if exp.get("type"):
        info.add(
            f"Type: {exp['type'].get('display_name', exp['type'].get('name', 'N/A'))}"
        )
    if exp.get("markdown"):
        content = tree.add("[bold]Content[/bold]")
        for line in exp["markdown"].split("\n")[:10]:
            content.add(f"[dim]{line}[/dim]")
        if len(exp["markdown"].split("\n")) > 10:
            content.add("[dim]...[/dim]")
    return tree


def render_types_tree(types_list: list) -> Tree:
    """Render experiment types as a tree."""
    tree = Tree("[bold]Experiment Types[/bold]")
    for t in types_list:
        name = t.get("name", "unknown")
        display = t.get("display_name", name)
        active = "" if t.get("is_active", True) else " [dim](inactive)[/dim]"
        suffix = f" ({display})" if display != name else ""
        branch = tree.add(f"[cyan]{name}[/cyan]{suffix}{active}")
        if t.get("description"):
            branch.add(f"[dim]{t['description']}[/dim]")
    return tree


def render_fields_tree(fields: list, title: str = "Metadata Fields") -> Tree:
    """Render metadata field definitions as a tree."""
    tree = Tree(f"[bold]{title}[/bold]")
    for f in fields:
        key = f.get("key", "unknown")
        name = f.get("display_name", key)
        ftype = f.get("field_type", "TEXT")
        required = "[yellow]*[/yellow]" if f.get("required") else ""
        active = "" if f.get("is_active", True) else " [dim](inactive)[/dim]"
        label = f"[cyan]{key}[/cyan] {required}{name} [dim]({ftype})[/dim]{active}"
        branch = tree.add(label)
        if f.get("description"):
            branch.add(f"[dim]{f['description']}[/dim]")
        if f.get("unit"):
            branch.add(f"Unit: {f['unit']}")
        if f.get("allowed_values"):
            branch.add(f"Allowed: {', '.join(f['allowed_values'])}")
        if f.get("default_value"):
            branch.add(f"Default: {f['default_value']}")
    return tree


def render_type_detail_tree(exp_type: dict) -> Tree:
    """Render a single experiment type's details as a tree."""
    name = exp_type.get("name", "unknown")
    display = exp_type.get("display_name", name)
    tree = Tree(f"[bold cyan]{name}[/bold cyan] ({display})")
    info = tree.add("[bold]Info[/bold]")
    info.add(f"ID: [cyan]{exp_type.get('id', '')}[/cyan]")
    active = "[green]Yes[/green]" if exp_type.get("is_active") else "[dim]No[/dim]"
    info.add(f"Active: {active}")
    if exp_type.get("description"):
        info.add(f"Description: {exp_type['description']}")
    if exp_type.get("created_at"):
        info.add(f"Created: {exp_type['created_at'][:10]}")
    if exp_type.get("updated_at"):
        info.add(f"Updated: {exp_type['updated_at'][:10]}")
    metadata_fields = exp_type.get("metadata_fields") or []
    if metadata_fields:
        fields_branch = tree.add(
            f"[bold]Metadata Fields ({len(metadata_fields)})[/bold]"
        )
        for mf in metadata_fields:
            req = "[yellow]*[/yellow]" if mf.get("required") else ""
            ftype = mf.get("field_type", "TEXT")
            fields_branch.add(
                f"[cyan]{mf.get('key', '')}[/cyan] {req}{mf.get('display_name', '')} "
                f"[dim]({ftype})[/dim]"
            )
    if exp_type.get("markdown_template"):
        template = tree.add("[bold]Template[/bold]")
        for line in exp_type["markdown_template"].split("\n")[:5]:
            template.add(f"[dim]{line}[/dim]")
        if len(exp_type["markdown_template"].split("\n")) > 5:
            template.add("[dim]...[/dim]")
    return tree


def render_activity_tree(activities: list, title: str = "Activity") -> Tree:
    """Render activity feed as a tree."""
    tree = Tree(f"[bold]{title}[/bold]")
    for act in activities:
        action = act.get("action", "unknown")
        resource = act.get("resource_type", "")
        timestamp = act.get("created_at", "")[:16] if act.get("created_at") else ""
        color = {"create": "green", "update": "yellow", "delete": "red"}.get(
            action, "white"
        )
        branch = tree.add(
            f"[{color}]{action}[/{color}] {resource} [dim]{timestamp}[/dim]"
        )
        if act.get("resource_id"):
            branch.add(f"[dim]ID: {act['resource_id']}[/dim]")
    return tree


def render_artifacts_tree(artifacts: list, title: str = "Artifacts") -> Tree:
    """Render artifacts as a tree."""
    tree = Tree(f"[bold]{title}[/bold]")
    for art in artifacts:
        name = (
            art.get("artifact_path")
            or art.get("name")
            or art.get("filename")
            or art.get("s3_key", "")
        )
        size = art.get("size_bytes", 0)
        size_str = (
            f"{size / 1024 / 1024:.1f}MB"
            if size > 1024 * 1024
            else f"{size / 1024:.1f}KB"
            if size > 1024
            else f"{size}B"
        )
        is_external = art.get("is_external", False)
        source = "[yellow]external[/yellow]" if is_external else "[dim]internal[/dim]"
        branch = tree.add(f"[cyan]{name}[/cyan] {source} [dim]{size_str}[/dim]")
        if art.get("content_type") or art.get("artifact_type"):
            branch.add(
                f"[dim]Type: {art.get('content_type') or art.get('artifact_type')}[/dim]"
            )
        if art.get("experiments"):
            branch.add(f"[dim]Connections: {len(art['experiments'])}[/dim]")
    return tree


def render_artifact_detail_tree(art: dict) -> Tree:
    """Render a single artifact's details as a tree."""
    name = art.get("name") or art.get("artifact_path") or art.get("s3_key", "")
    tree = Tree(f"[bold cyan]{name}[/bold cyan]")
    info = tree.add("[bold]Info[/bold]")
    info.add(f"ID: [cyan]{art.get('id', '')}[/cyan]")
    info.add(f"Type: {art.get('artifact_type', 'N/A')}")
    size = art.get("size_bytes", 0)
    size_str = (
        f"{size / 1024 / 1024:.2f} MB"
        if size > 1024 * 1024
        else f"{size / 1024:.2f} KB"
        if size > 1024
        else f"{size} B"
    )
    info.add(f"Size: {size_str}")
    info.add(f"Status: {art.get('status', 'N/A')}")
    if art.get("is_external"):
        info.add("[yellow]External artifact[/yellow]")
    experiments = art.get("experiments", [])
    if experiments:
        conns = tree.add(f"[bold]Connected Experiments ({len(experiments)})[/bold]")
        for exp in experiments:
            conns.add(
                f"[cyan]{exp.get('display_id', '')}[/cyan] {exp.get('title', '')}"
            )
    else:
        tree.add("[yellow]Not connected to any experiments[/yellow]")
    return tree


def is_uuid(value: str) -> bool:
    try:
        import uuid as uuid_module

        uuid_module.UUID(value)
        return True
    except ValueError:
        return False


def resolve_experiment_type(api: str, type_value: str) -> str | None:
    if is_uuid(type_value):
        return type_value
    try:
        response = httpx.get(
            f"{api.rstrip('/')}/api/experiment-types",
            headers=get_auth_headers(),
            timeout=10,
        )
        response.raise_for_status()
        types = response.json()
        for t in types:
            if t.get("name", "").lower() == type_value.lower():
                return t["id"]
            if t.get("display_name", "").lower() == type_value.lower():
                return t["id"]
        return type_value
    except httpx.HTTPError:
        return type_value


def paginate_results(
    items: list,
    render_page: callable,
    page_size: int = PAGE_SIZE,
) -> None:
    if not items:
        return

    total = len(items)
    offset = 0

    while offset < total:
        page = items[offset : offset + page_size]
        render_page(page)
        offset += page_size

        if offset >= total:
            typer.secho(f"\n({total} total)", fg=typer.colors.BRIGHT_BLACK)
            break

        remaining = total - offset
        typer.secho(
            f"\n[{offset}/{total}] Press SPACE for more ({remaining} remaining), q to quit",
            fg=typer.colors.BRIGHT_BLACK,
        )

        try:
            import termios
            import tty

            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = sys.stdin.read(1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

            if ch in ("q", "Q", "\x03"):  # q or Ctrl+C
                typer.echo()
                break
            if ch != " ":
                typer.echo()
                break
            typer.echo()
        except (ImportError, OSError):
            break


@app.command()
def version(
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Show CLI and server version information."""
    local_ver = get_local_version()
    api_url = get_api_base(server)
    server_ver = get_server_version(api_url)

    table = Table(title="Version Information")
    table.add_column("Component", style="cyan")
    table.add_column("Version", style="bold")
    table.add_column("Status", justify="center")

    def parse_version(v: str) -> tuple[int, ...]:
        return tuple(int(x) for x in v.split("."))

    cli_outdated = False
    if server_ver and server_ver != "unknown":
        try:
            cli_outdated = parse_version(local_ver) < parse_version(server_ver)
        except ValueError:
            pass

    local_status = "[yellow]⚠ update available[/yellow]" if cli_outdated else "✓"
    table.add_row("Local CLI", local_ver, local_status)

    if server_ver and server_ver != "unknown":
        table.add_row(f"Server ({api_url})", server_ver, "✓")
    elif server_ver == "unknown":
        table.add_row(f"Server ({api_url})", "unknown", "[red]✗[/red]")
    else:
        table.add_row(f"Server ({api_url})", "unreachable", "[red]✗[/red]")

    console.print()
    console.print(table)
    console.print()

    if cli_outdated:
        console.print(
            "[yellow]A newer CLI version is available. Upgrade with:[/yellow]"
        )
        console.print("  [cyan]uv tool upgrade diffuse-hub[/cyan]")
        console.print()


@app.command("list")
def list_experiments(
    query: str | None = typer.Option(
        None,
        "--query",
        "-q",
        help="Query string with search syntax (e.g., 'tag:crystal AND resolution:>1.5')",
    ),
    public: bool = typer.Option(False, "--public", help="Show only public experiments"),
    private: bool = typer.Option(
        False, "--private", help="Show only private experiments"
    ),
    sort: str = typer.Option(
        "recent", "--sort", "-s", help="Sort by: recent, oldest, title, artifacts"
    ),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    page: int | None = typer.Option(
        None,
        "--page",
        "-p",
        help="Page number (1-indexed). Disables interactive pagination",
    ),
    page_size: int | None = typer.Option(
        None, "--page-size", "-n", help="Items per page (max 200)"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List experiments with optional filtering and sorting.

    Query syntax supports:
      - field:value       Match field containing value
      - field:>value      Greater than comparison (dates, numbers)
      - field:>=value     Greater than or equal
      - field:value*      Wildcard prefix match
      - field:"quoted"    Exact phrase match
      - AND, OR, NOT      Boolean operators
      - (...)             Grouping

    Built-in fields: title, summary, id, tag, author, type, created, updated, public
    Custom metadata fields are also searchable.

    Examples:
      diffuse list -q "tag:crystal"
      diffuse list -q "tag:xray AND resolution:>1.5"
      diffuse list -q "created:>2024-01-01 AND NOT public:false"
    """
    if page is not None and page < 1:
        typer.secho("Invalid page: must be >= 1", fg=typer.colors.RED)
        raise typer.Exit(code=1)
    if page_size is not None and page_size < 1:
        typer.secho("Invalid page-size: must be >= 1", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments"

    params: dict[str, str | int] = {}

    if query:
        params["q"] = query

    sort_map = {"recent": ("updated_at", "desc"), "oldest": ("updated_at", "asc")}
    if sort in sort_map:
        params["sort"], params["order"] = sort_map[sort]
    elif sort == "title":
        params["sort"] = "title"
        params["order"] = "asc"

    effective_page_size = min(page_size or 200, 200)
    params["limit"] = effective_page_size
    if page is not None:
        params["offset"] = (page - 1) * effective_page_size

    try:
        response = httpx.get(
            endpoint, params=params, headers=get_auth_headers(), timeout=10
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 400:
            error_detail = exc.response.json().get("detail", str(exc))
            typer.secho(f"Search error: {error_detail}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to retrieve experiments: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to retrieve experiments: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    experiments = response.json()

    if public:
        experiments = [e for e in experiments if e.get("is_public")]
    elif private:
        experiments = [e for e in experiments if not e.get("is_public")]

    if sort == "artifacts":
        experiments.sort(key=lambda e: e.get("artifact_count") or 0, reverse=True)

    if format in ["json", "yaml"]:
        typer.echo(format_output(experiments, format))
        return

    if not experiments:
        typer.echo("No experiments found.")
        return

    def render_tree_page(items: list) -> None:
        console.print(render_experiment_tree(items))

    def render_table_page(items: list) -> None:
        table = Table(show_lines=False, show_header=True)
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Title", style="bold")
        table.add_column("Summary")
        table.add_column("Updated", style="dim", no_wrap=True)
        table.add_column("Public", justify="center", width=6)

        for exp in items:
            table.add_row(
                exp.get("display_id") or exp.get("id", ""),
                exp.get("title", "Untitled"),
                exp.get("summary") or "",
                exp.get("updated_at", "")[:10],
                "Y" if exp.get("is_public") else "-",
            )

        console.print(table)

    render_fn = render_tree_page if format == "tree" else render_table_page

    if page is not None:
        render_fn(experiments)
    else:
        paginate_results(experiments, render_fn, page_size or PAGE_SIZE)


@app.command()
def view(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """View experiment details."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{experiment_id}"

    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to retrieve experiment: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    experiment = response.json()

    if format in ["json", "yaml"]:
        typer.echo(format_output(experiment, format))
        return

    if format == "tree":
        console.print(render_experiment_detail_tree(experiment))
        return

    # Table format
    table = Table(show_header=False, box=None)
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("Title", experiment.get("title", "Untitled"))
    table.add_row("ID", experiment.get("display_id") or experiment.get("id", ""))
    table.add_row("UUID", experiment.get("id", ""))
    table.add_row("Public", "Yes" if experiment.get("is_public") else "No")
    table.add_row("Updated", experiment.get("updated_at", "N/A"))
    if experiment.get("summary"):
        table.add_row("Summary", experiment["summary"])
    if experiment.get("tags"):
        table.add_row("Tags", ", ".join(experiment["tags"]))
    if experiment.get("type"):
        table.add_row(
            "Type",
            experiment["type"].get(
                "display_name", experiment["type"].get("name", "N/A")
            ),
        )
    console.print(table)
    if experiment.get("markdown"):
        console.print("\n[bold]Content[/bold]")
        console.print(
            f"[dim]{experiment['markdown'][:500]}{'...' if len(experiment['markdown']) > 500 else ''}[/dim]"
        )


@app.command()
def create(
    title: str = typer.Option(
        ..., "--title", "-t", help="Experiment title", prompt=True
    ),
    exp_type: str | None = typer.Option(
        None, "--type", "-T", help="Experiment type (e.g., generic, protocol, dataset)"
    ),
    summary: str | None = typer.Option(None, "--summary", help="Brief summary"),
    tags: str | None = typer.Option(None, "--tags", help="Comma-separated tags"),
    markdown: Path | None = typer.Option(
        None, "--markdown", help="Path to markdown file"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Create a new experiment."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments"

    payload: dict = {"title": title}
    if exp_type:
        payload["type_id"] = resolve_experiment_type(api, exp_type)
    if summary:
        payload["summary"] = summary
    if tags:
        payload["tags"] = [t.strip() for t in tags.split(",")]
    if markdown and markdown.exists():
        payload["markdown"] = markdown.read_text()

    try:
        response = httpx.post(
            endpoint, headers=get_auth_headers(), json=payload, timeout=15
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to create experiment: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    experiment = response.json()
    typer.secho(
        f"Experiment created: {experiment.get('display_id', experiment.get('id'))}",
        fg=typer.colors.GREEN,
    )
    typer.echo(f"  Title: {experiment.get('title')}")


@app.command()
def edit(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    title: str | None = typer.Option(None, "--title", help="Update title"),
    summary: str | None = typer.Option(None, "--summary", help="Update summary"),
    tags: str | None = typer.Option(
        None, "--tags", help="Update tags (comma-separated)"
    ),
    markdown: Path | None = typer.Option(
        None, "--markdown", help="Update markdown from file"
    ),
    editor: bool = typer.Option(
        False, "--editor", "-e", help="Open markdown in $EDITOR"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Edit an experiment."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{experiment_id}"

    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
        experiment = response.json()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to retrieve experiment: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    payload = {}

    if editor:
        editor_cmd = os.environ.get("EDITOR", "vim")
        with tempfile.NamedTemporaryFile(mode="w+", suffix=".md", delete=False) as tmp:
            tmp.write(experiment.get("markdown", ""))
            tmp.flush()
            tmp_path = tmp.name

        try:
            subprocess.run([editor_cmd, tmp_path], check=True)
            with open(tmp_path) as f:
                payload["markdown"] = f.read()
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    if title:
        payload["title"] = title
    if summary:
        payload["summary"] = summary
    if tags:
        payload["tags"] = [t.strip() for t in tags.split(",")]
    if markdown and markdown.exists():
        payload["markdown"] = markdown.read_text()

    if not payload:
        typer.echo("No changes specified.")
        return

    try:
        response = httpx.patch(
            endpoint, headers=get_auth_headers(), json=payload, timeout=15
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to update experiment: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"✓ Experiment updated: {experiment_id}", fg=typer.colors.GREEN)


@app.command()
def delete(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    hard: bool = typer.Option(
        False, "--hard", help="Permanently delete (admin only, removes artifacts)"
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Delete an experiment."""
    action = "permanently delete" if hard else "delete"
    if not yes:
        confirm = typer.confirm(f"{action.capitalize()} experiment {experiment_id}?")
        if not confirm:
            raise typer.Abort()

    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{experiment_id}"
    if hard:
        endpoint += "/hard"

    try:
        response = httpx.delete(endpoint, headers=get_auth_headers(), timeout=15)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to {action} experiment: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"Experiment {action}d: {experiment_id}", fg=typer.colors.GREEN)


@app.command()
def restore(
    experiment_id: str = typer.Argument(..., help="Experiment ID or display ID"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Restore a soft-deleted experiment from trash."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{experiment_id}/restore"

    try:
        response = httpx.post(endpoint, headers=get_auth_headers(), timeout=15)
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            typer.secho(f"Experiment not found: {experiment_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to restore experiment: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to restore experiment: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"Experiment restored: {experiment_id}", fg=typer.colors.GREEN)


@app.command()
def publish(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Publish an experiment to the public catalog."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{experiment_id}/publish"

    try:
        response = httpx.post(endpoint, headers=get_auth_headers(), timeout=30)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to publish experiment: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho("✓ Experiment published!", fg=typer.colors.GREEN)


@app.command()
def unpublish(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Unpublish an experiment from the public catalog."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{experiment_id}/unpublish"

    try:
        response = httpx.post(endpoint, headers=get_auth_headers(), timeout=30)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to unpublish experiment: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho("✓ Experiment unpublished!", fg=typer.colors.GREEN)


@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
async def _upload_part(
    client: httpx.AsyncClient,
    url: str,
    headers: dict,
    data: bytes,
    part_number: int,
) -> dict:
    """Upload a single part with retry logic."""
    response = await client.put(url, headers=headers, content=data, timeout=300)
    response.raise_for_status()
    etag = response.headers.get("ETag") or response.headers.get("etag")
    if not etag:
        raise RuntimeError(f"Missing ETag for part {part_number}")
    return {"part_number": part_number, "etag": etag.replace('"', "")}


async def _upload_parts_parallel(
    file_path: Path,
    parts: list[dict],
    chunk_size: int,
    concurrency: int,
    progress: Progress,
    task_id,
    file_task=None,
) -> list[dict]:
    """Upload all parts in parallel with concurrency limit."""
    semaphore = asyncio.Semaphore(concurrency)
    file_size = file_path.stat().st_size

    async def upload_with_semaphore(part: dict) -> dict:
        async with semaphore:
            part_number = part["part_number"]
            start = (part_number - 1) * chunk_size
            to_read = min(chunk_size, file_size - start)

            with file_path.open("rb") as f:
                f.seek(start)
                data = f.read(to_read)

            async with httpx.AsyncClient() as client:
                result = await _upload_part(
                    client, part["url"], part.get("headers", {}), data, part_number
                )
            progress.advance(task_id, to_read)
            if file_task is not None:
                progress.advance(file_task, to_read)
            return result

    tasks = [upload_with_semaphore(part) for part in parts]
    results = await asyncio.gather(*tasks)
    return sorted(results, key=lambda x: x["part_number"])


EXCLUDE_DIRS = {"__pycache__", ".git", ".svn", ".hg", "node_modules", ".venv", "venv"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".swp", ".swo", ".DS_Store"}


def _collect_files(path: Path) -> list[Path]:
    """Recursively collect all files from a path, excluding common patterns."""
    if path.is_file():
        return [path]

    def should_include(f: Path) -> bool:
        if any(part in EXCLUDE_DIRS for part in f.parts):
            return False
        if f.suffix in EXCLUDE_SUFFIXES or f.name in EXCLUDE_SUFFIXES:
            return False
        return True

    return sorted(f for f in path.rglob("*") if f.is_file() and should_include(f))


async def _batch_create_sessions(
    api: str,
    experiment_id: str | None,
    files: list[tuple[Path, str, str]],  # (file_path, artifact_path, checksum)
) -> dict[str, dict]:
    """Batch create upload sessions for multiple files.

    Returns dict mapping artifact_path to session data.
    If experiment_id is None, creates standalone artifacts.
    """
    headers = get_auth_headers()
    file_requests = []
    for file_path, artifact_path, checksum in files:
        stat = file_path.stat()
        metadata = {
            "experiment_slug": experiment_id or "standalone",
            "artifact_name": artifact_path,
            "artifact_type": "artifact",
            "tags": [],
            "checksum": checksum,
            "description": f"Uploaded {artifact_path}",
            "file_mtime": stat.st_mtime,
        }
        file_request: dict = {
            "filename": artifact_path,
            "content_type": _guess_content_type(file_path),
            "size_bytes": stat.st_size,
            "file_mtime": stat.st_mtime,
            "metadata_document": metadata,
        }
        # Only include experiment_id if not standalone
        if experiment_id:
            file_request["experiment_id"] = experiment_id
        file_requests.append(file_request)

    payload: dict = {"files": file_requests}
    # Only include experiment_id in batch payload if not standalone
    if experiment_id:
        payload["experiment_id"] = experiment_id

    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{api.rstrip('/')}/api/uploads/sessions/batch",
            headers=headers,
            json=payload,
            timeout=60,
        )
        response.raise_for_status()

    result = response.json()
    sessions = {}
    for i, session in enumerate(result["sessions"]):
        artifact_path = files[i][1]
        sessions[artifact_path] = session
    return sessions


async def _batch_finalize_sessions(
    api: str,
    finalizations: list[dict],
) -> dict:
    """Batch finalize multiple upload sessions.

    Args:
        finalizations: list of {session_id, parts, metadata_document}

    Returns response with completed and failed lists.
    """
    headers = get_auth_headers()
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{api.rstrip('/')}/api/uploads/finalize/batch",
            headers=headers,
            json={"finalizations": finalizations},
            timeout=120,
        )
        response.raise_for_status()
    return response.json()


async def _upload_files_batch(
    files: list[tuple[Path, str, str]],  # (file_path, artifact_path, checksum)
    experiment_id: str | None,
    api: str,
    concurrency: int,
    progress: Progress,
    overall_task,
    stats,
    live,
) -> list[tuple[str, dict | None, str | None]]:
    """Upload multiple files using batch session creation and finalization.

    This reduces HTTP requests from 2N+1 to 3 for N files:
    - 1 batch session creation (instead of N)
    - N parallel part uploads (same)
    - 1 batch finalization (instead of N)

    If experiment_id is None, creates standalone artifacts.

    Returns list of (artifact_path, result, error) tuples.
    """
    if not files:
        return []

    # Step 1: Batch create all sessions
    try:
        sessions = await _batch_create_sessions(api, experiment_id, files)
    except Exception as e:
        # If batch fails, return all files as failed
        return [(ap, None, f"Batch session creation failed: {e}") for _, ap, _ in files]

    # Save sessions for potential resume
    for file_path, artifact_path, checksum in files:
        session = sessions.get(artifact_path)
        if session:
            session_data = {
                "session_id": session["session_id"],
                "file_path": str(file_path),
                "artifact_path": artifact_path,
                "experiment_id": experiment_id,
                "api": api,
                "content_type": _guess_content_type(file_path),
                "chunk_size": session["chunk_size"],
                "file_size": file_path.stat().st_size,
                "checksum": checksum,
            }
            save_upload_session(session_data)

    # Step 2: Upload parts for all files concurrently
    semaphore = asyncio.Semaphore(concurrency)
    upload_results: dict[
        str, tuple[list[dict], dict]
    ] = {}  # artifact_path -> (parts, metadata)
    failed: list[tuple[str, str]] = []

    async def upload_file_parts(file_path: Path, artifact_path: str, checksum: str):
        session = sessions.get(artifact_path)
        if not session:
            return (artifact_path, None, "No session created")

        stat = file_path.stat()
        chunk_size = session["chunk_size"]

        file_task = progress.add_task(
            f"  {artifact_path}", total=stat.st_size, start=False
        )
        progress.start_task(file_task)

        try:
            parts = await _upload_parts_with_semaphore(
                file_path,
                session["presigned_parts"],
                chunk_size,
                semaphore,
                progress,
                overall_task,
                file_task,
                stats,
                live,
            )
            metadata = {
                "experiment_slug": experiment_id,
                "artifact_name": artifact_path,
                "artifact_type": "artifact",
                "tags": [],
                "checksum": checksum,
                "description": f"Uploaded {artifact_path}",
                "file_mtime": stat.st_mtime,
            }
            upload_results[artifact_path] = (parts, metadata, session["session_id"])

            progress.update(
                file_task,
                description=f"[green]  {artifact_path} ✓",
                completed=stat.st_size,
            )
            stats.total_uploaded += stat.st_size
            return (artifact_path, "uploaded", None)
        except Exception as e:
            progress.update(
                file_task,
                description=f"[red]  {artifact_path} ✗",
                completed=stat.st_size,
            )
            stats.failed_files += 1
            return (artifact_path, None, str(e))
        finally:
            stats.active_uploads = max(0, stats.active_uploads - 1)

    # Upload all files concurrently
    stats.active_uploads = len(files)
    tasks = [upload_file_parts(fp, ap, cs) for fp, ap, cs in files]
    part_results = await asyncio.gather(*tasks)

    # Collect failures from part upload phase
    for artifact_path, result, error in part_results:
        if error:
            failed.append((artifact_path, error))

    # Step 3: Batch finalize all successful uploads
    finalizations = []
    for artifact_path, (parts, metadata, session_id) in upload_results.items():
        if not parts:
            failed.append((artifact_path, "No parts uploaded (file may be too small)"))
            continue
        finalizations.append(
            {
                "session_id": session_id,
                "parts": parts,
                "metadata_document": metadata,
            }
        )

    final_results: list[tuple[str, dict | None, str | None]] = []

    if finalizations:
        try:
            batch_result = await _batch_finalize_sessions(api, finalizations)
            completed_ids = set(batch_result.get("completed", []))
            failed_items = {
                f["session_id"]: f["error"] for f in batch_result.get("failed", [])
            }

            for artifact_path, (parts, metadata, session_id) in upload_results.items():
                if session_id in completed_ids:
                    delete_upload_session(experiment_id, artifact_path)
                    stats.completed_files += 1
                    final_results.append((artifact_path, {"status": "completed"}, None))
                elif session_id in failed_items:
                    final_results.append(
                        (artifact_path, None, failed_items[session_id])
                    )
                else:
                    final_results.append(
                        (artifact_path, None, "Unknown finalization status")
                    )
        except Exception as e:
            # Batch finalize failed - mark all as failed
            for artifact_path in upload_results:
                final_results.append(
                    (artifact_path, None, f"Batch finalization failed: {e}")
                )

    # Add failures from earlier phases
    for artifact_path, error in failed:
        final_results.append((artifact_path, None, error))

    return final_results


async def _upload_files_concurrent(
    files: list[tuple[Path, str, str]],  # (file_path, artifact_path, checksum)
    experiment_id: str,
    api: str,
    concurrency: int,
    progress: Progress,
    overall_task,
    checksum_cache: dict | None,
    stats,
) -> list[tuple[str, dict | None, str | None]]:
    """Upload multiple files concurrently with shared concurrency limit.

    Returns list of (artifact_path, result, error) tuples.
    """
    semaphore = asyncio.Semaphore(concurrency)

    async def upload_file(file_path: Path, artifact_path: str, checksum: str):
        file_size = file_path.stat().st_size
        file_task = progress.add_task(
            f"  {artifact_path}", total=file_size, start=False
        )
        try:
            progress.start_task(file_task)
            result = await _upload_file_async(
                file_path,
                artifact_path,
                experiment_id,
                api,
                semaphore,
                progress,
                overall_task,
                checksum_cache,
                checksum,
                file_task,
                stats,
                None,  # No live display
            )
            progress.remove_task(file_task)
            stats.total_uploaded += file_size
            return (artifact_path, result, None)
        except Exception as e:
            progress.update(
                file_task,
                description=f"[red]  {artifact_path} (failed)",
                completed=file_size,
            )
            progress.advance(
                overall_task, file_size - progress.tasks[file_task].completed
            )
            return (artifact_path, None, str(e))

    tasks = [upload_file(fp, ap, cs) for fp, ap, cs in files]
    return await asyncio.gather(*tasks)


async def _upload_files_concurrent_with_stats(
    files: list[tuple[Path, str, str]],  # (file_path, artifact_path, checksum)
    experiment_id: str | None,
    api: str,
    concurrency: int,
    progress: Progress,
    overall_task,
    checksum_cache: dict | None,
    stats,
    live,
) -> list[tuple[str, dict | None, str | None]]:
    """Upload multiple files concurrently with enhanced stats tracking.

    If experiment_id is None, creates standalone artifacts.

    Returns list of (artifact_path, result, error) tuples.
    """
    semaphore = asyncio.Semaphore(concurrency)

    async def upload_file(file_path: Path, artifact_path: str, checksum: str):
        stats.active_uploads += 1
        stats.current_file = artifact_path
        if live:
            live.update(
                Panel.fit(
                    stats.get_table(), title="📊 Upload Progress", border_style="blue"
                )
            )

        file_size = file_path.stat().st_size

        # Only show individual progress bars in test mode, not in Live display
        if live:
            file_task = None
        else:
            file_task = progress.add_task(
                f"  {artifact_path}", total=file_size, start=False
            )
            progress.start_task(file_task)

        try:
            result = await _upload_file_async(
                file_path,
                artifact_path,
                experiment_id,
                api,
                semaphore,
                progress,
                overall_task,
                checksum_cache,
                checksum,
                file_task,
                stats,
                live,
            )
            if file_task is not None:
                progress.update(
                    file_task,
                    description=f"[green]  {artifact_path} ✓",
                    completed=file_size,
                )

                # Remove the task after a brief delay to show success
                async def remove_task():
                    await asyncio.sleep(0.1)
                    progress.remove_task(file_task)

                asyncio.create_task(remove_task())
            stats.total_uploaded += file_size
            stats.completed_files += 1
            return (artifact_path, result, None)
        except Exception as e:
            if file_task is not None:
                progress.update(
                    file_task,
                    description=f"[red]  {artifact_path} (failed)",
                    completed=file_size,
                )
                progress.advance(
                    overall_task, file_size - progress.tasks[file_task].completed
                )
            stats.failed_files += 1
            return (artifact_path, None, str(e))
        finally:
            stats.active_uploads -= 1
            if stats.active_uploads == 0:
                stats.current_file = ""
            if live:
                live.refresh()

    tasks = [upload_file(fp, ap, cs) for fp, ap, cs in files]
    return await asyncio.gather(*tasks)


async def _upload_file_async(
    file_path: Path,
    artifact_path: str,
    experiment_id: str | None,
    api: str,
    semaphore: asyncio.Semaphore,
    progress: Progress,
    overall_task,
    checksum_cache: dict | None,
    checksum: str,
    file_task,
    stats,
    live,
) -> dict:
    """Upload a single file asynchronously using shared semaphore.

    If experiment_id is None, creates a standalone artifact.
    """
    file_size = file_path.stat().st_size

    # Check for existing partial upload session
    existing_session = load_upload_session(experiment_id, artifact_path)
    if existing_session:
        if (
            existing_session.get("file_size") == file_size
            and existing_session.get("checksum") == checksum
        ):
            try:
                return await _resume_upload_async(
                    existing_session,
                    api,
                    semaphore,
                    progress,
                    overall_task,
                    file_task,
                    stats,
                    live,
                )
            except httpx.HTTPStatusError as e:
                if e.response.status_code in (404, 400, 410):
                    # Session expired/invalid - delete local cache and start fresh
                    delete_upload_session(experiment_id, artifact_path)
                    # Fall through to start a new upload
                else:
                    raise
        else:
            delete_upload_session(experiment_id, artifact_path)

    # Start new upload
    return await _start_upload_async(
        file_path,
        artifact_path,
        experiment_id,
        api,
        semaphore,
        progress,
        overall_task,
        checksum,
        file_task,
        stats,
        live,
    )


async def _start_upload_async(
    file_path: Path,
    artifact_path: str,
    experiment_id: str | None,
    api: str,
    semaphore: asyncio.Semaphore,
    progress: Progress,
    overall_task,
    checksum: str,
    file_task,
    stats,
    live,
) -> dict:
    """Start a new upload session asynchronously.

    If experiment_id is None, creates a standalone artifact.
    """
    stat = file_path.stat()
    content_type = _guess_content_type(file_path)

    metadata = {
        "experiment_slug": experiment_id or "standalone",
        "artifact_name": artifact_path,
        "artifact_type": "artifact",
        "tags": [],
        "checksum": checksum,
        "description": f"Uploaded {artifact_path}",
        "file_mtime": stat.st_mtime,
    }

    # Build request payload - only include experiment_id if not standalone
    session_payload: dict = {
        "filename": artifact_path,
        "content_type": content_type,
        "size_bytes": stat.st_size,
        "metadata_document": metadata,
    }
    if experiment_id:
        session_payload["experiment_id"] = experiment_id

    headers = get_auth_headers()
    async with httpx.AsyncClient() as client:
        session_response = await client.post(
            f"{api.rstrip('/')}/api/uploads/session",
            headers=headers,
            json=session_payload,
            timeout=15,
        )
        session_response.raise_for_status()

    session = session_response.json()
    chunk_size = session["chunk_size"]
    session_id = session["session_id"]

    session_data = {
        "session_id": session_id,
        "file_path": str(file_path),
        "artifact_path": artifact_path,
        "experiment_id": experiment_id,
        "api": api,
        "content_type": content_type,
        "chunk_size": chunk_size,
        "file_size": stat.st_size,
        "checksum": checksum,
        "file_mtime": stat.st_mtime,
    }
    save_upload_session(session_data)

    try:
        parts_payload = await _upload_parts_with_semaphore(
            file_path,
            session["presigned_parts"],
            chunk_size,
            semaphore,
            progress,
            overall_task,
            file_task,
            stats,
            live,
        )

        async with httpx.AsyncClient() as client:
            finalize_response = await client.post(
                f"{api.rstrip('/')}/api/uploads/{session_id}/finalize",
                headers=headers,
                json={
                    "session_id": session_id,
                    "parts": parts_payload,
                    "metadata_document": metadata,
                },
                timeout=30,
            )
            finalize_response.raise_for_status()

        delete_upload_session(experiment_id, artifact_path)
        return finalize_response.json()
    except Exception:
        raise


async def _resume_upload_async(
    session_data: dict,
    api: str,
    semaphore: asyncio.Semaphore,
    progress: Progress,
    overall_task,
    file_task,
    stats,
    live,
) -> dict:
    """Resume an interrupted upload asynchronously."""
    session_id = session_data["session_id"]
    file_path = Path(session_data["file_path"])
    artifact_path = session_data["artifact_path"]
    experiment_id = session_data["experiment_id"]
    chunk_size = session_data["chunk_size"]

    headers = get_auth_headers()
    async with httpx.AsyncClient() as client:
        refresh_response = await client.post(
            f"{api.rstrip('/')}/api/uploads/{session_id}/refresh-urls",
            headers=headers,
            timeout=15,
        )
        refresh_response.raise_for_status()

    refreshed = refresh_response.json()
    parts_to_upload = refreshed.get("presigned_parts", [])

    if parts_to_upload:
        parts_payload = await _upload_parts_with_semaphore(
            file_path,
            parts_to_upload,
            chunk_size,
            semaphore,
            progress,
            overall_task,
            file_task,
            stats,
            live,
        )
    else:
        parts_payload = []

    file_mtime = session_data.get("file_mtime") or file_path.stat().st_mtime
    metadata = {
        "experiment_slug": experiment_id,
        "artifact_name": artifact_path,
        "artifact_type": "artifact",
        "tags": [],
        "checksum": session_data.get("checksum", ""),
        "description": f"Uploaded {artifact_path}",
        "file_mtime": file_mtime,
    }

    async with httpx.AsyncClient() as client:
        finalize_response = await client.post(
            f"{api.rstrip('/')}/api/uploads/{session_id}/finalize",
            headers=headers,
            json={
                "session_id": session_id,
                "parts": parts_payload,
                "metadata_document": metadata,
            },
            timeout=30,
        )
        finalize_response.raise_for_status()

    delete_upload_session(experiment_id, artifact_path)
    return finalize_response.json()


async def _upload_parts_with_semaphore(
    file_path: Path,
    parts: list[dict],
    chunk_size: int,
    semaphore: asyncio.Semaphore,
    progress: Progress,
    overall_task,
    file_task,
    stats,
    live,
) -> list[dict]:
    """Upload parts using shared semaphore for global concurrency control."""
    file_size = file_path.stat().st_size

    async def upload_part(part: dict) -> dict:
        async with semaphore:
            part_number = part["part_number"]
            start = (part_number - 1) * chunk_size
            to_read = min(chunk_size, file_size - start)

            with file_path.open("rb") as f:
                f.seek(start)
                data = f.read(to_read)

            async with httpx.AsyncClient() as client:
                result = await _upload_part(
                    client, part["url"], part.get("headers", {}), data, part_number
                )
            progress.advance(overall_task, to_read)
            if file_task is not None:
                progress.advance(file_task, to_read)
            stats.total_uploaded += to_read
            if live:
                live.update(
                    Panel.fit(
                        stats.get_table(),
                        title="📊 Upload Progress",
                        border_style="blue",
                    )
                )
            return result

    tasks = [upload_part(part) for part in parts]
    results = await asyncio.gather(*tasks)
    return sorted(results, key=lambda x: x["part_number"])


def _upload_single_file(
    file_path: Path,
    artifact_path: str,
    experiment_id: str,
    api: str,
    concurrency: int,
    progress: Progress,
    task_id,
    checksum_cache: dict | None = None,
    skip_dedup: bool = False,
    precomputed_checksum: str | None = None,
    file_task=None,
) -> dict | None:
    """Upload a single file and return the artifact info.

    Automatically detects and resumes partial uploads (like rsync).
    Returns dict with "skipped": True if file was skipped due to deduplication.
    """
    file_size = file_path.stat().st_size
    checksum = precomputed_checksum or compute_checksum(file_path, checksum_cache)

    # Check for existing artifact with same checksum (deduplication)
    if not skip_dedup:
        existing = check_artifact_exists(api, checksum)
        if existing:
            progress.advance(task_id, file_size)
            return {"skipped": True, "existing_artifact": existing}

    # Check for existing partial upload session
    existing_session = load_upload_session(experiment_id, artifact_path)
    if existing_session:
        # Verify file hasn't changed
        if (
            existing_session.get("file_size") == file_size
            and existing_session.get("checksum") == checksum
        ):
            try:
                return _resume_upload(
                    existing_session, api, concurrency, progress, task_id
                )
            except httpx.HTTPStatusError as e:
                if e.response.status_code in (404, 400, 410):
                    # Session expired/invalid - delete local cache and start fresh
                    delete_upload_session(experiment_id, artifact_path)
                    # Fall through to start a new upload
                else:
                    raise
        else:
            # File changed, discard old session
            delete_upload_session(experiment_id, artifact_path)

    # Start new upload
    return _start_new_upload(
        file_path,
        artifact_path,
        experiment_id,
        api,
        concurrency,
        progress,
        task_id,
        checksum,
        file_task,
    )


def _start_new_upload(
    file_path: Path,
    artifact_path: str,
    experiment_id: str,
    api: str,
    concurrency: int,
    progress: Progress,
    task_id,
    checksum: str,
    file_task=None,
) -> dict:
    """Start a new upload session."""
    endpoint = f"{api.rstrip('/')}/api/uploads/session"
    stat = file_path.stat()
    content_type = _guess_content_type(file_path)

    metadata = {
        "experiment_slug": experiment_id,
        "artifact_name": artifact_path,
        "artifact_type": "artifact",
        "tags": [],
        "checksum": checksum,
        "description": f"Uploaded {artifact_path}",
        "file_mtime": stat.st_mtime,
    }

    headers = get_auth_headers()
    session_response = httpx.post(
        endpoint,
        headers=headers,
        json={
            "experiment_id": experiment_id,
            "filename": artifact_path,
            "content_type": content_type,
            "size_bytes": stat.st_size,
            "metadata_document": metadata,
        },
        timeout=15,
    )
    session_response.raise_for_status()

    session = session_response.json()
    chunk_size = session["chunk_size"]
    session_id = session["session_id"]

    # Save session for resume capability
    session_data = {
        "session_id": session_id,
        "file_path": str(file_path),
        "artifact_path": artifact_path,
        "experiment_id": experiment_id,
        "api": api,
        "content_type": content_type,
        "chunk_size": chunk_size,
        "file_size": stat.st_size,
        "checksum": checksum,
        "file_mtime": stat.st_mtime,
    }
    save_upload_session(session_data)

    try:
        parts_payload = asyncio.run(
            _upload_parts_parallel(
                file_path,
                session["presigned_parts"],
                chunk_size,
                concurrency,
                progress,
                task_id,
                file_task,
            )
        )

        finalize_response = httpx.post(
            f"{api.rstrip('/')}/api/uploads/{session_id}/finalize",
            headers=headers,
            json={
                "session_id": session_id,
                "parts": parts_payload,
                "metadata_document": metadata,
            },
            timeout=30,
        )
        finalize_response.raise_for_status()

        # Clean up session file on success
        delete_upload_session(experiment_id, artifact_path)
        return finalize_response.json()
    except Exception:
        # Session file remains for resume
        raise


def _resume_upload(
    session_data: dict,
    api: str,
    concurrency: int,
    progress: Progress,
    task_id,
) -> dict:
    """Resume an interrupted upload from saved session."""
    session_id = session_data["session_id"]
    file_path = Path(session_data["file_path"])
    chunk_size = session_data["chunk_size"]
    checksum = session_data["checksum"]
    experiment_id = session_data["experiment_id"]
    artifact_path = session_data["artifact_path"]

    headers = get_auth_headers()

    # Get fresh presigned URLs for incomplete parts
    refresh_resp = httpx.post(
        f"{api.rstrip('/')}/api/uploads/{session_id}/refresh-urls",
        headers=headers,
        timeout=15,
    )
    refresh_resp.raise_for_status()
    refresh_data = refresh_resp.json()

    presigned_parts = refresh_data.get("presigned_parts", [])

    if presigned_parts:
        asyncio.run(
            _upload_parts_parallel(
                file_path,
                presigned_parts,
                chunk_size,
                concurrency,
                progress,
                task_id,
            )
        )
    else:
        # All parts already uploaded, advance progress
        progress.advance(task_id, file_path.stat().st_size)

    file_mtime = session_data.get("file_mtime") or file_path.stat().st_mtime
    metadata = {
        "experiment_slug": experiment_id,
        "artifact_name": artifact_path,
        "artifact_type": "artifact",
        "tags": [],
        "checksum": checksum,
        "description": f"Uploaded {artifact_path}",
        "file_mtime": file_mtime,
    }

    finalize_response = httpx.post(
        f"{api.rstrip('/')}/api/uploads/{session_id}/finalize",
        headers=headers,
        json={
            "session_id": session_id,
            "parts": [],
            "metadata_document": metadata,
        },
        timeout=30,
    )
    finalize_response.raise_for_status()

    # Clean up session file on success
    delete_upload_session(experiment_id, artifact_path)
    return finalize_response.json()


@app.command()
def upload(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    paths: list[Path] = typer.Argument(..., help="Paths to files or directories"),
    concurrency: int = typer.Option(
        32, "--concurrency", "-c", help="Parallel upload streams (default: 32)"
    ),
    no_cache: bool = typer.Option(False, "--no-cache", help="Disable checksum cache"),
    no_dedup: bool = typer.Option(False, "--no-dedup", help="Disable deduplication"),
    standalone: bool = typer.Option(
        False,
        "--standalone",
        "-s",
        help="Upload without connecting to an experiment (orphaned artifact)",
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Upload files or directories to an experiment with parallel multipart upload.

    Use --standalone to upload artifacts without connecting them to an experiment.
    Standalone artifacts can later be connected to experiments or collections.
    """
    import time

    start_time = time.time()

    api = get_api_base(server)

    # Handle standalone mode - use None for experiment_id internally
    effective_experiment_id: str | None = None if standalone else experiment_id

    if standalone:
        typer.secho(
            "Standalone mode: artifacts will NOT be connected to any experiment",
            fg=typer.colors.YELLOW,
        )

    # Validate and resolve paths
    resolved_paths: list[Path] = []
    for p in paths:
        resolved = p.resolve()
        if not resolved.exists():
            typer.secho(f"Path not found: {p}", fg=typer.colors.RED)
            raise typer.Exit(code=1)
        resolved_paths.append(resolved)

    # Collect files from all paths, tracking base path for artifact naming
    files: list[Path] = []
    base_paths: dict[Path, Path] = {}
    for p in resolved_paths:
        collected = _collect_files(p)
        base = p if p.is_dir() else p.parent
        for f in collected:
            if f not in base_paths:
                files.append(f)
                base_paths[f] = base

    if not files:
        typer.secho("No files found to upload.", fg=typer.colors.YELLOW)
        raise typer.Exit(code=1)

    checksum_cache = None if no_cache else load_checksum_cache()

    # Pre-compute checksums for all files
    file_checksums: dict[Path, str] = {}
    for f in files:
        file_checksums[f] = compute_checksum(f, checksum_cache)

    # Batch check which files already exist on server
    existing_checksums: set[str] = set()
    if not no_dedup:
        existing_checksums = check_artifacts_batch(api, list(file_checksums.values()))

    new_files = []  # Files without existing sessions (use batch)
    resume_files = []  # Files with existing sessions (resume individually)
    skipped_files = []  # Files skipped due to deduplication
    empty_files = []  # 0-byte files (can't use multipart upload)

    for file_path in files:
        base = base_paths[file_path]
        if file_path == base:
            artifact_path = file_path.name
        else:
            artifact_path = str(file_path.relative_to(base))
        checksum = file_checksums[file_path]

        file_size = file_path.stat().st_size
        if file_size == 0:
            empty_files.append(artifact_path)
            continue
        if checksum in existing_checksums:
            skipped_files.append((artifact_path, file_size))
        else:
            # Check if we have a resume session
            session = load_upload_session(effective_experiment_id, artifact_path)
            if session:
                resume_files.append((file_path, artifact_path, checksum))
            else:
                new_files.append((file_path, artifact_path, checksum))

    files_to_upload = new_files + resume_files  # Combined for display
    resumed_files = [(ap, fp.stat().st_size) for fp, ap, _ in resume_files]

    skipped_size = sum(size for _, size in skipped_files)
    resumed_size = sum(size for _, size in resumed_files)
    upload_size = sum(f.stat().st_size for f, _, _ in files_to_upload)

    total_files = len(files)
    upload_files_count = len(files_to_upload)
    skipped_count = len(skipped_files)
    resumed_count = len(resumed_files)
    empty_count = len(empty_files)

    # Display upload plan
    if upload_files_count > 0 or empty_count > 0:
        upload_size_mb = upload_size / (1024 * 1024)
        resumed_size_mb = resumed_size / (1024 * 1024)
        skipped_size_mb = skipped_size / (1024 * 1024)

        for p in resolved_paths:
            typer.echo(f"📁 {p}")
        typer.echo(
            f"📊 {total_files} file(s), {upload_size_mb + resumed_size_mb + skipped_size_mb:.1f} MB total"
        )
        if upload_files_count > 0:
            typer.echo(
                f"⬆️  Upload: {upload_files_count} file(s), {upload_size_mb:.1f} MB"
            )
        if resumed_count > 0:
            typer.echo(f"🔄 Resume: {resumed_count} file(s), {resumed_size_mb:.1f} MB")
        if skipped_count > 0:
            typer.echo(
                f"⏭️  Skip: {skipped_count} file(s), {skipped_size_mb:.1f} MB (deduplicated)"
            )
        if empty_count > 0:
            typer.echo(f"📄 Empty: {empty_count} file(s) (skipped)")
        typer.echo()

    if not files_to_upload and not resumed_files:
        if skipped_files:
            typer.secho(
                "✓ All files already exist on server (deduplicated)",
                fg=typer.colors.GREEN,
            )
        else:
            typer.secho("No files to upload.", fg=typer.colors.YELLOW)
        return

    # Enhanced progress display
    from rich.live import Live
    from rich.table import Table
    from rich.panel import Panel

    # Check if we're in a test environment (captured output)
    is_test_env = hasattr(sys.stdout, "getvalue") or os.environ.get(
        "PYTEST_CURRENT_TEST"
    )

    class UploadStats:
        def __init__(self):
            self.active_uploads = 0
            self.completed_files = 0
            self.failed_files = 0
            self.current_file = ""
            self.speed = 0.0
            self.total_uploaded = 0
            self.start_time = time.time()

        def get_table(self) -> Table:
            table = Table(show_header=False, box=None, pad_edge=False)
            table.add_column("Metric", style="dim", width=12)
            table.add_column("Value", style="bold")

            elapsed = time.time() - self.start_time
            if elapsed > 0:
                avg_speed = self.total_uploaded / elapsed / (1024 * 1024)  # MB/s
            else:
                avg_speed = 0

            table.add_row("Active", f"{self.active_uploads}/{concurrency}")
            table.add_row("Completed", f"{self.completed_files}")
            table.add_row(
                "Failed", f"{self.failed_files}" if self.failed_files else "-"
            )
            table.add_row(
                "Current",
                self.current_file[:30] + "..."
                if len(self.current_file) > 30
                else self.current_file,
            )
            table.add_row("Speed", f"{avg_speed:.1f} MB/s")
            table.add_row("Elapsed", f"{elapsed:.1f}s")

            return table

    stats = UploadStats()

    failed_uploads: list[tuple[str, str]] = []
    completed_count = 0
    results = []

    if is_test_env:
        # Simple progress for tests
        progress_bar = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=console,
        )
        with progress_bar:
            overall_task = progress_bar.add_task(
                "[cyan]Total", total=upload_size + resumed_size, completed=0
            )
            # Use batch upload for new files (reduces HTTP requests from 2N+1 to 3)
            if new_files:
                batch_results = asyncio.run(
                    _upload_files_batch(
                        new_files,
                        effective_experiment_id,
                        api,
                        concurrency,
                        progress_bar,
                        overall_task,
                        stats,
                        None,  # No live display in test mode
                    )
                )
                results.extend(batch_results)
            # Resume files individually (they already have sessions)
            if resume_files:
                resume_results = asyncio.run(
                    _upload_files_concurrent_with_stats(
                        resume_files,
                        effective_experiment_id,
                        api,
                        concurrency,
                        progress_bar,
                        overall_task,
                        checksum_cache,
                        stats,
                        None,  # No live display in test mode
                    )
                )
                results.extend(resume_results)
            for artifact_path, result, error in results:
                if error:
                    failed_uploads.append((artifact_path, error))
                else:
                    completed_count += 1
    else:
        # Enhanced display for interactive use
        progress_bar = Progress(
            TextColumn("[progress.description]{task.description}"),
            BarColumn(complete_style="green"),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=console,
            expand=True,
        )

        overall_progress = progress_bar.add_task(
            f"[cyan]Total Progress ({upload_files_count + resumed_count} files)",
            total=upload_size + resumed_size,
            completed=0,
        )

        def create_display():
            return Panel.fit(
                stats.get_table(), title="📊 Upload Progress", border_style="blue"
            )

        try:
            display_panel = create_display()

            with progress_bar:
                with Live(display_panel, console=console, refresh_per_second=4) as live:
                    # Use batch upload for new files (reduces HTTP requests)
                    if new_files:
                        batch_results = asyncio.run(
                            _upload_files_batch(
                                new_files,
                                effective_experiment_id,
                                api,
                                concurrency,
                                progress_bar,
                                overall_progress,
                                stats,
                                live,
                            )
                        )
                        results.extend(batch_results)
                    # Resume files individually (they already have sessions)
                    if resume_files:
                        resume_results = asyncio.run(
                            _upload_files_concurrent_with_stats(
                                resume_files,
                                effective_experiment_id,
                                api,
                                concurrency,
                                progress_bar,
                                overall_progress,
                                checksum_cache,
                                stats,
                                live,
                            )
                        )
                        results.extend(resume_results)
                    for artifact_path, result, error in results:
                        if error:
                            failed_uploads.append((artifact_path, error))
                        else:
                            completed_count += 1
        except Exception:
            # Fall back to simple progress display if Live fails
            progress_bar = Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                DownloadColumn(),
                TransferSpeedColumn(),
                TimeRemainingColumn(),
                console=console,
            )
            with progress_bar:
                overall_task = progress_bar.add_task(
                    "[cyan]Total", total=upload_size + resumed_size, completed=0
                )
                results = []  # Reset for fallback
                # Use batch upload for new files
                if new_files:
                    batch_results = asyncio.run(
                        _upload_files_batch(
                            new_files,
                            effective_experiment_id,
                            api,
                            concurrency,
                            progress_bar,
                            overall_task,
                            stats,
                            None,
                        )
                    )
                    results.extend(batch_results)
                # Resume files individually
                if resume_files:
                    resume_results = asyncio.run(
                        _upload_files_concurrent_with_stats(
                            resume_files,
                            effective_experiment_id,
                            api,
                            concurrency,
                            progress_bar,
                            overall_task,
                            checksum_cache,
                            stats,
                            None,
                        )
                    )
                    results.extend(resume_results)
                for artifact_path, result, error in results:
                    if error:
                        failed_uploads.append((artifact_path, error))
                    else:
                        completed_count += 1

    if checksum_cache is not None:
        save_checksum_cache(None, checksum_cache)

    # Final summary
    elapsed_time = time.time() - start_time
    total_processed = completed_count + len(skipped_files) + len(resumed_files)

    if elapsed_time > 0:
        avg_speed = (upload_size + resumed_size) / elapsed_time / (1024 * 1024)  # MB/s
    else:
        avg_speed = 0

    typer.echo()
    typer.secho("📋 Upload Summary", fg=typer.colors.BLUE, bold=True)

    if completed_count > 0:
        typer.secho(f"✓ Uploaded: {completed_count} file(s)", fg=typer.colors.GREEN)

    if resumed_files:
        resumed_size_mb = resumed_size / (1024 * 1024)
        typer.secho(
            f"🔄 Resumed: {len(resumed_files)} file(s), {resumed_size_mb:.1f} MB",
            fg=typer.colors.YELLOW,
        )

    if skipped_files:
        skipped_size_mb = skipped_size / (1024 * 1024)
        typer.secho(
            f"⏭️  Skipped: {len(skipped_files)} file(s), {skipped_size_mb:.1f} MB (deduplicated)",
            fg=typer.colors.CYAN,
        )

    if failed_uploads:
        typer.secho(f"✗ Failed: {len(failed_uploads)} file(s)", fg=typer.colors.RED)
        for name, err in failed_uploads:
            typer.echo(f"  {name}: {err}")
        raise typer.Exit(code=1)

    total_size_mb = (upload_size + resumed_size + skipped_size) / (1024 * 1024)
    typer.secho(
        f"⏱️  Time: {elapsed_time:.1f}s | Speed: {avg_speed:.1f} MB/s | Total: {total_processed} file(s), {total_size_mb:.1f} MB",
        fg=typer.colors.GREEN,
    )


@app.command()
def download(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    artifact_path: str = typer.Argument(..., help="Artifact path/name"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file path"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Download an artifact from an experiment."""
    api = get_api_base(server)

    headers = get_auth_headers()

    try:
        exp_response = httpx.get(
            f"{api.rstrip('/')}/api/experiments/{experiment_id}",
            headers=headers,
            timeout=10,
        )
        exp_response.raise_for_status()
        experiment = exp_response.json()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to retrieve experiment: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    artifact = None
    for art in experiment.get("artifacts", []):
        if art.get("name") == artifact_path or art.get("id") == artifact_path:
            artifact = art
            break

    if not artifact:
        typer.secho(f"Artifact not found: {artifact_path}", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    try:
        download_response = httpx.get(
            f"{api.rstrip('/')}/api/artifacts/{artifact['id']}/download",
            headers=headers,
            follow_redirects=True,
            timeout=300,
        )
        download_response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Download failed: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    output_path = output or Path(artifact.get("name", "download"))
    output_path.write_bytes(download_response.content)
    typer.secho(f"✓ Downloaded to: {output_path}", fg=typer.colors.GREEN)


@app.command()
def activity(
    limit: int = typer.Option(20, "--limit", "-n", help="Number of recent activities"),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """View recent activity."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/activity"

    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to retrieve activity: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    activities = response.json()[:limit]

    if format in ["json", "yaml"]:
        typer.echo(format_output(activities, format))
        return

    if not activities:
        typer.echo("No recent activity.")
        return

    if format == "tree":

        def render_tree_page(page: list) -> None:
            console.print(render_activity_tree(page))

        paginate_results(activities, render_tree_page)
    else:

        def render_table_page(page: list) -> None:
            table = Table(show_lines=False, show_header=True)
            table.add_column("Time", style="dim")
            table.add_column("Actor")
            table.add_column("Action", style="cyan")
            table.add_column("Resource")

            for act in page:
                table.add_row(
                    act.get("timestamp", "")[:19],
                    act.get("actor", "System"),
                    act.get("action", ""),
                    f"{act.get('resource_type', '')}/{act.get('resource_id', '')}",
                )

            console.print(table)

        paginate_results(activities, render_table_page)


@metadata_app.command("get")
def metadata_get(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    format: str = typer.Option(
        "table", "--format", help="Output format: table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Get metadata for an experiment."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{experiment_id}/metadata"

    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to retrieve metadata: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    metadata = response.json()

    if format in ["json", "yaml"]:
        typer.echo(format_output(metadata, format))
        return

    if not metadata:
        typer.echo("No metadata set for this experiment.")
        return

    table = Table(title=f"Metadata for {experiment_id}")
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    for key, value in metadata.items():
        table.add_row(key, str(value))

    console.print(table)


@metadata_app.command("set")
def metadata_set(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    field_key: str = typer.Argument(..., help="Metadata field key"),
    field_value: str = typer.Argument(..., help="Metadata field value"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Set a metadata field for an experiment."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{experiment_id}/metadata"

    try:
        response = httpx.patch(
            endpoint,
            headers=get_auth_headers(),
            json={"metadata": {field_key: field_value}},
            timeout=10,
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to set metadata: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(
        f"✓ Metadata field '{field_key}' set to '{field_value}'", fg=typer.colors.GREEN
    )


@metadata_app.command("apply")
def metadata_apply(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    file: Path = typer.Option(
        ..., "--file", "-f", help="Path to metadata JSON/YAML file"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Set multiple metadata fields from a file."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{experiment_id}/metadata"

    try:
        if file.suffix in [".yaml", ".yml"]:
            import yaml

            metadata = yaml.safe_load(file.read_text())
        else:
            metadata = json.loads(file.read_text())
    except (json.JSONDecodeError, Exception) as exc:
        typer.secho(f"Invalid metadata file: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    try:
        response = httpx.patch(
            endpoint,
            headers=get_auth_headers(),
            json={"metadata": metadata},
            timeout=10,
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to set metadata: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"✓ Applied {len(metadata)} metadata field(s)", fg=typer.colors.GREEN)


@metadata_app.command("fields")
def metadata_fields(
    format: str = typer.Option(
        "table", "--format", help="Output format: table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List available metadata field definitions."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/admin/metadata-fields"

    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to retrieve metadata fields: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    fields = response.json()

    if format in ["json", "yaml"]:
        typer.echo(format_output(fields, format))
        return

    if not fields:
        typer.echo("No metadata fields defined.")
        return

    table = Table(title="Metadata Field Definitions")
    table.add_column("Key", style="cyan")
    table.add_column("Display Name", style="bold")
    table.add_column("Type")
    table.add_column("Required", justify="center")
    table.add_column("Unit")

    for field in fields:
        table.add_row(
            field.get("key", ""),
            field.get("display_name", ""),
            field.get("field_type", ""),
            "✓" if field.get("required") else "—",
            field.get("unit", "") or "—",
        )

    console.print(table)


@auth_app.command("login")
def auth_login(
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
    client_id: str | None = typer.Option(
        None,
        "--client-id",
        help="GitHub OAuth client ID (auto-detected from environment)",
    ),
) -> None:
    """Authenticate with GitHub using device flow."""
    api = get_api_base(server)
    if not client_id:
        client_id = get_github_client_id(api)
        typer.echo(f"Using GitHub OAuth app for: {api}")

    try:
        device_response = httpx.post(
            "https://github.com/login/device/code",
            data={"client_id": client_id, "scope": "read:org"},
            headers={"Accept": "application/json"},
            timeout=15,
        )
        device_response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to initiate device flow: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    device_data = device_response.json()
    device_code = device_data.get("device_code")
    user_code = device_data.get("user_code")
    verification_uri = device_data.get("verification_uri")
    interval = device_data.get("interval", 5)
    expires_in = device_data.get("expires_in", 900)

    if not all([device_code, user_code, verification_uri]):
        typer.secho("Invalid device flow response from GitHub.", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    typer.echo("\n" + "=" * 60)
    typer.secho(f"Visit: {verification_uri}", fg=typer.colors.BRIGHT_CYAN, bold=True)
    typer.secho(f"Enter code: {user_code}", fg=typer.colors.BRIGHT_YELLOW, bold=True)
    typer.echo("=" * 60 + "\n")
    typer.echo(f"Waiting for authorization (expires in {expires_in}s)...")

    start_time = time.time()
    while time.time() - start_time < expires_in:
        time.sleep(interval)

        try:
            token_response = httpx.post(
                "https://github.com/login/oauth/access_token",
                data={
                    "client_id": client_id,
                    "device_code": device_code,
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                },
                headers={"Accept": "application/json"},
                timeout=15,
            )
            token_response.raise_for_status()
        except httpx.HTTPError as exc:
            typer.secho(f"Polling error: {exc}", fg=typer.colors.RED)
            continue

        token_data = token_response.json()

        if "error" in token_data:
            error = token_data["error"]
            if error == "authorization_pending":
                continue
            if error == "slow_down":
                interval += 5
                continue
            if error in {"expired_token", "access_denied"}:
                typer.secho(
                    f"Authorization {error.replace('_', ' ')}.", fg=typer.colors.RED
                )
                raise typer.Exit(code=1)
            typer.secho(f"GitHub error: {error}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

        access_token = token_data.get("access_token")
        if not access_token:
            typer.secho("No access token received from GitHub.", fg=typer.colors.RED)
            raise typer.Exit(code=1)

        config = load_config()
        config["github_token"] = access_token
        save_config(config)

        typer.secho("\n✓ Authentication successful!", fg=typer.colors.GREEN)
        typer.echo(f"  Token stored in {CONFIG_FILE}")
        return

    typer.secho("\nAuthorization timed out. Please try again.", fg=typer.colors.RED)
    raise typer.Exit(code=1)


@auth_app.command("status")
def auth_status(
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Show authentication status and app health."""
    api = get_api_base(server)
    config = load_config()

    # Check API health
    typer.secho("\n=== App Health ===", bold=True)
    try:
        health_response = httpx.get(f"{api.rstrip('/')}/healthz", timeout=5)
        if health_response.status_code == 200:
            typer.secho(f"✓ API responding at {api}", fg=typer.colors.GREEN)
        else:
            typer.secho(
                f"⚠ API returned status {health_response.status_code}",
                fg=typer.colors.YELLOW,
            )
    except httpx.HTTPError as exc:
        typer.secho(f"✗ API unreachable: {exc}", fg=typer.colors.RED)
        return

    # Show GitHub OAuth Client ID
    client_id = get_github_client_id(api)
    typer.echo(f"  GitHub OAuth Client ID: {client_id}")

    # Check authentication
    typer.secho("\n=== Authentication ===", bold=True)

    if api_key_env := os.environ.get("DIFFUSE_API_KEY"):
        typer.secho("✓ API key set via DIFFUSE_API_KEY", fg=typer.colors.GREEN)
        typer.echo(f"  Prefix: {api_key_env[:8]}...")
        try:
            resp = httpx.get(
                f"{api.rstrip('/')}/api/api-keys/personal",
                headers={"Authorization": f"Bearer {api_key_env}"},
                timeout=10,
            )
            if resp.is_success:
                typer.secho("  ✓ API key is valid", fg=typer.colors.GREEN)
            else:
                typer.secho(
                    f"  ✗ API key rejected (status {resp.status_code})",
                    fg=typer.colors.RED,
                )
        except httpx.HTTPError as exc:
            typer.secho(f"  ✗ Could not validate key: {exc}", fg=typer.colors.YELLOW)
        return

    if api_key := config.get("api_key"):
        typer.secho("✓ API key configured", fg=typer.colors.GREEN)
        typer.echo(f"  Prefix: {api_key[:8]}...")
        try:
            resp = httpx.get(
                f"{api.rstrip('/')}/api/api-keys/personal",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=10,
            )
            if resp.is_success:
                typer.secho("  ✓ API key is valid", fg=typer.colors.GREEN)
            else:
                typer.secho(
                    f"  ✗ API key rejected (status {resp.status_code})",
                    fg=typer.colors.RED,
                )
        except httpx.HTTPError as exc:
            typer.secho(f"  ✗ Could not validate key: {exc}", fg=typer.colors.YELLOW)
        return

    if "github_token" not in config:
        typer.secho("✗ Not logged in", fg=typer.colors.YELLOW)
        typer.echo("  Run 'diffuse auth login' to authenticate")
        typer.echo("  Or set an API key with 'diffuse keys set <key>'")
        return

    typer.secho("✓ Token found", fg=typer.colors.GREEN)

    # Try to get user info
    try:
        headers = get_auth_headers()
        user_response = httpx.get(
            "https://api.github.com/user",
            headers={"Authorization": headers.get("Authorization", "")},
            timeout=10,
        )
        user_response.raise_for_status()
        gh_user = user_response.json()

        typer.echo(f"  GitHub user: {gh_user.get('login')}")
        if name := gh_user.get("name"):
            typer.echo(f"  Name: {name}")

        # Try to get team memberships (requires read:org scope)
        try:
            teams_response = httpx.get(
                "https://api.github.com/user/teams",
                headers={"Authorization": headers.get("Authorization", "")},
                timeout=10,
            )
            teams_response.raise_for_status()
            teams = teams_response.json()

            typer.echo(f"\n  Teams ({len(teams)}):")
            for team in teams[:5]:  # Show first 5 teams
                # Build nested team path (same logic as backend)
                slugs = []
                current = team
                while current:
                    slug = str(current.get("slug", "")).lower()
                    if slug:
                        slugs.insert(0, slug)
                    current = (
                        current.get("parent")
                        if isinstance(current.get("parent"), dict)
                        else None
                    )
                team_path = "/".join(slugs)
                team_name = team.get("name", team.get("slug", ""))
                typer.echo(f"    • {team_path} ({team_name})")
            if len(teams) > 5:
                typer.echo(f"    ... and {len(teams) - 5} more")
        except httpx.HTTPError:
            typer.secho(
                "\n  ⚠ Team membership unavailable (token lacks 'read:org' scope)",
                fg=typer.colors.YELLOW,
            )

        # Try to get Diffuse role
        typer.echo()
        try:
            whoami_response = httpx.get(
                f"{api.rstrip('/')}/api/whoami", headers=headers, timeout=10
            )
            whoami_response.raise_for_status()
            whoami = whoami_response.json()

            role = whoami.get("role", "unknown")
            typer.secho(
                f"  Diffuse role: {role.upper()}", fg=typer.colors.CYAN, bold=True
            )
            if primary_team := whoami.get("primary_team"):
                typer.echo(f"  Primary team: {primary_team}")

        except httpx.HTTPError:
            typer.secho("  ⚠ Could not determine Diffuse role", fg=typer.colors.YELLOW)
            typer.echo("    Token may not have required permissions")

    except httpx.HTTPError as exc:
        typer.secho(f"✗ Token validation failed: {exc}", fg=typer.colors.RED)
        typer.echo("  Token may be expired or invalid")
        typer.echo("  Run 'diffuse auth login' to re-authenticate")


@auth_app.command("logout")
def auth_logout() -> None:
    """Clear stored authentication credentials."""
    config = load_config()
    was_logged_in = "github_token" in config

    config.pop("github_token", None)
    save_config(config)

    if was_logged_in:
        typer.secho("✓ Logged out", fg=typer.colors.GREEN)
    else:
        typer.echo("Not logged in.")


@config_app.command("view")
def config_view() -> None:
    """View CLI configuration."""
    config = load_config()
    if not config:
        typer.echo("No configuration found.")
        return

    table = Table(title="Configuration")
    table.add_column("Key", style="cyan")
    table.add_column("Value")

    for key, value in config.items():
        if key == "github_token":
            display_value = "***" + value[-4:] if len(value) > 4 else "***"
        else:
            display_value = value
        table.add_row(key, display_value)

    console.print(table)


@config_app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Configuration key"),
    value: str = typer.Argument(..., help="Configuration value"),
) -> None:
    """Set a configuration value."""
    config = load_config()
    config[key] = value
    save_config(config)
    typer.secho(f"✓ Configuration updated: {key}", fg=typer.colors.GREEN)


@config_app.command("reset")
def config_reset(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Reset CLI configuration."""
    if not yes:
        confirm = typer.confirm("Reset all configuration?")
        if not confirm:
            raise typer.Abort()

    CONFIG_FILE.unlink(missing_ok=True)
    typer.secho("✓ Configuration reset", fg=typer.colors.GREEN)


@config_app.command("env")
def config_env(
    environment: str | None = typer.Argument(
        None, help="Environment to set (local, staging, prod) or custom URL"
    ),
    list_envs: bool = typer.Option(
        False, "--list", "-l", help="List available environments"
    ),
) -> None:
    """Set the target environment for API calls."""
    if list_envs:
        table = Table(title="Available Environments")
        table.add_column("Name", style="cyan")
        table.add_column("URL", style="bold")
        table.add_column("Current", justify="center")

        config = load_config()
        current_api_url = config.get("api_url")

        for env_name, env_url in ENV_URLS.items():
            is_current = current_api_url == env_url
            table.add_row(env_name, env_url, "✓" if is_current else "")

        console.print(table)
        typer.echo(
            "\nYou can also set DIFFUSE_ENV or DIFFUSE_API_URL environment variables."
        )
        typer.echo(
            "Priority: --server flag > DIFFUSE_API_URL env var > DIFFUSE_ENV env var > config > default"
        )
        return

    if not environment:
        api_url = get_api_base(None)

        if env_var := os.getenv("DIFFUSE_API_URL"):
            typer.secho(
                f"Current environment (DIFFUSE_API_URL): {env_var}",
                fg=typer.colors.CYAN,
            )
        elif env_name := os.getenv("DIFFUSE_ENV"):
            typer.secho(
                f"Current environment (DIFFUSE_ENV={env_name}): {api_url}",
                fg=typer.colors.CYAN,
            )
        elif config := load_config().get("api_url"):
            typer.secho(f"Current environment (config): {config}", fg=typer.colors.CYAN)
        else:
            typer.echo(f"Using default: {api_url}")
            typer.echo("Run 'diffuse config env --list' to see available environments.")
        return

    if environment in ENV_URLS:
        api_url = ENV_URLS[environment]
        typer.echo(f"Setting environment to: {environment} ({api_url})")
    elif environment.startswith("http://") or environment.startswith("https://"):
        api_url = environment
        typer.echo(f"Setting custom API URL: {api_url}")
    else:
        typer.secho(
            f"Unknown environment: {environment}",
            fg=typer.colors.RED,
        )
        typer.echo("Available environments: local, staging, prod")
        typer.echo("Or provide a custom URL starting with http:// or https://")
        raise typer.Exit(code=1)

    config = load_config()
    config["api_url"] = api_url
    save_config(config)
    typer.secho(f"✓ Environment set to: {api_url}", fg=typer.colors.GREEN)


@artifacts_app.command("list")
def artifacts_list(
    experiment: str | None = typer.Option(
        None, "--experiment", "-e", help="Filter by experiment ID"
    ),
    orphaned: bool = typer.Option(
        False, "--orphaned", help="Show only orphaned artifacts (no connections)"
    ),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List all artifacts with optional filtering."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/artifacts"

    params = {}
    if experiment:
        params["experiment_id"] = experiment
    if orphaned:
        params["orphaned"] = "true"

    try:
        response = httpx.get(
            endpoint, headers=get_auth_headers(), params=params, timeout=30
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to list artifacts: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    artifacts = response.json()

    if format in ["json", "yaml"]:
        console.print(format_output(artifacts, format))
        return

    if not artifacts:
        typer.secho("No artifacts found.", fg=typer.colors.YELLOW)
        return

    if format == "tree":

        def render_tree_page(page: list) -> None:
            console.print(render_artifacts_tree(page))

        paginate_results(artifacts, render_tree_page)
    else:

        def render_table_page(page: list) -> None:
            table = Table(show_lines=False, show_header=True)
            table.add_column("ID", style="cyan", no_wrap=True)
            table.add_column("Name")
            table.add_column("Type")
            table.add_column("Size")
            table.add_column("Connections")

            for artifact in page:
                size_mb = artifact.get("size_bytes", 0) / (1024 * 1024)
                conn_count = len(artifact.get("experiments", []))
                table.add_row(
                    artifact["id"][:8] + "...",
                    artifact["name"],
                    artifact["artifact_type"],
                    f"{size_mb:.2f} MB",
                    str(conn_count),
                )

            console.print(table)

        paginate_results(artifacts, render_table_page)


@artifacts_app.command("info")
def artifacts_info(
    artifact_id: str = typer.Argument(..., help="Artifact ID"),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Show detailed information about an artifact including connections."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/artifacts/{artifact_id}"

    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=30)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to get artifact info: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    artifact = response.json()

    if format in ["json", "yaml"]:
        console.print(format_output(artifact, format))
        return

    if format == "tree":
        console.print(render_artifact_detail_tree(artifact))
        return

    # Table format
    table = Table(show_header=False, box=None)
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("Name", artifact["name"])
    table.add_row("ID", artifact["id"])
    table.add_row("Type", artifact["artifact_type"])
    table.add_row("Size", f"{artifact['size_bytes'] / (1024 * 1024):.2f} MB")
    table.add_row("Status", artifact["status"])
    console.print(table)

    experiments = artifact.get("experiments", [])
    if experiments:
        exp_table = Table(title=f"Connected Experiments ({len(experiments)})")
        exp_table.add_column("ID", style="cyan")
        exp_table.add_column("Title")
        for exp in experiments:
            exp_table.add_row(exp["display_id"], exp["title"])
        console.print(exp_table)
    else:
        typer.secho("\n⚠ Not connected to any experiments", fg=typer.colors.YELLOW)


@artifacts_app.command("connect")
def artifacts_connect(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    artifact_ids: list[str] = typer.Argument(
        None, help="Artifact ID(s) or S3 key(s) when --bucket is used"
    ),
    path: str | None = typer.Option(
        None, "--path", help="Custom artifact path (single artifact, no --bucket)"
    ),
    bucket: str | None = typer.Option(
        None, "--bucket", "-b", help="External bucket name (args become S3 keys)"
    ),
    prefix: str | None = typer.Option(
        None, "--prefix", help="Attach all files under this prefix (requires --bucket)"
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation (--bucket)"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Connect artifacts to an experiment.

    Without --bucket, connects internal artifacts by ID.
    With --bucket, links external S3 artifacts without copying data.

    Examples:

        diffuse artifacts connect EXP-1 artifact-1 artifact-2

        diffuse artifacts connect EXP-1 data/scan.h5 --bucket osn-chess

        diffuse artifacts connect EXP-1 --bucket osn-chess --prefix data/2024/
    """
    if prefix and not bucket:
        typer.secho("--prefix requires --bucket", fg=typer.colors.RED)
        raise typer.Exit(code=1)
    if path and bucket:
        typer.secho("--path cannot be used with --bucket", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    api = get_api_base(server)
    headers = get_auth_headers()

    if bucket:
        if prefix:
            resolved_keys = _resolve_external_prefix(api, headers, bucket, prefix)
            if not resolved_keys:
                typer.secho(
                    f"No files found under prefix '{prefix}'",
                    fg=typer.colors.YELLOW,
                )
                return
            artifacts_payload = [{"s3_key": k} for k in resolved_keys]
        else:
            if not artifact_ids:
                typer.secho(
                    "Provide S3 key(s) as arguments or use --prefix",
                    fg=typer.colors.RED,
                )
                raise typer.Exit(code=1)
            artifacts_payload = [{"s3_key": k} for k in artifact_ids]

        count = len(artifacts_payload)
        if not yes:
            confirm = typer.confirm(
                f"Attach {count} external artifact(s) from '{bucket}' to {experiment_id}?"
            )
            if not confirm:
                raise typer.Abort()

        try:
            response = httpx.post(
                f"{api.rstrip('/')}/api/external-artifacts/batch-attach",
                headers=headers,
                json={
                    "experiment_id": experiment_id,
                    "bucket_name": bucket,
                    "artifacts": artifacts_payload,
                },
                timeout=120,
            )
            response.raise_for_status()
            result = response.json()
        except httpx.HTTPError as exc:
            typer.secho(
                f"Failed to attach external artifacts: {exc}", fg=typer.colors.RED
            )
            raise typer.Exit(code=1) from exc

        attached = result.get("attached", 0)
        typer.secho(
            f"Attached {attached} external artifact(s) to {experiment_id}",
            fg=typer.colors.GREEN,
        )
        return

    if not artifact_ids:
        typer.secho("Provide at least one artifact ID", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    if len(artifact_ids) == 1:
        endpoint = f"{api.rstrip('/')}/api/artifacts/connect"
        params = {
            "experiment_id": experiment_id,
            "artifact_id": artifact_ids[0],
        }
        if path:
            params["artifact_path"] = path

        try:
            response = httpx.post(endpoint, headers=headers, params=params, timeout=30)
            response.raise_for_status()
        except httpx.HTTPError as exc:
            typer.secho(f"Failed to connect artifact: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc

        typer.secho(
            f"Artifact {artifact_ids[0]} connected to {experiment_id}",
            fg=typer.colors.GREEN,
        )
    else:
        endpoint = f"{api.rstrip('/')}/api/artifacts/batch-connect"
        try:
            response = httpx.post(
                endpoint,
                headers=headers,
                json={"experiment_id": experiment_id, "artifact_ids": artifact_ids},
                timeout=60,
            )
            response.raise_for_status()
            result = response.json()
        except httpx.HTTPError as exc:
            typer.secho(f"Failed to connect artifacts: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc

        typer.secho(
            f"Connected {result.get('connected', 0)} artifact(s) to {experiment_id}",
            fg=typer.colors.GREEN,
        )


@artifacts_app.command("disconnect")
def artifacts_disconnect(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    artifact_ids: list[str] = typer.Argument(..., help="Artifact ID(s) to disconnect"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Disconnect one or more artifacts from an experiment."""
    api = get_api_base(server)

    if len(artifact_ids) == 1:
        endpoint = f"{api.rstrip('/')}/api/artifacts/disconnect"
        params = {
            "experiment_id": experiment_id,
            "artifact_id": artifact_ids[0],
        }

        try:
            response = httpx.post(
                endpoint, headers=get_auth_headers(), params=params, timeout=30
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            typer.secho(f"Failed to disconnect artifact: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc

        typer.secho(
            f"Artifact {artifact_ids[0]} disconnected from {experiment_id}",
            fg=typer.colors.GREEN,
        )
    else:
        endpoint = f"{api.rstrip('/')}/api/artifacts/batch-disconnect"
        try:
            response = httpx.post(
                endpoint,
                headers=get_auth_headers(),
                json={"experiment_id": experiment_id, "artifact_ids": artifact_ids},
                timeout=60,
            )
            response.raise_for_status()
            result = response.json()
        except httpx.HTTPError as exc:
            typer.secho(f"Failed to disconnect artifacts: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc

        typer.secho(
            f"Disconnected {result.get('disconnected', 0)}, "
            f"deleted {result.get('deleted', 0)} artifact(s)",
            fg=typer.colors.GREEN,
        )


@artifacts_app.command("delete")
def artifacts_delete(
    artifact_id: str = typer.Argument(..., help="Artifact ID to delete"),
    force: bool = typer.Option(
        False, "--force", help="Force delete even if connected to experiments"
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Delete an artifact (only if not connected to any experiments)."""
    if not yes:
        confirm = typer.confirm(f"Delete artifact {artifact_id}?")
        if not confirm:
            raise typer.Abort()

    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/artifacts/{artifact_id}"

    params = {}
    if force:
        params["force"] = "true"

    try:
        response = httpx.delete(
            endpoint, headers=get_auth_headers(), params=params, timeout=30
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        if "still connected" in str(exc).lower():
            typer.secho(
                "✗ Cannot delete: artifact is still connected to experiments. "
                "Use 'disconnect' first or --force to override.",
                fg=typer.colors.RED,
            )
        else:
            typer.secho(f"Failed to delete artifact: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"✓ Artifact {artifact_id} deleted", fg=typer.colors.GREEN)


@artifacts_app.command("purge")
def artifacts_purge(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Disconnect and delete all artifacts from an experiment."""
    api = get_api_base(server)

    # Get artifacts for this experiment
    try:
        response = httpx.get(
            f"{api.rstrip('/')}/api/artifacts",
            headers=get_auth_headers(),
            params={"experiment_id": experiment_id},
            timeout=30,
        )
        response.raise_for_status()
        artifacts = response.json()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to list artifacts: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    if not artifacts:
        typer.echo("No artifacts to purge")
        return

    if not yes:
        confirm = typer.confirm(
            f"Disconnect and delete {len(artifacts)} artifact(s) from {experiment_id}?"
        )
        if not confirm:
            raise typer.Abort()

    artifact_ids = [a["id"] for a in artifacts]

    # Batch disconnect and delete
    try:
        response = httpx.post(
            f"{api.rstrip('/')}/api/artifacts/batch-disconnect",
            headers=get_auth_headers(),
            json={"experiment_id": experiment_id, "artifact_ids": artifact_ids},
            timeout=60,
        )
        response.raise_for_status()
        result = response.json()
        typer.secho(
            f"✓ Disconnected {result.get('disconnected', 0)}, "
            f"deleted {result.get('deleted', 0)} artifact(s)",
            fg=typer.colors.GREEN,
        )
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to purge artifacts: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc


def _format_file_size(size: int) -> str:
    """Human-readable file size."""
    if size >= 1024 * 1024 * 1024:
        return f"{size / 1024 / 1024 / 1024:.1f} GB"
    if size >= 1024 * 1024:
        return f"{size / 1024 / 1024:.1f} MB"
    if size >= 1024:
        return f"{size / 1024:.1f} KB"
    return f"{size} B"


@artifacts_app.command("buckets")
def artifacts_buckets(
    format: str = typer.Option(
        "table", "--format", "-f", help="Output format: table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List configured external buckets (OSN, S3, etc.)."""
    api = get_api_base(server)

    try:
        response = httpx.get(
            f"{api.rstrip('/')}/api/external-buckets",
            headers=get_auth_headers(),
            timeout=30,
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to list external buckets: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    buckets = response.json()

    if format in ["json", "yaml"]:
        console.print(format_output(buckets, format))
        return

    if not buckets:
        typer.secho("No external buckets configured.", fg=typer.colors.YELLOW)
        return

    table = Table(show_lines=False, show_header=True, title="External Buckets")
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Type", style="bold")
    table.add_column("Bucket")
    table.add_column("Public")
    table.add_column("Endpoint")

    for b in buckets:
        table.add_row(
            b["name"],
            b["type"],
            b["bucket"],
            "yes" if b.get("public") else "no",
            b["endpoint_url"],
        )

    console.print(table)


@artifacts_app.command("browse")
def artifacts_browse(
    bucket_name: str = typer.Argument(..., help="External bucket name"),
    prefix: str = typer.Option("", "--prefix", "-p", help="S3 key prefix to browse"),
    refresh: bool = typer.Option(
        False, "--refresh", help="Force refresh (bypass server cache)"
    ),
    format: str = typer.Option(
        "table", "--format", "-f", help="Output format: table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Browse contents of an external bucket."""
    api = get_api_base(server)

    params: dict[str, str] = {}
    if prefix:
        params["prefix"] = prefix
    if refresh:
        params["force_refresh"] = "true"

    try:
        response = httpx.get(
            f"{api.rstrip('/')}/api/external-buckets/{bucket_name}",
            headers=get_auth_headers(),
            params=params,
            timeout=60,
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to browse bucket: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    listing = response.json()

    if format in ["json", "yaml"]:
        console.print(format_output(listing, format))
        return

    prefixes = listing.get("prefixes", [])
    objects = listing.get("objects", [])

    if not prefixes and not objects:
        typer.secho(
            f"No objects found in {bucket_name}"
            + (f" at prefix '{prefix}'" if prefix else ""),
            fg=typer.colors.YELLOW,
        )
        return

    title = f"[bold]{bucket_name}[/bold]"
    if prefix:
        title += f" / [dim]{prefix}[/dim]"
    if listing.get("cached"):
        title += " [dim](cached)[/dim]"

    tree = Tree(title)

    for p in sorted(prefixes):
        display = p.removeprefix(prefix) if prefix else p
        tree.add(f"[bold blue]{display}[/bold blue]")

    for obj in objects:
        key = obj["key"]
        display = key.removeprefix(prefix) if prefix else key
        size = _format_file_size(obj.get("size", 0))
        tree.add(f"[cyan]{display}[/cyan] [dim]{size}[/dim]")

    console.print(tree)
    console.print(f"\n[dim]{len(prefixes)} folder(s), {len(objects)} file(s)[/dim]")


CHECKSUM_CACHE_FILE = CONFIG_DIR / "checksum_cache.json"


def load_checksum_cache(cache_dir: Path | None = None) -> dict:
    """Load checksum cache from JSON file."""
    cache_file = (
        (cache_dir / "checksum_cache.json") if cache_dir else CHECKSUM_CACHE_FILE
    )
    if not cache_file.exists():
        return {}
    try:
        return json.loads(cache_file.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def save_checksum_cache(cache_dir: Path | None, cache: dict) -> None:
    """Save checksum cache to JSON file."""
    target_dir = cache_dir or CONFIG_DIR
    target_dir.mkdir(parents=True, exist_ok=True)
    cache_file = target_dir / "checksum_cache.json"
    cache_file.write_text(json.dumps(cache, indent=2))


def get_cached_checksum(cache: dict, file_path: Path) -> str | None:
    """Get cached checksum if file mtime and size match."""
    key = str(file_path)
    if key not in cache:
        return None
    entry = cache[key]
    stat = file_path.stat()
    if entry.get("mtime") == stat.st_mtime and entry.get("size") == stat.st_size:
        return entry.get("checksum")
    return None


def update_checksum_cache(cache: dict, file_path: Path, checksum: str) -> None:
    """Update cache entry for a file."""
    stat = file_path.stat()
    cache[str(file_path)] = {
        "checksum": checksum,
        "mtime": stat.st_mtime,
        "size": stat.st_size,
    }


def compute_checksum(path: Path, cache: dict | None = None) -> str:
    """Compute SHA256 checksum, using cache if available."""
    if cache is not None:
        cached = get_cached_checksum(cache, path)
        if cached:
            return cached

    hasher = sha256()
    with path.open("rb") as buffer:
        for chunk in iter(lambda: buffer.read(1024 * 1024), b""):
            if not chunk:
                break
            hasher.update(chunk)
    checksum = hasher.hexdigest()

    if cache is not None:
        update_checksum_cache(cache, path, checksum)

    return checksum


UPLOADS_DIR = CONFIG_DIR / "uploads"


def _session_key(experiment_id: str | None, artifact_path: str) -> str:
    """Generate a unique key for a session based on experiment and artifact path."""
    import hashlib

    # Use "standalone" prefix for uploads without experiment
    exp_part = experiment_id if experiment_id else "standalone"
    key = f"{exp_part}:{artifact_path}"
    return hashlib.sha256(key.encode()).hexdigest()[:16]


def _session_file_path(experiment_id: str | None, artifact_path: str) -> Path:
    """Get path to session file based on experiment and artifact."""
    return UPLOADS_DIR / f"{_session_key(experiment_id, artifact_path)}.json"


def save_upload_session(session_data: dict) -> None:
    """Save upload session to disk for resume capability."""
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    session_file = _session_file_path(
        session_data["experiment_id"], session_data["artifact_path"]
    )
    session_file.write_text(json.dumps(session_data, indent=2))


def load_upload_session(experiment_id: str | None, artifact_path: str) -> dict | None:
    """Load upload session from disk for a specific file."""
    session_file = _session_file_path(experiment_id, artifact_path)
    if not session_file.exists():
        return None
    try:
        return json.loads(session_file.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def delete_upload_session(experiment_id: str | None, artifact_path: str) -> None:
    """Delete upload session file after successful upload."""
    session_file = _session_file_path(experiment_id, artifact_path)
    if session_file.exists():
        session_file.unlink()


def check_artifact_exists(api: str, checksum: str) -> dict | None:
    """Check if an artifact with given checksum already exists on server."""
    headers = get_auth_headers()
    try:
        resp = httpx.get(
            f"{api.rstrip('/')}/api/artifacts/by-checksum/{checksum}",
            headers=headers,
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json()
    except httpx.HTTPError:
        pass
    return None


def check_artifacts_batch(api: str, checksums: list[str]) -> set[str]:
    """Batch check which checksums exist on server. Returns set of existing checksums."""
    if not checksums:
        return set()
    headers = get_auth_headers()
    try:
        resp = httpx.post(
            f"{api.rstrip('/')}/api/artifacts/by-checksums",
            headers=headers,
            json=checksums,
            timeout=30,
        )
        if resp.status_code == 200:
            result = resp.json()
            return {cs for cs, exists in result.items() if exists}
    except httpx.HTTPError:
        pass
    return set()


def render_relationships_tree(
    relationships: list, experiment_id: str, title: str = "Relationships"
) -> Tree:
    """Render experiment relationships as a tree."""
    tree = Tree(f"[bold]{title}[/bold]")
    if not relationships:
        tree.add("[dim]No relationships[/dim]")
        return tree

    for rel in relationships:
        rel_type = rel.get("relationship_type", "unknown")
        from_exp = rel.get("from_experiment") or {}
        to_exp = rel.get("to_experiment") or {}
        from_id = (
            from_exp.get("display_id")
            or rel.get("from_display_id")
            or rel.get("from_experiment_id", "")[:8]
        )
        to_id = (
            to_exp.get("display_id")
            or rel.get("to_display_id")
            or rel.get("to_experiment_id", "")[:8]
        )
        from_title = from_exp.get("title") or rel.get("from_title", "")
        to_title = to_exp.get("title") or rel.get("to_title", "")

        branch = tree.add(
            f"[cyan]{from_id}[/cyan] [bold]{rel_type}[/bold] [cyan]{to_id}[/cyan]"
        )
        if from_title:
            branch.add(f"[dim]From: {from_title}[/dim]")
        if to_title:
            branch.add(f"[dim]To: {to_title}[/dim]")
    return tree


@relationships_app.command("list")
def relationships_list(
    experiment_id: str = typer.Argument(..., help="Experiment ID"),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List relationships for an experiment."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{experiment_id}/relationships"

    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to retrieve relationships: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    relationships = response.json()

    if format in ["json", "yaml"]:
        typer.echo(format_output(relationships, format))
        return

    if not relationships:
        typer.echo("No relationships found.")
        return

    if format == "tree":
        console.print(render_relationships_tree(relationships, experiment_id))
    else:
        table = Table(show_lines=False, show_header=True)
        table.add_column("From", style="cyan", no_wrap=True)
        table.add_column("Type", style="bold", justify="center")
        table.add_column("To", style="cyan", no_wrap=True)
        table.add_column("Created", style="dim", no_wrap=True)

        for rel in relationships:
            from_exp = rel.get("from_experiment") or {}
            to_exp = rel.get("to_experiment") or {}
            from_id = (
                from_exp.get("display_id")
                or rel.get("from_display_id")
                or rel.get("from_experiment_id", "")[:8]
            )
            to_id = (
                to_exp.get("display_id")
                or rel.get("to_display_id")
                or rel.get("to_experiment_id", "")[:8]
            )
            table.add_row(
                from_id,
                rel.get("relationship_type", ""),
                to_id,
                rel.get("created_at", "")[:10] if rel.get("created_at") else "",
            )

        console.print(table)


@relationships_app.command("add")
def relationships_add(
    from_id: str = typer.Argument(..., help="Source experiment ID"),
    to_id: str = typer.Argument(..., help="Target experiment ID"),
    rel_type: str = typer.Option(
        "uses", "--type", "-t", help="Relationship type: uses, relates_to"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Create a relationship between two experiments."""
    if rel_type not in ("uses", "relates_to"):
        typer.secho(
            f"Invalid relationship type: {rel_type}. Must be 'uses' or 'relates_to'",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{from_id}/relationships"
    payload = {
        "from_experiment_id": from_id,
        "to_experiment_id": to_id,
        "relationship_type": rel_type,
    }

    try:
        response = httpx.post(
            endpoint, headers=get_auth_headers(), json=payload, timeout=15
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to create relationship: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(
        f"Relationship created: {from_id} {rel_type} {to_id}",
        fg=typer.colors.GREEN,
    )


@relationships_app.command("remove")
def relationships_remove(
    from_id: str = typer.Argument(..., help="Source experiment ID"),
    to_id: str = typer.Argument(..., help="Target experiment ID"),
    rel_type: str = typer.Option(
        "uses", "--type", "-t", help="Relationship type: uses, relates_to"
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Remove a relationship between two experiments."""
    if rel_type not in ("uses", "relates_to"):
        typer.secho(
            f"Invalid relationship type: {rel_type}. Must be 'uses' or 'relates_to'",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{from_id}/relationships"
    params = {
        "from_experiment_id": from_id,
        "to_experiment_id": to_id,
        "relationship_type": rel_type,
    }

    try:
        response = httpx.delete(
            endpoint, headers=get_auth_headers(), params=params, timeout=15
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to remove relationship: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(
        f"Relationship removed: {from_id} {rel_type} {to_id}",
        fg=typer.colors.GREEN,
    )


@fields_app.command("list")
def fields_list(
    include_inactive: bool = typer.Option(
        False, "--include-inactive", help="Include inactive field definitions"
    ),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List metadata field definitions."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/admin/metadata-fields"

    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 403:
            typer.secho("Access denied. Admin role required.", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to list fields: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to list fields: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    fields = response.json()
    if not include_inactive:
        fields = [f for f in fields if f.get("is_active", True)]

    if format in ["json", "yaml"]:
        console.print(format_output(fields, format))
        return

    if not fields:
        typer.echo("No metadata fields defined.")
        return

    if format == "table":
        table = Table(title="Metadata Fields")
        table.add_column("Key", style="cyan", no_wrap=True)
        table.add_column("Display Name", style="bold")
        table.add_column("Type")
        table.add_column("Required", justify="center")
        table.add_column("Unit")
        table.add_column("Active", justify="center")
        for f in fields:
            table.add_row(
                f.get("key", ""),
                f.get("display_name", ""),
                f.get("field_type", "TEXT"),
                "Y" if f.get("required") else "-",
                f.get("unit", "") or "-",
                "Y" if f.get("is_active", True) else "-",
            )
        console.print(table)
        return

    console.print(render_fields_tree(fields))


@fields_app.command("create")
def fields_create(
    key: str = typer.Option(..., "--key", "-k", help="Unique field key"),
    name: str = typer.Option(..., "--name", "-n", help="Display name"),
    field_type: str = typer.Option(
        "TEXT",
        "--type",
        "-t",
        help="Field type: TEXT, NUMBER, BOOLEAN, ENUM, DATE, URL",
    ),
    description: str | None = typer.Option(
        None, "--description", "-d", help="Field description"
    ),
    unit: str | None = typer.Option(None, "--unit", "-u", help="Unit of measurement"),
    required: bool = typer.Option(
        False, "--required", "-r", help="Mark field as required"
    ),
    allowed_values: str | None = typer.Option(
        None, "--allowed-values", help="Comma-separated allowed values (for ENUM type)"
    ),
    default: str | None = typer.Option(None, "--default", help="Default value"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Create a new metadata field definition."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/admin/metadata-fields"

    payload = {
        "key": key,
        "display_name": name,
        "field_type": field_type.upper(),
        "required": required,
    }
    if description:
        payload["description"] = description
    if unit:
        payload["unit"] = unit
    if allowed_values:
        payload["allowed_values"] = [v.strip() for v in allowed_values.split(",")]
    if default:
        payload["default_value"] = default

    try:
        response = httpx.post(
            endpoint, headers=get_auth_headers(), json=payload, timeout=10
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 403:
            typer.secho("Access denied. Admin role required.", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        detail = exc.response.json().get("detail", str(exc))
        typer.secho(f"Failed to create field: {detail}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to create field: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    result = response.json()
    typer.secho(f"Field created: {result.get('key', key)}", fg=typer.colors.GREEN)


@fields_app.command("update")
def fields_update(
    field_id: str = typer.Argument(..., help="Field ID or key"),
    name: str | None = typer.Option(None, "--name", "-n", help="New display name"),
    description: str | None = typer.Option(
        None, "--description", "-d", help="New description"
    ),
    field_type: str | None = typer.Option(None, "--type", "-t", help="New field type"),
    unit: str | None = typer.Option(None, "--unit", "-u", help="New unit"),
    required: bool | None = typer.Option(
        None, "--required/--no-required", help="Mark as required or not"
    ),
    active: bool | None = typer.Option(
        None, "--active/--inactive", help="Set active status"
    ),
    allowed_values: str | None = typer.Option(
        None, "--allowed-values", help="Comma-separated allowed values"
    ),
    default: str | None = typer.Option(None, "--default", help="Default value"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Update a metadata field definition."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/admin/metadata-fields/{field_id}"

    payload = {}
    if name is not None:
        payload["display_name"] = name
    if description is not None:
        payload["description"] = description
    if field_type is not None:
        payload["field_type"] = field_type.upper()
    if unit is not None:
        payload["unit"] = unit
    if required is not None:
        payload["required"] = required
    if active is not None:
        payload["is_active"] = active
    if allowed_values is not None:
        payload["allowed_values"] = [v.strip() for v in allowed_values.split(",")]
    if default is not None:
        payload["default_value"] = default

    if not payload:
        typer.secho("No updates specified.", fg=typer.colors.YELLOW)
        raise typer.Exit(code=0)

    try:
        response = httpx.patch(
            endpoint, headers=get_auth_headers(), json=payload, timeout=10
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 403:
            typer.secho("Access denied. Admin role required.", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        if exc.response.status_code == 404:
            typer.secho(f"Field not found: {field_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        detail = exc.response.json().get("detail", str(exc))
        typer.secho(f"Failed to update field: {detail}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to update field: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"Field updated: {field_id}", fg=typer.colors.GREEN)


@fields_app.command("delete")
def fields_delete(
    field_id: str = typer.Argument(..., help="Field ID or key"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Delete a metadata field definition."""
    if not yes:
        confirm = typer.confirm(f"Delete field {field_id}?")
        if not confirm:
            raise typer.Abort()

    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/admin/metadata-fields/{field_id}"

    try:
        response = httpx.delete(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 403:
            typer.secho("Access denied. Admin role required.", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        if exc.response.status_code == 404:
            typer.secho(f"Field not found: {field_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to delete field: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to delete field: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"Field deleted: {field_id}", fg=typer.colors.GREEN)


@types_app.command("list")
def types_list(
    include_inactive: bool = typer.Option(
        False, "--include-inactive", help="Include inactive experiment types"
    ),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List experiment types."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiment-types"

    params = {}
    if include_inactive:
        params["include_inactive"] = "true"

    try:
        response = httpx.get(
            endpoint, headers=get_auth_headers(), params=params, timeout=10
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to list types: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    types = response.json()

    if format in ["json", "yaml"]:
        console.print(format_output(types, format))
        return

    if not types:
        typer.echo("No experiment types defined.")
        return

    if format == "table":
        table = Table(title="Experiment Types")
        table.add_column("Name", style="cyan", no_wrap=True)
        table.add_column("Display Name", style="bold")
        table.add_column("Description")
        table.add_column("Active", justify="center")
        for t in types:
            table.add_row(
                t.get("name", ""),
                t.get("display_name", ""),
                (t.get("description", "") or "")[:50],
                "Y" if t.get("is_active", True) else "-",
            )
        console.print(table)
        return

    console.print(render_types_tree(types))


@types_app.command("view")
def types_view(
    type_id: str = typer.Argument(..., help="Type ID or name"),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """View details of an experiment type."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiment-types/{type_id}"

    try:
        response = httpx.get(
            endpoint,
            headers=get_auth_headers(),
            params={"include_metadata_fields": "true"},
            timeout=10,
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            typer.secho(f"Type not found: {type_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to get type: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to get type: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    exp_type = response.json()

    if format in ["json", "yaml"]:
        console.print(format_output(exp_type, format))
        return

    if format == "table":
        table = Table(show_header=False, box=None)
        table.add_column("Field", style="dim", width=18)
        table.add_column("Value")
        table.add_row("ID", exp_type.get("id", ""))
        table.add_row("Name", exp_type.get("name", ""))
        table.add_row("Display Name", exp_type.get("display_name", ""))
        table.add_row("Description", exp_type.get("description", "") or "-")
        table.add_row("Active", "Yes" if exp_type.get("is_active") else "No")
        metadata_fields = exp_type.get("metadata_fields") or []
        table.add_row("Metadata Fields", str(len(metadata_fields)))
        console.print(table)
        return

    console.print(render_type_detail_tree(exp_type))


@types_app.command("create")
def types_create(
    name: str = typer.Option(..., "--name", "-n", help="Unique type name (slug)"),
    display_name: str = typer.Option(
        ..., "--display-name", "-d", help="Human-readable display name"
    ),
    description: str | None = typer.Option(
        None, "--description", help="Type description"
    ),
    template: Path | None = typer.Option(
        None, "--template", "-t", help="Path to markdown template file"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Create a new experiment type."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiment-types"

    payload = {
        "name": name,
        "display_name": display_name,
    }
    if description:
        payload["description"] = description
    if template:
        if not template.exists():
            typer.secho(f"Template file not found: {template}", fg=typer.colors.RED)
            raise typer.Exit(code=1)
        payload["markdown_template"] = template.read_text()

    try:
        response = httpx.post(
            endpoint, headers=get_auth_headers(), json=payload, timeout=10
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 403:
            typer.secho("Access denied. Admin role required.", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        detail = exc.response.json().get("detail", str(exc))
        typer.secho(f"Failed to create type: {detail}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to create type: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    result = response.json()
    typer.secho(f"Type created: {result.get('name', name)}", fg=typer.colors.GREEN)


@types_app.command("update")
def types_update(
    type_id: str = typer.Argument(..., help="Type ID or name"),
    display_name: str | None = typer.Option(
        None, "--display-name", "-d", help="New display name"
    ),
    description: str | None = typer.Option(
        None, "--description", help="New description"
    ),
    template: Path | None = typer.Option(
        None, "--template", "-t", help="Path to new markdown template file"
    ),
    active: bool | None = typer.Option(
        None, "--active/--inactive", help="Set active status"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Update an experiment type."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiment-types/{type_id}"

    payload = {}
    if display_name is not None:
        payload["display_name"] = display_name
    if description is not None:
        payload["description"] = description
    if template is not None:
        if not template.exists():
            typer.secho(f"Template file not found: {template}", fg=typer.colors.RED)
            raise typer.Exit(code=1)
        payload["markdown_template"] = template.read_text()
    if active is not None:
        payload["is_active"] = active

    if not payload:
        typer.secho("No updates specified.", fg=typer.colors.YELLOW)
        raise typer.Exit(code=0)

    try:
        response = httpx.patch(
            endpoint, headers=get_auth_headers(), json=payload, timeout=10
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 403:
            typer.secho("Access denied. Admin role required.", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        if exc.response.status_code == 404:
            typer.secho(f"Type not found: {type_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        detail = exc.response.json().get("detail", str(exc))
        typer.secho(f"Failed to update type: {detail}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to update type: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"Type updated: {type_id}", fg=typer.colors.GREEN)


@types_app.command("delete")
def types_delete(
    type_id: str = typer.Argument(..., help="Type ID or name"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Delete (deactivate) an experiment type."""
    if not yes:
        confirm = typer.confirm(f"Delete type {type_id}?")
        if not confirm:
            raise typer.Abort()

    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiment-types/{type_id}"

    try:
        response = httpx.delete(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 403:
            typer.secho("Access denied. Admin role required.", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        if exc.response.status_code == 404:
            typer.secho(f"Type not found: {type_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to delete type: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to delete type: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"Type deleted: {type_id}", fg=typer.colors.GREEN)


@types_app.command("set-fields")
def types_set_fields(
    type_id: str = typer.Argument(..., help="Type ID or name"),
    field_ids: list[str] = typer.Argument(..., help="Metadata field IDs to assign"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Set metadata fields for an experiment type."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiment-types/{type_id}/metadata-fields"

    try:
        response = httpx.put(
            endpoint,
            headers=get_auth_headers(),
            json={"metadata_field_ids": field_ids},
            timeout=10,
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 403:
            typer.secho("Access denied. Admin role required.", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        if exc.response.status_code == 404:
            typer.secho(f"Type not found: {type_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        detail = exc.response.json().get("detail", str(exc))
        typer.secho(f"Failed to set fields: {detail}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to set fields: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(
        f"Metadata fields set for {type_id}: {len(field_ids)} field(s)",
        fg=typer.colors.GREEN,
    )


# -----------------------------------------------------------------------------
# Collections commands
# -----------------------------------------------------------------------------


def render_collections_tree(collections_list: list, title: str = "Collections") -> Tree:
    """Render collections as a Rich tree."""
    tree = Tree(f"[bold]{title}[/bold]")
    for coll in collections_list:
        display_id = coll.get("display_id", "")
        name = coll.get("name", "")
        artifact_count = coll.get("artifact_count", 0)
        experiment_count = coll.get("experiment_count", 0)
        is_snapshot = coll.get("is_snapshot", False)

        snapshot_badge = " [yellow](snapshot)[/yellow]" if is_snapshot else ""
        branch = tree.add(
            f"[cyan]{display_id}[/cyan] {name}{snapshot_badge} "
            f"[dim]{artifact_count} artifacts, {experiment_count} experiments[/dim]"
        )

        if coll.get("description"):
            branch.add(
                f"[dim]{coll['description'][:100]}...[/dim]"
                if len(coll.get("description", "")) > 100
                else f"[dim]{coll['description']}[/dim]"
            )

        tags = coll.get("tags") or []
        if tags:
            branch.add(f"[dim]Tags: {', '.join(tags)}[/dim]")

    return tree


def render_collection_detail_tree(coll: dict) -> Tree:
    """Render a single collection with full details as a Rich tree."""
    display_id = coll.get("display_id", "")
    name = coll.get("name", "")
    is_snapshot = coll.get("is_snapshot", False)

    snapshot_badge = " [yellow](snapshot)[/yellow]" if is_snapshot else ""
    tree = Tree(f"[bold cyan]{display_id}[/bold cyan] {name}{snapshot_badge}")

    # Basic info
    info_branch = tree.add("[bold]Info[/bold]")
    info_branch.add(f"ID: [dim]{coll['id']}[/dim]")
    info_branch.add(f"Created: [dim]{coll.get('created_at', 'N/A')}[/dim]")
    if coll.get("created_by"):
        info_branch.add(f"Creator: [dim]{coll['created_by']}[/dim]")
    if coll.get("description"):
        info_branch.add(f"Description: [dim]{coll['description']}[/dim]")
    if coll.get("tags"):
        info_branch.add(f"Tags: [dim]{', '.join(coll['tags'])}[/dim]")

    # Snapshot info
    if is_snapshot and coll.get("snapshot_of_id"):
        info_branch.add(f"Snapshot of: [dim]{coll.get('snapshot_of_id', 'N/A')}[/dim]")
        if coll.get("snapshot_note"):
            info_branch.add(f"Note: [dim]{coll['snapshot_note']}[/dim]")

    # Stats
    stats_branch = tree.add("[bold]Stats[/bold]")
    stats_branch.add(f"Artifacts: {coll.get('artifact_count', 0)}")
    stats_branch.add(f"Experiments: {coll.get('experiment_count', 0)}")
    total_size = coll.get("total_size_bytes", 0)
    if total_size:
        stats_branch.add(f"Total size: {total_size / (1024 * 1024):.2f} MB")

    # Artifacts
    artifacts = coll.get("artifacts") or []
    if artifacts:
        artifacts_branch = tree.add(f"[bold]Artifacts ({len(artifacts)})[/bold]")
        for art in artifacts[:10]:  # Show first 10
            size_mb = art.get("size_bytes", 0) / (1024 * 1024)
            artifacts_branch.add(
                f"[cyan]{art.get('artifact_path', art.get('name', 'N/A'))}[/cyan] [dim]{size_mb:.2f} MB[/dim]"
            )
        if len(artifacts) > 10:
            artifacts_branch.add(f"[dim]... and {len(artifacts) - 10} more[/dim]")

    # Experiments
    experiments = coll.get("experiments") or []
    if experiments:
        exp_branch = tree.add(
            f"[bold]Connected Experiments ({len(experiments)})[/bold]"
        )
        for exp in experiments[:10]:
            exp_branch.add(
                f"[cyan]{exp.get('display_id', 'N/A')}[/cyan] {exp.get('title', 'N/A')}"
            )
        if len(experiments) > 10:
            exp_branch.add(f"[dim]... and {len(experiments) - 10} more[/dim]")

    return tree


@collections_app.command("list")
def collections_list(
    search: str | None = typer.Option(
        None, "--search", "-s", help="Search in name/description"
    ),
    tag: str | None = typer.Option(None, "--tag", "-t", help="Filter by tag"),
    include_snapshots: bool = typer.Option(
        True, "--snapshots/--no-snapshots", help="Include snapshots"
    ),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List all collections with optional filtering."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/collections"

    params = {"include_snapshots": str(include_snapshots).lower()}
    if search:
        params["search"] = search
    if tag:
        params["tag"] = tag

    try:
        response = httpx.get(
            endpoint, headers=get_auth_headers(), params=params, timeout=30
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to list collections: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    collections_list_data = response.json()

    if format in ["json", "yaml"]:
        console.print(format_output(collections_list_data, format))
        return

    if not collections_list_data:
        typer.secho("No collections found.", fg=typer.colors.YELLOW)
        return

    if format == "tree":

        def render_tree_page(page: list) -> None:
            console.print(render_collections_tree(page))

        paginate_results(collections_list_data, render_tree_page)
    else:

        def render_table_page(page: list) -> None:
            table = Table(show_lines=False, show_header=True)
            table.add_column("Display ID", style="cyan", no_wrap=True)
            table.add_column("Name")
            table.add_column("Artifacts", justify="center")
            table.add_column("Experiments", justify="center")
            table.add_column("Snapshot", justify="center")

            for coll in page:
                snapshot_badge = "Y" if coll.get("is_snapshot") else "-"
                table.add_row(
                    coll.get("display_id", "N/A"),
                    coll.get("name", "N/A"),
                    str(coll.get("artifact_count", 0)),
                    str(coll.get("experiment_count", 0)),
                    snapshot_badge,
                )
            console.print(table)

        paginate_results(collections_list_data, render_table_page)


@collections_app.command("create")
def collections_create(
    name: str = typer.Option(..., "--name", "-n", help="Collection name"),
    description: str | None = typer.Option(
        None, "--description", "-d", help="Description"
    ),
    tags: list[str] = typer.Option([], "--tag", "-t", help="Tags (can be repeated)"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Create a new collection."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/collections"

    payload: dict[str, str | list[str] | None] = {"name": name}
    if description:
        payload["description"] = description
    if tags:
        payload["tags"] = tags

    try:
        response = httpx.post(
            endpoint, headers=get_auth_headers(), json=payload, timeout=30
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to create collection: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    result = response.json()
    typer.secho(
        f"Collection created: {result.get('display_id')} - {result.get('name')}",
        fg=typer.colors.GREEN,
    )


@collections_app.command("info")
def collections_info(
    collection_id: str = typer.Argument(
        ..., help="Collection ID or display ID (COL-N)"
    ),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Show detailed information about a collection."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/collections/{collection_id}"

    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=30)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to get collection: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    coll = response.json()

    if format in ["json", "yaml"]:
        console.print(format_output(coll, format))
        return

    console.print(render_collection_detail_tree(coll))


@collections_app.command("update")
def collections_update(
    collection_id: str = typer.Argument(
        ..., help="Collection ID or display ID (COL-N)"
    ),
    name: str | None = typer.Option(None, "--name", "-n", help="New name"),
    description: str | None = typer.Option(
        None, "--description", "-d", help="New description"
    ),
    tags: list[str] = typer.Option(
        None, "--tag", "-t", help="New tags (replaces existing)"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Update a collection's metadata."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/collections/{collection_id}"

    payload = {}
    if name is not None:
        payload["name"] = name
    if description is not None:
        payload["description"] = description
    if tags is not None:
        payload["tags"] = tags

    if not payload:
        typer.secho("No updates provided.", fg=typer.colors.YELLOW)
        return

    try:
        response = httpx.patch(
            endpoint, headers=get_auth_headers(), json=payload, timeout=30
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 400:
            typer.secho("Cannot modify a snapshot collection.", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to update collection: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to update collection: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    result = response.json()
    typer.secho(
        f"Collection updated: {result.get('display_id')}", fg=typer.colors.GREEN
    )


@collections_app.command("delete")
def collections_delete(
    collection_id: str = typer.Argument(
        ..., help="Collection ID or display ID (COL-N)"
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Force delete even if connected to experiments"
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Delete a collection."""
    api = get_api_base(server)

    # First get collection info
    info_endpoint = f"{api.rstrip('/')}/api/collections/{collection_id}"
    try:
        response = httpx.get(info_endpoint, headers=get_auth_headers(), timeout=30)
        response.raise_for_status()
        coll = response.json()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to get collection: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    if not yes:
        exp_count = coll.get("experiment_count", 0)
        if exp_count > 0 and not force:
            typer.secho(
                f"Collection is connected to {exp_count} experiment(s). "
                "Use --force to delete anyway.",
                fg=typer.colors.YELLOW,
            )
            raise typer.Exit(code=1)

        confirm = typer.confirm(
            f"Delete collection {coll.get('display_id')} - {coll.get('name')}?"
        )
        if not confirm:
            typer.echo("Cancelled.")
            raise typer.Exit(code=0)

    endpoint = f"{api.rstrip('/')}/api/collections/{collection_id}"
    params = {"force": str(force).lower()}

    try:
        response = httpx.delete(
            endpoint, headers=get_auth_headers(), params=params, timeout=30
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to delete collection: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"Collection deleted: {coll.get('display_id')}", fg=typer.colors.GREEN)


@collections_app.command("add")
def collections_add(
    collection_id: str = typer.Argument(
        ..., help="Collection ID or display ID (COL-N)"
    ),
    artifact_ids: list[str] = typer.Argument(
        None, help="Artifact ID(s) or S3 key(s) when --bucket is used"
    ),
    path: str | None = typer.Option(
        None, "--path", "-p", help="Custom artifact path (single artifact, no --bucket)"
    ),
    bucket: str | None = typer.Option(
        None, "--bucket", "-b", help="External bucket name (args become S3 keys)"
    ),
    prefix: str | None = typer.Option(
        None, "--prefix", help="Attach all files under this prefix (requires --bucket)"
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation (--bucket)"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Add artifact(s) to a collection.

    Without --bucket, adds internal artifacts by ID.
    With --bucket, links external S3 artifacts without copying data.

    Examples:

        diffuse collections add COL-1 artifact-1 artifact-2

        diffuse collections add COL-1 data/scan.h5 --bucket osn-chess

        diffuse collections add COL-1 --bucket osn-chess --prefix data/2024/
    """
    if prefix and not bucket:
        typer.secho("--prefix requires --bucket", fg=typer.colors.RED)
        raise typer.Exit(code=1)
    if path and bucket:
        typer.secho("--path cannot be used with --bucket", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    api = get_api_base(server)
    headers = get_auth_headers()

    if bucket:
        if prefix:
            resolved_keys = _resolve_external_prefix(api, headers, bucket, prefix)
            if not resolved_keys:
                typer.secho(
                    f"No files found under prefix '{prefix}'",
                    fg=typer.colors.YELLOW,
                )
                return
            artifacts_payload = [{"s3_key": k} for k in resolved_keys]
        else:
            if not artifact_ids:
                typer.secho(
                    "Provide S3 key(s) as arguments or use --prefix",
                    fg=typer.colors.RED,
                )
                raise typer.Exit(code=1)
            artifacts_payload = [{"s3_key": k} for k in artifact_ids]

        count = len(artifacts_payload)
        if not yes:
            confirm = typer.confirm(
                f"Attach {count} external artifact(s) from '{bucket}' to collection {collection_id}?"
            )
            if not confirm:
                raise typer.Abort()

        try:
            response = httpx.post(
                f"{api.rstrip('/')}/api/collections/{collection_id}/external-artifacts/batch-attach",
                headers=headers,
                json={
                    "bucket_name": bucket,
                    "artifacts": artifacts_payload,
                },
                timeout=120,
            )
            response.raise_for_status()
            result = response.json()
        except httpx.HTTPError as exc:
            typer.secho(
                f"Failed to attach external artifacts: {exc}", fg=typer.colors.RED
            )
            raise typer.Exit(code=1) from exc

        attached = result.get("attached", 0)
        typer.secho(
            f"Attached {attached} external artifact(s) to collection {collection_id}",
            fg=typer.colors.GREEN,
        )
        return

    if not artifact_ids:
        typer.secho("Provide at least one artifact ID", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    if len(artifact_ids) == 1:
        endpoint = f"{api.rstrip('/')}/api/collections/{collection_id}/artifacts"
        payload = {"artifact_id": artifact_ids[0]}
        if path:
            payload["artifact_path"] = path

        try:
            response = httpx.post(endpoint, headers=headers, json=payload, timeout=30)
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 400:
                typer.secho("Cannot modify a snapshot collection.", fg=typer.colors.RED)
            elif exc.response.status_code == 409:
                typer.secho(
                    "Artifact is already in this collection.", fg=typer.colors.YELLOW
                )
            else:
                typer.secho(f"Failed to add artifact: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        except httpx.HTTPError as exc:
            typer.secho(f"Failed to add artifact: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc

        typer.secho(
            f"Artifact {artifact_ids[0]} added to collection.", fg=typer.colors.GREEN
        )
    else:
        endpoint = f"{api.rstrip('/')}/api/collections/{collection_id}/artifacts/batch"
        payload = {"artifacts": [{"artifact_id": aid} for aid in artifact_ids]}

        try:
            response = httpx.post(endpoint, headers=headers, json=payload, timeout=60)
            response.raise_for_status()
            result = response.json()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 400:
                typer.secho("Cannot modify a snapshot collection.", fg=typer.colors.RED)
            else:
                typer.secho(f"Failed to add artifacts: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        except httpx.HTTPError as exc:
            typer.secho(f"Failed to add artifacts: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc

        typer.secho(
            f"Added {result.get('added', 0)} artifact(s), skipped {result.get('skipped_duplicates', 0)} duplicates.",
            fg=typer.colors.GREEN,
        )


@collections_app.command("remove")
def collections_remove(
    collection_id: str = typer.Argument(
        ..., help="Collection ID or display ID (COL-N)"
    ),
    artifact_ids: list[str] = typer.Argument(..., help="Artifact ID(s) to remove"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Remove artifact(s) from a collection."""
    api = get_api_base(server)

    if len(artifact_ids) == 1:
        endpoint = f"{api.rstrip('/')}/api/collections/{collection_id}/artifacts/{artifact_ids[0]}"

        try:
            response = httpx.delete(endpoint, headers=get_auth_headers(), timeout=30)
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 400:
                typer.secho("Cannot modify a snapshot collection.", fg=typer.colors.RED)
            elif exc.response.status_code == 404:
                typer.secho("Artifact not found in collection.", fg=typer.colors.YELLOW)
            else:
                typer.secho(f"Failed to remove artifact: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        except httpx.HTTPError as exc:
            typer.secho(f"Failed to remove artifact: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc

        typer.secho(
            f"Artifact {artifact_ids[0]} removed from collection.",
            fg=typer.colors.GREEN,
        )
    else:
        endpoint = (
            f"{api.rstrip('/')}/api/collections/{collection_id}/artifacts/batch-remove"
        )
        payload = {"artifact_ids": artifact_ids}

        try:
            response = httpx.post(
                endpoint, headers=get_auth_headers(), json=payload, timeout=60
            )
            response.raise_for_status()
            result = response.json()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 400:
                typer.secho("Cannot modify a snapshot collection.", fg=typer.colors.RED)
            else:
                typer.secho(f"Failed to remove artifacts: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        except httpx.HTTPError as exc:
            typer.secho(f"Failed to remove artifacts: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc

        typer.secho(
            f"Removed {result.get('removed', 0)} artifact(s) (requested {result.get('requested', 0)}).",
            fg=typer.colors.GREEN,
        )


@collections_app.command("connect")
def collections_connect(
    experiment_id: str = typer.Argument(
        ..., help="Experiment ID or display ID (EXP-N)"
    ),
    collection_id: str = typer.Argument(
        ..., help="Collection ID or display ID (COL-N)"
    ),
    alias: str | None = typer.Option(
        None, "--alias", "-a", help="Alias for this experiment context"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Connect a collection to an experiment."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/experiments/{experiment_id}/collections/connect"

    payload = {"collection_id": collection_id}
    if alias:
        payload["alias"] = alias

    try:
        response = httpx.post(
            endpoint, headers=get_auth_headers(), json=payload, timeout=30
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 409:
            typer.secho(
                "Collection is already connected to this experiment.",
                fg=typer.colors.YELLOW,
            )
        else:
            typer.secho(f"Failed to connect collection: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to connect collection: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    result = response.json()
    typer.secho(
        f"Collection {result.get('display_id')} connected to experiment {experiment_id}.",
        fg=typer.colors.GREEN,
    )


@collections_app.command("disconnect")
def collections_disconnect(
    experiment_id: str = typer.Argument(
        ..., help="Experiment ID or display ID (EXP-N)"
    ),
    collection_id: str = typer.Argument(
        ..., help="Collection ID or display ID (COL-N)"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Disconnect a collection from an experiment."""
    api = get_api_base(server)
    endpoint = (
        f"{api.rstrip('/')}/api/experiments/{experiment_id}/collections/{collection_id}"
    )

    try:
        response = httpx.delete(endpoint, headers=get_auth_headers(), timeout=30)
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            typer.secho(
                "Collection is not connected to this experiment.",
                fg=typer.colors.YELLOW,
            )
        else:
            typer.secho(f"Failed to disconnect collection: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to disconnect collection: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(
        f"Collection {collection_id} disconnected from experiment {experiment_id}.",
        fg=typer.colors.GREEN,
    )


@collections_app.command("snapshot")
def collections_snapshot(
    collection_id: str = typer.Argument(
        ..., help="Collection ID or display ID (COL-N)"
    ),
    note: str | None = typer.Option(None, "--note", "-n", help="Snapshot note"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Create an immutable snapshot of a collection."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/collections/{collection_id}/snapshots"

    payload = {}
    if note:
        payload["note"] = note

    try:
        response = httpx.post(
            endpoint, headers=get_auth_headers(), json=payload, timeout=30
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 400:
            typer.secho("Cannot create a snapshot of a snapshot.", fg=typer.colors.RED)
        else:
            typer.secho(f"Failed to create snapshot: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to create snapshot: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    result = response.json()
    typer.secho(
        f"Snapshot created: {result.get('display_id')} - {result.get('name')}",
        fg=typer.colors.GREEN,
    )


@collections_app.command("snapshots")
def collections_snapshots(
    collection_id: str = typer.Argument(
        ..., help="Collection ID or display ID (COL-N)"
    ),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List all snapshots of a collection."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/collections/{collection_id}/snapshots"

    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=30)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to list snapshots: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    snapshots = response.json()

    if format in ["json", "yaml"]:
        console.print(format_output(snapshots, format))
        return

    if not snapshots:
        typer.secho("No snapshots found for this collection.", fg=typer.colors.YELLOW)
        return

    console.print(
        render_collections_tree(snapshots, title=f"Snapshots of {collection_id}")
    )


# -----------------------------------------------------------------------------
# Governance Commands
# -----------------------------------------------------------------------------


def _format_task_status(status: str) -> str:
    """Format task status with color."""
    colors = {
        "open": "yellow",
        "in_progress": "cyan",
        "resolved": "green",
        "dismissed": "dim",
    }
    return f"[{colors.get(status, 'white')}]{status}[/{colors.get(status, 'white')}]"


def _format_priority(priority: str) -> str:
    """Format priority with color."""
    colors = {
        "critical": "red",
        "high": "orange1",
        "medium": "yellow",
        "low": "dim",
    }
    return (
        f"[{colors.get(priority, 'white')}]{priority}[/{colors.get(priority, 'white')}]"
    )


def _resolve_governance_task_id(api_base: str, partial_id: str) -> str:
    """Resolve a partial task ID to a full UUID.

    Supports partial ID matching like git does with commit SHAs.
    Returns the full task ID if exactly one match is found.
    """
    if len(partial_id) == 36 and partial_id.count("-") == 4:
        return partial_id

    endpoint = f"{api_base.rstrip('/')}/api/governance/tasks"
    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPError:
        return partial_id

    tasks = response.json()
    matches = [t for t in tasks if t.get("id", "").startswith(partial_id)]

    if len(matches) == 1:
        return matches[0]["id"]
    if len(matches) > 1:
        typer.secho(
            f"Ambiguous task ID '{partial_id}' matches {len(matches)} tasks:",
            fg=typer.colors.RED,
        )
        for m in matches[:5]:
            typer.echo(f"  {m['id'][:8]} - {m.get('title', '')[:40]}")
        raise typer.Exit(code=1)

    return partial_id


def _render_governance_task_tree(tasks: list) -> Tree:
    """Render governance tasks as a tree."""
    tree = Tree("[bold]Governance Tasks[/bold]")
    for task in tasks:
        status = task.get("status", "unknown")
        priority = task.get("priority", "medium")
        title = task.get("title", "Untitled")
        task_id = task.get("id", "")[:8]

        branch = tree.add(
            f"[cyan]{task_id}[/cyan] {title} {_format_task_status(status)} {_format_priority(priority)}"
        )
        branch.add(f"[dim]Type: {task.get('task_type', 'unknown')}[/dim]")
        if task.get("experiment_id"):
            branch.add(f"[dim]Experiment: {task.get('experiment_id')}[/dim]")
        if task.get("assigned_to_name"):
            branch.add(f"[dim]Assigned: {task.get('assigned_to_name')}[/dim]")
        branch.add(f"[dim]Created: {task.get('created_at', '')}[/dim]")
    return tree


@governance_app.command("list")
def governance_list(
    task_type: str | None = typer.Option(
        None,
        "--type",
        "-t",
        help="Filter by type: duplicate_review, missing_metadata, validation_failure, enrichment_required",
    ),
    status: str | None = typer.Option(
        None,
        "--status",
        "-s",
        help="Filter by status: open, in_progress, resolved, dismissed",
    ),
    experiment: str | None = typer.Option(
        None, "--experiment", "-e", help="Filter by experiment ID"
    ),
    artifact: str | None = typer.Option(
        None, "--artifact", "-a", help="Filter by artifact ID"
    ),
    mine: bool = typer.Option(
        False, "--mine", "-m", help="Show only tasks assigned to me"
    ),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    limit: int = typer.Option(
        50, "--limit", "-n", help="Maximum number of tasks to return"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List governance tasks."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/governance/tasks"

    params: dict[str, str | int] = {"limit": limit}
    if task_type:
        params["task_type"] = task_type
    if status:
        params["status"] = status
    if experiment:
        params["experiment_id"] = experiment
    if artifact:
        params["artifact_id"] = artifact
    if mine:
        params["assigned_to_me"] = "true"

    try:
        response = httpx.get(
            endpoint, headers=get_auth_headers(), params=params, timeout=10
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 401:
            typer.secho(
                "Authentication required. Run: diffuse auth login", fg=typer.colors.RED
            )
            raise typer.Exit(code=1) from exc
        if exc.response.status_code == 403:
            typer.secho("Access denied.", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to list tasks: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to list tasks: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    tasks = response.json()
    if not tasks:
        typer.echo("No governance tasks found.")
        return

    if format in ["json", "yaml"]:
        console.print(format_output(tasks, format))
        return

    if format == "table":
        table = Table(title="Governance Tasks")
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Title", style="bold")
        table.add_column("Type")
        table.add_column("Status", justify="center")
        table.add_column("Priority", justify="center")
        table.add_column("Assigned To")
        for task in tasks:
            table.add_row(
                task.get("id", "")[:8],
                (task.get("title", "") or "")[:40],
                task.get("task_type", ""),
                task.get("status", ""),
                task.get("priority", ""),
                task.get("assigned_to_name", "") or "-",
            )
        console.print(table)
        return

    console.print(_render_governance_task_tree(tasks))


@governance_app.command("view")
def governance_view(
    task_id: str = typer.Argument(..., help="Task ID"),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """View governance task details."""
    api = get_api_base(server)
    resolved_id = _resolve_governance_task_id(api, task_id)
    endpoint = f"{api.rstrip('/')}/api/governance/tasks/{resolved_id}"

    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            typer.secho(f"Task not found: {task_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to get task: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to get task: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    task = response.json()

    if format in ["json", "yaml"]:
        console.print(format_output(task, format))
        return

    if format == "table":
        table = Table(show_header=False, box=None)
        table.add_column("Field", style="dim", width=18)
        table.add_column("Value")
        table.add_row("ID", task.get("id", ""))
        table.add_row("Title", task.get("title", ""))
        table.add_row("Type", task.get("task_type", ""))
        table.add_row("Status", task.get("status", ""))
        table.add_row("Priority", task.get("priority", ""))
        table.add_row("Description", (task.get("description", "") or "-")[:100])
        table.add_row("Assigned To", task.get("assigned_to_name", "") or "-")
        table.add_row("Experiment", task.get("experiment_id", "") or "-")
        table.add_row("Artifact", task.get("artifact_id", "") or "-")
        table.add_row("Created", task.get("created_at", ""))
        table.add_row("Updated", task.get("updated_at", ""))
        if task.get("resolved_at"):
            table.add_row("Resolved At", task.get("resolved_at", ""))
            table.add_row("Resolved By", task.get("resolved_by_name", "") or "-")
            table.add_row("Resolution", (task.get("resolution_notes", "") or "-")[:100])
        console.print(table)
        return

    tree = Tree(f"[bold]{task.get('title', 'Task')}[/bold]")
    tree.add(f"[cyan]ID:[/cyan] {task.get('id', '')}")
    tree.add(f"[cyan]Type:[/cyan] {task.get('task_type', '')}")
    tree.add(f"[cyan]Status:[/cyan] {_format_task_status(task.get('status', ''))}")
    tree.add(f"[cyan]Priority:[/cyan] {_format_priority(task.get('priority', ''))}")
    if task.get("description"):
        tree.add(f"[cyan]Description:[/cyan] {task.get('description', '')}")
    tree.add(
        f"[cyan]Assigned To:[/cyan] {task.get('assigned_to_name', '') or 'Unassigned'}"
    )
    if task.get("experiment_id"):
        tree.add(f"[cyan]Experiment:[/cyan] {task.get('experiment_id', '')}")
    if task.get("artifact_id"):
        tree.add(f"[cyan]Artifact:[/cyan] {task.get('artifact_id', '')}")
    tree.add(f"[dim]Created: {task.get('created_at', '')}[/dim]")
    tree.add(f"[dim]Updated: {task.get('updated_at', '')}[/dim]")
    if task.get("resolved_at"):
        resolution = tree.add("[green]Resolution[/green]")
        resolution.add(f"Resolved at: {task.get('resolved_at', '')}")
        resolution.add(f"Resolved by: {task.get('resolved_by_name', '') or '-'}")
        if task.get("resolution_notes"):
            resolution.add(f"Notes: {task.get('resolution_notes', '')}")
    console.print(tree)


@governance_app.command("create")
def governance_create(
    title: str = typer.Option(..., "--title", "-t", help="Task title"),
    task_type: str = typer.Option(
        ...,
        "--type",
        help="Task type: duplicate_review, missing_metadata, validation_failure, enrichment_required",
    ),
    priority: str = typer.Option(
        "medium", "--priority", "-p", help="Priority: low, medium, high, critical"
    ),
    description: str | None = typer.Option(
        None, "--description", "-d", help="Task description"
    ),
    experiment: str | None = typer.Option(
        None, "--experiment", "-e", help="Related experiment ID"
    ),
    artifact: str | None = typer.Option(
        None, "--artifact", "-a", help="Related artifact ID"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Create a governance task."""
    api = get_api_base(server)
    endpoint = f"{api.rstrip('/')}/api/governance/tasks"

    payload: dict[str, str] = {
        "title": title,
        "task_type": task_type,
        "priority": priority,
    }
    if description:
        payload["description"] = description
    if experiment:
        payload["experiment_id"] = experiment
    if artifact:
        payload["artifact_id"] = artifact

    try:
        response = httpx.post(
            endpoint, headers=get_auth_headers(), json=payload, timeout=10
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 403:
            typer.secho(
                "Access denied. Admin or member role required.", fg=typer.colors.RED
            )
            raise typer.Exit(code=1) from exc
        detail = exc.response.json().get("detail", str(exc))
        typer.secho(f"Failed to create task: {detail}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to create task: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    task = response.json()
    typer.secho(f"Task created: {task.get('id', '')}", fg=typer.colors.GREEN)


@governance_app.command("update")
def governance_update(
    task_id: str = typer.Argument(..., help="Task ID"),
    title: str | None = typer.Option(None, "--title", "-t", help="New title"),
    description: str | None = typer.Option(
        None, "--description", "-d", help="New description"
    ),
    status: str | None = typer.Option(
        None, "--status", "-s", help="New status: open, in_progress"
    ),
    priority: str | None = typer.Option(
        None, "--priority", "-p", help="New priority: low, medium, high, critical"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Update a governance task."""
    api = get_api_base(server)
    resolved_id = _resolve_governance_task_id(api, task_id)
    endpoint = f"{api.rstrip('/')}/api/governance/tasks/{resolved_id}"

    payload: dict[str, str] = {}
    if title is not None:
        payload["title"] = title
    if description is not None:
        payload["description"] = description
    if status is not None:
        payload["status"] = status
    if priority is not None:
        payload["priority"] = priority

    if not payload:
        typer.secho("No updates specified.", fg=typer.colors.YELLOW)
        return

    try:
        response = httpx.patch(
            endpoint, headers=get_auth_headers(), json=payload, timeout=10
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            typer.secho(f"Task not found: {task_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to update task: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to update task: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"Task updated: {task_id}", fg=typer.colors.GREEN)


@governance_app.command("resolve")
def governance_resolve(
    task_id: str = typer.Argument(..., help="Task ID"),
    notes: str | None = typer.Option(None, "--notes", "-n", help="Resolution notes"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Resolve a governance task."""
    api = get_api_base(server)
    resolved_id = _resolve_governance_task_id(api, task_id)
    endpoint = f"{api.rstrip('/')}/api/governance/tasks/{resolved_id}/resolve"

    payload: dict[str, str] = {}
    if notes:
        payload["resolution_notes"] = notes

    try:
        response = httpx.post(
            endpoint, headers=get_auth_headers(), json=payload, timeout=10
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            typer.secho(f"Task not found: {task_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to resolve task: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to resolve task: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"Task resolved: {task_id}", fg=typer.colors.GREEN)


@governance_app.command("dismiss")
def governance_dismiss(
    task_id: str = typer.Argument(..., help="Task ID"),
    reason: str = typer.Option(..., "--reason", "-r", help="Reason for dismissal"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Dismiss a governance task."""
    api = get_api_base(server)
    resolved_id = _resolve_governance_task_id(api, task_id)
    endpoint = f"{api.rstrip('/')}/api/governance/tasks/{resolved_id}/dismiss"

    try:
        response = httpx.post(
            endpoint, headers=get_auth_headers(), json={"reason": reason}, timeout=10
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            typer.secho(f"Task not found: {task_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to dismiss task: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to dismiss task: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"Task dismissed: {task_id}", fg=typer.colors.GREEN)


@governance_app.command("delete")
def governance_delete(
    task_id: str = typer.Argument(..., help="Task ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Delete a governance task (admin only)."""
    api = get_api_base(server)
    resolved_id = _resolve_governance_task_id(api, task_id)

    if not yes:
        confirm = typer.confirm(f"Delete task {resolved_id[:8]}?")
        if not confirm:
            raise typer.Abort()

    endpoint = f"{api.rstrip('/')}/api/governance/tasks/{resolved_id}"

    try:
        response = httpx.delete(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 403:
            typer.secho("Access denied. Admin role required.", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        if exc.response.status_code == 404:
            typer.secho(f"Task not found: {task_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to delete task: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to delete task: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"Task deleted: {task_id}", fg=typer.colors.GREEN)


@governance_app.command("comment")
def governance_add_comment(
    task_id: str = typer.Argument(..., help="Task ID"),
    content: str = typer.Option(..., "--content", "-c", help="Comment text"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Add a comment to a governance task."""
    api = get_api_base(server)
    resolved_id = _resolve_governance_task_id(api, task_id)
    endpoint = f"{api.rstrip('/')}/api/governance/tasks/{resolved_id}/comments"

    try:
        response = httpx.post(
            endpoint,
            headers=get_auth_headers(),
            json={"content": content},
            timeout=10,
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            typer.secho(f"Task not found: {task_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to add comment: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to add comment: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho("Comment added.", fg=typer.colors.GREEN)


@governance_app.command("comments")
def governance_list_comments(
    task_id: str = typer.Argument(..., help="Task ID"),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List comments on a governance task."""
    api = get_api_base(server)
    resolved_id = _resolve_governance_task_id(api, task_id)
    endpoint = f"{api.rstrip('/')}/api/governance/tasks/{resolved_id}/comments"

    try:
        response = httpx.get(endpoint, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            typer.secho(f"Task not found: {task_id}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to list comments: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to list comments: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    comments = response.json()

    if format == "json":
        console.print_json(data=comments)
        return
    if format == "yaml":
        import yaml

        console.print(yaml.dump(comments, default_flow_style=False))
        return

    if not comments:
        typer.secho("No comments found.", fg=typer.colors.YELLOW)
        return

    from rich.table import Table

    if format == "table":
        table = Table(show_lines=True)
        table.add_column("Author", style="bold")
        table.add_column("Content")
        table.add_column("Created", style="dim")
        for c in comments:
            table.add_row(
                c.get("author_name") or "—",
                c.get("content", ""),
                c.get("created_at", "")[:19],
            )
        console.print(table)
        return

    # Default: tree format
    from rich.tree import Tree

    tree = Tree(f"[bold]Comments on {task_id}[/bold]")
    for c in comments:
        author = c.get("author_name") or "Unknown"
        created = c.get("created_at", "")[:19]
        branch = tree.add(f"[bold]{author}[/bold] [dim]{created}[/dim]")
        branch.add(c.get("content", ""))
    console.print(tree)


@governance_app.command("scan")
def governance_scan(
    scan_type: str = typer.Argument(..., help="Scan type: duplicates or enrich"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Trigger a governance scan (admin only).

    Scan types:
      duplicates  - Scan for duplicate artifacts
      enrich      - Trigger MIME type enrichment for pending artifacts
    """
    api = get_api_base(server)

    scan_map = {
        "duplicates": "/api/governance/flows/scan-duplicates",
        "enrich": "/api/governance/flows/enrich-pending",
    }

    if scan_type not in scan_map:
        typer.secho(
            f"Unknown scan type: {scan_type}. Use 'duplicates' or 'enrich'.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    endpoint = f"{api.rstrip('/')}{scan_map[scan_type]}"

    try:
        response = httpx.post(endpoint, headers=get_auth_headers(), timeout=30)
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 403:
            typer.secho("Access denied. Admin role required.", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        typer.secho(f"Failed to trigger scan: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to trigger scan: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    data = response.json()
    typer.secho(f"Scan queued: {data.get('message', scan_type)}", fg=typer.colors.GREEN)


# ── flow: K8s experiment jobs ─────────────────────────────────────────

# Generic K8s status colors — shared by all experiment types.
_K8S_STATUS_COLOR: dict[str, str] = {
    "completed": "green",
    "failed": "red",
    "running": "yellow",
    "pending": "dim",
}

# Maximum time (seconds) to wait before giving up on a stuck job.
_POLL_TIMEOUT_SECONDS = 4 * 3600  # 4 hours
_POLL_INTERVAL_SECONDS = 15
_POLL_RETRY_INTERVAL_SECONDS = 10
_POLL_MAX_CONSECUTIVE_ERRORS = 12  # 2 minutes of consecutive failures


def _poll_k8s_job(api: str, job_name: str, machine: str | None = None) -> None:
    """Poll a K8s job until it completes or times out (generic)."""
    import time

    typer.echo(f"Polling {job_name}...")
    start = time.monotonic()
    consecutive_errors = 0

    while True:
        elapsed = time.monotonic() - start
        if elapsed > _POLL_TIMEOUT_SECONDS:
            typer.secho(
                f"  {job_name}: timed out after {_POLL_TIMEOUT_SECONDS // 3600}h",
                fg=typer.colors.YELLOW,
            )
            return

        try:
            params: dict = {}
            if machine:
                params["machine"] = machine
            response = httpx.get(
                f"{api.rstrip('/')}/api/k8s/jobs/{job_name}",
                params=params,
                headers=get_auth_headers(),
                timeout=10,
            )
            response.raise_for_status()
            consecutive_errors = 0
        except httpx.HTTPError as exc:
            consecutive_errors += 1
            if consecutive_errors >= _POLL_MAX_CONSECUTIVE_ERRORS:
                typer.secho(
                    f"  {job_name}: giving up after {consecutive_errors} consecutive errors: {exc}",
                    fg=typer.colors.RED,
                )
                return
            if consecutive_errors == 1 or consecutive_errors % 5 == 0:
                typer.secho(
                    f"  {job_name}: poll error ({consecutive_errors}x): {exc}",
                    fg=typer.colors.YELLOW,
                )
            time.sleep(_POLL_RETRY_INTERVAL_SECONDS)
            continue

        data = response.json()
        status_val = data.get("status", "unknown")

        if status_val == "completed":
            typer.secho(f"  {job_name}: completed", fg=typer.colors.GREEN)
            return
        elif status_val == "failed":
            typer.secho(f"  {job_name}: failed", fg=typer.colors.RED)
            return
        else:
            typer.echo(f"  {job_name}: {status_val} (active={data.get('active', 0)})")
            time.sleep(_POLL_INTERVAL_SECONDS)


# ── flow sampleworks (sampleworks-specific) ──────────────────────────


@flow_app.command("sampleworks")
def flow_sampleworks(
    preset: str = typer.Argument(
        "all",
        help="Job preset: boltz2-xrd, boltz2-md, protenix, rf3, or 'all' (default)",
    ),
    wait: bool = typer.Option(
        False, "--wait", "-w", help="Wait for the K8s job to complete"
    ),
    gradient_weights: str | None = typer.Option(
        None,
        "--gradient-weights",
        "-g",
        help="Override gradient weights (space-separated, e.g. '0.1 0.2 0.5')",
    ),
    ensemble_sizes: str | None = typer.Option(
        None,
        "--ensemble-sizes",
        "-e",
        help="Override ensemble sizes (space-separated, e.g. '4 8')",
    ),
    machine: str | None = typer.Option(
        None,
        "--machine",
        "-m",
        help="Compute resource name to target (default: auto-resolve)",
    ),
    input_path: str | None = typer.Option(
        None,
        "--input-path",
        "-i",
        help="Host path for input data directory on the compute resource",
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Run a sampleworks grid-search job on the compute cluster.

    With no arguments, runs all four presets in parallel (8 GPUs total).

    Presets:
      all          Run all four presets in parallel (default)
      boltz2-xrd   Boltz2 with X-ray diffraction (2 GPUs)
      boltz2-md    Boltz2 with molecular dynamics (2 GPUs)
      protenix     Protenix protein structure prediction (2 GPUs)
      rf3          RoseTTAFold3 (2 GPUs)

    Examples:
      diffuse run sampleworks
      diffuse run sampleworks boltz2-xrd
      diffuse run sampleworks rf3 --wait
      diffuse run sampleworks all -g "0.1 0.2"
      diffuse run sampleworks boltz2-xrd --machine sampleworks
      diffuse run sampleworks boltz2-xrd -i /data/my_proteins
    """
    api = get_api_base(server)
    valid = ["boltz2-xrd", "boltz2-md", "protenix", "rf3", "all"]
    if preset not in valid:
        typer.secho(
            f"Unknown preset '{preset}'. Valid: {', '.join(valid)}",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    if preset == "all":
        _flow_sampleworks_all(
            api, wait, gradient_weights, ensemble_sizes, machine, input_path
        )
        return

    payload: dict = {
        "preset": preset,
        "wait": wait,
    }
    if gradient_weights:
        payload["gradient_weights"] = gradient_weights
    if ensemble_sizes:
        payload["ensemble_sizes"] = ensemble_sizes
    if machine:
        payload["machine"] = machine
    if input_path:
        payload["input_host_path"] = input_path

    typer.secho(f"Submitting sampleworks job: {preset}", fg=typer.colors.CYAN)

    try:
        response = httpx.post(
            f"{api.rstrip('/')}/api/sampleworks/run",
            headers=get_auth_headers(),
            json=payload,
            timeout=30,
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to submit job: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    data = response.json()
    typer.secho(f"Job queued: {data['job_name']}", fg=typer.colors.GREEN)
    if data.get("prefect_flow_run_id"):
        typer.echo(f"  Prefect flow run: {data['prefect_flow_run_id']}")
    typer.echo(f"  Status: {data['status']}")
    typer.echo(f"  {data['message']}")

    if wait:
        typer.echo()
        _poll_k8s_job(api, data["job_name"], machine=machine)


def _flow_sampleworks_all(
    api: str,
    wait: bool,
    gradient_weights: str | None,
    ensemble_sizes: str | None,
    machine: str | None = None,
    input_path: str | None = None,
) -> None:
    """Submit all sampleworks presets."""
    presets = ["boltz2-xrd", "boltz2-md", "protenix", "rf3"]
    typer.secho(f"Submitting {len(presets)} sampleworks jobs...", fg=typer.colors.CYAN)

    for preset_name in presets:
        payload: dict = {"preset": preset_name, "wait": False}
        if gradient_weights:
            payload["gradient_weights"] = gradient_weights
        if ensemble_sizes:
            payload["ensemble_sizes"] = ensemble_sizes
        if machine:
            payload["machine"] = machine
        if input_path:
            payload["input_host_path"] = input_path

        try:
            response = httpx.post(
                f"{api.rstrip('/')}/api/sampleworks/run",
                headers=get_auth_headers(),
                json=payload,
                timeout=30,
            )
            response.raise_for_status()
            data = response.json()
            typer.secho(
                f"  {preset_name}: queued ({data['job_name']})", fg=typer.colors.GREEN
            )
        except httpx.HTTPError as exc:
            typer.secho(f"  {preset_name}: failed ({exc})", fg=typer.colors.RED)

    if wait:
        typer.echo()
        typer.secho("Polling all jobs...", fg=typer.colors.CYAN)
        for preset_name in presets:
            _poll_k8s_job(api, f"sampleworks-{preset_name}", machine=machine)


# ── flow waterflow (waterflow-specific) ──────────────────────────────


@flow_app.command("waterflow")
def flow_waterflow(
    preset: str = typer.Argument(
        "train-gvp",
        help="Job preset: train-gvp, train-esm, train-slae, inference, generate-esm",
    ),
    wait: bool = typer.Option(
        False, "--wait", "-w", help="Wait for the K8s job to complete"
    ),
    epochs: int | None = typer.Option(None, "--epochs", help="Override epoch count"),
    batch_size: int | None = typer.Option(
        None, "--batch-size", "-b", help="Override batch size"
    ),
    lr: float | None = typer.Option(None, "--lr", help="Override learning rate"),
    encoder_type: str | None = typer.Option(
        None, "--encoder", help="Override encoder type (gvp, esm, slae)"
    ),
    run_name: str | None = typer.Option(
        None, "--run-name", "-n", help="Custom run name for checkpoints"
    ),
    run_dir: str | None = typer.Option(
        None, "--run-dir", help="Training run dir (required for inference)"
    ),
    num_steps: int | None = typer.Option(
        None, "--num-steps", help="Override inference integration steps"
    ),
    train_list: str | None = typer.Option(
        None, "--train-list", help="Override train split file path"
    ),
    val_list: str | None = typer.Option(
        None, "--val-list", help="Override validation split file path"
    ),
    pdb_list: str | None = typer.Option(
        None, "--pdb-list", help="Override PDB list for inference"
    ),
    split_file: str | None = typer.Option(
        None, "--split-file", help="Override split file for ESM generation"
    ),
    wandb_key: str | None = typer.Option(
        None, "--wandb-key", help="W&B API key (omit to disable)"
    ),
    wandb_project: str | None = typer.Option(
        None, "--wandb-project", help="W&B project name"
    ),
    machine: str | None = typer.Option(
        None, "--machine", "-m", help="Compute resource name to target"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Run a WaterFlow job on the compute cluster.

    Presets:
      train-gvp     Train with GVP encoder (default)
      train-esm     Train with ESM encoder
      train-slae    Train with SLAE encoder
      inference     Run inference with a trained checkpoint
      generate-esm  Generate ESM3 embeddings

    Examples:
      diffuse run waterflow
      diffuse run waterflow train-esm
      diffuse run waterflow train-gvp --epochs 100 --batch-size 8
      diffuse run waterflow train-gvp -n my_experiment --wait
      diffuse run waterflow inference --run-dir /data/checkpoints/my_run
      diffuse run waterflow generate-esm --split-file /data/splits/train.txt
      diffuse run waterflow train-esm --machine my-gpu-box
    """
    api = get_api_base(server)
    valid = ["train-gvp", "train-esm", "train-slae", "inference", "generate-esm"]
    if preset not in valid:
        typer.secho(
            f"Unknown preset '{preset}'. Valid: {', '.join(valid)}",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    payload: dict = {
        "preset": preset,
        "wait": wait,
    }
    if epochs is not None:
        payload["epochs"] = epochs
    if batch_size is not None:
        payload["batch_size"] = batch_size
    if lr is not None:
        payload["lr"] = lr
    if encoder_type:
        payload["encoder_type"] = encoder_type
    if run_name:
        payload["run_name"] = run_name
    if run_dir:
        payload["run_dir"] = run_dir
    if num_steps is not None:
        payload["num_steps"] = num_steps
    if train_list:
        payload["train_list"] = train_list
    if val_list:
        payload["val_list"] = val_list
    if pdb_list:
        payload["pdb_list"] = pdb_list
    if split_file:
        payload["split_file"] = split_file
    if wandb_key:
        payload["wandb_api_key"] = wandb_key
    if wandb_project:
        payload["wandb_project"] = wandb_project
    if machine:
        payload["machine"] = machine

    typer.secho(f"Submitting waterflow job: {preset}", fg=typer.colors.CYAN)

    try:
        response = httpx.post(
            f"{api.rstrip('/')}/api/waterflow/run",
            headers=get_auth_headers(),
            json=payload,
            timeout=30,
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to submit job: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    data = response.json()
    typer.secho(f"Job queued: {data['job_name']}", fg=typer.colors.GREEN)
    if data.get("prefect_flow_run_id"):
        typer.echo(f"  Prefect flow run: {data['prefect_flow_run_id']}")
    typer.echo(f"  Status: {data['status']}")
    typer.echo(f"  {data['message']}")

    if wait:
        typer.echo()
        _poll_k8s_job(api, data["job_name"], machine=machine)


# ── flow status / logs / presets (generic K8s + sampleworks) ─────────


@flow_app.command("status")
def flow_status(
    job_name: str | None = typer.Argument(
        None, help="Job name (e.g. sampleworks-boltz2-xrd). Omit to list all."
    ),
    label_selector: str | None = typer.Option(
        None, "--label", "-l", help="K8s label selector (e.g. 'app=sampleworks')"
    ),
    machine: str | None = typer.Option(
        None,
        "--machine",
        "-m",
        help="Compute resource name to target (default: auto-resolve)",
    ),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Show status of K8s experiment jobs.

    Examples:
      diffuse run status
      diffuse run status sampleworks-boltz2-xrd
      diffuse run status -l app=sampleworks
      diffuse run status -f json
      diffuse run status --machine sampleworks
    """
    api = get_api_base(server)

    if job_name:
        try:
            params: dict = {}
            if machine:
                params["machine"] = machine
            response = httpx.get(
                f"{api.rstrip('/')}/api/k8s/jobs/{job_name}",
                params=params,
                headers=get_auth_headers(),
                timeout=10,
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            typer.secho(f"Failed to get job status: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc

        data = response.json()
        if format == "json":
            typer.echo(json.dumps(data, indent=2))
            return

        table = Table(show_header=False, box=None)
        table.add_column("Field", style="dim", width=18)
        table.add_column("Value")
        table.add_row("Name", data.get("name", ""))
        table.add_row("Model", data.get("model", ""))
        status_val = data.get("status", "unknown")
        sc = _K8S_STATUS_COLOR.get(status_val, "white")
        table.add_row("Status", f"[{sc}]{status_val}[/{sc}]")
        table.add_row("Created", data.get("created", "N/A"))
        table.add_row("Active", str(data.get("active", 0)))
        table.add_row("Succeeded", str(data.get("succeeded", 0)))
        table.add_row("Failed", str(data.get("failed", 0)))
        console.print(table)
        return

    # List all jobs
    try:
        list_params: dict = {}
        if label_selector:
            list_params["label_selector"] = label_selector
        if machine:
            list_params["machine"] = machine
        response = httpx.get(
            f"{api.rstrip('/')}/api/k8s/jobs",
            params=list_params,
            headers=get_auth_headers(),
            timeout=10,
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to list jobs: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    jobs = response.json()

    if format == "json":
        typer.echo(json.dumps(jobs, indent=2))
        return

    if not jobs:
        typer.echo("No K8s jobs found.")
        return

    if format == "table":
        table = Table(show_lines=False, show_header=True)
        table.add_column("Name", style="cyan", no_wrap=True)
        table.add_column("Model", style="bold")
        table.add_column("Status", justify="center")
        table.add_column("Active", justify="center")
        table.add_column("Created", style="dim")
        for j in jobs:
            status_val = j.get("status", "unknown")
            sc = _K8S_STATUS_COLOR.get(status_val, "white")
            table.add_row(
                j.get("name", ""),
                j.get("model", ""),
                f"[{sc}]{status_val}[/{sc}]",
                str(j.get("active", 0)),
                (j.get("created") or "")[:16],
            )
        console.print(table)
    else:
        tree = Tree("[bold]K8s Jobs[/bold]")
        for j in jobs:
            status_val = j.get("status", "unknown")
            sc = _K8S_STATUS_COLOR.get(status_val, "white")
            branch = tree.add(
                f"[cyan]{j.get('name', '')}[/cyan] [{sc}]{status_val}[/{sc}]"
            )
            branch.add(f"[dim]Model: {j.get('model', '')}[/dim]")
            branch.add(f"[dim]Created: {(j.get('created') or 'N/A')[:16]}[/dim]")
            if j.get("active", 0) > 0:
                branch.add(f"Active: {j['active']}")
        console.print(tree)


@flow_app.command("logs")
def flow_logs(
    job_name: str = typer.Argument(..., help="Job name (e.g. sampleworks-boltz2-xrd)"),
    tail: int = typer.Option(200, "--tail", "-n", help="Number of tail lines to fetch"),
    machine: str | None = typer.Option(
        None,
        "--machine",
        "-m",
        help="Compute resource name to target (default: auto-resolve)",
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Fetch logs from a K8s experiment job.

    Examples:
      diffuse run logs sampleworks-rf3
      diffuse run logs sampleworks-boltz2-xrd --tail 500
      diffuse run logs sampleworks-rf3 --machine sampleworks
    """
    api = get_api_base(server)

    try:
        log_params: dict = {"tail": tail}
        if machine:
            log_params["machine"] = machine
        response = httpx.get(
            f"{api.rstrip('/')}/api/k8s/jobs/{job_name}/logs",
            params=log_params,
            headers=get_auth_headers(),
            timeout=30,
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to fetch logs: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    data = response.json()
    typer.echo(data.get("logs", ""))


@flow_app.command("presets")
def flow_presets(
    experiment_type: str | None = typer.Option(
        None,
        "--type",
        "-t",
        help="Filter by type: sampleworks, waterflow (default: show all)",
    ),
    format: str = typer.Option(
        "tree", "--format", "-f", help="Output format: tree, table, json"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List available experiment job presets.

    Examples:
      diffuse run presets
      diffuse run presets -t waterflow
      diffuse run presets -t sampleworks -f table
    """
    api = get_api_base(server)

    url = f"{api.rstrip('/')}/api/run/presets"
    if experiment_type:
        url += f"?experiment_type={experiment_type}"

    try:
        response = httpx.get(url, headers=get_auth_headers(), timeout=10)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        typer.secho(f"Failed to list presets: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    all_presets = response.json()

    if format == "json":
        typer.echo(json.dumps(all_presets, indent=2))
        return

    if format == "table":
        table = Table(show_lines=False, show_header=True)
        table.add_column("Type", style="magenta", no_wrap=True)
        table.add_column("Preset", style="cyan", no_wrap=True)
        table.add_column("Command/Model", style="bold")
        table.add_column("GPUs", justify="center")
        table.add_column("Details")
        for exp_type, presets in all_presets.items():
            for p in presets:
                detail = ""
                if exp_type == "sampleworks":
                    detail = f"gw={p.get('gradient_weights', '')} ens={p.get('ensemble_sizes', '')}"
                elif exp_type == "waterflow":
                    detail = (
                        f"enc={p.get('encoder_type', '')} epochs={p.get('epochs', '')}"
                    )
                table.add_row(
                    exp_type,
                    p.get("name", ""),
                    p.get("model", p.get("command", "")),
                    str(p.get("gpu_count", 1)),
                    detail,
                )
        console.print(table)
    else:
        root = Tree("[bold]Experiment Presets[/bold]")
        for exp_type, presets in all_presets.items():
            type_branch = root.add(f"[bold magenta]{exp_type}[/bold magenta]")
            for p in presets:
                branch = type_branch.add(f"[cyan]{p.get('name', '')}[/cyan]")
                if exp_type == "sampleworks":
                    branch.add(f"Model: [bold]{p.get('model', '')}[/bold]")
                    if p.get("methods"):
                        branch.add(f"Method: {p['methods']}")
                    branch.add(f"GPUs: {p.get('gpu_count', 2)}")
                    branch.add(f"Gradient weights: {p.get('gradient_weights', '')}")
                    branch.add(f"Ensemble sizes: {p.get('ensemble_sizes', '')}")
                elif exp_type == "waterflow":
                    branch.add(f"Command: [bold]{p.get('command', '')}[/bold]")
                    if p.get("encoder_type"):
                        branch.add(f"Encoder: {p['encoder_type']}")
                    branch.add(f"GPUs: {p.get('gpu_count', 1)}")
                    if p.get("epochs"):
                        branch.add(f"Epochs: {p['epochs']}")
                    if p.get("batch_size"):
                        branch.add(f"Batch size: {p['batch_size']}")
        console.print(root)


@app.callback(invoke_without_command=True)
def main_callback(
    ctx: typer.Context,
    version: bool | None = typer.Option(
        None,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """Diffuse CLI."""
    check_for_updates()
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())


@keys_app.command("list")
def keys_list(
    format: str = typer.Option(
        "table", "--format", "-f", help="Output format: table, json, yaml"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """List personal API keys."""
    api = get_api_base(server)
    try:
        response = httpx.get(
            f"{api.rstrip('/')}/api/api-keys/personal",
            headers=get_auth_headers(),
            timeout=10,
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        typer.secho(f"Error: {exc.response.status_code}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Request failed: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    keys = response.json()

    if format in ("json", "yaml"):
        typer.echo(format_output(keys, format))
        return

    if not keys:
        typer.echo("No API keys found.")
        return

    table = Table(title="Personal API Keys")
    table.add_column("Name", style="bold")
    table.add_column("Key Prefix", style="cyan")
    table.add_column("Created", style="dim")
    table.add_column("Last Used", style="dim")
    table.add_column("Status", justify="center")

    for key in keys:
        status = (
            "[green]Active[/green]"
            if not key.get("revoked_at")
            else "[red]Revoked[/red]"
        )
        created = (key.get("created_at") or "")[:10]
        last_used = (key.get("last_used_at") or "Never")[:10]
        table.add_row(
            key.get("name", ""),
            key.get("key_prefix", ""),
            created,
            last_used,
            status,
        )

    console.print(table)


@keys_app.command("create")
def keys_create(
    name: str = typer.Argument(..., help="Name for the API key"),
    description: str | None = typer.Option(
        None, "--description", "-d", help="Description of the key's purpose"
    ),
    expires_in_days: int | None = typer.Option(
        None, "--expires-in-days", help="Days until expiry (omit for no expiry)"
    ),
    save: bool = typer.Option(
        False, "--save", help="Auto-save key to ~/.diffuse/config.json"
    ),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Create a personal API key."""
    api = get_api_base(server)
    payload: dict = {"name": name}
    if description:
        payload["description"] = description
    if expires_in_days:
        from datetime import datetime, timedelta, UTC

        expires_at = datetime.now(UTC) + timedelta(days=expires_in_days)
        payload["expires_at"] = expires_at.isoformat()

    try:
        response = httpx.post(
            f"{api.rstrip('/')}/api/api-keys/personal",
            json=payload,
            headers=get_auth_headers(),
            timeout=10,
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        typer.secho(f"Error: {exc.response.status_code}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Request failed: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    data = response.json()
    raw_key = data.get("key", "")

    console.print()
    console.print(
        Panel(
            f"[bold]Key:[/bold] [cyan]{raw_key}[/cyan]\n\n"
            "[yellow]Store this key securely — it will not be shown again.[/yellow]",
            title="API Key Created",
            border_style="green",
            padding=(1, 2),
        )
    )

    if save:
        config = load_config()
        config["api_key"] = raw_key
        save_config(config)
        typer.secho(f"✓ Key saved to {CONFIG_FILE}", fg=typer.colors.GREEN)


@keys_app.command("revoke")
def keys_revoke(
    key_id: str = typer.Argument(..., help="ID of the API key to revoke"),
    server: str | None = typer.Option(
        None, "--server", help="Base URL of the Diffuse API"
    ),
) -> None:
    """Revoke a personal API key."""
    confirmed = typer.confirm(f"Revoke key {key_id}?")
    if not confirmed:
        raise typer.Abort()

    api = get_api_base(server)
    try:
        response = httpx.delete(
            f"{api.rstrip('/')}/api/api-keys/personal/{key_id}",
            headers=get_auth_headers(),
            timeout=10,
        )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        typer.secho(f"Error: {exc.response.status_code}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        typer.secho(f"Request failed: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.secho(f"✓ Key {key_id} revoked", fg=typer.colors.GREEN)


@keys_app.command("set")
def keys_set(
    key: str = typer.Argument(..., help="API key string (starts with dfk_)"),
) -> None:
    """Save an API key to config (for keys created via the web UI)."""
    if not key.startswith("dfk_"):
        typer.secho("Invalid key format: must start with 'dfk_'", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    config = load_config()
    config["api_key"] = key
    save_config(config)
    typer.secho(f"✓ API key saved to {CONFIG_FILE}", fg=typer.colors.GREEN)


@keys_app.command("clear")
def keys_clear() -> None:
    """Remove stored API key from config."""
    config = load_config()
    if "api_key" not in config:
        typer.echo("No API key configured.")
        return
    config.pop("api_key")
    save_config(config)
    typer.secho("✓ API key removed from config", fg=typer.colors.GREEN)


if __name__ == "__main__":
    app()
