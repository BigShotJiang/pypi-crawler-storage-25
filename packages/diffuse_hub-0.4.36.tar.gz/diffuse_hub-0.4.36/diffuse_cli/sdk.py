"""Python SDK for Diffuse - use CLI functionality programmatically in notebooks/scripts.

Usage:
    from diffuse_cli.sdk import Diffuse

    # Connect to local server
    diffuse = Diffuse(server="http://localhost:8000")

    # List experiments
    experiments = diffuse.experiments.list()
    experiments = diffuse.experiments.list(query="tag:crystal", sort="recent")

    # Get experiment details
    exp = diffuse.experiments.get("EXP-1")

    # Create experiment
    exp = diffuse.experiments.create(title="My Experiment", tags=["ml", "vision"])

    # Update experiment
    diffuse.experiments.update("EXP-1", title="New Title")

    # List artifacts
    artifacts = diffuse.artifacts.list()

    # Get artifact info
    art = diffuse.artifacts.get("abc123")

    # External buckets (OSN, etc.)
    buckets = diffuse.external_buckets.list()
    listing = diffuse.external_buckets.browse("osn-diffuse-chess", prefix="data/")
    diffuse.external_buckets.attach_to_experiment("EXP-1", "osn-diffuse-chess", [{"s3_key": "data/x.h5"}])
    diffuse.external_buckets.attach_to_collection("COL-1", "osn-diffuse-chess", [{"s3_key": "data/x.h5"}])

    # Collection imports
    diffuse.collections.import_internal("COL-1", [{"s3_key": "raw/file.h5", "name": "file.h5"}])
    diffuse.collections.attach_external("COL-1", "ext-bucket", [{"s3_key": "data/x.csv"}])

    # Search — discover fields and values
    fields = diffuse.search.fields()  # all searchable fields
    tags = diffuse.search.values("tag")  # discover tag values
    print(diffuse.search.QUERY_SYNTAX)  # query syntax reference
    # Governance tasks
    tasks = diffuse.governance.list(status="open")
    diffuse.governance.resolve("task-id", notes="Fixed duplicate")
    diffuse.governance.add_comment("task-id", "Looks good")
    # Download artifact (returns presigned URL)
    url = diffuse.artifacts.download_url("abc123")

    # Experiment relationships
    rels = diffuse.relationships.list("EXP-1")
    diffuse.relationships.add("EXP-1", "EXP-2", relationship_type="uses")
    diffuse.relationships.remove("EXP-1", "EXP-1", "EXP-2", "uses")

    # Activity / audit trail
    events = diffuse.activity.list()

    # Admin operations (requires admin role)
    fields = diffuse.fields.list()
    new_field = diffuse.fields.create(
        key="resolution",
        display_name="Resolution",
        field_type="NUMBER",
        unit="angstrom"
    )

    types = diffuse.types.list()
    diffuse.types.set_fields(type_id, [field_id1, field_id2])
"""

from __future__ import annotations

import json
import mimetypes
import os
import time
from pathlib import Path
from typing import Any

import httpx


def _guess_content_type(path: Path) -> str:
    """Guess MIME type from file extension, defaulting to application/octet-stream."""
    mime_type, _ = mimetypes.guess_type(str(path))
    return mime_type or "application/octet-stream"


CONFIG_DIR = Path.home() / ".diffuse"
CONFIG_FILE = CONFIG_DIR / "config.json"
API_DEFAULT = "https://hub.diffuse.science"
ENV_URLS = {
    "local": "http://127.0.0.1:8000",
    "prod": "https://hub.diffuse.science",
}


def _load_config() -> dict[str, str]:
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def _save_config(config: dict[str, str]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def _get_api_base(server: str | None) -> str:
    if server:
        return server
    if env_var := os.getenv("DIFFUSE_API_URL"):
        return env_var
    if env_name := os.getenv("DIFFUSE_ENV"):
        if env_name in ENV_URLS:
            return ENV_URLS[env_name]
    config = _load_config()
    if api_url := config.get("api_url"):
        return api_url
    return API_DEFAULT


def _get_auth_headers() -> dict[str, str]:
    if api_key := os.getenv("DIFFUSE_API_KEY"):
        return {"Authorization": f"Bearer {api_key}"}
    config = _load_config()
    if api_key := config.get("api_key"):
        return {"Authorization": f"Bearer {api_key}"}
    if token := config.get("github_token"):
        return {"Authorization": f"Bearer {token}"}
    return {}


def login(server: str | None = None) -> str:
    """Authenticate with GitHub using device flow.

    Opens a browser for GitHub OAuth authentication. The token is stored
    in ~/.diffuse/config.json for future use.

    Args:
        server: API server URL (default: https://hub.diffuse.science)

    Returns:
        The GitHub access token.

    Raises:
        DiffuseError: If authentication fails or times out.

    Example:
        >>> from diffuse_cli import login, Diffuse
        >>> login()  # Opens browser, waits for auth
        >>> diffuse = Diffuse()  # Now authenticated
    """
    api = _get_api_base(server)

    # Get client ID from server
    try:
        resp = httpx.get(f"{api.rstrip('/')}/auth/client-id", timeout=5)
        resp.raise_for_status()
        client_id = resp.json()["client_id"]
    except httpx.HTTPError as exc:
        raise DiffuseError(f"Failed to get client ID from {api}: {exc}") from exc

    # Initiate device flow
    try:
        device_resp = httpx.post(
            "https://github.com/login/device/code",
            data={"client_id": client_id, "scope": "read:org"},
            headers={"Accept": "application/json"},
            timeout=15,
        )
        device_resp.raise_for_status()
    except httpx.HTTPError as exc:
        raise DiffuseError(f"Failed to initiate device flow: {exc}") from exc

    device_data = device_resp.json()
    device_code = device_data.get("device_code")
    user_code = device_data.get("user_code")
    verification_uri = device_data.get("verification_uri")
    interval = device_data.get("interval", 5)
    expires_in = device_data.get("expires_in", 900)

    if not all([device_code, user_code, verification_uri]):
        raise DiffuseError("Invalid device flow response from GitHub")

    # Display instructions
    print("\n" + "=" * 60)
    print(f"Visit: {verification_uri}")
    print(f"Enter code: {user_code}")
    print("=" * 60)
    print(f"\nWaiting for authorization (expires in {expires_in}s)...")

    # Poll for token
    start_time = time.time()
    while time.time() - start_time < expires_in:
        time.sleep(interval)

        try:
            token_resp = httpx.post(
                "https://github.com/login/oauth/access_token",
                data={
                    "client_id": client_id,
                    "device_code": device_code,
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                },
                headers={"Accept": "application/json"},
                timeout=15,
            )
            token_resp.raise_for_status()
        except httpx.HTTPError:
            continue

        token_data = token_resp.json()

        if "error" in token_data:
            error = token_data["error"]
            if error == "authorization_pending":
                continue
            if error == "slow_down":
                interval += 5
                continue
            if error in {"expired_token", "access_denied"}:
                raise DiffuseError(f"Authorization {error.replace('_', ' ')}")
            raise DiffuseError(f"GitHub error: {error}")

        access_token = token_data.get("access_token")
        if not access_token:
            raise DiffuseError("No access token received from GitHub")

        # Save token
        config = _load_config()
        config["github_token"] = access_token
        _save_config(config)

        print(f"\n✓ Authentication successful! Token stored in {CONFIG_FILE}")
        return access_token

    raise DiffuseError("Authorization timed out")


class DiffuseError(Exception):
    """Raised when an API call fails."""

    def __init__(
        self, message: str, status_code: int | None = None, detail: Any = None
    ):
        super().__init__(message)
        self.status_code = status_code
        self.detail = detail


class ExperimentsAPI:
    """Experiments API."""

    def __init__(self, client: httpx.Client, base_url: str):
        self._client = client
        self._base = f"{base_url.rstrip('/')}/api/experiments"

    def list(
        self,
        *,
        query: str | None = None,
        public: bool | None = None,
        sort: str = "recent",
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict]:
        """List experiments with optional filtering.

        Args:
            query: Search query (e.g., "tag:crystal AND resolution:>1.5")
            public: Filter by public status (True=public only, False=private only, None=all)
            sort: Sort order: "recent", "oldest", "title"
            limit: Max results to return
            offset: Pagination offset
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if query:
            params["q"] = query

        sort_map = {"recent": ("updated_at", "desc"), "oldest": ("updated_at", "asc")}
        if sort in sort_map:
            params["sort"], params["order"] = sort_map[sort]
        elif sort == "title":
            params["sort"] = "title"
            params["order"] = "asc"

        resp = self._client.get(self._base, params=params)
        self._raise_for_status(resp)
        experiments = resp.json()

        if public is True:
            experiments = [e for e in experiments if e.get("is_public")]
        elif public is False:
            experiments = [e for e in experiments if not e.get("is_public")]

        return experiments

    def get(self, experiment_id: str) -> dict:
        """Get experiment details by ID (display ID like EXP-1 or UUID)."""
        resp = self._client.get(f"{self._base}/{experiment_id}")
        self._raise_for_status(resp)
        return resp.json()

    def create(
        self,
        title: str,
        *,
        summary: str | None = None,
        tags: list[str] | None = None,
        markdown: str | None = None,
        type_id: str | None = None,
    ) -> dict:
        """Create a new experiment."""
        payload: dict[str, Any] = {"title": title}
        if summary:
            payload["summary"] = summary
        if tags:
            payload["tags"] = tags
        if markdown:
            payload["markdown"] = markdown
        if type_id:
            payload["type_id"] = type_id

        resp = self._client.post(self._base, json=payload)
        self._raise_for_status(resp)
        return resp.json()

    def update(
        self,
        experiment_id: str,
        *,
        title: str | None = None,
        summary: str | None = None,
        tags: list[str] | None = None,
        markdown: str | None = None,
    ) -> dict:
        """Update an experiment."""
        payload: dict[str, Any] = {}
        if title is not None:
            payload["title"] = title
        if summary is not None:
            payload["summary"] = summary
        if tags is not None:
            payload["tags"] = tags
        if markdown is not None:
            payload["markdown"] = markdown

        if not payload:
            return self.get(experiment_id)

        resp = self._client.patch(f"{self._base}/{experiment_id}", json=payload)
        self._raise_for_status(resp)
        return resp.json()

    def delete(self, experiment_id: str) -> None:
        """Delete an experiment."""
        resp = self._client.delete(f"{self._base}/{experiment_id}")
        self._raise_for_status(resp)

    def publish(self, experiment_id: str) -> dict:
        """Publish an experiment (make it public)."""
        resp = self._client.post(f"{self._base}/{experiment_id}/publish")
        self._raise_for_status(resp)
        return resp.json()

    def unpublish(self, experiment_id: str) -> dict:
        """Unpublish an experiment (make it private)."""
        resp = self._client.post(f"{self._base}/{experiment_id}/unpublish")
        self._raise_for_status(resp)
        return resp.json()

    def types(self) -> list[dict]:
        """List available experiment types."""
        resp = self._client.get(f"{self._base.rsplit('/', 1)[0]}/experiment-types")
        self._raise_for_status(resp)
        return resp.json()

    def activity(self, experiment_id: str, *, limit: int = 50) -> list[dict]:
        """Get activity log for an experiment."""
        resp = self._client.get(
            f"{self._base}/{experiment_id}/activity", params={"limit": limit}
        )
        self._raise_for_status(resp)
        return resp.json()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise DiffuseError(
            f"API error: {resp.status_code}",
            status_code=resp.status_code,
            detail=detail or resp.text,
        )


class ArtifactsAPI:
    """Artifacts API."""

    def __init__(self, client: httpx.Client, base_url: str):
        self._client = client
        self._base = f"{base_url.rstrip('/')}/api/artifacts"

    def list(
        self,
        *,
        experiment_id: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict]:
        """List artifacts, optionally filtered by experiment."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if experiment_id:
            params["experiment_id"] = experiment_id
        resp = self._client.get(self._base, params=params)
        self._raise_for_status(resp)
        return resp.json()

    def get(self, artifact_id: str) -> dict:
        """Get artifact details."""
        resp = self._client.get(f"{self._base}/{artifact_id}")
        self._raise_for_status(resp)
        return resp.json()

    def connect(
        self, artifact_id: str, experiment_id: str, *, path: str | None = None
    ) -> dict:
        """Connect an artifact to an experiment."""
        payload: dict[str, Any] = {"artifact_id": artifact_id}
        if path:
            payload["artifact_path"] = path
        resp = self._client.post(
            f"{self._base.rsplit('/', 1)[0]}/experiments/{experiment_id}/artifacts/connect",
            json=payload,
        )
        self._raise_for_status(resp)
        return resp.json()

    def disconnect(self, artifact_id: str, experiment_id: str) -> None:
        """Disconnect an artifact from an experiment."""
        resp = self._client.delete(
            f"{self._base.rsplit('/', 1)[0]}/experiments/{experiment_id}/artifacts/{artifact_id}"
        )
        self._raise_for_status(resp)

    def batch_connect(
        self,
        artifact_ids: list[str],
        experiment_id: str,
    ) -> dict:
        """Connect multiple artifacts to an experiment."""
        resp = self._client.post(
            f"{self._base}/batch-connect",
            json={"experiment_id": experiment_id, "artifact_ids": artifact_ids},
        )
        self._raise_for_status(resp)
        return resp.json()

    def batch_disconnect(
        self,
        artifact_ids: list[str],
        experiment_id: str,
    ) -> dict:
        """Disconnect multiple artifacts from an experiment."""
        resp = self._client.post(
            f"{self._base}/batch-disconnect",
            json={"experiment_id": experiment_id, "artifact_ids": artifact_ids},
        )
        self._raise_for_status(resp)
        return resp.json()

    def delete(self, artifact_id: str, *, force: bool = False) -> None:
        """Delete an artifact (only if connected to ≤1 experiment, unless force=True)."""
        params = {"force": "true"} if force else {}
        resp = self._client.delete(f"{self._base}/{artifact_id}", params=params)
        self._raise_for_status(resp)

    def upload(
        self,
        file_path: Path | str,
        *,
        experiment_id: str | None = None,
        file_mtime: float | None = None,
        content_type: str | None = None,
    ) -> dict:
        """Upload a single file, optionally connecting it to an experiment.

        Args:
            file_path: Path to file to upload
            experiment_id: Optional experiment ID (e.g., EXP-1). If not provided,
                          creates a standalone artifact.
            file_mtime: Optional file modification time (Unix timestamp).
                        If not provided, extracted from file stat.
            content_type: MIME type of the file. If not provided, auto-detected
                         from file extension.

        Returns:
            Dict with artifact details including 'artifact_id'.

        Examples:
            # Upload to experiment
            diffuse.artifacts.upload("./data.csv", experiment_id="EXP-1")

            # Standalone upload
            diffuse.artifacts.upload("./data.csv")
        """
        file_path = Path(file_path)
        stat = file_path.stat()
        mtime = file_mtime if file_mtime is not None else stat.st_mtime
        mime = content_type or _guess_content_type(file_path)

        # Build session request - only include experiment_id if provided
        session_payload: dict[str, Any] = {
            "filename": file_path.name,
            "content_type": mime,
            "size_bytes": stat.st_size,
            "file_mtime": mtime,
        }
        if experiment_id:
            session_payload["experiment_id"] = experiment_id

        session_resp = self._client.post(
            f"{self._base.rsplit('/', 1)[0]}/uploads/session",
            json=session_payload,
        )
        self._raise_for_status(session_resp)
        session = session_resp.json()

        finalize_resp = self._client.post(
            f"{self._base.rsplit('/', 1)[0]}/uploads/{session['session_id']}/finalize",
            json={
                "session_id": session["session_id"],
                "parts": [],
                "metadata_document": {
                    "experiment_slug": experiment_id or "standalone",
                    "artifact_name": file_path.name,
                    "artifact_type": "artifact",
                    "tags": [],
                    "checksum": "",
                    "description": f"Uploaded {file_path.name}",
                    "file_mtime": mtime,
                },
            },
        )
        self._raise_for_status(finalize_resp)
        return finalize_resp.json()

    def upload_directory(
        self,
        directory_path: Path | str,
        *,
        experiment_id: str | None = None,
    ) -> dict:
        """Upload all files in a directory, optionally connecting to an experiment.

        Args:
            directory_path: Path to directory to upload
            experiment_id: Optional experiment ID (e.g., EXP-1). If not provided,
                          creates standalone artifacts.

        Returns:
            Dict with 'completed' and 'failed' lists.

        Examples:
            # Upload to experiment
            diffuse.artifacts.upload_directory("./data/", experiment_id="EXP-1")

            # Standalone upload
            diffuse.artifacts.upload_directory("./data/")
        """
        directory_path = Path(directory_path)
        files = sorted(f for f in directory_path.rglob("*") if f.is_file())

        file_requests = []
        for f in files:
            stat = f.stat()
            file_request: dict[str, Any] = {
                "filename": str(f.relative_to(directory_path)),
                "content_type": _guess_content_type(f),
                "size_bytes": stat.st_size,
                "file_mtime": stat.st_mtime,
            }
            if experiment_id:
                file_request["experiment_id"] = experiment_id
            file_requests.append(file_request)

        # Build batch payload - only include experiment_id if provided
        batch_payload: dict[str, Any] = {"files": file_requests}
        if experiment_id:
            batch_payload["experiment_id"] = experiment_id

        batch_resp = self._client.post(
            f"{self._base.rsplit('/', 1)[0]}/uploads/sessions/batch",
            json=batch_payload,
        )
        self._raise_for_status(batch_resp)
        sessions = batch_resp.json()

        finalizations = []
        for i, session in enumerate(sessions.get("sessions", [])):
            f = files[i]
            stat = f.stat()
            finalizations.append(
                {
                    "session_id": session["session_id"],
                    "parts": [],
                    "metadata_document": {
                        "experiment_slug": experiment_id or "standalone",
                        "artifact_name": str(f.relative_to(directory_path)),
                        "artifact_type": "artifact",
                        "tags": [],
                        "checksum": "",
                        "description": f"Uploaded {f.relative_to(directory_path)}",
                        "file_mtime": stat.st_mtime,
                    },
                }
            )

        finalize_resp = self._client.post(
            f"{self._base.rsplit('/', 1)[0]}/uploads/finalize/batch",
            json={"finalizations": finalizations},
        )
        self._raise_for_status(finalize_resp)
        return finalize_resp.json()

    def download_url(self, artifact_id: str) -> str:
        """Get a presigned download URL for an artifact.

        Returns a temporary URL that can be used to download the artifact
        directly from object storage. Useful in notebooks for streaming
        data into pandas, PIL, or other tools.

        Args:
            artifact_id: Artifact UUID

        Returns:
            Presigned download URL string.

        Examples:
            >>> url = diffuse.artifacts.download_url("abc123")
            >>> df = pandas.read_csv(url)
        """
        # Use a separate client without follow_redirects to capture the 307
        resp = self._client.get(
            f"{self._base}/{artifact_id}/download",
            follow_redirects=False,
        )
        if resp.status_code in {307, 302, 301}:
            return resp.headers["location"]
        self._raise_for_status(resp)
        # Fallback: if the server returned 200 with a URL body
        return resp.text

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise DiffuseError(
            f"API error: {resp.status_code}",
            status_code=resp.status_code,
            detail=detail or resp.text,
        )


class MetadataAPI:
    """Metadata API for experiments."""

    def __init__(self, client: httpx.Client, base_url: str):
        self._client = client
        self._base = f"{base_url.rstrip('/')}/api/experiments"

    def get(self, experiment_id: str, key: str | None = None) -> dict | Any:
        """Get metadata for an experiment. If key is provided, returns just that value."""
        resp = self._client.get(f"{self._base}/{experiment_id}/metadata")
        self._raise_for_status(resp)
        data = resp.json()
        if key:
            return data.get(key)
        return data

    def set(self, experiment_id: str, key: str, value: Any) -> dict:
        """Set a single metadata field."""
        resp = self._client.post(
            f"{self._base}/{experiment_id}/metadata",
            json={"key": key, "value": value},
        )
        self._raise_for_status(resp)
        return resp.json()

    def update(self, experiment_id: str, metadata: dict[str, Any]) -> dict:
        """Update multiple metadata fields at once."""
        resp = self._client.patch(
            f"{self._base}/{experiment_id}/metadata",
            json=metadata,
        )
        self._raise_for_status(resp)
        return resp.json()

    def delete(self, experiment_id: str, key: str) -> None:
        """Delete a metadata field."""
        resp = self._client.delete(f"{self._base}/{experiment_id}/metadata/{key}")
        self._raise_for_status(resp)

    def fields(self) -> list[dict]:
        """List available metadata field definitions."""
        resp = self._client.get(f"{self._base.rsplit('/', 1)[0]}/metadata/fields")
        self._raise_for_status(resp)
        return resp.json()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise DiffuseError(
            f"API error: {resp.status_code}",
            status_code=resp.status_code,
            detail=detail or resp.text,
        )


class FieldsAPI:
    """API for managing metadata field definitions."""

    def __init__(self, client: httpx.Client, base_url: str):
        self._client = client
        self._base = f"{base_url.rstrip('/')}/api/admin/metadata-fields"

    def list(self, *, include_inactive: bool = False) -> list[dict]:
        """List metadata field definitions."""
        params = {"include_inactive": "true"} if include_inactive else {}
        resp = self._client.get(self._base, params=params)
        self._raise_for_status(resp)
        return resp.json()

    def create(
        self,
        key: str,
        display_name: str,
        *,
        field_type: str = "TEXT",
        description: str | None = None,
        unit: str | None = None,
        required: bool = False,
        allowed_values: list[str] | None = None,
        default_value: str | None = None,
    ) -> dict:
        """Create a new metadata field definition."""
        payload: dict[str, Any] = {
            "key": key,
            "display_name": display_name,
            "field_type": field_type,
            "required": required,
        }
        if description is not None:
            payload["description"] = description
        if unit is not None:
            payload["unit"] = unit
        if allowed_values is not None:
            payload["allowed_values"] = allowed_values
        if default_value is not None:
            payload["default_value"] = default_value

        resp = self._client.post(self._base, json=payload)
        self._raise_for_status(resp)
        return resp.json()

    def update(
        self,
        field_id: str,
        *,
        display_name: str | None = None,
        description: str | None = None,
        field_type: str | None = None,
        unit: str | None = None,
        required: bool | None = None,
        is_active: bool | None = None,
        allowed_values: list[str] | None = None,
        default_value: str | None = None,
    ) -> dict:
        """Update a metadata field definition."""
        payload: dict[str, Any] = {}
        if display_name is not None:
            payload["display_name"] = display_name
        if description is not None:
            payload["description"] = description
        if field_type is not None:
            payload["field_type"] = field_type
        if unit is not None:
            payload["unit"] = unit
        if required is not None:
            payload["required"] = required
        if is_active is not None:
            payload["is_active"] = is_active
        if allowed_values is not None:
            payload["allowed_values"] = allowed_values
        if default_value is not None:
            payload["default_value"] = default_value

        if not payload:
            resp = self._client.get(f"{self._base}/{field_id}")
            self._raise_for_status(resp)
            return resp.json()

        resp = self._client.patch(f"{self._base}/{field_id}", json=payload)
        self._raise_for_status(resp)
        return resp.json()

    def delete(self, field_id: str) -> None:
        """Delete a metadata field definition."""
        resp = self._client.delete(f"{self._base}/{field_id}")
        self._raise_for_status(resp)

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise DiffuseError(
            f"API error: {resp.status_code}",
            status_code=resp.status_code,
            detail=detail or resp.text,
        )


class TypesAPI:
    """API for managing experiment types."""

    def __init__(self, client: httpx.Client, base_url: str):
        self._client = client
        self._base = f"{base_url.rstrip('/')}/api/experiment-types"

    def list(self, *, include_inactive: bool = False) -> list[dict]:
        """List experiment types."""
        params = {"include_inactive": "true"} if include_inactive else {}
        resp = self._client.get(self._base, params=params)
        self._raise_for_status(resp)
        return resp.json()

    def get(self, type_id: str, *, include_metadata_fields: bool = True) -> dict:
        """Get experiment type details."""
        params = {"include_metadata_fields": "true"} if include_metadata_fields else {}
        resp = self._client.get(f"{self._base}/{type_id}", params=params)
        self._raise_for_status(resp)
        return resp.json()

    def create(
        self,
        name: str,
        display_name: str,
        *,
        description: str | None = None,
        markdown_template: str = "",
    ) -> dict:
        """Create a new experiment type."""
        payload: dict[str, Any] = {
            "name": name,
            "display_name": display_name,
            "markdown_template": markdown_template,
        }
        if description is not None:
            payload["description"] = description

        resp = self._client.post(self._base, json=payload)
        self._raise_for_status(resp)
        return resp.json()

    def update(
        self,
        type_id: str,
        *,
        display_name: str | None = None,
        description: str | None = None,
        markdown_template: str | None = None,
        is_active: bool | None = None,
    ) -> dict:
        """Update an experiment type."""
        payload: dict[str, Any] = {}
        if display_name is not None:
            payload["display_name"] = display_name
        if description is not None:
            payload["description"] = description
        if markdown_template is not None:
            payload["markdown_template"] = markdown_template
        if is_active is not None:
            payload["is_active"] = is_active

        if not payload:
            return self.get(type_id)

        resp = self._client.patch(f"{self._base}/{type_id}", json=payload)
        self._raise_for_status(resp)
        return resp.json()

    def delete(self, type_id: str) -> None:
        """Deactivate an experiment type (soft delete)."""
        resp = self._client.delete(f"{self._base}/{type_id}")
        self._raise_for_status(resp)

    def set_fields(self, type_id: str, field_ids: list[str]) -> dict:
        """Set metadata fields for an experiment type.

        Replaces all existing field associations.
        """
        resp = self._client.put(
            f"{self._base}/{type_id}/metadata-fields",
            json={"metadata_field_ids": field_ids},
        )
        self._raise_for_status(resp)
        return resp.json()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise DiffuseError(
            f"API error: {resp.status_code}",
            status_code=resp.status_code,
            detail=detail or resp.text,
        )


class ExternalBucketsAPI:
    """API for browsing and attaching external S3 artifacts (e.g. OSN).

    External buckets are read-only S3-compatible stores configured on the server.
    Artifacts can be linked to experiments or collections without copying data.

    Examples:
        >>> diffuse.external_buckets.list()
        >>> diffuse.external_buckets.browse("osn-diffuse-chess", prefix="data/")
        >>> diffuse.external_buckets.attach_to_experiment(
        ...     "EXP-1", "osn-diffuse-chess",
        ...     [{"s3_key": "data/scan001.h5"}, {"s3_key": "data/scan002.h5"}],
        ... )
        >>> diffuse.external_buckets.attach_to_collection(
        ...     "COL-1", "osn-diffuse-chess",
        ...     [{"s3_key": "data/scan001.h5"}],
        ... )
    """

    def __init__(
        self,
        client: httpx.Client,
        base_url: str,
        collections: CollectionsAPI | None = None,
    ):
        self._client = client
        self._api = f"{base_url.rstrip('/')}/api"
        self._collections = collections

    def list(self) -> list[dict]:
        """List all configured external buckets.

        Returns:
            List of bucket configs with name, type, endpoint_url, bucket,
            public, no_sign_request, web_base_url.
        """
        resp = self._client.get(f"{self._api}/external-buckets")
        self._raise_for_status(resp)
        return resp.json()

    def browse(
        self,
        bucket_name: str,
        *,
        prefix: str = "",
        force_refresh: bool = False,
    ) -> dict:
        """Browse the contents of an external bucket.

        Args:
            bucket_name: Configured bucket name (e.g. "osn-diffuse-chess")
            prefix: S3 prefix to list under (use trailing "/" for directories)
            force_refresh: Bypass server-side cache

        Returns:
            Dict with bucket_name, prefix, objects (list), prefixes (list), cached (bool).
        """
        params: dict[str, Any] = {"prefix": prefix}
        if force_refresh:
            params["force_refresh"] = "true"
        resp = self._client.get(
            f"{self._api}/external-buckets/{bucket_name}", params=params
        )
        self._raise_for_status(resp)
        return resp.json()

    def attach_to_experiment(
        self,
        experiment_id: str,
        bucket_name: str,
        artifacts: list[dict[str, str]],
    ) -> dict:
        """Attach external artifacts to an experiment.

        Creates external artifact records (if they don't exist) and connects
        them to the experiment. No data is copied.

        Args:
            experiment_id: Experiment ID or display ID (e.g. "EXP-1")
            bucket_name: Configured external bucket name
            artifacts: List of {"s3_key": "...", "name": "..."} dicts.
                       "name" is optional and defaults to the filename.

        Returns:
            Dict with 'attached' count.
        """
        resp = self._client.post(
            f"{self._api}/external-artifacts/batch-attach",
            json={
                "experiment_id": experiment_id,
                "bucket_name": bucket_name,
                "artifacts": artifacts,
            },
        )
        self._raise_for_status(resp)
        return resp.json()

    def attach_to_collection(
        self,
        collection_id: str,
        bucket_name: str,
        artifacts: list[dict[str, str]],
    ) -> dict:
        """Attach external artifacts to a collection.

        Delegates to CollectionsAPI.attach_external() so there is one
        implementation of the HTTP call for this endpoint.

        Args:
            collection_id: Collection ID or display ID (e.g. "COL-1")
            bucket_name: Configured external bucket name
            artifacts: List of {"s3_key": "...", "name": "..."} dicts

        Returns:
            Dict with 'attached' count.
        """
        if self._collections is not None:
            return self._collections.attach_external(
                collection_id, bucket_name, artifacts
            )
        # Fallback when constructed without a CollectionsAPI reference
        resp = self._client.post(
            f"{self._api}/collections/{collection_id}/external-artifacts/batch-attach",
            json={"bucket_name": bucket_name, "artifacts": artifacts},
        )
        self._raise_for_status(resp)
        return resp.json()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise DiffuseError(
            f"API error: {resp.status_code}",
            status_code=resp.status_code,
            detail=detail or resp.text,
        )


class CollectionsAPI:
    """API for managing artifact collections.

    Collections are logical groupings of artifacts that can be shared across
    multiple experiments. They support immutable snapshots for reproducibility.

    Examples:
        >>> diffuse.collections.list()
        >>> diffuse.collections.get("COL-1")
        >>> diffuse.collections.create(name="Training Dataset v1", tags=["ml", "dataset"])
        >>> diffuse.collections.add_artifact("COL-1", "artifact-uuid")
        >>> diffuse.collections.connect("COL-1", "EXP-5")
        >>> diffuse.collections.snapshot("COL-1", note="Release candidate")
    """

    def __init__(self, client: httpx.Client, base_url: str):
        self._client = client
        self._base = f"{base_url.rstrip('/')}/api/collections"

    def list(
        self,
        *,
        search: str | None = None,
        tag: str | None = None,
        include_snapshots: bool = True,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict]:
        """List collections with optional filtering.

        Args:
            search: Search in name/description
            tag: Filter by tag
            include_snapshots: Include snapshot collections
            limit: Maximum number of results
            offset: Number of results to skip

        Returns:
            List of collection summary dicts
        """
        params: dict[str, Any] = {
            "include_snapshots": str(include_snapshots).lower(),
            "limit": limit,
            "offset": offset,
        }
        if search:
            params["search"] = search
        if tag:
            params["tag"] = tag

        resp = self._client.get(self._base, params=params)
        self._raise_for_status(resp)
        return resp.json()

    def get(self, collection_id: str) -> dict:
        """Get collection details by ID or display ID (COL-N).

        Returns full collection detail including artifacts, experiments, and snapshots.
        """
        resp = self._client.get(f"{self._base}/{collection_id}")
        self._raise_for_status(resp)
        return resp.json()

    def create(
        self,
        name: str,
        *,
        description: str | None = None,
        tags: list[str] | None = None,
    ) -> dict:
        """Create a new collection.

        Args:
            name: Collection name
            description: Optional description
            tags: Optional list of tags

        Returns:
            Created collection summary
        """
        payload: dict[str, Any] = {"name": name}
        if description:
            payload["description"] = description
        if tags:
            payload["tags"] = tags

        resp = self._client.post(self._base, json=payload)
        self._raise_for_status(resp)
        return resp.json()

    def update(
        self,
        collection_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        tags: list[str] | None = None,
    ) -> dict:
        """Update a collection's metadata.

        Cannot be used on snapshot collections.
        """
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if tags is not None:
            payload["tags"] = tags

        if not payload:
            return self.get(collection_id)

        resp = self._client.patch(f"{self._base}/{collection_id}", json=payload)
        self._raise_for_status(resp)
        return resp.json()

    def delete(self, collection_id: str, *, force: bool = False) -> None:
        """Delete a collection.

        Args:
            collection_id: Collection ID or display ID
            force: Force delete even if connected to experiments
        """
        params = {"force": str(force).lower()}
        resp = self._client.delete(f"{self._base}/{collection_id}", params=params)
        self._raise_for_status(resp)

    def add_artifact(
        self,
        collection_id: str,
        artifact_id: str,
        *,
        artifact_path: str | None = None,
    ) -> dict:
        """Add an artifact to a collection.

        Args:
            collection_id: Collection ID or display ID
            artifact_id: Artifact UUID
            artifact_path: Optional display path

        Returns:
            Collection artifact summary
        """
        payload: dict[str, Any] = {"artifact_id": artifact_id}
        if artifact_path:
            payload["artifact_path"] = artifact_path

        resp = self._client.post(
            f"{self._base}/{collection_id}/artifacts", json=payload
        )
        self._raise_for_status(resp)
        return resp.json()

    def add_artifacts(
        self,
        collection_id: str,
        artifacts: list[dict[str, str]],
    ) -> dict:
        """Batch add artifacts to a collection.

        Args:
            collection_id: Collection ID or display ID
            artifacts: List of {"artifact_id": ..., "artifact_path": ...} dicts

        Returns:
            Dict with 'added', 'skipped_duplicates', 'not_found' counts
        """
        payload = {"artifacts": artifacts}
        resp = self._client.post(
            f"{self._base}/{collection_id}/artifacts/batch", json=payload
        )
        self._raise_for_status(resp)
        return resp.json()

    def remove_artifact(self, collection_id: str, artifact_id: str) -> None:
        """Remove an artifact from a collection."""
        resp = self._client.delete(
            f"{self._base}/{collection_id}/artifacts/{artifact_id}"
        )
        self._raise_for_status(resp)

    def remove_artifacts(self, collection_id: str, artifact_ids: list[str]) -> dict:
        """Batch remove artifacts from a collection.

        Returns:
            Dict with 'removed' and 'requested' counts
        """
        payload = {"artifact_ids": artifact_ids}
        resp = self._client.post(
            f"{self._base}/{collection_id}/artifacts/batch-remove", json=payload
        )
        self._raise_for_status(resp)
        return resp.json()

    def connect(
        self,
        collection_id: str,
        experiment_id: str,
        *,
        alias: str | None = None,
    ) -> dict:
        """Connect a collection to an experiment.

        Args:
            collection_id: Collection ID or display ID
            experiment_id: Experiment ID or display ID (EXP-N)
            alias: Optional context-specific alias

        Returns:
            Collection summary
        """
        payload: dict[str, Any] = {"collection_id": collection_id}
        if alias:
            payload["alias"] = alias

        base_url = self._base.replace("/api/collections", "/api")
        resp = self._client.post(
            f"{base_url}/experiments/{experiment_id}/collections/connect",
            json=payload,
        )
        self._raise_for_status(resp)
        return resp.json()

    def disconnect(self, collection_id: str, experiment_id: str) -> None:
        """Disconnect a collection from an experiment."""
        base_url = self._base.replace("/api/collections", "/api")
        resp = self._client.delete(
            f"{base_url}/experiments/{experiment_id}/collections/{collection_id}"
        )
        self._raise_for_status(resp)

    def snapshot(self, collection_id: str, *, note: str | None = None) -> dict:
        """Create an immutable snapshot of a collection.

        Args:
            collection_id: Collection ID or display ID
            note: Optional note describing the snapshot

        Returns:
            Created snapshot collection summary
        """
        payload: dict[str, Any] = {}
        if note:
            payload["note"] = note

        resp = self._client.post(
            f"{self._base}/{collection_id}/snapshots", json=payload
        )
        self._raise_for_status(resp)
        return resp.json()

    def list_snapshots(self, collection_id: str) -> list[dict]:
        """List all snapshots of a collection."""
        resp = self._client.get(f"{self._base}/{collection_id}/snapshots")
        self._raise_for_status(resp)
        return resp.json()

    def list_artifacts(self, collection_id: str) -> list[dict]:
        """List artifacts in a collection."""
        resp = self._client.get(f"{self._base}/{collection_id}/artifacts")
        self._raise_for_status(resp)
        return resp.json()

    def list_experiments(self, collection_id: str) -> list[dict]:
        """List experiments connected to a collection."""
        coll = self.get(collection_id)
        return coll.get("experiments", [])

    def import_internal(
        self,
        collection_id: str,
        artifacts: list[dict[str, str]],
        *,
        delete_source: bool = False,
    ) -> dict:
        """Import artifacts from the /raw bucket into a collection.

        This is an async operation — returns immediately with a flow_run_id
        that can be polled for progress.

        Args:
            collection_id: Collection ID or display ID
            artifacts: List of {"s3_key": "...", "name": "..."} dicts
            delete_source: Remove source files after import

        Returns:
            Dict with 'status', 'count', 'flow_run_id'.
        """
        resp = self._client.post(
            f"{self._base}/{collection_id}/internal-artifacts/batch-import",
            json={"artifacts": artifacts, "delete_source": delete_source},
        )
        self._raise_for_status(resp)
        return resp.json()

    def attach_external(
        self,
        collection_id: str,
        bucket_name: str,
        artifacts: list[dict[str, str]],
    ) -> dict:
        """Attach external S3 artifacts to a collection.

        Args:
            collection_id: Collection ID or display ID
            bucket_name: Configured external bucket name
            artifacts: List of {"s3_key": "...", "name": "..."} dicts

        Returns:
            Dict with 'attached' count.
        """
        resp = self._client.post(
            f"{self._base}/{collection_id}/external-artifacts/batch-attach",
            json={"bucket_name": bucket_name, "artifacts": artifacts},
        )
        self._raise_for_status(resp)
        return resp.json()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise DiffuseError(
            f"API error: {resp.status_code}",
            status_code=resp.status_code,
            detail=detail or resp.text,
        )


class ApiKeysAPI:
    def __init__(self, client: httpx.Client, base_url: str):
        self._client = client
        self._base_url = base_url

    def list(self) -> list[dict]:
        resp = self._client.get(f"{self._base_url}/api/api-keys/personal")
        self._raise_for_status(resp)
        return resp.json()

    def create(
        self,
        name: str,
        expires_in_days: int | None = None,
        description: str | None = None,
    ) -> dict:
        payload: dict[str, Any] = {"name": name}
        if description:
            payload["description"] = description
        if expires_in_days:
            from datetime import datetime, timedelta, UTC

            expires_at = datetime.now(UTC) + timedelta(days=expires_in_days)
            payload["expires_at"] = expires_at.isoformat()
        resp = self._client.post(
            f"{self._base_url}/api/api-keys/personal", json=payload
        )
        self._raise_for_status(resp)
        return resp.json()

    def revoke(self, key_id: str) -> None:
        resp = self._client.delete(f"{self._base_url}/api/api-keys/personal/{key_id}")
        self._raise_for_status(resp)

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise DiffuseError(
            f"API error: {resp.status_code}",
            status_code=resp.status_code,
            detail=detail or resp.text,
        )


class SearchAPI:
    """Search helpers — discover searchable fields and values.

    The experiment search uses a structured query syntax that can be passed
    to ``diffuse.experiments.list(query=...)``. Use this API to discover
    available fields and their values.

    Query syntax examples::

        tag:crystal AND resolution:>1.5
        title:"Thaumatin Structure" OR title:Lysozyme
        created:>2024-01-01 AND created:<2024-12-31
        (tag:xray OR tag:neutron) AND NOT public:false

    Operators: ``AND``, ``OR``, ``NOT``, parentheses for grouping.
    Comparisons: ``>``, ``>=``, ``<``, ``<=``, ``=`` (for numbers/dates).
    Wildcards: ``tag:xray*`` (prefix match), ``beamline:*`` (field exists).
    """

    QUERY_SYNTAX = (
        "field:value          - field contains value\n"
        'field:"quoted"       - exact phrase match\n'
        "field:value*         - wildcard prefix match\n"
        "field:*              - field has any value (exists)\n"
        "field:=value         - exact match\n"
        "field:>value         - greater than (numbers/dates)\n"
        "field:>=value        - greater than or equal\n"
        "field:<value         - less than\n"
        "field:<=value        - less than or equal\n"
        "AND / OR / NOT       - boolean operators\n"
        "( )                  - grouping\n"
        "plain text           - full-text search (title, summary, tags)\n"
        "\n"
        "Built-in fields: title, summary, id, tag, author, type, created, updated, public\n"
        "Custom metadata fields are also searchable by key."
    )

    def __init__(self, client: httpx.Client, base_url: str):
        self._client = client
        self._base = f"{base_url.rstrip('/')}/api/search"

    def fields(self, prefix: str = "") -> list[dict]:
        """Discover searchable fields.

        Args:
            prefix: Filter fields by prefix (e.g., "res" matches "resolution")

        Returns:
            List of field dicts with key, display_name, type, description, builtin.
        """
        resp = self._client.get(
            f"{self._base}/autocomplete/fields", params={"prefix": prefix}
        )
        self._raise_for_status(resp)
        return resp.json()

    def values(self, field: str, prefix: str = "") -> list[dict]:
        """Discover values for a searchable field.

        Args:
            field: Field key (e.g., "tag", "type", "resolution")
            prefix: Filter values by prefix

        Returns:
            List of value dicts (varies by field type: value, count, display, color).
        """
        resp = self._client.get(
            f"{self._base}/autocomplete/values",
            params={"field": field, "prefix": prefix},
        )
        self._raise_for_status(resp)
        return resp.json()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise DiffuseError(
            f"API error: {resp.status_code}",
            status_code=resp.status_code,
            detail=detail or resp.text,
        )


class GovernanceAPI:
    """API for governance tasks — duplicate review, missing metadata, validation, enrichment.

    Examples:
        >>> tasks = diffuse.governance.list()
        >>> task = diffuse.governance.get("task-id")
        >>> diffuse.governance.resolve("task-id", notes="Fixed duplicate")
        >>> diffuse.governance.add_comment("task-id", "Looks like a false positive")
    """

    def __init__(self, client: httpx.Client, base_url: str):
        self._client = client
        self._base = f"{base_url.rstrip('/')}/api/governance"

    def list(
        self,
        *,
        task_type: str | None = None,
        status: str | None = None,
        assigned_to_me: bool = False,
        experiment_id: str | None = None,
        artifact_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict]:
        """List governance tasks with optional filtering.

        Args:
            task_type: Filter by type: "duplicate_review", "missing_metadata",
                       "validation_failure", "enrichment_required"
            status: Filter by status: "open", "in_progress", "resolved", "dismissed"
            assigned_to_me: Only show tasks assigned to the current user
            experiment_id: Filter by experiment
            artifact_id: Filter by artifact
            limit: Max results (1-200)
            offset: Pagination offset
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if task_type:
            params["task_type"] = task_type
        if status:
            params["status"] = status
        if assigned_to_me:
            params["assigned_to_me"] = "true"
        if experiment_id:
            params["experiment_id"] = experiment_id
        if artifact_id:
            params["artifact_id"] = artifact_id

        resp = self._client.get(f"{self._base}/tasks", params=params)
        self._raise_for_status(resp)
        return resp.json()

    def get(self, task_id: str) -> dict:
        """Get a governance task by ID."""
        resp = self._client.get(f"{self._base}/tasks/{task_id}")
        self._raise_for_status(resp)
        return resp.json()

    def create(
        self,
        title: str,
        task_type: str,
        *,
        priority: str = "medium",
        description: str | None = None,
        artifact_id: str | None = None,
        experiment_id: str | None = None,
        related_artifact_ids: list[str] | None = None,
        assigned_to_id: str | None = None,
    ) -> dict:
        """Create a governance task.

        Args:
            title: Task title
            task_type: "duplicate_review", "missing_metadata",
                       "validation_failure", "enrichment_required"
            priority: "low", "medium", "high", "critical"
            description: Optional description
            artifact_id: Related artifact ID
            experiment_id: Related experiment ID
            related_artifact_ids: Additional related artifact IDs
            assigned_to_id: User ID to assign
        """
        payload: dict[str, Any] = {
            "title": title,
            "task_type": task_type,
            "priority": priority,
        }
        if description is not None:
            payload["description"] = description
        if artifact_id is not None:
            payload["artifact_id"] = artifact_id
        if experiment_id is not None:
            payload["experiment_id"] = experiment_id
        if related_artifact_ids is not None:
            payload["related_artifact_ids"] = related_artifact_ids
        if assigned_to_id is not None:
            payload["assigned_to_id"] = assigned_to_id

        resp = self._client.post(f"{self._base}/tasks", json=payload)
        self._raise_for_status(resp)
        return resp.json()

    def update(
        self,
        task_id: str,
        *,
        title: str | None = None,
        description: str | None = None,
        status: str | None = None,
        task_type: str | None = None,
        priority: str | None = None,
        assigned_to_id: str | None = None,
    ) -> dict:
        """Update a governance task.

        Args:
            task_id: Task ID
            title: New title
            description: New description
            status: New status
            task_type: New type
            priority: New priority
            assigned_to_id: New assignee
        """
        payload: dict[str, Any] = {}
        if title is not None:
            payload["title"] = title
        if description is not None:
            payload["description"] = description
        if status is not None:
            payload["status"] = status
        if task_type is not None:
            payload["task_type"] = task_type
        if priority is not None:
            payload["priority"] = priority
        if assigned_to_id is not None:
            payload["assigned_to_id"] = assigned_to_id

        resp = self._client.patch(f"{self._base}/tasks/{task_id}", json=payload)
        self._raise_for_status(resp)
        return resp.json()

    def delete(self, task_id: str) -> None:
        """Hard-delete a governance task (admin only)."""
        resp = self._client.delete(f"{self._base}/tasks/{task_id}")
        self._raise_for_status(resp)

    def resolve(self, task_id: str, *, notes: str | None = None) -> dict:
        """Resolve a governance task.

        Args:
            task_id: Task ID
            notes: Optional resolution notes
        """
        payload: dict[str, Any] = {}
        if notes is not None:
            payload["resolution_notes"] = notes

        resp = self._client.post(f"{self._base}/tasks/{task_id}/resolve", json=payload)
        self._raise_for_status(resp)
        return resp.json()

    def dismiss(self, task_id: str, *, reason: str) -> dict:
        """Dismiss a governance task.

        Args:
            task_id: Task ID
            reason: Required reason for dismissal
        """
        resp = self._client.post(
            f"{self._base}/tasks/{task_id}/dismiss",
            json={"reason": reason},
        )
        self._raise_for_status(resp)
        return resp.json()

    def add_comment(self, task_id: str, content: str) -> dict:
        """Add a comment to a governance task.

        Args:
            task_id: Task ID
            content: Comment text
        """
        resp = self._client.post(
            f"{self._base}/tasks/{task_id}/comments",
            json={"content": content},
        )
        self._raise_for_status(resp)
        return resp.json()

    def list_comments(self, task_id: str) -> list[dict]:
        """List comments on a governance task."""
        resp = self._client.get(f"{self._base}/tasks/{task_id}/comments")
        self._raise_for_status(resp)
        return resp.json()

    def stats(self) -> dict:
        """Get governance statistics.

        Returns:
            Dict with by_status, by_type, open_count, in_progress_count,
            unassigned_count, total_count.
        """
        resp = self._client.get(f"{self._base}/stats")
        self._raise_for_status(resp)
        return resp.json()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise DiffuseError(
            f"API error: {resp.status_code}",
            status_code=resp.status_code,
            detail=detail or resp.text,
        )


class RelationshipsAPI:
    """API for managing experiment relationships."""

    def __init__(self, client: httpx.Client, base_url: str):
        self._client = client
        self._base = f"{base_url.rstrip('/')}/api/experiments"

    def list(self, experiment_id: str) -> list[dict]:
        """List relationships for an experiment.

        Args:
            experiment_id: Experiment ID or display ID (e.g., EXP-1)

        Returns:
            List of relationship dicts with from/to experiment details.
        """
        resp = self._client.get(f"{self._base}/{experiment_id}/relationships")
        self._raise_for_status(resp)
        return resp.json()

    def add(
        self,
        experiment_id: str,
        to_experiment_id: str,
        relationship_type: str = "uses",
    ) -> dict:
        """Create a relationship between two experiments.

        Args:
            experiment_id: Source experiment ID or display ID
            to_experiment_id: Target experiment ID or display ID
            relationship_type: "uses" or "relates_to"

        Returns:
            Created relationship dict.
        """
        resp = self._client.post(
            f"{self._base}/{experiment_id}/relationships",
            json={
                "from_experiment_id": experiment_id,
                "to_experiment_id": to_experiment_id,
                "relationship_type": relationship_type,
            },
        )
        self._raise_for_status(resp)
        return resp.json()

    def remove(
        self,
        experiment_id: str,
        from_experiment_id: str,
        to_experiment_id: str,
        relationship_type: str,
    ) -> None:
        """Remove a relationship between two experiments.

        Args:
            experiment_id: URL experiment ID (must be one of from/to)
            from_experiment_id: Source experiment ID or display ID
            to_experiment_id: Target experiment ID or display ID
            relationship_type: "uses" or "relates_to"
        """
        resp = self._client.delete(
            f"{self._base}/{experiment_id}/relationships",
            params={
                "from_experiment_id": from_experiment_id,
                "to_experiment_id": to_experiment_id,
                "relationship_type": relationship_type,
            },
        )
        self._raise_for_status(resp)

    def graph(self, experiment_id: str) -> dict:
        """Get the relationship graph for an experiment.

        Args:
            experiment_id: Experiment ID or display ID

        Returns:
            Graph dict with nodes and edges.
        """
        resp = self._client.get(f"{self._base}/{experiment_id}/graph")
        self._raise_for_status(resp)
        return resp.json()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise DiffuseError(
            f"API error: {resp.status_code}",
            status_code=resp.status_code,
            detail=detail or resp.text,
        )


class ActivityAPI:
    """API for accessing the audit trail."""

    def __init__(self, client: httpx.Client, base_url: str):
        self._client = client
        self._base = f"{base_url.rstrip('/')}/api"

    def list(self) -> list[dict]:
        """List recent activity events across all experiments.

        Returns:
            List of activity event dicts.
        """
        resp = self._client.get(f"{self._base}/activity")
        self._raise_for_status(resp)
        return resp.json()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise DiffuseError(
            f"API error: {resp.status_code}",
            status_code=resp.status_code,
            detail=detail or resp.text,
        )


class Diffuse:
    """Python SDK for Diffuse.

    Examples:
        >>> diffuse = Diffuse()  # Uses default server from config
        >>> diffuse = Diffuse(server="http://localhost:8000")
        >>> diffuse = Diffuse(env="local")  # Shorthand for localhost
        >>> diffuse = Diffuse(env="prod")  # Shorthand for hub.diffuse.science

        >>> experiments = diffuse.experiments.list()
        >>> exp = diffuse.experiments.get("EXP-1")
        >>> new_exp = diffuse.experiments.create(title="My Experiment")
    """

    def __init__(
        self,
        server: str | None = None,
        *,
        env: str | None = None,
        token: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
    ):
        """Initialize the Diffuse SDK.

        Args:
            server: API server URL (overrides env and config)
            env: Environment shorthand: "local", "prod"
            token: GitHub token for authentication (overrides stored token)
            api_key: API key for authentication (takes priority over token)
            timeout: HTTP request timeout in seconds
        """
        if env and env in ENV_URLS:
            server = ENV_URLS[env]

        self._base_url = _get_api_base(server)

        if api_key:
            headers = {"Authorization": f"Bearer {api_key}"}
        elif token:
            headers = {"Authorization": f"Bearer {token}"}
        else:
            headers = _get_auth_headers()

        self._client = httpx.Client(
            headers=headers,
            timeout=timeout,
            follow_redirects=True,
        )

        self.experiments = ExperimentsAPI(self._client, self._base_url)
        self.artifacts = ArtifactsAPI(self._client, self._base_url)
        self.collections = CollectionsAPI(self._client, self._base_url)
        self.external_buckets = ExternalBucketsAPI(
            self._client, self._base_url, collections=self.collections
        )
        self.metadata = MetadataAPI(self._client, self._base_url)
        self.fields = FieldsAPI(self._client, self._base_url)
        self.types = TypesAPI(self._client, self._base_url)
        self.api_keys = ApiKeysAPI(self._client, self._base_url)
        self.search = SearchAPI(self._client, self._base_url)
        self.governance = GovernanceAPI(self._client, self._base_url)
        self.relationships = RelationshipsAPI(self._client, self._base_url)
        self.activity = ActivityAPI(self._client, self._base_url)

    @property
    def server(self) -> str:
        """The API server URL."""
        return self._base_url

    def version(self) -> dict:
        """Get server version info."""
        resp = self._client.get(f"{self._base_url.rstrip('/')}/api/version")
        if resp.is_success:
            return resp.json()
        return {}

    def upload(
        self,
        experiment_id: str,
        file_path: Path | str,
        *,
        file_mtime: float | None = None,
        content_type: str = "application/octet-stream",
    ) -> dict:
        """Upload a file to an experiment.

        Convenience method that delegates to artifacts.upload().
        """
        return self.artifacts.upload(
            experiment_id=experiment_id,
            file_path=file_path,
            file_mtime=file_mtime,
            content_type=content_type,
        )

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> Diffuse:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"Diffuse(server={self._base_url!r})"
