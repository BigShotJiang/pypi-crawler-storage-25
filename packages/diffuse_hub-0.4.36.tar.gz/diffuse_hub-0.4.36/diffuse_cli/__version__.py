"""Version information for the Diffuse CLI."""

__version__ = "0.4.36"
