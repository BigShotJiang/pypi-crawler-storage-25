# diffuse-hub

Python SDK and command-line interface for the [Diffuse](https://hub.diffuse.science) research data platform.

Manage experiments, metadata, and artifacts from your terminal or programmatically from notebooks and scripts.

## Installation

```bash
# Full install (CLI + SDK)
pip install "diffuse-hub[cli]"

# SDK only (lightweight, no CLI deps)
pip install diffuse-hub
```

Or run the CLI without installing:

```bash
uvx --from "diffuse-hub[cli]" diffuse --help
```

For a persistent CLI install on your PATH:

```bash
uv tool install "diffuse-hub[cli]"
diffuse --help
```

## Quickstart

### CLI

```bash
diffuse auth login
diffuse experiments list
diffuse experiments create --title "My Experiment" --tags ml,vision
diffuse artifacts upload ./data.h5 --experiment EXP-1
```

Run `diffuse --help` for the full command reference.

### SDK

```python
from diffuse_cli.sdk import Diffuse

diffuse = Diffuse()  # reads config / env vars for auth

experiments = diffuse.experiments.list(query="tag:crystal", sort="recent")
exp = diffuse.experiments.get("EXP-1")

artifacts = diffuse.artifacts.list(experiment="EXP-1")
url = diffuse.artifacts.download_url("abc123")
```

## Configuration

The CLI reads `~/.diffuse/config.json` and the following environment variables:

| Variable | Purpose |
|---|---|
| `DIFFUSE_API_URL` | Override the API base URL |
| `DIFFUSE_API_KEY` | Authenticate with a personal / system API key (`dfk_...`) |
| `DIFFUSE_ENV` | Shorthand: `local` or `prod` |

## Links

- Platform: https://hub.diffuse.science
- CLI reference: https://hub.diffuse.science/cli-docs
- Source & issues: https://github.com/diff-use/webapp

## License

Apache-2.0
