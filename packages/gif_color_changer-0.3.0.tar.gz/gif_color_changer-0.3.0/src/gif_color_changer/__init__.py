"""GIF color replacement CLI."""

