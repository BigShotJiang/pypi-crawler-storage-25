# Copyright 2025 Helix Technologies Limited
# Licensed under the Apache License, Version 2.0 (see LICENSE file).
"""
Pydantic-based Replicant agent for intelligent conversation with APIs.

This module provides a Replicant agent that can converse with APIs using
configurable facts and system prompts to achieve specific goals.
"""

import json
import re
from typing import Any, Dict, List, Optional
from datetime import datetime

from pydantic import BaseModel, Field, PrivateAttr
from pydantic_ai import Agent as PydanticAgent
from pydantic_ai.models import infer_model
from pydantic_ai.messages import ImageUrl

from ..models import ReplicantConfig, Message, GoalEvaluationResult, GoalEvaluationMode, BrowserObservation, GoalEvidenceMode
from ..tools.http_client import HTTPResponse
from ..tools.token_usage import TokenUsageTracker


class GoalEvaluationOutput(BaseModel):
    """Structured output from the goal evaluation LLM."""

    goal_achieved: bool = Field(
        ..., description="True if the goal has been definitively achieved, False otherwise"
    )
    confidence: float = Field(
        ..., description="Confidence score from 0.0 (not achieved) to 1.0 (definitely achieved)"
    )
    reasoning: str = Field(
        ..., description="Brief explanation of the decision"
    )


class ConversationState(BaseModel):
    """Current state of the conversation."""
    model_config = {"extra": "forbid"}
    
    turn_count: int = Field(0, description="Current turn number")
    goal_achieved: bool = Field(False, description="Whether the goal has been achieved")
    conversation_history: List[Message] = Field(default_factory=list, description="Full conversation history")
    extracted_info: Dict[str, Any] = Field(default_factory=dict, description="Information extracted from the conversation")
    goal_evaluation_result: Optional[GoalEvaluationResult] = Field(None, description="Latest goal evaluation result")


class GoalEvaluator(BaseModel):
    """Evaluates whether conversation goals have been achieved using different strategies."""
    model_config = {"extra": "forbid"}

    mode: GoalEvaluationMode = Field(..., description="Evaluation mode")
    model_name: Optional[str] = Field(None, description="Model for intelligent evaluation")
    screenshot_model_name: Optional[str] = Field(None, description="Model for screenshot-based evaluation (vision-capable)")
    custom_prompt: Optional[str] = Field(None, description="Custom evaluation prompt")
    completion_keywords: List[str] = Field(..., description="Keywords for keyword-based evaluation")
    verbose: bool = Field(False, description="Enable verbose output for system prompts")
    llm_debug: bool = Field(False, description="Print complete LLM prompts on every call")

    _token_tracker: Optional[TokenUsageTracker] = PrivateAttr(default=None)

    def set_tracker(self, tracker: TokenUsageTracker) -> None:
        """Attach a :class:`TokenUsageTracker` to record LLM usage."""
        self._token_tracker = tracker

    @classmethod
    def create(cls, config: ReplicantConfig, verbose: bool = False, llm_debug: bool = False) -> "GoalEvaluator":
        """Create a GoalEvaluator from ReplicantConfig.

        Args:
            config: Replicant configuration

        Returns:
            Configured GoalEvaluator
        """
        model_name = config.goal_evaluation_model or config.llm.model

        # Get screenshot evaluation model from browser config if available
        screenshot_model_name = None
        if config.browser and config.browser.screenshot_evaluation_model:
            screenshot_model_name = config.browser.screenshot_evaluation_model

        return cls(
            mode=config.goal_evaluation_mode,
            model_name=model_name,
            screenshot_model_name=screenshot_model_name,
            custom_prompt=config.goal_evaluation_prompt,
            completion_keywords=config.completion_keywords,
            verbose=verbose,
            llm_debug=llm_debug,
        )
    
    async def evaluate_goal_completion(
        self,
        goal: str,
        conversation: str,  # Changed from conversation_history for flexibility
        facts: Dict[str, Any],
        current_observation: Optional[BrowserObservation] = None,
        screenshot_path: Optional[str] = None,
        goal_evidence_mode: GoalEvidenceMode = GoalEvidenceMode.DOM,
    ) -> GoalEvaluationResult:
        """Evaluate whether the conversation goal has been achieved.

        Args:
            goal: The goal to evaluate
            conversation: Conversation text (or messages)
            facts: Available facts for context
            current_observation: Optional browser observation for browser mode
            screenshot_path: Optional path to screenshot for visual evaluation
            goal_evidence_mode: Evidence mode (dom, screenshot, dom_then_screenshot, both)

        Returns:
            Goal evaluation result
        """
        # For browser mode, include observation in the evaluation
        if current_observation:
            # Add browser context to facts
            facts = dict(facts)  # Copy to avoid mutation
            facts["current_url"] = current_observation.url
            facts["page_title"] = current_observation.title
            facts["visible_text"] = current_observation.visible_text[:2000]  # Excerpt

        # Determine evaluation strategy based on evidence mode
        if goal_evidence_mode == GoalEvidenceMode.SCREENSHOT:
            # Screenshot-only evaluation
            if screenshot_path:
                return await self._evaluate_with_screenshot(goal, conversation, facts, screenshot_path)
            else:
                # Fallback to DOM if no screenshot available
                return await self._evaluate_with_llm(goal, conversation, facts, current_observation)

        elif goal_evidence_mode == GoalEvidenceMode.DOM:
            # DOM-only evaluation (existing behavior)
            if self.mode == GoalEvaluationMode.KEYWORDS:
                return self._evaluate_with_keywords(goal, conversation, current_observation)
            elif self.mode == GoalEvaluationMode.INTELLIGENT:
                return await self._evaluate_with_llm(goal, conversation, facts, current_observation)
            elif self.mode == GoalEvaluationMode.HYBRID:
                return await self._evaluate_hybrid(goal, conversation, facts, current_observation)

        elif goal_evidence_mode == GoalEvidenceMode.DOM_THEN_SCREENSHOT:
            # Try DOM first, fallback to screenshot if confidence is low
            if self.mode == GoalEvaluationMode.KEYWORDS:
                dom_result = self._evaluate_with_keywords(goal, conversation, current_observation)
            else:
                dom_result = await self._evaluate_with_llm(goal, conversation, facts, current_observation)

            # If confidence is low and screenshot is available, try screenshot evaluation
            if dom_result.confidence < 0.5 and screenshot_path:
                screenshot_result = await self._evaluate_with_screenshot(goal, conversation, facts, screenshot_path)
                # Use screenshot result if it has higher confidence
                if screenshot_result.confidence > dom_result.confidence:
                    screenshot_result.reasoning = f"DOM evaluation had low confidence ({dom_result.confidence:.2f}), using screenshot evaluation. {screenshot_result.reasoning}"
                    return screenshot_result

            return dom_result

        elif goal_evidence_mode == GoalEvidenceMode.BOTH:
            # Use both DOM and screenshot, combine results
            dom_result = await self._evaluate_with_llm(goal, conversation, facts, current_observation)

            if screenshot_path:
                screenshot_result = await self._evaluate_with_screenshot(goal, conversation, facts, screenshot_path)
                # Average the confidences
                combined_confidence = (dom_result.confidence + screenshot_result.confidence) / 2

                # If both agree, use that result
                if dom_result.goal_achieved == screenshot_result.goal_achieved:
                    return GoalEvaluationResult(
                        goal_achieved=dom_result.goal_achieved,
                        confidence=combined_confidence,
                        reasoning=f"Combined DOM+Screenshot evaluation. DOM: {dom_result.reasoning}\nScreenshot: {screenshot_result.reasoning}",
                        evaluation_method="intelligent",
                        fallback_used=False,
                    )
                else:
                    # Disagreement - use screenshot as it's more reliable
                    return GoalEvaluationResult(
                        goal_achieved=screenshot_result.goal_achieved,
                        confidence=screenshot_result.confidence,
                        reasoning=f"DOM and screenshot disagreed. Using screenshot result. Screenshot: {screenshot_result.reasoning}",
                        evaluation_method="intelligent",
                        fallback_used=False,
                    )

            return dom_result

        else:
            raise ValueError(f"Unknown goal evaluation mode: {self.mode}")
    
    def _evaluate_with_keywords(
        self,
        goal: str,
        conversation: str,
        current_observation: Optional[BrowserObservation] = None,
    ) -> GoalEvaluationResult:
        """Evaluate goal completion using keyword matching (legacy behavior).

        Args:
            goal: The goal to evaluate
            conversation: Conversation text
            current_observation: Optional browser observation

        Returns:
            Goal evaluation result
        """
        # Check for completion keywords in conversation and visible text
        goal_achieved = False
        matched_keywords = []
        search_text = conversation.lower()

        # Add browser visible text to search
        if current_observation:
            search_text += " " + current_observation.visible_text.lower()

        # Check for keywords
        for keyword in self.completion_keywords:
            if keyword.lower() in search_text:
                goal_achieved = True
                matched_keywords.append(keyword)

        reasoning = f"Keyword evaluation: {'Found' if goal_achieved else 'No'} completion keywords"
        if matched_keywords:
            reasoning += f" (matched: {', '.join(matched_keywords)})"

        return GoalEvaluationResult(
            goal_achieved=goal_achieved,
            confidence=1.0 if goal_achieved else 0.0,  # Keywords give binary confidence
            reasoning=reasoning,
            evaluation_method="keywords",
            fallback_used=False
        )
    
    async def _evaluate_with_llm(
        self,
        goal: str,
        conversation: str,
        facts: Dict[str, Any],
        current_observation: Optional[BrowserObservation] = None,
    ) -> GoalEvaluationResult:
        """Evaluate goal completion using LLM analysis.

        Args:
            goal: The goal to evaluate
            conversation: Conversation text
            facts: Available facts for context
            current_observation: Optional browser observation

        Returns:
            Goal evaluation result
        """
        try:
            # Build evaluation prompt
            prompt = self._build_evaluation_prompt(goal, conversation, facts, current_observation)

            # Create LLM agent for evaluation with structured output
            model = infer_model(self.model_name)
            agent: PydanticAgent[None, GoalEvaluationOutput] = PydanticAgent(
                model=model,
                output_type=GoalEvaluationOutput,
                instructions="You are an expert at evaluating whether conversation goals have been achieved. Be precise and analytical.",
                model_settings={"max_tokens": 1000},
            )

            # Verbose/LLM-debug logging of the goal evaluation prompt
            if self.verbose or self.llm_debug:
                sep = "=" * 80
                label = "🔬 LLM DEBUG" if self.llm_debug else "🔍 VERBOSE"
                print(f"\n{sep}")
                print(f"{label}: GOAL EVALUATION PROMPT SENT TO PYDANTICAI")
                print(sep)
                print(f"Model: {self.model_name}")
                print(f"Instructions: You are an expert at evaluating whether conversation goals have been achieved. Be precise and analytical.")
                print()
                print("── PROMPT ──")
                print(prompt)
                print(f"{sep}\n")

            # Get structured evaluation
            result = await agent.run(prompt)
            evaluation = result.output

            # Record token usage if a tracker is attached
            if self._token_tracker is not None and self.model_name:
                self._token_tracker.record_pydantic_usage(
                    self.model_name, result.usage(), purpose="goal_evaluation"
                )

            return GoalEvaluationResult(
                goal_achieved=evaluation.goal_achieved,
                confidence=max(0.0, min(1.0, evaluation.confidence)),
                reasoning=evaluation.reasoning,
                evaluation_method="intelligent",
                fallback_used=False,
            )

        except Exception as e:
            # Return failure result if LLM evaluation fails
            return GoalEvaluationResult(
                goal_achieved=False,
                confidence=0.0,
                reasoning=f"LLM evaluation failed: {str(e)}",
                evaluation_method="intelligent",
                fallback_used=False,
            )
    
    async def _evaluate_hybrid(
        self,
        goal: str,
        conversation: str,
        facts: Dict[str, Any],
        current_observation: Optional[BrowserObservation] = None,
    ) -> GoalEvaluationResult:
        """Evaluate goal completion using LLM with keyword fallback.

        Args:
            goal: The goal to evaluate
            conversation: Conversation text
            facts: Available facts for context
            current_observation: Optional browser observation

        Returns:
            Goal evaluation result
        """
        try:
            # Try LLM evaluation first
            llm_result = await self._evaluate_with_llm(goal, conversation, facts, current_observation)

            # If confidence is too low, fall back to keywords
            if llm_result.confidence < 0.5:
                keyword_result = self._evaluate_with_keywords(goal, conversation, current_observation)
                return GoalEvaluationResult(
                    goal_achieved=keyword_result.goal_achieved,
                    confidence=keyword_result.confidence,
                    reasoning=f"Hybrid evaluation: LLM confidence {llm_result.confidence:.2f} too low, fell back to keywords. {keyword_result.reasoning}",
                    evaluation_method="hybrid",
                    fallback_used=True
                )

            return llm_result

        except Exception as e:
            # Fall back to keywords on error
            keyword_result = self._evaluate_with_keywords(goal, conversation, current_observation)
            return GoalEvaluationResult(
                goal_achieved=keyword_result.goal_achieved,
                confidence=keyword_result.confidence,
                reasoning=f"Hybrid evaluation: LLM evaluation failed ({str(e)}), fell back to keywords. {keyword_result.reasoning}",
                evaluation_method="hybrid",
                fallback_used=True
            )

    async def _evaluate_with_screenshot(
        self,
        goal: str,
        conversation: str,
        facts: Dict[str, Any],
        screenshot_path: str,
    ) -> GoalEvaluationResult:
        """Evaluate goal completion using screenshot analysis with multimodal LLM.

        Args:
            goal: The goal to evaluate
            conversation: Conversation text
            facts: Available facts for context
            screenshot_path: Path to screenshot image

        Returns:
            Goal evaluation result
        """
        try:
            import base64
            from pathlib import Path

            # Read and encode screenshot
            screenshot_bytes = Path(screenshot_path).read_bytes()
            base64_image = base64.b64encode(screenshot_bytes).decode('utf-8')
            data_url = f"data:image/png;base64,{base64_image}"

            # Build multimodal prompt
            prompt = self._build_screenshot_evaluation_prompt(goal, conversation, facts)

            # Create LLM agent for evaluation with structured output
            # Use screenshot_model_name if specified, otherwise fall back to model_name
            model_to_use = self.screenshot_model_name or self.model_name
            model = infer_model(model_to_use)
            agent: PydanticAgent[None, GoalEvaluationOutput] = PydanticAgent(
                model=model,
                output_type=GoalEvaluationOutput,
                instructions="You are an expert at evaluating whether conversation goals have been achieved by analyzing screenshots. Be precise and analytical.",
                model_settings={"max_tokens": 1000},
            )

            # Verbose/LLM-debug logging
            if self.verbose or self.llm_debug:
                sep = "=" * 80
                label = "🔬 LLM DEBUG" if self.llm_debug else "🔍 VERBOSE"
                print(f"\n{sep}")
                print(f"{label}: GOAL EVALUATION WITH SCREENSHOT")
                print(sep)
                print(f"Model: {model_to_use}")
                if self.screenshot_model_name:
                    print(f"Using dedicated screenshot evaluation model")
                print(f"Screenshot: {screenshot_path}")
                print()
                print("── PROMPT ──")
                print(prompt)
                print(f"{sep}\n")

            # Run multimodal evaluation with image
            result = await agent.run(
                prompt,
                message_history=[
                    {"role": "user", "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": data_url}}
                    ]}
                ]
            )
            evaluation = result.output

            # Record token usage if a tracker is attached
            if self._token_tracker is not None:
                model_to_use = self.screenshot_model_name or self.model_name
                if model_to_use:
                    self._token_tracker.record_pydantic_usage(
                        model_to_use, result.usage(), purpose="screenshot_evaluation"
                    )

            return GoalEvaluationResult(
                goal_achieved=evaluation.goal_achieved,
                confidence=max(0.0, min(1.0, evaluation.confidence)),
                reasoning=f"Screenshot-based evaluation: {evaluation.reasoning}",
                evaluation_method="intelligent",
                fallback_used=False,
            )

        except Exception as e:
            # Return failure result if screenshot evaluation fails
            return GoalEvaluationResult(
                goal_achieved=False,
                confidence=0.0,
                reasoning=f"Screenshot evaluation failed: {str(e)}",
                evaluation_method="intelligent",
                fallback_used=False,
            )

    def _build_screenshot_evaluation_prompt(
        self,
        goal: str,
        conversation: str,
        facts: Dict[str, Any],
    ) -> str:
        """Build the evaluation prompt for screenshot-based analysis.

        Args:
            goal: The goal to evaluate
            conversation: Conversation text
            facts: Available facts for context

        Returns:
            Formatted evaluation prompt
        """
        if self.custom_prompt:
            # Use custom prompt with variable substitution
            return self.custom_prompt.format(
                goal=goal,
                facts=json.dumps(facts, indent=2),
                conversation=conversation,
            )

        # Build evaluation prompt
        return f"""Given this conversation goal: "{goal}"

User facts: {json.dumps(facts, indent=2)}

Recent conversation:
{conversation}

Analyze the screenshot to determine if the goal has been achieved. Consider:
1. Is there visible confirmation of completion (success messages, confirmation numbers, booking details)?
2. Does the UI show the desired end state (form submitted, action completed, goal reached)?
3. Look for specific visual indicators like success icons, confirmation dialogs, completion screens
4. Distinguish between intermediate steps vs final completion"""

    def _build_evaluation_prompt(
        self,
        goal: str,
        conversation: str,
        facts: Dict[str, Any],
        current_observation: Optional[BrowserObservation] = None,
    ) -> str:
        """Build the evaluation prompt for LLM analysis.

        Args:
            goal: The goal to evaluate
            conversation: Conversation text
            facts: Available facts for context
            current_observation: Optional browser observation

        Returns:
            Formatted evaluation prompt
        """
        if self.custom_prompt:
            # Use custom prompt with variable substitution
            return self.custom_prompt.format(
                goal=goal,
                facts=json.dumps(facts, indent=2),
                conversation=conversation,
            )

        # Build evaluation prompt
        prompt_parts = [
            f"Given this conversation goal: \"{goal}\"",
            "",
            f"User facts: {json.dumps(facts, indent=2)}",
            "",
        ]

        # Add browser context if available
        if current_observation:
            prompt_parts.extend([
                "Current browser state:",
                f"  URL: {current_observation.url}",
                f"  Title: {current_observation.title}",
                f"  Visible text excerpt: {current_observation.visible_text[:500]}...",
                "",
            ])

        prompt_parts.extend([
            "Recent conversation:",
            conversation,
            "",
            "Has the goal been definitively achieved? Consider:",
            "1. Has the user received confirmation that the action was completed?",
            "2. Are there concrete indicators of success (confirmation numbers, bookings, etc.)?",
            "3. Distinguish between promises (\"I will do this\") vs accomplishments (\"This is done\")",
            "4. Look for specific completion indicators, not just polite acknowledgments",
        ])

        return "\n".join(prompt_parts)
    
    def _format_conversation_for_prompt(self, messages: List[Message]) -> str:
        """Format conversation history for the evaluation prompt.
        
        Args:
            messages: List of messages to format
            
        Returns:
            Formatted conversation string
        """
        formatted = []
        for msg in messages:
            role = "User" if msg.role == "user" else "Assistant"
            formatted.append(f"{role}: {msg.content}")
        return "\n".join(formatted)


class ResponseGenerator(BaseModel):
    """Generates responses using PydanticAI agent with system prompt and available facts."""
    model_config = {"extra": "forbid"}
    
    model_name: str = Field(..., description="PydanticAI model name")
    system_prompt: str = Field(..., description="System prompt for response generation")
    model_settings: Dict[str, Any] = Field(default_factory=dict, description="Model settings")
    facts: Dict[str, Any] = Field(..., description="Available facts")
    verbose: bool = Field(False, description="Enable verbose output for system prompts")
    llm_debug: bool = Field(False, description="Print complete LLM prompts on every call")

    _token_tracker: Optional[TokenUsageTracker] = PrivateAttr(default=None)

    def set_tracker(self, tracker: TokenUsageTracker) -> None:
        """Attach a :class:`TokenUsageTracker` to record LLM usage."""
        self._token_tracker = tracker
    
    def _create_agent(self) -> PydanticAgent:
        """Create a PydanticAI agent instance."""
        from pydantic_ai.models import infer_model
        
        model = infer_model(self.model_name)
        
        return PydanticAgent(
            model=model,
            instructions=self.system_prompt,
            model_settings=self.model_settings if self.model_settings else None
        )
    
    async def generate_response(self, api_message: str, conversation_state: ConversationState) -> str:
        """Generate a response to an API message using PydanticAI.
        
        Args:
            api_message: Message from the API
            conversation_state: Current conversation state
            
        Returns:
            Generated response
        """
        try:
            # Get current date and time
            current_datetime = datetime.now()
            date_str = current_datetime.strftime("%A, %B %d, %Y")
            time_str = current_datetime.strftime("%I:%M %p %Z")
            
            # Prepare context with facts AND conversation history
            context = f"Current date and time: {date_str} at {time_str}\n\n"
            context += f"Available facts: {json.dumps(self.facts, indent=2)}\n\n"
            
            # Add conversation history for context
            if conversation_state.conversation_history:
                context += "Conversation history:\n"
                for msg in conversation_state.conversation_history[-6:]:  # Last 6 messages
                    context += f"- {msg.role}: {msg.content}\n"
                context += "\n"
            
            context += f"Current API message: {api_message}\n\n"
            context += "Please generate a natural response as a user working toward your goal. "
            context += "Use the available facts when appropriate, and respond naturally to the API's question or statement. "
            context += "You know the current date and time, so you can reference it when relevant to the conversation."
            
            # Create and use PydanticAI agent
            agent = self._create_agent()
            
            # Verbose/LLM-debug logging of the complete system prompt
            if self.verbose or self.llm_debug:
                sep = "=" * 80
                label = "🔬 LLM DEBUG" if self.llm_debug else "🔍 VERBOSE"
                turn_num = conversation_state.turn_count + 1
                print(f"\n{sep}")
                print(f"{label}: REPLICANT RESPONSE GENERATION  (turn={turn_num})")
                print(sep)
                print(f"Model         : {self.model_name}")
                print(f"Model Settings: {self.model_settings}")
                print()
                print("── SYSTEM PROMPT ──")
                print(self.system_prompt)
                print()
                print("── USER CONTEXT ──")
                print(context)
                print(f"{sep}\n")
            
            result = await agent.run(context)
            
            # Record token usage if a tracker is attached
            if self._token_tracker is not None:
                self._token_tracker.record_pydantic_usage(
                    self.model_name, result.usage(), purpose="response_generation"
                )

            return result.output
            
        except Exception as e:
            # Fallback to simple response if LLM fails
            print(f"PydanticAI generation failed: {e}")
            return self._generate_fallback_response(api_message, conversation_state)
    
    def _generate_fallback_response(self, api_message: str, conversation_state: ConversationState) -> str:
        """Generate a simple fallback response when LLM fails.
        
        Args:
            api_message: Message from the API
            conversation_state: Current conversation state
            
        Returns:
            Simple fallback response
        """
        api_lower = api_message.lower()
        
        # Very simple fallback responses
        if any(word in api_lower for word in ["hello", "hi", "welcome", "start"]):
            return "Hello! I'd like to get started with my request."
        elif any(word in api_lower for word in ["help", "assist"]):
            return "Yes, I'd appreciate your help with this."
        elif any(word in api_lower for word in ["confirm", "correct", "right"]):
            return "Yes, that sounds correct."
        elif "?" in api_message:
            return "I'm not sure about that. Could you help me with it?"
        else:
            return "I understand. Let's continue."


class ReplicantAgent(BaseModel):
    """Pydantic-based Replicant agent for intelligent conversation."""
    model_config = {"extra": "forbid"}
    
    config: ReplicantConfig = Field(..., description="Replicant configuration")
    state: ConversationState = Field(default_factory=ConversationState, description="Current conversation state")
    response_generator: ResponseGenerator = Field(..., description="Response generation utility")
    goal_evaluator: GoalEvaluator = Field(..., description="Goal evaluation utility")
    
    @classmethod
    def create(cls, config: ReplicantConfig, verbose: bool = False, llm_debug: bool = False, token_tracker: Optional[TokenUsageTracker] = None) -> "ReplicantAgent":
        """Create a new Replicant agent.
        
        Args:
            config: Replicant configuration
            verbose: Enable verbose output for system prompts
            llm_debug: Print complete LLM prompts on every call
            token_tracker: Optional tracker to record LLM token usage and cost
            
        Returns:
            Configured Replicant agent
        """
        # Build model settings - only include parameters that are explicitly provided
        model_settings = {}
        if config.llm.temperature is not None:
            model_settings["temperature"] = config.llm.temperature
        if config.llm.max_tokens is not None:
            model_settings["max_tokens"] = config.llm.max_tokens
        
        response_generator = ResponseGenerator(
            model_name=config.llm.model,
            system_prompt=config.system_prompt,
            model_settings=model_settings,
            facts=config.facts,
            verbose=verbose,
            llm_debug=llm_debug,
        )
        if token_tracker is not None:
            response_generator.set_tracker(token_tracker)
        
        goal_evaluator = GoalEvaluator.create(config, verbose=verbose, llm_debug=llm_debug)
        if token_tracker is not None:
            goal_evaluator.set_tracker(token_tracker)
        
        return cls(
            config=config,
            response_generator=response_generator,
            goal_evaluator=goal_evaluator
        )
    
    async def should_continue_conversation(self) -> bool:
        """Determine if the conversation should continue.
        
        Returns:
            True if conversation should continue, False if complete
        """
        # Check turn limit
        if self.state.turn_count >= self.config.max_turns:
            return False
        
        # Check if goal is already marked as achieved
        if self.state.goal_achieved:
            return False
        
        # Evaluate goal completion using the configured method
        if self.state.conversation_history:
            evaluation_result = await self.goal_evaluator.evaluate_goal_completion(
                goal=self.config.goal,
                conversation_history=self.state.conversation_history,
                facts=self.config.facts
            )
            
            # Store evaluation result for reporting
            self.state.goal_evaluation_result = evaluation_result
            
            if evaluation_result.goal_achieved:
                self.state.goal_achieved = True
                return False
        
        return True
    
    def get_initial_message(self) -> Optional[str]:
        """Get the initial message to start the conversation.
        
        Returns:
            Initial message if configured, otherwise None.
        """
        return self.config.initial_message

    async def generate_opening_message(self) -> str:
        """Generate an opening message from goal and facts when no initial_message is configured."""
        prompt = (
            f"You are starting a new conversation to achieve this goal: {self.config.goal}\n"
            f"Available facts: {json.dumps(self.config.facts, indent=2)}\n\n"
            "Write a natural opening message as a user. Be concise and direct."
        )
        return await self.response_generator.generate_response(
            api_message=prompt,
            conversation_state=self.state,
        )

    async def process_api_response(self, api_response: str, triggering_message: Optional[str] = None) -> str:
        """Process an API response and generate the next user message.
        
        Args:
            api_response: Response from the API
            triggering_message: The user message that triggered this API response (for initial message)
            
        Returns:
            Next user message
        """
        # Add the triggering user message if this is the first response
        if triggering_message:
            user_trigger_message = Message(
                role="user",
                content=triggering_message,
                timestamp=datetime.now()
            )
            self.state.conversation_history.append(user_trigger_message)
        
        # Add API response to conversation history
        api_message = Message(
            role="assistant",
            content=api_response,
            timestamp=datetime.now()
        )
        self.state.conversation_history.append(api_message)
        
        # Generate response using PydanticAI
        user_response = await self.response_generator.generate_response(api_response, self.state)
        
        # Add user response to conversation history
        user_message = Message(
            role="user",
            content=user_response,
            timestamp=datetime.now()
        )
        self.state.conversation_history.append(user_message)
        
        # Increment turn count
        self.state.turn_count += 1
        
        return user_response
    
    def get_conversation_summary(self) -> Dict[str, Any]:
        """Get a summary of the conversation.
        
        Returns:
            Conversation summary
        """
        summary = {
            "total_turns": self.state.turn_count,
            "goal_achieved": self.state.goal_achieved,
            "conversation_length": len(self.state.conversation_history),
            "facts_used": self._count_facts_used(),
            "goal": self.config.goal,
        }
        
        # Add goal evaluation details if available
        if self.state.goal_evaluation_result:
            summary.update({
                "goal_evaluation_method": self.state.goal_evaluation_result.evaluation_method,
                "goal_evaluation_confidence": self.state.goal_evaluation_result.confidence,
                "goal_evaluation_reasoning": self.state.goal_evaluation_result.reasoning,
                "goal_evaluation_fallback_used": self.state.goal_evaluation_result.fallback_used,
            })
        
        return summary
    
    def _count_facts_used(self) -> int:
        """Count how many facts were used in the conversation.
        
        Returns:
            Number of facts mentioned
        """
        facts_mentioned = set()
        
        for message in self.state.conversation_history:
            if message.role == "user":
                for fact_key, fact_value in self.config.facts.items():
                    if str(fact_value).lower() in message.content.lower():
                        facts_mentioned.add(fact_key)
        
        return len(facts_mentioned) 