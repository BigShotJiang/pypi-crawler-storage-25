"""
LangSmith integration — emit a LangSmith run for every Interven scan.

When LangSmith is configured for the LangChain process (LANGSMITH_API_KEY +
LANGSMITH_TRACING=true), this module makes every Interven decision visible
in the same trace tree the customer's engineering team already uses for
debugging the agent. Decisions appear as `interven.scan` child runs under
the parent agent run, with:

    - Inputs: tool_name, method, url (no body — bodies may carry PII)
    - Outputs: decision, risk_score, risk_band, reason_codes, trace_id
    - Tags: ['interven', 'security', '<decision>', '<risk_band>']
    - Metadata: link back to the Interven console for the full forensic view

Why this matters: it means a fintech compliance reviewer browsing LangSmith
sees the policy enforcement next to the LLM calls, without context-switching
to a second tool. It's also the single feature that makes LangChain Inc.
notice you're built natively on their stack.

LangSmith is OPTIONAL — if `langsmith` isn't installed or LANGSMITH_API_KEY
isn't set, this module silently no-ops and `InterventCallback` works exactly
as before. No customer is forced to use LangSmith.
"""
from __future__ import annotations

import logging
import os
import uuid
from typing import Any, Optional


logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lazy import — LangSmith is an optional dep. The presence of the package +
# the LANGSMITH_API_KEY env are both required for actual emission.
# ---------------------------------------------------------------------------

_LS_AVAILABLE: Optional[bool] = None


def _langsmith_enabled() -> bool:
    """True iff langsmith is importable AND tracing is configured."""
    global _LS_AVAILABLE
    if _LS_AVAILABLE is False:
        return False
    if _LS_AVAILABLE is None:
        try:
            import langsmith  # noqa: F401
            _LS_AVAILABLE = True
        except ImportError:
            _LS_AVAILABLE = False
            return False

    # LangSmith uses these env vars to decide whether to send. We respect
    # them too — if LangSmith itself isn't tracing this process, we don't
    # spam the API with our own runs.
    if not os.environ.get("LANGSMITH_API_KEY") and not os.environ.get("LANGCHAIN_API_KEY"):
        return False
    tracing = os.environ.get("LANGSMITH_TRACING", os.environ.get("LANGCHAIN_TRACING_V2", "")).lower()
    if tracing in ("false", "0", ""):
        # If the customer hasn't turned tracing on, don't fire. (LangSmith's
        # own behavior is to skip submission too in this case.)
        return False
    return True


def _console_link(trace_id: Optional[str]) -> Optional[str]:
    if not trace_id:
        return None
    return f"https://app.intervensecurity.com/activity?trace_id={trace_id}"


# ---------------------------------------------------------------------------
# Run emission. Uses langsmith.Client.create_run directly rather than the
# @traceable decorator, because we need to attach our scan as a CHILD of the
# customer's parent run (the agent / chain / tool call that triggered us)
# rather than as a free-standing root.
# ---------------------------------------------------------------------------

def emit_scan_run(
    *,
    tool_name: str,
    method: str,
    url: str,
    decision: str,
    risk_score: float,
    risk_band: str,
    reason_codes: list[str],
    trace_id: str,
    approval_id: Optional[str] = None,
    parent_run_id: Optional[uuid.UUID] = None,
    runtime_type: str = "langchain",
) -> None:
    """Best-effort emit one LangSmith run for an Interven scan decision.

    NEVER raises — LangSmith failures must not affect the agent. We log a
    warning and move on, the same way LangSmith's own client does.
    """
    if not _langsmith_enabled():
        return

    try:
        from langsmith import Client as LSClient
    except ImportError:
        return

    try:
        client = LSClient()
        run_id = uuid.uuid4()
        now_ms = _now_iso()

        # Tags help LangSmith users filter the trace tree. Lowercase so
        # they sort cleanly with LangSmith's own auto-tags.
        tags = [
            "interven",
            "interven.scan",
            f"interven.decision.{decision.lower()}",
            f"interven.risk.{risk_band.lower()}",
            f"interven.runtime.{runtime_type.lower()}",
        ]
        if reason_codes:
            tags.extend(f"interven.reason.{c.lower()}" for c in reason_codes[:5])

        # Inputs: deliberately no body. Bodies may contain PII / secrets, and
        # LangSmith stores inputs verbatim. The body lives in Interven's
        # encrypted store and is linked via console_url.
        inputs: dict[str, Any] = {
            "tool_name": tool_name,
            "method": method,
            "url": url,
        }

        outputs: dict[str, Any] = {
            "decision": decision,
            "risk_score": risk_score,
            "risk_band": risk_band,
            "reason_codes": reason_codes,
            "trace_id": trace_id,
        }
        if approval_id:
            outputs["approval_id"] = approval_id
            outputs["approval_url"] = f"https://app.intervensecurity.com/approvals/{approval_id}"

        link = _console_link(trace_id)
        metadata: dict[str, Any] = {
            "interven.console_url": link,
            "interven.runtime_type": runtime_type,
        }

        client.create_run(
            id=run_id,
            name=f"interven.scan.{tool_name}",
            run_type="tool",
            inputs=inputs,
            outputs=outputs,
            start_time=now_ms,
            end_time=now_ms,
            parent_run_id=parent_run_id,
            tags=tags,
            extra={"metadata": metadata},
            error=(
                f"Interven {decision}: {', '.join(reason_codes) or 'policy match'}"
                if decision in ("DENY", "REQUIRE_APPROVAL")
                else None
            ),
        )
    except Exception as e:  # noqa: BLE001 — best-effort
        logger.debug("[interven] LangSmith emission failed (non-fatal): %s", e)


def _now_iso() -> str:
    """LangSmith accepts ISO datetimes for start_time/end_time."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()
