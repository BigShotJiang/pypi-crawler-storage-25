"""
LangChain callback handler that routes every tool invocation through Interven.

This plugs into LangChain's standard callback system — any AgentExecutor,
CompiledGraph, or chain that respects callbacks will invoke it. No tool
code changes required.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Optional
from uuid import UUID

try:
    from langchain_core.callbacks import BaseCallbackHandler
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "interven-langchain requires langchain-core. "
        "pip install 'interven-langchain[langchain]' or pip install langchain-core"
    ) from e

from interven import Client

from .langsmith_integration import emit_scan_run


logger = logging.getLogger(__name__)


class InterventBlockedError(RuntimeError):
    """Raised when Interven blocks a tool call. Stops the agent loop cleanly."""

    def __init__(self, tool: str, reason_codes: list[str], trace_id: str, approval_url: Optional[str] = None):
        self.tool = tool
        self.reason_codes = reason_codes
        self.trace_id = trace_id
        self.approval_url = approval_url
        msg = f"[Interven] Tool '{tool}' blocked: {', '.join(reason_codes) or 'policy'}"
        if approval_url:
            msg += f" — approve at {approval_url}"
        super().__init__(msg)


class InterventCallback(BaseCallbackHandler):
    """LangChain callback that scans every tool call through Interven.

    Installation:

        from langchain.agents import AgentExecutor
        from interven_langchain import InterventCallback
        agent = AgentExecutor(..., callbacks=[InterventCallback(api_key="iv_live_...")])

    Decision handling:

    - ALLOW             → tool runs normally
    - SANITIZE          → tool input is replaced with the sanitized_body and the tool runs
    - DENY              → raises InterventBlockedError (or returns a refusal via on_tool_error)
    - REQUIRE_APPROVAL  → raises InterventBlockedError pointing at the approval URL

    Options:
    - `on_block`: "raise" (default, stops the agent) or "return_message" (returns a refusal
      string to the LLM so it can replan without the tool result)
    - `mode`: "scan_only" (call /v1/scan and honor its decision — the default, framework-native)
             or "tool_gateway" (call /v1/tools/... and let Interven execute the tool on behalf
             of the agent; requires a registered credential on the Interven tenant)
    """

    # We need to see the start of tool calls to scan them, and optionally end/error.
    # When tool calls are nested we track them by run_id.
    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        client: Optional[Client] = None,
        on_block: str = "raise",
        gateway_url: Optional[str] = None,
        timeout: float = 30.0,
        runtime_type: str = "langchain",
    ):
        if on_block not in ("raise", "return_message"):
            raise ValueError("on_block must be 'raise' or 'return_message'")
        self.client = client or Client(
            api_key=api_key,
            gateway_url=gateway_url,
            timeout=timeout,
            runtime_type=runtime_type,
        )
        self.on_block = on_block
        # Track run_id -> (sanitized_input_str, original_input_str) so we can modify on start
        self._sanitized_inputs: dict[str, str] = {}
        # Track blocked runs so on_tool_end doesn't complain
        self._blocked_runs: dict[str, InterventBlockedError] = {}

    # LangChain invokes this before a tool starts executing.
    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[list[str]] = None,
        metadata: Optional[dict[str, Any]] = None,
        inputs: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        tool_name = (serialized or {}).get("name") or "unknown"
        # Heuristic URL extraction: if the tool is clearly an HTTP tool, try to pull url/method.
        # Otherwise treat the tool as a generic call and pass the input_str as body.text.
        body: Any
        method = "POST"
        url = f"tool://langchain/{tool_name}"
        if inputs and isinstance(inputs, dict):
            body = inputs
            url_candidate = inputs.get("url") or inputs.get("endpoint")
            if isinstance(url_candidate, str) and url_candidate.startswith(("http://", "https://")):
                url = url_candidate
                method = str(inputs.get("method", "POST")).upper()
        else:
            try:
                body = json.loads(input_str) if input_str else {}
                if not isinstance(body, dict):
                    body = {"input": input_str}
            except json.JSONDecodeError:
                body = {"input": input_str}

        try:
            result = self.client.scan(method=method, url=url, body=body)
        except Exception as e:
            # Fail-open: Interven unavailable → don't block the agent.
            logger.warning("[interven] scan unavailable, allowing tool call: %s", e)
            return

        # LangSmith integration — emit one child run per scan so the decision
        # shows up in the customer's existing trace tree. No-ops cleanly when
        # langsmith isn't installed or LANGSMITH_API_KEY isn't set.
        try:
            emit_scan_run(
                tool_name=tool_name,
                method=method,
                url=url,
                decision=result.decision,
                risk_score=getattr(result, "risk_score", 0.0),
                risk_band=getattr(result, "risk_band", "LOW"),
                reason_codes=list(getattr(result, "reason_codes", []) or []),
                trace_id=result.trace_id,
                approval_id=getattr(result, "approval_id", None),
                parent_run_id=run_id,
                runtime_type=self.client.runtime_type,
            )
        except Exception:  # noqa: BLE001
            # LangSmith failures must never break the agent. Already logged
            # inside emit_scan_run; ignore here.
            pass

        if result.decision == "ALLOW":
            return

        if result.decision == "SANITIZE":
            # Best-effort: if the original input_str parsed to a dict, replace fields from sanitized_body.
            # We can't actually mutate LangChain's input_str from here — only newer callback signatures
            # allow modification. So we log and let it pass; the DOWNSTREAM tool still gets the original.
            # This is the "scan-only" limitation — for true in-flight redaction use tool_gateway mode
            # or the guard() wrapper below.
            logger.warning(
                "[interven] SANITIZE on tool '%s' — trace %s. Upgrade to guard() wrapper for in-flight redaction.",
                tool_name, result.trace_id,
            )
            return

        # DENY or REQUIRE_APPROVAL — stop the tool
        err = InterventBlockedError(
            tool=tool_name,
            reason_codes=result.reason_codes,
            trace_id=result.trace_id,
            approval_url=(
                f"https://app.intervensecurity.com/approvals/{result.approval_id}"
                if result.approval_id else None
            ),
        )
        self._blocked_runs[str(run_id)] = err

        if self.on_block == "raise":
            raise err
        # on_block == "return_message": swallow here; on_tool_end will inject the refusal string.
        logger.info("[interven] %s blocked tool '%s', refusal will be surfaced to LLM", result.decision, tool_name)

    def on_tool_end(self, output: Any, *, run_id: UUID, **kwargs: Any) -> Any:
        blk = self._blocked_runs.pop(str(run_id), None)
        if blk is not None and self.on_block == "return_message":
            # Return the refusal text — LangChain will pass this back to the LLM as the tool's output.
            return str(blk)
        return output

    def on_tool_error(self, error: BaseException, *, run_id: UUID, **kwargs: Any) -> None:
        # Make sure blocked runs drop cleanly.
        self._blocked_runs.pop(str(run_id), None)
