"""
Tool-wrapper pattern — wrap an individual LangChain BaseTool so its invocations
are scanned by Interven before the real tool runs.

Use this when the callback pattern isn't enough (e.g., you need in-flight
SANITIZE to actually replace the tool input).

    from interven_langchain import guard
    from langchain_community.tools.tavily_search import TavilySearchResults

    tavily = guard(TavilySearchResults(), api_key="iv_live_...")
    result = tavily.invoke({"query": "..."})
"""
from __future__ import annotations

import json
import logging
from typing import Any, Optional

try:
    from langchain_core.tools import BaseTool
except ImportError as e:  # pragma: no cover
    raise ImportError("interven-langchain requires langchain-core. pip install langchain-core") from e

from interven import Client

from .callback import InterventBlockedError


logger = logging.getLogger(__name__)


def guard(tool: BaseTool, *, api_key: Optional[str] = None, client: Optional[Client] = None) -> BaseTool:
    """Return a new tool that scans each invocation through Interven before delegating.

    On DENY or REQUIRE_APPROVAL, `tool._run` raises InterventBlockedError.
    On SANITIZE, the scan's sanitized_body is used in place of the original input.
    """
    c = client or Client(api_key=api_key, runtime_type="langchain")
    original_run = tool._run
    original_arun = getattr(tool, "_arun", None)

    def _do_scan(tool_input: Any) -> Any:
        url = f"tool://langchain/{tool.name}"
        body = tool_input if isinstance(tool_input, dict) else {"input": tool_input}
        result = c.scan(method="POST", url=url, body=body)

        if result.decision == "ALLOW":
            return tool_input
        if result.decision == "SANITIZE":
            return result.sanitized_body if isinstance(result.sanitized_body, dict) else tool_input
        raise InterventBlockedError(
            tool=tool.name,
            reason_codes=result.reason_codes,
            trace_id=result.trace_id,
            approval_url=(
                f"https://app.intervensecurity.com/approvals/{result.approval_id}"
                if result.approval_id else None
            ),
        )

    def wrapped_run(*args: Any, **kwargs: Any) -> Any:
        # LangChain BaseTool._run signature varies by version; pass through unchanged
        # but scan the args dict first.
        if args:
            scanned = _do_scan(args[0])
            new_args = (scanned,) + args[1:]
            return original_run(*new_args, **kwargs)
        if kwargs:
            scanned = _do_scan(kwargs)
            return original_run(**(scanned if isinstance(scanned, dict) else kwargs))
        return original_run()

    tool._run = wrapped_run  # type: ignore[assignment]

    if original_arun is not None:
        async def wrapped_arun(*args: Any, **kwargs: Any) -> Any:
            if args:
                scanned = _do_scan(args[0])
                new_args = (scanned,) + args[1:]
                return await original_arun(*new_args, **kwargs)
            if kwargs:
                scanned = _do_scan(kwargs)
                return await original_arun(**(scanned if isinstance(scanned, dict) else kwargs))
            return await original_arun()

        tool._arun = wrapped_arun  # type: ignore[assignment]

    return tool
