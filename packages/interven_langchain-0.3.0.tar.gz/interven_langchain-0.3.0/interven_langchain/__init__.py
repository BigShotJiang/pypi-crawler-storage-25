"""
LangChain + LangGraph integration for Interven AI firewall.

LangGraph is built on top of LangChain's callback system, so the same
InterventCallback works for both. Pick the integration style that fits:

1. Callback (zero-glue, works in every prebuilt LangGraph agent):

    from langgraph.prebuilt import create_react_agent
    from interven_langchain import InterventCallback

    agent = create_react_agent(model, tools)
    cb = InterventCallback(api_key="iv_live_...")
    agent.invoke({"messages": [...]}, config={"callbacks": [cb]})

2. ToolNode replacement (LangGraph custom graphs — no config-threading):

    from interven_langchain.langgraph import interven_tool_node

    graph.add_node("tools", interven_tool_node(my_tools, api_key="iv_live_..."))

3. Tool wrapper (LangChain agents that invoke tools directly):

    from interven_langchain import guard

    guarded_tool = guard(MyTool(), api_key="iv_live_...")
    agent.invoke(..., tools=[guarded_tool])

4. Compiled-graph guard (custom LangGraph nodes, attach once to the
   compiled graph instead of threading callbacks):

    from interven_langchain.langgraph import guard_state_graph

    graph = builder.compile()
    guarded = guard_state_graph(graph, api_key="iv_live_...")
    guarded.invoke({"messages": [...]})

5. Custom node helper (you write your own tool-execution loop):

    from interven_langchain.langgraph import scan_tool_call

    decision = scan_tool_call(tool_name="...", args={...}, api_key="iv_live_...")
    if decision.is_blocked: ...
"""
from .callback import InterventCallback, InterventBlockedError
from .wrapper import guard

__all__ = ["InterventCallback", "InterventBlockedError", "guard"]
__version__ = "0.3.0"
