"""
LangGraph-specific helpers.

LangGraph is built on top of LangChain's callback infrastructure, so
`InterventCallback` (from interven_langchain.callback) already works for any
LangGraph agent that respects the `config={"callbacks": [...]}` parameter —
that is, every prebuilt agent (`create_react_agent`, `ToolNode`) and every
custom graph that passes config through. See docs.intervensecurity.com/docs/integrations/langgraph
for the full integration matrix.

This module adds LangGraph-specific ergonomics that the bare callback can't
cover:

    1. interven_tool_node()
       Drop-in replacement for langgraph.prebuilt.ToolNode that scans every
       tool invocation through Interven before execution.

    2. scan_tool_call()
       Synchronous helper for custom graph nodes that build their own
       tool-execution loops. Returns a decision the node can act on.

    3. guard_state_graph()
       Convenience wrapper that bolts InterventCallback onto every node that
       executes a tool. Use this when you don't want to thread `config` through
       every node yourself.

These all delegate to the same /v1/scan endpoint as the LangChain callback
and respect the same on_block, runtime_type, and timeout options.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Callable, Optional, Sequence

from interven import Client

from .callback import InterventBlockedError, InterventCallback
from .langsmith_integration import emit_scan_run


logger = logging.getLogger(__name__)


def _import_langgraph():
    """Lazy import so the package installs cleanly even when langgraph isn't pinned."""
    try:
        from langgraph.prebuilt import ToolNode  # type: ignore
        from langgraph.graph import StateGraph  # type: ignore
        return ToolNode, StateGraph
    except ImportError as e:  # pragma: no cover
        raise ImportError(
            "interven_langchain.langgraph helpers require LangGraph. "
            "pip install 'interven-langchain[langgraph]' or pip install langgraph>=0.2"
        ) from e


# ---------------------------------------------------------------------------
# 1. interven_tool_node — drop-in replacement for langgraph.prebuilt.ToolNode
# ---------------------------------------------------------------------------

def interven_tool_node(
    tools: Sequence[Any],
    *,
    api_key: Optional[str] = None,
    client: Optional[Client] = None,
    on_block: str = "raise",
    gateway_url: Optional[str] = None,
    runtime_type: str = "langgraph",
):
    """Build a LangGraph ToolNode wrapped with Interven scanning.

    Every tool the agent invokes inside the graph is scanned through Interven
    before execution. ALLOW + SANITIZE proceed to the real tool; DENY +
    REQUIRE_APPROVAL stop the tool with InterventBlockedError (or surface a
    refusal string to the LLM, depending on `on_block`).

    Usage:

        from langgraph.graph import StateGraph
        from interven_langchain.langgraph import interven_tool_node

        graph = StateGraph(MyState)
        graph.add_node("tools", interven_tool_node(my_tools, api_key="iv_live_..."))

    Args:
        tools: The list of LangChain BaseTool instances the node will execute.
        api_key: Interven API key (or pass `client=` for an existing Client).
        on_block: "raise" (default) — DENY/REQUIRE_APPROVAL stops the graph;
                  "return_message" — surfaces a refusal string to the LLM
                  so it can replan without that tool's result.
        gateway_url: Override the hosted endpoint (self-hosted Interven).
        runtime_type: Tagged on every scan record so the activity feed can
                      filter LangGraph-originated calls. Default: "langgraph".

    Returns:
        A LangGraph ToolNode whose .invoke() / .ainvoke() route through
        Interven first.
    """
    ToolNode, _ = _import_langgraph()

    cb = InterventCallback(
        api_key=api_key,
        client=client,
        on_block=on_block,
        gateway_url=gateway_url,
        runtime_type=runtime_type,
    )
    node = ToolNode(list(tools))

    # ToolNode is a Runnable. We attach our callback by wrapping invoke/ainvoke
    # so every call carries the Interven callback in config. This way the user
    # doesn't have to thread `config={"callbacks": [...]}` through every place
    # they invoke the node.
    original_invoke = node.invoke
    original_ainvoke = node.ainvoke

    def _merged_config(config: Optional[dict]) -> dict:
        cfg = dict(config or {})
        callbacks = list(cfg.get("callbacks") or [])
        if cb not in callbacks:
            callbacks.append(cb)
        cfg["callbacks"] = callbacks
        return cfg

    def invoke(input: Any, config: Optional[dict] = None, **kwargs: Any):
        return original_invoke(input, _merged_config(config), **kwargs)

    async def ainvoke(input: Any, config: Optional[dict] = None, **kwargs: Any):
        return await original_ainvoke(input, _merged_config(config), **kwargs)

    # Re-bind methods on the instance. ToolNode subclasses Runnable so this is
    # safe — the Runnable interface is pure-function-of-args.
    node.invoke = invoke  # type: ignore[method-assign]
    node.ainvoke = ainvoke  # type: ignore[method-assign]
    return node


# ---------------------------------------------------------------------------
# 2. scan_tool_call — synchronous helper for custom graph nodes
# ---------------------------------------------------------------------------

@dataclass
class ScanDecision:
    """The result of scanning one tool call. Matches /v1/scan, plus a
    `should_run` convenience flag for the common "is this allowed?" check."""
    decision: str
    risk_score: float
    risk_band: str
    reason_codes: list[str]
    trace_id: str
    sanitized_body: Any = None
    approval_id: Optional[str] = None

    @property
    def should_run(self) -> bool:
        """True for ALLOW + SANITIZE (caller swaps in sanitized_body), False otherwise."""
        return self.decision in ("ALLOW", "SANITIZE")

    @property
    def is_blocked(self) -> bool:
        return self.decision in ("DENY", "REQUIRE_APPROVAL")


def scan_tool_call(
    tool_name: str,
    args: Any,
    *,
    api_key: Optional[str] = None,
    client: Optional[Client] = None,
    url: Optional[str] = None,
    method: str = "POST",
    runtime_type: str = "langgraph",
) -> ScanDecision:
    """Scan one tool call and return a decision. Use inside custom nodes.

    LangGraph users sometimes write their own tool-execution node:

        def call_tool(state: AgentState) -> AgentState:
            tool_call = state["messages"][-1].tool_calls[0]
            decision = scan_tool_call(
                tool_name=tool_call["name"],
                args=tool_call["args"],
                api_key="iv_live_...",
            )
            if decision.is_blocked:
                return {"messages": [ToolMessage(
                    content=f"Blocked: {', '.join(decision.reason_codes)}",
                    tool_call_id=tool_call["id"],
                )]}
            args = decision.sanitized_body if decision.decision == "SANITIZE" else tool_call["args"]
            result = tool_registry[tool_call["name"]].invoke(args)
            return {"messages": [ToolMessage(content=result, tool_call_id=tool_call["id"])]}

    For built-in nodes (ToolNode, create_react_agent), use interven_tool_node()
    or InterventCallback instead — they're zero-glue.
    """
    c = client or Client(api_key=api_key, runtime_type=runtime_type)

    # Args may be a dict ({"input": "..."}), a string, or a structured object.
    body: Any
    if isinstance(args, dict):
        body = args
    elif isinstance(args, str):
        try:
            body = json.loads(args)
        except json.JSONDecodeError:
            body = {"input": args}
    else:
        body = {"input": args}

    effective_url = url or f"tool://langgraph/{tool_name}"
    result = c.scan(method=method, url=effective_url, body=body)

    # LangSmith span emission (no-ops cleanly when LangSmith isn't wired up).
    # In a custom-node context we don't have a parent_run_id from the callback
    # system, so the run shows up at the top level of the trace tree — still
    # useful, just less nested than InterventCallback's emission.
    try:
        emit_scan_run(
            tool_name=tool_name,
            method=method,
            url=effective_url,
            decision=result.decision,
            risk_score=getattr(result, "risk_score", 0.0),
            risk_band=getattr(result, "risk_band", "LOW"),
            reason_codes=list(getattr(result, "reason_codes", []) or []),
            trace_id=result.trace_id,
            approval_id=getattr(result, "approval_id", None),
            runtime_type=runtime_type,
        )
    except Exception:  # noqa: BLE001
        pass

    return ScanDecision(
        decision=result.decision,
        risk_score=result.risk_score,
        risk_band=result.risk_band,
        reason_codes=list(result.reason_codes or []),
        trace_id=result.trace_id,
        sanitized_body=getattr(result, "sanitized_body", None),
        approval_id=getattr(result, "approval_id", None),
    )


# ---------------------------------------------------------------------------
# 3. guard_state_graph — bolts InterventCallback into a compiled graph's invoke
# ---------------------------------------------------------------------------

def guard_state_graph(
    compiled_graph: Any,
    *,
    api_key: Optional[str] = None,
    client: Optional[Client] = None,
    on_block: str = "raise",
    gateway_url: Optional[str] = None,
    runtime_type: str = "langgraph",
):
    """Wrap a compiled LangGraph so every invoke/stream/ainvoke carries the
    Interven callback. Useful when you've built the graph yourself but don't
    want to thread the callback through every entry point.

    Usage:

        graph = builder.compile()
        guarded = guard_state_graph(graph, api_key="iv_live_...")
        guarded.invoke({"messages": [HumanMessage("hello")]})
    """
    cb = InterventCallback(
        api_key=api_key,
        client=client,
        on_block=on_block,
        gateway_url=gateway_url,
        runtime_type=runtime_type,
    )

    def _merge(config: Optional[dict]) -> dict:
        cfg = dict(config or {})
        callbacks = list(cfg.get("callbacks") or [])
        if cb not in callbacks:
            callbacks.append(cb)
        cfg["callbacks"] = callbacks
        return cfg

    # We don't subclass — we proxy the four methods the user is most likely to call.
    class GuardedGraph:
        def __init__(self, inner: Any) -> None:
            self._inner = inner
            self._cb = cb

        def __getattr__(self, name: str) -> Any:
            return getattr(self._inner, name)

        def invoke(self, input: Any, config: Optional[dict] = None, **kwargs: Any) -> Any:
            return self._inner.invoke(input, _merge(config), **kwargs)

        async def ainvoke(self, input: Any, config: Optional[dict] = None, **kwargs: Any) -> Any:
            return await self._inner.ainvoke(input, _merge(config), **kwargs)

        def stream(self, input: Any, config: Optional[dict] = None, **kwargs: Any):
            yield from self._inner.stream(input, _merge(config), **kwargs)

        async def astream(self, input: Any, config: Optional[dict] = None, **kwargs: Any):
            async for chunk in self._inner.astream(input, _merge(config), **kwargs):
                yield chunk

    return GuardedGraph(compiled_graph)


__all__ = [
    "InterventBlockedError",
    "InterventCallback",
    "interven_tool_node",
    "scan_tool_call",
    "guard_state_graph",
    "ScanDecision",
]
