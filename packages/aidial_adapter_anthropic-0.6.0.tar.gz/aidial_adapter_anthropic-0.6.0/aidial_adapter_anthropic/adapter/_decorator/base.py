from collections.abc import Callable
from dataclasses import dataclass

from aidial_sdk.chat_completion import Message
from pydantic import BaseModel

from aidial_adapter_anthropic.adapter._base import ChatCompletionAdapter
from aidial_adapter_anthropic.adapter._truncate_prompt import DiscardedMessages
from aidial_adapter_anthropic.dial.consumer import Consumer
from aidial_adapter_anthropic.dial.request import ModelParameters


@dataclass
class ChatCompletionDecorator(ChatCompletionAdapter):
    adapter: ChatCompletionAdapter

    async def chat(
        self,
        consumer: Consumer,
        params: ModelParameters,
        messages: list[Message],
    ) -> None:
        await self.adapter.chat(consumer, params, messages)

    async def configuration(self) -> type[BaseModel]:
        return await self.adapter.configuration()

    async def count_prompt_tokens(
        self, params: ModelParameters, messages: list[Message]
    ) -> int:
        return await self.adapter.count_prompt_tokens(params, messages)

    async def count_completion_tokens(self, string: str) -> int:
        return await self.adapter.count_completion_tokens(string)

    async def compute_discarded_messages(
        self, params: ModelParameters, messages: list[Message]
    ) -> DiscardedMessages | None:
        return await self.adapter.compute_discarded_messages(params, messages)


ChatCompletionTransformer = Callable[
    [ChatCompletionAdapter], ChatCompletionAdapter
]


def compose_decorators(
    *decorators: ChatCompletionTransformer,
) -> ChatCompletionTransformer:
    def compose(adapter: ChatCompletionAdapter) -> ChatCompletionAdapter:
        for decorator in reversed(decorators):
            adapter = decorator(adapter)
        return adapter

    return compose
