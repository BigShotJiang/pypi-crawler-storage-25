from abc import ABC, abstractmethod
from typing import Any

from aidial_sdk.chat_completion import Message
from pydantic import BaseModel

from aidial_adapter_anthropic._utils.list import ListProjection
from aidial_adapter_anthropic.adapter._errors import ValidationError
from aidial_adapter_anthropic.adapter._truncate_prompt import DiscardedMessages
from aidial_adapter_anthropic.dial.consumer import Consumer
from aidial_adapter_anthropic.dial.request import (
    ModelParameters,
    collect_text_content,
    is_system_role,
)


class ChatCompletionAdapter(ABC):
    @abstractmethod
    async def chat(
        self,
        consumer: Consumer,
        params: ModelParameters,
        messages: list[Message],
    ) -> None:
        pass

    async def configuration(self) -> type[BaseModel]:
        raise NotImplementedError

    async def count_prompt_tokens(
        self, params: ModelParameters, messages: list[Message]
    ) -> int:
        raise NotImplementedError

    async def count_completion_tokens(self, string: str) -> int:
        raise NotImplementedError

    async def compute_discarded_messages(
        self, params: ModelParameters, messages: list[Message]
    ) -> DiscardedMessages | None:
        """
        The method truncates the list of messages to fit
        into the token limit set in `params.max_prompt_tokens`.

        If the limit isn't provided, then it returns None.
        Otherwise, returns the indices of _discarded_ messages which should be
        removed from the list to make the rest fit into the token limit.
        """
        raise NotImplementedError


def default_preprocess_messages(
    messages: list[Message],
) -> ListProjection[Message]:
    def _is_empty_system_message(msg: Message) -> bool:
        return (
            is_system_role(msg.role)
            and collect_text_content(msg.content).strip() == ""
        )

    ret: list[tuple[Message, set[int]]] = []
    idx: set[int] = set()

    for i, msg in enumerate(messages):
        idx.add(i)
        if _is_empty_system_message(msg):
            continue
        ret.append((msg, idx))
        idx = set()

    if len(ret) == 0:
        raise ValidationError("List of messages must not be empty")

    return ListProjection(ret)


def keep_last(messages: list[Any], idx: int) -> bool:
    return idx == len(messages) - 1


def keep_last_and_system_messages(messages: list[Message], idx: int) -> bool:
    return is_system_role(messages[idx].role) or keep_last(messages, idx)


def trivial_partitioner(messages: list[Any]) -> list[int]:
    return [1] * len(messages)


def turn_based_partitioner(messages: list[Any]) -> list[int]:
    n = len(messages)
    return [2] * (n // 2) + [1] * (n % 2)
