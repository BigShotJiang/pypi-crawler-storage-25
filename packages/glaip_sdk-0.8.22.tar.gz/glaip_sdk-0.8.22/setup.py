"""Setup script for GLLM Modules."""

from setuptools import setup

if __name__ == "__main__":
    setup(
        build_with_nuitka=True,
        name="glaip-sdk-binary",
        version="0.8.22",
    )
