import argparse
import asyncio
import os
import re
import sys
import uuid
from pathlib import Path

from dotenv import load_dotenv

# Load .env from cwd (and walk up) before reading any LLM_* env vars. Existing
# shell-exported env values take precedence (override=False).
load_dotenv(override=False)

from .agent import ALL_TOOLS, DEFAULT_MODEL, run_once  # noqa: E402


def _parse_disabled(raw: str) -> list[str]:
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    unknown = [p for p in parts if p not in ALL_TOOLS]
    if unknown:
        raise argparse.ArgumentTypeError(
            f"Unknown tool(s): {unknown}. Choose from {list(ALL_TOOLS)}."
        )
    return parts


_ALIAS_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# Common DuckDB reserved words that would break `CREATE VIEW <alias> AS ...`.
# Not exhaustive — this catches the words a human is likely to type as an alias.
# Case-insensitive match. `vcf` is intentionally NOT here (it's the default alias).
_RESERVED_ALIASES = frozenset(
    {
        "all", "alter", "and", "any", "as", "asc", "between", "by",
        "case", "cast", "check", "column", "constraint", "create",
        "cross", "current_date", "current_time", "current_timestamp",
        "default", "delete", "desc", "describe", "distinct", "drop",
        "else", "end", "except", "exists", "false", "fetch", "for",
        "foreign", "from", "full", "grant", "group", "having", "in",
        "inner", "insert", "intersect", "into", "is", "join", "left",
        "like", "limit", "natural", "not", "null", "offset", "on",
        "only", "or", "order", "outer", "pivot", "primary", "references",
        "right", "select", "show", "some", "summarize", "table", "then",
        "to", "true", "union", "unique", "unpivot", "update", "using",
        "values", "view", "when", "where", "window", "with",
    }
)


def _parse_vcf_specs(raw: str) -> list[tuple[str, Path]]:
    """Parse a VCF spec string into a list of (alias, Path) pairs.

    Two forms are accepted:
      - Single bare path: "sample.vcf.gz" -> [("vcf", Path("sample.vcf.gz"))].
      - Comma-separated alias=path: "proband=p.vcf.gz,father=f.vcf.gz".

    Mixing the two forms in a single argument is rejected. Aliases must be
    valid SQL identifiers (used unquoted in CREATE VIEW), max 32 chars.
    """
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    if not parts:
        return []

    has_eq = [("=" in p) for p in parts]
    # Single part with '=' whose left-of-partition can't even be a candidate
    # alias is almost certainly a bare path with '=' in the filename — fast-path
    # that with a clear error before the generic "Invalid alias" message
    # confuses the user. Reserved-keyword aliases fall through to the normal
    # aliased branch so they get the dedicated reserved-keyword error.
    if len(parts) == 1 and has_eq[0]:
        head, _, _ = parts[0].partition("=")
        head = head.strip()
        # An empty head is unambiguously '=path' which has its own dedicated
        # error in the aliased branch — let that one fire instead.
        if head and (not _ALIAS_RE.match(head) or len(head) > 32):
            raise argparse.ArgumentTypeError(
                f"Could not parse VCF spec {parts[0]!r}: looks like a bare path "
                "containing '=' (which we use as the alias separator). Rename "
                "the file or wrap it in an alias, e.g. 'sample=path.vcf.gz'."
            )
    if any(has_eq) and not all(has_eq):
        raise argparse.ArgumentTypeError(
            "Mix of bare path and alias=path is not allowed. "
            "Either give one bare path, or alias every path."
        )
    if not any(has_eq):
        if len(parts) > 1:
            raise argparse.ArgumentTypeError(
                "Multiple paths require alias=path syntax, e.g. "
                "'proband=p.vcf.gz,father=f.vcf.gz'."
            )
        return [("vcf", Path(parts[0]))]

    specs: list[tuple[str, Path]] = []
    seen: set[str] = set()
    for p in parts:
        alias, _, path_str = p.partition("=")
        alias = alias.strip()
        path_str = path_str.strip()
        if not alias:
            raise argparse.ArgumentTypeError(f"Empty alias in spec: {p!r}.")
        if not path_str:
            raise argparse.ArgumentTypeError(f"Empty path for alias {alias!r}.")
        if not _ALIAS_RE.match(alias) or len(alias) > 32:
            raise argparse.ArgumentTypeError(
                f"Invalid alias {alias!r}: must match [A-Za-z_][A-Za-z0-9_]* and be ≤32 chars."
            )
        if alias.lower() in _RESERVED_ALIASES:
            raise argparse.ArgumentTypeError(
                f"Reserved DuckDB keyword: {alias!r}. Pick a different alias "
                f"(e.g. add a suffix: {alias}_view)."
            )
        if alias.lower() in seen:
            raise argparse.ArgumentTypeError(
                f"Duplicate alias: {alias!r} (aliases are case-insensitive in DuckDB)."
            )
        seen.add(alias.lower())
        specs.append((alias, Path(path_str)))
    return specs


def _env_truthy(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def _resolve_prompt(prompt: str | None, prompt_file: Path | None) -> str:
    """Read the prompt from --prompt, --prompt-file, or stdin.

    Precedence: --prompt-file > --prompt. If --prompt is `-`, read stdin.
    """
    if prompt_file is not None:
        if not prompt_file.exists():
            raise SystemExit(f"ERROR: prompt file not found: {prompt_file}")
        return prompt_file.read_text(encoding="utf-8").strip()
    if prompt is None:
        raise SystemExit("ERROR: provide --prompt or --prompt-file.")
    if prompt == "-":
        data = sys.stdin.read().strip()
        if not data:
            raise SystemExit("ERROR: --prompt - was given but stdin is empty.")
        return data
    return prompt


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="aiva_agent",
        description="Ask natural-language questions about a VCF, gather variant annotations, search literature, find trials, or classify variants.",
    )
    parser.add_argument(
        "--disable",
        type=_parse_disabled,
        default=os.environ.get("AIVA_DISABLE", ""),
        help=(
            f"Comma-separated tools to disable. Choices: {list(ALL_TOOLS)}. "
            "Falls back to AIVA_DISABLE env var; the flag replaces (does not merge) "
            "the env value. Default: nothing disabled (all tools on)."
        ),
    )
    parser.add_argument(
        "--vcf",
        type=_parse_vcf_specs,
        default=None,
        help=(
            "VCF spec(s). Single bare path: '--vcf sample.vcf.gz' (registers "
            "view `vcf`). Multiple aliased paths: "
            "'--vcf proband=p.vcf.gz,father=f.vcf.gz' (registers views "
            "`proband`, `father`). Falls back to AIVA_VCF env var; the flag "
            "replaces (does not merge) the env value. If neither is set, the "
            "vcf tool auto-disables itself."
        ),
    )
    prompt_group = parser.add_mutually_exclusive_group(required=True)
    prompt_group.add_argument(
        "--prompt",
        type=str,
        help="The question to ask the agent. Use '-' to read from stdin.",
    )
    prompt_group.add_argument(
        "--prompt-file",
        type=Path,
        help="Path to a file containing the prompt (UTF-8). Trailing whitespace is stripped.",
    )
    parser.add_argument(
        "--model",
        default=os.environ.get("LLM_MODEL", DEFAULT_MODEL),
        help=(
            "Model ID exactly as the provider expects "
            "(e.g. 'gpt-5.5', 'claude-opus-4-7', 'grok-2', 'meta-llama/Llama-3.1-70B-Instruct'). "
            "Falls back to LLM_MODEL env var, then to a built-in default."
        ),
    )
    parser.add_argument(
        "--base-url",
        default=None,
        help=(
            "OpenAI-compatible endpoint base URL (e.g. https://api.openai.com/v1, "
            "https://api.x.ai/v1, https://api.anthropic.com/v1). Falls back to LLM_BASE_URL env var."
        ),
    )
    parser.add_argument(
        "--api-key",
        default=None,
        help=(
            "API key for the chosen provider. Falls back to LLM_API_KEY env var. "
            "Prefer setting LLM_API_KEY in the environment to avoid shell-history leakage."
        ),
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="Write the agent's answer to this file instead of stdout. Parent directories are created automatically.",
    )
    parser.add_argument(
        "--session-id",
        type=str,
        default=os.environ.get("AIVA_SESSION_ID", "").strip() or None,
        help=(
            "Conversation session ID. Reuse the same value across runs to "
            "continue a conversation; history is stored in ~/.aiva/sessions.db. "
            "Falls back to AIVA_SESSION_ID env var. If unset, a fresh UUID is "
            "generated per run (effectively stateless)."
        ),
    )
    parser.add_argument(
        "--force",
        action="store_true",
        default=_env_truthy("AIVA_FORCE"),
        help=(
            "Allow --output to overwrite an existing file. Falls back to "
            "AIVA_FORCE env (1/true/yes); the flag wins if set."
        ),
    )
    args = parser.parse_args()

    session_id = args.session_id or f"aiva-{uuid.uuid4().hex[:12]}"

    disabled = list(args.disable)

    # args.vcf is None when --vcf was not given (sentinel default), else the
    # parsed list. When None, fall back to AIVA_VCF env so we can also tell
    # the user that the source was env in any "VCF not found" message.
    if args.vcf is None:
        env_raw = os.environ.get("AIVA_VCF", "")
        if env_raw:
            try:
                vcf_specs: list[tuple[str, Path]] = _parse_vcf_specs(env_raw)
            except argparse.ArgumentTypeError as e:
                print(f"error: AIVA_VCF: {e}", file=sys.stderr)
                return 2
        else:
            vcf_specs = []
        vcf_from_env = bool(vcf_specs)
    else:
        vcf_specs = list(args.vcf)
        vcf_from_env = False

    if "vcf" not in disabled:
        if not vcf_specs:
            print(
                "warning: vcf tool disabled (no --vcf flag or AIVA_VCF env). "
                "Pass --disable vcf to silence, or set AIVA_VCF in .env.",
                file=sys.stderr,
            )
            disabled.append("vcf")
        else:
            missing = [(alias, path) for alias, path in vcf_specs if not path.exists()]
            if missing:
                origin = " (from AIVA_VCF)" if vcf_from_env else ""
                for _alias, path in missing:
                    print(f"VCF not found: {path}{origin}", file=sys.stderr)
                return 2

    prompt = _resolve_prompt(args.prompt, args.prompt_file)

    if args.output is not None and args.output.exists() and not args.force:
        print(
            f"ERROR: {args.output} already exists. Pass --force to overwrite.",
            file=sys.stderr,
        )
        return 2

    if not args.session_id:
        print(
            f"session: {session_id} (set AIVA_SESSION_ID to resume)",
            file=sys.stderr,
        )

    result = asyncio.run(
        run_once(
            prompt,
            vcf_specs=vcf_specs if "vcf" not in disabled else None,
            disabled_tools=disabled,
            model=args.model,
            base_url=args.base_url,
            api_key=args.api_key,
            session_id=session_id,
        )
    )

    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(result, encoding="utf-8")
        print(f"Wrote {len(result)} chars to {args.output}", file=sys.stderr)
    else:
        print(result)
    return 0


if __name__ == "__main__":
    sys.exit(main())
