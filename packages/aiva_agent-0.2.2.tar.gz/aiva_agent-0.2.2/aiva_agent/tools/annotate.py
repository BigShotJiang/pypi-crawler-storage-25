import asyncio
import logging
import urllib.parse
from typing import Any

import httpx
from agents import function_tool

from ._shared import to_json

logger = logging.getLogger(__name__)

VEP_HOSTS = {
    "hg38": "https://rest.ensembl.org",
    "grch38": "https://rest.ensembl.org",
    "hg19": "https://grch37.rest.ensembl.org",
    "grch37": "https://grch37.rest.ensembl.org",
}
CIVIC_GRAPHQL_URL = "https://civicdb.org/api/graphql"
HTTP_TIMEOUT = 30

MYVARIANT_SAFE_FIELDS = [
    "_id", "chrom", "hg38.start", "hg38.end", "vcf.ref", "vcf.alt",
    "clinvar.clinical_significance", "clinvar.rcv.clinical_significance",
    "clinvar.rcv.conditions.name", "clinvar.rcv.preferred_name",
    "clinvar.gene.id", "clinvar.gene.symbol", "clinvar.allele_id",
    "clinvar.gold_stars", "clinvar.review_status",
    "gnomad_exome.af.af", "gnomad_exome.af.af_popmax", "gnomad_exome.ac.ac",
    "gnomad_genome.af.af", "gnomad_genome.af.af_popmax", "gnomad_genome.ac.ac",
    "dbsnp.rsid", "dbsnp.validated", "dbsnp.vartype",
    "civic.description", "civic.variant_types.name",
    "civic.evidence_items.clinical_significance",
    "civic.evidence_items.drugs.name", "civic.evidence_items.disease.name",
    "cgi.association", "cgi.evidence_level", "cgi.drug", "cgi.oncogenic_summary",
    "snpeff.ann.effect", "snpeff.ann.gene_name", "snpeff.ann.hgvs_p", "snpeff.ann.hgvs_c",
    "uniprot.Swiss-Prot.accession", "uniprot.Swiss-Prot.function",
    "uniprot.Swiss-Prot.feature",
]

# Commercial-license fields (CADD, dbNSFP). Caller must have appropriate licenses.
MYVARIANT_COMMERCIAL_FIELDS = [
    "cadd.phred", "cadd.rawscore", "cadd.consequence",
    "dbnsfp.cadd.phred",
    "dbnsfp.sift.pred", "dbnsfp.sift.score",
    "dbnsfp.polyphen2.hdiv.pred", "dbnsfp.polyphen2.hdiv.score",
    "dbnsfp.polyphen2.hvar.pred",
    "dbnsfp.revel.score",
    "dbnsfp.metalr.pred", "dbnsfp.metasvm.pred",
]


def _parse_vep_variant(variant: str) -> dict[str, Any]:
    """Parse a variant string into a VEP request shape (id / hgvs / region)."""
    v = variant.strip()
    if v.lower().startswith("rs"):
        return {"format": "id", "id": v}
    # MyVariant "GENE AND p.X" → "GENE:p.X"
    if " AND " in v.upper():
        gene, _, hgvs = v.partition(" AND ")
        v = f"{gene.strip()}:{hgvs.strip()}"
    lower = v.lower()
    if ":g." in lower or ":p." in lower or ":c." in lower:
        return {"format": "hgvs", "hgvs": v}
    parts = v.replace("-", ":").split(":")
    if len(parts) >= 4:
        return {
            "format": "region",
            "chrom": parts[0].replace("chr", ""),
            "pos": parts[1],
            "ref": parts[2],
            "alt": parts[3],
        }
    return {"format": "hgvs", "hgvs": v}


def _should_use_assembly(variants: Any) -> bool:
    items = variants if isinstance(variants, list) else [variants]
    for v in items:
        s = str(v).lower()
        if ":g." in s or s.startswith("rs"):
            return False
    return True


class _VEPClient:
    def __init__(self) -> None:
        self._headers = {"Content-Type": "application/json", "Accept": "application/json"}

    def _base(self, assembly: str, species: str) -> str:
        if species != "homo_sapiens":
            return "https://rest.ensembl.org"
        return VEP_HOSTS.get(assembly.lower(), VEP_HOSTS["hg38"])

    async def annotate_single(self, variant: str, assembly: str, species: str) -> dict[str, Any]:
        base = self._base(assembly, species)
        parsed = _parse_vep_variant(variant)
        is_human = species == "homo_sapiens"
        extras: dict[str, Any] = {"protein": 1, "domains": 1, "hgvs": 1}
        if is_human:
            extras["MaveDB"] = 1
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            if parsed["format"] == "id":
                url = f"{base}/vep/{species}/id/{parsed['id']}?content-type=application/json&protein=1&domains=1&hgvs=1{'&MaveDB=1' if is_human else ''}"
                response = await client.get(url, headers=self._headers)
            elif parsed["format"] == "hgvs":
                hgvs_encoded = urllib.parse.quote(parsed["hgvs"], safe="")
                url = f"{base}/vep/{species}/hgvs/{hgvs_encoded}?content-type=application/json&protein=1&domains=1&hgvs=1{'&MaveDB=1' if is_human else ''}"
                response = await client.get(url, headers=self._headers)
            elif parsed["format"] == "region":
                url = f"{base}/vep/{species}/region"
                payload = {"variants": [f"{parsed['chrom']} {parsed['pos']} . {parsed['ref']} {parsed['alt']}"], **extras}
                response = await client.post(url, json=payload, headers=self._headers)
            else:
                raise ValueError(f"Unsupported variant format: {variant}")
            response.raise_for_status()
            return response.json()

    async def annotate_batch(self, variants: list[str], assembly: str, species: str) -> list[dict[str, Any]]:
        base = self._base(assembly, species)
        is_human = species == "homo_sapiens"
        extras: dict[str, Any] = {"protein": 1, "domains": 1, "hgvs": 1}
        if is_human:
            extras["MaveDB"] = 1
        ids: list[str] = []
        hgvs_list: list[str] = []
        regions: list[str] = []
        for v in variants:
            parsed = _parse_vep_variant(v)
            if parsed["format"] == "id":
                ids.append(parsed["id"])
            elif parsed["format"] == "hgvs":
                hgvs_list.append(parsed["hgvs"])
            elif parsed["format"] == "region":
                regions.append(f"{parsed['chrom']} {parsed['pos']} . {parsed['ref']} {parsed['alt']}")
        results: list[dict[str, Any]] = []
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            if ids:
                r = await client.post(f"{base}/vep/{species}/id", json={"ids": ids, **extras}, headers=self._headers)
                r.raise_for_status()
                results.extend(r.json())
            if hgvs_list:
                r = await client.post(f"{base}/vep/{species}/hgvs", json={"hgvs_notations": hgvs_list, **extras}, headers=self._headers)
                r.raise_for_status()
                results.extend(r.json())
            if regions:
                r = await client.post(f"{base}/vep/{species}/region", json={"variants": regions, **extras}, headers=self._headers)
                r.raise_for_status()
                results.extend(r.json())
        return results


class _CIViCClient:
    def __init__(self) -> None:
        self._headers = {"Content-Type": "application/json", "Accept": "application/json"}

    async def _execute(self, query: str, variables: dict[str, Any] | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {"query": query}
        if variables:
            payload["variables"] = variables
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            response = await client.post(CIVIC_GRAPHQL_URL, json=payload, headers=self._headers)
            response.raise_for_status()
            return response.json()

    async def search_variant(self, gene: str, variant_name: str) -> int | None:
        query = """
        query SearchVariant($gene: String!, $variant: String!) {
          browseVariants(featureName: $gene, variantName: $variant, first: 1) {
            edges { node { id name link } }
          }
        }
        """
        result = await self._execute(query, {"gene": gene, "variant": variant_name})
        edges = result.get("data", {}).get("browseVariants", {}).get("edges", [])
        return edges[0]["node"]["id"] if edges else None

    async def get_evidence(self, variant_id: int) -> dict[str, Any]:
        query = """
        query GetVariantEvidence($id: Int!) {
          variant(id: $id) {
            id name
            feature { name }
            molecularProfiles {
              nodes {
                id name
                evidenceItems {
                  nodes {
                    id name status significance evidenceDirection evidenceLevel evidenceType
                    therapies { name ncitId }
                    disease { name doid }
                    source { citation sourceUrl }
                  }
                }
              }
            }
          }
        }
        """
        result = await self._execute(query, {"id": variant_id})
        return result.get("data", {}).get("variant", {}) or {}

    async def evidence_for(self, gene: str, variant_name: str) -> dict[str, Any]:
        clean = variant_name[2:] if variant_name.lower().startswith("p.") else variant_name
        variant_id = await self.search_variant(gene, clean)
        if not variant_id:
            return {"_source": "civic", "found": False, "gene": gene, "variant": variant_name,
                    "message": f"No CIViC entry found for {gene} {variant_name}"}
        evidence = await self.get_evidence(variant_id)
        if not evidence:
            return {"_source": "civic", "found": False, "gene": gene, "variant": variant_name,
                    "variant_id": variant_id, "message": "Variant found but no evidence retrieved"}
        evidence["_source"] = "civic"
        evidence["found"] = True
        evidence["civic_url"] = f"https://civicdb.org/variants/{variant_id}"
        return evidence


class VariantAnnotationWorker:
    def __init__(self) -> None:
        self._mv = None  # lazy
        self._vep = _VEPClient()
        self._civic = _CIViCClient()

    @property
    def myvariant(self):
        if self._mv is None:
            import myvariant
            self._mv = myvariant.MyVariantInfo()
        return self._mv

    async def annotate(
        self,
        action: str,
        variants: str | list[str] | None = None,
        gene: str | None = None,
        variant_name: str | None = None,
        assembly: str = "hg38",
        species: str = "homo_sapiens",
        include_commercial: bool = False,
    ) -> dict[str, Any]:
        action = action.lower().strip()
        if action == "myvariant":
            return await self._annotate_myvariant(variants, assembly, include_commercial)
        if action == "vep":
            return await self._annotate_vep(variants, assembly, species)
        if action == "civic":
            return await self._annotate_civic(gene, variant_name)
        return {
            "error": f"Unknown action: {action}",
            "valid_actions": ["myvariant", "vep", "civic"],
        }

    async def _annotate_myvariant(self, variants: Any, assembly: str, include_commercial: bool) -> dict[str, Any]:
        if not variants:
            return {"error": "variants parameter is required for myvariant action"}
        mv = self.myvariant
        field_list = MYVARIANT_SAFE_FIELDS + (MYVARIANT_COMMERCIAL_FIELDS if include_commercial else [])
        fields = ",".join(field_list)
        use_assembly = _should_use_assembly(variants)

        try:
            is_batch = isinstance(variants, list)
            if is_batch:
                params = {"species": "human", "returnall": True, "fields": fields}
                if use_assembly:
                    params["assembly"] = assembly
                result = await asyncio.wait_for(
                    asyncio.to_thread(mv.querymany, variants, **params), timeout=HTTP_TIMEOUT
                )
            elif " AND " in str(variants).upper():
                params = {"species": "human", "size": 10, "fields": fields}
                if use_assembly:
                    params["assembly"] = assembly
                result = await asyncio.wait_for(
                    asyncio.to_thread(mv.query, variants, **params), timeout=HTTP_TIMEOUT
                )
            else:
                params = {"fields": fields}
                if use_assembly:
                    params["assembly"] = assembly
                result = await asyncio.wait_for(
                    asyncio.to_thread(mv.getvariant, variants, **params), timeout=HTTP_TIMEOUT
                )
            if result is None or (isinstance(result, dict) and result.get("total", -1) == 0):
                return {"_source": "myvariant", "found": False,
                        "message": f"No annotations found for: {variants}",
                        "suggestion": "Try action='vep' for basic annotation."}
            if isinstance(result, dict):
                result["_source"] = "myvariant"
                return result
            return {"_source": "myvariant", "results": result}
        except asyncio.TimeoutError:
            return {"_source": "myvariant", "error": "MyVariant.info API timeout (30s)",
                    "suggestion": "Try action='vep' as alternative."}

    async def _annotate_vep(self, variants: Any, assembly: str, species: str) -> dict[str, Any]:
        if not variants:
            return {"error": "variants parameter is required for vep action"}
        if isinstance(variants, list):
            results = await self._vep.annotate_batch(variants, assembly, species)
            return {"_source": "ensembl_vep", "species": species, "assembly": assembly, "results": results}
        result = await self._vep.annotate_single(variants, assembly, species)
        if isinstance(result, list) and result:
            data = result[0]
        else:
            data = result if isinstance(result, dict) else {"raw": result}
        data["_source"] = "ensembl_vep"
        data["species"] = species
        data["assembly"] = assembly
        return data

    async def _annotate_civic(self, gene: str | None, variant_name: str | None) -> dict[str, Any]:
        if not gene or not variant_name:
            return {
                "error": "Both 'gene' and 'variant_name' are required for civic action",
                "example": {"action": "civic", "gene": "BRAF", "variant_name": "V600E"},
            }
        return await self._civic.evidence_for(gene, variant_name)


def build_annotate_tool():
    worker = VariantAnnotationWorker()

    @function_tool
    async def annotate_variant(
        action: str,
        context: str = "",
        variants: str | None = None,
        gene: str | None = None,
        variant_name: str | None = None,
        assembly: str = "hg38",
        species: str = "homo_sapiens",
        include_commercial: bool = False,
    ) -> str:
        """Get genomic variant annotations. For human, start with action='myvariant'
        (aggregated: ClinVar, gnomAD, CGI drug associations); fall back to action='vep' if
        myvariant returns limited data (comprehensive: consequences, SIFT/PolyPhen, domains).
        Use action='civic' for cancer drug response (requires gene + variant_name). For
        non-human / plant species, use action='vep' with species set.

        Args:
            action: 'myvariant' | 'vep' | 'civic'.
            context: Brief explanation of why you're annotating.
            variants: Variant ID for myvariant/vep. myvariant: rsID, HGVS genomic with chr,
                or 'GENE AND p.X'. vep: rsID, HGVS genomic WITHOUT chr prefix, HGVS protein
                (BRAF:p.V600E), HGVS coding, or chrom:pos:ref:alt. RefSeq transcripts for VEP
                must NOT include version.
            gene: Gene symbol for civic (e.g., 'BRAF').
            variant_name: Variant name for civic (e.g., 'V600E').
            assembly: Genome assembly 'hg19' or 'hg38'. Human only.
            species: Ensembl species name for VEP. Default 'homo_sapiens'.
            include_commercial: myvariant only. When True, includes CADD and dbNSFP prediction
                fields (SIFT, PolyPhen-2, REVEL, MetaLR, MetaSVM). These data sources require
                commercial licenses for non-academic use — only enable when the caller has
                verified license coverage.
        """
        try:
            data = await worker.annotate(
                action=action,
                variants=variants,
                gene=gene,
                variant_name=variant_name,
                assembly=assembly,
                species=species,
                include_commercial=include_commercial,
            )
            return to_json(data)
        except httpx.HTTPError as e:
            return to_json({"error": f"Annotation network error: {e}"})
        except Exception as e:
            return to_json({"error": f"Annotation unexpected error: {e}"})

    return annotate_variant
