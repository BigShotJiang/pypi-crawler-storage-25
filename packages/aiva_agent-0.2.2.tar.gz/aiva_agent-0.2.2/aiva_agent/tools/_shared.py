"""Minimal helpers shared across tool modules."""

import json
import re
from typing import Any


def to_json(payload: Any) -> str:
    """Serialize a tool result to a string the agent will see verbatim."""
    if isinstance(payload, str):
        return payload
    return json.dumps(payload, default=str, indent=2)


_JSON_OBJECT_RE = re.compile(r"\{.*\}", re.DOTALL)


def extract_json(text: str) -> dict[str, Any] | None:
    match = _JSON_OBJECT_RE.search(text)
    if not match:
        return None
    try:
        return json.loads(match.group(0))
    except json.JSONDecodeError:
        return None
