"""Agent runtime: builds an OpenAI Agents SDK Agent from --disable, runs it once.

Multi-provider works through any OpenAI-compatible endpoint:
- User passes --model, --base-url, --api-key (or sets LLM_BASE_URL / LLM_API_KEY)
- We construct AsyncOpenAI(base_url=, api_key=) and OpenAIChatCompletionsModel(model=, ...)
- Pass that as model= to Agent(...)

No PROVIDERS dict, no provider-prefix parsing, no LiteLLM. The user already knows
their provider's URL and has their key; we don't need to enumerate.
"""

import asyncio
import os
from pathlib import Path
from typing import Iterable

from agents import Agent, OpenAIChatCompletionsModel, Runner, SQLiteSession, function_tool
from openai import AsyncOpenAI

from .classification_prompts import ACMG_AMP_SYSTEM_PROMPT
from .prompts import get_main_system_prompt
from .tools import (
    build_annotate_tool,
    build_literature_tool,
    build_phen2gene_tool,
    build_trials_tool,
    build_vcf_tools,
    build_web_tool,
)

DEFAULT_MODEL = "gpt-5.5"
DEFAULT_MAX_TURNS = 25

ALL_TOOLS = ("vcf", "annotate", "literature", "trials", "phen2gene", "web", "classify")


def _resolve_max_turns() -> int:
    raw = os.environ.get("AIVA_MAX_TURNS", "").strip()
    if not raw:
        return DEFAULT_MAX_TURNS
    try:
        n = int(raw)
    except ValueError:
        return DEFAULT_MAX_TURNS
    return n if n > 0 else DEFAULT_MAX_TURNS


def _resolve_disabled(disabled_tools: Iterable[str] | None) -> list[str]:
    """Return the active tool list = ALL_TOOLS minus the disabled set.

    Default (None / empty) → every tool is on. Unknown names are ignored
    (the CLI already validates), preserving the lenient behavior of the
    previous `_resolve_enabled`.
    """
    if not disabled_tools:
        return list(ALL_TOOLS)
    drop = {name.strip() for name in disabled_tools if name and name.strip()}
    return [t for t in ALL_TOOLS if t not in drop]


def build_model(
    model: str,
    base_url: str | None = None,
    api_key: str | None = None,
) -> OpenAIChatCompletionsModel:
    """Construct an OpenAIChatCompletionsModel pointing at any OpenAI-compatible endpoint.

    Resolution order for base_url and api_key:
    1. The argument passed in (CLI flag).
    2. LLM_BASE_URL / LLM_API_KEY env vars.
    """
    resolved_base_url = base_url or os.environ.get("LLM_BASE_URL")
    resolved_api_key = api_key or os.environ.get("LLM_API_KEY")
    client = AsyncOpenAI(base_url=resolved_base_url, api_key=resolved_api_key)
    return OpenAIChatCompletionsModel(model=model, openai_client=client)


def build_classifier_tool(
    classifier_tools: list,
    model: str,
    base_url: str | None,
    api_key: str | None,
):
    """Wrap the variant-classifier sub-agent as a @function_tool callable from the parent.

    Mirrors genomiq's SubAgentRunner pattern: build a fresh Agent with the classifier's
    own tool palette, run it via Runner.run, return the JSON output.
    """
    sub_model = build_model(model, base_url, api_key)
    sub_agent = Agent(
        name="variant-classifier",
        instructions=ACMG_AMP_SYSTEM_PROMPT,
        model=sub_model,
        tools=classifier_tools,
    )

    # `variant_data` is a heterogeneous dict (rsid OR hgvs OR chrom/pos/ref/alt) — strict
    # JSON Schema doesn't model that cleanly without a TypedDict per shape, so we relax
    # strict mode for this single tool. The shape contract is documented in the docstring
    # and enforced by the sub-agent's system prompt.
    @function_tool(strict_mode=False)
    async def classify_variant(
        variant_data: dict,
        classification_type: str,
        assembly: str,
        phenotype_terms: str = "",
        description: str = "",
        additional_context: str = "",
    ) -> str:
        """Classify a genomic variant using ACMG/AMP 2015 guidelines (germline) or
        AMP/ASCO/CAP 2017 guidelines (somatic). Runs as a sub-agent that gathers
        annotations, literature, and trial evidence on its own, returning a JSON
        classification with criteria_met, evidence_summary, and sources.

        Args:
            variant_data: One of {"rsid": "rs..."} or {"hgvs": "..."} or
                {"chrom": "...", "pos": ..., "ref": "...", "alt": "..."}.
            classification_type: 'acmg' for germline or 'amp' for somatic/cancer.
            assembly: 'GRCh37' or 'GRCh38'.
            phenotype_terms: e.g. 'melanoma', 'hereditary breast cancer'.
            description: Sample/patient context (optional).
            additional_context: Verified clinical context (de novo status, family history,
                zygosity, segregation). Apply criteria strictly to what's stated here.
        """
        formatted = (
            "Classify this variant.\n\n"
            f"- variant_data: {variant_data}\n"
            f"- classification_type: {classification_type}\n"
            f"- assembly: {assembly}\n"
            f"- phenotype_terms: {phenotype_terms}\n"
            f"- description: {description}\n"
            f"- additional_context: {additional_context}\n"
        )
        result = await Runner.run(sub_agent, formatted, max_turns=_resolve_max_turns())
        return result.final_output

    return classify_variant


def build_tools_and_cleanup(
    enabled: list[str],
    vcf_specs: list[tuple[str, Path]] | None,
    model: str,
    base_url: str | None,
    api_key: str | None,
) -> tuple[list, list]:
    """Construct the tool list for an agent run plus any cleanup callables.

    Raises ValueError if 'vcf' is in `enabled` but `vcf_specs` is empty. The CLI
    auto-disables vcf with a warning before reaching this function; the guard
    is the contract for direct library callers.

    `vcf_specs` is a list of `(alias, path)` pairs; each becomes a named DuckDB
    view. Single-file invocations should pass `[("vcf", path)]`.

    classify is special: it needs annotate / literature / trials available to its
    sub-agent. We build those tools once and share the instances between the parent's
    palette and the classifier's palette.
    """
    tools: list = []
    cleanups: list = []

    annotate_tool = literature_tool = trials_tool = None

    if "vcf" in enabled:
        if not vcf_specs:
            raise ValueError("--vcf is required when 'vcf' is enabled")
        vcf_tools, vcf_cleanup = build_vcf_tools(vcf_specs)
        tools.extend(vcf_tools)
        cleanups.append(vcf_cleanup)

    if "annotate" in enabled or "classify" in enabled:
        annotate_tool = build_annotate_tool()
        if "annotate" in enabled:
            tools.append(annotate_tool)

    if "literature" in enabled or "classify" in enabled:
        literature_tool, literature_cleanup = build_literature_tool()
        cleanups.append(literature_cleanup)
        if "literature" in enabled:
            tools.append(literature_tool)

    if "trials" in enabled or "classify" in enabled:
        trials_tool, trials_cleanup = build_trials_tool()
        cleanups.append(trials_cleanup)
        if "trials" in enabled:
            tools.append(trials_tool)

    if "phen2gene" in enabled:
        phen2gene_tool, phen2gene_cleanup = build_phen2gene_tool()
        cleanups.append(phen2gene_cleanup)
        tools.append(phen2gene_tool)

    if "web" in enabled:
        tools.append(build_web_tool())

    if "classify" in enabled:
        classifier_tools = [t for t in (annotate_tool, literature_tool, trials_tool) if t is not None]
        tools.append(
            build_classifier_tool(
                classifier_tools=classifier_tools,
                model=model,
                base_url=base_url,
                api_key=api_key,
            )
        )

    return tools, cleanups


async def run_once(
    prompt: str,
    *,
    vcf_specs: list[tuple[str, Path]] | None = None,
    disabled_tools: Iterable[str] | None = None,
    model: str = DEFAULT_MODEL,
    base_url: str | None = None,
    api_key: str | None = None,
    session_id: str | None = None,
) -> str:
    enabled = _resolve_disabled(disabled_tools)

    tools, cleanups = build_tools_and_cleanup(
        enabled=enabled,
        vcf_specs=vcf_specs,
        model=model,
        base_url=base_url,
        api_key=api_key,
    )

    session = None
    if session_id:
        db_path = Path.home() / ".aiva" / "sessions.db"
        db_path.parent.mkdir(parents=True, exist_ok=True)
        session = SQLiteSession(session_id, str(db_path))

    try:
        agent = Agent(
            name="aiva",
            instructions=get_main_system_prompt(enabled, vcf_specs=vcf_specs),
            model=build_model(model, base_url, api_key),
            tools=tools,
        )
        result = await Runner.run(
            agent, prompt, max_turns=_resolve_max_turns(), session=session
        )
        return result.final_output
    finally:
        for cleanup in cleanups:
            try:
                result = cleanup()
                if asyncio.iscoroutine(result):
                    await result
            except Exception:
                pass
