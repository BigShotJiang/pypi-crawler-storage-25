"""Tests for build_model — the multi-provider client construction.

The model factory takes a model id, optional base_url, optional api_key and falls back
to LLM_BASE_URL / LLM_API_KEY env vars. It returns an OpenAIChatCompletionsModel
wrapping an AsyncOpenAI client.
"""

from aiva_agent.agent import build_model


def test_build_model_uses_explicit_args(monkeypatch):
    monkeypatch.delenv("LLM_BASE_URL", raising=False)
    monkeypatch.delenv("LLM_API_KEY", raising=False)
    model = build_model("gpt-5", "https://api.openai.com/v1", "sk-explicit")
    assert model.model == "gpt-5"
    assert str(model._client.base_url).rstrip("/") == "https://api.openai.com/v1"
    assert model._client.api_key == "sk-explicit"


def test_build_model_falls_back_to_env_vars(monkeypatch):
    monkeypatch.setenv("LLM_BASE_URL", "https://api.x.ai/v1")
    monkeypatch.setenv("LLM_API_KEY", "xai-from-env")
    model = build_model("grok-2", base_url=None, api_key=None)
    assert model.model == "grok-2"
    assert str(model._client.base_url).rstrip("/") == "https://api.x.ai/v1"
    assert model._client.api_key == "xai-from-env"


def test_build_model_explicit_args_override_env(monkeypatch):
    monkeypatch.setenv("LLM_BASE_URL", "https://from-env")
    monkeypatch.setenv("LLM_API_KEY", "key-from-env")
    model = build_model(
        "claude-opus-4-7",
        base_url="https://api.anthropic.com/v1",
        api_key="sk-ant-explicit",
    )
    assert str(model._client.base_url).rstrip("/") == "https://api.anthropic.com/v1"
    assert model._client.api_key == "sk-ant-explicit"


def test_build_model_raises_when_no_api_key_anywhere(monkeypatch):
    """OpenAI's AsyncOpenAI client requires an api_key. With no flag and no LLM_API_KEY
    env var (and no OPENAI_API_KEY fallback), construction fails with a clear error.
    We surface that error from build_model directly rather than masking it."""
    import pytest
    from openai import OpenAIError

    monkeypatch.delenv("LLM_BASE_URL", raising=False)
    monkeypatch.delenv("LLM_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    with pytest.raises(OpenAIError, match="api_key"):
        build_model("gpt-5", None, None)
