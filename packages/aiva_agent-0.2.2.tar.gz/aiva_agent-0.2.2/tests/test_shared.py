import json

from aiva_agent.tools._shared import extract_json, to_json


def test_to_json_str_passes_through():
    assert to_json("hello") == "hello"


def test_to_json_dict_serializes_with_indent():
    text = to_json({"a": 1, "b": [2, 3]})
    assert json.loads(text) == {"a": 1, "b": [2, 3]}
    assert "\n" in text  # indented


def test_to_json_handles_non_serializable_via_default_str():
    class Foo:
        def __repr__(self) -> str:
            return "Foo()"

    text = to_json({"f": Foo()})
    assert "Foo()" in text


def test_extract_json_finds_object_in_prose():
    text = "Here is the result:\n{\"classification\": \"Pathogenic\", \"score\": 7}\nDone."
    assert extract_json(text) == {"classification": "Pathogenic", "score": 7}


def test_extract_json_returns_none_when_no_object():
    assert extract_json("just prose, no braces") is None


def test_extract_json_returns_none_on_invalid_json():
    assert extract_json("{not valid json}") is None


def test_extract_json_handles_nested_objects():
    text = '{"outer": {"inner": [1, 2, {"deep": "ok"}]}}'
    assert extract_json(text) == {"outer": {"inner": [1, 2, {"deep": "ok"}]}}
