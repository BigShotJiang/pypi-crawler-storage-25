"""Mocked tests for the web tool (search + scrape).

We monkeypatch DDGS().text and the requests session to avoid real network. The
tool returns JSON-serialized strings; we parse them back to dicts to assert
shape.
"""

import json
from typing import Any
from unittest.mock import MagicMock

import pytest

from aiva_agent.tools.web import WebSearchWorker


@pytest.fixture
def fake_ddg_results():
    return [
        {
            "title": "TP53 R175H in lung cancer",
            "href": "https://example.com/paper1",
            "body": "Snippet about TP53 R175H...",
        },
        {
            "title": "p53 mutant role",
            "href": "https://example.com/paper2",
            "body": "Discussion of mutant p53...",
        },
    ]


async def test_search_clamps_limit(monkeypatch, fake_ddg_results):
    captured: dict[str, Any] = {}

    def fake_text(query, max_results):
        captured["query"] = query
        captured["max_results"] = max_results
        return fake_ddg_results

    w = WebSearchWorker()
    monkeypatch.setattr(w._ddgs, "text", fake_text)

    out = await w.search("anything", limit=999)
    assert captured["max_results"] == 50  # clamped
    assert out["returned_results"] == 2
    assert out["results"][0]["title"] == "TP53 R175H in lung cancer"
    assert out["results"][0]["url"] == "https://example.com/paper1"


async def test_search_minimum_limit(monkeypatch, fake_ddg_results):
    captured: dict[str, Any] = {}

    def fake_text(query, max_results):
        captured["max_results"] = max_results
        return fake_ddg_results

    w = WebSearchWorker()
    monkeypatch.setattr(w._ddgs, "text", fake_text)

    await w.search("anything", limit=0)
    assert captured["max_results"] == 1  # clamped up


async def test_search_passes_query_through(monkeypatch, fake_ddg_results):
    captured: dict[str, Any] = {}

    def fake_text(query, max_results):
        captured["query"] = query
        return fake_ddg_results

    w = WebSearchWorker()
    monkeypatch.setattr(w._ddgs, "text", fake_text)

    await w.search("BRAF V600E melanoma", limit=5)
    assert captured["query"] == "BRAF V600E melanoma"


async def test_scrape_extracts_main_content(monkeypatch):
    fake_html = """
    <html><body>
      <article>
        <h1>Title</h1>
        <p>The TP53 R175H mutation is associated with lung cancer aggressiveness
        and resistance to chemotherapy. Multiple studies have shown that this hotspot
        gain-of-function mutation drives metastasis through MAPK pathway activation.</p>
      </article>
    </body></html>
    """
    fake_response = MagicMock()
    fake_response.text = fake_html
    fake_response.raise_for_status = MagicMock()

    w = WebSearchWorker()
    monkeypatch.setattr(w._http, "get", lambda *a, **kw: fake_response)

    out = await w.scrape("https://example.com/paper")
    assert "error" not in out
    assert "TP53 R175H" in out["content"]
    assert out["url"] == "https://example.com/paper"
    assert out["truncated"] is False


async def test_scrape_truncates_at_max_chars(monkeypatch):
    big = "<html><body><article>" + ("X" * 25_000) + "</article></body></html>"
    fake_response = MagicMock()
    fake_response.text = big
    fake_response.raise_for_status = MagicMock()

    w = WebSearchWorker()
    monkeypatch.setattr(w._http, "get", lambda *a, **kw: fake_response)

    out = await w.scrape("https://example.com/big")
    if "error" not in out:  # only check truncation if extraction succeeded
        assert out["truncated"] is True
        assert len(out["content"]) == 20_000


async def test_scrape_returns_error_on_http_failure(monkeypatch):
    import requests

    def boom(*a, **kw):
        raise requests.ConnectionError("network down")

    w = WebSearchWorker()
    monkeypatch.setattr(w._http, "get", boom)

    out = await w.scrape("https://example.com/dead")
    assert "error" in out
    assert "network down" in out["error"]


async def test_scrape_returns_error_when_extraction_yields_nothing(monkeypatch):
    fake_response = MagicMock()
    fake_response.text = "<html></html>"
    fake_response.raise_for_status = MagicMock()

    w = WebSearchWorker()
    monkeypatch.setattr(w._http, "get", lambda *a, **kw: fake_response)

    out = await w.scrape("https://example.com/empty")
    assert "error" in out


def test_tool_factory_returns_named_tool():
    """build_web_tool must produce a single FunctionTool named 'web_search'."""
    from aiva_agent.tools.web import build_web_tool

    tool = build_web_tool()
    assert tool.name == "web_search"
    # The action/query/url validation logic is exercised by the WebSearchWorker
    # tests above; we don't double-test it through the SDK's tool wrapper.
