from aiva_agent.tools.annotate import _parse_vep_variant, _should_use_assembly


def test_parses_rsid_lowercase_and_uppercase():
    assert _parse_vep_variant("rs113488022") == {"format": "id", "id": "rs113488022"}
    assert _parse_vep_variant("RS113488022") == {"format": "id", "id": "RS113488022"}


def test_parses_hgvs_genomic():
    out = _parse_vep_variant("7:g.140753336A>T")
    assert out == {"format": "hgvs", "hgvs": "7:g.140753336A>T"}


def test_parses_hgvs_protein():
    out = _parse_vep_variant("BRAF:p.V600E")
    assert out == {"format": "hgvs", "hgvs": "BRAF:p.V600E"}


def test_parses_hgvs_coding():
    out = _parse_vep_variant("ENST00000366667:c.1799T>A")
    assert out == {"format": "hgvs", "hgvs": "ENST00000366667:c.1799T>A"}


def test_converts_myvariant_AND_syntax_to_vep_colon():
    out = _parse_vep_variant("BRAF AND p.V600E")
    assert out == {"format": "hgvs", "hgvs": "BRAF:p.V600E"}


def test_parses_chrom_pos_ref_alt_colon_separated():
    out = _parse_vep_variant("7:140753336:A:T")
    assert out == {"format": "region", "chrom": "7", "pos": "140753336", "ref": "A", "alt": "T"}


def test_parses_chrom_pos_ref_alt_dash_separated():
    out = _parse_vep_variant("7-140753336-A-T")
    assert out == {"format": "region", "chrom": "7", "pos": "140753336", "ref": "A", "alt": "T"}


def test_strips_chr_prefix_from_region_chrom():
    out = _parse_vep_variant("chr7:140753336:A:T")
    assert out["chrom"] == "7"


def test_should_use_assembly_skips_for_hgvs_genomic():
    # HGVS genomic carries its own coordinate system
    assert _should_use_assembly("7:g.140753336A>T") is False


def test_should_use_assembly_skips_for_rsid():
    assert _should_use_assembly("rs113488022") is False


def test_should_use_assembly_keeps_for_protein_hgvs():
    assert _should_use_assembly("BRAF:p.V600E") is True


def test_should_use_assembly_skips_when_any_in_list_is_genomic():
    assert _should_use_assembly(["BRAF:p.V600E", "7:g.140753336A>T"]) is False
