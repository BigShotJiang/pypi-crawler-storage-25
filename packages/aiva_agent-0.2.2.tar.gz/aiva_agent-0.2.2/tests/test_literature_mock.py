import pytest
import respx
from httpx import Response

from aiva_agent.tools.literature import PUBTATOR_BASE, PubTatorWorker


@pytest.fixture
def fake_pubtator_payload():
    return {
        "count": 2,
        "results": [
            {
                "pmid": 12345,
                "pmcid": "PMC9999",
                "title": "TP53 R175H in lung cancer",
                "journal": "J Test",
                "date": "2024-05-01",
                "authors": ["Smith J", "Doe A"],
                "doi": "10.1/test",
                "score": 0.95,
                "text_hl": "Mutations in @GENE_TP53_7157@@@ associated with @DISEASE_Lung_Neoplasms_MESH:D008175@@@.",
                "citations": {"NLM": "Smith J et al. 2024"},
            },
            {
                "pmid": 67890,
                "title": "Another TP53 paper",
                "journal": "J Other",
                "date": "2023-10-01",
                "authors": ["Roe R"],
                "score": 0.7,
            },
        ],
    }


@respx.mock
async def test_search_returns_formatted_results(fake_pubtator_payload):
    respx.get(f"{PUBTATOR_BASE}/search/").mock(
        return_value=Response(200, json=fake_pubtator_payload)
    )
    w = PubTatorWorker()
    try:
        out = await w.search("TP53 R175H lung cancer", limit=5)
    finally:
        await w.aclose()

    assert out["query"] == "TP53 R175H lung cancer"
    assert out["total_results"] == 2
    assert out["returned_results"] == 2
    first = out["results"][0]
    assert first["pmid"] == "12345"
    assert first["pmcid"] == "PMC9999"
    assert first["year"] == "2024"
    assert first["annotations"]["genes"] == ["TP53 (7157)"]
    assert first["annotations"]["diseases"] == ["Lung Neoplasms (MESH:D008175)"]


@respx.mock
async def test_search_clamps_limit_and_uses_size_param(fake_pubtator_payload):
    route = respx.get(f"{PUBTATOR_BASE}/search/").mock(
        return_value=Response(200, json=fake_pubtator_payload)
    )
    w = PubTatorWorker()
    try:
        await w.search("anything", limit=500)  # > 100 → clamped to 100
    finally:
        await w.aclose()

    request = route.calls.last.request
    assert "size=100" in str(request.url)
    assert "text=anything" in str(request.url)


@respx.mock
async def test_search_date_sort_adds_sort_param(fake_pubtator_payload):
    route = respx.get(f"{PUBTATOR_BASE}/search/").mock(
        return_value=Response(200, json=fake_pubtator_payload)
    )
    w = PubTatorWorker()
    try:
        await w.search("anything", sort="date")
    finally:
        await w.aclose()

    assert "sort=date+desc" in str(route.calls.last.request.url) or "sort=date%20desc" in str(route.calls.last.request.url)


@respx.mock
async def test_search_handles_empty_results():
    respx.get(f"{PUBTATOR_BASE}/search/").mock(
        return_value=Response(200, json={"count": 0, "results": []})
    )
    w = PubTatorWorker()
    try:
        out = await w.search("nothing matches")
    finally:
        await w.aclose()
    assert out["returned_results"] == 0
    assert out["results"] == []


@respx.mock
async def test_search_invalid_sort_falls_back_to_relevance(fake_pubtator_payload):
    route = respx.get(f"{PUBTATOR_BASE}/search/").mock(
        return_value=Response(200, json=fake_pubtator_payload)
    )
    w = PubTatorWorker()
    try:
        await w.search("test", sort="bogus")
    finally:
        await w.aclose()
    # invalid sort should NOT add a sort param (relevance is the default)
    assert "sort=" not in str(route.calls.last.request.url)
