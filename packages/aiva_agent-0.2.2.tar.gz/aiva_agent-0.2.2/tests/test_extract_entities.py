from aiva_agent.tools.literature import PubTatorWorker

extract = PubTatorWorker._extract_entities


def test_returns_empty_for_empty_input():
    assert extract("", "@GENE_") == []


def test_extracts_single_gene_with_id():
    text = "Some text @GENE_BRCA1_672@@@ more text"
    assert extract(text, "@GENE_") == ["BRCA1 (672)"]


def test_extracts_multiple_unique_entities():
    text = "@GENE_TP53_7157@@@ found, also @GENE_BRCA1_672@@@ and @GENE_TP53_7157@@@ again"
    out = extract(text, "@GENE_")
    assert out == ["TP53 (7157)", "BRCA1 (672)"]


def test_handles_multiword_names_with_underscores():
    text = "@DISEASE_Breast_Neoplasms_MESH:D001943@@@"
    assert extract(text, "@DISEASE_") == ["Breast Neoplasms (MESH:D001943)"]


def test_skips_entities_without_closing_marker():
    text = "@GENE_TP53_7157 no closer here"
    assert extract(text, "@GENE_") == []


def test_does_not_match_other_prefixes():
    text = "@GENE_BRCA1_672@@@ @DISEASE_Breast_Neoplasms_MESH:D001943@@@"
    assert extract(text, "@GENE_") == ["BRCA1 (672)"]
    assert extract(text, "@DISEASE_") == ["Breast Neoplasms (MESH:D001943)"]


def test_falls_back_to_raw_token_when_no_underscore_id_split():
    text = "@VARIANT_rs28934578@@@"
    out = extract(text, "@VARIANT_")
    # rsXXX has no underscore so should map identifier section
    assert out and "rs28934578" in out[0]
