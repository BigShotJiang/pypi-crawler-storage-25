import pytest
import responses

from aiva_agent.tools.trials import CTGOV_BASE, ClinicalTrialsWorker


@pytest.fixture
def fake_search_payload():
    return {
        "totalCount": 1,
        "studies": [
            {
                "protocolSection": {
                    "identificationModule": {"nctId": "NCT01234567", "briefTitle": "Test trial"},
                    "statusModule": {
                        "overallStatus": "RECRUITING",
                        "enrollmentInfo": {"count": 100, "type": "ESTIMATED"},
                        "startDateStruct": {"date": "2024-01-01"},
                        "completionDateStruct": {"date": "2026-01-01"},
                    },
                    "designModule": {"phases": ["PHASE2"], "studyType": "INTERVENTIONAL"},
                    "conditionsModule": {"conditions": ["Melanoma"]},
                    "armsInterventionsModule": {"interventions": [{"name": "Drug X", "type": "DRUG"}]},
                    "sponsorCollaboratorsModule": {"leadSponsor": {"name": "TestSponsor"}},
                    "contactsLocationsModule": {
                        "locations": [
                            {"facility": "Hospital", "city": "Boston", "state": "MA", "country": "USA"},
                        ]
                    },
                }
            }
        ],
    }


@pytest.fixture
def fake_details_payload():
    return {
        "protocolSection": {
            "identificationModule": {
                "nctId": "NCT01234567",
                "briefTitle": "Test trial",
                "officialTitle": "Long Official Title for Test trial",
            },
            "statusModule": {
                "overallStatus": "RECRUITING",
                "enrollmentInfo": {"count": 100, "type": "ESTIMATED"},
                "startDateStruct": {"date": "2024-01-01"},
                "primaryCompletionDateStruct": {"date": "2025-06-01"},
                "completionDateStruct": {"date": "2026-01-01"},
                "lastUpdatePostDateStruct": {"date": "2024-06-01"},
            },
            "designModule": {"phases": ["PHASE2"], "studyType": "INTERVENTIONAL"},
            "conditionsModule": {"conditions": ["Melanoma"]},
            "armsInterventionsModule": {
                "interventions": [{"type": "DRUG", "name": "Drug X", "description": "Targeted therapy"}]
            },
            "eligibilityModule": {
                "eligibilityCriteria": "Adults 18+",
                "sex": "ALL",
                "minimumAge": "18 Years",
                "maximumAge": "N/A",
                "healthyVolunteers": False,
            },
            "sponsorCollaboratorsModule": {
                "leadSponsor": {"name": "TestSponsor"},
                "collaborators": [{"name": "Collab Inc"}],
            },
            "descriptionModule": {"briefSummary": "A test trial.", "detailedDescription": "Long description."},
            "outcomesModule": {
                "primaryOutcomes": [
                    {"measure": "OS", "description": "Overall Survival", "timeFrame": "24 months"}
                ]
            },
            "contactsLocationsModule": {
                "locations": [
                    {"facility": "Hospital", "city": "Boston", "state": "MA", "country": "USA", "status": "RECRUITING"}
                ]
            },
        }
    }


@responses.activate
async def test_search_builds_correct_query_params(fake_search_payload):
    responses.add(responses.GET, CTGOV_BASE, json=fake_search_payload, status=200)
    w = ClinicalTrialsWorker()
    try:
        out = await w.search(
            condition="melanoma",
            gene_or_variant="BRAF V600E",
            phase="PHASE2",
            study_type="INTERVENTIONAL",
            recruiting_status="RECRUITING",
            limit=5,
        )
    finally:
        await w.aclose()

    call = responses.calls[0]
    url = call.request.url
    assert "query.cond=melanoma" in url
    assert "query.term=BRAF+V600E" in url or "query.term=BRAF%20V600E" in url
    assert "filter.advanced=" in url  # has phase + study_type filters
    assert "AREA%5BPhase%5DPHASE2" in url or "AREA[Phase]PHASE2" in url
    assert "filter.overallStatus=RECRUITING" in url

    assert out["total_trials"] == 1
    assert out["returned_trials"] == 1
    assert out["trials"][0]["nct_id"] == "NCT01234567"
    assert out["trials"][0]["phase"] == "PHASE2"
    assert out["trials"][0]["sponsor"] == "TestSponsor"
    assert "Hospital, Boston, MA, USA" in out["trials"][0]["locations"]


@responses.activate
async def test_search_clamps_limit_to_100(fake_search_payload):
    responses.add(responses.GET, CTGOV_BASE, json=fake_search_payload, status=200)
    w = ClinicalTrialsWorker()
    try:
        await w.search(condition="melanoma", limit=500)
    finally:
        await w.aclose()
    assert "pageSize=100" in responses.calls[0].request.url


@responses.activate
async def test_search_defaults_to_recruiting_when_no_filters(fake_search_payload):
    responses.add(responses.GET, CTGOV_BASE, json=fake_search_payload, status=200)
    w = ClinicalTrialsWorker()
    try:
        await w.search()
    finally:
        await w.aclose()
    assert "filter.overallStatus=RECRUITING" in responses.calls[0].request.url


@responses.activate
async def test_details_extracts_full_trial_record(fake_details_payload):
    responses.add(
        responses.GET,
        f"{CTGOV_BASE}/NCT01234567",
        json=fake_details_payload,
        status=200,
    )
    w = ClinicalTrialsWorker()
    try:
        out = await w.details("NCT01234567")
    finally:
        await w.aclose()

    assert out["nct_id"] == "NCT01234567"
    assert out["official_title"] == "Long Official Title for Test trial"
    assert out["eligibility"]["min_age"] == "18 Years"
    assert out["sponsor"]["lead"] == "TestSponsor"
    assert out["sponsor"]["collaborators"] == ["Collab Inc"]
    assert out["primary_outcomes"][0]["measure"] == "OS"
    assert out["dates"]["start"] == "2024-01-01"


@responses.activate
async def test_details_returns_error_when_missing_protocolSection():
    responses.add(
        responses.GET,
        f"{CTGOV_BASE}/NCT99999999",
        json={"foo": "bar"},
        status=200,
    )
    w = ClinicalTrialsWorker()
    try:
        out = await w.details("NCT99999999")
    finally:
        await w.aclose()
    assert "error" in out
