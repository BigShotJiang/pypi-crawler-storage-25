import io
from pathlib import Path

import pytest

from aiva_agent.cli import _resolve_prompt


def test_resolve_prompt_inline_string():
    assert _resolve_prompt("hello world", None) == "hello world"


def test_resolve_prompt_file_takes_precedence_over_stdin(tmp_path: Path):
    prompt_file = tmp_path / "p.txt"
    prompt_file.write_text("from file\n", encoding="utf-8")
    # Even with --prompt set, --prompt-file wins.
    assert _resolve_prompt("inline", prompt_file) == "from file"


def test_resolve_prompt_file_strips_trailing_whitespace(tmp_path: Path):
    prompt_file = tmp_path / "p.txt"
    prompt_file.write_text("  question?\n\n", encoding="utf-8")
    assert _resolve_prompt(None, prompt_file) == "question?"


def test_resolve_prompt_missing_file_exits(tmp_path: Path):
    with pytest.raises(SystemExit, match="prompt file not found"):
        _resolve_prompt(None, tmp_path / "nope.txt")


def test_resolve_prompt_neither_provided_exits():
    with pytest.raises(SystemExit, match="provide --prompt or --prompt-file"):
        _resolve_prompt(None, None)


def test_resolve_prompt_dash_reads_stdin(monkeypatch):
    monkeypatch.setattr("sys.stdin", io.StringIO("from stdin\n"))
    assert _resolve_prompt("-", None) == "from stdin"


def test_resolve_prompt_dash_with_empty_stdin_exits(monkeypatch):
    monkeypatch.setattr("sys.stdin", io.StringIO(""))
    with pytest.raises(SystemExit, match="stdin is empty"):
        _resolve_prompt("-", None)


def test_resolve_prompt_handles_multiline_file(tmp_path: Path):
    prompt_file = tmp_path / "p.txt"
    body = "Line 1\nLine 2\nLine 3"
    prompt_file.write_text(body, encoding="utf-8")
    assert _resolve_prompt(None, prompt_file) == body
