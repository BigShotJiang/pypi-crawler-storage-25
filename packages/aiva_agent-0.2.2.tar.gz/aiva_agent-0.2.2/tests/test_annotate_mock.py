"""Mocked HTTP tests for VEP and CIViC. MyVariant uses the official ``myvariant``
SDK which goes through ``requests`` with internal session caching, so its happy path
is exercised by ``scripts/test_workers.py`` (live)."""

import pytest
import respx
from httpx import Response

from aiva_agent.tools.annotate import CIVIC_GRAPHQL_URL, VariantAnnotationWorker


@respx.mock
async def test_vep_single_rsid_uses_id_endpoint():
    route = respx.get(
        url__regex=r"https://rest\.ensembl\.org/vep/homo_sapiens/id/rs113488022.*"
    ).mock(
        return_value=Response(
            200,
            json=[
                {"id": "rs113488022", "most_severe_consequence": "missense_variant"}
            ],
        )
    )
    w = VariantAnnotationWorker()
    out = await w._annotate_vep("rs113488022", "hg38", "homo_sapiens")
    assert route.called
    assert out["_source"] == "ensembl_vep"
    assert out["species"] == "homo_sapiens"
    assert out["assembly"] == "hg38"
    assert out["most_severe_consequence"] == "missense_variant"


@respx.mock
async def test_vep_hgvs_protein_url_encoded():
    route = respx.get(
        url__regex=r"https://rest\.ensembl\.org/vep/homo_sapiens/hgvs/.*"
    ).mock(
        return_value=Response(
            200,
            json=[{"id": "BRAF:p.V600E", "most_severe_consequence": "missense_variant"}],
        )
    )
    w = VariantAnnotationWorker()
    await w._annotate_vep("BRAF:p.V600E", "hg38", "homo_sapiens")
    # Colon must be percent-encoded as %3A
    assert "%3A" in str(route.calls.last.request.url)


@respx.mock
async def test_vep_grch37_endpoint_used_for_hg19():
    route = respx.get(
        url__regex=r"https://grch37\.rest\.ensembl\.org/.*"
    ).mock(return_value=Response(200, json=[{"id": "x"}]))
    w = VariantAnnotationWorker()
    await w._annotate_vep("rs1", "hg19", "homo_sapiens")
    assert route.called


@respx.mock
async def test_vep_non_human_uses_main_endpoint_regardless_of_assembly():
    route = respx.get(
        url__regex=r"https://rest\.ensembl\.org/vep/arabidopsis_thaliana/.*"
    ).mock(return_value=Response(200, json=[{"id": "x"}]))
    w = VariantAnnotationWorker()
    # Even with assembly=hg19, non-human stays on rest.ensembl.org
    await w._annotate_vep("AT1G01010:c.100A>T", "hg19", "arabidopsis_thaliana")
    assert route.called


@respx.mock
async def test_vep_region_format_uses_post_with_payload():
    route = respx.post(
        url__regex=r"https://rest\.ensembl\.org/vep/homo_sapiens/region.*"
    ).mock(
        return_value=Response(
            200,
            json=[{"input": "7 140753336 . A T", "most_severe_consequence": "missense_variant"}],
        )
    )
    w = VariantAnnotationWorker()
    out = await w._annotate_vep("7:140753336:A:T", "hg38", "homo_sapiens")
    assert route.called
    assert route.calls.last.request.method == "POST"
    body = route.calls.last.request.read()
    assert b"variants" in body
    assert b"140753336" in body
    assert out["most_severe_consequence"] == "missense_variant"


@respx.mock
async def test_vep_batch_routes_by_format():
    id_route = respx.post(url__regex=r".*/vep/homo_sapiens/id$").mock(
        return_value=Response(200, json=[{"id": "rs1"}])
    )
    hgvs_route = respx.post(url__regex=r".*/vep/homo_sapiens/hgvs$").mock(
        return_value=Response(200, json=[{"id": "BRAF:p.V600E"}])
    )
    region_route = respx.post(url__regex=r".*/vep/homo_sapiens/region$").mock(
        return_value=Response(200, json=[{"id": "7 140753336 . A T"}])
    )
    w = VariantAnnotationWorker()
    out = await w._annotate_vep(
        ["rs1", "BRAF:p.V600E", "7:140753336:A:T"], "hg38", "homo_sapiens"
    )
    assert id_route.called and hgvs_route.called and region_route.called
    assert out["_source"] == "ensembl_vep"
    assert len(out["results"]) == 3


@respx.mock
async def test_civic_returns_evidence_when_variant_found():
    payload_search = {
        "data": {
            "browseVariants": {
                "edges": [{"node": {"id": 12, "name": "V600E", "link": "/variants/12"}}]
            }
        }
    }
    payload_evidence = {
        "data": {
            "variant": {
                "id": 12,
                "name": "V600E",
                "feature": {"name": "BRAF"},
                "molecularProfiles": {"nodes": []},
            }
        }
    }
    routes = respx.post(CIVIC_GRAPHQL_URL).mock(
        side_effect=[
            Response(200, json=payload_search),
            Response(200, json=payload_evidence),
        ]
    )
    w = VariantAnnotationWorker()
    out = await w._annotate_civic("BRAF", "V600E")
    assert routes.call_count == 2
    assert out["found"] is True
    assert out["civic_url"] == "https://civicdb.org/variants/12"
    assert out["_source"] == "civic"


@respx.mock
async def test_civic_returns_not_found_when_no_match():
    respx.post(CIVIC_GRAPHQL_URL).mock(
        return_value=Response(200, json={"data": {"browseVariants": {"edges": []}}})
    )
    w = VariantAnnotationWorker()
    out = await w._annotate_civic("BRAF", "ZZZ999Z")
    assert out["found"] is False
    assert "No CIViC entry" in out["message"]


@respx.mock
async def test_civic_strips_p_dot_prefix_before_search():
    route = respx.post(CIVIC_GRAPHQL_URL).mock(
        return_value=Response(200, json={"data": {"browseVariants": {"edges": []}}})
    )
    w = VariantAnnotationWorker()
    await w._annotate_civic("BRAF", "p.V600E")
    body = route.calls.last.request.read()
    # The lowercase "p." must be stripped — only "V600E" should be in the variables.
    assert b"V600E" in body
    assert b"p.V600E" not in body


async def test_annotate_router_rejects_unknown_action():
    w = VariantAnnotationWorker()
    out = await w.annotate(action="bogus")
    assert "error" in out
    assert "valid_actions" in out
    assert out["valid_actions"] == ["myvariant", "vep", "civic"]


async def test_annotate_civic_requires_gene_and_variant_name():
    w = VariantAnnotationWorker()
    out = await w.annotate(action="civic", gene="BRAF")  # missing variant_name
    assert "error" in out


async def test_annotate_myvariant_requires_variants():
    w = VariantAnnotationWorker()
    out = await w.annotate(action="myvariant")
    assert "error" in out
