"""Integration test for the compact vcf_schema summary.

Uses the bundled `data/test.vcf.gz` (a 56-sample CAGI cohort) to verify the
summary fits in the agent's context budget and lists samples + FORMAT field
names correctly. Skips if the test fixture isn't present.
"""

from pathlib import Path

import pytest

FIXTURE = Path("data/test.vcf.gz")


@pytest.fixture(scope="module")
def summary() -> str:
    if not FIXTURE.exists():
        pytest.skip(f"missing fixture: {FIXTURE}")
    from aiva_agent.tools.vcf import _open_connection, _summarize_view

    specs = [("vcf", FIXTURE)]
    con = _open_connection(specs)
    try:
        return _summarize_view(con, "vcf", FIXTURE)
    finally:
        con.close()


def test_summary_is_compact(summary: str):
    # The whole single-view summary should fit in a handful of lines, not
    # hundreds. A 56-sample file produces 430 raw DESCRIBE rows; the summary
    # must collapse them.
    n_lines = summary.count("\n") + 1
    assert n_lines <= 10, f"expected ≤10 lines, got {n_lines}\n{summary}"


def test_summary_lists_view_header(summary: str):
    assert summary.startswith("view: vcf")
    assert "data/test.vcf.gz" in summary


def test_summary_lists_standard_columns(summary: str):
    assert "CHROM VARCHAR" in summary
    assert "POS BIGINT" in summary
    assert "ALT VARCHAR[]" in summary


def test_summary_includes_info_block(summary: str):
    assert "INFO_AC" in summary
    assert "INFO_AN" in summary


def test_summary_lists_samples(summary: str):
    assert "samples" in summary
    # The fixture has trio CAGI7_RGP IDs; verify at least one shows up.
    assert "CAGI7_RGP" in summary


def test_summary_lists_format_field_names_once(summary: str):
    # Each canonical FORMAT field should appear exactly once in the
    # FORMAT/<sample> block, regardless of how many samples are in the file.
    format_line = next(
        (line for line in summary.splitlines() if line.lstrip().startswith("FORMAT/")),
        None,
    )
    assert format_line is not None, f"missing FORMAT line:\n{summary}"
    for fid in ("GT", "AD", "GQ", "FT", "PGT", "PID", "PS", "RGQ"):
        assert format_line.count(f"{fid} ") == 1 or format_line.count(f", {fid}") == 1, (
            f"{fid} should appear exactly once in:\n{format_line}"
        )
