from opik.integrations.genai import track_genai

__all__ = ("track_genai",)