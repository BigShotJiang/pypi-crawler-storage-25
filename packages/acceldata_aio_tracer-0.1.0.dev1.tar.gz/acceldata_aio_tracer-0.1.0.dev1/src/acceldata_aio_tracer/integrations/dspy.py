from opik.integrations.dspy import OpikCallback as DSPyCallback

__all__ = ("DSPyCallback",)