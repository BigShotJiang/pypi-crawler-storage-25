from opik.integrations.bedrock import track_bedrock

__all__ = ("track_bedrock",)