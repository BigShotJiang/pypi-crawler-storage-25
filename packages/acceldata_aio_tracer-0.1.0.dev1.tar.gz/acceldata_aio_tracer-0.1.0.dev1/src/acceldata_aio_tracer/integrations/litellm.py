from opik.integrations.litellm import track_completion

__all__ = ("track_completion",)