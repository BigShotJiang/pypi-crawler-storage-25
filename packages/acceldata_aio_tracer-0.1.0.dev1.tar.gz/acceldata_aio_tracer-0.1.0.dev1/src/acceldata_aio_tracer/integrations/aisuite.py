from opik.integrations.aisuite import track_aisuite

__all__ = ("track_aisuite",)