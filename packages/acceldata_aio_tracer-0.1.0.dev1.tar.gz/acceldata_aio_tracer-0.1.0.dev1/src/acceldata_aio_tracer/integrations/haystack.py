from opik.integrations.haystack import OpikConnector as HaystackConnector

__all__ = ("HaystackConnector",)