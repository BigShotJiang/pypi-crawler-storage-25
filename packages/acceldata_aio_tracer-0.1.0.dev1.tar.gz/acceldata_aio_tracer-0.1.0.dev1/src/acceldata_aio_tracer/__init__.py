from typing import Optional

import opik as _opik
from opik import *  # noqa: F401, F403

from . import _opik_bridge
from .auth import (
    AcceldataAuth,
    setup_acceldata_auth,
    setup_acceldata_auth_hook,
)
from .client import AcceldataTracer


def configure(
    url: str,
    access_key: str,
    secret_key: str,
    *,
    project_name: Optional[str] = None,
    debug: bool = False,
    check_tls_certificate: bool = True,
) -> None:
    """Acceldata equivalent of opik.configure().

    Registers the Acceldata auth hook so every subsequent Opik client
    carries accessKey/secretKey headers, applies the URL/project settings,
    and optionally installs an HTTP debug interceptor.

    The first three parameters (``url``, ``access_key``, ``secret_key``) are
    the SDK's stable public surface and may be passed positionally or by
    name. All other options are keyword-only so future flags can be added,
    deprecated, or removed without breaking customer call sites.

    Each argument has a matching ``ACCELDATA_AIO_*`` env variable that can
    be used instead of an explicit call. If both are present the explicit
    argument wins; if neither, ``configure()`` cannot be skipped. Upstream
    ``OPIK_*`` names are accepted as a fallback (see README "Environment
    variables").

    Args:
        url: Acceldata gateway URL, e.g.
            ``https://acme.acceldata.local:5443/aio``.
            Env: ``ACCELDATA_AIO_URL`` (fallback: ``OPIK_URL_OVERRIDE``).
        access_key: Acceldata API access key.
            Env: ``ACCELDATA_AIO_ACCESS_KEY``
            (fallback: ``OPIK_ACCESS_KEY``).
        secret_key: Acceldata API secret key.
            Env: ``ACCELDATA_AIO_SECRET_KEY``
            (fallback: ``OPIK_SECRET_KEY``).
        project_name: Default project name for traces.
            Env: ``ACCELDATA_AIO_PROJECT_NAME``
            (fallback: ``OPIK_PROJECT_NAME``).
        debug: When True, install an httpx interceptor that logs every Opik
            HTTP call and, on >=400 responses, dumps the request body to
            disk and prints a copy-paste curl for replay. Off by default.
            Env: ``ACCELDATA_AIO_DEBUG`` accepts ``1`` / ``true`` / ``yes``
            / ``on`` (case-insensitive) to enable. Wrapper-specific — has
            no upstream ``OPIK_*`` fallback.
        check_tls_certificate: When False, disables TLS certificate
            verification for outbound HTTP calls. Use only for local dev
            against self-signed gateways. Default True.
            Env: ``ACCELDATA_AIO_CHECK_TLS_CERTIFICATE``
            (fallback: ``OPIK_CHECK_TLS_CERTIFICATE``).
    """
    _opik_bridge.apply_configure(
        url=url,
        access_key=access_key,
        secret_key=secret_key,
        project_name=project_name,
        debug=debug,
        check_tls_certificate=check_tls_certificate,
    )


# Bootstrap ACCELDATA_AIO_* env vars and auto-register the auth hook at
# import time. All upstream-naming details live in _opik_bridge so this
# module stays free of OPIK_* references.
_opik_bridge.bootstrap_from_env()


__all__ = (
    "AcceldataTracer",
    "AcceldataAuth",
    "configure",
    "setup_acceldata_auth",
    "setup_acceldata_auth_hook",
    *_opik.__all__,
)

del _opik
