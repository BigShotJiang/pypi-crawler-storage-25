"""Configuration management for reDUP."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib
    except ImportError:
        tomllib = None

from redup.config import config as global_config
from redup.core.models import ScanConfig


def _load_toml_file(file_path: Path) -> dict[str, Any]:
    """Load TOML file and return as dictionary."""
    if tomllib is None:
        return {}

    if not file_path.exists():
        return {}

    try:
        with open(file_path, "rb") as f:
            return tomllib.load(f)
    except Exception:
        return {}


def _get_config_from_pyproject() -> dict[str, Any]:
    """Get reDUP configuration from pyproject.toml [tool.redup] section."""
    pyproject_path = Path.cwd() / "pyproject.toml"
    data = _load_toml_file(pyproject_path)
    return data.get("tool", {}).get("redup", {})


def _get_config_from_redup_toml() -> dict[str, Any]:
    """Get reDUP configuration from redup.toml file."""
    redup_toml_path = Path.cwd() / "redup.toml"
    return _load_toml_file(redup_toml_path)


def load_config() -> dict[str, Any]:
    """Load reDUP configuration from available sources.

    Priority order:
    1. Environment variables (REDUP_*)
    2. .env file in current directory (auto-loaded via redup.config)
    3. redup.toml in current directory
    4. [tool.redup] in pyproject.toml
    5. Global config defaults (redup.config)
    """
    # Start with global config defaults (already includes .env if present)
    config = {
        "extensions": global_config.DEFAULT_EXTENSIONS,
        "min_lines": global_config.DEFAULT_MIN_LINES,
        "min_similarity": global_config.DEFAULT_MIN_SIMILARITY,
        "include_tests": global_config.DEFAULT_INCLUDE_TESTS,
        "output": global_config.DEFAULT_OUTPUT_DIR,
        "format": global_config.DEFAULT_FORMAT,
    }

    # Load from redup.toml
    config.update(_get_config_from_redup_toml())

    # Load from pyproject.toml (overwrites redup.toml)
    config.update(_get_config_from_pyproject())

    # Override with environment variables
    env_mappings = {
        "REDUP_EXTENSIONS": ("extensions", str),
        "REDUP_MIN_LINES": ("min_lines", int),
        "REDUP_MIN_SIMILARITY": ("min_similarity", float),
        "REDUP_INCLUDE_TESTS": ("include_tests", bool),
        "REDUP_OUTPUT": ("output", str),
        "REDUP_FORMAT": ("format", str),
        "REDUP_MAX_GROUPS": ("max_groups", int),
        "REDUP_MAX_LINES": ("max_lines", int),
    }

    for env_var, (key, type_func) in env_mappings.items():
        value = os.getenv(env_var)
        if value is not None:
            try:
                if type_func == bool:
                    config[key] = value.lower() in ("true", "1", "yes", "on")
                else:
                    config[key] = type_func(value)
            except (ValueError, TypeError):
                pass  # Ignore invalid environment variables

    return config


def config_to_scan_config(config: dict[str, Any], path: Path) -> ScanConfig:
    """Convert configuration dict to ScanConfig object."""
    extensions = config.get("extensions", ".py")
    if isinstance(extensions, str):
        ext_list = [
            e.strip() if e.startswith(".") else f".{e.strip()}" for e in extensions.split(",")
        ]
    else:
        ext_list = extensions

    scan_config = config.get("scan", {})
    lsh_config = config.get("lsh", {})

    return ScanConfig(
        root=path,
        extensions=ext_list,
        min_block_lines=config.get("min_lines", scan_config.get("min_lines", 3)),
        min_similarity=config.get("min_similarity", scan_config.get("min_similarity", 0.85)),
        include_tests=config.get("include_tests", scan_config.get("include_tests", False)),
        lsh_enabled=lsh_config.get("enabled", True),
        lsh_min_lines=lsh_config.get("min_lines", 50),
        lsh_threshold=lsh_config.get("threshold", 0.8),
    )


def create_sample_redup_toml() -> str:
    """Create a sample redup.toml configuration file content."""
    return """# reDUP Configuration File
# See https://github.com/semcod/redup for documentation
#
# You can also use a .env file in your project directory:
#   REDUP_DEFAULT_OUTPUT_FILENAME=my_duplication.yaml
#   REDUP_DEFAULT_FORMAT=toon
#   REDUP_MIN_LINES=5

[scan]
# File extensions to scan (comma-separated)
extensions = ".py,.js,.ts,.go,.rs,.java"
# Minimum block size in lines to consider as duplicate
min_lines = 3
# Minimum similarity score (0.0-1.0) for fuzzy matches
min_similarity = 0.85
# Include test files in analysis
include_tests = false

[lsh]
# Enable LSH near-duplicate detection for large blocks
enabled = true
# Minimum block size for LSH analysis
min_lines = 50
# Similarity threshold for LSH (0.0-1.0)
threshold = 0.8

[check]
# CI gate thresholds
max_groups = 10
max_lines = 100

[output]
# Default output format
format = "toon"
# Default output filename (can include suffix)
filename = "duplication.toon.yaml"
# Default output directory (relative to project root)
output = "redup_output"

[reporting]
# Include code snippets in JSON output
include_snippets = false
# Generate suggestions for refactoring
generate_suggestions = true
"""
