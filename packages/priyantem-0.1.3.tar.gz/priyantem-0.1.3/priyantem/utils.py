import pyperclip

def add(a, b):
    result = a + b
    pyperclip.copy(str(result))
    return result

def square(n):
    result = n * n
    pyperclip.copy(str(result))
    return result

programs = {
    "add": add,
    "square": square
}