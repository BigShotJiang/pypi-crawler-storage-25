from dataclasses import dataclass
from pathlib import Path

import yaml
from dotenv import find_dotenv, load_dotenv
import os


@dataclass
class LLMConfig:
    provider: str
    model: str
    temperature: float


@dataclass
class EmbeddingsConfig:
    provider: str
    model: str


@dataclass
class VectorStoreConfig:
    provider: str
    persist_directory: str


@dataclass
class IngestionConfig:
    sync_on_startup: bool
    chunk_size: int
    chunk_overlap: int


@dataclass
class ZoteroConfig:
    library_id: str
    library_type: str
    api_key: str


@dataclass
class Config:
    llm: LLMConfig
    embeddings: EmbeddingsConfig
    vector_store: VectorStoreConfig
    ingestion: IngestionConfig
    zotero: ZoteroConfig


def load_config(path: str = "config.yaml") -> Config:
    """Load config from a YAML file and apply .env overrides. Raises if required fields are missing."""
    load_dotenv(find_dotenv(usecwd=True))

    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(
            "config.yaml not found."
        )

    raw = yaml.safe_load(config_path.read_text())

    # Zotero — env vars take precedence over config.yaml
    zotero_raw = raw.get("zotero", {})
    library_id = os.getenv("ZOTERO_LIBRARY_ID") or zotero_raw.get("library_id", "")
    api_key = os.getenv("ZOTERO_API_KEY", "")

    if not library_id:
        raise ValueError(
            "Zotero library ID is not set. Add 'zotero.library_id' to config.yaml "
            "or set the ZOTERO_LIBRARY_ID environment variable."
        )
    if not api_key:
        raise ValueError(
            "ZOTERO_API_KEY is not set. Add it to your .env file or environment variables."
        )

    vs_raw = raw.get("vector_store", {})
    ing_raw = raw.get("ingestion", {})
    llm_raw = raw.get("llm", {})
    emb_raw = raw.get("embeddings", {})

    return Config(
        llm=LLMConfig(
            provider=llm_raw.get("provider", "openai"),
            model=llm_raw.get("model", "gpt-4o"),
            temperature=llm_raw.get("temperature", 0.2),
        ),
        embeddings=EmbeddingsConfig(
            provider=emb_raw.get("provider", "openai"),
            model=emb_raw.get("model", "text-embedding-3-small"),
        ),
        vector_store=VectorStoreConfig(
            provider=vs_raw.get("provider", "chroma"),
            persist_directory=vs_raw.get("persist_directory", ".zori/chroma"),
        ),
        ingestion=IngestionConfig(
            sync_on_startup=ing_raw.get("sync_on_startup", False),
            chunk_size=ing_raw.get("chunk_size", 1000),
            chunk_overlap=ing_raw.get("chunk_overlap", 200),
        ),
        zotero=ZoteroConfig(
            library_id=library_id,
            library_type=zotero_raw.get("library_type", "user"),
            api_key=api_key,
        ),
    )
