"""Claude Code provider: detection and auth handlers for desktop onboarding."""

from __future__ import annotations

import json
import shutil
import subprocess
import threading
from typing import Any

from obra.config.loaders import get_gateway_onboarding_config

# Module-level state for the background auth subprocess.
_auth_process: subprocess.Popen | None = None
_auth_lock = threading.Lock()


def detect_claude_code() -> dict[str, Any]:
    """Detect whether the Claude Code native binary is installed.

    Returns dict with ``installed``, and either ``path``/``version``
    or ``install_url``/``install_command``.
    """
    config = get_gateway_onboarding_config()
    timeout = config["detection_timeout_s"]

    binary_path = shutil.which("claude")
    if not binary_path:
        return {
            "installed": False,
            "install_url": "https://claude.com/download",
            "install_command": "curl -fsSL https://claude.com/install.sh | sh",
        }

    # Try to get the version.
    try:
        result = subprocess.run(
            [binary_path, "--version"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        version = result.stdout.strip() if result.returncode == 0 else "unknown"
    except (subprocess.TimeoutExpired, OSError):
        version = "unknown"

    return {
        "installed": True,
        "path": binary_path,
        "version": version,
    }


def check_claude_code_auth() -> dict[str, Any]:
    """Check whether Claude Code is authenticated.

    Returns dict with ``authenticated`` and optional ``auth_issue``.
    """
    config = get_gateway_onboarding_config()
    timeout = config["auth_check_timeout_s"]

    binary_path = shutil.which("claude")
    if not binary_path:
        return {"authenticated": False, "auth_issue": "not_installed"}

    try:
        result = subprocess.run(
            [binary_path, "auth", "status"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode == 0:
            # claude auth status returns JSON with a loggedIn boolean.
            try:
                data = json.loads(result.stdout)
                if data.get("loggedIn"):
                    return {"authenticated": True, "auth_issue": None}
            except (json.JSONDecodeError, AttributeError):
                pass
            # Fallback: match keywords in non-JSON output.
            output = result.stdout.lower()
            if "authenticated" in output or "logged in" in output or "loggedin" in output:
                return {"authenticated": True, "auth_issue": None}
            if "expired" in output:
                return {"authenticated": False, "auth_issue": "expired"}
        return {"authenticated": False, "auth_issue": "not_authenticated"}
    except subprocess.TimeoutExpired:
        return {"authenticated": False, "auth_issue": "connection_failed"}
    except OSError:
        return {"authenticated": False, "auth_issue": "not_installed"}


def authenticate_claude_code() -> dict[str, Any]:
    """Trigger Claude Code OAuth login flow.

    Spawns ``claude auth login`` in the background. The auth-status
    endpoint detects completion by re-checking ``check_claude_code_auth()``.
    """
    global _auth_process

    config = get_gateway_onboarding_config()
    auth_timeout = config["auth_timeout_s"]

    binary_path = shutil.which("claude")
    if not binary_path:
        return {"triggered": False, "error": "Claude Code is not installed"}

    with _auth_lock:
        # Kill any existing auth process.
        if _auth_process is not None:
            try:
                _auth_process.kill()
            except OSError:
                pass
            _auth_process = None

        try:
            _auth_process = subprocess.Popen(
                [binary_path, "auth", "login"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
        except OSError as e:
            return {"triggered": False, "error": str(e)}

    # Start a timer to kill the process if auth times out.
    def _timeout_killer():
        global _auth_process
        with _auth_lock:
            if _auth_process is not None:
                try:
                    _auth_process.kill()
                except OSError:
                    pass
                _auth_process = None

    timer = threading.Timer(auth_timeout, _timeout_killer)
    timer.daemon = True
    timer.start()

    return {"triggered": True}
