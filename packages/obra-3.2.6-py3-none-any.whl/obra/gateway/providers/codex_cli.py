"""OpenAI Codex CLI provider: detection and auth handlers for desktop onboarding."""

from __future__ import annotations

import shutil
import subprocess
import threading
from typing import Any

from obra.config.loaders import get_gateway_onboarding_config

# Module-level state for the background auth subprocess.
_auth_process: subprocess.Popen | None = None
_auth_lock = threading.Lock()


def detect_codex_cli() -> dict[str, Any]:
    """Detect whether the Codex CLI binary is installed.

    Returns dict with ``installed``, and either ``path``/``version``
    or ``install_url``/``install_command``.
    """
    config = get_gateway_onboarding_config()
    timeout = config["detection_timeout_s"]

    binary_path = shutil.which("codex")
    if not binary_path:
        return {
            "installed": False,
            "install_url": "https://openai.com/codex/",
            "install_command": "npm install -g @openai/codex",
        }

    # Try to get the version.
    try:
        result = subprocess.run(
            [binary_path, "--version"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        version = result.stdout.strip() if result.returncode == 0 else "unknown"
    except (subprocess.TimeoutExpired, OSError):
        version = "unknown"

    return {
        "installed": True,
        "path": binary_path,
        "version": version,
    }


def check_openai_auth() -> dict[str, Any]:
    """Check whether Codex CLI is authenticated with OpenAI.

    Function named ``check_openai_auth`` to match the onboarding.py
    resolution convention ``check_{provider_id}_auth`` where provider_id
    is ``openai``.

    Returns dict with ``authenticated`` and optional ``auth_issue``.
    """
    config = get_gateway_onboarding_config()
    timeout = config["auth_check_timeout_s"]

    binary_path = shutil.which("codex")
    if not binary_path:
        return {"authenticated": False, "auth_issue": "not_installed"}

    try:
        result = subprocess.run(
            [binary_path, "auth", "status"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode == 0:
            output = result.stdout.lower()
            if "authenticated" in output or "logged in" in output:
                return {"authenticated": True, "auth_issue": None}
            if "expired" in output:
                return {"authenticated": False, "auth_issue": "expired"}
        return {"authenticated": False, "auth_issue": "not_authenticated"}
    except subprocess.TimeoutExpired:
        return {"authenticated": False, "auth_issue": "connection_failed"}
    except OSError:
        return {"authenticated": False, "auth_issue": "not_installed"}


def authenticate_codex_cli() -> dict[str, Any]:
    """Trigger Codex CLI OAuth login flow.

    Spawns ``codex --login`` in the background. The auth-status
    endpoint detects completion by re-checking ``check_openai_auth()``.
    """
    global _auth_process

    config = get_gateway_onboarding_config()
    auth_timeout = config["auth_timeout_s"]

    binary_path = shutil.which("codex")
    if not binary_path:
        return {"triggered": False, "error": "Codex CLI is not installed"}

    with _auth_lock:
        if _auth_process is not None:
            try:
                _auth_process.kill()
            except OSError:
                pass
            _auth_process = None

        try:
            _auth_process = subprocess.Popen(
                [binary_path, "--login"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
        except OSError as e:
            return {"triggered": False, "error": str(e)}

    def _timeout_killer():
        global _auth_process
        with _auth_lock:
            if _auth_process is not None:
                try:
                    _auth_process.kill()
                except OSError:
                    pass
                _auth_process = None

    timer = threading.Timer(auth_timeout, _timeout_killer)
    timer.daemon = True
    timer.start()

    return {"triggered": True}
