"""Canonical Workflow Studio workflow-run routes."""

from __future__ import annotations

from collections import Counter
from datetime import datetime
from typing import Any

from fastapi import APIRouter, HTTPException, Query, Request, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field, field_validator

from obra.api import APIClient
from obra.domains.resolution import DomainResolutionError
from obra.exceptions import APIError
from obra.gateway.error_codes import (
    CONFLICT,
    INVALID_REQUEST,
    QUALITY_SCORECARD_FETCH_FAILED,
    RUN_NOT_FOUND,
    STAGE_NOT_FOUND,
    WORKING_DIRECTORY_NOT_ALLOWED,
)
from obra.gateway.errors import GatewayAPIError
from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.session_manager import SessionNotFoundError
from obra.gateway.validation import (
    resolve_input_document_from_workflow,
    validate_input_against_spec,
)
from obra.gateway.workflow_studio.comparison import build_run_comparison
from obra.gateway.workflow_studio.operator_actions import WorkflowRunActionService
from obra.gateway.workflow_studio.artifacts import build_artifact_summary
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository

router = APIRouter(prefix="/api/workflow-runs", tags=["workflow-studio"])


class CreateWorkflowRunRequest(BaseModel):
    """Request body for creating a canonical workflow run."""

    model_config = ConfigDict(extra="forbid")

    objective: str = Field(..., max_length=10_000)
    project_id: str = Field(..., max_length=256)
    working_dir: str = Field(..., max_length=4096)
    workflow_id: str | None = None
    revision_id: str | None = None
    domain_id: str | None = None
    parent_payload: dict[str, Any] = Field(default_factory=dict)
    launch_metadata: dict[str, Any] = Field(default_factory=dict)
    input_manifest: list[str] | None = None
    input_payload: dict[str, str] | None = None

    @field_validator("workflow_id", "revision_id", "domain_id", mode="before")
    @classmethod
    def _normalize_optional_strings(cls, value: Any) -> str | None:
        if value is None:
            return None
        if isinstance(value, str):
            normalized = value.strip()
            return normalized or None
        return value


class ResumeWorkflowRunRequest(BaseModel):
    """Request body for resuming a workflow run."""

    resume_target: str | None = None


class ValidateInputRequest(BaseModel):
    """Request body for workflow input pre-flight validation."""

    model_config = ConfigDict(extra="forbid")

    workflow_id: str = Field(..., max_length=256)
    input_payload: dict[str, str] | None = None


class OperatorActionRequest(BaseModel):
    """Request body for operator actions."""

    action: str = Field(..., max_length=128)
    payload: dict[str, Any] = Field(default_factory=dict)


class ResolveEscalationRequest(BaseModel):
    """Request body for escalation resolution."""

    choice: str = Field(..., max_length=128)
    was_timeout: bool = False


@router.get("/")
async def list_workflow_runs(
    request: Request,
    workflow_id: str | None = Query(default=None, max_length=256),
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return paginate_collection(
        collection_key="workflow_runs",
        items=repository.list_runs(workflow_id=workflow_id),
        params=pagination_params_from_request(request),
    )


@router.get("/compare")
async def compare_workflow_runs(
    request: Request,
    run_ids: str = Query(..., description="Comma-separated run IDs"),
) -> dict[str, Any]:
    normalized_run_ids = list(
        dict.fromkeys(run_id.strip() for run_id in run_ids.split(",") if run_id.strip())
    )
    if len(normalized_run_ids) < 2:
        raise GatewayAPIError(
            error_code=INVALID_REQUEST,
            message="At least two run_ids are required",
            status_code=status.HTTP_400_BAD_REQUEST,
        )
    if len(normalized_run_ids) > 10:
        raise GatewayAPIError(
            error_code=INVALID_REQUEST,
            message="At most 10 run_ids are allowed",
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    repository = WorkflowStudioRepository.from_request(request)
    bundles = []
    for run_id in normalized_run_ids:
        try:
            bundles.append(repository.get_run_bundle(run_id))
        except (KeyError, SessionNotFoundError) as exc:
            raise GatewayAPIError(
                error_code=RUN_NOT_FOUND,
                message=f"Run not found: {run_id}",
                status_code=status.HTTP_404_NOT_FOUND,
            ) from exc
    return build_run_comparison(bundles)


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_workflow_run(
    body: CreateWorkflowRunRequest,
    request: Request,
) -> dict[str, object]:
    session_manager = request.app.state.session_manager
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    if callable(client_factory):
        session_manager.set_client_factory(client_factory)
    if body.workflow_id is not None:
        repository = WorkflowStudioRepository.from_request(request)
        workflow = repository.get_workflow(body.workflow_id)
        if workflow is not None:
            input_document = resolve_input_document_from_workflow(workflow)
            if input_document is not None:
                errors = validate_input_against_spec(input_document, body.input_payload)
                if errors:
                    return JSONResponse(
                        status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                        content={
                            "error_code": "validation_error",
                            "message": "Request failed",
                            "hint": None,
                            "validation_errors": errors,
                        },
                    )
    try:
        run_id = session_manager.create_workflow_run(
            objective=body.objective,
            project_id=body.project_id,
            working_dir=body.working_dir,
            workflow_id=body.workflow_id,
            revision_id=body.revision_id,
            domain_id=body.domain_id,
            parent_payload=body.parent_payload,
            launch_metadata=body.launch_metadata,
            input_manifest=body.input_manifest,
            input_payload=body.input_payload,
        )
    except DomainResolutionError as exc:
        raise GatewayAPIError(
            error_code=exc.code,
            message=str(exc),
            status_code=exc.http_status.value,
        ) from exc
    except ValueError as exc:
        raise GatewayAPIError(
            error_code=WORKING_DIRECTORY_NOT_ALLOWED,
            message="Working directory not allowed",
            status_code=status.HTTP_403_FORBIDDEN,
        ) from exc

    repository = WorkflowStudioRepository.from_request(request)
    workflow_run = repository.get_run(run_id)
    return {"workflow_run": workflow_run or {"run_id": run_id, "workflow_run_id": run_id}}


@router.post("/validate-input")
async def validate_input(body: ValidateInputRequest, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    workflow = repository.get_workflow(body.workflow_id)
    if workflow is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")

    input_document = resolve_input_document_from_workflow(workflow)
    if input_document is None:
        return {
            "valid": True,
            "errors": [],
            "workflow_id": body.workflow_id,
            "note": "No input spec defined for this workflow",
        }

    errors = validate_input_against_spec(input_document, body.input_payload)
    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "workflow_id": body.workflow_id,
    }


@router.get("/{run_id}")
async def get_workflow_run(run_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    workflow_run = repository.get_run(run_id)
    if workflow_run is None:
        raise GatewayAPIError(
            error_code=RUN_NOT_FOUND,
            message="Workflow run not found",
            status_code=status.HTTP_404_NOT_FOUND,
        )
    return {"workflow_run": workflow_run}


@router.get("/{run_id}/lineage")
async def get_workflow_run_lineage(run_id: str, request: Request) -> dict[str, Any]:
    repository = WorkflowStudioRepository.from_request(request)
    try:
        lineage = repository.get_run_lineage(run_id)
    except SessionNotFoundError as exc:
        raise GatewayAPIError(
            error_code=RUN_NOT_FOUND,
            message="Workflow run not found",
            status_code=status.HTTP_404_NOT_FOUND,
        ) from exc
    return {"lineage": lineage}


@router.post("/{run_id}/cancel")
async def cancel_workflow_run(run_id: str, request: Request) -> dict[str, object]:
    service = WorkflowRunActionService(request.app.state.session_manager)
    try:
        return service.cancel(
            run_id,
            client_request_id=_client_request_id(request),
        )
    except Exception as exc:
        raise GatewayAPIError(
            error_code=RUN_NOT_FOUND,
            message="Workflow run not found",
            status_code=status.HTTP_404_NOT_FOUND,
        ) from exc


@router.post("/{run_id}/resume")
async def resume_workflow_run(
    run_id: str,
    body: ResumeWorkflowRunRequest,
    request: Request,
) -> dict[str, object]:
    service = WorkflowRunActionService(request.app.state.session_manager)
    try:
        return service.resume(
            run_id,
            resume_target=body.resume_target,
            client_request_id=_client_request_id(request),
        )
    except ValueError as exc:
        raise GatewayAPIError(
            error_code=CONFLICT,
            message=str(exc),
            status_code=status.HTTP_409_CONFLICT,
        ) from exc
    except Exception as exc:
        raise GatewayAPIError(
            error_code=RUN_NOT_FOUND,
            message="Workflow run not found",
            status_code=status.HTTP_404_NOT_FOUND,
        ) from exc


@router.post("/{run_id}/operator-actions")
async def perform_operator_action(
    run_id: str,
    body: OperatorActionRequest,
    request: Request,
) -> dict[str, object]:
    service = WorkflowRunActionService(request.app.state.session_manager)
    return service.dispatch(
        run_id,
        action=body.action,
        payload=body.payload,
        client_request_id=_client_request_id(request),
    )


@router.post("/{run_id}/escalations/{escalation_id}/resolve")
async def resolve_workflow_run_escalation(
    run_id: str,
    escalation_id: str,
    body: ResolveEscalationRequest,
    request: Request,
) -> dict[str, object]:
    service = WorkflowRunActionService(request.app.state.session_manager)
    return service.resolve_escalation(
        run_id,
        escalation_id,
        choice=body.choice,
        was_timeout=body.was_timeout,
        client_request_id=_client_request_id(request),
    )


@router.get("/{run_id}/stages")
async def list_run_stages(run_id: str, request: Request) -> dict[str, Any]:
    bundle = _get_run_bundle(request, run_id)
    return paginate_collection(
        collection_key="stages",
        items=[_stage_summary(stage) for stage in bundle.pipeline_stages],
        params=pagination_params_from_request(request),
    )


@router.get("/{run_id}/stages/{stage_name}")
async def get_run_stage(run_id: str, stage_name: str, request: Request) -> dict[str, Any]:
    bundle = _get_run_bundle(request, run_id)
    stage = next(
        (
            candidate
            for candidate in bundle.pipeline_stages
            if str(candidate.get("stage_name") or candidate.get("trigger") or "") == stage_name
        ),
        None,
    )
    if stage is None:
        raise GatewayAPIError(
            error_code=STAGE_NOT_FOUND,
            message=f"Stage {stage_name} not found in run {run_id}",
            status_code=404,
        )

    execution_status = stage.get("execution_status") or stage.get("status")
    quality_loop_state = _stage_quality_loop_state(stage)
    return {
        "stage": {
            "stage_name": str(stage.get("stage_name") or stage.get("trigger") or ""),
            "status": stage.get("status"),
            "runner_kind": stage.get("runner_kind"),
            "execution_status": execution_status,
            "duration_s": _stage_duration_s(stage),
            "iteration_count": _stage_iteration_count(stage),
            "output_artifacts": _stage_output_artifacts(stage),
            "metadata": {
                "last_result": dict(stage.get("last_result") or {}),
                "started_at": stage.get("started_at"),
                "completed_at": stage.get("completed_at"),
                "resume_metadata": dict(stage.get("resume_metadata") or {}),
                "pending_manual_metadata": dict(stage.get("pending_manual_metadata") or {}),
            },
            "quality_loop_state": quality_loop_state,
            "failure_detail": _stage_failure_detail(
                stage,
                execution_status=execution_status,
                quality_loop_state=quality_loop_state,
            ),
        }
    }


@router.get("/{run_id}/summary")
async def get_run_summary(run_id: str, request: Request) -> dict[str, Any]:
    bundle = _get_run_bundle(request, run_id)
    stages = bundle.pipeline_stages
    normalized_statuses = [
        str(stage.get("execution_status") or stage.get("status") or "unknown") for stage in stages
    ]
    stages_by_status = Counter(normalized_statuses)
    total_duration_s = sum(
        duration
        for duration in (_stage_duration_s(stage) for stage in stages)
        if duration is not None
    )
    failed_stages = []
    for stage in stages:
        execution_status = str(stage.get("execution_status") or stage.get("status") or "")
        if execution_status.lower() not in {"failed", "error"}:
            continue
        last_result = stage.get("last_result")
        if not isinstance(last_result, dict):
            last_result = {}
        failed_stages.append(
            {
                "stage_name": str(stage.get("stage_name") or stage.get("trigger") or ""),
                "reason_code": (
                    last_result.get("reason_code")
                    or last_result.get("error_code")
                    or stage.get("outcome")
                    or execution_status
                ),
            }
        )

    overall_outcome = "in_progress"
    lowered_statuses = [status_name.lower() for status_name in normalized_statuses]
    if stages and all(
        status_name in {"completed", "passed", "success"} for status_name in lowered_statuses
    ):
        overall_outcome = "success"
    elif stages and all(status_name in {"failed", "error"} for status_name in lowered_statuses):
        overall_outcome = "failure"
    elif any(status_name in {"failed", "error"} for status_name in lowered_statuses):
        overall_outcome = "partial_failure"

    return {
        "summary": {
            "total_stages": len(stages),
            "stages_by_status": dict(stages_by_status),
            "total_duration_s": total_duration_s,
            "failed_stages": failed_stages,
            "overall_outcome": overall_outcome,
        }
    }


@router.get("/{run_id}/escalations")
async def list_run_escalations(run_id: str, request: Request) -> dict[str, Any]:
    bundle = _get_run_bundle(request, run_id)
    by_escalation_id: dict[str, dict[str, Any]] = {}
    active_escalation_id = str(bundle.record.escalation_id or "").strip()
    blocking_summary = (
        dict(bundle.record.blocking_summary)
        if isinstance(bundle.record.blocking_summary, dict)
        else {}
    )
    current_stage = (
        dict(bundle.record.current_stage) if isinstance(bundle.record.current_stage, dict) else {}
    )

    if active_escalation_id:
        by_escalation_id[active_escalation_id] = {
            "escalation_id": active_escalation_id,
            "reason": str(
                blocking_summary.get("reason") or blocking_summary.get("state") or "pending"
            ),
            "status": "pending",
            "stage_name": current_stage.get("stage_name"),
            "created": bundle.record.created_at.isoformat(),
        }

    for event in bundle.remote_events:
        payload = event.get("payload")
        if not isinstance(payload, dict):
            payload = {}
        event_type = str(event.get("event_type") or event.get("type") or "")
        escalation_id = str(
            event.get("escalation_id") or payload.get("escalation_id") or ""
        ).strip()
        if not escalation_id:
            if event_type != "escalation_notice":
                continue
            escalation_id = str(payload.get("id") or "").strip()
            if not escalation_id:
                continue
        created = _event_timestamp(event, default=bundle.record.created_at.isoformat())
        entry = {
            "escalation_id": escalation_id,
            "reason": str(payload.get("reason") or event.get("message") or "escalation"),
            "status": "pending" if escalation_id == active_escalation_id else "resolved",
            "stage_name": payload.get("stage_name") or event.get("stage_name"),
            "created": created,
        }
        existing = by_escalation_id.get(escalation_id)
        if existing is None or created >= str(existing.get("created") or ""):
            by_escalation_id[escalation_id] = entry

    return paginate_collection(
        collection_key="escalations",
        items=sorted(
            by_escalation_id.values(),
            key=lambda item: str(item.get("created") or ""),
            reverse=True,
        ),
        params=pagination_params_from_request(request),
    )


@router.get("/{run_id}/review-state")
async def get_run_review_state(run_id: str, request: Request) -> dict[str, Any]:
    bundle = _get_run_bundle(request, run_id)
    quality_loop_decisions = _collect_quality_loop_decisions(bundle)
    reviewer_findings = _collect_reviewer_findings(bundle)
    iteration_counts = {
        str(stage.get("stage_name") or stage.get("trigger") or ""): _stage_iteration_count(stage)
        for stage in bundle.pipeline_stages
        if str(stage.get("stage_name") or stage.get("trigger") or "").strip()
    }
    quality_scorecards = _fetch_quality_scorecards(request, run_id, bundle)
    return {
        "review_state": {
            "quality_loop_decisions": quality_loop_decisions,
            "iteration_counts": iteration_counts,
            "reviewer_findings": reviewer_findings,
            "quality_scorecards": quality_scorecards,
        }
    }


@router.get("/{run_id}/outputs")
async def get_run_outputs(run_id: str, request: Request) -> dict[str, Any]:
    bundle = _get_run_bundle(request, run_id)
    artifacts_by_id = {
        str(artifact.get("artifact_id") or ""): artifact
        for artifact in bundle.workflow_artifacts
        if str(artifact.get("artifact_id") or "").strip()
    }
    stages: dict[str, list[dict[str, Any]]] = {}
    for stage in bundle.pipeline_stages:
        stage_name = str(stage.get("stage_name") or stage.get("trigger") or "").strip()
        if not stage_name:
            continue
        artifact_summaries: list[dict[str, Any]] = []
        seen_artifact_ids: set[str] = set()
        for artifact_ref in _stage_output_artifacts(stage):
            artifact_id = str(artifact_ref.get("target_artifact_id") or "").strip()
            if not artifact_id or artifact_id in seen_artifact_ids:
                continue
            artifact = artifacts_by_id.get(artifact_id)
            if artifact is None:
                continue
            artifact_summaries.append(build_artifact_summary(artifact))
            seen_artifact_ids.add(artifact_id)
        if artifact_summaries:
            stages[stage_name] = artifact_summaries
    return {"stages": stages}


def _client_request_id(request: Request) -> str | None:
    value = (
        request.headers.get("X-Obra-Client-Request-Id", "").strip()
        or request.headers.get("X-Client-Request-Id", "").strip()
    )
    return value or None


def _get_run_bundle(request: Request, run_id: str) -> Any:
    repository = WorkflowStudioRepository.from_request(request)
    try:
        return repository.get_run_bundle(run_id)
    except SessionNotFoundError as exc:
        raise GatewayAPIError(
            error_code=RUN_NOT_FOUND,
            message=f"Workflow run {run_id} not found",
            status_code=404,
        ) from exc


def _stage_summary(stage: dict[str, Any]) -> dict[str, Any]:
    execution_status = stage.get("execution_status") or stage.get("status")
    return {
        "stage_name": str(stage.get("stage_name") or stage.get("trigger") or ""),
        "status": stage.get("status"),
        "runner_kind": stage.get("runner_kind"),
        "execution_status": execution_status,
        "duration_s": _stage_duration_s(stage),
        "iteration_count": _stage_iteration_count(stage),
        "reason_code": _stage_reason_code(stage, execution_status=execution_status),
    }


def _stage_iteration_count(stage: dict[str, Any]) -> int:
    try:
        return int(stage.get("iteration") or 0)
    except (TypeError, ValueError):
        return 0


def _stage_duration_s(stage: dict[str, Any]) -> float | None:
    last_result = stage.get("last_result")
    if isinstance(last_result, dict):
        duration = last_result.get("duration_s")
        if isinstance(duration, int | float):
            return float(duration)
        if isinstance(duration, str):
            try:
                return float(duration)
            except ValueError:
                pass
    started_at = _parse_datetime(stage.get("started_at"))
    completed_at = _parse_datetime(stage.get("completed_at"))
    if started_at is None or completed_at is None:
        return None
    return max((completed_at - started_at).total_seconds(), 0.0)


def _parse_datetime(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    normalized = value.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        return None


def _stage_output_artifacts(stage: dict[str, Any]) -> list[dict[str, Any]]:
    output_artifacts: list[dict[str, Any]] = []
    for field_name in (
        "stage_output_artifact_refs",
        "accepted_stage_output_artifact_refs",
        "candidate_stage_output_artifact_refs",
    ):
        raw_refs = stage.get(field_name)
        if not isinstance(raw_refs, list):
            continue
        for item in raw_refs:
            if isinstance(item, dict):
                output_artifacts.append(dict(item))
    return output_artifacts


def _stage_quality_loop_state(stage: dict[str, Any]) -> dict[str, Any] | None:
    payload = {
        "loop_state": stage.get("loop_state"),
        "loop_verdict": stage.get("loop_verdict"),
        "loop_signal": dict(stage.get("loop_signal") or {}),
        "pending_manual_reason": stage.get("pending_manual_reason"),
        "pending_manual_required_action": stage.get("pending_manual_required_action"),
    }
    if not any(value for value in payload.values()):
        return None
    return payload


def _stage_failure_detail(
    stage: dict[str, Any],
    *,
    execution_status: Any,
    quality_loop_state: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if str(execution_status or "").lower() not in {"failed", "error"}:
        return None
    last_result = stage.get("last_result")
    if not isinstance(last_result, dict):
        last_result = {}
    runner_metadata = last_result.get("metadata")
    if not isinstance(runner_metadata, dict):
        runner_metadata = {}
    loop_verdict = str((quality_loop_state or {}).get("loop_verdict") or "").strip().lower()
    return {
        "error_code": last_result.get("reason_code") or last_result.get("error_code"),
        "error_message": (
            str(last_result.get("error_message") or last_result.get("reason") or "").strip()
        ),
        "is_retryable": loop_verdict in {"retry_allowed", "revise_required"},
        "runner_metadata": runner_metadata,
    }


def _stage_reason_code(
    stage: dict[str, Any],
    *,
    execution_status: Any,
) -> str | None:
    if str(execution_status or "").lower() not in {"failed", "error"}:
        return None
    last_result = stage.get("last_result")
    if not isinstance(last_result, dict):
        last_result = {}
    reason_code = (
        last_result.get("reason_code")
        or last_result.get("error_code")
        or stage.get("outcome")
        or None
    )
    return str(reason_code) if reason_code is not None else None


def _event_timestamp(event: dict[str, Any], *, default: str) -> str:
    for key in ("timestamp", "created_at", "occurred_at", "updated_at"):
        value = event.get(key)
        if isinstance(value, str) and value:
            return value
    payload = event.get("payload")
    if isinstance(payload, dict):
        for key in ("timestamp", "created_at", "occurred_at", "updated_at"):
            value = payload.get(key)
            if isinstance(value, str) and value:
                return value
    return default


def _collect_quality_loop_decisions(bundle: Any) -> list[dict[str, Any]]:
    decisions: list[dict[str, Any]] = []
    for source_name, payload in (
        ("workflow_lifecycle_decisions", bundle.remote_session.get("workflow_lifecycle_decisions")),
        (
            "resume_context.lifecycle_decisions",
            _dict_value(bundle.remote_session.get("resume_context")).get("lifecycle_decisions"),
        ),
    ):
        if isinstance(payload, dict) and payload:
            decisions.append({"source": source_name, **dict(payload)})

    for stage in bundle.pipeline_stages:
        quality_loop_state = _stage_quality_loop_state(stage)
        if quality_loop_state is None:
            continue
        decisions.append(
            {
                "source": "pipeline_stage",
                "stage_name": stage.get("stage_name") or stage.get("trigger"),
                **quality_loop_state,
            }
        )

    for event in bundle.remote_events:
        payload = event.get("payload")
        if not isinstance(payload, dict):
            continue
        if any(key in payload for key in ("loop_verdict", "loop_state", "quality_decision")):
            decisions.append(
                {
                    "source": "remote_event",
                    "event_type": event.get("event_type") or event.get("type"),
                    "stage_name": payload.get("stage_name"),
                    **dict(payload),
                }
            )
    return decisions


def _collect_reviewer_findings(bundle: Any) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for event in bundle.remote_events:
        payload = event.get("payload")
        if not isinstance(payload, dict):
            payload = {}
        if isinstance(payload.get("reviewer_findings"), list):
            for finding in payload["reviewer_findings"]:
                if isinstance(finding, dict):
                    findings.append(
                        {
                            "source": "remote_event",
                            "event_type": event.get("event_type") or event.get("type"),
                            **dict(finding),
                        }
                    )
            continue
        if any(
            key in payload for key in ("review_feedback", "finding", "quality_verdict", "issues")
        ):
            findings.append(
                {
                    "source": "remote_event",
                    "event_type": event.get("event_type") or event.get("type"),
                    **dict(payload),
                }
            )
    return findings


def _fetch_quality_scorecards(request: Request, run_id: str, bundle: Any) -> list[dict[str, Any]]:
    candidate_item_ids = []
    seen_item_ids: set[str] = set()
    for event in bundle.remote_events:
        payload = event.get("payload")
        if not isinstance(payload, dict):
            payload = {}
        for raw_item_id in (event.get("item_id"), payload.get("item_id")):
            item_id = str(raw_item_id or "").strip()
            if not item_id or item_id in seen_item_ids:
                continue
            seen_item_ids.add(item_id)
            candidate_item_ids.append(item_id)

    if not candidate_item_ids:
        return []

    record = request.app.state.session_manager.get_session(run_id)
    hybrid_session_id = str(record.hybrid_session_id or "").strip()
    if not hybrid_session_id:
        return []

    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    client = client_factory() if callable(client_factory) else APIClient.from_config()
    scorecards = []
    for item_id in candidate_item_ids:
        try:
            payload = client.get_quality_scorecard(hybrid_session_id, item_id)
        except APIError as exc:
            raise GatewayAPIError.from_api_error(
                exc,
                default_error_code=QUALITY_SCORECARD_FETCH_FAILED,
                default_message=f"Failed to load quality scorecard for run {run_id}",
            ) from exc
        scorecards.append({"item_id": item_id, **dict(payload)})
    return scorecards


def _dict_value(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    return {}
