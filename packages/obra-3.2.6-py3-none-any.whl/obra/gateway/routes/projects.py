"""Workflow Studio project routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Request, status
from pydantic import BaseModel, ConfigDict, Field

from obra.api import APIClient
from obra.exceptions import APIError
from obra.gateway.errors import GatewayAPIError

router = APIRouter(prefix="/api/projects", tags=["workflow-studio"])


class CreateProjectRequest(BaseModel):
    """Request body for creating a project."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., min_length=1, max_length=256)
    working_dir: str = Field(..., min_length=1, max_length=4096)
    description: str = Field(default="", max_length=4096)
    domain_id: str | None = Field(default=None, max_length=128)


class UpdateProjectRequest(BaseModel):
    """Request body for updating a project."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, max_length=256)
    working_dir: str | None = Field(default=None, max_length=4096)
    domain_id: str | None = Field(default=None, max_length=128)


@router.get("/")
async def list_projects(request: Request) -> dict[str, Any]:
    """List projects plus the user's default selection."""
    client = _get_api_client(request)
    include_deleted = request.query_params.get("all", "false") == "true"
    try:
        payload = client.list_projects_with_selection(include_deleted=include_deleted)
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="project_list_failed",
            default_message="Failed to list projects",
        ) from exc

    projects = payload.get("projects")
    return {
        "projects": projects if isinstance(projects, list) else [],
        "default_project_id": payload.get("default_project_id"),
    }


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_project(body: CreateProjectRequest, request: Request) -> dict[str, Any]:
    """Create a project."""
    client = _get_api_client(request)
    try:
        project = client.create_project(
            name=body.name,
            working_dir=body.working_dir,
            description=body.description,
            domain_id=body.domain_id,
        )
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="project_create_failed",
            default_message="Failed to create project",
        ) from exc
    return {"project": project}


@router.get("/{project_id}")
async def get_project(project_id: str, request: Request) -> dict[str, Any]:
    """Get a project by id."""
    client = _get_api_client(request)
    try:
        project = client.get_project(project_id)
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="project_not_found",
            default_message=f"Failed to load project {project_id}",
        ) from exc
    return {"project": project}


@router.post("/{project_id}")
async def update_project(
    project_id: str,
    body: UpdateProjectRequest,
    request: Request,
) -> dict[str, Any]:
    """Update one project."""
    if body.name is None and body.working_dir is None and body.domain_id is None:
        raise GatewayAPIError(
            error_code="missing_field",
            message="No updates provided",
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    client = _get_api_client(request)
    try:
        project = client.update_project(
            project_id,
            name=body.name,
            working_dir=body.working_dir,
            domain_id=body.domain_id,
        )
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="project_update_failed",
            default_message=f"Failed to update project {project_id}",
        ) from exc
    return {"project": project}


@router.post("/{project_id}/select")
async def select_project(project_id: str, request: Request) -> dict[str, Any]:
    """Select the default project for the current user."""
    client = _get_api_client(request)
    try:
        return client.select_project(project_id)
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="project_select_failed",
            default_message=f"Failed to select project {project_id}",
        ) from exc


def _get_api_client(request: Request) -> APIClient:
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    if callable(client_factory):
        return client_factory()
    return APIClient.from_config()
