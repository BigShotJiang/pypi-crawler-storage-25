"""Onboarding API routes for desktop provider setup.

These endpoints live on the Studio browser-session surface (no global
bearer dependency) but require an active Studio browser session.
"""

from __future__ import annotations

from http import HTTPStatus
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

from obra.config.loaders import get_gateway_onboarding_config
from obra.gateway.providers.onboarding_state import OnboardingState
from obra.gateway.providers.registry import ProviderRegistry
from obra.gateway.studio_browser import (
    is_studio_browser_authenticated_request,
)

router = APIRouter(prefix="/api/onboarding", tags=["onboarding"])

# Module-level singletons (initialized lazily on first request).
_registry: ProviderRegistry | None = None
_onboarding_state: OnboardingState | None = None


def _get_registry() -> ProviderRegistry:
    global _registry
    if _registry is None:
        config = get_gateway_onboarding_config()
        _registry = ProviderRegistry(config.get("providers"))
    return _registry


def _get_state() -> OnboardingState:
    global _onboarding_state
    if _onboarding_state is None:
        _onboarding_state = OnboardingState()
    return _onboarding_state


def _require_session(request: Request) -> None:
    """Enforce an active Studio browser session."""
    if not is_studio_browser_authenticated_request(request):
        raise HTTPException(
            status_code=HTTPStatus.UNAUTHORIZED,
            detail="Studio browser session required",
        )


@router.get("/status")
async def onboarding_status(request: Request) -> JSONResponse:
    """Overall onboarding status with per-provider state and UI timing hints."""
    _require_session(request)

    config = get_gateway_onboarding_config()
    registry = _get_registry()
    state = _get_state()

    providers_status: dict[str, Any] = {}
    for provider in registry.list_providers():
        # Run live detection.
        try:
            detection_handler = registry.resolve_detection_handler(provider.provider_id)
            detection = detection_handler()
        except Exception:
            detection = {"installed": False}

        # Run live auth check via registry-resolved check handler.
        try:
            check_fn = registry.resolve_check_handler(provider.provider_id)
            auth_status = check_fn()
        except Exception:
            auth_status = {"authenticated": False, "auth_issue": "check_failed"}

        # Update persisted state based on live detection.
        if detection.get("installed"):
            state.mark_provider_installed(provider.provider_id)
        if auth_status.get("authenticated"):
            state.mark_provider_authenticated(provider.provider_id)

        providers_status[provider.provider_id] = {
            "installed": detection.get("installed", False),
            "authenticated": auth_status.get("authenticated", False),
            "auth_healthy": auth_status.get("authenticated", False),
            "auth_issue": auth_status.get("auth_issue"),
            "auth_method": provider.auth_method,
            "display_name": provider.display_name,
            "version": detection.get("version"),
            "path": detection.get("path"),
            "install_url": detection.get("install_url"),
            "install_command": detection.get("install_command"),
            # Ollama-specific sub-fields (passed through if present).
            **(
                {
                    "codex_installed": detection.get("codex_installed"),
                    "ollama_reachable": detection.get("ollama_reachable"),
                    "ollama_endpoint": detection.get("ollama_endpoint"),
                    "ollama_issue": detection.get("ollama_issue"),
                    "ollama_hint": detection.get("ollama_hint"),
                }
                if detection.get("codex_installed") is not None
                else {}
            ),
        }

    # Auto-complete onboarding when at least one provider is authenticated.
    any_authenticated = any(
        p.get("authenticated") for p in providers_status.values()
    ) if providers_status else False
    if any_authenticated and not state.is_completed():
        state.mark_completed()

    # UI timing hints (milliseconds for the web client).
    ui_timing = {
        "status_poll_interval_ms": config["status_poll_interval_s"] * 1000,
        "banner_poll_interval_ms": config["banner_poll_interval_s"] * 1000,
        "success_dwell_ms": config["success_dwell_s"] * 1000,
        "ready_retry_interval_ms": config["ready_retry_interval_s"] * 1000,
    }

    return JSONResponse(
        {
            "completed": state.is_completed(),
            "providers": providers_status,
            "ui_timing": ui_timing,
        }
    )


@router.get("/providers")
async def list_providers(request: Request) -> JSONResponse:
    """List available providers with metadata."""
    _require_session(request)

    registry = _get_registry()
    providers = []
    for p in registry.list_providers():
        # Quick detection check.
        try:
            handler = registry.resolve_detection_handler(p.provider_id)
            detection = handler()
        except Exception:
            detection = {"installed": False}

        providers.append(
            {
                "provider_id": p.provider_id,
                "display_name": p.display_name,
                "auth_method": p.auth_method,
                "installed": detection.get("installed", False),
                "install_url": p.install_url,
                "install_command": p.install_command,
            }
        )

    return JSONResponse({"providers": providers})


@router.post("/providers/{provider_id}/authenticate")
async def authenticate_provider(provider_id: str, request: Request) -> JSONResponse:
    """Trigger the provider's auth flow."""
    _require_session(request)

    config = get_gateway_onboarding_config()
    registry = _get_registry()

    try:
        auth_handler = registry.resolve_auth_handler(provider_id)
    except KeyError:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail=f"Unknown provider: {provider_id}",
        )

    result = auth_handler()

    return JSONResponse(
        {
            **result,
            "poll_endpoint": f"/api/onboarding/providers/{provider_id}/auth-status",
            "poll_interval_ms": config["status_poll_interval_s"] * 1000,
            "auth_timeout_s": config["auth_timeout_s"],
        }
    )


@router.get("/providers/{provider_id}/auth-status")
async def provider_auth_status(provider_id: str, request: Request) -> JSONResponse:
    """Check auth completion status for a provider."""
    _require_session(request)

    registry = _get_registry()
    provider = registry.get(provider_id)
    if not provider:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail=f"Unknown provider: {provider_id}",
        )

    # Resolve the check function via registry check_handler path.
    try:
        check_fn = registry.resolve_check_handler(provider_id)
        auth_status = check_fn()
    except Exception as e:
        auth_status = {"authenticated": False, "auth_issue": str(e)}

    # Update persisted state on success.
    if auth_status.get("authenticated"):
        state = _get_state()
        state.mark_provider_authenticated(provider_id)

    return JSONResponse(auth_status)


@router.post("/complete")
async def complete_onboarding(request: Request) -> JSONResponse:
    """Mark onboarding as complete."""
    _require_session(request)
    state = _get_state()
    state.mark_completed()
    return JSONResponse({"completed": True})
