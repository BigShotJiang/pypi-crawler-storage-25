"""Session-level helper functions extracted from session_manager.py."""

from __future__ import annotations

import json
import logging
import threading
import uuid
from collections.abc import Callable
from contextlib import contextmanager
from pathlib import Path
from typing import TYPE_CHECKING, Any
from unittest.mock import patch

from obra.core.interrupts import GracefulInterrupt

if TYPE_CHECKING:
    from obra.gateway.session_manager import SessionRecord

logger = logging.getLogger(__name__)


def _validate_working_dir(working_dir: str, allowed_base: Path) -> Path:
    """Validate that the working directory resolves under the configured base path."""
    resolved = Path(working_dir).expanduser().resolve()
    allowed_base_resolved = allowed_base.resolve()
    if not resolved.is_relative_to(allowed_base_resolved):
        raise ValueError(f"working_dir must be within {allowed_base}")
    return resolved


def _make_cancel_aware_callback(
    cancel_event: threading.Event,
    original_callback: Callable[[str, dict], None],
) -> Callable[[str, dict], None]:
    """Wrap progress callbacks with per-session cancellation checks."""

    def _wrapped(action: str, payload: dict) -> None:
        if cancel_event.is_set():
            raise GracefulInterrupt("session_cancelled")
        original_callback(action, payload)

    return _wrapped


def _session_ref(record: SessionRecord, fallback_session_id: str) -> str:
    """Return the best available string session reference for emitted payloads."""
    hybrid_session_id = record.hybrid_session_id
    if isinstance(hybrid_session_id, str) and hybrid_session_id:
        return hybrid_session_id
    return fallback_session_id


def _new_derivation_id() -> str:
    return f"drv_{uuid.uuid4().hex[:12]}"


def _stable_payload_fingerprint(payload: dict[str, Any]) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)


def _extract_derivation_id(payload: dict[str, Any]) -> str | None:
    if not isinstance(payload, dict):
        return None
    direct = _string_or_none(payload.get("derivation_id"))
    if direct is not None:
        return direct
    state = payload.get("workflow_derivation_state")
    if isinstance(state, dict):
        return _string_or_none(state.get("derivation_id"))
    return None


def _string_or_none(value: Any) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None


def _resolve_gateway_workflow_metadata_domain(
    plan_context: dict[str, Any] | None,
) -> str | None:
    """Read the explicit workflow-backed domain without request override rewriting."""
    if not isinstance(plan_context, dict):
        return None
    workflow_definition = (
        plan_context.get("workflow_definition")
        if isinstance(plan_context.get("workflow_definition"), dict)
        else {}
    )
    workflow_source_summary = (
        plan_context.get("workflow_source_summary")
        if isinstance(plan_context.get("workflow_source_summary"), dict)
        else {}
    )
    workflow_source_artifact = (
        plan_context.get("workflow_source_artifact")
        if isinstance(plan_context.get("workflow_source_artifact"), dict)
        else {}
    )
    return (
        _string_or_none(workflow_definition.get("domain_id"))
        or _string_or_none(workflow_source_summary.get("domain_id"))
        or _string_or_none(workflow_source_artifact.get("domain_id"))
        or _string_or_none(plan_context.get("domain_id"))
    )


def _resolve_gateway_derivation_metadata_domain(
    request_payload: dict[str, Any] | None,
) -> str | None:
    """Read explicit workflow metadata domains embedded in derivation requests."""
    if not isinstance(request_payload, dict):
        return None
    workflow_source_summary = (
        request_payload.get("workflow_source_summary")
        if isinstance(request_payload.get("workflow_source_summary"), dict)
        else {}
    )
    workflow_source_artifact = (
        request_payload.get("workflow_source_artifact")
        if isinstance(request_payload.get("workflow_source_artifact"), dict)
        else {}
    )
    baseline_workflow_ref = (
        request_payload.get("baseline_workflow_ref")
        if isinstance(request_payload.get("baseline_workflow_ref"), dict)
        else {}
    )
    baseline_metadata = (
        baseline_workflow_ref.get("metadata")
        if isinstance(baseline_workflow_ref.get("metadata"), dict)
        else {}
    )
    return (
        _string_or_none(workflow_source_summary.get("domain_id"))
        or _string_or_none(workflow_source_artifact.get("domain_id"))
        or _string_or_none(baseline_workflow_ref.get("domain_id"))
        or _string_or_none(baseline_metadata.get("domain_id"))
    )


@contextmanager
def _gateway_noninteractive_stdio():
    """Gateway-owned runs must never depend on the server's controlling TTY."""
    with (
        patch("sys.stdin.isatty", return_value=False),
        patch("sys.stdout.isatty", return_value=False),
    ):
        yield
