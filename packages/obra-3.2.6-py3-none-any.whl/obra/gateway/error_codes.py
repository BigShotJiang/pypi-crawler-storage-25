"""Canonical gateway route error-code constants."""

from __future__ import annotations

from http import HTTPStatus
from typing import Any

ARTIFACT_CONTENT_NOT_FOUND = "artifact_content_not_found"
ARTIFACT_NOT_FOUND = "artifact_not_found"
AUTHENTICATION_FAILED = "authentication_failed"
AUTHENTICATION_REQUIRED = "authentication_required"
AUTOMATION_DERIVATION_NOT_FOUND = "automation_derivation_not_found"
AUTOMATION_RUN_NOT_FOUND = "automation_run_not_found"
CALLBACK_NOT_FOUND = "callback_not_found"
CONFLICT = "conflict"
DOCUMENT_NOT_FOUND = "document_not_found"
IDEMPOTENCY_KEY_REQUIRED = "idempotency_key_required"
INVALID_REQUEST = "invalid_request"
PIPELINE_NOT_FOUND = "pipeline_not_found"
QUALITY_SCORECARD_FETCH_FAILED = "quality_scorecard_fetch_failed"
RUNNER_NOT_FOUND = "runner_not_found"
RUN_NOT_FOUND = "run_not_found"
SOURCE_THREAD_NOT_FOUND = "source_thread_not_found"
STAGE_NOT_FOUND = "stage_not_found"
STUDIO_BROWSER_SESSION_REQUIRED = "studio_browser_session_required"
STUDIO_TOKEN_REQUIRED = "studio_token_required"
TEMPLATE_ASSET_NOT_FOUND = "template_asset_not_found"
THREAD_NOT_FOUND = "thread_not_found"
TURN_NOT_FOUND = "turn_not_found"
VALIDATION_ERROR = "validation_error"
WEBHOOK_NOT_FOUND = "webhook_not_found"
WORKFLOW_DERIVATION_NOT_FOUND = "workflow_derivation_not_found"
WORKFLOW_NOT_FOUND = "workflow_not_found"
WORKFLOW_REVISION_NOT_FOUND = "workflow_revision_not_found"
WORKING_DIRECTORY_NOT_ALLOWED = "working_directory_not_allowed"

_MESSAGE_TO_ERROR_CODE = {
    "Artifact not found": ARTIFACT_NOT_FOUND,
    "Artifact content not found": ARTIFACT_CONTENT_NOT_FOUND,
    "Authentication failed": AUTHENTICATION_FAILED,
    "Authentication required": AUTHENTICATION_REQUIRED,
    "Automation derivation not found": AUTOMATION_DERIVATION_NOT_FOUND,
    "Automation run not found": AUTOMATION_RUN_NOT_FOUND,
    "Callback not found": CALLBACK_NOT_FOUND,
    "Document not found": DOCUMENT_NOT_FOUND,
    "Idempotency-Key header is required": IDEMPOTENCY_KEY_REQUIRED,
    "Pipeline not found": PIPELINE_NOT_FOUND,
    "Runner not found": RUNNER_NOT_FOUND,
    "Source thread not found": SOURCE_THREAD_NOT_FOUND,
    "Stage not found": STAGE_NOT_FOUND,
    "Studio browser session required": STUDIO_BROWSER_SESSION_REQUIRED,
    "Template asset not found": TEMPLATE_ASSET_NOT_FOUND,
    "Thread not found": THREAD_NOT_FOUND,
    "Turn not found": TURN_NOT_FOUND,
    "Valid bearer token is required": STUDIO_TOKEN_REQUIRED,
    "Webhook not found": WEBHOOK_NOT_FOUND,
    "Workflow derivation not found": WORKFLOW_DERIVATION_NOT_FOUND,
    "Workflow revision not found": WORKFLOW_REVISION_NOT_FOUND,
    "Workflow not found": WORKFLOW_NOT_FOUND,
    "Workflow run not found": RUN_NOT_FOUND,
    "Working directory not allowed": WORKING_DIRECTORY_NOT_ALLOWED,
}


def infer_gateway_error_code(
    detail: Any,
    *,
    status_code: int,
) -> str:
    """Infer the canonical gateway error code for a raw HTTPException detail."""
    if isinstance(detail, dict):
        if isinstance(detail.get("error_code"), str) and detail["error_code"].strip():
            return detail["error_code"].strip()
        if isinstance(detail.get("code"), str) and detail["code"].strip():
            return detail["code"].strip()
        if isinstance(detail.get("error"), str) and detail["error"].strip():
            return str(detail["error"]).strip().lower().replace(" ", "_")
    message = str(detail or "").strip()
    if message in _MESSAGE_TO_ERROR_CODE:
        return _MESSAGE_TO_ERROR_CODE[message]
    if status_code == HTTPStatus.NOT_FOUND:
        return INVALID_REQUEST if not message else f"{message.lower().replace(' ', '_')}"
    if status_code == HTTPStatus.UNAUTHORIZED:
        return AUTHENTICATION_FAILED
    if status_code == HTTPStatus.CONFLICT:
        return CONFLICT
    if status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        return VALIDATION_ERROR
    return INVALID_REQUEST
