from __future__ import annotations
"""
qpop.core - Core popup function module

Provides the main QPop function for displaying popup notifications.
"""


from PyQt6.QtWidgets import QApplication
from rbpop.win.popped import PopWin

from qwork.qpop.manager import QPopManager


def QPop(pop_win_inst: PopWin) -> None:
    """
    Global function: Add popup to manager and display

    This is the main API for qpop, wrapping rbpop's functionality
    with qwork-style naming.

    Requires QApplication instance to exist.

    Args:
        pop_win_inst: PopWin instance to display

    Raises:
        RuntimeError: If QApplication instance doesn't exist

    Example:
        >>> from PyQt6.QtWidgets import QApplication
        >>> from qwork.qpop import QPop, QPInfo
        >>> app = QApplication([])
        >>> QPop(QPInfo("Hello World!"))
    """
    _app = QApplication.instance()
    if _app is None:
        raise RuntimeError("QApplication instance required, please create QApplication first")

    _manager = QPopManager.GetInstance()
    _manager.AddWindow(pop_win_inst)
