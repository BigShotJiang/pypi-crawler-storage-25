from __future__ import annotations
"""
qpop - Pop notification module for qwork

A wrapper around rbpop providing simplified and unified API
for desktop popup notifications with PyQt6.

Naming Convention:
- Functions: PascalCase
- Methods: camelCase
- Internal: _prefix
- Constants: UPPER_CASE
"""


# Import from rbpop
from rbpop.win.popped import PopWin
from rbpop.prefab.message import QPMsg, QPInfo, QPWarn, QPError

# Import from submodules
from qwork.qpop.manager import QPopManager
from qwork.qpop.builder import PopBuilder
from qwork.qpop.core import QPop
from qwork.qpop.shortcut import PopInfo, PopWarn, PopError

# Constants
QPOP_COLOR_INFO = "rgb(140, 190, 122)"
QPOP_COLOR_WARN = "rgb(195, 185, 72)"
QPOP_COLOR_ERROR = "rgb(190, 140, 122)"

QPOP_DEFAULT_SIZE = (360, 120)
QPOP_DEFAULT_CT = 4000  # milliseconds

__all__ = [
    # Core classes from rbpop
    'PopWin',
    'QPMsg',
    'QPInfo',
    'QPWarn',
    'QPError',
    # Core function
    'QPop',
    # Manager
    'QPopManager',
    # Builder
    'PopBuilder',
    # Shortcut functions
    'PopInfo',
    'PopWarn',
    'PopError',
    # Constants
    'QPOP_COLOR_INFO',
    'QPOP_COLOR_WARN',
    'QPOP_COLOR_ERROR',
    'QPOP_DEFAULT_SIZE',
    'QPOP_DEFAULT_CT',
]
