"""
qpop demo - 弹窗通知模块演示

展示 qpop 的各种功能和用法。
运行: python demo_qpop.py
"""

import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget
from PyQt6.QtCore import Qt

from qwork import (
    PopInfo, PopWarn, PopError,
    PopBuilder, QPop, QPInfo
)


class QPopDemo(QMainWindow):
    """qpop 演示窗口"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("qpop Demo - 弹窗通知演示")
        self.setGeometry(100, 100, 400, 500)

        # 中央控件
        _central = QWidget()
        self.setCentralWidget(_central)

        # 布局
        _layout = QVBoxLayout(_central)
        _layout.setSpacing(15)
        _layout.setContentsMargins(30, 30, 30, 30)

        # 标题
        _title = QPushButton("=== qpop 弹窗演示 ===")
        _title.setEnabled(False)
        _title.setStyleSheet("font-size: 18px; font-weight: bold; padding: 10px;")
        _layout.addWidget(_title)

        _layout.addSpacing(20)

        # 1. 快捷函数演示
        _section1 = QPushButton("【1】快捷函数 - 最简单用法")
        _section1.setEnabled(False)
        _section1.setStyleSheet("background-color: #f0f0f0; padding: 8px;")
        _layout.addWidget(_section1)

        _btn1 = QPushButton("PopInfo - 信息提示")
        _btn1.setStyleSheet("background-color: rgb(140, 190, 122); padding: 10px;")
        _btn1.clicked.connect(self._onInfo)
        _layout.addWidget(_btn1)

        _btn2 = QPushButton("PopWarn - 警告提示")
        _btn2.setStyleSheet("background-color: rgb(195, 185, 72); padding: 10px;")
        _btn2.clicked.connect(self._onWarn)
        _layout.addWidget(_btn2)

        _btn3 = QPushButton("PopError - 错误提示")
        _btn3.setStyleSheet("background-color: rgb(190, 140, 122); padding: 10px;")
        _btn3.clicked.connect(self._onError)
        _layout.addWidget(_btn3)

        _layout.addSpacing(20)

        # 2. Builder 模式演示
        _section2 = QPushButton("【2】Builder 模式 - 最灵活")
        _section2.setEnabled(False)
        _section2.setStyleSheet("background-color: #f0f0f0; padding: 8px;")
        _layout.addWidget(_section2)

        _btn4 = QPushButton("完整配置弹窗")
        _btn4.setStyleSheet("padding: 10px;")
        _btn4.clicked.connect(self._onBuilderFull)
        _layout.addWidget(_btn4)

        _btn5 = QPushButton("带关闭按钮的弹窗")
        _btn5.setStyleSheet("padding: 10px;")
        _btn5.clicked.connect(self._onBuilderClose)
        _layout.addWidget(_btn5)

        _btn6 = QPushButton("自定义样式弹窗")
        _btn6.setStyleSheet("padding: 10px;")
        _btn6.clicked.connect(self._onBuilderStyle)
        _layout.addWidget(_btn6)

        _layout.addSpacing(20)

        # 3. 批量演示
        _section3 = QPushButton("【3】批量演示 - 队列效果")
        _section3.setEnabled(False)
        _section3.setStyleSheet("background-color: #f0f0f0; padding: 8px;")
        _layout.addWidget(_section3)

        _btn7 = QPushButton("连续弹出 5 个弹窗（展示队列管理）")
        _btn7.setStyleSheet("background-color: #e0e8ff; padding: 10px;")
        _btn7.clicked.connect(self._onBatch)
        _layout.addWidget(_btn7)

        _layout.addStretch()

        # 退出按钮
        _btnExit = QPushButton("退出演示")
        _btnExit.setStyleSheet("background-color: #ffcccc; padding: 10px;")
        _btnExit.clicked.connect(self.close)
        _layout.addWidget(_btnExit)

    # ====================
    # 快捷函数演示
    # ====================

    def _onInfo(self):
        """信息提示"""
        PopInfo("这是一条信息提示", "Info")

    def _onWarn(self):
        """警告提示"""
        PopWarn("这是一个警告", "Warning", ct=6000)

    def _onError(self):
        """错误提示"""
        PopError("这是一个错误", "Error", ct=8000)

    # ====================
    # Builder 模式演示
    # ====================

    def _onBuilderFull(self):
        """完整配置"""
        PopBuilder()\
            .SetTitle("下载完成")\
            .SetMessage("文件已成功下载并保存")\
            .SetCt(5000)\
            .Info()\
            .Show()

    def _onBuilderClose(self):
        """带关闭按钮"""
        PopBuilder()\
            .SetTitle("新消息")\
            .SetMessage("您收到 3 条新消息")\
            .EnableCloseButton(True)\
            .SetCt(10000)\
            .Info()\
            .Show()

    def _onBuilderStyle(self):
        """自定义样式"""
        PopBuilder()\
            .SetTitle("严重错误")\
            .SetTitleStyle("color:red;font-size:16px")\
            .SetMessage("无法连接到服务器，请检查网络")\
            .SetMsgStyle("color:#333;font-weight:bold")\
            .EnableCloseButton(True)\
            .SetCt(8000)\
            .Error()\
            .Show()

    # ====================
    # 批量演示
    # ====================

    def _onBatch(self):
        """批量弹出"""
        for i in range(5):
            _types = [PopInfo, PopWarn, PopError]
            _msgs = [
                f"任务 {i+1} 完成",
                f"任务 {i+1} 需要关注",
                f"任务 {i+1} 失败"
            ]
            _titles = ["Info", "Warn", "Error"]

            _types[i % 3](_msgs[i % 3], _titles[i % 3], ct=4000 + i * 1000)


def main():
    app = QApplication(sys.argv)

    # 检查 QApplication（qpop 需要）
    print(f"QApplication 实例: {QApplication.instance()}")

    # 创建演示窗口
    demo = QPopDemo()
    demo.show()

    # 显示欢迎弹窗
    PopBuilder()\
        .SetTitle("欢迎使用 qpop")\
        .SetMessage("点击按钮查看不同弹窗效果")\
        .SetCt(5000)\
        .Info()\
        .Show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
