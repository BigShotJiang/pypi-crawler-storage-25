from __future__ import annotations
"""
qpop.shortcut - Quick popup creation functions

Provides convenience functions for quick popup notifications.
"""


from rbpop.win.popped import PopWin
from rbpop.prefab.message import QPInfo, QPWarn, QPError

from qwork.qpop.manager import QPopManager


# Constants
DEFAULT_CT = 4000


def PopInfo(msg: str, title: str | None = None, ct: int = DEFAULT_CT, **kwargs) -> PopWin:
    """
    Quick create and show info popup

    Args:
        msg: Message content
        title: Optional title
        ct: Display duration in milliseconds
        **kwargs: Additional options (close, size, etc.)

    Returns:
        PopWin: The created popup instance
    """
    _pop = QPInfo(msg=msg, title=title, ct=ct, **kwargs)
    _manager = QPopManager.GetInstance()
    _manager.AddWindow(_pop)
    return _pop


def PopWarn(msg: str, title: str | None = None, ct: int = DEFAULT_CT, **kwargs) -> PopWin:
    """
    Quick create and show warning popup

    Args:
        msg: Message content
        title: Optional title
        ct: Display duration in milliseconds
        **kwargs: Additional options (close, size, etc.)

    Returns:
        PopWin: The created popup instance
    """
    _pop = QPWarn(msg=msg, title=title, ct=ct, **kwargs)
    _manager = QPopManager.GetInstance()
    _manager.AddWindow(_pop)
    return _pop


def PopError(msg: str, title: str | None = None, ct: int = DEFAULT_CT, **kwargs) -> PopWin:
    """
    Quick create and show error popup

    Args:
        msg: Message content
        title: Optional title
        ct: Display duration in milliseconds
        **kwargs: Additional options (close, size, etc.)

    Returns:
        PopWin: The created popup instance
    """
    _pop = QPError(msg=msg, title=title, ct=ct, **kwargs)
    _manager = QPopManager.GetInstance()
    _manager.AddWindow(_pop)
    return _pop
