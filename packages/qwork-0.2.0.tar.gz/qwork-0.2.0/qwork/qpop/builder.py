from __future__ import annotations
"""
qpop.builder - Fluent builder for popup notifications

Provides chainable API for configuring and showing popups.
"""


from typing import Self, Any

from rbpop.win.popped import PopWin
from rbpop.prefab.message import QPMsg, QPInfo, QPWarn, QPError

from qwork.qpop.manager import QPopManager


class PopBuilder:
    """
    Fluent builder for creating popup notifications

    Provides chainable API for configuring and showing popups.

    Usage:
        PopBuilder().SetTitle("Hello").SetMessage("World").Info().Show()
        PopBuilder().SetMessage("Simple message").Warn().Show()
        PopBuilder().SetMessage("Error!").SetCt(8000).Error().Show()
    """

    # Default values as class constants
    DEFAULT_CT = 4000
    DEFAULT_SLIDE_DURATION = 800
    DEFAULT_SIZE = (360, 120)

    def __init__(self) -> None:
        """Initialize builder with defaults"""
        self._title: str | None = None
        self._message: str = ""
        self._ct: int = self.DEFAULT_CT
        self._msg_style: str | None = None
        self._title_style: str | None = None
        self._close_btn: bool = False
        self._slide_in: bool = True
        self._slide_duration: int = self.DEFAULT_SLIDE_DURATION
        self._size: tuple[int, int] | None = None
        self._type: str = "info"

    def SetTitle(self, title: str | None) -> Self:
        """Set popup title"""
        self._title = title
        return self

    def SetMessage(self, message: str) -> Self:
        """Set popup message (required)"""
        self._message = message
        return self

    def SetCt(self, ct: int) -> Self:
        """Set display duration in milliseconds"""
        self._ct = ct
        return self

    def SetMsgStyle(self, style: str) -> Self:
        """Set message CSS style"""
        self._msg_style = style
        return self

    def SetTitleStyle(self, style: str) -> Self:
        """Set title CSS style"""
        self._title_style = style
        return self

    def EnableCloseButton(self, enable: bool = True) -> Self:
        """Enable/disable close button"""
        self._close_btn = enable
        return self

    def SetSlideIn(self, enable: bool, duration: int = 800) -> Self:
        """Configure slide-in animation"""
        self._slide_in = enable
        self._slide_duration = duration
        return self

    def SetSize(self, width: int, height: int) -> Self:
        """Set popup window size"""
        self._size = (width, height)
        return self

    def Info(self) -> Self:
        """Set as info type (green background)"""
        self._type = "info"
        return self

    def Warn(self) -> Self:
        """Set as warning type (yellow background)"""
        self._type = "warn"
        return self

    def Error(self) -> Self:
        """Set as error type (red background)"""
        self._type = "error"
        return self

    def Build(self) -> PopWin:
        """Build the popup window instance"""
        _kwargs: dict[str, Any] = {
            "slide_in": self._slide_in,
            "slide_duration": self._slide_duration,
        }
        if self._size:
            _kwargs["size"] = self._size

        _common_args = {
            "msg": self._message,
            "title": self._title,
            "ct": self._ct,
            "msg_style": self._msg_style,
            "title_style": self._title_style,
            "close": self._close_btn,
        }

        if self._type == "info":
            return QPInfo(**_common_args, **_kwargs)
        elif self._type == "warn":
            return QPWarn(**_common_args, **_kwargs)
        elif self._type == "error":
            return QPError(**_common_args, **_kwargs)
        else:
            return QPMsg(**_common_args, **_kwargs)

    def Show(self) -> PopWin:
        """Build and show the popup window"""
        _pop = self.Build()
        _manager = QPopManager.GetInstance()
        _manager.AddWindow(_pop)
        return _pop
