from __future__ import annotations
"""
qpop.manager - Popup window manager module

Provides QPopManager with qwork-style naming conventions.
"""


from typing import Self

from rbpop.win.popped import PopWin
from rbpop.win.manager import WinManager as _RbWinManager


class QPopManager:
    """
    Popup window manager with qwork-style naming

    Wraps rbpop's WinManager with PascalCase method names
    and simplified API.

    Usage:
        manager = QPopManager.GetInstance()
        manager.AddWindow(pop_win)
    """

    _instance: QPopManager | None = None

    def __init__(self) -> None:
        """Initialize manager wrapper"""
        self._manager = _RbWinManager.get_instance()

    @classmethod
    def GetInstance(cls) -> Self:
        """Get global singleton instance"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def AddWindow(self, win: PopWin) -> None:
        """Add popup window to manager"""
        self._manager.add_window(win)

    def RemoveWindow(self, win: PopWin) -> bool:
        """Remove popup window from manager"""
        return self._manager.remove_window(win)

    def HideAll(self) -> None:
        """Hide all popup windows"""
        self._manager.hide_all_windows()

    def ShowAll(self) -> None:
        """Show all popup windows"""
        self._manager.show_all_windows()

    def GetWindowCount(self) -> int:
        """Get number of active windows"""
        return self._manager.get_window_count()

    def IsEmpty(self) -> bool:
        """Check if no active windows"""
        return self._manager.is_empty()

    def ClearAll(self) -> None:
        """Close all popup windows"""
        for win in self._manager._win_list[:]:
            win.close()
        self._manager._win_list.clear()
        self._manager._pending_queue.clear()
