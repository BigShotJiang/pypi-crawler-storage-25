"""
缩略图滑块进度条
提供代码缩略图和快速导航功能
"""

from PyQt6.QtCore import QSize


from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QScrollArea, QFrame, 
    QGraphicsView, QGraphicsScene, QGraphicsTextItem,
    QApplication
)
from PyQt6.QtCore import (
    Qt, QRect, QRectF, QPoint, QPointF, 
    pyqtSignal, QTimer
)
from PyQt6.QtGui import (
    QPainter, QColor, QFont, QFontMetrics, 
    QMouseEvent, QWheelEvent, QPaintEvent,
    QTextDocument, QTextCursor, QTextCharFormat
)
from typing import Optional, Callable


class MinimapWidget(QWidget):
    """代码缩略图控件"""
    
    # 信号
    clicked = pyqtSignal(int)  # 点击位置对应的行号
    viewport_changed = pyqtSignal(float, float)  # 视口改变 (start_ratio, end_ratio)
    
    # 颜色配置（浅色主题）
    COLORS = {
        'background': '#f5f5f5',
        'text': '#666666',
        'keyword': '#0000ff',
        'string': '#008000',
        'comment': '#808080',
        'function': '#795e26',
        'class': '#267f99',
        'number': '#098658',
        'viewport': '#5a9bd5',
        'viewport_border': '#4a8bc5',
    }
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self._code: str = ""
        self._lines: list = []
        self._line_count: int = 0
        
        # 缩略图比例
        self._scale: float = 0.15
        self._line_height: int = 2  # 每行高度（像素）
        self._char_width: float = 1.2  # 字符宽度
        
        # 视口位置
        self._viewport_start: float = 0.0  # 0.0 - 1.0
        self._viewport_end: float = 1.0    # 0.0 - 1.0
        
        # 拖拽状态
        self._dragging: bool = False
        self._drag_start_y: int = 0
        self._drag_start_viewport: float = 0.0
        
        # 设置固定宽度
        self.setFixedWidth(120)
        self.setMinimumHeight(100)
        
        # 启用鼠标跟踪
        self.setMouseTracking(True)
        
        # 设置背景色
        self.setStyleSheet(f"background-color: {self.COLORS['background']};")
    
    def set_code(self, code: str):
        """设置代码"""
        self._code = code
        self._lines = code.split('\n') if code else []
        self._line_count = len(self._lines)
        self.update()
    
    def set_scale(self, scale: float):
        """设置缩放比例"""
        self._scale = max(0.05, min(0.5, scale))
        self.update()
    
    def set_viewport(self, start_ratio: float, end_ratio: float):
        """设置视口位置"""
        self._viewport_start = max(0.0, min(1.0, start_ratio))
        self._viewport_end = max(0.0, min(1.0, end_ratio))
        self.update()
    
    def set_viewport_by_lines(self, first_visible: int, last_visible: int, total_lines: int):
        """通过行号设置视口"""
        if total_lines > 0:
            self._viewport_start = first_visible / total_lines
            self._viewport_end = (last_visible + 1) / total_lines
            self.update()
    
    def paintEvent(self, event: QPaintEvent):
        """绘制事件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        
        # 绘制背景
        painter.fillRect(self.rect(), QColor(self.COLORS['background']))
        
        if not self._lines:
            return
        
        # 计算绘制参数
        widget_height = self.height()
        content_height = self._line_count * self._line_height
        
        # 如果内容太高，需要缩放
        if content_height > widget_height:
            scale_y = widget_height / content_height
        else:
            scale_y = 1.0
        
        # 绘制代码行
        painter.setPen(QColor(self.COLORS['text']))
        painter.setFont(QFont('Consolas', 2))
        
        for i, line in enumerate(self._lines):
            y = int(i * self._line_height * scale_y)
            
            # 绘制行（简化处理，只显示部分字符）
            display_line = line[:80]  # 限制行长度
            if display_line.strip():
                # 简单的语法高亮
                self._draw_line(painter, display_line, 2, y, scale_y)
        
        # 绘制视口指示器
        self._draw_viewport(painter, scale_y)
        
        painter.end()
    
    def _draw_line(self, painter: QPainter, line: str, x: int, y: int, scale_y: float):
        """绘制单行代码（简化语法高亮）"""
        # 简单的关键字检测
        stripped = line.strip()
        
        # 根据行类型选择颜色
        color = self.COLORS['text']
        if stripped.startswith('#'):
            color = self.COLORS['comment']
        elif stripped.startswith('class '):
            color = self.COLORS['class']
        elif stripped.startswith('def '):
            color = self.COLORS['function']
        elif stripped.startswith(('import ', 'from ')):
            color = self.COLORS['keyword']
        elif any(kw in stripped for kw in ['return', 'if', 'for', 'while', 'with', 'try']):
            color = self.COLORS['keyword']
        
        painter.setPen(QColor(color))
        
        # 绘制文本（限制长度）
        display_text = line[:50].replace('\t', ' ')
        painter.drawText(x, y + int(self._line_height * scale_y) - 1, display_text)
    
    def _draw_viewport(self, painter: QPainter, scale_y: float):
        """绘制视口指示器"""
        widget_height = self.height()
        
        # 计算视口矩形
        viewport_y = int(self._viewport_start * self._line_count * self._line_height * scale_y)
        viewport_height = int((self._viewport_end - self._viewport_start) * 
                              self._line_count * self._line_height * scale_y)
        
        # 限制在widget内
        viewport_y = max(0, min(viewport_y, widget_height - 10))
        viewport_height = max(10, min(viewport_height, widget_height - viewport_y))
        
        # 绘制视口背景
        viewport_rect = QRect(0, viewport_y, self.width(), viewport_height)
        painter.fillRect(viewport_rect, QColor(self.COLORS['viewport']))
        
        # 绘制视口边框
        painter.setPen(QColor(self.COLORS['viewport_border']))
        painter.drawRect(viewport_rect)
    
    def mousePressEvent(self, event: QMouseEvent):
        """鼠标按下事件"""
        if event.button() == Qt.MouseButton.LeftButton:
            self._dragging = True
            self._drag_start_y = event.pos().y()
            self._drag_start_viewport = self._viewport_start
            
            # 计算点击位置对应的行号
            line = self._get_line_at_y(event.pos().y())
            self.clicked.emit(line)
    
    def mouseMoveEvent(self, event: QMouseEvent):
        """鼠标移动事件"""
        if self._dragging:
            # 计算拖拽偏移
            delta_y = event.pos().y() - self._drag_start_y
            widget_height = self.height()
            
            # 转换为视口比例偏移
            if self._line_count > 0:
                delta_ratio = delta_y / (self._line_count * self._line_height)
                new_start = self._drag_start_viewport + delta_ratio
                new_start = max(0.0, min(1.0 - (self._viewport_end - self._viewport_start), new_start))
                
                viewport_size = self._viewport_end - self._viewport_start
                self._viewport_start = new_start
                self._viewport_end = new_start + viewport_size
                
                self.viewport_changed.emit(self._viewport_start, self._viewport_end)
                self.update()
    
    def mouseReleaseEvent(self, event: QMouseEvent):
        """鼠标释放事件"""
        if event.button() == Qt.MouseButton.LeftButton:
            self._dragging = False
    
    def wheelEvent(self, event: QWheelEvent):
        """滚轮事件"""
        # 根据滚轮滚动调整视口
        delta = event.angleDelta().y()
        scroll_step = 0.05
        
        if delta > 0:
            # 向上滚动
            new_start = max(0.0, self._viewport_start - scroll_step)
            viewport_size = self._viewport_end - self._viewport_start
            self._viewport_start = new_start
            self._viewport_end = new_start + viewport_size
        else:
            # 向下滚动
            viewport_size = self._viewport_end - self._viewport_start
            new_start = min(1.0 - viewport_size, self._viewport_start + scroll_step)
            self._viewport_start = new_start
            self._viewport_end = new_start + viewport_size
        
        self.viewport_changed.emit(self._viewport_start, self._viewport_end)
        self.update()
    
    def _get_line_at_y(self, y: int) -> int:
        """获取指定y坐标对应的行号"""
        widget_height = self.height()
        content_height = self._line_count * self._line_height
        
        if content_height > widget_height:
            scale_y = widget_height / content_height
        else:
            scale_y = 1.0
        
        line = int(y / (self._line_height * scale_y))
        return max(0, min(line, self._line_count - 1))
    
    def get_preferred_height(self) -> int:
        """获取首选高度"""
        return max(100, int(self._line_count * self._line_height * self._scale))


class MinimapSlider(QWidget):
    """缩略图滑块 - 类似PyCharm的右侧进度条"""
    
    # 信号
    position_changed = pyqtSignal(float)  # 位置改变信号 (0.0 - 1.0)
    
    # 颜色配置
    COLORS = {
        'background': '#f0f0f0',
        'track': '#e0e0e0',
        'thumb': '#5a9bd5',
        'thumb_hover': '#4a8bc5',
        'thumb_border': '#3a7bb5',
        'highlight': '#ff8c00',
    }
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self._value: float = 0.0  # 当前值 (0.0 - 1.0)
        self._thumb_height: int = 50  # 滑块高度
        self._thumb_ratio: float = 0.1  # 滑块高度比例
        self._dragging: bool = False
        self._hover: bool = False
        self._drag_start_y: int = 0
        self._drag_start_value: float = 0.0
        
        # 设置固定宽度
        self.setFixedWidth(15)
        self.setMinimumHeight(100)
        
        # 启用鼠标跟踪
        self.setMouseTracking(True)
        
        # 设置样式
        self.setStyleSheet(f"background-color: {self.COLORS['background']};")
    
    def set_value(self, value: float):
        """设置当前值"""
        self._value = max(0.0, min(1.0, value))
        self.update()
    
    def set_thumb_ratio(self, ratio: float):
        """设置滑块高度比例（相对于整个控件）"""
        self._thumb_ratio = max(0.05, min(1.0, ratio))
        self.update()
    
    def paintEvent(self, event: QPaintEvent):
        """绘制事件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        width = self.width()
        height = self.height()
        
        # 绘制背景轨道
        painter.fillRect(self.rect(), QColor(self.COLORS['background']))
        
        # 绘制轨道
        track_rect = QRect(2, 0, width - 4, height)
        painter.fillRect(track_rect, QColor(self.COLORS['track']))
        
        # 计算滑块位置和大小
        thumb_height = max(20, int(height * self._thumb_ratio))
        max_thumb_y = height - thumb_height
        thumb_y = int(self._value * max_thumb_y)
        
        # 绘制滑块
        thumb_rect = QRect(1, thumb_y, width - 2, thumb_height)
        
        # 滑块颜色
        thumb_color = self.COLORS['thumb_hover'] if self._hover else self.COLORS['thumb']
        painter.fillRect(thumb_rect, QColor(thumb_color))
        
        # 绘制滑块边框
        painter.setPen(QColor(self.COLORS['thumb_border']))
        painter.drawRect(thumb_rect)
        
        painter.end()
    
    def mousePressEvent(self, event: QMouseEvent):
        """鼠标按下事件"""
        if event.button() == Qt.MouseButton.LeftButton:
            self._dragging = True
            self._drag_start_y = event.pos().y()
            self._drag_start_value = self._value
            
            # 检查是否点击在滑块上
            thumb_height = max(20, int(self.height() * self._thumb_ratio))
            max_thumb_y = self.height() - thumb_height
            thumb_y = int(self._value * max_thumb_y)
            
            click_y = event.pos().y()
            if not (thumb_y <= click_y <= thumb_y + thumb_height):
                # 点击在轨道其他位置，直接跳转到该位置
                new_value = click_y / self.height()
                self.set_value(new_value)
                self.position_changed.emit(self._value)
    
    def mouseMoveEvent(self, event: QMouseEvent):
        """鼠标移动事件"""
        # 检查是否悬停在滑块上
        thumb_height = max(20, int(self.height() * self._thumb_ratio))
        max_thumb_y = self.height() - thumb_height
        thumb_y = int(self._value * max_thumb_y)
        
        click_y = event.pos().y()
        was_hover = self._hover
        self._hover = thumb_y <= click_y <= thumb_y + thumb_height
        
        if was_hover != self._hover:
            self.update()
        
        if self._dragging:
            # 计算拖拽偏移
            delta_y = event.pos().y() - self._drag_start_y
            max_thumb_y = self.height() - thumb_height
            
            if max_thumb_y > 0:
                delta_value = delta_y / max_thumb_y
                new_value = self._drag_start_value + delta_value
                self.set_value(new_value)
                self.position_changed.emit(self._value)
    
    def mouseReleaseEvent(self, event: QMouseEvent):
        """鼠标释放事件"""
        if event.button() == Qt.MouseButton.LeftButton:
            self._dragging = False
    
    def wheelEvent(self, event: QWheelEvent):
        """滚轮事件"""
        delta = event.angleDelta().y()
        scroll_step = 0.05
        
        if delta > 0:
            self.set_value(self._value - scroll_step)
        else:
            self.set_value(self._value + scroll_step)
        
        self.position_changed.emit(self._value)


class MinimapPanel(QWidget):
    """缩略图面板 - 组合缩略图和滑块"""
    
    # 信号
    navigate_to_line = pyqtSignal(int)  # 导航到指定行
    viewport_scroll = pyqtSignal(float)  # 视口滚动信号
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self._setup_ui()
    
    def _setup_ui(self):
        """设置UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # 创建缩略图
        self.minimap = MinimapWidget()
        self.minimap.clicked.connect(self._on_minimap_clicked)
        self.minimap.viewport_changed.connect(self._on_viewport_changed)
        layout.addWidget(self.minimap, 1)
        
        # 创建滑块
        self.slider = MinimapSlider()
        self.slider.position_changed.connect(self._on_slider_changed)
        
        # 将滑块放在右侧
        self._slider_container = QWidget(self)
        slider_layout = QVBoxLayout(self._slider_container)
        slider_layout.setContentsMargins(0, 0, 0, 0)
        slider_layout.addWidget(self.slider)
        
        # 设置固定宽度
        self.setFixedWidth(135)
        
        # 启用鼠标跟踪
        self.setMouseTracking(True)
    
    def resizeEvent(self, event):
        """调整大小事件"""
        super().resizeEvent(event)
        # 调整滑块容器位置
        self._slider_container.setGeometry(
            self.width() - 15, 0, 15, self.height()
        )
    
    def set_code(self, code: str):
        """设置代码"""
        self.minimap.set_code(code)
    
    def set_viewport(self, first_visible: int, last_visible: int, total_lines: int):
        """设置视口"""
        self.minimap.set_viewport_by_lines(first_visible, last_visible, total_lines)
        
        # 更新滑块
        if total_lines > 0:
            thumb_ratio = (last_visible - first_visible + 1) / total_lines
            self.slider.set_thumb_ratio(thumb_ratio)
            
            value = first_visible / total_lines
            self.slider.set_value(value)
    
    def _on_minimap_clicked(self, line: int):
        """缩略图点击事件"""
        self.navigate_to_line.emit(line)
    
    def _on_viewport_changed(self, start_ratio: float, end_ratio: float):
        """视口改变事件"""
        # 更新滑块位置
        self.slider.set_value(start_ratio)
        
        # 发送滚动信号
        self.viewport_scroll.emit(start_ratio)
    
    def _on_slider_changed(self, value: float):
        """滑块改变事件"""
        # 更新缩略图视口
        thumb_ratio = self.slider._thumb_ratio
        self.minimap.set_viewport(value, value + thumb_ratio)
        
        # 发送导航信号
        if self.minimap._line_count > 0:
            line = int(value * self.minimap._line_count)
            self.navigate_to_line.emit(line)


class CodeOverview(QWidget):
    """代码概览控件 - 简化版的缩略图"""
    
    clicked = pyqtSignal(int)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self._code: str = ""
        self._lines: list = []
        self._line_height: int = 2
        
        self.setFixedWidth(100)
        self.setMinimumHeight(200)
        
        # 设置背景
        self.setStyleSheet("background-color: #f5f5f5; border-left: 1px solid #ddd;")
    
    def set_code(self, code: str):
        """设置代码"""
        self._code = code
        self._lines = code.split('\n') if code else []
        self.update()
    
    def paintEvent(self, event: QPaintEvent):
        """绘制事件"""
        painter = QPainter(self)
        
        # 绘制背景
        painter.fillRect(self.rect(), QColor('#f5f5f5'))
        
        if not self._lines:
            return
        
        # 计算缩放
        content_height = len(self._lines) * self._line_height
        scale = 1.0
        if content_height > self.height():
            scale = self.height() / content_height
        
        # 绘制代码行
        painter.setPen(QColor('#999999'))
        
        for i, line in enumerate(self._lines):
            y = int(i * self._line_height * scale)
            
            if line.strip():
                # 根据行内容调整颜色
                color = '#999999'
                stripped = line.strip()
                
                if stripped.startswith('class '):
                    color = '#267f99'
                elif stripped.startswith('def '):
                    color = '#795e26'
                elif stripped.startswith('#'):
                    color = '#808080'
                elif any(kw in stripped for kw in ['if ', 'for ', 'while ', 'return']):
                    color = '#0000ff'
                
                painter.setPen(QColor(color))
                
                # 绘制简化表示
                indent = len(line) - len(line.lstrip())
                x = min(indent, 20)
                width = min(len(line.strip()) * 0.6, self.width() - x)
                
                painter.drawLine(x, y + 1, int(x + width), y + 1)
        
        painter.end()
    
    def mousePressEvent(self, event: QMouseEvent):
        """鼠标按下事件"""
        if event.button() == Qt.MouseButton.LeftButton:
            # 计算点击的行号
            content_height = len(self._lines) * self._line_height
            scale = 1.0
            if content_height > self.height():
                scale = self.height() / content_height
            
            y = event.pos().y()
            line = int(y / (self._line_height * scale))
            line = max(0, min(line, len(self._lines) - 1))
            
            self.clicked.emit(line)
    
    def sizeHint(self):
        """大小建议"""
        return QSize(100, 400)
