"""
代码折叠系统
支持代码块的折叠和展开
"""

from PyQt6.QtCore import QObject, pyqtSignal, QRect, Qt, QPoint
from PyQt6.QtGui import QPainter, QColor, QFont, QIcon, QPolygon
from PyQt6.QtWidgets import QStyle, QStyleOption
from typing import List, Dict, Set, Tuple, Optional
import ast
import re


class FoldRegion:
    """折叠区域"""
    def __init__(self, start_line: int, end_line: int, 
                 fold_type: str = 'block', indent: int = 0):
        self.start_line = start_line  # 开始行（1-based）
        self.end_line = end_line      # 结束行（1-based）
        self.fold_type = fold_type    # 类型：class, function, if, for, while, with, try
        self.indent = indent          # 缩进级别
        self.collapsed = False        # 是否折叠
        self.marker_rect: Optional[QRect] = None  # 折叠标记矩形
    
    def __repr__(self):
        return f"FoldRegion({self.start_line}-{self.end_line}, {self.fold_type})"
    
    def contains(self, line: int) -> bool:
        """检查行是否在折叠区域内"""
        return self.start_line < line <= self.end_line
    
    def toggle(self):
        """切换折叠状态"""
        self.collapsed = not self.collapsed
        return self.collapsed


class CodeFolder(QObject):
    """代码折叠管理器"""
    
    fold_changed = pyqtSignal(int, bool)  # 折叠状态改变信号 (line, collapsed)
    regions_changed = pyqtSignal()  # 折叠区域改变信号
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._regions: List[FoldRegion] = []
        self._collapsed_lines: Set[int] = set()  # 被折叠的行
        self._code: str = ""
    
    def analyze_code(self, code: str):
        """分析代码，找出可折叠区域"""
        self._code = code
        self._regions = []

        try:
            tree = ast.parse(code)
            # 遍历模块的所有顶层节点
            for node in tree.body:
                self._analyze_node(node, 0)
        except SyntaxError:
            # 语法错误时使用简单缩进分析
            self._analyze_indentation(code)

        # 按开始行排序
        self._regions.sort(key=lambda r: r.start_line)

        self.regions_changed.emit()
    
    def _analyze_node(self, node: ast.AST, indent: int):
        """递归分析AST节点"""
        if isinstance(node, ast.ClassDef):
            end_line = self._get_end_line(node)
            if end_line > node.lineno:
                self._regions.append(FoldRegion(
                    start_line=node.lineno,
                    end_line=end_line,
                    fold_type='class',
                    indent=indent
                ))
            for item in node.body:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.FunctionDef):
            end_line = self._get_end_line(node)
            if end_line > node.lineno:
                self._regions.append(FoldRegion(
                    start_line=node.lineno,
                    end_line=end_line,
                    fold_type='function',
                    indent=indent
                ))
            for item in node.body:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.AsyncFunctionDef):
            end_line = self._get_end_line(node)
            if end_line > node.lineno:
                self._regions.append(FoldRegion(
                    start_line=node.lineno,
                    end_line=end_line,
                    fold_type='function',
                    indent=indent
                ))
            for item in node.body:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.If):
            end_line = self._get_end_line(node)
            if end_line > node.lineno:
                self._regions.append(FoldRegion(
                    start_line=node.lineno,
                    end_line=end_line,
                    fold_type='if',
                    indent=indent
                ))
            for item in node.body:
                self._analyze_node(item, indent + 1)
            for item in node.orelse:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.For):
            end_line = self._get_end_line(node)
            if end_line > node.lineno:
                self._regions.append(FoldRegion(
                    start_line=node.lineno,
                    end_line=end_line,
                    fold_type='for',
                    indent=indent
                ))
            for item in node.body:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.While):
            end_line = self._get_end_line(node)
            if end_line > node.lineno:
                self._regions.append(FoldRegion(
                    start_line=node.lineno,
                    end_line=end_line,
                    fold_type='while',
                    indent=indent
                ))
            for item in node.body:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.With):
            end_line = self._get_end_line(node)
            if end_line > node.lineno:
                self._regions.append(FoldRegion(
                    start_line=node.lineno,
                    end_line=end_line,
                    fold_type='with',
                    indent=indent
                ))
            for item in node.body:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.Try):
            end_line = self._get_end_line(node)
            if end_line > node.lineno:
                self._regions.append(FoldRegion(
                    start_line=node.lineno,
                    end_line=end_line,
                    fold_type='try',
                    indent=indent
                ))
            for item in node.body:
                self._analyze_node(item, indent + 1)
            for handler in node.handlers:
                for item in handler.body:
                    self._analyze_node(item, indent + 1)
            for item in node.orelse:
                self._analyze_node(item, indent + 1)
            for item in node.finalbody:
                self._analyze_node(item, indent + 1)
    
    def _get_end_line(self, node: ast.AST) -> int:
        """获取节点的结束行号"""
        max_line = getattr(node, 'lineno', 0)
        for child in ast.walk(node):
            if hasattr(child, 'lineno'):
                max_line = max(max_line, child.lineno)
            if hasattr(child, 'end_lineno') and child.end_lineno:
                max_line = max(max_line, child.end_lineno)
        return max_line
    
    def _analyze_indentation(self, code: str):
        """使用缩进分析代码块（语法错误时的回退方案）

        改进的折叠逻辑：
        1. 只有行末带有 ':' 的语句才显示折叠按钮（排除行末空白字符干扰）
        2. 通过缩进分析找到代码块的结束位置
        3. 如果用户代码正确（有缩进的子块），才显示折叠按钮
        """
        lines = code.split('\n')

        # 匹配可能的代码块开始语句（关键字在行首，以冒号结尾）
        block_patterns = [
            (r'^\s*(class|def)\s+\w+', 'block'),
            (r'^\s*(async\s+def)\s+\w+', 'block'),
            (r'^\s*if\s+[^:]+:', 'if'),
            (r'^\s*elif\s+[^:]+:', 'elif'),
            (r'^\s*else\s*:', 'else'),
            (r'^\s*for\s+[^:]+:', 'for'),
            (r'^\s*while\s+[^:]+:', 'while'),
            (r'^\s*with\s+[^:]+:', 'with'),
            (r'^\s*try\s*:', 'try'),
            (r'^\s*except\s*', 'except'),
            (r'^\s*finally\s*:', 'finally'),
            (r'^\s*match\s+[^:]+:', 'match'),
            (r'^\s*case\s+[^:]+:', 'case'),
        ]

        def get_indent(line: str) -> int:
            """获取行的缩进级别"""
            return len(line) - len(line.lstrip())

        def is_block_start(line: str) -> tuple:
            """检查是否是代码块开始
            返回: (是否是块开始, 块类型)
            """
            # 去除行末空白后检查是否以冒号结尾
            stripped_end = line.rstrip()
            if not stripped_end.endswith(':'):
                return False, ''

            for pattern, block_type in block_patterns:
                if re.match(pattern, line):
                    return True, block_type
            return False, ''

        i = 0
        while i < len(lines):
            line = lines[i]

            # 检查是否是块开始
            is_start, block_type = is_block_start(line)
            if is_start:
                start_indent = get_indent(line)
                start_line = i + 1

                # 查找块的结束位置
                # 块的结束是下一个相同缩进或更少缩进的非空行
                j = i + 1
                while j < len(lines):
                    next_line = lines[j]
                    next_line_stripped = next_line.strip()

                    if next_line_stripped:  # 非空行
                        next_indent = get_indent(next_line)

                        # 如果缩进小于等于起始缩进，说明块结束了
                        if next_indent <= start_indent:
                            break

                        # 检查是否是同一缩进级别的 elif/else/case（这些应该属于同一个 if/match 块，而不是新块）
                        if next_indent == start_indent + 4:
                            next_is_start, next_type = is_block_start(next_line)
                            if next_is_start and next_type in ('elif', 'else', 'case'):
                                # 这些是分支语句，不终止当前块
                                pass

                    j += 1

                end_line = j
                # 只有当块有实际内容（至少有一行缩进的子代码）时才显示折叠按钮
                if end_line > start_line + 1:
                    # 检查中间是否有缩进的代码
                    has_indented_content = False
                    for k in range(start_line, end_line):
                        content_line = lines[k]
                        if content_line.strip():
                            content_indent = get_indent(content_line)
                            if content_indent > start_indent:
                                has_indented_content = True
                                break

                    if has_indented_content:
                        region = FoldRegion(
                            start_line=start_line,
                            end_line=end_line - 1,  # 结束于最后一个子代码行
                            fold_type=block_type,
                            indent=start_indent // 4
                        )
                        self._regions.append(region)

            i += 1
    
    def get_regions(self) -> List[FoldRegion]:
        """获取所有折叠区域"""
        return self._regions
    
    def get_region_at_line(self, line: int) -> Optional[FoldRegion]:
        """获取指定行的折叠区域"""
        for region in self._regions:
            if region.start_line == line:
                return region
        return None
    
    def get_region_by_pos(self, x: int, y: int, line_height: int, 
                          offset_y: int = 0) -> Optional[FoldRegion]:
        """根据鼠标位置获取折叠区域"""
        for region in self._regions:
            if region.marker_rect and region.marker_rect.contains(x, y):
                return region
        return None
    
    def toggle_fold(self, line: int) -> bool:
        """切换指定行的折叠状态"""
        region = self.get_region_at_line(line)
        if region:
            collapsed = region.toggle()
            self._update_collapsed_lines()
            self.fold_changed.emit(line, collapsed)
            return collapsed
        return False
    
    def fold_region(self, line: int):
        """折叠指定区域"""
        region = self.get_region_at_line(line)
        if region and not region.collapsed:
            region.collapsed = True
            self._update_collapsed_lines()
            self.fold_changed.emit(line, True)
    
    def unfold_region(self, line: int):
        """展开指定区域"""
        region = self.get_region_at_line(line)
        if region and region.collapsed:
            region.collapsed = False
            self._update_collapsed_lines()
            self.fold_changed.emit(line, False)
    
    def fold_all(self):
        """折叠所有区域"""
        for region in self._regions:
            region.collapsed = True
        self._update_collapsed_lines()
        self.regions_changed.emit()
    
    def unfold_all(self):
        """展开所有区域"""
        for region in self._regions:
            region.collapsed = False
        self._update_collapsed_lines()
        self.regions_changed.emit()
    
    def fold_at_level(self, level: int):
        """折叠指定级别的区域"""
        for region in self._regions:
            if region.indent == level:
                region.collapsed = True
        self._update_collapsed_lines()
        self.regions_changed.emit()
    
    def _update_collapsed_lines(self):
        """更新被折叠的行集合"""
        self._collapsed_lines.clear()
        for region in self._regions:
            if region.collapsed:
                for line in range(region.start_line + 1, region.end_line + 1):
                    self._collapsed_lines.add(line)
    
    def is_line_collapsed(self, line: int) -> bool:
        """检查行是否被折叠"""
        return line in self._collapsed_lines
    
    def get_visible_line_count(self) -> int:
        """获取可见行数"""
        if not self._code:
            return 0
        total_lines = len(self._code.split('\n'))
        return total_lines - len(self._collapsed_lines)
    
    def map_visible_to_real(self, visible_line: int) -> int:
        """将可见行号映射到实际行号"""
        real_line = 0
        visible_count = 0
        
        while visible_count < visible_line:
            real_line += 1
            if real_line not in self._collapsed_lines:
                visible_count += 1
        
        return real_line
    
    def map_real_to_visible(self, real_line: int) -> int:
        """将实际行号映射到可见行号"""
        visible_line = 0
        for line in range(1, real_line + 1):
            if line not in self._collapsed_lines:
                visible_line += 1
        return visible_line
    
    def get_fold_marker_rect(self, line: int, x: int, y: int, 
                             size: int = 12) -> QRect:
        """获取折叠标记的矩形区域"""
        margin = (line_height - size) // 2 if 'line_height' in dir() else 2
        return QRect(x, y + margin, size, size)


class FoldMarkerPainter:
    """折叠标记绘制器"""
    
    MARKER_SIZE = 12
    MARKER_MARGIN = 2
    
    def __init__(self, folder: CodeFolder):
        self._folder = folder
    
    def paint_marker(self, painter: QPainter, region: FoldRegion,
                     x: int, y: int, line_height: int):
        """绘制折叠标记"""
        # 计算标记位置
        marker_x = x + 2
        marker_y = int(y + (line_height - self.MARKER_SIZE) // 2)

        # 更新区域的标记矩形
        region.marker_rect = QRect(marker_x, marker_y,
                                    self.MARKER_SIZE, self.MARKER_SIZE)
        
        # 绘制背景
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor('#e0e0e0'))
        painter.drawRect(marker_x, marker_y, self.MARKER_SIZE, self.MARKER_SIZE)
        
        # 绘制边框
        painter.setPen(QColor('#999999'))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(marker_x, marker_y, self.MARKER_SIZE, self.MARKER_SIZE)
        
        # 绘制展开/折叠图标
        painter.setPen(QColor('#333333'))
        painter.setBrush(QColor('#333333'))
        
        center_x = marker_x + self.MARKER_SIZE // 2
        center_y = marker_y + self.MARKER_SIZE // 2
        
        if region.collapsed:
            # 折叠状态：绘制右向三角形
            polygon = QPolygon([
                QPoint(marker_x + 3, marker_y + 3),
                QPoint(marker_x + 3, marker_y + self.MARKER_SIZE - 3),
                QPoint(marker_x + self.MARKER_SIZE - 3, marker_y + self.MARKER_SIZE // 2),
            ])
            painter.drawPolygon(polygon)
        else:
            # 展开状态：绘制下向三角形
            polygon = QPolygon([
                QPoint(marker_x + 3, marker_y + 3),
                QPoint(marker_x + self.MARKER_SIZE - 3, marker_y + 3),
                QPoint(marker_x + self.MARKER_SIZE // 2, marker_y + self.MARKER_SIZE - 3),
            ])
            painter.drawPolygon(polygon)
    
    def paint_guides(self, painter: QPainter, regions: List[FoldRegion],
                     x: int, first_line: int, last_line: int, 
                     line_height: int, scroll_y: int):
        """绘制折叠引导线"""
        painter.setPen(QColor('#d0d0d0'))
        
        for region in regions:
            if region.end_line < first_line or region.start_line > last_line:
                continue
            
            # 计算引导线位置
            start_y = (region.start_line - 1) * line_height - scroll_y + line_height // 2
            end_y = (region.end_line - 1) * line_height - scroll_y + line_height // 2
            
            # 限制在可见区域内
            start_y = max(start_y, 0)
            end_y = min(end_y, (last_line - first_line + 1) * line_height)
            
            # 绘制垂直引导线
            guide_x = x + self.MARKER_SIZE // 2
            painter.drawLine(guide_x, start_y, guide_x, end_y)
            
            # 绘制水平引导线（到代码开始）
            if not region.collapsed:
                painter.drawLine(guide_x, end_y, x + 20, end_y)


def get_fold_indicator(line: str) -> Tuple[bool, str]:
    """获取行的折叠指示器信息

    改进：检查行末是否有冒号（排除行末空白字符干扰）
    """
    # 去除行末空白后检查是否以冒号结尾
    stripped_end = line.rstrip()
    if not stripped_end.endswith(':'):
        return False, ''

    stripped = line.strip()

    if stripped.startswith('class '):
        return True, 'class'
    elif stripped.startswith('def '):
        return True, 'def'
    elif stripped.startswith('async def '):
        return True, 'async'
    elif stripped.startswith('if '):
        return True, 'if'
    elif stripped.startswith('for '):
        return True, 'for'
    elif stripped.startswith('while '):
        return True, 'while'
    elif stripped.startswith('with '):
        return True, 'with'
    elif stripped.startswith('try:'):
        return True, 'try'
    elif stripped.startswith('elif '):
        return True, 'elif'
    elif stripped.startswith('else:'):
        return True, 'else'
    elif stripped.startswith('except'):
        return True, 'except'
    elif stripped.startswith('finally:'):
        return True, 'finally'
    elif stripped.startswith('match '):
        return True, 'match'
    elif stripped.startswith('case '):
        return True, 'case'

    return False, ''
