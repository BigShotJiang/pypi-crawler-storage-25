"""
上下文分析器
分析代码上下文，支持隐藏的上下文代码（CA和CB）
"""

from PyQt6.QtCore import QObject, pyqtSignal
from typing import List, Dict, Set, Optional, Tuple, Any
import ast
import re


class ContextInfo:
    """上下文信息"""
    def __init__(self):
        self.classes: Dict[str, Dict] = {}  # 类名 -> 类信息
        self.functions: Dict[str, Dict] = {}  # 函数名 -> 函数信息
        self.variables: Dict[str, str] = {}  # 变量名 -> 类型
        self.imports: Dict[str, str] = {}  # 导入的模块/名称
        self.current_class: Optional[str] = None  # 当前类
        self.current_function: Optional[str] = None  # 当前函数
        self.indent_level: int = 0  # 当前缩进级别
        self.scope_stack: List[str] = []  # 作用域栈


class CodeContext:
    """代码上下文 - 包含隐藏代码和可见代码"""
    def __init__(self):
        self.code_a: str = ""  # 类定义代码 (CA)
        self.code_b: str = ""  # 函数定义代码 (CB)
        self.prefix: str = ""  # 前缀缩进
        self.visible_code: str = ""  # 可见代码 (CC)
    
    def get_full_code(self) -> str:
        """获取完整代码（用于分析）"""
        lines = []
        
        if self.code_a:
            lines.append(self.code_a)
            lines.append("")
        
        if self.code_b:
            lines.append(self.code_b)
            lines.append("")
        
        # 添加可见代码（带缩进）
        if self.prefix:
            for line in self.visible_code.split('\n'):
                lines.append(self.prefix + line)
        else:
            lines.append(self.visible_code)
        
        return '\n'.join(lines)
    
    def get_visible_line_number(self, full_line: int) -> int:
        """将完整代码行号转换为可见代码行号"""
        offset = 0
        if self.code_a:
            offset += len(self.code_a.split('\n')) + 1
        if self.code_b:
            offset += len(self.code_b.split('\n')) + 1
        
        visible_line = full_line - offset
        return max(0, visible_line)
    
    def get_full_line_number(self, visible_line: int) -> int:
        """将可见代码行号转换为完整代码行号"""
        offset = 0
        if self.code_a:
            offset += len(self.code_a.split('\n')) + 1
        if self.code_b:
            offset += len(self.code_b.split('\n')) + 1
        
        return visible_line + offset


class ContextAnalyzer(QObject):
    """上下文分析器"""
    
    analysis_complete = pyqtSignal(object)  # 分析完成信号
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._context = CodeContext()
        self._analysis_result: Optional[ContextInfo] = None
    
    def set_context(self, code_a: str = "", code_b: str = "", 
                   prefix: str = "", visible_code: str = ""):
        """
        设置代码上下文
        
        Args:
            code_a: 类定义代码 (CA)
            code_b: 函数定义代码 (CB)
            prefix: 前缀缩进
            visible_code: 可见代码 (CC)
        """
        self._context.code_a = code_a
        self._context.code_b = code_b
        self._context.prefix = prefix
        self._context.visible_code = visible_code
        
        # 重新分析
        self.analyze()
    
    def analyze(self) -> ContextInfo:
        """分析代码上下文"""
        full_code = self._context.get_full_code()
        self._analysis_result = self._analyze_code(full_code)
        self.analysis_complete.emit(self._analysis_result)
        return self._analysis_result
    
    def _analyze_code(self, code: str) -> ContextInfo:
        """分析代码"""
        info = ContextInfo()
        
        try:
            tree = ast.parse(code)
            
            # 分析导入
            self._analyze_imports(tree, info)
            
            # 分析类和函数
            self._analyze_definitions(tree, info)
            
            # 分析变量
            self._analyze_variables(tree, info)
            
        except SyntaxError:
            # 语法错误时返回空信息
            pass
        
        return info
    
    def _analyze_imports(self, tree: ast.AST, info: ContextInfo):
        """分析导入语句"""
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    name = alias.asname if alias.asname else alias.name
                    info.imports[name] = alias.name
            
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    name = alias.asname if alias.asname else alias.name
                    info.imports[name] = f"{module}.{alias.name}"
    
    def _analyze_definitions(self, tree: ast.AST, info: ContextInfo):
        """分析类和函数定义"""
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                class_info = {
                    'name': node.name,
                    'bases': [self._get_name(base) for base in node.bases],
                    'methods': {},
                    'attributes': {},
                    'line': node.lineno,
                }
                
                # 分析方法
                for item in node.body:
                    if isinstance(item, ast.FunctionDef):
                        method_info = self._analyze_function(item)
                        class_info['methods'][item.name] = method_info
                    elif isinstance(item, ast.Assign):
                        for target in item.targets:
                            if isinstance(target, ast.Name):
                                class_info['attributes'][target.id] = {
                                    'line': item.lineno,
                                    'value': self._get_value_repr(item.value)
                                }
                
                info.classes[node.name] = class_info
            
            elif isinstance(node, ast.FunctionDef):
                # 顶层函数
                func_info = self._analyze_function(node)
                info.functions[node.name] = func_info
    
    def _analyze_function(self, node: ast.FunctionDef) -> Dict:
        """分析函数定义"""
        return {
            'name': node.name,
            'args': [arg.arg for arg in node.args.args],
            'defaults': len(node.args.defaults),
            'vararg': node.args.vararg.arg if node.args.vararg else None,
            'kwarg': node.args.kwarg.arg if node.args.kwarg else None,
            'decorators': [self._get_name(d) for d in node.decorator_list],
            'line': node.lineno,
            'docstring': ast.get_docstring(node),
        }
    
    def _analyze_variables(self, tree: ast.AST, info: ContextInfo):
        """分析变量定义"""
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        var_type = self._infer_type(node.value)
                        info.variables[target.id] = var_type
            
            elif isinstance(node, ast.AnnAssign):
                if isinstance(node.target, ast.Name):
                    annotation = self._get_name(node.annotation)
                    info.variables[node.target.id] = annotation
    
    def _infer_type(self, node: Optional[ast.expr]) -> str:
        """推断表达式类型"""
        if node is None:
            return "Any"
        
        if isinstance(node, ast.Num):
            if isinstance(node.n, int):
                return "int"
            return "float"
        
        elif isinstance(node, ast.Str):
            return "str"
        
        elif isinstance(node, ast.List):
            return "list"
        
        elif isinstance(node, ast.Dict):
            return "dict"
        
        elif isinstance(node, ast.Set):
            return "set"
        
        elif isinstance(node, ast.Tuple):
            return "tuple"
        
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                return node.func.id
        
        return "Any"
    
    def _get_name(self, node: ast.AST) -> str:
        """获取节点名称"""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            return f"{self._get_name(node.value)}.{node.attr}"
        elif isinstance(node, ast.Subscript):
            return self._get_name(node.value)
        return str(node)
    
    def _get_value_repr(self, node: ast.expr) -> str:
        """获取值的字符串表示"""
        if isinstance(node, ast.Num):
            return str(node.n)
        elif isinstance(node, ast.Str):
            return repr(node.s)
        elif isinstance(node, ast.NameConstant):
            return str(node.value)
        elif isinstance(node, ast.Name):
            return node.id
        return "..."
    
    def get_class_info(self, class_name: str) -> Optional[Dict]:
        """获取类信息"""
        if self._analysis_result:
            return self._analysis_result.classes.get(class_name)
        return None
    
    def get_function_info(self, func_name: str) -> Optional[Dict]:
        """获取函数信息"""
        if self._analysis_result:
            return self._analysis_result.functions.get(func_name)
        return None
    
    def get_variable_type(self, var_name: str) -> Optional[str]:
        """获取变量类型"""
        if self._analysis_result:
            return self._analysis_result.variables.get(var_name)
        return None
    
    def get_available_names(self, line: int = None) -> List[str]:
        """获取可用名称列表"""
        names = []
        
        if self._analysis_result:
            names.extend(self._analysis_result.imports.keys())
            names.extend(self._analysis_result.classes.keys())
            names.extend(self._analysis_result.functions.keys())
            names.extend(self._analysis_result.variables.keys())
        
        return sorted(set(names))
    
    def get_context_at_line(self, line: int) -> Dict[str, Any]:
        """获取指定行号的上下文信息"""
        result = {
            'in_class': None,
            'in_function': None,
            'scope': 'module',
            'available_names': [],
        }
        
        if not self._analysis_result:
            return result
        
        # 查找当前所在的类和函数
        for class_name, class_info in self._analysis_result.classes.items():
            if class_info['line'] <= line:
                result['in_class'] = class_name
                for method_name, method_info in class_info['methods'].items():
                    if method_info['line'] <= line:
                        result['in_function'] = method_name
        
        for func_name, func_info in self._analysis_result.functions.items():
            if func_info['line'] <= line:
                result['in_function'] = func_name
        
        # 确定作用域
        if result['in_class'] and result['in_function']:
            result['scope'] = 'method'
        elif result['in_function']:
            result['scope'] = 'function'
        elif result['in_class']:
            result['scope'] = 'class'
        
        # 获取可用名称
        result['available_names'] = self._get_available_names_for_scope(result)
        
        return result
    
    def _get_available_names_for_scope(self, context: Dict) -> List[str]:
        """获取指定作用域的可用名称"""
        names = []
        
        if self._analysis_result:
            # 所有作用域都可用
            names.extend(self._analysis_result.imports.keys())
            names.extend(self._analysis_result.classes.keys())
            names.extend(self._analysis_result.functions.keys())
            
            # 在方法中，添加self的属性和方法
            if context['scope'] == 'method' and context['in_class']:
                class_info = self._analysis_result.classes.get(context['in_class'])
                if class_info:
                    names.append('self')
                    names.extend(class_info['methods'].keys())
                    names.extend(class_info['attributes'].keys())
        
        return sorted(set(names))
    
    def get_completion_context(self, code: str, cursor_pos: int) -> Dict[str, Any]:
        """获取补全上下文"""
        full_code = self._context.get_full_code()
        
        # 计算光标在完整代码中的位置
        visible_prefix = code[:cursor_pos]
        full_prefix = self._context.code_a + '\n\n' + self._context.code_b + '\n\n'
        if self._context.prefix:
            for line in visible_prefix.split('\n'):
                full_prefix += self._context.prefix + line + '\n'
        else:
            full_prefix += visible_prefix
        
        full_cursor_pos = len(full_prefix)
        
        # 获取当前词
        current_word = ""
        for i in range(cursor_pos - 1, -1, -1):
            if i < 0 or not (code[i].isalnum() or code[i] == '_'):
                break
            current_word = code[i] + current_word
        
        # 检查是否在点号后
        after_dot = False
        object_name = ""
        if cursor_pos > 0:
            # 跳过空白
            check_pos = cursor_pos - 1
            while check_pos >= 0 and code[check_pos].isspace():
                check_pos -= 1
            
            if check_pos >= 0 and code[check_pos] == '.':
                after_dot = True
                # 获取对象名
                obj_end = check_pos
                obj_start = obj_end - 1
                while obj_start >= 0 and (code[obj_start].isalnum() or code[obj_start] == '_'):
                    obj_start -= 1
                obj_start += 1
                object_name = code[obj_start:obj_end].strip()
        
        return {
            'current_word': current_word,
            'after_dot': after_dot,
            'object_name': object_name,
            'full_code': full_code,
            'cursor_pos': full_cursor_pos,
        }


class ScopeAnalyzer:
    """作用域分析器 - 分析代码作用域"""
    
    def __init__(self):
        self.scopes: List[Dict] = []
    
    def analyze(self, code: str) -> List[Dict]:
        """分析代码作用域"""
        self.scopes = []
        
        try:
            tree = ast.parse(code)
            self._analyze_node(tree, 0)
        except SyntaxError:
            pass
        
        return self.scopes
    
    def _analyze_node(self, node: ast.AST, indent: int):
        """递归分析节点"""
        if isinstance(node, ast.ClassDef):
            self.scopes.append({
                'type': 'class',
                'name': node.name,
                'line_start': node.lineno,
                'line_end': self._get_end_line(node),
                'indent': indent,
            })
            for item in node.body:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.FunctionDef):
            self.scopes.append({
                'type': 'function',
                'name': node.name,
                'line_start': node.lineno,
                'line_end': self._get_end_line(node),
                'indent': indent,
            })
            for item in node.body:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.If):
            self.scopes.append({
                'type': 'if',
                'line_start': node.lineno,
                'line_end': self._get_end_line(node),
                'indent': indent,
            })
            for item in node.body:
                self._analyze_node(item, indent + 1)
            for item in node.orelse:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.For):
            self.scopes.append({
                'type': 'for',
                'line_start': node.lineno,
                'line_end': self._get_end_line(node),
                'indent': indent,
            })
            for item in node.body:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.While):
            self.scopes.append({
                'type': 'while',
                'line_start': node.lineno,
                'line_end': self._get_end_line(node),
                'indent': indent,
            })
            for item in node.body:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.With):
            self.scopes.append({
                'type': 'with',
                'line_start': node.lineno,
                'line_end': self._get_end_line(node),
                'indent': indent,
            })
            for item in node.body:
                self._analyze_node(item, indent + 1)
        
        elif isinstance(node, ast.Try):
            self.scopes.append({
                'type': 'try',
                'line_start': node.lineno,
                'line_end': self._get_end_line(node),
                'indent': indent,
            })
            for item in node.body:
                self._analyze_node(item, indent + 1)
            for handler in node.handlers:
                for item in handler.body:
                    self._analyze_node(item, indent + 1)
            for item in node.orelse:
                self._analyze_node(item, indent + 1)
            for item in node.finalbody:
                self._analyze_node(item, indent + 1)
    
    def _get_end_line(self, node: ast.AST) -> int:
        """获取节点的结束行号"""
        max_line = getattr(node, 'lineno', 0)
        for child in ast.walk(node):
            if hasattr(child, 'lineno'):
                max_line = max(max_line, child.lineno)
            if hasattr(child, 'end_lineno') and child.end_lineno:
                max_line = max(max_line, child.end_lineno)
        return max_line
    
    def get_scope_at_line(self, line: int) -> Optional[Dict]:
        """获取指定行号的作用域"""
        for scope in self.scopes:
            if scope['line_start'] <= line <= scope['line_end']:
                return scope
        return None
    
    def get_foldable_regions(self) -> List[Tuple[int, int]]:
        """获取可折叠区域列表"""
        regions = []
        for scope in self.scopes:
            if scope['line_end'] > scope['line_start']:
                regions.append((scope['line_start'], scope['line_end']))
        return regions
