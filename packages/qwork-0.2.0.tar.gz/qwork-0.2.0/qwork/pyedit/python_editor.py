"""
Python编辑器主Widget
整合所有组件，提供完整的Python代码编辑功能
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QFrame, QLabel, QStatusBar, QToolBar, QPushButton,
    QApplication
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer, QSize
from PyQt6.QtGui import QFont, QIcon, QAction, QKeySequence
from typing import Optional, Callable

from .code_editor import CodeEditor
from .minimap import MinimapPanel, CodeOverview
from .context_analyzer import ContextAnalyzer


class PythonEditor(QWidget):
    """
    Python编辑器主控件
    
    功能：
    - Python语法高亮
    - 智能代码补全（类似PyCharm）
    - 上下文分析（支持隐藏代码CA和CB）
    - 代码折叠（Ctrl++ / Ctrl+-）
    - 行号显示
    - 缩略图滑块
    
    使用示例：
        editor = PythonEditor()
        editor.set_context_code(
            code_a="class A(CL):\\n    NAME = ''\\n    ...",
            code_b="def myfn(self, c:OuterClassRef, k: KnowRef, *refs):\\n    v = 0",
            prefix="    "  # 4空格缩进
        )
        editor.set_code("# 在这里编辑代码\\nself.do_something()")
    """
    
    # 信号
    text_modified = pyqtSignal()  # 文本修改
    cursor_position_changed = pyqtSignal(int, int)  # 光标位置改变 (line, column)
    completions_ready = pyqtSignal(list)  # 补全建议就绪
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # 隐藏代码上下文
        self._context_code_a: str = ""  # 类定义代码 (CA)
        self._context_code_b: str = ""  # 函数定义代码 (CB)
        self._context_prefix: str = ""  # 前缀缩进
        
        # 设置UI
        self._setup_ui()
        self._setup_toolbar()
        self._setup_statusbar()
        self._setup_connections()
    
    def _setup_ui(self):
        """设置UI"""
        # 主布局
        self._main_layout = QVBoxLayout(self)
        self._main_layout.setContentsMargins(0, 0, 0, 0)
        self._main_layout.setSpacing(0)
        
        # 创建分割器
        self._splitter = QSplitter(Qt.Orientation.Horizontal)
        self._splitter.setHandleWidth(2)
        
        # 创建代码编辑器
        self._editor = CodeEditor()
        self._editor.text_modified.connect(self._on_text_modified)
        self._editor.cursor_position_changed.connect(self._on_cursor_position_changed)
        
        # 创建缩略图面板
        self._minimap = MinimapPanel()
        self._minimap.navigate_to_line.connect(self._on_navigate_to_line)
        self._minimap.viewport_scroll.connect(self._on_viewport_scroll)
        
        # 添加到分割器
        self._splitter.addWidget(self._editor)
        self._splitter.addWidget(self._minimap)
        
        # 设置分割比例
        self._splitter.setSizes([600, 120])
        self._splitter.setStretchFactor(0, 1)
        self._splitter.setStretchFactor(1, 0)
        
        # 添加到主布局
        self._main_layout.addWidget(self._splitter)
        
        # 设置样式
        self.setStyleSheet("""
            PythonEditor {
                background-color: #ffffff;
                border: 1px solid #cccccc;
            }
            QSplitter::handle {
                background-color: #e0e0e0;
            }
            QSplitter::handle:hover {
                background-color: #5a9bd5;
            }
        """)
    
    def _setup_toolbar(self):
        """设置工具栏"""
        self._toolbar = QToolBar()
        self._toolbar.setMovable(False)
        self._toolbar.setFixedHeight(32)
        
        # 折叠按钮
        self._btn_fold_all = QPushButton("折叠全部")
        self._btn_fold_all.setFixedHeight(24)
        self._btn_fold_all.setToolTip("Ctrl+Shift+- 折叠所有代码块")
        self._btn_fold_all.clicked.connect(self._editor.fold_all)
        
        self._btn_unfold_all = QPushButton("展开全部")
        self._btn_unfold_all.setFixedHeight(24)
        self._btn_unfold_all.setToolTip("Ctrl+Shift++ 展开所有代码块")
        self._btn_unfold_all.clicked.connect(self._editor.unfold_all)
        
        # 添加按钮到工具栏
        self._toolbar.addWidget(self._btn_fold_all)
        self._toolbar.addWidget(self._btn_unfold_all)
        
        # 添加分隔线
        self._toolbar.addSeparator()
        
        # 添加标签
        self._lbl_position = QLabel("行 1, 列 1")
        self._lbl_position.setStyleSheet("color: #666666; padding: 0 10px;")
        self._toolbar.addWidget(self._lbl_position)
        
        # 添加到主布局
        self._main_layout.insertWidget(0, self._toolbar)
        
        # 设置工具栏样式
        self._toolbar.setStyleSheet("""
            QToolBar {
                background-color: #f5f5f5;
                border-bottom: 1px solid #cccccc;
                spacing: 5px;
                padding: 2px 5px;
            }
            QPushButton {
                background-color: #ffffff;
                border: 1px solid #cccccc;
                border-radius: 3px;
                padding: 4px 12px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #e8f4fc;
                border-color: #5a9bd5;
            }
            QPushButton:pressed {
                background-color: #d0e8f8;
            }
        """)
    
    def _setup_statusbar(self):
        """设置状态栏"""
        self._statusbar = QStatusBar()
        self._statusbar.setFixedHeight(22)
        self._statusbar.setStyleSheet("""
            QStatusBar {
                background-color: #f5f5f5;
                border-top: 1px solid #cccccc;
                font-size: 11px;
            }
        """)
        
        # 添加状态标签
        self._lbl_status = QLabel("就绪")
        self._lbl_status.setStyleSheet("color: #666666; padding: 0 5px;")
        self._statusbar.addWidget(self._lbl_status)
        
        # 添加到主布局
        self._main_layout.addWidget(self._statusbar)
    
    def _setup_connections(self):
        """设置信号连接"""
        # 定时更新缩略图
        self._update_timer = QTimer()
        self._update_timer.timeout.connect(self._update_minimap)
        self._update_timer.start(500)  # 每500ms更新一次
    
    def set_context_code(self, code_a: str = "", code_b: str = "", prefix: str = ""):
        """
        设置上下文代码

        这是本编辑器的核心功能。可以设置隐藏的上下文代码，这些代码
        不会显示在编辑器中，但会参与语法分析和代码补全。

        Args:
            code_a: 类定义代码 (CA)，例如：
                class A(CL):
                    NAME = ''
                    ...
            code_b: 函数定义代码 (CB)，例如：
                def myfn(self, c:OuterClassRef, k: KnowRef, *refs):
                    v = 0
            prefix: 前缀缩进，用于编辑器中的代码
        """
        print(f"[PythonEditor.set_context_code] Setting context code")
        print(f"[PythonEditor.set_context_code] code_a length: {len(code_a)}")
        print(f"[PythonEditor.set_context_code] code_b length: {len(code_b)}")
        print(f"[PythonEditor.set_context_code] prefix: {repr(prefix)}")

        self._context_code_a = code_a
        self._context_code_b = code_b
        self._context_prefix = prefix

        # 更新编辑器
        self._editor.set_context_code(code_a, code_b, prefix)

        # 更新缩略图
        self._update_minimap()
    
    def get_context_code(self) -> tuple:
        """获取上下文代码"""
        return (self._context_code_a, self._context_code_b, self._context_prefix)
    
    def set_code(self, code: str):
        """设置编辑器中的代码"""
        self._editor.set_text(code)
        self._update_minimap()

    def get_code(self) -> str:
        """获取编辑器中的代码"""
        return self._editor.get_text()
    
    def append_code(self, code: str):
        """追加代码"""
        current = self.get_code()
        if current and not current.endswith('\n'):
            code = '\n' + code
        self._editor.appendPlainText(code)
    
    def clear(self):
        """清空编辑器"""
        self._editor.clear()
        self._update_minimap()
    
    def _update_minimap(self):
        """更新缩略图"""
        # 构建完整代码用于缩略图显示
        full_code = self._build_full_code()
        self._minimap.set_code(full_code)
        
        # 更新视口
        first, last = self._editor.get_visible_lines()
        total = self._editor.document().blockCount()
        self._minimap.set_viewport(first, last, total)
    
    def _build_full_code(self) -> str:
        """构建完整代码（CA + CB + CC，替换 <__begin__> 占位符）"""
        # 获取可见代码（CC）
        visible_code = self.get_code()

        # 添加前缀缩进（8空格，用于类方法体内）
        if self._context_prefix:
            cc_lines = []
            for line in visible_code.split('\n'):
                cc_lines.append(self._context_prefix + line)
            cc_code = '\n'.join(cc_lines)
        else:
            cc_code = visible_code

        # 如果有 CA，直接替换其中的 <__begin__>
        if self._context_code_a:
            full_code = self._context_code_a.replace('<__begin__>', cc_code)
        elif self._context_code_b:
            # 兼容旧格式：使用 CB
            full_code = self._context_code_b.replace('<__begin__>', cc_code)
        else:
            full_code = cc_code

        return full_code

    def get_full_code(self) -> str:
        """
        获取完整代码（CA + CB + CC）

        Returns:
            完整代码字符串，包含导入、类定义、函数定义和可见代码
        """
        return self._build_full_code()
    
    def _on_text_modified(self):
        """文本修改事件"""
        self.text_modified.emit()
        # 检查 QLabel 是否还存在（防止窗口关闭后崩溃）
        if self._lbl_status is not None:
            try:
                self._lbl_status.setText("已修改")
                QTimer.singleShot(2000, self._reset_status_label)
            except RuntimeError:
                # QLabel 已被删除，忽略
                pass

    def _reset_status_label(self):
        """重置状态栏标签（带存在性检查）"""
        if self._lbl_status is not None:
            try:
                self._lbl_status.setText("就绪")
            except RuntimeError:
                # QLabel 已被删除，忽略
                pass
    
    def _on_cursor_position_changed(self, line: int, column: int):
        """光标位置改变事件"""
        self._lbl_position.setText(f"行 {line}, 列 {column}")
        self.cursor_position_changed.emit(line, column)
    
    def _on_navigate_to_line(self, line: int):
        """导航到指定行"""
        # 将缩略图行号转换为编辑器行号
        editor_line = self._map_minimap_to_editor_line(line)
        self._editor.scroll_to_line(editor_line)
    
    def _on_viewport_scroll(self, ratio: float):
        """视口滚动事件"""
        # 计算对应的行号
        total_lines = self._editor.document().blockCount()
        line = int(ratio * total_lines) + 1
        self._editor.scroll_to_line(line)
    
    def _map_minimap_to_editor_line(self, minimap_line: int) -> int:
        """将缩略图行号映射到编辑器行号"""
        # 计算偏移
        offset = 0
        if self._context_code_a:
            offset += len(self._context_code_a.split('\n')) + 1
        if self._context_code_b:
            offset += len(self._context_code_b.split('\n')) + 1
        
        # 转换为编辑器行号
        editor_line = minimap_line - offset
        return max(1, editor_line)
    
    def get_cursor_position(self) -> tuple:
        """获取光标位置 (line, column)"""
        return self._editor.get_cursor_position()
    
    def set_cursor_position(self, line: int, column: int = 0):
        """设置光标位置"""
        self._editor.set_cursor_position(line, column)
    
    def set_focus(self):
        """设置焦点到编辑器"""
        self._editor.setFocus()
    
    def fold_all(self):
        """折叠所有代码块"""
        self._editor.fold_all()
        self._lbl_status.setText("已折叠所有代码块")
    
    def unfold_all(self):
        """展开所有代码块"""
        self._editor.unfold_all()
        self._lbl_status.setText("已展开所有代码块")
    
    def fold_current(self):
        """折叠当前代码块"""
        # 调用编辑器的折叠功能
        self._editor._fold_current_block()
    
    def unfold_current(self):
        """展开当前代码块"""
        self._editor._unfold_current_block()
    
    def get_editor(self) -> CodeEditor:
        """获取内部的CodeEditor实例"""
        return self._editor
    
    def set_font(self, font: QFont):
        """设置字体"""
        self._editor.setFont(font)
    
    def set_font_family(self, family: str, size: int = 12):
        """设置字体族和大小"""
        font = QFont(family, size)
        self.set_font(font)


class PythonEditorDialog(QWidget):
    """
    Python编辑器对话框
    提供独立的编辑器窗口
    """
    
    def __init__(self, title: str = "Python编辑器", parent=None):
        super().__init__(parent)
        
        self.setWindowTitle(title)
        self.setMinimumSize(800, 600)
        self.resize(900, 700)
        
        # 创建布局
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # 创建编辑器
        self.editor = PythonEditor()
        layout.addWidget(self.editor)
        
        # 设置样式
        self.setStyleSheet("""
            PythonEditorDialog {
                background-color: #ffffff;
            }
        """)
    
    def set_context_code(self, code_a: str = "", code_b: str = "", prefix: str = ""):
        """设置上下文代码"""
        self.editor.set_context_code(code_a, code_b, prefix)
    
    def set_code(self, code: str):
        """设置代码"""
        self.editor.set_code(code)
    
    def get_code(self) -> str:
        """获取代码"""
        return self.editor.get_code()


class PythonEditorFactory:
    """Python编辑器工厂类"""
    
    @staticmethod
    def create_editor(parent=None, 
                     code_a: str = "",
                     code_b: str = "",
                     prefix: str = "",
                     initial_code: str = "") -> PythonEditor:
        """
        创建配置好的Python编辑器
        
        Args:
            parent: 父控件
            code_a: 类定义代码
            code_b: 函数定义代码
            prefix: 前缀缩进
            initial_code: 初始代码
            
        Returns:
            配置好的PythonEditor实例
        """
        editor = PythonEditor(parent)
        editor.set_context_code(code_a, code_b, prefix)
        
        if initial_code:
            editor.set_code(initial_code)
        
        return editor
    
    @staticmethod
    def create_node_editor(parent=None, 
                          node_class_code: str = "",
                          handler_code: str = "",
                          initial_code: str = "") -> PythonEditor:
        """
        创建用于节点编辑的Python编辑器
        
        Args:
            parent: 父控件
            node_class_code: 节点类定义代码 (CA)
            handler_code: 处理函数代码 (CB)
            initial_code: 初始代码
            
        Returns:
            配置好的PythonEditor实例
        """
        return PythonEditorFactory.create_editor(
            parent=parent,
            code_a=node_class_code,
            code_b=handler_code,
            prefix="        ",  # 8空格缩进
            initial_code=initial_code
        )


# 便捷函数
def create_editor(parent=None) -> PythonEditor:
    """创建Python编辑器"""
    return PythonEditor(parent)


def create_editor_with_context(code_a: str = "", 
                                code_b: str = "", 
                                prefix: str = "",
                                initial_code: str = "",
                                parent=None) -> PythonEditor:
    """创建带上下文的Python编辑器"""
    editor = PythonEditor(parent)
    editor.set_context_code(code_a, code_b, prefix)
    if initial_code:
        editor.set_code(initial_code)
    return editor
