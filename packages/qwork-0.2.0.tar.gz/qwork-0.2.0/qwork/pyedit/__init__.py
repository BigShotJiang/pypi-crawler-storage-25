"""
PyEdit - Python代码编辑器模块

基于PyQt6和Python 3.12的高级Python代码编辑器

功能特性：
- Python语法高亮（浅色主题）
- 智能代码补全（类似PyCharm）
- 上下文分析（支持隐藏的上下文代码）
- 代码折叠（Ctrl++ / Ctrl+-）
- 行号显示
- 缩略图滑块

使用示例：
    from pyedit import PythonEditor
    
    editor = PythonEditor()
    
    # 设置上下文代码（隐藏但参与分析）
    editor.set_context_code(
        code_a="class A(CL):\\n    NAME = ''\\n    ...",
        code_b="def myfn(self, c:OuterClassRef, k: KnowRef, *refs):\\n    v = 0",
        prefix="    "
    )
    
    # 设置编辑器中的代码
    editor.set_code("self.do_something()")
    
    # 获取代码
    code = editor.get_code()
"""

__version__ = '1.0.0'
__author__ = 'PyEdit Team'

# 主要组件
from .python_editor import (
    PythonEditor,
    PythonEditorDialog,
    PythonEditorFactory,
    create_editor,
    create_editor_with_context,
)

from .code_editor import CodeEditor
from .syntax_highlighter import PythonSyntaxHighlighter
from .completer import (
    CodeCompleter,
    SmartCompleter,
    CompletionItem,
    CompletionWorker,
)
from .context_analyzer import (
    ContextAnalyzer,
    ContextInfo,
    CodeContext,
    ScopeAnalyzer,
)
from .code_folder import (
    CodeFolder,
    FoldRegion,
    FoldMarkerPainter,
    get_fold_indicator,
)
from .line_number_area import (
    LineNumberArea,
    LineNumberDelegate,
    FoldingIndicator,
)
from .minimap import (
    MinimapWidget,
    MinimapSlider,
    MinimapPanel,
    CodeOverview,
)

__all__ = [
    # 主编辑器
    'PythonEditor',
    'PythonEditorDialog',
    'PythonEditorFactory',
    'create_editor',
    'create_editor_with_context',
    
    # 代码编辑器组件
    'CodeEditor',
    
    # 语法高亮
    'PythonSyntaxHighlighter',
    
    # 代码补全
    'CodeCompleter',
    'SmartCompleter',
    'CompletionItem',
    'CompletionWorker',
    
    # 上下文分析
    'ContextAnalyzer',
    'ContextInfo',
    'CodeContext',
    'ScopeAnalyzer',
    
    # 代码折叠
    'CodeFolder',
    'FoldRegion',
    'FoldMarkerPainter',
    'get_fold_indicator',
    
    # 行号
    'LineNumberArea',
    'LineNumberDelegate',
    'FoldingIndicator',
    
    # 缩略图
    'MinimapWidget',
    'MinimapSlider',
    'MinimapPanel',
    'CodeOverview',
]
