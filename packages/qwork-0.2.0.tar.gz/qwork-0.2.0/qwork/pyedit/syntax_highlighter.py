"""
Python语法高亮器
基于QSyntaxHighlighter实现
"""

from PyQt6.QtCore import QRegularExpression
from PyQt6.QtGui import (
    QSyntaxHighlighter, QTextCharFormat, QColor,
    QFont, QTextDocument
)
from typing import List, Tuple, Pattern
import re


class PythonSyntaxHighlighter(QSyntaxHighlighter):
    """Python语法高亮器 - 浅色主题"""
    
    # 浅色主题颜色配置
    COLORS = {
        'keyword': '#0000FF',      # 蓝色 - 关键字
        'string': '#008000',       # 绿色 - 字符串
        'comment': '#808080',      # 灰色 - 注释
        'function': '#795E26',     # 棕色 - 函数名
        'class': '#267F99',        # 青色 - 类名
        'number': '#098658',       # 深绿色 - 数字
        'operator': '#000000',     # 黑色 - 运算符
        'builtin': '#0000FF',      # 蓝色 - 内置函数
        'decorator': '#795E26',    # 棕色 - 装饰器
        'self': '#0000FF',         # 蓝色 - self
        'f_string_expr': '#001080', # 深蓝色 - f-string表达式
    }
    
    # Python关键字
    KEYWORDS = [
        'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue',
        'def', 'del', 'elif', 'else', 'except', 'False', 'finally', 'for',
        'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'None',
        'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'True', 'try',
        'while', 'with', 'yield'
    ]
    
    # Python内置函数
    BUILTINS = [
        'abs', 'all', 'any', 'bin', 'bool', 'bytearray', 'bytes', 'callable',
        'chr', 'classmethod', 'compile', 'complex', 'delattr', 'dict', 'dir',
        'divmod', 'enumerate', 'eval', 'exec', 'filter', 'float', 'format',
        'frozenset', 'getattr', 'globals', 'hasattr', 'hash', 'help', 'hex',
        'id', 'input', 'int', 'isinstance', 'issubclass', 'iter', 'len',
        'list', 'locals', 'map', 'max', 'memoryview', 'min', 'next', 'object',
        'oct', 'open', 'ord', 'pow', 'print', 'property', 'range', 'repr',
        'reversed', 'round', 'set', 'setattr', 'slice', 'sorted', 'staticmethod',
        'str', 'sum', 'super', 'tuple', 'type', 'vars', 'zip', '__import__'
    ]
    
    def __init__(self, parent: QTextDocument = None):
        super().__init__(parent)
        self._setup_formats()
        self._setup_rules()
    
    def _setup_formats(self):
        """设置文本格式"""
        # 关键字格式
        self.keyword_format = QTextCharFormat()
        self.keyword_format.setForeground(QColor(self.COLORS['keyword']))
        self.keyword_format.setFontWeight(QFont.Weight.Bold)
        
        # 字符串格式
        self.string_format = QTextCharFormat()
        self.string_format.setForeground(QColor(self.COLORS['string']))
        
        # 多行字符串格式
        self.multiline_string_format = QTextCharFormat()
        self.multiline_string_format.setForeground(QColor(self.COLORS['string']))
        
        # 注释格式
        self.comment_format = QTextCharFormat()
        self.comment_format.setForeground(QColor(self.COLORS['comment']))
        self.comment_format.setFontItalic(True)
        
        # 函数定义格式
        self.function_format = QTextCharFormat()
        self.function_format.setForeground(QColor(self.COLORS['function']))
        
        # 类定义格式
        self.class_format = QTextCharFormat()
        self.class_format.setForeground(QColor(self.COLORS['class']))
        
        # 数字格式
        self.number_format = QTextCharFormat()
        self.number_format.setForeground(QColor(self.COLORS['number']))
        
        # 运算符格式
        self.operator_format = QTextCharFormat()
        self.operator_format.setForeground(QColor(self.COLORS['operator']))
        
        # 内置函数格式
        self.builtin_format = QTextCharFormat()
        self.builtin_format.setForeground(QColor(self.COLORS['builtin']))
        
        # 装饰器格式
        self.decorator_format = QTextCharFormat()
        self.decorator_format.setForeground(QColor(self.COLORS['decorator']))
        
        # self格式
        self.self_format = QTextCharFormat()
        self.self_format.setForeground(QColor(self.COLORS['self']))
        self.self_format.setFontWeight(QFont.Weight.Bold)
        
        # f-string表达式格式
        self.f_string_expr_format = QTextCharFormat()
        self.f_string_expr_format.setForeground(QColor(self.COLORS['f_string_expr']))
        self.f_string_expr_format.setFontWeight(QFont.Weight.Bold)
    
    def _setup_rules(self):
        """设置高亮规则"""
        self.rules: List[Tuple[QRegularExpression, QTextCharFormat]] = []
        
        # 关键字规则
        keyword_pattern = r'\b(' + '|'.join(self.KEYWORDS) + r')\b'
        self.rules.append((QRegularExpression(keyword_pattern), self.keyword_format))
        
        # self规则
        self.rules.append((QRegularExpression(r'\bself\b'), self.self_format))
        
        # 内置函数规则
        builtin_pattern = r'\b(' + '|'.join(self.BUILTINS) + r')(?=\s*\()'
        self.rules.append((QRegularExpression(builtin_pattern), self.builtin_format))
        
        # 函数定义规则
        self.rules.append((
            QRegularExpression(r'\bdef\s+(\w+)'),
            self.function_format
        ))
        
        # 类定义规则
        self.rules.append((
            QRegularExpression(r'\bclass\s+(\w+)'),
            self.class_format
        ))
        
        # 装饰器规则
        self.rules.append((
            QRegularExpression(r'@[\w.]+'),
            self.decorator_format
        ))
        
        # 数字规则
        number_pattern = r'\b\d+\.?\d*([eE][+-]?\d+)?\b|\b0[xX][0-9a-fA-F]+\b|\b0[oO]?[0-7]+\b|\b0[bB][01]+\b'
        self.rules.append((QRegularExpression(number_pattern), self.number_format))
        
        # 双引号字符串规则
        self.rules.append((
            QRegularExpression(r'"[^"\\]*(\\.[^"\\]*)*"'),
            self.string_format
        ))
        
        # 单引号字符串规则
        self.rules.append((
            QRegularExpression(r"'[^'\\]*(\\.[^'\\]*)*'"),
            self.string_format
        ))
        
        # f-string规则 (简化处理)
        self.rules.append((
            QRegularExpression(r'f"[^"\\]*(\\.[^"\\]*)*"'),
            self.string_format
        ))
        self.rules.append((
            QRegularExpression(r"f'[^'\\]*(\\.[^'\\]*)*'"),
            self.string_format
        ))
        
        # 单行注释规则
        self.rules.append((
            QRegularExpression(r'#[^\n]*'),
            self.comment_format
        ))
    
    def highlightBlock(self, text: str):
        """高亮文本块"""
        # 应用基本规则
        for pattern, fmt in self.rules:
            match_iterator = pattern.globalMatch(text)
            while match_iterator.hasNext():
                match = match_iterator.next()
                # 对于函数和类定义，只高亮名称部分
                if pattern.pattern().startswith(r'\bdef\s+') or \
                   pattern.pattern().startswith(r'\bclass\s+'):
                    # 获取捕获组（函数/类名）
                    if match.lastCapturedIndex() >= 1:
                        start = match.capturedStart(1)
                        length = match.capturedLength(1)
                    else:
                        start = match.capturedStart()
                        length = match.capturedLength()
                else:
                    start = match.capturedStart()
                    length = match.capturedLength()
                
                self.setFormat(start, length, fmt)
        
        # 处理多行字符串
        self._highlight_multiline_strings(text)
        
        # 设置当前块状态用于多行字符串跟踪
        self.setCurrentBlockState(0)
    
    def _highlight_multiline_strings(self, text: str):
        """高亮多行字符串"""
        # 三引号字符串检测
        triple_double = '"""'
        triple_single = "'''"
        
        # 检查是否在多行字符串中
        in_multiline = self.previousBlockState() == 1
        
        i = 0
        while i < len(text):
            if not in_multiline:
                # 查找三引号开始
                dd_pos = text.find(triple_double, i)
                ds_pos = text.find(triple_single, i)
                
                start_pos = -1
                is_double = True
                
                if dd_pos != -1 and (ds_pos == -1 or dd_pos < ds_pos):
                    start_pos = dd_pos
                    is_double = True
                elif ds_pos != -1:
                    start_pos = ds_pos
                    is_double = False
                
                if start_pos != -1:
                    # 查找结束
                    end_marker = triple_double if is_double else triple_single
                    end_pos = text.find(end_marker, start_pos + 3)
                    
                    if end_pos != -1:
                        # 单行多行字符串
                        length = end_pos - start_pos + 3
                        self.setFormat(start_pos, length, self.multiline_string_format)
                        i = end_pos + 3
                    else:
                        # 多行开始
                        length = len(text) - start_pos
                        self.setFormat(start_pos, length, self.multiline_string_format)
                        in_multiline = True
                        self.setCurrentBlockState(1)
                        break
                else:
                    break
            else:
                # 在多行字符串中，查找结束
                end_pos_dd = text.find(triple_double, i)
                end_pos_ds = text.find(triple_single, i)
                
                # 需要知道是哪种三引号
                # 简化处理：检查哪个先出现
                end_pos = -1
                if end_pos_dd != -1 and end_pos_ds != -1:
                    end_pos = min(end_pos_dd, end_pos_ds)
                elif end_pos_dd != -1:
                    end_pos = end_pos_dd
                elif end_pos_ds != -1:
                    end_pos = end_pos_ds
                
                if end_pos != -1:
                    # 多行字符串结束
                    length = end_pos + 3
                    self.setFormat(0, length, self.multiline_string_format)
                    in_multiline = False
                    self.setCurrentBlockState(0)
                    i = end_pos + 3
                else:
                    # 仍在多行字符串中
                    self.setFormat(0, len(text), self.multiline_string_format)
                    self.setCurrentBlockState(1)
                    break


class HighlightRule:
    """高亮规则辅助类"""
    def __init__(self, pattern: str, color: str, bold: bool = False, italic: bool = False):
        self.pattern = QRegularExpression(pattern)
        self.format = QTextCharFormat()
        self.format.setForeground(QColor(color))
        if bold:
            self.format.setFontWeight(QFont.Weight.Bold)
        if italic:
            self.format.setFontItalic(True)
