"""
代码补全系统 - 增强版
提供类似PyCharm的智能代码补全功能

增强特性:
- 智能self.属性/方法分析
- 支持from xxx import *导入
- 优化的响应速度（缓存机制）
"""

import os
import glob


from PyQt6.QtWidgets import (
    QCompleter, QListView, QFrame, QApplication, QWidget
)
from PyQt6.QtCore import (
    Qt, QStringListModel, pyqtSignal, QObject,
    QThread, QTimer, QRect
)
from PyQt6.QtGui import QColor, QFont, QKeyEvent
from typing import List, Dict, Set, Optional, Callable, Any, Tuple
import re
import ast
import inspect
import builtins
import importlib
import sys
import importlib.util
from functools import lru_cache
from time import time


class CompletionItem:
    """补全项"""
    def __init__(self, text: str, display: str = None, 
                 item_type: str = 'variable', icon: str = '',
                 detail: str = '', priority: int = 0):
        self.text = text
        self.display = display or text
        self.item_type = item_type  # variable, function, class, keyword, builtin, attribute
        self.icon = icon
        self.detail = detail
        self.priority = priority
    
    def __repr__(self):
        return f"CompletionItem({self.text}, type={self.item_type})"
    
    def __eq__(self, other):
        if isinstance(other, CompletionItem):
            return self.text == other.text and self.item_type == other.item_type
        return False
    
    def __hash__(self):
        return hash((self.text, self.item_type))


class ImportResolver:
    """导入解析器 - 处理from xxx import *语句"""
    
    def __init__(self):
        self._import_cache: Dict[str, List[str]] = {}
        self._module_cache: Dict[str, Any] = {}
    
    def resolve_star_import(self, module_name: str) -> List[str]:
        """
        解析from module_name import *导入的符号
        
        Args:
            module_name: 模块名称
            
        Returns:
            导入的符号列表
        """
        if module_name in self._import_cache:
            return self._import_cache[module_name]
        
        try:
            # 尝试导入模块
            if module_name in sys.modules:
                module = sys.modules[module_name]
            else:
                module = importlib.import_module(module_name)
                self._module_cache[module_name] = module
            
            # 获取__all__或使用dir()
            if hasattr(module, '__all__'):
                names = list(module.__all__)
            else:
                names = [name for name in dir(module) if not name.startswith('_')]
            
            self._import_cache[module_name] = names
            return names
            
        except Exception:
            # 导入失败（builtin有入口错误保护），尝试静态分析
            return self._try_custom_import(module_name)
    
    def _try_custom_import(self, module_name: str) -> List[str]:
        """尝试导入自定义模块（如builtin）或从子模块解析"""
        # 尝试在当前路径和常见路径中查找
        try:
            # 尝试直接导入
            spec = importlib.util.find_spec(module_name)
            if spec is None:
                # 尝试在当前目录查找
                current_dir = os.getcwd()
                if current_dir not in sys.path:
                    sys.path.insert(0, current_dir)
                spec = importlib.util.find_spec(module_name)

            if spec is not None:
                try:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)

                    if hasattr(module, '__all__'):
                        names = list(module.__all__)
                    else:
                        names = [name for name in dir(module) if not name.startswith('_')]

                    self._import_cache[module_name] = names
                    self._module_cache[module_name] = module
                    return names
                except Exception:
                    # 导入失败（如builtin有入口错误），尝试静态分析
                    return self._parse_module_static(spec.origin)

        except Exception:
            pass

        return []

    def _parse_module_static(self, file_path: str) -> List[str]:
        """静态分析模块文件，提取导出的符号（不执行代码）"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            names = []
            tree = ast.parse(content)

            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom):
                    # from xxx import *  -> 解析子模块
                    if any(alias.name == '*' for alias in node.names):
                        # 尝试解析子模块
                        module = node.module
                        if module:
                            sub_names = self._get_submodule_exports(module, file_path)
                            names.extend(sub_names)
                    else:
                        # from xxx import a, b, c
                        for alias in node.names:
                            names.append(alias.asname if alias.asname else alias.name)

            return names

        except Exception:
            return []

    def _get_submodule_exports(self, module: str, parent_file: str) -> List[str]:
        """获取子模块导出的符号"""
        try:
            # 构建子模块路径
            parent_dir = os.path.dirname(parent_file)
            parts = module.split('.')
            sub_path = os.path.join(parent_dir, *parts[1:]) + '.py'

            if os.path.exists(sub_path):
                return self._parse_submodule_file(sub_path)

            # 尝试作为包导入
            sub_init = os.path.join(parent_dir, *parts[1:], '__init__.py')
            if os.path.exists(sub_init):
                return self._parse_module_static(sub_init)

        except Exception:
            pass

        return []

    def _parse_submodule_file(self, file_path: str) -> List[str]:
        """解析子模块文件，获取导出的类和函数"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            names = []
            tree = ast.parse(content)

            for node in ast.walk(tree):
                # class XXX
                if isinstance(node, ast.ClassDef):
                    if not node.name.startswith('_'):
                        names.append(node.name)
                # def XXX
                elif isinstance(node, ast.FunctionDef):
                    if not node.name.startswith('_'):
                        names.append(node.name)
                # XXX = ...
                elif isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and not target.id.startswith('_'):
                            names.append(target.id)

            return names

        except Exception:
            return []
    
    def get_module_members(self, module_name: str) -> List[Tuple[str, str, Any]]:
        """
        获取模块成员及其类型
        
        Returns:
            [(name, type_str, obj), ...]
        """
        try:
            if module_name in self._module_cache:
                module = self._module_cache[module_name]
            else:
                module = importlib.import_module(module_name)
                self._module_cache[module_name] = module
            
            members = []
            for name in dir(module):
                if not name.startswith('_'):
                    try:
                        obj = getattr(module, name)
                        if inspect.isfunction(obj) or inspect.isbuiltin(obj):
                            members.append((name, 'function', obj))
                        elif inspect.isclass(obj):
                            members.append((name, 'class', obj))
                        else:
                            members.append((name, 'variable', obj))
                    except Exception:
                        members.append((name, 'unknown', None))
            return members
            
        except Exception:
            return []
    
    def clear_cache(self):
        """清除缓存"""
        self._import_cache.clear()
        self._module_cache.clear()

    def get_class_members(self, class_name: str, module_name: str = None) -> List[Tuple[str, str, str]]:
        """
        获取类的成员（方法和属性）

        Args:
            class_name: 类名
            module_name: 模块名（可选）

        Returns:
            [(name, type, doc), ...]  type: 'method' 或 'attribute'
        """
        try:
            # 如果提供了模块名，优先从该模块查找
            if module_name and module_name in self._module_cache:
                module = self._module_cache[module_name]
                if hasattr(module, class_name):
                    cls = getattr(module, class_name)
                    if inspect.isclass(cls):
                        members = []
                        for name, obj in inspect.getmembers(cls):
                            if not name.startswith('_'):
                                if inspect.isfunction(obj) or inspect.ismethod(obj):
                                    members.append((name, 'method', inspect.getdoc(obj) or ''))
                                else:
                                    members.append((name, 'attribute', str(type(obj).__name__)))
                        return members
        except Exception:
            pass

        # 尝试静态分析
        try:
            return self._get_class_members_static(class_name, module_name)
        except Exception:
            pass

        return []

    def _get_class_members_static(self, class_name: str, module_name: str = None) -> List[Tuple[str, str, str]]:
        """静态分析获取类成员（包括基类成员）"""
        try:

            # 构建模块文件路径
            if not module_name:
                return []

            base_dir = os.getcwd()

            # 获取模块路径
            if '.' in module_name:
                parts = module_name.split('.')
                module_dir = os.path.join(base_dir, *parts)
            else:
                module_dir = os.path.join(base_dir, module_name)

            # 收集要搜索的文件列表
            files_to_search = []

            # 1. 直接文件: module_name.py
            direct_file = module_dir + '.py'
            if os.path.exists(direct_file):
                files_to_search.append(direct_file)

            # 2. 包目录: module_name/__init__.py
            if os.path.isdir(module_dir):
                init_file = os.path.join(module_dir, '__init__.py')
                if os.path.exists(init_file):
                    files_to_search.append(init_file)

                # 3. 子模块: module_name/*.py
                sub_files = glob.glob(os.path.join(module_dir, '*.py'))
                for sub_file in sub_files:
                    if sub_file not in files_to_search:
                        files_to_search.append(sub_file)

                # 4. 子包: module_name/*/__init__.py
                sub_dirs = [d for d in os.listdir(module_dir)
                           if os.path.isdir(os.path.join(module_dir, d)) and not d.startswith('_')]
                for sub_dir in sub_dirs:
                    sub_init = os.path.join(module_dir, sub_dir, '__init__.py')
                    if os.path.exists(sub_init) and sub_init not in files_to_search:
                        files_to_search.append(sub_init)

            print(f"[DEBUG TYPE] Searching for class '{class_name}' in {len(files_to_search)} files")

            # 解析所有文件，构建类名到类定义的映射
            class_map = {}  # class_name -> (file_path, class_node)
            for file_path in files_to_search:
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    tree = ast.parse(content)
                    for node in ast.walk(tree):
                        if isinstance(node, ast.ClassDef):
                            class_map[node.name] = (file_path, node)
                except Exception as e:
                    continue

            # 递归获取类及其基类的成员
            visited_classes = set()
            all_members = []

            def collect_members(class_name_to_find):
                """递归收集类及其基类的成员"""
                if class_name_to_find in visited_classes:
                    return
                visited_classes.add(class_name_to_find)

                if class_name_to_find not in class_map:
                    return

                file_path, class_node = class_map[class_name_to_find]
                print(f"[DEBUG TYPE] Analyzing class '{class_name_to_find}' in {file_path}")

                # 收集当前类的成员
                for item in class_node.body:
                    if isinstance(item, ast.FunctionDef) and not item.name.startswith('_'):
                        doc = ast.get_docstring(item) or ''
                        # 检查是否是 @property 装饰的属性
                        is_property = any(
                            (isinstance(d, ast.Name) and d.id == 'property') or
                            (isinstance(d, ast.Attribute) and d.attr == 'property')
                            for d in item.decorator_list
                        )
                        if is_property:
                            all_members.append((item.name, 'attribute', doc))
                        else:
                            all_members.append((item.name, 'method', doc))
                    elif isinstance(item, ast.Assign):
                        for target in item.targets:
                            if isinstance(target, ast.Name) and not target.id.startswith('_'):
                                all_members.append((target.id, 'attribute', 'class attribute'))
                    elif isinstance(item, ast.AnnAssign):
                        if isinstance(item.target, ast.Name) and not item.target.id.startswith('_'):
                            all_members.append((item.target.id, 'attribute', 'class attribute'))

                # 递归收集基类的成员
                for base in class_node.bases:
                    if isinstance(base, ast.Name):
                        base_name = base.id
                    elif isinstance(base, ast.Attribute):
                        base_name = base.attr
                    else:
                        continue
                    collect_members(base_name)

            # 开始收集
            collect_members(class_name)

            # 去重（保留第一个出现的）
            seen = set()
            unique_members = []
            for member in all_members:
                if member[0] not in seen:
                    seen.add(member[0])
                    unique_members.append(member)

            print(f"[DEBUG TYPE] Found {len(unique_members)} unique members for class '{class_name}'")
            return unique_members

        except Exception as e:
            print(f"[DEBUG TYPE] Exception in _get_class_members_static: {e}")
            return []

    def get_module_variable_type(self, module_name: str, var_name: str) -> Optional[str]:
        """
        从模块文件中查找模块级变量的类型

        Args:
            module_name: 模块名（如 'builtin'）
            var_name: 变量名（如 'SPAWN'）

        Returns:
            变量类型名或 None
        """
        try:

            # 构建模块文件路径
            base_dir = os.getcwd()

            if '.' in module_name:
                parts = module_name.split('.')
                module_dir = os.path.join(base_dir, *parts)
            else:
                module_dir = os.path.join(base_dir, module_name)

            # 收集要搜索的文件列表
            files_to_search = []

            # 1. 直接文件: module_name.py
            direct_file = module_dir + '.py'
            if os.path.exists(direct_file):
                files_to_search.append(direct_file)

            # 2. 包目录: module_name/__init__.py
            init_file = os.path.join(module_dir, '__init__.py')
            if os.path.exists(init_file):
                files_to_search.append(init_file)

            # 解析文件查找变量定义
            for file_path in files_to_search:
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    tree = ast.parse(content)

                    for node in ast.walk(tree):
                        # 查找模块级赋值: VAR = ...
                        if isinstance(node, ast.Assign):
                            for target in node.targets:
                                if isinstance(target, ast.Name) and target.id == var_name:
                                    # 推断类型
                                    var_type = self._infer_type_from_value(node.value)
                                    if var_type:
                                        return var_type
                                    # 如果推断失败，检查是否是类实例化
                                    if isinstance(node.value, ast.Call):
                                        if isinstance(node.value.func, ast.Name):
                                            return node.value.func.id
                                        elif isinstance(node.value.func, ast.Attribute):
                                            return node.value.func.attr
                                    # 处理 or 表达式: A or B
                                    elif isinstance(node.value, ast.BoolOp) and isinstance(node.value.op, ast.Or):
                                        # 取最后一个值（通常是默认值）
                                        if node.value.values:
                                            last_value = node.value.values[-1]
                                            if isinstance(last_value, ast.Call):
                                                if isinstance(last_value.func, ast.Name):
                                                    return last_value.func.id
                                                elif isinstance(last_value.func, ast.Attribute):
                                                    return last_value.func.attr
                        # 查找类型注解: VAR: Type
                        elif isinstance(node, ast.AnnAssign):
                            if isinstance(node.target, ast.Name) and node.target.id == var_name:
                                if isinstance(node.annotation, ast.Name):
                                    return node.annotation.id
                                elif isinstance(node.annotation, ast.Attribute):
                                    return node.annotation.attr

                except Exception:
                    continue

        except Exception:
            pass

        return None

    def _infer_type_from_value(self, node: ast.AST) -> Optional[str]:
        """从 AST 节点推断值的类型"""
        if isinstance(node, ast.Num):
            return 'int' if isinstance(node.n, int) else 'float'
        elif isinstance(node, ast.Str):
            return 'str'
        elif isinstance(node, ast.Constant):
            if isinstance(node.value, str):
                return 'str'
            elif isinstance(node.value, int):
                return 'int'
            elif isinstance(node.value, float):
                return 'float'
            elif isinstance(node.value, list):
                return 'list'
            elif isinstance(node.value, dict):
                return 'dict'
        elif isinstance(node, ast.List):
            return 'list'
        elif isinstance(node, ast.Dict):
            return 'dict'
        elif isinstance(node, ast.Tuple):
            return 'tuple'
        elif isinstance(node, ast.Set):
            return 'set'
        elif isinstance(node, ast.BoolOp):
            # 处理 or 表达式: A or B，尝试推断右侧的类型（通常是默认值）
            # 如: SPAWN = get.spawn(...) or Point(0, 0)
            if node.values:
                return self._infer_type_from_value(node.values[-1])
        return None


class SelfAnalyzer:
    """self分析器 - 专门分析类中的self属性和方法"""
    
    def __init__(self):
        self._class_cache: Dict[str, Dict[str, Any]] = {}
    
    def analyze_class(self, code: str, class_name: str = None) -> Dict[str, Any]:
        """
        分析类定义，提取属性和方法
        
        Args:
            code: 代码字符串
            class_name: 类名（可选，用于指定分析哪个类）
            
        Returns:
            {
                'attributes': {name: {'type': str, 'line': int}},
                'methods': {name: {'args': [...], 'line': int, 'docstring': str}},
                'class_attributes': {name: {...}},
                'bases': [...]
            }
        """
        cache_key = str(hash(code)) if not class_name else f"{hash(code)}_{class_name}"
        if cache_key in self._class_cache:
            return self._class_cache[cache_key]

        result = {
            'attributes': {},
            'methods': {},
            'class_attributes': {},
            'bases': []
        }

        try:
            tree = ast.parse(code)

            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    if class_name and node.name != class_name:
                        continue

                    # 记录基类
                    result['bases'] = [self._get_name(base) for base in node.bases]

                    # 分析类体
                    for item in node.body:
                        # 类属性（直接在类体中的赋值）
                        if isinstance(item, ast.Assign):
                            for target in item.targets:
                                if isinstance(target, ast.Name):
                                    result['class_attributes'][target.id] = {
                                        'line': item.lineno,
                                        'value': self._get_value_repr(item.value)
                                    }
                        
                        # 类型注解的类属性
                        elif isinstance(item, ast.AnnAssign):
                            if isinstance(item.target, ast.Name):
                                result['class_attributes'][item.target.id] = {
                                    'line': item.lineno,
                                    'annotation': self._get_name(item.annotation) if item.annotation else None
                                }
                        
                        # 方法
                        elif isinstance(item, ast.FunctionDef):
                            method_info = self._analyze_method(item)
                            result['methods'][item.name] = method_info
                            
                            # 分析方法中的self赋值（实例属性）
                            self._analyze_self_attributes(item, result['attributes'])

                    break  # 找到目标类后退出

        except SyntaxError:
            pass

        self._class_cache[cache_key] = result
        return result
    
    def _analyze_method(self, node: ast.FunctionDef) -> Dict:
        """分析方法定义"""
        return {
            'name': node.name,
            'args': [arg.arg for arg in node.args.args],
            'defaults': len(node.args.defaults),
            'vararg': node.args.vararg.arg if node.args.vararg else None,
            'kwarg': node.args.kwarg.arg if node.args.kwarg else None,
            'line': node.lineno,
            'docstring': ast.get_docstring(node),
            'decorators': [self._get_name(d) for d in node.decorator_list]
        }
    
    def _analyze_self_attributes(self, method_node: ast.FunctionDef, 
                                  attributes: Dict[str, Dict]):
        """分析方法中的self.xxx赋值"""
        for node in ast.walk(method_node):
            if isinstance(node, ast.Attribute):
                if isinstance(node.value, ast.Name) and node.value.id == 'self':
                    if node.attr not in attributes:
                        attributes[node.attr] = {
                            'line': getattr(node, 'lineno', 0),
                            'type': 'unknown'
                        }
            
            # 更精确的分析：找到self.xxx = ...的赋值
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Attribute):
                        if isinstance(target.value, ast.Name) and target.value.id == 'self':
                            attr_name = target.attr
                            attr_type = self._infer_type(node.value)
                            attributes[attr_name] = {
                                'line': getattr(node, 'lineno', 0),
                                'type': attr_type
                            }
            
            # 类型注解的实例属性
            elif isinstance(node, ast.AnnAssign):
                if isinstance(node.target, ast.Attribute):
                    if isinstance(node.target.value, ast.Name) and node.target.value.id == 'self':
                        attr_name = node.target.attr
                        annotation = self._get_name(node.annotation) if node.annotation else 'Any'
                        attributes[attr_name] = {
                            'line': getattr(node, 'lineno', 0),
                            'type': annotation
                        }
    
    def _infer_type(self, node: Optional[ast.expr]) -> str:
        """推断表达式类型"""
        if node is None:
            return "Any"
        
        if isinstance(node, ast.Num):
            return "int" if isinstance(node.n, int) else "float"
        elif isinstance(node, ast.Str):
            return "str"
        elif isinstance(node, ast.List):
            return "list"
        elif isinstance(node, ast.Dict):
            return "dict"
        elif isinstance(node, ast.Set):
            return "set"
        elif isinstance(node, ast.Tuple):
            return "tuple"
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                return node.func.id
            elif isinstance(node.func, ast.Attribute):
                return node.func.attr
        elif isinstance(node, ast.NameConstant):
            return "bool" if isinstance(node.value, bool) else str(type(node.value).__name__)
        elif isinstance(node, ast.Constant):
            if isinstance(node.value, bool):
                return "bool"
            elif isinstance(node.value, (int, float)):
                return "int" if isinstance(node.value, int) else "float"
            elif isinstance(node.value, str):
                return "str"
            return type(node.value).__name__
        
        return "Any"
    
    def _get_name(self, node: ast.AST) -> str:
        """获取节点名称"""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            return f"{self._get_name(node.value)}.{node.attr}"
        elif isinstance(node, ast.Subscript):
            return self._get_name(node.value)
        return str(node)
    
    def _get_value_repr(self, node: ast.expr) -> str:
        """获取值的字符串表示"""
        if isinstance(node, ast.Num):
            return str(node.n)
        elif isinstance(node, ast.Str):
            return repr(node.s)
        elif isinstance(node, ast.NameConstant):
            return str(node.value)
        elif isinstance(node, ast.Constant):
            return repr(node.value)
        elif isinstance(node, ast.Name):
            return node.id
        return "..."
    
    def get_self_completions(self, code: str, prefix: str = "") -> List[CompletionItem]:
        """
        获取self.的补全项
        
        Args:
            code: 代码字符串
            prefix: 前缀过滤
            
        Returns:
            补全项列表
        """
        completions = []
        class_info = self.analyze_class(code)

        # 添加类属性
        for name, info in class_info['class_attributes'].items():
            if name.startswith(prefix) and not name.startswith('_'):
                completions.append(CompletionItem(
                    text=name,
                    display=f"⚡ {name}",
                    item_type='attribute',
                    detail=f"Class attribute (line {info.get('line', 0)})",
                    priority=95
                ))
        
        # 添加实例属性
        for name, info in class_info['attributes'].items():
            if name.startswith(prefix) and not name.startswith('_'):
                type_info = info.get('type', 'unknown')
                completions.append(CompletionItem(
                    text=name,
                    display=f"🟢 {name}: {type_info}",
                    item_type='attribute',
                    detail=f"Instance attribute ({type_info})",
                    priority=90
                ))
        
        # 添加方法
        for name, info in class_info['methods'].items():
            if name.startswith(prefix) and not name.startswith('_'):
                args_str = ', '.join(info['args'][1:])  # 排除self
                completions.append(CompletionItem(
                    text=name,
                    display=f"🟠 {name}({args_str})",
                    item_type='method',
                    detail=info.get('docstring', '')[:50] if info.get('docstring') else None,
                    priority=85
                ))
        
        return completions
    
    def clear_cache(self):
        """清除缓存"""
        self._class_cache.clear()


class CodeCompleter(QObject):
    """代码补全管理器 - 增强版"""
    
    completion_requested = pyqtSignal(str, int)  # 补全请求信号 (text, cursor_pos)
    completion_ready = pyqtSignal(list)  # 补全结果就绪信号
    
    # 类型图标映射
    TYPE_ICONS = {
        'keyword': '🔷',
        'function': '🔶',
        'method': '🟠',
        'class': '🟦',
        'variable': '🟡',
        'attribute': '🟢',
        'builtin': '🔵',
        'module': '📦',
        'property': '⚡',
        'parameter': '🔹',
    }
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._context_code_a: str = ""  # 隐藏代码A (类定义)
        self._context_code_b: str = ""  # 隐藏代码B (函数定义)
        self._prefix_code: str = ""     # 前缀代码（缩进等）
        
        # Python关键字
        self._keywords = [
            'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue',
            'def', 'del', 'elif', 'else', 'except', 'False', 'finally', 'for',
            'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'None',
            'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'True', 'try',
            'while', 'with', 'yield'
        ]
        
        # Python内置函数
        self._builtins = dir(builtins)
        
        # 常用模块
        self._common_modules = [
            'os', 'sys', 're', 'json', 'collections', 'itertools', 'functools',
            'datetime', 'time', 'math', 'random', 'typing', 'pathlib', 'inspect'
        ]
        
        # 缓存机制
        self._cached_completions: Dict[str, List[CompletionItem]] = {}
        self._cache_timestamp: Dict[str, float] = {}
        self._cache_ttl = 30  # 缓存有效期（秒）
        
        # 导入解析器
        self._import_resolver = ImportResolver()
        
        # self分析器
        self._self_analyzer = SelfAnalyzer()
        
        # 从CA解析的导入符号
        self._star_imports: Dict[str, List[str]] = {}
        self._imported_modules: Dict[str, str] = {}  # name -> module
    
    def set_context_code(self, code_a: str = "", code_b: str = "", prefix: str = ""):
        """
        设置上下文代码

        Args:
            code_a: 隐藏的类定义代码 (CA)
            code_b: 隐藏的函数定义代码 (CB)
            prefix: 前缀代码（用于缩进）
        """
        print(f"[CodeCompleter.set_context_code] Setting context code")
        print(f"[CodeCompleter.set_context_code] code_a length: {len(code_a)}")
        print(f"[CodeCompleter.set_context_code] code_b length: {len(code_b)}")
        print(f"[CodeCompleter.set_context_code] prefix: {repr(prefix)}")

        self._context_code_a = code_a
        self._context_code_b = code_b
        self._prefix_code = prefix

        # 清除缓存
        self._cached_completions.clear()
        self._cache_timestamp.clear()

        # 解析CA中的导入
        self._parse_imports_from_ca()
        print(f"[CodeCompleter.set_context_code] Star imports: {list(self._star_imports.keys())}")
        for module, names in self._star_imports.items():
            print(f"[CodeCompleter.set_context_code]   {module}: {len(names)} symbols")

        # 清除分析器缓存
        self._self_analyzer.clear_cache()
        self._import_resolver.clear_cache()
    
    def _parse_imports_from_ca(self):
        """从CA代码中解析导入语句"""
        self._star_imports.clear()
        self._imported_modules.clear()

        if not self._context_code_a:
            print("[_parse_imports_from_ca] No CA code")
            return

        print(f"[_parse_imports_from_ca] Parsing CA code ({len(self._context_code_a)} chars)")
        print(f"[_parse_imports_from_ca] CA first 100 chars: {repr(self._context_code_a[:100])}")

        try:
            # 替换 <__begin__> 占位符，使代码可解析
            clean_code = self._context_code_a.replace('<__begin__>', '        pass')
            tree = ast.parse(clean_code)
            print(f"[_parse_imports_from_ca] AST parsed successfully")

            import_count = 0
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom):
                    import_count += 1
                    module = node.module or ""
                    print(f"[_parse_imports_from_ca] Found ImportFrom: from {module} import {[a.name for a in node.names]}")

                    # 检查是否是from xxx import *
                    for alias in node.names:
                        if alias.name == '*':
                            print(f"[_parse_imports_from_ca] Resolving star import from: {module}")
                            # 解析星号导入
                            imported_names = self._import_resolver.resolve_star_import(module)
                            print(f"[_parse_imports_from_ca] Resolved {len(imported_names)} names from {module}")
                            self._star_imports[module] = imported_names
                            for name in imported_names:
                                self._imported_modules[name] = module
                        else:
                            # 普通导入
                            name = alias.asname if alias.asname else alias.name
                            self._imported_modules[name] = module

                elif isinstance(node, ast.Import):
                    import_count += 1
                    print(f"[_parse_imports_from_ca] Found Import: {[a.name for a in node.names]}")
                    for alias in node.names:
                        name = alias.asname if alias.asname else alias.name
                        self._imported_modules[name] = alias.name

            print(f"[_parse_imports_from_ca] Total imports found: {import_count}")

        except SyntaxError as e:
            print(f"[_parse_imports_from_ca] SyntaxError: {e}")
        except Exception as e:
            print(f"[_parse_imports_from_ca] Exception: {e}")
    
    def get_completions(self, text: str, cursor_pos: int) -> List[CompletionItem]:
        """
        获取补全建议 - 优化版本
        
        Args:
            text: 当前编辑器中的代码
            cursor_pos: 光标位置
            
        Returns:
            补全项列表
        """
        start_time = time()
        
        # 构建完整代码用于分析
        full_code = self._build_full_code(text)
        
        # 获取当前词
        current_word = self._get_current_word(text, cursor_pos)
        
        # 获取光标前的上下文
        context = self._get_context(text, cursor_pos)
        
        # 检查缓存
        cache_key = f"{hash(full_code)}_{current_word}_{context.get('object_name', '')}"
        if cache_key in self._cached_completions:
            timestamp = self._cache_timestamp.get(cache_key, 0)
            if time() - timestamp < self._cache_ttl:
                return self._cached_completions[cache_key]
        
        completions = []

        # 1. 如果是属性访问，优先处理
        if context['after_dot'] and context['object_name']:
            completions.extend(self._get_attribute_completions(
                full_code, context['object_name'], current_word,
                is_subscript=context.get('is_subscript', False),
                is_chained_call=context.get('is_chained_call', False)
            ))
        else:
            # 2. 添加关键字
            completions.extend(self._get_keyword_completions(current_word))
            
            # 3. 添加内置函数
            completions.extend(self._get_builtin_completions(current_word))
            
            # 4. 添加星号导入的符号
            completions.extend(self._get_star_import_completions(current_word))
            
            # 5. 从上下文代码分析补全
            completions.extend(self._get_context_completions(full_code, current_word, context))
        
        # 去重并排序
        seen = set()
        unique_completions = []
        for item in completions:
            key = (item.text, item.item_type)
            if key not in seen:
                seen.add(key)
                unique_completions.append(item)
        
        # 按优先级排序，优先显示完全匹配和开头匹配的项（区分大小写）
        def sort_key(item):
            # 完全匹配（区分大小写）排最前面
            if item.text == current_word:
                match_score = 0
            # 完全匹配（不区分大小写）排第二
            elif item.text.lower() == current_word.lower():
                match_score = 1
            # 开头匹配（区分大小写）排第三
            elif item.text.startswith(current_word):
                match_score = 2
            # 开头匹配（不区分大小写）排第四
            elif item.text.lower().startswith(current_word.lower()):
                match_score = 3
            # 其他
            else:
                match_score = 4

            # 检查是否全大写（用于 self. 补全时的排序）
            is_all_upper = 1 if item.text.isupper() and len(item.text) > 1 else 0

            # 排序优先级：
            # 1. match_score（匹配程度）
            # 2. -priority（补全项优先级，高的在前）
            # 3. is_all_upper（全大写的排在最后）
            # 4. first_char（首字符字母顺序）
            # 5. len(text)（字符串长度，短的在前）
            # 6. text.lower()（字母顺序）
            first_char = item.text[0].lower() if item.text else ''
            return (match_score, -item.priority, is_all_upper, first_char, len(item.text), item.text.lower())

        unique_completions.sort(key=sort_key)
        
        # 缓存结果
        self._cached_completions[cache_key] = unique_completions
        self._cache_timestamp[cache_key] = time()
        
        # 性能监控（调试用）
        elapsed = time() - start_time
        if elapsed > 0.1:  # 超过100ms的慢查询
            print(f"[Completer] Slow completion: {elapsed*1000:.1f}ms")
        
        return unique_completions
    
    def _build_full_code(self, text: str) -> str:
        """构建完整代码（包含上下文，替换 <__begin__> 占位符）"""
        # 添加前缀缩进
        prefix = self._prefix_code if self._prefix_code else "    "
        cc_lines = []
        for line in text.splitlines():
            cc_lines.append(prefix + line)
        cc_code = '\n'.join(cc_lines)

        # 如果有 CA，直接替换其中的 <__begin__>
        if self._context_code_a:
            full_code = self._context_code_a.replace('<__begin__>', cc_code)
        elif self._context_code_b:
            # 兼容旧格式：使用 CB
            full_code = self._context_code_b.replace('<__begin__>', cc_code)
        else:
            full_code = cc_code

        return full_code
    
    def _get_current_word(self, text: str, cursor_pos: int) -> str:
        """获取光标处的当前词"""
        if cursor_pos <= 0:
            return ""
        
        # 向前查找词的开始
        start = cursor_pos - 1
        while start >= 0 and (text[start].isalnum() or text[start] == '_'):
            start -= 1
        start += 1
        
        return text[start:cursor_pos]
    
    def _get_context(self, text: str, cursor_pos: int) -> Dict[str, Any]:
        """获取代码上下文信息"""
        context = {
            'after_dot': False,
            'object_name': '',
            'in_string': False,
            'in_comment': False,
        }
        
        # 检查是否在字符串或注释中
        line_start = text.rfind('\n', 0, cursor_pos) + 1
        line = text[line_start:cursor_pos]
        
        if '#' in line:
            comment_pos = line.find('#')
            if comment_pos >= 0:
                context['in_comment'] = True
        
        # 检查点号访问（支持 self.attr 或 self. 后的输入）
        if cursor_pos > 0:
            # 向前查找，跳过当前词（如果有）
            check_pos = cursor_pos - 1
            while check_pos >= 0 and (text[check_pos].isalnum() or text[check_pos] == '_'):
                check_pos -= 1

            # 跳过空白
            while check_pos >= 0 and text[check_pos].isspace():
                check_pos -= 1

            # 检查是否是点号
            if check_pos >= 0 and text[check_pos] == '.':
                context['after_dot'] = True
                # 获取点号前的完整表达式（支持链式调用如 get.creep()）
                expr_end = check_pos
                expr_start = expr_end - 1

                # 处理括号平衡（支持方法调用）
                paren_count = 0
                bracket_count = 0

                while expr_start >= 0:
                    char = text[expr_start]
                    if char == ')':
                        paren_count += 1
                    elif char == '(':
                        if paren_count > 0:
                            paren_count -= 1
                        else:
                            break  # 不匹配的左括号
                    elif char == ']':
                        bracket_count += 1
                    elif char == '[':
                        if bracket_count > 0:
                            bracket_count -= 1
                        else:
                            pass  # 可能允许 [ 作为表达式的一部分
                    elif char == '.' and paren_count == 0 and bracket_count == 0:
                        pass  # 作为链式调用的一部分
                    elif not (char.isalnum() or char == '_' or char == '.' or (paren_count > 0 or bracket_count > 0)):
                        # 遇到非标识符字符且不在括号内，停止
                        if paren_count == 0 and bracket_count == 0:
                            break

                    expr_start -= 1

                expr_start += 1
                full_expr = text[expr_start:expr_end].strip()
                context['object_name'] = full_expr
                context['is_chained_call'] = '.' in full_expr and '(' in full_expr

                print(f"[DEBUG CONTEXT] Expression before dot: '{full_expr}', chained: {context['is_chained_call']}")

                # 检查是否是下标访问（如 refs[0]. 或 get.creeps()[0].）
                # 优先检查字面量，然后再处理复杂表达式
                lit_start = check_pos - 1
                while lit_start >= 0 and text[lit_start].isspace():
                    lit_start -= 1

                if lit_start >= 0:
                    if text[lit_start] == ']':
                        # 找到了 ]，需要找到匹配的 [ 并提取前面的完整表达式
                        bracket_count = 1
                        i = lit_start - 1
                        while i >= 0 and bracket_count > 0:
                            if text[i] == ']':
                                bracket_count += 1
                            elif text[i] == '[':
                                bracket_count -= 1
                            i -= 1

                        if bracket_count == 0:
                            # 找到了匹配的 [，提取 [ 前面的完整表达式
                            # 使用与提取 object_name 相同的逻辑
                            expr_end = i  # i 指向 [ 前面的位置
                            expr_start = expr_end

                            # 处理括号平衡
                            paren_count = 0
                            inner_bracket_count = 0

                            while expr_start >= 0:
                                char = text[expr_start]
                                if char == ')':
                                    paren_count += 1
                                elif char == '(':
                                    if paren_count > 0:
                                        paren_count -= 1
                                    else:
                                        break
                                elif char == ']':
                                    inner_bracket_count += 1
                                elif char == '[':
                                    if inner_bracket_count > 0:
                                        inner_bracket_count -= 1
                                elif char == '.' and paren_count == 0 and inner_bracket_count == 0:
                                    pass  # 作为表达式的一部分
                                elif not (char.isalnum() or char == '_' or char == '.' or paren_count > 0 or inner_bracket_count > 0):
                                    if paren_count == 0 and inner_bracket_count == 0:
                                        break

                                expr_start -= 1

                            expr_start += 1
                            base_expr = text[expr_start:expr_end+1].strip()

                            if base_expr:
                                context['object_name'] = base_expr
                                context['is_subscript'] = True
                                print(f"[DEBUG CONTEXT] Found subscript access: {base_expr}[...]")
                            else:
                                # 简单变量名
                                i_end = i
                                while i_end >= 0 and text[i_end].isspace():
                                    i_end -= 1

                                i_start = i_end
                                while i_start >= 0 and (text[i_start].isalnum() or text[i_start] == '_'):
                                    i_start -= 1
                                i_start += 1

                                var_name = text[i_start:i_end+1].strip()
                                if var_name:
                                    context['object_name'] = var_name
                                    context['is_subscript'] = True
                                    print(f"[DEBUG CONTEXT] Found subscript access: {var_name}[...]")

                # 如果没有找到对象名，检查是否是字面量（如 [], {}, "", 123 等）
                if not context['object_name']:
                    lit_start = check_pos - 1
                    while lit_start >= 0 and text[lit_start].isspace():
                        lit_start -= 1

                    # 检查各种字面量
                    if lit_start >= 0:
                        char = text[lit_start]
                        if char == ']':
                            context['object_name'] = '__list_literal__'
                        elif char == '}':
                            context['object_name'] = '__dict_literal__'
                        elif char == '"' or char == "'":
                            context['object_name'] = '__str_literal__'
                        elif char.isdigit():
                            context['object_name'] = '__num_literal__'
                        # 检查元组 () - 需要向前找到匹配的括号
                        elif char == ')':
                            # 简单处理，假设是元组
                            context['object_name'] = '__tuple_literal__'

        return context
    
    def _get_keyword_completions(self, prefix: str) -> List[CompletionItem]:
        """获取关键字补全"""
        if not prefix:
            return []
        
        completions = []
        prefix_lower = prefix.lower()
        for kw in self._keywords:
            if kw.startswith(prefix_lower):
                completions.append(CompletionItem(
                    text=kw,
                    display=f"{self.TYPE_ICONS['keyword']} {kw}",
                    item_type='keyword',
                    priority=100
                ))
        return completions
    
    def _get_builtin_completions(self, prefix: str) -> List[CompletionItem]:
        """获取内置函数补全"""
        if not prefix:
            return []
        
        completions = []
        for name in self._builtins:
            if name.startswith(prefix) and not name.startswith('_'):
                try:
                    obj = getattr(builtins, name, None)
                    item_type = 'function' if callable(obj) else 'variable'
                    completions.append(CompletionItem(
                        text=name,
                        display=f"{self.TYPE_ICONS.get(item_type, '🔹')} {name}",
                        item_type=item_type,
                        priority=80
                    ))
                except Exception:
                    pass
        return completions
    
    def _get_star_import_completions(self, prefix: str) -> List[CompletionItem]:
        """获取星号导入的补全"""
        if not prefix:
            return []

        completions = []
        seen = set()  # 去重，避免与内置函数重复

        for module, names in self._star_imports.items():
            for name in names:
                if name.startswith(prefix) and name not in seen:
                    seen.add(name)
                    # 跳过 Python 内置函数（避免与 _get_builtin_completions 重复）
                    if hasattr(builtins, name):
                        continue
                    # 尝试获取类型信息
                    try:
                        module_obj = sys.modules.get(module)
                        if module_obj:
                            obj = getattr(module_obj, name, None)
                            if inspect.isfunction(obj) or inspect.isbuiltin(obj):
                                item_type = 'function'
                                display = f"{self.TYPE_ICONS['function']} {name}()"
                            elif inspect.isclass(obj):
                                item_type = 'class'
                                display = f"{self.TYPE_ICONS['class']} {name}"
                            else:
                                item_type = 'variable'
                                display = f"{self.TYPE_ICONS['variable']} {name}"
                        else:
                            item_type = 'variable'
                            display = f"📦 {name}"
                    except Exception:
                        item_type = 'variable'
                        display = f"📦 {name}"
                    
                    completions.append(CompletionItem(
                        text=name,
                        display=display,
                        item_type=item_type,
                        detail=f"from {module} import *",
                        priority=85
                    ))
        
        return completions
    
    def _get_context_completions(self, code: str, prefix: str,
                                  context: Dict[str, Any]) -> List[CompletionItem]:
        """从代码上下文获取补全（包括CA中的代码）"""
        if not prefix:
            return []

        completions = []
        seen_names = set()  # 去重

        # 解析的代码列表：当前编辑器代码 + CA代码
        codes_to_parse = [code]
        if self._context_code_a:
            # 用有效函数体替换 <__begin__> 使CA可解析
            clean_ca = self._context_code_a.replace('<__begin__>', '        pass')
            codes_to_parse.append(clean_ca)

        for code_text in codes_to_parse:
            try:
                tree = ast.parse(code_text)

                # 收集定义的变量、函数、类
                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef):
                        if node.name.startswith(prefix) and node.name not in seen_names:
                            seen_names.add(node.name)
                            completions.append(CompletionItem(
                                text=node.name,
                                display=f"{self.TYPE_ICONS['function']} {node.name}()",
                                item_type='function',
                                priority=90
                            ))
                        # 添加参数
                        for arg in node.args.args:
                            if arg.arg.startswith(prefix) and arg.arg not in seen_names:
                                seen_names.add(arg.arg)
                                completions.append(CompletionItem(
                                    text=arg.arg,
                                    display=f"{self.TYPE_ICONS['parameter']} {arg.arg}",
                                    item_type='parameter',
                                    priority=85
                                ))
                        # 添加 *args 和 **kwargs
                        if node.args.vararg and node.args.vararg.arg.startswith(prefix):
                            if node.args.vararg.arg not in seen_names:
                                seen_names.add(node.args.vararg.arg)
                                completions.append(CompletionItem(
                                    text=node.args.vararg.arg,
                                    display=f"{self.TYPE_ICONS['parameter']} *{node.args.vararg.arg}",
                                    item_type='parameter',
                                    priority=85
                                ))
                        if node.args.kwarg and node.args.kwarg.arg.startswith(prefix):
                            if node.args.kwarg.arg not in seen_names:
                                seen_names.add(node.args.kwarg.arg)
                                completions.append(CompletionItem(
                                    text=node.args.kwarg.arg,
                                    display=f"{self.TYPE_ICONS['parameter']} **{node.args.kwarg.arg}",
                                    item_type='parameter',
                                    priority=85
                                ))

                    elif isinstance(node, ast.ClassDef):
                        if node.name.startswith(prefix) and node.name not in seen_names:
                            seen_names.add(node.name)
                            completions.append(CompletionItem(
                                text=node.name,
                                display=f"{self.TYPE_ICONS['class']} {node.name}",
                                item_type='class',
                                priority=90
                            ))

                        # 类方法
                        for item in node.body:
                            if isinstance(item, ast.FunctionDef):
                                if item.name.startswith(prefix) and item.name not in seen_names:
                                    seen_names.add(item.name)
                                    completions.append(CompletionItem(
                                        text=item.name,
                                        display=f"{self.TYPE_ICONS['method']} {item.name}()",
                                        item_type='method',
                                        priority=85
                                    ))

                    elif isinstance(node, ast.Assign):
                        for target in node.targets:
                            if isinstance(target, ast.Name):
                                if target.id.startswith(prefix) and target.id not in seen_names:
                                    seen_names.add(target.id)
                                    completions.append(CompletionItem(
                                        text=target.id,
                                        display=f"{self.TYPE_ICONS['variable']} {target.id}",
                                        item_type='variable',
                                        priority=96  # 局部变量优先级最高
                                    ))

            except SyntaxError:
                pass

        return completions
    
    def _get_subscript_element_completions(self, var_name: str, prefix: str) -> List[CompletionItem]:
        """
        获取下标访问的元素类型补全（如 refs[0]. 或 get.creeps()[0]. 中的元素类型成员）

        Args:
            var_name: 变量名或表达式（如 'refs' 或 'get.creeps()'）
            prefix: 前缀过滤

        Returns:
            元素类型的成员补全
        """
        completions = []
        print(f"[DEBUG SUBSCRIPT] Analyzing subscript for: '{var_name}'")

        # 系统性类型推断：先推断表达式的类型，再提取元素类型
        container_type = self._infer_expression_type_systematic(var_name)

        if container_type:
            print(f"[DEBUG SUBSCRIPT] Container type for '{var_name}': {container_type}")
            # 从容器类型提取元素类型
            element_type = self._extract_element_type(container_type)
            if element_type:
                print(f"[DEBUG SUBSCRIPT] Element type: {element_type}")
                completions.extend(self._get_builtin_type_completions(element_type, prefix))
                print(f"[DEBUG SUBSCRIPT] Found {len(completions)} completions for element type '{element_type}'")
            else:
                # 无法提取元素类型，返回容器本身的补全（如 list 的方法）
                completions.extend(self._get_builtin_type_completions(container_type, prefix))
        else:
            # 回退到原来的逻辑：检查 vararg
            completions.extend(self._get_vararg_element_completions(var_name, prefix))

        return completions

    def _infer_expression_type_systematic(self, expr: str) -> Optional[str]:
        """
        系统性类型推断引擎

        分析表达式并返回其类型，支持：
        - 简单变量（如 'refs', 'get'）
        - 方法调用（如 'get.creeps()'）
        - 属性访问（如 'get.creep'）

        Args:
            expr: 表达式字符串

        Returns:
            类型名称，如 'list', 'List[Creep]', 'CreepLogic' 等
        """
        expr = expr.strip()
        if not expr:
            return None

        print(f"[TYPE ENGINE] Analyzing: '{expr}'")

        # 解析表达式
        parsed = self._parse_expression_structure(expr)
        if not parsed:
            return None

        # 根据解析结果推断类型
        return self._resolve_parsed_type(parsed)

    def _parse_expression_structure(self, expr: str) -> Optional[Dict]:
        """
        解析表达式为结构化表示

        例如:
        - 'refs' -> {'kind': 'variable', 'name': 'refs'}
        - 'get.creeps()' -> {'kind': 'call', 'receiver': 'get', 'method': 'creeps'}
        - 'get.creep' -> {'kind': 'attr', 'receiver': 'get', 'attr': 'creep'}
        """
        expr = expr.strip()

        # 方法调用: xxx.yyy()
        if expr.endswith(')'):
            paren_depth = 0
            paren_pos = -1
            for i in range(len(expr) - 1, -1, -1):
                if expr[i] == ')':
                    paren_depth += 1
                elif expr[i] == '(':
                    paren_depth -= 1
                    if paren_depth == 0:
                        paren_pos = i
                        break

            if paren_pos > 0:
                before = expr[:paren_pos].strip()
                if '.' in before:
                    dot_pos = before.rfind('.')
                    return {
                        'kind': 'call',
                        'receiver': before[:dot_pos].strip(),
                        'method': before[dot_pos + 1:].strip()
                    }
                else:
                    return {'kind': 'call', 'receiver': None, 'method': before}

        # 属性访问: xxx.yyy
        if '.' in expr:
            dot_pos = expr.rfind('.')
            return {
                'kind': 'attr',
                'receiver': expr[:dot_pos].strip(),
                'attr': expr[dot_pos + 1:].strip()
            }

        # 简单变量
        if expr.isidentifier():
            return {'kind': 'variable', 'name': expr}

        return None

    def _resolve_parsed_type(self, parsed: Dict) -> Optional[str]:
        """根据解析结果解析类型"""
        kind = parsed.get('kind')

        if kind == 'variable':
            return self._resolve_variable_type_systematic(parsed['name'])

        elif kind == 'call':
            receiver = parsed.get('receiver')
            method = parsed['method']
            if receiver:
                receiver_type = self._resolve_parsed_type(self._parse_expression_structure(receiver))
                if receiver_type:
                    return self._resolve_method_return_type_systematic(receiver_type, method)
            return None

        elif kind == 'attr':
            receiver = parsed.get('receiver')
            attr = parsed['attr']
            if receiver:
                receiver_type = self._resolve_parsed_type(self._parse_expression_structure(receiver))
                if receiver_type:
                    return self._resolve_attribute_type_systematic(receiver_type, attr)
            return None

        return None

    def _resolve_variable_type_systematic(self, var_name: str) -> Optional[str]:
        """查找变量的类型注解（系统性版本）"""
        codes_to_check = []
        if self._context_code_a:
            codes_to_check.append(self._context_code_a.replace('<__begin__>', '        pass'))
        if self._context_code_b:
            codes_to_check.append(self._context_code_b.replace('<__begin__>', '        pass'))

        # 1. 在上下文代码中查找参数注解
        for code_text in codes_to_check:
            try:
                tree = ast.parse(code_text)
                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef):
                        for arg in node.args.args:
                            if arg.arg == var_name and arg.annotation:
                                return self._extract_type_name_from_ast(arg.annotation)
                        if node.args.vararg and node.args.vararg.arg == var_name and node.args.vararg.annotation:
                            return self._extract_type_name_from_ast(node.args.vararg.annotation)
                        if node.args.kwarg and node.args.kwarg.arg == var_name and node.args.kwarg.annotation:
                            return self._extract_type_name_from_ast(node.args.kwarg.annotation)
            except SyntaxError:
                pass

        # 2. 在 star imports 中查找类定义
        for module_name in self._star_imports.keys():
            members = self._import_resolver.get_class_members(var_name, module_name)
            if members:
                return var_name  # 找到类定义

        return None

    def _resolve_method_return_type_systematic(self, class_type: str, method_name: str) -> Optional[str]:
        """查找类方法的返回类型（系统性版本）"""
        # 1. 首先在本地代码中查找
        codes_to_check = []
        if self._context_code_a:
            codes_to_check.append(self._context_code_a.replace('<__begin__>', '        pass'))

        for code_text in codes_to_check:
            try:
                tree = ast.parse(code_text)
                for node in ast.walk(tree):
                    if isinstance(node, ast.ClassDef):
                        for item in node.body:
                            if isinstance(item, ast.FunctionDef) and item.name == method_name:
                                if item.returns:
                                    return self._extract_type_name_from_ast(item.returns)
            except SyntaxError:
                pass

        # 2. 在 star imports 中查找
        return self._get_return_type_from_static_analysis(class_type, method_name, 'builtin')

    def _resolve_attribute_type_systematic(self, class_type: str, attr_name: str) -> Optional[str]:
        """查找类属性的类型"""
        # 简化处理，返回类名（假设属性是类实例）
        return class_type

    def _extract_element_type(self, container_type: str) -> Optional[str]:
        """
        从容器类型中提取元素类型
        例如: List[Creep] -> Creep, list[Creep] -> Creep
        """
        if not container_type:
            return None

        # 匹配泛型类型
        match = re.match(r'(?:List|list|Set|set|FrozenSet)\[(\w+)\]', container_type)
        if match:
            return match.group(1)

        # tuple[CreepLogic, ...] -> CreepLogic
        match = re.match(r'(?:Tuple|tuple)\[(\w+)', container_type)
        if match:
            return match.group(1)

        # Dict[str, Creep] -> Creep (值类型)
        match = re.match(r'(?:Dict|dict)\[\w+,\s*(\w+)\]', container_type)
        if match:
            return match.group(1)

        return None

    def _extract_type_name_from_ast(self, annotation: ast.AST) -> Optional[str]:
        """从 AST 注解节点提取类型名称"""
        if isinstance(annotation, ast.Name):
            return annotation.id
        elif isinstance(annotation, ast.Constant):
            return annotation.value
        elif isinstance(annotation, ast.Str):
            return annotation.s
        elif isinstance(annotation, ast.Attribute):
            return f"{annotation.value.id}.{annotation.attr}"
        elif isinstance(annotation, ast.Subscript):
            if isinstance(annotation.value, ast.Name):
                container = annotation.value.id
                if isinstance(annotation.slice, ast.Name):
                    return f"{container}[{annotation.slice.id}]"
                elif isinstance(annotation.slice, ast.Constant):
                    return f"{container}[{annotation.slice.value}]"
                elif isinstance(annotation.slice, ast.Str):
                    return f"{container}[{annotation.slice.s}]"
                else:
                    return f"{container}[...]"
        elif isinstance(annotation, ast.BinOp):
            # 联合类型如 Creep | None
            if isinstance(annotation.left, ast.Name):
                return annotation.left.id
            elif isinstance(annotation.left, ast.Attribute):
                return f"{annotation.left.value.id}.{annotation.left.attr}"
        return None

    def _get_vararg_element_completions(self, var_name: str, prefix: str) -> List[CompletionItem]:
        """
        回退方法：检查 vararg（*args）的元素类型
        """
        completions = []
        codes_to_check = []
        if self._context_code_a:
            codes_to_check.append(self._context_code_a.replace('<__begin__>', '        pass'))
        if self._context_code_b:
            codes_to_check.append(self._context_code_b.replace('<__begin__>', '        pass'))

        element_type = None

        for code_text in codes_to_check:
            try:
                tree = ast.parse(code_text)
                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef):
                        if node.args.vararg and node.args.vararg.arg == var_name:
                            annotation = node.args.vararg.annotation
                            if annotation:
                                if isinstance(annotation, ast.Constant):
                                    element_type = annotation.value
                                elif isinstance(annotation, ast.Str):
                                    element_type = annotation.s
                                elif isinstance(annotation, ast.Name):
                                    element_type = annotation.id
                            break
                    if element_type:
                        break
            except SyntaxError:
                pass

        if element_type:
            completions.extend(self._get_builtin_type_completions(element_type, prefix))

        return completions

    def _get_chained_call_completions(self, expr: str, prefix: str) -> List[CompletionItem]:
        """
        获取链式调用的补全（如 get.creep().）

        Args:
            expr: 表达式（如 'get.creep()'）
            prefix: 前缀过滤

        Returns:
            方法返回类型的成员补全
        """
        print(f"[DEBUG CHAIN] Analyzing chained expression: '{expr}'")
        completions = []

        # 尝试在上下文中查找方法定义
        codes_to_check = []
        if self._context_code_a:
            codes_to_check.append(self._context_code_a.replace('<__begin__>', '        pass'))
        if self._context_code_b:
            codes_to_check.append(self._context_code_b.replace('<__begin__>', '        pass'))

        # 提取方法名（最后一个 . 后面到 ( 之前的部分）
        # 例如 get.creep() -> creep
        method_name = None
        receiver = None
        if '.' in expr and '(' in expr:
            # 找到最后一个 . 后面到 ( 之前的部分
            paren_pos = expr.rfind('(')
            dot_pos = expr.rfind('.', 0, paren_pos)
            if dot_pos > 0 and paren_pos > dot_pos:
                method_name = expr[dot_pos+1:paren_pos].strip()
                receiver = expr[:dot_pos].strip()
                print(f"[DEBUG CHAIN] Method: '{method_name}', Receiver: '{receiver}'")

        if not method_name:
            return completions

        return_type = None

        # 1. 首先在本地代码中查找
        for code_text in codes_to_check:
            if return_type:
                break
            try:
                tree = ast.parse(code_text)
                for node in ast.walk(tree):
                    if isinstance(node, ast.ClassDef):
                        for item in node.body:
                            if isinstance(item, ast.FunctionDef) and item.name == method_name:
                                # 找到了方法，检查返回类型注解
                                if item.returns:
                                    if isinstance(item.returns, ast.Name):
                                        return_type = item.returns.id
                                    elif isinstance(item.returns, ast.Constant):
                                        return_type = item.returns.value
                                    elif isinstance(item.returns, ast.Str):
                                        return_type = item.returns.s
                                    elif isinstance(item.returns, ast.Attribute):
                                        return_type = f"{item.returns.value.id}.{item.returns.attr}"
                                    print(f"[DEBUG CHAIN] Found return type for '{method_name}' in local code: {return_type}")
                                    break
                    if return_type:
                        break
            except SyntaxError:
                pass

        # 2. 如果没有找到，尝试从 star imports 中查找
        if not return_type and receiver:
            print(f"[DEBUG CHAIN] Not found in local code, trying star imports for receiver '{receiver}'")
            return_type = self._get_method_return_type_from_star_imports(receiver, method_name)
            if return_type:
                print(f"[DEBUG CHAIN] Found return type from star imports: {return_type}")

        if return_type:
            # 对于 List[Creep] 这样的返回类型，提供 list 的补全
            # 只有当用户输入 get.creeps()[0]. 时才提供 Creep 的补全
            completions.extend(self._get_builtin_type_completions(return_type, prefix))
            print(f"[DEBUG CHAIN] Found {len(completions)} completions for return type '{return_type}'")

        return completions

    def _get_method_return_type_from_star_imports(self, class_name: str, method_name: str) -> Optional[str]:
        """
        从 star import 的模块中查找类的方法返回类型

        Args:
            class_name: 类名（如 'get'）
            method_name: 方法名（如 'creep'）

        Returns:
            返回类型名称，如果没有找到则返回 None
        """
        print(f"[DEBUG STAR METHOD] Looking for {class_name}.{method_name} return type in star imports")

        for module_name in self._star_imports.keys():
            print(f"[DEBUG STAR METHOD] Checking module: {module_name}")
            try:
                # 使用 ImportResolver 获取类成员
                members = self._import_resolver.get_class_members(class_name, module_name)
                if members:
                    print(f"[DEBUG STAR METHOD] Found class '{class_name}' with {len(members)} members in '{module_name}'")
                    # 类成员包含方法和属性，我们需要静态分析来获取方法的返回类型
                    # 尝试通过静态分析获取
                    return_type = self._get_return_type_from_static_analysis(class_name, method_name, module_name)
                    if return_type:
                        return return_type
            except Exception as e:
                print(f"[DEBUG STAR METHOD] Error checking module {module_name}: {e}")

        return None

    def _get_return_type_from_static_analysis(self, class_name: str, method_name: str, module_name: str) -> Optional[str]:
        """
        静态分析模块文件获取方法的返回类型注解

        Args:
            class_name: 类名
            method_name: 方法名
            module_name: 模块名

        Returns:
            返回类型名称，如果没有找到则返回 None
        """
        try:

            # 构建模块文件路径
            base_dir = os.getcwd()
            if '.' in module_name:
                parts = module_name.split('.')
                module_path = os.path.join(base_dir, *parts) + '.py'
            else:
                module_path = os.path.join(base_dir, module_name + '.py')

            # 检查是否存在包目录
            module_dir = os.path.join(base_dir, module_name)
            init_file = os.path.join(module_dir, '__init__.py')

            files_to_search = []
            if os.path.exists(module_path):
                files_to_search.append(module_path)
            if os.path.exists(init_file):
                files_to_search.append(init_file)

            # 也在模块目录下查找子模块
            if os.path.isdir(module_dir):
                for sub_file in os.listdir(module_dir):
                    if sub_file.endswith('.py') and not sub_file.startswith('_'):
                        files_to_search.append(os.path.join(module_dir, sub_file))

            print(f"[DEBUG STATIC] Searching {class_name}.{method_name} in {len(files_to_search)} files")

            for file_path in files_to_search:
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()

                    tree = ast.parse(content)

                    for node in ast.walk(tree):
                        if isinstance(node, ast.ClassDef) and node.name == class_name:
                            for item in node.body:
                                if isinstance(item, ast.FunctionDef) and item.name == method_name:
                                    # 找到了方法，获取返回类型
                                    if item.returns:
                                        if isinstance(item.returns, ast.Name):
                                            return item.returns.id
                                        elif isinstance(item.returns, ast.Constant):
                                            return item.returns.value
                                        elif isinstance(item.returns, ast.Str):
                                            return item.returns.s
                                        elif isinstance(item.returns, ast.Subscript):
                                            # 处理 List[Type] 等情况
                                            if isinstance(item.returns.value, ast.Name):
                                                container_type = item.returns.value.id
                                                # 尝试获取元素类型
                                                element_type = None
                                                if isinstance(item.returns.slice, ast.Name):
                                                    element_type = item.returns.slice.id
                                                elif isinstance(item.returns.slice, ast.Constant):
                                                    element_type = item.returns.slice.value
                                                elif isinstance(item.returns.slice, ast.Str):
                                                    element_type = item.returns.slice.s

                                                if element_type:
                                                    return f"{container_type}[{element_type}]"
                                                else:
                                                    return f"{container_type}[...]"
                                        elif isinstance(item.returns, ast.Attribute):
                                            return f"{item.returns.value.id}.{item.returns.attr}"
                                        elif isinstance(item.returns, ast.BinOp):
                                            # 处理联合类型如 Creep | None
                                            # 返回左边的类型（通常是实际类型，不是 None）
                                            if isinstance(item.returns.left, ast.Name):
                                                left_type = item.returns.left.id
                                                # 如果左边是 None，返回右边
                                                if left_type == 'None' and isinstance(item.returns.right, ast.Name):
                                                    return item.returns.right.id
                                                return left_type
                                            elif isinstance(item.returns.left, ast.Attribute):
                                                return f"{item.returns.left.value.id}.{item.returns.left.attr}"
                                    return None
                except Exception as e:
                    continue

        except Exception as e:
            print(f"[DEBUG STATIC] Error: {e}")

        return None

    def _extract_element_type_from_generic(self, type_str: str) -> Optional[str]:
        """
        从泛型类型字符串中提取元素类型
        例如：List[Creep] -> Creep, List[Point] -> Point

        Args:
            type_str: 类型字符串（如 'List[...]'）

        Returns:
            元素类型名称，如果不是泛型则返回 None
        """
        if not type_str:
            return None

        # 匹配 List[...] 或 list[...]
        match = re.match(r'(?:List|list)\[(\w+)\]', type_str)
        if match:
            return match.group(1)

        # 也处理 Set[...], Dict[...] 等
        match = re.match(r'(?:Set|set)\[(\w+)\]', type_str)
        if match:
            return match.group(1)

        return None

    def _get_attribute_completions(self, code: str, object_name: str,
                                    prefix: str, is_subscript: bool = False,
                                    is_chained_call: bool = False) -> List[CompletionItem]:
        """获取对象属性补全 - 增强版"""
        completions = []

        # 如果是下标访问（如 refs[0].），需要获取元素类型的成员
        if is_subscript:
            element_completions = self._get_subscript_element_completions(object_name, prefix)
            if element_completions:
                return element_completions

        # 处理链式调用（如 get.creep().）
        print(f"[DEBUG ATTR] object_name='{object_name}', is_chained_call={is_chained_call}, has_dot={'/' in object_name}, has_paren={'(' in object_name}")
        if is_chained_call or ('.' in object_name and '(' in object_name):
            print(f"[DEBUG ATTR] Calling _get_chained_call_completions for '{object_name}'")
            chained_completions = self._get_chained_call_completions(object_name, prefix)
            print(f"[DEBUG ATTR] _get_chained_call_completions returned {len(chained_completions)} completions")
            if chained_completions:
                return chained_completions

        # 特殊对象处理：self
        if object_name == 'self':
            # 使用 CA (code_a) 来分析类结构
            # 不能用包含当前输入的完整代码，因为可能包含语法错误（如 self.）
            class_code = self._context_code_a if self._context_code_a else code
            # 用有效的函数体替换 <__begin__>，获得可解析的类定义
            clean_code = class_code.replace('<__begin__>', '        pass')
            # 清除缓存，确保分析最新代码
            self._self_analyzer.clear_cache()
            self_completions = self._self_analyzer.get_self_completions(clean_code, prefix)
            completions.extend(self_completions)

            # 同时获取基类（如 CreepLogic）的成员
            try:
                tree = ast.parse(clean_code)
                for node in ast.walk(tree):
                    if isinstance(node, ast.ClassDef):
                        for base in node.bases:
                            # 获取基类名称
                            if isinstance(base, ast.Name):
                                base_name = base.id
                            elif isinstance(base, ast.Attribute):
                                base_name = base.attr
                            else:
                                continue
                            # 从 star imports 中查找基类
                            for module in self._star_imports.keys():
                                base_members = self._import_resolver.get_class_members(base_name, module)
                                if base_members:
                                    print(f"[DEBUG SELF] Found base class '{base_name}' with {len(base_members)} members")
                                    for name, member_type, doc in base_members:
                                        if name.startswith(prefix) and not name.startswith('_') and not any(c.text == name for c in completions):
                                            if member_type == 'method':
                                                completions.append(CompletionItem(
                                                    text=name,
                                                    display=f"{self.TYPE_ICONS['method']} {name}()",
                                                    item_type='method',
                                                    detail=f"from {base_name}: {doc[:50] if doc else 'method'}",
                                                    priority=90
                                                ))
                                            else:
                                                completions.append(CompletionItem(
                                                    text=name,
                                                    display=f"{self.TYPE_ICONS['attribute']} {name}",
                                                    item_type='attribute',
                                                    detail=f"from {base_name}: {doc if doc else 'attribute'}",
                                                    priority=95
                                                ))
                                    break
                        break
            except Exception as e:
                print(f"[DEBUG SELF] Error getting base class members: {e}")

        # 字面量处理
        elif object_name == '__list_literal__':
            completions.extend(self._get_builtin_type_completions('list', prefix))
        elif object_name == '__dict_literal__':
            completions.extend(self._get_builtin_type_completions('dict', prefix))
        elif object_name == '__tuple_literal__':
            completions.extend(self._get_builtin_type_completions('tuple', prefix))
        elif object_name == '__str_literal__':
            completions.extend(self._get_builtin_type_completions('str', prefix))
            
            # 额外的AST分析确保不遗漏
            try:
                # 使用 code_a 分析类（干净的类定义代码）
                analysis_code = self._context_code_a if self._context_code_a else code
                # 替换 <__begin__> 使代码可解析
                analysis_code = analysis_code.replace('<__begin__>', '        pass')
                tree = ast.parse(analysis_code)
                for node in ast.walk(tree):
                    if isinstance(node, ast.ClassDef):
                        # 收集类属性
                        for item in node.body:
                            if isinstance(item, ast.Assign):
                                for target in item.targets:
                                    if isinstance(target, ast.Name):
                                        if target.id.startswith(prefix) and not any(c.text == target.id for c in completions):
                                            completions.append(CompletionItem(
                                                text=target.id,
                                                display=f"{self.TYPE_ICONS['attribute']} {target.id}",
                                                item_type='attribute',
                                                priority=95
                                            ))
                            elif isinstance(item, ast.FunctionDef):
                                if item.name.startswith(prefix) and not item.name.startswith('_') and not any(c.text == item.name for c in completions):
                                    completions.append(CompletionItem(
                                        text=item.name,
                                        display=f"{self.TYPE_ICONS['method']} {item.name}()",
                                        item_type='method',
                                        priority=90
                                    ))
            except SyntaxError:
                pass
        
        # 处理导入的模块
        elif object_name in self._imported_modules:
            module_name = self._imported_modules[object_name]
            try:
                members = self._import_resolver.get_module_members(module_name)
                for name, type_str, obj in members:
                    if name.startswith(prefix) and not name.startswith('_'):
                        if type_str == 'function':
                            display = f"{self.TYPE_ICONS['function']} {name}()"
                            item_type = 'function'
                        elif type_str == 'class':
                            display = f"{self.TYPE_ICONS['class']} {name}"
                            item_type = 'class'
                        else:
                            display = f"{self.TYPE_ICONS['variable']} {name}"
                            item_type = 'variable'
                        
                        completions.append(CompletionItem(
                            text=name,
                            display=display,
                            item_type=item_type,
                            detail=f"from {module_name}",
                            priority=85
                        ))
            except Exception:
                pass
        
        # 尝试从代码中获取对象类型并提供类型推断补全
        if object_name != 'self':
            print(f"[DEBUG TYPE] Getting type infer for '{object_name}'")
            # 尝试使用编辑器代码推断类型，但处理不完整的语法
            type_completions = self._get_type_infer_completions(code, object_name, prefix)
            print(f"[DEBUG TYPE] Type infer returned {len(type_completions)} items")
            completions.extend(type_completions)

        return completions

    def _get_type_infer_completions(self, code: str, object_name: str, prefix: str) -> List[CompletionItem]:
        """基于类型推断获取补全"""
        completions = []

        # 尝试解析代码，处理不完整的语法
        tree = None
        code_to_parse = code

        # 尝试解析，如果失败则逐行去掉最后一行再试
        for attempt in range(5):  # 最多尝试5次
            try:
                tree = ast.parse(code_to_parse)
                break
            except SyntaxError:
                # 去掉最后一行
                lines = code_to_parse.rstrip().split('\n')
                if len(lines) <= 1:
                    break
                code_to_parse = '\n'.join(lines[:-1])

        if tree is None:
            return completions

        try:
            # 查找变量赋值或函数参数注解，推断类型
            var_type = None
            assign_count = 0

            # 首先检查函数参数的类型注解（包括CA和CB代码中的）
            codes_to_check = [code_to_parse]
            if self._context_code_a:
                # 清理CA代码使其可解析
                clean_ca = self._context_code_a.replace('<__begin__>', '        pass')
                codes_to_check.append(clean_ca)
            if self._context_code_b:
                # 清理CB代码使其可解析
                clean_cb = self._context_code_b.replace('<__begin__>', '        pass')
                codes_to_check.append(clean_cb)

            for code_text in codes_to_check:
                try:
                    check_tree = ast.parse(code_text)
                    for node in ast.walk(check_tree):
                        if isinstance(node, ast.FunctionDef):
                            # 检查普通参数
                            for arg in node.args.args:
                                if arg.arg == object_name and arg.annotation:
                                    # 获取类型注解的名称
                                    if isinstance(arg.annotation, ast.Name):
                                        var_type = arg.annotation.id
                                        print(f"[DEBUG TYPE] Found param annotation for '{object_name}': {var_type}")
                                    elif isinstance(arg.annotation, ast.Attribute):
                                        var_type = f"{arg.annotation.value.id}.{arg.annotation.attr}"
                                        print(f"[DEBUG TYPE] Found param annotation for '{object_name}': {var_type}")
                                    break

                            # 检查可变参数 *args
                            if not var_type and node.args.vararg:
                                if node.args.vararg.arg == object_name and node.args.vararg.annotation:
                                    annotation = node.args.vararg.annotation
                                    if isinstance(annotation, ast.Name):
                                        var_type = annotation.id
                                        print(f"[DEBUG TYPE] Found vararg annotation for '{object_name}': {var_type}")
                                    elif isinstance(annotation, ast.Constant):
                                        var_type = annotation.value
                                        print(f"[DEBUG TYPE] Found vararg annotation for '{object_name}': {var_type}")
                                    elif isinstance(annotation, ast.Str):  # Python 3.7 compatibility
                                        var_type = annotation.s
                                        print(f"[DEBUG TYPE] Found vararg annotation for '{object_name}': {var_type}")
                                    elif isinstance(annotation, ast.Attribute):
                                        var_type = f"{annotation.value.id}.{annotation.attr}"
                                        print(f"[DEBUG TYPE] Found vararg annotation for '{object_name}': {var_type}")

                            # 检查关键字可变参数 **kwargs
                            if not var_type and node.args.kwarg:
                                if node.args.kwarg.arg == object_name and node.args.kwarg.annotation:
                                    annotation = node.args.kwarg.annotation
                                    if isinstance(annotation, ast.Name):
                                        var_type = annotation.id
                                        print(f"[DEBUG TYPE] Found kwarg annotation for '{object_name}': {var_type}")
                                    elif isinstance(annotation, ast.Constant):
                                        var_type = annotation.value
                                        print(f"[DEBUG TYPE] Found kwarg annotation for '{object_name}': {var_type}")

                            if var_type:
                                break
                    if var_type:
                        break
                except SyntaxError:
                    pass

            # 如果没有找到参数注解，再检查赋值语句
            if not var_type:
                for node in ast.walk(tree):
                    if isinstance(node, ast.Assign):
                        assign_count += 1
                        for target in node.targets:
                            target_name = getattr(target, 'id', None)
                            print(f"[DEBUG TYPE] Checking assignment #{assign_count}: target={target_name}")
                            if isinstance(target, ast.Name) and target.id == object_name:
                                var_type = self._infer_type(node.value)
                                print(f"[DEBUG TYPE] Found assignment for '{object_name}', type={var_type}")
                                break
                        if var_type:
                            break

            print(f"[DEBUG TYPE] Total assignments found: {assign_count}")

            # 根据类型获取内置方法/属性
            if var_type:
                # 检查是否是 vararg (*args) - 这种情况下类型是 tuple[ElementType]
                is_vararg = False
                for code_text in codes_to_check:
                    try:
                        check_tree = ast.parse(code_text)
                        for node in ast.walk(check_tree):
                            if isinstance(node, ast.FunctionDef):
                                if node.args.vararg and node.args.vararg.arg == object_name:
                                    is_vararg = True
                                    print(f"[DEBUG TYPE] '{object_name}' is a vararg, type is tuple[{var_type}]")
                                    break
                            if is_vararg:
                                break
                    except SyntaxError:
                        pass

                if is_vararg:
                    # *args 是 tuple[ElementType]，只提供元组方法
                    # 要访问元素类型成员，应该用 refs[0].
                    completions.extend(self._get_builtin_type_completions('tuple', prefix))
                else:
                    # 普通类型
                    completions.extend(self._get_builtin_type_completions(var_type, prefix))
            else:
                # 在本地代码中找不到类型，尝试从 star imports 中查找
                print(f"[DEBUG TYPE] Could not infer type for '{object_name}' from local code, trying star imports...")
                star_import_completions = self._get_star_import_class_completions(object_name, prefix)
                if star_import_completions:
                    completions.extend(star_import_completions)
                    print(f"[DEBUG TYPE] Found {len(star_import_completions)} completions from star imports for '{object_name}'")
                else:
                    print(f"[DEBUG TYPE] Could not infer type for '{object_name}'")

        except Exception as e:
            print(f"[DEBUG TYPE] Exception: {e}")

        return completions

    def _get_star_import_class_completions(self, class_name: str, prefix: str) -> List[CompletionItem]:
        """
        从 star import 的模块中查找类定义或模块级变量并返回成员补全

        Args:
            class_name: 类名或变量名（如 'get' 或 'SPAWN'）
            prefix: 前缀过滤

        Returns:
            成员补全列表
        """
        completions = []
        print(f"[DEBUG STAR] Looking for class/variable '{class_name}' in star imports")

        # 首先尝试查找类定义
        for module_name in self._star_imports.keys():
            print(f"[DEBUG STAR] Checking module: {module_name}")
            members = self._import_resolver.get_class_members(class_name, module_name)
            if members:
                print(f"[DEBUG STAR] Found {len(members)} members for class '{class_name}' in '{module_name}'")
                for name, member_type, doc in members:
                    if name.startswith(prefix) and not name.startswith('_'):
                        if member_type == 'method':
                            completions.append(CompletionItem(
                                text=name,
                                display=f"{self.TYPE_ICONS['method']} {name}()",
                                item_type='method',
                                detail=doc[:50] if doc else 'method',
                                priority=85
                            ))
                        else:
                            completions.append(CompletionItem(
                                text=name,
                                display=f"{self.TYPE_ICONS['attribute']} {name}",
                                item_type='attribute',
                                detail=doc if doc else 'attribute',
                                priority=95
                            ))
                return completions  # 找到了类，直接返回

        # 如果不是类，尝试作为模块级变量查找其类型
        print(f"[DEBUG STAR] Class not found, trying to find variable type for '{class_name}'")
        var_type = self._get_variable_type_from_star_imports(class_name)
        print(f"[DEBUG STAR] Variable '{class_name}' type: {var_type}")
        if var_type:
            print(f"[DEBUG STAR] Variable '{class_name}' has type '{var_type}', getting completions")
            # 获取该类型的成员补全
            return self._get_type_completions_from_star_imports(var_type, prefix)

        print(f"[DEBUG STAR] Could not find type for '{class_name}'")
        return completions

    def _get_variable_type_from_star_imports(self, var_name: str) -> Optional[str]:
        """
        从 star import 的模块中查找模块级变量的类型

        Args:
            var_name: 变量名（如 'SPAWN'）

        Returns:
            变量类型名或 None
        """
        for module_name in self._star_imports.keys():
            var_type = self._import_resolver.get_module_variable_type(module_name, var_name)
            if var_type:
                return var_type
        return None

    def _get_type_completions_from_star_imports(self, type_name: str, prefix: str) -> List[CompletionItem]:
        """
        从 star import 的模块中获取指定类型的成员补全

        Args:
            type_name: 类型名（如 'Point'）
            prefix: 前缀过滤

        Returns:
            成员补全列表
        """
        completions = []

        # 首先尝试作为类查找成员
        for module_name in self._star_imports.keys():
            members = self._import_resolver.get_class_members(type_name, module_name)
            if members:
                for name, member_type, doc in members:
                    if name.startswith(prefix) and not name.startswith('_'):
                        if member_type == 'method':
                            completions.append(CompletionItem(
                                text=name,
                                display=f"{self.TYPE_ICONS['method']} {name}()",
                                item_type='method',
                                detail=doc[:50] if doc else 'method',
                                priority=85
                            ))
                        else:
                            completions.append(CompletionItem(
                                text=name,
                                display=f"{self.TYPE_ICONS['attribute']} {name}",
                                item_type='attribute',
                                detail=doc if doc else 'attribute',
                                priority=95
                            ))
                return completions

        # 如果不是类，尝试作为内置类型处理
        return self._get_builtin_type_completions(type_name, prefix)

    def _infer_type(self, node: ast.AST) -> Optional[str]:
        """推断表达式类型"""
        node_type = type(node).__name__
        print(f"[DEBUG TYPE] _infer_type: node_type={node_type}")

        if isinstance(node, ast.List):
            print(f"[DEBUG TYPE] Detected list")
            return 'list'
        elif isinstance(node, ast.Dict):
            return 'dict'
        elif isinstance(node, ast.Str):
            return 'str'
        elif isinstance(node, ast.Num):
            return 'int' if isinstance(node.n, int) else 'float'
        elif isinstance(node, ast.Constant):
            if isinstance(node.value, str):
                return 'str'
            elif isinstance(node.value, int):
                return 'int'
            elif isinstance(node.value, float):
                return 'float'
            elif isinstance(node.value, list):
                return 'list'
            elif isinstance(node.value, dict):
                return 'dict'
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                func_name = node.func.id
                type_map = {
                    'list': 'list',
                    'dict': 'dict',
                    'str': 'str',
                    'int': 'int',
                    'float': 'float',
                    'set': 'set',
                    'tuple': 'tuple',
                }
                return type_map.get(func_name)
        return None

    def _get_builtin_type_completions(self, type_name: str, prefix: str) -> List[CompletionItem]:
        """获取内置类型的方法和属性"""
        completions = []
        prefix_lower = prefix.lower()

        # list 类型的方法
        list_methods = [
            ('append', '添加元素到列表末尾'),
            ('extend', '扩展列表'),
            ('insert', '插入元素'),
            ('remove', '移除元素'),
            ('pop', '弹出元素'),
            ('clear', '清空列表'),
            ('index', '查找索引'),
            ('count', '计数'),
            ('sort', '排序'),
            ('reverse', '反转'),
            ('copy', '复制列表'),
        ]

        # dict 类型的方法
        dict_methods = [
            ('keys', '获取所有键'),
            ('values', '获取所有值'),
            ('items', '获取所有键值对'),
            ('get', '获取值'),
            ('pop', '弹出键值'),
            ('popitem', '弹出最后键值'),
            ('update', '更新字典'),
            ('clear', '清空字典'),
            ('setdefault', '设置默认值'),
            ('copy', '复制字典'),
        ]

        # str 类型的方法
        str_methods = [
            ('upper', '转大写'),
            ('lower', '转小写'),
            ('title', '标题化'),
            ('strip', '去除空白'),
            ('split', '分割'),
            ('join', '连接'),
            ('replace', '替换'),
            ('find', '查找'),
            ('startswith', '是否以...开头'),
            ('endswith', '是否以...结尾'),
            ('format', '格式化'),
        ]

        # tuple 类型的方法
        tuple_methods = [
            ('count', '计数'),
            ('index', '查找索引'),
        ]

        type_methods = {
            'list': list_methods,
            'dict': dict_methods,
            'str': str_methods,
            'tuple': tuple_methods,
        }

        # 处理泛型类型如 List[Creep] -> 映射到 list
        actual_type = type_name
        if type_name and '[' in type_name:
            # 提取容器类型，如 List[Creep] -> List
            container = type_name.split('[')[0].lower()
            if container in ('list', 'dict', 'set', 'tuple'):
                actual_type = container
                print(f"[DEBUG BUILTIN] Mapped generic type '{type_name}' to '{actual_type}'")

        methods = type_methods.get(actual_type, [])
        for name, detail in methods:
            if name.lower().startswith(prefix_lower):
                completions.append(CompletionItem(
                    text=name,
                    display=f"{self.TYPE_ICONS['method']} {name}()",
                    item_type='method',
                    detail=detail,
                    priority=85
                ))

        # 如果不是内置类型，尝试从 star imports 中查找类成员
        if not methods:
            print(f"[DEBUG TYPE] Looking for class '{type_name}' in star imports: {list(self._star_imports.keys())}")
            # 查找类型来自哪个模块
            type_module = None
            for module, names in self._star_imports.items():
                print(f"[DEBUG TYPE] Checking module '{module}' with {len(names)} names")
                if type_name in names:
                    type_module = module
                    print(f"[DEBUG TYPE] Found '{type_name}' in module '{module}'")
                    break

            # 尝试从模块中获取类成员
            if type_module:
                members = self._import_resolver.get_class_members(type_name, type_module)
                print(f"[DEBUG TYPE] get_class_members returned {len(members)} members")
            else:
                # 尝试所有 star import 的模块
                print(f"[DEBUG TYPE] Type '{type_name}' not found in star imports, trying all modules")
                members = []
                for module in self._star_imports.keys():
                    members = self._import_resolver.get_class_members(type_name, module)
                    if members:
                        print(f"[DEBUG TYPE] Found {len(members)} members in module '{module}'")
                        break

            # 添加类成员到补全 - 属性(property)优先于方法
            for name, member_type, doc in members:
                if name.lower().startswith(prefix_lower):
                    if member_type == 'method':
                        completions.append(CompletionItem(
                            text=name,
                            display=f"{self.TYPE_ICONS['method']} {name}()",
                            item_type='method',
                            detail=doc[:50] if doc else 'method',
                            priority=85  # 方法优先级较低
                        ))
                    else:
                        # 属性（包括@property）优先级更高
                        completions.append(CompletionItem(
                            text=name,
                            display=f"{self.TYPE_ICONS['attribute']} {name}",
                            item_type='attribute',
                            detail=doc if doc else 'attribute',
                            priority=95  # 属性优先级更高，显示更靠前
                        ))

        return completions


class SmartCompleter(QCompleter):
    """智能补全器 - 增强的QCompleter"""
    
    activated_item = pyqtSignal(object)  # 发送CompletionItem对象
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # 创建自定义模型
        self._model = QStringListModel()
        self.setModel(self._model)
        
        # 补全项列表
        self._completion_items: List[CompletionItem] = []
        
        # 设置补全模式
        self.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.setFilterMode(Qt.MatchFlag.MatchStartsWith)
        
        # 设置弹出窗口样式
        self._setup_popup_style()
        
        # 连接信号
        self.activated.connect(self._on_activated)
        
        # 最大显示项数
        self.setMaxVisibleItems(15)
    
    def _setup_popup_style(self):
        """设置弹出窗口样式"""
        popup = self.popup()
        if popup:
            popup.setStyleSheet("""
                QListView {
                    background-color: #ffffff;
                    border: 1px solid #cccccc;
                    border-radius: 4px;
                    padding: 2px;
                    font-family: Consolas, monospace;
                    font-size: 12px;
                }
                QListView::item {
                    padding: 3px 8px;
                    border-radius: 2px;
                }
                QListView::item:selected {
                    background-color: #5a9bd5;
                    color: white;
                }
                QListView::item:hover {
                    background-color: #e8f4fc;
                }
            """)
            popup.setFrameShape(QFrame.Shape.StyledPanel)
            popup.setFrameShadow(QFrame.Shadow.Plain)
            popup.setMinimumWidth(220)
            popup.setMaximumWidth(400)
            popup.setMaximumHeight(350)
    
    def set_completion_items(self, items: List[CompletionItem]):
        """设置补全项"""
        self._completion_items = items
        
        # 更新模型
        display_list = [item.display for item in items]
        self._model.setStringList(display_list)
    
    def get_current_item(self) -> Optional[CompletionItem]:
        """获取当前选中的补全项"""
        popup = self.popup()
        if popup is None:
            return None
        current_row = popup.currentIndex().row()
        if 0 <= current_row < len(self._completion_items):
            return self._completion_items[current_row]
        return None
    
    def _on_activated(self, text: str):
        """补全项被激活"""
        item = self.get_current_item()
        if item:
            self.activated_item.emit(item)
    
    def update_completions(self, items: List[CompletionItem], rect: QRect = None):
        """更新补全列表

        Args:
            items: 补全项列表
            rect: 弹窗位置矩形，默认为空（由调用方后续调用 complete(rect)）
        """
        self.set_completion_items(items)

        # 如果有补全项，显示弹出窗口
        if items:
            self.complete(rect if rect else QRect())
            # 默认选中第一项
            popup = self.popup()
            if popup:
                popup.setCurrentIndex(self._model.index(0, 0))
                # 如果提供了位置，强制移动弹窗到该位置
                if rect:
                    global_pos = self.widget().mapToGlobal(rect.topLeft())
                    popup.move(global_pos)
        else:
            popup = self.popup()
            if popup:
                popup.hide()


class CompletionWorker(QThread):
    """后台补全计算工作线程"""
    
    completions_ready = pyqtSignal(list)
    
    def __init__(self, completer: CodeCompleter):
        super().__init__()
        self._completer = completer
        self._text = ""
        self._cursor_pos = 0
        self._running = False
    
    def set_params(self, text: str, cursor_pos: int):
        """设置参数"""
        self._text = text
        self._cursor_pos = cursor_pos
    
    def run(self):
        """运行补全计算"""
        self._running = True
        completions = self._completer.get_completions(self._text, self._cursor_pos)
        if self._running:
            self.completions_ready.emit(completions)
    
    def stop(self):
        """停止工作线程"""
        self._running = False
        self.wait(50)  # 减少等待时间
