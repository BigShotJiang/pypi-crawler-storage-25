"""
PyEdit测试脚本
"""

from pyedit import PythonEditor, PythonEditorFactory
from pyedit import CodeEditor
from pyedit import PythonSyntaxHighlighter
from pyedit import CodeCompleter, SmartCompleter, CompletionItem
from pyedit import ContextAnalyzer, CodeContext
from pyedit import CodeFolder, FoldRegion
from pyedit import LineNumberArea
from pyedit import MinimapPanel, MinimapWidget


import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel
from PyQt6.QtCore import Qt

# 测试导入
try:
    print("✓ PythonEditor 导入成功")
except ImportError as e:
    print(f"✗ PythonEditor 导入失败: {e}")
    sys.exit(1)

try:
    print("✓ CodeEditor 导入成功")
except ImportError as e:
    print(f"✗ CodeEditor 导入失败: {e}")

try:
    print("✓ PythonSyntaxHighlighter 导入成功")
except ImportError as e:
    print(f"✗ PythonSyntaxHighlighter 导入失败: {e}")

try:
    print("✓ Completer 导入成功")
except ImportError as e:
    print(f"✗ Completer 导入失败: {e}")

try:
    print("✓ ContextAnalyzer 导入成功")
except ImportError as e:
    print(f"✗ ContextAnalyzer 导入失败: {e}")

try:
    print("✓ CodeFolder 导入成功")
except ImportError as e:
    print(f"✗ CodeFolder 导入失败: {e}")

try:
    print("✓ LineNumberArea 导入成功")
except ImportError as e:
    print(f"✗ LineNumberArea 导入失败: {e}")

try:
    print("✓ Minimap 导入成功")
except ImportError as e:
    print(f"✗ Minimap 导入失败: {e}")


class TestWindow(QWidget):
    """测试窗口"""
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("PyEdit 功能测试")
        self.setMinimumSize(1000, 700)
        
        layout = QVBoxLayout(self)
        
        # 说明标签
        info = QLabel("PyEdit 功能测试 - 测试上下文代码功能")
        info.setStyleSheet("font-size: 14px; font-weight: bold; padding: 10px;")
        layout.addWidget(info)
        
        # 创建编辑器
        self.editor = PythonEditor()
        
        # 设置上下文代码（模拟节点编辑器的场景）
        code_a = '''class DialogueNode(BaseNode):
    """对话节点"""
    
    NODE_TYPE = "dialogue"
    NAME = "Dialogue"
    
    speaker = ""
    text = ""
    choices = []
    
    def __init__(self):
        super().__init__()
        self.connections = []
        self.variables = {}
    
    def on_enter(self):
        """进入节点"""
        print(f"Entering: {self.text}")
    
    def on_exit(self):
        """离开节点"""
        print(f"Exiting: {self.text}")
'''
        
        code_b = '''def handle_connection(self, context: GameContext, player: Player, *args):
    """处理连接"""
    result = None
    selected_choice = None
'''
        
        prefix = "        "  # 8空格缩进
        
        self.editor.set_context_code(code_a, code_b, prefix)
        
        # 设置初始代码
        initial_code = '''# 在这里编辑代码
# 可用的变量: context, player, result, selected_choice
# 可用的self属性: speaker, text, choices, connections, variables

# 示例：显示对话选项
for i, choice in enumerate(self.choices):
    print(f"{i+1}. {choice}")

# 获取玩家选择
selected_choice = player.get_input()

# 根据选择设置结果
if selected_choice:
    result = f"choice_{selected_choice}"
else:
    result = "default"

return result
'''
        
        self.editor.set_code(initial_code)
        layout.addWidget(self.editor)
        
        # 测试按钮
        btn_layout = QVBoxLayout()
        
        btn_get_code = QPushButton("获取代码")
        btn_get_code.clicked.connect(self._get_code)
        btn_layout.addWidget(btn_get_code)
        
        btn_fold = QPushButton("折叠全部 (Ctrl+Shift+-)")
        btn_fold.clicked.connect(self.editor.fold_all)
        btn_layout.addWidget(btn_fold)
        
        btn_unfold = QPushButton("展开全部 (Ctrl+Shift++)")
        btn_unfold.clicked.connect(self.editor.unfold_all)
        btn_layout.addWidget(btn_unfold)
        
        layout.addLayout(btn_layout)
        
        # 结果显示
        self.result_label = QLabel("结果将显示在这里")
        self.result_label.setStyleSheet("""
            QLabel {
                background-color: #f0f0f0;
                border: 1px solid #cccccc;
                padding: 10px;
                font-family: Consolas, monospace;
            }
        """)
        layout.addWidget(self.result_label)
    
    def _get_code(self):
        """获取代码"""
        code = self.editor.get_code()
        # 只显示前200个字符
        display = code[:200] + "..." if len(code) > 200 else code
        self.result_label.setText(f"代码:\n{display}")


def main():
    """主函数"""
    app = QApplication(sys.argv)
    
    print("\n启动测试窗口...")
    
    window = TestWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
