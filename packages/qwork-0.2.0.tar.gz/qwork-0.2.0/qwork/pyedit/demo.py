"""
PyEdit演示程序
展示Python编辑器的各种功能
"""

from PyQt6.QtWidgets import QInputDialog


import sys
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, 
    QHBoxLayout, QPushButton, QLabel, QTextEdit, 
    QSplitter, QFrame, QMenuBar, QMenu, QStatusBar,
    QFileDialog, QMessageBox, QDialog, QDialogButtonBox
)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QFont, QAction, QKeySequence, QIcon

# 导入pyedit模块
from pyedit import PythonEditor, PythonEditorFactory


class DemoWindow(QMainWindow):
    """演示窗口"""
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("PyEdit - Python代码编辑器演示")
        self.setMinimumSize(1200, 800)
        self.resize(1400, 900)
        
        self._setup_ui()
        self._setup_menubar()
        self._setup_statusbar()
        self._setup_shortcuts()
        
        # 创建示例编辑器
        self._create_example_editor()
    
    def _setup_ui(self):
        """设置UI"""
        # 中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # 说明标签
        self._lbl_info = QLabel(
            "PyEdit - 支持上下文代码的Python编辑器 | "
            "快捷键: Ctrl++ 展开 | Ctrl+- 折叠 | Ctrl+Shift++ 展开全部 | Ctrl+Shift+- 折叠全部 | "
            "Ctrl+Space 代码补全"
        )
        self._lbl_info.setStyleSheet("""
            QLabel {
                background-color: #f0f0f0;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 8px 12px;
                font-size: 12px;
                color: #333333;
            }
        """)
        layout.addWidget(self._lbl_info)
        
        # 分割器
        splitter = QSplitter(Qt.Orientation.Vertical)
        
        # 上半部分：编辑器
        self._editor_frame = QFrame()
        self._editor_frame.setFrameShape(QFrame.Shape.StyledPanel)
        editor_layout = QVBoxLayout(self._editor_frame)
        editor_layout.setContentsMargins(0, 0, 0, 0)
        
        # 创建Python编辑器
        self._editor = PythonEditor()
        editor_layout.addWidget(self._editor)
        
        splitter.addWidget(self._editor_frame)
        
        # 下半部分：信息显示
        self._info_frame = QFrame()
        self._info_frame.setFrameShape(QFrame.Shape.StyledPanel)
        info_layout = QVBoxLayout(self._info_frame)
        info_layout.setContentsMargins(10, 10, 10, 10)
        
        # 上下文代码显示
        info_label = QLabel("上下文代码（隐藏但参与分析）:")
        info_label.setStyleSheet("font-weight: bold; color: #333333;")
        info_layout.addWidget(info_label)
        
        self._txt_context = QTextEdit()
        self._txt_context.setReadOnly(True)
        self._txt_context.setMaximumHeight(150)
        self._txt_context.setStyleSheet("""
            QTextEdit {
                background-color: #f8f8f8;
                border: 1px solid #dddddd;
                border-radius: 4px;
                padding: 8px;
                font-family: Consolas, monospace;
                font-size: 11px;
                color: #666666;
            }
        """)
        info_layout.addWidget(self._txt_context)
        
        # 按钮区域
        btn_layout = QHBoxLayout()
        
        self._btn_show_code = QPushButton("获取编辑器代码")
        self._btn_show_code.setToolTip("获取当前编辑器中的代码")
        self._btn_show_code.clicked.connect(self._show_current_code)
        btn_layout.addWidget(self._btn_show_code)
        
        self._btn_fold_all = QPushButton("折叠全部")
        self._btn_fold_all.setToolTip("Ctrl+Shift+-")
        self._btn_fold_all.clicked.connect(self._editor.fold_all)
        btn_layout.addWidget(self._btn_fold_all)
        
        self._btn_unfold_all = QPushButton("展开全部")
        self._btn_unfold_all.setToolTip("Ctrl+Shift++")
        self._btn_unfold_all.clicked.connect(self._editor.unfold_all)
        btn_layout.addWidget(self._btn_unfold_all)
        
        self._btn_new_example = QPushButton("新示例")
        self._btn_new_example.setToolTip("加载新的示例代码")
        self._btn_new_example.clicked.connect(self._load_new_example)
        btn_layout.addWidget(self._btn_new_example)
        
        btn_layout.addStretch()
        info_layout.addLayout(btn_layout)
        
        splitter.addWidget(self._info_frame)
        
        # 设置分割比例
        splitter.setSizes([600, 200])
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 0)
        
        layout.addWidget(splitter)
    
    def _setup_menubar(self):
        """设置菜单栏"""
        menubar = self.menuBar()
        
        # 文件菜单
        file_menu = menubar.addMenu("文件(&F)")
        
        new_action = QAction("新建(&N)", self)
        new_action.setShortcut(QKeySequence.StandardKey.New)
        new_action.triggered.connect(self._new_file)
        file_menu.addAction(new_action)
        
        open_action = QAction("打开(&O)...", self)
        open_action.setShortcut(QKeySequence.StandardKey.Open)
        open_action.triggered.connect(self._open_file)
        file_menu.addAction(open_action)
        
        save_action = QAction("保存(&S)", self)
        save_action.setShortcut(QKeySequence.StandardKey.Save)
        save_action.triggered.connect(self._save_file)
        file_menu.addAction(save_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("退出(&X)", self)
        exit_action.setShortcut(QKeySequence.StandardKey.Quit)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # 编辑菜单
        edit_menu = menubar.addMenu("编辑(&E)")
        
        undo_action = QAction("撤销(&U)", self)
        undo_action.setShortcut(QKeySequence.StandardKey.Undo)
        undo_action.triggered.connect(self._editor.get_editor().undo)
        edit_menu.addAction(undo_action)
        
        redo_action = QAction("重做(&R)", self)
        redo_action.setShortcut(QKeySequence.StandardKey.Redo)
        redo_action.triggered.connect(self._editor.get_editor().redo)
        edit_menu.addAction(redo_action)
        
        edit_menu.addSeparator()
        
        fold_action = QAction("折叠当前块", self)
        fold_action.setShortcut("Ctrl+-")
        fold_action.triggered.connect(self._editor.fold_current)
        edit_menu.addAction(fold_action)
        
        unfold_action = QAction("展开当前块", self)
        unfold_action.setShortcut("Ctrl++")
        unfold_action.triggered.connect(self._editor.unfold_current)
        edit_menu.addAction(unfold_action)
        
        # 示例菜单
        example_menu = menubar.addMenu("示例(&X)")
        
        basic_example = QAction("基础示例", self)
        basic_example.triggered.connect(lambda: self._load_example("basic"))
        example_menu.addAction(basic_example)
        
        class_example = QAction("类定义示例", self)
        class_example.triggered.connect(lambda: self._load_example("class"))
        example_menu.addAction(class_example)
        
        function_example = QAction("函数示例", self)
        function_example.triggered.connect(lambda: self._load_example("function"))
        example_menu.addAction(function_example)
        
        node_example = QAction("节点编辑示例", self)
        node_example.triggered.connect(lambda: self._load_example("node"))
        example_menu.addAction(node_example)
    
    def _setup_statusbar(self):
        """设置状态栏"""
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)
        self.statusbar.showMessage("就绪 - 使用 Ctrl+Space 触发代码补全")
    
    def _setup_shortcuts(self):
        """设置快捷键"""
        # 折叠快捷键
        pass  # 已在菜单中设置
    
    def _create_example_editor(self):
        """创建示例编辑器"""
        self._load_example("node")
    
    def _load_example(self, example_type: str):
        """加载示例"""
        if example_type == "basic":
            code_a = ""
            code_b = ""
            prefix = ""
            initial_code = '''# 欢迎使用 PyEdit
# 这是一个基础的Python编辑器示例

def hello_world():
    """打印问候语"""
    print("Hello, World!")
    return True

# 调用函数
hello_world()
'''
        
        elif example_type == "class":
            code_a = '''class Person:
    """人员类"""
    
    species = "Homo sapiens"
    
    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age
    
    def introduce(self):
        return f"My name is {self.name}, I am {self.age} years old."
'''
            code_b = ""
            prefix = ""
            initial_code = '''# 使用Person类
person = Person("Alice", 30)
print(person.introduce())
'''
        
        elif example_type == "function":
            code_a = ""
            code_b = '''def process_data(data: list, callback: callable = None):
    """处理数据"""
    results = []
    for item in data:
        processed = item * 2
        if callback:
            callback(processed)
        results.append(processed)
    return results
'''
            prefix = "    "
            initial_code = '''# 在函数内部编辑
# 可以使用callback和results等变量
if callback:
    callback(42)
'''
        
        elif example_type == "node":
            # 节点编辑示例（模拟node_widgets的用例）
            code_a = '''class DialogueNode(BaseNode):
    """对话节点"""
    
    NODE_TYPE = "dialogue"
    NAME = "Dialogue"
    
    # 节点属性
    speaker = ""
    text = ""
    choices = []
    
    def __init__(self):
        super().__init__()
        self.connections = []
        self.variables = {}
    
    def on_enter(self):
        """进入节点时调用"""
        print(f"Entering dialogue: {self.text}")
    
    def on_exit(self):
        """离开节点时调用"""
        print(f"Exiting dialogue: {self.text}")
'''
            code_b = '''def handle_connection(self, context: GameContext, player: Player, *args):
    """处理连接"""
    result = None
    selected_choice = None
'''
            prefix = "        "  # 8空格缩进
            initial_code = '''# 在这里编辑处理逻辑
# 可用的变量: context, player, result, selected_choice
# 可用的self属性: speaker, text, choices, connections, variables

# 显示对话选项
for i, choice in enumerate(self.choices):
    print(f"{i+1}. {choice}")

# 获取玩家选择
selected_choice = player.get_input()

# 根据选择设置结果
if selected_choice == "1":
    result = "option_1"
elif selected_choice == "2":
    result = "option_2"
else:
    result = "default"

# 返回结果
return result
'''
        
        else:
            code_a = ""
            code_b = ""
            prefix = ""
            initial_code = ""
        
        # 设置编辑器
        self._editor.set_context_code(code_a, code_b, prefix)
        self._editor.set_code(initial_code)
        
        # 更新上下文显示
        context_text = f"""=== 类定义代码 (CA) ===
{code_a if code_a else '(无)'}

=== 函数定义代码 (CB) ===
{code_b if code_b else '(无)'}

=== 前缀缩进 ===
{repr(prefix) if prefix else '(无)'}
"""
        self._txt_context.setText(context_text)
        
        self.statusbar.showMessage(f"已加载示例: {example_type}")
    
    def _load_new_example(self):
        """加载新示例"""
        
        examples = ["basic", "class", "function", "node"]
        example, ok = QInputDialog.getItem(
            self, "选择示例", "示例类型:", examples, 0, False
        )
        
        if ok and example:
            self._load_example(example)
    
    def _show_current_code(self):
        """显示当前代码"""
        code = self._editor.get_code()
        
        dialog = QDialog(self)
        dialog.setWindowTitle("当前编辑器代码")
        dialog.setMinimumSize(600, 400)
        
        layout = QVBoxLayout(dialog)
        
        text_edit = QTextEdit()
        text_edit.setPlainText(code)
        text_edit.setReadOnly(True)
        text_edit.setStyleSheet("""
            QTextEdit {
                background-color: #f8f8f8;
                border: 1px solid #dddddd;
                border-radius: 4px;
                padding: 8px;
                font-family: Consolas, monospace;
                font-size: 12px;
            }
        """)
        layout.addWidget(text_edit)
        
        btn_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        btn_box.rejected.connect(dialog.reject)
        layout.addWidget(btn_box)
        
        dialog.exec()
    
    def _new_file(self):
        """新建文件"""
        self._editor.clear()
        self.statusbar.showMessage("新建文件")
    
    def _open_file(self):
        """打开文件"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "打开Python文件", "", "Python文件 (*.py);;所有文件 (*.*)"
        )
        
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    code = f.read()
                self._editor.set_code(code)
                self.statusbar.showMessage(f"已打开: {file_path}")
            except Exception as e:
                QMessageBox.critical(self, "错误", f"无法打开文件:\n{str(e)}")
    
    def _save_file(self):
        """保存文件"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "保存Python文件", "", "Python文件 (*.py);;所有文件 (*.*)"
        )
        
        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(self._editor.get_code())
                self.statusbar.showMessage(f"已保存: {file_path}")
            except Exception as e:
                QMessageBox.critical(self, "错误", f"无法保存文件:\n{str(e)}")


def main():
    """主函数"""
    app = QApplication(sys.argv)
    
    # 设置应用样式
    app.setStyle('Fusion')
    
    # 设置全局字体
    font = QFont('Microsoft YaHei', 9)
    app.setFont(font)
    
    # 创建窗口
    window = DemoWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
