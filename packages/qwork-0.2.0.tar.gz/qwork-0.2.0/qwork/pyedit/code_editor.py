"""
代码编辑器组件 - 增强版
基于QPlainTextEdit的高级Python代码编辑器

增强特性:
- 优化的代码补全响应速度
- Consolas字体12号
"""

from PyQt6.QtWidgets import (
    QPlainTextEdit, QWidget, QVBoxLayout, QHBoxLayout,
    QScrollBar, QAbstractSlider
)
from PyQt6.QtCore import (
    Qt, QRect, QRectF, QSize, pyqtSignal, QTimer, QPoint
)
from PyQt6.QtGui import (
    QPainter, QColor, QFont, QFontMetrics, QKeyEvent,
    QMouseEvent, QWheelEvent, QTextCursor, QTextFormat,
    QKeySequence, QAction, QTextDocument
)
from typing import Optional, List, Dict, Callable

from .syntax_highlighter import PythonSyntaxHighlighter
from .line_number_area import LineNumberArea, LineNumberDelegate
from .code_folder import CodeFolder, FoldRegion, FoldMarkerPainter
from .completer import CodeCompleter, SmartCompleter, CompletionItem
from .context_analyzer import ContextAnalyzer


class CodeEditor(QPlainTextEdit):
    """
    高级代码编辑器
    
    功能：
    - Python语法高亮
    - 代码折叠
    - 行号显示
    - 代码补全（优化响应速度）
    - 智能缩进
    """
    
    # 信号
    text_modified = pyqtSignal()  # 文本修改信号
    cursor_position_changed = pyqtSignal(int, int)  # 光标位置改变 (line, column)
    fold_changed = pyqtSignal(int, bool)  # 折叠状态改变
    completions_requested = pyqtSignal(str, int)  # 请求补全
    
    # 编辑器配置
    TAB_WIDTH = 4
    FONT_FAMILY = 'Consolas'
    FONT_SIZE = 14
    
    # 颜色配置（浅色主题）
    COLORS = {
        'background': '#ffffff',
        'text': '#333333',
        'selection': '#add6ff',
        'current_line': '#f5f5f5',
        'line_number_bg': '#f0f0f0',
        'line_number_text': '#999999',
        'fold_marker': '#999999',
        'whitespace': '#d0d0d0',
    }
    
    def __init__(self, parent=None):
        super().__init__(parent)

        # 代码折叠
        self._folder = CodeFolder()
        self._fold_marker_painter = FoldMarkerPainter(self._folder)

        # 上下文分析
        self._context_analyzer = ContextAnalyzer()

        # 行号边栏（必须在_setup_font之前创建）
        self._line_number_area = LineNumberArea(editor=self, parent=self)
        print(f"[CodeEditor] LineNumberArea created, parent={self}")

        # 初始化组件
        self._setup_ui()
        self._setup_font()
        self._setup_highlighter()
        self._setup_completer()
        self._setup_connections()

        # 连接信号
        self._folder.fold_changed.connect(self._on_fold_changed)
        self._line_number_area.fold_clicked.connect(self._on_fold_clicked)
        self._line_number_area.line_clicked.connect(self._on_line_clicked)

        # 更新行号区域
        self._line_number_area.set_line_count(self.blockCount())
        self._update_line_number_area_width()
        self._update_line_number_area_geometry()
        
        # 补全延迟计时器 - 优化为更短的延迟
        self._completion_timer = QTimer()
        self._completion_timer.setSingleShot(True)
        self._completion_timer.timeout.connect(self._show_completions)
        
        # 隐藏代码上下文
        self._context_code_a: str = ""  # 类定义代码
        self._context_code_b: str = ""  # 函数定义代码
        self._context_prefix: str = ""  # 前缀缩进
        
        # 当前补全前缀
        self._current_completion_prefix: str = ""
        
        # 最后补全时间（用于性能优化）
        self._last_completion_time = 0
        
        # 补全防抖间隔（毫秒）
        self._completion_debounce_ms = 50
    
    def _setup_ui(self):
        """设置UI"""
        # 设置背景色
        self.setStyleSheet(f"""
            QPlainTextEdit {{
                background-color: {self.COLORS['background']};
                color: {self.COLORS['text']};
                border: none;
                selection-background-color: {self.COLORS['selection']};
                font-family: {self.FONT_FAMILY};
                font-size: {self.FONT_SIZE}px;
            }}
        """)
        
        # 启用当前行高亮
        self.setCenterOnScroll(True)
        
        # 设置Tab宽度
        self.setTabStopDistance(self.fontMetrics().horizontalAdvance(' ') * self.TAB_WIDTH)
        
        # 启用自动换行
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        
        # 设置光标宽度
        self.setCursorWidth(2)
    
    def _setup_font(self):
        """设置字体 - Consolas 14号"""
        font = QFont(self.FONT_FAMILY, self.FONT_SIZE)
        font.setFixedPitch(True)
        font.setStyleHint(QFont.StyleHint.Monospace)
        self.setFont(font)

        # 更新行号区域字体
        self._line_number_area.set_font(font)
        # 行高将在 _sync_line_height 中同步
    
    def _setup_highlighter(self):
        """设置语法高亮"""
        self._highlighter = PythonSyntaxHighlighter(self.document())
    
    def _setup_completer(self):
        """设置代码补全"""
        self._completer_manager = CodeCompleter()
        
        self._completer = SmartCompleter(self)
        self._completer.setWidget(self)
        self._completer.activated_item.connect(self._on_completion_activated)
    
    def _setup_connections(self):
        """设置信号连接"""
        # 文本修改
        self.textChanged.connect(self._on_text_changed)
        
        # 光标位置改变
        self.cursorPositionChanged.connect(self._on_cursor_position_changed)
        
        # 滚动
        self.verticalScrollBar().valueChanged.connect(
            self._on_vertical_scroll_changed
        )
        
        # 更新请求
        self.updateRequest.connect(self._on_update_request)
        
        # 块计数改变
        self.blockCountChanged.connect(self._on_block_count_changed)
    
    def set_context_code(self, code_a: str = "", code_b: str = "", prefix: str = ""):
        """
        设置上下文代码

        Args:
            code_a: 类定义代码 (CA)
            code_b: 函数定义代码 (CB)
            prefix: 前缀缩进
        """
        print(f"[CodeEditor.set_context_code] Setting context code")
        print(f"[CodeEditor.set_context_code] code_a length: {len(code_a)}")
        print(f"[CodeEditor.set_context_code] code_b length: {len(code_b)}")
        print(f"[CodeEditor.set_context_code] prefix: {repr(prefix)}")

        self._context_code_a = code_a
        self._context_code_b = code_b
        self._context_prefix = prefix

        # 更新补全器和分析器
        self._completer_manager.set_context_code(code_a, code_b, prefix)
        self._context_analyzer.set_context(code_a, code_b, prefix, self.toPlainText())
        
        # 重新分析代码折叠
        self._analyze_folding()
    
    def _analyze_folding(self):
        """分析代码折叠"""
        # 只分析可见代码（避免上下文代码干扰行号）
        visible_code = self.toPlainText()
        self._folder.analyze_code(visible_code)

        # 更新行号区域的可折叠行
        foldable_lines = [r.start_line for r in self._folder.get_regions()]
        self._line_number_area.set_foldable_lines(foldable_lines)
    
    def _build_full_code(self) -> str:
        """构建完整代码"""
        lines = []
        
        if self._context_code_a:
            lines.append(self._context_code_a)
            lines.append("")
        
        if self._context_code_b:
            lines.append(self._context_code_b)
            lines.append("")
        
        visible_code = self.toPlainText()
        if self._context_prefix:
            for line in visible_code.split('\n'):
                lines.append(self._context_prefix + line)
        else:
            lines.append(visible_code)
        
        return '\n'.join(lines)
    
    def resizeEvent(self, event):
        """调整大小事件"""
        super().resizeEvent(event)
        
        # 更新行号区域位置
        self._update_line_number_area_geometry()
    
    def _update_line_number_area_geometry(self):
        """更新行号区域几何"""
        cr = self.contentsRect()
        width = self._line_number_area.width()
        # 行号区域放在最左侧，与编辑器内容区对齐
        self._line_number_area.setGeometry(
            cr.left(), cr.top(),
            width, cr.height()
        )
        print(f"[CodeEditor] LineNumberArea geometry: x={cr.left()}, y={cr.top()}, w={width}, h={cr.height()}")
    
    def _update_line_number_area_width(self):
        """更新行号区域宽度"""
        width = self._line_number_area.width()
        self.setViewportMargins(width, 0, 0, 0)
        print(f"[CodeEditor] viewport margins set: {width}")
    
    def _on_block_count_changed(self, count: int):
        """块计数改变"""
        self._line_number_area.set_line_count(count)
        self._update_line_number_area_width()
        self._analyze_folding()
        # 同步行高
        QTimer.singleShot(0, self._sync_line_height)
    
    def _sync_line_height(self):
        """同步行号区域行高与 QPlainTextEdit 实际行高"""
        block = self.firstVisibleBlock()
        if block.isValid():
            block_rect = self.blockBoundingRect(block)
            if block_rect.height() > 0:
                actual_height = int(block_rect.height())
                if actual_height != self._line_number_area._line_height:
                    self._line_number_area.set_line_height(actual_height)

    def _on_update_request(self, rect: QRect, dy: int):
        """更新请求"""
        # 同步行高
        self._sync_line_height()
        # 行号区域现在直接从编辑器获取可见行，只需要重绘
        self._line_number_area.update()

        if rect.contains(self.viewport().rect()):
            self._update_line_number_area_width()
    
    def paintEvent(self, event):
        """绘制事件"""
        # 获取被折叠的行
        collapsed_regions = [(r.start_line, r.end_line) for r in self._folder.get_regions() if r.collapsed]

        if not collapsed_regions:
            # 没有折叠，正常绘制
            self._draw_current_line_highlight()
            super().paintEvent(event)
            return

        # 有折叠，需要自定义绘制
        self._paint_with_folding(event, collapsed_regions)

    def _paint_with_folding(self, event, collapsed_regions):
        """带折叠的自定义绘制 - 压缩被折叠的行"""
        painter = QPainter(self.viewport())
        painter.setClipRect(event.rect())

        # 构建被折叠的行集合
        folded_lines = set()
        fold_ranges = []
        for start, end in collapsed_regions:
            folded_lines.update(range(start + 1, end + 1))
            fold_ranges.append((start, end))

        # 计算折叠导致的y偏移
        # 对于每一行，计算在它之前有多少行被折叠了
        # 被折叠的内部行是 (start+1) 到 end
        line_height = self._line_number_area._line_height
        def get_y_offset(line):
            offset = 0
            for start, end in fold_ranges:
                if line > start:
                    if line > end:
                        # 完全在折叠区域之后，减去所有被折叠的内部行
                        offset += (end - start) * line_height
                    # 如果在折叠区域内（start < line <= end），正常显示，不偏移
            return offset

        # 绘制可见的块
        block = self.firstVisibleBlock()
        while block.isValid():
            block_num = block.blockNumber() + 1
            block_rect = self.blockBoundingGeometry(block)

            # 如果被折叠，跳过不绘制
            if block_num in folded_lines:
                block = block.next()
                continue

            # 计算调整后的y位置
            y_offset = get_y_offset(block_num)
            adjusted_rect = block_rect.translated(0, -y_offset)
            adjusted_rect.translate(self.contentOffset())

            # 如果块在视口外，停止
            if adjusted_rect.top() > self.viewport().height():
                break

            # 绘制当前行高亮
            if block_num == self.textCursor().blockNumber() + 1:
                painter.fillRect(adjusted_rect, QColor(self.COLORS['current_line']))

            # 绘制块内容
            self._draw_block_content(painter, block, adjusted_rect)

            # 如果是折叠起始行，绘制折叠占位符
            for start, end in fold_ranges:
                if block_num == start:
                    self._draw_single_fold_placeholder(
                        painter, block, adjusted_rect, start, end
                    )

            block = block.next()

        painter.end()

    def _draw_block_content(self, painter: QPainter, block, rect: QRect):
        """绘制块内容"""
        layout = block.layout()
        if not layout:
            return

        for i in range(layout.lineCount()):
            line = layout.lineAt(i)
            line_rect = QRectF(
                rect.x() + line.x(),
                rect.y() + line.y(),
                line.width(),
                line.height()
            )
            line.draw(painter, line_rect.topLeft())

    def _draw_single_fold_placeholder(self, painter: QPainter, block, rect: QRect,
                                       start_line: int, end_line: int):
        """绘制单个折叠占位符"""
        x = int(rect.x())
        y = int(rect.y())
        width = int(self.viewport().width() - x - 20)
        height = int(rect.height())

        # 绘制灰色圆角矩形占位符
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor('#e8e8e8'))
        painter.drawRoundedRect(x, y, width, height, 4, 4)

        # 绘制边框
        painter.setPen(QColor('#c0c0c0'))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(x, y, width, height, 4, 4)

        # 绘制折叠的文本内容
        text = block.text().strip()
        if len(text) > 50:
            text = text[:50] + '...'

        painter.setPen(QColor('#666666'))
        font = QFont(self.FONT_FAMILY, self.FONT_SIZE)
        painter.setFont(font)

        text_x = x + 10
        text_y = y + height // 2 + 5
        painter.drawText(text_x, text_y, text)

        # 绘制三个小圆点
        dot_y = y + height // 2
        dot_spacing = 6
        dot_radius = 2
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor('#999999'))

        text_width = QFontMetrics(font).horizontalAdvance(text)
        dots_x = text_x + text_width + 15

        for i in range(3):
            dot_x = dots_x + i * dot_spacing
            painter.drawEllipse(dot_x - dot_radius, dot_y - dot_radius,
                              dot_radius * 2, dot_radius * 2)

    def _draw_fold_placeholders(self):
        """绘制折叠占位符（灰色圆角矩形 + 三个小圆点）"""
        collapsed_regions = [r for r in self._folder.get_regions() if r.collapsed]
        if not collapsed_regions:
            return

        painter = QPainter(self.viewport())
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        for region in collapsed_regions:
            # 获取折叠起始行和结束行
            start_block = self.document().findBlockByNumber(region.start_line - 1)
            end_block = self.document().findBlockByNumber(region.end_line - 1)

            if not start_block.isValid():
                continue

            # 计算位置
            start_rect = self.blockBoundingGeometry(start_block)
            start_rect.translate(self.contentOffset())

            if end_block.isValid():
                end_rect = self.blockBoundingGeometry(end_block)
                end_rect.translate(self.contentOffset())
                # 折叠区域高度（从起始行底部到结束行底部）
                fold_height = end_rect.bottom() - start_rect.bottom()
            else:
                fold_height = 0

            x = int(start_rect.x())
            y_start = int(start_rect.y())
            width = int(self.viewport().width() - x - 20)
            line_height = int(start_rect.height())

            # 1. 先用白色背景覆盖被折叠的代码行（隐藏原代码）
            if fold_height > 0:
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor('#ffffff'))
                painter.drawRect(x, int(start_rect.bottom()), width, int(fold_height))

            # 2. 绘制灰色圆角矩形占位符（在起始行位置，覆盖原第一行）
            painter.setBrush(QColor('#e8e8e8'))
            painter.drawRoundedRect(x, y_start, width, line_height, 4, 4)

            # 3. 绘制边框
            painter.setPen(QColor('#c0c0c0'))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRoundedRect(x, y_start, width, line_height, 4, 4)

            # 4. 绘制折叠的文本内容（第一行）
            text = start_block.text().strip()
            if len(text) > 50:
                text = text[:50] + '...'

            painter.setPen(QColor('#666666'))
            font = QFont(self.FONT_FAMILY, self.FONT_SIZE)
            painter.setFont(font)

            text_x = x + 10
            text_y = y_start + line_height // 2 + 5
            painter.drawText(text_x, text_y, text)

            # 5. 绘制三个小圆点
            dot_y = y_start + line_height // 2
            dot_spacing = 6
            dot_radius = 2
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor('#999999'))

            text_width = QFontMetrics(font).horizontalAdvance(text)
            dots_x = text_x + text_width + 15

            for i in range(3):
                dot_x = dots_x + i * dot_spacing
                painter.drawEllipse(dot_x - dot_radius, dot_y - dot_radius,
                                  dot_radius * 2, dot_radius * 2)

        painter.end()

    def _draw_current_line_highlight(self):
        """绘制当前行高亮"""
        # 检查当前行是否被折叠
        cursor = self.textCursor()
        block = cursor.block()
        line = block.blockNumber() + 1

        # 如果被折叠，不绘制高亮
        for region in self._folder.get_regions():
            if region.collapsed and region.contains(line):
                return

        if not block.isValid():
            return

        # 获取当前行的几何信息
        layout = block.layout()
        if not layout:
            return

        # 获取当前块在文档中的位置
        block_rect = self.blockBoundingGeometry(block)
        block_rect.translate(self.contentOffset())

        # 绘制高亮背景
        painter = QPainter(self.viewport())
        painter.fillRect(block_rect, QColor(self.COLORS['current_line']))
        painter.end()
    
    def _draw_fold_markers(self):
        """绘制折叠标记"""
        painter = QPainter(self.viewport())
        
        # 获取可见区域
        first_visible = self.firstVisibleBlock().blockNumber() + 1
        last_visible = first_visible
        
        block = self.firstVisibleBlock()
        while block.isValid():
            rect = self.blockBoundingGeometry(block)
            rect.translate(self.contentOffset())
            
            if rect.top() > self.viewport().height():
                break
            
            last_visible = block.blockNumber() + 1
            block = block.next()
        
        # 绘制每个折叠区域的标记
        for region in self._folder.get_regions():
            if first_visible <= region.start_line <= last_visible:
                # 计算位置
                block = self.document().findBlockByNumber(region.start_line - 1)
                rect = self.blockBoundingGeometry(block)
                rect.translate(self.contentOffset())
                
                # 绘制标记
                x = 4
                y = rect.top()
                height = rect.height()
                
                self._fold_marker_painter.paint_marker(
                    painter, region, x, y, height
                )
        
        painter.end()
    
    def _on_text_changed(self):
        """文本改变"""
        self.text_modified.emit()
        
        # 延迟分析折叠
        QTimer.singleShot(500, self._analyze_folding)
        
        # 触发补全
        self._trigger_completion()
    
    def _on_cursor_position_changed(self):
        """光标位置改变"""
        cursor = self.textCursor()
        line = cursor.blockNumber() + 1
        column = cursor.columnNumber()
        
        self.cursor_position_changed.emit(line, column)
        
        # 更新当前行
        self._line_number_area.set_current_line(line)
        
        # 隐藏补全窗口（如果光标移动较远）
        if self._completer.popup().isVisible():
            # 检查是否还在当前词附近
            current_word = self._get_current_word()
            if not current_word.startswith(self._current_completion_prefix):
                self._completer.popup().hide()
    
    def _on_vertical_scroll_changed(self, value: int):
        """垂直滚动改变"""
        self._line_number_area.update()
    
    def _on_fold_clicked(self, line: int):
        """折叠按钮点击"""
        self._folder.toggle_fold(line)
        self._line_number_area.toggle_fold(line)
        self.fold_changed.emit(line, self._folder.get_region_at_line(line).collapsed 
                               if self._folder.get_region_at_line(line) else False)
        self.update()
    
    def _on_line_clicked(self, line: int):
        """行号点击"""
        # 移动光标到指定行
        block = self.document().findBlockByNumber(line - 1)
        if block.isValid():
            cursor = QTextCursor(block)
            self.setTextCursor(cursor)
            self.setFocus()
    
    def _on_fold_changed(self, line: int, collapsed: bool):
        """折叠状态改变"""
        self._line_number_area.set_folded_lines([
            r.start_line for r in self._folder.get_regions() if r.collapsed
        ])
        self.update()
    
    def keyPressEvent(self, event: QKeyEvent):
        """键盘按下事件"""
        key = event.key()
        modifiers = event.modifiers()

        # 处理折叠快捷键
        if modifiers == Qt.KeyboardModifier.ControlModifier:
            if key == Qt.Key.Key_Minus or key == Qt.Key.Key_Underscore:
                # Ctrl + - : 折叠当前块
                self._fold_current_block()
                return
            elif key == Qt.Key.Key_Plus or key == Qt.Key.Key_Equal:
                # Ctrl + + : 展开当前块
                self._unfold_current_block()
                return
        
        if modifiers == (Qt.KeyboardModifier.ControlModifier | 
                        Qt.KeyboardModifier.ShiftModifier):
            if key == Qt.Key.Key_Minus or key == Qt.Key.Key_Underscore:
                # Ctrl + Shift + - : 折叠所有
                self._folder.fold_all()
                self.update()
                return
            elif key == Qt.Key.Key_Plus or key == Qt.Key.Key_Equal:
                # Ctrl + Shift + + : 展开所有
                self._folder.unfold_all()
                self.update()
                return
        
        # 处理补全导航 - 将事件传递给补全器处理（必须在 Tab/Enter 处理之前）
        if self._completer.popup() and self._completer.popup().isVisible():
            if key == Qt.Key.Key_Escape:
                # ESC 关闭补全窗口
                self._completer.popup().hide()
                event.accept()
                return
            elif key in (Qt.Key.Key_Up, Qt.Key.Key_Down,
                        Qt.Key.Key_Return, Qt.Key.Key_Enter,
                        Qt.Key.Key_Tab):
                # 这些键交给补全器处理
                # QCompleter 会自动处理 Up/Down/Enter
                # 对于 Tab，我们需要手动触发补全
                if key == Qt.Key.Key_Tab:
                    current_item = self._completer.get_current_item()
                    if current_item:
                        self._on_completion_activated(current_item)
                        self._completer.popup().hide()
                    event.accept()
                    return
                # 让 QCompleter 处理其他键
                event.ignore()
                return
            elif key in (Qt.Key.Key_Left, Qt.Key.Key_Right):
                # 左右箭头关闭补全窗口并正常处理
                self._completer.popup().hide()
                # 继续正常处理箭头键

        # 处理Tab键（智能缩进）- 只在补全窗口不可见时
        if key == Qt.Key.Key_Tab and not event.modifiers():
            self._handle_tab()
            return

        # 处理Enter键（自动缩进）- 只在补全窗口不可见时
        if key == Qt.Key.Key_Return or key == Qt.Key.Key_Enter:
            self._handle_enter()
            return

        # 处理补全快捷键
        if key == Qt.Key.Key_Space and modifiers == Qt.KeyboardModifier.ControlModifier:
            self._show_completions()
            return

        # 调用父类的处理
        super().keyPressEvent(event)

        # 触发补全（优化：只在特定键后触发）
        if self._should_trigger_completion(key):
            self._trigger_completion()
    
    def _should_trigger_completion(self, key: int) -> bool:
        """判断是否应该触发补全"""
        # 字母数字下划线
        if Qt.Key.Key_A <= key <= Qt.Key.Key_Z or \
           Qt.Key.Key_0 <= key <= Qt.Key.Key_9 or \
           key == Qt.Key.Key_Underscore:
            return True
        
        # 点号（属性访问）
        if key == Qt.Key.Key_Period:
            return True
        
        return False
    
    def _handle_tab(self):
        """处理Tab键"""
        cursor = self.textCursor()
        
        if cursor.hasSelection():
            # 有多行选择，进行缩进/取消缩进
            self._indent_selection()
        else:
            # 单行，插入空格
            cursor.insertText(' ' * self.TAB_WIDTH)
    
    def _indent_selection(self):
        """缩进选中的行"""
        cursor = self.textCursor()
        start = cursor.selectionStart()
        end = cursor.selectionEnd()
        
        # 获取选中的块
        start_block = self.document().findBlock(start)
        end_block = self.document().findBlock(end)
        
        cursor.beginEditBlock()
        
        block = start_block
        while block.isValid() and block.blockNumber() <= end_block.blockNumber():
            block_cursor = QTextCursor(block)
            block_cursor.movePosition(QTextCursor.MoveOperation.StartOfBlock)
            block_cursor.insertText(' ' * self.TAB_WIDTH)
            block = block.next()
        
        cursor.endEditBlock()
    
    def _handle_enter(self):
        """处理Enter键"""
        cursor = self.textCursor()
        
        # 获取当前行的缩进
        block = cursor.block()
        line_text = block.text()
        indent = len(line_text) - len(line_text.lstrip())
        
        # 检查是否需要增加缩进
        stripped = line_text.strip()
        if stripped.endswith(':'):
            indent += self.TAB_WIDTH
        
        # 插入换行和缩进
        cursor.insertText('\n' + ' ' * indent)
    
    def _fold_current_block(self):
        """折叠当前块"""
        cursor = self.textCursor()
        line = cursor.blockNumber() + 1
        
        # 查找包含当前行的折叠区域
        for region in self._folder.get_regions():
            if region.contains(line):
                if not region.collapsed:
                    self._folder.fold_region(region.start_line)
                    self._line_number_area.set_folded_lines([
                        r.start_line for r in self._folder.get_regions() if r.collapsed
                    ])
                    self.update()
                return
        
        # 如果当前行就是折叠开始行
        self._folder.fold_region(line)
        self._line_number_area.toggle_fold(line)
        self.update()
    
    def _unfold_current_block(self):
        """展开当前块"""
        cursor = self.textCursor()
        line = cursor.blockNumber() + 1
        
        self._folder.unfold_region(line)
        self._line_number_area.toggle_fold(line)
        self.update()
    
    def _trigger_completion(self):
        """触发代码补全 - 优化版本"""
        # 取消之前的计时器
        self._completion_timer.stop()

        # 检查是否需要显示补全
        cursor = self.textCursor()
        pos = cursor.position()
        text = self.toPlainText()

        # 获取当前词
        current_word = self._get_current_word()

        # 检查是否在点号后
        after_dot = self._is_after_dot()

        # 如果当前词太短且不在点号后，不显示补全
        if len(current_word) < 1 and not after_dot:
            self._completer.popup().hide()
            return

        # 保存当前补全前缀
        self._current_completion_prefix = current_word

        # 如果在点号后，立即显示补全
        if after_dot:
            self._show_completions()
        else:
            # 否则使用短延迟
            self._completion_timer.start(self._completion_debounce_ms)
    
    def _show_completions(self):
        """显示补全列表 - 优化版本"""
        cursor = self.textCursor()
        pos = cursor.position()
        text = self.toPlainText()

        # 获取补全建议
        completions = self._completer_manager.get_completions(text, pos)

        if not completions:
            popup = self._completer.popup()
            if popup:
                popup.hide()
            return

        # 如果只有一个补全项且与当前输入完全匹配，隐藏补全窗口
        if len(completions) == 1 and self._current_completion_prefix:
            if completions[0].text.lower() == self._current_completion_prefix.lower():
                popup = self._completer.popup()
                if popup:
                    popup.hide()
                return

        # 计算弹出位置 - 基于当前词的开始位置
        cursor = self.textCursor()
        cursor_rect = self.cursorRect()

        # 如果有前缀词，调整位置到词的开始处（让补全窗口出现在输入位置）
        if self._current_completion_prefix:
            # 创建一个临时光标，移动到词的开始位置
            temp_cursor = QTextCursor(cursor)
            pos = cursor.position()
            # 向前查找词的开始
            start = pos - len(self._current_completion_prefix)
            if start >= 0:
                temp_cursor.setPosition(start)
                cursor_rect = self.cursorRect(temp_cursor)

        # 显示补全窗口 - cursorRect() 返回的是视口坐标
        # 需要转换为全局坐标，然后 completer 会处理坐标映射
        global_pos = self.viewport().mapToGlobal(cursor_rect.bottomLeft())

        # QCompleter.complete() 需要相对于 setWidget() 的坐标
        # 转换全局坐标到 widget 坐标
        widget_pos = self.mapFromGlobal(global_pos)
        popup_width = 300

        popup_rect = QRect(widget_pos, QSize(popup_width, 200))

        # 更新补全器并传入位置
        self._completer.update_completions(completions, popup_rect)
    
    def _on_completion_activated(self, item: CompletionItem):
        """补全项被激活"""
        cursor = self.textCursor()
        
        # 删除当前词
        current_word = self._get_current_word()
        if current_word:
            for _ in range(len(current_word)):
                cursor.deletePreviousChar()
        
        # 插入补全文本
        cursor.insertText(item.text)
        
        # 如果是函数/方法，添加括号
        if item.item_type in ('function', 'method', 'builtin'):
            cursor.insertText('()')
            cursor.movePosition(QTextCursor.MoveOperation.PreviousCharacter)
        
        self.setTextCursor(cursor)
        popup = self._completer.popup()
        if popup:
            popup.hide()
    
    def _get_current_word(self) -> str:
        """获取光标处的当前词"""
        cursor = self.textCursor()
        pos = cursor.position()
        text = self.toPlainText()
        
        # 向前查找词的开始
        start = pos - 1
        while start >= 0 and (text[start].isalnum() or text[start] == '_'):
            start -= 1
        start += 1
        
        return text[start:pos]
    
    def _is_after_dot(self) -> bool:
        """检查光标是否在点号后"""
        cursor = self.textCursor()
        pos = cursor.position()
        text = self.toPlainText()

        # 跳过空白
        check_pos = pos - 1
        while check_pos >= 0 and text[check_pos].isspace():
            check_pos -= 1

        return check_pos >= 0 and text[check_pos] == '.'
    
    def mousePressEvent(self, event: QMouseEvent):
        """鼠标按下事件"""
        # 折叠功能现在只在左侧行号区域处理
        super().mousePressEvent(event)
    
    def get_text(self) -> str:
        """获取文本"""
        return self.toPlainText()

    def set_text(self, text: str):
        """设置文本"""
        self.setPlainText(text)
    
    def get_cursor_position(self) -> tuple:
        """获取光标位置 (line, column)"""
        cursor = self.textCursor()
        return (cursor.blockNumber() + 1, cursor.columnNumber())
    
    def set_cursor_position(self, line: int, column: int = 0):
        """设置光标位置"""
        block = self.document().findBlockByNumber(line - 1)
        if block.isValid():
            cursor = QTextCursor(block)
            cursor.movePosition(QTextCursor.MoveOperation.Right, 
                              QTextCursor.MoveMode.MoveAnchor, column)
            self.setTextCursor(cursor)
    
    def get_visible_lines(self) -> tuple:
        """获取可见行范围 (first, last)"""
        first = self.firstVisibleBlock().blockNumber()
        
        block = self.firstVisibleBlock()
        last = first
        while block.isValid():
            rect = self.blockBoundingGeometry(block)
            rect.translate(self.contentOffset())
            
            if rect.top() > self.viewport().height():
                break
            
            last = block.blockNumber()
            block = block.next()
        
        return (first + 1, last + 1)
    
    def scroll_to_line(self, line: int):
        """滚动到指定行"""
        block = self.document().findBlockByNumber(line - 1)
        if block.isValid():
            cursor = QTextCursor(block)
            self.setTextCursor(cursor)
            self.ensureCursorVisible()
    
    def fold_all(self):
        """折叠所有"""
        self._folder.fold_all()
        self._line_number_area.set_folded_lines([
            r.start_line for r in self._folder.get_regions() if r.collapsed
        ])
        self.update()
    
    def unfold_all(self):
        """展开所有"""
        self._folder.unfold_all()
        self._line_number_area.set_folded_lines([
            r.start_line for r in self._folder.get_regions() if r.collapsed
        ])
        self.update()
