"""
行号边栏
显示行号和折叠按钮 - 扁平化设计风格
"""

from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import Qt, QRect, QSize, pyqtSignal, QPoint
from PyQt6.QtGui import QPainter, QColor, QFont, QMouseEvent, QPaintEvent, QFontMetrics, QPolygon, QPen
from typing import Optional, Callable, List


class LineNumberArea(QWidget):
    """行号边栏控件 - 扁平化风格"""

    # 信号
    fold_clicked = pyqtSignal(int)  # 折叠按钮点击信号 (line_number)
    line_clicked = pyqtSignal(int)  # 行号点击信号 (line_number)

    # 颜色配置（扁平化浅色主题）
    COLORS = {
        'background': '#f8f9fa',
        'fold_area_bg': '#f1f3f4',
        'line_area_bg': '#f8f9fa',
        'text': '#9aa0a6',
        'text_active': '#202124',
        'border': '#dadce0',
        'divider': '#dadce0',
        'fold_btn_bg': '#e8eaed',
        'fold_btn_bg_hover': '#dadce0',
        'fold_btn_icon': '#5f6368',
        'fold_btn_icon_active': '#1a73e8',
        'current_line': '#e8f0fe',
    }

    # 区域宽度配置
    FOLD_AREA_WIDTH = 22  # 折叠区域宽度
    LINE_NUMBER_PADDING = 8  # 行号边距
    DIVIDER_WIDTH = 1  # 分割线宽度

    def __init__(self, editor=None, parent=None):
        super().__init__(parent)

        self._editor = editor
        self._line_count: int = 0
        self._current_line: int = 1
        self._line_height: int = 20
        self._font: QFont = QFont('Consolas', 14)
        self._foldable_lines: set = set()  # 可折叠的行
        self._folded_lines: set = set()    # 已折叠的行
        self._fold_markers: dict = {}      # 折叠标记位置 {line: rect}
        self._hovered_fold_line: int = -1  # 鼠标悬停的折叠行

        # 设置固定宽度（将根据行数动态调整）
        self.setFixedWidth(60)

        # 设置背景色
        self.setStyleSheet(f"background-color: {self.COLORS['background']};")
        print(f"[LineNumberArea] __init__: parent={parent}, width={self.width()}")

        # 启用鼠标跟踪
        self.setMouseTracking(True)

    def set_line_count(self, count: int):
        """设置行数"""
        self._line_count = count
        self._update_width()
        self.update()

    def set_current_line(self, line: int):
        """设置当前行"""
        self._current_line = line
        self.update()

    def set_line_height(self, height: int):
        """设置行高"""
        self._line_height = height
        self.update()

    def set_font(self, font: QFont):
        """设置字体"""
        self._font = font
        self._update_width()
        self.update()

    def set_foldable_lines(self, lines: List[int]):
        """设置可折叠的行"""
        self._foldable_lines = set(lines)
        self.update()

    def set_folded_lines(self, lines: List[int]):
        """设置已折叠的行"""
        self._folded_lines = set(lines)
        self.update()

    def add_foldable_line(self, line: int):
        """添加可折叠行"""
        self._foldable_lines.add(line)
        self.update()

    def remove_foldable_line(self, line: int):
        """移除可折叠行"""
        self._foldable_lines.discard(line)
        self._folded_lines.discard(line)
        self.update()

    def toggle_fold(self, line: int):
        """切换折叠状态"""
        if line in self._folded_lines:
            self._folded_lines.discard(line)
        else:
            self._folded_lines.add(line)
        self.update()

    def _update_width(self):
        """根据行数更新宽度"""
        if self._line_count <= 0:
            self.setFixedWidth(self.FOLD_AREA_WIDTH + self.LINE_NUMBER_PADDING * 2 + self.DIVIDER_WIDTH)
            return

        # 计算所需宽度
        metrics = QFontMetrics(self._font)
        max_digits = len(str(self._line_count))

        # 折叠区域 + 行号宽度 + 边距 + 分割线
        text_width = metrics.horizontalAdvance('9' * max_digits)
        line_area_width = text_width + self.LINE_NUMBER_PADDING

        total_width = self.FOLD_AREA_WIDTH + self.DIVIDER_WIDTH + line_area_width
        self.setFixedWidth(max(50, total_width))

    def sizeHint(self):
        """大小建议"""
        return QSize(self.width(), self._line_count * self._line_height)

    def paintEvent(self, event: QPaintEvent):
        """绘制事件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # 强制填充红色背景用于调试
        painter.fillRect(self.rect(), QColor('red'))

        # 绘制折叠区域背景
        fold_rect = QRect(0, 0, self.FOLD_AREA_WIDTH, self.height())
        painter.fillRect(fold_rect, QColor(self.COLORS['fold_area_bg']))

        # 绘制行号区域背景
        line_rect = QRect(self.FOLD_AREA_WIDTH + self.DIVIDER_WIDTH, 0,
                         self.width() - self.FOLD_AREA_WIDTH - self.DIVIDER_WIDTH, self.height())
        painter.fillRect(line_rect, QColor(self.COLORS['line_area_bg']))

        # 绘制分割线（在折叠区域和行号区域之间）
        divider_x = self.FOLD_AREA_WIDTH
        painter.setPen(QColor(self.COLORS['divider']))
        painter.drawLine(divider_x, 0, divider_x, self.height())

        # 绘制右边框
        painter.setPen(QColor(self.COLORS['border']))
        painter.drawLine(self.width() - 1, 0, self.width() - 1, self.height())

        if self._line_count <= 0:
            painter.end()
            return

        # 设置字体
        painter.setFont(self._font)
        metrics = QFontMetrics(self._font)

        # 从父编辑器获取可见行范围
        first_line = 1
        last_line = self._line_count
        if self._editor:
            first_line = self._editor.firstVisibleBlock().blockNumber() + 1
            # 计算最后一个可见行
            block = self._editor.firstVisibleBlock()
            viewport_height = self._editor.viewport().height()
            last_line = first_line
            while block.isValid():
                block_rect = self._editor.blockBoundingGeometry(block)
                if block_rect.top() > viewport_height:
                    break
                last_line = block.blockNumber() + 1
                block = block.next()
            last_line = min(last_line, self._line_count)

        # 绘制每一行 - 直接从编辑器获取实际位置
        block = self._editor.document().findBlockByNumber(first_line - 1) if self._editor else None
        # 获取折叠区域信息（如果有）
        folded_regions = []
        if hasattr(self._editor, '_folder'):
            for region in self._editor._folder.get_regions():
                if region.collapsed:
                    folded_regions.append((region.start_line, region.end_line))

        # 计算折叠导致的y偏移函数
        # 注意：被折叠的内部行是 (start+1) 到 end
        line_height = self._line_height  # 使用固定的行高
        def get_fold_offset(line):
            offset = 0
            for start, end in folded_regions:
                if line > start:
                    # 被折叠的内部行数 = end - start
                    # 这些行在折叠后会消失，所以需要减去它们的高度
                    if line > end:
                        # 完全在折叠区域之后，减去所有被折叠的内部行
                        offset += (end - start) * line_height
                    # 如果在折叠区域内（start < line <= end），正常显示，不偏移
            return offset

        for line in range(first_line, last_line + 1):
            # 检查是否应该跳过此行（被折叠的内部行，不是起始行）
            is_folded_internal = False
            for start, end in folded_regions:
                if start < line <= end:
                    # 这是折叠区域的内部行，跳过
                    is_folded_internal = True
                    break

            if is_folded_internal:
                # 移动到下一个块但不绘制
                if block:
                    block = block.next()
                continue

            # 计算y位置：直接从编辑器获取该行的实际位置，并应用折叠偏移
            y = 0
            if block and block.isValid():
                block_rect = self._editor.blockBoundingGeometry(block)
                content_offset = self._editor.contentOffset()
                raw_y = int(block_rect.y() + content_offset.y())
                # 应用折叠偏移
                fold_offset = get_fold_offset(line)
                y = raw_y - fold_offset
                # 更新_line_height为实际行高（用于后续绘制元素）
                actual_height = int(block_rect.height())
                if actual_height > 0:
                    self._line_height = actual_height

            # 绘制当前行高亮（覆盖整个宽度）
            if line == self._current_line:
                painter.fillRect(
                    0, y, self.width() - 1, self._line_height,
                    QColor(self.COLORS['current_line'])
                )

            # 绘制折叠标记
            if line in self._foldable_lines:
                self._draw_fold_marker(painter, line, y)

            # 绘制行号
            is_active = (line == self._current_line)
            self._draw_line_number(painter, line, y, is_active)

            # 移动到下一个块
            if block:
                block = block.next()

        painter.end()

    def _draw_fold_marker(self, painter: QPainter, line: int, y: int):
        """绘制扁平化折叠标记"""
        is_hovered = (line == self._hovered_fold_line)
        is_collapsed = (line in self._folded_lines)

        # 按钮尺寸和位置（在折叠区域中央）
        btn_size = 14
        btn_x = (self.FOLD_AREA_WIDTH - btn_size) // 2
        btn_y = int(y + (self._line_height - btn_size) // 2)

        # 存储标记位置（扩大点击区域）
        self._fold_markers[line] = QRect(0, y, self.FOLD_AREA_WIDTH, self._line_height)

        # 绘制按钮背景（扁平化风格）
        if is_hovered:
            bg_color = QColor(self.COLORS['fold_btn_bg_hover'])
        else:
            bg_color = QColor(self.COLORS['fold_btn_bg'])

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(bg_color)
        painter.drawRoundedRect(btn_x, btn_y, btn_size, btn_size, 3, 3)

        # 绘制图标颜色
        icon_color = QColor(self.COLORS['fold_btn_icon_active']) if is_hovered else QColor(self.COLORS['fold_btn_icon'])
        painter.setPen(icon_color)
        painter.setBrush(icon_color)

        # 绘制加号/减号图标（扁平化风格）
        center_x = btn_x + btn_size // 2
        center_y = btn_y + btn_size // 2
        line_length = 6
        line_thickness = 1.5

        if is_collapsed:
            # 折叠状态：加号（+）
            # 水平线
            painter.setPen(QPen(icon_color, line_thickness))
            painter.drawLine(
                center_x - line_length // 2, center_y,
                center_x + line_length // 2, center_y
            )
            # 垂直线
            painter.drawLine(
                center_x, center_y - line_length // 2,
                center_x, center_y + line_length // 2
            )
        else:
            # 展开状态：减号（-）
            painter.setPen(QPen(icon_color, line_thickness))
            painter.drawLine(
                center_x - line_length // 2, center_y,
                center_x + line_length // 2, center_y
            )

    def _draw_line_number(self, painter: QPainter, line: int, y: int, is_active: bool):
        """绘制行号"""
        # 设置颜色
        color = self.COLORS['text_active'] if is_active else self.COLORS['text']
        painter.setPen(QColor(color))

        # 计算位置
        text = str(line)
        metrics = QFontMetrics(self._font)
        text_width = metrics.horizontalAdvance(text)

        # 行号右对齐，位于行号区域内
        line_area_start = self.FOLD_AREA_WIDTH + self.DIVIDER_WIDTH
        x = self.width() - text_width - self.LINE_NUMBER_PADDING
        text_y = y + (self._line_height - metrics.height()) // 2 + metrics.ascent()

        # 绘制文本
        painter.drawText(x, text_y, text)

    def _get_line_at_y(self, y: int) -> int:
        """根据y坐标获取行号 - 使用与绘制相同的逻辑"""
        if not self._editor or self._line_count <= 0:
            return 1

        # 从编辑器获取第一可见行
        first_line = self._editor.firstVisibleBlock().blockNumber() + 1
        block = self._editor.document().findBlockByNumber(first_line - 1)

        # 遍历可见行，找到对应的行
        for line_num in range(first_line, self._line_count + 1):
            if block.isValid():
                block_rect = self._editor.blockBoundingGeometry(block)
                content_offset = self._editor.contentOffset()
                block_y = int(block_rect.y() + content_offset.y())
                block_height = int(block_rect.height())

                if block_y <= y < block_y + block_height:
                    return line_num

                block = block.next()

        # 如果不在任何行内，返回最接近的行
        return min(max(1, y // self._line_height + 1), self._line_count)

    def mousePressEvent(self, event: QMouseEvent):
        """鼠标按下事件"""
        if event.button() == Qt.MouseButton.LeftButton:
            y = event.pos().y()
            line = self._get_line_at_y(y)

            if 1 <= line <= self._line_count:
                x = event.pos().x()

                # 检查是否点击在折叠区域
                if x < self.FOLD_AREA_WIDTH and line in self._foldable_lines:
                    self.fold_clicked.emit(line)
                    return

                # 否则发送行号点击信号
                self.line_clicked.emit(line)

    def mouseMoveEvent(self, event: QMouseEvent):
        """鼠标移动事件 - 用于hover效果"""
        y = event.pos().y()
        line = self._get_line_at_y(y)
        x = event.pos().x()

        if x < self.FOLD_AREA_WIDTH and line in self._foldable_lines and 1 <= line <= self._line_count:
            if self._hovered_fold_line != line:
                self._hovered_fold_line = line
                self.update()
        else:
            if self._hovered_fold_line != -1:
                self._hovered_fold_line = -1
                self.update()

    def leaveEvent(self, event):
        """鼠标离开事件"""
        if self._hovered_fold_line != -1:
            self._hovered_fold_line = -1
            self.update()

    def get_line_at_y(self, y: int) -> int:
        """获取指定y坐标对应的行号"""
        return self._get_line_at_y(y)

    def get_y_for_line(self, line: int) -> int:
        """获取指定行号的y坐标"""
        return (line - 1) * self._line_height


class FoldingIndicator:
    """折叠指示器 - 用于编辑器边距（扁平化风格）"""

    SIZE = 14

    def __init__(self, line: int, fold_type: str = 'block'):
        self.line = line
        self.fold_type = fold_type
        self.collapsed = False
        self.rect: Optional[QRect] = None

    def draw(self, painter: QPainter, x: int, y: int, height: int):
        """绘制扁平化折叠指示器"""
        size = self.SIZE

        # 计算位置（居中）
        marker_x = x + (22 - size) // 2  # 22是折叠区域宽度
        marker_y = y + (height - size) // 2

        # 存储矩形
        self.rect = QRect(marker_x, marker_y, size, size)

        # 绘制按钮背景（扁平化风格）
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor('#e8eaed'))
        painter.drawRoundedRect(marker_x, marker_y, size, size, 3, 3)

        # 绘制图标
        icon_color = QColor('#5f6368')
        painter.setPen(QPen(icon_color, 1.5))

        center_x = marker_x + size // 2
        center_y = marker_y + size // 2
        line_length = 6

        if self.collapsed:
            # 折叠状态：加号（+）
            # 水平线
            painter.drawLine(
                center_x - line_length // 2, center_y,
                center_x + line_length // 2, center_y
            )
            # 垂直线
            painter.drawLine(
                center_x, center_y - line_length // 2,
                center_x, center_y + line_length // 2
            )
        else:
            # 展开状态：减号（-）
            painter.drawLine(
                center_x - line_length // 2, center_y,
                center_x + line_length // 2, center_y
            )

    def contains(self, x: int, y: int) -> bool:
        """检查点是否在指示器内"""
        if self.rect:
            return self.rect.contains(x, y)
        return False


class LineNumberDelegate:
    """行号绘制委托 - 用于自定义编辑器"""

    def __init__(self, editor):
        self._editor = editor
        self._font = QFont('Consolas', 14)
        self._current_line = 1
        self._fold_indicators: dict = {}  # {line: FoldingIndicator}

    def paint(self, painter: QPainter, rect: QRect, line: int):
        """绘制行号"""
        fold_area_width = 22
        divider_width = 1

        # 绘制折叠区域背景
        fold_rect = QRect(rect.left(), rect.top(), fold_area_width, rect.height())
        painter.fillRect(fold_rect, QColor('#f1f3f4'))

        # 绘制行号区域背景
        line_rect = QRect(rect.left() + fold_area_width + divider_width, rect.top(),
                         rect.width() - fold_area_width - divider_width, rect.height())
        painter.fillRect(line_rect, QColor('#f8f9fa'))

        # 绘制分割线
        divider_x = rect.left() + fold_area_width
        painter.setPen(QColor('#dadce0'))
        painter.drawLine(divider_x, rect.top(), divider_x, rect.bottom())

        # 绘制右边框
        painter.setPen(QColor('#dadce0'))
        painter.drawLine(rect.right(), rect.top(), rect.right(), rect.bottom())

        # 绘制当前行高亮
        if line == self._current_line:
            painter.fillRect(rect, QColor('#e8f0fe'))

        # 绘制折叠指示器
        if line in self._fold_indicators:
            indicator = self._fold_indicators[line]
            indicator.draw(painter, rect.left(), rect.top(), rect.height())

        # 绘制行号
        painter.setFont(self._font)
        painter.setPen(QColor('#9aa0a6') if line != self._current_line else QColor('#202124'))

        metrics = QFontMetrics(self._font)
        text = str(line)
        text_width = metrics.horizontalAdvance(text)

        x = rect.right() - text_width - 8
        y = rect.top() + (rect.height() - metrics.height()) // 2 + metrics.ascent()

        painter.drawText(x, y, text)

    def set_current_line(self, line: int):
        """设置当前行"""
        self._current_line = line

    def add_fold_indicator(self, line: int, fold_type: str = 'block'):
        """添加折叠指示器"""
        self._fold_indicators[line] = FoldingIndicator(line, fold_type)

    def remove_fold_indicator(self, line: int):
        """移除折叠指示器"""
        if line in self._fold_indicators:
            del self._fold_indicators[line]

    def toggle_fold(self, line: int) -> bool:
        """切换折叠状态"""
        if line in self._fold_indicators:
            indicator = self._fold_indicators[line]
            indicator.collapsed = not indicator.collapsed
            return indicator.collapsed
        return False

    def get_indicator_at(self, x: int, y: int, line: int) -> Optional[FoldingIndicator]:
        """获取指定位置的折叠指示器"""
        if line in self._fold_indicators:
            indicator = self._fold_indicators[line]
            if indicator.contains(x, y):
                return indicator
        return None
