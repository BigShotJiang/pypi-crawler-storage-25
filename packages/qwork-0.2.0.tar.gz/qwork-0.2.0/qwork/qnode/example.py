"""
qnode库使用示例

展示如何使用qnode库创建节点图
"""

from PyQt6.QtWidgets import QVBoxLayout, QLabel, QTextEdit


import sys
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QPointF

from qwork.qnode import (
    NodeCanvasWindow, NodeCanvas, NodeItem,
    NodeShape, ConnectionType, QNodeEditor
)


class MyNodeEditor(QNodeEditor):
    """自定义节点编辑器示例"""
    
    def __init__(self, node, parent=None):
        super().__init__(node, parent)
        self.resize(400, 300)
        
        
        layout = QVBoxLayout(self)
        
        # 显示节点信息
        info_label = QLabel(f"Editing node: {node.name}")
        layout.addWidget(info_label)
        
        # 添加文本编辑器
        self.text_edit = QTextEdit()
        self.text_edit.setPlainText(node.data.get("content", ""))
        layout.addWidget(self.text_edit)
    
    def save(self) -> bool:
        """保存编辑器内容到节点"""
        self.node.data["content"] = self.text_edit.toPlainText()
        return True


def main():
    """主函数"""
    app = QApplication(sys.argv)
    
    # 创建主窗口
    window = NodeCanvasWindow()
    canvas = window.canvas
    
    # 添加一些节点
    node1 = canvas.addNode("Start", QPointF(0, 0), NodeShape.ELLIPSE)
    node2 = canvas.addNode("Process", QPointF(200, 100), NodeShape.RECTANGLE)
    node3 = canvas.addNode("Decision", QPointF(400, 0), NodeShape.DIAMOND)
    node4 = canvas.addNode("End", QPointF(600, 100), NodeShape.ELLIPSE)
    
    # 设置节点编辑器
    node2.editorClass = MyNodeEditor
    
    # 添加一些数据
    node2.data["description"] = "This is a process node"
    node2.data["content"] = "Process logic here..."
    
    # 创建连接
    canvas.addConnection(node1, node2)
    canvas.addConnection(node2, node3)
    canvas.addConnection(node3, node4)
    
    # 设置双向连接示例
    canvas.addConnection(node2, node4, is_bidirectional=True)
    
    # 设置起点节点
    canvas.startNode = node1
    
    # 显示窗口
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
