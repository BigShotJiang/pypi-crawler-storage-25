"""
qnode 箭头拖拽功能演示

演示如何通过拖拽连接线上的箭头来创建新连接。
"""

import sys
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QPointF

from qwork.qnode import NodeCanvas, NodeItem, NodeShape


def DemoArrowDrag():
    """演示箭头拖拽创建新连接功能"""
    app = QApplication(sys.argv)

    # 创建画布
    canvas = NodeCanvas()
    canvas.setWindowTitle("箭头拖拽演示 - 拖拽连接线上的箭头到另一个节点")
    canvas.resize(800, 600)

    # 创建三个节点
    node_a = canvas.addNode("节点 A", QPointF(200, 300), NodeShape.ELLIPSE)
    node_b = canvas.addNode("节点 B", QPointF(500, 200), NodeShape.RECTANGLE)
    node_c = canvas.addNode("节点 C", QPointF(500, 400), NodeShape.RECTANGLE)

    # 创建初始连接 A -> B
    conn = canvas.addConnection(node_a, node_b)
    print(f"创建连接: {node_a.name} -> {node_b.name}")

    # 演示说明
    print("\n=== 箭头拖拽功能说明 ===")
    print("1. 将鼠标悬停在连接线末端的箭头上")
    print("2. 按住鼠标左键拖拽箭头")
    print("3. 拖拽到另一个节点上释放，会创建新连接")
    print("4. 如果是单向连接，原连接会被移除，新连接会被创建")
    print("5. 如果是双向连接，会保留未拖拽方向的连接")
    print("\n提示：可以拖拽箭头到节点C来创建新连接！")

    canvas.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    DemoArrowDrag()
