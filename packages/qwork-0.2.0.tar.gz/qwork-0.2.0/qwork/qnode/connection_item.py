"""
连接项模块 - 表示两个节点之间的连线
包含两个独立的箭头项
"""

import math
from typing import Optional, List, Callable

from PyQt6.QtWidgets import QGraphicsItem, QGraphicsPathItem
from PyQt6.QtCore import Qt, QPointF, QTimer
from PyQt6.QtGui import QPainterPath, QPen, QColor

from qwork.qnode.styles import ConnectionStyle
from qwork.qnode.arrow_item import ArrowItem
from qwork.qnode.enums import ConnectionType


class ConnectionItem(QGraphicsPathItem):
    """
    连接项 - 表示两个节点之间的连线
    包含两个独立的箭头项，可以单独选中
    """
    
    def __init__(
        self,
        source_node: 'NodeItem',
        target_node: 'NodeItem',
        is_bidirectional: bool = False,
        connection_type: ConnectionType = ConnectionType.BEZIER,
        parent: Optional[QGraphicsItem] = None
    ) -> None:
        """
        初始化连接线
        
        Args:
            source_node: 源节点
            target_node: 目标节点
            is_bidirectional: 是否是双向连接
            connection_type: 连线类型（贝塞尔曲线或直线）
            parent: 父项
        """
        super().__init__(parent)
        
        self._source_node: 'NodeItem' = source_node
        self._target_node: 'NodeItem' = target_node
        self._is_bidirectional: bool = is_bidirectional
        self._connection_type: ConnectionType = connection_type
        self._style: ConnectionStyle = ConnectionStyle()
        
        # 设置样式
        self._setupStyle()
        
        # 设置可选项标志（连接线本身可选中，用于右键菜单）
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setAcceptHoverEvents(True)
        self.setZValue(1)
        
        # 创建箭头项
        self._target_arrow: ArrowItem = ArrowItem(self, is_source_arrow=False)
        self._source_arrow: Optional[ArrowItem] = None
        
        # 箭头拖拽回调
        self._arrow_drag_started_callback: Optional[Callable[[QPointF], None]] = None
        self._arrow_drag_moved_callback: Optional[Callable[[QPointF], None]] = None
        self._arrow_drag_finished_callback: Optional[Callable[[QPointF, bool], None]] = None
        
        # 闪烁动画定时器
        self._flash_timer: Optional[QTimer] = None
        
        # 更新路径
        self.updatePath()
    
    def setArrowDragCallbacks(
        self,
        started: Optional[Callable[[QPointF], None]] = None,
        moved: Optional[Callable[[QPointF], None]] = None,
        finished: Optional[Callable[[QPointF, bool], None]] = None
    ) -> None:
        """设置箭头拖拽回调函数"""
        self._arrow_drag_started_callback = started
        self._arrow_drag_moved_callback = moved
        self._arrow_drag_finished_callback = finished
        
        # 更新现有箭头的回调
        if self._target_arrow:
            self._target_arrow.setDragCallbacks(started, moved, finished)
        if self._source_arrow:
            self._source_arrow.setDragCallbacks(started, moved, finished)
    
    def _setupStyle(self) -> None:
        """设置连接线样式"""
        self._normal_pen = QPen(self._style.normal_color, self._style.stroke_width)
        self._normal_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        
        self._selected_pen = QPen(self._style.selected_color, self._style.selected_stroke_width)
        self._selected_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        
        self._hover_pen = QPen(self._style.hover_color, self._style.stroke_width + 1)
        self._hover_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        
        self.setPen(self._normal_pen)
    
    @property
    def sourceNode(self) -> 'NodeItem':
        """获取源节点"""
        return self._source_node
    
    @property
    def targetNode(self) -> 'NodeItem':
        """获取目标节点"""
        return self._target_node
    
    @property
    def targetArrow(self) -> ArrowItem:
        """获取目标端箭头"""
        return self._target_arrow
    
    @property
    def sourceArrow(self) -> Optional[ArrowItem]:
        """获取源端箭头（如果是双向连接）"""
        return self._source_arrow
    
    @property
    def arrows(self) -> List[ArrowItem]:
        """获取所有箭头"""
        arrows = [self._target_arrow]
        if self._source_arrow:
            arrows.append(self._source_arrow)
        return arrows
    
    @property
    def isBidirectional(self) -> bool:
        """是否是双向连接"""
        return self._is_bidirectional
    
    @isBidirectional.setter
    def isBidirectional(self, value: bool) -> None:
        """设置是否为双向连接"""
        self._is_bidirectional = value
        self.updatePath()
    
    @property
    def connectionType(self) -> ConnectionType:
        """获取连线类型"""
        return self._connection_type
    
    @connectionType.setter
    def connectionType(self, value: ConnectionType) -> None:
        """设置连线类型"""
        self._connection_type = value
        self.updatePath()
    
    def toggleConnectionType(self) -> None:
        """切换连线类型（贝塞尔曲线 <-> 直线）"""
        if self._connection_type == ConnectionType.BEZIER:
            self._connection_type = ConnectionType.STRAIGHT
        else:
            self._connection_type = ConnectionType.BEZIER
        self.updatePath()

    def swapDirection(self) -> None:
        """
        交换源节点和目标节点，用于保留反向连接时
        调用后，原来的 target->source 变成 source->target
        """
        # 交换节点引用
        self._source_node, self._target_node = self._target_node, self._source_node

        # 交换箭头引用（因为箭头方向也变了）
        self._target_arrow, self._source_arrow = self._source_arrow, self._target_arrow

        # 更新箭头的 is_source_arrow 标志
        if self._target_arrow:
            self._target_arrow._is_source_arrow = False
        if self._source_arrow:
            self._source_arrow._is_source_arrow = True
        
        # 如果交换后目标箭头为None（原本是源箭头），需要创建新的目标箭头
        if self._target_arrow is None:
            self._target_arrow = ArrowItem(self, is_source_arrow=False)
            if self.scene():
                self.scene().addItem(self._target_arrow)
            # 设置箭头拖拽回调
            self._target_arrow.setDragCallbacks(
                started=self._arrow_drag_started_callback,
                moved=self._arrow_drag_moved_callback,
                finished=self._arrow_drag_finished_callback
            )

        # 更新路径
        self.updatePath()

    def updatePath(self) -> None:
        """更新连线路径和箭头位置"""
        source_pos = self._source_node.sceneBoundingRect().center()
        target_pos = self._target_node.sceneBoundingRect().center()

        # 计算从边缘开始的点（使用节点的 getEdgePoint 方法以支持不同形状）
        source_edge = self._source_node.getEdgePoint(target_pos)
        target_edge = self._target_node.getEdgePoint(source_pos)
        
        # 根据连线类型创建路径
        if self._connection_type == ConnectionType.BEZIER:
            self._updateBezierPath(source_edge, target_edge)
        else:
            self._updateStraightPath(source_edge, target_edge)
    
    def _updateBezierPath(self, source_edge: QPointF, target_edge: QPointF) -> None:
        """更新贝塞尔曲线路径"""
        # 计算控制点（三次贝塞尔曲线）
        dx = target_edge.x() - source_edge.x()
        dy = target_edge.y() - source_edge.y()
        distance = math.sqrt(dx * dx + dy * dy)
        
        # 控制点偏移量（基于距离的比例）
        offset = min(distance * 0.5, 150)
        
        # 如果节点在水平方向差距大，则主要水平延伸
        if abs(dx) > abs(dy):
            ctrl1 = QPointF(source_edge.x() + offset * (1 if dx > 0 else -1), source_edge.y())
            ctrl2 = QPointF(target_edge.x() - offset * (1 if dx > 0 else -1), target_edge.y())
        else:
            # 否则主要垂直延伸
            ctrl1 = QPointF(source_edge.x(), source_edge.y() + offset * (1 if dy > 0 else -1))
            ctrl2 = QPointF(target_edge.x(), target_edge.y() - offset * (1 if dy > 0 else -1))
        
        # 创建路径
        path = QPainterPath()
        path.moveTo(source_edge)
        path.cubicTo(ctrl1, ctrl2, target_edge)
        
        self.setPath(path)
        
        # 更新目标端箭头（正方向）
        target_direction = QPointF(
            (target_edge.x() - ctrl2.x()) / distance if distance > 0 else 1,
            (target_edge.y() - ctrl2.y()) / distance if distance > 0 else 0
        )
        # 归一化
        dir_len = math.sqrt(target_direction.x() ** 2 + target_direction.y() ** 2)
        if dir_len > 0:
            target_direction = QPointF(target_direction.x() / dir_len, target_direction.y() / dir_len)

        arrow_tip_offset = 5.0  # 箭头尖端距离边缘的偏移
        arrow_tip = QPointF(
            target_edge.x() - arrow_tip_offset * target_direction.x(),
            target_edge.y() - arrow_tip_offset * target_direction.y()
        )

        self._target_arrow.updateArrow(arrow_tip, target_direction, ctrl2)
        
        # 确保箭头在场景中
        if self._target_arrow.scene() is None and self.scene():
            self.scene().addItem(self._target_arrow)

        # 如果是双向连线，更新源端箭头
        if self._is_bidirectional:
            if self._source_arrow is None:
                self._source_arrow = ArrowItem(self, is_source_arrow=True)
                if self.scene():
                    self.scene().addItem(self._source_arrow)
                # 设置箭头拖拽回调（如果已设置）
                if self._arrow_drag_started_callback:
                    self._source_arrow.setDragCallbacks(
                        self._arrow_drag_started_callback,
                        self._arrow_drag_moved_callback,
                        self._arrow_drag_finished_callback
                    )

            # 计算源端箭头方向：曲线在源端点的切线方向（使用控制点计算）
            source_direction = QPointF(
                (source_edge.x() - ctrl1.x()) / distance if distance > 0 else -1,
                (source_edge.y() - ctrl1.y()) / distance if distance > 0 else 0
            )
            # 归一化
            dir_len = math.sqrt(source_direction.x() ** 2 + source_direction.y() ** 2)
            if dir_len > 0:
                source_direction = QPointF(source_direction.x() / dir_len, source_direction.y() / dir_len)

            source_arrow_tip = QPointF(
                source_edge.x() - arrow_tip_offset * source_direction.x(),
                source_edge.y() - arrow_tip_offset * source_direction.y()
            )

            self._source_arrow.updateArrow(source_arrow_tip, source_direction, ctrl1)
        else:
            # 如果不是双向，移除源端箭头
            if self._source_arrow:
                if self._source_arrow.scene():
                    self._source_arrow.scene().removeItem(self._source_arrow)
                self._source_arrow = None
    
    def _updateStraightPath(self, source_edge: QPointF, target_edge: QPointF) -> None:
        """更新直线路径"""
        # 创建直线路径
        path = QPainterPath()
        path.moveTo(source_edge)
        path.lineTo(target_edge)
        
        self.setPath(path)
        
        # 计算方向向量
        dx = target_edge.x() - source_edge.x()
        dy = target_edge.y() - source_edge.y()
        distance = math.sqrt(dx * dx + dy * dy)
        
        # 归一化方向向量
        if distance > 0:
            direction = QPointF(dx / distance, dy / distance)
        else:
            direction = QPointF(1, 0)
        
        # 更新目标端箭头
        arrow_tip_offset = 5.0
        arrow_tip = QPointF(
            target_edge.x() - arrow_tip_offset * direction.x(),
            target_edge.y() - arrow_tip_offset * direction.y()
        )
        
        self._target_arrow.updateArrow(arrow_tip, direction, source_edge)
        
        # 确保箭头在场景中
        if self._target_arrow.scene() is None and self.scene():
            self.scene().addItem(self._target_arrow)

        # 如果是双向连线，更新源端箭头
        if self._is_bidirectional:
            if self._source_arrow is None:
                self._source_arrow = ArrowItem(self, is_source_arrow=True)
                if self.scene():
                    self.scene().addItem(self._source_arrow)
                # 设置箭头拖拽回调（如果已设置）
                if self._arrow_drag_started_callback:
                    self._source_arrow.setDragCallbacks(
                        self._arrow_drag_started_callback,
                        self._arrow_drag_moved_callback,
                        self._arrow_drag_finished_callback
                    )

            # 源端箭头方向相反
            source_direction = QPointF(-direction.x(), -direction.y())

            source_arrow_tip = QPointF(
                source_edge.x() - arrow_tip_offset * source_direction.x(),
                source_edge.y() - arrow_tip_offset * source_direction.y()
            )

            self._source_arrow.updateArrow(source_arrow_tip, source_direction, target_edge)
        else:
            # 如果不是双向，移除源端箭头
            if self._source_arrow:
                if self._source_arrow.scene():
                    self._source_arrow.scene().removeItem(self._source_arrow)
                self._source_arrow = None
    
    def setSelected(self, selected: bool) -> None:
        """设置连接线和所有箭头的选中状态"""
        if selected:
            self.setPen(self._selected_pen)
        else:
            self.setPen(self._normal_pen)
        
        # 同时选中/取消选中所有箭头
        self._target_arrow.setSelected(selected)
        if self._source_arrow:
            self._source_arrow.setSelected(selected)
    
    def flashError(self) -> None:
        """闪烁显示错误（连线更改失败）"""
        error_color = QColor("#8B0000")  # 暗灰红色
        error_pen = QPen(error_color, self._style.stroke_width + 2)
        error_pen.setCapStyle(Qt.PenCapStyle.RoundCap)

        original_pen = self.pen()

        # 闪烁3次
        flash_count = [0]

        def toggleFlash():
            flash_count[0] += 1
            if flash_count[0] % 2 == 1:
                self.setPen(error_pen)
            else:
                self.setPen(original_pen)

            if flash_count[0] >= 6:  # 3次闪烁 = 6次切换
                self._flash_timer.stop()
                self._flash_timer.deleteLater()
                self._flash_timer = None
                self.setPen(original_pen)

        self._flash_timer = QTimer()
        self._flash_timer.timeout.connect(toggleFlash)
        self._flash_timer.start(150)  # 150ms间隔

    def flashHighlight(self) -> None:
        """天蓝灰色高亮闪烁（用于子窗口中双击定位连线）"""
        highlight_color = QColor("#87CEEB")  # 天蓝灰色 (Sky Blue)
        highlight_pen = QPen(highlight_color, self._style.stroke_width + 4)
        highlight_pen.setCapStyle(Qt.PenCapStyle.RoundCap)

        original_pen = self.pen()
        original_z = self.zValue()

        # 提升到最上层显示
        self.setZValue(100)

        # 闪烁3次
        flash_count = [0]

        def toggleFlash():
            flash_count[0] += 1
            if flash_count[0] % 2 == 1:
                self.setPen(highlight_pen)
            else:
                self.setPen(original_pen)

            if flash_count[0] >= 6:  # 3次闪烁 = 6次切换
                self._flash_timer.stop()
                self._flash_timer.deleteLater()
                self._flash_timer = None
                self.setPen(original_pen)
                self.setZValue(original_z)  # 恢复原始层级

        self._flash_timer = QTimer()
        self._flash_timer.timeout.connect(toggleFlash)
        self._flash_timer.start(150)  # 150ms间隔

    def setColor(self, color: QColor) -> None:
        """
        设置连接线的主颜色

        Args:
            color: 主颜色
        """
        self._style.normal_color = color
        self._style.selected_color = color
        self._style.hover_color = color
        self._setupStyle()

    def setBorder(self, width: int = 1, color: QColor = None) -> None:
        """
        设置连接线的边框宽度（线宽）和颜色

        Args:
            width: 线宽，<=0 使用默认宽度
            color: 线颜色，None 表示使用默认颜色
        """
        if width > 0:
            self._style.stroke_width = width
            self._style.selected_stroke_width = width + 1
        if color is not None:
            self._style.normal_color = color
            self._style.selected_color = color
            self._style.hover_color = color
        self._setupStyle()

    def hoverEnterEvent(self, event) -> None:
        """鼠标进入事件"""
        super().hoverEnterEvent(event)
    
    def hoverLeaveEvent(self, event) -> None:
        """鼠标离开事件"""
        super().hoverLeaveEvent(event)
    
    def removeArrows(self) -> None:
        """移除所有箭头项"""
        if self._target_arrow and self._target_arrow.scene():
            self._target_arrow.scene().removeItem(self._target_arrow)
        
        if self._source_arrow and self._source_arrow.scene():
            self._source_arrow.scene().removeItem(self._source_arrow)
