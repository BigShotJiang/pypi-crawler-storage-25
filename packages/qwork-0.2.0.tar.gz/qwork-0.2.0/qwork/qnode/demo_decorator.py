"""
qnode 装饰器节点边框颜色演示

演示如何为不同类型的装饰器节点设置不同的边框颜色：
- recursive 装饰的节点 → 紫罗兰色 (violet) 边框
- behavior/sequence/selector/parallel 装饰的节点 → 皇家蓝色 (royal blue) 边框
"""

import sys
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QPointF

from qwork.qnode import NodeCanvas, NodeItem, NodeShape


def DemoDecoratorColors():
    """演示装饰器节点边框颜色"""
    app = QApplication(sys.argv)

    # 创建画布
    canvas = NodeCanvas()
    canvas.setWindowTitle("装饰器节点边框颜色演示")
    canvas.resize(900, 600)

    # 创建普通节点（无装饰器）
    node_normal = canvas.addNode("普通节点", QPointF(150, 150), NodeShape.ELLIPSE)

    # 创建 recursive 装饰的节点 → 紫罗兰色边框
    node_recursive = canvas.addNode("Recursive", QPointF(450, 150), NodeShape.RECTANGLE)
    node_recursive.decorator = "recursive"

    # 创建 behavior 装饰的节点 → 皇家蓝色边框
    node_behavior = canvas.addNode("Behavior", QPointF(150, 300), NodeShape.RECTANGLE)
    node_behavior.decorator = "behavior"

    # 创建 sequence 装饰的节点 → 皇家蓝色边框
    node_sequence = canvas.addNode("Sequence", QPointF(450, 300), NodeShape.RECTANGLE)
    node_sequence.decorator = "sequence"

    # 创建 selector 装饰的节点 → 皇家蓝色边框
    node_selector = canvas.addNode("Selector", QPointF(150, 450), NodeShape.RECTANGLE)
    node_selector.decorator = "selector"

    # 创建 parallel 装饰的节点 → 皇家蓝色边框
    node_parallel = canvas.addNode("Parallel", QPointF(450, 450), NodeShape.RECTANGLE)
    node_parallel.decorator = "parallel"

    # 创建菱形节点带 recursive 装饰器
    node_diamond = canvas.addNode("Recursive\nDiamond", QPointF(750, 300), NodeShape.DIAMOND)
    node_diamond.decorator = "recursive"

    print("=== 装饰器节点边框颜色演示 ===")
    print("紫罗兰色 (Violet) 边框: recursive 装饰的节点")
    print("皇家蓝色 (Royal Blue) 边框: behavior, sequence, selector, parallel 装饰的节点")
    print("")
    print("提示: 点击节点查看选中状态下的颜色效果")

    canvas.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    DemoDecoratorColors()
