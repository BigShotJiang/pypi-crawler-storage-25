"""
框选矩形模块
"""

from typing import Optional

from PyQt6.QtWidgets import QGraphicsItem, QGraphicsRectItem
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QBrush, QPen, QColor


class SelectionRect(QGraphicsRectItem):
    """框选矩形"""

    def __init__(self, parent: Optional[QGraphicsItem] = None) -> None:
        super().__init__(parent)

        # 设置样式（半透明蓝色）
        self._fill_color = QColor(0, 120, 215, 50)
        self._border_color = QColor(0, 120, 215, 200)
        self._border_width = 1

        self.setBrush(QBrush(self._fill_color))
        self.setPen(QPen(self._border_color, self._border_width, Qt.PenStyle.DashLine))

        # 设置Z值，确保在最上层
        self.setZValue(1000)

    def setColor(self, color: QColor) -> None:
        """
        设置框选矩形的填充颜色

        Args:
            color: 填充颜色
        """
        self._fill_color = color
        self.setBrush(QBrush(self._fill_color))

    def setBorder(self, width: int = 1, color: QColor = None) -> None:
        """
        设置框选矩形的边框宽度和颜色

        Args:
            width: 边框宽度，<=0 表示无边框
            color: 边框颜色，None 表示使用默认颜色
        """
        if width <= 0:
            self.setPen(QPen(Qt.PenStyle.NoPen))
        else:
            self._border_width = width
            if color is not None:
                self._border_color = color
            self.setPen(QPen(self._border_color, self._border_width, Qt.PenStyle.DashLine))
