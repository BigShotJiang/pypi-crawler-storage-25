"""


节点编辑器基类模块

提供QNodeEditor基类，用户可以通过继承此类来创建自定义的节点编辑器
"""

from qwork.qnode.node_item import NodeItem


from PyQt6.QtWidgets import QWidget
from typing import Optional, TYPE_CHECKING

class QNodeEditor(QWidget):
    """
    节点编辑器基类
    
    用户可以通过继承此类来创建自定义的节点编辑器。
    当节点被双击时，会实例化对应的编辑器，并将节点作为参数传入。
    
    Example:
        class MyNodeEditor(QNodeEditor):
            def __init__(self, node: NodeItem, parent=None):
                super().__init__(node, parent)
                # 自定义初始化
                
            def getTitle(self) -> str:
                return f"Editing: {self.node.name}"
    """
    
    def __init__(self, node: 'NodeItem', parent: Optional[QWidget] = None) -> None:
        """
        初始化节点编辑器
        
        Args:
            node: 要编辑的节点
            parent: 父窗口
        """
        super().__init__(parent)
        self._node = node
        self._setupUi()
    
    def _setupUi(self) -> None:
        """设置UI界面，子类可以重写此方法"""
        pass
    
    @property
    def node(self) -> 'NodeItem':
        """获取当前编辑的节点"""
        return self._node
    
    def getTitle(self) -> str:
        """获取编辑器窗口标题"""
        return f"Node Editor - {self._node.name}"
    
    def save(self) -> bool:
        """
        保存编辑器内容到节点
        
        Returns:
            True if save successful, False otherwise
        """
        return True
    
    def load(self) -> bool:
        """
        从节点加载内容到编辑器
        
        Returns:
            True if load successful, False otherwise
        """
        return True
