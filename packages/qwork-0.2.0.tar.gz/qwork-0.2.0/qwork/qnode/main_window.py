"""
主窗口模块 - 提供完整的节点画布应用程序窗口
"""

from PyQt6.QtWidgets import QFileDialog


from typing import Optional

from PyQt6.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QMessageBox
from PyQt6.QtCore import Qt

from qwork.qnode.node_canvas import NodeCanvas
from qwork.qnode.menu_bar import MenuBar


class NodeCanvasWindow(QMainWindow):
    """
    节点画布窗口 - 提供完整的节点画布应用程序
    
    Usage:
        from PyQt6.QtWidgets import QApplication
        from qnode import NodeCanvasWindow
        
        app = QApplication([])
        window = NodeCanvasWindow()
        window.show()
        app.exec()
    """
    
    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        
        self.setWindowTitle("NodeCanvas")
        self.setGeometry(100, 100, 1200, 800)
        
        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 创建布局
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # 创建画布
        self._canvas: NodeCanvas = NodeCanvas(self)
        layout.addWidget(self._canvas)
        
        # 创建菜单栏
        self._menu_bar: MenuBar = MenuBar(self)
        self.setMenuBar(self._menu_bar)
        
        # 连接菜单信号
        self._menu_bar.newGraphRequested.connect(self._onNewGraph)
        self._menu_bar.openGraphRequested.connect(self._onOpenGraph)
        self._menu_bar.saveGraphRequested.connect(self._onSaveGraph)
        self._menu_bar.saveAsGraphRequested.connect(self._onSaveAsGraph)
        self._menu_bar.exportGraphRequested.connect(self._onExportGraph)
        self._menu_bar.importGraphRequested.connect(self._onImportGraph)
        self._menu_bar.exitRequested.connect(self._onExit)
        
        # 当前文件路径
        self._current_file_path: Optional[str] = None
    
    @property
    def canvas(self) -> NodeCanvas:
        """获取画布"""
        return self._canvas
    
    def _onNewGraph(self) -> None:
        """新建图"""
        if self._canvas.changed:
            reply = QMessageBox.question(
                self, "Unsaved Changes",
                "The current graph has unsaved changes. Do you want to save them?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel
            )
            
            if reply == QMessageBox.StandardButton.Save:
                self._onSaveGraph()
            elif reply == QMessageBox.StandardButton.Cancel:
                return
        
        self._canvas.clear()
        self._current_file_path = None
        self._canvas.setJsonFilePath(None)
    
    def _onOpenGraph(self, file_path: str) -> None:
        """打开图"""
        if self._canvas.changed:
            reply = QMessageBox.question(
                self, "Unsaved Changes",
                "The current graph has unsaved changes. Do you want to save them?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel
            )
            
            if reply == QMessageBox.StandardButton.Save:
                self._onSaveGraph()
            elif reply == QMessageBox.StandardButton.Cancel:
                return
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                json_data = f.read()
            self._canvas.importData(json_data)
            self._current_file_path = file_path
            self._canvas.setJsonFilePath(file_path)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open file: {e}")
    
    def _onSaveGraph(self) -> None:
        """保存图"""
        if self._current_file_path:
            self._saveToFile(self._current_file_path)
        else:
            self._onSaveAsGraph("")
    
    def _onSaveAsGraph(self, file_path: str) -> None:
        """另存为"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Graph", "", "JSON Files (*.json);;All Files (*)"
        )
        if file_path:
            self._saveToFile(file_path)
            self._current_file_path = file_path
            self._canvas.setJsonFilePath(file_path)
    
    def _saveToFile(self, file_path: str) -> None:
        """保存到文件"""
        try:
            json_data = self._canvas.exportToJson()
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(json_data)
            self._canvas.resetChangedState()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save file: {e}")
    
    def _onExportGraph(self) -> None:
        """导出图"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Export Graph", "", "JSON Files (*.json);;All Files (*)"
        )
        if file_path:
            self._saveToFile(file_path)
    
    def _onImportGraph(self, file_path: str) -> None:
        """导入图"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                json_data = f.read()
            self._canvas.importData(json_data)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to import file: {e}")
    
    def _onExit(self) -> None:
        """退出"""
        if self._canvas.changed:
            reply = QMessageBox.question(
                self, "Unsaved Changes",
                "The current graph has unsaved changes. Do you want to save them?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel
            )
            
            if reply == QMessageBox.StandardButton.Save:
                self._onSaveGraph()
            elif reply == QMessageBox.StandardButton.Cancel:
                return
        
        self.close()
    
    def closeEvent(self, event) -> None:
        """关闭事件"""
        if self._canvas.changed:
            reply = QMessageBox.question(
                self, "Unsaved Changes",
                "The current graph has unsaved changes. Do you want to save them?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel
            )
            
            if reply == QMessageBox.StandardButton.Save:
                self._onSaveGraph()
                if self._canvas.changed:  # 如果保存失败
                    event.ignore()
                    return
            elif reply == QMessageBox.StandardButton.Cancel:
                event.ignore()
                return
        
        event.accept()
