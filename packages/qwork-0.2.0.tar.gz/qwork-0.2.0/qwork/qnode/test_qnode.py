"""
qnode库测试模块

使用PyQt6的测试框架测试所有功能
"""

from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QPoint


import sys
import unittest
from typing import Optional

from PyQt6.QtWidgets import QApplication, QGraphicsScene
from PyQt6.QtCore import Qt, QPointF, QRectF
from PyQt6.QtTest import QTest

from qwork.qnode import (
    NodeCanvas, NodeItem, ConnectionItem, ArrowItem,
    NodeState, NodeShape, ArrowState, ConnectionType,
    NodeStyle, ConnectionStyle, ArrowStyle,
    SelectionRect, QNodeEditor
)


class TestEnums(unittest.TestCase):
    """测试枚举类"""
    
    def testNodeState(self) -> None:
        """测试NodeState枚举"""
        self.assertEqual(NodeState.IDLE.name, "IDLE")
        self.assertEqual(NodeState.HOVER.name, "HOVER")
        self.assertEqual(NodeState.SELECTED.name, "SELECTED")
    
    def testNodeShape(self) -> None:
        """测试NodeShape枚举"""
        self.assertEqual(NodeShape.ELLIPSE.name, "ELLIPSE")
        self.assertEqual(NodeShape.RECTANGLE.name, "RECTANGLE")
        self.assertEqual(NodeShape.DIAMOND.name, "DIAMOND")
    
    def testArrowState(self) -> None:
        """测试ArrowState枚举"""
        self.assertEqual(ArrowState.IDLE.name, "IDLE")
        self.assertEqual(ArrowState.HOVER.name, "HOVER")
        self.assertEqual(ArrowState.SELECTED.name, "SELECTED")
    
    def testConnectionType(self) -> None:
        """测试ConnectionType枚举"""
        self.assertEqual(ConnectionType.BEZIER.name, "BEZIER")
        self.assertEqual(ConnectionType.STRAIGHT.name, "STRAIGHT")


class TestStyles(unittest.TestCase):
    """测试样式类"""
    
    def testNodeStyle(self) -> None:
        """测试NodeStyle"""
        style = NodeStyle()
        self.assertIsNotNone(style.idle_fill)
        self.assertIsNotNone(style.idle_stroke)
        self.assertIsNotNone(style.hover_overlay)
        self.assertIsNotNone(style.selected_stroke)
        self.assertIsNotNone(style.selected_overlay)
        self.assertEqual(style.stroke_width, 2.0)
        self.assertIsNotNone(style.text_color)
    
    def testConnectionStyle(self) -> None:
        """测试ConnectionStyle"""
        style = ConnectionStyle()
        self.assertIsNotNone(style.normal_color)
        self.assertIsNotNone(style.selected_color)
        self.assertIsNotNone(style.hover_color)
        self.assertEqual(style.stroke_width, 2.0)
        self.assertEqual(style.selected_stroke_width, 3.0)
    
    def testArrowStyle(self) -> None:
        """测试ArrowStyle"""
        style = ArrowStyle()
        self.assertIsNotNone(style.normal_color)
        self.assertIsNotNone(style.selected_color)
        self.assertIsNotNone(style.hover_color)
        self.assertEqual(style.arrow_size, 12.0)
        self.assertEqual(style.stroke_width, 2.0)


class TestNodeItem(unittest.TestCase):
    """测试NodeItem类"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.node = NodeItem("TestNode", QPointF(100, 100), NodeShape.ELLIPSE)
        self.scene.addItem(self.node)
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.scene.clear()
    
    def testNodeCreation(self) -> None:
        """测试节点创建"""
        self.assertEqual(self.node.name, "TestNode")
        self.assertEqual(self.node.pos(), QPointF(100, 100))
        self.assertEqual(self.node.nodeShape, NodeShape.ELLIPSE)
        self.assertEqual(self.node.state, NodeState.IDLE)
    
    def testNodeNameChange(self) -> None:
        """测试节点名称修改"""
        self.node.name = "NewName"
        self.assertEqual(self.node.name, "NewName")
    
    def testNodeShapeChange(self) -> None:
        """测试节点形状修改"""
        self.node.nodeShape = NodeShape.RECTANGLE
        self.assertEqual(self.node.nodeShape, NodeShape.RECTANGLE)
        
        self.node.nodeShape = NodeShape.DIAMOND
        self.assertEqual(self.node.nodeShape, NodeShape.DIAMOND)
    
    def testNodeData(self) -> None:
        """测试节点数据"""
        # 数据字典应该是可修改的
        self.node.data["key"] = "value"
        self.assertEqual(self.node.data["key"], "value")
        
        self.node.data["number"] = 42
        self.assertEqual(self.node.data["number"], 42)
    
    def testNodeEditorClass(self) -> None:
        """测试节点编辑器类"""
        self.assertIsNone(self.node.editorClass)
        
        # 设置编辑器类
        class TestEditor(QNodeEditor):
            pass
        
        self.node.editorClass = TestEditor
        self.assertEqual(self.node.editorClass, TestEditor)
    
    def testNodeSelection(self) -> None:
        """测试节点选择"""
        self.node.setSelected(True)
        self.assertTrue(self.node.isSelected())
        self.assertEqual(self.node.state, NodeState.SELECTED)
        
        self.node.setSelected(False)
        self.assertFalse(self.node.isSelected())
        self.assertEqual(self.node.state, NodeState.IDLE)
    
    def testNodeToDict(self) -> None:
        """测试节点转字典"""
        self.node.data["test"] = "data"
        data = self.node.toDict()
        
        self.assertIn("id", data)
        self.assertEqual(data["name"], "TestNode")
        self.assertEqual(data["shape"], "ELLIPSE")
        self.assertIn("position", data)
        self.assertIn("data", data)
        self.assertEqual(data["data"]["test"], "data")
    
    def testNodeFromDict(self) -> None:
        """测试节点从字典更新"""
        data = {
            "name": "UpdatedName",
            "shape": "RECTANGLE",
            "position": {"x": 200, "y": 300},
            "data": {"custom": "value"}
        }
        self.node.fromDict(data)
        
        self.assertEqual(self.node.name, "UpdatedName")
        self.assertEqual(self.node.nodeShape, NodeShape.RECTANGLE)
        self.assertEqual(self.node.pos(), QPointF(200, 300))
        self.assertEqual(self.node.data["custom"], "value")
    
    def testGetEdgePointEllipse(self) -> None:
        """测试圆形节点边缘点计算"""
        self.node.shape = NodeShape.ELLIPSE
        center = self.node.sceneBoundingRect().center()
        target = QPointF(center.x() + 200, center.y())
        edge = self.node.getEdgePoint(target)
        
        # 边缘点应该在中心右侧
        self.assertGreater(edge.x(), center.x())
    
    def testGetEdgePointRectangle(self) -> None:
        """测试矩形节点边缘点计算"""
        self.node.shape = NodeShape.RECTANGLE
        center = self.node.sceneBoundingRect().center()
        target = QPointF(center.x() + 200, center.y())
        edge = self.node.getEdgePoint(target)
        
        # 边缘点应该在中心右侧
        self.assertGreater(edge.x(), center.x())
    
    def testGetEdgePointDiamond(self) -> None:
        """测试菱形节点边缘点计算"""
        self.node.shape = NodeShape.DIAMOND
        center = self.node.sceneBoundingRect().center()
        target = QPointF(center.x() + 200, center.y())
        edge = self.node.getEdgePoint(target)

        # 边缘点应该在中心右侧
        self.assertGreater(edge.x(), center.x())

    def testSetColor(self) -> None:
        """测试设置节点颜色"""

        # 设置新颜色
        new_color = QColor(255, 0, 0)  # 红色
        self.node.setColor(new_color)

        # 验证颜色已设置
        self.assertEqual(self.node._style.idle_fill, new_color)

    def testSetBorder(self) -> None:
        """测试设置节点边框"""

        # 设置边框宽度和颜色
        border_color = QColor(0, 255, 0)  # 绿色
        self.node.setBorder(3, border_color)

        # 验证边框设置
        self.assertEqual(self.node._style.stroke_width, 3)
        self.assertEqual(self.node._style.idle_stroke, border_color)

        # 测试无边框（宽度<=0）
        self.node.setBorder(0)
        # 应该设置NoPen
        pen = self.node.pen()
        self.assertEqual(pen.style(), Qt.PenStyle.NoPen)

    def testNodeNameEditingState(self) -> None:
        """测试节点名称编辑状态"""
        # 初始状态应该不在编辑
        self.assertFalse(self.node.isEditingName)

        # 开始编辑
        self.node._startNameEdit()
        self.assertTrue(self.node.isEditingName)

        # 完成编辑
        self.node._finishNameEdit()
        self.assertFalse(self.node.isEditingName)

    def testNodeNameEditCancel(self) -> None:
        """测试取消节点名称编辑（保持原名称）"""
        original_name = self.node.name

        # 开始编辑
        self.node._startNameEdit()
        self.assertTrue(self.node.isEditingName)

        # 修改文本但不确认
        if self.node._name_edit:
            self.node._name_edit.setText("NewName")

        # 直接调用_finishNameEdit（模拟点击外部取消）
        self.node._finishNameEdit()

        # 由于文本被修改了，名称应该改变
        # 如果要测试取消功能，需要更复杂的逻辑
        self.assertFalse(self.node.isEditingName)

    def testNodeNameEditProxyWidget(self) -> None:
        """测试节点名称编辑使用QGraphicsProxyWidget"""
        # 开始编辑
        self.node._startNameEdit()
        self.assertTrue(self.node.isEditingName)

        # 检查代理控件存在
        self.assertTrue(hasattr(self.node, '_name_edit_proxy'))
        self.assertIsNotNone(self.node._name_edit_proxy)

        # 检查代理控件的父项是节点本身
        self.assertEqual(self.node._name_edit_proxy.parentItem(), self.node)

        # 完成编辑
        self.node._finishNameEdit()
        self.assertFalse(self.node.isEditingName)


class TestConnectionItem(unittest.TestCase):
    """测试ConnectionItem类"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.source_node = NodeItem("Source", QPointF(0, 0))
        self.target_node = NodeItem("Target", QPointF(200, 0))
        self.scene.addItem(self.source_node)
        self.scene.addItem(self.target_node)
        
        self.connection = ConnectionItem(
            self.source_node, self.target_node,
            is_bidirectional=False,
            connection_type=ConnectionType.BEZIER
        )
        self.scene.addItem(self.connection)
        self.scene.addItem(self.connection.targetArrow)
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.connection.removeArrows()
        self.scene.removeItem(self.connection)
        self.scene.clear()
    
    def testConnectionCreation(self) -> None:
        """测试连接创建"""
        self.assertEqual(self.connection.sourceNode, self.source_node)
        self.assertEqual(self.connection.targetNode, self.target_node)
        self.assertFalse(self.connection.isBidirectional)
        self.assertEqual(self.connection.connectionType, ConnectionType.BEZIER)
    
    def testConnectionTypeToggle(self) -> None:
        """测试连接类型切换"""
        self.assertEqual(self.connection.connectionType, ConnectionType.BEZIER)
        
        self.connection.toggleConnectionType()
        self.assertEqual(self.connection.connectionType, ConnectionType.STRAIGHT)
        
        self.connection.toggleConnectionType()
        self.assertEqual(self.connection.connectionType, ConnectionType.BEZIER)
    
    def testBidirectionalToggle(self) -> None:
        """测试双向连接切换"""
        self.assertFalse(self.connection.isBidirectional)
        
        self.connection.isBidirectional = True
        self.assertTrue(self.connection.isBidirectional)
        self.assertIsNotNone(self.connection.sourceArrow)
        
        self.connection.isBidirectional = False
        self.assertFalse(self.connection.isBidirectional)
        self.assertIsNone(self.connection.sourceArrow)
    
    def testSwapDirection(self) -> None:
        """测试连接方向交换"""
        original_source = self.connection.sourceNode
        original_target = self.connection.targetNode
        
        self.connection.swapDirection()

        self.assertEqual(self.connection.sourceNode, original_target)
        self.assertEqual(self.connection.targetNode, original_source)

    def testConnectionSetColor(self) -> None:
        """测试设置连接线颜色"""

        new_color = QColor(255, 0, 0)  # 红色
        self.connection.setColor(new_color)

        # 验证颜色已设置
        self.assertEqual(self.connection._style.normal_color, new_color)

    def testConnectionSetBorder(self) -> None:
        """测试设置连接线边框（线宽）"""

        # 设置线宽和颜色
        border_color = QColor(0, 255, 0)  # 绿色
        self.connection.setBorder(5, border_color)

        # 验证设置
        self.assertEqual(self.connection._style.stroke_width, 5)


class TestArrowItem(unittest.TestCase):
    """测试ArrowItem类"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.source_node = NodeItem("Source", QPointF(0, 0))
        self.target_node = NodeItem("Target", QPointF(200, 0))
        self.scene.addItem(self.source_node)
        self.scene.addItem(self.target_node)
        
        self.connection = ConnectionItem(self.source_node, self.target_node)
        self.scene.addItem(self.connection)
        self.arrow = self.connection.targetArrow
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.connection.removeArrows()
        self.scene.removeItem(self.connection)
        self.scene.clear()
    
    def testArrowCreation(self) -> None:
        """测试箭头创建"""
        self.assertEqual(self.arrow.connection, self.connection)
        self.assertFalse(self.arrow.isSourceArrow)
    
    def testArrowSelection(self) -> None:
        """测试箭头选择"""
        self.arrow.setSelected(True)
        self.assertTrue(self.arrow.isSelected())

        self.arrow.setSelected(False)
        self.assertFalse(self.arrow.isSelected())

    def testArrowSetColor(self) -> None:
        """测试设置箭头颜色"""

        new_color = QColor(255, 0, 0)  # 红色
        self.arrow.setColor(new_color)

        # 验证颜色已设置
        self.assertEqual(self.arrow._style.normal_color, new_color)

    def testArrowSetBorder(self) -> None:
        """测试设置箭头边框"""

        # 设置边框宽度和颜色
        border_color = QColor(0, 255, 0)  # 绿色
        self.arrow.setBorder(3, border_color)

        # 验证设置
        self.assertEqual(self.arrow._style.stroke_width, 3)


class TestSelectionRect(unittest.TestCase):
    """测试SelectionRect类"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.selection_rect = SelectionRect()
        self.scene.addItem(self.selection_rect)
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.scene.clear()
    
    def testSelectionRectCreation(self) -> None:
        """测试框选矩形创建"""
        self.assertIsNotNone(self.selection_rect)
        self.assertEqual(self.selection_rect.zValue(), 1000)

    def testSelectionRectSetColor(self) -> None:
        """测试设置框选矩形颜色"""

        new_color = QColor(255, 0, 0, 100)  # 半透明红色
        self.selection_rect.setColor(new_color)

        # 验证颜色已设置
        self.assertEqual(self.selection_rect._fill_color, new_color)

    def testSelectionRectSetBorder(self) -> None:
        """测试设置框选矩形边框"""

        # 设置边框宽度和颜色
        border_color = QColor(0, 255, 0)  # 绿色
        self.selection_rect.setBorder(3, border_color)

        # 验证设置
        self.assertEqual(self.selection_rect._border_width, 3)
        self.assertEqual(self.selection_rect._border_color, border_color)


class TestNodeCanvas(unittest.TestCase):
    """测试NodeCanvas类"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.canvas = NodeCanvas()
        self.canvas.resize(800, 600)
        self.canvas.show()
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.canvas.close()
    
    def testCanvasCreation(self) -> None:
        """测试画布创建"""
        self.assertIsNotNone(self.canvas.scene())
        self.assertEqual(len(self.canvas.nodes), 0)
        self.assertEqual(len(self.canvas.connections), 0)
    
    def testAddNode(self) -> None:
        """测试添加节点"""
        node = self.canvas.addNode("TestNode", QPointF(100, 100))
        self.assertIn(node, self.canvas.nodes)
        self.assertEqual(node.name, "TestNode")
    
    def testRemoveNode(self) -> None:
        """测试移除节点"""
        node = self.canvas.addNode("TestNode")
        self.canvas.removeNode(node)
        self.assertNotIn(node, self.canvas.nodes)
    
    def testAddConnection(self) -> None:
        """测试添加连接"""
        node1 = self.canvas.addNode("Node1", QPointF(0, 0))
        node2 = self.canvas.addNode("Node2", QPointF(200, 0))
        
        connection = self.canvas.addConnection(node1, node2)
        self.assertIn(connection, self.canvas.connections)
        self.assertEqual(connection.sourceNode, node1)
        self.assertEqual(connection.targetNode, node2)
    
    def testRemoveConnection(self) -> None:
        """测试移除连接"""
        node1 = self.canvas.addNode("Node1")
        node2 = self.canvas.addNode("Node2")
        connection = self.canvas.addConnection(node1, node2)
        
        self.canvas.removeConnection(connection)
        self.assertNotIn(connection, self.canvas.connections)
    
    def testStartNode(self) -> None:
        """测试起点节点"""
        node = self.canvas.addNode("StartNode")
        self.canvas.startNode = node
        
        self.assertEqual(self.canvas.startNode, node)
    
    def testExportImport(self) -> None:
        """测试导出导入"""
        # 创建一些节点和连接
        node1 = self.canvas.addNode("Node1", QPointF(0, 0))
        node2 = self.canvas.addNode("Node2", QPointF(100, 100))
        self.canvas.addConnection(node1, node2)
        self.canvas.startNode = node1
        
        # 导出（现在返回字典）
        data = self.canvas.export()
        self.assertIsInstance(data, dict)
        self.assertIn("nodes", data)
        self.assertIn("connections", data)

        # 测试导出为 JSON 字符串
        json_str = self.canvas.exportToJson()
        self.assertIsInstance(json_str, str)
        self.assertIn("nodes", json_str)

        # 清空
        self.canvas.clear()
        self.assertEqual(len(self.canvas.nodes), 0)
        self.assertEqual(len(self.canvas.connections), 0)

        # 导入字典
        self.canvas.importData(data)
        self.assertEqual(len(self.canvas.nodes), 2)
        self.assertEqual(len(self.canvas.connections), 1)
    
    def testClear(self) -> None:
        """测试清空画布"""
        node1 = self.canvas.addNode("Node1")
        node2 = self.canvas.addNode("Node2")
        self.canvas.addConnection(node1, node2)
        
        self.canvas.clear()
        self.assertEqual(len(self.canvas.nodes), 0)
        self.assertEqual(len(self.canvas.connections), 0)
    
    def testChangedState(self) -> None:
        """测试修改状态"""
        self.assertFalse(self.canvas.changed)

        self.canvas.addNode("TestNode")
        self.assertTrue(self.canvas.changed)

    def testClickOutsideToCancelNameEdit(self) -> None:
        """测试点击画布外部取消节点名称编辑"""
        # 添加节点
        node = self.canvas.addNode("TestNode", QPointF(100, 100))

        # 开始编辑
        node._startNameEdit()
        self.assertTrue(node.isEditingName)

        # 获取编辑控件的位置（在节点中心）
        proxy_rect = node._name_edit_proxy.sceneBoundingRect()
        edit_center = proxy_rect.center()

        # 模拟点击画布外部（远离编辑控件）
        outside_pos = QPointF(edit_center.x() + 200, edit_center.y() + 200)

        # 创建鼠标事件

        # 将场景坐标转换为视图坐标
        view_pos = self.canvas.mapFromScene(outside_pos)

        # 发送鼠标按下事件
        QTest.mouseClick(self.canvas.viewport(), Qt.MouseButton.LeftButton,
                        pos=view_pos)

        # 检查编辑是否被取消
        self.assertFalse(node.isEditingName)

    def testEdgeDetectionEllipse(self) -> None:
        """测试圆形节点边缘检测"""
        node = self.canvas.addNode("EllipseNode", QPointF(100, 100), NodeShape.ELLIPSE)
        center = node.sceneBoundingRect().center()
        radius = node.radius

        # 边缘位置（应该检测到）
        edge_pos = QPointF(center.x() + radius * 0.9, center.y())
        self.assertTrue(self.canvas._is_on_node_edge(node, edge_pos))

        # 中心位置（不应该检测到）
        center_pos = QPointF(center.x() + radius * 0.5, center.y())
        self.assertFalse(self.canvas._is_on_node_edge(node, center_pos))

        # 外部位置（不应该检测到）
        outside_pos = QPointF(center.x() + radius * 1.2, center.y())
        self.assertFalse(self.canvas._is_on_node_edge(node, outside_pos))

    def testEdgeDetectionRectangle(self) -> None:
        """测试矩形节点边缘检测，包括角落区域"""
        node = self.canvas.addNode("RectNode", QPointF(100, 100), NodeShape.RECTANGLE)
        center = node.sceneBoundingRect().center()
        rect = node.rect()
        half_w = rect.width() / 2
        half_h = rect.height() / 2

        # 右边缘位置（应该检测到）
        right_edge = QPointF(center.x() + half_w * 0.9, center.y())
        self.assertTrue(self.canvas._is_on_node_edge(node, right_edge))

        # 左边缘位置（应该检测到）
        left_edge = QPointF(center.x() - half_w * 0.9, center.y())
        self.assertTrue(self.canvas._is_on_node_edge(node, left_edge))

        # 上边缘位置（应该检测到）
        top_edge = QPointF(center.x(), center.y() - half_h * 0.9)
        self.assertTrue(self.canvas._is_on_node_edge(node, top_edge))

        # 下边缘位置（应该检测到）
        bottom_edge = QPointF(center.x(), center.y() + half_h * 0.9)
        self.assertTrue(self.canvas._is_on_node_edge(node, bottom_edge))

        # 角落区域（应该检测到）- 在圆角边缘附近
        # 计算一个更靠近实际边界的测试点
        inner_w = half_w - min(half_w, half_h) * 0.2
        inner_h = half_h - min(half_w, half_h) * 0.2
        # 在角落附近，稍微超出内矩形边界
        corner_pos = QPointF(center.x() + inner_w * 1.05, center.y() + inner_h * 1.05)
        self.assertTrue(self.canvas._is_on_node_edge(node, corner_pos))

        # 中心位置（不应该检测到）
        center_pos = QPointF(center.x(), center.y())
        self.assertFalse(self.canvas._is_on_node_edge(node, center_pos))

        # 外部位置（不应该检测到）
        outside_pos = QPointF(center.x() + half_w * 1.2, center.y())
        self.assertFalse(self.canvas._is_on_node_edge(node, outside_pos))

    def testEdgeDetectionRectangleCorners(self) -> None:
        """测试矩形节点四个角落的边缘检测"""
        node = self.canvas.addNode("RectNode", QPointF(100, 100), NodeShape.RECTANGLE)
        center = node.sceneBoundingRect().center()
        rect = node.rect()
        half_w = rect.width() / 2
        half_h = rect.height() / 2
        corner_radius = min(half_w, half_h) * 0.2
        inner_w = half_w - corner_radius
        inner_h = half_h - corner_radius

        # 测试四个角落（在圆角边缘附近）
        # 需要确保测试点在 inner_w/h 之外，但在 half_w/h 之内
        # 使用 inner_w * 1.1 确保在圆角区域内
        corners = [
            ("左下", QPointF(center.x() - inner_w * 1.1, center.y() + inner_h * 1.1)),
            ("右下", QPointF(center.x() + inner_w * 1.1, center.y() + inner_h * 1.1)),
            ("左上", QPointF(center.x() - inner_w * 1.1, center.y() - inner_h * 1.1)),
            ("右上", QPointF(center.x() + inner_w * 1.1, center.y() - inner_h * 1.1)),
        ]

        for name, pos in corners:
            with self.subTest(corner=name):
                self.assertTrue(
                    self.canvas._is_on_node_edge(node, pos),
                    f"{name}角落应该被检测为边缘区域"
                )

    def testEdgeDetectionDiamond(self) -> None:
        """测试菱形节点边缘检测"""
        node = self.canvas.addNode("DiamondNode", QPointF(100, 100), NodeShape.DIAMOND)
        center = node.sceneBoundingRect().center()
        radius = node.radius

        # 右顶点边缘位置（应该检测到）
        right_edge = QPointF(center.x() + radius * 0.9, center.y())
        self.assertTrue(self.canvas._is_on_node_edge(node, right_edge))

        # 上顶点边缘位置（应该检测到）
        top_edge = QPointF(center.x(), center.y() - radius * 0.9)
        self.assertTrue(self.canvas._is_on_node_edge(node, top_edge))

        # 中心位置（不应该检测到）
        center_pos = QPointF(center.x() + radius * 0.3, center.y() + radius * 0.3)
        self.assertFalse(self.canvas._is_on_node_edge(node, center_pos))

        # 外部位置（不应该检测到）
        outside_pos = QPointF(center.x() + radius * 1.2, center.y())
        self.assertFalse(self.canvas._is_on_node_edge(node, outside_pos))

    def testDuplicateConnectionFlashError(self) -> None:
        """测试重复连接时触发错误闪烁"""
        node1 = self.canvas.addNode("Node1", QPointF(0, 0))
        node2 = self.canvas.addNode("Node2", QPointF(200, 0))

        # 创建第一个连接
        conn1 = self.canvas.addConnection(node1, node2)
        self.assertEqual(len(self.canvas.connections), 1)

        # 尝试创建重复连接，应该返回已存在的连接并触发 flashError
        conn2 = self.canvas.addConnection(node1, node2)
        self.assertEqual(conn1, conn2)  # 返回同一个连接
        self.assertEqual(len(self.canvas.connections), 1)  # 连接数量不变

    def testReverseConnectionBecomesBidirectional(self) -> None:
        """测试反向连接转换为双向连接"""
        node1 = self.canvas.addNode("Node1", QPointF(0, 0))
        node2 = self.canvas.addNode("Node2", QPointF(200, 0))

        # 创建 node1 -> node2 的连接
        conn1 = self.canvas.addConnection(node1, node2)
        self.assertFalse(conn1.isBidirectional)
        self.assertEqual(len(self.canvas.connections), 1)

        # 创建反向连接 node2 -> node1，应该将原连接变为双向
        conn2 = self.canvas.addConnection(node2, node1)
        self.assertTrue(conn1.isBidirectional)  # 原连接变为双向
        self.assertEqual(conn1, conn2)  # 返回同一个连接
        self.assertEqual(len(self.canvas.connections), 1)  # 连接数量不变

    def testDuplicateBidirectionalConnectionFlashError(self) -> None:
        """测试重复双向连接时触发错误闪烁"""
        node1 = self.canvas.addNode("Node1", QPointF(0, 0))
        node2 = self.canvas.addNode("Node2", QPointF(200, 0))

        # 创建双向连接
        conn1 = self.canvas.addConnection(node1, node2, is_bidirectional=True)
        self.assertTrue(conn1.isBidirectional)

        # 尝试创建反向连接，应该触发 flashError
        conn2 = self.canvas.addConnection(node2, node1)
        self.assertEqual(conn1, conn2)
        self.assertTrue(conn1.isBidirectional)  # 保持双向


class TestQNodeEditor(unittest.TestCase):
    """测试QNodeEditor类"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.node = NodeItem("TestNode")
        self.scene.addItem(self.node)
        self.editor = QNodeEditor(self.node)
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.editor.close()
        self.scene.clear()
    
    def testEditorCreation(self) -> None:
        """测试编辑器创建"""
        self.assertEqual(self.editor.node, self.node)
    
    def testEditorTitle(self) -> None:
        """测试编辑器标题"""
        title = self.editor.getTitle()
        self.assertIn("TestNode", title)
    
    def testEditorSaveLoad(self) -> None:
        """测试编辑器保存和加载"""
        self.assertTrue(self.editor.save())
        self.assertTrue(self.editor.load())


class TestNodeShapes(unittest.TestCase):
    """测试不同节点形状"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def testEllipseShape(self) -> None:
        """测试椭圆形"""
        node = NodeItem("EllipseNode", shape=NodeShape.ELLIPSE)
        self.assertEqual(node.nodeShape, NodeShape.ELLIPSE)
        
        # 测试边缘点计算
        center = QPointF(100, 100)
        node.setPos(center)
        target = QPointF(200, 100)
        edge = node.getEdgePoint(target)
        self.assertIsNotNone(edge)
    
    def testRectangleShape(self) -> None:
        """测试矩形"""
        node = NodeItem("RectNode", shape=NodeShape.RECTANGLE)
        self.assertEqual(node.nodeShape, NodeShape.RECTANGLE)
        
        # 测试边缘点计算
        center = QPointF(100, 100)
        node.setPos(center)
        target = QPointF(200, 100)
        edge = node.getEdgePoint(target)
        self.assertIsNotNone(edge)
    
    def testDiamondShape(self) -> None:
        """测试菱形"""
        node = NodeItem("DiamondNode", shape=NodeShape.DIAMOND)
        self.assertEqual(node.nodeShape, NodeShape.DIAMOND)
        
        # 测试边缘点计算
        center = QPointF(100, 100)
        node.setPos(center)
        target = QPointF(200, 100)
        edge = node.getEdgePoint(target)
        self.assertIsNotNone(edge)


class TestArrowDragFunctionality(unittest.TestCase):
    """测试箭头拖拽创建新连接功能"""

    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)

    def setUp(self) -> None:
        """设置每个测试"""
        self.canvas = NodeCanvas()
        self.canvas.show()
        # 添加三个节点用于测试
        self.nodeA = self.canvas.addNode("NodeA", QPointF(0, 0))
        self.nodeB = self.canvas.addNode("NodeB", QPointF(300, 0))
        self.nodeC = self.canvas.addNode("NodeC", QPointF(600, 0))

    def tearDown(self) -> None:
        """清理每个测试"""
        self.canvas.close()

    def testArrowDragStateTracking(self) -> None:
        """测试箭头拖拽状态追踪属性"""
        # 创建连接
        conn = self.canvas.addConnection(self.nodeA, self.nodeB)
        self.assertIsNotNone(conn)

        # 获取目标箭头
        arrow = conn.targetArrow
        self.assertIsNotNone(arrow)

        # 检查isDragging初始状态
        self.assertFalse(arrow.isDragging)
        self.assertFalse(arrow.isSourceArrow)

    def testArrowDragSourceArrowProperty(self) -> None:
        """测试源端箭头属性"""
        # 创建双向连接
        conn = self.canvas.addConnection(self.nodeA, self.nodeB, is_bidirectional=True)
        self.assertIsNotNone(conn)
        self.assertTrue(conn.isBidirectional)

        # 检查目标箭头
        target_arrow = conn.targetArrow
        self.assertIsNotNone(target_arrow)
        self.assertFalse(target_arrow.isSourceArrow)

        # 检查源端箭头
        source_arrow = conn.sourceArrow
        self.assertIsNotNone(source_arrow)
        self.assertTrue(source_arrow.isSourceArrow)

    def testAddConnectionWithCheckPartners(self) -> None:
        """测试addConnection的checkPartners参数"""
        # 创建 A -> B 连接
        conn1 = self.canvas.addConnection(self.nodeA, self.nodeB)
        self.assertIsNotNone(conn1)
        self.assertEqual(len(self.canvas.connections), 1)

        # 使用 check_partners=False 尝试创建新连接（应该成功）
        conn2 = self.canvas.addConnection(self.nodeA, self.nodeC, check_partners=False)
        self.assertIsNotNone(conn2)
        self.assertEqual(len(self.canvas.connections), 2)
        self.assertIn(conn2, self.canvas.connections)

    def testAddConnectionSelfConnection(self) -> None:
        """测试连接到自身返回None"""
        # 尝试连接节点到自身
        conn = self.canvas.addConnection(self.nodeA, self.nodeA)
        self.assertIsNone(conn)

    def testDragTargetArrowCreatesNewConnection(self) -> None:
        """测试拖拽目标端箭头创建新连接"""
        # 创建 A -> B 的单向连接
        conn = self.canvas.addConnection(self.nodeA, self.nodeB)
        self.assertEqual(len(self.canvas.connections), 1)

        # 获取目标箭头（从A指向B的箭头）
        arrow = conn.targetArrow

        # 设置箭头拖拽状态（模拟拖拽开始）
        arrow._is_dragging = True
        drag_pos = self.nodeC.sceneBoundingRect().center()

        self.canvas._onArrowDragStarted(drag_pos)

        # 验证临时连接线已创建
        self.assertIsNotNone(self.canvas._temp_new_connection)
        self.assertEqual(self.canvas._dragged_arrow, arrow)
        self.assertEqual(self.canvas._original_connection, conn)

        # 模拟拖拽移动
        self.canvas._onArrowDragMoved(drag_pos)

        # 模拟拖拽结束到NodeC
        self.canvas._onArrowDragFinished(drag_pos, is_success=True)

        # 验证新连接已创建 A -> C
        self.assertEqual(len(self.canvas.connections), 1)
        new_conn = self.canvas.connections[0]
        self.assertEqual(new_conn.sourceNode, self.nodeA)
        self.assertEqual(new_conn.targetNode, self.nodeC)

    def testDragSourceArrowCreatesNewConnection(self) -> None:
        """测试拖拽源端箭头创建新连接（双向连接情况）"""
        # 创建 A <-> B 的双向连接
        conn = self.canvas.addConnection(self.nodeA, self.nodeB, is_bidirectional=True)
        self.assertEqual(len(self.canvas.connections), 1)

        # 获取源端箭头（从B指向A的箭头）
        source_arrow = conn.sourceArrow
        self.assertIsNotNone(source_arrow)

        # 设置箭头拖拽状态（模拟拖拽开始）
        source_arrow._is_dragging = True
        drag_pos = self.nodeC.sceneBoundingRect().center()
        self.canvas._onArrowDragStarted(drag_pos)

        # 验证状态已设置
        self.assertEqual(self.canvas._dragged_arrow, source_arrow)
        self.assertEqual(self.canvas._original_connection, conn)
        self.assertTrue(self.canvas._original_is_bidirectional)
        self.assertIsNotNone(self.canvas._temp_new_connection)

        # 模拟拖拽结束到NodeC
        self.canvas._onArrowDragFinished(drag_pos, is_success=True)

        # 验证：原连接变为单向 A -> B
        # 新连接创建 B -> C
        self.assertEqual(len(self.canvas.connections), 2)

        # 检查连接：应该有 A->B 和 B->C
        a_to_b = [c for c in self.canvas.connections
                  if c.sourceNode == self.nodeA and c.targetNode == self.nodeB]
        b_to_c = [c for c in self.canvas.connections
                  if c.sourceNode == self.nodeB and c.targetNode == self.nodeC]
        self.assertEqual(len(a_to_b), 1)
        self.assertEqual(len(b_to_c), 1)
        self.assertFalse(a_to_b[0].isBidirectional)

    def testDragArrowToSameTargetNoChange(self) -> None:
        """测试拖拽箭头到相同目标不创建新连接"""
        # 创建 A -> B 连接
        conn = self.canvas.addConnection(self.nodeA, self.nodeB)
        self.assertEqual(len(self.canvas.connections), 1)

        # 获取目标箭头
        arrow = conn.targetArrow

        # 设置箭头拖拽状态（模拟拖拽开始）
        arrow._is_dragging = True
        drag_pos = self.nodeB.sceneBoundingRect().center()
        self.canvas._onArrowDragStarted(drag_pos)

        # 模拟拖拽结束到同一目标
        self.canvas._onArrowDragFinished(drag_pos, is_success=True)

        # 验证：连接数量不变，原连接保持不变
        self.assertEqual(len(self.canvas.connections), 1)
        self.assertEqual(self.canvas.connections[0], conn)
        self.assertEqual(conn.sourceNode, self.nodeA)
        self.assertEqual(conn.targetNode, self.nodeB)

    def testDragArrowToSameNodeFlashError(self) -> None:
        """测试拖拽箭头到源节点本身触发错误闪烁"""
        # 创建 A -> B 连接
        conn = self.canvas.addConnection(self.nodeA, self.nodeB)

        # 获取目标箭头
        arrow = conn.targetArrow

        # 设置箭头拖拽状态（模拟拖拽开始）
        arrow._is_dragging = True
        drag_pos = self.nodeA.sceneBoundingRect().center()
        self.canvas._onArrowDragStarted(drag_pos)

        # 模拟拖拽结束到源节点（自身）
        self.canvas._onArrowDragFinished(drag_pos, is_success=True)

        # 验证：连接数量不变，原连接保持不变
        self.assertEqual(len(self.canvas.connections), 1)

    def testDragArrowFailureFlashError(self) -> None:
        """测试拖拽失败触发错误闪烁"""
        # 创建 A -> B 连接
        conn = self.canvas.addConnection(self.nodeA, self.nodeB)

        # 获取目标箭头
        arrow = conn.targetArrow

        # 设置箭头拖拽状态（模拟拖拽开始）
        arrow._is_dragging = True
        drag_pos = QPointF(1000, 1000)  # 远离所有节点的位置
        self.canvas._onArrowDragStarted(drag_pos)

        # 模拟拖拽失败
        self.canvas._onArrowDragFinished(drag_pos, is_success=False)

        # 验证状态已重置
        self.assertIsNone(self.canvas._dragged_arrow)
        self.assertIsNone(self.canvas._original_connection)

    def testBidirectionalToUnidirectionalConversion(self) -> None:
        """测试双向连接拖拽后转换为单向连接"""
        # 创建 A <-> B 的双向连接
        conn = self.canvas.addConnection(self.nodeA, self.nodeB, is_bidirectional=True)
        self.assertTrue(conn.isBidirectional)
        self.assertEqual(len(self.canvas.connections), 1)

        # 获取目标箭头（A->B）
        target_arrow = conn.targetArrow

        # 设置箭头拖拽状态（模拟拖拽开始）
        target_arrow._is_dragging = True
        drag_pos = self.nodeC.sceneBoundingRect().center()
        self.canvas._onArrowDragStarted(drag_pos)

        # 验证状态已设置
        self.assertEqual(self.canvas._dragged_arrow, target_arrow)
        self.assertTrue(self.canvas._original_is_bidirectional)

        # 模拟拖拽结束
        self.canvas._onArrowDragFinished(drag_pos, is_success=True)

        # 验证：原连接变为 B -> A（单向）
        # 新连接 A -> C 创建
        self.assertEqual(len(self.canvas.connections), 2)

        # 找到 B -> A 的连接
        b_to_a = [c for c in self.canvas.connections
                  if c.sourceNode == self.nodeB and c.targetNode == self.nodeA]
        self.assertEqual(len(b_to_a), 1)
        self.assertFalse(b_to_a[0].isBidirectional)

        # 找到 A -> C 的连接
        a_to_c = [c for c in self.canvas.connections
                  if c.sourceNode == self.nodeA and c.targetNode == self.nodeC]
        self.assertEqual(len(a_to_c), 1)

    def testDuplicateConnectionWithCheckPartnersFalse(self) -> None:
        """测试已存在连接时addConnection返回已存在连接"""
        # 创建 A -> B 连接
        conn1 = self.canvas.addConnection(self.nodeA, self.nodeB)
        self.assertIsNotNone(conn1)

        # 尝试再次创建 A -> B，即使 check_partners=False 也应该返回已存在的连接
        conn2 = self.canvas.addConnection(self.nodeA, self.nodeB, check_partners=False)
        self.assertEqual(conn1, conn2)

    def testDragArrowToExistingConnectionArrow(self) -> None:
        """测试拖拽箭头到已存在连接的箭头上（不删除原连接）"""
        # 创建 A -> B 和 A -> C 两个连接
        conn_ab = self.canvas.addConnection(self.nodeA, self.nodeB)
        conn_ac = self.canvas.addConnection(self.nodeA, self.nodeC)
        self.assertEqual(len(self.canvas.connections), 2)
        self.assertIn(conn_ab, self.canvas.connections)
        self.assertIn(conn_ac, self.canvas.connections)

        # 获取 A->B 的目标箭头
        arrow_ab = conn_ab.targetArrow

        # 拖拽 A->B 的箭头到 C 节点
        arrow_ab._is_dragging = True
        drag_pos = self.nodeC.sceneBoundingRect().center()
        self.canvas._onArrowDragStarted(drag_pos)

        # 验证临时连接线已创建
        self.assertIsNotNone(self.canvas._temp_new_connection)

        # 模拟拖拽结束到C节点（A->C已存在）
        self.canvas._onArrowDragFinished(drag_pos, is_success=True)

        # 验证：两个连接都应该仍然存在
        self.assertEqual(len(self.canvas.connections), 2)
        self.assertIn(conn_ab, self.canvas.connections)
        self.assertIn(conn_ac, self.canvas.connections)

        # 验证 A->B 连接没有被删除
        self.assertEqual(conn_ab.sourceNode, self.nodeA)
        self.assertEqual(conn_ab.targetNode, self.nodeB)

    def testBidirectionalSourceArrowHasCallbacks(self) -> None:
        """测试双向连接的 source_arrow 有拖拽回调"""
        # 创建 A -> B 连接
        conn = self.canvas.addConnection(self.nodeA, self.nodeB)

        # 创建 B -> A 连接，使 A<->B 成为双向连接
        # 注意：addConnection 会返回已存在的连接（现在变为双向）
        conn2 = self.canvas.addConnection(self.nodeB, self.nodeA)

        # 验证是同一个连接且已变为双向
        self.assertEqual(conn, conn2)
        self.assertTrue(conn.isBidirectional)

        # 获取 source_arrow（从 B 指向 A 的箭头）
        source_arrow = conn.sourceArrow
        self.assertIsNotNone(source_arrow)

        # 验证 source_arrow 有拖拽回调
        self.assertIsNotNone(source_arrow._drag_started_callback)
        self.assertIsNotNone(source_arrow._drag_moved_callback)
        self.assertIsNotNone(source_arrow._drag_finished_callback)

    def testDragBidirectionalSourceArrow(self) -> None:
        """测试拖拽双向连接的 source_arrow（从 B 指向 A 的箭头）到 C"""
        # 创建双向连接 A<->B
        conn = self.canvas.addConnection(self.nodeA, self.nodeB, is_bidirectional=True)
        self.assertTrue(conn.isBidirectional)
        self.assertEqual(len(self.canvas.connections), 1)

        # 获取 source_arrow（从 B 指向 A 的箭头）
        source_arrow = conn.sourceArrow
        self.assertIsNotNone(source_arrow)
        self.assertTrue(source_arrow.isSourceArrow)

        # 验证回调已设置
        self.assertIsNotNone(source_arrow._drag_started_callback)

        # 拖拽 source_arrow 到 C
        source_arrow._is_dragging = True
        drag_pos = self.nodeC.sceneBoundingRect().center()
        self.canvas._onArrowDragStarted(drag_pos)

        # 验证临时连接线已创建
        self.assertIsNotNone(self.canvas._temp_new_connection)
        self.assertEqual(self.canvas._dragged_arrow, source_arrow)

        # 模拟拖拽结束到C节点
        self.canvas._onArrowDragFinished(drag_pos, is_success=True)

        # 验证：应该有两个连接：A->B 和 B->C
        # 原双向连接 A<->B 变为单向 A->B，新连接 B->C 创建
        self.assertEqual(len(self.canvas.connections), 2)

        # 验证 B->C 连接已创建（source_arrow 起点是 B）
        b_to_c = [c for c in self.canvas.connections
                  if c.sourceNode == self.nodeB and c.targetNode == self.nodeC]
        self.assertEqual(len(b_to_c), 1)


class TestConnectionTypes(unittest.TestCase):
    """测试不同连接类型"""

    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)

    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.source_node = NodeItem("Source", QPointF(0, 0))
        self.target_node = NodeItem("Target", QPointF(200, 0))
        self.scene.addItem(self.source_node)
        self.scene.addItem(self.target_node)

    def tearDown(self) -> None:
        """清理每个测试"""
        self.scene.clear()

    def testBezierConnection(self) -> None:
        """测试贝塞尔曲线连接"""
        connection = ConnectionItem(
            self.source_node, self.target_node,
            connection_type=ConnectionType.BEZIER
        )
        self.scene.addItem(connection)
        self.scene.addItem(connection.targetArrow)
        
        self.assertEqual(connection.connectionType, ConnectionType.BEZIER)
        
        connection.removeArrows()
        self.scene.removeItem(connection)
    
    def testStraightConnection(self) -> None:
        """测试直线连接"""
        connection = ConnectionItem(
            self.source_node, self.target_node,
            connection_type=ConnectionType.STRAIGHT
        )
        self.scene.addItem(connection)
        self.scene.addItem(connection.targetArrow)
        
        self.assertEqual(connection.connectionType, ConnectionType.STRAIGHT)
        
        connection.removeArrows()
        self.scene.removeItem(connection)


class TestDecorator(unittest.TestCase):
    """测试装饰器节点边框颜色"""

    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)

    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.node = NodeItem("TestNode", QPointF(100, 100))
        self.scene.addItem(self.node)

    def tearDown(self) -> None:
        """清理每个测试"""
        self.scene.clear()

    def testDecoratorProperty(self) -> None:
        """测试装饰器属性"""
        # 初始状态应该没有装饰器
        self.assertIsNone(self.node.decorator)

        # 设置 recursive 装饰器
        self.node.decorator = "recursive"
        self.assertEqual(self.node.decorator, "recursive")

        # 设置 behavior 装饰器
        self.node.decorator = "behavior"
        self.assertEqual(self.node.decorator, "behavior")

        # 清除装饰器
        self.node.decorator = None
        self.assertIsNone(self.node.decorator)

    def testRecursiveDecoratorColor(self) -> None:
        """测试 recursive 装饰器返回紫罗兰色"""
        self.node.decorator = "recursive"
        color = self.node._getDecoratorStrokeColor()

        self.assertIsNotNone(color)
        # 紫罗兰色: RGB(238, 130, 238)
        self.assertEqual(color.red(), 238)
        self.assertEqual(color.green(), 130)
        self.assertEqual(color.blue(), 238)

    def testBehaviorDecoratorColor(self) -> None:
        """测试 behavior 装饰器返回皇家蓝色"""
        self.node.decorator = "behavior"
        color = self.node._getDecoratorStrokeColor()

        self.assertIsNotNone(color)
        # 皇家蓝色: RGB(65, 105, 225)
        self.assertEqual(color.red(), 65)
        self.assertEqual(color.green(), 105)
        self.assertEqual(color.blue(), 225)

    def testSequenceDecoratorColor(self) -> None:
        """测试 sequence 装饰器返回皇家蓝色"""
        self.node.decorator = "sequence"
        color = self.node._getDecoratorStrokeColor()
        self.assertIsNotNone(color)

    def testSelectorDecoratorColor(self) -> None:
        """测试 selector 装饰器返回皇家蓝色"""
        self.node.decorator = "selector"
        color = self.node._getDecoratorStrokeColor()
        self.assertIsNotNone(color)

    def testParallelDecoratorColor(self) -> None:
        """测试 parallel 装饰器返回皇家蓝色"""
        self.node.decorator = "parallel"
        color = self.node._getDecoratorStrokeColor()
        self.assertIsNotNone(color)

    def testNoDecoratorReturnsNone(self) -> None:
        """测试无装饰器时返回 None"""
        color = self.node._getDecoratorStrokeColor()
        self.assertIsNone(color)

    def testUnknownDecoratorReturnsNone(self) -> None:
        """测试未知装饰器返回 None"""
        self.node.decorator = "unknown"
        color = self.node._getDecoratorStrokeColor()
        self.assertIsNone(color)

    def testDecoratorCaseInsensitive(self) -> None:
        """测试装饰器类型不区分大小写"""
        # 大写的 RECURSIVE
        self.node.decorator = "RECURSIVE"
        color = self.node._getDecoratorStrokeColor()
        self.assertIsNotNone(color)

        # 混合大小写的 Behavior
        self.node.decorator = "Behavior"
        color = self.node._getDecoratorStrokeColor()
        self.assertIsNotNone(color)


def RunAllTests() -> None:
    """运行所有测试"""
    # 创建测试套件
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # 添加所有测试类
    suite.addTests(loader.loadTestsFromTestCase(TestEnums))
    suite.addTests(loader.loadTestsFromTestCase(TestStyles))
    suite.addTests(loader.loadTestsFromTestCase(TestNodeItem))
    suite.addTests(loader.loadTestsFromTestCase(TestConnectionItem))
    suite.addTests(loader.loadTestsFromTestCase(TestArrowItem))
    suite.addTests(loader.loadTestsFromTestCase(TestSelectionRect))
    suite.addTests(loader.loadTestsFromTestCase(TestNodeCanvas))
    suite.addTests(loader.loadTestsFromTestCase(TestQNodeEditor))
    suite.addTests(loader.loadTestsFromTestCase(TestNodeShapes))
    suite.addTests(loader.loadTestsFromTestCase(TestArrowDragFunctionality))
    suite.addTests(loader.loadTestsFromTestCase(TestConnectionTypes))
    suite.addTests(loader.loadTestsFromTestCase(TestDecorator))

    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # 返回测试结果
    return result.wasSuccessful()


if __name__ == "__main__":
    success = RunAllTests()
    sys.exit(0 if success else 1)
