"""
代码工具模块 - 用于检查 graph JSON 的合理性
"""

import os
from code_checker.checker import LocalPackageChecker
from .layout_utils import OverlapDetector
from .layout_utils import check_viewport


import json as json_mod
import re
import ast
from typing import Dict, Callable, Tuple, List, Set, Any


# ============================================================================
# 关键子函数（必须全部通过）
# ============================================================================

def check_structure(canvas, json, code) -> Tuple[bool, str]:
    """
    检查 JSON 基本结构是否有效

    Args:
        canvas: 画布对象（未使用）
        json: JSON 数据字典
        code: 代码内容（未使用）

    Returns:
        (是否通过, 失败描述)
    """
    if not isinstance(json, dict):
        return False, "JSON 必须是字典类型"

    if "nodes" not in json:
        return False, "缺少 'nodes' 字段"

    if not isinstance(json["nodes"], list):
        return False, "'nodes' 必须是列表类型"

    return True, ""


def check_node_names(canvas, json, code) -> Tuple[bool, str]:
    """
    检查节点名称的合理性

    检查项：
    1. 不能有空白名称节点
    2. 不能有重复节点名称
    3. 不能有系统内部函数名（StageMachineLogicMeta.IGNORES）
    4. 节点不能以 '_', 数字, 特殊符号开头（可以是中文）

    Args:
        canvas: 画布对象（未使用）
        json: JSON 数据字典
        code: 代码内容（未使用）

    Returns:
        (是否通过, 失败描述)
    """
    # 系统内部函数列表（来自 StageMachineLogicMeta.IGNORES）
    INTERNAL_FUNCTIONS: Set[str] = {
        'ref', 'refLast', 'refNext', 'refAdjacent', 'refEnd', 'refHead', 'link', 'transform', 'creeps',
        "listenFor", "cancelListen", "pushEvent", "schedule", "cancelSchedule", "handleStage",
        'onStart', 'onStop', 'onStep', 'onChanged', 'onKilled', 'onDraw', 'onLoading',
        "productQueue", "showQueue", "jumpQueue", "accelerate"
    }

    nodes = json.get("nodes", [])
    if not nodes:
        return True, ""  # 没有节点时跳过

    names: List[str] = []
    for i, node in enumerate(nodes):
        if not isinstance(node, dict):
            return False, f"第 {i+1} 个节点不是字典类型"

        name = node.get("name", "")

        # 检查 1：不能有空白名称
        if not name or not str(name).strip():
            return False, f"第 {i+1} 个节点名称为空"

        name = str(name).strip()

        # 检查 4：不能以 '_', 数字, 特殊符号开头（中文开头是允许的）
        # 检查首字符
        first_char = name[0]
        # 允许的字符：字母（含中文）、非下划线的特殊字符不算
        # 不允许：下划线、数字
        if first_char == '_':
            return False, f"节点 '{name}' 以下划线开头，这不会被认定为状态节点"
        if first_char.isdigit():
            return False, f"节点 '{name}' 以数字开头，这不会被认定为状态节点"
        # 检查是否为特殊符号（非字母、非中文、非下划线）
        if not (first_char.isalpha() or '\u4e00' <= first_char <= '\u9fff'):
            return False, f"节点 '{name}' 以特殊符号开头，这不会被认定为状态节点"

        names.append(name)

    # 检查 2：不能有重复名称
    name_counts: Dict[str, int] = {}
    for name in names:
        name_counts[name] = name_counts.get(name, 0) + 1

    duplicates = [name for name, count in name_counts.items() if count > 1]
    if duplicates:
        return False, f"存在重复节点名称: {', '.join(duplicates)}"

    # 检查 3：不能使用系统内部函数名
    internal_used = []
    for name in names:
        # 检查是否与内部函数名完全匹配（大小写敏感）
        if name in INTERNAL_FUNCTIONS:
            internal_used.append(name)

    if internal_used:
        return False, f"节点名称使用了系统内部保留字: {', '.join(internal_used)}"

    return True, ""


def _get_checker_with_builtin():
    """
    创建配置好 builtin 包的 LocalPackageChecker

    Returns:
        LocalPackageChecker 实例，或 None 如果导入失败
    """
    try:

        # 获取 builtin 包的路径
        builtin_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'builtin')

        # 创建检查器，传入 builtin 包路径
        checker = LocalPackageChecker(package_path=builtin_path)
        return checker
    except Exception:
        return None


def check_syntax_errors(canvas, json, code) -> Tuple[bool, str]:
    """
    检查节点代码的语法错误（关键检查）

    使用 code_checker 模块对代码进行语法分析。

    Args:
        canvas: 画布对象（未使用）
        json: JSON 数据字典（未使用）
        code: 代码内容

    Returns:
        (是否通过, 失败描述)
    """
    # 如果没有提供代码，跳过此检查
    if not code or not str(code).strip():
        return True, ""

    try:

        checker = _get_checker_with_builtin()
        if checker is None:
            # 回退到默认检查器
            checker = LocalPackageChecker()

        all_syntax_errors = []

        # 检查代码
        issues = checker.check_code(str(code), path="<generated>")
        for issue in issues:
            if issue.severity == 'syntax':
                all_syntax_errors.append(f"第{issue.line}行: {issue.message}")

        if all_syntax_errors:
            # 最多显示5个错误
            error_preview = all_syntax_errors[:5]
            more_count = len(all_syntax_errors) - 5
            result = "发现语法错误:\n" + "\n".join(error_preview)
            if more_count > 0:
                result += f"\n... 还有 {more_count} 个错误"
            return False, result

        return True, ""

    except ImportError:
        # code_checker 不可用，跳过此检查
        return True, ""
    except Exception as e:
        return False, f"语法检查异常: {e}"


def check_type_inference(canvas, json, code) -> Tuple[bool, str]:
    """
    检查节点代码的类型推断问题（次要检查）

    使用 code_checker 模块对代码进行类型分析和属性检查。

    Args:
        canvas: 画布对象（未使用）
        json: JSON 数据字典（未使用）
        code: 代码内容

    Returns:
        (是否通过, 描述)
    """
    # 如果没有提供代码，跳过此检查
    if not code or not str(code).strip():
        return True, ""

    try:

        checker = _get_checker_with_builtin()
        if checker is None:
            # 回退到默认检查器
            checker = LocalPackageChecker()

        type_issues = []
        attribute_issues = []

        # 检查代码
        issues = checker.check_code(str(code), path="<generated>")

        # 收集类型和属性问题
        for issue in issues:
            if issue.severity == 'type':
                type_issues.append(f"第{issue.line}行: {issue.message}")
            elif issue.severity == 'attribute':
                attribute_issues.append(f"第{issue.line}行: {issue.message}")

        issues_desc = []
        if type_issues:
            preview = type_issues[:3]
            more = len(type_issues) - 3
            desc = "类型问题:\n" + "\n".join(preview)
            if more > 0:
                desc += f"\n... 还有 {more} 个"
            issues_desc.append(desc)

        if attribute_issues:
            preview = attribute_issues[:3]
            more = len(attribute_issues) - 3
            desc = "属性访问问题:\n" + "\n".join(preview)
            if more > 0:
                desc += f"\n... 还有 {more} 个"
            issues_desc.append(desc)

        if issues_desc:
            return False, "\n\n".join(issues_desc)

        return True, ""

    except ImportError:
        # code_checker 不可用，跳过此检查
        return True, ""
    except Exception as e:
        return False, f"类型检查异常: {e}"


def check_connections(canvas, json, code) -> Tuple[bool, str]:
    """
    检查连接的合理性

    Args:
        canvas: 画布对象（未使用）
        json: JSON 数据字典
        code: 代码内容（未使用）

    Returns:
        (是否通过, 失败描述)
    """
    nodes = json.get("nodes", [])
    connections = json.get("connections", [])

    if not connections:
        return True, ""  # 没有连接时跳过

    # 获取有效的节点 id 集合
    node_ids: Set[int] = set()
    for node in nodes:
        if isinstance(node, dict) and "id" in node:
            node_ids.add(node["id"])

    for i, conn in enumerate(connections):
        if not isinstance(conn, dict):
            return False, f"第 {i+1} 个连接不是字典类型"

        source_id = conn.get("source_id")
        target_id = conn.get("target_id")

        if source_id is None:
            return False, f"第 {i+1} 个连接缺少 'source_id'"
        if target_id is None:
            return False, f"第 {i+1} 个连接缺少 'target_id'"

        # 检查连接的节点是否存在（id 在 nodes 中）
        # 注意：导入时 id 会被重新生成，所以这里宽松检查
        # 如果要严格检查，需要确保 id 在 node_ids 中

    return True, ""


# ============================================================================
# 次要子函数（用于区分"基本合理"和"完全合理"）
# ============================================================================

def check_has_start_node(canvas, json, code) -> Tuple[bool, str]:
    """
    检查是否设置了起点节点

    Args:
        canvas: 画布对象（未使用）
        json: JSON 数据字典
        code: 代码内容（未使用）

    Returns:
        (是否通过, 描述)
    """
    start_node_id = json.get("start_node_id")

    if start_node_id is None:
        return False, "未设置起点节点"

    # 检查起点节点是否存在
    nodes = json.get("nodes", [])
    node_ids = {node.get("id") for node in nodes if isinstance(node, dict)}

    if start_node_id not in node_ids:
        return False, "起点节点 ID 不存在于节点列表中"

    return True, ""


def check_has_code_content(canvas, json, code) -> Tuple[bool, str]:
    """
    检查节点是否有代码内容

    Args:
        canvas: 画布对象（未使用）
        json: JSON 数据字典
        code: 代码内容（未使用）

    Returns:
        (是否通过, 描述)
    """
    nodes = json.get("nodes", [])

    has_code = False
    for node in nodes:
        if isinstance(node, dict):
            connection_texts = node.get("connection_texts", {})
            if connection_texts:
                # 检查是否有非空的代码内容（排除 __doc__）
                for key, value in connection_texts.items():
                    if key not in ["__doc__"] and value and str(value).strip():
                        has_code = True
                        break
        if has_code:
            break

    if not has_code:
        return False, "所有节点都没有代码内容（只有空节点）"

    return True, ""


def check_node_count(canvas, json, code) -> Tuple[bool, str]:
    """
    检查节点数量是否合理

    Args:
        canvas: 画布对象（未使用）
        json: JSON 数据字典
        code: 代码内容（未使用）

    Returns:
        (是否通过, 描述)
    """
    nodes = json.get("nodes", [])
    count = len(nodes)

    if count == 0:
        return False, "图中没有节点"

    if count > 100:
        return False, f"节点数量过多 ({count} 个)，建议拆分为多个图"

    return True, ""


def check_root_validity(canvas, json, code) -> Tuple[bool, str]:
    """
    检查 ROOT 配置的合理性

    Args:
        canvas: 画布对象（未使用）
        json: JSON 数据字典
        code: 代码内容（未使用）

    Returns:
        (是否通过, 描述)
    """
    roots = json.get("roots", [])

    if not roots:
        return False, "没有配置 ROOT"

    if len(roots) > 1:
        return False, "存在多个 ROOT（应该只有一个）"

    root = roots[0]
    if isinstance(root, dict):
        if not root.get("name"):
            return False, "ROOT 名称为空"

    return True, ""


def check_overlaps_canvas(canvas, json, code) -> Tuple[bool, str]:
    """
    检查画布中是否存在重叠（需要 canvas 对象）

    Args:
        canvas: NodeCanvas 实例
        json: JSON 数据字典（未使用）
        code: 代码内容（未使用）

    Returns:
        (是否通过, 描述)
    """
    try:
        detector = OverlapDetector(canvas)
        overlaps = detector.find_all_overlaps()

        if overlaps:
            summary = detector.get_overlap_summary()
            details = []
            if summary.get("node_node", 0) > 0:
                details.append(f"节点-节点: {summary['node_node']}处")
            if summary.get("node_connection", 0) > 0:
                details.append(f"节点-连线: {summary['node_connection']}处")
            if summary.get("connection_connection", 0) > 0:
                details.append(f"连线-连线: {summary['connection_connection']}处")
            if summary.get("node_root", 0) > 0:
                details.append(f"节点-ROOT: {summary['node_root']}处")
            if summary.get("root_root", 0) > 0:
                details.append(f"ROOT-ROOT: {summary['root_root']}处")
            if summary.get("connection_root", 0) > 0:
                details.append(f"连线-ROOT: {summary['connection_root']}处")

            return False, f"存在 {len(overlaps)} 处重叠 ({', '.join(details)})，建议执行自动布局"

        return True, ""
    except Exception as e:
        return False, f"重叠检查异常: {e}"


def check_viewport_canvas(canvas, json, code) -> Tuple[bool, str]:
    """
    检查视口是否合适（需要 canvas 对象）

    Args:
        canvas: NodeCanvas 实例
        json: JSON 数据字典（未使用）
        code: 代码内容（未使用）

    Returns:
        (是否通过, 描述)
    """
    try:
        result = check_viewport(canvas)

        if not result.get("ok", True):
            issues = []
            if not result.get("center_ok", True):
                offset = result.get("center_offset", 0)
                issues.append(f"中心偏差过大 ({offset:.1f}像素)")
            if not result.get("scale_ok", True):
                scale_offset = result.get("scale_offset", 0)
                issues.append(f"缩放比例不合适 ({scale_offset*100:+.1f}%)")

            return False, f"视口设置不理想: {', '.join(issues)}，建议使用'自动适应视口'功能"

        return True, ""
    except Exception as e:
        return False, f"视口检查异常: {e}"


# ============================================================================
# 函数字典定义
# ============================================================================

# 关键子函数字典（必须全部通过，否则为"不合理"）
CRITICAL_CHECKS: Dict[str, Callable[..., Tuple[bool, str]]] = {
    "结构检查": check_structure,
    "节点名称检查": check_node_names,
    "连接有效性检查": check_connections,
    "语法错误检查": check_syntax_errors,
}

# 次要子函数字典（用于区分"基本合理"和"完全合理"）
SECONDARY_CHECKS: Dict[str, Callable[..., Tuple[bool, str]]] = {
    "起点节点检查": check_has_start_node,
    "代码内容检查": check_has_code_content,
    "节点数量检查": check_node_count,
    "ROOT配置检查": check_root_validity,
    "类型推断检查": check_type_inference,
}

# 布局相关次要检查（需要 canvas 对象）
LAYOUT_CHECKS: Dict[str, Callable[..., Tuple[bool, str]]] = {
    "重叠检查": check_overlaps_canvas,
    "视口检查": check_viewport_canvas,
}


# ============================================================================
# 主接口函数
# ============================================================================

def check_graph_validity(canvas, json=None, code=None) -> dict:
    """
    主接口函数 - 检查给定 graph JSON 的合理性

    检查逻辑：
    1. 首先由内部各个关键子合理性取 AND，False 则必定为"不合理"
    2. True 则对次要子合理性取 AND，False 则为"基本合理"
    3. 最后就"完全合理"

    Args:
        canvas: NodeCanvas 实例
        json: 可选，可以是 JSON 字符串或字典。如果为 None，则从 canvas 导出
        code: 可选，Python 代码内容。如果为 None，则使用 canvas._generate_python_code() 生成

    Returns:
        字典，必定包含以下键：
        - 合理性: str - "不合理" / "基本合理" / "完全合理"
        - 详情: dict - 各检查项的结果详情
        - 错误列表: List[str] - 失败的检查描述
        - 建议列表: List[str] - 改进建议列表

    Raises:
        ValueError: 如果 JSON 结构检查失败
    """
    # 如果 json 为 None，从 canvas 导出
    if json is None:
        if canvas is None:
            raise ValueError("canvas 和 json 不能同时为空")
        json = canvas.export()

    # 解析 JSON 字符串
    if isinstance(json, str):
        try:
            data = json_mod.loads(json)
        except json_mod.JSONDecodeError as e:
            raise ValueError(f"无效的 JSON 格式: {e}")
    else:
        data = json

    # 首先检查必须是字典
    if not isinstance(data, dict):
        raise ValueError("JSON 必须是字典类型")

    # 如果 code 为 None，使用 canvas 生成 Python 代码
    if code is None and canvas is not None:
        try:
            code = canvas._generate_python_code()
        except Exception:
            code = None

    # ========== 调试输出 ==========
    debug_file = os.path.join(os.path.dirname(__file__), 'debug_check_code.py')
    with open(debug_file, 'w', encoding='utf-8') as f:
        f.write("# ===== 调试：传入检查的 code =====\n")
        f.write("# code 类型: %s\n" % type(code))
        f.write("# code 长度: %s\n\n" % (len(code) if code else 0))
        if code:
            f.write(code)
        else:
            f.write("# code 为 None 或空\n")
    print("[调试] code 已保存到:", debug_file)
    # ========== 调试输出结束 ==========

    result = {
        "合理性": "",
        "详情": {},
        "错误列表": [],
        "建议列表": []
    }

    # 执行关键检查
    critical_passed = True
    for check_name, check_func in CRITICAL_CHECKS.items():
        try:
            passed, description = check_func(canvas, data, code)
            result["详情"][check_name] = {
                "通过": passed,
                "描述": description if description else "通过"
            }
            if not passed:
                critical_passed = False
                result["错误列表"].append(f"{check_name}: {description}")
        except Exception as e:
            critical_passed = False
            result["详情"][check_name] = {
                "通过": False,
                "描述": f"检查异常: {e}"
            }
            result["错误列表"].append(f"{check_name}: 检查异常 - {e}")

    # 关键检查未通过 -> 不合理
    if not critical_passed:
        result["合理性"] = "不合理"
        return result

    # 执行次要检查（基于 JSON）
    secondary_passed = True
    for check_name, check_func in SECONDARY_CHECKS.items():
        try:
            passed, description = check_func(canvas, data, code)
            result["详情"][check_name] = {
                "通过": passed,
                "描述": description if description else "通过"
            }
            if not passed:
                secondary_passed = False
                result["建议列表"].append(f"{check_name}: {description}")
        except Exception as e:
            secondary_passed = False
            result["详情"][check_name] = {
                "通过": False,
                "描述": f"检查异常: {e}"
            }
            result["建议列表"].append(f"{check_name}: 检查异常 - {e}")

    # 执行布局相关检查（需要 canvas 对象）
    if canvas is not None:
        for check_name, check_func in LAYOUT_CHECKS.items():
            try:
                passed, description = check_func(canvas, data, code)
                result["详情"][check_name] = {
                    "通过": passed,
                    "描述": description if description else "通过"
                }
                if not passed:
                    secondary_passed = False
                    result["建议列表"].append(f"{check_name}: {description}")
            except Exception as e:
                # 布局检查异常不影响整体结果，只记录
                result["详情"][check_name] = {
                    "通过": True,
                    "描述": f"检查跳过: {e}"
                }

    # 次要检查未通过 -> 基本合理
    if not secondary_passed:
        result["合理性"] = "基本合理"
    else:
        result["合理性"] = "完全合理"

    return result
