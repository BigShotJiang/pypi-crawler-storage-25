"""


节点编辑子窗口模块
实现节点的编辑功能，包括名称编辑、连接列表管理和文本编辑
"""

from .node_item import NodeItem
import re
import unicodedata
from PyQt6.QtWidgets import QMenu
from .node_canvas import NodeCanvas


from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLineEdit,
    QListWidget, QListWidgetItem, QTextEdit, QLabel, QFrame,
    QTabWidget, QPushButton, QScrollArea, QApplication, QToolButton
)
from PyQt6.QtCore import Qt, pyqtSignal, QMimeData, QSize, QPoint
from PyQt6.QtGui import QDrag, QMouseEvent, QPaintEvent, QPainter, QFont, QPalette, QColor
from typing import List, TYPE_CHECKING, Dict, Optional

# 导入 PythonEditor
import sys
sys.path.insert(0, 'C:/Users/22290/Desktop/node')
from pyedit import PythonEditor


class DraggableListWidget(QListWidget):
    """支持拖拽排序的列表控件（固定项永远固定在顶部和底部）"""

    # 固定项及其固定位置
    TOP_FIXED_ITEM = "📥进入节点"  # 永远在第一个
    BOTTOM_FIXED_ITEM = "📤离开节点"  # 永远在最后一个

    # 固定项ID映射（用于data角色）
    FIXED_ITEM_DATA_MAP = {
        TOP_FIXED_ITEM: "__begin__",
        BOTTOM_FIXED_ITEM: "__end__",
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDragDropMode(QListWidget.DragDropMode.InternalMove)
        self.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.setDragDropOverwriteMode(False)
        self.setSelectionMode(QListWidget.SelectionMode.SingleSelection)

        # 设置样式（适应浅色背景）
        self.setStyleSheet("""
            QListWidget {
                background-color: #ffffff;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 4px;
            }
            QListWidget::item {
                background-color: #e8e8e8;
                color: #333333;
                border-radius: 4px;
                padding: 8px 12px;
                margin: 2px 0px;
                font-size: 13px;
            }
            QListWidget::item:selected {
                background-color: #5a9bd5;
                color: #ffffff;
                border: 1px solid #4a8bc5;
            }
            QListWidget::item:hover {
                background-color: #d0d0d0;
            }
            QListWidget::item:selected:hover {
                background-color: #5a9bd5;
            }
            QListWidget::item:disabled {
                background-color: #f5f5f5;
                color: #999999;
            }
        """)

    def is_fixed_item(self, item):
        """检查是否是固定项（进入或离开）"""
        return item.text() in {self.TOP_FIXED_ITEM, self.BOTTOM_FIXED_ITEM}

    def startDrag(self, supportedActions):
        """开始拖拽"""
        item = self.currentItem()
        if item is None:
            return

        # 固定项不可拖拽
        if self.is_fixed_item(item):
            return

        # 创建拖拽对象
        drag = QDrag(self)
        mime_data = QMimeData()

        # 存储当前项的索引
        row = self.row(item)
        mime_data.setText(str(row))
        drag.setMimeData(mime_data)

        # 执行拖拽
        drag.exec(supportedActions)

    def dragEnterEvent(self, event):
        """拖拽进入事件"""
        if event.source() == self:
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        """拖拽移动事件 - 只能在进入和离开之间拖拽"""
        if event.source() != self:
            event.ignore()
            return

        # 获取源项
        source_row = int(event.mimeData().text())
        source_item = self.item(source_row)

        # 固定项不可拖拽
        if source_item and self.is_fixed_item(source_item):
            event.ignore()
            return

        # 获取目标位置
        target_item = self.itemAt(event.position().toPoint())

        # 找到进入和离开的索引
        top_idx = self._get_top_fixed_index()
        bottom_idx = self._get_bottom_fixed_index()

        if target_item is None:
            # 拖到了列表末尾 - 检查是否超过离开节点
            if bottom_idx >= 0:
                # 不能超过离开节点
                event.ignore()
                return
        else:
            target_row = self.row(target_item)

            # 不能拖到进入节点之前
            if top_idx >= 0 and target_row <= top_idx:
                event.ignore()
                return

            # 不能拖到离开节点之后
            if bottom_idx >= 0 and target_row >= bottom_idx:
                event.ignore()
                return

        event.accept()

    def _get_top_fixed_index(self):
        """获取顶部固定项（进入节点）的索引"""
        for i in range(self.count()):
            if self.item(i).text() == self.TOP_FIXED_ITEM:
                return i
        return -1

    def _get_bottom_fixed_index(self):
        """获取底部固定项（离开节点）的索引"""
        for i in range(self.count()):
            if self.item(i).text() == self.BOTTOM_FIXED_ITEM:
                return i
        return -1

    def dropEvent(self, event):
        """放置事件 - 实现重新排序（只能在进入和离开之间）"""
        if event.source() != self:
            event.ignore()
            return

        # 获取源索引
        source_row = int(event.mimeData().text())

        # 获取源项
        source_item = self.item(source_row)

        # 固定项不可拖拽
        if source_item and self.is_fixed_item(source_item):
            event.ignore()
            return

        # 找到进入和离开的索引
        top_idx = self._get_top_fixed_index()
        bottom_idx = self._get_bottom_fixed_index()

        # 获取目标位置（放置在哪一项之前）
        target_item = self.itemAt(event.position().toPoint())

        if target_item is None:
            # 拖到了列表末尾 - 限制在离开节点之前
            if bottom_idx >= 0:
                target_row = bottom_idx
            else:
                target_row = self.count()
        else:
            target_row = self.row(target_item)

            # 不能放到进入节点或之前
            if top_idx >= 0 and target_row <= top_idx:
                event.ignore()
                return

            # 不能放到离开节点或之后
            if bottom_idx >= 0 and target_row >= bottom_idx:
                event.ignore()
                return

        # 如果源和目标相同，不做任何操作
        if source_row == target_row or source_row == target_row - 1:
            event.ignore()
            return

        # 获取源项的数据
        source_item = self.takeItem(source_row)
        source_data = source_item.data(Qt.ItemDataRole.UserRole)
        source_text = source_item.text()
        source_flags = source_item.flags()

        # 调整目标索引（如果源在目标之前）
        if source_row < target_row:
            target_row -= 1

        # 确保目标位置在有效范围内
        if top_idx >= 0:
            target_row = max(target_row, top_idx + 1)
        if bottom_idx >= 0:
            target_row = min(target_row, bottom_idx)

        # 创建新项并插入
        new_item = QListWidgetItem(source_text)
        new_item.setData(Qt.ItemDataRole.UserRole, source_data)
        new_item.setFlags(source_flags)

        self.insertItem(target_row, new_item)
        self.setCurrentItem(new_item)

        event.accept()


class EditorTab(QWidget):
    """编辑器标签页 - 使用 PythonEditor 提供智能代码编辑"""

    text_modified = pyqtSignal(str, bool)  # tab_id, is_modified

    def __init__(self, tab_id: str, title: str, node_name: str = "", parent=None):
        super().__init__(parent)

        self.tab_id = tab_id
        self.title = title
        self._modified = False  # 是否被编辑过
        self._node_name = node_name

        # 创建布局
        layout = QVBoxLayout(self)
        layout.setContentsMargins(2, 2, 2, 2)  # margin全为2
        layout.setSpacing(0)

        # 创建 PythonEditor
        self.editor = PythonEditor()

        # 设置 CA 和 CB
        self._setup_context_code()

        layout.addWidget(self.editor)

        # 连接文本修改信号
        self.editor.text_modified.connect(self._on_text_changed)

        # 修改回调函数（替代信号）
        self._modified_callback = None

        # 设置背景色
        self.setStyleSheet("""
            EditorTab {
                background-color: #ffffff;
            }
        """)

    def _setup_context_code(self, begin_code: str = "", root_class_code: str = ""):
        """设置 PythonEditor 的上下文代码 (CA 和 CB)

        Args:
            begin_code: begin 标签页的代码，用于在函数体内提供变量补全
            root_class_code: ROOT 的类头部代码（包含导入、类定义、NAME、RECIPE、类变量等）
        """
        safe_name = self._sanitize_name(self._node_name)

        # 处理 begin 代码：添加缩进使其成为函数体的一部分
        indented_begin = ""
        if begin_code:
            # 为 begin 代码添加8空格缩进
            lines = begin_code.strip().split('\n')
            indented_begin = '\n'.join('        ' + line for line in lines)
            indented_begin += '\n'

        # 构建 CA 代码
        # root_class_code 现在包含完整的类头部（导入、类定义、NAME、RECIPE、类变量等）
        # 我们只需要在后面添加方法存根
        if root_class_code:
            # 使用传入的类头部代码
            CA = root_class_code.rstrip() + '\n'
        else:
            # 默认类头部（当没有 ROOT 时）
            CA = f"""from builtin import *

class MyClass(CreepLogic):
    NAME = 'MyClass'

"""

        # 添加方法存根
        CA += f"""    def {safe_name}(self, c: Creep, k: GlobalKnowledge, *refs):
{indented_begin}<__begin__>"""

        # CB - 不需要单独的 CB，因为函数定义已经在 CA 中
        CB = ""

        # 设置上下文代码
        # prefix 使用8空格（4空格类方法缩进 + 4空格函数体缩进）
        self.editor.set_context_code(
            code_a=CA,
            code_b=CB,
            prefix="        "  # 8空格缩进（类方法体内）
        )

    def update_begin_context(self, begin_code: str, root_class_code: str = ""):
        """更新 begin 代码上下文，用于在其他标签页中补全 begin 定义的变量"""
        self._setup_context_code(begin_code, root_class_code)

    def _sanitize_name(self, name: str) -> str:
        """将节点名称转换为有效的Python标识符"""

        if not name:
            return 'node'

        # 检查字符是否是合法的标识符字符
        def is_valid_char(c: str, is_first: bool) -> bool:
            if c == '_':
                return True
            if is_first:
                return unicodedata.category(c).startswith('L')
            else:
                cat = unicodedata.category(c)
                return cat.startswith('L') or cat.startswith('N')

        # 构建安全名称
        safe_chars = []
        for i, c in enumerate(name):
            if is_valid_char(c, i == 0):
                safe_chars.append(c)
            else:
                safe_chars.append('_')

        safe = ''.join(safe_chars)

        # 如果第一个字符是数字，添加下划线前缀
        if safe and safe[0].isdigit():
            safe = '_' + safe

        # 确保不为空
        if not safe:
            safe = 'node'

        return safe

    def get_text(self) -> str:
        """获取文本内容（CC - 可见代码）"""
        return self.editor.get_code()

    def set_text(self, text: str):
        """设置文本内容（CC - 可见代码）"""
        # [修复] 阻塞信号防止初始化时误标记为修改
        self.editor.blockSignals(True)
        self.editor.set_code(text)
        self.editor.blockSignals(False)

    def update_placeholder(self, new_title: str):
        """更新 placeholder 文本 - PythonEditor 不直接支持，可忽略"""
        pass

    def _on_text_changed(self):
        """文本改变时触发 - 不受撤销影响"""
        if not self._modified:
            self._modified = True
            if self._modified_callback:
                self._modified_callback(self.tab_id, True)

    def is_modified(self) -> bool:
        """是否被编辑过"""
        return self._modified

    def set_modified_callback(self, callback):
        """设置修改回调函数 callback(tab_id, is_modified)"""
        self._modified_callback = callback

    def mark_as_saved(self):
        """标记为已保存"""
        self._modified = False
        if self._modified_callback:
            self._modified_callback(self.tab_id, False)


class VSStyleTabBar(QWidget):
    """VS Code风格的标签栏 - 支持拖拽重新排序和右键菜单"""

    tab_clicked = pyqtSignal(str)  # 点击标签
    tab_closed = pyqtSignal(str)  # 关闭标签
    tab_reordered = pyqtSignal(str, int)  # 标签重新排序（tab_id, new_index）
    context_menu_requested = pyqtSignal(str, QPoint)  # 右键菜单请求 (tab_id, position)

    def __init__(self, parent=None, doc_tab_id: str = "__doc__"):
        super().__init__(parent)

        self.tabs: Dict[str, QWidget] = {}
        self.tab_order: List[str] = []
        self.active_tab: Optional[str] = None
        self._drag_tab_id: Optional[str] = None
        self._doc_tab_id = doc_tab_id  # 文档标签ID
        self._close_buttons: Dict[str, QPushButton] = {}  # 存储关闭按钮

        # 设置固定高度
        self.setFixedHeight(32)
        self.setStyleSheet("""
            VSStyleTabBar {
                background-color: #f0f0f0;
                border-bottom: 1px solid #cccccc;
            }
        """)

        # 主布局
        self._layout = QHBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(0)
        self._layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

    def add_tab(self, tab_id: str, title: str) -> bool:
        """添加标签页，如果已存在返回False"""
        if tab_id in self.tabs:
            return False

        tab_widget = self._create_tab_widget(tab_id, title)
        self.tabs[tab_id] = tab_widget
        self.tab_order.append(tab_id)

        # 插入到布局中
        index = len(self.tab_order) - 1
        self._layout.insertWidget(index, tab_widget)

        # 更新关闭按钮显示状态（在标签添加到字典后调用）
        self._update_close_buttons()

        # 默认激活新标签
        if self.active_tab is None:
            self.set_active_tab(tab_id)

        return True

    def _create_tab_widget(self, tab_id: str, title: str) -> QWidget:
        """创建单个标签页控件"""
        tab = QWidget()
        tab.setFixedHeight(31)
        tab.setCursor(Qt.CursorShape.PointingHandCursor)

        # 根据是否激活设置样式
        is_active = (self.active_tab == tab_id)
        tab.setStyleSheet(self._get_tab_style(is_active))

        layout = QHBoxLayout(tab)
        layout.setContentsMargins(10, 0, 5, 0)
        layout.setSpacing(5)

        # 标题标签
        label = QLabel(title)
        label.setStyleSheet("background: transparent; border: none;")
        font = QFont()
        font.setPointSize(9)
        label.setFont(font)
        layout.addWidget(label)

        # 关闭按钮（初始状态默认为隐藏，等_update_close_buttons来设置正确状态）
        close_btn = QPushButton("×")
        close_btn.setFixedSize(16, 16)
        close_btn.setVisible(False)  # 默认隐藏，由_update_close_buttons控制
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                color: #666666;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #e81123;
                color: white;
                border-radius: 3px;
            }
        """)
        close_btn.clicked.connect(lambda: self._on_close_clicked(tab_id))
        layout.addWidget(close_btn)
        self._close_buttons[tab_id] = close_btn

        # 存储tab_id用于点击处理
        tab._tab_id = tab_id

        # 鼠标事件处理
        tab.mousePressEvent = lambda e, tid=tab_id: self._on_tab_clicked(tid, e)
        tab.mouseMoveEvent = lambda e, tid=tab_id: self._on_tab_drag(tid, e)

        # 右键菜单
        tab.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        tab.customContextMenuRequested.connect(lambda pos, tid=tab_id: self._on_context_menu(tid, pos))

        return tab

    def _update_close_buttons(self):
        """更新所有关闭按钮的显示状态
        - 文档标签：只有存在其他标签时才显示关闭按钮
        - 其他标签：总是显示关闭按钮
        """
        has_other_tabs = any(tid != self._doc_tab_id for tid in self.tabs.keys())

        for tab_id, btn in self._close_buttons.items():
            if tab_id == self._doc_tab_id:
                # 文档标签：只有存在其他标签时才显示关闭按钮
                btn.setVisible(has_other_tabs)
            else:
                # 其他标签：总是显示关闭按钮
                btn.setVisible(True)

    def _on_context_menu(self, tab_id: str, pos):
        """显示右键菜单"""

        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: #ffffff;
                border: 1px solid #cccccc;
                padding: 4px;
            }
            QMenu::item {
                padding: 6px 20px;
                color: #333333;
            }
            QMenu::item:selected {
                background-color: #5a9bd5;
                color: white;
            }
            QMenu::separator {
                height: 1px;
                background-color: #cccccc;
                margin: 4px 8px;
            }
        """)

        # 获取当前标签的索引
        current_idx = self.tab_order.index(tab_id) if tab_id in self.tab_order else -1

        # 关闭
        close_action = menu.addAction("关闭")
        close_action.triggered.connect(lambda: self._on_close_clicked(tab_id))

        # 关闭其他
        close_others_action = menu.addAction("关闭其他")
        close_others_action.triggered.connect(lambda: self._close_others(tab_id))

        # 关闭右侧
        if current_idx < len(self.tab_order) - 1:
            close_right_action = menu.addAction("关闭右侧")
            close_right_action.triggered.connect(lambda: self._close_right(tab_id))

        menu.addSeparator()

        # 关闭全部
        close_all_action = menu.addAction("关闭全部")
        close_all_action.triggered.connect(self._close_all)

        # 显示菜单
        menu.exec(self.tabs[tab_id].mapToGlobal(pos))

    def _close_others(self, keep_tab_id: str):
        """关闭除指定标签外的所有标签"""
        tabs_to_close = [tid for tid in self.tab_order if tid != keep_tab_id]
        for tid in tabs_to_close:
            self.close_tab(tid)

    def _close_right(self, tab_id: str):
        """关闭指定标签右侧的所有标签"""
        if tab_id not in self.tab_order:
            return
        idx = self.tab_order.index(tab_id)
        tabs_to_close = self.tab_order[idx + 1:]
        for tid in tabs_to_close:
            self.close_tab(tid)

    def _close_all(self):
        """关闭所有标签（会触发重新打开文档）"""
        tabs_to_close = list(self.tab_order)
        for tid in tabs_to_close:
            self.close_tab(tid)

    def _get_tab_style(self, is_active: bool) -> str:
        """获取标签样式"""
        if is_active:
            return """
                QWidget {
                    background-color: #ffffff;
                    border-top: 2px solid #5a9bd5;
                    border-left: 1px solid #cccccc;
                    border-right: 1px solid #cccccc;
                    border-bottom: 1px solid #ffffff;
                }
                QLabel {
                    color: #333333;
                }
            """
        else:
            return """
                QWidget {
                    background-color: #ececec;
                    border-top: 2px solid transparent;
                    border-left: 1px solid transparent;
                    border-right: 1px solid transparent;
                    border-bottom: 1px solid #cccccc;
                }
                QLabel {
                    color: #666666;
                }
                QWidget:hover {
                    background-color: #f8f8f8;
                }
            """

    def set_active_tab(self, tab_id: str):
        """设置活动标签"""
        if tab_id not in self.tabs:
            return

        # 更新之前的活动标签样式
        if self.active_tab and self.active_tab in self.tabs:
            old_tab = self.tabs[self.active_tab]
            old_tab.setStyleSheet(self._get_tab_style(False))

        # 更新新的活动标签样式
        self.active_tab = tab_id
        new_tab = self.tabs[tab_id]
        new_tab.setStyleSheet(self._get_tab_style(True))

    def _update_tab_title(self, tab_id: str, new_title: str):
        """更新标签页标题"""
        if tab_id not in self.tabs:
            return

        tab_widget = self.tabs[tab_id]
        # 找到标题标签并更新文本
        layout = tab_widget.layout()
        if layout and layout.count() > 0:
            # 第一个widget是标题标签
            label = layout.itemAt(0).widget()
            if label:
                label.setText(new_title)

    def _on_tab_clicked(self, tab_id: str, event: QMouseEvent):
        """标签点击处理"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.set_active_tab(tab_id)
            self.tab_clicked.emit(tab_id)

    def _on_close_clicked(self, tab_id: str):
        """关闭按钮点击处理"""
        self.close_tab(tab_id)

    def close_tab(self, tab_id: str):
        """关闭标签页"""
        if tab_id not in self.tabs:
            return

        # 移除控件
        tab_widget = self.tabs[tab_id]
        self._layout.removeWidget(tab_widget)
        tab_widget.deleteLater()

        # 从字典和顺序列表中移除
        del self.tabs[tab_id]
        if tab_id in self.tab_order:
            self.tab_order.remove(tab_id)

        # 移除关闭按钮引用
        if tab_id in self._close_buttons:
            del self._close_buttons[tab_id]

        # 如果关闭的是活动标签，切换到另一个
        if self.active_tab == tab_id:
            self.active_tab = None
            if self.tab_order:
                # 优先切换到左边的标签
                new_index = max(0, len(self.tab_order) - 1)
                new_tab_id = self.tab_order[new_index]
                self.set_active_tab(new_tab_id)
                self.tab_clicked.emit(new_tab_id)

        # 更新关闭按钮显示状态
        self._update_close_buttons()

        self.tab_closed.emit(tab_id)

    def _on_tab_drag(self, tab_id: str, event: QMouseEvent):
        """标签拖拽处理"""
        if event.buttons() != Qt.MouseButton.LeftButton:
            return

        # 简化的拖拽实现 - 这里可以实现更复杂的拖拽逻辑
        # 目前只记录拖拽状态
        self._drag_tab_id = tab_id


class VSStyleEditor(QWidget):
    """VS Code风格的编辑器 - 包含标签栏和内容区"""

    tab_changed = pyqtSignal(str)  # 当前标签改变
    doc_reopen_requested = pyqtSignal()  # 请求重新打开文档标签

    def __init__(self, parent=None, doc_tab_id: str = "__doc__", node_name: str = ""):
        super().__init__(parent)

        # 文档标签ID
        self._doc_tab_id = doc_tab_id

        # 节点名称（用于生成 CB 中的函数名）
        self._node_name = node_name

        # begin 标签页的代码，用于在其他标签页中补全 begin 定义的变量
        self._begin_code: str = ""

        # ROOT 的类定义代码（包含类属性如 FLAG_R）
        self._root_class_code: str = ""

        # 存储所有打开的标签页
        self._tabs: Dict[str, EditorTab] = {}

        # 跟踪修改状态
        self._modified_tabs: set = set()

        # 创建布局
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 创建标签栏（传入文档标签ID）
        self.tab_bar = VSStyleTabBar(doc_tab_id=doc_tab_id)
        self.tab_bar.tab_clicked.connect(self._on_tab_clicked)
        self.tab_bar.tab_closed.connect(self._on_tab_closed)
        layout.addWidget(self.tab_bar)

        # 创建内容区
        self.content_area = QWidget()
        self.content_layout = QVBoxLayout(self.content_area)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.setSpacing(0)
        layout.addWidget(self.content_area, 1)

        # 当前显示的标签
        self._current_tab: Optional[EditorTab] = None

        # 保存回调函数
        self._save_callback = None

    def set_begin_code(self, begin_code: str):
        """设置 begin 标签页的代码，用于在其他标签页中补全"""
        self._begin_code = begin_code

    def set_root_class_code(self, root_class_code: str):
        """设置 ROOT 的类定义代码，用于在 self. 补全时包含 ROOT 中定义的类属性"""
        self._root_class_code = root_class_code

    def update_all_tabs_context(self):
        """更新所有标签页的上下文代码（当 ROOT 类定义改变时调用）"""
        for tab_id, tab in self._tabs.items():
            if hasattr(tab, '_setup_context_code'):
                tab._setup_context_code(self._begin_code, self._root_class_code)

    def open_tab(self, tab_id: str, title: str, text: str = "") -> EditorTab:
        """打开或切换到标签页（最多5个标签，超过时关闭最早的）"""
        # 如果已存在，切换到它
        if tab_id in self._tabs:
            # [修复] 保存所有修改的标签，而非仅当前标签
            self.save_all_modified_tabs()
            self.tab_bar.set_active_tab(tab_id)
            self._show_tab(tab_id)
            return self._tabs[tab_id]

        # 检查标签数量限制（最多5个）
        MAX_TABS = 5
        while len(self._tabs) >= MAX_TABS:
            # 找到最早的标签（排除文档标签）
            oldest_tab = None
            for tid in self.tab_bar.tab_order:
                if tid != self._doc_tab_id and tid in self._tabs:
                    oldest_tab = tid
                    break

            if oldest_tab:
                self._close_oldest_tab(oldest_tab)
            else:
                # 只有文档标签了，无法关闭
                break

        # [修复] 保存所有修改的标签，而非仅当前标签
        self.save_all_modified_tabs()

        # 创建新标签页（传递节点名称用于生成 CB）
        tab = EditorTab(tab_id, title, node_name=self._node_name)
        # 如果不是 begin 标签页本身，传入 begin 代码用于上下文补全
        if tab_id != '__begin__' and self._begin_code:
            tab.update_begin_context(self._begin_code)
        # 设置 ROOT 类定义代码（用于 self. 补全）
        # 注意：对于 __begin__ 标签，begin_code 应该是空的，避免代码被嵌入两次
        if self._root_class_code:
            begin_code_for_ca = "" if tab_id == '__begin__' else self._begin_code
            tab._setup_context_code(begin_code_for_ca, self._root_class_code)
        tab.set_text(text)
        tab.set_modified_callback(self._on_tab_modified)
        self._tabs[tab_id] = tab

        # 添加到标签栏
        self.tab_bar.add_tab(tab_id, title)

        # 显示标签
        self._show_tab(tab_id)

        return tab

    def set_save_callback(self, callback):
        """设置保存回调函数，参数为(tab_id, text)"""
        self._save_callback = callback

    def _on_tab_modified(self, tab_id: str, is_modified: bool):
        """处理标签修改状态"""
        if is_modified:
            self._modified_tabs.add(tab_id)
        else:
            self._modified_tabs.discard(tab_id)
        # 通知父窗口更新标题
        parent = self.parent()
        while parent:
            if hasattr(parent, '_update_title'):
                parent._update_title()
                break
            parent = parent.parent()

    def _save_modified_tab(self, tab_id: str):
        """保存指定标签页的内容"""
        if tab_id in self._modified_tabs and tab_id in self._tabs:
            text = self._tabs[tab_id].get_text()
            if self._save_callback:
                self._save_callback(tab_id, text)
            self._tabs[tab_id].mark_as_saved()
            self._modified_tabs.discard(tab_id)

    def _close_oldest_tab(self, tab_id: str):
        """关闭最早的标签页（使用标准的关闭逻辑）"""
        # 直接调用标准的标签关闭处理
        self._on_tab_closed(tab_id)

    def save_all_modified_tabs(self):
        """保存所有修改过的标签页"""
        for tab_id in list(self._modified_tabs):
            self._save_modified_tab(tab_id)

    def _on_tab_clicked(self, tab_id: str):
        """标签点击处理 - 切换前保存所有修改的标签"""
        # [修复] 保存所有修改的标签
        self.save_all_modified_tabs()
        self._show_tab(tab_id)

    def _on_tab_closed(self, tab_id: str):
        """标签关闭处理 - 保存所有修改"""
        # [修复] 保存所有修改的标签（包括当前正要关闭的）
        self.save_all_modified_tabs()

        if tab_id in self._tabs:
            tab = self._tabs[tab_id]
            self.content_layout.removeWidget(tab)
            tab.hide()
            del self._tabs[tab_id]

            # 从标签栏中移除
            self.tab_bar.close_tab(tab_id)

            # 如果关闭的是当前标签，显示新的活动标签
            if self._current_tab and self._current_tab.tab_id == tab_id:
                self._current_tab = None
                if self.tab_bar.active_tab and self.tab_bar.active_tab in self._tabs:
                    self._show_tab(self.tab_bar.active_tab)

            # 如果所有标签都关闭了，发出重新打开文档请求
            if len(self._tabs) == 0:
                self.doc_reopen_requested.emit()

    def _show_tab(self, tab_id: str):
        """显示指定标签页的内容"""
        if tab_id not in self._tabs:
            return

        # 隐藏当前标签
        if self._current_tab:
            self._current_tab.hide()

        # 显示新标签
        self._current_tab = self._tabs[tab_id]
        if self._current_tab.parent() != self.content_area:
            self.content_layout.addWidget(self._current_tab)
        self._current_tab.show()

        # 更新标签栏
        self.tab_bar.set_active_tab(tab_id)

        self.tab_changed.emit(tab_id)

    def get_current_tab_id(self) -> Optional[str]:
        """获取当前活动标签页的ID"""
        if self._current_tab:
            return self._current_tab.tab_id
        return None

    def get_tab_text(self, tab_id: str) -> str:
        """获取指定标签页的文本"""
        if tab_id in self._tabs:
            return self._tabs[tab_id].get_text()
        return ""

    def set_tab_text(self, tab_id: str, text: str):
        """设置指定标签页的文本"""
        if tab_id in self._tabs:
            self._tabs[tab_id].set_text(text)

    def close_tab(self, tab_id: str):
        """关闭指定标签页"""
        self.tab_bar.close_tab(tab_id)

    def get_all_tab_texts(self) -> Dict[str, str]:
        """获取所有标签页的文本"""
        return {tab_id: tab.get_text() for tab_id, tab in self._tabs.items()}


class NodeEditWindow(QWidget):
    """
    节点编辑窗口

    功能：
    - 编辑节点名称
    - 显示和管理连接的目标节点列表（支持拖拽排序）
    - VS Code风格的编辑器标签页
    """

    # 信号定义
    name_changed = pyqtSignal(str)  # 名称改变信号
    closed = pyqtSignal()  # 窗口关闭信号
    highlight_connection_requested = pyqtSignal(object)  # 请求高亮连线

    # 类级别的窗口跟踪字典
    _open_windows: dict = {}

    # 固定项的ID映射（用于列表项点击识别）
    FIXED_ITEM_BEGIN = "__begin__"
    FIXED_ITEM_END = "__end__"
    FIXED_ITEM_DOC = "__doc__"

    # 固定项映射：列表文本 -> 数据ID
    FIXED_ITEMS = {
        "📥进入节点": FIXED_ITEM_BEGIN,
        "📤离开节点": FIXED_ITEM_END,
    }

    @classmethod
    def get_or_create(cls, node, parent=None):
        """获取或创建节点的编辑窗口"""
        node_id = id(node)

        if node_id in cls._open_windows:
            window = cls._open_windows[node_id]
            if window.isVisible():
                window.raise_()
                window.activateWindow()
                return window
            else:
                del cls._open_windows[node_id]

        window = cls(node, parent)
        cls._open_windows[node_id] = window
        return window

    @classmethod
    def close_all(cls):
        """关闭所有打开的编辑窗口"""
        for window in list(cls._open_windows.values()):
            window.close()
        cls._open_windows.clear()

    def __init__(self, node, parent=None):
        super().__init__(parent)

        self._node = node
        self._node_id = id(node)

        self._setup_ui()
        self._load_node_data()
        self._connect_signals()

        # 设置初始标题
        self._update_title()
        self.setMinimumSize(860, 650)
        self.resize(960, 650)

        # 通知节点编辑窗口已打开，显示悬浮按钮
        self._node.set_edit_window_open(True)

    def _setup_ui(self):
        """设置UI界面"""
        # 主布局
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(10)
        main_layout.setContentsMargins(12, 12, 12, 12)

        # 设置窗口背景色
        self.setStyleSheet("""
            QWidget {
                background-color: #F0F0F0;
            }
            QLineEdit {
                background-color: #ffffff;
                color: #333333;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 8px 12px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 1px solid #5a9bd5;
            }
        """)

        # 第一行：节点名称标签
        self.name_label = QLabel("名称:")
        self.name_label.setStyleSheet("color: #666666; font-size: 12px;")
        main_layout.addWidget(self.name_label)

        # 名称输入框和置顶按钮的水平布局
        name_row_layout = QHBoxLayout()
        name_row_layout.setSpacing(8)
        name_row_layout.setContentsMargins(0, 0, 0, 0)

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("输入节点名称...")
        name_row_layout.addWidget(self.name_input, 1)

        # 置顶按钮（正方形，📌图标，checkable模式）
        self.pin_button = QPushButton("📌")
        self.pin_button.setFixedSize(36, 36)  # 正方形按钮
        self.pin_button.setCheckable(True)
        self.pin_button.setChecked(True)  # 默认激活（置顶）
        self.pin_button.setToolTip("固定窗口在最前")
        self.pin_button.setStyleSheet("""
            QPushButton {
                background-color: #5a9bd5;
                border: 2px solid #4a8bc5;
                border-radius: 4px;
                font-size: 16px;
                color: white;
            }
            QPushButton:hover {
                background-color: #6aaee5;
                border-color: #5a9bd5;
            }
            QPushButton:pressed {
                background-color: #4a8bc5;
            }
            QPushButton:!checked {
                background-color: #e0e0e0;
                border-color: #cccccc;
                color: #888888;
            }
            QPushButton:!checked:hover {
                background-color: #d0d0d0;
                border-color: #bbbbbb;
            }
        """)
        self.pin_button.toggled.connect(self._on_pin_toggled)
        name_row_layout.addWidget(self.pin_button)

        main_layout.addLayout(name_row_layout)

        # 默认设置为置顶
        self._update_window_stay_on_top(True)

        # 第二行：水平布局（列表 + 编辑器）
        content_layout = QHBoxLayout()
        content_layout.setSpacing(10)

        # 左侧：连接列表
        list_container = QWidget()
        list_layout = QVBoxLayout(list_container)
        list_layout.setContentsMargins(0, 0, 0, 0)
        list_layout.setSpacing(4)

        self.connections_label = QLabel("连接与动作:")
        self.connections_label.setStyleSheet("color: #666666; font-size: 12px;")
        list_layout.addWidget(self.connections_label)

        self.connections_list = DraggableListWidget()
        list_layout.addWidget(self.connections_list)

        content_layout.addWidget(list_container, 30)

        # 右侧：VS风格编辑器（传入文档标签ID和节点名称）
        self.editor = VSStyleEditor(doc_tab_id=self.FIXED_ITEM_DOC, node_name=self._node.name)
        self.editor.doc_reopen_requested.connect(self._reopen_doc_tab)
        self.editor.set_save_callback(self._on_tab_save)
        content_layout.addWidget(self.editor, 70)

        main_layout.addLayout(content_layout, 1)

    def _load_node_data(self):
        """从节点加载数据"""
        # 加载名称
        self.name_input.setText(self._node.name)

        # 加载连接列表（包括固定项）
        self._load_connections()

        # 加载连接文本字典
        connection_texts = getattr(self._node, "_connection_texts", {})
        if not connection_texts:
            connection_texts = {
                "__begin__": "",
                "__end__": "",
                "__doc__": ""
            }

        # 设置 begin 代码用于上下文补全
        begin_code = connection_texts.get("__begin__", "")
        self.editor.set_begin_code(begin_code)

        # 默认打开文档标签
        self._open_fixed_item_tab(self.FIXED_ITEM_DOC, "📄文档")

    def _load_connections(self):
        """加载连接列表（进入节点固定在顶部，离开节点固定在底部）"""
        self.connections_list.clear()

        # 1. 添加顶部固定项：进入节点
        top_item_text = DraggableListWidget.TOP_FIXED_ITEM
        item = QListWidgetItem(top_item_text)
        item.setData(Qt.ItemDataRole.UserRole, DraggableListWidget.FIXED_ITEM_DATA_MAP[top_item_text])
        item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
        self.connections_list.addItem(item)

        # 2. 添加连接项（可拖拽，位于进入和离开之间）
        connections = getattr(self._node, "_connections", [])
        connection_order = getattr(self._node, "_connection_order", None)

        # 排序连接
        if connection_order:
            ordered_connections = []
            for target in connection_order:
                if target in connections:
                    ordered_connections.append(target)
            for target in connections:
                if target not in ordered_connections:
                    ordered_connections.append(target)
            connections = ordered_connections

        # 添加到列表
        for target_node in connections:
            item_text = f"> {target_node.name}"
            list_item = QListWidgetItem(item_text)
            list_item.setData(Qt.ItemDataRole.UserRole, target_node)
            list_item.setFlags(
                Qt.ItemFlag.ItemIsEnabled |
                Qt.ItemFlag.ItemIsSelectable |
                Qt.ItemFlag.ItemIsDragEnabled |
                Qt.ItemFlag.ItemIsDropEnabled
            )
            self.connections_list.addItem(list_item)

        # 3. 添加底部固定项：离开节点
        bottom_item_text = DraggableListWidget.BOTTOM_FIXED_ITEM
        item = QListWidgetItem(bottom_item_text)
        item.setData(Qt.ItemDataRole.UserRole, DraggableListWidget.FIXED_ITEM_DATA_MAP[bottom_item_text])
        item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
        self.connections_list.addItem(item)

        # 存储已连接的节点信号（用于断开连接）
        self._connected_nodes: set = set()

    def _connect_signals(self):
        """连接信号槽"""
        # 名称输入
        self.name_input.editingFinished.connect(self._on_name_edited)
        self._node.name_changed.connect(self._on_node_name_changed)

        # 列表点击 - 打开或切换标签
        self.connections_list.itemClicked.connect(self._on_list_item_clicked)

        # 列表双击 - 高亮连线
        self.connections_list.itemDoubleClicked.connect(self._on_list_item_double_clicked)

        # 连接所有相关节点的名称改变信号
        self._connect_target_node_signals()

    def _on_list_item_clicked(self, item):
        """列表项点击 - 打开或切换标签"""
        data = item.data(Qt.ItemDataRole.UserRole)

        if isinstance(data, str) and data in self.FIXED_ITEMS.values():
            # 固定项
            title_map = {
                self.FIXED_ITEM_BEGIN: "📥进入节点",
                self.FIXED_ITEM_END: "📤离开节点",
                self.FIXED_ITEM_DOC: "📄文档"
            }
            self._open_fixed_item_tab(data, title_map[data])
        else:
            # 连接项
            target_node = data
            tab_id = f"conn_{id(target_node)}"
            title = f"> {target_node.name}"
            self._open_connection_tab(tab_id, title, target_node)

    def _open_fixed_item_tab(self, tab_id: str, title: str):
        """打开固定项标签"""
        connection_texts = getattr(self._node, "_connection_texts", {})
        text = connection_texts.get(tab_id, "")
        self.editor.open_tab(tab_id, title, text)

    def _open_connection_tab(self, tab_id: str, title: str, target_node):
        """打开连接项标签"""
        connection_texts = getattr(self._node, "_connection_texts", {})
        text = connection_texts.get(tab_id, "")
        self.editor.open_tab(tab_id, title, text)

    def _on_list_item_double_clicked(self, item):
        """列表项双击 - 高亮连线"""
        data = item.data(Qt.ItemDataRole.UserRole)

        # 只有连接项可以高亮
        if not isinstance(data, str):
            self.highlight_connection_requested.emit(data)

    def _reopen_doc_tab(self):
        """重新打开文档标签（当关闭文档后关闭所有其他标签时调用）"""
        self._open_fixed_item_tab(self.FIXED_ITEM_DOC, "📄文档")

    def _on_name_edited(self):
        """名称编辑完成，检查安全化名称是否重复"""
        new_name = self.name_input.text().strip()
        if new_name and new_name != self._node.name:
            # 获取画布检查安全化名称是否可用
            canvas = None
            if self._node.scene() and self._node.scene().views():
                view = self._node.scene().views()[0]
                if isinstance(view, NodeCanvas):
                    canvas = view

            if canvas and not canvas.is_safe_name_available(new_name, exclude_node=self._node):
                # 名称冲突，获取一个可用的安全名
                safe_name = canvas.get_safe_name(new_name, exclude_node=self._node)
                # 如果安全名与用户输入不同，使用安全名
                final_name = safe_name if safe_name != new_name else new_name
            else:
                final_name = new_name

            self._node.name = final_name
            self._node.update()
            self._update_title()
            self.name_changed.emit(final_name)
            # 如果名称被修改（因冲突），更新输入框显示
            if final_name != new_name:
                self.name_input.setText(final_name)

    def _on_pin_toggled(self, checked: bool):
        """置顶按钮切换事件"""
        self._update_window_stay_on_top(checked)

    def _update_window_stay_on_top(self, stay_on_top: bool):
        """更新窗口置顶状态，尽量减少闪烁"""
        # 检查当前状态是否已符合要求
        current_stay_on_top = bool(self.windowFlags() & Qt.WindowType.WindowStaysOnTopHint)
        if current_stay_on_top == stay_on_top:
            return  # 状态相同，无需更改

        # 保存窗口状态
        was_visible = self.isVisible()
        pos = self.pos()
        size = self.size()

        # 更新窗口标志
        flags = self.windowFlags()
        if stay_on_top:
            flags |= Qt.WindowType.WindowStaysOnTopHint
        else:
            flags &= ~Qt.WindowType.WindowStaysOnTopHint

        # 设置标志并恢复状态
        self.setWindowFlags(flags)
        self.resize(size)
        self.move(pos)
        if was_visible:
            self.show()
            self.raise_()
            self.activateWindow()

    def _connect_target_node_signals(self):
        """连接所有目标节点的名称改变信号"""
        connections = getattr(self._node, "_connections", [])
        for target_node in connections:
            if target_node not in self._connected_nodes:
                target_node.name_changed.connect(self._on_target_node_name_changed)
                self._connected_nodes.add(target_node)

    def _on_target_node_name_changed(self, node, new_name):
        """目标节点名称改变时的处理 - 更新列表项和标签页标题"""
        # 1. 更新列表项
        for i in range(self.connections_list.count()):
            item = self.connections_list.item(i)
            data = item.data(Qt.ItemDataRole.UserRole)
            # 检查是否是目标节点（通过id比较，因为可能不是同一个对象引用）
            if data is node:
                # 更新列表项文本
                item.setText(f"> {new_name}")
                break

        # 2. 更新已打开的标签页标题和placeholder
        tab_id = f"conn_{id(node)}"
        if tab_id in self.editor._tabs:
            # 更新标签栏标题
            self.editor.tab_bar._update_tab_title(tab_id, f"> {new_name}")
            # 更新 placeholder
            self.editor._tabs[tab_id].update_placeholder(f"> {new_name}")

    def _on_node_name_changed(self, node, new_name):
        """节点名称从外部改变"""
        self._update_title()
        if not self.name_input.hasFocus():
            self.name_input.setText(new_name)

    def update_connection_list(self):
        """更新连接列表（从画布调用）"""
        # 保存当前打开的标签
        open_tabs = list(self.editor._tabs.keys())

        # 重新加载列表
        self._load_connections()

        # 连接新目标节点的信号
        self._connect_target_node_signals()

        # 关闭不再有效的连接标签
        current_targets = set()
        for i in range(self.connections_list.count()):
            item = self.connections_list.item(i)
            data = item.data(Qt.ItemDataRole.UserRole)
            if not isinstance(data, str):
                current_targets.add(f"conn_{id(data)}")

        for tab_id in open_tabs:
            if tab_id.startswith("conn_") and tab_id not in current_targets:
                self.editor.close_tab(tab_id)

    def _save_to_node(self):
        """将数据保存到节点"""
        # 保存名称
        new_name = self.name_input.text().strip()
        if new_name:
            self._node.name = new_name

        # 保存连接顺序（只保存非固定项）
        connection_order = []
        for i in range(self.connections_list.count()):
            item = self.connections_list.item(i)
            data = item.data(Qt.ItemDataRole.UserRole)
            if not isinstance(data, str):  # 只保存连接项
                connection_order.append(data)
        self._node._connection_order = connection_order

        # 保存所有标签页的文本
        if not hasattr(self._node, '_connection_texts') or self._node._connection_texts is None:
            self._node._connection_texts = {}

        all_texts = self.editor.get_all_tab_texts()
        for tab_id, text in all_texts.items():
            self._node._connection_texts[tab_id] = text

        # 通知节点更新
        self._node.update()

    def _on_tab_save(self, tab_id: str, text: str):
        """保存单个标签页的内容到节点

        在切换标签、关闭标签或关闭窗口时被调用
        """
        if not hasattr(self._node, '_connection_texts') or self._node._connection_texts is None:
            self._node._connection_texts = {}

        # 保存文本到节点
        self._node._connection_texts[tab_id] = text

        # 如果保存的是 begin 标签页，更新所有其他标签页的 begin 上下文
        if tab_id == '__begin__' and text:
            for other_tab_id, other_tab in self.editor._tabs.items():
                if other_tab_id != '__begin__':
                    other_tab.update_begin_context(text, self.editor._root_class_code)

    def closeEvent(self, event):
        """窗口关闭事件"""
        try:
            # 先保存所有修改的标签页
            self.editor.save_all_modified_tabs()

            # 安全地保存到节点
            try:
                self._save_to_node()
            except Exception:
                pass  # 节点可能已被销毁

            # 通知节点编辑窗口已关闭，隐藏悬浮按钮
            try:
                if self._node:
                    self._node.set_edit_window_open(False)
            except Exception:
                pass  # 节点可能已被销毁
        except Exception:
            pass

        # 从类级别的窗口管理中移除
        if self._node_id in NodeEditWindow._open_windows:
            del NodeEditWindow._open_windows[self._node_id]

        self.closed.emit()
        event.accept()

    def get_node(self):
        """获取关联的节点"""
        return self._node

    def get_connection_order(self):
        """获取连接顺序"""
        order = []
        for i in range(self.connections_list.count()):
            item = self.connections_list.item(i)
            data = item.data(Qt.ItemDataRole.UserRole)
            if not isinstance(data, str):
                order.append(data)
        return order

    def get_connection_texts(self):
        """获取连接文本字典"""
        return getattr(self._node, '_connection_texts', {
            "__begin__": "",
            "__end__": "",
            "__doc__": ""
        })

    def set_root_class_code(self, root_class_code: str):
        """
        设置 ROOT 的类定义代码，用于在 self. 补全时包含 ROOT 中定义的类属性

        Args:
            root_class_code: ROOT 类定义标签的内容（包含 FLAG_R 等类属性）
        """
        if root_class_code and hasattr(self, 'editor'):
            self.editor.set_root_class_code(root_class_code)

    def _update_title(self):
        """更新窗口标题，根据是否有未保存的修改添加 '*'"""
        has_modified = bool(self.editor._modified_tabs)
        title = f"{self._node.name} - Edit{' *' if has_modified else ''}"
        self.setWindowTitle(title)


# 便捷函数
def edit_node(node, parent=None):
    """打开节点的编辑窗口"""
    return NodeEditWindow.get_or_create(node, parent)


def close_all_edit_windows():
    """关闭所有打开的节点编辑窗口"""
    NodeEditWindow.close_all()
