"""
框选矩形模块
"""

from typing import Optional

from PyQt6.QtWidgets import QGraphicsItem, QGraphicsRectItem
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QBrush, QPen, QColor


class SelectionRect(QGraphicsRectItem):
    """框选矩形"""
    
    def __init__(self, parent: Optional[QGraphicsItem] = None) -> None:
        super().__init__(parent)
        
        # 设置样式（半透明蓝色）
        self.setBrush(QBrush(QColor(0, 120, 215, 50)))
        self.setPen(QPen(QColor(0, 120, 215, 200), 1, Qt.PenStyle.DashLine))
        
        # 设置Z值，确保在最上层
        self.setZValue(1000)
