"""


节点项模块 - 表示状态机中的一个状态节点
"""

from qwork.qnode.old_version.connection_item import ConnectionItem
import re
import unicodedata
from .connection_item import ConnectionItem
from .node_canvas import NodeCanvas


import math
from typing import Optional, TYPE_CHECKING, Callable, List, Union

from PyQt6.QtWidgets import (
    QGraphicsItem, QGraphicsEllipseItem, QGraphicsTextItem,
    QLineEdit, QWidget, QApplication
)
from PyQt6.QtCore import Qt, QPointF, QRectF, QTimer, pyqtSignal, QObject, QPropertyAnimation, QEasingCurve, pyqtProperty
from PyQt6.QtGui import QBrush, QPen, QColor, QFont, QPainterPath

import json

from qwork.qnode.old_version.styles import NodeStyle
from qwork.qnode.old_version.enums import NodeState, NodeShape

class HoverButton(QObject):
    """
    悬浮按钮 - 用于节点编辑的浮动按钮
    包含圆形背景和编辑图标
    """
    clicked = pyqtSignal()  # 点击信号
    
    def __init__(self, parent: QGraphicsItem = None) -> None:
        super().__init__()
        
        self._parent = parent
        self._radius: float = 15.0

        # 创建圆形背景（浅黄灰色）
        self._ellipse_item = QGraphicsEllipseItem(parent)
        self._ellipse_item.setBrush(QBrush(QColor(240, 230, 200)))  # 浅黄灰色
        self._ellipse_item.setPen(QPen(QColor(180, 130, 80), 2))  # 橙灰色描边，2像素宽
        self._ellipse_item.setZValue(100)  # 确保在最上层
        self._ellipse_item.setAcceptHoverEvents(True)
        self._ellipse_item.setToolTip("编辑窗口已打开")  # 添加 tooltip

        # 创建编辑图标文本（书本图标）
        self._text_item = QGraphicsTextItem("📖", parent)
        self._text_item.setZValue(101)  # 确保在圆形背景之上
        self._text_item.setAcceptHoverEvents(False)
        self._text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

        # 初始隐藏（只有当编辑窗口打开时才显示）
        self._opacity: float = 0.0
        self._update_opacity()
        
        # 设置按钮位置（左上角）
        self._update_position()

    def _update_opacity(self) -> None:
        """更新透明度"""
        # 检查 C++ 对象是否已被删除
        if not hasattr(self, '_ellipse_item') or self._ellipse_item is None:
            return
        try:
            self._ellipse_item.setOpacity(self._opacity)
            self._text_item.setOpacity(self._opacity)
        except RuntimeError:
            # C++ 对象已被删除
            pass

    def get_opacity(self) -> float:
        """获取当前透明度"""
        return self._opacity

    def set_opacity(self, value: float) -> None:
        """设置透明度"""
        self._opacity = value
        self._update_opacity()

    # 创建属性用于动画
    opacity = pyqtProperty(float, get_opacity, set_opacity)

    def _is_valid(self) -> bool:
        """检查 C++ 对象是否仍然有效"""
        if not hasattr(self, '_ellipse_item') or self._ellipse_item is None:
            return False
        try:
            # 尝试访问对象，如果已被删除会抛出 RuntimeError
            self._ellipse_item.isVisible()
            return True
        except RuntimeError:
            return False

    def _update_position(self) -> None:
        """更新按钮位置（节点左上角）"""
        if not self._is_valid():
            return
        if self._parent is None:
            return

        try:
            parent_rect = self._parent.rect()
            center = parent_rect.center()

            # 计算节点左上角的偏移位置
            # 按钮中心位于节点左上角偏右下一点的位置
            offset_x = -parent_rect.width() / 2 + self._radius
            offset_y = -parent_rect.height() / 2 + self._radius

            # 设置圆形背景位置
            ellipse_rect = QRectF(
                center.x() + offset_x - self._radius,
                center.y() + offset_y - self._radius,
                self._radius * 2,
                self._radius * 2
            )
            self._ellipse_item.setRect(ellipse_rect)

            # 设置文本居中
            text_rect = self._text_item.boundingRect()
            text_pos = QPointF(
                center.x() + offset_x - text_rect.width() / 2,
                center.y() + offset_y - text_rect.height() / 2
            )
            self._text_item.setPos(text_pos)
        except RuntimeError:
            # C++ 对象已被删除
            pass
    
    def set_radius(self, radius: float) -> None:
        """设置按钮半径"""
        self._radius = radius
        self._update_position()
    
    def show(self) -> None:
        """显示按钮（带动画）"""
        if not self._is_valid():
            return
        try:
            self._update_position()
            self._ellipse_item.show()
            self._text_item.show()
        except RuntimeError:
            pass

    def hide(self) -> None:
        """隐藏按钮"""
        if not self._is_valid():
            return
        try:
            self._ellipse_item.hide()
            self._text_item.hide()
        except RuntimeError:
            pass

    def contains(self, pos: QPointF) -> bool:
        """检查点是否在按钮内"""
        if not self._is_valid():
            return False
        try:
            return self._ellipse_item.contains(pos) or self._text_item.contains(pos)
        except RuntimeError:
            return False

    def mouse_press_event(self, event) -> bool:
        """处理鼠标按下事件"""
        if not self._is_valid():
            return False
        try:
            # 检查是否点击在按钮上
            local_pos = self._ellipse_item.mapFromScene(event.scenePos())
            if self._ellipse_item.contains(local_pos):
                self.clicked.emit()
                return True

            # 检查是否点击在文本上
            text_local_pos = self._text_item.mapFromScene(event.scenePos())
            if self._text_item.contains(text_local_pos):
                self.clicked.emit()
                return True
        except RuntimeError:
            pass

        return False


class StartMarker(QObject):
    """
    起点标记 - 用于在节点右上角显示起点状态
    包含圆形背景和🔷图标
    """

    def __init__(self, parent: QGraphicsItem = None) -> None:
        super().__init__()

        self._parent = parent
        self._radius: float = 15.0

        # 创建圆形背景
        self._ellipse_item = QGraphicsEllipseItem(parent)
        self._ellipse_item.setBrush(QBrush(QColor(200, 240, 220)))  # 浅绿色背景
        self._ellipse_item.setPen(QPen(QColor(80, 150, 100), 2))  # 绿灰色描边，2像素宽
        self._ellipse_item.setZValue(100)  # 确保在最上层
        self._ellipse_item.setAcceptHoverEvents(False)
        self._ellipse_item.setToolTip("起点节点")  # 添加 tooltip

        # 创建图标文本（🔷）
        self._text_item = QGraphicsTextItem("🔷", parent)
        self._text_item.setZValue(101)  # 确保在圆形背景之上
        self._text_item.setAcceptHoverEvents(False)
        self._text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

        # 初始隐藏
        self._opacity: float = 0.0
        self._update_opacity()

        # 设置按钮位置（右上角）
        self._update_position()

    def _is_valid(self) -> bool:
        """检查 C++ 对象是否仍然有效"""
        if not hasattr(self, '_ellipse_item') or self._ellipse_item is None:
            return False
        try:
            # 尝试访问对象，如果已被删除会抛出 RuntimeError
            self._ellipse_item.isVisible()
            return True
        except RuntimeError:
            return False

    def _update_opacity(self) -> None:
        """更新透明度"""
        if not self._is_valid():
            return
        try:
            self._ellipse_item.setOpacity(self._opacity)
            self._text_item.setOpacity(self._opacity)
        except RuntimeError:
            pass

    def get_opacity(self) -> float:
        """获取当前透明度"""
        return self._opacity

    def set_opacity(self, value: float) -> None:
        """设置透明度"""
        self._opacity = value
        self._update_opacity()

    # 创建属性用于动画
    opacity = pyqtProperty(float, get_opacity, set_opacity)

    def _update_position(self) -> None:
        """更新标记位置（节点右上角）"""
        if not self._is_valid():
            return
        if self._parent is None:
            return

        try:
            parent_rect = self._parent.rect()
            center = parent_rect.center()

            # 计算节点右上角的偏移位置
            offset_x = parent_rect.width() / 2 - self._radius
            offset_y = -parent_rect.height() / 2 + self._radius

            # 设置圆形背景位置
            ellipse_rect = QRectF(
                center.x() + offset_x - self._radius,
                center.y() + offset_y - self._radius,
                self._radius * 2,
                self._radius * 2
            )
            self._ellipse_item.setRect(ellipse_rect)

            # 设置文本居中
            text_rect = self._text_item.boundingRect()
            text_pos = QPointF(
                center.x() + offset_x - text_rect.width() / 2,
                center.y() + offset_y - text_rect.height() / 2
            )
            self._text_item.setPos(text_pos)
        except RuntimeError:
            pass

    def set_radius(self, radius: float) -> None:
        """设置标记半径"""
        self._radius = radius
        self._update_position()

    def show(self) -> None:
        """显示标记（带动画）"""
        if not self._is_valid():
            return
        try:
            self._update_position()
            self._ellipse_item.show()
            self._text_item.show()
        except RuntimeError:
            pass

    def hide(self) -> None:
        """隐藏标记"""
        if not self._is_valid():
            return
        try:
            self._ellipse_item.hide()
            self._text_item.hide()
        except RuntimeError:
            pass


class NodeSignalHelper(QObject):
    """
    信号辅助类 - 用于为NodeItem提供信号支持
    因为QGraphicsEllipseItem继承自QGraphicsItem而不是QObject，
    所以需要通过组合方式来提供信号功能
    """
    edit_requested = pyqtSignal(object)  # 编辑请求信号，参数为节点自身
    name_changed = pyqtSignal(object, str)  # 名称改变信号，参数为节点自身和新名称

    def __init__(self, parent: 'NodeItem') -> None:
        super().__init__()
        self._parent = parent


class NodeItem(QGraphicsEllipseItem):
    """
    节点项 - 表示状态机中的一个状态节点
    圆形，显示节点名称，支持多种状态样式
    """

    def __init__(
        self,
        name: str,
        position: QPointF = QPointF(0, 0),
        parent: Optional[QGraphicsItem] = None
    ) -> None:
        """
        初始化节点

        Args:
            name: 节点名称
            position: 节点位置
            parent: 父项
        """
        # 先设置基本属性（不需要QGraphicsItem的部分）
        self._name: str = name
        self._safe_name: str = self._sanitize_name(name)  # 安全化名称
        self._style: NodeStyle = NodeStyle()
        self._state: NodeState = NodeState.IDLE
        self._shape: NodeShape = NodeShape.ELLIPSE
        self._min_radius: float = 40.0
        self._padding: float = 15.0
        self._edit_mode: bool = False

        # 计算半径
        self._radius: float = self._calculate_radius()

        # 初始化QGraphicsEllipseItem（矩形以(0,0)为中心）
        super().__init__(-self._radius, -self._radius, self._radius * 2, self._radius * 2, parent)

        # 使用setPos设置位置（节点的中心点）
        self.setPos(position)

        # 设置节点的Z值，确保在连线上方（连线Z=1，箭头Z=10）
        self.setZValue(50)

        # 创建信号辅助对象
        self._signal_helper = NodeSignalHelper(self)

        # 创建文本项
        self._text_item: QGraphicsTextItem = QGraphicsTextItem(self._name, self)
        self._text_item.setDefaultTextColor(self._style.text_color)
        # 禁用文本项的所有鼠标事件处理，让事件完全传递给父节点
        self._text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        self._text_item.setAcceptHoverEvents(False)
        self._text_item.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        self._center_text()

        # 设置可选项标志
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges, True)
        self.setAcceptHoverEvents(True)

        # 创建悬浮按钮（左上角的编辑按钮）
        self._hover_button: HoverButton = HoverButton(self)
        self._hover_button.clicked.connect(self._on_hover_button_clicked)

        # 创建起点标记（右上角的🔷标记）
        self._start_marker: Optional[HoverButton] = None
        self._is_start_marker_visible: bool = False
        self._start_marker_animation: Optional[QPropertyAnimation] = None

        # 悬浮状态追踪
        self._is_button_visible: bool = False
        self._edit_window_open: bool = False  # 编辑窗口是否打开

        # Recursive 标记
        self._is_recursive: bool = False

        # 创建透明度动画
        self._opacity_animation: QPropertyAnimation = QPropertyAnimation(self._hover_button, b"opacity")
        self._opacity_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

        # 应用样式
        self._apply_style()

    @property
    def edit_requested(self):
        """编辑请求信号"""
        return self._signal_helper.edit_requested

    @property
    def name_changed(self):
        """名称改变信号"""
        return self._signal_helper.name_changed

    def _calculate_radius(self) -> float:
        """根据文本计算节点半径"""
        temp_text = QGraphicsTextItem(self._name)
        text_rect = temp_text.boundingRect()
        
        # 取宽高的较大值，加上padding，确保圆形能容纳文本
        text_size = max(text_rect.width(), text_rect.height())
        radius = (text_size / 2) + self._padding
        
        return max(radius, self._min_radius)
    
    def _center_text(self) -> None:
        """将文本居中到节点"""
        if not self._text_item:
            return
        text_rect = self._text_item.boundingRect()
        center = self.rect().center()

        self._text_item.setPos(
            center.x() - text_rect.width() / 2,
            center.y() - text_rect.height() / 2
        )
    
    def _apply_style(self) -> None:
        """应用当前状态的样式"""
        # 基础填充色
        base_color = self._style.idle_fill
        
        if self._state == NodeState.IDLE:
            fill_color = base_color
            stroke_color = self._style.idle_stroke
        elif self._state == NodeState.HOVER:
            fill_color = self._blend_colors(base_color, self._style.hover_overlay)
            stroke_color = self._style.idle_stroke
        elif self._state == NodeState.SELECTED:
            fill_color = self._blend_colors(base_color, self._style.selected_overlay)
            stroke_color = self._style.selected_stroke
        else:
            fill_color = base_color
            stroke_color = self._style.idle_stroke
        
        self.setBrush(QBrush(fill_color))
        self.setPen(QPen(stroke_color, self._style.stroke_width))
    
    def _blend_colors(self, base: QColor, overlay: QColor, overlay_alpha: float = 0.5) -> QColor:
        """混合两种颜色"""
        result = QColor(overlay)
        result.setAlpha(int(overlay_alpha * 255))
        
        # 简单的颜色混合
        r = int(base.red() * (1 - overlay_alpha) + overlay.red() * overlay_alpha)
        g = int(base.green() * (1 - overlay_alpha) + overlay.green() * overlay_alpha)
        b = int(base.blue() * (1 - overlay_alpha) + overlay.blue() * overlay_alpha)
        
        return QColor(r, g, b)
    
    def set_edit_window_open(self, open: bool) -> None:
        """设置编辑窗口是否打开，控制悬浮按钮的显示（带动画）"""
        self._edit_window_open = open
        if open:
            # 编辑窗口打开时，显示按钮（带动画）
            self._show_hover_button_immediately()
        else:
            # 编辑窗口关闭时，隐藏按钮（带动画）
            self._hide_hover_button()

    def _show_hover_button_immediately(self) -> None:
        """显示悬浮按钮（带淡入动画）- 当编辑窗口打开时调用"""
        if not self._edit_window_open:
            return

        # 计算按钮半径（0.2 * min(width, height)）
        rect = self.rect()
        button_radius = 0.2 * min(rect.width(), rect.height())
        self._hover_button.set_radius(button_radius)

        self._hover_button.show()
        self._is_button_visible = True

        # 淡入动画（200ms）
        self._opacity_animation.stop()
        self._opacity_animation.setDuration(200)
        self._opacity_animation.setStartValue(self._hover_button.get_opacity())
        self._opacity_animation.setEndValue(1.0)
        self._opacity_animation.start()
    
    def _hide_hover_button(self) -> None:
        """隐藏悬浮按钮（带淡出动画）"""
        if not self._is_button_visible:
            return
        
        # 淡出动画（100ms）
        self._opacity_animation.stop()
        self._opacity_animation.setDuration(100)
        self._opacity_animation.setStartValue(self._hover_button.get_opacity())
        self._opacity_animation.setEndValue(0.0)
        self._opacity_animation.finished.connect(self._on_hide_animation_finished)
        self._opacity_animation.start()
    
    def _on_hide_animation_finished(self) -> None:
        """隐藏动画完成回调"""
        self._opacity_animation.finished.disconnect(self._on_hide_animation_finished)
        # 如果编辑窗口已关闭，则隐藏按钮
        if not self._edit_window_open:
            self._hover_button.hide()
            self._is_button_visible = False
    
    def _on_hover_button_clicked(self) -> None:
        """悬浮按钮点击回调"""
        self._signal_helper.edit_requested.emit(self)

    def set_start_marker_visible(self, visible: bool) -> None:
        """设置起点标记的显示状态"""
        if visible == self._is_start_marker_visible:
            return

        self._is_start_marker_visible = visible

        if visible:
            # 创建起点标记
            if self._start_marker is None:
                self._start_marker = StartMarker(self)
                self._start_marker_animation = QPropertyAnimation(self._start_marker, b"opacity")
                self._start_marker_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

            # 显示动画
            self._start_marker.show()
            self._start_marker_animation.stop()
            self._start_marker_animation.setDuration(200)
            self._start_marker_animation.setStartValue(self._start_marker.get_opacity())
            self._start_marker_animation.setEndValue(1.0)
            self._start_marker_animation.start()
        else:
            # 隐藏动画
            if self._start_marker is not None:
                self._start_marker_animation.stop()
                self._start_marker_animation.setDuration(100)
                self._start_marker_animation.setStartValue(self._start_marker.get_opacity())
                self._start_marker_animation.setEndValue(0.0)
                self._start_marker_animation.finished.connect(self._on_start_marker_hide_finished)
                self._start_marker_animation.start()

    def _on_start_marker_hide_finished(self) -> None:
        """起点标记隐藏动画完成回调"""
        self._start_marker_animation.finished.disconnect(self._on_start_marker_hide_finished)
        if not self._is_start_marker_visible and self._start_marker is not None:
            self._start_marker.hide()

    @property
    def name(self) -> str:
        """获取节点名称"""
        return self._name
    
    @name.setter
    def name(self, value: str) -> None:
        """设置节点名称（不检查重名，重名检查由外部负责）"""
        old_name = self._name
        self._name = value
        self._safe_name = self._sanitize_name(value)  # 更新安全化名称
        self._text_item.setPlainText(value)

        # 发射名称改变信号
        if old_name != value:
            self._signal_helper.name_changed.emit(self, value)

        # 重新计算半径
        new_radius = self._calculate_radius()
        if new_radius != self._radius:
            self._radius = new_radius
            rect = self.rect()
            center = rect.center()
            new_rect = QRectF(
                center.x() - self._radius,
                center.y() - self._radius,
                self._radius * 2,
                self._radius * 2
            )
            self.setRect(new_rect)
            self._center_text()
            # 更新起点标记位置（如果存在）
            if self._start_marker is not None:
                self._start_marker._update_position()
        else:
            self._center_text()
    
    @property
    def safe_name(self) -> str:
        """获取安全化的节点名称（合法Python标识符）"""
        return self._safe_name

    @property
    def radius(self) -> float:
        """获取节点半径"""
        return self._radius

    @radius.setter
    def radius(self, value: float) -> None:
        """设置节点半径"""
        self._radius = value
        # 更新矩形大小
        rect = self.rect()
        center = rect.center()
        new_rect = QRectF(
            center.x() - self._radius,
            center.y() - self._radius,
            self._radius * 2,
            self._radius * 2
        )
        self.setRect(new_rect)
        self._center_text()

    @property
    def center(self) -> QPointF:
        """获取节点中心点"""
        return self.sceneBoundingRect().center()
    
    @property
    def state(self) -> NodeState:
        """获取节点状态"""
        return self._state
    
    @state.setter
    def state(self, value: NodeState) -> None:
        """设置节点状态"""
        if self._state != value:
            self._state = value
            self._apply_style()

    def generate_code(self, index: int = -1, isc: bool = False) -> str:
        """
        生成节点的Python代码

        新格式：使用 CA/CB/CC 结构
        - CA: from builtin import *
        - CB: def {safe_name}(self, c: Creep, k: GlobalKnowledge, *refs):\n    <__begin__>
        - CC: 用户编辑的代码，替换 <__begin__> 占位符

        Args:
            index: 控制输出哪些块
                - -1: 输出全部
                - 0 或 'doc': 仅文档
                - 1 或 'begin': 文档 + 进入节点
                - 2+: 文档 + 进入节点 + 前 (index-1) 个连接（包括对应的子函数和调用链）
            isc: 是否使用类型注解形式，True用 'c: Creep'，False用 'it'

        Returns:
            生成的Python代码字符串
        """
        # 处理字符串类型的index
        if isinstance(index, str):
            index_map = {
                'doc': 0,
                'begin': 1,
                'end': -1
            }
            index = index_map.get(index, -1)

        # 获取连接文本字典
        texts = getattr(self, '_connection_texts', {
            '__doc__': '',
            '__begin__': '',
            '__end__': ''
        })

        # 获取连接列表（按顺序）
        connections = getattr(self, '_connections', [])
        connection_order = getattr(self, '_connection_order', None)

        # 按顺序排列连接
        if connection_order:
            ordered_connections = []
            for target in connection_order:
                if target in connections:
                    ordered_connections.append(target)
            for target in connections:
                if target not in ordered_connections:
                    ordered_connections.append(target)
            connections = ordered_connections

        # 分离不同类型的块
        doc_text = texts.get('__doc__', '').strip()
        begin_text = texts.get('__begin__', '').strip()
        end_text = texts.get('__end__', '').strip()

        # 收集连接块（目标节点原始名称, 安全名称, 内容）
        connection_blocks = []
        for target_node in connections:
            conn_key = f"conn_{id(target_node)}"
            conn_text = texts.get(conn_key, '').strip()
            if conn_text:
                # 存储原始名称（用于$Begin/$End）、安全名称（用于代码）和内容
                connection_blocks.append((target_node.name, target_node.safe_name, conn_text))

        # 根据index过滤
        if index == 0:
            # 仅文档
            begin_text = ""
            end_text = ""
            connection_blocks = []
        elif index == 1:
            # 文档 + 进入节点
            end_text = ""
            connection_blocks = []
        elif index >= 2:
            # 文档 + 进入节点 + 前(index-1)个连接
            connection_blocks = connection_blocks[:index - 1]
        # else: -1 输出全部

        # CA - 导入语句（固定）
        ca_code = "from builtin import *"

        # CB - 函数定义，包含 <__begin__> 占位符
        first_param = 'c: Creep' if isc else 'it'
        cb_code = f"def {self._safe_name}(self, {first_param}, k: GlobalKnowledge, *refs):\n    <__begin__>"

        # CC - 构建主函数体各部分（替换 <__begin__> 的内容）
        cc_parts = []

        # 0. 文档块
        if doc_text:
            doc_lines = doc_text.split('\n')
            indented_lines = ['    ' + line for line in doc_lines]
            indented_doc = '\n'.join(indented_lines)
            cc_parts.append(f'"""\n{indented_doc}\n    """')

        # 1. 进入节点块（使用 $Begin/$End 包裹）
        if begin_text:
            formatted_begin = self._format_block_content_spaces(begin_text)
            cc_parts.append(f"'''$Begin:begin'''\n{formatted_begin}\n    '''$End:begin'''\n")

        # 2. 连接块：生成子函数定义 + if-elif 调用链
        if connection_blocks:
            # 生成子函数定义
            sub_functions = []
            for target_name, target_safe_name, content in connection_blocks:
                sub_func_name = f"_to_{target_safe_name}"

                # 格式化子函数内容（双重缩进，因为是嵌套函数）
                lines = content.split('\n')
                indented_lines = []
                for line in lines:
                    if line.strip():
                        if not line.startswith('    '):
                            line = '        ' + line
                        else:
                            # 已有4空格缩进，再加一层
                            line = '    ' + line
                    else:
                        line = '    ' + line
                    indented_lines.append(line)
                sub_content = '\n'.join(indented_lines)

                # 构建子函数定义（$Begin/$End 包裹整个函数定义）
                sub_func = f"    def {sub_func_name}():\n{sub_content}"
                wrapped_sub_func = f"    '''$Begin:{target_name}'''\n{sub_func}\n    '''$End:{target_name}'''\n"
                sub_functions.append(wrapped_sub_func)

            cc_parts.extend(sub_functions)

            # 生成 if-elif 调用链
            if_chain_lines = []
            for i, (_, target_safe_name, _) in enumerate(connection_blocks):
                sub_func_name = f"_to_{target_safe_name}"

                # 第一个用 if，后续用 elif
                if i == 0:
                    prefix = "if"
                else:
                    prefix = "elif"

                # 调用子函数并返回目标节点安全化名称
                if_chain_lines.append(f"{prefix} {sub_func_name}():\n        return \"{target_safe_name}\"")

            # if-elif 链需要有正确的缩进
            if_chain_code = '\n    '.join(if_chain_lines)
            cc_parts.append('    ' + if_chain_code + '\n')

        # 3. 退出节点块
        if end_text:
            formatted_end = self._format_block_content_spaces(end_text)
            cc_parts.append(f"    '''$Begin:end'''\n{formatted_end}\n    '''$End:end'''\n")

        # 组装 CC（函数体内容）
        if not cc_parts:
            cc_code = "pass"
        else:
            cc_code = '\n'.join(cc_parts)

        # 组装最终代码：CA + CB（<__begin__> 替换为 CC）
        full_code = f"{ca_code}\n\n{cb_code.replace('<__begin__>', cc_code)}"
        return full_code

    def _format_block_content_spaces(self, content: str) -> str:
        """格式化块内容，确保每行都有4空格缩进"""
        lines = content.split('\n')
        indented_lines = []
        for line in lines:
            if line.strip() and not line.startswith('    '):
                line = '    ' + line
            indented_lines.append(line)
        return '\n'.join(indented_lines)

    def _format_block_content(self, content: str) -> str:
        """格式化块内容，确保每行都有制表符缩进"""
        lines = content.split('\n')
        indented_lines = []
        for line in lines:
            if line.strip() and not line.startswith('\t'):
                line = '\t' + line
            indented_lines.append(line)
        return '\n'.join(indented_lines)

    def _format_block_content_spaces(self, content: str) -> str:
        """格式化块内容，确保每行都有4空格缩进"""
        lines = content.split('\n')
        indented_lines = []
        for line in lines:
            if line.strip() and not line.startswith('    '):
                line = '    ' + line
            indented_lines.append(line)
        return '\n'.join(indented_lines)

    @staticmethod
    def _sanitize_name(name: str) -> str:
        """
        将节点名称转换为有效的Python标识符

        Python 3 标识符规则：
        - 第一个字符：字母（含中文）或下划线
        - 后续字符：字母（含中文）、数字或下划线

        Args:
            name: 原始节点名称

        Returns:
            安全的Python标识符
        """

        if not name:
            return 'node'

        # 检查字符是否是合法的标识符字符
        def is_valid_char(c: str, is_first: bool) -> bool:
            if c == '_':
                return True
            if is_first:
                # 第一个字符：必须是字母或下划线（不能是数字）
                return unicodedata.category(c).startswith('L')
            else:
                # 后续字符：可以是字母或数字
                cat = unicodedata.category(c)
                return cat.startswith('L') or cat.startswith('N')

        # 构建安全名称
        safe_chars = []
        for i, c in enumerate(name):
            if is_valid_char(c, i == 0):
                safe_chars.append(c)
            else:
                safe_chars.append('_')

        safe = ''.join(safe_chars)

        # 如果第一个字符是数字（原始名称以数字开头），添加下划线前缀
        if safe and safe[0].isdigit():
            safe = '_' + safe

        # 确保不为空
        if not safe:
            safe = 'node'

        return safe

    def hoverEnterEvent(self, event) -> None:
        """鼠标进入事件"""
        if self._state != NodeState.SELECTED:
            self._state = NodeState.HOVER
            self._apply_style()

        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event) -> None:
        """鼠标离开事件"""
        if self._state != NodeState.SELECTED:
            self._state = NodeState.IDLE
            self._apply_style()

        super().hoverLeaveEvent(event)
        
        super().hoverLeaveEvent(event)
    
    def mousePressEvent(self, event) -> None:
        """鼠标按下事件"""
        # 检查是否点击了悬浮按钮
        if self._is_button_visible and self._hover_button.mouse_press_event(event):
            return
        
        super().mousePressEvent(event)
    
    def itemChange(self, change: QGraphicsItem.GraphicsItemChange, value):
        """项状态改变事件"""
        if change == QGraphicsItem.GraphicsItemChange.ItemSelectedChange:
            if value:
                self._state = NodeState.SELECTED
            else:
                self._state = NodeState.IDLE
            self._apply_style()
        elif change == QGraphicsItem.GraphicsItemChange.ItemPositionHasChanged:
            # 位置已改变，更新连接
            if self.scene():
                self._update_connections()
        
        return super().itemChange(change, value)
    
    def _update_connections(self) -> None:
        """更新与此节点相关的所有连接"""
        if not self.scene():
            return

        for item in self.scene().items():
            if isinstance(item, ConnectionItem):
                if item.source_node == self or item.target_node == self:
                    item.update_path()

    # ==================== AI API 方法 ====================

    def to_dict(self) -> dict:
        """
        将节点转换为字典

        Returns:
            包含节点所有数据的字典
        """
        # 获取现有的 connection_texts
        connection_texts = getattr(self, '_connection_texts', {}).copy()

        # 确保每个连接都有对应的字段（即使为空）
        connections = getattr(self, '_connections', [])
        for target_node in connections:
            conn_key = f"conn_{id(target_node)}"
            if conn_key not in connection_texts:
                connection_texts[conn_key] = ""

        # 确保 __begin__ 和 __end__ 字段存在（即使为空）
        if "__begin__" not in connection_texts:
            connection_texts["__begin__"] = ""
        if "__end__" not in connection_texts:
            connection_texts["__end__"] = ""

        data = {
            "id": id(self),  # 使用对象id作为唯一标识
            "name": self._name,
            "position": {"x": self.pos().x(), "y": self.pos().y()},
            "connection_texts": connection_texts,
        }
        # 递归节点有特殊属性
        if hasattr(self, '_is_recursive') and self._is_recursive:
            data["is_recursive"] = True
            data["radius"] = self._radius
        return data

    def from_dict(self, data: dict) -> None:
        """
        从字典更新节点数据

        Args:
            data: 节点数据字典，可以只包含要修改的部分

        Example:
            node.from_dict({"name": "new_name"})  # 只改名称
            node.from_dict({"position": {"x": 100, "y": 200}})  # 只改位置
            node.from_dict({"connection_texts": {"__begin__": "pass"}})  # 合并代码
        """
        # 更新名称
        if "name" in data:
            self.set_name(data["name"])

        # 更新位置
        if "position" in data:
            pos = data["position"]
            self.setPos(QPointF(pos.get("x", 0), pos.get("y", 0)))

        # 更新代码（合并而非替换）
        if "connection_texts" in data:
            if not hasattr(self, '_connection_texts'):
                self._connection_texts = {}
            self._connection_texts.update(data["connection_texts"])

        # 更新递归属性
        if "is_recursive" in data:
            self._is_recursive = data["is_recursive"]
        if "radius" in data:
            self._radius = data["radius"]
            # 更新椭圆大小
            self.setRect(-self._radius, -self._radius, self._radius * 2, self._radius * 2)

    def copy(self) -> None:
        """
        复制节点到剪贴板
        将节点的JSON内容复制到剪贴板，排除id和position信息
        不包含connection和起点信息
        """
        data = self.to_dict()

        # 移除id信息
        data.pop("id", None)

        # 移除position信息（复制时不包含位置）
        data.pop("position", None)

        # 移除connection_texts中的连接特定内容（以conn_开头的键）
        if "connection_texts" in data:
            filtered_texts = {}
            for key, value in data["connection_texts"].items():
                # 只保留非连接特定的键（不以conn_开头）
                if not key.startswith("conn_"):
                    filtered_texts[key] = value
            data["connection_texts"] = filtered_texts

        # 将JSON复制到剪贴板
        json_str = json.dumps(data, ensure_ascii=False, indent=2)
        clipboard = QApplication.clipboard()
        clipboard.setText(json_str)

    @staticmethod
    def from_json(json_data: Union[str, dict], position: Optional[QPointF] = None) -> 'NodeItem':
        """
        从JSON数据实例化节点

        静态方法，不使用JSON中的id和position信息，并进行必要字段的检查

        字段检查规则：
        - 必要字段（必须存在且有效）：
            - name: 字符串类型，非空

        - 可选字段（如果存在会被应用）：
            - connection_texts: 字典类型，节点的代码块内容
            - is_recursive: bool/int/str类型，是否标记为递归节点
            - radius: 数值类型，节点半径（必须 >= min_radius）

        - 忽略的字段：
            - id: 始终忽略，创建新节点会生成新的id
            - position: 忽略JSON中的位置，优先使用传入的position参数，否则默认(0, 0)
            - 其他未知字段: 被忽略

        Args:
            json_data: JSON字符串或字典，包含节点数据
            position: 可选，指定节点位置，如果不提供则默认为(0, 0)

        Returns:
            新创建的NodeItem实例

        Raises:
            ValueError: 如果JSON数据缺少必要字段或格式不正确

        Example:
            # 从JSON字符串创建（位置默认为0,0）
            node = NodeItem.from_json('{"name": "State1", "connection_texts": {"__begin__": "pass"}}')

            # 从字典创建，并指定新位置
            node = NodeItem.from_json(data_dict, QPointF(300, 400))
        """
        # 解析JSON字符串
        if isinstance(json_data, str):
            try:
                data = json.loads(json_data)
            except json.JSONDecodeError as e:
                raise ValueError(f"无效的JSON数据: {e}")
        else:
            data = json_data.copy() if json_data else {}

        # 检查必要字段
        if not isinstance(data, dict):
            raise ValueError("JSON数据必须是字典类型")

        # 必须包含name字段
        if "name" not in data or not data["name"]:
            raise ValueError("缺少必要字段: name（节点名称）")

        name = data["name"]
        if not isinstance(name, str):
            raise ValueError(f"name必须是字符串类型，当前类型: {type(name).__name__}")

        # 确定位置
        if position is not None:
            # 使用传入的位置（优先）
            node_pos = position
        else:
            # 默认位置（忽略JSON中的position）
            node_pos = QPointF(0, 0)

        # 创建节点实例
        node = NodeItem(name=name, position=node_pos)

        # 应用connection_texts（如果存在）
        if "connection_texts" in data and isinstance(data["connection_texts"], dict):
            node._connection_texts = data["connection_texts"].copy()

        # 应用递归属性（如果存在）
        if "is_recursive" in data:
            is_recursive = data["is_recursive"]
            if isinstance(is_recursive, bool):
                node._is_recursive = is_recursive
            elif isinstance(is_recursive, (int, str)):
                # 尝试转换为bool
                node._is_recursive = bool(is_recursive)

        # 应用radius（如果存在且大于最小半径）
        if "radius" in data:
            try:
                radius = float(data["radius"])
                if radius >= node._min_radius:
                    node._radius = radius
                    node.setRect(-radius, -radius, radius * 2, radius * 2)
                    # 重新计算文本位置
                    node._center_text()
                    # 更新起点标记位置（如果存在）
                    if node._start_marker is not None:
                        node._start_marker._update_position()
            except (TypeError, ValueError):
                # 忽略无效的radius值
                pass

        return node

    def get_name(self) -> str:
        """获取节点名称"""
        return self._name

    def set_name(self, name: str) -> None:
        """设置节点名称"""
        self._name = name
        self._safe_name = self._sanitize_name(name)
        if self._text_item:
            self._text_item.setPlainText(name)
            # 强制文本项重新计算大小
            self._text_item.adjustSize()
        # 重新计算半径以适应新名称
        self._radius = self._calculate_radius()
        self.setRect(-self._radius, -self._radius, self._radius * 2, self._radius * 2)
        self._center_text()
        # 更新起点标记位置（如果存在）
        if self._start_marker is not None:
            self._start_marker._update_position()
        # 发射名称改变信号
        self._signal_helper.name_changed.emit(self, name)
        self.update()  # 触发重绘

    def get_position(self) -> dict:
        """获取节点位置"""
        return {"x": self.pos().x(), "y": self.pos().y()}

    def set_position(self, x: float, y: float) -> None:
        """
        设置节点在场景中的位置（中心点）

        Args:
            x: X 坐标
            y: Y 坐标
        """
        # 设置矩形为以(0,0)为中心
        self.setRect(-self._radius, -self._radius, self._radius * 2, self._radius * 2)

        # 使用setPos设置节点在场景中的位置
        self.setPos(QPointF(x, y))

    def get_connection_texts(self) -> dict:
        """获取连接文本字典"""
        return getattr(self, '_connection_texts', {})

    def set_connection_texts(self, texts: dict) -> None:
        """设置连接文本字典（合并）"""
        if not hasattr(self, '_connection_texts'):
            self._connection_texts = {}
        self._connection_texts.update(texts)

    def generate_method_code(self, base_indent: str = "    ") -> str:
        """
        生成节点方法代码（与 generate_code 使用相同的连接处理逻辑）

        规则：
        - 只输出有内容的块（不包括文档块 __doc__）
        - 如果所有块都没有内容，输出 pass
        - 每个有内容的块带有 # $Begin:XXX 和 # $End:XXX 标记

        Args:
            base_indent: 基础缩进（默认4空格，即类方法级别）

        Returns:
            方法代码字符串
        """
        lines = []
        texts = getattr(self, '_connection_texts', {})
        body_indent = base_indent + "    "  # 方法体内缩进

        # 收集所有有内容的块（不包括文档块 __doc__）
        content_blocks = []

        # 检查 __begin__ 块
        begin_code = texts.get("__begin__", "").strip()
        if begin_code:
            content_blocks.append(("begin", begin_code))

        # 检查 __end__ 块
        end_code = texts.get("__end__", "").strip()
        has_end_block = bool(end_code)

        # 获取出边连接（使用与 generate_code 相同的逻辑）
        connections = getattr(self, '_connections', [])
        connection_order = getattr(self, '_connection_order', None)

        # 按顺序排列连接
        if connection_order:
            ordered_connections = []
            for target in connection_order:
                if target in connections:
                    ordered_connections.append(target)
            for target in connections:
                if target not in ordered_connections:
                    ordered_connections.append(target)
            connections = ordered_connections

        # 收集有内容的连接块
        conn_blocks = []
        for target_node in connections:
            conn_key = f"conn_{id(target_node)}"
            conn_text = texts.get(conn_key, '').strip()
            if conn_text:  # 只收集有内容的连接
                target_name = target_node._name if target_node else "unknown"
                conn_blocks.append((target_name, conn_text))

        # 递归装饰器
        if getattr(self, '_is_recursive', False):
            lines.append(f"{base_indent}@recursive")

        # 方法定义
        lines.append(f"{base_indent}def {self._name}(self, c: Creep, k: GlobalKnowledge, *refs):")

        # 添加文档块（如果有内容）
        doc_code = texts.get("__doc__", "").strip()
        if doc_code:
            for line in doc_code.split("\n"):
                lines.append(f"{body_indent}{line}")

        # 如果没有任何有内容的块，输出 pass
        if not content_blocks and not conn_blocks and not has_end_block:
            lines.append(f"{body_indent}pass")
        else:
            # 输出 begin 块（如果有内容）
            if content_blocks:
                block_name, block_code = content_blocks[0]
                lines.append(f"{body_indent}# $Begin:{block_name}")
                for line in block_code.split("\n"):
                    lines.append(f"{body_indent}{line}")
                lines.append(f"{body_indent}# $End:{block_name}")
                lines.append("")

            # 输出连接块（如果有内容）
            for target_name, conn_text in conn_blocks:
                func_name = f"_to_{target_name}"

                lines.append(f"{body_indent}def {func_name}():")
                lines.append(f"{body_indent}    # $Begin:{target_name}")
                for line in conn_text.split("\n"):
                    lines.append(f"{body_indent}    {line}")
                lines.append(f"{body_indent}    # $End:{target_name}")
                lines.append("")
                lines.append(f"{body_indent}if {func_name}():")
                lines.append(f'{body_indent}    return "{target_name}"')
                lines.append("")

            # 输出 end 块（如果有内容）
            if has_end_block:
                lines.append(f"{body_indent}# $Begin:end")
                for line in end_code.split("\n"):
                    lines.append(f"{body_indent}{line}")
                lines.append(f"{body_indent}# $End:end")

        return "\n".join(lines)

    def mouseDoubleClickEvent(self, event) -> None:
        """双击事件 - 编辑节点名称或打开编辑窗口"""
        if event.button() == Qt.MouseButton.LeftButton:
            # 检查是否双击在文本区域
            text_rect = self._text_item.boundingRect()
            text_pos = self._text_item.pos()
            click_pos = event.pos()
            
            # 判断点击位置是否在文本区域内
            is_on_text = (
                text_pos.x() <= click_pos.x() <= text_pos.x() + text_rect.width() and
                text_pos.y() <= click_pos.y() <= text_pos.y() + text_rect.height()
            )
            
            if is_on_text:
                # 双击文本区域 - 编辑节点名称
                self._start_editing()
            else:
                # 双击非文本区域 - 打开编辑窗口
                self._signal_helper.edit_requested.emit(self)
        
        super().mouseDoubleClickEvent(event)
    
    def _start_editing(self) -> None:
        """开始编辑节点名称 - LineEdit覆盖在Label上"""
        if self._edit_mode:
            return
        
        self._edit_mode = True
        
        # 隐藏文本项
        self._text_item.hide()
        
        # 创建LineEdit作为子项
        self._line_edit = QLineEdit()
        self._line_edit.setText(self._name)
        self._line_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # 设置样式，使其看起来与Label一致
        self._line_edit.setStyleSheet("""
            QLineEdit {
                background-color: transparent;
                border: none;
                color: #333333;
            }
        """)
        
        # 设置字体
        font = QFont()
        font.setPointSize(10)
        self._line_edit.setFont(font)
        
        # 获取视图并添加LineEdit
        scene = self.scene()
        if scene and scene.views():
            view = scene.views()[0]
            
            # 计算LineEdit的位置和大小
            text_rect = self._text_item.boundingRect()
            node_rect = self.rect()
            
            # 将节点坐标转换为视图坐标
            text_scene_pos = self.mapToScene(self._text_item.pos())
            text_view_pos = view.mapFromScene(text_scene_pos)
            
            # 设置LineEdit大小与文本项相同
            self._line_edit.setFixedSize(int(text_rect.width()) + 20, int(text_rect.height()) + 10)
            
            # 居中放置
            center_view_pos = view.mapFromScene(self.mapToScene(node_rect.center()))
            self._line_edit.move(
                center_view_pos.x() - self._line_edit.width() // 2,
                center_view_pos.y() - self._line_edit.height() // 2
            )
            
            # 添加到视图
            self._line_edit.setParent(view.viewport())
            self._line_edit.show()
            self._line_edit.setFocus()
            self._line_edit.selectAll()
            
            # 连接信号
            self._line_edit.editingFinished.connect(self._finish_editing)
    
    def _finish_editing(self) -> None:
        """完成编辑节点名称，检查安全化名称是否重复"""
        if hasattr(self, '_line_edit'):
            new_name = self._line_edit.text().strip()
            if new_name and new_name != self._name:
                # 检查安全化名称是否可用
                canvas = None
                if self.scene() and self.scene().views():
                    view = self.scene().views()[0]
                    if isinstance(view, NodeCanvas):
                        canvas = view

                if canvas and not canvas.is_safe_name_available(new_name, exclude_node=self):
                    # 名称冲突，获取一个可用的安全名并提示用户
                    safe_name = canvas.get_safe_name(new_name, exclude_node=self)
                    # 尝试使用安全名作为新名称（如果与用户输入不同）
                    if safe_name != new_name:
                        # 使用安全名作为显示名称（添加数字后缀）
                        self.name = safe_name
                    else:
                        # 安全名相同但冲突（不同字符安全化后相同）
                        # 保持原名称不变
                        pass
                else:
                    self.name = new_name

            # 移除LineEdit
            self._line_edit.deleteLater()
            delattr(self, '_line_edit')

        # 显示文本项
        self._text_item.show()
        self._edit_mode = False

    @property
    def shape_type(self) -> NodeShape:
        """获取节点形状"""
        return self._shape

    @shape_type.setter
    def shape_type(self, value: NodeShape) -> None:
        """设置节点形状"""
        if self._shape != value:
            self._shape = value
            self.update()  # 触发重绘

    def toggle_shape(self) -> None:
        """切换节点形状（圆形/矩形）"""
        if self._shape == NodeShape.ELLIPSE:
            self._shape = NodeShape.RECTANGLE
        else:
            self._shape = NodeShape.ELLIPSE
        self.update()  # 触发重绘

    @property
    def is_recursive(self) -> bool:
        """获取是否标记为 Recursive"""
        return self._is_recursive

    def set_recursive(self, recursive: bool) -> None:
        """设置 Recursive 标记状态"""
        if self._is_recursive != recursive:
            self._is_recursive = recursive
            self.update()  # 触发重绘

    def toggle_recursive(self) -> None:
        """切换 Recursive 标记状态"""
        self.set_recursive(not self._is_recursive)

    def paint(self, painter, option, widget=None) -> None:
        """绘制节点，根据形状绘制圆形或矩形"""
        # 获取当前样式
        base_color = self._style.idle_fill

        if self._state == NodeState.IDLE:
            fill_color = base_color
            stroke_color = self._style.idle_stroke
        elif self._state == NodeState.HOVER:
            fill_color = self._blend_colors(base_color, self._style.hover_overlay)
            stroke_color = self._style.idle_stroke
        elif self._state == NodeState.SELECTED:
            fill_color = self._blend_colors(base_color, self._style.selected_overlay)
            stroke_color = self._style.selected_stroke
        else:
            fill_color = base_color
            stroke_color = self._style.idle_stroke

        painter.setBrush(QBrush(fill_color))
        painter.setPen(QPen(stroke_color, self._style.stroke_width))

        rect = self.rect()

        # 先绘制形状填充和正常描边
        if self._shape == NodeShape.ELLIPSE:
            painter.drawEllipse(rect)
        else:
            corner_radius = min(rect.width(), rect.height()) * 0.2
            painter.drawRoundedRect(rect, corner_radius, corner_radius)

        # 绘制 Recursive 紫红色描边（在正常描边内部）
        if self._is_recursive:
            # 使用更明显的颜色和更宽的描边
            recursive_pen = QPen(QColor(220, 20, 140), 4)  # 亮紫红色，4像素宽
            recursive_pen.setCosmetic(True)  # 保持线宽不受变换影响
            painter.setPen(recursive_pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)  # 不填充

            if self._shape == NodeShape.ELLIPSE:
                # 缩小较多的椭圆，使紫红色描边在正常描边内部明显可见
                shrink = 5  # 增加缩进距离
                recursive_rect = rect.adjusted(shrink, shrink, -shrink, -shrink)
                # 确保矩形有效
                if recursive_rect.width() > 0 and recursive_rect.height() > 0:
                    painter.drawEllipse(recursive_rect)
            else:
                # 缩小较多的圆角矩形
                shrink = 5
                recursive_rect = rect.adjusted(shrink, shrink, -shrink, -shrink)
                if recursive_rect.width() > 0 and recursive_rect.height() > 0:
                    corner_radius = min(recursive_rect.width(), recursive_rect.height()) * 0.2
                    painter.drawRoundedRect(recursive_rect, corner_radius, corner_radius)

            # 恢复画笔
            painter.setPen(QPen(stroke_color, self._style.stroke_width))

        # 绘制可连线边缘区域的视觉指示（浅灰色描边）
        self._draw_edge_indicator(painter, rect)

        # 绘制文本项边框（提示用户不要点击此处）
        self._draw_text_border(painter)

    def get_edge_point(self, target_pos: QPointF) -> QPointF:
        """
        计算从节点中心到目标位置的边缘点
        根据节点形状（圆形或矩形）计算正确的边缘交点
        """
        center = self.center

        if self._shape == NodeShape.ELLIPSE:
            dx = target_pos.x() - center.x()
            dy = target_pos.y() - center.y()
            angle = math.atan2(dy, dx)
            return QPointF(
                center.x() + self._radius * math.cos(angle),
                center.y() + self._radius * math.sin(angle)
            )
        else:
            # 圆角矩形处理
            rect = self.rect()
            local_target = self.mapFromScene(target_pos)
            local_center = rect.center()

            dx = local_target.x() - local_center.x()
            dy = local_target.y() - local_center.y()

            if abs(dx) < 1e-6 and abs(dy) < 1e-6:
                return center

            half_w = rect.width() / 2
            half_h = rect.height() / 2
            corner_radius = min(half_w, half_h) * 0.2

            # 计算与外层矩形的交点
            t_x = half_w / abs(dx) if abs(dx) > 1e-6 else float('inf')
            t_y = half_h / abs(dy) if abs(dy) > 1e-6 else float('inf')
            t_rect = min(t_x, t_y)

            # 矩形交点（本地坐标）
            ix = local_center.x() + dx * t_rect
            iy = local_center.y() + dy * t_rect

            # 内矩形边界（不含圆角的区域）
            inner_w = half_w - corner_radius
            inner_h = half_h - corner_radius

            # 检查是否在圆角区域（同时超出内矩形的x和y边界）
            in_corner = abs(ix - local_center.x()) > inner_w and abs(iy - local_center.y()) > inner_h

            if not in_corner:
                # 在直线边上，直接返回矩形交点
                return self.mapToScene(QPointF(ix, iy))

            # 在圆角区域，计算与圆的精确交点
            sign_x = 1 if dx > 0 else -1
            sign_y = 1 if dy > 0 else -1

            # 圆角圆心（本地坐标）
            cx = local_center.x() + sign_x * inner_w
            cy = local_center.y() + sign_y * inner_h

            # 解二次方程：|t*V - (C - O)|^2 = r^2，其中O是local_center
            # 简化为标准形式 at^2 + bt + c = 0
            a = dx * dx + dy * dy
            b = -2 * (dx * (cx - local_center.x()) + dy * (cy - local_center.y()))
            c = (cx - local_center.x()) ** 2 + (cy - local_center.y()) ** 2 - corner_radius ** 2

            discriminant = b * b - 4 * a * c

            if discriminant < 0:
                return self.mapToScene(QPointF(ix, iy))

            sqrt_d = math.sqrt(discriminant)
            t1 = (-b - sqrt_d) / (2 * a)
            t2 = (-b + sqrt_d) / (2 * a)

            # 边界限制（确保交点不超出矩形的边）
            min_x = local_center.x() - half_w
            max_x = local_center.x() + half_w
            min_y = local_center.y() - half_h
            max_y = local_center.y() + half_h

            valid_ts = []
            for t in [t1, t2]:
                if t > 1e-6:
                    px = local_center.x() + dx * t
                    py = local_center.y() + dy * t

                    # 检查是否在正确的象限（相对于圆心）
                    in_quad_x = (sign_x > 0 and px >= cx) or (sign_x < 0 and px <= cx)
                    in_quad_y = (sign_y > 0 and py >= cy) or (sign_y < 0 and py <= cy)

                    # 关键修正：确保在矩形边界内（不超出直线边范围）
                    in_bounds = (min_x <= px <= max_x) and (min_y <= py <= max_y)

                    if in_quad_x and in_quad_y and in_bounds:
                        valid_ts.append(t)

            if not valid_ts:
                return self.mapToScene(QPointF(ix, iy))

            # 取较近的有效交点（进入圆的交点）
            t_arc = min(valid_ts)

            local_edge_x = local_center.x() + dx * t_arc
            local_edge_y = local_center.y() + dy * t_arc

            return self.mapToScene(QPointF(local_edge_x, local_edge_y))

    def _draw_edge_indicator(self, painter, rect) -> None:
        """
        绘制可连线边缘区域的视觉指示
        在节点边缘显示一个浅灰色的环，指示用户可以从此处拖拽创建连线
        """
        # 边缘区域的起始比例（与 node_canvas.py 中 _is_on_node_edge 一致）
        # 视觉指示比实际可连线区域稍小（减小1-2像素）
        inner_ratio = 0.75  # 边缘区域宽度

        # 非常浅的灰色
        indicator_color = QColor(200, 200, 200, 60)  # 浅灰色，半透明
        indicator_pen = QPen(indicator_color, 1)
        indicator_pen.setStyle(Qt.PenStyle.SolidLine)
        painter.setPen(indicator_pen)
        painter.setBrush(QBrush(indicator_color))

        if self._shape == NodeShape.ELLIPSE:
            # 圆形：绘制一个圆环（填充的椭圆减去内部）
            # 由于 QPainter 的混合模式，我们直接绘制一个半透明的圆环
            center = rect.center()
            outer_radius = self._radius
            inner_radius = self._radius * inner_ratio

            # 创建圆环路径（外圆减去内圆）
            path = QPainterPath()
            path.addEllipse(center, outer_radius, outer_radius)
            path.addEllipse(center, inner_radius, inner_radius)
            painter.drawPath(path)
        else:
            # 矩形：绘制一个边框环
            corner_radius = min(rect.width(), rect.height()) * 0.2

            # 内矩形（不包含边缘环的区域）
            margin = (1 - inner_ratio) * min(rect.width(), rect.height()) / 2
            inner_rect = rect.adjusted(margin, margin, -margin, -margin)

            # 创建矩形环路径（外矩形减去内矩形）
            path = QPainterPath()
            path.addRoundedRect(rect, corner_radius, corner_radius)
            inner_corner = max(0, corner_radius - margin)
            path.addRoundedRect(inner_rect, inner_corner, inner_corner)
            painter.drawPath(path)

    def _draw_text_border(self, painter) -> None:
        """
        绘制文本项的虚线边框
        提示用户从边缘拖拽创建连线，而不是点击文字
        """
        text_rect = self._text_item.boundingRect()
        text_pos = self._text_item.pos()

        # 文本项的矩形（在节点坐标系中）
        border_rect = QRectF(
            text_pos.x(),
            text_pos.y(),
            text_rect.width(),
            text_rect.height()
        )

        # 浅灰色虚线
        border_color = QColor(200, 200, 200, 60)  # 浅灰色，半透明
        border_pen = QPen(border_color, 1)
        border_pen.setStyle(Qt.PenStyle.DashLine)
        border_pen.setDashPattern([3, 3])  # 3像素实线，3像素空白

        painter.setPen(border_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)  # 不填充

        # 绘制虚线边框
        painter.drawRect(border_rect)
