# ===== 调试：传入检查的 code =====
# code 类型: <class 'str'>
# code 长度: 3076

# Generated Python Code from Node Canvas
# ====================================

from builtin import *

class WorkerCreep(CreepLogic):
    """
    一个简单的工人爬虫示例
    """

    NAME = 'WorkerCreep'
    RECIPE = 'MW'

    # 类属性定义
    ENERGY_TARGET = 200  # 目标能量值

    # ==================== Class Callbacks ====================

    def onLoading(self, c: Creep | None, k: GlobalKnowledge, *refs):
        # $Begin:onLoading
        print("WorkerCreep 加载完成")
        # $End:onLoading

    def onStart(self, c: Creep, k: GlobalKnowledge, *refs):
        # $Begin:onStart
        print(f"爬虫 {c.name} 开始工作")
        # $End:onStart

    def onStep(self, c: Creep, k: GlobalKnowledge, *refs):
        # $Begin:onStep
        pass
        # $End:onStep

    def onStop(self, c: Creep, k: GlobalKnowledge, *refs):
        # $Begin:onStop
        print("爬虫停止")
        # $End:onStop

    def onDraw(self, c: Creep, k: GlobalKnowledge, *refs):
        # $Begin:onDraw
        pass
        # $End:onDraw

    def onKilled(self, c: Creep | None, k: GlobalKnowledge, *refs):
        # $Begin:onKilled
        print("爬虫被击杀")
        # $End:onKilled

    # ==================== Node Functions ====================

    def start(self, c: Creep, k: GlobalKnowledge, *refs):
        """
        开始节点：初始化爬虫状态
        """
        # $Begin:begin
        # 获取爬虫能量
        current_energy = c.store.getUsedCapacity(RESOURCE_ENERGY)
        max_energy = c.store.getCapacity(RESOURCE_ENERGY)
        print(f"当前能量：{current_energy}/{max_energy}")
        # $End:begin

        def _to_move():
            # $Begin:move
            return True  # 总是跳转到move节点
            # $End:move

        if _to_move():
            return "move"


    def move(self, c: Creep, k: GlobalKnowledge, *refs):
        """
        移动节点：检查是否需要移动
        """
        # $Begin:begin
        # 检查爬虫是否有足够的能量
        has_energy = c.store.getUsedCapacity(RESOURCE_ENERGY) > 0
        print(f"移动检查：有能量={has_energy}")
        # $End:begin

        def _to_work():
            # $Begin:work
            # 如果有能量，跳转到工作节点
            return has_energy
            # $End:work

        if _to_work():
            return "work"

        # $Begin:end
        # 如果没有执行任何跳转，默认继续
        c.move(TOP)
        # $End:end

    def work(self, c: Creep, k: GlobalKnowledge, *refs):
        """
        工作节点：执行工作操作
        """
        # $Begin:begin
        # 查找附近的工作目标
        # 使用全局函数查找资源
        target = findClosest(c, FIND_SOURCES)
        print(f"工作目标：{target}")
        # $End:begin

        def _to_end():
            # $Begin:end
            # 工作完成后跳转到结束节点
            return True
            # $End:end

        if _to_end():
            return "end"

        # $Begin:end
        # 收尾操作：如果没有跳转则采集
        if target:
            c.harvest(target)
        # $End:end

    def end(self, c: Creep, k: GlobalKnowledge, *refs):
        """
        结束节点：清理和重置状态
        """
        # $Begin:begin
        # 记录工作完成
        print(f"{c.name} 完成了一个工作周期")
        # $End:begin

        # $Begin:end
        # 重置状态，准备下一个周期
        pass
        # $End:end
