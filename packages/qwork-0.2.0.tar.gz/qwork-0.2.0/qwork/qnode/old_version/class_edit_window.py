"""


ClassEditWindow - ROOT 图元的编辑窗口

采用与 NodeEditWindow 类似的布局：
- 左侧：列表（文档、类定义、onXxx 回调）
- 右侧：VS Code 风格的编辑器
"""

from .root_item import RootItem
from PyQt6.QtWidgets import QGridLayout, QCheckBox, QSpinBox, QDoubleSpinBox
from PyQt6.QtCore import Qt
from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QCheckBox, QSpinBox, QDoubleSpinBox, QComboBox, QLineEdit
import ast


from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QFrame,
    QComboBox, QListWidget, QListWidgetItem,
    QApplication
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont, QColor, QPalette
from typing import Dict, List, TYPE_CHECKING

# 导入 NodeEditWindow 中的编辑器组件
import sys
sys.path.insert(0, 'C:/Users/22290/Desktop/node')
from node_widgets.node_edit_window import VSStyleEditor, DraggableListWidget


class ClassEditWindow(QMainWindow):
    """
    ROOT 图元的类编辑窗口

    布局：
    - 顶部：类名和继承类型选择
    - 中部：左侧列表（文档、类定义、onXxx），右侧编辑器
    - 底部：保存/取消按钮
    """

    # 信号定义
    closed = pyqtSignal()  # 窗口关闭信号

    # 类级别的窗口管理 - 每个 ROOT 实例只能有一个窗口
    _instances: dict = {}  # root_item -> window

    # 固定项的ID映射
    TAB_DOC = "__doc__"
    TAB_CDEF = "__cdef__"  # 类定义

    # 固定项显示文本
    FIXED_ITEMS = {
        TAB_DOC: "📄文档",
        TAB_CDEF: "📋类定义",
    }

    @classmethod
    def get_or_create(cls, root_item, parent=None):
        """
        获取或创建 ROOT 的编辑窗口

        Args:
            root_item: RootItem 实例
            parent: 父窗口

        Returns:
            ClassEditWindow 实例
        """
        # 检查是否已有窗口
        if root_item in cls._instances:
            window = cls._instances[root_item]
            window.raise_()
            window.activateWindow()
            return window

        # 创建新窗口
        window = cls(root_item, parent)
        cls._instances[root_item] = window
        return window

    @classmethod
    def close_for_root(cls, root_item):
        """关闭指定 ROOT 的编辑窗口"""
        if root_item in cls._instances:
            window = cls._instances[root_item]
            window.close()
            del cls._instances[root_item]

    @classmethod
    def close_all(cls):
        """关闭所有打开的 ClassEditWindow"""
        for window in list(cls._instances.values()):
            window.close()
        cls._instances.clear()

    @classmethod
    def get_all_open_windows(cls):
        """获取所有打开的窗口列表"""
        return list(cls._instances.values())

    def __init__(self, root_item, parent=None):
        """
        初始化 ClassEditWindow

        Args:
            root_item: RootItem 实例
            parent: 父窗口
        """
        super().__init__(parent)

        self._root_item = root_item
        self._original_name = root_item.name if root_item else "MyClass"

        # 存储标签页内容（类似 Node 的 _connection_texts）
        self._tab_contents: Dict[str, str] = {
            self.TAB_DOC: "",
            self.TAB_CDEF: "",
        }

        # 设置行布局引用
        self._settings_layout = None

        # 窗口设置
        self.setWindowTitle(f"编辑类 - {self._original_name}")
        self.setMinimumSize(860, 650)
        self.resize(960, 750)

        # 创建UI
        self._setup_ui()
        self._load_root_data()
        self._connect_signals()

        # 设置初始标题
        self._update_title()

        # 通知 ROOT 图元窗口已打开
        self._root_item.set_edit_window_open(True)

    def _setup_ui(self):
        """设置UI界面"""
        # 创建中央部件
        central = QWidget()
        self.setCentralWidget(central)

        # 主布局
        main_layout = QVBoxLayout(central)
        main_layout.setSpacing(10)
        main_layout.setContentsMargins(12, 12, 12, 12)

        # 设置窗口背景色（注意：不设置 QPushButton 全局样式，以免影响标签栏的关闭按钮）
        self.setStyleSheet("""
            QWidget {
                background-color: #F0F0F0;
            }
            QLineEdit {
                background-color: #ffffff;
                color: #333333;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 8px 12px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 1px solid #5a9bd5;
            }
            /* 注意：QComboBox 样式由具体实例设置，不设置全局样式 */
            /* 注意：不设置 QPushButton 全局样式，由各个按钮自行设置 */
        """)

        # 第一行：类名和类型选择（在同一行）
        name_row_layout = QHBoxLayout()
        name_row_layout.setSpacing(8)

        # 类名标签和输入框
        name_label = QLabel("类名:")
        name_label.setStyleSheet("color: #666666; font-size: 12px;")
        name_label.setToolTip("生成的Python类名，同时也是爬虫名称(NAME)，不能以数字开头和结尾")
        name_row_layout.addWidget(name_label)

        self._name_input = QLineEdit(self._original_name)
        self._name_input.setPlaceholderText("输入类名...")
        self._name_input.setMinimumWidth(200)  # 确保类名显示完整
        name_row_layout.addWidget(self._name_input, 1)

        # 类名改变时更新上下文代码
        self._name_input.textChanged.connect(self._update_all_tabs_context_code)

        # 间隔
        name_row_layout.addSpacing(20)

        # 导入自标签和下拉框
        import_label = QLabel("导入自:")
        import_label.setStyleSheet("color: #666666; font-size: 12px;")
        import_label.setToolTip("选择导入来源：builtin(完整游戏API) 或 basic(用户增强型基础)")
        name_row_layout.addWidget(import_label)

        self._import_combo = QComboBox()
        self._import_combo.addItems(["builtin", "basic"])
        self._import_combo.setFixedWidth(100)
        # 设置当前值（默认 builtin）
        if self._root_item:
            current_import = getattr(self._root_item, 'import_from', 'builtin')
            index = self._import_combo.findText(current_import)
            if index >= 0:
                self._import_combo.setCurrentIndex(index)
        name_row_layout.addWidget(self._import_combo)

        # 间隔
        name_row_layout.addSpacing(10)

        # 继承类型标签和下拉框
        type_label = QLabel("继承自:")
        type_label.setStyleSheet("color: #666666; font-size: 12px;")
        type_label.setToolTip("选择基类：CreepLogic(带爬虫生命周期管理) 或 Logic(纯逻辑无实体)")
        name_row_layout.addWidget(type_label)

        self._type_combo = QComboBox()
        self._type_combo.addItems(["CreepLogic", "Logic"])
        self._type_combo.setFixedWidth(140)
        # 设置当前值
        if self._root_item:
            current_type = self._root_item.logic_type
            index = self._type_combo.findText(current_type)
            if index >= 0:
                self._type_combo.setCurrentIndex(index)
        name_row_layout.addWidget(self._type_combo)

        # 置顶按钮（📌图标，checkable模式）
        self._pin_button = QPushButton("📌")
        self._pin_button.setFixedSize(36, 36)
        self._pin_button.setCheckable(True)
        self._pin_button.setChecked(False)  # 默认不置顶
        self._pin_button.setToolTip("固定窗口在最前")
        self._pin_button.setStyleSheet("""
            QPushButton {
                background-color: #5a9bd5;
                border: 2px solid #4a8bc5;
                border-radius: 4px;
                font-size: 16px;
                color: white;
            }
            QPushButton:hover {
                background-color: #6aaee5;
                border-color: #5a9bd5;
            }
            QPushButton:pressed {
                background-color: #4a8bc5;
            }
            QPushButton:!checked {
                background-color: #e0e0e0;
                border-color: #cccccc;
                color: #888888;
            }
            QPushButton:!checked:hover {
                background-color: #d0d0d0;
                border-color: #bbbbbb;
            }
        """)
        self._pin_button.toggled.connect(self._on_pin_toggled)
        name_row_layout.addWidget(self._pin_button)

        # 默认不置顶
        self._update_window_stay_on_top(False)

        # 使用按钮式下拉框，更现代
        self._type_combo.setStyleSheet("""
            QComboBox {
                background-color: #ffffff;
                color: #333333;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 8px 12px;
                font-size: 14px;
                combobox-popup: 0;
            }
            QComboBox:hover {
                border-color: #5a9bd5;
                background-color: #f8f9fa;
            }
            QComboBox:focus {
                border-color: #5a9bd5;
            }
            QComboBox::drop-down {
                border: none;
                width: 28px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 5px solid #666666;
                margin-right: 8px;
            }
            QComboBox::down-arrow:on {
                border-top: none;
                border-bottom: 5px solid #666666;
            }
            QComboBox QAbstractItemView {
                background-color: #ffffff;
                color: #333333;
                border: 1px solid #e0e0e0;
                border-radius: 10px;
                selection-background-color: transparent;
                selection-color: #333333;
                padding: 8px;
                outline: none;
                margin-top: 6px;
            }
            QComboBox QAbstractItemView::item {
                background-color: transparent;
                border: none;
                padding: 10px 16px;
                border-radius: 8px;
                min-height: 20px;
                margin: 4px 0px;
            }
            QComboBox QAbstractItemView::item:hover {
                background-color: #f0f7ff;
                border: none;
            }
            QComboBox QAbstractItemView::item:selected {
                background-color: #5a9bd5;
                color: #ffffff;
                border: none;
            }
        """)

        # 为导入自下拉框设置相同样式
        self._import_combo.setStyleSheet("""
            QComboBox {
                background-color: #ffffff;
                color: #333333;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 8px 12px;
                font-size: 14px;
                combobox-popup: 0;
            }
            QComboBox:hover {
                border-color: #5a9bd5;
                background-color: #f8f9fa;
            }
            QComboBox:focus {
                border-color: #5a9bd5;
            }
            QComboBox::drop-down {
                border: none;
                width: 28px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 5px solid #666666;
                margin-right: 8px;
            }
            QComboBox::down-arrow:on {
                border-top: none;
                border-bottom: 5px solid #666666;
            }
            QComboBox QAbstractItemView {
                background-color: #ffffff;
                color: #333333;
                border: 1px solid #e0e0e0;
                border-radius: 10px;
                selection-background-color: transparent;
                selection-color: #333333;
                padding: 8px;
                outline: none;
                margin-top: 6px;
            }
            QComboBox QAbstractItemView::item {
                background-color: transparent;
                border: none;
                padding: 10px 16px;
                border-radius: 8px;
                min-height: 20px;
                margin: 4px 0px;
            }
            QComboBox QAbstractItemView::item:hover {
                background-color: #f0f7ff;
                border: none;
            }
            QComboBox QAbstractItemView::item:selected {
                background-color: #5a9bd5;
                color: #ffffff;
                border: none;
            }
        """)

        main_layout.addLayout(name_row_layout)

        # 设置属性行（网格布局）
        self._settings_layout = self._setup_settings_row(main_layout)

        # 第二行：水平布局（列表 + 编辑器）
        content_layout = QHBoxLayout()
        content_layout.setSpacing(10)

        # 左侧：标签列表
        list_container = QWidget()
        list_layout = QVBoxLayout(list_container)
        list_layout.setContentsMargins(0, 0, 0, 0)
        list_layout.setSpacing(4)

        list_label = QLabel("类成员:")
        list_label.setStyleSheet("color: #666666; font-size: 12px;")
        list_label.setToolTip("类的组成部分：文档、类定义、以及各种回调函数(onLoading/onStart/onStep等)")
        list_layout.addWidget(list_label)

        self._tab_list = QListWidget()
        self._tab_list.setStyleSheet("""
            QListWidget {
                background-color: #ffffff;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 4px;
            }
            QListWidget::item {
                background-color: #e8e8e8;
                color: #333333;
                border-radius: 4px;
                padding: 8px 12px;
                margin: 2px 0px;
                font-size: 13px;
            }
            QListWidget::item:selected {
                background-color: #5a9bd5;
                color: #ffffff;
                border: 1px solid #4a8bc5;
            }
            QListWidget::item:hover {
                background-color: #d0d0d0;
            }
            QListWidget::item:selected:hover {
                background-color: #5a9bd5;
            }
        """)
        self._tab_list.itemClicked.connect(self._on_list_item_clicked)
        list_layout.addWidget(self._tab_list)

        content_layout.addWidget(list_container, 30)

        # 右侧：VS风格编辑器（传入文档标签ID和类名）
        self._editor = VSStyleEditor(doc_tab_id=self.TAB_DOC, node_name=self._original_name)
        self._editor.doc_reopen_requested.connect(self._reopen_doc_tab)
        self._editor.set_save_callback(self._on_tab_save)
        content_layout.addWidget(self._editor, 70)

        main_layout.addLayout(content_layout, 1)

    def _setup_editor_context_code(self):
        """为编辑器设置上下文代码（包含实际的类定义）"""
        if not self._root_item:
            return

        # 获取类名和继承类型
        class_name = self._name_input.text().strip() or self._root_item.name
        base_class = self._type_combo.currentText() or self._root_item.logic_type

        # 获取类定义标签的内容（类属性定义，应无缩进）
        class_def_code = self._tab_contents.get(self.TAB_CDEF, "")

        # 类定义代码不加缩进（存储时保持原始无缩进格式）
        formatted_class_def = ""
        if class_def_code:
            lines = class_def_code.strip().split('\n')
            formatted_class_def = '\n'.join(line.lstrip() for line in lines if line.strip())
            if formatted_class_def:
                formatted_class_def = f"\n    # 类属性定义\n    " + formatted_class_def.replace('\n', '\n    ') + '\n'

        # 构建 CA（类定义代码）
        # 包含导入语句和完整的类定义
        CA = f"""from builtin import *

class {class_name}({base_class}):
    NAME = '{class_name}'
{formatted_class_def}
    # onXxx 回调占位符（由编辑器提供具体实现）
    def _placeholder_(self, c: Creep, k: GlobalKnowledge, *refs: "CreepLogic"):
        <__begin__>
"""

        # CB - 不需要额外的函数定义
        CB = ""

        # 设置所有标签页的上下文代码
        for tab_id, tab in self._editor._tabs.items():
            if hasattr(tab, 'editor'):
                tab.editor.set_context_code(
                    code_a=CA,
                    code_b=CB,
                    prefix="        "  # 8空格缩进
                )

    def _update_all_tabs_context_code(self):
        """更新所有标签页的上下文代码"""
        self._setup_editor_context_code()


    def _connect_signals(self):
        """连接信号"""
        # 类类型改变时更新列表和回调
        self._type_combo.currentTextChanged.connect(self._on_type_changed)

        # 监听 RootItem 的名称变化（当外部通过 API 修改时）
        if self._root_item:
            self._root_item._signal_helper.name_changed.connect(self._on_root_name_changed)

    def _on_root_name_changed(self, root_item, new_name: str):
        """
        当外部（如 API）修改 RootItem 名称时的回调

        更新窗口标题和类名输入框（如果当前没有编辑）
        """
        # 更新窗口标题（通过 _update_title 考虑修改状态）
        self._update_title()

        # 如果输入框没有被聚焦（用户没有在编辑），则更新输入框
        if not self._name_input.hasFocus():
            # 暂时断开 textChanged 信号，避免循环
            self._name_input.textChanged.disconnect(self._update_all_tabs_context_code)
            self._name_input.setText(new_name)
            self._name_input.textChanged.connect(self._update_all_tabs_context_code)

    def _on_type_changed(self, new_type: str):
        """类类型改变时的回调"""
        if self._root_item:
            # 获取新类型的有效回调列表
            valid_callbacks = set(RootItem._get_on_callbacks_for_type(new_type))

            # 关闭不再属于新类型的已打开标签页
            self._close_invalid_tabs(valid_callbacks)

            # 更新 root_item 的类型
            self._root_item.logic_type = new_type

            # 重新加载列表以更新 onXxx 项
            self._reload_tab_list()

            # 重新创建设置行
            self._refresh_settings_row()

            # 更新上下文代码（继承类型改变）
            self._update_all_tabs_context_code()

    def _refresh_settings_row(self):
        """刷新设置属性行"""
        # 获取主布局
        main_layout = self.centralWidget().layout()

        # 使用存储的引用移除旧的设置行
        if hasattr(self, '_settings_layout') and self._settings_layout:
            old_layout = self._settings_layout
            while old_layout.count():
                child = old_layout.takeAt(0)
                if child.widget():
                    child.widget().deleteLater()
                elif child.layout():
                    # 递归清理子布局
                    self._clear_layout(child.layout())
            main_layout.removeItem(old_layout)

        # 重新创建设置行（不添加到父布局）
        self._settings_layout = self._setup_settings_row(None)

        # 在正确位置插入（索引1，在name_row_layout之后，content_layout之前）
        main_layout.insertLayout(1, self._settings_layout)

        # 刷新布局
        self.centralWidget().update()

    def _clear_layout(self, layout):
        """递归清理布局中的所有控件"""
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
            elif child.layout():
                self._clear_layout(child.layout())

    def _setup_settings_row(self, parent_layout):
        """设置属性行 - 网格布局显示类级别设置（现代简洁风格）"""

        # 创建网格布局
        grid = QGridLayout()
        grid.setSpacing(12)
        grid.setContentsMargins(4, 8, 4, 8)

        # 获取当前类型的设置
        settings = self._root_item.class_settings if self._root_item else []
        if not settings:
            # 即使为空也添加布局占位（如果提供了父布局）
            if parent_layout:
                parent_layout.addLayout(grid)
            return grid

        # 存储控件引用
        self._setting_widgets = {}

        # 每行最多5个格子，文本型占2个
        col = 0
        row = 0

        for setting in settings:
            name = setting["name"]
            setting_type = setting["type"]
            default = setting["default"]
            description = setting.get("description", "")

            # 创建容器 widget 用于组合标签和控件
            container = QWidget()
            hlayout = QHBoxLayout(container)
            hlayout.setSpacing(4)
            hlayout.setContentsMargins(0, 0, 0, 0)

            # 创建标签
            label = QLabel(name)
            label.setStyleSheet("color: #888888; font-size: 11px; font-weight: 500;")
            label.setToolTip(description)
            hlayout.addWidget(label)

            # 根据类型创建不同的控件
            if setting_type == "bool":
                # 复选框 - 与窗口风格一致
                widget = QCheckBox()
                widget.setChecked(bool(default))
                widget.setToolTip(description)
                widget.setStyleSheet("""
                    QCheckBox {
                        spacing: 4px;
                    }
                    QCheckBox::indicator {
                        width: 16px;
                        height: 16px;
                        border-radius: 4px;
                        border: 1px solid #cccccc;
                        background-color: #ffffff;
                    }
                    QCheckBox::indicator:hover {
                        border-color: #5a9bd5;
                    }
                    QCheckBox::indicator:checked {
                        background-color: #5a9bd5;
                        border-color: #4a8bc5;
                    }
                """)
            elif setting_type == "int":
                # 整数输入框
                widget = QSpinBox()
                widget.setRange(-999999, 999999)
                if default is not None:
                    widget.setValue(default)
                widget.setToolTip(description)
                widget.setFixedWidth(70)
                widget.setStyleSheet("""
                    QSpinBox {
                        background-color: #ffffff;
                        border: 1px solid #cccccc;
                        border-radius: 4px;
                        padding: 4px;
                        font-size: 12px;
                        color: #333333;
                    }
                    QSpinBox:focus {
                        border-color: #5a9bd5;
                    }
                    QSpinBox::up-button {
                        width: 16px;
                        border-left: 1px solid #cccccc;
                        border-bottom: 1px solid #cccccc;
                        background: #f8f8f8;
                        border-top-right-radius: 3px;
                        padding: 2px;
                    }
                    QSpinBox::down-button {
                        width: 16px;
                        border-left: 1px solid #cccccc;
                        background: #f8f8f8;
                        border-bottom-right-radius: 3px;
                        padding: 2px;
                    }
                    QSpinBox::up-button:hover, QSpinBox::down-button:hover {
                        background-color: #e8e8e8;
                    }
                    QSpinBox::up-arrow {
                        image: none;
                        border-left: 3px solid transparent;
                        border-right: 3px solid transparent;
                        border-bottom: 5px solid #666666;
                        width: 0px;
                        height: 0px;
                    }
                    QSpinBox::down-arrow {
                        image: none;
                        border-left: 3px solid transparent;
                        border-right: 3px solid transparent;
                        border-top: 5px solid #666666;
                        width: 0px;
                        height: 0px;
                    }
                """)
            elif setting_type == "float":
                # 浮点数输入框
                widget = QDoubleSpinBox()
                widget.setRange(-999999.9, 999999.9)
                widget.setSingleStep(0.1)
                widget.setDecimals(1)
                if default is not None:
                    widget.setValue(default)
                widget.setToolTip(description)
                widget.setFixedWidth(70)
                widget.setStyleSheet("""
                    QDoubleSpinBox {
                        background-color: #ffffff;
                        border: 1px solid #cccccc;
                        border-radius: 4px;
                        padding: 4px;
                        font-size: 12px;
                        color: #333333;
                    }
                    QDoubleSpinBox:focus {
                        border-color: #5a9bd5;
                    }
                    QDoubleSpinBox::up-button {
                        width: 16px;
                        border-left: 1px solid #cccccc;
                        border-bottom: 1px solid #cccccc;
                        background: #f8f8f8;
                        border-top-right-radius: 3px;
                        padding: 2px;
                    }
                    QDoubleSpinBox::down-button {
                        width: 16px;
                        border-left: 1px solid #cccccc;
                        background: #f8f8f8;
                        border-bottom-right-radius: 3px;
                        padding: 2px;
                    }
                    QDoubleSpinBox::up-button:hover, QDoubleSpinBox::down-button:hover {
                        background-color: #e8e8e8;
                    }
                    QDoubleSpinBox::up-arrow {
                        image: none;
                        border-left: 3px solid transparent;
                        border-right: 3px solid transparent;
                        border-bottom: 5px solid #666666;
                        width: 0px;
                        height: 0px;
                    }
                    QDoubleSpinBox::down-arrow {
                        image: none;
                        border-left: 3px solid transparent;
                        border-right: 3px solid transparent;
                        border-top: 5px solid #666666;
                        width: 0px;
                        height: 0px;
                    }
                """)
            elif setting_type == "select":
                # 下拉选择类型
                options = setting.get("options", [])
                widget = QComboBox()
                widget.addItem("--")  # 空选项
                widget.addItems(options)
                if default is not None and default in options:
                    widget.setCurrentText(default)
                else:
                    widget.setCurrentIndex(0)  # 选择 "--"
                widget.setToolTip(description)
                widget.setFixedWidth(100)
                widget.setStyleSheet("""
                    QComboBox {
                        background-color: #ffffff;
                        border: 1px solid #cccccc;
                        border-radius: 4px;
                        padding: 4px 8px;
                        font-size: 12px;
                        color: #333333;
                        min-height: 24px;
                    }
                    QComboBox:hover {
                        border-color: #5a9bd5;
                    }
                    QComboBox:focus {
                        border-color: #5a9bd5;
                    }
                    QComboBox::drop-down {
                        border: none;
                        width: 20px;
                    }
                    QComboBox::down-arrow {
                        image: none;
                        border-left: 4px solid transparent;
                        border-right: 4px solid transparent;
                        border-top: 5px solid #666666;
                    }
                    QComboBox QAbstractItemView {
                        background-color: #ffffff;
                        border: 1px solid #cccccc;
                        selection-background-color: #5a9bd5;
                        selection-color: #ffffff;
                    }
                """)
            elif setting_type == "list":
                # 列表类型使用 LineEdit，占2格 - 与窗口风格一致
                widget = QLineEdit()
                if default is not None:
                    widget.setText(str(default))
                widget.setToolTip(description)
                widget.setPlaceholderText(name)
                widget.setMinimumWidth(120)  # 两格宽度
                widget.setStyleSheet("""
                    QLineEdit {
                        background-color: #ffffff;
                        border: 1px solid #cccccc;
                        border-radius: 4px;
                        padding: 4px 8px;
                        font-size: 12px;
                        color: #333333;
                    }
                    QLineEdit:focus {
                        border-color: #5a9bd5;
                    }
                """)
            else:
                # 混合类型使用 LineEdit，占2格 - 与窗口风格一致
                widget = QLineEdit()
                if default is not None:
                    widget.setText(str(default))
                widget.setToolTip(description)
                widget.setPlaceholderText(name)
                widget.setStyleSheet("""
                    QLineEdit {
                        background-color: #ffffff;
                        border: 1px solid #cccccc;
                        border-radius: 4px;
                        padding: 4px 8px;
                        font-size: 12px;
                        color: #333333;
                    }
                    QLineEdit:focus {
                        border-color: #5a9bd5;
                    }
                """)

            # 存储控件
            self._setting_widgets[name] = widget
            hlayout.addWidget(widget)

            # 确定占用的列数：bool/数字/选择占1格，列表/文本占2格
            if setting_type in ("bool", "int", "float", "select"):
                col_span = 1
            else:
                col_span = 2

            # 添加到网格
            grid.addWidget(container, row, col, 1, col_span)

            # 更新列位置
            col += col_span

            # 检查是否需要换行（每行最多5个格子）
            if col >= 5:
                row += 1
                col = 0

        # 添加拉伸因子
        for c in range(5):
            grid.setColumnStretch(c, 1)

        # 只在提供了父布局时才添加（初始创建时）
        if parent_layout:
            parent_layout.addLayout(grid)

        # 加载保存的设置值
        self._load_settings_values()

        return grid

    def _on_pin_toggled(self, checked: bool):
        """置顶按钮切换事件"""
        self._update_window_stay_on_top(checked)

    def _update_window_stay_on_top(self, stay_on_top: bool):
        """更新窗口置顶状态"""
        # 检查当前状态是否已符合要求
        current_stay_on_top = bool(self.windowFlags() & Qt.WindowType.WindowStaysOnTopHint)
        if current_stay_on_top == stay_on_top:
            return

        # 保存窗口状态
        was_visible = self.isVisible()
        pos = self.pos()
        size = self.size()

        # 更新窗口标志
        flags = self.windowFlags()
        if stay_on_top:
            flags |= Qt.WindowType.WindowStaysOnTopHint
        else:
            flags &= ~Qt.WindowType.WindowStaysOnTopHint

        self.setWindowFlags(flags)

        # 恢复窗口状态
        self.resize(size)
        self.move(pos)
        if was_visible:
            self.show()

    def _close_invalid_tabs(self, valid_callbacks: set):
        """
        关闭不属于当前类型的已打开标签页

        Args:
            valid_callbacks: 当前类型有效的回调名称集合
        """
        # 获取所有已打开的标签页
        opened_tabs = list(self._editor._tabs.keys())

        for tab_id in opened_tabs:
            # 跳过固定项（文档、类定义）
            if tab_id in self.FIXED_ITEMS:
                continue

            # 如果标签页不在有效回调列表中，关闭它
            if tab_id not in valid_callbacks:
                # 先保存内容
                text = self._editor.get_tab_text(tab_id)
                self._tab_contents[tab_id] = text

                # 关闭标签页
                self._editor.close_tab(tab_id)

                # 从内容字典中移除（可选：保留数据以防切换回来）
                # 这里选择保留，这样切换回去时内容还在

    def _load_root_data(self):
        """从 ROOT 加载数据"""
        # 加载类名
        self._name_input.setText(self._root_item.name)

        # 加载导入自（如果存在）
        import_from = getattr(self._root_item, 'import_from', 'builtin')
        index = self._import_combo.findText(import_from)
        if index >= 0:
            self._import_combo.setCurrentIndex(index)

        # 加载标签列表
        self._reload_tab_list()

        # 加载内容（从 root_item）
        saved_contents = self._root_item.class_contents
        self._tab_contents = {
            self.TAB_DOC: saved_contents.get(self.TAB_DOC, ""),
            self.TAB_CDEF: saved_contents.get(self.TAB_CDEF, ""),
        }
        # 加载 onXxx 回调内容
        for callback in self._root_item.on_callbacks:
            self._tab_contents[callback] = saved_contents.get(callback, "")

        # 加载设置值
        self._load_settings_values()

        # 默认打开文档标签
        doc_content = self._tab_contents.get(self.TAB_DOC, "")
        self._open_tab(self.TAB_DOC, self.FIXED_ITEMS[self.TAB_DOC], doc_content)

        # 设置上下文代码（包含类定义）
        QTimer.singleShot(100, self._setup_editor_context_code)

    def _load_settings_values(self):
        """从 root_item 加载设置值到控件"""
        if not self._root_item:
            return

        saved_values = self._root_item.class_settings_values
        if not saved_values:
            return


        for name, value in saved_values.items():
            if name not in self._setting_widgets:
                continue

            widget = self._setting_widgets[name]
            try:
                if isinstance(widget, QCheckBox):
                    widget.setChecked(bool(value))
                elif isinstance(widget, QSpinBox):
                    widget.setValue(int(value) if value is not None else 0)
                elif isinstance(widget, QDoubleSpinBox):
                    widget.setValue(float(value) if value is not None else 0.0)
                elif isinstance(widget, QComboBox):
                    if value is None:
                        widget.setCurrentIndex(0)  # "--"
                    else:
                        index = widget.findText(str(value))
                        if index >= 0:
                            widget.setCurrentIndex(index)
                        else:
                            widget.setCurrentIndex(0)
                elif isinstance(widget, QLineEdit):
                    if isinstance(value, list):
                        widget.setText(str(value))
                    else:
                        widget.setText(str(value) if value is not None else "")
            except Exception:
                # 加载失败时保持默认值
                pass

    def _reload_tab_list(self):
        """重新加载标签列表"""
        self._tab_list.clear()

        # 添加固定项
        for tab_id, title in self.FIXED_ITEMS.items():
            item = QListWidgetItem(title)
            item.setData(Qt.ItemDataRole.UserRole, tab_id)
            self._tab_list.addItem(item)

        # 根据当前类型添加 onXxx 回调
        if self._root_item:
            for callback in self._root_item.on_callbacks:
                # onXxx 显示为 🔧onXxx
                title = f"🔧{callback}"
                item = QListWidgetItem(title)
                item.setData(Qt.ItemDataRole.UserRole, callback)
                self._tab_list.addItem(item)

    def _on_list_item_clicked(self, item: QListWidgetItem):
        """列表项点击处理"""
        tab_id = item.data(Qt.ItemDataRole.UserRole)
        title = item.text()

        # 先保存当前打开的标签页内容
        self._save_current_tab_content()

        # 获取或创建内容
        text = self._tab_contents.get(tab_id, "")
        self._open_tab(tab_id, title, text)

    def _save_current_tab_content(self):
        """保存当前打开的标签页内容到 _tab_contents"""
        # 获取当前活动的标签页
        current_tab_id = self._editor.get_current_tab_id()
        if current_tab_id:
            # 获取当前标签页的文本内容
            text = self._editor.get_tab_text(current_tab_id)
            # 保存到 _tab_contents
            self._tab_contents[current_tab_id] = text

    def _open_tab(self, tab_id: str, title: str, text: str):
        """打开标签页"""
        # 使用 VSStyleEditor 打开标签
        self._editor.open_tab(tab_id, title, text)

        # 设置上下文代码（包含实际的类定义）
        # 延迟执行，确保标签页已创建
        QTimer.singleShot(0, self._setup_editor_context_code)

    def _reopen_doc_tab(self):
        """重新打开文档标签"""
        text = self._tab_contents.get(self.TAB_DOC, "")
        self._open_tab(self.TAB_DOC, self.FIXED_ITEMS[self.TAB_DOC], text)

    def _on_tab_save(self, tab_id: str, text: str):
        """标签页保存回调"""
        self._tab_contents[tab_id] = text

        # 如果类定义标签的内容改变，更新所有标签页的上下文代码
        if tab_id == self.TAB_CDEF:
            self._update_all_tabs_context_code()

    def _save_to_root(self):
        """保存所有数据到 ROOT"""
        # 保存所有修改的标签
        self._editor.save_all_modified_tabs()

        # 保存类名
        new_name = self._name_input.text().strip()
        if new_name and self._root_item:
            self._root_item.name = new_name

        # 保存类类型
        if self._root_item:
            new_type = self._type_combo.currentText()
            self._root_item.logic_type = new_type

        # 保存导入自
        if self._root_item:
            new_import = self._import_combo.currentText()
            self._root_item.import_from = new_import

        # 保存所有 _tab_contents 到 root_item
        if self._root_item:
            self._root_item.class_contents = self._tab_contents

        # 保存设置值到 root_item
        if self._root_item and hasattr(self, '_setting_widgets'):
            settings_values = {}
            for name, widget in self._setting_widgets.items():
                # 根据控件类型获取值
                if isinstance(widget, QCheckBox):
                    settings_values[name] = widget.isChecked()
                elif isinstance(widget, QSpinBox):
                    settings_values[name] = widget.value()
                elif isinstance(widget, QDoubleSpinBox):
                    settings_values[name] = widget.value()
                elif isinstance(widget, QComboBox):
                    text = widget.currentText()
                    settings_values[name] = None if text == "--" else text
                elif isinstance(widget, QLineEdit):
                    # 尝试解析为列表
                    text = widget.text().strip()
                    if text.startswith('[') and text.endswith(']'):
                        try:
                            settings_values[name] = ast.literal_eval(text)
                        except:
                            settings_values[name] = text
                    else:
                        settings_values[name] = text
            self._root_item.class_settings_values = settings_values

    def closeEvent(self, event):
        """窗口关闭事件 - 自动保存数据到 ROOT"""
        try:
            # 保存数据到 ROOT
            self._save_to_root()
        except Exception:
            pass  # ROOT 可能已被销毁

        # 通知 ROOT 图元窗口已关闭
        try:
            if self._root_item:
                self._root_item.set_edit_window_open(False)
        except Exception:
            pass  # ROOT 可能已被销毁

        # 从实例字典中移除
        if self._root_item in self._instances:
            del self._instances[self._root_item]

        # 发射关闭信号
        self.closed.emit()

        super().closeEvent(event)

    def _update_title(self):
        """更新窗口标题，根据是否有未保存的修改添加 '*'"""
        has_modified = bool(self._editor._modified_tabs)
        title = f"{self._root_item.name} - Edit{' *' if has_modified else ''}"
        self.setWindowTitle(title)

    def showEvent(self, event):
        """窗口显示事件"""
        super().showEvent(event)
        self.raise_()
        self.activateWindow()
