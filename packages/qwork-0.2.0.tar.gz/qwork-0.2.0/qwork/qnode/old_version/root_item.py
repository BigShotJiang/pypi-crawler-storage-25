"""
ROOT 图元模块 - 特殊的类编辑图元

ROOT 不是节点，不能连线，始终是孤立单元
可以双击打开 ClassEditWindow 进行编辑
"""

from typing import Optional, List, Dict, Any

from PyQt6.QtWidgets import (
    QGraphicsItem, QGraphicsEllipseItem, QGraphicsTextItem,
    QWidget, QLineEdit
)
from PyQt6.QtCore import Qt, QPointF, QRectF, QTimer, pyqtSignal, QObject, QPropertyAnimation, QEasingCurve, pyqtProperty
from PyQt6.QtGui import QBrush, QPen, QColor, QFont, QPainterPath, QLinearGradient

from qwork.qnode.old_version.styles import NodeStyle
from qwork.qnode.old_version.enums import NodeState


class RootSignalHelper(QObject):
    """ROOT 信号助手类 - 用于处理信号发射"""
    edit_requested = pyqtSignal(object)  # 编辑请求信号
    name_changed = pyqtSignal(object, str)  # 名称改变信号


class AnimationHelper(QObject):
    """动画助手类 - QObject 包装器用于 QPropertyAnimation"""
    def __init__(self, parent: Optional[QObject] = None) -> None:
        super().__init__(parent)
        self._opacity = 0.0
        self._callback: Optional[callable] = None

    def get_opacity(self) -> float:
        return self._opacity

    def set_opacity(self, value: float) -> None:
        self._opacity = value
        if self._callback:
            self._callback(value)

    def set_callback(self, callback: callable) -> None:
        """设置透明度变化时的回调函数"""
        self._callback = callback

    opacity = pyqtProperty(float, get_opacity, set_opacity)


class CreepLogicMarker(QObject):
    """
    CreepLogic 类型标记 - 用于在 ROOT 右上角显示 🆑
    只在继承自 CreepLogic 时显示
    """

    def __init__(self, parent: QGraphicsItem = None) -> None:
        super().__init__()

        self._parent = parent
        self._radius: float = 15.0

        # 创建圆形背景
        self._ellipse_item = QGraphicsEllipseItem(parent)
        self._ellipse_item.setBrush(QBrush(QColor(220, 240, 200)))  # 浅黄绿色背景
        self._ellipse_item.setPen(QPen(QColor(100, 150, 80), 2))  # 绿灰色描边
        self._ellipse_item.setZValue(100)  # 确保在最上层
        self._ellipse_item.setAcceptHoverEvents(False)
        self._ellipse_item.setToolTip("CreepLogic 类型")  # 添加 tooltip

        # 创建图标文本（C）
        self._text_item = QGraphicsTextItem("C", parent)
        # 设置文本颜色为 Indian Red
        self._text_item.setDefaultTextColor(QColor("#CD5555"))
        # 设置字体为 Consolas，大小 16，加粗
        font = QFont("Consolas", 16)
        font.setBold(True)
        self._text_item.setFont(font)
        self._text_item.setZValue(101)  # 确保在圆形背景之上
        self._text_item.setAcceptHoverEvents(False)
        self._text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

        # 初始隐藏
        self._opacity: float = 0.0
        self._update_opacity()

        # 设置标记位置（右上角）
        self._update_position()

    def _is_valid(self) -> bool:
        """检查 C++ 对象是否仍然有效"""
        if not hasattr(self, '_ellipse_item') or self._ellipse_item is None:
            return False
        try:
            self._ellipse_item.isVisible()
            return True
        except RuntimeError:
            return False

    def _update_opacity(self) -> None:
        """更新透明度"""
        if not self._is_valid():
            return
        try:
            self._ellipse_item.setOpacity(self._opacity)
            self._text_item.setOpacity(self._opacity)
        except RuntimeError:
            pass

    def get_opacity(self) -> float:
        """获取当前透明度"""
        return self._opacity

    def set_opacity(self, value: float) -> None:
        """设置透明度"""
        self._opacity = value
        self._update_opacity()

    # 创建属性用于动画
    opacity = pyqtProperty(float, get_opacity, set_opacity)

    def _update_position(self) -> None:
        """更新标记位置（ROOT 右上角）"""
        if not self._is_valid():
            return
        if self._parent is None:
            return

        try:
            # 使用固定半径 15
            marker_radius = 15.0

            # RootItem 的中心是 (0, 0) 本地坐标
            # 右上角位置：x = +radius, y = -radius
            offset_x = self._parent._radius - marker_radius
            offset_y = -self._parent._radius + marker_radius

            # 设置圆形背景位置
            ellipse_rect = QRectF(
                offset_x - marker_radius,
                offset_y - marker_radius,
                marker_radius * 2,
                marker_radius * 2
            )
            self._ellipse_item.setRect(ellipse_rect)

            # 设置文本居中
            text_rect = self._text_item.boundingRect()
            text_pos = QPointF(
                offset_x - text_rect.width() / 2,
                offset_y - text_rect.height() / 2
            )
            self._text_item.setPos(text_pos)
        except RuntimeError:
            pass

    def show(self) -> None:
        """显示标记"""
        if self._is_valid():
            self._ellipse_item.show()
            self._text_item.show()

    def hide(self) -> None:
        """隐藏标记"""
        if self._is_valid():
            self._ellipse_item.hide()
            self._text_item.hide()


class RootItem(QGraphicsItem):
    """
    ROOT 图元 - 特殊的类编辑图元

    特点：
    - 不是节点，不能连线
    - 始终是孤立单元
    - 圆环形状，带阴影质感
    - 双击打开 ClassEditWindow
    - 左上角显示编辑状态标记
    """

    def __init__(
        self,
        x: float,
        y: float,
        radius: float,
        name: str = "MyClass",
        style: Optional[NodeStyle] = None
    ) -> None:
        # 初始化图元
        super().__init__()

        # 基础属性
        self._radius = radius
        # 单圆，不是圆环
        self._shadow_offset = 4.0  # 阴影偏移
        self._shadow_blur = 6.0  # 阴影模糊半径
        self._name = name
        self._style = style or NodeStyle()
        self._state = NodeState.IDLE

        # 类类型属性: Logic 或 CreepLogic
        self._logic_type: str = "CreepLogic"  # 默认使用 CreepLogic
        # 导入来源属性: builtin 或 basic
        self._import_from: str = "builtin"  # 默认使用 builtin
        # onXxx 回调列表（只读属性，根据 logic_type 自动更新）
        self._on_callbacks: List[str] = self._get_on_callbacks_for_type(self._logic_type)

        # 类编辑内容存储（类似 Node 的 _connection_texts）
        # 键: __doc__, __cdef__, onXxx 等；值: 文本内容
        self._class_contents: Dict[str, str] = {
            "__doc__": '"""\n这是一个注释\n"""',      # 默认文档
            "__cdef__": "",     # 类定义
        }
        # 类设置值存储
        self._class_settings_values: Dict[str, Any] = {}

        # 使用setPos设置位置
        self.setPos(x, y)

        # 设置可选和可移动
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges, True)
        self.setAcceptHoverEvents(True)

        # 信号助手
        self._signal_helper = RootSignalHelper()

        # 编辑状态
        self._edit_window_open = False
        self._is_marker_visible = False

        # 创建文本项（与 NodeItem 一致的处理）
        self._text_item = QGraphicsTextItem(self._name, self)
        self._text_item.setDefaultTextColor(self._style.text_color)
        self._text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        self._text_item.setAcceptHoverEvents(False)
        self._text_item.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        self._center_text()

        # 创建编辑状态标记（左上角显示）
        self._edit_marker: Optional[QGraphicsEllipseItem] = None
        self._edit_marker_text: Optional[QGraphicsTextItem] = None
        self._edit_marker_animation: Optional[QPropertyAnimation] = None

        # 创建 CreepLogic 类型标记（右上角显示）
        self._cl_marker: Optional[CreepLogicMarker] = None
        self._cl_marker_animation: Optional[QPropertyAnimation] = None
        # 默认显示（因为默认 logic_type 是 CreepLogic）
        self._show_cl_marker()

        # 应用样式
        self._apply_style()

        # 拖拽状态
        self._dragging = False
        self._drag_start_pos: Optional[QPointF] = None
        self._edit_mode = False  # 编辑模式标志

    def boundingRect(self) -> QRectF:
        """返回图元的边界矩形（包含阴影）"""
        # 包含阴影的边界
        margin = self._shadow_blur + self._shadow_offset
        return QRectF(
            -self._radius - margin,
            -self._radius - margin,
            (self._radius + margin) * 2,
            (self._radius + margin) * 2
        )

    def shape(self) -> QPainterPath:
        """返回图元的形状（用于碰撞检测）"""
        # 单圆形状
        path = QPainterPath()
        path.addEllipse(QPointF(0, 0), self._radius, self._radius)
        return path

    def contains(self, point: QPointF) -> bool:
        """检查点是否在外圆内（用于鼠标点击检测，包含内圆区域用于文本编辑）"""
        # 计算点到中心的距离
        distance = (point.x() ** 2 + point.y() ** 2) ** 0.5
        # 接受整个外圆区域（包括内圆），这样文本区域也能接收事件
        return distance <= self._radius

    def paint(self, painter, option, widget=None) -> None:
        """绘制圆环 ROOT 图元，带阴影质感"""
        # 获取颜色
        if self._state == NodeState.IDLE:
            base_color = self._style.idle_fill
            stroke_color = self._style.idle_stroke
        elif self._state == NodeState.HOVER:
            base_color = self._style.idle_fill.lighter(110)
            stroke_color = self._style.idle_stroke.lighter(110)
        elif self._state == NodeState.SELECTED:
            base_color = self._style.idle_fill.lighter(120)
            stroke_color = QColor("#FF8C00")  # 橙色
        else:
            base_color = self._style.idle_fill
            stroke_color = self._style.idle_stroke

        # 1. 绘制阴影（底部偏移的深色圆）
        shadow_color = QColor(0, 0, 0, 60)  # 半透明黑色
        shadow_gradient = QLinearGradient(
            -self._radius, -self._radius + self._shadow_offset,
            self._radius, self._radius + self._shadow_offset
        )
        shadow_gradient.setColorAt(0, QColor(0, 0, 0, 40))
        shadow_gradient.setColorAt(0.5, QColor(0, 0, 0, 60))
        shadow_gradient.setColorAt(1, QColor(0, 0, 0, 80))

        painter.setBrush(QBrush(shadow_gradient))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(
            QPointF(self._shadow_offset, self._shadow_offset),
            self._radius, self._radius
        )

        # 2. 绘制外圆（主圆环的外圈）
        outer_gradient = QLinearGradient(
            -self._radius, -self._radius,
            self._radius, self._radius
        )
        # 顶部亮，底部暗，营造立体感
        light_color = base_color.lighter(130)
        dark_color = base_color.darker(110)
        outer_gradient.setColorAt(0, light_color)
        outer_gradient.setColorAt(0.5, base_color)
        outer_gradient.setColorAt(1, dark_color)

        painter.setBrush(QBrush(outer_gradient))
        painter.setPen(QPen(stroke_color, self._style.stroke_width))
        painter.drawEllipse(QPointF(0, 0), self._radius, self._radius)

        # 4. 绘制高光（顶部边缘的亮点）
        highlight_gradient = QLinearGradient(
            -self._radius * 0.5, -self._radius * 0.8,
            self._radius * 0.5, -self._radius * 0.3
        )
        highlight_gradient.setColorAt(0, QColor(255, 255, 255, 0))
        highlight_gradient.setColorAt(0.5, QColor(255, 255, 255, 40))
        highlight_gradient.setColorAt(1, QColor(255, 255, 255, 0))

        painter.setBrush(QBrush(highlight_gradient))
        painter.setPen(Qt.PenStyle.NoPen)
        # 只在顶部绘制高光弧
        painter.drawEllipse(QPointF(0, -self._radius * 0.1), self._radius * 0.9, self._radius * 0.6)

        # 绘制文本项边框（提示用户不要点击此处）
        self._draw_text_border(painter)

    def _draw_text_border(self, painter) -> None:
        """
        绘制文本项的虚线边框
        提示用户从边缘拖拽创建连线，而不是点击文字
        """
        text_rect = self._text_item.boundingRect()
        text_pos = self._text_item.pos()

        # 文本项的矩形（在节点坐标系中）
        border_rect = QRectF(
            text_pos.x(),
            text_pos.y(),
            text_rect.width(),
            text_rect.height()
        )

        # 浅灰色虚线
        border_color = QColor(200, 200, 200, 60)  # 浅灰色，半透明
        border_pen = QPen(border_color, 1)
        border_pen.setStyle(Qt.PenStyle.DashLine)
        border_pen.setDashPattern([3, 3])  # 3像素实线，3像素空白

        painter.setPen(border_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)  # 不填充

        # 绘制虚线边框
        painter.drawRect(border_rect)

    def mousePressEvent(self, event) -> None:
        """鼠标按下事件"""
        if event.button() == Qt.MouseButton.LeftButton:
            self._dragging = True
            self._drag_start_pos = event.scenePos()
            self.setSelected(True)
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        """鼠标移动事件 - 手动实现拖拽"""
        if self._dragging and self._drag_start_pos is not None:
            # 计算移动增量
            delta = event.scenePos() - self._drag_start_pos
            # 更新位置
            self.setPos(self.pos() + delta)
            # 更新拖拽起始位置
            self._drag_start_pos = event.scenePos()
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        """鼠标释放事件"""
        if event.button() == Qt.MouseButton.LeftButton:
            self._dragging = False
            self._drag_start_pos = None
            event.accept()
        else:
            super().mouseReleaseEvent(event)

    @property
    def name(self) -> str:
        """获取 ROOT 名称"""
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        """设置 ROOT 名称"""
        self.set_name(value)

    @property
    def logic_type(self) -> str:
        """获取类类型 (Logic 或 CreepLogic)"""
        return self._logic_type

    @logic_type.setter
    def logic_type(self, value: str) -> None:
        """
        设置类类型，自动更新 on_callbacks 列表

        Args:
            value: "Logic" 或 "CreepLogic"
        """
        if value not in ("Logic", "CreepLogic"):
            raise ValueError(f"logic_type must be 'Logic' or 'CreepLogic', got '{value}'")

        if self._logic_type != value:
            self._logic_type = value
            # 自动更新 on_callbacks 列表
            self._on_callbacks = self._get_on_callbacks_for_type(value)
            # 更新 CreepLogic 标记显示状态
            if value == "CreepLogic":
                self._show_cl_marker()
            else:
                self._hide_cl_marker()

    @property
    def import_from(self) -> str:
        """获取导入来源 (builtin 或 basic)"""
        return self._import_from

    @import_from.setter
    def import_from(self, value: str) -> None:
        """
        设置导入来源

        Args:
            value: "builtin" 或 "basic"
        """
        if value not in ("builtin", "basic"):
            raise ValueError(f"import_from must be 'builtin' or 'basic', got '{value}'")

        self._import_from = value

    @property
    def on_callbacks(self) -> List[str]:
        """获取当前类型的 onXxx 回调列表（只读）"""
        return self._on_callbacks.copy()  # 返回副本，防止外部修改

    @staticmethod
    def _get_on_callbacks_for_type(logic_type: str) -> List[str]:
        """
        根据类类型获取对应的 onXxx 回调列表

        Args:
            logic_type: "Logic" 或 "CreepLogic"

        Returns:
            onXxx 回调名称列表
        """
        if logic_type == "CreepLogic":
            return ["onLoading", "onStart", "onStep", "onStop", "onDraw", "onKilled"]
        else:  # Logic
            return ["onLoading", "onStart", "onStep", "onStop"]

    @property
    def class_settings(self) -> List[dict]:
        """
        获取当前类型的类级别设置属性列表（除了 NAME）

        Returns:
            设置属性列表，每个属性包含：
            - name: 属性名
            - type: 类型 ('bool', 'int', 'float', 'str', 'list', 'mixed')
            - default: 默认值
            - description: 描述
        """
        return self._get_class_settings_for_type(self._logic_type)

    @staticmethod
    def _get_class_settings_for_type(logic_type: str) -> List[dict]:
        """
        根据类类型获取类级别设置属性

        Args:
            logic_type: "Logic" 或 "CreepLogic"

        Returns:
            设置属性列表
        """
        # Logic 基类的设置（所有类型共享）
        base_settings = [
            {"name": "LOG", "type": "bool", "default": True, "description": "是否输出状态机日志"},
            {"name": "PRIORITY", "type": "int", "default": 0, "description": "逻辑优先级,数值越大优先级越高"},
        ]

        # CreepLogic 特有的设置
        creep_settings = [
            {"name": "DRAW", "type": "bool", "default": False, "description": "是否绘制爬虫信息"},
            {"name": "LAYER", "type": "int", "default": 10, "description": "爬虫绘制图层"},
            {"name": "LINK", "type": "list", "default": [], "description": "爬虫逻辑链接(list或str)"},
            {"name": "ONCE", "type": "bool", "default": True, "description": "是否禁用死亡后重生"},
            {"name": "SPAWNABLE", "type": "bool", "default": True, "description": "是否可以孵化"},
            {"name": "RECIPE", "type": "mixed", "default": "M1", "description": "爬虫配方(list或str)"},
            {"name": "OPTIMISE", "type": "bool", "default": True, "description": "自动优化配方"},
            {"name": "EXTENSION", "type": "bool", "default": True, "description": "使用extension"},
            {"name": "DIRECTION", "type": "select", "options": ["TOP", "TOP_RIGHT", "RIGHT", "BOTTOM_RIGHT", "BOTTOM", "BOTTOM_LEFT", "LEFT", "TOP_LEFT", "--", "IN_DIRECT", "OUT_DIRECT"], "default": None, "description": "出生方向"},
        ]

        if logic_type == "CreepLogic":
            return base_settings + creep_settings
        else:
            return base_settings

    @property
    def class_contents(self) -> Dict[str, str]:
        """
        获取类编辑内容字典

        Returns:
            包含 __doc__, __cdef__, onXxx 等键的内容字典
        """
        return self._class_contents.copy()

    @class_contents.setter
    def class_contents(self, value: Dict[str, str]) -> None:
        """
        设置类编辑内容字典

        Args:
            value: 新的内容字典
        """
        self._class_contents = value.copy()

    def get_class_content(self, key: str) -> str:
        """
        获取指定键的类编辑内容

        Args:
            key: 内容键（如 __doc__, __cdef__, onXxx 等）

        Returns:
            内容文本，不存在则返回空字符串
        """
        return self._class_contents.get(key, "")

    def set_class_content(self, key: str, content: str) -> None:
        """
        设置指定键的类编辑内容

        Args:
            key: 内容键（如 __doc__, __cdef__, onXxx 等）
            content: 内容文本
        """
        self._class_contents[key] = content

    @property
    def class_settings_values(self) -> Dict[str, Any]:
        """
        获取类设置值字典

        Returns:
            设置名称到设置值的映射字典
        """
        return self._class_settings_values.copy()

    @class_settings_values.setter
    def class_settings_values(self, value: Dict[str, Any]) -> None:
        """
        设置类设置值字典

        Args:
            value: 新的设置值字典
        """
        self._class_settings_values = value.copy()

    def get_setting_value(self, name: str) -> Any:
        """
        获取指定设置的值

        Args:
            name: 设置名称

        Returns:
            设置值，不存在则返回 None
        """
        return self._class_settings_values.get(name)

    def set_setting_value(self, name: str, value: Any) -> None:
        """
        设置指定设置的值

        Args:
            name: 设置名称
            value: 设置值
        """
        self._class_settings_values[name] = value

    # ==================== AI API 方法 ====================

    def to_dict(self) -> dict:
        """
        将类转换为字典

        Returns:
            包含类所有数据的字典
        """
        # 获取所有默认设置值
        all_settings = {}
        for setting in self.class_settings:
            name = setting["name"]
            # 优先使用用户设置的值，否则使用默认值
            if name in self._class_settings_values:
                value = self._class_settings_values[name]
            else:
                value = setting["default"]

            # 过滤掉不可序列化的值（如函数、lambda等）
            if not callable(value) and not isinstance(value, (type, type(lambda: None))):
                all_settings[name] = value

        # 确保 class_contents 包含所有标准字段（即使为空）
        class_contents = self._class_contents.copy()

        # 确保 __doc__ 和 __cdef__ 存在
        if "__doc__" not in class_contents:
            class_contents["__doc__"] = ""
        if "__cdef__" not in class_contents:
            class_contents["__cdef__"] = ""

        # 确保所有 onXxx 回调字段存在（即使为空）
        for callback in self._on_callbacks:
            if callback not in class_contents:
                class_contents[callback] = ""

        return {
            "name": self._name,
            "position": {"x": self.pos().x(), "y": self.pos().y()},
            "logic_type": self._logic_type,
            "import_from": self._import_from,
            "class_contents": class_contents,
            "class_settings_values": all_settings
        }

    def from_dict(self, data: dict) -> None:
        """
        从字典更新类数据

        Args:
            data: 类数据字典，可以只包含要修改的部分

        Example:
            root.from_dict({"name": "NewClass"})  # 只改类名
            root.from_dict({"logic_type": "Logic"})  # 只改类型
            root.from_dict({"class_contents": {"__cdef__": "FLAG = get.flag()"}})  # 合并内容
            root.from_dict({"class_settings_values": {"RECIPE": "W2W2"}})  # 合并设置
        """
        # 更新名称
        if "name" in data:
            self.set_name(data["name"])

        # 更新位置
        if "position" in data:
            pos = data["position"]
            self.setPos(QPointF(pos.get("x", 0), pos.get("y", 0)))

        # 更新逻辑类型
        if "logic_type" in data:
            self.set_logic_type(data["logic_type"])

        # 更新导入来源（如果存在，否则使用默认值 builtin）
        if "import_from" in data:
            self.import_from = data["import_from"]

        # 更新类内容（合并）
        if "class_contents" in data:
            self._class_contents.update(data["class_contents"])

        # 更新类设置（合并）
        if "class_settings_values" in data:
            self._class_settings_values.update(data["class_settings_values"])

    def get_name(self) -> str:
        """获取类名"""
        return self._name

    def set_name(self, name: str) -> None:
        """设置类名"""
        self._name = name
        if self._text_item:
            self._text_item.setPlainText(name)
            # 强制文本项重新计算大小
            self._text_item.adjustSize()

            # 根据文本宽度调整 ROOT 大小
            self._radius = self._calculate_radius()

            # 更新形状和边界
            self.prepareGeometryChange()

        self._center_text()

        # 更新 CreepLogic 标记位置（因为半径可能改变）
        if self._cl_marker:
            self._update_cl_marker_position()

        self._signal_helper.name_changed.emit(self, name)
        self.update()  # 触发重绘

    def _calculate_radius(self) -> float:
        """根据文本内容计算合适的半径"""
        if not self._text_item:
            return 40.0  # 默认半径

        text_rect = self._text_item.boundingRect()
        # 半径需要覆盖文本宽度的一半加上边距
        # 文本在圆内水平居中，所以半径 >= 文本宽度/2 + 边距
        min_radius_from_width = text_rect.width() / 2 + 15  # 15px 边距

        # 高度方向也要考虑
        min_radius_from_height = text_rect.height() / 2 + 10

        # 取较大值，但最小 40，最大 200
        radius = max(40.0, min_radius_from_width, min_radius_from_height)
        radius = min(200.0, radius)

        return radius

    def get_position(self) -> dict:
        """获取位置"""
        return {"x": self.pos().x(), "y": self.pos().y()}

    def set_position(self, x: float, y: float) -> None:
        """设置位置"""
        self.setPos(QPointF(x, y))

    def get_logic_type(self) -> str:
        """获取逻辑类型"""
        return self._logic_type

    def set_logic_type(self, logic_type: str) -> None:
        """设置逻辑类型"""
        self._logic_type = logic_type
        self._on_callbacks = self._get_on_callbacks_for_type(logic_type)

    def get_class_contents(self) -> dict:
        """获取类内容字典"""
        return self._class_contents.copy()

    def set_class_contents(self, contents: dict) -> None:
        """设置类内容字典（合并）"""
        self._class_contents.update(contents)

    def get_class_settings_values(self) -> dict:
        """获取类设置值字典"""
        return self._class_settings_values.copy()

    def set_class_settings_values(self, settings: dict) -> None:
        """设置类设置值字典（合并）"""
        self._class_settings_values.update(settings)

    def generate_class_header(self) -> str:
        """
        生成类头部代码（类定义、文档、NAME、RECIPE、类变量等）

        Returns:
            类头部代码字符串，用于代码生成和编辑器上下文
        """
        lines = []

        # 类定义
        lines.append(f"class {self._name}({self._logic_type}):")

        # 文档字符串 (紧跟类定义之后)
        doc_code = self._class_contents.get("__doc__", "").strip()
        if doc_code:
            for line in doc_code.split("\n"):
                lines.append(f"    {line}")
            lines.append("")

        # NAME
        lines.append(f"    NAME = '{self._name}'")

        # RECIPE（从设置中获取）
        recipe = self._class_settings_values.get("RECIPE", "M2W2")
        lines.append(f"    RECIPE = '{recipe}'")

        # 类变量定义（__cdef__）
        cdef = self._class_contents.get("__cdef__", "")
        if cdef.strip():
            lines.append("")
            lines.append("    # 类属性定义")
            for line in cdef.strip().split("\n"):
                # 确保每行都有正确的缩进（4空格）
                stripped_line = line.lstrip()
                if stripped_line:  # 非空行
                    lines.append(f"    {stripped_line}")

        # 空行分隔
        lines.append("")

        return "\n".join(lines)

    def generate_method_stub(self, method_name: str, include_body: bool = False, body_code: str = "") -> str:
        """
        生成方法存根代码

        Args:
            method_name: 方法名
            include_body: 是否包含函数体
            body_code: 函数体代码（如果 include_body 为 True）

        Returns:
            方法存根代码字符串
        """
        lines = []

        # 方法定义
        lines.append(f"    def {method_name}(self, c: Creep, k: GlobalKnowledge, *refs):")

        if include_body and body_code:
            # 添加函数体（需要缩进）
            for line in body_code.strip().split("\n"):
                lines.append(f"        {line}")
        else:
            # 空函数体，只有占位符
            lines.append("        <__begin__>")

        return "\n".join(lines)

    def generate_full_class(self, node_methods: list = None) -> str:
        """
        生成完整类代码

        Args:
            node_methods: 节点方法代码列表，每个元素是一个字符串

        Returns:
            完整类代码字符串
        """
        import_source = self._import_from  # 使用设置的导入来源

        lines = [
            "# Generated Python Code from Node Canvas",
            "# ====================================",
            "",
            f"from {import_source} import *",
            ""
        ]

        # 类头部（包含文档字符串）
        lines.append(self.generate_class_header())

        # 先收集有内容的回调
        callbacks_with_content = []
        for callback_name in self._on_callbacks:
            callback_code = self._class_contents.get(callback_name, "").strip()
            if callback_code:
                callbacks_with_content.append((callback_name, callback_code))

        # 只有有内容的回调才输出区域
        if callbacks_with_content:
            lines.append("    # ==================== Class Callbacks ====================")
            lines.append("")

            for callback_name, callback_code in callbacks_with_content:
                # onLoading 和 onKilled 的 c 参数类型是 Creep | None
                if callback_name in ("onLoading", "onKilled"):
                    lines.append(f"    def {callback_name}(self, c: Creep | None, k: GlobalKnowledge, *refs):")
                else:
                    lines.append(f"    def {callback_name}(self, c: Creep, k: GlobalKnowledge, *refs):")
                lines.append(f"        # $Begin:{callback_name}")
                for line in callback_code.split("\n"):
                    lines.append(f"        {line}")
                lines.append(f"        # $End:{callback_name}")
                lines.append("")

        # 节点函数区域标记
        lines.append("    # ==================== Node Functions ====================")
        lines.append("")

        # 添加节点方法
        if node_methods:
            for method_code in node_methods:
                lines.append(method_code)
                lines.append("")

        return "\n".join(lines)

    @property
    def center(self) -> QPointF:
        """获取中心点"""
        return self.sceneBoundingRect().center()

    def _center_text(self) -> None:
        """将文本居中于椭圆"""
        if not self._text_item:
            return
        text_rect = self._text_item.boundingRect()
        # 文本位置相对于父项
        text_x = -text_rect.width() / 2
        text_y = -text_rect.height() / 2
        self._text_item.setPos(text_x, text_y)

    def _apply_style(self) -> None:
        """应用样式到图元 - 触发重绘"""
        self.update()  # 触发 paint 方法重绘

    def set_edit_window_open(self, open: bool) -> None:
        """设置编辑窗口是否打开，控制左上角标记的显示"""
        self._edit_window_open = open
        if open:
            self._show_edit_marker()
        else:
            self._hide_edit_marker()

    def _show_edit_marker(self) -> None:
        """显示编辑标记（左上角）"""
        if self._is_marker_visible:
            return

        self._is_marker_visible = True

        # 创建标记
        if self._edit_marker is None:
            self._edit_marker = QGraphicsEllipseItem(self)
            self._edit_marker.setBrush(QBrush(QColor(240, 230, 200)))  # 浅黄灰色（与Node一致）
            self._edit_marker.setPen(QPen(QColor(180, 130, 80), 2))  # 橙灰色描边（与Node一致）
            self._edit_marker.setZValue(100)
            self._edit_marker.setToolTip("编辑窗口已打开")  # 添加 tooltip

            self._edit_marker_text = QGraphicsTextItem("📖", self._edit_marker)  # 书本图标（与Node一致）
            self._edit_marker_text.setZValue(101)
            self._edit_marker_text.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

            # 创建动画助手和动画
            self._animation_helper = AnimationHelper()
            self._animation_helper.set_callback(self._set_marker_opacity)
            self._edit_marker_animation = QPropertyAnimation(self._animation_helper, b"opacity")
            self._edit_marker_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

        # 更新位置
        self._update_edit_marker_position()

        # 显示并播放淡入动画
        try:
            if self._edit_marker:
                self._edit_marker.show()
            if self._edit_marker_text:
                self._edit_marker_text.show()

            self._edit_marker_animation.stop()
            self._edit_marker_animation.setDuration(200)
            self._edit_marker_animation.setStartValue(0.0)
            self._edit_marker_animation.setEndValue(1.0)
            self._edit_marker_animation.start()
        except RuntimeError:
            pass

    def _is_edit_marker_valid(self) -> bool:
        """检查编辑标记的 C++ 对象是否仍然有效"""
        if not self._edit_marker:
            return False
        try:
            self._edit_marker.isVisible()
            return True
        except RuntimeError:
            return False

    def _hide_edit_marker(self) -> None:
        """隐藏编辑标记"""
        if not self._is_marker_visible or not self._is_edit_marker_valid():
            return

        try:
            # 淡出动画
            self._edit_marker_animation.stop()
            self._edit_marker_animation.setDuration(100)
            self._edit_marker_animation.setStartValue(self._edit_marker.opacity())
            self._edit_marker_animation.setEndValue(0.0)
            self._edit_marker_animation.finished.connect(self._on_hide_marker_finished)
            self._edit_marker_animation.start()
        except RuntimeError:
            pass

    def _on_hide_marker_finished(self) -> None:
        """隐藏动画完成回调"""
        try:
            self._edit_marker_animation.finished.disconnect(self._on_hide_marker_finished)
        except Exception:
            pass
        if not self._edit_window_open and self._is_edit_marker_valid():
            try:
                self._edit_marker.hide()
            except RuntimeError:
                pass
        self._is_marker_visible = False

    def _update_edit_marker_position(self) -> None:
        """更新编辑标记位置（左上角）"""
        if not self._is_edit_marker_valid():
            return

        try:
            # 使用 _radius 计算位置
            radius = 0.15 * self._radius * 2  # 标记半径

            # 左上角位置
            offset_x = -self._radius + radius
            offset_y = -self._radius + radius

            marker_rect = QRectF(
                offset_x - radius,
                offset_y - radius,
                radius * 2,
                radius * 2
            )
            self._edit_marker.setRect(marker_rect)

            # 文本居中
            if self._edit_marker_text is not None:
                text_rect = self._edit_marker_text.boundingRect()
                self._edit_marker_text.setPos(
                    offset_x - text_rect.width() / 2,
                    offset_y - text_rect.height() / 2
                )
        except RuntimeError:
            pass

    def _set_marker_opacity(self, value: float) -> None:
        """设置标记透明度（动画回调）"""
        if not self._edit_marker:
            return
        try:
            # 检查 C++ 对象是否已被删除
            self._edit_marker.isVisible()
            self._edit_marker.setOpacity(value)
            if self._edit_marker_text:
                self._edit_marker_text.setOpacity(value)
        except RuntimeError:
            # C++ 对象已被删除
            pass

    # ==================== CreepLogic 标记方法 ====================

    def _show_cl_marker(self) -> None:
        """显示 CreepLogic 标记（右上角）"""
        # 创建标记（如果不存在）
        if self._cl_marker is None:
            self._cl_marker = CreepLogicMarker(self)
            self._cl_marker_animation = QPropertyAnimation(self._cl_marker, b"opacity")
            self._cl_marker_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

        # 更新位置
        self._cl_marker._update_position()

        # 显示并播放淡入动画
        try:
            self._cl_marker.show()
            self._cl_marker_animation.stop()
            self._cl_marker_animation.setDuration(200)
            self._cl_marker_animation.setStartValue(self._cl_marker.get_opacity())
            self._cl_marker_animation.setEndValue(1.0)
            self._cl_marker_animation.start()
        except RuntimeError:
            pass

    def _hide_cl_marker(self) -> None:
        """隐藏 CreepLogic 标记"""
        if self._cl_marker is None:
            return

        try:
            # 淡出动画
            self._cl_marker_animation.stop()
            self._cl_marker_animation.setDuration(100)
            self._cl_marker_animation.setStartValue(self._cl_marker.get_opacity())
            self._cl_marker_animation.setEndValue(0.0)
            self._cl_marker_animation.finished.connect(self._on_hide_cl_marker_finished)
            self._cl_marker_animation.start()
        except RuntimeError:
            pass

    def _on_hide_cl_marker_finished(self) -> None:
        """隐藏 CreepLogic 标记动画完成回调"""
        try:
            self._cl_marker_animation.finished.disconnect(self._on_hide_cl_marker_finished)
        except Exception:
            pass
        if self._cl_marker and self._logic_type != "CreepLogic":
            try:
                self._cl_marker.hide()
            except RuntimeError:
                pass

    def _update_cl_marker_position(self) -> None:
        """更新 CreepLogic 标记位置"""
        if self._cl_marker:
            self._cl_marker._update_position()

    # ==================== 事件处理 ====================

    def hoverEnterEvent(self, event) -> None:
        """鼠标进入事件"""
        if self._state != NodeState.SELECTED:
            self._state = NodeState.HOVER
            self._apply_style()
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event) -> None:
        """鼠标离开事件"""
        if self._state != NodeState.SELECTED:
            self._state = NodeState.IDLE
            self._apply_style()
        super().hoverLeaveEvent(event)

    def mouseDoubleClickEvent(self, event) -> None:
        """双击事件 - 打开编辑窗口"""
        if event.button() == Qt.MouseButton.LeftButton:
            # 双击文本区域编辑名称，否则打开编辑窗口
            text_rect = self._text_item.boundingRect()
            text_pos = self._text_item.pos()
            click_pos = event.pos()

            is_on_text = (
                text_pos.x() <= click_pos.x() <= text_pos.x() + text_rect.width() and
                text_pos.y() <= click_pos.y() <= text_pos.y() + text_rect.height()
            )

            if is_on_text:
                self._start_name_editing()
            else:
                self._signal_helper.edit_requested.emit(self)

        super().mouseDoubleClickEvent(event)

    def _start_name_editing(self) -> None:
        """开始编辑名称 - 创建LineEdit覆盖在文本上"""
        if self._edit_mode:
            return

        if not self.scene() or not self.scene().views():
            return

        self._edit_mode = True
        self._edit_view = self.scene().views()[0]  # 保存视图引用，用于位置更新

        # 隐藏文本项
        self._text_item.hide()

        # 创建LineEdit
        self._line_edit = QLineEdit()
        self._line_edit.setText(self._name)
        self._line_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._line_edit.setStyleSheet("""
            QLineEdit {
                background-color: transparent;
                border: none;
                color: #333333;
            }
        """)

        # 设置字体
        font = QFont()
        font.setPointSize(10)
        self._line_edit.setFont(font)

        # 计算LineEdit大小（与文本项相同）
        text_rect = self._text_item.boundingRect()
        self._line_edit.setFixedSize(int(text_rect.width()) + 20, int(text_rect.height()) + 10)

        # 添加到视图
        self._line_edit.setParent(self._edit_view.viewport())

        # 更新LineEdit位置（居中放置，使用节点中心）
        self._update_line_edit_position()

        self._line_edit.show()
        self._line_edit.setFocus()
        self._line_edit.selectAll()

        # 连接编辑完成信号
        self._line_edit.editingFinished.connect(self._finish_name_editing)

    def _start_editing(self) -> None:
        """开始编辑名称（与 _start_name_editing 相同，用于统一接口）"""
        self._start_name_editing()

    def _update_line_edit_position(self) -> None:
        """更新LineEdit位置（当节点移动时调用）"""
        if not hasattr(self, '_line_edit') or not hasattr(self, '_edit_view'):
            return

        # 居中放置 - 使用节点中心（RootItem 的中心是 (0,0) 本地坐标）
        center_view_pos = self._edit_view.mapFromScene(self.mapToScene(QPointF(0, 0)))
        self._line_edit.move(
            center_view_pos.x() - self._line_edit.width() // 2,
            center_view_pos.y() - self._line_edit.height() // 2
        )

    def _finish_name_editing(self) -> None:
        """完成名称编辑"""
        if hasattr(self, '_line_edit'):
            new_name = self._line_edit.text().strip()
            if new_name and new_name != self._name:
                self.name = new_name

            self._line_edit.deleteLater()
            delattr(self, '_line_edit')

        # 清理视图引用
        if hasattr(self, '_edit_view'):
            delattr(self, '_edit_view')

        # 显示文本项
        self._text_item.show()
        self._edit_mode = False

    def itemChange(self, change: QGraphicsItem.GraphicsItemChange, value):
        """项状态改变事件"""
        if change == QGraphicsItem.GraphicsItemChange.ItemSelectedChange:
            if value:
                self._state = NodeState.SELECTED
            else:
                self._state = NodeState.IDLE
            self._apply_style()
        elif change == QGraphicsItem.GraphicsItemChange.ItemPositionHasChanged:
            # 位置改变时更新编辑标记位置
            if self._edit_marker:
                self._update_edit_marker_position()
            # 位置改变时更新 CreepLogic 标记位置
            if self._cl_marker:
                self._update_cl_marker_position()
            # 位置改变时更新LineEdit位置（如果在编辑中）
            if self._edit_mode:
                self._update_line_edit_position()

        return super().itemChange(change, value)
