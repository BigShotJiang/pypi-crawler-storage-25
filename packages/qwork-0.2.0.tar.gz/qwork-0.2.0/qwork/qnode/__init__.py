"""
qnode - A generic node graph canvas library based on PyQt6

This library provides a generic node graph canvas widget that can be used
for various node-based visual editing applications.

Usage:
    from qnode import NodeCanvas, NodeItem, ConnectionItem
    
    canvas = NodeCanvas()
    node1 = canvas.addNode("Start", QPointF(0, 0))
    node2 = canvas.addNode("End", QPointF(200, 0))
    canvas.addConnection(node1, node2)
"""

from qwork.qnode.enums import NodeState, NodeShape, ArrowState, ConnectionType
from qwork.qnode.styles import NodeStyle, ConnectionStyle, ArrowStyle
from qwork.qnode.node_item import NodeItem
from qwork.qnode.connection_item import ConnectionItem
from qwork.qnode.arrow_item import ArrowItem
from qwork.qnode.selection_rect import SelectionRect
from qwork.qnode.style_panel import StylePanel
from qwork.qnode.node_canvas import NodeCanvas
from qwork.qnode.main_window import NodeCanvasWindow
from qwork.qnode.qnode_editor import QNodeEditor

__version__ = "1.0.0"
__author__ = "qnode"

__all__ = [
    # Enums
    "NodeState",
    "NodeShape", 
    "ArrowState",
    "ConnectionType",
    # Styles
    "NodeStyle",
    "ConnectionStyle",
    "ArrowStyle",
    # Items
    "NodeItem",
    "ConnectionItem",
    "ArrowItem",
    "SelectionRect",
    # UI Components
    "StylePanel",
    # Canvas and Window
    "NodeCanvas",
    "NodeCanvasWindow",
    # Editor
    "QNodeEditor",
]
