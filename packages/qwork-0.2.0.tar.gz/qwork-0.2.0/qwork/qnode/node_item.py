"""
节点项模块 - 表示节点图中的一个节点
支持圆形、矩形、菱形三种形状
"""

from qwork.qnode.connection_item import ConnectionItem


import math
from typing import Optional, Dict, Any

from PyQt6.QtWidgets import (
    QGraphicsItem, QGraphicsEllipseItem, QGraphicsRectItem,
    QGraphicsTextItem, QGraphicsPathItem, QWidget
)
from PyQt6.QtCore import Qt, QPointF, QRectF, QTimer, pyqtSignal, QObject, QPropertyAnimation, QEasingCurve, pyqtProperty
from PyQt6.QtGui import QBrush, QPen, QColor, QFont, QPainterPath

from qwork.qnode.styles import NodeStyle
from qwork.qnode.enums import NodeState, NodeShape


# 常量定义
MIN_RADIUS = 40.0
PADDING = 15.0
TEXT_EDIT_PADDING = 4.0
BUTTON_RADIUS_RATIO = 0.2
ANIMATION_DURATION_SHOW = 200
ANIMATION_DURATION_HIDE = 100
Z_VALUE_NODE = 50
Z_VALUE_BUTTON = 100
Z_VALUE_MARKER = 100


class HoverButton(QObject):
    """
    悬浮按钮 - 用于节点编辑的浮动按钮
    包含圆形背景和编辑图标
    """
    clicked = pyqtSignal()  # 点击信号
    
    def __init__(self, parent: QGraphicsItem = None) -> None:
        super().__init__()
        
        self._parent = parent
        self._radius: float = 15.0

        # 创建圆形背景（浅黄灰色）
        self._ellipse_item = QGraphicsEllipseItem(parent)
        self._ellipse_item.setBrush(QBrush(QColor(240, 230, 200)))  # 浅黄灰色
        self._ellipse_item.setPen(QPen(QColor(180, 130, 80), 2))  # 橙灰色描边，2像素宽
        self._ellipse_item.setZValue(Z_VALUE_BUTTON)  # 确保在最上层
        self._ellipse_item.setAcceptHoverEvents(True)
        self._ellipse_item.setToolTip("编辑窗口已打开")  # 添加 tooltip

        # 创建编辑图标文本（书本图标）
        self._text_item = QGraphicsTextItem("📖", parent)
        self._text_item.setZValue(Z_VALUE_BUTTON + 1)  # 确保在圆形背景之上
        self._text_item.setAcceptHoverEvents(False)
        self._text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

        # 初始隐藏（只有当编辑窗口打开时才显示）
        self._opacity: float = 0.0
        self._updateOpacity()
        
        # 设置按钮位置（左上角）
        self._updatePosition()

    def _updateOpacity(self) -> None:
        """更新透明度"""
        if not hasattr(self, '_ellipse_item') or self._ellipse_item is None:
            return
        try:
            self._ellipse_item.setOpacity(self._opacity)
            self._text_item.setOpacity(self._opacity)
        except RuntimeError:
            pass

    def getOpacity(self) -> float:
        """获取当前透明度"""
        return self._opacity

    def setOpacity(self, value: float) -> None:
        """设置透明度"""
        self._opacity = value
        self._updateOpacity()

    # 创建属性用于动画
    opacity = pyqtProperty(float, getOpacity, setOpacity)

    def _isValid(self) -> bool:
        """检查 C++ 对象是否仍然有效"""
        if not hasattr(self, '_ellipse_item') or self._ellipse_item is None:
            return False
        try:
            self._ellipse_item.isVisible()
            return True
        except RuntimeError:
            return False

    def _updatePosition(self) -> None:
        """更新按钮位置（节点左上角）"""
        if not self._isValid():
            return
        if self._parent is None:
            return

        try:
            parent_rect = self._parent.rect()
            center = parent_rect.center()

            # 计算节点左上角的偏移位置
            offset_x = -parent_rect.width() / 2 + self._radius
            offset_y = -parent_rect.height() / 2 + self._radius

            # 设置圆形背景位置
            ellipse_rect = QRectF(
                center.x() + offset_x - self._radius,
                center.y() + offset_y - self._radius,
                self._radius * 2,
                self._radius * 2
            )
            self._ellipse_item.setRect(ellipse_rect)

            # 设置文本居中
            text_rect = self._text_item.boundingRect()
            text_pos = QPointF(
                center.x() + offset_x - text_rect.width() / 2,
                center.y() + offset_y - text_rect.height() / 2
            )
            self._text_item.setPos(text_pos)
        except RuntimeError:
            pass
    
    def setRadius(self, radius: float) -> None:
        """设置按钮半径"""
        self._radius = radius
        self._updatePosition()
    
    def show(self) -> None:
        """显示按钮（带动画）"""
        if not self._isValid():
            return
        try:
            self._updatePosition()
            self._ellipse_item.show()
            self._text_item.show()
        except RuntimeError:
            pass

    def hide(self) -> None:
        """隐藏按钮"""
        if not self._isValid():
            return
        try:
            self._ellipse_item.hide()
            self._text_item.hide()
        except RuntimeError:
            pass

    def contains(self, pos: QPointF) -> bool:
        """检查点是否在按钮内"""
        if not self._isValid():
            return False
        try:
            return self._ellipse_item.contains(pos) or self._text_item.contains(pos)
        except RuntimeError:
            return False

    def mousePressEvent(self, event) -> bool:
        """处理鼠标按下事件"""
        if not self._isValid():
            return False
        try:
            local_pos = self._ellipse_item.mapFromScene(event.scenePos())
            if self._ellipse_item.contains(local_pos):
                self.clicked.emit()
                return True

            text_local_pos = self._text_item.mapFromScene(event.scenePos())
            if self._text_item.contains(text_local_pos):
                self.clicked.emit()
                return True
        except RuntimeError:
            pass

        return False


class StartMarker(QObject):
    """
    起点标记 - 用于在节点右上角显示起点状态
    包含圆形背景和🔷图标
    """

    def __init__(self, parent: QGraphicsItem = None) -> None:
        super().__init__()

        self._parent = parent
        self._radius: float = 15.0

        # 创建圆形背景
        self._ellipse_item = QGraphicsEllipseItem(parent)
        self._ellipse_item.setBrush(QBrush(QColor(200, 240, 220)))  # 浅绿色背景
        self._ellipse_item.setPen(QPen(QColor(80, 150, 100), 2))  # 绿灰色描边，2像素宽
        self._ellipse_item.setZValue(Z_VALUE_MARKER)  # 确保在最上层
        self._ellipse_item.setAcceptHoverEvents(False)
        self._ellipse_item.setToolTip("起点节点")  # 添加 tooltip

        # 创建图标文本（🔷）
        self._text_item = QGraphicsTextItem("🔷", parent)
        self._text_item.setZValue(Z_VALUE_MARKER + 1)  # 确保在圆形背景之上
        self._text_item.setAcceptHoverEvents(False)
        self._text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

        # 初始隐藏
        self._opacity: float = 0.0
        self._updateOpacity()

        # 设置按钮位置（右上角）
        self._updatePosition()

    def _isValid(self) -> bool:
        """检查 C++ 对象是否仍然有效"""
        if not hasattr(self, '_ellipse_item') or self._ellipse_item is None:
            return False
        try:
            self._ellipse_item.isVisible()
            return True
        except RuntimeError:
            return False

    def _updateOpacity(self) -> None:
        """更新透明度"""
        if not self._isValid():
            return
        try:
            self._ellipse_item.setOpacity(self._opacity)
            self._text_item.setOpacity(self._opacity)
        except RuntimeError:
            pass

    def getOpacity(self) -> float:
        """获取当前透明度"""
        return self._opacity

    def setOpacity(self, value: float) -> None:
        """设置透明度"""
        self._opacity = value
        self._updateOpacity()

    # 创建属性用于动画
    opacity = pyqtProperty(float, getOpacity, setOpacity)

    def _updatePosition(self) -> None:
        """更新标记位置（节点右上角）"""
        if not self._isValid():
            return
        if self._parent is None:
            return

        try:
            parent_rect = self._parent.rect()
            center = parent_rect.center()

            # 计算节点右上角的偏移位置
            offset_x = parent_rect.width() / 2 - self._radius
            offset_y = -parent_rect.height() / 2 + self._radius

            # 设置圆形背景位置
            ellipse_rect = QRectF(
                center.x() + offset_x - self._radius,
                center.y() + offset_y - self._radius,
                self._radius * 2,
                self._radius * 2
            )
            self._ellipse_item.setRect(ellipse_rect)

            # 设置文本居中
            text_rect = self._text_item.boundingRect()
            text_pos = QPointF(
                center.x() + offset_x - text_rect.width() / 2,
                center.y() + offset_y - text_rect.height() / 2
            )
            self._text_item.setPos(text_pos)
        except RuntimeError:
            pass

    def setRadius(self, radius: float) -> None:
        """设置标记半径"""
        self._radius = radius
        self._updatePosition()

    def show(self) -> None:
        """显示标记（带动画）"""
        if not self._isValid():
            return
        try:
            self._updatePosition()
            self._ellipse_item.show()
            self._text_item.show()
        except RuntimeError:
            pass

    def hide(self) -> None:
        """隐藏标记"""
        if not self._isValid():
            return
        try:
            self._ellipse_item.hide()
            self._text_item.hide()
        except RuntimeError:
            pass


class NodeSignalHelper(QObject):
    """
    信号辅助类 - 用于为NodeItem提供信号支持
    因为QGraphicsEllipseItem继承自QGraphicsItem而不是QObject，
    所以需要通过组合方式来提供信号功能
    """
    editRequested = pyqtSignal(object)  # 编辑请求信号，参数为节点自身
    nameChanged = pyqtSignal(object, str)  # 名称改变信号，参数为节点自身和新名称

    def __init__(self, parent: 'NodeItem') -> None:
        super().__init__()
        self._parent = parent


class NodeItem(QGraphicsEllipseItem):
    """
    节点项 - 表示节点图中的一个节点
    支持圆形、矩形、菱形三种形状
    """

    def __init__(
        self,
        name: str,
        position: QPointF = QPointF(0, 0),
        shape: NodeShape = NodeShape.ELLIPSE,
        parent: Optional[QGraphicsItem] = None
    ) -> None:
        """
        初始化节点

        Args:
            name: 节点名称
            position: 节点位置
            shape: 节点形状
            parent: 父项
        """
        # 先设置基本属性
        self._name: str = name
        self._shape: NodeShape = shape
        self._style: NodeStyle = NodeStyle()
        self._state: NodeState = NodeState.IDLE
        self._min_radius: float = MIN_RADIUS
        self._padding: float = PADDING
        
        # 计算半径
        self._radius: float = self._calculateRadius()

        # 初始化QGraphicsEllipseItem（矩形以(0,0)为中心）
        super().__init__(-self._radius, -self._radius, self._radius * 2, self._radius * 2, parent)

        # 使用setPos设置位置（节点的中心点）
        self.setPos(position)

        # 设置节点的Z值，确保在连线上方（连线Z=1，箭头Z=10）
        self.setZValue(Z_VALUE_NODE)

        # 创建信号辅助对象
        self._signal_helper = NodeSignalHelper(self)

        # 创建文本项
        self._text_item: QGraphicsTextItem = QGraphicsTextItem(self._name, self)
        self._text_item.setDefaultTextColor(self._style.text_color)
        # 禁用文本项的所有鼠标事件处理，让事件完全传递给父节点
        self._text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        self._text_item.setAcceptHoverEvents(False)
        self._text_item.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        self._centerText()

        # 设置可选项标志
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges, True)
        self.setAcceptHoverEvents(True)

        # 创建悬浮按钮（左上角的编辑按钮）
        self._hover_button: HoverButton = HoverButton(self)
        self._hover_button.clicked.connect(self._onHoverButtonClicked)

        # 创建起点标记（右上角的🔷标记）
        self._start_marker: Optional[StartMarker] = None
        self._is_start_marker_visible: bool = False
        self._start_marker_animation: Optional[QPropertyAnimation] = None

        # 创建 single 标记（左下角的⚡标记）
        self._single_marker: Optional[SingleMarker] = None
        self._is_single_marker_visible: bool = False
        self._single_marker_animation: Optional[QPropertyAnimation] = None

        # 创建 custom 标记（右下角的自定义标记）
        self._custom_marker: Optional[CustomMarker] = None
        self._is_custom_marker_visible: bool = False
        self._custom_marker_animation: Optional[QPropertyAnimation] = None

        # 悬浮状态追踪
        self._is_button_visible: bool = False
        self._edit_window_open: bool = False  # 编辑窗口是否打开

        # 创建透明度动画
        self._opacity_animation: QPropertyAnimation = QPropertyAnimation(self._hover_button, b"opacity")
        self._opacity_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

        # 数据存储（只读属性，用户可以自由添加数据）
        self._data: Dict[str, Any] = {}

        # 编辑器类（用户自定义编辑器）
        self._editor_class: Optional[type] = None

        # 名称编辑状态
        self._is_editing_name: bool = False

        # 更名区域（浅浅浅灰色虚线框）
        self._name_edit_area: QRectF = self._calculateNameEditArea()

        # 自定义样式属性（用于导出/导入和面板控制）
        self._custom_fill_color: Optional[QColor] = None
        self._custom_stroke_color: Optional[QColor] = None
        self._custom_stroke_width: Optional[float] = None
        self._custom_font_family: Optional[str] = None
        self._custom_font_size: Optional[int] = None
        self._custom_radius: Optional[float] = None

        # 装饰器类型
        self._decorator: Optional[str] = None

        # 应用样式
        self._applyStyle()

    @property
    def editRequested(self):
        """编辑请求信号"""
        return self._signal_helper.editRequested

    @property
    def nameChanged(self):
        """名称改变信号"""
        return self._signal_helper.nameChanged
    
    @property
    def data(self) -> Dict[str, Any]:
        """获取节点的数据字典（只读属性，但字典内容可修改）"""
        return self._data
    
    @property
    def editorClass(self) -> Optional[type]:
        """获取节点编辑器类"""
        return self._editor_class
    
    @editorClass.setter
    def editorClass(self, value: Optional[type]) -> None:
        """设置节点编辑器类"""
        self._editor_class = value

    @property
    def decorator(self) -> Optional[str]:
        """获取节点装饰器类型"""
        return self._decorator

    @decorator.setter
    def decorator(self, value: Optional[str]) -> None:
        """设置节点装饰器类型

        Args:
            value: 装饰器类型，支持 'recursive', 'behavior', 'sequence', 'selector', 'parallel'
        """
        self._decorator = value
        self.update()  # 重绘节点以应用新的边框颜色

    def _getDecoratorStrokeColor(self) -> Optional[QColor]:
        """根据装饰器类型获取边框颜色

        Returns:
            装饰器对应的边框颜色，如果没有装饰器则返回 None
        """
        if self._decorator is None:
            return None

        decorator = self._decorator.lower()

        # recursive -> 紫罗兰色 (violet)
        if decorator == 'recursive':
            return QColor(238, 130, 238)  # Violet

        # behavior, sequence, selector, parallel -> 皇家蓝色 (royal blue)
        if decorator in ('behavior', 'sequence', 'selector', 'parallel'):
            return QColor(65, 105, 225)  # Royal Blue

        return None

    def _calculateRadius(self) -> float:
        """根据文本计算节点半径"""
        temp_text = QGraphicsTextItem(self._name)
        text_rect = temp_text.boundingRect()
        
        # 取宽高的较大值，加上padding，确保圆形能容纳文本
        text_size = max(text_rect.width(), text_rect.height())
        radius = (text_size / 2) + self._padding
        
        return max(radius, self._min_radius)
    
    def _centerText(self) -> None:
        """将文本居中到节点"""
        if not self._text_item:
            return
        text_rect = self._text_item.boundingRect()
        center = self.rect().center()

        self._text_item.setPos(
            center.x() - text_rect.width() / 2,
            center.y() - text_rect.height() / 2
        )

        # 更新更名区域位置
        self._name_edit_area = self._calculateNameEditArea()

    def _calculateNameEditArea(self) -> QRectF:
        """计算名称编辑区域（文本周围的虚线框区域）"""
        text_rect = self._text_item.boundingRect()
        text_pos = self._text_item.pos()
        # 左右1px内边距，上下0px（文本本身已有足够空白）
        hpad = 1.0
        vpad = 0.0
        return QRectF(
            text_pos.x() + text_rect.x() - hpad,
            text_pos.y() + text_rect.y() - vpad,
            text_rect.width() + hpad * 2,
            text_rect.height() + vpad * 2
        )

    def _applyStyle(self) -> None:
        """应用当前状态的样式"""
        # 基础填充色
        base_color = self._style.idle_fill

        if self._state == NodeState.IDLE:
            fill_color = base_color
            stroke_color = self._style.idle_stroke
        elif self._state == NodeState.HOVER:
            fill_color = self._blendColors(base_color, self._style.hover_overlay)
            stroke_color = self._style.idle_stroke
        elif self._state == NodeState.SELECTED:
            fill_color = self._blendColors(base_color, self._style.selected_overlay)
            stroke_color = self._style.selected_stroke
        else:
            fill_color = base_color
            stroke_color = self._style.idle_stroke

        self.setBrush(QBrush(fill_color))
        self.setPen(QPen(stroke_color, self._style.stroke_width))

    def setColor(self, color: QColor) -> None:
        """
        设置节点的主颜色（填充色）

        Args:
            color: 主颜色
        """
        self._custom_fill_color = color
        self._style.idle_fill = color
        self._applyStyle()

    def setBorder(self, width: int = 1, color: QColor = None) -> None:
        """
        设置节点的边框宽度和颜色

        Args:
            width: 边框宽度，<=0 表示无边框
            color: 边框颜色，None 表示使用默认颜色
        """
        if width <= 0:
            self.setPen(QPen(Qt.PenStyle.NoPen))
            self._custom_stroke_width = 0
        else:
            self._custom_stroke_width = width
            self._style.stroke_width = width
            if color is not None:
                self._custom_stroke_color = color
                self._style.idle_stroke = color
                self._style.selected_stroke = color
            self._applyStyle()

    def setFont(self, family: str = None, size: int = None) -> None:
        """
        设置节点文本的字体

        Args:
            family: 字体家族，None 表示不改变
            size: 字体大小，None 表示不改变
        """
        font = self._text_item.font()
        if family is not None:
            self._custom_font_family = family
            font.setFamily(family)
        if size is not None and size > 0:
            self._custom_font_size = size
            font.setPointSize(size)
        self._text_item.setFont(font)

        # 始终重新居中文字，确保位置正确
        self._centerText()

        # 重新计算大小以适应新字体（如果没有自定义半径）
        if not hasattr(self, '_custom_radius') or not self._custom_radius:
            new_radius = self._calculateRadius()
            if new_radius != self._radius:
                self._radius = new_radius
                rect = self.rect()
                center = rect.center()
                new_rect = QRectF(
                    center.x() - self._radius,
                    center.y() - self._radius,
                    self._radius * 2,
                    self._radius * 2
                )
                self.setRect(new_rect)
                self._centerText()
                if self._start_marker is not None:
                    self._start_marker._updatePosition()

    def setRadius(self, radius: float) -> None:
        """
        设置节点半径（大小）

        Args:
            radius: 新的半径值
        """
        if radius < MIN_RADIUS:
            radius = MIN_RADIUS
        self._custom_radius = radius
        self._radius = radius
        rect = self.rect()
        center = rect.center()
        new_rect = QRectF(
            center.x() - self._radius,
            center.y() - self._radius,
            self._radius * 2,
            self._radius * 2
        )
        self.setRect(new_rect)
        self._centerText()
        if self._start_marker is not None:
            self._start_marker._updatePosition()

    @property
    def fontFamily(self) -> str:
        """获取当前字体家族"""
        return self._text_item.font().family()

    @property
    def fontSize(self) -> int:
        """获取当前字体大小"""
        return self._text_item.font().pointSize()

    @property
    def strokeWidth(self) -> float:
        """获取当前边框宽度"""
        return self._style.stroke_width

    @property
    def fillColor(self) -> QColor:
        """获取当前填充颜色"""
        return self._style.idle_fill

    @property
    def strokeColor(self) -> QColor:
        """获取当前边框颜色"""
        return self._style.idle_stroke
    
    def _blendColors(self, base: QColor, overlay: QColor, overlay_alpha: float = 0.5) -> QColor:
        """混合两种颜色"""
        result = QColor(overlay)
        result.setAlpha(int(overlay_alpha * 255))
        
        # 简单的颜色混合
        r = int(base.red() * (1 - overlay_alpha) + overlay.red() * overlay_alpha)
        g = int(base.green() * (1 - overlay_alpha) + overlay.green() * overlay_alpha)
        b = int(base.blue() * (1 - overlay_alpha) + overlay.blue() * overlay_alpha)
        
        return QColor(r, g, b)
    
    def setEditWindowOpen(self, open: bool) -> None:
        """设置编辑窗口是否打开，控制悬浮按钮的显示（带动画）"""
        self._edit_window_open = open
        if open:
            self._showHoverButtonImmediately()
        else:
            self._hideHoverButton()

    def _showHoverButtonImmediately(self) -> None:
        """显示悬浮按钮（带淡入动画）- 当编辑窗口打开时调用"""
        if not self._edit_window_open:
            return

        # 计算按钮半径
        rect = self.rect()
        button_radius = BUTTON_RADIUS_RATIO * min(rect.width(), rect.height())
        self._hover_button.setRadius(button_radius)

        self._hover_button.show()
        self._is_button_visible = True

        # 淡入动画
        self._opacity_animation.stop()
        self._opacity_animation.setDuration(ANIMATION_DURATION_SHOW)
        self._opacity_animation.setStartValue(self._hover_button.getOpacity())
        self._opacity_animation.setEndValue(1.0)
        self._opacity_animation.start()
    
    def _hideHoverButton(self) -> None:
        """隐藏悬浮按钮（带淡出动画）"""
        if not self._is_button_visible:
            return
        
        # 淡出动画
        self._opacity_animation.stop()
        self._opacity_animation.setDuration(ANIMATION_DURATION_HIDE)
        self._opacity_animation.setStartValue(self._hover_button.getOpacity())
        self._opacity_animation.setEndValue(0.0)
        self._opacity_animation.finished.connect(self._onHideAnimationFinished)
        self._opacity_animation.start()
    
    def _onHideAnimationFinished(self) -> None:
        """隐藏动画完成回调"""
        self._opacity_animation.finished.disconnect(self._onHideAnimationFinished)
        if not self._edit_window_open:
            self._hover_button.hide()
            self._is_button_visible = False
    
    def _onHoverButtonClicked(self) -> None:
        """悬浮按钮点击回调"""
        self._signal_helper.editRequested.emit(self)

    def setStartMarkerVisible(self, visible: bool) -> None:
        """设置起点标记的显示状态"""
        if visible == self._is_start_marker_visible:
            return

        self._is_start_marker_visible = visible

        if visible:
            # 创建起点标记
            if self._start_marker is None:
                self._start_marker = StartMarker(self)
                self._start_marker_animation = QPropertyAnimation(self._start_marker, b"opacity")
                self._start_marker_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

            # 显示动画
            self._start_marker.show()
            self._start_marker_animation.stop()
            self._start_marker_animation.setDuration(ANIMATION_DURATION_SHOW)
            self._start_marker_animation.setStartValue(self._start_marker.getOpacity())
            self._start_marker_animation.setEndValue(1.0)
            self._start_marker_animation.start()
        else:
            # 隐藏动画
            if self._start_marker is not None:
                self._start_marker_animation.stop()
                self._start_marker_animation.setDuration(ANIMATION_DURATION_HIDE)
                self._start_marker_animation.setStartValue(self._start_marker.getOpacity())
                self._start_marker_animation.setEndValue(0.0)
                self._start_marker_animation.finished.connect(self._onStartMarkerHideFinished)
                self._start_marker_animation.start()

    def _onStartMarkerHideFinished(self) -> None:
        """起点标记隐藏动画完成回调"""
        self._start_marker_animation.finished.disconnect(self._onStartMarkerHideFinished)
        if not self._is_start_marker_visible and self._start_marker is not None:
            self._start_marker.hide()

    def setSingleMarkerVisible(self, visible: bool) -> None:
        """设置 single 标记的显示状态"""
        if visible == self._is_single_marker_visible:
            return

        self._is_single_marker_visible = visible

        if visible:
            # 创建 single 标记
            if self._single_marker is None:
                self._single_marker = SingleMarker(self)
                self._single_marker_animation = QPropertyAnimation(self._single_marker, b"opacity")
                self._single_marker_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

            # 显示动画
            self._single_marker.show()
            self._single_marker_animation.stop()
            self._single_marker_animation.setDuration(ANIMATION_DURATION_SHOW)
            self._single_marker_animation.setStartValue(self._single_marker.getOpacity())
            self._single_marker_animation.setEndValue(1.0)
            self._single_marker_animation.start()
        else:
            # 隐藏动画
            if self._single_marker is not None:
                self._single_marker_animation.stop()
                self._single_marker_animation.setDuration(ANIMATION_DURATION_HIDE)
                self._single_marker_animation.setStartValue(self._single_marker.getOpacity())
                self._single_marker_animation.setEndValue(0.0)
                self._single_marker_animation.finished.connect(self._onSingleMarkerHideFinished)
                self._single_marker_animation.start()

    def _onSingleMarkerHideFinished(self) -> None:
        """single 标记隐藏动画完成回调"""
        self._single_marker_animation.finished.disconnect(self._onSingleMarkerHideFinished)
        if not self._is_single_marker_visible and self._single_marker is not None:
            self._single_marker.hide()

    def setCustomMarkerVisible(self, visible: bool) -> None:
        """设置 custom 标记的显示状态"""
        if visible == self._is_custom_marker_visible:
            return

        self._is_custom_marker_visible = visible

        if visible:
            # 创建 custom 标记
            if self._custom_marker is None:
                self._custom_marker = CustomMarker(self)
                self._custom_marker_animation = QPropertyAnimation(self._custom_marker, b"opacity")
                self._custom_marker_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

            # 显示动画
            self._custom_marker.show()
            self._custom_marker_animation.stop()
            self._custom_marker_animation.setDuration(ANIMATION_DURATION_SHOW)
            self._custom_marker_animation.setStartValue(self._custom_marker.getOpacity())
            self._custom_marker_animation.setEndValue(1.0)
            self._custom_marker_animation.start()
        else:
            # 隐藏动画
            if self._custom_marker is not None:
                self._custom_marker_animation.stop()
                self._custom_marker_animation.setDuration(ANIMATION_DURATION_HIDE)
                self._custom_marker_animation.setStartValue(self._custom_marker.getOpacity())
                self._custom_marker_animation.setEndValue(0.0)
                self._custom_marker_animation.finished.connect(self._onCustomMarkerHideFinished)
                self._custom_marker_animation.start()

    def _onCustomMarkerHideFinished(self) -> None:
        """custom 标记隐藏动画完成回调"""
        self._custom_marker_animation.finished.disconnect(self._onCustomMarkerHideFinished)
        if not self._is_custom_marker_visible and self._custom_marker is not None:
            self._custom_marker.hide()

    def setCustomMarkerStyle(
        self,
        text: str = None,
        bg_color: QColor = None,
        fg_color: QColor = None,
        border_color: QColor = None,
        border_width: float = None,
        radius: float = None
    ) -> None:
        """
        设置 custom 标记的样式

        Args:
            text: 显示字符
            bg_color: 背景色
            fg_color: 前景色（文本颜色）
            border_color: 边框颜色
            border_width: 边框厚度
            radius: 标记半径
        """
        # 如果标记不存在，先创建它
        if self._custom_marker is None:
            self._custom_marker = CustomMarker(self)
            self._custom_marker_animation = QPropertyAnimation(self._custom_marker, b"opacity")
            self._custom_marker_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

        self._custom_marker.setStyle(
            text=text,
            bg_color=bg_color,
            fg_color=fg_color,
            border_color=border_color,
            border_width=border_width,
            radius=radius
        )

    def getCustomMarkerStyle(self) -> dict:
        """
        获取 custom 标记的当前样式配置

        Returns:
            包含样式的字典，如果标记未创建则返回空字典
        """
        if self._custom_marker is None:
            return {}
        return self._custom_marker.getStyle()

    @property
    def name(self) -> str:
        """获取节点名称"""
        return self._name
    
    @name.setter
    def name(self, value: str) -> None:
        """设置节点名称"""
        old_name = self._name
        self._name = value
        self._text_item.setPlainText(value)

        # 发射名称改变信号
        if old_name != value:
            self._signal_helper.nameChanged.emit(self, value)

        # 重新计算半径
        new_radius = self._calculateRadius()
        if new_radius != self._radius:
            self._radius = new_radius
            rect = self.rect()
            center = rect.center()
            new_rect = QRectF(
                center.x() - self._radius,
                center.y() - self._radius,
                self._radius * 2,
                self._radius * 2
            )
            self.setRect(new_rect)
            self._centerText()
            # 更新起点标记位置（如果存在）
            if self._start_marker is not None:
                self._start_marker._updatePosition()
            # 更新所有连线
            self._updateConnections()
        else:
            self._centerText()
    
    @property
    def nodeShape(self) -> NodeShape:
        """获取节点形状"""
        return self._shape
    
    @nodeShape.setter
    def nodeShape(self, value: NodeShape) -> None:
        """设置节点形状"""
        if self._shape != value:
            self._shape = value
            self.update()
    
    @property
    def radius(self) -> float:
        """获取节点半径"""
        return self._radius

    @radius.setter
    def radius(self, value: float) -> None:
        """设置节点半径"""
        self._radius = value
        # 更新矩形大小
        rect = self.rect()
        center = rect.center()
        new_rect = QRectF(
            center.x() - self._radius,
            center.y() - self._radius,
            self._radius * 2,
            self._radius * 2
        )
        self.setRect(new_rect)
        self._centerText()
        # 更新标记位置（如果存在）
        if self._start_marker is not None:
            self._start_marker._updatePosition()
        if self._single_marker is not None:
            self._single_marker._updatePosition()
        if self._custom_marker is not None:
            self._custom_marker._updatePosition()

    @property
    def center(self) -> QPointF:
        """获取节点中心点"""
        return self.sceneBoundingRect().center()
    
    @property
    def state(self) -> NodeState:
        """获取节点状态"""
        return self._state
    
    @state.setter
    def state(self, value: NodeState) -> None:
        """设置节点状态"""
        if self._state != value:
            self._state = value
            self._applyStyle()

    def getEdgePoint(self, target_pos: QPointF) -> QPointF:
        """
        计算从节点中心到目标方向的边缘点
        根据节点形状不同，计算方式不同

        Args:
            target_pos: 目标位置

        Returns:
            边缘点坐标
        """
        center = self.sceneBoundingRect().center()

        if self._shape == NodeShape.ELLIPSE:
            # 圆形：使用角度计算边缘点
            dx = target_pos.x() - center.x()
            dy = target_pos.y() - center.y()
            angle = math.atan2(dy, dx)

            return QPointF(
                center.x() + self._radius * math.cos(angle),
                center.y() + self._radius * math.sin(angle)
            )

        elif self._shape == NodeShape.RECTANGLE:
            # 圆角矩形处理 - 参考老版本实现
            rect = self.rect()
            local_target = self.mapFromScene(target_pos)
            local_center = rect.center()

            dx = local_target.x() - local_center.x()
            dy = local_target.y() - local_center.y()

            if abs(dx) < 1e-6 and abs(dy) < 1e-6:
                return center

            half_w = rect.width() / 2
            half_h = rect.height() / 2
            corner_radius = min(half_w, half_h) * 0.2

            # 计算与外层矩形的交点
            t_x = half_w / abs(dx) if abs(dx) > 1e-6 else float('inf')
            t_y = half_h / abs(dy) if abs(dy) > 1e-6 else float('inf')
            t_rect = min(t_x, t_y)

            # 矩形交点（本地坐标）
            ix = local_center.x() + dx * t_rect
            iy = local_center.y() + dy * t_rect

            # 内矩形边界（不含圆角的区域）
            inner_w = half_w - corner_radius
            inner_h = half_h - corner_radius

            # 检查是否在圆角区域（同时超出内矩形的x和y边界）
            in_corner = abs(ix - local_center.x()) > inner_w and abs(iy - local_center.y()) > inner_h

            if not in_corner:
                # 在直线边上，直接返回矩形交点
                return self.mapToScene(QPointF(ix, iy))

            # 在圆角区域，计算与圆的精确交点
            sign_x = 1 if dx > 0 else -1
            sign_y = 1 if dy > 0 else -1

            # 圆角圆心（本地坐标）
            cx = local_center.x() + sign_x * inner_w
            cy = local_center.y() + sign_y * inner_h

            # 解二次方程：|t*V - (C - O)|^2 = r^2
            a = dx * dx + dy * dy
            b = -2 * (dx * (cx - local_center.x()) + dy * (cy - local_center.y()))
            c = (cx - local_center.x()) ** 2 + (cy - local_center.y()) ** 2 - corner_radius ** 2

            discriminant = b * b - 4 * a * c

            if discriminant < 0:
                return self.mapToScene(QPointF(ix, iy))

            sqrt_d = math.sqrt(discriminant)
            t1 = (-b - sqrt_d) / (2 * a)
            t2 = (-b + sqrt_d) / (2 * a)

            # 边界限制
            min_x = local_center.x() - half_w
            max_x = local_center.x() + half_w
            min_y = local_center.y() - half_h
            max_y = local_center.y() + half_h

            valid_ts = []
            for t in [t1, t2]:
                if t > 1e-6:
                    px = local_center.x() + dx * t
                    py = local_center.y() + dy * t

                    # 检查是否在正确的象限
                    in_quad_x = (sign_x > 0 and px >= cx) or (sign_x < 0 and px <= cx)
                    in_quad_y = (sign_y > 0 and py >= cy) or (sign_y < 0 and py <= cy)
                    in_bounds = (min_x <= px <= max_x) and (min_y <= py <= max_y)

                    if in_quad_x and in_quad_y and in_bounds:
                        valid_ts.append(t)

            if not valid_ts:
                return self.mapToScene(QPointF(ix, iy))

            # 取较近的有效交点
            t_arc = min(valid_ts)
            local_edge_x = local_center.x() + dx * t_arc
            local_edge_y = local_center.y() + dy * t_arc

            return self.mapToScene(QPointF(local_edge_x, local_edge_y))

        elif self._shape == NodeShape.DIAMOND:
            # 菱形：计算与菱形边界的交点
            dx = target_pos.x() - center.x()
            dy = target_pos.y() - center.y()

            if dx == 0 and dy == 0:
                return center

            # 菱形由四个顶点组成，使用参数方程计算交点
            abs_dx = abs(dx)
            abs_dy = abs(dy)

            if abs_dx + abs_dy == 0:
                return center

            scale = self._radius / (abs_dx + abs_dy)

            return QPointF(
                center.x() + dx * scale,
                center.y() + dy * scale
            )

        return center

    def hoverEnterEvent(self, event) -> None:
        """鼠标进入事件"""
        if self._state != NodeState.SELECTED:
            self._state = NodeState.HOVER
            self._applyStyle()

        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event) -> None:
        """鼠标离开事件"""
        if self._state != NodeState.SELECTED:
            self._state = NodeState.IDLE
            self._applyStyle()

        super().hoverLeaveEvent(event)
    
    def mousePressEvent(self, event) -> None:
        """鼠标按下事件"""
        # 检查是否点击了悬浮按钮
        if self._is_button_visible and self._hover_button.mousePressEvent(event):
            return

        # 检查是否点击了名称编辑区域（开始编辑名称）
        if event.button() == Qt.MouseButton.LeftButton:
            # 将场景坐标转换为本地坐标
            local_pos = self.mapFromScene(event.scenePos())
            if self._name_edit_area.contains(local_pos):
                self._startNameEdit()
                return

        super().mousePressEvent(event)
    
    def _startNameEdit(self) -> None:
        """开始编辑节点名称 - 使用QGraphicsTextItem原生编辑，完全贴合文本"""
        if self._is_editing_name:
            return

        self._is_editing_name = True

        # 启用文本项的编辑功能（原位编辑，完全贴合文本）
        self._text_item.setTextInteractionFlags(Qt.TextInteractionFlag.TextEditorInteraction)
        self._text_item.setFocus()

        # 选中全部文本
        cursor = self._text_item.textCursor()
        cursor.select(cursor.SelectionType.Document)
        self._text_item.setTextCursor(cursor)

    def _finishNameEdit(self) -> None:
        """完成名称编辑"""
        if not self._is_editing_name:
            return

        # 获取新名称（从文本项）
        new_name = self._text_item.toPlainText().strip()

        # 禁用文本项的编辑功能
        self._text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

        # 更新名称（这会重新居中并更新虚线框）
        if new_name and new_name != self._name:
            self.name = new_name

        self._is_editing_name = False

    @property
    def isEditingName(self) -> bool:
        """是否正在编辑名称"""
        return self._is_editing_name
    
    def itemChange(self, change: QGraphicsItem.GraphicsItemChange, value):
        """项状态改变事件"""
        if change == QGraphicsItem.GraphicsItemChange.ItemSelectedChange:
            if value:
                self._state = NodeState.SELECTED
            else:
                self._state = NodeState.IDLE
            self._applyStyle()
        elif change == QGraphicsItem.GraphicsItemChange.ItemPositionHasChanged:
            # 位置已改变，更新连接
            if self.scene():
                self._updateConnections()
        
        return super().itemChange(change, value)
    
    def _updateConnections(self) -> None:
        """更新与此节点相关的所有连接"""
        if not self.scene():
            return

        for item in self.scene().items():
            if isinstance(item, ConnectionItem):
                if item.sourceNode == self or item.targetNode == self:
                    item.updatePath()
    
    def toDict(self) -> dict:
        """
        将节点转换为字典

        Returns:
            包含节点所有数据的字典
        """
        result = {
            "id": id(self),
            "name": self._name,
            "shape": self._shape.name,
            "position": {"x": self.pos().x(), "y": self.pos().y()},
            "data": self._data.copy(),
        }

        # 添加样式信息（如果有自定义样式）
        style_data = {}
        if hasattr(self, '_custom_fill_color') and self._custom_fill_color:
            style_data["fill_color"] = self._custom_fill_color.name()
        if hasattr(self, '_custom_stroke_color') and self._custom_stroke_color:
            style_data["stroke_color"] = self._custom_stroke_color.name()
        if hasattr(self, '_custom_stroke_width') and self._custom_stroke_width is not None:
            style_data["stroke_width"] = self._custom_stroke_width
        if hasattr(self, '_custom_font_family') and self._custom_font_family:
            style_data["font_family"] = self._custom_font_family
        if hasattr(self, '_custom_font_size') and self._custom_font_size:
            style_data["font_size"] = self._custom_font_size
        if hasattr(self, '_custom_radius') and self._custom_radius:
            style_data["radius"] = self._custom_radius

        if style_data:
            result["style"] = style_data

        # 添加 custom 标记配置（如果有）
        if self._custom_marker is not None:
            result["custom"] = self._custom_marker.getStyle()

        return result

    def fromDict(self, data: dict) -> None:
        """
        从字典更新节点数据

        Args:
            data: 节点数据字典
        """
        # 更新名称
        if "name" in data:
            self.name = data["name"]

        # 更新形状
        if "shape" in data:
            try:
                self._shape = NodeShape[data["shape"]]
            except KeyError:
                pass

        # 更新位置
        if "position" in data:
            pos = data["position"]
            self.setPos(QPointF(pos.get("x", 0), pos.get("y", 0)))

        # 更新数据
        if "data" in data:
            self._data.update(data["data"])

        # 加载样式
        if "style" in data:
            style = data["style"]
            if "fill_color" in style:
                self._custom_fill_color = QColor(style["fill_color"])
                self._style.idle_fill = self._custom_fill_color
            if "stroke_color" in style:
                self._custom_stroke_color = QColor(style["stroke_color"])
                self._style.idle_stroke = self._custom_stroke_color
                self._style.selected_stroke = self._custom_stroke_color
            if "stroke_width" in style:
                self._custom_stroke_width = style["stroke_width"]
                self._style.stroke_width = self._custom_stroke_width
            if "font_family" in style:
                self._custom_font_family = style["font_family"]
                font = self._text_item.font()
                font.setFamily(self._custom_font_family)
                self._text_item.setFont(font)
            if "font_size" in style:
                self._custom_font_size = style["font_size"]
                font = self._text_item.font()
                font.setPointSize(self._custom_font_size)
                self._text_item.setFont(font)
            if "radius" in style:
                self._custom_radius = style["radius"]
                self._radius = self._custom_radius
                rect = self.rect()
                center = rect.center()
                new_rect = QRectF(
                    center.x() - self._radius,
                    center.y() - self._radius,
                    self._radius * 2,
                    self._radius * 2
                )
                self.setRect(new_rect)
                self._centerText()
            self._applyStyle()

        # 加载 custom 标记配置（可选）
        if "custom" in data:
            custom_data = data["custom"]
            if isinstance(custom_data, dict):
                # 创建并配置 custom 标记
                if self._custom_marker is None:
                    self._custom_marker = CustomMarker(self)
                    self._custom_marker_animation = QPropertyAnimation(self._custom_marker, b"opacity")
                    self._custom_marker_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

                # 解析颜色值
                def parseColor(value):
                    if isinstance(value, str):
                        return QColor(value)
                    return None

                self._custom_marker.setStyle(
                    text=custom_data.get("text"),
                    bg_color=parseColor(custom_data.get("bg_color")),
                    fg_color=parseColor(custom_data.get("fg_color")),
                    border_color=parseColor(custom_data.get("border_color")),
                    border_width=custom_data.get("border_width"),
                    radius=custom_data.get("radius")
                )

                # 如果标记设置为可见，显示它
                # 注意：这里不自动显示，由调用者通过 setCustomMarkerVisible 控制

    def paint(self, painter, option, widget=None) -> None:
        """绘制节点，根据形状绘制圆形、矩形或菱形"""
        # 获取当前样式
        base_color = self._style.idle_fill

        # 获取装饰器边框颜色（如果有）
        decorator_color = self._getDecoratorStrokeColor()

        if self._state == NodeState.IDLE:
            fill_color = base_color
            stroke_color = decorator_color if decorator_color else self._style.idle_stroke
        elif self._state == NodeState.HOVER:
            fill_color = self._blendColors(base_color, self._style.hover_overlay)
            stroke_color = decorator_color if decorator_color else self._style.idle_stroke
        elif self._state == NodeState.SELECTED:
            fill_color = self._blendColors(base_color, self._style.selected_overlay)
            # 选中状态下，如果节点有装饰器，稍微加亮装饰器颜色
            if decorator_color:
                # 混合装饰器颜色和选中颜色
                stroke_color = self._blendColors(decorator_color, self._style.selected_stroke, 0.3)
            else:
                stroke_color = self._style.selected_stroke
        else:
            fill_color = base_color
            stroke_color = decorator_color if decorator_color else self._style.idle_stroke

        painter.setBrush(QBrush(fill_color))
        painter.setPen(QPen(stroke_color, self._style.stroke_width))

        rect = self.rect()

        # 根据形状绘制
        if self._shape == NodeShape.ELLIPSE:
            painter.drawEllipse(rect)
        elif self._shape == NodeShape.RECTANGLE:
            corner_radius = min(rect.width(), rect.height()) * 0.2
            painter.drawRoundedRect(rect, corner_radius, corner_radius)
        else:  # DIAMOND
            # 绘制菱形
            center = rect.center()
            path = QPainterPath()
            path.moveTo(center.x(), rect.top())
            path.lineTo(rect.right(), center.y())
            path.lineTo(center.x(), rect.bottom())
            path.lineTo(rect.left(), center.y())
            path.closeSubpath()
            painter.drawPath(path)

        # 绘制可连线边缘区域的视觉指示
        self._draw_edge_indicator(painter)

        # 绘制名称编辑区域的虚线框（浅浅浅灰色）
        self._draw_name_edit_area(painter)

    def _draw_name_edit_area(self, painter) -> None:
        """
        绘制名称编辑区域的虚线框
        使用浅浅浅灰色虚线框包围文本区域，提示用户可以点击更名
        """
        if self._is_editing_name:
            return  # 编辑时不显示虚线框

        # 浅浅浅灰色虚线（带透明度）
        dash_pen = QPen(QColor(220, 220, 220, 120), 1)  # 浅浅浅灰色，半透明
        dash_pen.setStyle(Qt.PenStyle.DashLine)
        painter.setPen(dash_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)

        # 绘制虚线矩形（使用本地坐标）
        painter.drawRect(self._name_edit_area)

    def _draw_edge_indicator(self, painter) -> None:
        """
        绘制可连线边缘区域的视觉指示
        在节点边缘显示一个浅灰色的环，指示用户可以从此处拖拽创建连线
        """
        # 边缘区域的起始比例（与 node_canvas.py 中 _is_on_node_edge 一致）
        inner_ratio = 0.75  # 边缘区域起始位置（半径的75%处）

        # 非常浅的灰色，半透明
        indicator_color = QColor(200, 200, 200, 60)  # 浅灰色，半透明
        indicator_pen = QPen(indicator_color, 1)
        indicator_pen.setStyle(Qt.PenStyle.SolidLine)
        painter.setPen(indicator_pen)
        painter.setBrush(QBrush(indicator_color))

        rect = self.rect()

        if self._shape == NodeShape.ELLIPSE:
            # 圆形：绘制一个圆环（填充的椭圆减去内部）
            center = rect.center()
            outer_radius = self._radius
            inner_radius = self._radius * inner_ratio

            # 创建圆环路径（外圆减去内圆）
            path = QPainterPath()
            path.addEllipse(center, outer_radius, outer_radius)
            path.addEllipse(center, inner_radius, inner_radius)
            painter.drawPath(path)
        elif self._shape == NodeShape.RECTANGLE:
            # 矩形：绘制圆角矩形环
            corner_radius = min(rect.width(), rect.height()) * 0.2

            # 内矩形（不包含边缘环的区域）
            margin = (1 - inner_ratio) * min(rect.width(), rect.height()) / 2
            inner_rect = rect.adjusted(margin, margin, -margin, -margin)

            # 创建矩形环路径（外矩形减去内矩形）
            path = QPainterPath()
            path.addRoundedRect(rect, corner_radius, corner_radius)
            inner_corner = max(0, corner_radius - margin)
            path.addRoundedRect(inner_rect, inner_corner, inner_corner)
            painter.drawPath(path)
        else:  # DIAMOND
            # 菱形：绘制菱形环
            center = rect.center()
            margin = (1 - inner_ratio) * min(rect.width(), rect.height()) / 2

            # 外菱形
            outer_path = QPainterPath()
            outer_path.moveTo(center.x(), rect.top())
            outer_path.lineTo(rect.right(), center.y())
            outer_path.lineTo(center.x(), rect.bottom())
            outer_path.lineTo(rect.left(), center.y())
            outer_path.closeSubpath()

            # 内菱形（按比例缩小）
            inner_path = QPainterPath()
            inner_top = center.y() - (center.y() - rect.top()) * inner_ratio
            inner_right = center.x() + (rect.right() - center.x()) * inner_ratio
            inner_bottom = center.y() + (rect.bottom() - center.y()) * inner_ratio
            inner_left = center.x() - (center.x() - rect.left()) * inner_ratio

            inner_path.moveTo(center.x(), inner_top)
            inner_path.lineTo(inner_right, center.y())
            inner_path.lineTo(center.x(), inner_bottom)
            inner_path.lineTo(inner_left, center.y())
            inner_path.closeSubpath()

            # 创建菱形环路径
            path = QPainterPath()
            path.addPath(outer_path)
            path.addPath(inner_path)
            painter.drawPath(path)

    def eventFilter(self, watched, event) -> bool:
        """事件过滤器 - 检测点击编辑框外部来取消编辑"""
        if not self._is_editing_name:
            return False

        if event.type() == event.Type.GraphicsSceneMousePress:
            # 检查点击位置是否在代理控件内
            if self._name_edit_proxy:
                # 获取代理控件在场景中的边界框
                proxy_rect = self._name_edit_proxy.sceneBoundingRect()
                mouse_event = event
                click_pos = mouse_event.scenePos()

                # 如果点击位置不在代理控件内，则完成编辑
                if not proxy_rect.contains(click_pos):
                    self._finishNameEdit()
                    return False  # 允许事件继续传递

        return False  # 其他事件不处理，继续传递


class SingleMarker(QObject):
    """
    Single标记 - 用于在节点左下角显示当前执行状态
    包含圆形背景和⚡图标（表示正在执行）
    """

    def __init__(self, parent: QGraphicsItem = None) -> None:
        super().__init__()

        self._parent = parent
        self._radius: float = 15.0

        # 创建圆形背景（橙黄色 - 表示活跃/执行中）
        self._ellipse_item = QGraphicsEllipseItem(parent)
        self._ellipse_item.setBrush(QBrush(QColor(255, 200, 100)))  # 橙黄色背景
        self._ellipse_item.setPen(QPen(QColor(200, 150, 50), 2))  # 深橙色描边，2像素宽
        self._ellipse_item.setZValue(Z_VALUE_MARKER)  # 确保在最上层
        self._ellipse_item.setAcceptHoverEvents(False)
        self._ellipse_item.setToolTip("正在执行")  # 添加 tooltip

        # 创建图标文本（⚡）
        self._text_item = QGraphicsTextItem("⚡", parent)
        self._text_item.setZValue(Z_VALUE_MARKER + 1)  # 确保在圆形背景之上
        self._text_item.setAcceptHoverEvents(False)
        self._text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

        # 初始隐藏
        self._opacity: float = 0.0
        self._updateOpacity()

        # 设置标记位置（左下角）
        self._updatePosition()

    def _isValid(self) -> bool:
        """检查 C++ 对象是否仍然有效"""
        if not hasattr(self, '_ellipse_item') or self._ellipse_item is None:
            return False
        try:
            self._ellipse_item.isVisible()
            return True
        except RuntimeError:
            return False

    def _updateOpacity(self) -> None:
        """更新透明度"""
        if not self._isValid():
            return
        try:
            self._ellipse_item.setOpacity(self._opacity)
            self._text_item.setOpacity(self._opacity)
        except RuntimeError:
            pass

    def getOpacity(self) -> float:
        """获取当前透明度"""
        return self._opacity

    def setOpacity(self, value: float) -> None:
        """设置透明度"""
        self._opacity = value
        self._updateOpacity()

    # 创建属性用于动画
    opacity = pyqtProperty(float, getOpacity, setOpacity)

    def _updatePosition(self) -> None:
        """更新标记位置（节点左下角）"""
        if not self._isValid():
            return
        if self._parent is None:
            return

        try:
            parent_rect = self._parent.rect()
            center = parent_rect.center()

            # 计算节点左下角的偏移位置
            offset_x = -parent_rect.width() / 2 + self._radius
            offset_y = parent_rect.height() / 2 - self._radius

            # 设置圆形背景位置
            ellipse_rect = QRectF(
                center.x() + offset_x - self._radius,
                center.y() + offset_y - self._radius,
                self._radius * 2,
                self._radius * 2
            )
            self._ellipse_item.setRect(ellipse_rect)

            # 设置文本居中
            text_rect = self._text_item.boundingRect()
            text_pos = QPointF(
                center.x() + offset_x - text_rect.width() / 2,
                center.y() + offset_y - text_rect.height() / 2
            )
            self._text_item.setPos(text_pos)
        except RuntimeError:
            pass

    def setRadius(self, radius: float) -> None:
        """设置标记半径"""
        self._radius = radius
        self._updatePosition()

    def show(self) -> None:
        """显示标记（带动画）"""
        if not self._isValid():
            return
        try:
            self._updatePosition()
            self._ellipse_item.show()
            self._text_item.show()
        except RuntimeError:
            pass

    def hide(self) -> None:
        """隐藏标记"""
        if not self._isValid():
            return
        try:
            self._ellipse_item.hide()
            self._text_item.hide()
        except RuntimeError:
            pass


class CustomMarker(QObject):
    """
    Custom标记 - 用户自定义标识
    支持自定义显示字符、背景色、前景色、边框颜色和厚度、半径
    默认位置在节点右下角
    """

    # 默认样式值
    DEFAULT_TEXT = "★"
    DEFAULT_BG_COLOR = QColor(227, 242, 253)  # 浅蓝色 #E3F2FD
    DEFAULT_FG_COLOR = QColor(21, 101, 192)   # 深蓝色 #1565C0
    DEFAULT_BORDER_COLOR = QColor(100, 181, 246)  # 中蓝色 #64B5F6
    DEFAULT_BORDER_WIDTH = 2
    DEFAULT_RADIUS = 15.0

    def __init__(self, parent: QGraphicsItem = None) -> None:
        super().__init__()

        self._parent = parent
        self._radius: float = self.DEFAULT_RADIUS
        self._text: str = self.DEFAULT_TEXT
        self._bg_color: QColor = self.DEFAULT_BG_COLOR
        self._fg_color: QColor = self.DEFAULT_FG_COLOR
        self._border_color: QColor = self.DEFAULT_BORDER_COLOR
        self._border_width: float = self.DEFAULT_BORDER_WIDTH

        # 创建圆形背景
        self._ellipse_item = QGraphicsEllipseItem(parent)
        self._ellipse_item.setBrush(QBrush(self._bg_color))
        self._ellipse_item.setPen(QPen(self._border_color, self._border_width))
        self._ellipse_item.setZValue(Z_VALUE_MARKER)
        self._ellipse_item.setAcceptHoverEvents(False)
        self._ellipse_item.setToolTip("自定义标记")

        # 创建图标文本
        self._text_item = QGraphicsTextItem(self._text, parent)
        self._text_item.setDefaultTextColor(self._fg_color)
        self._text_item.setZValue(Z_VALUE_MARKER + 1)
        self._text_item.setAcceptHoverEvents(False)
        self._text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

        # 初始隐藏
        self._opacity: float = 0.0
        self._updateOpacity()

        # 设置标记位置（右下角）
        self._updatePosition()

    def _isValid(self) -> bool:
        """检查 C++ 对象是否仍然有效"""
        if not hasattr(self, '_ellipse_item') or self._ellipse_item is None:
            return False
        try:
            self._ellipse_item.isVisible()
            return True
        except RuntimeError:
            return False

    def _updateOpacity(self) -> None:
        """更新透明度"""
        if not self._isValid():
            return
        try:
            self._ellipse_item.setOpacity(self._opacity)
            self._text_item.setOpacity(self._opacity)
        except RuntimeError:
            pass

    def getOpacity(self) -> float:
        """获取当前透明度"""
        return self._opacity

    def setOpacity(self, value: float) -> None:
        """设置透明度"""
        self._opacity = value
        self._updateOpacity()

    # 创建属性用于动画
    opacity = pyqtProperty(float, getOpacity, setOpacity)

    def setText(self, text: str) -> None:
        """设置显示字符"""
        self._text = text if text else self.DEFAULT_TEXT
        if self._isValid():
            self._text_item.setPlainText(self._text)
            self._updatePosition()

    def setBgColor(self, color: QColor) -> None:
        """设置背景色"""
        self._bg_color = color if color else self.DEFAULT_BG_COLOR
        if self._isValid():
            self._ellipse_item.setBrush(QBrush(self._bg_color))

    def setFgColor(self, color: QColor) -> None:
        """设置前景色（文本颜色）"""
        self._fg_color = color if color else self.DEFAULT_FG_COLOR
        if self._isValid():
            self._text_item.setDefaultTextColor(self._fg_color)

    def setBorderColor(self, color: QColor) -> None:
        """设置边框颜色"""
        self._border_color = color if color else self.DEFAULT_BORDER_COLOR
        if self._isValid():
            self._ellipse_item.setPen(QPen(self._border_color, self._border_width))

    def setBorderWidth(self, width: float) -> None:
        """设置边框厚度"""
        self._border_width = width if width > 0 else self.DEFAULT_BORDER_WIDTH
        if self._isValid():
            self._ellipse_item.setPen(QPen(self._border_color, self._border_width))

    def setRadius(self, radius: float) -> None:
        """设置标记半径"""
        self._radius = radius if radius > 0 else self.DEFAULT_RADIUS
        self._updatePosition()

    def setStyle(
        self,
        text: str = None,
        bg_color: QColor = None,
        fg_color: QColor = None,
        border_color: QColor = None,
        border_width: float = None,
        radius: float = None
    ) -> None:
        """批量设置样式"""
        if text is not None:
            self._text = text
        if bg_color is not None:
            self._bg_color = bg_color
        if fg_color is not None:
            self._fg_color = fg_color
        if border_color is not None:
            self._border_color = border_color
        if border_width is not None:
            self._border_width = border_width
        if radius is not None:
            self._radius = radius

        if self._isValid():
            self._text_item.setPlainText(self._text)
            self._text_item.setDefaultTextColor(self._fg_color)
            self._ellipse_item.setBrush(QBrush(self._bg_color))
            self._ellipse_item.setPen(QPen(self._border_color, self._border_width))
            self._updatePosition()

    def getStyle(self) -> dict:
        """获取当前样式配置"""
        return {
            "text": self._text,
            "bg_color": self._bg_color.name(),
            "fg_color": self._fg_color.name(),
            "border_color": self._border_color.name(),
            "border_width": self._border_width,
            "radius": self._radius
        }

    def _updatePosition(self) -> None:
        """更新标记位置（节点右下角）"""
        if not self._isValid():
            return
        if self._parent is None:
            return

        try:
            parent_rect = self._parent.rect()
            center = parent_rect.center()

            # 计算节点右下角的偏移位置
            offset_x = parent_rect.width() / 2 - self._radius
            offset_y = parent_rect.height() / 2 - self._radius

            # 设置圆形背景位置
            ellipse_rect = QRectF(
                center.x() + offset_x - self._radius,
                center.y() + offset_y - self._radius,
                self._radius * 2,
                self._radius * 2
            )
            self._ellipse_item.setRect(ellipse_rect)

            # 设置文本居中
            text_rect = self._text_item.boundingRect()
            text_pos = QPointF(
                center.x() + offset_x - text_rect.width() / 2,
                center.y() + offset_y - text_rect.height() / 2
            )
            self._text_item.setPos(text_pos)
        except RuntimeError:
            pass

    def show(self) -> None:
        """显示标记（带动画）"""
        if not self._isValid():
            return
        try:
            self._updatePosition()
            self._ellipse_item.show()
            self._text_item.show()
        except RuntimeError:
            pass

    def hide(self) -> None:
        """隐藏标记"""
        if not self._isValid():
            return
        try:
            self._ellipse_item.hide()
            self._text_item.hide()
        except RuntimeError:
            pass

    def _isValid(self) -> bool:
        """检查 C++ 对象是否仍然有效"""
        if not hasattr(self, '_ellipse_item') or self._ellipse_item is None:
            return False
        try:
            self._ellipse_item.isVisible()
            return True
        except RuntimeError:
            return False

    def _updateOpacity(self) -> None:
        """更新透明度"""
        if not self._isValid():
            return
        try:
            self._ellipse_item.setOpacity(self._opacity)
            self._text_item.setOpacity(self._opacity)
        except RuntimeError:
            pass

    def getOpacity(self) -> float:
        """获取当前透明度"""
        return self._opacity

    def setOpacity(self, value: float) -> None:
        """设置透明度"""
        self._opacity = value
        self._updateOpacity()

    # 创建属性用于动画
    opacity = pyqtProperty(float, getOpacity, setOpacity)
