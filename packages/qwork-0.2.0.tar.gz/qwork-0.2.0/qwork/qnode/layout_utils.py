"""
布局工具模块 - 提供自动布局算法
"""

import math
from typing import List, Dict, Optional, Tuple

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import QTransform

from qwork.qnode.node_item import NodeItem
from qwork.qnode.connection_item import ConnectionItem


class DenseLayoutEngine:
    """密集布局引擎 - 提供多种自动布局策略"""
    
    def __init__(self, canvas: 'NodeCanvas') -> None:
        self._canvas = canvas
        self._nodes: List[NodeItem] = canvas.nodes
        self._connections: List[ConnectionItem] = canvas.connections
    
    def autoLayout(self, strategy: str = "compact") -> None:
        """
        自动布局
        
        Args:
            strategy: 布局策略 ("compact", "circular", "grid", "hierarchical", "force")
        """
        if not self._nodes:
            return
        
        if strategy == "compact":
            self._compactLayout()
        elif strategy == "circular":
            self._circularLayout()
        elif strategy == "grid":
            self._gridLayout()
        elif strategy == "hierarchical":
            self._hierarchicalLayout()
        elif strategy == "force":
            self._forceDirectedLayout()
        
        # 更新所有连接
        for conn in self._connections:
            conn.updatePath()
        
        # 标记画布已修改
        self._canvas.changed = True
    
    def _compactLayout(self) -> None:
        """紧凑布局 - 将节点排列成紧凑的网格"""
        if not self._nodes:
            return
        
        # 计算节点大小
        node_size = 100  # 假设节点大小为100x100
        spacing = 20  # 节点间距
        
        # 计算网格尺寸
        node_count = len(self._nodes)
        cols = int(math.sqrt(node_count))
        if cols * cols < node_count:
            cols += 1
        
        # 计算起始位置（使布局居中）
        start_x = -(cols * (node_size + spacing)) / 2
        start_y = -(math.ceil(node_count / cols) * (node_size + spacing)) / 2
        
        # 排列节点
        for i, node in enumerate(self._nodes):
            row = i // cols
            col = i % cols
            x = start_x + col * (node_size + spacing)
            y = start_y + row * (node_size + spacing)
            node.setPos(QPointF(x, y))
    
    def _circularLayout(self) -> None:
        """圆形布局 - 将节点排列成圆形"""
        if not self._nodes:
            return
        
        node_count = len(self._nodes)
        if node_count == 1:
            self._nodes[0].setPos(QPointF(0, 0))
            return
        
        # 计算圆形半径
        radius = max(200, node_count * 30)
        
        # 排列节点
        for i, node in enumerate(self._nodes):
            angle = 2 * math.pi * i / node_count
            x = radius * math.cos(angle)
            y = radius * math.sin(angle)
            node.setPos(QPointF(x, y))
    
    def _gridLayout(self) -> None:
        """网格布局 - 将节点排列成规则的网格"""
        if not self._nodes:
            return
        
        # 计算节点大小
        node_size = 100
        spacing = 30
        
        # 计算网格尺寸
        node_count = len(self._nodes)
        cols = int(math.sqrt(node_count * 1.5))  # 稍微宽一点的网格
        if cols < 1:
            cols = 1
        
        # 计算起始位置
        start_x = -(cols * (node_size + spacing)) / 2
        start_y = -(math.ceil(node_count / cols) * (node_size + spacing)) / 2
        
        # 排列节点
        for i, node in enumerate(self._nodes):
            row = i // cols
            col = i % cols
            x = start_x + col * (node_size + spacing)
            y = start_y + row * (node_size + spacing)
            node.setPos(QPointF(x, y))
    
    def _hierarchicalLayout(self) -> None:
        """层次布局 - 基于连接的层次结构"""
        if not self._nodes:
            return
        
        # 构建邻接表
        adjacency: Dict[NodeItem, List[NodeItem]] = {node: [] for node in self._nodes}
        for conn in self._connections:
            adjacency[conn.sourceNode].append(conn.targetNode)
        
        # 计算每个节点的层次（距离起点的距离）
        levels: Dict[NodeItem, int] = {}
        
        # 找到没有入边的节点作为起点
        in_degree: Dict[NodeItem, int] = {node: 0 for node in self._nodes}
        for conn in self._connections:
            in_degree[conn.targetNode] = in_degree.get(conn.targetNode, 0) + 1
        
        # BFS计算层次
        queue = [node for node in self._nodes if in_degree[node] == 0]
        for node in queue:
            levels[node] = 0
        
        while queue:
            current = queue.pop(0)
            for neighbor in adjacency[current]:
                if neighbor not in levels:
                    levels[neighbor] = levels[current] + 1
                    queue.append(neighbor)
        
        # 为没有层次的节点分配层次
        max_level = max(levels.values()) if levels else 0
        for node in self._nodes:
            if node not in levels:
                levels[node] = max_level + 1
        
        # 按层次分组
        level_groups: Dict[int, List[NodeItem]] = {}
        for node, level in levels.items():
            if level not in level_groups:
                level_groups[level] = []
            level_groups[level].append(node)
        
        # 布局
        node_size = 100
        level_spacing = 150
        node_spacing = 120
        
        for level, nodes in level_groups.items():
            y = level * level_spacing
            count = len(nodes)
            start_x = -(count * node_spacing) / 2
            
            for i, node in enumerate(nodes):
                x = start_x + i * node_spacing
                node.setPos(QPointF(x, y))
    
    def _forceDirectedLayout(self) -> None:
        """力导向布局 - 模拟物理力"""
        if not self._nodes:
            return
        
        # 参数
        iterations = 100
        repulsion_force = 1000
        attraction_force = 0.01
        damping = 0.8
        
        # 初始化速度
        velocities: Dict[NodeItem, QPointF] = {node: QPointF(0, 0) for node in self._nodes}
        
        for _ in range(iterations):
            # 计算斥力
            for i, node1 in enumerate(self._nodes):
                for j, node2 in enumerate(self._nodes):
                    if i >= j:
                        continue
                    
                    pos1 = node1.pos()
                    pos2 = node2.pos()
                    dx = pos1.x() - pos2.x()
                    dy = pos1.y() - pos2.y()
                    distance = math.sqrt(dx * dx + dy * dy)
                    
                    if distance < 1:
                        distance = 1
                    
                    force = repulsion_force / (distance * distance)
                    fx = force * dx / distance
                    fy = force * dy / distance
                    
                    velocities[node1] = QPointF(
                        velocities[node1].x() + fx,
                        velocities[node1].y() + fy
                    )
                    velocities[node2] = QPointF(
                        velocities[node2].x() - fx,
                        velocities[node2].y() - fy
                    )
            
            # 计算引力（连接的节点）
            for conn in self._connections:
                node1 = conn.sourceNode
                node2 = conn.targetNode
                
                pos1 = node1.pos()
                pos2 = node2.pos()
                dx = pos2.x() - pos1.x()
                dy = pos2.y() - pos1.y()
                distance = math.sqrt(dx * dx + dy * dy)
                
                if distance < 1:
                    distance = 1
                
                force = attraction_force * distance
                fx = force * dx / distance
                fy = force * dy / distance
                
                velocities[node1] = QPointF(
                    velocities[node1].x() + fx,
                    velocities[node1].y() + fy
                )
                velocities[node2] = QPointF(
                    velocities[node2].x() - fx,
                    velocities[node2].y() - fy
                )
            
            # 应用速度和阻尼
            for node in self._nodes:
                vel = velocities[node]
                new_pos = QPointF(
                    node.pos().x() + vel.x() * damping,
                    node.pos().y() + vel.y() * damping
                )
                node.setPos(new_pos)
                
                # 应用阻尼
                velocities[node] = QPointF(vel.x() * 0.9, vel.y() * 0.9)


class ViewportFitter:
    """视口适配器 - 自动调整视图以适应所有节点"""
    
    def __init__(self, canvas: 'NodeCanvas') -> None:
        self._canvas = canvas
    
    def fitViewport(self, margin: float = 50.0) -> None:
        """
        自动调整视图以适应所有节点
        
        Args:
            margin: 边距
        """
        nodes = self._canvas.nodes
        if not nodes:
            return
        
        # 计算边界框
        rect = QRectF()
        for node in nodes:
            node_rect = node.sceneBoundingRect()
            rect = rect.united(node_rect)
        
        # 添加边距
        rect.adjust(-margin, -margin, margin, margin)
        
        # 适应视图
        self._canvas.fitInView(rect, Qt.AspectRatioMode.KeepAspectRatio)
    
    def centerOnNodes(self) -> None:
        """将视图中心对准所有节点的中心"""
        nodes = self._canvas.nodes
        if not nodes:
            return
        
        # 计算中心点
        center = QPointF(0, 0)
        for node in nodes:
            center += node.pos()
        center /= len(nodes)
        
        # 设置视图中心
        self._canvas.centerOn(center)
