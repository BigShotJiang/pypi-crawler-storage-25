# -*- coding: utf-8 -*-

from __future__ import annotations
"""


AI Onion - 基于 Onion 架构的 AI 交互抽象层

设计原则:
1. 核心抽象定义 AI 交互的基本契约
2. 实现类提供具体的 AI 提供商支持（Kimi、OpenAI 等）
3. 使用洋葱架构解耦核心逻辑与实现细节
"""

from pydantic import BaseModel
from onion import OnionUnload
from .models import get_available_models
import asyncio
import json
import re
import importlib
from PyQt6.QtWidgets import QApplication
from qwork.qai.qais import ShowSettingsDialog, QAISettingsDialog
from typing import Union as TypingUnion


import inspect
from typing import AsyncIterator, Dict, List, Optional, Any, TypeVar, Union, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from onion import Onion, abstractmethod

ToolParams = TypeVar("ToolParams", bound="BaseModel")


@dataclass
class ToolDef:
    """
    工具定义类 - 统一封装函数工具

    从 Python 函数自动提取 OpenAI Function Calling 格式的工具定义

    示例:
        >>> def TestTool(count: int) -> float:
        ...     '''生成指定数量的随机数并返回平均值'''
        ...     return sum([random.random() for _ in range(count)]) / count
        >>> tool = ToolDef(TestTool)
        >>> tool.todict()
        {
            'type': 'function',
            'function': {
                'name': 'TestTool',
                'description': '生成指定数量的随机数并返回平均值',
                'parameters': {
                    'type': 'object',
                    'properties': {'count': {'type': 'integer'}},
                    'required': ['count']
                }
            }
        }
    """
    _fn: Callable = field(repr=False)
    _schema: Dict[str, Any] = field(default_factory=dict, repr=False)

    def __post_init__(self):
        if not callable(self._fn):
            raise ValueError("ToolDef._fn must be callable")
        self._schema = self._extract_schema()

    def _extract_schema(self) -> Dict[str, Any]:
        """从函数提取 OpenAI 格式的工具定义"""
        sig = inspect.signature(self._fn)
        doc = inspect.getdoc(self._fn)
        description = doc.split('\n')[0] if doc else f"执行 {self._fn.__name__}"

        # Python 类型到 JSON Schema 类型的映射
        type_mapping = {
            int: 'integer',
            float: 'number',
            str: 'string',
            bool: 'boolean',
            list: 'array',
            dict: 'object',
            any: 'string',
            Any: 'string',
        }

        properties = {}
        required = []

        for param_name, param in sig.parameters.items():
            # 跳过 *args 和 **kwargs
            if param.kind in (param.VAR_POSITIONAL, param.VAR_KEYWORD):
                continue

            prop = {}

            # 获取类型注解
            if param.annotation != inspect.Parameter.empty:
                py_type = param.annotation
                # 处理 Optional[T] 或 Union[T, None]
                origin = getattr(py_type, '__origin__', None)
                if origin is not None:
                    args = getattr(py_type, '__args__', ())
                    if origin is Optional or (origin is TypingUnion and type(None) in args):
                        py_type = next((a for a in args if a is not type(None)), str)

                json_type = type_mapping.get(py_type, 'string')
                prop['type'] = json_type

            properties[param_name] = prop

            # 没有默认值则加入 required
            if param.default == inspect.Parameter.empty:
                required.append(param_name)

        return {
            'type': 'function',
            'function': {
                'name': self._fn.__name__,
                'description': description,
                'parameters': {
                    'type': 'object',
                    'properties': properties,
                    'required': required
                }
            }
        }

    @property
    def fn(self) -> Callable:
        """工具函数"""
        return self._fn

    @property
    def name(self) -> str:
        """工具名称（函数名）"""
        return self._fn.__name__

    @property
    def doc(self) -> str:
        """工具描述（文档字符串第一行）"""
        return self._schema['function']['description']

    @property
    def description(self) -> str:
        """同 doc，兼容 OpenAI 命名"""
        return self.doc

    @property
    def params(self) -> Dict[str, Any]:
        """参数定义"""
        return self._schema['function']['parameters']

    @property
    def parameters(self) -> Dict[str, Any]:
        """同 params，兼容 OpenAI 命名"""
        return self.params

    def todict(self) -> Dict[str, Any]:
        """输出 OpenAI 格式的工具定义字典"""
        return self._schema.copy()

    async def call(self, **kwargs) -> Any:
        """调用工具函数"""
        result = self._fn(**kwargs)
        # 如果结果是协程，等待它
        if asyncio.iscoroutine(result):
            result = await result
        return result


@dataclass
class ToolCall:
    """工具调用数据类"""
    id: str
    name: str
    arguments: str

    def parseArguments(self) -> Dict[str, Any]:
        try:
            return json.loads(self.arguments)
        except json.JSONDecodeError:
            return {}


@dataclass
class ToolCallResult:
    """工具调用结果数据类"""
    tool_call_id: str
    name: str
    output: str
    success: bool = True
    message: str = ""


@dataclass
class Message:
    """AI 消息数据类"""
    role: str
    content: str
    metadata: Optional[Dict[str, Any]] = None
    tool_calls: Optional[List[ToolCall]] = None
    tool_call_id: Optional[str] = None


@dataclass
class ChatResponse:
    """聊天响应数据类"""
    content: str
    model: Optional[str] = None
    usage: Optional[Dict[str, int]] = None
    metadata: Optional[Dict[str, Any]] = None

    def getTotalTokens(self) -> int:
        if self.usage:
            return self.usage.get("total_tokens", 0)
        return 0

    def getPromptTokens(self) -> int:
        if self.usage:
            return self.usage.get("prompt_tokens", 0)
        return 0

    def getCompletionTokens(self) -> int:
        if self.usage:
            return self.usage.get("completion_tokens", 0)
        return 0


class AICore(Onion):
    """
    AI 交互核心抽象类
    """

    _class_config: Optional[Any] = None

    def __init__(self, config: Optional[Dict[str, str]] = None):
        super().__init__()

        if config is None:
            config = self.loadConfig()

        if not config:
            raise ValueError("No config provided. Please run loadConfig() first.")

        self._config = self._createConfig(config)
        type(self)._class_config = self._config

    def _ensureConfig(self) -> Any:
        if hasattr(self, '_config') and self._config is not None:
            return self._config

        if type(self)._class_config is not None:
            self._config = type(self)._class_config
            return self._config

        configdata = self.loadConfig()
        if configdata:
            self._config = self._createConfig(configdata)
            type(self)._class_config = self._config
            return self._config

        raise RuntimeError(f"{type(self).__name__} not configured.")

    @abstractmethod
    def _createConfig(self, config: Dict[str, str]) -> Any:
        pass

    @abstractmethod
    def providerName(self) -> str:
        pass

    @abstractmethod
    def defaultModel(self) -> str:
        pass

    @abstractmethod
    def supportsStreaming(self) -> bool:
        pass

    @abstractmethod
    def supportsTools(self) -> bool:
        pass

    @abstractmethod
    def maxStepsPerTurn(self) -> int:
        pass

    @abstractmethod
    async def chat(
            self,
            messages: List[Message | str],
            model: Optional[str] = None,
            temperature: float = 0.7,
            maxtokens: Optional[int] = None,
            tooldefs: Optional[list[ToolDef]] = None,
            **kwargs
    ) -> ChatResponse:
        """
        非流式聊天对话

        Args:
            messages: 消息列表
            model: 模型名称
            temperature: 温度参数
            maxtokens: 最大 token 数
            tooldefs: 工具定义列表，AI 内部自行调用
        """
        pass

    @abstractmethod
    async def chatStream(
            self,
            messages: List[Message | str],
            model: Optional[str] = None,
            temperature: float = 0.7,
            maxtokens: Optional[int] = None,
            tooldefs: Optional[List[ToolDef]] = None,
            **kwargs
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        流式聊天对话

        Args:
            messages: 消息列表
            model: 模型名称
            temperature: 温度参数
            maxtokens: 最大 token 数
            tooldefs: 工具定义列表，AI 内部自行调用
        """
        pass

    async def healthCheck(self, prompt: str = "请仅回复'1'") -> Optional[str]:
        try:
            response = await self.simple_chat(prompt, temperature=0.1)
            content = response.strip() if response else ''
            return content if content else None
        except Exception as e:
            print(f"[BaseAI] Health check failed: {type(e).__name__}: {e}")
            return None

    @abstractmethod
    def loadConfig(self) -> Optional[Dict[str, str]]:
        pass

    async def simpleChat(self, usermessage: str, systemprompt: Optional[str] = None, temperature: float = 0.7) -> str:
        messages = []
        if systemprompt:
            messages.append(Message(role="system", content=systemprompt))
        messages.append(Message(role="user", content=usermessage))

        response = await self.chat(messages, temperature=temperature)
        return response.content

    async def complete(
            self,
            prompt: str,
            model: Optional[str] = None,
            temperature: float = 0.7,
            maxtokens: Optional[int] = None,
            tooldefs: Optional[List[ToolDef]] = None,
            **kwargs
    ) -> ChatResponse:
        messages = [Message(role="user", content=prompt)]
        return await self.chat(messages, model, temperature, maxtokens, tooldefs, **kwargs)

    @abstractmethod
    async def rollback(self, conversationidx: int) -> bool:
        pass

    @abstractmethod
    def maxContextTokens(self) -> int:
        pass

    @abstractmethod
    def currentTokenCount(self) -> int:
        pass

    def estimateTokensForMessages(self, messages: List[Message], tooldefs: Optional[List[ToolDef]] = None) -> int:

        _totaltokens = 0
        _msgoverhead = 4

        for msg in messages:
            content = msg.content if msg.content else ""
            _cnchars = len(re.findall(r'[\u4e00-\u9fff]', content))
            _enwords = len(re.findall(r'[a-zA-Z]+', content))
            _otherchars = len(content) - _cnchars - sum(len(w) for w in re.findall(r'[a-zA-Z]+', content))

            _msgtokens = _msgoverhead + (
                    _cnchars * 1.5 +
                    _enwords * 1.3 +
                    max(0, _otherchars) * 0.5
            )
            _totaltokens += int(_msgtokens)

        if tooldefs:
            _toolsjson = json.dumps([t.todict() for t in tooldefs], ensure_ascii=False)
            _totaltokens += int(len(_toolsjson) * 0.4)

        return max(1, int(_totaltokens))

    def contextUsagePercent(self) -> float:
        maxtokens = self.maxContextTokens()
        if maxtokens <= 0:
            return 0.0
        return (self.currentTokenCount() / maxtokens) * 100.0

    def __str__(self) -> str:
        return f"{self.__class__.__name__}({self.providerName()}, {self.defaultModel()})"

    def __repr__(self) -> str:
        return (
            f"<{self.__class__.__name__} "
            f"provider={self.providerName()!r} "
            f"model={self.defaultModel()!r} "
            f"streaming={self.supportsStreaming()} "
            f"tools={self.supportsTools()}>"
        )


def CreateAI(provider: str, only: bool = False) -> "AICore | None":
    """
    创建 AI 实例（Onion 工厂函数）

    通过基类 AICore 实例化，自动加载指定提供商的实现。
    配置加载失败时返回 None，便于链式调用: CreateAI("kimi") or CreateAI("empty")

    Args:
        provider: 提供商名称 (kimi, qwen, deepseek, empty 等)
        only: 若为 True，配置不存在时抛出错误而非返回 None

    Returns:
        AICore 实例，或 None（配置不存在时，仅当 only=False）

    Raises:
        ValueError: 不支持的提供商，或配置不存在（仅当 only=True）

    示例:
        >>> from qai.aio import CreateAI
        >>> ai = CreateAI("kimi") or CreateAI("empty")
        >>> response = await ai.chat(messages)
        >>>
        >>> # 强制必须成功
        >>> ai = CreateAI("kimi", only=True)
    """

    provider = provider.lower()

    # 清除旧的实现绑定
    OnionUnload(AICore)

    # 获取所有可用的 AI 模型
    available_models = get_available_models()
    available_providers = {}

    for _attr_name, _cls in available_models.items():
        # 获取 provider 名称（去掉 AI 后缀）
        _provider_name = _attr_name[:-2] if _attr_name.endswith('AI') else _attr_name
        _provider_name = _provider_name.lower()
        available_providers[_provider_name] = _cls

    # 检查请求的 provider 是否可用
    if provider not in available_providers:
        raise ValueError(f"不支持的 AI 提供商: {provider} (支持: {', '.join(sorted(available_providers.keys()))})")

    # 动态导入并创建实例
    # 先导入实现类以确保 Onion 能正确编译
    _cls = available_providers[provider]
    _module_name = _cls.__module__
    try:
        importlib.import_module(_module_name)
        return AICore()
    except ValueError as e:
        if "No config provided" in str(e) or "not configured" in str(e):
            if only:
                raise ValueError(f"{provider} 配置不存在，请先配置 AI 提供商") from e
            return None
        raise


def OpenQaiSetting(parent=None, modal: bool = True):
    """
    打开 QAI 设置对话框

    兼容已有 UI 项目和没有 UI 的项目：
    - 若当前已有 Qt 应用运行，直接使用现有应用
    - 若没有 UI，自动创建 QApplication 并执行事件循环

    Args:
        parent: 父窗口，若已有 UI 可传入主窗口
        modal: 是否以模态方式显示，False 时为非模态（已有 UI 时推荐）

    Returns:
        若 modal=True: 返回设置结果字典或 None（用户取消）
        若 modal=False: 返回对话框实例

    Raises:
        RuntimeError: PyQt6 未安装

    示例:
        # 无 UI 项目 - 阻塞等待用户配置
        result = OpenQaiSetting()
        if result:
            print(f"配置了 {len(result['providers'])} 个提供商")

        # 已有 UI 项目 - 非模态
        dialog = OpenQaiSetting(parent=main_window, modal=False)
    """
    # 检查是否已有 Qt 应用
    app = QApplication.instance()
    created_app = False

    if app is None:
        # 没有 UI，创建新的 QApplication
        app = QApplication([])
        created_app = True

    if modal:
        # 模态模式：阻塞等待用户操作
        result = ShowSettingsDialog(parent)

        # 若我们创建了应用，执行事件循环
        if created_app:
            # 对话框已关闭，无需循环，但确保处理未处理的事件
            app.processEvents()

        return result
    else:
        # 非模态模式：创建对话框但不阻塞
        dialog = QAISettingsDialog(parent)
        dialog.setModal(False)
        dialog.show()

        # 若我们创建了应用，需要启动事件循环
        if created_app:
            # 连接对话框关闭信号退出应用
            dialog.finished.connect(app.quit)
            app.exec()

        return dialog
