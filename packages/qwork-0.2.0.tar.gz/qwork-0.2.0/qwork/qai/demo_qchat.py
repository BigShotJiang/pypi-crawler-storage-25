# -*- coding: utf-8 -*-
"""
QAI QChat GUI Demo

测试 QAIChatWidget 的图形界面功能，使用新的 ToolDef 接口。

运行方式:
    python -m qwork.qai.demo_qchat
"""

from datetime import datetime

import random
import sys
from PyQt6.QtWidgets import QApplication
from qwork.qai import CreateAI, QAIChatWidget, ToolDef


def TestTool(count: int) -> float:
    """生成指定数量的随机数并返回平均值"""
    print(f"[TestTool] AI调用了此函数，参数 count={count}")
    values = [random.random() * 100 for _ in range(count)]
    avg = sum(values) / len(values) if values else 0
    return avg


def GetCurrentTime(format: str = "%Y-%m-%d %H:%M:%S") -> str:
    """获取当前时间，返回指定格式的字符串"""
    return datetime.now().strftime(format)


def Main():
    """启动 QChat GUI Demo"""
    app = QApplication(sys.argv)
    app.setStyle('Fusion')

    # 创建聊天窗口
    window = QAIChatWidget()

    # 使用 ToolDef 注册工
    window.setTooldefs([ToolDef(TestTool), ToolDef(GetCurrentTime)])
    # print(f"已注册工具: {[td.name for td in tooldefs]}")

    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    Main()
