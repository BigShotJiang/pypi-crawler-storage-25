# -*- coding: utf-8 -*-
"""
QAI 设置对话框 - 左侧 Tab 布局

功能：
- API 供应商配置（使用 config 模块功能）
- 系统提示词设置
- 工具黑名单设置
"""

from PyQt6.QtCore import QSettings
import sys
from PyQt6.QtWidgets import QApplication


import json
import os
from typing import Optional, Dict, Any

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QWidget, QMessageBox, QTabWidget,
    QListWidget, QListWidgetItem, QAbstractItemView,
    QTextEdit, QSplitter, QFrame, QComboBox
)
from PyQt6.QtGui import QStandardItemModel, QStandardItem
from PyQt6.QtCore import Qt
from PyQt6.QtCore import Qt

from .config import QAIConfig
from .models import get_available_models


class APIConfigTab(QWidget):
    """API 配置 Tab 页面"""

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)

        self._config = QAIConfig()
        self._providers: Dict[str, Dict[str, str]] = {}

        self._setup_ui()
        self._load_config()

    def _setup_ui(self):
        """设置 UI 界面"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        # 标题和新增按钮行
        header_layout = QHBoxLayout()

        info_label = QLabel("已配置的 AI 供应商：")
        info_label.setStyleSheet("font-size: 14px; font-weight: bold; color: #333333;")
        header_layout.addWidget(info_label)

        header_layout.addStretch()

        self.add_btn = QPushButton("+ 新增")
        self.add_btn.setFixedWidth(80)
        self.add_btn.clicked.connect(self._on_add)
        self.add_btn.setStyleSheet("""
            QPushButton {
                background-color: #5a9bd5;
                border: 1px solid #4a8bc5;
                border-radius: 4px;
                color: white;
                padding: 6px 12px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #6aaee5;
            }
        """)
        header_layout.addWidget(self.add_btn)

        layout.addLayout(header_layout)

        # 供应商列表
        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.list_widget.setAlternatingRowColors(True)
        self.list_widget.setStyleSheet("""
            QListWidget {
                background-color: #ffffff;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 5px;
                font-size: 13px;
            }
            QListWidget::item {
                padding: 8px;
                border-bottom: 1px solid #eeeeee;
                min-height: 40px;
            }
            QListWidget::item:selected {
                background-color: #e0f0ff;
                color: #333333;
            }
            QListWidget::item:alternate {
                background-color: #f9f9f9;
            }
        """)
        layout.addWidget(self.list_widget)

        # 配置文件路径提示
        self.path_label = QLabel(f"配置文件: {self._config.config_path}")
        self.path_label.setStyleSheet("color: #999999; font-size: 10px;")
        self.path_label.setWordWrap(True)
        layout.addWidget(self.path_label)

    def _load_config(self):
        """加载配置"""
        providers = self._config.load()
        if providers:
            self._providers = providers
        self._refresh_list()

    def _refresh_list(self):
        """刷新供应商列表"""
        self.list_widget.clear()

        if not self._providers:
            empty_item = QListWidgetItem("暂无供应商配置，点击右上角'新增'添加")
            empty_item.setFlags(empty_item.flags() & ~Qt.ItemFlag.ItemIsEnabled)
            self.list_widget.addItem(empty_item)
            return

        for name, config in sorted(self._providers.items()):
            item_widget = self._create_provider_item(name, config)
            list_item = QListWidgetItem()
            list_item.setSizeHint(item_widget.sizeHint())
            list_item.setData(Qt.ItemDataRole.UserRole, name)
            self.list_widget.addItem(list_item)
            self.list_widget.setItemWidget(list_item, item_widget)

    def _create_provider_item(self, name: str, config: Dict[str, str]) -> QWidget:
        """创建单个供应商列表项的 Widget"""
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(10, 5, 10, 5)
        layout.setSpacing(10)

        # 左侧：供应商信息
        info_layout = QVBoxLayout()
        info_layout.setSpacing(2)

        name_label = QLabel(name)
        name_label.setStyleSheet("font-size: 13px; font-weight: bold; color: #333333;")
        info_layout.addWidget(name_label)

        url_label = QLabel(config.get("url", ""))
        url_label.setStyleSheet("font-size: 11px; color: #666666;")
        url_label.setWordWrap(True)
        info_layout.addWidget(url_label)

        layout.addLayout(info_layout, 1)

        # 右侧：操作按钮
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(5)

        edit_btn = QPushButton("修改")
        edit_btn.setFixedWidth(50)
        edit_btn.setStyleSheet("""
            QPushButton {
                background-color: #5a9bd5;
                border: 1px solid #4a8bc5;
                border-radius: 4px;
                color: white;
                padding: 4px 10px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #6aaee5;
            }
        """)
        edit_btn.clicked.connect(lambda: self._on_edit(name))
        btn_layout.addWidget(edit_btn)

        delete_btn = QPushButton("删除")
        delete_btn.setFixedWidth(50)
        delete_btn.setStyleSheet("""
            QPushButton {
                background-color: #e74c3c;
                border: 1px solid #c0392b;
                border-radius: 4px;
                color: white;
                padding: 4px 10px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #c0392b;
            }
        """)
        delete_btn.clicked.connect(lambda: self._on_delete(name))
        btn_layout.addWidget(delete_btn)

        layout.addLayout(btn_layout)

        return widget

    def _on_add(self):
        """新增供应商"""
        dialog = ProviderConfigDialog(self, existing_providers=self._providers)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            result = dialog.get_result()
            if result:
                name = result["name"]
                if name in self._providers:
                    QMessageBox.warning(self, "重复名称", f"供应商'{name}'已存在")
                    return

                self._providers[name] = {
                    "url": result["url"],
                    "key": result["key"]
                }
                self._config.save(self._providers)
                self._refresh_list()

    def _on_edit(self, name: str):
        """修改供应商配置"""
        config = self._providers.get(name)
        if not config:
            return

        dialog = ProviderConfigDialog(
            self,
            provider_name=name,
            url=config.get("url", ""),
            key=config.get("key", ""),
            existing_providers=self._providers
        )
        if dialog.exec() == QDialog.DialogCode.Accepted:
            result = dialog.get_result()
            if result:
                new_key = result["key"]
                if new_key == "__KEEP_ORIGINAL_KEY__":
                    new_key = config.get("key", "")
                self._providers[name] = {
                    "url": result["url"],
                    "key": new_key
                }
                self._config.save(self._providers)
                self._refresh_list()

    def _on_delete(self, name: str):
        """删除供应商"""
        reply = QMessageBox.question(
            self,
            "确认删除",
            f"确定要删除供应商'{name}'的配置吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            del self._providers[name]
            self._config.save(self._providers)
            self._refresh_list()

    def get_providers(self) -> Dict[str, Dict[str, str]]:
        """获取当前所有供应商配置"""
        return self._providers.copy()


class ProviderConfigDialog(QDialog):
    """单个供应商配置编辑对话框"""

    @staticmethod
    def _get_available_providers():
        """获取所有可用的 AI 提供商（排除 empty）"""
        available_models = get_available_models()
        providers = []
        for name in available_models.keys():
            # 获取 provider 名称（去掉 AI 后缀）
            provider_name = name[:-2] if name.endswith('AI') else name
            provider_name = provider_name.lower()
            if provider_name != 'empty':
                providers.append(provider_name)
        return sorted(providers)

    def __init__(self, parent: Optional[QWidget] = None, provider_name: str = "", url: str = "", key: str = "", existing_providers: Optional[Dict[str, Dict[str, str]]] = None):
        super().__init__(parent)

        self._provider_name = provider_name
        self._is_edit_mode = bool(provider_name)
        self._result: Optional[Dict[str, str]] = None
        self._existing_providers = existing_providers or {}

        self._setup_ui()
        self.set_values(url, key)

    def _setup_ui(self):
        """设置 UI 界面"""
        self.setWindowTitle("编辑供应商配置" if self._is_edit_mode else "新增供应商")
        self.setMinimumSize(450, 330)
        self.resize(480, 350)

        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # 说明标签
        info_label = QLabel("请输入供应商配置信息：")
        info_label.setStyleSheet("color: #333333; font-size: 14px; font-weight: bold;")
        main_layout.addWidget(info_label)

        # 供应商名称输入行
        name_layout = QHBoxLayout()
        name_layout.setSpacing(10)

        name_label = QLabel("供应商名称:")
        name_label.setStyleSheet("color: #666666; font-size: 12px;")
        name_layout.addWidget(name_label)

        self.name_input = QComboBox()
        self.name_input.setEditable(False)
        self.name_input.setMinimumWidth(150)

        # 使用自定义模型以支持禁用特定项
        model = QStandardItemModel()

        # 计算已使用的供应商
        used_models = set(self._existing_providers.keys())

        # 获取动态可用的提供商列表
        available_providers = self._get_available_providers()

        for model_name in available_providers:
            item = QStandardItem(model_name)
            item.setEnabled(True)

            if model_name in used_models:
                if self._is_edit_mode and model_name == self._provider_name:
                    # 当前编辑的项：正常显示，不禁用
                    pass
                else:
                    # 其他已使用的项：显示[已使用]并禁用
                    item.setText(f"{model_name} [已使用]")
                    item.setEnabled(False)
                    item.setData(Qt.GlobalColor.gray, Qt.ItemDataRole.ForegroundRole)

            model.appendRow(item)

        self.name_input.setModel(model)

        # 设置当前选中项
        if self._provider_name:
            for i in range(model.rowCount()):
                item = model.item(i)
                if item.text().startswith(self._provider_name):
                    self.name_input.setCurrentIndex(i)
                    break

        name_layout.addWidget(self.name_input)
        name_layout.addStretch()

        main_layout.addLayout(name_layout)

        # URL 输入行
        url_layout = QVBoxLayout()
        url_layout.setSpacing(5)

        url_label = QLabel("URL 地址:")
        url_label.setStyleSheet("color: #666666; font-size: 12px;")
        url_layout.addWidget(url_label)

        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("例如: http://localhost:8000/v1")
        url_layout.addWidget(self.url_input)

        main_layout.addLayout(url_layout)

        # Key 输入行
        key_layout = QVBoxLayout()
        key_layout.setSpacing(5)

        key_label = QLabel("Key:")
        key_label.setStyleSheet("color: #666666; font-size: 12px;")
        key_layout.addWidget(key_label)

        self.key_input = QLineEdit()
        self.key_input.setPlaceholderText("输入您的 API Key" if not self._is_edit_mode else "留空表示不修改，输入则更新 Key")
        key_layout.addWidget(self.key_input)

        main_layout.addLayout(key_layout)

        # 按钮行
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)
        button_layout.addStretch()

        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.setFixedWidth(80)
        self.cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_btn)

        self.save_btn = QPushButton("保存")
        self.save_btn.setFixedWidth(80)
        self.save_btn.setDefault(True)
        self.save_btn.clicked.connect(self._on_save)
        button_layout.addWidget(self.save_btn)

        main_layout.addLayout(button_layout)
        main_layout.addStretch()

        self.setStyleSheet("""
            QDialog {
                background-color: #F0F0F0;
            }
            QLineEdit {
                background-color: #ffffff;
                color: #333333;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 8px 12px;
                font-size: 13px;
            }
            QLineEdit:focus {
                border: 1px solid #5a9bd5;
            }
            QComboBox {
                background-color: #ffffff;
                color: #333333;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 6px 10px;
                padding-right: 28px;
                font-size: 13px;
                min-height: 22px;
            }
            QComboBox:hover {
                border: 1px solid #5a9bd5;
            }
            QComboBox:focus {
                border: 1px solid #5a9bd5;
            }
            QComboBox::drop-down {
                border: none;
                width: 24px;
                background: transparent;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 6px solid #666666;
                width: 0;
                height: 0;
                margin-top: 2px;
            }
            QComboBox::down-arrow:on {
                border-top: none;
                border-bottom: 6px solid #666666;
            }
            QComboBox QAbstractItemView {
                background-color: #ffffff;
                color: #333333;
                selection-background-color: #5a9bd5;
                selection-color: #ffffff;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 4px 0;
                outline: none;
            }
            QComboBox QAbstractItemView::item {
                padding: 8px 12px;
                min-height: 20px;
            }
            QComboBox QAbstractItemView::item:hover {
                background-color: #e8f4fc;
                color: #333333;
            }
            QComboBox QAbstractItemView::item:selected {
                background-color: #5a9bd5;
                color: #ffffff;
            }
            QComboBox QAbstractItemView::item:disabled {
                background-color: #f5f5f5;
                color: #999999;
            }
            QPushButton {
                background-color: #5a9bd5;
                border: 1px solid #4a8bc5;
                border-radius: 4px;
                color: white;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #6aaee5;
            }
        """)

    def _on_save(self):
        """保存按钮点击处理"""
        name = self.name_input.currentText().strip()
        url = self.url_input.text().strip()
        key = self.key_input.text().strip()

        if not name:
            QMessageBox.warning(self, "输入错误", "请选择供应商名称")
            self.name_input.setFocus()
            return

        if not url:
            QMessageBox.warning(self, "输入错误", "请输入 URL 地址")
            self.url_input.setFocus()
            return

        if not key:
            if self._is_edit_mode:
                reply = QMessageBox.question(
                    self,
                    "确认更新",
                    "Key 为空，这将只更新 URL，保留原有的 Key。\n\n是否继续？",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No
                )
                if reply != QMessageBox.StandardButton.Yes:
                    self.key_input.setFocus()
                    return
                key = "__KEEP_ORIGINAL_KEY__"
            else:
                QMessageBox.warning(self, "输入错误", "请输入 Key")
                self.key_input.setFocus()
                return

        self._result = {
            "name": name,
            "url": url,
            "key": key
        }
        self.accept()

    def get_result(self) -> Optional[Dict[str, str]]:
        """获取配置结果"""
        return self._result

    def set_values(self, url: str = "", key: str = ""):
        """预设配置值"""
        self.url_input.setText(url)
        if not self._is_edit_mode:
            self.key_input.setText(key)


class ToolBlacklistTab(QWidget):
    """工具黑名单 Tab 页面"""

    # 默认黑名单（禁止危险工具）
    DEFAULT_BLACKLIST: set = set()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)

        self._blacklist: set[str] = set()
        self._setup_ui()
        self._load_blacklist()

    def _setup_ui(self):
        """设置 UI 界面"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        # 标题
        title_label = QLabel("AI 工具黑名单:")
        title_label.setStyleSheet("font-size: 14px; font-weight: bold; color: #333333;")
        layout.addWidget(title_label)

        # 说明
        info_label = QLabel("当 AI 调用黑名单中的工具时，会立即终止对话并自动回复。每行输入一个工具名称。")
        info_label.setStyleSheet("font-size: 12px; color: #666666;")
        info_label.setWordWrap(True)
        layout.addWidget(info_label)

        # 文本编辑区
        self.blacklist_edit = QTextEdit()
        self.blacklist_edit.setPlaceholderText("输入工具名称，每行一个...\n例如：\nshell\nbash")
        self.blacklist_edit.setStyleSheet("""
            QTextEdit {
                background-color: #ffffff;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 10px;
                font-size: 13px;
                color: #333333;
                font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            }
            QTextEdit:focus {
                border: 1px solid #5a9bd5;
            }
        """)
        layout.addWidget(self.blacklist_edit)

        # 按钮行
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()

        self.save_btn = QPushButton("保存")
        self.save_btn.setFixedWidth(80)
        self.save_btn.clicked.connect(self._on_save)
        self.save_btn.setStyleSheet("""
            QPushButton {
                background-color: #5a9bd5;
                border: 1px solid #4a8bc5;
                border-radius: 4px;
                color: white;
                padding: 6px 12px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #6aaee5;
            }
        """)
        btn_layout.addWidget(self.save_btn)

        layout.addLayout(btn_layout)

        # 常用工具提示
        tips_label = QLabel("常用工具参考：get_graph, get_node, add_node, remove_node, add_connection, "
                           "set_node_code, read_psa_atom, validate_psa_atom, auto_layout, reset_viewport")
        tips_label.setStyleSheet("font-size: 11px; color: #999999;")
        tips_label.setWordWrap(True)
        layout.addWidget(tips_label)

    def _load_blacklist(self):
        """从设置加载黑名单"""
        settings = QSettings("MyCompany", "NodeEditor")
        blacklist_str = settings.value("ai/tool_blacklist", "")
        if blacklist_str:
            self._blacklist = set(name.strip().lower() for name in blacklist_str.split('\n') if name.strip())
        else:
            self._blacklist = self.DEFAULT_BLACKLIST.copy()
        self._update_edit()

    def _update_edit(self):
        """更新文本编辑区"""
        self.blacklist_edit.setPlainText('\n'.join(sorted(self._blacklist)))

    def _on_save(self):
        """保存按钮点击"""
        self.save_blacklist()
        QMessageBox.information(self, "保存成功", "工具黑名单已保存")

    def save_blacklist(self):
        """保存黑名单到设置"""
        settings = QSettings("MyCompany", "NodeEditor")

        text = self.blacklist_edit.toPlainText()
        self._blacklist = set(name.strip().lower() for name in text.split('\n') if name.strip())

        settings.setValue("ai/tool_blacklist", '\n'.join(sorted(self._blacklist)))
        print(f"[Settings] 工具黑名单已保存: {self._blacklist}")
        return self._blacklist.copy()

    def get_blacklist(self) -> set[str]:
        """获取当前黑名单"""
        text = self.blacklist_edit.toPlainText()
        return set(name.strip().lower() for name in text.split('\n') if name.strip())


class SystemPromptTab(QWidget):
    """系统提示词 Tab 页面"""

    # 默认系统提示词
    DEFAULT_SYSTEM_PROMPT = ""

    def __init__(self, parent: Optional[QWidget] = None, chat_widget=None):
        super().__init__(parent)

        self._chat_widget = chat_widget
        self._system_prompt = self.DEFAULT_SYSTEM_PROMPT

        self._setup_ui()
        self._load_system_prompt()

    MAX_CHARS = 5000

    def _setup_ui(self):
        """设置 UI 界面"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        # 标题
        title_label = QLabel("系统提示词 (System Prompt):")
        title_label.setStyleSheet("font-size: 14px; font-weight: bold; color: #333333;")
        layout.addWidget(title_label)

        # 说明
        info_label = QLabel("设置 AI 的系统提示词，用于定义 AI 的行为和角色。修改后切换标签页或关闭窗口自动保存。")
        info_label.setStyleSheet("font-size: 12px; color: #666666;")
        info_label.setWordWrap(True)
        layout.addWidget(info_label)

        # 文本编辑区
        self.prompt_edit = QTextEdit()
        self.prompt_edit.setPlaceholderText("输入系统提示词...")
        self.prompt_edit.setStyleSheet("""
            QTextEdit {
                background-color: #ffffff;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 10px;
                font-size: 13px;
                color: #333333;
            }
            QTextEdit:focus {
                border: 1px solid #5a9bd5;
            }
        """)
        self.prompt_edit.textChanged.connect(self._on_text_changed)
        layout.addWidget(self.prompt_edit)

        # 字符计数标签
        self.char_count_label = QLabel("0 / 5000")
        self.char_count_label.setStyleSheet("font-size: 12px; color: #666666;")
        self.char_count_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        layout.addWidget(self.char_count_label)

        self._is_modified = False

    def _load_system_prompt(self):
        """加载当前的系统提示词"""
        if self._chat_widget and hasattr(self._chat_widget, '_system_prompt'):
            self._system_prompt = self._chat_widget._system_prompt
            self.prompt_edit.setPlainText(self._system_prompt)
        else:
            self.prompt_edit.setPlainText(self._system_prompt)
        self._is_modified = False
        self._update_char_count_label(len(self._system_prompt))

    def _on_text_changed(self):
        """文本变化时设置修改标记并检查字符限制"""
        text = self.prompt_edit.toPlainText()
        char_count = len(text)

        if char_count > self.MAX_CHARS:
            cursor = self.prompt_edit.textCursor()
            cursor_pos = cursor.position()

            self.prompt_edit.blockSignals(True)
            self.prompt_edit.setPlainText(text[:self.MAX_CHARS])
            self.prompt_edit.blockSignals(False)

            if cursor_pos > self.MAX_CHARS:
                cursor.setPosition(self.MAX_CHARS)
            else:
                cursor.setPosition(cursor_pos)
            self.prompt_edit.setTextCursor(cursor)

            char_count = self.MAX_CHARS

        self._update_char_count_label(char_count)
        self._is_modified = True

    def _update_char_count_label(self, count: int):
        """更新字符计数标签"""
        self.char_count_label.setText(f"{count} / {self.MAX_CHARS}")
        if count >= self.MAX_CHARS * 0.9:
            self.char_count_label.setStyleSheet("font-size: 12px; color: #F44336; font-weight: bold;")
        elif count >= self.MAX_CHARS * 0.7:
            self.char_count_label.setStyleSheet("font-size: 12px; color: #FFC107;")
        else:
            self.char_count_label.setStyleSheet("font-size: 12px; color: #666666;")

    def is_modified(self) -> bool:
        """检查是否有修改"""
        return self._is_modified

    def save_if_modified(self) -> bool:
        """如果有修改则保存，返回是否执行了保存"""
        if not self._is_modified:
            return False

        new_prompt = self.prompt_edit.toPlainText().strip()
        if not new_prompt:
            new_prompt = self.DEFAULT_SYSTEM_PROMPT

        self._system_prompt = new_prompt

        if self._chat_widget:
            if hasattr(self._chat_widget, '_system_prompt'):
                self._chat_widget._system_prompt = new_prompt
            if hasattr(self._chat_widget, '_messages'):
                for msg in self._chat_widget._messages:
                    if msg.get('role') == 'system':
                        msg['content'] = new_prompt
                        break

        self._is_modified = False
        return True

    def get_system_prompt(self) -> str:
        """获取当前系统提示词"""
        return self._system_prompt


class QAISettingsDialog(QDialog):
    """
    QAI 设置对话框 - 左侧 Tab 布局

    Tabs:
    1. API 配置 - 管理 AI 供应商配置
    2. 系统提示 - 设置系统提示词
    3. 工具黑名单 - 设置禁用的 AI 工具
    """

    def __init__(self, parent: Optional[QWidget] = None, chat_widget=None):
        super().__init__(parent)

        self._chat_widget = chat_widget

        self.setWindowTitle("设置")
        self.setMinimumSize(600, 450)
        self.resize(700, 500)

        self._setup_ui()

    def _setup_ui(self):
        """设置 UI 界面"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 创建 TabWidget，tab 在顶部
        self.tab_widget = QTabWidget()
        self.tab_widget.setTabPosition(QTabWidget.TabPosition.North)
        self.tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: none;
                background-color: #f5f5f5;
            }
            QTabBar::tab {
                background-color: #e0e0e0;
                border: 1px solid #cccccc;
                padding: 8px 24px;
                margin-right: -1px;
                font-size: 13px;
                min-width: 60px;
            }
            QTabBar::tab:selected {
                background-color: #f5f5f5;
                border-bottom: none;
                font-weight: bold;
            }
            QTabBar::tab:!selected {
                background-color: #e8e8e8;
            }
            QTabBar::tab:hover:!selected {
                background-color: #d8d8d8;
            }
        """)

        # API 配置 Tab
        self.api_tab = APIConfigTab(self)
        self.tab_widget.addTab(self.api_tab, "API")

        # 系统提示 Tab
        self.system_tab = SystemPromptTab(self, self._chat_widget)
        self.tab_widget.addTab(self.system_tab, "提示词")

        # 工具黑名单 Tab
        self.blacklist_tab = ToolBlacklistTab(self)
        self.tab_widget.addTab(self.blacklist_tab, "工具黑名单")

        self._current_tab_index = 0
        self.tab_widget.currentChanged.connect(self._on_tab_changed)

        layout.addWidget(self.tab_widget)

        # 底部按钮栏
        btn_layout = QHBoxLayout()
        btn_layout.setContentsMargins(15, 10, 15, 15)
        btn_layout.addStretch()

        self.close_btn = QPushButton("关闭")
        self.close_btn.setFixedWidth(100)
        self.close_btn.clicked.connect(self.accept)
        self.close_btn.setStyleSheet("""
            QPushButton {
                background-color: #5a9bd5;
                border: 1px solid #4a8bc5;
                border-radius: 4px;
                color: white;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #6aaee5;
            }
        """)
        btn_layout.addWidget(self.close_btn)

        layout.addLayout(btn_layout)

    def get_api_providers(self) -> Dict[str, Dict[str, str]]:
        """获取 API 供应商配置"""
        return self.api_tab.get_providers()

    def get_system_prompt(self) -> str:
        """获取系统提示词"""
        return self.system_tab.get_system_prompt()

    def get_tool_blacklist(self) -> set[str]:
        """获取工具黑名单"""
        return self.blacklist_tab.get_blacklist()

    def _on_tab_changed(self, new_index: int):
        """Tab 切换时保存之前的 tab 内容"""
        if self._current_tab_index == 1:
            if self.system_tab.save_if_modified():
                print("[Settings] 系统提示词已自动保存")

        if self._current_tab_index == 2:
            self.blacklist_tab.save_blacklist()
            print("[Settings] 工具黑名单已自动保存")

        self._current_tab_index = new_index

    def closeEvent(self, event):
        """关闭窗口时保存修改"""
        if self.system_tab.save_if_modified():
            print("[Settings] 系统提示词已自动保存")

        self.blacklist_tab.save_blacklist()
        print("[Settings] 工具黑名单已自动保存")

        event.accept()


def ShowSettingsDialog(parent: Optional[QWidget] = None,
                         chat_widget=None) -> Optional[Dict[str, Any]]:
    """
    显示设置对话框

    Args:
        parent: 父窗口
        chat_widget: AI GUI 的 chat_widget 引用，用于更新系统提示词

    Returns:
        包含 providers、system_prompt 和 tool_blacklist 的字典，如果用户取消返回 None
    """
    dialog = QAISettingsDialog(parent, chat_widget)

    if dialog.exec() == QDialog.DialogCode.Accepted:
        return {
            'providers': dialog.get_api_providers(),
            'system_prompt': dialog.get_system_prompt(),
            'tool_blacklist': dialog.get_tool_blacklist()
        }

    return None


def LoadSettings() -> Dict[str, Any]:
    """
    加载所有设置

    Returns:
        包含 providers、system_prompt 和 tool_blacklist 的字典
    """
    config = QAIConfig()
    providers = config.load() or {}

    settings = QSettings("MyCompany", "NodeEditor")
    blacklist_str = settings.value("ai/tool_blacklist", "")
    if blacklist_str:
        tool_blacklist = set(name.strip() for name in blacklist_str.split('\n') if name.strip())
    else:
        tool_blacklist = ToolBlacklistTab.DEFAULT_BLACKLIST.copy()

    return {
        'providers': providers,
        'system_prompt': SystemPromptTab.DEFAULT_SYSTEM_PROMPT,
        'tool_blacklist': tool_blacklist
    }


def LoadToolBlacklist() -> set[str]:
    """
    加载工具黑名单

    Returns:
        黑名单工具名称集合（小写）
    """
    settings = QSettings("MyCompany", "NodeEditor")
    blacklist_str = settings.value("ai/tool_blacklist", "")
    if blacklist_str:
        return set(name.strip().lower() for name in blacklist_str.split('\n') if name.strip())
    return ToolBlacklistTab.DEFAULT_BLACKLIST.copy()


# 测试代码
if __name__ == "__main__":

    app = QApplication(sys.argv)
    app.setStyle('Fusion')

    result = ShowSettingsDialog()

    if result:
        print(f"\n设置已保存:")
        print(f"  供应商数量: {len(result['providers'])}")
        print(f"  系统提示词: {result['system_prompt'][:50]}...")
    else:
        print("\n用户取消")

    sys.exit(0)
