# -*- coding: utf-8 -*-
"""
AI GUI 对话界面 - 基于 PyQt6 + AICore + KimiAI

功能特性:
- 流式输出显示
- 思考过程折叠显示
- Markdown 渲染支持
- 对话历史管理
- 系统提示设置
"""

import markdown
from markdown.extensions import fenced_code, tables, nl2br
import re
import weakref
from PyQt6.QtCore import QTimer
from .qsettings import AISettingsDialog
from ai.canvas_tools import install_event_handler
from ai.canvas_api import BackupManager
from ai.canvas_api import CanvasAPI
import traceback


import sys
import os
import time
import asyncio
from typing import Optional, Dict
from dataclasses import dataclass

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTextEdit, QLineEdit, QPushButton, QLabel, QScrollArea,
    QFrame, QSplitter, QToolBar, QStatusBar, QMenu, QSystemTrayIcon,
    QDialog, QPlainTextEdit, QMessageBox, QSizePolicy, QSpacerItem,
    QFileDialog, QApplication, QTextBrowser, QGraphicsOpacityEffect
)
from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, QRunnable, QThreadPool, QObject,
    QMetaObject, Q_ARG, QTimer, QSize, QPropertyAnimation, QEasingCurve
)
from PyQt6.QtGui import (
    QFont, QColor, QPalette, QPainter, QPen, QBrush, QFontMetrics,
    QAction, QIcon, QTextCursor, QKeyEvent, QTextCharFormat, QTextDocument
)


class CircularProgressBar(QWidget):
    """
    环形进度条控件

    显示上下文使用百分比，颜色根据使用程度变化：
    - 0-50%: 绿色
    - 50-80%: 黄色
    - 80-100%: 红色
    """

    def __init__(self, parent=None, size=32):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self._percentage = 0.0
        self._max_tokens = 0
        self._current_tokens = 0

    def set_max_tokens(self, max_tokens: int):
        """设置最大 token 数"""
        self._max_tokens = max_tokens
        self.update()

    def set_current_tokens(self, current_tokens: int):
        """设置当前 token 数"""
        self._current_tokens = current_tokens
        if self._max_tokens > 0:
            self._percentage = min(100.0, (current_tokens / self._max_tokens) * 100.0)
        else:
            self._percentage = 0.0
        self.update()

    def set_percentage(self, percentage: float):
        """直接设置百分比 (0-100)"""
        self._percentage = max(0.0, min(100.0, percentage))
        self.update()

    def get_color(self) -> QColor:
        """根据百分比返回颜色"""
        if self._percentage < 50:
            return QColor("#4CAF50")  # 绿色
        elif self._percentage < 80:
            return QColor("#FFC107")  # 黄色
        else:
            return QColor("#F44336")  # 红色

    def paintEvent(self, event):
        """绘制环形进度条"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # 获取绘制区域
        rect = self.rect()
        size = min(rect.width(), rect.height())
        margin = 4
        rect_size = size - 2 * margin

        # 中心点
        center = rect.center()

        # 绘制背景圆环
        bg_pen = QPen(QColor("#E0E0E0"))
        bg_pen.setWidth(3)
        bg_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(bg_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(center, rect_size // 2 - 2, rect_size // 2 - 2)

        # 绘制进度圆环
        if self._percentage > 0:
            progress_pen = QPen(self.get_color())
            progress_pen.setWidth(3)
            progress_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            painter.setPen(progress_pen)

            # 计算角度（从顶部开始，顺时针）
            start_angle = 90 * 16  # 从顶部开始（Qt 角度：0 是 3 点钟方向，90 是 12 点钟方向）
            span_angle = -int(self._percentage * 3.6 * 16)  # 负值表示顺时针

            painter.drawArc(
                center.x() - rect_size // 2 + 2,
                center.y() - rect_size // 2 + 2,
                rect_size - 4,
                rect_size - 4,
                start_angle,
                span_angle
            )

        # 绘制百分比文字
        painter.setPen(QColor("#333333"))
        font = QFont("Microsoft YaHei", 8, QFont.Weight.Bold)
        painter.setFont(font)

        text = f"{int(self._percentage)}%"
        text_rect = painter.boundingRect(rect, Qt.AlignmentFlag.AlignCenter, text)
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter, text)

        painter.end()


# 导入 markdown 库（如果没有则使用简单方案）
try:
    MARKDOWN_AVAILABLE = True
except ImportError:
    MARKDOWN_AVAILABLE = False

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ai.ai_onion import AICore, Message
import ai.kimi_ai  # 自动注册 Kimi，作为提供方
# import ai.deepseek_ai
# import ai.qwen_ai
# import ai.empty_ai  # 使用 EmptyAI 作为默认实现


class WorkerSignals(QObject):
    """工作器信号定义"""

    finished = pyqtSignal()
    error = pyqtSignal(str)
    result = pyqtSignal(object)
    chunk = pyqtSignal(dict)  # 流式输出块
    token_usage = pyqtSignal(dict)  # token 使用信息
    tool_call = pyqtSignal(dict)  # 工具调用信息


class MessageWidgetSignals(QObject):
    """消息组件信号定义"""

    undo_requested = pyqtSignal(int)  # 参数: message_index


class ToolCallWidget(QFrame):
    """工具调用显示组件 - 显示简短的工具调用信息"""

    def __init__(self, tool_name: str, tool_id: str = "", status: str = "pending", result: str = "", parent=None):
        super().__init__(parent)
        self.tool_name = tool_name
        self.tool_id = tool_id
        self.status = status  # pending, running, success, error
        self.result = result
        self._start_time = None  # 开始时间
        self._elapsed_ms = 0  # 已耗时（毫秒）
        self._timer = QTimer(self)  # 计时器
        self._timer.timeout.connect(self._update_elapsed_time)
        self._setup_ui()

    def _setup_ui(self):
        """设置 UI"""
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setStyleSheet("""
            ToolCallWidget {
                background-color: #f8f9fa;
                border-radius: 6px;
                border: 1px solid #e0e0e0;
                padding: 4px;
            }
        """)
        self.setMaximumWidth(280)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(8)

        # 工具名称
        self.name_label = QLabel(f"🔧 {self.tool_name}")
        self.name_label.setStyleSheet("""
            font-size: 12px;
            color: #333;
            font-weight: 500;
        """)
        layout.addWidget(self.name_label)

        layout.addStretch()

        # 耗时标签（在状态标签左边）
        self.time_label = QLabel()
        self.time_label.setStyleSheet("""
            font-size: 11px;
            color: #666;
            padding: 2px 6px;
        """)
        self.time_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        layout.addWidget(self.time_label)

        # 状态标签
        self.status_label = QLabel()
        self.status_label.setStyleSheet("""
            font-size: 11px;
            padding: 2px 6px;
            border-radius: 3px;
        """)
        layout.addWidget(self.status_label)

        self._update_status_display()

        # 如果初始状态是 running，启动计时器
        if self.status == "running":
            self._start_timer()

    def _update_status_display(self):
        """更新状态显示"""
        status_styles = {
            "pending": ("⏳", "待执行", "#999", "#f0f0f0"),
            "running": ("▶️", "执行中", "#2196F3", "#E3F2FD"),
            "success": ("✅", "完成", "#4CAF50", "#E8F5E9"),
            "error": ("❌", "失败", "#F44336", "#FFEBEE"),
        }

        icon, text, color, bg_color = status_styles.get(self.status, status_styles["pending"])
        self.status_label.setText(icon)
        self.status_label.setStyleSheet(f"""
            font-size: 11px;
            color: {color};
            background-color: {bg_color};
            padding: 2px 8px;
            border-radius: 4px;
        """)

        # 根据状态更新边框颜色
        border_colors = {
            "pending": "#e0e0e0",
            "running": "#2196F3",
            "success": "#4CAF50",
            "error": "#F44336",
        }
        border_color = border_colors.get(self.status, "#e0e0e0")
        self.setStyleSheet(f"""
            ToolCallWidget {{
                background-color: #f8f9fa;
                border-radius: 6px;
                border: 1px solid {border_color};
                padding: 4px;
            }}
        """)

    def _format_elapsed_time(self, elapsed_ms: int) -> str:
        """格式化耗时显示
        - 小于3秒: 显示为 ms (整数)
        - 3-60秒: 显示为 ?s, 允许一位小数
        - 大于60秒: 显示为 ?m?s, 都是整数
        """
        seconds = elapsed_ms / 1000.0
        if seconds < 3:
            # ms 必须是整数
            return f"{int(elapsed_ms)}ms"
        elif seconds <= 60:
            # s 允许一位小数
            return f"{seconds:.1f}s"
        else:
            # m?s 格式，都是整数
            minutes = int(seconds // 60)
            remaining_seconds = int(seconds % 60)
            if remaining_seconds == 0:
                return f"{minutes}m"
            else:
                return f"{minutes}m{remaining_seconds}s"

    def _update_elapsed_time(self):
        """更新耗时显示（定时器回调）"""
        if self._start_time is not None:
            self._elapsed_ms = int((time.time() - self._start_time) * 1000)
            self.time_label.setText(self._format_elapsed_time(self._elapsed_ms))

    def _start_timer(self):
        """开始计时"""
        self._start_time = time.time()
        self._elapsed_ms = 0
        self._update_elapsed_time()  # 立即更新一次
        self._timer.start(1000)  # 每秒更新一次

    def _stop_timer(self):
        """停止计时"""
        self._timer.stop()
        if self._start_time is not None:
            self._elapsed_ms = int((time.time() - self._start_time) * 1000)
            self._start_time = None
        # 更新显示（即使 _start_time 为 None 也要更新 label）
        self.time_label.setText(self._format_elapsed_time(self._elapsed_ms))

    def update_status(self, status: str, result: str = ""):
        """更新工具调用状态"""
        # 状态变化时处理计时器
        if status == "running" and self.status != "running":
            # 开始执行，启动计时器
            self._start_timer()
        elif status in ("success", "error") and self.status == "running":
            # 执行完成，停止计时器
            self._stop_timer()

        self.status = status
        if result:
            # 过滤掉替换字符 U+FFFD 和零宽空格 U+200B
            self.result = result.replace('\ufffd', '').replace('\u200b', '')
        self._update_status_display()

    def mouseDoubleClickEvent(self, event):
        """双击显示详细信息"""
        if self.result:
            dialog = QDialog(self)
            dialog.setWindowTitle(f"工具调用详情 - {self.tool_name}")
            dialog.setMinimumSize(500, 300)

            layout = QVBoxLayout(dialog)

            text_edit = QPlainTextEdit()
            text_edit.setPlainText(self.result)
            text_edit.setReadOnly(True)
            layout.addWidget(text_edit)

            btn = QPushButton("关闭")
            btn.clicked.connect(dialog.accept)
            layout.addWidget(btn)

            dialog.exec()


class StreamWorker(QRunnable):
    """流式输出工作器"""

    def __init__(self, ai: AICore, messages: list[Message], tool_definitions=None, tool_executor=None, canvas=None):
        super().__init__()
        self.ai = ai
        self.messages = messages
        self.tool_definitions = tool_definitions or []  # OpenAI 格式的工具定义
        self.tool_executor = tool_executor  # 工具执行器
        self.canvas = canvas
        self.signals = WorkerSignals()
        self._is_running = True
        self._canvas_tool_ids = set()  # 跟踪已发出的 Canvas 工具调用 ID

    def run(self):
        """运行异步流式任务"""
        try:
            asyncio.run(self._stream())
        except Exception as e:
            self.signals.error.emit(str(e))
        finally:
            self.signals.finished.emit()

    async def _stream(self):
        """执行流式请求"""
        # 确定是否使用工具 - 只要有工具定义就传递
        tools = self.tool_definitions if self.tool_definitions else None

        try:
            async for chunk in self.ai.chat_stream(
                self.messages,
                tools=tools,
                tool_executor=self.tool_executor,
                max_steps_per_turn=self.ai.max_steps_per_turn if tools else 1
            ):
                if not self._is_running:
                    break

                chunk_type = chunk.get("type")

                # 处理思考过程和内容
                if chunk_type in ("reasoning_start", "reasoning", "reasoning_end", "content"):
                    self.signals.chunk.emit(chunk)

                # 处理工具调用
                elif chunk_type == "tool_call":
                    tool_name = chunk.get("name", "")
                    tool_id = chunk.get("id", "")
                    # 存储 name -> id 映射，供 ToolResult 使用
                    if not hasattr(self, '_tool_name_to_id'):
                        self._tool_name_to_id = {}
                    self._tool_name_to_id[tool_name] = tool_id
                    # 显示所有工具调用（不仅限于画布工具）
                    self._canvas_tool_ids.add(tool_id)
                    self.signals.tool_call.emit({
                        "type": "tool_call",
                        "tool_name": tool_name,
                        "tool_id": tool_id,
                        "status": "running"
                    })

                # 处理工具结果
                elif chunk_type == "tool_result":
                    tool_name = chunk.get("name", "")
                    result = chunk.get("result", "")
                    success = chunk.get("success", True)
                    # 优先使用 chunk 中的 id，如果没有则尝试从映射中获取
                    tool_id = chunk.get("id", "")
                    if not tool_id and tool_name:
                        tool_id = getattr(self, '_tool_name_to_id', {}).get(tool_name, "")
                    if tool_name or tool_id:
                        self.signals.tool_call.emit({
                            "type": "tool_result",
                            "tool_name": tool_name,
                            "tool_id": tool_id,
                            "status": "success" if success else "error",
                            "result": result
                        })

                # 处理 token 使用信息
                elif chunk_type == "token_usage":
                    usage = chunk.get("usage", {})
                    self.signals.token_usage.emit(usage)

        except Exception as e:
            # 如果失败，尝试不带工具重试
            if tools:
                print(f"Tool call failed, falling back to normal stream: {e}")
                traceback.print_exc()
                async for chunk in self.ai.chat_stream(self.messages):
                    if not self._is_running:
                        break
                    self.signals.chunk.emit(chunk)
            else:
                raise

    def stop(self):
        """停止流式输出"""
        self._is_running = False


@dataclass
class MessageData:
    """消息数据类"""
    role: str  # "user", "assistant", "system"
    content: str
    reasoning: Optional[str] = None


class MarkdownTextBrowser(QTextBrowser):
    """支持 Markdown 渲染的文本浏览器 - 自动适应高度"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setOpenExternalLinks(True)
        self.setReadOnly(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        self.document().contentsChanged.connect(self._update_height)

        # 确保使用 UTF-8 编码
        self.document().setDocumentMargin(4)
        # 设置默认字体，确保支持中文显示
        font = QFont("Microsoft YaHei", 10)
        font.setStyleHint(QFont.StyleHint.SansSerif)
        self.setFont(font)
        self.setStyleSheet("""
            QTextBrowser {
                background-color: transparent;
                border: none;
                font-size: 13px;
                line-height: 1.6;
                font-family: "Microsoft YaHei", "PingFang SC", "Hiragino Sans GB", "Noto Sans CJK SC", sans-serif;
            }
            /* 代码块样式 */
            pre {
                background-color: #f5f5f5;
                border-radius: 6px;
                padding: 12px;
                margin: 8px 0;
                font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
                font-size: 12px;
                overflow-x: auto;
                white-space: pre-wrap;
                word-wrap: break-word;
            }
            code {
                background-color: #f0f0f0;
                padding: 2px 6px;
                border-radius: 3px;
                font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
                font-size: 12px;
            }
            /* 表格样式 */
            table {
                border-collapse: collapse;
                margin: 8px 0;
                width: 100%;
            }
            th, td {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }
            th {
                background-color: #f5f5f5;
                font-weight: bold;
            }
            /* 引用块 */
            blockquote {
                border-left: 4px solid #ddd;
                margin: 8px 0;
                padding: 8px 16px;
                color: #666;
                background-color: #f9f9f9;
            }
            /* 列表 */
            ul, ol {
                margin: 8px 0;
                padding-left: 24px;
            }
            li {
                margin: 4px 0;
            }
            /* 标题 */
            h1, h2, h3, h4, h5, h6 {
                margin: 12px 0 8px 0;
                font-weight: bold;
            }
            h1 { font-size: 20px; }
            h2 { font-size: 18px; }
            h3 { font-size: 16px; }
            h4, h5, h6 { font-size: 14px; }
            /* 链接 */
            a {
                color: #2196F3;
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }
            /* 分割线 */
            hr {
                border: none;
                border-top: 1px solid #ddd;
                margin: 16px 0;
            }
            /* LaTeX 公式占位 */
            .math {
                background-color: #f8f8f8;
                padding: 4px 8px;
                border-radius: 4px;
                font-family: 'Times New Roman', serif;
                font-style: italic;
            }
        """)

        # 初始化 markdown 转换器
        if MARKDOWN_AVAILABLE:
            self.md = markdown.Markdown(extensions=[
                'fenced_code',
                'tables',
                'nl2br',
                'toc',
            ])
        else:
            self.md = None

        self.raw_text = ""

    def setMarkdownText(self, text: str):
        """设置并渲染 Markdown 文本"""
        # 过滤掉替换字符 U+FFFD 和零宽空格 U+200B
        # U+FFFD (�) 表示无法解码的字符
        text = text.replace('\ufffd', '').replace('\u200b', '')

        # 确保文本是有效的 UTF-8 字符串
        try:
            # 如果文本是 bytes，解码为 UTF-8
            if isinstance(text, bytes):
                text = text.decode('utf-8', errors='ignore')
        except Exception:
            pass

        self.raw_text = text

        if self.md:
            self.md.reset()
            html = self.md.convert(text)
        else:
            # 简单的 Markdown 处理（无外部库时）
            html = self._simple_markdown_to_html(text)

        # 包装在完整的 HTML 文档中，使用 UTF-8 编码
        # 添加更多中文字体支持，确保字符正确显示
        full_html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style>
        body {{
            font-family: 'Microsoft YaHei', 'PingFang SC', 'Hiragino Sans GB', 'Noto Sans CJK SC', 'Source Han Sans CN', 'WenQuanYi Micro Hei', 'Segoe UI', sans-serif;
            font-size: 13px;
            line-height: 1.6;
        }}
    </style>
</head>
<body>
{html}
</body>
</html>"""
        # 使用 setHtml 设置 HTML 内容
        self.setHtml(full_html)
        # 设置完 HTML 后更新高度
        QTimer.singleShot(10, self._update_height)

    def _update_height(self):
        """根据内容自动调整高度，最大600px"""
        MAX_HEIGHT = 600
        doc = self.document()
        doc.setTextWidth(self.viewport().width())
        content_height = int(doc.size().height() + 10)  # 加一点边距

        if content_height <= MAX_HEIGHT:
            # 内容较少，自适应高度，隐藏滚动条
            self.setMinimumHeight(content_height)
            self.setMaximumHeight(content_height)
            self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        else:
            # 内容较多，固定最大高度，显示滚动条
            self.setMinimumHeight(MAX_HEIGHT)
            self.setMaximumHeight(MAX_HEIGHT)
            self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

    def resizeEvent(self, event):
        """窗口大小变化时重新计算高度"""
        super().resizeEvent(event)
        self._update_height()

    def appendMarkdownText(self, text: str):
        """追加 Markdown 文本（用于流式输出）"""
        self.raw_text += text
        self.setMarkdownText(self.raw_text)

    def _simple_markdown_to_html(self, text: str) -> str:
        """简单的 Markdown 转 HTML（备用方案）"""

        # 先处理代码块（在转义之前）
        code_blocks = []

        def code_block_repl(match):
            lang = match.group(1) or ""
            code = match.group(2)
            # 转义代码块内的 HTML
            code = code.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            placeholder = f"\x00CODEBLOCK{len(code_blocks)}\x00"
            code_blocks.append(f'<pre><code class="language-{lang}">{code}</code></pre>')
            return placeholder

        text = re.sub(r'```(\w+)?\n(.*?)```', code_block_repl, text, flags=re.DOTALL)

        # 转义 HTML 特殊字符（代码块外）
        text = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

        # 行内代码 `...`
        text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)

        # 粗体 **...**
        text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)

        # 斜体 *...*
        text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', text)

        # 标题
        text = re.sub(r'^### (.+)$', r'<h3>\1</h3>', text, flags=re.MULTILINE)
        text = re.sub(r'^## (.+)$', r'<h2>\1</h2>', text, flags=re.MULTILINE)
        text = re.sub(r'^# (.+)$', r'<h1>\1</h1>', text, flags=re.MULTILINE)

        # 列表
        lines = text.split('\n')
        result = []
        in_list = False
        for line in lines:
            if line.strip().startswith('- ') or line.strip().startswith('* '):
                if not in_list:
                    result.append('<ul>')
                    in_list = True
                content = line.strip()[2:]
                result.append(f'<li>{content}</li>')
            else:
                if in_list:
                    result.append('</ul>')
                    in_list = False
                result.append(line)
        if in_list:
            result.append('</ul>')
        text = '\n'.join(result)

        # 链接 [text](url)
        text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', text)

        # 分割线
        text = re.sub(r'^---+$', '<hr>', text, flags=re.MULTILINE)

        # 引用块
        lines = text.split('\n')
        result = []
        in_quote = False
        for line in lines:
            if line.strip().startswith('> '):
                if not in_quote:
                    result.append('<blockquote>')
                    in_quote = True
                content = line.strip()[2:]
                result.append(content + '<br>')
            else:
                if in_quote:
                    result.append('</blockquote>')
                    in_quote = False
                result.append(line)
        if in_quote:
            result.append('</blockquote>')
        text = '\n'.join(result)

        # 段落（简单处理）
        paragraphs = text.split('\n\n')
        text = '\n\n'.join(f'<p>{p}</p>' if not p.startswith('<') else p for p in paragraphs)

        # 还原代码块
        for i, block in enumerate(code_blocks):
            text = text.replace(f"\x00CODEBLOCK{i}\x00", block)

        return text


class ReasoningBlockWidget(QFrame):
    """单个思考块组件 - 支持多次思考"""

    _counter = 0  # 类级别的计数器，用于生成思考块编号

    def __init__(self, block_index: int = 0, parent=None):
        super().__init__(parent)
        self.block_index = block_index
        self.reasoning_expanded = True  # 默认展开
        self._setup_ui()

    def _setup_ui(self):
        """设置 UI"""
        self.setStyleSheet("""
            QFrame {
                background-color: #f5f5f5;
                border-radius: 6px;
                border-left: 3px solid #9e9e9e;
            }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(4)

        # 思考过程标题（可点击折叠）
        self.reasoning_header = QPushButton(f"💭 思考过程 #{self.block_index + 1} ▼")
        self.reasoning_header.setStyleSheet("""
            QPushButton {
                border: none;
                color: #666;
                font-size: 11px;
                text-align: left;
                padding: 2px;
            }
            QPushButton:hover {
                color: #333;
            }
        """)
        self.reasoning_header.setCursor(Qt.CursorShape.PointingHandCursor)
        self.reasoning_header.clicked.connect(self._toggle_reasoning)
        layout.addWidget(self.reasoning_header)

        # 思考内容 - 使用 MarkdownTextBrowser，限制最大高度
        self.reasoning_content = MarkdownTextBrowser()
        self.reasoning_content.setMaximumHeight(400)  # 最大高度 400px
        layout.addWidget(self.reasoning_content)

    def _toggle_reasoning(self):
        """切换思考过程显示/隐藏"""
        self.reasoning_expanded = not self.reasoning_expanded
        self.reasoning_content.setVisible(self.reasoning_expanded)
        arrow = "▼" if self.reasoning_expanded else "▶"
        self.reasoning_header.setText(f"💭 思考过程 #{self.block_index + 1} {arrow}")

    def set_reasoning_finished(self):
        """标记思考完成，自动折叠"""
        self.reasoning_header.setText(f"💭 思考过程 #{self.block_index + 1} ▶")
        if self.reasoning_expanded:
            self._toggle_reasoning()  # 折叠起来

    def append_reasoning(self, text: str):
        """追加思考内容"""
        self.reasoning_content.appendMarkdownText(text)
        # 滚动到底部显示最新内容
        try:
            scrollbar = self.reasoning_content.verticalScrollBar()
            if scrollbar:
                scrollbar.setValue(scrollbar.maximum())
        except Exception:
            pass  # 忽略滚动错误


class MessageWidget(QFrame):
    """消息显示组件"""

    def __init__(self, message_data: MessageData, message_index: int = -1, parent=None):
        super().__init__(parent)
        self.message_data = message_data
        self.message_index = message_index  # 消息索引（用于回滚）
        self.signals = MessageWidgetSignals()
        self._hover_panel = None
        # 存储思考块和工具调用控件，保持顺序
        self._reasoning_blocks: list[ReasoningBlockWidget] = []
        self._tool_call_widgets: dict[str, ToolCallWidget] = {}
        self._tool_call_by_name: dict[str, ToolCallWidget] = {}  # 通过名称索引
        self._current_reasoning_block: ReasoningBlockWidget | None = None
        self._content_insert_index = 1  # 内容应该在头部之后插入
        # 工具调用行管理
        self._tool_call_rows: list[QWidget] = []  # 存储所有行容器
        self._current_tool_call_row: QWidget | None = None  # 当前行容器
        self._current_row_tool_count = 0  # 当前行中的工具调用数量
        self._setup_ui()

    def _setup_ui(self):
        """设置 UI"""
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        # 启用鼠标跟踪以支持 hover 效果
        self.setMouseTracking(True)
        self.setAttribute(Qt.WidgetAttribute.WA_Hover, True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 8)
        layout.setSpacing(4)

        # 头部（角色标识 + 操作按钮）
        header_layout = QHBoxLayout()

        role_label = QLabel(self._get_role_display())
        role_label.setStyleSheet(f"""
            font-weight: bold;
            color: {self._get_role_color()};
            font-size: 12px;
        """)
        header_layout.addWidget(role_label)
        header_layout.addStretch()

        # 为所有消息添加操作按钮面板（用户消息显示复制和撤销）
        self._hover_panel = QWidget()
        hover_layout = QHBoxLayout(self._hover_panel)
        hover_layout.setContentsMargins(0, 0, 0, 0)
        hover_layout.setSpacing(4)

        # 复制按钮（所有消息都有）
        copy_btn = QPushButton("📚")
        copy_btn.setToolTip("复制内容")
        copy_btn.setStyleSheet("""
            QPushButton {
                border: none;
                background-color: transparent;
                font-size: 14px;
                padding: 2px 6px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: rgba(0, 0, 0, 0.1);
            }
        """)
        copy_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        copy_btn.clicked.connect(self._on_copy)
        hover_layout.addWidget(copy_btn)

        # 撤销按钮（仅用户消息有，且需要有有效索引）
        if self.message_data.role == "user" and self.message_index >= 0:
            undo_btn = QPushButton("↩️")
            undo_btn.setToolTip("撤销到此消息（恢复输入并回滚图）")
            undo_btn.setStyleSheet("""
                QPushButton {
                    border: none;
                    background-color: transparent;
                    font-size: 14px;
                    padding: 2px 6px;
                    border-radius: 4px;
                }
                QPushButton:hover {
                    background-color: rgba(255, 0, 0, 0.1);
                }
            """)
            undo_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            undo_btn.clicked.connect(self._on_undo)
            hover_layout.addWidget(undo_btn)

        header_layout.addWidget(self._hover_panel)

        layout.addLayout(header_layout)

        # 内容浏览器 - 消息主体内容
        self.content_browser = MarkdownTextBrowser()
        self.content_browser.setMarkdownText(self.message_data.content)
        # 暂时添加到布局，后续会根据思考块动态调整位置
        layout.addWidget(self.content_browser)

        # 设置背景色
        self.setStyleSheet(f"""
            MessageWidget {{
                background-color: {self._get_bg_color()};
                border-radius: 8px;
                border: 1px solid {self._get_border_color()};
            }}
        """)

    def _get_role_display(self) -> str:
        """获取角色显示名称"""
        role_map = {
            "user": "👤 用户",
            "assistant": "🤖 助手",
            "system": "⚙️ 系统"
        }
        return role_map.get(self.message_data.role, self.message_data.role)

    def _get_role_color(self) -> str:
        """获取角色标识颜色"""
        color_map = {
            "user": "#2196F3",
            "assistant": "#4CAF50",
            "system": "#9E9E9E"
        }
        return color_map.get(self.message_data.role, "#333")

    def _get_bg_color(self) -> str:
        """获取背景颜色"""
        bg_map = {
            "user": "#E3F2FD",
            "assistant": "#F1F8E9",
            "system": "#F5F5F5"
        }
        return bg_map.get(self.message_data.role, "#FFF")

    def _get_border_color(self) -> str:
        """获取边框颜色"""
        border_map = {
            "user": "#BBDEFB",
            "assistant": "#DCEDC8",
            "system": "#E0E0E0"
        }
        return border_map.get(self.message_data.role, "#DDD")

    def update_content(self, content: str):
        """更新消息内容（用于流式输出）"""
        self.message_data.content = content
        self.content_browser.setMarkdownText(content)

    def append_content(self, text: str):
        """追加内容（用于流式输出）"""
        self.message_data.content += text
        self.content_browser.appendMarkdownText(text)

    def start_new_reasoning(self) -> ReasoningBlockWidget:
        """开始新的思考块 - 在创建新思考块之前先封存当前内容"""
        # 先封存当前内容浏览器（如果有内容的话）
        self._freeze_current_content()

        block_index = len(self._reasoning_blocks)
        block = ReasoningBlockWidget(block_index=block_index, parent=self)
        self._reasoning_blocks.append(block)
        self._current_reasoning_block = block

        # 插入到 content_browser 之前
        layout = self.layout()
        content_index = -1
        for i in range(layout.count()):
            item = layout.itemAt(i)
            if item and item.widget() == self.content_browser:
                content_index = i
                break

        if content_index >= 0:
            layout.insertWidget(content_index, block)
        else:
            layout.addWidget(block)

        return block

    def _freeze_current_content(self):
        """将当前内容浏览器设为只读并创建新的"""
        # 只有当有内容时才封存
        if hasattr(self, 'content_browser') and self.content_browser.raw_text.strip():
            # 将当前 content_browser 设为只读
            self.content_browser.setReadOnly(True)
            # 记录这个 content_browser 已经封存
            if not hasattr(self, '_frozen_content_browsers'):
                self._frozen_content_browsers = []
            self._frozen_content_browsers.append(self.content_browser)

            # 创建新的 content_browser
            new_browser = MarkdownTextBrowser()
            new_browser.setMarkdownText("")

            # 找到旧 content_browser 的位置并替换
            layout = self.layout()
            content_index = -1
            for i in range(layout.count()):
                item = layout.itemAt(i)
                if item and item.widget() == self.content_browser:
                    content_index = i
                    break

            if content_index >= 0:
                # 移除旧的，添加新的
                layout.insertWidget(content_index + 1, new_browser)
            else:
                layout.addWidget(new_browser)

            self.content_browser = new_browser

    def append_reasoning(self, text: str):
        """追加思考内容到当前思考块"""
        # 如果没有当前思考块，创建一个
        if self._current_reasoning_block is None:
            self.start_new_reasoning()
        self._current_reasoning_block.append_reasoning(text)

    def finish_current_reasoning(self):
        """结束当前思考块"""
        if self._current_reasoning_block:
            self._current_reasoning_block.set_reasoning_finished()
            self._current_reasoning_block = None
            # 思考结束时封存当前内容
            self._freeze_current_content()

    def _on_copy(self):
        """复制消息内容到剪贴板"""
        clipboard = QApplication.clipboard()
        clipboard.setText(self.message_data.content)

    def _on_undo(self):
        """发出撤销请求信号"""
        if self.message_index >= 0:
            self.signals.undo_requested.emit(self.message_index)

    def _get_or_create_tool_call_row(self) -> QWidget:
        """获取或创建新的工具调用行容器"""
        # 如果当前行已满或不存在，创建新行
        if self._current_tool_call_row is None or self._current_row_tool_count >= 2:
            row_widget = QWidget()
            row_layout = QHBoxLayout(row_widget)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(8)
            row_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

            self._tool_call_rows.append(row_widget)
            self._current_tool_call_row = row_widget
            self._current_row_tool_count = 0

            # 将行插入到布局中
            layout = self.layout()
            insert_index = -1

            # 如果有当前思考块，工具调用应该插入在当前思考块之后
            if hasattr(self, '_current_reasoning_block') and self._current_reasoning_block:
                for i in range(layout.count()):
                    item = layout.itemAt(i)
                    if item and item.widget() == self._current_reasoning_block:
                        insert_index = i + 1
                        break

            # 如果没有找到当前思考块，查找 content_browser 并插入在它之前
            if insert_index < 0:
                for i in range(layout.count()):
                    item = layout.itemAt(i)
                    if item and item.widget() == self.content_browser:
                        insert_index = i
                        break

            if insert_index >= 0:
                layout.insertWidget(insert_index, row_widget)
            else:
                layout.addWidget(row_widget)

        return self._current_tool_call_row

    def add_tool_call(self, tool_name: str, tool_id: str):
        """添加工具调用显示控件"""
        print(f"[Tool] ▶ {tool_name}")
        # 创建工具调用控件
        tool_widget = ToolCallWidget(tool_name, tool_id, status="running")
        self._tool_call_widgets[tool_id] = tool_widget
        self._tool_call_by_name[tool_name] = tool_widget

        # 获取或创建行容器
        row_widget = self._get_or_create_tool_call_row()
        row_layout = row_widget.layout()

        # 添加到当前行，设置 stretch 因子使工具控件平分宽度
        row_layout.addWidget(tool_widget, stretch=1)
        self._current_row_tool_count += 1

        # 如果当前行已满（2个工具），添加 stretch 以保持对齐
        if self._current_row_tool_count >= 2:
            row_layout.addStretch()

    def update_tool_call(self, tool_id_or_name: str, status: str, result: str):
        """更新工具调用状态"""
        widget = None

        # 先尝试通过 ID 查找
        if hasattr(self, '_tool_call_widgets') and tool_id_or_name in self._tool_call_widgets:
            widget = self._tool_call_widgets[tool_id_or_name]

        # 如果没有找到，尝试通过名称查找
        if widget is None and hasattr(self, '_tool_call_by_name'):
            widget = self._tool_call_by_name.get(tool_id_or_name)

        # 如果仍然没有找到，遍历所有控件比较名称
        if widget is None and hasattr(self, '_tool_call_widgets'):
            for w in self._tool_call_widgets.values():
                if w.tool_name == tool_id_or_name:
                    widget = w
                    break

        if widget:
            widget.update_status(status, result)


class ChatWidget(QWidget):
    """聊天主组件"""

    def __init__(self, parent=None, canvas=None, tool_definitions=None, tool_executor=None):
        super().__init__(parent)
        self.ai: Optional[AICore] = None
        self.messages: list[Message] = []
        self.message_widgets: list[MessageWidget] = []
        self.system_prompt = "You are a helpful assistant. You have access to canvas tools to interact with the node editor."
        self.current_worker: Optional[StreamWorker] = None
        self.current_reasoning: list[str] = []
        self.current_content: list[str] = []
        self.in_reasoning = False
        self._canvas = canvas  # 画布引用
        self._tool_definitions = tool_definitions or []  # OpenAI 格式的工具定义列表
        self._tool_executor = tool_executor  # 工具执行器

        # 备份管理
        self._backup_manager = None
        self._conversation_counter = 0  # 对话计数器（用于备份索引）
        self._user_message_indices = []  # 记录用户消息在 messages 列表中的索引

        # 安装 Canvas 工具的事件处理器（用于跨线程调用）
        if tool_definitions or tool_executor:
            install_event_handler()

        # 初始化备份管理器（如果有画布）
        if canvas:
            self._backup_manager = BackupManager()

        # Token 使用统计（累积值，用于显示）
        self._total_prompt_tokens = 0
        self._total_completion_tokens = 0
        self._last_response_usage = None  # 最后一次响应的 usage 信息

        # 活跃的后台线程引用（防止窗口关闭时信号对象被销毁）
        self._active_workers: list = []

        # Health check 状态标志
        self._health_check_passed = False

        self._setup_ui()
        self._init_ai()

    def _setup_ui(self):
        """设置 UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)

        # 工具栏
        toolbar = QHBoxLayout()

        self.reset_btn = QPushButton("➕")
        self.reset_btn.setToolTip("新对话")
        self.reset_btn.clicked.connect(self.reset_conversation)
        toolbar.addWidget(self.reset_btn)

        self.system_btn = QPushButton("⚙")
        self.system_btn.setToolTip("设置")
        self.system_btn.clicked.connect(self.set_system_prompt)
        toolbar.addWidget(self.system_btn)

        toolbar.addStretch()

        # Token 使用统计容器（包含 label 和进度条）
        token_container = QWidget()
        token_layout = QHBoxLayout(token_container)
        token_layout.setContentsMargins(0, 0, 0, 0)
        token_layout.setSpacing(4)

        # Token 数量 label（默认透明，hover 时淡入）
        self.token_count_label = QLabel("0 / 0")
        self.token_count_label.setStyleSheet("""
            QLabel {
                font-size: 11px;
                color: #666666;
            }
        """)
        # 设置 opacity effect 用于动画
        self._token_label_opacity = QGraphicsOpacityEffect(self.token_count_label)
        self._token_label_opacity.setOpacity(0.0)  # 默认完全透明
        self.token_count_label.setGraphicsEffect(self._token_label_opacity)
        token_layout.addWidget(self.token_count_label)

        # 创建淡入淡出动画
        self._token_label_animation = QPropertyAnimation(self._token_label_opacity, b"opacity")
        self._token_label_animation.setDuration(200)  # 200ms 动画时长
        self._token_label_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

        # Token 使用环形进度条
        self.token_progress = CircularProgressBar(size=40)
        self.token_progress.setMouseTracking(True)
        token_layout.addWidget(self.token_progress)

        # 为 token_container 设置鼠标事件处理
        token_container.setMouseTracking(True)
        token_container.enterEvent = self._on_token_container_enter
        token_container.leaveEvent = self._on_token_container_leave

        toolbar.addWidget(token_container)

        toolbar.addSpacing(10)

        # 状态标签（初始灰色，等待健康检查）
        self.status_label = QLabel("⚪ 初始化中...")
        toolbar.addWidget(self.status_label)

        layout.addLayout(toolbar)

        # 分割器
        splitter = QSplitter(Qt.Orientation.Vertical)

        # 消息显示区域
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #fafafa;
            }
            QScrollBar:vertical {
                background: #f0f0f0;
                width: 12px;
            }
            QScrollBar::handle:vertical {
                background: #c0c0c0;
                border-radius: 6px;
                min-height: 30px;
            }
            QScrollBar::handle:vertical:hover {
                background: #a0a0a0;
            }
        """)

        self.messages_container = QWidget()
        self.messages_layout = QVBoxLayout(self.messages_container)
        self.messages_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.messages_layout.setSpacing(12)
        self.messages_layout.addStretch()

        scroll.setWidget(self.messages_container)
        self.scroll_area = scroll  # 保存为实例变量
        splitter.addWidget(scroll)

        # 输入区域
        input_widget = QWidget()
        input_layout = QVBoxLayout(input_widget)
        input_layout.setContentsMargins(0, 0, 0, 0)
        input_layout.setSpacing(8)

        # 输入框
        self.input_edit = QPlainTextEdit()
        self.input_edit.setPlaceholderText("输入消息... (Enter 发送, Shift+Enter 换行)")
        self.input_edit.setMaximumHeight(120)
        self.input_edit.setStyleSheet("""
            QPlainTextEdit {
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 8px;
                font-size: 13px;
                background-color: white;
            }
            QPlainTextEdit:focus {
                border-color: #2196F3;
            }
        """)
        self.input_edit.installEventFilter(self)
        input_layout.addWidget(self.input_edit)

        # 底部按钮栏
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()

        self.stop_btn = QPushButton("⏹️ 停止")
        self.stop_btn.setEnabled(False)
        self.stop_btn.setStyleSheet("""
            QPushButton {
                background-color: #ff5722;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #e64a19;
            }
            QPushButton:disabled {
                background-color: #ccc;
            }
        """)
        self.stop_btn.clicked.connect(self.stop_generation)
        btn_layout.addWidget(self.stop_btn)

        self.send_btn = QPushButton("📤 发送")
        self.send_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 24px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QPushButton:disabled {
                background-color: #BDBDBD;
                color: #EEEEEE;
            }
        """)
        self.send_btn.clicked.connect(self.send_message)
        btn_layout.addWidget(self.send_btn)

        input_layout.addLayout(btn_layout)
        splitter.addWidget(input_widget)
        splitter.setSizes([600, 150])

        layout.addWidget(splitter)

        # 初始化消息列表（添加系统提示）
        if self.system_prompt:
            self.messages.append(Message(role="system", content=self.system_prompt))

    def _init_ai(self):
        """初始化 AI"""
        try:
            self.ai = AICore()
            print(f"[AI] {self.ai}")
            self.status_label.setText(f"⚪ {self.ai.provider_name} ({self.ai.default_model}) - 检查中...")

            # 初始化 token 进度条
            self.token_progress.set_max_tokens(self.ai.max_context_tokens)
            self._update_token_display()

            # 异步健康检查
            self._check_health()

            # 就绪前禁用发送按钮
            self.send_btn.setEnabled(False)

        except Exception as e:
            self.status_label.setText(f"🔴 初始化失败: {e}")
            QMessageBox.critical(self, "错误", f"AI 初始化失败:\n{e}")

    def _update_token_display(self):
        """更新 token 显示"""
        if not self.ai:
            return

        # 使用实例方法估算当前消息的 token 数
        estimated_tokens = self.ai.estimate_tokens_for_messages(
            self.messages,
            self._tool_definitions
        )

        # 如果有实际的 usage 数据，更新进度条显示实际使用量
        # 注意：usage 是单次请求的 token 数，不是累积值
        if self._last_response_usage:
            # 使用最近一次响应的 prompt_tokens（实际输入上下文大小）
            actual_prompt_tokens = self._last_response_usage.get('prompt_tokens', 0)
            # 显示时使用估算值和实际值中的较大者
            display_tokens = max(estimated_tokens, actual_prompt_tokens)
        else:
            display_tokens = estimated_tokens

        # 更新进度条
        self.token_progress.set_current_tokens(display_tokens)

        # 更新 token 数量 label
        self._update_token_count_label()

    def update_token_usage(self, usage: Dict[str, int]):
        """
        更新 token 使用情况（从 API 响应中获取）

        Args:
            usage: 包含 prompt_tokens, completion_tokens, total_tokens 的字典
        """
        self._last_response_usage = usage
        self._total_prompt_tokens += usage.get('prompt_tokens', 0)
        self._total_completion_tokens += usage.get('completion_tokens', 0)
        self._update_token_display()

    def _check_health(self):
        """异步健康检查 - 向 AI 问好并显示回复（系统提问，不显示用户消息）"""
        print(f"[_check_health] Called, in_progress={getattr(self, '_health_check_in_progress', False)}")
        # 如果 health check 已在进行中，跳过
        if getattr(self, '_health_check_in_progress', False):
            print(f"[_check_health] Skipping - already in progress")
            return
        self._health_check_in_progress = True
        print(f"[_check_health] Started")

        class HealthWorker(QRunnable):
            def __init__(self, ai, chat_widget_ref):
                super().__init__()
                self.ai = ai
                self.chat_widget_ref = chat_widget_ref
                self.signals = WorkerSignals()

            def run(self):
                try:
                    # 调用基类的 health_check 方法（使用默认"你好"提示词）
                    result = asyncio.run(self.ai.health_check())
                    try:
                        self.signals.result.emit(result)
                    except RuntimeError:
                        pass  # 信号对象已被销毁，忽略
                except Exception as e:
                    try:
                        self.signals.error.emit(str(e))
                    except RuntimeError:
                        pass  # 信号对象已被销毁，忽略
                finally:
                    # 从活跃列表中移除
                    widget = self.chat_widget_ref()
                    if widget and self in widget._active_workers:
                        widget._active_workers.remove(self)

        worker = HealthWorker(self.ai, weakref.ref(self))
        self._active_workers.append(worker)  # 保持引用

        def on_health_result(result):
            self._health_check_in_progress = False
            if result:
                # 返回了文本，添加助手消息显示
                self.add_message_widget("assistant", result)
                self.status_label.setText(f"🟢 {self.ai.provider_name} - 就绪")
                # 就绪后启用发送按钮
                self.send_btn.setEnabled(True)
                # 标记 health check 通过
                self._health_check_passed = True
            else:
                # 返回 None，表示服务不可用
                self.status_label.setText(f"🟡 {self.ai.provider_name} - 健康检查失败")
                self._health_check_passed = False

        def on_health_error(e):
            self._health_check_in_progress = False
            self.status_label.setText(f"🟡 {self.ai.provider_name} - 检查失败")
            self._health_check_passed = False

        worker.signals.result.connect(on_health_result)
        worker.signals.error.connect(on_health_error)
        QThreadPool.globalInstance().start(worker)

    def eventFilter(self, obj, event):
        """事件过滤器 - 处理 Enter 发送"""
        if obj == self.input_edit and event.type() == event.Type.KeyPress:
            if event.key() == Qt.Key.Key_Return and not event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                self.send_message()
                return True
        return super().eventFilter(obj, event)

    def add_message_widget(self, role: str, content: str = "", reasoning: str = None, message_index: int = -1) -> MessageWidget:
        """添加消息组件"""
        # 移除底部的 stretch
        if self.messages_layout.count() > 0:
            item = self.messages_layout.itemAt(self.messages_layout.count() - 1)
            if item and item.spacerItem():
                self.messages_layout.removeItem(item)

        # 创建消息组件（仅用户消息且有有效索引时显示撤销按钮）
        msg_data = MessageData(role=role, content=content, reasoning=reasoning)
        msg_widget = MessageWidget(msg_data, message_index=message_index)

        # 连接撤销信号
        if role == "user" and message_index >= 0:
            msg_widget.signals.undo_requested.connect(self._on_undo_requested)

        self.messages_layout.addWidget(msg_widget)
        self.message_widgets.append(msg_widget)

        # 重新添加 stretch
        self.messages_layout.addStretch()

        # 滚动到底部
        self.scroll_to_bottom()

        return msg_widget

    def scroll_to_bottom(self):
        """滚动到底部 - 使用多次尝试确保滚动到正确位置"""
        def do_scroll():
            if hasattr(self, 'scroll_area') and self.scroll_area:
                scrollbar = self.scroll_area.verticalScrollBar()
                scrollbar.setValue(scrollbar.maximum())

        # 立即尝试滚动
        do_scroll()
        # 在布局调整后再次滚动（10ms后）
        QTimer.singleShot(10, do_scroll)
        # 再次确保滚动到底部（50ms后，等待高度调整完成）
        QTimer.singleShot(50, do_scroll)
        # 最后一次尝试（100ms后，确保所有渲染完成）
        QTimer.singleShot(100, do_scroll)

    def send_message(self):
        """发送消息"""
        text = self.input_edit.toPlainText().strip()
        if not text:
            return

        if not self.ai:
            QMessageBox.warning(self, "警告", "AI 未初始化")
            return

        # 清空输入框
        self.input_edit.clear()

        # 首次用户提问时，添加 readme 内容
        if self._conversation_counter == 0:
            try:
                readme_path = os.path.join(os.path.dirname(__file__), 'ai.readme.md')
                with open(readme_path, 'r', encoding='utf-8') as f:
                    readme_content = f.read()
                # 将 readme 作为系统消息添加（仅首次）
                self.messages.append(Message(role="system", content=f"请阅读以下使用规范：\n\n{readme_content}"))
            except Exception:
                pass  # 如果读取失败，继续正常流程

        # 保存备份（如果有画布和备份管理器）
        if self._backup_manager and self._canvas:
            try:
                canvas_api = CanvasAPI(self._canvas)
                graph_data = canvas_api.get_graph()
                self._backup_manager.save_backup(
                    self._conversation_counter,
                    graph_data,
                    text
                )
            except RuntimeError as e:
                # 画布对象已被删除，跳过备份
                print(f"[Backup] Skip: {e}")
            except Exception as e:
                print(f"[Backup] Error: {e}")

        # 记录用户消息在 messages 列表中的索引
        user_message_index = len(self.messages)
        self._user_message_indices.append(user_message_index)

        # 添加用户消息（传入对话索引用于撤销）
        self.add_message_widget("user", text, message_index=self._conversation_counter)
        self.messages.append(Message(role="user", content=text))

        # 增加对话计数器
        self._conversation_counter += 1

        # 更新 token 显示
        self._update_token_display()

        # 禁用发送按钮，启用停止按钮
        self.send_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)

        # 添加空的助手消息（用于流式更新）
        self.current_assistant_widget = self.add_message_widget("assistant", "")
        self.current_content = []
        self.current_reasoning = []
        self.in_reasoning = False

        # 启动流式输出（传入工具定义、工具执行器和画布）
        self.current_worker = StreamWorker(
            self.ai,
            self.messages.copy(),
            tool_definitions=self._tool_definitions,
            tool_executor=self._tool_executor,
            canvas=self._canvas
        )
        self.current_worker.signals.chunk.connect(self._on_chunk)
        self.current_worker.signals.error.connect(self._on_error)
        self.current_worker.signals.finished.connect(self._on_finished)
        self.current_worker.signals.token_usage.connect(self._on_token_usage)
        self.current_worker.signals.tool_call.connect(self._on_tool_call)
        QThreadPool.globalInstance().start(self.current_worker)

    def _on_chunk(self, chunk: dict):
        """处理流式输出块"""
        chunk_type = chunk.get("type", "content")
        text = chunk.get("text", "")
        # 过滤掉替换字符 U+FFFD 和零宽空格 U+200B
        text = text.replace('\ufffd', '').replace('\u200b', '')

        if chunk_type == "reasoning_start":
            self.in_reasoning = True
            # 开始新的思考块
            if self.current_assistant_widget:
                self.current_assistant_widget.start_new_reasoning()

        elif chunk_type == "reasoning":
            self.current_reasoning.append(text)
            # 追加到当前思考块
            if self.current_assistant_widget:
                self.current_assistant_widget.append_reasoning(text)
            self.scroll_to_bottom()

        elif chunk_type == "reasoning_end":
            self.in_reasoning = False
            # 思考完成，自动折叠当前思考块
            if self.current_assistant_widget:
                self.current_assistant_widget.finish_current_reasoning()

        elif chunk_type == "content":
            self.current_content.append(text)
            if self.current_assistant_widget:
                self.current_assistant_widget.append_content(text)
            self.scroll_to_bottom()

        elif chunk_type == "token_usage":
            # 从流式响应中捕获 token 使用信息
            usage = chunk.get("usage")
            if usage:
                self._on_token_usage(usage)

    def _on_tool_call(self, tool_info: dict):
        """处理工具调用信息"""
        info_type = tool_info.get("type")

        if info_type == "tool_call":
            # 新的工具调用
            tool_name = tool_info.get("tool_name", "unknown")
            tool_id = tool_info.get("tool_id", "")

            # 检查是否在黑名单中（大小写不敏感）- 在工具显示前拦截
            if self._tool_executor and hasattr(self._tool_executor, '_tool_blacklist'):
                blacklist = self._tool_executor._tool_blacklist
                # _tool_blacklist 已经是小写集合
                if tool_name.lower() in blacklist:
                    print(f"[Blacklist] 工具 '{tool_name}' 在黑名单中，立即终止")
                    # 先显示工具调用（标记为被阻止）
                    if self.current_assistant_widget:
                        self.current_assistant_widget.add_tool_call(tool_name, tool_id)
                        widget = self.current_assistant_widget._tool_call_widgets.get(tool_id)
                        if widget:
                            widget.update_status("error", f"工具 '{tool_name}' 被黑名单阻止")
                    # 停止当前生成并自动回复
                    self.stop_current_generation()
                    self._auto_reply_blacklist(tool_name)
                    return

            # 在助手消息组件中插入工具调用控件
            if self.current_assistant_widget:
                self.current_assistant_widget.add_tool_call(tool_name, tool_id)
            self.scroll_to_bottom()

        elif info_type == "tool_result":
            # 工具调用结果
            tool_name = tool_info.get("tool_name", "")
            tool_id = tool_info.get("tool_id", "")  # 现在可以获取到 tool_id
            status = tool_info.get("status", "success")
            result = tool_info.get("result", "")
            status_icon = "✓" if status == "success" else "✗"
            # 更新工具调用状态 - 优先通过 tool_id 查找，其次通过名称
            if self.current_assistant_widget:
                widget = None
                # 优先通过 ID 查找
                if tool_id and hasattr(self.current_assistant_widget, '_tool_call_widgets'):
                    widget = self.current_assistant_widget._tool_call_widgets.get(tool_id)
                # 如果找不到，通过名称查找
                if widget is None and tool_name and hasattr(self.current_assistant_widget, '_tool_call_widgets'):
                    for tid, w in self.current_assistant_widget._tool_call_widgets.items():
                        if w.tool_name == tool_name:
                            widget = w
                            break
                if widget:
                    print(f"[Tool] {status_icon} {tool_name} → {status}")
                    widget.update_status(status, result)
                else:
                    print(f"[Tool] ✗ {tool_name} → widget not found")

    def _on_token_usage(self, usage: dict):
        """处理 token 使用信息"""
        self._last_response_usage = usage
        prompt_tokens = usage.get("prompt_tokens", 0)
        completion_tokens = usage.get("completion_tokens", 0)
        total_tokens = usage.get("total_tokens", 0)

        # 累积统计
        self._total_prompt_tokens += prompt_tokens
        self._total_completion_tokens += completion_tokens

        # 打印到控制台
        print(f"[Token Usage] Prompt: {prompt_tokens}, Completion: {completion_tokens}, Total: {total_tokens}")

        # 更新显示
        self._update_token_display()

    def _on_error(self, error: str):
        """处理错误"""
        self.current_assistant_widget.update_content(f"❌ 错误: {error}")

    def _on_finished(self):
        """流式输出完成"""
        # 保存助手回复到历史
        content = "".join(self.current_content)
        if self.current_reasoning:
            reasoning = "".join(self.current_reasoning)
            full_content = f"<thinking>\n{reasoning}\n</thinking>\n\n{content}"
        else:
            full_content = content

        self.messages.append(Message(role="assistant", content=full_content))

        # 更新 token 显示
        self._update_token_display()

        # 重置状态
        self.send_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.current_worker = None

    def _on_undo_requested(self, conversation_index: int):
        """
        处理撤销请求

        1. 将消息内容设置到输入框
        2. 调用 AI rollback 清除模型中的相关对话
        3. 恢复图状态
        4. 清除该对话框及后续对话框
        """
        print(f"[Undo] → #{conversation_index}")

        # 验证 conversation_index 有效性
        if conversation_index < 0 or conversation_index >= self._conversation_counter:
            QMessageBox.warning(self, "撤销失败", f"无效的对话索引: {conversation_index}")
            return

        # 获取要撤销的用户消息内容
        user_msg_index = self._user_message_indices[conversation_index] if conversation_index < len(self._user_message_indices) else -1
        if user_msg_index < 0 or user_msg_index >= len(self.messages):
            QMessageBox.warning(self, "撤销失败", "找不到对应的用户消息")
            return

        user_message = self.messages[user_msg_index]
        if user_message.role != "user":
            QMessageBox.warning(self, "撤销失败", "消息角色不匹配")
            return

        # 1. 将消息内容设置到输入框（覆盖已有内容）
        self.input_edit.setPlainText(user_message.content)

        # 2. 恢复图状态（如果有画布和备份管理器）
        if self._backup_manager and self._canvas:
            try:
                canvas_api = CanvasAPI(self._canvas)
                error = self._backup_manager.restore_backup(canvas_api, conversation_index)
                if error:
                    QMessageBox.warning(self, "恢复图失败", f"无法恢复到之前的状态: {error}")
                    return
            except Exception as e:
                QMessageBox.warning(self, "恢复图失败", f"恢复图时出错: {e}")
                return

        # 3. 清除该对话及后续的对话框和消息
        # 找到对应的消息组件索引
        widget_index = -1
        for i, widget in enumerate(self.message_widgets):
            if widget.message_index == conversation_index:
                widget_index = i
                break

        if widget_index < 0:
            QMessageBox.warning(self, "撤销失败", "找不到对应的消息组件")
            return

        # 删除从该组件开始的所有消息组件
        widgets_to_remove = self.message_widgets[widget_index:]
        for widget in widgets_to_remove:
            widget.deleteLater()
        self.message_widgets = self.message_widgets[:widget_index]

        # 删除对应的消息记录
        # 找到下一个用户消息的索引（如果存在）
        next_user_index = len(self.messages)
        if conversation_index + 1 < len(self._user_message_indices):
            next_user_index = self._user_message_indices[conversation_index + 1]
        else:
            # 这是最后一个对话，删除到末尾
            next_user_index = len(self.messages)

        # 保留系统消息和该用户消息之前的所有消息
        self.messages = self.messages[:user_msg_index]

        # 更新用户消息索引列表
        self._user_message_indices = self._user_message_indices[:conversation_index]

        # 更新对话计数器
        self._conversation_counter = conversation_index

        # 清理后续备份文件
        if self._backup_manager:
            self._backup_manager.delete_backups_from(conversation_index + 1)

        # 4. 调用 AI rollback（异步执行）
        if self.ai:
            try:
                # 对于无状态的 Kimi AI，rollback 只是验证
                asyncio.run(self.ai.rollback(conversation_index))
            except Exception:
                pass

        # 更新 token 显示
        self._update_token_display()

    def stop_generation(self):
        """停止生成"""
        if self.current_worker:
            self.current_worker.stop()
            self.current_worker = None
            self.send_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)

    def stop_current_generation(self):
        """停止当前生成（供内部调用）"""
        if self.current_worker:
            self.current_worker.stop()
            self.current_worker = None
            self.send_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)
            print("[Chat] 已停止当前生成")

    def _auto_reply_blacklist(self, blocked_tool_name: str):
        """
        当工具被黑名单阻止时，自动回复 AI

        Args:
            blocked_tool_name: 被阻止的工具名称
        """
        reply_message = f"{blocked_tool_name}工具禁止使用，继续"

        # 添加系统消息（作为 assistant 角色回复）
        if self.current_assistant_widget:
            self.current_assistant_widget.append_content(f"\n\n{reply_message}")

        # 保存到消息历史
        self.messages.append(Message(role="assistant", content=reply_message))

        # 滚动到底部
        self.scroll_to_bottom()

        # 重置状态但保持当前 assistant widget
        self.send_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.current_worker = None

        print(f"[Blacklist] 已自动回复: {reply_message}")

        # 延迟后触发 AI 继续（确保状态已重置）
        QTimer.singleShot(300, self._trigger_ai_continue)

    def _trigger_ai_continue(self):
        """触发 AI 继续对话 - 保持现有上下文，不重置状态"""
        if not self.ai:
            return

        # 不创建新助手组件，不重置 current_content
        # 直接在现有上下文中继续

        # 禁用发送按钮，启用停止按钮
        self.send_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)

        # 启动新的流式输出
        self.current_worker = StreamWorker(
            self.ai,
            self.messages.copy(),
            tool_definitions=self._tool_definitions,
            tool_executor=self._tool_executor,
            canvas=self._canvas
        )
        self.current_worker.signals.chunk.connect(self._on_chunk)
        self.current_worker.signals.error.connect(self._on_error)
        self.current_worker.signals.finished.connect(self._on_finished)
        self.current_worker.signals.token_usage.connect(self._on_token_usage)
        self.current_worker.signals.tool_call.connect(self._on_tool_call)
        QThreadPool.globalInstance().start(self.current_worker)

        print("[Blacklist] 已触发 AI 继续")

    def clear_history(self):
        """清空对话历史"""
        # 清除所有消息组件
        for widget in self.message_widgets:
            widget.deleteLater()
        self.message_widgets.clear()

        # 保留系统提示
        self.messages = []
        if self.system_prompt:
            self.messages.append(Message(role="system", content=self.system_prompt))

        # 重置对话计数器和索引
        self._conversation_counter = 0
        self._user_message_indices = []

        # 清除所有备份
        if self._backup_manager:
            self._backup_manager.clear_all_backups()

        # 重置 token 计数相关状态
        self._last_response_usage = None
        self._total_prompt_tokens = 0
        self._total_completion_tokens = 0

        # 更新 token 显示
        self._update_token_display()

    def reset_conversation(self, silent: bool = False, reset_health: bool = True):
        """
        重置对话

        Args:
            silent: 如果为 True，静默重置（不显示对话框）
            reset_health: 如果为 True，重置 health check 状态
        """
        self.clear_history()
        # 重置 health check 状态（如果需要）
        if reset_health:
            self._health_check_passed = False
        if not silent:
            QMessageBox.information(self, "提示", "对话已重置")

    def set_system_prompt(self):
        """打开设置对话框"""

        dialog = AISettingsDialog(self, self)
        dialog.exec()

    def _on_token_container_enter(self, event=None):
        """鼠标进入 token 容器时淡入显示 label"""
        if hasattr(self, '_token_label_animation') and self._token_label_animation:
            self._token_label_animation.stop()
            self._token_label_animation.setStartValue(self._token_label_opacity.opacity())
            self._token_label_animation.setEndValue(1.0)
            self._token_label_animation.start()

    def _on_token_container_leave(self, event=None):
        """鼠标离开 token 容器时淡出隐藏 label"""
        if hasattr(self, '_token_label_animation') and self._token_label_animation:
            self._token_label_animation.stop()
            self._token_label_animation.setStartValue(self._token_label_opacity.opacity())
            self._token_label_animation.setEndValue(0.0)
            self._token_label_animation.start()

    def _update_token_count_label(self):
        """更新 token 数量 label 显示"""
        if hasattr(self, 'token_count_label'):
            # 从进度条获取当前 token 数和最大 token 数
            current = getattr(self.token_progress, '_current_tokens', 0)
            max_tokens = getattr(self.token_progress, '_max_tokens', 128000)
            if max_tokens <= 0:
                max_tokens = 128000  # kimi 默认上下文长度
            self.token_count_label.setText(f"{current:,} / {max_tokens:,}")


class QChatWidget(QWidget):
    """主窗口 - 作为 QWidget 以便嵌入其他应用"""

    # 关闭请求信号
    close_requested = pyqtSignal()

    def __init__(self, canvas=None, tool_definitions=None, tool_executor=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI Chat - Kimi (with Canvas Tools)")
        self.setMinimumSize(900, 900)

        # 保存画布和工具引用
        self._canvas = canvas
        self._tool_definitions = tool_definitions
        self._tool_executor = tool_executor

        # 创建主布局
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 创建顶部标题栏（包含关闭按钮）
        self._setup_header(layout)

        # 创建聊天组件，传入画布、工具定义和工具执行器
        self.chat_widget = ChatWidget(
            canvas=canvas,
            tool_definitions=tool_definitions,
            tool_executor=tool_executor
        )
        layout.addWidget(self.chat_widget)

    def _setup_header(self, parent_layout):
        """设置顶部标题栏"""
        header = QWidget()
        header.setFixedHeight(36)
        header.setStyleSheet("""
            QWidget {
                background-color: #e8e8e8;
                border-bottom: 1px solid #cccccc;
            }
        """)

        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(12, 0, 8, 0)
        header_layout.setSpacing(8)

        # 标题
        title_label = QLabel("AI Chat")
        title_label.setStyleSheet("""
            font-size: 14px;
            font-weight: bold;
            color: #333333;
            border: none;
            background-color: transparent;
        """)
        header_layout.addWidget(title_label)

        header_layout.addStretch()

        # 关闭按钮（仅在嵌入模式下显示）
        self._close_btn = QPushButton("×")
        self._close_btn.setFixedSize(24, 24)
        self._close_btn.setToolTip("隐藏")
        self._close_btn.setStyleSheet("""
            QPushButton {
                border: none;
                background-color: transparent;
                font-size: 18px;
                font-weight: bold;
                color: #666666;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #ff4444;
                color: white;
            }
            QPushButton:pressed {
                background-color: #cc3333;
            }
        """)
        self._close_btn.clicked.connect(self._on_close_clicked)
        header_layout.addWidget(self._close_btn)

        parent_layout.addWidget(header)

    def _on_close_clicked(self):
        """关闭按钮点击处理"""
        self.close_requested.emit()
        # 如果作为独立窗口运行，则隐藏而不是关闭
        if self.parent():
            self.hide()
        else:
            self.close()

    def show_close_button(self, show: bool = True):
        """显示/隐藏关闭按钮"""
        if hasattr(self, '_close_btn'):
            self._close_btn.setVisible(show)

    def stop_and_reset(self, reset: bool = False):
        """
        停止当前 AI 生成，可选择重置对话

        Args:
            reset: 是否重置对话历史
        """
        # 停止当前生成
        if hasattr(self.chat_widget, 'stop_generation'):
            self.chat_widget.stop_generation()

        # 重置对话（如果需要）
        if reset and hasattr(self.chat_widget, 'reset_conversation'):
            hc_passed = getattr(self.chat_widget, '_health_check_passed', False)
            hc_in_progress = getattr(self.chat_widget, '_health_check_in_progress', False)
            print(f"[stop_and_reset] hc_passed={hc_passed}, in_progress={hc_in_progress}")
            # 静默重置对话，但保留 health check 状态以便检查
            self.chat_widget.reset_conversation(silent=True, reset_health=False)
            # 如果之前 health check 未通过，重新运行 health check
            if not hc_passed and not hc_in_progress:
                print(f"[stop_and_reset] Triggering _check_health")
                self.chat_widget._check_health()
            else:
                print(f"[stop_and_reset] Skipping _check_health")

    def export_chat(self):
        """导出对话"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "导出对话", "chat_history.md", "Markdown (*.md);;文本文件 (*.txt)"
        )
        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    for msg in self.chat_widget.messages:
                        if msg.role != "system":
                            f.write(f"## {msg.role.upper()}\n\n")
                            f.write(f"{msg.content}\n\n---\n\n")
                QMessageBox.information(self, "成功", "对话已导出")
            except Exception as e:
                QMessageBox.critical(self, "错误", f"导出失败: {e}")

    def show_about(self):
        """显示关于对话框"""
        QMessageBox.about(self, "关于", """
            <h2>AI Chat</h2>
            <p>基于 PyQt6 + AICore + KimiAI 的对话界面</p>
            <p>支持流式输出、思考过程显示、Markdown 渲染</p>
        """)


def main():
    """主函数"""
    # 设置 asyncio 事件循环策略
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    app = QApplication(sys.argv)

    # 设置应用样式
    app.setStyle("Fusion")

    # 设置全局字体
    font = QFont("Microsoft YaHei", 10)
    app.setFont(font)

    window = QChatWidget()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
