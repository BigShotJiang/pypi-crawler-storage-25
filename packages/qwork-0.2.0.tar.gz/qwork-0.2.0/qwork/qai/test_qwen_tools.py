# -*- coding: utf-8 -*-
"""
测试 Qwen AI 工具调用功能

运行方式:
    python -m qwork.qai.test_qwen_tools
"""

from datetime import datetime
import traceback

import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from qwork.qai.aio import ToolDef, Message
from qwork.qai import CreateAI


def GetCurrentTime(format: str = "%Y-%m-%d %H:%M:%S") -> str:
    """获取当前时间，返回指定格式的字符串"""
    return datetime.now().strftime(format)


def Calculator(expression: str) -> float:
    """执行数学计算表达式"""
    return eval(expression)


async def TestQwenTools():
    """测试 Qwen 工具调用"""
    print("=" * 60)
    print("Qwen AI 工具调用测试")
    print("=" * 60)

    # 创建 AI 实例
    try:
        ai = CreateAI("qwen", only=True)
        print(f"\n[OK] AI 创建成功: {ai.providerName()}")
    except Exception as e:
        print(f"\n[FAIL] AI 创建失败: {e}")
        return False

    # 定义工具
    tooldefs = [ToolDef(GetCurrentTime), ToolDef(Calculator)]
    print(f"[OK] 注册了 {len(tooldefs)} 个工具")

    # 测试1: 非流式 chat 带工具调用
    print("\n" + "-" * 60)
    print("测试1: 非流式 chat 调用工具")
    print("-" * 60)

    messages = [Message(role="user", content="现在几点了？请使用工具获取当前时间。")]

    try:
        response = await ai.chat(messages, tooldefs=tooldefs)
        print(f"[OK] 响应内容: {response.content[:200]}...")
        print(f"[OK] 模型: {response.model}")
        print(f"[OK] Token 使用: {response.usage}")
    except Exception as e:
        print(f"[FAIL] chat 失败: {e}")
        traceback.print_exc()
        return False

    # 测试2: 数学计算工具调用
    print("\n" + "-" * 60)
    print("测试2: 数学计算工具调用")
    print("-" * 60)

    messages = [Message(role="user", content="帮我计算 12345 * 67890 等于多少？")]

    try:
        response = await ai.chat(messages, tooldefs=tooldefs)
        print(f"[OK] 响应内容: {response.content}")
    except Exception as e:
        print(f"[FAIL] chat 失败: {e}")
        traceback.print_exc()
        return False

    # 测试3: 流式输出带工具调用
    print("\n" + "-" * 60)
    print("测试3: 流式 chatStream 调用工具")
    print("-" * 60)

    messages = [Message(role="user", content="现在几点了？")]

    try:
        print("流式输出: ", end="", flush=True)
        tool_call_seen = False
        tool_result_seen = False

        async for chunk in ai.chatStream(messages, tooldefs=tooldefs):
            if chunk.get("type") == "content":
                print(chunk.get("text", ""), end="", flush=True)
            elif chunk.get("type") == "tool_call":
                tool_call_seen = True
                print(f"\n[TOOL_CALL] name={chunk.get('name')}, args={chunk.get('arguments')}")
            elif chunk.get("type") == "tool_result":
                tool_result_seen = True
                print(f"\n[TOOL_RESULT] name={chunk.get('name')}, result={chunk.get('result')}")
            elif chunk.get("type") == "reasoning_start":
                print("\n[REASONING_START]", end="", flush=True)
            elif chunk.get("type") == "reasoning":
                print(chunk.get("text", ""), end="", flush=True)
            elif chunk.get("type") == "reasoning_end":
                print("\n[REASONING_END]", end="", flush=True)

        print()
        if tool_call_seen:
            print("[OK] 检测到工具调用")
        if tool_result_seen:
            print("[OK] 检测到工具结果")
    except Exception as e:
        print(f"\n[FAIL] chatStream 失败: {e}")
        traceback.print_exc()
        return False

    print("\n" + "=" * 60)
    print("[OK] 所有测试通过!")
    print("=" * 60)
    return True


if __name__ == "__main__":
    success = asyncio.run(TestQwenTools())
    sys.exit(0 if success else 1)
