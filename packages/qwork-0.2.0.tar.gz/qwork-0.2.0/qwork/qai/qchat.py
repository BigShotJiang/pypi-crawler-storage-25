# -*- coding: utf-8 -*-
"""
QAI 聊天 GUI 界面 - 基于 PyQt6 + AICore

功能特性:
- 流式输出显示
- 思考过程折叠显示
- Markdown 渲染支持
- 对话历史管理
- 系统提示设置
- 工具调用显示
- Token 使用追踪
- 健康检查
"""

import markdown
from markdown.extensions import fenced_code, tables, nl2br
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineSettings
from qwork.qai.models import EmptyAI
import re
from PyQt6.QtGui import QStandardItemModel, QStandardItem
from qwork.qai import ShowSettingsDialog
from PyQt6.QtCore import QUrl
import base64
from qwork.qai import CreateAI


import sys
import os
import time
import asyncio
from typing import Optional, Dict
from dataclasses import dataclass

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTextEdit, QLineEdit, QPushButton, QLabel, QScrollArea,
    QFrame, QSplitter, QToolBar, QStatusBar, QMenu, QSystemTrayIcon,
    QDialog, QPlainTextEdit, QMessageBox, QSizePolicy, QSpacerItem,
    QFileDialog, QTextBrowser, QGraphicsOpacityEffect, QComboBox
)
from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, QRunnable, QThreadPool, QObject,
    QMetaObject, Q_ARG, QTimer, QSize, QPropertyAnimation, QEasingCurve
)
from PyQt6.QtGui import (
    QFont, QColor, QPalette, QPainter, QPen, QBrush, QFontMetrics,
    QAction, QIcon, QTextCursor, QKeyEvent, QTextCharFormat, QTextDocument
)

from qwork.qai.aio import AICore, Message, ChatResponse, ToolDef
from qwork.qai.models import get_available_models
from qwork.qai.config import QAIConfig


# 导入 markdown 库（如果没有则使用简单方案）
try:
    MARKDOWN_AVAILABLE = True
except ImportError:
    MARKDOWN_AVAILABLE = False


class CircularProgressBar(QWidget):
    """
    环形进度条控件

    显示上下文使用百分比，颜色根据使用程度变化：
    - 0-50%: 绿色
    - 50-80%: 黄色
    - 80-100%: 红色
    """

    def __init__(self, parent=None, size=32):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self._percentage = 0.0
        self._max_tokens = 0
        self._current_tokens = 0

    def set_max_tokens(self, max_tokens: int):
        """设置最大 token 数"""
        self._max_tokens = max_tokens
        self.update()

    def set_current_tokens(self, current_tokens: int):
        """设置当前 token 数"""
        self._current_tokens = current_tokens
        if self._max_tokens > 0:
            self._percentage = min(100.0, (current_tokens / self._max_tokens) * 100)
        else:
            self._percentage = 0.0
        self.update()

    def set_percentage(self, percentage: float):
        """设置百分比 (0-100)"""
        self._percentage = max(0.0, min(100.0, percentage))
        self.update()

    def get_color(self) -> QColor:
        """根据百分比获取颜色"""
        if self._percentage < 50:
            return QColor(76, 175, 80)  # 绿色
        elif self._percentage < 80:
            return QColor(255, 193, 7)  # 黄色
        else:
            return QColor(244, 67, 54)  # 红色

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        size = min(self.width(), self.height())
        rect = self.rect()
        center_x = rect.center().x()
        center_y = rect.center().y()
        radius = (size - 6) // 2

        # 背景圆环
        painter.setPen(QPen(QColor(200, 200, 200), 3))
        painter.drawEllipse(center_x - radius, center_y - radius, radius * 2, radius * 2)

        # 进度圆弧
        if self._percentage > 0:
            painter.setPen(QPen(self.get_color(), 3))
            span_angle = int(-self._percentage * 3.6 * 16)  # 转换为 1/16 度
            painter.drawArc(center_x - radius, center_y - radius,
                          radius * 2, radius * 2, 90 * 16, span_angle)

        # 中心文字
        painter.setPen(QColor(100, 100, 100))
        font = QFont("Microsoft YaHei", 7)
        painter.setFont(font)
        text = f"{int(self._percentage)}%"
        metrics = QFontMetrics(font)
        text_rect = metrics.boundingRect(text)
        painter.drawText(center_x - text_rect.width() // 2,
                        center_y + text_rect.height() // 4, text)

        painter.end()


class WorkerSignals(QObject):
    """工作器信号定义"""

    finished = pyqtSignal()
    error = pyqtSignal(str)
    result = pyqtSignal(object)
    chunk = pyqtSignal(dict)  # 流式输出块
    token_usage = pyqtSignal(dict)  # token 使用信息
    tool_call = pyqtSignal(dict)  # 工具调用信息


class MessageWidgetSignals(QObject):
    """消息组件信号定义"""

    undo_requested = pyqtSignal(int)  # 参数: message_index


class ToolCallWidget(QFrame):
    """工具调用显示组件 - 显示简短的工具调用信息"""

    def __init__(self, tool_name: str, tool_id: str = "", status: str = "pending", result: str = "", parent=None):
        super().__init__(parent)
        self.tool_name = tool_name
        self.tool_id = tool_id
        self.status = status  # pending, running, success, error
        self.result = result
        self._start_time = None  # 开始时间
        self._elapsed_ms = 0  # 已耗时（毫秒）
        self._timer = QTimer(self)  # 计时器
        self._timer.timeout.connect(self._update_elapsed_time)
        self._setup_ui()

    def _setup_ui(self):
        """设置 UI"""
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setStyleSheet("""
            ToolCallWidget {
                background-color: #f8f9fa;
                border-radius: 6px;
                border: 1px solid #e0e0e0;
                padding: 4px;
            }
        """)
        self.setMaximumWidth(280)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(8)

        # 工具名称
        self.name_label = QLabel(f"🔧 {self.tool_name}")
        self.name_label.setStyleSheet("""
            font-size: 12px;
            color: #333;
            font-weight: 500;
        """)
        layout.addWidget(self.name_label)

        layout.addStretch()

        # 耗时标签（在状态标签左边）
        self.time_label = QLabel()
        self.time_label.setStyleSheet("""
            font-size: 11px;
            color: #666;
        """)
        layout.addWidget(self.time_label)

        # 状态标签
        self.status_label = QLabel()
        self.status_label.setStyleSheet("""
            font-size: 11px;
            font-weight: bold;
            padding: 2px 6px;
            border-radius: 4px;
        """)
        layout.addWidget(self.status_label)

        self._update_status_display()

    def _update_status_display(self):
        """更新状态显示"""
        status_styles = {
            "pending": ("⏳", "#ff9800", "#fff3e0"),
            "running": ("🔄", "#2196f3", "#e3f2fd"),
            "success": ("✓", "#4caf50", "#e8f5e9"),
            "error": ("✗", "#f44336", "#ffebee"),
        }

        icon, text_color, bg_color = status_styles.get(self.status, ("?", "#666", "#f5f5f5"))

        self.status_label.setText(f"{icon} {self.status.upper()}")
        self.status_label.setStyleSheet(f"""
            font-size: 11px;
            font-weight: bold;
            padding: 2px 6px;
            border-radius: 4px;
            color: {text_color};
            background-color: {bg_color};
        """)

        # 启动或停止计时器
        if self.status == "running":
            self._start_timer()
        else:
            self._stop_timer()

    def _format_elapsed_time(self, elapsed_ms: int) -> str:
        """格式化经过的时间"""
        if elapsed_ms < 1000:
            return f"{elapsed_ms}ms"
        elif elapsed_ms < 60000:
            seconds = elapsed_ms / 1000
            return f"{seconds:.1f}s"
        else:
            minutes = elapsed_ms // 60000
            seconds = (elapsed_ms % 60000) // 1000
            return f"{minutes}m{seconds}s"

    def _update_elapsed_time(self):
        """更新耗时显示"""
        if self._start_time:
            self._elapsed_ms = int((time.time() - self._start_time) * 1000)
            self.time_label.setText(self._format_elapsed_time(self._elapsed_ms))

    def _start_timer(self):
        """启动计时器"""
        if self._start_time is None:
            self._start_time = time.time()
            self._timer.start(100)  # 每 100ms 更新一次

    def _stop_timer(self):
        """停止计时器"""
        self._timer.stop()
        if self._start_time:
            self._elapsed_ms = int((time.time() - self._start_time) * 1000)
            self._start_time = None
            self.time_label.setText(self._format_elapsed_time(self._elapsed_ms))

    def update_status(self, status: str, result: str = ""):
        """更新状态"""
        self.status = status
        if result:
            self.result = result
        self._update_status_display()

        # 成功或错误时停止计时
        if status in ("success", "error"):
            self._stop_timer()

    def mouseDoubleClickEvent(self, event):
        """双击显示详情"""
        if self.result:
            dialog = QDialog(self)
            dialog.setWindowTitle(f"工具结果: {self.tool_name}")
            dialog.setMinimumSize(500, 400)

            layout = QVBoxLayout(dialog)

            text_edit = QTextEdit()
            text_edit.setPlainText(self.result)
            text_edit.setReadOnly(True)
            layout.addWidget(text_edit)

            close_btn = QPushButton("关闭")
            close_btn.clicked.connect(dialog.close)
            layout.addWidget(close_btn)

            dialog.exec()


class StreamWorker(QRunnable):
    """流式工作器 - 在后台线程中运行异步流式对话"""

    def __init__(self, ai: AICore, messages: list, tooldefs=None, canvas=None):
        super().__init__()
        self.ai = ai
        self.messages = messages.copy()
        self.signals = WorkerSignals()
        self._is_running = True
        self.tooldefs = tooldefs
        self.canvas = canvas

    def run(self):
        """运行工作器"""
        try:
            asyncio.run(self._stream())
        except Exception as e:
            self.signals.error.emit(str(e))
        finally:
            self.signals.finished.emit()

    async def _stream(self):
        """流式对话"""
        try:
            kwargs = {}
            if self.tooldefs:
                kwargs["tooldefs"] = self.tooldefs

            async for chunk in self.ai.chatStream(self.messages, **kwargs):
                if not self._is_running:
                    break

                chunk_type = chunk.get("type", "")

                if chunk_type == "tool_call":
                    self.signals.tool_call.emit(chunk)

                    # 如果有工具定义，尝试执行工具
                    if self.tooldefs and chunk.get("tool_calls"):
                        # 构建工具名称到 ToolDef 的映射
                        tool_map = {td.name: td for td in self.tooldefs}

                        for tool_info in chunk["tool_calls"]:
                            if not self._is_running:
                                break

                            tool_name = tool_info.get("name", "")
                            arguments = tool_info.get("arguments", {})

                            try:
                                tooldef = tool_map.get(tool_name)
                                if tooldef:
                                    result = await tooldef.call(**arguments)
                                    # 发送工具结果
                                    self.signals.chunk.emit({
                                        "type": "tool_result",
                                        "tool_name": tool_name,
                                        "result": str(result)[:200],
                                        "full_result": result
                                    })
                                else:
                                    self.signals.chunk.emit({
                                        "type": "tool_result",
                                        "tool_name": tool_name,
                                        "error": f"Unknown tool: {tool_name}"
                                    })
                            except Exception as e:
                                self.signals.chunk.emit({
                                    "type": "tool_result",
                                    "tool_name": tool_name,
                                    "error": str(e)
                                })
                elif chunk_type == "token_usage":
                    self.signals.token_usage.emit(chunk.get("usage", {}))
                else:
                    self.signals.chunk.emit(chunk)

        except Exception as e:
            self.signals.error.emit(str(e))

    def stop(self):
        """停止工作器"""
        self._is_running = False


@dataclass
class MessageData:
    """消息数据类"""
    role: str
    content: str
    reasoning: str = ""
    tool_calls: list = None

    def __post_init__(self):
        if self.tool_calls is None:
            self.tool_calls = []


# 尝试导入 QWebEngineView 用于真正的数学渲染
try:
    WEBENGINE_AVAILABLE = True
except ImportError:
    WEBENGINE_AVAILABLE = False


class MathRenderWidget(QWidget):
    """
    数学公式渲染组件 - 使用 QWebEngineView + MathJax

    提供真正的 LaTeX 数学符号渲染（分数、积分、求和等）
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._setup_ui()
        self._current_html = ""
        self._raw_text = ""  # 累积的原始 markdown 文本
        self._last_height = 0  # 上次设置的高度，防止抖动
        self._pending_height_update = False  # 是否有待处理的高度更新
        self._content_hash = None  # 内容哈希，防止重复更新

    def _setup_ui(self):
        """设置 UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 设置透明背景
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        # 设置大小策略 - 允许高度自适应
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        if WEBENGINE_AVAILABLE:
            self._web_view = QWebEngineView(self)
            # 完全透明背景，融入消息气泡
            self._web_view.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
            self._web_page = self._web_view.page()
            self._web_page.setBackgroundColor(QColor(0, 0, 0, 0))  # 透明背景

            # 去除边框和滚动条，融入背景
            self._web_view.setStyleSheet("""
                QWebEngineView {
                    background-color: transparent;
                    border: none;
                }
            """)
            # 启用本地存储和 JavaScript
            settings = self._web_view.settings()
            settings.setAttribute(QWebEngineSettings.WebAttribute.LocalStorageEnabled, True)
            settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
            settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanAccessClipboard, True)
            settings.setAttribute(QWebEngineSettings.WebAttribute.ShowScrollBars, False)
            # 设置最小宽度，防止内容被压缩
            self._web_view.setMinimumWidth(300)
            layout.addWidget(self._web_view)

            # 连接加载完成信号
            self._web_view.loadFinished.connect(self._on_load_finished)
        else:
            # 回退到 QTextBrowser
            self._web_view = QTextBrowser(self)
            self._web_view.setStyleSheet("""
                QTextBrowser {
                    background-color: transparent;
                    border: none;
                    font-family: 'Microsoft YaHei', Consolas, monospace;
                    font-size: 14px;
                    line-height: 1.6;
                }
            """)
            self._web_view.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            layout.addWidget(self._web_view)

    def set_markdown_text(self, text: str):
        """设置 Markdown 文本并渲染数学公式"""
        # 保存原始文本（用于后续追加）
        self._raw_text = text
        html = self._generate_html(text)
        self._current_html = html

        if WEBENGINE_AVAILABLE:
            # 使用 about:blank 作为 baseUrl，确保编码正确
            self._web_view.setHtml(html, QUrl("about:blank"))
            # 延迟更新高度，但检查内容是否已变化
            self._pending_height_update = True
            QTimer.singleShot(500, self._delayed_update_height)
        else:
            self._web_view.setHtml(html)
            self._update_height()

    def _generate_html(self, text: str) -> str:
        """生成包含 MathJax 的 HTML"""

        # 保护数学公式不被 markdown 处理（临时替换为占位符）
        math_placeholders = []
        def protect_math(match):
            math_placeholders.append(match.group(0))
            return f"MATHPLACEHOLDER{len(math_placeholders)-1}"

        # 保护行内公式 $...$ 和块级公式 $$...$$
        # 使用非贪婪匹配，并支持多行
        protected_text = re.sub(r'\$\$.*?\$\$', protect_math, text, flags=re.DOTALL)
        protected_text = re.sub(r'(?<!\$)\$[^\$\n]+?\$(?!\$)', protect_math, protected_text)

        # 处理 Markdown
        if MARKDOWN_AVAILABLE:
            try:
                md = markdown.Markdown(extensions=['fenced_code', 'tables', 'nl2br'])
                html_content = md.convert(protected_text)
            except Exception:
                html_content = self._simple_markdown(protected_text)
        else:
            html_content = self._simple_markdown(protected_text)

        # 恢复数学公式
        for i, math in enumerate(math_placeholders):
            html_content = html_content.replace(f"MATHPLACEHOLDER{i}", math)

        # 在 f-string 中，反斜杠会被转义（如 \f 变成换页符）
        # 需要将反斜杠转义为双反斜杠，但在 HTML 中 MathJax 需要单反斜杠
        # 所以这里不做处理，而是在 _generate_html_from_content 中使用 repr 或替换
        return self._generate_html_from_content(html_content)

    def _generate_html_from_content(self, html_content: str) -> str:
        """从已转换的 HTML 内容生成完整页面"""
        # 使用字符串拼接代替 f-string，避免反斜杠转义问题

        head_part = r"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        window.MathJax = {
            tex: {
                inlineMath: [['$', '$'], ['\\\\(', '\\\\)']],
                displayMath: [['$$', '$$'], ['\\\\[', '\\\\]']],
                processEscapes: true,
                processEnvironments: true
            },
            options: {
                skipHtmlTags: ['script', 'noscript', 'style', 'textarea', 'pre']
            },
            startup: {
                typeset: true,
                ready: () => {
                    MathJax.startup.defaultReady();
                    setTimeout(() => {
                        if (window.qtChannel) window.qtChannel.heightChanged(document.body.scrollHeight);
                    }, 100);
                }
            }
        };
    </script>
    <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
    <style>
        html, body {
            background: transparent !important;
            margin: 0;
            padding: 0;
            width: 100%;
            min-width: 280px;
        }
        body {
            font-family: "Microsoft YaHei", "PingFang SC", "Hiragino Sans GB", "Noto Sans CJK SC", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            font-size: 14px;
            line-height: 1.7;
            color: #333;
            padding: 0;
            margin: 0;
            white-space: normal !important;
            word-wrap: break-word !important;
            overflow-wrap: break-word !important;
            word-break: normal !important;
        }
        p {
            margin: 8px 0;
            white-space: normal !important;
            word-wrap: break-word !important;
            overflow-wrap: break-word !important;
            word-break: normal !important;
        }
        div {
            white-space: normal !important;
            word-wrap: break-word !important;
            word-break: normal !important;
        }
        span {
            white-space: normal !important;
        }
        h1, h2, h3, h4, h5, h6, li, td, th {
            white-space: normal !important;
            word-break: normal !important;
        }
        code, pre {
            word-break: break-all !important;
            white-space: pre-wrap !important;
        }
        pre {
            background: #263238;
            color: #aed581;
            padding: 16px;
            border-radius: 8px;
            overflow-x: auto;
            font-family: Consolas, "SF Mono", Monaco, monospace;
            font-size: 13px;
            margin: 10px 0;
        }
        code {
            background: #f5f5f5;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: Consolas, monospace;
            font-size: 0.9em;
        }
        pre code {
            background: transparent;
            padding: 0;
        }
        blockquote {
            border-left: 4px solid #2196f3;
            margin: 10px 0;
            padding: 10px 20px;
            background: #f5f5f5;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 10px 0;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background: #f5f5f5;
            font-weight: bold;
        }
        h1, h2, h3 {
            margin: 16px 0 8px 0;
        }
        ul, ol {
            margin: 8px 0;
            padding-left: 24px;
        }
        li {
            margin: 4px 0;
        }
        .MathJax {
            outline: none;
        }
        mjx-container {
            display: inline-block;
            margin: 0 2px;
        }
    </style>
</head>
<body>
"""

        tail_part = r"""
</body>
</html>
"""
        # 拼接 HTML
        result = head_part + html_content + tail_part
        return result

    def _simple_markdown(self, text: str) -> str:
        """简单 Markdown 转换"""
        # 转义 HTML
        text = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        # 粗体、斜体
        text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
        text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', text)
        # 标题
        text = re.sub(r'^### (.+)$', r'<h3>\1</h3>', text, flags=re.MULTILINE)
        text = re.sub(r'^## (.+)$', r'<h2>\1</h2>', text, flags=re.MULTILINE)
        text = re.sub(r'^# (.+)$', r'<h1>\1</h1>', text, flags=re.MULTILINE)
        # 引用、链接
        text = re.sub(r'^> (.+)$', r'<blockquote>\1</blockquote>', text, flags=re.MULTILINE)
        text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', text)
        # 列表
        text = re.sub(r'^- (.+)$', r'<li>\1</li>', text, flags=re.MULTILINE)
        # 换行：将多个连续换行合并为段落分隔，单个换行转为 <br>
        # 先处理段落（两个以上换行）
        text = re.sub(r'\n{2,}', '</p><p>', text)
        # 再处理单个换行
        text = text.replace('\n', '<br>')
        # 包装在段落中
        if not text.startswith('<'):
            text = '<p>' + text + '</p>'
        return text

    def append_markdown_text(self, text: str):
        """追加 Markdown 文本 - 流式输出时直接追加到DOM，不重新渲染"""
        if not text:
            return

        # 累积原始文本（保存原始格式用于最终渲染）
        self._raw_text += text

        if WEBENGINE_AVAILABLE:
            # 使用 base64 编码避免转义问题
            text_bytes = text.encode('utf-8')
            text_b64 = base64.b64encode(text_bytes).decode('ascii')

            # 使用JavaScript创建文本节点，保留原始换行
            js_code = f"""
                (function() {{
                    var body = document.body;
                    if (!body) return 0;

                    // 获取或创建流式内容容器
                    var streamingContainer = document.getElementById('streaming-content');
                    if (!streamingContainer) {{
                        streamingContainer = document.createElement('pre');
                        streamingContainer.id = 'streaming-content';
                        streamingContainer.style.whiteSpace = 'pre-wrap';
                        streamingContainer.style.wordWrap = 'break-word';
                        streamingContainer.style.margin = '0';
                        streamingContainer.style.padding = '0';
                        streamingContainer.style.background = 'transparent';
                        streamingContainer.style.border = 'none';
                        streamingContainer.style.fontFamily = '"Microsoft YaHei", -apple-system, sans-serif';
                        streamingContainer.style.fontSize = '14px';
                        streamingContainer.style.lineHeight = '1.7';
                        streamingContainer.style.color = '#333';
                        body.appendChild(streamingContainer);
                    }}

                    // 解码并追加文本内容（正确处理UTF-8）
                    var binary = atob('{text_b64}');
                    var decoded = decodeURIComponent(escape(binary));
                    streamingContainer.textContent += decoded;

                    return body.scrollHeight;
                }})()
            """
            self._web_view.page().runJavaScript(js_code, self._set_height)
        else:
            # 非WebEngine模式，直接追加文本
            current = self._web_view.toPlainText()
            self._web_view.setPlainText(current + text)
            self._update_height()

    def finish_streaming(self):
        """流式输出完成，重新渲染整个文档以正确处理Markdown和MathJax"""
        if self._raw_text:
            # 清除内容哈希，强制重新渲染后更新高度
            # （因为虽然内容相同，但渲染方式从<pre>变为正式Markdown）
            if hasattr(self, '_last_content_hash'):
                delattr(self, '_last_content_hash')
            self.set_markdown_text(self._raw_text)

    def _on_load_finished(self, ok):
        """页面加载完成时强制样式并更新高度"""
        if ok and WEBENGINE_AVAILABLE:
            # 强制应用样式到所有元素（解决中文换行问题）
            force_style_js = """
                (function() {
                    // 注入强制样式
                    var style = document.createElement('style');
                    style.id = 'force-wrap-style';
                    style.textContent = `
                        * {
                            white-space: normal !important;
                            word-wrap: break-word !important;
                            overflow-wrap: break-word !important;
                            word-break: normal !important;
                        }
                        p, div, span, h1, h2, h3, h4, h5, h6, li, td, th, blockquote {
                            white-space: normal !important;
                            word-break: normal !important;
                        }
                        mjx-container, mjx-container * {
                            display: inline-block !important;
                            white-space: normal !important;
                        }
                    `;
                    // 避免重复添加
                    if (!document.getElementById('force-wrap-style')) {
                        document.head.appendChild(style);
                    }
                    // 获取当前高度
                    var getHeight = function() {
                        var body = document.body;
                        var html = document.documentElement;
                        if (!body) return 0;
                        return Math.max(
                            body.scrollHeight, body.offsetHeight,
                            html.clientHeight, html.scrollHeight, html.offsetHeight
                        );
                    };
                    // 等待 MathJax 渲染完成（如果有公式）
                    if (window.MathJax && MathJax.typesetPromise && MathJax.startup && MathJax.startup.document) {
                        // 检查是否有数学公式需要渲染
                        var hasMath = document.querySelector('script[type^="math/tex"], .math, mjx-container, [class*="math"]');
                        if (hasMath || document.body.innerHTML.indexOf('$') >= 0) {
                            return MathJax.typesetPromise().then(getHeight).catch(getHeight);
                        }
                    }
                    return getHeight();
                })()
            """
            self._web_view.page().runJavaScript(force_style_js, lambda h: self._set_height(h if h else 100))
            # 额外延迟再次更新（无公式时 MathJax 可能不触发 ready）
            QTimer.singleShot(300, lambda: self._update_height())
            QTimer.singleShot(600, lambda: self._update_height())

    def _delayed_update_height(self):
        """延迟更新高度 - 检查是否仍有待处理的更新"""
        if self._pending_height_update:
            self._pending_height_update = False
            self._update_height()

    def _update_height(self):
        """根据内容调整高度"""
        if WEBENGINE_AVAILABLE:
            # WebEngineView: 使用 JavaScript 获取内容高度
            # 使用更可靠的方式获取高度
            js_code = """
                (function() {
                    var body = document.body;
                    var html = document.documentElement;
                    if (!body) return 0;
                    // 获取最大高度
                    var height = Math.max(
                        body.scrollHeight,
                        body.offsetHeight,
                        html.clientHeight,
                        html.scrollHeight,
                        html.offsetHeight
                    );
                    return height;
                })()
            """
            try:
                self._web_view.page().runJavaScript(js_code, self._set_height)
            except Exception:
                # 如果 JS 执行失败，使用备用方案
                self._set_height(100)
        else:
            doc = self._web_view.document()
            doc.setTextWidth(self._web_view.viewport().width())
            height = doc.size().height() + 20
            self._set_height(int(height))

    def _set_height(self, height: int):
        """设置组件高度"""
        if not height or height <= 0:
            height = 100
        # 限制高度在合理范围内
        final_height = max(30, min(height + 10, 5000))
        # 防止高度抖动：如果高度变化小于10像素，不更新
        if abs(final_height - self._last_height) < 10:
            return
        # 如果内容未变化，不更新高度（防止布局变化导致的误判）
        current_hash = hash(self._raw_text) if self._raw_text else 0
        if hasattr(self, '_last_content_hash') and current_hash == self._last_content_hash:
            return
        self._last_content_hash = current_hash
        self._last_height = final_height
        # 只设置最小高度，不设置固定高度，让布局管理器处理
        self._web_view.setMinimumHeight(final_height)
        self.updateGeometry()

    def resizeEvent(self, event):
        """重载大小调整事件"""
        super().resizeEvent(event)
        # 只在宽度变化时更新高度（避免高度变化导致的循环）
        # 注意：首次显示时 oldSize 可能为 (-1, -1)
        old_width = event.oldSize().width()
        new_width = event.size().width()
        if old_width > 0 and old_width != new_width:
            QTimer.singleShot(100, self._update_height)


class MarkdownTextBrowser(QTextBrowser):
    """Markdown 文本浏览器 - 支持 Markdown 渲染"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setOpenExternalLinks(True)
        self.setStyleSheet("""
            QTextBrowser {
                background-color: transparent;
                border: none;
                font-family: 'Microsoft YaHei', 'Consolas', monospace;
                font-size: 14px;
                line-height: 1.6;
            }
        """)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        # 设置基础样式
        self.document().setDefaultStyleSheet("""
            body {
                font-family: 'Microsoft YaHei', sans-serif;
                font-size: 14px;
                line-height: 1.6;
                color: #333;
            }
            code {
                background-color: #f5f5f5;
                padding: 2px 6px;
                border-radius: 3px;
                font-family: 'Consolas', monospace;
                font-size: 13px;
            }
            pre {
                background-color: #263238;
                color: #aed581;
                padding: 16px;
                border-radius: 8px;
                overflow-x: auto;
                margin: 10px 0;
            }
            pre code {
                background-color: transparent;
                padding: 0;
                color: inherit;
            }
            blockquote {
                border-left: 4px solid #2196f3;
                margin: 10px 0;
                padding: 10px 20px;
                background-color: #f5f5f5;
                color: #666;
            }
            table {
                border-collapse: collapse;
                width: 100%;
                margin: 10px 0;
            }
            th, td {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }
            th {
                background-color: #2196f3;
                color: white;
            }
            tr:nth-child(even) {
                background-color: #f9f9f9;
            }
            h1, h2, h3, h4, h5, h6 {
                color: #1976d2;
                margin: 16px 0 8px 0;
            }
            a {
                color: #2196f3;
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }
            ul, ol {
                margin: 8px 0;
                padding-left: 24px;
            }
            li {
                margin: 4px 0;
            }
        """)

    def setMarkdownText(self, text: str):
        """设置 Markdown 文本（支持 LaTeX）"""

        # 转换 Markdown
        html = self._markdown_to_html(text)

        # 使用 CSS 确保正确显示（包括换行）
        full_html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
body {{
    font-family: 'Microsoft YaHei', -apple-system, BlinkMacSystemFont, sans-serif;
    font-size: 14px;
    line-height: 1.6;
    color: #333;
    white-space: pre-wrap;
    word-wrap: break-word;
}}
pre {{
    background: #263238;
    color: #aed581;
    padding: 16px;
    border-radius: 8px;
    overflow-x: auto;
    margin: 10px 0;
    font-family: Consolas, monospace;
    white-space: pre;
}}
code {{
    background: #f5f5f5;
    padding: 2px 6px;
    border-radius: 3px;
    font-family: Consolas, monospace;
    font-size: 13px;
}}
pre code {{
    background: transparent;
    padding: 0;
}}
.math-inline {{
    background: #f0f0f0;
    padding: 1px 4px;
    border-radius: 3px;
    font-family: Consolas, monospace;
    font-size: 0.9em;
    color: #333;
}}
.math-block {{
    background: #f8f8f8;
    padding: 12px 16px;
    border-radius: 6px;
    margin: 12px 0;
    overflow-x: auto;
    font-family: Consolas, monospace;
    font-size: 14px;
    color: #333;
    border-left: 3px solid #2196f3;
}}
blockquote {{
    border-left: 4px solid #ddd;
    margin: 10px 0;
    padding: 10px 20px;
    background: #f9f9f9;
    color: #666;
}}
table {{
    border-collapse: collapse;
    width: 100%;
    margin: 10px 0;
}}
th, td {{
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}}
th {{
    background: #f5f5f5;
    font-weight: bold;
}}
ul, ol {{
    margin: 8px 0;
    padding-left: 24px;
}}
h1, h2, h3 {{
    margin: 16px 0 8px 0;
}}
</style>
</head>
<body>{html}</body>
</html>"""

        self.setHtml(full_html)
        self._update_height()

    def _simple_md_convert(self, text: str) -> str:
        """简单 Markdown 转换（无依赖）"""
        text = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
        text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', text)
        text = re.sub(r'^### (.+)$', r'<h3>\1</h3>', text, flags=re.MULTILINE)
        text = re.sub(r'^## (.+)$', r'<h2>\1</h2>', text, flags=re.MULTILINE)
        text = re.sub(r'^# (.+)$', r'<h1>\1</h1>', text, flags=re.MULTILINE)
        text = re.sub(r'^> (.+)$', r'<blockquote>\1</blockquote>', text, flags=re.MULTILINE)
        text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', text)
        text = re.sub(r'^- (.+)$', r'<li>\1</li>', text, flags=re.MULTILINE)
        paragraphs = text.split('\n\n')
        result = []
        in_list = False
        for p in paragraphs:
            p = p.strip()
            if not p:
                continue
            if p.startswith('<li>'):
                if not in_list:
                    result.append('<ul>')
                    in_list = True
                result.append(p)
            else:
                if in_list:
                    result.append('</ul>')
                    in_list = False
                if p.startswith('<'):
                    result.append(p)
                else:
                    result.append(f'<p>{p}</p>')
        if in_list:
            result.append('</ul>')
        return '\n'.join(result)

    def _update_height(self):
        """根据内容调整高度"""
        doc = self.document()
        doc.setTextWidth(self.viewport().width())
        height = doc.size().height() + 20
        self.setMinimumHeight(int(height))
        self.setMaximumHeight(int(height) + 100)

    def resizeEvent(self, event):
        """重载大小调整事件"""
        super().resizeEvent(event)
        self._update_height()

    def appendMarkdownText(self, text: str):
        """追加 Markdown 文本"""
        current = self.toPlainText()
        self.setMarkdownText(current + text)

    def _markdown_to_html(self, text: str) -> str:
        """
        Markdown + LaTeX 到 HTML 转换（兼容 QTextBrowser，无 JS）

        LaTeX 公式用特殊样式显示，不进行数学渲染
        """

        # 存储保护的内容列表（按顺序）
        protected = []

        def protect(html: str = None) -> str:
            """保护内容并返回占位符"""
            idx = len(protected)
            protected.append(html)
            return f"@@PROT{idx}@@"

        def restore(html: str) -> str:
            """还原所有保护的内容"""
            for idx, val in enumerate(protected):
                if val is not None:
                    html = html.replace(f"@@PROT{idx}@@", val)
            return html

        # 1. 保护代码块
        def code_block_repl(match):
            lang = match.group(1) or ""
            code = match.group(2)
            escaped = code.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            return protect(f'<pre class="code-block"><code>{escaped}</code></pre>')

        text = re.sub(r'```(\w+)?\n(.*?)```', code_block_repl, text, flags=re.DOTALL)

        # 2. 保护行内代码
        def inline_code_repl(match):
            code = match.group(1)
            escaped = code.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            return protect(f'<code class="inline-code">{escaped}</code>')

        text = re.sub(r'`([^`]+)`', inline_code_repl, text)

        # 3. 保护 $$...$$ 块级公式
        def block_formula_repl(match):
            formula = match.group(1).strip()
            escaped = formula.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            return protect(f'<div class="math-block">$${escaped}$$</div>')

        text = re.sub(r'\$\$(.+?)\$\$', block_formula_repl, text, flags=re.DOTALL)

        # 4. 保护 $...$ 行内公式
        def inline_formula_repl(match):
            formula = match.group(1).strip()
            escaped = formula.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            return protect(f'<span class="math-inline">${escaped}$</span>')

        text = re.sub(r'\$([^$\n]+?)\$', inline_formula_repl, text)

        # 5. 转换 Markdown
        try:
            md = markdown.Markdown(extensions=['fenced_code', 'tables', 'toc', 'nl2br'])
            html_content = md.convert(text)
        except ImportError:
            html_content = self._simple_md_convert(text)

        # 6. 还原保护的内容
        html_content = restore(html_content)

        return html_content

    def _simple_md_convert(self, text: str) -> str:
        """简单 Markdown 转换（无依赖）"""
        # 转义 HTML
        text = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        # 粗体、斜体
        text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
        text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', text)
        # 标题
        text = re.sub(r'^### (.+)$', r'<h3>\1</h3>', text, flags=re.MULTILINE)
        text = re.sub(r'^## (.+)$', r'<h2>\1</h2>', text, flags=re.MULTILINE)
        text = re.sub(r'^# (.+)$', r'<h1>\1</h1>', text, flags=re.MULTILINE)
        # 引用、链接
        text = re.sub(r'^> (.+)$', r'<blockquote>\1</blockquote>', text, flags=re.MULTILINE)
        text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', text)
        # 列表
        text = re.sub(r'^- (.+)$', r'<li>\1</li>', text, flags=re.MULTILINE)
        # 段落
        paragraphs = text.split('\n\n')
        result = []
        in_list = False
        for p in paragraphs:
            p = p.strip()
            if not p:
                continue
            if p.startswith('<li>'):
                if not in_list:
                    result.append('<ul>')
                    in_list = True
                result.append(p)
            else:
                if in_list:
                    result.append('</ul>')
                    in_list = False
                if p.startswith('<'):
                    result.append(p)
                else:
                    result.append(f'<p>{p}</p>')
        if in_list:
            result.append('</ul>')
        return '\n'.join(result)

    def _simple_markdown_to_html(self, text: str) -> str:
        """简单的 Markdown 到 HTML 转换（无外部依赖时使用）"""

        # 先处理代码块
        code_blocks = []
        def code_block_repl(match):
            lang = match.group(1) or ""
            code = match.group(2)
            code = code.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            placeholder = f"\x00CODEBLOCK{len(code_blocks)}\x00"
            code_blocks.append(f'<pre><code class="language-{lang}">{code}</code></pre>')
            return placeholder

        text = re.sub(r'```(\w+)?\n(.*?)```', code_block_repl, text, flags=re.DOTALL)

        # 转义 HTML
        text = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

        # 行内代码
        text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)

        # 粗体、斜体
        text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
        text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', text)

        # 标题
        text = re.sub(r'^### (.+)$', r'<h3>\1</h3>', text, flags=re.MULTILINE)
        text = re.sub(r'^## (.+)$', r'<h2>\1</h2>', text, flags=re.MULTILINE)
        text = re.sub(r'^# (.+)$', r'<h1>\1</h1>', text, flags=re.MULTILINE)

        # 引用、链接、列表
        text = re.sub(r'^> (.+)$', r'<blockquote>\1</blockquote>', text, flags=re.MULTILINE)
        text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', text)
        text = re.sub(r'^- (.+)$', r'<li>\1</li>', text, flags=re.MULTILINE)

        # 段落
        paragraphs = text.split('\n\n')
        paragraphs = [f'<p>{p}</p>' if not p.startswith('<') else p for p in paragraphs]
        text = '\n'.join(paragraphs)

        # 还原代码块
        for i, block in enumerate(code_blocks):
            text = text.replace(f"\x00CODEBLOCK{i}\x00", block)

        return f"<!DOCTYPE html><html><head><meta charset='UTF-8'></head><body>{text}</body></html>"


class ReasoningBlockWidget(QFrame):
    """思考块组件 - 显示 AI 的思考过程"""

    def __init__(self, block_index: int = 0, parent=None):
        super().__init__(parent)
        self.block_index = block_index
        self._is_expanded = True  # 默认展开，思考完成后自动折叠
        self._content_text = ""
        self._setup_ui()

    def _setup_ui(self):
        """设置 UI"""
        self.setStyleSheet("""
            ReasoningBlockWidget {
                background-color: #f5f5f5;
                border-radius: 8px;
                border: 1px dashed #ccc;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(4)

        # 标题栏（可点击折叠）
        header = QWidget()
        header.setCursor(Qt.CursorShape.PointingHandCursor)
        header.mousePressEvent = lambda e: self._toggle_reasoning()

        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(0, 0, 0, 0)

        # 展开/折叠图标
        self._toggle_icon = QLabel("▼")
        self._toggle_icon.setStyleSheet("font-size: 12px;")
        header_layout.addWidget(self._toggle_icon)

        # 标题
        title = QLabel(f"💭 思考过程 {self.block_index + 1}")
        title.setStyleSheet("""
            font-size: 12px;
            color: #666;
            font-weight: bold;
        """)
        header_layout.addWidget(title)

        header_layout.addStretch()

        # 状态标签
        self._status_label = QLabel("思考中...")
        self._status_label.setStyleSheet("""
            font-size: 11px;
            color: #2196f3;
        """)
        header_layout.addWidget(self._status_label)

        layout.addWidget(header)

        # 内容区域
        self._content = QTextEdit()
        self._content.setReadOnly(True)
        self._content.setStyleSheet("""
            QTextEdit {
                background-color: #fafafa;
                border: none;
                font-family: 'Consolas', monospace;
                font-size: 13px;
                color: #666;
                padding: 8px;
            }
        """)
        self._content.setMinimumHeight(80)  # 最小高度
        self._content.setMaximumHeight(400)  # 最大高度（从600减小）
        self._content.setVisible(self._is_expanded)  # 根据折叠状态设置可见性
        layout.addWidget(self._content)

        # 设置初始图标状态
        self._toggle_icon.setText("▼" if self._is_expanded else "▶")

    def _toggle_reasoning(self):
        """切换展开/折叠状态"""
        self._is_expanded = not self._is_expanded
        self._content.setVisible(self._is_expanded)
        self._toggle_icon.setText("▼" if self._is_expanded else "▶")

    def set_reasoning_finished(self):
        """设置思考完成，自动折叠"""
        self._status_label.setText("已完成")
        self._status_label.setStyleSheet("""
            font-size: 11px;
            color: #4caf50;
        """)
        # 思考完成后自动折叠
        if self._is_expanded:
            self._toggle_reasoning()

    def _format_reasoning_html(self, text: str) -> str:
        """将思考内容格式化为 HTML（支持 LaTeX 样式）"""

        # 转义 HTML
        escaped = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

        # 处理 $$...$$ 块级公式 - 特殊样式
        def block_formula_repl(match):
            formula = match.group(1).strip()
            return f'<div style="background:#f0f0f0;padding:8px 12px;border-radius:4px;margin:8px 0;overflow-x:auto;font-family:Consolas,monospace;font-size:13px;color:#555;border-left:3px solid #999;">{formula}</div>'

        escaped = re.sub(r'\$\$(.+?)\$\$', block_formula_repl, escaped, flags=re.DOTALL)

        # 处理 $...$ 行内公式 - 特殊样式
        def inline_formula_repl(match):
            formula = match.group(1).strip()
            return f'<span style="background:#e8e8e8;padding:1px 4px;border-radius:2px;font-family:Consolas,monospace;font-size:0.9em;color:#555;">{formula}</span>'

        escaped = re.sub(r'\$([^$\n]+?)\$', inline_formula_repl, escaped)

        # 换行转 <br>
        escaped = escaped.replace('\n', '<br>')

        return f"""
        <html>
        <head><meta charset="UTF-8"></head>
        <body style="font-family:Consolas,'SF Mono',monospace;font-size:13px;line-height:1.5;color:#666;padding:0;margin:0;">
        {escaped}
        </body>
        </html>
        """

    def append_reasoning(self, text: str):
        """追加思考内容"""
        self._content_text += text
        self._content.setHtml(self._format_reasoning_html(self._content_text))
        # 滚动到底部
        scrollbar = self._content.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())


class MessageWidget(QFrame):
    """消息组件 - 显示单条消息"""

    def __init__(self, message_data: MessageData, message_index: int = -1, parent=None):
        super().__init__(parent)
        self.message_data = message_data
        self.message_index = message_index
        self.signals = MessageWidgetSignals()
        self._current_reasoning_widget = None
        self._tool_call_widgets = {}
        self._setup_ui()

    def _setup_ui(self):
        """设置 UI"""
        # 根据角色设置样式
        bg_color = self._get_bg_color()
        border_color = self._get_border_color()

        self.setStyleSheet(f"""
            MessageWidget {{
                background-color: {bg_color};
                border-radius: 12px;
                border: 1px solid {border_color};
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)

        # 头部信息栏
        header = QWidget()
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(0, 0, 0, 0)

        # 角色图标和名称
        role_label = QLabel(f"{self._get_role_display()}")
        role_label.setStyleSheet(f"""
            font-size: 12px;
            font-weight: bold;
            color: {self._get_role_color()};
        """)
        header_layout.addWidget(role_label)

        header_layout.addStretch()

        # 操作按钮面板
        hover_panel = QWidget()
        hover_layout = QHBoxLayout(hover_panel)
        hover_layout.setContentsMargins(0, 0, 0, 0)
        hover_layout.setSpacing(4)

        # 复制按钮（所有消息都有）
        copy_btn = QPushButton("📚")
        copy_btn.setToolTip("复制内容")
        copy_btn.setStyleSheet("""
            QPushButton {
                border: none;
                background-color: transparent;
                font-size: 14px;
                padding: 2px 6px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: rgba(0, 0, 0, 0.1);
            }
        """)
        copy_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        copy_btn.clicked.connect(self._on_copy)
        hover_layout.addWidget(copy_btn)

        # 撤销按钮（仅用户消息有，且需要有有效索引）
        if self.message_data.role == "user" and self.message_index >= 0:
            undo_btn = QPushButton("↩️")
            undo_btn.setToolTip("撤销到此消息（恢复输入并回滚）")
            undo_btn.setStyleSheet("""
                QPushButton {
                    border: none;
                    background-color: transparent;
                    font-size: 14px;
                    padding: 2px 6px;
                    border-radius: 4px;
                }
                QPushButton:hover {
                    background-color: rgba(255, 0, 0, 0.1);
                }
            """)
            undo_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            undo_btn.clicked.connect(self._on_undo)
            hover_layout.addWidget(undo_btn)

        header_layout.addWidget(hover_panel)

        layout.addWidget(header)

        # 思考过程区域（仅 AI 消息）
        self._reasoning_container = None
        if self.message_data.role == "assistant":
            self._reasoning_container = QWidget()
            self._reasoning_layout = QVBoxLayout(self._reasoning_container)
            self._reasoning_layout.setContentsMargins(0, 0, 0, 0)
            self._reasoning_layout.setSpacing(4)
            layout.addWidget(self._reasoning_container)

            # 如果已有思考内容，显示它
            if self.message_data.reasoning:
                self._add_reasoning_block(self.message_data.reasoning)

        # 工具调用区域（仅 AI 消息）
        self._tool_container = None
        if self.message_data.role == "assistant":
            self._tool_container = QWidget()
            self._tool_layout = QVBoxLayout(self._tool_container)
            self._tool_layout.setContentsMargins(0, 0, 0, 0)
            self._tool_layout.setSpacing(4)
            self._tool_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)
            layout.addWidget(self._tool_container)

            # 添加已有的工具调用
            for tool_call in self.message_data.tool_calls:
                self.add_tool_call(tool_call.get("name", ""), tool_call.get("id", ""))

        # 内容区域 - 使用 MathRenderWidget 支持真正的数学公式渲染
        self._content = MathRenderWidget()
        self._content.set_markdown_text(self.message_data.content)
        layout.addWidget(self._content)

    def _get_role_display(self) -> str:
        """获取角色显示名称"""
        names = {
            "user": "👤 用户",
            "assistant": "🤖 AI",
            "system": "⚙️ 系统",
            "tool": "🔧 工具"
        }
        return names.get(self.message_data.role, self.message_data.role)

    def _get_role_color(self) -> str:
        """获取角色颜色"""
        colors = {
            "user": "#1976d2",
            "assistant": "#388e3c",
            "system": "#f57c00",
            "tool": "#7b1fa2"
        }
        return colors.get(self.message_data.role, "#666666")

    def _get_bg_color(self) -> str:
        """获取背景颜色"""
        colors = {
            "user": "#e3f2fd",
            "assistant": "#f5f5f5",
            "system": "#fff3e0",
            "tool": "#f3e5f5"
        }
        return colors.get(self.message_data.role, "#fafafa")

    def _get_border_color(self) -> str:
        """获取边框颜色"""
        colors = {
            "user": "#bbdefb",
            "assistant": "#e0e0e0",
            "system": "#ffe0b2",
            "tool": "#e1bee7"
        }
        return colors.get(self.message_data.role, "#e0e0e0")

    def update_content(self, content: str):
        """更新内容"""
        self.message_data.content = content
        self._content.set_markdown_text(content)

    def append_content(self, text: str):
        """追加内容"""
        self.message_data.content += text
        self._content.append_markdown_text(text)

    def finish_content_streaming(self):
        """完成内容流式输出，重新渲染以正确处理 Markdown 和 MathJax"""
        self._content.finish_streaming()

    def start_new_reasoning(self) -> ReasoningBlockWidget:
        """开始新的思考块（仅 AI 消息）"""
        if self._reasoning_container is None:
            raise RuntimeError("User messages do not support reasoning")
        block = ReasoningBlockWidget(self._reasoning_layout.count())
        self._reasoning_layout.addWidget(block)
        self._current_reasoning_widget = block
        return block

    def _freeze_current_content(self):
        """冻结当前内容（在开始新的 reasoning 之前）"""
        if self.message_data.content and self._current_reasoning_widget:
            # 保存当前内容到 reasoning 数据
            self.message_data.reasoning = self.message_data.content

    def append_reasoning(self, text: str):
        """追加思考内容"""
        if self._current_reasoning_widget:
            self._current_reasoning_widget.append_reasoning(text)
        else:
            # 创建新的思考块
            block = self.start_new_reasoning()
            block.append_reasoning(text)

    def finish_current_reasoning(self):
        """完成当前思考"""
        if self._current_reasoning_widget:
            self._current_reasoning_widget.set_reasoning_finished()
            self._current_reasoning_widget = None

    def _on_copy(self):
        """复制内容"""
        clipboard = QApplication.clipboard()
        clipboard.setText(self.message_data.content)

    def _on_undo(self):
        """撤销请求"""
        self.signals.undo_requested.emit(self.message_index)

    def _get_or_create_tool_call_row(self) -> QWidget:
        """获取或创建工具调用行（仅 AI 消息）"""
        if self._tool_container is None:
            raise RuntimeError("User messages do not support tool calls")
        # 如果最后一个工具调用行已满（3个）或没有，创建新行
        if self._tool_layout.count() == 0:
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(8)
            row_layout.addStretch()
            self._tool_layout.addWidget(row)
            return row

        last_row = self._tool_layout.itemAt(self._tool_layout.count() - 1).widget()
        if last_row.layout().count() >= 4:  # stretch + 3 个工具
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(8)
            row_layout.addStretch()
            self._tool_layout.addWidget(row)
            return row

        return last_row

    def add_tool_call(self, tool_name: str, tool_id: str):
        """添加工具调用显示（仅 AI 消息）"""
        if self._tool_container is None:
            raise RuntimeError("User messages do not support tool calls")
        tool_widget = ToolCallWidget(tool_name, tool_id, "pending")
        self._tool_call_widgets[tool_id or tool_name] = tool_widget

        row = self._get_or_create_tool_call_row()
        row.layout().insertWidget(row.layout().count() - 1, tool_widget)

    def update_tool_call(self, tool_id_or_name: str, status: str, result: str = ""):
        """更新工具调用状态"""
        if tool_id_or_name in self._tool_call_widgets:
            self._tool_call_widgets[tool_id_or_name].update_status(status, result)


class QAIChatWidget(QMainWindow):
    """
    QAI 聊天主窗口

    提供与 AI 交互的图形界面
    """

    def __init__(self, ai: Optional[AICore] = None, parent=None):
        super().__init__(parent)

        self._ai = ai
        self._messages: list[Message] = []
        self._message_widgets: list[MessageWidget] = []
        self._system_prompt = ""
        self._is_streaming = False
        self._current_worker = None

        # 工具配置
        self._tooldefs: list[ToolDef] | None = None

        self._setup_ui()
        self._setup_connections()

    def _setup_ui(self):
        """设置 UI 界面"""
        self.setWindowTitle("QAI 聊天")
        self.setMinimumSize(800, 600)
        self.resize(900, 700)

        # 中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # 主布局
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)

        # 消息区域
        self._scroll_area = QScrollArea()
        self._scroll_area.setWidgetResizable(True)
        self._scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #fafafa;
            }
        """)

        self._messages_container = QWidget()
        self._messages_layout = QVBoxLayout(self._messages_container)
        self._messages_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self._messages_layout.setSpacing(10)
        self._messages_layout.addStretch()

        self._scroll_area.setWidget(self._messages_container)
        main_layout.addWidget(self._scroll_area, 1)

        # 输入区域
        input_layout = QHBoxLayout()

        self._input_field = QLineEdit()
        self._input_field.setPlaceholderText("输入消息...")
        self._input_field.setStyleSheet("""
            QLineEdit {
                padding: 10px;
                border: 1px solid #ccc;
                border-radius: 8px;
                font-size: 14px;
                font-family: 'Microsoft YaHei', sans-serif;
            }
            QLineEdit:focus {
                border: 2px solid #2196f3;
            }
        """)
        input_layout.addWidget(self._input_field, 1)

        self._send_btn = QPushButton("发送")
        self._send_btn.setFixedWidth(80)
        self._send_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196f3;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 10px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976d2;
            }
            QPushButton:pressed {
                background-color: #1565c0;
            }
            QPushButton:disabled {
                background-color: #bdbdbd;
            }
        """)
        input_layout.addWidget(self._send_btn)

        # 停止按钮
        self._stop_btn = QPushButton("停止")
        self._stop_btn.setFixedWidth(80)
        self._stop_btn.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 10px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #d32f2f;
            }
        """)
        self._stop_btn.setVisible(False)
        input_layout.addWidget(self._stop_btn)

        main_layout.addLayout(input_layout)

        # 顶部控制栏（使用 QWidget 而不是 QToolBar）
        header = QWidget()
        header.setFixedHeight(40)
        header.setStyleSheet("""
            QWidget {
                background-color: #f5f5f5;
                border-bottom: 1px solid #ddd;
            }
        """)
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(12, 0, 8, 0)
        header_layout.setSpacing(8)

        # 左侧：图标按钮（正方形）
        # 新对话按钮
        self._new_chat_btn = QPushButton("➕")
        self._new_chat_btn.setFixedSize(32, 32)
        self._new_chat_btn.setToolTip("新对话")
        self._new_chat_btn.setStyleSheet("""
            QPushButton {
                border: 1px solid #ccc;
                border-radius: 4px;
                background-color: #f5f5f5;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
            }
        """)
        self._new_chat_btn.clicked.connect(self.clear_messages)
        header_layout.addWidget(self._new_chat_btn)

        # 设置按钮（打开 QAISettingsDialog）
        self._settings_btn = QPushButton("⚙")
        self._settings_btn.setFixedSize(32, 32)
        self._settings_btn.setToolTip("设置")
        self._settings_btn.setStyleSheet("""
            QPushButton {
                border: 1px solid #ccc;
                border-radius: 4px;
                background-color: #f5f5f5;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
            }
        """)
        self._settings_btn.clicked.connect(self._open_settings)
        header_layout.addWidget(self._settings_btn)

        header_layout.addStretch()

        # 右侧：Token 使用统计容器
        token_container = QWidget()
        token_layout = QHBoxLayout(token_container)
        token_layout.setContentsMargins(0, 0, 0, 0)
        token_layout.setSpacing(4)

        # Token 数量 label（默认透明，hover 时淡入）
        self._token_label = QLabel("0 / 0")
        self._token_label.setStyleSheet("""
            QLabel {
                font-size: 11px;
                color: #666666;
            }
        """)
        # 设置 opacity effect 用于动画
        self._token_label_opacity = QGraphicsOpacityEffect(self._token_label)
        self._token_label_opacity.setOpacity(0.0)  # 默认完全透明
        self._token_label.setGraphicsEffect(self._token_label_opacity)
        token_layout.addWidget(self._token_label)

        # 创建淡入淡出动画
        self._token_label_animation = QPropertyAnimation(self._token_label_opacity, b"opacity")
        self._token_label_animation.setDuration(200)  # 200ms 动画时长
        self._token_label_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

        # Token 使用环形进度条
        self._token_indicator = CircularProgressBar(size=40)
        self._token_indicator.setMouseTracking(True)
        token_layout.addWidget(self._token_indicator)

        # 为 token_container 设置鼠标事件处理
        token_container.setMouseTracking(True)
        token_container.enterEvent = self._on_token_container_enter
        token_container.leaveEvent = self._on_token_container_leave

        header_layout.addWidget(token_container)

        header_layout.addSpacing(10)

        # AI 模型选择
        self._model_combo = QComboBox()
        self._model_combo.setMinimumWidth(100)
        self._refresh_model_combo()
        self._model_combo.currentTextChanged.connect(self._on_model_changed)
        self._model_combo.setStyleSheet("""
            QComboBox {
                background-color: #ffffff;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 5px 8px;
                padding-right: 24px;
                color: #333333;
                font-size: 13px;
                min-height: 20px;
            }
            QComboBox:hover {
                border: 1px solid #5a9bd5;
            }
            QComboBox::drop-down {
                border: none;
                width: 22px;
                background: transparent;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 6px solid #666666;
                width: 0;
                height: 0;
                margin-top: 2px;
            }
            QComboBox::down-arrow:on {
                border-top: none;
                border-bottom: 6px solid #666666;
            }
            QComboBox QAbstractItemView {
                background-color: #ffffff;
                color: #333333;
                selection-background-color: #5a9bd5;
                selection-color: #ffffff;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 4px 0;
                outline: none;
            }
            QComboBox QAbstractItemView::item {
                padding: 8px 12px;
                min-height: 20px;
            }
            QComboBox QAbstractItemView::item:hover {
                background-color: #e8f4fc;
                color: #333333;
            }
            QComboBox QAbstractItemView::item:selected {
                background-color: #5a9bd5;
                color: #ffffff;
            }
        """)
        header_layout.addWidget(self._model_combo)

        # 将 header 添加到主布局顶部
        main_layout.insertWidget(0, header)

        # 状态栏
        self._status_bar = QStatusBar()
        self.setStatusBar(self._status_bar)
        self._status_bar.showMessage("就绪")

    def _setup_connections(self):
        """设置信号连接"""
        self._send_btn.clicked.connect(self._on_send)
        self._input_field.returnPressed.connect(self._on_send)
        self._stop_btn.clicked.connect(self.stop_generation)

    def _refresh_model_combo(self):
        """刷新 AI 模型选择下拉框

        使用 get_available_models 获取所有可用模型，
        根据配置状态显示：
        - empty 始终排在最前面
        - 有配置的 AI 正常显示
        - 无 apikey 的显示为灰色并追加 [未配置]
        """

        self._model_combo.clear()

        # 获取所有可用模型和配置
        available_models = get_available_models()
        config = QAIConfig()
        providers = config.load()

        # 构建模型列表，empty 始终在最前
        model_items = []
        empty_item = None

        for name, cls in available_models.items():
            # 获取 provider 名称（去掉 AI 后缀）
            provider_name = name[:-2] if name.endswith('AI') else name
            provider_name = provider_name.lower()

            # 检查是否有配置
            provider_config = providers.get(provider_name, {})
            has_config = bool(provider_config.get('key', '').strip())

            if provider_name == 'empty':
                # empty 始终排在最前面
                empty_item = (provider_name, True, name)
            else:
                model_items.append((provider_name, has_config, name))

        # 排序：empty 在最前，其他按名称排序
        model_items.sort(key=lambda x: x[0])

        # 使用自定义模型以支持禁用特定项
        model = QStandardItemModel()

        # 先添加 empty
        if empty_item:
            item = QStandardItem(empty_item[0])
            item.setData(empty_item[0], Qt.ItemDataRole.UserRole)  # 存储原始 provider 名
            model.appendRow(item)

        # 添加其他模型
        for provider_name, has_config, class_name in model_items:
            if has_config:
                # 有配置：正常显示
                item = QStandardItem(provider_name)
            else:
                # 无配置：显示灰色并追加 [未配置]
                item = QStandardItem(f"{provider_name} [未配置]")
                item.setEnabled(False)
                item.setData(Qt.GlobalColor.gray, Qt.ItemDataRole.ForegroundRole)
            item.setData(provider_name, Qt.ItemDataRole.UserRole)  # 存储原始 provider 名
            model.appendRow(item)

        self._model_combo.setModel(model)

    def _on_send(self):
        """发送消息"""
        text = self._input_field.text().strip()
        if not text:
            return

        if not self._ai:
            QMessageBox.warning(self, "未配置", "请先配置 AI 提供商")
            return

        # 添加用户消息
        self._add_message("user", text)
        self._messages.append(Message(role="user", content=text))
        self._input_field.clear()

        # 开始流式响应
        self._start_stream_response()

    def _add_message(self, role: str, content: str = "", reasoning: str = "") -> MessageWidget:
        """添加消息"""
        # 移除 stretch
        stretch = self._messages_layout.takeAt(self._messages_layout.count() - 1)

        # 创建消息数据
        message_data = MessageData(role=role, content=content, reasoning=reasoning)

        # 创建消息组件
        widget = MessageWidget(message_data, len(self._message_widgets))
        widget.signals.undo_requested.connect(self._on_undo_requested)

        self._message_widgets.append(widget)
        self._messages_layout.addWidget(widget)

        # 重新添加 stretch
        self._messages_layout.addStretch()

        # 滚动到底部
        QTimer.singleShot(100, self._scroll_to_bottom)

        return widget

    def _scroll_to_bottom(self):
        """滚动到底部"""
        scrollbar = self._scroll_area.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def _start_stream_response(self):
        """开始流式响应"""
        self._is_streaming = True
        self._send_btn.setVisible(False)
        self._stop_btn.setVisible(True)
        self._status_bar.showMessage("AI 思考中...")

        # 添加 AI 消息组件
        self._current_widget = self._add_message("assistant", "")

        # 创建工作器
        self._current_worker = StreamWorker(
            self._ai,
            self._messages,
            self._tooldefs
        )

        # 连接信号
        self._current_worker.signals.chunk.connect(self._on_chunk)
        self._current_worker.signals.tool_call.connect(self._on_tool_call)
        self._current_worker.signals.token_usage.connect(self._on_token_usage)
        self._current_worker.signals.error.connect(self._on_error)
        self._current_worker.signals.finished.connect(self._on_finished)

        # 启动工作器
        QThreadPool.globalInstance().start(self._current_worker)

    def _on_chunk(self, chunk: dict):
        """处理流式输出块"""
        chunk_type = chunk.get("type", "")

        if chunk_type == "content":
            text = chunk.get("text", "")
            self._current_widget.append_content(text)
            self._scroll_to_bottom()

        elif chunk_type == "reasoning_start":
            self._current_widget.start_new_reasoning()

        elif chunk_type == "reasoning":
            text = chunk.get("text", "")
            self._current_widget.append_reasoning(text)

        elif chunk_type == "reasoning_end":
            self._current_widget.finish_current_reasoning()

        elif chunk_type == "tool_result":
            tool_name = chunk.get("tool_name", "")
            result = chunk.get("result", "")
            self._current_widget.append_content(f"\n[工具 {tool_name} 结果]: {result}\n")

    def _on_tool_call(self, tool_info: dict):
        """处理工具调用"""
        tool_calls = tool_info.get("tool_calls", [])
        for tool in tool_calls:
            tool_name = tool.get("name", "")
            tool_id = tool.get("id", "")
            self._current_widget.add_tool_call(tool_name, tool_id)

    def _on_token_usage(self, usage: dict):
        """处理 Token 使用信息"""
        total = usage.get("total_tokens", 0)
        self._status_bar.showMessage(f"Token 使用: {total}")

        # 更新指示器
        max_tokens = self._ai.maxContextTokens() if self._ai else 0
        current = usage.get("total_tokens", 0)
        self._token_indicator.set_max_tokens(max_tokens)
        self._token_indicator.set_current_tokens(current)

        # 更新标签
        if max_tokens > 0:
            self._token_label.setText(f"{current:,} / {max_tokens:,}")
        else:
            self._token_label.setText(f"{current:,} / ∞")

    def _on_error(self, error: str):
        """处理错误"""
        self._current_widget.append_content(f"\n[错误: {error}]\n")

    def _on_finished(self):
        """完成响应"""
        self._is_streaming = False
        self._send_btn.setVisible(True)
        self._stop_btn.setVisible(False)
        self._status_bar.showMessage("就绪")

        # 流式输出完成，重新渲染以正确处理 Markdown 和 MathJax
        if self._current_widget:
            self._current_widget.finish_content_streaming()

        # 保存 AI 回复到历史
        content = self._current_widget.message_data.content
        if content:
            self._messages.append(Message(role="assistant", content=content))

        self._current_worker = None

    def _on_undo_requested(self, message_index: int):
        """处理撤销请求"""
        # 保留到 message_index 之前的消息
        self._messages = self._messages[:message_index]

        # 移除对应的消息组件
        for i in range(message_index, len(self._message_widgets)):
            widget = self._message_widgets[i]
            self._messages_layout.removeWidget(widget)
            widget.deleteLater()

        self._message_widgets = self._message_widgets[:message_index]
        self._status_bar.showMessage(f"已撤销到消息 {message_index}")

    def stop_generation(self):
        """停止生成"""
        if self._current_worker:
            self._current_worker.stop()
            self._status_bar.showMessage("已停止")

    def clear_messages(self):
        """清空对话历史"""
        # 清空布局中的所有部件（保留 stretch）
        while self._messages_layout.count() > 1:
            item = self._messages_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        # 清空数据
        self._message_widgets.clear()
        self._messages.clear()
        self._status_bar.showMessage("对话已清空")

    def set_system_prompt(self):
        """设置系统提示词"""
        dialog = QDialog(self)
        dialog.setWindowTitle("设置系统提示词")
        dialog.setMinimumSize(500, 300)

        layout = QVBoxLayout(dialog)

        text_edit = QPlainTextEdit()
        text_edit.setPlainText(self._system_prompt)
        layout.addWidget(text_edit)

        btn_layout = QHBoxLayout()

        save_btn = QPushButton("保存")
        save_btn.clicked.connect(dialog.accept)
        btn_layout.addWidget(save_btn)

        cancel_btn = QPushButton("取消")
        cancel_btn.clicked.connect(dialog.reject)
        btn_layout.addWidget(cancel_btn)

        layout.addLayout(btn_layout)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            self._system_prompt = text_edit.toPlainText()
            self._status_bar.showMessage("系统提示词已更新")

    def _open_settings(self):
        """打开设置对话框"""
        result = ShowSettingsDialog()
        if result:
            self._status_bar.showMessage(f"设置已保存: {len(result.get('providers', {}))} 个提供商")
            # 刷新模型列表以反映配置变化
            self._refresh_model_combo()

    def _on_model_changed(self, model_name: str):
        """模型切换"""
        # 从当前选中项获取原始 provider 名称
        idx = self._model_combo.currentIndex()
        if idx < 0:
            return

        provider = self._model_combo.model().item(idx).data(Qt.ItemDataRole.UserRole)
        if not provider:
            return

        try:
            new_ai = CreateAI(provider, only=True)
            self._ai = new_ai
            # 重置上下文百分比控件
            self._token_indicator.set_percentage(0)
            self._status_bar.showMessage(f"已切换到模型: {provider}")
        except Exception as e:
            QMessageBox.warning(self, "切换失败", f"无法切换到 {provider}: {e}")

    def set_ai(self, ai: AICore):
        """设置 AI 实例"""
        self._ai = ai
        # 更新combobox显示
        if ai:
            provider = ai.providerName()
            # 在 model 中查找匹配的 provider
            model = self._model_combo.model()
            for i in range(model.rowCount()):
                item = model.item(i)
                if item and item.data(Qt.ItemDataRole.UserRole) == provider:
                    self._model_combo.setCurrentIndex(i)
                    break

    def setTooldefs(self, tooldefs: list[ToolDef] | None):
        """设置工具定义列表

        Args:
            tooldefs: ToolDef 列表，每个 ToolDef 封装了一个函数及其 OpenAI 格式定义
        """
        self._tooldefs = tooldefs

    def _on_token_container_enter(self, event=None):
        """鼠标进入 token 容器时淡入显示 label"""
        if hasattr(self, '_token_label_animation') and self._token_label_animation:
            self._token_label_animation.stop()
            self._token_label_animation.setStartValue(self._token_label_opacity.opacity())
            self._token_label_animation.setEndValue(1.0)
            self._token_label_animation.start()

    def _on_token_container_leave(self, event=None):
        """鼠标离开 token 容器时淡出隐藏 label"""
        if hasattr(self, '_token_label_animation') and self._token_label_animation:
            self._token_label_animation.stop()
            self._token_label_animation.setStartValue(self._token_label_opacity.opacity())
            self._token_label_animation.setEndValue(0.0)
            self._token_label_animation.start()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle('Fusion')

    # 创建空 AI 实例用于测试

    ai = EmptyAI()

    window = QAIChatWidget(ai)
    window.show()

    sys.exit(app.exec())
