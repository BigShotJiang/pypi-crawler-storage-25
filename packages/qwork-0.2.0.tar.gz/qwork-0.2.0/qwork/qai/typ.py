# -*- coding: utf-8 -*-
"""
QAI 共享类型定义

提供所有模块共享的类型别名、枚举和协议类
"""

from typing import AsyncIterator, Dict, List, Optional, Any, Protocol, Union
from dataclasses import dataclass
from enum import Enum


# ==================== 类型别名 ====================

JsonDict = Dict[str, Any]
"""JSON 风格的字典类型"""

MessageList = List[Dict[str, Any]]
"""消息列表类型（OpenAI 格式）"""

StreamChunk = Dict[str, Any]
"""流式输出块类型"""


# ==================== 枚举 ====================

class MessageRole(str, Enum):
    """消息角色枚举"""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


class StreamChunkType(str, Enum):
    """流式输出块类型枚举"""
    REASONING_START = "reasoning_start"
    REASONING = "reasoning"
    REASONING_END = "reasoning_end"
    CONTENT = "content"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    TOKEN_USAGE = "token_usage"


# ==================== 协议类 ====================

class ToolExecutorProtocol(Protocol):
    """工具执行器协议"""

    async def execute(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """
        执行工具调用

        Args:
            tool_name: 工具名称
            arguments: 工具参数

        Returns:
            工具执行结果
        """
        ...


class AIProviderProtocol(Protocol):
    """AI 提供商协议"""

    @property
    def provider_name(self) -> str: ...

    @property
    def default_model(self) -> str: ...

    @property
    def supports_streaming(self) -> bool: ...

    @property
    def supports_tools(self) -> bool: ...

    async def chat(self, messages: List[Any], **kwargs) -> Any: ...

    async def chat_stream(self, messages: List[Any], **kwargs) -> AsyncIterator[StreamChunk]: ...


# ==================== 数据类 ====================

@dataclass
class TokenUsage:
    """Token 使用数据类"""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, int]]) -> 'TokenUsage':
        """从字典创建 TokenUsage"""
        if not data:
            return cls()
        return cls(
            prompt_tokens=data.get('prompt_tokens', 0),
            completion_tokens=data.get('completion_tokens', 0),
            total_tokens=data.get('total_tokens', 0)
        )


@dataclass
class ProviderConfig:
    """提供商配置数据类"""
    name: str
    url: str
    key: str
    default_model: Optional[str] = None
    extra_params: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, str]:
        """转换为字典（不包含敏感信息）"""
        return {
            'name': self.name,
            'url': self.url,
            'key': '***' if self.key else '',
            'default_model': self.default_model or '',
        }


@dataclass
class ChatMessage:
    """聊天消息数据类（简化版）"""
    role: str
    content: str
    metadata: Optional[Dict[str, Any]] = None

    def to_openai_format(self) -> Dict[str, str]:
        """转换为 OpenAI 格式"""
        return {"role": self.role, "content": self.content}


# ==================== 便捷函数 ====================

def create_stream_chunk(chunk_type: StreamChunkType, **kwargs) -> StreamChunk:
    """
    创建标准格式的流式输出块

    Args:
        chunk_type: 块类型
        **kwargs: 其他字段

    Returns:
        StreamChunk: 流式输出块
    """
    return {"type": chunk_type.value, **kwargs}
