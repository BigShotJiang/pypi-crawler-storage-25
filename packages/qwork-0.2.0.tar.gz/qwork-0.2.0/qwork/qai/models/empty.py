# -*- coding: utf-8 -*-

from __future__ import annotations
"""
Empty AI 实现 - 基于 AICore 抽象类

作为默认 AI 占位符，当没有配置 AI 时使用。
所有方法返回空结果或错误提示。
"""

import sys
import os
import asyncio
from typing import Dict, Optional, Any, List, AsyncIterator

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from qwork.qai.aio import AICore, Message, ChatResponse, ToolDef


class EmptyAI(AICore):
    """
    空 AI 实现类

    作为默认占位符，不提供实际的 AI 功能。
    所有方法返回空结果或友好的错误提示。
    """

    def providerName(self) -> str:
        """AI 提供商名称"""
        return "empty"

    def defaultModel(self) -> str:
        """默认模型名称"""
        return "none"

    def supportsStreaming(self) -> bool:
        """是否支持流式输出"""
        return False

    def supportsTools(self) -> bool:
        """是否支持工具调用"""
        return False

    def maxStepsPerTurn(self) -> int:
        """单轮最大步骤数"""
        return 1

    def maxContextTokens(self) -> int:
        """
        最大上下文 token 数

        Returns:
            int: 0 (无限制，因为不实际处理)
        """
        return 0

    def currentTokenCount(self) -> int:
        """
        当前上下文的 token 数量

        Returns:
            int: 始终返回 0，因为 EmptyAI 不维护实际状态
        """
        return 0

    def _createConfig(self, config: Dict[str, str]) -> Any:
        """创建空配置对象"""
        return {}

    def loadConfig(self) -> Optional[Dict[str, str]]:
        """
        加载配置

        EmptyAI 总是返回一个空配置，表示不需要配置
        """
        return {"url": "", "key": ""}

    async def chat(
        self,
        messages: list[Message | str],
        model: Optional[str] = None,
        temperature: float = 0.7,
        maxtokens: Optional[int] = None,
        tooldefs: Optional[list[ToolDef]] = None,
        **kwargs
    ) -> ChatResponse:
        """
        非流式聊天对话

        返回提示用户配置 AI 的消息
        """
        return ChatResponse(
            content="[AI not configured]\n\nPlease configure AI provider (Kimi, Qwen, etc.) in settings.",
            model=self.defaultModel(),
            usage={"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        )

    async def chatStream(
        self,
        messages: list[Message | str],
        model: Optional[str] = None,
        temperature: float = 0.7,
        maxtokens: Optional[int] = None,
        tooldefs: Optional[list[ToolDef]] = None,
        **kwargs
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        流式聊天对话

        返回提示用户配置 AI 的消息
        """
        yield {"type": "content", "text": "[AI not configured]\n\nPlease configure AI provider (Kimi, Qwen, etc.) in settings."}

    async def rollback(self, conversationidx: int) -> bool:
        """
        回滚到指定对话索引之前的状态

        空 AI 始终返回 True
        """
        print(f"[EmptyAI] Rollback to conversation index {conversationidx}")
        return True


# 测试代码
if __name__ == "__main__":
    async def test():
        print("=" * 50)
        print("EmptyAI Implementation Test")
        print("=" * 50)

        # 创建实例
        print("\n1. Creating EmptyAI instance...")
        ai = EmptyAI()
        print(f"   Provider: {ai.providerName()}")
        print(f"   Default model: {ai.defaultModel()}")
        print(f"   Supports streaming: {ai.supportsStreaming()}")
        print(f"   Supports tools: {ai.supportsTools()}")

        # 健康检查
        print("\n2. Health check...")
        healthy = await ai.healthCheck()
        print(f"   Status: {'OK' if healthy else 'FAILED (expected)'}")

        # 简单对话
        print("\n3. Simple chat test...")
        response = await ai.simpleChat("Hello")
        print(f"   Response: {response}")

        # 完整对话
        print("\n4. Chat with messages...")
        messages = [
            Message(role="user", content="What is 2+2?")
        ]
        response = await ai.chat(messages)
        print(f"   Response: {response.content}")

        # 流式输出
        print("\n5. Stream test...")
        print("   Stream: ", end='', flush=True)
        async for chunk in ai.chatStream(messages):
            print(chunk.get("text", ""), end='', flush=True)
        print()

        print("\n" + "=" * 50)
        print("EmptyAI tests passed!")
        print("=" * 50)

    asyncio.run(test())
