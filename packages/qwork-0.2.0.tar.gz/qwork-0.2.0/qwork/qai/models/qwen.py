# -*- coding: utf-8 -*-

from __future__ import annotations
"""


Qwen AI 实现 - 基于 AICore 抽象类

提供对 通义千问 (Qwen) API 的支持，使用 OpenAI 格式
支持工具调用和流式输出
"""

from openai import AsyncOpenAI
from qwork.qai.config import LoadProviderConfig
import traceback


import sys
import os
import asyncio
import json
from typing import Dict, Optional, Any, List, AsyncIterator

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from qwork.qai.aio import AICore, Message, ChatResponse, ToolCall, ToolCallResult, ToolDef


# ==================== 模块级辅助函数 ====================

def _get_client(config: Dict[str, str]):
    """获取 OpenAI 客户端实例"""
    return AsyncOpenAI(
        api_key=config['key'],
        base_url=config['url']
    )


def _convert_messages(messages: list) -> list[dict]:
    """将 Message 对象或 dict 列表转换为 OpenAI 格式"""
    result = []
    for msg in messages:
        # 处理字典格式
        if isinstance(msg, dict):
            result.append(msg)
            continue

        # 处理 Message 对象
        msg_dict = {"role": msg.role, "content": msg.content}
        if msg.tool_calls and msg.role == "assistant":
            msg_dict["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.name,
                        "arguments": tc.arguments
                    }
                }
                for tc in msg.tool_calls
            ]
        if msg.tool_call_id:
            msg_dict["tool_call_id"] = msg.tool_call_id
        result.append(msg_dict)
    return result


def _convert_tooldefs(tooldefs: Optional[List[ToolDef]]) -> Optional[List[Dict[str, Any]]]:
    """将 ToolDef 列表转换为 OpenAI 格式工具定义"""
    if not tooldefs:
        return None
    return [td.todict() for td in tooldefs]


async def _execute_tool_calls(
    tool_calls: List[ToolCall],
    tooldefs: Optional[List[ToolDef]]
) -> List[ToolCallResult]:
    """执行工具调用"""
    if not tooldefs:
        return []

    # 构建工具名称到 ToolDef 的映射
    tool_map = {td.name: td for td in tooldefs}

    results = []
    for tc in tool_calls:
        try:
            args = tc.parseArguments()
            tooldef = tool_map.get(tc.name)
            if not tooldef:
                results.append(ToolCallResult(
                    tool_call_id=tc.id,
                    name=tc.name,
                    output=f"Unknown tool: {tc.name}",
                    success=False
                ))
                continue

            # 使用 ToolDef.call 执行工具
            result = await tooldef.call(**args)
            results.append(ToolCallResult(
                tool_call_id=tc.id,
                name=tc.name,
                output=str(result),
                success=True
            ))
        except Exception as e:
            results.append(ToolCallResult(
                tool_call_id=tc.id,
                name=tc.name,
                output=f"Error: {e}",
                success=False
            ))

    return results


# ==================== QwenAI 类 ====================

class QwenAI(AICore):
    """
    通义千问 AI 实现类

    使用 OpenAI 兼容 API 与 Qwen 服务交互
    支持流式输出和工具调用
    """

    def providerName(self) -> str:
        """AI 提供商名称"""
        return "qwen"

    def defaultModel(self) -> str:
        """默认模型名称"""
        return "qwen3.5-plus"

    def supportsStreaming(self) -> bool:
        """是否支持流式输出"""
        return True

    def supportsTools(self) -> bool:
        """是否支持工具调用"""
        return True

    def maxStepsPerTurn(self) -> int:
        """单轮最大步骤数"""
        return 64

    def maxContextTokens(self) -> int:
        """
        Qwen 模型支持的最大上下文 token 数

        Returns:
            int: 256000 tokens (256k)
        """
        return 256000

    def currentTokenCount(self) -> int:
        """
        当前上下文的 token 数量

        QwenAI 不维护实际状态，返回 0。
        GUI 应使用 ai.estimate_tokens_for_messages() 实例方法进行估算。

        Returns:
            int: 始终返回 0
        """
        return 0

    def _createConfig(self, config: Dict[str, str]) -> Dict[str, str]:
        """从配置字典创建配置对象"""
        # 确保 URL 以 /v1 结尾
        base_url = config.get('url', '').rstrip('/')
        if not base_url.endswith('/v1'):
            base_url = base_url + '/v1'

        return {
            'url': base_url,
            'key': config.get('key', '')
        }

    def loadConfig(self) -> Optional[Dict[str, str]]:
        """从配置文件加载 API 凭证 {"url": ..., "key": ...}"""
        try:
            return LoadProviderConfig("qwen")
        except Exception:
            return None

    async def chat(
        self,
        messages: list[Message | str],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tooldefs: Optional[List[ToolDef]] = None,
        **kwargs
    ) -> ChatResponse:
        """
        非流式聊天对话

        使用 OpenAI 兼容 API 调用 Qwen
        """
        config = self._ensureConfig()
        client = _get_client(config)
        openai_messages = _convert_messages(messages)

        # 构建请求参数
        request_params = {
            "model": model or self.defaultModel(),
            "messages": openai_messages,
            "temperature": temperature,
            "stream": False
        }

        if max_tokens is not None:
            request_params["max_tokens"] = max_tokens

        # 转换并添加工具（如果提供）
        tools = _convert_tooldefs(tooldefs) if tooldefs else None
        if tools and self.supportsTools():
            request_params["tools"] = tools
            request_params["tool_choice"] = "auto"

        # Qwen 特有参数：enable_thinking（混合思考模式，默认启用）
        enable_thinking = kwargs.get("enable_thinking", True)
        if enable_thinking:
            request_params["extra_body"] = {
                "enable_thinking": True
            }

        try:
            # 多轮工具调用循环
            max_tool_rounds = kwargs.get('max_steps_per_turn', self.maxStepsPerTurn())
            tool_round = 0

            while tool_round < max_tool_rounds:
                response = await client.chat.completions.create(**request_params)
                message = response.choices[0].message
                content = message.content or ""

                # 如果没有工具调用，直接返回结果
                if not hasattr(message, 'tool_calls') or not message.tool_calls:
                    break

                # 有工具调用，需要执行并继续循环
                tool_round += 1
                if not tooldefs:
                    break

                # 构建工具调用列表
                tool_calls = []
                for tc in message.tool_calls:
                    tool_call = ToolCall(
                        id=tc.id,
                        name=tc.function.name,
                        arguments=tc.function.arguments
                    )
                    tool_calls.append(tool_call)

                # 执行工具调用
                tool_results = await _execute_tool_calls(tool_calls, tooldefs)

                # 将 assistant 消息（含 tool_calls）添加到历史
                openai_messages.append({
                    "role": "assistant",
                    "content": content,
                    "tool_calls": [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {
                                "name": tc.name,
                                "arguments": tc.arguments
                            }
                        }
                        for tc in tool_calls
                    ]
                })

                # 将 tool 结果添加到历史
                for result in tool_results:
                    openai_messages.append({
                        "role": "tool",
                        "tool_call_id": result.tool_call_id,
                        "content": result.output
                    })

                # 更新请求参数，继续循环
                request_params["messages"] = openai_messages

            # 提取使用量
            usage = None
            if hasattr(response, 'usage') and response.usage:
                usage = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens
                }

            return ChatResponse(
                content=content,
                model=response.model,
                usage=usage
            )

        except Exception as e:
            return ChatResponse(
                content=f"Error: {str(e)}",
                model=model or self.defaultModel(),
                usage=None
            )

    async def chatStream(
        self,
        messages: list[Message | str],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tooldefs: Optional[List[ToolDef]] = None,
        **kwargs
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        流式聊天对话

        使用 OpenAI 兼容 API 流式调用 Qwen
        """
        config = self._ensureConfig()
        client = _get_client(config)
        openai_messages = _convert_messages(messages)

        # 构建请求参数
        request_params = {
            "model": model or self.defaultModel(),
            "messages": openai_messages,
            "temperature": temperature,
            "stream": True,
            "stream_options": {"include_usage": True}
        }

        if max_tokens is not None:
            request_params["max_tokens"] = max_tokens

        # 转换并添加工具（如果提供）
        tools = _convert_tooldefs(tooldefs) if tooldefs else None
        if tools and self.supportsTools():
            request_params["tools"] = tools
            request_params["tool_choice"] = "auto"

        # Qwen 特有参数：enable_thinking（混合思考模式，默认启用）
        enable_thinking = kwargs.get("enable_thinking", True)
        if enable_thinking:
            request_params["extra_body"] = {
                "enable_thinking": True
            }

        # 多轮工具调用循环
        max_tool_rounds = kwargs.get('max_steps_per_turn', self.maxStepsPerTurn())
        tool_round = 0
        total_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}

        try:
            while tool_round < max_tool_rounds:
                stream = await client.chat.completions.create(**request_params)

                reasoning_started = False
                pending_tool_calls: Dict[str, Dict[str, Any]] = {}
                current_tool_call: Optional[Dict[str, Any]] = None
                has_tool_calls = False
                assistant_content = ""

                async for chunk in stream:
                    delta = chunk.choices[0].delta if chunk.choices else None

                    # 处理使用量信息
                    if hasattr(chunk, 'usage') and chunk.usage:
                        total_usage["prompt_tokens"] += chunk.usage.prompt_tokens
                        total_usage["completion_tokens"] += chunk.usage.completion_tokens
                        total_usage["total_tokens"] += chunk.usage.total_tokens

                    # 如果没有 delta，跳过后续处理
                    if not delta:
                        continue

                    # 处理 reasoning_content（如果模型支持）
                    if hasattr(delta, 'reasoning_content') and delta.reasoning_content:
                        if not reasoning_started:
                            reasoning_started = True
                            yield {"type": "reasoning_start", "text": ""}
                        yield {"type": "reasoning", "text": delta.reasoning_content}
                        continue

                    # 普通内容
                    if delta.content:
                        if reasoning_started:
                            reasoning_started = False
                            yield {"type": "reasoning_end", "text": ""}
                        assistant_content += delta.content
                        yield {"type": "content", "text": delta.content}

                    # 处理工具调用
                    if hasattr(delta, 'tool_calls') and delta.tool_calls:
                        has_tool_calls = True
                        for tc in delta.tool_calls:
                            if tc.id:
                                # 新工具调用开始
                                current_tool_call = {
                                    "id": tc.id,
                                    "name": tc.function.name if tc.function else "",
                                    "arguments": tc.function.arguments if tc.function and tc.function.arguments else ""
                                }
                                pending_tool_calls[tc.id] = current_tool_call
                                yield {
                                    "type": "tool_call",
                                    "name": current_tool_call["name"],
                                    "arguments": current_tool_call["arguments"],
                                    "id": tc.id
                                }
                            elif current_tool_call and tc.function and tc.function.arguments:
                                # 追加参数
                                current_tool_call["arguments"] += tc.function.arguments

                    # 检测工具调用完成
                    if chunk.choices and hasattr(chunk.choices[0], 'finish_reason'):
                        if chunk.choices[0].finish_reason == 'tool_calls':
                            has_tool_calls = True

                if reasoning_started:
                    yield {"type": "reasoning_end", "text": ""}

                # 如果没有工具调用，结束循环
                if not has_tool_calls or not tooldefs or not pending_tool_calls:
                    break

                # 执行工具调用并继续下一轮
                tool_round += 1

                # 构建完整的工具调用结果
                tool_calls_list = []
                for tool_id, tool_info in pending_tool_calls.items():
                    tool_calls_list.append(ToolCall(
                        id=tool_id,
                        name=tool_info["name"],
                        arguments=tool_info["arguments"]
                    ))

                tool_results = await _execute_tool_calls(tool_calls_list, tooldefs)

                # 将 assistant 消息（含 tool_calls）添加到历史
                openai_messages.append({
                    "role": "assistant",
                    "content": assistant_content,
                    "tool_calls": [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {
                                "name": tc.name,
                                "arguments": tc.arguments
                            }
                        }
                        for tc in tool_calls_list
                    ]
                })

                # 将 tool 结果添加到历史并 yield
                for result in tool_results:
                    yield {
                        "type": "tool_result",
                        "name": result.name,
                        "result": result.output,
                        "id": result.tool_call_id
                    }
                    openai_messages.append({
                        "role": "tool",
                        "tool_call_id": result.tool_call_id,
                        "content": result.output
                    })

                # 更新请求参数继续循环
                request_params["messages"] = openai_messages

            # 输出累计的使用量
            if total_usage["total_tokens"] > 0:
                yield {
                    "type": "token_usage",
                    "usage": total_usage
                }

        except Exception as e:
            yield {"type": "content", "text": f"Error: {str(e)}"}

    async def rollback(self, conversation_index: int) -> bool:
        """
        回滚到指定对话索引之前的状态

        Qwen AI 使用无状态的 API 调用，对话历史由调用方管理。

        Args:
            conversation_index: 要回滚到的对话索引（该索引及之后的对话将被移除）

        Returns:
            bool: 回滚是否成功（始终返回 True，因为 Qwen API 是无状态的）
        """
        print(f"[QwenAI] Rollback to conversation index {conversation_index}")
        return True


# 测试代码
if __name__ == "__main__":
    async def test():
        print("=" * 50)
        print("QwenAI Implementation Test")
        print("=" * 50)

        try:
            # 创建实例
            print("\n1. Creating QwenAI instance...")
            ai = QwenAI()
            print(f"   Provider: {ai.provider_name}")
            print(f"   Default model: {ai.default_model}")
            print(f"   Supports streaming: {ai.supports_streaming}")
            print(f"   Supports tools: {ai.supports_tools}")

            # 健康检查
            print("\n2. Health check...")
            healthy = await ai.health_check()
            print(f"   Status: {'OK' if healthy else 'FAILED'}")

            if not healthy:
                print("Health check failed, skipping chat tests")
                return

            # 简单对话
            print("\n3. Simple chat test...")
            response = await ai.simple_chat(
                "Say 'Hello from Qwen AI!' and nothing else.",
                system_prompt="You are a helpful assistant."
            )
            print(f"   Response: {response}")

            # 完整对话
            print("\n4. Chat with messages...")
            messages = [
                Message(role="system", content="You are a helpful assistant."),
                Message(role="user", content="What is 2+2? Answer in one word.")
            ]
            response = await ai.chat(messages)
            print(f"   Response: {response.content}")
            print(f"   Model: {response.model}")

            # 流式输出
            print("\n5. Stream test...")
            print("   Stream: ", end='', flush=True)
            async for chunk in ai.chat_stream(messages):
                print(chunk.get("text", ""), end='', flush=True)
            print()

            print("\n" + "=" * 50)
            print("All tests passed!")
            print("=" * 50)

        except Exception as e:
            print(f"\nError: {type(e).__name__}: {e}")
            traceback.print_exc()
            sys.exit(1)

    asyncio.run(test())
