"""
QAI 模型子模块

自动注册所有可用的 AI 模型实现
自动发现：自动扫描 models/ 目录下所有 .py 文件（除 aio 和私有模块外）
智能识别：只导入以 AI 结尾且定义在该模块中的类（如 KimiAI、DeepSeekAI）
容错处理：单个模块导入失败不会影响其他模块加载
向后兼容：__all__ 动态生成，包含所有成功加载的类
便捷函数：提供 get_available_models()

"""

import importlib
import pkgutil
import os
from typing import Dict, Type, Any

# 当前包目录
_current_dir = os.path.dirname(os.path.abspath(__file__))

# 存储成功导入的类
_registered_models: Dict[str, Type] = {}
_import_errors: list = []

# 自动发现所有模型模块（跳过私有模块和 aio）
for _finder, _module_name, _is_pkg in pkgutil.iter_modules([_current_dir]):
    # 跳过 __init__、私有模块和 aio 基类模块
    if _module_name.startswith('_') or _module_name == 'aio':
        continue
    
    try:
        # 动态导入模块
        _module = importlib.import_module(f'.{_module_name}', __name__)
        
        # 查找模块中定义的 AI 类（以 AI 结尾且定义在该模块中）
        for _attr_name in dir(_module):
            # 只关心以 AI 结尾的类名（如 EmptyAI, KimiAI）
            if not _attr_name.endswith('AI') or _attr_name.startswith('_'):
                continue
            
            _cls = getattr(_module, _attr_name)
            
            # 确保是类、且定义在当前模块（避免导入依赖项中的类）
            if isinstance(_cls, type) and _cls.__module__ == _module.__name__:
                _registered_models[_attr_name] = _cls
                globals()[_attr_name] = _cls
                
    except Exception as _e:
        _import_errors.append((_module_name, str(_e)))

# 设置 __all__ 为动态发现的类名
__all__ = list(_registered_models.keys())

# 开发调试用：如果有导入错误可取消注释查看
# if _import_errors:
#     import warnings
#     for mod, err in _import_errors:
#         warnings.warn(f"QAI module '{mod}' failed to load: {err}", RuntimeWarning)


# 便捷函数：获取所有可用的 AI 实现类
def get_available_models() -> Dict[str, Type]:
    """返回所有已注册的 AI 模型类字典 {name: class}"""
    return _registered_models.copy()
