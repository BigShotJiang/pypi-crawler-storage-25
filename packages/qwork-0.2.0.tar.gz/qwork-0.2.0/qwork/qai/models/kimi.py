# -*- coding: utf-8 -*-

from __future__ import annotations
"""
Kimi AI 实现 - 基于 AICore 抽象类

提供对 Kimi API 的支持，使用 kimi_agent_sdk
支持 OpenAI 格式的工具定义
"""

from kosong.tooling import CallableTool2, ToolReturnValue
from pydantic import create_model, Field
from typing import Any as TypingAny
from kimi_agent_sdk import Session
from kaos.path import KaosPath
from kosong.message import TextPart, ThinkPart
import traceback
from qwork.qai.config import LoadProviderConfig


import sys
import os
import asyncio
import json
import types
from typing import Dict, Optional, Any, List, AsyncIterator

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from pydantic import SecretStr, BaseModel, Field
from kimi_cli.config import Config, LLMProvider, LLMModel

from qwork.qai.aio import AICore, Message, ChatResponse, ToolCall, ToolCallResult, ToolDef


# ==================== 工具执行结果 ====================

class ToolResult:
    """工具执行结果（兼容 Kimi SDK 格式）"""
    __slots__ = ('success', 'output', 'message')

    def __init__(self, success: bool, output: str = "", message: str = ""):
        self.success = success
        self.output = output
        self.message = message

    @classmethod
    def ok(cls, output: str) -> "ToolResult":
        return cls(success=True, output=str(output), message="")

    @classmethod
    def error(cls, message: str) -> "ToolResult":
        return cls(success=False, output="", message=message)


# ==================== 模块级辅助函数 ====================


# ==================== 工具执行结果 ====================

class ToolResult:
    """工具执行结果（兼容 Kimi SDK 格式）"""
    __slots__ = ('success', 'output', 'message')

    def __init__(self, success: bool, output: str = "", message: str = ""):
        self.success = success
        self.output = output
        self.message = message

    @classmethod
    def ok(cls, output: str) -> "ToolResult":
        return cls(success=True, output=str(output), message="")

    @classmethod
    def error(cls, message: str) -> "ToolResult":
        return cls(success=False, output="", message=message)


# ==================== 模块级辅助函数 ====================

def _convert_tools_to_kimi(tooldefs: List[ToolDef]) -> List[Any]:
    """
    将 ToolDef 列表转换为 Kimi SDK 工具

    使用 kosong.tooling.CallableTool2 创建兼容的工具
    """
    if not tooldefs:
        return []

    try:

        kimi_tools = []

        for tooldef in tooldefs:
            # 从 ToolDef 获取 OpenAI 格式定义
            tool_dict = tooldef.todict()
            func_def = tool_dict.get('function', {})

            name = func_def.get('name', '')
            description = func_def.get('description', '')
            parameters = func_def.get('parameters', {})

            if not name:
                continue

            # 禁用可能危险的工具
            DISABLED_TOOLS = {'ReadFile', 'WriteFile', 'StrReplaceFile', 'Shell'}
            if name in DISABLED_TOOLS:
                continue

            # 创建参数模型
            properties = parameters.get('properties', {})
            required = parameters.get('required', [])

            # 构建 Pydantic 模型字段
            fields = {}
            for param_name, param_info in properties.items():
                param_type = param_info.get('type', 'string')
                param_desc = param_info.get('description', '')

                if param_type == 'string':
                    default = ... if param_name in required else None
                    fields[param_name] = (str, Field(default=default, description=param_desc))
                elif param_type == 'integer':
                    default = ... if param_name in required else None
                    fields[param_name] = (int, Field(default=default, description=param_desc))
                elif param_type == 'number':
                    default = ... if param_name in required else None
                    fields[param_name] = (float, Field(default=default, description=param_desc))
                elif param_type == 'boolean':
                    default = ... if param_name in required else None
                    fields[param_name] = (bool, Field(default=default, description=param_desc))
                elif param_type == 'object':
                    default = ... if param_name in required else None
                    fields[param_name] = (Dict[str, Any], Field(default=default, description=param_desc))
                elif param_type == 'array':
                    default = ... if param_name in required else None
                    fields[param_name] = (List[Any], Field(default=default, description=param_desc))
                else:
                    default = ... if param_name in required else None
                    fields[param_name] = (TypingAny, Field(default=default, description=param_desc))

            # 创建参数模型
            if fields:
                ParamsModel = create_model(f'{name}_Params', **fields)
            else:
                ParamsModel = create_model(f'{name}_Params', __base__=BaseModel)

            # 创建工具实例（使用闭包捕获 tooldef）
            tool_instance = _create_tool_instance(name, description, ParamsModel, tooldef)
            if tool_instance:
                kimi_tools.append(tool_instance)

        return kimi_tools

    except Exception as e:
        print(f"[KimiAI] Error converting tools: {e}")
        traceback.print_exc()
        return []


def _create_tool_instance(name: str, description: str, ParamsModel: Any, tooldef: ToolDef):
    """创建工具实例（使用闭包捕获 tooldef）"""

    class ToolImpl(CallableTool2[ParamsModel]):
        def __init__(self):
            super().__init__(name=name, description=description, params=ParamsModel)

        async def __call__(self, params):
            """执行工具调用"""
            try:
                # 将 Pydantic 模型转换为字典
                if hasattr(params, 'model_dump'):
                    args = params.model_dump()
                elif hasattr(params, 'dict'):
                    args = params.dict()
                else:
                    args = vars(params)

                # 调用 ToolDef 的 call 方法
                result = await tooldef.call(**args)

                # 构造返回值
                return ToolReturnValue(
                    is_error=False,
                    output=str(result),
                    message="",
                    display=[]
                )
            except Exception as e:
                return ToolReturnValue(
                    is_error=True,
                    output="",
                    message=f"Error: {e}",
                    display=[]
                )

    try:
        return ToolImpl()
    except Exception as e:
        print(f"[KimiAI] Failed to create tool {name}: {e}")
        return None


async def _execute_tool_calls(
    tool_calls: List[ToolCall],
    toolexecutor: Optional[Any]
) -> List[ToolCallResult]:
    """执行工具调用"""
    if not toolexecutor:
        return []

    results = []
    for tc in tool_calls:
        try:
            args = tc.parse_arguments()
            if hasattr(toolexecutor, 'execute'):
                result = await toolexecutor.execute(tc.name, args)
                if hasattr(result, 'success') and hasattr(result, 'output'):
                    results.append(ToolCallResult(
                        tool_call_id=tc.id,
                        name=tc.name,
                        output=result.output if result.success else result.message,
                        success=result.success
                    ))
                else:
                    results.append(ToolCallResult(
                        tool_call_id=tc.id,
                        name=tc.name,
                        output=str(result),
                        success=True
                    ))
            else:
                results.append(ToolCallResult(
                    tool_call_id=tc.id,
                    name=tc.name,
                    output="Tool executor does not have execute method",
                    success=False
                ))
        except Exception as e:
            results.append(ToolCallResult(
                tool_call_id=tc.id,
                name=tc.name,
                output=f"Error: {e}",
                success=False
            ))

    return results


# ==================== KimiAI 类 ====================

class KimiAI(AICore):
    """
    Kimi AI 实现类

    使用 kimi_agent_sdk 与 Kimi API 交互
    遵守 Onion 架构约定：只实现抽象方法，不定义新属性和 __init__
    支持 OpenAI 格式的工具定义，内部转换为 Kimi 格式
    """

    def providerName(self) -> str:
        """AI 提供商名称"""
        return "kimi"

    def defaultModel(self) -> str:
        """默认模型名称"""
        return "kimi"

    def supportsStreaming(self) -> bool:
        """是否支持流式输出"""
        return True

    def supportsTools(self) -> bool:
        """是否支持工具调用"""
        return True

    def maxStepsPerTurn(self) -> int:
        """单轮最大步骤数"""
        return 256

    def maxContextTokens(self) -> int:
        """
        Kimi 模型支持的最大上下文 token 数

        Returns:
            int: 256000 tokens (256k)
        """
        return 256000

    def currentTokenCount(self) -> int:
        """
        当前上下文的 token 数量

        EmptyAI 不维护实际状态，返回 0。
        GUI 应使用 ai.estimate_tokens_for_messages() 实例方法进行估算。

        Returns:
            int: 始终返回 0
        """
        return 0

    def _createConfig(self, config: Dict[str, str]) -> Config:
        """从配置字典创建 Config 对象"""
        # 确保 URL 以 /v1 结尾
        base_url = config['url']
        if not base_url.rstrip('/').endswith('/v1'):
            base_url = base_url.rstrip('/') + '/v1'

        # 创建内部配置
        provider = LLMProvider(
            type="kimi",
            base_url=base_url,
            api_key=SecretStr(config['key'])
        )

        model = LLMModel(
            provider="kimi",
            model="kimi",
            max_context_size=256000
        )

        return Config(
            providers={"kimi": provider},
            models={"kimi": model},
            default_model="kimi"
        )

    def loadConfig(self) -> Optional[Dict[str, str]]:
        """从配置文件加载 API 凭证 {"url": ..., "key": ...}"""
        try:
            return LoadProviderConfig("kimi")
        except Exception:
            return None

    async def chat(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tooldefs: Optional[List[ToolDef]] = None,
        **kwargs
    ) -> ChatResponse:
        """
        非流式聊天对话

        使用 kimi_agent_sdk.Session 或 prompt 实现
        支持 OpenAI 格式的工具定义
        """

        def _get_msg_attr(msg, attr: str):
            """获取消息属性，支持 dict 和 Message 对象"""
            if isinstance(msg, dict):
                return msg.get(attr, "")
            return getattr(msg, attr, "")

        config = self._ensureConfig()
        user_input = _get_msg_attr(messages[-1], "content") if messages else ""

        # 构建完整对话历史
        full_context = ""
        for msg in messages:
            role = _get_msg_attr(msg, "role")
            content = _get_msg_attr(msg, "content")
            if role == "system":
                full_context = f"System: {content}\n\n" + full_context
            elif role == "user":
                full_context += f"User: {content}\n"
            elif role == "assistant":
                full_context += f"Assistant: {content}\n"

        # 转换工具为 Kimi 格式
        kimi_tools = _convert_tools_to_kimi(tooldefs) if tooldefs else []

        async with await Session.create(
            work_dir=KaosPath.cwd(),
            config=config,
            model=model or self.defaultModel(),
            thinking=True,
            yolo=False,  # 禁用内置工具（ReadFile, Shell 等）
            max_steps_per_turn=kwargs.get('max_steps_per_turn', self.maxStepsPerTurn()),
        ) as session:
            # 添加工具到 session
            if kimi_tools and hasattr(session, '_cli') and hasattr(session._cli, 'soul'):
                soul = session._cli.soul
                if hasattr(soul, 'agent') and hasattr(soul.agent, 'toolset'):
                    toolset = soul.agent.toolset
                    for tool in kimi_tools:
                        try:
                            toolset.add(tool)
                        except Exception:
                            pass

            response_text = []
            tool_results = []

            print(f"[DEBUG KIMI CHAT] 开始 session.prompt，上下文长度: {len(full_context)} 字符", flush=True)
            # 提示词已保存到项目根目录的 prompt.txt 文件中，不再打印到控制台
            message_count = 0
            start_time = asyncio.get_event_loop().time()
            last_message_time = start_time
            TIMEOUT_SECONDS = 300  # 5分钟无消息超时
            TOTAL_TIMEOUT_SECONDS = 600  # 10分钟总超时（增强需要更长时间）

            try:
                async for wire_msg in session.prompt(full_context, merge_wire_messages=True):
                    msg_type = type(wire_msg).__name__
                    message_count += 1
                    current_time = asyncio.get_event_loop().time()
                    last_message_time = current_time
                    elapsed = current_time - start_time

                    if message_count % 10 == 0:
                        print(f"[DEBUG KIMI CHAT] 已接收 {message_count} 条消息，已运行 {elapsed:.1f}秒", flush=True)

                    # 检查无消息超时
                    if current_time - last_message_time > TIMEOUT_SECONDS:
                        print(f"[DEBUG KIMI CHAT] 无消息超时：{TIMEOUT_SECONDS}秒内没有新消息", flush=True)
                        break

                    # 检查总超时
                    if elapsed > TOTAL_TIMEOUT_SECONDS:
                        print(f"[DEBUG KIMI CHAT] 总超时：运行超过 {TOTAL_TIMEOUT_SECONDS} 秒，强制退出", flush=True)
                        break

                    # 处理文本内容
                    if hasattr(wire_msg, 'text'):
                        text = wire_msg.text
                        if text:
                            response_text.append(text)
                    elif hasattr(wire_msg, 'extract_text'):
                        text = wire_msg.extract_text()
                        if text:
                            response_text.append(text)

                    # 处理工具调用结果
                    elif msg_type == 'ToolResult':
                        tool_name = getattr(wire_msg, 'name', '')
                        result = getattr(wire_msg, 'content', '') or getattr(wire_msg, 'result', '')
                        tool_results.append(f"[{tool_name}]: {result}")

            except Exception as e:
                print(f"[DEBUG KIMI CHAT] session.prompt 异常: {e}", flush=True)
                traceback.print_exc()
                raise

            total_elapsed = asyncio.get_event_loop().time() - start_time
            print(f"[DEBUG KIMI CHAT] session.prompt 结束，共接收 {message_count} 条消息，响应长度: {len(''.join(response_text))} 字符，总耗时: {total_elapsed:.1f}秒", flush=True)

            full_response = ''.join(response_text)

            # 如果有工具结果，追加到响应
            if tool_results:
                full_response += "\n\n" + "\n".join(tool_results)

            print(f"[DEBUG KIMI CHAT] 返回 ChatResponse，内容长度: {len(full_response)} 字符", flush=True)
            return ChatResponse(
                content=full_response,
                model=model or self.defaultModel(),
                usage=None
            )

    async def chatStream(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tooldefs: Optional[List[ToolDef]] = None,
        **kwargs
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        流式聊天对话

        使用 Session 获得真正的流式体验，支持工具调用
        支持 OpenAI 格式的工具定义
        """

        def _get_msg_attr(msg, attr: str):
            """获取消息属性，支持 dict 和 Message 对象"""
            if isinstance(msg, dict):
                return msg.get(attr, "")
            return getattr(msg, attr, "")

        config = self._ensureConfig()

        # 构建完整对话历史
        full_context = ""
        for msg in messages:
            role = _get_msg_attr(msg, "role")
            content = _get_msg_attr(msg, "content")
            if role == "system":
                full_context = f"System: {content}\n\n" + full_context
            elif role == "user":
                full_context += f"User: {content}\n"
            elif role == "assistant":
                full_context += f"Assistant: {content}\n"

        # 转换工具为 Kimi 格式
        kimi_tools = _convert_tools_to_kimi(tooldefs) if tooldefs else []

        async with await Session.create(
            work_dir=KaosPath.cwd(),
            config=config,
            model=model or self.defaultModel(),
            thinking=True,
            yolo=False,  # 禁用内置工具（ReadFile, Shell 等）
            max_steps_per_turn=kwargs.get('max_steps_per_turn', self.maxStepsPerTurn()),
        ) as session:
            # 添加工具到 session
            if kimi_tools and hasattr(session, '_cli') and hasattr(session._cli, 'soul'):
                soul = session._cli.soul
                if hasattr(soul, 'agent') and hasattr(soul.agent, 'toolset'):
                    toolset = soul.agent.toolset
                    for tool in kimi_tools:
                        try:
                            toolset.add(tool)
                        except Exception:
                            pass

            reasoning_started = False
            pending_tool_calls = []  # 队列：存储 (tool_id, tool_name) 按调用顺序

            async for wire_msg in session.prompt(full_context, merge_wire_messages=False):
                msg_type = type(wire_msg).__name__

                # 处理思考过程
                if isinstance(wire_msg, ThinkPart):
                    if not reasoning_started:
                        reasoning_started = True
                        yield {"type": "reasoning_start", "text": ""}
                    yield {"type": "reasoning", "text": wire_msg.think}

                # 处理正文内容
                elif isinstance(wire_msg, TextPart):
                    if reasoning_started:
                        reasoning_started = False
                        yield {"type": "reasoning_end", "text": ""}
                    text = wire_msg.text.replace('\ufffd', '').replace('\u200b', '')
                    if text:
                        yield {"type": "content", "text": text}

                # 处理工具调用
                elif msg_type == 'ToolCall':
                    # ToolCall 使用 function.name 结构
                    func = getattr(wire_msg, 'function', None)
                    tool_name = getattr(func, 'name', '') if func else getattr(wire_msg, 'name', '')
                    tool_args = getattr(func, 'arguments', '') if func else getattr(wire_msg, 'arguments', '')
                    tool_id = getattr(wire_msg, 'id', f'call_{len(pending_tool_calls)}')
                    # 加入队列，供 ToolResult 匹配
                    pending_tool_calls.append((tool_id, tool_name))
                    yield {
                        "type": "tool_call",
                        "name": tool_name,
                        "arguments": str(tool_args),
                        "id": tool_id
                    }

                # 处理工具结果 - 工具已由 Kimi Agent SDK 内部执行
                elif msg_type == 'ToolResult':
                    result = getattr(wire_msg, 'content', '') or getattr(wire_msg, 'result', '')
                    # 如果没有 content/result，尝试从 return_value 获取
                    if not result:
                        return_value = getattr(wire_msg, 'return_value', None)
                        if return_value:
                            result = getattr(return_value, 'output', '') or getattr(return_value, 'result', '')
                    # 获取工具执行的成功状态（如果有）
                    success = getattr(wire_msg, 'success', True)
                    # 从队列中取出对应的工具信息（按顺序匹配）
                    if pending_tool_calls:
                        tool_id, tool_name = pending_tool_calls.pop(0)
                    else:
                        tool_id = ''
                        tool_name = ''

                    yield {
                        "type": "tool_result",
                        "name": tool_name,
                        "result": str(result),
                        "id": tool_id,
                        "success": success
                    }

                # 捕获 token 使用信息
                elif msg_type == 'StatusUpdate':
                    token_usage = getattr(wire_msg, 'token_usage', None)
                    if token_usage:
                        input_total = (getattr(token_usage, 'input_other', 0) +
                                      getattr(token_usage, 'input_cache_read', 0) +
                                      getattr(token_usage, 'input_cache_creation', 0))
                        yield {
                            "type": "token_usage",
                            "usage": {
                                "prompt_tokens": input_total,
                                "completion_tokens": getattr(token_usage, 'output', 0),
                                "total_tokens": getattr(token_usage, 'total', 0) or (input_total + getattr(token_usage, 'output', 0))
                            }
                        }

            if reasoning_started:
                yield {"type": "reasoning_end", "text": ""}

    async def rollback(self, conversation_index: int) -> bool:
        """
        回滚到指定对话索引之前的状态

        Kimi AI 使用无状态的 API 调用，对话历史由调用方管理。

        Args:
            conversation_index: 要回滚到的对话索引（该索引及之后的对话将被移除）

        Returns:
            bool: 回滚是否成功（始终返回 True，因为 Kimi API 是无状态的）
        """
        print(f"[KimiAI] Rollback to conversation index {conversation_index}")
        return True


# 测试代码
if __name__ == "__main__":
    async def test():
        print("=" * 50)
        print("KimiAI Implementation Test")
        print("=" * 50)

        try:
            # 创建实例
            print("\n1. Creating KimiAI instance...")
            ai = KimiAI()
            print(f"   Provider: {ai.provider_name}")
            print(f"   Default model: {ai.default_model}")
            print(f"   Supports streaming: {ai.supports_streaming}")
            print(f"   Supports tools: {ai.supports_tools}")

            # 健康检查
            print("\n2. Health check...")
            healthy = await ai.health_check()
            print(f"   Status: {'OK' if healthy else 'FAILED'}")

            if not healthy:
                print("Health check failed, skipping chat tests")
                return

            # 简单对话
            print("\n3. Simple chat test...")
            response = await ai.simple_chat(
                "Say 'Hello from Kimi AI!' and nothing else.",
                system_prompt="You are a helpful assistant."
            )
            print(f"   Response: {response}")

            # 完整对话
            print("\n4. Chat with messages...")
            messages = [
                Message(role="system", content="You are a helpful assistant."),
                Message(role="user", content="What is 2+2? Answer in one word.")
            ]
            response = await ai.chat(messages)
            print(f"   Response: {response.content}")
            print(f"   Model: {response.model}")

            # 流式输出
            print("\n5. Stream test...")
            print("   Stream: ", end='', flush=True)
            async for chunk in ai.chat_stream(messages):
                print(chunk.get("text", ""), end='', flush=True)
            print()

            # 工具调用测试
            print("\n6. Tool call test...")
            # 使用 OpenAI 格式的工具定义
            test_tools = [
                {
                    "type": "function",
                    "function": {
                        "name": "calculator",
                        "description": "执行基础数学运算",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "expression": {
                                    "type": "string",
                                    "description": "要计算的数学表达式"
                                }
                            },
                            "required": ["expression"]
                        }
                    }
                }
            ]
            tool_messages = [
                Message(role="system", content="You are a helpful assistant."),
                Message(role="user", content="Calculate 123 * 456")
            ]
            response = await ai.chat(tool_messages, tools=test_tools)
            print(f"   Response with tools: {response.content[:200]}...")

            print("\n" + "=" * 50)
            print("All tests passed!")
            print("=" * 50)

        except Exception as e:
            print(f"\nError: {type(e).__name__}: {e}")
            traceback.print_exc()
            sys.exit(1)

    asyncio.run(test())
