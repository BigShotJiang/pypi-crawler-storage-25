# -*- coding: utf-8 -*-
"""
QAI - AI 交互模块

提供统一的 AI 交互接口，支持多种 AI 提供商。

基本用法:
    # 导入核心组件
    from qai import AICore, Message, ChatResponse

    # 导入 GUI 组件
    from qai import QAIChatWidget, QAISettingsDialog, ShowSettingsDialog

    # 导入配置
    from qai import QAIConfig, LoadConfig, SaveConfig

    # 导入模型（自动注册）
    from qai.models import KimiAI, QwenAI, EmptyAI
"""

from qwork.qai.demo import SimpleChatDemo, QuickChat, quick_chat, quick_chat_sync


__version__ = "1.0.0"
__author__ = "QWork"

# 核心抽象层
from qwork.qai.aio import (
    AICore,
    Message,
    ChatResponse,
    ToolDef,
    ToolCall,
    ToolCallResult,
    CreateAI,
    OpenQaiSetting,
)

# GUI 组件
from qwork.qai.qchat import (
    QAIChatWidget, CircularProgressBar, MessageWidget,
    ToolCallWidget, ReasoningBlockWidget, MarkdownTextBrowser
)
from qwork.qai.qais import (
    QAISettingsDialog,
    ShowSettingsDialog,
    LoadSettings,
    LoadToolBlacklist,
)

# 配置管理
from qwork.qai.config import (
    QAIConfig,
    LoadConfig,
    SaveConfig,
    LoadProviderConfig,
)

# 类型定义
from qwork.qai.typ import (
    JsonDict,
    MessageList,
    StreamChunk,
    MessageRole,
    StreamChunkType,
    TokenUsage,
    ProviderConfig,
    ChatMessage,
    create_stream_chunk,
)

# 模型子模块（需要显式导入）
from qwork.qai import models

# Demo 模块（可选导入）
try:
    _has_demo = True
except ImportError:
    _has_demo = False

__all__ = [
    # 版本信息
    "__version__",
    "__author__",

    # 核心抽象
    "AICore",
    "Message",
    "ChatResponse",
    "ToolCall",
    "ToolCallResult",
    "CreateAI",
    "OpenQaiSetting",

    # GUI 组件
    "QAIChatWidget",
    "CircularProgressBar",
    "MessageWidget",
    "ToolCallWidget",
    "ReasoningBlockWidget",
    "MarkdownTextBrowser",
    "QAISettingsDialog",
    "ShowSettingsDialog",
    "LoadSettings",
    "LoadToolBlacklist",

    # 配置管理
    "QAIConfig",
    "LoadConfig",
    "SaveConfig",
    "LoadProviderConfig",

    # 类型定义
    "JsonDict",
    "MessageList",
    "StreamChunk",
    "MessageRole",
    "StreamChunkType",
    "TokenUsage",
    "ProviderConfig",
    "ChatMessage",
    "create_stream_chunk",

    # 子模块
    "models",
]
