# -*- coding: utf-8 -*-
"""
QAI 配置管理模块

提供 AI 配置的加载、保存和管理功能
"""

import json
import os
from typing import Dict, Optional, Any, List
from pathlib import Path


DEFAULT_CONFIG_DIR = Path.home() / ".config" / "qai"
DEFAULT_CONFIG_FILE = DEFAULT_CONFIG_DIR / "providers.json"


class QAIConfig:
    """
    QAI 配置管理类

    管理 AI 提供商的配置，支持多个提供商
    """

    # 默认提供商列表
    DEFAULT_PROVIDERS = {
        "kimi": {
            "url": "https://api.moonshot.cn/v1",
            "key": ""
        },
        "qwen": {
            "url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
            "key": ""
        }
    }

    def __init__(self, config_path: Optional[str] = None):
        """
        初始化配置管理器

        Args:
            config_path: 配置文件路径，默认使用 ~/.config/qai/providers.json
        """
        if config_path:
            self._config_path = Path(config_path)
        else:
            self._config_path = DEFAULT_CONFIG_FILE

        self._providers: Dict[str, Dict[str, str]] = {}

    @property
    def config_path(self) -> Path:
        """获取配置文件路径"""
        return self._config_path

    def load(self) -> Dict[str, Dict[str, str]]:
        """
        加载配置

        Returns:
            提供商配置字典 {name: {url, key}}
        """
        if self._config_path.exists():
            try:
                with open(self._config_path, 'r', encoding='utf-8') as f:
                    self._providers = json.load(f)
            except (json.JSONDecodeError, IOError):
                self._providers = {}
        else:
            self._providers = {}

        return self._providers.copy()

    def save(self, providers: Optional[Dict[str, Dict[str, str]]] = None) -> bool:
        """
        保存配置

        Args:
            providers: 要保存的提供商配置，None 则保存当前配置

        Returns:
            bool: 是否保存成功
        """
        if providers is not None:
            self._providers = providers

        try:
            # 确保目录存在
            self._config_path.parent.mkdir(parents=True, exist_ok=True)

            with open(self._config_path, 'w', encoding='utf-8') as f:
                json.dump(self._providers, f, indent=2, ensure_ascii=False)
            return True
        except IOError as e:
            print(f"[QAIConfig] Failed to save config: {e}")
            return False

    def getProvider(self, name: str) -> Optional[Dict[str, str]]:
        """
        获取指定提供商配置

        Args:
            name: 提供商名称

        Returns:
            提供商配置 {url, key}，不存在返回 None
        """
        return self._providers.get(name)

    def setProvider(self, name: str, url: str, key: str) -> None:
        """
        设置提供商配置

        Args:
            name: 提供商名称
            url: API URL
            key: API Key
        """
        self._providers[name] = {"url": url, "key": key}

    def removeProvider(self, name: str) -> bool:
        """
        删除提供商配置

        Args:
            name: 提供商名称

        Returns:
            bool: 是否成功删除
        """
        if name in self._providers:
            del self._providers[name]
            return True
        return False

    def listProviders(self) -> List[str]:
        """
        获取所有已配置提供商名称

        Returns:
            提供商名称列表
        """
        return list(self._providers.keys())

    @staticmethod
    def LoadProviderConfig(provider_name: str) -> Optional[Dict[str, str]]:
        """
        静态方法：从默认位置加载指定提供商配置

        Args:
            provider_name: 提供商名称

        Returns:
            提供商配置 {url, key}，不存在返回 None
        """
        config = QAIConfig()
        providers = config.load()
        return providers.get(provider_name)


# ==================== 便捷函数 ====================

def LoadConfig(config_path: Optional[str] = None) -> Dict[str, Dict[str, str]]:
    """
    加载配置

    Args:
        config_path: 配置文件路径，默认使用 ~/.config/qai/providers.json

    Returns:
        提供商配置字典
    """
    return QAIConfig(config_path).load()


def SaveConfig(providers: Dict[str, Dict[str, str]], config_path: Optional[str] = None) -> bool:
    """
    保存配置

    Args:
        providers: 提供商配置字典
        config_path: 配置文件路径，默认使用 ~/.config/qai/providers.json

    Returns:
        bool: 是否保存成功
    """
    return QAIConfig(config_path).save(providers)


def LoadProviderConfig(provider_name: str) -> Optional[Dict[str, str]]:
    """
    加载指定提供商配置

    Args:
        provider_name: 提供商名称

    Returns:
        提供商配置 {url, key}，不存在返回 None
    """
    return QAIConfig.LoadProviderConfig(provider_name)
