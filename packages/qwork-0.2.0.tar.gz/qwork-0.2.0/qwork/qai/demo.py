# -*- coding: utf-8 -*-
"""
QAI 简单对话 Demo

运行方式:
    python -m qai.demo
"""

import asyncio
import sys
from qwork.qai import *


async def _runChat(ai, messages, showprompt: str = None, showreasoning: bool = True):
    """运行一次对话"""
    if showprompt:
        print(f"You: {showprompt}")

    full = ""
    reasoning = ""
    inreasoning = False
    import sys

    async for chunk in ai.chatStream(messages):
        t = chunk.get("type")

        if t == "reasoning_start":
            if showreasoning and not inreasoning:
                print("\n[思考] ", end="", flush=True)
                inreasoning = True

        elif t == "reasoning":
            if showreasoning:
                text = chunk.get("text", "")
                print(text, end="", flush=True)
                sys.stdout.flush()
                reasoning += text

        elif t == "reasoning_end":
            if showreasoning and inreasoning:
                print("\n")
                inreasoning = False

        elif t == "content":
            if not inreasoning:
                print("AI: ", end="", flush=True)
                inreasoning = True  # 标记已输出AI前缀
            text = chunk.get("text", "")
            print(text, end="", flush=True)
            sys.stdout.flush()
            full += text

    if not inreasoning or reasoning:
        print()
    return full


async def Demo():
    """简单对话演示"""
    ai = CreateAI("kimi", only=True)
    print(f"AI: {ai.providerName()}")
    print("Type 'quit' to exit\n")

    messages = []

    # 交互模式
    while True:
        try:
            userinput = input("You: ").strip()
        except EOFError:
            break

        if not userinput:
            continue
        if userinput.lower() == "quit":
            break

        # 支持字符串或 Message 对象
        messages.append({"role": "user", "content": userinput})
        full = await _runChat(ai, messages)
        messages.append({"role": "assistant", "content": full})


if __name__ == "__main__":
    asyncio.run(Demo())
