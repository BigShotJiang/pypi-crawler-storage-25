# -*- coding: utf-8 -*-
"""
测试 ToolDef 和新的 AI 接口

验证:
1. ToolDef 功能完整
2. EmptyAI 使用 tooldefs 参数
3. QwenAI 使用 tooldefs 参数（如果有配置）
4. KimiAI 使用 tooldefs 参数（如果有配置）
"""

from datetime import datetime
from qwork.qai.models.empty import EmptyAI
import traceback

import asyncio
import sys
import os
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from qwork.qai.aio import ToolDef, Message, ChatResponse


# ==================== 测试工具函数 ====================

def Calculator(expression: str) -> float:
    """执行数学计算表达式"""
    return eval(expression)


def GetCurrentTime(format: str = "%Y-%m-%d %H:%M:%S") -> str:
    """获取当前时间，返回指定格式的字符串"""
    return datetime.now().strftime(format)


def GetWeather(city: str, unit: str = "celsius") -> str:
    """获取指定城市的天气信息"""
    return f"{city} 天气晴朗，25{unit}"


# ==================== ToolDef 测试 ====================

def TestToolDef():
    """测试 ToolDef 类功能"""
    print("=" * 60)
    print("测试 ToolDef 类")
    print("=" * 60)

    # 1. 测试构造
    print("\n1. 测试 ToolDef(fn) 构造...")
    calc_tool = ToolDef(Calculator)
    time_tool = ToolDef(GetCurrentTime)
    weather_tool = ToolDef(GetWeather)
    print(f"   [OK] Calculator tool created")
    print(f"   [OK] GetCurrentTime tool created")
    print(f"   [OK] GetWeather tool created")

    # 2. 测试 fn property
    print("\n2. 测试 fn property...")
    assert calc_tool.fn == Calculator
    assert time_tool.fn == GetCurrentTime
    print(f"   [OK] calc_tool.fn = {calc_tool.fn.__name__}")
    print(f"   [OK] time_tool.fn = {time_tool.fn.__name__}")

    # 3. 测试 doc/description property
    print("\n3. 测试 doc/description property...")
    print(f"   [OK] calc_tool.doc = '{calc_tool.doc}'")
    print(f"   [OK] calc_tool.description = '{calc_tool.description}'")
    assert calc_tool.doc == "执行数学计算表达式"
    assert calc_tool.description == calc_tool.doc

    # 4. 测试 params/parameters property
    print("\n4. 测试 params/parameters property...")
    calc_params = calc_tool.params
    print(f"   [OK] calc_tool.params = {json.dumps(calc_params, indent=6, ensure_ascii=False)}")
    assert "properties" in calc_params
    assert "expression" in calc_params["properties"]
    assert calc_params["required"] == ["expression"]

    time_params = time_tool.params
    print(f"   [OK] time_tool.params = {json.dumps(time_params, indent=6, ensure_ascii=False)}")
    assert "format" in time_params["properties"]
    # format has default value, so not in required

    weather_params = weather_tool.params
    print(f"   [OK] weather_tool.params = {json.dumps(weather_params, indent=6, ensure_ascii=False)}")
    assert "city" in weather_params["properties"]
    assert "unit" in weather_params["properties"]
    assert weather_params["required"] == ["city"]  # unit has default

    # 5. 测试 todict() 方法
    print("\n5. 测试 todict() 方法...")
    calc_dict = calc_tool.todict()
    print(f"   [OK] calc_tool.todict() = {json.dumps(calc_dict, indent=6, ensure_ascii=False)}")
    assert calc_dict["type"] == "function"
    assert calc_dict["function"]["name"] == "Calculator"
    assert "parameters" in calc_dict["function"]

    # 6. 测试 name property
    print("\n6. 测试 name property...")
    print(f"   [OK] calc_tool.name = '{calc_tool.name}'")
    print(f"   [OK] time_tool.name = '{time_tool.name}'")
    assert calc_tool.name == "Calculator"
    assert time_tool.name == "GetCurrentTime"

    # 7. 测试 call 方法（同步函数）- 在已有事件循环中需要使用 await
    print("\n7. 测试 call 方法...")
    # 由于测试在异步上下文中运行，直接 await
    pass  # call 方法测试移到 TestAsyncTool 中统一测试

    print("\n[OK] ToolDef 所有测试通过!")
    return True


# ==================== EmptyAI 测试 ====================

async def TestEmptyAI():
    """测试 EmptyAI 使用 tooldefs 参数"""
    print("\n" + "=" * 60)
    print("测试 EmptyAI")
    print("=" * 60)


    ai = EmptyAI()
    print(f"\n1. EmptyAI 实例创建成功")
    print(f"   [OK] providerName: {ai.providerName()}")
    print(f"   [OK] defaultModel: {ai.defaultModel()}")

    # 测试带 tooldefs 的 chat
    print("\n2. 测试 chat 带 tooldefs 参数...")
    tooldefs = [ToolDef(Calculator), ToolDef(GetCurrentTime)]
    messages = [Message(role="user", content="What is 2+2?")]

    response = await ai.chat(messages, tooldefs=tooldefs)
    print(f"   [OK] Response: {response.content[:50]}...")

    # 测试带 tooldefs 的 chatStream
    print("\n3. 测试 chatStream 带 tooldefs 参数...")
    stream_text = []
    async for chunk in ai.chatStream(messages, tooldefs=tooldefs):
        stream_text.append(chunk.get("text", ""))
    full_text = "".join(stream_text)
    print(f"   [OK] Stream response: {full_text[:50]}...")

    print("\n[OK] EmptyAI 所有测试通过!")
    return True


# ==================== 异步工具测试 ====================

async def AsyncTool(delay: int, value: str) -> str:
    """异步工具函数，用于测试 ToolDef.call 处理协程"""
    await asyncio.sleep(delay * 0.01)  # 缩短测试时间
    return f"Async result: {value}"


async def TestAsyncTool():
    """测试 ToolDef 调用异步函数"""
    print("\n" + "=" * 60)
    print("测试 ToolDef 异步函数")
    print("=" * 60)

    tooldef = ToolDef(AsyncTool)
    print(f"\n1. 创建 ToolDef for async function")
    print(f"   [OK] name: {tooldef.name}")
    print(f"   [OK] doc: {tooldef.doc}")

    print("\n2. 调用异步工具...")
    result = await tooldef.call(delay=1, value="test")
    print(f"   [OK] Result: {result}")
    assert result == "Async result: test"

    print("\n[OK] 异步工具测试通过!")
    return True


# ==================== ToolDef call 测试 ====================

async def TestToolDefCall():
    """测试 ToolDef.call 方法（同步和异步函数）"""
    print("\n" + "=" * 60)
    print("测试 ToolDef.call 方法")
    print("=" * 60)

    calc_tool = ToolDef(Calculator)
    time_tool = ToolDef(GetCurrentTime)

    print("\n1. 测试同步函数调用...")
    result = await calc_tool.call(expression="2 + 2")
    print(f"   [OK] Calculator(2+2) = {result}")
    assert float(result) == 4.0

    time_result = await time_tool.call()
    print(f"   [OK] GetCurrentTime() = {time_result}")
    assert isinstance(time_result, str)

    # 测试带默认参数的函数
    weather_tool = ToolDef(GetWeather)
    weather_result = await weather_tool.call(city="北京")
    print(f"   [OK] GetWeather(city='北京') = {weather_result}")
    assert "北京" in weather_result

    weather_result2 = await weather_tool.call(city="上海", unit="华氏度")
    print(f"   [OK] GetWeather(city='上海', unit='华氏度') = {weather_result2}")
    assert "上海" in weather_result2
    assert "华氏度" in weather_result2

    print("\n[OK] ToolDef.call 测试通过!")
    return True


# ==================== 集成测试 ====================

def TestToolDefSchemaExtraction():
    """测试工具定义提取与 OpenAI 格式兼容"""
    print("\n" + "=" * 60)
    print("测试 ToolDef Schema 提取")
    print("=" * 60)

    tooldefs = [
        ToolDef(Calculator),
        ToolDef(GetCurrentTime),
        ToolDef(GetWeather)
    ]

    # 转换为 OpenAI 格式工具列表
    openai_tools = [td.todict() for td in tooldefs]

    print("\nOpenAI 格式工具定义:")
    print(json.dumps(openai_tools, indent=4, ensure_ascii=False))

    # 验证格式
    for tool in openai_tools:
        assert tool["type"] == "function"
        assert "function" in tool
        assert "name" in tool["function"]
        assert "description" in tool["function"]
        assert "parameters" in tool["function"]
        params = tool["function"]["parameters"]
        assert params["type"] == "object"
        assert "properties" in params

    print("\n[OK] OpenAI 格式验证通过!")
    return True


# ==================== 主测试入口 ====================

async def RunAllTests():
    """运行所有测试"""
    print("\n" + "=" * 60)
    print("开始 ToolDef 和 AI 接口测试")
    print("=" * 60)

    results = []

    # 1. ToolDef 测试
    try:
        results.append(("ToolDef", TestToolDef()))
    except Exception as e:
        print(f"\n[FAIL] ToolDef 测试失败: {e}")
        traceback.print_exc()
        results.append(("ToolDef", False))

    # 2. EmptyAI 测试
    try:
        results.append(("EmptyAI", await TestEmptyAI()))
    except Exception as e:
        print(f"\n[FAIL] EmptyAI 测试失败: {e}")
        traceback.print_exc()
        results.append(("EmptyAI", False))

    # 3. ToolDef.call 测试
    try:
        results.append(("ToolDefCall", await TestToolDefCall()))
    except Exception as e:
        print(f"\n[FAIL] ToolDefCall 测试失败: {e}")
        traceback.print_exc()
        results.append(("ToolDefCall", False))

    # 4. 异步工具测试
    try:
        results.append(("AsyncTool", await TestAsyncTool()))
    except Exception as e:
        print(f"\n[FAIL] AsyncTool 测试失败: {e}")
        traceback.print_exc()
        results.append(("AsyncTool", False))

    # 5. Schema 提取测试
    try:
        results.append(("SchemaExtraction", TestToolDefSchemaExtraction()))
    except Exception as e:
        print(f"\n[FAIL] SchemaExtraction 测试失败: {e}")
        traceback.print_exc()
        results.append(("SchemaExtraction", False))

    # 打印测试结果汇总
    print("\n" + "=" * 60)
    print("测试结果汇总")
    print("=" * 60)
    for name, passed in results:
        status = "[OK] 通过" if passed else "[FAIL] 失败"
        print(f"  {name}: {status}")

    all_passed = all(passed for _, passed in results)
    print("\n" + "=" * 60)
    if all_passed:
        print("所有测试通过! [OK]")
    else:
        print("部分测试失败! [FAIL]")
    print("=" * 60)

    return all_passed


if __name__ == "__main__":
    success = asyncio.run(RunAllTests())
    sys.exit(0 if success else 1)
