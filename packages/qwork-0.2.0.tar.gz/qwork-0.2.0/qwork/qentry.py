"""
QEntry - Registry Explorer UI for qwork
显示所有注册的类、函数和方法，按子包分组
"""

import inspect
import re
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTreeWidget, QTreeWidgetItem,
    QLabel, QSplitter, QTextEdit, QTabWidget, QApplication, QFrame,
    QScrollArea, QSizePolicy
)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QFont, QColor
from typing import Optional, Dict, List, Any

from qwork.registry import (
    registry, ClassInfo, FunctionInfo, MethodInfo, PropertyInfo, ConstantInfo, ParameterInfo
)


# Modern color scheme
_COLORS = {
    'bg': '#f8f9fa',
    'card': '#ffffff',
    'border': '#e1e4e8',
    'text': '#24292e',
    'text_secondary': '#586069',
    'accent': '#0366d6',
    'accent_light': '#f1f8ff',
    'success': '#28a745',
    'warning': '#f9a825',
    'class_color': '#6f42c1',
    'func_color': '#28a745',
    'method_color': '#0366d6',
}


class Card(QFrame):
    """卡片容器"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"""
            Card {{
                background-color: {_COLORS['card']};
                border: 1px solid {_COLORS['border']};
                border-radius: 8px;
            }}
        """)
        self.setFrameShape(QFrame.Shape.StyledPanel)


class StyledTree(QTreeWidget):
    """美化后的树形控件"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"""
            QTreeWidget {{
                background-color: {_COLORS['card']};
                border: 1px solid {_COLORS['border']};
                border-radius: 8px;
                padding: 8px;
                outline: none;
            }}
            QTreeWidget::item {{
                padding: 6px 4px;
                border-radius: 4px;
                margin: 2px 0;
            }}
            QTreeWidget::item:hover {{
                background-color: {_COLORS['accent_light']};
            }}
            QTreeWidget::item:selected {{
                background-color: {_COLORS['accent']};
                color: white;
            }}
            QTreeWidget::branch:has-children:!has-siblings:closed,
            QTreeWidget::branch:closed:has-children:has-siblings {{
                border-top: 5px solid transparent;
                border-bottom: 5px solid transparent;
                border-left: 8px solid {_COLORS['text_secondary']};
                margin-left: 4px;
                image: none;
            }}
            QTreeWidget::branch:open:has-children:!has-siblings,
            QTreeWidget::branch:open:has-children:has-siblings {{
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 8px solid {_COLORS['accent']};
                margin-left: 4px;
                image: none;
            }}
            QHeaderView::section {{
                background-color: {_COLORS['bg']};
                padding: 8px;
                border: none;
                border-bottom: 2px solid {_COLORS['border']};
                font-weight: bold;
            }}
        """)
        self.setHeaderHidden(False)
        self.setUniformRowHeights(True)
        self.setAlternatingRowColors(False)


class DetailPanel(QFrame):
    """详情面板 - 仅显示签名和文档"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._buildui()

    def _buildui(self):
        self.setStyleSheet(f"""
            DetailPanel {{
                background-color: {_COLORS['card']};
                border: 1px solid {_COLORS['border']};
                border-radius: 8px;
            }}
            QLabel {{
                color: {_COLORS['text']};
            }}
        """)

        _layout = QVBoxLayout(self)
        _layout.setContentsMargins(20, 20, 20, 20)
        _layout.setSpacing(16)

        # 标题区域
        self._titlelabel = QLabel("Select an item")
        self._titlelabel.setStyleSheet(f"""
            font-size: 20px;
            font-weight: bold;
            color: {_COLORS['text']};
        """)
        _layout.addWidget(self._titlelabel)

        # 类型标签
        self._typelabel = QLabel()
        self._typelabel.setStyleSheet(f"""
            color: {_COLORS['text_secondary']};
            font-size: 12px;
            padding: 4px 12px;
            background-color: {_COLORS['bg']};
            border-radius: 12px;
        """)
        _layout.addWidget(self._typelabel)

        # 签名区域
        _sigframe = QFrame()
        _sigframe.setStyleSheet(f"""
            QFrame {{
                background-color: {_COLORS['bg']};
                border-radius: 6px;
                border-left: 4px solid {_COLORS['accent']};
            }}
        """)
        _siglayout = QVBoxLayout(_sigframe)
        _siglayout.setContentsMargins(16, 12, 16, 12)

        _sigtitle = QLabel("SIGNATURE")
        _sigtitle.setStyleSheet(f"color: {_COLORS['text_secondary']}; font-size: 10px; font-weight: bold;")
        _siglayout.addWidget(_sigtitle)

        self._sigedit = QTextEdit()
        self._sigedit.setReadOnly(True)
        self._sigedit.setMaximumHeight(80)
        self._sigedit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._sigedit.setStyleSheet(f"""
            QTextEdit {{
                background-color: transparent;
                border: none;
                font-family: 'Consolas', 'Monaco', monospace;
                font-size: 13px;
                color: {_COLORS['text']};
            }}
        """)
        _siglayout.addWidget(self._sigedit)
        _layout.addWidget(_sigframe)

        # 文档区域
        _docframe = QFrame()
        _docframe.setStyleSheet(f"""
            QFrame {{
                background-color: transparent;
                border: none;
            }}
        """)
        _doclayout = QVBoxLayout(_docframe)
        _doclayout.setContentsMargins(0, 0, 0, 0)
        _doclayout.setSpacing(8)

        _doctitle = QLabel("DOCUMENTATION")
        _doctitle.setStyleSheet(f"color: {_COLORS['text_secondary']}; font-size: 10px; font-weight: bold;")
        _doclayout.addWidget(_doctitle)

        self._docedit = QTextEdit()
        self._docedit.setReadOnly(True)
        self._docedit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._docedit.setStyleSheet(f"""
            QTextEdit {{
                background-color: {_COLORS['bg']};
                border: 1px solid {_COLORS['border']};
                border-radius: 6px;
                padding: 8px;
                font-size: 13px;
                color: {_COLORS['text']};
            }}
        """)
        _doclayout.addWidget(self._docedit, stretch=1)
        _layout.addWidget(_docframe, stretch=1)

        _layout.addStretch()

    def clear(self):
        self._titlelabel.setText("Select an item")
        self._typelabel.setText("")
        self._typelabel.setVisible(False)
        self._sigedit.setText("")
        self._docedit.setText("Select an item from the tree to view details")

    def _highlightdoc(self, doc: str) -> str:
        """高亮文档中的 Google 和 reST 风格关键字"""
        if not doc:
            return "No documentation available"

        # Google 风格关键字
        _google_keywords = [
            'Args', 'Arguments', 'Params', 'Parameters',
            'Returns', 'Return',
            'Raises', 'Raise', 'Exceptions', 'Exception',
            'Yields', 'Yield',
            'Note', 'Notes',
            'Example', 'Examples',
            'See Also',
            'Warning', 'Warnings',
            'Todo', 'TODO',
            'Attributes', 'Attribute',
        ]

        # reST 风格关键字 (:keyword:)
        _rest_keywords = [
            'param', 'parameter', 'arg', 'argument',
            'type', 'paramtype',
            'returns', 'return', 'rtype', 'returnstype',
            'raises', 'raise', 'except', 'exception',
            'yields', 'yield', 'yieldtype',
            'note', 'notes',
            'see', 'seealso',
            'warning', 'warn',
            'todo',
            'attr', 'attribute',
        ]

        _lines = doc.split('\n')
        _result = []

        for _line in _lines:
            _highlighted = _line

            # 高亮 Google 风格关键字 (行首，后面跟冒号)
            for _kw in _google_keywords:
                _pattern = f'^([ ]*)({_kw})(:)'
                _repl = f'\\1<span style="color: {_COLORS["accent"]}; font-weight: bold;">\\2</span>\\3'
                _highlighted = re.sub(_pattern, _repl, _highlighted)

            # 高亮 reST 风格关键字 (:keyword:)
            for _kw in _rest_keywords:
                _pattern = f'(\\:{_kw}\\:)'
                _repl = f'<span style="color: {_COLORS["func_color"]}; font-weight: bold;">\\1</span>'
                _highlighted = re.sub(_pattern, _repl, _highlighted)

            # 高亮参数名 (跟在 Args: 或 :param: 后面)
            _highlighted = re.sub(
                r'(\s)([a-zA-Z_][a-zA-Z0-9_]*)(\s*\()',
                f'\\1<span style="color: {_COLORS["method_color"]};">\\2</span>\\3',
                _highlighted
            )

            # 高亮类型注解 (str, int, bool, etc.)
            _builtin_types = ['str', 'int', 'float', 'bool', 'list', 'dict', 'tuple', 'set', 'None', 'Any', 'Optional', 'Union', 'Callable']
            for _typ in _builtin_types:
                _pattern = f'\\b({_typ})\\b'
                _repl = f'<span style="color: {_COLORS["class_color"]};">\\1</span>'
                _highlighted = re.sub(_pattern, _repl, _highlighted)

            _result.append(_highlighted)

        return '<br>'.join(_result)

    def _scrolldocbottom(self):
        """滚动文档到底部"""
        from PyQt6.QtGui import QTextCursor
        _cursor = self._docedit.textCursor()
        _cursor.movePosition(QTextCursor.MoveOperation.End)
        self._docedit.setTextCursor(_cursor)

    def showclass(self, info: ClassInfo):
        self._titlelabel.setText(info.name)
        self._typelabel.setText(f"  CLASS  ")
        self._typelabel.setStyleSheet(f"""
            color: {_COLORS['class_color']};
            font-size: 11px;
            font-weight: bold;
            padding: 4px 12px;
            background-color: {_COLORS['class_color']}20;
            border-radius: 12px;
        """)
        self._typelabel.setVisible(True)

        _bases = f"({', '.join(info.bases)})" if info.bases else ""
        self._sigedit.setText(f"class {info.name}{_bases}")
        self._docedit.setHtml(self._highlightdoc(info.doc or ""))
        self._scrolldocbottom()

    def showfunction(self, info: FunctionInfo):
        self._titlelabel.setText(info.name)
        self._typelabel.setText(f"  FUNCTION  ")
        self._typelabel.setStyleSheet(f"""
            color: {_COLORS['func_color']};
            font-size: 11px;
            font-weight: bold;
            padding: 4px 12px;
            background-color: {_COLORS['func_color']}20;
            border-radius: 12px;
        """)
        self._typelabel.setVisible(True)

        self._sigedit.setText(info.signature)
        self._docedit.setHtml(self._highlightdoc(info.doc or ""))
        self._scrolldocbottom()

    def showmethod(self, info: MethodInfo):
        self._titlelabel.setText(info.name)
        self._typelabel.setText(f"  METHOD  ")
        self._typelabel.setStyleSheet(f"""
            color: {_COLORS['method_color']};
            font-size: 11px;
            font-weight: bold;
            padding: 4px 12px;
            background-color: {_COLORS['method_color']}20;
            border-radius: 12px;
        """)
        self._typelabel.setVisible(True)

        self._sigedit.setText(info.signature)
        self._docedit.setHtml(self._highlightdoc(info.doc or ""))
        self._scrolldocbottom()

    def showproperty(self, info: PropertyInfo):
        self._titlelabel.setText(info.name)
        self._typelabel.setText(f"  PROPERTY  ")
        self._typelabel.setStyleSheet(f"""
            color: {_COLORS['accent']};
            font-size: 11px;
            font-weight: bold;
            padding: 4px 12px;
            background-color: {_COLORS['accent']}20;
            border-radius: 12px;
        """)
        self._typelabel.setVisible(True)

        self._sigedit.setText(f"@{info.name} (property)")
        self._docedit.setHtml(self._highlightdoc(info.doc or ""))
        self._scrolldocbottom()

    def showconstant(self, info: ConstantInfo):
        self._titlelabel.setText(info.name)
        self._typelabel.setText(f"  CONSTANT  ")
        self._typelabel.setStyleSheet(f"""
            color: {_COLORS['func_color']};
            font-size: 11px;
            font-weight: bold;
            padding: 4px 12px;
            background-color: {_COLORS['func_color']}20;
            border-radius: 12px;
        """)
        self._typelabel.setVisible(True)

        _valstr = repr(info.value)
        if len(_valstr) > 100:
            _valstr = _valstr[:100] + "..."
        self._sigedit.setText(f"{info.name} = {_valstr}")
        self._docedit.setHtml("Class constant (ALL UPPERCASE)")


class QEntry(QWidget):
    """
    Registry Explorer - 显示qwork中所有注册的类、函数和方法
    按子包分组显示为Tab页
    """

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("QWork Registry Explorer")
        self.resize(1200, 800)

        self.setStyleSheet(f"""
            QWidget {{
                background-color: {_COLORS['bg']};
                font-family: 'Segoe UI', 'Microsoft YaHei', sans-serif;
            }}
            /* Scrollbar Styles */
            QScrollBar:vertical {{
                background-color: {_COLORS['bg']};
                width: 10px;
                border-radius: 5px;
            }}
            QScrollBar::handle:vertical {{
                background-color: {_COLORS['border']};
                border-radius: 5px;
                min-height: 30px;
            }}
            QScrollBar::handle:vertical:hover {{
                background-color: {_COLORS['text_secondary']};
            }}
            QScrollBar::handle:vertical:pressed {{
                background-color: {_COLORS['accent']};
            }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0px;
            }}
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
                background: none;
            }}
            QScrollBar:horizontal {{
                background-color: {_COLORS['bg']};
                height: 10px;
                border-radius: 5px;
            }}
            QScrollBar::handle:horizontal {{
                background-color: {_COLORS['border']};
                border-radius: 5px;
                min-width: 30px;
            }}
            QScrollBar::handle:horizontal:hover {{
                background-color: {_COLORS['text_secondary']};
            }}
            QScrollBar::handle:horizontal:pressed {{
                background-color: {_COLORS['accent']};
            }}
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
                width: 0px;
            }}
            QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{
                background: none;
            }}
        """)

        self._buildui()
        self._loadregistry()

    def _buildui(self):
        """构建UI"""
        _layout = QVBoxLayout(self)
        _layout.setContentsMargins(20, 20, 20, 20)
        _layout.setSpacing(16)

        # 标题区域
        _header = QFrame()
        _header.setStyleSheet(f"""
            QFrame {{
                background-color: {_COLORS['card']};
                border: 1px solid {_COLORS['border']};
                border-radius: 8px;
            }}
        """)
        _headerlayout = QHBoxLayout(_header)
        _headerlayout.setContentsMargins(20, 16, 20, 16)

        _title = QLabel("📦 QWork Registry Explorer")
        _title.setStyleSheet(f"""
            font-size: 24px;
            font-weight: bold;
            color: {_COLORS['text']};
        """)
        _headerlayout.addWidget(_title)

        _headerlayout.addStretch()

        self._statslabel = QLabel()
        self._statslabel.setStyleSheet(f"""
            color: {_COLORS['text_secondary']};
            font-size: 13px;
        """)
        _headerlayout.addWidget(self._statslabel)

        _layout.addWidget(_header)

        # Tab Widget - 每个子包一个Tab
        self._tabwidget = QTabWidget()
        self._tabwidget.setStyleSheet(f"""
            QTabWidget::pane {{
                background-color: transparent;
                border: none;
            }}
            QTabBar::tab {{
                background-color: transparent;
                color: {_COLORS['text_secondary']};
                padding: 10px 20px;
                margin-right: 4px;
                border-radius: 6px 6px 0 0;
            }}
            QTabBar::tab:hover {{
                background-color: {_COLORS['border']}40;
            }}
            QTabBar::tab:selected {{
                background-color: {_COLORS['card']};
                color: {_COLORS['accent']};
                font-weight: bold;
            }}
        """)
        _layout.addWidget(self._tabwidget)

    def _loadregistry(self):
        """加载注册表数据并按子包分组"""
        # 按子包分组
        _packages: Dict[str, Dict[str, Any]] = {}

        # 收集类
        for _name, _info in registry._class_info.items():
            _pkg = self._getpackage(_info.module)
            if _pkg not in _packages:
                _packages[_pkg] = {'classes': {}, 'functions': {}}
            _packages[_pkg]['classes'][_name] = _info

        # 收集函数
        for _name, _info in registry._function_info.items():
            _pkg = self._getpackage(_info.module)
            if _pkg not in _packages:
                _packages[_pkg] = {'classes': {}, 'functions': {}}
            _packages[_pkg]['functions'][_name] = _info

        # 为每个包创建Tab
        for _pkgname in sorted(_packages.keys()):
            _pkgdata = _packages[_pkgname]
            _tab = self._createtab(_pkgname, _pkgdata)
            self._tabwidget.addTab(_tab, f"  {_pkgname.upper()}  ")

        # 更新统计
        _totalclasses = len(registry._class_info)
        _totalfuncs = len(registry._function_info)
        self._statslabel.setText(f"{_totalclasses} Classes  •  {_totalfuncs} Functions")

    def _getpackage(self, module: str) -> str:
        """从模块路径获取包名"""
        if module.startswith('qwork.'):
            _parts = module.split('.')
            if len(_parts) >= 2:
                return _parts[1]
        return 'core'

    def _createtab(self, pkgname: str, pkgdata: Dict) -> QWidget:
        """为子包创建Tab内容"""
        _tab = QWidget()
        _tab.setStyleSheet("background-color: transparent;")
        _layout = QHBoxLayout(_tab)
        _layout.setContentsMargins(0, 10, 0, 0)
        _layout.setSpacing(16)

        # 分割器
        _splitter = QSplitter(Qt.Orientation.Horizontal)
        _splitter.setStyleSheet("""
            QSplitter::handle {
                background-color: transparent;
                width: 2px;
            }
        """)

        # 左侧：树形列表
        _treewidget = StyledTree()
        _treewidget.setHeaderLabel(f"📁 {pkgname} - Classes & Functions")
        _treewidget.setMinimumWidth(320)
        _treewidget.setMaximumWidth(450)
        _treewidget.itemClicked.connect(self._onitemclicked)
        _splitter.addWidget(_treewidget)

        # 填充树
        self._filleTree(_treewidget, pkgdata)

        # 右侧：详情面板
        self._detailpanel = DetailPanel()
        self._detailpanel.clear()
        _splitter.addWidget(self._detailpanel)

        _splitter.setSizes([380, 820])
        _layout.addWidget(_splitter)

        return _tab

    def _filleTree(self, tree: StyledTree, pkgdata: Dict):
        """填充树形控件"""
        tree.clear()

        # 类节点
        if pkgdata['classes']:
            _classroot = QTreeWidgetItem(tree, [f"📦 Classes ({len(pkgdata['classes'])})"])
            _classroot.setExpanded(True)
            _font = QFont()
            _font.setBold(True)
            _classroot.setFont(0, _font)
            _classroot.setForeground(0, QColor(_COLORS['class_color']))

            for _name, _info in sorted(pkgdata['classes'].items()):
                _classitem = QTreeWidgetItem(_classroot, [f"  {_name}"])
                _classitem.setData(0, Qt.ItemDataRole.UserRole, ('class', _info))
                _classitem.setForeground(0, QColor(_COLORS['text']))

                # 添加 Properties 子节点
                if _info.properties:
                    _propsroot = QTreeWidgetItem(_classitem, [f"  Properties ({len(_info.properties)})"])
                    _propsroot.setForeground(0, QColor(_COLORS['text_secondary']))
                    for _prop in sorted(_info.properties, key=lambda p: p.name):
                        _propitem = QTreeWidgetItem(_propsroot, [f"    @{_prop.name}"])
                        _propitem.setData(0, Qt.ItemDataRole.UserRole, ('property', _prop))
                        _propitem.setForeground(0, QColor(_COLORS['accent']))

                # 添加 Constants 子节点
                if _info.constants:
                    _constsroot = QTreeWidgetItem(_classitem, [f"  Constants ({len(_info.constants)})"])
                    _constsroot.setForeground(0, QColor(_COLORS['text_secondary']))
                    for _const in sorted(_info.constants, key=lambda c: c.name):
                        _constitem = QTreeWidgetItem(_constsroot, [f"    {_const.name}"])
                        _constitem.setData(0, Qt.ItemDataRole.UserRole, ('constant', _const))
                        _constitem.setForeground(0, QColor(_COLORS['func_color']))

                # 添加方法子节点
                if _info.methods:
                    _methodsroot = QTreeWidgetItem(_classitem, [f"  Methods ({len(_info.methods)})"])
                    _methodsroot.setForeground(0, QColor(_COLORS['text_secondary']))
                    for _method in sorted(_info.methods, key=lambda m: m.name):
                        _methoditem = QTreeWidgetItem(_methodsroot, [f"    • {_method.name}()"])
                        _methoditem.setData(0, Qt.ItemDataRole.UserRole, ('method', _method))
                        _methoditem.setForeground(0, QColor(_COLORS['method_color']))

        # 函数节点
        if pkgdata['functions']:
            _funcroot = QTreeWidgetItem(tree, [f"⚡ Functions ({len(pkgdata['functions'])})"])
            _funcroot.setExpanded(True)
            _font = QFont()
            _font.setBold(True)
            _funcroot.setFont(0, _font)
            _funcroot.setForeground(0, QColor(_COLORS['func_color']))

            for _name, _info in sorted(pkgdata['functions'].items()):
                _funcitem = QTreeWidgetItem(_funcroot, [f"  {_name}()"])
                _funcitem.setData(0, Qt.ItemDataRole.UserRole, ('function', _info))
                _funcitem.setForeground(0, QColor(_COLORS['text']))

    def _onitemclicked(self, item: QTreeWidgetItem, column: int):
        """处理树项点击"""
        _data = item.data(0, Qt.ItemDataRole.UserRole)
        if not _data:
            return

        _type, _info = _data

        if _type == 'class':
            self._detailpanel.showclass(_info)
        elif _type == 'function':
            self._detailpanel.showfunction(_info)
        elif _type == 'method':
            self._detailpanel.showmethod(_info)
        elif _type == 'property':
            self._detailpanel.showproperty(_info)
        elif _type == 'constant':
            self._detailpanel.showconstant(_info)

    def refresh(self):
        """刷新注册表显示"""
        while self._tabwidget.count() > 0:
            self._tabwidget.removeTab(0)
        self._loadregistry()


def ShowRegistryExplorer():
    """显示注册表浏览器（便捷函数）"""
    import sys

    _need_exec = False
    _app = QApplication.instance()
    if not _app:
        _app = QApplication(sys.argv)
        _need_exec = True

    _window = QEntry()
    _window.show()

    if _need_exec:
        sys.exit(_app.exec())

    return _window


if __name__ == '__main__':
    ShowRegistryExplorer()
