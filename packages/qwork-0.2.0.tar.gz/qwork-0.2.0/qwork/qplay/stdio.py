"""
qplay stdio module - Kernel logging and output management

Provides unified logging mechanism that:
- Preserves color output to terminal
- Logs to file simultaneously
- Supports log levels and formatting
"""

import re
import sys
import os
from datetime import datetime
from typing import TextIO
from enum import Enum, auto

# Color support
try:
    from colorama import init as colorama_init, Fore, Style
    colorama_init(autoreset=True)
    _COLOR_AVAILABLE = True
except ImportError:
    _COLOR_AVAILABLE = False
    class _Fore:
        def __getattr__(self, name: str) -> str:
            return ''
    class _Style:
        def __getattr__(self, name: str) -> str:
            return ''
    Fore = _Fore()
    Style = _Style()


class LogLevel(Enum):
    """Log level enumeration."""
    DEBUG = auto()
    INFO = auto()
    WARN = auto()
    ERROR = auto()
    FATAL = auto()


# Level colors mapping
_LEVEL_COLORS = {
    LogLevel.DEBUG: Fore.CYAN,
    LogLevel.INFO: Fore.GREEN,
    LogLevel.WARN: Fore.YELLOW,
    LogLevel.ERROR: Fore.RED,
    LogLevel.FATAL: Fore.MAGENTA + Style.BRIGHT,
}

# Level names mapping
_LEVEL_NAMES = {
    LogLevel.DEBUG: "DEBUG",
    LogLevel.INFO: "INFO",
    LogLevel.WARN: "WARN",
    LogLevel.ERROR: "ERROR",
    LogLevel.FATAL: "FATAL",
}


class DualOutput:
    """
    Dual output stream that writes to both terminal and log file.
    Preserves color output to terminal while writing plain text to file.
    """

    def __init__(self, terminal: TextIO, file_path: str, *, level: LogLevel = LogLevel.INFO):
        self._terminal = terminal
        self._level = level
        self._file_path = file_path
        self._file = None
        self._ensure_file()

    def _ensure_file(self) -> None:
        """Ensure log file is open (overwrite mode)."""
        if self._file is None or self._file.closed:
            os.makedirs(os.path.dirname(self._file_path), exist_ok=True)
            self._file = open(self._file_path, 'w', encoding='utf-8')

    def write(self, message: str) -> None:
        """Write message to both terminal and file."""
        # Always write to terminal (preserves color codes)
        self._terminal.write(message)

        # Strip color codes for file output
        plain_message = self._strip_colors(message)
        if plain_message.strip():
            self._ensure_file()
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            self._file.write(f"[{timestamp}] {plain_message}")
            self._file.flush()

    def flush(self) -> None:
        """Flush both streams."""
        self._terminal.flush()
        if self._file:
            self._file.flush()

    def close(self) -> None:
        """Close file stream."""
        if self._file:
            self._file.close()

    @staticmethod
    def _strip_colors(text: str) -> str:
        """Strip ANSI color codes from text."""
        ansi_pattern = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_pattern.sub('', text)


class Logger:
    """
    Unified logger with level support.

    Usage:
        from qplay import Qlog
        Qlog.info("message")
        Qlog.warn("warning")
        Qlog.error("error")
    """

    _instance: 'Logger | None' = None
    _initialized: bool = False

    def __new__(cls) -> 'Logger':
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if Logger._initialized:
            return
        Logger._initialized = True

        self._stdout: DualOutput | None = None
        self._stderr: DualOutput | None = None
        self._min_level = LogLevel.DEBUG
        self._tag_width = 12

    def init(self, log_dir: str, *, min_level: LogLevel = LogLevel.INFO) -> 'Logger':
        """
        Initialize logger with log directory.

        Args:
            log_dir: Directory for log files
            min_level: Minimum log level to output

        Returns:
            self for chaining
        """
        self._min_level = min_level

        log_path = os.path.join(log_dir, "log.txt")
        err_path = os.path.join(log_dir, "error.txt")

        # Create dual outputs
        self._stdout = DualOutput(sys.stdout, log_path, level=min_level)
        self._stderr = DualOutput(sys.stderr, err_path, level=LogLevel.ERROR)

        # Redirect sys streams
        sys.stdout = self._stdout
        sys.stderr = self._stderr

        return self

    def _log(self, level: LogLevel, tag: str, message: str, extra: str | None = None) -> None:
        """Internal log method."""
        if level.value < self._min_level.value:
            return

        color = _LEVEL_COLORS.get(level, '')
        reset = Style.RESET_ALL if _COLOR_AVAILABLE else ''

        # Format: [tag] message (extra)
        padded_tag = tag.ljust(self._tag_width)
        if extra:
            line = f"[{color}{padded_tag}{reset}] {message} ({extra})\n"
        else:
            line = f"[{color}{padded_tag}{reset}] {message}\n"

        if self._stdout:
            self._stdout.write(line)
        else:
            print(line, end='')

    def debug(self, tag: str, message: str, extra: str | None = None) -> None:
        """Debug level log."""
        self._log(LogLevel.DEBUG, tag, message, extra)

    def info(self, tag: str, message: str, extra: str | None = None) -> None:
        """Info level log."""
        self._log(LogLevel.INFO, tag, message, extra)

    def warn(self, tag: str, message: str, extra: str | None = None) -> None:
        """Warning level log."""
        self._log(LogLevel.WARN, tag, message, extra)

    def error(self, tag: str, message: str, extra: str | None = None) -> None:
        """Error level log."""
        self._log(LogLevel.ERROR, tag, message, extra)

    def fatal(self, tag: str, message: str, extra: str | None = None) -> None:
        """Fatal level log."""
        self._log(LogLevel.FATAL, tag, message, extra)

    def raw(self, message: str) -> None:
        """Raw output without formatting."""
        if self._stdout:
            self._stdout.write(message)
        else:
            print(message, end='')


# Global logger instance
Qlog = Logger()


def InitLog(log_dir: str, *, min_level: LogLevel = LogLevel.INFO) -> Logger:
    """
    Initialize logging system.

    Args:
        log_dir: Directory for log files
        min_level: Minimum log level

    Returns:
        Logger instance
    """
    return Qlog.init(log_dir, min_level=min_level)


def Info(tag: str, message: str, extra: str | None = None) -> None:
    """Shortcut for info log."""
    Qlog.info(tag, message, extra)


def Warn(tag: str, message: str, extra: str | None = None) -> None:
    """Shortcut for warning log."""
    Qlog.warn(tag, message, extra)


def Error(tag: str, message: str, extra: str | None = None) -> None:
    """Shortcut for error log."""
    Qlog.error(tag, message, extra)


def Debug(tag: str, message: str, extra: str | None = None) -> None:
    """Shortcut for debug log."""
    Qlog.debug(tag, message, extra)
