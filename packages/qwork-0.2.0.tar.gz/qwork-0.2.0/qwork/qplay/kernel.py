"""
qplay kernel module - Core runtime components G F H T

G: Global dictionary for shared state
F: File storage (runtime)
H: History storage
T: File path utility
"""

import os
import sys
import shutil
import time
import getpass
import platform
import re
import datetime
from pathlib import Path
from typing import Any, Self
from dataclasses import dataclass
from zipfile import ZipFile, ZIP_DEFLATED

from qwork.qplay.stdio import LogLevel, Qlog, Info, Warn, Error
from tqdm import tqdm

from files3 import files


# =============================================================================
# T - FilePathRealer
# =============================================================================

class FilePathRealer:
    """
    File path utility for resolving relative paths to absolute paths.

    Usage:
        T = FilePathRealer("/path/to/temp")
        full_path = T.join("my.xlsx")  # -> /path/to/temp/my.xlsx
    """

    def __init__(self, path: str):
        if not os.path.isdir(path):
            raise NotADirectoryError(f"Path '{path}' is not a valid directory.")
        self._path = os.path.abspath(path)

    def join(self, *args: str) -> str:
        """Join path components and ensure directory exists if it looks like a file."""
        path = os.path.join(self._path, *args)
        # If path has extension and doesn't exist, create parent directories
        if '.' in os.path.basename(path) and not os.path.exists(path):
            parent = os.path.dirname(path)
            if parent and not os.path.exists(parent):
                os.makedirs(parent, exist_ok=True)
        return path

    def __truediv__(self, other: str) -> str:
        """Support T / 'filename' syntax."""
        return self.join(other)

    def __str__(self) -> str:
        return self._path

    @property
    def path(self) -> str:
        """Get base path."""
        return self._path


# =============================================================================
# G - Global State Manager
# =============================================================================

class GlobalState:
    """
    Global state dictionary with attribute access.

    G.key = value  # Set value
    value = G.key  # Get value
    """

    _instance: 'GlobalState | None' = None
    _initialized: bool = False

    def __new__(cls) -> 'GlobalState':
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if GlobalState._initialized:
            return
        GlobalState._initialized = True
        self._data: dict[str, Any] = {}

    def __getattr__(self, name: str) -> Any:
        """Get attribute from internal dict."""
        if name.startswith('_'):
            return object.__getattribute__(self, name)
        return self._data.get(name)

    def __setattr__(self, name: str, value: Any) -> None:
        """Set attribute in internal dict."""
        if name.startswith('_'):
            object.__setattr__(self, name, value)
        else:
            self._data[name] = value

    def __getitem__(self, key: str) -> Any:
        """Dict-style get."""
        return self._data.get(key)

    def __setitem__(self, key: str, value: Any) -> None:
        """Dict-style set."""
        self._data[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        """Get value with default."""
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> Self:
        """Set value and return self for chaining."""
        self._data[key] = value
        return self

    def clear(self) -> None:
        """Clear all data."""
        self._data.clear()

    def keys(self) -> list[str]:
        """Get all keys."""
        return list(self._data.keys())

    def to_dict(self) -> dict[str, Any]:
        """Export to plain dictionary."""
        return self._data.copy()

    def from_dict(self, data: dict[str, Any]) -> Self:
        """Import from dictionary."""
        self._data.update(data)
        return self


# =============================================================================
# Kernel - Singleton container for G F H T
# =============================================================================

class Kernel:
    """
    Singleton kernel container holding G F H T instances.

    Provides unified access to all runtime components through single instance.

    Usage:
        from qwork.qplay import Kernel

        k = Kernel()
        k.init("/work/dir")

        # Access components
        k.G.myvar = "value"
        data = k.F.read("file.txt")
        path = k.T.join("data.xlsx")

        # Or destructure
        G, F, H, T = k.components()
    """

    _instance: 'Kernel | None' = None
    _initialized: bool = False

    def __new__(cls) -> 'Kernel':
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if Kernel._initialized:
            return
        Kernel._initialized = True

        self._G: GlobalState | None = None
        self._F: Any | None = None
        self._H: Any | None = None
        self._T: FilePathRealer | None = None
        self._work_dir: str | None = None

    def init(self, work_dir: str | None = None) -> Self:
        """
        Initialize kernel with working directory.

        Args:
            work_dir: Working directory, defaults to current directory

        Returns:
            self for chaining
        """
        self._work_dir = work_dir or os.getcwd()
        self._G, self._F, self._H, self._T = Kernel.Create(self._work_dir)
        return self

    @property
    def G(self) -> GlobalState:
        """Global state dictionary."""
        if self._G is None:
            self.init()
        return self._G  # type: ignore

    @property
    def F(self) -> files:
        """Runtime file storage (files3.files)."""
        if self._F is None:
            self.init()
        return self._F

    @property
    def H(self) -> files:
        """History file storage (files3.files)."""
        if self._H is None:
            self.init()
        return self._H

    @property
    def T(self) -> FilePathRealer:
        """File path utility."""
        if self._T is None:
            self.init()
        return self._T  # type: ignore

    def components(self) -> tuple[GlobalState, Any, Any, FilePathRealer]:
        """
        Get all components as tuple.

        Returns:
            Tuple of (G, F, H, T)
        """
        return (self.G, self.F, self.H, self.T)

    def backup(self) -> str | None:
        """
        Backup runtime and cleanup both runtime and temp.

        Returns:
            Backup directory path or None if failed
        """
        return Kernel.Backup(self._work_dir)

    @property
    def work_dir(self) -> str:
        """Get current working directory."""
        return self._work_dir or os.getcwd()

    # -------------------------------------------------------------------------
    # Static methods for environment management
    # -------------------------------------------------------------------------

    @staticmethod
    def Prepare(work_dir: str | None = None) -> str:
        """
        Prepare runtime environment directories.

        Args:
            work_dir: Working directory, defaults to current directory

        Returns:
            Working directory path
        """
        if work_dir is None:
            work_dir = os.getcwd()

        data_dir = os.path.join(work_dir, ".data")
        paths = {
            'runtime': os.path.join(data_dir, "runtime"),
            'history': os.path.join(data_dir, "history"),
            'backup': os.path.join(data_dir, "backup"),
            'temp': os.path.join(data_dir, "temp"),
        }

        for name, path in paths.items():
            if not os.path.exists(path):
                os.makedirs(path, exist_ok=True)
                Info("PrepEnv", f"created {name}", path)

        return work_dir

    @staticmethod
    def Create(work_dir: str | None = None) -> tuple[GlobalState, Any, Any, FilePathRealer]:
        """
        Create complete runtime environment.

        Args:
            work_dir: Working directory, defaults to current directory

        Returns:
            Tuple of (G, F, H, T)
        """

        work_dir = Kernel.Prepare(work_dir)
        data_dir = os.path.join(work_dir, ".data")
        runtime_dir = os.path.join(data_dir, "runtime")

        # Check and auto-backup/cleanup if needed (BEFORE log init!)
        Kernel._automaintenance(data_dir)

        # Initialize logging
        Qlog.init(runtime_dir, min_level=LogLevel(1))  # INFO

        # Log startup info
        Info("Qplay", "runtime starting")
        Info("Qplay", f".data: {data_dir}")
        Info("Qplay", f"python: {sys.version}")
        Info("Qplay", f"platform: {platform.platform()}")
        Info("Qplay", f"user: {getpass.getuser()}")

        # Create components
        G = GlobalState()
        F = files(os.path.join(data_dir, "runtime"))
        H = files(os.path.join(data_dir, "history"))
        T = FilePathRealer(os.path.join(data_dir, "temp"))

        Info("Qplay", "runtime initialized")

        return G, F, H, T

    @staticmethod
    def _automaintenance(data_dir: str) -> None:
        """
        Auto backup and cleanup on startup.
        - If runtime has meaningful content: backup + cleanup
        - If temp not empty: cleanup
        """
        runtime_dir = os.path.join(data_dir, "runtime")
        temp_dir = os.path.join(data_dir, "temp")

        # Check if runtime has meaningful content
        if Kernel._runtimemeaningful(runtime_dir):
            Info("Kernel", "runtime has meaningful content, auto backup")
            Kernel.Backup(os.path.dirname(data_dir))

        # Check if temp has content
        if os.path.exists(temp_dir) and os.listdir(temp_dir):
            Info("Kernel", "temp not empty, auto cleanup")
            Kernel._cleandir(temp_dir)

        # Check backup history for compression
        Kernel._compressoldbackups(data_dir)

    @staticmethod
    def _runtimemeaningful(runtime_dir: str) -> bool:
        """
        Check if runtime directory has meaningful content that needs backup.
        Returns True if:
        - error.txt is non-empty
        - OR log.txt first and last timestamp diff > 3 seconds
        - OR runtime has other files besides error.txt and log.txt
        """
        if not os.path.exists(runtime_dir):
            return False

        files = os.listdir(runtime_dir)
        if not files:
            return False

        # Check for files other than error.txt and log.txt
        other_files = [f for f in files if f not in ("error.txt", "log.txt")]
        if other_files:
            return True

        # Check error.txt is non-empty
        error_path = os.path.join(runtime_dir, "error.txt")
        if os.path.exists(error_path) and os.path.getsize(error_path) > 0:
            return True

        # Check log.txt timestamp span > 1 minute
        log_path = os.path.join(runtime_dir, "log.txt")
        if os.path.exists(log_path):
            try:
                with open(log_path, "r", encoding="utf-8") as f:
                    content = f.read()
                    # Extract all timestamps: [YYYY-MM-DD HH:MM:SS.mmm]
                    timestamps = re.findall(r'\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3})\]', content)
                    if len(timestamps) >= 2:
                        first_ts = datetime.datetime.strptime(timestamps[0], "%Y-%m-%d %H:%M:%S.%f")
                        last_ts = datetime.datetime.strptime(timestamps[-1], "%Y-%m-%d %H:%M:%S.%f")
                        if (last_ts - first_ts).total_seconds() > 3:
                            return True
            except Exception:
                pass

        return False

    @staticmethod
    def _cleandir(dir_path: str, exclude: set[str] | None = None) -> None:
        """
        Remove all contents inside a directory without removing the directory itself.

        Args:
            dir_path: Directory to clean
            exclude: Set of filenames to skip (case-sensitive)
        """
        if not os.path.exists(dir_path):
            return
        exclude = exclude or set()
        for fname in os.listdir(dir_path):
            if fname in exclude:
                continue
            fpath = os.path.join(dir_path, fname)
            try:
                if os.path.isfile(fpath):
                    os.remove(fpath)
                elif os.path.isdir(fpath):
                    shutil.rmtree(fpath)
            except Exception as e:
                Warn("backup", f"cleanup failed for {fname}", str(e))

    @staticmethod
    def _parsebackupdate(backup_name: str) -> datetime.date | None:
        """Parse backup directory name to date. Format: YYYY-MM-DD_<seconds>"""
        try:
            # Extract YYYY-MM-DD part
            date_part = backup_name.split("_")[0]
            year, month, day = map(int, date_part.split("-"))
            return datetime.date(year, month, day)
        except (ValueError, IndexError):
            return None

    @staticmethod
    def _compressoldbackups(data_dir: str) -> None:
        """
        Compress old backups if conditions met:
        - Latest backup date != today
        - AND (backup count >= 60 OR earliest-latest > 120 days)

        History is copied into backup before compression.
        After compression, only zip files remain in backup dir.
        """
        backup_dir = os.path.join(data_dir, "backup")
        if not os.path.exists(backup_dir):
            return

        # Get all backup entries (exclude zip files)
        entries = []
        for name in os.listdir(backup_dir):
            path = os.path.join(backup_dir, name)
            if os.path.isdir(path):
                date = Kernel._parsebackupdate(name)
                if date:
                    entries.append((name, date, path))

        if len(entries) < 2:
            return

        # Sort by date
        entries.sort(key=lambda x: x[1])

        today = datetime.date.today()
        latest_date = entries[-1][1]
        earliest_date = entries[0][1]

        # Check conditions
        date_diff = (latest_date - earliest_date).days

        if latest_date == today:
            return  # Latest is today, skip

        if not (len(entries) >= 60 or date_diff > 120):
            return  # Conditions not met

        # Copy history to backup for compression
        history_dir = os.path.join(data_dir, "history")
        history_backup_dir = os.path.join(backup_dir, "_history")
        if os.path.exists(history_dir):
            try:
                shutil.copytree(history_dir, history_backup_dir)
                Info("zipping", "history copied for compression")
            except Exception as e:
                Warn("zipping", "failed to copy history", str(e))

        # Perform compression
        zip_name = f"u{earliest_date.strftime('%Y%m%d')}-{latest_date.strftime('%Y%m%d')}.zip"
        zip_path = os.path.join(backup_dir, zip_name)

        Info("zipping", f"compressing {len(entries)} backups to", zip_name)

        # Collect all directories to compress (backups + history if exists)
        dirs_to_compress = [(name, path) for name, date, path in entries]
        if os.path.exists(history_backup_dir):
            dirs_to_compress.append(("_history", history_backup_dir))

        with ZipFile(zip_path, "w", ZIP_DEFLATED) as zf:
            for name, path in tqdm(dirs_to_compress, desc="Compressing"):
                for root, dirs, files in os.walk(path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.join(name, os.path.relpath(file_path, path))
                        zf.write(file_path, arcname)

        # Remove all directories in backup (keep only zip files)
        for name in os.listdir(backup_dir):
            path = os.path.join(backup_dir, name)
            if os.path.isdir(path):
                try:
                    shutil.rmtree(path)
                except Exception as e:
                    Warn("zipping", f"failed to remove {name}", str(e))

        Info("zipping", "compression complete", zip_path)

    @staticmethod
    def Backup(work_dir: str | None = None) -> str | None:
        """
        Backup runtime and temp directories, then cleanup both.

        Args:
            work_dir: Working directory

        Returns:
            Backup directory path or None if failed
        """
        if work_dir is None:
            work_dir = os.getcwd()

        data_dir = os.path.join(work_dir, ".data")
        now = datetime.datetime.now()
        backup_name = f"{now.year}-{now.month:02d}-{now.day:02d}_{int(time.time()) % 86400}"
        backup_dir = os.path.join(data_dir, "backup", backup_name)

        try:
            runtime_dir = os.path.join(data_dir, "runtime")
            temp_dir = os.path.join(data_dir, "temp")

            if os.path.exists(runtime_dir):
                shutil.copytree(runtime_dir, os.path.join(backup_dir, "runtime"))
            if os.path.exists(temp_dir):
                shutil.copytree(temp_dir, os.path.join(backup_dir, "temp"))

            Info("backup", f"backup created", backup_dir)

            # Cleanup temp after backup
            Kernel._cleandir(temp_dir)

            # Cleanup runtime but skip log files (they're in use by Qlog)
            Kernel._cleandir(runtime_dir, exclude={"error.txt", "log.txt"})

            return backup_dir
        except Exception as e:
            Error("backup", "backup failed", str(e))
            return None


# Global kernel instance for convenience
K = Kernel()
