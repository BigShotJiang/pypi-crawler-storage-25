"""
qplay play module - Full test suite for WebPage and Element

Test coverage:
- WebPage construction modes (shared, newbrowser, parasitic)
- Browser lifecycle management
- Element operations
- Cross-page interactions
"""

from playwright.sync_api import Locator


import time
import pytest
from playwright.sync_api import Page, Browser

from qwork.qplay.play import WebPage, Element, Sleep, ResolveIdent, _BrowserManager


# =============================================================================
# Helper Functions
# =============================================================================


def _createTestHtml():
    """Return test HTML content."""
    return """
    <!DOCTYPE html>
    <html>
    <head><title>Test Page</title></head>
    <body>
        <div id="main">
            <h1 class="title">Test Title</h1>
            <input id="text_input" type="text" value="default" />
            <button id="click_btn">Click Me</button>
            <a href="https://example.com" id="link">Example Link</a>
            <ul id="list">
                <li class="item">Item 1</li>
                <li class="item">Item 2</li>
                <li class="item">Item 3</li>
            </ul>
        </div>
        <div id="empty"></div>
    </body>
    </html>
    """


# =============================================================================
# WebPage Construction Tests
# =============================================================================


class TestWebPageConstruction:
    """Test WebPage construction modes."""

    def testSharedBrowser(self):
        """Test shared browser mode (default)."""
        page1 = WebPage()
        page2 = WebPage()

        # Both should use same browser
        assert page1.browser is page2.browser
        assert not page1.isParasitic
        assert not page2.isParasitic
        assert page1.host is None
        assert page2.host is None

        page1.close()
        page2.close()

    def testNewBrowser(self):
        """Test new browser mode."""
        page1 = WebPage(True)
        page2 = WebPage(True)

        # Each should have its own browser
        assert page1.browser is not page2.browser
        assert page1._ownbrowser
        assert page2._ownbrowser

        page1.close()
        page2.close()

    def testNewBrowserHeadless(self):
        """Test new browser with headless parameter."""
        # Headless browser (invisible)
        page_hidden = WebPage(True, headless=True)
        assert page_hidden.isHeadless

        # Visible browser
        page_visible = WebPage(True, headless=False)
        assert not page_visible.isHeadless

        page_hidden.close()
        page_visible.close()

    def testSharedBrowserIgnoresHeadless(self):
        """Test that shared browser mode ignores headless parameter."""
        # Shared browser uses manager's settings
        page1 = WebPage(headless=False)
        page2 = WebPage(headless=True)  # This should be ignored

        # Both should share same browser
        assert page1.browser is page2.browser

        page1.close()
        page2.close()

    def testParasiticPage(self):
        """Test parasitic page construction."""
        # A creates browser
        pageA = WebPage(True)

        # B parasitic on A
        pageB = WebPage(pageA)

        # C parasitic on B (chains to A)
        pageC = WebPage(pageB)

        # All should use same browser
        assert pageA.browser is pageB.browser
        assert pageB.browser is pageC.browser

        # Check parasitic flags
        assert not pageA.isParasitic
        assert pageB.isParasitic
        assert pageC.isParasitic

        # Check host relationships
        assert pageA.host is None
        assert pageB.host is pageA
        assert pageC.host is pageB

        # Check root hosts
        assert pageA.rootHost is None
        assert pageB.rootHost is pageA
        assert pageC.rootHost is pageA

        # Cleanup: close in reverse order
        pageC.close()
        pageB.close()
        pageA.close()

    def testParasiticOnShared(self):
        """Test parasitic page on shared browser."""
        # A uses shared browser
        pageA = WebPage()

        # B parasitic on A
        pageB = WebPage(pageA)

        # Both use same browser
        assert pageA.browser is pageB.browser
        assert not pageA.isParasitic
        assert pageB.isParasitic

        pageB.close()
        pageA.close()


# =============================================================================
# Browser Lifecycle Tests
# =============================================================================


class TestBrowserLifecycle:
    """Test browser and page lifecycle."""

    def testPageCloseOnly(self):
        """Test that closing parasitic page doesn't affect host."""
        pageA = WebPage(True)
        pageB = WebPage(pageA)

        # B closes, A should still work
        pageB.close()

        # A should still be functional
        pageA.goto("about:blank")
        assert pageA.url == "about:blank"

        pageA.close()

    def testContextManager(self):
        """Test WebPage as context manager."""
        with WebPage() as page:
            page.goto("about:blank")
            assert page.url == "about:blank"

        # Page should be closed after context

    def testReferenceCounting(self):
        """Test browser reference counting."""
        # Get initial count
        initial_count = _BrowserManager._refcount

        page1 = WebPage()
        assert _BrowserManager._refcount == initial_count + 1

        page2 = WebPage()
        assert _BrowserManager._refcount == initial_count + 2

        page1.close()
        assert _BrowserManager._refcount == initial_count + 1

        page2.close()
        assert _BrowserManager._refcount == initial_count


# =============================================================================
# Navigation Tests
# =============================================================================


class TestNavigation:
    """Test page navigation."""

    def testGoto(self):
        """Test goto method."""
        page = WebPage()

        result = page.goto("about:blank")
        assert result is page  # Returns self for chaining
        assert page.url == "about:blank"

        page.close()

    def testUrlProperty(self):
        """Test url property."""
        page = WebPage()
        page.goto("about:blank")

        assert page.url == "about:blank"

        page.close()

    def testTitleProperty(self):
        """Test title property."""
        page = WebPage()
        page.goto("data:text/html,<title>Test Title</title><body></body>")

        assert page.title == "Test Title"

        page.close()

    def testHtmlProperty(self):
        """Test html property."""
        page = WebPage()
        page.goto("data:text/html,<body><div>test</div></body>")

        html = page.html
        assert "<div>test</div>" in html

        page.close()

    def testBackForwardRefresh(self):
        """Test navigation methods."""
        page = WebPage()

        # Navigate to two different pages
        page.goto("about:blank")
        page.goto("about:blank#test")

        # Test back
        page.back()
        # Test forward
        page.forward()
        # Test refresh
        page.refresh()

        page.close()


# =============================================================================
# Element Property Tests
# =============================================================================


class TestElementProperties:
    """Test Element properties and basic operations."""

    @pytest.fixture
    def page(self):
        """Create a test page with sample HTML."""
        page = WebPage()
        html = _createTestHtml()
        page.goto(f"data:text/html,{html}")
        yield page
        page.close()

    def testTagName(self, page):
        """Test tag_name property."""
        elem = page.seek("//h1")
        assert elem.tag_name == "h1"

    def testTextProperty(self, page):
        """Test text property."""
        elem = page.seek("//h1")
        assert elem.text == "Test Title"

    def testIdProperty(self, page):
        """Test id property."""
        elem = page.seek("//div[@id='main']")
        assert elem.id == "main"

    def testValueProperty(self, page):
        """Test value property."""
        elem = page.seek("//input[@id='text_input']")
        assert elem.value == "default"

    def testSizeProperty(self, page):
        """Test size property."""
        elem = page.seek("//h1")
        size = elem.size
        assert "width" in size
        assert "height" in size

    def testRectProperty(self, page):
        """Test rect property."""
        elem = page.seek("//h1")
        rect = elem.rect
        assert "x" in rect
        assert "y" in rect
        assert "width" in rect
        assert "height" in rect

    def testBackendProperty(self, page):
        """Test backend property returns Locator."""
        elem = page.seek("//h1")
        assert isinstance(elem.backend, Locator)


# =============================================================================
# Element Search Tests
# =============================================================================


class TestElementSearch:
    """Test element searching methods."""

    @pytest.fixture
    def page(self):
        """Create a test page with sample HTML."""
        page = WebPage()
        html = _createTestHtml()
        page.goto(f"data:text/html,{html}")
        yield page
        page.close()

    def testSeek(self, page):
        """Test seek method."""
        elem = page.seek("//h1")
        assert elem is not None
        assert elem.tag_name == "h1"

    def testSeekNotFoundWithError(self, page):
        """Test seek raises error when element not found."""
        with pytest.raises(RuntimeError):
            page.seek("//div[@id='nonexistent']")

    def testSeekNotFoundNoError(self, page):
        """Test seek returns None without error."""
        elem = page.seek("//div[@id='nonexistent']", error=False)
        assert elem is None

    def testSeeks(self, page):
        """Test seeks method."""
        elems = page.seeks("//li[@class='item']")
        assert len(elems) == 3

    def testSeeksEmpty(self, page):
        """Test seeks returns empty list."""
        elems = page.seeks("//span[@class='nonexistent']")
        assert len(elems) == 0

    def testTestMethod(self, page):
        """Test test method."""
        assert page.test("//h1") is True
        assert page.test("//span[@id='nonexistent']") is False

    def testWait(self, page):
        """Test wait method."""
        elem = page.wait("//h1", waitlimit=5000)
        assert elem is not None
        assert elem.tag_name == "h1"

    def testWaits(self, page):
        """Test waits method."""
        elems = page.waits("//li[@class='item']", waitlimit=5000)
        assert len(elems) == 3


# =============================================================================
# Element Action Tests
# =============================================================================


class TestElementActions:
    """Test element action methods."""

    @pytest.fixture
    def page(self):
        """Create a test page with interactive elements."""
        page = WebPage()
        html = """
        <!DOCTYPE html>
        <html>
        <body>
            <input id="input" type="text" value="" />
            <button id="btn" onclick="document.getElementById('result').innerText='clicked'">Click</button>
            <div id="result"></div>
            <a href="about:blank" id="link">Link</a>
        </body>
        </html>
        """
        page.goto(f"data:text/html,{html}")
        yield page
        page.close()

    def testClick(self, page):
        """Test click method."""
        result = page.click("//button[@id='btn']")
        assert result is page  # Returns self for chaining

        # Check result
        elem = page.seek("//div[@id='result']")
        assert elem.text == "clicked"

    def testTyping(self, page):
        """Test typing method."""
        page.typing("//input[@id='input']", "hello world")

        elem = page.seek("//input[@id='input']")
        assert elem.value == "hello world"

    def testTypingClear(self, page):
        """Test typing with clear=False."""
        page.typing("//input[@id='input']", "first")
        page.typing("//input[@id='input']", "second", clear=False)

        # clear=False should append
        elem = page.seek("//input[@id='input']")
        assert elem.value == "firstsecond"

    def testDoubleClick(self, page):
        """Test doubleClick method."""
        result = page.doubleClick("//input[@id='input']")
        assert result is page

    def testRightClick(self, page):
        """Test rClick method."""
        result = page.rClick("//input[@id='input']")
        assert result is page

    def testMiddleClick(self, page):
        """Test mClick method."""
        result = page.mClick("//a[@id='link']")
        assert result is page


# =============================================================================
# Child Element Tests
# =============================================================================


class TestChildElements:
    """Test element relationship methods."""

    @pytest.fixture
    def page(self):
        """Create a test page with nested elements."""
        page = WebPage()
        html = """
        <!DOCTYPE html>
        <html>
        <body>
            <div id="parent" class="parent-class" data-attr="parent-value">
                <span id="child1">Child 1</span>
                <span id="child2" class="child-class">Child 2</span>
            </div>
        </body>
        </html>
        """
        page.goto(f"data:text/html,{html}")
        yield page
        page.close()

    def testParentProperty(self, page):
        """Test parent property."""
        child = page.seek("//span[@id='child1']")
        parent = child.parent

        assert parent is not None
        assert parent.id == "parent"

    def testChildrenProperty(self, page):
        """Test children property."""
        parent = page.seek("//div[@id='parent']")
        children = parent.children

        assert len(children) == 2

    def testGetAttr(self, page):
        """Test geta method."""
        elem = page.seek("//div[@id='parent']")

        assert elem.geta("id") == "parent"
        assert elem.geta("class") == "parent-class"
        assert elem.geta("data-attr") == "parent-value"

    def testHasAttr(self, page):
        """Test hasa method."""
        elem = page.seek("//div[@id='parent']")

        assert elem.hasa("id") is True
        assert elem.hasa("nonexistent") is False

    def testListAttr(self, page):
        """Test lista method."""
        elem = page.seek("//div[@id='parent']")
        attrs = elem.lista()

        assert "id" in attrs
        assert "class" in attrs


# =============================================================================
# IdentityLib Integration Tests
# =============================================================================


class TestIdentityIntegration:
    """Test identylib integration."""

    def testResolveIdentFunction(self):
        """Test ResolveIdent function."""
        # Direct xpath should pass through
        assert ResolveIdent("//div[@id='test']") == "//div[@id='test']"

    def testSeekWithXpath(self):
        """Test seek with direct xpath."""
        page = WebPage()
        page.goto("data:text/html,<div id='test'>content</div>")

        elem = page.seek("//div[@id='test']")
        assert elem.text == "content"

        page.close()


# =============================================================================
# Utility Function Tests
# =============================================================================


class TestUtilities:
    """Test utility functions."""

    def testSleepWithValue(self):
        """Test Sleep with positive value."""
        start = time.time()
        Sleep(100)  # 100ms
        elapsed = time.time() - start
        assert elapsed >= 0.08  # Allow some tolerance

    def testSleepWithNone(self):
        """Test Sleep with None."""
        start = time.time()
        Sleep(None)
        elapsed = time.time() - start
        assert elapsed < 0.01  # Should return immediately

    def testSleepWithZero(self):
        """Test Sleep with zero."""
        start = time.time()
        Sleep(0)
        elapsed = time.time() - start
        assert elapsed < 0.01  # Should return immediately


# =============================================================================
# Integration Tests
# =============================================================================


class TestIntegration:
    """Integration tests combining multiple features."""

    def testParasiticNavigation(self):
        """Test navigation in parasitic pages."""
        # A creates browser
        pageA = WebPage(True)
        pageA.goto("about:blank")

        # B parasitic on A
        pageB = WebPage(pageA)
        pageB.goto("about:blank#b")

        # C parasitic on B
        pageC = WebPage(pageB)
        pageC.goto("about:blank#c")

        # Each should have different URLs
        assert pageA.url == "about:blank"
        assert pageB.url == "about:blank#b"
        assert pageC.url == "about:blank#c"

        # All use same browser
        assert pageA.browser is pageB.browser is pageC.browser

        pageC.close()
        pageB.close()
        pageA.close()

    def testMixedModes(self):
        """Test mixing different construction modes."""
        # Shared browser pages
        shared1 = WebPage()
        shared2 = WebPage()

        # New browser page
        new_browser = WebPage(True)

        # Parasitic on shared
        para_shared = WebPage(shared1)

        # Parasitic on new browser
        para_new = WebPage(new_browser)

        # Shared pages use same browser
        assert shared1.browser is shared2.browser

        # Parasitic pages follow their hosts
        assert para_shared.browser is shared1.browser
        assert para_new.browser is new_browser.browser

        # New browser is independent
        assert new_browser.browser is not shared1.browser

        para_new.close()
        para_shared.close()
        new_browser.close()
        shared2.close()
        shared1.close()

    def testElementActionsAcrossPages(self):
        """Test element operations work correctly across different page modes."""
        html = "data:text/html,<button id='btn' onclick='this.innerText=\"clicked\"'>Click</button>"

        # Test on shared browser
        shared = WebPage()
        shared.goto(html)
        shared.click("//button[@id='btn']")
        assert shared.seek("//button[@id='btn']").text == "clicked"
        shared.close()

        # Test on new browser
        new_browser = WebPage(True)
        new_browser.goto(html)
        new_browser.click("//button[@id='btn']")
        assert new_browser.seek("//button[@id='btn']").text == "clicked"
        new_browser.close()


# =============================================================================
# Main Entry Point
# =============================================================================


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
