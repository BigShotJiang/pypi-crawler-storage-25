"""
Pula 多网站统一测试

测试 Baidu、Bilibili、Kimi 三个网站的 XPath 生成。
全路径 XPath 作为常量定义在文件开头。
"""

from lxml.etree import parse, HTMLParser
from io import StringIO
from qwork.qplay.play import Element
from qwork.qplay.persist import PersistPage


import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ============ 测试用例常量定义 ============

# Baidu (https://www.baidu.com)
BAIDU_CASES = [
    # (全路径xpath, 期望标签, 描述)
    ("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/a[8]", "a", "文库链接"),
    ("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/a[6]", "a", "气泡链接(target=_blank)"),
    ("/html[1]/body[1]/div[2]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/a[1]/div[1]/div[1]/span[2]", "span", "换一换"),
    ("/html[1]/body[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[6]/div[1]/button[1]", "button", "聊天提交按钮"),
]

# Bilibili (https://www.bilibili.com)
BILIBILI_CASES = [
    # Header 区域
    ("/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/ul[2]/li[6]/div[1]/*[local-name()='svg'][1]", "svg", "历史记录图标"),
    ("/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/ul[2]/li[5]/div[1]/*[local-name()='svg'][1]/*[local-name()='path'][1]", "path", "收藏图标path"),
    ("/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/ul[2]/li[1]/li[1]/div[1]/div[1]", "div", "登录入口"),
    # Header-left 区域
    ("/html[1]/body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/*[local-name()='svg'][1]", "svg", "左侧展开按钮图标"),
]

# Kimi (https://kimi.moonshot.cn)
KIMI_CASES = [
    # 示例占位，实际使用时请补充真实路径
    # ("/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[1]/div[1]/button[1]", "button", "发送按钮"),
]


# ============ 测试实现 ============

def _safe_print(s: str) -> str:
    """安全打印，处理 GBK 编码问题"""
    return "".join(c if ord(c) < 128 else "?" for c in s)


def TestSite(_name: str, _url: str, _cases: list[tuple[str, str, str]], _page) -> bool:
    """测试单个网站的所有用例"""

    print(f"\n=== {_name} ({_url}) ===")

    _html = _page.html
    _tree = parse(StringIO(_html), HTMLParser())
    _root = _tree.getroot()

    _passed = 0
    _failed = 0

    for _absxp, _expected_tag, _desc in _cases:
        print(f"\nTest: {_desc}")
        print(f"  abs: {_absxp}")

        try:
            # 使用 Playwright 定位元素
            _loc = _page._page.locator(f"xpath={_absxp}").first
            _elem = Element(_loc, _page)

            # 获取优化后的 xpath
            _xp = _elem.xpath
            print(f"  gen: {_safe_print(_xp)}")

            # 验证唯一性
            _matches = _tree.xpath(_xp)
            _ok = len(_matches) == 1

            if _ok:
                print(f"  result: PASS (matches=1)")
                _passed += 1
            else:
                print(f"  result: FAIL (matches={len(_matches)})")
                _failed += 1

        except Exception as _e:
            print(f"  result: ERROR {type(_e).__name__}: {_e}")
            _failed += 1

    print(f"\n{_name} Summary: {_passed} passed, {_failed} failed")
    return _failed == 0


def main():

    _all_passed = True

    # Test Baidu
    try:
        _p = PersistPage(9222)
        _p.goto("https://www.baidu.com")
        if not TestSite("Baidu", "https://www.baidu.com", BAIDU_CASES, _p):
            _all_passed = False
    except Exception as _e:
        print(f"Baidu test failed: {_e}")
        _all_passed = False

    # Test Bilibili
    try:
        _p = PersistPage(9222)
        _p.goto("https://www.bilibili.com")
        if not TestSite("Bilibili", "https://www.bilibili.com", BILIBILI_CASES, _p):
            _all_passed = False
    except Exception as _e:
        print(f"Bilibili test failed: {_e}")
        _all_passed = False

    # Test Kimi (placeholder)
    if KIMI_CASES:
        try:
            _p = PersistPage(9222)
            _p.goto("https://kimi.moonshot.cn")
            if not TestSite("Kimi", "https://kimi.moonshot.cn", KIMI_CASES, _p):
                _all_passed = False
        except Exception as _e:
            print(f"Kimi test failed: {_e}")
            _all_passed = False
    else:
        print("\n=== Kimi (skipped - no test cases defined) ===")

    print("\n" + "=" * 40)
    if _all_passed:
        print("All tests PASSED")
        return 0
    else:
        print("Some tests FAILED")
        return 1


if __name__ == "__main__":
    exit(main())
