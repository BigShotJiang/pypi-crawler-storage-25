import sys, os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from qwork.qplay.persist import PersistPage
from lxml.etree import parse, HTMLParser, QName
from io import StringIO

p = PersistPage(9222)
html = p.html
tree = parse(StringIO(html), HTMLParser())
root = tree.getroot()

nodes = tree.xpath("/html/body/div[2]/div[2]/div[1]/div[1]/ul[2]/li[5]/div[1]/*[local-name()='svg']")
print('svg nodes:', len(nodes))
for n in nodes:
    print('tag raw:', repr(n.tag))
    print('tag localname:', QName(n).localname)
    for c in n.getchildren():
        print('  child raw tag:', repr(c.tag))
        print('  child localname:', QName(c.tag).localname if isinstance(c.tag, str) else type(c.tag))
        break
    break

path = [
    {'tag': 'html', 'idx': 1},
    {'tag': 'body', 'idx': 1},
    {'tag': 'div', 'idx': 2},
    {'tag': 'div', 'idx': 2},
    {'tag': 'div', 'idx': 1},
    {'tag': 'div', 'idx': 1},
    {'tag': 'ul', 'idx': 2},
    {'tag': 'li', 'idx': 5},
    {'tag': 'div', 'idx': 1},
    {'tag': 'svg', 'idx': 1},
    {'tag': 'path', 'idx': 1},
]
node = root
for item in path[1:]:
    candidates = []
    for c in node.getchildren():
        if not isinstance(c.tag, str):
            continue
        local = QName(c.tag).localname.lower()
        if local == item['tag']:
            candidates.append(c)
    idx = item['idx'] - 1
    print("{}[{}] -> children={} idx={}".format(item['tag'], item['idx'], len(candidates), idx))
    if idx < 0 or idx >= len(candidates):
        print('MISMATCH!')
        break
    node = candidates[idx]
else:
    print('MATCH:', node.tag, node.attrib)
