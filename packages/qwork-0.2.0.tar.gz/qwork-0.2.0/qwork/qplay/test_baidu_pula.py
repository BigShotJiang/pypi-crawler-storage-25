import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from qwork.qplay.persist import PersistPage
from lxml.etree import parse, HTMLParser
from io import StringIO


def _safe(s: str) -> str:
    return "".join(c if ord(c) < 128 else "?" for c in s)


def main():
    page = PersistPage(9222)
    page.goto("https://www.baidu.com")

    html = page.html
    tree = parse(StringIO(html), HTMLParser())
    root = tree.getroot()

    # TC1: 文库 link
    e1 = page.seek("//a[normalize-space(.)='文库']")
    xp1 = e1.xpath
    m1 = tree.xpath(xp1)
    ok1 = len(m1) == 1
    print(f"TC1 ok={ok1} xp={_safe(xp1)}")
    assert ok1, f"TC1 failed: {xp1}"

    # TC2: bubble link (target=_blank)
    e2 = page.seek("//a[@target='_blank']")
    xp2 = e2.xpath
    m2 = tree.xpath(xp2)
    ok2 = len(m2) == 1
    print(f"TC2 ok={ok2} xp={_safe(xp2)}")
    assert ok2, f"TC2 failed: {xp2}"

    # TC3: 换一换 span
    e3 = page.seek("//span[normalize-space(.)='换一换']")
    xp3 = e3.xpath
    m3 = tree.xpath(xp3)
    ok3 = len(m3) == 1
    print(f"TC3 ok={ok3} xp={_safe(xp3)}")
    assert ok3, f"TC3 failed: {xp3}"

    # TC4: the only button on page
    e4 = page.seek("//button")
    xp4 = e4.xpath
    m4 = tree.xpath(xp4)
    ok4 = len(m4) == 1
    print(f"TC4 ok={ok4} xp={_safe(xp4)}")
    assert ok4, f"TC4 failed: {xp4}"

    print("All Baidu test cases passed.")


if __name__ == "__main__":
    main()
