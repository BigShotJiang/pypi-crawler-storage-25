"""
qplay ptable module - HTML Table wrapper implementation

Provides WebTable class that wraps an IElement to provide standardized
table data access with support for header indexing, row/column operations,
and data extraction.
"""

from typing import Any, Self

import tpltable
from tpltable.style import TYPE_BCOLOR, TYPE_FONT_BOLD, TYPE_BORDER
from tpltable.basic import Border, Side
from openpyxl.utils import get_column_letter

from qwork.qplay.interface import IElement
from qwork.qplay.stdio import Warn


class WebTable:
    """
    HTML Table wrapper providing standardized data access.

    Wraps an IElement representing a <table> to provide convenient
    row/column indexing, header-based access, and data extraction.

    Usage:
        table = WebTable(page.seek("//table"))

        # Basic info
        print(table.width, table.height)
        print(table.header)

        # Cell access
        cell = table.cell(0, 1)           # row 0, col 1 element
        text = table.cell(0, 1, True)     # row 0, col 1 text

        # Row/Column
        row = table.row(0)                # all cells in row 0
        col = table.col("名称")            # all cells in "名称" column

        # [] indexing
        table[0]              # row 0
        table[0, 1]           # cell at row 0, col 1
        table[0, True]        # row 0 texts
        table[None, "名称"]    # "名称" column

        # Export
        data = table.tolist()   # 2D list
        dicts = table.todict()  # list of dicts
        tpl = table.totpl()     # tpltable.Table
    """

    def __init__(self, element: IElement):
        """
        Initialize table wrapper.

        Args:
            element: IElement representing a <table> element
        """
        self._element = element
        self._headeridx: dict[str, int] = {}
        self._rawheaders: list[str] = []  # Original headers including duplicates
        self._width = 0
        self._height = 0
        self._parsestructure()

    def _parsestructure(self) -> None:
        """Parse table structure to determine dimensions and headers."""
        rows = self._element.seeks(".//tr")
        if not rows:
            return

        def _processheaders(header_cells: list[IElement]) -> None:
            """Process header cells, handling duplicates."""
            self._width = len(header_cells)
            seen: dict[str, int] = {}  # Track occurrences for deduplication

            for idx, cell in enumerate(header_cells):
                text = cell.text.strip()
                self._rawheaders.append(text)

                if text:
                    # Handle duplicate headers by adding suffix
                    if text in seen:
                        seen[text] += 1
                        unique_key = f"{text}_{seen[text]}"
                    else:
                        seen[text] = 0
                        unique_key = text
                    self._headeridx[unique_key] = idx

        # Check first row for headers
        header_cells = rows[0].seeks(".//th")
        if header_cells:
            _processheaders(header_cells)
        else:
            # No <th>, check for thead
            thead = self._element.seek(".//thead", error=False)
            if thead:
                header_cells = thead.seeks(".//th")
                if header_cells:
                    _processheaders(header_cells)

        # Calculate data rows (excluding header row if present)
        data_rows = self._getdatarows()
        self._height = len(data_rows)

        # Update width from data rows if not set
        if self._width == 0 and data_rows:
            first_row_cells = data_rows[0].seeks(".//td")
            self._width = len(first_row_cells)

    def _getdatarows(self) -> list[IElement]:
        """Get data rows (excluding header rows)."""
        all_rows = self._element.seeks(".//tr")
        if not all_rows:
            return []

        # Check if first row has <th> or is in <thead>
        if all_rows[0].seek(".//th", error=False):
            return all_rows[1:]

        # Check for thead/tbody structure
        thead = self._element.seek(".//thead", error=False)
        if thead:
            tbody = self._element.seek(".//tbody", error=False)
            if tbody:
                return tbody.seeks(".//tr")
            return all_rows[1:] if len(all_rows) > 1 else []

        return all_rows

    def _resolvecol(self, col: int | str) -> int:
        """
        Resolve column index from int or header name.

        For duplicate headers, you can use:
        - '名称' -> returns first occurrence (index 0)
        - '名称_1' -> returns second occurrence (index 1)
        - '名称_2' -> returns third occurrence (index 2)
        """
        if isinstance(col, int):
            return col
        if col in self._headeridx:
            return self._headeridx[col]
        # Fallback: if col matches raw header text, return first occurrence
        for idx, h in enumerate(self._rawheaders):
            if h == col:
                return idx
        raise KeyError(f"Column '{col}' not found in headers: {list(self._headeridx.keys())}")

    def _parserowidx(self, row: int | str) -> int:
        """
        Parse row index from int or header index string.

        Header index formats:
        - '17' - match text in first column
        - '序号:17' - match text in '序号' column
        - '::a' - escaped ':' in text (means ':a')
        """
        if isinstance(row, int):
            return row

        # Parse header index format
        parts = row.split(":")

        # Handle escaped '::' -> ':'
        resolved_parts = []
        i = 0
        while i < len(parts):
            if i < len(parts) - 1 and parts[i + 1] == "":
                # Found '::', combine with next non-empty
                resolved_parts.append(parts[i] + ":" + parts[i + 2] if i + 2 < len(parts) else parts[i] + ":")
                i += 3
            else:
                resolved_parts.append(parts[i])
                i += 1

        if len(resolved_parts) == 1:
            # Simple text match in first column
            search_text = resolved_parts[0]
            col_idx = 0
        else:
            # Header column specified
            header_name = resolved_parts[0]
            search_text = resolved_parts[1]
            col_idx = self._resolvecol(header_name)

        # Find matching row
        data_rows = self._getdatarows()
        for idx, data_row in enumerate(data_rows):
            cells = data_row.seeks(".//td")
            if col_idx < len(cells):
                cell_text = cells[col_idx].text.strip()
                if cell_text == search_text:
                    return idx

        raise ValueError(f"Row with '{row}' not found")

    def _getcellfromrow(self, row_elem: IElement, col_idx: int) -> IElement | None:
        """Get cell element from row element at given column index."""
        cells = row_elem.seeks(".//td")
        if col_idx < len(cells):
            return cells[col_idx]
        return None

    def _resolveinner(self, cell: IElement | None, inner: bool | str | None) -> IElement | str | None:
        """Resolve inner parameter to get final value."""
        if cell is None:
            return None
        if inner is None or inner is False:
            return cell
        if inner is True:
            return cell.text
        # inner is xpath string
        return cell.seek(inner, error=False)

    # -------------------------------------------------------------------------
    # Table metadata properties
    # -------------------------------------------------------------------------

    @property
    def width(self) -> int:
        """表格列数。"""
        return self._width

    @property
    def height(self) -> int:
        """表格行数（不含表头）。"""
        return self._height

    @property
    def header(self) -> list[str]:
        """
        去重后的表头文本列表，重复表头会添加 _1, _2 等后缀。
        如: ['名称', '名称_1', '名称_2']
        """
        return list(self._headeridx.keys())

    @property
    def rawheader(self) -> list[str]:
        """
        原始表头文本列表，包含重复项和空字符串。
        如: ['名称', '名称', '名称', '']
        """
        return self._rawheaders.copy()

    # -------------------------------------------------------------------------
    # Cell access
    # -------------------------------------------------------------------------

    def cell(
        self,
        row: int | str,
        col: int | str,
        inner: bool | str | None = None
    ) -> IElement | str | None:
        """
        获取指定行列的单元格元素或文本。

        Args:
            row: 行索引 (0-based) 或表头索引字符串
            col: 列索引 (0-based) 或表头列名
            inner: True获取文本 / str设置内部xpath / None返回元素

        Returns:
            IElement, str, 或 None（单元格不存在时）
        """
        row_idx = self._parserowidx(row) if isinstance(row, str) else row
        col_idx = self._resolvecol(col) if isinstance(col, str) else col

        data_rows = self._getdatarows()
        if row_idx < 0:
            row_idx = len(data_rows) + row_idx
        if row_idx < 0 or row_idx >= len(data_rows):
            return None

        cell_elem = self._getcellfromrow(data_rows[row_idx], col_idx)
        return self._resolveinner(cell_elem, inner)

    # -------------------------------------------------------------------------
    # Row operations
    # -------------------------------------------------------------------------

    def row(
        self,
        row: int | str,
        inner: bool | str | None = None
    ) -> list[IElement | str | None]:
        """
        获取整行所有单元格。

        Args:
            row: 行索引 (0-based) 或表头索引字符串
            inner: True获取文本 / str设置内部xpath / None返回元素

        Returns:
            单元格列表，长度等于 width，缺失的单元格为 None
        """
        row_idx = self._parserowidx(row) if isinstance(row, str) else row

        data_rows = self._getdatarows()
        if row_idx < 0:
            row_idx = len(data_rows) + row_idx
        if row_idx < 0 or row_idx >= len(data_rows):
            return [None] * self._width

        row_elem = data_rows[row_idx]
        result = []
        for col_idx in range(self._width):
            cell = self._getcellfromrow(row_elem, col_idx)
            result.append(self._resolveinner(cell, inner))
        return result

    # -------------------------------------------------------------------------
    # Column operations
    # -------------------------------------------------------------------------

    def col(
        self,
        col: int | str,
        inner: bool | str | None = None
    ) -> list[IElement | str | None]:
        """
        获取整列单元格。

        Args:
            col: 列索引 (0-based) 或表头列名
            inner: True获取文本 / str设置内部xpath / None返回元素

        Returns:
            该列所有单元格，长度等于 height
        """
        col_idx = self._resolvecol(col) if isinstance(col, str) else col

        data_rows = self._getdatarows()
        result = []
        for row_elem in data_rows:
            cell = self._getcellfromrow(row_elem, col_idx)
            result.append(self._resolveinner(cell, inner))
        return result

    # -------------------------------------------------------------------------
    # Data extraction
    # -------------------------------------------------------------------------

    def tolist(self, inner: bool | str | None = None) -> list[list[IElement | str]]:
        """
        获取完整表格数据。

        Args:
            inner: True获取文本 / str设置内部xpath / None返回元素

        Returns:
            二维列表 [row][col]
        """
        result = []
        data_rows = self._getdatarows()
        for row_elem in data_rows:
            row_data = []
            for col_idx in range(self._width):
                cell = self._getcellfromrow(row_elem, col_idx)
                row_data.append(self._resolveinner(cell, inner))
            result.append(row_data)
        return result

    def todict(self, inner: bool | str | None = None) -> list[dict[str, str]]:
        """
        将表格转换为字典列表 (每行一个 dict，key 为表头)。

        Args:
            inner: True获取文本 / str设置内部xpath

        Returns:
            字典列表，key 为 header，value 为单元格文本或内部文本
        """
        headers = self.header
        if not headers:
            Warn("table", "no headers found, using column indices as keys")
            headers = [str(i) for i in range(self._width)]

        result = []
        data_rows = self._getdatarows()
        for row_elem in data_rows:
            row_dict = {}
            for col_idx, header in enumerate(headers):
                cell = self._getcellfromrow(row_elem, col_idx)
                resolved = self._resolveinner(cell, inner)
                row_dict[header] = str(resolved) if resolved is not None else ""
            result.append(row_dict)
        return result

    def totpl(self) -> tpltable.Table:
        """
        将表格转换为 tpltable 对象，表头作为第一行数据。

        样式:
            - 第一行（表头）: 字体加粗，浅灰色背景 #F5F5F5
            - 所有单元格: 添加框线

        Returns:
            tpltable.Table，第一行为表头，后续为数据行
        """
        headers = self.rawheader if self.rawheader else self.header
        data = self.tolist(inner=True)

        # Build table data: headers first, then data rows
        str_data = []

        if headers:
            str_data.append(headers)
        for row in data:
            str_row = [str(cell) if cell is not None else "" for cell in row]
            str_data.append(str_row)

        # Create table
        tpl = tpltable.Table(_from=str_data)

        if not str_data:
            return tpl

        max_row = len(str_data)
        max_col = len(str_data[0])
        end_col = get_column_letter(max_col)

        # Define border style
        _thin_border = Border(
            left=Side(style='thin', color='000000'),
            right=Side(style='thin', color='000000'),
            top=Side(style='thin', color='000000'),
            bottom=Side(style='thin', color='000000')
        )

        # Apply styles using range indexing
        # 1. First row (headers): bold + light gray background
        tpl.styles[f"A1:{end_col}1"].set(TYPE_FONT_BOLD, True)
        tpl.styles[f"A1:{end_col}1"].set(TYPE_BCOLOR, 'F5F5F5')

        # 2. All cells: add border
        tpl.styles[f"A1:{end_col}{max_row}"].set(TYPE_BORDER, _thin_border)

        return tpl

    # -------------------------------------------------------------------------
    # [] indexing
    # -------------------------------------------------------------------------

    def __getitem__(
        self,
        idx: tuple[int | str | None, int | str | None, bool | str | None]
        | tuple[int | str | None, int | str | None]
        | tuple[int | str]
        | int
        | str,
    ) -> IElement | str | list[IElement | str | None] | None:
        """
        多态索引访问表格数据。

        支持格式:
        - table[row]              # 整行
        - table[row, col]         # 单个单元格
        - table[row, inner]       # 整行带inner转换
        - table[None, col]        # 整列
        - table[row, col, inner]  # 单元格带inner转换
        - table[None, col, inner] # 整列带inner转换

        Examples:
            table[0]                 # 第0行
            table["序号:17"]         # 表头索引定位的行
            table[0, True]           # 第0行文本
            table[0, "//a"]          # 第0行每个cell下的//a
            table[None, 1]           # 第1列
            table[False, "名称"]      # "名称"列
            table[0, 1]              # 第0行第1列单元格
            table[0, 1, True]        # 第0行第1列文本
        """
        # Normalize idx to tuple
        if not isinstance(idx, tuple):
            idx = (idx,)

        # Handle single index: table[row]
        if len(idx) == 1:
            row = idx[0]
            if isinstance(row, int) or isinstance(row, str):
                return self.row(row)
            raise TypeError(f"Invalid row index type: {type(row)}")

        # Handle two indices
        if len(idx) == 2:
            first, second = idx

            # Check if second is inner flag (bool or str starting with /)
            is_inner = isinstance(second, bool) or (isinstance(second, str) and second.startswith("/"))

            if first is None or first is False:
                # Column access: table[None, col] or table[False, col]
                if is_inner:
                    raise ValueError("Cannot use inner flag alone for column, use table[None, col, inner]")
                return self.col(second)

            if is_inner:
                # Row with inner: table[row, True] or table[row, "//a"]
                return self.row(first, second)

            # Cell access: table[row, col]
            return self.cell(first, second)

        # Handle three indices
        if len(idx) == 3:
            row, col, inner = idx

            if row is None or row is False:
                # Column with inner: table[None, col, inner]
                return self.col(col, inner)

            # Cell with inner: table[row, col, inner]
            return self.cell(row, col, inner)

        raise ValueError(f"Invalid index: {idx}")

    # -------------------------------------------------------------------------
    # Utility
    # -------------------------------------------------------------------------

    @property
    def element(self) -> IElement:
        """Get underlying table element."""
        return self._element

    # -------------------------------------------------------------------------
    # IElement delegation - WebTable acts as an IElement
    # -------------------------------------------------------------------------

    @property
    def tag_name(self) -> str:
        """元素标签名。"""
        return self._element.tag_name

    @property
    def xpath(self) -> str:
        """元素xpath。"""
        return self._element.xpath

    @property
    def text(self) -> str:
        """元素文本内容。"""
        return self._element.text

    @property
    def id(self) -> str:
        """元素内部 ID。"""
        return self._element.id

    @property
    def value(self) -> str | None:
        """元素 value 属性。"""
        return self._element.value

    @property
    def size(self) -> dict:
        """元素尺寸 (width, height)。"""
        return self._element.size

    @property
    def rect(self) -> dict:
        """元素矩形 (尺寸和位置)。"""
        return self._element.rect

    @property
    def parent(self) -> IElement | None:
        """元素父节点。"""
        return self._element.parent

    @property
    def children(self) -> list[IElement]:
        """元素子节点。"""
        return self._element.children

    @property
    def backend(self):
        """元素后端。"""
        return self._element.backend

    def geta(self, attr_name: str):
        """获取自身的某个attr，例如'class' 'id'。"""
        return self._element.geta(attr_name)

    def hasa(self, attr_name: str) -> bool:
        """判断自身是否有某个attr，例如'class' 'id'。"""
        return self._element.hasa(attr_name)

    def lista(self) -> list[str]:
        """检索目标的所有attr字段。"""
        return self._element.lista()

    # IAbstractInteraction delegation
    def seek(self, identity: str, *, error: bool = True, pre: int | None = None, after: int | None = None) -> IElement | None:
        """查找单个元素。"""
        return self._element.seek(identity, error=error, pre=pre, after=after)

    def seeks(self, identity: str, *, pre: int | None = None, after: int | None = None) -> list[IElement]:
        """查找多个元素。"""
        return self._element.seeks(identity, pre=pre, after=after)

    def wait(self, identity: str, waitlimit: int = 10000, *, error: bool = True, pre: int | None = None, after: int | None = None) -> IElement | None:
        """等待元素存在。"""
        return self._element.wait(identity, waitlimit, error=error, pre=pre, after=after)

    def waits(self, identity: str, waitlimit: int = 10000, *, pre: int | None = None, after: int | None = None) -> list[IElement]:
        """等待多个元素存在。"""
        return self._element.waits(identity, waitlimit, pre=pre, after=after)

    def test(self, identity: str, *, pre: int | None = 0, after: int | None = 0) -> bool:
        """测试元素是否存在 (非阻塞)。"""
        return self._element.test(identity, pre=pre, after=after)

    def click(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """左键点击元素。"""
        self._element.click(identity, limit=limit, pre=pre, after=after)
        return self

    def typing(self, identity: str, *keys: str, clear: bool = True, pre: int | None = None, after: int | None = None) -> Self:
        """在元素中输入文本。"""
        self._element.typing(identity, *keys, clear=clear, pre=pre, after=after)
        return self

    def hold(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """在元素上按住鼠标左键。"""
        self._element.hold(identity, limit=limit, pre=pre, after=after)
        return self

    def release(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """释放鼠标按钮。"""
        self._element.release(identity, limit=limit, pre=pre, after=after)
        return self

    def doubleClick(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """双击元素。"""
        self._element.doubleClick(identity, limit=limit, pre=pre, after=after)
        return self

    def rClick(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """右键点击元素。"""
        self._element.rClick(identity, limit=limit, pre=pre, after=after)
        return self

    def mClick(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """中键点击元素。"""
        self._element.mClick(identity, limit=limit, pre=pre, after=after)
        return self

    def screenshot(self, path: str | None = None, *, toimage: bool = True) -> Any | None:
        """截图。返回 numpy.ndarray、bytes 或 None。"""
        return self._element.screenshot(path=path, toimage=toimage)

    def __repr__(self) -> str:
        return f"<WebTable {self.width}x{self.height} rawheaders={self.rawheader}>"

    def __str__(self) -> str:
        """返回格式化的表格文本表示，使用原始表头（含重复）。"""
        if self._width == 0 or self._height == 0:
            return "<WebTable empty>"

        data = self.tolist(inner=True)

        # Convert to strings and calculate column widths
        str_data = []
        for row in data:
            str_row = [str(cell) if cell is not None else "" for cell in row]
            str_data.append(str_row)

        # Use raw headers (including duplicates) for display
        display_headers = self._rawheaders if self._rawheaders else [str(i) for i in range(self._width)]

        # Calculate max width for each column
        col_widths = []
        for col_idx in range(self._width):
            width = len(display_headers[col_idx]) if col_idx < len(display_headers) else 0
            for row in str_data:
                if col_idx < len(row):
                    width = max(width, len(row[col_idx]))
            col_widths.append(min(width, 30))  # Cap at 30 chars

        # Build output lines
        lines = []

        # Header row
        header_cells = []
        for col_idx, header in enumerate(display_headers):
            header_cells.append(header.ljust(col_widths[col_idx]))
        lines.append(" | ".join(header_cells))
        lines.append("-" * (sum(col_widths) + 3 * (len(col_widths) - 1)))

        # Data rows (limit to 5 rows)
        max_rows = min(len(str_data), 5)
        for row_idx in range(max_rows):
            row_cells = []
            for col_idx in range(self._width):
                cell_text = str_data[row_idx][col_idx] if col_idx < len(str_data[row_idx]) else ""
                # Truncate if too long
                if len(cell_text) > 30:
                    cell_text = cell_text[:27] + "..."
                row_cells.append(cell_text.ljust(col_widths[col_idx]))
            lines.append(" | ".join(row_cells))

        # Show truncation indicator
        if len(str_data) > 5:
            lines.append(f"... ({len(str_data) - 5} more rows)")

        return "\n".join(lines)


__all__ = ["WebTable"]
