from typing import Any

from qwork.qplay.kernel import (
    GlobalState,
    FilePathRealer,
    Kernel,
    K
)

from qwork.qplay.utils import (
    DownloadWatcher,
)

from qwork.qplay.identylib import (
    IdentityLib,
    IdentityRecord,
    ID,
    Identity,
    Register,
    Resolve,
    Batch,
    MACRO_PREFIX,
    ID_PREFIX,
)

from qwork.qplay.play import (
    Element,
    WebPage,
)

from qwork.qplay.persist import (
    PersistPage,
    PersistError,
    PersistOccupiedError,
    PersistNoPortError,
)

from qwork.qplay.ptable import (
    WebTable,
)

# Direct component access (from initialized kernel)
G = K.G
F = K.F
H = K.H
T = K.T



__all__ = [
    # Core components
    'G', 'F', 'H', 'T', 'K',

    # Kernel classes
    'Kernel',
    'GlobalState',
    'FilePathRealer',

    # Utils
    'DownloadWatcher',

    # Identity
    'IdentityLib',
    'IdentityRecord',
    'ID',
    'Identity',
    'Register',
    'Resolve',
    'Batch',
    'MACRO_PREFIX',
    'ID_PREFIX',

    # Playwright browser automation
    'Element',
    'WebPage',
    'PersistPage',
    'PersistError',
    'PersistOccupiedError',
    'PersistNoPortError',

    # Table wrapper
    'WebTable',
]

