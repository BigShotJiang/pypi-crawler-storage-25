"""
qplay interface module - Protocol definitions for element abstraction

Provides IElement protocol that abstracts common operations between
SeleElement and SeleDriver, enabling polymorphic element handling.
"""

from typing import Protocol, runtime_checkable, Any, Self
from typing import List

import tpltable
from playwright.sync_api import Locator

class IAbstractInteraction(Protocol):

    # -------------------------------------------------------------------------
    # Element searching - Core interface
    # -------------------------------------------------------------------------

    def seek(self, identity: str, *, error: bool = True, pre: int | None = None, after: int | None = None) -> "IElement":
        """
        查找单个元素。

        Args:
            identity: 元素标识符
                - xpath: "//div[@id='main']"
                - @id: "@login" -> "//*[@id='login']"
                - $macro: "$btn" -> 从库解析
                - inline: "$btn: //button" -> 注册并返回
                - params: "$btn('ok')" -> 参数化
            error: 未找到时是否抛出异常
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            找到的元素，若 error=False 且未找到则返回 None
        """
        ...

    def seeks(self, identity: str, *, pre: int | None = None, after: int | None = None) -> List["IElement"]:
        """
        查找多个元素。

        Args:
            identity: 元素标识符 (xpath, @id, $macro, inline, params)
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            找到的元素列表
        """
        ...

    def wait(self, identity: str, waitlimit: int = 10000, *, error: bool = True, pre: int | None = None, after: int | None = None) -> "IElement":
        """
        等待元素存在。

        Args:
            identity: 元素标识符 (xpath, @id, $macro, inline, params)
            waitlimit: 最大等待时间 (毫秒)
            error: 超时时是否抛出异常
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            找到的元素，若 error=False 且超时则返回 None
        """
        ...

    def waits(self, identity: str, waitlimit: int = 10000, *, pre: int | None = None, after: int | None = None) -> List["IElement"]:
        """
        等待多个元素存在。

        Args:
            identity: 元素标识符 (xpath, @id, $macro, inline, params)
            waitlimit: 最大等待时间 (毫秒)
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            找到的元素列表
        """
        ...

    def test(self, identity: str, *, pre: int | None = 0, after: int | None = 0) -> bool:
        """
        测试元素是否存在 (非阻塞)。

        Args:
            identity: 元素标识符 (xpath, @id, $macro, inline, params)
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            元素存在返回 True
        """
        ...

    def table(self, identity: str | None = None, *, waitlimit: int = 10000, pre: int | None = None, after: int | None = None) -> "IWebTable":
        """
        获取表格包装器 WebTable。

        Args:
            identity: 表格元素标识符 (xpath, @id, $macro)。
                     None 表示将自身作为表格元素（WebPage 对应 body）
            waitlimit: 等待超时（毫秒），仅当指定 identity 时有效
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            WebTable 实例
        """
        ...

    # -------------------------------------------------------------------------
    # Element interaction
    # -------------------------------------------------------------------------

    def click(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """
        左键点击元素。

        Args:
            identity: 元素标识符 (xpath, @id, $macro, inline, params)，None 表示点击自身
            limit: 等待限制 (毫秒)
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            self 用于链式调用
        """
        ...

    def typing(self, identity: str, *keys: str, clear: bool = True, pre: int | None = None, after: int | None = None) -> Self:
        """
        在元素中输入文本。

        Args:
            identity: 元素标识符 (xpath, @id, $macro, inline, params) 或要输入的文本
            keys: 要输入的按键
            clear: 输入前是否清空
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            self 用于链式调用
        """
        ...

    def hold(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """
        在元素上按住鼠标左键。

        Args:
            identity: 元素标识符 (xpath, @id, $macro)，None 表示按住自身
            limit: 等待限制 (毫秒)
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            self 用于链式调用
        """
        ...

    def release(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """
        释放鼠标按钮。默认释放所有鼠标按钮

        Args:
            identity: 元素标识符 (xpath, @id, $macro)，None 表示在自身上释放
            limit: 等待限制 (毫秒)
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            self 用于链式调用
        """
        ...

    def doubleClick(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """
        双击元素。

        Args:
            identity: 元素标识符 (xpath, @id, $macro)，None 表示双击自身
            limit: 等待限制 (毫秒)
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            self 用于链式调用
        """
        ...

    def rClick(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """
        右键点击元素。

        Args:
            identity: 元素标识符 (xpath, @id, $macro)，None 表示右键点击自身
            limit: 等待限制 (毫秒)
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            self 用于链式调用
        """
        ...


    def mClick(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """
        中键点击元素。

        Args:
            identity: 元素标识符 (xpath, @id, $macro)，None 表示中键点击自身
            limit: 等待限制 (毫秒)
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            self 用于链式调用
        """
        ...

    def screenshot(self, path: str | None = None, *, toimage: bool = True) -> Any | None:
        """
        截图。

        Args:
            path: 保存路径，None 则不保存到文件
            toimage: True 返回 numpy.ndarray，False 返回原始 bytes

        Returns:
            numpy.ndarray 或 bytes 图像数据，失败时返回 None
        """
        ...


@runtime_checkable
class IElement(IAbstractInteraction, Protocol):
    """
    元素类对象的协议，支持查找和交互操作。

    实现类:
    - SeleElement: 单个网页元素
    - SeleDriver: 网页驱动 (根元素)

    用法:
        def process_element(element: IElement) -> None:
            child = element.seek("//div")
            children = element.seeks("//span")
    """

    # -------------------------------------------------------------------------
    # Element properties
    # -------------------------------------------------------------------------

    @property
    def tag_name(self) -> str:
        """元素标签名。"""
        ...

    @property
    def xpath(self) -> str:
        """
        获取该元素的基于页面的xpath
        
        Return:
            str 该元素基于页面的xpath
        """
        pass


    @property
    def text(self) -> str:
        """元素文本内容。"""
        ...

    @property
    def id(self) -> str:
        """元素内部 ID。"""
        ...

    @property
    def value(self) -> str | None:
        """元素 value 属性。"""
        ...

    @property
    def size(self) -> dict:
        """元素尺寸 (width, height)。"""
        ...

    @property
    def rect(self) -> dict:
        """元素矩形 (尺寸和位置)。"""
        ...

    @property
    def parent(self) -> "IElement":
        """元素父节点。"""
        ...

    @property
    def children(self) -> list["IElement"]:
        """元素子节点。"""
        ...

    @property
    def backend(self) -> Locator:
        """元素后端。"""
        ...

    def geta(self, attr_name:str) -> Any:
        """
        获取自身的某个attr，例如'class' 'id'
        
        Returns:
            Any 属性对应的值
            
        Note:
            对于无属性attr，例如div<class='a' checked id='@12134'>，geta('checked')返回None。此时建议用hasa代替
        """
        pass
    
    def hasa(self, attr_name:str) -> bool:
        """
        判断自身是否有某个attr，例如'class' 'id'
        
        Returns:
            bool 属性是否存在
        """
        pass
    
    def lista(self) -> list[str]:
        """
        检索目标的所有attr字段
        
        Returns:
            list[str] 属性列表
        """
        pass

@runtime_checkable
class IWebPage(IAbstractInteraction, Protocol):
    """
    页面驱动专属操作的协议。

    从 IElement 分离以区分仅驱动支持的功能。
    """

    @property
    def title(self) -> str:
        """当前页面标题。"""
        ...

    @property
    def url(self) -> str:
        """当前页面 URL。"""
        ...

    @url.setter
    def url(self, url: str) -> None:
        """跳转到url"""
        pass

    @property
    def html(self) -> str:
        """当前页面 HTML 源码。"""
        ...

    def back(self) -> None:
        """返回历史记录。"""
        ...

    def forward(self) -> None:
        """前进历史记录。"""
        ...

    def refresh(self) -> None:
        """刷新当前页面。"""
        ...

    def inspect(self, *, pre: int | None = None, after: int | None = None) -> "IElement":
        """
        检视元素模式。高亮鼠标处的元素，并截获下一次鼠标点击，返回点击的元素。

        Args:
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            用户点击的元素
        """
        ...


@runtime_checkable
class IWebTable(IElement, Protocol):
    """
    表格组件接口 - 提供对 HTML Table 结构的标准化访问，同时继承 IElement 的所有功能。

    设计原则:
    - 继承 IElement 的所有元素操作方法 (xpath, text, seek, click 等)
    - 支持行列索引访问，符合直觉
    - 延迟加载，按需提取文本内容
    - 实现类负责处理 tbody/thead 结构差异、行列合并等复杂情况

    Usage:
        table = Table(page.seek("//table"))

        # 基本信息
        print(table.width, table.height)
        print(table.header)  # 表头文本列表

        # 单元格访问 - 通过 cell() 方法或 [] 索引
        cell = table.cell(0, 1)           # 第0行第1列的 IElement
        cell_text = table.cell(0, 1, True)  # 第0行第1列的文本内容

        # 行数据
        row = table.row(0)                # 第0行所有单元格
        row_text = table[0, True]         # 第0行所有内部文本

        # 列数据
        col = table.col(1)                # 第1列所有单元格，可用 header 索引: table.col("名称")
        col_text = table[None, 1, True]   # 第1列所有内部文本

        # [] 索引多态访问
        table[0]              # 第0行
        table[0, 1]           # 第0行第1列单元格
        table[None, "名称"]   # "名称"列
        table[0, 1, "//a"]    # 第0行第1列下的 //a 元素

        # 批量导出
        data = table.tolist()   # 二维列表
        dicts = table.todict()  # 字典列表
    """

    # -------------------------------------------------------------------------
    # Table metadata
    # -------------------------------------------------------------------------

    @property
    def width(self) -> int:
        """表格列数 (根据第一行确定，实现类处理 colspan 情况)。"""
        ...

    @property
    def height(self) -> int:
        """表格行数 (不含表头)。"""
        ...

    @property
    def header(self) -> list[str]:
        """
        表头文本列表，空表返回空列表。

        并列表头处理:
            当存在重复的表头时（如 [['名称', '名称', '值'], ...]），
            返回的列表会对重复项添加后缀以区分：
            ['名称', '名称_1', '值']
            原始表头可通过 rawheader 属性获取。
        """
        ...

    @property
    def rawheader(self) -> list[str]:
        """
        原始表头文本列表，包含重复项和空字符串。

        与 header 属性的区别:
            rawheader 保留原始顺序和所有重复项，如：
            ['实色效果', '英文名称', 'R.G.B', '16色', '实色效果', '英文名称', 'R.G.B', '16色']
        """
        ...

    # -------------------------------------------------------------------------
    # Cell access - 基础单元格操作
    # -------------------------------------------------------------------------

    def cell(self, row: int | str, col: int | str, inner: bool | str | None = None) -> "IElement | str | None":
        """
        获取指定行列的单元格元素或文本。

        Args:
            row: 行索引 (0-based) | int / 表头索引 详见下
            col: 列索引 (0-based) | int / 对应的表头列名
            inner: 是否获取内部文本 | bool / 设置一个内部xpath，这将基于该cell再seek一次

        NOTE - 表头索引:
            表头索引可以是两种类型。
            1. 一般字符串，默认对表格第一列进行匹配(找到一个td中包含该文本)。该td所在的行被视作行索引
            2. 指定表头和内容字符串，以':'进行分隔。前面是表头列名，后面是待匹配的文本。先根据表头列名匹配列，然后再查找该列的匹配td，取其行索引(类似1)
            e.g. '17' '序号:17' 如果要表示':'，亲使用'::'，例如'::a'表示实际文本':a'

        NOTE - 并列表头:
            当表头存在重复时（如两个'名称'列），col 参数支持两种访问方式：
            1. 使用原始表头名（如 '名称'）- 返回第一匹配列（索引0）
            2. 使用带后缀的表头名（如 '名称_1'）- 返回第二匹配列（索引4）
            带后缀的表头名可通过 header 属性查看。

        Returns:
            IElement / str / None。当 inner=True 或 inner=str 时返回 str，单元格不存在时返回 None

        Note:
            支持负索引，-1 表示最后一行/列
        """
        ...

    # -------------------------------------------------------------------------
    # Row iteration - 行级操作
    # -------------------------------------------------------------------------

    def row(self, row: int | str, inner: bool | str = None) -> list["IElement | str | None"]:
        """
        获取整行所有单元格。

        Args:
            row: 行索引 (0-based) | int / 表头索引，详见 cell() 方法 NOTE
            inner: 是否获取内部文本 | bool / 设置一个内部 xpath，每个单元格将基于此 xpath 再 seek 一次

        Returns:
            单元格列表，长度等于 width，缺失的单元格为 None

        Note - 并列表头:
            当存在并列表头时，返回的列表包含所有列（包括重复表头对应的列），
            列顺序与原始表头顺序一致。例如对于表头
            ['实色效果', '英文名称', 'R.G.B', '16色', '实色效果', '英文名称', 'R.G.B', '16色']，
            返回的列表长度为 8。
        """
        ...

    # -------------------------------------------------------------------------
    # Column operations - 列级操作
    # -------------------------------------------------------------------------

    def col(self, col: int | str, inner: bool | str = None) -> list["IElement | str | None"]:
        """
        获取整列单元格。

        Args:
            col: 列索引 (0-based) | int / 对应的表头列名
            inner: 是否获取内部文本 | bool / 设置一个内部 xpath，每个单元格将基于此 xpath 再 seek 一次

        Returns:
            该列所有单元格，长度等于 height

        Note - 并列表头:
            当存在重复表头时（如两个 '名称' 列）：
            1. 使用原始名称 '名称' - 返回第一个匹配列（索引0）
            2. 使用带后缀名称 '名称_1' - 返回第二个匹配列（索引4）
            查看可用的带后缀表头名，使用 table.header 属性。
        """
        ...


    # -------------------------------------------------------------------------
    # Data extraction - 数据提取
    # -------------------------------------------------------------------------

    def tolist(self, inner: bool | str = None) -> list[list["IElement | str"]]:
        """
        获取完整表格数据。

        Args:
            inner: 是否获取内部文本 | bool / 设置一个内部 xpath，每个单元格将基于此 xpath 再 seek 一次

        Returns:
            二维列表 [row][col]，元素类型为 IElement 或 str

        Note - 并列表头:
            返回的二维列表包含所有列（包括重复表头对应的列），
            列数等于 width（原始表头的列数）。
            例如对于表头 ['A', 'B', 'A', 'B']，每行返回 4 个元素。
        """
        ...

    def todict(self, inner: bool | str = None) -> list[dict[str, str]]:
        """
        将表格转换为字典列表 (每行一个 dict，key 为表头)。

        Args:
            inner: 是否获取内部文本 | bool / 设置一个内部 xpath，每个单元格将基于此 xpath 再 seek 一次

        Returns:
            字典列表，key 为 header，value 为单元格文本或内部文本

        Note - 并列表头:
            当存在重复表头时，使用去重后的表头作为 key（如 '名称', '名称_1'）。
            这意味着 todict() 可以解决重复 key 的问题，但会丢失原始表头的信息。
            如果需要保留原始表头结构，建议使用 tolist() 方法。
        """
        ...
    
    def totpl(self) -> tpltable.Table:  # 不支持inner参数
        """
        将表格转换为tpltable对象

        Returns:
            tpltable.Table
        """
        ...

    def __getitem__(
        self,
        idx: tuple[int | str | None, int | str | None, bool | str | None]
        | tuple[int | str | None, int | str | None]
        | tuple[int | str]
        | int
        | str,
    ) -> "IElement | str | list[IElement | str | None] | None":
        """
        多态索引访问表格数据。

        支持三种长度的索引：

        长度1 - 获取整行:
            table[row] -> list[IElement | None]
            row: int | str  行索引(0-based) / 表头索引，详见 cell() NOTE

        长度2 - 三种模式:
            ① table[row, inner]     -> list[IElement | str | None]  整行带inner转换
            ② table[None, col]      -> list[IElement | None]       整列
            ③ table[row, col]       -> IElement | None             单个单元格

        长度3 - 两种模式:
            ① table[row, col, inner]  -> IElement | str | None           单元格带inner转换
            ② table[None, col, inner] -> list[IElement | str | None]     整列带inner转换

        Args:
            idx: 索引元组或单值
                - row: 行索引 / 表头索引字符串 / None或False表示取列
                - col: 列索引 / 表头列名 / None或False表示取行
                - inner: True获取内部文本 / str设置内部xpath再seek一次 / None或False不转换

        Returns:
            根据索引组合返回不同结果类型:
            - 行索引: list[IElement | str | None]
            - 列索引: list[IElement | str | None]
            - 行列索引: IElement | str | None

        Note - 并列表头:
            当存在重复表头时，使用带后缀的表头名来精确指定列：
            - table[None, "名称"]    # 返回第一个 "名称" 列（索引0）
            - table[None, "名称_1"]  # 返回第二个 "名称" 列（索引4）
            查看可用的带后缀表头名，使用 table.header 属性。

        Examples:
            table[0]                 # 第0行所有单元格
            table["序号:17"]         # 表头索引定位的行
            table[0, True]           # 第0行，返回内部文本
            table[0, "//a"]          # 第0行，返回每个cell下的//a元素
            table[None, 1]           # 第1列所有单元格
            table[False, "名称"]     # "名称"列所有单元格
            table[0, 1]              # 第0行第1列单元格
            table[0, 1, True]        # 第0行第1列单元格的内部文本
            table[None, 1, True]     # 第1列所有单元格的内部文本
        """
        ...


__all__ = [
    'IElement',
    'IWebPage',
    'IWebTable',
]
