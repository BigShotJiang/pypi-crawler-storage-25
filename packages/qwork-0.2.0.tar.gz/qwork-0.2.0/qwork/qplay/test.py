from qwork.qplay.persist import PersistPage

page = PersistPage()
# page.goto("https://www.baidu.com")
print(page.url)

e0 = page.table("//table[contains(@class,'toolTable')]")
print(e0)

t = e0.totpl()
print(t)
