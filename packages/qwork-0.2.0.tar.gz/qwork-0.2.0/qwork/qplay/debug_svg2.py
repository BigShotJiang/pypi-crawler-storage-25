import sys, os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from qwork.qplay.persist import PersistPage
from lxml.etree import parse, HTMLParser
from io import StringIO

p = PersistPage(9222)
html = p.html
tree = parse(StringIO(html), HTMLParser())

uls = tree.xpath("//ul[@class='right-entry']")
print('uls:', len(uls))
for ul in uls:
    for i, li in enumerate(li for li in ul.getchildren() if isinstance(li.tag, str)):
        text = ''.join(li.itertext()).strip()
        print(f"  li{i}: class={li.get('class')!r} text={text!r}")
        # show direct div children
        for j, div in enumerate(c for c in li.getchildren() if isinstance(c.tag, str) and c.tag.lower() == 'div'):
            div_text = ''.join(div.itertext()).strip()
            print(f"    div{j}: class={div.get('class')!r} text={div_text!r}")
