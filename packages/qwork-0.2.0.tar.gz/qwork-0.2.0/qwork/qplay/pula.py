"""
pula - Robust XPath Generator

Based on stable XPath generation research. Iteratively refines candidate
XPaths using attribute scoring, semantic evaluation, and uniqueness verification.
"""

import re
import math
import heapq
from typing import Any

from lxml.etree import Element as LxmlElement


# ---------- Constants ----------
ATTR_PRIORITY = {
    "data-testid": 0,
    "data-qa": 0,
    "data-cy": 0,
    "id": 1,
    "name": 2,
    "aria-label": 3,
    "aria-labelledby": 3,
    "role": 4,
    "alt": 5,
    "title": 6,
    "placeholder": 7,
    "type": 8,
    "value": 9,
    "class": 10,
}

ATTR_BLACKLIST = {
    "onclick",
    "onload",
    "tabindex",
    "width",
    "height",
    "style",
    "size",
    "maxlength",
    "target",
    "data-io-article-url",
}

DYNAMIC_PATTERNS = [
    (re.compile(r"^data-v-[0-9a-f]{8}$"), "vue-scope"),
    (re.compile(r"^_ngcontent-[a-z0-9]+$"), "angular-scope"),
    (re.compile(r"^css-[a-z0-9]+$"), "css-in-js"),
    (re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"), "uuid"),
    (re.compile(r"^ext-gen-\d+$"), "extjs-generated"),
    (re.compile(r"^__[a-zA-Z0-9]{8,}$"), "react-random"),
]

TAILWIND_PREFIXES = {
    "flex", "grid", "block", "inline", "hidden", "visible",
    "items-", "justify-", "rounded", "border", "shadow",
    "bg-", "text-", "font-", "p-", "m-", "px-", "py-", "mx-", "my-",
    "w-", "h-", "min-", "max-", "overflow-", "absolute", "relative",
    "static", "fixed", "sticky", "top-", "left-", "right-", "bottom-",
    "z-", "opacity-", "cursor-", "select-", "pointer-", "resize-",
}

GENERAL_TERMS = {
    "submit", "cancel", "search", "filter", "user", "order",
    "product", "login", "logout", "menu", "nav", "home", "about",
    "contact", "cart", "checkout", "wishlist", "feed", "like", "share",
    "balance", "transfer", "send", "receive", "profile", "setting",
    "copy", "paste", "delete", "edit", "save", "download", "upload",
}

MAX_ATTR_COMBO = 3
MAX_BFS_DEPTH = 8
POS_PENALTY = 600.0
STAR_PENALTY = 200.0
LENGTH_PENALTY = 5.0


# ---------- Data Classes ----------
class XpathCandidate:
    def __init__(self, value: str, score: float = 0.0):
        self.value = value
        self.score = score

    def __lt__(self, other: "XpathCandidate") -> bool:
        return self.score > other.score

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, XpathCandidate):
            return NotImplemented
        return self.value == other.value

    def __hash__(self) -> int:
        return hash(self.value)


class AttrInfo:
    def __init__(self, name: str, value: str):
        self.name = name
        self.value = value
        self.stablescore = 0.0
        self.freq = 1
        self.uniqueness = 1.0


# ---------- Internal Utilities ----------
def _isDynamicValue(_value: str) -> bool:
    if not _value:
        return True
    for _pat, _kind in DYNAMIC_PATTERNS:
        if _pat.search(_value):
            return True
    if len(_value) < 5:
        return False
    _counts = {}
    for _c in _value:
        _counts[_c] = _counts.get(_c, 0) + 1
    _entropy = -sum(
        (_c / len(_value)) * math.log2(_c / len(_value)) for _c in _counts.values()
    )
    return _entropy > 4.5


def _isCssInJsClass(_cls: str) -> bool:
    if re.match(r"^css-[a-z0-9]+$", _cls):
        return True
    for _prefix in TAILWIND_PREFIXES:
        if _cls.startswith(_prefix):
            return True
    return False


_UTILITY_PREFIXES = {
    "c-", "s-", "v-", "el-", "is-", "ui-", "ant-", "css-", "sc-", "styled-",
    "mx-", "my-", "px-", "py-", "mt-", "pt-", "mr-", "pr-", "mb-", "pb-",
    "ml-", "pl-", "w-", "h-", "bg-", "text-", "border-", "rounded-",
    "flex-", "grid-", "gap-", "p-", "m-", "col-", "row-", "justify-",
    "items-", "content-", "space-", "overflow-", "z-", "opacity-",
    "shadow-", "transition-", "transform-", "cursor-", "select-",
    "resize-", "list-", "table-", "decoration-", "tracking-", "leading-",
    "font-", "whitespace-", "break-", "align-", "float-", "clear-",
    "bili-", "vui-", "arco-", "t-",
}


def _filterClasses(_classstr: str) -> list[str]:
    if not _classstr:
        return []
    _parts = _classstr.split()
    _filtered = []
    for _p in _parts:
        if _isCssInJsClass(_p):
            continue
        if _isDynamicValue(_p):
            continue
        # drop common utility/framework prefixes (c-font-normal, s-item, v-popover, el-button, etc.)
        _pref = _p.split("-")[0] + "-" if "-" in _p else ""
        if _pref and any(_p.startswith(q) for q in _UTILITY_PREFIXES):
            continue
        _filtered.append(_p)
    return _filtered


def _isSequenceValue(_value: str) -> tuple[bool, str, int]:
    _m = re.match(r"^([a-z]+-)(\d{1,2})$", _value)
    if not _m:
        return False, "", 0
    return True, _m.group(1), int(_m.group(2))


def _buildAttrPredicate(_name: str, _value: str) -> str:
    if _name == "class":
        _parts = _value.split()
        if len(_parts) == 1:
            return f"[contains(@class,'{_parts[0]}')]"
        _preds = [f"contains(@class,'{_p}')" for _p in _parts]
        return "[" + " and ".join(_preds) + "]"
    if _name == "ns":
        return f"[normalize-space(.)='{_value}']"
    if _name in ("href", "src"):
        _stable = _value.split("?")[0].rstrip("/")
        if len(_stable) > 25:
            _domain = re.match(r"(https?://[^/]+)", _stable)
            if _domain:
                return f"[contains(@{_name},'{_domain.group(1)}')]"
            return f"[starts-with(@{_name},'{_stable[:25]}')]"
        return f"[starts-with(@{_name},'{_stable}')]"
    return f"[@{_name}='{_value}']"


def _buildComboPredicate(_attrs: list[AttrInfo]) -> str:
    _parts = []
    for _a in _attrs:
        if _a.name == "class":
            for _cp in _a.value.split():
                _parts.append(f"contains(@class,'{_cp}')")
        elif _a.name == "ns":
            _parts.append(f"normalize-space(.)='{_a.value}'")
        else:
            _parts.append(f"@{_a.name}='{_a.value}'")
    return "[" + " and ".join(_parts) + "]"


def _headTag(_xpath: str) -> str:
    _body = _xpath[2:] if _xpath.startswith("//") else _xpath
    if not _body:
        return "*"
    _first = _body.split("/")[0]
    _tag = _first.split("[")[0]
    return _tag if _tag else "*"


def _headHasPredicate(_xpath: str) -> bool:
    _body = _xpath[2:] if _xpath.startswith("//") else _xpath
    if not _body:
        return False
    _first = _body.split("/")[0]
    return "[" in _first


def _addPredicateToHead(_xpath: str, _predicate: str) -> str:
    _body = _xpath[2:] if _xpath.startswith("//") else _xpath
    if not _body:
        return "//*" + _predicate
    _parts = _body.split("/", 1)
    _first = _parts[0]
    if "[" in _first:
        _idx = _first.index("[")
        _tag = _first[:_idx]
        _rest = _first[_idx:]
        _new_first = _tag + _predicate + _rest
    else:
        _new_first = _first + _predicate
    if len(_parts) == 1:
        return "//" + _new_first
    return "//" + _new_first + "/" + _parts[1]


def _replaceHeadTag(_xpath: str, _tag: str) -> str:
    _body = _xpath[2:] if _xpath.startswith("//") else _xpath
    if not _body:
        return f"//{_tag}"
    _parts = _body.split("/", 1)
    _first = _parts[0]
    if "[" in _first:
        _idx = _first.index("[")
        _new_first = _tag + _first[_idx:]
    else:
        _new_first = _tag
    if len(_parts) == 1:
        return f"//{_new_first}"
    return f"//{_new_first}/{_parts[1]}"


def _getLength(_xpath: str) -> int:
    _body = _xpath[2:] if _xpath.startswith("//") else _xpath
    if not _body:
        return 0
    return sum(1 for _p in _body.split("/") if _p)


def _addLevel(_xpath: str) -> str:
    return "//*" + _xpath[1:]


def _isBareTag(_xpath: str) -> bool:
    _body = _xpath[2:] if _xpath.startswith("//") else _xpath
    if not _body:
        return False
    _segs = _body.split("/")
    return len(_segs) == 1 and "[" not in _segs[0] and _segs[0] != "*"


# ---------- Builder Class ----------
class PulaBuilder:
    def __init__(self, document: LxmlElement):
        self._document = document
        self._total = self._countElements(document)
        self._index = self._buildIndex(document)
        self._seqcache: dict[str, bool] = {}

    def _countElements(self, _node: LxmlElement) -> int:
        _count = 1
        for _child in _node.iterchildren():
            if isinstance(_child.tag, str):
                _count += self._countElements(_child)
        return _count

    def _buildIndex(self, _node: LxmlElement) -> dict[str, int]:
        _idx: dict[str, int] = {}
        for _el in _node.iter():
            if not isinstance(_el.tag, str):
                continue
            for _k, _v in _el.attrib.items():
                _key = f"{_k}={_v}"
                _idx[_key] = _idx.get(_key, 0) + 1
                if _k == "class":
                    for _tok in _v.split():
                        _idx[f"class-contains={_tok}"] = _idx.get(f"class-contains={_tok}", 0) + 1
            _text = self._normalizeText(_el)
            if _text:
                _idx[f"ns={_text}"] = _idx.get(f"ns={_text}", 0) + 1
        return _idx

    def _normalizeText(self, _el: LxmlElement) -> str:
        _text = "".join(_el.itertext())
        _text = " ".join(_text.split())
        if len(_text) > 80:
            return _text[:80]
        return _text

    def _countMatches(self, _xpath: str) -> int:
        try:
            return len(self._document.xpath(_xpath))
        except Exception:
            return 0

    def _isUnique(self, _xpath: str, _target: LxmlElement) -> bool:
        try:
            _matches = self._document.xpath(_xpath)
            return len(_matches) == 1 and _matches[0] == _target
        except Exception:
            return False

    def _getAncestor(self, _element: LxmlElement, _level: int) -> LxmlElement:
        _node = _element
        for _ in range(_level):
            _parent = _node.getparent()
            if _parent is None:
                break
            _node = _parent
        return _node

    def _getTag(self, _element: LxmlElement) -> str:
        return _element.tag.lower() if isinstance(_element.tag, str) else "*"

    def _isSequenceStable(self, _prefix: str) -> bool:
        if _prefix in self._seqcache:
            return self._seqcache[_prefix]
        _count = 0
        for _el in self._document.iter():
            if not isinstance(_el.tag, str):
                continue
            _idv = _el.get("id", "")
            _m = re.match(rf"^{re.escape(_prefix)}(\d{{1,2}})$", _idv)
            if _m:
                _count += 1
        _stable = _count <= 3
        self._seqcache[_prefix] = _stable
        return _stable

    def _evaluateAttr(self, _name: str, _value: str) -> AttrInfo:
        _info = AttrInfo(_name, _value)
        if _name in ATTR_BLACKLIST:
            _info.stablescore = 0.0
            _info.freq = self._index.get(f"{_name}={_value}", 1)
            return _info

        if _isDynamicValue(_value):
            _info.stablescore = 0.1
            _info.freq = self._index.get(f"{_name}={_value}", 1)
            return _info

        if _name == "class":
            _filtered = _filterClasses(_value)
            if not _filtered:
                _info.stablescore = 0.1
                _info.freq = 1
            else:
                _info.value = " ".join(_filtered)
                _info.stablescore = 0.75
                _maxfreq = 1
                for _tok in _filtered:
                    _f = self._index.get(f"class-contains={_tok}", 1)
                    if _f > _maxfreq:
                        _maxfreq = _f
                _info.freq = _maxfreq
            return _info

        if _name in ("data-testid", "data-qa", "data-cy"):
            _info.stablescore = 0.95
        elif _name == "id":
            _is_seq, _prefix, _idx = _isSequenceValue(_value)
            if _is_seq and self._isSequenceStable(_prefix):
                _info.stablescore = 0.8
            else:
                _info.stablescore = 0.85
        elif _name in ("aria-label", "aria-labelledby"):
            _info.stablescore = 0.8
        elif _name == "name":
            _info.stablescore = 0.75
        elif _name in ("alt", "title", "placeholder"):
            _info.stablescore = 0.7
        elif _name in ("href", "src"):
            _info.stablescore = 0.28
            # truncate query params for scoring
            _trunc = _value.split("?")[0]
            _info.freq = self._index.get(f"{_name}={_trunc}", 1)
            return _info
        else:
            _info.stablescore = 0.5

        _info.freq = self._index.get(f"{_name}={_value}", 1)
        return _info

    def _computeAttrScore(self, _info: AttrInfo) -> float:
        if self._total <= 1:
            _u = 1.0
        else:
            _u = min(1.0, math.log2(self._total / _info.freq) / math.log2(self._total))
        _s = _info.stablescore
        _p = ATTR_PRIORITY.get(_info.name, 20)
        _sem = 0.0
        _low = _info.value.lower()
        for _term in GENERAL_TERMS:
            if _term in _low:
                _sem = max(_sem, 0.2)
        _lenpen = max(0, (len(_info.value) - 30) * 0.01)
        _score = (_u ** 2) * (_s ** 1.5) * (1.0 / (_p + 1)) * (1.0 + _sem) - _lenpen
        return max(0.0, _score)

    def _getTextAttr(self, _element: LxmlElement) -> AttrInfo | None:
        _text = self._normalizeText(_element)
        if not _text:
            return None
        _freq = self._index.get(f"ns={_text}", 1)
        _info = AttrInfo("ns", _text)
        _info.freq = _freq
        _len = len(_text)
        if _len <= 4:
            _base = 0.9
        elif _len <= 7:
            _base = 0.6
        else:
            _base = 0.2
        _info.stablescore = _base
        _info.uniqueness = (
            1.0 if self._total <= 1 else min(1.0, math.log2(self._total / _freq) / math.log2(self._total))
        )
        return _info

    def _getAttrs(self, _element: LxmlElement) -> list[AttrInfo]:
        _attrs = []
        for _k, _v in _element.attrib.items():
            _info = self._evaluateAttr(_k, _v)
            if _info.stablescore > 0.15:
                _attrs.append(_info)
        for _a in _attrs:
            _a.stablescore = self._computeAttrScore(_a)
            _a.uniqueness = (
                1.0 if self._total <= 1 else min(1.0, math.log2(self._total / _a.freq) / math.log2(self._total))
            )
        _attrs.sort(key=lambda _x: _x.stablescore, reverse=True)
        return _attrs

    def _scoreXpath(self, _xpath: str) -> float:
        _slen = len(_xpath)
        _has_pos = bool(re.search(r"\[\d+\]", _xpath))
        _has_star = _headTag(_xpath) == "*"
        _depth = max(0, _xpath.count("/") - 1)
        _struct_penalty = _depth * 20
        _score = 1000.0 - _slen * LENGTH_PENALTY - _struct_penalty
        if _has_pos:
            _score -= POS_PENALTY
        if _has_star:
            _score -= STAR_PENALTY
        for _tag in ("button", "a", "input", "nav", "header", "main"):
            if f"//{_tag}" in _xpath or f"/{_tag}[" in _xpath or f"/{_tag}/" in _xpath:
                _score += 10.0
                break
        return _score

    def _expand(self, _xpath: str, _element: LxmlElement) -> list[XpathCandidate]:
        _level = _getLength(_xpath)
        _ancestor = self._getAncestor(_element, _level - 1)
        _cands: list[XpathCandidate] = []

        # 1. convert star to actual tag
        if _headTag(_xpath) == "*":
            _new = _replaceHeadTag(_xpath, self._getTag(_ancestor))
            _cands.append(XpathCandidate(_new, self._scoreXpath(_new)))

        if not _headHasPredicate(_xpath) and _headTag(_xpath) != "*" and isinstance(_ancestor.tag, str):
            _attrs = self._getAttrs(_ancestor)
            _textinfo = self._getTextAttr(_ancestor)

            # 2. single best attributes (class is split into individual tokens)
            for _a in _attrs[:6]:
                if _a.name == "class":
                    _tokens = _a.value.split()
                    for _tok in _tokens[:2]:
                        _pred = f"[contains(@class,'{_tok}')]"
                        _new = _addPredicateToHead(_xpath, _pred)
                        _cands.append(
                            XpathCandidate(_new, self._scoreXpath(_new) + _a.stablescore * 100)
                        )
                else:
                    _pred = _buildAttrPredicate(_a.name, _a.value)
                    _new = _addPredicateToHead(_xpath, _pred)
                    _cands.append(
                        XpathCandidate(_new, self._scoreXpath(_new) + _a.stablescore * 100)
                    )
                    if _a.name == "id":
                        _is_seq, _prefix, _idx = _isSequenceValue(_a.value)
                        if _is_seq and self._isSequenceStable(_prefix):
                            _pred = f"[starts-with(@id,'{_prefix}')]"
                            _new = _addPredicateToHead(_xpath, _pred)
                            _cands.append(
                                XpathCandidate(_new, self._scoreXpath(_new) + _a.stablescore * 80)
                            )

            # 3. text content predicate
            if _textinfo:
                _pred = f"[normalize-space(.)='{_textinfo.value}']"
                _new = _addPredicateToHead(_xpath, _pred)
                _cands.append(
                    XpathCandidate(_new, self._scoreXpath(_new) + _textinfo.stablescore * 90)
                )

            # 3.5 short-text + first-class shortcut (highly preferred over href/src)
            if _textinfo and len(_textinfo.value) <= 4:
                _class_attr = next((a for a in _attrs if a.name == "class"), None)
                if _class_attr:
                    _first_tok = _class_attr.value.split()[0]
                    _combo_pred = _buildComboPredicate([_textinfo, AttrInfo("class", _first_tok)])
                    _new = _addPredicateToHead(_xpath, _combo_pred)
                    _cands.append(
                        XpathCandidate(_new, self._scoreXpath(_new) + 200.0)
                    )

            # 4. attribute combinations (pairs and triples)
            # flatten class tokens and include normalize-space so combos stay short and semantic
            _flat_attrs: list[AttrInfo] = []
            if _textinfo and _textinfo.stablescore > 0.15:
                _flat_attrs.append(_textinfo)
            for _a in _attrs:
                if _a.name == "class":
                    for _tok in _a.value.split()[:2]:
                        _cp = AttrInfo("class", _tok)
                        _cp.stablescore = _a.stablescore
                        _cp.freq = _a.freq
                        _cp.uniqueness = _a.uniqueness
                        _flat_attrs.append(_cp)
                else:
                    _flat_attrs.append(_a)
            _top = [a for a in _flat_attrs if a.stablescore > 0.0][:MAX_ATTR_COMBO]
            _pair_score_base = 110.0
            _triple_score_base = 115.0
            for _i in range(len(_top)):
                for _j in range(_i + 1, len(_top)):
                    _combo = [_top[_i], _top[_j]]
                    _pred = _buildComboPredicate(_combo)
                    _new = _addPredicateToHead(_xpath, _pred)
                    _minscore = min(_combo, key=lambda _x: _x.stablescore).stablescore
                    _cands.append(
                        XpathCandidate(_new, self._scoreXpath(_new) + _minscore * _pair_score_base)
                    )
            if len(_top) >= 3:
                for _i in range(len(_top)):
                    for _j in range(_i + 1, len(_top)):
                        for _k in range(_j + 1, len(_top)):
                            _combo = [_top[_i], _top[_j], _top[_k]]
                            _pred = _buildComboPredicate(_combo)
                            _new = _addPredicateToHead(_xpath, _pred)
                            _minscore = min(_combo, key=lambda _x: _x.stablescore).stablescore
                            _cands.append(
                                XpathCandidate(
                                    _new, self._scoreXpath(_new) + _minscore * _triple_score_base
                                )
                            )

        # 5. position predicate - last resort, heavily penalized
        if _headTag(_xpath) != "*" and isinstance(_ancestor.tag, str):
            _parent = _ancestor.getparent()
            if _parent is not None:
                _pos = 1
                for _sib in _parent.iterchildren():
                    if not isinstance(_sib.tag, str):
                        continue
                    if _sib == _ancestor:
                        break
                    if _sib.tag.lower() == _ancestor.tag.lower():
                        _pos += 1
                _pred = f"[{_pos}]"
                _new = _addPredicateToHead(_xpath, _pred)
                _cands.append(XpathCandidate(_new, self._scoreXpath(_new) - POS_PENALTY))

        # 6. add ancestor level
        _anc_count = 0
        _tmp = _element
        while _tmp.getparent() is not None:
            _tmp = _tmp.getparent()
            _anc_count += 1
        if _level - 1 < _anc_count:
            _new = _addLevel(_xpath)
            _cands.append(XpathCandidate(_new, self._scoreXpath(_new) - 20.0))

        _seen = set()
        _out = []
        for _c in _cands:
            if _c.value not in _seen:
                _seen.add(_c.value)
                _out.append(_c)
        return _out

    def _enhanceBareTag(self, _xpath: str, _element: LxmlElement) -> str | None:
        if not _isBareTag(_xpath):
            return None
        _attrs = self._getAttrs(_element)
        _textinfo = self._getTextAttr(_element)
        # prefer high-stability single attributes
        for _a in _attrs:
            if _a.name in ("id", "data-testid", "data-qa", "data-cy"):
                _pred = _buildAttrPredicate(_a.name, _a.value)
                _new = _addPredicateToHead(_xpath, _pred)
                if self._isUnique(_new, _element):
                    return _new
        # try text
        if _textinfo:
            _pred = _buildAttrPredicate(_textinfo.name, _textinfo.value)
            _new = _addPredicateToHead(_xpath, _pred)
            if self._isUnique(_new, _element):
                return _new
        # try other single attributes
        for _a in _attrs:
            if _a.name == "class":
                for _tok in _a.value.split()[:2]:
                    _pred = f"[contains(@class,'{_tok}')]"
                    _new = _addPredicateToHead(_xpath, _pred)
                    if self._isUnique(_new, _element):
                        return _new
            else:
                _pred = _buildAttrPredicate(_a.name, _a.value)
                _new = _addPredicateToHead(_xpath, _pred)
                if self._isUnique(_new, _element):
                    return _new
        # try top combos
        _flat: list[AttrInfo] = []
        if _textinfo and _textinfo.stablescore > 0.15:
            _flat.append(_textinfo)
        for _a in _attrs:
            if _a.name == "class":
                for _tok in _a.value.split()[:2]:
                    _cp = AttrInfo("class", _tok)
                    _cp.stablescore = _a.stablescore
                    _cp.freq = _a.freq
                    _cp.uniqueness = _a.uniqueness
                    _flat.append(_cp)
            else:
                _flat.append(_a)
        _flat = [a for a in _flat if a.stablescore > 0.0]
        for _i in range(len(_flat)):
            for _j in range(_i + 1, len(_flat)):
                _pred = _buildComboPredicate([_flat[_i], _flat[_j]])
                _new = _addPredicateToHead(_xpath, _pred)
                if self._isUnique(_new, _element):
                    return _new
        return None

    def build(self, _element: LxmlElement) -> str:
        _queue: list[tuple[float, int, str]] = []
        _counter = 0
        heapq.heappush(_queue, (0.0, _counter, "//*"))
        _counter += 1
        _visited: set[str] = {"//*"}
        _fallback = "//*"

        while _queue:
            _, _, _xpath = heapq.heappop(_queue)
            if self._isUnique(_xpath, _element):
                _enhanced = self._enhanceBareTag(_xpath, _element)
                if _enhanced:
                    return _enhanced
                return _xpath

            _level = _getLength(_xpath)
            if _level > _getLength(_fallback) and _headTag(_xpath) != "*":
                _fallback = _xpath
            if _level > MAX_BFS_DEPTH:
                continue

            for _c in self._expand(_xpath, _element):
                if _c.value in _visited:
                    continue
                _visited.add(_c.value)
                heapq.heappush(_queue, (-_c.score, _counter, _c.value))
                _counter += 1

        if _fallback != "//*":
            return _fallback
        raise RuntimeError("pula: could not generate robust xpath")


# ---------- Public API ----------
def GenerateRobustXPath(_element: LxmlElement, _document: LxmlElement) -> str:
    _builder = PulaBuilder(_document)
    return _builder.build(_element)
