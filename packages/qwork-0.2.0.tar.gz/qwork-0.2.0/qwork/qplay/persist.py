"""
qplay persist module - Persistent WebPage with cross-interpreter singleton

Provides PersistPage class that maintains a visible browser instance across
interpreter sessions. Uses file-based locking for cross-process singleton
enforcement and heartbeat mechanism for liveness detection.

Key mechanism:
- Browser is launched as independent subprocess with --remote-debugging-port
- Playwright connects via CDP (connect_over_cdp)
- On cleanup, we disconnect (not close) from browser, leaving it running
- Next session reconnects to existing browser via saved CDP endpoint
"""

import ctypes

if sys.platform == "win32":
    import msvcrt
else:
    import fcntl

import os
import sys
import time
import json
import atexit
import signal
import threading
import tempfile
import subprocess
import socket
from pathlib import Path
from typing import Self, Any
from datetime import datetime, timezone
from contextlib import suppress

# Suppress Node.js deprecation warnings from Playwright
os.environ["NODE_OPTIONS"] = os.environ.get("NODE_OPTIONS", "") + " --no-warnings"

from playwright.sync_api import sync_playwright, Page, Browser
from qwork.qplay.play import WebPage, BROWSER_TYPE, Info

# Constants
HEARTBEAT_INTERVAL = 3  # seconds
HEARTBEAT_MISS_LIMIT = 3  # max missed heartbeats before disconnect
HEARTBEAT_TIMEOUT = HEARTBEAT_INTERVAL * HEARTBEAT_MISS_LIMIT

CDP_PORT_START = 9222
CDP_PORT_END = 9322

# State file paths (in temp directory for cross-platform compatibility)
PERSIST_DIR = Path(tempfile.gettempdir()) / "qwork_qplay_persist"
LOCK_FILE = PERSIST_DIR / "persist.lock"
STATE_FILE = PERSIST_DIR / "persist.state"


class PersistError(Exception):
    """Persistent page operation error."""
    pass


class PersistOccupiedError(PersistError):
    """Raised when another interpreter holds the persist instance."""
    pass


class PersistNoPortError(PersistError):
    """Raised when no available CDP port found."""
    pass


def _findAvailablePort(start: int = CDP_PORT_START, end: int = CDP_PORT_END) -> int | None:
    """Find an available port in range."""
    for port in range(start, end):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", port))
                return port
        except OSError:
            continue
    return None


def _isPortOpen(port: int) -> bool:
    """Check if a port is accepting connections."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            s.connect(("127.0.0.1", port))
            return True
    except (OSError, ConnectionRefusedError):
        return False


def _getChromePath() -> str | None:
    """Get Chrome/Chromium executable path."""
    # Check common paths
    if sys.platform == "win32":
        paths = [
            "C:/Program Files/Google/Chrome/Application/chrome.exe",
            "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
            os.path.expandvars("${LOCALAPPDATA}/Google/Chrome/Application/chrome.exe"),
            os.path.expandvars("${PROGRAMFILES}/Google/Chrome/Application/chrome.exe"),
        ]
    elif sys.platform == "darwin":
        paths = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
        ]
    else:
        paths = [
            "/usr/bin/google-chrome",
            "/usr/bin/chromium",
            "/usr/bin/chromium-browser",
            "/snap/bin/chromium",
        ]

    for path in paths:
        if path and os.path.exists(path):
            return path
    return None


class _PersistState:
    """Persistent state manager for cross-process coordination."""

    def __init__(self):
        self._lock = threading.Lock()
        PERSIST_DIR.mkdir(parents=True, exist_ok=True)

    def _read(self) -> dict:
        """Read current state from file."""
        try:
            if STATE_FILE.exists():
                with open(STATE_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return {}

    def _write(self, data: dict) -> None:
        """Atomically write state to file."""
        tmp_file = STATE_FILE.with_suffix(".tmp")
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(data, f)
        tmp_file.replace(STATE_FILE)

    def getBrowser(self) -> dict | None:
        """Get persistent browser info if it exists and is alive."""
        with self._lock:
            _state = self._read()
            _cdp_port = _state.get("cdp_port")
            _browserpid = _state.get("browserpid")

            if not _cdp_port:
                return None

            # Check if browser process is still alive
            if _browserpid and not self._isProcessAlive(_browserpid):
                # Browser is dead, clear state
                self._write({})
                return None

            # Also check if port is open
            if not _isPortOpen(_cdp_port):
                # Port not responding, clear state
                self._write({})
                return None

            return {
                "cdp_port": _cdp_port,
                "browserpid": _browserpid,
            }

    def getHolder(self) -> dict | None:
        """Get current holder info or None if free."""
        with self._lock:
            _state = self._read()
            _holder_pid = _state.get("holder_pid")

            if not _holder_pid:
                return None

            # Check if holder process is still alive
            if not self._isProcessAlive(_holder_pid):
                # Holder is dead, release ownership but keep browser
                _state["holder_pid"] = None
                _state["heartbeat"] = None
                self._write(_state)
                return None

            # Check heartbeat
            _lastbeat = _state.get("heartbeat", 0)
            if time.time() - _lastbeat > HEARTBEAT_TIMEOUT:
                # Heartbeat timeout, release ownership
                _state["holder_pid"] = None
                _state["heartbeat"] = None
                self._write(_state)
                return None

            return {
                "holder_pid": _holder_pid,
                "pid": _holder_pid,
                "heartbeat": _lastbeat,
                "starttime": _state.get("starttime"),
                "cdp_port": _state.get("cdp_port"),
                "browserpid": _state.get("browserpid"),
            }

    def acquire(self, holder_pid: int, cdp_port: int | None = None, browserpid: int | None = None) -> bool:
        """Acquire persist ownership. Creates or adopts browser. Returns True if successful."""
        with self._lock:
            _current_holder = self._getHolderPid()
            if _current_holder is not None and _current_holder != holder_pid:
                return False

            _state = self._read()
            _state["holder_pid"] = holder_pid
            _state["heartbeat"] = time.time()
            _state["starttime"] = datetime.now(timezone.utc).isoformat()
            if cdp_port is not None:
                _state["cdp_port"] = cdp_port
            if browserpid is not None:
                _state["browserpid"] = browserpid
            self._write(_state)
            return True

    def tryAcquire(self, holder_pid: int, browserpid: int | None = None) -> bool:
        """Backward compatibility alias for acquire."""
        return self.acquire(holder_pid, browserpid=browserpid)

    def updateHeartbeat(self, holder_pid: int) -> bool:
        """Update heartbeat timestamp. Returns False if no longer holder."""
        with self._lock:
            if self._getHolderPid() != holder_pid:
                return False
            _state = self._read()
            _state["heartbeat"] = time.time()
            self._write(_state)
            return True

    def release(self, holder_pid: int) -> bool:
        """Release persist ownership if held by given pid. Keeps browser running."""
        with self._lock:
            if self._getHolderPid() == holder_pid:
                _state = self._read()
                _state["holder_pid"] = None
                _state["heartbeat"] = None
                self._write(_state)
                return True
            return False

    def clear(self) -> None:
        """Clear all state (including browser info)."""
        with self._lock:
            self._write({})

    def _getHolderPid(self) -> int | None:
        """Get current holder PID without liveness check."""
        _state = self._read()
        return _state.get("holder_pid")

    @staticmethod
    def _isProcessAlive(pid: int) -> bool:
        """Check if a process is still running (cross-platform)."""
        if sys.platform == "win32":
            try:
                _kernel32 = ctypes.windll.kernel32
                _handle = _kernel32.OpenProcess(1, False, pid)
                if _handle:
                    _kernel32.CloseHandle(_handle)
                    return True
                return False
            except Exception:
                return False
        else:
            try:
                os.kill(pid, 0)
                return True
            except ProcessLookupError:
                return False


class _FileLock:
    """Cross-platform file lock for singleton enforcement."""

    def __init__(self, lockfile: Path):
        self._lockfile = lockfile
        self._fd = None

    def acquire(self, blocking: bool = False) -> bool:
        """Try to acquire file lock."""
        try:
            if sys.platform == "win32":
                return self._acquireWindows(blocking)
            else:
                return self._acquireUnix(blocking)
        except Exception:
            return False

    def release(self) -> None:
        """Release file lock."""
        try:
            if sys.platform == "win32":
                self._releaseWindows()
            else:
                self._releaseUnix()
        except Exception:
            pass

    def _acquireWindows(self, blocking: bool) -> bool:
        _mode = "w+" if not self._lockfile.exists() else "r+"
        try:
            self._fd = open(self._lockfile, _mode)
        except PermissionError:
            return False

        try:
            if blocking:
                msvcrt.locking(self._fd.fileno(), msvcrt.LK_LOCK, 1)
            else:
                msvcrt.locking(self._fd.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            self._fd.close()
            self._fd = None
            return False

        self._fd.seek(0)
        self._fd.truncate()
        self._fd.write(str(os.getpid()))
        self._fd.flush()
        return True

    def _releaseWindows(self) -> None:
        if self._fd:
            try:
                msvcrt.locking(self._fd.fileno(), msvcrt.LK_UNLCK, 1)
            except OSError:
                pass
            self._fd.close()
            self._fd = None

    def _acquireUnix(self, blocking: bool) -> bool:
        self._fd = open(self._lockfile, "w")
        try:
            _flags = fcntl.LOCK_EX
            if not blocking:
                _flags |= fcntl.LOCK_NB
            fcntl.flock(self._fd, _flags)
            self._fd.write(str(os.getpid()))
            self._fd.flush()
            return True
        except (IOError, OSError):
            self._fd.close()
            self._fd = None
            return False

    def _releaseUnix(self) -> None:
        if self._fd:
            fcntl.flock(self._fd, fcntl.LOCK_UN)
            self._fd.close()
            self._fd = None


class PersistPage(WebPage):
    """
    Persistent WebPage singleton with cross-interpreter locking.

    Maintains a visible browser instance that survives interpreter restarts.
    Only one interpreter can hold the PersistPage at a time.

    Features:
    - Browser runs as independent process (via CDP)
    - Disconnect on exit, reconnect on new session
    - Heartbeat mechanism for crash detection
    - Non-blocking acquisition (raises PersistOccupiedError if held)

    Usage:
        try:
            page = PersistPage()
            page.goto("https://example.com")
            # Browser stays open even after interpreter exits
        except PersistOccupiedError:
            print("Another interpreter holds the persistent page")

        # Later, in new interpreter session:
        page = PersistPage()  # Reconnects to existing browser
    """

    _instance: "PersistPage | None" = None
    _initialized: bool = False
    _singleton_lock: threading.Lock = threading.Lock()
    _lock: _FileLock | None = None
    _state: _PersistState | None = None
    _heartbeat_thread: threading.Thread | None = None
    _stop_heartbeat: threading.Event | None = None
    _own_pid: int = 0

    # Playwright objects
    _playwright: Any = None
    _cdp_port: int | None = None
    _browserpid: int | None = None

    def __new__(cls, *args, **kwargs) -> "PersistPage":
        if cls._instance is None:
            with cls._singleton_lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(
        self,
        browsertype: BROWSER_TYPE = "chromium",
        headless: bool = False,
    ):
        with PersistPage._singleton_lock:
            # Prevent re-initialization
            if PersistPage._initialized:
                return

        # Initialize state manager
        if PersistPage._state is None:
            PersistPage._state = _PersistState()

        self._own_pid = os.getpid()

        # Try to acquire file lock (non-blocking)
        if PersistPage._lock is None:
            PersistPage._lock = _FileLock(LOCK_FILE)

        if not PersistPage._lock.acquire(blocking=False):
            _holder = PersistPage._state.getHolder()
            if _holder:
                raise PersistOccupiedError(
                    f"PersistPage is held by PID {_holder['holder_pid']} "
                    f"(started at {_holder.get('starttime', 'unknown')})"
                )
            PersistPage._lock.release()
            if not PersistPage._lock.acquire(blocking=False):
                raise PersistOccupiedError("Unable to acquire PersistPage lock")

        # Check if we should reconnect to existing browser or create new
        # First check for existing browser (separate from holder)
        _existing_browser = PersistPage._state.getBrowser()
        _existing_holder = PersistPage._state.getHolder()

        # Initialize WebPage attributes
        self._browsertype: BROWSER_TYPE = browsertype
        self._headless = headless
        self._host: "WebPage | None" = None
        self._root_host: "WebPage | None" = None
        self._browser: Browser | None = None
        self._page: Page | None = None
        self._ownbrowser = True
        self._is_parasitic = False
        self._browser_source = "persist"

        # Initialize playwright
        self._playwright = sync_playwright().start()

        if _existing_browser:
            # Try to reconnect to existing browser
            _port = _existing_browser["cdp_port"]
            if _isPortOpen(_port):
                self._reconnect(_port)
                # Try to get browser PID from state if available
                self._browserpid = _existing_browser.get("browserpid")
                Info("persist", "reconnected to existing browser", f"port={_port}")
            else:
                # Port not responding, create new browser
                self._launch()
                Info("persist", "created new browser (old one dead)")
        else:
            # No existing browser, create new
            self._launch()
            Info("persist", "created new persistent browser")

        # Acquire ownership (mark as holder in state)
        PersistPage._state.acquire(self._own_pid, self._cdp_port, self._browserpid)

        # Start heartbeat thread
        self._startHeartbeat()

        # Register cleanup handlers
        atexit.register(self._cleanup)
        self._setupSignalHandlers()

        # Call Element init with page root
        super(WebPage, self).__init__(self._page.locator("html"), self)

        PersistPage._initialized = True
        Info("persist", "initialized", f"pid={self._own_pid}, port={self._cdp_port}")

    def _launch(self) -> None:
        """Launch browser as independent subprocess with CDP port."""
        # Find available port
        _port = _findAvailablePort()
        if _port is None:
            raise PersistNoPortError(f"No available CDP port in range {CDP_PORT_START}-{CDP_PORT_END}")

        self._cdp_port = _port

        # Get Chrome/Chromium path
        _chrome_path = _getChromePath()
        if not _chrome_path:
            raise PersistError("Chrome/Chromium not found. Please install Chrome.")

        # Launch browser as subprocess (not managed by Playwright)
        _user_data_dir = PERSIST_DIR / f"chrome_profile_{_port}"
        _user_data_dir.mkdir(parents=True, exist_ok=True)

        _args = [
            _chrome_path,
            f"--remote-debugging-port={_port}",
            f"--user-data-dir={_user_data_dir}",
            "--no-first-run",
            "--no-default-browser-check",
        ]

        if self._headless:
            _args.append("--headless=new")

        # Start browser process independently
        if sys.platform == "win32":
            _creationflags = subprocess.CREATE_NEW_PROCESS_GROUP
            _browser_proc = subprocess.Popen(
                _args,
                creationflags=_creationflags,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            _browser_proc = subprocess.Popen(
                _args,
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

        self._browserpid = _browser_proc.pid

        # Wait for CDP to be ready
        _max_wait = 30  # seconds
        _start_time = time.time()
        while time.time() - _start_time < _max_wait:
            if _isPortOpen(_port):
                break
            time.sleep(0.1)
        else:
            raise PersistError(f"Browser did not start on port {_port} within {_max_wait}s")

        # Connect via CDP
        self._reconnect(_port)

    def _reconnect(self, port: int) -> None:
        """Connect to existing browser via CDP."""
        self._cdp_port = port
        _endpoint = f"http://127.0.0.1:{port}"

        try:
            self._browser = self._playwright.chromium.connect_over_cdp(_endpoint)
            # Create or get page
            _context = self._browser.contexts[0] if self._browser.contexts else self._browser.new_context()
            self._page = _context.pages[0] if _context.pages else _context.new_page()
        except Exception as _e:
            raise PersistError(f"Failed to connect to browser at {_endpoint}") from _e

    def _startHeartbeat(self) -> None:
        """Start heartbeat monitoring thread."""
        PersistPage._stop_heartbeat = threading.Event()

        def _heartbeatLoop():
            while PersistPage._stop_heartbeat and not PersistPage._stop_heartbeat.is_set():
                if PersistPage._state:
                    if not PersistPage._state.updateHeartbeat(self._own_pid):
                        Info("persist", "lost ownership, stopping heartbeat")
                        break
                if PersistPage._stop_heartbeat:
                    PersistPage._stop_heartbeat.wait(HEARTBEAT_INTERVAL)

        PersistPage._heartbeat_thread = threading.Thread(
            target=_heartbeatLoop,
            daemon=True,
            name="PersistHeartbeat"
        )
        PersistPage._heartbeat_thread.start()
        Info("persist", "heartbeat started")

    def _setupSignalHandlers(self) -> None:
        """Setup signal handlers for graceful shutdown."""
        def _signalHandler(signum, frame):
            Info("persist", f"received signal {signum}, cleaning up")
            self._cleanup()
            signal.default_int_handler(signum, frame)

        with suppress(ValueError):
            signal.signal(signal.SIGTERM, _signalHandler)
        with suppress(ValueError):
            signal.signal(signal.SIGINT, _signalHandler)

    def _cleanup(self) -> None:
        """Cleanup resources on interpreter exit - disconnect but don't close browser."""
        if not PersistPage._initialized:
            return

        Info("persist", "cleanup started - disconnecting from browser")

        # Stop heartbeat
        if PersistPage._stop_heartbeat:
            PersistPage._stop_heartbeat.set()
            PersistPage._stop_heartbeat = None

        if PersistPage._heartbeat_thread:
            PersistPage._heartbeat_thread.join(timeout=1)
            PersistPage._heartbeat_thread = None

        # Release state ownership
        if PersistPage._state:
            PersistPage._state.release(self._own_pid)

        # Release file lock
        if PersistPage._lock:
            PersistPage._lock.release()
            PersistPage._lock = None

        # Disconnect from browser (don't close it!)
        # This allows the browser to keep running independently
        if self._browser:
            try:
                # Use disconnect() not close() - browser keeps running
                self._browser.disconnect()
                Info("persist", f"disconnected from browser on port {self._cdp_port}")
            except Exception:
                pass
            self._browser = None

        if self._page:
            self._page = None

        # Stop playwright
        if self._playwright:
            try:
                self._playwright.stop()
            except Exception:
                pass
            self._playwright = None

        PersistPage._initialized = False
        PersistPage._instance = None
        Info("persist", "cleanup complete - browser persists")

    def close(self) -> None:
        """
        Override close to prevent browser termination.

        PersistPage browser survives close(). Use forceClose() to actually close.
        """
        Info("persist", "close() called - browser persists (use forceClose() to terminate)")

    def forceClose(self) -> None:
        """Force close the persistent browser and kill the process."""
        Info("persist", "forceClose() called - terminating browser")

        # Stop heartbeat first
        if PersistPage._stop_heartbeat:
            PersistPage._stop_heartbeat.set()
            PersistPage._stop_heartbeat = None

        if PersistPage._heartbeat_thread:
            PersistPage._heartbeat_thread.join(timeout=1)
            PersistPage._heartbeat_thread = None

        # Release ownership
        if PersistPage._state:
            PersistPage._state.release(self._own_pid)

        # Close page and browser
        if self._page:
            try:
                self._page.close()
            except Exception:
                pass
            self._page = None

        if self._browser:
            try:
                self._browser.close()
            except Exception:
                pass
            self._browser = None

        # Kill browser process if still running
        if self._browserpid:
            try:
                if PersistPage._state._isProcessAlive(self._browserpid):
                    if sys.platform == "win32":
                        _kernel32 = ctypes.windll.kernel32
                        _handle = _kernel32.OpenProcess(1, False, self._browserpid)
                        if _handle:
                            _kernel32.TerminateProcess(_handle, 0)
                            _kernel32.CloseHandle(_handle)
                    else:
                        os.kill(self._browserpid, signal.SIGTERM)
                        time.sleep(0.5)
                        if PersistPage._state._isProcessAlive(self._browserpid):
                            os.kill(self._browserpid, signal.SIGKILL)
            except Exception:
                pass
            self._browserpid = None

        # Cleanup
        self._cleanup()

    @classmethod
    def isAvailable(cls) -> bool:
        """Check if PersistPage is available (not held by another interpreter)."""
        if cls._initialized:
            return True

        _state = _PersistState()
        _holder = _state.getHolder()
        return _holder is None

    @classmethod
    def getHolderInfo(cls) -> dict | None:
        """Get information about current holder, if any."""
        _state = _PersistState()
        return _state.getHolder()

    @classmethod
    def releaseStale(cls) -> bool:
        """Force release stale lock if holder is dead. Returns True if released."""
        _state = _PersistState()
        _holder = _state.getHolder()
        if _holder is None:
            try:
                LOCK_FILE.unlink(missing_ok=True)
                return True
            except Exception:
                return False
        return False

    @classmethod
    def killBrowser(cls) -> bool:
        """Kill the persistent browser process if it exists."""
        _state = _PersistState()
        _browser = _state.getBrowser()

        if _browser and _browser.get("browserpid"):
            _pid = _browser["browserpid"]
            try:
                if _state._isProcessAlive(_pid):
                    if sys.platform == "win32":
                        _kernel32 = ctypes.windll.kernel32
                        _handle = _kernel32.OpenProcess(1, False, _pid)
                        if _handle:
                            _kernel32.TerminateProcess(_handle, 0)
                            _kernel32.CloseHandle(_handle)
                    else:
                        os.kill(_pid, signal.SIGTERM)
                        time.sleep(0.5)
                        if _state._isProcessAlive(_pid):
                            os.kill(_pid, signal.SIGKILL)

                # Clear all state including browser
                _state.clear()
                return True
            except Exception:
                pass
        return False

    @classmethod
    def getBrowserInfo(cls) -> dict | None:
        """Get information about persistent browser, if it exists."""
        _state = _PersistState()
        return _state.getBrowser()


__all__ = [
    "PersistPage",
    "PersistError",
    "PersistOccupiedError",
    "PersistNoPortError",
    "getBrowserInfo",
]
