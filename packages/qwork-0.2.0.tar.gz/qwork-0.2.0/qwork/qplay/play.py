"""
qplay play module - Playwright-based WebPage and Element implementation

Provides synchronous WebPage (page driver) and Element (element wrapper) classes
using Playwright's sync API. Integrates with identylib for macro-based identity resolution.

Browser management:
- Shared playwright instance across all WebPage instances
- Default: share browser, create new page
- newbrowser=True: create new browser instance with new page
"""

from lxml.etree import parse, HTMLParser, QName
from io import StringIO


import time
from typing import Self, Any, Literal

import imageio
import numpy as np
from playwright.sync_api import Playwright, sync_playwright, Page, Browser, Locator

from qwork.qplay.identylib import Resolve
from qwork.qplay.stdio import Info
from qwork.qplay.interface import IElement, IWebPage, IWebTable
from qwork.qplay import pula
from qwork.qplay.ptable import WebTable

BROWSER_TYPE = Literal["chromium", "firefox", "webkit"]


def Sleep(ms: int | None) -> None:
    """Sleep for milliseconds if value is provided and positive."""
    if ms and ms > 0:
        time.sleep(ms / 1000)


def ResolveIdent(identity: str) -> str:
    """Resolve identity using identylib (handles @macros and xpath)."""
    return Resolve(identity)


def _Isidentity(identity: str) -> bool:
    _s = identity.strip()
    _n = len(_s)
    if _s.startswith("//") and _n >= 3:
        return True
    if _s.startswith("$") and _n >= 2:
        return True
    if _s.startswith("@") and _n >= 2:
        return True
    return False


class _BrowserManager:
    """
    Shared browser manager for WebPage instances.

    Manages singleton playwright instance and shared browser.
    """

    _playwright: Playwright | None = None
    _sharedbrowser: Browser | None = None
    _headless: bool = False
    _browsertype: str = "chromium"
    _refcount: int = 0

    @classmethod
    def getPlaywright(cls) -> Playwright:
        """Get or create shared playwright instance."""
        if cls._playwright is None:
            cls._playwright = sync_playwright().start()
            Info("play", "playwright initialized")
        return cls._playwright

    @classmethod
    def getSharedBrowser(cls, headless: bool = False, browsertype: BROWSER_TYPE = "chromium") -> Browser:
        """Get or create shared browser instance."""
        cls._headless = headless
        cls._browsertype = browsertype

        if cls._sharedbrowser is None:
            pw = cls.getPlaywright()
            launcher = getattr(pw, browsertype)
            cls._sharedbrowser = launcher.launch(headless=headless)
            Info("play", "shared browser launched", browsertype)

        return cls._sharedbrowser

    @classmethod
    def newBrowser(cls, headless: bool = False, browsertype: BROWSER_TYPE = "chromium") -> Browser:
        """Create new standalone browser instance."""
        pw = cls.getPlaywright()
        launcher = getattr(pw, browsertype)
        Info("play", "new browser launched", browsertype)
        return launcher.launch(headless=headless)

    @classmethod
    def addRef(cls) -> None:
        """Increment reference count."""
        cls._refcount += 1

    @classmethod
    def decRef(cls) -> None:
        """Decrement reference count and cleanup if zero."""
        cls._refcount -= 1
        if cls._refcount <= 0:
            cls._cleanup()

    @classmethod
    def _cleanup(cls) -> None:
        """Cleanup all browser resources."""
        if cls._sharedbrowser:
            cls._sharedbrowser.close()
            cls._sharedbrowser = None
            Info("play", "shared browser closed")

        if cls._playwright:
            cls._playwright.stop()
            cls._playwright = None
            Info("play", "playwright stopped")

        cls._refcount = 0


class Element:
    """
    Element wrapper using Playwright Locator.

    Provides element-level operations like click, type, and child element searching.
    """

    def __init__(self, locator: Locator, webpage: IWebPage, _xpath: str | None = None):
        self._locator = locator
        self._webpage = webpage
        self._xpath = _xpath
        self._xpath_optimized = False

    def __repr__(self) -> str:
        return self.__str__()

    def __str__(self) -> str:
        try:
            _info = self._locator.evaluate("""el => {
                const _tag = el.tagName.toLowerCase();
                const _id = el.id || '';
                const _cls = (typeof el.className === 'string') ? el.className : '';
                let _text = '';
                if (el.innerText !== undefined) {
                    _text = el.innerText.replace(/\\s+/g, ' ').trim().slice(0, 40);
                } else if (el.textContent) {
                    _text = el.textContent.replace(/\\s+/g, ' ').trim().slice(0, 40);
                }
                return {_tag, _id, _cls, _text};
            }""")
            _parts = [f"<{_info['_tag']}>"]
            if _info['_id']:
                _parts.append(f"id={_info['_id']!r}")
            if _info['_cls']:
                _parts.append(f"class={_info['_cls']!r}")
            if _info['_text']:
                _parts.append(f"text={_info['_text']!r}")
            return f'<Element({" ".join(_parts)})>'
        except Exception:
            return '<Element(detached)>'

    @property
    def tag_name(self) -> str:
        """元素标签名。"""
        return self._locator.evaluate("el => el.tagName.toLowerCase()")

    @property
    def text(self) -> str:
        """元素文本内容。"""
        return self._locator.inner_text()

    @property
    def id(self) -> str:
        """元素内部 ID。"""
        return self._locator.get_attribute("id") or ""

    @property
    def value(self) -> str | None:
        """元素 value 属性。"""
        return self._locator.input_value()

    @property
    def size(self) -> dict:
        """元素尺寸 (width, height)。"""
        box = self._locator.bounding_box()
        if box:
            return {"width": box["width"], "height": box["height"]}
        return {"width": 0, "height": 0}

    @property
    def rect(self) -> dict:
        """元素矩形 (尺寸和位置)。"""
        box = self._locator.bounding_box()
        if box:
            return {
                "x": box["x"],
                "y": box["y"],
                "width": box["width"],
                "height": box["height"]
            }
        return {"x": 0, "y": 0, "width": 0, "height": 0}

    @property
    def xpath(self) -> str:
        """元素xpath。"""
        if self._xpath_optimized:
            return self._xpath
        self._xpath = self._computeRobulaXPath()
        self._xpath_optimized = True
        return self._xpath

    def _getDomPath(self) -> list[dict]:
        """Get element's DOM path via browser JS evaluation."""
        return self._locator.evaluate("""el => {
            const getText = e => {
                let t = '';
                for (const node of e.childNodes) {
                    if (node.nodeType === Node.TEXT_NODE) t += node.textContent;
                }
                return t.trim();
            };
            const path = [];
            while (el) {
                let idx = 1;
                let sibling = el.previousElementSibling;
                while (sibling) {
                    if (sibling.tagName === el.tagName) idx++;
                    sibling = sibling.previousElementSibling;
                }
                path.unshift({
                    tag: el.tagName.toLowerCase(),
                    idx: idx,
                    id: el.id || '',
                    cls: el.getAttribute('class') || '',
                    text: (el.textContent || '').replace(/\\s+/g, ' ').trim().substring(0, 60),
                    d: el.tagName.toLowerCase() === 'path' ? (el.getAttribute('d') || '') : ''
                });
                el = el.parentElement;
            }
            return path;
        }""")

    def _getBrowserFingerprint(self) -> dict:
        """Get element fingerprint from browser for lxml matching fallback."""
        return self._locator.evaluate("""el => {
            const getText = e => {
                let t = '';
                for (const node of e.childNodes) {
                    if (node.nodeType === Node.TEXT_NODE) t += node.textContent;
                }
                return t.trim();
            };
            return {
                tag: el.tagName.toLowerCase(),
                id: el.id || '',
                cls: el.getAttribute('class') || '',
                text: getText(el),
                href: el.getAttribute('href') || '',
                src: el.getAttribute('src') || '',
                d: el.getAttribute('d') || ''
            };
        }""")

    def _computeRobulaXPath(self) -> str:
        """Compute robust xpath using pula algorithm."""

        _html = self._webpage.html
        _parser = HTMLParser()
        _document = parse(StringIO(_html), parser=_parser)
        _root = _document.getroot()

        _path = self._getDomPath()
        if not _path:
            raise RuntimeError("pula: empty DOM path")

        def _localTag(_el):
            _t = _el.tag
            if not isinstance(_t, str):
                return None
            if _t.startswith("{"):
                return QName(_t).localname.lower()
            return _t.lower()

        def _scoreNode(_node, _item):
            _s = 0.0
            if _item.get("id") and _node.get("id") == _item["id"]:
                _s += 100.0
            _ccls = (_node.get("class") or "").strip()
            _fcls = _item.get("cls", "").strip()
            if _ccls and _fcls:
                _common = len(set(_ccls.split()) & set(_fcls.split()))
                if _common:
                    _s += 10.0 * _common
            _ctext = ("".join(_node.itertext())).strip()
            _ftext = _item.get("text", "").strip()
            if _ctext and _ftext and _ctext == _ftext:
                _s += 50.0
            elif _ctext and _ftext and _ctext.startswith(_ftext):
                _s += 20.0
            if _item.get("d") and _localTag(_node) == "path":
                _cd = _node.get("d") or ""
                _fd = _item["d"]
                if _cd and _fd and _cd == _fd:
                    _s += 200.0
            return _s

        def _fuzzyWalk():
            _node = _root
            for _item in _path[1:]:
                _candidates = [c for c in _node.getchildren() if _localTag(c) == _item["tag"]]
                if not _candidates:
                    # structural divergence: look deeper
                    _candidates = [c for c in _node.iter() if c is not _node and _localTag(c) == _item["tag"]]
                    if not _candidates:
                        return None
                _scored = []
                for _candIdx, _c in enumerate(_candidates):
                    _match = _scoreNode(_c, _item)
                    _penalty = abs((_candIdx + 1) - _item["idx"]) * 2.0
                    _scored.append((_match - _penalty, _c))
                _scored.sort(key=lambda x: -x[0])
                _node = _scored[0][1]
            return _node

        _node = _fuzzyWalk()
        if _node is not None:
            return pula.GenerateRobustXPath(_node, _root)

        # Last-resort global leaf fingerprint (handles extreme divergence)
        _fp = self._getBrowserFingerprint()
        _targetTag = _fp.get("tag", "")
        _best: tuple[float, any] = (-1.0, None)

        for _candidate in _root.iter():
            if _localTag(_candidate) != _targetTag:
                continue
            _score = 0.0
            if (_candidate.get("id") or "") == _fp.get("id", "") and _fp.get("id"):
                _score += 10.0
            _ccls = (_candidate.get("class") or "").strip()
            _fcls = _fp.get("cls", "").strip()
            if _ccls and _fcls:
                _ctoks = set(_ccls.split())
                _ftoks = set(_fcls.split())
                _common = _ctoks & _ftoks
                if _common:
                    _score += 5.0 * (len(_common) / max(len(_ctoks), len(_ftoks)))
            _ctext = ("".join(_candidate.itertext())).strip()
            _ftext = _fp.get("text", "").strip()
            if _ctext and _ftext and _ctext == _ftext:
                _score += 5.0
            elif _ctext and _ftext and _ctext.startswith(_ftext):
                _score += 2.5
            if (_candidate.get("href") or "") == _fp.get("href", "") and _fp.get("href"):
                _score += 3.0
            if (_candidate.get("src") or "") == _fp.get("src", "") and _fp.get("src"):
                _score += 3.0
            if (_candidate.get("d") or "") == _fp.get("d", "") and _fp.get("d"):
                _score += 15.0
            if _score > _best[0]:
                _best = (_score, _candidate)

        if _best[1] is None or _best[0] <= 0:
            raise RuntimeError(f"pula: DOM path mismatch and fingerprint fallback failed for tag '{_targetTag}'")

        return pula.GenerateRobustXPath(_best[1], _root)

    @property
    def parent(self) -> IElement | None:
        """元素父节点。"""
        try:
            parent_locator = self._locator.locator("xpath=..")
            return Element(parent_locator, self._webpage)
        except Exception:
            return None

    @property
    def children(self) -> list[IElement]:
        """元素子节点。"""
        try:
            # Use CSS selector for direct children
            children_locators = self._locator.locator("> *").all()
            return [Element(loc, self._webpage) for loc in children_locators]
        except Exception:
            return []

    @property
    def backend(self) -> Locator:
        """元素后端。"""
        return self._locator

    def geta(self, attr_name: str) -> Any:
        """获取自身的某个attr，例如'class' 'id'。"""
        return self._locator.get_attribute(attr_name)

    def hasa(self, attr_name: str) -> bool:
        """判断自身是否有某个attr，例如'class' 'id'。"""
        try:
            result = self._locator.evaluate(f"el => el.hasAttribute('{attr_name}')")
            return bool(result)
        except Exception:
            return False

    def lista(self) -> list[str]:
        """检索目标的所有attr字段。"""
        attrs = self._locator.evaluate("el => Array.from(el.attributes).map(a => a.name)")
        return attrs if attrs else []

    def _getTargetLocator(self, identity: str | None = None) -> Locator:
        """Get target locator - self or child element."""
        if identity is None:
            return self._locator
        _xpath = ResolveIdent(identity)
        return self._locator.locator(f"xpath={_xpath}")

    def seek(self, identity: str, *, error: bool = True, pre: int | None = None, after: int | None = None) -> IElement | None:
        """查找单个元素。"""
        Sleep(pre)
        try:
            _xpath = ResolveIdent(identity)
            _locator = self._locator.locator(f"xpath={_xpath}").first
            # Force evaluation to check existence
            _locator.wait_for(state="attached", timeout=1000)
            Sleep(after)
            _composed = (self._xpath + _xpath) if self._xpath is not None else _xpath
            return Element(_locator, self._webpage, _xpath=_composed)
        except Exception as _e:
            Sleep(after)
            if error:
                raise RuntimeError(f"Element not found: {identity}") from _e
            return None

    def seeks(self, identity: str, *, pre: int | None = None, after: int | None = None) -> list[IElement]:
        """查找多个元素。"""
        Sleep(pre)
        _xpath = ResolveIdent(identity)
        _locators = self._locator.locator(f"xpath={_xpath}").all()
        Sleep(after)
        _composed = (self._xpath + _xpath) if self._xpath is not None else _xpath
        return [Element(_loc, self._webpage, _xpath=_composed) for _loc in _locators]

    def wait(self, identity: str, waitlimit: int = 10000, *, error: bool = True, pre: int | None = None, after: int | None = None) -> IElement | None:
        """等待元素存在。"""
        Sleep(pre)
        try:
            _xpath = ResolveIdent(identity)
            _locator = self._locator.locator(f"xpath={_xpath}").first
            _locator.wait_for(state="attached", timeout=waitlimit)
            Sleep(after)
            _composed = (self._xpath + _xpath) if self._xpath is not None else _xpath
            return Element(_locator, self._webpage, _xpath=_composed)
        except Exception as _e:
            Sleep(after)
            if error:
                raise TimeoutError(f"Wait timeout for element: {identity}") from _e
            return None

    def waits(self, identity: str, waitlimit: int = 10000, *, pre: int | None = None, after: int | None = None) -> list[IElement]:
        """等待多个元素存在。"""
        Sleep(pre)
        _xpath = ResolveIdent(identity)
        _locator = self._locator.locator(f"xpath={_xpath}")
        try:
            # Wait for at least one element
            _locator.first.wait_for(state="attached", timeout=waitlimit)
        except Exception:
            pass
        _locators = _locator.all()
        Sleep(after)
        _composed = (self._xpath + _xpath) if self._xpath is not None else _xpath
        return [Element(_loc, self._webpage, _xpath=_composed) for _loc in _locators]

    def test(self, identity: str, *, pre: int | None = 0, after: int | None = 0) -> bool:
        """测试元素是否存在 (非阻塞)。"""
        Sleep(pre)
        try:
            _xpath = ResolveIdent(identity)
            _count = self._locator.locator(f"xpath={_xpath}").count()
            Sleep(after)
            return _count > 0
        except Exception:
            Sleep(after)
            return False

    def click(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """左键点击元素。"""
        Sleep(pre)
        _target = self._getTargetLocator(identity)
        _target.click(timeout=limit)
        Sleep(after)
        return self

    def typing(self, identity: str, *keys: str, clear: bool = True, pre: int | None = None, after: int | None = None) -> Self:
        """在元素中输入文本。"""
        Sleep(pre)
        if _Isidentity(identity):
            _xpath = ResolveIdent(identity)
            _target = self._locator.locator(f"xpath={_xpath}")
        else:
            _target = self._locator
            keys = (identity,) + keys
        if clear:
            _target.fill("")
        if keys:
            _target.type("".join(keys))
        Sleep(after)
        return self

    def hold(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """在元素上按住鼠标左键。"""
        Sleep(pre)
        _target = self._getTargetLocator(identity)
        _target.hover(timeout=limit)
        self._webpage.backend.mouse.down()
        Sleep(after)
        return self

    def release(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """释放鼠标按钮。"""
        Sleep(pre)
        if identity:
            _xpath = ResolveIdent(identity)
            _target = self._locator.locator(f"xpath={_xpath}")
            _target.hover(timeout=limit)
        self._webpage.backend.mouse.up()
        Sleep(after)
        return self

    def doubleClick(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """双击元素。"""
        Sleep(pre)
        _target = self._getTargetLocator(identity)
        _target.dblclick(timeout=limit)
        Sleep(after)
        return self

    def rClick(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """右键点击元素。"""
        Sleep(pre)
        _target = self._getTargetLocator(identity)
        _target.click(button="right", timeout=limit)
        Sleep(after)
        return self

    def mClick(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """中键点击元素。"""
        Sleep(pre)
        _target = self._getTargetLocator(identity)
        _target.click(button="middle", timeout=limit)
        Sleep(after)
        return self

    def screenshot(self, path: str | None = None, *, toimage: bool = True) -> Any | None:
        """截图。

        Args:
            path: 保存路径，None 则不保存到文件
            toimage: True 返回 numpy.ndarray，False 返回原始 bytes

        Returns:
            numpy.ndarray 或 bytes 图像数据，失败时返回 None
        """
        try:
            _data = self._locator.screenshot(path=path)
            if toimage:
                return imageio.imread(_data)
            return _data
        except Exception:
            return None

    def table(self, identity: str | None = None, *, waitlimit: int = 10000, pre: int | None = None, after: int | None = None) -> IWebTable:
        """
        获取表格包装器 WebTable。

        Args:
            identity: 表格元素标识符 (xpath, @id, $macro)。
                     None 表示将自身作为表格元素
            waitlimit: 等待超时（毫秒），仅当指定 identity 时有效
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            WebTable 实例
        """

        Sleep(pre)
        if identity is None:
            # Use self as table element
            Sleep(after)
            return WebTable(self)

        # Wait for table element and wrap it
        _elem = self.wait(identity, waitlimit, pre=None, after=after)
        if _elem is None:
            raise RuntimeError(f"Table element not found: {identity}")
        return WebTable(_elem)


class WebPage(Element):
    """
    WebPage driver using Playwright.

    Inherits from Element to provide element-level operations on the page root,
    while adding page-level operations like navigation.

    Browser management:
    - Default (None): share browser, auto-create if not exists
    - True: new browser with default type
    - False: must share, raise if no shared browser
    - str: new browser with specified type ("chromium"|"firefox"|"webkit")
    - WebPage: parasitic mode on host's browser
    - Browser: parasitic mode on standalone browser instance

    Usage:
        # Share browser (default), auto-create if not exists
        page1 = WebPage()
        page2 = WebPage()  # same browser, new page

        # New browser instance
        page3 = WebPage(True)  # new browser, default type
        page4 = WebPage("firefox")  # new firefox browser
        page5 = WebPage(True, headless=True)  # new browser, headless mode

        # Must share, raise if no shared browser
        page6 = WebPage(False)  # RuntimeError if no shared browser

        # Parasitic pages
        pageB = WebPage(pageA)  # B parasitic on A
        pageC = WebPage(pageB)  # C parasitic on B

        # Parasitic on standalone Browser
        pageD = WebPage(browser_instance)
    """

    def __init__(
        self,
        browser: bool | str | IWebPage | Browser | None = None,
        headless: bool | None = None,
    ):
        self._browsertype: BROWSER_TYPE = "chromium"
        self._headless: bool = headless or False
        self._host: IWebPage | None = None
        self._root_host: IWebPage | None = None
        self._browser: Browser | None = None
        self._page: Page | None = None
        self._ownbrowser = False
        self._is_parasitic = False
        self._browser_source: str = ""

        # Parse browser parameter
        if browser is None:
            self._launchShared(auto_create=True)
        elif browser is True:
            self._launchNew()
        elif browser is False:
            self._launchShared(auto_create=False)
        elif isinstance(browser, str):
            self._browsertype = browser  # type: ignore
            self._launchNew()
        elif isinstance(browser, IWebPage):
            self._launchParasitic(browser)
        elif isinstance(browser, Browser):
            self._launchParasiticBrowser(browser)
        else:
            raise TypeError(f"Invalid browser type: {type(browser).__name__}")

        super().__init__(self._page.locator("html"), self, _xpath="/html")

    def _launchNew(self) -> None:
        """Launch new standalone browser."""
        self._browser = _BrowserManager.newBrowser(self._headless, self._browsertype)
        self._ownbrowser = True
        self._page = self._browser.new_page()
        self._browser_source = "new"
        Info("play", "new browser created", f"type={self._browsertype}, headless={self._headless}")

    def _launchShared(self, auto_create: bool) -> None:
        """Launch using shared browser.

        Args:
            auto_create: If True, create shared browser if not exists.
                        If False, raise RuntimeError if no shared browser.
        """
        if not auto_create and _BrowserManager._sharedbrowser is None:
            raise RuntimeError(
                "No shared browser available. "
                "Call WebPage(False) only when a shared browser already exists. "
                "Use WebPage() or WebPage(None) to auto-create shared browser."
            )

        self._browser = _BrowserManager.getSharedBrowser(self._headless, self._browsertype)
        _BrowserManager.addRef()
        self._page = self._browser.new_page()
        self._browser_source = "shared"
        Info("play", "shared browser page created")

    def _launchParasitic(self, host: IWebPage) -> None:
        """Launch parasitic mode on WebPage host."""
        self._host = host
        self._is_parasitic = True
        self._root_host = host._findRootHost()
        self._browser = self._root_host._browser
        self._page = self._browser.new_page()
        self._browser_source = "parasitic"
        Info("play", "parasitic page created", f"host={id(host)}, root={id(self._root_host)}")

    def _launchParasiticBrowser(self, browser: Browser) -> None:
        """Launch parasitic mode on standalone Browser instance."""
        self._browser = browser
        self._is_parasitic = True
        self._page = browser.new_page()
        self._browser_source = "parasitic_browser"
        Info("play", "parasitic page created on standalone browser")

    def _findRootHost(self) -> IWebPage:
        """Find the root host that owns the browser."""
        _host = getattr(self, '_host', None)
        if _host is None:
            return self
        return _host._findRootHost()

    @property
    def browser(self) -> Browser | None:
        """Browser instance for this page."""
        return self._browser

    @property
    def host(self) -> IWebPage | None:
        """Host page if parasitic, None otherwise."""
        return self._host

    @property
    def rootHost(self) -> IWebPage | None:
        """Root host that owns the browser."""
        return self._root_host

    @property
    def isParasitic(self) -> bool:
        """Whether this page is parasitic on another page."""
        return self._is_parasitic

    @property
    def isHeadless(self) -> bool:
        """Whether the browser is headless (only valid for new browser mode)."""
        return self._headless

    @property
    def browserType(self) -> str:
        """Browser type (chromium, firefox, webkit)."""
        return self._browsertype

    @property
    def browserSource(self) -> str:
        """Browser source: 'new', 'shared', 'parasitic', 'parasitic_browser'."""
        return self._browser_source

    @property
    def newbrowser(self) -> bool:
        """Backward compatibility: True if created with new browser."""
        return self._browser_source == "new"

    @property
    def backend(self) -> Page:
        """Page backend for driver-level operations."""
        return self._page

    @property
    def title(self) -> str:
        """当前页面标题。"""
        return self._page.title()

    @property
    def url(self) -> str:
        """当前页面 URL。"""
        return self._page.url

    @url.setter
    def url(self, url: str) -> None:
        """跳转到url。"""
        self._page.goto(url)

    @property
    def html(self) -> str:
        """当前页面 HTML 源码。"""
        return self._page.content()

    def back(self) -> None:
        """返回历史记录。"""
        self._page.go_back()

    def forward(self) -> None:
        """前进历史记录。"""
        self._page.go_forward()

    def refresh(self) -> None:
        """刷新当前页面。"""
        self._page.reload()

    def inspect(self, *, pre: int | None = None, after: int | None = None) -> IElement:
        """检视元素模式。高亮鼠标处的元素，并截获下一次鼠标点击，返回点击的元素。"""
        Sleep(pre)
        Info("inspect", "enter inspect mode, click an element")

        _js = """
        () => new Promise((resolve, reject) => {
            const TIMEOUT_MS = 60000;
            let highlighted = null;
            let originalOutline = '';
            let timer = setTimeout(() => {
                document.removeEventListener('mouseover', onMouseOver, true);
                document.removeEventListener('mouseout', onMouseOut, true);
                document.removeEventListener('click', onClick, true);
                unhighlight();
                reject(new Error('inspect timeout: no click within ' + TIMEOUT_MS + 'ms'));
            }, TIMEOUT_MS);
            function getTarget(e) {
                const path = e.composedPath ? e.composedPath() : [e.target];
                return path[0] || e.target;
            }
            function highlight(el) {
                if (highlighted === el) return;
                unhighlight();
                highlighted = el;
                originalOutline = el.style.outline;
                el.style.outline = '2px solid red';
            }
            function unhighlight() {
                if (highlighted) {
                    highlighted.style.outline = originalOutline;
                    highlighted = null;
                }
            }
            function getXPath(el) {
                if (el.id) {
                    return '//*[@id="' + el.id + '"]'
                }
                const parts = [];
                while (el && el.nodeType === Node.ELEMENT_NODE) {
                    let idx = 1;
                    let sibling = el.previousElementSibling;
                    while (sibling) {
                        if (sibling.tagName === el.tagName) idx++;
                        sibling = sibling.previousElementSibling;
                    }
                    let tagName;
                    if (el.namespaceURI === 'http://www.w3.org/2000/svg') {
                        tagName = "*[local-name()='" + el.localName + "']";
                    } else {
                        tagName = el.tagName.toLowerCase();
                    }
                    parts.unshift(tagName + '[' + idx + ']');
                    el = el.parentElement;
                }
                return '/' + parts.join('/');
            }
            function onMouseOver(e) { highlight(getTarget(e)); }
            function onMouseOut(e) { if (getTarget(e) === highlighted) unhighlight(); }
            function onClick(e) {
                e.preventDefault();
                e.stopPropagation();
                clearTimeout(timer);
                document.removeEventListener('mouseover', onMouseOver, true);
                document.removeEventListener('mouseout', onMouseOut, true);
                document.removeEventListener('click', onClick, true);
                unhighlight();
                resolve(getXPath(getTarget(e)));
            }
            document.addEventListener('mouseover', onMouseOver, true);
            document.addEventListener('mouseout', onMouseOut, true);
            document.addEventListener('click', onClick, true);
        })
        """
        _xpath = self._page.evaluate(_js)
        Info("inspect", "element selected", _xpath)
        return self.seek(_xpath, error=True, pre=None, after=after)

    def goto(self, url: str, *, waituntil: str = "load") -> Self:
        """
        Navigate to URL.

        Args:
            url: Target URL
            waituntil: When to consider navigation complete ('load', 'domcontentloaded', 'networkidle')

        Returns:
            self for chaining
        """
        self._page.goto(url, wait_until=waituntil)
        return self

    def close(self) -> None:
        """Close page and cleanup resources."""
        if self._page:
            self._page.close()
            self._page = None

        if self._is_parasitic:
            # Parasitic page only closes its page, not the browser
            self._browser = None
            self._root_host = None
            Info("play", "parasitic page closed")
        elif self._ownbrowser and self._browser:
            # Close standalone browser
            self._browser.close()
            self._browser = None
            Info("play", "standalone browser closed")
        elif self._browser_source == "shared":
            # Decrement shared browser reference
            _BrowserManager.decRef()

        self._browser = None
        Info("play", "page closed")

    def __enter__(self) -> Self:
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()

    # Override Element methods to work with page-level locators

    def seek(self, identity: str, *, error: bool = True, pre: int | None = None, after: int | None = None) -> IElement | None:
        """查找单个元素。"""
        Sleep(pre)
        try:
            _xpath = ResolveIdent(identity)
            _locator = self._page.locator(f"xpath={_xpath}").first
            _locator.wait_for(state="attached", timeout=1000)
            Sleep(after)
            return Element(_locator, self, _xpath=_xpath)
        except Exception as _e:
            Sleep(after)
            if error:
                raise RuntimeError(f"Element not found: {identity}") from _e
            return None

    def seeks(self, identity: str, *, pre: int | None = None, after: int | None = None) -> list[IElement]:
        """查找多个元素。"""
        Sleep(pre)
        _xpath = ResolveIdent(identity)
        _locators = self._page.locator(f"xpath={_xpath}").all()
        Sleep(after)
        return [Element(_loc, self, _xpath=_xpath) for _loc in _locators]

    def wait(self, identity: str, waitlimit: int = 10000, *, error: bool = True, pre: int | None = None, after: int | None = None) -> IElement | None:
        """等待元素存在。"""
        Sleep(pre)
        try:
            _xpath = ResolveIdent(identity)
            _locator = self._page.locator(f"xpath={_xpath}").first
            _locator.wait_for(state="attached", timeout=waitlimit)
            Sleep(after)
            return Element(_locator, self, _xpath=_xpath)
        except Exception as _e:
            Sleep(after)
            if error:
                raise TimeoutError(f"Wait timeout for element: {identity}") from _e
            return None

    def waits(self, identity: str, waitlimit: int = 10000, *, pre: int | None = None, after: int | None = None) -> list[IElement]:
        """等待多个元素存在。"""
        Sleep(pre)
        _xpath = ResolveIdent(identity)
        _locator = self._page.locator(f"xpath={_xpath}")
        try:
            _locator.first.wait_for(state="attached", timeout=waitlimit)
        except Exception:
            pass
        _locators = _locator.all()
        Sleep(after)
        return [Element(_loc, self, _xpath=_xpath) for _loc in _locators]

    def test(self, identity: str, *, pre: int | None = 0, after: int | None = 0) -> bool:
        """测试元素是否存在 (非阻塞)。"""
        Sleep(pre)
        try:
            _xpath = ResolveIdent(identity)
            _count = self._page.locator(f"xpath={_xpath}").count()
            Sleep(after)
            return _count > 0
        except Exception:
            Sleep(after)
            return False

    def _getTargetLocator(self, identity: str | None = None) -> Locator:
        """Get target locator from page."""
        if identity is None:
            # Return page body as default
            return self._page.locator("body")
        _xpath = ResolveIdent(identity)
        return self._page.locator(f"xpath={_xpath}")

    def click(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """左键点击元素。"""
        Sleep(pre)
        _target = self._getTargetLocator(identity)
        _target.click(timeout=limit)
        Sleep(after)
        return self

    def typing(self, identity: str, *keys: str, clear: bool = True, pre: int | None = None, after: int | None = None) -> Self:
        """在元素中输入文本。"""
        Sleep(pre)
        if not _Isidentity(identity):
            raise RuntimeError("Cannot typing webDriver without identity.")
        _xpath = ResolveIdent(identity)
        _target = self._page.locator(f"xpath={_xpath}")
        if clear:
            _target.fill("")
        if keys:
            _target.type("".join(keys))
        Sleep(after)
        return self

    def hold(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """在元素上按住鼠标左键。"""
        Sleep(pre)
        _target = self._getTargetLocator(identity)
        _target.hover(timeout=limit)
        self._page.mouse.down()
        Sleep(after)
        return self

    def release(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """释放鼠标按钮。"""
        Sleep(pre)
        if identity:
            _xpath = ResolveIdent(identity)
            _target = self._page.locator(f"xpath={_xpath}")
            _target.hover(timeout=limit)
        self._page.mouse.up()
        Sleep(after)
        return self

    def doubleClick(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """双击元素。"""
        Sleep(pre)
        _target = self._getTargetLocator(identity)
        _target.dblclick(timeout=limit)
        Sleep(after)
        return self

    def rClick(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """右键点击元素。"""
        Sleep(pre)
        _target = self._getTargetLocator(identity)
        _target.click(button="right", timeout=limit)
        Sleep(after)
        return self

    def mClick(self, identity: str | None = None, *, limit: int = 10000, pre: int | None = None, after: int | None = None) -> Self:
        """中键点击元素。"""
        Sleep(pre)
        _target = self._getTargetLocator(identity)
        _target.click(button="middle", timeout=limit)
        Sleep(after)
        return self

    def screenshot(self, path: str | None = None, *, toimage: bool = True) -> Any | None:
        """截图。

        Args:
            path: 保存路径，None 则不保存到文件
            toimage: True 返回 numpy.ndarray，False 返回原始 bytes

        Returns:
            numpy.ndarray 或 bytes 图像数据，失败时返回 None
        """
        try:
            _data = self._page.screenshot(path=path)
            if toimage:
                return imageio.imread(_data)
            return _data
        except Exception:
            return None

    def table(self, identity: str | None = None, *, waitlimit: int = 10000, pre: int | None = None, after: int | None = None) -> IWebTable:
        """
        获取表格包装器 WebTable。

        Args:
            identity: 表格元素标识符 (xpath, @id, $macro)。
                     None 表示使用 body 作为表格元素
            waitlimit: 等待超时（毫秒），仅当指定 identity 时有效
            pre: 前置等待时间 (毫秒)
            after: 后置等待时间 (毫秒)

        Returns:
            WebTable 实例
        """

        Sleep(pre)
        if identity is None:
            # Use body as table element for WebPage
            _body = Element(self._page.locator("body"), self, _xpath="//body")
            Sleep(after)
            return WebTable(_body)

        # Wait for table element and wrap it
        _elem = self.wait(identity, waitlimit, pre=None, after=after)
        if _elem is None:
            raise RuntimeError(f"Table element not found: {identity}")
        return WebTable(_elem)


__all__ = [
    "WebPage",
    "Element",
    "WebTable",
]
