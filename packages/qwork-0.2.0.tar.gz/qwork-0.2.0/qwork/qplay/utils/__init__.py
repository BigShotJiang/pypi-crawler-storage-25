"""
qplay utils.download_analyzer - Download monitoring utility

Monitors download directory for new files with filtering support.
"""

import os
import re
import shutil
import time
from typing import Self

from qwork.qplay.stdio import Info, Warn, Error


# Default paths
TEMP_PATH = os.path.join(os.getcwd(), ".data", "temp")
DOWNLOAD_PATH = os.path.join(os.environ.get('USERPROFILE', ''), 'Downloads')


class DownloadWatcher:
    """
    Watches download directory for new files.

    Usage:
        watcher = DownloadWatcher(target_re=r".*\\.pdf$")
        files = watcher.wait(n=1, timeout=30000)
        if files:
            copies = watcher.copyTo("/dest/path")
    """

    def __init__(
        self,
        path: str | None = None,
        *,
        target_re: str | None = None,
        ignore_re: str | None = r".*\.(crdownload|tmp)$"
    ):
        """
        Initialize download watcher.

        Args:
            path: Download directory path, defaults to system Downloads
            target_re: Regex to match target files
            ignore_re: Regex to ignore files (default: unfinished downloads)
        """
        self._path = path if path is not None else DOWNLOAD_PATH

        if not os.path.isdir(self._path):
            raise NotADirectoryError(f"Path '{self._path}' is not a valid directory.")

        self._current: set[str] = set(os.listdir(self._path))
        self._target_re = target_re
        self._ignore_re = ignore_re

        Info("dlwatch", f"watching", self._path)

    def _toFullPath(self, *names: str) -> list[str]:
        """Convert filenames to full paths."""
        return [os.path.join(self._path, n) for n in names]

    @property
    def downloads(self) -> list[str]:
        """Get list of new downloaded files matching filters."""
        new_files = set(os.listdir(self._path)) - self._current

        if self._target_re is None and self._ignore_re is None:
            return self._toFullPath(*new_files)

        filtered: list[str] = []
        for fname in new_files:
            if self._target_re and not re.search(self._target_re, fname):
                continue
            if self._ignore_re and re.search(self._ignore_re, fname):
                continue
            filtered.append(fname)

        return self._toFullPath(*filtered)

    def wait(self, n: int = 1, timeout: int = 60000) -> list[str]:
        """
        Wait for n files to be downloaded.

        Args:
            n: Number of files to wait for
            timeout: Timeout in milliseconds

        Returns:
            List of file paths, empty if timeout
        """
        start = time.time()

        while True:
            downloads = self.downloads
            if len(downloads) >= n:
                Info("dlwatch", f"found {len(downloads)} files")
                return downloads

            if (time.time() - start) * 1000 > timeout:
                Warn("dlwatch", f"timeout after {timeout}ms")
                return []

            time.sleep(0.75)

    def copyTo(
        self,
        dest_dir: str | None = None,
        new_name: str | None = None
    ) -> list[str]:
        """
        Copy downloaded files to destination.

        Args:
            dest_dir: Destination directory, defaults to temp
            new_name: New base name (preserves extension)

        Returns:
            List of copied file paths
        """
        if dest_dir is None:
            dest_dir = TEMP_PATH

        if not os.path.isdir(dest_dir):
            raise NotADirectoryError(f"Destination '{dest_dir}' is not valid.")

        copied: list[str] = []
        for src_path in self.downloads:
            fname = os.path.basename(src_path)

            if new_name is not None:
                # Preserve extension
                dot = fname.rfind('.')
                ext = "" if dot == -1 else fname[dot:]
                fname = new_name + ext

            dest_path = os.path.join(dest_dir, fname)
            shutil.copy2(src_path, dest_path)
            copied.append(dest_path)
            Info("dlwatch", f"copied", f"{fname} -> {dest_dir}")

        return copied

    def moveTo(
        self,
        dest_dir: str | None = None,
        new_name: str | None = None
    ) -> list[str]:
        """
        Move downloaded files to destination.

        Args:
            dest_dir: Destination directory, defaults to temp
            new_name: New base name (preserves extension)

        Returns:
            List of moved file paths
        """
        if dest_dir is None:
            dest_dir = TEMP_PATH

        if not os.path.isdir(dest_dir):
            raise NotADirectoryError(f"Destination '{dest_dir}' is not valid.")

        moved: list[str] = []
        for src_path in self.downloads:
            fname = os.path.basename(src_path)

            if new_name is not None:
                dot = fname.rfind('.')
                ext = "" if dot == -1 else fname[dot:]
                fname = new_name + ext

            dest_path = os.path.join(dest_dir, fname)
            shutil.move(src_path, dest_path)
            moved.append(dest_path)
            Info("dlwatch", f"moved", f"{fname} -> {dest_dir}")

        # Update snapshot after move
        self.flush()

        return moved

    def flush(self) -> list[str]:
        """
        Update directory snapshot and return new files.

        Returns:
            List of newly added files since last flush
        """
        previous = self._current.copy()
        self._current = set(os.listdir(self._path))
        new_files = self._current - previous
        return self._toFullPath(*new_files)

    @property
    def path(self) -> str:
        """Get watched directory path."""
        return self._path

    def snapshot(self) -> Self:
        """Take current snapshot without returning files."""
        self._current = set(os.listdir(self._path))
        return self
