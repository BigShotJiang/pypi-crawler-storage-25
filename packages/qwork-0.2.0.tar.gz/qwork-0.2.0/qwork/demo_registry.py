"""
Demo for qwork registry system.

This demonstrates how to use the registry to inspect registered classes and functions.
"""

import sys
sys.path.insert(0, r"F:\Python\Python314\Lib\site-packages")

# Import qwork (this will trigger registrations from submodules)
from qwork import (
    RegisterClass,
    RegisterFunction,
    VerifyRegistry,
    InspectRegistered,
    registry,
    ClassInfo,
    FunctionInfo,
)


# Define and register a sample class
@RegisterClass
class MyService:
    """A sample service class for demonstration."""

    def __init__(self, name: str = "default"):
        self._name = name

    def process(self, data: dict) -> str:
        """Process the input data and return a string result."""
        return f"Processed {len(data)} items"

    def _internal_helper(self, _value: int) -> bool:
        """Internal helper method (should be private)."""
        return _value > 0


# Define and register a sample function
@RegisterFunction
def CalculateSum(a: int, b: int) -> int:
    """Calculate the sum of two integers."""
    return a + b


@RegisterFunction(name="CustomName")
def SomeUtilityFunction(items: list[str], *, flag: bool = False) -> dict:
    """
    Process a list of items with optional flag.

    Args:
        items: List of string items to process
        flag: Optional boolean flag

    Returns:
        Dictionary with processed results
    """
    return {"items": items, "flag": flag, "count": len(items)}


def main():
    print("=" * 60)
    print("QWork Registry Demo")
    print("=" * 60)

    # 1. List all registered items
    print("\n[1] Registered Classes:")
    for _name in registry.list_classes():
        print(f"    - {_name}")

    print("\n[2] Registered Functions:")
    for _name in registry.list_functions():
        print(f"    - {_name}")

    # 2. Verify all registrations
    print("\n[3] Verification Results:")
    _result = VerifyRegistry()
    for _item in _result['valid']:
        print(f"    ✓ {_item}")
    for _err in _result['errors']:
        print(f"    ✗ {_err}")

    # 3. Inspect a registered class
    print("\n[4] Inspecting Class: MyService")
    _info = InspectRegistered("MyService")
    if isinstance(_info, ClassInfo):
        print(f"    Name: {_info.name}")
        print(f"    Module: {_info.module}")
        print(f"    Bases: {_info.bases}")
        print(f"    Is Dataclass: {_info.is_dataclass}")
        print(f"    Doc: {_info.doc}")
        print(f"    Methods ({len(_info.methods)}):")
        for _m in _info.methods:
            print(f"      - {_m.name}: {_m.signature}")

    # 4. Inspect a registered function
    print("\n[5] Inspecting Function: CalculateSum")
    _info = InspectRegistered("CalculateSum")
    if isinstance(_info, FunctionInfo):
        print(f"    Name: {_info.name}")
        print(f"    Module: {_info.module}")
        print(f"    Signature: {_info.signature}")
        print(f"    Return: {_info.return_annotation}")
        print(f"    Doc: {_info.doc}")
        print(f"    Parameters:")
        for _p in _info.parameters:
            _default = f" = {_p.default}" if _p.default != inspect.Parameter.empty else ""
            _anno = f": {_p.annotation}" if _p.annotation != inspect.Parameter.empty else ""
            print(f"      - {_p.name}{_anno} ({_p.kind}){_default}")

    # 5. Inspect custom named function
    print("\n[6] Inspecting Function: CustomName")
    _info = InspectRegistered("CustomName")
    if isinstance(_info, FunctionInfo):
        print(f"    Name: {_info.name}")
        print(f"    Signature: {_info.signature}")
        print(f"    Parameters ({len(_info.parameters)}):")
        for _p in _info.parameters:
            print(f"      - {_p.name} (kind={_p.kind})")

    # 6. Inspect qfsm registered classes (if imported)
    print("\n[7] Inspecting qfsm Stage class:")
    _info = InspectRegistered("Stage")
    if _info:
        print(f"    Found: {_info.name}")
        print(f"    Module: {_info.module}")
        print(f"    Methods: {len(_info.methods) if hasattr(_info, 'methods') else 'N/A'}")
    else:
        print("    Not registered yet (need to import qwork.qfsm)")

    print("\n" + "=" * 60)
    print("Demo completed!")
    print("=" * 60)


if __name__ == "__main__":
    import inspect
    main()
