"""
Test single marker behavior during behavior tree execution.
"""
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel
from PyQt6.QtCore import Qt, QTimer

from qwork.qfsm import Logic, sequence
from qwork.qflow.qchart import QFlowChart


class SlowSequenceLogic(Logic):
    """Logic with slow sequence for testing marker visibility."""

    NAME = "SlowTest"

    def start(self, inst):
        return "seq_parent"

    @sequence("slow_a", "slow_b")
    def seq_parent(self, inst):
        pass

    def slow_a(self, inst):
        import time
        time.sleep(0.1)  # Simulate slow execution
        return True

    def slow_b(self, inst):
        import time
        time.sleep(0.1)
        return True


class ControlPanel(QWidget):
    def __init__(self, chart, parent=None):
        super().__init__(parent)
        self.chart = chart

        layout = QVBoxLayout(self)

        self.status = QLabel("Ready")
        layout.addWidget(self.status)

        btn = QPushButton("Single Step")
        btn.clicked.connect(self.do_step)
        layout.addWidget(btn)

        btn10 = QPushButton("Auto Step (5 steps)")
        btn10.clicked.connect(self.auto_step)
        layout.addWidget(btn10)

        self.step_count = 0

    def do_step(self):
        self.step_count += 1
        self.status.setText(f"Step {self.step_count}")
        self.chart.doStep()

    def auto_step(self):
        for i in range(5):
            QTimer.singleShot(i * 800, self.do_step)


def main():
    app = QApplication(sys.argv)

    logic = SlowSequenceLogic()
    chart = QFlowChart(stage=logic, show_controls=False)
    chart.setWindowTitle("Single Marker Test")
    chart.resize(600, 400)

    # Track marker state
    marker_log = []

    original_handler = chart._event_bridge._handler

    def event_handler(data):
        new_state = data.get("new")
        event_type = data.get("type")
        result = data.get("result")

        if event_type == "behavior":
            marker_log.append({
                "state": new_state,
                "result": result,
                "executing": list(chart._executing_nodes)
            })
            print(f"[Event] {new_state} result={result}, executing={chart._executing_nodes}")

        original_handler(data)

    chart._event_bridge._handler = event_handler

    control = ControlPanel(chart)
    control.show()
    chart.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
