from typing import Any
import asyncio
import json
import re

from pydantic import BaseModel, Field, ValidationError
from qflow import *
from qfsm import *
from qai import *

user_intent = "科幻线索"
min_chapters = 20
volume = 1
max_iterations = 10

MASTER_OUTLINE_PROMPT = f"""你是小说大纲创建专家，能直接生成符合格式的结构化总纲。
阅读
## 任务
基于用户需求"{user_intent}"，生成包含至少{min_chapters}个章节的小说总纲，划分{volume}个卷册，确保逻辑连贯且形成完整故事弧线。

## 角色架构（三层体系）
1. 固定主要角色（3-5人）：贯穿全书的核心人物，必须在所有卷中出现
2. 卷册配角（2-5人/卷）：每卷新增的配角，可细分为：
   - 本卷专属：仅在本卷有重要戏份
   - 跨卷角色：会在其他卷作为NPC/背景角色出现（在其他卷重要性降一级）
3. 路人NPC：临时角色，无需生成详细档案

## 核心要素
1. 基础信息：标题（简洁有力）、类型（明确）、主题（15字内）、背景（50字内）、情节概要（100字内）
2. 卷册划分：每卷含合理章节数（标注chapters_range如"1-25"），总章节≥{min_chapters}
3. 卷册细节：每卷需含标题、主题（10字内）、3个关键转折点（每点15字内，推动主线）
4. 固定主要角色：列出3-5个核心角色（仅名称）
5. 每卷角色规划：为每卷规划新增配角（名称+是否跨卷标记）

## 输出格式
仅用```json和```包裹JSON内容，无任何额外文字，格式如下：{{
  "title": "小说标题",
  "genre": "类型",
  "theme": "核心主题",
  "setting": "故事背景",
  "plot_summary": "情节概要",
  "master_outline": [
    {{"title": "卷1标题", "chapters_range": "1-25", "theme": "卷主题", "key_turning_points": ["转折1", "转折2", "转折3"]}},
    ...
  ],
  "characters": ["主角1", "主角2", ...],  // 仅固定主要角色（3-5人）
  "character_plans": [  // 每卷角色规划
    {{
      "volume_index": 0,  // 卷索引从0开始
      "new_characters": ["卷1新角色1", "卷1新角色2"],  // 本卷新增角色名称
      "volume_only": ["卷1新角色1"],  // 本卷专属角色
      "cross_volume": ["卷1新角色2"]  // 跨卷角色（会在其他卷出现）
    }},
    ...
  ]
}}
注意：
- 角色名称必须在对应卷中有实际戏份，不能仅为凑数
- 跨卷角色在其他卷中重要性会降一级（从配角变为NPC背景）
- 角色总数建议：3-5固定主角 + 每卷2-5配角
严格遵循字段长度限制，直接输出符合要求的JSON！
"""

OUTLINE_REFLECT_PROMPT = """你是专业小说编辑，需要对小说大纲进行全面评估并提供结构化的反馈。

## 评估维度
1. **结构完整性(structure)**：整体架构是否完整，起承转合是否清晰，各幕/卷/章节分配比例是否合理，是否存在结构性缺失（如铺垫不足、收束仓促）
2. **情节设计(plot)**：主线是否清晰聚焦，支线是否服务于主线或角色成长，关键情节点（激励事件、第一情节点、中点、第二情节点、高潮、结局）是否明确且位置恰当，伏笔与回收是否形成闭环
3. **角色弧线(character_arc)**：主要角色的成长轨迹是否清晰可信，动机与转变逻辑是否充分，角色关系演变是否有层次，是否存在功能性工具人或性格扁平化问题
4. **世界观一致性(worldbuilding)**：核心设定是否自洽，规则体系是否一致，是否存在未解释的设定漏洞或后期机械降神风险，设定与情节融合度如何
5. **节奏规划(pacing)**：各阶段篇幅权重分配是否合理，张弛交替是否有韵律，是否存在过度铺垫或高潮 rushed 的风险，关键转折的密度是否适当
6. **冲突设计(conflict)**：核心冲突（人际/内心/人境）是否明确且可持续升级，对抗阻力是否有层次递进，解决方案是否过于轻易（Deus Ex Machina）
7. **逻辑框架(logic)**：宏观因果链是否完整，时间线/事件线是否冲突，关键决策节点是否符合角色利益与情境约束，是否存在为了情节牺牲逻辑的强行桥段

## 反馈要求
对于每个发现的问题，请提供：
- 问题类别（从上述7个维度中选择）
- 优先级（high/medium/low）
- 具体问题描述
- 改进建议（具体到建议增加/删除/调整哪个情节点或设定）
- 问题位置（如：第二幕中段/第15章大纲/角色X的转折处）

## 通过标准
- 总分必须 >= 8分 且 passes 才能通过
- **任何单项评分（structure_score/plot_score/character_arc_score/logic_score）< 6分 则直接不通过**（结构性问题不可妥协）
- 存在主线断裂、核心设定矛盾、或关键角色动机崩塌的，不通过

## 输出格式
请用```json和```包裹JSON内容，确保符合以下结构:
{{
  "score": 评分(1-10),
  "passes": 是否通过评审(true/false, 总分>=8且无不达标项才可为true),
  "coverage_check": 大纲覆盖度是否充足(true/false, 是否覆盖到结局),
  "feedback_items": [
    {{
      "category": "问题类别(structure/plot/character_arc/worldbuilding/pacing/conflict/logic)",
      "priority": "优先级(high/medium/low)",
      "issue": "具体问题描述",
      "suggestion": "改进建议",
      "location": "问题位置描述"
    }}
  ],
  "overall_feedback": "整体评价总结，重点关注大纲的商业可行性与创作风险",
  "structure_score": 结构评分(1-10),
  "plot_score": 情节评分(1-10),
  "character_arc_score": 角色弧线评分(1-10),
  "pacing_score": 节奏评分(1-10)
}}

注意：
- 如果大纲质量良好无明显问题，feedback_items可以为空数组
- 优先级定义：
  * high: 结构性致命伤，例如：核心设定矛盾、主线逻辑断裂、关键伏笔无回收计划、角色转变缺乏铺垫、结局机械降神
  * medium: 需要优化的问题，例如：某幕节奏失衡、支线与主线游离、角色动机薄弱、世界观细节缺失
  * low: 可选的增强建议，例如：增加情感节拍、丰富副线冲突、调整章节断点位置
- 只输出JSON内容，不要添加其他解释或说明
"""


# ========== Pydantic 模型定义 ==========

class VolumeOutline(BaseModel):
    title: str = Field(..., min_length=1, max_length=50)
    chapters_range: str = Field(..., pattern=r'^\d+-\d+$')
    theme: str = Field(..., min_length=1, max_length=20)
    key_turning_points: list[str] = Field(..., min_length=3, max_length=3)


class CharacterPlan(BaseModel):
    volume_index: int = Field(..., ge=0)
    new_characters: list[str] = Field(..., min_length=1)
    volume_only: list[str] = []
    cross_volume: list[str] = []


class NovelOutline(BaseModel):
    title: str = Field(..., min_length=1, max_length=50)
    genre: str = Field(..., min_length=1, max_length=30)
    theme: str = Field(..., min_length=1, max_length=20)
    setting: str = Field(..., min_length=1, max_length=100)
    plot_summary: str = Field(..., min_length=1, max_length=200)
    master_outline: list[VolumeOutline] = Field(..., min_length=1)
    characters: list[str] = Field(..., min_length=3, max_length=10)
    character_plans: list[CharacterPlan] = []


class ReviewFeedbackItem(BaseModel):
    category: str = Field(..., pattern=r'^(structure|plot|character_arc|worldbuilding|pacing|conflict|logic)$')
    priority: str = Field(..., pattern=r'^(high|medium|low)$')
    issue: str = Field(..., min_length=1)
    suggestion: str = Field(..., min_length=1)
    location: str = Field(..., min_length=1)


class NovelReview(BaseModel):
    score: float = Field(..., ge=1, le=10)
    passes: bool
    coverage_check: bool
    feedback_items: list[ReviewFeedbackItem] = []
    overall_feedback: str = Field(..., min_length=1)
    structure_score: float = Field(..., ge=1, le=10)
    plot_score: float = Field(..., ge=1, le=10)
    character_arc_score: float = Field(..., ge=1, le=10)
    pacing_score: float = Field(..., ge=1, le=10)


# ========== JSON 提取和验证 ==========

def _extract_json(text: str) -> dict:
    """从文本中提取 JSON 内容"""
    pattern = r'```json\s*(.*?)\s*```'
    matches = re.findall(pattern, text, re.DOTALL)
    if matches:
        return json.loads(matches[-1])
    return json.loads(text)


def _validate_outline(data: dict) -> tuple[bool, NovelOutline | None, str]:
    """验证大纲 JSON 数据
    
    Returns:
        (是否成功, 验证后的模型, 错误信息)
    """
    try:
        outline = NovelOutline.model_validate(data)
        return True, outline, ""
    except ValidationError as e:
        errors = []
        for err in e.errors():
            loc = '.'.join(str(x) for x in err['loc'])
            msg = err['msg']
            errors.append(f"{loc}: {msg}")
        return False, None, "; ".join(errors)


def _validate_review(data: dict) -> tuple[bool, NovelReview | None, str]:
    """验证审查结果 JSON 数据
    
    Returns:
        (是否成功, 验证后的模型, 错误信息)
    """
    try:
        review = NovelReview.model_validate(data)
        return True, review, ""
    except ValidationError as e:
        errors = []
        for err in e.errors():
            loc = '.'.join(str(x) for x in err['loc'])
            msg = err['msg']
            errors.append(f"{loc}: {msg}")
        return False, None, "; ".join(errors)


class OutlineReflectWorkflow(Logic):
    """小说大纲创作与审查工作流
    
    流程: idle -> write -> review -> (success/failure/revise)
    - write: AI 生成大纲
    - review: AI 审查大纲质量
    - success: 审查通过，输出结果
    - failure: 达到最大重试次数，放弃
    - revise: 根据反馈修改后重新生成
    """
    
    NAME = "OutlineReflectWorkflow"
    LOG = True
    
    def onLoading(self, inst: Any) -> None:
        """初始化 AI 实例"""
        self._ai: AICore | None = CreateAI("kimi", only=True)
        self._outline_response: ChatResponse | None = None
        self._review_response: ChatResponse | None = None
        self._iteration = 0
        self._max_iterations = max_iterations
        self._outline_data: dict | None = None
        self._review_data: dict | None = None
        self._feedback_history: list = []
    
    def onStart(self, inst: Any) -> None:
        """工作流开始"""
        print(f"\n{'='*60}")
        print(f"[Workflow] 大纲创作工作流启动")
        print(f"[Workflow] 主题: {user_intent}")
        print(f"[Workflow] 最少章节: {min_chapters}, 卷数: {volume}")
        print(f"[Workflow] 最大迭代次数: {self._max_iterations}")
        print(f"{'='*60}\n")
    
    def idle(self, inst: Any) -> str | None:
        """初始状态，进入创作"""
        return "write"
    
    def write(self, inst: Any) -> str | None:
        """创作状态：调用 AI 生成大纲"""
        self._iteration += 1
        print(f"\n[Write] 第 {self._iteration}/{self._max_iterations} 次创作...")
        
        # 如果有历史反馈，添加到提示词中
        prompt = MASTER_OUTLINE_PROMPT
        if self._feedback_history:
            feedback_text = "\n\n## 历史反馈（请避免之前的问题）\n"
            for i, fb in enumerate(self._feedback_history, 1):
                feedback_text += f"\n反馈 {i}:\n"
                for item in fb.get("feedback_items", []):
                    feedback_text += f"- [{item.get('priority', 'medium')}] {item.get('issue', '')}\n"
                    feedback_text += f"  建议: {item.get('suggestion', '')}\n"
            prompt += feedback_text
        
        try:
            messages = [Message(role="user", content=prompt)]
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        self._outline_response = loop.run_until_complete(self._ai.chat(messages))

        # 解析和验证 JSON
        try:
            raw_data = _extract_json(self._outline_response.content)
            is_valid, outline_model, error_msg = _validate_outline(raw_data)

            if not is_valid:
                print(f"[Write] 大纲验证失败: {error_msg}")
                if self._iteration >= self._max_iterations:
                    self._outline_data = raw_data  # 保存原始数据用于失败输出
                    return "failure"
                return "write"

            # 验证成功，保存数据
            self._outline_data = outline_model.model_dump()
            print(f"[Write] 大纲生成成功!")
            print(f"[Write] 标题: {outline_model.title}")
            print(f"[Write] 类型: {outline_model.genre}")
            print(f"[Write] 卷数: {len(outline_model.master_outline)}")
            print(f"[Write] 角色数: {len(outline_model.characters)}")
            return "review"
        except json.JSONDecodeError as e:
            print(f"[Write] JSON 解析失败: {e}")
            if self._iteration >= self._max_iterations:
                return "failure"
            return "write"
    
    def review(self, inst: Any) -> str | None:
        """审查状态：评估大纲质量"""
        print(f"\n[Review] 正在审查大纲质量...")
        
        # 构建审查提示词
        review_prompt = OUTLINE_REFLECT_PROMPT + f"\n\n## 待审查大纲\n\n{self._outline_response.content}"
        
        try:
            messages = [Message(role="user", content=review_prompt)]
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        self._review_response = loop.run_until_complete(self._ai.chat(messages))

        # 解析和验证审查结果
        try:
            raw_data = _extract_json(self._review_response.content)
            is_valid, review_model, error_msg = _validate_review(raw_data)

            if not is_valid:
                print(f"[Review] 审查结果验证失败: {error_msg}")
                print(f"[Review] 假设审查通过")
                self._review_data = raw_data
                return "success"

            # 验证成功
            self._review_data = review_model.model_dump()

        except json.JSONDecodeError:
            print(f"[Review] 审查结果解析失败，假设通过")
            return "success"

        # 保存反馈历史
        self._feedback_history.append(self._review_data)

        # 显示审查结果
        score = self._review_data.get("score", 0)
        passes = self._review_data.get("passes", False)
        feedback_items = self._review_data.get("feedback_items", [])

        print(f"[Review] 评分: {score}/10")
        print(f"[Review] 是否通过: {'是' if passes else '否'}")

        if feedback_items:
            print(f"[Review] 发现问题 ({len(feedback_items)} 个):")
            for item in feedback_items:
                priority = item.get("priority", "medium")
                category = item.get("category", "unknown")
                issue = item.get("issue", "")
                print(f"  - [{priority.upper()}] [{category}] {issue[:50]}...")

        # 判断是否通过
        if passes:
            return "success"

        # 未通过，检查是否还有重试次数
        if self._iteration >= self._max_iterations:
            print(f"[Review] 达到最大迭代次数，进入失败处理")
            return "failure"

        print(f"[Review] 需要修改，准备重新创作...")
        return "revise"
    
    def revise(self, inst: Any) -> str | None:
        """修订状态：准备重新创作"""
        print(f"\n[Revise] 根据反馈调整创作策略...")
        # 可以在这里添加额外的提示词调整逻辑
        return "write"
    
    def success(self, inst: Any) -> str | None:
        """成功状态：输出最终结果"""
        print(f"\n{'='*60}")
        print(f"[Success] ✓ 大纲创作成功!")
        print(f"[Success] 总迭代次数: {self._iteration}")
        print(f"{'='*60}")
        
        if self._outline_data:
            print(f"\n【最终大纲】")
            print(f"标题: {self._outline_data.get('title', 'N/A')}")
            print(f"类型: {self._outline_data.get('genre', 'N/A')}")
            print(f"主题: {self._outline_data.get('theme', 'N/A')}")
            print(f"背景: {self._outline_data.get('setting', 'N/A')}")
            print(f"\n情节概要:\n{self._outline_data.get('plot_summary', 'N/A')}")
            
            print(f"\n【卷册规划】")
            for vol in self._outline_data.get("master_outline", []):
                print(f"  - {vol.get('title', 'N/A')} ({vol.get('chapters_range', 'N/A')})")
                print(f"    主题: {vol.get('theme', 'N/A')}")
            
            print(f"\n【主要角色】")
            for char in self._outline_data.get("characters", []):
                print(f"  - {char}")
        
        if self._review_data:
            print(f"\n【审查评分】")
            print(f"总分: {self._review_data.get('score', 'N/A')}/10")
            print(f"结构: {self._review_data.get('structure_score', 'N/A')}/10")
            print(f"情节: {self._review_data.get('plot_score', 'N/A')}/10")
            print(f"角色弧线: {self._review_data.get('character_arc_score', 'N/A')}/10")
            print(f"节奏: {self._review_data.get('pacing_score', 'N/A')}/10")
            print(f"\n整体评价: {self._review_data.get('overall_feedback', 'N/A')}")
        
        print(f"\n{'='*60}")
        return None
    
    def failure(self, inst: Any) -> str | None:
        """失败状态：无法生成合格大纲"""
        print(f"\n{'='*60}")
        print(f"[Failure] ✗ 大纲创作失败")
        print(f"[Failure] 已尝试 {self._iteration} 次，未能通过审查")
        print(f"{'='*60}")
        
        if self._outline_data:
            print(f"\n【最后一次生成的大纲】")
            print(f"标题: {self._outline_data.get('title', 'N/A')}")
            print(f"类型: {self._outline_data.get('genre', 'N/A')}")
            print(f"\n原始内容:\n{self._outline_response.content[:500]}...")
        
        if self._review_data:
            print(f"\n【最后一次审查反馈】")
            print(f"评分: {self._review_data.get('score', 'N/A')}/10")
            print(f"未通过原因: {self._review_data.get('overall_feedback', 'N/A')}")
        
        print(f"\n{'='*60}")
        return None


if __name__ == "__main__":
    # 创建工作流实例
    workflow = OutlineReflectWorkflow()
    from PyQt6.QtWidgets import QApplication
    app = QApplication([])
    qchart = QFlowChart(workflow)
    qchart.show()
    app.exec()
    
