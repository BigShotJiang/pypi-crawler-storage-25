from __future__ import annotations
"""qflow._demo - Minimal demo for QFlowChart"""


import random
import time
import sys

from PyQt6.QtWidgets import QApplication, QMainWindow
from PyQt6.QtCore import Qt

from qwork.qflow.qchart import QFlowChart
from qwork.qflow.chart import ChartNode, ChartEdge
from qwork.qfsm import *

# Module-level QApplication reference to prevent garbage collection
_qapp: QApplication | None = None


class DemoLogic(Logic):
    """entry -> running -> exit"""
    NAME = "DemoLogic"

    def entry(self, inst):
        return "root"

    # =============== Tree ================
    @parallel("a", "b")
    def root(self, it):
        return True

    def a(self, it):
        return random.random() < 0.5
    
    @sequence("c", "d")
    def b(self, it):
        time.sleep(2)
        # print("b被执行")
        return True

    def c(self, it):                                                  
        return random.random() < 0.6
    
    def d(self, it):
        return 'record'
    # =====================================

    @recursive
    def record(self, inst):
        return "exit"

    def exit(self, inst):
        self._alive = False


class DemoChart(QFlowChart):
    """A demo chart with sample nodes and edges for testing."""

    def __init__(self):
        # Ensure QApplication exists for headless/test environments
        global _qapp
        if QApplication.instance() is None:
            _qapp = QApplication(sys.argv)
        super().__init__()
        # Create demo nodes
        self.addNode(ChartNode(nid="entry", name="Entry", ntype="entry", shape="ellipse"))
        self.addNode(ChartNode(nid="state1", name="State1", ntype="state", shape="rectangle"))
        self.addNode(ChartNode(nid="state2", name="State2", ntype="state", shape="rectangle"))
        self.addNode(ChartNode(nid="exit", name="Exit", ntype="exit", shape="ellipse"))

        # Create demo edges
        self.addEdge(ChartEdge(eid="e1", src="entry", dst="state1", etype="flow"))
        self.addEdge(ChartEdge(eid="e2", src="state1", dst="state2", etype="flow"))
        self.addEdge(ChartEdge(eid="e3", src="state2", dst="exit", etype="flow"))
        self.addEdge(ChartEdge(eid="e4", src="state2", dst="state1", etype="flow", bidirectional=True))

        # Set start node
        self.startnode = "entry"


class DemoWindow(QMainWindow):
    """Demo window for running QFlowChart GUI."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("QFlowChart Demo")
        self.setGeometry(100, 100, 1000, 700)

        self.setCentralWidget(QFlowChart(DemoLogic(), parent=self))


if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    window = DemoWindow()
    window.show()
    sys.exit(app.exec())
