"""Test decorator synchronization from Stage/Logic to qnode."""

from PyQt6.QtGui import QColor


import sys
import unittest
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QPointF

from qwork.qfsm import Stage, Logic, recursive
from qwork.qflow import QFlowChart
from qwork.qnode import NodeCanvas, NodeItem, NodeShape


class TestStage(Stage):
    """Test stage with recursive entry state."""
    NAME = "TestStage"

    @recursive
    def entry(self, inst, c, k):
        return None

    def normal(self, inst, c, k):
        return None


class TestLogic(Logic):
    """Test logic with recursive and normal states."""
    NAME = "TestLogic"

    @recursive
    def entry(self, inst, c, k, *refs):
        return None

    def process(self, inst, c, k, *refs):
        return None


class TestDecoratorSync(unittest.TestCase):
    """Test decorator synchronization from Stage/Logic to qnode nodes."""

    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)

    def testStageRecursiveDecorator(self):
        """Test that recursive state gets decorator in QFlowChart."""
        chart = QFlowChart()
        stage = TestStage()
        chart.setStage(stage)

        # Check that entry node has recursive decorator
        entry_node = chart._nodemap.get("entry")
        self.assertIsNotNone(entry_node)
        self.assertEqual(entry_node.decorator, "recursive")

        # Check that normal node does not have decorator
        normal_node = chart._nodemap.get("normal")
        self.assertIsNotNone(normal_node)
        self.assertIsNone(normal_node.decorator)

    def testLogicRecursiveDecorator(self):
        """Test that recursive state gets decorator in QFlowChart from Logic."""
        chart = QFlowChart()
        logic = TestLogic()
        chart.setStage(logic)

        # Check that entry node has recursive decorator
        entry_node = chart._nodemap.get("entry")
        self.assertIsNotNone(entry_node)
        self.assertEqual(entry_node.decorator, "recursive")

        # Check that process node does not have decorator
        process_node = chart._nodemap.get("process")
        self.assertIsNotNone(process_node)
        self.assertIsNone(process_node.decorator)

    def testDecoratorColorApplied(self):
        """Test that decorator color is actually applied."""

        chart = QFlowChart()
        stage = TestStage()
        chart.setStage(stage)

        entry_node = chart._nodemap.get("entry")
        self.assertIsNotNone(entry_node)

        # Get decorator color
        color = entry_node._getDecoratorStrokeColor()
        self.assertIsNotNone(color)

        # Should be violet for recursive
        self.assertEqual(color.red(), 238)
        self.assertEqual(color.green(), 130)
        self.assertEqual(color.blue(), 238)


if __name__ == "__main__":
    unittest.main()
