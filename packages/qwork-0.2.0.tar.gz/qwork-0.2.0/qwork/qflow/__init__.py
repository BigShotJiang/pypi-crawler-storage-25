"""
qflow - Flow chart module for qwork

Provides IChart interface and FlowChart implementation for converting
between qnode JSON format and qfsm Stage/Logic instances.
"""

from qwork.qflow.chart import IChart, Chart, ChartNode, ChartEdge, ChartLogic
from qwork.qflow.qchart import QFlowChart

# Editor components
from qwork.qflow.editor import (
    StageEditor,
    StageEditorDialog,
    StageEditorFactory,
    edit_state,
)

__all__ = [
    "IChart",
    "Chart",
    "ChartNode",
    "ChartEdge",
    "ChartLogic",
    "QFlowChart",
    # Editor exports
    "StageEditor",
    "StageEditorDialog",
    "StageEditorFactory",
    "edit_state",
]
