from __future__ import annotations
"""


qflow.editor - PyEdit-based editor for qflowchart node editing

This module provides StageEditor, a specialized Python editor for editing
qfsm Stage/Logic state methods with proper context awareness.
"""

from qwork.qfsm.stage import Stage



from typing import TYPE_CHECKING, Any, Type

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QDialog, QApplication
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont

from qwork.pyedit import PythonEditor, PythonEditorFactory

class StageEditor(PythonEditor):
    """
    Python editor specialized for qfsm Stage/Logic state editing.

    Provides context-aware editing for state methods with:
    - Class definition context (CA)
    - Function signature context (CB)
    - Proper self and inst parameter completion

    Example:
        editor = StageEditor()
        editor.set_stage_context(MyStageClass, "running")
        editor.set_code("return 'completed'")
    """

    code_saved = pyqtSignal(str)  # Emitted when code is saved

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._stage_class: Type[Stage] | None = None
        self._state_name: str = ""
        self._inst_type: str = "Any"

    def set_stage_context(
        self,
        stage_class: Type[Stage],
        state_name: str,
        inst_type: str = "Any"
    ) -> None:
        """
        Set the Stage/Logic class context for editing.

        Args:
            stage_class: The Stage/Logic class being edited
            state_name: The state method name being edited
            inst_type: Type annotation for inst parameter (default: Any)
        """
        self._stage_class = stage_class
        self._state_name = state_name
        self._inst_type = inst_type

        # Build context code
        code_a = self._build_class_context()
        code_b = self._build_function_context()

        # Set context with 8-space prefix for method body
        self.set_context_code(
            code_a=code_a,
            code_b=code_b,
            prefix="        "  # 8 spaces for method indentation
        )

    def _build_class_context(self) -> str:
        """Build class definition context (CA)."""
        if self._stage_class is None:
            return ""

        class_name = self._stage_class.__name__

        # Get base classes
        bases = []
        for base in self._stage_class.__bases__:
            if base.__name__ != "object":
                bases.append(base.__name__)

        base_str = f"({', '.join(bases)})" if bases else ""

        # Build class definition with common attributes
        lines = [
            f"class {class_name}{base_str}:",
            f'    NAME = "{self._stage_class.NAME}"',
            "",
            "    # Class-level attributes",
        ]

        # Add common Stage/Logic attributes
        lines.extend([
            "    LOG: bool = True",
            "    LIMIT: int = 24",
            "",
            "    def __init__(self, inst: Any = None) -> None:",
            "        self._inst = inst",
            "        self._current: str | None = None",
            "",
        ])

        # Add other state methods as stubs for completion
        states = getattr(self._stage_class, "__states__", [])
        for state in states:
            if state != self._state_name:
                lines.append(f"    def {state}(self, inst: {self._inst_type}):")
                lines.append("        ...")
                lines.append("")

        return "\n".join(lines)

    def _build_function_context(self) -> str:
        """Build function definition context (CB)."""
        if not self._state_name:
            return ""

        lines = [
            f"    def {self._state_name}(self, inst: {self._inst_type}):",
            '        """',
            f"        State: {self._state_name}",
            "",
            "        Args:",
            f"            inst: The bound instance ({self._inst_type})",
            "",
            "        Returns:",
            "            str: Next state name to transition to",
            "            None: Stay in current state",
            "            True: Success (stay)",
            "            False: Failure (for behavior trees)",
            '        """',
            "<__begin__>",  # Placeholder for visible code
        ]

        return "\n".join(lines)

    def get_state_code(self) -> str:
        """
        Get the edited code (function body only, without indentation).

        Returns:
            The code without the 8-space prefix
        """
        full_code = self.get_code()
        lines = full_code.split('\n')

        # Remove 8-space prefix from each line
        result_lines = []
        for line in lines:
            if line.startswith("        "):
                result_lines.append(line[8:])
            elif line.startswith("\t"):
                # Handle tab case
                result_lines.append(line[1:])
            else:
                result_lines.append(line)

        return '\n'.join(result_lines)


class StageEditorDialog(QDialog):
    """
    Dialog for editing Stage/Logic state methods.

    Provides a modal dialog with StageEditor for editing state code.
    """

    def __init__(
        self,
        stage_class: Type[Stage],
        state_name: str,
        initial_code: str = "",
        doc: str = "",
        parent: QWidget | None = None
    ):
        """
        Initialize the editor dialog.

        Args:
            stage_class: The Stage/Logic class
            state_name: Name of the state being edited
            initial_code: Initial code content
            doc: Documentation string for the state
            parent: Parent widget
        """
        super().__init__(parent)

        self._stage_class = stage_class
        self._state_name = state_name
        self._doc = doc
        self._saved_code: str = ""

        self.setWindowTitle(f"Edit State: {state_name}")
        self.setMinimumSize(900, 700)
        self.resize(1000, 750)

        self._setup_ui()
        self._setup_editor(initial_code)

    def _setup_ui(self) -> None:
        """Setup the dialog UI."""
        self.setStyleSheet("""
            QDialog {
                background-color: #f5f5f5;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        # Header with doc
        if self._doc:
            doc_label = QLabel(f"Documentation: {self._doc}")
            doc_label.setStyleSheet("""
                QLabel {
                    color: #666;
                    font-size: 12px;
                    padding: 5px;
                    background-color: #e8e8e8;
                    border-radius: 4px;
                }
            """)
            doc_label.setWordWrap(True)
            layout.addWidget(doc_label)

        # Editor
        self._editor = StageEditor()
        layout.addWidget(self._editor, stretch=1)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()

        self._btn_save = QPushButton("Save")
        self._btn_save.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 8px 24px;
                font-weight: bold;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        self._btn_save.clicked.connect(self._on_save)

        self._btn_cancel = QPushButton("Cancel")
        self._btn_cancel.setStyleSheet("""
            QPushButton {
                background-color: #757575;
                color: white;
                padding: 8px 24px;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #616161;
            }
        """)
        self._btn_cancel.clicked.connect(self.reject)

        btn_layout.addWidget(self._btn_cancel)
        btn_layout.addWidget(self._btn_save)

        layout.addLayout(btn_layout)

    def _setup_editor(self, initial_code: str) -> None:
        """Setup the editor with context and initial code."""
        self._editor.set_stage_context(
            self._stage_class,
            self._state_name
        )

        if initial_code:
            self._editor.set_code(initial_code)

    def _on_save(self) -> None:
        """Handle save button click."""
        self._saved_code = self._editor.get_state_code()
        self.accept()

    def get_code(self) -> str:
        """Get the edited code."""
        return self._saved_code


class StageEditorFactory:
    """Factory for creating StageEditor instances."""

    @staticmethod
    def create_editor(
        stage_class: Type[Stage],
        state_name: str,
        initial_code: str = "",
        parent: QWidget | None = None
    ) -> StageEditor:
        """
        Create a configured StageEditor.

        Args:
            stage_class: The Stage/Logic class
            state_name: Name of the state being edited
            initial_code: Initial code content
            parent: Parent widget

        Returns:
            Configured StageEditor instance
        """
        editor = StageEditor(parent)
        editor.set_stage_context(stage_class, state_name)

        if initial_code:
            editor.set_code(initial_code)

        return editor

    @staticmethod
    def edit_state(
        stage_class: Type[Stage],
        state_name: str,
        initial_code: str = "",
        doc: str = "",
        parent: QWidget | None = None
    ) -> str | None:
        """
        Open a modal dialog to edit a state method.

        Args:
            stage_class: The Stage/Logic class
            state_name: Name of the state being edited
            initial_code: Initial code content
            doc: Documentation string
            parent: Parent widget

        Returns:
            The edited code if saved, None if cancelled
        """
        dialog = StageEditorDialog(
            stage_class=stage_class,
            state_name=state_name,
            initial_code=initial_code,
            doc=doc,
            parent=parent
        )

        if dialog.exec() == QDialog.DialogCode.Accepted:
            return dialog.get_code()
        return None


# Convenience function
def edit_state(
    stage_class: Type[Stage],
    state_name: str,
    initial_code: str = "",
    doc: str = "",
    parent: QWidget | None = None
) -> str | None:
    """
    Open a modal dialog to edit a state method.

    Args:
        stage_class: The Stage/Logic class
        state_name: Name of the state being edited
        initial_code: Initial code content
        doc: Documentation string
        parent: Parent widget

    Returns:
        The edited code if saved, None if cancelled
    """
    return StageEditorFactory.edit_state(
        stage_class, state_name, initial_code, doc, parent
    )


__all__ = [
    "StageEditor",
    "StageEditorDialog",
    "StageEditorFactory",
    "edit_state",
]
