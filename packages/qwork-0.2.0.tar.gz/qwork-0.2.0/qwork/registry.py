"""
Registry module for qwork - provides registration mechanism for classes and functions.
"""

import inspect
import sys
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set, Type, Union, get_type_hints


@dataclass(frozen=True)
class MethodInfo:
    """Information about a class method."""
    name: str
    doc: Optional[str]
    signature: str
    params: List[Dict[str, Any]] = field(default_factory=list)


@dataclass(frozen=True)
class PropertyInfo:
    """Information about a class property."""
    name: str
    doc: Optional[str]


@dataclass(frozen=True)
class ConstantInfo:
    """Information about a class constant (ALL UPPERCASE)."""
    name: str
    value: Any


@dataclass(frozen=True)
class ClassInfo:
    """Information about a registered class."""
    name: str
    module: str
    bases: List[str]
    doc: Optional[str]
    methods: List[MethodInfo] = field(default_factory=list)
    properties: List[PropertyInfo] = field(default_factory=list)
    constants: List[ConstantInfo] = field(default_factory=list)
    is_dataclass: bool = False


@dataclass(frozen=True)
class ParameterInfo:
    """Information about a function/method parameter."""
    name: str
    kind: str  # POSITIONAL_ONLY, POSITIONAL_OR_KEYWORD, VAR_POSITIONAL, KEYWORD_ONLY, VAR_KEYWORD
    default: Any = field(default=inspect.Parameter.empty)
    annotation: Any = field(default=inspect.Parameter.empty)

    def __post_init__(self):
        # Convert inspect.Parameter constants to string for serialization
        if self.kind == inspect.Parameter.VAR_POSITIONAL:
            object.__setattr__(self, 'kind', 'VAR_POSITIONAL')
        elif self.kind == inspect.Parameter.VAR_KEYWORD:
            object.__setattr__(self, 'kind', 'VAR_KEYWORD')
        elif self.kind == inspect.Parameter.POSITIONAL_ONLY:
            object.__setattr__(self, 'kind', 'POSITIONAL_ONLY')
        elif self.kind == inspect.Parameter.KEYWORD_ONLY:
            object.__setattr__(self, 'kind', 'KEYWORD_ONLY')
        elif self.kind == inspect.Parameter.POSITIONAL_OR_KEYWORD:
            object.__setattr__(self, 'kind', 'POSITIONAL_OR_KEYWORD')


@dataclass(frozen=True)
class FunctionInfo:
    """Information about a registered function."""
    name: str
    module: str
    doc: Optional[str]
    signature: str
    parameters: List[ParameterInfo] = field(default_factory=list)
    return_annotation: Any = field(default=inspect.Parameter.empty)
    is_method: bool = False
    is_classmethod: bool = False
    is_staticmethod: bool = False
    is_property: bool = False


class Registry:
    """
    Central registry for qwork modules to register their classes and functions.

    Usage:
        # In a module's __init__.py:
        from qwork import registry

        registry.register_class(MyClass)
        registry.register_function(my_function)
    """

    def __init__(self):
        self._classes: Dict[str, Type] = {}
        self._functions: Dict[str, Callable] = {}
        self._class_info: Dict[str, ClassInfo] = {}
        self._function_info: Dict[str, FunctionInfo] = {}

    def register_class(self, cls: Type, name: Optional[str] = None) -> Type:
        """
        Register a class with the registry.

        Args:
            cls: The class to register
            name: Optional custom name (defaults to class __name__)

        Returns:
            The registered class (for use as decorator)
        """
        _key = name or cls.__name__
        self._classes[_key] = cls
        self._class_info[_key] = self._inspect_class(cls)
        return cls

    def register_function(self, func: Callable, name: Optional[str] = None) -> Callable:
        """
        Register a function with the registry.

        Args:
            func: The function to register
            name: Optional custom name (defaults to function __name__)

        Returns:
            The registered function (for use as decorator)
        """
        _key = name or func.__name__
        self._functions[_key] = func
        self._function_info[_key] = self._inspect_function(func, is_method=False)
        return func

    def _inspect_class(self, cls: Type) -> ClassInfo:
        """Inspect a class and return ClassInfo dataclass."""
        _methods = []

        for _name, _method in inspect.getmembers(cls, predicate=inspect.isfunction):
            if _name.startswith('_'):
                continue
            _methods.append(self._inspect_method(_name, _method))

        # Check for classmethod, staticmethod, property
        _properties = []
        for _name, _value in cls.__dict__.items():
            if _name.startswith('_'):
                continue
            if isinstance(_value, classmethod):
                _methods.append(self._inspect_method(_name, _value.__func__, is_classmethod=True))
            elif isinstance(_value, staticmethod):
                _methods.append(self._inspect_method(_name, _value.__func__, is_staticmethod=True))
            elif isinstance(_value, property):
                _properties.append(PropertyInfo(
                    name=_name,
                    doc=_value.__doc__
                ))

        # Collect constants (ALL UPPERCASE attributes, excluding underscore prefix)
        _constants = []
        for _name, _value in cls.__dict__.items():
            if _name.startswith('_'):
                continue
            if _name.isupper() and not callable(_value) and not isinstance(_value, (staticmethod, classmethod, property)):
                _constants.append(ConstantInfo(
                    name=_name,
                    value=_value
                ))

        return ClassInfo(
            name=cls.__name__,
            module=cls.__module__,
            bases=[b.__name__ for b in cls.__bases__ if b != object],
            doc=cls.__doc__,
            methods=_methods,
            properties=_properties,
            constants=_constants,
            is_dataclass=hasattr(cls, '__dataclass_fields__')
        )

    def _inspect_method(self, name: str, method: Callable, is_classmethod: bool = False,
                        is_staticmethod: bool = False) -> MethodInfo:
        """Inspect a method and return MethodInfo."""
        _sig = inspect.signature(method)
        _params = []

        for _pname, _param in _sig.parameters.items():
            if _pname == 'self' or _pname == 'cls':
                continue
            _params.append({
                'name': _pname,
                'kind': str(_param.kind).split('.')[-1],
                'default': _param.default if _param.default != inspect.Parameter.empty else None,
                'annotation': _param.annotation if _param.annotation != inspect.Parameter.empty else None
            })

        return MethodInfo(
            name=name,
            doc=method.__doc__,
            signature=str(_sig),
            params=_params
        )

    def _inspect_function(self, func: Callable, is_method: bool = False) -> FunctionInfo:
        """Inspect a function and return FunctionInfo dataclass."""
        _sig = inspect.signature(func)
        _params = []

        for _pname, _param in _sig.parameters.items():
            _params.append(ParameterInfo(
                name=_pname,
                kind=_param.kind,
                default=_param.default if _param.default != inspect.Parameter.empty else inspect.Parameter.empty,
                annotation=_param.annotation if _param.annotation != inspect.Parameter.empty else inspect.Parameter.empty
            ))

        return FunctionInfo(
            name=func.__name__,
            module=func.__module__,
            doc=func.__doc__,
            signature=str(_sig),
            parameters=_params,
            return_annotation=_sig.return_annotation if _sig.return_annotation != inspect.Parameter.empty else inspect.Parameter.empty,
            is_method=is_method
        )

    def get_class(self, name: str) -> Optional[Type]:
        """Get a registered class by name."""
        return self._classes.get(name)

    def get_function(self, name: str) -> Optional[Callable]:
        """Get a registered function by name."""
        return self._functions.get(name)

    def get_class_info(self, name: str) -> Optional[ClassInfo]:
        """Get ClassInfo for a registered class."""
        return self._class_info.get(name)

    def get_function_info(self, name: str) -> Optional[FunctionInfo]:
        """Get FunctionInfo for a registered function."""
        return self._function_info.get(name)

    def list_classes(self) -> List[str]:
        """List all registered class names."""
        return list(self._classes.keys())

    def list_functions(self) -> List[str]:
        """List all registered function names."""
        return list(self._functions.keys())

    def is_registered(self, name: str) -> bool:
        """Check if a name is registered (class or function)."""
        return name in self._classes or name in self._functions

    def verify(self) -> Dict[str, Any]:
        """
        Verify all registered items are accessible and valid.

        Returns:
            Dict with 'valid' list and 'errors' list
        """
        _result = {'valid': [], 'errors': []}

        for _name, _cls in self._classes.items():
            try:
                # Verify class is importable and has correct info
                _info = self._class_info.get(_name)
                if _info is None:
                    _result['errors'].append(f"Class '{_name}' missing info")
                elif _info.name != _cls.__name__:
                    _result['errors'].append(f"Class '{_name}' name mismatch: {_info.name} vs {_cls.__name__}")
                else:
                    _result['valid'].append(f"Class: {_name}")
            except Exception as e:
                _result['errors'].append(f"Class '{_name}': {str(e)}")

        for _name, _func in self._functions.items():
            try:
                # Verify function is callable and has correct info
                if not callable(_func):
                    _result['errors'].append(f"Function '{_name}' is not callable")
                else:
                    _info = self._function_info.get(_name)
                    if _info is None:
                        _result['errors'].append(f"Function '{_name}' missing info")
                    elif _info.name != _func.__name__:
                        _result['errors'].append(f"Function '{_name}' name mismatch: {_info.name} vs {_func.__name__}")
                    else:
                        _result['valid'].append(f"Function: {_name}")
            except Exception as e:
                _result['errors'].append(f"Function '{_name}': {str(e)}")

        return _result

    def inspect_item(self, name: str) -> Union[ClassInfo, FunctionInfo, None]:
        """
        Inspect a registered item (class or function) and return its info.

        Args:
            name: The registered name

        Returns:
            ClassInfo or FunctionInfo, or None if not found
        """
        if _info := self._class_info.get(name):
            return _info
        return self._function_info.get(name)

    def clear(self):
        """Clear all registrations (mainly for testing)."""
        self._classes.clear()
        self._functions.clear()
        self._class_info.clear()
        self._function_info.clear()


# Global registry instance
registry = Registry()

# Convenience functions for module registration
def RegisterClass(cls: Optional[Type] = None, *, name: Optional[str] = None):
    """
    Decorator or function to register a class.

    Usage:
        @RegisterClass
        class MyClass: ...

        @RegisterClass(name="custom_name")
        class MyClass2: ...

        RegisterClass(MyClass3)
    """
    def _decorator(_cls):
        return registry.register_class(_cls, name)

    if cls is not None:
        return _decorator(cls)
    return _decorator


def RegisterFunction(func: Optional[Callable] = None, *, name: Optional[str] = None):
    """
    Decorator or function to register a function.

    Usage:
        @RegisterFunction
        def my_func(): ...

        @RegisterFunction(name="custom_name")
        def my_func2(): ...

        RegisterFunction(my_func3)
    """
    def _decorator(_func):
        return registry.register_function(_func, name)

    if func is not None:
        return _decorator(func)
    return _decorator


def VerifyRegistry() -> Dict[str, Any]:
    """Verify all registered items."""
    return registry.verify()


def InspectRegistered(name: str) -> Union[ClassInfo, FunctionInfo, None]:
    """Inspect a registered item by name."""
    return registry.inspect_item(name)


if __name__ == '__main__':
    from qwork.qentry import ShowRegistryExplorer
    ShowRegistryExplorer()
