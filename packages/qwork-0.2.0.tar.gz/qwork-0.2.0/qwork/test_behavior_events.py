"""
Test script for behavior tree events and visualization.
"""
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit
from PyQt6.QtCore import Qt, QTimer

from qwork.qfsm import Logic, sequence, selector, parallel
from qwork.qflow.qchart import QFlowChart


class TestLogic(Logic):
    """Test logic with behavior tree composites."""

    NAME = "TestLogic"

    def __init__(self):
        super().__init__()
        self.event_log = []

    def onChanged(self, src, dst, inst):
        """Track state changes."""
        self.event_log.append(f"onChanged: {src} -> {dst}")
        print(f"[Callback] onChanged: {src} -> {dst}")

    def start(self, inst):
        return "sequence_root"

    @sequence("action_a", "action_b", "action_c")
    def sequence_root(self, inst):
        """Sequence composite - executes children in order."""
        pass

    def action_a(self, inst):
        """First action - returns True (success)."""
        print("  [Executing action_a]")
        return True

    def action_b(self, inst):
        """Second action - returns True (success)."""
        print("  [Executing action_b]")
        return True

    def action_c(self, inst):
        """Third action - returns True (success)."""
        print("  [Executing action_c]")
        return True


class EventMonitor(QWidget):
    """Monitor to capture and display events."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Event Monitor")
        self.resize(400, 300)

        layout = QVBoxLayout(self)
        self.text = QTextEdit()
        self.text.setReadOnly(True)
        layout.addWidget(self.text)

        self.events = []

    def log_event(self, event_type, data):
        """Log an event."""
        state = data.get("new", "?")
        result = data.get("result", "N/A")
        evt_type = data.get("type", "state")
        msg = f"[{event_type}] state={state}, type={evt_type}, result={result}"
        self.events.append(msg)
        self.text.append(msg)
        print(f"[Event] {msg}")


def main():
    app = QApplication(sys.argv)

    # Create test logic
    logic = TestLogic()

    # Create flow chart
    chart = QFlowChart(stage=logic, show_controls=True)
    chart.setWindowTitle("Behavior Tree Event Test")
    chart.resize(800, 600)

    # Create event monitor
    monitor = EventMonitor()
    monitor.show()

    # Track event order
    event_order = []

    # Hook into the event bridge to capture events
    original_handler = chart._event_bridge._handler

    def event_handler(data):
        event_order.append({
            "new": data.get("new"),
            "old": data.get("old"),
            "type": data.get("type"),
            "result": data.get("result")
        })
        monitor.log_event("changed", data)
        original_handler(data)

    chart._event_bridge._handler = event_handler

    # Show chart
    chart.show()

    # Auto-step after short delay
    def auto_step():
        print("\n" + "="*60)
        print("Starting auto-step sequence...")
        print("="*60 + "\n")

        for i in range(10):
            QTimer.singleShot(i * 500, lambda: chart.doStep())

        # Print event order after execution
        def print_summary():
            print("\n" + "="*60)
            print("EVENT ORDER SUMMARY")
            print("="*60)

            behavior_events = [e for e in event_order if e.get("type") == "behavior"]

            print(f"\nTotal events: {len(event_order)}")
            print(f"Behavior events: {len(behavior_events)}")

            print("\nBehavior event sequence:")
            for i, evt in enumerate(behavior_events, 1):
                print(f"  {i}. {evt['old']} -> {evt['new']}, result={evt.get('result')}")

            # Verify order
            print("\nVerifying event order...")
            expected_sequence = [
                ("sequence_root", "action_a"),
                ("action_a", "action_b"),
                ("action_b", "action_c"),
                ("action_c", None)  # Final
            ]

            errors = []
            for i, (expected_from, expected_to) in enumerate(expected_sequence):
                if i >= len(behavior_events):
                    errors.append(f"Missing event {i}: expected {expected_from} -> {expected_to}")
                    continue

                actual = behavior_events[i]
                actual_from = actual.get("old")
                actual_to = actual.get("new")

                if actual_from != expected_from or actual_to != expected_to:
                    errors.append(f"Event {i} mismatch: expected {expected_from} -> {expected_to}, got {actual_from} -> {actual_to}")

            if errors:
                print("ERRORS:")
                for e in errors:
                    print(f"  - {e}")
            else:
                print("All events in correct order!")

        QTimer.singleShot(6000, print_summary)

    QTimer.singleShot(1000, auto_step)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
