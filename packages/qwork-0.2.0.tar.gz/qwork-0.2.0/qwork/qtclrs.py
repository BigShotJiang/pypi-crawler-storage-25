from PyQt6.QtGui import QColor

SNOW = QColor(255, 250, 250, 225)
GHOSTWHITE = QColor(248, 248, 255, 225)
WHITESMOKE = QColor(245, 245, 245, 225)
GAINSBORO = QColor(220, 220, 220, 225)
FLORALWHITE = QColor(255, 250, 240, 225)
OLDLACE = QColor(253, 245, 230, 225)
LINEN = QColor(250, 240, 230, 225)
ANTIQUEWHITE = QColor(250, 235, 215, 225)
PAPAYAWHIP = QColor(255, 239, 213, 225)
BLANCHEDALMOND = QColor(255, 235, 205, 225)
BISQUE = QColor(255, 228, 196, 225)
PEACHPUFF = QColor(255, 218, 185, 225)
NAVAJOWHITE = QColor(255, 222, 173, 225)
MOCCASIN = QColor(255, 228, 181, 225)
CORNSILK = QColor(255, 248, 220, 225)
IVORY = QColor(255, 255, 240, 225)
LEMONCHIFFON = QColor(255, 250, 205, 225)
SEASHELL = QColor(255, 245, 238, 225)
HONEYDEW = QColor(240, 255, 240, 225)
MINTCREAM = QColor(245, 255, 250, 225)
AZURE = QColor(240, 255, 255, 225)
ALICEBLUE = QColor(240, 248, 255, 225)
LAVENDER = QColor(230, 230, 250, 225)
LAVENDERBLUSH = QColor(255, 240, 245, 225)
MISTYROSE = QColor(255, 228, 225, 225)
WHITE = QColor(255, 255, 255, 225)
BLACK = QColor(0, 0, 0, 225)
DARKSLATEGRAY = QColor(47, 79, 79, 225)
DIMGREY = QColor(105, 105, 105, 225)
SLATEGREY = QColor(112, 128, 144, 225)
LIGHTSLATEGRAY = QColor(119, 136, 153, 225)
GREY = QColor(190, 190, 190, 225)
LIGHTGRAY = QColor(211, 211, 211, 225)
MIDNIGHTBLUE = QColor(25, 25, 112, 225)
NAVYBLUE = QColor(0, 0, 128, 225)
CORNFLOWERBLUE = QColor(100, 149, 237, 225)
DARKSLATEBLUE = QColor(72, 61, 139, 225)
SLATEBLUE = QColor(106, 90, 205, 225)
MEDIUMSLATEBLUE = QColor(123, 104, 238, 225)
LIGHTSLATEBLUE = QColor(132, 112, 255, 225)
MEDIUMBLUE = QColor(0, 0, 205, 225)
ROYALBLUE = QColor(65, 105, 225, 225)
BLUE = QColor(0, 0, 255, 225)
DODGERBLUE = QColor(30, 144, 255, 225)
DEEPSKYBLUE = QColor(0, 191, 255, 225)
SKYBLUE = QColor(135, 206, 235, 225)
LIGHTSKYBLUE = QColor(135, 206, 250, 225)
STEELBLUE = QColor(70, 130, 180, 225)
LIGHTSTEELBLUE = QColor(176, 196, 222, 225)
LIGHTBLUE = QColor(173, 216, 230, 225)
POWDERBLUE = QColor(176, 224, 230, 225)
PALETURQUOISE = QColor(175, 238, 238, 225)
DARKTURQUOISE = QColor(0, 206, 209, 225)
MEDIUMTURQUOISE = QColor(72, 209, 204, 225)
TURQUOISE = QColor(64, 224, 208, 225)
CYAN = QColor(0, 255, 255, 225)
LIGHTCYAN = QColor(224, 255, 255, 225)
CADETBLUE = QColor(95, 158, 160, 225)
MEDIUMAQUAMARINE = QColor(102, 205, 170, 225)
AQUAMARINE = QColor(127, 255, 212, 225)
DARKGREEN = QColor(0, 100, 0, 225)
DARKOLIVEGREEN = QColor(85, 107, 47, 225)
DARKSEAGREEN = QColor(143, 188, 143, 225)
SEAGREEN = QColor(46, 139, 87, 225)
MEDIUMSEAGREEN = QColor(60, 179, 113, 225)
LIGHTSEAGREEN = QColor(32, 178, 170, 225)
PALEGREEN = QColor(152, 251, 152, 225)
SPRINGGREEN = QColor(0, 255, 127, 225)
LAWNGREEN = QColor(124, 252, 0, 225)
GREEN = QColor(0, 255, 0, 225)
CHARTREUSE = QColor(127, 255, 0, 225)
MEDSPRINGGREEN = QColor(0, 250, 154, 225)
GREENYELLOW = QColor(173, 255, 47, 225)
LIMEGREEN = QColor(50, 205, 50, 225)
YELLOWGREEN = QColor(154, 205, 50, 225)
FORESTGREEN = QColor(34, 139, 34, 225)
OLIVEDRAB = QColor(107, 142, 35, 225)
DARKKHAKI = QColor(189, 183, 107, 225)
PALEGOLDENROD = QColor(238, 232, 170, 225)
LTGOLDENRODYELLO = QColor(250, 250, 210, 225)
LIGHTYELLOW = QColor(255, 255, 224, 225)
YELLOW = QColor(255, 255, 0, 225)
GOLD = QColor(255, 215, 0, 225)
LIGHTGOLDENROD = QColor(238, 221, 130, 225)
GOLDENROD = QColor(218, 165, 32, 225)
DARKGOLDENROD = QColor(184, 134, 11, 225)
ROSYBROWN = QColor(188, 143, 143, 225)
INDIANRED = QColor(205, 92, 92, 225)
SADDLEBROWN = QColor(139, 69, 19, 225)
SIENNA = QColor(160, 82, 45, 225)
PERU = QColor(205, 133, 63, 225)
BURLYWOOD = QColor(222, 184, 135, 225)
BEIGE = QColor(245, 245, 220, 225)
WHEAT = QColor(245, 222, 179, 225)
SANDYBROWN = QColor(244, 164, 96, 225)
TAN = QColor(210, 180, 140, 225)
CHOCOLATE = QColor(210, 105, 30, 225)
FIREBRICK = QColor(178, 34, 34, 225)
BROWN = QColor(165, 42, 42, 225)
DARKSALMON = QColor(233, 150, 122, 225)
SALMON = QColor(250, 128, 114, 225)
LIGHTSALMON = QColor(255, 160, 122, 225)
ORANGE = QColor(255, 165, 0, 225)
DARKORANGE = QColor(255, 140, 0, 225)
CORAL = QColor(255, 127, 80, 225)
LIGHTCORAL = QColor(240, 128, 128, 225)
TOMATO = QColor(255, 99, 71, 225)
ORANGERED = QColor(255, 69, 0, 225)
RED = QColor(255, 0, 0, 225)
HOTPINK = QColor(255, 105, 180, 225)
DEEPPINK = QColor(255, 20, 147, 225)
PINK = QColor(255, 192, 203, 225)
LIGHTPINK = QColor(255, 182, 193, 225)
PALEVIOLETRED = QColor(219, 112, 147, 225)
MAROON = QColor(176, 48, 96, 225)
MEDIUMVIOLETRED = QColor(199, 21, 133, 225)
VIOLETRED = QColor(208, 32, 144, 225)
MAGENTA = QColor(255, 0, 255, 225)
VIOLET = QColor(238, 130, 238, 225)
PLUM = QColor(221, 160, 221, 225)
ORCHID = QColor(218, 112, 214, 225)
MEDIUMORCHID = QColor(186, 85, 211, 225)
DARKORCHID = QColor(153, 50, 204, 225)
DARKVIOLET = QColor(148, 0, 211, 225)
BLUEVIOLET = QColor(138, 43, 226, 225)
PURPLE = QColor(160, 32, 240, 225)
MEDIUMPURPLE = QColor(147, 112, 219, 225)
THISTLE = QColor(216, 191, 216, 225)
SNOW1 = QColor(255, 250, 250, 225)
SNOW2 = QColor(238, 233, 233, 225)
SNOW3 = QColor(205, 201, 201, 225)
SNOW4 = QColor(139, 137, 137, 225)
SEASHELL1 = QColor(255, 245, 238, 225)
SEASHELL2 = QColor(238, 229, 222, 225)
SEASHELL3 = QColor(205, 197, 191, 225)
SEASHELL4 = QColor(139, 134, 130, 225)
ANTIQUEWHITE1 = QColor(255, 239, 219, 225)
ANTIQUEWHITE2 = QColor(238, 223, 204, 225)
ANTIQUEWHITE3 = QColor(205, 192, 176, 225)
ANTIQUEWHITE4 = QColor(139, 131, 120, 225)
BISQUE1 = QColor(255, 228, 196, 225)
BISQUE2 = QColor(238, 213, 183, 225)
BISQUE3 = QColor(205, 183, 158, 225)
BISQUE4 = QColor(139, 125, 107, 225)
PEACHPUFF1 = QColor(255, 218, 185, 225)
PEACHPUFF2 = QColor(238, 203, 173, 225)
PEACHPUFF3 = QColor(205, 175, 149, 225)
PEACHPUFF4 = QColor(139, 119, 101, 225)
NAVAJOWHITE1 = QColor(255, 222, 173, 225)
NAVAJOWHITE2 = QColor(238, 207, 161, 225)
NAVAJOWHITE3 = QColor(205, 179, 139, 225)
NAVAJOWHITE4 = QColor(139, 121, 94, 225)
LEMONCHIFFON1 = QColor(255, 250, 205, 225)
LEMONCHIFFON2 = QColor(238, 233, 191, 225)
LEMONCHIFFON3 = QColor(205, 201, 165, 225)
LEMONCHIFFON4 = QColor(139, 137, 112, 225)
CORNSILK1 = QColor(255, 248, 220, 225)
CORNSILK2 = QColor(238, 232, 205, 225)
CORNSILK3 = QColor(205, 200, 177, 225)
CORNSILK4 = QColor(139, 136, 120, 225)
IVORY1 = QColor(255, 255, 240, 225)
IVORY2 = QColor(238, 238, 224, 225)
IVORY3 = QColor(205, 205, 193, 225)
IVORY4 = QColor(139, 139, 131, 225)
HONEYDEW1 = QColor(240, 255, 240, 225)
HONEYDEW2 = QColor(224, 238, 224, 225)
HONEYDEW3 = QColor(193, 205, 193, 225)
HONEYDEW4 = QColor(131, 139, 131, 225)
LAVENDERBLUSH1 = QColor(255, 240, 245, 225)
LAVENDERBLUSH2 = QColor(238, 224, 229, 225)
LAVENDERBLUSH3 = QColor(205, 193, 197, 225)
LAVENDERBLUSH4 = QColor(139, 131, 134, 225)
MISTYROSE1 = QColor(255, 228, 225, 225)
MISTYROSE2 = QColor(238, 213, 210, 225)
MISTYROSE3 = QColor(205, 183, 181, 225)
MISTYROSE4 = QColor(139, 125, 123, 225)
AZURE1 = QColor(240, 255, 255, 225)
AZURE2 = QColor(224, 238, 238, 225)
AZURE3 = QColor(193, 205, 205, 225)
AZURE4 = QColor(131, 139, 139, 225)
SLATEBLUE1 = QColor(131, 111, 255, 225)
SLATEBLUE2 = QColor(122, 103, 238, 225)
SLATEBLUE3 = QColor(105, 89, 205, 225)
SLATEBLUE4 = QColor(71, 60, 139, 225)
ROYALBLUE1 = QColor(72, 118, 255, 225)
ROYALBLUE2 = QColor(67, 110, 238, 225)
ROYALBLUE3 = QColor(58, 95, 205, 225)
ROYALBLUE4 = QColor(39, 64, 139, 225)
BLUE1 = QColor(0, 0, 255, 225)
BLUE2 = QColor(0, 0, 238, 225)
BLUE3 = QColor(0, 0, 205, 225)
BLUE4 = QColor(0, 0, 139, 225)
DODGERBLUE1 = QColor(30, 144, 255, 225)
DODGERBLUE2 = QColor(28, 134, 238, 225)
DODGERBLUE3 = QColor(24, 116, 205, 225)
DODGERBLUE4 = QColor(16, 78, 139, 225)
STEELBLUE1 = QColor(99, 184, 255, 225)
STEELBLUE2 = QColor(92, 172, 238, 225)
STEELBLUE3 = QColor(79, 148, 205, 225)
STEELBLUE4 = QColor(54, 100, 139, 225)
DEEPSKYBLUE1 = QColor(0, 191, 255, 225)
DEEPSKYBLUE2 = QColor(0, 178, 238, 225)
DEEPSKYBLUE3 = QColor(0, 154, 205, 225)
DEEPSKYBLUE4 = QColor(0, 104, 139, 225)
SKYBLUE1 = QColor(135, 206, 255, 225)
SKYBLUE2 = QColor(126, 192, 238, 225)
SKYBLUE3 = QColor(108, 166, 205, 225)
SKYBLUE4 = QColor(74, 112, 139, 225)
LIGHTSKYBLUE1 = QColor(176, 226, 255, 225)
LIGHTSKYBLUE2 = QColor(164, 211, 238, 225)
LIGHTSKYBLUE3 = QColor(141, 182, 205, 225)
LIGHTSKYBLUE4 = QColor(96, 123, 139, 225)
SLATEGRAY1 = QColor(198, 226, 255, 225)
SLATEGRAY2 = QColor(185, 211, 238, 225)
SLATEGRAY3 = QColor(159, 182, 205, 225)
SLATEGRAY4 = QColor(108, 123, 139, 225)
LIGHTSTEELBLUE1 = QColor(202, 225, 255, 225)
LIGHTSTEELBLUE2 = QColor(188, 210, 238, 225)
LIGHTSTEELBLUE3 = QColor(162, 181, 205, 225)
LIGHTSTEELBLUE4 = QColor(110, 123, 139, 225)
LIGHTBLUE1 = QColor(191, 239, 255, 225)
LIGHTBLUE2 = QColor(178, 223, 238, 225)
LIGHTBLUE3 = QColor(154, 192, 205, 225)
LIGHTBLUE4 = QColor(104, 131, 139, 225)
LIGHTCYAN1 = QColor(224, 255, 255, 225)
LIGHTCYAN2 = QColor(209, 238, 238, 225)
LIGHTCYAN3 = QColor(180, 205, 205, 225)
LIGHTCYAN4 = QColor(122, 139, 139, 225)

# -------------------

LT_SNOW = QColor(255, 250, 250, 50)
LT_GHOSTWHITE = QColor(248, 248, 255, 50)
LT_WHITESMOKE = QColor(245, 245, 245, 50)
LT_GAINSBORO = QColor(220, 220, 220, 50)
LT_FLORALWHITE = QColor(255, 250, 240, 50)
LT_OLDLACE = QColor(253, 245, 230, 50)
LT_LINEN = QColor(250, 240, 230, 50)
LT_ANTIQUEWHITE = QColor(250, 235, 215, 50)
LT_PAPAYAWHIP = QColor(255, 239, 213, 50)
LT_BLANCHEDALMOND = QColor(255, 235, 205, 50)
LT_BISQUE = QColor(255, 228, 196, 50)
LT_PEACHPUFF = QColor(255, 218, 185, 50)
LT_NAVAJOWHITE = QColor(255, 222, 173, 50)
LT_MOCCASIN = QColor(255, 228, 181, 50)
LT_CORNSILK = QColor(255, 248, 220, 50)
LT_IVORY = QColor(255, 255, 240, 50)
LT_LEMONCHIFFON = QColor(255, 250, 205, 50)
LT_SEASHELL = QColor(255, 245, 238, 50)
LT_HONEYDEW = QColor(240, 255, 240, 50)
LT_MINTCREAM = QColor(245, 255, 250, 50)
LT_AZURE = QColor(240, 255, 255, 50)
LT_ALICEBLUE = QColor(240, 248, 255, 50)
LT_LAVENDER = QColor(230, 230, 250, 50)
LT_LAVENDERBLUSH = QColor(255, 240, 245, 50)
LT_MISTYROSE = QColor(255, 228, 225, 50)
LT_WHITE = QColor(255, 255, 255, 50)
LT_BLACK = QColor(0, 0, 0, 50)
LT_DARKSLATEGRAY = QColor(47, 79, 79, 50)
LT_DIMGREY = QColor(105, 105, 105, 50)
LT_SLATEGREY = QColor(112, 128, 144, 50)
LT_LIGHTSLATEGRAY = QColor(119, 136, 153, 50)
LT_GREY = QColor(190, 190, 190, 50)
LT_LIGHTGRAY = QColor(211, 211, 211, 50)
LT_MIDNIGHTBLUE = QColor(25, 25, 112, 50)
LT_NAVYBLUE = QColor(0, 0, 128, 50)
LT_CORNFLOWERBLUE = QColor(100, 149, 237, 50)
LT_DARKSLATEBLUE = QColor(72, 61, 139, 50)
LT_SLATEBLUE = QColor(106, 90, 205, 50)
LT_MEDIUMSLATEBLUE = QColor(123, 104, 238, 50)
LT_LIGHTSLATEBLUE = QColor(132, 112, 255, 50)
LT_MEDIUMBLUE = QColor(0, 0, 205, 50)
LT_ROYALBLUE = QColor(65, 105, 225, 50)
LT_BLUE = QColor(0, 0, 255, 50)
LT_DODGERBLUE = QColor(30, 144, 255, 50)
LT_DEEPSKYBLUE = QColor(0, 191, 255, 50)
LT_SKYBLUE = QColor(135, 206, 235, 50)
LT_LIGHTSKYBLUE = QColor(135, 206, 250, 50)
LT_STEELBLUE = QColor(70, 130, 180, 50)
LT_LIGHTSTEELBLUE = QColor(176, 196, 222, 50)
LT_LIGHTBLUE = QColor(173, 216, 230, 50)
LT_POWDERBLUE = QColor(176, 224, 230, 50)
LT_PALETURQUOISE = QColor(175, 238, 238, 50)
LT_DARKTURQUOISE = QColor(0, 206, 209, 50)
LT_MEDIUMTURQUOISE = QColor(72, 209, 204, 50)
LT_TURQUOISE = QColor(64, 224, 208, 50)
LT_CYAN = QColor(0, 255, 255, 50)
LT_LIGHTCYAN = QColor(224, 255, 255, 50)
LT_CADETBLUE = QColor(95, 158, 160, 50)
LT_MEDIUMAQUAMARINE = QColor(102, 205, 170, 50)
LT_AQUAMARINE = QColor(127, 255, 212, 50)
LT_DARKGREEN = QColor(0, 100, 0, 50)
LT_DARKOLIVEGREEN = QColor(85, 107, 47, 50)
LT_DARKSEAGREEN = QColor(143, 188, 143, 50)
LT_SEAGREEN = QColor(46, 139, 87, 50)
LT_MEDIUMSEAGREEN = QColor(60, 179, 113, 50)
LT_LIGHTSEAGREEN = QColor(32, 178, 170, 50)
LT_PALEGREEN = QColor(152, 251, 152, 50)
LT_SPRINGGREEN = QColor(0, 255, 127, 50)
LT_LAWNGREEN = QColor(124, 252, 0, 50)
LT_GREEN = QColor(0, 255, 0, 50)
LT_CHARTREUSE = QColor(127, 255, 0, 50)
LT_MEDSPRINGGREEN = QColor(0, 250, 154, 50)
LT_GREENYELLOW = QColor(173, 255, 47, 50)
LT_LIMEGREEN = QColor(50, 205, 50, 50)
LT_YELLOWGREEN = QColor(154, 205, 50, 50)
LT_FORESTGREEN = QColor(34, 139, 34, 50)
LT_OLIVEDRAB = QColor(107, 142, 35, 50)
LT_DARKKHAKI = QColor(189, 183, 107, 50)
LT_PALEGOLDENROD = QColor(238, 232, 170, 50)
LT_LTGOLDENRODYELLO = QColor(250, 250, 210, 50)
LT_LIGHTYELLOW = QColor(255, 255, 224, 50)
LT_YELLOW = QColor(255, 255, 0, 50)
LT_GOLD = QColor(255, 215, 0, 50)
LT_LIGHTGOLDENROD = QColor(238, 221, 130, 50)
LT_GOLDENROD = QColor(218, 165, 32, 50)
LT_DARKGOLDENROD = QColor(184, 134, 11, 50)
LT_ROSYBROWN = QColor(188, 143, 143, 50)
LT_INDIANRED = QColor(205, 92, 92, 50)
LT_SADDLEBROWN = QColor(139, 69, 19, 50)
LT_SIENNA = QColor(160, 82, 45, 50)
LT_PERU = QColor(205, 133, 63, 50)
LT_BURLYWOOD = QColor(222, 184, 135, 50)
LT_BEIGE = QColor(245, 245, 220, 50)
LT_WHEAT = QColor(245, 222, 179, 50)
LT_SANDYBROWN = QColor(244, 164, 96, 50)
LT_TAN = QColor(210, 180, 140, 50)
LT_CHOCOLATE = QColor(210, 105, 30, 50)
LT_FIREBRICK = QColor(178, 34, 34, 50)
LT_BROWN = QColor(165, 42, 42, 50)
LT_DARKSALMON = QColor(233, 150, 122, 50)
LT_SALMON = QColor(250, 128, 114, 50)
LT_LIGHTSALMON = QColor(255, 160, 122, 50)
LT_ORANGE = QColor(255, 165, 0, 50)
LT_DARKORANGE = QColor(255, 140, 0, 50)
LT_CORAL = QColor(255, 127, 80, 50)
LT_LIGHTCORAL = QColor(240, 128, 128, 50)
LT_TOMATO = QColor(255, 99, 71, 50)
LT_ORANGERED = QColor(255, 69, 0, 50)
LT_RED = QColor(255, 0, 0, 50)
LT_HOTPINK = QColor(255, 105, 180, 50)
LT_DEEPPINK = QColor(255, 20, 147, 50)
LT_PINK = QColor(255, 192, 203, 50)
LT_LIGHTPINK = QColor(255, 182, 193, 50)
LT_PALEVIOLETRED = QColor(219, 112, 147, 50)
LT_MAROON = QColor(176, 48, 96, 50)
LT_MEDIUMVIOLETRED = QColor(199, 21, 133, 50)
LT_VIOLETRED = QColor(208, 32, 144, 50)
LT_MAGENTA = QColor(255, 0, 255, 50)
LT_VIOLET = QColor(238, 130, 238, 50)
LT_PLUM = QColor(221, 160, 221, 50)
LT_ORCHID = QColor(218, 112, 214, 50)
LT_MEDIUMORCHID = QColor(186, 85, 211, 50)
LT_DARKORCHID = QColor(153, 50, 204, 50)
LT_DARKVIOLET = QColor(148, 0, 211, 50)
LT_BLUEVIOLET = QColor(138, 43, 226, 50)
LT_PURPLE = QColor(160, 32, 240, 50)
LT_MEDIUMPURPLE = QColor(147, 112, 219, 50)
LT_THISTLE = QColor(216, 191, 216, 50)
LT_SNOW1 = QColor(255, 250, 250, 50)
LT_SNOW2 = QColor(238, 233, 233, 50)
LT_SNOW3 = QColor(205, 201, 201, 50)
LT_SNOW4 = QColor(139, 137, 137, 50)
LT_SEASHELL1 = QColor(255, 245, 238, 50)
LT_SEASHELL2 = QColor(238, 229, 222, 50)
LT_SEASHELL3 = QColor(205, 197, 191, 50)
LT_SEASHELL4 = QColor(139, 134, 130, 50)
LT_ANTIQUEWHITE1 = QColor(255, 239, 219, 50)
LT_ANTIQUEWHITE2 = QColor(238, 223, 204, 50)
LT_ANTIQUEWHITE3 = QColor(205, 192, 176, 50)
LT_ANTIQUEWHITE4 = QColor(139, 131, 120, 50)
LT_BISQUE1 = QColor(255, 228, 196, 50)
LT_BISQUE2 = QColor(238, 213, 183, 50)
LT_BISQUE3 = QColor(205, 183, 158, 50)
LT_BISQUE4 = QColor(139, 125, 107, 50)
LT_PEACHPUFF1 = QColor(255, 218, 185, 50)
LT_PEACHPUFF2 = QColor(238, 203, 173, 50)
LT_PEACHPUFF3 = QColor(205, 175, 149, 50)
LT_PEACHPUFF4 = QColor(139, 119, 101, 50)
LT_NAVAJOWHITE1 = QColor(255, 222, 173, 50)
LT_NAVAJOWHITE2 = QColor(238, 207, 161, 50)
LT_NAVAJOWHITE3 = QColor(205, 179, 139, 50)
LT_NAVAJOWHITE4 = QColor(139, 121, 94, 50)
LT_LEMONCHIFFON1 = QColor(255, 250, 205, 50)
LT_LEMONCHIFFON2 = QColor(238, 233, 191, 50)
LT_LEMONCHIFFON3 = QColor(205, 201, 165, 50)
LT_LEMONCHIFFON4 = QColor(139, 137, 112, 50)
LT_CORNSILK1 = QColor(255, 248, 220, 50)
LT_CORNSILK2 = QColor(238, 232, 205, 50)
LT_CORNSILK3 = QColor(205, 200, 177, 50)
LT_CORNSILK4 = QColor(139, 136, 120, 50)
LT_IVORY1 = QColor(255, 255, 240, 50)
LT_IVORY2 = QColor(238, 238, 224, 50)
LT_IVORY3 = QColor(205, 205, 193, 50)
LT_IVORY4 = QColor(139, 139, 131, 50)
LT_HONEYDEW1 = QColor(240, 255, 240, 50)
LT_HONEYDEW2 = QColor(224, 238, 224, 50)
LT_HONEYDEW3 = QColor(193, 205, 193, 50)
LT_HONEYDEW4 = QColor(131, 139, 131, 50)
LT_LAVENDERBLUSH1 = QColor(255, 240, 245, 50)
LT_LAVENDERBLUSH2 = QColor(238, 224, 229, 50)
LT_LAVENDERBLUSH3 = QColor(205, 193, 197, 50)
LT_LAVENDERBLUSH4 = QColor(139, 131, 134, 50)
LT_MISTYROSE1 = QColor(255, 228, 225, 50)
LT_MISTYROSE2 = QColor(238, 213, 210, 50)
LT_MISTYROSE3 = QColor(205, 183, 181, 50)
LT_MISTYROSE4 = QColor(139, 125, 123, 50)
LT_AZURE1 = QColor(240, 255, 255, 50)
LT_AZURE2 = QColor(224, 238, 238, 50)
LT_AZURE3 = QColor(193, 205, 205, 50)
LT_AZURE4 = QColor(131, 139, 139, 50)
LT_SLATEBLUE1 = QColor(131, 111, 255, 50)
LT_SLATEBLUE2 = QColor(122, 103, 238, 50)
LT_SLATEBLUE3 = QColor(105, 89, 205, 50)
LT_SLATEBLUE4 = QColor(71, 60, 139, 50)
LT_ROYALBLUE1 = QColor(72, 118, 255, 50)
LT_ROYALBLUE2 = QColor(67, 110, 238, 50)
LT_ROYALBLUE3 = QColor(58, 95, 205, 50)
LT_ROYALBLUE4 = QColor(39, 64, 139, 50)
LT_BLUE1 = QColor(0, 0, 255, 50)
LT_BLUE2 = QColor(0, 0, 238, 50)
LT_BLUE3 = QColor(0, 0, 205, 50)
LT_BLUE4 = QColor(0, 0, 139, 50)
LT_DODGERBLUE1 = QColor(30, 144, 255, 50)
LT_DODGERBLUE2 = QColor(28, 134, 238, 50)
LT_DODGERBLUE3 = QColor(24, 116, 205, 50)
LT_DODGERBLUE4 = QColor(16, 78, 139, 50)
LT_STEELBLUE1 = QColor(99, 184, 255, 50)
LT_STEELBLUE2 = QColor(92, 172, 238, 50)
LT_STEELBLUE3 = QColor(79, 148, 205, 50)
LT_STEELBLUE4 = QColor(54, 100, 139, 50)
LT_DEEPSKYBLUE1 = QColor(0, 191, 255, 50)
LT_DEEPSKYBLUE2 = QColor(0, 178, 238, 50)
LT_DEEPSKYBLUE3 = QColor(0, 154, 205, 50)
LT_DEEPSKYBLUE4 = QColor(0, 104, 139, 50)
LT_SKYBLUE1 = QColor(135, 206, 255, 50)
LT_SKYBLUE2 = QColor(126, 192, 238, 50)
LT_SKYBLUE3 = QColor(108, 166, 205, 50)
LT_SKYBLUE4 = QColor(74, 112, 139, 50)
LT_LIGHTSKYBLUE1 = QColor(176, 226, 255, 50)
LT_LIGHTSKYBLUE2 = QColor(164, 211, 238, 50)
LT_LIGHTSKYBLUE3 = QColor(141, 182, 205, 50)
LT_LIGHTSKYBLUE4 = QColor(96, 123, 139, 50)
LT_SLATEGRAY1 = QColor(198, 226, 255, 50)
LT_SLATEGRAY2 = QColor(185, 211, 238, 50)
LT_SLATEGRAY3 = QColor(159, 182, 205, 50)
LT_SLATEGRAY4 = QColor(108, 123, 139, 50)
LT_LIGHTSTEELBLUE1 = QColor(202, 225, 255, 50)
LT_LIGHTSTEELBLUE2 = QColor(188, 210, 238, 50)
LT_LIGHTSTEELBLUE3 = QColor(162, 181, 205, 50)
LT_LIGHTSTEELBLUE4 = QColor(110, 123, 139, 50)
LT_LIGHTBLUE1 = QColor(191, 239, 255, 50)
LT_LIGHTBLUE2 = QColor(178, 223, 238, 50)
LT_LIGHTBLUE3 = QColor(154, 192, 205, 50)
LT_LIGHTBLUE4 = QColor(104, 131, 139, 50)
LT_LIGHTCYAN1 = QColor(224, 255, 255, 50)
LT_LIGHTCYAN2 = QColor(209, 238, 238, 50)
LT_LIGHTCYAN3 = QColor(180, 205, 205, 50)
LT_LIGHTCYAN4 = QColor(122, 139, 139, 50)


# =============================================================================
# Color Gallery UI
# =============================================================================

def ShowColorGallery() -> None:
    """
    Open color library display UI

    Features:
    - Auto column layout: one extra column per 300px width
    - Each color shows: name label + hex label (black text, #xxxxxx) + color block
    - Scroll bar support
    - Default size: 1200x800

    Usage:
        from qwork.qtclrs import ShowColorGallery
        ShowColorGallery()
    """
    import sys
    import importlib
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout,
        QHBoxLayout, QLabel, QScrollArea, QFrame
    )
    from PyQt6.QtCore import Qt
    from PyQt6.QtGui import QFont

    # Dynamically import current module to get color definitions
    _mod = importlib.import_module('qwork.qtclrs')

    # Get all color definitions from module
    _color_map = {}
    for _name in dir(_mod):
        if not _name.startswith('_') and _name.isupper():
            _val = getattr(_mod, _name)
            if isinstance(_val, QColor):
                _color_map[_name] = _val

    print(f"[ShowColorGallery] Found {len(_color_map)} colors")

    # Sort colors by hue (color spectrum)
    def _get_hue(item):
        _color = item[1]
        return _color.hue() if _color.hue() >= 0 else 360  # -1 for achromatic colors

    _all_colors = sorted(_color_map.items(), key=_get_hue)

    class ColorGallery(QMainWindow):
        # Layout constants
        ITEM_WIDTH = 328           # Single color item width (calculated from widgets)
        COL_SPACING = 20           # Spacing between columns
        MARGIN = 20                # Main layout left/right margin
        MIN_COLS = 1               # Minimum columns

        def __init__(self):
            super().__init__()
            self.setWindowTitle("QWork Color Gallery")

            # Calculate minimum window width (single column + margins)
            _min_width = self.ITEM_WIDTH + 2 * self.MARGIN
            self.setMinimumWidth(_min_width)
            self.setGeometry(100, 100, 1500, 800)

            # Store colors for relayout
            self._colors = _all_colors
            self._cols_layout = None
            self._container = None

            # Central widget with scroll area
            _scroll = QScrollArea()
            _scroll.setWidgetResizable(True)
            self.setCentralWidget(_scroll)

            # Container widget
            self._container = QWidget()
            _scroll.setWidget(self._container)

            # Main layout
            self._main_layout = QVBoxLayout(self._container)
            self._main_layout.setSpacing(10)
            self._main_layout.setContentsMargins(self.MARGIN, 20, self.MARGIN, 20)

            # Initial layout
            self._DoLayout()

        def resizeEvent(self, event):
            """Handle resize to recalculate columns"""
            super().resizeEvent(event)
            self._DoLayout()

        def _CalcCols(self) -> int:
            """Calculate optimal column count based on window width"""
            _avail_width = self.width() - 2 * self.MARGIN
            _cols = 1
            while True:
                _needed = _cols * self.ITEM_WIDTH + (_cols - 1) * self.COL_SPACING
                if _needed > _avail_width:
                    return max(self.MIN_COLS, _cols - 1)
                _cols += 1
                # Safety limit
                if _cols > 20:
                    return 20

        def _DoLayout(self):
            """Create/refresh column layout"""
            # Calculate columns
            _cols = self._CalcCols()

            # Check if column count changed
            if hasattr(self, '_current_cols') and self._current_cols == _cols:
                return
            self._current_cols = _cols

            # Remove old layout if exists
            if self._cols_layout is not None:
                # Remove all widgets from layout
                while self._cols_layout.count():
                    _item = self._cols_layout.takeAt(0)
                    if _item.widget():
                        _item.widget().deleteLater()
                self._main_layout.removeItem(self._cols_layout)
                self._cols_layout.deleteLater()

            # Create new columns layout
            self._cols_layout = QHBoxLayout()
            self._cols_layout.setSpacing(self.COL_SPACING)

            # Split colors into columns
            _per_col = len(self._colors) // _cols + 1
            for _i in range(_cols):
                _col_widget = QWidget()
                _col_layout = QVBoxLayout(_col_widget)
                _col_layout.setSpacing(4)
                _col_layout.setContentsMargins(0, 0, 0, 0)

                _start = _i * _per_col
                _end = min(_start + _per_col, len(self._colors))

                for _name, _color in self._colors[_start:_end]:
                    _item = self._CreateColorItem(_name, _color)
                    _col_layout.addWidget(_item)

                _col_layout.addStretch()
                self._cols_layout.addWidget(_col_widget)

            self._main_layout.addLayout(self._cols_layout)

        def _CreateColorItem(self, name: str, color: QColor) -> QFrame:
            """Create single color display item with copy buttons"""
            _frame = QFrame()
            _frame.setFrameShape(QFrame.Shape.StyledPanel)
            _frame.setFixedHeight(32)

            _layout = QHBoxLayout(_frame)
            _layout.setContentsMargins(4, 2, 8, 2)
            _layout.setSpacing(6)

            from PyQt6.QtWidgets import QPushButton

            # Common button style
            _btn_style = """
                QPushButton {
                    background-color: #ffffff;
                    border: 1px solid #cccccc;
                    border-radius: 4px;
                    padding: 2px;
                }
                QPushButton:hover {
                    background-color: #f5f5f5;
                    border-color: #aaaaaa;
                }
                QPushButton:pressed {
                    background-color: #e8e8e8;
                }
            """

            # Copy button 1: copy color name (leftmost)
            _copy_name_btn = QPushButton("📄")
            _copy_name_btn.setFixedSize(24, 24)
            _copy_name_btn.setToolTip("Copy color name")
            _copy_name_btn.setStyleSheet(_btn_style)
            _copy_name_btn.clicked.connect(lambda checked, n=name: self._CopyToClipboard(n))

            # Name label
            _name_label = QLabel(name)
            _name_label.setFixedWidth(140)
            _name_font = QFont("Consolas", 9)
            _name_label.setFont(_name_font)

            # Copy button 2: copy hex value (left of hex label)
            _hex_val = f"#{color.red():02X}{color.green():02X}{color.blue():02X}"
            _copy_hex_btn = QPushButton("📄")
            _copy_hex_btn.setFixedSize(24, 24)
            _copy_hex_btn.setToolTip("Copy hex code")
            _copy_hex_btn.setStyleSheet(_btn_style)
            _copy_hex_btn.clicked.connect(lambda checked, h=_hex_val: self._CopyToClipboard(h))

            # Hex label (black text)
            _hex_label = QLabel(_hex_val)
            _hex_label.setFixedWidth(70)
            _hex_label.setStyleSheet("color: black;")
            _hex_font = QFont("Consolas", 9)
            _hex_label.setFont(_hex_font)

            # Color block
            _block = QLabel()
            _block.setFixedSize(40, 20)
            _block.setStyleSheet(
                f"background-color: {_hex_val}; "
                f"border: 1px solid #888888;"
            )

            _layout.addWidget(_copy_name_btn)   # Copy color name
            _layout.addWidget(_name_label)
            _layout.addWidget(_copy_hex_btn)    # Copy hex
            _layout.addWidget(_hex_label)
            _layout.addWidget(_block)
            _layout.addStretch()

            return _frame

        def _CopyToClipboard(self, text: str) -> None:
            """Copy text to clipboard"""
            _app = QApplication.instance()
            if _app:
                _app.clipboard().setText(text)

    # Create and show app
    _app = QApplication.instance()
    if _app is None:
        _app = QApplication(sys.argv)

    _gallery = ColorGallery()
    _gallery.show()

    # If no existing app, run event loop
    if not QApplication.instance() or QApplication.instance().topLevelWidgets() == [_gallery]:
        _app.exec()

if __name__ == '__main__':
    ShowColorGallery()
