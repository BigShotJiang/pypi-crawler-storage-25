from __future__ import annotations
"""stdio compatibility module for qfsm.

This module provides a compatibility layer for the std.info/std.error/std.warn
functions used in the old version of qfsm.
"""

# Color codes for terminal output
class Colors:
    RESET = "\033[0m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    BRIGHT = "\033[1m"


def info(tag: str, message: str, extra: str = "") -> None:
    """Print info message.

    Args:
        tag: Message tag/source (e.g., "LogicName.fbm")
        message: Main message content
        extra: Extra information to append
    """
    if extra:
        print(f"[{tag}] {message} {extra}")
    else:
        print(f"[{tag}] {message}")


def error(tag: str, message: str, *args) -> None:
    """Print error message.

    Args:
        tag: Message tag/source
        message: Error message
        *args: Additional arguments to print
    """
    msg = f"[{tag}] {message}"
    if args:
        msg += " " + " ".join(str(a) for a in args)
    print(msg)


def warn(tag: str, message: str) -> None:
    """Print warning message.

    Args:
        tag: Message tag/source
        message: Warning message
    """
    print(f"[{tag}] {message}")


def debug(tag: str, message: str) -> None:
    """Print debug message.

    Args:
        tag: Message tag/source
        message: Debug message
    """
    print(f"[{tag}] {message}")
