"""Tests for EventSystem"""

import pytest
from qwork.qfsm.utils import EventSystem


class TestEventSystemBasic:
    """Test basic EventSystem functionality"""
    
    def test_listen_for_event(self):
        """Test listenFor registers callback"""
        es = EventSystem()
        
        called = False
        
        def handler(data):
            nonlocal called
            called = True
        
        es.listenFor("test_event", handler)
        es.pushEvent("test_event", {})
        
        assert called
    
    def test_multiple_handlers(self):
        """Test multiple handlers for same event"""
        es = EventSystem()
        
        calls = []
        
        def handler1(data):
            calls.append(1)
        
        def handler2(data):
            calls.append(2)
        
        es.listenFor("test_event", handler1)
        es.listenFor("test_event", handler2)
        es.pushEvent("test_event", {})
        
        assert 1 in calls
        assert 2 in calls
    
    def test_cancel_listen(self):
        """Test cancelListen removes callback"""
        es = EventSystem()
        
        called = False
        
        def handler(data):
            nonlocal called
            called = True
        
        es.listenFor("test_event", handler)
        es.cancelListen("test_event", handler)
        es.pushEvent("test_event", {})
        
        assert not called
    
    def test_cancel_all_listeners(self):
        """Test cancelListen without handler removes all"""
        es = EventSystem()
        
        calls = []
        
        def handler1(data):
            calls.append(1)
        
        def handler2(data):
            calls.append(2)
        
        es.listenFor("test_event", handler1)
        es.listenFor("test_event", handler2)
        es.cancelListen("test_event")
        es.pushEvent("test_event", {})
        
        assert len(calls) == 0


class TestEventSystemSourceFiltering:
    """Test source filtering"""
    
    def test_source_filter_matching(self):
        """Test that events from matching sources are received"""
        es = EventSystem()
        
        calls = []
        
        def handler(data):
            calls.append(data)
        
        es.listenFor("test_event", handler, "source1", "source2")
        es.pushEvent("test_event", {"msg": "hello"}, source="source1")
        
        assert len(calls) == 1
        assert calls[0]["msg"] == "hello"
    
    def test_source_filter_non_matching(self):
        """Test that events from non-matching sources are filtered"""
        es = EventSystem()
        
        calls = []
        
        def handler(data):
            calls.append(data)
        
        es.listenFor("test_event", handler, "source1")
        es.pushEvent("test_event", {"msg": "hello"}, source="source2")
        
        assert len(calls) == 0
    
    def test_no_source_filter_receives_all(self):
        """Test that listeners without source filter receive all"""
        es = EventSystem()
        
        calls = []
        
        def handler(data):
            calls.append(data)
        
        es.listenFor("test_event", handler)
        es.pushEvent("test_event", {"msg": "hello"}, source="any_source")
        
        assert len(calls) == 1


class TestEventSystemTargetFiltering:
    """Test target filtering"""
    
    def test_target_filter_matching(self):
        """Test that events with matching targets are received"""
        es = EventSystem()

        calls = []

        def handler(data):
            calls.append(data)

        es.listenFor("test_event", handler)
        # No targets specified means all listeners receive
        es.pushEvent("test_event", {"msg": "hello"})

        assert len(calls) == 1
    
    def test_data_passed_to_handler(self):
        """Test that data is passed to handler"""
        es = EventSystem()
        
        received_data = None
        
        def handler(data):
            nonlocal received_data
            received_data = data
        
        es.listenFor("test_event", handler)
        es.pushEvent("test_event", {"key": "value", "num": 42})
        
        assert received_data["key"] == "value"
        assert received_data["num"] == 42


class TestEventSystemEdgeCases:
    """Test edge cases"""
    
    def test_no_listeners(self):
        """Test that pushEvent with no listeners doesn't error"""
        es = EventSystem()
        
        es.pushEvent("test_event", {})  # Should not raise
    
    def test_unknown_event(self):
        """Test that pushEvent for unknown event doesn't error"""
        es = EventSystem()
        
        def handler(data):
            pass
        
        es.listenFor("other_event", handler)
        es.pushEvent("test_event", {})  # Should not raise
    
    def test_handler_exception(self):
        """Test that handler exception doesn't break system"""
        es = EventSystem()
        
        calls = []
        
        def bad_handler(data):
            raise ValueError("Test error")
        
        def good_handler(data):
            calls.append(data)
        
        es.listenFor("test_event", bad_handler)
        es.listenFor("test_event", good_handler)
        
        try:
            es.pushEvent("test_event", {})
        except:
            pass  # Exception might propagate
        
        # Good handler should still be called
        assert len(calls) == 1
