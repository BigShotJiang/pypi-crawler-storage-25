"""Tests for Logic class"""

from qwork.qfsm.meta import StageMachineMeta


import pytest
from qwork.qfsm.logic import Logic
from qwork.qfsm.scheduler import Scheduler
from qwork.qfsm.meta import clear_prototypes


@pytest.fixture(autouse=True)
def reset_state():
    """Reset state before each test"""
    Scheduler._instance = None
    clear_prototypes()
    Logic._Logic__names__ = {}
    Logic._Logic__types__ = {}
    StageMachineMeta.__ID_PROTOS__ = {}
    yield
    Scheduler._instance = None


class MockKnowledge:
    """Mock knowledge object"""
    pass


class TestLogicInit:
    """Test Logic initialization"""
    
    def test_logic_auto_registers(self):
        """Test that Logic auto-registers with Scheduler"""
        scheduler = Scheduler()
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic = TestLogic()
        
        assert logic in scheduler
    
    def test_logic_tracks_instances(self):
        """Test that Logic tracks instances by name"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic1 = TestLogic()
        logic2 = TestLogic()
        
        instances = Logic._Logic__names__.get("TestLogic", {})
        assert logic1.uid in instances
        assert logic2.uid in instances


class TestLogicLifecycle:
    """Test Logic lifecycle methods"""
    
    def test_check_method(self):
        """Test _check method"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic = TestLogic()
        
        assert logic._check(False) is True
    
    def test_enter_method(self):
        """Test _enter method calls onStart"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def __init__(self):
                self.started = False
                super().__init__()
            
            def my_state(self, inst):
                return None
            
            def onStart(self, it):
                self.started = True
        
        logic = TestLogic()
        logic._enter()
        
        assert logic.started
        assert logic._isEntered
    
    def test_step_method(self):
        """Test _step method calls handleStage and onStep"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def __init__(self):
                self.stepped = False
                super().__init__()
            
            def my_state(self, inst):
                return None
            
            def onStep(self, it):
                self.stepped = True
        
        logic = TestLogic()
        logic._current = "my_state"
        logic._step()
        
        assert logic.stepped
    
    def test_exit_method(self):
        """Test _exit method calls onStop"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def __init__(self):
                self.stopped = False
                super().__init__()
            
            def my_state(self, inst):
                return None
            
            def onStop(self, it):
                self.stopped = True
        
        logic = TestLogic()
        logic._exit()
        
        assert logic.stopped


class TestLogicProperties:
    """Test Logic properties"""
    
    def test_alive_property(self):
        """Test alive property"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic = TestLogic()
        
        assert logic.alive is True
        
        logic.alive = False
        
        assert logic.alive is False
    
    def test_enabled_property(self):
        """Test enabled property"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic = TestLogic()
        
        assert logic.enabled is True
        
        logic.enabled = False
        
        assert logic.enabled is False
    
    def test_uid_property(self):
        """Test uid property"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic1 = TestLogic()
        logic2 = TestLogic()
        
        assert logic1.uid == 0
        assert logic2.uid == 1
    
    def test_priority_property(self):
        """Test priority property"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            PRIORITY = 5
            
            def my_state(self, inst):
                return None
        
        logic = TestLogic()
        
        assert logic.priority == 5


class TestLogicRef:
    """Test Logic reference methods"""
    
    def test_ref_by_name(self):
        """Test ref() by base name returns list"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic1 = TestLogic()
        logic2 = TestLogic()
        
        refs = logic1.ref("TestLogic")

        assert isinstance(refs, list)
        assert logic1 in refs
        assert logic2 in refs

    def test_ref_by_full_name(self):
        """Test ref() by full name returns single instance"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic1 = TestLogic()
        logic2 = TestLogic()
        
        ref1 = logic1.ref("TestLogic0")
        ref2 = logic2.ref("TestLogic1")
        
        assert ref1 is logic1
        assert ref2 is logic2
    
    def test_ref_last(self):
        """Test refLast() returns previous instance"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic1 = TestLogic()
        logic2 = TestLogic()
        
        assert logic2.refLast() is logic1
        assert logic1.refLast() is None
    
    def test_ref_next(self):
        """Test refNext() returns next instance"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic1 = TestLogic()
        logic2 = TestLogic()
        
        assert logic1.refNext() is logic2
        assert logic2.refNext() is None
    
    def test_ref_adjacent(self):
        """Test refAdjacent() returns prev and next"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic1 = TestLogic()
        logic2 = TestLogic()
        logic3 = TestLogic()
        
        prev, next = logic2.refAdjacent()
        
        assert prev is logic1
        assert next is logic3
    
    def test_ref_head(self):
        """Test refHead() returns first instance"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic1 = TestLogic()
        logic2 = TestLogic()
        
        assert logic1.refHead() is logic1
    
    def test_ref_end(self):
        """Test refEnd() returns last instance"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic1 = TestLogic()
        logic2 = TestLogic()
        
        assert logic1.refEnd() is logic2


class TestLogicKill:
    """Test Logic kill functionality"""
    
    def test_kill_sets_alive_false(self):
        """Test kill() sets alive to False"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic = TestLogic()
        
        assert logic.alive is True
        
        logic.kill()
        
        assert logic.alive is False


class TestLogicControl:
    """Test Logic control methods"""
    
    def test_enable_disable(self):
        """Test enable() and disable() methods"""
        
        class TestLogic(Logic):
            NAME = "TestLogic"
            
            def my_state(self, inst):
                return None
        
        logic = TestLogic()
        
        assert logic.enabled is True
        
        logic.disable()
        
        assert logic.enabled is False
        
        logic.enable()
        
        assert logic.enabled is True
