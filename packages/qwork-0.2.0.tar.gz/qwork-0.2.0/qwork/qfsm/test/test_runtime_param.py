"""
测试状态方法的参数检查功能

验证内容：
1. 方法接受 inst 参数 - 应该传递 inst
2. 方法不接受任何参数 - 不应该传递 inst
3. 方法接受 *args - 应该传递 inst
4. 方法接受 **kwargs - 应该传递 inst
5. 缓存机制 - __runtime_paramable__ 应该被设置
6. 集成测试 - Stage 子类的各种状态方法
"""

import pytest
from qwork.qfsm.stage import (
    Stage,
    _checkMethodAcceptsParam,
    _invokeStateMethod,
    _RUNTIME_PARAMABLE_CACHE,
)


class TestCheckMethodAcceptsParam:
    """测试 _checkMethodAcceptsParam 函数"""

    def setup_method(self):
        """每个测试前清空缓存"""
        _RUNTIME_PARAMABLE_CACHE.clear()

    def test_no_params(self):
        """测试不接受参数的方法"""
        def noParams(self):
            return "ok"

        result = _checkMethodAcceptsParam(noParams)
        assert result is False
        assert noParams.__runtime_paramable__ is False

    def test_with_self_and_param(self):
        """测试有self和一个参数的方法"""
        class MyClass:
            def method(self, inst):
                return inst

        # 测试未绑定方法
        result = _checkMethodAcceptsParam(MyClass.method)
        assert result is True
        assert MyClass.method.__runtime_paramable__ is True

    def test_with_self_no_other_params(self):
        """测试只有self参数的方法"""
        class MyClass:
            def method(self):
                return "ok"

        # 测试未绑定方法
        result = _checkMethodAcceptsParam(MyClass.method)
        assert result is False
        assert MyClass.method.__runtime_paramable__ is False

    def test_with_args(self):
        """测试接受 *args 的方法"""
        def withArgs(self, *args):
            return args

        result = _checkMethodAcceptsParam(withArgs)
        assert result is True
        assert withArgs.__runtime_paramable__ is True

    def test_with_kwargs(self):
        """测试接受 **kwargs 的方法"""
        def withKwargs(self, **kwargs):
            return kwargs

        result = _checkMethodAcceptsParam(withKwargs)
        assert result is True
        assert withKwargs.__runtime_paramable__ is True

    def test_with_args_and_kwargs(self):
        """测试接受 *args, **kwargs 的方法"""
        def withBoth(self, *args, **kwargs):
            return (args, kwargs)

        result = _checkMethodAcceptsParam(withBoth)
        assert result is True
        assert withBoth.__runtime_paramable__ is True

    def test_with_default_param(self):
        """测试有默认参数的方法"""
        def withDefault(self, inst=None):
            return inst

        result = _checkMethodAcceptsParam(withDefault)
        assert result is True
        assert withDefault.__runtime_paramable__ is True

    def test_cache_is_used(self):
        """测试缓存被使用"""
        def testMethod(self, inst):
            return inst

        # 第一次调用
        result1 = _checkMethodAcceptsParam(testMethod)
        assert result1 is True
        assert testMethod.__runtime_paramable__ is True

        # 修改缓存值
        testMethod.__runtime_paramable__ = False

        # 第二次调用应该使用缓存
        result2 = _checkMethodAcceptsParam(testMethod)
        assert result2 is False  # 使用缓存值


class TestInvokeStateMethod:
    """测试 _invokeStateMethod 函数"""

    def test_invoke_with_param(self):
        """测试调用接受参数的方法"""
        received = []

        class TestClass:
            def withParam(self, inst):
                received.append(inst)
                return "result"

        obj = TestClass()
        # 使用 bound method（self 已自动绑定）
        result = _invokeStateMethod(obj.withParam, "my_inst")
        assert result == "result"
        assert received == ["my_inst"]

    def test_invoke_without_param(self):
        """测试调用不接受参数的方法"""
        received = []

        class TestClass:
            def noParams(self):
                received.append("called")
                return "result"

        obj = TestClass()
        # 使用 bound method（self 已自动绑定）
        result = _invokeStateMethod(obj.noParams, "my_inst")
        assert result == "result"
        assert received == ["called"]

    def test_invoke_with_args(self):
        """测试调用接受 *args 的方法"""
        received = []

        class TestClass:
            def withArgs(self, *args):
                received.extend(args)
                return "result"

        obj = TestClass()
        # 使用 bound method（self 已自动绑定）
        result = _invokeStateMethod(obj.withArgs, "my_inst")
        assert result == "result"
        assert "my_inst" in received


class TestStageIntegration:
    """集成测试 - 测试 Stage 类的各种状态方法"""

    def setup_method(self):
        """每个测试前清空缓存"""
        _RUNTIME_PARAMABLE_CACHE.clear()

    def test_state_with_inst_param(self):
        """测试接受 inst 参数的状态方法"""
        received = []

        class MyInst:
            pass

        class MyStage(Stage):
            NAME = "MyStage"

            def start(self, inst):
                received.append(("start", inst))
                return None

        my_inst = MyInst()
        stage = MyStage(my_inst)
        stage.handleStage(log=False)

        assert len(received) == 1
        assert received[0] == ("start", my_inst)

    def test_state_without_params(self):
        """测试不接受参数的状态方法"""
        received = []

        class MyInst:
            pass

        class MyStage(Stage):
            NAME = "MyStage"

            def start(self):
                received.append("start_called")
                return None

        my_inst = MyInst()
        stage = MyStage(my_inst)
        stage.handleStage(log=False)

        assert len(received) == 1
        assert received[0] == "start_called"

    def test_state_with_args(self):
        """测试接受 *args 的状态方法"""
        received = []

        class MyInst:
            pass

        class MyStage(Stage):
            NAME = "MyStage"

            def start(self, *args):
                received.extend(args)
                return None

        my_inst = MyInst()
        stage = MyStage(my_inst)
        stage.handleStage(log=False)

        assert my_inst in received

    def test_mixed_states(self):
        """测试混合参数类型的状态方法"""
        received = []

        class MyInst:
            pass

        class MyStage(Stage):
            NAME = "MyStage"

            def start(self, inst):
                received.append(("start", inst))
                return "process"

            def process(self):
                received.append("process_no_inst")
                return "end"

            def end(self, inst):
                received.append(("end", inst))
                return None

        my_inst = MyInst()
        stage = MyStage(my_inst)

        # 执行多个 tick
        stage.handleStage(log=False)  # start -> process
        stage.handleStage(log=False)  # process -> end
        stage.handleStage(log=False)  # end

        assert len(received) == 3
        assert received[0] == ("start", my_inst)
        assert received[1] == "process_no_inst"
        assert received[2] == ("end", my_inst)

    def test_runtime_paramable_cache_set_on_stage(self):
        """测试 __runtime_paramable__ 缓存被设置在 Stage 方法上"""

        class MyStage(Stage):
            NAME = "MyStage"

            def start(self, inst):
                return "noInst"  # 转移到 noInst

            def noInst(self):
                return None

        # 创建实例前检查
        assert not hasattr(MyStage.start, '__runtime_paramable__')
        assert not hasattr(MyStage.noInst, '__runtime_paramable__')

        # 创建并执行（使用 None 作为 inst 避免元类问题）
        stage = MyStage(None)
        stage.handleStage(log=False)  # 执行 start，然后转移到 noInst
        stage.handleStage(log=False)  # 执行 noInst

        # 执行后检查：bound method 应该有缓存属性
        # 从实例上获取的 bound method 可以设置属性
        start_method = stage.start  # 获取 bound method
        noInst_method = stage.noInst

        # bound method 可能无法直接设置 __runtime_paramable__
        # 但模块级缓存应该存在
        # 缓存键是 (id(obj), id(func)) 对于 bound method
        start_cache_key = (id(stage), id(start_method.__func__))
        noInst_cache_key = (id(stage), id(noInst_method.__func__))

        assert start_cache_key in _RUNTIME_PARAMABLE_CACHE or hasattr(start_method, '__runtime_paramable__')
        assert noInst_cache_key in _RUNTIME_PARAMABLE_CACHE or hasattr(noInst_method, '__runtime_paramable__')

        # 验证缓存值
        start_result = _checkMethodAcceptsParam(start_method)
        noInst_result = _checkMethodAcceptsParam(noInst_method)
        assert start_result is True
        assert noInst_result is False


class TestEdgeCases:
    """测试边界情况"""

    def setup_method(self):
        """每个测试前清空缓存"""
        _RUNTIME_PARAMABLE_CACHE.clear()

    def test_method_with_multiple_params(self):
        """测试接受多个参数的方法"""
        def multiParam(self, a, b, c):
            return (a, b, c)

        result = _checkMethodAcceptsParam(multiParam)
        assert result is True
        assert multiParam.__runtime_paramable__ is True

    def test_method_with_only_defaults(self):
        """测试所有参数都有默认值的方法"""
        def allDefaults(self, a=1, b=2):
            return (a, b)

        result = _checkMethodAcceptsParam(allDefaults)
        assert result is True
        assert allDefaults.__runtime_paramable__ is True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
