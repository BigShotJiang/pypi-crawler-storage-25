"""Integration tests for qfsm library"""

from qwork.qfsm import Stage, sequence, selector
from qwork.qfsm import Stage, recursive
from qwork.qfsm import Stage, sequence


import pytest
from qwork.qfsm import Stage, Logic, Scheduler
from qwork.qfsm.decorators import recursive, listen, sequence, selector
from qwork.qfsm.meta import clear_prototypes


@pytest.fixture(autouse=True)
def reset_state():
    """Reset state before each test"""
    Scheduler._instance = None
    clear_prototypes()
    Stage._Stage__id__ = {}
    Logic._Logic__names__ = {}
    Logic._Logic__types__ = {}
    yield
    Scheduler._instance = None


class TestFullWorkflow:
    """Test complete state machine workflows"""

    def test_traffic_light_workflow(self):
        """Test traffic light state machine"""

        class TrafficLight(Logic):
            NAME = "TrafficLight"
            LIMIT = 3

            def __init__(self):
                self.transitions = []
                super().__init__()

            def initial(self, inst):
                return "red"

            def red(self, inst):
                return "green"

            def green(self, inst):
                return "yellow"

            @recursive
            def yellow(self, inst):
                return "red"

            def onChanged(self, src, dst, inst):
                self.transitions.append((src, dst))

        light = TrafficLight()
        scheduler = Scheduler()

        # First tick - initial to red
        scheduler.handle()
        assert light._current == "red"

        # Second tick - red to green
        scheduler.handle()
        assert light._current == "green"

        # Third tick - green to yellow, then yellow -> red (recursive in same tick)
        scheduler.handle()
        assert light._current == "red"  # Yellow is recursive, immediately goes to red

    def test_counter_workflow(self):
        """Test counter with recursive state"""

        class Counter(Logic):
            NAME = "Counter"
            LIMIT = 10

            def __init__(self):
                self.count = 0
                super().__init__()

            @recursive
            def counting(self, inst):
                self.count += 1
                if self.count >= 5:
                    return "done"
                return "counting"

            def done(self, inst):
                return None

        counter = Counter()
        scheduler = Scheduler()

        counter._current = "counting"
        scheduler.handle()

        assert counter.count == 5
        assert counter._current == "done"


class TestMultipleInstances:
    """Test multiple interacting logic instances"""
    
    def test_priority_ordering(self):
        """Test that higher priority instances are processed first"""

        class LowPriority(Logic):
            NAME = "LowPriority"
            PRIORITY = 0

            def __init__(self):
                self.order = None
                super().__init__()

            def state(self, inst):
                if self.order is None:
                    self.order = Logic._Logic__execution_order
                return None

        class HighPriority(Logic):
            NAME = "HighPriority"
            PRIORITY = 10

            def __init__(self):
                self.order = None
                super().__init__()

            def state(self, inst):
                if self.order is None:
                    self.order = Logic._Logic__execution_order
                return None

        # Track execution order
        Logic._Logic__execution_order = 0

        low = LowPriority()
        high = HighPriority()

        scheduler = Scheduler()
        scheduler.handle()

        # Both should have been processed
        assert low._isEntered
        assert high._isEntered
    
    def test_instance_referencing(self):
        """Test that instances can reference each other"""

        class Worker(Logic):
            NAME = "Worker"

            def __init__(self):
                self.partner = None
                super().__init__()

            def state(self, inst):
                if self.partner is None:
                    # Find another worker
                    others = self.ref("Worker")
                    for other in others:
                        if other is not self:
                            self.partner = other
                            break
                return None

        worker1 = Worker()
        worker2 = Worker()

        scheduler = Scheduler()
        scheduler.handle()

        assert worker1.partner is worker2 or worker1.partner is None
        assert worker2.partner is worker1 or worker2.partner is None


class TestEventDriven:
    """Test event-driven state changes"""
    
    def test_event_listener(self):
        """Test that @listen decorator correctly marks methods as listeners"""

        class EventDriven(Logic):
            NAME = "EventDriven"

            def __init__(self):
                super().__init__()

            def waiting(self, inst):
                return None

            @listen("trigger")
            def on_trigger(self, data):
                pass

        logic = EventDriven()

        # Verify __listens__ is correctly populated
        assert "trigger" in logic.__listens__
        assert "on_trigger" in [h[0] for h in logic.__listens__["trigger"]]
        # Verify @listen methods are not in __states__
        assert "on_trigger" not in logic.__states__


class TestBehaviorTree:
    """Test behavior tree composites in integration"""

    def test_sequence_all_succeed(self):
        """Test sequence when all children succeed"""

        class SequenceTest(Logic):
            NAME = "SequenceTest"

            def __init__(self):
                self.executed = []
                super().__init__()

            @sequence("step2", "step3")
            def step1(self, it):
                self.executed.append(1)
                return True

            def step2(self, it):
                self.executed.append(2)
                return True

            def step3(self, it):
                self.executed.append(3)
                return True

        logic = SequenceTest()
        scheduler = Scheduler()

        # Tick-based execution: each handle() executes one step
        scheduler.handle()  # Executes step1 (enters sequence) and step2
        scheduler.handle()  # Executes step3

        assert 2 in logic.executed
        assert 3 in logic.executed

    def test_sequence_fails_on_false(self):
        """Test sequence stops when a child returns False"""

        class SequenceFailTest(Logic):
            NAME = "SequenceFailTest"

            def __init__(self):
                self.executed = []
                super().__init__()

            @sequence("step2", "step3")
            def step1(self, it):
                return True

            def step2(self, it):
                self.executed.append(2)
                return False  # Fail - should stop sequence

            def step3(self, it):
                self.executed.append(3)
                return True

        logic = SequenceFailTest()
        scheduler = Scheduler()

        scheduler.handle()

        assert 2 in logic.executed
        assert 3 not in logic.executed  # step3 should not execute

    def test_selector_integration(self):
        """Test selector composite in full workflow"""

        class SelectorTest(Logic):
            NAME = "SelectorTest"

            def __init__(self):
                self.tried = []
                super().__init__()

            @selector("option1", "option2")
            def selector_state(self, it):
                self.tried.append("selector")
                return False  # Fail, try options

            def option1(self, it):
                self.tried.append("option1")
                return True  # Success

            def option2(self, it):
                self.tried.append("option2")
                return None

        logic = SelectorTest()
        scheduler = Scheduler()

        logic._current = "selector_state"

        scheduler.handle()

        # Selector executes children directly, not the parent state's method
        assert "option1" in logic.tried

    def test_behavior_tree_with_listen_decorator(self):
        """Test that @listen methods are not treated as states"""

        class BehaviorWithListen(Logic):
            NAME = "BehaviorWithListen"

            def __init__(self):
                self.executed = []
                self.event_received = False
                super().__init__()

            @sequence("step2", "step3")
            def step1(self, it):
                self.executed.append(1)
                return True

            def step2(self, it):
                self.executed.append(2)
                return True

            def step3(self, it):
                self.executed.append(3)
                return True

            @listen("test_event")
            def on_test_event(self, data):
                self.event_received = True

        logic = BehaviorWithListen()
        scheduler = Scheduler()

        # Verify __states__ doesn't include on_test_event
        assert "on_test_event" not in logic.__states__
        assert "step1" in logic.__states__
        assert "step2" in logic.__states__
        assert "step3" in logic.__states__

        # Verify __listens__ is correctly populated
        assert "test_event" in logic.__listens__

        # Tick-based execution: each handle() executes one step
        scheduler.handle()  # Executes step1 (enters sequence) and step2
        scheduler.handle()  # Executes step3

        # Verify sequence executed
        assert 2 in logic.executed
        assert 3 in logic.executed

    def test_sequence_running_resume(self):
        """Test that RUNNING (None) pauses and resumes from same child, skipping parent."""

        class RunningTest(Logic):
            NAME = "RunningTest"

            def __init__(self):
                self.first_calls = 0
                self.second_calls = 0
                super().__init__()

            @sequence("child1", "child2")
            def parent(self, it):
                self.first_calls += 1
                it.now = self.now  # Set marker on first call
                return True

            def child1(self, it):
                self.second_calls += 1
                # On first tick, return RUNNING (None)
                # On subsequent ticks, if it.now != self.now, succeed
                if not hasattr(it, 'now'):
                    it.now = 0
                if it.now == self.now:
                    return None  # RUNNING
                it.now = self.now
                return True

            def child2(self, it):
                return True

        logic = RunningTest()
        scheduler = Scheduler()

        # Tick 1: parent executes, child1 returns RUNNING
        scheduler.handle()
        assert logic.first_calls == 1  # Parent executed once
        assert logic.second_calls == 1  # Child1 executed once

        # Tick 2: should resume child1 directly, skip parent
        scheduler.handle()
        assert logic.first_calls == 1  # Parent still only executed once
        assert logic.second_calls == 2  # Child1 executed again (resumed)
        # Sequence pauses after child1 succeeds (tick-based execution)

        # Tick 3: continue sequence, execute child2
        scheduler.handle()
        assert logic.first_calls == 1  # Parent still only executed once
        assert logic.second_calls == 2  # Child1 not executed again
        # Sequence completes after child2

        # Tick 4: new sequence starts from beginning
        scheduler.handle()
        assert logic.first_calls == 2  # Parent executed again
        assert logic.second_calls == 3  # Child1 executed again

    def test_nested_behavior_tree_indentation(self, capsys):
        """Test that nested behavior trees have correct indentation in output."""

        class TestLogic(Stage):
            NAME = "TestIndent"

            @sequence("child_seq", "child_sel")
            def root(self, it):
                return True

            @sequence("leaf_a", "leaf_b")
            def child_seq(self, it):
                return True

            @selector("leaf_c", "leaf_d")
            def child_sel(self, it):
                return True

            def leaf_a(self, it):
                return True

            def leaf_b(self, it):
                return True

            def leaf_c(self, it):
                return False

            def leaf_d(self, it):
                return True

        logic = TestLogic()
        logic.handleStage()

        captured = capsys.readouterr()
        output = captured.out

        # 老版本输出格式：使用 std.info，行为树内部转换使用 [...] 作为 tag
        # 例如：[...] root -> child_seq
        lines = output.split('\n')

        # 检查是否有行为树内部转换的输出（使用 [...] 作为 tag）
        bt_transitions = []
        for line in lines:
            if '[...]' in line and '->' in line:
                bt_transitions.append(line)

        # 应该至少有行为树内部的转换输出
        assert len(bt_transitions) > 0, f"Expected behavior tree transitions with [...] tag, got: {output}"

        # 检查是否包含从 root 到 child_seq 的转换
        root_to_child = any('root -> child_seq' in line for line in bt_transitions)
        assert root_to_child, f"Expected transition root -> child_seq, got: {bt_transitions}"


class TestLifecycleManagement:
    """Test instance lifecycle management"""
    
    def test_instance_cleanup(self):
        """Test that dead instances are cleaned up"""

        class ShortLived(Logic):
            NAME = "ShortLived"

            def __init__(self):
                self.ticks = 0
                super().__init__()

            def state(self, inst):
                self.ticks += 1
                if self.ticks >= 2:
                    self.kill()
                return None

        logic = ShortLived()
        scheduler = Scheduler()

        assert logic in scheduler

        scheduler.handle()
        assert logic.alive

        scheduler.handle()
        assert not logic.alive

        scheduler.handle()
        assert logic not in scheduler

    def test_enable_disable(self):
        """Test that disabled instances are skipped"""

        class Toggleable(Logic):
            NAME = "Toggleable"

            def __init__(self):
                self.ticks = 0
                super().__init__()

            def state(self, inst):
                self.ticks += 1
                return None

        logic = Toggleable()
        scheduler = Scheduler()

        scheduler.handle()
        assert logic.ticks == 1

        logic.disable()
        scheduler.handle()
        assert logic.ticks == 1  # Should not increment

        logic.enable()
        scheduler.handle()
        assert logic.ticks == 2


class TestRecursiveExecution:
    """Test recursive state execution with None return"""

    def test_recursive_with_none_return(self):
        """Test that recursive state with None return re-executes"""

        class TestLogic(Stage):
            NAME = "TestRecursive"

            def __init__(self):
                self.count = 0
                super().__init__()

            @recursive
            def counter(self, it):
                self.count += 1
                if self.count >= 3:
                    return "done"
                return None  # Should re-execute because of @recursive

            def done(self, it):
                return None

        logic = TestLogic()
        logic._current = "counter"

        # Single tick should execute counter 3 times
        logic.handleStage(log=False)

        assert logic.count == 3, f"Expected count=3, got {logic.count}"
        assert logic.current == "done"


class TestBehaviorTreeBREAK:
    """Test behavior tree BREAK to external state"""

    def test_break_to_external_prints_transition(self, capsys):
        """Test that BREAK to external state prints the transition"""

        class TestLogic(Stage):
            NAME = "TestBREAK"

            @sequence("child1", "child2")
            def root(self, it):
                return True

            def child1(self, it):
                return True

            def child2(self, it):
                return "external"  # BREAK to external state

            def external(self, it):
                return "exit"

            def exit(self, it):
                return None

        logic = TestLogic()
        # Execute multiple ticks to complete the behavior tree
        for _ in range(5):
            logic.handleStage()
            if logic.current not in ["root", "child1", "child2"]:
                break

        captured = capsys.readouterr()
        output = captured.out

        # Should print the BREAK transition
        assert "child2 -> external" in output, f"Expected 'child2 -> external' in output, got: {output}"

        # Should use [LogicName.fbm] tag for external transition
        assert f"[{logic.name}.fbm]" in output, f"Expected '[{logic.name}.fbm]' tag in output"
