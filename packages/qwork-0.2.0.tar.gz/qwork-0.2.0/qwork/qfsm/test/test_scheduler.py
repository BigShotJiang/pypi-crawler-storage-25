"""Tests for Scheduler"""

import pytest
from qwork.qfsm.scheduler import Scheduler
from qwork.qfsm.meta import StageMachineMeta, clear_prototypes


@pytest.fixture(autouse=True)
def reset_scheduler():
    """Reset scheduler before each test"""
    Scheduler._instance = None
    clear_prototypes()
    yield
    Scheduler._instance = None


class TestSchedulerSingleton:
    """Test scheduler singleton behavior"""
    
    def test_singleton(self):
        """Test that Scheduler is a singleton"""
        s1 = Scheduler()
        s2 = Scheduler()
        assert s1 is s2
    
    def test_same_instance_across_calls(self):
        """Test same instance returned across multiple calls"""
        instances = [Scheduler() for _ in range(5)]
        assert all(i is instances[0] for i in instances)


class TestSchedulerLogin:
    """Test class registration via login()"""
    
    def test_login_registers_class(self):
        """Test that login registers a class"""
        scheduler = Scheduler()
        
        class TestLogic(metaclass=StageMachineMeta):
            NAME = "TestLogic"
            
            def state_a(self, inst):
                return None
        
        scheduler.login(TestLogic)
        assert "TestLogic" in scheduler.prototypes
        assert scheduler.prototypes["TestLogic"] is TestLogic
    
    def test_login_validates_name(self):
        """Test that login validates NAME attribute"""
        scheduler = Scheduler()
        
        class BadLogic:
            pass
        
        with pytest.raises(ValueError):
            scheduler.login(BadLogic)
    
    def test_login_rejects_digit_suffix(self):
        """Test that login rejects NAME ending with digit"""
        scheduler = Scheduler()
        
        class BadLogic:
            NAME = "BadLogic1"
        
        with pytest.raises(ValueError):
            scheduler.login(BadLogic)


class MockLogic:
    """Mock logic class for testing"""
    NAME = "MockLogic"
    PRIORITY = 0
    
    def __init__(self):
        self._alive = True
        self._enabled = True
        self._isEntered = False
        self.check_called = False
        self.enter_called = False
        self.step_called = False
        self.exit_called = False
    
    @property
    def alive(self):
        return self._alive
    
    @alive.setter
    def alive(self, value):
        self._alive = value
    
    @property
    def enabled(self):
        return self._enabled
    
    @enabled.setter
    def enabled(self, value):
        self._enabled = value
    
    def _check(self, is_seek):
        self.check_called = True
        return True
    
    def _enter(self):
        self.enter_called = True
        self._isEntered = True
    
    def _step(self):
        self.step_called = True
    
    def _exit(self):
        self.exit_called = True


class TestSchedulerAdd:
    """Test instance registration via add()"""
    
    def test_add_instance_directly(self):
        """Test adding an instance directly"""
        scheduler = Scheduler()
        mock = MockLogic()
        
        result = scheduler.add(mock)
        
        assert result is mock
        assert mock in scheduler.updates or mock in scheduler.waits
    
    def test_add_by_name(self):
        """Test adding by registered name"""
        scheduler = Scheduler()
        
        class TestLogic(metaclass=StageMachineMeta):
            NAME = "TestLogic"
            PRIORITY = 0
            
            def __init__(self):
                self._alive = True
                self._enabled = True
                self._isEntered = False
            
            def _check(self, is_seek):
                return True
            
            def _enter(self):
                self._isEntered = True
            
            def _step(self):
                pass
            
            def _exit(self):
                pass
        
        scheduler.login(TestLogic)
        instance = scheduler.add("TestLogic")
        
        assert isinstance(instance, TestLogic)


class TestSchedulerHandle:
    """Test the main handle() loop"""
    
    def test_handle_calls_lifecycle(self):
        """Test that handle calls all lifecycle methods"""
        scheduler = Scheduler()
        mock = MockLogic()
        scheduler.add(mock)
        
        scheduler.handle()
        
        assert mock.check_called
        assert mock.enter_called
        assert mock.step_called
    
    def test_handle_removes_dead_instances(self):
        """Test that handle removes dead instances"""
        scheduler = Scheduler()
        mock = MockLogic()
        scheduler.add(mock)
        
        scheduler.handle()
        assert mock.enter_called  # First tick enters
        
        mock._alive = False
        scheduler.handle()
        
        assert mock.exit_called
        assert mock not in scheduler.updates
    
    def test_handle_skips_disabled_instances(self):
        """Test that handle skips disabled instances"""
        scheduler = Scheduler()
        mock = MockLogic()
        mock._enabled = False
        scheduler.add(mock)
        
        scheduler.handle()
        
        assert mock.check_called  # Check is still called
        assert not mock.enter_called  # But not entered
        assert not mock.step_called
    
    def test_handle_priority_ordering(self):
        """Test that instances are processed by priority"""
        scheduler = Scheduler()
        
        class HighPriority(MockLogic):
            PRIORITY = 10
        
        class LowPriority(MockLogic):
            PRIORITY = 0
        
        low = LowPriority()
        high = HighPriority()
        
        scheduler.add(low)
        scheduler.add(high)
        
        # Both should be in updates after handle
        scheduler.handle()
        
        assert high in scheduler.updates
        assert low in scheduler.updates


class TestSchedulerEnableDisable:
    """Test enable/disable functionality"""
    
    def test_disable_prevents_processing(self):
        """Test that global disable prevents processing"""
        scheduler = Scheduler()
        mock = MockLogic()
        scheduler.add(mock)
        
        Scheduler.Disable()
        scheduler.handle()
        
        # Global disable prevents all processing
        assert not mock.check_called
        
        # Re-enable for other tests
        Scheduler.Enable()
    
    def test_instance_enable_disable(self):
        """Test instance-level enable/disable"""
        scheduler = Scheduler()
        mock = MockLogic()
        scheduler.add(mock)
        
        scheduler.disable()
        # Global disable affects all new handles
        
        scheduler.enable()


class TestSchedulerLenAndContains:
    """Test __len__ and __contains__"""
    
    def test_len_counts_instances(self):
        """Test that __len__ returns total instance count"""
        scheduler = Scheduler()
        
        assert len(scheduler) == 0
        
        mock1 = MockLogic()
        mock2 = MockLogic()
        scheduler.add(mock1)
        scheduler.add(mock2)
        
        assert len(scheduler) == 2
    
    def test_contains_checks_instance(self):
        """Test that __contains__ checks for instance"""
        scheduler = Scheduler()
        mock = MockLogic()
        
        assert mock not in scheduler
        
        scheduler.add(mock)
        
        assert mock in scheduler
