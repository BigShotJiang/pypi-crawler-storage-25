from __future__ import annotations
"""
QFSM PyQt6 Demo - 可视化对战界面

展示:
1. 实时游戏画面渲染
2. 角色移动、攻击动画
3. 状态机状态显示
4. 战斗日志
5. 游戏控制（开始/暂停/加速）
"""

import time



import sys
import math
from typing import Any, Optional
from dataclasses import dataclass
from enum import Enum, auto

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QTextEdit, QSlider, QGroupBox, QGridLayout,
    QSplitter, QFrame
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QRectF, QPointF
from PyQt6.QtGui import (
    QPainter, QColor, QBrush, QPen, QFont, QFontMetrics,
    QLinearGradient, QRadialGradient
)

from qwork.qfsm.logic import Logic
from qwork.qfsm.scheduler import Scheduler


# =============================================================================
# 游戏实体和数据类
# =============================================================================

class EntityType(Enum):
    PLAYER = auto()
    ENEMY = auto()
    PROJECTILE = auto()


@dataclass
class GameEntity:
    """游戏实体"""
    name: str
    x: float
    y: float
    health: int
    max_health: int
    entity_type: EntityType
    radius: float = 20.0
    is_active: bool = True

    def distance_to(self, other: 'GameEntity') -> float:
        return math.sqrt((self.x - other.x)**2 + (self.y - other.y)**2)


@dataclass
class Projectile:
    """投射物（攻击效果）"""
    x: float
    y: float
    target_x: float
    target_y: float
    damage: int
    source: str
    speed: float = 8.0
    life: int = 20


# =============================================================================
# 状态机类
# =============================================================================

class GameManager(Logic):
    """游戏管理器"""
    NAME = "GameManager"
    PRIORITY = 100

    def __init__(self, game_widget: 'GameWidget') -> None:
        super().__init__(None)
        self.game = game_widget
        self.tick_count = 0
        self.game_over = False

    def onStart(self, it) -> None:
        self.listenFor("enemy_died", self._on_enemy_died)
        self.listenFor("player_died", self._on_player_died)
        self.game.log("游戏开始!")

    def _on_enemy_died(self, data: Any) -> None:
        name = data.get("name", "Unknown") if isinstance(data, dict) else data
        self.game.log(f"敌人 {name} 被消灭!")
        self.game.enemy_killed += 1

    def _on_player_died(self, data: Any) -> None:
        self.game.log("玩家死亡! 游戏结束!")
        self.game_over = True
        self.game.game_over(False)

    def onStep(self, it) -> None:
        self.tick_count += 1
        self.game.update_display()

        # 检查胜利条件
        if self.game.enemy_killed >= len(self.game.enemy_entities):
            self.game.log("所有敌人被消灭! 胜利!")
            self.game_over = True
            self.game.game_over(True)
            self.kill()

    def idle(self, it) -> str | None:
        if self.game_over:
            return "game_over"
        return None

    def game_over(self, it) -> str | None:
        self.pushEvent("game_over", None)
        self.kill()
        return None


class Player(Logic):
    """玩家控制器"""
    NAME = "Player"
    PRIORITY = 50

    def __init__(self, entity: GameEntity, game: 'GameWidget') -> None:
        super().__init__(entity)
        self._inst: GameEntity = entity
        self.game = game
        self.target: Optional[GameEntity] = None
        self.attack_cooldown = 0
        self.current_state_name = "idle"

    def onStart(self, it) -> None:
        self.game.log(f"玩家 {self._inst.name} 准备就绪")

    def onStep(self, it) -> None:
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1
        self.game.player_state = self.current_state_name

    def idle(self, it) -> str | None:
        self.current_state_name = "idle"
        # 寻找最近的敌人
        closest = None
        closest_dist = float('inf')

        for enemy_entity in self.game.enemy_entities:
            if enemy_entity.health > 0:
                dist = self._inst.distance_to(enemy_entity)
                if dist < closest_dist:
                    closest_dist = dist
                    closest = enemy_entity

        if closest:
            self.target = closest
            if closest_dist > 60:  # 攻击范围
                return "move"
            else:
                return "attack"
        return None

    def move(self, it) -> str | None:
        self.current_state_name = "move"
        if not self.target or self.target.health <= 0:
            return "idle"

        dx = self.target.x - self._inst.x
        dy = self.target.y - self._inst.y
        dist = math.sqrt(dx**2 + dy**2)

        if dist <= 60:
            return "attack"

        # 移动
        speed = 3.0
        if dist > 0:
            self._inst.x += (dx / dist) * speed
            self._inst.y += (dy / dist) * speed

        # 边界检查
        self._inst.x = max(30, min(self.game.width() - 30, self._inst.x))
        self._inst.y = max(30, min(self.game.height() - 100, self._inst.y))

        return "move"

    def attack(self, it) -> str | None:
        self.current_state_name = "attack"
        if not self.target or self.target.health <= 0:
            return "idle"

        if self.attack_cooldown > 0:
            return "attack"

        # 发射投射物
        damage = 25
        self.game.add_projectile(
            self._inst.x, self._inst.y,
            self.target.x, self.target.y,
            damage, "player"
        )
        self.attack_cooldown = 8

        return "attack"


class Enemy(Logic):
    """敌人AI"""
    NAME = "Enemy"
    PRIORITY = 40

    def __init__(self, entity: GameEntity, patrol_points: list[tuple[float, float]],
                 game: 'GameWidget') -> None:
        super().__init__(entity)
        self._inst: GameEntity = entity
        self.patrol_points = patrol_points
        self.current_point = 0
        self.game = game
        self.player_entity = game.player_entity
        self.attack_cooldown = 0
        self.alert_range = 150.0
        self.attack_range = 60.0
        self.current_state_name = "patrol"

    def onStart(self, it) -> None:
        self.listenFor("game_over", self._on_game_over)

    def _on_game_over(self, data: Any) -> None:
        self.kill()

    def onStep(self, it) -> None:
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1
        if self._inst.health <= 0:
            self.kill()

    def patrol(self, it) -> str | None:
        self.current_state_name = "patrol"
        # 检查玩家
        if self.player_entity.health > 0:
            dist = self._inst.distance_to(self.player_entity)
            if dist <= self.alert_range:
                return "chase"

        # 巡逻移动
        target = self.patrol_points[self.current_point]
        dx = target[0] - self._inst.x
        dy = target[1] - self._inst.y
        dist = math.sqrt(dx**2 + dy**2)

        if dist < 5:
            self.current_point = (self.current_point + 1) % len(self.patrol_points)
        else:
            speed = 1.5
            self._inst.x += (dx / dist) * speed
            self._inst.y += (dy / dist) * speed

        return None

    def chase(self, it) -> str | None:
        self.current_state_name = "chase"
        if self.player_entity.health <= 0:
            return "patrol"

        dist = self._inst.distance_to(self.player_entity)

        if dist > self.alert_range * 1.3:
            return "patrol"
        if dist <= self.attack_range:
            return "attack"

        # 追击
        dx = self.player_entity.x - self._inst.x
        dy = self.player_entity.y - self._inst.y
        speed = 2.0
        if dist > 0:
            self._inst.x += (dx / dist) * speed
            self._inst.y += (dy / dist) * speed

        return "chase"

    def attack(self, it) -> str | None:
        self.current_state_name = "attack"
        if self.player_entity.health <= 0:
            return "patrol"

        dist = self._inst.distance_to(self.player_entity)
        if dist > self.attack_range:
            return "chase"

        if self.attack_cooldown > 0:
            return "attack"

        # 发射投射物
        damage = 12
        self.game.add_projectile(
            self._inst.x, self._inst.y,
            self.player_entity.x, self.player_entity.y,
            damage, self._inst.name
        )
        self.attack_cooldown = 10

        return "attack"


# =============================================================================
# PyQt6 游戏组件
# =============================================================================

class GameWidget(QWidget):
    """游戏画面组件"""

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setMinimumSize(800, 500)
        self.setAutoFillBackground(True)

        # 游戏状态
        self.running = False
        self.game_speed = 1
        self.tick_count = 0
        self.enemy_killed = 0
        self.player_state = "idle"
        self.game_result: Optional[str] = None

        # 游戏对象
        self.player_entity = GameEntity("Hero", 100, 250, 100, 100, EntityType.PLAYER, 25)
        self.enemy_entities: list[GameEntity] = []
        self.projectiles: list[Projectile] = []

        # 状态机
        self.scheduler: Optional[Scheduler] = None
        self.game_manager: Optional[GameManager] = None
        self.player_logic: Optional[Player] = None
        self.enemy_logics: list[Enemy] = []

        # 定时器
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.game_tick)

        # 颜色
        self.bg_color = QColor(30, 30, 40)
        self.player_color = QColor(100, 200, 100)
        self.enemy_color = QColor(200, 100, 100)
        self.projectile_player = QColor(100, 255, 100)
        self.projectile_enemy = QColor(255, 100, 100)

    def init_game(self) -> None:
        """初始化游戏"""
        # 重置实体
        self.player_entity = GameEntity("Hero", 100, 250, 100, 100, EntityType.PLAYER, 25)
        self.enemy_entities = [
            GameEntity("Slime", 600, 150, 75, 75, EntityType.ENEMY, 20),
            GameEntity("Goblin", 650, 350, 100, 100, EntityType.ENEMY, 22),
            GameEntity("Orc", 700, 250, 125, 125, EntityType.ENEMY, 25),
        ]
        self.projectiles.clear()
        self.tick_count = 0
        self.enemy_killed = 0
        self.player_state = "idle"
        self.game_result = None

        # 创建调度器
        self.scheduler = Scheduler()
        self.scheduler.login(GameManager)
        self.scheduler.login(Player)
        self.scheduler.login(Enemy)

        # 创建状态机
        self.game_manager = GameManager(self)
        self.player_logic = Player(self.player_entity, self)

        self.enemy_logics = []
        patrol_patterns = [
            [(550, 100), (650, 100), (650, 200), (550, 200)],
            [(600, 300), (700, 300), (700, 400), (600, 400)],
            [(650, 200), (750, 200), (750, 300), (650, 300)],
        ]

        for i, enemy_entity in enumerate(self.enemy_entities):
            logic = Enemy(enemy_entity, patrol_patterns[i], self)
            self.enemy_logics.append(logic)

    def start_game(self) -> None:
        """开始游戏"""
        if not self.running:
            self.init_game()
            self.running = True
            self.timer.start(50 // self.game_speed)  # 20fps基础

    def pause_game(self) -> None:
        """暂停/继续"""
        if self.running:
            if self.timer.isActive():
                self.timer.stop()
            else:
                self.timer.start(50 // self.game_speed)

    def stop_game(self) -> None:
        """停止游戏"""
        self.running = False
        self.timer.stop()

    def set_speed(self, speed: int) -> None:
        """设置游戏速度"""
        self.game_speed = speed
        if self.timer.isActive():
            self.timer.start(50 // self.game_speed)

    def game_tick(self) -> None:
        """游戏tick"""
        if self.scheduler and self.running:
            self.scheduler.handle()
            self.tick_count += 1

            # 更新投射物
            self.update_projectiles()

            # 检查伤害
            self.check_damage()

            self.update()

    def update_projectiles(self) -> None:
        """更新投射物位置"""
        for p in self.projectiles[:]:
            dx = p.target_x - p.x
            dy = p.target_y - p.y
            dist = math.sqrt(dx**2 + dy**2)

            if dist < p.speed or p.life <= 0:
                self.projectiles.remove(p)
                continue

            p.x += (dx / dist) * p.speed
            p.y += (dy / dist) * p.speed
            p.life -= 1

    def check_damage(self) -> None:
        """检查投射物命中"""
        for p in self.projectiles[:]:
            hit = False

            if p.source == "player":
                # 玩家攻击，检查命中敌人
                for enemy in self.enemy_entities:
                    if enemy.health > 0:
                        dist = math.sqrt((p.x - enemy.x)**2 + (p.y - enemy.y)**2)
                        if dist < enemy.radius:
                            enemy.health -= p.damage
                            hit = True
                            if enemy.health <= 0:
                                self.pushEvent("enemy_died", {"name": enemy.name})
                            break
            else:
                # 敌人攻击，检查命中玩家
                if self.player_entity.health > 0:
                    dist = math.sqrt((p.x - self.player_entity.x)**2 + (p.y - self.player_entity.y)**2)
                    if dist < self.player_entity.radius:
                        self.player_entity.health -= p.damage
                        hit = True
                        if self.player_entity.health <= 0:
                            self.pushEvent("player_died", {"name": self.player_entity.name})

            if hit and p in self.projectiles:
                self.projectiles.remove(p)

    def add_projectile(self, x: float, y: float, tx: float, ty: float,
                       damage: int, source: str) -> None:
        """添加投射物"""
        self.projectiles.append(Projectile(x, y, tx, ty, damage, source))

    def pushEvent(self, event: str, data: Any) -> None:
        """推送事件"""
        if self.game_manager:
            self.game_manager.pushEvent(event, data)

    def log(self, message: str) -> None:
        """添加日志"""
        # 由主窗口处理
        if self.parent() and hasattr(self.parent(), 'add_log'):
            self.parent().add_log(message)

    def update_display(self) -> None:
        """更新显示信息"""
        if self.parent() and hasattr(self.parent(), 'update_info'):
            self.parent().update_info()

    def game_over(self, victory: bool) -> None:
        """游戏结束"""
        self.game_result = "VICTORY" if victory else "DEFEAT"
        self.running = False
        self.timer.stop()

    def paintEvent(self, event) -> None:
        """绘制游戏画面"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # 绘制背景
        painter.fillRect(self.rect(), self.bg_color)

        # 绘制网格
        pen = QPen(QColor(50, 50, 60))
        pen.setWidth(1)
        painter.setPen(pen)
        for i in range(0, self.width(), 50):
            painter.drawLine(i, 0, i, self.height())
        for i in range(0, self.height(), 50):
            painter.drawLine(0, i, self.width(), i)

        # 绘制投射物
        for p in self.projectiles:
            color = self.projectile_player if p.source == "player" else self.projectile_enemy
            painter.setBrush(QBrush(color))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(int(p.x - 4), int(p.y - 4), 8, 8)

        # 绘制敌人
        for i, enemy in enumerate(self.enemy_entities):
            if enemy.health > 0:
                self.draw_entity(painter, enemy, self.enemy_color, i)

        # 绘制玩家
        if self.player_entity.health > 0:
            self.draw_entity(painter, self.player_entity, self.player_color, -1)

        # 绘制游戏结果
        if self.game_result:
            self.draw_game_result(painter)

        painter.end()

    def draw_entity(self, painter: QPainter, entity: GameEntity,
                    color: QColor, index: int) -> None:
        """绘制实体"""
        x, y = int(entity.x), int(entity.y)
        r = int(entity.radius)

        # 绘制范围圈（巡逻/警戒范围）
        if entity.entity_type == EntityType.ENEMY:
            pen = QPen(QColor(200, 100, 100, 50))
            pen.setWidth(2)
            pen.setStyle(Qt.PenStyle.DotLine)
            painter.setPen(pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawEllipse(x - 150, y - 150, 300, 300)

        # 绘制实体阴影
        painter.setBrush(QBrush(QColor(0, 0, 0, 100)))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(x - r + 3, y - r + 5, r * 2, r * 2)

        # 绘制实体主体
        gradient = QRadialGradient(x - r//3, y - r//3, r)
        gradient.setColorAt(0, color.lighter(150))
        gradient.setColorAt(1, color)
        painter.setBrush(QBrush(gradient))
        painter.setPen(QPen(color.darker(120), 2))
        painter.drawEllipse(x - r, y - r, r * 2, r * 2)

        # 绘制方向指示
        painter.setPen(QPen(color.darker(150), 3))
        if entity.entity_type == EntityType.PLAYER and self.player_logic:
            target = self.player_logic.target
            if target:
                dx = target.x - entity.x
                dy = target.y - entity.y
                dist = math.sqrt(dx**2 + dy**2)
                if dist > 0:
                    end_x = x + (dx / dist) * (r - 5)
                    end_y = y + (dy / dist) * (r - 5)
                    painter.drawLine(x, y, int(end_x), int(end_y))

        # 绘制血条背景
        bar_width = r * 2
        bar_height = 6
        bar_x = x - bar_width // 2
        bar_y = y - r - 15
        painter.fillRect(bar_x, bar_y, bar_width, bar_height, QColor(60, 60, 60))

        # 绘制血条
        health_pct = max(0, entity.health / entity.max_health)
        health_width = int(bar_width * health_pct)
        if health_pct > 0.5:
            health_color = QColor(100, 200, 100)
        elif health_pct > 0.25:
            health_color = QColor(200, 200, 100)
        else:
            health_color = QColor(200, 100, 100)
        painter.fillRect(bar_x, bar_y, health_width, bar_height, health_color)

        # 绘制血条边框
        painter.setPen(QPen(QColor(100, 100, 100), 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(bar_x, bar_y, bar_width, bar_height)

        # 绘制名称
        painter.setPen(QPen(Qt.GlobalColor.white))
        font = QFont("Microsoft YaHei", 9, QFont.Weight.Bold)
        painter.setFont(font)
        text_rect = QRectF(x - 40, y + r + 5, 80, 20)
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter, entity.name)

        # 绘制状态（如果是敌人）
        if entity.entity_type == EntityType.ENEMY and index >= 0:
            logic = self.enemy_logics[index] if index < len(self.enemy_logics) else None
            if logic:
                state_text = logic.current_state_name.upper()
                painter.setPen(QPen(QColor(200, 200, 200)))
                font = QFont("Microsoft YaHei", 8)
                painter.setFont(font)
                state_rect = QRectF(x - 40, y + r + 22, 80, 16)
                painter.drawText(state_rect, Qt.AlignmentFlag.AlignCenter, state_text)

    def draw_game_result(self, painter: QPainter) -> None:
        """绘制游戏结果"""
        # 半透明遮罩
        overlay = QColor(0, 0, 0, 180)
        painter.fillRect(self.rect(), overlay)

        # 结果文字
        if self.game_result == "VICTORY":
            text = "VICTORY!"
            color = QColor(100, 255, 100)
        else:
            text = "DEFEAT!"
            color = QColor(255, 100, 100)

        painter.setPen(QPen(color))
        font = QFont("Microsoft YaHei", 48, QFont.Weight.Bold)
        painter.setFont(font)

        metrics = QFontMetrics(font)
        text_width = metrics.horizontalAdvance(text)
        x = (self.width() - text_width) // 2
        y = self.height() // 2

        painter.drawText(x, y, text)

        # 提示文字
        painter.setPen(QPen(QColor(200, 200, 200)))
        font = QFont("Microsoft YaHei", 14)
        painter.setFont(font)
        hint = "Press START to play again"
        hint_width = QFontMetrics(font).horizontalAdvance(hint)
        painter.drawText((self.width() - hint_width) // 2, y + 50, hint)


class MainWindow(QMainWindow):
    """主窗口"""

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("QFSM Battle Demo - PyQt6")
        self.setMinimumSize(1000, 600)

        # 创建中央部件
        central = QWidget()
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        layout.setSpacing(10)

        # 分割器
        splitter = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(splitter)

        # 左侧：游戏画面
        self.game_widget = GameWidget()
        splitter.addWidget(self.game_widget)

        # 右侧：控制面板
        control_panel = self.create_control_panel()
        splitter.addWidget(control_panel)

        splitter.setSizes([800, 200])

        # 设置样式
        self.setStyleSheet("""
            QMainWindow {
                background-color: #2b2b2b;
            }
            QWidget {
                background-color: #2b2b2b;
                color: #cccccc;
            }
            QGroupBox {
                border: 1px solid #555;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 10px;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
            QPushButton {
                background-color: #3d3d3d;
                border: 1px solid #555;
                padding: 8px 16px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #4d4d4d;
            }
            QPushButton:pressed {
                background-color: #5d5d5d;
            }
            QTextEdit {
                background-color: #1e1e1e;
                border: 1px solid #444;
                color: #aaa;
            }
            QSlider::groove:horizontal {
                height: 8px;
                background: #3d3d3d;
                border-radius: 4px;
            }
            QSlider::handle:horizontal {
                background: #6d6d6d;
                width: 18px;
                margin: -5px 0;
                border-radius: 9px;
            }
            QLabel {
                color: #aaa;
            }
        """)

    def create_control_panel(self) -> QWidget:
        """创建控制面板"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setSpacing(15)

        # 控制按钮组
        control_group = QGroupBox("Game Control")
        control_layout = QVBoxLayout(control_group)

        self.start_btn = QPushButton("START")
        self.start_btn.setStyleSheet("background-color: #2d5a2d;")
        self.start_btn.clicked.connect(self.on_start)
        control_layout.addWidget(self.start_btn)

        self.pause_btn = QPushButton("PAUSE")
        self.pause_btn.clicked.connect(self.on_pause)
        control_layout.addWidget(self.pause_btn)

        self.stop_btn = QPushButton("STOP")
        self.stop_btn.setStyleSheet("background-color: #5a2d2d;")
        self.stop_btn.clicked.connect(self.on_stop)
        control_layout.addWidget(self.stop_btn)

        layout.addWidget(control_group)

        # 速度控制
        speed_group = QGroupBox("Game Speed")
        speed_layout = QVBoxLayout(speed_group)

        self.speed_slider = QSlider(Qt.Orientation.Horizontal)
        self.speed_slider.setMinimum(1)
        self.speed_slider.setMaximum(5)
        self.speed_slider.setValue(1)
        self.speed_slider.valueChanged.connect(self.on_speed_changed)
        speed_layout.addWidget(self.speed_slider)

        self.speed_label = QLabel("1x")
        self.speed_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        speed_layout.addWidget(self.speed_label)

        layout.addWidget(speed_group)

        # 状态信息
        info_group = QGroupBox("Status")
        info_layout = QGridLayout(info_group)

        info_layout.addWidget(QLabel("Tick:"), 0, 0)
        self.tick_label = QLabel("0")
        info_layout.addWidget(self.tick_label, 0, 1)

        info_layout.addWidget(QLabel("Player State:"), 1, 0)
        self.player_state_label = QLabel("idle")
        info_layout.addWidget(self.player_state_label, 1, 1)

        info_layout.addWidget(QLabel("Player HP:"), 2, 0)
        self.player_hp_label = QLabel("100/100")
        info_layout.addWidget(self.player_hp_label, 2, 1)

        info_layout.addWidget(QLabel("Enemies:"), 3, 0)
        self.enemy_label = QLabel("3")
        info_layout.addWidget(self.enemy_label, 3, 1)

        info_layout.addWidget(QLabel("Killed:"), 4, 0)
        self.killed_label = QLabel("0")
        info_layout.addWidget(self.killed_label, 4, 1)

        layout.addWidget(info_group)

        # 战斗日志
        log_group = QGroupBox("Battle Log")
        log_layout = QVBoxLayout(log_group)

        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.document().setMaximumBlockCount(100)
        log_layout.addWidget(self.log_text)

        layout.addWidget(log_group)

        # 添加弹性空间
        layout.addStretch()

        return panel

    def on_start(self) -> None:
        """开始按钮"""
        self.game_widget.start_game()
        self.add_log("游戏开始!")

    def on_pause(self) -> None:
        """暂停按钮"""
        self.game_widget.pause_game()
        if self.game_widget.timer.isActive():
            self.pause_btn.setText("PAUSE")
        else:
            self.pause_btn.setText("RESUME")

    def on_stop(self) -> None:
        """停止按钮"""
        self.game_widget.stop_game()
        self.pause_btn.setText("PAUSE")

    def on_speed_changed(self, value: int) -> None:
        """速度改变"""
        self.speed_label.setText(f"{value}x")
        self.game_widget.set_speed(value)

    def add_log(self, message: str) -> None:
        """添加日志"""
        timestamp = time.strftime("%H:%M:%S")
        self.log_text.append(f"[{timestamp}] {message}")

    def update_info(self) -> None:
        """更新信息"""
        self.tick_label.setText(str(self.game_widget.tick_count))
        self.player_state_label.setText(self.game_widget.player_state.upper())

        hp = self.game_widget.player_entity.health
        max_hp = self.game_widget.player_entity.max_health
        self.player_hp_label.setText(f"{max(0, hp)}/{max_hp}")

        alive_enemies = sum(1 for e in self.game_widget.enemy_entities if e.health > 0)
        self.enemy_label.setText(str(alive_enemies))
        self.killed_label.setText(str(self.game_widget.enemy_killed))


def main():
    app = QApplication(sys.argv)

    # 设置应用字体
    font = QFont("Microsoft YaHei", 10)
    app.setFont(font)

    window = MainWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
