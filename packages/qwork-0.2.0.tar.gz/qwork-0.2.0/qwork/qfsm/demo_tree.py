# -*- coding: utf-8 -*-
import time
from random import random
from qwork.qfsm import *


class MyLogic(Logic):
    NAME = "My"

    @sequence("second", "third")
    def first(self, it):
        it.now = self.now  # 在 BlackBoard 上动态添加 now 属性
        return random() < 0.7

    
    def second(self, it):
        if it.now == self.now:
            return None
        return random() > 0.5
    
    
    @selector("A", "B")
    def third(self, it):
        return random() < 0.5
    
    def A(self, it):
        if random() < 0.25: return
        return random() < 0.5
    
    def B(self, it):
        if random() < 0.25: return
        return random() < 0.5
    

    @listen("system")
    def my_handle(self, data):
        print(f"{self.name} recv event: {data}")


# 创建调度器
sch = Scheduler()
cl0 = Logic("My")  # inst 默认是 BlackBoard()

for i in range(10):
    print("TICK{}".format(sch.tick))
    sch.handle()
