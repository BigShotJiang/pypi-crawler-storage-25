# AI说明: 本文件起文档作用，不可运行
from builtin.const import *
from builtin.stdio import *
from builtin.view import *
from builtin.math import *


# > sort 8
class Scheduler:  # > remove
    """ Scheduler类，用于调度和管理逻辑流程。 提供核心控制功能，如任务调度、优先级管理、错误处理和资源清理。 """  # > remove
    instance = None  # 单例模式实例  # > remove

    def __new__(cls, *args, **kwargs):  # > remove
        """ 实现单例模式，确保只有一个Scheduler实例。 """  # > remove
        if not cls.instance:  # > remove
            cls.instance = super().__new__(cls)  # > remove
        return cls.instance  # > remove

    def __init__(self):  # > remove
        """ 初始化Scheduler实例。 创建存储逻辑原型、更新队列和等待队列的容器。 """  # > remove
        self.prototypes = {}  # 逻辑原型注册表  # > remove
        self.updates = []  # 高优先级更新队列  # > remove
        self.waits = []  # 低优先级等待队列  # > remove
        Scheduler.instance = self  # > remove

    def login(self, prototype):  # > remove
        """ 注册逻辑原型到Scheduler中。 """  # > remove
        pass  # > remove

    def add(self, obj_or_name: str | "Logic", *args) -> "Logic" | None:  # > remove
        """ 添加逻辑实例到更新或等待队列中。 Args： obj_or_name: 逻辑名称或逻辑对象。 *args: 可选参数，用于实例化逻辑对象。 Return： Logic实例或None。"""  # > remove
        pass  # > remove

    def handle(self):  # > remove
        """    # > remove
        主处理逻辑，在每个时间周期内执行以下步骤：  # > remove
        1. 将等待队列中的实例转移到更新队列。  # > remove
        2. 分阶段处理更新队列中的实例：  # > remove
           a. 检查阶段：验证实例状态。  # > remove
           b. 入口阶段：初始化实例。  # > remove
           c. 步骤阶段：执行实例逻辑。  # > remove
           d. 退出阶段：清理无效实例。    # > remove
        """  # > remove
        pass  # > remove

    @staticmethod  # > remove
    def Disable():  # > remove
        """ 禁用调度器。 """  # > remove
        pass  # > remove

    @staticmethod  # > remove
    def Enable():  # > remove
        """ 启用调度器。 """  # > remove
        pass  # > remove

    def disable(self):  # > remove
        """ 禁用调度器。 """  # > remove
        pass  # > remove

    def enable(self):  # > remove
        """ 启用调度器。 """  # > remove
        pass  # > remove


class ListenSystem:  # > remove
    """ ListenSystem类，用于监听系统事件。 """  # > remove

    def __init__(self, game_object: "GameObject"):  # > remove
        """ 初始化ListenSystem实例。 """  # > remove
        pass  # > remove

    def listenFor(self, event: str, fn: callable):  # > remove
        """ 监听指定事件。 """  # > remove
        pass  # > remove

    def cancelListen(self, event: str):  # > remove
        """ 取消监听指定事件。 """  # > remove
        pass  # > remove

    def pushEvent(self, event: str, ename: str, data: dict | UsrObject | None = None, *targets: str):  # > remove
        """ 推送事件到监听系统。 """  # > remove
        pass  # > remove


class Monitor:  # > remove
    """ Monitor类，用于监视对象的生成和销毁，以及creep的watching任务。 """  # > remove
    instance = None  # 单例模式实例  # > remove
    watchings = {}  # 用于存储所有监视记录  # > remove

    def __new__(cls, *args, **kwargs):  # > remove
        """ 实现单例模式，确保只有一个Monitor实例。 """  # > remove
        if not cls.instance:  # > remove
            cls.instance = super().__new__(cls)  # > remove
        return cls.instance  # > remove

    def __init__(self):  # > remove
        """ 初始化Monitor实例。 """  # > remove
        if not hasattr(self, 'watchings'):  # > remove
            self.watchings = {}  # > remove
        self.eda: ListenSystem = None  # > remove

    def enemyEnterAreaWatching(self, watching_name: str, plt, prb, callback) -> None:  # > remove
        """  # > remove
        敌方进入区域监视。  # > remove

        :param watching_name: 监视名称  # > remove
        :type watching_name: str  # > remove
        :param plt: 区域起点坐标  # > remove
        :type plt: dict  # > remove
        :param prb: 区域终点坐标  # > remove
        :type prb: dict  # > remove
        :param callback: 回调函数 fn(creeps)  # > remove
        :type callback: function(list[Creep])  # > remove
        """  # > remove
        pass  # > remove

    def friendEnterAreaWatching(self, watching_name: str, plt, prb, callback) -> None:  # > remove
        """  # > remove
        友方进入区域监视。  # > remove

        :param watching_name: 监视名称  # > remove
        :type watching_name: str  # > remove
        :param plt: 区域起点坐标  # > remove
        :type plt: dict  # > remove
        :param prb: 区域终点坐标  # > remove
        :type prb: dict  # > remove
        :param callback: 回调函数 fn(creeps)  # > remove
        :type callback: function(list[Creep])  # > remove
        """  # > remove
        pass  # > remove

    def enemyExitAreaWatching(self, watching_name: str, plt, prb, callback) -> None:  # > remove
        """  # > remove
        敌方离开区域监视。  # > remove

        :param watching_name: 监视名称  # > remove
        :type watching_name: str  # > remove
        :param plt: 区域起点坐标  # > remove
        :type plt: dict  # > remove
        :param prb: 区域终点坐标  # > remove
        :type prb: dict  # > remove
        :param callback: 回调函数 fn(creeps)  # > remove
        :type callback: function(list[Creep])  # > remove
        """  # > remove
        pass  # > remove

    def friendExitAreaWatching(self, watching_name: str, plt, prb, callback) -> None:  # > remove
        """  # > remove
        友方离开区域监视。  # > remove

        :param watching_name: 监视名称  # > remove
        :type watching_name: str  # > remove
        :param plt: 区域起点坐标  # > remove
        :type plt: dict  # > remove
        :param prb: 区域终点坐标  # > remove
        :type prb: dict  # > remove
        :param callback: 回调函数 fn(creeps)  # > remove
        :type callback: function(list[Creep])  # > remove
        """  # > remove
        pass  # > remove

    def cancelWatching(self, watching_name: str) -> None:  # > remove
        """  # > remove
        取消所有与指定监视名称相关的监视记录。  # > remove

        :param watching_name: 监视名称  # > remove
        :type watching_name: str  # > remove
        """  # > remove
        pass  # > remove


SREC = []  # 调试日志列表 | Debug log list


class StageMachineLogicMeta(type):
    """Metaclass for automatic class registration and state node management.

    合并后的元类，用于自动注册类到Scheduler中，并管理Stage类的状态节点和原型记录。

    功能 / Features:
    - 自动注册符合条件的类到Scheduler | Automatic registration of eligible classes to Scheduler
    - 自动发现并记录状态节点（函数） | Automatic discovery and recording of state nodes (functions)
    - 管理类原型记录 | Management of class prototype records
    """

    logs = []  # 日志记录列表 | Log records list

    __listens__ = {}
    # 记录类定义时使用的listen装饰器信息 | Records listen decorator info during class definition

    __recursive__ = {}
    # 记录类定义时使用的recursive装饰器信息 | Records recursive decorator info during class definition

    __behaviors__ = {}
    # 记录类定义时使用的bt装饰器信息 | Records bt decorator info during class definition

    __protos__ = {}
    """字典，用于记录Stage类的原型。
    Dictionary for recording Stage class prototypes.

    键为类名，值为类对象。
    Keys are class names, values are class objects.
    
    @Example:
    {"Stage": Stage, }
    """

    IGNORES = [
        'ref', 'refLast', 'refNext', 'refAdjacent', 'refEnd', 'refHead', 'link', 'transform', 'creeps',
        "listenFor", "cancelListen", "pushEvent", "schedule", "cancelSchedule", "handleStage",
        'onStart', 'onStop', 'onStep', 'onChanged', 'onKilled', 'onDraw', 'onLoading',
        "productQueue", "showQueue", "jumpQueue", "accelerate"
    ]
    """特殊方法名列表，这些方法不会被识别为状态节点。
    List of special method names that won't be recognized as state nodes.
    """

    def __new__(meta, name, bases, attrs):
        """Creates a new class with automatic registration and state management.

        创建新类并自动注册到Scheduler中（若类名不是'CreepLogic'），同时管理状态节点和原型记录。

        Args:
            meta: 元类本身 | The metaclass itself
            name: 新创建的类的名称 | Name of the class being created
            bases: 新创建的类的基类元组 | Tuple of base classes
            attrs: 新创建的类的属性字典 | Attributes dictionary

        Returns:
            type: 新创建的类 | The newly created class
        """

        # 初始化状态节点列表 | Initialize state nodes list
        attrs['__states__'] = []

        # 获取并设置递归状态节点（直接访问字典，因为在js环境下，字典键不存在时访问不会报错）
        # Get and set recursive state nodes (safe access, no KeyError)
        attrs['__listens__'] = StageMachineLogicMeta.__listens__[name] or {}
        attrs['__recursive__'] = StageMachineLogicMeta.__recursive__[name] or []
        attrs['__behaviors__'] = StageMachineLogicMeta.__behaviors__[name] or {}
        # SREC.append(f"new class, name = {name}")
        # SREC.append(f"attrs.__recursive__={attrs['__recursive__']}")
        # SREC.append(f"attrs.__behaviors__={attrs['__behaviors__']}")

        # 以下代码原为清空recursive字典，现已注释 | Below code was for clearing recursive dict, now commented
        # StageMachineLogicMeta.__recursive__ = []

        # 合并父类的状态节点和递归节点 | Merge parent class state nodes and recursive nodes
        old_listens = {}
        old_behaviors = {}
        for base in bases:
            # 以下三行原为调试日志，现已注释 | Below 3 lines were debug logs, now commented
            # StageMachineLogicMeta.logs.append(base.NAME)
            # StageMachineLogicMeta.logs.append(base.__states__)
            # StageMachineLogicMeta.logs.append(base.__recursive__)

            # JS环境检测：若父类有__states__则合并 | JS environment check: merge if base has __states__
            if base.__states__:  # js中运行才能这么写 | Only works in JS environment
                attrs['__states__'].extend(base.__states__)
                # 日志记录base的递归状态（尽管位于__states__判断块内）
                # Log base recursive states (though inside __states__ block)
            # 合并父类的监听节点 | Merge parent listen nodes
            if base.__listens__:
                old_listens.update(base.__listens__)
            # 合并父类的递归节点 | Merge parent recursive nodes
            if base.__recursive__:
                attrs['__recursive__'].extend(base.__recursive__)
            if base.__behaviors__:
                old_behaviors.update(base.__behaviors__)

        if len(old_listens):
            old_listens.update(attrs['__listens__'])
            attrs['__listens__'] = old_listens

        if len(old_behaviors):
            old_behaviors.update(attrs['__behaviors__'])
            attrs['__behaviors__'] = old_behaviors

        # SREC.append("recursive: " + str(attrs['__recursive__']))

        # 去重处理 | Deduplication
        attrs['__states__'] = list(set(attrs['__states__']))
        attrs['__recursive__'] = list(set(attrs['__recursive__']))
        # __behaviors__是字典类型，不需要set去重 | __behaviors__ is dict type, no need for set deduplication

        # 以下两行为JS兼容性代码/指令，不可修改 | Below 2 lines are JS compatibility code/instructions, do not modify
        # > insert const iters = Object.entries(attrs);
        iters = []  # > remove

        for key, value in iters:
            # 筛选条件：非下划线开头、可调用、非全大写、非忽略列表 | Filter: no underscore, callable, not uppercase, not in ignore list
            if not key.startswith('_') and callable(value):
                if key.isupper():
                    continue
                if key in StageMachineLogicMeta.IGNORES:
                    continue
                attrs['__states__'].append(key)

        # 以下行原为状态统计日志，现已注释 | Below line was state stats log, now commented
        # StageMachineLogicMeta.logs.append(f"{name} {attrs['NAME']:>20} {len(attrs['__states__'])} {attrs['__recursive__']}")

        # 以下代码原为重置__new__方法，现已注释 | Below code was for resetting __new__ method, now commented
        # if name != 'Stage':
        #     attrs['__new__'] = object.__new__

        # 创建类 | Create the class
        new_class = type.__new__(meta, name, bases, attrs)
        # SREC.append(f"Check behaviors: {new_class.__behaviors__}")

        # 注册到Scheduler（排除特定基类）| Register to Scheduler (exclude specific base classes)
        if name not in ["CreepLogic", "Logic", "Stage", "TeamLogic"]:
            Scheduler().login(new_class)
            # 记录到原型字典 | Record in prototype dictionary
            StageMachineLogicMeta.__protos__[new_class.NAME] = new_class

        return new_class

    @classmethod
    def proto(cls, name):
        """Gets a Stage class prototype.

        获取一个Stage类的原型。

        Args:
            name: 类名 | Class name

        Returns:
            type: Stage类的原型 | Stage class prototype

        Raises:
            不抛出异常，仅打印错误日志 | Does not raise exception, only prints error log
        """
        if name in cls.__protos__:
            return cls.__protos__[name]
        else:
            # 根据语言设置打印相应错误消息 | Print error message according to language setting
            if LANGUAGE == 'cn':
                std.error("StageMachineLogicMeta.proto", "找不到Stage原型: " + name)
            else:
                std.error("StageMachineLogicMeta.proto", "Stage prototype not found: " + name)


def recursive(func):
    """
    递归装饰器，用于标记一个方法为递归调用。  
    * 被递归装饰的函数，会在一个tick内被多次调用，直到返回一个新的状态。  
    * 注意，最大递归深度为16。通过Stage的子类的LIMIT属性可以修改。  
    """
    pass


def _recursiveLogin(class_name, function_name):
    # 编译器将上面一句话的function_name替换为对应的函数名
    # print("__recursive__", StageMachineLogicMeta.__recursive__)
    # print("recursive", class_name, function_name, StageMachineLogicMeta.__recursive__)
    if st.na(StageMachineLogicMeta.__recursive__.py_get(class_name)):
        StageMachineLogicMeta.__recursive__[class_name] = []
    StageMachineLogicMeta.__recursive__[class_name].append(function_name)


def listen(ename: str, *source):
    """
    监听装饰器，用于标记一个方法为事件的监听函数。
    """
    pass


def _listenLogin(class_name, function_name, ename: str, *source):
    if st.na(StageMachineLogicMeta.__listens__.py_get(class_name)):
        StageMachineLogicMeta.__listens__[class_name] = {}
    if st.na(StageMachineLogicMeta.__listens__[class_name].py_get(ename)):
        StageMachineLogicMeta.__listens__[class_name][ename] = []
    StageMachineLogicMeta.__listens__[class_name][ename].append([function_name, list(source)])


def _preLoginBehavior(class_name, function_name):
    if st.na(StageMachineLogicMeta.__behaviors__.py_get(class_name)):
        StageMachineLogicMeta.__behaviors__[class_name] = {}
    if st.na(StageMachineLogicMeta.__behaviors__[class_name].py_get(function_name)):
        StageMachineLogicMeta.__behaviors__[class_name][function_name] = {
            "children": None,
            "composite": None,
        }
    return StageMachineLogicMeta.__behaviors__[class_name][function_name]


def _checkChildren(type_name: str, class_name, function_name, item):
    if item["children"] is not None:
        if LANGUAGE == 'cn':
            std.error(f"@{type_name}<{class_name}>{function_name}", f"节点不能重复标记后继状态，当前已有后继状态：{item['children']}")
        else:
            std.error(f"@{type_name}<{class_name}>{function_name}", f"Node cannot have multiple children. Currently have: {item['children']}")


def _checkComposite(type_name: str, class_name, function_name, item):
    if item["composite"] is not None:
        if LANGUAGE == 'cn':
            std.error(f"@{type_name}<{class_name}>{function_name}", f"节点已被标记为组合节点，不能再被标记。当前组合节点类型为：{item['composite']}")
        else:
            std.error(f"@{type_name}<{class_name}>{function_name}", f"Node cannot have multiple composite types. Currently type: {item['composite']}")


def behavior(s: str):
    """
    行为装饰器，用于标记一个方法为行为的后继状态。
    """
    pass


def _behaviorLogin(class_name, function_name, target_name):
    item = _preLoginBehavior(class_name, function_name)

    _checkChildren("behavior", class_name, function_name, item)

    item["children"] = target_name


def sequence(*s: str):
    """
    组合装饰器:Sequence，用于标记一个方法的后继为序列
    """
    pass


def _sequenceLogin(class_name, function_name, *target_names: str):
    item = _preLoginBehavior(class_name, function_name)
    _checkChildren("sequence", class_name, function_name, item)
    _checkComposite("sequence", class_name, function_name, item)
    item["children"] = list(target_names)
    item["composite"] = "sequence"


def selector(*s: str):
    """
    组合装饰器:Selector，用于标记一个方法的后继为选择器
    """
    pass


def _selectorLogin(class_name, function_name, *target_names: str):
    item = _preLoginBehavior(class_name, function_name)
    _checkChildren("selector", class_name, function_name, item)
    _checkComposite("selector", class_name, function_name, item)
    item["children"] = list(target_names)
    item["composite"] = "selector"


def parallel(*s: str):
    """
    组合装饰器:Parallel，用于标记一个方法的后继为并行器
    """
    pass


def _parallelLogin(class_name, function_name, *target_names: str):
    item = _preLoginBehavior(class_name, function_name)
    _checkChildren("parallel", class_name, function_name, item)
    _checkComposite("parallel", class_name, function_name, item)
    item["children"] = list(target_names)
    item["composite"] = "parallel"


class _NamedNode:
    """命名基类，提供名称属性和树形结构管理能力。

    Base class that provides NAME attribute and tree structure management.
    """

    NAME = ""  # 类的默认名称 | Default class name

    def __init__(self):
        """初始化命名节点。

        Initializes a named node.
        """
        self._parent = None  # 父节点引用 | Parent node reference
        self._children = []  # 子节点列表 | List of child nodes
        self._name = self.NAME  # 实例名称，默认使用类名 | Instance name, defaults to class name

    @property
    def parent(self):
        """获取父节点。

        Get parent node.

        Returns:
            _NamedNode: 父节点对象或None | Parent node object or None
        """
        return self._parent

    # 添加子节点 | Add child node
    def __add_child__(self, child: "_NamedNode") -> None:
        """添加一个子节点到当前节点。

        Adds a child node to the current node.

        Args:
            child: 要添加的子节点对象 | Child node object to add

        Returns:
            None
        """
        # 类型验证：确保child是_NamedNode实例 | Type validation: ensure child is a _NamedNode instance
        if not isinstance(child, _NamedNode):
            if LANGUAGE == 'cn':
                std.warn(f"_NamedNode<{self.NAME}>", f"child 不是 _NamedNode 类型：{type(child)}")
            else:
                std.warn(f"_NamedNode<{self.NAME}>", f"child is not an instance of _NamedNode: {type(child)}")
            return

        # 验证子节点尚未挂载到其他父节点 | Verify child is not already attached to another parent
        if child._parent is not None:
            if LANGUAGE == 'cn':
                std.warn(f"_NamedNode<{self.NAME}>", f"child 已有父节点")
            else:
                std.warn(f"_NamedNode<{self.NAME}>", f"child already has a parent")
            return

        # 执行添加操作：更新父子关系 | Perform add operation: update parent-child relationship
        self._children.append(child)
        child._parent = self

    def __remove_child__(self, child_or_name):
        """删除一个子节点，支持按对象或名称删除。

        Removes a child node by object reference or name.

        Args:
            child_or_name: 子节点对象或名称 | Child node object or name

        Returns:
            None
        """
        target_child = None  # 要删除的目标子节点 | Target child node to remove

        # 根据参数类型查找目标子节点 | Find target child based on parameter type
        if isinstance(child_or_name, _NamedNode):
            # 直接对象匹配 | Direct object matching
            if child_or_name in self._children:
                target_child = child_or_name
        elif isinstance(child_or_name, str):
            # 按名称查找 | Find by name
            for child in self._children:
                if child._proto_name == child_or_name:
                    target_child = child
                    break
        else:
            # 无效参数类型处理 | Invalid parameter type handling
            if LANGUAGE == 'cn':
                std.warn(f"_NamedNode<{self.NAME}>", f"无效的参数类型：{type(child_or_name)}")
            else:
                std.warn(f"_NamedNode<{self.NAME}>", f"Invalid parameter type: {type(child_or_name)}")
            return

        # 执行删除操作：从列表移除并断开父子关系 | Perform removal: remove from list and disconnect parent-child relationship
        if target_child is not None:
            self._children.remove(target_child)
            target_child._parent = None
        else:
            # 未找到目标子节点 | Target child not found
            if LANGUAGE == 'cn':
                std.warn(f"_NamedNode<{self.NAME}>", f"未找到子节点：{child_or_name}")
            else:
                std.warn(f"_NamedNode<{self.NAME}>", f"Child not found: {child_or_name}")


class Stage(_NamedNode, metaclass=StageMachineLogicMeta):
    NAME = "Stage"
    LOG = True
    LIMIT: int = 24  # 最大递归深度
    RED_DOT = std.ansi_color("#FF7A7A") + "..." + JS_RESET
    GREEN_DOT = std.ansi_color("#ADFF3F") + "..." + JS_RESET
    BLUE_DOT = std.ansi_color("#8ACEFF") + "..." + JS_RESET
    COLORED_DOT = std.ansi_color("#FF7A7A") + "." + std.ansi_color("#ADFF3F") + "." + std.ansi_color("#8ACEFF") + "." + JS_RESET
    __id__ = {}  # 用于记录基于NAME区别各类的ID
    __states__ = []  # 这个属性由元类自动添加，除此外只读

    # 这个类不是元类维护的类。

    def __init__(self, inst: any = None):
        super().__init__()
        # 检查 NAME 是否为空
        if not self.NAME:
            # raise Exception(f"Logic '{self.NAME}' has no name.")
            if LANGUAGE == 'cn':
                std.error(self.__class__.__name__, "NAME值没有设定或设定为空串。")
            else:
                std.error(self.__class__.__name__, "NAME value is not set or is an empty string.")
        # 检查 NAME 是否以数字结尾
        if self.NAME and self.NAME[len(self.NAME) - 1].isdigit():
            # raise Exception(f"Name '{self.NAME}' ends with a digit, which is not allowed.")
            if LANGUAGE == 'cn':
                std.error(self.__class__.__name__, f"NAME值以数字结尾，这是不允许的。:{self.NAME}")
            else:
                std.error(self.__class__.__name__, "NAME value ends with a digit, which is not allowed.: " + self.NAME)
        # 检查LIMIT是否为正整数
        if not isinstance(self.LIMIT, int) or self.LIMIT <= 0:  # raise Exception(f"LIMIT must be a positive integer, but got {self.LIMIT}.")
            if LANGUAGE == 'cn':
                std.error(f"{self.__class__.__name__}<{self.NAME}>", f"LIMIT必须是正整数，但是得到了{self.LIMIT}。")
            else:
                std.error(f"{self.__class__.__name__}<{self.NAME}>", f"LIMIT must be a positive integer, but got {self.LIMIT}.")
        # 检查LIMIT较大值
        if self.LIMIT > 64:  # warn(f"LIMIT值较大: {self.LIMIT}")
            if LANGUAGE == 'cn':
                std.warn(f"{self.__class__.__name__}<{self.NAME}>", f"LIMIT值较大: {self.LIMIT}")
            else:
                std.warn(f"{self.__class__.__name__}<{self.NAME}>", f"LIMIT value is large: {self.LIMIT}")
        ######
        self._inst = inst
        self._recursive_left = self.LIMIT
        self._states_length = len(self.__states__)
        self._current = None
        self._uid = self.__get_id__(self.NAME)
        self._name = f"{self.NAME}{self._uid}"
        self.name = self._name
        self.__listens__ = StageMachineLogicMeta.__listens__[self.__class__.__name__]  # > remove
        self.__recursive__ = StageMachineLogicMeta.__recursive__[self.__class__.__name__]  # > remove
        self.__behaviors__ = StageMachineLogicMeta.__behaviors__[self.__class__.__name__]  # > remove

        # #### Event System #### 
        if not self._name:
            self._name = self.__class__.__name__
        self._eda = None  # > remove
        # > insert self._eda = new ListenSystem(self, self._name);
        self._scs = None  # > remove
        # > insert self._scs = new ScheduleSystem(self);
        if self.__class__ is Stage:
            self.onLoading(self._inst, know, *self._children)

        # #### Listen System #### 
        # 全量注册监听事件
        for event_name, handlers in self.__listens__.items():
            for function_name, sources in handlers:
                # print(event_name, function_name, sources)
                func = getattr(self, function_name, None)
                if func is None:
                    if LANGUAGE == 'cn':
                        std.warn(f"{self._name}", f"监听事件 {event_name} 对应的函数 {function_name} 不存在。")
                    else:
                        std.warn(f"{self._name}", f"Function {function_name} for event {event_name} does not exist.")
                    continue

                # 如果function name同时位于states中，那么就忽略该事件。
                if function_name in self.__states__:
                    if LANGUAGE == 'cn':
                        std.warn(f"{self._name}", f"监听事件 {event_name} 对应的函数 {function_name} 是状态函数，不能作为事件监听函数。")
                    else:
                        std.warn(f"{self._name}", f"Function {function_name} for event {event_name} is a state function, and cannot be used as an event listener function.")
                    continue
                self._eda.listenFor(event_name, func, *sources)

        # #### Behavior System #### 
        # 当前如果正在执行行为，那么表示该行为的起点。
        self._bhead = None  # > remove
        # 行为上下文。
        self._bhcontext = {}  # > remove
        self._reset_context()
        # __behaviors__ be like {'second': {'children': ['test1', 'test2', 'test3'], 'composite': 'sequence'}, 'first': {'children': 'second', 'composite': None}}

    def onLoading(self, it: any, k: GlobalKnowledge, *ref):
        pass

    @classmethod
    def __get_id__(cls, _name):
        """
        获取指定名称的唯一ID，并自增该名称的ID计数。

        Args:
            _name (str): 名称。

        Returns:
            int: 唯一ID。
        """
        # 如果名称不在__id__字典中，则初始化其ID为0
        if _name not in cls.__id__:
            cls.__id__[_name] = 0
        # 自增名称的ID计数
        cls.__id__[_name] += 1
        # 返回自增后的ID
        return cls.__id__[_name]

    @property
    def inst(self) -> any:
        """
        获取逻辑/状态机对象的绑定实例。

        Description:
            Attribute `inst` represents the instance of the logic/Stage 's object.  
            It is a read-only attribute whose value is set during the initialization of the instance.  
            `inst` 属性表示逻辑/状态机对象的实例。它是一个只读属性，其值在实例初始化时被自动设置。  

        Returns:
            any: the binded instance of the logic object. 逻辑/状态机的绑定实例。

        Example:
            >>> logic_instance = Logic()  
            >>> print(logic_instance.inst)  
            None
        """
        return self._inst

    @property
    def name(self) -> str:
        """
        获取逻辑/状态机实例的名称。

        Description:
            Attribute `name` represents the name of the logic instance.  
            It is a read-only attribute whose value is set during the initialization of the instance.  
            `name` 属性表示逻辑实例的名称。它是一个只读属性，其值在实例初始化时被自动设置。  

        Returns:
            str: the name of the logic instance. 实例的名称。  

        Example:
            >>> logic_instance = Logic()  
            >>> print(logic_instance.name)  
            "Logic0"
        """
        return self._name

    @name.setter
    def name(self, value: str):
        """
        不应该由用户使用。
        """
        self._name = value

    # ## Event functions ## #
    def listenFor(self, ename: str, callback: callable, *sources: str):
        """
        * 监听事件 | Listen for events
        * 如果sources为None，则监听所有来源 | If sources is None, listen to all sources

        Args:
            ename: str  # 事件名 | event name
            callback: callable  # 回调函数 | callback function
            sources: str | None  # 来源列表 | source str

        Returns:
            None
        """
        sources = sources if sources else []
        self._eda.listenFor(ename, callback, *sources)

    def pushEvent(self, ename: str, data: dict | UsrObject | None = None, *targets: str):
        """
        * 推送事件 | Push events

        Args:
            ename: str  # 事件名 | event name
            data: dict | UsrObject | None  # 事件数据 | event data
            targets: str  # 目标监听器名称列表（可变参数）| target listener names (variadic)

        Returns:
            None

        Note:
            - 如果指定 targets，则优先匹配目标，忽略 sources 过滤
            - 如果未指定 targets，则使用原有的 sources 过滤逻辑
            - targets 使用 startsWith 方式进行匹配
        """
        # 注意：_eda.pushEvent 在 JavaScript 实现中已经处理了 targets 参数
        self._eda.pushEvent(ename, data, *targets)

    def cancelListen(self, ename: str):
        """
        * 取消监听事件 | Cancel listening for events
        """
        self._eda.cancelListen(ename)

    @property
    def current(self) -> str:
        """
        获取逻辑实例当前所处的状态。

        Description:
            Attribute `current` represents the current state of the logic instance.  
            It is a read-only attribute whose value is maintained by the state machine and reflects the instance's position in the state transition process.  
            `current` 属性表示逻辑实例当前所处的状态。它是一个只读属性，其值由状态机维护，反映实例在状态切换过程中的当前的状态。  

        Returns:
            str: the current state name of the logic instance. 当前状态的名称。

        Example:
            >>> logic_instance = Logic()  
            >>> print(logic_instance.current)  
            None  
            >>> # define a new Logic with state-function  
            >>> # 定义一个带有状态函数的新逻辑  
            >>> class MyLogic(Logic):  
            ...     def initial_state(self, inst:any, k: GlobalKnowledge):  
            ...         return "active_state"  
            ...  
            ...     def active_state(self, inst:any, k: GlobalKnowledge):  
            ...         return "active_state2"  
            ...  
            ...     def active_state2(self, inst:any, k: GlobalKnowledge):  
            ...         return "active_state"  
            ...  
            >>> my_logic = MyLogic()  
            >>> print(my_logic.current)  
            "initial_state"  
            >>> # When the instance is `_enter()` in the scheduler, each call to the _step() method will update the `current` attribute once.  
            >>> # 当实例在调度器中完成_enter()方法调用后，每次_step()方法的调用都会更新一次current属性  
            >>> print(my_logic.current)  
            "active_state"  
            >>> # Sometimes you may want to perform multiple state transitions within a single tick, in which case you need to use the `recursive` decorator.  
            >>> # The state method decorated with this decorator will immediately call `current` update with the new state after returning the new state.  
            >>> # 有时候，你希望在一个tick内执行多个状态跳变，这时你需要用到recursive装饰器。  
            >>> # 被这个装饰器装饰的状态方法会在返回新状态后立即以新状态再次调用`current`的更新。  
            >>> class MyLogic2(Logic):  
            ...     @recursive  
            ...     def initial_state(self, inst:any, k: GlobalKnowledge):  
            ...         return "active_state"  
            ...  
            ...     def active_state(self, inst:any, k: GlobalKnowledge):  
            ...         return "active_state2"  
            ...  
            ...     def active_state2(self, inst:any, k: GlobalKnowledge):  
            ...         return "active_state"  
            ...  
            >>> my_logic2 = MyLogic2()  
            >>> print(my_logic2.current)  # print after the first update  
            "active_state2"  


        Notes:
            - `current` 属性逻辑上是只读的，不应直接修改。 除非你清楚你在做什么。 
            - 该值在状态切换时会自动更新，并触发 `onChanged` 方法的调用。  
            - 如果需要了解状态切换的原因或目标，可以结合 `changed` 方法的参数来获取更多信息。  
        """
        return self._current

    @current.setter
    def current(self, value: str):
        """
        请谨慎使用。
        
        """

        if value not in self.__states__:
            if LANGUAGE == 'cn':
                std.error(self._name + ".current", "无效的新状态: " + value)
            else:
                std.error(self._name + ".current", "Invalid New state: " + value)
            return

        if self._current == value:
            return

        if self._bhead is not None and value != self._bhead:
            if LANGUAGE == 'cn':
                std.warn(self._name + ".current", "当前正处于行为状态，手动切换将丢失行为上下文。")
            else:
                std.warn(self._name + ".current", "Manually switching states while in behavior mode will lose behavior context.")
            self._bhead = None

        try:
            self.onChanged(self._current, value, self._inst, know)
        except Exception as e:
            if LANGUAGE == 'cn':
                std.error(self._name + ".changed", "执行状态切换逻辑时发生错误: " + str(e))
            else:
                std.error(self._name + ".changed", "An error occurred while executing the state change logic: " + str(e))

        self._current = value

    def handleStage(self, log=None, _me=None):
        """
        执行当前状态，若返回一个str，则切换到该状态。

        Args:
            log (bool): 是否打印日志，默认为True。

        Raises:
            ValueError: 如果当前状态或目标状态无效。
        """
        if log is None: log = self.LOG
        # print(f"me: {self.name}, current: {self._current}, state_len: {self._states_length}")
        # print("详细状态、recursive、behavior:", self.__states__, '\n', self.__recursive__, '\n', self.__behaviors__)
        if self._states_length == 0: return

        # 检查是否recursive
        recursive_flag = False
        uf_recursive = False

        if self._current not in self.__states__:
            uf_recursive = True
            if len(self.__states__) and (self._current is None or self._current is undefined):
                self._current = self.__states__[0]
            else:
                # raise ValueError(f"Invalid state '{self.current}' in Stage '{self.NAME}'")
                # print("states", self.__states__)
                if LANGUAGE == 'cn':
                    std.error(self._name + ".fbm", "无效的状态: " + self._current, "states:", str(self.__states__))
                else:
                    std.error(self._name + ".fbm", "Invalid state: " + self._current, "states:", str(self.__states__))

        try:
            next_state = getattr(self, self._current)(self._inst, know, *self._children)
            if next_state is undefined: next_state = None
            # print(f"raw next_state: {next_state}")
        except Exception as e:
            if LANGUAGE == 'cn':
                std.error(self._name + "." + self._current, "执行状态逻辑时发生错误: " + str(e))
            else:
                std.error(self._name + "." + self._current,
                          "An error occurred while executing the state logic: " + str(e))
            return

        behavior_stop = False
        running_flag = False
        success_flag = False
        failure_flag = False
        if not isinstance(next_state, str):
            # 检查bh特殊模式
            accepted = math.random()  # > remove
            # > insert const accepted = (next_state instanceof BT_Status) || next_state === true || next_state === false || next_state === null;

            if accepted:
                success_flag = (next_state is SUCCESS) or (next_state is True)
                running_flag = (next_state is RUNNING) or (next_state is None)
                failure_flag = (next_state is FAILURE) or (next_state is False)
                if success_flag: next_state = SUCCESS
                elif failure_flag: next_state = FAILURE
                # print(f"current:{self._current} call result: {next_state}, _me={_me}")
                if not running_flag or self._bhead is not None:
                    next_state = self._handle_behavior(self._current, next_state, _me is None)
                    if next_state == self._bhead and next_state is not None: behavior_stop = True
                
                if next_state is None: next_state = self._current
            else:
                if LANGUAGE == 'cn':
                    std.warn(self._name + ".fbm", "状态方法返回一个意外的非字符串值: " + str(next_state))
                else:
                    std.warn(self._name + ".fbm", "State method returned an unexpected non-string value: " + str(next_state))


        # 只要返回字符串，总是视作打断行为树。
        else:
            behavior_stop = True

        # 行为树结束，重置行为状态
        if behavior_stop: self._reset_context()

        # 非运行状态，且行为树头不为空，标记递归调用
        if self._bhead is not None and not running_flag:
            recursive_flag = True
        
        # 强制递归调用
        if self._bhcontext["para-force"]:
            self._bhcontext["para-force"] = False
            # print("Force.")
            recursive_flag = True

        # 检查新状态是否有效
        if next_state not in self.__states__:
            # raise ValueError(f"Invalid state '{next_state}' in Stage '{self.NAME}'")
            if LANGUAGE == 'cn':
                std.error(self._name + ".fbm", "无效的新状态: " + str(next_state), "states:", str(self.__states__))
            else:
                std.error(self._name + ".fbm", "Invalid next state: " + str(next_state), "states:", str(self.__states__))
            return

        # print(f"uf_recursive={uf_recursive} current={self._current} next_state={next_state} states={self.__states__} recursive={self.__recursive__}")
        if (uf_recursive and self._current in self.__recursive__) or (next_state in self.__recursive__) or recursive_flag:
            self._recursive_left -= 1
            if self._recursive_left <= 0:
                if LANGUAGE == 'cn':
                    std.error(self._name + ".fbm", "递归调用次数超过限制: " + str(self.LIMIT))
                else:
                    std.error(self._name + ".fbm", "Recursive call count exceeded limit: " + str(self.LIMIT))
                return
            recursive_flag = True

        if log:
            dot = "..."
            if success_flag:
                dot = self.GREEN_DOT
            elif failure_flag:
                dot = self.RED_DOT
            # print(f"success_flag={success_flag} failure_flag={failure_flag}, {self.GREEN_DOT},{self.RED_DOT}")
            std.info(dot if _me else (self._name + ".fbm"), self._current + " -> " + str(next_state), dot if recursive_flag else "")

        try:
            if isinstance(next_state, str) and self._current != next_state:
                self.onChanged(self._current, next_state, self._inst, know)
        except Exception as e:
            if LANGUAGE == 'cn':
                std.error(self._name + ".changed", "执行状态切换逻辑时发生错误: " + str(e))
            else:
                std.error(self._name + ".changed", "An error occurred while executing the state change logic: " + str(e))

        # 更新当前状态
        if isinstance(next_state, str):
            self._current = next_state

        if recursive_flag:
            self.handleStage(log, True)
        else:
            self._recursive_left = self.LIMIT

    def _reset_context(self):
        """
        重置行为上下文。
        """
        self._bhead = None
        self._bhcontext = {"stack": []}

    def _trance_back(self, peek: bool = False):
        """
        回溯行为树，返回上一个组合节点或是head。
        """
        context_stack = self._bhcontext.py_get("stack", [])
        if context_stack.length <= 0: return self._bhead
        index = context_stack.length - 1
        if peek: return context_stack[index]
        return context_stack.pop(index)
        
    def _handle_behavior(self, current_state, next_state, _from_stage_first: bool = False):
        """
        处理行为系统逻辑。

        Args:
            current_state (str): 当前状态名称。
            next_state (any): 状态方法返回的值。

        Returns:
            str: 处理后的下一个状态。
        """
        result_state = current_state
        context_stack = self._bhcontext["stack"]
        behavior_info = self.__behaviors__[current_state]
        # if st.na(behavior_info): return current_state
        # print(f"handle_behavior {current_state} -> {next_state}, info:{behavior_info}, stack:{context_stack}")

        if next_state is None or next_state is RUNNING:
            backend = self._trance_back(True)
            backend_info = self.__behaviors__[backend]
            
            if backend_info["composite"] == "parallel":
                para_context = self._bhcontext[backend]
                history = para_context["history"]
                self._bhcontext["para-force"] = True
                current_index = para_context["indexes"][para_context["current"]]
                
                # 查找下一个未执行的子节点
                # print(f"Running: {current_index}, from_stage_first={_from_stage_first}, history={history}")
                for bias in range(1, history.length):
                    i = (current_index + bias) % history.length
                    
                    if not history[i]:
                        # 清除force
                        if i < current_index and not _from_stage_first:
                            self._bhcontext["para-force"] = False
                        result_state = backend_info["children"][i]
                        para_context["current"] = result_state
                        break
                    
            else:
                result_state = current_state
        # FAILURE的情况
        elif next_state is FAILURE:
            backend = self._trance_back(True)
            if backend is self._bhead:
                result_state = self._bhead if self._bhead else current_state
                self._reset_context()
            else:
                backend_info = self.__behaviors__[backend]  # !如果此处报错，说明曾经一个非组合的节点被推入栈中
                # print(f"Failure: backend={backend}, backend_info={backend_info}")
                if backend_info["composite"] == "selector":
                    sel_context = self._bhcontext[backend]  # !如果此处报错，说明曾经一个selector的节点被推入栈中但是没有初始化上下文
                    current_index = sel_context["index"] + 1
                    sel_context["index"] = current_index
                    # print(f"bt_context={sel_context}, current_index={current_index}")

                    if current_index >= len(backend_info["children"]):
                        # 所有子节点都失败了，那么这个selector也失败了
                        # 弹出selector
                        self._trance_back()

                        # 清除selector的上下文
                        del self._bhcontext[backend]

                        result_state = self._handle_behavior(self._trance_back(True), FAILURE)
                    else:
                        result_state = backend_info["children"][current_index]
                elif backend_info["composite"] == "parallel":
                    # parallel节点的处理：继续执行下一个子节点，该失败节点对应位置置为True，表示已执行完毕
                    para_context = self._bhcontext[backend]
                    history = para_context["history"]
                    indexes = para_context["indexes"]
                    para_current = para_context["current"]
                    current_index = indexes[para_current]
                    history[current_index] = True
                    para_context["left"] -= 1

                    if para_context["left"] <= 0:
                        # 所有子节点都执行完毕
                        # 弹出parallel节点
                        self._trance_back()

                        # 清除parallel的上下文
                        del self._bhcontext[backend]

                        # 所有子节点都失败了，那么这个parallel也失败了
                        result_state = self._handle_behavior(self._trance_back(True), FAILURE)
                    else:
                        # result_state = backend_info["children"][current_index]
                        # 查找下一个未执行的子节点
                        flag = False
                        for bias in range(1, history.length):
                            i = (current_index + bias) % history.length
                            if not history[i]:
                                result_state = backend_info["children"][i]
                                flag = True
                                break
                        
                        if not flag:
                            # 所有子节点都执行完毕, 立刻更新left
                            para_context["left"] = 0
                            
                            # 产生一个警告
                            if LANGUAGE == 'cn':
                                std.warn(self._name + ".fbm", f"并行节点 `{backend}` 所有子节点都执行完毕，但是其left不为0。")
                            else:
                                std.warn(self._name + ".fbm", f"Parallel node `{backend}` all children have been executed, but its left is not 0.")
                            
                            result_state = self._handle_behavior(current_state, FAILURE)  # 重试
                else:
                    result_state = self._handle_behavior(backend, FAILURE)
        # SUCCESS的情况
        elif next_state is SUCCESS:
            if self._bhead is None:
                self._bhead = current_state
            
            # print(f"SUCCESS: current_state={current_state}, behavior_info={behavior_info}")
            # 如果没有定义行为，那么找到下一个状态
            if not behavior_info:
                top_node = self._trance_back(True)
                top_behavior = self.__behaviors__[top_node]  # !如果此处报错，说明曾经一个非组合的节点被推入栈中
                # print(f"SUCCESS: top_node={top_node}, top_behavior={top_behavior}")
                if top_node is self._bhead:
                    result_state = self._bhead
                elif top_node is not self._bhead and top_behavior["composite"] is not None:
                    result_state = self._handle_behavior(top_node, SUCCESS)
                else:
                    # 那么这可能是一个孤立节点
                    result_state = current_state

                    if LANGUAGE == 'cn':
                        std.warn(self._name + ".fbm", "一个孤立行为状态正在重复，可能不是您期望的行为。状态: " + current_state)
                    else:
                        std.warn(self._name + ".fbm", "An orphan behavior state is being repeated, which may not be the behavior you expect. State: " + current_state)
            # 处理非组合行为
            elif behavior_info["composite"] is None and behavior_info["children"] is not None:
                result_state = behavior_info["children"]
            # 处理sequence节点
            elif behavior_info["composite"] == "sequence" and isinstance(behavior_info["children"], list):
                # 获取当前sequence的执行状态
                if current_state not in self._bhcontext:
                    seq_context = {"index": 0}
                    self._bhcontext[current_state] = seq_context
                else:
                    seq_context = self._bhcontext[current_state]

                current_index = seq_context["index"]
                children = behavior_info["children"]

                # 首次进入sequence，将当前状态压入栈
                if current_index is 0: 
                    context_stack.append(current_state)
                    result_state = children[current_index]

                # 检查是否有更多子节点要执行
                if current_index < len(children):
                    # 执行下一个子节点
                    result_state = children[current_index]
                    # 更新sequence上下文
                    seq_context["index"] = current_index + 1
                else:
                    # 所有子节点都执行完毕，整个sequence成功
                    # 从栈中弹出sequence节点
                    self._trance_back()

                    # 清除sequence上下文
                    if current_state in self._bhcontext:
                        del self._bhcontext[current_state]

                    top_node = self._trance_back(True)

                    if top_node is self._bhead:
                        result_state = self._bhead
                        self._reset_context()
                    else:
                        result_state = self._handle_behavior(top_node, SUCCESS)
            # 处理selector节点
            elif behavior_info["composite"] == "selector" and isinstance(behavior_info["children"], list):
                # 获取当前selector的执行状态
                if current_state not in self._bhcontext:
                    sel_context = {"index": 0}
                    self._bhcontext[current_state] = sel_context
                else:
                    sel_context = self._bhcontext[current_state]

                current_index = sel_context["index"]
                children = behavior_info["children"]

                # 首次进入selector，将当前状态压入栈
                if current_index == 0:
                    context_stack.append(current_state)
                    result_state = children[0]
                    # sel_context["index"] = 1
                else:
                    # 子节点成功，整个selector成功
                    # 从栈中弹出selector节点
                    self._trance_back()

                    # 清除selector上下文
                    if current_state in self._bhcontext:
                        del self._bhcontext[current_state]

                    top_node = self._trance_back(True)

                    if top_node is self._bhead:
                        result_state = self._bhead
                        self._reset_context()
                    else:
                        result_state = self._handle_behavior(top_node, SUCCESS)
            # 处理parallel节点
            elif behavior_info["composite"] == "parallel" and isinstance(behavior_info["children"], list):
                # 获取当前parallel的执行状态
                if current_state not in self._bhcontext:
                    # 初始化parallel上下文，result默认FAILURE
                    _history = []  # > remove
                    # > insert const _history = Array(behavior_info["children"].length).fill(false);
                    # para_context = {"index": 0, "result": FAILURE}
                    children = behavior_info["children"]
                    para_context = {"history": _history, "indexes": {}, "current": "", "left": children.length}
                    self._bhcontext[current_state] = para_context
                    initial_flag = True

                    for i in range(len(children)):
                        para_context["indexes"][children[i]] = i
                else:
                    para_context = self._bhcontext[current_state]
                    children = behavior_info["children"]
                    initial_flag = False


                # 首次进入parallel，将当前状态压入栈
                if initial_flag:
                    context_stack.append(current_state)
                    para_context["current"] = children[0]
                    result_state = children[0]
                else:
                    # 更新结果：使用OR逻辑，只要有一个SUCCESS就执行完毕
                    # 从栈中弹出parallel节点
                    self._trance_back()

                    # 清除parallel的上下文
                    if current_state in self._bhcontext:
                        del self._bhcontext[current_state]

                    top_node = self._trance_back(True)

                    if top_node is self._bhead:
                        result_state = self._bhead
                        self._reset_context()
                    else:
                        result_state = self._handle_behavior(top_node, SUCCESS)
        else:
            if LANGUAGE == 'cn':
                std.warn(self._name + ".fbm", f"意外的状态: {next_state}。程序不会终止，但这可能意味着状态机已经发生逻辑错误。")
            else:
                std.warn(self._name + ".fbm", f"Unexpected state: {next_state}. The program will not terminate, but this may indicate a logic error in the state machine.")

        return result_state

    def onChanged(self, src: str, dst: str, inst: any, k: GlobalKnowledge):
        """
        在不同状态切换时调用，子类可重写。

        Args:
            src (str): 源状态。
            dst (str): 目标状态。
            inst (any): 绑定的实例。
            k (GlobalKnowledge): 全局知识对象。
        """
        pass


class Logic(Stage):
    """
    所有逻辑的基类，提供了状态机的基本功能，可以在调度器中执行。

    本类通过元类（`StageMachineLogicMeta`）自动管理状态节点，并提供状态切换和生命周期管理功能。
    状态机的核心是通过状态方法的返回值来切换状态，并通过事件系统和调度器管理整个状态机的运行。

    ### 基础概念

    - **状态节点**：每个状态是一个方法，必须返回下一个状态的名称（字符串）。状态方法名不能以 `_` 开头。
    - **状态切换**：状态切换通过状态方法的返回值实现。例如，如果 `stateA` 方法返回 `"stateB"`，则状态机将切换到 `stateB`。
    - **递归执行**：使用 `@recursive` 装饰器标记状态方法，可在同一个 tick 内多次执行该状态，直到返回一个新的状态。
    - **调度器**：调度器（`Scheduler`）将 `Logic` 实例自动注册，并管理其生命周期。

    ### 状态定义与切换

    - **定义状态机**：创建一个继承自 `Logic` 的类，并定义状态方法。
    - **状态切换**：状态切换由状态方法的返回值决定。例如，在 `state1` 中返回 `"state2"` 将切换到 `state2`。
    - **递归状态切换**：使用 `@recursive` 装饰器标记状态方法，可在同一个 tick 内多次执行。

    ### 调度器与钩子

    - **调度器管理**：调度器会自动注册所有的 `Logic` 子类。每个 `Logic` 实例会在调度器的循环中调用 `_step` 方法。
    - **生命周期钩子**：`_check`、`_enter`、`_step`、`_exit` 等方法分别在不同的生命周期阶段被调用。

    ### 事件系统与绑定实例

    - **绑定实例**：`Logic` 实例可以通过构造函数绑定一个实例（`_inst`），用于传递上下文。
    - **事件系统**：可以在状态事件中触发自定义行为。

    ### 调试与日志

    - **状态日志**：启用 `LOG` 属性可查看状态切换日志。
    - **调试信息**：使用 `std.info` 和 `std.error` 输出调试信息。

    Example:
        以下是一个完整的示例，展示如何定义和使用一个状态机：

        ```python
        class TrafficLight(Logic):
            NAME = "TrafficLight"
            LIMIT = 3  # 设置递归深度限制

            def initial_state(self, it, k):  # 如果你不使用it和k则可以省略参数
                # 初始化状态
                print("Traffic light initializing...")
                return "red"

            def red(self):  # 如果你不使用it和k则可以省略参数
                print("Red light: STOP")
                return "green"  # 切换到 green 状态

            def green(self):  # 如果你不使用it和k则可以省略参数
                print("Green light: GO")
                return "yellow"

            @recursive  # 递归状态切换
            def yellow(self):  # 如果你不使用it和k则可以省略参数
                print("Yellow light: CAUTION")
                return "red"

            def onChange(self, current, next_state, it, k):  # 如果你不使用it和k则可以省略参数
                print(f"从 {current} 切换至 {next_state}")

        # 创建实例
        traffic_light = Scheduler().add("TrafficLight")
        # 运行游戏，观察输出:
        #    [tick 1]Traffic light initializing...
        #            从 initial_state 切换至 red
        #    [tick 2]Red light: STOP
        #            从 red 切换至 green
        #    [tick 3]Green light: GO
        #            从 green 切换至 yellow
        #    [tick 4]Yellow light: CAUTION
        #            从 yellow 切换至 red
        #            Red light: STOP
        #            从 red 切换至 green
        #    [tick 5]Green light: GO
        #            从 green 切换至 yellow
        #    ...
        
        ```
    """
    LOG: bool = True  # 是否输出状态机日志
    NAME: str = "Logic"  # 默认名称
    PRIORITY: int = 0  # 逻辑优先级, 数值越大, 优先级越高
    __names__ = {}  # 用于记录逻辑的名称
    __types__ = {}  # 用于记录逻辑的类型

    def __new__(args):
        # NOTE: transcrypt的阴间绝活，传入的参数实际是args，而不是cls
        inst_name = args[0]
        if isinstance(inst_name, str):
            proto = StageMachineLogicMeta.proto(inst_name)
            if proto is None:
                if LANGUAGE == "cn":
                    std.error("Logic", "未找到指定的逻辑: " + inst_name)
                else:
                    std.error("Logic", "Logic not found: " + inst_name)
            return proto(*args[1:])
        else:
            obj = super().__new__()  # > remove
            # > insert var obj = object.__new__.call(this, args);
            return obj

    def __init__(self, inst: any = None, *args):
        super().__init__(inst)
        self._alive = True
        self._enabled = True
        self._isEntered = False  # 调度器维护，用户不应修改

        # #### add into Scheduler ####
        Scheduler().add(self)

    # properties #
    @property
    def alive(self) -> bool:
        """
        获取实例的存活状态。

        Description:
            The `alive` property indicates whether the logic instance is currently active and should be processed by the scheduler.  
            When an instance's `alive` property is set to `False`, the scheduler will remove it from the update queue and call the `_exit` method to perform cleanup operations.  
            当实例被添加到调度器的更新队列时，`alive` 属性通常为 `True`。调度器会定期检查每个实例的 `alive` 属性，如果发现实例的 `alive` 属性为 `False`，  
            调度器会将该实例从更新队列中移除，并调用 `_exit` 方法来执行清理操作。  

        Returns:
            bool: True if the instance is alive (active), False otherwise. 如果实例存活（处于激活状态），返回 `True`；否则返回 `False`。

        Interaction with Scheduler:
            The scheduler checks the `alive` property during each cycle to determine whether to continue processing the instance.  
            If `alive` becomes `False`, the instance is marked for removal and its `_exit` method is invoked. This allows for proper resource cleanup and lifecycle management.  
            调度器在每次循环中都会检查实例的 `alive` 属性。  
            如果 `alive` 属性变为 `False`，实例会被标记为需要移除，并且调度器会在退出阶段调用 `_exit` 方法来清理资源。  

        Example:
            >>> logic_instance = Logic()  
            >>> print(logic_instance.alive)  
            True  
            >>> # Later, when the logic is no longer needed, set alive to False  
            >>> # 当实例不再需要时，将其 alive 属性设置为 False  
            >>> logic_instance._alive = False  
            >>> # The scheduler will then handle removal and cleanup in the next cycle  
            >>> # 调度器会在下一循环中处理移除和清理操作  
        """
        return self._alive

    @alive.setter
    def alive(self, value: bool):
        """
        设置实例的存活状态。

        Args:
            value (bool): 存活状态。如果为 `True`，则实例将保持激活状态；如果为 `False`，则实例将被标记为需要清理和移除。

        Description:
            The `alive` property controls the lifecycle of the logic instance.  
            When `alive` is set to `False`, the instance is marked for removal from the scheduler's update queue and its `_exit` method is called to perform cleanup operations.  
            `alive` 属性控制逻辑实例的生命周期。  
            当 `alive` 被设置为 `False` 时，实例将被标记为从调度器的更新队列中移除，并且其 `_exit` 方法将被调用以执行清理操作。
        """
        self._alive = value

    @property
    def uid(self) -> int:
        """
        Returns the unique identifier (UID) of this kind(by ```NAME```) logic instance.  
        The UID is generated based on the instance's name and an incrementing counter,  
        ensuring that each instance with the same ```NAME``` has a distinct identifier.  
        返回该类型(由```NAME```进行区分)的逻辑实例的唯一标识符 (UID)。  
        唯一标识符是基于实例的名称和一个递增计数器生成的，  
        确保了具有相同名称(```NAME```)的每个实例都有一个不同的标识符。  

        ●ω＜🤍♪: it starts from 1. For example, if the NAME is "worker", the first instance's uid is 1, i.e. "worker1".  
        ●ω＜🤍♪: The UID is unique within the same ```NAME```, but it may be the same across different ```NAME```s. For example, "worker1" and "builder1", their uids are both 1.  
        ●ω＜🤍♪: 从1开始。比如NAME为"worker"，那么第一个实例的uid为1，即"worker1"。  
        ●ω＜🤍♪: 这个uid只在同一```NAME```下唯一，不同```NAME```下的uid可能相同。比如"worker1"和"builder1", 它们的uid都是1。  

        Returns:
            int: The unique identifier of this kind(by ```NAME```) and this instance. 该实例在对应```NAME```下的唯一标识符。

        Example:
            >>> logic_instance = Logic()  
            >>> print(logic_instance.uid)  
            1  
            >>> # Each instance with the same ```NAME``` will have a different UID  
            >>> logic_instance2 = Logic()  
            >>> print(logic_instance2.uid)  
            2
        """
        return self._uid

    @property
    def enabled(self) -> bool:
        """
        获取逻辑实例在调度器中是否参与各个运作周期。  
        
        Description:
            Attribute `enabled` represents whether the logic instance participates in the operation cycles of the scheduler.  
            If the value of this attribute is False, the scheduler will not process the logic instance in the current tick, and the `_check()`, `_enter()`, and `_step()` methods will not be called.  
            However, if the `_alive` attribute of the scheduler is False at the end of the current tick, the `_exit()` method will still be called to exit the logic instance.  
            `enabled` 属性表示逻辑实例是否参与调度器的各个运作周期。如果该属性的值为False，调度器将不会在当前tick中处理该逻辑实例，`_check()`、`_enter()`和`_step()`方法将不会被调用。  
            然而，如果调度器的`_alive`属性在当前tick结束时为False，`_exit()`方法仍然会被调用以执行退出逻辑。
            
        Returns:
            bool: whether the logic instance participates in the operation cycles of the scheduler. 逻辑实例是否参与调度器的各个运作周期。
                    
        """
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        """
        设置逻辑实例在调度器中是否参与各个运作周期。

        Args:
            value (bool): whether the logic instance participates in the operation cycles of the scheduler. 逻辑实例是否参与调度器的各个运作周期。

        Returns:
            None
        """
        self._enabled = value

    # system callbacks #

    def _check(self, is_seek: bool) -> None | str | bool:
        return True  # 返回True表示检查通过

    def _enter(self) -> None | str | bool:
        self.onStart(self._inst, know, *self._children)
        return

    def _exit(self) -> None | str | bool:
        self.onStop(self._inst, know, *self._children)
        return

    def _step(self) -> None | str | bool:
        self.handleStage(self.LOG)
        self.onStep(self._inst, know, *self._children)
        return

    # ## ref functions ## #
    @classmethod
    def ref(cls, name: str) -> "Logic" | list["Logic"] | None:
        """
        通过名称获取对应Logic实例（单例或列表）

        如果你的name不以数字结尾，将返回一个列表，否则返回一个Logic实例。

        Args:
            name: str  # Logic名称

        Note:
            具体返回的Logic的实际类型取决于你是通过哪个类调用的此方法。它们都基于_UpdatableStage类。

        Returns:
            list | Logic  # Logic实例或列表

        Usage:
            insts = Logic.ref("example")  # 返回Logic实例的列表  
            single_inst = Logic.ref("example1")  # 返回特定的Logic实例

        Assumption:
            py_get 等同于 dict.get，即从字典中安全地获取值。
        """
        if name is None or name is undefined:  # 检查name是否为None或未定义
            return None

        name_len = len(name)
        if name_len <= 0:  # 检查name是否为空字符串
            if LANGUAGE == 'cn':
                std.error(f"{cls.__name__}.ref", "参数name的传入值不能为空。")
            else:
                std.error(f"{cls.__name__}.ref", "The value of parameter 'name' cannot be empty.")
            return None

        if not name[name_len - 1].isdigit():  # 如果name不以数字结尾
            # 尝试从cls.__names__中获取所有同名实例
            insts = cls.__names__.py_get(name, {})  # 类似于dict.get，若不存在则返回空字典
            insts = list(insts.values())  # 获取实例列表
            return [it for it in insts if it._alive]
        else:
            # 处理以数字结尾的名称
            if name_len <= 1:  # 如果名称全是数字
                error_msg = (
                    f"{cls.__name__}.ref: 传入的参数name的值不能只包含数字: {name}"
                    if LANGUAGE == 'cn'
                    else f"{cls.__name__}.ref: The value of parameter 'name' cannot only contain numbers: {name}"
                )
                std.error(error_msg)
                return None
            # 反向遍历字符串，找到第一个非数字字符
            for i in range(name_len - 1, -1, -1):
                if not name[i].isdigit():
                    # 分割名称为非数字部分和数字部分
                    print(name, i)
                    name_part = name[:i + 1]
                    num_part = int(name[i + 1:])
                    insts = cls.__names__.py_get(name_part, {})  # 获取实例字典
                    _ = insts.py_get(num_part, None)  # 获取实例列表
                    if not _ or not _._alive:
                        return None
                    return _
            return None  # 其他情况返回None

    def refLast(self) -> "Logic" | None:
        """
        获取当前逻辑模块的前一个实例

        该方法通过 `self.ref(self._name)` 获取与当前逻辑模块名称相关的实例列表，
        并查找当前模块在列表中的位置，返回前一个模块实例。

        Returns:
            Logic | None: 前一个逻辑模块实例或 None（如果不存在）

        Note:
            如果当前逻辑模块为列表中的第一个元素，或列表长度小于等于1，则返回 None。
        """
        lst = self.ref(self.NAME)
        if lst is None:
            if LANGUAGE == "cn":
                std.warn(f"{self._name}.refLast", "指定的基础名不存在: " + self.NAME)
            else:
                std.warn(f"{self._name}.refLast", "The specified base name does not exist: " + self.NAME)
            return None
        length = len(lst)
        if length <= 1:
            return None  # 如果列表长度小于等于1，直接返回None

        found = -1
        # print(f"me: {self}")
        # 遍历列表，从第二个元素开始寻找当前实例
        for i in range(1, length):
            # print(f"lst[{i}]: {lst[i]}")
            if lst[i] == self:
                found = i
                break

        if found != -1:
            # 返回前一个元素
            return lst[found - 1] if found > 0 else None
        else:
            return None  # 如果当前实例未找到或为第一个元素

    def refNext(self) -> "Logic" | None:
        """
        获取当前逻辑模块的下一个实例

        该方法通过 `self.ref(self._name)` 获取与当前逻辑模块名称相关的实例列表，
        并查找当前模块在列表中的位置，返回下一个模块实例。

        Returns:
            Logic | None: 下一个逻辑模块实例或 None（如果不存在）

        Note:
            如果当前逻辑模块为列表中的最后一个元素，或列表长度小于等于1，则返回 None。
        """
        lst = self.ref(self.NAME)
        if lst is None:
            if LANGUAGE == "cn":
                std.warn(f"{self._name}.refNext", "指定的基础名不存在: " + self.NAME)
            else:
                std.warn(f"{self._name}.refNext", "The specified base name does not exist: " + self.NAME)
            return None
        length = len(lst)
        if length <= 1:
            return None  # 如果列表长度小于等于1，直接返回None

        found = -1
        # 遍历列表，查找当前实例的位置
        for i in range(length):
            if lst[i] == self:
                found = i
                break

        if found != -1 and found < length - 1:
            # 返回下一个元素
            return lst[found + 1]
        else:
            return None  # 如果当前实例未找到或为最后一个元素

    def refAdjacent(self) -> tuple["Logic | None", "Logic | None"]:
        """
        获取当前逻辑模块的前一个和后一个实例

        该方法返回一个包含两个元素的元组，分别代表前一个和后一个实例。

        Returns:
            tuple[Logic | None, Logic | None]: 前一个和后一个逻辑模块实例
        """
        # 从名称获取实例列表
        instance_list = self.ref(self.NAME)
        if instance_list is None:
            # 如果没有获取到实例列表
            return (None, None)

        length = len(instance_list)
        if length <= 1:
            # 如果列表长度小于等于1，无法得到前后实例
            return (None, None)

        # 查找当前实例所在位置
        current_index = instance_list.length - 1
        for idx, inst in enumerate(instance_list):
            if inst == self:
                current_index = idx
                break

        # 根据找到的索引，确定前一个和下一个实例
        prev_instance = instance_list[current_index - 1] if current_index > 0 else None
        next_instance = instance_list[current_index + 1] if current_index < length - 1 else None

        return prev_instance, next_instance

    def refEnd(self) -> "Logic" | None:
        """
        获取同名逻辑模块列表中的最后一个实例

        Returns:
            Logic | None: 最后一个同名逻辑模块实例或 None
        """
        # 从名称获取实例列表
        instance_list = self.ref(self.NAME)

        # 如果没有获取到实例列表或列表为空
        if not instance_list:
            return None

        # 返回列表的最后一个元素
        return instance_list[instance_list.length - 1]

    def refHead(self) -> "Logic" | None:
        """
        获取同名逻辑模块列表中的第一个实例

        Returns:
            Logic | None: 第一个同名逻辑模块实例或 None
        """
        # 从名称获取实例列表
        instance_list = self.ref(self.NAME)

        # 如果没有获取到实例列表或列表为空
        if not instance_list:
            return None
        # 返回列表的第一个元素
        return instance_list[0]

    # ## onXxx callbacks ## #

    def onLoading(self, it: any, k: GlobalKnowledge, *children) -> None:
        """
        当init完成后，立刻调用此方法  
        *这个函数由调度器调用，以适应不同继承层次的类实现自己的init逻辑后才执行此方法

        Args:
            it (any): 绑定的实例。可能为None
            k (GlobalKnowledge): 全局知识对象。
        """
        pass

    def onStart(self, it: any, k: GlobalKnowledge, *children) -> None:
        pass

    def onStep(self, it: any, k: GlobalKnowledge, *children) -> None:
        pass

    def onStop(self, it: any, k: GlobalKnowledge, *children) -> None:
        pass

    # ## Queue functions ## #
    @staticmethod
    def productQueue() -> list["Logic"]:
        """
        这个函数可以返回当前等待生产creep的CreepLogic的实例列表 | This function can return a list of instances of CreepLogic waiting to produce creep

        Returns:
            list["CreepLogic"]
        """
        res = []
        sch = Scheduler()
        for logic in sch.updates:
            if logic._isEntered:
                continue
            res.append(logic)
        return res

    @classmethod
    def showQueue(cls) -> None:
        """
        这个函数可以返回当前等待生产creep的CreepLogic的实例列表 | This function can return a list of instances of CreepLogic waiting to produce creep

        Returns:
            list["CreepLogic"]
        """
        queues = cls.productQueue()
        if len(queues) > 0:
            if LANGUAGE == "cn":
                std.info(f"{cls.__name__}.showQueue",
                         "当前等待生产creep的CreepLogic的实例列表: \n" + "\n".join([str(lc) for lc in queues]))
            else:
                std.info(f"{cls.__name__}.showQueue",
                         "Current list of CreepLogic waiting to produce creep: \n" + "\n".join(
                             [str(lc) for lc in queues]))
        else:
            if LANGUAGE == "cn":
                std.info(f"{cls.__name__}.showQueue", "当前没有等待生产creep的CreepLogic的实例列表")
            else:
                std.info(f"{cls.__name__}.showQueue", "No CreepLogic waiting to produce creep")
        print()  # 换行

    def schedule(self, delay: int, callback: callable):
        """
        * 延迟执行 | Delay execution

        Args:
            delay: int
            callback: callable
        """
        self._scs.schedule(delay, callback)

    def cancelSchedule(self, callback: callable):
        """
        * 取消延迟执行 | Cancel delay execution

        Args:
            callback: callable
        """
        self._scs.cancelSchedule(callback)

    def transform(self, name: str) -> "Logic":
        """
        * 转换为指定名称的逻辑模块 | Transform to the specified logic module

        Args:
            name: str

        Returns:
            Logic: 转换后的逻辑模块实例
        """
        self.alive = False
        return Logic(name, self.inst)

    def __str__(self):
        return f"{self.__class__.__name__}({self._name})"


class _CreepLogicSettings(Logic):
    """
    爬虫逻辑设置类，用于定义爬虫的基本属性和行为。

    Attributes:
        NAME (str): 爬虫名称。
        LINK (list[str]): 爬虫逻辑链接，标记的link只会启用一次，即使反复初始化。
        ONCE (bool): 如果killed函数被调用，置为True，爬虫逻辑将被删除。
        RECIPE (list[str]): 爬虫配方，默认为[MOVE]。
        OPTIMISE (bool): 是否自动优化配方，默认为True。
        EXTENSION (bool): 生产爬虫时是否使用extension，默认为True。
    """

    # ---------------------- 爬虫本体 | Creep --------------------------- #
    DRAW: bool = False  # 是否绘制爬虫信息
    LAYER: int = 10  # 爬虫绘制图层，默认为10

    # ---------------------- 流程与结构 | Flow & Struct --------------------------- #
    LINK: list[str] | str = None  # 爬虫逻辑链接
    ONCE: bool = True  # 是否禁用死亡后重生

    # ---------------------- 孵化选项 | Spawning --------------------------- #
    SPAWNABLE = True  # 是否可以孵化标志(如果没有孵化标志，将不会被孵化; 没有孵化的逻辑不会执行后续step
    RECIPE: list[str] | NamedRecipe = ["MOVE"]  # 爬虫配方，默认为["MOVE"]
    OPTIMISE: bool = True  # 自动优化配方标志
    EXTENSION: bool = True  # 使用extension标志
    DIRECTION: int = None  # 出生方向


class CreepLogic(_CreepLogicSettings, metaclass=StageMachineLogicMeta):
    """
    爬虫逻辑基类，继承自_CreepLogicSettings，提供爬虫逻辑的基本属性和方法。
    """
    SCH = Scheduler()  # 调度器实例
    NAME = "CreepLogic"  # 爬虫逻辑名称

    def __new__(args):
        # NOTE: transcrypt的阴间绝活，传入的参数实际是args，而不是cls
        spawn_creep_name = args[0]
        if isinstance(spawn_creep_name, str):
            # print("CreepLogic", "new", spawn_creep_name)
            proto = StageMachineLogicMeta.proto(spawn_creep_name)
            if proto is None:
                if LANGUAGE == "cn":
                    std.error("CreepLogic", "未找到指定的爬虫逻辑: " + spawn_creep_name)
                else:
                    std.error("CreepLogic", "CreepLogic not found: " + spawn_creep_name)
            return proto(*args[1:])
        else:
            obj = super().__new__()  # > remove
            # > insert var obj = object.__new__.call(this, args);
            return obj

    def __init__(self, spawn_creep_name: StructureSpawn | Creep | str | None = None, spawn_recipe: list[str] | str | StructureSpawn = None, recipe_optimise: list[str] | str | bool = None, _optimise: bool = None):
        """
        初始化爬虫逻辑 | Initialize creep logic

        有三种构造方式:
        CreepLogic(creep)  # 根据已有creep初始化逻辑
        CreepLogic(creep, spawn, [recipe, [optimise])  # 使用已有的creep，并且也指定spawn以重生。此时还可以紧跟recipe和optimise
        CreepLogic(spawn, [recipe, [optimise])  # 只指定spawn，后续可以紧跟recipe和optimise
        """
        super().__init__()
        self._creep: Creep | None = None
        # 绑定的creep | bound creep
        self._spawn: StructureSpawn | None = None
        # 绑定的spawn | bound spawn
        self.__param_in__(spawn_creep_name, spawn_recipe, recipe_optimise, _optimise)
        # --------------------------------
        self._movable: bool = True  # 用来限制可以移动的creep是否可以接受移动指令
        self._extension = self.EXTENSION  # 后续需要修改单个实例的extension属性
        self._view: View | None = View(self.LAYER) if self.DRAW else None
        self._pv: PartsVector = PartsVector(self._recipe)  # > remove
        # > insert self._pv = new PartsVector(self._recipe);
        self._cost: int = PartsVector.partsCost(self._recipe)
        self._grade: int = PartsVector.partsGrade(self._recipe)
        self._expand_name: str = self.__expand_name__(self._name, 16)  # 用于输出的爬虫名
        # > self.name = self._name;  // 'name' in python will be as 'py_name'. we need a real 'name' property here.

        # 与TeamLogic的藕合:
        self._team: TeamLogic | None = None
        self._spawning: bool = False  # 是否正在孵化

        # 检查
        self.__after_check__()

        # 处理link相关逻辑
        if self.__class__.LINK:
            tmp = self.__class__.LINK
            self.__class__.LINK = None  # 避免递归
            if isinstance(tmp, (list, tuple)):
                self.link(*tmp)
            elif isinstance(tmp, str):
                self.link(tmp)
            elif LANGUAGE == "cn":
                std.warn(f"CreepLogic<{self._name}>", "LINK属性必须是list或str, Got type=", str(type(tmp)))
            else:
                std.warn(f"CreepLogic<{self._name}>", "LINK must be a list or str, Got type=", str(type(tmp)))

    def __param_in__(self, sc: StructureSpawn | Creep, sr: list[str] | str | StructureSpawn = None, ro: list[str] | str | bool = True, _optimise: bool = None):
        # 根据传入的sc对象类型，分别赋值给creep或spawn
        if st.spawn(sc):
            self._spawn = sc
            _recipe = sr or None
            _optimise = ro or None
            
        elif st.creep(sc):
            self._creep = sc
            self._creep.logic = self
            # > insert self._creep.name = self._name;
            self._inst = self._creep

            if sr: self._spawn = sr
            _recipe = ro or None
            _optimise = _optimise or None
        else:
            if LANGUAGE == "cn": 
                std.error(f"CreepLogic<{self._name}>", "参数1必须是StructureSpawn或Creep类型，当前:" + str(type(sc)))
            else:
                std.error(f"CreepLogic<{self._name}>", "Parameter 1 must be StructureSpawn or Creep type, Got:" + str(type(sc)))
            raise
        
        if _recipe: 
            self._recipe = std.parse_recipe(_recipe)
        else:
            self._recipe = std.parse_recipe(self.RECIPE.recipe if self.RECIPE.recipe else self.RECIPE)
        if _optimise: 
            self._optimise = _optimise
        else:
            self._optimise = self.OPTIMISE

    def __after_check__(self):
        # 对name进行一系列检查
        name_len = len(self.NAME)
        if name_len <= 0:
            if LANGUAGE == "cn":
                std.error(f"CreepLogic", "CreepLogic必须有非空的唯一NAME，当前:" + self.NAME)
            else:
                std.error("CreepLogic", "CreepLogic must has not empty NAME, Got:" + self.NAME)
        if self.NAME[name_len - 1].isdigit():
            self.NAME += "_"
        if self.NAME in CreepLogic.__types__ and self.__class__.__name__ is not CreepLogic.__types__[self.NAME]:
            if LANGUAGE == "cn":
                std.error("CreepLogic", "CreepLogic必须具有唯一的NAME，当前:" + self.NAME, "上一个使用此NAME的class:" + self.__class__.__name__)
            else:
                std.error("CreepLogic", "CreepLogic must has unique type, Got '" + self.NAME, "' last used by class " + self.__class__.__name__)
        else:
            CreepLogic.__types__[self._name] = self.__class__.__name__
        if self.NAME not in CreepLogic.__names__:
            CreepLogic.__names__[self.NAME] = {}
        CreepLogic.__names__[self.NAME][self._uid] = self

        # 检查recipe是否为空，为空则报错
        if not self._recipe:
            if LANGUAGE == "cn":
                # 中文
                std.error(f"CreepLogic<{self._name}>", "CreepLogic必须含有正确的属性: RECIPE。当前类型:" + str(type(self._recipe)))
            else:
                std.error(f"CreepLogic<{self._name}>", "CreepLogic must has correct property: RECIPE. Got type:" + str(type(self._recipe)))

    @property
    def team(self) -> "TeamLogic":
        """
        获取绑定的TeamLogic实例
        * 如果未绑定，则返回None
        """
        return self._team

    @staticmethod
    def creeps(*logics) -> list[Creep | None]:
        """
        * 将多个爬虫逻辑实例转换为爬虫实例列表 | Convert multiple CreepLogic instances to a list of Creep instances
        如果逻辑没有绑定creep，则对应位置返回None | If the logic is not bound to a creep, return None at the corresponding position
        """
        # 将传入的爬虫逻辑实例转换为爬虫实例列表
        return [logic._creep if st.creep(logic._creep) else None for logic in logics]

    @property
    def creep(self) -> Creep | None:
        """
        获取绑定的creep
        * 如果creep未绑定，则返回None
        """
        return self._creep

    @property
    def c(self) -> Creep | None:
        """
        获取绑定的creep 简写版本
        * 如果creep未绑定，则返回None
        """
        return self._creep

    @property
    def movable(self) -> bool:
        """
        用于禁用可移动的creep接受移动指令
        
        * 只读
        最初设计来用于TeamLogic，允许TeamLogic禁用mate-CreepLogic中的move操作
        """
        return self._movable

    @property
    def spawn(self) -> StructureSpawn | None:
        """
        获取绑定的spawn
        * 如果creep未绑定，则返回None
        """
        return self._spawn

    @property
    def x(self) -> int | undefined:
        """
        获取creep的x坐标
        * 如果creep不存在，则返回undefined
        """
        if not self._creep or not self._creep.exists:
            return undefined
        return self._creep.x

    @property
    def y(self) -> int | undefined:
        """
        获取creep的y坐标
        * 如果creep不存在，则返回undefined
        """
        if not self._creep or not self._creep.exists:
            return undefined
        return self._creep.y

    @property
    def id(self) -> str:
        """
        获取creep的id
        * 如果creep未绑定，则返回空字符串
        """
        if not self._creep:
            return ""
        return self._creep.id

    @property
    def exists(self) -> bool:
        """
        获取creep是否存在
        * 如果creep未绑定，则返回False
        """
        if not self._creep:
            return False
        return self._creep.exists

    @property
    def recipe(self) -> list[str]:
        """
        获取配方
        """
        return self._recipe

    @property
    def partsVector(self) -> PartsVector:
        """
        获取配方的组件向量
        
        Description:
            等同于Creep的partsVector属性。  
            但是考虑到Creep不是一开始就存在的(至少大部分情况下是spawn稍后创建的)，  
            所以这里提供一个PartsVector属性，以便在Creep实例化之前使用，基于RECIPE。
            it is equivalent to the partsVector attribute of Creep.  
            However, considering that Creep is not always instantiated (at least most of the time it is created later by spawn),  
            so here is a PartsVector attribute provided for use before the Creep instance is instantiated, based on RECIPE.
        """
        if self._creep and self._creep.exists:
            return self._creep.partsVector
        return self._pv

    @property
    def cost(self) -> int:
        """
        获取recipe的cost
        """
        return self._cost

    @property
    def grade(self) -> int | undefined:
        """
        获取creep的分数
        * 如果creep不存在，则返回undefined
        """
        if not self._creep or not self._creep.exists:
            return undefined
        return self._creep.grade

    @property
    def ready(self) -> bool:
        """
        获取creep是否已经准备好
        
        Description:
            如果creep为空或是不存在，那么返回False。
            if creep is empty or not exists, return False.
        """
        return self._creep and self._creep.exists  # 采用了简短的判别方式，如果creep的类型不是Creep|None，可能会出现逻辑问题

    @property
    def spawning(self) -> bool:
        """
        获取creep是否正在孵化
        """
        return self._spawning

    def link(self, *next_logics: str) -> list["CreepLogic"]:
        """
        * 设置下一个CreepLogic | Set the next CreepLogic
        这个函数会在全局类型表中找到对应NAME的CreepLogic，并将其实例化 |
            This function will find the CreepLogic corresponding to NAME in the global type table and instantiate it

        返回的CreepLogics为disable状态，下一个stage=0的handle会自动启用此。在自动启用前，.enable函数将被禁用 |
            The returned CreepLogics are in disable state, and the next stage=0 handle will automatically enable this. Before automatic enabling, the .enable function will be disabled

        Args:
            next_logics: str  # CreepLogic.NAME

        Returns:
            list[CreepLogic]  # 返回下一个CreepLogic的实例列表 | Returns the instance list of the next CreepLogic
        """
        if len(next_logics) <= 0: return []
        results = []

        try:
            for name in next_logics:
                _new = CreepLogic(name, self._spawn)
                results.append(_new)
                self.__add_child__(_new)

        except Exception as e:
            # 中英文都一样
            std.error(f"CreepLogic<{self.NAME}>.link", e)

        return results

    def transform(self, new_type_name: str) -> "CreepLogic":
        """
        * 由用户调用，将此Updatable转换为新的类型 | called by user to transform this Updatable to a new type

        Example:
            work0.transform("traval-worker")
            # stop work0
            # start traval-worker0

        Args:
            new_type_name: str

        Returns:
            CreepLogic
        """

        _type = StageMachineLogicMeta.proto(new_type_name)
        if not _type:
            if LANGUAGE == "cn":
                std.error(f"{self._name}.transform", f"找不到原型：{new_type_name}")
            else:
                std.error(f"{self._name}.transform", f"Can not find prototype: {new_type_name}")
        if not issubclass(_type, CreepLogic):
            if LANGUAGE == "cn":
                std.error(f"CreepLogic<{self._name}>.transform", f"原型不是CreepLogic：{new_type_name}")
            else:
                std.error(f"CreepLogic<{self._name}>.transform", f"Prototype is not CreepLogic: {new_type_name}")
        logic = _type(self._creep, self._spawn)
        if not logic: return
        logic._parent = self._parent
        logic._children = self._children
        for child in self._children:
            child._parent = logic
        self._alive = False
        return logic

    def onLoading(self, c: Creep | None, k: GlobalKnowledge, *refs: "CreepLogic") -> None:
        """
        当__init__函数执行完后立刻调用该函数  
        called immediately after the __init__ function is executed
        
        * 是由Scheduler调用此的，为了确保不同Logic都能在__init__完全结束后再执行该函数
        * is called by Scheduler to ensure that different Logic can execute this function after __init__ is completely executed
        
        Args:
            c (Creep | None): 如果初始化时传入了creep，那么此处才为Creep实例，否则为None
            k (GlobalKnowledge): GlobalKnowledge全局知识
            refs (CreepLogic): 此处指由link创建的子实例。
        """
        pass

    def onStart(self, c: Creep, k: GlobalKnowledge, *refs: "CreepLogic") -> None:
        """
        当CreepLogic的check首次通过后，调度器执行其_enter方法，然后由其执行此函数
        called by the scheduler to execute its _enter method, and then execute this function
        
        Args:
            c (Creep): 此处应当总是有Creep的
            k (GlobalKnowledge): GlobalKnowledge全局知识
            refs (CreepLogic): 此处指由link创建的子实例。
        """
        pass

    def onStep(self, c: Creep, k: GlobalKnowledge, *refs) -> None:
        """
        当CreepLogic的check通过后，调度器执行其_step方法，然后由其执行此函数
        called by the scheduler to execute its _step method, and then execute this function
        
        Args:
            c (Creep): Creep实例
            k (GlobalKnowledge): GlobalKnowledge全局知识
            refs (CreepLogic): 此处指由link创建的子实例。
        """
        pass

    def onStop(self, c: Creep | None, k: GlobalKnowledge, *refs: "CreepLogic") -> None:
        """
        当CreepLogic的check首次不通过后，调度器执行其_exit方法，然后由其执行此函数
        called by the scheduler to execute its _exit method, and then execute this function
        
        Args:
            c (Creep | None): stop时可能没有Creep，也可能Creep已不存在(.exists=False)
            k (GlobalKnowledge): GlobalKnowledge全局知识
            refs (CreepLogic): 此处指由link创建的子实例。
        """
        pass

    def onDraw(self, c: Creep, v: View, k: GlobalKnowledge, *refs: "CreepLogic") -> None:
        """
        当你通过DRAW属性启用了绘制功能后，_step中会自动在最后执行此函数  
        called automatically at the end of _step when you enable the drawing function through the DRAW attribute

        Args:
            c: Creep
            v: View
            k: GlobalKnowledge
            refs: CreepLogic
        """
        # v.header(c)
        pass

    def onKilled(self, c: Creep | None, k: GlobalKnowledge, *refs: "CreepLogic") -> None:
        """
        当CreepLogic的creep从对局中被移除时，_check负责执行此函数  
        called by _check when the creep is removed from the game
        
        Args:
            c (Creep | None): 可能为None
            k (GlobalKnowledge): GlobalKnowledge全局知识
            refs (CreepLogic): 此处指由link创建的子实例。
        """
        pass

    def accelerate(self) -> None:
        """
        用于在创建CreepLogic的同一tick内，就触发Creep的创建。
        Used to accelerate the creation of CreepLogic in the same tick.
        """
        self._check(False)

    def _check(self, is_seek: bool) -> None | str | bool:
        if not self._alive: return False
        result = self._creep and self._creep.exists  # 采用简化的判定方式，要求数据必须是Creep|None类型。否则可能出现逻辑问题
        result = bool(result)  # 不知道为什么transcrypt对None and xxx的解释结果为None。所以这里强制转换为bool

        if self._isEntered and not result:  # 检查Creep是否存活
            # ## Killed ## #
            self.onKilled(self._creep, know, *self._children)

            if self.ONCE:
                self._alive = False
                return False
        # print("_check", self._name, result, self._creep)
        if not result and self._spawn:
            result = self._spawn.seek(self._recipe, self.name, self._optimise, self.DIRECTION)
            if result is True:
                self._spawning = True
                result = False
            elif result is not False:
                self._creep = result
                self._creep.logic = self
                self._creep.name = self._name
                self._inst = self._creep
                self._spawning = False
                result = True

        if is_seek or result: return result
        # ## 只有Creep不存在才会执行下面的代码 ## #
        if not self.SPAWNABLE: return  # return None表明不会打断后续CreepLogic

        # 尝试创建Creep
        if not self._recipe:  # 表明这是一个一次性的CreepLogic | This is a one-time CreepLogic
            self._alive = False
            return False
        elif self._spawn:  # 尝试创建新的Creep | Try to create a new Creep
            if not self._extension:
                if get.energy(self._spawn) < self._cost:
                    return False

            self._creep = self._spawn.create(self._recipe, self.name, self._optimise, self.DIRECTION)
            if isinstance(self._creep, int) and self._creep > 0:
                self._spawning = True
                self._extension = True  # 重置为True，表示不再限制extension | Reset to True, indicating no longer limiting extension
            if not st.creep(self._creep):
                self._creep = None
                return False
            self._spawning = False
            self._inst = self._creep
            self._creep.logic = self
            self._extension = self.EXTENSION  # 重置为默认值 | Reset to default value
            return True
        else:
            if LANGUAGE == "cn":
                std.error(f"CreepLogic<{self.NAME}>", "CreepLogic在初始化时没有传入spawn或creep，_check阶段无法创建或重生creep。")
            else:
                std.error(f"CreepLogic<{self.NAME}>",
                          "CreepLogic did not pass in a spawn or creep when initialized, and cannot create or respawn creep during the _check stage.")
            return None  # return None表明不会打断后续CreepLogic

    def _step(self) -> None | str | bool:
        self.handleStage(self.LOG)
        self.onStep(self._inst, know, *self._children)
        return

    BRACKET_COLOR = std.ansi_color(255, 248, 220)
    BRACKET_COLOR2 = std.ansi_color(255, 228, 225)

    @staticmethod
    def __get_state__(logic):
        return "🟢 " if logic.ready is undefined or logic.ready else (
            "🔵 " if logic.enabled else (
                "🟡 " if logic.alive else "☠️"
            )
        )

    @staticmethod
    def __expand_name__(_name, _length):
        # 将name扩充到指定长度，中文视作2字符，英文视作1字符
        # 内联计算字符串的实际长度，中文字符算2，英文字符算1
        current_length = 0
        for char in _name:
            if '\u4e00' <= char <= '\u9fff':  # 判断是否为中文字符
                current_length += 1.6
            else:
                current_length += 1

        current_length = math.ceil(current_length)

        # print("name:", _name, "length:", current_length)

        # 如果当前长度已经大于或等于目标长度，则直接返回
        if current_length >= _length:
            return _name

        # 计算需要填充的空格数量
        spaces_to_add = _length - current_length

        # 在右侧填充空格
        expanded_blanks = []
        for i in range(spaces_to_add):
            expanded_blanks.append(" ")
        expanded_name = _name + "".join(expanded_blanks)

        return expanded_name

    def __str__(self):
        creep_flag = st.creep(self._creep)
        spawn_flag = st.spawn(self._spawn)
        if creep_flag:
            creep_string = str(self._creep)
        else:
            creep_string = std.wrap_bracket("未绑定Creep" if LANGUAGE == "cn" else "No Creep", "[", self.BRACKET_COLOR2)
        if spawn_flag:
            spawn_string = str(self._spawn)
        else:
            spawn_string = std.wrap_bracket("未绑定Spawn" if LANGUAGE == "cn" else "No Spawn", "[", self.BRACKET_COLOR2)

        if creep_flag:
            spawn_string = ""
        elif spawn_flag:
            creep_string = ""

        if not self._parent or self._parent.ready:
            after_string = f"{creep_string}{spawn_string}"
        else:
            after_string = std.wrap_bracket(f"{self.__get_state__(self._parent)}{self._parent.name}", "[",
                                            self.BRACKET_COLOR)
        return f"{self.__get_state__(self)}{self._expand_name} {after_string}"


# > if 1
class Mate:
    # 继承Creep是仅用于IDE提示作用的，实际通过property机制返回Creep实例
    def __init__(self, name: str | None = None, spawn: StructureSpawn = None):
        self._proto_name: str = name  # 原型名称
        self._index: int = 0  # instance:TeamLogic第几个mate
        self._attr_name: str = None  # 大概长这样 f"mate_{self._proto_name}_{self._index}"
        self._proto: type = None
        self._spawn: StructureSpawn = spawn
        self._no_spawn_warn_flag: bool = False

        if name:
            self._proto = StageMachineLogicMeta.proto(name)
            if not self._proto:
                if LANGUAGE == "cn":
                    std.error(f"Mate<{self._proto_name}>", "未找到指定的CreepLogic-Proto: " + name)
                else:
                    std.error(f"Mate<{self._proto_name}>", "CreepLogic-Proto not found: " + name)

    def _MateGet_(self, instance) -> Creep | None:
        # 检查instance是否为TeamLogic实例
        if not isinstance(instance, TeamLogic):  # 不是TeamLogic实例, 可能是初始化阶段，直接返回self
            return self

        # 使用instance的__mates__属性来存储每个实例的logic
        if self._attr_name not in instance.__mates__:
            instance.__mates__[self._attr_name] = None

        logic = instance.__mates__[self._attr_name]

        # 如果已经有logic且ready，直接返回creep
        # print(f"Mate<{self._name}>: {logic}")
        if logic and logic.ready:
            return logic.creep

        # 否则尝试respawn
        return self.__respawn__(instance, self._attr_name)

    def _MateSet_(self, instance, value: str | Creep | CreepLogic | StructureSpawn):
        std.error("Mate", "Mate can not be assigned directly now.")
        if isinstance(value, StructureSpawn):
            self._spawn = value
        elif isinstance(value, str):
            self._proto_name = value
            self._proto = StageMachineLogicMeta.proto(value)
            if not self._proto:
                if LANGUAGE == "cn":
                    std.error(f"Mate<{self._proto_name}>", "未找到指定的CreepLogic-Proto: " + value)
                else:
                    std.error(f"Mate<{self._proto_name}>", "CreepLogic-Proto not found: " + value)
        elif isinstance(value, Creep):
            logic = value.logic
            if not logic:
                if LANGUAGE == "cn":
                    std.error("Mate", "Creep实例未绑定CreepLogic. Creep:", str(value))
                else:
                    std.error("Mate", "Creep instance is not bound to CreepLogic. Creep:", str(value))
            self._proto_name = logic.NAME
            self._proto = logic.__class__
            # 存储到instance的__mates__中
            if isinstance(instance, TeamLogic):
                self._attr_name = f"mate_{self._proto_name}_{self._index}"
                instance.__mates__[self._attr_name] = logic
        elif isinstance(value, CreepLogic):
            self._proto_name = value.NAME
            self._proto = value
            # 存储到instance的__mates__中
            if isinstance(instance, TeamLogic):
                self._attr_name = f"mate_{self._proto_name}_{self._index}"
                instance.__mates__[self._attr_name] = value
        else:
            if LANGUAGE == "cn":
                std.error("Mate", "参数错误: value必须是str或Creep或CreepLogic类型")
            else:
                std.error("Mate", "Parameter error: 'value' must be of type str or Creep or CreepLogic")

        self._no_spawn_warn_flag = False

    def __respawn__(self, instance, mate_key: str) -> Creep | None:
        """
        如果指定了spawn参数，那么在缺省creepLogic实例时respawn指定的CreepLogic
        *否则不会工作。并且在手动赋值前仅产生一次警告。
        *使用instance的__mates__属性来存储每个实例的logic
        """
        if self._proto is None:
            return None

        logic = instance.__mates__[mate_key]

        # 如果已经有logic且ready，直接返回creep
        if logic and logic.ready:
            return logic.creep

        # 如果已经有logic但不ready，返回None
        if logic:
            return None

        # 搜索已有的CreepLogic
        if instance.SEARCH:
            cl_s = CreepLogic.ref(self._proto_name)
            # print(f"name: {self._name}, cl_s: {cl_s}")
            for cl in cl_s:
                # 检查是否已经被其他TeamLogic占用
                # print(f"cl._team: {cl._team}")
                if not cl._team:
                    cl._team = instance
                    instance.__mates__[mate_key] = cl
                    return cl.creep

        # 自动创建CreepLogic
        if instance.CREATE:
            if not self._spawn:
                if not self._no_spawn_warn_flag:
                    if LANGUAGE == "cn":
                        std.warn(f"Mate<{self._proto_name}>", "未指定spawn，无法自动创建CreepLogic.请手动指定。")
                    else:
                        std.warn(f"Mate<{self._proto_name}>", "Spawn not specified, unable to auto create CreepLogic. Please manual set it.")
                    self._no_spawn_warn_flag = True
                return None
            new_logic = CreepLogic(self._proto_name, self._spawn)
            new_logic._team = instance
            instance.__mates__[mate_key] = new_logic
            return new_logic.creep

        return None

    def __str__(self):
        return f"Mate<{self._attr_name}>"


# > else
class Mate(Creep):  # 仅供在IDE中提示属性使用
    """
    TeamLogic 的伙伴属性描述符，用于自动化管理 CreepLogic 实例。
    在类型提示层面表现为 Creep，运行时自动查找或创建对应的 Creep 实例。
    ** 只能用在 TeamLogic 的类属性定义中 **
    ** 被赋值的变量，类型为Creep | None **
    """

    def __init__(self, creep_logic_name: str = None):
        super().__init__(None)


# > endif

class TeamLogic(Logic):
    # 该类由用户继承定义若干类型为Mate的属性
    NAME = "TeamLogic"
    SEARCH = True  # 是否允许搜索已有的同类型CreepLogic自动填充到Mate属性中
    CREATE = False  # 是否允许自动创建CreepLogic实例填充到Mate属性中

    def __init__(self, inst: any = None, *args):
        super().__init__(inst, *args)

        self.__mates__: dict[str, any] = {}

        # 初始化所有Mate属性
        self._mates_keys = []
        self._mates_attrs = {}
        self._init_mate_properties()
        self._mates_inited = True

        # print(f"mates: {self.__mates__}")

        for k, v in self.__mates__.items():
            self._mates_keys.append(k)  # v is CreepLogic

        self._mates = None
        self._mate_tick = 0

    @property
    def mates(self) -> list[Creep | None]:
        """返回所有Mate属性对应的Creep实例列表"""
        if self._mate_tick != k.now:
            if not self._mates_inited: return []
            self._mate_tick = k.now
            self._mates = []
            for i in range(self._mates_keys.length):
                mate_logic = self.__mates__[self._mates_keys[i]]
                self._mates.append(mate_logic.creep if mate_logic else None)

        return self._mates

    def _init_mate_properties(self):
        """初始化所有Mate属性"""
        _index = 0
        for attr_name in dir(self.__class__):
            attr_value = getattr(self.__class__, attr_name)
            if isinstance(attr_value, Mate):
                # 为每个Mate属性创建对应的实例属性
                if attr_value._index is 0:
                    _index += 1
                    mate_key = f"mate_{attr_value._proto_name}_{_index}"
                    attr_value._index = _index
                    attr_value._attr_name = mate_key
                else:
                    mate_key = attr_value._attr_name

                # print(f"mate_key: {mate_key}")
                self.__mates__[mate_key] = None
                self._mates_attrs[mate_key] = attr_name

    @property
    def ready(self) -> bool:
        """
        检查所有Mate属性是否都已就绪
        :return: 如果所有Mate属性都已就绪则返回True，否则返回False
        """
        if not self.__mates__:  # js中，这表示null or undefined
            return False

        # print(f"logic: {self._mates_keys}")
        for k in self._mates_keys:
            mate = self.__mates__[k]
            if not mate or not mate.ready:
                return False

        return True

    def transform(self, new_type_name: str):
        """
        转换为新的TeamLogic类型
        :param new_type_name: 新的TeamLogic类型名
        """
        self.alive = False
        self._clearTeam()
        TeamLogic(new_type_name)

    def _clearTeam(self):
        # 清理所有CreepLogic的_team引用
        for mate_logic in self.__mates__.values():
            # print(f"mate_logic: {mate_logic}")
            if mate_logic is not None:
                mate_logic._team = None
                if mate_logic.ready or mate_logic.spawning:
                    continue
                mate_logic.alive = False

    def _exit(self) -> None | str | bool:
        res = super()._exit()
        self._clearTeam()
        return res


def case(*sbu) -> str | None:
    """
    多条件跳转函数。
    Multi-condition state transition function.

    Args:
        *sbu: 
            参数0(可选)可以是整数，表示基带时间；未提供时默认为0。
            参数1(可选)可以是str，表示默认跳转状态；未提供时默认为None。
            * 返回参数1需要满足: 
                ①参数1被传入；
                ②没有定义任何tout；
                ③没有满足任何条件；
                ④如果启用了timeout，且全部超时。           
            其余参数按组出现，每组2-4个参数：
            - .to:str - 跳转目标状态字符串。
            - .cond:any[not str] - 判断条件。
            - [.timeout:int] - 超时时间（可选）。
            - [.tout:str] - 超时跳转状态字符串（可选）。

            The first parameter (optional) can be an integer, representing the base time; defaults to 0 if not provided.
            The second parameter (optional) can be a str, representing the default target state string; defaults to None if not provided.
            * To return the second parameter, the following conditions must be met: 
                ① the second parameter is provided; 
                ② no `tout` is defined; 
                ③ no condition is met; 
                ④ if timeout is enabled, all have timed out.
            The remaining parameters appear in groups of 2-4:
            - .to:str - Target state string.
            - .cond:any[not str] - Condition to check.
            - [.timeout:int] - Timeout duration (optional).
            - [.tout:str] - Timeout target state string (optional).

    Returns:
        str | None: 
            满足某条件时返回对应状态字符串，否则返回None。

            Return the `target state string` if the condition is met, otherwise return None.

    Notes:
        如果条件满足，返回`跳转目标状态字符串`。
        启用`超时时间`后，超时后忽略此检查。
        启用`超时跳转状态字符串`后，超时后立刻返回此状态。

        If the condition is met, return the `target state string`.
        If the timeout is enabled, ignore the check if the timeout expires.
        If `tout` is enabled, return the `tout` state immediately after the timeout.
    """
    stime = 0  # 基带时间
    state = 0  # 0
    index = 0  # 索引
    final: str = None  # 默认状态
    to: str = None  # 新的状态
    cond: any = ''  # 判断条件
    timeout: int = None  # 超时时间
    tout: str = None  # 超时跳转状态
    length = len(sbu)
    leninc = length + 1
    count = 0  # 组数记录

    if length and isinstance(sbu[0], int):
        stime = sbu[0]
        index += 1

    if (index + 1) < length and isinstance(sbu[index], str) and isinstance(sbu[index + 1], str):
        final = sbu[index]
        index += 1

    waits = 0  # 如果还有timeout定义了，但是未触发。那么等待，默认0
    while index < leninc:
        if index is length:
            it = None
            state = 4
        else:
            it = sbu[index]

        if state is 0:
            if isinstance(it, str):
                to = it
                state = 1
            else:
                if LANGUAGE is 'cn':
                    std.error("case", f"[索引{index}] 第{count}组.to(参数0)错误，期望字符串类型，实际{type(it)}")
                else:
                    std.error("case", f"[index {index}] Group {count} .to (param 0) error, expect str type, actual {type(it)}")
        elif state is 1:
            if not isinstance(it, str):
                cond = it
                state = 2
            else:
                if LANGUAGE is 'cn':
                    std.error("case", f"[索引{index}] 第{count}组.cond(参数1)错误，期望非字符串类型，实际{type(it)} [{to}, ...]")
                else:
                    std.error("case", f"[index {index}] Group {count} .cond (param 1) error, expect non-str type, actual {type(it)} [{to}, ...]")
        elif state is 2:
            if isinstance(it, str):
                state = 4
                index -= 1  # 回退
            elif isinstance(it, int):
                timeout = it
                state = 3
            else:
                if LANGUAGE is 'cn':
                    std.error("case", f"[索引{index}] 第{count}组.timeout(参数3)错误，期望整数类型，实际{type(it)} [{to}, {bool(cond)}, ...]")
                else:
                    std.error("case", f"[index {index}] Group {count} .timeout (param 3) error, expect int type, actual {type(it)} [{to}, {bool(cond)}, ...]")
        elif state is 3:
            state = 4
            if index is (length - 1) or isinstance(sbu[index + 1], str):
                if isinstance(it, str):
                    tout = it
                elif LANGUAGE is 'cn':
                    std.error("case", f"[索引{index}] 第{count}组.tout(参数4)错误，期望字符串类型，实际{type(it)} [{to}, {bool(cond)}, {timeout}], ...")
                else:
                    std.error("case", f"[index {index}] Group {count} .tout (param 4) error, expect str type, actual {type(it)} [{to}, {bool(cond)}, {timeout}], ...")
            else:
                index -= 1  # 回退

        if state is 4:  # exec
            if cond is '':
                if LANGUAGE is 'cn':
                    std.warn("case", f"[索引{index}] 第{count}组缺少cond(参数1) [{to}, ...]")
                else:
                    std.warn("case", f"[index {index}] Group {count} missing cond (param 1) [{to}, ...]")
            # print(f"case {count} [{to}, {cond}, {timeout}, {tout}]")
            if timeout is not None:
                waits += 1
                if know.now > (stime + timeout):
                    if tout is not None: return tout
                    waits -= 1
            if bool(cond):
                return to
            state = 0
            count += 1
            to = None
            cond = ''
            timeout = None
            tout = None

        index += 1

    return None if waits > 0 else final
