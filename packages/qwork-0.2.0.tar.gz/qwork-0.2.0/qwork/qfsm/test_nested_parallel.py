"""Test nested behavior tree in parallel"""
from qwork.qfsm import Stage
from qwork.qfsm.decorators import sequence, parallel

# Use lowercase method names as states (Stage auto-discovers them)


class DemoLogic(Stage):
    NAME = "DemoLogic"
    LOG = True

    def __init__(self):
        super().__init__()
        self.call_order = []

    def entry(self, inst):
        self.call_order.append("entry")
        return "root"

    @parallel("a", "b")
    def root(self, inst):
        self.call_order.append("root")
        return True

    def a(self, inst):
        self.call_order.append("a")
        return False  # FAIL

    @sequence("c", "d")
    def b(self, inst):
        self.call_order.append("b")
        return True

    def c(self, inst):
        self.call_order.append("c")
        return True

    def d(self, inst):
        self.call_order.append("d")
        return True

    def c(self, inst):
        self.call_order.append("c")
        return True

    def d(self, inst):
        self.call_order.append("d")
        return True


def test_nested_parallel():
    print("\n" + "="*60)
    print("TEST: Nested sequence in parallel")
    print("="*60)

    stage = DemoLogic()

    # Tick 1: entry -> root
    print("\n--- Tick 1 ---")
    stage.handleStage(log=True)

    # Tick 2: parallel execution
    print("\n--- Tick 2 ---")
    stage.handleStage(log=True)

    # Tick 3: continue parallel
    print("\n--- Tick 3 ---")
    stage.handleStage(log=True)

    print(f"\nCall order: {stage.call_order}")
    print(f"Current state: {stage.current_state}")

    # Verify c and d were both called
    assert "c" in stage.call_order, "c should be called"
    assert "d" in stage.call_order, "d should be called"
    print("PASS: Both c and d were called")


if __name__ == "__main__":
    test_nested_parallel()
