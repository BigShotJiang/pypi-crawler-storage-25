"""Test behavior tree events - verify CHANGED events are triggered for child nodes"""

import random
import sys
import time
sys.path.insert(0, 'F:\\Python\\Python314\\Lib\\site-packages')

from qwork.qfsm import Stage
from qwork.qfsm.decorators import parallel, sequence, selector


class TestStage(Stage):
    """Test stage with behavior tree - captures events synchronously"""
    NAME = "TestStage"
    LOG = True  # Enable to see state transitions in console

    def __init__(self):
        super().__init__()
        self.events = []

    def onChanged(self, src, dst, inst):
        """Synchronously capture state changes"""
        super().onChanged(src, dst, inst)
        self.events.append(("CHANGED", f"{src} -> {dst}"))

    def entry(self, inst):
        return "root"

    @parallel("a", "b")
    def root(self, inst):
        return True

    def a(self, inst):
        return True

    @sequence("c", "d")
    def b(self, inst):
        return True

    def c(self, inst):
        return True

    def d(self, inst):
        return True


def test_parallel_behavior():
    """Test parallel behavior tree triggers CHANGED for children"""
    print("="*60)
    print("TEST: Parallel behavior - CHANGED events for children")
    print("="*60)

    stage = TestStage()
    stage.events.clear()  # Clear init events

    print("\n--- Tick 1: entry -> root ---")
    stage.handleStage(log=True)
    print(f"Current state: {stage.current}")
    print(f"Events: {stage.events}")

    print("\n--- Tick 2: root parallel execution ---")
    stage.events.clear()
    stage.handleStage(log=True)
    print(f"Current state: {stage.current}")
    print(f"Events: {stage.events}")

    # Check for child transitions
    changed_events = [e for e in stage.events if e[0] == "CHANGED"]
    child_transitions = [e for e in changed_events if "->" in e[1]]

    print(f"\nChild transitions captured: {len(child_transitions)}")
    for t in child_transitions:
        print(f"  {t[1]}")

    # We expect to see transitions like:
    # - root -> a
    # - a -> b (or similar, depending on execution order)
    success = len(child_transitions) > 0

    # Check specific transitions
    has_root_to_child = any("root ->" in e[1] for e in child_transitions)

    if has_root_to_child:
        print("PASS: Found CHANGED event from root to child")
    else:
        print("FAIL: No CHANGED event from root to child")

    return success and has_root_to_child


def test_sequence_behavior():
    """Test sequence behavior tree"""
    print("\n" + "="*60)
    print("TEST: Sequence behavior - step by step execution")
    print("="*60)

    class SeqStage(Stage):
        NAME = "SeqStage"
        LOG = True

        def __init__(self):
            super().__init__()
            self.events = []

        def onChanged(self, src, dst, inst):
            self.events.append(("CHANGED", f"{src} -> {dst}"))

        def entry(self, inst):
            return "seq"

        @sequence("s1", "s2", "s3")
        def seq(self, inst):
            return True

        def s1(self, inst):
            return True

        def s2(self, inst):
            return True

        def s3(self, inst):
            return True

    stage = SeqStage()
    stage.events.clear()

    print("\n--- Tick 1: entry -> seq ---")
    stage.handleStage(log=True)
    print(f"Events: {stage.events}")

    all_events = []
    all_events.extend(stage.events)

    print("\n--- Tick 2: seq starts ---")
    stage.events.clear()
    stage.handleStage(log=True)
    print(f"Events: {stage.events}")
    all_events.extend(stage.events)

    # Sequence pauses after each child, so run more ticks
    for i in range(5):
        print(f"\n--- Tick {i+3} ---")
        stage.events.clear()
        stage.handleStage(log=True)
        if stage.events:
            print(f"Events: {stage.events}")
        all_events.extend(stage.events)
        if not stage.events:
            break

    print(f"\n=== All CHANGED events ===")
    changed = [e for e in all_events if e[0] == "CHANGED"]
    for c in changed:
        print(f"  {c[1]}")

    # Check for child transitions in sequence
    child_changes = [e for e in changed if "seq" in e[1] or "s1" in e[1] or "s2" in e[1] or "s3" in e[1]]

    # We expect at least: entry -> seq, and some transitions involving s1, s2, s3
    success = len(child_changes) >= 2

    if success:
        print(f"PASS: Found {len(child_changes)} relevant CHANGED events")
    else:
        print(f"FAIL: Only found {len(child_changes)} relevant CHANGED events")

    return success


def test_selector_behavior():
    """Test selector behavior tree"""
    print("\n" + "="*60)
    print("TEST: Selector behavior - first success stops")
    print("="*60)

    class SelStage(Stage):
        NAME = "SelStage"
        LOG = True

        def __init__(self):
            super().__init__()
            self.events = []

        def onChanged(self, src, dst, inst):
            self.events.append(("CHANGED", f"{src} -> {dst}"))

        def entry(self, inst):
            return "sel"

        @selector("f1", "f2", "f3")
        def sel(self, inst):
            return True

        def f1(self, inst):
            return False  # Fail, try next

        def f2(self, inst):
            return True  # Success, stop

        def f3(self, inst):
            return True  # Won't execute

    stage = SelStage()
    stage.events.clear()

    print("\n--- Tick 1: entry -> sel ---")
    stage.handleStage(log=True)

    all_events = list(stage.events)

    print("\n--- Tick 2: selector execution ---")
    stage.events.clear()
    stage.handleStage(log=True)
    all_events.extend(stage.events)

    # Run more ticks
    for i in range(3):
        print(f"\n--- Tick {i+3} ---")
        stage.events.clear()
        stage.handleStage(log=True)
        if stage.events:
            print(f"Events: {stage.events}")
        all_events.extend(stage.events)

    print(f"\n=== All CHANGED events ===")
    changed = [e for e in all_events if e[0] == "CHANGED"]
    for c in changed:
        print(f"  {c[1]}")

    # Selector should have transitioned to f1, then to f2 (when f1 fails)
    has_child_transition = any("sel" in e[1] or "f1" in e[1] or "f2" in e[1] for e in changed)

    if has_child_transition:
        print("PASS: Selector has child transitions")
        return True
    else:
        print("FAIL: No child transitions in selector")
        return False


if __name__ == "__main__":
    results = []

    results.append(("Parallel", test_parallel_behavior()))
    results.append(("Sequence", test_sequence_behavior()))
    results.append(("Selector", test_selector_behavior()))

    print("\n" + "="*60)
    print("FINAL RESULTS")
    print("="*60)
    all_pass = True
    for name, passed in results:
        status = "PASS" if passed else "FAIL"
        print(f"  {name}: {status}")
        if not passed:
            all_pass = False

    if all_pass:
        print("\nALL TESTS PASSED!")
        sys.exit(0)
    else:
        print("\nSOME TESTS FAILED")
        sys.exit(1)
