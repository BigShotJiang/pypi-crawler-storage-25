# © Copyright 2025-2026, Query.Farm LLC - https://query.farm
# SPDX-License-Identifier: Apache-2.0

"""HTTP client implementation using httpx.

Provides ``http_connect`` context manager, ``HttpStreamSession``,
``http_introspect``, ``http_capabilities``, and ``request_upload_urls``.
"""

from __future__ import annotations

import contextlib
import json
import logging
import re
from collections.abc import Callable, Iterator, Mapping
from dataclasses import dataclass
from http import HTTPStatus
from io import BytesIO
from types import MappingProxyType, TracebackType
from typing import TYPE_CHECKING, Any, cast

import httpx
import pyarrow as pa
from pyarrow import ipc

from vgi_rpc.external import (
    ExternalLocationConfig,
    UploadUrl,
    make_external_location_batch,
    resolve_external_location,
)
from vgi_rpc.log import Message
from vgi_rpc.metadata import (
    CANCEL_KEY,
    STATE_KEY,
    merge_metadata,
    strip_keys,
)
from vgi_rpc.rpc import (
    _EMPTY_SCHEMA,
    AnnotatedBatch,
    MethodType,
    RpcError,
    RpcMethodInfo,
    _dispatch_log_or_error,
    _drain_stream,
    _read_batch_with_log_check,
    _read_unary_response,
    _send_request,
    _write_request,
    rpc_methods,
)
from vgi_rpc.rpc._debug import fmt_batch, wire_http_logger
from vgi_rpc.rpc._wire import _read_stream_header
from vgi_rpc.utils import ArrowSerializableDataclass, IpcValidation, ValidatedReader, empty_batch

from ._common import (
    _ARROW_CONTENT_TYPE,
    _SESSION_ENDPOINT,
    _UPLOAD_URL_METHOD,
    _UPLOAD_URL_PARAMS_SCHEMA,
    ECHO_HEADER_PREFIX,
    EXTERNALIZATION_ENABLED_HEADER,
    MAX_EXTERNALIZED_RESPONSE_BYTES_HEADER,
    MAX_REQUEST_BYTES_HEADER,
    MAX_RESPONSE_BYTES_HEADER,
    MAX_UPLOAD_BYTES_HEADER,
    SESSION_ACCEPT_HEADER,
    SESSION_CLOSE_HEADER,
    SESSION_HEADER,
    STICKY_DEFAULT_TTL_HEADER,
    STICKY_ECHO_HEADERS_HEADER,
    STICKY_ENABLED_HEADER,
    SUPPORTED_ENCODINGS_HEADER,
    UPLOAD_URL_HEADER,
    Encoding,
    available_encodings,
    parse_encoding_list,
)
from ._common import (
    compress as _compress_with_encoding,
)
from ._retry import HttpRetryConfig, _options_with_retry, _post_with_retry

if TYPE_CHECKING:
    from vgi_rpc.introspect import ServiceDescription

    from ._testing import _SyncTestClient, _SyncTestResponse


def _client_offered_encodings() -> tuple[Encoding, ...]:
    """Return encodings the client can both produce *and* decode.

    httpx auto-decompresses gzip and deflate; for zstd it transparently
    decompresses if ``zstandard`` is importable.  We therefore advertise
    whatever ``available_encodings()`` reports — runtime presence of the
    libraries is the same gate on both ends.
    """
    return available_encodings()


def _choose_request_encoding(caps: HttpServerCapabilities | None) -> Encoding:
    """Pick the codec for outgoing request bodies.

    Honours the client's own preference order (zstd before gzip when
    both are available) intersected with the server's advertised set
    on ``HttpServerCapabilities.supported_encodings``.  Defaults to
    zstd when caps are not yet discovered — every existing server can
    decode zstd, so this is the safe back-compat choice.
    """
    client_set = _client_offered_encodings()
    if not client_set:
        # No codec we can produce; caller should fall back to identity.
        return Encoding.ZSTD  # placeholder; caller checks compression_level
    server_set: tuple[Encoding, ...] = caps.supported_encodings if caps is not None else (Encoding.ZSTD,)
    for enc in client_set:
        if enc in server_set:
            return enc
    # No overlap.  Send zstd and let the server respond 415 — the
    # caller is expected to surface that as a clear "server doesn't
    # speak any of our codecs" error.
    return client_set[0]


def _prepare_request_body(
    content: bytes,
    *,
    encoding: Encoding | None,
    compression_level: int | None,
) -> bytes:
    """Compress *content* with the resolved codec (or return as-is)."""
    if encoding is None:
        return content
    # zstd honours the user-configured level; gzip uses its codec default.
    level = compression_level if encoding is Encoding.ZSTD else None
    return _compress_with_encoding(encoding, content, level=level)


def _externalize_via_upload_url(
    body: bytes,
    *,
    client: httpx.Client | _SyncTestClient,
    url_prefix: str,
    url_validator: Callable[[str], None] | None,
    retry_config: HttpRetryConfig | None,
    capabilities: HttpServerCapabilities,
) -> bytes:
    """Upload *body* to a server-vended URL and return a pointer-batch body.

    Caller must have already verified ``capabilities.upload_url_support``;
    this helper does no capability check.  Used from both the unary/init
    path on ``_HttpProxy`` and the exchange path on ``HttpStreamSession``.
    """
    if not capabilities.upload_url_support:
        raise RpcError(
            "RequestTooLarge",
            "Request exceeds max_request_bytes and the server does not advertise upload_url_support",
            "",
        )
    if not isinstance(client, httpx.Client):
        raise RpcError(
            "ExternalUploadFailed",
            "Auto-externalization requires an httpx.Client (the in-process test shim doesn't support PUT)",
            "",
        )
    urls = request_upload_urls(client=client, prefix=url_prefix, count=1, retry=retry_config)
    if not urls:
        raise RpcError("ProtocolError", "Server returned no upload URLs", "")
    upload_url = urls[0].upload_url
    download_url = urls[0].download_url
    if url_validator is not None:
        url_validator(upload_url)
        url_validator(download_url)
    put_resp = client.put(upload_url, content=body, headers={"Content-Type": _ARROW_CONTENT_TYPE})
    if not (200 <= put_resp.status_code < 300):
        raise RpcError(
            "ExternalUploadFailed",
            f"PUT to upload URL failed: HTTP {put_resp.status_code}",
            "",
        )
    return _build_pointer_request_body(body, download_url)


def _build_pointer_request_body(original_body: bytes, location_url: str) -> bytes:
    """Convert an inline IPC request body into an externalized pointer body.

    Reads the original request batch (assumed to be a single IPC stream
    with one batch carrying ``vgi_rpc.method`` / ``vgi_rpc.request_version``
    in custom_metadata), then writes a new IPC stream containing a
    zero-row pointer batch with the same schema and merged metadata
    (original dispatch keys + ``vgi_rpc.location``).

    The receiving server's ``_read_request`` honours the outer batch's
    dispatch metadata for routing, then resolves the pointer to fetch
    the inner batch for parameter extraction.
    """
    reader = ipc.open_stream(BytesIO(original_body))
    batch, custom_metadata = reader.read_next_batch_with_custom_metadata()
    pointer_batch, loc_md = make_external_location_batch(batch.schema, location_url)
    merged = merge_metadata(custom_metadata, loc_md)
    buf = BytesIO()
    with ipc.new_stream(buf, batch.schema) as writer:
        writer.write_batch(pointer_batch, custom_metadata=merged)
    return buf.getvalue()


def _open_response_stream(
    content: bytes,
    status_code: int,
    ipc_validation: IpcValidation = IpcValidation.FULL,
) -> ValidatedReader:
    """Open an Arrow IPC stream from HTTP response bytes.

    Args:
        content: Response body bytes.
        status_code: HTTP status code (used in error messages).
        ipc_validation: Validation level for batches read from the stream.

    Returns:
        A ``ValidatedReader`` wrapping the IPC stream.

    Raises:
        RpcError: If the server returns 401 (``AuthenticationError``) or
            the response is not a valid Arrow IPC stream.

    """
    if wire_http_logger.isEnabledFor(logging.DEBUG):
        wire_http_logger.debug(
            "Open response stream: status=%d, body_size=%d",
            status_code,
            len(content),
        )
    # 401 responses are plain text (not Arrow IPC) because they are produced
    # by _AuthMiddleware before any method is resolved, so no output schema
    # is available.  We surface them as RpcError("AuthenticationError").
    if status_code == HTTPStatus.UNAUTHORIZED:
        raise RpcError("AuthenticationError", content.decode(errors="replace"), "")
    try:
        return ValidatedReader(ipc.open_stream(BytesIO(content)), ipc_validation)
    except pa.ArrowInvalid:
        body_preview = content[:200].decode(errors="replace") if content else ""
        raise RpcError(
            "HttpError",
            f"HTTP {status_code}: response is not a valid Arrow IPC stream (first 200 bytes: {body_preview!r})",
            "",
        ) from None


# ---------------------------------------------------------------------------
# Client — http_connect + HttpStreamSession
# ---------------------------------------------------------------------------


class HttpStreamSession:
    """Client-side handle for a stream over HTTP (both producer and exchange patterns).

    For producer streams, use ``__iter__()`` — yields batches from batched
    responses and follows continuation tokens transparently.
    For exchange streams, use ``exchange()`` — sends an input batch and
    receives an output batch.

    Supports context manager protocol for convenience.
    """

    __slots__ = (
        "_capabilities",
        "_client",
        "_compression_level",
        "_external_config",
        "_finished",
        "_header",
        "_ipc_validation",
        "_method",
        "_on_log",
        "_output_schema",
        "_pending_batches",
        "_retry_config",
        "_state_bytes",
        "_url_prefix",
    )

    def __init__(
        self,
        client: httpx.Client | _SyncTestClient,
        url_prefix: str,
        method: str,
        state_bytes: bytes | None,
        output_schema: pa.Schema,
        on_log: Callable[[Message], None] | None = None,
        *,
        external_config: ExternalLocationConfig | None = None,
        ipc_validation: IpcValidation = IpcValidation.FULL,
        pending_batches: list[AnnotatedBatch] | None = None,
        finished: bool = False,
        header: object | None = None,
        retry_config: HttpRetryConfig | None = None,
        compression_level: int | None = None,
    ) -> None:
        """Initialize with HTTP client, method details, and initial state."""
        self._client = client
        self._url_prefix = url_prefix
        self._method = method
        self._state_bytes = state_bytes
        self._output_schema = output_schema
        self._on_log = on_log
        self._external_config = external_config
        self._ipc_validation = ipc_validation
        self._pending_batches: list[AnnotatedBatch] = pending_batches or []
        self._finished = finished
        self._header = header
        self._retry_config = retry_config
        self._compression_level = compression_level
        self._capabilities: HttpServerCapabilities | None = None

    def _maybe_externalize_request(self, body: bytes) -> bytes:
        """Pre-emptively externalize *body* if cached caps say it's too large.

        Mirrors ``_HttpProxy._maybe_externalize_request``: never probes
        OPTIONS speculatively; the 413 fallback warms caps for future
        pre-emption.
        """
        caps = self._capabilities
        if caps is None:
            return body
        if caps.max_request_bytes is None or not caps.upload_url_support or len(body) <= caps.max_request_bytes:
            return body
        return self._externalize_request_body(body)

    def _externalize_request_body(self, body: bytes) -> bytes:
        """Externalize *body* via server-vended URL; warm the caps cache."""
        if self._capabilities is None:
            self._capabilities = http_capabilities(
                client=self._client, prefix=self._url_prefix, retry=self._retry_config
            )
        validator = self._external_config.url_validator if self._external_config is not None else None
        return _externalize_via_upload_url(
            body,
            client=self._client,
            url_prefix=self._url_prefix,
            url_validator=validator,
            retry_config=self._retry_config,
            capabilities=self._capabilities,
        )

    @property
    def header(self) -> object | None:
        """The stream header, or ``None`` if the stream has no header."""
        return self._header

    def typed_header[H: ArrowSerializableDataclass](self, header_type: type[H]) -> H:
        """Return the stream header narrowed to the expected type.

        Args:
            header_type: The expected header dataclass type.

        Returns:
            The header, typed as *header_type*.

        Raises:
            TypeError: If the header is ``None`` or not an instance of
                *header_type*.

        """
        if self._header is None:
            raise TypeError(f"Stream has no header (expected {header_type.__name__})")
        if not isinstance(self._header, header_type):
            raise TypeError(f"Header type mismatch: expected {header_type.__name__}, got {type(self._header).__name__}")
        return self._header

    def _resolve_request_encoding(self) -> Encoding | None:
        """Choose a codec for the request body based on cached caps.

        Stable across both ``_build_headers`` and ``_prepare_body`` so
        the two stay in lockstep regardless of which gets called first
        (Python evaluates ``kwargs`` left-to-right, so ``prepare_body``
        may run before ``build_headers`` in some call sites).
        """
        if self._compression_level is None:
            return None
        client_set = _client_offered_encodings()
        if not client_set:
            return None
        return _choose_request_encoding(self._capabilities)

    def _build_headers(self) -> dict[str, str]:
        """Build HTTP headers, advertising codecs and selecting one for the body when compression is enabled."""
        encoding = self._resolve_request_encoding()
        headers: dict[str, str] = {"Content-Type": _ARROW_CONTENT_TYPE}
        if encoding is not None:
            headers["Content-Encoding"] = encoding.value
            headers["Accept-Encoding"] = ", ".join(e.value for e in _client_offered_encodings())
        return headers

    def _prepare_body(self, content: bytes) -> bytes:
        """Compress *content* with the codec resolved from cached caps."""
        encoding = self._resolve_request_encoding()
        return _prepare_request_body(
            content,
            encoding=encoding,
            compression_level=self._compression_level,
        )

    def exchange(self, input_batch: AnnotatedBatch) -> AnnotatedBatch:
        """Send an input batch and receive the output batch.

        Args:
            input_batch: The input batch to send.

        Returns:
            The output batch from the server.

        Raises:
            RpcError: If the server reports an error or the stream has finished.

        """
        if self._state_bytes is None:
            raise RpcError("ProtocolError", "Stream has finished — no state token available", "")

        batch_to_write = input_batch.batch
        cm_to_write = input_batch.custom_metadata

        # Build the inline body first; auto-externalization (if needed)
        # then operates on the serialized bytes via the server-vended
        # upload-URL flow.  The state token is on the outer batch, so
        # _build_pointer_request_body preserves it on the pointer.
        req_buf = BytesIO()
        state_md = pa.KeyValueMetadata({STATE_KEY: self._state_bytes})
        merged = merge_metadata(cm_to_write, state_md)
        with ipc.new_stream(req_buf, batch_to_write.schema) as writer:
            writer.write_batch(batch_to_write, custom_metadata=merged)
        body = self._maybe_externalize_request(req_buf.getvalue())

        if wire_http_logger.isEnabledFor(logging.DEBUG):
            wire_http_logger.debug(
                "HTTP stream exchange: method=%s, input=%s",
                self._method,
                fmt_batch(batch_to_write),
            )
        # Exchange calls are NOT retried: the server's process() method may
        # have side effects, and a proxy 502 after server processing would
        # cause duplicate execution.  Only init/unary/continuation are retried.
        resp = self._client.post(
            f"{self._url_prefix}/{self._method}/exchange",
            content=self._prepare_body(body),
            headers=self._build_headers(),
        )
        if resp.status_code == HTTPStatus.REQUEST_ENTITY_TOO_LARGE:
            body = self._externalize_request_body(body)
            resp = self._client.post(
                f"{self._url_prefix}/{self._method}/exchange",
                content=self._prepare_body(body),
                headers=self._build_headers(),
            )
        if wire_http_logger.isEnabledFor(logging.DEBUG):
            wire_http_logger.debug(
                "HTTP stream exchange response: method=%s, status=%d, size=%d",
                self._method,
                resp.status_code,
                len(resp.content),
            )

        # Read response — log batches + data batch with state
        reader = _open_response_stream(resp.content, resp.status_code, self._ipc_validation)
        try:
            ab = _read_batch_with_log_check(reader, self._on_log, self._external_config)
        except RpcError:
            _drain_stream(reader)
            raise

        # Extract updated state from metadata
        if ab.custom_metadata is not None:
            new_state = ab.custom_metadata.get(STATE_KEY)
            if new_state is not None:
                self._state_bytes = new_state

        # Strip state token from user-visible metadata
        user_cm = strip_keys(ab.custom_metadata, STATE_KEY)

        _drain_stream(reader)
        return AnnotatedBatch(batch=ab.batch, custom_metadata=user_cm)

    def _send_continuation(self, token: bytes) -> ValidatedReader:
        """Send a continuation request and return the new response reader."""
        req_buf = BytesIO()
        state_md = pa.KeyValueMetadata({STATE_KEY: token})
        with ipc.new_stream(req_buf, _EMPTY_SCHEMA) as writer:
            writer.write_batch(empty_batch(_EMPTY_SCHEMA), custom_metadata=state_md)

        resp = _post_with_retry(
            self._client,
            f"{self._url_prefix}/{self._method}/exchange",
            content=self._prepare_body(req_buf.getvalue()),
            headers=self._build_headers(),
            config=self._retry_config,
        )
        return _open_response_stream(resp.content, resp.status_code, self._ipc_validation)

    def __iter__(self) -> Iterator[AnnotatedBatch]:
        """Iterate over output batches from a producer stream.

        Yields pre-loaded batches from init, then follows continuation tokens.
        """
        # Yield pre-loaded batches from init response
        yield from self._pending_batches
        self._pending_batches.clear()

        if self._finished:
            return

        # Follow continuation tokens
        if self._state_bytes is None:
            return

        reader: ValidatedReader | None = None
        try:
            reader = self._send_continuation(self._state_bytes)
            while True:
                try:
                    batch, custom_metadata = reader.read_next_batch_with_custom_metadata()
                except StopIteration:
                    break

                # Check for continuation token (zero-row batch with STATE_KEY)
                if batch.num_rows == 0 and custom_metadata is not None:
                    token = custom_metadata.get(STATE_KEY)
                    if token is not None:
                        if not isinstance(token, bytes):
                            raise TypeError(f"Expected bytes for state token, got {type(token).__name__}")
                        _drain_stream(reader)
                        reader = self._send_continuation(token)
                        continue

                # Dispatch log/error batches
                if _dispatch_log_or_error(batch, custom_metadata, self._on_log):
                    continue

                resolved_batch, resolved_cm = resolve_external_location(
                    batch, custom_metadata, self._external_config, self._on_log, reader.ipc_validation
                )
                yield AnnotatedBatch(batch=resolved_batch, custom_metadata=resolved_cm)
        except RpcError:
            if reader is not None:
                _drain_stream(reader)
            raise

    def close(self) -> None:
        """Close the session (no-op for HTTP — stateless)."""

    def cancel(self) -> None:
        """Signal the server to discard stream state and stop processing.

        Sends a ``POST {prefix}/{method}/exchange`` carrying ``vgi_rpc.cancel``
        metadata alongside the current state token. The server invokes
        ``state.on_cancel(ctx)`` (if defined) and releases the state.

        Idempotent and best-effort: network failures are swallowed. After
        ``cancel()``, the session is marked finished; further ``exchange()``
        or iteration raises ``RpcError``.
        """
        if self._finished or self._state_bytes is None:
            self._finished = True
            self._state_bytes = None
            return
        token = self._state_bytes
        self._finished = True
        self._state_bytes = None
        if wire_http_logger.isEnabledFor(logging.DEBUG):
            wire_http_logger.debug("HTTP stream cancel: method=%s", self._method)
        req_buf = BytesIO()
        cancel_md = pa.KeyValueMetadata({STATE_KEY: token, CANCEL_KEY: b"1"})
        with ipc.new_stream(req_buf, _EMPTY_SCHEMA) as writer:
            writer.write_batch(empty_batch(_EMPTY_SCHEMA), custom_metadata=cancel_md)
        try:
            resp = self._client.post(
                f"{self._url_prefix}/{self._method}/exchange",
                content=self._prepare_body(req_buf.getvalue()),
                headers=self._build_headers(),
            )
        except Exception:
            return
        with contextlib.suppress(Exception):
            reader = _open_response_stream(resp.content, resp.status_code, self._ipc_validation)
            _drain_stream(reader)

    def __enter__(self) -> HttpStreamSession:
        """Enter the context."""
        return self

    def __exit__(
        self,
        _exc_type: type[BaseException] | None,
        _exc_val: BaseException | None,
        _exc_tb: TracebackType | None,
    ) -> None:
        """Exit the context."""
        self.close()


@contextlib.contextmanager
def http_connect[P](
    protocol: type[P],
    base_url: str | None = None,
    *,
    prefix: str | None = None,
    on_log: Callable[[Message], None] | None = None,
    client: httpx.Client | _SyncTestClient | None = None,
    external_location: ExternalLocationConfig | None = None,
    ipc_validation: IpcValidation = IpcValidation.FULL,
    retry: HttpRetryConfig | None = None,
    compression_level: int | None = 3,
) -> Iterator[P]:
    """Connect to an HTTP RPC server and yield a typed proxy.

    Args:
        protocol: The Protocol class defining the RPC interface.
        base_url: Base URL of the server (e.g. ``http://localhost:8000``).
            Required when *client* is ``None``; ignored when a pre-built
            *client* is provided.  The internally-created client follows
            redirects transparently.
        prefix: URL prefix matching the server's prefix.  When ``None``
            (the default), auto-detected from a ``_SyncTestClient``'s
            ``.prefix`` attribute, or ``""`` for other clients.
        on_log: Optional callback for log messages from the server.
        client: Optional HTTP client — ``httpx.Client`` for production,
            or a ``_SyncTestClient`` from ``make_sync_client()`` for testing.
        external_location: Optional ExternalLocationConfig for
            resolving and producing externalized batches.
        ipc_validation: Validation level for incoming IPC batches.
        retry: Optional retry configuration for transient HTTP failures.
            When ``None`` (the default), no retries are attempted.
        compression_level: Zstandard compression level for request bodies.
            ``3`` (the default) compresses requests and adds
            ``Content-Encoding: zstd``.  ``None`` disables request
            compression (httpx still auto-decompresses server responses).

    Yields:
        A typed RPC proxy supporting all methods defined on *protocol*.

    Raises:
        ValueError: If *base_url* is ``None`` and *client* is ``None``.

    """
    own_client = client is None
    if client is None:
        if base_url is None:
            raise ValueError("base_url is required when client is not provided")
        client = httpx.Client(base_url=base_url, follow_redirects=True)

    # Auto-detect prefix from _SyncTestClient when not explicitly provided
    url_prefix = getattr(client, "prefix", "") if prefix is None else prefix
    try:
        yield cast(
            P,
            _HttpProxy(
                protocol,
                client,
                url_prefix,
                on_log,
                external_config=external_location,
                ipc_validation=ipc_validation,
                retry_config=retry,
                compression_level=compression_level,
            ),
        )
    finally:
        if own_client:
            client.close()


def http_introspect(
    base_url: str | None = None,
    *,
    prefix: str | None = None,
    client: httpx.Client | _SyncTestClient | None = None,
    ipc_validation: IpcValidation = IpcValidation.FULL,
    retry: HttpRetryConfig | None = None,
) -> ServiceDescription:
    """Send a ``__describe__`` request over HTTP and return a ``ServiceDescription``.

    Args:
        base_url: Base URL of the server (e.g. ``http://localhost:8000``).
            Required when *client* is ``None``.
        prefix: URL prefix matching the server's prefix.  ``None``
            auto-detects from ``_SyncTestClient``.
        client: Optional HTTP client (``httpx.Client`` or ``_SyncTestClient``).
        ipc_validation: Validation level for incoming IPC batches.
        retry: Optional retry configuration for transient HTTP failures.

    Returns:
        A ``ServiceDescription`` with all method metadata.

    Raises:
        RpcError: If the server does not support introspection or returns
            an error.
        ValueError: If *base_url* is ``None`` and *client* is ``None``.

    """
    from vgi_rpc.introspect import DESCRIBE_METHOD_NAME, parse_describe_batch

    own_client = client is None
    if client is None:
        if base_url is None:
            raise ValueError("base_url is required when client is not provided")
        client = httpx.Client(base_url=base_url, follow_redirects=True)
    if prefix is None:
        prefix = getattr(client, "prefix", "")

    try:
        # Build a minimal request: empty params with __describe__ method name
        req_buf = BytesIO()
        request_metadata = pa.KeyValueMetadata(
            {
                b"vgi_rpc.method": DESCRIBE_METHOD_NAME.encode(),
                b"vgi_rpc.request_version": b"1",
            }
        )
        with ipc.new_stream(req_buf, _EMPTY_SCHEMA) as writer:
            writer.write_batch(
                pa.RecordBatch.from_pydict({}, schema=_EMPTY_SCHEMA),
                custom_metadata=request_metadata,
            )

        resp = _post_with_retry(
            client,
            f"{prefix}/{DESCRIBE_METHOD_NAME}",
            content=req_buf.getvalue(),
            headers={"Content-Type": _ARROW_CONTENT_TYPE},
            config=retry,
        )

        reader = _open_response_stream(resp.content, resp.status_code, ipc_validation)
        # Skip log batches
        while True:
            batch, custom_metadata = reader.read_next_batch_with_custom_metadata()
            if not _dispatch_log_or_error(batch, custom_metadata):
                break
        _drain_stream(reader)

        return parse_describe_batch(batch, custom_metadata)
    finally:
        if own_client:
            client.close()


def _init_http_stream_session(
    client: httpx.Client | _SyncTestClient,
    url_prefix: str,
    method_name: str,
    reader: ValidatedReader,
    on_log: Callable[[Message], None] | None = None,
    *,
    external_config: ExternalLocationConfig | None = None,
    ipc_validation: IpcValidation = IpcValidation.FULL,
    header: object | None = None,
    retry_config: HttpRetryConfig | None = None,
    compression_level: int | None = None,
) -> HttpStreamSession:
    """Parse an init response and return an ``HttpStreamSession``.

    Reads the IPC stream from the init response, collecting state tokens,
    pending data batches, and log/error batches.  This is shared between
    ``_HttpProxy._make_stream_caller`` and the CLI.

    Args:
        client: HTTP client for subsequent exchange requests.
        url_prefix: URL path prefix (e.g. ``/vgi``).
        method_name: RPC method name.
        reader: ``ValidatedReader`` opened from the init response.
        on_log: Optional log callback.
        external_config: Optional external location config.
        ipc_validation: Validation level for IPC batches.
        header: Optional pre-read stream header.
        retry_config: Optional retry configuration for transient failures.
        compression_level: Zstandard compression level for exchange requests.

    Returns:
        A configured ``HttpStreamSession`` ready for iteration or exchange.

    Raises:
        RpcError: If the server reports an error in the init response.

    """
    output_schema = reader.schema
    state_bytes: bytes | None = None
    pending_batches: list[AnnotatedBatch] = []
    finished = False

    try:
        while True:
            try:
                batch, custom_metadata = reader.read_next_batch_with_custom_metadata()
            except StopIteration:
                finished = True
                break

            # Check for state token (zero-row batch with STATE_KEY)
            if batch.num_rows == 0 and custom_metadata is not None:
                token = custom_metadata.get(STATE_KEY)
                if token is not None:
                    if isinstance(token, bytes):
                        state_bytes = token
                    break

            # Dispatch log/error batches
            if _dispatch_log_or_error(batch, custom_metadata, on_log):
                continue

            # Data batch from producer init
            resolved_batch, resolved_cm = resolve_external_location(
                batch, custom_metadata, external_config, on_log, reader.ipc_validation
            )
            pending_batches.append(AnnotatedBatch(batch=resolved_batch, custom_metadata=resolved_cm))
    except RpcError:
        _drain_stream(reader)
        raise

    _drain_stream(reader)

    return HttpStreamSession(
        client=client,
        url_prefix=url_prefix,
        method=method_name,
        state_bytes=state_bytes,
        output_schema=output_schema,
        on_log=on_log,
        external_config=external_config,
        ipc_validation=ipc_validation,
        pending_batches=pending_batches,
        finished=finished,
        header=header,
        retry_config=retry_config,
        compression_level=compression_level,
    )


class _HttpProxy:
    """Dynamic proxy that implements RPC method calls over HTTP."""

    def __init__(
        self,
        protocol: type,
        client: httpx.Client | _SyncTestClient,
        url_prefix: str,
        on_log: Callable[[Message], None] | None = None,
        *,
        external_config: ExternalLocationConfig | None = None,
        ipc_validation: IpcValidation = IpcValidation.FULL,
        retry_config: HttpRetryConfig | None = None,
        compression_level: int | None = None,
    ) -> None:
        self._protocol = protocol
        self._client = client
        self._url_prefix = url_prefix
        self._methods = rpc_methods(protocol)
        self._on_log = on_log
        self._external_config = external_config
        self._ipc_validation = ipc_validation
        self._retry_config = retry_config
        self._compression_level = compression_level
        # Capability cache populated lazily on first oversized request.
        # ``None`` = not yet probed; missing fields = server didn't advertise.
        self._capabilities: HttpServerCapabilities | None = None

    def _get_capabilities(self) -> HttpServerCapabilities:
        """Discover and cache the server's externalization capabilities.

        Refreshes on first use and whenever the cached snapshot's
        ``cache_expires_at`` (from the server's ``Cache-Control``) has
        passed.  ``None`` expiry means cache forever for this proxy
        instance — server restarts won't be picked up until the proxy
        is recreated, which is the same trade-off the test fixtures use.
        """
        import time as _time

        caps = self._capabilities
        if caps is not None and (caps.cache_expires_at is None or _time.monotonic() < caps.cache_expires_at):
            return caps
        self._capabilities = http_capabilities(client=self._client, prefix=self._url_prefix, retry=self._retry_config)
        return self._capabilities

    def _maybe_externalize_request(self, body: bytes) -> bytes:
        """Pre-emptively externalize *body* if cached capabilities say it's too large.

        The first call on a fresh proxy returns *body* unchanged — we
        don't probe OPTIONS just to check size; the 413 fallback in
        each caller handles that case and warms ``_capabilities`` so
        future calls can pre-empt the failed POST.
        """
        caps = self._capabilities
        if caps is None:
            return body
        if caps.max_request_bytes is None or not caps.upload_url_support or len(body) <= caps.max_request_bytes:
            return body
        return self._externalize_request_body(body)

    def _externalize_request_body(self, body: bytes) -> bytes:
        """Unconditionally externalize *body* via server-vended upload URL.

        Used as the 413 fallback path and (once ``_capabilities`` is
        warm) the pre-flight optimisation in ``_maybe_externalize_request``.
        Populates ``_capabilities`` as a side effect on first use so
        subsequent oversize calls skip the failed POST.
        """
        if self._capabilities is None:
            self._capabilities = self._get_capabilities()
        validator = self._external_config.url_validator if self._external_config is not None else None
        return _externalize_via_upload_url(
            body,
            client=self._client,
            url_prefix=self._url_prefix,
            url_validator=validator,
            retry_config=self._retry_config,
            capabilities=self._capabilities,
        )

    def _resolve_request_encoding(self) -> Encoding | None:
        """Choose a codec for the request body based on cached caps.

        Stable across both ``_build_headers`` and ``_prepare_body`` so
        the two stay in lockstep regardless of which gets called first
        (Python evaluates ``kwargs`` left-to-right, so ``prepare_body``
        may run before ``build_headers`` in some call sites).
        """
        if self._compression_level is None:
            return None
        client_set = _client_offered_encodings()
        if not client_set:
            return None
        return _choose_request_encoding(self._capabilities)

    def _build_headers(self) -> dict[str, str]:
        """Build HTTP headers, advertising codecs and selecting one for the body when compression is enabled."""
        encoding = self._resolve_request_encoding()
        headers: dict[str, str] = {"Content-Type": _ARROW_CONTENT_TYPE}
        if encoding is not None:
            headers["Content-Encoding"] = encoding.value
            headers["Accept-Encoding"] = ", ".join(e.value for e in _client_offered_encodings())
        return headers

    def _prepare_body(self, content: bytes) -> bytes:
        """Compress *content* with the codec resolved from cached caps."""
        encoding = self._resolve_request_encoding()
        return _prepare_request_body(
            content,
            encoding=encoding,
            compression_level=self._compression_level,
        )

    def _refresh_supported_encodings_from_response(
        self, resp: httpx.Response | _SyncTestResponse
    ) -> tuple[Encoding, ...] | None:
        """Harvest ``VGI-Supported-Encodings`` from a response and cache it.

        ``_CapabilitiesMiddleware`` stamps the header on every response,
        including 415s — so the moment we see *any* response from the
        server, we can refine the cached codec set without an OPTIONS
        probe.  Returns the parsed list when present, else ``None``.
        """
        raw = resp.headers.get(SUPPORTED_ENCODINGS_HEADER) or resp.headers.get(SUPPORTED_ENCODINGS_HEADER.lower())
        if not raw:
            return None
        parsed = tuple(parse_encoding_list(raw))
        if not parsed:
            return None
        # Replace or augment the cached caps with the fresh codec list.
        if self._capabilities is None:
            self._capabilities = HttpServerCapabilities(supported_encodings=parsed)
        else:
            from dataclasses import replace

            self._capabilities = replace(self._capabilities, supported_encodings=parsed)
        return parsed

    def __getattr__(self, name: str) -> Any:
        """Resolve RPC method names to callable proxies, caching on first access.

        Returns ``Any`` because each method name maps to a different callable
        signature (unary or stream), so no single static return type can
        represent all of them.
        """
        info = self._methods.get(name)
        if info is None:
            raise AttributeError(f"{self._protocol.__name__} has no RPC method '{name}'")

        if info.method_type == MethodType.UNARY:
            caller = self._make_unary_caller(info)
        elif info.method_type == MethodType.STREAM:
            caller = self._make_stream_caller(info)
        else:
            raise AttributeError(f"Unknown method type for '{name}'")

        self.__dict__[name] = caller
        return caller

    def with_session_token(
        self,
        token: str | None = None,
    ) -> contextlib.AbstractContextManager[_SessionView]:
        """Enter a sticky-session scope; yield a proxy view that tracks the session token.

        Inside the ``with`` block, every request automatically carries
        ``VGI-Session-Accept: true`` (the client opt-in that the server's
        ``ctx.open_session`` requires) and, once the server returns one,
        ``VGI-Session: <token>``. Captured tokens auto-update from response
        headers and clear when the server emits ``VGI-Session-Close: true``.

        Outside the ``with`` block, the underlying connection sends none
        of these headers — so any sticky session a server method might
        open without the opt-in would be silently leaked. The opt-in is
        the leak-prevention contract.

        On block exit, if a session is still live (the server hasn't
        emitted ``VGI-Session-Close``), the framework fires a best-effort
        ``DELETE /vgi/__session__`` so handle-bearing state (cursors, file
        handles) gets released promptly. Failures are suppressed —
        the server's TTL eviction is the safety net.

        Multiple ``with_session_token()`` blocks may be open on the same
        connection concurrently; each block has its own token state because
        the per-call headers are emitted by the per-block tracking client,
        not by the shared underlying httpx.Client.

        Args:
            token: Optional initial session token to resume an existing
                session (e.g. previously stashed via
                :meth:`_SessionView.current_session_token` across a
                process lifecycle).

        Returns:
            A context manager yielding a :class:`_SessionView`. The view
            quacks like the underlying typed proxy — calling any RPC
            method on it goes through the session-tracking client.

        """
        return _open_session_view(self, token)

    def _delete_session_best_effort(self, token: str) -> None:
        """Issue ``DELETE /vgi/__session__`` and swallow any errors.

        Invoked by :class:`_SessionView` on context-manager exit when the
        session is still live. Logs at DEBUG so operators can investigate
        the rare network-failure path without polluting normal logs.
        """
        try:
            self._client.delete(
                f"{self._url_prefix}/{_SESSION_ENDPOINT}",
                headers={SESSION_HEADER: token},
            )
        except Exception:
            wire_http_logger.debug(
                "Best-effort DELETE /%s on with_session_token() exit failed",
                _SESSION_ENDPOINT,
                exc_info=True,
            )

    def _make_unary_caller(self, info: RpcMethodInfo) -> Callable[..., object]:
        client = self._client
        url_prefix = self._url_prefix
        on_log = self._on_log
        ext_cfg = self._external_config
        ipc_validation = self._ipc_validation
        retry_cfg = self._retry_config
        build_headers = self._build_headers
        prepare_body = self._prepare_body
        refresh_supported = self._refresh_supported_encodings_from_response

        maybe_externalize = self._maybe_externalize_request
        externalize = self._externalize_request_body

        def caller(**kwargs: object) -> object:
            if wire_http_logger.isEnabledFor(logging.DEBUG):
                wire_http_logger.debug("HTTP unary call: %s/%s", url_prefix, info.name)
            req_buf = BytesIO()
            _send_request(req_buf, info, kwargs)
            body = maybe_externalize(req_buf.getvalue())

            resp = _post_with_retry(
                client,
                f"{url_prefix}/{info.name}",
                content=prepare_body(body),
                headers=build_headers(),
                config=retry_cfg,
            )
            # 415 fallback: codec we picked isn't enabled on this server.
            # The response carries ``VGI-Supported-Encodings`` (stamped on
            # every response by ``_CapabilitiesMiddleware``); refresh caps
            # and retry once with a codec the server actually accepts.
            if resp.status_code == HTTPStatus.UNSUPPORTED_MEDIA_TYPE and refresh_supported(resp) is not None:
                resp = _post_with_retry(
                    client,
                    f"{url_prefix}/{info.name}",
                    content=prepare_body(body),
                    headers=build_headers(),
                    config=retry_cfg,
                )
            # 413 fallback: server raised its-cap-changed-since-discovery
            # error; externalize and retry once.
            if resp.status_code == HTTPStatus.REQUEST_ENTITY_TOO_LARGE:
                body = externalize(body)
                resp = _post_with_retry(
                    client,
                    f"{url_prefix}/{info.name}",
                    content=prepare_body(body),
                    headers=build_headers(),
                    config=retry_cfg,
                )
            if wire_http_logger.isEnabledFor(logging.DEBUG):
                wire_http_logger.debug(
                    "HTTP unary response: method=%s, status=%d, size=%d",
                    info.name,
                    resp.status_code,
                    len(resp.content),
                )

            reader = _open_response_stream(resp.content, resp.status_code, ipc_validation)
            return _read_unary_response(reader, info, on_log, ext_cfg)

        return caller

    def _make_stream_caller(self, info: RpcMethodInfo) -> Callable[..., HttpStreamSession]:
        client = self._client
        url_prefix = self._url_prefix
        on_log = self._on_log
        ext_cfg = self._external_config
        ipc_validation = self._ipc_validation
        retry_cfg = self._retry_config
        build_headers = self._build_headers
        prepare_body = self._prepare_body
        compression_level = self._compression_level
        refresh_supported = self._refresh_supported_encodings_from_response

        maybe_externalize = self._maybe_externalize_request
        externalize = self._externalize_request_body

        def caller(**kwargs: object) -> HttpStreamSession:
            if wire_http_logger.isEnabledFor(logging.DEBUG):
                wire_http_logger.debug("HTTP stream init: %s/%s/init", url_prefix, info.name)
            # Send init request
            req_buf = BytesIO()
            _send_request(req_buf, info, kwargs)
            body = maybe_externalize(req_buf.getvalue())

            resp = _post_with_retry(
                client,
                f"{url_prefix}/{info.name}/init",
                content=prepare_body(body),
                headers=build_headers(),
                config=retry_cfg,
            )
            if resp.status_code == HTTPStatus.UNSUPPORTED_MEDIA_TYPE and refresh_supported(resp) is not None:
                resp = _post_with_retry(
                    client,
                    f"{url_prefix}/{info.name}/init",
                    content=prepare_body(body),
                    headers=build_headers(),
                    config=retry_cfg,
                )
            if resp.status_code == HTTPStatus.REQUEST_ENTITY_TOO_LARGE:
                body = externalize(body)
                resp = _post_with_retry(
                    client,
                    f"{url_prefix}/{info.name}/init",
                    content=prepare_body(body),
                    headers=build_headers(),
                    config=retry_cfg,
                )
            if wire_http_logger.isEnabledFor(logging.DEBUG):
                wire_http_logger.debug(
                    "HTTP stream init response: method=%s, status=%d, size=%d",
                    info.name,
                    resp.status_code,
                    len(resp.content),
                )

            # Read header from response before main IPC stream (if method declares one).
            # For non-401 errors (e.g. 500), _read_stream_header still works correctly
            # because _set_error_response writes a proper IPC error stream with error
            # metadata, which _read_stream_header detects via _dispatch_log_or_error.
            header = None
            resp_stream = BytesIO(resp.content)
            if info.header_type is not None:
                # Check for auth errors first (plain text, not Arrow IPC)
                if resp.status_code == 401:
                    _open_response_stream(resp.content, resp.status_code, ipc_validation)
                header = _read_stream_header(resp_stream, info.header_type, ipc_validation, on_log, ext_cfg)

            reader = _open_response_stream(resp_stream.read(), resp.status_code, ipc_validation)
            return _init_http_stream_session(
                client=client,
                url_prefix=url_prefix,
                method_name=info.name,
                reader=reader,
                on_log=on_log,
                external_config=ext_cfg,
                ipc_validation=ipc_validation,
                header=header,
                retry_config=retry_cfg,
                compression_level=compression_level,
            )

        return caller


# ---------------------------------------------------------------------------
# Sticky session client-side support
# ---------------------------------------------------------------------------


class _SessionTrackingClient:
    """Thin wrapper around an httpx.Client / _SyncTestClient that injects + captures session headers.

    Every outgoing request carries ``VGI-Session-Accept: true`` (the
    server-side opt-in flag) and, if the view has captured a token,
    ``VGI-Session: <token>``. Every response is scanned for
    ``VGI-Session`` (token rotated by the server — happens at open
    and could in future happen on refresh) and ``VGI-Session-Close:
    true`` (clears the captured token). The wrapped client is shared
    across proxy method closures via duck-typing — we forward
    ``post``/``get``/``options``/``delete``/``put`` explicitly and
    delegate everything else via :meth:`__getattr__`.
    """

    __slots__ = ("_inner", "_view")

    def __init__(self, inner: httpx.Client | _SyncTestClient, view: _SessionView) -> None:
        self._inner = inner
        self._view = view

    def __getattr__(self, name: str) -> Any:
        """Delegate unknown attributes (e.g. ``base_url``, ``headers``) to the inner client."""
        return getattr(self._inner, name)

    def _merge_headers(self, headers: dict[str, str] | None) -> dict[str, str]:
        """Add session opt-in + token + replayed echo headers to a per-request header dict."""
        merged: dict[str, str] = dict(headers or {})
        merged[SESSION_ACCEPT_HEADER] = "true"
        if self._view._token is not None:
            merged[SESSION_HEADER] = self._view._token
        # Replay every echo header the server told us to carry through.
        # The dict is populated lazily on the session-opening response;
        # before that it's empty and the loop is a no-op.
        for name, value in self._view._echo_headers.items():
            # Caller-supplied headers take precedence — operators MAY override
            # an echo header per-call via the explicit headers kwarg if they
            # have a reason to. The normal path leaves them untouched.
            merged.setdefault(name, value)
        return merged

    def _capture(self, resp: Any) -> None:
        """Update the view's session state and captured echo headers from response headers."""
        try:
            hdrs = resp.headers
        except AttributeError:
            return
        token = hdrs.get(SESSION_HEADER) or hdrs.get(SESSION_HEADER.lower())
        if token:
            self._view._token = token
        # Capture VGI-Echo-* on every response (cheap; only emitted on session
        # open, so subsequent responses are no-ops). httpx headers are
        # case-insensitive but _SyncTestResponse stores lowercase — iterate
        # over items() so we hit both shapes uniformly.
        prefix_lower = ECHO_HEADER_PREFIX.lower()
        for hname, hvalue in hdrs.items():
            name_lower = hname.lower()
            if name_lower.startswith(prefix_lower):
                self._view._echo_headers[hname[len(ECHO_HEADER_PREFIX) :]] = hvalue
        close_flag = hdrs.get(SESSION_CLOSE_HEADER) or hdrs.get(SESSION_CLOSE_HEADER.lower())
        if (close_flag or "").strip().lower() == "true":
            self._view._token = None
            self._view._echo_headers.clear()
            self._view._closed = True

    def post(self, url: str, **kwargs: Any) -> Any:
        """Forward POST, merging session headers and capturing the response."""
        kwargs["headers"] = self._merge_headers(kwargs.get("headers"))
        resp = self._inner.post(url, **kwargs)
        self._capture(resp)
        return resp

    def get(self, url: str, **kwargs: Any) -> Any:
        """Forward GET, merging session headers and capturing the response."""
        kwargs["headers"] = self._merge_headers(kwargs.get("headers"))
        resp = self._inner.get(url, **kwargs)
        self._capture(resp)
        return resp

    def options(self, url: str, **kwargs: Any) -> Any:
        """Forward OPTIONS — capability probes don't open sessions, but capture anyway."""
        kwargs["headers"] = self._merge_headers(kwargs.get("headers"))
        resp = self._inner.options(url, **kwargs)
        self._capture(resp)
        return resp

    def delete(self, url: str, **kwargs: Any) -> Any:
        """Forward DELETE — used by ``_HttpProxy._delete_session_best_effort``."""
        kwargs["headers"] = self._merge_headers(kwargs.get("headers"))
        resp = self._inner.delete(url, **kwargs)
        self._capture(resp)
        return resp

    def put(self, url: str, **kwargs: Any) -> Any:
        """Forward PUT unchanged — externalised upload URLs go to external storage."""
        # Don't inject session headers on PUT to external storage URLs:
        # they aren't vgi-rpc requests, and adding random headers could
        # break signed-URL validation.
        return self._inner.put(url, **kwargs)

    def close(self) -> None:
        """No-op: we don't own the inner client; the caller closes it."""


class _SessionView:
    """A scoped sticky-session view of an :class:`_HttpProxy`.

    Yielded by :meth:`_HttpProxy.with_session_token`. Delegates attribute
    access to a fresh proxy whose client is wrapped in
    :class:`_SessionTrackingClient`, so calling ``view.open_counter(...)``
    invokes the underlying proxy through the tracking client and
    automatically carries / captures session headers.

    Stays minimal: token state is two fields, the public surface is
    :meth:`current_session_token` for stashing across processes.
    """

    __slots__ = ("_closed", "_echo_headers", "_outer", "_proxy", "_token", "_tracking_client")

    def __init__(self, outer: _HttpProxy, initial_token: str | None) -> None:
        self._outer = outer
        self._token = initial_token
        self._closed = False
        # Headers the server told us to echo on subsequent requests in this
        # session. Populated by ``_SessionTrackingClient._capture`` from
        # ``VGI-Echo-*`` response headers on the session-opening response.
        # Caller-readable via :meth:`current_echo_headers`.
        self._echo_headers: dict[str, str] = {}
        self._tracking_client = _SessionTrackingClient(outer._client, self)
        # The tracking client implements the same duck-typed surface that
        # _HttpProxy uses (post/get/options/delete/put + close + base_url
        # via __getattr__ delegation); casting to satisfy the union type
        # is honest because the wrapper preserves the contract exactly.
        self._proxy = _HttpProxy(
            outer._protocol,
            cast("httpx.Client | _SyncTestClient", self._tracking_client),
            outer._url_prefix,
            outer._on_log,
            external_config=outer._external_config,
            ipc_validation=outer._ipc_validation,
            retry_config=outer._retry_config,
            compression_level=outer._compression_level,
        )

    def current_session_token(self) -> str | None:
        """Return the session token in flight, or ``None`` if no session is open.

        Useful for stashing the token across a process lifecycle and
        passing it back later via ``conn.with_session_token(token=stashed)``
        to resume the same server-side session. Call :meth:`detach` before
        leaving the ``with`` block to suppress the best-effort DELETE so
        the stashed token resolves to a live registry entry.
        """
        return self._token

    def current_echo_headers(self) -> Mapping[str, str]:
        """Return a read-only snapshot of headers the server told the client to echo.

        Populated by the server's ``VGI-Echo-<name>: <value>`` response
        headers on the session-opening response — used for client-driven
        routing (e.g. ``fly-force-instance-id`` on Fly.io). Empty before
        the first session-opening call returns, and empty again after the
        server emits ``VGI-Session-Close: true``.

        Callers stashing a token for later resumption SHOULD also stash
        this mapping; without the echo headers the resumed session may
        misroute on platforms that depend on client-supplied routing
        (no `Set-Cookie` analogue exists for headers).
        """
        # Return a copy so callers can't mutate our internal state.
        return MappingProxyType(dict(self._echo_headers))

    def detach(self) -> str | None:
        """Hand the session token off to the caller; suppress the exit-time DELETE.

        After ``detach()`` the view forgets the token, so the ``with`` block's
        exit will not fire ``DELETE /vgi/__session__``. The server-side
        session remains live until its TTL elapses or another caller
        explicitly closes it. Returns the token (or ``None`` if no session
        was live to begin with) for convenience.

        Use this when stashing a token for later resumption — without
        ``detach()``, the framework's "always release handles promptly"
        contract would evict the session the moment the block exits.
        """
        token = self._token
        self._token = None
        self._closed = True  # marks the view as already torn down for exit logic
        return token

    def __getattr__(self, name: str) -> Any:
        """Delegate RPC method calls to the inner session-tracking proxy."""
        return getattr(self._proxy, name)


@contextlib.contextmanager
def _open_session_view(
    outer: _HttpProxy,
    token: str | None,
) -> Iterator[_SessionView]:
    """Context-manager body for :meth:`_HttpProxy.with_session_token`."""
    view = _SessionView(outer, initial_token=token)
    try:
        yield view
    finally:
        if not view._closed and view._token is not None:
            outer._delete_session_best_effort(view._token)


# ---------------------------------------------------------------------------
# Server capabilities discovery
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class HttpServerCapabilities:
    """Capabilities advertised by an HTTP RPC server.

    Discovered via ``OPTIONS {prefix}/health`` (or any other route —
    the headers are emitted on every response).  The server may include
    a ``Cache-Control: max-age=N`` header on the OPTIONS response; the
    client honours that and refreshes when ``cache_expires_at`` lapses.

    Attributes:
        max_request_bytes: Maximum request body size the server advertises,
            or ``None`` if the server does not advertise a limit.  The
            server returns ``413 Payload Too Large`` for inline bodies
            above this; clients should externalize via the upload-URL
            flow.
        max_response_bytes: HTTP body cap the server advertises for its
            own responses, or ``None`` if no body cap is configured.
            Conformance tests sizing oversized payloads should multiply
            this by a comfortable factor to provably overshoot.
        max_externalized_response_bytes: Cap on per-response externalised
            payload bytes, or ``None`` if no external cap is configured.
        externalization_enabled: ``True`` iff the server has a storage
            backend wired up.  When ``False``, externalisation cannot
            rescue an oversize response; conformance tests for the
            externalised strict-fail path should skip.
        upload_url_support: Whether the server exposes
            ``__upload_url__/init`` for client-vended pointer-batch uploads.
        max_upload_bytes: Maximum upload size the server advertises for
            client-vended URLs, or ``None`` if not advertised.
        supported_encodings: Content-encoding codecs the server can
            decompress on request bodies and re-encode for responses.
            Parsed from the ``VGI-Supported-Encodings`` response header;
            falls back to ``(Encoding.ZSTD,)`` when the header is
            missing — matches the pre-gzip server, which only ever
            accepted zstd.
        cache_expires_at: Monotonic timestamp (``time.monotonic()``) at
            which this snapshot of the capabilities should be re-probed.
            ``None`` means no expiry hint was given.

    """

    max_request_bytes: int | None = None
    max_response_bytes: int | None = None
    max_externalized_response_bytes: int | None = None
    externalization_enabled: bool = False
    upload_url_support: bool = False
    max_upload_bytes: int | None = None
    supported_encodings: tuple[Encoding, ...] = (Encoding.ZSTD,)
    cache_expires_at: float | None = None
    sticky_enabled: bool = False
    """Whether the server has ``enable_sticky=True`` and supports ``VGI-Session``."""
    sticky_default_ttl: int | None = None
    """Default session TTL in seconds when ``open_session`` is called without an explicit TTL."""
    sticky_echo_headers: tuple[str, ...] = ()
    """Header names the server tells the client to echo on every subsequent session request.

    Parsed from the comma-separated ``VGI-Sticky-Echo-Headers`` capability
    header. Empty tuple when the server is sticky-enabled but has no
    echo-header config (the default), or when the server is non-sticky.
    Concrete values land on the ``_SessionView`` via captured
    ``VGI-Echo-<name>`` response headers on the session-opening response;
    this field exposes the *names* for introspection (LB configuration,
    cross-language client implementations).
    """


def http_capabilities(
    base_url: str | None = None,
    *,
    prefix: str | None = None,
    client: httpx.Client | _SyncTestClient | None = None,
    retry: HttpRetryConfig | None = None,
) -> HttpServerCapabilities:
    """Discover server capabilities via ``OPTIONS {prefix}/health``.

    The capability headers (``VGI-Max-Request-Bytes``,
    ``VGI-Upload-URL-Support``, ``VGI-Max-Upload-Bytes``) are emitted on
    every response, but the dedicated discovery target is ``/health``
    because it is mandatory in every implementation and exempt from
    auth.  The server may include ``Cache-Control: max-age=N`` on the
    OPTIONS response; if so the returned ``HttpServerCapabilities``
    carries ``cache_expires_at`` so callers can refresh on expiry.

    Args:
        base_url: Base URL of the server (e.g. ``http://localhost:8000``).
            Required when *client* is ``None``.
        prefix: URL prefix matching the server's prefix.  ``None``
            auto-detects from ``_SyncTestClient``.
        client: Optional HTTP client (``httpx.Client`` or ``_SyncTestClient``).
        retry: Optional retry configuration for transient HTTP failures.

    Returns:
        An ``HttpServerCapabilities`` with discovered values.

    Raises:
        ValueError: If *base_url* is ``None`` and *client* is ``None``.

    """
    import time as _time

    own_client = client is None
    if client is None:
        if base_url is None:
            raise ValueError("base_url is required when client is not provided")
        client = httpx.Client(base_url=base_url, follow_redirects=True)
    if prefix is None:
        prefix = getattr(client, "prefix", "")

    try:
        url = f"{prefix}/health"
        resp = _options_with_retry(client, url, config=retry)
        headers = resp.headers

        max_req: int | None = None
        raw = headers.get(MAX_REQUEST_BYTES_HEADER) or headers.get(MAX_REQUEST_BYTES_HEADER.lower())
        if raw is not None:
            with contextlib.suppress(ValueError):
                max_req = int(raw)

        max_resp: int | None = None
        raw = headers.get(MAX_RESPONSE_BYTES_HEADER) or headers.get(MAX_RESPONSE_BYTES_HEADER.lower())
        if raw is not None:
            with contextlib.suppress(ValueError):
                max_resp = int(raw)

        max_ext_resp: int | None = None
        raw = headers.get(MAX_EXTERNALIZED_RESPONSE_BYTES_HEADER) or headers.get(
            MAX_EXTERNALIZED_RESPONSE_BYTES_HEADER.lower()
        )
        if raw is not None:
            with contextlib.suppress(ValueError):
                max_ext_resp = int(raw)

        ext_enabled_raw = headers.get(EXTERNALIZATION_ENABLED_HEADER) or headers.get(
            EXTERNALIZATION_ENABLED_HEADER.lower()
        )
        ext_enabled = ext_enabled_raw == "true" if ext_enabled_raw is not None else False

        upload_raw = headers.get(UPLOAD_URL_HEADER) or headers.get(UPLOAD_URL_HEADER.lower())
        upload_support = upload_raw == "true" if upload_raw is not None else False

        max_upload: int | None = None
        upload_bytes_raw = headers.get(MAX_UPLOAD_BYTES_HEADER) or headers.get(MAX_UPLOAD_BYTES_HEADER.lower())
        if upload_bytes_raw is not None:
            with contextlib.suppress(ValueError):
                max_upload = int(upload_bytes_raw)

        supported_raw = headers.get(SUPPORTED_ENCODINGS_HEADER) or headers.get(SUPPORTED_ENCODINGS_HEADER.lower())
        if supported_raw:
            parsed = tuple(parse_encoding_list(supported_raw))
            # Empty parse (e.g. server advertised codecs we don't recognise)
            # falls back to zstd-only — the historical behaviour.
            supported_encodings = parsed if parsed else (Encoding.ZSTD,)
        else:
            supported_encodings = (Encoding.ZSTD,)

        # Honour Cache-Control: max-age=N for refresh scheduling.
        cache_expires_at: float | None = None
        cc = headers.get("Cache-Control") or headers.get("cache-control")
        if cc:
            for token in cc.split(","):
                t = token.strip().lower()
                if t.startswith("max-age="):
                    with contextlib.suppress(ValueError):
                        cache_expires_at = _time.monotonic() + float(t[len("max-age=") :])
                    break

        sticky_enabled_raw = headers.get(STICKY_ENABLED_HEADER) or headers.get(STICKY_ENABLED_HEADER.lower())
        sticky_enabled = sticky_enabled_raw == "true" if sticky_enabled_raw is not None else False

        sticky_ttl: int | None = None
        sticky_ttl_raw = headers.get(STICKY_DEFAULT_TTL_HEADER) or headers.get(STICKY_DEFAULT_TTL_HEADER.lower())
        if sticky_ttl_raw is not None:
            with contextlib.suppress(ValueError):
                sticky_ttl = int(sticky_ttl_raw)

        sticky_echo_raw = headers.get(STICKY_ECHO_HEADERS_HEADER) or headers.get(STICKY_ECHO_HEADERS_HEADER.lower())
        sticky_echo: tuple[str, ...]
        if sticky_echo_raw:
            sticky_echo = tuple(name.strip() for name in sticky_echo_raw.split(",") if name.strip())
        else:
            sticky_echo = ()

        return HttpServerCapabilities(
            max_request_bytes=max_req,
            max_response_bytes=max_resp,
            max_externalized_response_bytes=max_ext_resp,
            externalization_enabled=ext_enabled,
            upload_url_support=upload_support,
            max_upload_bytes=max_upload,
            supported_encodings=supported_encodings,
            cache_expires_at=cache_expires_at,
            sticky_enabled=sticky_enabled,
            sticky_default_ttl=sticky_ttl,
            sticky_echo_headers=sticky_echo,
        )
    finally:
        if own_client:
            client.close()


def request_upload_urls(
    base_url: str | None = None,
    *,
    count: int = 1,
    prefix: str | None = None,
    client: httpx.Client | _SyncTestClient | None = None,
    retry: HttpRetryConfig | None = None,
) -> list[UploadUrl]:
    """Request pre-signed upload URLs from the server's ``__upload_url__`` endpoint.

    The server must have been configured with an ``upload_url_provider``
    in ``make_wsgi_app()``.

    Args:
        base_url: Base URL of the server (e.g. ``http://localhost:8000``).
            Required when *client* is ``None``.
        count: Number of upload URLs to request (default 1, max 100).
        prefix: URL prefix matching the server's prefix.  ``None``
            auto-detects from ``_SyncTestClient``.
        client: Optional HTTP client (``httpx.Client`` or ``_SyncTestClient``).
        retry: Optional retry configuration for transient HTTP failures.

    Returns:
        A list of ``UploadUrl`` objects with pre-signed PUT and GET URLs.

    Raises:
        RpcError: If the server does not support upload URLs (404) or
            returns an error.
        ValueError: If *base_url* is ``None`` and *client* is ``None``.

    """
    own_client = client is None
    if client is None:
        if base_url is None:
            raise ValueError("base_url is required when client is not provided")
        client = httpx.Client(base_url=base_url, follow_redirects=True)
    if prefix is None:
        prefix = getattr(client, "prefix", "")

    try:
        # Build request IPC with standard wire protocol metadata
        req_buf = BytesIO()
        _write_request(req_buf, _UPLOAD_URL_METHOD, _UPLOAD_URL_PARAMS_SCHEMA, {"count": count})

        resp = _post_with_retry(
            client,
            f"{prefix}/__upload_url__/init",
            content=req_buf.getvalue(),
            headers={"Content-Type": _ARROW_CONTENT_TYPE},
            config=retry,
        )

        # Without an upload_url_provider the route doesn't exist and the
        # request falls through to _StreamInitResource → 404.
        if resp.status_code == HTTPStatus.NOT_FOUND:
            raise RpcError("NotSupported", "Server does not support upload URLs", "")

        reader = _open_response_stream(resp.content, resp.status_code)
        urls: list[UploadUrl] = []
        try:
            while True:
                try:
                    batch, custom_metadata = reader.read_next_batch_with_custom_metadata()
                except StopIteration:
                    break

                if _dispatch_log_or_error(batch, custom_metadata):
                    continue

                for i in range(batch.num_rows):
                    upload_url = batch.column("upload_url")[i].as_py()
                    download_url = batch.column("download_url")[i].as_py()
                    expires_at = batch.column("expires_at")[i].as_py()
                    urls.append(UploadUrl(upload_url=upload_url, download_url=download_url, expires_at=expires_at))
        except RpcError:
            _drain_stream(reader)
            raise
        _drain_stream(reader)
        return urls
    finally:
        if own_client:
            client.close()


# ---------------------------------------------------------------------------
# OAuth Protected Resource Metadata discovery (RFC 9728)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class OAuthResourceMetadataResponse:
    """Parsed RFC 9728 metadata received from a server (client-side).

    Returned by ``http_oauth_metadata()`` and ``fetch_oauth_metadata()``.
    For the server-side configuration class, see ``OAuthResourceMetadata``
    in ``vgi_rpc.http._oauth``.

    Attributes:
        resource: Canonical URL of the protected resource.
        authorization_servers: Authorization server issuer URLs.
        scopes_supported: OAuth scopes the resource understands.
        bearer_methods_supported: Token delivery methods supported.
        resource_signing_alg_values_supported: JWS algorithms for
            resource-signed responses.
        resource_name: Human-readable name of the resource.
        resource_documentation: URL to developer documentation.
        resource_policy_uri: URL to the resource's privacy policy.
        resource_tos_uri: URL to the resource's terms of service.
        client_id: OAuth client_id to use when authenticating with the
            authorization server.  Custom extension (not in RFC 9728).
        client_secret: OAuth client_secret to use when authenticating with the
            authorization server.  Custom extension (not in RFC 9728).
        use_id_token_as_bearer: When ``True``, the client should use the
            OIDC ``id_token`` as the Bearer token instead of the
            ``access_token``.  Custom extension (not in RFC 9728).
        device_code_client_id: OAuth client_id to use specifically for the
            device code grant flow.  Custom extension (not in RFC 9728).
        device_code_client_secret: OAuth client_secret to use specifically
            for the device code grant flow.  Custom extension (not in
            RFC 9728).

    """

    resource: str
    authorization_servers: tuple[str, ...]
    scopes_supported: tuple[str, ...] = ()
    bearer_methods_supported: tuple[str, ...] = ("header",)
    resource_signing_alg_values_supported: tuple[str, ...] = ()
    resource_name: str | None = None
    resource_documentation: str | None = None
    resource_policy_uri: str | None = None
    resource_tos_uri: str | None = None
    client_id: str | None = None
    client_secret: str | None = None
    use_id_token_as_bearer: bool = False
    device_code_client_id: str | None = None
    device_code_client_secret: str | None = None


def http_oauth_metadata(
    base_url: str | None = None,
    *,
    prefix: str | None = None,
    client: httpx.Client | _SyncTestClient | None = None,
) -> OAuthResourceMetadataResponse | None:
    """Discover OAuth Protected Resource Metadata (RFC 9728).

    Sends ``GET /.well-known/oauth-protected-resource{prefix}`` and parses
    the JSON response into an ``OAuthResourceMetadataResponse``.

    Args:
        base_url: Base URL of the server (e.g. ``http://localhost:8000``).
            Required when *client* is ``None``.
        prefix: URL prefix matching the server's prefix.  ``None``
            auto-detects from ``_SyncTestClient``.
            Must match the ``prefix`` passed to ``make_wsgi_app()`` on the
            server side — a mismatch will result in a 404 (``None`` return).
        client: Optional HTTP client (``httpx.Client`` or ``_SyncTestClient``).

    Returns:
        An ``OAuthResourceMetadataResponse`` with discovered metadata, or
        ``None`` if the server does not advertise metadata (404).

    Raises:
        ValueError: If *base_url* is ``None`` and *client* is ``None``,
            or if the server returns an unexpected HTTP error.

    """
    own_client = client is None
    if client is None:
        if base_url is None:
            raise ValueError("base_url is required when client is not provided")
        client = httpx.Client(base_url=base_url, follow_redirects=True)
    if prefix is None:
        prefix = getattr(client, "prefix", "")

    try:
        url = f"/.well-known/oauth-protected-resource{prefix}"
        resp: httpx.Response | _SyncTestResponse = client.get(url)
        if resp.status_code == HTTPStatus.NOT_FOUND:
            return None
        if resp.status_code != HTTPStatus.OK:
            raise ValueError(f"Failed to fetch OAuth metadata from {url}: HTTP {resp.status_code}")
        body: dict[str, Any] = json.loads(resp.content)
        return _parse_metadata_json(body)
    finally:
        if own_client:
            client.close()


_RESOURCE_METADATA_RE = re.compile(r'resource_metadata="([^"]+)"')
_CLIENT_ID_RE = re.compile(r'client_id="([^"]+)"')
_CLIENT_SECRET_RE = re.compile(r'client_secret="([^"]+)"')
_USE_ID_TOKEN_RE = re.compile(r'use_id_token_as_bearer="([^"]+)"')
_DEVICE_CODE_CLIENT_ID_RE = re.compile(r'device_code_client_id="([^"]+)"')
_DEVICE_CODE_CLIENT_SECRET_RE = re.compile(r'device_code_client_secret="([^"]+)"')


def parse_resource_metadata_url(www_authenticate: str) -> str | None:
    """Extract the ``resource_metadata`` URL from a ``WWW-Authenticate`` header.

    Parses a ``Bearer`` challenge per RFC 9728 Section 5.1 and returns
    the ``resource_metadata`` parameter value, or ``None`` if not present.

    Args:
        www_authenticate: The ``WWW-Authenticate`` header value
            (e.g. ``'Bearer resource_metadata="https://..."'``).

    Returns:
        The metadata URL string, or ``None`` if the header does not
        contain a ``resource_metadata`` parameter.

    """
    match = _RESOURCE_METADATA_RE.search(www_authenticate)
    return match.group(1) if match else None


def parse_client_id(www_authenticate: str) -> str | None:
    """Extract the ``client_id`` from a ``WWW-Authenticate`` header.

    Parses a ``Bearer`` challenge and returns the ``client_id`` parameter
    value, or ``None`` if not present.  This is a custom extension (not
    defined in RFC 9728).

    Args:
        www_authenticate: The ``WWW-Authenticate`` header value.

    Returns:
        The client_id string, or ``None`` if not present.

    """
    match = _CLIENT_ID_RE.search(www_authenticate)
    return match.group(1) if match else None


def parse_client_secret(www_authenticate: str) -> str | None:
    """Extract the ``client_secret`` from a ``WWW-Authenticate`` header.

    Parses a ``Bearer`` challenge and returns the ``client_secret`` parameter
    value, or ``None`` if not present.  This is a custom extension (not
    defined in RFC 9728).

    Args:
        www_authenticate: The ``WWW-Authenticate`` header value.

    Returns:
        The client_secret string, or ``None`` if not present.

    """
    match = _CLIENT_SECRET_RE.search(www_authenticate)
    return match.group(1) if match else None


def parse_use_id_token_as_bearer(www_authenticate: str) -> bool:
    """Extract the ``use_id_token_as_bearer`` flag from a ``WWW-Authenticate`` header.

    Parses a ``Bearer`` challenge and returns ``True`` if the
    ``use_id_token_as_bearer`` parameter is present with value ``"true"``.
    This is a custom extension (not defined in RFC 9728).

    Args:
        www_authenticate: The ``WWW-Authenticate`` header value.

    Returns:
        ``True`` if the header contains ``use_id_token_as_bearer="true"``,
        ``False`` otherwise.

    """
    match = _USE_ID_TOKEN_RE.search(www_authenticate)
    return match.group(1) == "true" if match else False


def parse_device_code_client_id(www_authenticate: str) -> str | None:
    """Extract the ``device_code_client_id`` from a ``WWW-Authenticate`` header.

    Parses a ``Bearer`` challenge and returns the ``device_code_client_id``
    parameter value, or ``None`` if not present.  This is a custom extension
    (not defined in RFC 9728).

    Args:
        www_authenticate: The ``WWW-Authenticate`` header value.

    Returns:
        The device_code_client_id string, or ``None`` if not present.

    """
    match = _DEVICE_CODE_CLIENT_ID_RE.search(www_authenticate)
    return match.group(1) if match else None


def parse_device_code_client_secret(www_authenticate: str) -> str | None:
    """Extract the ``device_code_client_secret`` from a ``WWW-Authenticate`` header.

    Parses a ``Bearer`` challenge and returns the ``device_code_client_secret``
    parameter value, or ``None`` if not present.  This is a custom extension
    (not defined in RFC 9728).

    Args:
        www_authenticate: The ``WWW-Authenticate`` header value.

    Returns:
        The device_code_client_secret string, or ``None`` if not present.

    """
    match = _DEVICE_CODE_CLIENT_SECRET_RE.search(www_authenticate)
    return match.group(1) if match else None


def _parse_metadata_json(body: dict[str, Any]) -> OAuthResourceMetadataResponse:
    """Parse a JSON dict into an ``OAuthResourceMetadataResponse``.

    Raises:
        ValueError: If required fields (``resource``, ``authorization_servers``)
            are missing from the JSON.

    """
    try:
        resource = body["resource"]
        authorization_servers = body["authorization_servers"]
    except KeyError as exc:
        raise ValueError(f"OAuth metadata response missing required field {exc}") from exc
    return OAuthResourceMetadataResponse(
        resource=resource,
        authorization_servers=tuple(authorization_servers),
        scopes_supported=tuple(body.get("scopes_supported", ())),
        bearer_methods_supported=tuple(body.get("bearer_methods_supported", ("header",))),
        resource_signing_alg_values_supported=tuple(body.get("resource_signing_alg_values_supported", ())),
        resource_name=body.get("resource_name"),
        resource_documentation=body.get("resource_documentation"),
        resource_policy_uri=body.get("resource_policy_uri"),
        resource_tos_uri=body.get("resource_tos_uri"),
        client_id=body.get("client_id"),
        client_secret=body.get("client_secret"),
        use_id_token_as_bearer=body.get("use_id_token_as_bearer", False),
        device_code_client_id=body.get("device_code_client_id"),
        device_code_client_secret=body.get("device_code_client_secret"),
    )


def fetch_oauth_metadata(
    metadata_url: str,
    *,
    client: httpx.Client | _SyncTestClient | None = None,
) -> OAuthResourceMetadataResponse:
    """Fetch OAuth metadata from a URL extracted from a 401 ``WWW-Authenticate`` header.

    Unlike ``http_oauth_metadata()`` which constructs the well-known URL
    from a base URL + prefix, this function fetches from an explicit URL
    — typically parsed from a 401 response via
    ``parse_resource_metadata_url()``.

    Args:
        metadata_url: Full URL to the metadata document (e.g.
            ``https://api.example.com/.well-known/oauth-protected-resource/vgi``).
        client: Optional HTTP client (``httpx.Client`` or ``_SyncTestClient``).

    Returns:
        An ``OAuthResourceMetadataResponse`` with the server's OAuth metadata.

    Raises:
        ValueError: If the server returns a non-200 status code or the
            response is missing required fields.

    """
    own_client = client is None
    if client is None:
        client = httpx.Client(follow_redirects=True)

    try:
        resp: httpx.Response | _SyncTestResponse = client.get(metadata_url)
        if resp.status_code != HTTPStatus.OK:
            raise ValueError(f"Failed to fetch OAuth metadata from {metadata_url}: HTTP {resp.status_code}")
        body: dict[str, Any] = json.loads(resp.content)
        return _parse_metadata_json(body)
    finally:
        if own_client:
            client.close()
