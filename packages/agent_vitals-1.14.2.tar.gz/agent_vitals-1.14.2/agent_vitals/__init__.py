"""Agent Vitals — Standalone agent health monitor.

Detect loops, stuck states, thrash, and runaway costs in any AI agent workflow.

Usage::

    from agent_vitals import AgentVitals, VitalsSnapshot, RawSignals

    monitor = AgentVitals(mission_id="my-task")
    snapshot = monitor.step(
        findings_count=5,
        coverage_score=0.6,
        total_tokens=12000,
        error_count=0,
    )
"""

from .config import ProfileFieldDiff, ThresholdProfile, VitalsConfig, get_vitals_config
from .detection.adaptive_threshold import AdaptiveThreshold, AdaptiveThresholdUpdate
from .detection.cusum import CUSUMTracker, CUSUMUpdate
from .detection.loop import LoopDetectionResult, detect_loop
from .detection.stop_rule import StopRuleSignals, derive_stop_signals
from .exceptions import (
    AdapterError,
    BacktestError,
    ConfigurationError,
    ExportError,
    UnknownProfileError,
    VitalsError,
)
from .export import JSONLExporter, OTLPExporter, VitalsExporter
from .monitor import AgentVitals
from .schema import (
    HealthState,
    InterventionRecord,
    RawSignals,
    TemporalMetricsResult,
    VitalsSnapshot,
)

try:
    from importlib.metadata import version as _pkg_version

    __version__ = _pkg_version("agent-vitals")
except Exception:
    __version__ = "0.0.0"

__all__ = [
    "AdapterError",
    "AgentVitals",
    "AdaptiveThreshold",
    "AdaptiveThresholdUpdate",
    "BacktestError",
    "CUSUMTracker",
    "CUSUMUpdate",
    "ConfigurationError",
    "ExportError",
    "HealthState",
    "InterventionRecord",
    "JSONLExporter",
    "LoopDetectionResult",
    "OTLPExporter",
    "ProfileFieldDiff",
    "RawSignals",
    "StopRuleSignals",
    "TemporalMetricsResult",
    "ThresholdProfile",
    "UnknownProfileError",
    "VitalsConfig",
    "VitalsError",
    "VitalsExporter",
    "VitalsSnapshot",
    "derive_stop_signals",
    "detect_loop",
    "get_vitals_config",
]
