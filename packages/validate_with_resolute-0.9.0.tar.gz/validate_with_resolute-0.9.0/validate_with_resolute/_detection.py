"""Framework detection utilities for validate-with-resolute package."""

import dataclasses
from typing import Any, TypeVar
from resolute import Resolute

T = TypeVar('T')


def detect_and_modify(obj: T, changes: dict[str, Any]) -> Resolute[T]:
    """Detect object type and apply modifications using appropriate method.

    Detection order:
    1. Pydantic v2 (has model_copy method)
    2. Dataclass (via dataclasses.is_dataclass)
    3. Fallback to copy.replace() (Python 3.13+)

    Args:
        obj: The object to modify
        changes: Dictionary of field names and new values

    Returns:
        Resolute[T] containing either the modified object or errors
    """
    try:
        # Check for Pydantic v2
        if hasattr(obj, 'model_copy') and callable(getattr(obj, 'model_copy')):
            return _modify_pydantic(obj, changes)

        # Check for dataclass
        if dataclasses.is_dataclass(obj):
            return _modify_dataclass(obj, changes)

        # Fallback to copy.replace() (Python 3.13+)
        return _modify_with_copy_replace(obj, changes)

    except Exception as e:
        return Resolute.from_error(e)


def _modify_pydantic(obj: T, changes: dict[str, Any]) -> Resolute[T]:
    """Modify a Pydantic v2 model using model_copy.

    Args:
        obj: Pydantic model instance
        changes: Dictionary of field names and new values

    Returns:
        Resolute[T] containing either the modified model or validation errors
    """
    try:
        # Pydantic v2: model_copy doesn't re-validate by default
        # We need to use model_validate with the merged data to trigger validation
        current_data = obj.model_dump()
        updated_data = {**current_data, **changes}

        # This will trigger validation
        modified = obj.__class__.model_validate(updated_data)
        return Resolute.from_value(modified)
    except Exception as e:
        return Resolute.from_error(e)


def _modify_dataclass(obj: T, changes: dict[str, Any]) -> Resolute[T]:
    """Modify a dataclass using dataclasses.replace.

    Args:
        obj: Dataclass instance
        changes: Dictionary of field names and new values

    Returns:
        Resolute[T] containing either the modified dataclass or errors
    """
    errors = []

    # Validate field names first
    valid_fields = {f.name for f in dataclasses.fields(obj)}
    invalid_fields = set(changes.keys()) - valid_fields

    if invalid_fields:
        for field in invalid_fields:
            errors.append(ValueError(f"Invalid field name: '{field}'"))

    # If there are invalid fields, collect all errors and return
    if errors:
        return Resolute.from_errors(errors)

    try:
        # Apply the changes
        modified = dataclasses.replace(obj, **changes)
        return Resolute.from_value(modified)
    except Exception as e:
        errors.append(e)
        return Resolute.from_errors(errors)


def _modify_with_copy_replace(obj: T, changes: dict[str, Any]) -> Resolute[T]:
    """Modify an object using copy.replace() from Python 3.13+.

    Args:
        obj: Any object supporting copy.replace()
        changes: Dictionary of field names and new values

    Returns:
        Resolute[T] containing either the modified object or errors
    """
    try:
        import copy
        if not hasattr(copy, 'replace'):
            return Resolute.from_error(
                TypeError(
                    f"Unsupported type: {type(obj).__name__}. "
                    "Object must be a dataclass, Pydantic v2 model, "
                    "or support copy.replace() (Python 3.13+)"
                )
            )

        modified = copy.replace(obj, **changes)
        return Resolute.from_value(modified)
    except TypeError as e:
        # copy.replace() exists but doesn't support this object type
        # Provide a clearer error message
        if "does not support" in str(e):
            return Resolute.from_error(
                TypeError(
                    f"Unsupported type: {type(obj).__name__}. "
                    "Object must be a dataclass, Pydantic v2 model, "
                    "or support copy.replace() (Python 3.13+)"
                )
            )
        return Resolute.from_error(e)
    except Exception as e:
        return Resolute.from_error(e)
