"""Core modify() and create() functions for immutable object modifications."""

from typing import Any, TypeVar
from resolute import Resolute, Result
from ._detection import detect_and_modify

T = TypeVar('T')


def modify(obj: T, **changes: Any) -> Result[T]:
    """Immutably modify an object with the given changes.

    This function never raises exceptions. All errors are captured
    and returned in the Resolute.errors list.

    Supports:
    - Dataclasses (via dataclasses.replace)
    - Pydantic v2 models (via model_copy)
    - Objects supporting copy.replace() (Python 3.13+)

    Args:
        obj: The object to modify
        **changes: Field names and their new values

    Returns:
        Resolute[T]: Success with modified object, or failure with errors

    Examples:
        >>> from dataclasses import dataclass
        >>> @dataclass
        ... class User:
        ...     name: str
        ...     age: int
        >>> user = User(name="Bob", age=25)
        >>> result = modify(user, name="Alice")
        >>> result.is_success
        True
        >>> result.value.name
        'Alice'

        >>> # Invalid field
        >>> result = modify(user, invalid_field="value")
        >>> result.has_errors
        True
        >>> any(isinstance(e, ValueError) for e in result.errors)
        True

        >>> # Multiple changes
        >>> result = modify(user, name="Charlie", age=30)
        >>> result.value.name
        'Charlie'
        >>> result.value.age
        30
    """
    # Handle empty changes - return success with original object values
    if not changes:
        return Resolute.from_value(obj)

    try:
        # Delegate to framework detection and modification
        return detect_and_modify(obj, changes)
    except Exception as e:
        # Safety net: catch any unexpected exceptions
        return Resolute.from_error(e)


def create(cls: type[T], **kwargs: Any) -> Result[T]:
    """Create an instance of cls with validation errors wrapped in Resolute.

    Counterpart to modify() for object creation. Never raises exceptions -
    all errors are captured and returned in Resolute.errors.

    Args:
        cls: The class to instantiate
        **kwargs: Constructor arguments (field name/value pairs)

    Returns:
        Resolute[T]: Success with created instance, or failure with errors

    Examples:
        >>> from dataclasses import dataclass
        >>> @dataclass
        ... class User:
        ...     name: str
        ...     age: int
        >>> result = create(User, name="Bob", age=25)
        >>> result.is_success
        True
        >>> result.value.name
        'Bob'

        >>> # Missing required field
        >>> result = create(User, name="Bob")
        >>> result.has_errors
        True

        >>> # Pydantic validation error
        >>> from pydantic import BaseModel, field_validator
        >>> class Product(BaseModel):
        ...     price: float
        ...     @field_validator('price')
        ...     @classmethod
        ...     def validate(cls, v: float) -> float:
        ...         if v < 0: raise ValueError('price must be positive')
        ...         return v
        >>> result = create(Product, price=-5.0)
        >>> result.has_errors
        True
    """
    try:
        instance = cls(**kwargs)
        return Resolute.from_value(instance)
    except Exception as e:
        return Resolute.from_error(e)
