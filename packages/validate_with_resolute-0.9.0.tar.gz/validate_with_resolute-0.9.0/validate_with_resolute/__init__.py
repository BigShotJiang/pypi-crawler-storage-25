"""validate-with-resolute: Immutable object modifications with the Result pattern.

This package provides safe, immutable updates for dataclasses and Pydantic models
using the Result pattern (via the resolute package).

Key features:
- No exceptions escape the API
- All validation errors collected in Resolute.errors
- Type-safe immutable modifications
- Works with dataclasses and Pydantic v2

Example:
    >>> from dataclasses import dataclass
    >>> from validate_with_resolute import modify, Record

    >>> @dataclass
    ... class User(Record):
    ...     name: str
    ...     age: int

    >>> # Option 1: Use Record base class (best type checking!)
    >>> user = User(name="Bob", age=25)
    >>> result = user.with_(name="Alice")  # Autocomplete works!
    >>> result.value.name
    'Alice'

    >>> # Option 2: Use modify() directly
    >>> result = modify(user, name="Alice")
    >>> result.value.name
    'Alice'
"""

from .modify import modify, create
from .decorator import is_record, with_modify
from .record import Record

__all__ = [
    'modify',
    'create',
    'is_record',
    'with_modify',  # backwards-compatible alias for is_record
    'Record',
]

__version__ = '0.9.0'
