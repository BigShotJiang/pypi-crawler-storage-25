"""Decorator to add Record-like methods to classes."""

from typing import Any, TypeVar, Self
from resolute import Resolute
from .modify import modify

T = TypeVar('T')


def is_record(cls: type[T]) -> type[T]:
    """Decorator that adds .from_() and .with_() methods to a class.

    Equivalent to inheriting from Record, but works without inheritance.
    Useful when you can't or don't want to change the class hierarchy.

    **Type Checking Note:** Due to Python's type system limitations,
    type checkers and IDEs may not autocomplete the added methods
    (they are added dynamically at runtime). For better type checking,
    use the Record base class instead.

    Args:
        cls: The class to decorate

    Returns:
        The same class with .from_() and .with_() methods added

    Examples:
        >>> from dataclasses import dataclass
        >>> @is_record
        ... @dataclass
        ... class User:
        ...     name: str
        ...     age: int
        >>> result = User.from_(name="Bob", age=25)
        >>> result.is_success
        True
        >>> user = result.value
        >>> result = user.with_(name="Alice")
        >>> result.value.name
        'Alice'

        >>> # Works with Pydantic too
        >>> from pydantic import BaseModel
        >>> @is_record
        ... class Product(BaseModel):
        ...     title: str
        ...     price: float
        >>> result = Product.from_(title="Widget", price=9.99)
        >>> result.value.price
        9.99
    """

    def with_(self: Self, **changes: Any) -> Resolute[Self]:
        """Immutably modify this object with the given changes.

        Args:
            **changes: Field name/value pairs to update

        Returns:
            Resolute[Self] containing either the modified object or errors
        """
        return modify(self, **changes)

    def from_(decorated_cls: type[T], **kwargs: Any) -> Resolute[T]:
        """Create a new instance with validation errors wrapped in Resolute.

        Args:
            **kwargs: Constructor arguments

        Returns:
            Resolute[T] containing either the created instance or errors
        """
        try:
            instance = decorated_cls(**kwargs)
            return Resolute.from_value(instance)
        except Exception as e:
            return Resolute.from_error(e)

    cls.with_ = with_  # type: ignore
    cls.from_ = classmethod(from_)  # type: ignore

    return cls


# Keep with_modify as an alias for backwards compatibility
with_modify = is_record
