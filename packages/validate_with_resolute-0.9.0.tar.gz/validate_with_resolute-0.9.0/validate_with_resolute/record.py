"""Record base class for immutable modifications with .with_() method."""

from typing import Any, Self, TypeVar
from resolute import Resolute, Result

T = TypeVar('T', bound='Record')


class Record:
    """Base class enabling .with_() method for immutable object modifications.

    Inherit from this class to use the fluent .with_() API. Works as a mixin
    with both dataclasses and Pydantic models.

    Examples:
        Dataclass usage:
            >>> from dataclasses import dataclass
            >>> @dataclass
            ... class User(Record):
            ...     name: str
            ...     age: int
            >>> user = User(name="Bob", age=25)
            >>> result = user.with_(name="Alice")
            >>> result.is_success
            True
            >>> result.value.name
            'Alice'

        Pydantic usage:
            >>> from pydantic import BaseModel
            >>> class User(BaseModel, Record):
            ...     name: str
            ...     age: int
            >>> user = User(name="Bob", age=25)
            >>> result = user.with_(name="Alice")
            >>> result.is_success
            True

    Note:
        This is a mixin class that can be combined with any base class.
        For Pydantic models, use multiple inheritance: class MyModel(BaseModel, Record)
    """

    def with_(self: Self, **changes: Any) -> Result[Self]:
        """Immutably modify this object with the given changes.

        Creates a new instance with the specified field updates while preserving
        immutability of the original object. All validation is performed.

        Args:
            **changes: Field name/value pairs to update

        Returns:
            Resolute[Self]: Success with modified object, or failure with errors

        Examples:
            >>> result = user.with_(name="Alice", age=30)
            >>> if result.is_success:
            ...     updated_user = result.value

            >>> # Invalid field
            >>> result = user.with_(invalid_field="value")
            >>> result.has_errors
            True

            >>> # Multiple changes
            >>> result = user.with_(name="Bob", age=25, active=True)
        """
        from .modify import modify
        return modify(self, **changes)

    @classmethod
    def from_(cls: type[T], **kwargs: Any) -> Result[T]:
        """Create a new instance with validation errors wrapped in Resolute.

        This class method attempts to construct an instance using the provided
        keyword arguments. Any exceptions raised during construction (including
        validation errors) are captured and returned in Resolute.errors.

        Args:
            **kwargs: Constructor arguments (field name/value pairs)

        Returns:
            Resolute[T]: Success with created instance, or failure with errors

        Examples:
            >>> # Successful creation
            >>> result = User.from_(name="Bob", age=25)
            >>> if result.is_success:
            ...     user = result.value

            >>> # Validation error (e.g., negative age)
            >>> result = User.from_(name="Bob", age=-5)
            >>> if result.has_errors:
            ...     print(result.errors)  # [ValidationError(...)]

            >>> # Missing required field
            >>> result = User.from_(name="Bob")
            >>> if result.has_errors:
            ...     print(result.errors)  # [TypeError(...)]

            >>> # Invalid field type
            >>> result = User.from_(name="Bob", age="not a number")
            >>> if result.has_errors:
            ...     print(result.errors)  # [ValidationError(...)]

        Note:
            This is particularly useful with Pydantic models where validation
            errors would normally raise exceptions during construction.
        """
        try:
            instance = cls(**kwargs)
            return Resolute.from_value(instance)
        except Exception as e:
            return Resolute.from_error(e)
