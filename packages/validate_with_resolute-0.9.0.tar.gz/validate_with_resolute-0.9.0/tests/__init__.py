"""Test suite for validate-with-resolute package."""
