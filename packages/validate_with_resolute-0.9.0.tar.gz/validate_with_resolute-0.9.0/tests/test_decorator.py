"""Tests for the @is_record decorator (and backwards-compatible with_modify alias)."""

from dataclasses import dataclass
import pytest
from validate_with_resolute import is_record, with_modify, modify, create


class TestIsRecordDecorator:
    """Test the @is_record decorator."""

    def test_decorator_adds_with_and_from_methods(self):
        """Test that decorator adds both with_() and from_() methods."""
        @is_record
        @dataclass
        class Person:
            name: str
            age: int

        assert hasattr(Person, 'with_')
        assert hasattr(Person, 'from_')
        assert callable(Person.from_)

        person = Person(name="Bob", age=25)
        assert callable(person.with_)

    def test_from_creates_instance(self):
        """Test that from_() creates a new instance successfully."""
        @is_record
        @dataclass
        class Person:
            name: str
            age: int

        result = Person.from_(name="Bob", age=25)

        assert result.is_success
        assert isinstance(result.value, Person)
        assert result.value.name == "Bob"
        assert result.value.age == 25

    def test_from_captures_missing_field_error(self):
        """Test that from_() captures missing required field errors."""
        @is_record
        @dataclass
        class Person:
            name: str
            age: int

        result = Person.from_(name="Bob")  # Missing age

        assert result.has_errors
        assert isinstance(result.errors[0], TypeError)

    def test_with_method_works(self):
        """Test that with_() method correctly modifies an instance."""
        @is_record
        @dataclass
        class Person:
            name: str
            age: int

        person = Person(name="Bob", age=25)
        result = person.with_(name="Alice")

        assert result.is_success
        assert result.value.name == "Alice"
        assert person.name == "Bob"  # Original unchanged

    def test_decorator_returns_same_class(self):
        """Test that decorator returns the same class object."""
        @dataclass
        class Original:
            value: str

        decorated = is_record(Original)

        assert decorated is Original
        assert decorated.__name__ == "Original"

    def test_decorator_preserves_class_attributes(self):
        """Test that decorator doesn't remove existing class attributes."""
        @is_record
        @dataclass
        class Person:
            name: str

            def greet(self) -> str:
                return f"Hello, I'm {self.name}"

        person = Person(name="Bob")
        assert person.greet() == "Hello, I'm Bob"
        assert hasattr(person, 'with_')
        assert hasattr(person, 'from_')

    def test_decorator_with_pydantic(self):
        """Test decorator works with Pydantic models."""
        try:
            from pydantic import BaseModel, field_validator

            @is_record
            class User(BaseModel):
                name: str
                age: int

                @field_validator('age')
                @classmethod
                def validate_age(cls, v: int) -> int:
                    if v < 0:
                        raise ValueError('age must be positive')
                    return v

            # from_() captures validation errors
            result = User.from_(name="Bob", age=-5)
            assert result.has_errors

            result = User.from_(name="Bob", age=25)
            assert result.is_success

            # with_() also captures validation errors
            user = result.value
            result = user.with_(age=-5)  # type: ignore[attr-defined]
            assert result.has_errors

        except ImportError:
            pytest.skip("Pydantic not installed")

    def test_from_and_with_identical_to_create_and_modify(self):
        """Test that decorator methods behave identically to standalone functions."""
        @is_record
        @dataclass
        class Person:
            name: str
            age: int

        # from_() should match create()
        result1 = Person.from_(name="Bob", age=25)
        result2 = create(Person, name="Bob", age=25)

        assert result1.is_success == result2.is_success
        assert result1.value.name == result2.value.name

        # with_() should match modify()
        person = Person(name="Bob", age=25)
        result3 = person.with_(name="Alice")  # type: ignore[attr-defined]
        result4 = modify(person, name="Alice")

        assert result3.is_success == result4.is_success
        assert result3.value.name == result4.value.name

    def test_with_modify_is_alias_for_is_record(self):
        """Test that with_modify is a backwards-compatible alias for is_record."""
        assert with_modify is is_record

    def test_with_modify_still_adds_from_method(self):
        """Test that the old with_modify alias also adds from_() now."""
        @with_modify
        @dataclass
        class Person:
            name: str
            age: int

        assert hasattr(Person, 'from_')
        result = Person.from_(name="Bob", age=25)
        assert result.is_success

    def test_decorator_without_dataclass(self):
        """Test decorator on a regular class that's not supported by modify()."""
        @is_record
        class RegularClass:
            def __init__(self, value: str):
                self.value = value

        # from_() should succeed (just calls constructor)
        result = RegularClass.from_(value="test")  # type: ignore[attr-defined]
        assert result.is_success

        obj = result.value
        # with_() will fail because modify() doesn't support regular classes
        result2 = obj.with_(value="new")  # type: ignore[attr-defined]
        assert result2.has_errors
        assert any(isinstance(e, TypeError) for e in result2.errors)


class TestCreateFunction:
    """Test the standalone create() function."""

    def test_create_instance_successfully(self):
        """Test that create() successfully creates an instance."""
        @dataclass
        class User:
            name: str
            age: int

        result = create(User, name="Bob", age=25)

        assert result.is_success
        assert isinstance(result.value, User)
        assert result.value.name == "Bob"

    def test_create_with_missing_field(self):
        """Test that create() captures missing field errors."""
        @dataclass
        class User:
            name: str
            age: int

        result = create(User, name="Bob")  # Missing age

        assert result.has_errors
        assert isinstance(result.errors[0], TypeError)

    def test_create_with_pydantic_validation(self):
        """Test that create() captures Pydantic validation errors."""
        try:
            from pydantic import BaseModel, field_validator

            class User(BaseModel):
                name: str
                age: int

                @field_validator('age')
                @classmethod
                def validate_age(cls, v: int) -> int:
                    if v < 0:
                        raise ValueError('age must be positive')
                    return v

            result = create(User, name="Bob", age=-5)
            assert result.has_errors

            result = create(User, name="Bob", age=25)
            assert result.is_success

        except ImportError:
            pytest.skip("Pydantic not installed")

    def test_create_never_raises(self):
        """Test that create() never raises exceptions."""
        @dataclass
        class User:
            name: str

        # None of these should raise
        result1 = create(User)           # Missing name
        result2 = create(User, bad="x")  # Wrong field

        assert result1.has_errors
        assert result2.has_errors or result2.is_success

    def test_create_matches_from_on_record(self):
        """Test that create(Cls) matches Cls.from_() on Record subclasses."""
        from validate_with_resolute import Record

        @dataclass
        class User(Record):
            name: str
            age: int

        result1 = create(User, name="Bob", age=25)
        result2 = User.from_(name="Bob", age=25)

        assert result1.is_success == result2.is_success
        assert result1.value.name == result2.value.name
        assert result1.value.age == result2.value.age
