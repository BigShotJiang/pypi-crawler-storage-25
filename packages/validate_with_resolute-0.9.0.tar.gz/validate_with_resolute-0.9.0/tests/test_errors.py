"""Tests for error handling in validate-with-resolute."""

from dataclasses import dataclass
import pytest
from validate_with_resolute import modify, with_modify


@dataclass
class User:
    """Test user dataclass."""
    name: str
    age: int
    active: bool = True


@dataclass
class StrictUser:
    """User with type hints that will cause type errors if violated."""
    name: str
    age: int


class UnsupportedClass:
    """A class that doesn't support dataclass or Pydantic."""

    def __init__(self, value: str):
        self.value = value


class TestErrorHandling:
    """Test comprehensive error handling."""

    def test_no_exceptions_escape_api(self):
        """Test that no exceptions escape the modify() API."""
        user = User(name="Bob", age=25)

        # Invalid field - should not raise
        result = modify(user, invalid_field="value")
        assert result.has_errors

        # Multiple invalid fields - should not raise
        result = modify(user, bad1="x", bad2="y", bad3="z")
        assert result.has_errors

    def test_error_messages_are_descriptive(self):
        """Test that error messages contain useful information."""
        user = User(name="Bob", age=25)
        result = modify(user, invalid_field="value")

        assert result.has_errors
        error_msg = str(result.errors[0])
        assert "invalid_field" in error_msg
        assert len(error_msg) > 10  # Should be descriptive

    def test_mix_of_valid_and_invalid_changes(self):
        """Test mix of valid and invalid field changes."""
        user = User(name="Bob", age=25)
        result = modify(user, name="Alice", invalid_field="value")

        # Should return error (invalid field present)
        assert result.has_errors
        assert isinstance(result.errors[0], ValueError)

    def test_type_mismatch_handling(self):
        """Test that type mismatches are handled gracefully."""
        user = User(name="Bob", age=25)

        # Try to set age to a string (type mismatch)
        # Dataclasses don't enforce types at runtime by default,
        # but if validation existed, it would be caught
        result = modify(user, age="not a number")

        # This should succeed for dataclass (no runtime type checking)
        # but demonstrates error handling capability
        # In production with validators, this would fail
        assert result.is_success or result.has_errors

    def test_unsupported_object_type(self):
        """Test that unsupported types return appropriate error."""
        obj = UnsupportedClass("test")
        result = modify(obj, value="new")

        assert result.has_errors
        assert any(isinstance(e, TypeError) for e in result.errors)
        error_msg = str(result.errors[0])
        assert "unsupported" in error_msg.lower()

    def test_multiple_errors_all_collected(self):
        """Test that multiple errors are all collected."""
        user = User(name="Bob", age=25)
        result = modify(user, invalid1="x", invalid2="y", invalid3="z")

        assert result.has_errors
        assert len(result.errors) == 3
        assert all(isinstance(e, ValueError) for e in result.errors)

    def test_empty_modifications_succeeds(self):
        """Test that empty modifications return success."""
        user = User(name="Bob", age=25)
        result = modify(user)

        assert result.is_success
        assert result.value.name == "Bob"
        assert result.value.age == 25

    def test_none_value_handling(self):
        """Test handling of None values."""
        @dataclass
        class OptionalUser:
            name: str
            age: int
            nickname: str | None = None

        user = OptionalUser(name="Bob", age=25, nickname="Bobby")
        result = modify(user, nickname=None)

        assert result.is_success
        assert result.value.nickname is None

    def test_error_accumulation_in_single_call(self):
        """Test that errors accumulate from a single modify call."""
        user = User(name="Bob", age=25)

        # Multiple invalid fields in one call
        result = modify(user, bad_field_1="x", bad_field_2="y")

        assert result.has_errors
        assert len(result.errors) >= 2

    def test_with_modify_decorator_error_handling(self):
        """Test that @with_modify preserves error handling."""
        @with_modify
        @dataclass
        class Person:
            name: str
            age: int

        person = Person(name="Bob", age=25)
        result = person.with_(invalid="value")

        assert result.has_errors
        assert isinstance(result.errors[0], ValueError)

    def test_identical_behavior_modify_and_with(self):
        """Test that modify() and with_() have identical error behavior."""
        @with_modify
        @dataclass
        class Person:
            name: str
            age: int

        person = Person(name="Bob", age=25)

        # Test with invalid field
        result1 = modify(person, invalid_field="x")
        result2 = person.with_(invalid_field="x")

        assert result1.has_errors == result2.has_errors
        assert len(result1.errors) == len(result2.errors)
        assert type(result1.errors[0]) == type(result2.errors[0])

    def test_nested_object_simple_modification(self):
        """Test simple nested object modification (pass modified nested object)."""
        @dataclass
        class Address:
            city: str
            country: str

        @dataclass
        class Person:
            name: str
            address: Address

        address = Address(city="NYC", country="USA")
        person = Person(name="Bob", address=address)

        # Modify nested object separately, then pass to parent
        new_address_result = modify(address, city="LA")
        assert new_address_result.is_success

        result = modify(person, address=new_address_result.value)
        assert result.is_success
        assert result.value.address.city == "LA"
        assert person.address.city == "NYC"  # Original unchanged
