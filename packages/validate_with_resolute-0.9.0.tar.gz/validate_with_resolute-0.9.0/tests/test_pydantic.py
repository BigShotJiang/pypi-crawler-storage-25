"""Tests for Pydantic v2 model modifications using validate-with-resolute."""

import pytest

try:
    from pydantic import BaseModel, field_validator, ValidationError
    PYDANTIC_AVAILABLE = True
except ImportError:
    PYDANTIC_AVAILABLE = False
    pytest.skip("Pydantic not installed", allow_module_level=True)

from validate_with_resolute import modify, with_modify


class User(BaseModel):
    """Test user Pydantic model."""
    name: str
    age: int
    email: str = "user@example.com"

    @field_validator('age')
    @classmethod
    def validate_age(cls, v: int) -> int:
        if v < 0:
            raise ValueError('age must be non-negative')
        if v > 150:
            raise ValueError('age must be realistic')
        return v

    @field_validator('name')
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError('name cannot be empty')
        return v


class Product(BaseModel):
    """Test product Pydantic model."""
    title: str
    price: float

    @field_validator('price')
    @classmethod
    def validate_price(cls, v: float) -> float:
        if v < 0:
            raise ValueError('price must be non-negative')
        return v


class TestPydanticModify:
    """Test modify() function with Pydantic models."""

    def test_pydantic_modification_returns_new_instance(self):
        """Test that modification returns a new instance."""
        user = User(name="Bob", age=25)
        result = modify(user, name="Alice")

        assert result.is_success
        assert result.value is not user
        assert isinstance(result.value, User)

    def test_pydantic_modification_leaves_original_unchanged(self):
        """Test that original object is never modified."""
        user = User(name="Bob", age=25)
        original_name = user.name
        original_age = user.age

        result = modify(user, name="Alice", age=30)

        assert result.is_success
        assert user.name == original_name
        assert user.age == original_age

    def test_pydantic_validation_failure_captured(self):
        """Test that Pydantic validation errors are captured."""
        user = User(name="Bob", age=25)
        result = modify(user, age=-5)

        assert result.has_errors
        assert len(result.errors) >= 1
        # Pydantic wraps validation errors in ValidationError
        assert any('age' in str(e).lower() for e in result.errors)

    def test_multiple_validation_errors_collected(self):
        """Test that multiple validation errors are collected."""
        user = User(name="Bob", age=25)
        result = modify(user, age=-5, name="")

        assert result.has_errors
        # Both validations should fail
        errors_str = ' '.join(str(e) for e in result.errors)
        assert 'age' in errors_str.lower() or 'name' in errors_str.lower()

    def test_pydantic_valid_modification(self):
        """Test successful Pydantic modification."""
        user = User(name="Bob", age=25)
        result = modify(user, age=30)

        assert result.is_success
        assert result.value.age == 30
        assert result.value.name == "Bob"

    def test_pydantic_type_preservation(self):
        """Test that type is preserved with Pydantic models."""
        product = Product(title="Widget", price=9.99)
        result = modify(product, price=12.99)

        assert result.is_success
        assert isinstance(result.value, Product)
        assert result.value.price == 12.99

    def test_pydantic_invalid_field_with_validation(self):
        """Test invalid field on Pydantic model.

        Note: By default, Pydantic v2 ignores extra fields.
        To test error handling for extra fields, use ConfigDict(extra='forbid').
        """
        from pydantic import ConfigDict

        class StrictUser(BaseModel):
            model_config = ConfigDict(extra='forbid')

            name: str
            age: int

            @field_validator('age')
            @classmethod
            def validate_age(cls, v: int) -> int:
                if v < 0:
                    raise ValueError('age must be non-negative')
                return v

        user = StrictUser(name="Bob", age=25)
        result = modify(user, nonexistent="value")

        assert result.has_errors
        # Pydantic will raise ValidationError for extra fields when extra='forbid'
        assert len(result.errors) >= 1


class TestPydanticWithModify:
    """Test @with_modify decorator with Pydantic models."""

    def test_decorator_works_with_pydantic(self):
        """Test that decorator works with Pydantic models."""
        @with_modify
        class Person(BaseModel):
            name: str
            age: int

        person = Person(name="Bob", age=25)
        assert hasattr(person, 'with_')

    def test_pydantic_with_method_validation(self):
        """Test that with_() preserves Pydantic validation."""
        @with_modify
        class Person(BaseModel):
            name: str
            age: int

            @field_validator('age')
            @classmethod
            def validate_age(cls, v: int) -> int:
                if v < 0:
                    raise ValueError('age must be positive')
                return v

        person = Person(name="Bob", age=25)
        result = person.with_(age=-5)

        assert result.has_errors
        assert any('age' in str(e).lower() for e in result.errors)

    def test_pydantic_with_method_success(self):
        """Test successful with_() on Pydantic model."""
        @with_modify
        class Person(BaseModel):
            name: str
            age: int

        person = Person(name="Bob", age=25)
        result = person.with_(name="Alice", age=30)

        assert result.is_success
        assert result.value.name == "Alice"
        assert result.value.age == 30

    def test_pydantic_with_original_unchanged(self):
        """Test that Pydantic original is unchanged."""
        @with_modify
        class Person(BaseModel):
            name: str
            age: int

        person = Person(name="Bob", age=25)
        result = person.with_(age=30)

        assert person.age == 25
        assert result.value.age == 30
