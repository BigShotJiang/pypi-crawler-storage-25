"""Tests for dataclass modifications using validate-with-resolute."""

from dataclasses import dataclass
import pytest
from validate_with_resolute import modify, with_modify


@dataclass
class User:
    """Test user dataclass."""
    name: str
    age: int
    email: str = "user@example.com"


@dataclass
class Product:
    """Test product dataclass."""
    title: str
    price: float
    in_stock: bool = True


class TestDataclassModify:
    """Test modify() function with dataclasses."""

    def test_dataclass_modification_returns_new_instance(self):
        """Test that modification returns a new instance."""
        user = User(name="Bob", age=25)
        result = modify(user, name="Alice")

        assert result.is_success
        assert result.value is not user
        assert isinstance(result.value, User)

    def test_dataclass_modification_leaves_original_unchanged(self):
        """Test that original object is never modified."""
        user = User(name="Bob", age=25)
        original_name = user.name
        original_age = user.age

        result = modify(user, name="Alice", age=30)

        assert result.is_success
        assert user.name == original_name
        assert user.age == original_age

    def test_single_field_modification(self):
        """Test modifying a single field."""
        user = User(name="Bob", age=25)
        result = modify(user, name="Alice")

        assert result.is_success
        assert result.value.name == "Alice"
        assert result.value.age == 25  # unchanged
        assert result.value.email == "user@example.com"  # unchanged

    def test_multiple_fields_modification(self):
        """Test modifying multiple fields in single call."""
        user = User(name="Bob", age=25)
        result = modify(user, name="Alice", age=30, email="alice@example.com")

        assert result.is_success
        assert result.value.name == "Alice"
        assert result.value.age == 30
        assert result.value.email == "alice@example.com"

    def test_type_preservation(self):
        """Test that Generic[T] type is maintained."""
        user = User(name="Bob", age=25)
        result = modify(user, age=26)

        assert result.is_success
        assert type(result.value) == User
        # Type checker should know result.value is User
        assert result.value.name == "Bob"

    def test_default_field_modification(self):
        """Test modifying a field with default value."""
        user = User(name="Bob", age=25)
        result = modify(user, email="bob.new@example.com")

        assert result.is_success
        assert result.value.email == "bob.new@example.com"

    def test_empty_changes_returns_success(self):
        """Test that empty changes dict returns success with same values."""
        user = User(name="Bob", age=25)
        result = modify(user)

        assert result.is_success
        assert result.value.name == "Bob"
        assert result.value.age == 25

    def test_invalid_field_name_returns_error(self):
        """Test that invalid field names result in ValueError."""
        user = User(name="Bob", age=25)
        result = modify(user, invalid_field="value")

        assert result.has_errors
        assert len(result.errors) == 1
        assert isinstance(result.errors[0], ValueError)
        assert "invalid_field" in str(result.errors[0])

    def test_multiple_invalid_fields_all_reported(self):
        """Test that all invalid field names are reported."""
        user = User(name="Bob", age=25)
        result = modify(user, invalid1="x", invalid2="y")

        assert result.has_errors
        assert len(result.errors) == 2
        assert all(isinstance(e, ValueError) for e in result.errors)


class TestDataclassWithModify:
    """Test @with_modify decorator with dataclasses."""

    def test_decorator_adds_with_method(self):
        """Test that decorator adds with_() method to class."""
        @with_modify
        @dataclass
        class Person:
            name: str
            age: int

        person = Person(name="Bob", age=25)
        assert hasattr(person, 'with_')
        assert callable(person.with_)

    def test_with_method_calls_modify_internally(self):
        """Test that with_() calls modify() internally."""
        @with_modify
        @dataclass
        class Person:
            name: str
            age: int

        person = Person(name="Bob", age=25)
        result = person.with_(name="Alice")

        assert result.is_success
        assert result.value.name == "Alice"
        assert result.value.age == 25

    def test_with_method_preserves_immutability(self):
        """Test that with_() doesn't modify original."""
        @with_modify
        @dataclass
        class Person:
            name: str
            age: int

        person = Person(name="Bob", age=25)
        result = person.with_(name="Alice")

        assert person.name == "Bob"
        assert result.value.name == "Alice"

    def test_with_method_multiple_changes(self):
        """Test with_() method with multiple changes."""
        @with_modify
        @dataclass
        class Person:
            name: str
            age: int

        person = Person(name="Bob", age=25)
        result = person.with_(name="Charlie", age=35)

        assert result.is_success
        assert result.value.name == "Charlie"
        assert result.value.age == 35
