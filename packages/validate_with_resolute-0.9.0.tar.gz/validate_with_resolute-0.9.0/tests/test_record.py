"""Tests for Record base class."""

from dataclasses import dataclass
import pytest
from validate_with_resolute import Record, modify

try:
    from pydantic import BaseModel, field_validator
    PYDANTIC_AVAILABLE = True
except ImportError:
    PYDANTIC_AVAILABLE = False


class TestRecordWithDataclass:
    """Test Record base class with dataclasses."""

    def test_record_with_dataclass(self):
        """Test that Record works as a mixin with dataclass."""
        @dataclass
        class User(Record):
            name: str
            age: int

        user = User(name="Bob", age=25)

        # Should have with_() method
        assert hasattr(user, 'with_')
        assert callable(user.with_)

    def test_record_with_method_works(self):
        """Test that with_() method actually modifies."""
        @dataclass
        class User(Record):
            name: str
            age: int

        user = User(name="Bob", age=25)
        result = user.with_(name="Alice")

        assert result.is_success
        assert result.value.name == "Alice"
        assert result.value.age == 25

    def test_record_preserves_immutability(self):
        """Test that original object is unchanged."""
        @dataclass
        class User(Record):
            name: str
            age: int

        user = User(name="Bob", age=25)
        result = user.with_(name="Alice")

        assert user.name == "Bob"  # Original unchanged
        assert result.value.name == "Alice"

    def test_record_multiple_changes(self):
        """Test multiple changes in one call."""
        @dataclass
        class User(Record):
            name: str
            age: int
            active: bool = True

        user = User(name="Bob", age=25)
        result = user.with_(name="Charlie", age=35, active=False)

        assert result.is_success
        assert result.value.name == "Charlie"
        assert result.value.age == 35
        assert result.value.active is False

    def test_record_invalid_field(self):
        """Test that invalid fields return errors."""
        @dataclass
        class User(Record):
            name: str
            age: int

        user = User(name="Bob", age=25)
        result = user.with_(invalid_field="oops")

        assert result.has_errors
        assert any(isinstance(e, ValueError) for e in result.errors)

    def test_record_identical_to_modify(self):
        """Test that Record.with_() behaves identically to modify()."""
        @dataclass
        class User(Record):
            name: str
            age: int

        user = User(name="Bob", age=25)

        result1 = user.with_(name="Alice", age=30)
        result2 = modify(user, name="Alice", age=30)

        assert result1.is_success == result2.is_success
        assert result1.value.name == result2.value.name
        assert result1.value.age == result2.value.age

    def test_record_with_inheritance(self):
        """Test Record works with class inheritance."""
        @dataclass
        class Base(Record):
            name: str

        @dataclass
        class Derived(Base):
            age: int

        obj = Derived(name="Bob", age=25)
        result = obj.with_(name="Alice", age=30)

        assert result.is_success
        assert result.value.name == "Alice"
        assert result.value.age == 30

    def test_record_empty_changes(self):
        """Test empty changes returns success."""
        @dataclass
        class User(Record):
            name: str
            age: int

        user = User(name="Bob", age=25)
        result = user.with_()

        assert result.is_success
        assert result.value.name == "Bob"
        assert result.value.age == 25


@pytest.mark.skipif(not PYDANTIC_AVAILABLE, reason="Pydantic not installed")
class TestRecordWithPydantic:
    """Test Record base class with Pydantic models."""

    def test_record_with_pydantic(self):
        """Test that Record works as a mixin with Pydantic."""
        class User(BaseModel, Record):
            name: str
            age: int

        user = User(name="Bob", age=25)

        # Should have with_() method
        assert hasattr(user, 'with_')
        assert callable(user.with_)

    def test_record_pydantic_with_method_works(self):
        """Test that with_() works with Pydantic validation."""
        class User(BaseModel, Record):
            name: str
            age: int

            @field_validator('age')
            @classmethod
            def validate_age(cls, v: int) -> int:
                if v < 0:
                    raise ValueError('age must be positive')
                return v

        user = User(name="Bob", age=25)
        result = user.with_(age=30)

        assert result.is_success
        assert result.value.age == 30

    def test_record_pydantic_validation_errors(self):
        """Test that Pydantic validation errors are captured."""
        class User(BaseModel, Record):
            name: str
            age: int

            @field_validator('age')
            @classmethod
            def validate_age(cls, v: int) -> int:
                if v < 0:
                    raise ValueError('age must be positive')
                return v

        user = User(name="Bob", age=25)
        result = user.with_(age=-5)

        assert result.has_errors
        assert any('age' in str(e).lower() for e in result.errors)

    def test_record_pydantic_immutability(self):
        """Test that original Pydantic model is unchanged."""
        class User(BaseModel, Record):
            name: str
            age: int

        user = User(name="Bob", age=25)
        result = user.with_(age=30)

        assert user.age == 25  # Original unchanged
        assert result.value.age == 30

    def test_record_pydantic_multiple_inheritance(self):
        """Test that multiple inheritance order works correctly."""
        # BaseModel must come first for Pydantic to work
        class User(BaseModel, Record):
            name: str
            age: int

        user = User(name="Bob", age=25)
        result = user.with_(name="Alice")

        assert result.is_success
        assert isinstance(result.value, BaseModel)
        assert isinstance(result.value, Record)


class TestRecordTypeAnnotations:
    """Test that Record has proper type annotations."""

    def test_record_has_type_hints(self):
        """Test that with_() method has proper type hints."""
        @dataclass
        class User(Record):
            name: str

        # Check that with_() exists and has annotations
        assert hasattr(User.with_, '__annotations__')
        annotations = User.with_.__annotations__

        # Should return Resolute
        assert 'return' in annotations


class TestRecordFromClassMethod:
    """Test Record.from_() class method for safe instance creation."""

    def test_from_creates_instance_successfully(self):
        """Test that from_() creates instances successfully."""
        @dataclass
        class User(Record):
            name: str
            age: int

        result = User.from_(name="Bob", age=25)

        assert result.is_success
        assert isinstance(result.value, User)
        assert result.value.name == "Bob"
        assert result.value.age == 25

    def test_from_with_default_values(self):
        """Test that from_() works with default values."""
        @dataclass
        class User(Record):
            name: str
            age: int = 0

        result = User.from_(name="Bob")

        assert result.is_success
        assert result.value.age == 0

    def test_from_with_missing_required_field(self):
        """Test that from_() captures missing required field errors."""
        @dataclass
        class User(Record):
            name: str
            age: int

        result = User.from_(name="Bob")

        assert result.has_errors
        assert len(result.errors) == 1
        assert isinstance(result.errors[0], TypeError)

    def test_from_with_invalid_field_type(self):
        """Test that from_() captures type errors."""
        @dataclass
        class User(Record):
            name: str
            age: int

        # Dataclasses don't enforce types at runtime by default,
        # but Pydantic does (tested separately)
        result = User.from_(name="Bob", age="not a number")

        # This succeeds for dataclass (no runtime type checking)
        assert result.is_success or result.has_errors

    def test_from_identical_to_modify_empty_object(self):
        """Test that from_() with kwargs is like modify() on empty."""
        @dataclass
        class User(Record):
            name: str
            age: int

        result = User.from_(name="Bob", age=25)

        assert result.is_success
        assert result.value.name == "Bob"
        assert result.value.age == 25

    def test_from_with_pydantic_validation(self):
        """Test that from_() captures Pydantic validation errors."""
        if not PYDANTIC_AVAILABLE:
            pytest.skip("Pydantic not installed")

        class User(BaseModel, Record):
            name: str
            age: int

            @field_validator('age')
            @classmethod
            def validate_age(cls, v: int) -> int:
                if v < 0:
                    raise ValueError('age must be positive')
                return v

        # Valid creation
        result = User.from_(name="Bob", age=25)
        assert result.is_success
        assert result.value.age == 25

        # Invalid age
        result = User.from_(name="Bob", age=-5)
        assert result.has_errors
        assert any('age' in str(e).lower() for e in result.errors)

    def test_from_with_pydantic_missing_field(self):
        """Test that from_() captures missing field errors with Pydantic."""
        if not PYDANTIC_AVAILABLE:
            pytest.skip("Pydantic not installed")

        class User(BaseModel, Record):
            name: str
            age: int

        result = User.from_(name="Bob")

        assert result.has_errors
        # Pydantic raises ValidationError for missing fields
        assert len(result.errors) >= 1

    def test_from_with_pydantic_extra_field(self):
        """Test that from_() handles extra fields based on Pydantic config."""
        if not PYDANTIC_AVAILABLE:
            pytest.skip("Pydantic not installed")

        class User(BaseModel, Record):
            name: str
            age: int

        # By default, Pydantic ignores extra fields
        result = User.from_(name="Bob", age=25, extra="ignored")

        assert result.is_success
        assert result.value.name == "Bob"

    def test_from_returns_correct_type(self):
        """Test that from_() returns the correct type."""
        @dataclass
        class User(Record):
            name: str

        @dataclass
        class Product(Record):
            title: str

        user_result = User.from_(name="Bob")
        product_result = Product.from_(title="Widget")

        assert user_result.is_success
        assert product_result.is_success
        assert isinstance(user_result.value, User)
        assert isinstance(product_result.value, Product)
        assert not isinstance(user_result.value, Product)

    def test_from_with_complex_validation(self):
        """Test from_() with complex Pydantic validation logic."""
        if not PYDANTIC_AVAILABLE:
            pytest.skip("Pydantic not installed")

        class User(BaseModel, Record):
            name: str
            age: int
            email: str

            @field_validator('age')
            @classmethod
            def validate_age(cls, v: int) -> int:
                if v < 0:
                    raise ValueError('age must be positive')
                if v > 150:
                    raise ValueError('age must be realistic')
                return v

            @field_validator('email')
            @classmethod
            def validate_email(cls, v: str) -> str:
                if '@' not in v:
                    raise ValueError('invalid email')
                return v

        # Multiple validation errors
        result = User.from_(name="Bob", age=-5, email="invalid")

        assert result.has_errors
        # Should capture validation errors from both fields
        errors_str = ' '.join(str(e) for e in result.errors)
        assert 'age' in errors_str.lower() or 'email' in errors_str.lower()
