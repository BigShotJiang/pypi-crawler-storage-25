"""Media I/O abstraction layer for :class:`~yggdrasil.io.buffer.BytesIO`.

Each concrete :class:`MediaIO` subclass handles reading and writing a specific
columnar or container format (Parquet, JSON, Arrow IPC, ZIP). The base class
provides:

* **Transparent compression** — when :attr:`media_type` carries a
  :class:`~yggdrasil.io.enums.Codec` (e.g. ``application/json+gzip``),
  reads automatically decompress and writes automatically compress, so
  callers never need to wrap in manual ``decompress()`` / ``compress()``
  calls.
* **Generic adapters** — :meth:`read_pylist`, :meth:`read_pydict`,
  :meth:`read_pandas_frame`, :meth:`read_polars_frame` (and their write
  counterparts) are all routed through the Arrow table read/write path.
* **Batched iteration** — every read method accepts an optional
  ``batch_size`` parameter. When set to a positive integer the method
  returns an ``Iterator`` of chunks instead of a single object, enabling
  memory-efficient streaming over large datasets.

Subclasses only need to implement three methods:

* ``check_options(options, **kwargs) → O`` — validate/merge caller options.
* ``_read_arrow_batches(options) → Iterator[pyarrow.RecordBatch]`` — yield
  record batches from the *uncompressed* buffer.
* ``_write_arrow_batches(batches, schema, options)`` — consume an iterator
  of record batches and write into the *uncompressed* buffer.

Typical usage::

    buf = BytesIO(raw_gzipped_parquet_bytes)
    buf.set_media_type(MediaType("application/vnd.apache.parquet+gzip"), safe=False)
    mio = buf.media_io()                     # returns ParquetIO with auto-decompress
    table = mio.read_arrow_table()           # decompresses then reads

    # Batched iteration
    for batch in mio.read_arrow_table(batch_size=1000):
        process(batch)
"""
from __future__ import annotations

import itertools
from abc import ABC, abstractmethod
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Generic, Iterator, Optional, Sequence, TypeVar, Union

import pyarrow as pa

from yggdrasil.io.enums import MimeTypes, Codec, MediaType, MimeType, SaveMode
from yggdrasil.pickle.serde import ObjectSerde
from .bytes_io import BytesIO
from .media_options import MediaOptions

if TYPE_CHECKING:
    import pandas
    import polars
    import pyarrow

    from yggdrasil.data.cast.options import CastOptionsArg
    from yggdrasil.data.schema import Schema


O = TypeVar("O", bound=MediaOptions)

__all__ = ["MediaIO", "MediaOptions"]


@dataclass(slots=True)
class MediaIO(ABC, Generic[O]):
    """Abstract base for format-specific I/O on a :class:`BytesIO` buffer."""

    media_type: MediaType
    buffer: BytesIO

    # ------------------------------------------------------------------
    # Codec helpers (private)
    # ------------------------------------------------------------------

    @property
    def codec(self) -> Codec | None:
        """Return the transport compression codec, or ``None``."""
        return self.media_type.codec if self.media_type else None

    def _decompressed_buffer(self) -> tuple[BytesIO, bool]:
        """Return ``(buffer, was_decompressed)``.

        If the media type has a codec the buffer is decompressed into a
        **copy** (the original buffer is not mutated). The caller must
        close the copy when done.
        """
        codec = self.codec
        if codec is not None and self.buffer.size > 0:
            return self.buffer.decompress(codec=codec, copy=True), True
        return self.buffer, False

    def _compress_into_buffer(self, plain: BytesIO) -> None:
        """Compress *plain* with :attr:`codec` and replace :attr:`buffer` contents."""
        codec = self.codec
        if codec is not None:
            compressed = plain.compress(codec=codec, copy=True)
            self.buffer.replace_with_payload(compressed.to_bytes())
        else:
            self.buffer.replace_with_payload(plain.to_bytes())

    # ------------------------------------------------------------------
    # Cast helpers (private)
    # ------------------------------------------------------------------

    @staticmethod
    def _apply_cast(
        data: "pyarrow.Table | pyarrow.RecordBatch",
        *,
        options: O,
    ) -> "pyarrow.Table | pyarrow.RecordBatch":
        """Apply configured Arrow cast when requested."""
        cast = options.cast
        if cast is None:
            return data

        try:
            return cast.cast_arrow_tabular(data)
        except Exception:
            if options.raise_error:
                raise
            return data

    # ------------------------------------------------------------------
    # Iterable inference helpers (private)
    # ------------------------------------------------------------------

    @staticmethod
    def _is_nonstring_iterable(obj: Any) -> bool:
        """Return True for iterables not handled by dedicated branches."""
        return (
            isinstance(obj, Iterable)
            and not isinstance(obj, (str, bytes, bytearray, dict, list, pa.Table))
        )

    @staticmethod
    def _is_path_input(obj: Any) -> bool:
        """Return True for ``str`` / ``Path`` / ``os.PathLike`` inputs."""
        if isinstance(obj, (str, Path)):
            return True
        return hasattr(obj, "__fspath__")

    @staticmethod
    def _peek_iterable(obj: Iterable[Any]) -> tuple[Any, Iterator[Any]]:
        """Return first item and a rebuilt iterator including that first item."""
        iterator = iter(obj)
        first = next(iterator)
        return first, itertools.chain((first,), iterator)

    @staticmethod
    def _normalize_dict_records(records: Iterable[Any]) -> list[dict]:
        """Materialize an iterable of dicts into a row-complete list.

        Collects the **union** of keys across all rows and fills missing
        keys with ``None``. This lets :func:`pyarrow.Table.from_pylist`
        safely ingest unstructured / sparse records (e.g. ``[{"id": 1},
        {"name": "a"}]`` or ``[{"id": None}]``) without silently dropping
        keys that don't appear in the first row.
        """
        materialized: list[dict] = []
        key_order: list[str] = []
        seen: set[str] = set()

        for row in records:
            if row is None:
                materialized.append({})
                continue
            if not isinstance(row, dict):
                raise TypeError(
                    "Expected dict rows for write_table(iterable[dict]); "
                    f"got item of type {type(row).__name__}"
                )
            materialized.append(row)
            for key in row:
                if key not in seen:
                    seen.add(key)
                    key_order.append(key)

        if not key_order:
            return []

        return [{k: row.get(k) for k in key_order} for row in materialized]

    @classmethod
    def _safe_table_from_pylist(cls, records: Iterable[Any]) -> "pyarrow.Table":
        """Build an Arrow table from dict records, tolerating sparse keys and null-only columns."""
        normalized = cls._normalize_dict_records(records)
        if not normalized:
            return pa.table({})
        return pa.Table.from_pylist(normalized)  # noqa

    @classmethod
    def _table_from_tabular_iterable(cls, obj: Iterable[Any]) -> "pyarrow.Table":
        """Infer an Arrow table from an iterable of supported tabular objects."""
        first, iterator = cls._peek_iterable(obj)

        if isinstance(first, dict):
            return cls._safe_table_from_pylist(iterator)

        if isinstance(first, pa.RecordBatch):
            return pa.Table.from_batches(list(iterator))

        if isinstance(first, pa.Table):
            tables = list(iterator)
            if not tables:
                return pa.table({})
            return pa.concat_tables(tables, promote_options="default")

        raise TypeError(
            "Unsupported iterable for write_table: expected an iterable of "
            "dict, pyarrow.RecordBatch, or pyarrow.Table, got first item "
            f"of type {type(first)!r}"
        )

    @classmethod
    def _iter_to_batches(
        cls,
        obj: Iterable[Any],
    ) -> tuple[Iterator["pyarrow.RecordBatch"], "pyarrow.Schema"]:
        """Infer a batch iterator and schema from an iterable of tabular objects."""
        first, iterator = cls._peek_iterable(obj)

        if isinstance(first, dict):
            table = cls._safe_table_from_pylist(iterator)
            return iter(table.to_batches()), table.schema

        if isinstance(first, pa.RecordBatch):
            return iterator, first.schema

        if isinstance(first, pa.Table):
            def batch_iter() -> Iterator["pyarrow.RecordBatch"]:
                for tb in iterator:
                    yield from tb.to_batches()

            return batch_iter(), first.schema

        raise TypeError(
            "Unsupported iterable for write_table: expected an iterable of "
            "dict, pyarrow.RecordBatch, or pyarrow.Table, got first item "
            f"of type {type(first)!r}"
        )

    def _write_batches_iterable(
        self,
        obj: Iterable[Any],
        *,
        options: O,
    ) -> None:
        """Write an iterable of tabular chunks to the buffer."""
        try:
            batches, schema = self._iter_to_batches(obj)
        except StopIteration:
            self._write_single_table(pa.table({}), options)
            return

        codec = self.codec
        if codec is not None:
            plain = BytesIO(config=self.buffer.config)
            orig_buffer = self.buffer
            self.buffer = plain
            try:
                self._write_arrow_batches(
                    batches=batches,
                    schema=schema,
                    options=options,
                )
            finally:
                self.buffer = orig_buffer
            self._compress_into_buffer(plain)
            plain.close()
        else:
            self._write_arrow_batches(
                batches=batches,
                schema=schema,
                options=options,
            )

    # ------------------------------------------------------------------
    # Schema inspection
    # ------------------------------------------------------------------

    def collect_schema(self, full: bool = False) -> "Schema":
        """Return the yggdrasil :class:`Schema` without collecting all data.

        Delegates to :meth:`_collect_arrow_schema` to obtain the Arrow
        schema through the most efficient path the concrete format offers
        (Parquet footer, Arrow IPC header, CSV header row, first JSON
        record, first ZIP member, …), then wraps it as a yggdrasil
        :class:`~yggdrasil.data.schema.Schema`.

        When *full* is ``True``, container formats that expose multiple
        inner payloads (:class:`~yggdrasil.io.buffer.zip_io.ZipIO`,
        :class:`~yggdrasil.io.buffer.path_io.PathIO`) inspect every
        member/file and return the unified schema instead of stopping at
        the first one. Single-payload formats ignore the flag.
        """
        from yggdrasil.data.schema import Schema

        return Schema.from_arrow(self._collect_arrow_schema(full=full))

    def _collect_arrow_schema(self, full: bool = False) -> "pyarrow.Schema":
        """Return the Arrow schema without collecting all data.

        Default implementation consumes only the first record batch from
        :meth:`read_arrow_batches`. Subclasses should override with a
        metadata-only fast path when the format allows one. The *full*
        flag is accepted for API consistency; container subclasses use
        it to inspect every member instead of just the first.
        """
        del full
        iterator = self.read_arrow_batches()
        try:
            first = next(iterator)
        except StopIteration:
            return pa.schema([])
        finally:
            close = getattr(iterator, "close", None)
            if close is not None:
                close()
        return first.schema

    # ------------------------------------------------------------------
    # Abstract protocol
    # ------------------------------------------------------------------

    @classmethod
    @abstractmethod
    def check_options(cls, options: Optional[O], *args, **kwargs) -> O:
        """Validate and merge caller-supplied options into a concrete instance."""

    def read_arrow_batches(
        self,
        *args,
        options: Optional[O] = None,
        columns: "Sequence[str] | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        ignore_empty: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        **media_options,
    ) -> Iterator["pyarrow.RecordBatch"]:
        """Yield Arrow record batches, transparently handling decompression.

        Parameters
        ----------
        options:
            Pre-built options instance for this format. When ``None`` a fresh
            default is constructed and the explicit keyword arguments below
            are merged on top.
        columns:
            Optional column projection — only these columns are materialized
            when the format supports pushdown. Unknown names either raise or
            get dropped depending on the format.
        cast:
            Arrow cast configuration applied to each batch after decode. Accepts
            a :class:`~yggdrasil.data.cast.options.CastOptions`, a target
            :class:`pyarrow.Schema` / :class:`pyarrow.Field` / :class:`pyarrow.DataType`,
            or a dict forwarded to ``CastOptions(**cast)``.
        use_threads:
            Enable parallel Arrow decode where the format supports it.
        ignore_empty:
            Suppress zero-row batches so callers never see empty shells.
        raise_error:
            When ``True`` (default) cast failures propagate; when ``False`` the
            uncast batch is yielded instead.
        **media_options:
            Format-specific knobs consumed by the concrete
            :meth:`check_options` implementation (e.g. ``compression``,
            ``delimiter``, ``member``).
        """
        resolved = self.check_options(
            options=options,
            *args,
            columns=columns,
            cast=cast,
            use_threads=use_threads,
            ignore_empty=ignore_empty,
            raise_error=raise_error,
            **media_options,
        )

        buf, decompressed = self._decompressed_buffer()
        orig_buffer = self.buffer
        try:
            if decompressed:
                self.buffer = buf

            for batch in self._read_arrow_batches(options=resolved):
                casted = self._apply_cast(batch, options=resolved)
                if isinstance(casted, pa.Table):
                    yield from casted.to_batches()
                else:
                    yield casted
        finally:
            if decompressed:
                self.buffer = orig_buffer
                buf.close()

    @abstractmethod
    def _read_arrow_batches(self, *, options: O) -> Iterator["pyarrow.RecordBatch"]:
        """Yield record batches from the **uncompressed** buffer."""

    def read_polars_frames(
        self,
        *args,
        options: Optional[O] = None,
        columns: "Sequence[str] | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        ignore_empty: "bool | Any" = ...,
        lazy: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        **media_options,
    ) -> Iterator["polars.DataFrame | polars.LazyFrame"]:
        """Yield one Polars frame per Arrow record batch.

        Parameters
        ----------
        options:
            Pre-built options instance, or ``None`` to start from defaults.
        columns:
            Optional column projection applied before materialization.
        cast:
            Arrow cast configuration applied to each batch before conversion.
        use_threads:
            Enable parallel Arrow decode where the format supports it.
        ignore_empty:
            Suppress zero-row batches.
        lazy:
            When ``True`` each yielded frame is wrapped as a
            :class:`polars.LazyFrame` instead of a
            :class:`polars.DataFrame`.
        raise_error:
            Control whether cast failures propagate.
        **media_options:
            Format-specific knobs forwarded to :meth:`check_options`.
        """
        from yggdrasil.polars.lib import polars as _pl

        resolved = self.check_options(
            options=options,
            *args,
            columns=columns,
            cast=cast,
            use_threads=use_threads,
            ignore_empty=ignore_empty,
            lazy=lazy,
            raise_error=raise_error,
            **media_options,
        )
        for batch in self.read_arrow_batches(options=resolved):
            df = _pl.from_arrow(batch, rechunk=False)
            yield df.lazy() if resolved.lazy else df

    @abstractmethod
    def _write_arrow_batches(
        self,
        *,
        batches: Iterator["pyarrow.RecordBatch"],
        schema: "pyarrow.Schema",
        options: O,
    ) -> None:
        """Consume record batches and write into the **uncompressed** buffer."""

    # ------------------------------------------------------------------
    # Internal helpers: table ↔ batches bridge
    # ------------------------------------------------------------------

    def _read_table_from_batches(self, *, options: O) -> "pyarrow.Table":
        """Collect all batches from :meth:`read_arrow_batches` into one table."""
        batches = list(self.read_arrow_batches(options=options))
        if not batches:
            return pa.table({})
        return pa.Table.from_batches(batches)

    def _write_table_as_batches(self, *, table: "pyarrow.Table", options: O) -> None:
        """Convert *table* to batches and forward to :meth:`_write_arrow_batches`."""
        casted = options.cast.cast_arrow_tabular(table)

        self._write_arrow_batches(
            batches=iter(casted.to_batches()),
            schema=casted.schema,
            options=options.with_cast(None),
        )

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def make(
        cls,
        buffer: "BytesIO | str | Path | Any",
        media: "MediaType | MimeType | str | None" = None,
    ) -> "MediaIO[MediaOptions]":
        if not isinstance(buffer, BytesIO):
            if media is None:
                media = MediaType.parse(buffer, default=MediaType(MimeTypes.OCTET_STREAM))
            buffer = BytesIO(buffer)

        if media is None:
            if buffer.media_type is None:
                raise ValueError(
                    "MediaIO.make requires a media type when the buffer has none set"
                )
            media = buffer.media_type

        media = MediaType.parse(media)
        mt = media.mime_type
        buffer.set_media_type(media, safe=False)

        if mt is MimeTypes.PARQUET:
            from .parquet_io import ParquetIO
            return ParquetIO(media_type=media, buffer=buffer)
        if mt is MimeTypes.CSV or mt is MimeTypes.TSV:
            from .csv_io import CsvIO
            return CsvIO(media_type=media, buffer=buffer)
        if mt is MimeTypes.JSON or mt is MimeTypes.NDJSON:
            from .json_io import JsonIO
            return JsonIO(media_type=media, buffer=buffer)
        if mt is MimeTypes.XML:
            from .xml_io import XmlIO
            return XmlIO(media_type=media, buffer=buffer)
        if mt is MimeTypes.ZIP:
            from .zip_io import ZipIO
            return ZipIO(media_type=media, buffer=buffer)
        if mt is MimeTypes.ARROW_IPC:
            from .arrow_ipc_io import IPCIO
            return IPCIO(media_type=media, buffer=buffer)
        if mt is MimeTypes.XLSX:
            from .xlsx_io import XlsxIO
            return XlsxIO(media_type=media, buffer=buffer)

        raise NotImplementedError(f"Cannot create media IO for {media!r}")

    # ------------------------------------------------------------------
    # Write guard
    # ------------------------------------------------------------------

    def skip_write(self, mode: SaveMode) -> bool:
        """Return ``True`` when to write should be skipped."""
        if self.buffer.size > 0:
            if mode == SaveMode.IGNORE:
                return True
            if mode == SaveMode.ERROR_IF_EXISTS:
                raise IOError(
                    f"Cannot write in already existing {self.buffer!r} "
                    f"with save mode {SaveMode.ERROR_IF_EXISTS.value}"
                )
        return False

    # ------------------------------------------------------------------
    # Option-merging helper (private)
    # ------------------------------------------------------------------

    @staticmethod
    def _merge_explicit_options(
        kwargs: dict[str, Any],
        **explicit: Any,
    ) -> dict[str, Any]:
        """Fold explicitly supplied base options back into ``kwargs``.

        The public read/write methods list ``MediaOptions`` fields with a
        ``...`` sentinel default so they show up in help/autocomplete.
        Anything the caller actually passed lands in *explicit*; sentinels
        are dropped so ``check_options`` sees only real overrides. An
        explicit positional value wins over a duplicate entry in *kwargs*.
        """
        for key, value in explicit.items():
            if value is ...:
                continue
            kwargs[key] = value
        return kwargs

    # ------------------------------------------------------------------
    # Generic write dispatcher
    # ------------------------------------------------------------------

    def write_table(
        self,
        obj: Any,
        *,
        options: O | None = None,
        mode: "SaveMode | str | None | Any" = ...,
        match_by: "Sequence[str] | str | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        **option_kwargs,
    ) -> None:
        """Write a supported tabular object to the buffer.

        Supported inputs
        ----------------
        - ``pyarrow.Table`` / ``pyarrow.RecordBatch``
        - ``Iterable[pyarrow.Table]`` / ``Iterable[pyarrow.RecordBatch]``
        - ``pandas.DataFrame``
        - ``polars.DataFrame`` / ``polars.LazyFrame``
        - ``list[dict]`` or any ``Iterable[dict]`` (including generators)
        - ``dict[str, list]`` (column-oriented)
        - ``str`` / :class:`pathlib.Path` / ``os.PathLike`` pointing to a
          file or directory readable by
          :class:`~yggdrasil.io.buffer.path_io.PathIO` — the source is
          streamed through Arrow batches into this buffer, enabling
          format conversion (e.g. Parquet → JSON).

        Unstructured record streams (heterogeneous or sparse keys, all-``None``
        values, e.g. ``[{"id": None}]`` or ``[{"a": 1}, {"b": "x"}]``) are
        normalized: the union of keys across rows is computed and missing
        entries are backfilled with ``None`` so no columns are silently
        dropped.

        Parameters
        ----------
        obj:
            The tabular payload to write. See "Supported inputs" above.
        options:
            Pre-built options instance for this format, or ``None`` for
            defaults. Explicit keyword arguments below override fields on
            *options*.
        mode:
            Write disposition when the buffer is non-empty. Accepts a
            :class:`~yggdrasil.io.enums.save_mode.SaveMode` or its string
            name (``"auto"``, ``"overwrite"``, ``"append"``, ``"upsert"``,
            ``"ignore"``, ``"error_if_exists"``, ``"truncate"``).
        match_by:
            Column name or sequence of column names that identify rows when
            *mode* is :attr:`SaveMode.UPSERT`. Ignored for other modes.
        cast:
            Arrow cast configuration applied to batches before encode.
        use_threads:
            Enable parallel encode where the format supports it.
        raise_error:
            Control whether cast failures propagate during write.
        **option_kwargs:
            Format-specific write knobs forwarded to :meth:`check_options`
            (e.g. ``compression``, ``include_header``, ``inner_media``).
        """
        option_kwargs = self._merge_explicit_options(
            option_kwargs,
            mode=mode,
            match_by=match_by,
            cast=cast,
            use_threads=use_threads,
            raise_error=raise_error,
        )

        if self._is_path_input(obj):
            from .local_path_io import LocalPathIO

            source = LocalPathIO.make(obj)
            return self.write_table(
                source.read_arrow_batches(),
                options=options,
                **option_kwargs,
            )

        if isinstance(obj, pa.Table):
            return self.write_arrow_table(
                table=obj,
                options=options,
                **option_kwargs,
            )
        elif isinstance(obj, pa.RecordBatch):
            return self.write_arrow_table(
                pa.Table.from_batches([obj]),
                options=options,
                **option_kwargs,
            )

        ns, _ = ObjectSerde.module_and_name(obj)

        if ns.startswith("polars"):
            return self.write_polars_frame(
                obj,
                options=options,
                **option_kwargs,
            )
        elif ns.startswith("pandas"):
            return self.write_pandas_frame(
                obj,
                options=options,
                **option_kwargs
            )

        if isinstance(obj, list):
            if obj:
                bad = next(
                    (row for row in obj if not isinstance(row, (dict, type(None)))),
                    None,
                )
                if bad is not None:
                    raise TypeError(
                        "write_table(list) expects list[dict], "
                        f"got element of type {type(bad).__name__}"
                    )
            self.write_pylist(
                data=obj,
                options=options,
                **option_kwargs,
            )
            return

        if isinstance(obj, dict):
            self.write_pydict(
                data=obj,
                options=options,
                **option_kwargs,
            )
            return

        if self._is_nonstring_iterable(obj):
            resolved = self.check_options(options=options, **option_kwargs)
            if self.skip_write(mode=resolved.mode):
                return

            if resolved.mode in (SaveMode.APPEND, SaveMode.UPSERT):
                table = self._table_from_tabular_iterable(obj)
                existing = self._read_existing_table()
                table = self._apply_save_mode(
                    existing,
                    table,
                    mode=resolved.mode,
                    match_by=resolved.match_by,
                )
                self._write_single_table(table, resolved)
                return

            self._write_batches_iterable(obj, options=resolved)
            return

        ns = ObjectSerde.full_namespace(obj)

        if ns.startswith("pandas."):
            self.write_pandas_frame(
                frame=obj,
                options=options,
                **option_kwargs,
            )
            return

        if ns.startswith("polars."):
            self.write_polars_frame(
                frame=obj,
                options=options,
                **option_kwargs,
            )
            return

        raise TypeError(
            "Unsupported tabular object for write_table: "
            f"{type(obj)!r} (namespace={ns!r}). Expected one of: "
            "pyarrow.Table, Iterator[pyarrow.Table], Iterator[pyarrow.RecordBatch], "
            "pandas.DataFrame, polars.DataFrame, polars.LazyFrame, "
            "list[dict], Iterator[dict], dict[str, list]."
        )

    # ------------------------------------------------------------------
    # Save-mode helpers (private)
    # ------------------------------------------------------------------

    def _read_existing_table(self) -> "pyarrow.Table | None":
        """Read the current buffer contents as an Arrow table, or ``None``."""
        if self.buffer.size <= 0:
            return None
        try:
            table = self.read_arrow_table()
            return table if isinstance(table, pa.Table) else None
        except Exception:
            return None

    @staticmethod
    def _apply_save_mode(
        existing: "pyarrow.Table | None",
        incoming: "pyarrow.Table",
        *,
        mode: SaveMode,
        match_by: "Sequence[str] | None",
    ) -> "pyarrow.Table":
        """Combine *existing* and *incoming* tables according to *mode*."""
        if existing is None or existing.num_rows == 0:
            return incoming

        if mode in (SaveMode.AUTO, SaveMode.OVERWRITE, SaveMode.TRUNCATE):
            return incoming

        if mode == SaveMode.APPEND:
            return pa.concat_tables([existing, incoming], promote_options="default")

        if mode == SaveMode.UPSERT:
            if not match_by:
                raise ValueError(
                    "SaveMode.UPSERT requires match_by columns, got None/empty"
                )
            match_by = list(match_by)

            for col in match_by:
                if col not in existing.column_names:
                    raise ValueError(
                        f"UPSERT match_by column {col!r} not in existing table "
                        f"(columns: {existing.column_names})"
                    )
                if col not in incoming.column_names:
                    raise ValueError(
                        f"UPSERT match_by column {col!r} not in incoming table "
                        f"(columns: {incoming.column_names})"
                    )

            incoming_keys: set[tuple] = set()
            incoming_key_arrays = [
                incoming.column(c).to_pylist() for c in match_by
            ]
            for row_idx in range(incoming.num_rows):
                key = tuple(arr[row_idx] for arr in incoming_key_arrays)
                incoming_keys.add(key)

            existing_key_arrays = [
                existing.column(c).to_pylist() for c in match_by
            ]
            keep_mask: list[bool] = []
            for row_idx in range(existing.num_rows):
                key = tuple(arr[row_idx] for arr in existing_key_arrays)
                keep_mask.append(key not in incoming_keys)

            surviving = existing.filter(pa.array(keep_mask, type=pa.bool_()))

            return pa.concat_tables(
                [surviving, incoming],
                promote_options="default",
            )

        return incoming

    # ------------------------------------------------------------------
    # Batching helpers (private)
    # ------------------------------------------------------------------

    @staticmethod
    def _iter_arrow_batches(
        table: "pyarrow.Table",
        batch_size: int,
    ) -> Iterator["pyarrow.Table"]:
        """Yield successive :class:`pyarrow.Table` slices of *batch_size* rows."""
        total = table.num_rows
        for offset in range(0, total, batch_size):
            yield table.slice(offset, min(batch_size, total - offset))

    # ------------------------------------------------------------------
    # Arrow (primary public API)
    # ------------------------------------------------------------------

    def read_arrow_table(
        self,
        *,
        options: O | None = None,
        columns: "Sequence[str] | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        ignore_empty: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        batch_size: "int | None | Any" = ...,
        **option_kwargs,
    ) -> Union["pyarrow.Table", Iterator["pyarrow.Table"]]:
        """Read the buffer into a :class:`pyarrow.Table`.

        Parameters
        ----------
        options:
            Pre-built options instance for this format, or ``None`` for
            defaults. Explicit keyword arguments below override fields on
            *options*.
        columns:
            Optional column projection — only these columns are
            materialized when the format supports pushdown.
        cast:
            Arrow cast configuration applied to each batch after decode.
        use_threads:
            Enable parallel Arrow decode where supported.
        ignore_empty:
            Suppress zero-row batches.
        raise_error:
            Control whether cast failures propagate.
        batch_size:
            When ``> 0``, returns an iterator of :class:`pyarrow.Table`
            chunks of at most *batch_size* rows instead of a single table.
        **option_kwargs:
            Format-specific read knobs forwarded to :meth:`check_options`.

        Returns
        -------
        pyarrow.Table | Iterator[pyarrow.Table]
            A single table, or an iterator of row-sliced tables when
            *batch_size* is set.
        """
        resolved = self.check_options(
            options=options,
            columns=columns,
            cast=cast,
            use_threads=use_threads,
            ignore_empty=ignore_empty,
            raise_error=raise_error,
            batch_size=batch_size,
            **option_kwargs,
        )
        table = self._read_table_from_batches(options=resolved)

        bs = resolved.batch_size
        if bs and bs > 0:
            return self._iter_arrow_batches(table, bs)
        return table

    def write_arrow_table(
        self,
        table: "pyarrow.Table",
        *,
        options: O | None = None,
        mode: "SaveMode | str | None | Any" = ...,
        match_by: "Sequence[str] | str | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        **option_kwargs,
    ) -> None:
        """Write a :class:`pyarrow.Table` to the buffer.

        Parameters
        ----------
        table:
            The :class:`pyarrow.Table` to encode.
        options:
            Pre-built options instance, or ``None`` for defaults.
        mode:
            Write disposition when the buffer is non-empty (``auto``,
            ``overwrite``, ``append``, ``upsert``, ``ignore``,
            ``error_if_exists``, ``truncate``).
        match_by:
            Column(s) used as the identity key for
            :attr:`SaveMode.UPSERT`.
        cast:
            Arrow cast configuration applied before encode.
        use_threads:
            Enable parallel encode where supported.
        raise_error:
            Control whether cast failures propagate.
        **option_kwargs:
            Format-specific write knobs forwarded to :meth:`check_options`.
        """
        resolved = self.check_options(
            options=options,
            mode=mode,
            match_by=match_by,
            cast=cast,
            use_threads=use_threads,
            raise_error=raise_error,
            **option_kwargs,
        )
        if self.skip_write(mode=resolved.mode):
            return

        if resolved.mode in (SaveMode.APPEND, SaveMode.UPSERT):
            existing = self._read_existing_table()
            table = self._apply_save_mode(
                existing,
                table,
                mode=resolved.mode,
                match_by=resolved.match_by,
            )

        self._write_single_table(table, resolved)

    def _write_single_table(
        self,
        table: "pyarrow.Table",
        options: O,
    ) -> None:
        """Write one table handling codec compression."""
        codec = self.codec
        if codec is not None:
            plain = BytesIO(config=self.buffer.config)
            orig_buffer = self.buffer
            self.buffer = plain
            try:
                self._write_table_as_batches(table=table, options=options)
            finally:
                self.buffer = orig_buffer
            self._compress_into_buffer(plain)
            plain.close()
        else:
            self._write_table_as_batches(table=table, options=options)

    # ------------------------------------------------------------------
    # Python dict / list convenience wrappers
    # ------------------------------------------------------------------

    def read_pylist(
        self,
        *,
        options: O | None = None,
        columns: "Sequence[str] | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        ignore_empty: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        batch_size: "int | None | Any" = ...,
        **option_kwargs,
    ) -> Union[list[dict], Iterator[list[dict]]]:
        """Read the buffer as a list of row dicts.

        Parameters
        ----------
        options:
            Pre-built options instance, or ``None`` for defaults.
        columns:
            Optional column projection applied before row materialization.
        cast:
            Arrow cast configuration applied before conversion to Python
            objects.
        use_threads:
            Enable parallel Arrow decode where supported.
        ignore_empty:
            Suppress zero-row batches.
        raise_error:
            Control whether cast failures propagate.
        batch_size:
            When ``> 0``, returns a generator yielding successive
            ``list[dict]`` chunks of at most *batch_size* rows.
        **option_kwargs:
            Format-specific read knobs forwarded to :meth:`check_options`.
        """
        resolved = self.check_options(
            options=options,
            columns=columns,
            cast=cast,
            use_threads=use_threads,
            ignore_empty=ignore_empty,
            raise_error=raise_error,
            batch_size=batch_size,
            **option_kwargs,
        )
        bs = resolved.batch_size
        if bs and bs > 0:
            return (
                chunk.to_pylist()
                for chunk in self.read_arrow_table(options=resolved)
            )
        return self.read_arrow_table(options=resolved).to_pylist()

    def write_pylist(
        self,
        data: Iterable[dict],
        *,
        options: O | None = None,
        mode: "SaveMode | str | None | Any" = ...,
        match_by: "Sequence[str] | str | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        **option_kwargs,
    ) -> None:
        """Write a list (or iterable/generator) of row dicts to the buffer.

        Accepts unstructured records: missing keys are filled with ``None``
        using the union of keys across rows, and all-``None`` columns are
        written with Arrow ``null`` type.

        Parameters
        ----------
        data:
            An iterable of row dicts. Sparse/heterogeneous keys are
            normalized against the union of keys seen across rows.
        options:
            Pre-built options instance, or ``None`` for defaults.
        mode:
            Write disposition when the buffer is non-empty.
        match_by:
            Identity columns used when *mode* is :attr:`SaveMode.UPSERT`.
        cast:
            Arrow cast configuration applied before encode.
        use_threads:
            Enable parallel encode where supported.
        raise_error:
            Control whether cast failures propagate.
        **option_kwargs:
            Format-specific write knobs forwarded to :meth:`check_options`.
        """
        tb = self._safe_table_from_pylist(data)
        self.write_arrow_table(
            table=tb,
            options=options,
            mode=mode,
            match_by=match_by,
            cast=cast,
            use_threads=use_threads,
            raise_error=raise_error,
            **option_kwargs,
        )

    def read_pydict(
        self,
        *,
        options: O | None = None,
        columns: "Sequence[str] | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        ignore_empty: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        batch_size: "int | None | Any" = ...,
        **option_kwargs,
    ) -> Union[dict[str, list], Iterator[dict[str, list]]]:
        """Read the buffer as a column-oriented dict.

        Parameters
        ----------
        options:
            Pre-built options instance, or ``None`` for defaults.
        columns:
            Optional column projection.
        cast:
            Arrow cast configuration applied before conversion.
        use_threads:
            Enable parallel Arrow decode where supported.
        ignore_empty:
            Suppress zero-row batches.
        raise_error:
            Control whether cast failures propagate.
        batch_size:
            When ``> 0``, returns a generator yielding successive
            ``dict[str, list]`` chunks of at most *batch_size* rows.
        **option_kwargs:
            Format-specific read knobs forwarded to :meth:`check_options`.
        """
        resolved = self.check_options(
            options=options,
            columns=columns,
            cast=cast,
            use_threads=use_threads,
            ignore_empty=ignore_empty,
            raise_error=raise_error,
            batch_size=batch_size,
            **option_kwargs,
        )
        bs = resolved.batch_size
        if bs and bs > 0:
            return (
                chunk.to_pydict()
                for chunk in self.read_arrow_table(options=resolved)
            )
        return self.read_arrow_table(options=resolved).to_pydict()

    def write_pydict(
        self,
        data: dict[str, list],
        *,
        options: O | None = None,
        mode: "SaveMode | str | None | Any" = ...,
        match_by: "Sequence[str] | str | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        **option_kwargs,
    ) -> None:
        """Write a column-oriented dict to the buffer.

        Parameters
        ----------
        data:
            A ``dict[str, list]`` where every value is a column-length list.
        options:
            Pre-built options instance, or ``None`` for defaults.
        mode:
            Write disposition when the buffer is non-empty.
        match_by:
            Identity columns used when *mode* is :attr:`SaveMode.UPSERT`.
        cast:
            Arrow cast configuration applied before encode.
        use_threads:
            Enable parallel encode where supported.
        raise_error:
            Control whether cast failures propagate.
        **option_kwargs:
            Format-specific write knobs forwarded to :meth:`check_options`.
        """
        tb = pa.Table.from_pydict(data) # noqa
        self.write_arrow_table(
            table=tb,
            options=options,
            mode=mode,
            match_by=match_by,
            cast=cast,
            use_threads=use_threads,
            raise_error=raise_error,
            **option_kwargs,
        )

    # ------------------------------------------------------------------
    # Pandas / Polars convenience wrappers
    # ------------------------------------------------------------------

    def read_pandas_frame(
        self,
        *,
        options: O | None = None,
        columns: "Sequence[str] | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        ignore_empty: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        batch_size: "int | None | Any" = ...,
        **option_kwargs,
    ) -> Union["pandas.DataFrame", Iterator["pandas.DataFrame"]]:
        """Read the buffer as a :class:`pandas.DataFrame`.

        Parameters
        ----------
        options:
            Pre-built options instance, or ``None`` for defaults.
        columns:
            Optional column projection.
        cast:
            Arrow cast configuration applied before pandas conversion.
        use_threads:
            Enable parallel Arrow decode where supported.
        ignore_empty:
            Suppress zero-row batches.
        raise_error:
            Control whether cast failures propagate.
        batch_size:
            When ``> 0``, returns a generator yielding
            :class:`pandas.DataFrame` chunks of at most *batch_size* rows.
        **option_kwargs:
            Format-specific read knobs forwarded to :meth:`check_options`.
        """
        resolved = self.check_options(
            options=options,
            columns=columns,
            cast=cast,
            use_threads=use_threads,
            ignore_empty=ignore_empty,
            raise_error=raise_error,
            batch_size=batch_size,
            **option_kwargs,
        )
        bs = resolved.batch_size
        if bs and bs > 0:
            return (
                chunk.to_pandas()
                for chunk in self.read_arrow_table(options=resolved)
            )
        return self.read_arrow_table(options=resolved).to_pandas()

    def write_pandas_frame(
        self,
        frame: "pandas.DataFrame",
        *,
        options: O | None = None,
        mode: "SaveMode | str | None | Any" = ...,
        match_by: "Sequence[str] | str | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        **option_kwargs,
    ) -> None:
        """Write a :class:`pandas.DataFrame` to the buffer.

        The index is preserved only when it has a non-empty ``name``; an
        unnamed ``RangeIndex`` is dropped to stay consistent with typical
        tabular outputs.

        Parameters
        ----------
        frame:
            The :class:`pandas.DataFrame` to encode.
        options:
            Pre-built options instance, or ``None`` for defaults.
        mode:
            Write disposition when the buffer is non-empty.
        match_by:
            Identity columns used when *mode* is :attr:`SaveMode.UPSERT`.
        cast:
            Arrow cast configuration applied before encode.
        use_threads:
            Enable parallel encode where supported.
        raise_error:
            Control whether cast failures propagate.
        **option_kwargs:
            Format-specific write knobs forwarded to :meth:`check_options`.
        """
        tb = pa.Table.from_pandas(
            frame,
            preserve_index=bool(frame.index.name),
        ) # noqa

        self.write_arrow_table(
            table=tb,
            options=options,
            mode=mode,
            match_by=match_by,
            cast=cast,
            use_threads=use_threads,
            raise_error=raise_error,
            **option_kwargs,
        )

    def read_polars_frame(
        self,
        *,
        options: O | None = None,
        columns: "Sequence[str] | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        ignore_empty: "bool | Any" = ...,
        lazy: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        batch_size: "int | None | Any" = ...,
        **option_kwargs,
    ) -> Union[
        "polars.DataFrame",
        "polars.LazyFrame",
        Iterator["polars.DataFrame"],
    ]:
        """Read the buffer as a Polars frame.

        Parameters
        ----------
        options:
            Pre-built options instance, or ``None`` for defaults.
        columns:
            Optional column projection.
        cast:
            Arrow cast configuration applied before Polars conversion.
        use_threads:
            Enable parallel Arrow decode where supported.
        ignore_empty:
            Suppress zero-row batches.
        lazy:
            When ``True`` the returned frame is a
            :class:`polars.LazyFrame` instead of a
            :class:`polars.DataFrame`. Ignored when *batch_size* is set.
        raise_error:
            Control whether cast failures propagate.
        batch_size:
            When ``> 0``, returns a generator yielding
            :class:`polars.DataFrame` chunks of at most *batch_size* rows.
        **option_kwargs:
            Format-specific read knobs forwarded to :meth:`check_options`.
        """
        from yggdrasil.polars.lib import polars as _pl

        resolved = self.check_options(
            options=options,
            columns=columns,
            cast=cast,
            use_threads=use_threads,
            ignore_empty=ignore_empty,
            lazy=lazy,
            raise_error=raise_error,
            batch_size=batch_size,
            **option_kwargs,
        )
        bs = resolved.batch_size
        if bs and bs > 0:
            return (
                _pl.from_arrow(chunk, rechunk=False)
                for chunk in self.read_arrow_table(options=resolved)
            )

        tb = self.read_arrow_table(options=resolved)
        df = _pl.from_arrow(tb, rechunk=False)
        return df.lazy() if resolved.lazy else df

    def write_polars_frame(
        self,
        frame: "polars.DataFrame | polars.LazyFrame",
        *,
        options: O | None = None,
        mode: "SaveMode | str | None | Any" = ...,
        match_by: "Sequence[str] | str | None | Any" = ...,
        cast: "CastOptionsArg | Any" = ...,
        use_threads: "bool | Any" = ...,
        raise_error: "bool | Any" = ...,
        **option_kwargs,
    ) -> None:
        """Write a Polars DataFrame or LazyFrame to the buffer.

        A :class:`polars.LazyFrame` is collected before encode.

        Parameters
        ----------
        frame:
            The Polars frame to encode.
        options:
            Pre-built options instance, or ``None`` for defaults.
        mode:
            Write disposition when the buffer is non-empty.
        match_by:
            Identity columns used when *mode* is :attr:`SaveMode.UPSERT`.
        cast:
            Arrow cast configuration applied before encode.
        use_threads:
            Enable parallel encode where supported.
        raise_error:
            Control whether cast failures propagate.
        **option_kwargs:
            Format-specific write knobs forwarded to :meth:`check_options`.
        """
        resolved = self.check_options(
            options=options,
            mode=mode,
            match_by=match_by,
            cast=cast,
            use_threads=use_threads,
            raise_error=raise_error,
            **option_kwargs,
        )
        casted = resolved.cast.cast_polars_tabular(frame)

        self.write_arrow_table(
            table=casted.rechunk().to_arrow(),
            options=resolved,
        )
