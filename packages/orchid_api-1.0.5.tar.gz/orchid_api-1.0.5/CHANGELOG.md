# CHANGELOG

<!-- version list -->

## v1.0.5 (2026-04-14)

### Bug Fixes

- Built-in tools auth context propagation.
  ([`e7b86d4`](https://github.com/gadz82/orchid-api/commit/e7b86d4e9eeaae4bfa8c10c9cba76043a48bd423))


## v1.0.4 (2026-04-14)

### Bug Fixes

- Built-in tools parameter declarations in config.
  ([`e804dc1`](https://github.com/gadz82/orchid-api/commit/e804dc158bba43b7956bd8e17236d5a5a03f0f3a))


## v1.0.3 (2026-04-13)

### Bug Fixes

- Tools result context injection.
  ([`f69a951`](https://github.com/gadz82/orchid-api/commit/f69a951fffa248dac9a5f9b408cc3c5dcbc8f2a3))


## v1.0.2 (2026-04-13)

### Bug Fixes

- Coversation context optimization.
  ([`ee10a38`](https://github.com/gadz82/orchid-api/commit/ee10a384c0ae6e12cd7d3d20b2cd017f3c354c7c))


## v1.0.0 (2026-04-13)

- Initial Release

## v1.0.1 (2026-04-10)

### Bug Fixes

- Remove useless Dockerfiles for orchid and orchid-api
  ([`e0a61ba`](https://github.com/gadz82/orchid-api/commit/e0a61ba21abda65011b0f7ea3337eb90238246e2))


## v1.0.0 (2026-04-10)

- Initial Release
