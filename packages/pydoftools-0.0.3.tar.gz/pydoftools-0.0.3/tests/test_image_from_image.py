import io

from PIL import Image as PILImage

from pydoftools.npk.consts import IMAGE_FORMAT_8888, IMG_VERSION_1
from pydoftools.npk.img.image import Image, ZlibImage
from pydoftools.npk.img.version.factory import IMGFactory
from pydoftools.npk.img.version.v1 import IMGv1


def test_from_image_sets_bytes_and_dimensions():
    image = Image(IMAGE_FORMAT_8888)

    image.from_image(PILImage.new("RGBA", (2, 3), (10, 20, 30, 40)))

    assert isinstance(image.data, bytes)
    assert image.w == 2
    assert image.h == 3
    assert image.mw == 2
    assert image.mh == 3
    assert image.size == 2 * 3 * 4


def test_zlib_image_from_image_round_trips_through_imgv1():
    img = IMGv1()
    img._version = IMG_VERSION_1

    image = ZlibImage(IMAGE_FORMAT_8888)
    image.from_image(PILImage.new("RGBA", (1, 1), (255, 0, 0, 255)))
    img.images.append(image)

    buffer = io.BytesIO()
    img.save(buffer)

    reopened = IMGFactory.open(io.BytesIO(buffer.getvalue()))
    rebuilt = reopened.build(reopened.images[0])

    assert len(reopened.images) == 1
    assert rebuilt.size == (1, 1)
    assert rebuilt.getpixel((0, 0)) == (255, 0, 0, 255)
