import copy
import io
from pathlib import Path

from pydoftools.npk import NPK

TEST_NPK_PATH = Path(__file__).resolve().parent / 'test.NPK'


def choose_target_file(npk: NPK):
    for file in npk.files:
        if not file.name.endswith('.img'):
            continue

        img = file.to_img()
        if len(img.images) > 0:
            return file

    raise AssertionError('test.NPK 里没有可用的 IMG 文件')


def test_can_append_image_and_read_it_back():
    with TEST_NPK_PATH.open('rb') as fp:
        npk = NPK.open(fp)
        npk.load_all()

    target_file = choose_target_file(npk)
    target_name = target_file.name

    img = target_file.to_img()
    original_count = len(img.images)
    original_sizes = [img.build(image).size for image in img.images]

    source_image = img.images[0]
    source_image.load()
    img.images.append(copy.deepcopy(source_image))

    img_buffer = io.BytesIO()
    img.save(img_buffer)
    target_file.set_data(img_buffer.getvalue())

    npk_buffer = io.BytesIO()
    npk.save(npk_buffer)
    npk_buffer.seek(0)

    saved_npk = NPK.open(npk_buffer)
    saved_file = saved_npk.file_by_name(target_name)
    assert saved_file is not None

    saved_img = saved_file.to_img()
    saved_sizes = [saved_img.build(image).size for image in saved_img.images]

    assert len(saved_img.images) == original_count + 1
    assert saved_sizes[:-1] == original_sizes
    assert saved_sizes[-1] == original_sizes[0]
