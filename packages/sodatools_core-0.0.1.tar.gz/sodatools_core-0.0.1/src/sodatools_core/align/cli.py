from __future__ import annotations

import sys
from typing import Annotated, Optional

import typer

from rich.console import Console

from sodatools_core.common.cli_helpers import (
    HELP_DELIMITER_INPUT,
    HELP_DELIMITER_OUTPUT,
    HELP_EXAMPLE,
    eager_print_callback,
)
from sodatools_core.common.align import _is_numeric
from sodatools_core.common.reader import split_fields, warn_if_tty

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data small | soda align
  soda sample-data small | soda align -H 1
  soda sample-data small | soda align -w 10
"""


def align(
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER_INPUT),
    ] = None,
    output_delimiter: Annotated[
        str,
        typer.Option("--output-delimiter", "-o", help=HELP_DELIMITER_OUTPUT),
    ] = "  ",
    right: Annotated[
        Optional[list[int]],
        typer.Option("--right", "-r", help="Force right-align column N (1-indexed, repeatable)"),
    ] = None,
    left: Annotated[
        Optional[list[int]],
        typer.Option("--left", "-l", help="Force left-align column N (1-indexed, repeatable)"),
    ] = None,
    width: Annotated[
        Optional[int],
        typer.Option("--width", "-w", help="Minimum column width (pads narrow columns, never truncates)"),
    ] = None,
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help="First N lines are headers (underlined)"),
    ] = None,
    example: Annotated[
        bool, typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE)
    ] = False,
) -> None:
    """Buffer and align columns to fixed widths. Numbers right-justified, strings left-justified."""
    warn_if_tty(sys.stdin, "align")

    right_cols = set(right) if right else set()
    left_cols = set(left) if left else set()

    # Buffer all rows
    all_rows: list[list[str]] = []
    for line in sys.stdin:
        stripped = line.rstrip("\r\n")
        if not stripped:
            continue
        all_rows.append(split_fields(line, delimiter))

    if not all_rows:
        raise SystemExit(0)

    # Compute max widths and auto-detect numeric columns
    ncols = max(len(row) for row in all_rows)
    widths = [0] * ncols
    numeric = [True] * ncols  # assume numeric until proven otherwise
    header_rows = header if header is not None else 0

    for row_idx, row in enumerate(all_rows):
        for i, f in enumerate(row):
            if len(f) > widths[i]:
                widths[i] = len(f)
            # Skip header rows for numeric detection
            if row_idx >= header_rows and f and not _is_numeric(f):
                numeric[i] = False

    # Explicit minimum width override
    if width is not None:
        widths = [max(w, width) for w in widths]

    # Explicit alignment overrides
    for col in right_cols:
        if 1 <= col <= ncols:
            numeric[col - 1] = True
    for col in left_cols:
        if 1 <= col <= ncols:
            numeric[col - 1] = False

    # Output
    for row_idx, row in enumerate(all_rows):
        parts: list[str] = []
        for i in range(ncols):
            val = row[i] if i < len(row) else ""
            if numeric[i] and row_idx >= header_rows:
                parts.append(val.rjust(widths[i]))
            else:
                parts.append(val.ljust(widths[i]))

        line_out = output_delimiter.join(parts).rstrip()

        if header is not None and row_idx < header:
            sys.stdout.write(line_out + "\n")
            # Underline: match alignment per column
            dashes: list[str] = []
            for i in range(ncols):
                dashes.append("-" * widths[i])
            sys.stdout.write(output_delimiter.join(dashes).rstrip() + "\n")
        else:
            sys.stdout.write(line_out + "\n")

    raise SystemExit(0)
