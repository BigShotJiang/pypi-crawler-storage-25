from __future__ import annotations

import sys
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Annotated, Optional

import typer
from rich.console import Console

from sodatools_core.common.cli_helpers import (
    HELP_ALIGN,
    HELP_DELIMITER,
    HELP_EXAMPLE,
    HELP_HEADER_SKIP,
    HELP_NO_FAIL,
    eager_print_callback,
)
from sodatools_core.common.align import StreamingAligner
from sodatools_core.common.parsing import parse_duration, parse_iso8601
from sodatools_core.common.reader import split_fields, warn_if_tty

err_console = Console(stderr=True)

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data weather | soda tag -H1 hot: 2gt25 cold: 2lt15 normal: 2ge15 2le25 | soda events -H1
  soda sample-data weather | soda tag -H1 hot: 2gt25 | soda events -H1 --min 5
  soda sample-data weather | soda tag -H1 hot: 2gt25 | soda events -H1 --gap 600 --print-header
"""


def _try_parse_datetime(value: str) -> datetime | None:
    try:
        return parse_iso8601(value)
    except (ValueError, IndexError, TypeError):
        return None


def _try_parse_float(value: str) -> float | None:
    try:
        return float(value)
    except ValueError:
        return None


def _format_duration(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.0f}s"
    if seconds < 3600:
        return f"{seconds / 60:.1f}m"
    if seconds < 86400:
        return f"{seconds / 3600:.1f}h"
    return f"{seconds / 86400:.1f}d"


def _resolve_col_idx(col: int, num_fields: int) -> int:
    """Resolve 1-indexed (or negative) column to 0-indexed."""
    if col > 0:
        return col - 1
    return num_fields + col


@dataclass
class PendingRun:
    state: str
    start_time: str
    start_val: float  # numeric time for comparison
    stop_time: str
    stop_val: float
    count: int


def _split_datetime(iso_str: str) -> tuple[str, str]:
    """Split an ISO 8601 string into date and time parts."""
    if "T" in iso_str:
        date, time = iso_str.split("T", 1)
        return date, time
    return iso_str, iso_str


@dataclass
class EventEmitter:
    """Streaming state machine for converting state rows to events."""

    min_samples: int
    gap_threshold: float  # seconds, 0 = disabled
    is_datetime: bool
    out_delim: str
    aligner: StreamingAligner | None
    merlin: bool = False

    current: PendingRun | None = field(default=None, init=False)
    pending: PendingRun | None = field(default=None, init=False)

    def _emit(self, run: PendingRun) -> None:
        if self.merlin:
            self._emit_merlin(run)
            return

        if self.is_datetime:
            dur_secs = run.stop_val - run.start_val
            duration = _format_duration(dur_secs)
        else:
            duration = str(run.stop_val - run.start_val)

        fields = [run.state, run.start_time, run.stop_time, duration, str(run.count)]
        if self.aligner is not None:
            self.aligner.write_row(fields)
        else:
            sys.stdout.write(self.out_delim.join(fields) + "\n")

    def _emit_merlin(self, run: PendingRun) -> None:
        dur_secs = run.stop_val - run.start_val
        start_date, start_time = _split_datetime(run.start_time)
        _, stop_time = _split_datetime(run.stop_time)
        fields = [
            start_date.replace("-", ""),
            start_time.replace(":", ""),
            stop_time.replace(":", ""),
            f"TYPE={run.state}", f"DUR={dur_secs:.0f}", f"NUMPTS={run.count}",
        ]
        if self.aligner is not None:
            self.aligner.write_row(fields)
        else:
            sys.stdout.write(self.out_delim.join(fields) + "\n")

    def _merge_pending_into_current(self) -> None:
        """Merge pending short run back into current event."""
        if self.pending is not None and self.current is not None:
            self.current.stop_time = self.pending.stop_time
            self.current.stop_val = self.pending.stop_val
            self.current.count += self.pending.count
            self.pending = None

    def process_row(self, state: str, time_str: str, time_val: float) -> None:
        # Check for time gap
        is_gap = False
        if self.gap_threshold > 0 and self.current is not None:
            prev_val = self.pending.stop_val if self.pending else self.current.stop_val
            delta = time_val - prev_val
            if delta > self.gap_threshold:
                is_gap = True

        if is_gap:
            # Flush everything
            self._merge_pending_into_current()
            if self.current is not None:
                self._emit(self.current)
            self.current = PendingRun(
                state=state, start_time=time_str, start_val=time_val,
                stop_time=time_str, stop_val=time_val, count=1,
            )
            self.pending = None
            return

        if self.current is None:
            # First row
            self.current = PendingRun(
                state=state, start_time=time_str, start_val=time_val,
                stop_time=time_str, stop_val=time_val, count=1,
            )
            return

        if state == self.current.state:
            # Same as current — merge any pending short run back
            self._merge_pending_into_current()
            self.current.stop_time = time_str
            self.current.stop_val = time_val
            self.current.count += 1

        elif self.pending is not None and state == self.pending.state:
            # Extends pending run
            self.pending.stop_time = time_str
            self.pending.stop_val = time_val
            self.pending.count += 1

            if self.pending.count >= self.min_samples:
                # Pending is confirmed — emit current, promote pending
                self._emit(self.current)
                self.current = self.pending
                self.pending = None

        else:
            # New state — merge any existing pending into current, start new pending
            self._merge_pending_into_current()

            if self.min_samples <= 1:
                # No min filtering — emit current immediately
                self._emit(self.current)
                self.current = PendingRun(
                    state=state, start_time=time_str, start_val=time_val,
                    stop_time=time_str, stop_val=time_val, count=1,
                )
            else:
                self.pending = PendingRun(
                    state=state, start_time=time_str, start_val=time_val,
                    stop_time=time_str, stop_val=time_val, count=1,
                )

    def flush(self) -> None:
        """Emit any remaining events."""
        self._merge_pending_into_current()
        if self.current is not None:
            self._emit(self.current)


def events(
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER),
    ] = None,
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help=HELP_HEADER_SKIP),
    ] = None,
    time_col: Annotated[
        int,
        typer.Option("--time", help="Time column (1-indexed, default: 1)"),
    ] = 1,
    state_col: Annotated[
        int,
        typer.Option("--state", help="State column (1-indexed, default: last)"),
    ] = -1,
    min_samples: Annotated[
        int,
        typer.Option("--min", help="Minimum samples for a state to be valid (shorter runs merge into previous)"),
    ] = 1,
    gap: Annotated[
        Optional[str],
        typer.Option("--gap", help="Time gap threshold (e.g. 60s, 5m, or bare seconds). Gaps > N break events."),
    ] = None,
    no_fail: Annotated[
        bool,
        typer.Option("--no-fail", help=HELP_NO_FAIL),
    ] = False,
    align_cols: Annotated[
        bool,
        typer.Option("--align", help=HELP_ALIGN),
    ] = False,
    merlin: Annotated[
        bool,
        typer.Option("--merlin", help="Merlin output format: date start stop TYPE= DUR= NUMPTS="),
    ] = False,
    print_header: Annotated[
        bool,
        typer.Option("--print-header", help="Print column names as first output row"),
    ] = False,
    example: Annotated[
        bool,
        typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE),
    ] = False,
) -> None:
    """Convert per-row state labels into bounded events with start/stop times."""
    warn_if_tty(sys.stdin, "events")

    out_delim = delimiter if delimiter is not None else " "
    aligner = StreamingAligner(out_delim) if align_cols else None

    # Skip header lines
    if header is not None:
        for _ in range(header):
            line = sys.stdin.readline()
            if not line:
                break

    # Output header (only if requested)
    if print_header:
        if merlin:
            header_fields = ["date", "start", "stop", "TYPE", "DUR", "NUMPTS"]
        else:
            header_fields = ["state", "start", "stop", "duration", "count"]
        if aligner is not None:
            aligner.write_row(header_fields)
        else:
            sys.stdout.write(out_delim.join(header_fields) + "\n")

    # Detect datetime vs numeric from first data line
    first_line = None
    is_datetime = False
    for line in sys.stdin:
        stripped = line.rstrip("\r\n")
        if not stripped:
            continue
        first_line = line
        fields = split_fields(line, delimiter)
        num_fields = len(fields)
        time_idx = _resolve_col_idx(time_col, num_fields)
        if time_idx < num_fields:
            is_datetime = _try_parse_datetime(fields[time_idx]) is not None
        break

    if first_line is None:
        raise SystemExit(0)

    # Parse gap threshold (duration string or bare seconds)
    gap_threshold: float = 0
    if gap is not None:
        try:
            gap_threshold = parse_duration(gap)
        except ValueError as e:
            err_console.print(f"Error: {e}", style="red")
            raise SystemExit(2)

    emitter = EventEmitter(
        min_samples=max(1, min_samples),
        gap_threshold=gap_threshold,
        is_datetime=is_datetime,
        out_delim=out_delim,
        aligner=aligner,
        merlin=merlin,
    )

    prev_time_val: float | None = None
    row_num = 0

    def _process_line(line: str) -> None:
        nonlocal prev_time_val, row_num
        row_num += 1
        stripped = line.rstrip("\r\n")
        if not stripped:
            return

        fields = split_fields(line, delimiter)
        num_fields = len(fields)
        time_idx = _resolve_col_idx(time_col, num_fields)
        state_idx = _resolve_col_idx(state_col, num_fields)

        if time_idx >= num_fields or state_idx >= num_fields:
            if no_fail:
                return
            err_console.print(
                f"Error: row {row_num} has {num_fields} fields, need columns {time_col} and {state_col}",
                style="red",
            )
            raise SystemExit(2)

        time_str = fields[time_idx]
        state = fields[state_idx]

        # Parse time value
        if is_datetime:
            dt = _try_parse_datetime(time_str)
            if dt is None:
                if no_fail:
                    return
                err_console.print(
                    f"Error: cannot parse '{time_str}' as datetime on row {row_num}",
                    style="red",
                )
                raise SystemExit(2)
            time_val = dt.timestamp()
        else:
            fval = _try_parse_float(time_str)
            if fval is None:
                if no_fail:
                    return
                err_console.print(
                    f"Error: cannot parse '{time_str}' as number on row {row_num}",
                    style="red",
                )
                raise SystemExit(2)
            time_val = fval

        # Check monotonicity
        if prev_time_val is not None and time_val < prev_time_val:
            if no_fail:
                return
            err_console.print(
                f"Error: non-monotonic time at row {row_num} (use sort -k1 to sort input)",
                style="red",
            )
            raise SystemExit(2)
        prev_time_val = time_val

        emitter.process_row(state, time_str, time_val)

    # Process first line
    _process_line(first_line)

    # Process remaining lines
    for line in sys.stdin:
        _process_line(line)

    emitter.flush()
    raise SystemExit(0)
