from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SeriesSpec:
    column: int
    name: str | None = None
    color: str | None = None
    marker: str | None = None


@dataclass
class SubplotSpec:
    series: list[SeriesSpec] = field(default_factory=list)
    ylabel: str | None = None
    ylim: tuple[float, float] | None = None
    hlines: list[float] = field(default_factory=list)
    hregions: list[tuple[float, float]] = field(default_factory=list)


@dataclass
class PlotSpec:
    subplots: list[SubplotSpec] = field(default_factory=list)
    title: str | None = None
    subtitle: str | None = None
    xlabel: str | None = None
    xlim: tuple[float, float] | None = None
    vlines: list[str] = field(default_factory=list)
    mark: str | None = None


# Option key aliases: short -> long
_SERIES_KEYS = {"n": "name", "c": "color", "m": "marker", "name": "name", "color": "color", "marker": "marker"}
_SUBPLOT_KEYS = {
    "y": "ylabel", "ylabel": "ylabel",
    "ylim": "ylim",
    "hline": "hline", "hl": "hline",
    "hr": "hr",
}
_FIGURE_KEYS = {
    "t": "title", "title": "title",
    "s": "subtitle", "subtitle": "subtitle",
    "x": "xlabel", "xlabel": "xlabel",
    "xlim": "xlim",
    "vl": "vline", "vline": "vline",
    "mark": "mark",
}


def _is_column_spec(arg: str) -> bool:
    """Check if arg is a column number (positive or negative int)."""
    try:
        int(arg)
        return True
    except ValueError:
        return False


def parse_plot_args(args: list[str]) -> PlotSpec:
    """Parse flat positional arg list into a structured PlotSpec.

    Args are processed left-to-right:
    - Integer -> new series on current subplot
    - '/' -> start a new subplot
    - key=value -> apply to current series, subplot, or figure
    """
    spec = PlotSpec()
    current_subplot = SubplotSpec()
    spec.subplots.append(current_subplot)
    current_series: SeriesSpec | None = None

    for arg in args:
        if arg == "/":
            current_subplot = SubplotSpec()
            spec.subplots.append(current_subplot)
            current_series = None
            continue

        if _is_column_spec(arg):
            current_series = SeriesSpec(column=int(arg))
            current_subplot.series.append(current_series)
            continue

        if "=" not in arg:
            raise ValueError(f"Unexpected argument: '{arg}' (expected column number, '/', or key=value)")

        key, value = arg.split("=", 1)

        # Figure-level options
        if key in _FIGURE_KEYS:
            resolved = _FIGURE_KEYS[key]
            if resolved == "title":
                spec.title = value
            elif resolved == "subtitle":
                spec.subtitle = value
            elif resolved == "xlabel":
                spec.xlabel = value
            elif resolved == "xlim":
                parts = value.split(":")
                if len(parts) != 2:
                    raise ValueError(f"Invalid xlim '{value}' (expected MIN:MAX)")
                spec.xlim = (float(parts[0]), float(parts[1]))
            elif resolved == "vline":
                spec.vlines.append(value)
            elif resolved == "mark":
                spec.mark = value
            continue

        # Subplot-level options
        if key in _SUBPLOT_KEYS:
            resolved = _SUBPLOT_KEYS[key]
            if resolved == "ylabel":
                current_subplot.ylabel = value
            elif resolved == "ylim":
                parts = value.split(":")
                if len(parts) != 2:
                    raise ValueError(f"Invalid ylim '{value}' (expected MIN:MAX)")
                current_subplot.ylim = (float(parts[0]), float(parts[1]))
            elif resolved == "hline":
                current_subplot.hlines.append(float(value))
            elif resolved == "hr":
                parts = value.split(":")
                if len(parts) != 2:
                    raise ValueError(f"Invalid horizontal region '{value}' (expected Y1:Y2)")
                current_subplot.hregions.append((float(parts[0]), float(parts[1])))
            continue

        # Series-level options
        if key in _SERIES_KEYS:
            if current_series is None:
                raise ValueError(f"Series option '{arg}' specified before any column")
            resolved = _SERIES_KEYS[key]
            setattr(current_series, resolved, value)
            continue

        raise ValueError(f"Unknown option key: '{key}'")

    # Validate at least one series exists
    all_series = [s for sub in spec.subplots for s in sub.series]
    if not all_series:
        raise ValueError("No columns specified to plot")

    return spec
