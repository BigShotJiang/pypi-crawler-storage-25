from __future__ import annotations

import numpy as np
from numpy.typing import NDArray


def lttb(
    x: NDArray[np.float64], y: NDArray[np.float64], n_out: int
) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
    """Downsample (x, y) to n_out points using Largest Triangle Three Buckets.

    Preserves visual shape of the data while reducing point count.
    Always keeps the first and last points.
    """
    n = len(x)
    if n_out >= n or n_out < 3:
        return x.copy(), y.copy()

    # Indices of selected points
    selected = np.empty(n_out, dtype=np.intp)
    selected[0] = 0
    selected[-1] = n - 1

    bucket_size = (n - 2) / (n_out - 2)
    prev_idx = 0

    for i in range(n_out - 2):
        # Current bucket range
        bucket_start = int((i + 1) * bucket_size) + 1
        bucket_end = min(int((i + 2) * bucket_size) + 1, n)

        # Next bucket range (for computing average)
        next_start = int((i + 2) * bucket_size) + 1
        next_end = min(int((i + 3) * bucket_size) + 1, n)

        # Average of next bucket
        if next_start < n:
            avg_x = np.mean(x[next_start:next_end])
            avg_y = np.mean(y[next_start:next_end])
        else:
            avg_x = x[-1]
            avg_y = y[-1]

        # Vectorized triangle area for all points in current bucket
        bx = x[bucket_start:bucket_end]
        by = y[bucket_start:bucket_end]
        areas = np.abs(
            (x[prev_idx] - avg_x) * (by - y[prev_idx])
            - (x[prev_idx] - bx) * (avg_y - y[prev_idx])
        )

        best_idx = bucket_start + np.argmax(areas)
        selected[i + 1] = best_idx
        prev_idx = best_idx

    return x[selected], y[selected]
