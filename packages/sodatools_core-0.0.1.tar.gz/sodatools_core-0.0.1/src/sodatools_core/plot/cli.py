from __future__ import annotations

import math
import sys
from datetime import datetime
from typing import Annotated, Optional

import numpy as np
import polars as pl
import typer
from numpy.typing import NDArray
from rich.console import Console

from sodatools_core.common.cli_helpers import (
    HELP_DELIMITER_INPUT,
    HELP_EXAMPLE,
    HELP_NO_FAIL,
    eager_print_callback,
)
from sodatools_core.common.dataframe import read_dataframe
from sodatools_core.common.parsing import parse_iso8601
from sodatools_core.common.reader import ReaderConfig, warn_if_tty
from sodatools_core.plot.lttb import lttb
from sodatools_core.plot.parser import SubplotSpec, parse_plot_args

err_console = Console(stderr=True)

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data weather | soda plot -H 1 2
  soda sample-data weather | soda plot -H 1 2 c=red / 3 c=blue
  soda sample-data weather | soda plot -H 1 2 -t "Temperature" --lttb 10
  soda sample-data weather | soda plot -H 1 2 --save out.png
"""

_DEFAULT_NULLS = ["?"]

_SYNTAX = """\
[bold]Positional argument syntax:[/]

  Arguments are column numbers, options (key=value), and subplot separators.

[bold]Column specs:[/]
  [blue]2[/]           plot column 2 as a y-axis series
  [blue]2 3[/]         two series on the same subplot
  [blue]2 / 3[/]       two separate subplots (/ starts a new subplot)

[bold]Per-series options[/] (apply to the preceding column):
  [blue]n=[/]NAME      series label in legend
  [blue]c=[/]COLOR     color (name or hex)
  [blue]m=[/]MARKER    marker style (o . , v ^ s D x + * h)

[bold]Per-subplot options[/] (apply to the current subplot):
  [blue]y=[/]LABEL     y-axis label
  [blue]ylim=[/]MIN:MAX  y-axis limits
  [blue]hline=[/]Y / [blue]hl=[/]Y  horizontal line at Y value
  [blue]hr=[/]Y1:Y2    horizontal shaded region from Y1 to Y2

[bold]Figure-level options[/] (positional or CLI flags):
  [blue]t=[/]TEXT / [blue]--title[/] / [blue]-t[/]       figure title
  [blue]s=[/]TEXT / [blue]--subtitle[/] / [blue]-s[/]     figure subtitle
  [blue]x=[/]LABEL / [blue]xlabel=[/]LABEL   x-axis label
  [blue]xlim=[/]MIN:MAX              x-axis limits
  [blue]vl=[/]X / [blue]vline=[/]X / [blue]--vline[/]  vertical line at X (repeatable)
  [blue]mark=[/]TEXT / [blue]--mark[/]       text in top-left and bottom-right corners

[bold]Examples:[/]
  soda plot 2                            basic scatter (col 1 = x, col 2 = y)
  soda plot 2 c=red m=o 3 c=blue m=^   colored series with markers
  soda plot 2 / 3                        two separate subplots
  soda plot 2 n=Temp c=red / 3 n=Hum    labeled series on separate subplots
  soda plot 2 hline=50 hr=10:100 vl=50  with annotations
  soda plot 2 ylim=0:100 x=Time         axis labels and limits
  soda plot 2 3 t=My_Plot mark=v1.2     title and corner mark via grammar
  soda plot -H 1 -t "My Plot" 2 3       title via CLI flag (allows spaces)
"""
_SCREEN_FRACTION = 0.8
_FALLBACK_FIGSIZE = (12.0, 7.0)


def _default_figsize(dpi: float) -> tuple[float, float]:
    """Compute figure size as 80% of primary monitor width, height from 16:9 ratio."""
    try:
        import tkinter as tk

        root = tk.Tk()
        screen_w = root.winfo_screenwidth()
        root.destroy()
    except Exception:
        return _FALLBACK_FIGSIZE

    width_px = screen_w * _SCREEN_FRACTION
    height_px = width_px * 9 / 16
    return (width_px / dpi, height_px / dpi)


def _resolve_column(col: int, num_fields: int) -> str:
    """Resolve a column reference (1-indexed or negative) to a column name."""
    if col > 0:
        idx = col - 1
    else:
        idx = num_fields + col
    return str(idx)


def _resolve_col_name(col: int, col_names: list[str]) -> str:
    """Resolve a 1-indexed (or negative) column ref to a column name."""
    if col > 0:
        idx = col - 1
    else:
        idx = len(col_names) + col
    if 0 <= idx < len(col_names):
        return col_names[idx]
    raise ValueError(f"Column {col} out of range (have {len(col_names)} columns)")


def plot(
    args: Annotated[
        Optional[list[str]],
        typer.Argument(help="Column specs and options, e.g. '2 n=Temp c=red / 3'"),
    ] = None,
    syntax: Annotated[
        bool,
        typer.Option(
            "--syntax",
            callback=eager_print_callback(_SYNTAX),
            is_eager=True,
            help="Show argument syntax reference and exit",
        ),
    ] = False,
    example: Annotated[
        bool,
        typer.Option(
            "--example",
            callback=eager_print_callback(_EXAMPLES),
            is_eager=True,
            help=HELP_EXAMPLE,
        ),
    ] = False,
    x: Annotated[
        int,
        typer.Option("--x", "-x", help="X-axis column (default: 1)"),
    ] = 1,
    delimiter: Annotated[
        Optional[str],
        typer.Option(
            "--delimiter", "-d", help=HELP_DELIMITER_INPUT
        ),
    ] = None,
    header: Annotated[
        Optional[int],
        typer.Option(
            "--header", "-H", help="First N lines are headers (use for labels)"
        ),
    ] = None,
    downsample: Annotated[
        Optional[int],
        typer.Option(
            "--lttb",
            help="Downsample by approx 1/N via LTTB (e.g. --lttb 20 keeps ~5%)",
        ),
    ] = None,
    cols: Annotated[
        int,
        typer.Option("--cols", help="Subplot grid columns (default: 1 = stacked)"),
    ] = 1,
    no_gaps: Annotated[
        bool,
        typer.Option(
            "--no-gaps", help="Remove time gaps (plot by row index with time labels)"
        ),
    ] = False,
    no_fail: Annotated[
        bool,
        typer.Option("--no-fail", help=HELP_NO_FAIL),
    ] = False,
    title: Annotated[
        Optional[str],
        typer.Option("--title", "-t", help="Figure title"),
    ] = None,
    subtitle: Annotated[
        Optional[str],
        typer.Option("--subtitle", "-s", help="Figure subtitle"),
    ] = None,
    vline: Annotated[
        Optional[list[str]],
        typer.Option(
            "--vline", help="Vertical line at X value (repeatable, number or datetime)"
        ),
    ] = None,
    mark_text: Annotated[
        Optional[str],
        typer.Option(
            "--mark", help="Text in top-left and bottom-right corners of the figure"
        ),
    ] = None,
    save: Annotated[
        Optional[list[str]],
        typer.Option(
            "--save",
            help="Save plot to file. .pkl saves interactive figure (for --load), other extensions (.png, .svg, .pdf, .jpg) save image. Repeatable.",
        ),
    ] = None,
    load: Annotated[
        Optional[str],
        typer.Option(
            "--load", help="Load a previously saved pickle figure and show it"
        ),
    ] = None,
    null: Annotated[
        Optional[list[str]],
        typer.Option("--null", help="Null sentinel values (repeatable, default: '?')"),
    ] = None,
) -> None:
    """Plot columnar data from stdin as interactive scatter plots."""
    if load:
        _load_figure(load)
        raise SystemExit(0)

    if not args:
        err_console.print(
            "Error: no columns specified (use --syntax for help)", style="red"
        )
        raise SystemExit(2)

    warn_if_tty(sys.stdin, "plot")

    # Parse positional args
    try:
        plot_spec = parse_plot_args(args)
    except ValueError as e:
        err_console.print(f"Error: {e}", style="red")
        raise SystemExit(2)

    # Merge grammar-level figure options with CLI flags (CLI flags win)
    if not title and plot_spec.title:
        title = plot_spec.title
    if not subtitle and plot_spec.subtitle:
        subtitle = plot_spec.subtitle
    if plot_spec.vlines:
        vline = list(vline or []) + plot_spec.vlines
    if not mark_text and plot_spec.mark:
        mark_text = plot_spec.mark

    null_sentinels = set(null if null is not None else _DEFAULT_NULLS)
    config = ReaderConfig(delimiter=delimiter, null_sentinels=null_sentinels)

    df, col_types = read_dataframe(sys.stdin, config, header_lines=header)

    if df.is_empty():
        err_console.print("Error: no data to plot", style="red")
        raise SystemExit(2)

    col_names = df.columns
    header_names = col_names  # used for default series labels

    # Resolve x column
    try:
        x_col = _resolve_col_name(x, col_names)
    except ValueError as e:
        err_console.print(f"Error: {e}", style="red")
        raise SystemExit(2)

    x_type = col_types[x_col]
    is_datetime = x_type == "datetime"

    # Extract x values
    x_datetimes: list[datetime] = []
    if is_datetime:
        x_series = df[x_col].drop_nulls()
        x_datetimes = x_series.to_list()

    # Prepare x-axis data as ndarray
    gap_indices: list[int] = []
    tick_labels: list[datetime] | None = None

    if is_datetime and no_gaps:
        plot_x = np.arange(len(x_datetimes), dtype=np.float64)
        tick_labels = x_datetimes
        # Detect gaps: consecutive deltas >5x the median
        if len(x_datetimes) > 2:
            deltas = np.array(
                [
                    (x_datetimes[i + 1] - x_datetimes[i]).total_seconds()
                    for i in range(len(x_datetimes) - 1)
                ]
            )
            median_delta = float(np.median(deltas))
            if median_delta > 0:
                gap_indices = list(np.where(deltas > median_delta * 5)[0])
    elif is_datetime:
        import matplotlib.dates as mdates

        plot_x = np.array([mdates.date2num(dt) for dt in x_datetimes], dtype=np.float64)
    else:
        x_numeric = df[x_col].drop_nulls().cast(pl.Float64)
        plot_x = x_numeric.to_numpy()

    # Now do the plotting
    import matplotlib.pyplot as plt

    n_subplots = len(plot_spec.subplots)
    nrows = math.ceil(n_subplots / cols)
    ncols = min(cols, n_subplots)

    fig_w, fig_h = _default_figsize(plt.rcParams["figure.dpi"])

    fig, axes_array = plt.subplots(
        nrows,
        ncols,
        figsize=(fig_w, fig_h),
        sharex=True,
        squeeze=False,
    )

    # Flatten axes for easy iteration
    axes_flat = [axes_array[r][c] for r in range(nrows) for c in range(ncols)]

    # Hide unused subplots
    for i in range(n_subplots, len(axes_flat)):
        axes_flat[i].set_visible(False)

    for ax, subplot_spec in zip(axes_flat, plot_spec.subplots):
        _plot_subplot(
            ax,
            subplot_spec,
            plot_x,
            df,
            col_names,
            col_types,
            header_names,
            downsample,
            no_fail,
        )

    # Vertical lines (figure-level, drawn on all subplots)
    if vline:
        for vl_str in vline:
            vl_val = _resolve_vline(vl_str, is_datetime, no_gaps, x_datetimes, plot_x)
            if vl_val is not None:
                for ax in axes_flat[:n_subplots]:
                    ax.axvline(vl_val, color="gray", linestyle="--", alpha=0.7)

    # Gap markers in no-gaps mode
    for gi in gap_indices:
        for ax in axes_flat[:n_subplots]:
            ax.axvline(gi + 0.5, color="gray", linestyle="--", linewidth=1.0, alpha=0.7)

    # X-axis label and limits (figure-level, applied to bottom subplots)
    if plot_spec.xlabel:
        for ax in axes_flat[:n_subplots]:
            ax.set_xlabel(plot_spec.xlabel)
    if plot_spec.xlim:
        for ax in axes_flat[:n_subplots]:
            ax.set_xlim(plot_spec.xlim)

    # Title and subtitle
    if title:
        fig.suptitle(title, fontsize=14, fontweight="bold")
    if subtitle:
        fig.text(
            0.5,
            0.96 if title else 0.98,
            subtitle,
            ha="center",
            fontsize=10,
            style="italic",
        )

    # Mark text (top-left and bottom-right corners)
    if mark_text:
        fig.text(
            0.01, 0.99, mark_text,
            ha="left", va="top", fontsize=8, transform=fig.transFigure,
        )
        fig.text(
            0.99, 0.01, mark_text,
            ha="right", va="bottom", fontsize=8, transform=fig.transFigure,
        )

    # Format x-axis
    if is_datetime and no_gaps and tick_labels:
        _format_no_gaps_xaxis(axes_flat[:n_subplots], tick_labels)
    elif is_datetime:
        import matplotlib.dates as mdates

        for ax in axes_flat[:n_subplots]:
            ax.xaxis.set_major_locator(mdates.AutoDateLocator())
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d %H:%M"))
        fig.autofmt_xdate()

    plt.tight_layout()
    if save:
        for path in save:
            if path.endswith(".pkl"):
                import pickle

                with open(path, "wb") as f:
                    pickle.dump(fig, f)
                err_console.print(
                    f"Figure saved to {path} (load with --load)", style="dim"
                )
            else:
                fig.savefig(path, bbox_inches="tight")
                err_console.print(f"Saved to {path}", style="dim")
    else:
        plt.show()
    raise SystemExit(0)


def _load_figure(path: str) -> None:
    """Load a pickled matplotlib figure and show it interactively."""
    import pickle

    import matplotlib.pyplot as plt

    with open(path, "rb") as f:
        fig = pickle.load(f)

    # Re-attach to a canvas manager so plt.show() works
    dummy_fig = plt.figure()
    manager = dummy_fig.canvas.manager
    manager.canvas.figure = fig
    fig.set_canvas(manager.canvas)
    plt.close(dummy_fig)

    plt.show()


def _plot_subplot(
    ax: object,
    subplot_spec: SubplotSpec,
    plot_x: NDArray[np.float64],
    df: pl.DataFrame,
    col_names: list[str],
    col_types: dict[str, str],
    header_names: list[str],
    downsample: int | None,
    no_fail: bool,
) -> None:
    """Plot all series for a single subplot."""
    categorical_maps: dict[str, dict[str, int]] = {}  # col -> {value: y_pos}

    for series in subplot_spec.series:
        try:
            y_col = _resolve_col_name(series.column, col_names)
        except ValueError as e:
            if no_fail:
                continue
            err_console.print(f"Error: {e}", style="red")
            raise SystemExit(2)

        is_categorical = col_types.get(y_col) == "string"

        if is_categorical:
            # Categorical: map unique values to y-positions by order of first appearance
            raw_series = df[y_col]
            raw_vals = raw_series.to_list()

            # Build category map (order of first appearance)
            if y_col not in categorical_maps:
                cat_map: dict[str, int] = {}
                for v in raw_vals:
                    if v is not None and v not in cat_map:
                        cat_map[v] = len(cat_map)
                categorical_maps[y_col] = cat_map
            cat_map = categorical_maps[y_col]

            # Build parallel x/y arrays, skipping nulls
            x_cat: list[float] = []
            y_cat: list[float] = []
            for i, v in enumerate(raw_vals):
                if v is not None and i < len(plot_x):
                    x_cat.append(plot_x[i])
                    y_cat.append(float(cat_map[v]))

            x_for_series = np.array(x_cat)
            y_for_series = np.array(y_cat)
        else:
            # Numeric: extract y values as numpy (drop nulls)
            y_series = df[y_col].drop_nulls().cast(pl.Float64, strict=False).drop_nulls()
            y_vals = y_series.to_numpy()

            n = min(len(plot_x), len(y_vals))
            x_for_series = plot_x[:n]
            y_for_series = y_vals[:n]

        # LTTB downsampling (only for numeric — categorical needs all points)
        if not is_categorical and downsample is not None and downsample > 1:
            n_out = max(3, len(x_for_series) // downsample)
            if n_out < len(x_for_series):
                x_for_series, y_for_series = lttb(x_for_series, y_for_series, n_out)

        # Determine label
        label = series.name
        if label is None:
            try:
                col_name = _resolve_col_name(series.column, col_names)
                if not col_name.isdigit():
                    label = col_name
            except ValueError:
                pass

        # Plot
        scatter_kwargs: dict[str, object] = {"s": 4, "label": label}
        if series.color:
            scatter_kwargs["c"] = series.color
        if series.marker:
            scatter_kwargs["marker"] = series.marker
        if is_categorical:
            scatter_kwargs["s"] = 12  # larger markers for categorical

        ax.scatter(x_for_series, y_for_series, **scatter_kwargs)

    # Configure categorical y-axis
    for cat_map in categorical_maps.values():
        positions = list(cat_map.values())
        labels = list(cat_map.keys())
        ax.set_yticks(positions)
        ax.set_yticklabels(labels)
        ax.set_ylim(-0.5, max(positions) + 0.5)

    # Subplot options
    if subplot_spec.ylabel:
        ax.set_ylabel(subplot_spec.ylabel)

    # Show legend if any series has a label
    has_labels = any(s.name for s in subplot_spec.series)
    if not has_labels:
        for s in subplot_spec.series:
            try:
                cn = _resolve_col_name(s.column, col_names)
                if not cn.isdigit():
                    has_labels = True
                    break
            except ValueError:
                pass
    if has_labels:
        ax.legend(fontsize=8)

    # Y-axis limits
    if subplot_spec.ylim:
        ax.set_ylim(subplot_spec.ylim)

    # Horizontal lines
    for hl_val in subplot_spec.hlines:
        ax.axhline(hl_val, color="gray", linestyle="--", alpha=0.7)

    # Horizontal regions
    for y1, y2 in subplot_spec.hregions:
        ax.axhspan(y1, y2, alpha=0.15, color="blue")


def _resolve_vline(
    vl_str: str,
    is_datetime: bool,
    no_gaps: bool,
    x_datetimes: list[datetime],
    plot_x: NDArray[np.float64],
) -> float | None:
    """Resolve a vertical line value to a plot x coordinate."""
    if is_datetime:
        try:
            dt = parse_iso8601(vl_str)
        except (ValueError, IndexError):
            dt = None
        if dt is not None:
            if no_gaps:
                deltas = np.array(
                    [abs((xdt - dt).total_seconds()) for xdt in x_datetimes]
                )
                return float(np.argmin(deltas))
            else:
                import matplotlib.dates as mdates

                return mdates.date2num(dt)
    try:
        return float(vl_str)
    except ValueError:
        return None


def _format_no_gaps_xaxis(axes: list[object], timestamps: list[datetime]) -> None:
    """Format x-axis with datetime labels at row indices (no-gaps mode)."""
    import matplotlib.ticker as mticker

    n = len(timestamps)
    if n == 0:
        return

    n_ticks = min(10, n)
    step = max(1, n // n_ticks)
    tick_positions = list(range(0, n, step))
    tick_strs = [timestamps[i].strftime("%Y-%m-%d %H:%M") for i in tick_positions]

    for ax in axes:
        ax.xaxis.set_major_locator(mticker.FixedLocator(tick_positions))
        ax.xaxis.set_major_formatter(mticker.FixedFormatter(tick_strs))

    for ax in axes:
        for label in ax.get_xticklabels():
            label.set_rotation(30)
            label.set_ha("right")
