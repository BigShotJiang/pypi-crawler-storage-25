from __future__ import annotations

import math
import random
import sys
from datetime import datetime, timedelta
from typing import Annotated, Optional

import typer
from rich.console import Console

_DATASETS = {
    "weather": "10,000 rows of simulated weather station data (5-min intervals, 3 time gaps)",
    "small": "20 rows of simple columnar data (name, value, status)",
    "numeric": "100 rows of numeric data with timestamp (4 columns)",
    "tle": "3 ISS TLE sets",
    "noisy": "200 rows of sensor data with defects for all clean strategies",
    "times": "100 ISO 8601 timestamps (1-minute intervals)",
}


def _generate_weather(rows: int = 10000) -> None:
    random.seed(42)
    sys.stdout.write(
        f"{'timestamp':19s} {'temp':>5s} {'humidity':>8s} {'pressure':>8s} {'wind_speed':>10s} {'status':4s} {'error_code'}\n"
    )

    t = datetime(2024, 1, 1, 0, 0, 0)
    delta = timedelta(minutes=5)
    gaps = {2000: 77, 5500: 173, 8200: 53}

    for i in range(rows):
        if i in gaps:
            t += timedelta(hours=gaps[i])

        day_frac = (t - datetime(2024, 1, 1)).total_seconds() / 86400
        hour = t.hour + t.minute / 60.0
        daily = math.sin((hour - 6) / 24 * 2 * math.pi)
        seasonal = day_frac * 0.03

        temp = 20.0 + 8.0 * daily + seasonal + random.gauss(0, 0.5)
        humidity = 55.0 - 15.0 * daily - seasonal * 0.3 + random.gauss(0, 1.0)
        pressure = 1013.0 + 2.0 * math.sin(day_frac / 7 * 2 * math.pi) + random.gauss(0, 0.3)
        wind_speed = max(0, 5.0 + 4.0 * daily + random.gauss(0, 0.8))

        r = random.random()
        if temp > 27 or temp < 13:
            status, code = ("ERR", 2) if r < 0.15 else ("WARN", 1) if r < 0.4 else ("OK", 0)
        elif wind_speed > 8:
            status, code = ("WARN", 1) if r < 0.2 else ("OK", 0)
        else:
            status, code = ("WARN", 1) if r < 0.02 else ("OK", 0)

        sys.stdout.write(
            f"{t.isoformat()} {temp:5.1f} {humidity:8.1f} {pressure:8.1f} {wind_speed:10.1f} {status:4s} {code}\n"
        )
        t += delta


def _generate_small() -> None:
    _FMT = "{:<7s} {:>5s} {:4s}\n"
    sys.stdout.write(_FMT.format("name", "value", "status"))
    rows = [
        ("alice", "42", "OK"), ("bob", "17", "OK"), ("charlie", "95", "WARN"), ("diana", "8", "OK"),
        ("eve", "73", "ERR"), ("frank", "31", "OK"), ("grace", "88", "WARN"), ("hank", "12", "OK"),
        ("iris", "56", "OK"), ("jack", "99", "ERR"), ("kate", "24", "OK"), ("leo", "67", "OK"),
        ("mia", "3", "WARN"), ("noah", "81", "OK"), ("olivia", "45", "OK"), ("pete", "29", "OK"),
        ("quinn", "91", "ERR"), ("rose", "15", "OK"), ("sam", "60", "WARN"), ("tina", "38", "OK"),
    ]
    for name, value, status in rows:
        sys.stdout.write(_FMT.format(name, value, status))


def _generate_numeric() -> None:
    random.seed(42)
    t = datetime(2024, 3, 1, 10, 0, 0)
    delta = timedelta(seconds=10)
    gap_at = 50
    for i in range(1, 101):
        if i == gap_at:
            t += timedelta(seconds=60)
        a = i
        b = math.sin(i / 10) * 50 + 50 + random.gauss(0, 5)
        c = i * i / 100
        sys.stdout.write(f"{t.isoformat()} {a:3d} {b:6.1f} {c:6.1f}\n")
        t += delta


def _generate_noisy() -> None:
    """Sensor data with defects for all clean strategies.

    Columns: timestamp temp mode pressure received
    Defects by strategy:
      mad     — temp spikes at rows 15, 42, 95, 165
      run     — mode glitches (single-row IDLE/ERR) at rows 10, 30, 55, 88, 110, 132, 175, 190
      rate    — pressure jumps at rows 25, 105, 155 (>2.0/s vs normal ~0.01/s)
      range   — temp out of [-40, 60] at spike rows (999, -50, 500, -200)
      clock   — received timestamp too far from timestamp at rows 20, 60, 120, 180
    Time gaps at rows 70 (120s) and 140 (300s).
    """
    random.seed(99)

    t = datetime(2024, 6, 1, 8, 0, 0)
    delta = timedelta(seconds=5)
    gaps = {70: 120, 140: 300}  # row -> gap in seconds

    # mad: spike locations — wild temp values
    spikes = {15: 999.0, 42: -50.0, 95: 500.0, 165: -200.0}

    # run: glitch locations — single-row mode blips
    glitches = {10, 30, 55, 88, 110, 132, 175, 190}

    # rate: pressure jump locations — sudden jumps (normal pressure changes ~0.01/s)
    pressure_jumps = {25: 50.0, 105: -30.0, 155: 40.0}

    # clock: received timestamp too far from sample timestamp
    # Normal: received = timestamp + 0.5-2s.  Bad: received = timestamp + 30-90s.
    clock_bad = {20, 60, 120, 180}

    pressure = 1013.0

    for i in range(200):
        if i in gaps:
            t += timedelta(seconds=gaps[i])

        # Base temp: slow sine wave with noise
        base_temp = 22.0 + 5.0 * math.sin(i / 30.0) + random.gauss(0, 0.3)
        temp = spikes[i] if i in spikes else base_temp

        # Mode: alternates between HEAT and COOL in ~40-row runs
        cycle = (i // 40) % 2
        mode = "HEAT" if cycle == 0 else "COOL"
        if i in glitches:
            mode = random.choice(["IDLE", "ERR"])

        # Pressure: smooth drift with injected jumps
        if i in pressure_jumps:
            pressure += pressure_jumps[i]
        else:
            pressure += 0.05 + random.gauss(0, 0.1)

        # Received timestamp: normally 0.5-2s after sample, sometimes way off
        if i in clock_bad:
            recv_offset = random.uniform(30, 90)
        else:
            recv_offset = random.uniform(0.5, 2.0)
        received = t + timedelta(seconds=recv_offset)

        sys.stdout.write(
            f"{t.isoformat()} {temp:7.1f} {mode:4s} {pressure:7.1f} {received.isoformat()}\n"
        )
        t += delta


def _generate_tle() -> None:
    sys.stdout.write("""\
ISS (ZARYA)
1 25544U 98067A   24015.50000000  .00016717  00000-0  10270-3 0  9993
2 25544  51.6416 247.4627 0006703  130.5360 229.6380 15.50110000434218
ISS (ZARYA)
1 25544U 98067A   24016.50000000  .00016800  00000-0  10310-3 0  9994
2 25544  51.6415 247.0915 0006710  131.2100 228.9600 15.50120000434374
ISS (ZARYA)
1 25544U 98067A   24017.50000000  .00016900  00000-0  10350-3 0  9995
2 25544  51.6414 246.7203 0006720  131.8840 228.2820 15.50130000434530
""")


def _generate_times() -> None:
    t = datetime(2024, 1, 15, 12, 0, 0)
    delta = timedelta(minutes=1)
    for _ in range(100):
        sys.stdout.write(t.isoformat() + "\n")
        t += delta


_GENERATORS = {
    "weather": _generate_weather,
    "small": _generate_small,
    "numeric": _generate_numeric,
    "noisy": _generate_noisy,
    "tle": _generate_tle,
    "times": _generate_times,
}


def sampledata(
    dataset: Annotated[
        Optional[str],
        typer.Argument(help="Dataset name (see --list)"),
    ] = None,
    list_datasets: Annotated[
        bool,
        typer.Option("--list", help="List available datasets"),
    ] = False,
) -> None:
    """Print sample data to stdout."""
    if list_datasets or dataset is None:
        console = Console()
        console.print("[bold]Available sample datasets:[/]")
        for name, desc in _DATASETS.items():
            console.print(f"  [blue]{name:12s}[/]  {desc}")
        console.print()
        console.print("[dim]Usage: soda sample-data <name> | soda <command>[/]")
        raise SystemExit(0)

    if dataset not in _GENERATORS:
        Console(stderr=True).print(f"Error: unknown dataset '{dataset}' (use --list)", style="red")
        raise SystemExit(2)

    _GENERATORS[dataset]()
    raise SystemExit(0)
