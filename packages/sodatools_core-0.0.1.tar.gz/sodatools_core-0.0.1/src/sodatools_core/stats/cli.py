from __future__ import annotations

import sys
from datetime import timedelta
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.table import Table

from sodatools_core.common.cli_helpers import (
    HELP_DELIMITER_INPUT,
    HELP_EXAMPLE,
    HELP_NO_COLOR,
    HELP_NO_FAIL,
    eager_print_callback,
)
from sodatools_core.common.dataframe import read_dataframe
from sodatools_core.common.reader import ReaderConfig, warn_if_tty
from sodatools_core.stats.analyze import (
    DatetimeStats,
    NumericStats,
    StringStats,
    analyze_datetime,
    analyze_numeric,
    analyze_string,
)

err_console = Console(stderr=True)

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data weather | soda stats -H 1
  soda sample-data weather | soda stats -H 1 --no-shape --no-mixing
  soda sample-data numeric | soda stats
"""

_DEFAULT_NULLS = ["?"]


def _format_timedelta(td: timedelta | None) -> str:
    if td is None:
        return "-"
    total_secs = td.total_seconds()
    if total_secs < 60:
        return f"{total_secs:.0f}s"
    if total_secs < 3600:
        return f"{total_secs / 60:.0f}m"
    if total_secs < 86400:
        return f"{total_secs / 3600:.1f}h"
    return f"{total_secs / 86400:.1f}d"


def _fmt(val: float | int | None, precision: int = 2) -> str:
    if val is None:
        return "-"
    if isinstance(val, int):
        return str(val)
    if abs(val) >= 1000:
        return f"{val:.1f}"
    if abs(val) >= 1:
        return f"{val:.{precision}f}"
    if val == 0:
        return "0"
    return f"{val:.{precision}g}"


def _runs_label(stats: NumericStats) -> str:
    if stats.runs is None or stats.expected_runs is None:
        return "-"
    ratio = stats.runs / stats.expected_runs if stats.expected_runs > 0 else 1.0
    if ratio < 0.8:
        return f"{stats.runs} (low)"
    return f"{stats.runs} (OK)"


def stats(
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER_INPUT),
    ] = None,
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help="First N lines are headers (use for column names)"),
    ] = None,
    null: Annotated[
        Optional[list[str]],
        typer.Option("--null", help="Null sentinel values (repeatable, default: '?')"),
    ] = None,
    no_fail: Annotated[
        bool,
        typer.Option("--no-fail", help=HELP_NO_FAIL),
    ] = False,
    no_color: Annotated[
        bool,
        typer.Option("--no-color", help=HELP_NO_COLOR),
    ] = False,
    summary: Annotated[
        bool,
        typer.Option("--summary/--no-summary", help="Show summary stats (Mean, Std, Min, P25, P75, Max)"),
    ] = True,
    trend: Annotated[
        bool,
        typer.Option("--trend/--no-trend", help="Show trend stats (Trend, Period)"),
    ] = True,
    outliers: Annotated[
        bool,
        typer.Option("--outliers/--no-outliers", help="Show outlier count"),
    ] = True,
    shape: Annotated[
        bool,
        typer.Option("--shape/--no-shape", help="Show shape stats (Kurt, BC, Modes)"),
    ] = True,
    mixing: Annotated[
        bool,
        typer.Option("--mixing/--no-mixing", help="Show mixing stats (Runs test)"),
    ] = True,
    example: Annotated[
        bool,
        typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE),
    ] = False,
) -> None:
    """Compute and display column statistics from stdin."""
    warn_if_tty(sys.stdin, "stats")

    null_sentinels = set(null if null is not None else _DEFAULT_NULLS)
    config = ReaderConfig(delimiter=delimiter, null_sentinels=null_sentinels)

    df, col_types = read_dataframe(sys.stdin, config, header_lines=header)

    if df.is_empty():
        err_console.print("Error: no data", style="red")
        raise SystemExit(2)

    ncols = len(df.columns)
    nrows = len(df)

    # Analyze columns by type
    datetime_stats: list[DatetimeStats] = []
    numeric_stats: list[NumericStats] = []
    string_stats: list[StringStats] = []

    for col in df.columns:
        dtype = col_types[col]
        if dtype == "datetime":
            datetime_stats.append(analyze_datetime(df[col]))
        elif dtype in ("int", "float"):
            numeric_stats.append(analyze_numeric(df[col]))
        else:
            string_stats.append(analyze_string(df[col]))

    # Output
    out = Console(no_color=no_color, width=300)
    n_numeric = len(numeric_stats)
    n_datetime = len(datetime_stats)
    out.print(f"{nrows} rows x {ncols} cols ({n_numeric} numeric, {n_datetime} datetime)")
    out.print()

    # Datetime table
    if datetime_stats:
        dt_table = Table(title="Datetime", title_style="bold", show_lines=False)
        dt_table.add_column("Column", style="bold")
        dt_table.add_column("Nulls", justify="right")
        dt_table.add_column("Range")
        dt_table.add_column("Span")
        dt_table.add_column("Rate")
        dt_table.add_column("Gaps")

        for s in datetime_stats:
            min_str = s.min_val.isoformat() if s.min_val else "-"
            max_str = s.max_val.isoformat() if s.max_val else "-"
            range_str = f"{min_str[:10]}..{max_str[:10]}"
            gap_str = f"{s.gap_count} (max {_format_timedelta(s.max_gap)})" if s.gap_count > 0 else "0"

            dt_table.add_row(
                s.name, str(s.nulls), range_str,
                _format_timedelta(s.span),
                _format_timedelta(s.median_interval),
                gap_str,
            )
        out.print(dt_table)
        out.print()

    # Numeric table
    if numeric_stats:
        num_table = Table(title="Numeric", title_style="bold", show_lines=False, expand=False)
        num_table.add_column("Column", style="bold", no_wrap=True)
        num_table.add_column("Nulls", justify="right", no_wrap=True)

        if summary:
            for label in ("Mean", "Std", "Min", "P25", "P75", "Max"):
                num_table.add_column(label, justify="right", no_wrap=True)
        if trend:
            num_table.add_column("Trend", justify="right", no_wrap=True)
            num_table.add_column("Period", justify="right", no_wrap=True)
        if outliers:
            num_table.add_column("Outliers", justify="right", no_wrap=True)
        if shape:
            num_table.add_column("Kurt", justify="right", no_wrap=True)
            num_table.add_column("BC", justify="right", no_wrap=True)
            num_table.add_column("Modes", justify="right", no_wrap=True)
        if mixing:
            num_table.add_column("Runs", justify="right", no_wrap=True)

        for s in numeric_stats:
            row_vals: list[str] = [s.name, str(s.nulls)]

            if summary:
                row_vals.extend([
                    _fmt(s.mean), _fmt(s.std), _fmt(s.min_val),
                    _fmt(s.p25), _fmt(s.p75), _fmt(s.max_val),
                ])
            if trend:
                trend_str = f"{s.trend:+.3f}" if s.trend is not None else "-"
                period_str = str(s.period) if s.period is not None else "-"
                row_vals.extend([trend_str, period_str])
            if outliers:
                row_vals.append(str(s.outlier_count))
            if shape:
                bc_str = _fmt(s.bimodality_coeff)
                if s.bimodality_coeff is not None and s.bimodality_coeff > 0.555:
                    bc_str = f"[bold yellow]{bc_str}[/]"
                row_vals.extend([
                    _fmt(s.kurtosis),
                    bc_str,
                    str(s.mode_count) if s.mode_count is not None else "-",
                ])
            if mixing:
                runs_str = _runs_label(s)
                if s.runs is not None and s.expected_runs is not None:
                    ratio = s.runs / s.expected_runs if s.expected_runs > 0 else 1.0
                    if ratio < 0.8:
                        runs_str = f"[bold yellow]{runs_str}[/]"
                row_vals.append(runs_str)

            num_table.add_row(*row_vals)

        out.print(num_table)
        out.print()

    # String table
    if string_stats:
        str_table = Table(title="String", title_style="bold", show_lines=False)
        str_table.add_column("Column", style="bold")
        str_table.add_column("Nulls", justify="right")
        str_table.add_column("Unique", justify="right")
        str_table.add_column("Top values")

        for s in string_stats:
            top_str = " ".join(f"{v}({c})" for v, c in s.top_values)
            str_table.add_row(s.name, str(s.nulls), str(s.unique), top_str)

        out.print(str_table)

    raise SystemExit(0)
