from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta

import numpy as np
import polars as pl
from numpy.typing import NDArray


# --- Stat results ---


@dataclass
class DatetimeStats:
    name: str
    nulls: int
    min_val: datetime | None
    max_val: datetime | None
    span: timedelta | None
    median_interval: timedelta | None
    gap_count: int = 0
    max_gap: timedelta | None = None


@dataclass
class NumericStats:
    name: str
    nulls: int
    mean: float | None = None
    std: float | None = None
    min_val: float | None = None
    max_val: float | None = None
    p25: float | None = None
    p75: float | None = None
    # Trend group
    trend: float | None = None
    period: int | None = None
    # Outlier group
    outlier_count: int = 0
    # Shape group
    kurtosis: float | None = None
    bimodality_coeff: float | None = None
    mode_count: int | None = None
    # Mixing group
    runs: int | None = None
    expected_runs: float | None = None


@dataclass
class StringStats:
    name: str
    nulls: int
    unique: int = 0
    top_values: list[tuple[str, int]] = field(default_factory=list)


# --- Analysis functions ---


def analyze_datetime(series: pl.Series) -> DatetimeStats:
    """Compute stats for a datetime column."""
    name = series.name
    nulls = series.null_count()
    non_null = series.drop_nulls().sort()

    if len(non_null) == 0:
        return DatetimeStats(name=name, nulls=nulls, min_val=None, max_val=None,
                             span=None, median_interval=None)

    min_val = non_null[0]
    max_val = non_null[-1]
    span = max_val - min_val

    median_interval = None
    gap_count = 0
    max_gap = None

    if len(non_null) > 1:
        # Compute intervals
        diffs = []
        for i in range(len(non_null) - 1):
            diffs.append((non_null[i + 1] - non_null[i]).total_seconds())

        diffs_arr = np.array(diffs)
        median_secs = float(np.median(diffs_arr))
        median_interval = timedelta(seconds=median_secs)

        # Detect gaps (>5x median)
        if median_secs > 0:
            gap_mask = diffs_arr > median_secs * 5
            gap_count = int(np.sum(gap_mask))
            if gap_count > 0:
                max_gap = timedelta(seconds=float(np.max(diffs_arr[gap_mask])))

    return DatetimeStats(
        name=name, nulls=nulls, min_val=min_val, max_val=max_val,
        span=span, median_interval=median_interval,
        gap_count=gap_count, max_gap=max_gap,
    )


def analyze_numeric(series: pl.Series) -> NumericStats:
    """Compute stats for a numeric column."""
    name = series.name
    nulls = series.null_count()
    non_null = series.drop_nulls()

    if len(non_null) == 0:
        return NumericStats(name=name, nulls=nulls)

    # Basic stats via polars
    mean = float(non_null.mean())
    std = float(non_null.std())
    min_val = float(non_null.min())
    max_val = float(non_null.max())
    p25 = float(non_null.quantile(0.25))
    p75 = float(non_null.quantile(0.75))

    # Convert to numpy for advanced stats
    arr = non_null.cast(pl.Float64).to_numpy()

    # Outliers (>3σ)
    if std > 0:
        outlier_count = int(np.sum(np.abs(arr - mean) > 3 * std))
    else:
        outlier_count = 0

    # Trend (linear regression slope)
    trend = None
    if len(arr) > 1:
        coeffs = np.polyfit(np.arange(len(arr)), arr, 1)
        trend = float(coeffs[0])

    # Period detection (FFT-based autocorrelation)
    period = _detect_period(arr)

    # Kurtosis and bimodality coefficient
    kurtosis = None
    bimodality_coeff = None
    if len(arr) > 3 and std > 0:
        centered = arr - mean
        m2 = np.mean(centered ** 2)
        m3 = np.mean(centered ** 3)
        m4 = np.mean(centered ** 4)
        if m2 > 0:
            kurtosis = float(m4 / m2 ** 2)
            skewness = float(m3 / m2 ** 1.5)
            if kurtosis > 0:
                bimodality_coeff = float((skewness ** 2 + 1) / kurtosis)

    # Mode count (histogram peak detection)
    mode_count = _count_modes(arr)

    # Runs test
    runs, expected_runs = _runs_test(arr)

    return NumericStats(
        name=name, nulls=nulls, mean=mean, std=std,
        min_val=min_val, max_val=max_val, p25=p25, p75=p75,
        trend=trend, period=period, outlier_count=outlier_count,
        kurtosis=kurtosis, bimodality_coeff=bimodality_coeff,
        mode_count=mode_count, runs=runs, expected_runs=expected_runs,
    )


def analyze_string(series: pl.Series) -> StringStats:
    """Compute stats for a string column."""
    name = series.name
    nulls = series.null_count()
    non_null = series.drop_nulls()

    if len(non_null) == 0:
        return StringStats(name=name, nulls=nulls)

    unique = non_null.n_unique()

    # Top values
    vc = non_null.value_counts().sort("count", descending=True).head(5)
    top_values = [(str(row[0]), int(row[1])) for row in vc.iter_rows()]

    return StringStats(name=name, nulls=nulls, unique=unique, top_values=top_values)


# --- Helper algorithms ---


def _detect_period(arr: NDArray[np.float64]) -> int | None:
    """Detect dominant period via FFT-based autocorrelation."""
    n = len(arr)
    if n < 10:
        return None

    # Detrend (remove linear trend)
    x = np.arange(n, dtype=np.float64)
    coeffs = np.polyfit(x, arr, 1)
    detrended = arr - np.polyval(coeffs, x)

    # FFT-based autocorrelation
    padded_n = 2 * n
    fft = np.fft.rfft(detrended, n=padded_n)
    acf = np.fft.irfft(fft * np.conj(fft))[:n]

    if acf[0] == 0:
        return None
    acf = acf / acf[0]  # normalize

    # Find first significant peak after initial decay
    # Skip the first few lags (at least 2)
    min_lag = 2
    # Find where ACF first drops below 0.5 (end of initial decay)
    start_search = min_lag
    for i in range(min_lag, min(n // 2, len(acf))):
        if acf[i] < 0.5:
            start_search = i
            break

    # Find peak after that
    best_lag = None
    best_val = 0.1  # minimum threshold
    for i in range(start_search, min(n // 2, len(acf) - 1)):
        if acf[i] > acf[i - 1] and acf[i] > acf[i + 1] and acf[i] > best_val:
            best_val = acf[i]
            best_lag = i
            break  # first significant peak

    return best_lag


def _count_modes(arr: NDArray[np.float64]) -> int:
    """Count modes by finding peaks in histogram."""
    if len(arr) < 5:
        return 1

    counts, _ = np.histogram(arr, bins="auto")

    if len(counts) < 3:
        return 1

    # Find peaks: bins where count > both neighbors
    peaks = 0
    for i in range(1, len(counts) - 1):
        if counts[i] > counts[i - 1] and counts[i] > counts[i + 1]:
            peaks += 1

    # Edge cases: check first and last bins
    if len(counts) >= 2:
        if counts[0] > counts[1]:
            peaks += 1
        if counts[-1] > counts[-2]:
            peaks += 1

    return max(1, peaks)


def _runs_test(arr: NDArray[np.float64]) -> tuple[int | None, float | None]:
    """Count runs above/below median and expected runs."""
    n = len(arr)
    if n < 5:
        return None, None

    median = np.median(arr)
    above = arr > median

    runs = 1 + int(np.sum(above[1:] != above[:-1]))
    n1 = int(np.sum(above))
    n2 = int(np.sum(~above))

    if n1 + n2 == 0:
        return None, None

    expected = 1 + 2 * n1 * n2 / (n1 + n2)
    return runs, float(expected)
