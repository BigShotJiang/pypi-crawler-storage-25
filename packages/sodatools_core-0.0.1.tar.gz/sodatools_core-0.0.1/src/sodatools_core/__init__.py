from sodatools_core.app import app


def main() -> None:
    app()
