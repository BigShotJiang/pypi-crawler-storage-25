from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from lark import Lark, Transformer, v_args

_GRAMMAR_PATH = Path(__file__).parent / "grammar.lark"
_parser = Lark.open(str(_GRAMMAR_PATH), parser="lalr")

# Valid parameter keys per strategy
_VALID_PARAMS: dict[str, set[str]] = {
    "mad": {"window", "delta"},
    "run": {"min"},
    "rate": {"max", "min"},
    "range": {"min", "max"},
    "clock": {"ref", "after", "before", "min", "max"},
    "mono": {"dir", "delta", "wrap"},
}


@dataclass(frozen=True)
class FilterExpr:
    column: int  # 1-indexed (or negative)
    strategy: str  # "mad", "run", "rate", "range", "clock"
    params: dict[str, str] = field(default_factory=dict)  # raw key=value pairs

    def get_int(self, key: str, default: int) -> int:
        if key in self.params:
            return int(self.params[key])
        return default

    def get_float(self, key: str, default: float) -> float:
        if key in self.params:
            return float(self.params[key])
        return default

    def get_str(self, key: str, default: str | None = None) -> str | None:
        return self.params.get(key, default)

    def has(self, key: str) -> bool:
        return key in self.params


@v_args(inline=True)
class FilterExprTransformer(Transformer):
    def start(self, *exprs: FilterExpr) -> list[FilterExpr]:
        return list(exprs)

    def expr(self, col_token: str, strategy: str, *params: tuple[str, str]) -> FilterExpr:
        column = int(col_token)
        param_dict = dict(params)
        return FilterExpr(column=column, strategy=strategy, params=param_dict)

    def param(self, token: str) -> tuple[str, str]:
        key, _, value = str(token).partition("=")
        return (key, value)

    # Strategy rules
    def mad(self, *_: object) -> str:
        return "mad"

    def run(self, *_: object) -> str:
        return "run"

    def rate(self, *_: object) -> str:
        return "rate"

    def range(self, *_: object) -> str:
        return "range"

    def clock(self, *_: object) -> str:
        return "clock"

    def mono(self, *_: object) -> str:
        return "mono"

    def COL(self, token: str) -> str:
        return str(token)

    def PARAM(self, token: str) -> str:
        return str(token)


_transformer = FilterExprTransformer()


def parse_filter(expr_str: str) -> list[FilterExpr]:
    """Parse a filter expression string into a list of FilterExpr."""
    tree = _parser.parse(expr_str)
    return _transformer.transform(tree)


def validate_expr(expr: FilterExpr) -> str | None:
    """Validate a FilterExpr. Returns error message or None if valid."""
    valid = _VALID_PARAMS.get(expr.strategy)
    if valid is None:
        return f"unknown strategy '{expr.strategy}'"

    for key in expr.params:
        if key not in valid:
            return f"unknown param '{key}' for strategy '{expr.strategy}' (valid: {', '.join(sorted(valid))})"

    if expr.strategy == "mad":
        window = expr.get_int("window", 11)
        if window < 1 or window % 2 == 0:
            return "--window must be a positive odd integer"

    if expr.strategy == "run":
        min_run = expr.get_int("min", 3)
        if min_run < 1:
            return "min must be >= 1"

    if expr.strategy == "rate":
        if not expr.has("max") and not expr.has("min"):
            return "rate requires at least 'max' or 'min' param"

    if expr.strategy == "range":
        if not expr.has("min") and not expr.has("max"):
            return "range requires at least 'min' or 'max' param"

    if expr.strategy == "mono":
        dir_val = expr.get_str("dir", "inc")
        if dir_val not in ("inc", "up", "dec", "down"):
            return "mono dir must be 'inc' or 'dec' (aliases: up, down)"
        if expr.has("wrap") and not expr.has("delta"):
            return "mono wrap requires delta"

    if expr.strategy == "clock":
        has_ref = expr.has("ref")
        has_absolute = expr.has("after") or expr.has("before")
        has_delta = expr.has("min") or expr.has("max")
        if has_ref:
            if has_absolute:
                return "clock with 'ref' uses 'min'/'max' (durations), not 'after'/'before'"
            if not has_delta:
                return "clock with 'ref' requires at least 'min' or 'max' (duration)"
        else:
            if has_delta and not has_absolute:
                return "clock without 'ref' uses 'after'/'before' (timestamps), not 'min'/'max'"
            if not has_absolute:
                return "clock requires 'ref' (for delta mode) or 'after'/'before' (for absolute mode)"

    return None
