from __future__ import annotations

import statistics
import sys
from collections import deque
from datetime import datetime
from typing import Annotated, Optional

import typer
from lark.exceptions import LarkError
from rich.console import Console

from sodatools_core.common.align import StreamingAligner
from sodatools_core.common.cli_helpers import (
    HELP_ALIGN,
    HELP_DELIMITER,
    HELP_EXAMPLE,
    HELP_HEADER_PASSTHRU,
    HELP_NO_FAIL,
    HELP_SYNTAX,
    eager_print_callback,
)
from sodatools_core.common.parsing import parse_duration, parse_iso8601
from sodatools_core.common.reader import split_fields, warn_if_tty
from sodatools_core.filter.parser import FilterExpr, parse_filter, validate_expr

err_console = Console(stderr=True)

_SYNTAX = """\
[bold]Expression syntax:[/]  <col>:<strategy> \[key=value ...]

  Columns are 1-indexed. Negative indices count from the end.
  Multiple expressions are evaluated independently.

[bold]Strategies:[/]

  [blue]mad[/]     Numeric outlier detection (median absolute deviation)
          Params: window=11 (odd int), delta=3.0
          Bad if |value - median| > delta * MAD

  [blue]run[/]     Discrete transient detection (run-length filter)
          Params: min=3
          Bad if consecutive run length < min

  [blue]rate[/]    Excessive rate of change per unit time
          Params: max (required), min
          Bad if |rate| > max, or rate < min / rate > max
          Uses global --time column for rate computation

  [blue]range[/]   Valid numeric range
          Params: min, max (at least one required)
          Bad if value < min or value > max

  [blue]clock[/]   Time consistency checks
          Absolute: after, before (timestamps)
          Delta:    ref (column), min, max (durations: Ns/Nm/Nh/Nd)

  [blue]mono[/]    Monotonicity violations
          Params: dir=inc (inc/up or dec/down), delta, wrap
          Bad if value goes wrong direction
          delta: max allowed forward step (big jumps are bad)
          wrap: rollover point (requires delta)

[bold]Global options:[/]
  --time N    Time column (1-indexed, default: 1). Used by rate and --gap.
  --gap DUR   Max time gap (e.g. 60s, 5m). Resets mad windows, run tracking,
              and rate state when consecutive rows are separated by > gap.

[bold]Examples:[/]
  soda filter 2:mad                         # defaults
  soda filter 2:mad window=21 delta=5       # custom
  soda filter 3:run min=5                   # run-length filter
  soda filter 2:rate max=5                  # rate per second
  soda filter 2:range min=0 max=100         # inclusive bounds
  soda filter 1:clock after=2024-01-01T00:00:00
  soda filter 3:clock ref=4 min=0s max=60s  # inter-column delta
  soda filter 2:mad 5:run min=3             # multiple expressions
  soda filter 1:mono                         # timestamp must increase
  soda filter 3:mono wrap=256 delta=10      # 8-bit counter with rollover
  soda filter 2:mad --gap 60s --time 1      # reset window on time gaps
"""

_EXAMPLES = """\
[bold]Examples:[/]  (use soda sample-data noisy for test data)

  # mad: remove temp spikes
  soda sample-data noisy | soda filter 2:mad --gap 30s

  # run: remove mode glitches (transient IDLE/ERR)
  soda sample-data noisy | soda filter 3:run --gap 30s

  # rate: flag excessive pressure change per second
  soda sample-data noisy | soda filter 4:rate max=2 --gap 30s

  # range: clamp temp to physical bounds
  soda sample-data noisy | soda filter 2:range min=-40 max=60

  # clock: flag samples where received is >10s after timestamp
  soda sample-data noisy | soda filter 5:clock ref=1 max=10s

  # combine all strategies
  soda sample-data noisy | soda filter 2:mad 3:run 4:rate max=2 5:clock ref=1 max=10s --gap 30s

  # inspect removed rows
  soda sample-data noisy | soda filter 2:mad 3:run --gap 30s --invert --drop

  # drop bad rows instead of replacing with ?
  soda sample-data noisy | soda filter 2:mad 3:run --gap 30s --drop
"""


def _try_float(val: str) -> float | None:
    try:
        return float(val)
    except ValueError:
        return None


def _try_parse_time(val: str) -> float | None:
    """Parse a time value as either a float or ISO 8601 timestamp (seconds)."""
    f = _try_float(val)
    if f is not None:
        return f
    try:
        return parse_iso8601(val).timestamp()
    except (ValueError, IndexError, TypeError):
        return None


def _resolve_col_idx(col: int, num_fields: int) -> int:
    """Resolve 1-indexed (or negative) column to 0-indexed."""
    if col < 0:
        idx = num_fields + col
    else:
        idx = col - 1
    return idx


def _write_row(
    fields: list[str],
    out_delim: str,
    aligner: StreamingAligner | None,
) -> None:
    if aligner is not None:
        aligner.write_row(fields)
    else:
        sys.stdout.write(out_delim.join(fields) + "\n")


# ---------------------------------------------------------------------------
# Strategy: range (row-at-a-time)
# ---------------------------------------------------------------------------


def _eval_range(expr: FilterExpr, value_str: str) -> bool:
    """Return True if value is BAD (outside range)."""
    val = _try_float(value_str)
    if val is None:
        return True  # non-numeric is bad
    if expr.has("min") and val < expr.get_float("min", 0.0):
        return True
    if expr.has("max") and val > expr.get_float("max", 0.0):
        return True
    return False


# ---------------------------------------------------------------------------
# Strategy: rate (row-at-a-time, needs previous row)
# ---------------------------------------------------------------------------


class RateState:
    def __init__(self, expr: FilterExpr) -> None:
        self.expr = expr
        self.rate_max = expr.get_float("max", float("inf")) if expr.has("max") else None
        self.rate_min = (
            expr.get_float("min", float("-inf")) if expr.has("min") else None
        )
        self.symmetric = self.rate_max is not None and self.rate_min is None
        self.prev_val: float | None = None
        self.prev_time: float | None = None

    def reset(self) -> None:
        self.prev_val = None
        self.prev_time = None

    def eval(self, fields: list[str], col_idx: int, time_val: float | None) -> bool:
        """Return True if value is BAD (excessive rate)."""
        val = _try_float(fields[col_idx]) if col_idx < len(fields) else None

        if val is None or time_val is None:
            self.prev_val = val
            self.prev_time = time_val
            return True  # can't evaluate, mark as bad

        if self.prev_val is None or self.prev_time is None:
            self.prev_val = val
            self.prev_time = time_val
            return False  # first row, can't compute rate

        dt = time_val - self.prev_time
        if dt == 0:
            self.prev_val = val
            self.prev_time = time_val
            return False  # same timestamp, skip

        rate = (val - self.prev_val) / dt
        self.prev_val = val
        self.prev_time = time_val

        if self.symmetric:
            return abs(rate) > self.rate_max
        bad = False
        if self.rate_max is not None and rate > self.rate_max:
            bad = True
        if self.rate_min is not None and rate < self.rate_min:
            bad = True
        return bad


# ---------------------------------------------------------------------------
# Strategy: clock (row-at-a-time)
# ---------------------------------------------------------------------------


def _eval_clock_absolute(expr: FilterExpr, value_str: str) -> bool:
    """Return True if value is BAD (outside time bounds)."""
    try:
        t = parse_iso8601(value_str)
    except (ValueError, IndexError, TypeError):
        # Try as numeric timestamp
        f = _try_float(value_str)
        if f is None:
            return True
        t = datetime.fromtimestamp(f)

    if expr.has("after"):
        try:
            after = parse_iso8601(expr.get_str("after", ""))
            if t < after:
                return True
        except (ValueError, IndexError, TypeError):
            pass

    if expr.has("before"):
        try:
            before = parse_iso8601(expr.get_str("before", ""))
            if t > before:
                return True
        except (ValueError, IndexError, TypeError):
            pass

    return False


def _eval_clock_delta(
    expr: FilterExpr, fields: list[str], col_idx: int, num_fields: int
) -> bool:
    """Return True if value is BAD (inter-column delta out of bounds)."""
    ref_col = _resolve_col_idx(expr.get_int("ref", 1), num_fields)
    if col_idx >= num_fields or ref_col >= num_fields:
        return True

    t1 = _try_parse_time(fields[col_idx])
    t2 = _try_parse_time(fields[ref_col])
    if t1 is None or t2 is None:
        return True

    delta_secs = t1 - t2

    if expr.has("min"):
        min_secs = parse_duration(expr.get_str("min", "0s"))
        if delta_secs < min_secs:
            return True

    if expr.has("max"):
        max_secs = parse_duration(expr.get_str("max", "0s"))
        if delta_secs > max_secs:
            return True

    return False


# ---------------------------------------------------------------------------
# Strategy: mono (row-at-a-time, needs previous row)
# ---------------------------------------------------------------------------


class MonoState:
    def __init__(self, expr: FilterExpr) -> None:
        self.going_up = expr.get_str("dir", "inc") in ("inc", "up")
        self.delta = expr.get_float("delta", float("inf")) if expr.has("delta") else None
        self.wrap = expr.get_float("wrap", 0.0) if expr.has("wrap") else None
        self.prev_val: float | None = None

    def reset(self) -> None:
        self.prev_val = None

    def eval(self, value_str: str) -> bool:
        """Return True if value is BAD (violates monotonicity)."""
        val = _try_float(value_str)
        if val is None:
            return True

        if self.prev_val is None:
            self.prev_val = val
            return False

        prev = self.prev_val
        self.prev_val = val

        if self.going_up:
            step = val - prev
            if step >= 0:
                # Forward step — check delta if set
                if self.delta is not None and step > self.delta:
                    return True
                return False
            # Backward step — only valid if wrap explains it
            if self.wrap is not None and self.delta is not None:
                wrapped_step = val + self.wrap - prev
                if 0 <= wrapped_step <= self.delta:
                    return False
            return True
        else:
            step = prev - val
            if step >= 0:
                if self.delta is not None and step > self.delta:
                    return True
                return False
            # Went up instead of down — check wrap
            if self.wrap is not None and self.delta is not None:
                wrapped_step = prev + self.wrap - val
                if 0 <= wrapped_step <= self.delta:
                    return False
            return True


# ---------------------------------------------------------------------------
# Strategy: mad (sliding window)
# ---------------------------------------------------------------------------


def _should_keep_mad(value: float, window_vals: list[float], delta: float) -> bool:
    """Return True if value should be KEPT (is not an outlier)."""
    median = statistics.median(window_vals)
    deviations = [abs(v - median) for v in window_vals]
    mad = statistics.median(deviations)

    if mad == 0.0:
        return value == median

    return abs(value - median) <= delta * mad


# ---------------------------------------------------------------------------
# Main command
# ---------------------------------------------------------------------------


def filter_cmd(
    exprs: Annotated[
        Optional[list[str]],
        typer.Argument(help="Filter expressions, e.g. '2:mad' '3:run min=5'"),
    ] = None,
    syntax: Annotated[
        bool, typer.Option("--syntax", callback=eager_print_callback(_SYNTAX), is_eager=True, help=HELP_SYNTAX)
    ] = False,
    example: Annotated[
        bool, typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE)
    ] = False,
    drop: Annotated[
        bool,
        typer.Option(
            "--drop", "-x", help="Drop entire row instead of replacing bad values"
        ),
    ] = False,
    mark: Annotated[
        bool,
        typer.Option(
            "--mark", "-m", help="Highlight bad values in red instead of replacing"
        ),
    ] = False,
    null: Annotated[
        str, typer.Option("--null", help="Null sentinel for replacement (default: ?)")
    ] = "?",
    invert: Annotated[
        bool,
        typer.Option("--invert", help="Output bad rows/values instead of good ones"),
    ] = False,
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER),
    ] = None,
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help=HELP_HEADER_PASSTHRU),
    ] = None,
    time_col: Annotated[
        int,
        typer.Option(
            "--time",
            help="Time column (1-indexed, default: 1). Used by rate and --gap.",
        ),
    ] = 1,
    gap: Annotated[
        Optional[str],
        typer.Option(
            "--gap", help="Max time gap (e.g. 60s, 5m). Resets mad/run/rate on gaps."
        ),
    ] = None,
    no_fail: Annotated[
        bool,
        typer.Option("--no-fail", help=HELP_NO_FAIL),
    ] = False,
    align_cols: Annotated[
        bool,
        typer.Option("--align", help=HELP_ALIGN),
    ] = False,
) -> None:
    """Filter noisy or invalid rows based on column behavior."""
    if not exprs:
        err_console.print(
            "Error: no expressions provided (use --syntax for help)", style="red"
        )
        raise SystemExit(2)

    warn_if_tty(sys.stdin, "filter")

    # Parse all expressions
    expr_str = " ".join(exprs)
    try:
        parsed = parse_filter(expr_str)
    except LarkError as e:
        err_console.print(f"Error parsing expression: {e}", style="red")
        raise SystemExit(2)

    # Validate
    for expr in parsed:
        err = validate_expr(expr)
        if err:
            err_console.print(
                f"Error in '{expr.column}:{expr.strategy}': {err}", style="red"
            )
            raise SystemExit(2)

    # Parse gap threshold
    gap_threshold: float | None = None
    if gap is not None:
        try:
            gap_threshold = parse_duration(gap)
        except ValueError as e:
            err_console.print(f"Error: {e}", style="red")
            raise SystemExit(2)

    out_delim = delimiter if delimiter is not None else " "
    aligner = StreamingAligner(out_delim) if align_cols else None

    # Pass through headers
    if header is not None:
        for _ in range(header):
            line = sys.stdin.readline()
            if not line:
                break
            sys.stdout.write(line)

    # Group expressions by strategy type for execution pipeline
    row_at_a_time: list[FilterExpr] = []  # range, clock, rate
    window_exprs: list[FilterExpr] = []  # mad
    run_exprs: list[FilterExpr] = []  # run

    for expr in parsed:
        if expr.strategy in ("range", "clock", "rate", "mono"):
            row_at_a_time.append(expr)
        elif expr.strategy == "mad":
            window_exprs.append(expr)
        elif expr.strategy == "run":
            run_exprs.append(expr)

    # Initialize rate and mono states
    rate_states: dict[int, RateState] = {}
    mono_states: dict[int, MonoState] = {}
    for expr in row_at_a_time:
        if expr.strategy == "rate":
            rate_states[id(expr)] = RateState(expr)
        elif expr.strategy == "mono":
            mono_states[id(expr)] = MonoState(expr)

    # Determine max window size needed for mad expressions
    max_window = 0
    for expr in window_exprs:
        w = expr.get_int("window", 11)
        if w > max_window:
            max_window = w

    # --- Execution ---
    # Read all rows, extract time values, detect gaps, evaluate row-at-a-time exprs.
    # (fields, bad_col_indices, time_value, is_gap_after_this_row)
    all_rows: list[tuple[list[str], set[int], float | None]] = []
    gap_indices: set[int] = set()  # row indices where a gap starts AFTER this row
    prev_time: float | None = None

    for line in sys.stdin:
        stripped = line.rstrip("\r\n")
        if not stripped:
            continue
        fields = split_fields(line, delimiter)
        num_fields = len(fields)

        # Extract time value for gap detection and rate
        time_col_idx = _resolve_col_idx(time_col, num_fields)
        time_val: float | None = None
        if 0 <= time_col_idx < num_fields:
            time_val = _try_parse_time(fields[time_col_idx])

        # Detect gap
        if gap_threshold is not None and prev_time is not None and time_val is not None:
            if abs(time_val - prev_time) > gap_threshold:
                # Mark the previous row as having a gap after it
                if all_rows:
                    gap_indices.add(len(all_rows) - 1)
                # Reset rate and mono states on gap
                for state in rate_states.values():
                    state.reset()
                for state in mono_states.values():
                    state.reset()

        prev_time = time_val

        bad_cols: set[int] = set()

        for expr in row_at_a_time:
            col_idx = _resolve_col_idx(expr.column, num_fields)
            if col_idx < 0 or col_idx >= num_fields:
                if no_fail:
                    continue
                err_console.print(
                    f"Error: column {expr.column} out of range (row has {num_fields} fields)",
                    style="red",
                )
                raise SystemExit(2)

            is_bad = False
            if expr.strategy == "range":
                is_bad = _eval_range(expr, fields[col_idx])
            elif expr.strategy == "rate":
                state = rate_states[id(expr)]
                is_bad = state.eval(fields, col_idx, time_val)
            elif expr.strategy == "clock":
                if expr.has("ref"):
                    is_bad = _eval_clock_delta(expr, fields, col_idx, num_fields)
                else:
                    is_bad = _eval_clock_absolute(expr, fields[col_idx])
            elif expr.strategy == "mono":
                is_bad = mono_states[id(expr)].eval(fields[col_idx])

            if is_bad:
                bad_cols.add(col_idx)

        all_rows.append((fields, bad_cols, time_val))

    # Stage 2: Window-based MAD evaluation (gap-aware)
    if window_exprs:
        half = max_window // 2
        _eval_mad_all_rows(all_rows, gap_indices, half, window_exprs, no_fail)

    # Stage 3: Run-length evaluation (gap-aware)
    if run_exprs:
        _eval_run_exprs(all_rows, gap_indices, run_exprs, no_fail)

    # --- Output ---
    _RED = "\033[31m"
    _RESET = "\033[0m"
    emitted = 0

    for fields, bad_cols, _ in all_rows:
        has_bad = len(bad_cols) > 0

        if drop:
            should_emit = (not has_bad and not invert) or (has_bad and invert)
            if should_emit:
                _write_row(fields, out_delim, aligner)
                emitted += 1
        elif mark:
            out_fields = list(fields)
            for i in bad_cols:
                if i < len(out_fields):
                    out_fields[i] = f"{_RED}{out_fields[i]}{_RESET}"
            _write_row(out_fields, out_delim, aligner)
            emitted += 1
        else:
            out_fields = list(fields)
            if invert:
                for i in range(len(out_fields)):
                    if i not in bad_cols:
                        out_fields[i] = null
            else:
                for i in bad_cols:
                    if i < len(out_fields):
                        out_fields[i] = null
            _write_row(out_fields, out_delim, aligner)
            emitted += 1

    # Grep-style exit: 1 when --drop produces no output
    raise SystemExit(0 if not drop or emitted > 0 else 1)


def _eval_mad_all_rows(
    all_rows: list[tuple[list[str], set[int], float | None]],
    gap_indices: set[int],
    half: int,
    window_exprs: list[FilterExpr],
    no_fail: bool,
) -> None:
    """Evaluate MAD expressions across all rows, resetting windows at gaps."""
    # Split row indices into segments separated by gaps
    segments: list[list[int]] = []
    current_seg: list[int] = []
    for i in range(len(all_rows)):
        current_seg.append(i)
        if i in gap_indices:
            segments.append(current_seg)
            current_seg = []
    if current_seg:
        segments.append(current_seg)

    # Process each segment independently
    for segment in segments:
        all_past: deque[int] = deque(maxlen=half)
        unemitted: deque[int] = deque()

        for i in segment:
            unemitted.append(i)

            while len(unemitted) > half:
                emit_idx = unemitted.popleft()
                _eval_mad_for_row(
                    emit_idx, all_rows, all_past, unemitted, half, window_exprs, no_fail
                )
                all_past.append(emit_idx)

        # Flush tail of segment
        while unemitted:
            emit_idx = unemitted.popleft()
            _eval_mad_for_row(
                emit_idx, all_rows, all_past, unemitted, half, window_exprs, no_fail
            )
            all_past.append(emit_idx)


def _eval_mad_for_row(
    emit_idx: int,
    all_rows: list[tuple[list[str], set[int], float | None]],
    all_past: deque[int],
    unemitted: deque[int],
    half: int,
    window_exprs: list[FilterExpr],
    no_fail: bool,
) -> None:
    """Evaluate MAD expressions for a single row using its window context."""
    fields, bad_cols, _ = all_rows[emit_idx]
    num_fields = len(fields)

    # Build window indices: past + emit + future
    window_indices = list(all_past) + [emit_idx] + list(unemitted)[:half]

    for expr in window_exprs:
        col_idx = _resolve_col_idx(expr.column, num_fields)
        if col_idx < 0 or col_idx >= num_fields:
            if no_fail:
                continue
            err_console.print(
                f"Error: column {expr.column} out of range (row has {num_fields} fields)",
                style="red",
            )
            raise SystemExit(2)

        target_val = _try_float(fields[col_idx])
        if target_val is None:
            if no_fail:
                bad_cols.add(col_idx)
                continue
            err_console.print(
                f"Error: non-numeric value '{fields[col_idx]}' in column {expr.column}",
                style="red",
            )
            raise SystemExit(2)

        window_vals: list[float] = []
        for wi in window_indices:
            row_fields = all_rows[wi][0]
            if col_idx < len(row_fields):
                v = _try_float(row_fields[col_idx])
                if v is not None:
                    window_vals.append(v)

        if not window_vals:
            bad_cols.add(col_idx)
            continue

        delta = expr.get_float("delta", 3.0)
        if not _should_keep_mad(target_val, window_vals, delta):
            bad_cols.add(col_idx)


def _eval_run_exprs(
    all_rows: list[tuple[list[str], set[int], float | None]],
    gap_indices: set[int],
    run_exprs: list[FilterExpr],
    no_fail: bool,
) -> None:
    """Evaluate run-length expressions across all rows, breaking runs at gaps."""
    for expr in run_exprs:
        min_run = expr.get_int("min", 3)

        run_start = 0
        run_value: str | None = None

        def _flush_run(start: int, end: int) -> None:
            """Mark rows in [start, end) as bad if run is too short."""
            if run_value is not None and (end - start) < min_run:
                for j in range(start, end):
                    rc = _resolve_col_idx(expr.column, len(all_rows[j][0]))
                    all_rows[j][1].add(rc)

        for i, (fields, bad_cols, _) in enumerate(all_rows):
            num_fields = len(fields)
            col_idx = _resolve_col_idx(expr.column, num_fields)

            if col_idx < 0 or col_idx >= num_fields:
                if no_fail:
                    _flush_run(run_start, i)
                    run_value = None
                    run_start = i + 1
                    continue
                err_console.print(
                    f"Error: column {expr.column} out of range (row has {num_fields} fields)",
                    style="red",
                )
                raise SystemExit(2)

            # Check for gap before this row (gap is after row i-1)
            if i > 0 and (i - 1) in gap_indices:
                _flush_run(run_start, i)
                run_value = None
                run_start = i

            val = fields[col_idx]

            if val != run_value:
                _flush_run(run_start, i)
                run_value = val
                run_start = i

        # Flush final run
        _flush_run(run_start, len(all_rows))
