from __future__ import annotations

import sys
from typing import Annotated, Optional

import typer

from rich.console import Console

from sodatools_core.common.cli_helpers import (
    HELP_ALIGN,
    HELP_DELIMITER,
    HELP_EXAMPLE,
    HELP_HEADER_PASSTHRU,
    eager_print_callback,
)
from sodatools_core.common.align import StreamingAligner
from sodatools_core.common.reader import split_fields, warn_if_tty

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data small | soda nf 3
  soda sample-data small | soda nf 4 --pad '?'
  soda sample-data small | soda nf 2 --min
"""


def nf(
    n: Annotated[
        int,
        typer.Argument(help="Required number of fields"),
    ],
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER),
    ] = None,
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help=HELP_HEADER_PASSTHRU),
    ] = None,
    min_mode: Annotated[
        bool,
        typer.Option("--min", help="N is minimum field count (don't truncate long lines)"),
    ] = False,
    pad: Annotated[
        Optional[str],
        typer.Option("--pad", help="Pad short rows with this value instead of dropping"),
    ] = None,
    align_cols: Annotated[
        bool,
        typer.Option("--align", help=HELP_ALIGN),
    ] = False,
    example: Annotated[
        bool, typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE)
    ] = False,
) -> None:
    """Enforce a specific number of fields per line."""
    warn_if_tty(sys.stdin, "nf")

    out_delim = delimiter if delimiter is not None else " "
    aligner = StreamingAligner(out_delim) if align_cols else None

    # Pass through header lines unchanged
    if header is not None:
        for _ in range(header):
            line = sys.stdin.readline()
            if not line:
                break
            sys.stdout.write(line)

    for line in sys.stdin:
        stripped = line.rstrip("\r\n")
        if not stripped:
            continue

        fields = split_fields(line, delimiter)
        count = len(fields)

        if count < n:
            if pad is not None:
                fields.extend([pad] * (n - count))
            else:
                continue  # drop short lines
        elif count > n and not min_mode:
            fields = fields[:n]

        if aligner is not None:
            aligner.write_row(fields)
        else:
            sys.stdout.write(out_delim.join(fields) + "\n")

    raise SystemExit(0)
