from __future__ import annotations

import sys


def _is_numeric(value: str) -> bool:
    """Check if a string looks like a number."""
    try:
        float(value)
        return True
    except ValueError:
        return False


class StreamingAligner:
    """Adaptive column aligner for streaming output.

    Tracks max width per column and pads fields accordingly.
    Numbers are right-justified, strings are left-justified.
    Converges to stable alignment after a few rows.
    """

    def __init__(self, delimiter: str = " ") -> None:
        self.delimiter = delimiter
        self._widths: list[int] = []
        self._numeric: list[bool | None] = []  # None = undecided
        self._locked: bool = False  # when True, _numeric is not auto-detected

    def format_row(self, fields: list[str]) -> str:
        # Expand tracking if needed
        while len(self._widths) < len(fields):
            self._widths.append(0)
            self._numeric.append(None)

        # Update max widths and detect numeric columns
        for i, f in enumerate(fields):
            if len(f) > self._widths[i]:
                self._widths[i] = len(f)
            if not self._locked and f and self._numeric[i] is not False:
                if _is_numeric(f):
                    self._numeric[i] = True
                else:
                    self._numeric[i] = False

        # Pad fields: right-justify numeric, left-justify strings
        parts: list[str] = []
        for i, f in enumerate(fields):
            if self._numeric[i]:
                parts.append(f.rjust(self._widths[i]))
            else:
                parts.append(f.ljust(self._widths[i]))

        return self.delimiter.join(parts).rstrip()

    def write_row(self, fields: list[str]) -> None:
        sys.stdout.write(self.format_row(fields) + "\n")
