from __future__ import annotations

from typing import TextIO

import polars as pl

from sodatools_core.common.parsing import parse_iso8601
from sodatools_core.common.reader import ReaderConfig, read_header, read_rows


def detect_column_type(series: pl.Series) -> str:
    """Detect column type from a polars string series.

    Returns 'datetime', 'int', 'float', or 'string'.
    """
    non_null = series.drop_nulls()
    if len(non_null) == 0:
        return "string"

    sample = non_null[0]

    # Try datetime
    try:
        parse_iso8601(sample)
        return "datetime"
    except (ValueError, IndexError, TypeError):
        pass

    # Try int
    try:
        int(sample)
        if "." not in sample:
            return "int"
    except (ValueError, TypeError):
        pass

    # Try float
    try:
        float(sample)
        return "float"
    except (ValueError, TypeError):
        pass

    return "string"


def cast_column(series: pl.Series, dtype: str) -> pl.Series:
    """Cast a string series to the detected type."""
    if dtype == "datetime":
        values = []
        for val in series.to_list():
            if val is None:
                values.append(None)
            else:
                try:
                    values.append(parse_iso8601(val))
                except (ValueError, IndexError):
                    values.append(None)
        return pl.Series(series.name, values, dtype=pl.Datetime)
    elif dtype == "int":
        return series.cast(pl.Int64, strict=False)
    elif dtype == "float":
        return series.cast(pl.Float64, strict=False)
    return series


def read_dataframe(
    stdin: TextIO,
    config: ReaderConfig,
    header_lines: int | None = None,
) -> tuple[pl.DataFrame, dict[str, str]]:
    """Read stdin into a typed polars DataFrame.

    Returns (dataframe, col_types) where col_types maps column name
    to detected type ('datetime', 'int', 'float', 'string').

    Column names come from header lines or default to "1", "2", ...
    """
    # Read headers
    header_names: list[str] = []
    if header_lines is not None and header_lines > 0:
        headers = read_header(stdin, config.delimiter, header_lines)
        if headers:
            header_names = headers[-1]  # use last header line for names

    # Collect all rows
    rows = list(read_rows(stdin, config))

    if not rows:
        return pl.DataFrame(), {}

    # Determine column count and names
    ncols = max(len(row) for row in rows)
    if header_names:
        col_names = header_names[:ncols]
        while len(col_names) < ncols:
            col_names.append(str(len(col_names) + 1))
    else:
        col_names = [str(i + 1) for i in range(ncols)]

    # Build columns (pad short rows with None)
    columns: dict[str, list[str | None]] = {name: [] for name in col_names}
    for row in rows:
        for i, name in enumerate(col_names):
            if i < len(row):
                columns[name].append(row[i])
            else:
                columns[name].append(None)

    df = pl.DataFrame(
        {name: pl.Series(name, vals, dtype=pl.Utf8) for name, vals in columns.items()}
    )

    # Detect and cast types
    col_types: dict[str, str] = {}
    for col in df.columns:
        dtype = detect_column_type(df[col])
        col_types[col] = dtype
        df = df.with_columns(cast_column(df[col], dtype).alias(col))

    return df, col_types
