"""Shared CLI helpers for typer commands."""

from __future__ import annotations

from typing import Callable

import typer
from rich.console import Console


def eager_print_callback(text: str) -> Callable[[typer.Context, bool], None]:
    """Return an eager typer callback that prints Rich text and exits."""

    def _callback(ctx: typer.Context, value: bool) -> None:
        if not value:
            return
        Console().print(text)
        raise SystemExit(0)

    return _callback


# ---------------------------------------------------------------------------
# Shared help text constants
# ---------------------------------------------------------------------------
# Use these in typer.Option(..., help=HELP_*) for consistency across tools.
# Tools with unique semantics (align, kut, stats, plot) keep their own text.

HELP_DELIMITER = "Field delimiter (default: whitespace)"
HELP_DELIMITER_INPUT = "Input field delimiter (default: whitespace)"
HELP_DELIMITER_OUTPUT = "Output field delimiter"
HELP_HEADER_PASSTHRU = "Pass through first N header lines unchanged"
HELP_HEADER_SKIP = "Skip first N header lines"
HELP_ALIGN = "Adaptively align output columns"
HELP_NO_FAIL = "Skip problematic rows instead of erroring"
HELP_EXAMPLE = "Show usage examples and exit"
HELP_SYNTAX = "Show expression syntax reference and exit"
HELP_NO_COLOR = "Disable colored output"
