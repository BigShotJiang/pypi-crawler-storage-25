from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass, field
from typing import TextIO

from rich.console import Console


@dataclass
class ReaderConfig:
    """Configuration for reading columnar text data from stdin."""

    delimiter: str | None = None
    null_sentinels: set[str] = field(default_factory=lambda: {"?"})


def warn_if_tty(stdin: TextIO, tool_name: str) -> None:
    """Print a hint if stdin is a terminal (no pipe)."""
    if stdin.isatty():
        Console(stderr=True).print(
            f"{tool_name}: reading from stdin (pipe data or press Ctrl+D to end)",
            style="dim",
        )


def split_fields(line: str, delimiter: str | None) -> list[str]:
    """Split a line into fields by delimiter (None = whitespace)."""
    stripped = line.rstrip("\r\n")
    if delimiter is not None:
        return stripped.split(delimiter)
    return stripped.split()


def replace_nulls(
    fields: list[str], null_sentinels: set[str]
) -> list[str | None]:
    """Replace null sentinel values with None."""
    return [None if f in null_sentinels else f for f in fields]


def read_header(
    stdin: TextIO, delimiter: str | None, n_lines: int
) -> list[list[str]]:
    """Read and return N header lines as split fields."""
    headers: list[list[str]] = []
    for _ in range(n_lines):
        line = stdin.readline()
        if not line:
            break
        headers.append(split_fields(line, delimiter))
    return headers


def read_rows(
    stdin: TextIO, config: ReaderConfig
) -> Iterator[list[str | None]]:
    """Yield rows from stdin with null replacement. Streaming."""
    for line in stdin:
        stripped = line.rstrip("\r\n")
        if not stripped:
            continue
        fields = split_fields(line, config.delimiter)
        yield replace_nulls(fields, config.null_sentinels)


def read_rows_raw(
    stdin: TextIO, delimiter: str | None
) -> Iterator[list[str]]:
    """Yield rows from stdin without null replacement. For streaming tools."""
    for line in stdin:
        stripped = line.rstrip("\r\n")
        if not stripped:
            continue
        yield split_fields(line, delimiter)
