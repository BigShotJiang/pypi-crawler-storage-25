class SodatoolsError(Exception):
    """Base exception for all sodatools errors."""


class FieldIndexError(SodatoolsError):
    """Raised when a field index is out of range for a given line."""

    def __init__(self, field_index: int, num_fields: int) -> None:
        self.field_index = field_index
        self.num_fields = num_fields
        super().__init__(
            f"Field {field_index} out of range (line has {num_fields} fields)"
        )


class NumericConversionError(SodatoolsError):
    """Raised when a value cannot be converted to a number for numeric comparison."""

    def __init__(self, value: str, context: str = "") -> None:
        self.value = value
        msg = f"Cannot convert '{value}' to a number"
        if context:
            msg += f" ({context})"
        super().__init__(msg)
