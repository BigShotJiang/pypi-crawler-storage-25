import re
from datetime import datetime, timezone


def parse_duration(s: str) -> float:
    """Parse a duration string or bare number to seconds.

    Accepts: '5m', '1.5h', '30s', '2d', or bare number '60' (seconds).
    """
    m = re.match(r"^(\d+(?:\.\d+)?)\s*([smhd])$", s)
    if m:
        value = float(m.group(1))
        unit = m.group(2)
        multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400}
        return value * multipliers[unit]
    try:
        return float(s)
    except ValueError:
        raise ValueError(
            f"Invalid duration '{s}' (use Ns, Nm, Nh, Nd, or bare seconds)"
        )


def parse_iso8601(text: str) -> datetime:
    """Parse an ISO 8601 date/datetime string.

    Supports formats like:
        2024-01-15
        2024-01-15T10:30:00
        2024-01-15T10:30:00Z
        2024-01-15T10:30:00+05:00
    """
    return datetime.fromisoformat(text.replace("Z", "+00:00"))


def text_to_int_array(text: str) -> list[int]:
    """Convert a range/list expression to an array of integers.

    Supports comma-separated values and dash ranges:
        "1,2,3"     -> [1, 2, 3]
        "1-5"       -> [1, 2, 3, 4, 5]
        "1-3,7,9-11" -> [1, 2, 3, 7, 9, 10, 11]
    """
    result: list[int] = []
    for part in text.split(","):
        part = part.strip()
        if "-" in part:
            start_str, end_str = part.split("-", 1)
            start = int(start_str.strip())
            end = int(end_str.strip())
            result.extend(range(start, end + 1))
        else:
            result.append(int(part))
    return result
