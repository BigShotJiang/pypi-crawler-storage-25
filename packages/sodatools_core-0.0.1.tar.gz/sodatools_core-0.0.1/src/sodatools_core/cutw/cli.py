from __future__ import annotations

import os
import sys
from typing import Annotated, Optional

import typer
from rich.console import Console

from sodatools_core.common.cli_helpers import HELP_EXAMPLE, eager_print_callback
from sodatools_core.common.reader import warn_if_tty

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data weather | soda cutw 60
  soda sample-data weather | soda cutw 40 --marker '…'
"""


def cutw(
    width: Annotated[
        Optional[int],
        typer.Argument(help="Max line width (default: terminal width)"),
    ] = None,
    marker: Annotated[
        str,
        typer.Option("--marker", help="Truncation indicator appended to cut lines"),
    ] = "",
    example: Annotated[
        bool, typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE)
    ] = False,
) -> None:
    """Truncate lines to a given width."""
    warn_if_tty(sys.stdin, "cutw")

    if width is None:
        try:
            width = os.get_terminal_size().columns
        except OSError:
            width = 80

    marker_len = len(marker)

    for line in sys.stdin:
        stripped = line.rstrip("\r\n")
        if len(stripped) > width:
            if marker_len > 0 and width > marker_len:
                stripped = stripped[: width - marker_len] + marker
            else:
                stripped = stripped[:width]
        sys.stdout.write(stripped + "\n")

    raise SystemExit(0)
