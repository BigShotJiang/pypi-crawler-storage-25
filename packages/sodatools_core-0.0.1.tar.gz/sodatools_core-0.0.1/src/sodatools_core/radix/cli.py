from __future__ import annotations

import sys
from typing import Annotated, Optional

import typer
from rich.console import Console

from sodatools_core.common.cli_helpers import (
    HELP_ALIGN,
    HELP_DELIMITER,
    HELP_EXAMPLE,
    HELP_HEADER_PASSTHRU,
    eager_print_callback,
)
from sodatools_core.common.align import StreamingAligner
from sodatools_core.common.reader import split_fields, warn_if_tty

err_console = Console(stderr=True)

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data small | soda radix --to hex
  soda sample-data small | soda radix --to bin
  soda sample-data small | soda radix --to hex -b 16
"""

_FROM_BASES = {
    "int": 10,
    "dec": 10,
    "hex": 16,
    "bin": 2,
    "oct": 8,
    "auto": 0,  # Python's int(x, 0) auto-detects 0x/0b/0o prefixes
}

import math


def _make_formatter(to_base: str, bits: int) -> callable:
    """Create a formatter function for the given output base and bit width."""
    if to_base in ("dec", "int"):
        width = len(str(2**bits - 1))
        return lambda v: f"{v:{width}d}"
    if to_base == "hex":
        width = math.ceil(bits / 4)
        return lambda v: f"{v:0{width}x}"
    if to_base == "bin":
        width = bits
        return lambda v: f"{v:0{width}b}"
    if to_base == "oct":
        width = math.ceil(bits / 3)
        return lambda v: f"{v:0{width}o}"
    raise ValueError(f"Unknown base: {to_base}")


def _try_parse(value: str, from_base: int) -> int | None:
    """Try to parse a string as an integer in the given base."""
    try:
        return int(value, from_base)
    except (ValueError, TypeError):
        return None


def radix(
    columns: Annotated[
        Optional[list[int]],
        typer.Argument(help="Columns to convert (1-indexed). Default: all integer columns."),
    ] = None,
    from_base: Annotated[
        str,
        typer.Option("--from", "-f", help="Input base: auto, int/dec, hex, bin, oct (default: auto)"),
    ] = "auto",
    to_base: Annotated[
        str,
        typer.Option("--to", "-t", help="Output base: dec/int, hex, bin, oct"),
    ] = "hex",
    bits: Annotated[
        int,
        typer.Option("--bits", "-b", help="Bit width for zero-padding (default: 8)"),
    ] = 8,
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER),
    ] = None,
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help=HELP_HEADER_PASSTHRU),
    ] = None,
    align_cols: Annotated[
        bool,
        typer.Option("--align", help=HELP_ALIGN),
    ] = False,
    example: Annotated[
        bool,
        typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE),
    ] = False,
) -> None:
    """Convert integer columns between number bases (dec, hex, bin, oct)."""
    warn_if_tty(sys.stdin, "radix")

    valid_to = {"dec", "int", "hex", "bin", "oct"}
    if from_base not in _FROM_BASES:
        err_console.print(f"Error: unknown --from base '{from_base}' (use: auto, int, dec, hex, bin, oct)", style="red")
        raise SystemExit(2)
    if to_base not in valid_to:
        err_console.print(f"Error: unknown --to base '{to_base}' (use: int, dec, hex, bin, oct)", style="red")
        raise SystemExit(2)

    base = _FROM_BASES[from_base]
    formatter = _make_formatter(to_base, bits)
    out_delim = delimiter if delimiter is not None else " "
    aligner = StreamingAligner(out_delim) if align_cols else None

    # Convert column list to 0-indexed set
    target_cols: set[int] | None = None
    if columns:
        target_cols = {(c - 1 if c > 0 else c) for c in columns}

    # Pass through headers
    if header is not None:
        for _ in range(header):
            line = sys.stdin.readline()
            if not line:
                break
            sys.stdout.write(line)

    for line in sys.stdin:
        stripped = line.rstrip("\r\n")
        if not stripped:
            continue

        fields = split_fields(line, delimiter)
        out_fields: list[str] = []

        for i, field in enumerate(fields):
            # Resolve negative column indices
            col_idx = i
            should_convert = target_cols is None or i in target_cols
            if target_cols is not None:
                # Also check negative indices
                neg_idx = i - len(fields)
                should_convert = i in target_cols or neg_idx in target_cols

            if should_convert:
                parsed = _try_parse(field, base)
                if parsed is not None:
                    out_fields.append(formatter(parsed))
                else:
                    out_fields.append(field)  # not parseable, leave as-is
            else:
                out_fields.append(field)

        if aligner is not None:
            aligner.write_row(out_fields)
        else:
            sys.stdout.write(out_delim.join(out_fields) + "\n")

    raise SystemExit(0)
