from __future__ import annotations

from sodatools_core.coltest.parser import TestExpr
from sodatools_core.common.exceptions import FieldIndexError, NumericConversionError


def _get_field(fields: list[str], test: TestExpr) -> str:
    idx = test.field_index - 1  # 1-indexed to 0-indexed
    if idx < 0 or idx >= len(fields):
        raise FieldIndexError(test.field_index, len(fields))
    return fields[idx]


def _to_float(value: str, context: str) -> float:
    try:
        return float(value)
    except ValueError:
        raise NumericConversionError(value, context) from None


def evaluate_test(test: TestExpr, fields: list[str]) -> bool:
    """Evaluate a single test expression against a list of fields."""
    field_value = _get_field(fields, test)
    op = test.operator

    # Numeric comparisons
    if op in ("eq", "ne", "gt", "lt", "ge", "le"):
        a = _to_float(field_value, f"field {test.field_index}")
        b = _to_float(test.value, "test value")
        if op == "eq":
            return a == b
        if op == "ne":
            return a != b
        if op == "gt":
            return a > b
        if op == "lt":
            return a < b
        if op == "ge":
            return a >= b
        # le
        return a <= b

    # String comparisons
    if op in ("seq", "sne", "sgt", "slt", "sge", "sle"):
        if op == "seq":
            return field_value == test.value
        if op == "sne":
            return field_value != test.value
        if op == "sgt":
            return field_value > test.value
        if op == "slt":
            return field_value < test.value
        if op == "sge":
            return field_value >= test.value
        # sle
        return field_value <= test.value

    # Regex match
    if op == "match_regex":
        assert test.compiled_regex is not None
        return test.compiled_regex.search(field_value) is not None

    raise ValueError(f"Unknown operator: {op}")


def evaluate_line(
    tests: list[TestExpr], fields: list[str], *, use_or: bool = False
) -> tuple[bool, list[bool]]:
    """Evaluate all tests against a line's fields.

    Returns (overall_result, per_test_results).
    """
    results = [evaluate_test(t, fields) for t in tests]
    if use_or:
        return (any(results), results)
    return (all(results), results)
