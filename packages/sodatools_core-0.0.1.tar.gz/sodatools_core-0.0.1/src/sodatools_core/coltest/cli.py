from __future__ import annotations

import sys
from typing import Annotated, Optional

import typer
from lark.exceptions import LarkError
from rich.console import Console
from rich.text import Text

from sodatools_core.coltest.evaluator import evaluate_line
from sodatools_core.coltest.parser import TestExpr, parse_test
from sodatools_core.common.cli_helpers import (
    HELP_DELIMITER,
    HELP_EXAMPLE,
    HELP_HEADER_PASSTHRU,
    HELP_NO_COLOR,
    HELP_NO_FAIL,
    HELP_SYNTAX,
    eager_print_callback,
)
from sodatools_core.common.exceptions import FieldIndexError, NumericConversionError
from sodatools_core.common.reader import read_header, read_rows_raw, split_fields, warn_if_tty

console = Console()
err_console = Console(stderr=True)

_SYNTAX = """\
[bold]Expression syntax:[/]  [dim]<col><op><value>[/]

  Columns are 1-indexed. Each positional argument is one test.
  Multiple tests are combined with AND (use --or for OR).

[bold]Numeric operators[/] (compare as floats):
  [blue]eq[/]  [dim]=[/]     equal            [blue]ne[/]  [dim]!=[/]    not equal
  [blue]gt[/]  [dim]>[/]     greater than     [blue]lt[/]  [dim]<[/]     less than
  [blue]ge[/]  [dim]>=[/]    greater/equal    [blue]le[/]  [dim]<=[/]    less/equal

[bold]String operators[/] (compare as strings):
  [blue]seq[/] [dim]s=[/]    equal            [blue]sne[/] [dim]s!=[/]   not equal
  [blue]sgt[/] [dim]s>[/]    greater          [blue]slt[/] [dim]s<[/]    less
  [blue]sge[/] [dim]s>=[/]   greater/equal    [blue]sle[/] [dim]s<=[/]   less/equal

[bold]Regex:[/]
  [blue]m[/]             regex search (re.search)

  Shell-safe aliases (eq, gt, seq, ...) are preferred over symbols.

[bold]Examples:[/]
  soda coltest 2eq42              field 2 equals 42 (numeric)
  soda coltest 1seqhello          field 1 equals "hello" (string)
  soda coltest "1m^abc"           field 1 matches regex ^abc
  soda coltest 2gt10 3lt100       field 2 > 10 AND field 3 < 100
  soda coltest --or 2eq1 2eq2     field 2 is 1 OR 2
  soda coltest --invert 6seqERR   lines where field 6 is NOT "ERR"
"""


_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data small | soda coltest 2gt50
  soda sample-data small | soda coltest --invert 2gt50
  soda sample-data small | soda coltest 3seqERR
  soda sample-data small | soda coltest -v 2gt50
"""


def _format_test_result(test: TestExpr, passed: bool) -> Text:
    """Format a single test result with rich coloring for -vv output."""
    t = Text()
    t.append(str(test.field_index), style="dim")
    t.append(test.operator, style="blue")
    t.append(test.value, style="default")
    t.append(":")
    if passed:
        t.append("T", style="green")
    else:
        t.append("F", style="red")
    return t


def _format_verdict(passed: bool) -> Text:
    """Format PASS/FAIL with rich coloring."""
    if passed:
        return Text("PASS", style="bold green")
    return Text("FAIL", style="bold red")


def coltest(
    tests: Annotated[
        Optional[list[str]],
        typer.Argument(help="Column test expressions, e.g. '2eq42' '1m^abc'"),
    ] = None,
    syntax: Annotated[
        bool, typer.Option("--syntax", callback=eager_print_callback(_SYNTAX), is_eager=True, help=HELP_SYNTAX)
    ] = False,
    example: Annotated[
        bool, typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE)
    ] = False,
    invert: Annotated[
        bool, typer.Option("--invert", help="Invert match result")
    ] = False,
    no_fail: Annotated[
        bool,
        typer.Option("--no-fail", help=HELP_NO_FAIL),
    ] = False,
    use_or: Annotated[
        bool, typer.Option("--or", help="Use OR logic instead of AND")
    ] = False,
    verbose: Annotated[
        int, typer.Option("-v", "--verbose", count=True, help="Verbosity: -v for PASS/FAIL, -vv for per-test detail")
    ] = 0,
    count: Annotated[
        bool, typer.Option("--count", "-c", help="Only print count of matching lines")
    ] = False,
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help=HELP_HEADER_PASSTHRU),
    ] = None,
    no_color: Annotated[
        bool, typer.Option("--no-color", help=HELP_NO_COLOR)
    ] = False,
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER),
    ] = None,
) -> None:
    """Filter lines from stdin based on column test expressions."""
    if not tests:
        err_console.print("Error: no test expressions provided (use --syntax for help)", style="red")
        raise SystemExit(2)

    warn_if_tty(sys.stdin, "coltest")

    out = Console(no_color=no_color)

    # Parse all test expressions upfront
    parsed_tests: list[TestExpr] = []
    for expr in tests:
        try:
            parsed_tests.append(parse_test(expr))
        except LarkError as e:
            err_console.print(f"Error parsing '{expr}': {e}", style="red")
            raise SystemExit(2)

    # Pass through header lines unchanged
    if header is not None:
        for _ in range(header):
            line = sys.stdin.readline()
            if not line:
                break
            sys.stdout.write(line)

    match_count = 0

    for line in sys.stdin:
        stripped = line.rstrip("\r\n")
        if not stripped:
            continue
        fields = split_fields(line, delimiter)

        try:
            passed, per_test = evaluate_line(
                parsed_tests, fields, use_or=use_or
            )
        except FieldIndexError as e:
            if no_fail:
                continue
            err_console.print(f"Error: {e}", style="red")
            raise SystemExit(2)
        except NumericConversionError as e:
            if no_fail:
                continue
            err_console.print(f"Error: {e}", style="red")
            raise SystemExit(2)

        if invert:
            passed = not passed

        if passed:
            match_count += 1

        if count:
            continue

        if verbose >= 2:
            # -vv: PASS/FAIL + per-test results + line
            parts = Text()
            parts.append_text(_format_verdict(passed))
            parts.append("  ")
            for i, (t, r) in enumerate(zip(parsed_tests, per_test)):
                if invert:
                    r = not r
                if i > 0:
                    parts.append(" ")
                parts.append_text(_format_test_result(t, r))
            parts.append("  ")
            parts.append(stripped)
            out.print(parts)
        elif verbose >= 1:
            # -v: PASS/FAIL + line
            parts = Text()
            parts.append_text(_format_verdict(passed))
            parts.append("  ")
            parts.append(stripped)
            out.print(parts)
        elif passed:
            # Default: only print passing lines
            sys.stdout.write(line)

    if count:
        sys.stdout.write(f"{match_count}\n")

    # Grep-style exit codes
    raise SystemExit(0 if match_count > 0 else 1)
