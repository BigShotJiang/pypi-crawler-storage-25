from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from lark import Lark, Transformer, v_args

_GRAMMAR_PATH = Path(__file__).parent / "grammar.lark"
_parser = Lark.open(str(_GRAMMAR_PATH), parser="lalr")


@dataclass(frozen=True)
class TestExpr:
    field_index: int
    operator: str
    value: str
    compiled_regex: Optional[re.Pattern[str]] = field(default=None, repr=False)

    def format_expr(self) -> str:
        """Return a compact string like '2eq42' for display."""
        return f"{self.field_index}{self.operator}{self.value}"


@v_args(inline=True)
class TestExprTransformer(Transformer):
    def start(self, test_expr: TestExpr) -> TestExpr:
        return test_expr

    def test(self, field_num: int, operator: str, value: str) -> TestExpr:
        compiled = None
        if operator == "match_regex":
            compiled = re.compile(value)
        return TestExpr(
            field_index=field_num,
            operator=operator,
            value=value,
            compiled_regex=compiled,
        )

    def FIELD_NUM(self, token: str) -> int:
        return int(token)

    def value(self, text: str) -> str:
        return text

    def VALUE_TEXT(self, token: str) -> str:
        return str(token)

    # Numeric operators
    def eq(self, *_: object) -> str:
        return "eq"

    def ne(self, *_: object) -> str:
        return "ne"

    def gt(self, *_: object) -> str:
        return "gt"

    def lt(self, *_: object) -> str:
        return "lt"

    def ge(self, *_: object) -> str:
        return "ge"

    def le(self, *_: object) -> str:
        return "le"

    # String operators
    def seq(self, *_: object) -> str:
        return "seq"

    def sne(self, *_: object) -> str:
        return "sne"

    def sgt(self, *_: object) -> str:
        return "sgt"

    def slt(self, *_: object) -> str:
        return "slt"

    def sge(self, *_: object) -> str:
        return "sge"

    def sle(self, *_: object) -> str:
        return "sle"

    # Regex
    def match_regex(self, *_: object) -> str:
        return "match_regex"


_transformer = TestExprTransformer()


def parse_test(expr: str) -> TestExpr:
    """Parse a test expression string into a TestExpr."""
    tree = _parser.parse(expr)
    return _transformer.transform(tree)
