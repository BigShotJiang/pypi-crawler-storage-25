from __future__ import annotations

import random
import statistics
import sys
from typing import Annotated, Optional

import typer
from rich.console import Console

from sodatools_core.common.cli_helpers import (
    HELP_ALIGN,
    HELP_DELIMITER,
    HELP_EXAMPLE,
    HELP_HEADER_PASSTHRU,
    eager_print_callback,
)
from sodatools_core.common.align import StreamingAligner
from sodatools_core.common.parsing import parse_duration, parse_iso8601
from sodatools_core.common.reader import split_fields, warn_if_tty

err_console = Console(stderr=True)

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data weather | soda sample every 10
  soda sample-data weather | soda sample random 20
  soda sample-data weather | soda sample pct 5
  soda sample-data weather | soda sample interval 1h -H 1
"""




def _try_float(val: str) -> float | None:
    try:
        return float(val)
    except ValueError:
        return None


def _try_parse_datetime_seconds(val: str) -> float | None:
    try:
        return parse_iso8601(val).timestamp()
    except (ValueError, IndexError, TypeError):
        return None


def sample(
    mode: Annotated[
        str,
        typer.Argument(help="Sampling mode: every, random, pct, interval"),
    ],
    value: Annotated[
        str,
        typer.Argument(help="N (rows/count/percent) or duration (e.g. 5m, 1h)"),
    ],
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER),
    ] = None,
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help=HELP_HEADER_PASSTHRU),
    ] = None,
    time_col: Annotated[
        int,
        typer.Option("--time", help="Time column for interval mode (1-indexed, default: 1)"),
    ] = 1,
    agg: Annotated[
        str,
        typer.Option("--agg", help="Aggregation for interval mode: last/first/mean/median/min/max"),
    ] = "last",
    align_cols: Annotated[
        bool,
        typer.Option("--align", help=HELP_ALIGN),
    ] = False,
    example: Annotated[
        bool,
        typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE),
    ] = False,
) -> None:
    """Sample or resample rows from stdin."""
    warn_if_tty(sys.stdin, "sample")

    out_delim = delimiter if delimiter is not None else " "
    aligner = StreamingAligner(out_delim) if align_cols else None

    def _write(fields: list[str]) -> None:
        if aligner is not None:
            aligner.write_row(fields)
        else:
            sys.stdout.write(out_delim.join(fields) + "\n")

    # Pass through headers
    if header is not None:
        for _ in range(header):
            line = sys.stdin.readline()
            if not line:
                break
            sys.stdout.write(line)

    if mode == "every":
        n = int(value)
        row_num = 0
        for line in sys.stdin:
            stripped = line.rstrip("\r\n")
            if not stripped:
                continue
            row_num += 1
            if row_num % n == 0:
                _write(split_fields(line, delimiter))

    elif mode == "random":
        # Reservoir sampling
        n = int(value)
        reservoir: list[list[str]] = []
        row_num = 0
        for line in sys.stdin:
            stripped = line.rstrip("\r\n")
            if not stripped:
                continue
            fields = split_fields(line, delimiter)
            row_num += 1
            if row_num <= n:
                reservoir.append(fields)
            else:
                j = random.randint(0, row_num - 1)
                if j < n:
                    reservoir[j] = fields
        for fields in reservoir:
            _write(fields)

    elif mode == "pct":
        pct = float(value) / 100.0
        for line in sys.stdin:
            stripped = line.rstrip("\r\n")
            if not stripped:
                continue
            if random.random() < pct:
                _write(split_fields(line, delimiter))

    elif mode == "interval":
        interval_secs = parse_duration(value)
        time_col_idx = time_col - 1

        # Detect datetime vs numeric from first line
        bin_rows: list[list[str]] = []
        bin_start: float | None = None
        is_datetime: bool | None = None

        def _get_time(fields: list[str]) -> float | None:
            nonlocal is_datetime
            if time_col_idx >= len(fields):
                return None
            val = fields[time_col_idx]
            if is_datetime is None:
                dt = _try_parse_datetime_seconds(val)
                if dt is not None:
                    is_datetime = True
                    return dt
                f = _try_float(val)
                if f is not None:
                    is_datetime = False
                    return f
                return None
            if is_datetime:
                return _try_parse_datetime_seconds(val)
            return _try_float(val)

        def _aggregate_bin(rows: list[list[str]]) -> list[str]:
            if not rows:
                return []
            ncols = max(len(r) for r in rows)
            result: list[str] = []
            for col_idx in range(ncols):
                col_vals = [r[col_idx] for r in rows if col_idx < len(r)]
                if not col_vals:
                    result.append("")
                    continue

                # Try numeric aggregation
                numeric = [_try_float(v) for v in col_vals]
                numeric_valid = [v for v in numeric if v is not None]

                if numeric_valid and len(numeric_valid) == len(col_vals):
                    if agg == "last":
                        result.append(col_vals[-1])
                    elif agg == "first":
                        result.append(col_vals[0])
                    elif agg == "mean":
                        result.append(f"{statistics.mean(numeric_valid):g}")
                    elif agg == "median":
                        result.append(f"{statistics.median(numeric_valid):g}")
                    elif agg == "min":
                        result.append(f"{min(numeric_valid):g}")
                    elif agg == "max":
                        result.append(f"{max(numeric_valid):g}")
                    else:
                        result.append(col_vals[-1])
                else:
                    # Non-numeric: use first value
                    result.append(col_vals[0])
            return result

        def _flush_bin() -> None:
            nonlocal bin_rows, bin_start
            if bin_rows:
                _write(_aggregate_bin(bin_rows))
                bin_rows = []
                bin_start = None

        for line in sys.stdin:
            stripped = line.rstrip("\r\n")
            if not stripped:
                continue
            fields = split_fields(line, delimiter)
            t = _get_time(fields)
            if t is None:
                continue

            if bin_start is None:
                bin_start = t

            if t - bin_start >= interval_secs:
                _flush_bin()
                bin_start = t

            bin_rows.append(fields)

        _flush_bin()

    else:
        err_console.print(f"Error: unknown mode '{mode}' (use: every, random, pct, interval)", style="red")
        raise SystemExit(2)

    raise SystemExit(0)
