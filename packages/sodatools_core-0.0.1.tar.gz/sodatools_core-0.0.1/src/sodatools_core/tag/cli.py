from __future__ import annotations

import sys
from dataclasses import dataclass, field
from typing import Annotated, Optional

import typer
from lark.exceptions import LarkError
from rich.console import Console

from sodatools_core.coltest.evaluator import evaluate_line
from sodatools_core.coltest.parser import TestExpr, parse_test
from sodatools_core.common.align import StreamingAligner
from sodatools_core.common.cli_helpers import (
    HELP_ALIGN,
    HELP_DELIMITER,
    HELP_EXAMPLE,
    HELP_HEADER_PASSTHRU,
    HELP_NO_FAIL,
    HELP_SYNTAX,
    eager_print_callback,
)
from sodatools_core.common.exceptions import FieldIndexError, NumericConversionError
from sodatools_core.common.reader import split_fields, warn_if_tty

err_console = Console(stderr=True)

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data small | soda tag -H1 high: 2gt50 low: 2le50
  soda sample-data weather | soda tag -H1 hot: 2gt25 cold: 2lt15 normal: 2ge15 2le25
  soda sample-data small | soda tag -H1 --drop err: 3seqERR
"""

_SYNTAX = """\
[bold]State assignment syntax:[/]

  Each state is a label (ending with ':') followed by conditions.
  Conditions use coltest expression syntax.

  soda tag hot: 2ge90 cold: 2le10 normal: 2gt10 2lt90

  Conditions within a state are combined with AND.
  By default, the first matching state wins.
  Use --all to output all matching states (comma-joined).

[bold]Options:[/]
  --default VALUE   state for unmatched lines (default: 'unknown')
  --drop            discard lines matching no state
  --all             output all matching states, not just the first

[bold]Examples:[/]
  soda tag hot: 2ge90 cold: 2le10 normal: 2gt10 2lt90
  soda tag --drop hot: 2ge90
  soda tag --default ok --all warn: 6seqWARN err: 6seqERR

  See `soda coltest --syntax` for condition syntax.
"""


@dataclass
class StateGroup:
    name: str
    tests: list[TestExpr] = field(default_factory=list)


def _parse_state_args(args: list[str]) -> list[StateGroup]:
    """Parse positional args into state groups."""
    groups: list[StateGroup] = []
    current: StateGroup | None = None

    for arg in args:
        if arg.endswith(":"):
            current = StateGroup(name=arg[:-1])
            groups.append(current)
        else:
            if current is None:
                raise ValueError(
                    f"Test expression '{arg}' before any state label (labels end with ':')"
                )
            try:
                current.tests.append(parse_test(arg))
            except LarkError as e:
                raise ValueError(f"Error parsing '{arg}': {e}") from None

    if not groups:
        raise ValueError("No state labels provided (labels end with ':')")

    for g in groups:
        if not g.tests:
            raise ValueError(f"State '{g.name}' has no conditions")

    return groups


def tag(
    args: Annotated[
        Optional[list[str]],
        typer.Argument(help="State definitions: 'label: condition...' (see --syntax)"),
    ] = None,
    syntax: Annotated[
        bool,
        typer.Option("--syntax", callback=eager_print_callback(_SYNTAX), is_eager=True, help=HELP_SYNTAX),
    ] = False,
    example: Annotated[
        bool,
        typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE),
    ] = False,
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER),
    ] = None,
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help=HELP_HEADER_PASSTHRU),
    ] = None,
    no_fail: Annotated[
        bool,
        typer.Option("--no-fail", help=HELP_NO_FAIL),
    ] = False,
    default: Annotated[
        str,
        typer.Option("--default", help="State for unmatched lines"),
    ] = "unknown",
    drop: Annotated[
        bool,
        typer.Option("--drop", help="Discard lines matching no state"),
    ] = False,
    all_matches: Annotated[
        bool,
        typer.Option("--all", help="Output all matching states (comma-joined), not just the first"),
    ] = False,
    align_cols: Annotated[
        bool,
        typer.Option("--align", help=HELP_ALIGN),
    ] = False,
) -> None:
    """Assign named states to lines based on column conditions."""
    if not args:
        err_console.print(
            "Error: no state definitions provided (use --syntax for help)",
            style="red",
        )
        raise SystemExit(2)

    try:
        state_groups = _parse_state_args(args)
    except ValueError as e:
        err_console.print(f"Error: {e}", style="red")
        raise SystemExit(2)

    warn_if_tty(sys.stdin, "tag")

    out_delim = delimiter if delimiter is not None else " "
    aligner = StreamingAligner(out_delim) if align_cols else None

    # Pass through header lines with an extra column label
    if header is not None:
        for _ in range(header):
            line = sys.stdin.readline()
            if not line:
                break
            fields = split_fields(line, delimiter)
            fields.append("_tag")
            if aligner is not None:
                aligner.write_row(fields)
            else:
                sys.stdout.write(out_delim.join(fields) + "\n")

    for line in sys.stdin:
        stripped = line.rstrip("\r\n")
        if not stripped:
            continue

        fields = split_fields(line, delimiter)

        matched: list[str] = []
        skip = False

        for group in state_groups:
            try:
                passed, _ = evaluate_line(group.tests, fields)
            except FieldIndexError:
                if no_fail:
                    skip = True
                    break
                raise
            except NumericConversionError:
                if no_fail:
                    skip = True
                    break
                raise

            if passed:
                matched.append(group.name)
                if not all_matches:
                    break

        if skip:
            continue

        if not matched:
            if drop:
                continue
            state = default
        else:
            state = ",".join(matched)

        fields.append(state)

        if aligner is not None:
            aligner.write_row(fields)
        else:
            sys.stdout.write(out_delim.join(fields) + "\n")

    raise SystemExit(0)
