from __future__ import annotations

import sys
from typing import Annotated, Optional

import typer
from rich.console import Console

from sodatools_core.common.cli_helpers import (
    HELP_ALIGN,
    HELP_DELIMITER,
    HELP_EXAMPLE,
    HELP_HEADER_PASSTHRU,
    eager_print_callback,
)
from sodatools_core.common.align import StreamingAligner
from sodatools_core.common.parsing import parse_iso8601
from sodatools_core.common.reader import split_fields, warn_if_tty

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data weather | soda kut 6 | soda uniq
  soda sample-data weather | soda kut 6 | soda uniq --count
  soda sample-data weather | soda uniq 6
"""


def _try_parse_datetime_seconds(value: str) -> float | None:
    """Try to parse as datetime, return epoch seconds or None."""
    try:
        return parse_iso8601(value).timestamp()
    except (ValueError, IndexError, TypeError):
        return None


def _try_float(value: str) -> float | None:
    try:
        return float(value)
    except ValueError:
        return None


def _keys_equal(
    a: list[str], b: list[str], key_indices: list[int], time_delta: float
) -> bool:
    """Compare key fields of two rows, with fuzzy time matching."""
    for idx in key_indices:
        va = a[idx] if idx < len(a) else ""
        vb = b[idx] if idx < len(b) else ""

        if va == vb:
            continue

        # Try numeric/datetime fuzzy comparison
        if time_delta > 0:
            # Try datetime
            da = _try_parse_datetime_seconds(va)
            db = _try_parse_datetime_seconds(vb)
            if da is not None and db is not None:
                if abs(da - db) <= time_delta:
                    continue
                return False

            # Try numeric
            fa = _try_float(va)
            fb = _try_float(vb)
            if fa is not None and fb is not None:
                if abs(fa - fb) <= time_delta:
                    continue
                return False

        return False

    return True


def uniq(
    columns: Annotated[
        Optional[list[int]],
        typer.Argument(help="Key columns (1-indexed). Default: all columns."),
    ] = None,
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER),
    ] = None,
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help=HELP_HEADER_PASSTHRU),
    ] = None,
    count: Annotated[
        bool,
        typer.Option("--count", "-c", help="Prepend count of consecutive duplicates"),
    ] = False,
    time_delta: Annotated[
        float,
        typer.Option("--time-delta", help="Seconds within which timestamps/numbers are considered equal"),
    ] = 0.01,
    align_cols: Annotated[
        bool,
        typer.Option("--align", help=HELP_ALIGN),
    ] = False,
    example: Annotated[
        bool,
        typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE),
    ] = False,
) -> None:
    """Deduplicate consecutive rows (like uniq, but column-aware)."""
    warn_if_tty(sys.stdin, "uniq")

    out_delim = delimiter if delimiter is not None else " "
    aligner = StreamingAligner(out_delim) if align_cols else None

    # Pass through headers
    if header is not None:
        for _ in range(header):
            line = sys.stdin.readline()
            if not line:
                break
            if count:
                sys.stdout.write("_count" + out_delim)
            sys.stdout.write(line)

    prev_fields: list[str] | None = None
    dup_count = 0
    key_indices: list[int] | None = None  # resolved on first row

    def _emit(fields: list[str], n: int) -> None:
        if count:
            out = [str(n)] + fields
        else:
            out = fields
        if aligner is not None:
            aligner.write_row(out)
        else:
            sys.stdout.write(out_delim.join(out) + "\n")

    for line in sys.stdin:
        stripped = line.rstrip("\r\n")
        if not stripped:
            continue

        fields = split_fields(line, delimiter)

        # Resolve key indices on first row
        if key_indices is None:
            if columns:
                key_indices = [
                    (c - 1 if c > 0 else len(fields) + c) for c in columns
                ]
            else:
                key_indices = list(range(len(fields)))

        if prev_fields is None:
            prev_fields = fields
            dup_count = 1
        elif _keys_equal(fields, prev_fields, key_indices, time_delta):
            dup_count += 1
        else:
            _emit(prev_fields, dup_count)
            prev_fields = fields
            dup_count = 1

    # Emit last group
    if prev_fields is not None:
        _emit(prev_fields, dup_count)

    raise SystemExit(0)
