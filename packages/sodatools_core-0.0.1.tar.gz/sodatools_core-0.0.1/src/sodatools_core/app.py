import typer

from sodatools_core.align.cli import align
from sodatools_core.filter.cli import filter_cmd
from sodatools_core.coltest.cli import coltest
from sodatools_core.cutw.cli import cutw
from sodatools_core.events.cli import events
from sodatools_core.delta.cli import delta
from sodatools_core.kut.cli import kut
from sodatools_core.nf.cli import nf
from sodatools_core.plot.cli import plot
from sodatools_core.radix.cli import radix
from sodatools_core.sample.cli import sample
from sodatools_core.sampledata.cli import sampledata
from sodatools_core.smooth.cli import smooth
from sodatools_core.stats.cli import stats
from sodatools_core.tag.cli import tag
from sodatools_core.uniq.cli import uniq

app = typer.Typer()


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    """sodatools — a collection of CLI tools for text processing."""
    if ctx.invoked_subcommand is None:
        ctx.get_help()


app.command("align")(align)
app.command("filter")(filter_cmd)
app.command("coltest")(coltest)
app.command("cutw")(cutw)
app.command("delta")(delta)
app.command("events")(events)
app.command("kut")(kut)
app.command("nf")(nf)
app.command("plot")(plot)
app.command("radix")(radix)
app.command("sample")(sample)
app.command("sample-data")(sampledata)
app.command("smooth")(smooth)
app.command("stats")(stats)
app.command("tag")(tag)
app.command("uniq")(uniq)
