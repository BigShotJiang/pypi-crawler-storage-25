from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Union

from lark import Lark, Transformer, v_args

_GRAMMAR_PATH = Path(__file__).parent / "grammar.lark"
_parser = Lark.open(str(_GRAMMAR_PATH), parser="lalr")


# --- Data types ---

# Sentinel value for $ (edge marker)
_DOLLAR = object()


@dataclass(frozen=True)
class ColRef:
    """A column reference. Positive = 1-indexed from start, negative = from end (-1 = last)."""

    value: int


@dataclass(frozen=True)
class SingleColumn:
    ref: ColRef


@dataclass(frozen=True)
class ColumnRange:
    start: ColRef
    end: ColRef
    step: int = 1


@dataclass(frozen=True)
class FirstN:
    """$-N: first N columns."""

    count: int
    step: int = 1


@dataclass(frozen=True)
class LastN:
    """N-$: last N columns."""

    count: int
    step: int = 1


@dataclass(frozen=True)
class OpenEnd:
    """N-: from column N to end."""

    start: ColRef
    step: int = 1


@dataclass(frozen=True)
class Exclusion:
    inner: Union[SingleColumn, ColumnRange, FirstN, LastN, OpenEnd]


@dataclass(frozen=True)
class LiteralText:
    text: str


@dataclass(frozen=True)
class Separator:
    pass


ColumnSpec = Union[
    SingleColumn, ColumnRange, FirstN, LastN, OpenEnd, Exclusion, LiteralText, Separator
]


def is_dynamic(spec: ColumnSpec) -> bool:
    """Check if a spec requires the field count to resolve."""
    if isinstance(spec, (FirstN, LastN, OpenEnd)):
        return True
    if isinstance(spec, SingleColumn):
        return spec.ref.value < 0
    if isinstance(spec, ColumnRange):
        return spec.start.value < 0 or spec.end.value < 0
    if isinstance(spec, Exclusion):
        return is_dynamic(spec.inner)
    return False


# --- Transformer ---


def _make_range(start: ColRef | object, end: ColRef | object, step: int = 1) -> ColumnSpec:
    """Interpret a range, handling $ sentinels for FirstN/LastN."""
    if start is _DOLLAR and isinstance(end, ColRef):
        # $-N: first N columns
        return FirstN(count=end.value, step=step)
    if isinstance(start, ColRef) and end is _DOLLAR:
        # N-$: last N columns
        return LastN(count=start.value, step=step)
    if isinstance(start, ColRef) and isinstance(end, ColRef):
        return ColumnRange(start=start, end=end, step=step)
    # $-$ is nonsensical
    raise ValueError("Invalid range: both endpoints cannot be $")


@v_args(inline=True)
class SpecTransformer(Transformer):
    def start(self, spec: ColumnSpec) -> ColumnSpec:
        return spec

    def spec(self, inner: ColumnSpec) -> ColumnSpec:
        return inner

    def exclusion(self, inner: ColumnSpec) -> Exclusion:
        return Exclusion(inner=inner)

    def literal(self, token: str) -> LiteralText:
        # Strip T" prefix and " suffix
        text = str(token)[2:-1]
        return LiteralText(text=text)

    def separator(self, _token: str) -> Separator:
        return Separator()

    # Column selection rules

    def single(self, ref: object) -> ColumnSpec:
        if ref is _DOLLAR:
            # Bare $ means last column -> ColRef(-1)
            return SingleColumn(ref=ColRef(value=-1))
        assert isinstance(ref, ColRef)
        return SingleColumn(ref=ref)

    def bounded_range(self, start: object, end: object) -> ColumnSpec:
        return _make_range(start, end)

    def stepped_range(self, start: object, end: object, step: str) -> ColumnSpec:
        return _make_range(start, end, step=int(step))

    def open_end_range(self, start: object) -> ColumnSpec:
        if start is _DOLLAR:
            raise ValueError("Invalid spec: $- is ambiguous. Use $-N for first N columns.")
        assert isinstance(start, ColRef)
        return OpenEnd(start=start)

    def stepped_open_end(self, start: object, step: str) -> ColumnSpec:
        if start is _DOLLAR:
            raise ValueError("Invalid spec: $- is ambiguous. Use $-N for first N columns.")
        assert isinstance(start, ColRef)
        return OpenEnd(start=start, step=int(step))

    # Column references

    def absolute(self, token: str) -> ColRef:
        return ColRef(value=int(token))

    def negative(self, token: str) -> ColRef:
        return ColRef(value=int(token))

    def dollar(self, _token: str) -> object:
        return _DOLLAR

    # Terminal handlers — only for terminals whose values we need
    def POSINT(self, token: str) -> str:
        return str(token)

    def NEGINT(self, token: str) -> str:
        return str(token)

    def LITERAL(self, token: str) -> str:
        return str(token)

    def SEP(self, token: str) -> str:
        return str(token)


_transformer = SpecTransformer()


def parse_spec(expr: str) -> ColumnSpec:
    """Parse a column spec expression string into a ColumnSpec."""
    tree = _parser.parse(expr)
    return _transformer.transform(tree)
