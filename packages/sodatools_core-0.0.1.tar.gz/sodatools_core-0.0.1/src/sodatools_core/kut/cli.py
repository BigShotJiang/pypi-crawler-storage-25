from __future__ import annotations

import sys
from typing import Annotated, Optional

import typer
from lark.exceptions import LarkError
from rich.console import Console

from sodatools_core.common.align import StreamingAligner
from sodatools_core.common.cli_helpers import (
    HELP_ALIGN,
    HELP_DELIMITER_INPUT,
    HELP_EXAMPLE,
    HELP_NO_FAIL,
    eager_print_callback,
)
from sodatools_core.common.exceptions import FieldIndexError
from sodatools_core.common.reader import split_fields, warn_if_tty
from sodatools_core.kut.evaluator import SpecResolver, format_output
from sodatools_core.kut.parser import (
    ColumnSpec,
    Exclusion,
    LiteralText,
    Separator,
    parse_spec,
)

err_console = Console(stderr=True)

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data small | soda kut 1 3
  soda sample-data weather | soda kut 1-3
  soda sample-data weather | soda kut 1-3 S 5-6
  soda sample-data small | soda kut '^2'
"""

_SYNTAX = """\
[bold]Column spec syntax:[/]  each positional argument selects columns for output.

[bold]Single columns:[/]
  [blue]3[/]         column 3 (1-indexed)
  [blue]-1[/]        last column
  [blue]-2[/]        second from last

[bold]Ranges:[/]
  [blue]1-3[/]       columns 1, 2, 3
  [blue]3-1[/]       reverse: 3, 2, 1
  [blue]3-[/]        column 3 to end (open end)
  [blue]$-3[/]       first 3 columns
  [blue]3-$[/]       last 3 columns
  [blue]-2--1[/]     second-from-last to last

[bold]Step ranges:[/]
  [blue]1-10:2[/]    every 2nd from 1-10: 1, 3, 5, 7, 9

[bold]Exclusion:[/]  (cannot mix with inclusion specs)
  [blue]^3[/]        all columns except 3
  [blue]^2-4[/]      all columns except 2, 3, 4

[bold]Insertion:[/]
  [blue]S[/]         insert separator string (default " | ", set with --sep)
  [blue]T"text"[/]   insert literal text

[bold]Examples:[/]
  soda kut 1 3 5                 columns 1, 3, 5
  soda kut 3-1                   columns 3, 2, 1 (reversed)
  soda kut 1-3 S 5-7             cols 1-3, separator, cols 5-7
  soda kut 1 'T"->"' 2           col 1, literal "->", col 2
  soda kut '^3'                  all columns except 3
  soda kut -- -1                 last column (-- to stop flag parsing)
"""


def _validate_no_mixed_exclusions(specs: list[ColumnSpec]) -> None:
    """Ensure exclusions are not mixed with inclusion specs."""
    has_exclusion = any(isinstance(s, Exclusion) for s in specs)
    has_inclusion = any(
        not isinstance(s, (Exclusion, LiteralText, Separator)) for s in specs
    )
    if has_exclusion and has_inclusion:
        err_console.print(
            "Error: cannot mix exclusion (^) and inclusion specs", style="red"
        )
        raise SystemExit(2)


def kut(
    specs: Annotated[
        Optional[list[str]],
        typer.Argument(help="Column spec expressions, e.g. '1-3' '5' '$-2'"),
    ] = None,
    syntax: Annotated[
        bool, typer.Option("--syntax", callback=eager_print_callback(_SYNTAX), is_eager=True, help="Show column spec syntax reference and exit")
    ] = False,
    example: Annotated[
        bool,
        typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE),
    ] = False,
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER_INPUT),
    ] = None,
    output_delimiter: Annotated[
        Optional[str],
        typer.Option("--output-delimiter", "-o", help="Output field delimiter (default: same as input)"),
    ] = None,
    sep: Annotated[
        str,
        typer.Option("--sep", "-s", help="Separator string for S markers"),
    ] = " | ",
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help="Apply column selection to first N header lines"),
    ] = None,
    no_fail: Annotated[
        bool,
        typer.Option("--no-fail", help=HELP_NO_FAIL),
    ] = False,
    align_cols: Annotated[
        bool,
        typer.Option("--align", help=HELP_ALIGN),
    ] = False,
) -> None:
    """Select, reorder, and format columns from stdin."""
    if not specs:
        err_console.print("Error: no column specs provided (use --syntax for help)", style="red")
        raise SystemExit(2)

    warn_if_tty(sys.stdin, "kut")

    # Determine output delimiter
    if output_delimiter is not None:
        out_delim = output_delimiter
    elif delimiter is not None:
        out_delim = delimiter
    else:
        out_delim = " "

    # Parse all specs upfront
    parsed_specs: list[ColumnSpec] = []
    for expr in specs:
        try:
            parsed_specs.append(parse_spec(expr))
        except LarkError as e:
            err_console.print(f"Error parsing '{expr}': {e}", style="red")
            raise SystemExit(2)

    _validate_no_mixed_exclusions(parsed_specs)

    resolver = SpecResolver(parsed_specs, sep)
    aligner = StreamingAligner(out_delim) if align_cols else None

    def _process_line(line: str) -> None:
        fields = split_fields(line, delimiter)

        num_fields = len(fields)
        try:
            plan = resolver.resolve(num_fields)
        except FieldIndexError as e:
            if no_fail:
                return
            err_console.print(f"Error: {e}", style="red")
            raise SystemExit(2)

        try:
            output = format_output(plan.segments, fields, out_delim)
        except (IndexError, FieldIndexError) as e:
            if no_fail:
                return
            err_console.print(f"Error: {e}", style="red")
            raise SystemExit(2)

        if aligner is not None:
            aligner.write_row(output.split(out_delim))
        else:
            sys.stdout.write(output + "\n")

    # Process header lines (same column selection)
    if header is not None:
        for _ in range(header):
            line = sys.stdin.readline()
            if not line:
                break
            _process_line(line)

    # Process data lines
    for line in sys.stdin:
        _process_line(line)

    raise SystemExit(0)
