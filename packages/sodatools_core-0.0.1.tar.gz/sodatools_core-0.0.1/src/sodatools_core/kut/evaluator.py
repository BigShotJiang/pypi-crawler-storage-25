from __future__ import annotations

from dataclasses import dataclass

from sodatools_core.common.exceptions import FieldIndexError
from sodatools_core.kut.parser import (
    ColRef,
    ColumnRange,
    ColumnSpec,
    Exclusion,
    FirstN,
    LastN,
    LiteralText,
    OpenEnd,
    Separator,
    SingleColumn,
    is_dynamic,
)

# A resolved segment is either a list of 1-based column indices or a literal string.
ResolvedSegment = list[int] | str


def resolve_ref(ref: ColRef, num_fields: int, *, validate: bool = True) -> int:
    """Resolve a ColRef to a concrete 1-based index."""
    if ref.value > 0:
        idx = ref.value
    else:
        # -1 -> num_fields, -2 -> num_fields - 1, etc.
        idx = num_fields + ref.value + 1
    if validate and (idx < 1 or idx > num_fields):
        raise FieldIndexError(ref.value, num_fields)
    return idx


def resolve_spec(
    spec: ColumnSpec, num_fields: int, sep_string: str
) -> ResolvedSegment:
    """Resolve a single ColumnSpec to concrete column indices or a string."""
    if isinstance(spec, SingleColumn):
        return [resolve_ref(spec.ref, num_fields)]

    if isinstance(spec, ColumnRange):
        start = resolve_ref(spec.start, num_fields)
        end = resolve_ref(spec.end, num_fields)
        if start <= end:
            return list(range(start, end + 1, spec.step))
        else:
            return list(range(start, end - 1, -spec.step))

    if isinstance(spec, FirstN):
        end = min(spec.count, num_fields)
        return list(range(1, end + 1, spec.step))

    if isinstance(spec, LastN):
        start = max(1, num_fields - spec.count + 1)
        return list(range(start, num_fields + 1, spec.step))

    if isinstance(spec, OpenEnd):
        start = resolve_ref(spec.start, num_fields)
        return list(range(start, num_fields + 1, spec.step))

    if isinstance(spec, Exclusion):
        excluded = set(resolve_spec(spec.inner, num_fields, sep_string))
        return [i for i in range(1, num_fields + 1) if i not in excluded]

    if isinstance(spec, LiteralText):
        return spec.text

    if isinstance(spec, Separator):
        return sep_string

    raise ValueError(f"Unknown spec type: {type(spec)}")


@dataclass
class ResolvedPlan:
    """Pre-resolved output plan. Reused when field count matches."""

    num_fields: int
    segments: list[ResolvedSegment]


class SpecResolver:
    """Resolves column specs with static/dynamic optimization.

    Static specs (no negative refs, no LastN, no OpenEnd) are resolved once.
    Dynamic specs are resolved per-line, cached by num_fields.
    """

    def __init__(self, specs: list[ColumnSpec], sep_string: str) -> None:
        self.specs = specs
        self.sep_string = sep_string
        self._static_indices: list[int] = []
        self._dynamic_indices: list[int] = []
        self._static_resolved: dict[int, ResolvedSegment] = {}
        self._static_done = False
        self._cache: ResolvedPlan | None = None

        # Classify specs
        for i, spec in enumerate(specs):
            if is_dynamic(spec):
                self._dynamic_indices.append(i)
            else:
                self._static_indices.append(i)

    def _resolve_static(self, num_fields: int) -> None:
        """Resolve static specs once on first call (needs real num_fields for validation)."""
        if self._static_done:
            return
        for i in self._static_indices:
            self._static_resolved[i] = resolve_spec(
                self.specs[i], num_fields, self.sep_string
            )
        self._static_done = True

    def resolve(self, num_fields: int) -> ResolvedPlan:
        if self._cache is not None and self._cache.num_fields == num_fields:
            return self._cache

        self._resolve_static(num_fields)

        segments: list[ResolvedSegment] = [None] * len(self.specs)  # type: ignore[list-item]

        # Fill in static segments
        for i, seg in self._static_resolved.items():
            segments[i] = seg

        # Resolve dynamic segments
        for i in self._dynamic_indices:
            segments[i] = resolve_spec(self.specs[i], num_fields, self.sep_string)

        plan = ResolvedPlan(num_fields=num_fields, segments=segments)
        self._cache = plan
        return plan


def format_output(
    segments: list[ResolvedSegment],
    fields: list[str],
    output_delim: str,
) -> str:
    """Build the output string from resolved segments and field values."""
    output_parts: list[str] = []
    need_delim = False

    for segment in segments:
        if isinstance(segment, str):
            # Literal or Separator — insert raw, no delimiter padding
            output_parts.append(segment)
            need_delim = False
        else:
            # List of 1-based column indices
            for i, idx in enumerate(segment):
                if need_delim or i > 0:
                    output_parts.append(output_delim)
                output_parts.append(fields[idx - 1])
                need_delim = True

    return "".join(output_parts)
