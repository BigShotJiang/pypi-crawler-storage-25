from __future__ import annotations

import statistics
import sys
from collections import deque
from typing import Annotated, Optional

import typer
from rich.console import Console

from sodatools_core.common.cli_helpers import (
    HELP_ALIGN,
    HELP_DELIMITER,
    HELP_EXAMPLE,
    HELP_HEADER_PASSTHRU,
    eager_print_callback,
)
from sodatools_core.common.align import StreamingAligner
from sodatools_core.common.reader import split_fields, warn_if_tty

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data weather | soda smooth 5 -H 1
  soda sample-data weather | soda smooth 5 -H 1 -m mean
  soda sample-data numeric | soda smooth 10 --no-trim
"""


def _try_float(val: str) -> float | None:
    try:
        return float(val)
    except ValueError:
        return None


def _smooth_values(vals: list[float | None], method: str) -> str:
    """Compute mean or median of non-None values."""
    numeric = [v for v in vals if v is not None]
    if not numeric:
        return ""
    if method == "median":
        return f"{statistics.median(numeric):.4g}"
    return f"{statistics.mean(numeric):.4g}"


def _emit_row(
    passthru_row: list[str],
    window_rows: list[list[str]],
    n_passthru: int,
    ncols: int,
    method: str,
    out_delim: str,
    aligner: StreamingAligner | None,
) -> None:
    """Emit one output row."""
    parts: list[str] = []
    for col_idx in range(n_passthru):
        if col_idx < len(passthru_row):
            parts.append(passthru_row[col_idx])
        else:
            parts.append("")
    for col_idx in range(n_passthru, ncols):
        col_vals = [
            _try_float(r[col_idx]) if col_idx < len(r) else None
            for r in window_rows
        ]
        parts.append(_smooth_values(col_vals, method))

    if aligner is not None:
        aligner.write_row(parts)
    else:
        sys.stdout.write(out_delim.join(parts) + "\n")


def smooth(
    window: Annotated[
        int,
        typer.Argument(help="Smoothing window size"),
    ],
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER),
    ] = None,
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help=HELP_HEADER_PASSTHRU),
    ] = None,
    passthru: Annotated[
        Optional[int],
        typer.Option("--passthru", "-p", help="Pass first N columns through unsmoothed (default: 1 if >1 col, 0 if 1 col)"),
    ] = None,
    method: Annotated[
        str,
        typer.Option("--method", "-m", help="Smoothing method: median or mean"),
    ] = "median",
    no_trim: Annotated[
        bool,
        typer.Option("--no-trim", help="Keep all rows (partial windows at edges)"),
    ] = False,
    align_cols: Annotated[
        bool,
        typer.Option("--align", help=HELP_ALIGN),
    ] = False,
    example: Annotated[
        bool,
        typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE),
    ] = False,
) -> None:
    """Apply sliding window smoothing to numeric columns."""
    warn_if_tty(sys.stdin, "smooth")

    out_delim = delimiter if delimiter is not None else " "
    trim = not no_trim
    aligner = StreamingAligner(out_delim) if align_cols else None

    # Read headers
    if header is not None:
        for _ in range(header):
            line = sys.stdin.readline()
            if not line:
                break
            sys.stdout.write(line)

    if window < 1:
        raise SystemExit(0)

    half = window // 2
    n_passthru = passthru
    ncols: int | None = None

    def _resolve(row: list[str]) -> None:
        nonlocal n_passthru, ncols
        ncols = len(row)
        if n_passthru is None:
            n_passthru = 1 if ncols > 1 else 0

    if trim:
        # Streaming trim: buffer exactly `window` rows, emit center on each step.
        buf: deque[list[str]] = deque()

        for line in sys.stdin:
            stripped = line.rstrip("\r\n")
            if not stripped:
                continue
            row = split_fields(line, delimiter)
            if ncols is None:
                _resolve(row)
            buf.append(row)

            if len(buf) == window:
                _emit_row(buf[half], list(buf), n_passthru, ncols, method, out_delim, aligner)
                buf.popleft()

    else:
        # Streaming no-trim: buffer `half` rows of lookahead.
        # We delay emission by `half` rows so we have future context.
        # Each emitted row i uses window: rows[i-half .. i+half] (clamped).
        #
        # Maintain two deques:
        #   `past`: rows already emitted-past (up to `half` rows behind current)
        #   `future`: rows buffered ahead (up to `half` rows)
        # When a new row arrives, it goes into `future`.
        # When `future` has `half` rows, the oldest unemitted row can be processed.

        all_past: deque[list[str]] = deque(maxlen=half)  # rows before emit point
        unemitted: deque[list[str]] = deque()  # rows waiting for enough future context
        future_count = 0

        for line in sys.stdin:
            stripped = line.rstrip("\r\n")
            if not stripped:
                continue
            row = split_fields(line, delimiter)
            if ncols is None:
                _resolve(row)
            unemitted.append(row)

            # Can we emit the oldest unemitted row? It needs `half` rows after it.
            # unemitted[0] is the row to emit. Rows after it in unemitted are its future.
            while len(unemitted) > half:
                emit_row = unemitted.popleft()
                # Window = past rows + emit_row + next `half` rows from unemitted
                window_rows = list(all_past) + [emit_row] + list(unemitted)[:half]
                _emit_row(emit_row, window_rows, n_passthru, ncols, method, out_delim, aligner)
                all_past.append(emit_row)

        # Flush remaining unemitted rows (tail, shrinking future window)
        while unemitted:
            emit_row = unemitted.popleft()
            window_rows = list(all_past) + [emit_row] + list(unemitted)[:half]
            _emit_row(emit_row, window_rows, n_passthru, ncols, method, out_delim, aligner)
            all_past.append(emit_row)

    raise SystemExit(0)
