from __future__ import annotations

import sys
from typing import Annotated, Optional

import typer
from rich.console import Console

from sodatools_core.common.cli_helpers import (
    HELP_ALIGN,
    HELP_DELIMITER,
    HELP_EXAMPLE,
    HELP_HEADER_PASSTHRU,
    eager_print_callback,
)
from sodatools_core.common.align import StreamingAligner
from sodatools_core.common.parsing import text_to_int_array
from sodatools_core.common.reader import split_fields, warn_if_tty

_EXAMPLES = """\
[bold]Examples:[/]
  soda sample-data weather | soda delta 2 3 -H 1
  soda sample-data weather | soda delta 2-5 --append -H 1
  soda sample-data numeric | soda delta --keep-first
"""


def _try_float(val: str) -> float | None:
    try:
        return float(val)
    except ValueError:
        return None


def delta(
    columns: Annotated[
        Optional[list[str]],
        typer.Argument(help="Columns to diff (1-indexed, ranges like 2-5). Default: all numeric."),
    ] = None,
    delimiter: Annotated[
        Optional[str],
        typer.Option("--delimiter", "-d", help=HELP_DELIMITER),
    ] = None,
    header: Annotated[
        Optional[int],
        typer.Option("--header", "-H", help=HELP_HEADER_PASSTHRU),
    ] = None,
    append: Annotated[
        bool,
        typer.Option("--append", help="Append diff columns instead of replacing originals"),
    ] = False,
    ref: Annotated[
        Optional[int],
        typer.Option("--ref", help="Diff against row N (1-indexed) instead of previous row"),
    ] = None,
    keep_first: Annotated[
        bool,
        typer.Option("--keep-first", help="Emit first row with zeros instead of dropping"),
    ] = False,
    align_cols: Annotated[
        bool,
        typer.Option("--align", help=HELP_ALIGN),
    ] = False,
    example: Annotated[
        bool,
        typer.Option("--example", callback=eager_print_callback(_EXAMPLES), is_eager=True, help=HELP_EXAMPLE),
    ] = False,
) -> None:
    """Compute row-to-row differences for numeric columns."""
    warn_if_tty(sys.stdin, "delta")

    out_delim = delimiter if delimiter is not None else " "
    aligner = StreamingAligner(out_delim) if align_cols else None

    # Expand column ranges (e.g. "2-5" -> [2, 3, 4, 5])
    expanded_cols: list[int] | None = None
    if columns:
        expanded_cols = []
        for spec in columns:
            expanded_cols.extend(text_to_int_array(spec))

    # Pass through headers (with extra columns if append mode)
    if header is not None:
        for _ in range(header):
            line = sys.stdin.readline()
            if not line:
                break
            if append:
                fields = split_fields(line, delimiter)
                diff_labels = [f"d_{f}" for f in fields]
                if expanded_cols:
                    diff_labels = [
                        diff_labels[(c - 1 if c > 0 else len(fields) + c)]
                        for c in expanded_cols
                    ]
                sys.stdout.write(
                    out_delim.join(fields + diff_labels) + "\n"
                )
            else:
                sys.stdout.write(line)

    diff_col_indices: list[int] | None = None  # resolved on first row
    prev_row: list[str] | None = None
    ref_row: list[str] | None = None
    row_num = 0

    def _resolve_diff_cols(fields: list[str]) -> list[int]:
        if expanded_cols:
            return [(c - 1 if c > 0 else len(fields) + c) for c in expanded_cols]
        # Auto-detect: all columns that parse as float
        return [i for i, f in enumerate(fields) if _try_float(f) is not None]

    def _compute_diff(current: list[str], reference: list[str]) -> list[str]:
        assert diff_col_indices is not None
        diffs: list[str] = []
        for idx in diff_col_indices:
            cv = _try_float(current[idx]) if idx < len(current) else None
            rv = _try_float(reference[idx]) if idx < len(reference) else None
            if cv is not None and rv is not None:
                d = cv - rv
                diffs.append(f"{d:g}")
            else:
                diffs.append("")
        return diffs

    def _emit(fields: list[str], diffs: list[str]) -> None:
        assert diff_col_indices is not None
        if append:
            out = fields + diffs
        else:
            # Replace diff columns in-place
            out = list(fields)
            for i, idx in enumerate(diff_col_indices):
                if idx < len(out):
                    out[idx] = diffs[i]
        if aligner is not None:
            aligner.write_row(out)
        else:
            sys.stdout.write(out_delim.join(out) + "\n")

    for line in sys.stdin:
        stripped = line.rstrip("\r\n")
        if not stripped:
            continue

        fields = split_fields(line, delimiter)
        row_num += 1

        # Resolve diff columns on first row
        if diff_col_indices is None:
            diff_col_indices = _resolve_diff_cols(fields)

        # Handle --ref mode
        if ref is not None and row_num == ref:
            ref_row = fields

        reference = ref_row if ref is not None else prev_row

        if reference is None:
            # First row (or ref row not yet seen)
            if keep_first:
                zeros = ["0"] * len(diff_col_indices)
                _emit(fields, zeros)
        else:
            diffs = _compute_diff(fields, reference)
            _emit(fields, diffs)

        if ref is None:
            prev_row = fields

    raise SystemExit(0)
