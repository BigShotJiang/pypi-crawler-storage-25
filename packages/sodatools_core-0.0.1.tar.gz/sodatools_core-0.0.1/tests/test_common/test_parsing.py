from __future__ import annotations

import pytest

from sodatools_core.common.parsing import parse_duration, parse_iso8601, text_to_int_array


class TestParseDuration:
    def test_seconds(self):
        assert parse_duration("30s") == 30.0

    def test_minutes(self):
        assert parse_duration("5m") == 300.0

    def test_hours(self):
        assert parse_duration("2h") == 7200.0

    def test_days(self):
        assert parse_duration("1d") == 86400.0

    def test_fractional(self):
        assert parse_duration("1.5h") == 5400.0

    def test_bare_number(self):
        assert parse_duration("60") == 60.0

    def test_bare_float(self):
        assert parse_duration("0.5") == 0.5

    def test_invalid(self):
        with pytest.raises(ValueError, match="Invalid duration"):
            parse_duration("abc")

    def test_invalid_unit(self):
        with pytest.raises(ValueError, match="Invalid duration"):
            parse_duration("5x")


class TestParseIso8601:
    def test_date_only(self):
        dt = parse_iso8601("2024-01-15")
        assert dt.year == 2024 and dt.month == 1 and dt.day == 15

    def test_datetime(self):
        dt = parse_iso8601("2024-01-15T10:30:00")
        assert dt.hour == 10 and dt.minute == 30

    def test_utc_z(self):
        dt = parse_iso8601("2024-01-15T10:30:00Z")
        assert dt.tzinfo is not None

    def test_with_offset(self):
        dt = parse_iso8601("2024-01-15T10:30:00+05:00")
        assert dt.utcoffset().total_seconds() == 18000


class TestTextToIntArray:
    def test_single(self):
        assert text_to_int_array("3") == [3]

    def test_range(self):
        assert text_to_int_array("2-5") == [2, 3, 4, 5]

    def test_comma_list(self):
        assert text_to_int_array("1,3,5") == [1, 3, 5]

    def test_mixed(self):
        assert text_to_int_array("1-3,7,9-11") == [1, 2, 3, 7, 9, 10, 11]
