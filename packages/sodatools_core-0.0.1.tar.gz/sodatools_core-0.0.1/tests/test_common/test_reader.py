from __future__ import annotations

from sodatools_core.common.reader import split_fields


class TestSplitFields:
    def test_whitespace_default(self):
        assert split_fields("  a  b  c  \n", None) == ["a", "b", "c"]

    def test_comma_delimiter(self):
        assert split_fields("a,b,c\n", ",") == ["a", "b", "c"]

    def test_tab_delimiter(self):
        assert split_fields("a\tb\tc\n", "\t") == ["a", "b", "c"]

    def test_strips_newline(self):
        assert split_fields("hello world\r\n", None) == ["hello", "world"]

    def test_single_field(self):
        assert split_fields("abc\n", None) == ["abc"]

    def test_empty_after_strip(self):
        assert split_fields("\n", None) == []
