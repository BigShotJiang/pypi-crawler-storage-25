from __future__ import annotations

from sodatools_core.common.align import StreamingAligner, _is_numeric


class TestIsNumeric:
    def test_integer(self):
        assert _is_numeric("42")

    def test_negative(self):
        assert _is_numeric("-3.14")

    def test_scientific(self):
        assert _is_numeric("1e5")

    def test_string(self):
        assert not _is_numeric("abc")

    def test_empty(self):
        assert not _is_numeric("")

    def test_mixed(self):
        assert not _is_numeric("12abc")


class TestStreamingAligner:
    def test_basic_formatting(self):
        a = StreamingAligner(" ")
        # First row establishes widths
        row1 = a.format_row(["abc", "12", "x"])
        row2 = a.format_row(["de", "345", "yz"])
        # Second row should be padded to match widths
        assert len(row2.split()) == 3

    def test_numeric_right_justified(self):
        a = StreamingAligner(" ")
        a.format_row(["abc", "12"])
        a.format_row(["def", "345"])
        row = a.format_row(["gh", "6"])
        # numeric column "6" should be right-padded/justified
        parts = row.split(" ")
        # The numeric value should have leading spaces
        assert "6" in row
