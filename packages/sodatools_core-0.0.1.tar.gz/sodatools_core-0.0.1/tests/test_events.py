from __future__ import annotations

from tests.conftest import run


class TestEvents:
    def test_basic_events(self, tagged):
        out, _, code = run(["events"], input=tagged)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) >= 3
        # First event should be cold (rows 1-4)
        first = lines[0].split()
        assert first[0] == "cold"

    def test_min_samples(self, tagged):
        out, _, code = run(["events", "--min", "3"], input=tagged)
        assert code == 0
        lines = out.strip().splitlines()
        # Short transients (1-2 rows) should be merged into surrounding events
        states = [l.split()[0] for l in lines]
        # Single-row "hot" at row 11 and single-row "normal" at row 12
        # should be merged, so fewer events
        assert len(lines) < 8

    def test_gap_threshold(self, tagged):
        out, _, code = run(["events", "--gap", "60m"], input=tagged)
        assert code == 0
        lines = out.strip().splitlines()
        # Gap between rows 16 and 17 (2h) should break events
        assert len(lines) >= 4

    def test_merlin_format(self, tagged):
        out, _, code = run(["events", "--merlin"], input=tagged)
        assert code == 0
        first = out.strip().splitlines()[0]
        assert "TYPE=cold" in first
        assert "DUR=" in first
        assert "NUMPTS=" in first
        # Date should have no dashes, time no colons
        fields = first.split()
        assert "-" not in fields[0]  # date
        assert ":" not in fields[1]  # start time

    def test_print_header(self, tagged):
        out, _, code = run(["events", "--print-header"], input=tagged)
        assert code == 0
        header = out.strip().splitlines()[0]
        assert "state" in header
        assert "start" in header
        assert "duration" in header

    def test_print_header_merlin(self, tagged):
        out, _, code = run(["events", "--print-header", "--merlin"], input=tagged)
        assert code == 0
        header = out.strip().splitlines()[0]
        assert "TYPE" in header
        assert "DUR" in header
        assert "NUMPTS" in header

    def test_numeric_time(self):
        data = "1.0 A\n2.0 A\n3.0 B\n4.0 B\n5.0 A\n"
        out, _, code = run(["events"], input=data)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) == 3
        assert lines[0].split()[0] == "A"

    def test_header_skipped(self, weather):
        # Tag weather then pipe to events — simulate with pre-tagged data
        out, _, code = run(["events", "-H", "1"], input="ts state\n1.0 A\n2.0 A\n3.0 B\n")
        assert code == 0
        # Header should NOT appear in output
        assert "ts" not in out

    def test_align(self, tagged):
        out, _, code = run(["events", "--align"], input=tagged)
        assert code == 0
        assert len(out.strip().splitlines()) >= 3

    def test_no_fail(self):
        data = "1.0 A\nbad B\n3.0 C\n"
        out, _, code = run(["events", "--no-fail"], input=data)
        assert code == 0

    def test_empty_input(self):
        out, _, code = run(["events"], input="")
        assert code == 0
        assert out.strip() == ""
