from __future__ import annotations

from tests.conftest import run


class TestRadix:
    def test_dec_to_hex(self, integers):
        out, _, code = run(["radix", "--to", "hex"], input=integers)
        assert code == 0
        first_row = out.strip().splitlines()[0].split()
        # 10 -> 0a, 255 -> ff, 128 -> 80, 0 -> 00
        assert first_row[0] == "0a"
        assert first_row[1] == "ff"
        assert first_row[2] == "80"
        assert first_row[3] == "00"

    def test_dec_to_bin(self, integers):
        out, _, code = run(["radix", "--to", "bin"], input=integers)
        assert code == 0
        first_row = out.strip().splitlines()[0].split()
        assert first_row[0] == "00001010"  # 10
        assert first_row[1] == "11111111"  # 255

    def test_dec_to_oct(self, integers):
        out, _, code = run(["radix", "--to", "oct"], input=integers)
        assert code == 0
        first_row = out.strip().splitlines()[0].split()
        assert first_row[0] == "012"  # 10

    def test_hex_to_dec(self):
        out, _, code = run(["radix", "--from", "hex", "--to", "dec"], input="ff 0a 80\n")
        assert code == 0
        fields = out.strip().split()
        assert fields == ["255", "10", "128"]

    def test_auto_detect(self):
        out, _, code = run(["radix", "--from", "auto", "--to", "dec"], input="0xff 0b1010\n")
        assert code == 0
        fields = out.strip().split()
        assert fields == ["255", "10"]

    def test_specific_columns(self, integers):
        out, _, code = run(["radix", "2", "--to", "hex"], input=integers)
        assert code == 0
        first_row = out.strip().splitlines()[0].split()
        # Column 1 should remain decimal, column 2 should be hex
        assert first_row[0] == "10"
        assert first_row[1] == "ff"

    def test_bits_width(self):
        out, _, code = run(["radix", "--to", "hex", "-b", "16"], input="255\n")
        assert code == 0
        assert out.strip() == "00ff"

    def test_non_integer_passthrough(self, small):
        out, _, code = run(["radix", "--to", "hex", "-H", "1"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        # String columns should pass through unchanged
        assert "alice" in lines[1]

    def test_header_passthrough(self, small):
        out, _, code = run(["radix", "--to", "hex", "-H", "1"], input=small)
        assert code == 0
        assert out.strip().splitlines()[0].split()[0] == "name"

    def test_invalid_from_base(self):
        _, err, code = run(["radix", "--from", "bogus", "--to", "hex"], input="10\n")
        assert code == 2

    def test_invalid_to_base(self):
        _, err, code = run(["radix", "--to", "bogus"], input="10\n")
        assert code == 2

    def test_empty_input(self):
        out, _, code = run(["radix", "--to", "hex"], input="")
        assert code == 0
        assert out.strip() == ""
