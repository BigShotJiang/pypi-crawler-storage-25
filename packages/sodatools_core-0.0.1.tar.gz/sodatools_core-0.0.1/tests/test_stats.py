from __future__ import annotations

from tests.conftest import run


class TestStats:
    def test_basic_with_header(self, weather):
        out, _, code = run(["stats", "-H", "1"], input=weather)
        assert code == 0
        # Should mention row and column counts
        assert "20 rows" in out
        assert "Numeric" in out

    def test_no_header(self, numeric):
        out, _, code = run(["stats"], input=numeric)
        assert code == 0
        assert "20 rows" in out

    def test_null_sentinels(self):
        data = "1 2 3\n4 ? 6\n7 NA 9\n10 11 12\n13 14 15\n"
        out, _, code = run(["stats", "--null", "?", "--null", "NA"], input=data)
        assert code == 0

    def test_no_summary(self, weather):
        out, _, code = run(["stats", "-H", "1", "--no-summary"], input=weather)
        assert code == 0
        assert "Mean" not in out

    def test_no_trend(self, weather):
        out, _, code = run(["stats", "-H", "1", "--no-trend"], input=weather)
        assert code == 0
        assert "Trend" not in out

    def test_no_color(self, weather):
        out, _, code = run(["stats", "-H", "1", "--no-color"], input=weather)
        assert code == 0

    def test_empty_input(self):
        _, _, code = run(["stats"], input="")
        assert code == 2

    def test_header_only(self, header_only):
        _, _, code = run(["stats", "-H", "1"], input=header_only)
        assert code == 2
