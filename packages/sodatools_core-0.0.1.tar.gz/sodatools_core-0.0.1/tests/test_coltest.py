from __future__ import annotations

from tests.conftest import run


class TestColtest:
    def test_numeric_eq(self, small):
        out, _, code = run(["coltest", "2eq42", "-H", "1"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) == 2  # header + alice
        assert "alice" in lines[1]

    def test_numeric_gt(self, small):
        out, _, code = run(["coltest", "2gt50", "-H", "1"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        data = lines[1:]
        # Values > 50: 95, 73, 88, 56, 99, 67, 81, 91, 60 = 9
        assert len(data) == 9

    def test_numeric_lt(self, small):
        out, _, code = run(["coltest", "2lt20", "-H", "1"], input=small)
        assert code == 0
        data = out.strip().splitlines()[1:]
        # Values < 20: 17, 8, 12, 3, 15 = 5
        assert len(data) == 5

    def test_string_eq(self, small):
        out, _, code = run(["coltest", "3seqOK", "-H", "1"], input=small)
        assert code == 0
        data = out.strip().splitlines()[1:]
        assert len(data) == 13

    def test_string_ne(self, small):
        out, _, code = run(["coltest", "3sneOK", "-H", "1"], input=small)
        assert code == 0
        data = out.strip().splitlines()[1:]
        # WARN(4) + ERR(3) = 7
        assert len(data) == 7

    def test_and_logic(self, small):
        out, _, code = run(["coltest", "2gt50", "3seqOK", "-H", "1"], input=small)
        assert code == 0
        data = out.strip().splitlines()[1:]
        # gt50 AND OK: iris(56), leo(67), noah(81), olivia(45 no), sam(60)...
        for line in data:
            fields = line.split()
            assert float(fields[1]) > 50
            assert fields[2] == "OK"

    def test_or_logic(self, small):
        out, _, code = run(["coltest", "--or", "2eq42", "2eq95", "-H", "1"], input=small)
        assert code == 0
        data = out.strip().splitlines()[1:]
        assert len(data) == 2  # alice(42), charlie(95)

    def test_invert(self, small):
        out, _, code = run(["coltest", "--invert", "3seqERR", "-H", "1"], input=small)
        assert code == 0
        data = out.strip().splitlines()[1:]
        # 20 - 3 ERR = 17
        assert len(data) == 17

    def test_count(self, small):
        out, _, code = run(["coltest", "3seqOK", "-H", "1", "--count"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        # Last line is the count (header may be passed through first)
        assert lines[-1].strip() == "13"

    def test_header_passthrough(self, small):
        out, _, code = run(["coltest", "2gt0", "-H", "1"], input=small)
        assert code == 0
        assert "name" in out.strip().splitlines()[0]

    def test_exit_code_1_no_match(self, small):
        _, _, code = run(["coltest", "2gt999", "-H", "1"], input=small)
        assert code == 1

    def test_exit_code_0_match(self, small):
        _, _, code = run(["coltest", "2gt0", "-H", "1"], input=small)
        assert code == 0

    def test_no_fail_skips_bad_rows(self, ragged):
        out, _, code = run(["coltest", "2gt0", "--no-fail"], input=ragged)
        # Should not error — skips rows with missing column 2
        assert code in (0, 1)

    def test_no_expressions_error(self, small):
        _, _, code = run(["coltest"], input=small)
        assert code == 2

    def test_custom_delimiter(self, csv_data):
        out, _, code = run(["coltest", "2gt50", "-d", ","], input=csv_data)
        assert code == 0
        assert "charlie" in out or "eve" in out

    def test_empty_input(self):
        _, _, code = run(["coltest", "1eq1"], input="")
        assert code == 1
