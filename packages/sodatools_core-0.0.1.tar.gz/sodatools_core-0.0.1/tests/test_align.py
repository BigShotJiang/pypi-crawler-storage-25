from __future__ import annotations

from tests.conftest import run


class TestAlign:
    def test_basic_alignment(self, weather):
        out, _, code = run(["align"], input=weather)
        assert code == 0
        lines = out.strip().splitlines()
        # Data rows should all have consistent width
        data_widths = [len(l.rstrip()) for l in lines[1:]]
        assert max(data_widths) - min(data_widths) <= 2

    def test_header_underline(self, weather):
        out, _, code = run(["align", "-H", "1"], input=weather)
        assert code == 0
        lines = out.strip().splitlines()
        # Second line should be dashes (underline)
        assert set(lines[1].replace(" ", "")) == {"-"}

    def test_right_override(self, small):
        out, _, code = run(["align", "--right", "1", "-H", "1"], input=small)
        assert code == 0
        # Column 1 (name) should be right-aligned
        lines = out.strip().splitlines()
        # Data lines: name field should have leading spaces
        data_line = lines[2]  # first data line (after header + underline)
        name_field = data_line.split("  ")[0]
        assert name_field.startswith(" ") or name_field == name_field.strip()

    def test_min_width(self, small):
        out, _, code = run(["align", "-w", "12", "-H", "1"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        # Each column should be at least 12 chars wide
        # Check header underline dashes
        dashes = lines[1].split("  ")
        for d in dashes:
            if d.strip():
                assert len(d) >= 12

    def test_output_delimiter(self, small):
        out, _, code = run(["align", "-o", "|"], input=small)
        assert code == 0
        assert "|" in out

    def test_custom_delimiter_input(self, csv_data):
        out, _, code = run(["align", "-d", ","], input=csv_data)
        assert code == 0
        assert "alice" in out
        lines = out.strip().splitlines()
        assert len(lines) == 8

    def test_empty_input(self):
        out, _, code = run(["align"], input="")
        assert code == 0
        assert out.strip() == ""

    def test_header_only(self, header_only):
        out, _, code = run(["align", "-H", "1"], input=header_only)
        assert code == 0
