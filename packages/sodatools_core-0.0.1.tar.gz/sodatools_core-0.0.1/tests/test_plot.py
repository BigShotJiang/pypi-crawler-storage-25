from __future__ import annotations

import tempfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")

from tests.conftest import run


class TestPlot:
    def test_save_png(self, weather):
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "test.png")
            _, _, code = run(["plot", "2", "-H", "1", "--save", path], input=weather)
            assert code == 0
            assert Path(path).exists()
            assert Path(path).stat().st_size > 0

    def test_no_columns_error(self, weather):
        _, _, code = run(["plot"], input=weather)
        assert code == 2
