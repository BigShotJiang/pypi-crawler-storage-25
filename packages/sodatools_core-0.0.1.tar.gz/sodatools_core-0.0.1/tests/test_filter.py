from __future__ import annotations

from tests.conftest import run


class TestFilterMad:
    def test_basic(self, noisy):
        out, _, code = run(["filter", "2:mad"], input=noisy)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) == 30
        # Row 5 (999.0) and row 15 (-200.0) should be replaced with "?"
        assert "999.0" not in out
        assert "-200.0" not in out
        assert "?" in out

    def test_custom_window_delta(self, noisy):
        out, _, code = run(["filter", "2:mad", "window=5", "delta=2"], input=noisy)
        assert code == 0
        assert "?" in out

    def test_gap_aware(self, noisy):
        out, _, code = run(["filter", "2:mad", "--gap", "30s"], input=noisy)
        assert code == 0
        assert len(out.strip().splitlines()) == 30


class TestFilterRun:
    def test_basic(self, noisy):
        out, _, code = run(["filter", "3:run"], input=noisy)
        assert code == 0
        # Single-row mode glitches (IDLE, ERR) should be replaced with "?"
        lines = out.strip().splitlines()
        assert len(lines) == 30
        # Row 8 had IDLE glitch, row 18 had ERR glitch
        assert "?" in out

    def test_custom_min(self, noisy):
        out, _, code = run(["filter", "3:run", "min=5"], input=noisy)
        assert code == 0


class TestFilterRate:
    def test_max(self, noisy):
        out, _, code = run(["filter", "4:rate", "max=2"], input=noisy)
        assert code == 0
        # Row 12 had pressure jump — should be flagged
        assert "?" in out


class TestFilterRange:
    def test_min_max(self, noisy):
        out, _, code = run(["filter", "2:range", "min=-40", "max=60"], input=noisy)
        assert code == 0
        # 999.0 and -200.0 are outside range
        assert "999.0" not in out
        assert "-200.0" not in out

    def test_min_only(self, noisy):
        out, _, code = run(["filter", "2:range", "min=0"], input=noisy)
        assert code == 0
        assert "-200.0" not in out

    def test_max_only(self, noisy):
        out, _, code = run(["filter", "2:range", "max=100"], input=noisy)
        assert code == 0
        assert "999.0" not in out


class TestFilterClock:
    def test_delta_ref(self, noisy):
        # Column 5 (received) vs column 1 (timestamp), max 10s
        out, _, code = run(["filter", "5:clock", "ref=1", "max=10s"], input=noisy)
        assert code == 0
        # Rows 10 and 25 have clock drift > 10s — should be flagged
        assert "?" in out


class TestFilterMono:
    def test_increasing(self, numeric):
        # Column 2 (counter 1-20) should be monotonically increasing
        out, _, code = run(["filter", "2:mono"], input=numeric)
        assert code == 0
        # All values should pass — counter is monotonic
        assert "?" not in out


class TestFilterOutputModes:
    def test_drop_mode(self, noisy):
        out, _, code = run(["filter", "2:range", "min=-40", "max=60", "--drop"], input=noisy)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) < 30

    def test_mark_mode(self, noisy):
        out, _, code = run(["filter", "2:range", "min=-40", "max=60", "--mark"], input=noisy)
        assert code == 0
        # ANSI escape codes should be present for bad values
        assert "\033[31m" in out

    def test_null_replacement(self, noisy):
        out, _, code = run(["filter", "2:range", "min=-40", "max=60", "--null", "NA"], input=noisy)
        assert code == 0
        assert "NA" in out
        assert "?" not in out

    def test_invert(self, noisy):
        out, _, code = run(["filter", "2:range", "min=-40", "max=60", "--invert"], input=noisy)
        assert code == 0
        # Inverted: good values become "?", bad stay
        lines = out.strip().splitlines()
        assert len(lines) == 30

    def test_invert_drop(self, noisy):
        out, _, code = run(["filter", "2:range", "min=-40", "max=60", "--invert", "--drop"], input=noisy)
        assert code == 0
        lines = out.strip().splitlines()
        # Only bad rows survive — should be 2 (999.0, -200.0)
        assert len(lines) == 2


class TestFilterCrossCutting:
    def test_multiple_expressions(self, noisy):
        out, _, code = run(["filter", "2:mad", "3:run", "--gap", "30s"], input=noisy)
        assert code == 0
        assert "?" in out

    def test_header_passthrough(self, weather):
        out, _, code = run(["filter", "2:range", "min=0", "max=100", "-H", "1"], input=weather)
        assert code == 0
        assert "timestamp" in out.strip().splitlines()[0]

    def test_align(self, noisy):
        out, _, code = run(["filter", "2:range", "min=0", "max=100", "--align"], input=noisy)
        assert code == 0

    def test_no_fail(self, ragged):
        out, _, code = run(["filter", "2:range", "min=0", "--no-fail"], input=ragged)
        assert code == 0

    def test_exit_code_1_drop_all(self):
        _, _, code = run(["filter", "1:range", "min=999", "--drop"], input="1\n2\n3\n")
        assert code == 1

    def test_no_expressions_error(self, noisy):
        _, _, code = run(["filter"], input=noisy)
        assert code == 2

    def test_parse_error(self, noisy):
        _, _, code = run(["filter", "bogus"], input=noisy)
        assert code == 2

    def test_empty_input(self):
        out, _, code = run(["filter", "1:range", "min=0"], input="")
        assert code == 0
        assert out.strip() == ""
