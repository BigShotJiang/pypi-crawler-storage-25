from __future__ import annotations

from tests.conftest import run


class TestKut:
    def test_single_column(self, small):
        out, _, code = run(["kut", "2", "-H", "1"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) == 21
        # Each line should be a single value
        assert lines[1].strip() == "42"

    def test_multiple_columns(self, small):
        out, _, code = run(["kut", "1", "3", "-H", "1"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        assert "alice" in lines[1]
        assert "OK" in lines[1]

    def test_range(self, weather):
        out, _, code = run(["kut", "1-3", "-H", "1"], input=weather)
        assert code == 0
        for line in out.strip().splitlines()[1:]:
            assert len(line.split()) == 3

    def test_reverse_range(self, small):
        out, _, code = run(["kut", "3-1", "-H", "1"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        # First field should be status (was col 3)
        assert lines[1].split()[0] == "OK"

    def test_negative_index(self, small):
        out, _, code = run(["kut", "-H", "1", "--", "-1"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        assert lines[1].strip() == "OK"

    def test_exclusion(self, small):
        out, _, code = run(["kut", "^2", "-H", "1"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        # Should have 2 columns (name, status), not 3
        assert len(lines[1].split()) == 2
        assert "42" not in lines[1]

    def test_output_delimiter(self, small):
        out, _, code = run(["kut", "1", "2", "-o", ",", "-H", "1"], input=small)
        assert code == 0
        assert "alice,42" in out

    def test_header_applies_selection(self, small):
        out, _, code = run(["kut", "1", "3", "-H", "1"], input=small)
        assert code == 0
        header = out.strip().splitlines()[0]
        assert "name" in header
        assert "status" in header
        assert "value" not in header

    def test_no_fail(self, ragged):
        out, _, code = run(["kut", "3", "--no-fail"], input=ragged)
        assert code == 0
        # Should skip rows with < 3 fields
        lines = out.strip().splitlines()
        assert len(lines) > 0

    def test_no_specs_error(self, small):
        _, err, code = run(["kut"], input=small)
        assert code == 2

    def test_custom_input_delimiter(self, csv_data):
        out, _, code = run(["kut", "1", "3", "-d", ","], input=csv_data)
        assert code == 0
        assert "alice" in out
        assert "OK" in out

    def test_align(self, small):
        out, _, code = run(["kut", "1", "2", "-H", "1", "--align"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) == 21

    def test_empty_input(self):
        out, _, code = run(["kut", "1"], input="")
        assert code == 0
        assert out.strip() == ""
