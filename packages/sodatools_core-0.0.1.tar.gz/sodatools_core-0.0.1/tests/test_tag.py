from __future__ import annotations

from tests.conftest import run


class TestTag:
    def test_basic_tagging(self, small):
        out, _, code = run(["tag", "high:", "2gt50", "low:", "2le50", "-H", "1"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) == 21  # header + 20
        # alice has value 42 -> low
        assert lines[1].split()[-1] == "low"
        # charlie has value 95 -> high
        assert lines[3].split()[-1] == "high"

    def test_multi_state(self, small):
        out, _, code = run(
            ["tag", "high:", "2gt80", "mid:", "2gt30", "2le80", "low:", "2le30", "-H", "1"],
            input=small,
        )
        assert code == 0
        lines = out.strip().splitlines()
        # All rows should have a tag
        for line in lines[1:]:
            tag = line.split()[-1]
            assert tag in ("high", "mid", "low")

    def test_default_state(self, small):
        # Only tag high, everything else gets default
        out, _, code = run(["tag", "--default", "other", "high:", "2gt90", "-H", "1"], input=small)
        assert code == 0
        tags = [line.split()[-1] for line in out.strip().splitlines()[1:]]
        assert "high" in tags
        assert "other" in tags

    def test_drop_unmatched(self, small):
        out, _, code = run(["tag", "--drop", "high:", "2gt90", "-H", "1"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        data = lines[1:]
        # Only rows with value > 90: 95, 99, 91 = 3
        assert len(data) == 3

    def test_all_matches(self, small):
        out, _, code = run(
            ["tag", "--all", "big:", "2gt50", "ok:", "3seqOK", "-H", "1"],
            input=small,
        )
        assert code == 0
        # Some rows should have comma-joined tags
        tags = [line.split()[-1] for line in out.strip().splitlines()[1:]]
        assert any("," in t for t in tags)

    def test_header_passthrough_with_tag_label(self, small):
        out, _, code = run(["tag", "high:", "2gt50", "low:", "2le50", "-H", "1"], input=small)
        assert code == 0
        header = out.strip().splitlines()[0]
        assert "_tag" in header

    def test_no_fail(self, ragged):
        out, _, code = run(["tag", "--no-fail", "big:", "2gt50", "small:", "2le50"], input=ragged)
        assert code == 0

    def test_align(self, small):
        out, _, code = run(
            ["tag", "high:", "2gt50", "low:", "2le50", "-H", "1", "--align"],
            input=small,
        )
        assert code == 0
        assert len(out.strip().splitlines()) == 21

    def test_no_args_error(self, small):
        _, _, code = run(["tag"], input=small)
        assert code == 2

    def test_empty_input(self):
        out, _, code = run(["tag", "x:", "1eq1"], input="")
        assert code == 0
        assert out.strip() == ""
