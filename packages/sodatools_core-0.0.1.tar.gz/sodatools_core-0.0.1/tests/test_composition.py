from __future__ import annotations

from tests.conftest import run


class TestComposition:
    def test_tag_to_events(self, weather):
        # Tag -> events pipeline
        tag_out, _, code = run(
            ["tag", "hot:", "2gt20", "cold:", "2le20", "-H", "1"],
            input=weather,
        )
        assert code == 0

        events_out, _, code = run(["events", "-H", "1"], input=tag_out)
        assert code == 0
        lines = events_out.strip().splitlines()
        assert len(lines) >= 2
        states = {l.split()[0] for l in lines}
        assert states <= {"hot", "cold"}

    def test_kut_smooth_align(self, weather):
        # kut -> smooth -> align
        kut_out, _, code = run(["kut", "1", "2", "3", "-H", "1"], input=weather)
        assert code == 0

        smooth_out, _, code = run(["smooth", "3", "-H", "1"], input=kut_out)
        assert code == 0

        align_out, _, code = run(["align", "-H", "1"], input=smooth_out)
        assert code == 0
        lines = align_out.strip().splitlines()
        assert len(lines) >= 3
        # Should have underline
        assert "-" in lines[1]

    def test_coltest_radix(self, small):
        # coltest -> radix
        coltest_out, _, code = run(["coltest", "2gt0", "-H", "1"], input=small)
        assert code == 0

        radix_out, _, code = run(["radix", "2", "--to", "hex", "-H", "1"], input=coltest_out)
        assert code == 0
        assert "alice" in radix_out
        # Value 42 -> 2a in hex
        assert "2a" in radix_out

    def test_sample_delta(self, weather):
        # sample -> delta
        sample_out, _, code = run(["sample", "every", "5", "-H", "1"], input=weather)
        assert code == 0

        delta_out, _, code = run(["delta", "2", "-H", "1"], input=sample_out)
        assert code == 0
        lines = delta_out.strip().splitlines()
        assert len(lines) >= 2  # header + at least 1 diff row

    def test_filter_kut_align(self, noisy):
        # filter -> kut -> align
        filter_out, _, code = run(
            ["filter", "2:range", "min=0", "max=100", "--drop"],
            input=noisy,
        )
        assert code == 0

        kut_out, _, code = run(["kut", "1", "2"], input=filter_out)
        assert code == 0

        align_out, _, code = run(["align"], input=kut_out)
        assert code == 0
        assert len(align_out.strip().splitlines()) >= 2
