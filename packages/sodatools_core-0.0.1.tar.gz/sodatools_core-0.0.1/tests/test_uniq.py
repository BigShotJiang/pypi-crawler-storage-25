from __future__ import annotations

from tests.conftest import run


class TestUniq:
    def test_basic_dedup(self, single_col):
        out, _, code = run(["uniq"], input=single_col)
        assert code == 0
        lines = out.strip().splitlines()
        # 15 rows with consecutive duplicates -> fewer unique groups
        assert len(lines) < 15
        # Verify no two consecutive lines are the same
        for i in range(1, len(lines)):
            assert lines[i] != lines[i - 1]

    def test_count_mode(self, single_col):
        out, _, code = run(["uniq", "--count"], input=single_col)
        assert code == 0
        lines = out.strip().splitlines()
        # First group is 10.0 appearing twice
        first = lines[0].split()
        assert first[0] == "2"
        assert first[1] == "10.0"

    def test_key_columns(self, weather):
        # Dedup on status column (6) only
        out, _, code = run(["uniq", "6", "-H", "1"], input=weather)
        assert code == 0
        lines = out.strip().splitlines()
        # Header + fewer rows (consecutive OK's collapsed)
        assert len(lines) < 21

    def test_header_passthrough(self, weather):
        out, _, code = run(["uniq", "-H", "1"], input=weather)
        assert code == 0
        assert "timestamp" in out.strip().splitlines()[0]

    def test_count_with_header(self, weather):
        out, _, code = run(["uniq", "6", "-H", "1", "--count"], input=weather)
        assert code == 0
        header = out.strip().splitlines()[0]
        assert "_count" in header

    def test_align(self, single_col):
        out, _, code = run(["uniq", "--align"], input=single_col)
        assert code == 0
        assert len(out.strip().splitlines()) > 0

    def test_empty_input(self):
        out, _, code = run(["uniq"], input="")
        assert code == 0
        assert out.strip() == ""

    def test_single_row(self, single_row):
        out, _, code = run(["uniq"], input=single_row)
        assert code == 0
        assert len(out.strip().splitlines()) == 1
