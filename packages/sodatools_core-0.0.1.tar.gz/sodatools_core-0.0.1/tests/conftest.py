from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from sodatools_core.app import app

FIXTURES = Path(__file__).parent / "fixtures"

runner = CliRunner()


def run(args: list[str], input: str | None = None) -> tuple[str, str, int]:
    """Invoke ``soda <args>`` and return (stdout, stderr, exit_code)."""
    result = runner.invoke(app, args, input=input)
    stderr = getattr(result, "stderr", "")
    return result.output, stderr, result.exit_code


def load(name: str) -> str:
    """Read a fixture file and return its contents."""
    return (FIXTURES / name).read_text()


@pytest.fixture()
def weather():
    return load("weather_20.txt")


@pytest.fixture()
def small():
    return load("small.txt")


@pytest.fixture()
def numeric():
    return load("numeric_20.txt")


@pytest.fixture()
def noisy():
    return load("noisy_30.txt")


@pytest.fixture()
def tagged():
    return load("tagged.txt")


@pytest.fixture()
def times():
    return load("times_20.txt")


@pytest.fixture()
def integers():
    return load("integers.txt")


@pytest.fixture()
def wide():
    return load("wide.txt")


@pytest.fixture()
def single_col():
    return load("single_col.txt")


@pytest.fixture()
def csv_data():
    return load("csv_data.txt")


@pytest.fixture()
def single_row():
    return load("single_row.txt")


@pytest.fixture()
def header_only():
    return load("header_only.txt")


@pytest.fixture()
def ragged():
    return load("ragged.txt")
