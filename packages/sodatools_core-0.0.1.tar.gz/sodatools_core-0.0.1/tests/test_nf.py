from __future__ import annotations

from tests.conftest import run, load


class TestNf:
    def test_exact_count_pass(self, small):
        out, _, code = run(["nf", "3", "-H", "1"], input=small)
        assert code == 0
        lines = out.strip().splitlines()
        # Header + 20 data rows all have 3 fields
        assert len(lines) == 21

    def test_drop_short_rows(self, ragged):
        out, _, code = run(["nf", "3"], input=ragged)
        assert code == 0
        for line in out.strip().splitlines():
            assert len(line.split()) >= 3

    def test_truncate_long_rows(self, ragged):
        out, _, code = run(["nf", "2"], input=ragged)
        assert code == 0
        for line in out.strip().splitlines():
            assert len(line.split()) == 2

    def test_min_mode(self, ragged):
        out, _, code = run(["nf", "2", "--min"], input=ragged)
        assert code == 0
        for line in out.strip().splitlines():
            assert len(line.split()) >= 2

    def test_pad(self, ragged):
        out, _, code = run(["nf", "3", "--pad", "?"], input=ragged)
        assert code == 0
        for line in out.strip().splitlines():
            assert len(line.split()) >= 3

    def test_header_passthrough(self, small):
        out, _, code = run(["nf", "3", "-H", "1"], input=small)
        assert code == 0
        first_line = out.strip().splitlines()[0]
        assert "name" in first_line

    def test_align(self, small):
        out, _, code = run(["nf", "3", "-H", "1", "--align"], input=small)
        assert code == 0
        assert len(out.strip().splitlines()) == 21

    def test_empty_input(self):
        out, _, code = run(["nf", "3"], input="")
        assert code == 0
        assert out.strip() == ""

    def test_single_column(self, single_col):
        out, _, code = run(["nf", "1"], input=single_col)
        assert code == 0
        assert len(out.strip().splitlines()) == 15
