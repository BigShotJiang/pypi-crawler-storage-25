from __future__ import annotations

from tests.conftest import run


class TestSmooth:
    def test_median_default(self, single_col):
        out, _, code = run(["smooth", "3"], input=single_col)
        assert code == 0
        lines = out.strip().splitlines()
        # Trim mode: 15 rows, window=3 -> 13 output rows
        assert len(lines) == 13

    def test_mean_method(self, single_col):
        out, _, code = run(["smooth", "3", "-m", "mean"], input=single_col)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) == 13

    def test_no_trim(self, single_col):
        out, _, code = run(["smooth", "3", "--no-trim"], input=single_col)
        assert code == 0
        lines = out.strip().splitlines()
        # No trim: all 15 rows kept
        assert len(lines) == 15

    def test_passthru(self, numeric):
        out, _, code = run(["smooth", "3", "-p", "1"], input=numeric)
        assert code == 0
        lines = out.strip().splitlines()
        # First column (timestamp) should pass through unchanged
        assert "2024-03-01" in lines[0]

    def test_passthru_auto(self, numeric):
        # Multi-column: passthru auto-defaults to 1
        out, _, code = run(["smooth", "3"], input=numeric)
        assert code == 0
        lines = out.strip().splitlines()
        assert "2024-03-01" in lines[0]

    def test_header_passthrough(self, weather):
        out, _, code = run(["smooth", "3", "-H", "1"], input=weather)
        assert code == 0
        assert "timestamp" in out.strip().splitlines()[0]

    def test_window_1(self, single_col):
        # Window=1 should be identity (values may be reformatted)
        out, _, code = run(["smooth", "1"], input=single_col)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) == 15
        assert float(lines[0].strip()) == 10.0

    def test_window_larger_than_data(self, single_col):
        # Window > data rows, trim mode -> no output
        out, _, code = run(["smooth", "99"], input=single_col)
        assert code == 0
        assert out.strip() == ""

    def test_align(self, numeric):
        out, _, code = run(["smooth", "3", "--align"], input=numeric)
        assert code == 0
        assert len(out.strip().splitlines()) > 0

    def test_empty_input(self):
        out, _, code = run(["smooth", "3"], input="")
        assert code == 0
        assert out.strip() == ""

    def test_single_row(self, single_row):
        out, _, code = run(["smooth", "3", "--no-trim"], input=single_row)
        assert code == 0
        assert len(out.strip().splitlines()) == 1
