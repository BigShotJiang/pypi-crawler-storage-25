from __future__ import annotations

from tests.conftest import run


class TestCutw:
    def test_truncate_to_width(self, wide):
        out, _, code = run(["cutw", "40"], input=wide)
        assert code == 0
        for line in out.strip().splitlines():
            assert len(line) <= 40

    def test_marker(self, wide):
        out, _, code = run(["cutw", "40", "--marker", "..."], input=wide)
        assert code == 0
        for line in out.strip().splitlines():
            assert len(line) <= 40
        # Long lines should end with marker
        long_lines = [l for l in out.strip().splitlines() if l.endswith("...")]
        assert len(long_lines) >= 2

    def test_short_lines_unchanged(self, wide):
        out, _, code = run(["cutw", "200"], input=wide)
        assert code == 0
        # No truncation needed — output should match input
        assert out.strip() == wide.strip()

    def test_empty_input(self):
        out, _, code = run(["cutw", "40"], input="")
        assert code == 0
        assert out.strip() == ""
