from __future__ import annotations

from tests.conftest import run


class TestSampleEvery:
    def test_every_5(self, weather):
        out, _, code = run(["sample", "every", "5", "-H", "1"], input=weather)
        assert code == 0
        lines = out.strip().splitlines()
        # Header + 20/5 = 4 data rows
        assert len(lines) == 5

    def test_every_1(self, weather):
        out, _, code = run(["sample", "every", "1", "-H", "1"], input=weather)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) == 21


class TestSampleRandom:
    def test_random_count(self, weather):
        out, _, code = run(["sample", "random", "5", "-H", "1"], input=weather)
        assert code == 0
        lines = out.strip().splitlines()
        # Header + exactly 5 random rows
        assert len(lines) == 6


class TestSamplePct:
    def test_pct(self, weather):
        out, _, code = run(["sample", "pct", "100", "-H", "1"], input=weather)
        assert code == 0
        lines = out.strip().splitlines()
        # 100% should give all rows
        assert len(lines) == 21


class TestSampleInterval:
    def test_interval_datetime(self, weather):
        out, _, code = run(["sample", "interval", "15m", "-H", "1"], input=weather)
        assert code == 0
        lines = out.strip().splitlines()
        # 20 rows over ~3.5h at 15m intervals -> several bins
        assert len(lines) >= 3

    def test_interval_agg_mean(self, numeric):
        out, _, code = run(["sample", "interval", "30s", "--agg", "mean"], input=numeric)
        assert code == 0
        assert len(out.strip().splitlines()) >= 2


class TestSampleCommon:
    def test_header_passthrough(self, weather):
        out, _, code = run(["sample", "every", "5", "-H", "1"], input=weather)
        assert code == 0
        assert "timestamp" in out.strip().splitlines()[0]

    def test_unknown_mode_error(self, weather):
        _, _, code = run(["sample", "bogus", "5"], input=weather)
        assert code == 2

    def test_align(self, weather):
        out, _, code = run(["sample", "every", "5", "-H", "1", "--align"], input=weather)
        assert code == 0

    def test_empty_input(self):
        out, _, code = run(["sample", "every", "5"], input="")
        assert code == 0
        assert out.strip() == ""
