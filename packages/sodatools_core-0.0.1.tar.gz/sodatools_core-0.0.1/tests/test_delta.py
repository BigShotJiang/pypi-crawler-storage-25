from __future__ import annotations

from tests.conftest import run


class TestDelta:
    def test_basic_diff(self, numeric):
        out, _, code = run(["delta", "2"], input=numeric)
        assert code == 0
        lines = out.strip().splitlines()
        # First row dropped by default -> 19 rows
        assert len(lines) == 19
        # Counter diffs should all be 1
        for line in lines:
            fields = line.split()
            assert fields[1] == "1"

    def test_column_range(self, numeric):
        out, _, code = run(["delta", "2-3"], input=numeric)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) == 19

    def test_keep_first(self, numeric):
        out, _, code = run(["delta", "2", "--keep-first"], input=numeric)
        assert code == 0
        lines = out.strip().splitlines()
        assert len(lines) == 20
        # First row should have 0
        assert lines[0].split()[1] == "0"

    def test_append_mode(self, numeric):
        out, _, code = run(["delta", "2", "--append"], input=numeric)
        assert code == 0
        lines = out.strip().splitlines()
        # Appended diff column means more fields
        assert len(lines[0].split()) == 5

    def test_header_passthrough(self, weather):
        out, _, code = run(["delta", "2", "-H", "1"], input=weather)
        assert code == 0
        assert "timestamp" in out.strip().splitlines()[0]

    def test_header_append_labels(self, weather):
        out, _, code = run(["delta", "2", "-H", "1", "--append"], input=weather)
        assert code == 0
        header = out.strip().splitlines()[0]
        assert "d_temp" in header

    def test_ref_mode(self, numeric):
        out, _, code = run(["delta", "2", "--ref", "1"], input=numeric)
        assert code == 0
        lines = out.strip().splitlines()
        # All diffs relative to row 1 (counter=1)
        # Row 1 itself: diff=0, row 2: diff=1, row 3: diff=2, ...
        assert lines[0].split()[1] == "0"
        assert lines[1].split()[1] == "1"
        assert lines[9].split()[1] == "9"

    def test_single_row(self, single_row):
        out, _, code = run(["delta", "2"], input=single_row)
        assert code == 0
        # No output — need two rows for a diff
        assert out.strip() == ""

    def test_single_row_keep_first(self, single_row):
        out, _, code = run(["delta", "2", "--keep-first"], input=single_row)
        assert code == 0
        assert len(out.strip().splitlines()) == 1

    def test_empty_input(self):
        out, _, code = run(["delta", "2"], input="")
        assert code == 0
        assert out.strip() == ""

    def test_align(self, numeric):
        out, _, code = run(["delta", "2", "--align"], input=numeric)
        assert code == 0
        assert len(out.strip().splitlines()) == 19
