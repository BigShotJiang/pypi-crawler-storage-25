# sodatools-core

CLI toolkit for columnar text processing. Entry point: `soda <command>`.

## Tooling

- Package manager: `uv`
- Build: `hatchling` + `hatch-vcs` (version from git tags)
- CLI framework: `typer` (rich is bundled with typer)
- Run: `uv run soda <command>`
- Install/sync: `uv sync`

## Architecture

```
src/sodatools_core/
    __init__.py          # exposes main() for entry point
    app.py               # typer app, registers all subcommands
    common/              # shared utilities
        reader.py        # Layer 1: streaming stdin reader (split, nulls, headers, TTY)
        dataframe.py     # Layer 2: buffered polars DataFrame builder (type detection, casting)
        align.py         # StreamingAligner for adaptive column alignment
        parsing.py       # text utilities (ISO 8601, int ranges, duration parsing)
        cli_helpers.py   # shared CLI helpers (eager_print_callback, help text constants)
        exceptions.py    # base exceptions (SodatoolsError, FieldIndexError, etc.)
    <tool>/              # one subpackage per tool
        cli.py           # typer command function
        parser.py        # input parsing (Lark grammar or simple)
        evaluator.py     # core logic
        grammar.lark     # Lark grammar (if needed)
```

## Tools

| Tool | Type | Description |
|------|------|-------------|
| align | Buffered | Align columns to fixed widths (auto right-justify numbers) |
| filter | Streaming | Filter noisy/invalid rows by column behavior (mad, run, rate, range, clock) |
| coltest | Streaming | Filter lines by column test expressions |
| cutw | Streaming | Truncate lines to terminal/explicit width |
| delta | Streaming | Row-to-row differences for numeric columns |
| events | Streaming | Convert state time series to bounded events |
| kut | Streaming | Select, reorder, format columns |
| nf | Streaming | Enforce field count per line |
| plot | Buffered | Interactive scatter plots (matplotlib) |
| radix | Streaming | Convert integers between bases (dec/hex/bin/oct) |
| sample | Mixed | Sample rows (every/random/pct) or resample by time interval |
| smooth | Streaming | Sliding window mean/median smoothing |
| stats | Buffered | Column statistics with rich table output (polars) |
| tag | Streaming | Assign named states based on column conditions |
| uniq | Streaming | Consecutive deduplication with optional column keys |

## Adding a new tool

1. Create `src/sodatools_core/<toolname>/` with `__init__.py` and `cli.py`
2. Define the typer command function in `cli.py`
3. Register in `app.py`: import + `app.command("<toolname>")(<fn>)`

## Two-layer data model

**Streaming tools** (line-at-a-time, can handle infinite stdin):
- Use `common/reader.py`: `split_fields()`, `read_rows_raw()`, `warn_if_tty()`
- No type casting — operate on raw strings
- No `--null` flag — users match sentinels directly
- Some tools (smooth, events) use bounded buffers (window-sized) while remaining streaming

**Buffering tools** (read all data into memory):
- Use `common/dataframe.py`: `read_dataframe()` returns a typed `polars.DataFrame`
- Auto-detects column types: datetime (ISO 8601), int, float, string
- Supports `--null` (repeatable) for null sentinel replacement (default: `?`)

## Common CLI options

Reusable options shared across tools. New tools should reuse these exact flag names, aliases, types, and defaults for consistency.

### Universal (nearly every tool)

| Flag | Alias | Type | Default | Used by | Purpose |
|------|-------|------|---------|---------|---------|
| `--delimiter` | `-d` | `Optional[str]` | `None` | all except cutw, sampledata | Input field delimiter (whitespace when None) |
| `--header` | `-H` | `Optional[int]` | `None` | all except cutw, sampledata | First N lines are headers (see semantics below) |
| `--example` | — | `bool` | `False` | all except sampledata | Show usage examples and exit |

### Common (many tools)

| Flag | Alias | Type | Default | Used by | Purpose |
|------|-------|------|---------|---------|---------|
| `--align` | — | `bool` | `False` | filter, delta, events, kut, nf, radix, sample, smooth, tag, uniq | Adaptive streaming column alignment (right-justify numbers, left-justify strings) |
| `--no-fail` | — | `bool` | `False` | filter, coltest, events, kut, plot, stats, tag | Skip problematic rows instead of erroring |
| `--syntax` | — | `bool` | `False` | filter, coltest, kut, plot, tag | Print expression syntax reference and exit |
| `--null` | — | `Optional[list[str]]` | `None` | plot, stats | Null sentinel values (repeatable, default: `?`). Buffering tools only. |
| `--null` | — | `str` | `"?"` | filter | Null sentinel for replacement (single value). |
| `--no-color` | — | `bool` | `False` | coltest, stats | Disable colored output |

### Specialized (2-3 tools with same pattern)

| Flag | Alias | Type | Default | Used by | Purpose |
|------|-------|------|---------|---------|---------|
| `--output-delimiter` | `-o` | `Optional[str]` | varies | align, kut | Output field delimiter (align defaults to `"  "`, kut inherits input) |
| `--passthru` | `-p` | `Optional[int]` | `None` | smooth | Pass first N columns through unmodified (auto-defaults to 1 when >1 col) |
| `--time` | — | `int` | `1` | events, filter, sample | Time column (1-indexed) |
| `--gap` | — | `str` | — | filter, events | Time gap threshold (duration string or bare seconds, e.g. `60s`, `5m`, `600`) |
| `--invert` | — | `bool` | `False` | filter, coltest | Invert/negate match or filter result |
| `--count` | `-c` | `bool` | `False` | coltest, uniq | Output count instead of data |
| `--print-header` | — | `bool` | `False` | events | Print generated column names as first output row |
| `--drop` | — | `bool` | `False` | filter (`-x`), tag | Discard non-matching rows |

### Shared help text

`common/cli_helpers.py` defines `HELP_*` constants for all shared option help strings. New tools should import and use these rather than writing inline help text. This ensures consistency across all `--help` output.

### --header semantics

The `--header` flag has three distinct behaviors depending on the tool:
- **Pass through**: headers are printed to stdout unchanged. Most streaming tools.
- **Skip**: headers are consumed and discarded. `events` (its output schema differs from input).
- **Special**: `align` (underlines headers), `kut` (applies column selection), `stats` (uses as column names), `plot` (uses as labels).

### --null semantics

- **Buffering tools** (`stats`, `plot`): `--null` is `Optional[list[str]]`, repeatable. Multiple sentinel values can be specified (e.g. `--null ? --null NA`). Default: `["?"]`.
- **Streaming tool** (`filter`): `--null` is `str`, single value. This is the *replacement* sentinel written to output for bad values. Default: `"?"`.

These differ intentionally: buffering tools *recognize* nulls in input, filter *writes* a null into output.

### Duration strings

All `--gap` flags and `sample interval` accept duration strings (`Ns`, `Nm`, `Nh`, `Nd`) or bare numbers (interpreted as seconds). Shared via `common/parsing.py:parse_duration()`.

### Exit codes

- `coltest`: exit 1 when no lines match (grep-style)
- `filter --drop`: exit 1 when no rows pass the filter (grep-style)
- All tools: exit 2 on user error

## Column specifications

Tools that accept column arguments support:
- Single columns: `3` (1-indexed), `-1` (last)
- Ranges via `text_to_int_array`: `2-5` expands to `[2,3,4,5]`, `1,3,5` for explicit lists (delta)
- kut has its own richer grammar (see `soda kut --syntax`): reverse ranges, `$`, exclusions, step ranges, literals

## Lark grammars

Tools with non-trivial argument syntax use Lark LALR grammars:
- Grammar file: `<tool>/grammar.lark`
- Parser cached at module level via `Lark.open()`
- Transformer converts parse tree to frozen dataclasses
- Use anonymous terminals (`_DASH`, `_COLON`) for structural tokens that shouldn't appear in the parse tree

## Column alignment

Two mechanisms, both auto-detect numeric columns (right-justify) vs strings (left-justify):
- `--align` flag on streaming tools (kut, nf, smooth, delta, tag, events, uniq) — adaptive, converges in a few rows
- `soda align` — buffered, perfect alignment with `--right`/`--left` overrides, `-w` min width, `-H` for underlined headers
- Shared logic in `common/align.py`: `StreamingAligner` class

## Tool composition patterns

```bash
# Tag states, then convert to events
cat data | soda tag -H1 hot: 2gt25 cold: 2lt15 | soda events -H1 --gap 600

# Select columns, smooth, align
cat data | soda kut 1 2 3 | soda smooth 5 | soda align -H1

# Filter, convert bases, align
cat data | soda coltest 2gt0 | soda radix --to hex | soda align

# Sample, compute deltas, plot
cat data | soda sample every 10 -H1 | soda delta 2-5 | soda plot 2
```

## Conventions

- 1-indexed columns (like awk), negative indices from end (like Python)
- Exit codes: 0 = success, 1 = no match (grep-style, where applicable), 2 = error
- stderr for errors/warnings (via `rich.console.Console(stderr=True)`)
- stdout for data output only
- TTY detection: warn user if stdin is a terminal
- `--save` on plot: infers format from extension (.pkl for interactive, .png/.svg/.pdf for image)

## Git Bash note

On Windows Git Bash, bare `/` in arguments is expanded to `C:/Program Files/Git/`. Use `MSYS_NO_PATHCONV=1` or quote the `/` when needed.
