"""Unit tests for engine/prompt.py — system prompt generation and Crew injection.

Run:  pytest tests/test_prompt.py -v
"""
import os
from pathlib import Path

import pytest

from byoe.engine.prompt import _read_truncated, _load_crew_context, system_prompt


# ── _read_truncated ───────────────────────────────────────────────────────────

class TestReadTruncated:
    def test_short_file_returned_intact(self, tmp_path):
        f = tmp_path / "short.md"
        f.write_text("hello world", encoding="utf-8")
        assert _read_truncated(f, 100) == "hello world"

    def test_long_file_is_truncated(self, tmp_path):
        f = tmp_path / "long.md"
        content = "A" * 200
        f.write_text(content, encoding="utf-8")
        result = _read_truncated(f, 100)
        assert len(result) < len(content)
        assert "omitted" in result

    def test_truncation_preserves_start_and_end(self, tmp_path):
        f = tmp_path / "content.md"
        f.write_text("START" + "X" * 1000 + "END", encoding="utf-8")
        result = _read_truncated(f, 50)
        assert "START" in result
        assert "END" in result

    def test_exactly_at_limit_not_truncated(self, tmp_path):
        f = tmp_path / "exact.md"
        content = "B" * 50
        f.write_text(content, encoding="utf-8")
        assert _read_truncated(f, 50) == content

    def test_utf8_content_handled(self, tmp_path):
        f = tmp_path / "zh.md"
        f.write_text("你好世界" * 10, encoding="utf-8")
        result = _read_truncated(f, 20)
        assert isinstance(result, str)


# ── _load_crew_context ────────────────────────────────────────────────────────

class TestLoadCrewContext:
    def test_returns_empty_without_any_files(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = _load_crew_context(tmp_path)
        assert result == ""

    def test_triggers_with_instructions_only(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "INSTRUCTIONS.md").write_text("## Rules\nBe helpful.", encoding="utf-8")
        result = _load_crew_context(tmp_path)
        assert "Crew" in result
        assert "Be helpful" in result

    def test_triggers_with_crew_yaml_only(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "crew.yaml").write_text("project: myapp\n", encoding="utf-8")
        result = _load_crew_context(tmp_path)
        assert result != ""
        assert "myapp" in result

    def test_triggers_with_legacy_devcrew_yaml(self, tmp_path, monkeypatch):
        """Backwards-compat: devcrew.yaml still works."""
        monkeypatch.chdir(tmp_path)
        (tmp_path / "devcrew.yaml").write_text("project: legacy\n", encoding="utf-8")
        result = _load_crew_context(tmp_path)
        assert result != ""
        assert "legacy" in result

    def test_injects_resume_when_present(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "INSTRUCTIONS.md").write_text("Rules", encoding="utf-8")
        crew = tmp_path / "crew"
        crew.mkdir()
        (crew / "resume.md").write_text("## Sprint\nIn progress: login", encoding="utf-8")
        result = _load_crew_context(tmp_path)
        assert "In progress: login" in result

    def test_skips_empty_blockers(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "INSTRUCTIONS.md").write_text("Rules", encoding="utf-8")
        crew = tmp_path / "crew"
        crew.mkdir()
        (crew / "blockers.md").write_text("# Blockers\n\n（无待解决问题）\n", encoding="utf-8")
        result = _load_crew_context(tmp_path)
        assert "Open Blockers" not in result

    def test_includes_non_empty_blockers(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "INSTRUCTIONS.md").write_text("Rules", encoding="utf-8")
        crew = tmp_path / "crew"
        crew.mkdir()
        (crew / "blockers.md").write_text(
            "# Blockers\n\n## OPEN\n- [B-1] API is slow\n", encoding="utf-8"
        )
        result = _load_crew_context(tmp_path)
        assert "B-1" in result

    def test_instructions_truncated_at_6000(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        long_instructions = "word " * 2000  # ~10000 chars
        (tmp_path / "INSTRUCTIONS.md").write_text(long_instructions, encoding="utf-8")
        result = _load_crew_context(tmp_path)
        assert len(result) < len(long_instructions)
        assert "omitted" in result


# ── system_prompt ─────────────────────────────────────────────────────────────

class TestSystemPrompt:
    def _fake_tools(self):
        class FakeTool:
            name = "fake_tool"
            description = "A fake tool for testing"
        return [FakeTool()]

    def test_contains_tool_names(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        prompt = system_prompt(self._fake_tools())
        assert "fake_tool" in prompt

    def test_contains_cwd(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        prompt = system_prompt(self._fake_tools())
        assert str(tmp_path).replace("\\", "/") in prompt.replace("\\", "/")

    def test_no_crew_context_without_files(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        prompt = system_prompt(self._fake_tools())
        assert "Crew" not in prompt

    def test_crew_context_injected(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "INSTRUCTIONS.md").write_text("## Test rules\nRule A.", encoding="utf-8")
        prompt = system_prompt(self._fake_tools())
        assert "Crew" in prompt
        assert "Rule A" in prompt

    def test_prompt_is_string(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = system_prompt(self._fake_tools())
        assert isinstance(result, str)
        assert len(result) > 100
