"""交互式 REPL — byoe chat 命令的核心实现。

直接使用内置 engine 层，system prompt 自动注入 Crew 项目上下文。
"""
from __future__ import annotations

import os
import sys

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from prompt_toolkit import prompt as pt_prompt
from prompt_toolkit.history import FileHistory
from prompt_toolkit.key_binding import KeyBindings

from byoe.engine.agent import Agent
from byoe.engine.config import Config
from byoe.engine.session import save_session, load_session, list_sessions
from byoe import __version__

console = Console()


def run_repl(agent: Agent, config: Config) -> None:
    """启动交互式 REPL。"""
    _print_welcome(config)

    hist_path = os.path.expanduser("~/.byoe_history")
    history = FileHistory(hist_path)

    kb = KeyBindings()

    @kb.add("enter")
    def _submit(event):
        event.current_buffer.validate_and_handle()

    @kb.add("escape", "enter")
    def _newline(event):
        event.current_buffer.insert_text("\n")

    while True:
        try:
            user_input = pt_prompt(
                "You > ",
                history=history,
                multiline=True,
                key_bindings=kb,
                prompt_continuation="...  ",
            ).strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\nBye!")
            break

        if not user_input:
            continue

        if user_input.lower() in ("quit", "exit", "/quit", "/exit"):
            break
        if user_input == "/help":
            _show_help()
            continue
        if user_input == "/reset":
            agent.reset()
            console.print("[yellow]Conversation reset.[/yellow]")
            continue
        if user_input == "/tokens":
            p = agent.llm.total_prompt_tokens
            c = agent.llm.total_completion_tokens
            line = (
                f"Tokens: [cyan]{p}[/cyan] prompt + [cyan]{c}[/cyan] completion"
                f" = [bold]{p+c}[/bold] total"
            )
            cost = agent.llm.estimated_cost
            if cost is not None:
                line += f"  (~${cost:.4f})"
            console.print(line)
            continue
        if user_input == "/model" or user_input.startswith("/model "):
            new_model = user_input[7:].strip() if user_input.startswith("/model ") else ""
            if new_model:
                agent.llm.model = new_model
                config.model = new_model
                console.print(f"Switched to [cyan]{new_model}[/cyan]")
            else:
                console.print(f"Current model: [cyan]{config.model}[/cyan]")
            continue
        if user_input == "/compact":
            from byoe.engine.context import estimate_tokens
            before = estimate_tokens(agent.messages)
            compressed = agent.context.maybe_compress(agent.messages, agent.llm)
            after = estimate_tokens(agent.messages)
            if compressed:
                console.print(
                    f"[green]Compressed: {before} → {after} tokens "
                    f"({len(agent.messages)} messages)[/green]"
                )
            else:
                console.print(f"[dim]Nothing to compress ({before} tokens)[/dim]")
            continue
        if user_input == "/save":
            sid = save_session(agent.messages, config.model, changed_files=agent.changed_files)
            console.print(f"[green]Session saved: {sid}[/green]")
            console.print(f"Resume with: byoe chat -r {sid}")
            continue
        if user_input == "/diff":
            if not agent.changed_files:
                console.print("[dim]No files modified this session.[/dim]")
            else:
                console.print(f"[bold]Files modified ({len(agent.changed_files)}):[/bold]")
                for f in sorted(agent.changed_files):
                    console.print(f"  [cyan]{f}[/cyan]")
            continue
        if user_input == "/sessions":
            sessions = list_sessions()
            if not sessions:
                console.print("[dim]No saved sessions.[/dim]")
            else:
                for s in sessions:
                    console.print(
                        f"  [cyan]{s['id']}[/cyan] ({s['model']}, {s['saved_at']}) {s['preview']}"
                    )
            continue

        streamed: list[str] = []

        def on_token(tok):
            streamed.append(tok)
            print(tok, end="", flush=True)

        def on_tool(name, kwargs):
            console.print(f"\n[dim]> {name}({_brief(kwargs)})[/dim]")

        def on_tool_result(name, kwargs, result):
            # Surface bash errors inline so the user sees them immediately
            if name == "bash" and result and (
                "[exit code:" in result or result.startswith("Error")
            ):
                preview = result[:300]
                if len(result) > 300:
                    preview += f"\n…({len(result)} chars)"
                console.print(f"[dim red]{preview}[/dim red]")

        _COMPRESS_LABELS = {
            "snip":      "⚡ 工具输出已裁剪",
            "summarize": "⚡ 上下文已摘要压缩",
            "collapse":  "⚡ 上下文已硬重置",
        }

        def on_compress(layer: str, before: int, after: int):
            label = _COMPRESS_LABELS.get(layer, "⚡ 上下文已压缩")
            console.print(
                f"\n[dim yellow]{label}（{before} → {after} tokens，"
                f"保留最近 {len(agent.messages)} 条消息）[/dim yellow]"
            )

        try:
            response = agent.chat(
                user_input,
                on_token=on_token,
                on_tool=on_tool,
                on_tool_result=on_tool_result,
                on_compress=on_compress,
            )
            if streamed:
                print()
            else:
                console.print(Markdown(response))
        except KeyboardInterrupt:
            console.print("\n[yellow]Interrupted.[/yellow]")
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]")


def _print_welcome(config: Config) -> None:
    from pathlib import Path
    cwd = Path.cwd()
    crew_indicator = ""
    if (cwd / "INSTRUCTIONS.md").exists() or (cwd / "crew.yaml").exists():
        crew_indicator = "\n[green]✓ Crew 项目上下文已自动注入[/green]"

    console.print(Panel(
        f"[bold]卜一智航 · BYOE[/bold] v{__version__}  [dim]byoe.net[/dim]\n"
        f"[dim]携智而来，决策随行 — Bring Your Own Executive AI[/dim]\n"
        f"Model: [cyan]{config.model}[/cyan]"
        + (f"  Base: [dim]{config.base_url}[/dim]" if config.base_url else "")
        + crew_indicator
        + "\nType [bold]/help[/bold] for commands, [bold]Ctrl+C[/bold] to cancel, [bold]quit[/bold] to exit.",
        border_style="blue",
        title="BYOE",
    ))


def _show_help() -> None:
    console.print(Panel(
        "[bold]Commands:[/bold]\n"
        "  /help          Show this help\n"
        "  /reset         Clear conversation history (re-loads project context)\n"
        "  /model         Show current model\n"
        "  /model <name>  Switch model mid-conversation\n"
        "  /tokens        Show token usage & estimated cost\n"
        "  /compact       Compress conversation context\n"
        "  /diff          Show files modified this session\n"
        "  /save          Save session to disk\n"
        "  /sessions      List saved sessions\n"
        "  quit           Exit\n"
        "\n"
        "[bold]Input:[/bold]\n"
        "  Enter          Submit message\n"
        "  Esc+Enter      Insert newline (for pasting code)\n"
        "\n"
        "[bold]Context:[/bold]\n"
        "  If INSTRUCTIONS.md or crew.yaml exists in cwd,\n"
        "  Crew project context is automatically injected into\n"
        "  the system prompt — no manual /add needed.",
        title="BYOE Help",
        border_style="dim",
    ))


def _brief(kwargs: dict, maxlen: int = 80) -> str:
    s = ", ".join(f"{k}={repr(v)[:40]}" for k, v in kwargs.items())
    return s[:maxlen] + ("..." if len(s) > maxlen else "")
