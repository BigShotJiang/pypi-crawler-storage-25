# Biobanking
Systematic collection, processing, storage, and analysis of biological samples and associated health records for medical research.

## Supported pipelines
### Preprocess
Contains biobank-specific modules for EHR data collection, cleaning, and processing.

### QC (Under construction)
Will contain biobank-specific modules for variant quality control and filtering.

### Annotation (Under construction)
Will contain biobank-specific modules for variant annotation.

### Association
Contains biobank-specific modules for genotype-phenotype association tests.

## Supported biobanks
### All of Us
The All of Us biobank consists of coupled whole genome sequencing and electronic health record data of more than 400k individuals, with continued expansion.

### UK Biobank (Under construction)
The UK Biobank consists of coupled whole genome sequencing and electronic health record data of ~500k participants.

## AoU REGENIE workflow
The All of Us association utilities currently support a packaged `regenie` workflow with three Step 2 modes:

- Burden association testing
- Mask-only runs for writing burden-mask PLINK datasets
- Interaction testing using the same burden inputs and optional interaction flags

The workflow implementation lives in [src/biobanking/workflows/regenie.wdl](C:\Users\dbanerjee\work\biobanking\src\biobanking\workflows\regenie.wdl), and the Python utilities live in [src/biobanking/association/aou.py](C:\Users\dbanerjee\work\biobanking\src\biobanking\association\aou.py).

The tracking model is phenotype-centered:

- Step 1 is tracked once per phenotype prefix
- Step 2 burden and interaction runs are tracked separately by mode under phenotype prefixes
- mask runs are tracked separately under a top-level `mask` namespace
- workflow metadata is written locally and synced to the workspace bucket

This keeps LOCO and prediction reuse aligned with the phenotype definition rather than with any specific burden or interaction run, while allowing masks to remain phenotype-independent artifacts.

### Recommended usage pattern
- Run or reuse Step 1 once per phenotype prefix.
- Use burden runs for standard gene-based tests.
- Use mask runs to materialize chromosome-wide burden-mask PLINK files from a universal dummy phenotype stored at `data/associations/masks/<burden_type>/dummy.tsv.gz`, without phenotype covariates.
- Use interaction runs only after Step 1 exists for the phenotype prefix you are testing.

More detailed usage examples are in [docs/workflows.md](C:\Users\dbanerjee\work\biobanking\docs\workflows.md).

## Internal use
```bash
python -m pip install -U pip build
pip install twine
# linux
rm -rf dist build *.egg-info src/*.egg-info
# windows
Remove-Item -Recurse -Force dist, *.egg-info, src\*.egg-info
python -m build
pip install dist/biobanking-0.0.14-py3-none-any.whl
python -c "from biobanking.association.aou import REGENIE; regenie = REGENIE(); from biobanking.preprocess.aou.measurements import save_measurements_in_wide_format; print('import ok')"
twine upload dist/*
```
