"""
Mock service clients for testing automations.

This module provides mock implementations of service clients that can be
used during local development and testing without requiring actual API access.

Example:
    from torivers_sdk.context.mocks import MockGmailClient, MockCredentialProxy

    # Create mock Gmail client with test data
    gmail = MockGmailClient()
    gmail.add_mock_email(
        EmailMessage(
            id="msg-1",
            thread_id="thread-1",
            subject="Test Email",
            sender="test@example.com",
            recipients=["user@example.com"],
            snippet="Hello...",
            date=datetime.now(timezone.utc),
            labels=["INBOX"],
        )
    )

    # Create mock credential proxy with the mock client
    proxy = MockCredentialProxy(["gmail"])
    proxy.register_mock_client("gmail", gmail)

    # Use in tests
    client = proxy.get_client("gmail")
    emails = client.list_emails()
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from torivers_sdk.context.clients import (
    EmailDraft,
    EmailMessage,
    GmailClient,
    GoogleSheetsClient,
    QuickBooksClient,
    ServiceClient,
    SlackChannel,
    SlackClient,
    SlackMessage,
    SpreadsheetInfo,
)
from torivers_sdk.context.credentials import CredentialProxy

# =============================================================================
# Mock Gmail Client
# =============================================================================


class MockGmailClient(GmailClient):
    """
    Mock Gmail client for testing.

    Stores emails in memory and simulates Gmail API operations.
    """

    def __init__(self) -> None:
        """Initialize mock Gmail client."""
        super().__init__(_auth_context={"mock": True})
        self._emails: list[EmailMessage] = []
        self._drafts: list[EmailDraft] = []
        self._sent_emails: list[dict[str, Any]] = []
        self._message_counter = 0

    def is_authenticated(self) -> bool:
        """Mock is always authenticated."""
        return True

    def add_mock_email(self, email: EmailMessage) -> None:
        """Add a mock email to the inbox."""
        self._emails.append(email)

    def add_mock_emails(self, emails: list[EmailMessage]) -> None:
        """Add multiple mock emails."""
        self._emails.extend(emails)

    def clear_mock_data(self) -> None:
        """Clear all mock data."""
        self._emails.clear()
        self._drafts.clear()
        self._sent_emails.clear()

    @property
    def sent_emails(self) -> list[dict[str, Any]]:
        """Get list of emails that were sent."""
        return list(self._sent_emails)

    def send_email(
        self,
        to: list[str],
        subject: str,
        body: str,
        cc: list[str] | None = None,
        bcc: list[str] | None = None,
        is_html: bool = False,
    ) -> str:
        """Send an email (stores in sent_emails list)."""
        self._message_counter += 1
        message_id = f"mock-msg-{self._message_counter}"

        self._sent_emails.append(
            {
                "id": message_id,
                "to": to,
                "subject": subject,
                "body": body,
                "cc": cc,
                "bcc": bcc,
                "is_html": is_html,
                "sent_at": datetime.now(timezone.utc).isoformat(),
            }
        )
        return message_id

    def list_emails(
        self,
        max_results: int = 10,
        query: str | None = None,
        label: str | None = None,
    ) -> list[EmailMessage]:
        """List emails (returns mock emails)."""
        result = self._emails

        if label:
            result = [e for e in result if label in e.labels]

        if query:
            query_lower = query.lower()
            result = [
                e
                for e in result
                if query_lower in e.subject.lower()
                or query_lower in e.sender.lower()
                or query_lower in e.snippet.lower()
            ]

        return result[:max_results]

    def get_email(self, message_id: str) -> EmailMessage:
        """Get a specific email by ID."""
        for email in self._emails:
            if email.id == message_id:
                return email
        raise ValueError(f"Email with ID '{message_id}' not found")

    def create_draft(self, draft: EmailDraft) -> str:
        """Create a draft."""
        self._message_counter += 1
        draft_id = f"mock-draft-{self._message_counter}"
        self._drafts.append(draft)
        return draft_id


# =============================================================================
# Mock Google Sheets Client
# =============================================================================


@dataclass
class MockSpreadsheet:
    """Mock spreadsheet data storage."""

    spreadsheet_id: str
    title: str
    sheets: dict[str, list[list[Any]]] = field(default_factory=dict)


class MockGoogleSheetsClient(GoogleSheetsClient):
    """
    Mock Google Sheets client for testing.

    Stores spreadsheet data in memory and simulates Sheets API operations.
    """

    def __init__(self) -> None:
        """Initialize mock Google Sheets client."""
        super().__init__(_auth_context={"mock": True})
        self._spreadsheets: dict[str, MockSpreadsheet] = {}

    def is_authenticated(self) -> bool:
        """Mock is always authenticated."""
        return True

    def add_mock_spreadsheet(
        self,
        spreadsheet_id: str,
        title: str,
        sheets: dict[str, list[list[Any]]] | None = None,
    ) -> None:
        """Add a mock spreadsheet."""
        self._spreadsheets[spreadsheet_id] = MockSpreadsheet(
            spreadsheet_id=spreadsheet_id,
            title=title,
            sheets=sheets or {"Sheet1": []},
        )

    def set_mock_data(
        self,
        spreadsheet_id: str,
        sheet_name: str,
        data: list[list[Any]],
    ) -> None:
        """Set data for a specific sheet."""
        if spreadsheet_id not in self._spreadsheets:
            self.add_mock_spreadsheet(spreadsheet_id, "Mock Spreadsheet")
        self._spreadsheets[spreadsheet_id].sheets[sheet_name] = data

    def clear_mock_data(self) -> None:
        """Clear all mock data."""
        self._spreadsheets.clear()

    def get_spreadsheet_info(self, spreadsheet_id: str) -> SpreadsheetInfo:
        """Get spreadsheet info."""
        if spreadsheet_id not in self._spreadsheets:
            raise ValueError(f"Spreadsheet '{spreadsheet_id}' not found")

        ss = self._spreadsheets[spreadsheet_id]
        return SpreadsheetInfo(
            spreadsheet_id=ss.spreadsheet_id,
            title=ss.title,
            sheets=list(ss.sheets.keys()),
            url=f"https://docs.google.com/spreadsheets/d/{spreadsheet_id}",
        )

    def get_range_values(
        self,
        spreadsheet_id: str,
        range: str,
        value_render_option: str = "FORMATTED_VALUE",
    ) -> list[list[Any]]:
        """Get values from a range."""
        if spreadsheet_id not in self._spreadsheets:
            raise ValueError(f"Spreadsheet '{spreadsheet_id}' not found")

        # Parse range (simplified - just returns all data from sheet)
        sheet_name = range.split("!")[0] if "!" in range else "Sheet1"
        ss = self._spreadsheets[spreadsheet_id]

        if sheet_name not in ss.sheets:
            return []

        return ss.sheets[sheet_name]

    def update_range(
        self,
        spreadsheet_id: str,
        range: str,
        values: list[list[Any]],
        value_input_option: str = "USER_ENTERED",
    ) -> int:
        """Update values in a range."""
        if spreadsheet_id not in self._spreadsheets:
            self.add_mock_spreadsheet(spreadsheet_id, "Mock Spreadsheet")

        sheet_name = range.split("!")[0] if "!" in range else "Sheet1"
        ss = self._spreadsheets[spreadsheet_id]
        ss.sheets[sheet_name] = values

        return sum(len(row) for row in values)

    def append_rows(
        self,
        spreadsheet_id: str,
        range: str,
        values: list[list[Any]],
    ) -> int:
        """Append rows to a sheet."""
        if spreadsheet_id not in self._spreadsheets:
            self.add_mock_spreadsheet(spreadsheet_id, "Mock Spreadsheet")

        sheet_name = range.split("!")[0] if "!" in range else "Sheet1"
        ss = self._spreadsheets[spreadsheet_id]

        if sheet_name not in ss.sheets:
            ss.sheets[sheet_name] = []

        ss.sheets[sheet_name].extend(values)
        return len(values)

    def clear_range(self, spreadsheet_id: str, range: str) -> None:
        """Clear values from a range."""
        if spreadsheet_id not in self._spreadsheets:
            return

        sheet_name = range.split("!")[0] if "!" in range else "Sheet1"
        ss = self._spreadsheets[spreadsheet_id]

        if sheet_name in ss.sheets:
            ss.sheets[sheet_name] = []

    # ------------------------------------------------------------------
    # spreadsheets.create
    # ------------------------------------------------------------------
    def create_spreadsheet(
        self,
        title: str | None = None,
        sheet_titles: list[str] | None = None,
        properties: dict[str, Any] | None = None,
        sheets: list[dict[str, Any]] | None = None,
    ) -> SpreadsheetInfo:
        """Create a new mock spreadsheet."""
        self._created_counter = getattr(self, "_created_counter", 0) + 1
        spreadsheet_id = f"mock-spreadsheet-{self._created_counter}"
        effective_title = (
            (properties or {}).get("title")
            or title
            or f"Mock Spreadsheet {self._created_counter}"
        )

        # Determine sheet names: explicit sheets > sheet_titles > default Sheet1
        sheet_map: dict[str, list[list[Any]]] = {}
        if sheets:
            for s in sheets:
                name = (s.get("properties") or {}).get("title")
                if name:
                    sheet_map[str(name)] = []
        elif sheet_titles:
            for name in sheet_titles:
                sheet_map[str(name)] = []
        else:
            sheet_map["Sheet1"] = []

        self._spreadsheets[spreadsheet_id] = MockSpreadsheet(
            spreadsheet_id=spreadsheet_id,
            title=str(effective_title),
            sheets=sheet_map,
        )
        return SpreadsheetInfo(
            spreadsheet_id=spreadsheet_id,
            title=str(effective_title),
            sheets=list(sheet_map.keys()),
            url=f"https://docs.google.com/spreadsheets/d/{spreadsheet_id}",
        )

    # ------------------------------------------------------------------
    # spreadsheets.getByDataFilter / batchUpdate
    # ------------------------------------------------------------------
    def get_spreadsheet_by_data_filter(
        self,
        spreadsheet_id: str,
        data_filters: list[dict[str, Any]],
        include_grid_data: bool = False,
    ) -> dict[str, Any]:
        """Mock: returns the basic info payload."""
        if spreadsheet_id not in self._spreadsheets:
            raise ValueError(f"Spreadsheet '{spreadsheet_id}' not found")
        ss = self._spreadsheets[spreadsheet_id]
        return {
            "spreadsheetId": ss.spreadsheet_id,
            "properties": {"title": ss.title},
            "sheets": [
                {"properties": {"title": name}} for name in ss.sheets
            ],
            "_appliedFilters": data_filters,
        }

    def batch_update_spreadsheet(
        self,
        spreadsheet_id: str,
        requests: list[dict[str, Any]],
        include_spreadsheet_in_response: bool | None = None,
        response_ranges: list[str] | None = None,
        response_include_grid_data: bool | None = None,
    ) -> dict[str, Any]:
        """Mock: applies a small subset of requests (addSheet, deleteSheet)."""
        if spreadsheet_id not in self._spreadsheets:
            self.add_mock_spreadsheet(spreadsheet_id, "Mock Spreadsheet")
        ss = self._spreadsheets[spreadsheet_id]
        replies: list[dict[str, Any]] = []
        for req in requests or []:
            if "addSheet" in req:
                title = ((req["addSheet"] or {}).get("properties") or {}).get("title")
                if title and title not in ss.sheets:
                    ss.sheets[str(title)] = []
                replies.append(
                    {
                        "addSheet": {
                            "properties": {
                                "title": title,
                                "sheetId": len(ss.sheets),
                            }
                        }
                    }
                )
            elif "deleteSheet" in req:
                # Sheet IDs aren't fully modeled; ignore in mock
                replies.append({"deleteSheet": {}})
            else:
                replies.append({})
        return {
            "spreadsheetId": spreadsheet_id,
            "replies": replies,
        }

    def create_sheet(self, spreadsheet_id: str, title: str) -> dict[str, Any]:
        """Mock create_sheet."""
        if spreadsheet_id not in self._spreadsheets:
            self.add_mock_spreadsheet(spreadsheet_id, "Mock Spreadsheet")
        ss = self._spreadsheets[spreadsheet_id]
        if title not in ss.sheets:
            ss.sheets[title] = []
        return {
            "spreadsheetId": spreadsheet_id,
            "replies": [
                {"addSheet": {"properties": {"title": title}}}
            ],
        }

    # ------------------------------------------------------------------
    # spreadsheets.values.batchGet / batchGetByDataFilter
    # ------------------------------------------------------------------
    def batch_get_values(
        self,
        spreadsheet_id: str,
        ranges: list[str],
        value_render_option: str = "FORMATTED_VALUE",
        date_time_render_option: str | None = None,
        major_dimension: str | None = None,
    ) -> list[dict[str, Any]]:
        """Mock batch get — returns ValueRange-shaped dicts."""
        result: list[dict[str, Any]] = []
        for rng in ranges:
            values = self.get_range_values(
                spreadsheet_id, rng, value_render_option=value_render_option
            )
            result.append(
                {
                    "range": rng,
                    "majorDimension": major_dimension or "ROWS",
                    "values": values,
                }
            )
        return result

    def batch_get_values_by_data_filter(
        self,
        spreadsheet_id: str,
        data_filters: list[dict[str, Any]],
        value_render_option: str = "FORMATTED_VALUE",
        date_time_render_option: str | None = None,
        major_dimension: str | None = None,
    ) -> list[dict[str, Any]]:
        """Mock: returns MatchedValueRange shapes derived from a1Range filters."""
        if spreadsheet_id not in self._spreadsheets:
            return []
        matched: list[dict[str, Any]] = []
        for f in data_filters or []:
            a1 = f.get("a1Range")
            if not a1:
                continue
            values = self.get_range_values(
                spreadsheet_id, a1, value_render_option=value_render_option
            )
            matched.append(
                {
                    "valueRange": {
                        "range": a1,
                        "majorDimension": major_dimension or "ROWS",
                        "values": values,
                    },
                    "dataFilters": [f],
                }
            )
        return matched

    # ------------------------------------------------------------------
    # spreadsheets.values.batchUpdate / batchUpdateByDataFilter
    # ------------------------------------------------------------------
    def batch_update_values(
        self,
        spreadsheet_id: str,
        data: list[dict[str, Any]],
        value_input_option: str = "USER_ENTERED",
        include_values_in_response: bool | None = None,
        response_value_render_option: str | None = None,
        response_date_time_render_option: str | None = None,
    ) -> dict[str, Any]:
        """Mock batch update — applies each ValueRange to the in-memory store."""
        total_updated_cells = 0
        for entry in data or []:
            rng = entry.get("range")
            values = entry.get("values") or []
            if not rng:
                continue
            total_updated_cells += self.update_range(
                spreadsheet_id, str(rng), values, value_input_option
            )
        return {
            "spreadsheetId": spreadsheet_id,
            "totalUpdatedRanges": len(data or []),
            "totalUpdatedRows": sum(len(d.get("values") or []) for d in (data or [])),
            "totalUpdatedColumns": 0,
            "totalUpdatedCells": total_updated_cells,
            "responses": [{"updatedRange": d.get("range")} for d in (data or [])],
        }

    def batch_update_values_by_data_filter(
        self,
        spreadsheet_id: str,
        data: list[dict[str, Any]],
        value_input_option: str = "USER_ENTERED",
        include_values_in_response: bool | None = None,
        response_value_render_option: str | None = None,
        response_date_time_render_option: str | None = None,
    ) -> dict[str, Any]:
        """Mock batch update by data filter (a1Range-based)."""
        responses: list[dict[str, Any]] = []
        for entry in data or []:
            data_filter = entry.get("dataFilter") or {}
            a1 = data_filter.get("a1Range")
            values = entry.get("values") or []
            if a1:
                self.update_range(
                    spreadsheet_id, str(a1), values, value_input_option
                )
                responses.append(
                    {"dataFilter": data_filter, "updatedRange": a1}
                )
        return {
            "spreadsheetId": spreadsheet_id,
            "totalUpdatedRanges": len(responses),
            "responses": responses,
        }

    # ------------------------------------------------------------------
    # spreadsheets.values.batchClear / batchClearByDataFilter
    # ------------------------------------------------------------------
    def batch_clear_values(
        self,
        spreadsheet_id: str,
        ranges: list[str],
    ) -> list[str]:
        """Mock batch clear."""
        cleared: list[str] = []
        for rng in ranges or []:
            self.clear_range(spreadsheet_id, rng)
            cleared.append(rng)
        return cleared

    def batch_clear_values_by_data_filter(
        self,
        spreadsheet_id: str,
        data_filters: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Mock batch clear by data filter."""
        cleared_filters: list[dict[str, Any]] = []
        for f in data_filters or []:
            a1 = f.get("a1Range")
            if a1:
                self.clear_range(spreadsheet_id, a1)
                cleared_filters.append(f)
        return {
            "spreadsheetId": spreadsheet_id,
            "clearedDataFilters": cleared_filters,
        }

    # ------------------------------------------------------------------
    # spreadsheets.sheets.copyTo
    # ------------------------------------------------------------------
    def copy_sheet_to(
        self,
        spreadsheet_id: str,
        sheet_id: int,
        destination_spreadsheet_id: str,
    ) -> dict[str, Any]:
        """Mock copy_sheet_to — copies the first sheet by index."""
        if spreadsheet_id not in self._spreadsheets:
            raise ValueError(f"Source spreadsheet '{spreadsheet_id}' not found")
        if destination_spreadsheet_id not in self._spreadsheets:
            self.add_mock_spreadsheet(
                destination_spreadsheet_id, "Mock Destination"
            )

        src = self._spreadsheets[spreadsheet_id]
        dst = self._spreadsheets[destination_spreadsheet_id]
        # Sheet IDs aren't fully modeled — copy by ordinal position
        src_sheet_names = list(src.sheets.keys())
        idx = sheet_id if 0 <= sheet_id < len(src_sheet_names) else 0
        if not src_sheet_names:
            raise ValueError("Source spreadsheet has no sheets to copy")
        source_name = src_sheet_names[idx]
        new_title = f"Copy of {source_name}"
        dst.sheets[new_title] = list(src.sheets[source_name])
        return {
            "sheetId": len(dst.sheets),
            "title": new_title,
            "index": len(dst.sheets) - 1,
        }

    # ------------------------------------------------------------------
    # spreadsheets.developerMetadata.*
    # ------------------------------------------------------------------
    def add_mock_developer_metadata(
        self,
        spreadsheet_id: str,
        metadata: dict[str, Any],
    ) -> None:
        """Register a mock DeveloperMetadata record for testing."""
        store = getattr(self, "_developer_metadata", None)
        if store is None:
            store = {}
            self._developer_metadata = store
        store.setdefault(spreadsheet_id, []).append(metadata)

    def get_developer_metadata(
        self,
        spreadsheet_id: str,
        metadata_id: int,
    ) -> dict[str, Any]:
        """Look up a DeveloperMetadata record by id (mock)."""
        store = getattr(self, "_developer_metadata", {})
        for entry in store.get(spreadsheet_id, []):
            if entry.get("metadataId") == metadata_id:
                return entry
        raise ValueError(
            f"Developer metadata '{metadata_id}' not found for "
            f"spreadsheet '{spreadsheet_id}'"
        )

    def search_developer_metadata(
        self,
        spreadsheet_id: str,
        data_filters: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Mock search — returns all metadata for the spreadsheet, unfiltered."""
        store = getattr(self, "_developer_metadata", {})
        entries = store.get(spreadsheet_id, [])
        return [
            {"developerMetadata": e, "dataFilters": data_filters} for e in entries
        ]


# =============================================================================
# Mock Slack Client
# =============================================================================


class MockSlackClient(SlackClient):
    """
    Mock Slack client for testing.

    Stores messages in memory and simulates Slack API operations.
    """

    def __init__(self) -> None:
        """Initialize mock Slack client."""
        super().__init__(_auth_context={"mock": True})
        self._channels: dict[str, SlackChannel] = {}
        self._messages: list[SlackMessage] = []
        self._reactions: list[dict[str, str]] = []
        self._message_counter = 0

    def is_authenticated(self) -> bool:
        """Mock is always authenticated."""
        return True

    def add_mock_channel(self, channel: SlackChannel) -> None:
        """Add a mock channel."""
        self._channels[channel.id] = channel
        self._channels[f"#{channel.name}"] = channel

    def clear_mock_data(self) -> None:
        """Clear all mock data."""
        self._channels.clear()
        self._messages.clear()
        self._reactions.clear()

    @property
    def sent_messages(self) -> list[SlackMessage]:
        """Get list of messages that were sent."""
        return list(self._messages)

    @property
    def added_reactions(self) -> list[dict[str, str]]:
        """Get list of reactions that were added."""
        return list(self._reactions)

    def send_message(
        self,
        channel: str,
        text: str,
        blocks: list[dict[str, Any]] | None = None,
        thread_ts: str | None = None,
    ) -> SlackMessage:
        """Send a message (stores in messages list)."""
        self._message_counter += 1
        ts = f"{self._message_counter}.{datetime.now(timezone.utc).timestamp()}"

        message = SlackMessage(
            ts=ts,
            channel=channel,
            text=text,
            user="mock-user",
            thread_ts=thread_ts,
        )
        self._messages.append(message)
        return message

    def get_channel(self, channel: str) -> SlackChannel:
        """Get channel information."""
        if channel in self._channels:
            return self._channels[channel]
        raise ValueError(f"Channel '{channel}' not found")

    def list_channels(
        self,
        exclude_archived: bool = True,
        types: str = "public_channel,private_channel",
    ) -> list[SlackChannel]:
        """List available channels."""
        # Return unique channels (avoid duplicates from ID and name keys)
        seen_ids: set[str] = set()
        result: list[SlackChannel] = []
        for channel in self._channels.values():
            if channel.id not in seen_ids:
                seen_ids.add(channel.id)
                result.append(channel)
        return result

    def update_message(
        self,
        channel: str,
        ts: str,
        text: str,
        blocks: list[dict[str, Any]] | None = None,
    ) -> SlackMessage:
        """Update an existing message."""
        for i, msg in enumerate(self._messages):
            if msg.ts == ts and msg.channel == channel:
                updated = SlackMessage(
                    ts=ts,
                    channel=channel,
                    text=text,
                    user=msg.user,
                    thread_ts=msg.thread_ts,
                )
                self._messages[i] = updated
                return updated
        raise ValueError(f"Message with ts '{ts}' not found in channel '{channel}'")

    def add_reaction(self, channel: str, ts: str, emoji: str) -> None:
        """Add a reaction to a message."""
        self._reactions.append(
            {
                "channel": channel,
                "ts": ts,
                "emoji": emoji,
            }
        )


# =============================================================================
# Mock QuickBooks Client
# =============================================================================


class MockQuickBooksClient(QuickBooksClient):
    """
    Mock QuickBooks client for testing.

    Records all operations and returns configurable test data. Mirrors the
    real ``QuickBooksClient`` — no ``realm_id`` argument on any method, since
    the runtime auto-injects it from the credential.

    Example:
        from torivers_sdk.context.mocks import MockQuickBooksClient, MockCredentialProxy

        qb = MockQuickBooksClient()
        proxy = MockCredentialProxy(["quickbooks"])
        proxy.register_mock_client("quickbooks", qb)

        company = qb.get_company_info()
        assert company["CompanyInfo"]["CompanyName"] == "Test Company"
    """

    def __init__(self) -> None:
        """Initialize mock QuickBooks client."""
        super().__init__(_auth_context={"mock": True})
        self._operations_performed: list[dict[str, Any]] = []
        self._mock_company_info: dict[str, Any] = {
            "CompanyInfo": {
                "CompanyName": "Test Company",
                "CompanyAddr": {"Line1": "123 Main St"},
            }
        }
        self._mock_invoices: list[dict[str, Any]] = []
        self._mock_customers: list[dict[str, Any]] = []
        self._mock_accounts: list[dict[str, Any]] = []
        self._mock_estimates: list[dict[str, Any]] = []
        self._mock_payments: list[dict[str, Any]] = []
        self._mock_bills: list[dict[str, Any]] = []
        self._mock_bill_payments: list[dict[str, Any]] = []
        self._mock_vendors: list[dict[str, Any]] = []
        self._mock_items: list[dict[str, Any]] = []
        self._mock_journal_entries: list[dict[str, Any]] = []
        self._mock_purchases: list[dict[str, Any]] = []
        self._mock_reports: dict[str, dict[str, Any]] = {
            "ProfitAndLoss": {"Header": {"ReportName": "ProfitAndLoss"}, "Rows": {}},
            "BalanceSheet": {"Header": {"ReportName": "BalanceSheet"}, "Rows": {}},
            "CashFlow": {"Header": {"ReportName": "CashFlow"}, "Rows": {}},
            "TrialBalance": {"Header": {"ReportName": "TrialBalance"}, "Rows": {}},
        }

    def _record(self, operation: str, **kwargs: Any) -> None:
        """Record an operation call (internal helper)."""
        entry = {"operation": operation}
        entry.update(kwargs)
        self._operations_performed.append(entry)

    @staticmethod
    def _paginate(
        items: list[dict[str, Any]], start_position: int, max_results: int
    ) -> list[dict[str, Any]]:
        """Slice a list using QuickBooks 1-indexed pagination semantics."""
        start = max(start_position - 1, 0)
        return items[start : start + max_results]

    def is_authenticated(self) -> bool:
        """Mock is always authenticated."""
        return True

    def get_company_info(self) -> dict[str, Any]:
        """Return mock company info."""
        self._record("get_company_info")
        return dict(self._mock_company_info)

    def list_invoices(
        self,
        max_results: int = 20,
        start_position: int = 1,
    ) -> dict[str, Any]:
        """Return mock invoice list."""
        self._record(
            "list_invoices",
            max_results=max_results,
            start_position=start_position,
        )
        page = self._mock_invoices[start_position - 1 : start_position - 1 + max_results]
        return {"QueryResponse": {"Invoice": page, "maxResults": len(page)}}

    def create_invoice(
        self,
        customer_ref_value: str,
        lines: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Record and return a mock created invoice."""
        invoice = {
            "Id": str(len(self._mock_invoices) + 1),
            "CustomerRef": {"value": customer_ref_value},
            "Line": lines,
        }
        self._mock_invoices.append(invoice)
        self._record(
            "create_invoice",
            customer_ref_value=customer_ref_value,
            lines=lines,
        )
        return {"Invoice": invoice}

    def list_customers(
        self,
        max_results: int = 20,
        start_position: int = 1,
    ) -> dict[str, Any]:
        """Return mock customer list."""
        self._record(
            "list_customers",
            max_results=max_results,
            start_position=start_position,
        )
        page = self._mock_customers[start_position - 1 : start_position - 1 + max_results]
        return {"QueryResponse": {"Customer": page, "maxResults": len(page)}}

    def list_accounts(
        self,
        max_results: int = 20,
        start_position: int = 1,
    ) -> dict[str, Any]:
        """Return mock account list."""
        self._record(
            "list_accounts",
            max_results=max_results,
            start_position=start_position,
        )
        page = self._paginate(self._mock_accounts, start_position, max_results)
        return {"QueryResponse": {"Account": page, "maxResults": len(page)}}

    # -- Invoices (extended) --------------------------------------------------

    def get_invoice(self, invoice_id: str) -> dict[str, Any]:
        """Return a single mock invoice by ID (or a stub if not pre-loaded)."""
        self._record("get_invoice", invoice_id=invoice_id)
        for inv in self._mock_invoices:
            if str(inv.get("Id")) == str(invoice_id):
                return {"Invoice": inv}
        return {"Invoice": {"Id": invoice_id, "SyncToken": "0"}}

    def update_invoice(
        self,
        invoice_id: str,
        sync_token: str,
        fields: dict[str, Any],
    ) -> dict[str, Any]:
        """Apply a sparse update to a mock invoice in place."""
        self._record(
            "update_invoice",
            invoice_id=invoice_id,
            sync_token=sync_token,
            fields=fields,
        )
        for inv in self._mock_invoices:
            if str(inv.get("Id")) == str(invoice_id):
                inv.update(fields)
                inv["SyncToken"] = str(int(sync_token) + 1)
                return {"Invoice": inv}
        stub = {"Id": invoice_id, "SyncToken": str(int(sync_token) + 1), **fields}
        return {"Invoice": stub}

    def send_invoice_email(
        self,
        invoice_id: str,
        send_to_email: str | None = None,
    ) -> dict[str, Any]:
        """Mock invoice email send."""
        self._record(
            "send_invoice_email",
            invoice_id=invoice_id,
            send_to_email=send_to_email,
        )
        return {"Invoice": {"Id": invoice_id, "EmailStatus": "EmailSent"}}

    def void_invoice(
        self, invoice_id: str, sync_token: str
    ) -> dict[str, Any]:
        """Mock void of an invoice."""
        self._record(
            "void_invoice",
            invoice_id=invoice_id,
            sync_token=sync_token,
        )
        for inv in self._mock_invoices:
            if str(inv.get("Id")) == str(invoice_id):
                inv["status"] = "Voided"
                inv["SyncToken"] = str(int(sync_token) + 1)
                return {"Invoice": inv}
        return {
            "Invoice": {
                "Id": invoice_id,
                "status": "Voided",
                "SyncToken": str(int(sync_token) + 1),
            }
        }

    # -- Estimates ------------------------------------------------------------

    def list_estimates(
        self,
        max_results: int = 20,
        start_position: int = 1,
    ) -> dict[str, Any]:
        """Return mock estimate list."""
        self._record(
            "list_estimates",
            max_results=max_results,
            start_position=start_position,
        )
        page = self._paginate(self._mock_estimates, start_position, max_results)
        return {"QueryResponse": {"Estimate": page, "maxResults": len(page)}}

    def create_estimate(
        self,
        customer_ref_value: str,
        lines: list[dict[str, Any]],
        txn_date: str | None = None,
        expiration_date: str | None = None,
    ) -> dict[str, Any]:
        """Record and return a mock created estimate."""
        estimate = {
            "Id": str(len(self._mock_estimates) + 1),
            "CustomerRef": {"value": customer_ref_value},
            "Line": lines,
            "TxnDate": txn_date,
            "ExpirationDate": expiration_date,
        }
        self._mock_estimates.append(estimate)
        self._record(
            "create_estimate",
            customer_ref_value=customer_ref_value,
            lines=lines,
            txn_date=txn_date,
            expiration_date=expiration_date,
        )
        return {"Estimate": estimate}

    def send_estimate_email(
        self,
        estimate_id: str,
        send_to_email: str | None = None,
    ) -> dict[str, Any]:
        """Mock estimate email send."""
        self._record(
            "send_estimate_email",
            estimate_id=estimate_id,
            send_to_email=send_to_email,
        )
        return {"Estimate": {"Id": estimate_id, "EmailStatus": "EmailSent"}}

    # -- Payments -------------------------------------------------------------

    def list_payments(
        self,
        max_results: int = 20,
        start_position: int = 1,
    ) -> dict[str, Any]:
        """Return mock payment list."""
        self._record(
            "list_payments",
            max_results=max_results,
            start_position=start_position,
        )
        page = self._paginate(self._mock_payments, start_position, max_results)
        return {"QueryResponse": {"Payment": page, "maxResults": len(page)}}

    def create_payment(
        self,
        customer_ref_value: str,
        total_amount: float,
        linked_invoice_id: str | None = None,
        txn_date: str | None = None,
        payment_method_ref_value: str | None = None,
    ) -> dict[str, Any]:
        """Record and return a mock created customer payment."""
        payment = {
            "Id": str(len(self._mock_payments) + 1),
            "CustomerRef": {"value": customer_ref_value},
            "TotalAmt": total_amount,
            "TxnDate": txn_date,
            "LinkedTxn": (
                [{"TxnId": linked_invoice_id, "TxnType": "Invoice"}]
                if linked_invoice_id
                else []
            ),
            "PaymentMethodRef": (
                {"value": payment_method_ref_value} if payment_method_ref_value else None
            ),
        }
        self._mock_payments.append(payment)
        self._record(
            "create_payment",
            customer_ref_value=customer_ref_value,
            total_amount=total_amount,
            linked_invoice_id=linked_invoice_id,
            txn_date=txn_date,
            payment_method_ref_value=payment_method_ref_value,
        )
        return {"Payment": payment}

    # -- Bills ----------------------------------------------------------------

    def list_bills(
        self,
        max_results: int = 20,
        start_position: int = 1,
    ) -> dict[str, Any]:
        """Return mock bill list."""
        self._record(
            "list_bills",
            max_results=max_results,
            start_position=start_position,
        )
        page = self._paginate(self._mock_bills, start_position, max_results)
        return {"QueryResponse": {"Bill": page, "maxResults": len(page)}}

    def get_bill(self, bill_id: str) -> dict[str, Any]:
        """Return a single mock bill by ID."""
        self._record("get_bill", bill_id=bill_id)
        for bill in self._mock_bills:
            if str(bill.get("Id")) == str(bill_id):
                return {"Bill": bill}
        return {"Bill": {"Id": bill_id, "SyncToken": "0"}}

    def create_bill(
        self,
        vendor_ref_value: str,
        lines: list[dict[str, Any]],
        due_date: str | None = None,
        txn_date: str | None = None,
        ap_account_ref_value: str | None = None,
    ) -> dict[str, Any]:
        """Record and return a mock created bill."""
        bill = {
            "Id": str(len(self._mock_bills) + 1),
            "VendorRef": {"value": vendor_ref_value},
            "Line": lines,
            "DueDate": due_date,
            "TxnDate": txn_date,
            "APAccountRef": (
                {"value": ap_account_ref_value} if ap_account_ref_value else None
            ),
        }
        self._mock_bills.append(bill)
        self._record(
            "create_bill",
            vendor_ref_value=vendor_ref_value,
            lines=lines,
            due_date=due_date,
            txn_date=txn_date,
            ap_account_ref_value=ap_account_ref_value,
        )
        return {"Bill": bill}

    def list_bill_payments(
        self,
        max_results: int = 20,
        start_position: int = 1,
    ) -> dict[str, Any]:
        """Return mock bill payment list."""
        self._record(
            "list_bill_payments",
            max_results=max_results,
            start_position=start_position,
        )
        page = self._paginate(self._mock_bill_payments, start_position, max_results)
        return {"QueryResponse": {"BillPayment": page, "maxResults": len(page)}}

    def create_bill_payment(
        self,
        vendor_ref_value: str,
        total_amount: float,
        linked_bill_ids: list[str],
        bank_account_ref_value: str,
        txn_date: str | None = None,
    ) -> dict[str, Any]:
        """Record and return a mock created bill payment."""
        bill_payment = {
            "Id": str(len(self._mock_bill_payments) + 1),
            "VendorRef": {"value": vendor_ref_value},
            "TotalAmt": total_amount,
            "TxnDate": txn_date,
            "PayType": "Check",
            "CheckPayment": {"BankAccountRef": {"value": bank_account_ref_value}},
            "Line": [
                {"LinkedTxn": [{"TxnId": bid, "TxnType": "Bill"}]} for bid in linked_bill_ids
            ],
        }
        self._mock_bill_payments.append(bill_payment)
        self._record(
            "create_bill_payment",
            vendor_ref_value=vendor_ref_value,
            total_amount=total_amount,
            linked_bill_ids=linked_bill_ids,
            bank_account_ref_value=bank_account_ref_value,
            txn_date=txn_date,
        )
        return {"BillPayment": bill_payment}

    # -- Customers (extended) -------------------------------------------------

    def get_customer(self, customer_id: str) -> dict[str, Any]:
        """Return a single mock customer by ID."""
        self._record("get_customer", customer_id=customer_id)
        for cust in self._mock_customers:
            if str(cust.get("Id")) == str(customer_id):
                return {"Customer": cust}
        return {"Customer": {"Id": customer_id, "SyncToken": "0"}}

    def create_customer(
        self,
        display_name: str,
        email: str | None = None,
        phone: str | None = None,
        company_name: str | None = None,
        billing_addr: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Record and return a mock created customer."""
        customer = {
            "Id": str(len(self._mock_customers) + 1),
            "DisplayName": display_name,
            "PrimaryEmailAddr": {"Address": email} if email else None,
            "PrimaryPhone": {"FreeFormNumber": phone} if phone else None,
            "CompanyName": company_name,
            "BillAddr": billing_addr,
        }
        self._mock_customers.append(customer)
        self._record(
            "create_customer",
            display_name=display_name,
            email=email,
            phone=phone,
            company_name=company_name,
            billing_addr=billing_addr,
        )
        return {"Customer": customer}

    def update_customer(
        self,
        customer_id: str,
        sync_token: str,
        fields: dict[str, Any],
    ) -> dict[str, Any]:
        """Apply a sparse update to a mock customer."""
        self._record(
            "update_customer",
            customer_id=customer_id,
            sync_token=sync_token,
            fields=fields,
        )
        for cust in self._mock_customers:
            if str(cust.get("Id")) == str(customer_id):
                cust.update(fields)
                cust["SyncToken"] = str(int(sync_token) + 1)
                return {"Customer": cust}
        return {
            "Customer": {
                "Id": customer_id,
                "SyncToken": str(int(sync_token) + 1),
                **fields,
            }
        }

    # -- Vendors --------------------------------------------------------------

    def list_vendors(
        self,
        max_results: int = 20,
        start_position: int = 1,
    ) -> dict[str, Any]:
        """Return mock vendor list."""
        self._record(
            "list_vendors",
            max_results=max_results,
            start_position=start_position,
        )
        page = self._paginate(self._mock_vendors, start_position, max_results)
        return {"QueryResponse": {"Vendor": page, "maxResults": len(page)}}

    def get_vendor(self, vendor_id: str) -> dict[str, Any]:
        """Return a single mock vendor by ID."""
        self._record("get_vendor", vendor_id=vendor_id)
        for vendor in self._mock_vendors:
            if str(vendor.get("Id")) == str(vendor_id):
                return {"Vendor": vendor}
        return {"Vendor": {"Id": vendor_id, "SyncToken": "0"}}

    def create_vendor(
        self,
        display_name: str,
        email: str | None = None,
        phone: str | None = None,
        company_name: str | None = None,
    ) -> dict[str, Any]:
        """Record and return a mock created vendor."""
        vendor = {
            "Id": str(len(self._mock_vendors) + 1),
            "DisplayName": display_name,
            "PrimaryEmailAddr": {"Address": email} if email else None,
            "PrimaryPhone": {"FreeFormNumber": phone} if phone else None,
            "CompanyName": company_name,
        }
        self._mock_vendors.append(vendor)
        self._record(
            "create_vendor",
            display_name=display_name,
            email=email,
            phone=phone,
            company_name=company_name,
        )
        return {"Vendor": vendor}

    # -- Items ----------------------------------------------------------------

    def list_items(
        self,
        max_results: int = 20,
        start_position: int = 1,
    ) -> dict[str, Any]:
        """Return mock item list."""
        self._record(
            "list_items",
            max_results=max_results,
            start_position=start_position,
        )
        page = self._paginate(self._mock_items, start_position, max_results)
        return {"QueryResponse": {"Item": page, "maxResults": len(page)}}

    def get_item(self, item_id: str) -> dict[str, Any]:
        """Return a single mock item by ID."""
        self._record("get_item", item_id=item_id)
        for item in self._mock_items:
            if str(item.get("Id")) == str(item_id):
                return {"Item": item}
        return {"Item": {"Id": item_id, "SyncToken": "0"}}

    def create_item(
        self,
        name: str,
        item_type: str,
        income_account_ref_value: str,
        unit_price: float | None = None,
        description: str | None = None,
        expense_account_ref_value: str | None = None,
    ) -> dict[str, Any]:
        """Record and return a mock created item."""
        item = {
            "Id": str(len(self._mock_items) + 1),
            "Name": name,
            "Type": item_type,
            "IncomeAccountRef": {"value": income_account_ref_value},
            "UnitPrice": unit_price,
            "Description": description,
            "ExpenseAccountRef": (
                {"value": expense_account_ref_value} if expense_account_ref_value else None
            ),
        }
        self._mock_items.append(item)
        self._record(
            "create_item",
            name=name,
            item_type=item_type,
            income_account_ref_value=income_account_ref_value,
            unit_price=unit_price,
            description=description,
            expense_account_ref_value=expense_account_ref_value,
        )
        return {"Item": item}

    # -- Accounts (extended) --------------------------------------------------

    def get_account(self, account_id: str) -> dict[str, Any]:
        """Return a single mock account by ID."""
        self._record("get_account", account_id=account_id)
        for acct in self._mock_accounts:
            if str(acct.get("Id")) == str(account_id):
                return {"Account": acct}
        return {"Account": {"Id": account_id, "SyncToken": "0"}}

    def create_account(
        self,
        name: str,
        account_type: str,
        account_sub_type: str | None = None,
        description: str | None = None,
        currency_ref_value: str | None = None,
    ) -> dict[str, Any]:
        """Record and return a mock created account."""
        account = {
            "Id": str(len(self._mock_accounts) + 1),
            "Name": name,
            "AccountType": account_type,
            "AccountSubType": account_sub_type,
            "Description": description,
            "CurrencyRef": (
                {"value": currency_ref_value} if currency_ref_value else None
            ),
        }
        self._mock_accounts.append(account)
        self._record(
            "create_account",
            name=name,
            account_type=account_type,
            account_sub_type=account_sub_type,
            description=description,
            currency_ref_value=currency_ref_value,
        )
        return {"Account": account}

    # -- Journal entries ------------------------------------------------------

    def list_journal_entries(
        self,
        max_results: int = 20,
        start_position: int = 1,
    ) -> dict[str, Any]:
        """Return mock journal entry list."""
        self._record(
            "list_journal_entries",
            max_results=max_results,
            start_position=start_position,
        )
        page = self._paginate(self._mock_journal_entries, start_position, max_results)
        return {"QueryResponse": {"JournalEntry": page, "maxResults": len(page)}}

    def create_journal_entry(
        self,
        lines: list[dict[str, Any]],
        txn_date: str | None = None,
        doc_number: str | None = None,
    ) -> dict[str, Any]:
        """Record and return a mock created journal entry."""
        entry = {
            "Id": str(len(self._mock_journal_entries) + 1),
            "Line": lines,
            "TxnDate": txn_date,
            "DocNumber": doc_number,
        }
        self._mock_journal_entries.append(entry)
        self._record(
            "create_journal_entry",
            lines=lines,
            txn_date=txn_date,
            doc_number=doc_number,
        )
        return {"JournalEntry": entry}

    # -- Purchases ------------------------------------------------------------

    def list_purchases(
        self,
        max_results: int = 20,
        start_position: int = 1,
    ) -> dict[str, Any]:
        """Return mock purchase list."""
        self._record(
            "list_purchases",
            max_results=max_results,
            start_position=start_position,
        )
        page = self._paginate(self._mock_purchases, start_position, max_results)
        return {"QueryResponse": {"Purchase": page, "maxResults": len(page)}}

    def create_purchase(
        self,
        payment_type: str,
        account_ref_value: str,
        lines: list[dict[str, Any]],
        entity_ref_value: str | None = None,
        entity_ref_type: str | None = None,
        txn_date: str | None = None,
    ) -> dict[str, Any]:
        """Record and return a mock created purchase."""
        purchase = {
            "Id": str(len(self._mock_purchases) + 1),
            "PaymentType": payment_type,
            "AccountRef": {"value": account_ref_value},
            "Line": lines,
            "EntityRef": (
                {"value": entity_ref_value, "type": entity_ref_type}
                if entity_ref_value
                else None
            ),
            "TxnDate": txn_date,
        }
        self._mock_purchases.append(purchase)
        self._record(
            "create_purchase",
            payment_type=payment_type,
            account_ref_value=account_ref_value,
            lines=lines,
            entity_ref_value=entity_ref_value,
            entity_ref_type=entity_ref_type,
            txn_date=txn_date,
        )
        return {"Purchase": purchase}

    # -- Reports --------------------------------------------------------------

    def get_profit_and_loss(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        accounting_method: str | None = None,
    ) -> dict[str, Any]:
        """Return the mock Profit and Loss report."""
        self._record(
            "get_profit_and_loss",
            start_date=start_date,
            end_date=end_date,
            accounting_method=accounting_method,
        )
        return dict(self._mock_reports["ProfitAndLoss"])

    def get_balance_sheet(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        accounting_method: str | None = None,
    ) -> dict[str, Any]:
        """Return the mock Balance Sheet report."""
        self._record(
            "get_balance_sheet",
            start_date=start_date,
            end_date=end_date,
            accounting_method=accounting_method,
        )
        return dict(self._mock_reports["BalanceSheet"])

    def get_cash_flow(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> dict[str, Any]:
        """Return the mock Cash Flow report."""
        self._record(
            "get_cash_flow",
            start_date=start_date,
            end_date=end_date,
        )
        return dict(self._mock_reports["CashFlow"])

    def get_trial_balance(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> dict[str, Any]:
        """Return the mock Trial Balance report."""
        self._record(
            "get_trial_balance",
            start_date=start_date,
            end_date=end_date,
        )
        return dict(self._mock_reports["TrialBalance"])

    def get_performed_operations(self) -> list[dict[str, Any]]:
        """Return all operations performed so far (for test assertions)."""
        return list(self._operations_performed)

    def set_mock_company_info(self, company_info: dict[str, Any]) -> None:
        """Override the default mock company info."""
        self._mock_company_info = company_info

    def add_mock_customer(self, customer: dict[str, Any]) -> None:
        """Add a mock customer."""
        self._mock_customers.append(customer)

    def add_mock_account(self, account: dict[str, Any]) -> None:
        """Add a mock account."""
        self._mock_accounts.append(account)

    def add_mock_invoice(self, invoice: dict[str, Any]) -> None:
        """Add a mock invoice (used to seed get/update/void/list responses)."""
        self._mock_invoices.append(invoice)

    def add_mock_estimate(self, estimate: dict[str, Any]) -> None:
        """Add a mock estimate."""
        self._mock_estimates.append(estimate)

    def add_mock_payment(self, payment: dict[str, Any]) -> None:
        """Add a mock customer payment."""
        self._mock_payments.append(payment)

    def add_mock_bill(self, bill: dict[str, Any]) -> None:
        """Add a mock bill."""
        self._mock_bills.append(bill)

    def add_mock_bill_payment(self, bill_payment: dict[str, Any]) -> None:
        """Add a mock bill payment."""
        self._mock_bill_payments.append(bill_payment)

    def add_mock_vendor(self, vendor: dict[str, Any]) -> None:
        """Add a mock vendor."""
        self._mock_vendors.append(vendor)

    def add_mock_item(self, item: dict[str, Any]) -> None:
        """Add a mock item."""
        self._mock_items.append(item)

    def add_mock_journal_entry(self, entry: dict[str, Any]) -> None:
        """Add a mock journal entry."""
        self._mock_journal_entries.append(entry)

    def add_mock_purchase(self, purchase: dict[str, Any]) -> None:
        """Add a mock purchase/expense transaction."""
        self._mock_purchases.append(purchase)

    def set_mock_report(self, report_name: str, payload: dict[str, Any]) -> None:
        """
        Override the default mock body for a report.

        Args:
            report_name: One of "ProfitAndLoss", "BalanceSheet", "CashFlow", "TrialBalance".
            payload: Full report dict to return from the matching getter.
        """
        if report_name not in self._mock_reports:
            raise ValueError(
                f"Unknown report '{report_name}'. Valid values: "
                f"{sorted(self._mock_reports)}"
            )
        self._mock_reports[report_name] = payload

    def clear_mock_data(self) -> None:
        """Clear all mock data and recorded operations."""
        self._mock_invoices.clear()
        self._mock_customers.clear()
        self._mock_accounts.clear()
        self._mock_estimates.clear()
        self._mock_payments.clear()
        self._mock_bills.clear()
        self._mock_bill_payments.clear()
        self._mock_vendors.clear()
        self._mock_items.clear()
        self._mock_journal_entries.clear()
        self._mock_purchases.clear()
        self._operations_performed.clear()


# =============================================================================
# Mock Credential Proxy
# =============================================================================


class MockCredentialProxy(CredentialProxy):
    """
    Mock credential proxy for testing.

    Allows registering mock service clients for use in tests.

    Example:
        proxy = MockCredentialProxy(["gmail", "slack"])

        # Register mock clients
        proxy.register_mock_client("gmail", MockGmailClient())
        proxy.register_mock_client("slack", MockSlackClient())

        # Use in automation
        gmail = proxy.get_client("gmail")
        gmail.send_email(to=["test@example.com"], subject="Test", body="Hello")
    """

    def __init__(self, allowed_services: list[str]) -> None:
        """
        Initialize mock credential proxy.

        Args:
            allowed_services: List of allowed service names
        """
        super().__init__(allowed_services, _internal_context={"mock": True})

    def register_mock_client(self, service: str, client: ServiceClient) -> None:
        """
        Register a mock client for a service.

        Args:
            service: Service name
            client: Mock client instance

        Raises:
            CredentialNotAllowedError: If service not in allowed list
        """
        self._register_client(service, client)

    def unregister_mock_client(self, service: str) -> None:
        """
        Unregister a mock client.

        Args:
            service: Service name to unregister
        """
        self._unregister_client(service)

    def clear_all_mock_clients(self) -> None:
        """Clear all registered mock clients."""
        self._clear_all_clients()

    @classmethod
    def with_gmail(
        cls, allowed_services: list[str] | None = None
    ) -> "MockCredentialProxy":
        """
        Create a mock proxy with a Gmail client pre-registered.

        Args:
            allowed_services: Additional allowed services (gmail is added automatically)

        Returns:
            MockCredentialProxy with MockGmailClient registered
        """
        services = list(allowed_services or [])
        if "gmail" not in services:
            services.append("gmail")

        proxy = cls(services)
        proxy.register_mock_client("gmail", MockGmailClient())
        return proxy

    @classmethod
    def with_google_sheets(
        cls, allowed_services: list[str] | None = None
    ) -> "MockCredentialProxy":
        """
        Create a mock proxy with a Google Sheets client pre-registered.

        Args:
            allowed_services: Additional allowed services

        Returns:
            MockCredentialProxy with MockGoogleSheetsClient registered
        """
        services = list(allowed_services or [])
        if "google_sheets" not in services:
            services.append("google_sheets")

        proxy = cls(services)
        proxy.register_mock_client("google_sheets", MockGoogleSheetsClient())
        return proxy

    @classmethod
    def with_slack(
        cls, allowed_services: list[str] | None = None
    ) -> "MockCredentialProxy":
        """
        Create a mock proxy with a Slack client pre-registered.

        Args:
            allowed_services: Additional allowed services

        Returns:
            MockCredentialProxy with MockSlackClient registered
        """
        services = list(allowed_services or [])
        if "slack" not in services:
            services.append("slack")

        proxy = cls(services)
        proxy.register_mock_client("slack", MockSlackClient())
        return proxy

    @classmethod
    def with_quickbooks(
        cls, allowed_services: list[str] | None = None
    ) -> "MockCredentialProxy":
        """
        Create a mock proxy with a QuickBooks client pre-registered.

        Args:
            allowed_services: Additional allowed services (quickbooks is added automatically)

        Returns:
            MockCredentialProxy with MockQuickBooksClient registered
        """
        services = list(allowed_services or [])
        if "quickbooks" not in services:
            services.append("quickbooks")

        proxy = cls(services)
        proxy.register_mock_client("quickbooks", MockQuickBooksClient())
        return proxy

    @classmethod
    def with_all_services(cls) -> "MockCredentialProxy":
        """
        Create a mock proxy with all service clients pre-registered.

        Returns:
            MockCredentialProxy with all mock clients registered
        """
        proxy = cls(["gmail", "google_sheets", "slack", "quickbooks"])
        proxy.register_mock_client("gmail", MockGmailClient())
        proxy.register_mock_client("google_sheets", MockGoogleSheetsClient())
        proxy.register_mock_client("slack", MockSlackClient())
        proxy.register_mock_client("quickbooks", MockQuickBooksClient())
        return proxy
