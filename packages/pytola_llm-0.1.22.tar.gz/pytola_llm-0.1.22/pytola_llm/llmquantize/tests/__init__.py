"""Tests for llmquantize module."""
