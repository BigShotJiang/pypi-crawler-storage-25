"""Specialized agents for multi-agent cognitive processing."""

import json
import time
from typing import Optional, Dict, Any, AsyncIterator, List

from .minimax_client import MiniMaxClient
from .tools import TOOL_REGISTRY


def _normalize_to_api_format(tools: Optional[List[Dict[str, Any]]]) -> Optional[List[Dict[str, Any]]]:
    """Convert flat tool schemas to MiniMax API format: {type: function, function: {...}}.

    TOOL_REGISTRY.list() returns flat schemas like {name, description, parameters}.
    MiniMax API expects {type: 'function', function: {name, description, parameters}}.
    External callers may already send the wrapped format — those pass through unchanged.
    """
    if not tools:
        return None
    result = []
    for t in tools:
        if t.get("type") == "function" and "function" in t:
            result.append(t)  # Already in correct format
        elif "name" in t:
            result.append({
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "parameters": t.get("parameters", {}),
                },
            })
    return result if result else None

import re

# Patterns matching MiniMax reasoning output — same as http_server.py
_THINK_TAGS = re.compile(r"<think>.*?</think>", re.DOTALL)
_MINIMAX_BLOCKS = re.compile(r"\[(COMPLEXITY|REASON|TOOL_CALL|OUTPUT|NOTES|NEXT_PLAN):?.*?\]", re.DOTALL)
_HORIZONTAL_RULE = re.compile(r"^\s*---\s*$", re.MULTILINE)


def _strip_reasoning_tags(text: str) -> str:
    """Remove MiniMax reasoning / think tags from text."""
    if not text:
        return text
    text = _THINK_TAGS.sub("", text)
    text = _MINIMAX_BLOCKS.sub("", text)
    text = _HORIZONTAL_RULE.sub("", text)
    return text.strip()


class Agent:
    """Base agent class."""

    def __init__(
        self,
        agent_id: str,
        role: str,
        persona: str,
        api_key: Optional[str] = None,
        model: str = "MiniMax-M2.7",
        max_tokens: int = 2000,
    ):
        self.agent_id = agent_id
        self.role = role
        self.persona = persona
        self.llm = MiniMaxClient(api_key)
        self.model = model
        self.max_tokens = max_tokens

    def _build_prompt(self, task: str, context: str = "", tools_prompt: str = "") -> str:
        """Build the prompt from task and context."""
        base = f"""{self.persona}

CONTEXT:
{context}

TASK:
{task}"""
        if tools_prompt:
            base += f"\n\n{tools_prompt}"
        base += f"\n\nRespond as a specialized {self.role} agent."
        return base

    def process(self, task: str, context: str = "") -> Dict[str, Any]:
        """Process a task with this agent (blocking)."""
        prompt = self._build_prompt(task, context)
        response = self.llm.generate(
            prompt=prompt,
            model=self.model,
            max_tokens=self.max_tokens,
        )
        return self._result(response, task)

    async def process_async(
        self,
        task: str,
        context: str = "",
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> AsyncIterator[Dict[str, Any]]:
        """Process a task with this agent (async).

        Executes tools internally and feeds results back to the LLM,
        so callers receive only tokens and a final done event.

        Yields:
            {"type": "start", "agent_id": "...", "role": "..."}
            {"type": "token", "content": "..."}
            {"type": "done", "response": "...", "timestamp": ...}
        """
        yield {"type": "start", "agent_id": self.agent_id, "role": self.role}

        # Build message history — switch to generate_stream_from_messages
        # so tool results can be appended and the LLM can continue
        system_msg = {
            "role": "system",
            "content": f"{self.persona}\n\nRespond as a specialized {self.role} agent.",
        }
        context_block = f"\nCONTEXT:\n{context}\n" if context else ""
        task_msg = {
            "role": "user",
            "content": f"{context_block}\nTASK:\n{task}",
        }
        messages = [system_msg, task_msg]

        # Allow up to 3 tool-call rounds before giving up
        max_rounds = 3
        accumulated = ""
        # Normalize flat tool schemas to MiniMax API format before LLM calls
        normalized_tools = _normalize_to_api_format(tools)

        for _round in range(max_rounds):
            # Stream from current message state
            async for event in self.llm.generate_stream_from_messages(
                messages=messages,
                model=self.model,
                max_tokens=self.max_tokens,
                tools=normalized_tools,
            ):
                if isinstance(event, dict):
                    if event["type"] == "token":
                        content = event["content"]
                        accumulated += content
                        yield {"type": "token", "content": content}
                    elif event["type"] == "tool_call":
                        # Execute tool and append result to messages, then continue
                        name = event.get("name", "")
                        raw_args = event.get("arguments", "{}")
                        try:
                            args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
                        except (json.JSONDecodeError, TypeError):
                            args = {"raw": str(raw_args)}

                        tool_result = TOOL_REGISTRY.execute(name, args)
                        tool_content = json.dumps(tool_result)

                        # Build args as a JSON string (required by OpenAI tool_calls format)
                        args_str = raw_args if isinstance(raw_args, str) else json.dumps(raw_args)
                        call_id = f"call_{_round:02d}_{event.get('index', 0):04d}"
                        messages.append({
                            "role": "assistant",
                            "content": None,
                            "tool_calls": [{
                                "id": call_id,
                                "type": "function",
                                "function": {
                                    "name": name,
                                    "arguments": args_str,
                                },
                            }],
                        })
                        messages.append({
                            "role": "tool",
                            "tool_call_id": call_id,
                            "content": tool_content,
                        })
                        # Continue to next iteration to get LLM response to tool result
                        break
                else:
                    # Plain string token (backward compat)
                    accumulated += event
                    yield {"type": "token", "content": event}

            else:
                # async-for exhausted naturally — no tool call, LLM finished
                break

        yield self._result(accumulated, task)

    def _result(self, response: str, task: str) -> Dict[str, Any]:
        """Build a standard result dict with reasoning tags stripped."""
        return {
            "type": "done",
            "agent_id": self.agent_id,
            "role": self.role,
            "task": task,
            "response": _strip_reasoning_tags(response),
            "timestamp": time.time(),
        }


# ── Persona definitions ────────────────────────────────────────────────────────

CREATOR_PERSONA = """You are a Creator Agent. Your role is to generate creative solutions and content.
You excel at thinking outside the box and proposing novel approaches.
Focus on innovation and possibilities, not limitations.
Be bold and imaginative in your responses.
When providing a solution, include concrete details, examples, and actionable steps.

IMPORTANT CODE ANALYSIS RULE: If the user asks you to analyze, modify, or reason about any file in a codebase,
you MUST first read that file with your read_file tool before giving any analysis or suggestions.
Do NOT reason about code you have not read. Do NOT describe patterns, classes, or functions that you
have not seen firsthand. If you have not read a file, say explicitly: I need to read that file first."""

CRITIC_PERSONA = """You are a Critic Agent. Your role is to evaluate solutions and identify flaws.
You excel at logical analysis and finding potential problems.
Focus on accuracy, consistency, and potential issues.
Be thorough and precise in your criticism, but always constructive — suggest improvements, don't just tear down.
When reviewing, consider: feasibility, completeness, edge cases, and clarity.

IMPORTANT CODE ANALYSIS RULE: If the user asks you to analyze, modify, or reason about any file in a codebase,
you MUST first read that file with your read_file tool before giving any analysis or suggestions.
Do NOT reason about code you have not read. Do NOT describe patterns, classes, or functions that you
have not seen firsthand. If you have not read a file, say explicitly: I need to read that file first."""

ANALYST_PERSONA = """You are an Analyst Agent. Your role is to break down complex problems into structured components.
You excel at understanding systems and identifying patterns.
Focus on thorough examination and structured thinking.
Be methodical and detail-oriented in your analysis.
Break the problem into: context, key constraints, success criteria, and potential approaches.

CRITICAL CODE ANALYSIS RULE — MANDATORY:
- If the user asks you to analyze, modify, or reason about any file in a codebase, you MUST call the read_file tool FIRST to read the actual file content.
- Do NOT reason about code you have not read. Do NOT describe patterns, classes, or functions that you have not seen firsthand.
- The CODE REFERENCE section (if present) contains the actual source code. Base your analysis ONLY on what you see there.
- If you need to read additional files to answer the question, call the read_file tool for each one.
- Never generate analysis about code you have not personally read or seen in the CODE REFERENCE.
- **Code review, bug analysis, or modification tasks are ALWAYS MODERATE complexity** — never SIMPLE. Mark them as [COMPLEXITY: MODERATE] or [COMPLEXITY: COMPLEX].

IMPORTANT: Start your response with a one-line complexity classification in this exact format:
[COMPLEXITY: SIMPLE]  — if the task is straightforward, factual, or needs a direct answer
[COMPLEXITY: MODERATE] — if the task needs some reasoning or creative approach but has a clear path
[COMPLEXITY: COMPLEX]  — if the task is multi-faceted, ambiguous, or needs deep reasoning with trade-offs

After the [COMPLEXITY:] line, add a one-line [REASON: ...] explaining your classification, then "---", then your full analysis.

IMPORTANT: You have access to tools (functions). If you need to use a tool to answer the user's question,
call the appropriate tool instead of trying to reason without it."""


# ── Agent subclasses ──────────────────────────────────────────────────────────

class CreatorAgent(Agent):
    def __init__(self, api_key: Optional[str] = None, model: str = "MiniMax-M2.7", max_tokens: int = 4000):
        super().__init__(
            agent_id="creator",
            role="Creator",
            persona=CREATOR_PERSONA,
            api_key=api_key,
            model=model,
            max_tokens=max_tokens,
        )


class CriticAgent(Agent):
    def __init__(self, api_key: Optional[str] = None, model: str = "MiniMax-M2.7", max_tokens: int = 8000):
        super().__init__(
            agent_id="critic",
            role="Critic",
            persona=CRITIC_PERSONA,
            api_key=api_key,
            model=model,
            max_tokens=max_tokens,
        )


class AnalystAgent(Agent):
    def __init__(self, api_key: Optional[str] = None, model: str = "MiniMax-M2.7", max_tokens: int = 12000):
        super().__init__(
            agent_id="analyst",
            role="Analyst",
            persona=ANALYST_PERSONA,
            api_key=api_key,
            model=model,
            max_tokens=max_tokens,
        )
