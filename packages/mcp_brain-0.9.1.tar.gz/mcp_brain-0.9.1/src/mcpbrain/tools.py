"""Local tool registry for MCP Brain — tools it can actually execute.

Each tool has:
  schema    — OpenAI function-compatible definition
  execute() — takes kwargs, returns a result dict

Tools are registered in TOOLS and can be listed, looked up, and called by name.
"""

import os
import re
import json
import itertools
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable


# ── Tool schemas (OpenAI function-compatible) ─────────────────────────────────

TERMINAL_SCHEMA = {
    "name": "terminal",
    "description": "Execute a shell command and return its stdout/stderr.",
    "parameters": {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "Shell command to execute"},
            "timeout": {"type": "integer", "description": "Max seconds to wait (default: 60)", "default": 60},
            "workdir": {"type": "string", "description": "Working directory for the command"},
        },
        "required": ["command"],
    },
}

READ_FILE_SCHEMA = {
    "name": "read_file",
    "description": "Read the contents of a file. Use for reading source code, configs, logs, etc.",
    "parameters": {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Absolute path to the file to read"},
            "offset": {"type": "integer", "description": "Line number to start reading from (1-indexed, default: 1)", "default": 1},
            "limit": {"type": "integer", "description": "Maximum number of lines to read (default: 500, max: 2000)", "default": 500},
        },
        "required": ["path"],
    },
}

WRITE_FILE_SCHEMA = {
    "name": "write_file",
    "description": "Write content to a file, completely replacing existing content. Creates parent directories automatically.",
    "parameters": {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Absolute path to the file to write"},
            "content": {"type": "string", "description": "Content to write to the file"},
        },
        "required": ["path", "content"],
    },
}

SKILL_VIEW_SCHEMA = {
    "name": "skill_view",
    "description": "Load the full content of a Hermes skill by name.",
    "parameters": {
        "type": "object",
        "properties": {
            "skill_name": {"type": "string", "description": "Name of the skill to view"},
        },
        "required": ["skill_name"],
    },
}

WEB_SEARCH_SCHEMA = {
    "name": "web_search",
    "description": "Search the web for information on any topic. Returns up to 5 relevant results with titles, URLs, and descriptions.",
    "parameters": {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "The search query to look up on the web"},
        },
        "required": ["query"],
    },
}

GIT_RUN_SCHEMA = {
    "name": "git_run",
    "description": "Run a git command in a repository. Returns the git command output.",
    "parameters": {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "Git command to run (without 'git' prefix, e.g. 'status', 'log --oneline -5')"},
            "path": {"type": "string", "description": "Path to the git repository (defaults to current working directory)"},
        },
        "required": ["command"],
    },
}


# ── Tool executors ────────────────────────────────────────────────────────────

def _terminal(command: str, timeout: int = 60, workdir: Optional[str] = None) -> Dict[str, Any]:
    """Execute a shell command and return stdout + stderr."""
    # Enrich PATH to include common user binaries locations
    extra_path = "/home/mc411/.local/bin:/usr/local/bin:/usr/bin:/bin"
    env = os.environ.copy()
    if "PATH" in env:
        env["PATH"] = f"{extra_path}:{env['PATH']}"
    else:
        env["PATH"] = extra_path

    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=workdir,
            env=env,
        )
        return {
            "success": result.returncode == 0,
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "returncode": -1, "stdout": "", "stderr": f"Command timed out after {timeout}s"}
    except (KeyboardInterrupt, SystemExit):
        raise
    except Exception as e:
        return {"success": False, "returncode": -1, "stdout": "", "stderr": str(e)}


def _read_file(path: str, offset: int = 1, limit: int = 500) -> Dict[str, Any]:
    """Read a file and return its contents."""
    MAX_SIZE = 10 * 1024 * 1024  # 10MB cap
    try:
        p = Path(path).expanduser().resolve()
        if not p.exists():
            return {"success": False, "error": f"File not found: {path}"}
        if not p.is_file():
            return {"success": False, "error": f"Not a regular file: {path}"}
        size = p.stat().st_size
        if size > MAX_SIZE:
            return {"success": False, "error": f"File too large ({size / 1024 / 1024:.1f}MB > 10MB limit)"}
        with open(p) as f:
            start = max(0, offset - 1)
            lines = list(itertools.islice(f, start, start + limit))
            remaining = sum(1 for _ in f)
            total = start + len(lines) + remaining
        content = "".join(lines)
        return {
            "success": True,
            "content": content,
            "total_lines": total,
            "offset": offset,
            "limit": limit,
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def _write_file(path: str, content: str) -> Dict[str, Any]:
    """Write content to a file. Resolves and validates path."""
    try:
        p = Path(path).expanduser().resolve()
        # Security: prevent path traversal. Reject absolute paths outside ~ or /home/mc411
        home = Path.home().resolve()
        if not (p.is_relative_to(home) or p.is_relative_to(Path("/tmp"))):
            return {"success": False, "error": f"Path outside allowed root: {path}"}
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)
        return {"success": True, "path": str(p)}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _skill_view(skill_name: str) -> Dict[str, Any]:
    """Load a Hermes skill's SKILL.md content."""
    skill_dir = Path("~/.hermes/skills").expanduser()
    skill_path = skill_dir / skill_name / "SKILL.md"
    
    if not skill_path.exists() or not skill_path.is_file():
        return {"success": False, "error": f"Skill not found: {skill_name}", "path": str(skill_path)}
    
    try:
        content = skill_path.read_text()
        if len(content) > 500_000:
            return {"success": False, "error": f"Skill file too large ({len(content)/1024:.0f}KB > 500KB limit)"}
        return {"success": True, "skill_name": skill_name, "content": content}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _web_search(query: str) -> Dict[str, Any]:
    """Search the web using curl (no API key needed)."""
    import urllib.parse
    
    encoded = urllib.parse.quote(query)
    url = f"https://lite.duckduckgo.com/lite/?q={encoded}"
    
    try:
        result = subprocess.run(
            ["curl", "-s", "--max-time", "10", url],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode != 0:
            return {"success": False, "query": query, "error": f"curl failed: {result.stderr[:200]}"}
        output = result.stdout[:1500]
        return {"success": True, "query": query, "results": output}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _git_run(command: str, path: Optional[str] = None) -> Dict[str, Any]:
    """Run a git command."""
    # Strip any leading "git " since we prepend it ourselves
    command = command.strip()
    if command.startswith("git "):
        command = command[4:]
    try:
        result = subprocess.run(
            ["git"] + command.split(),
            capture_output=True,
            text=True,
            timeout=30,
            cwd=path or os.getcwd(),
        )
        return {
            "success": result.returncode == 0,
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    except (KeyboardInterrupt, SystemExit):
        raise
    except Exception as e:
        return {"success": False, "returncode": -1, "stdout": "", "stderr": str(e)}


# ── Tool registry ─────────────────────────────────────────────────────────────

class ToolRegistry:
    """Registry of available local tools."""
    
    def __init__(self):
        self._tools: Dict[str, Dict[str, Any]] = {
            "terminal": {
                "schema": TERMINAL_SCHEMA,
                "execute": _terminal,
            },
            "read_file": {
                "schema": READ_FILE_SCHEMA,
                "execute": _read_file,
            },
            "write_file": {
                "schema": WRITE_FILE_SCHEMA,
                "execute": _write_file,
            },
            "skill_view": {
                "schema": SKILL_VIEW_SCHEMA,
                "execute": _skill_view,
            },
            "web_search": {
                "schema": WEB_SEARCH_SCHEMA,
                "execute": _web_search,
            },
            "git_run": {
                "schema": GIT_RUN_SCHEMA,
                "execute": _git_run,
            },
        }
    
    def list(self) -> List[Dict[str, Any]]:
        """Return all tool schemas."""
        return [t["schema"] for t in self._tools.values()]
    
    def get(self, name: str) -> Optional[Dict[str, Any]]:
        """Return a tool by name, or None if not found."""
        return self._tools.get(name)
    
    def execute(self, name: str, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a tool by name with given kwargs. Returns result dict."""
        tool = self._tools.get(name)
        if not tool:
            return {"success": False, "error": f"Unknown tool: {name}"}
        try:
            return tool["execute"](**kwargs)
        except Exception as e:
            return {"success": False, "error": str(e)}


# Singleton
TOOL_REGISTRY = ToolRegistry()
