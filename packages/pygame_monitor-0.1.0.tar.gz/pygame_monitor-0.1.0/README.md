# Pygame Variable Monitor

A lightweight, real-time debugging overlay for Pygame. This library allows you to track local variables and display them directly on your game window without messy print statements.
You can see your variables at left of your pygame window.

## Features
- **Real-time Tracking**: Watch variables change as your game logic runs.
- **Easy Integration**: Add a single line to your game loop.
- **Automatic Formatting**: Handles strings, integers, and floats automatically.

## Installation

1. Clone this repository to your project folder:
   ```bash
   pip install git+https://github.com/jigeobjeogin-eng/PygameMonitor.git
   
   Manual Option: Simply copy monitor.py into your project directory and ensure you have pygame installed
## Execution

1. Import the library
2. Display and update the variables by this method
    ```bash
   .display_variables(*your pygame.display.setmode()*, globals()) 