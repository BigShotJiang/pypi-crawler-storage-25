
#this is a pygame sample for testing the library


from src import monitor
import pygame

pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Test")



a = 1
b = 2
c = "success"


while True:



    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()


    screen.fill((0, 0, 0))


    monitor.display_variables(screen, globals())


    pygame.display.flip()