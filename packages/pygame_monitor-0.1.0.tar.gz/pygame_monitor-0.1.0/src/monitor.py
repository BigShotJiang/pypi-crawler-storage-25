import pygame

varList = {}
boxes = []


class Box:

    def __init__(self, varNum, text_to_display, box_height, current_font):
        self.y = varNum * box_height
        self.body = pygame.Rect(0, self.y, 250, box_height)

        self.text_surf = current_font.render(text_to_display, True, (255, 255, 255))

    def draw(self, surface):

        self.text_rect = self.text_surf.get_rect(topleft=(self.body.x + 5, self.body.y + 2))

        pygame.draw.rect(surface, (40, 40, 40), self.body)
        pygame.draw.rect(surface, (200, 200, 200), self.body, 1)
        surface.blit(self.text_surf, self.text_rect)


def display_variables(target_surface, local_vars):
    global varList, boxes
    pygame.font.init()


    varList.clear()
    for var, val in local_vars.items():
        if not var.startswith("__") and "mylib" not in var:
            varList[var] = val

    num_vars = len(varList)
    if num_vars == 0:
        return


    screen_height = target_surface.get_height()


    box_height = int(screen_height / num_vars)

    font_size = max(8, min(30, int(box_height * 0.7)))
    dynamic_font = pygame.font.SysFont("Arial", font_size)

    boxes.clear()
    for i, (key, value) in enumerate(varList.items()):
        boxes.append(Box(i, f"{key}: {value}", box_height, dynamic_font))

    for b in boxes:
        b.draw(target_surface)