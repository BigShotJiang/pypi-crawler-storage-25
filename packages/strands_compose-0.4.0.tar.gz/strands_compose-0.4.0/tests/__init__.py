"""strands-compose test suite."""
