"""Public model plotting facade.

The common model diagnostics use the DataFrame/payload API implemented in
``glmhmmt.model_plotting``. Legacy helpers that are not part of the common
notebook surface are kept in ``glmhmmt.model_plotting.legacy`` during the
transition, but common plots no longer prepare data internally.
"""

from __future__ import annotations

from glmhmmt.model_plotting.legacy import *  # noqa: F401,F403
from glmhmmt.model_plotting.legacy import (
    _state_color,
    custom_boxplot,
    norm_ll,
    plot_lapse_rates_boxplot,
    plot_ll,
    plot_model_comparison,
    plot_model_comparison_diffs,
    plot_occupancy,
    plot_occupancy_boxplot,
    plot_tau_sweep,
    plot_trans_mat,
    plot_trans_mat_boxplots,
    plot_transition_weights,
)
from glmhmmt.model_plotting import (
    plot_binary_emission_weights,
    plot_binary_emission_weights_by_subject,
    plot_binary_emission_weights_summary,
    plot_binary_emission_weights_summary_boxplot,
    plot_binary_emission_weights_summary_lineplot,
    plot_change_triggered_posteriors_by_subject,
    plot_change_triggered_posteriors_summary,
    plot_emission_weights,
    plot_emission_weights_by_subject,
    plot_emission_weights_summary,
    plot_emission_weights_summary_boxplot,
    plot_emission_weights_summary_lineplot,
    plot_posterior_probs,
    plot_session_deepdive,
    plot_session_trajectories,
    plot_state_accuracy,
    plot_state_dwell_times,
    plot_state_dwell_times_by_subject,
    plot_state_dwell_times_summary,
    plot_state_occupancy,
    plot_state_occupancy_overall_boxplot,
    plot_state_posterior_count_kde,
    plot_transition_matrix,
    plot_transition_matrix_by_subject,
)

__all__ = [
    "_state_color",
    "custom_boxplot",
    "norm_ll",
    "plot_binary_emission_weights",
    "plot_binary_emission_weights_by_subject",
    "plot_binary_emission_weights_summary",
    "plot_binary_emission_weights_summary_boxplot",
    "plot_binary_emission_weights_summary_lineplot",
    "plot_change_triggered_posteriors_by_subject",
    "plot_change_triggered_posteriors_summary",
    "plot_emission_weights",
    "plot_emission_weights_by_subject",
    "plot_emission_weights_summary",
    "plot_emission_weights_summary_boxplot",
    "plot_emission_weights_summary_lineplot",
    "plot_lapse_rates_boxplot",
    "plot_ll",
    "plot_model_comparison",
    "plot_model_comparison_diffs",
    "plot_occupancy",
    "plot_occupancy_boxplot",
    "plot_posterior_probs",
    "plot_session_deepdive",
    "plot_session_trajectories",
    "plot_state_accuracy",
    "plot_state_dwell_times",
    "plot_state_dwell_times_by_subject",
    "plot_state_dwell_times_summary",
    "plot_state_occupancy",
    "plot_state_occupancy_overall_boxplot",
    "plot_state_posterior_count_kde",
    "plot_tau_sweep",
    "plot_trans_mat",
    "plot_trans_mat_boxplots",
    "plot_transition_matrix",
    "plot_transition_matrix_by_subject",
    "plot_transition_weights",
]
