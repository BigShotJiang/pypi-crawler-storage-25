"""Security utilities for alfard."""
