#!/usr/bin/env python3
"""Test schedule as object vs JSON string."""

import requests
import json

API_KEY = "EWZooLROIS57EVW3BKGu7Pv6LNe4D6m4gkDjukx3"
WORKSPACE_ID = "6586b7e6-683e-4ee6-a6cf-24c19729b5ff"
BASE_URL = "https://api.toothfairylab.link"

headers = {
    "Content-Type": "application/json",
    "x-api-key": API_KEY,
}

print("="*70)
print("SCHEDULE FORMAT TEST")
print("="*70)

# Test 1: Schedule as nested object (what we're doing now)
print("\n" + "-"*70)
print("TEST 1: Schedule as nested object")
print("-"*70)
payload1 = {
    "name": "test_job_1",
    "agentID": "fd476412-f44e-464f-bf8d-e893b570096b",
    "customPromptID": "cb9e59bb-2466-4276-8502-0230ff855a41",
    "timezone": "UTC",
    "isActive": True,
    "schedule": {
        "frequency": "DAILY",
        "interval": 1,
        "dayOfWeek": 0,
        "dayOfMonth": 1,
        "hour": 10,
        "minute": 30
    },
    "workspaceid": WORKSPACE_ID
}
print(f"Payload structure: schedule is {type(payload1['schedule']).__name__}")
r = requests.post(f"{BASE_URL}/scheduled_job/create", headers=headers, json=payload1)
print(f"Status: {r.status_code}")
print(f"Response: {r.text[:200]}")

# Test 2: Schedule as JSON string (wrong)
print("\n" + "-"*70)
print("TEST 2: Schedule as JSON string (probably wrong)")
print("-"*70)
payload2 = {
    "name": "test_job_2",
    "agentID": "fd476412-f44e-464f-bf8d-e893b570096b",
    "customPromptID": "cb9e59bb-2466-4276-8502-0230ff855a41",
    "timezone": "UTC",
    "isActive": True,
    "schedule": json.dumps({
        "frequency": "DAILY",
        "interval": 1,
        "dayOfWeek": 0,
        "dayOfMonth": 1,
        "hour": 10,
        "minute": 30
    }),
    "workspaceid": WORKSPACE_ID
}
print(f"Payload structure: schedule is {type(payload2['schedule']).__name__}")
r = requests.post(f"{BASE_URL}/scheduled_job/create", headers=headers, json=payload2)
print(f"Status: {r.status_code}")
print(f"Response: {r.text[:200]}")

# Test 3: Try using GraphQL-style input
print("\n" + "-"*70)
print("TEST 3: Try raw body with proper GraphQL structure")
print("-"*70)

# Check if it needs a different wrapper
body_str = json.dumps({
    "name": "test_job_3",
    "agentID": "fd476412-f44e-464f-bf8d-e893b570096b",
    "customPromptID": "cb9e59bb-2466-4276-8502-0230ff855a41",
    "timezone": "UTC",
    "isActive": True,
    "schedule": {
        "frequency": "DAILY",
        "interval": 1
    },
    "workspaceid": WORKSPACE_ID
})
print(f"Raw JSON: {body_str[:300]}")
r = requests.post(f"{BASE_URL}/scheduled_job/create", headers=headers, data=body_str)
print(f"Status: {r.status_code}")
print(f"Response: {r.text[:200]}")

print("\n" + "="*70)