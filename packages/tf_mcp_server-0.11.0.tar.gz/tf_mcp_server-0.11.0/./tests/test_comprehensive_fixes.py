#!/usr/bin/env python3
"""Comprehensive test for MCP entity parameter alignment fixes - Minimal version.

Tests all SDK operations with minimal required parameters.
"""

import sys
import os
import json
import time
from datetime import datetime

sys.path.insert(0, "/Users/gabriele_sanguigno/TF_coding/python_sdk/src")

from toothfairyai import ToothFairyClient

API_KEY = "EWZooLROIS57EVW3BKGu7Pv6LNe4D6m4gkDjukx3"
WORKSPACE_ID = "6586b7e6-683e-4ee6-a6cf-24c19729b5ff"

client = ToothFairyClient(
    api_key=API_KEY, 
    workspace_id=WORKSPACE_ID,
    base_url="https://api.toothfairylab.link",
    ai_url="https://ai.toothfairylab.link",
    ai_stream_url="https://ais.toothfairylab.link",
)

TEST_PREFIX = f"test_v073_{int(time.time())}"
created_resources = []

def print_result(name, success=True, data=None, error=None):
    print(f"\n{'='*60}")
    print(f"TEST: {name}")
    print(f"{'='*60}")
    if success:
        print("✅ SUCCESS")
        if data:
            obj_id = getattr(data, 'id', None) or (data.get('id') if isinstance(data, dict) else None)
            obj_name = getattr(data, 'name', None) or getattr(data, 'label', None) or (data.get('name') if isinstance(data, dict) else None)
            print(f"ID: {obj_id}")
            print(f"Name: {obj_name}")
    else:
        print("❌ FAILED")
        print(f"Error: {error}")
    return success, data


def cleanup():
    print(f"\n{'='*60}")
    print("CLEANUP: Deleting created resources...")
    print(f"{'='*60}")
    for resource_type, resource_id in reversed(created_resources):
        try:
            if resource_type == "agent_function":
                client.agent_functions.delete(resource_id)
            elif resource_type == "scheduled_job":
                client.scheduled_jobs.delete(resource_id)
            elif resource_type == "document":
                client.documents.delete(resource_id)
            elif resource_type == "entity":
                client.entities.delete(resource_id)
            elif resource_type == "folder":
                client.folders.delete(resource_id)
            elif resource_type == "chat":
                client.chat.delete(resource_id)
            elif resource_type == "prompt":
                client.prompts.delete(resource_id)
            elif resource_type == "member":
                client.members.delete(resource_id)
            elif resource_type == "connection":
                client.connections.delete(resource_id)
            elif resource_type == "hook":
                client.hooks.delete(resource_id)
            print(f"  ✓ Deleted {resource_type}: {resource_id}")
        except Exception as e:
            print(f"  ✗ Failed to delete {resource_type}: {e}")


def test_agent_function():
    """Test agent function with minimal required params."""
    try:
        result = client.agent_functions.create(
            name=f"{TEST_PREFIX}_function",
            description="Test function for parameter validation",
            url="https://api.example.com/test",
            request_type="POST",
            authorisation_type="none",
        )
        success, data = print_result("Agent Function (minimal params)", True, result)
        if success and result:
            func_id = getattr(result, 'id', None)
            if func_id:
                created_resources.append(("agent_function", func_id))
            return func_id
    except Exception as e:
        print_result("Agent Function (minimal params)", False, error=str(e))
    return None


def test_scheduled_job():
    """Test scheduled job with required params."""
    try:
        agents = client.agents.list(limit=1)
        prompts = client.prompts.list(limit=1)
        
        agent_id = None
        prompt_id = None
        
        if agents.items:
            agent_id = agents.items[0].id
        if prompts.items:
            prompt_id = prompts.items[0].id
        
        if not agent_id or not prompt_id:
            print(f"\n{'='*60}")
            print(f"TEST: Scheduled Job")
            print(f"{'='*60}")
            print("⚠️ SKIPPED - No agent or prompt found")
            return None
        
        result = client.scheduled_jobs.create(
            name=f"{TEST_PREFIX}_scheduled_job",
            agent_id=agent_id,
            custom_prompt_id=prompt_id,
        )
        success, data = print_result("Scheduled Job (required params)", True, result)
        if success and result:
            job_id = getattr(result, 'id', None)
            if job_id:
                created_resources.append(("scheduled_job", job_id))
            return job_id
    except Exception as e:
        print_result("Scheduled Job (required params)", False, error=str(e))
    return None


def test_document():
    """Test document with required user_id."""
    try:
        result = client.documents.create(
            user_id="test_user",
            title=f"{TEST_PREFIX}_document",
        )
        success, data = print_result("Document (user_id required)", True, result)
        if success and result:
            doc_id = getattr(result, 'id', None)
            if doc_id:
                created_resources.append(("document", doc_id))
            return doc_id
    except Exception as e:
        print_result("Document (user_id required)", False, error=str(e))
    return None


def test_entity():
    """Test entity with all params."""
    try:
        result = client.entities.create(
            label=f"{TEST_PREFIX}_entity",
            entity_type="topic",
            description="Test entity",
            emoji="🧪",
            background_color="#FF5733",
        )
        success, data = print_result("Entity (with background_color)", True, result)
        if success and result:
            entity_id = getattr(result, 'id', None)
            if entity_id:
                created_resources.append(("entity", entity_id))
            return entity_id
    except Exception as e:
        print_result("Entity (with background_color)", False, error=str(e))
    return None


def test_folder():
    """Test folder with all params."""
    try:
        result = client.folders.create(
            name=f"{TEST_PREFIX}_folder",
            description="Test folder",
            emoji="📁",
            status="active",
        )
        success, data = print_result("Folder (name, description, emoji)", True, result)
        if success and result:
            folder_id = getattr(result, 'id', None)
            if folder_id:
                created_resources.append(("folder", folder_id))
            return folder_id
    except Exception as e:
        print_result("Folder (name, description, emoji)", False, error=str(e))
    return None


def test_chat():
    """Test chat with minimal params."""
    try:
        result = client.chat.create(
            name=f"{TEST_PREFIX}_chat",
        )
        success, data = print_result("Chat (minimal params)", True, result)
        if success and result:
            chat_id = getattr(result, 'id', None)
            if chat_id:
                created_resources.append(("chat", chat_id))
            return chat_id
    except Exception as e:
        print_result("Chat (minimal params)", False, error=str(e))
    return None


def test_prompt():
    """Test prompt with minimal params (128+ chars)."""
    try:
        long_prompt = "You are a helpful assistant. " * 20
        result = client.prompts.create(
            label=f"{TEST_PREFIX}_prompt",
            interpolation_string=long_prompt,
        )
        success, data = print_result("Prompt (minimal params)", True, result)
        if success and result:
            prompt_id = getattr(result, 'id', None)
            if prompt_id:
                created_resources.append(("prompt", prompt_id))
            return prompt_id
    except Exception as e:
        print_result("Prompt (minimal params)", False, error=str(e))
    return None


def test_member():
    """Test member creation."""
    try:
        result = client.members.create(
            user_id=f"{TEST_PREFIX}_user",
        )
        success, data = print_result("Member (minimal params)", True, result)
        if success and result:
            member_id = getattr(result, 'id', None)
            if member_id:
                created_resources.append(("member", member_id))
            return member_id
    except Exception as e:
        print_result("Member (minimal params)", False, error=str(e))
    return None


def test_connection():
    """Test connection creation."""
    try:
        result = client.connections.create(
            name=f"{TEST_PREFIX}_connection",
            type="openai",
        )
        success, data = print_result("Connection (minimal params)", True, result)
        if success and result:
            conn_id = getattr(result, 'id', None)
            if conn_id:
                created_resources.append(("connection", conn_id))
            return conn_id
    except Exception as e:
        print_result("Connection (minimal params)", False, error=str(e))
    return None


def test_hook():
    """Test hook with minimal params."""
    try:
        result = client.hooks.create(
            name=f"{TEST_PREFIX}_hook",
        )
        success, data = print_result("Hook (minimal params)", True, result)
        if success and result:
            hook_id = getattr(result, 'id', None)
            if hook_id:
                created_resources.append(("hook", hook_id))
            return hook_id
    except Exception as e:
        print_result("Hook (minimal params)", False, error=str(e))
    return None


def main():
    print(f"\n{'#'*70}")
    print("# COMPREHENSIVE SDK PARAMETER ALIGNMENT TEST")
    print(f"# Version: 0.7.3")
    print(f"# Timestamp: {datetime.now().isoformat()}")
    print(f"# Environment: DEV (toothfairylab.link)")
    print(f"{'#'*70}\n")
    
    print(f"Test prefix: {TEST_PREFIX}")
    print(f"Workspace: {WORKSPACE_ID}")
    print(f"SDK Client: {client.config.base_url}")
    
    results = {}
    
    print("\n" + "="*70)
    print("RUNNING TESTS...")
    print("="*70)
    
    try:
        results["agent_function"] = test_agent_function()
        results["scheduled_job"] = test_scheduled_job()
        results["document"] = test_document()
        results["entity"] = test_entity()
        results["folder"] = test_folder()
        results["chat"] = test_chat()
        results["prompt"] = test_prompt()
        results["member"] = test_member()
        results["connection"] = test_connection()
        results["hook"] = test_hook()
        
    except Exception as e:
        print(f"\n❌ TEST RUNNER ERROR: {e}")
        import traceback
        traceback.print_exc()
    finally:
        cleanup()
    
    print(f"\n{'#'*70}")
    print("# TEST SUMMARY")
    print(f"{'#'*70}")
    
    passed = sum(1 for v in results.values() if v is not None)
    total = len(results)
    failed = sum(1 for v in results.values() if v is None)
    
    print(f"\n✅ Passed: {passed}/{total}")
    print(f"❌ Failed: {failed}/{total}")
    
    for name, resource_id in results.items():
        status = "✅ CREATED" if resource_id else "❌ FAILED"
        print(f"  {status}: {name}" + (f" → {resource_id}" if resource_id else ""))
    
    print(f"\n{'#'*70}")
    if passed == total:
        print("# ✅ ALL TESTS PASSED - Parameters correctly aligned!")
    else:
        print(f"# ⚠️  {passed}/{total} tests passed - Server errors may be backend issues")
    print(f"{'#'*70}")
    
    return passed, total


if __name__ == "__main__":
    passed, total = main()
    sys.exit(0 if passed == total else 1)