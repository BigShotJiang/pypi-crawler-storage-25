#!/usr/bin/env python3
"""Validate credentials and test simple operations."""

import sys
sys.path.insert(0, "/Users/gabriele_sanguigno/TF_coding/python_sdk/src")

from toothfairyai import ToothFairyClient

API_KEY = "EWZooLROIS57EVW3BKGu7Pv6LNe4D6m4gkDjukx3"
WORKSPACE_ID = "6586b7e6-683e-4ee6-a6cf-24c19729b5ff"

print("="*70)
print("CREDENTIAL VALIDATION TEST")
print("="*70)
print(f"API Key: {API_KEY[:20]}...")
print(f"Workspace: {WORKSPACE_ID}")

try:
    client = ToothFairyClient(api_key=API_KEY, workspace_id=WORKSPACE_ID)
    print(f"\n✅ Client initialized successfully")
    
    print("\n" + "-"*70)
    print("Testing simple list operations...")
    print("-"*70)
    
    try:
        agents = client.agents.list(limit=1)
        print(f"✅ agents.list() - Found {len(agents.items)} agent(s)")
        if agents.items:
            print(f"   Sample agent: {agents.items[0].id}")
    except Exception as e:
        print(f"❌ agents.list() failed: {e}")
    
    try:
        prompts = client.prompts.list(limit=1)
        print(f"✅ prompts.list() - Found {len(prompts.items)} prompt(s)")
        if prompts.items:
            print(f"   Sample prompt: {prompts.items[0].id}")
    except Exception as e:
        print(f"❌ prompts.list() failed: {e}")
    
    try:
        folders = client.folders.list(limit=5)
        print(f"✅ folders.list() - Found {len(folders.items)} folder(s)")
    except Exception as e:
        print(f"❌ folders.list() failed: {e}")
    
except Exception as e:
    print(f"❌ Client initialization failed: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "="*70)