#!/usr/bin/env python3
"""Test scheduled job with new default frequency."""

import requests
import json

API_KEY = "EWZooLROIS57EVW3BKGu7Pv6LNe4D6m4gkDjukx3"
WORKSPACE_ID = "6586b7e6-683e-4ee6-a6cf-24c19729b5ff"
BASE_URL = "https://api.toothfairylab.link"

headers = {
    "Content-Type": "application/json",
    "x-api-key": API_KEY,
}

print("="*70)
print("SCHEDULED JOB TEST")
print("="*70)

# Test with frequency included
payload = {
    "name": "test_job",
    "agentID": "fd476412-f44e-464f-bf8d-e893b570096b",
    "customPromptID": "cb9e59bb-2466-4276-8502-0230ff855a41",
    "timezone": "UTC",
    "isActive": True,
    "schedule": {
        "frequency": "DAILY",
        "hour": 9,
        "minute": 0
    },
    "workspaceid": WORKSPACE_ID
}

print(f"\nPayload: {json.dumps(payload, indent=2)}")
r = requests.post(f"{BASE_URL}/scheduled_job/create", headers=headers, json=payload)
print(f"Status: {r.status_code}")
print(f"Response: {r.text}")