#!/usr/bin/env python3
"""Debug test to see what SDK sends to API."""

import sys
import json

sys.path.insert(0, "/Users/gabriele_sanguigno/TF_coding/python_sdk/src")

from toothfairyai import ToothFairyClient
from toothfairyai.client import ToothFairyClient as Client

API_KEY = "EWZooLROIS57EVW3BKGu7Pv6LNe4D6m4gkDjukx3"
WORKSPACE_ID = "6586b7e6-683e-4ee6-a6cf-24c19729b5ff"

# Monkey-patch the request method to log what's being sent
original_request = ToothFairyClient.request

def logged_request(self, method, endpoint, data=None, params=None, **kwargs):
    print(f"\n{'='*60}")
    print(f"SDK REQUEST: {method} {endpoint}")
    print(f"{'='*60}")
    print(f"Data payload: {json.dumps(data, indent=2, default=str)}")
    print(f"Params: {params}")
    try:
        return original_request(self, method, endpoint, data, params, **kwargs)
    except Exception as e:
        print(f"API ERROR: {getattr(e, 'response', 'No response')}")
        print(f"Status: {getattr(e, 'status_code', 'N/A')}")
        if hasattr(e, 'response') and e.response:
            import requests
            if isinstance(e.response, dict):
                print(f"Response body: {json.dumps(e.response, indent=2)}")
            elif hasattr(e.response, 'text'):
                print(f"Response body: {e.response.text}")
        raise

ToothFairyClient.request = logged_request

client = ToothFairyClient(
    api_key=API_KEY, 
    workspace_id=WORKSPACE_ID,
    base_url="https://api.toothfairylab.link",
    ai_url="https://ai.toothfairylab.link",
    ai_stream_url="https://ais.toothfairylab.link",
)

print("#"*70)
print("DEBUG: What does SDK send for each failing operation?")
print("#"*70)

# Test chat
print("\n" + "-"*70)
print("CHAT CREATE")
print("-"*70)
try:
    result = client.chat.create(name="test_chat")
    print(f"SUCCESS: {result}")
except Exception as e:
    print(f"FAILED: {e}")

# Test hook
print("\n" + "-"*70)
print("HOOK CREATE")
print("-"*70)
try:
    result = client.hooks.create(name="test_hook", description="Test hook")
    print(f"SUCCESS: {result}")
except Exception as e:
    print(f"FAILED: {e}")

# Test scheduled job
print("\n" + "-"*70)
print("SCHEDULED JOB CREATE")
print("-"*70)
try:
    agents = client.agents.list(limit=1)
    prompts = client.prompts.list(limit=1)
    if agents.items and prompts.items:
        result = client.scheduled_jobs.create(
            name="test_job",
            agent_id=agents.items[0].id,
            custom_prompt_id=prompts.items[0].id,
        )
        print(f"SUCCESS: {result}")
    else:
        print("SKIPPED: No agents or prompts")
except Exception as e:
    print(f"FAILED: {e}")

print("\n" + "#"*70)