#!/usr/bin/env python3
"""Test with exact SDK payloads."""

import requests
import json

API_KEY = "EWZooLROIS57EVW3BKGu7Pv6LNe4D6m4gkDjukx3"
WORKSPACE_ID = "6586b7e6-683e-4ee6-a6cf-24c19729b5ff"
BASE_URL = "https://api.toothfairylab.link"

headers = {
    "Content-Type": "application/json",
    "x-api-key": API_KEY,
}

print("="*70)
print("TEST EXACT SDK PAYLOADS")
print("="*70)

# Test 1: Chat with exact SDK payload
print("\n" + "-"*70)
print("CHAT: Exact SDK payload")
print("-"*70)
chat_payload = {
    "name": "test_chat",
    "customerId": "",
    "customerInfo": {},
    "primaryRole": "user",
    "externalParticipantId": "",
    "workspaceid": WORKSPACE_ID
}
print(f"Payload: {json.dumps(chat_payload, indent=2)}")
r = requests.post(f"{BASE_URL}/chat/create", headers=headers, json=chat_payload)
print(f"Status: {r.status_code}")
print(f"Response: {r.text}")

# Test 2: Scheduled Job with exact SDK payload  
print("\n" + "-"*70)
print("SCHEDULED JOB: Exact SDK payload")
print("-"*70)
sj_payload = {
    "name": "test_job",
    "agentID": "fd476412-f44e-464f-bf8d-e893b570096b",
    "customPromptID": "cb9e59bb-2466-4276-8502-0230ff855a41",
    "timezone": "UTC",
    "isActive": True,
    "workspaceid": WORKSPACE_ID
}
print(f"Payload: {json.dumps(sj_payload, indent=2)}")
r = requests.post(f"{BASE_URL}/scheduled_job/create", headers=headers, json=sj_payload)
print(f"Status: {r.status_code}")
print(f"Response: {r.text}")

# Test 3: Try different variations to find what works
print("\n" + "-"*70)
print("CHAT: Try without empty string fields")
print("-"*70)
chat_payload2 = {
    "name": "test_chat",
    "primaryRole": "user",
    "workspaceid": WORKSPACE_ID
}
print(f"Payload: {json.dumps(chat_payload2, indent=2)}")
r = requests.post(f"{BASE_URL}/chat/create", headers=headers, json=chat_payload2)
print(f"Status: {r.status_code}")
print(f"Response: {r.text}")

print("\n" + "="*70)