#!/usr/bin/env python3
"""Test different schedule formats."""

import requests
import json

API_KEY = "EWZooLROIS57EVW3BKGu7Pv6LNe4D6m4gkDjukx3"
WORKSPACE_ID = "6586b7e6-683e-4ee6-a6cf-24c19729b5ff"
BASE_URL = "https://api.toothfairylab.link"

headers = {
    "Content-Type": "application/json",
    "x-api-key": API_KEY,
}

print("="*70)
print("SCHEDULE FORMAT TEST")
print("="*70)

test_cases = [
    # Test 1: Basic schedule with frequency only
    {
        "name": "test_job_1",
        "agentID": "fd476412-f44e-464f-bf8d-e893b570096b",
        "customPromptID": "cb9e59bb-2466-4276-8502-0230ff855a41",
        "timezone": "UTC",
        "isActive": True,
        "schedule": {"frequency": "DAILY"},
        "workspaceid": WORKSPACE_ID
    },
    # Test 2: With hour and minute
    {
        "name": "test_job_2",
        "agentID": "fd476412-f44e-464f-bf8d-e893b570096b",
        "customPromptID": "cb9e59bb-2466-4276-8502-0230ff855a41",
        "timezone": "UTC",
        "isActive": True,
        "schedule": {"frequency": "DAILY", "hour": 9, "minute": 30},
        "workspaceid": WORKSPACE_ID
    },
    # Test 3: HOURLY with interval
    {
        "name": "test_job_3",
        "agentID": "fd476412-f44e-464f-bf8d-e893b570096b",
        "customPromptID": "cb9e59bb-2466-4276-8502-0230ff855a41",
        "timezone": "UTC",
        "isActive": True,
        "schedule": {"frequency": "HOURLY"},
        "workspaceid": WORKSPACE_ID
    },
]

for i, payload in enumerate(test_cases, 1):
    print(f"\n{'-'*70}")
    print(f"TEST {i}: frequency={payload['schedule']['frequency']}")
    print(f"{'-'*70}")
    print(f"Schedule: {json.dumps(payload['schedule'])}")
    r = requests.post(f"{BASE_URL}/scheduled_job/create", headers=headers, json=payload)
    print(f"Status: {r.status_code}")
    if r.status_code == 200:
        print(f"✅ SUCCESS!")
        print(f"Response: {r.text[:300]}...")
    else:
        print(f"❌ FAILED")
        print(f"Response: {r.text}")

print("\n" + "="*70)