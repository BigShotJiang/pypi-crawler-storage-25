#!/usr/bin/env python3
"""Raw API request to see actual 500 error responses."""

import requests
import json

API_KEY = "EWZooLROIS57EVW3BKGu7Pv6LNe4D6m4gkDjukx3"
WORKSPACE_ID = "6586b7e6-683e-4ee6-a6cf-24c19729b5ff"
BASE_URL = "https://api.toothfairylab.link"

headers = {
    "Content-Type": "application/json",
    "x-api-key": API_KEY,
}

print("="*70)
print("RAW API ERROR CAPTURE")
print("="*70)

endpoints = [
    ("POST", "/scheduled_job/create", {"name": "test_job", "agent_id": "fd476412-f44e-464f-bf8d-e893b570096b", "custom_prompt_id": "cb9e59bb-2466-4276-8502-0230ff855a41", "workspaceid": WORKSPACE_ID}),
    ("POST", "/chat/create", {"name": "test_chat", "workspaceid": WORKSPACE_ID}),
    ("POST", "/member/create", {"user_id": "test_user", "workspaceid": WORKSPACE_ID}),
    ("POST", "/connection/create", {"name": "test_conn", "type": "openai", "workspaceid": WORKSPACE_ID}),
    ("POST", "/hook/create", {"name": "test_hook", "workspaceid": WORKSPACE_ID}),
]

for method, endpoint, data in endpoints:
    print(f"\n{'-'*70}")
    print(f"{method} {endpoint}")
    print(f"Payload: {json.dumps(data, indent=2)}")
    print(f"{'-'*70}")
    
    try:
        response = requests.post(f"{BASE_URL}{endpoint}", headers=headers, json=data, timeout=30)
        print(f"Status: {response.status_code}")
        print(f"Headers: {dict(response.headers)}")
        print(f"Body: {response.text[:1000] if response.text else 'Empty'}")
    except Exception as e:
        print(f"Exception: {e}")

print("\n" + "="*70)