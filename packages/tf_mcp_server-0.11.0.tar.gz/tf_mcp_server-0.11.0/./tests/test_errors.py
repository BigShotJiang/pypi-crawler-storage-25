#!/usr/bin/env python3
"""Detailed error capture for each failing test."""

import sys
sys.path.insert(0, "/Users/gabriele_sanguigno/TF_coding/python_sdk/src")

from toothfairyai import ToothFairyClient

API_KEY = "EWZooLROIS57EVW3BKGu7Pv6LNe4D6m4gkDjukx3"
WORKSPACE_ID = "6586b7e6-683e-4ee6-a6cf-24c19729b5ff"

client = ToothFairyClient(
    api_key=API_KEY, 
    workspace_id=WORKSPACE_ID,
    base_url="https://api.toothfairylab.link",
    ai_url="https://ai.toothfairylab.link",
    ai_stream_url="https://ais.toothfairylab.link",
)

TEST_PREFIX = "test_errors"

print("="*70)
print("DETAILED ERROR CAPTURE")
print("="*70)

# Test scheduled_job
print("\n" + "-"*70)
print("SCHEDULED JOB")
print("-"*70)
try:
    agents = client.agents.list(limit=1)
    prompts = client.prompts.list(limit=1)
    print(f"Agents found: {len(agents.items)}")
    print(f"Prompts found: {len(prompts.items)}")
    if agents.items:
        print(f"Agent ID: {agents.items[0].id}")
    if prompts.items:
        print(f"Prompt ID: {prompts.items[0].id}")
    
    if agents.items and prompts.items:
        result = client.scheduled_jobs.create(
            name=f"{TEST_PREFIX}_job",
            agent_id=agents.items[0].id,
            custom_prompt_id=prompts.items[0].id,
        )
        print(f"SUCCESS: {result}")
except Exception as e:
    print(f"Exception type: {type(e).__name__}")
    print(f"Exception message: {e}")
    print(f"Status code: {getattr(e, 'status_code', 'N/A')}")
    print(f"Response data: {getattr(e, 'response', 'N/A')}")

# Test chat
print("\n" + "-"*70)
print("CHAT")
print("-"*70)
try:
    result = client.chat.create(name=f"{TEST_PREFIX}_chat")
    print(f"SUCCESS: {result}")
except Exception as e:
    print(f"Exception type: {type(e).__name__}")
    print(f"Exception message: {e}")
    print(f"Status code: {getattr(e, 'status_code', 'N/A')}")
    print(f"Response data: {getattr(e, 'response', 'N/A')}")

# Test member
print("\n" + "-"*70)
print("MEMBER")
print("-"*70)
try:
    result = client.members.create(user_id=f"{TEST_PREFIX}_user")
    print(f"SUCCESS: {result}")
except Exception as e:
    print(f"Exception type: {type(e).__name__}")
    print(f"Exception message: {e}")
    print(f"Status code: {getattr(e, 'status_code', 'N/A')}")
    print(f"Response data: {getattr(e, 'response', 'N/A')}")

# Test connection
print("\n" + "-"*70)
print("CONNECTION")
print("-"*70)
try:
    result = client.connections.create(name=f"{TEST_PREFIX}_conn", type="openai")
    print(f"SUCCESS: {result}")
except Exception as e:
    print(f"Exception type: {type(e).__name__}")
    print(f"Exception message: {e}")
    print(f"Status code: {getattr(e, 'status_code', 'N/A')}")
    print(f"Response data: {getattr(e, 'response', 'N/A')}")

# Test hook
print("\n" + "-"*70)
print("HOOK")
print("-"*70)
try:
    result = client.hooks.create(name=f"{TEST_PREFIX}_hook")
    print(f"SUCCESS: {result}")
except Exception as e:
    print(f"Exception type: {type(e).__name__}")
    print(f"Exception message: {e}")
    print(f"Status code: {getattr(e, 'status_code', 'N/A')}")
    print(f"Response data: {getattr(e, 'response', 'N/A')}")

print("\n" + "="*70)