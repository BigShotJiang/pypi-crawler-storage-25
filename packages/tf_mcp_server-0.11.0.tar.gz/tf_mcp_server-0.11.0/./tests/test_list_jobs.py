#!/usr/bin/env python3
"""Check existing scheduled jobs to see the correct format."""

import sys
sys.path.insert(0, "/Users/gabriele_sanguigno/TF_coding/python_sdk/src")

from toothfairyai import ToothFairyClient

API_KEY = "EWZooLROIS57EVW3BKGu7Pv6LNe4D6m4gkDjukx3"
WORKSPACE_ID = "6586b7e6-683e-4ee6-a6cf-24c19729b5ff"

client = ToothFairyClient(
    api_key=API_KEY, 
    workspace_id=WORKSPACE_ID,
    base_url="https://api.toothfairylab.link",
    ai_url="https://ai.toothfairylab.link",
    ai_stream_url="https://ais.toothfairylab.link",
)

print("="*70)
print("LIST EXISTING SCHEDULED JOBS")
print("="*70)

try:
    jobs = client.scheduled_jobs.list(limit=5)
    print(f"Found {len(jobs.items)} scheduled jobs")
    
    for job in jobs.items:
        print(f"\n{'-'*70}")
        print(f"Job ID: {job.id}")
        print(f"Name: {job.name}")
        print(f"Agent ID: {job.agent_id}")
        print(f"Schedule: {job.schedule}")
        print(f"Is Active: {job.is_active}")
        print(f"Status: {job.status}")
        
except Exception as e:
    print(f"Error: {e}")

print("\n" + "="*70)