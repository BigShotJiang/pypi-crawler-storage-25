"""Test structured output functionality directly via SDK."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from toothfairyai import ToothFairyClient

DEV_API_KEY = "EWZooLROIS57EVW3BKGu7Pv6LNe4D6m4gkDjukx3"
DEV_WORKSPACE_ID = "6586b7e6-683e-4ee6-a6cf-24c19729b5ff"
DEV_BASE_URL = "https://api.toothfairylab.link"


def test_structured_output_retriever():
    """Test creating a retriever agent with structured output."""
    print("\n" + "=" * 60)
    print("TEST: Create Agent with Structured Output (Retriever Mode)")
    print("=" * 60)
    
    client = ToothFairyClient(api_key=DEV_API_KEY, workspace_id=DEV_WORKSPACE_ID, base_url=DEV_BASE_URL)
    
    json_structure = {
        "type": "object",
        "properties": {
            "answer": {"type": "string"},
            "confidence": {"type": "number"},
            "sources": {"type": "array", "items": {"type": "string"}}
        },
        "required": ["answer", "confidence"]
    }
    
    agent = client.agents.create(
        label="Test Structured Output Retriever",
        mode="retriever",
        interpolation_string="You are a helpful assistant that answers questions based on provided documents. Return structured JSON output.",
        goals="Answer questions with structured JSON responses including answer, confidence score, and sources.",
        temperature=0.3,
        max_tokens=4096,
        max_history=10,
        top_k=4,
        doc_top_k=3,
        description="Test agent for structured output",
        enable_json_output=True,
        json_output_structure=json_structure,
    )
    
    print(f"\nAgent created with ID: {agent.id}")
    print(f"enable_json_output: {agent.enable_json_output}")
    print(f"json_output_structure: {agent.json_output_structure}")
    
    client.agents.delete(agent.id)
    print(f"\nAgent deleted: {agent.id}")
    
    return True


def test_structured_output_chatter():
    """Test creating a chatter agent with structured output."""
    print("\n" + "=" * 60)
    print("TEST: Create Agent with Structured Output (Chatter Mode)")
    print("=" * 60)
    
    client = ToothFairyClient(api_key=DEV_API_KEY, workspace_id=DEV_WORKSPACE_ID, base_url=DEV_BASE_URL)
    
    json_structure = {
        "type": "object",
        "properties": {
            "response": {"type": "string"},
            "sentiment": {"type": "string", "enum": ["positive", "neutral", "negative"]},
            "topics": {"type": "array", "items": {"type": "string"}}
        },
        "required": ["response", "sentiment"]
    }
    
    agent = client.agents.create(
        label="Test Structured Output Chatter",
        mode="chatter",
        interpolation_string="You are a conversational assistant. Respond in structured JSON format.",
        goals="Provide structured responses with sentiment analysis.",
        temperature=0.3,
        max_tokens=4096,
        max_history=10,
        top_k=4,
        doc_top_k=3,
        description="Test chatter agent for structured output",
        enable_json_output=True,
        json_output_structure=json_structure,
    )
    
    print(f"\nAgent created with ID: {agent.id}")
    print(f"enable_json_output: {agent.enable_json_output}")
    print(f"json_output_structure: {agent.json_output_structure}")
    
    client.agents.delete(agent.id)
    print(f"\nAgent deleted: {agent.id}")
    
    return True


def test_agent_without_structured_output():
    """Test creating an agent without structured output."""
    print("\n" + "=" * 60)
    print("TEST: Create Agent without Structured Output")
    print("=" * 60)
    
    client = ToothFairyClient(api_key=DEV_API_KEY, workspace_id=DEV_WORKSPACE_ID, base_url=DEV_BASE_URL)
    
    agent = client.agents.create(
        label="Test Regular Agent",
        mode="chatter",
        interpolation_string="You are a helpful assistant.",
        goals="Help users with questions.",
        temperature=0.3,
        max_tokens=4096,
        max_history=10,
        top_k=4,
        doc_top_k=3,
        description="Test agent without structured output",
    )
    
    print(f"\nAgent created with ID: {agent.id}")
    print(f"enable_json_output: {agent.enable_json_output}")
    print(f"json_output_structure: {agent.json_output_structure}")
    
    client.agents.delete(agent.id)
    print(f"\nAgent deleted: {agent.id}")
    
    return True


def main():
    """Run all tests."""
    print("\n" + "=" * 60)
    print("TESTING STRUCTURED OUTPUT VIA SDK")
    print("=" * 60)
    
    results = []
    
    try:
        results.append(("Regular Agent", test_agent_without_structured_output()))
    except Exception as e:
        print(f"FAILED: {e}")
        results.append(("Regular Agent", False))
    
    try:
        results.append(("Structured Output Retriever", test_structured_output_retriever()))
    except Exception as e:
        print(f"FAILED: {e}")
        results.append(("Structured Output Retriever", False))
    
    try:
        results.append(("Structured Output Chatter", test_structured_output_chatter()))
    except Exception as e:
        print(f"FAILED: {e}")
        results.append(("Structured Output Chatter", False))
    
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    
    for name, passed in results:
        status = "PASS" if passed else "FAIL"
        print(f"  {name}: {status}")
    
    all_passed = all(r[1] for r in results)
    print(f"\nOverall: {'ALL TESTS PASSED' if all_passed else 'SOME TESTS FAILED'}")
    
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())