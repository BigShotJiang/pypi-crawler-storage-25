# Changelog

All notable changes to the ToothFairyAI MCP Server will be documented in this file.

## [0.7.5] - 2026-04-12

### Added
- **New Skills**:
  - `create_member.py`: Guidance for member creation with proper field mappings
  - `create_connection.py`: Guidance for connection/hosting creation with type-specific requirements
- **Skill Updates**:
  - `create_scheduled_job.py`: Updated with correct frequency values, auto-generated fields documentation
    - Added `auto_generated_fields` section documenting backend defaults
    - Added `graphql_requirements` section for required AWSDateTime fields
    - Fixed frequency options: MINUTES, HOURLY, DAILY, WEEKLY, MONTHLY, YEARLY, CUSTOM

### Fixed
- **Backend Patches** (handler.py):
  - Added `_version: None` filter to prevent GraphQL errors
  - Added auto-generation of required fields for scheduled_job:
    - `startDate`: Current timestamp
    - `nextRunAt`: 1 hour from now
    - `status`: "PENDING"
  - Added member create operation with proper input wrapping
- **SDK Updates** (v0.6.1):
  - Fixed member manager to match API schema (UserWorkspaceType)
  - Added `status` parameter to scheduled_job create

### Test Results
- 8/10 tests passing (connection, hook, prompt, chat, folder, entity, document, agent_function)
- 2/10 tests pending backend deployment fixes (scheduled_job, member)

## [0.7.3] - 2026-03-26

### Added
- **Comprehensive Entity Parameter Alignment**: Fixed all MCP tools to match SDK manager parameters
  - **Agent Functions**: Added 40+ missing parameters including:
    - Function type flags: `is_mcp_server`, `is_callback_fn`, `is_database_script`, `is_html_fn`, `is_chat_fn`, `is_hand_off_fn`, `is_code_template`, `is_agent_skill`
    - Execution params: `code_execution_environment_id`, `custom_execution_code`, `model`, `scope`, `json_path_extractor`
    - Hand-off params: `hand_off_agent`, `hand_off_to_original_agent_on_completion`, `hand_off_to_original_agent_on_failure`, `hand_off_agent_on_completion`, `hand_off_agent_on_failure`
    - Chat params: `chat_script`, `chat_action`
    - HTML params: `html_url`, `html_script`, `is_html_redirect_fn`, `html_form_on_successful_submit_message`, `html_form_on_failed_submit_message`
    - Database params: `db_schema_metadata`, `pre_execution_script`, `post_execution_script`, `db_script`, `db_connection_id`, `pre_execution_fn_id`, `pre_execution_mapping`
    - GraphQL params: `graphql_query`, `graphql_mutation`, `graphql_operation_name`
    - Other params: `oauth_connection_id`, `handed_off_to_human_on_call`, `users_to_hand_off_to`, `is_global`, `depends_on_before_execution`, `depends_on_after_execution`, `params_as_path`
  - **Scheduled Jobs**: Added required `custom_prompt_id` parameter and 20+ optional params:
    - `timezone`, `description`, `forced_prompt`, `frequency`, `interval`, `cron_expression`
    - `day_of_week`, `day_of_month`, `hour`, `minute`, `is_active`
    - `start_date`, `end_date`, `execution_config`, `notification_config`, `retry_config`, `metadata`
  - **Documents**: Added missing `user_id` (required), `external_path`, `source`, `status`, `scope`
  - **Entities**: Changed `parent_id` to `parent_entity`, added `background_color`
  - **Folders**: Changed `label` to `name`, added `description`, `emoji`, `status`, `parent`
  - **Chat**: Aligned with SDK params: `name`, `customer_id`, `customer_info`, `primary_role`, `external_participant_id`, `channel_settings`
  - **Prompts**: Added `prompt_type`, `scope`, `style`, `domain`, `prompt_placeholder`, `available_to_agents`
  - **Hooks**: Added all explicit params: `description`, `function_name`, `custom_execution_instructions`, `custom_execution_secrets`, `static_docs`, `available_libraries`, `allow_external_api`, `hardcoded_script`, `is_template`

### New Tools
- **create_toothfairy_member**: Add members to workspace with `user_id`, `role`, `status`
- **create_toothfairy_connection**: Create AI model connections with `name`, `type`, `endpoint`, `model_name`, `base_model`, `custom_model`, `api_version`, `token_secret`, `description`

### Changed
- Updated `all_tools.py` with complete parameter sets for all entity creation functions
- Updated `mcp_tools.py` to register new tools and pass all parameters correctly

## [0.7.2] - 2026-03-26

### Added
- **Structured Output Support**: Added `enable_json_output` and `json_output_structure` parameters to `create_toothfairy_agent` tool
  - Allows agents to return structured JSON responses instead of natural language
  - Works with both `chatter` and `retriever` agent modes
  - Updated `skills/create_agent.py` with structured output examples
  - Updated `TOOLS.md` documentation with structured output section

### Changed
- Updated SDK dependency to `toothfairyai>=0.6.0` for structured output support
- Updated `all_tools.py` `create_agent()` function to pass structured output parameters to SDK

## [0.7.1] - Previous Release

### Features
- Comprehensive MCP server for ToothFairyAI SDK operations
- Skills templates for common operations
- Full tool coverage for all SDK managers