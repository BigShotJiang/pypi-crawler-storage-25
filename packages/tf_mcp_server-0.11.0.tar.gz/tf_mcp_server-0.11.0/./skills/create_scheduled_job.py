"""Skill template for creating ToothFairyAI scheduled jobs.

This skill guides AI assistants through scheduled job creation with cron validation.
CRITICAL: The schedule field MUST be a dict/object, NOT a JSON string.
"""

CREATE_SCHEDULED_JOB_SKILL = {
    "name": "create-scheduled-job",
    "description": "Create a new scheduled job to run an agent on a schedule",
    "auto_generated_fields": {
        "startDate": "Current timestamp (ISO 8601)",
        "nextRunAt": "1 hour from now (ISO 8601)",
        "status": "PENDING",
        "_version": "Filtered out if None",
    },
    "steps": [
        {
            "step": 1,
            "title": "Set required parameters",
            "required": ["name", "agent_id", "custom_prompt_id", "api_key", "workspace_id"],
            "descriptions": {
                "name": "Human-readable job name",
                "agent_id": "ID of the agent to run (maps to agentID in API)",
                "custom_prompt_id": "ID of the prompt to use (maps to customPromptID in API)",
                "api_key": "ToothFairyAI API key",
                "workspace_id": "Workspace ID",
            },
        },
        {
            "step": 2,
            "title": "Configure schedule as NESTED OBJECT",
            "description": "CRITICAL: schedule MUST be a dict/object with 'frequency' field, NOT a JSON string",
            "validation": {
                "format": "dict/object",
                "error": "schedule must be a dict like {'frequency': 'DAILY'}, NOT a JSON string",
            },
            "schedule_fields": {
                "frequency": {
                    "type": "string",
                    "required": True,
                    "options": ["MINUTES", "HOURLY", "DAILY", "WEEKLY", "MONTHLY", "YEARLY", "CUSTOM"],
                    "description": "How often the job runs (note: MINUTES not MINUTELY)",
                },
                "interval": {
                    "type": "integer",
                    "description": "Interval multiplier (e.g., every 2 hours)",
                },
                "hour": {
                    "type": "integer",
                    "range": "0-23",
                    "description": "Hour to run (required for DAILY, WEEKLY, MONTHLY)",
                },
                "minute": {
                    "type": "integer",
                    "range": "0-59",
                    "description": "Minute to run",
                },
                "day_of_week": {
                    "type": "integer",
                    "range": "0-6 (Sunday=0)",
                    "description": "Day of week (required for WEEKLY)",
                },
                "day_of_month": {
                    "type": "integer",
                    "range": "1-31",
                    "description": "Day of month (required for MONTHLY)",
                },
                "cron_expression": {
                    "type": "string",
                    "description": "Custom cron expression (required for CUSTOM frequency)",
                },
            },
            "correct_format": {
                "daily": {"frequency": "DAILY", "hour": 9, "minute": 0},
                "weekly": {"frequency": "WEEKLY", "day_of_week": 1, "hour": 8, "minute": 30},
                "monthly": {"frequency": "MONTHLY", "day_of_month": 1, "hour": 0, "minute": 0},
                "hourly": {"frequency": "HOURLY", "minute": 0},
                "custom": {"frequency": "CUSTOM", "cron_expression": "*/15 * * * *"},
            },
            "deprecated_format": "DO NOT USE: schedule as JSON string '{\"frequency\": \"DAILY\"}' - MUST be object",
        },
        {
            "step": 3,
            "title": "Set optional configurations",
            "optional": {
                "timezone": {"default": "UTC", "description": "Job timezone"},
                "is_active": {"default": True, "type": "boolean"},
                "description": {"type": "string", "max_length": 2048},
                "start_date": {"type": "string", "format": "ISO datetime", "note": "Auto-generated if not provided"},
                "end_date": {"type": "string", "format": "ISO datetime"},
                "status": {"default": "PENDING", "options": ["ACTIVE", "PAUSED", "PENDING", "RUNNING", "FAILED", "COMPLETED"], "note": "Auto-generated if not provided"},
                "execution_config": {"type": "object", "fields": ["timeout", "max_duration", "priority", "webhook_url"]},
                "notification_config": {"type": "object", "fields": ["on_success", "on_failure", "email_recipients"]},
                "retry_config": {"type": "object", "fields": ["max_retries", "retry_interval", "backoff_multiplier"]},
            },
        },
        {
            "step": 4,
            "title": "Build API payload with nested objects",
            "description": "Schedule, execution_config, notification_config, and retry_config are nested objects (NOT JSON strings)",
            "field_mappings": {
                "agent_id": "agentID",
                "custom_prompt_id": "customPromptID",
                "is_active": "isActive",
                "start_date": "startDate",
                "end_date": "endDate",
                "execution_config": "executionConfig",
                "notification_config": "notificationConfig",
                "retry_config": "retryConfig",
                "schedule": {
                    "cron_expression": "cronExpression",
                    "day_of_week": "dayOfWeek",
                    "day_of_month": "dayOfMonth",
                },
            },
        },
    ],
    "examples": {
        "daily_job": {
            "description": "Run agent daily at 9:00 AM UTC",
            "payload": {
                "name": "Daily Report Generator",
                "agent_id": "agent-123",
                "custom_prompt_id": "prompt-456",
                "timezone": "UTC",
                "schedule": {
                    "frequency": "DAILY",
                    "hour": 9,
                    "minute": 0,
                },
                "is_active": True,
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "weekly_job": {
            "description": "Run every Monday at 8:00 AM",
            "payload": {
                "name": "Weekly Summary",
                "agent_id": "agent-123",
                "custom_prompt_id": "prompt-456",
                "schedule": {
                    "frequency": "WEEKLY",
                    "day_of_week": 1,
                    "hour": 8,
                    "minute": 0,
                },
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "custom_cron": {
            "description": "Custom cron expression (every 15 minutes)",
            "payload": {
                "name": "Frequent Check",
                "agent_id": "agent-123",
                "custom_prompt_id": "prompt-456",
                "schedule": {
                    "frequency": "CUSTOM",
                    "cron_expression": "*/15 * * * *",
                },
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "with_notifications": {
            "description": "Job with email notifications on failure",
            "payload": {
                "name": "Critical Job",
                "agent_id": "agent-123",
                "custom_prompt_id": "prompt-456",
                "schedule": {"frequency": "DAILY", "hour": 0, "minute": 0},
                "notification_config": {
                    "on_failure": True,
                    "email_recipients": ["admin@example.com"],
                },
                "retry_config": {
                    "max_retries": 3,
                    "retry_interval": 300,
                },
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
    },
    "common_errors": {
        "missing_schedule_fields": {
            "cause": "Frequency-specific fields not provided",
            "solution": "WEEKLY needs day_of_week, MONTHLY needs day_of_month, CUSTOM needs cron_expression",
        },
        "invalid_cron": {
            "cause": "Malformed cron expression",
            "solution": "Use standard 5-field cron: minute hour day month weekday",
        },
        "end_before_start": {
            "cause": "end_date is before start_date",
            "solution": "Ensure end_date is after start_date",
        },
        "schedule_as_string": {
            "cause": "schedule provided as JSON string instead of dict",
            "solution": "Pass schedule as a dict object: schedule={'frequency': 'DAILY'}, NOT schedule='{\"frequency\": \"DAILY\"}'",
        },
    },
    "api_validation_schema": {
        "id": {"type": "string", "maxlength": 255, "auto_generated": True},
        "workspaceid": {"type": "string", "maxlength": 255, "from_token": True},
        "name": {"type": "string", "maxlength": 255, "required": True},
        "description": {"type": "string", "maxlength": 2048, "nullable": True},
        "agentID": {"type": "string", "maxlength": 255, "required": True},
        "customPromptID": {"type": "string", "maxlength": 255, "required": True},
        "timezone": {"type": "string", "maxlength": 255, "default": "UTC"},
        "isActive": {"type": "boolean", "default": True},
        "startDate": {"type": "string", "format": "AWSDateTime", "note": "Auto-generated if not provided"},
        "endDate": {"type": "string", "format": "AWSDateTime", "nullable": True},
        "nextRunAt": {"type": "string", "format": "AWSDateTime", "note": "Auto-generated (1 hour from now)"},
        "status": {"type": "string", "default": "PENDING", "allowed": ["ACTIVE", "PAUSED", "PENDING", "RUNNING", "FAILED", "COMPLETED"]},
        "schedule": {
            "type": "dict",
            "required": True,
            "schema": {
                "frequency": {"type": "string", "required": True, "allowed": ["MINUTES", "HOURLY", "DAILY", "WEEKLY", "MONTHLY", "YEARLY", "CUSTOM"]},
                "interval": {"type": "integer", "nullable": True},
                "hour": {"type": "integer", "nullable": True},
                "minute": {"type": "integer", "nullable": True},
                "dayOfWeek": {"type": "integer", "nullable": True},
                "dayOfMonth": {"type": "integer", "nullable": True},
                "cronExpression": {"type": "string", "nullable": True},
                "startDate": {"type": "string", "format": "AWSDateTime", "nullable": True},
                "endDate": {"type": "string", "format": "AWSDateTime", "nullable": True},
            },
        },
        "executionConfig": {"type": "dict", "nullable": True},
        "notificationConfig": {"type": "dict", "nullable": True},
        "retryConfig": {"type": "dict", "nullable": True},
    },
    "graphql_requirements": {
        "note": "GraphQL schema requires these fields - backend auto-generates if not provided",
        "required_fields": [
            {"name": "startDate", "type": "AWSDateTime", "default": "current timestamp"},
            {"name": "nextRunAt", "type": "AWSDateTime!", "default": "1 hour from now"},
            {"name": "status", "type": "CronJobStatus!", "default": "PENDING"},
        ],
    },
}