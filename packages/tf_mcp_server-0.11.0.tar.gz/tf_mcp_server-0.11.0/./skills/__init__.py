"""MCP Skill Templates for ToothFairyAI operations.

Skills provide step-by-step guidance for common operations with:
- Required parameters
- Validation rules
- Example payloads
- Common pitfalls
- API validation schemas
"""

from .create_agent import CREATE_AGENT_SKILL
from .update_prompt import UPDATE_PROMPT_SKILL
from .create_function import CREATE_FUNCTION_SKILL
from .setup_authorisation import SETUP_AUTHORISATION_SKILL
from .create_scheduled_job import CREATE_SCHEDULED_JOB_SKILL
from .create_document import CREATE_DOCUMENT_SKILL
from .create_member import CREATE_MEMBER_SKILL
from .create_connection import CREATE_CONNECTION_SKILL
from .document_workflow import DOCUMENT_WORKFLOW_SKILL
from .agent_interaction import AGENT_INTERACTION_SKILL

ALL_SKILLS = {
    "create-agent": CREATE_AGENT_SKILL,
    "update-prompt": UPDATE_PROMPT_SKILL,
    "create-function": CREATE_FUNCTION_SKILL,
    "setup-authorisation": SETUP_AUTHORISATION_SKILL,
    "create-scheduled-job": CREATE_SCHEDULED_JOB_SKILL,
    "create-document": CREATE_DOCUMENT_SKILL,
    "create-member": CREATE_MEMBER_SKILL,
    "create-connection": CREATE_CONNECTION_SKILL,
    "document-workflow": DOCUMENT_WORKFLOW_SKILL,
    "agent-interaction": AGENT_INTERACTION_SKILL,
}

def get_skill(name: str) -> dict:
    """Get a skill by name."""
    return ALL_SKILLS.get(name)

def list_skills() -> list:
    """List all available skills."""
    return list(ALL_SKILLS.keys())