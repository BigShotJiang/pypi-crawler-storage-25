"""Skill template for ToothFairyAI Knowledge Hub document workflows.

This skill explains the complete document lifecycle: upload, download, and management
using both MCP tools and direct API calls.
"""

DOCUMENT_WORKFLOW_SKILL = {
    "name": "document-workflow",
    "description": "Complete guide to ToothFairyAI Knowledge Hub document upload, download, and management workflows",
    "overview": """
    The ToothFairyAI Knowledge Hub manages documents for RAG (Retrieval Augmented Generation).
    Documents can be PDFs, text files, URLs, or raw text content. This skill covers:
    
    1. **Document Upload** - Two-step process: presign URL → upload → create document record
    2. **Document Download** - Get pre-signed download URLs for S3-stored files
    3. **Document Management** - List, search, update, and delete documents
    4. **API vs MCP** - When to use direct API vs MCP tools
    
    Key concepts:
    - All files are stored in S3 with paths like: s3://files-to-import-{region}-{stage}/imported-pdf/{workspace_id}/{uuid}.pdf
    - Documents have metadata records in the knowledge base
    - External_path field contains the S3 path
    - Pre-signed URLs expire quickly (5 minutes)
    """,
    "workflows": [
        {
            "name": "upload-pdf-document",
            "description": "Upload a PDF file to the Knowledge Hub",
            "steps": [
                {
                    "step": 1,
                    "title": "Get pre-signed upload URL",
                    "description": "Request a temporary upload URL from S3",
                    "method": "api",
                    "endpoint": "GET /documents/requestPreSignedURL",
                    "parameters": {
                        "filename": "workspace_id/filename.pdf (MUST include workspace ID prefix)",
                        "contentType": "application/pdf (optional, defaults based on extension)"
                    },
                    "headers": {
                        "x-api-key": "Your API key",
                        "accept": "application/json"
                    },
                    "example_curl": """
curl -G "https://api.toothfairyai.com/documents/requestPreSignedURL" \
  --data-urlencode "filename=8b37c0a6-595e-4c78-8931-4fec0188a993/my-document.pdf" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "accept: application/json"
                    """,
                    "response": {
                        "uploadURL": "Temporary S3 PUT URL with query parameters",
                        "filePath": "s3://files-to-import-aus-prod/imported-pdf/8b37c0a6-595e-4c78-8931-4fec0188a993/{uuid}.pdf"
                    }
                },
                {
                    "step": 2,
                    "title": "Upload file to S3",
                    "description": "PUT the file bytes to the uploadURL",
                    "method": "direct_s3",
                    "parameters": {
                        "uploadURL": "URL from step 1 (MUST include query string)",
                        "content": "PDF file bytes",
                        "Content-Type": "application/pdf"
                    },
                    "example_curl": """
curl -X PUT "<uploadURL from step 1>" \
  -H "Content-Type: application/pdf" \
  --data-binary @./document.pdf
                    """,
                    "notes": "Must use PUT with exact uploadURL including query params. Returns 200/204 on success."
                },
                {
                    "step": 3,
                    "title": "Create document record",
                    "description": "Create metadata record in knowledge base",
                    "method": "api",
                    "endpoint": "POST /doc/create",
                    "parameters": {
                        "workspaceid": "Your workspace ID",
                        "userid": "User ID creating the document",
                        "data": [
                            {
                                "type": "readComprehensionPdf",
                                "title": "Document title",
                                "external_path": "s3 path from step 1 filePath",
                                "topics": ["topic-id-1", "topic-id-2"],
                                "folderid": "mrcRoot or folder ID",
                                "status": "published or draft"
                            }
                        ]
                    },
                    "headers": {
                        "x-api-key": "Your API key",
                        "Content-Type": "application/json"
                    },
                    "example_curl": """
curl -X POST "https://api.toothfairyai.com/doc/create" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "workspaceid": "8b37c0a6-595e-4c78-8931-4fec0188a993",
    "userid": "user-123",
    "data": [{
      "type": "readComprehensionPdf",
      "title": "My Document",
      "external_path": "s3://files-to-import-aus-prod/imported-pdf/8b37c0a6-595e-4c78-8931-4fec0188a993/uuid.pdf"
    }]
  }'
                    """,
                    "response": {
                        "success": True,
                        "document_id": "Document ID for future reference"
                    }
                }
            ]
        },
        {
            "name": "download-document",
            "description": "Download a document from the Knowledge Hub",
            "steps": [
                {
                    "step": 1,
                    "title": "Get document metadata",
                    "description": "Find document by ID to get its external_path",
                    "method": "mcp",
                    "tool": "get_toothfairy_document",
                    "parameters": {
                        "api_key": "Your API key",
                        "workspace_id": "Your workspace ID",
                        "document_id": "Document ID to download"
                    },
                    "response_fields": {
                        "external_path": "S3 path (e.g., s3://files-to-import-aus-prod/imported-pdf/workspace_id/uuid.pdf)"
                    }
                },
                {
                    "step": 2,
                    "title": "Get pre-signed download URL",
                    "description": "Request temporary download URL for S3 file",
                    "method": "api",
                    "endpoint": "GET /documents/requestDownloadURLByWorkspace",
                    "parameters": {
                        "workspaceid": "Your workspace ID",
                        "filename": "S3 path without s3:// prefix (e.g., imported-pdf/workspace_id/uuid.pdf)",
                        "context": "pdf (for PDF documents)"
                    },
                    "headers": {
                        "x-api-key": "Your API key",
                        "accept": "application/json"
                    },
                    "example_curl": """
curl -G "https://api.toothfairyai.com/documents/requestDownloadURLByWorkspace" \
  --data-urlencode "workspaceid=8b37c0a6-595e-4c78-8931-4fec0188a993" \
  --data-urlencode "filename=imported-pdf/8b37c0a6-595e-4c78-8931-4fec0188a993/uuid.pdf" \
  --data-urlencode "context=pdf" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "accept: application/json"
                    """,
                    "response": {
                        "url": "Pre-signed S3 URL (expires in 5 minutes)",
                        "expiresIn": 300,
                        "fileKey": "S3 key",
                        "bucket": "S3 bucket name"
                    }
                },
                {
                    "step": 3,
                    "title": "Download file",
                    "description": "Download using the pre-signed URL",
                    "method": "direct_s3",
                    "parameters": {
                        "url": "Pre-signed URL from step 2"
                    },
                    "example_curl": """
curl -L "<pre-signed-url>" -o "downloaded.pdf"
                    """,
                    "notes": "URL expires in 5 minutes. Use -L to follow redirects."
                }
            ]
        },
        {
            "name": "list-search-documents",
            "description": "List and search documents in workspace",
            "steps": [
                {
                    "step": 1,
                    "title": "List all documents",
                    "description": "Get all documents in workspace",
                    "method": "mcp",
                    "tool": "list_toothfairy_documents",
                    "parameters": {
                        "api_key": "Your API key",
                        "workspace_id": "Your workspace ID",
                        "limit": 100
                    },
                    "response": "List of document objects with id, title, type, external_path, status"
                },
                {
                    "step": 2,
                    "title": "Search documents",
                    "description": "Search documents by text",
                    "method": "mcp",
                    "tool": "search_toothfairy_documents",
                    "parameters": {
                        "api_key": "Your API key",
                        "workspace_id": "Your workspace ID",
                        "text": "Search query"
                    },
                    "response": "Matching documents"
                },
                {
                    "step": 3,
                    "title": "Get document by ID",
                    "description": "Get specific document details",
                    "method": "mcp",
                    "tool": "get_toothfairy_document",
                    "parameters": {
                        "api_key": "Your API key",
                        "workspace_id": "Your workspace ID",
                        "document_id": "Document ID"
                    }
                }
            ]
        }
    ],
    "document_types": {
        "readComprehensionPdf": {
            "description": "PDF files uploaded to S3",
            "external_path": "Required - S3 path",
            "upload_method": "Two-step: presign → upload → create"
        },
        "readComprehensionFile": {
            "description": "Other file types (txt, docx, etc.)",
            "external_path": "Required - S3 path",
            "upload_method": "Same as PDF"
        },
        "readComprehensionUrl": {
            "description": "Web pages crawled by ToothFairyAI",
            "external_path": "Required - URL",
            "upload_method": "Direct create with URL"
        },
        "readComprehensionContent": {
            "description": "Direct text content (no file)",
            "external_path": "Not required",
            "upload_method": "Direct create with content"
        }
    },
    "s3_path_patterns": {
        "pdf": "imported-pdf/{workspace_id}/{uuid}.pdf",
        "generic_files": "imported_doc_files/{workspace_id}/{uuid}.{ext}",
        "audio": "imported_audio_files/{workspace_id}/{uuid}.wav",
        "video": "imported_video_files/{workspace_id}/{uuid}.mp4",
        "full_s3_path": "s3://files-to-import-{region}-{stage}/{type}/{workspace_id}/{uuid}.{ext}"
    },
    "authentication_methods": {
        "mcp_tools": {
            "required": ["api_key", "workspace_id", "region (default: au)"],
            "tool_pattern": "All tools start with validate_toothfairy_credentials first"
        },
        "direct_api": {
            "required_header": "x-api-key",
            "base_url": "https://api.toothfairyai.com",
            "region_specific": "No region in URL (unified endpoint)"
        }
    },
    "common_errors_and_solutions": {
        "403_unauthorized": {
            "cause": "Invalid API key or workspace not found",
            "solution": "Run validate_toothfairy_credentials first. Check API key and workspace ID."
        },
        "446_filename_pattern": {
            "cause": "Filename missing workspace ID prefix",
            "solution": "Format must be: {workspace_id}/filename.pdf"
        },
        "403_access_denied_on_upload": {
            "cause": "PUT to wrong URL or URL expired",
            "solution": "Use exact uploadURL with query string. URLs expire in 5 minutes."
        },
        "document_not_found": {
            "cause": "Invalid document ID or document not in workspace",
            "solution": "Use list_toothfairy_documents to find correct IDs."
        }
    },
    "mcp_tools_reference": {
        "upload_workflow": [
            "validate_toothfairy_credentials (ALWAYS FIRST)",
            "create_toothfairy_document (for direct text/content)",
            "Note: File upload requires direct API calls (not available in MCP)"
        ],
        "download_workflow": [
            "validate_toothfairy_credentials",
            "get_toothfairy_document (get external_path)",
            "list_toothfairy_documents (browse)",
            "search_toothfairy_documents (find)"
        ],
        "management": [
            "update_toothfairy_document",
            "delete_toothfairy_document",
            "create_toothfairy_folder",
            "list_toothfairy_folders"
        ]
    },
    "real_world_example": {
        "scenario": "Download document ID 11897 from workspace 8b37c0a6-595e-4c78-8931-4fec0188a993",
        "steps": [
            "1. Get document metadata: get_toothfairy_document(document_id='11897')",
            "2. Extract external_path: s3://files-to-import-aus-prod/imported-pdf/8b37c0a6-595e-4c78-8931-4fec0188a993/3f14a3ed-5d14-4d5e-b276-8c4102375d84.pdf",
            "3. Convert to filename: imported-pdf/8b37c0a6-595e-4c78-8931-4fec0188a993/3f14a3ed-5d14-4d5e-b276-8c4102375d84.pdf",
            "4. Request download URL: GET /documents/requestDownloadURLByWorkspace with workspaceid, filename, context='pdf'",
            "5. Download: curl -L <url> -o document.pdf"
        ],
        "curl_example": """
# Step 1: Get download URL
curl -G "https://api.toothfairyai.com/documents/requestDownloadURLByWorkspace" \
  --data-urlencode "workspaceid=8b37c0a6-595e-4c78-8931-4fec0188a993" \
  --data-urlencode "filename=imported-pdf/8b37c0a6-595e-4c78-8931-4fec0188a993/3f14a3ed-5d14-4d5e-b276-8c4102375d84.pdf" \
  --data-urlencode "context=pdf" \
  -H "x-api-key: T0tfvwoksV7LvbLnRsNGK54Rr4w04omsRHzzi125" \
  -H "accept: application/json"

# Step 2: Download file (using URL from response)
curl -L "https://files-to-import-aus-prod.s3.ap-southeast-2.amazonaws.com/...very-long-url..." -o "document_11897.pdf"
        """
    },
    "best_practices": {
        "1": "ALWAYS run validate_toothfairy_credentials before any MCP tool",
        "2": "For file uploads, use direct API calls (MCP doesn't have file upload tools)",
        "3": "Pre-signed URLs expire in 5 minutes - use immediately",
        "4": "Filenames must include workspace ID prefix: {workspace_id}/filename.pdf",
        "5": "Keep .tf_credentials.json with api_key and workspace_id for easy access",
        "6": "Use list_toothfairy_documents to discover document IDs before downloading",
        "7": "Check document status: 'published' documents are ready, 'draft' may not be searchable"
    }
}