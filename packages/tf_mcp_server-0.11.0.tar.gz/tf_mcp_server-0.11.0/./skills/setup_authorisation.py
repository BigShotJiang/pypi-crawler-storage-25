"""Skill template for setting up ToothFairyAI authorisations.

This skill guides AI assistants through the two-step authorisation flow.
"""

SETUP_AUTHORISATION_SKILL = {
    "name": "setup-authorisation",
    "description": "Create an authorisation for storing API credentials (used with functions)",
    "steps": [
        {
            "step": 1,
            "title": "Determine auth type",
            "description": "Choose the appropriate authentication type",
            "options": {
                "none": "No authentication required",
                "bearer": "Static bearer token (requires token_secret)",
                "apikey": "API key authentication (requires token_secret)",
                "oauth": "OAuth2 flow (requires client_id, client_secret, authorization_base_url, grant_type). For authorization_code grant_type, also provide token_secret with the refresh token.",
                "password": "Password-based auth (requires token_secret)",
                "basic": "HTTP Basic auth (requires token_secret)",
                "username_and_password": "Username/password combo (requires token_secret)",
            },
        },
        {
            "step": 2,
            "title": "Set required parameters",
            "required": ["name", "auth_type", "api_key", "workspace_id"],
            "descriptions": {
                "name": "Human-readable name for this authorisation",
                "auth_type": "Type from: none, bearer, apikey, oauth, password, basic, username_and_password",
                "api_key": "ToothFairyAI API key",
                "workspace_id": "Workspace ID",
            },
        },
        {
            "step": 3,
            "title": "Provide auth-type-specific fields",
            "description": "CRITICAL: Each auth_type requires specific additional fields",
            "required_by_type": {
                "bearer": ["token_secret"],
                "apikey": ["token_secret"],
                "password": ["token_secret"],
                "basic": ["token_secret"],
                "username_and_password": ["token_secret"],
                "oauth": ["client_id", "client_secret", "authorization_base_url", "grant_type"],
            },
            "optional_oauth_fields": ["scope", "token_base_url", "token_secret"],
            "oauth_token_secret_note": "token_secret is OPTIONAL for OAuth but REQUIRED for authorization_code grant_type to store the refresh token. It is NOT required for client_credentials grant_type.",
        },
        {
            "step": 4,
            "title": "Use authorisation_id in functions",
            "description": "After creating authorisation, use the returned authorisation_id in AgentFunction creation",
            "field_mapping": {
                "authorisation_id": "authorisationID",
            },
        },
    ],
    "examples": {
        "bearer_auth": {
            "description": "Bearer token authentication",
            "payload": {
                "name": "My API Bearer Token",
                "auth_type": "bearer",
                "token_secret": "your-bearer-token-here",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "apikey_auth": {
            "description": "API key authentication",
            "payload": {
                "name": "External API Key",
                "auth_type": "apikey",
                "token_secret": "your-api-key-here",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "oauth_client_credentials": {
            "description": "OAuth2 client credentials flow (no token_secret needed)",
            "payload": {
                "name": "OAuth2 Service",
                "auth_type": "oauth",
                "client_id": "your-client-id",
                "client_secret": "your-client-secret",
                "authorization_base_url": "https://auth.example.com/oauth/token",
                "grant_type": "client_credentials",
                "scope": "read write",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "oauth_authorization_code": {
            "description": "OAuth2 authorization_code flow with refresh token",
            "payload": {
                "name": "OAuth2 API with Refresh Token",
                "auth_type": "oauth",
                "client_id": "your-client-id",
                "client_secret": "your-client-secret",
                "token_secret": "your-refresh-token-here",
                "authorization_base_url": "https://auth.example.com/oauth/authorize",
                "token_base_url": "https://auth.example.com/oauth/token",
                "grant_type": "authorization_code",
                "scope": "openid read write offline_access",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "no_auth": {
            "description": "No authentication (for public APIs)",
            "payload": {
                "name": "Public API",
                "auth_type": "none",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
    },
    "common_errors": {
        "missing_token_secret": {
            "cause": "bearer/apikey/password/basic auth requires token_secret",
            "solution": "Add token_secret parameter with your token/key value",
        },
        "missing_oauth_fields": {
            "cause": "OAuth requires client_id, client_secret, authorization_base_url, grant_type",
            "solution": "Provide all four required OAuth fields",
        },
        "missing_refresh_token_for_authorization_code": {
            "cause": "OAuth authorization_code grant_type requires token_secret to store the refresh token",
            "solution": "Provide token_secret with the refresh token value when using authorization_code grant_type",
        },
        "wrong_auth_type": {
            "cause": "Using wrong auth_type for the API",
            "solution": "Check API documentation for correct authentication method",
        },
    },
    "workflow": {
        "description": "Two-step process for authenticated functions",
        "steps": [
            "1. Create authorisation → get authorisation_id",
            "2. Create function with authorisation_id parameter",
        ],
    },
}