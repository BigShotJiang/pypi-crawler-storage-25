"""Skill template for updating ToothFairyAI prompts.

This skill guides AI assistants through prompt updates with validation.
"""

UPDATE_PROMPT_SKILL = {
    "name": "update-prompt",
    "description": "Update an existing prompt template with proper validation",
    "steps": [
        {
            "step": 1,
            "title": "Get prompt ID",
            "description": "Retrieve the prompt_id from list_prompts or previous creation",
            "required": ["prompt_id", "api_key", "workspace_id"],
        },
        {
            "step": 2,
            "title": "Validate interpolation_string length",
            "description": "CRITICAL: interpolation_string must be at least 128 characters",
            "validation": {
                "min_length": 128,
                "error": "interpolation_string must be at least 128 characters",
            },
        },
        {
            "step": 3,
            "title": "Build update payload",
            "description": "All fields are optional for updates",
            "optional_fields": {
                "label": "Prompt name/identifier",
                "interpolation_string": "Prompt template content (min 128 chars)",
            },
        },
    ],
    "examples": {
        "update_prompt_content": {
            "description": "Update prompt template content",
            "payload": {
                "prompt_id": "prompt-123",
                "interpolation_string": "You are a helpful customer support agent. Always be polite and professional. Answer questions accurately based on the knowledge base. If you don't know something, admit it and offer to escalate to a human agent. Provide helpful suggestions when possible. Use clear, simple language.",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
    },
    "common_errors": {
        "interpolation_too_short": {
            "cause": "interpolation_string less than 128 characters",
            "solution": "Ensure prompt content is at least 128 characters",
        },
    },
}