"""Skill template for interacting with ToothFairyAI agents.

This skill guides AI assistants through:
1. Sending messages to agents (streaming vs dispatch)
2. Uploading files BEFORE agent requests
3. Using file keys in attachments
"""

AGENT_INTERACTION_SKILL = {
    "name": "agent-interaction",
    "description": "Complete guide to interacting with ToothFairyAI agents: messaging, file uploads, streaming vs dispatch",
    "overview": """
    ToothFairyAI agents can process messages and files. This skill covers:
    
    1. **Agent Interaction Modes**
       - Streaming (recommended): Real-time SSE responses via ais.* servers
       - Dispatch: Async tasks with polling via /dispatch endpoint
       - Planner: Multi-step orchestration via /planner endpoint
    
    2. **File Uploads (MANDATORY FIRST STEP)**
       - Files MUST be uploaded BEFORE agent requests
       - SDK: client.documents.upload() returns filename key
       - Use filename key in attachments parameter
    
    3. **API Domains**
       - ais.{region}.toothfairyai.com: Streaming (recommended)
       - ai.{region}.toothfairyai.com: REST, Dispatch, Predictions
       - api.{region}.toothfairyai.com: File uploads, management
    """,
    "api_domains": {
        "ai_streaming": {
            "domain": "ais.{region}.toothfairyai.com",
            "purpose": "SSE streaming responses (RECOMMENDED)",
            "endpoints": ["/agent", "/planner"],
        },
        "ai_services": {
            "domain": "ai.{region}.toothfairyai.com",
            "purpose": "REST, dispatch, predictions",
            "endpoints": ["/chatter", "/dispatch", "/predictions"],
            "note": "REST has 60-second hard timeout - prefer streaming",
        },
        "platform": {
            "domain": "api.{region}.toothfairyai.com",
            "purpose": "File uploads, agent management",
            "endpoints": ["/documents/requestPreSignedURL", "/doc/create"],
        },
    },
    "interaction_modes": {
        "streaming_recommended": {
            "description": "Stream real-time responses via SSE - RECOMMENDED for all agent interactions",
            "use_when": [
                "All agent interactions (this is the recommended default)",
                "Agentic Tooling 2.0 agents with tools",
                "Longer agent responses expected",
                "Want to see progress in real-time",
                "Multi-step reasoning and tool orchestration",
            ],
            "sdk_method": "client.streaming.send_to_agent()",
            "api_endpoint": "POST /agent",
            "api_domain": "ais.{region}.toothfairyai.com (Streaming server)",
            "why_preferred": [
                "No hard timeout (REST has 60s hard limit)",
                "Supports Agentic Tooling 2.0",
                "Real-time progress visibility",
                "Better UX with progressive output",
            ],
            "parameters": {
                "message": "User message text",
                "agent_id": "Target agent UUID",
                "chat_id": "Optional - existing chat UUID",
                "raw_stream": "True for token-by-token, False for message chunks",
                "attachments": "Optional - dict with images/audios/videos/files keys",
            },
            "stream_events": {
                "connected": "Connection established",
                "init": "Agent initializing",
                "initial_setup_completed": "Setup done, starting processing",
                "data_processing_completed": "RAG data retrieved",
                "tools_processing_completed": "Tool execution finished",
                "message": "Text chunks with metadata",
                "fulfilled": "Response complete",
                "complete": "Stream closed",
            },
            "example": {
                "description": "Stream agent response",
                "code": """
stream = client.streaming.send_to_agent("Hello", "agent-id")
for event in stream:
    if event.text:
        print(event.text, end="", flush=True)
print(f"\\nChat ID: {stream.chat_id}")
                """,
            },
        },
        "planner_streaming": {
            "description": "Stream orchestrator agent responses with multi-step planning",
            "use_when": [
                "Multi-agent orchestration via planner mode",
                "Task decomposition and delegation",
                "Autonomous step execution",
            ],
            "api_endpoint": "POST /planner",
            "api_domain": "ais.{region}.toothfairyai.com (Streaming only)",
            "note": "Planner endpoint is SSE-only, no REST equivalent",
            "parameters": {
                "workspaceid": "Workspace UUID",
                "agentid": "Planner agent UUID",
                "messages": [{"role": "user", "text": "task description"}],
            },
            "planning_statuses": {
                "IN_PROGRESS": "Plan being executed",
                "COMPLETED": "All steps done",
                "FAILED": "Plan execution failed",
                "STEP_REQUIRES_APPROVAL": "Current step needs approval",
                "DEEP_THINKING": "Extended reasoning mode",
                "EXECUTING_STEP": "Executing current step",
                "REPLANNING": "Revising the plan",
            },
        },
        "predictions_endpoint": {
            "description": "Raw LLM access - direct model inference without agent orchestration",
            "api_endpoint": "POST /predictions",
            "api_domain": "ai.{region}.toothfairyai.com",
            "use_when": [
                "Direct LLM access without agent framework",
                "Simple prompt-response pattern",
                "No RAG, tools, or agent features needed",
            ],
            "note": "Bypasses agent layer entirely - just raw model inference",
        },
        "rest_sync_deprecated": {
            "description": "REST sync mode - NOT RECOMMENDED (use streaming instead)",
            "warning": "REST mode has 60-second HARD TIMEOUT. Does NOT support Agentic Tooling 2.0. Use streaming (ais.* servers) instead.",
            "api_endpoint": "POST /chatter",
            "api_domain": "ai.{region}.toothfairyai.com (REST server)",
            "limitations": [
                "Hard 60-second timeout - complex tasks will fail",
                "No Agentic Tooling 2.0 support",
                "No real-time progress",
                "Avoid slow reasoning models",
            ],
            "only_use_when": [
                "Simple RAG queries that complete in < 60s",
                "Legacy integrations requiring REST",
            ],
        },
        "dispatch_async": {
            "description": "Dispatch async task - returns taskId for polling",
            "use_when": [
                "Very long-running tasks (hours)",
                "Background processing without waiting",
                "Batch operations via CronJobs infrastructure",
            ],
            "api_endpoint": "POST /dispatch",
            "api_domain": "ai.{region}.toothfairyai.com",
            "note": "SDK does NOT wrap this endpoint. Must use direct API call.",
            "parameters": {
                "workspaceid": "Workspace UUID",
                "agentid": "Agent UUID",
                "messages": [{"role": "user", "text": "message text"}],
                "images": "Optional - list of image keys from upload",
                "audios": "Optional - list of audio keys from upload",
                "videos": "Optional - list of video keys from upload",
                "files": "Optional - list of document keys from upload",
            },
            "response": {
                "taskId": "CronJob ID for status polling",
                "status": "QUEUED",
                "pollUrl": "/dispatch/status/{taskId}",
            },
            "polling": {
                "endpoint": "GET /dispatch/status/{taskId}",
                "statuses": ["QUEUED", "RUNNING", "COMPLETED", "FAILED", "PAUSED", "CANCELLED"],
                "interval": "10-30 seconds",
            },
            "example": {
                "code": """
import requests

# Dispatch the task
response = requests.post(
    "https://ai.toothfairyai.com/dispatch",
    headers={"x-api-key": "YOUR_API_KEY"},
    json={
        "workspaceid": "YOUR_WORKSPACE_ID",
        "agentid": "agent-uuid",
        "messages": [{"role": "user", "text": "Process this"}]
    }
)
task_id = response.json()["taskId"]

# Poll for completion
while True:
    status = requests.get(
        f"https://ai.toothfairyai.com/dispatch/status/{task_id}",
        headers={"x-api-key": "YOUR_API_KEY"}
    ).json()
    
    if status["status"] == "COMPLETED":
        print(status["result"])
        break
    time.sleep(10)
                """,
            },
        },
    },
    "decision_framework": {
        "question": "Which interaction mode should I use?",
        "quick_guide": {
            "simple_qa": "streaming (ais.*/agent) - recommended default",
            "multi_tool_agent": "streaming (ais.*/agent) - supports AT 2.0",
            "file_analysis": "streaming with attachments (upload first)",
            "planning_orchestration": "streaming (ais.*/planner)",
            "raw_llm": "predictions (ai.*/predictions)",
            "background_task": "dispatch (ai.*/dispatch) - returns taskId",
        },
    },
    "file_uploads": {
        "critical_rule": "FILES MUST BE UPLOADED FIRST - you cannot reference files directly in agent requests",
        "workflow_overview": """
        ┌─────────────────────────────────────────────────────────────────┐
        │  FILE UPLOAD WORKFLOW (MANDATORY)                              │
        ├─────────────────────────────────────────────────────────────────┤
        │                                                                 │
        │  Step 1: Upload file via SDK                                   │
        │  ─────────────────────────                                     │
        │  result = client.documents.upload("./file.pdf")               │
        │  → Returns FileUploadResult with 'filename' key                │
        │                                                                 │
        │  Step 2: Use the filename key in agent request                 │
        │  ──────────────────────────────────────────                    │
        │  attachments={"files": [result.filename]}                      │
        │                                                                 │
        │  Step 3: Agent receives file and processes                     │
        │  ──────────────────────────────────────                        │
        │                                                                 │
        └─────────────────────────────────────────────────────────────────┘
        """,
        "sdk_upload_method": {
            "description": "Use the SDK to upload files - it handles pre-signed URL and S3 upload automatically",
            "method": "client.documents.upload(file_path)",
            "parameters": {
                "file_path": "Path to local file (required)",
                "folder_id": "Folder ID for Knowledge Hub (default: mrcRoot)",
                "on_progress": "Optional callback(percent, loaded, total)",
            },
            "returns": {
                "FileUploadResult": {
                    "success": "bool - upload succeeded",
                    "filename": "str - THE KEY to use in agent requests",
                    "original_filename": "str - original file name",
                    "sanitized_filename": "str - sanitized version",
                    "content_type": "str - MIME type",
                    "size": "int - file size in bytes",
                    "size_in_mb": "float - file size in MB",
                },
            },
            "example": {
                "description": "Upload a file and use it in an agent request",
                "code": """
# Step 1: Upload the file FIRST
result = client.documents.upload("./report.pdf")
print(f"Uploaded: {result.filename}")
# result.filename = "report.pdf" (the key to use)

# Step 2: Use the filename key in agent request
stream = client.streaming.send_to_agent(
    message="Analyze this report and summarize key findings",
    agent_id="analyst-agent-id",
    attachments={"files": [result.filename]}
)

# Step 3: Process the response
for event in stream:
    if event.text:
        print(event.text, end="", flush=True)
                """,
            },
        },
        "attachment_types": {
            "images": {
                "description": "Image files for vision analysis",
                "formats": ["PNG", "JPEG", "GIF", "WebP", "SVG"],
                "parameter": "images",
                "example": 'attachments={"images": ["photo.png"]}',
            },
            "audios": {
                "description": "Audio files for transcription/analysis",
                "formats": ["WAV", "MP3", "M4A", "FLAC", "OGG"],
                "parameter": "audios",
                "max_size": "25MB",
                "example": 'attachments={"audios": ["recording.wav"]}',
            },
            "videos": {
                "description": "Video files for analysis",
                "formats": ["MP4", "AVI", "MOV", "MKV"],
                "parameter": "videos",
                "max_size": "500MB",
                "max_duration": "30 minutes",
                "example": 'attachments={"videos": ["demo.mp4"]}',
            },
            "files": {
                "description": "Document files for RAG/analysis",
                "formats": ["PDF", "CSV", "DOC", "DOCX", "XLS", "XLSX", "HTML", "TXT", "MD"],
                "parameter": "files",
                "example": 'attachments={"files": ["document.pdf", "data.xlsx"]}',
            },
        },
        "multiple_files": {
            "description": "Upload and use multiple files in one request",
            "example": {
                "code": """
# Upload multiple files
doc1 = client.documents.upload("./report.pdf")
doc2 = client.documents.upload("./data.xlsx")
image = client.documents.upload("./chart.png")

# Use all in one request
stream = client.streaming.send_to_agent(
    message="Analyze the report, data, and chart together",
    agent_id="analyst-agent-id",
    attachments={
        "files": [doc1.filename, doc2.filename],
        "images": [image.filename]
    }
)
                """,
            },
        },
        "direct_api_upload": {
            "description": "If SDK is not available, use direct API calls",
            "warning": "SDK method is preferred - this is only for non-SDK environments",
            "steps": [
                {
                    "step": 1,
                    "title": "Request pre-signed URL",
                    "endpoint": "GET /documents/requestPreSignedURL",
                    "api_domain": "api.{region}.toothfairyai.com",
                    "parameters": {
                        "filename": "MUST be: {workspace_id}/{filename}",
                    },
                    "response": {
                        "uploadURL": "Pre-signed S3 PUT URL",
                        "filePath": "S3 path (use as filename key)",
                    },
                },
                {
                    "step": 2,
                    "title": "Upload to S3",
                    "method": "PUT to uploadURL with file bytes",
                    "headers": {"Content-Type": "appropriate MIME type"},
                },
                {
                    "step": 3,
                    "title": "Use filePath as the filename key",
                    "note": "The filePath from step 1 is what you use in attachments",
                },
            ],
        },
        "common_errors": {
            "wrong_message_format": {
                "error": "Using {\"role\": \"user\", \"content\": \"...\"} in messages array",
                "solution": "CRITICAL: Use {\"role\": \"user\", \"text\": \"...\"} instead. The API expects 'text', NOT 'content'."
            },
            "file_not_uploaded": {
                "error": "Referencing a file that wasn't uploaded first",
                "solution": "Always call client.documents.upload() before using filename in attachments",
            },
            "wrong_filename": {
                "error": "Using local path instead of upload result filename",
                "solution": "Use result.filename from upload, not the local file path",
            },
            "agent_no_upload_permission": {
                "error": "Agent not configured to accept file uploads",
                "solution": "Check agent has allow_docs_upload, allow_images_upload, etc. enabled",
            },
        },
    },
    "best_practices": [
        "CRITICAL: The messages array uses {\"role\": \"user\", \"text\": \"...\"} NOT {\"role\": \"user\", \"content\": \"...\"}. Using \"content\" will cause errors.",
        "Use streaming (ais.* servers) for all agent interactions - no timeout, supports AT 2.0",
        "Upload files FIRST before any agent request that needs them",
        "Use result.filename from upload as the key in attachments",
        "For long background tasks, use /dispatch endpoint and poll for status",
        "Avoid REST mode (ai.* /chatter) - 60s hard timeout, no AT 2.0",
        "Check agent upload permissions before sending files",
    ],
}
