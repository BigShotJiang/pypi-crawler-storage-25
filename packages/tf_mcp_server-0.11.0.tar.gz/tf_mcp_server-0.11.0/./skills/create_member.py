"""Skill template for creating ToothFairyAI workspace members.

This skill guides AI assistants through member creation with proper field mapping.
"""

CREATE_MEMBER_SKILL = {
    "name": "create-member",
    "description": "Add a new member to a ToothFairyAI workspace",
    "steps": [
        {
            "step": 1,
            "title": "Set required parameters",
            "required": ["user_id", "api_key", "workspace_id"],
            "descriptions": {
                "user_id": "ID of the user to add (maps to userID in API)",
                "api_key": "ToothFairyAI API key",
                "workspace_id": "Workspace ID",
            },
        },
        {
            "step": 2,
            "title": "Set optional parameters",
            "optional": {
                "user_type": {
                    "type": "string",
                    "maxlength": 255,
                    "description": "Type of user (e.g., 'human', 'bot')",
                },
                "policy_id": {
                    "type": "string",
                    "maxlength": 255,
                    "description": "ID of the policy to assign (maps to policyID)",
                },
                "favorite_agents": {
                    "type": "array",
                    "description": "List of favorite agent IDs (maps to favoriteAgents)",
                },
                "recent_local_folders": {
                    "type": "array",
                    "description": "List of recent local folder IDs",
                },
                "recent_files": {
                    "type": "array",
                    "description": "List of recent file IDs",
                },
            },
        },
        {
            "step": 3,
            "title": "Build API payload with correct field mappings",
            "description": "Member maps to UserWorkspaceType in GraphQL",
            "field_mappings": {
                "user_id": "userID",
                "user_type": "userType",
                "policy_id": "policyID",
                "favorite_agents": "favoriteAgents",
                "recent_local_folders": "recentLocalFolders",
                "recent_files": "recentFiles",
            },
            "api_endpoint": "/member/create",
            "graphql_mutation": "createUserWorkspaceType",
        },
    ],
    "examples": {
        "basic_member": {
            "description": "Add a basic member to workspace",
            "payload": {
                "user_id": "user-123",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "member_with_policy": {
            "description": "Add member with assigned policy",
            "payload": {
                "user_id": "user-456",
                "user_type": "human",
                "policy_id": "policy-789",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "bot_member": {
            "description": "Add a bot/service account member",
            "payload": {
                "user_id": "bot-service-001",
                "user_type": "bot",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
    },
    "common_errors": {
        "missing_user_id": {
            "cause": "user_id not provided",
            "solution": "Always provide user_id (required field)",
        },
        "invalid_policy_id": {
            "cause": "policy_id does not exist",
            "solution": "Verify policy exists before assigning to member",
        },
    },
    "related_operations": {
        "list": {
            "tool": "list_toothfairy_members",
            "description": "List all workspace members",
        },
        "update": {
            "tool": "update_toothfairy_member",
            "params": ["member_id", "fields to update"],
        },
        "delete": {
            "tool": "delete_toothfairy_member",
            "params": ["member_id"],
        },
    },
    "api_validation_schema": {
        "id": {"type": "string", "maxlength": 255, "auto_generated": True},
        "workspaceid": {"type": "string", "maxlength": 255, "from_token": True},
        "userID": {"type": "string", "maxlength": 255, "required": True},
        "userType": {"type": "string", "maxlength": 255, "nullable": True},
        "policyID": {"type": "string", "maxlength": 255, "nullable": True},
        "favoriteAgents": {"type": "list", "nullable": True},
        "recentLocalFolders": {"type": "list", "nullable": True},
        "recentFiles": {"type": "list", "nullable": True},
    },
}