"""Skill template for creating ToothFairyAI agent functions (tools).

This skill guides AI assistants through function creation with JSON Schema validation,
including GraphQL-specific patterns and the critical authorisation_id two-step flow.
"""

CREATE_FUNCTION_SKILL = {
    "name": "create-function",
    "description": "Create a new agent function (tool) for external API calls",
    "steps": [
        {
            "step": 1,
            "title": "Set required parameters",
            "required": ["name", "description", "url", "api_key", "workspace_id"],
            "descriptions": {
                "name": "Function name (e.g., 'get_weather', 'fetch_projects')",
                "description": "Clear description of what the function does and WHEN to use it. For multi-function agents, include guidance like 'Call this at session start alongside fetch_clients and fetch_members'",
                "url": "API endpoint URL",
                "api_key": "ToothFairyAI API key",
                "workspace_id": "Workspace ID",
            },
        },
        {
            "step": 2,
            "title": "Set request type",
            "description": "HTTP method for the API call. For GraphQL, use graphql_query or graphql_mutation.",
            "options": ["get", "post", "put", "delete", "patch", "custom", "graphql_query", "graphql_mutation"],
            "default": "get",
            "graphql_note": "When using graphql_query or graphql_mutation, the graphql_query, graphql_mutation, and graphql_operation_name fields are NOT available on the create API. You must create the function first, then update it with these fields (see Step 6).",
        },
        {
            "step": 3,
            "title": "Define parameters in JSON Schema format",
            "description": "CRITICAL: Parameters MUST be in JSON Schema format, NOT deprecated array format",
            "validation": {
                "format": "JSON Schema object",
                "error": "Parameters must be a valid JSON Schema object with 'type', 'properties', and 'required'",
            },
            "correct_format": {
                "type": "object",
                "properties": {
                    "location": {"type": "string", "description": "City name"},
                    "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]},
                },
                "required": ["location"],
            },
            "deprecated_format": "DO NOT USE: [{'name': 'location', 'type': 'string'}]",
        },
        {
            "step": 4,
            "title": "Set authentication (CRITICAL: two-step flow)",
            "description": "CRITICAL: The authorisation_id must be set BOTH during creation AND confirmed after creation. The create API maps authorisation_id to authorisation_key internally, but the UI reads authorisation_id separately. If authorisation_id is null in the response, you MUST update the function to set it explicitly.",
            "auth_types": {
                "none": "No authentication",
                "bearer": "Static bearer token (requires token_secret)",
                "apikey": "API key (requires token_secret)",
                "oauth": "OAuth2 client credentials (requires client_id, client_secret, authorization_base_url, grant_type)",
            },
            "field_mapping": {
                "authorisation_id": "authorisationID - CRITICAL: Must be set on creation AND verified after. If null in response, update the function with {authorisation_id: '<id>'}",
                "authorisation_key": "Internal field set from authorisation_id on create, but does NOT populate the UI Authorisation dropdown",
                "code_execution_environment_id": "codeExecutionEnvironmentID",
                "is_mcp_server": "isMCPServer",
            },
            "workflow": [
                "1. Create authorisation → get authorisation_id",
                "2. Create function with authorisation_id AND authorisation_type",
                "3. Verify response: if authorisation_id is null, update the function with {authorisation_id: '<id>'}",
            ],
        },
        {
            "step": 5,
            "title": "Set static_args for widget context parameters (optional)",
            "description": "When an agent is embedded as a widget, the URL can include context parameters (e.g., ?tfCustomerId=<workspaceId>). Use static_args to inject these runtime-resolved values into API calls without the agent needing to provide them.",
            "static_args_pattern": {
                "description": "Map parameter names to context variable names. The platform auto-resolves them at runtime.",
                "example": {"workspaceId": "tfCustomerId", "limit": 500},
                "context_variables": {
                    "tfCustomerId": "The current workspace ID, auto-injected from the widget URL parameter. Use this for any workspace-scoped query instead of requiring the user to provide the workspace ID.",
                },
                "use_cases": [
                    "Workspace-scoped list queries (e.g., projectsByWorkspaceId) → static_args: {workspaceId: 'tfCustomerId', limit: 500}",
                    "Single entity by workspace ID (e.g., getWorkspace) → static_args: {id: 'tfCustomerId'}",
                    "Dynamic params (e.g., getProject by ID) → NO static_args, use parameter schema instead",
                ],
            },
        },
        {
            "step": 6,
            "title": "Post-creation update for GraphQL functions (REQUIRED for graphql_query/graphql_mutation)",
            "description": "CRITICAL: The create API does NOT accept graphql_query, graphql_mutation, or graphql_operation_name fields. For GraphQL functions, you MUST create the function first, then immediately update it with these fields.",
            "graphql_fields": {
                "graphql_query": "The full GraphQL query string including the operation declaration (e.g., 'query GetProject($id: ID!) { getProject(id: $id) { id name } }')",
                "graphql_mutation": "The GraphQL mutation string (for graphql_mutation request type). Set to empty string '' for queries.",
                "graphql_operation_name": "The operation name matching the query declaration (e.g., 'GetProject')",
            },
            "workflow": [
                "1. Create function with request_type='graphql_query', url, authorisation_type, etc.",
                "2. Get the function_id from the response",
                "3. Update the function with: {graphql_query: '...', graphql_operation_name: '...', graphql_mutation: ''}",
                "4. ALSO verify authorisation_id is set (if null, update with {authorisation_id: '<id>'})",
            ],
        },
    ],
    "examples": {
        "simple_get_function": {
            "description": "Simple GET function without authentication",
            "payload": {
                "name": "get_weather",
                "description": "Get current weather for a location",
                "url": "https://api.weather.com/current",
                "request_type": "get",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string", "description": "City name"},
                        "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]},
                    },
                    "required": ["location"],
                },
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "authenticated_post_function": {
            "description": "POST function with bearer auth (requires authorisation_id first)",
            "payload": {
                "name": "create_record",
                "description": "Create a new record in the database",
                "url": "https://api.example.com/records",
                "request_type": "post",
                "authorisation_id": "auth-123",
                "authorisation_type": "bearer",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "Record name"},
                        "value": {"type": "number", "description": "Record value"},
                    },
                    "required": ["name"],
                },
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "graphql_query_function": {
            "description": "GraphQL query function - REQUIRES two-step create+update flow",
            "step_1_create": {
                "description": "Step 1: Create the function with basic fields (graphql_query NOT available on create)",
                "payload": {
                    "name": "fetch_projects",
                    "description": "Fetch all projects in the current workspace. Call this at session start alongside fetch_clients, fetch_members, and fetch_cost_codes.",
                    "url": "https://api.example.com/graphql",
                    "request_type": "graphql_query",
                    "authorisation_type": "apikey",
                    "authorisation_id": "auth-abc-123",
                    "static_args": {"workspaceId": "tfCustomerId", "limit": 500},
                    "parameters": {"type": "object", "properties": {}},
                    "api_key": "YOUR_API_KEY",
                    "workspace_id": "YOUR_WORKSPACE_ID",
                },
            },
            "step_2_update": {
                "description": "Step 2: Update with GraphQL query fields + verify authorisation_id",
                "update_payload": {
                    "graphql_query": "query ProjectsByWorkspaceId($workspaceId: ID!, $limit: Int) { projectsByWorkspaceId(workspaceId: $workspaceId, limit: $limit) { items { id name status } } }",
                    "graphql_operation_name": "ProjectsByWorkspaceId",
                    "graphql_mutation": "",
                },
                "verify": "Check response.authorisation_id is not null. If null, also update with {authorisation_id: 'auth-abc-123'}",
            },
        },
        "graphql_dynamic_param_function": {
            "description": "GraphQL query with dynamic parameters (agent supplies IDs at runtime)",
            "step_1_create": {
                "payload": {
                    "name": "fetch_project",
                    "description": "Fetch full details for a single project by ID. Use after identifying the project ID from fetch_projects bootstrap data.",
                    "url": "https://api.example.com/graphql",
                    "request_type": "graphql_query",
                    "authorisation_type": "apikey",
                    "authorisation_id": "auth-abc-123",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string", "description": "The project ID"},
                        },
                        "required": ["id"],
                    },
                    "api_key": "YOUR_API_KEY",
                    "workspace_id": "YOUR_WORKSPACE_ID",
                },
            },
            "step_2_update": {
                "update_payload": {
                    "graphql_query": "query GetProject($id: ID!) { getProject(id: $id) { id name description status } }",
                    "graphql_operation_name": "GetProject",
                    "graphql_mutation": "",
                },
            },
            "note": "Dynamic-param functions have NO static_args. The agent resolves IDs from prior query results and passes them via the parameter schema.",
        },
    },
    "character_limits": {
        "description": "CRITICAL: Text fields have character limits enforced at API level",
        "fields": {
            "name": {"max": 64, "error": "Function name must not exceed 64 characters"},
            "description": {"max": 512, "error": "Description must not exceed 512 characters"},
            "custom_execution_code": {"max": 1024, "error": "Custom execution code must not exceed 1,024 characters"},
            "db_script": {"max": 255, "error": "Database script must not exceed 255 characters"},
            "html_script": {"max": 1024, "error": "HTML script must not exceed 1,024 characters"},
            "chat_script": {"max": 2048, "error": "Chat script must not exceed 2,048 characters"},
        },
    },
    "recovery_patterns": {
        "text_length_exceeded": {
            "description": "When API returns 'must not exceed X characters' error",
            "workflow": [
                "1. IDENTIFY: Parse error to find field name + character limit",
                "2. MEASURE: Count characters in the problematic field",
                "3. REDUCE: Apply compression strategy",
                "4. RETRY: Call create_toothfairy_function with reduced text",
            ],
            "compression_strategies": {
                "description": {
                    "limit": 512,
                    "strategy": "Focus on what the function does + when to use it",
                    "example": "'Fetches projects for workspace. Call at session start.' instead of detailed documentation",
                },
                "custom_execution_code": {
                    "limit": 1024,
                    "strategy": "Minify code, remove comments, use concise variable names",
                    "example": "result.json()['data'] instead of detailed parsing logic",
                },
                "db_script": {
                    "limit": 255,
                    "strategy": "Simplify query, remove formatting",
                    "example": "SELECT id,name FROM projects WHERE workspaceId=:wid instead of complex joins",
                },
            },
        },
    },
    "common_errors": {
        "deprecated_parameters_format": {
            "cause": "Using array format for parameters",
            "solution": "Use JSON Schema object format: {\"type\": \"object\", \"properties\": {...}, \"required\": [...]}",
        },
        "missing_authorisation": {
            "cause": "Function needs auth but no authorisation_id provided, OR authorisation_id is null after creation",
            "solution": "1. Create authorisation first. 2. Pass authorisation_id AND authorisation_type on function creation. 3. Verify response.authorisation_id is not null. 4. If null, update the function with {authorisation_id: '<id>'}",
        },
        "graphql_fields_on_create": {
            "cause": "Passing graphql_query, graphql_operation_name, or graphql_mutation on function creation",
            "solution": "These fields are NOT accepted by the create API. Create the function first, then update it with the GraphQL fields using the function_id from the response.",
        },
        "authorisation_dropdown_empty": {
            "cause": "The Authorisation dropdown in the UI shows empty even though auth was provided",
            "solution": "The create API maps authorisation_id to authorisation_key internally, but the UI reads authorisation_id separately. After creation, check if response.authorisation_id is null. If so, update the function with {authorisation_id: '<the-authorisation-id>'} to populate the UI dropdown.",
        },
        "missing_static_args_for_workspace_context": {
            "cause": "Agent asks the user for workspace ID when it should be auto-injected",
            "solution": "For workspace-scoped queries, use static_args with tfCustomerId context variable (e.g., static_args: {workspaceId: 'tfCustomerId'}). This auto-resolves to the current workspace ID from the widget URL.",
        },
        "functions_not_assigned_to_agent": {
            "cause": "Functions were created but the agent cannot see or use them — they are not in the agent's agent_functions array",
            "solution": "After creating functions, you MUST assign them to the agent by updating the agent with {agent_functions: [<id1>, <id2>, ...]}. Include ALL function IDs (existing + new) since the update replaces the entire array. Without this step, the agent has no access to the functions.",
        },
    },
    "patterns": {
        "multi_function_agent": {
            "description": "When building an agent with many functions sharing the same endpoint and auth, organize into tiers",
            "tiers": {
                "tier_1_bootstrap": {
                    "description": "Workspace-scoped list queries called at session start with static_args",
                    "pattern": "static_args: {workspaceId: 'tfCustomerId', limit: N}, parameters: {type: 'object', properties: {}}",
                    "example": "fetch_projects, fetch_clients, fetch_members",
                },
                "tier_2_project_scoped": {
                    "description": "Queries where the agent derives IDs from cached Tier 1 data",
                    "pattern": "No static_args, parameters: {type: 'object', properties: {projectId: {type: 'string'}}, required: ['projectId']}",
                    "example": "fetch_sheets_by_project, fetch_dockets_by_project",
                },
                "tier_3_entity_detail": {
                    "description": "Single entity lookups by ID from prior query results",
                    "pattern": "No static_args, parameters: {type: 'object', properties: {id: {type: 'string'}}, required: ['id']}",
                    "example": "fetch_project, fetch_docket, fetch_user",
                },
            },
        },
    },
}