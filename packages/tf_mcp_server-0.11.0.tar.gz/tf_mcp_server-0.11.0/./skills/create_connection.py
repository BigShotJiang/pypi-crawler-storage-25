"""Skill template for creating ToothFairyAI connections (hostings).

This skill guides AI assistants through connection creation for LLM providers.
"""

CREATE_CONNECTION_SKILL = {
    "name": "create-connection",
    "description": "Create a new LLM provider connection (Hosting)",
    "steps": [
        {
            "step": 1,
            "title": "Set required parameters",
            "required": ["name", "type", "api_key", "workspace_id"],
            "descriptions": {
                "name": "Connection name (alphanumeric and underscore only, max 64 chars)",
                "type": "Provider type from allowed list",
                "api_key": "ToothFairyAI API key",
                "workspace_id": "Workspace ID",
            },
        },
        {
            "step": 2,
            "title": "Choose connection type",
            "description": "Type determines required fields",
            "allowed_types": [
                "ollama",
                "groq",
                "together",
                "replicate",
                "aws",
                "anthropic",
                "azure_openai",
                "openai",
                "google",
                "local",
            ],
            "type_requirements": {
                "types_requiring_token_secret": [
                    "together",
                    "replicate",
                    "groq",
                    "anthropic",
                    "openai",
                    "google",
                    "azure_openai",
                ],
                "types_requiring_endpoint": ["local", "ollama", "azure_openai"],
                "types_requiring_model_name": ["local", "azure_openai"],
                "types_requiring_api_version": ["azure_openai"],
            },
        },
        {
            "step": 3,
            "title": "Set type-specific fields",
            "fields": {
                "token_secret": {
                    "type": "string",
                    "maxlength": 255,
                    "required_for": ["together", "replicate", "groq", "anthropic", "openai", "google", "azure_openai"],
                    "description": "API token/secret for the provider (maps to tokenSecret)",
                },
                "endpoint": {
                    "type": "string",
                    "maxlength": 255,
                    "required_for": ["local", "ollama", "azure_openai"],
                    "description": "API endpoint URL",
                },
                "model_name": {
                    "type": "string",
                    "maxlength": 255,
                    "required_for": ["local", "azure_openai"],
                    "description": "Model name to use (maps to modelName)",
                },
                "api_version": {
                    "type": "string",
                    "maxlength": 255,
                    "required_for": ["azure_openai"],
                    "description": "API version for Azure OpenAI (maps to apiVersion)",
                },
                "base_model": {
                    "type": "string",
                    "maxlength": 255,
                    "optional": True,
                    "description": "Base model identifier (maps to baseModel)",
                },
                "custom_model": {
                    "type": "boolean",
                    "optional": True,
                    "default": False,
                    "description": "Whether this is a custom model (maps to customModel)",
                },
                "description": {
                    "type": "string",
                    "maxlength": 255,
                    "optional": True,
                    "description": "Connection description",
                },
            },
        },
        {
            "step": 4,
            "title": "Build API payload",
            "description": "Connection maps to Hosting entity in GraphQL",
            "field_mappings": {
                "token_secret": "tokenSecret",
                "model_name": "modelName",
                "base_model": "baseModel",
                "custom_model": "customModel",
                "api_version": "apiVersion",
            },
            "api_endpoint": "/connection/create",
            "graphql_mutation": "createHosting",
        },
    ],
    "examples": {
        "openai_connection": {
            "description": "OpenAI API connection",
            "payload": {
                "name": "openai_prod",
                "type": "openai",
                "token_secret": "sk-...",
                "description": "Production OpenAI connection",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "azure_openai_connection": {
            "description": "Azure OpenAI connection (requires most fields)",
            "payload": {
                "name": "azure_gpt4",
                "type": "azure_openai",
                "endpoint": "https://your-resource.openai.azure.com/",
                "model_name": "gpt-4-deployment",
                "api_version": "2024-02-15-preview",
                "token_secret": "your-azure-key",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "ollama_local": {
            "description": "Local Ollama connection",
            "payload": {
                "name": "ollama_local",
                "type": "ollama",
                "endpoint": "http://localhost:11434",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "anthropic_connection": {
            "description": "Anthropic Claude connection",
            "payload": {
                "name": "anthropic_claude",
                "type": "anthropic",
                "token_secret": "sk-ant-...",
                "base_model": "claude-3-opus",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "google_connection": {
            "description": "Google Gemini connection",
            "payload": {
                "name": "google_gemini",
                "type": "google",
                "token_secret": "your-google-api-key",
                "base_model": "gemini-pro",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
    },
    "common_errors": {
        "invalid_name": {
            "cause": "Name contains invalid characters",
            "solution": "Use only alphanumeric characters and underscores (regex: ^[a-zA-Z0-9_]*$)",
        },
        "name_too_long": {
            "cause": "Name exceeds 64 characters",
            "solution": "Keep name under 64 characters",
        },
        "missing_token_secret": {
            "cause": "Provider type requires token_secret but not provided",
            "solution": "Add token_secret for providers like openai, anthropic, google, etc.",
        },
        "missing_endpoint": {
            "cause": "Provider type requires endpoint but not provided",
            "solution": "Add endpoint URL for local, ollama, or azure_openai",
        },
        "invalid_type": {
            "cause": "Type not in allowed list",
            "solution": "Use one of: ollama, groq, together, replicate, aws, anthropic, azure_openai, openai, google, local",
        },
    },
    "related_operations": {
        "list": {
            "tool": "list_toothfairy_connections",
            "description": "List all connections",
        },
        "get": {
            "tool": "get_toothfairy_connection",
            "params": ["connection_id"],
        },
        "update": {
            "tool": "update_toothfairy_connection",
            "params": ["connection_id", "fields to update"],
        },
        "delete": {
            "tool": "delete_toothfairy_connection",
            "params": ["connection_id"],
        },
    },
    "api_validation_schema": {
        "id": {"type": "string", "maxlength": 255, "auto_generated": True},
        "workspaceid": {"type": "string", "maxlength": 255, "from_token": True},
        "name": {"type": "string", "maxlength": 64, "regex": "^[a-zA-Z0-9_]*$", "required": True},
        "description": {"type": "string", "maxlength": 255, "nullable": True},
        "type": {"type": "string", "maxlength": 255, "required": True, "allowed": ["ollama", "groq", "together", "replicate", "aws", "anthropic", "azure_openai", "openai", "google", "local"]},
        "baseModel": {"type": "string", "maxlength": 255, "nullable": True},
        "customModel": {"type": "boolean", "nullable": True},
    },
}