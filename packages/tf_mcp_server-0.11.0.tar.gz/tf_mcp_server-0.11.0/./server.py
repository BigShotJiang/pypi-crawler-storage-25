"""Main MCP server for ToothFairyAI documentation.

This server exposes all ToothFairyAI SDK operations as MCP tools,
plus documentation and API search capabilities
"""

from typing import Optional

from fastmcp import FastMCP

from .config import config
from .resources.docs_loader import DocsLoader
from .resources.api_loader import ApiLoader
from .resources.release_notes_loader import ReleaseNotesLoader
from .resources.agent_guide import (
    get_agent_creation_guide as _get_guide,
    get_agent_creation_section,
)
from .tools.search import SearchTool
from .tools.mcp_tools import register_all_tools
from .skills import get_skill, list_skills

# Initialize the MCP server
# Note: For production with authentication, use a reverse proxy (nginx/traefik)
# with auth middleware, or configure OAuth via FastMCP's OAuthProvider
mcp = FastMCP(
    "ToothFairyAI Documentation",
    instructions="""
███████████████████████████████████████████████████████████████████████████████
MANDATORY RULE: ALWAYS CONSULT SKILLS BEFORE COMPLEX OPERATIONS
███████████████████████████████████████████████████████████████████████████████

BEFORE calling ANY create or update tool (agent, function, authorisation, etc.),
you MUST call get_toothfairy_skill() or recommend_skill_for_operation() FIRST.

Skills contain validation rules, character limits, two-step flows, and recovery
patterns that prevent API failures. IGNORING THIS WILL CAUSE ERRORS.

═══════════════════════════════════════════════════════════════════════════
QUICK START - NO AUTHENTICATION REQUIRED (20 tools)
═══════════════════════════════════════════════════════════════════════════

These tools work immediately without any API key:

DOCUMENTATION (10 tools):
- search_docs(query, limit): Search all documentation → Use first to find relevant info
- get_doc_by_topic(topic): Get full doc content by topic name
- get_agent_creation_guide(section): Comprehensive agent creation guide
  - Sections: modes, core-fields, mode-config, tools, features, departments, models, examples
- search_api_endpoints(query): Find API endpoints by keyword
- explain_api_domains(): Understand Platform API vs AI Services API vs Voice API
- list_doc_categories(): List available documentation categories
- get_api_spec(name): Get OpenAPI spec (platform, ai-services, voice)
- get_a2a_spec(): Get Agent-to-Agent protocol spec
- get_voice_spec(): Get Voice API spec

RELEASE NOTES (4 tools):
- list_release_notes(): List all release notes
- get_latest_release_notes(): Get most recent release notes
- get_release_notes(version): Get notes for specific version
- search_release_notes(query): Search release notes by keyword

PUBLIC ENDPOINTS (3 tools):
- fetch_toothfairy_announcement(): Get latest system announcement
- fetch_toothfairy_hireable_agents(): Browse agent templates for inspiration
- fetch_ai_models_list(): Get AI models and pricing info

SKILLS (2 tools):
- get_toothfairy_skill(skill_name): Get step-by-step guide for complex operations
- list_toothfairy_skills(): List all available skill guides
  - Available skills: create-agent, agent-interaction, document-workflow, create-function, etc.
  - Use agent-interaction skill for: messaging agents, file uploads, sync vs async dispatch

═══════════════════════════════════════════════════════════════════════════
MANDATORY SKILL CONSULTATION — ALWAYS CHECK THE SKILL BEFORE CREATING/UPDATING
═══════════════════════════════════════════════════════════════════════════

The following operations have associated skills that MUST be consulted FIRST.
They contain validation rules, character limits, two-step flows, and recovery patterns
that prevent common errors. Failing to consult the skill will cause API failures.

| Operation | Required Skill | Why |
|-----------|----------------|-----|
| Creating an agent | create-agent | Mode constraints, character limits, AT 2.0 config |
| Creating a function | create-function | JSON Schema format, auth two-step, GraphQL flow |
| Setting up authorisation | setup-authorisation | Two-step secret flow, OAuth tokenSecret rules |
| Creating a document | create-document | Upload types, folder organization |
| Creating a scheduled job | create-scheduled-job | Cron validation, frequency options |
| Creating a member | create-member | Role definitions |
| Creating a connection | create-connection | Provider-specific fields |
| Interacting with agents | agent-interaction | Sync vs async, file uploads |
| Document workflow | document-workflow | Upload/download lifecycle |

═══════════════════════════════════════════════════════════════════════════
SDK TOOLS - REQUIRE AUTHENTICATION (85 tools)
═══════════════════════════════════════════════════════════════════════════

Required parameters for all SDK tools: api_key, workspace_id, region (au/eu/us)
ALWAYS call validate_toothfairy_credentials FIRST to verify credentials!

AGENT MANAGEMENT (6 tools):
- validate_toothfairy_credentials → Call FIRST to verify API key works
- create_toothfairy_agent(label, mode, interpolation_string, goals, ...) → Create new agent
- get_toothfairy_agent(agent_id) → Get agent details
- update_toothfairy_agent(agent_id, ...) → Update agent fields
- delete_toothfairy_agent(agent_id) → Delete agent (IRREVERSIBLE)
- list_toothfairy_agents() → List all agents
- search_toothfairy_agents(search_term) → Search agents by label

AGENT FUNCTIONS/TOOLS (5 tools):
Functions are tools that agents can call (external APIs, databases, code execution):
- create_toothfairy_function(name, url, request_type, authorisation_type, ...)
- get_toothfairy_function(function_id)
- update_toothfairy_function(function_id, ...)
- delete_toothfairy_function(function_id) → IRREVERSIBLE
- list_toothfairy_functions()

AUTHORISATIONS (5 tools):
Store API credentials for function authentication:
- create_toothfairy_authorisation(type, ...) → Create auth config (oauth, bearer, apikey, basic)
- get_toothfairy_authorisation(auth_id)
- update_toothfairy_authorisation(auth_id, ...)
- delete_toothfairy_authorisation(auth_id) → IRREVERSIBLE
- list_toothfairy_authorisations()

SECRETS (2 tools):
Securely store sensitive values (tokens, passwords):
- create_toothfairy_secret(authorisation_id, token_secret) → Link to authorisation
- delete_toothfairy_secret(secret_id) → IRREVERSIBLE

DOCUMENTS/KNOWLEDGE BASE (6 tools):
- create_toothfairy_document(title, content, folder_id, ...)
- get_toothfairy_document(document_id)
- update_toothfairy_document(document_id, ...)
- delete_toothfairy_document(document_id) → IRREVERSIBLE
- list_toothfairy_documents()
- search_toothfairy_documents(search_text)

ENTITIES (6 tools):
Topics, intents, and named entities for NLP:
- create_toothfairy_entity(label, type, ...) → type: "topic", "intent", or "ner"
- get_toothfairy_entity(entity_id)
- update_toothfairy_entity(entity_id, ...)
- delete_toothfairy_entity(entity_id) → IRREVERSIBLE
- list_toothfairy_entities(type) → Filter by type
- search_toothfairy_entities(search_term)

FOLDERS (6 tools):
Organize documents in hierarchical structure:
- create_toothfairy_folder(name, parent_id, ...)
- get_toothfairy_folder(folder_id)
- update_toothfairy_folder(folder_id, ...)
- delete_toothfairy_folder(folder_id) → IRREVERSIBLE
- list_toothfairy_folders()
- get_toothfairy_folder_tree() → Get complete folder hierarchy

CHATS (5 tools):
Conversation sessions with agents:
- create_toothfairy_chat(agent_id, name, ...) → Create chat session
- get_toothfairy_chat(chat_id) → Get chat with all messages
- delete_toothfairy_chat(chat_id) → IRREVERSIBLE
- list_toothfairy_chats()
- send_toothfairy_message(chat_id, text, ...) → Send message and get agent response

PROMPTS (5 tools):
Reusable prompt templates:
- create_toothfairy_prompt(label, interpolation_string, ...)
- get_toothfairy_prompt(prompt_id)
- update_toothfairy_prompt(prompt_id, ...)
- delete_toothfairy_prompt(prompt_id) → IRREVERSIBLE
- list_toothfairy_prompts()

MEMBERS (4 tools):
Workspace user management:
- get_toothfairy_member(member_id)
- update_toothfairy_member(member_id, role, ...)
- delete_toothfairy_member(member_id) → IRREVERSIBLE
- list_toothfairy_members()

CHANNELS (5 tools):
Communication channels (SMS, WhatsApp, Email):
- create_toothfairy_channel(name, channel, provider, ...)
- get_toothfairy_channel(channel_id)
- update_toothfairy_channel(channel_id, ...)
- delete_toothfairy_channel(channel_id) → IRREVERSIBLE
- list_toothfairy_channels()

CONNECTIONS (3 tools):
Database connections for agent functions:
- get_toothfairy_connection(connection_id)
- delete_toothfairy_connection(connection_id) → IRREVERSIBLE
- list_toothfairy_connections()

BENCHMARKS (5 tools):
Test agent performance:
- create_toothfairy_benchmark(name, questions, ...)
- get_toothfairy_benchmark(benchmark_id)
- update_toothfairy_benchmark(benchmark_id, ...)
- delete_toothfairy_benchmark(benchmark_id) → IRREVERSIBLE
- list_toothfairy_benchmarks()

HOOKS (5 tools):
Custom code execution environments:
- create_toothfairy_hook(name, custom_execution_code, ...)
- get_toothfairy_hook(hook_id)
- update_toothfairy_hook(hook_id, ...)
- delete_toothfairy_hook(hook_id) → IRREVERSIBLE
- list_toothfairy_hooks()

SCHEDULED JOBS (5 tools):
Automated scheduled tasks:
- create_toothfairy_scheduled_job(name, agent_id, schedule, ...)
- get_toothfairy_scheduled_job(job_id)
- update_toothfairy_scheduled_job(job_id, ...)
- delete_toothfairy_scheduled_job(job_id) → IRREVERSIBLE
- list_toothfairy_scheduled_jobs()

SITES (4 tools):
Website crawling configuration:
- get_toothfairy_site(site_id)
- update_toothfairy_site(site_id, ...)
- delete_toothfairy_site(site_id) → IRREVERSIBLE
- list_toothfairy_sites()

DICTIONARY (2 tools):
Translation dictionary entries:
- get_toothfairy_dictionary_entry(entry_id)
- list_toothfairy_dictionary_entries()

REQUEST LOGS (2 tools):
API request history:
- get_toothfairy_request_log(log_id)
- list_toothfairy_request_logs()

SETTINGS (4 tools):
Workspace configuration:
- get_toothfairy_charting_settings()
- update_toothfairy_charting_settings(...)
- get_toothfairy_embeddings_settings()
- update_toothfairy_embeddings_settings(...)

BILLING (1 tool):
- get_toothfairy_month_costs() → Get monthly usage and costs

EMBEDDINGS (1 tool):
- create_toothfairy_embedding(text, ...) → Create text embeddings

═══════════════════════════════════════════════════════════════════════════
COMMON WORKFLOWS
═══════════════════════════════════════════════════════════════════════════

 WORKFLOW 1: Create a Basic Agent
 1. get_agent_creation_guide(section="examples") → Get example configurations
 2. validate_toothfairy_credentials(api_key, workspace_id, region) → Verify auth
 3. CRITICAL: Check character limits BEFORE creating agent:
    - label: max 50 chars
    - description: max 255 chars
    - interpolation_string: max 16,000 chars
    - goals: max 2,048 chars
    - pertinence_passage: max 512 chars
    - inhibition_passage: max 512 chars
    - custom_tooling_instructions: max 4,096 chars
 4. create_toothfairy_agent(label="My Agent", mode="chatter", interpolation_string="...", goals="...")
 5. create_toothfairy_chat(agent_id="new-agent-id", name="Test Chat")
 6. send_toothfairy_message(chat_id="...", text="Hello!")

WORKFLOW 2: Create Agent with External API Tool
1. create_toothfairy_authorisation(type="bearer", token_secret="api-key-123") → Store API credentials
2. create_toothfairy_function(
     name="Search API",
     url="https://api.example.com/search",
     request_type="GET",
     authorisation_type="bearer",
     authorisation_key="auth-id-from-step-1",
     parameters={"type": "object", "properties": {"query": {"type": "string"}}}
   )
3. create_toothfairy_agent(label="Search Agent", mode="retriever", agent_functions=["function-id"], ...)
4. Test with chat + send_toothfairy_message

WORKFLOW 3: Add Knowledge to Agent
1. create_toothfairy_folder(name="Product Docs")
2. create_toothfairy_document(title="Product Guide", content="# Product Guide\\n...", folder_id="...")
3. update_toothfairy_agent(agent_id, static_docs=["doc-id"]) → Always include this doc

WORKFLOW 4: Agent with Database Access
1. Create connection in ToothFairyAI Admin UI first
2. list_toothfairy_connections() → Get connection_id
3. create_toothfairy_function(
     name="Query Database",
     url="db://connection-id",
     request_type="custom",
     is_database_script=True,
     db_connection_id="connection-id",
     db_script="SELECT * FROM products WHERE name LIKE :name"
   )
4. create_toothfairy_agent with this function

WORKFLOW 5: Voice Agent
1. get_agent_creation_guide(section="voice") → Get voice-specific config
2. create_toothfairy_agent(
     label="Voice Assistant",
     mode="voice",
     voice_name="alloy",
     interpolation_string="You are a helpful voice assistant...",
     enable_inbound_sip=True
   )

WORKFLOW 6: Planner Agent (Multi-Agent Orchestration)
1. Create multiple specialist agents first (retriever, coder, etc.)
2. create_toothfairy_agent(
     label="Orchestrator",
     mode="planner",
     agents_pool=["agent-1-id", "agent-2-id"],
     max_planning_steps=10,
     planning_instructions="Break down complex tasks and delegate to specialists"
   )

═══════════════════════════════════════════════════════════════════════════
AGENT MODES & WHEN TO USE
═══════════════════════════════════════════════════════════════════════════

| Mode | Best For | Key Features |
|------|----------|--------------|
| chatter | General conversation, creative tasks | No knowledge base, uses LLM knowledge |
| retriever | Knowledge base Q&A | RAG, document retrieval, citations |
| coder | Code execution, data analysis | Python execution, has_code=True |
| planner | Multi-agent orchestration | Agents pool, task decomposition |
| computer | Browser/desktop automation | Virtual desktop, browser control |
| voice | Real-time voice conversations | SIP, speech-to-text, text-to-speech |

═══════════════════════════════════════════════════════════════════════════
AUTHORISATION TYPES FOR FUNCTIONS
═══════════════════════════════════════════════════════════════════════════

| Type | Use Case | Required Fields |
|------|----------|-----------------|
| oauth | OAuth2 client credentials | client_id, client_secret, authorization_base_url, grant_type |
| bearer | Static bearer token | token_secret (via create_toothfairy_secret) |
| apikey | API key in header | token_secret |
| basic | HTTP Basic auth | username, password |
| none | No authentication | None |

═══════════════════════════════════════════════════════════════════════════
FUNCTION PARAMETERS FORMAT (JSON Schema)
═══════════════════════════════════════════════════════════════════════════

Always use JSON Schema format for function parameters:
{
  "type": "object",
  "properties": {
    "query": {"type": "string", "description": "Search query"},
    "limit": {"type": "integer", "description": "Max results", "default": 10}
  },
  "required": ["query"]
}

═══════════════════════════════════════════════════════════════════════════
REGIONS
═══════════════════════════════════════════════════════════════════════════

Use region="au" (default, Australia), "eu" (Europe), or "us" (United States).
Each region has separate API endpoints and data residency.

═══════════════════════════════════════════════════════════════════════════
CRITICAL PATTERN: TEXT FIELD LENGTH MANAGEMENT & RECOVERY
═══════════════════════════════════════════════════════════════════════════

ALL ToothFairyAI entities (agents, functions, hooks, documents, prompts) have 
character limits on text fields. These limits are ENFORCED at the API level.

COMMON ERROR PATTERN:
- Error message contains "maxlength" or "must not exceed X characters"
- Example: "interpolationString must not exceed 16000 characters"

RECOVERY STRATEGY:
When a create/update operation fails with a character limit error:

1. IDENTIFY the field and its limit from the error message
2. MEASURE current text length
3. REDUCE text content using one of these strategies:
   - TRUNCATE: Cut text to fit (useful for descriptions)
   - SUMMARIZE: Compress to essential points (useful for instructions)
   - PRIORITIZE: Keep most important sections (useful for goals)
   - REFERENCE: Link to external docs instead of embedding full text
4. RETRY the operation with reduced text

APPLIES TO ALL ENTITIES:

AGENTS:
- label: 50 chars
- description: 255 chars
- interpolationString: 16,000 chars
- goals: 2,048 chars
- pertinencePassage: 512 chars
- inhibitionPassage: 512 chars
- customToolingInstructions: 4,096 chars
- ragInstructions: 4,096 chars
- planningInstructions: 4,096 chars
- reviewInstructions: 2,048 chars
- voiceInstructions: 4,096 chars

FUNCTIONS:
- name: 64 chars
- description: 512 chars
- customExecutionCode: 1,024 chars (for API functions)
- dbScript: 255 chars
- htmlScript: 1,024 chars
- chatScript: 2,048 chars

HOOKS:
- customExecutionCode: varies (check API)
- customExecutionInstructions: varies

PROMPTS:
- interpolationString: minimum 128 chars required

DOCUMENTS:
- title: 255 chars (typical)
- rawtext: larger limit but still enforced

PREVENTION PATTERN:
Before creating/updating ANY entity:
1. Consult the relevant skill/guide for character limits
2. Measure text length BEFORE API call
3. Proactively reduce if approaching limit
4. For large content: use documents + agent references instead of embedding

EXAMPLE RECOVERY FLOW:
```
User: Create agent with 20,000 char instructions
Agent: [Calls create_toothfairy_agent]
Error: "interpolationString must not exceed 16000 characters"
Agent: 
  1. Identifies: interpolationString, limit 16,000
  2. Measures: 20,000 chars
  3. Reduces: Summarizes to 15,500 chars keeping core instructions
  4. Retries: [Calls create_toothfairy_agent with reduced text]
Success: Agent created
```

═══════════════════════════════════════════════════════════════════════════
PRO TIPS
═══════════════════════════════════════════════════════════════════════════

1. ALWAYS use get_agent_creation_guide() before creating agents - it has examples for each mode
2. Use search_docs() first to find relevant documentation
3. Test agents with create_toothfairy_chat + send_toothfairy_message
4. Use static_docs to always include specific documents in agent context
5. Enable use_interleaved_reasoning=True for agents with tools/internet_search/code (agenticRAG MUST be False, model MUST be interleaved-capable, reasoning_mode='always')
6. Use allow_internet_search=True for agents that need current information
7. For OAuth functions: create authorisation FIRST, then reference it in function
8. Monitor costs with get_toothfairy_month_costs()
9. Use benchmarks to test agent quality before deployment
10. Check release notes for latest features and changes""",
)

# Initialize loaders
docs_loader = DocsLoader(config.docs_path)
api_loader = ApiLoader(config.api_docs_path)
# Release notes are in docs/tf_docs/release-notes (sibling to docs/)
release_notes_path = config.docs_path.parent / "release-notes"
release_notes_loader = ReleaseNotesLoader(release_notes_path)
search_tool = SearchTool(docs_loader, api_loader)

# Ensure docs are loaded at startup
docs_loader.load()
api_loader.load()
release_notes_loader.load()

# Register all SDK-based tools (~88 tools)
register_all_tools(mcp)


# ============================================================================
# Resources - Documentation
# ============================================================================


@mcp.resource("toothfairy://docs/list")
def list_all_docs() -> str:
    """List all available documentation pages."""
    docs = docs_loader.list_docs()
    lines = ["# ToothFairyAI Documentation\n"]
    lines.append(f"Total documents: {len(docs)}\n")

    # Group by category
    by_category = {}
    for doc in docs:
        cat = doc["category"]
        if cat not in by_category:
            by_category[cat] = []
        by_category[cat].append(doc)

    for category in sorted(by_category.keys()):
        lines.append(f"\n## {category.title()}\n")
        for doc in by_category[category]:
            lines.append(f"- [{doc['title']}]({doc['uri']})")
            if doc["description"]:
                lines.append(f"  - {doc['description'][:100]}...")

    return "\n".join(lines)


@mcp.resource("toothfairy://docs/{category}/{slug}")
def get_doc(category: str, slug: str) -> str:
    """
    Get a specific documentation page by category and slug.

    Args:
        category: The documentation category (e.g., "agents", "settings")
        slug: The document slug (e.g., "agents", "prompting")

    Returns:
        The markdown content of the documentation page
    """
    doc = docs_loader.get_doc(category, slug)
    if doc is None:
        return f"# Document Not Found\n\nNo document found for category='{category}', slug='{slug}'\n\nUse `toothfairy://docs/list` to see available documents."

    # Return content with metadata header
    header = f"# {doc.title}\n\n"
    if doc.description:
        header += f"> {doc.description}\n\n"
    header += f"**Category:** {doc.category} | **URI:** `{doc.uri}`\n\n---\n\n"

    return header + doc.content


# ============================================================================
# Resources - API Specifications
# ============================================================================


@mcp.resource("toothfairy://api/list")
def list_api_specs() -> str:
    """List all available API specifications."""
    specs = api_loader.list_specs()
    lines = ["# ToothFairyAI API Specifications\n"]
    lines.append(f"Total specs: {len(specs)}\n")

    lines.append("## IMPORTANT: API Domain Distinction")
    lines.append("ToothFairyAI has multiple API domains serving different purposes:")
    lines.append(
        "- **Platform API** (`api.{region}.toothfairyai.com`): Agent management & platform operations (create, update, delete agents, functions, entities, chat management)"
    )
    lines.append(
        "- **AI Services API** (`ai.{region}.toothfairyai.com`): AI operations (agent interaction, planning, search, tokenization, embeddings, model listing)"
    )
    lines.append(
        "- **Voice API** (`voice.{region}.toothfairyai.com`): Voice-specific operations"
    )
    lines.append("\nAlways use the correct domain for each type of operation!\n")

    # Group by API type
    by_type = {}
    for spec in specs:
        api_type = spec.get("api_type", "unknown")
        if api_type not in by_type:
            by_type[api_type] = []
        by_type[api_type].append(spec)

    # Display in order: platform, ai-services, voice, unknown
    display_order = ["platform", "ai-services", "voice", "unknown"]
    for api_type in display_order:
        if api_type in by_type:
            type_display = {
                "platform": "Platform API",
                "ai-services": "AI Services API",
                "voice": "Voice API",
                "unknown": "Other APIs",
            }.get(api_type, api_type)

            lines.append(f"\n## {type_display}")
            lines.append(
                f"**Base Domain:** `{by_type[api_type][0].get('base_domain', 'unknown')}`"
            )

            for spec in by_type[api_type]:
                lines.append(f"\n### {spec['title']} (v{spec['version']})")
                lines.append(f"- URI: `{spec['uri']}`")
                if spec["description"]:
                    lines.append(f"- {spec['description'][:200]}...")

    return "\n".join(lines)


@mcp.resource("toothfairy://api/{name}")
def get_api_spec(name: str) -> str:
    """
    Get an OpenAPI specification by name.

    Args:
        name: The spec name ("platform", "ai-services", or "voice")

    Returns:
        The OpenAPI spec as JSON string
    """
    spec = api_loader.get_spec(name)
    if spec is None:
        available = [s.name for s in api_loader.get_all_specs()]
        return f"# API Spec Not Found\n\nNo spec found for name='{name}'\n\nAvailable specs: {', '.join(available)}"

    return spec.raw_content


@mcp.resource("toothfairy://api/{name}/endpoints")
def get_api_endpoints(name: str) -> str:
    """
    Get a summary of all endpoints in an API spec.

    Args:
        name: The spec name ("platform", "ai-services", or "voice")

    Returns:
        Markdown summary of all endpoints
    """
    spec = api_loader.get_spec(name)
    if spec is None:
        return f"# API Spec Not Found\n\nNo spec found for name='{name}'"

    endpoints = spec.get_endpoints_summary()
    lines = [f"# {spec.title} - Endpoints\n"]

    # Add API type and domain info
    api_type_display = {
        "platform": "Platform API",
        "ai-services": "AI Services API",
        "voice": "Voice API",
    }.get(spec.api_type, "API")

    lines.append(f"**API Type:** {api_type_display}")
    lines.append(f"**Base Domain:** `{spec.base_domain}`")
    lines.append(f"**Total endpoints:** {len(endpoints)}\n")

    lines.append("## Endpoint Usage Notes")
    lines.append(f"- Use `{spec.base_domain}` as the base URL for all endpoints below")
    lines.append(
        "- Replace `{region}` with your region (au, eu, us) or omit for default region"
    )
    lines.append(
        "- Example: `https://"
        + spec.base_domain.replace("{region}.", "")
        + "{endpoint_path}`\n"
    )

    # Group by tag
    by_tag = {}
    for ep in endpoints:
        tags = ep.get("tags", ["Other"])
        for tag in tags:
            if tag not in by_tag:
                by_tag[tag] = []
            by_tag[tag].append(ep)

    for tag in sorted(by_tag.keys()):
        lines.append(f"\n## {tag}\n")
        for ep in by_tag[tag]:
            lines.append(f"- **{ep['method']}** `{ep['path']}`")
            lines.append(f"  - **Full URL:** `{ep.get('full_url', 'N/A')}`")
            if ep["summary"]:
                lines.append(f"  - **Summary:** {ep['summary']}")

    return "\n".join(lines)


@mcp.resource("toothfairy://api/integration-guide")
def get_integration_guide() -> str:
    """Get the Voice API integration guide."""
    guide = api_loader.get_integration_guide()
    if guide is None:
        return (
            "# Integration Guide Not Found\n\nThe integration guide is not available."
        )
    return guide


# ============================================================================
# Documentation Tools
# ============================================================================


@mcp.tool()
def search_docs(
    query: str,
    limit: int = 10,
    source: Optional[str] = None,
) -> list[dict]:
    """
    Search across all ToothFairyAI documentation.

    Args:
        query: The search query string
        limit: Maximum number of results (default: 10)
        source: Filter by source type ("docs" for markdown docs, "api" for API specs, or None for all)

    Returns:
        List of search results with title, uri, snippet, and relevance score
    """
    return search_tool.search(query, limit=limit, source_filter=source)


@mcp.tool()
def search_api_endpoints(query: str, limit: int = 20) -> list[dict]:
    """
    Search for specific API endpoints.

    Args:
        query: Search query (matches path, summary, description, or tags)
        limit: Maximum number of results (default: 20)

    Returns:
        List of matching endpoints with method, path, summary, tags, and API type info
    """
    endpoints = search_tool.search_endpoints(query, limit=limit)

    # Enhance the results with API type information
    enhanced_results = []
    for endpoint in endpoints:
        # Add API type display name
        api_type = endpoint.get("api_type", "unknown")
        api_type_display = {
            "platform": "Platform API",
            "ai-services": "AI Services API",
            "voice": "Voice API",
        }.get(api_type, "API")

        enhanced_endpoint = endpoint.copy()
        enhanced_endpoint["api_type_display"] = api_type_display
        enhanced_endpoint["base_domain"] = endpoint.get("base_domain", "unknown")

        # Add usage note
        enhanced_endpoint["usage_note"] = (
            f"Use {api_type_display} domain: {endpoint.get('base_domain', 'unknown')}"
        )

        enhanced_results.append(enhanced_endpoint)

    return enhanced_results


@mcp.tool()
def explain_api_domains() -> str:
    """
    Explain the different ToothFairyAI API domains and when to use each.

    Returns:
        Detailed explanation of API domain distinctions with examples
    """
    return """# ToothFairyAI API Domain Distinction Guide

## CRITICAL: Use the Correct Domain for Each Operation

ToothFairyAI has multiple API domains that serve different purposes. Using the wrong domain will result in errors or incorrect behavior.

## API Domains Overview

| API Type | Base Domain | Purpose | Example Operations |
|----------|-------------|---------|-------------------|
| **Platform API** | `api.{region}.toothfairyai.com` | Agent management & platform operations | Create/update/delete agents, functions, entities, chat management |
| **AI Services API** | `ai.{region}.toothfairyai.com` | AI operations & agent interaction | Chat with agents, planning, search, tokenization, embeddings, model listing |
| **Voice API** | `voice.{region}.toothfairyai.com` | Voice-specific operations | Voice calls, speech-to-text, text-to-speech |

## How to Identify Which API to Use

### 1. Check the OpenAPI Specification
- **Platform API** (`openapi.json`): Contains agent management endpoints (create, update, delete, list)
- **AI Services API** (`aiopenapi.json`): Contains AI operations endpoints (chat, planning, search, tokenization, embeddings)
- **Voice API** (`voiceapi.json`): Contains voice-specific endpoints

### 2. Look at the Endpoint Path
- **AI operations**: `/agent` (chat), `/planner`, `/searcher`, `/tokenizer`, `/embedder` -> Use **AI Services API**
- **Public endpoints** (no auth required): `/models_list` (AI Services), `/global_utils/fetch_hireable_agents`, `/global_utils/fetch_announcement` (Platform API)
- **Agent management**: `/agent/create`, `/agent/update/{id}`, `/agent/delete/{id}`, `/agent/list` -> Use **Platform API**
- **Voice operations**: `/voice/call`, `/transcribe` -> Use **Voice API**

### 3. Key Distinction
- **Platform API**: **MANAGING** agents and platform resources (CRUD operations)
- **AI Services API**: **USING AI** services (chat, search, tokenization, embeddings)
- **Voice API**: **VOICE** operations

## Examples

### Correct: Agent Chat (AI Service)
```bash
POST https://ai.toothfairyai.com/agent
Content-Type: application/json
{
  "workspaceid": "your-workspace-id",
  "agentid": "agent-uuid",
  "messages": [{"role": "user", "content": "Hello"}]
}
```

### Correct: Create Agent (Management)
```bash
POST https://api.toothfairyai.com/agent/create
Content-Type: application/json
{
  "workspaceID": "your-workspace-id",
  "label": "Research Assistant",
  "mode": "retriever",
  "interpolationString": "You are a research assistant..."
}
```

## Tool Integration

When using the MCP server tools:
- **Agent management operations** (`create_toothfairy_agent`, `list_toothfairy_agents`): Use Platform API domain internally
- **AI service operations**: Would use AI Services API domain
- **Always check** the `api_type` field in search results to know which domain to use

## Pro Tips
1. **Check the spec name** - `platform` = Platform API, `ai-services` = AI Services API, `voice` = Voice API
2. **Use `search_api_endpoints`** - It now includes `api_type_display` to show which API to use
3. **Regional domains** - Replace `{region}` with `au`, `eu`, or `us` (or omit for default)
4. **Remember**: Platform API manages resources, AI Services API provides AI capabilities

Remember: **Wrong domain = API errors**. Always verify you're using the correct API type!
"""


@mcp.tool()
def list_doc_categories() -> list[str]:
    """
    List all documentation categories.

    Returns:
        List of category names (e.g., ["agents", "settings", "guides"])
    """
    return search_tool.list_categories()


@mcp.tool()
def get_doc_by_topic(topic: str) -> str:
    """
    Get documentation for a specific topic.

    This is a convenience tool that searches for the topic and returns
    the most relevant document's full content.

    Args:
        topic: The topic to find (e.g., "agents", "prompting", "channels")

    Returns:
        The full markdown content of the most relevant document
    """
    results = search_tool.search(topic, limit=1, source_filter="docs")
    if not results:
        return f"No documentation found for topic: {topic}"

    # Get the full document
    uri = results[0]["uri"]
    # Parse uri: toothfairy://docs/{category}/{slug}
    parts = uri.replace("toothfairy://docs/", "").split("/")
    if len(parts) >= 2:
        category, slug = parts[0], parts[1]
        # Use docs_loader directly instead of the decorated resource function
        doc = docs_loader.get_doc(category, slug)
        if doc is None:
            return f"No document found for category='{category}', slug='{slug}'"

        # Return content with metadata header (same format as get_doc resource)
        header = f"# {doc.title}\n\n"
        if doc.description:
            header += f"> {doc.description}\n\n"
        header += f"**Category:** {doc.category} | **URI:** `{doc.uri}`\n\n---\n\n"
        return header + doc.content

    return f"Could not retrieve document for: {topic}"


@mcp.tool()
def get_agent_creation_guide(section: Optional[str] = None) -> str:
    """
    Get the comprehensive guide for creating ToothFairyAI agents.

    This guide covers all aspects of agent creation including:
    - Agent modes (chatter, retriever, coder, planner, voice)
    - Core fields and configuration
    - Tools system and customToolingInstructions
    - Feature flags and rules
    - Model configuration
    - Complete examples for each agent type

    Args:
        section: Optional section to retrieve. If not provided, returns the full guide.
                 Available sections: modes, core-fields, mode-config, tools, features,
                 departments, models, uploads, voice, planner, validation,
                 best-practices, examples, quick-reference

    Returns:
        The agent creation guide content (full or specific section)
    """
    if section:
        return get_agent_creation_section(section)
    return _get_guide()


# ============================================================================
# Release Notes Tools
# ============================================================================


@mcp.tool()
def list_release_notes() -> list[dict]:
    """
    List all available ToothFairyAI release notes.

    Returns a list of all release notes sorted by version (newest first),
    including version number, release date, title, and summary.

    Returns:
        List of release notes with version, release_date, title, summary, and uri
    """
    return release_notes_loader.list_notes()


@mcp.tool()
def get_latest_release_notes() -> str:
    """
    Get the most recent ToothFairyAI release notes.

    Returns the full content of the latest release notes including
    all new features, improvements, and fixes.

    Returns:
        The full markdown content of the latest release notes
    """
    note = release_notes_loader.get_latest()
    if note is None:
        return "No release notes found."

    header = f"# {note.title}\n\n"
    header += f"**Version:** {note.version} | **Released:** {note.release_date}\n\n"
    header += f"**URI:** `{note.uri}`\n\n---\n\n"

    return header + note.content


@mcp.tool()
def get_release_notes(version: str) -> str:
    """
    Get release notes for a specific version.

    Args:
        version: The version number to retrieve (e.g., "0.668.0", "v0.668.0", or "0.668")

    Returns:
        The full markdown content of the release notes for that version
    """
    note = release_notes_loader.get_note(version)
    if note is None:
        available = [n.version for n in release_notes_loader.get_all_notes()[:5]]
        return (
            f"No release notes found for version: {version}\n\n"
            f"Recent versions available: {', '.join(available)}\n\n"
            "Use `list_release_notes()` to see all available versions."
        )

    header = f"# {note.title}\n\n"
    header += f"**Version:** {note.version} | **Released:** {note.release_date}\n\n"
    header += f"**URI:** `{note.uri}`\n\n---\n\n"

    return header + note.content


@mcp.tool()
def search_release_notes(query: str, limit: int = 10) -> list[dict]:
    """
    Search release notes by keyword or phrase.

    Search across all release notes to find features, fixes, or changes
    mentioning the specified terms.

    Args:
        query: Search query (e.g., "voice agents", "MCP", "agentic tooling")
        limit: Maximum number of results (default: 10)

    Returns:
        List of matching release notes with version, title, snippet, and relevance score
    """
    return release_notes_loader.search(query, limit=limit)


# ============================================================================
# Skill Tools
# ============================================================================


@mcp.tool()
def get_toothfairy_skill(skill_name: str) -> dict:
    """
    Get a skill template for a ToothFairyAI operation.

    Skills provide step-by-step guidance with validation rules and example payloads.

    Args:
        skill_name: Name of the skill (e.g., "create-agent", "agent-interaction")

    Returns:
        Skill template with steps, validation rules, and examples
    """
    skill = get_skill(skill_name)
    if skill is None:
        available = list_skills()
        return {
            "success": False,
            "error": f"Skill not found: {skill_name}",
            "available_skills": available,
        }
    return {"success": True, "skill": skill}


@mcp.tool()
def list_toothfairy_skills() -> list[str]:
    """
    List all available skill templates.

    Skills provide step-by-step guidance for common ToothFairyAI operations.

    Returns:
        List of available skill names
    """
    return list_skills()


@mcp.tool()
def recommend_skill_for_operation(operation: str) -> dict:
    """
    Recommend the relevant skill for a given operation and highlight critical gotchas.

    Use this BEFORE calling create/update tools to avoid validation errors.

    Args:
        operation: Description of the intended operation (e.g., "create agent", "setup OAuth", "upload document")

    Returns:
        Dict with recommended skill name, critical warnings, and quick-start guidance
    """
    operation_lower = operation.lower()

    recommendations = {
        "agent": {
            "skill": "create-agent",
            "critical_warnings": [
                "mode='coder' requires has_code=True and forbids agentic_rag",
                "mode='voice' forbids agentic_rag (latency-sensitive)",
                "Character limits: label(50), interpolation_string(16000), goals(2048)",
                "AT 2.0: useInterleavedReasoning=True requires reasoning_mode='always' and agentic_rag=False",
            ],
        },
        "function": {
            "skill": "create-function",
            "critical_warnings": [
                "Parameters MUST be JSON Schema object format, NOT array format",
                "GraphQL functions require two-step: create first, then update with graphql_query",
                "After creation, VERIFY response.authorisation_id is not null; if null, update function with authorisation_id",
                "Use static_args with tfCustomerId for workspace-scoped queries",
            ],
        },
        "authorisation": {
            "skill": "setup-authorisation",
            "critical_warnings": [
                "ALWAYS use two-step flow: create authorisation without secrets, then create_secret with password_secret_value",
                "OAuth authorization_code grant_type requires token_secret (refresh token)",
                "OAuth client_credentials grant_type does NOT need token_secret",
            ],
        },
        "document": {
            "skill": "create-document",
            "critical_warnings": [
                "Valid doc_types: readComprehensionUrl, readComprehensionPdf, readComprehensionFile",
                "Default folder_id is 'mrcRoot'",
            ],
        },
        "scheduled_job": {
            "skill": "create-scheduled-job",
            "critical_warnings": [
                "frequency options: MINUTES, HOURLY, DAILY, WEEKLY, MONTHLY, YEARLY, CUSTOM",
                "CUSTOM frequency requires a valid cron_expression",
            ],
        },
        "member": {
            "skill": "create-member",
            "critical_warnings": [
                "role options: admin, member, viewer",
                "status options: active, inactive",
            ],
        },
        "connection": {
            "skill": "create-connection",
            "critical_warnings": [
                "type options: azure_openai, aws, local, google, anthropic, together, tf, replicate, azure, openai, groq, ollama",
                "token_secret required for most types except local, aws, ollama",
            ],
        },
        "agent_interaction": {
            "skill": "agent-interaction",
            "critical_warnings": [
                "Sync vs async dispatch modes",
                "File upload size limits and formats",
            ],
        },
        "document_workflow": {
            "skill": "document-workflow",
            "critical_warnings": [
                "Upload → process → publish lifecycle",
                "Supported file types and size limits",
            ],
        },
    }

    # Match operation to recommendation
    matched = None
    for key, rec in recommendations.items():
        if key in operation_lower or key.replace("_", " ") in operation_lower:
            matched = rec
            break

    if matched is None:
        return {
            "success": False,
            "message": f"No specific skill recommendation for '{operation}'",
            "suggestion": "Use list_toothfairy_skills() to see all available skills, or describe your operation with keywords like: agent, function, authorisation, document, scheduled_job, member, connection",
            "available_skills": list_skills(),
        }

    return {
        "success": True,
        "operation": operation,
        "recommended_skill": matched["skill"],
        "critical_warnings": matched["critical_warnings"],
        "next_step": f"Call get_toothfairy_skill('{matched['skill']}') for full step-by-step guidance",
    }


# ============================================================================
# Prompts (Templates)
# ============================================================================


@mcp.prompt()
def api_usage_guide(endpoint: str) -> str:
    """
    Generate a guide for using a specific API endpoint.

    Args:
        endpoint: The API endpoint path (e.g., "/chatter", "/agent/update")
    """
    return f"""Please help me understand how to use the ToothFairyAI API endpoint: {endpoint}

Search for this endpoint in the API documentation and provide:
1. The HTTP method and full path
2. Required authentication
3. Request parameters/body
4. Response format
5. Example usage

Use the search_api_endpoints and get_api_spec tools to find the information."""


@mcp.prompt()
def feature_guide(feature: str) -> str:
    """
    Generate a guide for a ToothFairyAI feature.

    Args:
        feature: The feature name (e.g., "agents", "knowledge hub", "channels")
    """
    return f"""Please help me understand the ToothFairyAI feature: {feature}

Search the documentation and provide:
1. What this feature does
2. How to configure it
3. Best practices
4. Related features

Use the search_docs and get_doc_by_topic tools to find the information."""


@mcp.prompt()
def create_agent(agent_type: str, use_case: str) -> str:
    """
    Generate configuration for a ToothFairyAI agent.

    Args:
        agent_type: Type of agent (e.g., "chatter", "retriever", "voice", "planner")
        use_case: Description of the agent's intended purpose
    """
    return f"""Please help me create a ToothFairyAI agent configuration.

Agent type: {agent_type}
Use case: {use_case}

Use the get_agent_creation_guide tool to:
1. Get the appropriate mode configuration for this agent type
2. Select the right model and temperature settings
3. Configure the appropriate tools and features
4. Write effective interpolationString (system prompt)
5. Write customToolingInstructions for the enabled tools
6. Set proper upload permissions based on the use case

Provide a complete, valid agent configuration object following the guide's best practices."""


# ============================================================================
# Custom HTTP Routes
# ============================================================================


@mcp.custom_route("/health", methods=["GET"])
async def health_check(request):
    """Health check endpoint for load balancers and monitoring."""
    from starlette.responses import JSONResponse

    return JSONResponse(
        {
            "status": "healthy",
            "server": "ToothFairyAI Documentation MCP",
            "docs_loaded": len(docs_loader.get_all_docs()),
            "api_specs_loaded": len(api_loader.get_all_specs()),
        }
    )


@mcp.custom_route("/info", methods=["GET"])
async def server_info(request):
    """Server information endpoint."""
    from starlette.responses import JSONResponse

    return JSONResponse(
        {
            "name": "ToothFairyAI MCP Server",
            "version": "0.11.0",
            "documentation": {
                "total_docs": len(docs_loader.get_all_docs()),
                "categories": docs_loader.get_categories(),
            },
            "release_notes": {
                "total": len(release_notes_loader.get_all_notes()),
                "latest_version": (
                    release_notes_loader.get_latest().version
                    if release_notes_loader.get_latest()
                    else None
                ),
            },
            "api_specs": [
                {"name": spec.name, "title": spec.title, "version": spec.version}
                for spec in api_loader.get_all_specs()
            ],
            "endpoints": {
                "sse": "/sse",
                "health": "/health",
                "info": "/info",
            },
            "tools": {
                "documentation": 13,
                "release_notes": 4,
                "public_utils": 3,
                "sdk": 85,
                "total": 105,
            },
        }
    )


# ============================================================================
# Main Entry Point
# ============================================================================


def main():
    """Run the MCP server."""
    import sys
    import uvicorn
    from starlette.middleware import Middleware

    # Check for --stdio flag to override config
    use_stdio = "--stdio" in sys.argv or config.transport == "stdio"

    # SSE resumability settings
    # FastMCP already has built-in 15-second pings to keep connections alive
    # For additional reliability with long-running operations, we enable resumability
    # This allows clients to reconnect and resume if disconnected
    enable_resumability = True

    print("=" * 60, file=sys.stderr)
    print("ToothFairyAI Documentation MCP Server", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    print(f"Transport: {'stdio' if use_stdio else 'sse'}", file=sys.stderr)
    if not use_stdio:
        print(f"Host: {config.host}", file=sys.stderr)
        print(f"Port: {config.port}", file=sys.stderr)
    print(file=sys.stderr)
    print(f"Docs path: {config.docs_path}", file=sys.stderr)
    print(f"API docs path: {config.api_docs_path}", file=sys.stderr)
    print(file=sys.stderr)
    print(
        f"Loaded {len(docs_loader.get_all_docs())} documentation pages", file=sys.stderr
    )
    print(
        f"Loaded {len(api_loader.get_all_specs())} API specifications", file=sys.stderr
    )
    print(
        f"Loaded {len(release_notes_loader.get_all_notes())} release notes",
        file=sys.stderr,
    )
    print(file=sys.stderr)
    if not use_stdio:
        print("Endpoints:", file=sys.stderr)
        print(f"  - SSE (MCP): http://{config.host}:{config.port}/sse", file=sys.stderr)
        print(f"  - Health: http://{config.host}:{config.port}/health", file=sys.stderr)
        print(f"  - Info: http://{config.host}:{config.port}/info", file=sys.stderr)
        print(file=sys.stderr)
        print(
            "Note: SSE with built-in 15s pings + resumability for reliable connections",
            file=sys.stderr,
        )
    else:
        print("Running in stdio mode (for local MCP clients)", file=sys.stderr)
    print("=" * 60, file=sys.stderr)

    if use_stdio:
        # Run with stdio transport for local use (Claude Code, etc.)
        mcp.run(transport="stdio")
    else:
        # Run with SSE transport with resumability support
        # FastMCP has built-in 15-second pings to keep connections alive
        # For additional reliability, we can enable EventStore for resumability
        app = mcp.http_app(transport="sse")

        # Run with uvicorn
        uvicorn.run(app, host=config.host, port=config.port, log_level="info")


if __name__ == "__main__":
    main()
