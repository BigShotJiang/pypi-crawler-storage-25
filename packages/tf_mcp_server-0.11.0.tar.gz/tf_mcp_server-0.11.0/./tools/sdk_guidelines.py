"""
ToothFairyAI SDK Usage Guidelines for MCP Server

This document provides guidelines for using the ToothFairyAI SDK correctly
when implementing MCP tools. Follow these patterns to ensure proper integration.

Version: 0.7.0
"""

# ============================================================================
# SDK CLIENT CONFIGURATION
# ============================================================================

# Regional API URLs
REGIONAL_URLS = {
    "au": "https://api.toothfairyai.com",
    "eu": "https://api.eu.toothfairyai.com",
    "us": "https://api.us.toothfairyai.com",
    "dev": "https://api.toothfairylab.link",  # Test environment
}

# Regional AI URLs (for streaming/chat)
REGIONAL_AI_URLS = {
    "au": "https://ai.toothfairyai.com",
    "eu": "https://ai.eu.toothfairyai.com",
    "us": "https://ai.us.toothfairyai.com",
    "dev": "https://ai.toothfairylab.link",
}

# Regional Streaming URLs
REGIONAL_STREAM_URLS = {
    "au": "https://ais.toothfairyai.com",
    "eu": "https://ais.eu.toothfairyai.com",
    "us": "https://ais.us.toothfairyai.com",
    "dev": "https://ais.toothfairylab.link",
}


def get_client(api_key: str, workspace_id: str, region: str = "au"):
    """
    Get a ToothFairyClient configured for the specified region.

    Args:
        api_key: ToothFairyAI API key
        workspace_id: Workspace UUID
        region: API region ("au", "eu", "us", "dev")

    Returns:
        Configured ToothFairyClient instance
    """
    from toothfairyai import ToothFairyClient

    base_url = REGIONAL_URLS.get(region, REGIONAL_URLS["au"])
    ai_url = REGIONAL_AI_URLS.get(region, REGIONAL_AI_URLS["au"])
    ai_stream_url = REGIONAL_STREAM_URLS.get(region, REGIONAL_STREAM_URLS["au"])

    return ToothFairyClient(
        api_key=api_key,
        workspace_id=workspace_id,
        base_url=base_url,
        ai_url=ai_url,
        ai_stream_url=ai_stream_url,
        timeout=120
    )


# ============================================================================
# AUTHORISATION CREATION
# ============================================================================

AUTHORISATION_PATTERNS = """
## Creating Authorisations with Secrets

IMPORTANT: The flow is two-step:
1. Create Authorisation first (without secret value)
2. Create Secret linked to Authorisation (with the actual secret value)

### Available Auth Types

| Type | Use Case | Secret Field |
|------|----------|--------------|
| `oauth` | OAuth2 client credentials flow | clientSecret (stored via secrets.create) |
| `bearer` | Static Bearer token | tokenSecret (stored via secrets.create) |
| `apikey` | API key authentication | tokenSecret (stored via secrets.create) |
| `basic` | Username/password | tokenSecret (stored via secrets.create) |
| `none` | No authentication | None |

### OAuth2 Authorisation (CORRECT FLOW)

Step 1: Create Authorisation (without secret):
```python
auth = client.authorisations.create(
    name="SharePoint Graph API",
    auth_type="oauth",
    client_id="your-client-id",
    # client_secret is NOT provided here
    authorization_base_url="https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
    grant_type="client_credentials",
    scope="https://graph.microsoft.com/.default"
)
```

Step 2: Create Secret linked to Authorisation:
```python
secret = client.secrets.create(
    authorisation_id=auth.id,
    password_secret_value="your-client-secret-value"  # The actual secret
)
```

The system automatically links the secret to the authorisation's `clientSecret` field.

### Bearer Token Authorisation

```python
# Step 1: Create Authorisation
auth = client.authorisations.create(
    name="API Token",
    auth_type="bearer"
    # token_secret is NOT provided here
)

# Step 2: Create Secret
secret = client.secrets.create(
    authorisation_id=auth.id,
    password_secret_value="your-bearer-token-value"
)
```

### API Key Authorisation

```python
# Step 1: Create Authorisation
auth = client.authorisations.create(
    name="API Key Auth",
    auth_type="apikey"
)

# Step 2: Create Secret
secret = client.secrets.create(
    authorisation_id=auth.id,
    password_secret_value="your-api-key-value"
)
```

IMPORTANT: Never pass secret values directly in authorisations.create().
Always use the two-step flow: authorisation → secret.
"""


# ============================================================================
# AGENT FUNCTION (TOOL) CREATION
# ============================================================================

FUNCTION_CREATION_PATTERNS = """
## Creating Agent Functions (API Tools)

Agent functions define external APIs that agents can call. Critical fields:

### Required Fields

| Field | Description | Example |
|-------|-------------|---------|
| `name` | Function identifier (used in customToolingInstructions) | `"sharepoint_search"` |
| `description` | When to use this tool (AI uses this to decide) | "Use when user wants to search..." |
| `url` | API endpoint URL (supports {{variable}} substitution) | `"https://graph.microsoft.com/v1.0/search/query"` |
| `request_type` | HTTP method | `"GET"`, `"POST"`, `"PUT"`, `"DELETE"` |
| `authorisation_type` | Authentication type | `"oauth"`, `"bearer"`, `"apikey"`, `"none"` |
| `authorisation_id` | ID of the authorisation to use | `"adf2190c-79ac-..."` |

### CRITICAL: authorisation_type vs authorisationID

```python
# CORRECT - Use "oauth" type and reference the authorisation ID
{
    "authorisation_type": "oauth",
    "authorisationID": "adf2190c-79ac-4f53-96ad-cf6c45684e3f"
}

# WRONG - Using "bearer" when OAuth is needed
{
    "authorisation_type": "bearer",  # WRONG for OAuth APIs
    "authorisationKey": "adf2190c..."  # DEPRECATED field
}
```

### Parameters Format (JSON Schema)

Parameters MUST use proper JSON Schema format:

```python
# CORRECT - JSON Schema format
parameters = {
    "type": "object",
    "properties": {
        "search_query": {
            "type": "string",
            "description": "The search query string"
        },
        "size": {
            "type": "integer",
            "description": "Number of results (default 25)"
        }
    },
    "required": ["search_query"]
}

# WRONG - List format (DEPRECATED)
parameters = [
    {"name": "search_query", "type": "string", "description": "..."}
]
```

### Complete Example: Creating a Tool

```python
import requests
import json

# Using raw API call for full control
response = requests.post(
    "https://api.toothfairylab.link/function/create",
    headers={
        "x-api-key": API_KEY,
        "Content-Type": "application/json"
    },
    json={
        "workspaceid": WORKSPACE_ID,
        "name": "sharepoint_search",
        "description": "Use this tool when the user wants to search for files...",
        "url": "https://graph.microsoft.com/v1.0/search/query",
        "requestType": "post",  # lowercase
        "authorisationType": "oauth",
        "authorisationID": auth_id,  # From authorisation creation
        "parameters": json.dumps({
            "type": "object",
            "properties": {
                "requests": {
                    "type": "array",
                    "description": "Search request array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "object",
                                "properties": {
                                    "queryString": {"type": "string"}
                                },
                                "required": ["queryString"]
                            }
                        },
                        "required": ["query"]
                    }
                }
            },
            "required": ["requests"]
        })
    }
)
```

### URL Path Parameters

Use `{{variable}}` syntax for dynamic path parameters:

```python
url = "https://graph.microsoft.com/v1.0/drives/{{drive_id}}/items/{{item_id}}/children"

# Parameters automatically populate URL variables
parameters = {
    "type": "object",
    "properties": {
        "drive_id": {"type": "string", "description": "The drive ID"},
        "item_id": {"type": "string", "description": "The item ID"}
    },
    "required": ["drive_id", "item_id"]
}
```

### Static Arguments

Use `staticArgs` for values that should always be included:

```python
{
    "staticArgs": {
        "api_version": "v1",
        "format": "json"
    }
}
```
"""


# ============================================================================
# AGENT CREATION
# ============================================================================

AGENT_CREATION_PATTERNS = """
## Creating Agents

### Required Fields

```python
agent = client.agents.create(
    label="Agent Name",
    mode="retriever",  # chatter, retriever, coder, planner, voice
    interpolation_string="You are a helpful assistant...",
    goals="Help users with their tasks",
    temperature=0.3,
    max_tokens=4096,
    max_history=20,
    top_k=10,
    doc_top_k=5
)
```

### Mode-Specific Configuration

#### Retriever Mode (Document Analysis, Research)

```python
{
    "mode": "retriever",
    "agentic_rag": True,        # Enable multi-step execution
    "has_code": True,           # Enable code execution
    "charting": True,           # Enable visualizations
    "allow_internet_search": True,
    "agent_functions": ["tool-id-1", "tool-id-2"]  # Assign tools
}
```

#### Chatter Mode (Conversational, Creative)

```python
{
    "mode": "chatter",
    "agentic_rag": False,       # MUST be false
    "temperature": 0.5,        # Higher for creativity
    "allow_images_generation": True  # Creative tools
}
```

#### Planner Mode (Orchestrator)

```python
{
    "mode": "planner",
    "agentic_rag": False,
    "planner_auto_agent_spawn": True,
    "max_planning_steps": 15,
    "planning_instructions": "..."
}
```

#### Voice Mode

```python
{
    "mode": "voice",
    "agentic_rag": False,       # NEVER enable
    "stt_model": "whisper-large-v3-turbo",
    "tts_model": "orpheus-fast",
    "llm_voice_model": "sorcerer",
    "voice_name": "autumn"
}
```

### Assigning Tools to Agent

```python
# Method 1: During creation
agent = client.agents.create(
    label="My Agent",
    mode="retriever",
    agent_functions=["tool-id-1", "tool-id-2"]
)

# Method 2: Update existing agent
response = requests.post(
    f"{BASE_URL}/agent/update",
    headers={"x-api-key": API_KEY, "Content-Type": "application/json"},
    json={
        "workspaceid": WORKSPACE_ID,
        "id": agent_id,
        "customToolingInstructions": "Use @tool_name when...",
        "agenticRAG": True
    }
)
```

### Custom Tooling Instructions

Format: Reference tools by name with `@` prefix:

```python
custom_tooling_instructions = \"\"\"
Use @sharepoint_search when the user wants to find documents by keywords.
Use @sharepoint_list_drives to show available document libraries.
Use @sharepoint_get_content to read a file's content.
Use @sharepoint_get_metadata to inspect file details.
\"\"\"
```
"""


# ============================================================================
# ERROR HANDLING
# ============================================================================

ERROR_HANDLING_PATTERNS = """
## Error Handling

### Standard Response Format

```python
# Success
{
    "success": True,
    "message": "Operation completed successfully",
    "data": {...}
}

# Error
{
    "success": False,
    "error": "Error description",
    "error_type": "validation_error"  # Optional error classification
}
```

### Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| 401 Unauthorized | Invalid API key | Check key in Admin > API Integration |
| 403 Forbidden | Insufficient permissions | Upgrade subscription |
| 404 Not Found | Invalid ID | Verify UUID exists |
| 429 Too Many Requests | Rate limit | Wait and retry |
| 500 Internal Server Error | Server issue | Retry or contact support |

### Safe Execution Wrapper

```python
def safe_execute(func):
    \"\"\"Decorator to safely execute SDK operations.\"\"\"
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "error_type": type(e).__name__
            }
    return wrapper
```
"""


# ============================================================================
# QUICK REFERENCE
# ============================================================================

QUICK_REFERENCE = """
## Quick Reference

### Client Initialization
from toothfairyai import ToothFairyClient

client = ToothFairyClient(
    api_key="your-api-key",
    workspace_id="your-workspace-id",
    base_url="https://api.toothfairyai.com",  # or toothfairylab.link for dev
    ai_url="https://ai.toothfairyai.com",
    ai_stream_url="https://ais.toothfairyai.com",
    timeout=120
)


### Create Authorisation + Secret (Two-Step Flow - REQUIRED)

# Step 1: Create Authorisation (WITHOUT secret)
auth = client.authorisations.create(
    name="SharePoint Graph API",
    auth_type="oauth",
    client_id="your-client-id",
    # NOT passing client_secret here
    authorization_base_url="https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
    grant_type="client_credentials",
    scope="https://graph.microsoft.com/.default"
)

# Step 2: Create Secret (WITH secret value)
secret = client.secrets.create(
    authorisation_id=auth.id,
    password_secret_value="your-actual-client-secret-value"
)


### Bearer Token Flow

# Step 1: Create Authorisation
auth = client.authorisations.create(
    name="API Token",
    auth_type="bearer"
)

# Step 2: Create Secret
secret = client.secrets.create(
    authorisation_id=auth.id,
    password_secret_value="your-bearer-token-value"
)


### Create Function (Tool)

# Use raw API for full control
requests.post(
    f"{base_url}/function/create",
    headers={"x-api-key": api_key, "Content-Type": "application/json"},
    json={
        "workspaceid": workspace_id,
        "name": "tool_name",
        "description": "When to use...",
        "url": "https://api.example.com/endpoint",
        "requestType": "get",
        "authorisationType": "oauth",
        "authorisationID": auth.id,
        "parameters": json.dumps({"type": "object", "properties": {...}})
    }
)


### Create Agent

agent = client.agents.create(
    label="Agent Name",
    mode="retriever",
    interpolation_string="...",
    goals="...",
    temperature=0.3,
    max_tokens=4096,
    agentic_rag=True,
    has_code=True,
    agent_functions=["tool-id-1", "tool-id-2"]
)


### Fine-Tuning Workflow

# Step 1: List trainable models (PUBLIC - no auth needed)
models = client.finetuning.list_models()

# Step 2: Generate dataset from workspace documents
result = client.finetuning.generate_dataset(
    name="my-sft-job",
    training_type="conversationalTraining",  # SFT
    base_model="toothfairyai/Llama-3.2-1B-Instruct",
    lora_r=16,
    num_epochs=3
)
training_log_id = result["training_log_id"]

# Step 3: Poll status until dataset is ready
import time
while True:
    status = client.finetuning.get_status(training_log_id)
    if status.status == "datasetReady":
        break
    elif status.status in ("inError", "cancelled"):
        raise Exception(f"Job failed: {status.error}")
    time.sleep(30)

# Step 4: Start training
result = client.finetuning.start_training(
    training_log_id=training_log_id,
    use_spot_instances=True
)

# Step 5: Monitor training progress
status = client.finetuning.get_status(training_log_id)
# When completed, download URLs are available in status.downloads

### Training Types Reference

| Type | Value | Document Source | Use Case |
|------|-------|-----------------|----------|
| SFT | conversationalTraining | Conversation docs | Instruction-following |
| DPO | generativeTraining | Preference docs | Preference alignment |
| GRPO | grpoTraining | Conversation docs | Reward-based optimization |
| KTO | ktoTraining | Preference docs | Unpaired preference training |
| CPT | continuedPretraining | Conversation docs | Domain adaptation |

### Key Field Names (SDK vs API)

| SDK Field | API Field | Notes |
|-----------|-----------|-------|
| `auth_type` | `authorisationType` | SDK uses snake_case |
| `authorisation_id` | `authorisationID` | API uses camelCase |
| `request_type` | `requestType` | SDK uses snake_case |
| `agent_functions` | `agentFunctions` | List of tool IDs |
| `agentic_rag` | `agenticRAG` | Boolean; MUST be false when useInterleavedReasoning=true |
| `use_interleaved_reasoning` | `useInterleavedReasoning` | AT 2.0 mode; requires interleaved-capable model + agenticRAG=false + reasoningMode='always' |
| `interleaved_preset` | `interleavedPreset` | AT 2.0 limits; recommended 'medium' |
| `max_total_tool_calls` | `maxTotalToolCalls` | Max tool calls per turn |
| `max_consecutive_same_tool` | `maxConsecutiveSameTool` | Max same-tool calls |
| `max_consecutive_failures` | `maxConsecutiveFailures` | Max consecutive failures |

### Test Environment URLs

For testing, use `toothfairylab.link` instead of `toothfairyai.com`:
- API: `https://api.toothfairylab.link`
- AI: `https://ai.toothfairylab.link`
- Stream: `https://ais.toothfairylab.link`

### CRITICAL PATTERNS

1. **Two-Step Auth Flow**:
   - `authorisations.create()` → NO secret value
   - `secrets.create()` → WITH secret value, links to authorisation

2. **Function Authorisation**:
   - `authorisationType: "oauth"` for OAuth APIs (NOT "bearer")
   - `authorisationID` references the authorisation ID

3. **Parameters Format**:
   - MUST use JSON Schema: `{"type": "object", "properties": {...}}`
   - NOT list format: `[{"name": "...", "type": "..."}]`

4. **Fine-Tuning Flow** (requires Business/Enterprise):
   - `finetuning.list_models()` → discover base models
   - `finetuning.generate_dataset()` → create dataset from docs
   - `finetuning.get_status()` → poll until datasetReady
   - `finetuning.start_training()` → begin training
   - `finetuning.get_status()` → monitor until completed
   - `status.downloads` → presigned URLs for LoRA adapter

5. **Training Data Generation (MagicWand)** (requires Business/Enterprise):
   - `finetuning.generate_training_data(chat_id="...")` → from chat conversation
   - `finetuning.generate_training_data(file_key="...")` → from uploaded file
   - Chat mode: transforms existing messages into training data
   - File mode: chunks document + LLM synthesizes multi-turn conversations
   - Supports all training types (SFT, DPO, GRPO, KTO, CPT)
   - DPO: set `generate_non_preferred=True` or provide `non_preferred_responses`
   - Optional `instructions` for LLM-based refinement (simplify, expand, etc.)
   - `create_document=True` (default) saves as training document in knowledge base
    - `scope="validation"` to create validation split instead of training split

6. **Benchmark Question Format** (CRITICAL - must follow this exactly):

   Each question is a dict with required "question" and "answer" keys:

   ```python
   # Correct format for questions parameter
   questions = [
       {"question": "What is the refund policy?", "answer": "Refunds within 30 days"},
       {"question": "How to reset password?", "answer": "Click Forgot Password", "reasoning": "Standard flow"},
       {"question": "Business hours?", "answer": "Mon-Fri 9am-5pm", "context": "Support page"},
   ]
   ```

   Schema:
   - "question" (required, max 6000 chars): The question to ask the agent
   - "answer" (required, max 6000 chars): The expected correct answer
   - "reasoning" (optional, max 6000 chars): Why this answer is correct
   - "context" (optional, max 6000 chars): Additional context for evaluation

   CSV format (for file upload via documents.upload):
   - Delimiter: semicolon (;) — NOT comma
   - All fields double-quoted, no header row
   - 2-4 fields per row: "question";"answer";"reasoning";"context"

   Example CSV content:
   ```
   "What is the refund policy?";"Refunds within 30 days";"Policy doc states 30-day window";"Refund section"
   "How do I reset my password?";"Click Forgot Password on the login page"
   ```

   Minimum questions by benchmark type:
   - Standard BM (type="bm"): 1+ questions
   - ABM Static (type="abm", mode="static"): 10-200 questions recommended
   - ABM Dynamic (type="abm", mode="dynamic"): 1+ questions

7. **Automated Fine-Tuning Pipeline** (full end-to-end workflow):

   Step 1: Ingest external documents → training data
   ```python
   # From uploaded file (PDF, DOCX, etc.)
   result = client.finetuning.generate_training_data(
       file_key="workspace-uuid/policy-handbook.pdf",
       training_type="conversationalTraining",
       chunk_size=3000, num_turns=8,
       create_document=True
   )
   # Or from existing chat
   result = client.finetuning.generate_training_data(
       chat_id="chat-uuid",
       training_type="conversationalTraining",
       create_document=True
   )
   ```

   Step 2: Create benchmark for evaluation
   ```python
   benchmark = client.benchmarks.create(
       name="Policy Knowledge Baseline",
       questions=[
           {"question": "What is the refund policy?", "answer": "Refunds within 30 days"},
           {"question": "Are digital products refundable?", "answer": "No"},
           # ... 10+ questions recommended for reliable evaluation
       ]
   )
   ```

    Step 3: Run baseline benchmark (BEFORE fine-tuning)
    ```python
    run = client.benchmarks.run(
        benchmark_id=benchmark.id,
        agent_id=agent_id,
        type="bm",
        name="Baseline BM"
    )
    baseline = client.benchmarks.wait_for_run(run.id)
    print(f"Baseline score: {baseline.score}")  # e.g. 0.45
    ```

    Step 4: Generate fine-tuning dataset
   ```python
   result = client.finetuning.generate_dataset(
       name="policy-sft-job",
       training_type="conversationalTraining",
       base_model="toothfairyai/Llama-3.2-1B-Instruct",
       lora_r=16, num_epochs=3
   )
   training_log_id = result["training_log_id"]
   ```

   Step 5: Wait for dataset + start training
   ```python
   import time
   while True:
       status = client.finetuning.get_status(training_log_id)
       if status.status == "datasetReady": break
       elif status.status in ("inError", "cancelled"): raise Exception(status.error)
       time.sleep(30)

   client.finetuning.start_training(training_log_id=training_log_id)
   while True:
       status = client.finetuning.get_status(training_log_id)
       if status.status == "completed": break
       elif status.status in ("inError", "cancelled"): raise Exception(status.error)
       time.sleep(30)
   ```

    Step 6: Deploy fine-tuned model + re-run benchmark (AFTER)
    ```python
    # Update agent's model
    client.agents.update(agent_id, llm_url=finetuned_model_url)

    # Re-run the same benchmark
    after_run = client.benchmarks.run(
        benchmark_id=benchmark.id,
        agent_id=agent_id,
        type="bm",
        name="Post-finetuning BM"
    )
    after_result = client.benchmarks.wait_for_run(after_run.id)

    # Compare scores
    improvement = after_result.score - baseline.score
    if improvement > 0:
        print(f"Improved by {improvement:.2%}!")
    else:
        # Rollback: restore original model
        client.agents.update(agent_id, llm_url=original_model_url)
        print(f"Score did not improve. Rolled back.")
    ```
"""