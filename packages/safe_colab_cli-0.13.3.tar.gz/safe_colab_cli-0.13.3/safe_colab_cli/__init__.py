"""Safe Colab CLI - Sandboxed Jupyter kernel with remote Hypha service access."""

__version__ = "0.13.3"
