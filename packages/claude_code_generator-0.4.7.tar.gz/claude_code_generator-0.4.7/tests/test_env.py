"""Tests for environment safety module."""

import logging
import os

import pytest

from code_generator.env import (
    DANGEROUS_VARS,
    OLLAMA_BASE_URL,
    WorkspaceMismatchError,
    assert_safe_environment,
    assert_safe_environment_ollama,
    assert_single_workspace,
    build_agent_env,
    strip_dangerous_env,
)


def test_dangerous_vars_contains_all_six() -> None:
    """DANGEROUS_VARS must list exactly the six documented variables."""
    expected = {
        "ANTHROPIC_API_KEY",
        "ANTHROPIC_AUTH_TOKEN",
        "ANTHROPIC_BEDROCK_API_KEY",
        "ANTHROPIC_VERTEX_PROJECT_ID",
        "CLAUDE_CODE_USE_BEDROCK",
        "CLAUDE_CODE_USE_VERTEX",
    }
    assert set(DANGEROUS_VARS) == expected


class TestStripDangerousEnv:
    def test_strips_present_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """strip_dangerous_env removes every DANGEROUS_VAR that is present."""
        for var in DANGEROUS_VARS:
            monkeypatch.setenv(var, "value")

        strip_dangerous_env()

        for var in DANGEROUS_VARS:
            assert var not in os.environ

    def test_no_error_when_vars_absent(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """strip_dangerous_env must not raise when vars are not present."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)

        strip_dangerous_env()  # should not raise

    def test_leaves_other_vars_intact(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """strip_dangerous_env must not touch unrelated environment variables."""
        monkeypatch.setenv("MY_SAFE_VAR", "safe")
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)

        strip_dangerous_env()

        assert os.environ.get("MY_SAFE_VAR") == "safe"


class TestBuildAgentEnv:
    def test_excludes_all_dangerous_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """build_agent_env returns a copy with no dangerous vars."""
        for var in DANGEROUS_VARS:
            monkeypatch.setenv(var, "should-be-stripped")

        env = build_agent_env()

        for var in DANGEROUS_VARS:
            assert var not in env

    def test_preserves_safe_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """build_agent_env keeps all non-dangerous environment variables."""
        monkeypatch.setenv("PATH", "/usr/bin")
        monkeypatch.setenv("HOME", "/home/user")
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)

        env = build_agent_env()

        assert env.get("PATH") == "/usr/bin"
        assert env.get("HOME") == "/home/user"

    def test_does_not_mutate_os_environ(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """build_agent_env returns a copy, not a reference to os.environ."""
        for var in DANGEROUS_VARS:
            monkeypatch.setenv(var, "value")

        env = build_agent_env()

        assert env is not os.environ
        # Originals still present in os.environ (monkeypatch will restore them)
        for var in DANGEROUS_VARS:
            assert var in os.environ


class TestAssertSafeEnvironment:
    def test_passes_when_no_dangerous_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """assert_safe_environment succeeds silently when env is clean."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)

        assert_safe_environment()  # must not raise

    def test_strips_var_when_present(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """assert_safe_environment strips dangerous vars instead of aborting."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-123")
        for var in DANGEROUS_VARS:
            if var != "ANTHROPIC_API_KEY":
                monkeypatch.delenv(var, raising=False)

        assert_safe_environment()

        assert "ANTHROPIC_API_KEY" not in os.environ

    def test_warning_names_dangerous_vars(
        self, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """The printed warning lists the offending variable names."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-abc")
        monkeypatch.setenv("CLAUDE_CODE_USE_BEDROCK", "1")
        for var in DANGEROUS_VARS:
            if var not in ("ANTHROPIC_API_KEY", "CLAUDE_CODE_USE_BEDROCK"):
                monkeypatch.delenv(var, raising=False)

        assert_safe_environment()

        captured = capsys.readouterr()
        assert "ANTHROPIC_API_KEY" in captured.err
        assert "CLAUDE_CODE_USE_BEDROCK" in captured.err
        assert "ANTHROPIC_API_KEY" not in os.environ
        assert "CLAUDE_CODE_USE_BEDROCK" not in os.environ

    def test_strips_each_dangerous_var(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """assert_safe_environment strips any individual dangerous var."""
        for dangerous_var in DANGEROUS_VARS:
            for v in DANGEROUS_VARS:
                monkeypatch.delenv(v, raising=False)

            monkeypatch.setenv(dangerous_var, "present")
            assert_safe_environment()
            assert dangerous_var not in os.environ


class TestAssertSafeEnvironmentOllama:
    """The Ollama bypass auto-strips parent ANTHROPIC_* vars instead of refusing."""

    def test_passes_when_no_dangerous_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """assert_safe_environment_ollama is silent when env is already clean."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)

        assert_safe_environment_ollama()  # must not raise

    def test_strips_anthropic_api_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """A stray ANTHROPIC_API_KEY is stripped from os.environ instead of aborting."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-real-key")
        for var in DANGEROUS_VARS:
            if var != "ANTHROPIC_API_KEY":
                monkeypatch.delenv(var, raising=False)

        assert_safe_environment_ollama()

        assert "ANTHROPIC_API_KEY" not in os.environ

    def test_warning_mentions_localhost_daemon(
        self, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """The printed warning names the Ollama daemon and the offending vars."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-abc")
        monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "tok")
        for var in DANGEROUS_VARS:
            if var not in ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN"):
                monkeypatch.delenv(var, raising=False)

        assert_safe_environment_ollama()

        captured = capsys.readouterr()
        assert OLLAMA_BASE_URL in captured.err
        assert "ANTHROPIC_API_KEY" in captured.err
        assert "ANTHROPIC_AUTH_TOKEN" in captured.err

    def test_strips_every_dangerous_var(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """assert_safe_environment_ollama strips any individual dangerous var."""
        for dangerous_var in DANGEROUS_VARS:
            for v in DANGEROUS_VARS:
                monkeypatch.delenv(v, raising=False)

            monkeypatch.setenv(dangerous_var, "present")
            assert_safe_environment_ollama()
            assert dangerous_var not in os.environ


class TestAssertSingleWorkspace:
    def test_single_workspace_mock_passes_without_error(self) -> None:
        """Single-workspace probe resolving to one identity must not raise."""

        def probe() -> frozenset[str]:
            return frozenset({"workspace-abc"})

        assert_single_workspace(probe=probe)  # must not raise

    def test_two_workspace_mock_raises_workspace_mismatch_error(self) -> None:
        """Two-workspace probe must raise WorkspaceMismatchError with workspace names."""

        def probe() -> frozenset[str]:
            return frozenset({"ws-a", "ws-b"})

        with pytest.raises(WorkspaceMismatchError, match="ws-a"):
            assert_single_workspace(probe=probe)

    def test_workspace_mismatch_error_is_runtime_error(self) -> None:
        """WorkspaceMismatchError must subclass RuntimeError."""
        assert issubclass(WorkspaceMismatchError, RuntimeError)

    def test_sdk_without_probe_logs_info_exactly_once(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """When probe returns None (SDK lacks workspace probe), logs INFO exactly once."""

        def probe() -> None:
            return None

        state: dict[str, object] = {"warned": False}

        with caplog.at_level(logging.INFO):
            assert_single_workspace(probe=probe, _state=state)  # first call
            assert_single_workspace(probe=probe, _state=state)  # second call — must not re-log

        info_records = [
            r
            for r in caplog.records
            if r.levelno == logging.INFO and "workspace probe" in r.message
        ]
        assert len(info_records) == 1, f"Expected exactly 1 INFO log, got {len(info_records)}"
        assert "single-workspace assertion deferred" in info_records[0].message

    def test_sdk_without_probe_does_not_raise(self) -> None:
        """When probe returns None, no exception is raised."""

        def probe() -> None:
            return None

        state: dict[str, object] = {"warned": False}
        assert_single_workspace(probe=probe, _state=state)  # must not raise

    def test_empty_workspace_set_does_not_raise(self) -> None:
        """Empty frozenset from probe (no identities registered) must not raise."""

        def probe() -> frozenset[str]:
            return frozenset()

        assert_single_workspace(probe=probe)  # must not raise


class TestBuildAgentEnvAnthropicMaxProvider:
    """Default provider must preserve byte-for-byte the current strip-everything path."""

    def test_default_provider_is_anthropic_max(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """build_agent_env() without provider kwarg uses anthropic-max."""
        for var in DANGEROUS_VARS:
            monkeypatch.setenv(var, "value")

        env = build_agent_env()  # no kwarg

        for var in DANGEROUS_VARS:
            assert var not in env

    def test_anthropic_max_strips_all_dangerous_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Explicit provider="anthropic-max" behaves identically to the default."""
        for var in DANGEROUS_VARS:
            monkeypatch.setenv(var, "value")

        env = build_agent_env(provider="anthropic-max")

        for var in DANGEROUS_VARS:
            assert var not in env

    def test_anthropic_max_preserves_unrelated_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """anthropic-max path leaves unrelated env vars intact."""
        monkeypatch.setenv("PATH", "/usr/bin")
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)

        env = build_agent_env(provider="anthropic-max")

        assert env.get("PATH") == "/usr/bin"


class TestBuildAgentEnvOllamaProvider:
    """Ollama provider rewrites ANTHROPIC_AUTH_TOKEN from OLLAMA_API_KEY and pins base URL."""

    def test_ollama_populates_auth_token_from_ollama_api_key(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """provider=ollama sets ANTHROPIC_AUTH_TOKEN to the OLLAMA_API_KEY value."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        monkeypatch.setenv("OLLAMA_API_KEY", "ollama-token-xyz")

        env = build_agent_env(provider="ollama")

        assert env["ANTHROPIC_AUTH_TOKEN"] == "ollama-token-xyz"

    def test_ollama_pins_base_url_to_localhost(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """provider=ollama sets ANTHROPIC_BASE_URL to http://localhost:11434."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        monkeypatch.setenv("OLLAMA_API_KEY", "ollama-token")

        env = build_agent_env(provider="ollama")

        assert env["ANTHROPIC_BASE_URL"] == "http://localhost:11434"

    def test_ollama_sets_empty_api_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """provider=ollama exposes ANTHROPIC_API_KEY="" so SDK picks AUTH_TOKEN path."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        monkeypatch.setenv("OLLAMA_API_KEY", "ollama-token")

        env = build_agent_env(provider="ollama")

        assert env.get("ANTHROPIC_API_KEY") == ""

    def test_ollama_ignores_parent_auth_token(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """OLLAMA_API_KEY wins over any pre-existing ANTHROPIC_AUTH_TOKEN in parent env."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "leaked-anthropic-token")
        monkeypatch.setenv("OLLAMA_API_KEY", "ollama-wins")

        env = build_agent_env(provider="ollama")

        assert env["ANTHROPIC_AUTH_TOKEN"] == "ollama-wins"

    def test_ollama_ignores_parent_anthropic_api_key(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """provider=ollama rewrites ANTHROPIC_API_KEY="" regardless of parent value.

        The builder strips every ANTHROPIC_* var from the returned dict and pins
        ANTHROPIC_BASE_URL to localhost, so a non-empty parent ANTHROPIC_API_KEY
        cannot leak to Anthropic. Operators no longer have to `unset` it in
        their shell before invoking `code-generator generate ollama`.
        """
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        monkeypatch.setenv("OLLAMA_API_KEY", "ollama-token")
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-real-key")

        env = build_agent_env(provider="ollama")

        assert env.get("ANTHROPIC_API_KEY") == ""
        assert env["ANTHROPIC_AUTH_TOKEN"] == "ollama-token"
        assert env["ANTHROPIC_BASE_URL"] == "http://localhost:11434"

    def test_ollama_refuses_when_base_url_mismatches(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """provider=ollama raises when ANTHROPIC_BASE_URL is pre-set to a non-localhost host."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.setenv("OLLAMA_API_KEY", "ollama-token")
        monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://evil.example.com")

        with pytest.raises(RuntimeError, match="ANTHROPIC_BASE_URL"):
            build_agent_env(provider="ollama")

    def test_ollama_accepts_preset_matching_base_url(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """provider=ollama accepts an already-correct ANTHROPIC_BASE_URL (idempotent)."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.setenv("OLLAMA_API_KEY", "ollama-token")
        monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://localhost:11434")

        env = build_agent_env(provider="ollama")

        assert env["ANTHROPIC_BASE_URL"] == "http://localhost:11434"

    def test_ollama_refuses_when_ollama_api_key_missing(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """provider=ollama raises explicitly when OLLAMA_API_KEY is absent."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        monkeypatch.delenv("OLLAMA_API_KEY", raising=False)

        with pytest.raises(RuntimeError, match="OLLAMA_API_KEY"):
            build_agent_env(provider="ollama")

    def test_ollama_refuses_when_ollama_api_key_empty(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """provider=ollama raises explicitly when OLLAMA_API_KEY is the empty string."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        monkeypatch.setenv("OLLAMA_API_KEY", "")

        with pytest.raises(RuntimeError, match="OLLAMA_API_KEY"):
            build_agent_env(provider="ollama")

    def test_ollama_env_exact_anthropic_key_set(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """The returned env has exactly three ANTHROPIC_* keys (AUTH_TOKEN, BASE_URL, API_KEY)."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        monkeypatch.setenv("OLLAMA_API_KEY", "ollama-token")

        env = build_agent_env(provider="ollama")

        anthropic_keys = {k for k in env if k.startswith("ANTHROPIC_")}
        assert anthropic_keys == {
            "ANTHROPIC_AUTH_TOKEN",
            "ANTHROPIC_BASE_URL",
            "ANTHROPIC_API_KEY",
        }

    def test_ollama_rejects_unknown_provider(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """An unknown provider value raises ValueError (Literal enforcement at runtime)."""
        monkeypatch.setenv("OLLAMA_API_KEY", "ollama-token")

        with pytest.raises(ValueError, match="provider"):
            build_agent_env(provider="bedrock")  # type: ignore[arg-type]

    def test_ollama_base_url_constant_is_exported(self) -> None:
        """OLLAMA_BASE_URL constant matches the pinned localhost endpoint."""
        assert OLLAMA_BASE_URL == "http://localhost:11434"


class TestAssertSingleWorkspaceLocalhostShortCircuit:
    """Localhost ANTHROPIC_BASE_URL short-circuits the workspace assertion."""

    def test_localhost_base_url_short_circuits_without_raise(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """ANTHROPIC_BASE_URL=http://localhost:11434 short-circuits (no probe invoked)."""
        monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://localhost:11434")
        probe_calls: list[int] = []

        def probe() -> frozenset[str]:
            probe_calls.append(1)
            return frozenset({"ws-a", "ws-b"})  # would normally raise

        assert_single_workspace(probe=probe, _state={"warned": False, "localhost_logged": False})
        assert probe_calls == [], "probe must not be invoked on the localhost short-circuit path"

    def test_localhost_any_port_short_circuits(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Any http://localhost:* endpoint (not just 11434) short-circuits."""
        monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://localhost:1234")

        def probe() -> frozenset[str]:
            return frozenset({"ws-a", "ws-b"})

        assert_single_workspace(
            probe=probe, _state={"warned": False, "localhost_logged": False}
        )  # must not raise

    def test_localhost_short_circuit_logs_info_once(
        self, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        """The localhost short-circuit emits an INFO log exactly once per invocation state."""
        monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://localhost:11434")
        state: dict[str, object] = {"warned": False, "localhost_logged": False}

        def probe() -> frozenset[str]:
            return frozenset({"one"})

        with caplog.at_level(logging.INFO):
            assert_single_workspace(probe=probe, _state=state)
            assert_single_workspace(probe=probe, _state=state)

        localhost_records = [
            r for r in caplog.records if r.levelno == logging.INFO and "localhost" in r.message
        ]
        assert len(localhost_records) == 1, (
            f"Expected exactly 1 localhost INFO log, got {len(localhost_records)}"
        )

    def test_non_localhost_base_url_does_not_short_circuit(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A non-localhost ANTHROPIC_BASE_URL still runs the probe and enforces workspace."""
        monkeypatch.setenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com")

        def probe() -> frozenset[str]:
            return frozenset({"ws-a", "ws-b"})

        with pytest.raises(WorkspaceMismatchError):
            assert_single_workspace(
                probe=probe, _state={"warned": False, "localhost_logged": False}
            )

    def test_unset_base_url_does_not_short_circuit(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When ANTHROPIC_BASE_URL is unset the regular probe path runs."""
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)

        def probe() -> frozenset[str]:
            return frozenset({"ws-a", "ws-b"})

        with pytest.raises(WorkspaceMismatchError):
            assert_single_workspace(
                probe=probe, _state={"warned": False, "localhost_logged": False}
            )
