import json
from collections.abc import AsyncIterator

import pytest

from flowra.llm import (
    ContentComplete,
    LLMRequest,
    StopReason,
    SystemMessage,
    TextBlock,
    TextDelta,
    Tool,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from flowra.llm.providers.azure_openai import AzureOpenAIProvider


@pytest.fixture
async def provider() -> AsyncIterator[AzureOpenAIProvider]:
    import os

    async with AzureOpenAIProvider(
        azure_endpoint=os.environ["AZURE_ENDPOINT"],
        api_key=os.environ["AZURE_API_KEY"],
        api_version="2025-03-01-preview",
    ) as p:
        yield p


MODEL = "gpt-4o-mini-2024-07-18"


async def test_simple_text_response(provider: AzureOpenAIProvider) -> None:
    request = LLMRequest(
        model=MODEL,
        messages=[
            UserMessage(blocks=[TextBlock(text="Reply with exactly: hello")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    assert len(response.message.blocks) > 0
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "hello" in text.lower()


async def test_system_message(provider: AzureOpenAIProvider) -> None:
    request = LLMRequest(
        model=MODEL,
        system=[
            SystemMessage(blocks=[TextBlock(text="You are a bot that only replies with the word 'pong'.")]),
        ],
        messages=[
            UserMessage(blocks=[TextBlock(text="ping")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "pong" in text.lower()


async def test_tool_use(provider: AzureOpenAIProvider) -> None:
    tool = Tool(
        name="get_weather",
        description="Get the current weather for a city.",
        input_schema={
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"},
            },
            "required": ["city"],
        },
    )
    request = LLMRequest(
        model=MODEL,
        messages=[
            UserMessage(blocks=[TextBlock(text="What's the weather in Paris?")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.TOOL_USE
    tool_uses = [b for b in response.message.blocks if isinstance(b, ToolUseBlock)]
    assert len(tool_uses) == 1
    assert tool_uses[0].name == "get_weather"
    assert isinstance(tool_uses[0].input, str)
    parsed = json.loads(tool_uses[0].input)
    assert parsed["city"].lower() == "paris"


async def test_tool_use_roundtrip(provider: AzureOpenAIProvider) -> None:
    tool = Tool(
        name="get_temperature",
        description="Get temperature for a city. Returns temperature in Celsius.",
        input_schema={
            "type": "object",
            "properties": {
                "city": {"type": "string"},
            },
            "required": ["city"],
        },
    )

    request1 = LLMRequest(
        model=MODEL,
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response1 = await provider.call(request1)
    print(response1)

    assert response1.stop_reason == StopReason.TOOL_USE
    tool_use = next(b for b in response1.message.blocks if isinstance(b, ToolUseBlock))

    request2 = LLMRequest(
        model=MODEL,
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
            response1.message,
            UserMessage(blocks=[ToolResultBlock(tool_use_id=tool_use.id, content="15")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response2 = await provider.call(request2)
    print(response2)

    assert response2.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response2.message.blocks if isinstance(b, TextBlock))
    assert "15" in text


async def test_stream_simple_text(provider: AzureOpenAIProvider) -> None:
    request = LLMRequest(
        model=MODEL,
        messages=[
            UserMessage(blocks=[TextBlock(text="Reply with exactly: hello")]),
        ],
        max_tokens=64,
    )

    events = []
    async for event in provider.stream(request):
        events.append(event)

    text_deltas = [e for e in events if isinstance(e, TextDelta)]
    completes = [e for e in events if isinstance(e, ContentComplete)]
    assert len(text_deltas) > 0
    assert len(completes) == 1
    assert completes[0].response.stop_reason == StopReason.END_TURN

    delta_text = "".join(d.text for d in text_deltas)
    full_text = "".join(b.text for b in completes[0].response.message.blocks if isinstance(b, TextBlock))
    assert delta_text == full_text


async def test_usage_is_returned(provider: AzureOpenAIProvider) -> None:
    request = LLMRequest(
        model=MODEL,
        messages=[
            UserMessage(blocks=[TextBlock(text="Say hi")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.usage is not None
    assert response.usage.input_tokens > 0
    assert response.usage.output_tokens > 0
