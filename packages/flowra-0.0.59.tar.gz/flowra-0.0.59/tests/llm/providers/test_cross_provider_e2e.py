"""Cross-provider e2e tests.

Turn 1 on one provider, turn 2 on another — validates that conversation
history (including server-side tool search items) transfers correctly.
"""

import base64
import json
import os
from collections.abc import AsyncIterator

import pytest
from anthropic import AsyncAnthropicVertex
from google.oauth2 import service_account
from openai import AsyncOpenAI

from flowra.llm import (
    LLMRequest,
    StopReason,
    SystemMessage,
    TextBlock,
    Tool,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider
from flowra.llm.providers.openai_responses import OpenAIResponsesProvider


@pytest.fixture
async def openai_provider() -> AsyncIterator[OpenAIResponsesProvider]:
    async with OpenAIResponsesProvider(
        client=AsyncOpenAI(api_key=os.environ["OPENAI_API_KEY"], base_url="https://eu.api.openai.com/v1"),
        owns_client=True,
    ) as p:
        yield p


@pytest.fixture
async def anthropic_provider() -> AsyncIterator[AnthropicVertexProvider]:
    project = os.environ["VERTEX_PROJECT_NAME"]
    location = os.environ["VERTEX_LOCATION"]
    creds_json = base64.b64decode(os.environ["VERTEX_CREDENTIALS"].encode()).decode()
    creds_info = json.loads(creds_json)
    creds = service_account.Credentials.from_service_account_info(creds_info).with_scopes(
        ["https://www.googleapis.com/auth/cloud-platform.read-only"]
    )
    client = AsyncAnthropicVertex(region=location, project_id=project, credentials=creds)
    async with AnthropicVertexProvider(client=client, owns_client=True) as p:
        yield p


async def test_openai_tool_search_then_anthropic_followup(
    openai_provider: OpenAIResponsesProvider,
    anthropic_provider: AnthropicVertexProvider,
) -> None:
    """Turn 1: OpenAI gpt-5.4 with tool search finds and calls a tool.
    Turn 2: Anthropic haiku continues the conversation with tool result.

    Validates that server-side tool search messages (ToolUseBlock/ToolResultBlock
    with matched IDs) are correctly understood by a different provider.
    """
    search_tool = Tool(
        name="__tool_search__",
        description="",
        extra={"openai": {"type": "tool_search"}},
    )
    weather_tool = Tool(
        name="get_weather",
        description="Get the current weather for a city. Returns JSON with temperature_celsius.",
        input_schema={
            "type": "object",
            "properties": {"city": {"type": "string", "description": "City name"}},
            "required": ["city"],
        },
        extra={"openai": {"defer_loading": True}},
    )

    # Turn 1: OpenAI with tool search
    response1 = await openai_provider.call(
        LLMRequest(
            model="gpt-5.4",
            messages=[UserMessage(blocks=[TextBlock(text="What's the weather in Tokyo?")])],
            tools=[search_tool, weather_tool],
            max_tokens=256,
        )
    )
    print("Turn 1 (OpenAI):", response1)

    assert response1.stop_reason == StopReason.TOOL_USE
    tool_uses = [b for b in response1.message.blocks if isinstance(b, ToolUseBlock)]
    assert len(tool_uses) == 1
    assert tool_uses[0].name == "get_weather"

    # Verify intermediate messages exist
    assert len(response1.messages) > 1, "Expected intermediate tool search messages"

    # Build history for turn 2: original question + all response messages + tool result
    history = [
        UserMessage(blocks=[TextBlock(text="What's the weather in Tokyo?")]),
        *response1.messages,
        UserMessage(
            blocks=[
                ToolResultBlock(
                    tool_use_id=tool_uses[0].id,
                    content='{"temperature_celsius": 22, "condition": "sunny"}',
                )
            ]
        ),
    ]

    # Turn 2: Anthropic haiku — same tool (without OpenAI-specific extras)
    plain_weather_tool = Tool(
        name="get_weather",
        description="Get the current weather for a city. Returns JSON with temperature_celsius.",
        input_schema={
            "type": "object",
            "properties": {"city": {"type": "string", "description": "City name"}},
            "required": ["city"],
        },
    )
    response2 = await anthropic_provider.call(
        LLMRequest(
            model="claude-haiku-4-5@20251001",
            system=[SystemMessage(blocks=[TextBlock(text="You are a helpful weather assistant. Be concise.")])],
            messages=history,
            tools=[plain_weather_tool],
            max_tokens=256,
        )
    )
    print("Turn 2 (Anthropic):", response2)

    assert response2.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response2.message.blocks if isinstance(b, TextBlock))
    assert "22" in text or "sunny" in text.lower() or "tokyo" in text.lower()
