import json
import os
from collections.abc import AsyncIterator

import pytest
from openai import AsyncOpenAI

from flowra.llm import (
    ContentComplete,
    LLMRequest,
    StopReason,
    SystemMessage,
    TextBlock,
    TextDelta,
    Tool,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from flowra.llm.providers.openai_responses import OpenAIResponsesProvider


@pytest.fixture
async def provider() -> AsyncIterator[OpenAIResponsesProvider]:
    async with OpenAIResponsesProvider(
        client=AsyncOpenAI(api_key=os.environ["OPENAI_API_KEY"]),
        owns_client=True,
    ) as p:
        yield p


async def test_simple_text_response(provider: OpenAIResponsesProvider) -> None:
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[UserMessage(blocks=[TextBlock(text="Reply with exactly: hello")])],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    assert len(response.message.blocks) > 0
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "hello" in text.lower()


async def test_system_message(provider: OpenAIResponsesProvider) -> None:
    request = LLMRequest(
        model="gpt-4.1-mini",
        system=[SystemMessage(blocks=[TextBlock(text="You are a bot that only replies with the word 'pong'.")])],
        messages=[UserMessage(blocks=[TextBlock(text="ping")])],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "pong" in text.lower()


async def test_tool_use(provider: OpenAIResponsesProvider) -> None:
    tool = Tool(
        name="get_weather",
        description="Get the current weather for a city.",
        input_schema={
            "type": "object",
            "properties": {"city": {"type": "string", "description": "City name"}},
            "required": ["city"],
        },
    )
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[UserMessage(blocks=[TextBlock(text="What's the weather in Paris?")])],
        tools=[tool],
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.TOOL_USE
    tool_uses = [b for b in response.message.blocks if isinstance(b, ToolUseBlock)]
    assert len(tool_uses) == 1
    assert tool_uses[0].name == "get_weather"
    assert isinstance(tool_uses[0].input, str)
    parsed = json.loads(tool_uses[0].input)
    assert parsed["city"].lower() == "paris"


async def test_tool_use_roundtrip(provider: OpenAIResponsesProvider) -> None:
    tool = Tool(
        name="get_temperature",
        description="Get temperature for a city. Returns temperature in Celsius.",
        input_schema={
            "type": "object",
            "properties": {"city": {"type": "string"}},
            "required": ["city"],
        },
    )

    response1 = await provider.call(
        LLMRequest(
            model="gpt-4.1-mini",
            messages=[UserMessage(blocks=[TextBlock(text="What is the temperature in London?")])],
            tools=[tool],
            max_tokens=256,
        )
    )
    print(response1)

    assert response1.stop_reason == StopReason.TOOL_USE
    tool_use = next(b for b in response1.message.blocks if isinstance(b, ToolUseBlock))

    response2 = await provider.call(
        LLMRequest(
            model="gpt-4.1-mini",
            messages=[
                UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
                response1.message,
                UserMessage(blocks=[ToolResultBlock(tool_use_id=tool_use.id, content="15")]),
            ],
            tools=[tool],
            max_tokens=256,
        )
    )
    print(response2)

    assert response2.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response2.message.blocks if isinstance(b, TextBlock))
    assert "15" in text


async def test_stream_simple_text(provider: OpenAIResponsesProvider) -> None:
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[UserMessage(blocks=[TextBlock(text="Reply with exactly: hello")])],
        max_tokens=64,
    )

    events = []
    async for event in provider.stream(request):
        events.append(event)

    text_deltas = [e for e in events if isinstance(e, TextDelta)]
    completes = [e for e in events if isinstance(e, ContentComplete)]
    assert len(text_deltas) > 0
    assert len(completes) == 1
    assert completes[0].response.stop_reason == StopReason.END_TURN

    delta_text = "".join(d.text for d in text_deltas)
    full_text = "".join(b.text for b in completes[0].response.message.blocks if isinstance(b, TextBlock))
    assert delta_text == full_text


async def test_usage_is_returned(provider: OpenAIResponsesProvider) -> None:
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[UserMessage(blocks=[TextBlock(text="Say hi")])],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.usage is not None
    assert response.usage.input_tokens > 0
    assert response.usage.output_tokens > 0


async def test_tool_search_with_defer_loading(provider: OpenAIResponsesProvider) -> None:
    """Tool search with defer_loading on gpt-5.4."""
    search_tool = Tool(
        name="__tool_search__",
        description="",
        extra={"openai": {"type": "tool_search"}},
    )
    deferred_tool = Tool(
        name="get_weather",
        description="Get the current weather for a city.",
        input_schema={
            "type": "object",
            "properties": {"city": {"type": "string"}},
            "required": ["city"],
        },
        extra={"openai": {"defer_loading": True}},
    )
    request = LLMRequest(
        model="gpt-5.4",
        messages=[UserMessage(blocks=[TextBlock(text="What's the weather in Paris?")])],
        tools=[search_tool, deferred_tool],
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.TOOL_USE
    tool_uses = [b for b in response.message.blocks if isinstance(b, ToolUseBlock)]
    assert len(tool_uses) == 1
    assert tool_uses[0].name == "get_weather"
    assert isinstance(tool_uses[0].input, str)
    parsed = json.loads(tool_uses[0].input)
    assert "paris" in parsed["city"].lower()


async def test_json_schema(provider: OpenAIResponsesProvider) -> None:
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[
            UserMessage(blocks=[TextBlock(text="List three European capital cities.")]),
        ],
        json_schema={
            "type": "object",
            "properties": {
                "cities": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": ["cities"],
        },
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    parsed = json.loads(text)
    assert "cities" in parsed
    assert isinstance(parsed["cities"], list)
    assert len(parsed["cities"]) == 3


async def test_max_tokens_truncation(provider: OpenAIResponsesProvider) -> None:
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[
            UserMessage(blocks=[TextBlock(text="Write a long essay about the history of mathematics.")]),
        ],
        max_tokens=16,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.MAX_TOKENS


async def test_tool_search_with_namespaces(provider: OpenAIResponsesProvider) -> None:
    """Tool search with namespaced deferred tools on gpt-5.4.

    4 tools in 2 namespaces (accounting, payments), all deferred.
    Ask a question that requires a payments tool — model should find it via tool search.
    Then do a full roundtrip with tool result.
    """
    search_tool = Tool(
        name="__tool_search__",
        description="",
        extra={"openai": {"type": "tool_search"}},
    )
    tools = [
        search_tool,
        Tool(
            name="get_chart_of_accounts",
            description="Get the chart of accounts for the business.",
            input_schema={"type": "object", "properties": {}, "required": []},
            extra={"openai": {"namespace": "accounting", "defer_loading": True}},
        ),
        Tool(
            name="get_trial_balance",
            description="Get the trial balance for a given period.",
            input_schema={
                "type": "object",
                "properties": {"period": {"type": "string", "description": "Period, e.g. 2026-Q1"}},
                "required": ["period"],
            },
            extra={"openai": {"namespace": "accounting", "defer_loading": True}},
        ),
        Tool(
            name="get_transactions",
            description="Get recent transactions for an account.",
            input_schema={
                "type": "object",
                "properties": {"account_id": {"type": "string", "description": "Account ID"}},
                "required": ["account_id"],
            },
            extra={"openai": {"namespace": "payments", "defer_loading": True}},
        ),
        Tool(
            name="make_payment",
            description="Make a payment to a payee.",
            input_schema={
                "type": "object",
                "properties": {
                    "payee_id": {"type": "string", "description": "Payee ID"},
                    "amount": {"type": "number", "description": "Amount in GBP"},
                },
                "required": ["payee_id", "amount"],
            },
            extra={"openai": {"namespace": "payments", "defer_loading": True}},
        ),
    ]

    # Turn 1: ask about transactions — model should search and find payments.get_transactions
    request1 = LLMRequest(
        model="gpt-5.4",
        messages=[UserMessage(blocks=[TextBlock(text="Show me recent transactions for account ACC-001")])],
        tools=tools,
        extra={
            "openai": {
                "namespaces": {
                    "accounting": "Accounting and bookkeeping tools",
                    "payments": "Payment and transaction tools",
                }
            }
        },
        max_tokens=256,
    )
    response1 = await provider.call(request1)
    print("Turn 1:", response1)

    assert response1.stop_reason == StopReason.TOOL_USE
    tool_uses = [b for b in response1.message.blocks if isinstance(b, ToolUseBlock)]
    assert len(tool_uses) == 1
    assert tool_uses[0].name == "get_transactions"

    # Verify tool search happened
    assert len(response1.messages) > 1, "Expected intermediate tool search messages"

    # Turn 2: send tool result back with all intermediate messages
    turn2_messages = [
        UserMessage(blocks=[TextBlock(text="Show me recent transactions for account ACC-001")]),
        *response1.messages,
        UserMessage(
            blocks=[
                ToolResultBlock(
                    tool_use_id=tool_uses[0].id,
                    content=json.dumps(
                        [
                            {"date": "2026-03-28", "description": "Coffee shop", "amount": -4.50},
                            {"date": "2026-03-29", "description": "Client payment", "amount": 1500.00},
                        ]
                    ),
                )
            ]
        ),
    ]
    request2 = LLMRequest(
        model="gpt-5.4",
        messages=turn2_messages,
        tools=tools,
        extra={
            "openai": {
                "namespaces": {
                    "accounting": "Accounting and bookkeeping tools",
                    "payments": "Payment and transaction tools",
                }
            }
        },
        max_tokens=256,
    )
    response2 = await provider.call(request2)
    print("Turn 2:", response2)

    assert response2.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response2.message.blocks if isinstance(b, TextBlock))
    # Model should mention something from the transaction data
    assert "1500" in text or "coffee" in text.lower() or "ACC-001" in text


async def test_tool_search_multi_turn_roundtrip(provider: OpenAIResponsesProvider) -> None:
    """Tool search with deferred tools: full roundtrip on gpt-5.4.

    Turn 1: model uses tool search to find get_weather, calls it.
    Turn 2: we send tool result + all intermediate messages back, model responds with text.
    """
    search_tool = Tool(
        name="__tool_search__",
        description="",
        extra={"openai": {"type": "tool_search"}},
    )
    deferred_tool = Tool(
        name="get_weather",
        description="Get the current weather for a city. Returns JSON with temperature_celsius.",
        input_schema={
            "type": "object",
            "properties": {"city": {"type": "string", "description": "City name"}},
            "required": ["city"],
        },
        extra={"openai": {"defer_loading": True}},
    )
    tools = [search_tool, deferred_tool]

    # Turn 1: ask about weather
    request1 = LLMRequest(
        model="gpt-5.4",
        messages=[UserMessage(blocks=[TextBlock(text="What's the weather in Berlin?")])],
        tools=tools,
        max_tokens=256,
    )
    response1 = await provider.call(request1)
    print("Turn 1:", response1)

    assert response1.stop_reason == StopReason.TOOL_USE
    tool_uses = [b for b in response1.message.blocks if isinstance(b, ToolUseBlock)]
    assert len(tool_uses) == 1
    assert tool_uses[0].name == "get_weather"

    # Verify intermediate messages exist (tool_search_call + tool_search_output)
    assert len(response1.messages) > 1, "Expected intermediate tool search messages"
    assert any(isinstance(m, UserMessage) for m in response1.messages), "Expected UserMessage from tool search output"

    # Turn 2: send back all messages + tool result
    turn2_messages = [
        UserMessage(blocks=[TextBlock(text="What's the weather in Berlin?")]),
        *response1.messages,
        UserMessage(blocks=[ToolResultBlock(tool_use_id=tool_uses[0].id, content='{"temperature_celsius": 18}')]),
    ]
    request2 = LLMRequest(
        model="gpt-5.4",
        messages=turn2_messages,
        tools=tools,
        max_tokens=256,
    )
    response2 = await provider.call(request2)
    print("Turn 2:", response2)

    assert response2.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response2.message.blocks if isinstance(b, TextBlock))
    assert "18" in text
