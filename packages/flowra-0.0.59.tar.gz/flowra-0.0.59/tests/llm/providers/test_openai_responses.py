"""Unit tests for OpenAIResponsesProvider."""

import base64
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
from openai.types.responses import ResponseFunctionToolCall, ResponseOutputMessage, ResponseOutputText

from flowra.llm import (
    AssistantMessage,
    LLMRequest,
    MediaBlock,
    StopReason,
    SystemMessage,
    TextBlock,
    Tool,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from flowra.llm.providers.openai_responses import OpenAIResponsesProvider


def _tool_search_tool() -> Tool:
    return Tool(
        name="__tool_search__",
        description="",
        extra={"openai": {"type": "tool_search"}},
    )


def _deferred_tool(name: str, description: str = "") -> Tool:
    return Tool(
        name=name,
        description=description,
        input_schema={"type": "object", "properties": {"x": {"type": "string"}}},
        extra={"openai": {"defer_loading": True}},
    )


def _make_response(
    *,
    output: list[Any] | None = None,
    status: str = "completed",
    usage: dict[str, Any] | None = None,
    response_id: str = "resp_123",
) -> MagicMock:
    response = MagicMock()
    response.id = response_id
    response.status = status
    response.output = output or []

    if usage:
        response.usage = MagicMock()
        response.usage.input_tokens = usage.get("input_tokens", 10)
        response.usage.output_tokens = usage.get("output_tokens", 5)
        response.usage.total_tokens = usage.get("total_tokens", 15)
        input_details = MagicMock()
        input_details.cached_tokens = usage.get("cached_tokens", 0)
        response.usage.input_tokens_details = input_details
        output_details = MagicMock()
        output_details.reasoning_tokens = usage.get("reasoning_tokens", 0)
        response.usage.output_tokens_details = output_details
    else:
        response.usage = None

    return response


def _make_output_message(text: str) -> ResponseOutputMessage:
    content = ResponseOutputText(annotations=[], text=text, type="output_text")
    return ResponseOutputMessage(
        id="msg_1",
        content=[content],
        role="assistant",
        status="completed",
        type="message",
    )


def _make_function_call(name: str, arguments: str, call_id: str = "call_1") -> ResponseFunctionToolCall:
    return ResponseFunctionToolCall(
        arguments=arguments,
        call_id=call_id,
        name=name,
        type="function_call",
    )


_USAGE = {"input_tokens": 10, "output_tokens": 5}


@pytest.fixture
def mock_client() -> AsyncMock:
    return AsyncMock()


@pytest.fixture
def provider(mock_client: AsyncMock) -> OpenAIResponsesProvider:
    return OpenAIResponsesProvider(client=mock_client)


class TestBasicCalls:
    async def test_calls_responses_create(self, provider: OpenAIResponsesProvider, mock_client: AsyncMock) -> None:
        mock_client.responses.create.return_value = _make_response(
            output=[_make_output_message("Hello!")],
            usage=_USAGE,
        )
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
        )
        result = await provider.call(request)

        mock_client.responses.create.assert_called_once()
        assert result.stop_reason == StopReason.END_TURN
        block = result.message.blocks[0]
        assert isinstance(block, TextBlock)
        assert block.text == "Hello!"

    async def test_constructor_requires_client_or_api_key(self) -> None:
        with pytest.raises(ValueError, match="Either 'client' or 'api_key' must be provided"):
            OpenAIResponsesProvider()


class TestToolConversion:
    async def test_tool_search_tool_converted(self, provider: OpenAIResponsesProvider, mock_client: AsyncMock) -> None:
        mock_client.responses.create.return_value = _make_response(output=[_make_output_message("Hi")], usage=_USAGE)
        request = LLMRequest(
            model="gpt-5.4",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
            tools=[_tool_search_tool(), _deferred_tool("get_weather", "Get weather")],
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        tools = call_kwargs["tools"]
        assert tools[0] == {"type": "tool_search"}
        assert tools[1]["type"] == "function"
        assert tools[1]["name"] == "get_weather"
        assert tools[1]["defer_loading"] is True

    async def test_regular_tool_no_defer_loading(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        mock_client.responses.create.return_value = _make_response(output=[_make_output_message("Hi")], usage=_USAGE)
        tool = Tool(name="search", description="Search", input_schema=None)
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
            tools=[tool],
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        tools = call_kwargs["tools"]
        assert tools[0]["type"] == "function"
        assert "defer_loading" not in tools[0]


class TestNamespaces:
    async def test_tools_grouped_into_namespace(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        mock_client.responses.create.return_value = _make_response(output=[_make_output_message("Hi")], usage=_USAGE)
        tools = [
            Tool(
                name="get_orders",
                description="List orders",
                input_schema={"type": "object", "properties": {"id": {"type": "string"}}},
                extra={"openai": {"namespace": "crm"}},
            ),
            Tool(
                name="get_customer",
                description="Get customer",
                input_schema={"type": "object", "properties": {"id": {"type": "string"}}},
                extra={"openai": {"namespace": "crm"}},
            ),
        ]
        request = LLMRequest(
            model="gpt-5.4",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
            tools=tools,
            extra={"openai": {"namespaces": {"crm": "CRM tools"}}},
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        api_tools = call_kwargs["tools"]
        assert len(api_tools) == 1
        ns = api_tools[0]
        assert ns["type"] == "namespace"
        assert ns["name"] == "crm"
        assert ns["description"] == "CRM tools"
        assert len(ns["tools"]) == 2
        assert ns["tools"][0]["name"] == "get_orders"
        assert ns["tools"][1]["name"] == "get_customer"
        assert ns["tools"][0]["type"] == "function"

    async def test_namespace_with_defer_loading(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        mock_client.responses.create.return_value = _make_response(output=[_make_output_message("Hi")], usage=_USAGE)
        tools = [
            _tool_search_tool(),
            Tool(
                name="delete_user",
                description="Delete user",
                input_schema={"type": "object", "properties": {}},
                extra={"openai": {"namespace": "admin", "defer_loading": True}},
            ),
        ]
        request = LLMRequest(
            model="gpt-5.4",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
            tools=tools,
            extra={"openai": {"namespaces": {"admin": "Admin tools"}}},
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        api_tools = call_kwargs["tools"]
        assert api_tools[0] == {"type": "tool_search"}
        ns = api_tools[1]
        assert ns["type"] == "namespace"
        assert ns["tools"][0]["defer_loading"] is True

    async def test_mixed_namespaced_and_plain_tools(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        mock_client.responses.create.return_value = _make_response(output=[_make_output_message("Hi")], usage=_USAGE)
        tools = [
            Tool(name="search", description="Search", input_schema=None),
            Tool(
                name="get_orders",
                description="List orders",
                input_schema={"type": "object", "properties": {}},
                extra={"openai": {"namespace": "crm"}},
            ),
        ]
        request = LLMRequest(
            model="gpt-5.4",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
            tools=tools,
            extra={"openai": {"namespaces": {"crm": "CRM tools"}}},
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        api_tools = call_kwargs["tools"]
        assert len(api_tools) == 2
        assert api_tools[0]["type"] == "function"
        assert api_tools[0]["name"] == "search"
        assert api_tools[1]["type"] == "namespace"
        assert api_tools[1]["name"] == "crm"

    async def test_namespace_response_name_translated_back(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        """Model calls 'crm.get_orders', provider translates back to 'get_orders'."""
        mock_client.responses.create.return_value = _make_response(
            output=[_make_function_call("crm.get_orders", '{"id":"123"}', call_id="call_1")],
            usage=_USAGE,
        )
        tools = [
            Tool(
                name="get_orders",
                description="List orders",
                input_schema={"type": "object", "properties": {"id": {"type": "string"}}},
                extra={"openai": {"namespace": "crm"}},
            ),
        ]
        request = LLMRequest(
            model="gpt-5.4",
            messages=[UserMessage(blocks=[TextBlock(text="list orders")])],
            tools=tools,
        )
        result = await provider.call(request)

        assert result.stop_reason == StopReason.TOOL_USE
        tool_use = result.message.blocks[0]
        assert isinstance(tool_use, ToolUseBlock)
        assert tool_use.name == "get_orders"  # translated back from crm.get_orders

    async def test_multiple_namespaces(self, provider: OpenAIResponsesProvider, mock_client: AsyncMock) -> None:
        mock_client.responses.create.return_value = _make_response(output=[_make_output_message("Hi")], usage=_USAGE)
        tools = [
            Tool(
                name="get_orders",
                description="List orders",
                input_schema={"type": "object", "properties": {}},
                extra={"openai": {"namespace": "crm"}},
            ),
            Tool(
                name="delete_user",
                description="Delete user",
                input_schema={"type": "object", "properties": {}},
                extra={"openai": {"namespace": "admin"}},
            ),
        ]
        request = LLMRequest(
            model="gpt-5.4",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
            tools=tools,
            extra={"openai": {"namespaces": {"crm": "CRM tools", "admin": "Admin tools"}}},
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        api_tools = call_kwargs["tools"]
        assert len(api_tools) == 2
        ns_names = {t["name"] for t in api_tools}
        assert ns_names == {"crm", "admin"}


class TestMessageConversion:
    async def test_system_messages_become_instructions(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        mock_client.responses.create.return_value = _make_response(output=[_make_output_message("Hi")], usage=_USAGE)
        request = LLMRequest(
            model="gpt-4.1-mini",
            system=[
                SystemMessage(blocks=[TextBlock(text="You are helpful.")]),
                SystemMessage(blocks=[TextBlock(text="Be concise.")]),
            ],
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        assert call_kwargs["instructions"] == "You are helpful.\n\nBe concise."

    async def test_user_text_message(self, provider: OpenAIResponsesProvider, mock_client: AsyncMock) -> None:
        mock_client.responses.create.return_value = _make_response(output=[_make_output_message("Hi")], usage=_USAGE)
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        input_items = call_kwargs["input"]
        assert input_items[0] == {"role": "user", "content": [{"type": "input_text", "text": "hello"}]}

    async def test_tool_result_becomes_function_call_output(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        mock_client.responses.create.return_value = _make_response(output=[_make_output_message("Sunny")], usage=_USAGE)
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[
                UserMessage(blocks=[TextBlock(text="Weather?")]),
                AssistantMessage(
                    blocks=[
                        ToolUseBlock(id="call_abc", name="get_weather", input='{"city":"Paris"}'),
                    ]
                ),
                UserMessage(
                    blocks=[
                        ToolResultBlock(tool_use_id="call_abc", content="Sunny, 22C"),
                    ]
                ),
            ],
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        items = call_kwargs["input"]
        assert items[0]["role"] == "user"
        assert items[1]["type"] == "function_call"
        assert items[1]["call_id"] == "call_abc"
        assert items[2]["type"] == "function_call_output"
        assert items[2]["output"] == "Sunny, 22C"

    async def test_tool_result_error_prepends_prefix(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        mock_client.responses.create.return_value = _make_response(output=[_make_output_message("Sorry")], usage=_USAGE)
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[
                UserMessage(
                    blocks=[
                        ToolResultBlock(tool_use_id="call_1", content="not found", is_error=True),
                    ]
                ),
            ],
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        assert call_kwargs["input"][0]["output"] == "Error: not found"

    async def test_max_tokens_becomes_max_output_tokens(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        mock_client.responses.create.return_value = _make_response(output=[_make_output_message("Hi")], usage=_USAGE)
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
            max_tokens=1024,
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        assert call_kwargs["max_output_tokens"] == 1024
        assert "max_tokens" not in call_kwargs

    async def test_image_block_converted_to_input_image(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        mock_client.responses.create.return_value = _make_response(output=[_make_output_message("Hi")], usage=_USAGE)
        image_data = b"\x89PNG\r\n\x1a\n"
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[
                UserMessage(blocks=[MediaBlock(data=image_data, media_type="image/png")]),
            ],
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        input_items = call_kwargs["input"]
        content = input_items[0]["content"]
        assert len(content) == 1
        assert content[0]["type"] == "input_image"
        expected_b64 = base64.b64encode(image_data).decode()
        assert content[0]["image_url"] == f"data:image/png;base64,{expected_b64}"


class TestResponseConversion:
    async def test_text_response(self, provider: OpenAIResponsesProvider, mock_client: AsyncMock) -> None:
        mock_client.responses.create.return_value = _make_response(
            output=[_make_output_message("Hello world!")], usage=_USAGE
        )
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
        )
        result = await provider.call(request)

        assert result.stop_reason == StopReason.END_TURN
        assert len(result.message.blocks) == 1
        assert isinstance(result.message.blocks[0], TextBlock)
        assert result.message.blocks[0].text == "Hello world!"

    async def test_tool_use_response(self, provider: OpenAIResponsesProvider, mock_client: AsyncMock) -> None:
        mock_client.responses.create.return_value = _make_response(
            output=[_make_function_call("get_weather", '{"city":"Paris"}', call_id="call_xyz")],
            usage=_USAGE,
        )
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[UserMessage(blocks=[TextBlock(text="weather")])],
            tools=[Tool(name="get_weather", description="", input_schema=None)],
        )
        result = await provider.call(request)

        assert result.stop_reason == StopReason.TOOL_USE
        tool_uses = [b for b in result.message.blocks if isinstance(b, ToolUseBlock)]
        assert len(tool_uses) == 1
        assert tool_uses[0].name == "get_weather"
        assert tool_uses[0].id == "call_xyz"
        assert tool_uses[0].input == '{"city":"Paris"}'

    async def test_mixed_text_and_tool_response(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        mock_client.responses.create.return_value = _make_response(
            output=[
                _make_output_message("Let me check..."),
                _make_function_call("get_weather", '{"city":"Paris"}'),
            ],
            usage=_USAGE,
        )
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[UserMessage(blocks=[TextBlock(text="weather?")])],
        )
        result = await provider.call(request)

        assert result.stop_reason == StopReason.TOOL_USE
        assert len(result.message.blocks) == 2
        assert isinstance(result.message.blocks[0], TextBlock)
        assert isinstance(result.message.blocks[1], ToolUseBlock)

    async def test_incomplete_status_maps_to_max_tokens(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        mock_client.responses.create.return_value = _make_response(
            output=[_make_output_message("partial...")],
            status="incomplete",
            usage=_USAGE,
        )
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
        )
        result = await provider.call(request)

        assert result.stop_reason == StopReason.MAX_TOKENS

    async def test_usage_with_cache(self, provider: OpenAIResponsesProvider, mock_client: AsyncMock) -> None:
        mock_client.responses.create.return_value = _make_response(
            output=[_make_output_message("Hi")],
            usage={"input_tokens": 100, "output_tokens": 50, "cached_tokens": 20},
        )
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
        )
        result = await provider.call(request)

        assert result.usage is not None
        assert result.usage.input_tokens == 80  # 100 - 20 cached
        assert result.usage.output_tokens == 50
        assert result.usage.cache_read_input_tokens == 20

    async def test_response_extra_contains_id(self, provider: OpenAIResponsesProvider, mock_client: AsyncMock) -> None:
        mock_client.responses.create.return_value = _make_response(
            output=[_make_output_message("Hi")],
            usage=_USAGE,
            response_id="resp_abc123",
        )
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[UserMessage(blocks=[TextBlock(text="hello")])],
        )
        result = await provider.call(request)

        assert result.extra["id"] == "resp_abc123"

    async def test_json_schema_passed_as_text_format(
        self, provider: OpenAIResponsesProvider, mock_client: AsyncMock
    ) -> None:
        mock_client.responses.create.return_value = _make_response(
            output=[_make_output_message('{"cities":["Paris"]}')],
            usage=_USAGE,
        )
        schema = {
            "type": "object",
            "properties": {"cities": {"type": "array", "items": {"type": "string"}}},
            "required": ["cities"],
        }
        request = LLMRequest(
            model="gpt-4.1-mini",
            messages=[UserMessage(blocks=[TextBlock(text="list cities")])],
            json_schema=schema,
        )
        await provider.call(request)

        call_kwargs = mock_client.responses.create.call_args.kwargs
        text_format = call_kwargs["text"]["format"]
        assert text_format["type"] == "json_schema"
        assert text_format["name"] == "response"
        assert text_format["strict"] is True
        # Schema is transformed to strict mode
        assert text_format["schema"]["additionalProperties"] is False
