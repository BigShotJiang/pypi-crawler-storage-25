import pytest

from flowra.llm import CostBreakdown, Usage


class TestCostBreakdown:
    def test_defaults_to_zero(self) -> None:
        cb = CostBreakdown()
        assert cb.input == 0.0
        assert cb.output == 0.0
        assert cb.cache_read == 0.0
        assert cb.cache_creation == 0.0

    def test_total_sums_all_fields(self) -> None:
        cb = CostBreakdown(input=0.01, output=0.02, cache_read=0.003, cache_creation=0.004)
        assert cb.total == pytest.approx(0.037)

    def test_total_zero_when_empty(self) -> None:
        assert CostBreakdown().total == 0.0

    def test_add_sums_per_category(self) -> None:
        a = CostBreakdown(input=0.01, output=0.02, cache_read=0.003, cache_creation=0.004)
        b = CostBreakdown(input=0.05, output=0.06, cache_read=0.007, cache_creation=0.008)
        result = a + b
        assert result.input == pytest.approx(0.06)
        assert result.output == pytest.approx(0.08)
        assert result.cache_read == pytest.approx(0.010)
        assert result.cache_creation == pytest.approx(0.012)

    def test_add_with_defaults(self) -> None:
        a = CostBreakdown(input=0.01)
        b = CostBreakdown(output=0.02)
        result = a + b
        assert result.input == pytest.approx(0.01)
        assert result.output == pytest.approx(0.02)
        assert result.cache_read == 0.0
        assert result.cache_creation == 0.0

    def test_frozen(self) -> None:
        cb = CostBreakdown(input=0.01)
        with pytest.raises(AttributeError):
            cb.input = 0.02  # type: ignore[misc]


class TestUsageAddWithCost:
    def test_sums_cost_both_present(self) -> None:
        a = Usage(
            input_tokens=10,
            output_tokens=20,
            cost=CostBreakdown(input=0.01, output=0.02),
        )
        b = Usage(
            input_tokens=5,
            output_tokens=10,
            cost=CostBreakdown(input=0.03, output=0.04),
        )
        result = a + b
        assert result.cost is not None
        assert result.cost.input == pytest.approx(0.04)
        assert result.cost.output == pytest.approx(0.06)

    def test_cost_one_none_preserves_other(self) -> None:
        cb = CostBreakdown(input=0.01, output=0.02)
        a = Usage(input_tokens=1, output_tokens=1, cost=cb)
        b = Usage(input_tokens=1, output_tokens=1)
        assert (a + b).cost is cb
        assert (b + a).cost is cb

    def test_cost_both_none(self) -> None:
        a = Usage(input_tokens=1, output_tokens=1)
        b = Usage(input_tokens=1, output_tokens=1)
        assert (a + b).cost is None

    def test_cost_and_cost_usd_independent(self) -> None:
        a = Usage(
            input_tokens=1,
            output_tokens=1,
            cost_usd=0.05,
            cost=CostBreakdown(input=0.02, output=0.03),
        )
        b = Usage(
            input_tokens=1,
            output_tokens=1,
            cost_usd=0.10,
            cost=CostBreakdown(input=0.04, output=0.06),
        )
        result = a + b
        assert result.cost_usd == pytest.approx(0.15)
        assert result.cost is not None
        assert result.cost.total == pytest.approx(0.15)
