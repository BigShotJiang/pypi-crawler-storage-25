from flowra.llm import TextBlock


class TestMetadata:
    def test_separate_instances_have_independent_metadata(self) -> None:
        a = TextBlock(text="a")
        b = TextBlock(text="b")
        assert a.metadata is not b.metadata
