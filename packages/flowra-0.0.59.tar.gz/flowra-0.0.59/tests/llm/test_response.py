import pytest

from flowra.llm import Usage


class TestUsageAdd:
    def test_sums_all_token_fields(self) -> None:
        a = Usage(input_tokens=10, output_tokens=20, cache_read_input_tokens=5)
        b = Usage(input_tokens=3, output_tokens=7, cache_read_input_tokens=2)
        result = a + b
        assert result.input_tokens == 13
        assert result.output_tokens == 27
        assert result.cache_read_input_tokens == 7

    def test_sums_cache_creation_fields(self) -> None:
        a = Usage(
            input_tokens=1,
            output_tokens=1,
            cache_creation_input_tokens=10,
            extra={"cache_creation_5m_input_tokens": 5, "cache_creation_1h_input_tokens": 3},
        )
        b = Usage(
            input_tokens=1,
            output_tokens=1,
            cache_creation_input_tokens=20,
            extra={"cache_creation_5m_input_tokens": 15, "cache_creation_1h_input_tokens": 7},
        )
        result = a + b
        assert result.cache_creation_input_tokens == 30
        assert result.extra["cache_creation_5m_input_tokens"] == 20
        assert result.extra["cache_creation_1h_input_tokens"] == 10

    def test_merges_extra_numeric_values(self) -> None:
        a = Usage(input_tokens=1, output_tokens=1, extra={"custom_tokens": 10})
        b = Usage(input_tokens=1, output_tokens=1, extra={"custom_tokens": 5})
        result = a + b
        assert result.extra["custom_tokens"] == 15

    def test_merges_extra_non_numeric_values(self) -> None:
        a = Usage(input_tokens=1, output_tokens=1, extra={"model": "old"})
        b = Usage(input_tokens=1, output_tokens=1, extra={"model": "new"})
        result = a + b
        assert result.extra["model"] == "new"

    def test_merges_extra_disjoint_keys(self) -> None:
        a = Usage(input_tokens=1, output_tokens=1, extra={"a": 1})
        b = Usage(input_tokens=1, output_tokens=1, extra={"b": 2})
        result = a + b
        assert result.extra == {"a": 1, "b": 2}

    def test_empty_extras(self) -> None:
        a = Usage(input_tokens=10, output_tokens=20)
        b = Usage(input_tokens=5, output_tokens=10)
        result = a + b
        assert result.extra == {}

    def test_merges_extra_float_values(self) -> None:
        a = Usage(input_tokens=1, output_tokens=1, extra={"score": 1.5})
        b = Usage(input_tokens=1, output_tokens=1, extra={"score": 2.3})
        result = a + b
        assert result.extra["score"] == pytest.approx(3.8)

    def test_sums_cost_usd_both_present(self) -> None:
        a = Usage(input_tokens=1, output_tokens=1, cost_usd=0.01)
        b = Usage(input_tokens=1, output_tokens=1, cost_usd=0.02)
        result = a + b
        assert result.cost_usd == pytest.approx(0.03)

    def test_cost_usd_one_none(self) -> None:
        a = Usage(input_tokens=1, output_tokens=1, cost_usd=0.05)
        b = Usage(input_tokens=1, output_tokens=1)
        assert (a + b).cost_usd == pytest.approx(0.05)
        assert (b + a).cost_usd == pytest.approx(0.05)

    def test_cost_usd_both_none(self) -> None:
        a = Usage(input_tokens=1, output_tokens=1)
        b = Usage(input_tokens=1, output_tokens=1)
        assert (a + b).cost_usd is None
