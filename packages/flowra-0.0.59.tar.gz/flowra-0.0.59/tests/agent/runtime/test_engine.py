import dataclasses
from typing import Any

import pytest

from flowra.agent import (
    Agent,
    AgentStore,
    CallAgent,
    CallStep,
    ChildOutput,
    GotoAgent,
    GotoStep,
    Scalar,
    ServiceLocator,
    Spawn,
    step,
)
from flowra.agent.definition import AgentDefinition, AgentInstance, AgentRegistry, CallStepHandler
from flowra.agent.runtime.engine import Completed, Engine, Progressed
from flowra.agent.runtime.execution import ExecutionStatus
from flowra.agent.runtime.instance_factory import create_instance_sealed
from flowra.agent.runtime.scope import NamedScopeRegistry, RuntimeScope, ScopeData


def _scope_factory(parent_services: dict[type, Any], persistent: ScopeData | None = None) -> RuntimeScope:
    return RuntimeScope(
        parent_services=parent_services, named_scope_registry=NamedScopeRegistry(), persistent=persistent
    )


def _instance_factory(
    defn: AgentDefinition, scope: RuntimeScope, services: dict[type, Any], agent_spec: Any | None = None
) -> AgentInstance:
    return create_instance_sealed(defn, scope, services, agent_spec)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Val:
    v: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class TSpec:
    msg: str


def _defn(handler: CallStepHandler, entry_step: str = "run") -> AgentDefinition:
    def create(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
        return AgentInstance(call_step=handler)

    return AgentDefinition(steps={}, type_registry={}, create_instance=create, entry_step=entry_step)


def _engine(agents: dict[str, Any]) -> Engine:
    return Engine(
        registry=AgentRegistry(agents),
        scope_factory=_scope_factory,
        instance_factory=_instance_factory,
    )


class TestAdvanceSingleStep:
    async def test_completed_in_one_tick(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        engine = _engine({"a": _defn(handler)})
        root = await engine.build_root("a", "start")
        result = await engine.advance(root)
        assert isinstance(result, Completed)
        assert isinstance(result.result, Val)
        assert result.result.v == "ok"


class TestAdvanceGotoStep:
    async def test_progressed_then_completed(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "a":
                return GotoStep(step="b")
            return Val(v="done")

        engine = _engine({"x": _defn(handler)})
        root = await engine.build_root("x", "a")

        r1 = await engine.advance(root)
        assert isinstance(r1, Progressed)
        assert root.status == ExecutionStatus.PENDING_STEP
        assert root.pending_step == "b"

        r2 = await engine.advance(root)
        assert isinstance(r2, Completed)


class TestAdvanceGotoAgent:
    async def test_replaces_node_in_place(self) -> None:
        async def ha(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return GotoAgent(agent="/b")

        async def hb(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="from_b")

        engine = _engine({"a": _defn(ha), "b": _defn(hb, entry_step="run")})
        root = await engine.build_root("a", "go")

        r1 = await engine.advance(root)
        assert isinstance(r1, Progressed)
        assert root.agent_name == "b"
        assert root.pending_step == "run"

        r2 = await engine.advance(root)
        assert isinstance(r2, Completed)
        assert isinstance(r2.result, Val)
        assert r2.result.v == "from_b"


class TestSpawnTreeShape:
    async def test_spawn_creates_children_nodes(self) -> None:
        async def parent(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "start":
                return Spawn(
                    children=[
                        CallAgent(agent="/c", spec=TSpec(msg="1"), state="c1"),
                        CallAgent(agent="/c", spec=TSpec(msg="2"), state="c2"),
                    ],
                    then="join",
                )
            assert child_outputs is not None
            return Val(v=",".join(r.result.v for r in child_outputs))  # type: ignore[union-attr]

        async def child(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            assert isinstance(spec, TSpec)
            return Val(v=spec.msg)

        engine = _engine({"p": _defn(parent), "c": _defn(child, entry_step="work")})
        root = await engine.build_root("p", "start")

        # Tick 1: parent spawns
        r1 = await engine.advance(root)
        assert isinstance(r1, Progressed)
        assert root.status == ExecutionStatus.WAITING_CHILDREN
        assert root.children is not None
        assert len(root.children) == 2
        assert all(c.status == ExecutionStatus.PENDING_STEP for c in root.children)
        assert root.then_step == "join"

        # Tick 2: children execute in parallel (propagation deferred to next tick)
        r2 = await engine.advance(root)
        assert isinstance(r2, Progressed)
        assert root.status == ExecutionStatus.WAITING_CHILDREN
        assert root.children is not None
        assert all(c.status == ExecutionStatus.COMPLETED for c in root.children)

        # Tick 3: propagation collapses children → parent becomes PENDING_STEP("join") → join executes → completed
        r3 = await engine.advance(root)
        assert isinstance(r3, Completed)
        assert isinstance(r3.result, Val)
        assert r3.result.v == "1,2"


class TestSpawnCallStepFork:
    async def test_fork_children_and_collect(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "start":
                return Spawn(
                    children=[
                        CallStep(step="task", spec=TSpec(msg="a")),
                        CallStep(step="task", spec=TSpec(msg="b")),
                    ],
                    then="join",
                )
            if tag == "task":
                assert isinstance(spec, TSpec)
                return Val(v=spec.msg)
            assert child_outputs is not None
            return Val(v="+".join(r.result.v for r in child_outputs))  # type: ignore[union-attr]

        engine = _engine({"x": _defn(handler)})
        root = await engine.build_root("x", "start")

        await engine.advance(root)  # spawn
        await engine.advance(root)  # children + propagate
        r = await engine.advance(root)  # join
        assert isinstance(r, Completed)
        assert isinstance(r.result, Val)
        assert r.result.v == "a+b"


class TestParallelExecution:
    async def test_multiple_children_run_in_same_tick(self) -> None:
        call_order: list[str] = []

        async def parent(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "start":
                return Spawn(
                    children=[
                        CallAgent(agent="/c", spec=TSpec(msg="1"), state="c1"),
                        CallAgent(agent="/c", spec=TSpec(msg="2"), state="c2"),
                        CallAgent(agent="/c", spec=TSpec(msg="3"), state="c3"),
                    ],
                    then="join",
                )
            return Val(v="done")

        async def child(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            assert isinstance(spec, TSpec)
            call_order.append(spec.msg)
            return Val(v=spec.msg)

        engine = _engine({"p": _defn(parent), "c": _defn(child, entry_step="w")})
        root = await engine.build_root("p", "start")

        await engine.advance(root)  # spawn
        await engine.advance(root)  # all 3 children in one tick

        # All 3 children were called in the same tick
        assert len(call_order) == 3
        assert set(call_order) == {"1", "2", "3"}


class TestServicePropagation:
    async def test_parent_provides_service_child_sees_it(self) -> None:
        received_services: dict[type, Any] = {}

        async def parent(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "start":
                return Spawn(
                    children=[CallAgent(agent="/c")],
                    then="join",
                )
            return Val(v="done")

        def create_parent(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
            sl.provide(str, "hello_service")

            async def h(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                return await parent(tag, spec, child_outputs)

            return AgentInstance(call_step=h)

        def create_child(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
            received_services.update(sl.services)

            async def h(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                return Val(v="child_done")

            return AgentInstance(call_step=h)

        parent_defn = AgentDefinition(steps={}, type_registry={}, create_instance=create_parent, entry_step="start")
        child_defn = AgentDefinition(steps={}, type_registry={}, create_instance=create_child, entry_step="work")
        engine = _engine({"p": parent_defn, "c": child_defn})
        root = await engine.build_root("p", "start")

        await engine.advance(root)  # spawn
        await engine.advance(root)  # children
        await engine.advance(root)  # join

        assert str in received_services
        assert received_services[str] == "hello_service"

    async def test_goto_agent_does_not_inherit_local_provides(self) -> None:
        sibling_services: dict[type, Any] = {}

        def create_a(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
            sl.provide(int, 42)

            async def h(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                return GotoAgent(agent="/b")

            return AgentInstance(call_step=h)

        def create_b(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
            sibling_services.update(sl.services)

            async def h(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                return Val(v="b")

            return AgentInstance(call_step=h)

        defn_a = AgentDefinition(steps={}, type_registry={}, create_instance=create_a, entry_step="go")
        defn_b = AgentDefinition(steps={}, type_registry={}, create_instance=create_b, entry_step="run")
        engine = _engine({"a": defn_a, "b": defn_b})
        root = await engine.build_root("a", "go")

        await engine.advance(root)  # goto agent b
        await engine.advance(root)  # b completes

        assert int not in sibling_services


class TestNodeIds:
    async def test_root_has_root_node_id(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        engine = _engine({"a": _defn(handler)})
        root = await engine.build_root("a", "start")
        assert root.node_id == "root"

    async def test_children_get_indexed_node_ids(self) -> None:
        async def parent(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "start":
                return Spawn(
                    children=[
                        CallAgent(agent="/c", state="c0"),
                        CallAgent(agent="/c", state="c1"),
                        CallAgent(agent="/c", state="c2"),
                    ],
                    then="join",
                )
            return Val(v="done")

        async def child(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        engine = _engine({"p": _defn(parent), "c": _defn(child, entry_step="w")})
        root = await engine.build_root("p", "start")
        await engine.advance(root)  # spawn

        assert root.children is not None
        assert root.children[0].node_id == "root.0"
        assert root.children[1].node_id == "root.1"
        assert root.children[2].node_id == "root.2"

    async def test_goto_agent_preserves_node_id(self) -> None:
        async def ha(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return GotoAgent(agent="/b")

        async def hb(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="from_b")

        engine = _engine({"a": _defn(ha), "b": _defn(hb, entry_step="run")})
        root = await engine.build_root("a", "go")

        await engine.advance(root)  # goto agent b
        assert root.node_id == "root"
        assert root.agent_name == "b"


class TestUnknownAgent:
    async def test_build_root_raises_key_error(self) -> None:
        engine = _engine({})
        with pytest.raises(KeyError):
            await engine.build_root("nonexistent", "start")


class TestPersistentKeyPassthrough:
    async def test_persistent_key_from_call_agent_passes_to_child(self) -> None:
        async def parent(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "start":
                return Spawn(
                    children=[CallAgent(agent="/c", state="child-key")],
                    then="join",
                )
            return Val(v="done")

        async def child(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        engine = _engine({"p": _defn(parent), "c": _defn(child, entry_step="work")})
        root = await engine.build_root("p", "start")
        await engine.advance(root)  # spawn

        assert root.children is not None
        assert root.children[0].persistent_key == "child-key"

    async def test_root_persistent_key(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        engine = _engine({"a": _defn(handler)})
        root = await engine.build_root("a", "start", persistent_key="root-key")
        assert root.persistent_key == "root-key"


class TestPersistentKeyUniqueness:
    async def test_duplicate_persistent_key_raises(self) -> None:
        async def parent(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "start":
                return Spawn(
                    children=[
                        CallAgent(agent="/c", state="dup"),
                        CallAgent(agent="/c", state="dup"),
                    ],
                    then="join",
                )
            return Val(v="done")

        async def child(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        engine = _engine({"p": _defn(parent), "c": _defn(child, entry_step="work")})
        root = await engine.build_root("p", "start")

        with pytest.raises(ValueError, match="Duplicate"):
            await engine.advance(root)

    async def test_persistent_key_released_after_child_completion(self) -> None:
        """After children complete and are cleaned up, their persistent_keys are released."""
        call_count = 0

        async def parent(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            nonlocal call_count
            call_count += 1
            if tag == "start":
                return Spawn(
                    children=[CallAgent(agent="/c", state="reusable")],
                    then="mid",
                )
            if tag == "mid":
                # Second spawn reusing the same persistent_key
                return Spawn(
                    children=[CallAgent(agent="/c", state="reusable")],
                    then="join",
                )
            return Val(v="done")

        async def child(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        engine = _engine({"p": _defn(parent), "c": _defn(child, entry_step="w")})
        root = await engine.build_root("p", "start")

        await engine.advance(root)  # spawn first batch
        await engine.advance(root)  # children complete, propagate → mid
        await engine.advance(root)  # mid spawns second batch with same key (should not raise)
        await engine.advance(root)  # children complete, propagate → join
        r = await engine.advance(root)  # join completes
        assert isinstance(r, Completed)


# -- Type-based agent resolution ----------------------------------------------


class _AgentB(Agent[None, Val]):
    @step(entry=True)
    async def run(self) -> Val:
        return Val(v="from_b")

    @step
    async def work(self) -> Val:
        return Val(v="child_ok")


class TestTypeResolution:
    async def test_goto_agent_with_type(self) -> None:
        async def ha(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            return GotoAgent(agent=_AgentB)

        engine = _engine({"a": _defn(ha), "b": _AgentB})
        root = await engine.build_root("a", "go")
        await engine.advance(root)  # goto agent b
        assert root.agent_name == "b"
        r = await engine.advance(root)
        assert isinstance(r, Completed)
        assert isinstance(r.result, Val)
        assert r.result.v == "from_b"

    async def test_call_agent_with_type_in_spawn(self) -> None:
        async def parent(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            if tag == "start":
                return Spawn(
                    children=[CallAgent(agent=_AgentB)],
                    then="join",
                )
            return Val(v="done")

        engine = _engine({"p": _defn(parent), "c": _AgentB})
        root = await engine.build_root("p", "start")
        await engine.advance(root)  # spawn
        await engine.advance(root)  # child completes
        r = await engine.advance(root)  # join
        assert isinstance(r, Completed)

    async def test_unregistered_type_raises_key_error(self) -> None:
        async def handler(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            return GotoAgent(agent=_AgentB)

        engine = _engine({"a": _defn(handler)})
        root = await engine.build_root("a", "go")
        with pytest.raises(KeyError):
            await engine.advance(root)


# -- Goto persistent_key tests ------------------------------------------------


class TestGotoPersistentKey:
    async def test_goto_same_agent_keeps_persistent_key(self) -> None:
        """Goto within same agent keeps current persistent_key."""

        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "a":
                return GotoStep(step="b")
            return Val(v="done")

        engine = _engine({"x": _defn(handler)})
        root = await engine.build_root("x", "a", persistent_key="my-key")

        await engine.advance(root)  # goto b
        assert root.persistent_key == "my-key"

    async def test_goto_cross_agent_defaults_to_agent_name(self) -> None:
        """Goto to different agent without explicit state defaults persistent_key to agent name."""

        async def ha(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            return GotoAgent(agent="/b")

        async def hb(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            return Val(v="from_b")

        engine = _engine({"a": _defn(ha), "b": _defn(hb, entry_step="run")})
        root = await engine.build_root("a", "go", persistent_key="original")

        await engine.advance(root)  # goto agent b
        assert root.persistent_key == "b"

    async def test_goto_cross_agent_explicit_state(self) -> None:
        """Goto to different agent with explicit state uses that key."""

        async def ha(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            return GotoAgent(agent="/b", state="explicit")

        async def hb(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            return Val(v="from_b")

        engine = _engine({"a": _defn(ha), "b": _defn(hb, entry_step="run")})
        root = await engine.build_root("a", "go", persistent_key="original")

        await engine.advance(root)  # goto agent b
        assert root.persistent_key == "explicit"

    async def test_goto_uses_target_agent_name_as_key(self) -> None:
        """GotoAgent without explicit state uses the target agent name as persistent_key."""
        goto_count = 0

        async def ha(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            nonlocal goto_count
            goto_count += 1
            if goto_count <= 2:
                return GotoAgent(agent="/b")
            return Val(v="done")

        async def hb(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            return GotoAgent(agent="/a")

        engine = _engine(
            {
                "a": _defn(ha, entry_step="go"),
                "b": _defn(hb, entry_step="go"),
            }
        )
        root = await engine.build_root("a", "go")

        await engine.advance(root)  # a → b
        assert root.persistent_key == "b"

        await engine.advance(root)  # b → a
        assert root.persistent_key == "a"

        await engine.advance(root)  # a → b
        assert root.persistent_key == "b"


# -- Scope semantics for Call (slots) -----------------------------------------


def _defn_with_counter(handler_factory: Any) -> AgentDefinition:
    """Build an AgentDefinition with a 'counter' Scalar slot in ephemeral scope."""

    def create(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
        store: AgentStore = sl.services[AgentStore]
        counter = store.ephemeral.slot(Scalar[int], "counter")
        return handler_factory(counter)

    return AgentDefinition(
        steps={},
        type_registry={},
        create_instance=create,
        entry_step="start",
    )


class TestCallStepScopeSemantics:
    async def test_same_agent_no_storage_key_shares_parent_scope(self) -> None:
        """Same-agent Call without storage_key shares parent's scope."""
        child_values: list[int] = []
        parent_values_after: list[int] = []

        def make_handler(counter: Any) -> AgentInstance:
            async def handler(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                if tag == "start":
                    counter.set(42)
                    return Spawn(
                        children=[CallStep(step="task")],
                        then="join",
                    )
                if tag == "task":
                    child_values.append(counter.get(0))
                    counter.set(99)
                    return Val(v="ok")
                parent_values_after.append(counter.get(0))
                return Val(v="done")

            return AgentInstance(call_step=handler)

        defn = _defn_with_counter(make_handler)
        engine = _engine({"x": defn})
        root = await engine.build_root("x", "start")

        await engine.advance(root)  # start sets counter=42, spawns
        await engine.advance(root)  # child runs, sees 42, sets 99
        await engine.advance(root)  # join

        assert child_values == [42]  # child sees parent's state
        assert parent_values_after == [99]  # parent sees child's mutation (shared scope)

    async def test_same_agent_with_fork_ephemeral_gets_isolated_copy(self) -> None:
        """Same-agent Call with fork_ephemeral=True gets a copy — child sees parent state but mutations are isolated."""
        child_values: list[int] = []
        parent_values_after: list[int] = []

        def make_handler(counter: Any) -> AgentInstance:
            async def handler(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                if tag == "start":
                    counter.set(42)
                    return Spawn(
                        children=[CallStep(step="task", fork_ephemeral=True)],
                        then="join",
                    )
                if tag == "task":
                    child_values.append(counter.get(0))
                    counter.set(99)
                    return Val(v="ok")
                parent_values_after.append(counter.get(0))
                return Val(v="done")

            return AgentInstance(call_step=handler)

        defn = _defn_with_counter(make_handler)
        engine = _engine({"x": defn})
        root = await engine.build_root("x", "start")

        await engine.advance(root)  # start sets counter=42, spawns
        await engine.advance(root)  # child runs, sees 42, sets 99
        await engine.advance(root)  # join

        assert child_values == [42]  # child inherited parent's state via fork
        assert parent_values_after == [42]  # parent NOT affected by child's mutation


class TestScopeRestoreCallback:
    async def test_scope_restore_called_on_build_root(self) -> None:
        """scope_restore callback is invoked when building root node."""
        calls: list[tuple[str | None, str, str]] = []

        async def restore(scope: RuntimeScope, persistent_key: str | None, node_id: str, agent_name: str) -> None:
            calls.append((persistent_key, node_id, agent_name))

        async def handler(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            return Val(v="done")

        engine = Engine(
            registry=AgentRegistry({"a": _defn(handler)}),
            scope_factory=_scope_factory,
            instance_factory=_instance_factory,
            scope_restore=restore,
        )
        await engine.build_root("a", "run", persistent_key="root")

        assert len(calls) == 1
        assert calls[0] == ("root", "root", "a")

    async def test_scope_restore_called_on_goto_agent(self) -> None:
        """scope_restore callback is invoked when GotoAgent creates a new node."""
        calls: list[tuple[str | None, str, str]] = []

        async def restore(scope: RuntimeScope, persistent_key: str | None, node_id: str, agent_name: str) -> None:
            calls.append((persistent_key, node_id, agent_name))

        async def ha(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            return GotoAgent(agent="/b")

        async def hb(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            return Val(v="done")

        engine = Engine(
            registry=AgentRegistry({"a": _defn(ha), "b": _defn(hb)}),
            scope_factory=_scope_factory,
            instance_factory=_instance_factory,
            scope_restore=restore,
        )
        root = await engine.build_root("a", "run")

        calls.clear()
        await engine.advance(root)  # GotoAgent → b

        assert len(calls) == 1
        assert calls[0][2] == "b"  # agent_name

    async def test_scope_restore_called_on_spawn_children(self) -> None:
        """scope_restore callback is invoked for each spawned child."""
        calls: list[tuple[str | None, str, str]] = []

        async def restore(scope: RuntimeScope, persistent_key: str | None, node_id: str, agent_name: str) -> None:
            calls.append((persistent_key, node_id, agent_name))

        async def parent_handler(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            if tag == "start":
                return Spawn(
                    children=[
                        CallAgent(agent="/child", state="c1"),
                        CallAgent(agent="/child", state="c2"),
                    ],
                    then="join",
                )
            return Val(v="done")

        async def child_handler(
            tag: str, spec: Any = None, child_outputs: list[ChildOutput] | None = None, agent_spec: Any = None
        ) -> Any:
            return Val(v="child")

        engine = Engine(
            registry=AgentRegistry(
                {
                    "parent": _defn(parent_handler, entry_step="start"),
                    "child": _defn(child_handler),
                }
            ),
            scope_factory=_scope_factory,
            instance_factory=_instance_factory,
            scope_restore=restore,
        )
        root = await engine.build_root("parent", "start")

        calls.clear()
        await engine.advance(root)  # spawn creates 2 children

        assert len(calls) == 2
        assert {c[0] for c in calls} == {"c1", "c2"}  # persistent_keys
        assert all(c[2] == "child" for c in calls)  # agent_names
