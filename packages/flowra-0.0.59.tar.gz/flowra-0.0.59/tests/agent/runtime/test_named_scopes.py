"""Tests for named scope functionality on RuntimeScope."""

from flowra.agent import AppendOnlyList, Scalar, Scope
from flowra.agent.runtime.scope import NamedScopeRegistry, RuntimeScope


class TestScopeAccess:
    def test_scope_returns_scope_type(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        handle = scope.scope("session")
        assert isinstance(handle, Scope)

    def test_scope_slot_creates_in_named_scope(self) -> None:
        registry = NamedScopeRegistry()
        scope = RuntimeScope(named_scope_registry=registry)
        scope.scope("session").slot(Scalar[int], "counter")

        # Named scope has the slot
        named = registry.get_or_create("session")
        assert named.get_slot_value_types() == {"counter": int}

        # Local scope does NOT have the slot
        assert scope.ephemeral.get_slot_value_types() == {}

    def test_same_scope_same_key_returns_same_instance(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        s1 = scope.scope("session").slot(Scalar[int], "x")
        s2 = scope.scope("session").slot(Scalar[int], "x")
        assert s1 is s2

    def test_named_scope_changes_separate_from_local(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        local = scope.ephemeral.slot(Scalar[int], "x")
        shared = scope.scope("session").slot(Scalar[int], "y")

        local.set(1)
        shared.set(2)

        # Local scope changes only include local slots
        local_changes = scope.ephemeral.get_changes()
        assert "x" in local_changes.scalars
        assert "y" not in local_changes.scalars

    def test_named_scope_has_own_changes(self) -> None:
        registry = NamedScopeRegistry()
        scope = RuntimeScope(named_scope_registry=registry)
        scope.ephemeral.slot(Scalar[int], "local").set(10)
        scope.scope("session").slot(Scalar[int], "shared").set(20)

        named = registry.get_or_create("session")
        named_changes = named.get_changes()
        assert named_changes.scalars == {"shared": 20}

    def test_multiple_named_scopes(self) -> None:
        registry = NamedScopeRegistry()
        scope = RuntimeScope(named_scope_registry=registry)

        scope.scope("a").slot(Scalar[int], "x").set(1)
        scope.scope("b").slot(Scalar[str], "y").set("hello")

        a = registry.get_or_create("a")
        b = registry.get_or_create("b")
        assert a.get_changes().scalars == {"x": 1}
        assert b.get_changes().scalars == {"y": "hello"}


class TestForkWithNamedScopes:
    def test_fork_shares_named_registry(self) -> None:
        registry = NamedScopeRegistry()
        parent = RuntimeScope(named_scope_registry=registry)
        parent.scope("session").slot(Scalar[int], "x").set(42)

        child = parent.fork_ephemeral()
        child_slot = child.scope("session").slot(Scalar[int], "x")
        assert child_slot.get() == 42  # Same slot, same data

    def test_fork_does_not_copy_named_scope(self) -> None:
        registry = NamedScopeRegistry()
        parent = RuntimeScope(named_scope_registry=registry)
        shared = parent.scope("session").slot(Scalar[int], "x")
        shared.set(10)

        child = parent.fork_ephemeral()
        child_shared = child.scope("session").slot(Scalar[int], "x")

        # Both point to the same slot
        assert child_shared is shared

        # Child's write is visible to parent
        child_shared.set(20)
        assert shared.get() == 20

    def test_fork_copies_local_but_not_named(self) -> None:
        registry = NamedScopeRegistry()
        parent = RuntimeScope(named_scope_registry=registry)
        parent.ephemeral.slot(Scalar[int], "local").set(100)
        parent.scope("session").slot(Scalar[int], "shared").set(200)

        child = parent.fork_ephemeral()

        # Local is copied (independent)
        child.ephemeral.slot(Scalar[int], "local").set(999)
        assert parent.ephemeral.slot(Scalar[int], "local").get() == 100

        # Named scope is shared (same instance)
        child.scope("session").slot(Scalar[int], "shared").set(999)
        assert parent.scope("session").slot(Scalar[int], "shared").get() == 999


class TestNamedScopeWithAppendOnly:
    def test_append_only_in_named_scope(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        log = scope.scope("session").slot(AppendOnlyList[str], "log")
        log.append("entry1")
        log.append("entry2")
        assert log.get_all() == ["entry1", "entry2"]

    def test_shared_append_only(self) -> None:
        registry = NamedScopeRegistry()
        scope1 = RuntimeScope(named_scope_registry=registry)
        scope2 = RuntimeScope(named_scope_registry=registry)

        log1 = scope1.scope("session").slot(AppendOnlyList[str], "log")
        log2 = scope2.scope("session").slot(AppendOnlyList[str], "log")

        log1.append("from_agent_1")
        log2.append("from_agent_2")

        assert log1.get_all() == ["from_agent_1", "from_agent_2"]
        assert log1 is log2
