"""Tests for named scope persistence: save, hydrate, resume."""

import dataclasses

from flowra.agent import Agent, AgentRuntime, AgentStore, AppendOnlyList, InMemorySessionStorage, Scalar, step


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Spec:
    value: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Result:
    output: str


class TestNamedScopePersistence:
    async def test_named_scope_saved_and_loaded(self) -> None:
        """Named scope data persists across runtime.run() calls."""

        class WriterAgent(Agent[Spec, Result]):
            def __init__(self, store: AgentStore) -> None:
                self.log = store.scope("session").slot(AppendOnlyList[str], "log")

            @step(entry=True)
            async def write(self, spec: Spec) -> Result:
                self.log.append(spec.value)
                return Result(output=f"wrote {spec.value}")

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"writer": WriterAgent}, storage=storage)

        await runtime.run(agent=WriterAgent, spec=Spec(value="hello"))
        await runtime.run(agent=WriterAgent, spec=Spec(value="world"))

        # Named scope data stored under the scope name directly
        state = await storage.load("session")
        assert state is not None
        assert "log" in state
        assert len(state["log"]) == 2

    async def test_named_scope_hydrated_on_second_run(self) -> None:
        """Agent sees data from previous run via named scope."""

        class AccumulatorAgent(Agent[Spec, Result]):
            def __init__(self, store: AgentStore) -> None:
                self.items = store.scope("shared").slot(AppendOnlyList[str], "items")

            @step(entry=True)
            async def run(self, spec: Spec) -> Result:
                count_before = len(self.items.get_all())
                self.items.append(spec.value)
                return Result(output=f"before={count_before}")

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"acc": AccumulatorAgent}, storage=storage)

        r1 = await runtime.run(agent=AccumulatorAgent, spec=Spec(value="a"))
        assert r1.output == "before=0"

        r2 = await runtime.run(agent=AccumulatorAgent, spec=Spec(value="b"))
        assert r2.output == "before=1"

        r3 = await runtime.run(agent=AccumulatorAgent, spec=Spec(value="c"))
        assert r3.output == "before=2"

    async def test_named_scope_dirty_tracking(self) -> None:
        """Only dirty named scope data is saved."""

        class WriterAgent(Agent[Spec, Result]):
            def __init__(self, store: AgentStore) -> None:
                self.counter = store.scope("stats").slot(Scalar[int], "total")

            @step(entry=True)
            async def write(self, spec: Spec) -> Result:
                current = self.counter.get(0)
                self.counter.set(current + 1)
                return Result(output=str(current + 1))

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"w": WriterAgent}, storage=storage)

        await runtime.run(agent=WriterAgent, spec=Spec(value="x"))
        state = await storage.load("stats")
        assert state is not None
        assert state["total"] == 1

        await runtime.run(agent=WriterAgent, spec=Spec(value="y"))
        state = await storage.load("stats")
        assert state is not None
        assert state["total"] == 2

    async def test_multiple_named_scopes_persisted_independently(self) -> None:
        """Different named scopes have different storage keys."""

        class MultiScopeAgent(Agent[Spec, Result]):
            def __init__(self, store: AgentStore) -> None:
                self.chat = store.scope("chat").slot(AppendOnlyList[str], "messages")
                self.audit = store.scope("audit").slot(AppendOnlyList[str], "events")

            @step(entry=True)
            async def run(self, spec: Spec) -> Result:
                self.chat.append(f"msg:{spec.value}")
                self.audit.append(f"evt:{spec.value}")
                return Result(output="ok")

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"multi": MultiScopeAgent}, storage=storage)

        await runtime.run(agent=MultiScopeAgent, spec=Spec(value="hi"))

        chat_state = await storage.load("chat")
        audit_state = await storage.load("audit")
        assert chat_state is not None
        assert audit_state is not None
        assert chat_state["messages"] == ["msg:hi"]
        assert audit_state["events"] == ["evt:hi"]

    async def test_named_scope_with_dataclass_serialization(self) -> None:
        """Dataclass types in named scopes are serialized correctly."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Entry:
            text: str
            score: int

        class EntryAgent(Agent[Spec, Result]):
            def __init__(self, store: AgentStore) -> None:
                self.entries = store.scope("data").slot(AppendOnlyList[Entry], "entries")

            @step(entry=True)
            async def run(self, spec: Spec) -> Result:
                self.entries.append(Entry(text=spec.value, score=len(spec.value)))
                return Result(output="ok")

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"entry": EntryAgent}, storage=storage)

        await runtime.run(agent=EntryAgent, spec=Spec(value="hello"))
        await runtime.run(agent=EntryAgent, spec=Spec(value="world"))

        state = await storage.load("data")
        assert state is not None
        assert len(state["entries"]) == 2

    async def test_local_and_named_scope_coexist(self) -> None:
        """Agent can use both local and named scope slots."""

        class HybridAgent(Agent[Spec, Result]):
            def __init__(self, store: AgentStore) -> None:
                self.local_count = store.persistent.slot(Scalar[int], "count")
                self.shared_log = store.scope("session").slot(AppendOnlyList[str], "log")

            @step(entry=True)
            async def run(self, spec: Spec) -> Result:
                c = self.local_count.get(0)
                self.local_count.set(c + 1)
                self.shared_log.append(f"{c}:{spec.value}")
                return Result(output=str(c + 1))

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"hybrid": HybridAgent}, storage=storage)

        await runtime.run(agent=HybridAgent, spec=Spec(value="a"))
        await runtime.run(agent=HybridAgent, spec=Spec(value="b"))

        # Local scope under "hybrid" (agent name is the default key)
        local_state = await storage.load("hybrid")
        assert local_state is not None
        assert local_state["count"] == 2

        # Named scope under "session"
        session_state = await storage.load("session")
        assert session_state is not None
        assert session_state["log"] == ["0:a", "1:b"]

    async def test_named_scope_with_dataclass_types_hydrates(self) -> None:
        """Named scope slots with dataclass types (UserMessage, AssistantMessage)
        hydrate correctly via lazy per-slot deserialization.

        Regression: previously, named scope type_registry was empty, causing
        'Unknown type tag' errors during hydration on second run.
        """
        from flowra.llm import AssistantMessage, TextBlock, UserMessage

        class ChatHistoryAgent(Agent[Spec, Result]):
            __slots__ = ("__history",)

            def __init__(self, store: AgentStore) -> None:
                conversation = store["conversation"]
                self.__history = conversation.slot(AppendOnlyList[UserMessage | AssistantMessage], "history")

            @step(entry=True)
            async def run(self, spec: Spec) -> Result:
                self.__history.append(UserMessage.text(spec.value))
                self.__history.append(AssistantMessage(blocks=[TextBlock(text=f"reply to {spec.value}")]))
                return Result(output=str(len(self.__history)))

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"chat": ChatHistoryAgent}, storage=storage)

        r1 = await runtime.run(agent=ChatHistoryAgent, spec=Spec(value="hello"))
        assert isinstance(r1, Result)
        assert r1.output == "2"

        # Second run: named scope hydrates lazily — previously failed with 'Unknown type tag'
        r2 = await runtime.run(agent=ChatHistoryAgent, spec=Spec(value="world"))
        assert isinstance(r2, Result)
        assert r2.output == "4"
