from flowra.agent.runtime.scope import NamedScopeRegistry


class TestGetOrCreate:
    def test_same_name_returns_same_scope(self) -> None:
        registry = NamedScopeRegistry()
        scope_a = registry.get_or_create("session")
        scope_b = registry.get_or_create("session")
        assert scope_a is scope_b

    def test_different_names_return_different_scopes(self) -> None:
        registry = NamedScopeRegistry()
        scope_a = registry.get_or_create("session")
        scope_b = registry.get_or_create("audit")
        assert scope_a is not scope_b

    def test_all_scopes_returns_created(self) -> None:
        registry = NamedScopeRegistry()
        registry.get_or_create("a")
        registry.get_or_create("b")
        scopes = registry.all_scopes()
        assert set(scopes.keys()) == {"a", "b"}
