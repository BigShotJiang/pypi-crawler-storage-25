"""Test that ephemeral scopes are isolated between sibling agents."""

import dataclasses
from typing import ClassVar

from flowra.agent import (
    Agent,
    AgentDefinitionRef,
    AgentRuntime,
    AgentStore,
    CallAgent,
    InMemorySessionStorage,
    Scalar,
    ServiceLocator,
    Spawn,
    step,
)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Spec:
    value: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Result:
    output: str


class CounterService:
    """Service that wraps an ephemeral slot. Created per-agent over its own store."""

    __slots__ = ("__counter",)

    def __init__(self, store: AgentStore) -> None:
        self.__counter = store.ephemeral.slot(Scalar[int], "counter")

    def get(self) -> int | None:
        return self.__counter.get() if self.__counter.has_value() else None

    def set(self, value: int) -> None:
        self.__counter.set(value)


class WriterAgent(Agent[Spec, Result]):
    """Writes a value into CounterService."""

    __slots__ = ("__svc",)

    def __init__(self, store: AgentStore, services: ServiceLocator) -> None:
        svc = CounterService(store)
        self.__svc = svc
        services.provide(svc)

    @step(entry=True)
    async def run(self, spec: Spec) -> Result:
        self.__svc.set(42)
        return Result(output="written")


class ReaderAgent(Agent[Spec, Result]):
    """Reads the current value from CounterService — should be empty (own ephemeral)."""

    __slots__ = ("__svc",)

    def __init__(self, store: AgentStore, services: ServiceLocator) -> None:
        svc = CounterService(store)
        self.__svc = svc
        services.provide(svc)

    @step(entry=True)
    async def run(self, spec: Spec) -> Result:
        value = self.__svc.get()
        return Result(output=f"value={value}")


class RootAgent(Agent[Spec, Result]):
    """Spawns WriterAgent, then ReaderAgent sequentially."""

    __slots__ = ()
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
        "writer": WriterAgent,
        "reader": ReaderAgent,
    }

    @step(entry=True)
    async def start(self, spec: Spec) -> Spawn:
        return Spawn(
            children=[CallAgent(agent=WriterAgent, spec=spec)],
            then=self.after_write,
        )

    @step("after_write")
    async def after_write(self, result: Result) -> Spawn:
        return Spawn(
            children=[CallAgent(agent=ReaderAgent, spec=Spec(value="read"))],
            then=self.finish,
        )

    @step("finish")
    async def finish(self, result: Result) -> Result:
        return result


class TestEphemeralIsolation:
    async def test_sibling_agents_have_isolated_ephemeral_scopes(self) -> None:
        """WriterAgent writes to ephemeral counter, ReaderAgent reads its own — should be None.

        Uses storage to ensure ephemeral data is persisted and the isolation
        is tested at the storage level, not just in-memory.
        """
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(
            agents={"root": RootAgent, "writer": WriterAgent, "reader": ReaderAgent},
            storage=storage,
        )
        result = await runtime.run(agent=RootAgent, spec=Spec(value="test"))
        assert isinstance(result, Result)
        # ReaderAgent should see None — its ephemeral scope is separate from WriterAgent's
        assert result.output == "value=None"
