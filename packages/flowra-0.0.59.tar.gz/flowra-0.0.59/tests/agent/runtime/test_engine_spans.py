"""Tests for engine span lifecycle (AgentSpan / StepSpan)."""

import dataclasses
from typing import Any

import pytest

from flowra.agent import AgentSpan, ChildOutput, Event, GotoAgent, GotoStep, SpanExitHandler, StepSpan
from flowra.agent.definition import AgentDefinition, AgentInstance, AgentRegistry, CallStepHandler
from flowra.agent.flow.hooks import HooksImpl, HookSubscription
from flowra.agent.runtime.engine import Completed, Engine, Progressed
from flowra.agent.runtime.instance_factory import create_instance_sealed
from flowra.agent.runtime.scope import NamedScopeRegistry, RuntimeScope, ScopeData


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Val:
    v: str


def _scope_factory(parent_services: dict[type, Any], persistent: ScopeData | None = None) -> RuntimeScope:
    return RuntimeScope(
        parent_services=parent_services, named_scope_registry=NamedScopeRegistry(), persistent=persistent
    )


def _instance_factory(
    defn: AgentDefinition, scope: RuntimeScope, services: dict[type, Any], agent_spec: Any | None = None
) -> AgentInstance:
    return create_instance_sealed(defn, scope, services, agent_spec)


def _defn(handler: CallStepHandler, entry_step: str = "run") -> AgentDefinition:
    def create(sl: Any, agent_spec: Any | None = None) -> AgentInstance:
        return AgentInstance(call_step=handler)

    return AgentDefinition(steps={}, type_registry={}, create_instance=create, entry_step=entry_step)


def _engine_with_hooks(agents: dict[str, Any], sub: HookSubscription) -> Engine:
    return Engine(
        registry=AgentRegistry(agents),
        scope_factory=_scope_factory,
        instance_factory=_instance_factory,
        services={HookSubscription: sub},
    )


class TestSimpleAgentSpans:
    async def test_agent_and_step_spans_opened_and_closed(self) -> None:
        """AgentSpan opened at create, StepSpan opened, both closed on completion with result."""
        events: list[str] = []

        def agent_span_handler(event: Event[AgentSpan]) -> SpanExitHandler:
            span = event.data
            events.append(f"agent_enter:{span.agent_info.path}")

            def on_end(error: BaseException | None = None) -> None:
                events.append(f"agent_exit:{span.agent_info.path}:result={span.result}")

            return on_end

        def step_span_handler(event: Event[StepSpan]) -> SpanExitHandler:
            span = event.data
            events.append(f"step_enter:{span.step}")

            def on_end(error: BaseException | None = None) -> None:
                events.append(f"step_exit:{span.step}:result={span.result}")

            return on_end

        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        sub = HooksImpl()
        sub.on_span(AgentSpan, agent_span_handler)
        sub.on_span(StepSpan, step_span_handler)

        engine = _engine_with_hooks({"a": _defn(handler)}, sub)
        root = await engine.build_root("a", "run")

        # After build_root, both spans should be open
        assert events == ["agent_enter:a", "step_enter:run"]

        result = await engine.advance(root)
        assert isinstance(result, Completed)

        # Both spans closed with the result
        assert events == [
            "agent_enter:a",
            "step_enter:run",
            "step_exit:run:result=Val(v='ok')",
            "agent_exit:a:result=Val(v='ok')",
        ]


class TestGotoStepSpans:
    async def test_step_span_closed_and_reopened_on_goto_step(self) -> None:
        """StepSpan closed with GotoStep result, new StepSpan opened for next step."""
        events: list[str] = []

        def agent_span_handler(event: Event[AgentSpan]) -> SpanExitHandler:
            span = event.data
            events.append(f"agent_enter:{span.agent_info.path}")

            def on_end(error: BaseException | None = None) -> None:
                events.append(f"agent_exit:{span.agent_info.path}")

            return on_end

        def step_span_handler(event: Event[StepSpan]) -> SpanExitHandler:
            span = event.data
            events.append(f"step_enter:{span.step}")

            def on_end(error: BaseException | None = None) -> None:
                events.append(f"step_exit:{span.step}:result={span.result}")

            return on_end

        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "a":
                return GotoStep(step="b")
            return Val(v="done")

        sub = HooksImpl()
        sub.on_span(AgentSpan, agent_span_handler)
        sub.on_span(StepSpan, step_span_handler)

        engine = _engine_with_hooks({"x": _defn(handler, entry_step="a")}, sub)
        root = await engine.build_root("x", "a")

        assert events == ["agent_enter:x", "step_enter:a"]

        # Advance: GotoStep closes step "a", opens step "b"
        r1 = await engine.advance(root)
        assert isinstance(r1, Progressed)
        assert events == [
            "agent_enter:x",
            "step_enter:a",
            "step_exit:a:result=GotoStep(step='b', spec=None)",
            "step_enter:b",
        ]

        # Advance: step "b" completes
        r2 = await engine.advance(root)
        assert isinstance(r2, Completed)
        assert events[-2:] == [
            "step_exit:b:result=Val(v='done')",
            "agent_exit:x",
        ]


class TestGotoAgentSpans:
    async def test_spans_closed_and_reopened_on_goto_agent(self) -> None:
        """StepSpan + AgentSpan closed, new AgentSpan + StepSpan opened for new agent."""
        events: list[str] = []

        def agent_span_handler(event: Event[AgentSpan]) -> SpanExitHandler:
            span = event.data
            events.append(f"agent_enter:{span.agent_info.path}")

            def on_end(error: BaseException | None = None) -> None:
                events.append(f"agent_exit:{span.agent_info.path}")

            return on_end

        def step_span_handler(event: Event[StepSpan]) -> SpanExitHandler:
            span = event.data
            events.append(f"step_enter:{span.step}")

            def on_end(error: BaseException | None = None) -> None:
                events.append(f"step_exit:{span.step}")

            return on_end

        async def ha(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return GotoAgent(agent="/b")

        async def hb(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="from_b")

        sub = HooksImpl()
        sub.on_span(AgentSpan, agent_span_handler)
        sub.on_span(StepSpan, step_span_handler)

        engine = _engine_with_hooks({"a": _defn(ha, entry_step="go"), "b": _defn(hb, entry_step="run")}, sub)
        root = await engine.build_root("a", "go")

        assert events == ["agent_enter:a", "step_enter:go"]

        # GotoAgent: close step + agent for "a", open agent + step for "b"
        r1 = await engine.advance(root)
        assert isinstance(r1, Progressed)
        assert events == [
            "agent_enter:a",
            "step_enter:go",
            "step_exit:go",
            "agent_exit:a",
            "agent_enter:b",
            "step_enter:run",
        ]

        # "b" completes
        r2 = await engine.advance(root)
        assert isinstance(r2, Completed)
        assert events[-2:] == ["step_exit:run", "agent_exit:b"]


class TestExceptionSafetySpans:
    async def test_all_spans_closed_with_error_on_advance_exception(self) -> None:
        """All spans closed with error when advance() throws."""
        events: list[str] = []

        def agent_span_handler(event: Event[AgentSpan]) -> SpanExitHandler:
            span = event.data
            events.append(f"agent_enter:{span.agent_info.path}")

            def on_end(error: BaseException | None = None) -> None:
                events.append(f"agent_exit:{span.agent_info.path}:error={error}")

            return on_end

        def step_span_handler(event: Event[StepSpan]) -> SpanExitHandler:
            span = event.data
            events.append(f"step_enter:{span.step}")

            def on_end(error: BaseException | None = None) -> None:
                events.append(f"step_exit:{span.step}:error={error}")

            return on_end

        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            raise RuntimeError("kaboom")

        sub = HooksImpl()
        sub.on_span(AgentSpan, agent_span_handler)
        sub.on_span(StepSpan, step_span_handler)

        engine = _engine_with_hooks({"a": _defn(handler)}, sub)
        root = await engine.build_root("a", "run")

        assert events == ["agent_enter:a", "step_enter:run"]

        with pytest.raises(RuntimeError, match="kaboom"):
            await engine.advance(root)

        # Both spans should be closed with the error
        assert len(events) == 4
        assert "step_exit:run:error=kaboom" in events[2]
        assert "agent_exit:a:error=kaboom" in events[3]
