import pytest

from flowra.agent import AppendOnlyList, Scalar
from flowra.agent.runtime.scope import NamedScopeRegistry, RuntimeScope, ScopeData
from flowra.agent.storage import ChangeSet


class TestScalar:
    def test_scalar_starts_unset(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        sv = scope.ephemeral.slot(Scalar[int], "x")
        assert not sv.has_value()

    def test_scalar_get_with_default(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        sv = scope.ephemeral.slot(Scalar[int], "x")
        assert sv.get(0) == 0

    def test_scalar_same_key_returns_same_instance(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        sv1 = scope.ephemeral.slot(Scalar[int], "x")
        sv2 = scope.ephemeral.slot(Scalar[int], "x")
        assert sv1 is sv2


class TestAppendOnly:
    def test_append_only_starts_empty(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        al = scope.ephemeral.slot(AppendOnlyList[str], "log")
        assert al.get_all() == []

    def test_append_only_same_key_returns_same_instance(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        al1 = scope.ephemeral.slot(AppendOnlyList[str], "log")
        al2 = scope.ephemeral.slot(AppendOnlyList[str], "log")
        assert al1 is al2


class TestSlot:
    def test_rejects_invalid_type(self) -> None:
        scope_data = ScopeData()
        with pytest.raises(TypeError, match="slot\\(\\) cls must be Scalar"):
            scope_data.slot(str, "x")  # type: ignore[arg-type]

    def test_records_value_types(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        scope.ephemeral.slot(Scalar[int], "counter")
        scope.ephemeral.slot(AppendOnlyList[str], "log")
        types = scope.ephemeral.get_slot_value_types()
        assert types == {"counter": int, "log": str}

    def test_store_slot_raises_runtime_error(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        with pytest.raises(RuntimeError, match=r"Use store\.ephemeral\.slot"):
            scope.slot(Scalar[int], "x")


class TestServices:
    def test_provide_and_get_services(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        scope.provide(str, "hello")
        assert scope.get_services() == {str: "hello"}

    def test_get_services_merges_parent(self) -> None:
        scope = RuntimeScope(parent_services={int: 42}, named_scope_registry=NamedScopeRegistry())
        scope.provide(str, "hello")
        services = scope.get_services()
        assert services == {int: 42, str: "hello"}

    def test_local_overrides_parent(self) -> None:
        scope = RuntimeScope(parent_services={str: "parent"}, named_scope_registry=NamedScopeRegistry())
        scope.provide(str, "local")
        assert scope.get_services() == {str: "local"}

    def test_provide_rejects_wrong_type(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        with pytest.raises(TypeError, match="Expected instance of str, got int"):
            scope.provide(str, 42)  # type: ignore[arg-type]

    def test_get_inherited_services_excludes_local(self) -> None:
        scope = RuntimeScope(parent_services={int: 42}, named_scope_registry=NamedScopeRegistry())
        scope.provide(str, "local")
        inherited = scope.get_inherited_services()
        assert inherited == {int: 42}
        assert str not in inherited

    def test_services_property_returns_merged(self) -> None:
        scope = RuntimeScope(parent_services={int: 42}, named_scope_registry=NamedScopeRegistry())
        scope.provide(str, "hello")
        assert scope.services == {int: 42, str: "hello"}


class TestFlush:
    async def test_flush_calls_callback(self) -> None:
        called = False

        async def cb() -> None:
            nonlocal called
            called = True

        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        scope.set_flush_callback(cb)
        await scope.flush()
        assert called

    async def test_flush_without_callback_is_noop(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        await scope.flush()  # should not raise


class TestGetChanges:
    def test_dirty_scalar_returned(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        sv = scope.ephemeral.slot(Scalar[int], "x")
        sv.set(5)
        changes = scope.ephemeral.get_changes()
        assert changes.scalars == {"x": 5}
        assert changes.appends == {}

    def test_clean_scalar_not_returned(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        scope.ephemeral.slot(Scalar[int], "x")
        changes = scope.ephemeral.get_changes()
        assert changes.scalars == {}

    def test_unflushed_appends_returned(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        al = scope.ephemeral.slot(AppendOnlyList[str], "log")
        al.append("a")
        al.append("b")
        changes = scope.ephemeral.get_changes()
        assert changes.scalars == {}
        assert changes.appends == {"log": ["a", "b"]}


class TestMarkClean:
    def test_mark_clean_clears_dirty(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        sv = scope.ephemeral.slot(Scalar[int], "x")
        sv.set(5)
        al = scope.ephemeral.slot(AppendOnlyList[str], "log")
        al.append("a")

        scope.ephemeral.mark_clean()

        changes = scope.ephemeral.get_changes()
        assert changes.scalars == {}
        assert changes.appends == {}


class TestSnapshot:
    def test_snapshot_includes_scalars_and_lists(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        sv = scope.ephemeral.slot(Scalar[int], "x")
        sv.set(42)
        al = scope.ephemeral.slot(AppendOnlyList[str], "log")
        al.append("a")
        al.append("b")

        snap = scope.ephemeral.snapshot()
        assert snap == {"x": 42, "log": ["a", "b"]}


class TestLoadRaw:
    def test_load_raw_restores_scalar(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        sv = scope.ephemeral.slot(Scalar[int], "x")
        scope.ephemeral.load_raw({"x": 42})
        assert sv.get() == 42

    def test_load_raw_restores_append_only(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        al = scope.ephemeral.slot(AppendOnlyList[str], "log")
        scope.ephemeral.load_raw({"log": ["a", "b"]})
        assert al.get_all() == ["a", "b"]

    def test_load_raw_does_not_mark_dirty(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        scope.ephemeral.slot(Scalar[int], "x")
        scope.ephemeral.load_raw({"x": 42})
        changes = scope.ephemeral.get_changes()
        assert changes.scalars == {}


class TestForkEphemeral:
    def test_fork_copies_scalar_values(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        sv = scope.ephemeral.slot(Scalar[int], "x")
        sv.set(20)

        child = scope.fork_ephemeral()
        child_sv = child.ephemeral.slot(Scalar[int], "x")
        assert child_sv.get() == 20

    def test_fork_copies_append_only(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        al = scope.ephemeral.slot(AppendOnlyList[str], "log")
        al.append("a")

        child = scope.fork_ephemeral()
        child_al = child.ephemeral.slot(AppendOnlyList[str], "log")
        assert child_al.get_all() == ["a"]

    def test_fork_child_is_independent(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        sv = scope.ephemeral.slot(Scalar[int], "x")

        child = scope.fork_ephemeral()
        child_sv = child.ephemeral.slot(Scalar[int], "x")
        child_sv.set(99)

        assert not sv.has_value()
        assert child_sv.get() == 99

    def test_fork_child_not_dirty(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        scope.ephemeral.slot(Scalar[int], "x").set(20)
        scope.ephemeral.slot(AppendOnlyList[str], "log").append("a")

        child = scope.fork_ephemeral()
        changes = child.ephemeral.get_changes()
        assert changes.scalars == {}
        assert changes.appends == {}

    def test_fork_with_parent_services(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        child = scope.fork_ephemeral(parent_services={str: "hello"})
        assert child.get_services() == {str: "hello"}

    async def test_fork_does_not_copy_flush_callback(self) -> None:
        called = False

        async def cb() -> None:
            nonlocal called
            called = True

        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        scope.set_flush_callback(cb)

        child = scope.fork_ephemeral()
        await child.flush()
        assert not called


class TestLoadRawUnknownKey:
    def test_unknown_key_skipped(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        scope.ephemeral.slot(Scalar[int], "x")
        scope.ephemeral.load_raw({"x": 42, "unknown_key": 99})
        sv = scope.ephemeral.slot(Scalar[int], "x")
        assert sv.get() == 42


class TestChangeSetEmpty:
    def test_empty_when_no_data(self) -> None:
        cs = ChangeSet(scalars={}, appends={})
        assert cs.empty is True

    def test_not_empty_with_scalars(self) -> None:
        cs = ChangeSet(scalars={"x": 1}, appends={})
        assert cs.empty is False

    def test_not_empty_with_appends(self) -> None:
        cs = ChangeSet(scalars={}, appends={"log": ["a"]})
        assert cs.empty is False
