import dataclasses

from flowra.agent import Agent, AgentInfo, Event, ExecutionContext, ExecutionFrame, SpanExitHandler
from flowra.agent.flow.hooks import HooksImpl


@dataclasses.dataclass(slots=True, kw_only=True)
class SampleEvent:
    value: int
    extra: str = ""


@dataclasses.dataclass(slots=True, kw_only=True)
class OtherEvent:
    name: str


def _test_context(path: str = "test") -> ExecutionContext:
    """Build a hierarchical ExecutionContext — every prefix of ``path`` becomes a frame.

    ``"app/parent/child"`` produces a stack of three frames (``app``, ``app/parent``,
    ``app/parent/child``) so ancestor-based filters can match naturally.
    """
    parts = path.split("/")
    frames: list[ExecutionFrame] = []
    for i in range(len(parts)):
        partial = "/".join(parts[: i + 1])
        info = AgentInfo(name=parts[i], path=partial, source_type=None, parent=None)
        frames.append(ExecutionFrame(agent=info))
    return ExecutionContext(frame=frames[-1], stack=tuple(frames))


def _hooks(root: HooksImpl | None = None, path: str = "test") -> HooksImpl:
    r = root or HooksImpl()
    return r.for_agent(_test_context(path))


class TestHookSubscription:
    def test_on_registers_handler(self) -> None:
        root = HooksImpl()
        hooks = _hooks(root)
        assert not hooks.has_handlers(SampleEvent)
        root.on(SampleEvent, lambda e: None)
        # Dynamic: newly registered global handler is visible
        assert hooks.has_handlers(SampleEvent)
        assert not hooks.has_handlers(OtherEvent)


class TestHooks:
    async def test_emit_no_handlers(self) -> None:
        hooks = _hooks()
        result = await hooks.emit(SampleEvent(value=42))
        assert result.value == 42

    async def test_sync_handler_called(self) -> None:
        received: list[Event[SampleEvent]] = []

        def handler(event: Event[SampleEvent]) -> None:
            received.append(event)

        root = HooksImpl()
        root.on(SampleEvent, handler)
        hooks = _hooks(root)
        await hooks.emit(SampleEvent(value=7))

        assert len(received) == 1
        assert received[0].data.value == 7

    async def test_async_handler_called(self) -> None:
        received: list[int] = []

        async def handler(event: Event[SampleEvent]) -> None:
            received.append(event.data.value)

        root = HooksImpl()
        root.on(SampleEvent, handler)
        hooks = _hooks(root)
        await hooks.emit(SampleEvent(value=99))

        assert received == [99]

    async def test_multiple_handlers_called_in_order(self) -> None:
        order: list[str] = []

        root = HooksImpl()
        root.on(SampleEvent, lambda e: order.append("first"))
        root.on(SampleEvent, lambda e: order.append("second"))
        root.on(SampleEvent, lambda e: order.append("third"))
        hooks = _hooks(root)
        await hooks.emit(SampleEvent(value=0))

        assert order == ["first", "second", "third"]

    async def test_has_handlers(self) -> None:
        root = HooksImpl()
        hooks = _hooks(root)
        assert not hooks.has_handlers(SampleEvent)

        root.on(SampleEvent, lambda e: None)
        assert hooks.has_handlers(SampleEvent)
        assert not hooks.has_handlers(OtherEvent)

    async def test_handler_mutation_visible(self) -> None:
        def mutate(event: Event[SampleEvent]) -> None:
            event.data.extra = "mutated"

        root = HooksImpl()
        root.on(SampleEvent, mutate)
        hooks = _hooks(root)
        result = await hooks.emit(SampleEvent(value=1))

        assert result.extra == "mutated"

    async def test_context_stamped(self) -> None:
        agent_info = AgentInfo(name="test", path="root/test", source_type=Agent, parent=None)
        frame = ExecutionFrame(agent=agent_info, spec=None)
        context = ExecutionContext(frame=frame, stack=(frame,))
        received_contexts: list[ExecutionContext] = []

        def handler(event: Event[SampleEvent]) -> None:
            received_contexts.append(event.context)

        root = HooksImpl()
        root.on(SampleEvent, handler)
        hooks = root.for_agent(context)
        await hooks.emit(SampleEvent(value=1))

        assert len(received_contexts) == 1
        assert received_contexts[0] is context
        assert received_contexts[0].frame.agent.source_type is Agent
        assert received_contexts[0].frame.agent.path == "root/test"


class TestScopedSubscription:
    """Tests for Hooks.on() — scoped subscription to sub-agent events."""

    async def test_scoped_handler_fires_for_descendants(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value))

        child = _hooks(root, path="app/parent/child")
        await child.emit(SampleEvent(value=42))

        assert received == [42]

    async def test_scoped_handler_not_fired_for_self(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value))

        # Scoped handler excludes self (inclusive=False)
        await parent.emit(SampleEvent(value=99))
        assert received == []

    async def test_scoped_handler_not_fired_for_self_even_with_new_hooks(self) -> None:
        """Even if new Hooks is created for the same path after on(), self is excluded."""
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value))

        # New hooks for the same path — should still NOT include scoped handler
        parent_new = _hooks(root, path="app/parent")
        await parent_new.emit(SampleEvent(value=99))
        assert received == []

    async def test_scoped_handler_not_fired_for_siblings(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value))

        sibling = _hooks(root, path="app/sibling")
        await sibling.emit(SampleEvent(value=99))
        assert received == []

    async def test_scope_string_filters_to_child(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value), scope="child_a")

        child_a = _hooks(root, path="app/parent/child_a")
        child_b = _hooks(root, path="app/parent/child_b")

        await child_a.emit(SampleEvent(value=1))
        await child_b.emit(SampleEvent(value=2))

        assert received == [1]

    async def test_scope_string_includes_grandchildren(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value), scope="child")

        grandchild = _hooks(root, path="app/parent/child/grandchild")
        await grandchild.emit(SampleEvent(value=7))

        assert received == [7]

    async def test_scope_agent_type(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value), during=Agent)

        # Build a real hierarchy where a descendant frame has source_type=Agent.
        app = AgentInfo(name="app", path="app", source_type=None, parent=None)
        parent_info = AgentInfo(name="parent", path="app/parent", source_type=None, parent=None)
        child_info = AgentInfo(name="child", path="app/parent/child", source_type=Agent, parent=None)
        stack = (ExecutionFrame(agent=app), ExecutionFrame(agent=parent_info), ExecutionFrame(agent=child_info))
        child_ctx = ExecutionContext(frame=stack[-1], stack=stack)
        child = root.for_agent(child_ctx)
        await child.emit(SampleEvent(value=5))
        assert received == [5]

    async def test_scope_agent_type_no_match(self) -> None:
        """Type scope doesn't fire if no matching agent type in stack."""
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value), during=Agent)

        # Child without source_type=Agent
        child = _hooks(root, path="app/parent/child")
        await child.emit(SampleEvent(value=5))
        assert received == []

    async def test_global_type_scope(self) -> None:
        """scope=AgentType on root (runtime.hooks) fires for any matching agent."""
        received: list[int] = []
        root = HooksImpl()

        root.on(SampleEvent, lambda e: received.append(e.data.value), during=Agent)

        child_info = AgentInfo(name="child", path="app/child", source_type=Agent, parent=None)
        child_frame = ExecutionFrame(agent=child_info)
        child_ctx = ExecutionContext(frame=child_frame, stack=(child_frame,))
        child = root.for_agent(child_ctx)
        await child.emit(SampleEvent(value=42))
        assert received == [42]

    async def test_global_type_scope_no_match(self) -> None:
        """scope=AgentType on root does not fire if agent type doesn't match."""
        received: list[int] = []
        root = HooksImpl()

        root.on(SampleEvent, lambda e: received.append(e.data.value), during=Agent)

        child = _hooks(root, path="app/child")  # source_type=None
        await child.emit(SampleEvent(value=99))
        assert received == []

    async def test_global_and_scoped_coexist(self) -> None:
        global_received: list[int] = []
        scoped_received: list[int] = []
        root = HooksImpl()

        root.on(SampleEvent, lambda e: global_received.append(e.data.value))

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: scoped_received.append(e.data.value))

        child = _hooks(root, path="app/parent/child")
        await child.emit(SampleEvent(value=10))

        assert global_received == [10]
        assert scoped_received == [10]

    async def test_has_handlers_includes_scoped(self) -> None:
        root = HooksImpl()
        child = _hooks(root, path="app/parent/child")
        assert not child.has_handlers(SampleEvent)

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: None)

        # Dynamic: child now sees the scoped handler
        assert child.has_handlers(SampleEvent)
        # Sibling does not
        sibling_child = _hooks(root, path="app/sibling/child")
        assert not sibling_child.has_handlers(SampleEvent)

    async def test_clear_scoped(self) -> None:
        root = HooksImpl()
        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: None)
        parent.on_span(SampleEvent, lambda e: None)
        parent.on(SampleEvent, lambda e: None, during=Agent)
        parent.on_span(SampleEvent, lambda e: None, during=Agent)

        child = _hooks(root, path="app/parent/child")
        assert child.has_handlers(SampleEvent)
        assert child.has_span_handlers(SampleEvent)
        root.clear_scoped()
        assert not child.has_handlers(SampleEvent)
        assert not child.has_span_handlers(SampleEvent)

    async def test_scoped_on_span_path(self) -> None:
        """on_span with path scope fires for descendants."""
        entered: list[int] = []
        exited: list[int] = []

        @dataclasses.dataclass
        class Span:
            value: int
            result: str | None = None

        def handler(event: Event[Span]) -> SpanExitHandler:
            entered.append(event.data.value)

            def on_end(error: BaseException | None = None) -> None:
                exited.append(event.data.value)

            return on_end

        root = HooksImpl()
        parent = _hooks(root, path="app/parent")
        parent.on_span(Span, handler, scope="child")

        child = _hooks(root, path="app/parent/child")
        span = await child.open_span(Span(value=1))
        span.result = "ok"
        await child.close_span(span)

        assert entered == [1]
        assert exited == [1]

        # Sibling should not fire
        sibling = _hooks(root, path="app/parent/other")
        await sibling.open_span(Span(value=2))
        assert entered == [1]

    async def test_scoped_on_span_type(self) -> None:
        """on_span with type scope fires only when matching agent type in stack."""
        entered: list[int] = []

        @dataclasses.dataclass
        class Span:
            value: int

        root = HooksImpl()
        parent = _hooks(root, path="app/parent")
        parent.on_span(Span, lambda e: entered.append(e.data.value), during=Agent)

        # Child WITH matching source_type
        app = AgentInfo(name="app", path="app", source_type=None, parent=None)
        parent_info = AgentInfo(name="parent", path="app/parent", source_type=None, parent=None)
        child_info = AgentInfo(name="child", path="app/parent/child", source_type=Agent, parent=None)
        stack = (ExecutionFrame(agent=app), ExecutionFrame(agent=parent_info), ExecutionFrame(agent=child_info))
        child_ctx = ExecutionContext(frame=stack[-1], stack=stack)
        child = root.for_agent(child_ctx)
        await child.open_span(Span(value=10))
        assert entered == [10]

        # Child WITHOUT matching source_type — should not fire
        other = _hooks(root, path="app/parent/other")
        await other.open_span(Span(value=20))
        assert entered == [10]


# -- scope / during — filesystem-style paths, registry vs call-stack semantics --


def _ctx_with_stack(frames: list[tuple[str, type | None]]) -> ExecutionContext:
    """Build an ExecutionContext from a top-down stack of (path, source_type) tuples."""
    infos = [AgentInfo(name=p.rsplit("/", 1)[-1], path=p, source_type=st, parent=None) for p, st in frames]
    exec_frames = tuple(ExecutionFrame(agent=i) for i in infos)
    return ExecutionContext(frame=exec_frames[-1], stack=exec_frames)


class TestScopePathSemantics:
    """``scope`` is an additional registry-path filter on the emitter.
    The call-stack baseline still applies: subscriber must be a strict
    ancestor in the event's stack. ``scope`` narrows further — emitter's
    path must be at or under the resolved scope.
    """

    async def test_scope_narrows_to_registry_subtree(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        sub = _hooks(root, path="app/parent")
        sub.on(SampleEvent, lambda e: received.append(e.data.value), scope="./helper")

        helper_leaf = _hooks(root, path="app/parent/helper/deep")
        await helper_leaf.emit(SampleEvent(value=5))

        # Sibling of helper — still in subscriber's call stack, but not under ./helper
        sibling = _hooks(root, path="app/parent/other")
        await sibling.emit(SampleEvent(value=6))

        assert received == [5]

    async def test_scope_absolute_path(self) -> None:
        """An absolute scope works when the emitter happens to be under that path
        *and* the subscriber is on its call stack (i.e., subscriber called into it)."""
        received: list[int] = []
        root = HooksImpl()

        sub = _hooks(root, path="app/parent")
        sub.on(SampleEvent, lambda e: received.append(e.data.value), scope="/app/parent/worker")

        # Emitter inside "/app/parent/worker" and the stack goes through subscriber.
        emitter = _hooks(root, path="app/parent/worker/leaf")
        await emitter.emit(SampleEvent(value=11))

        # Emitter elsewhere — still in subscriber's call tree but outside the scope path.
        other = _hooks(root, path="app/parent/sidecar")
        await other.emit(SampleEvent(value=12))

        assert received == [11]

    async def test_scope_dot_means_subscriber_subtree(self) -> None:
        """``scope='.'`` resolves to the subscriber's own path. Baseline still excludes
        self-emits; self cannot fire even with ``scope='.'`` because the baseline
        requires a strict ancestor."""
        received_self: list[int] = []
        received_default: list[int] = []
        root = HooksImpl()

        sub = _hooks(root, path="app/parent")
        sub.on(SampleEvent, lambda e: received_self.append(e.data.value), scope=".")
        sub.on(OtherEvent, lambda e: received_default.append(int(e.data.name)))

        # Self-emit never fires — baseline (strict ancestor) excludes self.
        await sub.emit(SampleEvent(value=1))
        await sub.emit(OtherEvent(name="1"))
        assert received_self == []
        assert received_default == []

        # Descendant — baseline passes, scope='.' also matches (emitter under subscriber).
        child = _hooks(root, path="app/parent/child")
        await child.emit(SampleEvent(value=2))
        await child.emit(OtherEvent(name="2"))
        assert received_self == [2]
        assert received_default == [2]


class TestDuringSemantics:
    """``during`` is a call-stack filter: a frame on the stack must satisfy
    the filter AND be within the subscriber's subtree."""

    async def test_during_type_matches_descendant_but_not_ancestor(self) -> None:
        """Ancestor ChatAgent on the stack must NOT trigger a subscriber's during=ChatAgent."""
        received: list[int] = []
        root = HooksImpl()

        # Subscriber at app/mid; the stack will have ChatAgent at app/chat (ancestor-position
        # in call tree) — but the subscriber's subtree is app/mid, so app/chat is out of reach.
        sub = _hooks(root, path="app/mid")
        sub.on(SampleEvent, lambda e: received.append(e.data.value), during=Agent)

        # Stack with Agent-typed ancestor above the subscriber.
        ancestor_ctx = _ctx_with_stack(
            [
                ("app", None),
                ("app/chat", Agent),  # Agent-typed ancestor
                ("app/mid", None),
                ("app/mid/leaf", None),  # emitter
            ]
        )
        emitter_a = root.for_agent(ancestor_ctx)
        await emitter_a.emit(SampleEvent(value=100))
        assert received == []

        # Stack with Agent-typed frame UNDER the subscriber.
        descendant_ctx = _ctx_with_stack(
            [
                ("app", None),
                ("app/mid", None),
                ("app/mid/chat", Agent),  # Agent-typed inside subscriber's subtree
                ("app/mid/chat/leaf", None),  # emitter
            ]
        )
        emitter_d = root.for_agent(descendant_ctx)
        await emitter_d.emit(SampleEvent(value=200))
        assert received == [200]

    async def test_during_string_path_walks_stack(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        sub = _hooks(root, path="app")
        sub.on(SampleEvent, lambda e: received.append(e.data.value), during="/app/chat")

        stack_with_chat = _ctx_with_stack(
            [
                ("app", None),
                ("app/chat", None),
                ("app/chat/sub", None),
                ("app/chat/sub/leaf", None),
            ]
        )
        await root.for_agent(stack_with_chat).emit(SampleEvent(value=11))

        stack_without_chat = _ctx_with_stack(
            [
                ("app", None),
                ("app/other", None),
                ("app/other/leaf", None),
            ]
        )
        await root.for_agent(stack_without_chat).emit(SampleEvent(value=22))

        assert received == [11]


class TestScopeAndDuringComposition:
    async def test_both_filters_must_match(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        sub = _hooks(root, path="app")
        sub.on(
            SampleEvent,
            lambda e: received.append(e.data.value),
            scope="/app/worker",
            during=Agent,
        )

        # Scope matches (emitter under app/worker) + during matches (Agent in stack within app).
        ok_ctx = _ctx_with_stack(
            [
                ("app", None),
                ("app/chat", Agent),
                ("app/chat/worker_call", None),
                ("app/worker", None),
                ("app/worker/leaf", None),
            ]
        )
        await root.for_agent(ok_ctx).emit(SampleEvent(value=1))
        assert received == [1]

        # Scope matches but no Agent in stack: during fails.
        no_during_ctx = _ctx_with_stack(
            [
                ("app", None),
                ("app/worker", None),
                ("app/worker/leaf", None),
            ]
        )
        await root.for_agent(no_during_ctx).emit(SampleEvent(value=2))
        assert received == [1]

        # During matches but emitter outside /app/worker: scope fails.
        no_scope_ctx = _ctx_with_stack(
            [
                ("app", None),
                ("app/chat", Agent),
                ("app/chat/leaf", None),
            ]
        )
        await root.for_agent(no_scope_ctx).emit(SampleEvent(value=3))
        assert received == [1]


class TestRecursiveSubscriber:
    """When the same subscriber path appears multiple times in the call stack
    (agent recursively calls itself), the baseline/during filters must anchor
    on the *nearest* occurrence — frames above that are out of reach for the
    active invocation."""

    async def test_during_scans_only_below_innermost_occurrence(self) -> None:
        """Two frames at subscriber's path on the stack: ``during`` sees only
        frames below the inner one. A type frame sitting between the outer and
        inner subscriber instances is invisible to the inner invocation."""
        received: list[int] = []
        root = HooksImpl()

        sub = _hooks(root, path="app/recursive")
        sub.on(SampleEvent, lambda e: received.append(e.data.value), during=Agent)

        # Stack: outer-subscriber → Agent-typed middle frame → inner-subscriber → emitter
        # From the INNER subscriber's perspective, the Agent-typed frame sits above it
        # and must not match ``during=Agent``.
        ctx = _ctx_with_stack(
            [
                ("app/recursive", None),  # outer
                ("app/middle", Agent),  # Agent between outer and inner
                ("app/recursive", None),  # inner
                ("app/recursive/leaf", None),  # emitter
            ]
        )
        emitter = root.for_agent(ctx)
        await emitter.emit(SampleEvent(value=42))

        assert received == []

    async def test_during_matches_when_type_below_inner(self) -> None:
        """Same recursive shape, but the Agent-typed frame is below the inner
        subscriber. Now it IS in reach and ``during=Agent`` fires."""
        received: list[int] = []
        root = HooksImpl()

        sub = _hooks(root, path="app/recursive")
        sub.on(SampleEvent, lambda e: received.append(e.data.value), during=Agent)

        ctx = _ctx_with_stack(
            [
                ("app/recursive", None),  # outer
                ("app/recursive", None),  # inner
                ("app/recursive/middle", Agent),  # Agent below inner
                ("app/recursive/leaf", None),  # emitter
            ]
        )
        emitter = root.for_agent(ctx)
        await emitter.emit(SampleEvent(value=7))

        assert received == [7]


class TestGlobalScope:
    async def test_global_absolute_scope(self) -> None:
        received: list[int] = []
        root = HooksImpl()
        root.on(SampleEvent, lambda e: received.append(e.data.value), scope="/app/target")

        inside = _hooks(root, path="app/target/leaf")
        await inside.emit(SampleEvent(value=1))

        outside = _hooks(root, path="app/elsewhere")
        await outside.emit(SampleEvent(value=2))

        assert received == [1]
