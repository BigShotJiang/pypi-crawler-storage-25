import asyncio
from typing import get_origin
from unittest.mock import patch

import pytest

from flowra.agent import AgentStore, AppendOnlyList, InterruptedError, InterruptToken, Scalar, Scope, TimeoutExpired
from flowra.agent.flow.timeout import TimeoutAgent, TimeoutSpec


class FakeInterruptToken(InterruptToken):
    def __init__(self) -> None:
        self.__interrupted = False
        self.__event = asyncio.Event()

    @property
    def interrupted(self) -> bool:
        return self.__interrupted

    def check(self) -> None:
        if self.__interrupted:
            raise InterruptedError

    async def wait(self) -> None:
        await self.__event.wait()

    def set(self) -> None:
        self.__interrupted = True
        self.__event.set()


class _FakeScope(Scope):
    def __init__(self) -> None:
        self._slots: dict[str, Scalar | AppendOnlyList] = {}  # type: ignore[type-arg]

    def slot(self, cls: type, key: str) -> Scalar | AppendOnlyList:  # type: ignore[type-arg]
        if key in self._slots:
            return self._slots[key]
        origin = get_origin(cls) or cls
        if origin is Scalar:
            s: Scalar | AppendOnlyList = Scalar()  # type: ignore[type-arg]
        elif origin is AppendOnlyList:
            s = AppendOnlyList()  # type: ignore[type-arg]
        else:
            raise TypeError(f"Unknown slot type: {cls}")
        self._slots[key] = s
        return s


class FakeAgentStore(AgentStore):
    def __init__(self) -> None:
        self._ephemeral = _FakeScope()
        self._persistent = _FakeScope()

    @property
    def ephemeral(self) -> Scope:
        return self._ephemeral

    @property
    def persistent(self) -> Scope:
        return self._persistent

    def scope(self, name: str) -> Scope:
        raise NotImplementedError

    async def flush(self) -> None:
        pass


def _make_agent(
    store: FakeAgentStore | None = None,
    interrupt: FakeInterruptToken | None = None,
) -> tuple[TimeoutAgent, FakeAgentStore, FakeInterruptToken]:
    s = store or FakeAgentStore()
    i = interrupt or FakeInterruptToken()
    return TimeoutAgent(s, i), s, i


class TestTimeoutAgent:
    async def test_expires_after_deadline(self) -> None:
        """TimeoutAgent returns TimeoutExpired when deadline passes."""
        agent, _, _ = _make_agent()
        with patch("flowra.agent.flow.timeout.time") as mock_time:
            mock_time.time.return_value = 100.0
            result = await agent.wait(TimeoutSpec(seconds=0))  # type: ignore[misc]
        assert isinstance(result, TimeoutExpired)
        assert result.seconds == 0

    async def test_short_timeout_returns_expired(self) -> None:
        """TimeoutAgent with very short timeout returns TimeoutExpired."""
        agent, _, _ = _make_agent()
        result = await agent.wait(TimeoutSpec(seconds=0.01))  # type: ignore[misc]
        assert isinstance(result, TimeoutExpired)
        assert result.seconds == 0.01

    async def test_interrupt_before_deadline_raises(self) -> None:
        """If interrupted before deadline, raises InterruptedError."""
        agent, _, interrupt = _make_agent()

        async def interrupt_soon() -> None:
            await asyncio.sleep(0.01)
            interrupt.set()

        task = asyncio.create_task(interrupt_soon())
        with pytest.raises(InterruptedError):
            await agent.wait(TimeoutSpec(seconds=10))  # type: ignore[misc]
        await task

    async def test_already_interrupted_raises(self) -> None:
        """If token is already interrupted, raises immediately."""
        interrupt = FakeInterruptToken()
        interrupt.set()
        agent, _, _ = _make_agent(interrupt=interrupt)
        with pytest.raises(InterruptedError):
            await agent.wait(TimeoutSpec(seconds=10))  # type: ignore[misc]

    async def test_deadline_persisted_and_restored(self) -> None:
        """Deadline is saved via flush and reused on re-entry."""
        store = FakeAgentStore()
        interrupt = FakeInterruptToken()
        agent, _, _ = _make_agent(store=store, interrupt=interrupt)

        # First call: deadline = 100 + 5 = 105, but we interrupt before it fires
        with patch("flowra.agent.flow.timeout.time") as mock_time:
            mock_time.time.return_value = 100.0

            async def interrupt_soon() -> None:
                await asyncio.sleep(0.01)
                interrupt.set()

            task = asyncio.create_task(interrupt_soon())
            with pytest.raises(InterruptedError):
                await agent.wait(TimeoutSpec(seconds=5))  # type: ignore[misc]
            await task

        # Second call with new interrupt token, same store: deadline already persisted
        agent2, _, _ = _make_agent(store=store)
        with patch("flowra.agent.flow.timeout.time") as mock_time:
            # Now time is past the deadline
            mock_time.time.return_value = 106.0
            result = await agent2.wait(TimeoutSpec(seconds=5))  # type: ignore[misc]

        assert isinstance(result, TimeoutExpired)
        assert result.seconds == 5
