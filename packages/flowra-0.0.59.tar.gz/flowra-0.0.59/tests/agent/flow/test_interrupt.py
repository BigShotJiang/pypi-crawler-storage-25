import asyncio
import dataclasses

import pytest

from flowra.agent import Agent, AgentRuntime, Interrupted, InterruptedError, InterruptToken, InterruptTokenSource, step


class TestInterruptTokenSource:
    def test_initial_state_is_false(self) -> None:
        source = InterruptTokenSource()
        assert source.token.interrupted is False

    def test_interrupt_makes_token_interrupted(self) -> None:
        source = InterruptTokenSource()
        source.interrupt()
        assert source.token.interrupted is True

    def test_interrupt_is_idempotent(self) -> None:
        source = InterruptTokenSource()
        source.interrupt()
        source.interrupt()
        assert source.token.interrupted is True

    def test_clear_resets_token(self) -> None:
        source = InterruptTokenSource()
        source.interrupt()
        assert source.token.interrupted is True
        source.clear()
        assert source.token.interrupted is False

    def test_check_does_not_raise_when_not_interrupted(self) -> None:
        source = InterruptTokenSource()
        source.token.check()  # should not raise

    def test_check_raises_when_interrupted(self) -> None:
        source = InterruptTokenSource()
        source.interrupt()
        with pytest.raises(InterruptedError):
            source.token.check()

    async def test_wait_returns_immediately_when_already_interrupted(self) -> None:
        source = InterruptTokenSource()
        source.interrupt()
        await source.token.wait()  # should not hang

    async def test_wait_completes_when_interrupted_concurrently(self) -> None:
        source = InterruptTokenSource()

        async def interrupt_after_delay() -> None:
            await asyncio.sleep(0.01)
            source.interrupt()

        task = asyncio.create_task(interrupt_after_delay())
        await asyncio.wait_for(source.token.wait(), timeout=1.0)
        await task
        assert source.token.interrupted is True


class TestInterruptTokenCascade:
    def test_parent_interrupt_cascades_to_child(self) -> None:
        parent = InterruptTokenSource()
        child = parent.create_child()
        parent.interrupt()
        assert child.token.interrupted is True

    def test_child_interrupt_does_not_affect_parent(self) -> None:
        parent = InterruptTokenSource()
        child = parent.create_child()
        child.interrupt()
        assert child.token.interrupted is True
        assert parent.token.interrupted is False

    def test_cascade_through_multiple_levels(self) -> None:
        root = InterruptTokenSource()
        mid = root.create_child()
        leaf = mid.create_child()
        root.interrupt()
        assert mid.token.interrupted is True
        assert leaf.token.interrupted is True

    def test_child_created_after_parent_interrupted_starts_interrupted(self) -> None:
        parent = InterruptTokenSource()
        parent.interrupt()
        child = parent.create_child()
        assert child.token.interrupted is True

    def test_clear_does_not_cascade(self) -> None:
        parent = InterruptTokenSource()
        child = parent.create_child()
        parent.interrupt()
        assert child.token.interrupted is True
        parent.clear()
        assert parent.token.interrupted is False
        # child remains interrupted — clear is not cascaded
        assert child.token.interrupted is True

    def test_multiple_children_all_receive_cascade(self) -> None:
        parent = InterruptTokenSource()
        c1 = parent.create_child()
        c2 = parent.create_child()
        c3 = parent.create_child()
        parent.interrupt()
        assert c1.token.interrupted is True
        assert c2.token.interrupted is True
        assert c3.token.interrupted is True

    def test_interrupt_one_child_leaves_siblings_unaffected(self) -> None:
        parent = InterruptTokenSource()
        c1 = parent.create_child()
        c2 = parent.create_child()
        c1.interrupt()
        assert c1.token.interrupted is True
        assert c2.token.interrupted is False
        assert parent.token.interrupted is False

    def test_dispose_removes_child_from_parent(self) -> None:
        parent = InterruptTokenSource()
        child = parent.create_child()
        child.dispose()
        parent.interrupt()
        # After dispose, child should NOT receive cascade
        assert parent.token.interrupted is True
        assert child.token.interrupted is False


class TestInterruptedResult:
    async def test_runtime_interrupt_returns_interrupted_result(self) -> None:
        """runtime.interrupt() → root agent sees InterruptedError → result is Interrupted."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Done:
            v: str

        class SlowAgent(Agent[None, Done]):
            def __init__(self, interrupt: InterruptToken) -> None:
                self.interrupt = interrupt

            @step(entry=True)
            async def run(self) -> Done:
                self.interrupt.check()
                return Done(v="ok")

        runtime = AgentRuntime(agents={"a": SlowAgent})
        runtime.interrupt()
        result = await runtime.run(agent="a")
        assert isinstance(result, Interrupted)

    async def test_interrupted_agent_returns_interrupted_not_none(self) -> None:
        """Interrupted result is Interrupted(), not None."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Done:
            v: str

        class WaitAgent(Agent[None, Done]):
            def __init__(self, interrupt: InterruptToken) -> None:
                self.interrupt = interrupt

            @step(entry=True)
            async def run(self) -> Done:
                # wait() + check() pattern: wait unblocks when interrupted,
                # then check() raises InterruptedError
                await self.interrupt.wait()
                self.interrupt.check()
                return Done(v="should not reach")

        runtime = AgentRuntime(agents={"a": WaitAgent})
        runtime.interrupt()
        result = await runtime.run(agent="a")
        assert isinstance(result, Interrupted)
