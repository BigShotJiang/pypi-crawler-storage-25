import pytest

from flowra.agent import AppendOnlyList, Scalar


class TestScalar:
    def test_get_on_unset_raises(self) -> None:
        sv: Scalar[int] = Scalar()
        with pytest.raises(LookupError, match="no value"):
            sv.get()

    def test_get_with_default_on_unset(self) -> None:
        sv: Scalar[int] = Scalar()
        assert sv.get(42) == 42

    def test_get_after_set(self) -> None:
        sv: Scalar[int] = Scalar()
        sv.set(10)
        assert sv.get() == 10

    def test_get_with_default_after_set(self) -> None:
        sv: Scalar[int] = Scalar()
        sv.set(10)
        assert sv.get(99) == 10

    def test_has_value_before_set(self) -> None:
        assert not Scalar().has_value()

    def test_has_value_after_set(self) -> None:
        sv: Scalar[int] = Scalar()
        sv.set(1)
        assert sv.has_value()

    def test_has_value_after_restore(self) -> None:
        sv: Scalar[int] = Scalar()
        sv.restore(5)
        assert sv.has_value()

    def test_not_dirty_initially(self) -> None:
        assert not Scalar().is_dirty()

    def test_dirty_after_set(self) -> None:
        sv: Scalar[int] = Scalar()
        sv.set(1)
        assert sv.is_dirty()

    def test_dirty_after_set_to_same_value(self) -> None:
        sv: Scalar[int] = Scalar()
        sv.set(0)
        assert sv.is_dirty()

    def test_mark_clean(self) -> None:
        sv: Scalar[int] = Scalar()
        sv.set(1)
        sv.mark_clean()
        assert not sv.is_dirty()

    def test_dirty_again_after_clean_then_set(self) -> None:
        sv: Scalar[int] = Scalar()
        sv.set(1)
        sv.mark_clean()
        sv.set(2)
        assert sv.is_dirty()

    def test_none_value(self) -> None:
        sv: Scalar[int | None] = Scalar()
        sv.set(None)
        assert sv.get() is None
        sv.set(5)
        assert sv.get() == 5

    def test_complex_type(self) -> None:
        sv: Scalar[dict[str, int]] = Scalar()
        sv.set({"a": 1})
        sv.set({"b": 2})
        assert sv.get() == {"b": 2}

    def test_restore_sets_value(self) -> None:
        sv: Scalar[int] = Scalar()
        sv.restore(42)
        assert sv.get() == 42

    def test_restore_not_dirty(self) -> None:
        sv: Scalar[int] = Scalar()
        sv.restore(42)
        assert not sv.is_dirty()

    def test_restore_clears_dirty(self) -> None:
        sv: Scalar[int] = Scalar()
        sv.set(1)
        assert sv.is_dirty()
        sv.restore(2)
        assert sv.get() == 2
        assert not sv.is_dirty()


class TestAppendOnlyList:
    def test_empty(self) -> None:
        assert AppendOnlyList().get_all() == []

    def test_append_and_get(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList()
        lst.append(1)
        lst.append(2)
        assert lst.get_all() == [1, 2]

    def test_get_all_returns_copy(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList()
        lst.append(1)
        result = lst.get_all()
        result.append(999)
        assert lst.get_all() == [1]

    def test_initial_items(self) -> None:
        lst: AppendOnlyList[str] = AppendOnlyList(["a", "b"])
        assert lst.get_all() == ["a", "b"]
        lst.append("c")
        assert lst.get_all() == ["a", "b", "c"]

    def test_initial_items_not_mutated(self) -> None:
        original = [1, 2]
        lst: AppendOnlyList[int] = AppendOnlyList(original)
        lst.append(3)
        assert original == [1, 2]

    def test_initial_items_are_not_unflushed(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList([1, 2])
        assert lst.get_unflushed() == []

    def test_get_unflushed_after_append(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList([1, 2])
        lst.append(3)
        lst.append(4)
        assert lst.get_unflushed() == [3, 4]

    def test_get_unflushed_returns_copy(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList()
        lst.append(1)
        unflushed = lst.get_unflushed()
        unflushed.append(999)
        assert lst.get_unflushed() == [1]

    def test_mark_clean_resets_unflushed(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList()
        lst.append(1)
        lst.append(2)
        lst.mark_clean()
        assert lst.get_unflushed() == []

    def test_append_after_clean(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList()
        lst.append(1)
        lst.mark_clean()
        lst.append(2)
        assert lst.get_all() == [1, 2]
        assert lst.get_unflushed() == [2]

    def test_accepts_tuple(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList((1, 2, 3))
        assert lst.get_all() == [1, 2, 3]

    def test_restore_replaces_items(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList([1, 2])
        lst.restore([10, 20, 30])
        assert lst.get_all() == [10, 20, 30]

    def test_restore_not_unflushed(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList()
        lst.restore([1, 2, 3])
        assert lst.get_unflushed() == []

    def test_restore_clears_unflushed(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList()
        lst.append(1)
        lst.append(2)
        assert lst.get_unflushed() == [1, 2]
        lst.restore([10, 20])
        assert lst.get_all() == [10, 20]
        assert lst.get_unflushed() == []

    def test_extend(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList([1])
        lst.extend([2, 3, 4])
        assert lst.get_all() == [1, 2, 3, 4]

    def test_extend_unflushed(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList([1])
        lst.extend([2, 3])
        assert lst.get_unflushed() == [2, 3]

    def test_extend_empty(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList([1])
        lst.extend([])
        assert lst.get_all() == [1]
        assert lst.get_unflushed() == []

    def test_extend_after_append(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList()
        lst.append(1)
        lst.extend([2, 3])
        assert lst.get_all() == [1, 2, 3]
        assert lst.get_unflushed() == [1, 2, 3]

    def test_extend_accepts_generator(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList()
        lst.extend(x * 2 for x in range(3))
        assert lst.get_all() == [0, 2, 4]

    def test_len(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList()
        assert len(lst) == 0
        lst.append(1)
        assert len(lst) == 1
        lst.extend([2, 3])
        assert len(lst) == 3

    def test_getitem(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList()
        lst.extend([10, 20, 30])
        assert lst[0] == 10
        assert lst[1] == 20
        assert lst[2] == 30
        assert lst[-1] == 30

    def test_getitem_out_of_range(self) -> None:
        lst: AppendOnlyList[int] = AppendOnlyList()
        lst.append(1)
        import pytest

        with pytest.raises(IndexError):
            lst[5]

    def test_restore_does_not_mutate_input(self) -> None:
        original = [1, 2]
        lst: AppendOnlyList[int] = AppendOnlyList()
        lst.restore(original)
        lst.append(3)
        assert original == [1, 2]
