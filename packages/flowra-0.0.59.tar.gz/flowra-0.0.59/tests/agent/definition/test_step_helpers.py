import pytest

from flowra.agent import step
from flowra.agent.definition import get_step_tag, resolve_step_ref
from flowra.agent.definition.step import is_entry_step


class TestStepDecoratorWithExplicitTag:
    def test_sets_tag(self) -> None:
        @step("my_tag")  # type: ignore[arg-type]
        async def handler() -> None:
            pass

        assert get_step_tag(handler) == "my_tag"

    def test_preserves_function_identity(self) -> None:
        async def original() -> None:
            pass

        decorated = step("t")(original)  # type: ignore[arg-type]
        assert decorated is original

    def test_sync_function(self) -> None:
        @step("sync_tag")  # type: ignore[arg-type]
        def handler() -> str:
            return "ok"

        assert get_step_tag(handler) == "sync_tag"
        assert handler() == "ok"

    def test_multiple_decorators_last_wins(self) -> None:
        @step("second")  # type: ignore[arg-type]
        @step("first")  # type: ignore[arg-type]
        def handler() -> None:
            pass

        assert resolve_step_ref(handler) == "second"


class TestStepDecoratorWithAutoTag:
    def test_bare_decorator(self) -> None:
        @step  # type: ignore[arg-type]
        def process() -> None:
            pass

        assert get_step_tag(process) == "process"

    def test_bare_decorator_preserves_identity(self) -> None:
        def original() -> None:
            pass

        decorated = step(original)  # type: ignore[arg-type]
        assert decorated is original

    def test_bare_decorator_async(self) -> None:
        @step  # type: ignore[arg-type]
        async def fetch_data() -> None:
            pass

        assert resolve_step_ref(fetch_data) == "fetch_data"

    def test_empty_parens(self) -> None:
        @step()  # type: ignore[arg-type]
        def my_step() -> None:
            pass

        assert get_step_tag(my_step) == "my_step"

    def test_empty_string_tag_uses_name(self) -> None:
        @step("")  # type: ignore[arg-type]
        def handler() -> None:
            pass

        assert get_step_tag(handler) == "handler"

    def test_bound_method_auto_tag(self) -> None:
        class Agent:
            @step  # type: ignore[arg-type]
            def process(self) -> None:
                pass

        assert resolve_step_ref(Agent().process) == "process"
        assert resolve_step_ref(Agent.process) == "process"


class TestGetStepTag:
    def test_returns_none_for_undecorated(self) -> None:
        def plain() -> None:
            pass

        assert get_step_tag(plain) is None

    def test_returns_tag_for_decorated(self) -> None:
        @step("x")  # type: ignore[arg-type]
        def fn() -> None:
            pass

        assert get_step_tag(fn) == "x"

    def test_returns_none_for_lambda(self) -> None:
        assert get_step_tag(lambda: None) is None


class TestResolveStepRef:
    def test_string_passthrough(self) -> None:
        assert resolve_step_ref("my_tag") == "my_tag"

    def test_decorated_function(self) -> None:
        @step("the_tag")  # type: ignore[arg-type]
        def fn() -> None:
            pass

        assert resolve_step_ref(fn) == "the_tag"

    def test_bound_method(self) -> None:
        class Obj:
            @step("method_tag")  # type: ignore[arg-type]
            def my_method(self) -> None:
                pass

        obj = Obj()
        assert resolve_step_ref(obj.my_method) == "method_tag"

    def test_unbound_method(self) -> None:
        class Obj:
            @step("unbound_tag")  # type: ignore[arg-type]
            def my_method(self) -> None:
                pass

        assert resolve_step_ref(Obj.my_method) == "unbound_tag"

    def test_undecorated_raises(self) -> None:
        def plain() -> None:
            pass

        with pytest.raises(TypeError, match="not a @step-decorated method"):
            resolve_step_ref(plain)  # type: ignore[arg-type]

    def test_undecorated_bound_method_raises(self) -> None:
        class Obj:
            def plain(self) -> None:
                pass

        with pytest.raises(TypeError, match="not a @step-decorated method"):
            resolve_step_ref(Obj().plain)  # type: ignore[arg-type]

    def test_lambda_raises(self) -> None:
        with pytest.raises(TypeError, match="not a @step-decorated method"):
            resolve_step_ref(lambda: None)  # type: ignore[arg-type]


class TestEntryStep:
    def test_not_entry_by_default(self) -> None:
        @step  # type: ignore[arg-type]
        def process() -> None:
            pass

        assert not is_entry_step(process)

    def test_not_entry_with_explicit_tag(self) -> None:
        @step("my_tag")  # type: ignore[arg-type]
        def process() -> None:
            pass

        assert not is_entry_step(process)

    def test_entry_true(self) -> None:
        @step(entry=True)  # type: ignore[arg-type]
        def process() -> None:
            pass

        assert is_entry_step(process)

    def test_entry_with_tag(self) -> None:
        @step("my_tag", entry=True)  # type: ignore[arg-type]
        def process() -> None:
            pass

        assert is_entry_step(process)
        assert get_step_tag(process) == "my_tag"

    def test_entry_false_explicit(self) -> None:
        @step(entry=False)  # type: ignore[arg-type]
        def process() -> None:
            pass

        assert not is_entry_step(process)

    def test_undecorated_not_entry(self) -> None:
        def process() -> None:
            pass

        assert not is_entry_step(process)
