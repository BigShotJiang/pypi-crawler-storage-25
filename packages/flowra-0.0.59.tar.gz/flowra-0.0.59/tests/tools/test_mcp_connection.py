import asyncio
import json
from typing import Any
from unittest.mock import patch

import httpx

from flowra.tools import McpConnection, ToolDefinition, ToolErrorKind, ToolResult


def _jsonrpc_result(request_body: bytes, result: dict[str, Any]) -> httpx.Response:
    body = json.loads(request_body)
    return httpx.Response(
        200,
        json={"jsonrpc": "2.0", "id": body.get("id"), "result": result},
        headers={"content-type": "application/json"},
    )


def _jsonrpc_error(request_body: bytes, code: int, message: str) -> httpx.Response:
    body = json.loads(request_body)
    return httpx.Response(
        200,
        json={"jsonrpc": "2.0", "id": body.get("id"), "error": {"code": code, "message": message}},
        headers={"content-type": "application/json"},
    )


def _noop_handler(request: httpx.Request) -> httpx.Response:
    return _jsonrpc_result(request.content, {})


def _build_connection(
    *,
    tools: dict[str, ToolDefinition] | None = None,
    handler: Any = None,
) -> McpConnection:
    if tools is None:
        tools = {
            "test_tool": ToolDefinition(
                name="test_tool",
                description="A test tool",
                input_schema=None,
                output_schema=None,
            )
        }
    client = httpx.AsyncClient(transport=httpx.MockTransport(handler or _noop_handler))
    return McpConnection(client=client, url="http://test/mcp", session_id=None, tools=tools)


class TestGetTools:
    async def test_returns_cached_tools(self) -> None:
        conn = _build_connection()
        try:
            tools = conn.get_tools()
            assert len(tools) == 1
            assert tools[0].name == "test_tool"
        finally:
            await conn.close()

    async def test_excludes_removed_tools(self) -> None:
        tools = {
            "tool_a": ToolDefinition(name="tool_a", description="A", input_schema=None, output_schema=None),
            "tool_b": ToolDefinition(name="tool_b", description="B", input_schema=None, output_schema=None),
        }

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            method = body.get("method")
            if method == "tools/call":
                return _jsonrpc_error(request.content, -32602, "Unknown tool")
            if method == "tools/list":
                return _jsonrpc_result(
                    request.content,
                    {
                        "tools": [{"name": "tool_b", "description": "B", "inputSchema": {"type": "object"}}],
                    },
                )
            return _jsonrpc_result(request.content, {})

        conn = _build_connection(tools=tools, handler=handler)
        try:
            await conn.call_tool("tool_a")
            remaining = conn.get_tools()
            assert len(remaining) == 1
            assert remaining[0].name == "tool_b"
        finally:
            await conn.close()

    async def test_returns_empty_when_no_tools(self) -> None:
        conn = _build_connection(tools={})
        try:
            assert conn.get_tools() == []
        finally:
            await conn.close()


class TestCallTool:
    async def test_returns_error_for_unknown_tool(self) -> None:
        conn = _build_connection()
        try:
            result = await conn.call_tool("nonexistent")
            assert result == ToolResult(
                content="Unknown tool: nonexistent", is_error=True, error_kind=ToolErrorKind.UNKNOWN_TOOL
            )
        finally:
            await conn.close()

    async def test_calls_server_and_returns_result(self) -> None:
        requests: list[dict[str, Any]] = []

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            requests.append(body)
            return _jsonrpc_result(
                request.content,
                {
                    "content": [{"type": "text", "text": "hello"}],
                    "isError": False,
                },
            )

        conn = _build_connection(handler=handler)
        try:
            result = await conn.call_tool("test_tool", {"arg": "value"})
            assert result == ToolResult(content="hello", is_error=False)
            assert requests[-1]["params"]["name"] == "test_tool"
            assert requests[-1]["params"]["arguments"] == {"arg": "value"}
        finally:
            await conn.close()

    async def test_returns_tool_execution_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return _jsonrpc_result(
                request.content,
                {
                    "content": [{"type": "text", "text": "failed"}],
                    "isError": True,
                },
            )

        conn = _build_connection(handler=handler)
        try:
            result = await conn.call_tool("test_tool")
            assert result == ToolResult(content="failed", is_error=True, error_kind=ToolErrorKind.EXECUTION)
            assert len(conn.get_tools()) == 1
        finally:
            await conn.close()

    async def test_unknown_tool_in_call_result_removes_tool(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            if body.get("method") == "tools/list":
                return _jsonrpc_result(request.content, {"tools": []})
            return _jsonrpc_result(
                request.content,
                {
                    "content": [{"type": "text", "text": "Unknown tool: test_tool"}],
                    "isError": True,
                },
            )

        conn = _build_connection(handler=handler)
        try:
            result = await conn.call_tool("test_tool")
            assert result.is_error is True
            assert conn.get_tools() == []
        finally:
            await conn.close()

    async def test_handles_jsonrpc_error_invalid_params(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            if body.get("method") == "tools/list":
                return _jsonrpc_result(request.content, {"tools": []})
            return _jsonrpc_error(request.content, -32602, "Unknown tool: test_tool")

        conn = _build_connection(handler=handler)
        try:
            result = await conn.call_tool("test_tool")
            assert result.is_error is True
            assert conn.get_tools() == []
        finally:
            await conn.close()

    async def test_non_invalid_params_error_does_not_remove_tool(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return _jsonrpc_error(request.content, -32603, "Internal error")

        conn = _build_connection(handler=handler)
        try:
            result = await conn.call_tool("test_tool")
            assert result.is_error is True
            assert len(conn.get_tools()) == 1
        finally:
            await conn.close()

    async def test_returns_error_for_removed_tool(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            if body.get("method") == "tools/list":
                return _jsonrpc_result(request.content, {"tools": []})
            return _jsonrpc_error(request.content, -32602, "Unknown tool")

        conn = _build_connection(handler=handler)
        try:
            await conn.call_tool("test_tool")
            result = await conn.call_tool("test_tool")
            assert result == ToolResult(
                content="Unknown tool: test_tool", is_error=True, error_kind=ToolErrorKind.UNKNOWN_TOOL
            )
        finally:
            await conn.close()

    async def test_passes_empty_dict_for_none_arguments(self) -> None:
        requests: list[dict[str, Any]] = []

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            requests.append(body)
            return _jsonrpc_result(
                request.content,
                {
                    "content": [{"type": "text", "text": "ok"}],
                    "isError": False,
                },
            )

        conn = _build_connection(handler=handler)
        try:
            await conn.call_tool("test_tool")
            assert requests[-1]["params"]["arguments"] == {}
        finally:
            await conn.close()


class TestConnect:
    async def test_connect_initializes_and_fetches_tools(self) -> None:
        requests: list[dict[str, Any]] = []

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            requests.append(body)
            method = body.get("method")
            if method == "initialize":
                return httpx.Response(
                    200,
                    json={
                        "jsonrpc": "2.0",
                        "id": body["id"],
                        "result": {
                            "protocolVersion": "2025-03-26",
                            "capabilities": {"tools": {"listChanged": True}},
                            "serverInfo": {"name": "test-server", "version": "1.0"},
                        },
                    },
                    headers={"content-type": "application/json", "mcp-session-id": "test-session-123"},
                )
            if method == "notifications/initialized":
                return httpx.Response(202)
            if method == "tools/list":
                return _jsonrpc_result(
                    request.content,
                    {
                        "tools": [{"name": "my_tool", "description": "My tool", "inputSchema": {"type": "object"}}],
                    },
                )
            return _jsonrpc_result(request.content, {})

        transport = httpx.MockTransport(handler)
        with_headers = {"X-Key": "val"}

        # Patch httpx.AsyncClient to capture headers and use our transport
        original_init = httpx.AsyncClient.__init__

        def patched_init(self_client: Any, **kwargs: Any) -> None:
            kwargs["transport"] = transport
            original_init(self_client, **kwargs)

        with patch.object(httpx.AsyncClient, "__init__", patched_init):
            conn = await McpConnection.connect("http://example.com/mcp", headers=with_headers)

        try:
            tools = conn.get_tools()
            assert len(tools) == 1
            assert tools[0].name == "my_tool"
            assert tools[0].description == "My tool"

            methods = [r.get("method") for r in requests]
            assert "initialize" in methods
            assert "notifications/initialized" in methods
            assert "tools/list" in methods
        finally:
            await conn.close()


class TestBackgroundRefresh:
    async def test_removed_tools_cleared_after_refresh(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            method = body.get("method")
            if method == "tools/call":
                return _jsonrpc_error(request.content, -32602, "Unknown tool")
            if method == "tools/list":
                return _jsonrpc_result(
                    request.content,
                    {
                        "tools": [{"name": "new_tool", "description": "New", "inputSchema": {"type": "object"}}],
                    },
                )
            return _jsonrpc_result(request.content, {})

        conn = _build_connection(handler=handler)
        try:
            await conn.call_tool("test_tool")
            assert conn.get_tools() == []

            await asyncio.sleep(0.1)

            tools = conn.get_tools()
            assert len(tools) == 1
            assert tools[0].name == "new_tool"
        finally:
            await conn.close()


class TestMultiBlockContent:
    async def test_multiple_text_blocks_joined_with_newline(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return _jsonrpc_result(
                request.content,
                {
                    "content": [
                        {"type": "text", "text": "line 1"},
                        {"type": "text", "text": "line 2"},
                    ],
                    "isError": False,
                },
            )

        conn = _build_connection(handler=handler)
        try:
            result = await conn.call_tool("test_tool")
            assert result.content == "line 1\nline 2"
            assert result.is_error is False
        finally:
            await conn.close()

    async def test_non_text_block_serialized_as_str(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return _jsonrpc_result(
                request.content,
                {
                    "content": [
                        {"type": "image", "data": "base64..."},
                    ],
                    "isError": False,
                },
            )

        conn = _build_connection(handler=handler)
        try:
            result = await conn.call_tool("test_tool")
            assert "image" in result.content
        finally:
            await conn.close()


class TestSseResponses:
    async def test_sse_response_parsed(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            sse_data = json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": body["id"],
                    "result": {"content": [{"type": "text", "text": "sse result"}], "isError": False},
                }
            )
            sse_body = f"data: {sse_data}\n\n"
            return httpx.Response(
                200,
                text=sse_body,
                headers={"content-type": "text/event-stream"},
            )

        conn = _build_connection(handler=handler)
        try:
            result = await conn.call_tool("test_tool")
            assert result.content == "sse result"
            assert result.is_error is False
        finally:
            await conn.close()


class TestReconnect:
    async def test_reconnect_on_http_error_then_retry_succeeds(self) -> None:
        call_count = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            body = json.loads(request.content)
            method = body.get("method")
            if method == "tools/call":
                call_count += 1
                if call_count == 1:
                    return httpx.Response(500, text="Internal Server Error")
                return _jsonrpc_result(
                    request.content,
                    {"content": [{"type": "text", "text": "success"}], "isError": False},
                )
            if method == "initialize":
                return httpx.Response(
                    200,
                    json={"jsonrpc": "2.0", "id": body["id"], "result": {"protocolVersion": "2025-03-26"}},
                    headers={"content-type": "application/json", "mcp-session-id": "new-session"},
                )
            if method == "notifications/initialized":
                return httpx.Response(202)
            if method == "tools/list":
                return _jsonrpc_result(
                    request.content,
                    {"tools": [{"name": "test_tool", "description": "A test tool", "inputSchema": {"type": "object"}}]},
                )
            return _jsonrpc_result(request.content, {})

        conn = _build_connection(handler=handler)
        try:
            result = await conn.call_tool("test_tool")
            assert result.content == "success"
            assert result.is_error is False
            assert call_count == 2
        finally:
            await conn.close()

    async def test_reconnect_fails_returns_unavailable(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            method = body.get("method")
            if method == "tools/call":
                return httpx.Response(500, text="Internal Server Error")
            if method == "initialize":
                raise httpx.ConnectError("Connection refused")
            return _jsonrpc_result(request.content, {})

        conn = _build_connection(handler=handler)
        try:
            result = await conn.call_tool("test_tool")
            assert result.is_error is True
            assert "temporarily unavailable" in result.content
        finally:
            await conn.close()


class TestContextManager:
    async def test_async_context_manager(self) -> None:
        conn = _build_connection(tools={})
        async with conn as c:
            assert c is conn
