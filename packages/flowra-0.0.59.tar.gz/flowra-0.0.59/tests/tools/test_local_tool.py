import dataclasses
import datetime
import decimal
import uuid
from typing import Annotated, Any

import pytest

from flowra.tools import ExecutableTool, ToolResult, get_tool, tool, tool_arg


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SearchParams:
    query: str
    count: int = 5


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SearchResult:
    items: list[str]


class MyService:
    def __init__(self, prefix: str = "svc") -> None:
        self.prefix = prefix


async def _call(
    lt: ExecutableTool, input: dict[str, Any] | None = None, services: dict[type, Any] | None = None
) -> ToolResult:
    return await lt.executor(input or {}, services or {})


# -- @tool decorator ----------------------------------------------------------


class TestToolDecorator:
    def test_basic_with_docstring(self) -> None:
        @tool("search")
        def search(params: SearchParams) -> SearchResult:
            """Search for items."""
            return SearchResult(items=[params.query])

        lt = get_tool(search)
        assert lt.definition.name == "search"
        assert lt.definition.description == "Search for items."

    def test_explicit_description(self) -> None:
        @tool("search", description="Custom description")
        def search(params: SearchParams) -> str:
            return ""

        lt = get_tool(search)
        assert lt.definition.description == "Custom description"

    def test_no_docstring_no_description_raises(self) -> None:
        with pytest.raises(ValueError, match="must have description or docstring"):

            @tool("bad")
            def handler() -> None:  # pyright: ignore[reportUnusedFunction]
                pass

    def test_invalid_name_raises(self) -> None:
        with pytest.raises(ValueError, match="must match"):

            @tool("bad.name")
            def handler() -> None:  # pyright: ignore[reportUnusedFunction]
                """Has docstring."""

    def test_missing_type_annotation_raises(self) -> None:
        with pytest.raises(TypeError, match="must have a type annotation"):

            @tool("bad")
            def handler(x) -> None:  # noqa: ANN001  # pyright: ignore[reportUnusedFunction, reportMissingParameterType]
                """Has docstring."""


class TestGetTool:
    def test_on_decorated(self) -> None:
        @tool("ping")
        def ping() -> str:
            """Ping."""
            return "pong"

        assert isinstance(get_tool(ping), ExecutableTool)

    def test_on_undecorated_raises(self) -> None:
        def plain() -> None:
            pass

        with pytest.raises(ValueError, match="is not decorated with @tool"):
            get_tool(plain)


# -- Binding resolution -------------------------------------------------------


class TestBindingHeuristic:
    def test_single_dataclass_is_input(self) -> None:
        @tool("search")
        def search(params: SearchParams) -> str:
            """Search."""
            return ""

        lt = get_tool(search)
        assert lt.definition.input_schema is not None
        assert lt.definition.input_schema["type"] == "object"
        assert "query" in lt.definition.input_schema["properties"]

    def test_no_params_empty_schema(self) -> None:
        @tool("ping")
        def ping() -> str:
            """Ping."""
            return "pong"

        lt = get_tool(ping)
        assert lt.definition.input_schema is None

    def test_non_dataclass_is_service(self) -> None:
        @tool("with_svc")
        def handler(svc: MyService) -> str:
            """Has docstring."""
            return svc.prefix

        lt = get_tool(handler)
        assert lt.definition.input_schema is None

    def test_multiple_dataclasses_without_marker_raises(self) -> None:
        @dataclasses.dataclass
        class Other:
            x: int = 0

        with pytest.raises(TypeError, match="multiple dataclass parameters"):

            @tool("bad")
            def handler(a: SearchParams, b: Other) -> None:  # pyright: ignore[reportUnusedFunction]
                """Has docstring."""

    def test_unsupported_param_type_raises(self) -> None:
        with pytest.raises(TypeError, match="must be a dataclass or a service type"):

            @tool("bad")
            def handler(x: list[str]) -> None:  # pyright: ignore[reportUnusedFunction]
                """Has docstring."""


class TestExplicitMarkers:
    def test_tool_input_marker(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Config:
            api_key: str

        @tool("fetch")
        def fetch(params: Annotated[SearchParams, tool_arg.INPUT], config: Config) -> str:
            """Fetch data."""
            return ""

        lt = get_tool(fetch)
        assert lt.definition.input_schema is not None
        assert "query" in lt.definition.input_schema["properties"]

    def test_tool_input_on_second_param(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Config:
            api_key: str

        @tool("fetch")
        def fetch(config: Config, params: Annotated[SearchParams, tool_arg.INPUT]) -> str:
            """Fetch data."""
            return ""

        lt = get_tool(fetch)
        assert lt.definition.input_schema is not None
        assert "query" in lt.definition.input_schema["properties"]

    def test_tool_service_marker(self) -> None:
        @tool("fetch")
        def fetch(params: SearchParams, svc: Annotated[MyService, tool_arg.SERVICE]) -> str:
            """Fetch data."""
            return ""

        lt = get_tool(fetch)
        assert lt.definition.input_schema is not None
        assert "query" in lt.definition.input_schema["properties"]

    def test_tool_input_and_tool_service(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Config:
            api_key: str

        @tool("fetch")
        def fetch(
            params: Annotated[SearchParams, tool_arg.INPUT],
            config: Annotated[Config, tool_arg.SERVICE],
        ) -> str:
            """Fetch data."""
            return ""

        lt = get_tool(fetch)
        assert lt.definition.input_schema is not None
        assert "query" in lt.definition.input_schema["properties"]

    def test_tool_service_without_tool_input_heuristic_still_works(self) -> None:
        @tool("fetch")
        def fetch(params: SearchParams, svc: Annotated[MyService, tool_arg.SERVICE]) -> str:
            """Fetch data."""
            return ""

        lt = get_tool(fetch)
        assert lt.definition.input_schema is not None
        assert "query" in lt.definition.input_schema["properties"]

    def test_multiple_tool_input_raises(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Other:
            x: int

        with pytest.raises(TypeError, match=r"multiple tool_arg\.INPUT parameters"):

            @tool("bad")
            def handler(  # pyright: ignore[reportUnusedFunction]
                a: Annotated[SearchParams, tool_arg.INPUT], b: Annotated[Other, tool_arg.INPUT]
            ) -> None:
                """Has docstring."""

    def test_tool_input_on_non_dataclass_raises(self) -> None:
        with pytest.raises(TypeError, match=r"tool_arg\.INPUT parameter.*must be a dataclass"):

            @tool("bad")
            def handler(x: Annotated[str, tool_arg.INPUT]) -> None:  # pyright: ignore[reportUnusedFunction]
                """Has docstring."""

    def test_explicit_input_marker_on_single_param(self) -> None:
        @tool("search")
        def search(params: Annotated[SearchParams, tool_arg.INPUT]) -> str:
            """Search."""
            return ""

        lt = get_tool(search)
        assert lt.definition.input_schema is not None
        assert "query" in lt.definition.input_schema["properties"]


# -- Schemas ------------------------------------------------------------------


class TestSchemas:
    def test_input_schema_from_dataclass(self) -> None:
        @tool("search")
        def search(params: SearchParams) -> str:
            """Search."""
            return ""

        lt = get_tool(search)
        assert lt.definition.input_schema is not None
        assert lt.definition.input_schema["type"] == "object"
        assert "query" in lt.definition.input_schema["properties"]
        assert "count" in lt.definition.input_schema["properties"]
        assert "query" in lt.definition.input_schema["required"]

    def test_output_schema_from_dataclass(self) -> None:
        @tool("search")
        def search(params: SearchParams) -> SearchResult:
            """Search."""
            return SearchResult(items=[])

        lt = get_tool(search)
        assert lt.definition.output_schema is not None
        assert lt.definition.output_schema["type"] == "object"
        assert "items" in lt.definition.output_schema["properties"]

    def test_output_schema_none_for_non_dataclass(self) -> None:
        @tool("ping")
        def ping() -> str:
            """Ping."""
            return "pong"

        lt = get_tool(ping)
        assert lt.definition.output_schema is None


# -- Handler execution --------------------------------------------------------


class TestHandlerExecution:
    async def test_sync_tool(self) -> None:
        @tool("search")
        def search(params: SearchParams) -> SearchResult:
            """Search."""
            return SearchResult(items=[params.query])

        lt = get_tool(search)
        result = await _call(lt, input={"query": "hello"})
        assert result.content == '{"items": ["hello"]}'
        assert result.is_error is False

    async def test_async_tool(self) -> None:
        @tool("search")
        async def search(params: SearchParams) -> SearchResult:
            """Search."""
            return SearchResult(items=[params.query])

        lt = get_tool(search)
        result = await _call(lt, input={"query": "world"})
        assert result.content == '{"items": ["world"]}'

    async def test_no_params(self) -> None:
        @tool("ping")
        def ping() -> str:
            """Ping."""
            return "pong"

        lt = get_tool(ping)
        result = await _call(lt)
        assert result.content == "pong"

    async def test_service_injection(self) -> None:
        @tool("greet")
        def greet(svc: MyService) -> str:
            """Greet."""
            return svc.prefix

        lt = get_tool(greet)
        result = await _call(lt, services={MyService: MyService(prefix="hello")})
        assert result.content == "hello"

    async def test_params_and_service(self) -> None:
        @tool("combo")
        def combo(params: SearchParams, svc: MyService) -> str:
            """Combo."""
            return f"{svc.prefix}: {params.query}"

        lt = get_tool(combo)
        result = await _call(lt, input={"query": "test"}, services={MyService: MyService(prefix="Hi")})
        assert result.content == "Hi: test"

    async def test_explicit_markers_execution(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Config:
            prefix: str

        @tool("greet")
        def greet(params: Annotated[SearchParams, tool_arg.INPUT], config: Annotated[Config, tool_arg.SERVICE]) -> str:
            """Greet."""
            return f"{config.prefix}: {params.query}"

        lt = get_tool(greet)
        result = await _call(lt, input={"query": "hello"}, services={Config: Config(prefix="Hi")})
        assert result.content == "Hi: hello"

    async def test_result_dataclass_to_json(self) -> None:
        @tool("search")
        def search() -> SearchResult:
            """Search."""
            return SearchResult(items=["a", "b"])

        lt = get_tool(search)
        result = await _call(lt)
        assert result.content == '{"items": ["a", "b"]}'

    async def test_result_dict_to_json(self) -> None:
        @tool("info")
        def info() -> dict[str, str]:
            """Info."""
            return {"key": "value"}

        lt = get_tool(info)
        result = await _call(lt)
        assert result.content == '{"key": "value"}'

    async def test_result_str_passthrough(self) -> None:
        @tool("ping")
        def ping() -> str:
            """Ping."""
            return "pong"

        lt = get_tool(ping)
        result = await _call(lt)
        assert result.content == "pong"

    async def test_result_other_to_str(self) -> None:
        @tool("num")
        def num() -> int:
            """Num."""
            return 42

        lt = get_tool(num)
        result = await _call(lt)
        assert result.content == "42"

    async def test_result_bool_to_str(self) -> None:
        @tool("check")
        def check() -> bool:
            """Check."""
            return True

        lt = get_tool(check)
        result = await _call(lt)
        assert result.content == "True"

    async def test_result_list_primitives_to_json(self) -> None:
        @tool("items")
        def items() -> list[str]:
            """Items."""
            return ["a", "b", "c"]

        lt = get_tool(items)
        result = await _call(lt)
        assert result.content == '["a", "b", "c"]'

    async def test_result_list_dict_to_json(self) -> None:
        @tool("items")
        def items() -> list[dict[str, Any]]:
            """Items."""
            return [{"a": 1}, {"b": 2}]

        lt = get_tool(items)
        result = await _call(lt)
        assert result.content == '[{"a": 1}, {"b": 2}]'

    async def test_result_list_dataclass_to_json(self) -> None:
        @tool("search_all")
        def search_all() -> list[SearchResult]:
            """Search all."""
            return [SearchResult(items=["a"]), SearchResult(items=["b", "c"])]

        lt = get_tool(search_all)
        result = await _call(lt)
        assert result.content == '[{"items": ["a"]}, {"items": ["b", "c"]}]'

    async def test_result_dict_with_uuid(self) -> None:
        uid = uuid.UUID("12345678-1234-5678-1234-567812345678")

        @tool("info")
        def info() -> dict[str, Any]:
            """Info."""
            return {"id": uid}

        lt = get_tool(info)
        result = await _call(lt)
        assert result.content == '{"id": "12345678-1234-5678-1234-567812345678"}'

    async def test_result_dict_with_decimal(self) -> None:
        @tool("info")
        def info() -> dict[str, Any]:
            """Info."""
            return {"amount": decimal.Decimal("10.5")}

        lt = get_tool(info)
        result = await _call(lt)
        assert result.content == '{"amount": "10.5"}'

    async def test_result_dict_with_datetime(self) -> None:
        @tool("info")
        def info() -> dict[str, Any]:
            """Info."""
            return {"ts": datetime.datetime(2024, 1, 15, 10, 30, 0)}

        lt = get_tool(info)
        result = await _call(lt)
        assert result.content == '{"ts": "2024-01-15T10:30:00"}'

    async def test_result_dict_with_date(self) -> None:
        @tool("info")
        def info() -> dict[str, Any]:
            """Info."""
            return {"day": datetime.date(2024, 1, 15)}

        lt = get_tool(info)
        result = await _call(lt)
        assert result.content == '{"day": "2024-01-15"}'

    async def test_result_dict_with_time(self) -> None:
        @tool("info")
        def info() -> dict[str, Any]:
            """Info."""
            return {"t": datetime.time(10, 30, 0)}

        lt = get_tool(info)
        result = await _call(lt)
        assert result.content == '{"t": "10:30:00"}'


# -- Required / optional services ---------------------------------------------


class TestServiceOptional:
    async def test_required_service_missing_raises(self) -> None:
        @tool("greet")
        def greet(svc: MyService) -> str:
            """Greet."""
            return svc.prefix

        lt = get_tool(greet)
        with pytest.raises(TypeError, match="Required service MyService not found"):
            await _call(lt)

    async def test_required_service_provided(self) -> None:
        @tool("greet")
        def greet(svc: MyService) -> str:
            """Greet."""
            return svc.prefix

        lt = get_tool(greet)
        result = await _call(lt, services={MyService: MyService(prefix="ok")})
        assert result.content == "ok"

    async def test_optional_service_missing_gets_none(self) -> None:
        @tool("greet")
        def greet(svc: MyService | None) -> str:
            """Greet."""
            return "none" if svc is None else svc.prefix

        lt = get_tool(greet)
        result = await _call(lt)
        assert result.content == "none"

    async def test_optional_service_provided(self) -> None:
        @tool("greet")
        def greet(svc: MyService | None) -> str:
            """Greet."""
            return "none" if svc is None else svc.prefix

        lt = get_tool(greet)
        result = await _call(lt, services={MyService: MyService(prefix="yes")})
        assert result.content == "yes"

    async def test_optional_service_with_annotated_marker(self) -> None:
        @tool("greet")
        def greet(svc: Annotated[MyService | None, tool_arg.SERVICE]) -> str:
            """Greet."""
            return "none" if svc is None else svc.prefix

        lt = get_tool(greet)
        result = await _call(lt)
        assert result.content == "none"

    async def test_optional_service_with_marker_provided(self) -> None:
        @tool("greet")
        def greet(svc: Annotated[MyService | None, tool_arg.SERVICE]) -> str:
            """Greet."""
            return "none" if svc is None else svc.prefix

        lt = get_tool(greet)
        result = await _call(lt, services={MyService: MyService(prefix="yes")})
        assert result.content == "yes"


# -- Input validation ----------------------------------------------------------


class TestInputValidation:
    async def test_invalid_input_raises_validation_error(self) -> None:
        @tool("search")
        def search(params: SearchParams) -> str:
            """Search."""
            return params.query

        lt = get_tool(search)
        with pytest.raises(Exception, match="'query' is a required property"):
            await _call(lt, input={})
