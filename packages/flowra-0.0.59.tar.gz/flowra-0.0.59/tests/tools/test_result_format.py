import dataclasses
import json
import uuid
from datetime import date, datetime, time
from decimal import Decimal

from flowra.tools._result_format import format_result


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Item:
    name: str
    amount: Decimal


class TestScalarsUseCanonicalStrings:
    def test_str(self) -> None:
        assert format_result("hello") == "hello"

    def test_int(self) -> None:
        assert format_result(42) == "42"

    def test_bool(self) -> None:
        assert format_result(True) == "True"

    def test_uuid_canonical(self) -> None:
        u = uuid.UUID("12345678-1234-5678-1234-567812345678")
        assert format_result(u) == str(u)

    def test_decimal_preserves_precision(self) -> None:
        assert format_result(Decimal("3.14159")) == "3.14159"

    def test_datetime_iso_at_top_level(self) -> None:
        dt = datetime(2026, 4, 20, 15, 30, 0)
        assert format_result(dt) == "2026-04-20T15:30:00"

    def test_date_iso(self) -> None:
        assert format_result(date(2026, 4, 20)) == "2026-04-20"

    def test_time_iso(self) -> None:
        assert format_result(time(15, 30, 45)) == "15:30:45"

    def test_bytes_base64(self) -> None:
        import base64

        data = b"\x00\x01\x02\xff"
        assert format_result(data) == base64.b64encode(data).decode("ascii")


class TestNestedDatetimeConsistency:
    """Datetime inside list/dict must use the same ISO format as at the top level."""

    def test_datetime_in_list(self) -> None:
        dt = datetime(2026, 4, 20, 15, 30, 0)
        assert format_result([dt]) == '["2026-04-20T15:30:00"]'

    def test_datetime_in_dict(self) -> None:
        dt = datetime(2026, 4, 20, 15, 30, 0)
        assert format_result({"when": dt}) == '{"when": "2026-04-20T15:30:00"}'


class TestDictWithMixedValues:
    """Review finding: format_result must walk dicts recursively and normalize dataclasses/stdlib values."""

    def test_dict_with_dataclass_value(self) -> None:
        result = format_result({"item": Item(name="a", amount=Decimal("1.5"))})
        assert json.loads(result) == {"item": {"name": "a", "amount": "1.5"}}

    def test_dict_with_stdlib_values(self) -> None:
        u = uuid.UUID("11111111-1111-1111-1111-111111111111")
        result = format_result({"id": u, "amount": Decimal("2.50"), "when": date(2026, 4, 20)})
        assert json.loads(result) == {
            "id": "11111111-1111-1111-1111-111111111111",
            "amount": "2.50",
            "when": "2026-04-20",
        }

    def test_dict_with_nested_list_of_dataclasses(self) -> None:
        result = format_result({"items": [Item(name="a", amount=Decimal("1")), Item(name="b", amount=Decimal("2"))]})
        assert json.loads(result) == {"items": [{"name": "a", "amount": "1"}, {"name": "b", "amount": "2"}]}


class TestListWithMixedValues:
    """Review finding: list with a non-dataclass first element used to silently drop subsequent dataclasses."""

    def test_list_mixed_scalar_and_dataclass(self) -> None:
        result = format_result([1, Item(name="x", amount=Decimal("9"))])
        assert json.loads(result) == [1, {"name": "x", "amount": "9"}]

    def test_list_of_stdlib_scalars(self) -> None:
        result = format_result([uuid.UUID("11111111-1111-1111-1111-111111111111"), Decimal("0.5")])
        assert json.loads(result) == ["11111111-1111-1111-1111-111111111111", "0.5"]

    def test_list_of_dataclasses(self) -> None:
        result = format_result([Item(name="a", amount=Decimal("1")), Item(name="b", amount=Decimal("2"))])
        assert json.loads(result) == [{"name": "a", "amount": "1"}, {"name": "b", "amount": "2"}]
