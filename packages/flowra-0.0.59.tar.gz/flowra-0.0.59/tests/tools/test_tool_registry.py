import dataclasses
from typing import Any

import pytest

from flowra.tools import ExecutableTool, ToolDefinition, ToolExecutor, ToolRegistry, ToolResult, tool, tool_filter


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Params:
    q: str


@tool("search")
def search_tool(params: Params) -> str:
    """Search."""
    return params.q


@tool("ping")
def ping_tool() -> str:
    """Ping."""
    return "pong"


@tool("dup")
def dup_tool() -> str:
    """Dup."""
    return "dup"


def _make_tool(
    name: str,
    description: str = "desc",
    executor: ToolExecutor | None = None,
) -> ExecutableTool:
    """Create a fake ExecutableTool (simulates an MCP-style tool)."""

    async def default_executor(args: dict[str, Any], services: dict[type, Any]) -> ToolResult:
        return ToolResult(content=f"mocked:{name}", is_error=False)

    return ExecutableTool(
        definition=ToolDefinition(name=name, description=description),
        executor=executor or default_executor,
    )


# -- Local tools ---------------------------------------------------------------


class TestLocalTools:
    def test_no_prefix(self) -> None:
        registry = ToolRegistry([search_tool, ping_tool])
        assert [t.definition.name for t in registry.get_tools()] == ["search", "ping"]

    def test_with_prefix(self) -> None:
        registry = ToolRegistry.builder().add(search_tool, prefix="grp").build()
        assert registry.get_tools()[0].definition.name == "grp__search"

    def test_duplicate_raises(self) -> None:
        with pytest.raises(ValueError, match="Duplicate tool name"):
            ToolRegistry([search_tool, search_tool])

    def test_same_name_different_prefix_ok(self) -> None:
        registry = ToolRegistry.builder().add(search_tool, prefix="a").add(search_tool, prefix="b").build()
        assert [t.definition.name for t in registry.get_tools()] == ["a__search", "b__search"]

    def test_bare_executable_tool(self) -> None:
        registry = ToolRegistry([search_tool])
        assert [t.definition.name for t in registry.get_tools()] == ["search"]

    def test_duplicate_raises_mixed_sources(self) -> None:
        with pytest.raises(ValueError, match="Duplicate tool name"):
            ToolRegistry.builder().add(search_tool).add(search_tool).build()

    def test_tool_definition_fields(self) -> None:
        registry = ToolRegistry([search_tool])
        et = registry.get_tools()[0]
        assert et.definition.name == "search"
        assert et.definition.description == "Search."
        assert et.definition.input_schema is not None
        assert "q" in et.definition.input_schema["properties"]


# -- get_llm_tools -------------------------------------------------------------


class TestGetLlmTools:
    def test_converts_to_llm_tools(self) -> None:
        registry = ToolRegistry([search_tool, ping_tool])
        llm_tools = registry.get_llm_tools()
        assert len(llm_tools) == 2
        assert llm_tools[0].name == "search"
        assert llm_tools[0].description == "Search."
        search_schema = llm_tools[0].input_schema
        assert search_schema is not None
        assert "q" in search_schema["properties"]
        assert llm_tools[1].name == "ping"

    def test_preserves_output_schema(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Result:
            value: str

        @tool("with_output")
        def with_output(params: Params) -> Result:
            """Has output schema."""
            return Result(value=str(params.q))

        registry = ToolRegistry([with_output])
        llm_tools = registry.get_llm_tools()
        assert llm_tools[0].output_schema is not None
        assert "value" in llm_tools[0].output_schema["properties"]

    def test_output_schema_none_for_non_dataclass_return(self) -> None:
        registry = ToolRegistry([ping_tool])
        llm_tools = registry.get_llm_tools()
        assert llm_tools[0].output_schema is None

    def test_with_prefix(self) -> None:
        registry = ToolRegistry.builder().add(search_tool, prefix="grp").build()
        llm_tools = registry.get_llm_tools()
        assert llm_tools[0].name == "grp__search"


# -- Order preservation --------------------------------------------------------


class TestOrder:
    def test_order_matches_input(self) -> None:
        registry = (
            ToolRegistry.builder()
            .add(ping_tool, prefix="a")
            .add(search_tool, prefix="b")
            .add(dup_tool, prefix="c")
            .build()
        )
        assert [t.definition.name for t in registry.get_tools()] == ["a__ping", "b__search", "c__dup"]

    def test_order_reversed(self) -> None:
        registry = (
            ToolRegistry.builder()
            .add(dup_tool, prefix="c")
            .add(search_tool, prefix="b")
            .add(ping_tool, prefix="a")
            .build()
        )
        assert [t.definition.name for t in registry.get_tools()] == ["c__dup", "b__search", "a__ping"]

    def test_mixed_local_and_fake_mcp_order(self) -> None:
        registry = ToolRegistry.builder().add(ping_tool, prefix="local").add(_make_tool("fetch"), prefix="mcp").build()
        assert [t.definition.name for t in registry.get_tools()] == ["local__ping", "mcp__fetch"]


# -- Duplicates ----------------------------------------------------------------


class TestDuplicates:
    def test_duplicate_with_same_name_raises(self) -> None:
        with pytest.raises(ValueError, match="Duplicate tool name"):
            ToolRegistry([search_tool, _make_tool("search")])

    def test_duplicate_fake_mcp_raises(self) -> None:
        with pytest.raises(ValueError, match="Duplicate tool name"):
            ToolRegistry([_make_tool("fetch"), _make_tool("fetch")])

    def test_different_prefixes_no_conflict(self) -> None:
        registry = (
            ToolRegistry.builder().add(_make_tool("fetch"), prefix="a").add(_make_tool("fetch"), prefix="b").build()
        )
        assert [t.definition.name for t in registry.get_tools()] == ["a__fetch", "b__fetch"]

    def test_same_prefix_different_tools(self) -> None:
        registry = (
            ToolRegistry.builder()
            .add([_make_tool("search"), _make_tool("summarize")], prefix="ai")
            .add(_make_tool("translate"), prefix="ai")
            .build()
        )
        tools = sorted([t.definition.name for t in registry.get_tools()])
        assert tools == ["ai__search", "ai__summarize", "ai__translate"]

    def test_same_prefix_duplicate_tools_raises(self) -> None:
        with pytest.raises(ValueError, match="Duplicate tool name"):
            (
                ToolRegistry.builder()
                .add(_make_tool("search"), prefix="ai")
                .add([_make_tool("search"), _make_tool("translate")], prefix="ai")
                .build()
            )


# -- Execute -------------------------------------------------------------------


class TestExecute:
    async def test_local_tool(self) -> None:
        registry = ToolRegistry([search_tool])
        result = await registry.execute("search", {"q": "hello"})
        assert result.content == "hello"
        assert result.is_error is False

    async def test_local_tool_no_args(self) -> None:
        registry = ToolRegistry([ping_tool])
        result = await registry.execute("ping")
        assert result.content == "pong"

    async def test_local_tool_with_prefix(self) -> None:
        registry = ToolRegistry.builder().add(ping_tool, prefix="grp").build()
        result = await registry.execute("grp__ping")
        assert result.content == "pong"

    async def test_unknown_tool(self) -> None:
        registry = ToolRegistry([ping_tool])
        result = await registry.execute("nonexistent")
        assert result.is_error is True
        assert "Unknown tool" in result.content

    async def test_local_tool_error(self) -> None:
        @tool("failing")
        def failing() -> str:
            """Fail."""
            raise RuntimeError("boom")

        registry = ToolRegistry([failing])
        result = await registry.execute("failing")
        assert result.is_error is True
        assert "boom" in result.content

    async def test_fake_mcp_tool(self) -> None:
        registry = ToolRegistry.builder().add(_make_tool("fetch"), prefix="mcp").build()
        result = await registry.execute("mcp__fetch", {"url": "http://example.com"})
        assert result.content == "mocked:fetch"
        assert result.is_error is False

    async def test_fake_mcp_tool_error(self) -> None:
        async def error_executor(args: dict[str, Any], services: dict[type, Any]) -> ToolResult:
            return ToolResult(content="bad request", is_error=True)

        registry = ToolRegistry([_make_tool("fetch", executor=error_executor)])
        result = await registry.execute("fetch")
        assert result.content == "bad request"
        assert result.is_error is True

    async def test_local_tool_with_services(self) -> None:
        class MyService:
            def __init__(self, prefix: str) -> None:
                self.prefix = prefix

        @tool("greet")
        def greet(svc: MyService) -> str:
            """Greet."""
            return svc.prefix

        registry = ToolRegistry([greet])
        result = await registry.execute("greet", services={MyService: MyService("hi")})
        assert result.content == "hi"


# -- Empty registry ------------------------------------------------------------


class TestEmptyRegistry:
    def test_empty_returns_registry(self) -> None:
        registry = ToolRegistry()
        assert isinstance(registry, ToolRegistry)

    def test_empty_has_no_tools(self) -> None:
        registry = ToolRegistry()
        assert registry.get_tools() == []
        assert registry.get_llm_tools() == []

    def test_empty_get_tool_definition_returns_none(self) -> None:
        registry = ToolRegistry()
        assert registry.get_tool_definition("anything") is None

    async def test_empty_execute_unknown_tool(self) -> None:
        registry = ToolRegistry()
        result = await registry.execute("anything", {})
        assert result.is_error
        assert "Unknown tool" in result.content


# -- Builder -------------------------------------------------------------------


class TestBuilder:
    def test_builder_add_single(self) -> None:
        registry = ToolRegistry.builder().add(ping_tool).build()
        assert [t.definition.name for t in registry.get_tools()] == ["ping"]

    def test_builder_add_iterable(self) -> None:
        tools = [search_tool, ping_tool]
        registry = ToolRegistry.builder().add(tools).build()
        assert [t.definition.name for t in registry.get_tools()] == ["search", "ping"]

    def test_builder_add_registry(self) -> None:
        inner = ToolRegistry([search_tool, ping_tool])
        registry = ToolRegistry.builder().add(inner, prefix="ns").build()
        assert [t.definition.name for t in registry.get_tools()] == ["ns__search", "ns__ping"]

    def test_builder_filter(self) -> None:
        tools = [search_tool, ping_tool]
        registry = ToolRegistry.builder().add(tools, filter=lambda t: t.definition.name == "ping").build()
        assert [t.definition.name for t in registry.get_tools()] == ["ping"]

    def test_builder_prefix_and_filter(self) -> None:
        tools = [search_tool, ping_tool]
        registry = (
            ToolRegistry.builder().add(tools, prefix="ns", filter=lambda t: t.definition.name == "search").build()
        )
        assert [t.definition.name for t in registry.get_tools()] == ["ns__search"]

    def test_builder_exclude_suffix_exact(self) -> None:
        tools = [search_tool, ping_tool]
        registry = ToolRegistry.builder().add(tools, filter=tool_filter.EXCLUDE_SUFFIX("ping")).build()
        assert [t.definition.name for t in registry.get_tools()] == ["search"]

    def test_builder_exclude_suffix_with_prefix(self) -> None:
        tools = [_make_tool("mcp__payments__get_payees"), _make_tool("mcp__invoices__create_draft")]
        registry = ToolRegistry.builder().add(tools, filter=tool_filter.EXCLUDE_SUFFIX("get_payees")).build()
        assert [t.definition.name for t in registry.get_tools()] == ["mcp__invoices__create_draft"]

    def test_builder_exclude_suffix_multiple(self) -> None:
        tools = [search_tool, ping_tool, dup_tool]
        registry = ToolRegistry.builder().add(tools, filter=tool_filter.EXCLUDE_SUFFIX("ping", "dup")).build()
        assert [t.definition.name for t in registry.get_tools()] == ["search"]

    def test_builder_exclude_suffix_no_partial_match(self) -> None:
        tools = [_make_tool("get_payees"), _make_tool("xget_payees")]
        registry = ToolRegistry.builder().add(tools, filter=tool_filter.EXCLUDE_SUFFIX("get_payees")).build()
        assert [t.definition.name for t in registry.get_tools()] == ["xget_payees"]

    def test_builder_exclude_suffix_with_filter(self) -> None:
        tools = [search_tool, ping_tool, dup_tool]
        registry = (
            ToolRegistry.builder()
            .add(
                tools,
                filter=tool_filter.ALL_OF(
                    lambda t: t.definition.name != "dup",
                    tool_filter.EXCLUDE_SUFFIX("ping"),
                ),
            )
            .build()
        )
        assert [t.definition.name for t in registry.get_tools()] == ["search"]

    def test_builder_exclude_suffix_with_add_prefix(self) -> None:
        tools = [search_tool, ping_tool]
        registry = ToolRegistry.builder().add(tools, prefix="ns", filter=tool_filter.EXCLUDE_SUFFIX("ping")).build()
        assert [t.definition.name for t in registry.get_tools()] == ["ns__search"]

    def test_builder_include_suffix_exact(self) -> None:
        tools = [search_tool, ping_tool, dup_tool]
        registry = ToolRegistry.builder().add(tools, filter=tool_filter.INCLUDE_SUFFIX("ping")).build()
        assert [t.definition.name for t in registry.get_tools()] == ["ping"]

    def test_builder_include_suffix_with_prefix(self) -> None:
        tools = [_make_tool("mcp__payments__get_payees"), _make_tool("mcp__invoices__create_draft")]
        registry = ToolRegistry.builder().add(tools, filter=tool_filter.INCLUDE_SUFFIX("get_payees")).build()
        assert [t.definition.name for t in registry.get_tools()] == ["mcp__payments__get_payees"]

    def test_builder_include_suffix_multiple(self) -> None:
        tools = [search_tool, ping_tool, dup_tool]
        registry = ToolRegistry.builder().add(tools, filter=tool_filter.INCLUDE_SUFFIX("ping", "search")).build()
        assert [t.definition.name for t in registry.get_tools()] == ["search", "ping"]

    def test_builder_include_suffix_no_partial_match(self) -> None:
        tools = [_make_tool("get_payees"), _make_tool("xget_payees")]
        registry = ToolRegistry.builder().add(tools, filter=tool_filter.INCLUDE_SUFFIX("get_payees")).build()
        assert [t.definition.name for t in registry.get_tools()] == ["get_payees"]

    def test_builder_include_and_exclude_suffix(self) -> None:
        tools = [search_tool, ping_tool, dup_tool]
        registry = (
            ToolRegistry.builder()
            .add(
                tools,
                filter=tool_filter.ALL_OF(
                    tool_filter.INCLUDE_SUFFIX("search", "ping"),
                    tool_filter.EXCLUDE_SUFFIX("ping"),
                ),
            )
            .build()
        )
        assert [t.definition.name for t in registry.get_tools()] == ["search"]
