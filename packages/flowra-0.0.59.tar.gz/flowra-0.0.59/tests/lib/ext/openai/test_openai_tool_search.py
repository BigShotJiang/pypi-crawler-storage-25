from flowra.llm import LLMRequest, Tool
from flowra.llm.ext.openai import openai_tool_search


def _tool(name: str) -> Tool:
    return Tool(name=name, description="", input_schema=None)


def _request(tools: list[Tool] | None = None) -> LLMRequest:
    return LLMRequest(model="test", system=[], messages=[], tools=tools)


class TestOpenAIToolSearch:
    def test_defers_all_tools_by_default(self) -> None:
        ext = openai_tool_search()
        req = _request(tools=[_tool("a"), _tool("b")])
        ext(req)

        assert req.tools is not None
        assert req.tools[0].name == "__tool_search__"
        assert req.tools[0].extra["openai"]["type"] == "tool_search"
        assert req.tools[1].extra.get("openai", {}).get("defer_loading") is True
        assert req.tools[2].extra.get("openai", {}).get("defer_loading") is True

    def test_predicate_filters_tools(self) -> None:
        ext = openai_tool_search(predicate=lambda t: t.name.startswith("admin_"))
        req = _request(tools=[_tool("search"), _tool("admin_delete"), _tool("admin_ban")])
        ext(req)

        assert req.tools is not None
        assert req.tools[0].name == "__tool_search__"
        assert "defer_loading" not in req.tools[1].extra.get("openai", {})
        assert req.tools[1].name == "search"
        assert req.tools[2].extra.get("openai", {}).get("defer_loading") is True
        assert req.tools[3].extra.get("openai", {}).get("defer_loading") is True

    def test_no_tools_noop(self) -> None:
        ext = openai_tool_search()
        req = _request(tools=None)
        ext(req)
        assert req.tools is None

    def test_empty_tools_noop(self) -> None:
        ext = openai_tool_search()
        req = _request(tools=[])
        ext(req)
        assert req.tools == []

    def test_predicate_matches_nothing_noop(self) -> None:
        ext = openai_tool_search(predicate=lambda _: False)
        req = _request(tools=[_tool("a"), _tool("b")])
        ext(req)

        assert req.tools is not None
        assert len(req.tools) == 2
        assert req.tools[0].name == "a"

    def test_preserves_existing_extra(self) -> None:
        ext = openai_tool_search()
        tool = Tool(name="a", description="desc", extra={"custom": "value"})
        req = _request(tools=[tool])
        ext(req)

        assert req.tools is not None
        deferred = req.tools[1]
        assert deferred.extra["custom"] == "value"
        assert deferred.extra["openai"]["defer_loading"] is True
