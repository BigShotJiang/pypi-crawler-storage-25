import pytest

from flowra.llm import AssistantMessage, LLMRequest, SystemMessage, TextBlock, Tool, ToolUseBlock, UserMessage
from flowra.llm.ext.anthropic import (
    ToolSearchVariant,
    anthropic_cache_all,
    anthropic_cache_all_messages,
    anthropic_cache_all_system_messages,
    anthropic_cache_all_tools,
    anthropic_cache_non_transient_messages,
    anthropic_cache_non_transient_system_messages,
    anthropic_cache_non_transient_tools,
    anthropic_tool_search,
)

_CC = {"anthropic": {"cache_control": {"type": "ephemeral"}}}


def _sys(text: str, *, transient: bool = False) -> SystemMessage:
    return SystemMessage(blocks=[TextBlock(text=text, transient=transient)], transient=transient)


def _user(text: str, *, transient: bool = False) -> UserMessage:
    return UserMessage(blocks=[TextBlock(text=text, transient=transient)], transient=transient)


def _assistant(text: str, *, transient: bool = False) -> AssistantMessage:
    return AssistantMessage(blocks=[TextBlock(text=text, transient=transient)], transient=transient)


def _tool(name: str) -> Tool:
    return Tool(name=name, description="", input_schema=None)


def _request(
    system: list[SystemMessage] | None = None,
    messages: list[UserMessage | AssistantMessage] | None = None,
    tools: list[Tool] | None = None,
) -> LLMRequest:
    return LLMRequest(model="test", system=system or [], messages=messages or [], tools=tools)


# -- System message caching --


class TestCacheAllSystemMessages:
    def test_caches_last_system_block(self) -> None:
        req = _request(system=[_sys("a"), _sys("b")])
        anthropic_cache_all_system_messages(req)
        assert "cache_control" not in req.system[0].blocks[0].extra.get("anthropic", {})
        assert req.system[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}

    def test_empty_system(self) -> None:
        req = _request(system=[])
        anthropic_cache_all_system_messages(req)
        assert req.system == []

    def test_clears_old_cache(self) -> None:
        req = _request(
            system=[
                SystemMessage(blocks=[TextBlock(text="a", extra=_CC)]),
                _sys("b"),
            ]
        )
        anthropic_cache_all_system_messages(req)
        assert "cache_control" not in req.system[0].blocks[0].extra.get("anthropic", {})
        assert req.system[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}


class TestCacheNonTransientSystemMessages:
    def test_caches_last_non_transient(self) -> None:
        req = _request(system=[_sys("stable"), _sys("dynamic", transient=True)])
        anthropic_cache_non_transient_system_messages(req)
        assert req.system[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        assert "cache_control" not in req.system[1].blocks[0].extra.get("anthropic", {})

    def test_all_non_transient_caches_last(self) -> None:
        req = _request(system=[_sys("a"), _sys("b")])
        anthropic_cache_non_transient_system_messages(req)
        assert "cache_control" not in req.system[0].blocks[0].extra.get("anthropic", {})
        assert req.system[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}

    def test_all_transient_no_cache(self) -> None:
        req = _request(system=[_sys("a", transient=True)])
        anthropic_cache_non_transient_system_messages(req)
        assert "cache_control" not in req.system[0].blocks[0].extra.get("anthropic", {})

    def test_multi_block_system_message(self) -> None:
        req = _request(
            system=[
                SystemMessage(
                    blocks=[
                        TextBlock(text="stable"),
                        TextBlock(text="dynamic", transient=True),
                    ]
                ),
            ]
        )
        anthropic_cache_non_transient_system_messages(req)
        # Non-transient prefix: ["stable"]; stops at "dynamic" (transient)
        assert req.system[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        assert "cache_control" not in req.system[0].blocks[1].extra.get("anthropic", {})


# -- Tool caching --


class TestCacheAllTools:
    def test_caches_last_tool(self) -> None:
        req = _request(tools=[_tool("a"), _tool("b")])
        anthropic_cache_all_tools(req)
        assert req.tools is not None
        assert "cache_control" not in req.tools[0].extra.get("anthropic", {})
        assert req.tools[1].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}

    def test_empty_tools(self) -> None:
        req = _request(tools=None)
        anthropic_cache_all_tools(req)
        assert req.tools is None

    def test_clears_old_cache(self) -> None:
        req = _request(tools=[Tool(name="a", description="", extra=_CC), _tool("b")])
        anthropic_cache_all_tools(req)
        assert req.tools is not None
        assert "cache_control" not in req.tools[0].extra.get("anthropic", {})
        assert req.tools[1].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}


class TestCacheNonTransientTools:
    def test_caches_last_non_transient(self) -> None:
        req = _request(tools=[_tool("stable"), Tool(name="dynamic", description="", transient=True)])
        anthropic_cache_non_transient_tools(req)
        assert req.tools is not None
        assert req.tools[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        assert "cache_control" not in req.tools[1].extra.get("anthropic", {})

    def test_all_non_transient_caches_last(self) -> None:
        req = _request(tools=[_tool("a"), _tool("b")])
        anthropic_cache_non_transient_tools(req)
        assert req.tools is not None
        assert "cache_control" not in req.tools[0].extra.get("anthropic", {})
        assert req.tools[1].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}

    def test_all_transient_no_cache(self) -> None:
        req = _request(tools=[Tool(name="a", description="", transient=True)])
        anthropic_cache_non_transient_tools(req)
        assert req.tools is not None
        assert "cache_control" not in req.tools[0].extra.get("anthropic", {})


# -- Message caching --


class TestCacheAllMessages:
    def test_caches_last_message_block(self) -> None:
        req = _request(messages=[_user("hello"), _assistant("hi")])
        anthropic_cache_all_messages(req)
        assert "cache_control" not in req.messages[0].blocks[0].extra.get("anthropic", {})
        assert req.messages[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}

    def test_empty_messages(self) -> None:
        req = _request(messages=[])
        anthropic_cache_all_messages(req)
        assert req.messages == []

    def test_tool_use_block(self) -> None:
        req = _request(
            messages=[
                AssistantMessage(blocks=[ToolUseBlock(id="1", name="t", input={})]),
            ]
        )
        anthropic_cache_all_messages(req)
        assert req.messages[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}


class TestCacheNonTransientMessages:
    def test_caches_last_non_transient(self) -> None:
        req = _request(messages=[_user("history"), _user("current", transient=True)])
        anthropic_cache_non_transient_messages(req)
        assert req.messages[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        assert "cache_control" not in req.messages[1].blocks[0].extra.get("anthropic", {})

    def test_all_non_transient_caches_last(self) -> None:
        req = _request(messages=[_user("a"), _assistant("b")])
        anthropic_cache_non_transient_messages(req)
        assert "cache_control" not in req.messages[0].blocks[0].extra.get("anthropic", {})
        assert req.messages[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}


# -- Composite --


class TestAnthropicCacheAll:
    def test_caches_system_tools_and_messages(self) -> None:
        req = _request(
            system=[_sys("system")],
            messages=[_user("hello"), _assistant("hi")],
            tools=[_tool("a"), _tool("b")],
        )
        anthropic_cache_all(req)

        assert req.system[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        assert req.tools is not None
        assert "cache_control" not in req.tools[0].extra.get("anthropic", {})
        assert req.tools[1].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        assert "cache_control" not in req.messages[0].blocks[0].extra.get("anthropic", {})
        assert req.messages[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}

    def test_mutates_in_place(self) -> None:
        system = [_sys("system")]
        tools = [_tool("a")]
        req = _request(system=system, tools=tools)
        anthropic_cache_all(req)
        assert system[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        assert tools[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}


# -- Tool search --


class TestToolSearch:
    def test_defers_all_tools_by_default(self) -> None:
        ext = anthropic_tool_search()
        req = _request(tools=[_tool("a"), _tool("b")])
        ext(req)

        assert req.tools is not None
        # Search tool added at the beginning
        assert req.tools[0].name == "tool_search_tool_bm25"
        assert req.tools[0].extra["anthropic"]["type"] == "tool_search_tool_bm25_20251119"
        # Original tools have defer_loading
        assert req.tools[1].extra.get("anthropic", {}).get("defer_loading") is True
        assert req.tools[2].extra.get("anthropic", {}).get("defer_loading") is True

    def test_regex_variant(self) -> None:
        ext = anthropic_tool_search(variant=ToolSearchVariant.REGEX)
        req = _request(tools=[_tool("a")])
        ext(req)

        assert req.tools is not None
        assert req.tools[0].name == "tool_search_tool_regex"
        assert req.tools[0].extra["anthropic"]["type"] == "tool_search_tool_regex_20251119"

    def test_predicate_filters_tools(self) -> None:
        ext = anthropic_tool_search(predicate=lambda t: t.name.startswith("admin_"))
        req = _request(tools=[_tool("search"), _tool("admin_delete"), _tool("admin_ban")])
        ext(req)

        assert req.tools is not None
        assert req.tools[0].name == "tool_search_tool_bm25"
        assert "defer_loading" not in req.tools[1].extra.get("anthropic", {})
        assert req.tools[1].name == "search"
        assert req.tools[2].extra.get("anthropic", {}).get("defer_loading") is True
        assert req.tools[3].extra.get("anthropic", {}).get("defer_loading") is True

    def test_no_tools_noop(self) -> None:
        ext = anthropic_tool_search()
        req = _request(tools=None)
        ext(req)
        assert req.tools is None

    def test_predicate_matches_nothing_noop(self) -> None:
        ext = anthropic_tool_search(predicate=lambda t: False)
        req = _request(tools=[_tool("a"), _tool("b")])
        ext(req)

        assert req.tools is not None
        assert len(req.tools) == 2
        assert req.tools[0].name == "a"

    def test_invalid_variant_raises(self) -> None:
        with pytest.raises((ValueError, KeyError)):
            anthropic_tool_search(variant="unknown")  # type: ignore[arg-type]

    def test_preserves_existing_extra(self) -> None:
        ext = anthropic_tool_search()
        tool = Tool(name="a", description="desc", extra={"custom": "value"})
        req = _request(tools=[tool])
        ext(req)

        assert req.tools is not None
        deferred = req.tools[1]
        assert deferred.extra["custom"] == "value"
        assert deferred.extra["anthropic"]["defer_loading"] is True
