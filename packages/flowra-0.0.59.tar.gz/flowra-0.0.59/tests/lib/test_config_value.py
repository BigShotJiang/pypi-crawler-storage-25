from flowra.lib.config_value import resolve_config_value


class TestResolve:
    async def test_plain_value(self) -> None:
        assert await resolve_config_value(42) == 42

    async def test_sync_callable(self) -> None:
        assert await resolve_config_value(lambda: 42) == 42

    async def test_async_callable(self) -> None:
        async def get_value() -> int:
            return 42

        assert await resolve_config_value(get_value) == 42
