import dataclasses

from flowra.agent import AgentRuntime
from flowra.lib import LLMConfig
from flowra.lib.turn import TurnConfig
from flowra.lib.turn.tool_call import ToolCallAgent, ToolCallResult, ToolCallSpec
from flowra.llm import LLMProvider, LLMRequest, LLMResponse, ToolUseBlock
from flowra.tools import ToolRegistry, tool


class _UnusedProvider(LLMProvider):
    async def call(self, request: LLMRequest) -> LLMResponse:
        raise AssertionError("provider.call is not expected in these tests")


_UNUSED_PROVIDER = _UnusedProvider()


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AddParams:
    a: int
    b: int


@tool("add")
def add_tool(params: AddParams) -> int:
    """Add two numbers."""
    return params.a + params.b


class TestToolCallAgent:
    async def test_execute_tool_call(self) -> None:
        registry = ToolRegistry([add_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use),
        )

        assert isinstance(result, ToolCallResult)
        assert result.tool_use == tool_use
        assert result.result.tool_use_id == "call_1"
        assert result.result.content == "5"
        assert result.result.is_error is False

    async def test_denied_by_allowed_tools(self) -> None:
        registry = ToolRegistry([add_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use, allowed_tools={"other_tool"}),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is True
        assert result.result.content == "Unknown tool: add"

    async def test_denied_by_denied_tools(self) -> None:
        registry = ToolRegistry([add_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use, denied_tools={"add"}),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is True
        assert result.result.content == "Unknown tool: add"

    async def test_allowed_tools_permits_listed_tool(self) -> None:
        registry = ToolRegistry([add_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use, allowed_tools={"add"}),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is False
        assert result.result.content == "5"

    async def test_allowed_tools_wildcard(self) -> None:
        registry = ToolRegistry([add_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use, allowed_tools={"add*"}),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is False
        assert result.result.content == "5"

    async def test_allowed_tools_wildcard_no_match(self) -> None:
        registry = ToolRegistry([add_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use, allowed_tools={"mcp_*"}),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is True

    async def test_denied_tools_wildcard(self) -> None:
        registry = ToolRegistry([add_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use, denied_tools={"a*"}),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is True

    async def test_execute_interrupted(self) -> None:
        registry = ToolRegistry([add_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        runtime.interrupt()

        tool_use = ToolUseBlock(id="call_2", name="add", input={"a": 10, "b": 20})

        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use),
        )

        assert isinstance(result, ToolCallResult)
        assert result.tool_use == tool_use
        assert result.result.tool_use_id == "call_2"
        assert result.result.content == "Tool execution interrupted"
        assert result.result.is_error is True
