import dataclasses

from flowra.agent import (
    AgentRuntime,
    AppendOnlyList,
    Event,
    HookSubscription,
    InMemorySessionStorage,
    Interrupted,
    persistent,
)
from flowra.agent.flow.hooks import HooksImpl
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec, ConversationReadyEvent
from flowra.lib.turn import AfterToolCallEvent, StartTurnEvent
from flowra.lib.turn.tool_call import ToolCallAgentContext
from flowra.llm import (
    AssistantMessage,
    LLMProvider,
    LLMRequest,
    LLMResponse,
    StopReason,
    SystemMessage,
    TextBlock,
    ToolUseBlock,
    Usage,
    UserMessage,
)
from flowra.tools import ToolRegistry, tool


class TestChatAgent:
    async def test_single_turn(self) -> None:
        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Hello!")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        registry = ToolRegistry([])
        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
        )
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                ChatConfig: config,
            },
        )

        result = await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("Hi"),
        )

        assert isinstance(result, ChatResult)
        assert result.response == "Hello!"
        assert result.usage is not None
        assert result.usage.input_tokens == 10
        assert result.usage.output_tokens == 5

    async def test_multi_turn_session_accumulates(self) -> None:
        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text=f"Response {self.call_count}")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        registry = ToolRegistry([])
        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
        )
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: config,
            },
        )

        # Turn 1
        result1 = await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("First"),
            state="chat",
        )
        assert isinstance(result1, ChatResult)
        assert result1.response == "Response 1"

        # Turn 2 — LLM should see session history from turn 1
        # No cleanup needed: child node IDs are unique per run (r1.0, r2.0, etc.)
        result2 = await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("Second"),
            state="chat",
        )
        assert isinstance(result2, ChatResult)
        assert result2.response == "Response 2"

        # Check that turn 2 LLM request included history from turn 1
        turn2_request = provider.requests[1]
        # History: user("First") + assistant("Response 1")
        # Turn messages: user("Second")
        # Total: 3 messages
        assert len(turn2_request.messages) == 3

        # First message should be the user message from turn 1
        assert isinstance(turn2_request.messages[0], UserMessage)
        assert isinstance(turn2_request.messages[0].blocks[0], TextBlock)
        assert turn2_request.messages[0].blocks[0].text == "First"

        # Second should be assistant response from turn 1
        assert isinstance(turn2_request.messages[1], AssistantMessage)
        assert isinstance(turn2_request.messages[1].blocks[0], TextBlock)
        assert turn2_request.messages[1].blocks[0].text == "Response 1"

        # Third should be the new user message for turn 2
        assert isinstance(turn2_request.messages[2], UserMessage)
        assert isinstance(turn2_request.messages[2].blocks[0], TextBlock)
        assert turn2_request.messages[2].blocks[0].text == "Second"

    async def test_tool_use_turn(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class GreetParams:
            name: str

        @tool("greet")
        def greet_tool(params: GreetParams) -> str:
            """Greet someone."""
            return f"Hello, {params.name}!"

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        messages=[
                            AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="greet", input={"name": "World"})])
                        ],
                        stop_reason=StopReason.TOOL_USE,
                        usage=Usage(input_tokens=10, output_tokens=20),
                    )
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="I greeted World for you!")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=30, output_tokens=15),
                )

        provider = MockProvider()
        registry = ToolRegistry([greet_tool])
        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
        )
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                ChatConfig: config,
            },
        )

        result = await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("Greet the world"),
        )

        assert isinstance(result, ChatResult)
        assert result.response == "I greeted World for you!"
        # Usage should be aggregated across both LLM calls
        assert result.usage is not None
        assert result.usage.input_tokens == 40
        assert result.usage.output_tokens == 35

    async def test_none_response_when_no_text(self) -> None:
        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                # Assistant message with no text blocks (only tool use, then end turn)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([])
        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
        )
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                ChatConfig: config,
            },
        )

        result = await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("Hi"),
        )

        assert isinstance(result, ChatResult)
        assert result.response is None
        assert result.usage is None

    async def test_on_user_message_hook(self) -> None:
        def augment_user_message(event: Event[StartTurnEvent]) -> None:
            user_message = event.data.messages[0]
            # Add a system reminder after the user message
            reminder = UserMessage(
                blocks=[TextBlock(text="[Remember: be helpful]")],
                transient=True,
            )
            event.data.messages = [user_message, reminder]

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([])
        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
        )
        hooks = HooksImpl()
        hooks.on(StartTurnEvent, augment_user_message)
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                ChatConfig: config,
                HookSubscription: hooks,
            },
        )

        result = await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("Hello"),
        )

        assert isinstance(result, ChatResult)
        assert result.response == "OK"

        # LLM should have received 2 messages: original user message + reminder
        assert len(provider.requests) == 1
        llm_messages = provider.requests[0].messages
        assert len(llm_messages) == 2
        assert isinstance(llm_messages[0], UserMessage)
        assert isinstance(llm_messages[0].blocks[0], TextBlock)
        assert llm_messages[0].blocks[0].text == "Hello"
        assert isinstance(llm_messages[1], UserMessage)
        assert isinstance(llm_messages[1].blocks[0], TextBlock)
        assert llm_messages[1].blocks[0].text == "[Remember: be helpful]"

    async def test_transient_messages_auto_filtered_from_history(self) -> None:
        """Transient messages are automatically stripped from session history."""

        def inject_reminder(event: Event[StartTurnEvent]) -> None:
            user_message = event.data.messages[0]
            reminder = UserMessage(
                blocks=[TextBlock(text="[transient reminder]")],
                transient=True,
            )
            event.data.messages = [user_message, reminder]

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        registry = ToolRegistry([])
        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
        )
        hooks = HooksImpl()
        hooks.on(StartTurnEvent, inject_reminder)
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: config,
                HookSubscription: hooks,
            },
        )

        # Turn 1: reminder is injected but should be filtered from session
        await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("Hello"),
            state="chat",
        )

        # Turn 1 LLM saw the reminder (2 user messages + no session history)
        assert len(provider.requests[0].messages) == 2

        # Turn 2: session should NOT contain the transient reminder
        await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("Again"),
            state="chat",
        )

        # Turn 2 LLM: session(user "Hello" + assistant "OK") + turn(user "Again" + reminder)
        # The transient reminder from turn 1 should NOT be in session history
        turn2_messages = provider.requests[1].messages
        assert len(turn2_messages) == 4
        assert isinstance(turn2_messages[0], UserMessage)
        assert turn2_messages[0].blocks[0].text == "Hello"  # type: ignore[union-attr]
        assert isinstance(turn2_messages[1], AssistantMessage)
        assert turn2_messages[1].blocks[0].text == "OK"  # type: ignore[union-attr]
        assert isinstance(turn2_messages[2], UserMessage)
        assert turn2_messages[2].blocks[0].text == "Again"  # type: ignore[union-attr]
        assert isinstance(turn2_messages[3], UserMessage)
        assert turn2_messages[3].blocks[0].text == "[transient reminder]"  # type: ignore[union-attr]

    async def test_transient_auto_filtered_even_without_hook(self) -> None:
        """Transient messages are auto-filtered from session even without explicit SaveHistoryEvent hook."""

        def inject_reminder(event: Event[StartTurnEvent]) -> None:
            user_message = event.data.messages[0]
            reminder = UserMessage(
                blocks=[TextBlock(text="[transient]")],
                transient=True,
            )
            event.data.messages = [user_message, reminder]

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        registry = ToolRegistry([])
        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
        )
        hooks = HooksImpl()
        hooks.on(StartTurnEvent, inject_reminder)
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: config,
                HookSubscription: hooks,
            },
        )

        await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("Hello"),
            state="chat",
        )
        await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("Again"),
            state="chat",
        )

        # Transient reminder auto-filtered from session
        # Turn 2: session(user "Hello" + assistant "OK") + turn(user "Again" + transient)
        turn2_messages = provider.requests[1].messages
        assert len(turn2_messages) == 4
        assert turn2_messages[0].blocks[0].text == "Hello"  # type: ignore[union-attr]
        assert turn2_messages[1].blocks[0].text == "OK"  # type: ignore[union-attr]
        assert turn2_messages[2].blocks[0].text == "Again"  # type: ignore[union-attr]
        assert turn2_messages[3].blocks[0].text == "[transient]"  # type: ignore[union-attr]

    async def test_named_scope_via_state_parameter(self) -> None:
        """Parent can redirect ChatAgent's persistent scope to a named scope via state=."""

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        registry = ToolRegistry([])
        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
        )
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: config,
            },
        )

        await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("Hello"),
            state=persistent.NAMED("chat_history"),
        )
        await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("World"),
            state=persistent.NAMED("chat_history"),
        )

        # History stored under named scope key directly
        named_state = await storage.load("chat_history")
        assert named_state is not None
        assert "history" in named_state
        assert len(named_state["history"]) == 4  # 2 turns x (user + assistant)

        # Turn 2 should see turn 1 history
        turn2_messages = provider.requests[1].messages
        assert len(turn2_messages) == 3  # history(user, assistant) + turn(user)
        assert turn2_messages[0].blocks[0].text == "Hello"  # type: ignore[union-attr]
        assert turn2_messages[1].blocks[0].text == "OK"  # type: ignore[union-attr]
        assert turn2_messages[2].blocks[0].text == "World"  # type: ignore[union-attr]

    async def test_history_slot_via_callable(self) -> None:
        """history= callable receives AgentStore and controls where history is stored."""

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        registry = ToolRegistry([])
        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
            history=lambda store: store["shared"].slot(AppendOnlyList[UserMessage | AssistantMessage], "conv"),
        )
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: config,
            },
        )

        await runtime.run(agent=ChatAgent, spec=ChatSpec.text("Hello"), state="s1")
        await runtime.run(agent=ChatAgent, spec=ChatSpec.text("World"), state="s1")

        # Turn 2 should see turn 1 history from the named scope
        turn2_messages = provider.requests[1].messages
        assert len(turn2_messages) == 3
        assert turn2_messages[0].blocks[0].text == "Hello"  # type: ignore[union-attr]
        assert turn2_messages[1].blocks[0].text == "OK"  # type: ignore[union-attr]
        assert turn2_messages[2].blocks[0].text == "World"  # type: ignore[union-attr]

        # History stored under the named scope, not the persistent scope
        named_state = await storage.load("shared")
        assert named_state is not None
        assert "conv" in named_state

    async def test_history_slot_via_ephemeral(self) -> None:
        """history= with ephemeral scope means history does not persist across runs."""

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        registry = ToolRegistry([])
        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
            history=lambda store: store.ephemeral.slot(AppendOnlyList[UserMessage | AssistantMessage], "history"),
        )
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: config,
            },
        )

        await runtime.run(agent=ChatAgent, spec=ChatSpec.text("Hello"), state="s1")
        await runtime.run(agent=ChatAgent, spec=ChatSpec.text("World"), state="s1")

        # Turn 2 should NOT see turn 1 history (ephemeral resets each run)
        turn2_messages = provider.requests[1].messages
        assert len(turn2_messages) == 1
        assert turn2_messages[0].blocks[0].text == "World"  # type: ignore[union-attr]

    async def test_system_messages_prepended_to_session(self) -> None:
        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        registry = ToolRegistry([])
        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
        )
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: config,
            },
        )

        await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("Hello"),
            state="chat",
        )
        await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("Again"),
            state="chat",
        )

        # Turn 1: system in request.system, user in request.messages
        turn1_system = provider.requests[0].system
        turn1_messages = provider.requests[0].messages
        assert len(turn1_system) == 1
        assert isinstance(turn1_system[0], SystemMessage)
        assert turn1_system[0].blocks[0].text == "You are helpful."
        assert len(turn1_messages) == 1
        assert turn1_messages[0].blocks[0].text == "Hello"  # type: ignore[union-attr]

        # Turn 2: system in request.system, session(user, assistant) + user in request.messages
        turn2_system = provider.requests[1].system
        turn2_messages = provider.requests[1].messages
        assert len(turn2_system) == 1
        assert isinstance(turn2_system[0], SystemMessage)
        assert turn2_system[0].blocks[0].text == "You are helpful."
        assert len(turn2_messages) == 3
        assert turn2_messages[0].blocks[0].text == "Hello"  # type: ignore[union-attr]
        assert turn2_messages[1].blocks[0].text == "OK"  # type: ignore[union-attr]
        assert turn2_messages[2].blocks[0].text == "Again"  # type: ignore[union-attr]

    async def test_interrupt_before_llm_saves_history(self) -> None:
        """Interrupt before LLM call: user message is saved to history, Interrupted propagates."""

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        config = ChatConfig(
            tools=ToolRegistry([]),
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
        )
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: config,
            },
        )
        runtime.interrupt()

        # Turn 1: interrupted before LLM call
        result1 = await runtime.run(agent=ChatAgent, spec=ChatSpec.text("Hello"), state="chat")
        assert isinstance(result1, Interrupted)

        # Turn 2: should see "Hello" in history
        result2 = await runtime.run(agent=ChatAgent, spec=ChatSpec.text("World"), state="chat")
        assert isinstance(result2, ChatResult)
        assert result2.response == "OK"

        # LLM received history(user "Hello") + turn(user "World")
        assert len(provider.requests) == 1
        msgs = provider.requests[0].messages
        assert len(msgs) == 2
        assert msgs[0].blocks[0].text == "Hello"  # type: ignore[union-attr]
        assert msgs[1].blocks[0].text == "World"  # type: ignore[union-attr]

    async def test_interrupt_after_tool_saves_partial_history(self) -> None:
        """Interrupt after tool execution: tool results are saved to history."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Params:
            name: str

        @tool("greet")
        def greet(params: Params) -> str:
            """Greet."""
            return f"Hello, {params.name}!"

        runtime_ref: list[AgentRuntime] = []

        def interrupt_after_tool(event: Event[AfterToolCallEvent]) -> None:
            runtime_ref[0].interrupt()

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                self.requests.append(request)
                if self.call_count == 1:
                    return LLMResponse(
                        messages=[AssistantMessage(blocks=[ToolUseBlock(id="c1", name="greet", input={"name": "W"})])],
                        stop_reason=StopReason.TOOL_USE,
                        usage=Usage(input_tokens=10, output_tokens=5),
                    )
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        config = ChatConfig(
            tools=ToolRegistry([greet]),
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
        )

        hooks = HooksImpl()
        hooks.on(AfterToolCallEvent, interrupt_after_tool)
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: config,
                HookSubscription: hooks,
            },
        )
        runtime_ref.append(runtime)

        # Turn 1: tool executes, then interrupted
        result1 = await runtime.run(agent=ChatAgent, spec=ChatSpec.text("Hi"), state="chat")
        assert isinstance(result1, Interrupted)
        # LLM was called once (tool use), tool executed, then interrupt caught in collect_results
        assert provider.call_count == 1

        # Turn 2: should see partial history from interrupted turn
        runtime2 = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: config,
            },
        )
        result2 = await runtime2.run(agent=ChatAgent, spec=ChatSpec.text("Continue"), state="chat")
        assert isinstance(result2, ChatResult)
        assert result2.response == "Done"

        # Turn 2 LLM should see history from interrupted turn + new message
        turn2_msgs = provider.requests[-1].messages
        # history: user("Hi"), assistant(tool_use), user(tool_result) + turn: user("Continue")
        assert len(turn2_msgs) == 4
        assert isinstance(turn2_msgs[0], UserMessage)
        assert turn2_msgs[0].blocks[0].text == "Hi"  # type: ignore[union-attr]
        assert isinstance(turn2_msgs[1], AssistantMessage)
        assert isinstance(turn2_msgs[1].blocks[0], ToolUseBlock)
        assert isinstance(turn2_msgs[3], UserMessage)
        assert turn2_msgs[3].blocks[0].text == "Continue"  # type: ignore[union-attr]


class _NestedChatAgent(ChatAgent):
    """Subclass just so the registry can hold a second top-level ChatAgent path."""


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _NestedToolParams:
    prompt: str


class TestChatAgentTurnReadyIsolation:
    """Regression: ``ChatAgent`` subscribes to ``TurnReadyEvent`` with
    ``scope=TurnAgent`` (registry-based), so a TurnAgent running in a
    different registry subtree (e.g. inside an agent-as-tool) must NOT
    trigger the outer ChatAgent's handler.

    If the subscription were ``during=TurnAgent`` (call-stack-based), any
    TurnAgent frame on the stack below the outer ChatAgent would match
    — including the nested one from the inner chat — and the outer
    ChatAgent's ``ConversationReadyEvent`` would fire twice (once for its
    own turn, once for the nested turn's messages).
    """

    async def test_nested_chat_tool_does_not_trigger_outer_turn_ready(self) -> None:
        @tool("call_nested")
        def call_nested(params: _NestedToolParams, ctx: ToolCallAgentContext) -> None:
            """Spawn an inner ChatAgent via agent-as-tool."""
            ctx.call_agent(_NestedChatAgent, ChatSpec.text(params.prompt))

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                # The OUTER chat sees the "call_nested" tool in its request; use it once.
                tool_names = {t.name for t in (request.tools or [])}
                if "call_nested" in tool_names and self.call_count == 1:
                    return LLMResponse(
                        messages=[
                            AssistantMessage(
                                blocks=[ToolUseBlock(id="c1", name="call_nested", input={"prompt": "inner"})]
                            )
                        ],
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Everyone else (inner chat's turn, outer chat's follow-up) replies with plain text.
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="done")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        outer_config = ChatConfig(
            tools=ToolRegistry([call_nested]),
            llm_config=LLMConfig(provider=provider, model="test"),
            system=[],
        )
        runtime = AgentRuntime(
            agents={"chat": ChatAgent, "nested_chat": _NestedChatAgent},
            services={
                ChatConfig: outer_config,
            },
        )

        events: list[Event[ConversationReadyEvent]] = []
        runtime.hooks.on(ConversationReadyEvent, events.append)

        result = await runtime.run(agent=ChatAgent, spec=ChatSpec.text("trigger inner"))

        assert isinstance(result, ChatResult)
        assert result.response == "done"

        # Exactly two ConversationReadyEvent emissions — one from outer ChatAgent's
        # subscription (its own TurnAgent at /chat/turn), one from inner ChatAgent's
        # subscription (its own TurnAgent at /nested_chat/turn).
        # If outer used during=TurnAgent, the nested TurnReadyEvent would ALSO fire
        # outer's handler, giving 3 events.
        assert len(events) == 2

        # Confirm each event's conversation carries the right turn messages.
        outer_user_text = events[0].data.conversation[0].blocks[0].text  # type: ignore[union-attr]
        inner_user_text = events[1].data.conversation[0].blocks[0].text  # type: ignore[union-attr]
        assert outer_user_text == "trigger inner"
        assert inner_user_text == "inner"
