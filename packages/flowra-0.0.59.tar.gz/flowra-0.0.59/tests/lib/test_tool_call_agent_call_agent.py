import dataclasses
import uuid
from datetime import date, datetime, time
from decimal import Decimal
from typing import Annotated

import pytest

from flowra.agent import Agent, AgentRuntime, InMemorySessionStorage, agent_arg, step
from flowra.agent.definition import AgentDefinition
from flowra.lib import LLMConfig
from flowra.lib.turn import TurnConfig
from flowra.lib.turn.tool_call import (
    ToolCallAgent,
    ToolCallAgentContext,
    ToolCallResult,
    ToolCallSpec,
    agent_tool,
    get_agent_tool,
    make_agent_tool,
)
from flowra.llm import LLMProvider, LLMRequest, LLMResponse, ToolUseBlock
from flowra.tools import ToolErrorKind, ToolRegistry, ToolResult, tool


class _UnusedProvider(LLMProvider):
    async def call(self, request: LLMRequest) -> LLMResponse:
        raise AssertionError("provider.call is not expected in these tests")


_UNUSED_PROVIDER = _UnusedProvider()

# -- Test agent that will be spawned via call_agent --


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GreetSpec:
    name: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GreetResult:
    greeting: str


class GreetAgent(Agent[GreetSpec, GreetResult]):
    @step(entry=True)
    async def greet(self, spec: Annotated[GreetSpec, agent_arg.AGENT_SPEC]) -> GreetResult:
        return GreetResult(greeting=f"Hello, {spec.name}!")


# -- Tools --


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class DelegateParams:
    name: str


@tool("delegate")
def delegate_tool(params: DelegateParams, ctx: ToolCallAgentContext) -> None:
    """Delegate greeting to GreetAgent."""
    ctx.call_agent(GreetAgent, GreetSpec(name=params.name))


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class NoopParams:
    pass


@tool("noop")
def noop_tool(params: NoopParams) -> str:
    """Simple tool that does not call_agent."""
    return "done"


class TestToolCallAgentCallAgent:
    async def test_call_agent_spawns_and_returns_result(self) -> None:
        registry = ToolRegistry([delegate_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "greet": GreetAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="delegate", input={"name": "World"})

        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use),
        )

        assert isinstance(result, ToolCallResult)
        assert result.tool_use == tool_use
        assert result.result.tool_use_id == "call_1"
        assert result.result.is_error is False
        assert '"Hello, World!"' in result.result.content

    async def test_no_call_agent_returns_normal_result(self) -> None:
        registry = ToolRegistry([noop_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_2", name="noop", input={})

        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.content == "done"
        assert result.result.is_error is False

    async def test_call_agent_twice_raises(self) -> None:
        """Calling call_agent() twice in one tool execution raises RuntimeError."""
        ctx = ToolCallAgentContext()
        ctx.call_agent(GreetAgent, GreetSpec(name="A"))

        with pytest.raises(RuntimeError, match=r"call_agent.*once"):
            ctx.call_agent(GreetAgent, GreetSpec(name="B"))


class TestMakeAgentTool:
    async def test_make_agent_tool_creates_working_tool(self) -> None:
        local_tool = make_agent_tool(GreetAgent, name="greet", description="Greet someone")
        assert local_tool.definition.name == "greet"
        assert local_tool.definition.description == "Greet someone"
        assert local_tool.definition.input_schema is not None
        assert "name" in local_tool.definition.input_schema.get("properties", {})
        assert local_tool.definition.output_schema is not None
        assert "greeting" in local_tool.definition.output_schema.get("properties", {})

        registry = ToolRegistry([local_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "greet": GreetAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="greet", input={"name": "Alice"})
        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is False
        assert '"Hello, Alice!"' in result.result.content

    async def test_make_agent_tool_with_string_ref(self) -> None:
        local_tool = make_agent_tool(GreetAgent, name="greet", description="Greet", agent_ref="/greet")

        registry = ToolRegistry([local_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "greet": GreetAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="greet", input={"name": "Bob"})
        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is False
        assert '"Hello, Bob!"' in result.result.content


class TestAgentToolDecorator:
    async def test_decorator_and_get_agent_tool(self) -> None:
        @agent_tool(name="greet2", description="Greet v2")
        class DecoratedGreetAgent(Agent[GreetSpec, GreetResult]):
            @step(entry=True)
            async def greet(self, spec: Annotated[GreetSpec, agent_arg.AGENT_SPEC]) -> GreetResult:
                return GreetResult(greeting=f"Hi, {spec.name}!")

        local_tool = get_agent_tool(DecoratedGreetAgent)
        assert local_tool.definition.name == "greet2"
        assert local_tool.definition.description == "Greet v2"

        registry = ToolRegistry([local_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "greet2": DecoratedGreetAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="greet2", input={"name": "Eve"})
        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is False
        assert '"Hi, Eve!"' in result.result.content

    def test_get_agent_tool_raises_for_undecorated(self) -> None:
        with pytest.raises(ValueError, match="not decorated"):
            get_agent_tool(GreetAgent)


class TestAgentToolDescriptionFromDocstring:
    def test_make_agent_tool_uses_class_docstring(self) -> None:
        class DocstringAgent(Agent[GreetSpec, GreetResult]):
            """Greet someone nicely."""

            @step(entry=True)
            async def greet(self, spec: Annotated[GreetSpec, agent_arg.AGENT_SPEC]) -> GreetResult:
                return GreetResult(greeting=f"Hello, {spec.name}!")

        local_tool = make_agent_tool(DocstringAgent, name="greet_doc")
        assert local_tool.definition.description == "Greet someone nicely."

    def test_make_agent_tool_explicit_description_overrides_docstring(self) -> None:
        class DocstringAgent2(Agent[GreetSpec, GreetResult]):
            """From docstring."""

            @step(entry=True)
            async def greet(self, spec: Annotated[GreetSpec, agent_arg.AGENT_SPEC]) -> GreetResult:
                return GreetResult(greeting=f"Hello, {spec.name}!")

        local_tool = make_agent_tool(DocstringAgent2, name="greet_explicit", description="Explicit desc")
        assert local_tool.definition.description == "Explicit desc"

    def test_make_agent_tool_no_description_no_docstring_raises(self) -> None:
        with pytest.raises(ValueError, match="must have description or agent class docstring"):
            make_agent_tool(GreetAgent, name="greet_nodesc")

    def test_agent_tool_decorator_uses_class_docstring(self) -> None:
        @agent_tool(name="greet_dec_doc")
        class DecDocAgent(Agent[GreetSpec, GreetResult]):
            """Decorated with docstring."""

            @step(entry=True)
            async def greet(self, spec: Annotated[GreetSpec, agent_arg.AGENT_SPEC]) -> GreetResult:
                return GreetResult(greeting=f"Hello, {spec.name}!")

        local_tool = get_agent_tool(DecDocAgent)
        assert local_tool.definition.description == "Decorated with docstring."

    def test_agent_tool_decorator_explicit_description_overrides(self) -> None:
        @agent_tool(name="greet_dec_explicit", description="Explicit")
        class DecExplicitAgent(Agent[GreetSpec, GreetResult]):
            """From docstring."""

            @step(entry=True)
            async def greet(self, spec: Annotated[GreetSpec, agent_arg.AGENT_SPEC]) -> GreetResult:
                return GreetResult(greeting=f"Hello, {spec.name}!")

        local_tool = get_agent_tool(DecExplicitAgent)
        assert local_tool.definition.description == "Explicit"


class TestAgentToolOutputSchema:
    def test_output_schema_from_single_result_type(self) -> None:
        local_tool = make_agent_tool(GreetAgent, name="greet", description="Greet")
        assert local_tool.definition.output_schema is not None
        assert "greeting" in local_tool.definition.output_schema.get("properties", {})

    def test_output_schema_excludes_tool_result(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class MySpec:
            text: str

        class MyAgent(Agent[MySpec, GreetResult | ToolResult]):
            """Agent with ToolResult."""

            @step(entry=True)
            async def run(self, spec: Annotated[MySpec, agent_arg.AGENT_SPEC]) -> GreetResult | ToolResult:
                return GreetResult(greeting=spec.text)

        local_tool = make_agent_tool(MyAgent, name="my", description="My")
        assert local_tool.definition.output_schema is not None
        assert "greeting" in local_tool.definition.output_schema.get("properties", {})

    def test_output_schema_none_for_only_tool_result(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class MySpec:
            pass

        class MyAgent(Agent[MySpec, ToolResult]):
            """Agent returning only ToolResult."""

            @step(entry=True)
            async def run(self, spec: Annotated[MySpec, agent_arg.AGENT_SPEC]) -> ToolResult:
                return ToolResult(content="ok")

        local_tool = make_agent_tool(MyAgent, name="my", description="My")
        assert local_tool.definition.output_schema is None


class TestAgentToolReturnsToolResult:
    async def test_agent_tool_returns_tool_result_error(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class ValidateSpec:
            text: str

        class ValidateAgent(Agent[ValidateSpec, GreetResult | ToolResult]):
            """Validate text."""

            @step(entry=True)
            async def validate(self, spec: Annotated[ValidateSpec, agent_arg.AGENT_SPEC]) -> GreetResult | ToolResult:
                if spec.text == "bad":
                    return ToolResult(content="Validation failed", is_error=True)
                return GreetResult(greeting=f"Valid: {spec.text}")

        local_tool = make_agent_tool(ValidateAgent, name="validate", description="Validate text")
        registry = ToolRegistry([local_tool])
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "validate": ValidateAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
            storage=storage,
        )

        tool_use = ToolUseBlock(id="call_1", name="validate", input={"text": "bad"})
        result = await runtime.run(agent=ToolCallAgent, spec=ToolCallSpec(tool_use=tool_use))

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is True
        assert result.result.content == "Validation failed"

    async def test_agent_tool_returns_tool_result_success(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class ValidateSpec:
            text: str

        class ValidateAgent(Agent[ValidateSpec, GreetResult | ToolResult]):
            """Validate text."""

            @step(entry=True)
            async def validate(self, spec: Annotated[ValidateSpec, agent_arg.AGENT_SPEC]) -> GreetResult | ToolResult:
                if spec.text == "bad":
                    return ToolResult(content="Validation failed", is_error=True)
                return GreetResult(greeting=f"Valid: {spec.text}")

        local_tool = make_agent_tool(ValidateAgent, name="validate", description="Validate text")
        registry = ToolRegistry([local_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "validate": ValidateAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="validate", input={"text": "good"})
        result = await runtime.run(agent=ToolCallAgent, spec=ToolCallSpec(tool_use=tool_use))

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is False
        assert '"Valid: good"' in result.result.content

    async def test_agent_tool_returns_tool_result_with_error_kind(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class CheckSpec:
            pass

        class CheckAgent(Agent[CheckSpec, ToolResult]):
            """Check something."""

            @step(entry=True)
            async def check(self, spec: Annotated[CheckSpec, agent_arg.AGENT_SPEC]) -> ToolResult:
                return ToolResult(content="Not valid", is_error=True, error_kind=ToolErrorKind.EXECUTION)

        local_tool = make_agent_tool(CheckAgent, name="check", description="Check")
        registry = ToolRegistry([local_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "check": CheckAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="check", input={})
        result = await runtime.run(agent=ToolCallAgent, spec=ToolCallSpec(tool_use=tool_use))

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is True
        assert result.result.content == "Not valid"
        assert result.error_kind == ToolErrorKind.EXECUTION

    async def test_agent_tool_returns_tool_result_non_error(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class CheckSpec:
            pass

        class CheckAgent(Agent[CheckSpec, ToolResult]):
            """Return non-error ToolResult."""

            @step(entry=True)
            async def check(self, spec: Annotated[CheckSpec, agent_arg.AGENT_SPEC]) -> ToolResult:
                return ToolResult(content="all good")

        local_tool = make_agent_tool(CheckAgent, name="check", description="Check")
        registry = ToolRegistry([local_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "check": CheckAgent},
            services={
                TurnConfig: TurnConfig(
                    tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
                )
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="check", input={})
        result = await runtime.run(agent=ToolCallAgent, spec=ToolCallSpec(tool_use=tool_use))

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is False
        assert result.result.content == "all good"
        assert result.error_kind is None


class TestMakeAgentToolErrors:
    async def test_agent_tool_outside_tool_call_agent_raises(self) -> None:
        local_tool = make_agent_tool(GreetAgent, name="greet", description="Greet")
        registry = ToolRegistry([local_tool])
        result = await registry.execute("greet", {"name": "Alice"}, services={})
        assert result.is_error is True
        assert "ToolCallAgentContext" in result.content

    def test_multiple_spec_types_raises(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class OtherSpec:
            value: int

        agent_def = dataclasses.replace(
            GreetAgent.__agent_definition__,
            spec_types=frozenset({GreetSpec, OtherSpec}),
        )
        with pytest.raises(TypeError, match="exactly one spec type"):
            make_agent_tool(agent_def, name="greet", description="Greet", agent_ref="/greet")

    def test_agent_definition_without_agent_ref_raises(self) -> None:
        agent_def = GreetAgent.__agent_definition__
        assert isinstance(agent_def, AgentDefinition)
        with pytest.raises(TypeError, match="agent_ref is required"):
            make_agent_tool(agent_def, name="greet", description="Greet")


# -- Primitive result type agents -----------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class PrimitiveSpec:
    value: str


class StrAgent(Agent[PrimitiveSpec, str]):
    """Agent returning str."""

    @step(entry=True)
    async def run(self, spec: Annotated[PrimitiveSpec, agent_arg.AGENT_SPEC]) -> str:
        return f"hello {spec.value}"


class IntAgent(Agent[PrimitiveSpec, int]):
    """Agent returning int."""

    @step(entry=True)
    async def run(self, spec: Annotated[PrimitiveSpec, agent_arg.AGENT_SPEC]) -> int:
        return len(spec.value)


class BoolAgent(Agent[PrimitiveSpec, bool]):
    """Agent returning bool."""

    @step(entry=True)
    async def run(self, spec: Annotated[PrimitiveSpec, agent_arg.AGENT_SPEC]) -> bool:
        return spec.value == "yes"


class DecimalAgent(Agent[PrimitiveSpec, Decimal]):
    """Agent returning Decimal."""

    @step(entry=True)
    async def run(self, spec: Annotated[PrimitiveSpec, agent_arg.AGENT_SPEC]) -> Decimal:
        return Decimal(spec.value)


class UUIDAgent(Agent[PrimitiveSpec, uuid.UUID]):
    """Agent returning UUID."""

    @step(entry=True)
    async def run(self, spec: Annotated[PrimitiveSpec, agent_arg.AGENT_SPEC]) -> uuid.UUID:
        return uuid.UUID(spec.value)


class DateAgent(Agent[PrimitiveSpec, date]):
    """Agent returning date."""

    @step(entry=True)
    async def run(self, spec: Annotated[PrimitiveSpec, agent_arg.AGENT_SPEC]) -> date:
        return date.fromisoformat(spec.value)


class DatetimeAgent(Agent[PrimitiveSpec, datetime]):
    """Agent returning datetime."""

    @step(entry=True)
    async def run(self, spec: Annotated[PrimitiveSpec, agent_arg.AGENT_SPEC]) -> datetime:
        return datetime.fromisoformat(spec.value)


class TimeAgent(Agent[PrimitiveSpec, time]):
    """Agent returning time."""

    @step(entry=True)
    async def run(self, spec: Annotated[PrimitiveSpec, agent_arg.AGENT_SPEC]) -> time:
        return time.fromisoformat(spec.value)


class BytesAgent(Agent[PrimitiveSpec, bytes]):
    """Agent returning bytes."""

    @step(entry=True)
    async def run(self, spec: Annotated[PrimitiveSpec, agent_arg.AGENT_SPEC]) -> bytes:
        return spec.value.encode()


async def _run_agent_tool(child_agent: type[Agent], input_value: str, tool_name: str = "child") -> ToolCallResult:
    local_tool = make_agent_tool(child_agent, name=tool_name, description="Child")
    registry = ToolRegistry([local_tool])
    runtime = AgentRuntime(
        agents={"tool_call": ToolCallAgent, tool_name: child_agent},
        services={
            TurnConfig: TurnConfig(
                tools=registry, llm_config=LLMConfig(provider=_UNUSED_PROVIDER, model="test"), system=[], history=[]
            )
        },
    )
    tool_use = ToolUseBlock(id="call_1", name=tool_name, input={"value": input_value})
    result = await runtime.run(agent=ToolCallAgent, spec=ToolCallSpec(tool_use=tool_use))
    assert isinstance(result, ToolCallResult)
    return result


class TestPrimitiveResultSchema:
    """Primitive result types yield output_schema=None (no JSON Schema root for primitives)."""

    def test_str_result_output_schema_is_none(self) -> None:
        local_tool = make_agent_tool(StrAgent, name="str_agent", description="Str")
        assert local_tool.definition.output_schema is None

    def test_int_result_output_schema_is_none(self) -> None:
        local_tool = make_agent_tool(IntAgent, name="int_agent", description="Int")
        assert local_tool.definition.output_schema is None

    def test_decimal_result_output_schema_is_none(self) -> None:
        local_tool = make_agent_tool(DecimalAgent, name="d", description="D")
        assert local_tool.definition.output_schema is None

    def test_uuid_result_output_schema_is_none(self) -> None:
        local_tool = make_agent_tool(UUIDAgent, name="u", description="U")
        assert local_tool.definition.output_schema is None

    def test_primitive_union_with_tool_result_output_schema_is_none(self) -> None:
        class StrOrErrAgent(Agent[PrimitiveSpec, str | ToolResult]):
            """Str or ToolResult."""

            @step(entry=True)
            async def run(self, spec: Annotated[PrimitiveSpec, agent_arg.AGENT_SPEC]) -> str | ToolResult:
                return spec.value

        local_tool = make_agent_tool(StrOrErrAgent, name="s", description="S")
        assert local_tool.definition.output_schema is None


class TestPrimitiveResultSerialization:
    """Primitive results flow through ToolCallAgent as stringified content."""

    async def test_str_result_content_is_plain_string(self) -> None:
        result = await _run_agent_tool(StrAgent, "world")
        assert result.result.is_error is False
        assert result.result.content == "hello world"

    async def test_int_result_content_is_decimal_string(self) -> None:
        result = await _run_agent_tool(IntAgent, "Alice")
        assert result.result.content == "5"

    async def test_bool_true_result(self) -> None:
        result = await _run_agent_tool(BoolAgent, "yes")
        assert result.result.content == "True"

    async def test_bool_false_result(self) -> None:
        result = await _run_agent_tool(BoolAgent, "no")
        assert result.result.content == "False"

    async def test_decimal_result_preserves_precision(self) -> None:
        result = await _run_agent_tool(DecimalAgent, "3.14159265358979323846")
        assert result.result.content == "3.14159265358979323846"

    async def test_uuid_result_is_canonical_string(self) -> None:
        value = "12345678-1234-5678-1234-567812345678"
        result = await _run_agent_tool(UUIDAgent, value)
        assert result.result.content == value

    async def test_date_result_is_iso(self) -> None:
        result = await _run_agent_tool(DateAgent, "2026-04-20")
        assert result.result.content == "2026-04-20"

    async def test_datetime_result_is_iso(self) -> None:
        result = await _run_agent_tool(DatetimeAgent, "2026-04-20T15:30:00")
        assert result.result.content == "2026-04-20T15:30:00"

    async def test_time_result_is_iso(self) -> None:
        result = await _run_agent_tool(TimeAgent, "15:30:45")
        assert result.result.content == "15:30:45"

    async def test_bytes_result_base64(self) -> None:
        import base64

        result = await _run_agent_tool(BytesAgent, "hi")
        assert result.result.content == base64.b64encode(b"hi").decode("ascii")


class TestPrimitiveResultTypeRegistry:
    """Primitive result types don't pollute the type registry (which stores only dataclasses)."""

    def test_primitive_not_registered(self) -> None:
        definition = IntAgent.__agent_definition__
        assert int not in definition.type_registry.values()
        assert PrimitiveSpec in definition.type_registry.values()

    def test_primitive_result_type_recorded(self) -> None:
        definition = IntAgent.__agent_definition__
        assert definition.result_types == frozenset({int})


class TestStepValidationRejectsUnsupported:
    """Non-primitive, non-dataclass return types are rejected at compile time."""

    def test_custom_class_rejected(self) -> None:
        class Custom:
            pass

        def _build() -> None:
            class BadAgent(Agent[PrimitiveSpec, Custom]):
                @step(entry=True)
                async def run(self, spec: Annotated[PrimitiveSpec, agent_arg.AGENT_SPEC]) -> Custom:
                    return Custom()

            assert BadAgent  # pragma: no cover

        with pytest.raises(TypeError, match="must be a dataclass"):
            _build()
