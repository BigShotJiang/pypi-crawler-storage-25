# Getting Started

This guide walks you through building your first LLM-powered application with
Flowra — from a single LLM call to a multi-turn chatbot with tools.

## Installation

```bash
pip install flowra[anthropic]   # Claude via Vertex AI
pip install flowra[openai]      # OpenAI-compatible APIs
pip install flowra[google]      # Gemini via Vertex AI
pip install flowra[providers]   # all providers
```

Flowra requires Python 3.12+.

## Your first LLM call

The simplest thing you can do with Flowra is call an LLM directly through
the provider interface:

```python
import asyncio
from flowra.llm import LLMRequest, TextBlock, UserMessage
from flowra.llm.providers.openai import OpenAIProvider

async def main() -> None:
    async with OpenAIProvider(api_key="sk-...") as provider:
        request = LLMRequest(
            model="gpt-4o",
            messages=[UserMessage(blocks=[TextBlock(text="What is 2 + 2?")])],
            max_tokens=256,
        )

        response = await provider.call(request)
        print(response.message.blocks[0].text)  # "4"

asyncio.run(main())
```

This is useful for one-off calls, but most applications need something more:
conversation history, tools, persistence. That's where agents come in.

## A simple chatbot

Flowra ships `ChatAgent` — a pre-built agent for multi-turn conversations. It
manages conversation history automatically, so the LLM sees all previous messages
on every turn.

```python
import asyncio
from flowra.agent import AgentRuntime, InMemorySessionStorage
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.llm import SystemMessage, TextBlock
from flowra.llm.providers.openai import OpenAIProvider

async def main() -> None:
    async with OpenAIProvider(api_key="sk-...") as provider:
        config = ChatConfig(
            llm_config=LLMConfig(provider=provider, model="gpt-4o"),
            system=[SystemMessage(blocks=[TextBlock(text="You are a helpful assistant.")])],
        )

        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=InMemorySessionStorage(),
            services={
                ChatConfig: config,
            },
        )

        while True:
            user_input = input("You: ")
            if not user_input:
                break

            result = await runtime.run(agent=ChatAgent, spec=ChatSpec.text(user_input))

            if isinstance(result, ChatResult) and result.response:
                print(f"Assistant: {result.response}")

asyncio.run(main())
```

Key pieces:

- **`AgentRuntime`** — runs agents. You register agent classes and provide their
  configs via dependency injection (the `services={...}` dict).
- **`LLMConfig`** — describes *how to call the LLM*: the provider instance, model
  name, and request-level settings. Nested into `ChatConfig` so the agent can
  resolve it at runtime.
- **`InMemorySessionStorage`** — keeps agent state (conversation history) in memory
  between `runtime.run()` calls. Without storage, each call is independent — the
  agent won't remember previous turns.
- **`ChatAgent`** — pre-built multi-turn chat agent. Each `runtime.run()` call
  is one conversation turn.
- **`ChatSpec`** — input for ChatAgent (the user's messages).
- **`ChatResult`** — output with the assistant's text response.

## Adding tools

Tools let the LLM call your Python functions. Define a tool with the `@tool`
decorator, register it in a `ToolRegistry`, and pass the registry to the config:

```python
import asyncio
from dataclasses import dataclass
from flowra.agent import AgentRuntime
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.llm import SystemMessage, TextBlock
from flowra.llm.providers.openai import OpenAIProvider
from flowra.tools import ToolRegistry, tool

@dataclass
class WeatherParams:
    city: str

@tool("get_weather")
def get_weather(params: WeatherParams) -> str:
    """Get current weather for a city."""
    return f"It's sunny and 22C in {params.city}"

async def main() -> None:
    async with OpenAIProvider(api_key="sk-...") as provider:
        registry = ToolRegistry([get_weather])

        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(provider=provider, model="gpt-4o"),
            system=[SystemMessage(blocks=[TextBlock(text="You are a helpful assistant.")])],
        )

        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                ChatConfig: config,
            },
        )

        result = await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec.text("What's the weather in Paris?"),
        )

        if isinstance(result, ChatResult) and result.response:
            print(result.response)
            # "It's sunny and 22C in Paris"

asyncio.run(main())
```

How it works under the hood:

1. ChatAgent sends the user message + tool definitions to the LLM
2. The LLM responds with a tool call (`get_weather` with `{"city": "Paris"}`)
3. Flowra executes the tool, feeds the result back to the LLM
4. The LLM produces a final text response incorporating the tool result

The tool input schema is derived automatically from the `WeatherParams` dataclass.
The tool description is taken from the docstring (or you can pass it explicitly).

## Streaming

To see text as it arrives (instead of waiting for the full response), register a
handler for `TextDeltaEvent`:

```python
from flowra.lib.observability import TextDeltaEvent

runtime = AgentRuntime(
    agents={"chat": ChatAgent},
    services={
        ChatConfig: config,
    },
)
runtime.hooks.on(TextDeltaEvent, lambda e: print(e.data.text, end="", flush=True))
```

When a `TextDeltaEvent` handler is registered, agents automatically switch from
`provider.call()` to `provider.stream()`.

## Session persistence

In the chatbot example above, we used `InMemorySessionStorage` — it keeps
conversation history in memory, but loses it when the program exits. To persist
across restarts (or recover from crashes), swap in `FileSessionStorage`:

```python
from flowra.agent import AgentRuntime, FileSessionStorage

storage = FileSessionStorage(base_dir="./sessions", session_id="my-chat")

runtime = AgentRuntime(
    agents={"chat": ChatAgent},
    storage=storage,
    services={...},
)

# First run:
result = await runtime.run(agent=ChatAgent, spec=ChatSpec.text("Hi!"))

# After restart — resume if there's a pending execution (e.g. after a crash):
if await runtime.has_pending_execution():
    result = await runtime.resume()

# Or just run normally — ChatAgent reads history from storage automatically:
result = await runtime.run(agent=ChatAgent, spec=ChatSpec.text("What did I say?"))
```

## What's next

This guide covered the most common use case: a chatbot with tools and persistence.
Flowra can do much more:

- **[Architecture](architecture.md)** — package structure, dependency graph, data flow
- **[Working with LLMs](llm.md)** — providers, streaming, structured output,
  prompt caching, extended thinking
- **[Tools](tools.md)** — tool groups, MCP servers, service injection into tools
- **[Agents](agents.md)** — custom state machine agents with steps, control flow,
  parallel execution
- **[Patterns](patterns.md)** — multi-agent patterns: router, pipeline, fan-out,
  race, feedback loop
- **[Observability](observability.md)** — hooks, span tracking, MLflow and
  OpenTelemetry integrations

---

**Next:** [Architecture](architecture.md)
