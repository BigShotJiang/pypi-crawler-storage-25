# Prompt: Test Review and Completeness

You are reviewing the test suite for a Python package. Your goal is to assess the quality of existing tests and identify gaps in coverage.

## Context

You will be given:
- The full source code of every file in the package
- The test files for the package (from `tests/` directory)
- The package name

The test directory structure mirrors the package structure. E2E tests use `_e2e` suffix (e.g., `test_anthropic_e2e.py`).

## Part 1: Test quality review

For each test file, review every test function:

### Test naming

- Does the test name describe what it verifies? (e.g., `test_spawn_executes_children_in_parallel` — good; `test_spawn` — too vague; `test_old_behavior` — stale name)
- After refactors, test names become stale. Flag any test whose name doesn't match what it actually tests.

### Test meaningfulness

Flag tests that are trivial or meaningless:
- Tests that only verify an object can be constructed (unless construction has complex validation)
- Tests that check `isinstance(x, SomeClass)` without testing behavior
- Tests that duplicate other tests
- Tests that always pass regardless of code changes (tautologies)
- Commented-out tests

### Test structure

- **One concept per test:** each test should verify one behavior. If a test has many unrelated assertions — flag it for splitting.
- **Clear arrange/act/assert:** can you easily identify the setup, the action being tested, and what's being verified?
- **Tests verify outcomes, not implementation:** tests should check what the code does, not how it does it internally. Asserting on private attributes or implementation details makes tests brittle.

### Edge cases and error paths

- Does the test suite cover error conditions? (Invalid inputs, exceptions, edge cases)
- Are boundary values tested? (Empty collections, None, zero, max values)

## Part 2: Coverage analysis

Compare the package's public API against the test suite:

### Per-symbol coverage

For each public symbol in the package's `__all__`:
- Is there at least one test that exercises it?
- Are the key behaviors of that symbol tested?
- List untested symbols.

### Integration coverage

- Are there tests that exercise the package's public API as a consumer would use it? (Importing from `__init__.py`, realistic multi-step usage)
- Are there tests for interactions between modules within the package?

### E2E coverage (if applicable)

- If the package interacts with external services, are there E2E tests?
- Are E2E tests properly separated (with `_e2e` suffix)?

### Missing test scenarios

Based on reading the source code, list specific test scenarios that should exist but don't:
- Error handling paths that aren't tested
- Configuration combinations that aren't tested
- Edge cases at boundaries (empty inputs, None values, concurrent access)
- Behavioral contracts that aren't verified

## Output format

```
# Test Review: flowra.<package_name>

## Part 1: Test quality

### <test_file>.py

#### test_xxx (line N)
- **Name accuracy:** OK | STALE: <what it actually tests>
- **Meaningfulness:** OK | TRIVIAL: <why>
- **Structure:** OK | ISSUE: <description>
- **Verdict:** KEEP | FIX | DELETE

#### test_yyy (line M)
...

### <test_file>.py
...

## Part 2: Coverage analysis

### Public API coverage

| Symbol | Tested | Key behaviors covered |
|--------|--------|-----------------------|
| `Foo`  | YES    | construction, method_a, method_b |
| `Bar`  | NO     | — |
| `baz`  | PARTIAL| only happy path |

### Integration tests
<Assessment of integration test coverage, or "None found.">

### E2E tests
<Assessment, or "Not applicable." / "None found.">

### Missing test scenarios
1. <Specific scenario with expected behavior>
2. <Specific scenario with expected behavior>
...

## Summary
- Test files reviewed: N
- Individual tests reviewed: N
- Tests to fix: N (naming, structure, or meaningfulness issues)
- Tests to delete: N
- Public symbols tested: N / M
- Missing test scenarios: N
```

## Important

- Read the source code first to understand what each function/class is supposed to do, THEN check if tests verify that behavior.
- Be specific about missing scenarios — don't say "needs more tests", say "need a test that verifies X returns Y when given Z".
- Don't flag tests as "trivial" just because they're short. A short test that verifies a specific edge case is valuable.
- Don't review code style in tests unless it affects test quality (e.g., unclear assertion messages).
- Don't suggest "guard" tests that merely assert hardcoded values of constants or enum members (e.g., `assert StopReason.END_TURN == "end_turn"`). If someone renames a value, they'll update the test too — such tests catch nothing.
- Don't suggest tests that require accessing private members via name mangling (`obj._ClassName__method`). Tests must only use the public API. If behavior can't be tested through the public API, suggest a design refactoring instead.
