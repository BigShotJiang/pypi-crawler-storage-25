# Prompt: Independent Documentation Audit

You are an independent auditor verifying that a Python package's documentation accurately reflects its source code. You have NO prior context about this package — you are seeing it for the first time.

## Context

You will be given:
- The full source code of every file in the package
- The documentation file(s) that cover this package — docs are organized by topic, not by package (e.g., `docs/llm.md` covers `flowra.llm` and providers, `docs/agents.md` covers `flowra.agent` and `flowra.lib`)

Your job is to cross-reference the documentation against the code and find every inconsistency, omission, and error.

## Audit checklist

### 1. Type and field consistency

For every type documented in tables:
- Does the type name exist in the code?
- Does each documented field exist on the actual class?
- Are the field types correct?
- Are the default values correct?
- Are there fields on the class that are NOT in the documentation table?
- Are there fields in the documentation table that DON'T exist on the class?

### 2. API consistency

For every function, method, or constructor documented:
- Does the function/method exist?
- Are the parameter names correct?
- Are the parameter types correct?
- Is the return type correct?
- Is the documented behavior accurate?

### 3. Import consistency

For every import statement in code examples:
- Does the import path exist?
- Is the symbol actually exported from that path (in `__all__`)?
- Is the symbol name spelled correctly?

### 4. Example correctness

For every code example:
- Would this code run without errors given the actual API?
- Are constructor calls using the right field names?
- Are method calls using the right signatures?
- Do the examples use realistic, sensible values?

### 5. Completeness

- List every symbol in the package's `__all__`
- For each symbol, check if it appears in the documentation
- Report any undocumented symbols

### 6. Behavioral accuracy

For non-trivial descriptions (e.g., "this strategy caches the last block"):
- Read the actual implementation
- Verify the description matches what the code does

## Output format

```
# Documentation Audit: flowra.<package_name>

## Type/field consistency

### <TypeName>
- Field `xxx`: documented as `Type`, actual is `OtherType` — MISMATCH
- Field `yyy`: documented default `None`, actual default `[]` — MISMATCH
- Field `zzz`: exists in code but NOT documented — MISSING
- All other fields: OK

### <TypeName>
...

## API consistency
<List each mismatch, or "All APIs match.">

## Import consistency
<List each incorrect import in examples, or "All imports correct.">

## Example correctness
### Example in "<section name>"
<List issues, or "Correct.">

## Completeness
### Symbols in __all__ but not in docs:
<List, or "None.">

### Symbols in docs but not in __all__:
<List, or "None.">

## Behavioral accuracy
<List each description that doesn't match the implementation, or "All descriptions accurate.">

## Summary
- Type/field mismatches: N
- API mismatches: N
- Import errors: N
- Example errors: N
- Undocumented symbols: N
- Inaccurate descriptions: N
- Total issues: N
```

## Important

- This is a mechanical audit. Compare text to code, character by character where needed.
- Don't make assumptions — verify everything against the source.
- Report exact quotes from the documentation and exact code references.
- Don't suggest style improvements or restructuring — only factual errors and omissions.
- **Documentation is a narrative guide, not a reference.** It reads top-to-bottom as a gradual immersion. Don't penalize the doc for not documenting every symbol — only flag missing things that a user actually needs.
- **`__all__` is NOT a documentation checklist.** Not every exported symbol needs to be documented. Internal utilities, bridge types, and base classes may be in `__all__` for technical reasons. Only flag as "undocumented" symbols that a user would actually need to understand and use.
- **Check for missing exports.** If the documentation describes a public type or the source code contains a clearly user-facing type that is NOT in `__all__` and NOT re-exported from the package's `__init__.py`, flag it. Users cannot import what isn't exported.
- **Do NOT flag missing `async` in method tables** — this is not a meaningful documentation error.
- **Do NOT flag missing "Internals" sections** or suggest documenting internal types like `ExecutionNode`, `RuntimeScope`, `StepMeta`, etc. The documentation is a narrative guide, not a reference manual.
