# Agents

Flowra agents are state machines: you define steps, and the engine handles
execution, persistence, and crash recovery. This guide covers building custom
agents beyond the pre-built `ChatAgent` and `TurnAgent`.

If you just need a chatbot, see [Getting Started](getting-started.md). This guide
is for when you need custom control flow, persistent state, parallel execution,
or multi-agent coordination.

## Your first agent

An agent is a class that inherits from `Agent[Spec, Result]` with one or more
`@step` methods:

```python
from dataclasses import dataclass
from flowra.agent import Agent, AgentRuntime, step

@dataclass
class GreetSpec:
    name: str

@dataclass
class GreetResult:
    message: str

class GreetAgent(Agent[GreetSpec, GreetResult]):
    @step(entry=True)
    async def greet(self, spec: GreetSpec) -> GreetResult:
        return GreetResult(message=f"Hello, {spec.name}!")

# Run it:
runtime = AgentRuntime(agents={"greet": GreetAgent})
result = await runtime.run(agent=GreetAgent, spec=GreetSpec(name="World"))
print(result.message)  # "Hello, World!"
```

Key rules:

- **`Agent[Spec, Result]`** — typed with input spec and output result. Both
  can be a dataclass, a primitive (`str`, `int`, `float`, `bool`, `bytes`,
  `UUID`, `datetime`, `date`, `time`, `Decimal`), or a container (`list`,
  `dict`). Generic forms like `list[int]` or `dict[str, Foo]` are accepted —
  the container origin is used for runtime dispatch, the type parameters
  inform your own code.
- **`@step(entry=True)`** — exactly one entry step per agent
- **Step parameters and return types** follow the same rule: dataclass,
  primitive, or bare container. The engine matches parameters by `isinstance`
  and serializes returns through the checkpoint layer (primitives and
  containers are stored natively; dataclasses use the type registry).
- Use `None` if the agent doesn't need input (`Agent[None, Result]`) or doesn't
  return a value (`Agent[Spec, None]`)

#### Child binding: `agent_arg.CHILD` vs `agent_arg.CHILDREN`

Two markers split child-result binding cleanly by signature, not by type:

- **`agent_arg.CHILD`** — strictly single. The parameter binds to exactly
  one child result whose `isinstance` matches the annotated type. Works for
  any type, including `list[X]` (means "one child whose result IS a list").
- **`agent_arg.CHILDREN`** — strictly plural. Requires a `list[X]`
  annotation. Collects every child whose result `isinstance` matches `X`
  into a `list[X]`. If no child matches, the parameter binds to `[]`.

Both markers accept an optional tag: `agent_arg.CHILD("name")` /
`agent_arg.CHILDREN("group")` — only children spawned with that tag are
considered.

**No marker on `list[X]`** — the engine tries both interpretations
(`single list-child` and `plural X-children`) and picks the one that matched:

- Only one interpretation has candidates → that one wins.
- Both have candidates (a `list` child **and** `X` children) → the engine
  raises `RuntimeError("Ambiguous binding...")` at bind time.
- Neither matches → parameter defaults to `[]` (since the declared type is
  `list[...]`).

Use explicit `CHILDREN` (or `CHILD`) whenever both shapes might coexist.

## Multi-step agents

Steps transition to other steps using control flow actions. This is where agents
become state machines:

```python
from flowra.agent import Agent, GotoStep, step

@dataclass
class ValidationResult:
    is_valid: bool
    error: str | None = None

@dataclass
class ProcessSpec:
    data: str

@dataclass
class ProcessResult:
    status: str

class ProcessAgent(Agent[ProcessSpec, ProcessResult]):
    @step(entry=True)
    async def validate(self, spec: ProcessSpec) -> GotoStep | ProcessResult:
        if not spec.data:
            return ProcessResult(status="error: empty data")
        return GotoStep(step=self.process, spec=ValidationResult(is_valid=True))

    @step
    async def process(self, validation: ValidationResult) -> ProcessResult:
        return ProcessResult(status="done")
```

### Control flow actions

| Action                                   | Behavior                                     |
|------------------------------------------|----------------------------------------------|
| `GotoStep(step=self.next, spec=data)`    | Jump to another step (tail call — no return) |
| `GotoAgent(agent=OtherAgent, spec=data)` | Jump to another agent (tail call)            |
| Return a result (dataclass or primitive) | Agent completes with this value              |

Steps receive their input via typed parameters — the engine matches by type.

## Agent state

Multi-step agents often need to remember data — between steps within a single
run, across multiple `runtime.run()` calls, or shared with other agents.
Flowra provides typed slots organized into scopes with different lifetimes:

```python
class MyAgent(Agent[Spec, Result]):
    def __init__(self, store: AgentStore) -> None:
        # Ephemeral — per-run scratch state (fresh each runtime.run() call)
        self.temp = store.ephemeral.slot(Scalar[str], "temp")

        # Persistent — survives across runs (key controlled by parent)
        self.count = store.persistent.slot(Scalar[int], "count")

        # Named scope — session-wide, shared across agents
        self.log = store["session"].slot(AppendOnlyList[str], "log")
```

| Scope              | Lifetime                                   | Key controlled by                                                  |
|--------------------|--------------------------------------------|--------------------------------------------------------------------|
| `store.ephemeral`  | One `run()` call (survives crash recovery) | Engine (node ID)                                                   |
| `store.persistent` | Across `run()` calls                       | Parent via `state=` param, default = agent's full name in registry |
| `store["name"]`    | Across `run()` calls                       | Agent itself (the name)                                            |

Two slot types:

- **`Scalar[T]`** — single mutable value. `.get(default)` / `.set(value)`
- **`AppendOnlyList[T]`** — append-only list. `.append(item)` / `.get_all() -> list[T]`

Both track changes incrementally — only dirty data is persisted on each step
boundary.

**Note:** State only persists when `AgentRuntime` has a `storage` —
at minimum `InMemorySessionStorage()` for in-process use, or
`FileSessionStorage` for crash recovery. Without storage, state is
discarded after each `run()` call.

### Controlling persistent scope from the parent

When spawning a child agent, the parent controls what `store.persistent`
resolves to via the `state` parameter:

```python
# Default — persistent key = agent's full name in registry (e.g., "parent/calc")
CallAgent(agent=CalcAgent, spec=spec)

# Explicit key
CallAgent(agent=CalcAgent, spec=spec, state="user-123-calc")

# Ephemeral — no persistence for this child
CallAgent(agent=CalcAgent, spec=spec, state=persistent.EPHEMERAL)

# Named scope — redirect persistent to a shared named scope
CallAgent(agent=CalcAgent, spec=spec, state=persistent.NAMED("session"))
```

The same `state` parameter works on `GotoAgent` and `runtime.run()`.

### Shared persistent scope

The exclusive persistent key check is an inter-agent contract: the agent
declares whether callers may spawn multiple concurrent instances sharing
the same persistent scope. By default this is not allowed — spawning two
instances of the same agent concurrently causes an error (duplicate persistent
key). To allow it, the agent opts in with `@shared_persistent`:

```python
from flowra.agent import shared_persistent

@shared_persistent
class WorkerAgent(Agent[Spec, Result]):
    ...

# OK — both workers share persistent scope
CallAgent(agent=WorkerAgent)
CallAgent(agent=WorkerAgent)
```

This only applies to `CallAgent` (inter-agent boundaries). Within an agent,
`CallStep` always shares the parent's scopes — no decorator needed, the agent
controls its own internal state.

### Named scopes for cross-agent state

Named scopes are session-wide — any agent can access the same scope by name:

```python
class OrchestratorAgent(Agent[Spec, Result]):
    def __init__(self, store: AgentStore, services: ServiceLocator) -> None:
        self.log = store["session"].slot(AppendOnlyList[str], "log")
        services.provide(self.log)  # pass to children via DI

class ChildAgent(Agent[Spec, Result]):
    def __init__(self, store: AgentStore) -> None:
        # Same scope, same slot — shared with parent
        self.log = store["session"].slot(AppendOnlyList[str], "log")
```

### Crash recovery

With `FileSessionStorage`, state is persisted to disk after every step. If the
process crashes, you can resume from where it left off:

```python
from flowra.agent import AgentRuntime, FileSessionStorage

storage = FileSessionStorage(base_dir="./sessions", session_id="my-session")
runtime = AgentRuntime(agents={"counter": CounterAgent}, storage=storage)

# First run — crashes mid-execution
result = await runtime.run(agent=CounterAgent, spec=CounterSpec(target=10))

# After restart — resume from last completed step
if await runtime.has_pending_execution():
    result = await runtime.resume()
```

### Cloning in-memory storage

`InMemorySessionStorage` supports snapshotting — take a deep copy of all stored
data and use it to create a new, independent storage:

```python
from flowra.agent import InMemorySessionStorage

# After some agent runs have populated the storage...
snapshot = storage.snapshot()          # deep-copy all data out
cloned = InMemorySessionStorage(snapshot)  # deep-copy into new storage
```

This is useful for forking a session (e.g. branching a conversation) or
inspecting storage contents. The snapshot is a frozen dataclass with `execution`
and `node_states` fields.

## Dependency injection

Agent constructors receive services by type matching. Some services are always
available:

| Service            | Purpose                                        |
|--------------------|------------------------------------------------|
| `AgentStore`       | Access ephemeral, persistent, and named scopes |
| `InterruptToken`   | Check for cooperative interruption             |
| `InterruptControl` | Interrupt self or children                     |
| `ServiceLocator`   | Provide services to child agents               |

Other services come from `AgentRuntime(services={...})`:

```python
class MyAgent(Agent[Spec, Result]):
    def __init__(self, db: DatabaseClient, config: MyConfig) -> None:
        self.db = db
        self.config = config

runtime = AgentRuntime(
    agents={"my": MyAgent},
    services={DatabaseClient: db, MyConfig: config},
)
```

A parameter typed `T | None` is optional — receives `None` if the service isn't
registered.

### Providing services to children

Use `ServiceLocator` to register services that child agents (and tools) can
access:

```python
class ParentAgent(Agent[Spec, Result]):
    def __init__(self, services: ServiceLocator) -> None:
        services.provide(MyService())
        # Now any child agent or tool can receive MyService via DI
```

## Parallel execution with Spawn

`Spawn` launches child agents (or steps) in parallel and collects results:

```python
from flowra.agent import Agent, CallAgent, Spawn, WhenAll, step

class FanOutAgent(Agent[SearchQuery, MergedResults]):
    @step(entry=True)
    async def search(self, spec: SearchQuery) -> Spawn:
        return Spawn(
            WhenAll(
                CallAgent(agent=WebSearch, spec=SearchSpec(query=spec.query, source="web")),
                CallAgent(agent=DocSearch, spec=SearchSpec(query=spec.query, source="docs")),
            ),
            then=self.merge,
        )

    @step
    async def merge(self, results: list[SearchResult]) -> MergedResults:
        all_items = [item for r in results for item in r.items]
        return MergedResults(all_items=all_items)
```

### Completion strategies

| Strategy                          | Behavior                                      |
|-----------------------------------|-----------------------------------------------|
| `WhenAll(child1, child2, ...)`    | Wait for all children, return list of results |
| `WhenAny(child1, child2, ...)`    | First to finish wins, cancel the rest         |
| `WhenN(child1, child2, ..., n=2)` | Wait for N, cancel the rest                   |

### Tags and typed collection

When children return different types, use tags to identify them:

```python
from typing import Annotated
from flowra.agent import agent_arg

@step(entry=True)
async def analyze(self, spec: AnalysisSpec) -> Spawn:
    return Spawn(
        CallAgent(agent=SentimentAgent, spec=spec, tag="sentiment"),
        CallAgent(agent=SummaryAgent, spec=spec, tag="summary"),
        then=self.combine,
    )

@step
async def combine(
    self,
    sentiment: Annotated[SentimentResult, agent_arg.CHILD("sentiment")],
    summary: Annotated[SummaryResult, agent_arg.CHILD("summary")],
) -> CombinedResult:
    return CombinedResult(sentiment=sentiment, summary=summary)
```

### Timeouts

Any parallel execution can be wrapped with a timeout:

```python
from flowra.agent import TimeoutExpired, WhenAny, timeout

@step(entry=True)
async def start(self, spec: TaskSpec) -> Spawn:
    return Spawn(
        WhenAny(
            CallAgent(agent=SlowAgent, spec=spec),
            timeout(seconds=30),
        ),
        then=self.handle,
    )

@step
async def handle(
    self,
    result: TaskResult | None,
    expired: TimeoutExpired | None,
) -> FinalResult:
    if expired:
        return FinalResult(status="timeout")
    assert result is not None
    return FinalResult(status="done", data=result)
```

## Interrupts

Flowra uses cooperative interruption — agents check for interrupt signals and
stop gracefully.

### Checking for interrupts

Accept `InterruptToken` in your constructor. Two approaches:

**Polling with `check()`** — call in loops to detect interruption:

```python
class WorkerAgent(Agent[WorkSpec, WorkResult]):
    def __init__(self, interrupt: InterruptToken) -> None:
        self.interrupt = interrupt

    @step(entry=True)
    async def work(self, spec: WorkSpec) -> WorkResult:
        for item in spec.items:
            self.interrupt.check()  # raises InterruptedError if interrupted
            await process(item)
        return WorkResult(done=True)
```

**Async wait with `wait()`** — block until interrupted, useful for agents that
need to sleep or wait for an external signal:

```python
import asyncio

class PollingAgent(Agent[PollSpec, PollResult]):
    def __init__(self, interrupt: InterruptToken) -> None:
        self.interrupt = interrupt

    @step(entry=True)
    async def poll(self, spec: PollSpec) -> PollResult:
        while True:
            result = await check_status(spec.job_id)
            if result.done:
                return PollResult(data=result.data)
            # Sleep 5s, but wake up immediately if interrupted:
            try:
                await asyncio.wait_for(self.interrupt.wait(), timeout=5.0)
                self.interrupt.check()  # raises InterruptedError
            except TimeoutError:
                pass  # timeout expired — not interrupted, loop again
```

**Wrapping async iterators with `with_interrupt()`** — for streaming:

```python
from flowra.agent import with_interrupt

async for event in with_interrupt(provider.stream(request), self.interrupt):
    process(event)
# Raises InterruptedError if token fires mid-stream; properly closes the iterator.
```

### Interrupting from outside

```python
runtime = AgentRuntime(agents={"worker": WorkerAgent})

# In another coroutine or signal handler:
runtime.interrupt()  # all agents will see the interrupt on next .check()
```

### Handling interrupted children

When a child is interrupted (e.g. by `WhenAny` cancellation), the parent can
handle it by declaring `Interrupted` in the result type:

```python
from flowra.agent import Interrupted

@step
async def collect(
    self,
    result: Annotated[WorkResult | Interrupted, agent_arg.CHILD("worker")],
) -> FinalResult:
    if isinstance(result, Interrupted):
        return FinalResult(status="worker was interrupted")
    return FinalResult(status="done", data=result)
```

### InterruptControl

Agents can interrupt their own children programmatically:

```python
class EscalationAgent(Agent[Spec, Result]):
    def __init__(self, interrupt_control: InterruptControl) -> None:
        self.interrupt_control = interrupt_control

    # When a tool or hook detects the need to escalate:
    def escalate(self) -> None:
        self.interrupt_control.interrupt_children()  # interrupt all child agents
```

## Events and hooks

Agents communicate with the outside world through events. Register handlers via
`runtime.hooks`:

```python
runtime = AgentRuntime(
    agents={"my": MyAgent},
    services={...},
)
runtime.hooks.on(MyCustomEvent, lambda event: print(event.data))
```

### Filtering subscriptions: `scope` and `during`

Subscription matching has three layers:

1. **Baseline (always).** When you subscribe from an agent's `__init__`,
   the subscription only fires for events whose call stack includes your
   agent as a *strict* ancestor. You see events from anything you called
   — directly or transitively — but never your own emits, and never
   events from siblings or ancestors. Global subscriptions via
   `runtime.hooks.on(...)` skip this — they fire on everything.
2. **`scope` (optional).** Additional filter on the **emitter's registry
   path**. Strings follow the [path convention](#path-convention-for-agent-refs);
   a type is resolved through the registry (starting from the
   subscriber's path, walking up) to its registered path. Matches when
   `emitter.path` is at or under the resolved path.
3. **`during` (optional).** Additional filter on the **call stack**.
   Looks for a frame *below* the subscriber that matches: a type checks
   `frame.agent.source_type`; a string checks `frame.agent.path`.

All layers are ANDed. Self-emits can never reach the subscriber — the
baseline always excludes them.

**`scope=Type` resolution.** A type is resolved via
`registry.name_for_type(Type, context=subscriber_path)` — the same
algorithm as `CallAgent(agent=Type)`. The resolver walks the registry
**upward** from the subscriber's path, stopping at the first container
that registers the type. That means:

- If the type is registered along the subscriber's ancestor chain (or at
  root) — it resolves to the nearest one.
- If the type is registered only *below* the subscriber or in a sibling
  subtree — it's invisible from the subscriber's context.
- If the type is unregistered — `hooks.on(...)` raises `KeyError` right
  at registration time.

When you need a type that isn't visible from your position, use
`scope="/absolute/path"` or fall back to `during=Type` (which walks the
call stack directly and doesn't require registry visibility).

```python
# Everything launched by me, unfiltered
hooks.on(Evt, h)

# Emitter must be registered under /app/worker
hooks.on(Evt, h, scope="/app/worker")

# Somewhere below me in the call stack there must be a TurnAgent
hooks.on(Evt, h, during=TurnAgent)

# Both: emitter under /app/worker AND TurnAgent is on the call stack
hooks.on(Evt, h, scope="/app/worker", during=TurnAgent)
```

#### Walkthrough — what fires and when

Assume this registry layout:

```
/app
  └── /app/chat           (ChatAgent)
        ├── /app/chat/turn    (TurnAgent)
        └── /app/chat/helper  (HelperAgent)
  └── /app/other          (OtherAgent)
```

And a run where `/app` calls `/app/chat`, which calls `/app/chat/turn`,
which emits `MyEvent`. The event's call stack is
`[app, app/chat, app/chat/turn]` (top to bottom; the emitter is last).

The table below shows what fires for each subscription, with the
subscriber's path in the first column:

| Subscriber     | Subscription                            | Fires? | Why                                                              |
|----------------|-----------------------------------------|--------|------------------------------------------------------------------|
| `/app`         | `hooks.on(MyEvent, h)`                  | ✓      | `/app` is a strict ancestor of `turn` on the stack               |
| `/app`         | `hooks.on(MyEvent, h, scope=ChatAgent)` | ✓      | scope resolves to `/app/chat`; emitter `/app/chat/turn` is under |
| `/app`         | `hooks.on(MyEvent, h, scope="./chat")`  | ✓      | same as above via relative path                                  |
| `/app`         | `hooks.on(MyEvent, h, scope="/app/other")` | ✗   | emitter not under `/app/other`                                   |
| `/app`         | `hooks.on(MyEvent, h, during=TurnAgent)`| ✓      | `turn` is below subscriber on the stack                          |
| `/app`         | `hooks.on(MyEvent, h, during=HelperAgent)` | ✗   | no `HelperAgent` frame on this stack                             |
| `/app/chat`    | `hooks.on(MyEvent, h)`                  | ✓      | `/app/chat` is a strict ancestor on the stack                    |
| `/app/chat`    | `hooks.on(MyEvent, h, scope=".")`       | ✓      | scope='.' = `/app/chat`; emitter `/app/chat/turn` is under       |
| `/app/chat`    | `hooks.on(MyEvent, h, scope="../other")`| ✗      | emitter not under `/app/other`                                   |
| `/app/chat/turn` | `hooks.on(MyEvent, h)`                | ✗      | subscriber IS the emitter — baseline requires strict ancestor    |
| `/app/chat/helper` | `hooks.on(MyEvent, h)`              | ✗      | subscriber is a sibling, not an ancestor on this stack           |
| `/app/other`   | `hooks.on(MyEvent, h)`                  | ✗      | subscriber not on the stack at all                               |
| *(global)*     | `runtime.hooks.on(MyEvent, h)`          | ✓      | global — baseline skipped                                        |
| *(global)*     | `runtime.hooks.on(MyEvent, h, scope=ChatAgent)` | ✓ | emitter under `/app/chat`                                       |
| *(global)*     | `runtime.hooks.on(MyEvent, h, during=HelperAgent)` | ✗ | no HelperAgent on stack                                         |

Now a subtler case — the **ancestor-is-on-stack** trap we avoid. Stack:
`[app, app/chat, app/chat/turn, app/chat/turn/tool]`. Subscriber is at
`/app/chat/turn`. Whichever subscription they use with
`during=ChatAgent`:

| Subscriber        | Subscription                              | Fires? | Why                                                                |
|-------------------|------------------------------------------|--------|--------------------------------------------------------------------|
| `/app/chat/turn`  | `hooks.on(E, h, during=ChatAgent)`       | ✗      | `ChatAgent` is *above* subscriber on the stack — stack walk below subscriber finds no match |
| `/app`            | `hooks.on(E, h, during=ChatAgent)`       | ✓      | `ChatAgent` is below `/app` on the stack                            |

Finally, self + composition:

| Subscriber  | Subscription                                          | Fires? | Why                                                       |
|-------------|-------------------------------------------------------|--------|-----------------------------------------------------------|
| `/app/chat` | `hooks.on(E, h, scope=".")` when `/app/chat` emits `E` | ✗    | self-emit blocked by baseline (no strict ancestor)        |
| `/app/chat` | `hooks.on(E, h, scope="./turn", during=TurnAgent)` when `turn` emits | ✓ | both filters match        |
| `/app/chat` | `hooks.on(E, h, scope="./helper", during=TurnAgent)` when `turn` emits | ✗ | scope rejects — emitter is under `./turn`, not `./helper` |

### Path convention for agent refs

Flowra uses filesystem-style paths everywhere an agent is referenced by
string — `CallAgent(agent=...)`, `GotoAgent(agent=...)`, `scope=`, `during=`,
`runtime.run(agent=...)`:

| Form        | Meaning                                                       |
|-------------|---------------------------------------------------------------|
| `/foo/bar`  | Absolute path from registry root                              |
| `foo/bar`   | Relative, down from the calling agent's path (top-level: abs) |
| `./foo`     | Relative, down (explicit)                                     |
| `../foo`    | Parent of caller + `foo`                                      |
| `.`         | The caller itself (same as its full path)                     |
| `..`        | Parent of the caller                                          |

`runtime.run(agent="chat")` without a caller context resolves `chat` as
absolute (it's a top-level entry). Inside an agent, `CallAgent(agent="helper")`
is relative — use `/helper` if you really want the root-level `helper`.

### Pre-built events

`ChatAgent` and `TurnAgent` emit lifecycle events you can hook into.

Lifecycle events (from `flowra.lib.turn`):

| Event                    | When                                     | Mutable fields                                |
|--------------------------|------------------------------------------|-----------------------------------------------|
| `StartTurnEvent`         | Start of turn (before first iter)        | `messages`                                    |
| `MessageAcceptedEvent`   | After message accepted                   | —                                             |
| `StartIterationEvent`    | Each tool loop iteration                 | `additional_messages`                         |
| `TextReasoningEvent`     | Each text block in LLM response          | —                                             |
| `ThinkingEvent`          | Each thinking block in LLM response      | —                                             |
| `ServerToolCallEvent`    | Server-side tool call (e.g. tool search) | —                                             |
| `ServerToolResultEvent`  | Server-side tool result                  | —                                             |
| `BeforeToolCallEvent`    | Before tool execution                    | `tool_use`, `tool_definition`                 |
| `AfterToolCallEvent`     | After tool execution                     | `result`, `error_kind`, `additional_blocks`, `additional_messages` |
| `ResultMessageEvent`     | LLM finished (END_TURN)                  | `continue_messages`                           |

Streaming events (from `flowra.lib.observability`):

| Event                | When                         |
|----------------------|------------------------------|
| `TextDeltaEvent`     | Each streamed text chunk     |
| `ThinkingDeltaEvent` | Each streamed thinking chunk |

### Custom events

Define your own event types and emit them from agents:

```python
from dataclasses import dataclass
from flowra.agent import Hooks

@dataclass
class ProgressEvent:
    percent: int

class MyAgent(Agent[Spec, Result]):
    def __init__(self, hooks: Hooks) -> None:
        self.hooks = hooks

    @step(entry=True)
    async def work(self, spec: Spec) -> Result:
        await self.hooks.emit(ProgressEvent(percent=50))
        ...
```

### ExecutionContext

Every event carries an `ExecutionContext` — the path from the root agent to the
agent that emitted the event. Use it to identify which agent or spec is active:

```python
def on_delta(event: Event[TextDeltaEvent]) -> None:
    spec = event.context.find_spec(ResearchSpec)
    if spec:
        print(f"[{spec.model}] {event.data.text}")
```

## Pre-built agents

Flowra ships agents for the most common patterns:

### ChatAgent

Multi-turn chat with persistent conversation history. Each `runtime.run()` call
is one turn — the agent delegates to `TurnAgent` internally.

Messages marked `transient=True` are automatically stripped from session history
(see [The `transient` hint](llm.md#the-transient-hint)).

```python
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec

config = ChatConfig(
    llm_config=LLMConfig(provider=provider, model="gpt-4o"),
    system=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
    max_llm_calls=10,      # per turn
)
```

By default, history is stored in `store.persistent` under key `"history"`.
Use the `history` parameter to control where history lives:

```python
from flowra.agent import AppendOnlyList
from flowra.llm import AssistantMessage, UserMessage

# Named scope — share history across agents
config = ChatConfig(
    ...,
    history=lambda store: store["shared"].slot(
        AppendOnlyList[UserMessage | AssistantMessage], "history"
    ),
)

# Ephemeral — history resets each run (no persistence)
config = ChatConfig(
    ...,
    history=lambda store: store.ephemeral.slot(
        AppendOnlyList[UserMessage | AssistantMessage], "history"
    ),
)

# Custom slot key
config = ChatConfig(
    ...,
    history=lambda store: store.persistent.slot(
        AppendOnlyList[UserMessage | AssistantMessage], "conversation"
    ),
)
```

### TurnAgent

Single-turn LLM tool loop: send messages, execute tool calls, feed results back,
repeat until done. `ChatAgent` uses this internally.

```python
from flowra.lib.turn import TurnAgent, TurnConfig, TurnResult, TurnSpec

config = TurnConfig(
    llm_config=LLMConfig(provider=provider, model="gpt-4o"),
    system=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
    history=[],            # conversation history (managed externally)
    max_llm_calls=5,
)
```

### LLMCallAgent

Single LLM call — no tool loop, no history. Configured via `LLMCallConfig`,
supports tools and JSON schema:

```python
from flowra.lib import LLMCallAgent, LLMConfig
from flowra.lib.llm_call import LLMCallConfig, LLMCallResult, LLMCallSpec

runtime = AgentRuntime(
    agents={"llm": LLMCallAgent},
    services={
        LLMCallConfig: LLMCallConfig(
            llm_config=LLMConfig(provider=provider, model="gpt-4o"),
            system=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
            tools=registry,  # optional — pass tools for single-shot tool use
        ),
    },
)

result = await runtime.run(
    agent=LLMCallAgent,
    spec=LLMCallSpec(
        messages=[UserMessage(blocks=[TextBlock(text="What is 2+2?")])],
    ),
)
# result.message: AssistantMessage | None (None on error)
# result.usage: Usage | None
# result.error: str | None (error message if LLM call failed)
# result.elapsed: float (seconds)
```

---

**Prev:** [Tools](tools.md) | **Next:** [Patterns](patterns.md)
