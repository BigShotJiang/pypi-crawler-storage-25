# Working with LLMs

Flowra provides a provider-agnostic LLM interface. This guide covers provider
setup, streaming, structured output, extended thinking, prompt caching, and
tool search.

For the basics (making a call, using ChatAgent), see
[Getting Started](getting-started.md).

## Providers

Flowra ships four providers. Each lives in its own module to avoid pulling in
unnecessary dependencies.

### AnthropicVertexProvider (Claude via Vertex AI)

```bash
pip install flowra[anthropic]
```

```python
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider

# From credentials:
async with AnthropicVertexProvider(
    project="my-gcp-project",
    location="us-east5",
    credentials="<base64-encoded service account JSON>",
) as provider:
    ...

# Or with a pre-configured client:
from anthropic import AsyncAnthropicVertex
async with AnthropicVertexProvider(client=my_client) as provider:
    ...
```

### AzureOpenAIProvider (OpenAI models via Azure)

```bash
pip install flowra[openai]
```

```python
from flowra.llm.providers.azure_openai import AzureOpenAIProvider

async with AzureOpenAIProvider(
    azure_endpoint="https://my-resource.openai.azure.com",
    api_key="...",
    api_version="2025-03-01-preview",
) as provider:
    ...

# Or with a pre-configured client:
from openai.lib.azure import AsyncAzureOpenAI
async with AzureOpenAIProvider(client=my_client) as provider:
    ...
```

### AnthropicFoundryProvider (Claude via Azure AI Foundry)

```bash
pip install flowra[anthropic]
```

```python
from flowra.llm.providers.anthropic_foundry import AnthropicFoundryProvider

async with AnthropicFoundryProvider(
    resource="my-azure-resource",
    api_key="...",
) as provider:
    ...

# Or with a pre-configured client:
from anthropic.lib.foundry import AsyncAnthropicFoundry
async with AnthropicFoundryProvider(client=my_client) as provider:
    ...
```

### OpenAIProvider (OpenAI and compatible APIs)

```bash
pip install flowra[openai]
```

```python
from flowra.llm.providers.openai import OpenAIProvider

async with OpenAIProvider(api_key="sk-...") as provider:
    ...

# Custom base URL (e.g. Inception AI, local LLM servers):
async with OpenAIProvider(
    api_key="sk-...",
    base_url="https://api.inceptionlabs.ai/v1",
) as provider:
    ...
```

### OpenAIResponsesProvider (OpenAI Responses API)

```bash
pip install flowra[openai]
```

```python
from flowra.llm.providers.openai_responses import OpenAIResponsesProvider

async with OpenAIResponsesProvider(api_key="sk-...") as provider:
    ...
```

Uses the OpenAI Responses API instead of Chat Completions. Supports all
Responses API features including tool search with deferred tool loading.
Use this provider when you need tool search or want the Responses API
benefits (better caching, improved performance on reasoning models).

### GoogleVertexProvider (Gemini via Vertex AI)

```bash
pip install flowra[google]
```

```python
from flowra.llm.providers.google_vertex import GoogleVertexProvider

async with GoogleVertexProvider(
    project="my-gcp-project",
    location="us-east5",
    credentials="<base64-encoded service account JSON>",
) as provider:
    ...
```

## Making calls

All providers implement the same interface:

```python
from flowra.llm import LLMRequest, TextBlock, UserMessage

request = LLMRequest(
    model="claude-sonnet-4-5@20250929",
    messages=[UserMessage(blocks=[TextBlock(text="Hello!")])],
    max_tokens=256,
)

response = await provider.call(request)
print(response.message.blocks[0].text)
print(response.usage.input_tokens, response.usage.output_tokens)
print(response.usage.cost_usd)  # estimated cost
```

## Streaming

Stream text token by token. `ContentComplete` at the end carries the full
response:

```python
from flowra.llm import TextDelta, ThinkingDelta, ContentComplete

async for event in provider.stream(request):
    match event:
        case TextDelta(text=text):
            print(text, end="", flush=True)
        case ThinkingDelta(text=text):
            print(f"[thinking] {text}", end="")
        case ContentComplete(response=response):
            print()
            # response.usage, response.stop_reason, etc.
```

When using `ChatAgent` or `TurnAgent`, you don't call `stream()` directly —
register a `TextDeltaEvent` handler and the agent switches to streaming
automatically (see [Getting Started — Streaming](getting-started.md#streaming)).

## Structured output (JSON schema)

Force the LLM to return JSON matching a schema:

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Three European capitals")])],
        json_schema={
            "type": "object",
            "properties": {"cities": {"type": "array", "items": {"type": "string"}}},
            "required": ["cities"],
        },
        max_tokens=256,
    )
)
```

How each provider handles it:

- **Anthropic** — prompt injection + validation + retries (up to `max_schema_retries`).
  Returns `StopReason.SCHEMA_VALIDATION_FAILED` if all retries fail.
- **OpenAI (Chat Completions)** — native `response_format` with strict mode.
- **OpenAI (Responses API)** — native `text.format` with strict mode.
- **Google** — native `response_schema` with JSON mime type.

## Extended thinking

Enable the model's reasoning/thinking mode for complex tasks.

### Anthropic (Claude)

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Solve step by step...")])],
        max_tokens=8192,
        extra=build_extra(AnthropicRequestExtra(thinking_budget_tokens=4000)),
    )
)

for block in response.message.blocks:
    if isinstance(block, ThinkingBlock):
        print(f"[thinking] {block.text}")
    elif isinstance(block, TextBlock):
        print(block.text)
```

### Google (Gemini)

```python
from flowra.llm import build_extra
from flowra.llm.providers.google_vertex import GoogleRequestExtra

# Gemini 3 — thinking level
extra=build_extra(GoogleRequestExtra(thinking_level="medium"))

# Gemini 2.5 — thinking budget
extra=build_extra(GoogleRequestExtra(thinking_budget=4096))
```

When using `ChatAgent`/`TurnAgent`, pass `extra` through `LLMConfig`:

```python
from flowra.lib import LLMConfig
from flowra.llm import build_extra
from flowra.llm.providers.anthropic_vertex import AnthropicRequestExtra

config = LLMConfig(
    provider=provider,
    model="claude-sonnet-4-5@20250929",
    max_tokens=8192,
    extra=build_extra(AnthropicRequestExtra(thinking_budget_tokens=4000)),
)
```

## Request extensions

`LLMConfig.request_extensions` is a sequence of callables that mutate the
`LLMRequest` just before it is dispatched to the provider. Each extension has
the signature `(LLMRequest) -> None`. This is the mechanism for prompt
caching, tool search, and other provider-specific request transforms.

```python
from flowra.lib import LLMConfig
from flowra.llm.ext.anthropic import anthropic_cache_all

config = LLMConfig(
    provider=provider,
    model="claude-sonnet-4-5@20250929",
    request_extensions=(anthropic_cache_all,),
)
```

Extensions are scoped to the `LLMConfig` they are attached to — no global
registration, no hook installation, no scope resolution. Each agent that
resolves this config runs the listed extensions in order.

## Prompt caching (Anthropic)

Anthropic supports caching parts of the prompt to reduce cost and latency on
repeated calls. Flowra ships a set of extensions that set cache breakpoints
automatically.

### Quick setup

```python
from flowra.llm.ext.anthropic import anthropic_cache_all

config = LLMConfig(
    provider=provider,
    model="claude-sonnet-4-5@20250929",
    request_extensions=(anthropic_cache_all,),
)
```

`anthropic_cache_all` caches system messages, tools, and the last conversation
message — covers the most common case.

### Available composites

| Extension                        | Caches                                                      |
|----------------------------------|-------------------------------------------------------------|
| `anthropic_cache_all`            | System messages + tools + last message                      |
| `anthropic_cache_non_transient`  | Non-transient prefix of system + tools + messages           |

### Individual extensions

For fine-grained control, use single-slot extensions directly:

| Extension                                        | What it caches                                                          |
|--------------------------------------------------|-------------------------------------------------------------------------|
| `anthropic_cache_all_system_messages`            | Last block of the last system message                                   |
| `anthropic_cache_non_transient_system_messages`  | Last non-transient system block (stops at first transient)              |
| `anthropic_cache_all_tools`                      | Last tool definition                                                    |
| `anthropic_cache_non_transient_tools`            | Last non-transient tool (stops at first transient)                      |
| `anthropic_cache_all_messages`                   | Last block of the last message                                          |
| `anthropic_cache_non_transient_messages`         | Last non-transient message block (stops at first transient)             |

```python
from flowra.llm.ext.anthropic import (
    anthropic_cache_all_system_messages,
    anthropic_cache_all_tools,
)

config = LLMConfig(
    provider=provider,
    model="claude-sonnet-4-5@20250929",
    request_extensions=(
        anthropic_cache_all_system_messages,
        anthropic_cache_all_tools,
    ),
)
```

### The `transient` hint

Blocks and messages can be marked `transient=True` to indicate non-permanent
content. This affects two things:

1. **Caching** — `*_non_transient_*` extensions skip transient blocks when
   placing cache breakpoints, preventing cache invalidation from injected
   context that changes on every call.
2. **Session history** — `ChatAgent` automatically strips transient messages
   when saving conversation history. Transient content (e.g. injected context,
   ephemeral reminders) won't accumulate across turns.

```python
from flowra.llm import TextBlock, UserMessage

# Transient block — won't be cached by non-transient extensions:
TextBlock(text="Current time: 12:00", transient=True)

# Transient message — won't be saved to session history:
UserMessage(blocks=[TextBlock(text="[system reminder]")], transient=True)
```

### Custom extensions

An extension is just a callable ``(LLMRequest) -> None``. Write your own to
apply provider-specific transforms — for example, stamping cache markers on
application-defined history boundaries:

```python
from flowra.llm import LLMRequest
from flowra.llm.providers.anthropic_vertex import AnthropicCacheable

def my_cache_history(request: LLMRequest) -> None:
    # Find the last message marked as a history boundary by your application
    for m in reversed(request.messages):
        if m.metadata.get("history_boundary"):
            if m.blocks:
                AnthropicCacheable(cache_control={"type": "ephemeral"}).write_to(m.blocks[-1])
            break

config = LLMConfig(
    provider=provider,
    model="claude-sonnet-4-5@20250929",
    request_extensions=(my_cache_history,),
)
```

## Tool search

When an agent has many tools (50+), tool definitions consume a large chunk of
the context, and the LLM's ability to pick the right tool degrades. Tool search
solves this with deferred tool loading — tools are sent with only names and
descriptions, and a server-side search tool discovers full definitions on demand.

### Anthropic

```python
from flowra.llm.ext.anthropic import anthropic_tool_search

config = LLMConfig(
    provider=provider,
    model="claude-sonnet-4-5@20250929",
    request_extensions=(anthropic_tool_search(),),
)
```

Reduces token usage by ~85% while maintaining tool selection accuracy.

| Parameter   | Default                  | Description                                           |
|-------------|--------------------------|-------------------------------------------------------|
| `variant`   | `ToolSearchVariant.BM25` | `BM25` (natural language) or `REGEX` (regex patterns) |
| `predicate` | `None`                   | Optional `(Tool) -> bool` — only defer matching tools |

```python
from flowra.llm.ext.anthropic import ToolSearchVariant, anthropic_tool_search

# Defer only admin tools:
anthropic_tool_search(predicate=lambda t: t.name.startswith("admin_"))

# Use regex variant:
anthropic_tool_search(variant=ToolSearchVariant.REGEX)
```

### OpenAI

Requires `OpenAIResponsesProvider` and models that support tool search
(gpt-5.4+).

```python
from flowra.llm.ext.openai import openai_tool_search

config = LLMConfig(
    provider=provider,
    model="gpt-5.4",
    request_extensions=(openai_tool_search(),),
)
```

| Parameter   | Default | Description                                           |
|-------------|---------|-------------------------------------------------------|
| `predicate` | `None`  | Optional `(Tool) -> bool` — only defer matching tools |

```python
# Defer only admin tools:
openai_tool_search(predicate=lambda t: t.name.startswith("admin_"))
```

### How it works

1. Before each LLM call, selected tools are marked with `defer_loading: true`
   and a search tool is added to the request
2. The model receives only tool names and descriptions — no full schemas
3. When the model needs a tool, it calls the search tool with a query
4. The API returns full definitions of matching tools
5. The model invokes the discovered tools normally — transparent to the agent

## Cost tracking

Every `LLMResponse` includes token usage and estimated cost:

```python
response = await provider.call(request)

usage = response.usage
print(usage.input_tokens)                  # input tokens (excludes cached)
print(usage.output_tokens)                 # output tokens
print(usage.cache_read_input_tokens)       # tokens read from cache
print(usage.cache_creation_input_tokens)   # tokens written to cache
print(usage.cost_usd)                      # total estimated cost in USD
```

`Usage` supports addition — accumulate across multiple calls:

```python
total_usage = response1.usage + response2.usage
print(total_usage.cost_usd)
```

---

**Prev:** [Architecture](architecture.md) | **Next:** [Tools](tools.md)
