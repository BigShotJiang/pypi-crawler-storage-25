# Voice & STT for Agent Pipelines — Research

Research date: 2026-03-08
Status: not implemented

## Industry approaches

### N-best list / multiple hypotheses
Standard ASR (Automatic Speech Recognition) approach. STT engine returns top-N results
with confidence scores instead of a single transcription. Most production STT services
support this natively (`max_alternatives` parameter).

### Contextual biasing / speech adaptation
Provide hints to STT: "these words/phrases are likely in this context." The engine boosts
their probability during recognition. Google calls it **speech adaptation / phrase hints**,
OpenAI Whisper uses `prompt` parameter (weaker). Ideal for domain-specific vocabulary
(recipient names, bank names, transaction types).

### Two-pass recognition
First pass — general recognition. Second pass — re-recognize the same audio with refined
context (e.g. after identifying the intent as "payment", add frequent recipients as hints).
Used in voice assistants (Alexa, Google Assistant) for domain-specific scenarios.

### Lattice rescoring
Advanced: STT produces a graph (lattice) of possible recognitions, then an external model
(e.g. LLM) re-ranks paths using domain context. Conceptually close to feeding N-best
variants to an LLM agent and letting it choose.


## STT services comparison

| Service                         | N-best                | Phrase hints                 | Streaming | Price       | Notes                                  |
|---------------------------------|-----------------------|------------------------------|-----------|-------------|----------------------------------------|
| **Google Cloud Speech-to-Text** | Up to 30 alternatives | `speech_contexts` with boost | Real-time | ~$0.006/15s | Available in GCP, good Russian support |
| **Google Cloud STT V2**         | Yes                   | Yes + auto-adaptation        | Real-time | Similar     | Newer API, better quality              |
| **OpenAI Whisper API**          | No (single result)    | `prompt` (weak)              | No        | $0.006/min  | Good quality but no N-best             |
| **Deepgram**                    | Yes                   | Keywords with boost          | Real-time | $0.0043/min | Fast, good for real-time               |
| **Azure Speech**                | N-best                | Phrase list                  | Real-time | ~$1/hour    | Good Russian support                   |

### Google Cloud Speech-to-Text — N-best + phrase hints example

```python
from google.cloud.speech_v1 import RecognitionConfig, SpeechContext

config = RecognitionConfig(
    language_code="ru-RU",
    max_alternatives=5,
    speech_contexts=[SpeechContext(
        phrases=["Маша", "Петя", "Сбербанк"],
        boost=15.0,
    )],
)
```


## Local / free options for experimentation

| Package            | N-best          | Hints            | Quality                      | Install                             |
|--------------------|-----------------|------------------|------------------------------|-------------------------------------|
| **faster-whisper** | Via beam search | `initial_prompt` | Excellent (= OpenAI Whisper) | `pip install faster-whisper`        |
| **Vosk**           | `alternatives`  | Grammars         | Medium                       | `pip install vosk` + model download |
| **whisper.cpp**    | Limited         | No               | Excellent                    | Compile from source                 |

### faster-whisper — quickstart

```bash
pip install faster-whisper
```

```python
from faster_whisper import WhisperModel

model = WhisperModel("base", device="cpu")  # or "large-v3" for best quality
segments, info = model.transcribe("audio.wav", beam_size=5)
for segment in segments:
    print(f"[{segment.start:.1f}s - {segment.end:.1f}s] {segment.text}")
```

Works on Apple Silicon (M1/M2/M3). `beam_size=5` enables multiple hypotheses internally.


## Recommendation for Anna Money

**Google Cloud Speech-to-Text** for production:
- Already available in GCP
- Native N-best (`max_alternatives`) — feed all variants to agent
- Phrase hints with boost — inject frequent recipients, bank names per user
- Real-time streaming — for voice chat scenarios
- Good Russian language support

**faster-whisper** for local experimentation:
- Free, no API keys needed
- Quality comparable to OpenAI Whisper
- Fast on CPU, faster on GPU
- Good starting point before committing to a cloud service


## How this maps to Flowra

- **`on_user_message` hook** — enrich voice input with domain context (frequent recipients,
  recent transactions) before agent sees it
- **Capabilities** — recognize intent (payment, transfer, balance) → load relevant capability
  with domain vocabulary for potential re-recognition
- **Agent-as-tool** — STT as a callable tool that agent can invoke with hints for
  re-recognition: "re-transcribe with these phrase hints"
- **Streaming** — `on_text_delta` feeds TTS for real-time voice response
