# Lifecycle Hooks & Conversation View

Research date: 2026-04-11

## Problem

External code needs to scan the full conversation (past history + current turn messages) during a turn. Currently `turn_messages` lives in TurnAgent's ephemeral scope and is inaccessible from outside.

Previous attempt (`StartTurnEvent.turn_messages`) failed because the hook doesn't re-fire on crash recovery — `start` step isn't replayed on resume.

## Design: `__post_init__` Lifecycle Method

Add a single new concept: `__post_init__()` — an async lifecycle method on Agent.

- Called by the engine after `__init__`, both on first run and crash recovery
- Takes no parameters — agent already has everything from `__init__` in `self`
- Async — agent can emit hook events, do async work

This is the **only new framework mechanism**. Everything else uses existing hooks.

### How TurnAgent uses it

```python
class TurnAgent(Agent[TurnSpec, TurnResult]):
    def __init__(self, store, hooks, ...):
        self.__turn_messages = store.ephemeral.slot(...)
        self.__hooks = hooks

    async def __post_init__(self):
        await self.__hooks.emit(TurnReadyEvent(turn_messages=self.__turn_messages))
```

`TurnReadyEvent` is a regular typed hook event — not a special lifecycle event.

### How ChatAgent uses it

```python
class ChatAgent(Agent[ChatSpec, ChatResult]):
    def __init__(self, store, hooks, ...):
        self.__history = ...
        hooks.on(TurnReadyEvent, self.__on_turn_ready, scope=TurnAgent)

    async def __on_turn_ready(self, event):
        conversation = Conversation(self.__history, event.data.turn_messages)
        await self.__hooks.emit(ConversationReadyEvent(conversation=conversation))
```

### How external code uses it

```python
hooks.on(ConversationReadyEvent, lambda e: scanner.attach(e.data.conversation))
```

Each level emits its own typed event. No generic `AgentInitialized` — just domain-specific events through regular hooks.

## Conversation

A thin read-only view over history + turn_messages:

```python
class Conversation:
    def __init__(self, history, turn_messages):
        self.__history = history
        self.__turn_messages = turn_messages

    @property
    def messages(self) -> list[UserMessage | AssistantMessage]:
        return [*self.__history, *self.__turn_messages]
```

Conversation owns no data. History lives in ChatAgent's persistent scope, turn_messages in TurnAgent's ephemeral scope.

For parallel forks (e.g., reviewer + generator on the same history): each TurnAgent has its own ephemeral turn_messages. Each fork is `Conversation(shared_history, this_turn_messages)`.

## Why not a unified list?

Considered making Conversation a single append-only list with fork/commit. Rejected because:

- Requires checkpoint/rollback on append-only storage — complex
- Transient messages (context injection) would need special handling
- Parallel turns require branching anyway — which is conceptually the same as separate lists with a combined view

The thin view approach is simpler and composes naturally with existing storage.

## Transient Messages

Transient messages (e.g., "[Remember: be helpful]") should NOT be in the conversation. They're context injection, not real messages. Inject them at LLM request time (via `StartIterationEvent.additional_messages` or `PrepareLLMRequestEvent`), not as fake messages in the history.

This simplifies Conversation — it only contains real messages.

## Unified Binding

Currently three separate binding systems: `agent_arg` for `__init__`, `step_arg` for steps, `tool_arg` for tools. Agent binding should be unified under a single `agent_arg` namespace with one resolver for `__init__`, `__post_init__`, and all steps.

### Sources

| Marker | Source | Matching | Available in |
|--------|--------|----------|-------------|
| `agent_arg.AGENT_SPEC` | Spec the agent was created with | isinstance | `__init__`, `__post_init__`, all steps |
| `agent_arg.STEP_SPEC` | Spec for this step invocation | isinstance | steps |
| `agent_arg.CHILD(tag?)` | Child results after Spawn | isinstance | then-steps |
| `agent_arg.SERVICE` | ServiceLocator | exact type | everywhere |

### Matching rules

- **Services** — exact type match (`services[type]`)
- **Everything else** (agent spec, step spec, child results) — isinstance match. Subclasses, union members all match. If parameter is `BaseSpec` and value is `PaymentSpec(BaseSpec)` → match.

### Implicit resolution (no annotation)

When no explicit marker, resolver tries sources in order:
1. Value isinstance-matches step spec → `STEP_SPEC`
2. Value isinstance-matches agent spec type → `AGENT_SPEC`
3. Value isinstance-matches child outputs → `CHILD`
4. Exact type match in services → `SERVICE`

Step spec takes priority over agent spec — it's closer to the current context.

For entry step: `AGENT_SPEC` and `STEP_SPEC` are the same value. For `GotoStep(spec=something)`: `STEP_SPEC` is `something`, `AGENT_SPEC` is the original agent spec.

### Simple agents need no `__init__`

```python
class SimpleAgent(Agent[MySpec, MyResult]):
    @step(entry=True)
    async def run(self, spec: MySpec, provider: LLMProvider) -> MyResult:
        response = await provider.call(...)
        return MyResult(text=response.message)
```

### `tool_arg` stays separate

Tools are a different concept — `tool_arg.INPUT` / `tool_arg.SERVICE` remain unchanged.

## Open Questions

1. Naming: `__post_init__`, `on_ready`, `after_init`?
2. Do we need a corresponding `pre_destroy` / `on_teardown`?
