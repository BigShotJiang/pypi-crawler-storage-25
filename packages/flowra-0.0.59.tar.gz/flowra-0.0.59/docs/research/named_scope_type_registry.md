# Named Scope Type Registry — Missing Type Registration

## Problem

When a named scope contains slots with dataclass types (e.g., `AppendOnlyList[UserMessage | AssistantMessage]`), those types are not registered in the scope's `type_registry`. This causes `TypeError: Unknown type tag` during deserialization when the named scope is hydrated from storage.

## Reproduction

A multi-agent setup where:

1. Root agent creates a named scope with a typed slot:
   ```python
   conversation = store["conversation"]
   history = conversation.slot(AppendOnlyList[UserMessage | AssistantMessage], "history")
   ```

2. Root agent spawns child agent A (e.g., a router), which runs and finishes.

3. Root agent then spawns child agent B. During creation of B, `__init_node` in `runtime.py` tries to hydrate the named scope "conversation" from storage:
   ```python
   # runtime.py:408-416
   for scope_name, named_scope in registry.all_scopes().items():
       if not registry.is_hydrated(scope_name):
           ns_tr = named_scope.type_registry  # ← EMPTY dict
           ns_state = await storage.load(scope_name)
           if ns_state:
               deserialized = {k: deserialize_value(v, ns_tr) for k, v in ns_state.items()}
   ```

4. `deserialize_value` encounters a serialized `UserMessage` object, looks it up in the empty `type_registry`, and raises:
   ```
   TypeError: Unknown type tag: 'UserMessage'
   ```

## Root Cause

`ScopeData.__type_registry` (in `scope.py:30`) is initialized as an empty dict and **never populated**:

```python
class ScopeData:
    def __init__(self) -> None:
        ...
        self.__type_registry: dict[str, type] = {}

    def slot(self, cls: Any, key: str) -> Any:
        origin = get_origin(cls) or cls
        args = get_args(cls)
        if origin is Scalar:
            if args:
                self.__slot_value_types[key] = args[0]
            # ← type_registry is NOT updated with dataclass types from args[0]
            return self.__create_scalar(key)
        if origin is AppendOnlyList:
            if args:
                self.__slot_value_types[key] = args[0]
            # ← type_registry is NOT updated with dataclass types from args[0]
            return self.__create_append_only(key)
```

By contrast, agent-level type registries are built by `build_type_registry` in `compile/type_registry.py`, which walks step hints and calls `collect_dataclass_types`. But named scopes bypass this — they are created programmatically in agent constructors, and their slot types are never introspected for type registration.

## Suggested Fix

In `ScopeData.slot()`, collect dataclass types from slot type arguments into `__type_registry`:

```python
from ..definition.compile.type_registry import collect_dataclass_types

def slot(self, cls: Any, key: str) -> Any:
    origin = get_origin(cls) or cls
    args = get_args(cls)
    if origin is Scalar:
        if args:
            self.__slot_value_types[key] = args[0]
            collect_dataclass_types(args[0], self.__type_registry)
        return self.__create_scalar(key)
    if origin is AppendOnlyList:
        if args:
            self.__slot_value_types[key] = args[0]
            collect_dataclass_types(args[0], self.__type_registry)
        return self.__create_append_only(key)
```

This ensures that any dataclass types used in slot declarations are available for deserialization when the scope is hydrated from storage.

## Notes

- This likely also affects **persistent scopes** (`store.persistent.slot(...)`) — the same `ScopeData` class is used. However, per-agent persistent scopes use the agent's type registry (from step hints) during hydration, so the problem only manifests when types are introduced programmatically (not via step hints).
- The `slot_value_types` dict already captures the top-level type arg, but `type_registry` needs the full recursive collection (e.g., `UserMessage` contains `TextBlock`, `ToolUseBlock`, etc.).
- `collect_dataclass_types` already handles recursive walking and deduplication.
