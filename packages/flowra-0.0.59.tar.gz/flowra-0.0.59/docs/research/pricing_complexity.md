# LLM Pricing Complexity — Research

Research date: 2026-03-18
Implemented: `flowra/llm/pricing/` with `PricingRegistry` and auto-generated data from litellm

## Dimensions that affect price

### 1. Access provider

The same model costs differently depending on how you access it:

| Model             | Direct API   | Vertex AI  | Bedrock   | Azure     |
|-------------------|--------------|------------|-----------|-----------|
| Claude Sonnet 4.6 | $3/$15       | different  | different | N/A       |
| GPT-4o            | $2.50/$10    | N/A        | N/A       | different |
| Gemini 2.5 Pro    | N/A          | $1.25/$10  | N/A       | N/A       |

litellm tracks this — each model has separate entries per provider.

### 2. Context length tiers

Anthropic and Google charge more for long contexts (>200k tokens):

**Anthropic:** Input 2x, Output 1.5x, Cache read 2x, Cache creation 2.5x

**Google Gemini 2.5 Pro:** Input 2x, Output 1.5x, Cache read 2x

### 3. Cache creation TTL (Anthropic)

- 5-minute ephemeral: 1.25x input price
- 1-hour: 2x input price

### 4. Thinking/reasoning tokens

Extended thinking tokens billed at output rate (Anthropic, OpenAI reasoning models).

### 5. Batch API discounts

OpenAI Batch API: 50% off. Google Batch: different rates. Not tracked.

## What was implemented

`PricingRegistry` in `flowra/llm/pricing/` supports all dimensions above except batch discounts:
- Per-provider pricing via `(provider, model)` lookup
- Context length tiers (>200k tokens)
- Cache creation TTL variants (5m and 1h)
- Reasoning tokens
- Auto-generated data from litellm (`tools/sync_pricing.py` → `data/generated.json`)
- Manual overrides in `data/custom.json`

## What's not covered

- **Batch API discounts** — not tracked (low priority, batch usage is rare in agent scenarios)
