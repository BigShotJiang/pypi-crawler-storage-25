# Agent Async Initialization — Research

Research date: 2026-04-06
Status: Parked — not needed immediately (ToolRegistry redesign removes the primary use case)

## Problem

Agent constructors (`__init__`) are sync. Sometimes an agent needs to perform async work before any steps run — e.g., fetching data from a service, opening a resource, initializing something that requires I/O.

### Constraints

- `__init__` is called by the runtime, not by user code
- On crash recovery, the entire agent tree is recreated from scratch — constructors are called again
- Slot hydration (restoring persisted state) happens after `__init__`
- The runtime fully controls agent creation and could support async initialization

### Why it matters less now

The primary motivating use case was creating `ToolRegistry` in agent constructors (which required MCP connections, an async operation). With the proposed ToolRegistry redesign (see `tool_registry_redesign.md`), registry creation becomes sync, removing the immediate need.

However, the general problem remains — agents may want to do async work during initialization for other reasons (fetching configuration, warming caches, acquiring resources).

## Options explored

### Option A: Separate `async def setup(self)` method

Runtime calls `__init__` (sync), then `setup()` (async) if it exists.

```python
class MyAgent(Agent[Spec, Result]):
    def __init__(self, store: AgentStore) -> None:
        self.__history = store["conversation"].slot(...)

    async def setup(self, some_service: MyService) -> None:
        self.__data = await some_service.fetch_something()
```

**Pros:**
- Simple, explicit
- `__init__` stays sync, `setup` is clearly async
- Parameters injected by runtime in both

**Cons:**
- Two initialization methods — confusing ("what goes where?")
- `self` is partially initialized between `__init__` and `setup`
- Name `setup` may conflict with user methods

### Option B: Dunder `__ainit__` as async factory (replaces `__init__`)

If `__ainit__` exists, runtime calls it instead of `__init__`. It's a classmethod that returns `Self`.

```python
class MyAgent(Agent[Spec, Result]):
    def __init__(self, history: AppendOnlyList[...], data: SomeData) -> None:
        self.__history = history
        self.__data = data

    @classmethod
    async def __ainit__(cls, store: AgentStore, some_service: MyService) -> Self:
        history = store["conversation"].slot(...)
        data = await some_service.fetch_something()
        return cls(history=history, data=data)
```

**Pros:**
- Clean separation: `__ainit__` is the factory with DI, `__init__` is a plain constructor
- Single entry point for runtime
- `__init__` can be tested independently without runtime

**Cons:**
- Custom dunder names (`__name__`) are reserved by Python for the language itself — using them in libraries is discouraged
- Looks like a Python language feature but isn't — may confuse developers
- No known precedent in major Python libraries

### Option C: Fixed-name classmethod `create`

Convention: if an agent has `async def create(cls, ...) -> Self`, runtime uses it.

```python
class MyAgent(Agent[Spec, Result]):
    def __init__(self, history: AppendOnlyList[...], data: SomeData) -> None:
        self.__history = history
        self.__data = data

    @classmethod
    async def create(cls, store: AgentStore, some_service: MyService) -> Self:
        history = store["conversation"].slot(...)
        data = await some_service.fetch_something()
        return cls(history=history, data=data)
```

**Pros:**
- Well-known pattern in the Python ecosystem
- No magic, no custom dunders
- Many async libraries use this: `aiosqlite.connect()`, various `create()` factories

**Cons:**
- Fixed name — may conflict with user methods (though unlikely for `create`)
- Convention-based — not enforced by types

**Precedents:**
- `aiosqlite`: `db = await aiosqlite.connect("file.db")`
- `aiohttp`: `session = aiohttp.ClientSession()` + `__aenter__`
- `asyncpg`: `conn = await asyncpg.connect(...)`
- `motor`: `client = motor.AsyncIOMotorClient(...)`
- General Python community: `@classmethod async def create()` is the most common async factory pattern

### Option D: Decorator `@agent_factory`

Runtime finds the factory method by decorator marker (like `@step`).

```python
class MyAgent(Agent[Spec, Result]):
    def __init__(self, history: AppendOnlyList[...], data: SomeData) -> None:
        self.__history = history
        self.__data = data

    @agent_factory
    @classmethod
    async def my_custom_factory(cls, store: AgentStore, some_service: MyService) -> Self:
        history = store["conversation"].slot(...)
        data = await some_service.fetch_something()
        return cls(history=history, data=data)
```

**Pros:**
- No fixed name
- Consistent with `@step` pattern in Flowra
- Explicit opt-in

**Cons:**
- More machinery for something that's at most one method per agent
- Needs validation (at most one `@agent_factory` per class)
- Decorator stacking (`@agent_factory @classmethod async`) is verbose

### Option E: Do nothing

Don't add async init. Keep `__init__` sync. If async work is needed, do it outside (in the wiring layer) and provide results via services.

**Pros:**
- No new concepts
- Forces clean architecture — async resources are managed externally
- Simpler framework

**Cons:**
- Less flexible for agents that genuinely need per-instance async initialization
- Pushes complexity to the wiring layer

## Recommendation

No immediate action needed — the ToolRegistry redesign eliminates the primary use case.

If this becomes needed later, **Option C** (`create` classmethod) or **Option D** (decorator) are the strongest candidates. Option C is simpler and follows ecosystem conventions. Option D is more consistent with Flowra's own patterns.

**Option B** (`__ainit__` dunder) should be avoided — custom dunders are reserved by Python and create false expectations.
