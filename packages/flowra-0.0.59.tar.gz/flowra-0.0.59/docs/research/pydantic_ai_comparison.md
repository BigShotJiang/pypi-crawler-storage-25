# Pydantic AI Comparison — Research

Research date: 2026-04-03

## Overview

Pydantic AI is a Python 3.12+ agent framework by the Pydantic team, designed with FastAPI-like
ergonomics. Central abstraction is the `Agent[DepsType, OutputType]` class — a declarative,
stateless global object that orchestrates LLM interactions through tools, structured output,
and dependency injection.

flowra's central abstraction is a state machine agent (`Agent[Spec, Result]`) with explicit
`@step` methods, persistent state slots, and crash recovery.

## Architecture

| | **flowra** | **Pydantic AI** |
|---|---|---|
| Agent | State machine with `@step` methods, `Agent[Spec, Result]` | Declarative object `Agent[Deps, Output]`, no steps |
| Definition | Class with constructor (DI via services) | Global variable (FastAPI-style) |
| Graph/FSM | Built into the core — `@step`, `Spawn`, `CallAgent`, `GotoAgent` | Separate `pydantic-graph` library, edges via return types |
| Philosophy | State machine first — agent = automaton with persistent state | LLM loop first — agent = wrapper over LLM call |

## LLM Providers

| | **flowra** | **Pydantic AI** |
|---|---|---|
| Abstraction | `LLMProvider` ABC, `call()` + `stream()` | `Model` ABC, separated from `Provider` (auth) and `Profile` (format) |
| Providers | 6 (Anthropic Vertex/Foundry, OpenAI/Azure, OpenAI Responses, Google Vertex) | 11+ (OpenAI, Anthropic, Gemini, xAI, Bedrock, Groq, Mistral, etc.) |
| Fallback | None built-in | `FallbackModel` — automatic failover |
| Concurrency limit | None built-in | `ConcurrencyLimitedModel` |
| Pricing | Built-in `PricingRegistry` with per-provider rates | None (via Logfire/external) |

Pydantic AI has a three-layer model abstraction: Model (SDK wrapper), Provider (auth/connection),
Profile (request format). This allows e.g. `AzureProvider` to work with `OpenAIChatModel` without
a separate class. flowra uses a single `LLMProvider` class per backend, with inheritance for
variants (e.g. `AzureOpenAIProvider(OpenAIProvider)`).

## Tools

| | **flowra** | **Pydantic AI** |
|---|---|---|
| Definition | `@tool` decorator, `ToolRegistry` | `@agent.tool` / `@agent.tool_plain` decorators |
| DI | `ServiceLocator` — any services in agent constructor | `RunContext[DepsType]` — typed context parameter |
| MCP | `McpConnection` | `MCPServer`, `FastMCPToolset` |
| Retry | Via `max_consecutive_errors` | `ModelRetry` exception, per-tool retry limits |
| Toolsets | `ToolRegistry` (filtering, grouping) | Rich system: `FilteredToolset`, `PrefixedToolset`, `DeferredLoadingToolset`, `ApprovalRequiredToolset` |
| Schema generation | From function signature + `marshmallow_recipe` | From function signature + Pydantic models + docstrings |

Pydantic AI's tool system is more composable — toolsets can be filtered, prefixed, renamed,
deferred, or require approval. flowra's `ToolRegistry` is simpler but handles the common cases.

## State Management

| | **flowra** | **Pydantic AI** |
|---|---|---|
| Model | `Scalar[T]`, `AppendOnlyList[T]` — typed slots with dirty tracking | No built-in; `message_history` passed manually |
| Scopes | `ephemeral`, `persistent`, `named` | None (only in Graph: `FileStatePersistence`) |
| Crash recovery | Built-in — restore from storage | Only in Graph |
| Session storage | `InMemorySessionStorage`, extensible ABC | None at agent level |

This is flowra's biggest differentiator. State is first-class: typed slots, automatic
dirty tracking, crash recovery, named scopes for cross-agent shared state. Pydantic AI
treats state as external — the application manages conversation history and persistence.

## Streaming

| | **flowra** | **Pydantic AI** |
|---|---|---|
| Events | `TextDelta`, `ThinkingDelta`, `ContentComplete` | `stream_text()`, `stream_output()`, raw events |
| Structured streaming | No (falls back to non-streaming) | Yes — partial Pydantic objects via `stream_output()` |

Pydantic AI can stream partial structured objects (e.g. partial `UserProfile` as fields
arrive). flowra streams text/thinking deltas and delivers the full response at the end.

## Structured Output

| | **flowra** | **Pydantic AI** |
|---|---|---|
| Approach | `json_schema` in `LLMRequest` + retry validation (Anthropic) | 3 modes: ToolOutput, NativeOutput, PromptedOutput |
| Types | Raw JSON schema, `marshmallow_recipe` | `BaseModel`, `dataclass`, `TypedDict`, union, output functions |
| Retry | `max_schema_retries` | `@agent.output_validator` + `ModelRetry` |

Pydantic AI's structured output is significantly richer:
- **ToolOutput** — registers output type as a tool call (default, most reliable)
- **NativeOutput** — uses model's JSON Schema mode (OpenAI structured outputs)
- **PromptedOutput** — injects schema into instructions (universal fallback)
- **Output functions** — functions as output types, model provides arguments
- **Union types** — `Foo | Bar` lets the model pick

flowra keeps it simpler — raw JSON schema with prompt-based enforcement and retry loop.

## Multi-Agent

| | **flowra** | **Pydantic AI** |
|---|---|---|
| Orchestration | `CallAgent`, `GotoAgent`, `Spawn` (parallel) — first-class | Delegation via tools or programmatic hand-off |
| Parallel execution | `Spawn(children=[...])` — built-in | None built-in |
| Shared state | Named scopes (`store["shared"]`) | Via deps |

flowra's multi-agent is more structured: explicit child spawning, parallel execution,
shared state through named scopes. Pydantic AI relies on calling child agents from tools
or application code — more flexible but less structured.

## Testing

| | **flowra** | **Pydantic AI** |
|---|---|---|
| Approach | Mock `LLMProvider`, standard pytest | `TestModel` (auto-generates valid responses), `FunctionModel` (custom) |
| Safety guard | None | `ALLOW_MODEL_REQUESTS = False` prevents accidental real API calls |

Pydantic AI's `TestModel` auto-generates valid responses matching tool schemas and output
types without any AI calls. This is a significant DX advantage for unit testing.

## Observability

| | **flowra** | **Pydantic AI** |
|---|---|---|
| Span-hooks | Built-in `LLMCallSpan`, `ToolCallSpan`, `AgentSpan`, `StepSpan` | Via Logfire / OTel |
| Integrations | MLflow, OpenTelemetry (built-in ext) | Logfire, Langfuse, W&B, Arize, MLflow, ~10 more |

Both support OpenTelemetry. Pydantic AI has a commercial integration (Logfire) and wider
third-party support. flowra has built-in span-hooks with guaranteed enter/exit semantics.

## Capabilities (Pydantic AI unique)

Pydantic AI has a **Capabilities** system — composable bundles of tools + hooks +
instructions + model settings:
- `Thinking`, `WebSearch`, `WebFetch`, `ImageGeneration` — provider-adaptive built-ins
- `MCP`, `ThreadExecutor`, `Hooks`, `PrepareTools` — utility capabilities
- Custom capabilities via `AbstractCapability`

Multiple capabilities compose automatically: before hooks fire in order, after hooks in
reverse, wrap hooks nest as middleware. flowra has no direct equivalent — similar
functionality is achieved through hook subscriptions and service injection.

## Key Takeaways

**flowra is stronger in:**
- Persistent state with crash recovery — first-class, typed, automatic
- State machine agents with explicit steps and transitions
- Parallel sub-agent execution (`Spawn`)
- Built-in pricing tracking
- Named scopes for cross-agent shared state

**Pydantic AI is stronger in:**
- Provider ecosystem (11+ vs 6)
- Structured output (3 modes, partial streaming, output functions, union types)
- Toolset composition (filtered, prefixed, deferred, approval-required)
- Testing ergonomics (TestModel, FunctionModel, safety guard)
- Capabilities system (composable extensions)
- Model fallback/concurrency controls
- Community adoption and third-party integrations

**Different design centers:**
- flowra: "agents are stateful automata that survive crashes" — optimized for long-running,
  persistent, multi-step workflows
- Pydantic AI: "agents are typed LLM wrappers" — optimized for request/response patterns
  with rich validation and provider flexibility

## Ideas Worth Considering

From Pydantic AI's design, potentially useful for flowra:

1. **FallbackModel** — automatic model failover (try model A, fall back to B)
2. **TestModel** — auto-generate valid mock responses from tool/output schemas
3. **Richer toolset composition** — filtered, prefixed, deferred loading, approval-required
4. **Output functions** — functions as output types
5. **Partial structured streaming** — stream partial objects as fields arrive
6. **Safety guard for tests** — prevent accidental real API calls
7. **Capabilities** — composable extension bundles (tools + hooks + instructions)
