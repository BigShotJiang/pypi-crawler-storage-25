# Built-in LLM Retry with Backoff in Tool Loop — Research

Research date: 2026-03-24
Status: not implemented

## Problem

When LLM providers return transient errors (429 rate limit, 5xx server errors,
network timeouts), the tool loop has no retry logic. The exception propagates
and kills the agent.

Note: both `anthropic` and `openai` SDKs have built-in retry (2 retries by
default), but SDK retries are short (seconds). Real throttling can last minutes.

## Recommendation: retry inside TurnAgent.call_llm()

Retry on transient LLM errors is infrastructure, not business logic. It belongs
in the tool loop with a simple config.

### RetryConfig

```python
@dataclass(frozen=True)
class RetryConfig:
    max_attempts: int = 5           # total attempts (1 = no retry)
    initial_delay: float = 4.0      # seconds
    max_delay: float = 240.0        # seconds
    backoff_factor: float = 2.0     # exponential multiplier
    retryable: Callable[[BaseException], bool] | None = None  # custom predicate
```

### What to retry

Generic check without importing provider SDKs:

```python
def is_retryable(exc: BaseException) -> bool:
    status = getattr(exc, "status_code", None) or getattr(exc, "status", None)
    if status in (429, 500, 502, 503, 529):
        return True
    type_name = type(exc).__name__
    if any(s in type_name for s in ("Timeout", "Connection", "Unavailable")):
        return True
    return False
```

### Streaming

Retry only on initial connection errors. If `stream()` raises before yielding
any events — retry. Mid-stream failures are rare and a different problem.

### Interrupt integration

`asyncio.sleep(delay)` during backoff should respect the interrupt token.

## Open questions

1. **Jitter?** Add ±25% random jitter to avoid thundering herd.
2. **Retry-After header?** Low priority — SDKs likely consume it in their built-in retries.
3. **Default on or off?** On — `RetryConfig()` with sensible defaults. `max_attempts=1` for fail-fast.

## Related

- `model_fallback.md` — complementary. Retry handles transient errors (same model),
  fallback handles persistent errors (switch model). Could chain: retry N times → fallback.
