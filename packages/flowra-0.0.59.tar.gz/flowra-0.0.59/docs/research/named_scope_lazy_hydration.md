# Scope Lazy Per-Slot Hydration

Research date: 2026-04-12

Supersedes: `named_scope_type_registry.md` (wrong approach)

## Problem

All scopes (ephemeral, persistent, named) currently rely on external type
registries for deserialization. This is fragile:

- **Named scopes**: shared between agents, slots created at different times.
  Eager whole-scope hydration fails — slots not yet created are skipped, types
  from later agents are missing.
- **Ephemeral/persistent**: use agent-level type registry (from step hints).
  Works today, but only because agent compilation statically collects all types.
  Programmatically created slots with types not in step hints would fail.

The root cause: type knowledge and hydration are separated. Types are collected
in one place (compile-time or scope-level registry), hydration happens elsewhere
(runtime `__init_node`), and they must agree. This is unnecessary coupling.

## Solution: Unified lazy per-slot hydration for all scopes

Every scope (ephemeral, persistent, named) works the same way:

1. **Load phase**: Raw serialized data loaded from storage into scope as
   `dict[str, Any]` — no deserialization.

2. **Slot creation**: `scope.slot(AppendOnlyList[T], "key")`:
   - Create the slot (Scalar or AppendOnlyList)
   - If raw data has "key" → deserialize using type `T` → restore into slot
   - Build type registry entry from `T` (for later serialization)
   - Remove "key" from raw data (consumed)

3. **Serialization**: Uses per-slot type info from `slot()` calls (already
   stored in `slot_value_types`). Build tag_by_type lazily from
   `collect_dataclass_types` at slot creation time.

### No separate type_registry needed

Type info comes from `slot()` parameter — always correct, always available at
the right time. No compile-time collection, no scope-level registry, no
agent-level registry needed for scope hydration.

Agent-level type registry (from `compile_agent`) remains for execution state
serialization (pending_spec, result, child_results) — unrelated to scopes.

### What changes

- `ScopeData.type_registry` — replace with serialization-only registry built
  lazily from `slot()` calls via `collect_dataclass_types`
- `ScopeData.hydrate(data)` — becomes `load_raw(data)`, stores raw dict
- `ScopeData.slot()` — after creating slot, checks raw data and restores
- `NamedScopeRegistry.is_hydrated` / `mark_hydrated` — remove
- Runtime `__init_node` — loads raw data into all scopes without deserializing
- Runtime serialization — uses scope's lazily-built type info

### Validation

- `slot()` with existing key but different container type → error
- Raw data keys never claimed by any slot → warning or silent
