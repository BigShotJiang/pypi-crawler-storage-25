# Strands Agents SDK vs Flowra — Comparison

Research date: 2026-03-08
Updated: 2026-04-08

## Strands multi-agent architecture

Strands provides three multi-agent patterns in `strands.multiagent`:

### Graph (deterministic DAG)

`GraphBuilder` / `Graph` — dependency-driven execution with parallel batches:

- Nodes are `Agent` or nested `MultiAgentBase` (Graph/Swarm can be a node)
- Edges with optional `condition: Callable[[GraphState], bool]` — developer-defined routing
- Real parallel execution via `asyncio.create_task` for independent nodes
- Cyclic graphs supported (with `max_node_executions` + `execution_timeout` limits)
- State between nodes: text (output → input) + `GraphState.results` dict for conditions
- Session management at Graph level (individual agent nodes cannot have their own)
- Interrupts supported (hook-based, for human-in-the-loop)
- Hooks: `BeforeNodeCallEvent`, `AfterNodeCallEvent`

### Swarm (autonomous handoffs)

`Swarm` — LLM-driven sequential coordination:

- Auto-injects `handoff_to_agent` tool into every agent
- LLM decides when and to whom to hand off
- **Strictly sequential** — one agent at a time, no parallel execution
- `SharedContext` — JSON key-value store between agents (via handoff `context` param)
- Repetitive handoff detection to prevent agent loops
- Safety limits: `max_handoffs`, `max_iterations`, `execution_timeout`

### Workflow (community tool, not in core SDK)

Lives in `strands_tools` package — LLM creates and manages workflows via tool calls.
This is an LLM-controlled tool, not a framework-level orchestration primitive.

### Agent-as-tool

No first-class abstraction. Options:
- Nest Graph/Swarm as a node inside another Graph
- `use_agent` / `use_llm` community tools (LLM spawns sub-agents dynamically)
- Manual: wrap agent call in a `@tool` function

## What Strands has that Flowra doesn't

| Capability | Strands | Flowra | Priority |
|---|---|---|---|
| **Guardrails** | Amazon Bedrock Guardrails — content filtering, topic blocking, PII | None | Medium |
| **A2A protocol** | Cross-process agent communication via standard protocol | No — agents within a single runtime | Low |
| **Cloud session stores** | DynamoDB, S3, Bedrock AgentCore Memory | InMemory, File, custom (no cloud adapters) | Medium |
| **Swarm pattern** | LLM-driven handoffs with `handoff_to_agent` tool | No built-in swarm; achievable via custom tools | Low |
| **Cyclic graphs** | Graph supports cycles with safety limits | No cycles — agents are DAGs (but `GotoStep` loops within an agent) | Low |
| **Bidirectional streaming** | Experimental real-time voice/audio | No | Low |

## What Flowra has that Strands doesn't (or weaker)

| Capability | Flowra | Strands |
|---|---|---|
| **Step-level crash recovery** | Persistence after each step, resume from exact point | Session persistence after node calls, not within a node |
| **Incremental dirty-tracking** | `Scalar[T]` / `AppendOnlyList[T]` save only changes | Saves state entirely |
| **Typed state with scopes** | `Scalar[T]`, `AppendOnlyList[T]` with ephemeral/persistent/named scopes | Text + JSON dict between agents, no typed state |
| **State machine with compile-time checks** | `@step`, `GotoStep`/`GotoAgent`/`Spawn` — compiler checks types at class definition | Model-driven loop, no explicit state machine |
| **`WhenAny`/`WhenN` combinators** | First-to-complete wins, automatic cancellation of losers | Graph has only dependency-based (WhenAll) parallelism |
| **Cooperative interrupts** | `InterruptToken` with parent→child cascade through entire tree | Hook-based interrupts for human-in-the-loop, no cascading |
| **DI into tool handlers** | Services injected by type annotation | Tools receive only tool input + `ToolContext` |
| **Agent-as-tool** | `@agent_tool` / `make_agent_tool` — first-class with input/output schema | No first-class abstraction |
| **Tool search with deferred loading** | Anthropic + OpenAI server-side tool search, ~85% token reduction | No equivalent |
| **Compile-time result type validation** | Step return types must be subset of Agent generic parameter | No type checking between nodes |

## Parallel execution comparison

| Aspect | Strands Graph | Flowra |
|---|---|---|
| Mechanism | Nodes without dependencies run in parallel batches | `Spawn` with `WhenAll`/`WhenAny`/`WhenN` |
| Cancellation | No — all parallel nodes must complete | `WhenAny`/`WhenN` cancel remaining children |
| Nesting | Graph/Swarm can be a node | Agents can `Spawn` other agents recursively |
| State isolation | Shared `GraphState.results` dict | Scoped: each agent has own ephemeral/persistent state |

## Sources

- [Introducing Strands Agents (AWS Blog)](https://aws.amazon.com/blogs/opensource/introducing-strands-agents-an-open-source-ai-agents-sdk/)
- [Strands Agents Documentation](https://strandsagents.com/latest/documentation/docs/)
- [Multi-Agent Patterns](https://dev.to/aws-builders/understanding-multi-agent-patterns-in-strands-agent-graph-swarm-and-workflow-4nb8)
- [A2A Protocol](https://strandsagents.com/latest/documentation/docs/user-guide/concepts/multi-agent/agent-to-agent/)
- [Guardrails](https://strandsagents.com/latest/documentation/docs/user-guide/safety-security/guardrails/)
- [GitHub - sdk-python](https://github.com/strands-agents/sdk-python)
- [Strands Graph source](https://github.com/strands-agents/sdk-python/blob/main/src/strands/multiagent/graph.py)
- [Strands Swarm source](https://github.com/strands-agents/sdk-python/blob/main/src/strands/multiagent/swarm.py)
