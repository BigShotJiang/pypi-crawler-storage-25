# Tool Registry Redesign — Research

Research date: 2026-04-06
Updated: 2026-04-07 (decisions finalized)

## Problem

The current `ToolRegistry` conflates two concerns:

1. **Connection management** — opening/closing MCP connections, background tool list refresh
2. **Tool resolution & execution** — looking up tools by name, executing them

This creates several problems:

- `ToolRegistry.create()` is async (because it opens MCP connections), so registries cannot be created in agent constructors. Agent constructors must be sync because they are re-invoked on crash recovery.
- `ToolRegistry` owns MCP connections and is responsible for closing them. Composing registries (e.g., parent MCP registry + child's local tools) requires ownership tracking (borrowed vs owned sources).
- `LocalToolGroup` is essentially a mini-registry with a prefix — a redundant concept.
- MCP tool lists are refreshed in the background and `ToolRegistry` auto-rebuilds on changes. This is problematic for workflows that pre-process tool lists (e.g., discovering mode descriptors from tool markers) — a tool list changing mid-session would invalidate the pre-processed state.
- There is no clean way for a sub-agent to extend a parent's tool set with its own local tools without creating a separate registry (which would require re-connecting to MCP).
- `ToolRegistry` is a service on `AgentRuntime`, meaning it's static for the lifetime of the runtime. No way to provide different tools per-run or dynamically.

## Real-world scenario (Gemma)

Gemma's chat workflow:

1. Connects to MCP servers and gets available tools
2. Scans tool descriptions for markers (`#mode_descriptor`, `#modes`, `#nomodes`)
3. Calls `#mode_descriptor` tools to get mode configuration (JSON)
4. Filters tools by mode (include/exclude lists from descriptors)
5. Each mode agent needs: filtered external tools + its own system tools (e.g., `respond_to_customer`, `switch_mode`)

This means:
- MCP tool list must be **frozen** after discovery — no background updates mid-session
- Tool registry composition must be **sync** — sub-agents are created/destroyed frequently, including on crash recovery
- The domain layer must not care whether tools came from MCP or local stubs (for testing/simulation scripts)

## Decisions

### 1. ExecutableTool — unified tool unit

A single frozen type that represents a tool ready to execute, regardless of origin (local or MCP):

```python
type ToolExecutor = Callable[[dict[str, Any], dict[type, Any]], Awaitable[ToolResult]]
#                             ^args               ^services

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ExecutableTool:
    definition: ToolDefinition
    executor: ToolExecutor

    def with_name(self, name: str) -> Self:
        return dataclasses.replace(
            self, definition=dataclasses.replace(self.definition, name=name),
        )
```

- **LocalTool** creates an `ExecutableTool` where the executor closes over handler + binding + validation
- **MCP snapshot** creates an `ExecutableTool` where the executor closes over `connection.call_tool(original_name, args)` (services ignored)
- The registry doesn't know or care about the origin — it just stores executable tools

### 2. ToolRegistry — immutable container

`ToolRegistry` is a frozen, sync, composable container of `ExecutableTool`s:

```python
class ToolRegistry:
    def __init__(self, tools: Sequence[ExecutableTool] = ()) -> None:
        # Validate no duplicate names — raise ValueError on duplicate
        # Build internal dict[str, ExecutableTool]
        ...

    # Querying
    def get_tools(self) -> list[ExecutableTool]: ...
    def get_tool_definition(self, name: str) -> ToolDefinition | None: ...
    def get_llm_tools(self) -> list[Tool]: ...

    # Iteration
    def __iter__(self) -> Iterator[ExecutableTool]: ...

    # Execution
    async def execute(
        self,
        name: str,
        args: dict[str, Any] | str | None = None,
        *,
        services: dict[type, Any] | None = None,
    ) -> ToolResult: ...

    # Builder for complex composition
    @classmethod
    def builder(cls) -> ToolRegistryBuilder: ...
```

Key properties:
- **Immutable** — no `add()`, everything passed in constructor
- **Sync creation** — no async, no I/O
- **No ownership** — does not own MCP connections, does not close anything
- **Iterable** — can iterate over tools for filtering/inspection
- **Duplicate handling** — error on duplicate names, always strict

### 3. ToolRegistryBuilder — convenience for complex composition

```python
class ToolRegistryBuilder:
    def add(
        self,
        source: ExecutableTool | ToolRegistry | Iterable[ExecutableTool],
        *,
        prefix: str | None = None,
        filter: Callable[[ExecutableTool], bool] | None = None,
    ) -> Self: ...

    def build(self) -> ToolRegistry: ...
```

Usage:

```python
registry = (
    ToolRegistry.builder()
    .add(respond_to_customer)
    .add(mcp_registry, filter=lambda t: t.definition.name not in excluded)
    .add(card_tools, prefix="cards")
    .build()
)
```

### 4. McpConnection.snapshot() → ToolRegistry

`McpConnection.snapshot()` returns a frozen `ToolRegistry` with tools from the current tool list. Each tool's executor closes over the connection reference and the original tool name.

```python
mcp_registry = conn.snapshot()  # ToolRegistry, sync, frozen
```

- Background refresh in `McpConnection` continues but does not affect already-taken snapshots
- If a tool is removed from the MCP server after snapshot, `call_tool()` returns an appropriate error
- If the connection is closed, executors return errors
- Next `conn.snapshot()` call returns a new registry with the updated tool list

### 5. ToolRegistry as configuration, not a service

`ToolRegistry` moves from `AgentRuntime` services to `ChatConfig` / `TurnConfig` as `ConfigValue[ToolRegistry]`:

```python
@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatConfig:
    tools: ConfigValue[ToolRegistry] = ToolRegistry()  # default: empty
    llm_config: ConfigValue[LLMConfig] = ...
    ...
```

This enables:

```python
# Static tools
config = ChatConfig(tools=registry, ...)

# Dynamic tools — fresh snapshot each LLM call
config = ChatConfig(tools=lambda: conn.snapshot(), ...)

# Async dynamic
config = ChatConfig(tools=async_get_registry, ...)
```

`TurnAgent` resolves `config.tools` via `resolve_config_value()` before each LLM call, alongside other config values it already resolves.

### 6. Removed concepts

- **`LocalToolGroup`** — replaced by `ToolRegistry` composition via builder with prefix
- **`McpToolGroup`** — replaced by explicit `McpConnection.connect()` + `snapshot()`
- **`ToolRegistry.create()`** — async factory no longer needed
- **`ToolRegistry.create_empty()`** — replaced by `ToolRegistry()` (default empty)
- **`on_tools_changed` subscription in ToolRegistry** — registry is frozen, consumer decides when to refresh
- **`ToolSource` type alias** — no longer needed

## Migration path

1. Add `ExecutableTool` type to `flowra/tools/`
2. Add `LocalTool` → `ExecutableTool` conversion
3. Redesign `ToolRegistry` as immutable container of `ExecutableTool`
4. Add `ToolRegistryBuilder` with prefix/filter support
5. Add `McpConnection.snapshot()` → `ToolRegistry`
6. Move `ToolRegistry` from service to `ConfigValue[ToolRegistry]` in `ChatConfig` / `TurnConfig`
7. Remove `LocalToolGroup`, `McpToolGroup`, `ToolRegistry.create()`, `on_tools_changed`
8. Update `TurnAgent` to resolve tools from config
9. Update all tests, examples, and docs
