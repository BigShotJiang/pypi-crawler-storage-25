# Flowra vs LangChain/LangGraph — Comparison

Research date: 2026-04-08

## Overview

LangChain is the established Python ecosystem for LLM applications, consisting of langchain-core, langgraph (agent framework), and LangSmith (commercial observability). Flowra is a pre-1.0 library with a fundamentally different design philosophy: minimal API surface, dependency injection, scoped state, and typed events.

## 1. LLM Abstraction

**LangChain** uses `BaseChatModel` with the Runnable interface (`ainvoke`, `batch`, `astream`, `astream_events`). Structured output via `with_structured_output()`. 100+ community-maintained provider packages.

**Flowra** uses `LLMProvider` with two methods: `call(LLMRequest) -> LLMResponse` and `stream(LLMRequest) -> AsyncIterator[StreamEvent]`. 6 built-in providers. Structured output via `json_schema` on `LLMRequest`. Streaming events are a typed union: `TextDelta | ThinkingDelta | ContentComplete`.

| Aspect            | LangChain                                              | Flowra                                                                                   |
|-------------------|--------------------------------------------------------|------------------------------------------------------------------------------------------|
| Provider count    | 100+ (community-maintained)                            | 6 built-in, tightly controlled                                                           |
| API surface       | Large (Runnable interface, LCEL)                       | Minimal (call + stream)                                                                  |
| Structured output | `with_structured_output()` method                      | `json_schema` field on request                                                           |
| Streaming model   | `AIMessageChunk` iterator + callbacks + astream_events | Typed `StreamEvent` union                                                                |
| Cost tracking     | Via LangSmith or manual                                | Built-in `Usage` with `cost_usd` on every response                                       |
| Provider extras   | Model-specific kwargs passed through                   | Namespaced `extra["anthropic"]`/`extra["openai"]`/`extra["google"]` with typed accessors |

**LangChain advantage:** Massive provider ecosystem; community covers niche models quickly.

**Flowra advantage:** Cleaner, more minimal API. Built-in cost estimation per response. Typed provider extras prevent cross-provider leakage. The streaming model is simpler (no callback handler hierarchy).

## 2. Tool System

**LangChain** uses `@tool` decorator on functions. Input schemas from Pydantic models or function signatures. MCP via separate `langchain-mcp-adapters` package. Error handling: `handle_tool_error=True` or custom handler.

**Flowra** uses `@tool` decorator with dataclass parameters. Immutable `ToolRegistry`. MCP built-in via `McpConnection`. First-class DI into tool handlers by type annotation. Typed `ToolErrorKind` (UNKNOWN_TOOL, SCHEMA_VALIDATION, EXECUTION). Agents as tools via `@agent_tool`. Tool filtering with fnmatch patterns.

| Aspect          | LangChain                                 | Flowra                                                        |
|-----------------|-------------------------------------------|---------------------------------------------------------------|
| Schema source   | Pydantic models or function type hints    | Dataclass parameters                                          |
| MCP support     | Separate `langchain-mcp-adapters` package | Built-in `McpConnection`                                      |
| DI into tools   | Not built-in; pass via closure or global  | First-class DI by type annotation                             |
| Error types     | Boolean `is_error` or custom handler      | Typed `ToolErrorKind` enum                                    |
| Tool search     | Not built-in at tool level                | Built-in Anthropic + OpenAI tool search with deferred loading |
| Agents-as-tools | Via manual wrapping                       | `@agent_tool` decorator                                       |
| Tool registry   | Mutable list                              | Immutable `ToolRegistry` with builder pattern and prefixes    |

**LangChain advantage:** Pydantic is more mainstream than dataclasses for schema definition; broader community familiarity.

**Flowra advantage:** Built-in DI into tool handlers (no closures or globals). Built-in MCP. Immutable registry prevents accidental mutation. Tool search (deferred loading) reduces token usage by ~85%.

## 3. Agent Framework

**LangGraph** uses a graph-based model. `StateGraph` with nodes (functions) and edges (transitions). State is a `TypedDict` or Pydantic model, shared across all nodes. Parallel execution via fan-out edges; fan-in via reducer functions. Persistence via checkpointers (Postgres, Redis, SQLite, in-memory). Human-in-the-loop via breakpoints.

**Flowra** uses class-based state machines. `Agent[Spec, Result]` with `@step` methods. Transitions via return types: `GotoStep`, `GotoAgent`, `Spawn`. Parallel execution via `Spawn` with `WhenAll`/`WhenAny`/`WhenN` combinators. State in typed slots (`Scalar[T]`, `AppendOnlyList[T]`) with scoped lifetimes (ephemeral, persistent, named). Cooperative interrupts with `InterruptToken`.

| Aspect               | LangGraph                                         | Flowra                                                    |
|----------------------|---------------------------------------------------|-----------------------------------------------------------|
| Model                | Directed graph (nodes + edges)                    | Class-based state machines                                |
| State definition     | TypedDict / Pydantic with reducers                | Typed slots (Scalar, AppendOnlyList) with scopes          |
| State sharing        | Global state dict, all nodes see everything       | Scoped: ephemeral, persistent, named                      |
| Parallel execution   | Fan-out via edges, superstep atomicity            | `Spawn` + `WhenAll`/`WhenAny`/`WhenN` combinators         |
| Transitions          | External: `add_edge()`, `add_conditional_edges()` | Inline: return `GotoStep` / `GotoAgent` from step methods |
| Persistence backends | Postgres, Redis, SQLite, in-memory                | File, in-memory                                           |
| Interrupts           | Breakpoints for human-in-the-loop                 | Cooperative `InterruptToken` with cascading               |
| DI                   | Not built-in (state dict is the mechanism)        | Constructor injection by type                             |
| Multi-agent          | Subgraphs                                         | `GotoAgent`, `CallAgent`, `Spawn`                         |

**LangGraph advantage:** More persistence backends. Visual tooling (LangGraph Studio). Broader adoption with more community examples. Human-in-the-loop is first-class.

**Flowra advantage:** State scoping prevents accidental leakage between agents. `WhenAny`/`WhenN` with automatic cancellation is more expressive. Transitions as return values are more natural in Python. DI is built into the framework. Cooperative interrupts with cascading are more sophisticated than breakpoints.

## 4. Observability

**LangChain** relies on LangSmith (commercial SaaS) as its primary platform. OpenTelemetry support added in 2025. Callback handlers (`on_llm_start`, `on_tool_start`, etc.) for hooks. MLflow integration via community packages.

**Flowra** uses a generic `HookSubscription` + `Hooks` + typed `Event[T]` system. Built-in MLflow and OpenTelemetry integrations. `FlowingVar` keeps tracing context in sync across async/parallel execution.

| Aspect              | LangChain                           | Flowra                                           |
|---------------------|-------------------------------------|--------------------------------------------------|
| Primary platform    | LangSmith (commercial)              | Bring-your-own (MLflow, OTel, custom)            |
| Hook mechanism      | Callback handlers (class-based)     | Typed event system                               |
| OTel support        | Via LangSmith SDK conversion        | Direct OTel spans with GenAI conventions         |
| MLflow support      | Via community / MLflow auto-tracing | Built-in module                                  |
| Context propagation | Via LangSmith or OTel context       | `FlowingVar` with `on_enter`/`on_exit` callbacks |

**LangChain advantage:** LangSmith is a polished platform with dashboards, evaluation, and dataset management.

**Flowra advantage:** No vendor lock-in. Typed event system is more flexible than callback handlers. `FlowingVar` elegantly handles tracing context across async boundaries.

## 5. Type Safety

| Aspect             | LangChain                            | Flowra                                           |
|--------------------|--------------------------------------|--------------------------------------------------|
| Validation library | Pydantic v2                          | Dataclasses + marshmallow                        |
| State types        | TypedDict / Pydantic                 | Generic typed slots                              |
| Agent generics     | Runnable[Input, Output]              | Agent[Spec, Result] with compile-time validation |
| Static analysis    | Improving but inconsistent with LCEL | pyright in CI, 0 errors enforced                 |

**LangChain advantage:** Pydantic is the industry standard with richer validation and better error messages.

**Flowra advantage:** Dataclasses are lighter-weight. `Agent[Spec, Result]` with compile-time validation (step result types ⊆ generic result types) provides stronger guarantees.

## 6. Developer Experience

| Aspect             | LangChain                                         | Flowra                                                     |
|--------------------|---------------------------------------------------|------------------------------------------------------------|
| Learning curve     | Steep (LCEL, Runnables, callbacks, many packages) | Moderate (Agent, step, tool patterns)                      |
| Boilerplate        | Higher (state definitions, edge wiring, reducers) | Lower (return types define transitions, DI handles wiring) |
| Community          | Very large                                        | Minimal (pre-1.0)                                          |
| Commercial tooling | LangSmith, LangGraph Platform                     | None                                                       |
| Debugging          | Complex (many abstraction layers)                 | Transparent (fewer layers)                                 |

**LangChain advantage:** Massive community, extensive tutorials, commercial support, visual tools.

**Flowra advantage:** Dramatically less boilerplate and fewer concepts. No expression language. DI removes manual wiring. Codebase is small enough to read entirely.

## Summary

| Category             | LangChain/LangGraph Edge                  | Flowra Edge                                                              |
|----------------------|-------------------------------------------|--------------------------------------------------------------------------|
| LLM Abstraction      | 100+ providers                            | Cleaner API, built-in cost tracking, typed streaming                     |
| Tool System          | Pydantic ecosystem                        | Built-in DI, MCP, tool search, immutable registry                        |
| Agent Framework      | More persistence backends, visual tooling | State scoping, WhenAny/WhenN, inline transitions, cooperative interrupts |
| Observability        | LangSmith platform                        | Vendor-agnostic, typed events, FlowingVar context                        |
| Type Safety          | Pydantic industry standard                | Lighter dataclasses, stronger agent generics, pyright CI                 |
| Developer Experience | Large community, commercial support       | Less boilerplate, fewer abstractions, more transparent                   |

## Bottom Line

LangChain/LangGraph is the established ecosystem with massive community support and commercial tooling. Its weaknesses — complexity, over-abstraction, vendor coupling to LangSmith — are well-documented.

Flowra takes a fundamentally different approach: minimal API, DI as first-class, scoped state with explicit lifetimes, typed events. The cooperative interrupt system, tool search with deferred loading, and `WhenAny`/`WhenN` combinators have no direct equivalents in LangGraph.

The main risk with flowra is pre-1.0 maturity and tiny community. The main risk with LangChain is accumulating complexity that pushes developers toward direct API calls.
