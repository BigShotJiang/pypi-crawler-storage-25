# Named Scopes — Shared Agent Storage

Research date: 2026-04-02
Status: All phases implemented

## Problem

Agents in Flowra can only store persistent state in their own scope — a single
namespace tied to the node's `storage_key`. There is no mechanism for agents to
access shared, cross-agent persistent storage.

### What works today

Each agent declares slots via `AgentStore`:

```python
class ChatAgent(Agent[ChatSpec, ChatResult]):
    def __init__(self, store: AgentStore):
        self.history = store.slot(AppendOnlyList[Message], "history")
```

All slots live in the agent's scope, identified by `storage_key`. The key is
set by the caller:

```python
CallAgent(agent=ChatAgent, spec=spec, storage_key="chat")
```

### What doesn't work

1. **No shared storage.** If `AnalysisAgent` and `SummaryAgent` both need access
   to a session-level chat log, there's no way to give them a shared persistent
   slot. The only workaround is passing a plain Python object through DI — but it
   isn't persisted, isn't dirty-tracked, and isn't restored on crash recovery.

2. **storage_key controls the entire scope.** An agent can't have some slots in
   its local scope and other slots in a shared scope. It's all-or-nothing.

3. **storage_key leaks implementation details.** The caller must know the right
   key to pass. This is an implementation detail of the child agent that shouldn't
   leak upward.

### Motivating use cases

- **Shared session log.** Multiple agents (chatbot, watchdog, auditor) read/write
  the same conversation history.
- **Reusable agents.** A general-purpose `ChatAgent` needs "a place to store chat".
  The caller decides where that place is — by hierarchy position, by explicit key,
  or shared with other agents. The agent itself shouldn't care.
- **Cross-agent coordination.** A parent orchestrator creates a shared resource
  (e.g., accumulated results), children write to it, parent reads the aggregated
  state.


## Proposed design

### Core idea: `store.scope(name)`

`AgentStore` gains a new method — `scope(name)` — that returns a handle to a
named scope. The handle has the same `slot()` API:

```python
class AgentStore(abc.ABC):
    # Existing — slot in agent's own (local) scope
    def slot(self, cls, key: str) -> Scalar[T] | AppendOnlyList[T]: ...

    # New — access a named scope
    def scope(self, name: str) -> Scope: ...

class Scope:
    def slot(self, cls, key: str) -> Scalar[T] | AppendOnlyList[T]: ...
```

Usage:

```python
class OrchestratorAgent(Agent[Spec, Result]):
    def __init__(self, store: AgentStore, services: ServiceLocator):
        # Local slot — lives in my agent scope (same as today)
        self.mode = store.slot(Scalar[str], "mode")

        # Shared slot — lives in the "session" named scope
        session = store.scope("session")
        self.history = session.slot(AppendOnlyList[Message], "history")

        # Can pass the slot object to children via DI
        services.provide(self.history)
```

Children can receive slots via DI (already hydrated):

```python
class ChatAgent(Agent[ChatSpec, ChatResult]):
    def __init__(self, history: AppendOnlyList[Message]):
        self.__history = history  # injected, already hydrated
```

Or access the same named scope independently:

```python
class WatchdogAgent(Agent[Spec, Result]):
    def __init__(self, store: AgentStore):
        session = store.scope("session")
        # Same scope + same key + same type → same slot instance
        self.history = session.slot(AppendOnlyList[Message], "history")
```

### Slot identity

A slot is uniquely identified by `(scope_name, slot_key)`. If two agents
call `store.scope("session").slot(AppendOnlyList[Message], "history")`, they
get the **same slot instance**.

If a second call uses a different container type for the same `(scope, key)`,
it's a runtime error.

### Persistence

Named scopes are persisted independently, using the scope name as the storage
key. At each step boundary, the runtime collects dirty changes from ALL scopes
(both agent-local and named):

```
for each scope (local + named):
    changes = scope.get_changes()
    if not changes.empty:
        storage.save_node_state(scope.storage_key, changes)
    scope.mark_clean()
```

### Hydration

Hydration follows the natural top-down tree construction order:

1. Parent agent is constructed — its `__init__` calls `store.scope("session").slot(...)`
2. Named scope "session" is loaded from storage, slots are hydrated
3. Parent provides slot objects to children via DI/services
4. Children receive already-hydrated slot instances
5. If a child independently accesses `store.scope("session")`, it gets the same
   (already hydrated) scope instance

No special hydration ordering is needed — the tree construction order guarantees
parents are hydrated before children exist.

### Relationship with storage_key

`storage_key` on `CallAgent`/`GotoStep` continues to control the **agent-local
scope** — where `store.slot(...)` (without `.scope()`) writes. Named scopes are
orthogonal — they exist regardless of how the agent's local scope is configured.

This means an agent can have:
- Local slots in its own scope (controlled by `storage_key`)
- Shared slots in any number of named scopes

### FORK semantics

When a scope is forked (via `storage_key=FORK`):
- **Local slots** are copied (current behavior)
- **Named scope slots** are NOT copied — they remain shared. A fork creates an
  isolated local scope but doesn't duplicate shared resources.

### Concurrent writes

With parallel `Spawn`, two children might write to the same named scope
concurrently. For `AppendOnlyList`, this is safe — appends commute. For
`Scalar`, last-write-wins. This matches the semantics of shared mutable state.
If stronger guarantees are needed, the user should coordinate via the agent
protocol (e.g., only one writer at a time, or only write from the parent after
collecting child results).


## Design decisions

1. **Scope lifecycle.** No reset/clear mechanism for now. Named scopes persist
   across `runtime.run()` calls, same as agent-local scopes.

2. **Scope discovery.** Lazy. The runtime discovers named scopes as agents
   create them during construction. No upfront declaration required.

3. **Type registry for named scopes.** Per-scope, built automatically from
   `slot()` declarations via `collect_dataclass_types`. Each named scope's
   `RuntimeScope` has its own `type_registry` dict. Types are registered
   when agents call `slot()` during construction.

4. **Scope naming collisions with storage_key.** Resolved: named scopes use
   their name directly as storage key (e.g., `"session"`). Agent-local scopes
   use `"__node__:"` prefix (e.g., `"__node__:root"`). No collisions possible.

5. **Transactional consistency.** The existing model is sufficient: open
   transaction → save all dirty scopes (local + named) → close transaction.
   File-based storage has no real guarantees, but real deployments will use
   a database with proper transactions.


## Implementation plan

### Phase 1: Named scope registry + persistence ✓

Implemented. See commit `feat/named-scopes`.

- `Scope` ABC extracted from `AgentStore` with `slot()` method
- `AgentStore.scope(name) -> Scope` added
- `NamedScopeRegistry` in `scope.py` — session-wide, lazy creation, hydration tracking
- `RuntimeScope.scope(name)` delegates to shared registry
- `AgentRuntime` creates registry, hydrates/persists named scopes at step boundaries
- Named scopes: clean storage keys; agent-local: `__node__:` prefix
- Per-scope type registry built from `slot()` calls
- 23 new tests

### Phase 2: Update built-in agents ✓

Implemented. `ChatAgent` uses `store.persistent` for history. The parent
controls where persistent scope points via the `state` parameter on `CallAgent`
or `runtime.run()`. To share history across agents, use
`state=persistent.NAMED("session")`.

### Phase 3: Unified scope model (design in progress)

Redesign `storage_key` into a unified scope model where everything is a scope.

#### Current problems with storage_key

`storage_key` on `CallAgent` is overloaded: `None`, `NEW_SCOPE`, `FORK`, or a
string. The semantics differ between `CallAgent`, `CallStep`, `GotoStep`, and
`GotoAgent` in non-obvious ways. `store.slot(...)` doesn't say anything about
the slot's lifetime — it's all controlled externally.

#### Proposed model: everything is a scope

No more bare `store.slot(...)`. All slots go through an explicit scope:

```python
class CalcAgent(Agent[Spec, Result]):
    def __init__(self, store: AgentStore):
        self.temp = store.ephemeral.slot(Scalar[str], "temp")
        self.history = store.persistent.slot(AppendOnlyList[str], "history")
        self.shared = store["session"].slot(AppendOnlyList[str], "log")
```

Three scope types:

| Scope | Lifetime | Key controlled by | Storage key |
|-------|----------|-------------------|-------------|
| `store.ephemeral` | One run | Engine (node_id) | Auto-generated, not reused |
| `store.persistent` | Across runs | Parent at call site | Default = agent registry name |
| `store["name"]` | Across runs | Agent itself | The name directly |

#### CallStep vs CallAgent — two fundamentally different operations

**CallStep** — step within the same agent. Works on the same state:

- Ephemeral: shared with parent (default), or forked (`fork_ephemeral=True`)
- Persistent: always shared (same agent, same persistent scope)
- Named scopes: always shared

```python
# Default — same state, no isolation
Spawn(children=[CallStep(step=self.process)])

# Fork — isolated copy of ephemeral, persistent stays shared
Spawn(children=[CallStep(step=self.process, fork_ephemeral=True)])
```

No `persistent` parameter on CallStep. No need to declare anything. Fork
only copies ephemeral state — persistent and named are shared by definition.

**CallAgent** — different agent. Parent controls the child's persistent scope
via the `state` parameter and `persistent.*` markers:

```python
from flowra.agent import persistent

# Default — persistent key = agent registry name ("calc"), exclusive
CallAgent(agent=CalcAgent)

# Explicit key — persistent under this key, exclusive
CallAgent(agent=CalcAgent, state="user-123-calc")

# Ephemeral — fresh scope, no persistence
CallAgent(agent=CalcAgent, state=persistent.EPHEMERAL)

# Shared — requires @shared_persistent on agent
CallAgent(agent=WorkerAgent, state=persistent.SHARED)          # shared, default key
CallAgent(agent=WorkerAgent, state=persistent.SHARED("pool"))  # shared, explicit key

# Named — redirect persistent to a named scope
CallAgent(agent=AnalysisAgent, state=persistent.NAMED("session"))
```

`persistent.NAMED("session")` is powerful for reusable agents: the agent writes
to `store.persistent`, but parent redirects it to a shared named scope. The
agent doesn't know the difference.

Markers follow the same convention as `step_arg.CHILD` / `step_arg.CHILD("tag")`
— UPPER_CASE, callable with optional parameter.

#### Persistent scope: default key

Default persistent key = agent's full name in the registry. Agent registered as
`"calc"` → `store.persistent` uses key `"calc"`.

#### Exclusive vs shared persistent ✓

By default, persistent scopes are **exclusive** — two concurrent nodes with the
same persistent key cause a `DuplicateStorageKey` error. This catches accidental
collisions.

For agents that support concurrent access (e.g., self-spawn), the agent
declares `@shared_persistent`:

```python
@shared_persistent
class WorkerAgent(Agent[Spec, Result]):
    ...

# OK — decorator allows shared persistent key
CallAgent(agent=WorkerAgent)
CallAgent(agent=WorkerAgent)

# Error — no decorator, duplicate key
CallAgent(agent=CalcAgent)
CallAgent(agent=CalcAgent)  # DuplicateStorageKey error
```

The decorator alone is sufficient — no caller-side marker needed.
`persistent.NAMED` bypasses the exclusive check inherently (named scopes are
shared by definition).
