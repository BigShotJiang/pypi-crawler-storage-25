# E2E Tests Security for Public Repository — Research

Research date: 2026-03-27
Status: decided

## Problem

The `pull_request_e2e.yml` workflow uses `pull_request_target`, which runs in the
context of the base branch (master) and has access to secrets. Combined with
`checkout ref: pull_request.head.sha`, this means untrusted PR code executes
with access to secrets (API keys for OpenAI, Vertex, etc.).

Current mitigation: the workflow only runs for OWNER/MEMBER/COLLABORATOR or when
the `e2e` label is added. This is partial protection — if a maintainer adds the
label to a malicious PR without carefully reviewing all code, secrets can be
exfiltrated.

## Options Considered

### 1. Keep `pull_request_target` with label gating (current)

- Pros: simple, automatic
- Cons: human error can leak secrets; `pull_request_target` + checkout of PR code
  is a known attack vector

### 2. Two-repo approach with `repository_dispatch`

Public repo sends a dispatch event to a private repo (anna-flowra) which runs
the actual e2e tests with secrets.

- Pros: secrets only in private repo
- Cons: requires a PAT or GitHub App token in the public repo. A stolen PAT
  (even fine-grained with `actions: write`) can trigger workflows in the private
  repo, indirectly accessing secrets. GitHub App is safer (short-lived tokens)
  but more complex to set up.

### 3. Two-repo approach with manual `workflow_dispatch` only

Private repo (anna-flowra) has a `workflow_dispatch` workflow that accepts a
flowra ref as input. Triggered manually via `gh workflow run` or GitHub UI.
No automatic triggers, no labels, no PAT in public repo.

- Pros: zero attack surface in the public repo — no secrets at all, no automatic
  triggers. Simple to understand and audit.
- Cons: manual step required before merging PRs that need e2e validation.

## Decision

**Option 3 — manual `workflow_dispatch` in anna-flowra, no automation.**

Rationale:
- E2e tests are not needed on every PR — they run selectively anyway.
- Manual trigger is a small overhead vs. the security benefit of having
  zero secrets in the public repository.
- The `gh workflow run` command makes it easy enough from the command line.

## Implementation Plan

### In flowra (public repo)

1. Delete `.github/workflows/pull_request_e2e.yml`
2. Move e2e tests from `tests/` to anna-flowra (or keep them here but only
   run them from anna-flowra's workflow)

### In anna-flowra (private repo)

Add a workflow:

```yaml
name: flowra-e2e

on:
  workflow_dispatch:
    inputs:
      ref:
        description: 'flowra ref (branch, tag, or SHA)'
        required: true
        default: 'master'

jobs:
  test_e2e:
    runs-on: ${{ matrix.os }}
    timeout-minutes: 15
    strategy:
      fail-fast: false
      matrix:
        os: [ubuntu-latest, macos-latest]
        python: ["3.12", "3.13", "3.14"]
    env:
      OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
      OPENAI_ORGANIZATION: ${{ secrets.OPENAI_ORGANIZATION }}
      OPENAI_BASE_URL: ${{ vars.OPENAI_BASE_URL }}
      VERTEX_PROJECT_NAME: ${{ vars.VERTEX_PROJECT_NAME }}
      VERTEX_LOCATION: ${{ vars.VERTEX_LOCATION }}
      VERTEX_CREDENTIALS: ${{ secrets.VERTEX_CREDENTIALS }}
    steps:
      - name: Checkout anna-flowra
        uses: actions/checkout@v6

      - name: Checkout flowra
        uses: actions/checkout@v6
        with:
          repository: <owner>/flowra
          ref: ${{ inputs.ref }}
          path: flowra

      - name: Set up uv
        uses: astral-sh/setup-uv@v7

      - name: Set up Python
        run: echo ${{ matrix.python }} > flowra/.python-version

      - name: Install deps
        working-directory: flowra
        run: MODE=ci make deps

      - name: Run e2e tests
        working-directory: flowra
        run: MODE=ci make test-e2e
```

### Usage

```bash
# Run e2e for a specific PR branch
gh workflow run flowra-e2e.yml -R <owner>/anna-flowra -f ref=feature-branch

# Run e2e for a specific commit
gh workflow run flowra-e2e.yml -R <owner>/anna-flowra -f ref=abc1234

# Run e2e for master
gh workflow run flowra-e2e.yml -R <owner>/anna-flowra
```
