# Agent Tool Error Handling — Research

Research date: 2026-04-06
Resolved: 2026-04-07

## Problem

Agent tools (`@agent_tool`) currently cannot return error results to the LLM. When `ToolCallAgent.collect_agent_result` receives the agent's result, it always serializes it as a successful `ToolResultBlock(is_error=False)`.

For regular tools (`@tool`), errors are straightforward — the handler returns `ToolResult(content=..., is_error=True)` or raises an exception (caught by `ToolCallAgent.execute`).

But agent tools return a typed dataclass result, and there's no way to signal "this is an error result that the LLM should see as a tool error."

### Real-world scenario

`respond_to_customer` is an agent-tool that includes a grounding validation step. If grounding fails, the agent needs to return an error to the LLM so it can adjust its response and retry. Currently, there's no way to do this — the agent can only return its `Result` type or raise an exception.

## Decision

**Agent tool returns `ToolResult` directly when it wants to signal an error.**

An agent tool is a tool implemented as an agent (not an agent that happens to be used as a tool). Since it's fundamentally a tool, it speaks the tool's language — `ToolResult`.

- Happy path: return typed dataclass result as before
- Error path: return `ToolResult(content="...", is_error=True)`
- `collect_agent_result` does an `isinstance` check: if `ToolResult` — use as-is, otherwise serialize via `mr.dump`

### Why not exceptions?

Raising an exception from inside an agent would crash it — the agent's tool loop would be interrupted, state lost. But the agent completed its work normally; it just decided the result is an error for the parent LLM. This is a normal return, not an exceptional situation.

### Why not a convention-based field?

Adding `is_error: bool` to every result dataclass pollutes the domain type with tool-loop semantics.

### Why not a new type like `AgentToolError`?

Unnecessary — `ToolResult` already exists and carries exactly the right semantics.

## Implementation

In `ToolCallAgent.collect_agent_result`:

```python
if isinstance(agent_result, ToolResult):
    result = ToolResultBlock(
        tool_use_id=tool_use.id,
        content=agent_result.content,
        is_error=agent_result.is_error,
    )
    error_kind = agent_result.error_kind
else:
    content = json.dumps(mr.dump(agent_result))
    result = ToolResultBlock(
        tool_use_id=tool_use.id,
        content=content,
    )
    error_kind = None
```

### Usage example

Include `ToolResult` in the Agent's result type parameter so it participates in
type registry and serialization:

```python
class GroundingAgent(Agent[Params, Result | ToolResult]):
    """Check grounding and respond."""

    @step(entry=True)
    async def run(self, spec: Annotated[Params, step_arg.SPEC]) -> Result | ToolResult:
        if not grounded:
            return ToolResult(content="Response is not grounded. Please use tools first.", is_error=True)
        return Result(status="ok")
```
