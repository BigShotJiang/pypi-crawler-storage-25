import dataclasses
import enum
from typing import Any

from ...llm import AssistantMessage, StopReason, TextBlock, Usage, UserMessage

__all__ = ["TurnResult", "TurnSpec", "TurnStatus"]


class TurnStatus(enum.StrEnum):
    COMPLETED = "completed"
    MAX_LLM_CALLS = "max_llm_calls"
    INTERRUPTED = "interrupted"
    FINISH_REQUESTED = "finish_requested"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class TurnSpec:
    messages: list[UserMessage]
    metadata: dict[str, Any] | None = None

    @classmethod
    def text(cls, text: str, *, metadata: dict[str, Any] | None = None) -> "TurnSpec":
        return cls(messages=[UserMessage.text(text)], metadata=metadata)

    def __preview__(self) -> str:
        texts = [b.text for m in self.messages for b in m.blocks if isinstance(b, TextBlock)]
        return " ".join(texts) if texts else "(no text)"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class TurnResult:
    messages: list[UserMessage | AssistantMessage]
    status: TurnStatus
    stop_reason: StopReason | None = None
    result_message: AssistantMessage | None = None
    usage: Usage | None = None

    def __preview__(self) -> str:
        if self.result_message is None:
            return self.status
        texts = [b.text for b in self.result_message.blocks if isinstance(b, TextBlock)]
        return "\n".join(texts) if texts else self.status
