"""LLM observability events — spans and streaming deltas."""

import dataclasses

from ...llm import LLMRequest, LLMResponse, ToolResultBlock, ToolUseBlock, Usage
from ...tools import ToolErrorKind

__all__ = [
    "LLMCallSpan",
    "TextDeltaEvent",
    "ThinkingDeltaEvent",
    "ToolCallSpan",
    "UsageEvent",
]


# -- Span types (span-hooks: guaranteed enter/exit) --


# Mutable: request set at open, response set before close.
@dataclasses.dataclass(slots=True, kw_only=True)
class LLMCallSpan:
    request: LLMRequest
    response: LLMResponse | None = None


# Mutable: tool_use set at open, result set before close.
@dataclasses.dataclass(slots=True, kw_only=True)
class ToolCallSpan:
    tool_use: ToolUseBlock
    result: ToolResultBlock | None = None
    error_kind: ToolErrorKind | None = None


# -- Streaming events (regular hooks: observation-only) --


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class TextDeltaEvent:
    """Emitted during streaming for each text chunk.

    Observation-only — use for real-time text display.
    Registering a handler enables streaming mode automatically.
    """

    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ThinkingDeltaEvent:
    """Emitted during streaming for each thinking chunk.

    Observation-only — use for real-time thinking display.
    Registering a handler enables streaming mode automatically.
    """

    text: str


# -- Usage tracking --


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class UsageEvent:
    """Emitted after each LLM call with the usage from that call.

    Subscribe to accumulate usage across all descendants — including
    sub-agents invoked as tools.

    Built-in agents (TurnAgent, LLMCallAgent) emit this automatically.
    Custom agents that call LLM providers directly should emit it too.
    """

    usage: Usage
