from typing import ClassVar

from ...agent import (
    Agent,
    AgentDefinitionRef,
    AgentStore,
    AppendOnlyList,
    CallAgent,
    Event,
    Hooks,
    InterruptToken,
    ServiceLocator,
    Spawn,
    step,
)
from ...llm import AssistantMessage, TextBlock, UserMessage
from ..turn import TurnAgent, TurnConfig, TurnReadyEvent, TurnResult, TurnSpec
from .config import ChatConfig
from .conversation import Conversation
from .hook_events import ConversationReadyEvent, SaveHistoryEvent
from .spec import ChatResult, ChatSpec

__all__ = ["ChatAgent"]


class ChatAgent(Agent[ChatSpec, ChatResult]):
    __slots__ = ("__config", "__history", "__hooks", "__interrupt")
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
        "turn": TurnAgent,
    }

    def __init__(
        self,
        store: AgentStore,
        services: ServiceLocator,
        config: ChatConfig,
        hooks: Hooks,
        interrupt: InterruptToken,
    ) -> None:
        self.__interrupt = interrupt
        if config.history is None:
            self.__history = store.persistent.slot(AppendOnlyList[UserMessage | AssistantMessage], "history")
        elif callable(config.history):
            self.__history = config.history(store)
        else:
            self.__history = config.history
        self.__config = config
        self.__hooks = hooks
        hooks.on(TurnReadyEvent, self.__on_turn_ready, scope=TurnAgent)
        services.provide(
            TurnConfig(
                llm_config=config.llm_config,
                system=config.system,
                tools=config.tools,
                history=self.__history.get_all,
                json_schema=config.json_schema,
                allowed_tools=config.allowed_tools,
                denied_tools=config.denied_tools,
                max_llm_calls=config.max_llm_calls,
                max_consecutive_errors=config.max_consecutive_errors,
            ),
        )

    @step("process_message", entry=True)
    async def process_message(self, spec: ChatSpec) -> Spawn:
        return Spawn(
            children=[
                CallAgent(
                    agent=TurnAgent,
                    spec=TurnSpec(messages=spec.messages, metadata=spec.metadata),
                ),
            ],
            then=self.collect_result,
        )

    @step("collect_result")
    async def collect_result(self, result: TurnResult) -> ChatResult:
        messages = list(result.messages)
        event = await self.__hooks.emit(SaveHistoryEvent(messages=messages))
        self.__history.extend(m for m in event.messages if not m.transient)

        self.__interrupt.check()

        response: str | None = None
        if result.result_message is not None:
            texts = [block.text for block in result.result_message.blocks if isinstance(block, TextBlock)]
            if texts:
                response = "\n".join(texts)

        return ChatResult(response=response, usage=result.usage)

    async def __on_turn_ready(self, event: Event[TurnReadyEvent]) -> None:
        conversation = Conversation(self.__history, event.data.turn_messages)
        await self.__hooks.emit(ConversationReadyEvent(conversation=conversation, context=event.data.context))
