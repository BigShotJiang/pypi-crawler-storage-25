import dataclasses
from collections.abc import Callable
from typing import Any

from ...agent import AgentStore, AppendOnlyList
from ...llm import AssistantMessage, SystemMessage, UserMessage
from ...tools import ToolRegistry
from ..config_value import ConfigValue
from ..llm_config import LLMConfig

__all__ = ["ChatConfig", "HistorySlot"]

type HistorySlot = (
    AppendOnlyList[UserMessage | AssistantMessage]
    | Callable[[AgentStore], AppendOnlyList[UserMessage | AssistantMessage]]
)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatConfig:
    """Configuration for ChatAgent.

    ChatAgent uses this to build a TurnConfig for each turn,
    injecting conversation history.

    Data providers accept ConfigValue[T] — a plain value, sync callable, or async callable.

    ``history`` controls where conversation history is stored:

    - ``None`` (default) — ``store.persistent.slot(AppendOnlyList, "history")``
    - A callable ``(AgentStore) -> AppendOnlyList`` — factory called with the store
    - An ``AppendOnlyList`` instance — used directly (e.g. a pre-created slot)
    """

    llm_config: ConfigValue[LLMConfig]
    system: ConfigValue[list[SystemMessage]]
    tools: ConfigValue[ToolRegistry | None] = None
    history: HistorySlot | None = None
    json_schema: ConfigValue[dict[str, Any] | None] = None
    max_llm_calls: ConfigValue[int] = 10
    allowed_tools: ConfigValue[set[str] | None] = None
    denied_tools: ConfigValue[set[str] | None] = None
    max_consecutive_errors: ConfigValue[int | None] = None
