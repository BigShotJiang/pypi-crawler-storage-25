from collections.abc import Iterator, Sequence
from typing import overload

from ...agent.state import AppendOnlyList
from ...llm import AssistantMessage, UserMessage

__all__ = ["Conversation"]

type _Message = UserMessage | AssistantMessage


class Conversation(Sequence[_Message]):
    """Read-only combined view over history + current turn messages.

    Efficiently supports forward iteration, reverse iteration, indexing,
    slicing, and length — all without copying (except slices).
    """

    __slots__ = ("__history", "__turn_messages")

    def __init__(
        self,
        history: AppendOnlyList[_Message],
        turn_messages: AppendOnlyList[_Message],
    ) -> None:
        self.__history = history
        self.__turn_messages = turn_messages

    def __len__(self) -> int:
        return len(self.__history) + len(self.__turn_messages)

    @overload
    def __getitem__(self, index: int) -> _Message: ...
    @overload
    def __getitem__(self, index: slice) -> list[_Message]: ...
    def __getitem__(self, index: int | slice) -> _Message | list[_Message]:
        if isinstance(index, slice):
            return list(self)[index]
        h_len = len(self.__history)
        if index < 0:
            index += len(self)
        if index < 0 or index >= len(self):
            raise IndexError(index)
        if index < h_len:
            return self.__history[index]
        return self.__turn_messages[index - h_len]

    def __iter__(self) -> Iterator[_Message]:
        yield from self.__history.get_all()
        yield from self.__turn_messages.get_all()

    def __reversed__(self) -> Iterator[_Message]:
        for i in range(len(self.__turn_messages) - 1, -1, -1):
            yield self.__turn_messages[i]
        for i in range(len(self.__history) - 1, -1, -1):
            yield self.__history[i]

    @property
    def history_len(self) -> int:
        return len(self.__history)

    @property
    def turn_len(self) -> int:
        return len(self.__turn_messages)
