# Mutable events (NOT frozen): handlers can mutate fields to communicate
# outcomes back to the agent. Observation-only events are frozen.

import dataclasses

from ...llm import AssistantMessage, UserMessage
from ..turn.context import TurnAgentContext
from .conversation import Conversation

__all__ = [
    "ConversationReadyEvent",
    "SaveHistoryEvent",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ConversationReadyEvent:
    """Emitted when the conversation view is ready (after ``TurnReadyEvent``).

    Fires on both creation and crash recovery. The ``conversation`` provides
    a read-only combined view over history + current turn messages.
    """

    conversation: Conversation
    context: TurnAgentContext


@dataclasses.dataclass(slots=True, kw_only=True)
class SaveHistoryEvent:
    """Emitted before messages are saved to conversation history.

    Replace ``messages`` to control what gets persisted — e.g. filter out
    transient messages injected by hooks.
    """

    messages: list[UserMessage | AssistantMessage]
