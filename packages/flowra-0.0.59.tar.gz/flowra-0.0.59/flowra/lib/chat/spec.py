import dataclasses
from typing import Any

from ...llm import TextBlock, Usage, UserMessage

__all__ = ["ChatResult", "ChatSpec"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatSpec:
    messages: list[UserMessage]
    metadata: dict[str, Any] | None = None

    @classmethod
    def text(cls, text: str, *, metadata: dict[str, Any] | None = None) -> "ChatSpec":
        return cls(messages=[UserMessage.text(text)], metadata=metadata)

    def __preview__(self) -> str:
        texts = [b.text for m in self.messages for b in m.blocks if isinstance(b, TextBlock)]
        return " ".join(texts) if texts else "(no text)"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatResult:
    response: str | None = None
    usage: Usage | None = None

    def __preview__(self) -> str:
        return self.response or ""
