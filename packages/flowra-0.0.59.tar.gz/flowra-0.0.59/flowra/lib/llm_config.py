import dataclasses
from collections.abc import Sequence
from typing import Any

from ..llm import LLMProvider, RequestExtension

__all__ = ["LLMConfig"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LLMConfig:
    provider: LLMProvider
    model: str
    temperature: float | None = None
    top_p: float | None = None
    max_tokens: int | None = None
    stop_sequences: list[str] | None = None
    extra: dict[str, Any] = dataclasses.field(default_factory=dict)
    request_extensions: Sequence[RequestExtension] = ()
