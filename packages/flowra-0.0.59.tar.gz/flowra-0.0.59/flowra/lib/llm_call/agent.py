import logging
import time

from ...agent import Agent, Hooks, InterruptedError, InterruptToken, step, with_interrupt
from ...llm import ContentComplete, LLMRequest, TextDelta, ThinkingDelta
from ..config_value import resolve_config_value
from ..observability import LLMCallSpan, TextDeltaEvent, ThinkingDeltaEvent, UsageEvent
from .config import LLMCallConfig
from .spec import LLMCallResult, LLMCallSpec

__all__ = ["LLMCallAgent"]

logger = logging.getLogger(__name__)


class LLMCallAgent(Agent[LLMCallSpec, LLMCallResult]):
    __slots__ = ("__config", "__hooks", "__interrupt")

    def __init__(
        self,
        interrupt: InterruptToken,
        hooks: Hooks,
        config: LLMCallConfig,
    ) -> None:
        self.__interrupt = interrupt
        self.__hooks = hooks
        self.__config = config

    @step(entry=True)
    async def call(self, spec: LLMCallSpec) -> LLMCallResult:
        self.__interrupt.check()

        llm_config = await resolve_config_value(self.__config.llm_config)
        system_messages = await resolve_config_value(self.__config.system)

        registry = await resolve_config_value(self.__config.tools)
        tools = registry.get_llm_tools() if registry is not None else []

        json_schema = await resolve_config_value(self.__config.json_schema)

        request = LLMRequest(
            model=llm_config.model,
            system=[m for m in system_messages if m.blocks],
            messages=list(spec.messages),
            tools=tools,
            json_schema=json_schema,
            temperature=llm_config.temperature,
            top_p=llm_config.top_p,
            max_tokens=llm_config.max_tokens,
            stop_sequences=llm_config.stop_sequences,
            extra=llm_config.extra,
        )

        for ext in llm_config.request_extensions:
            ext(request)

        t0 = time.monotonic()
        try:
            async with self.__hooks.span(LLMCallSpan(request=request)) as llm_span:
                if self.__hooks.has_handlers(TextDeltaEvent) or self.__hooks.has_handlers(ThinkingDeltaEvent):
                    response = None
                    async for event in with_interrupt(llm_config.provider.stream(request), self.__interrupt):
                        match event:
                            case TextDelta(text=text):
                                await self.__hooks.emit(TextDeltaEvent(text=text))
                            case ThinkingDelta(text=text):
                                await self.__hooks.emit(ThinkingDeltaEvent(text=text))
                            case ContentComplete(response=resp):
                                response = resp
                    assert response is not None
                else:
                    response = await llm_config.provider.call(request)
                llm_span.response = response
        except InterruptedError:
            raise
        except Exception as e:
            logger.exception("LLM call failed")
            elapsed = time.monotonic() - t0
            return LLMCallResult(error=f"LLM call failed: {e}", elapsed=elapsed)
        elapsed = time.monotonic() - t0

        if response.usage is not None:
            await self.__hooks.emit(UsageEvent(usage=response.usage))

        return LLMCallResult(message=response.message, usage=response.usage, elapsed=elapsed)
