import dataclasses
from typing import Any

from ...llm import SystemMessage
from ...tools import ToolRegistry
from ..config_value import ConfigValue
from ..llm_config import LLMConfig

__all__ = ["LLMCallConfig"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LLMCallConfig:
    """Configuration for LLMCallAgent.

    Data providers accept ConfigValue[T] — a plain value, sync callable, or async callable.
    """

    llm_config: ConfigValue[LLMConfig]
    system: ConfigValue[list[SystemMessage]] = dataclasses.field(default_factory=list)
    tools: ConfigValue[ToolRegistry | None] = None
    json_schema: ConfigValue[dict[str, Any] | None] = None
