import dataclasses
import enum
from typing import Any, Protocol, Self

__all__ = ["ExecutableTool", "ToolDefinition", "ToolErrorKind", "ToolExecutor", "ToolResult"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolDefinition:
    name: str
    description: str
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None


class ToolErrorKind(enum.StrEnum):
    UNKNOWN_TOOL = "unknown_tool"
    SCHEMA_VALIDATION = "schema_validation"
    EXECUTION = "execution"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolResult:
    content: str
    is_error: bool = False
    error_kind: ToolErrorKind | None = None


class ToolExecutor(Protocol):
    async def __call__(self, args: dict[str, Any], services: dict[type, Any]) -> ToolResult: ...


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ExecutableTool:
    definition: ToolDefinition
    executor: ToolExecutor

    def with_name(self, name: str) -> Self:
        return dataclasses.replace(self, definition=dataclasses.replace(self.definition, name=name))
