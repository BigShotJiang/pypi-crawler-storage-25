import base64
import dataclasses
import datetime
import decimal
import json
import uuid
from typing import Any

import marshmallow_recipe as mr

__all__ = ["format_result"]


def format_result(result: Any) -> str:
    """Serialize a tool/agent result value to a string for a ToolResult/ToolResultBlock content.

    Recursively normalizes dataclasses via ``mr.dump`` and stdlib scalars (``UUID``,
    ``Decimal``, ``datetime``, ``date``, ``time``, ``bytes``) to JSON-friendly values,
    then serializes the result. Datetimes use ISO format (``T`` separator) consistently
    whether at the top level or nested inside a list/dict. ``bytes`` are base64-encoded
    (matching the checkpoint serializer).

    - Dataclass → ``mr.dump`` (recursively normalized JSON).
    - ``dict`` / ``list`` → recursively normalized, then ``json.dumps``.
    - Stdlib scalars → canonical string form directly.
    - Everything else → ``str(result)``.
    """
    if _is_dataclass_instance(result):
        return json.dumps(_normalize(result))
    if isinstance(result, (dict, list)):
        return json.dumps(_normalize(result))
    if isinstance(result, (datetime.datetime, datetime.date, datetime.time)):
        return result.isoformat()
    if isinstance(result, (uuid.UUID, decimal.Decimal)):
        return str(result)
    if isinstance(result, bytes):
        return base64.b64encode(result).decode("ascii")
    return str(result)


def _normalize(value: Any) -> Any:
    if _is_dataclass_instance(value):
        return _normalize(mr.dump(value))
    if isinstance(value, dict):
        return {k: _normalize(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_normalize(item) for item in value]
    if isinstance(value, tuple):
        return [_normalize(item) for item in value]
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, decimal.Decimal):
        return str(value)
    if isinstance(value, datetime.datetime):
        return value.isoformat()
    if isinstance(value, datetime.date):
        return value.isoformat()
    if isinstance(value, datetime.time):
        return value.isoformat()
    if isinstance(value, bytes):
        return base64.b64encode(value).decode("ascii")
    return value


def _is_dataclass_instance(value: Any) -> bool:
    return dataclasses.is_dataclass(value) and not isinstance(value, type)
