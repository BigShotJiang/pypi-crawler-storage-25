"""Filter factories for ``ToolRegistryBuilder.add(filter=...)``.

Each factory returns a ``ToolFilterFn`` closed over its arguments. Combine them
with ``ALL_OF`` / ``ANY_OF``, or mix with plain lambdas — a filter is just a
``Callable[[ExecutableTool], bool]``.

Usage::

    from flowra.tools import tool_filter

    builder.add(tools, filter=tool_filter.INCLUDE_SUFFIX("create_draft"))
    builder.add(tools, filter=tool_filter.ALL_OF(
        tool_filter.INCLUDE_SUFFIX("a", "b"),
        tool_filter.EXCLUDE_SUFFIX("c"),
    ))
"""

from collections.abc import Callable

from .types import ExecutableTool

__all__ = ["ALL_OF", "ANY_OF", "EXCLUDE_SUFFIX", "INCLUDE_SUFFIX", "ToolFilterFn"]


type ToolFilterFn = Callable[[ExecutableTool], bool]

_NAME_SEPARATOR = "__"


def _matches_suffix(name: str, patterns: tuple[str, ...]) -> bool:
    return any(name == p or name.endswith(f"{_NAME_SEPARATOR}{p}") for p in patterns)


def _include_suffix(*suffixes: str) -> ToolFilterFn:
    def apply(tool: ExecutableTool) -> bool:
        return _matches_suffix(tool.definition.name, suffixes)

    return apply


def _exclude_suffix(*suffixes: str) -> ToolFilterFn:
    def apply(tool: ExecutableTool) -> bool:
        return not _matches_suffix(tool.definition.name, suffixes)

    return apply


def _all_of(*filters: ToolFilterFn) -> ToolFilterFn:
    def apply(tool: ExecutableTool) -> bool:
        return all(f(tool) for f in filters)

    return apply


def _any_of(*filters: ToolFilterFn) -> ToolFilterFn:
    def apply(tool: ExecutableTool) -> bool:
        return any(f(tool) for f in filters)

    return apply


INCLUDE_SUFFIX = _include_suffix
"""Match tools whose name equals any of the given suffixes or ends with ``__<suffix>``."""

EXCLUDE_SUFFIX = _exclude_suffix
"""Match tools whose name does NOT equal any of the given suffixes and does NOT end with ``__<suffix>``."""

ALL_OF = _all_of
"""Combine filters with AND semantics — a tool passes if every filter matches."""

ANY_OF = _any_of
"""Combine filters with OR semantics — a tool passes if any filter matches."""
