"""Universal LLM pricing registry backed by JSON data files.

Loads pricing from ``data/generated.json`` (auto-generated from litellm) and
``data/custom.json`` (manual overrides).  Providers call :func:`estimate_cost`
with their provider key and token counts to get a :class:`CostBreakdown`.
"""

from __future__ import annotations

import dataclasses
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..response import CostBreakdown

__all__ = ["DATA_DIR", "ModelPricing", "PricingRegistry"]

DATA_DIR = Path(__file__).parent / "data"

_CONTEXT_TIER_THRESHOLD = 200_000


@dataclass(frozen=True, slots=True, kw_only=True)
class ModelPricing:
    """Per-model pricing rates, all in $/1M tokens.

    Fields default to ``0.0``; omit in JSON when not applicable.
    """

    input: float = 0.0
    output: float = 0.0
    cache_read: float = 0.0
    cache_creation: float = 0.0  # default TTL (5-minute ephemeral for Anthropic)
    cache_creation_1h: float = 0.0  # Anthropic 1-hour cache
    reasoning_output: float = 0.0  # 0 → billed at normal output rate

    # Above-200k context tier overrides (0 → use base rate for all tokens).
    input_above_200k: float = 0.0
    output_above_200k: float = 0.0
    cache_read_above_200k: float = 0.0
    cache_creation_above_200k: float = 0.0
    cache_creation_1h_above_200k: float = 0.0


class PricingRegistry:
    """Universal LLM pricing registry.

    Holds per-provider pricing tables and computes costs via
    :meth:`estimate_cost`.
    """

    __slots__ = ("_tables",)

    def __init__(self) -> None:
        # provider → [(model_key, pricing)], sorted longest-key-first.
        self._tables: dict[str, list[tuple[str, ModelPricing]]] = {}

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    @classmethod
    def load_default(cls) -> PricingRegistry:
        """Load bundled ``generated.json`` + ``custom.json`` (custom wins)."""
        registry = cls()
        generated = DATA_DIR / "generated.json"
        custom = DATA_DIR / "custom.json"
        if generated.exists():
            registry._load_json(generated)
        if custom.exists():
            registry._load_json(custom)
        return registry

    def _load_json(self, path: Path) -> None:
        raw: dict[str, dict[str, Any]] = json.loads(path.read_text())
        for provider, models in raw.items():
            for model_key, fields in models.items():
                existing = self._resolve(provider, model_key, exact=True)
                if existing is not None:
                    # Merge: existing fields serve as base, new fields override.
                    merged = {f.name: getattr(existing, f.name) for f in dataclasses.fields(existing)}
                    merged.update(fields)
                    pricing = ModelPricing(**merged)
                else:
                    pricing = ModelPricing(**fields)
                self._set(provider, model_key, pricing)

    # ------------------------------------------------------------------
    # Runtime registration
    # ------------------------------------------------------------------

    def register(self, provider: str, model: str, pricing: ModelPricing) -> None:
        """Add or override pricing for *model* under *provider* at runtime."""
        self._set(provider, model, pricing)

    # ------------------------------------------------------------------
    # Cost estimation
    # ------------------------------------------------------------------

    def estimate_cost(
        self,
        model: str,
        *,
        provider: str,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int = 0,
        cache_creation_tokens: int = 0,
        cache_creation_1h_tokens: int = 0,
        reasoning_tokens: int = 0,
    ) -> CostBreakdown | None:
        """Estimate dollar cost for a single LLM call.

        Returns ``None`` if *model* is not found under *provider*.

        Contract: *input_tokens* must **not** include cached tokens — those go
        into *cache_read_tokens* / *cache_creation_tokens*.
        """
        pricing = self._resolve(provider, model)
        if pricing is None:
            return None

        total_input_side = input_tokens + cache_read_tokens + cache_creation_tokens + cache_creation_1h_tokens

        has_tier = pricing.input_above_200k > 0 or pricing.output_above_200k > 0 or pricing.cache_read_above_200k > 0

        if has_tier and total_input_side > _CONTEXT_TIER_THRESHOLD:
            below = _CONTEXT_TIER_THRESHOLD / total_input_side
            above = 1.0 - below

            def _rate(base: float, tier: float) -> float:
                return below * base + above * (tier if tier > 0 else base)

            input_rate = _rate(pricing.input, pricing.input_above_200k)
            output_rate = _rate(pricing.output, pricing.output_above_200k)
            cache_read_rate = _rate(pricing.cache_read, pricing.cache_read_above_200k)
            cache_creation_rate = _rate(pricing.cache_creation, pricing.cache_creation_above_200k)
            cache_creation_1h_rate = _rate(pricing.cache_creation_1h, pricing.cache_creation_1h_above_200k)
        else:
            input_rate = pricing.input
            output_rate = pricing.output
            cache_read_rate = pricing.cache_read
            cache_creation_rate = pricing.cache_creation
            cache_creation_1h_rate = pricing.cache_creation_1h

        output_cost = output_tokens * output_rate / 1_000_000
        if reasoning_tokens > 0 and pricing.reasoning_output > 0:
            output_cost += reasoning_tokens * pricing.reasoning_output / 1_000_000

        return CostBreakdown(
            input=input_tokens * input_rate / 1_000_000,
            output=output_cost,
            cache_read=cache_read_tokens * cache_read_rate / 1_000_000,
            cache_creation=(
                cache_creation_tokens * cache_creation_rate + cache_creation_1h_tokens * cache_creation_1h_rate
            )
            / 1_000_000,
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _resolve(self, provider: str, model: str, *, exact: bool = False) -> ModelPricing | None:
        table = self._tables.get(provider)
        if table is None:
            return None
        if exact:
            for key, pricing in table:
                if key == model:
                    return pricing
        else:
            for key, pricing in table:
                if key in model:
                    return pricing
        return None

    def _set(self, provider: str, model_key: str, pricing: ModelPricing) -> None:
        table = self._tables.setdefault(provider, [])
        # Remove existing entry for this key if present.
        table[:] = [(k, p) for k, p in table if k != model_key]
        table.append((model_key, pricing))
        # Re-sort longest-key-first for correct substring matching.
        table.sort(key=lambda item: len(item[0]), reverse=True)
