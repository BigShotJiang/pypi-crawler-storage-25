"""Universal LLM pricing — JSON-backed registry with per-provider cost estimation."""

from ..response import CostBreakdown
from .registry import ModelPricing, PricingRegistry

__all__ = ["CostBreakdown", "ModelPricing", "PricingRegistry", "estimate_cost", "get_registry"]

_default: PricingRegistry | None = None


def get_registry() -> PricingRegistry:
    """Return the default :class:`PricingRegistry` (lazy-loaded singleton)."""
    global _default
    if _default is None:
        _default = PricingRegistry.load_default()
    return _default


def estimate_cost(
    model: str,
    *,
    provider: str,
    input_tokens: int,
    output_tokens: int,
    cache_read_tokens: int = 0,
    cache_creation_tokens: int = 0,
    cache_creation_1h_tokens: int = 0,
    reasoning_tokens: int = 0,
) -> CostBreakdown | None:
    """Convenience wrapper around :meth:`PricingRegistry.estimate_cost`."""
    return get_registry().estimate_cost(
        model,
        provider=provider,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cache_read_tokens=cache_read_tokens,
        cache_creation_tokens=cache_creation_tokens,
        cache_creation_1h_tokens=cache_creation_1h_tokens,
        reasoning_tokens=reasoning_tokens,
    )
