import dataclasses
from typing import Any, ClassVar, Self

import marshmallow_recipe as mr

__all__ = ["LLMData", "ProviderExtra", "build_extra"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LLMData:
    metadata: dict[str, Any] = dataclasses.field(default_factory=dict)
    extra: dict[str, Any] = dataclasses.field(default_factory=dict)
    transient: bool = False


class ProviderExtra:
    """Base class for provider-specific extra dataclasses.

    Subclasses are frozen dataclasses with ``mr.MISSING`` defaults and
    ``@mr.options(none_value_handling=mr.NoneValueHandling.INCLUDE)``.

    Three operations:

    - **build**: ``build_extra(MyExtra(field=value))`` → ``dict``
    - **write**: ``MyExtra(field=value).write_to(obj)`` — mutate existing object
    - **read**: ``MyExtra.read_from(obj)`` → typed dataclass
    """

    __slots__ = ()

    KEY: ClassVar[str]

    def write_to_extra(self, extra: dict[str, Any]) -> None:
        data = extra.setdefault(self.KEY, {})
        for key, value in mr.dump(self).items():
            if value is None:
                data.pop(key, None)
            else:
                data[key] = value

    @classmethod
    def read_from_extra(cls, extra: dict[str, Any]) -> Self:
        return mr.load(cls, extra.get(cls.KEY, {}))


def build_extra(*writers: ProviderExtra) -> dict[str, Any]:
    extra: dict[str, Any] = {}
    for w in writers:
        w.write_to_extra(extra)
    return extra
