from openai.lib.azure import AsyncAzureOpenAI

from .openai import OpenAIProvider

__all__ = [
    "AzureOpenAIProvider",
]


class AzureOpenAIProvider(OpenAIProvider):
    __slots__ = ()

    def __init__(
        self,
        *,
        client: AsyncAzureOpenAI | None = None,
        azure_endpoint: str | None = None,
        api_key: str | None = None,
        api_version: str | None = None,
        owns_client: bool = False,
    ) -> None:
        if client is not None:
            super().__init__(client=client, owns_client=owns_client, pricing_provider="azure")
        elif azure_endpoint is not None:
            super().__init__(
                client=AsyncAzureOpenAI(
                    azure_endpoint=azure_endpoint,
                    api_key=api_key,
                    api_version=api_version,
                    max_retries=0,
                ),
                owns_client=True,
                pricing_provider="azure",
            )
        else:
            raise ValueError("Either 'client' or 'azure_endpoint' must be provided")
