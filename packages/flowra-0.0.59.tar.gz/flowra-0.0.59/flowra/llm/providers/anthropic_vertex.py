import base64
import json
from typing import Any

from anthropic import AsyncAnthropicVertex, omit
from anthropic.lib.streaming import AsyncMessageStreamManager
from anthropic.types import Message as AnthropicMessage
from google.oauth2 import service_account

from .anthropic import (
    ANTHROPIC_EXTRA_KEY as ANTHROPIC_EXTRA_KEY,
    AnthropicBlockExtra as AnthropicBlockExtra,
    AnthropicCacheable as AnthropicCacheable,
    AnthropicClient,
    AnthropicMessageParams,
    AnthropicProvider,
    AnthropicRequestExtra as AnthropicRequestExtra,
    AnthropicToolExtra as AnthropicToolExtra,
)

__all__ = [
    "ANTHROPIC_EXTRA_KEY",
    "AnthropicBlockExtra",
    "AnthropicCacheable",
    "AnthropicRequestExtra",
    "AnthropicToolExtra",
    "AnthropicVertexProvider",
]


def _to_sdk_kwargs(params: AnthropicMessageParams) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "model": params.model,
        "messages": params.messages,
        "max_tokens": params.max_tokens,
        "system": params.system if params.system is not None else omit,
        "tools": params.tools if params.tools is not None else omit,
        "temperature": params.temperature if params.temperature is not None else omit,
        "top_p": params.top_p if params.top_p is not None else omit,
        "stop_sequences": params.stop_sequences if params.stop_sequences is not None else omit,
        "thinking": params.thinking if params.thinking is not None else omit,
    }
    return kwargs


class AnthropicVertexProvider(AnthropicProvider):
    __slots__ = ()

    class _Client(AnthropicClient):
        __slots__ = ("__client",)

        def __init__(self, client: AsyncAnthropicVertex) -> None:
            self.__client = client

        async def create_message(self, params: AnthropicMessageParams) -> AnthropicMessage:
            return await self.__client.messages.create(**_to_sdk_kwargs(params), stream=False)  # type: ignore[call-overload]

        def stream_messages(self, params: AnthropicMessageParams) -> AsyncMessageStreamManager[Any]:
            return self.__client.messages.stream(**_to_sdk_kwargs(params))

        async def close(self) -> None:
            await self.__client.close()

    def __init__(
        self,
        *,
        client: AsyncAnthropicVertex | None = None,
        project: str | None = None,
        location: str | None = None,
        credentials: str | None = None,
        owns_client: bool = False,
    ) -> None:
        if client is not None:
            super().__init__(client=self._Client(client), owns_client=owns_client)
        elif project and location and credentials:
            super().__init__(
                client=self._Client(self.__create_client(project=project, location=location, credentials=credentials)),
                owns_client=True,
            )
        else:
            raise ValueError("Either 'client' or all of 'project', 'location', 'credentials' must be provided")

    @staticmethod
    def __create_client(*, project: str, location: str, credentials: str) -> AsyncAnthropicVertex:
        creds_json = base64.b64decode(credentials.encode()).decode()
        creds_info = json.loads(creds_json)
        google_creds = service_account.Credentials.from_service_account_info(creds_info)
        google_creds = google_creds.with_scopes(["https://www.googleapis.com/auth/cloud-platform"])
        return AsyncAnthropicVertex(region=location, project_id=project, credentials=google_creds)
