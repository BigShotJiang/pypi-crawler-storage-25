from typing import Any

from anthropic import omit
from anthropic.lib.foundry import AsyncAnthropicFoundry
from anthropic.lib.streaming import AsyncMessageStreamManager
from anthropic.types import Message as AnthropicMessage

from .anthropic import AnthropicClient, AnthropicMessageParams, AnthropicProvider

__all__ = [
    "AnthropicFoundryProvider",
]


def _to_sdk_kwargs(params: AnthropicMessageParams) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "model": params.model,
        "messages": params.messages,
        "max_tokens": params.max_tokens,
        "system": params.system if params.system is not None else omit,
        "tools": params.tools if params.tools is not None else omit,
        "temperature": params.temperature if params.temperature is not None else omit,
        "top_p": params.top_p if params.top_p is not None else omit,
        "stop_sequences": params.stop_sequences if params.stop_sequences is not None else omit,
        "thinking": params.thinking if params.thinking is not None else omit,
    }
    return kwargs


class AnthropicFoundryProvider(AnthropicProvider):
    __slots__ = ()

    class _Client(AnthropicClient):
        __slots__ = ("__client",)

        def __init__(self, client: AsyncAnthropicFoundry) -> None:
            self.__client = client

        async def create_message(self, params: AnthropicMessageParams) -> AnthropicMessage:
            return await self.__client.messages.create(**_to_sdk_kwargs(params), stream=False)  # type: ignore[call-overload]

        def stream_messages(self, params: AnthropicMessageParams) -> AsyncMessageStreamManager[Any]:
            return self.__client.messages.stream(**_to_sdk_kwargs(params))

        async def close(self) -> None:
            await self.__client.close()

    def __init__(
        self,
        *,
        client: AsyncAnthropicFoundry | None = None,
        resource: str | None = None,
        api_key: str | None = None,
        owns_client: bool = False,
    ) -> None:
        if client is not None:
            super().__init__(client=self._Client(client), owns_client=owns_client, pricing_provider="azure_ai")
        elif resource is not None:
            super().__init__(
                client=self._Client(
                    AsyncAnthropicFoundry(
                        resource=resource,
                        api_key=api_key,
                        max_retries=0,
                    )
                ),
                owns_client=True,
                pricing_provider="azure_ai",
            )
        else:
            raise ValueError("Either 'client' or 'resource' must be provided")
