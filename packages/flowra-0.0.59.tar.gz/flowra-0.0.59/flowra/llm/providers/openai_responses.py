import base64
import dataclasses
import json
from collections.abc import AsyncIterator
from typing import Any, ClassVar

import marshmallow_recipe as mr
from openai import AsyncOpenAI
from openai.types.responses import (
    Response as OpenAIResponse,
    ResponseFunctionToolCall,
    ResponseOutputMessage,
    ResponseOutputText,
    ResponseToolSearchCall,
    ResponseToolSearchOutputItem,
)
from openai.types.responses.response_usage import ResponseUsage

from ..base import ProviderExtra
from ..blocks import AssistantBlock, MediaBlock, TextBlock, ThinkingBlock, ToolResultBlock, ToolUseBlock
from ..messages import AssistantMessage, UserMessage
from ..openai_schema import make_schema_strict
from ..pricing import estimate_cost as pricing_estimate_cost
from ..provider import LLMProvider
from ..request import LLMRequest
from ..response import LLMResponse, StopReason, Usage
from ..schema_formatting import format_output_schema_for_description
from ..stream import ContentComplete, StreamEvent, TextDelta
from ..tools import Tool

__all__ = [
    "OPENAI_EXTRA_KEY",
    "OpenAIRequestExtra",
    "OpenAIResponsesProvider",
    "OpenAIToolExtra",
]

OPENAI_EXTRA_KEY = "openai"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
@mr.options(none_value_handling=mr.NoneValueHandling.INCLUDE)
class OpenAIToolExtra(ProviderExtra):
    KEY: ClassVar[str] = OPENAI_EXTRA_KEY
    defer_loading: bool | None = mr.MISSING
    type: str | None = mr.MISSING
    namespace: str | None = mr.MISSING

    def write_to(self, tool: Tool) -> None:
        self.write_to_extra(tool.extra)

    @classmethod
    def read_from(cls, tool: Tool) -> "OpenAIToolExtra":
        return cls.read_from_extra(tool.extra)

    @classmethod
    def raw(cls, tool: Tool) -> dict[str, Any]:
        return tool.extra.get(cls.KEY, {})


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
@mr.options(none_value_handling=mr.NoneValueHandling.INCLUDE)
class OpenAIRequestExtra(ProviderExtra):
    KEY: ClassVar[str] = OPENAI_EXTRA_KEY
    namespaces: dict[str, str] | None = mr.MISSING

    def write_to(self, request: LLMRequest) -> None:
        self.write_to_extra(request.extra)

    @classmethod
    def read_from(cls, request: LLMRequest) -> "OpenAIRequestExtra":
        return cls.read_from_extra(request.extra)


class OpenAIResponsesProvider(LLMProvider):
    """OpenAI provider using the Responses API.

    Supports all Responses API features including tool search with
    deferred tool loading and namespace grouping. For the Chat Completions
    API, use ``OpenAIProvider`` instead.
    """

    __slots__ = ("__client", "__owns_client")

    def __init__(
        self,
        *,
        client: AsyncOpenAI | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        organization: str | None = None,
        owns_client: bool = False,
    ) -> None:
        if client is not None:
            self.__client = client
            self.__owns_client = owns_client
        elif api_key is not None:
            self.__client = AsyncOpenAI(api_key=api_key, base_url=base_url, organization=organization)
            self.__owns_client = True
        else:
            raise ValueError("Either 'client' or 'api_key' must be provided")

    async def aclose(self) -> None:
        if self.__owns_client:
            await self.__client.close()

    async def call(self, request: LLMRequest) -> LLMResponse:
        kwargs, name_map = self.__build_kwargs(request)
        response: OpenAIResponse = await self.__client.responses.create(**kwargs)
        return self.__convert_response(response, request.model, name_map)

    async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
        kwargs, name_map = self.__build_kwargs(request)
        async with self.__client.responses.stream(**kwargs) as api_stream:
            async for event in api_stream:
                if event.type == "response.output_text.delta":
                    yield TextDelta(text=event.delta)

            response = await api_stream.get_final_response()

        yield ContentComplete(response=self.__convert_response(response, request.model, name_map))

    def __build_kwargs(self, request: LLMRequest) -> tuple[dict[str, Any], dict[str, str]]:
        kwargs: dict[str, Any] = {
            "model": request.model,
        }

        if request.system:
            kwargs["instructions"] = "\n\n".join("\n\n".join(b.text for b in msg.blocks) for msg in request.system)

        input_items = self.__convert_messages(request.messages)
        if input_items:
            kwargs["input"] = input_items

        if request.max_tokens is not None:
            kwargs["max_output_tokens"] = request.max_tokens

        if request.temperature is not None:
            kwargs["temperature"] = request.temperature

        if request.top_p is not None:
            kwargs["top_p"] = request.top_p

        name_map: dict[str, str] = {}
        if request.tools:
            req_extra = OpenAIRequestExtra.read_from(request)
            ns_descriptions = req_extra.namespaces if req_extra.namespaces else {}
            kwargs["tools"], name_map = self.__convert_tools(request.tools, ns_descriptions)

        if request.json_schema:
            kwargs["text"] = {
                "format": {
                    "type": "json_schema",
                    "name": "response",
                    "strict": True,
                    "schema": make_schema_strict(request.json_schema),
                },
            }

        return kwargs, name_map

    @classmethod
    def __convert_messages(
        cls,
        messages: list[UserMessage | AssistantMessage],
    ) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []

        for message in messages:
            match message:
                case UserMessage(blocks=blocks):
                    content_parts: list[dict[str, Any]] = []
                    for block in blocks:
                        match block:
                            case TextBlock(text=text):
                                content_parts.append({"type": "input_text", "text": text})
                            case MediaBlock(data=data, media_type=media_type):
                                b64 = base64.b64encode(data).decode()
                                data_uri = f"data:{media_type};base64,{b64}"
                                if media_type.startswith("image/"):
                                    content_parts.append(
                                        {
                                            "type": "input_image",
                                            "image_url": data_uri,
                                        }
                                    )
                                else:
                                    content_parts.append(
                                        {
                                            "type": "input_file",
                                            "file_data": data_uri,
                                        }
                                    )
                            case ToolResultBlock(
                                tool_use_id=tool_use_id,
                                content=content,
                                is_error=is_error,
                            ):
                                if content_parts:
                                    items.append({"role": "user", "content": content_parts})
                                    content_parts = []
                                openai_extra = block.extra.get(OPENAI_EXTRA_KEY, {})
                                if openai_extra.get("type") == "tool_search_output":
                                    original_id = openai_extra.get("original_id", tool_use_id)
                                    items.append(
                                        {
                                            "type": "tool_search_output",
                                            "id": original_id,
                                            "call_id": None,
                                            "execution": openai_extra.get("execution", "server"),
                                            "status": "completed",
                                            "tools": json.loads(content),
                                        }
                                    )
                                else:
                                    output = f"Error: {content}" if is_error else content
                                    items.append(
                                        {
                                            "type": "function_call_output",
                                            "call_id": tool_use_id,
                                            "output": output,
                                        }
                                    )
                    if content_parts:
                        items.append({"role": "user", "content": content_parts})

                case AssistantMessage(blocks=blocks):
                    text_parts: list[str] = []
                    for block in blocks:
                        match block:
                            case TextBlock(text=text):
                                text_parts.append(text)
                            case ToolUseBlock(id=id_, name=name, input=input_):
                                if text_parts:
                                    items.append(
                                        {
                                            "role": "assistant",
                                            "content": "\n".join(text_parts),
                                        }
                                    )
                                    text_parts = []
                                openai_extra = block.extra.get(OPENAI_EXTRA_KEY, {})
                                if openai_extra.get("type") == "tool_search_call":
                                    items.append(
                                        {
                                            "type": "tool_search_call",
                                            "id": id_,
                                            "call_id": None,
                                            "execution": openai_extra.get("execution", "server"),
                                            "status": "completed",
                                            "arguments": input_ or {},
                                        }
                                    )
                                else:
                                    arguments = input_ if isinstance(input_, str) else json.dumps(input_ or {})
                                    fc_item: dict[str, Any] = {
                                        "type": "function_call",
                                        "call_id": id_,
                                        "name": name,
                                        "arguments": arguments,
                                    }
                                    ns = openai_extra.get("namespace")
                                    if ns is not None:
                                        fc_item["namespace"] = ns
                                    items.append(fc_item)
                            case ThinkingBlock():
                                pass
                    if text_parts:
                        items.append(
                            {
                                "role": "assistant",
                                "content": "\n".join(text_parts),
                            }
                        )

        return items

    @staticmethod
    def __convert_tools(
        tools: list[Tool],
        ns_descriptions: dict[str, str],
    ) -> tuple[list[dict[str, Any]], dict[str, str]]:
        """Convert flowra tools to OpenAI API format, grouping by namespace.

        Returns (api_tools, name_map) where name_map maps OpenAI wire names
        (``ns.func``) back to flowra tool names (``func``).
        """
        result: list[dict[str, Any]] = []
        # namespace_name -> [function_entries]
        namespaces: dict[str, list[dict[str, Any]]] = {}
        name_map: dict[str, str] = {}

        for tool in tools:
            extra = OpenAIToolExtra.raw(tool)

            if extra.get("type") == "tool_search":
                result.append({"type": "tool_search"})
                continue

            description = tool.description
            if tool.output_schema:
                description += format_output_schema_for_description(tool.output_schema)

            entry: dict[str, Any] = {
                "name": tool.name,
                "description": description,
                "parameters": tool.input_schema or {"type": "object", "properties": {}},
                "strict": False,
            }

            if extra.get("defer_loading"):
                entry["defer_loading"] = True

            ns = extra.get("namespace")
            if ns:
                if ns not in namespaces:
                    namespaces[ns] = []
                namespaces[ns].append(entry)
                name_map[f"{ns}.{tool.name}"] = tool.name
            else:
                entry["type"] = "function"
                result.append(entry)

        for ns_name, functions in namespaces.items():
            for fn in functions:
                fn["type"] = "function"
            result.append(
                {
                    "type": "namespace",
                    "name": ns_name,
                    "description": ns_descriptions.get(ns_name, ""),
                    "tools": functions,
                }
            )

        return result, name_map

    @classmethod
    def __convert_response(
        cls,
        response: OpenAIResponse,
        model: str,
        name_map: dict[str, str],
    ) -> LLMResponse:
        messages: list[UserMessage | AssistantMessage] = []
        blocks: list[AssistantBlock] = []
        stop_reason = StopReason.OTHER
        has_tool_calls = False
        last_search_call_id: str | None = None

        def _flush_blocks() -> None:
            nonlocal blocks
            if blocks:
                messages.append(AssistantMessage(blocks=blocks))
                blocks = []

        for item in response.output:
            if isinstance(item, ResponseOutputMessage):
                for content in item.content:
                    if isinstance(content, ResponseOutputText):
                        blocks.append(TextBlock(text=content.text))
            elif isinstance(item, ResponseFunctionToolCall):
                has_tool_calls = True
                tool_name = name_map.get(item.name, item.name)
                extra: dict[str, Any] = {}
                if item.namespace is not None:
                    extra[OPENAI_EXTRA_KEY] = {"namespace": item.namespace}
                blocks.append(
                    ToolUseBlock(
                        id=item.call_id,
                        name=tool_name,
                        input=item.arguments,
                        extra=extra,
                    )
                )
            elif isinstance(item, ResponseToolSearchCall):
                _flush_blocks()
                call_id = item.call_id or item.id
                last_search_call_id = call_id
                arguments = item.arguments if isinstance(item.arguments, dict | str) else None
                search_block: AssistantBlock = ToolUseBlock(
                    id=call_id,
                    name="__tool_search__",
                    input=arguments,
                    extra={OPENAI_EXTRA_KEY: {"type": "tool_search_call", "execution": item.execution}},
                )
                messages.append(AssistantMessage(blocks=[search_block]))
            elif isinstance(item, ResponseToolSearchOutputItem):
                call_id = last_search_call_id or item.call_id or item.id
                original_id = item.call_id or item.id
                tool_defs = [t.model_dump() for t in item.tools]
                result_block = ToolResultBlock(
                    tool_use_id=call_id,
                    content=json.dumps(tool_defs),
                    extra={
                        OPENAI_EXTRA_KEY: {
                            "type": "tool_search_output",
                            "execution": item.execution,
                            "original_id": original_id,
                        }
                    },
                )
                messages.append(UserMessage(blocks=[result_block]))

        _flush_blocks()

        match response.status:
            case "completed":
                stop_reason = StopReason.TOOL_USE if has_tool_calls else StopReason.END_TURN
            case "incomplete":
                stop_reason = StopReason.MAX_TOKENS
            case _:
                stop_reason = StopReason.OTHER

        usage = cls.__convert_usage(response.usage, model) if response.usage else None

        extra: dict[str, Any] = {}
        if response.id:
            extra["id"] = response.id
        if response.status:
            extra["provider_status"] = response.status

        if not messages:
            messages.append(AssistantMessage(blocks=[]))

        return LLMResponse(
            messages=messages,
            stop_reason=stop_reason,
            usage=usage,
            extra=extra,
        )

    @classmethod
    def __convert_usage(cls, usage: ResponseUsage, model: str) -> Usage:
        cache_read = 0
        if usage.input_tokens_details and usage.input_tokens_details.cached_tokens:
            cache_read = usage.input_tokens_details.cached_tokens

        input_tokens = max(0, usage.input_tokens - cache_read)

        reasoning_tokens = 0
        extra: dict[str, Any] = {}
        if usage.output_tokens_details and usage.output_tokens_details.reasoning_tokens:
            reasoning_tokens = usage.output_tokens_details.reasoning_tokens
            extra["reasoning_tokens"] = reasoning_tokens

        cost = pricing_estimate_cost(
            model,
            provider="openai",
            input_tokens=input_tokens,
            output_tokens=usage.output_tokens,
            cache_read_tokens=cache_read,
            reasoning_tokens=reasoning_tokens,
        )
        return Usage(
            input_tokens=input_tokens,
            output_tokens=usage.output_tokens,
            cache_read_input_tokens=cache_read,
            cost_usd=cost.total if cost is not None else None,
            cost=cost,
            extra=extra,
        )
