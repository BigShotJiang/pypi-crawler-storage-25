import dataclasses
from typing import Any, Literal

from .base import LLMData

__all__ = [
    "AssistantBlock",
    "MediaBlock",
    "TextBlock",
    "ThinkingBlock",
    "ToolResultBlock",
    "ToolUseBlock",
    "UserBlock",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class TextBlock(LLMData):
    type: Literal["text"] = "text"
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class MediaBlock(LLMData):
    """Binary media content: images, PDFs, documents.

    Providers dispatch on *media_type* to choose the right wire format
    (e.g. ``image`` vs ``document`` for Anthropic, ``image_url`` vs ``file``
    for OpenAI).
    """

    type: Literal["media"] = "media"
    data: bytes
    media_type: str
    filename: str | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolUseBlock(LLMData):
    type: Literal["tool_use"] = "tool_use"
    id: str
    name: str
    input: dict[str, Any] | str | None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolResultBlock(LLMData):
    type: Literal["tool_result"] = "tool_result"
    tool_use_id: str
    content: str
    is_error: bool = False


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ThinkingBlock(LLMData):
    type: Literal["thinking"] = "thinking"
    text: str


type UserBlock = TextBlock | MediaBlock | ToolResultBlock
type AssistantBlock = TextBlock | ToolUseBlock | ThinkingBlock
