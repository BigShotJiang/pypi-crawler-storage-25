import dataclasses
from collections.abc import Callable
from typing import Any

from .messages import AssistantMessage, SystemMessage, UserMessage
from .tools import Tool

__all__ = ["LLMRequest", "RequestExtension"]


type RequestExtension = Callable[["LLMRequest"], None]
"""Mutating transform over an ``LLMRequest``.

Attach to ``LLMConfig.request_extensions`` to apply provider-specific
transforms (prompt caching, tool search, etc.) before the request is
dispatched to the provider.
"""


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LLMRequest:
    model: str
    system: list[SystemMessage] = dataclasses.field(default_factory=list)
    messages: list[UserMessage | AssistantMessage] = dataclasses.field(default_factory=list)
    tools: list[Tool] | None = None
    json_schema: dict[str, Any] | None = None
    """JSON Schema for structured output. Provider validates the response against
    the schema and retries up to max_schema_retries times on validation failure.
    If validation fails after all retries, stop_reason is SCHEMA_VALIDATION_FAILED."""
    temperature: float | None = None
    top_p: float | None = None
    max_tokens: int | None = None
    stop_sequences: list[str] | None = None
    max_schema_retries: int = 3
    extra: dict[str, Any] = dataclasses.field(default_factory=dict)
    """Provider-specific configuration, namespaced by provider key.

    Example: ``{"anthropic": {"thinking_budget_tokens": 4000},
    "openai": {"namespaces": {"crm": "CRM tools"}}}``
    """
