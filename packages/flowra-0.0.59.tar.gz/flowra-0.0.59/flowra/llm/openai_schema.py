"""OpenAI strict JSON schema transformation.

Shared between ``OpenAIProvider`` (Chat Completions) and
``OpenAIResponsesProvider`` (Responses API).
"""

from typing import Any

__all__ = ["make_schema_strict"]


def make_schema_strict(schema: dict[str, Any]) -> dict[str, Any]:
    """Transform JSON schema to OpenAI strict mode requirements.

    OpenAI strict mode requires:
    1. All objects must have ``additionalProperties: false``
    2. All properties must be in ``required`` array
    3. Optional fields use ``anyOf`` with null type
    """
    return _process_node(schema)


def _strip_ref_extras(item: dict[str, Any]) -> dict[str, Any]:
    if "$ref" in item:
        extra_keys = {"default", "description", "title"}
        if any(k in item for k in extra_keys):
            return {k: v for k, v in item.items() if k not in extra_keys}
    return item


def _process_property(prop_schema: dict[str, Any], is_required: bool) -> dict[str, Any]:
    if "$ref" in prop_schema:
        clean = _strip_ref_extras(prop_schema)
        if not is_required:
            return {"anyOf": [clean, {"type": "null"}]}
        return clean

    if "anyOf" in prop_schema:
        items: list[dict[str, Any]] = []
        has_null = False
        for item in prop_schema["anyOf"]:
            if item.get("type") == "null":
                has_null = True
            else:
                clean = _strip_ref_extras(item) if "$ref" in item else _process_node(item)
                items.append(clean)

        if (not is_required and not has_null) or has_null:
            items.append({"type": "null"})

        result = {**prop_schema, "anyOf": items}
        if is_required and "default" in result:
            result = {k: v for k, v in result.items() if k != "default"}
        return result

    result = _process_node(prop_schema)

    if not is_required and "type" in result:
        prop_type = result["type"]
        if isinstance(prop_type, str) and prop_type != "null":
            type_keys = {"type", "items", "properties", "required", "additionalProperties", "enum"}
            metadata = {k: v for k, v in result.items() if k not in type_keys}
            type_schema = {k: v for k, v in result.items() if k in type_keys}
            result = {**metadata, "anyOf": [type_schema, {"type": "null"}]}
        elif isinstance(prop_type, list) and "null" not in prop_type:
            type_keys = {"type", "items", "properties", "required", "additionalProperties", "enum"}
            metadata = {k: v for k, v in result.items() if k not in type_keys}
            type_schema = {k: v for k, v in result.items() if k in type_keys}
            type_schema["type"] = prop_type[0] if len(prop_type) == 1 else prop_type
            result = {**metadata, "anyOf": [type_schema, {"type": "null"}]}

    if is_required and "default" in result:
        result = {k: v for k, v in result.items() if k != "default"}

    return result


def _process_node(obj: Any) -> Any:
    if not isinstance(obj, dict):
        return obj

    if "$ref" in obj:
        return obj

    result: dict[str, Any] = {}
    for key, value in obj.items():
        if key == "$defs":
            result[key] = {name: _process_node(defn) for name, defn in value.items()}
        elif key == "properties" and isinstance(value, dict):
            current_required = set(obj.get("required", []))
            result[key] = {name: _process_property(prop, name in current_required) for name, prop in value.items()}
        elif key == "items" and isinstance(value, dict):
            result[key] = _process_node(value)
        elif key == "anyOf" and isinstance(value, list):
            result[key] = [_process_node(item) if isinstance(item, dict) else item for item in value]
        elif isinstance(value, dict):
            result[key] = _process_node(value)
        elif isinstance(value, list):
            result[key] = [_process_node(item) if isinstance(item, dict) else item for item in value]
        else:
            result[key] = value

    if "properties" in result:
        result["additionalProperties"] = False
        result["required"] = sorted(result["properties"].keys())
        if "type" not in result:
            result["type"] = "object"
        for prop_name, prop_schema in result["properties"].items():
            if isinstance(prop_schema, dict) and "default" in prop_schema:
                result["properties"][prop_name] = {k: v for k, v in prop_schema.items() if k != "default"}
    elif result.get("type") == "object":
        result["additionalProperties"] = False
        if "properties" not in result:
            result["properties"] = {}
        if "required" not in result:
            result["required"] = []

    return result
