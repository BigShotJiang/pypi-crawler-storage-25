import dataclasses

from .response import LLMResponse

__all__ = [
    "ContentComplete",
    "StreamEvent",
    "TextDelta",
    "ThinkingDelta",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class TextDelta:
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ThinkingDelta:
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ContentComplete:
    response: LLMResponse


type StreamEvent = TextDelta | ThinkingDelta | ContentComplete
