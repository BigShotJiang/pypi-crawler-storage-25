"""Anthropic prompt caching extensions.

Each extension is a ``RequestExtension`` — a plain callable that mutates
an ``LLMRequest`` in place. Attach them via ``LLMConfig.request_extensions``.

The ``*_non_transient_*`` variants respect the ``transient`` hint on
blocks/messages/tools — transient content is not cached. The ``*_all_*``
variants cache the last block regardless of ``transient``.
"""

from collections.abc import Sequence

from ... import LLMData, LLMRequest, Message
from ...providers.anthropic_vertex import AnthropicCacheable

__all__ = [
    "anthropic_cache_all_messages",
    "anthropic_cache_all_system_messages",
    "anthropic_cache_all_tools",
    "anthropic_cache_non_transient_messages",
    "anthropic_cache_non_transient_system_messages",
    "anthropic_cache_non_transient_tools",
]


# -- Helpers --


def _set_cache(obj: LLMData) -> None:
    AnthropicCacheable(cache_control={"type": "ephemeral"}).write_to(obj)


def _clear_cache(obj: LLMData) -> None:
    AnthropicCacheable(cache_control=None).write_to(obj)


def _clear_message_cache(messages: Sequence[Message]) -> None:
    for m in messages:
        for b in m.blocks:
            _clear_cache(b)


def _cache_last_block(messages: Sequence[Message]) -> None:
    if not messages:
        return
    _clear_message_cache(messages)
    last = messages[-1]
    if last.blocks:
        _set_cache(last.blocks[-1])


def _cache_last_non_transient_block(messages: Sequence[Message]) -> None:
    if not messages:
        return
    _clear_message_cache(messages)
    target_idx = -1
    for i in range(len(messages)):
        if messages[i].transient:
            break
        target_idx = i
    if target_idx >= 0:
        msg = messages[target_idx]
        if msg.blocks:
            block_idx = -1
            for j in range(len(msg.blocks)):
                if msg.blocks[j].transient:
                    break
                block_idx = j
            if block_idx >= 0:
                _set_cache(msg.blocks[block_idx])


# -- System message caching --


def anthropic_cache_all_system_messages(request: LLMRequest) -> None:
    """Cache the last block of the last system message."""
    if request.system:
        _cache_last_block(request.system)


def anthropic_cache_non_transient_system_messages(request: LLMRequest) -> None:
    """Cache the last non-transient block in the non-transient prefix."""
    if request.system:
        _cache_last_non_transient_block(request.system)


# -- Tool caching --


def anthropic_cache_all_tools(request: LLMRequest) -> None:
    """Cache the last tool definition."""
    if not request.tools:
        return
    for tool in request.tools:
        _clear_cache(tool)
    _set_cache(request.tools[-1])


def anthropic_cache_non_transient_tools(request: LLMRequest) -> None:
    """Cache the last non-transient tool in the non-transient prefix."""
    if not request.tools:
        return
    for tool in request.tools:
        _clear_cache(tool)
    target_idx = -1
    for i in range(len(request.tools)):
        if request.tools[i].transient:
            break
        target_idx = i
    if target_idx >= 0:
        _set_cache(request.tools[target_idx])


# -- Message caching --


def anthropic_cache_all_messages(request: LLMRequest) -> None:
    """Cache the last block of the last message."""
    if request.messages:
        _cache_last_block(request.messages)


def anthropic_cache_non_transient_messages(request: LLMRequest) -> None:
    """Cache the last non-transient block in the non-transient prefix."""
    if request.messages:
        _cache_last_non_transient_block(request.messages)
