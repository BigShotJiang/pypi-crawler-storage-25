"""Anthropic tool search extension.

Deferred tool loading for large tool sets — marks tools with
``defer_loading: true`` and adds the Anthropic server-side search tool.
"""

import enum
from collections.abc import Callable

from ... import LLMRequest, RequestExtension, Tool
from ...providers.anthropic_vertex import AnthropicToolExtra

__all__ = ["ToolSearchVariant", "anthropic_tool_search"]


class ToolSearchVariant(enum.StrEnum):
    BM25 = "bm25"
    REGEX = "regex"


_SEARCH_TOOL_TYPES: dict[ToolSearchVariant, str] = {
    ToolSearchVariant.BM25: "tool_search_tool_bm25_20251119",
    ToolSearchVariant.REGEX: "tool_search_tool_regex_20251119",
}


def anthropic_tool_search(
    *,
    variant: ToolSearchVariant = ToolSearchVariant.BM25,
    predicate: Callable[[Tool], bool] | None = None,
) -> RequestExtension:
    """Build a request extension that defers tool loading and adds a server-side search tool.

    Marks tools with ``defer_loading: true`` so Claude sees only names and
    descriptions (not full schemas). Adds a server-side search tool that
    Claude calls to discover full tool definitions on demand.

    Reduces token usage by ~85% when using many tools (50+).

    Args:
        variant: Search tool variant — ``BM25`` (natural language, default)
            or ``REGEX`` (Claude constructs regex patterns).
        predicate: Optional callable ``(Tool) -> bool`` to select which tools
            to defer. By default all tools are deferred.
    """
    search_tool_type = _SEARCH_TOOL_TYPES[variant]
    search_tool_name = f"tool_search_tool_{variant}"

    def apply(request: LLMRequest) -> None:
        if not request.tools:
            return

        has_deferred = False
        for tool in request.tools:
            if predicate is None or predicate(tool):
                AnthropicToolExtra(defer_loading=True).write_to(tool)
                has_deferred = True

        if not has_deferred:
            return

        search_tool = Tool(name=search_tool_name, description="")
        AnthropicToolExtra(type=search_tool_type).write_to(search_tool)
        request.tools.insert(0, search_tool)

    return apply
