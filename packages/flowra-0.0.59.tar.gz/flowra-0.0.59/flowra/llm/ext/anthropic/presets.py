"""Composite presets for common Anthropic caching configurations.

Individual extensions (import from ``cache``):
- ``anthropic_cache_all_messages`` — cache the last block of the last message
- ``anthropic_cache_all_system_messages`` — cache the last block of the last system message
- ``anthropic_cache_all_tools`` — cache the last tool definition
- ``anthropic_cache_non_transient_messages`` — cache last non-transient block (stops at first transient)
- ``anthropic_cache_non_transient_system_messages`` — cache last non-transient system block (stops at first transient)
- ``anthropic_cache_non_transient_tools`` — cache last non-transient tool (stops at first transient)

Composite presets (call multiple caching slots in one extension):
- ``anthropic_cache_all`` — system + tools + messages
- ``anthropic_cache_non_transient`` — non-transient system + tools + messages
"""

from ... import LLMRequest
from .cache import (
    anthropic_cache_all_messages,
    anthropic_cache_all_system_messages,
    anthropic_cache_all_tools,
    anthropic_cache_non_transient_messages,
    anthropic_cache_non_transient_system_messages,
    anthropic_cache_non_transient_tools,
)

__all__ = [
    "anthropic_cache_all",
    "anthropic_cache_non_transient",
]


def anthropic_cache_all(request: LLMRequest) -> None:
    """Cache the last system message, the last tool, and the last message."""
    anthropic_cache_all_system_messages(request)
    anthropic_cache_all_tools(request)
    anthropic_cache_all_messages(request)


def anthropic_cache_non_transient(request: LLMRequest) -> None:
    """Cache the non-transient prefix of system messages, tools, and messages."""
    anthropic_cache_non_transient_system_messages(request)
    anthropic_cache_non_transient_tools(request)
    anthropic_cache_non_transient_messages(request)
