"""OpenAI tool search extension.

Deferred tool loading for large tool sets — marks tools with
``defer_loading: true`` and adds the server-side tool search tool
for the OpenAI Responses API.

Requires ``OpenAIResponsesProvider`` and models that support tool
search (gpt-5.4+).
"""

from collections.abc import Callable

from ... import LLMRequest, RequestExtension, Tool
from ...providers.openai_responses import OpenAIToolExtra

__all__ = ["openai_tool_search"]


def openai_tool_search(
    *,
    predicate: Callable[[Tool], bool] | None = None,
) -> RequestExtension:
    """Build a request extension that defers tool loading and enables OpenAI tool search.

    Marks tools with ``defer_loading: true`` so the model sees only names and
    descriptions (not full schemas). Adds a server-side ``tool_search`` tool
    that discovers full tool definitions on demand.

    Reduces token usage when using many tools (50+).

    Args:
        predicate: Optional callable ``(Tool) -> bool`` to select which tools
            to defer. By default all tools are deferred.
    """

    def apply(request: LLMRequest) -> None:
        if not request.tools:
            return

        has_deferred = False
        for tool in request.tools:
            if predicate is None or predicate(tool):
                OpenAIToolExtra(defer_loading=True).write_to(tool)
                has_deferred = True

        if not has_deferred:
            return

        search_tool = Tool(name="__tool_search__", description="")
        OpenAIToolExtra(type="tool_search").write_to(search_tool)
        request.tools.insert(0, search_tool)

    return apply
