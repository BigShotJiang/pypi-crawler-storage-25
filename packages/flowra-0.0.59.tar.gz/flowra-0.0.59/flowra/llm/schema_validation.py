import json
from typing import Any

import jsonschema

__all__ = ["strip_markdown_code_block", "validate_json_schema"]


def strip_markdown_code_block(text: str) -> str:
    text = text.strip()
    if text.startswith("```") and text.endswith("```"):
        lines = text.split("\n")
        return "\n".join(lines[1:-1])
    if text.startswith("```"):
        lines = text.split("\n")
        return "\n".join(lines[1:])
    return text


def validate_json_schema(text: str, schema: dict[str, Any]) -> tuple[str | None, str]:
    """Strips markdown code fences, parses JSON, validates against the schema.

    Returns ``(error, cleaned_text)``.  *error* is ``None`` on success (and
    *cleaned_text* contains the fence-stripped JSON string) or an error
    description when validation fails.
    """
    cleaned = strip_markdown_code_block(text)
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as e:
        return f"Invalid JSON: {e}", cleaned
    try:
        jsonschema.validate(instance=parsed, schema=schema)
    except jsonschema.ValidationError as e:
        return f"Schema validation error: {e}", cleaned
    return None, cleaned
