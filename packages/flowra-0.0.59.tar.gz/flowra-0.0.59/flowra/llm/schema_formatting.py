import json
from typing import Any

__all__ = ["format_output_schema_for_description", "format_schema_for_llm"]


def format_schema_for_llm(
    schema: dict[str, Any],
    root_schema: dict[str, Any] | None = None,
    indent: int = 0,
) -> str:
    if root_schema is None:
        root_schema = schema

    if "$ref" in schema:
        ref_path = schema["$ref"].split("/")
        target = root_schema
        for part in ref_path[1:]:
            target = target.get(part, {})
        return format_schema_for_llm(target, root_schema, indent)

    if "allOf" in schema:
        for sub in schema["allOf"]:
            if "$ref" in sub or "properties" in sub:
                return format_schema_for_llm(sub, root_schema, indent)
        if schema["allOf"]:
            return format_schema_for_llm(schema["allOf"][0], root_schema, indent)

    if "anyOf" in schema:
        types = []
        has_null = False
        for s in schema["anyOf"]:
            if s.get("type") == "null":
                has_null = True
                continue
            types.append(format_schema_for_llm(s, root_schema, indent))
        result = " | ".join(types)
        if has_null:
            result += " | null"
        return result

    stype = schema.get("type")

    if isinstance(stype, list):
        non_null = [t for t in stype if t != "null"]
        has_null = len(non_null) < len(stype)
        rest = {k: v for k, v in schema.items() if k != "type"}
        any_of = [{**rest, "type": t} for t in non_null]
        if has_null:
            any_of.append({"type": "null"})
        return format_schema_for_llm({"anyOf": any_of}, root_schema, indent)

    if stype == "object" or "properties" in schema:
        props = schema.get("properties", {})
        if not props:
            return "object"

        required = set(schema.get("required", []))
        lines = []
        inner_prefix = "  " * (indent + 1)

        for key, prop in props.items():
            is_req = "*" if key in required else "?"
            desc = prop.get("description", "").strip()
            comment = f" // {desc}" if desc else ""
            type_content = format_schema_for_llm(prop, root_schema, indent + 1)
            lines.append(f"{inner_prefix}{key}{is_req}: {type_content}{comment}")

        outer_prefix = "  " * indent
        title = schema.get("title", "")
        title_comment = f" // {title}" if title else ""
        return f"{{{title_comment}\n{chr(10).join(lines)}\n{outer_prefix}}}"

    if stype == "array":
        items = schema.get("items", {})
        items_type = format_schema_for_llm(items, root_schema, indent)
        return f"array<{items_type}>"

    if "enum" in schema:
        return " | ".join(json.dumps(v) for v in schema["enum"])

    result = stype or "any"
    if "default" in schema:
        result += f" (default: {json.dumps(schema['default'])})"

    return result


def format_output_schema_for_description(schema: dict[str, Any]) -> str:
    formatted = format_schema_for_llm(schema)
    return f"\n\nOutput structure:\n{formatted}"
