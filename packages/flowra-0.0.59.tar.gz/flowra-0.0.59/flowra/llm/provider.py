import abc
from collections.abc import AsyncIterator
from typing import Self

from .request import LLMRequest
from .response import LLMResponse
from .stream import ContentComplete, StreamEvent

__all__ = ["LLMProvider"]


class LLMProvider(abc.ABC):
    __slots__ = ()

    @abc.abstractmethod
    async def call(self, request: LLMRequest) -> LLMResponse: ...

    async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
        response = await self.call(request)
        yield ContentComplete(response=response)

    async def aclose(self) -> None:
        """Close the provider and release underlying resources.

        Override in subclasses that own closeable clients.
        """

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()
