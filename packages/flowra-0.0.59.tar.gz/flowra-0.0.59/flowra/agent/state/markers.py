import enum

__all__ = [
    "FORK",
    "NEW_SCOPE",
    "Fork",
    "NewScope",
]


class NewScope(enum.Enum):
    NEW_SCOPE = "NEW_SCOPE"


NEW_SCOPE = NewScope.NEW_SCOPE


class Fork(enum.Enum):
    FORK = "FORK"


FORK = Fork.FORK
