"""Markers for the ``state`` parameter on ``CallAgent`` / ``GotoAgent``.

Usage::

    from flowra.agent import persistent

    CallAgent(agent=CalcAgent, state="my-key")               # exclusive, explicit key
    CallAgent(agent=CalcAgent, state=persistent.EPHEMERAL)    # fresh, no persistence
    CallAgent(agent=CalcAgent, state=persistent.NAMED("s"))   # redirect to named scope
"""

__all__ = [
    "EPHEMERAL",
    "NAMED",
    "PersistentState",
]


class _Ephemeral:
    """Marker: child gets a fresh ephemeral persistent scope (no persistence)."""

    __slots__ = ()

    def __repr__(self) -> str:
        return "persistent.EPHEMERAL"


EPHEMERAL = _Ephemeral()


class _Named:
    """Marker: child's persistent scope is redirected to a named scope.

    ``NAMED("session")`` makes ``store.persistent`` point to named scope ``"session"``.
    """

    __slots__ = ("name",)

    def __init__(self, name: str | None = None) -> None:
        self.name = name

    def __call__(self, name: str) -> "_Named":
        return _Named(name)

    def __repr__(self) -> str:
        if self.name is None:
            return "persistent.NAMED"
        return f'persistent.NAMED("{self.name}")'


NAMED = _Named()


type PersistentState = str | _Ephemeral | _Named | None
