import abc
from typing import Any, overload

from .values import AppendOnlyList, Scalar

__all__ = ["AgentStore", "Scope"]


class Scope(abc.ABC):
    """Minimal storage interface: declare typed slots."""

    __slots__ = ()

    @overload
    def slot[T](self, cls: type[Scalar[T]], key: str) -> Scalar[T]: ...

    @overload
    def slot[T](self, cls: type[AppendOnlyList[T]], key: str) -> AppendOnlyList[T]: ...

    @abc.abstractmethod
    def slot(self, cls: Any, key: str) -> Any: ...


class AgentStore(Scope):
    __slots__ = ()

    def slot(self, cls: Any, key: str) -> Any:
        raise RuntimeError("Use store.ephemeral.slot(), store.persistent.slot(), or store['name'].slot()")

    @property
    @abc.abstractmethod
    def ephemeral(self) -> Scope: ...

    @property
    @abc.abstractmethod
    def persistent(self) -> Scope: ...

    @abc.abstractmethod
    def scope(self, name: str) -> Scope: ...

    def __getitem__(self, name: str) -> Scope:
        return self.scope(name)

    @abc.abstractmethod
    async def flush(self) -> None: ...
