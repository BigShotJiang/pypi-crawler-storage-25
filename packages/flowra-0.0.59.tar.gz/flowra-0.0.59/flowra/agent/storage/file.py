import json
import os
import re
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from .session_storage import ChangeSet, SessionStorage

__all__ = ["FileSessionStorage"]

_UNSAFE_CHARS = re.compile(r"[^a-zA-Z0-9_\-]")


class FileSessionStorage(SessionStorage):
    __slots__ = ("__ephemeral_dir", "__execution_path", "__nodes_dir", "__session_dir")

    def __init__(self, base_dir: str, session_id: str) -> None:
        self.__session_dir = os.path.join(base_dir, self.__sanitize_key(session_id))
        self.__nodes_dir = os.path.join(self.__session_dir, "nodes")
        self.__ephemeral_dir = os.path.join(self.__session_dir, "ephemeral")
        self.__execution_path = os.path.join(self.__session_dir, "execution.json")

    @asynccontextmanager
    async def begin_transaction(self) -> AsyncIterator[None]:
        yield

    async def save_execution(self, execution: dict[str, Any]) -> None:
        os.makedirs(self.__nodes_dir, exist_ok=True)
        self.__write_json(self.__execution_path, execution)

    async def has_execution(self) -> bool:
        return os.path.exists(self.__execution_path)  # noqa: ASYNC240

    async def load_execution(self) -> dict[str, Any] | None:
        return self.__read_json(self.__execution_path)

    async def clear_execution(self) -> None:
        if os.path.exists(self.__execution_path):  # noqa: ASYNC240
            os.remove(self.__execution_path)

    async def save(self, key: str, changes: ChangeSet) -> None:
        self.__save_to(self.__nodes_dir, key, changes)

    async def load(self, key: str) -> dict[str, Any] | None:
        return self.__load_from(self.__nodes_dir, key)

    async def save_ephemeral(self, key: str, changes: ChangeSet) -> None:
        self.__save_to(self.__ephemeral_dir, key, changes)

    async def load_ephemeral(self, key: str) -> dict[str, Any] | None:
        return self.__load_from(self.__ephemeral_dir, key)

    async def clear_ephemeral(self) -> None:
        if os.path.isdir(self.__ephemeral_dir):  # noqa: ASYNC240
            import shutil

            shutil.rmtree(self.__ephemeral_dir)

    def __save_to(self, target_dir: str, key: str, changes: ChangeSet) -> None:
        os.makedirs(target_dir, exist_ok=True)
        if changes.scalars:
            path = self.__scalar_path(key, target_dir)
            existing: dict[str, Any] = self.__read_json(path) or {}
            existing.update(changes.scalars)
            self.__write_json(path, existing)
        for field, items in changes.appends.items():
            path = self.__append_path(key, field, target_dir)
            with open(path, "a") as f:
                for item in items:
                    f.write(json.dumps(item) + "\n")

    def __load_from(self, target_dir: str, key: str) -> dict[str, Any] | None:
        result: dict[str, Any] = self.__read_json(self.__scalar_path(key, target_dir)) or {}
        prefix = self.__sanitize_key(key) + "."
        suffix = ".jsonl"
        if os.path.isdir(target_dir):
            for filename in os.listdir(target_dir):
                if filename.startswith(prefix) and filename.endswith(suffix):
                    field = filename[len(prefix) : -len(suffix)]
                    result[field] = self.__read_jsonl(os.path.join(target_dir, filename))
        return result if result else None

    def __scalar_path(self, key: str, target_dir: str) -> str:
        return os.path.join(target_dir, f"{self.__sanitize_key(key)}.json")

    def __append_path(self, key: str, field: str, target_dir: str) -> str:
        return os.path.join(target_dir, f"{self.__sanitize_key(key)}.{field}.jsonl")

    @staticmethod
    def __sanitize_key(key: str) -> str:
        return _UNSAFE_CHARS.sub("_", key)

    @staticmethod
    def __read_json(path: str) -> Any | None:
        if not os.path.exists(path):
            return None
        with open(path) as f:
            return json.load(f)

    @staticmethod
    def __read_jsonl(path: str) -> list[Any]:
        with open(path) as f:
            return [json.loads(line) for line in f if line.strip()]

    @staticmethod
    def __write_json(path: str, data: Any) -> None:
        with open(path, "w") as f:
            json.dump(data, f)
