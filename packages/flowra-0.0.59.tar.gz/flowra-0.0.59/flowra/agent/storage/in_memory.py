import copy
import dataclasses
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from .session_storage import ChangeSet, SessionStorage

__all__ = ["InMemorySessionSnapshot", "InMemorySessionStorage"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class InMemorySessionSnapshot:
    """Immutable deep-copy snapshot of all data inside an InMemorySessionStorage."""

    execution: dict[str, Any] | None
    node_states: dict[str, dict[str, Any]]
    ephemeral_states: dict[str, dict[str, Any]] = dataclasses.field(default_factory=dict)


class InMemorySessionStorage(SessionStorage):
    __slots__ = ("__ephemeral_states", "__execution", "__node_states")

    def __init__(self, snapshot: InMemorySessionSnapshot | None = None) -> None:
        if snapshot is not None:
            self.__execution: dict[str, Any] | None = copy.deepcopy(snapshot.execution)
            self.__node_states: dict[str, dict[str, Any]] = copy.deepcopy(snapshot.node_states)
            self.__ephemeral_states: dict[str, dict[str, Any]] = copy.deepcopy(snapshot.ephemeral_states)
        else:
            self.__execution = None
            self.__node_states = {}
            self.__ephemeral_states = {}

    def snapshot(self) -> InMemorySessionSnapshot:
        """Return a deep-copy snapshot of all stored data."""
        return InMemorySessionSnapshot(
            execution=copy.deepcopy(self.__execution),
            node_states=copy.deepcopy(self.__node_states),
            ephemeral_states=copy.deepcopy(self.__ephemeral_states),
        )

    @asynccontextmanager
    async def begin_transaction(self) -> AsyncIterator[None]:
        yield

    async def has_execution(self) -> bool:
        return self.__execution is not None

    async def save_execution(self, execution: dict[str, Any]) -> None:
        self.__execution = execution

    async def load_execution(self) -> dict[str, Any] | None:
        return self.__execution

    async def clear_execution(self) -> None:
        self.__execution = None

    async def save(self, key: str, changes: ChangeSet) -> None:
        self.__apply_changes(self.__node_states, key, changes)

    async def load(self, key: str) -> dict[str, Any] | None:
        return self.__load_from(self.__node_states, key)

    async def save_ephemeral(self, key: str, changes: ChangeSet) -> None:
        self.__apply_changes(self.__ephemeral_states, key, changes)

    async def load_ephemeral(self, key: str) -> dict[str, Any] | None:
        return self.__load_from(self.__ephemeral_states, key)

    async def clear_ephemeral(self) -> None:
        self.__ephemeral_states.clear()

    @staticmethod
    def __apply_changes(store: dict[str, dict[str, Any]], key: str, changes: ChangeSet) -> None:
        if key not in store:
            store[key] = {}
        state = store[key]
        state.update(changes.scalars)
        for k, items in changes.appends.items():
            if k not in state:
                state[k] = []
            state[k].extend(items)

    @staticmethod
    def __load_from(store: dict[str, dict[str, Any]], key: str) -> dict[str, Any] | None:
        state = store.get(key)
        if state is None:
            return None
        return dict(state)
