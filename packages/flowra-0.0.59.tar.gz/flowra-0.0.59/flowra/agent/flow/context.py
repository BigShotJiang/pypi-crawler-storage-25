import dataclasses
from typing import Any, overload

from ..definition import AbstractAgent

__all__ = [
    "AgentInfo",
    "ExecutionContext",
    "ExecutionFrame",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AgentInfo:
    """An agent in the registration hierarchy."""

    name: str
    path: str
    source_type: type[AbstractAgent] | None
    parent: "AgentInfo | None"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ExecutionFrame:
    """One frame in the execution stack."""

    agent: AgentInfo
    spec: Any | None = None
    tag: str | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ExecutionContext:
    """Execution metadata describing where an action is happening.

    ``frame`` is the current agent.
    ``stack`` is the full execution path from root to current (inclusive).
    """

    frame: ExecutionFrame
    stack: tuple[ExecutionFrame, ...]

    def find_spec[T](self, spec_type: type[T]) -> T | None:
        """Find the nearest spec of the given type (current frame first, then up)."""
        for frame in reversed(self.stack):
            if isinstance(frame.spec, spec_type):
                return frame.spec
        return None

    def get_spec[T](self, spec_type: type[T]) -> T:
        """Find the nearest spec of the given type or raise ``LookupError``."""
        result = self.find_spec(spec_type)
        if result is None:
            raise LookupError(f"No frame with spec type {spec_type.__name__} in execution stack")
        return result

    @overload
    def find_frame(self, *, spec_type: type) -> ExecutionFrame | None: ...
    @overload
    def find_frame[A: AbstractAgent](self, *, agent_type: type[A]) -> ExecutionFrame | None: ...

    def find_frame(
        self,
        *,
        spec_type: type | None = None,
        agent_type: type[AbstractAgent] | None = None,
    ) -> ExecutionFrame | None:
        """Find the nearest frame matching the criteria (current first, then up)."""
        return self.__find_frame(spec_type=spec_type, agent_type=agent_type)

    @overload
    def get_frame(self, *, spec_type: type) -> ExecutionFrame: ...
    @overload
    def get_frame[A: AbstractAgent](self, *, agent_type: type[A]) -> ExecutionFrame: ...

    def get_frame(
        self,
        *,
        spec_type: type | None = None,
        agent_type: type[AbstractAgent] | None = None,
    ) -> ExecutionFrame:
        """Find the nearest frame matching the criteria or raise ``LookupError``."""
        result = self.__find_frame(spec_type=spec_type, agent_type=agent_type)
        if result is None:
            criteria: list[str] = []
            if spec_type is not None:
                criteria.append(f"spec_type={spec_type.__name__}")
            if agent_type is not None:
                criteria.append(f"agent_type={agent_type.__name__}")
            raise LookupError(f"No frame with {', '.join(criteria)} in execution stack")
        return result

    def __find_frame(
        self,
        *,
        spec_type: type | None = None,
        agent_type: type[AbstractAgent] | None = None,
    ) -> ExecutionFrame | None:
        if spec_type is None and agent_type is None:
            raise TypeError("At least one of spec_type or agent_type must be provided")
        for frame in reversed(self.stack):
            if spec_type is not None and not isinstance(frame.spec, spec_type):
                continue
            if agent_type is not None and frame.agent.source_type is not agent_type:
                continue
            return frame
        return None
