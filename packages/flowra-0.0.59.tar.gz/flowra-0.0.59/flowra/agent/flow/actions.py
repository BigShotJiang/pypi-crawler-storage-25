import dataclasses
from typing import Any

from ..definition import AgentRef, StepRef, resolve_step_ref
from ..state.persistent import PersistentState

__all__ = [
    "CallAgent",
    "CallStep",
    "GotoAgent",
    "GotoStep",
    "PersistentState",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class GotoStep:
    step: str
    spec: Any | None

    def __init__(
        self,
        *,
        step: StepRef,
        spec: Any | None = None,
    ) -> None:
        object.__setattr__(self, "step", resolve_step_ref(step))
        object.__setattr__(self, "spec", spec)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class CallStep:
    step: str
    spec: Any | None
    fork_ephemeral: bool
    tag: str | None

    def __init__(
        self,
        *,
        step: StepRef,
        spec: Any | None = None,
        fork_ephemeral: bool = False,
        tag: str | None = None,
    ) -> None:
        object.__setattr__(self, "step", resolve_step_ref(step))
        object.__setattr__(self, "spec", spec)
        object.__setattr__(self, "fork_ephemeral", fork_ephemeral)
        object.__setattr__(self, "tag", tag)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GotoAgent:
    agent: AgentRef
    spec: Any | None = None
    state: PersistentState = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CallAgent:
    agent: AgentRef
    spec: Any | None = None
    state: PersistentState = None
    tag: str | None = None
