import dataclasses

from ..definition import StepRef, resolve_step_ref
from .actions import CallAgent, CallStep, GotoAgent, GotoStep

__all__ = [
    "Spawn",
    "SpawnChild",
    "SpawnNode",
    "StepAction",
    "WhenAll",
    "WhenAny",
    "WhenN",
]

type SpawnChild = CallStep | CallAgent


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class WhenAll:
    nodes: tuple["SpawnNode", ...]

    def __init__(self, *nodes: "SpawnNode") -> None:
        object.__setattr__(self, "nodes", nodes)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class WhenAny:
    nodes: tuple["SpawnNode", ...]

    def __init__(self, *nodes: "SpawnNode") -> None:
        if not nodes:
            raise ValueError("WhenAny requires at least 1 node")
        object.__setattr__(self, "nodes", nodes)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class WhenN:
    nodes: tuple["SpawnNode", ...]
    n: int

    def __init__(self, *nodes: "SpawnNode", n: int) -> None:
        if n < 0 or n > len(nodes):
            raise ValueError(f"WhenN: n must be between 0 and {len(nodes)}, got {n}")
        object.__setattr__(self, "nodes", nodes)
        object.__setattr__(self, "n", n)


type SpawnNode = SpawnChild | WhenAll | WhenAny | WhenN


def _flatten_leaves(node: SpawnNode, out: list[SpawnChild]) -> None:
    match node:
        case CallStep() | CallAgent():
            out.append(node)
        case WhenAll(nodes=nodes) | WhenAny(nodes=nodes) | WhenN(nodes=nodes):
            for child in nodes:
                _flatten_leaves(child, out)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class Spawn:
    root: SpawnNode
    children: list[SpawnChild]
    then: str

    def __init__(
        self,
        *args: SpawnNode,
        children: list[SpawnChild] | None = None,
        then: StepRef,
    ) -> None:
        if args and children is not None:
            raise TypeError("Cannot specify both positional SpawnNode args and 'children' keyword")
        if children is not None:
            if len(children) > 1:
                root: SpawnNode = WhenAll(*children)
            elif len(children) == 1:
                root = children[0]
            else:
                root = WhenAll()
            flat = list(children)
        elif args:
            args_list = list(args)
            if len(args_list) == 1 and isinstance(args_list[0], (WhenAll, WhenAny, WhenN)):
                root = args_list[0]
            elif len(args_list) > 1:
                root = WhenAll(*args_list)
            else:
                root = args_list[0]
            flat: list[SpawnChild] = []
            _flatten_leaves(root, flat)
        else:
            raise TypeError("Spawn requires at least one child")
        object.__setattr__(self, "root", root)
        object.__setattr__(self, "children", flat)
        object.__setattr__(self, "then", resolve_step_ref(then))


type StepAction = GotoStep | GotoAgent | Spawn
