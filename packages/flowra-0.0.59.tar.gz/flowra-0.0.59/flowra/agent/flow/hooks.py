import dataclasses
import inspect
import logging
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from typing import Any

from ..definition import AbstractAgent, AgentRegistry
from ..definition._path import resolve_path
from .context import ExecutionContext

__all__ = [
    "Event",
    "HookSubscription",
    "Hooks",
    "SpanExitHandler",
]

_logger = logging.getLogger(__name__)


type SpanExitHandler = Callable[[BaseException | None], None | Awaitable[None]]
"""Exit callback returned by a span handler. Called when the span closes.

Receives the error (if the span ended due to an exception) or ``None``.
May be sync or async — the emitter checks ``isawaitable`` at runtime.
"""


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Event[T]:
    """Generic envelope wrapping event/span data with execution context.

    Used for both regular events (``hooks.on``) and span enter handlers
    (``hooks.on_span``), providing a consistent interface.
    """

    data: T
    context: ExecutionContext


# ---------------------------------------------------------------------------
# ABC hierarchy
# ---------------------------------------------------------------------------


class HookSubscription(ABC):
    """Subscribe to events and spans.

    **Baseline (agent-context subscriptions).** A handler fires only when
    the subscriber appears as a *strict* ancestor in the event's call
    stack — i.e. the subscriber's registry path is on
    ``event.context.stack`` somewhere above the current emitter. Self-emits
    are never delivered back to the subscriber. Global subscriptions
    (``runtime.hooks.on(...)`` without an agent context) skip the baseline
    and match every emit.

    ``scope`` — optional registry-path filter on the emitting agent. When
    set, the emitter's ``frame.agent.path`` must be at or under the resolved
    scope. Strings follow the flowra path convention
    (``/foo`` absolute, ``foo`` / ``./foo`` relative down from the
    subscriber, ``../foo`` relative up, ``.`` self, ``..`` parent).
    A ``type[AbstractAgent]`` is resolved through the registry (walking up
    from the subscriber's path) to its registered path.

    ``during`` — optional call-stack filter. When set, some frame *below*
    the subscriber in the event's stack must match: a ``type`` matches when
    ``frame.agent.source_type`` is that type; a string matches when the
    frame's path is at or under the resolved path. Frames above the
    subscriber are ignored — subscribers cannot reach across to their
    ancestors.

    ``scope`` and ``during`` are independent additional filters AND'd with
    the baseline. Both default to ``None`` (no filter beyond the baseline).
    """

    @abstractmethod
    def on[E](
        self,
        event_type: type[E],
        handler: Callable[[Event[E]], Any],
        *,
        scope: str | type[AbstractAgent] | None = None,
        during: str | type[AbstractAgent] | None = None,
    ) -> None: ...

    @abstractmethod
    def on_span[T](
        self,
        span_type: type[T],
        handler: Callable[[Event[T]], SpanExitHandler | None | Awaitable[SpanExitHandler | None]],
        *,
        scope: str | type[AbstractAgent] | None = None,
        during: str | type[AbstractAgent] | None = None,
    ) -> None: ...


class Hooks(HookSubscription, ABC):
    """Subscribe + emit events and spans."""

    @abstractmethod
    async def emit[T](self, data: T) -> T: ...

    @abstractmethod
    async def open_span[T](self, span: T) -> T: ...

    @abstractmethod
    async def close_span(self, span: Any, *, error: BaseException | None = None) -> None: ...

    @abstractmethod
    def has_handlers(self, event_type: type) -> bool: ...

    @abstractmethod
    def has_span_handlers(self, span_type: type) -> bool: ...

    @asynccontextmanager
    async def span[T](self, span: T) -> AsyncIterator[T]:
        """Context manager: open span, yield, close on exit (with error on exception)."""
        await self.open_span(span)
        try:
            yield span
            await self.close_span(span)
        except BaseException as e:
            await self.close_span(span, error=e)
            raise


# ---------------------------------------------------------------------------
# Internal types
# ---------------------------------------------------------------------------


def _is_at_or_under(for_path: str, prefix: str) -> bool:
    """``for_path`` equals ``prefix`` or is a descendant of it. Empty prefix matches all."""
    if not prefix:
        return True
    return for_path == prefix or for_path.startswith(prefix + "/")


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _Subscription:
    """A single subscription stored in a handler group.

    Matching rules (see ``HookSubscription`` docstring for the full spec):

    - **Baseline (agent-context subscriptions only).** The subscriber must
      appear as a *strict* ancestor in ``event.context.stack`` — i.e. a
      frame with ``path == subscriber_path`` that is not the current
      emitter. Self-emits do not fire. Global subscriptions (no subscriber
      context) skip this check.
    - ``scope_prefix`` (if set) restricts the emitter's registry path to
      be at or under that path.
    - ``during_prefix`` / ``during_type`` (if set) require some frame
      *below* the subscriber in the stack to match.

    All applicable filters are ANDed.
    """

    handler: Callable[..., Any]
    subscriber_path: str
    scope_prefix: str | None
    during_prefix: str | None
    during_type: type[AbstractAgent] | None
    has_during: bool


class _HandlerGroup:
    __slots__ = ("global_subscriptions", "scoped_subscriptions")

    def __init__(self) -> None:
        # Registered from runtime.hooks (no agent context). No baseline filter.
        self.global_subscriptions: dict[type, list[_Subscription]] = {}
        # Registered from an agent context. Baseline filter always applies.
        self.scoped_subscriptions: dict[type, list[_Subscription]] = {}

    def clear_scoped(self) -> None:
        self.scoped_subscriptions.clear()


# ---------------------------------------------------------------------------
# Single implementation
# ---------------------------------------------------------------------------


class HooksImpl(Hooks):
    """Concrete implementation of Hooks.

    Root instance (``context=None``) owns the handler storage and is used as
    ``runtime.hooks``. Agent instances (``context=..., _root=root``) share
    the root's storage and add emit/span capabilities.
    """

    __slots__ = ("_context", "_events", "_exit_handlers", "_registry", "_root", "_spans")

    def __init__(
        self,
        *,
        context: ExecutionContext | None = None,
        _root: "HooksImpl | None" = None,
        registry: AgentRegistry | None = None,
    ) -> None:
        if _root is None:
            self._root: HooksImpl = self
            self._events = _HandlerGroup()
            self._spans = _HandlerGroup()
            self._registry: AgentRegistry | None = registry
        else:
            self._root = _root
            self._registry = None  # follow root's registry via property
        self._context = context
        self._exit_handlers: dict[int, list[Callable[..., Any]]] = {}

    # -- HookSubscription --

    def on[E](
        self,
        event_type: type[E],
        handler: Callable[[Event[E]], Any],
        *,
        scope: str | type[AbstractAgent] | None = None,
        during: str | type[AbstractAgent] | None = None,
    ) -> None:
        self.__register(self._root._events, event_type, handler, scope=scope, during=during)

    def on_span[T](
        self,
        span_type: type[T],
        handler: Callable[[Event[T]], SpanExitHandler | None | Awaitable[SpanExitHandler | None]],
        *,
        scope: str | type[AbstractAgent] | None = None,
        during: str | type[AbstractAgent] | None = None,
    ) -> None:
        self.__register(self._root._spans, span_type, handler, scope=scope, during=during)

    # -- Hooks --

    def has_handlers(self, event_type: type) -> bool:
        return self.__has(self._root._events, event_type)

    def has_span_handlers(self, span_type: type) -> bool:
        return self.__has(self._root._spans, span_type)

    async def emit[T](self, data: T) -> T:
        event = Event(data=data, context=self.__context)
        for handler in self.__resolve(self._root._events, type(data)):
            result = handler(event)
            if inspect.isawaitable(result):
                await result
        return event.data

    async def open_span[T](self, span: T) -> T:
        handlers = self.__resolve(self._root._spans, type(span))
        if handlers:
            event = Event(data=span, context=self.__context)
            exit_list: list[SpanExitHandler] = []
            for handler in reversed(handlers):
                try:
                    exit_handler = handler(event)
                    if inspect.isawaitable(exit_handler):
                        exit_handler = await exit_handler
                    if exit_handler is not None:
                        exit_list.append(exit_handler)
                except Exception:
                    _logger.exception("Span enter handler failed")
            if exit_list:
                self._exit_handlers[id(span)] = exit_list
        return span

    async def close_span(self, span: Any, *, error: BaseException | None = None) -> None:
        exit_list: list[SpanExitHandler] | None = self._exit_handlers.pop(id(span), None)
        if exit_list is None:
            return
        for exit_handler in reversed(exit_list):
            try:
                r = exit_handler(error)
                if inspect.isawaitable(r):
                    await r
            except Exception:
                _logger.exception("Span exit handler failed")

    # -- Lifecycle --

    def configure_registry(self, registry: AgentRegistry) -> None:
        """Attach an AgentRegistry to the root so type-based scopes resolve to paths."""
        self._root._registry = registry

    def for_agent(self, context: ExecutionContext) -> "HooksImpl":
        """Create an agent-scoped view sharing this instance's storage."""
        return HooksImpl(context=context, _root=self._root)

    def clear_scoped(self) -> None:
        """Clear all scoped handlers. Called between runs to prevent accumulation."""
        self._root._events.clear_scoped()
        self._root._spans.clear_scoped()

    # -- Internals --

    @property
    def __context(self) -> ExecutionContext:
        assert self._context is not None, "emit/span requires an agent context"
        return self._context

    def __register(
        self,
        group: _HandlerGroup,
        key: type,
        handler: Callable[..., Any],
        *,
        scope: str | type[AbstractAgent] | None,
        during: str | type[AbstractAgent] | None,
    ) -> None:
        subscriber_path = self._context.frame.agent.path if self._context is not None else ""
        scope_prefix = self.__resolve_scope(scope, subscriber_path)
        during_prefix, during_type, has_during = self.__resolve_during(during, subscriber_path)
        subscription = _Subscription(
            handler=handler,
            subscriber_path=subscriber_path,
            scope_prefix=scope_prefix,
            during_prefix=during_prefix,
            during_type=during_type,
            has_during=has_during,
        )
        bucket = group.global_subscriptions if self._context is None else group.scoped_subscriptions
        bucket.setdefault(key, []).append(subscription)

    def __resolve_scope(
        self,
        scope: str | type[AbstractAgent] | None,
        subscriber_path: str,
    ) -> str | None:
        if scope is None:
            return None
        if isinstance(scope, type):
            # Resolve the type via the registry, walking up from the subscriber's path
            # so subagents registered locally under the subscriber are found.
            return self.__require_registry().name_for_type(scope, context=subscriber_path)
        context: str | None = subscriber_path if subscriber_path else None
        return resolve_path(scope, context=context)

    def __resolve_during(
        self,
        during: str | type[AbstractAgent] | None,
        subscriber_path: str,
    ) -> tuple[str | None, type[AbstractAgent] | None, bool]:
        if during is None:
            return None, None, False
        if isinstance(during, type):
            return None, during, True
        context: str | None = subscriber_path if subscriber_path else None
        return resolve_path(during, context=context), None, True

    def __require_registry(self) -> AgentRegistry:
        registry = self._root._registry
        if registry is None:
            raise RuntimeError(
                "Type-based scope requires the registry; HooksImpl must be constructed or configured with one."
            )
        return registry

    def __resolve(self, group: _HandlerGroup, key: type) -> list[Callable[..., Any]]:
        result: list[Callable[..., Any]] = []
        for subscription in group.global_subscriptions.get(key, []):
            if self.__matches(subscription, is_scoped=False):
                result.append(subscription.handler)
        if self._context is not None:
            for subscription in group.scoped_subscriptions.get(key, []):
                if self.__matches(subscription, is_scoped=True):
                    result.append(subscription.handler)
        return result

    def __matches(self, subscription: _Subscription, *, is_scoped: bool) -> bool:
        context = self._context
        assert context is not None, "matching requires an agent context"
        stack = context.stack

        # Baseline (agent-context subscriptions): subscriber must be a strict ancestor
        # in the event's call stack. Skipped for global subscriptions.
        subscriber_index: int | None
        if is_scoped:
            subscriber_index = self.__find_strict_ancestor_index(stack, subscription.subscriber_path)
            if subscriber_index is None:
                return False
        else:
            subscriber_index = None

        emitter_path = stack[-1].agent.path

        if subscription.scope_prefix is not None and not _is_at_or_under(emitter_path, subscription.scope_prefix):
            return False

        if subscription.has_during:
            below_frames = stack[subscriber_index + 1 :] if subscriber_index is not None else stack
            if not self.__during_matches(subscription, below_frames):
                return False

        return True

    @staticmethod
    def __find_strict_ancestor_index(stack: tuple[Any, ...], subscriber_path: str) -> int | None:
        """Return the index of the *nearest* frame whose path matches, if it is
        a strict ancestor (not the emitter). Walking from the emitter upward
        keeps semantics stable under recursion: when the same path appears
        multiple times on the stack, the innermost occurrence wins so
        ``during=`` filters scan only the frames below the current
        invocation. ``None`` means the subscriber is not a strict ancestor
        (including the case where it IS the emitter).
        """
        for i in range(len(stack) - 2, -1, -1):
            if stack[i].agent.path == subscriber_path:
                return i
        return None

    @staticmethod
    def __during_matches(subscription: _Subscription, frames: tuple[Any, ...]) -> bool:
        for frame in frames:
            if subscription.during_type is not None and frame.agent.source_type is not subscription.during_type:
                continue
            if subscription.during_prefix is not None and not _is_at_or_under(
                frame.agent.path, subscription.during_prefix
            ):
                continue
            return True
        return False

    def __has(self, group: _HandlerGroup, key: type) -> bool:
        """Would any handler fire if an event of ``key`` type were emitted right now?

        For root-level (no context) callers, returns True if any global subscription
        exists. For agent-level callers, applies the same filters as ``emit`` would.
        """
        if self._context is None:
            return bool(group.global_subscriptions.get(key))
        for subscription in group.global_subscriptions.get(key, []):
            if self.__matches(subscription, is_scoped=False):
                return True
        for subscription in group.scoped_subscriptions.get(key, []):
            if self.__matches(subscription, is_scoped=True):
                return True
        return False
