import abc
from typing import Any, overload

__all__ = ["ServiceLocator"]


class ServiceLocator(abc.ABC):
    __slots__ = ()

    @overload
    def provide[T](self, service_type: type[T], instance: T, /) -> None: ...
    @overload
    def provide(self, instance: object, /) -> None: ...

    def provide(self, /, *args: Any) -> None:
        if len(args) == 2:
            self._do_provide(args[0], args[1])
        elif len(args) == 1:
            self._do_provide(type(args[0]), args[0])
        else:
            raise TypeError(f"provide() takes 1 or 2 positional arguments, got {len(args)}")

    @abc.abstractmethod
    def _do_provide(self, service_type: type, instance: Any) -> None: ...

    @property
    @abc.abstractmethod
    def services(self) -> dict[type, Any]: ...
