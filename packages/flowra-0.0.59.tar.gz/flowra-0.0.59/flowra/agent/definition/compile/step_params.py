import dataclasses
import types
from typing import Annotated, Any, Union, get_args, get_origin

from .. import agent_arg
from .type_helpers import (
    SUPPORTED_VALUE_TYPES,
    flatten_types,
    get_type_hints,
    is_nullable,
    resolve_hint,
    to_isinstance_type,
    unwrap_optional,
)

__all__ = ["PluralBind", "SingleBind", "StepParam", "compile_step_params", "find_spec_types"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SingleBind:
    """Bind the param to exactly one candidate value."""

    match_type: type | tuple[type, ...]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class PluralBind:
    """Collect every matching child result into a list.

    An interpretation is considered "matched" only when ≥1 child result
    satisfies ``element_type``. If every interpretation of a param fails to
    match, the resolver falls back to ``[]`` when the param has any
    ``PluralBind`` interpretation (i.e., the declared type is ``list[X]``).
    This keeps ambiguity detection useful when a list child is also present.
    """

    element_type: type | tuple[type, ...]


type BindInterpretation = SingleBind | PluralBind


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class StepParam:
    name: str
    interpretations: tuple[BindInterpretation, ...]
    nullable: bool = False
    check_agent_spec: bool = True
    check_step_spec: bool = True
    check_children: bool = True
    check_services: bool = True
    child_tag: str | None = None


def compile_step_params(method: Any) -> tuple[StepParam, ...]:
    """Compile step method parameters into binding descriptors."""
    hints = get_type_hints(method)
    params: list[StepParam] = []
    for name, hint in hints.items():
        if name == "self" or name == "return":
            continue

        marker, inner_type = _find_marker(hint)
        raw_type = inner_type if marker is not None else hint

        check_agent_spec = True
        check_step_spec = True
        check_children = True
        check_services = True
        child_tag: str | None = None

        if marker is agent_arg.AGENT_SPEC:
            check_step_spec = False
            check_children = False
            check_services = False
        elif marker is agent_arg.STEP_SPEC:
            check_agent_spec = False
            check_children = False
            check_services = False
        elif isinstance(marker, (type(agent_arg.CHILD), type(agent_arg.CHILDREN))):
            check_agent_spec = False
            check_step_spec = False
            check_services = False
            child_tag = marker.tag
        elif marker is agent_arg.SERVICE:
            check_agent_spec = False
            check_step_spec = False
            check_children = False

        step_name = getattr(method, "__qualname__", getattr(method, "__name__", repr(method)))
        interpretations = _compile_interpretations(raw_type, marker, name, step_name)
        if not check_services:
            for interp in interpretations:
                _validate_interpretation_type(interp, name, method)

        params.append(
            StepParam(
                name=name,
                interpretations=interpretations,
                nullable=is_nullable(raw_type),
                check_agent_spec=check_agent_spec,
                check_step_spec=check_step_spec,
                check_children=check_children,
                check_services=check_services,
                child_tag=child_tag,
            )
        )
    return tuple(params)


def find_spec_types(method: Any) -> frozenset[type]:
    """Find spec types from a step method's agent_arg.AGENT_SPEC-annotated parameter."""
    hints = get_type_hints(method)
    for name, hint in hints.items():
        if name == "self" or name == "return":
            continue
        marker, inner_type = _find_marker(hint)
        if marker is agent_arg.AGENT_SPEC:
            unwrapped = unwrap_optional(inner_type)
            flat = flatten_types(unwrapped)
            concrete = [t for t in flat if t is not type(None) and isinstance(t, type)]
            if concrete:
                return frozenset(concrete)
    return frozenset()


def _find_marker(hint: Any) -> tuple[Any, Any]:
    """Find an agent_arg marker in an Annotated type hint."""
    if get_origin(hint) is Annotated:
        return _check_annotated_metadata(hint)
    if isinstance(hint, types.UnionType) or get_origin(hint) is Union:
        for arg in get_args(hint):
            if arg is type(None):
                continue
            if get_origin(arg) is Annotated:
                return _check_annotated_metadata(arg)
    return None, None


def _check_annotated_metadata(annotated_hint: Any) -> tuple[Any, Any]:
    args = get_args(annotated_hint)
    if len(args) < 2:
        return None, None
    inner_type = args[0]
    for meta in args[1:]:
        if _is_marker(meta):
            return meta, inner_type
    return None, None


def _is_marker(meta: Any) -> bool:
    return (
        meta is agent_arg.AGENT_SPEC
        or meta is agent_arg.STEP_SPEC
        or meta is agent_arg.SERVICE
        or isinstance(meta, (type(agent_arg.CHILD), type(agent_arg.CHILDREN)))
    )


def _compile_interpretations(
    hint: Any,
    marker: Any,
    param_name: str,
    step_name: str,
) -> tuple[BindInterpretation, ...]:
    """Compile one or two binding interpretations per the CHILD/CHILDREN rules.

    - CHILD: strictly single, match_type is the full declared type's runtime shape.
    - CHILDREN: strictly plural, requires list[X] annotation, element_type = X.
    - No marker on list[X]: both Single(list) and Plural(X) — engine picks unique at bind time.
    - No marker on non-list: Single(runtime_type).
    """
    if isinstance(marker, type(agent_arg.CHILDREN)):
        unwrapped = unwrap_optional(hint)
        resolved = resolve_hint(unwrapped)
        origin = get_origin(resolved)
        if origin is not list and resolved is not list:
            raise TypeError(
                f"Step {step_name!r} parameter {param_name!r}: "
                f"agent_arg.CHILDREN requires a list[X] annotation, got {hint!r}"
            )
        element_type = _extract_list_element_type(resolved)
        return (PluralBind(element_type=element_type),)

    if isinstance(marker, type(agent_arg.CHILD)):
        return (SingleBind(match_type=_runtime_type(hint)),)

    unwrapped = unwrap_optional(hint)
    resolved = resolve_hint(unwrapped)
    origin = get_origin(resolved)
    if origin is list:
        element_type = _extract_list_element_type(resolved)
        return (
            SingleBind(match_type=list),
            PluralBind(element_type=element_type),
        )
    return (SingleBind(match_type=_runtime_type(hint)),)


def _extract_list_element_type(resolved: Any) -> type | tuple[type, ...]:
    if resolved is list:
        return object
    args = get_args(resolved)
    if not args:
        return object
    return to_isinstance_type(args[0])


def _runtime_type(hint: Any) -> type | tuple[type, ...]:
    """Collapse a type hint to the type(s) usable with isinstance().

    For generic aliases like ``list[int]`` or ``dict[str, int]``, returns the origin
    (``list`` / ``dict``) so that ``isinstance(value, origin)`` works at runtime.
    Unions are deferred to ``to_isinstance_type`` which flattens them into a tuple —
    on Python 3.14, ``get_origin`` of a union returns a concrete ``type``, so the
    plain ``isinstance(origin, type)`` check would mistakenly collapse the union.
    """
    unwrapped = unwrap_optional(hint)
    resolved = resolve_hint(unwrapped)
    if isinstance(resolved, types.UnionType) or get_origin(resolved) is Union:
        return to_isinstance_type(unwrapped)
    origin = get_origin(resolved)
    if origin is not None and isinstance(origin, type):
        return origin
    return to_isinstance_type(unwrapped)


def _validate_interpretation_type(interp: BindInterpretation, param_name: str, method: Any) -> None:
    if isinstance(interp, SingleBind):
        _validate_step_param_type(interp.match_type, param_name, method)
    else:
        _validate_step_param_type(interp.element_type, param_name, method)


def _validate_step_param_type(match_type: type | tuple[type, ...], param_name: str, method: Any) -> None:
    if match_type is object:
        return
    types_to_check = match_type if isinstance(match_type, tuple) else (match_type,)
    for t in types_to_check:
        if not (dataclasses.is_dataclass(t) or issubclass(t, SUPPORTED_VALUE_TYPES)):
            step_name = getattr(method, "__qualname__", getattr(method, "__name__", repr(method)))
            raise TypeError(
                f"Step {step_name!r} parameter {param_name!r}: type {t.__name__} must be a "
                f"dataclass, a primitive (str, int, float, bool, bytes, UUID, datetime, date, "
                f"time, Decimal), list, or dict"
            )
