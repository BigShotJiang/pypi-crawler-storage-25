import types
import typing
import uuid
from datetime import date, datetime, time
from decimal import Decimal
from typing import Annotated, Any, TypeAliasType, Union, get_args, get_origin

__all__ = [
    "SUPPORTED_VALUE_TYPES",
    "extract_service_type",
    "flatten_types",
    "get_type_hints",
    "is_nullable",
    "resolve_hint",
    "to_isinstance_type",
    "unwrap_optional",
]

SUPPORTED_VALUE_TYPES: tuple[type, ...] = (
    str,
    int,
    float,
    bool,
    bytes,
    uuid.UUID,
    datetime,
    date,
    time,
    Decimal,
    list,
    dict,
)


def resolve_hint(hint: Any) -> Any:
    """Unwrap TypeAliasType to the underlying type."""
    while isinstance(hint, TypeAliasType):
        hint = hint.__value__
    return hint


def flatten_types(t: Any) -> list[Any]:
    """Flatten unions into a list of individual types. Non-unions return [t]."""
    t = resolve_hint(t)
    if isinstance(t, types.UnionType) or get_origin(t) is Union:
        result: list[Any] = []
        for arg in get_args(t):
            result.extend(flatten_types(arg))
        return result
    return [t]


def is_nullable(tp: Any) -> bool:
    """Check if type allows None (T | None, Optional[T])."""
    tp = resolve_hint(tp)
    if get_origin(tp) is Annotated:
        tp = get_args(tp)[0]
    if isinstance(tp, types.UnionType) or get_origin(tp) is Union:
        return type(None) in get_args(tp)
    return False


def unwrap_optional(tp: Any) -> Any:
    """Strip None from a union type. Non-union types pass through unchanged."""
    tp = resolve_hint(tp)
    if isinstance(tp, types.UnionType) or get_origin(tp) is Union:
        non_none = [a for a in get_args(tp) if a is not type(None)]
        if len(non_none) == 1:
            return resolve_hint(non_none[0])
        if len(non_none) > 1:
            return Union[tuple(non_none)]  # noqa: UP007
    return tp


def get_type_hints(obj: Any) -> dict[str, Any]:
    """Safe wrapper around typing.get_type_hints with include_extras=True."""
    try:
        return typing.get_type_hints(obj, include_extras=True)
    except Exception:
        return {}


def extract_service_type(resolved: Any) -> type | None:
    """Extract the service type from an __init__ parameter hint.

    Unwraps Annotated and Optional. Returns None if the hint
    doesn't resolve to a concrete type.
    """
    if get_origin(resolved) is Annotated:
        resolved = get_args(resolved)[0]
    if isinstance(resolved, type):
        return resolved
    if isinstance(resolved, types.UnionType) or get_origin(resolved) is Union:
        non_none = [a for a in get_args(resolved) if a is not type(None)]
        if len(non_none) == 1 and isinstance(non_none[0], type):
            return non_none[0]
    return None


def to_isinstance_type(hint: Any) -> type | tuple[type, ...]:
    """Convert a type hint to a type (or tuple) usable with isinstance().

    Returns ``object`` as a wildcard when the hint is Any or unresolvable.
    """
    unwrapped = unwrap_optional(hint)
    if unwrapped is Any:
        return object
    flat = flatten_types(unwrapped)
    concrete = [t for t in flat if t is not type(None) and isinstance(t, type)]
    if not concrete:
        return object
    if len(concrete) == 1:
        return concrete[0]
    return tuple(concrete)
