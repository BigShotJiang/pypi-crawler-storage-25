import dataclasses
import inspect
from typing import Any, get_origin

from ...flow import CallAgent, CallStep, GotoAgent, GotoStep, Spawn
from .type_helpers import SUPPORTED_VALUE_TYPES, flatten_types, get_type_hints

__all__ = ["validate_step_return_type"]


def validate_step_return_type(method: Any, tag: str) -> frozenset[type]:
    """Validate step return type and extract result (non-action) types."""
    hints = get_type_hints(method)
    ret = hints.get("return")
    if ret is None or ret is inspect.Parameter.empty:
        return frozenset()
    ret_types = flatten_types(ret)
    result_types: set[type] = set()
    for raw in ret_types:
        if raw is type(None):
            continue
        t = _unwrap_generic(raw)
        if t is None:
            return frozenset()
        if issubclass(t, (GotoStep, GotoAgent, Spawn)):
            continue
        if issubclass(t, (CallStep, CallAgent)):
            raise TypeError(
                f"Step {tag!r} return type {t.__name__} is not a valid StepResult "
                f"(must be GotoStep | GotoAgent | Spawn | dataclass | primitive | list | dict | None)"
            )
        if not (dataclasses.is_dataclass(t) or issubclass(t, SUPPORTED_VALUE_TYPES)):
            raise TypeError(
                f"Step {tag!r} return type {t.__name__} must be a dataclass, a primitive "
                f"(str, int, float, bool, bytes, UUID, datetime, date, time, Decimal), "
                f"list, or dict"
            )
        result_types.add(t)
    return frozenset(result_types)


def _unwrap_generic(t: Any) -> type | None:
    """Return a concrete runtime type for ``t``, unwrapping generic aliases like ``list[int]``.

    Returns ``None`` if ``t`` can't be collapsed to a type (opaque hint — caller bails).
    """
    if isinstance(t, type):
        return t
    origin = get_origin(t)
    if isinstance(origin, type):
        return origin
    return None
