import inspect
from collections.abc import Callable, Coroutine
from typing import Any

from ...services import ServiceLocator
from ..model import AgentInstance, ChildOutput
from .init_params import InitParam
from .step_params import BindInterpretation, PluralBind, SingleBind, StepParam
from .steps import CompiledStep

__all__ = ["create_instance"]

_NO_MATCH: Any = object()


def create_instance(
    agent_cls: type,
    init_params: tuple[InitParam, ...],
    compiled_steps: dict[str, CompiledStep],
    sl: ServiceLocator,
    agent_spec: Any | None = None,
) -> AgentInstance:
    """Instantiate agent and return an AgentInstance with a bound call_step closure."""
    all_services = dict(sl.services)
    kwargs: dict[str, Any] = {}
    for ip in init_params:
        if ip.is_spec:
            if agent_spec is not None and isinstance(agent_spec, ip.service_type):
                kwargs[ip.name] = agent_spec
            elif ip.nullable:
                kwargs[ip.name] = None
        else:
            if ip.service_type in all_services:
                kwargs[ip.name] = all_services[ip.service_type]
            elif ip.nullable:
                kwargs[ip.name] = None
    agent = agent_cls(**kwargs)

    raw_hook = getattr(agent, "__post_init__", None)
    if raw_hook is not None:

        async def _post_init_wrapper() -> None:
            result = raw_hook()
            if inspect.isawaitable(result):
                await result

        post_init_fn: Callable[[], Coroutine[Any, Any, None]] | None = _post_init_wrapper
    else:
        post_init_fn = None

    def bind_step_args(
        step: CompiledStep,
        *,
        step_spec: Any | None = None,
        child_outputs: list[ChildOutput] | None = None,
    ) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for param in step.params:
            matched: list[tuple[BindInterpretation, Any]] = []
            for interp in param.interpretations:
                value = _resolve_interpretation(
                    interp,
                    param,
                    step_spec=step_spec,
                    child_outputs=child_outputs,
                )
                if value is _NO_MATCH:
                    continue
                matched.append((interp, value))

            if len(matched) == 1:
                result[param.name] = matched[0][1]
            elif len(matched) > 1:
                raise RuntimeError(
                    f"Ambiguous binding for parameter '{param.name}' in step '{step.tag}': "
                    f"{len(matched)} interpretations matched ({[type(i).__name__ for i, _ in matched]})"
                )
            elif any(isinstance(i, PluralBind) for i in param.interpretations):
                # Declared as list[...] but nothing to collect — default to empty list.
                result[param.name] = []
            elif param.nullable:
                result[param.name] = None
        return result

    def _resolve_interpretation(
        interp: BindInterpretation,
        param: StepParam,
        *,
        step_spec: Any | None,
        child_outputs: list[ChildOutput] | None,
    ) -> Any:
        if isinstance(interp, SingleBind):
            return _resolve_single(interp, param, step_spec=step_spec, child_outputs=child_outputs)
        return _resolve_plural(interp, param, child_outputs=child_outputs)

    def _resolve_single(
        interp: SingleBind,
        param: StepParam,
        *,
        step_spec: Any | None,
        child_outputs: list[ChildOutput] | None,
    ) -> Any:
        mt = interp.match_type
        candidates: list[Any] = []

        if param.check_step_spec and step_spec is not None and isinstance(step_spec, mt):
            candidates.append(step_spec)

        if param.check_agent_spec and agent_spec is not None and isinstance(agent_spec, mt) and not candidates:
            candidates.append(agent_spec)

        if param.check_children and child_outputs:
            for co in child_outputs:
                if param.child_tag is not None and co.tag != param.child_tag:
                    continue
                if isinstance(co.result, mt):
                    candidates.append(co.result)

        if param.check_services and not candidates:
            service_type = mt if isinstance(mt, type) else None
            if service_type is not None and service_type in all_services:
                candidates.append(all_services[service_type])

        if not candidates:
            return _NO_MATCH
        if len(candidates) > 1:
            raise RuntimeError(
                f"Ambiguous binding for parameter '{param.name}': {len(candidates)} candidates match type {mt!r}"
            )
        return candidates[0]

    def _resolve_plural(
        interp: PluralBind,
        param: StepParam,
        *,
        child_outputs: list[ChildOutput] | None,
    ) -> Any:
        if not param.check_children or not child_outputs:
            return _NO_MATCH
        et = interp.element_type
        collected: list[Any] = []
        for co in child_outputs:
            if param.child_tag is not None and co.tag != param.child_tag:
                continue
            if isinstance(co.result, et):
                collected.append(co.result)
        if not collected:
            return _NO_MATCH
        return collected

    async def call_step(
        tag: str,
        spec: Any | None = None,
        child_outputs: list[ChildOutput] | None = None,
    ) -> Any:
        step = compiled_steps.get(tag)
        if step is None:
            raise RuntimeError(f"Step {tag!r} not found in {agent_cls.__name__}")
        step_kwargs = bind_step_args(step, step_spec=spec, child_outputs=child_outputs or [])
        result = getattr(agent, step.method_name)(**step_kwargs)
        if inspect.isawaitable(result):
            return await result
        return result

    return AgentInstance(call_step=call_step, post_init=post_init_fn)
