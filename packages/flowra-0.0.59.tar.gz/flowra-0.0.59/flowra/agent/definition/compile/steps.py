import dataclasses

from ..model import StepMeta
from ..step_helpers import get_step_tag
from .step_params import StepParam, compile_step_params, find_spec_types
from .step_validation import validate_step_return_type

__all__ = ["CompiledStep", "compile_steps"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CompiledStep:
    tag: str
    method_name: str
    spec_types: frozenset[type]
    params: tuple[StepParam, ...]


def compile_steps(
    agent_cls: type,
) -> tuple[dict[str, CompiledStep], dict[str, StepMeta]]:
    """Walk agent MRO, find all @step methods, compile each."""
    compiled_steps: dict[str, CompiledStep] = {}
    step_metas: dict[str, StepMeta] = {}

    for klass in reversed(agent_cls.__mro__):
        for attr_name in vars(klass):
            val = getattr(klass, attr_name, None)
            if not callable(val):
                continue
            tag = get_step_tag(val)
            if tag is None:
                continue

            result_types = validate_step_return_type(val, tag)
            params = compile_step_params(val)
            spec_types = find_spec_types(val)
            compiled_steps[tag] = CompiledStep(tag=tag, method_name=attr_name, spec_types=spec_types, params=params)
            step_metas[tag] = StepMeta(spec_types=spec_types, result_types=result_types)

    return compiled_steps, step_metas
