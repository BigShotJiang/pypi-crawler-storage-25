"""Annotated markers for agent parameter binding.

Used in ``__init__``, ``__post_init__``, and ``@step`` methods to control
how parameters are resolved.

Two child-binding markers — ``CHILD`` is strictly single (param matches
exactly one child result), ``CHILDREN`` is strictly plural (param type must
be ``list[X]`` and collects every matching child into a list). Without a
marker, ``list[X]`` admits both interpretations and the engine picks the
unique one at runtime (raises ``RuntimeError("Ambiguous binding ...")`` if
both match).

Usage::

    from flowra.agent import agent_arg

    class MyAgent(Agent[MySpec, MyResult]):
        def __init__(
            self,
            spec: Annotated[MySpec, agent_arg.AGENT_SPEC],
            provider: Annotated[LLMProvider, agent_arg.SERVICE],
        ) -> None: ...

        @step
        async def collect(
            self,
            r1: Annotated[Result1 | None, agent_arg.CHILD("r1")],
            results: Annotated[list[SubResult], agent_arg.CHILDREN],
        ) -> FinalResult: ...
"""

__all__ = [
    "AGENT_SPEC",
    "CHILD",
    "CHILDREN",
    "SERVICE",
    "STEP_SPEC",
]


class _Child:
    __slots__ = ("tag",)

    def __init__(self, tag: str | None = None) -> None:
        self.tag = tag

    def __call__(self, tag: str) -> "_Child":
        return _Child(tag)


class _Children:
    __slots__ = ("tag",)

    def __init__(self, tag: str | None = None) -> None:
        self.tag = tag

    def __call__(self, tag: str) -> "_Children":
        return _Children(tag)


AGENT_SPEC = object()
STEP_SPEC = object()
SERVICE = object()
CHILD = _Child()
CHILDREN = _Children()
