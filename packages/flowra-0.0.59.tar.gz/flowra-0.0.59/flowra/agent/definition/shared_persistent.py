"""Decorator to mark an agent as supporting shared persistent scope.

Usage::

    from flowra.agent import shared_persistent

    @shared_persistent
    class WorkerAgent(Agent[Spec, Result]):
        ...

When an agent is decorated with ``@shared_persistent``, the engine skips
the exclusive persistent key check — multiple concurrent instances can
share the same persistent key.
"""

import dataclasses

__all__ = ["shared_persistent"]


def shared_persistent[T: type](cls: T) -> T:
    """Mark an agent class as supporting shared persistent scope."""
    cls.__shared_persistent__ = True  # type: ignore[attr-defined]
    # Update already-compiled AgentDefinition (set by __init_subclass__)
    defn = getattr(cls, "__agent_definition__", None)
    if defn is not None:
        cls.__agent_definition__ = dataclasses.replace(defn, shared_persistent=True)  # type: ignore[attr-defined]
    return cls
