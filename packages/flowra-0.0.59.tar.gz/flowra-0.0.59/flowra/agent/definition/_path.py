"""Filesystem-style path resolution for agent registry paths.

Conventions:
    /foo/bar   -> absolute path (leading '/' stripped; stored without it).
    foo/bar    -> relative, down from ``context`` (like ``./foo/bar``).
                  If ``context`` is ``None`` (top-level call), treated as absolute.
    ./foo/bar  -> relative, down (explicit; requires a context).
    .          -> ``context`` itself.
    ..         -> parent of ``context``.
    ../foo     -> parent of ``context``, then descend into ``foo``.

The internal absolute representation has no leading slash (e.g. ``"root/chat"``).
The leading '/' in user-facing refs is just syntactic marking for absolute.
"""

__all__ = ["parent_path", "resolve_path"]


def resolve_path(ref: str, *, context: str | None) -> str:
    """Resolve a user-facing path ref to an absolute registry path.

    Raises ``ValueError`` for invalid refs (empty, malformed, escapes root,
    or explicit relative ref given without a context).
    """
    if not ref:
        raise ValueError("Path ref must be non-empty")

    if ref.startswith("/"):
        absolute = ref[1:]
        if not absolute:
            raise ValueError("Path ref '/' is the registry root, not an agent")
        _validate_segments(absolute, ref)
        return absolute

    if ref == ".":
        if context is None:
            raise ValueError(f"Relative path ref {ref!r} requires a context")
        if not context:
            raise ValueError("Cannot resolve '.' at registry root (no context)")
        return context

    if ref == "..":
        if context is None:
            raise ValueError(f"Relative path ref {ref!r} requires a context")
        return _parent_or_fail(context, ref)

    if ref.startswith("./"):
        if context is None:
            raise ValueError(f"Relative path ref {ref!r} requires a context")
        tail = ref[2:]
        if not tail:
            raise ValueError(f"Path ref {ref!r} is malformed")
        _validate_segments(tail, ref)
        return f"{context}/{tail}" if context else tail

    if ref.startswith("../"):
        if context is None:
            raise ValueError(f"Relative path ref {ref!r} requires a context")
        parent = _parent_or_fail(context, ref)
        remaining = ref[3:]
        while remaining.startswith("../"):
            parent = _parent_or_fail(parent, ref)
            remaining = remaining[3:]
        if remaining == "..":
            return _parent_or_fail(parent, ref)
        if not remaining:
            raise ValueError(f"Path ref {ref!r} is malformed")
        _validate_segments(remaining, ref)
        return f"{parent}/{remaining}" if parent else remaining

    if ref.startswith("."):
        # ".foo", ".." already handled above; anything else starting with "." is malformed
        raise ValueError(f"Path ref {ref!r} is malformed (use './' or '../' prefix)")

    _validate_segments(ref, ref)
    # Empty string context is the registry root (no "current directory"); treat like None.
    return f"{context}/{ref}" if context else ref


def parent_path(path: str) -> str:
    """Return the parent of an absolute path. Empty for root-level paths."""
    slash = path.rfind("/")
    return path[:slash] if slash >= 0 else ""


def _parent_or_fail(path: str, ref: str) -> str:
    if not path:
        raise ValueError(f"Path ref {ref!r} escapes registry root")
    return parent_path(path)


def _validate_segments(path: str, ref: str) -> None:
    if path.endswith("/"):
        raise ValueError(f"Path ref {ref!r} has a trailing slash")
    if "//" in path:
        raise ValueError(f"Path ref {ref!r} contains empty segment")
    for segment in path.split("/"):
        if segment.startswith(".") or segment == "":
            raise ValueError(f"Path ref {ref!r} contains invalid segment {segment!r}")
