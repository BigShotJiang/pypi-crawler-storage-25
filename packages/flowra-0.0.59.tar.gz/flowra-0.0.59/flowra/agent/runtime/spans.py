"""Engine-level span types for agent execution tracing."""

import dataclasses
from typing import Any

from ..flow import AgentInfo

__all__ = [
    "AgentSpan",
    "StepSpan",
]


# Mutable: spec set at open, result set before close.
@dataclasses.dataclass(slots=True, kw_only=True)
class AgentSpan:
    """One per agent identity on a node. Closed on completion or GotoAgent."""

    agent_info: AgentInfo
    spec: Any | None
    is_resume: bool = False
    result: Any | None = None


# Mutable: step/spec set at open, result set before close.
@dataclasses.dataclass(slots=True, kw_only=True)
class StepSpan:
    """One per step invocation. Closed when step returns."""

    agent_info: AgentInfo
    step: str
    spec: Any | None
    result: Any | None = None
