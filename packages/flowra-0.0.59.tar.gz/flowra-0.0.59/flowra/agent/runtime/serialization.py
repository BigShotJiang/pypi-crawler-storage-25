import base64
import dataclasses
import uuid
from datetime import date, datetime, time
from decimal import Decimal
from typing import Any

import marshmallow_recipe as mr

from ..flow import Interrupted

__all__ = ["deserialize_value", "serialize_value"]

_INTERRUPTED_TAG = "__interrupted__"


def serialize_value(value: Any, type_tags: dict[type, str]) -> Any:
    if value is None or isinstance(value, str | int | float | bool):
        return value
    if isinstance(value, Interrupted):
        return {_INTERRUPTED_TAG: True}
    if isinstance(value, bytes):
        return {"__bytes__": base64.b64encode(value).decode("ascii")}
    if isinstance(value, uuid.UUID):
        return {"__uuid__": str(value)}
    if isinstance(value, datetime):
        return {"__datetime__": value.isoformat()}
    if isinstance(value, date):
        return {"__date__": value.isoformat()}
    if isinstance(value, time):
        return {"__time__": value.isoformat()}
    if isinstance(value, Decimal):
        return {"__decimal__": str(value)}
    if isinstance(value, list):
        return [serialize_value(item, type_tags) for item in value]
    if isinstance(value, dict):
        return {k: serialize_value(v, type_tags) for k, v in value.items()}
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        tag = type_tags.get(type(value))
        if tag is None:
            raise TypeError(f"Type {type(value).__qualname__!r} is not registered in type_tags")
        return {"__type__": tag, "__data__": mr.dump(value)}
    raise TypeError(f"Cannot serialize {type(value).__name__}: {value!r}")


def deserialize_value(value: Any, type_registry: dict[str, type]) -> Any:
    if value is None or isinstance(value, str | int | float | bool):
        return value
    if isinstance(value, list):
        return [deserialize_value(item, type_registry) for item in value]
    if isinstance(value, dict):
        if "__bytes__" in value:
            return base64.b64decode(value["__bytes__"])
        if "__uuid__" in value:
            return uuid.UUID(value["__uuid__"])
        if "__datetime__" in value:
            return datetime.fromisoformat(value["__datetime__"])
        if "__date__" in value:
            return date.fromisoformat(value["__date__"])
        if "__time__" in value:
            return time.fromisoformat(value["__time__"])
        if "__decimal__" in value:
            return Decimal(value["__decimal__"])
        if _INTERRUPTED_TAG in value:
            return Interrupted()
        type_tag = value.get("__type__")
        if type_tag is None:
            return {k: deserialize_value(v, type_registry) for k, v in value.items()}
        cls = type_registry.get(type_tag)
        if cls is None:
            raise TypeError(f"Unknown type tag: {type_tag!r}")
        return mr.load(cls, value["__data__"])
    raise TypeError(f"Cannot deserialize {type(value).__name__}: {value!r}")
