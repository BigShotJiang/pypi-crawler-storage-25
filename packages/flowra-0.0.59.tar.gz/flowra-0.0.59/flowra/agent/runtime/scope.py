import logging
from collections.abc import Awaitable, Callable
from typing import Any, get_args, get_origin

from ..definition.compile import collect_dataclass_types
from ..runtime.serialization import deserialize_value, serialize_value
from ..services import ServiceLocator
from ..state import AgentStore, AppendOnlyList, Scalar, Scope
from ..storage import ChangeSet

logger = logging.getLogger(__name__)

__all__ = ["FlushCallback", "NamedScopeRegistry", "RuntimeScope", "ScopeData"]

type FlushCallback = Callable[[], Awaitable[None]]


class ScopeData(Scope):
    """Concrete scope implementation: slot storage, dirty tracking, lazy hydration.

    Supports two orderings:
    - ``slot()`` first, ``load_raw()`` later: ``load_raw`` retroactively hydrates existing slots
    - ``load_raw()`` first, ``slot()`` later: ``slot`` hydrates from raw data on creation
    """

    __slots__ = (
        "__append_only_lists",
        "__loaded",
        "__raw_data",
        "__scalars",
        "__slot_value_types",
        "__type_by_tag",
    )

    def __init__(self) -> None:
        self.__scalars: dict[str, Scalar] = {}
        self.__append_only_lists: dict[str, AppendOnlyList] = {}
        self.__slot_value_types: dict[str, type] = {}
        self.__type_by_tag: dict[str, type] = {}
        self.__raw_data: dict[str, Any] = {}
        self.__loaded = False

    def slot(self, cls: Any, key: str) -> Any:
        origin = get_origin(cls) or cls
        args = get_args(cls)
        if origin is Scalar:
            value_type = args[0] if args else None
            if value_type is not None:
                self.__slot_value_types[key] = value_type
                collect_dataclass_types(value_type, self.__type_by_tag)
            result = self.__create_scalar(key)
            self.__try_hydrate_slot(key)
            return result
        if origin is AppendOnlyList:
            value_type = args[0] if args else None
            if value_type is not None:
                self.__slot_value_types[key] = value_type
                collect_dataclass_types(value_type, self.__type_by_tag)
            result = self.__create_append_only(key)
            self.__try_hydrate_slot(key)
            return result
        raise TypeError(f"slot() cls must be Scalar[T] or AppendOnlyList[T], got {cls!r}")

    @property
    def is_loaded(self) -> bool:
        return self.__loaded

    def load_raw(self, data: dict[str, Any]) -> None:
        """Load raw serialized data from storage. Hydrates all declared slots that have data."""
        self.__raw_data = dict(data)
        self.__loaded = True
        for key in list(self.__raw_data):
            if key in self.__scalars or key in self.__append_only_lists:
                self.__try_hydrate_slot(key)

    def get_slot_value_types(self) -> dict[str, type]:
        return dict(self.__slot_value_types)

    @property
    def tag_by_type(self) -> dict[type, str]:
        return {v: k for k, v in self.__type_by_tag.items()}

    def get_changes(self) -> ChangeSet:
        tag_by_type = self.tag_by_type
        scalars: dict[str, Any] = {}
        appends: dict[str, list[Any]] = {}
        for key, sv in self.__scalars.items():
            if sv.is_dirty():
                scalars[key] = serialize_value(sv.get(), tag_by_type)
        for key, al in self.__append_only_lists.items():
            unflushed = al.get_unflushed()
            if unflushed:
                appends[key] = [serialize_value(item, tag_by_type) for item in unflushed]
        return ChangeSet(scalars=scalars, appends=appends)

    def mark_clean(self) -> None:
        for sv in self.__scalars.values():
            sv.mark_clean()
        for al in self.__append_only_lists.values():
            al.mark_clean()

    def snapshot(self) -> dict[str, Any]:
        data: dict[str, Any] = {}
        for key, sv in self.__scalars.items():
            if sv.has_value():
                data[key] = sv.get()
        for key, al in self.__append_only_lists.items():
            data[key] = al.get_all()
        return data

    def fork(self) -> "ScopeData":
        child = ScopeData()
        child.__slot_value_types = dict(self.__slot_value_types)
        child.__type_by_tag = dict(self.__type_by_tag)
        child.__loaded = True
        for key, sv in self.__scalars.items():
            child_sv: Scalar = Scalar()
            if sv.has_value():
                child_sv.restore(sv.get())
            child.__scalars[key] = child_sv
        for key, al in self.__append_only_lists.items():
            child_al: AppendOnlyList = AppendOnlyList()
            child_al.restore(al.get_all())
            child.__append_only_lists[key] = child_al
        return child

    def __create_scalar(self, key: str) -> Scalar:
        if key in self.__scalars:
            return self.__scalars[key]
        value: Scalar = Scalar()
        self.__scalars[key] = value
        return value

    def __create_append_only(self, key: str) -> AppendOnlyList:
        if key in self.__append_only_lists:
            return self.__append_only_lists[key]
        al: AppendOnlyList = AppendOnlyList()
        self.__append_only_lists[key] = al
        return al

    def __try_hydrate_slot(self, key: str) -> None:
        if key not in self.__raw_data:
            return
        raw_value = self.__raw_data.pop(key)
        deserialized = deserialize_value(raw_value, self.__type_by_tag)
        if key in self.__scalars:
            self.__scalars[key].restore(deserialized)
        elif key in self.__append_only_lists:
            self.__append_only_lists[key].restore(deserialized)


class NamedScopeRegistry:
    """Session-wide registry of named scopes. Created by AgentRuntime, shared across all RuntimeScope instances."""

    __slots__ = ("__scopes",)

    def __init__(self) -> None:
        self.__scopes: dict[str, ScopeData] = {}

    def get_or_create(self, name: str) -> ScopeData:
        if name not in self.__scopes:
            self.__scopes[name] = ScopeData()
        return self.__scopes[name]

    def all_scopes(self) -> dict[str, ScopeData]:
        return dict(self.__scopes)


class RuntimeScope(AgentStore, ServiceLocator):
    """AgentStore + ServiceLocator for agents. Provides access to ephemeral, persistent, and named scopes."""

    __slots__ = (
        "__ephemeral",
        "__flush_callback",
        "__named_scope_registry",
        "__parent_services",
        "__persistent",
        "__services",
    )

    def __init__(
        self,
        parent_services: dict[type, Any] | None = None,
        *,
        named_scope_registry: NamedScopeRegistry,
        ephemeral: ScopeData | None = None,
        persistent: ScopeData | None = None,
    ) -> None:
        self.__parent_services: dict[type, Any] = parent_services or {}
        self.__services: dict[type, Any] = {}
        self.__flush_callback: FlushCallback | None = None
        self.__named_scope_registry = named_scope_registry
        self.__ephemeral = ephemeral or ScopeData()
        self.__persistent = persistent or ScopeData()

    @property
    def ephemeral(self) -> ScopeData:
        return self.__ephemeral

    @property
    def persistent(self) -> ScopeData:
        return self.__persistent

    def scope(self, name: str) -> Scope:
        return self.__named_scope_registry.get_or_create(name)

    @property
    def named_scope_registry(self) -> NamedScopeRegistry:
        return self.__named_scope_registry

    def fork_ephemeral(self, parent_services: dict[type, Any] | None = None) -> "RuntimeScope":
        """Create a child scope with forked ephemeral state. Persistent and named scopes stay shared."""
        return RuntimeScope(
            parent_services=parent_services,
            named_scope_registry=self.__named_scope_registry,
            ephemeral=self.__ephemeral.fork(),
            persistent=self.__persistent,
        )

    def _do_provide(self, service_type: type, instance: Any) -> None:
        if not isinstance(instance, service_type):
            raise TypeError(f"Expected instance of {service_type.__name__}, got {type(instance).__name__}")
        self.__services[service_type] = instance

    async def flush(self) -> None:
        if self.__flush_callback is not None:
            await self.__flush_callback()

    @property
    def services(self) -> dict[type, Any]:
        return self.get_services()

    def get_services(self) -> dict[type, Any]:
        return {**self.__parent_services, **self.__services}

    def get_inherited_services(self) -> dict[type, Any]:
        return dict(self.__parent_services)

    def set_flush_callback(self, callback: FlushCallback) -> None:
        self.__flush_callback = callback
