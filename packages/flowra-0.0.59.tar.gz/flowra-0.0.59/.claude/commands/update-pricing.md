# Update Pricing

Update the LLM pricing data in `flowra/llm/pricing/data/` with current pricing from the web.

## Instructions

You are updating the pricing data for LLM models used by this project.

### Project structure

Pricing is stored in JSON files under `flowra/llm/pricing/data/`:

- `generated.json` — auto-generated from litellm via `tools/sync_pricing.py`. **Do not edit manually.**
- `custom.json` — manual overrides and additions for models/fields missing from litellm. Custom entries are **merged** with generated entries (custom fields override, other fields preserved from generated).

The JSON format is `provider → model → pricing_fields`:

```json
{
  "anthropic": {
    "claude-sonnet-4-6": {
      "input": 3.0,
      "output": 15.0,
      "cache_read": 0.3,
      "cache_creation": 3.75,
      "cache_creation_1h": 6.0,
      "input_above_200k": 6.0,
      "output_above_200k": 22.5
    }
  }
}
```

Provider keys: `anthropic`, `openai`, `google` (future: `bedrock/us`, `azure/eu`, etc.)

All prices in **$/1M tokens**. Omit fields that are zero.

Available pricing fields:
- `input`, `output` — base rates
- `cache_read` — cache read cost
- `cache_creation` — cache creation cost (5-minute ephemeral for Anthropic)
- `cache_creation_1h` — Anthropic 1-hour cache creation cost
- `reasoning_output` — separate reasoning token rate (if different from output)
- `input_above_200k`, `output_above_200k`, `cache_read_above_200k`, `cache_creation_above_200k`, `cache_creation_1h_above_200k` — context tier rates for >200k tokens

### Steps to follow

1. **Read current pricing data**: Read `custom.json` and `generated.json` to see existing models and prices.

2. **Determine which models to update**:
   - If the user provided arguments (e.g., `/update-pricing all Gemini models`), search for pricing for those specific models.
   - If no arguments were provided, refresh pricing for models in `custom.json`.

3. **Web search for current pricing**: Use WebSearch to find the most up-to-date pricing:
   - Search official pricing pages: Anthropic (anthropic.com/pricing), OpenAI (openai.com/api/pricing), Google Cloud (cloud.google.com/vertex-ai/generative-ai/pricing)
   - Focus on models/fields that `generated.json` is missing (check litellm gaps)

4. **Update `custom.json`**:
   - Add/update entries for models or fields not covered by `generated.json`
   - For partially missing fields (e.g., litellm has base rates but not `cache_creation_1h`), only include the missing fields — they will be merged with generated data
   - For completely missing models, include all known pricing fields
   - Remove entries from `custom.json` that are now fully covered by `generated.json`

5. **Verify**: Run `make test name=pricing` to ensure nothing is broken.

## Important notes

- All prices are in dollars per 1 million tokens
- `custom.json` entries **merge** with `generated.json` — you only need to specify fields that differ or are missing
- Anthropic has separate 5-minute and 1-hour cache creation prices. 5m = 1.25x base input, 1h = 2x base input
- OpenAI and Google cache creation is free — no `cache_creation` field needed
- Model matching uses substring matching, so keys should be specific enough to avoid false matches
- Always prioritize official pricing pages from model providers
- To regenerate `generated.json` from litellm, run: `python tools/sync_pricing.py --apply`
