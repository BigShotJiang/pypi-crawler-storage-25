"""MLflow parallel workers demo — reproduces production architecture.

Architecture:
1. Global mlflow.start_run()
2. N workers via asyncio.create_task()
3. Each worker creates its own runtime + hooks + MLFLOW_TRACING.install
4. Each turn: with mlflow.start_span("conversation_turn") -> runtime.run()

Tests whether parallel workers corrupt each other's MLflow context.

Usage:
    make mlflow-parallel

Then view traces:
    uv run mlflow ui --port 5050
    # http://localhost:5050, experiment "flowra-parallel"
"""

import asyncio
import pathlib

import mlflow

from examples.app_agent import AppAgent, AppConfig
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate
from flowra.agent import AgentRuntime, InMemorySessionStorage
from flowra.ext.mlflow import MLFLOW_TRACING
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()


async def run_turn(
    runtime: AgentRuntime,
    question: str,
    worker_id: str,
) -> ChatResult:
    """Run a single turn inside an external MLflow span (like production code)."""
    with mlflow.start_span(name=f"conversation_turn_{worker_id}") as span:
        span.set_inputs({"question": question, "worker": worker_id})

        result = await runtime.run(
            agent=AppAgent,
            spec=ChatSpec.text(question),
        )

        if isinstance(result, ChatResult):
            span.set_outputs({"answer": result.response})

    return result


async def worker(
    worker_id: str,
    questions: list[str],
    registry: ToolRegistry,
    router: LLMProvider,
) -> list[ChatResult]:
    """Worker that creates its own runtime and processes questions sequentially."""
    app_config = AppConfig(
        provider=router,
        default_model=DEFAULT_MODEL,
        tools=registry,
        system=lambda: [SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)])],
    )

    runtime = AgentRuntime(
        agents={"app": AppAgent},
        storage=InMemorySessionStorage(),
        services={
            AppConfig: app_config,
        },
    )
    MLFLOW_TRACING.install(runtime, experiment_name="flowra-parallel", trace_steps=True)

    results = []
    for question in questions:
        print(f"[{worker_id}] Asking: {question}")
        result = await run_turn(runtime, question, worker_id)
        print(f"[{worker_id}] Answer: {result.response}")
        results.append(result)

    return results


async def main() -> None:
    mlflow.set_experiment("flowra-parallel")
    router = create_router()

    registry = ToolRegistry([calculate])
    print("=" * 70)
    print("Architecture: global mlflow run + N async workers")
    print("Each worker: own runtime + hooks + MLFLOW_TRACING.install")
    print("Each turn: with mlflow.start_span() -> runtime.run()")
    print("=" * 70)

    with mlflow.start_run(run_name="parallel_simulation"):
        # Create worker tasks (like asyncio.create_task in production)
        worker_a = asyncio.create_task(worker("W01", ["What is 7 * 8? Use the calculator."], registry, router))
        worker_b = asyncio.create_task(worker("W02", ["What is 12 + 15? Use the calculator."], registry, router))

        await asyncio.gather(worker_a, worker_b)

    print("\n" + "=" * 70)
    print("Done! Check traces at http://localhost:5050")
    print("Experiment: flowra-parallel")
    print()
    print("Expected: each conversation_turn span has flowra spans nested inside")
    print("Bug: if spans from W01 appear under W02's trace (or vice versa)")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
