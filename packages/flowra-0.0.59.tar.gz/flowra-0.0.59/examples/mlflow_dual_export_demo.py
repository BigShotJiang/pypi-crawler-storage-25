"""MLflow with OTel dual export — single trace ID shared between MLflow and OTel.

MLflow is built on OTel internally. With dual export enabled, MLflow sends spans
to both its own backend AND to an OTel collector. Same trace ID in both systems.

Prerequisites:
    pip install opentelemetry-exporter-otlp

    Jaeger must be running:
    docker run -d --name jaeger -p 16686:16686 -p 4317:4317 jaegertracing/all-in-one:latest

Usage:
    # Set environment variables:
    export OTEL_EXPORTER_OTLP_TRACES_ENDPOINT="http://localhost:4317"
    export MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT="true"
    export OTEL_SERVICE_NAME="flowra-mlflow-dual"

    # Run:
    uv run python examples/mlflow_dual_export_demo.py

View traces:
    # MLflow UI:
    uv run mlflow ui --port 5050
    # http://localhost:5050 → experiment "mlflow-dual-export"

    # Jaeger UI:
    # http://localhost:16686 → service "flowra-mlflow-dual"

    # Check that SAME trace ID appears in both UIs!
"""

import asyncio
import os
import pathlib

from examples.app_agent import AppAgent, AppConfig
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate
from flowra.agent import AgentRuntime, InMemorySessionStorage
from flowra.ext.mlflow import MLFLOW_TRACING
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.llm import SystemMessage, TextBlock
from flowra.tools import ToolRegistry

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()


async def main() -> None:
    # Check that environment variables are set
    required_vars = {
        "OTEL_EXPORTER_OTLP_TRACES_ENDPOINT": "http://localhost:4317",
        "MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT": "true",
        "OTEL_SERVICE_NAME": "flowra-mlflow-dual",
    }

    print("=" * 70)
    print("Checking environment variables for MLflow dual export:")
    print("=" * 70)

    missing = []
    for var, default in required_vars.items():
        value = os.environ.get(var)
        if value:
            print(f"✓ {var}={value}")
        else:
            print(f"✗ {var} not set (will use default: {default})")
            os.environ[var] = default
            missing.append(var)

    if missing:
        print("\nInfo: Auto-set missing variables to defaults")

    print("=" * 70)

    router = create_router()

    registry = ToolRegistry([calculate])
    app_config = AppConfig(
        provider=router,
        default_model=DEFAULT_MODEL,
        tools=registry,
        system=lambda: [SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)])],
    )

    runtime = AgentRuntime(
        agents={"app": AppAgent},
        storage=InMemorySessionStorage(),
        services={
            AppConfig: app_config,
        },
    )

    # Install ONLY MLflow tracing (it will dual-export to OTel)
    MLFLOW_TRACING.install(runtime, experiment_name="mlflow-dual-export", trace_steps=True)

    print("\n" + "=" * 70)
    print("Running with MLflow dual export to OTel")
    print("=" * 70)
    print("MLflow: experiment 'mlflow-dual-export'")
    print("OTel:   service 'flowra-mlflow-dual' in Jaeger")
    print("Note:   SAME trace ID in both systems")
    print("=" * 70)

    result = await runtime.run(
        agent=AppAgent,
        spec=ChatSpec.text("What is 42 * 13? Use the calculator."),
    )

    if isinstance(result, ChatResult):
        print("\n→ Question: What is 42 * 13?")
        print(f"← Answer: {result.response}")
        if result.usage:
            print(f"  Tokens: {result.usage.input_tokens} in, {result.usage.output_tokens} out")
            if result.usage.cost_usd:
                print(f"  Cost: ${result.usage.cost_usd:.4f}")

    print("\n" + "=" * 70)
    print("Done! View traces in:")
    print("  MLflow: uv run mlflow ui --port 5050")
    print("          http://localhost:5050 (experiment: mlflow-dual-export)")
    print()
    print("  Jaeger: http://localhost:16686 (service: flowra-mlflow-dual)")
    print()
    print("🔍 Compare trace IDs — they should be IDENTICAL in both UIs!")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
