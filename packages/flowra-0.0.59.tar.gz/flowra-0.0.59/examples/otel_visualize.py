"""Parse OTel ConsoleSpanExporter JSON output and visualize span tree.

Usage:
    uv run python examples/otel_nested_demo.py 2>&1 | uv run python examples/otel_visualize.py
"""

import json
import sys
from collections import defaultdict


def parse_spans(input_text: str) -> list[dict]:
    """Parse JSON spans from console output."""
    spans = []
    current_json = []
    brace_count = 0

    for line in input_text.split("\n"):
        stripped = line.strip()
        if not stripped:
            continue

        # Count braces to detect JSON object boundaries
        for char in stripped:
            if char == "{":
                brace_count += 1
            elif char == "}":
                brace_count -= 1

        current_json.append(line)

        # Complete JSON object detected
        if brace_count == 0 and current_json:
            json_str = "\n".join(current_json)
            try:
                span = json.loads(json_str)
                if "name" in span and "context" in span:
                    spans.append(span)
            except json.JSONDecodeError:
                pass
            current_json = []

    return spans


def build_tree(spans: list[dict]) -> dict:
    """Build parent-child tree from spans."""
    # Group spans by trace_id
    traces = defaultdict(list)
    for span in spans:
        trace_id = span["context"]["trace_id"]
        traces[trace_id].append(span)

    # For each trace, build tree
    trees = {}
    for trace_id, trace_spans in traces.items():
        # Build children map
        children = defaultdict(list)
        roots = []

        for span in trace_spans:
            parent_id = span.get("parent_id")
            if parent_id is None:
                roots.append(span)
            else:
                children[parent_id].append(span)

        trees[trace_id] = {"roots": roots, "children": children}

    return trees


def format_duration(start: str, end: str) -> str:
    """Format duration in human-readable format."""
    from datetime import datetime

    start_dt = datetime.fromisoformat(start.replace("Z", "+00:00"))
    end_dt = datetime.fromisoformat(end.replace("Z", "+00:00"))
    duration = (end_dt - start_dt).total_seconds()
    if duration < 1:
        return f"{duration * 1000:.0f}ms"
    return f"{duration:.2f}s"


def print_span(span: dict, children_map: dict, prefix: str = "", is_last: bool = True) -> None:
    """Print span with tree formatting."""
    span_id = span["context"]["span_id"]
    name = span["name"]
    duration = format_duration(span["start_time"], span["end_time"])
    status = span.get("status", {}).get("status_code", "UNSET")

    # Format status color
    status_symbol = "✓" if status == "OK" else "○" if status == "UNSET" else "✗"

    # Tree characters
    connector = "└── " if is_last else "├── "
    print(f"{prefix}{connector}{status_symbol} {name} ({duration})")

    # Print children
    span_children = children_map.get(span_id, [])
    # Sort by start time
    span_children.sort(key=lambda s: s["start_time"])

    for i, child in enumerate(span_children):
        is_child_last = i == len(span_children) - 1
        child_prefix = prefix + ("    " if is_last else "│   ")
        print_span(child, children_map, child_prefix, is_child_last)


def main() -> None:
    # Read stdin
    input_text = sys.stdin.read()

    # Parse spans
    spans = parse_spans(input_text)

    if not spans:
        print("No spans found in input", file=sys.stderr)
        return

    # Build tree
    trees = build_tree(spans)

    print(f"\n{'=' * 60}")
    print(f"Found {len(spans)} spans in {len(trees)} trace(s)")
    print(f"{'=' * 60}\n")

    # Print each trace
    for trace_id, tree in trees.items():
        print(f"Trace: {trace_id}")
        print()

        roots = tree["roots"]
        children = tree["children"]

        for i, root in enumerate(roots):
            is_last = i == len(roots) - 1
            print_span(root, children, "", is_last)

        print()


if __name__ == "__main__":
    main()
