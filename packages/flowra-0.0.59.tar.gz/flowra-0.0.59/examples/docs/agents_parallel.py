"""Agents: Parallel execution with Spawn and WhenAny.

Corresponds to docs/agents.md "Parallel execution" and docs/patterns.md "Race" sections.

Usage:
    make docs-example name=agents_parallel
"""

import asyncio
import dataclasses
import time
from dataclasses import dataclass
from typing import Annotated, ClassVar

from examples.model_registry import create_router
from flowra.agent import (
    Agent,
    AgentDefinitionRef,
    AgentRuntime,
    CallAgent,
    ServiceLocator,
    Spawn,
    TimeoutExpired,
    WhenAny,
    agent_arg,
    step,
    timeout,
)
from flowra.lib import LLMCallAgent, LLMConfig
from flowra.lib.llm_call import LLMCallConfig, LLMCallResult, LLMCallSpec
from flowra.lib.observability import TextDeltaEvent
from flowra.llm import SystemMessage, TextBlock, UserMessage


@dataclass
class ResearchSpec:
    question: str
    model: str


@dataclass
class ResearchResult:
    answer: str
    model: str


class Researcher(Agent[ResearchSpec, ResearchResult]):
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"llm": LLMCallAgent}

    def __init__(self, spec: ResearchSpec, sl: ServiceLocator, llm_config: LLMConfig) -> None:
        self.__spec = spec
        sl.provide(
            LLMCallConfig(
                llm_config=dataclasses.replace(llm_config, model=spec.model),
                system=[SystemMessage(blocks=[TextBlock(text="Answer briefly.")])],
            )
        )

    @step(entry=True)
    async def research(self) -> Spawn:
        return Spawn(
            CallAgent(
                agent=LLMCallAgent,
                spec=LLMCallSpec(
                    messages=[UserMessage(blocks=[TextBlock(text=self.__spec.question)])],
                ),
            ),
            then=self.done,
        )

    @step
    def done(self, response: LLMCallResult) -> ResearchResult:
        text = (
            "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
            if response.message
            else response.error or "Unknown error"
        )
        return ResearchResult(answer=text, model=self.__spec.model)


@dataclass
class RaceSpec:
    question: str
    model1: str
    model2: str


@dataclass
class RaceResult:
    winner: str
    answer: str


class RaceAgent(Agent[RaceSpec, RaceResult]):
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"researcher": Researcher}

    @step(entry=True)
    async def start(self, spec: RaceSpec) -> Spawn:
        return Spawn(
            WhenAny(
                CallAgent(agent=Researcher, spec=ResearchSpec(question=spec.question, model=spec.model1), tag="r1"),
                CallAgent(agent=Researcher, spec=ResearchSpec(question=spec.question, model=spec.model2), tag="r2"),
                timeout(seconds=30),
            ),
            then=self.finish,
        )

    @step
    async def finish(
        self,
        r1: Annotated[ResearchResult | None, agent_arg.CHILD("r1")],
        r2: Annotated[ResearchResult | None, agent_arg.CHILD("r2")],
        expired: TimeoutExpired | None,
    ) -> RaceResult:
        if expired:
            return RaceResult(winner="(none)", answer="Timed out")
        winner = r1 or r2
        assert winner is not None
        return RaceResult(winner=winner.model, answer=winner.answer)


async def main() -> None:
    router = create_router()

    model1 = "anthropic/sonnet-4-5"
    model2 = "google/gemini-2.5-flash"

    runtime = AgentRuntime(
        agents={"race": RaceAgent},
        services={LLMConfig: LLMConfig(provider=router, model=model1)},
    )
    runtime.hooks.on(TextDeltaEvent, lambda e: None)  # enable streaming (silent)

    spec = RaceSpec(question="Why is the sky blue? One sentence.", model1=model1, model2=model2)
    print(f"Racing: {model1} vs {model2}\n")

    t0 = time.monotonic()
    result = await runtime.run(agent=RaceAgent, spec=spec)
    elapsed = time.monotonic() - t0

    assert isinstance(result, RaceResult)
    print(f"Winner: {result.winner} ({elapsed:.1f}s)")
    print(f"Answer: {result.answer}")


if __name__ == "__main__":
    asyncio.run(main())
