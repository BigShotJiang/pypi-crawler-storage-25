"""Working with LLMs: Direct streaming.

Corresponds to docs/llm.md "Streaming" section.

Usage:
    make docs-example name=llm_streaming
"""

import asyncio

from examples.model_registry import DEFAULT_MODEL, create_router
from flowra.llm import ContentComplete, LLMRequest, TextBlock, TextDelta, ThinkingDelta, UserMessage


async def main() -> None:
    router = create_router()

    request = LLMRequest(
        model=DEFAULT_MODEL,
        messages=[UserMessage(blocks=[TextBlock(text="What is the capital of Japan?")])],
        max_tokens=256,
    )

    async for event in router.stream(request):
        match event:
            case TextDelta(text=text):
                print(text, end="", flush=True)
            case ThinkingDelta(text=text):
                print(f"[thinking] {text}", end="")
            case ContentComplete(response=response):
                print()
                if response.usage:
                    print(f"\n({response.usage.input_tokens} in, {response.usage.output_tokens} out)")


if __name__ == "__main__":
    asyncio.run(main())
