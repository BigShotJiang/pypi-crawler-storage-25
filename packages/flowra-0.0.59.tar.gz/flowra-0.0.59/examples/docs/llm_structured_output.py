"""Working with LLMs: Structured output (JSON schema).

Corresponds to docs/llm.md "Structured output" section.

Usage:
    make docs-example name=llm_structured_output
"""

import asyncio
import json

from examples.model_registry import DEFAULT_MODEL, create_router
from flowra.llm import LLMRequest, StopReason, TextBlock, UserMessage


async def main() -> None:
    router = create_router()

    response = await router.call(
        LLMRequest(
            model=DEFAULT_MODEL,
            messages=[UserMessage(blocks=[TextBlock(text="Three European capitals")])],
            json_schema={
                "type": "object",
                "properties": {"cities": {"type": "array", "items": {"type": "string"}}},
                "required": ["cities"],
            },
            max_tokens=256,
        )
    )

    first_block = response.message.blocks[0]

    if response.stop_reason == StopReason.SCHEMA_VALIDATION_FAILED:
        assert isinstance(first_block, TextBlock)
        print(f"Schema validation failed. Raw: {first_block.text}")
        return

    assert isinstance(first_block, TextBlock)
    text = first_block.text
    data = json.loads(text)
    print(f"Cities: {', '.join(data['cities'])}")

    if response.usage:
        print(f"({response.usage.input_tokens} in, {response.usage.output_tokens} out)")


if __name__ == "__main__":
    asyncio.run(main())
