"""MLflow tracing demo — runs a single chat request with MLflow tracing.

Usage:
    make mlflow-demo
    # or directly (with .env loaded):
    uv run python examples/mlflow_demo.py

Then view traces:
    uv run mlflow ui --port 5050
    # open http://localhost:5050, experiment "flowra-demo", Traces tab
"""

import asyncio
import pathlib

from examples.app_agent import AppAgent, AppConfig
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate, random_numbers
from flowra.agent import AgentRuntime, InMemorySessionStorage
from flowra.ext.mlflow import MLFLOW_TRACING
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.llm import SystemMessage, TextBlock
from flowra.tools import ToolRegistry

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()


async def main() -> None:
    router = create_router()

    registry = ToolRegistry([calculate, random_numbers])
    app_config = AppConfig(
        provider=router,
        default_model=DEFAULT_MODEL,
        tools=registry,
        system=lambda: [
            SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)]),
        ],
    )

    runtime = AgentRuntime(
        agents={"app": AppAgent},
        storage=InMemorySessionStorage(),
        services={
            AppConfig: app_config,
        },
    )
    MLFLOW_TRACING.install(runtime, experiment_name="flowra-demo", trace_steps=True)

    print("Sending: What is 2+2? Use the calculator tool.")
    result = await runtime.run(
        agent=AppAgent,
        spec=ChatSpec.text("What is 2+2? Use the calculator tool."),
    )

    if isinstance(result, ChatResult):
        print(f"\nAssistant: {result.response}")
        if result.usage:
            print(f"Tokens: {result.usage.input_tokens} in, {result.usage.output_tokens} out")
            if result.usage.cost_usd is not None:
                print(f"Cost: ${result.usage.cost_usd:.4f}")

    print("\nDone! View traces: uv run mlflow ui --port 5050")


if __name__ == "__main__":
    asyncio.run(main())
