# MLflow + OpenTelemetry Tracing Combinations

This directory contains examples demonstrating different ways to use MLflow and OpenTelemetry tracing together.

## Quick Reference

| Example | MLflow | OTel | Trace IDs | Best for |
|---------|--------|------|-----------|----------|
| `mlflow_otel_both_demo.py` | ✓ Independent | ✓ Independent | Different | Full picture, two UIs |
| `mlflow_dual_export_demo.py` | ✓ Dual export | Via MLflow | **Same** | Single instrumentation |
| `mlflow_otel_nested_demo.py` | ✓ Independent | ✓ Nested | Different | External OTel context |

## Examples

### 1. Both Independently (`mlflow_otel_both_demo.py`)

**What it does:**
- Enables both MLflow and OTel tracing
- Creates two independent trace trees
- Different trace IDs

**Run:**
```bash
make mlflow-otel-both
```

**View traces:**
- MLflow: http://localhost:5050 (experiment: `mlflow-otel-both`)
- Jaeger: http://localhost:16686 (service: `flowra`)

**Use case:**
You want the full picture with both UIs:
- MLflow for LLM-specific details (cost, tokens, chat preview)
- OTel for distributed tracing with standard GenAI semantic conventions

**Trade-off:** Two separate trace IDs — no direct link between traces.

---

### 2. MLflow Dual Export (`mlflow_dual_export_demo.py`)

**What it does:**
- Enables only MLflow tracing
- MLflow automatically exports spans to OTel collector
- Same trace ID in both systems

**Setup:**
Requires environment variables:
```bash
export OTEL_EXPORTER_OTLP_TRACES_ENDPOINT="http://localhost:4317"
export MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT="true"
export OTEL_SERVICE_NAME="flowra-mlflow-dual"
```

**Run:**
```bash
make mlflow-dual-export
```

**View traces:**
- MLflow: http://localhost:5050 (experiment: `mlflow-dual-export`)
- Jaeger: http://localhost:16686 (service: `flowra-mlflow-dual`)

**Check:** Trace IDs should be **identical** in both UIs!

**Use case:**
Single instrumentation with dual output. MLflow is the source of truth, OTel gets a copy.

**Trade-off:** MLflow uses its own attribute names (`mlflow.chat.tokenUsage`) instead of
standard GenAI semantic conventions (`gen_ai.usage.input_tokens`), so OTel backends
won't recognize them as standard GenAI spans.

---

### 3. External OTel Span Wrapping Flowra (`mlflow_otel_nested_demo.py`)

**What it does:**
- External OTel span created by business application
- Flowra runs inside with BOTH MLflow and OTel tracing
- OTel spans nest into external context
- MLflow creates independent trace tree

**Run:**
```bash
make mlflow-otel-nested
```

**View traces:**
- Jaeger: http://localhost:16686 (service: `business_app`)
  - Shows: `business_workflow` span with flowra spans nested inside
- MLflow: http://localhost:5050 (experiment: `mlflow-otel-nested`)
  - Shows: independent MLflow trace tree

**Use case:**
Flowra is part of a larger service that already uses OTel tracing. You want:
- OTel: full distributed trace including external business logic
- MLflow: LLM-specific view with cost/token details

**Key insight:**
- OTel integrates with external context (same trace tree)
- MLflow creates independent tree (its own trace ID)
- Both capture the SAME execution from different perspectives

---

## Other Examples

### 4. MLflow Only with External Span (`mlflow_nested_demo.py`)

External MLflow span wrapping flowra (only MLflow tracing).

```bash
make mlflow-nested-demo
```

### 5. OTel Only with External Span (`otel_nested_demo.py`)

External OTel span wrapping flowra (only OTel tracing).

```bash
make otel-nested-demo
# Visualize:
make otel-nested-visualize
```

### 6. OTel with Jaeger (`otel_jaeger_demo.py`)

OTel tracing with external span, exported to Jaeger.

```bash
make otel-jaeger-demo
```

---

## Decision Tree

```
Do you use OTel in your service already?
├── No → MLflow only (simplest, best LLM UI)
└── Yes
    ├── Do you need MLflow's LLM-specific UI?
    │   ├── No → OTel only (standard, lightweight)
    │   └── Yes
    │       ├── Do you want one trace ID across both?
    │       │   ├── Yes → MLflow with OTel export (dual export)
    │       │   └── No → Both independently
    │       └── Do you need standard GenAI semconv attributes?
    │           ├── Yes → Both independently (OTel uses gen_ai.*)
    │           └── No → MLflow with OTel export (simpler)
```

---

## Quick Start

1. **Start Jaeger** (for OTel examples):
   ```bash
   docker run -d --name jaeger \
     -p 16686:16686 \
     -p 4317:4317 \
     jaegertracing/all-in-one:latest
   ```

2. **Run an example**:
   ```bash
   make mlflow-otel-both
   ```

3. **View traces**:
   - MLflow UI: `uv run mlflow ui --port 5050` → http://localhost:5050
   - Jaeger UI: http://localhost:16686

---

## See Also

- `docs/observability.md` — full documentation on tracing options
- `flowra/ext/mlflow.py` — MLflow integration implementation
- `flowra/ext/otel.py` — OpenTelemetry integration implementation
