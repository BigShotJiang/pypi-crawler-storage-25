"""Random number generator tool with interrupt support."""

import asyncio
import dataclasses
import json
import logging
import random

from flowra.agent import InterruptToken
from flowra.tools import tool

from .calculator import TOOL_DELAY

log = logging.getLogger(__name__)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class RandomNumbersParams:
    count: int
    min: int = 1
    max: int = 100


@tool("random_numbers")
async def random_numbers(params: RandomNumbersParams, interrupt: InterruptToken) -> str:
    """Generate random integers. Returns JSON with the numbers array."""
    log.info(
        "TOOL random_numbers(count=%d, min=%d, max=%d) — sleeping %.1fs",
        params.count,
        params.min,
        params.max,
        TOOL_DELAY,
    )
    try:
        await asyncio.wait_for(interrupt.wait(), timeout=TOOL_DELAY)
        log.info("TOOL random_numbers — interrupted during sleep")
        return "Error: generation interrupted"
    except TimeoutError:
        pass
    nums = [random.randint(params.min, params.max) for _ in range(params.count)]
    result = json.dumps({"numbers": nums, "count": len(nums), "range": {"min": params.min, "max": params.max}})
    log.info("TOOL random_numbers => %s", result[:120])
    return result
