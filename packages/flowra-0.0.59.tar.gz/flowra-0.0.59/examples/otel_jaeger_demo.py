"""OpenTelemetry with Jaeger — flowra spans nested in external OTel spans.

Sends traces to Jaeger for visualization.

Prerequisites:
    Jaeger must be running:
    docker run -d --name jaeger \
        -p 16686:16686 \
        -p 4317:4317 \
        jaegertracing/all-in-one:latest

Usage:
    uv run python examples/otel_jaeger_demo.py

Then view traces:
    open http://localhost:16686
    # Select service "business_app" and click "Find Traces"
"""

import asyncio
import pathlib

from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from examples.app_agent import AppAgent, AppConfig
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate, random_numbers
from flowra.agent import AgentRuntime, InMemorySessionStorage
from flowra.ext.otel import OTEL_TRACING
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.llm import SystemMessage, TextBlock
from flowra.tools import ToolRegistry

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()


async def run_agent_with_flowra_tracing(runtime: AgentRuntime, question: str) -> ChatResult:
    """Run agent with flowra's OTel tracing."""
    print(f"\n→ Sending: {question}")
    result = await runtime.run(
        agent=AppAgent,
        spec=ChatSpec.text(question),
    )

    if isinstance(result, ChatResult):
        print(f"← Assistant: {result.response}")
        if result.usage:
            print(f"  Tokens: {result.usage.input_tokens} in, {result.usage.output_tokens} out")
            if result.usage.cost_usd is not None:
                print(f"  Cost: ${result.usage.cost_usd:.4f}")

    return result


async def main() -> None:
    # Configure OpenTelemetry with OTLP exporter (sends to Jaeger)
    resource = Resource(attributes={"service.name": "business_app"})
    provider = TracerProvider(resource=resource)

    # OTLP exporter sends traces to Jaeger on localhost:4317
    otlp_exporter = OTLPSpanExporter(endpoint="http://localhost:4317", insecure=True)
    provider.add_span_processor(BatchSpanProcessor(otlp_exporter))

    trace.set_tracer_provider(provider)

    # Get tracers
    app_tracer = trace.get_tracer("business_app")

    router = create_router()

    registry = ToolRegistry([calculate, random_numbers])
    app_config = AppConfig(
        provider=router,
        default_model=DEFAULT_MODEL,
        tools=registry,
        system=lambda: [
            SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)]),
        ],
    )

    runtime = AgentRuntime(
        agents={"app": AppAgent},
        storage=InMemorySessionStorage(),
        services={
            AppConfig: app_config,
        },
    )
    OTEL_TRACING.install(runtime, tracer_name="flowra", capture_content=False)

    # Create external OTel spans
    print("=" * 60)
    print("Creating external OTel span: 'business_logic'")
    print("Flowra spans will be nested inside")
    print("=" * 60)

    with app_tracer.start_as_current_span("business_logic") as business_span:
        business_span.set_attribute("workflow", "multi-question-processing")

        # First agent call inside external span
        with app_tracer.start_as_current_span("question_1_processing") as q1_span:
            q1_span.set_attribute("question", "What is 5+3?")
            result1 = await run_agent_with_flowra_tracing(runtime, "What is 5+3? Use the calculator.")
            q1_span.set_attribute("answer", result1.response or "")

        # Second agent call inside external span
        with app_tracer.start_as_current_span("question_2_processing") as q2_span:
            q2_span.set_attribute("question", "Generate 3 random numbers")
            result2 = await run_agent_with_flowra_tracing(runtime, "Generate 3 random numbers between 1 and 100.")
            q2_span.set_attribute("answer", result2.response or "")

        business_span.set_attribute("questions_processed", 2)
        business_span.set_attribute("status", "success")

    # Flush traces before exit
    provider.force_flush()

    print("\n" + "=" * 60)
    print("Done! Traces sent to Jaeger.")
    print("View at: http://localhost:16686")
    print('  1. Select service "business_app"')
    print('  2. Click "Find Traces"')
    print("  3. Click on the trace to see nested spans")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
