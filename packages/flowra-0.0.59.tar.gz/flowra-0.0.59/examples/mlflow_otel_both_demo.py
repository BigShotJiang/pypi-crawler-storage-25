"""MLflow + OTel — both independently (two separate trace trees).

Two independent span trees:
- MLflow for LLM-specific analysis (cost, tokens, chat UI)
- OTel for distributed tracing (GenAI semantic conventions)

Traces are NOT linked (different trace IDs).

Usage:
    uv run python examples/mlflow_otel_both_demo.py

View traces:
    # MLflow UI:
    uv run mlflow ui --port 5050
    # http://localhost:5050 → experiment "mlflow-otel-both"

    # Jaeger UI:
    # http://localhost:16686 → service "flowra"
"""

import asyncio
import pathlib

from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from examples.app_agent import AppAgent, AppConfig
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate
from flowra.agent import AgentRuntime, InMemorySessionStorage
from flowra.ext.mlflow import MLFLOW_TRACING
from flowra.ext.otel import OTEL_TRACING
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.llm import SystemMessage, TextBlock
from flowra.tools import ToolRegistry

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()


async def main() -> None:
    # Configure OTel
    resource = Resource(attributes={"service.name": "flowra"})
    provider = TracerProvider(resource=resource)
    otlp_exporter = OTLPSpanExporter(endpoint="http://localhost:4317", insecure=True)
    provider.add_span_processor(BatchSpanProcessor(otlp_exporter))
    trace.set_tracer_provider(provider)

    router = create_router()

    registry = ToolRegistry([calculate])
    app_config = AppConfig(
        provider=router,
        default_model=DEFAULT_MODEL,
        tools=registry,
        system=lambda: [SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)])],
    )

    runtime = AgentRuntime(
        agents={"app": AppAgent},
        storage=InMemorySessionStorage(),
        services={
            AppConfig: app_config,
        },
    )

    # Install BOTH tracing systems independently
    MLFLOW_TRACING.install(runtime, experiment_name="mlflow-otel-both", trace_steps=True)
    OTEL_TRACING.install(runtime, tracer_name="flowra", capture_content=False)

    print("=" * 70)
    print("Running with BOTH MLflow and OTel tracing (independently)")
    print("=" * 70)
    print("MLflow: experiment 'mlflow-otel-both'")
    print("OTel:   service 'flowra' in Jaeger")
    print("Note:   Different trace IDs (two separate trees)")
    print("=" * 70)

    result = await runtime.run(
        agent=AppAgent,
        spec=ChatSpec.text("What is 15 * 7? Use the calculator."),
    )

    if isinstance(result, ChatResult):
        print("\n→ Question: What is 15 * 7?")
        print(f"← Answer: {result.response}")
        if result.usage:
            print(f"  Tokens: {result.usage.input_tokens} in, {result.usage.output_tokens} out")
            if result.usage.cost_usd:
                print(f"  Cost: ${result.usage.cost_usd:.4f}")

    # Flush OTel spans
    provider.force_flush()

    print("\n" + "=" * 70)
    print("Done! View traces in:")
    print("  MLflow: uv run mlflow ui --port 5050")
    print("          http://localhost:5050 (experiment: mlflow-otel-both)")
    print()
    print("  Jaeger: http://localhost:16686 (service: flowra)")
    print()
    print("Check that both UIs show traces with DIFFERENT trace IDs")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
