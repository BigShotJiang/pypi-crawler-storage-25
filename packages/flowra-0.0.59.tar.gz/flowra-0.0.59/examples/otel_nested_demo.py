"""OpenTelemetry nested tracing demo — flowra agent runs inside external OTel span.

Demonstrates that flowra integrates with external OpenTelemetry context. When you
create a span with `tracer.start_as_current_span()` and call flowra inside,
flowra's spans become children of the external span.

Usage:
    uv run python examples/otel_nested_demo.py

Output shows spans in console (ConsoleSpanExporter). In production, replace with
OTLP exporter to send to Jaeger/Tempo/etc.
"""

import asyncio
import pathlib

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import ConsoleSpanExporter, SimpleSpanProcessor

from examples.app_agent import AppAgent, AppConfig
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate, random_numbers
from flowra.agent import AgentRuntime, InMemorySessionStorage
from flowra.ext.otel import OTEL_TRACING
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.llm import SystemMessage, TextBlock
from flowra.tools import ToolRegistry

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()


async def run_agent_with_flowra_tracing(runtime: AgentRuntime, question: str) -> ChatResult:
    """Run agent with flowra's OTel tracing."""
    print(f"\n→ Sending: {question}")
    result = await runtime.run(
        agent=AppAgent,
        spec=ChatSpec.text(question),
    )

    if isinstance(result, ChatResult):
        print(f"← Assistant: {result.response}")
        if result.usage:
            print(f"  Tokens: {result.usage.input_tokens} in, {result.usage.output_tokens} out")
            if result.usage.cost_usd is not None:
                print(f"  Cost: ${result.usage.cost_usd:.4f}")

    return result


async def main() -> None:
    # Configure OpenTelemetry
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(ConsoleSpanExporter()))
    trace.set_tracer_provider(provider)

    # Get a tracer for the application
    app_tracer = trace.get_tracer("business_app")

    router = create_router()

    registry = ToolRegistry([calculate, random_numbers])
    app_config = AppConfig(
        provider=router,
        default_model=DEFAULT_MODEL,
        tools=registry,
        system=lambda: [
            SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)]),
        ],
    )

    runtime = AgentRuntime(
        agents={"app": AppAgent},
        storage=InMemorySessionStorage(),
        services={
            AppConfig: app_config,
        },
    )
    OTEL_TRACING.install(runtime, tracer_name="flowra", capture_content=False)

    # Create an external OTel span
    print("=" * 60)
    print("Creating external OTel span: 'business_logic'")
    print("=" * 60)

    with app_tracer.start_as_current_span("business_logic") as business_span:
        business_span.set_attribute("workflow", "multi-question-processing")

        # First agent call inside external span
        with app_tracer.start_as_current_span("question_1_processing") as q1_span:
            q1_span.set_attribute("question", "What is 5+3?")
            result1 = await run_agent_with_flowra_tracing(runtime, "What is 5+3? Use the calculator.")
            q1_span.set_attribute("answer", result1.response or "")

        # Second agent call inside external span
        with app_tracer.start_as_current_span("question_2_processing") as q2_span:
            q2_span.set_attribute("question", "Generate 3 random numbers")
            result2 = await run_agent_with_flowra_tracing(runtime, "Generate 3 random numbers between 1 and 100.")
            q2_span.set_attribute("answer", result2.response or "")

        business_span.set_attribute("questions_processed", 2)
        business_span.set_attribute("status", "success")

    print("\n" + "=" * 60)
    print("Done! Check console output above for nested span hierarchy.")
    print("Flowra spans should appear as children of external spans.")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
