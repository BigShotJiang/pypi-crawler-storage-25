import asyncio
from unittest.mock import AsyncMock, patch

from ninja_kafka_sdk.client import NinjaClient


def test_send_success_result_preserves_general_wrapper_contract():
    with patch("ninja_kafka_sdk.client.KafkaProducer"):
        client = NinjaClient(
            kafka_servers="localhost:9092",
            consumer_group="test-group",
        )

    client.send_task_result = AsyncMock(return_value=True)

    result = asyncio.run(
        client.send_success_result(
            correlation_id="cid-success",
            account_id=42,
            task="linkedin_scrape_connections",
            data={"first_profile_url": "https://example.com/in/test"},
            metrics={"duration_ms": 1234},
        )
    )

    assert result is True
    client.send_task_result.assert_awaited_once_with(
        correlation_id="cid-success",
        task="linkedin_scrape_connections",
        status="SUCCESS",
        account_id=42,
        data={"first_profile_url": "https://example.com/in/test"},
        error=None,
        metrics={"duration_ms": 1234},
    )


def test_send_error_result_preserves_general_wrapper_contract():
    with patch("ninja_kafka_sdk.client.KafkaProducer"):
        client = NinjaClient(
            kafka_servers="localhost:9092",
            consumer_group="test-group",
        )

    client.send_task_result = AsyncMock(return_value=True)

    result = asyncio.run(
        client.send_error_result(
            correlation_id="cid-error",
            account_id=42,
            error_code="TASK_FAILED",
            error_message="boom",
            task="linkedin_scrape_followers",
            data={"account_email": "user@example.com"},
            metrics={"duration_ms": 4321},
        )
    )

    assert result is True
    client.send_task_result.assert_awaited_once_with(
        correlation_id="cid-error",
        task="linkedin_scrape_followers",
        status="FAILED",
        account_id=42,
        data={"account_email": "user@example.com"},
        error={"code": "TASK_FAILED", "message": "boom"},
        metrics={"duration_ms": 4321},
    )
