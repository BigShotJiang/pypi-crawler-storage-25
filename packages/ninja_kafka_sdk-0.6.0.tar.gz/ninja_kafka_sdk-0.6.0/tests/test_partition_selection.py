"""Tests for BLA-405: smart partition selection in send_task().

Validates:
- send_task() no longer hardcodes partition=0
- Lag-based partition selection picks lowest-lag partition
- Randomized tie-break on equal lag
- Fallback to random healthy partition when lag unavailable
- Cache TTL behavior
- Config parameter task_consumer_group
"""
import asyncio
import sys
import time
from pathlib import Path
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ninja_kafka_sdk.client import NinjaClient
from ninja_kafka_sdk.config import NinjaKafkaConfig


def run(coro):
    return asyncio.run(coro)


def make_client(task_consumer_group=None, partitions=None):
    """Create a NinjaClient with mocked producer and optional partition setup."""
    with patch('ninja_kafka_sdk.client.KafkaProducer'):
        c = NinjaClient(
            kafka_servers='localhost:9092',
            consumer_group='scheduler',
            tasks_topic='ninja-tasks',
            task_consumer_group=task_consumer_group,
        )
        mock_producer = MagicMock()
        future = MagicMock()
        future.get.return_value = MagicMock(topic='ninja-tasks', partition=0, offset=0)
        mock_producer.send.return_value = future
        if partitions is not None:
            mock_producer.partitions_for.return_value = partitions
        else:
            mock_producer.partitions_for.return_value = None
        c.producer = mock_producer
        return c


class TestTaskConsumerGroupConfig:

    def test_task_consumer_group_defaults_to_none(self):
        """Config accepts task_consumer_group as optional parameter, default None."""
        config = NinjaKafkaConfig(
            kafka_servers='localhost:9092',
            consumer_group='test'
        )
        assert config.task_consumer_group is None

    def test_task_consumer_group_explicit(self):
        """Config stores task_consumer_group when provided."""
        config = NinjaKafkaConfig(
            kafka_servers='localhost:9092',
            consumer_group='scheduler',
            task_consumer_group='browser-ninja-prod'
        )
        assert config.task_consumer_group == 'browser-ninja-prod'


class TestPartitionSelection:

    def test_send_task_does_not_force_partition_zero(self):
        """AC-3: send_task() must not hardcode partition=0 on multi-partition topic."""
        client = make_client(partitions={0, 1, 2})
        run(client.send_task(task='linkedin_scrape', account_id=1))

        call_kwargs = client.producer.send.call_args.kwargs
        # Partition should be set (not None) and should be one of the available partitions
        assert 'partition' in call_kwargs
        assert call_kwargs['partition'] in {0, 1, 2}

    def test_selects_lowest_lag_partition(self):
        """AC-3: picks partition with lowest consumer lag."""
        from kafka import TopicPartition
        client = make_client(task_consumer_group='browser-ninja', partitions={0, 1, 2})

        # Pre-populate lag cache: partition 2 has lowest lag
        client._partition_lag_cache['ninja-tasks'] = (
            time.time(),
            {0: 100, 1: 50, 2: 10}
        )

        run(client.send_task(task='linkedin_scrape', account_id=1))
        assert client.producer.send.call_args.kwargs['partition'] == 2

    def test_random_tiebreak_on_equal_lag(self):
        """AC-3: randomized tie-break when multiple partitions have equal lag."""
        client = make_client(task_consumer_group='browser-ninja', partitions={0, 1, 2})

        # All partitions have equal lag
        client._partition_lag_cache['ninja-tasks'] = (
            time.time(),
            {0: 50, 1: 50, 2: 50}
        )

        selected = set()
        for _ in range(50):
            run(client.send_task(task='linkedin_scrape', account_id=1))
            selected.add(client.producer.send.call_args.kwargs['partition'])

        # With 50 trials and 3 equal options, expect at least 2 different partitions
        assert len(selected) >= 2

    def test_fallback_to_random_when_lag_unavailable(self):
        """AC-3: falls back to random healthy partition when lag lookup fails."""
        client = make_client(task_consumer_group='browser-ninja', partitions={0, 1, 2})
        # No lag cache, and _ensure_lag_consumer/_ensure_admin_client will fail
        # because there's no real Kafka broker

        run(client.send_task(task='linkedin_scrape', account_id=1))

        call_kwargs = client.producer.send.call_args.kwargs
        # Should still send successfully with some partition (random fallback)
        # or None (auto-select) — either way, send succeeds
        assert call_kwargs['topic'] == 'ninja-tasks'

    def test_single_partition_uses_zero(self):
        """Single-partition topics use partition 0."""
        client = make_client(partitions={0})
        run(client.send_task(task='linkedin_scrape', account_id=1))
        assert client.producer.send.call_args.kwargs['partition'] == 0

    def test_fallback_to_random_without_task_consumer_group(self):
        """Without task_consumer_group, skip lag lookup, use random partition."""
        client = make_client(task_consumer_group=None, partitions={0, 1, 2})
        run(client.send_task(task='linkedin_scrape', account_id=1))

        call_kwargs = client.producer.send.call_args.kwargs
        assert call_kwargs['partition'] in {0, 1, 2}
        # No admin client should have been created
        assert client._admin_client is None

    def test_lag_cache_reused_within_ttl(self):
        """Lag lookup results are cached to avoid per-send overhead."""
        client = make_client(task_consumer_group='browser-ninja', partitions={0, 1, 2})

        # Pre-populate cache with recent timestamp
        client._partition_lag_cache['ninja-tasks'] = (
            time.time(),
            {0: 100, 1: 10, 2: 50}
        )

        run(client.send_task(task='linkedin_scrape', account_id=1))
        run(client.send_task(task='linkedin_scrape', account_id=2))

        # Cache should still have original values (not refreshed)
        assert client._partition_lag_cache['ninja-tasks'][1] == {0: 100, 1: 10, 2: 50}
        # Both sends should pick partition 1 (lowest lag)
        for call in client.producer.send.call_args_list:
            assert call.kwargs['partition'] == 1

    def test_lag_cache_refreshed_after_ttl(self):
        """Lag cache expires after TTL, triggering refresh attempt."""
        client = make_client(task_consumer_group='browser-ninja', partitions={0, 1, 2})

        # Pre-populate cache with EXPIRED timestamp
        client._partition_lag_cache['ninja-tasks'] = (
            time.time() - client._LAG_CACHE_TTL - 1,
            {0: 100, 1: 10, 2: 50}
        )

        # send_task will try to refresh lag (and fail because no real broker)
        # but should still succeed via fallback
        run(client.send_task(task='linkedin_scrape', account_id=1))
        assert client.producer.send.call_args.kwargs['topic'] == 'ninja-tasks'

    def test_no_partition_metadata_uses_auto_select(self):
        """When producer has no partition metadata, let Kafka auto-select."""
        client = make_client(partitions=None)
        run(client.send_task(task='linkedin_scrape', account_id=1))

        call_kwargs = client.producer.send.call_args.kwargs
        # No partition should be specified
        assert 'partition' not in call_kwargs


class TestProdValidation:
    """On-Action — these require live prod environment. Skeletons for QA."""

    def test_load_balanced_across_both_hosts(self):
        """On-Action — AC-3: scheduler-dispatched batch lands on both ninja1 and ninja2.
        Trigger: post-deploy validation batch using scheduler dispatch endpoint.
        """
        pass

    def test_no_duplicate_processing(self):
        """On-Action — AC-4: no message processed by both hosts.
        Trigger: same post-deploy validation batch as AC-3.
        """
        pass
