"""BLA-670: durable producer defaults — AC-1..AC-4 unit assertions."""
import pytest

from ninja_kafka_sdk.config import NinjaKafkaConfig


@pytest.fixture
def producer_settings():
    config = NinjaKafkaConfig(
        kafka_servers="localhost:9092",
        consumer_group="bla670-tests",
    )
    return config._get_producer_settings()


class TestProducerDurableDefaults:
    """AC-1..AC-3: producer settings must enforce durable delivery semantics."""

    def test_acks_is_all(self, producer_settings):
        """AC-1: `_get_producer_settings()` returns `acks='all'`."""
        assert producer_settings["acks"] == "all"

    def test_enable_idempotence_true(self, producer_settings):
        """AC-2: `_get_producer_settings()` returns `enable_idempotence=True`."""
        assert producer_settings["enable_idempotence"] is True

    def test_retries_non_zero(self, producer_settings):
        """AC-3: retries non-zero (idempotence-compatible)."""
        assert producer_settings["retries"] > 0

    def test_max_in_flight_is_one(self, producer_settings):
        """AC-3: max_in_flight_requests_per_connection==1 (idempotence-compatible)."""
        assert producer_settings["max_in_flight_requests_per_connection"] == 1


class TestProducerSettingsRegression:
    """AC-4: deterministic regression guard — assert AC-1..AC-3 exactly in one shot."""

    def test_producer_settings_durable_defaults(self, producer_settings):
        """AC-4: exact assertions on durable-default keys.

        Pinned to the keys/values that AC-1..AC-3 require. Other keys may exist
        and are not asserted here so that throughput/buffer tuning stays
        independent of the durability contract.
        """
        assert producer_settings["acks"] == "all", "AC-1"
        assert producer_settings["enable_idempotence"] is True, "AC-2"
        assert producer_settings["retries"] > 0, "AC-3 retries"
        assert producer_settings["max_in_flight_requests_per_connection"] == 1, (
            "AC-3 max_in_flight"
        )
