"""Tests for ordered multi-topic consumer support (BLA-403).

Validates:
- Config accepts task_topics as ordered list
- tasks_topic backward compatibility (becomes task_topics=[tasks_topic])
- Producer always uses tasks_topic (no routing params)
- Consumer subscribes to all task_topics when configured
- Consumer subscribes to single topic when task_topics not provided
- Priority drain order matches task_topics list order
"""
import asyncio
import sys
from pathlib import Path

import pytest
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ninja_kafka_sdk.client import NinjaClient
from ninja_kafka_sdk.config import NinjaKafkaConfig


def run(coro):
    return asyncio.run(coro)


class TestNinjaKafkaConfig:
    def test_task_topics_default_from_tasks_topic(self):
        config = NinjaKafkaConfig(
            kafka_servers='localhost:9092',
            consumer_group='test'
        )
        assert config.task_topics == ['ninja-tasks']

    def test_task_topics_explicit(self):
        config = NinjaKafkaConfig(
            kafka_servers='localhost:9092',
            consumer_group='test',
            task_topics=['ninja-tasks', 'ninja-tasks-low']
        )
        assert config.task_topics == ['ninja-tasks', 'ninja-tasks-low']

    def test_tasks_topic_preserved_as_producer_topic(self):
        config = NinjaKafkaConfig(
            kafka_servers='localhost:9092',
            consumer_group='test',
            tasks_topic='ninja-tasks',
            task_topics=['ninja-tasks', 'ninja-tasks-low']
        )
        assert config.tasks_topic == 'ninja-tasks'
        assert config.task_topics == ['ninja-tasks', 'ninja-tasks-low']

    def test_task_topics_overrides_tasks_topic_for_consumer(self):
        config = NinjaKafkaConfig(
            kafka_servers='localhost:9092',
            consumer_group='test',
            tasks_topic='ninja-tasks',
            task_topics=['topic-a', 'topic-b', 'topic-c']
        )
        assert config.task_topics == ['topic-a', 'topic-b', 'topic-c']
        assert config.tasks_topic == 'ninja-tasks'


@pytest.fixture
def client_multi_topic():
    """Client with ordered task_topics configured."""
    with patch('ninja_kafka_sdk.client.KafkaProducer'):
        c = NinjaClient(
            kafka_servers='localhost:9092',
            consumer_group='test',
            tasks_topic='ninja-tasks',
            task_topics=['ninja-tasks', 'ninja-tasks-low']
        )
        mock_producer = MagicMock()
        future = MagicMock()
        future.get.return_value = MagicMock(topic='ninja-tasks', partition=0, offset=0)
        mock_producer.send.return_value = future
        c.producer = mock_producer
        return c


@pytest.fixture
def client_single_topic():
    """Client with only the default topic (backward compat)."""
    with patch('ninja_kafka_sdk.client.KafkaProducer'):
        c = NinjaClient(
            kafka_servers='localhost:9092',
            consumer_group='auto-login',
            tasks_topic='ninja-tasks'
        )
        mock_producer = MagicMock()
        future = MagicMock()
        future.get.return_value = MagicMock(topic='ninja-tasks', partition=0, offset=0)
        mock_producer.send.return_value = future
        c.producer = mock_producer
        return c


class TestProducerAlwaysUsesDefaultTopic:
    """Producer publishes to tasks_topic regardless of task_topics config."""

    def test_send_task_uses_tasks_topic_with_multi_configured(self, client_multi_topic):
        run(
            client_multi_topic.send_task(task='linkedin_post', account_id=1)
        )
        assert client_multi_topic.producer.send.call_args.kwargs['topic'] == 'ninja-tasks'

    def test_send_task_uses_tasks_topic_single(self, client_single_topic):
        run(
            client_single_topic.send_task(task='linkedin_verification', account_id=1)
        )
        assert client_single_topic.producer.send.call_args.kwargs['topic'] == 'ninja-tasks'

    def test_payload_shape_unchanged(self, client_multi_topic):
        run(
            client_multi_topic.send_task(
                task='linkedin_scrape_connections',
                account_id=42,
                email='test@example.com',
                parameters={'key': 'val'}
            )
        )
        payload = client_multi_topic.producer.send.call_args[1]['value']
        assert payload['task'] == 'linkedin_scrape_connections'
        assert payload['account_id'] == 42
        assert 'correlation_id' in payload

    def test_correlation_id_prefixed(self, client_multi_topic):
        cid = run(
            client_multi_topic.send_task(task='linkedin_post', account_id=1)
        )
        assert cid.startswith('test:')

    def test_results_topic_unchanged(self, client_multi_topic):
        assert client_multi_topic.config.results_topic == 'ninja-results'


class TestMultiTopicSubscription:
    """Consumer subscribes to all task_topics with priority drain."""

    def test_subscribe_all_task_topics(self):
        with patch('ninja_kafka_sdk.client.KafkaProducer'), \
             patch('ninja_kafka_sdk.client.KafkaConsumer') as mock_consumer_cls:
            mock_consumer = MagicMock()
            mock_consumer.assignment.return_value = set()
            mock_consumer_cls.return_value = mock_consumer

            c = NinjaClient(
                kafka_servers='localhost:9092',
                consumer_group='browser-ninja',
                task_topics=['ninja-tasks', 'ninja-tasks-low']
            )
            c._running = True

            mock_consumer.poll.return_value = {}
            def stop_after_subscribe(*args, **kwargs):
                c._running = False
                return set()
            mock_consumer.assignment.side_effect = stop_after_subscribe

            c._consume_tasks()

            subscribe_call = mock_consumer.subscribe.call_args
            topics = subscribe_call[0][0]
            assert topics == ['ninja-tasks', 'ninja-tasks-low']

    def test_subscribe_single_topic_backward_compat(self):
        with patch('ninja_kafka_sdk.client.KafkaProducer'), \
             patch('ninja_kafka_sdk.client.KafkaConsumer') as mock_consumer_cls:
            mock_consumer = MagicMock()
            mock_consumer.assignment.return_value = set()
            mock_consumer_cls.return_value = mock_consumer

            c = NinjaClient(
                kafka_servers='localhost:9092',
                consumer_group='browser-ninja',
                tasks_topic='ninja-tasks'
            )
            c._running = True

            def stop_after_subscribe(*args, **kwargs):
                c._running = False
                return set()
            mock_consumer.assignment.side_effect = stop_after_subscribe

            c._consume_tasks()

            subscribe_call = mock_consumer.subscribe.call_args
            topics = subscribe_call[0][0]
            assert topics == ['ninja-tasks']


class TestBackwardCompatibility:
    """Existing callers without task_topics continue to work unchanged."""

    def test_client_without_task_topics(self):
        with patch('ninja_kafka_sdk.client.KafkaProducer'):
            c = NinjaClient(
                kafka_servers='localhost:9092',
                consumer_group='auto-login'
            )
            assert c.config.task_topics == ['ninja-tasks']
            assert c.config.tasks_topic == 'ninja-tasks'

    def test_send_task_default_single_topic(self, client_single_topic):
        cid = run(
            client_single_topic.send_task(task='linkedin_verification', account_id=1)
        )
        assert cid.startswith('auto-login:')
        assert client_single_topic.producer.send.call_args.kwargs['topic'] == 'ninja-tasks'
