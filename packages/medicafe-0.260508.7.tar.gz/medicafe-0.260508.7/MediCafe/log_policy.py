from __future__ import print_function

import os
import time

try:
    from MediCafe.logging_config import DEBUG, PERFORMANCE_LOGGING
except Exception:
    DEBUG = False
    PERFORMANCE_LOGGING = False
try:
    from MediCafe.diagnostics_policy import resolve_diagnostics_policy
except Exception:
    resolve_diagnostics_policy = None


def _env_true(name, default=False):
    try:
        raw = os.environ.get(name)
    except Exception:
        raw = None
    if raw is None:
        return bool(default)
    return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')


def normalize_level(level, default='INFO'):
    try:
        text = str(level or '').strip().upper()
    except Exception:
        text = ''
    if text in ('CRITICAL', 'ERROR', 'WARNING', 'INFO', 'DEBUG'):
        return text
    return str(default or 'INFO').upper()


def is_verbose_logging_enabled():
    """Return True when verbose payload emission is explicitly enabled.

    - `DEBUG` enables verbose payloads for triage sessions.
    - `MEDICAFE_VERBOSE_LOGGING=1` enables verbose payloads without config changes.

    Performance logging (timing-only) should not implicitly enable structured payload dumps.
    """
    if resolve_diagnostics_policy is not None:
        try:
            policy = resolve_diagnostics_policy({'MediLink_Config': {'DEBUG': bool(DEBUG)}})
            return bool(policy.get('verbose'))
        except Exception:
            pass
    if bool(DEBUG):
        return True
    return _env_true('MEDICAFE_VERBOSE_LOGGING', False)


def should_emit_detailed_payload(kind, level='INFO', payload=None):
    lvl = normalize_level(level)
    if lvl in ('ERROR', 'CRITICAL', 'WARNING'):
        return True
    if lvl == 'DEBUG':
        return is_verbose_logging_enabled()
    if is_verbose_logging_enabled():
        return True
    # Keep successful JSON IO events inspectable by default; suppress phase-chatter elsewhere.
    if str(kind or '').strip().lower() == 'json_io_event':
        try:
            phase = str((payload or {}).get('phase') or '').strip().lower()
        except Exception:
            phase = ''
        return phase in ('success', 'promote_failed', 'lock_failed', 'temp_open_failed', 'temp_write_failed')
    return False


def summarize_event(kind, payload):
    data = payload if isinstance(payload, dict) else {}
    name = str(kind or '').strip().lower()
    if name == 'csv_processing':
        return "event={} stage={} iteration={} cache_result={}".format(
            data.get('event', ''),
            data.get('stage', ''),
            data.get('iteration', ''),
            data.get('cache_result', ''),
        )
    if name == 'csv_preprocess':
        return "stage={} rows={} retained={} removed={}".format(
            data.get('stage', ''),
            data.get('row_count_in', data.get('total_rows', '')),
            data.get('retained_count', ''),
            data.get('removed_count', ''),
        )
    if name == 'payer_resolution':
        return "stage={} rows={} resolved={} unsupported={}".format(
            data.get('stage', ''),
            data.get('row_count', ''),
            data.get('resolved_count', ''),
            (data.get('skip_counts') or {}).get('unsupported_payer_id', ''),
        )
    if name == 'deductible_cache_csv':
        return "stage={} rows={} tuples={} dropped={}".format(
            data.get('stage', ''),
            data.get('row_count', ''),
            data.get('patient_tuple_count', ''),
            data.get('dropped_before_tuple_count', ''),
        )
    return ''


def get_cache_recency_hours(default_hours=24):
    try:
        raw = os.environ.get('MEDICAFE_DEDUCTIBLE_RECENT_CACHE_HOURS')
    except Exception:
        raw = None
    if raw is None:
        return int(default_hours)
    try:
        val = int(float(str(raw).strip()))
        if val <= 0:
            return int(default_hours)
        return val
    except Exception:
        return int(default_hours)


def get_patient_stale_days(default_days=120):
    try:
        raw = os.environ.get('MEDICAFE_DEDUCTIBLE_MAX_STALE_DAYS')
    except Exception:
        raw = None
    if raw is None:
        return int(default_days)
    try:
        val = int(float(str(raw).strip()))
        if val <= 0:
            return int(default_days)
        return val
    except Exception:
        return int(default_days)


def should_run_cache_eligibility_reconciliation(config, source_folder=None, drift_evidence=None):
    """
    Decide whether startup cache eligibility reconciliation should run.
    Returns (bool should_run, str reason).
    """
    if isinstance(drift_evidence, dict):
        flags = drift_evidence.get('drift_flags')
        if isinstance(flags, list) and flags:
            return True, 'drift_evidence:{0}'.format(str(flags[0] or '')[:80])
    if _env_true('MEDICAFE_FORCE_CACHE_RECONCILE', False):
        return True, 'forced_by_env'
    if _env_true('MEDICAFE_SKIP_CACHE_RECONCILE', False):
        return False, 'disabled_by_env'

    try:
        cfg = config if isinstance(config, dict) else {}
        csv_path = str(cfg.get('CSV_FILE_PATH') or '').strip()
    except Exception:
        csv_path = ''
    if not csv_path:
        return False, 'missing_config_csv_path'
    if not os.path.exists(csv_path):
        return False, 'config_csv_missing_on_disk'

    csv_dir = os.path.dirname(csv_path)
    cache_path = os.path.join(csv_dir, 'insurance_type_cache.json')
    if not os.path.exists(cache_path):
        return True, 'cache_file_missing'

    recency_hours = get_cache_recency_hours(24)
    threshold_seconds = float(recency_hours) * 3600.0
    now = time.time()
    try:
        cache_age = max(0.0, now - os.path.getmtime(cache_path))
    except Exception:
        return True, 'cache_mtime_unreadable'
    if cache_age > threshold_seconds:
        return True, 'cache_older_than_{}h'.format(recency_hours)

    try:
        csv_mtime = os.path.getmtime(csv_path)
    except Exception:
        csv_mtime = 0
    if csv_mtime and csv_mtime > (now - threshold_seconds):
        return True, 'csv_recently_modified'

    if source_folder and os.path.isdir(source_folder):
        try:
            for name in os.listdir(source_folder):
                if name.lower().endswith('.csv'):
                    return True, 'source_folder_contains_csv'
        except Exception:
            pass

    return False, 'cache_fresh_within_{}h'.format(recency_hours)
