from __future__ import print_function

import io
import json
import os


def policy_envelope(effective_policy=None, source_map=None, reason='', warning=''):
    out = {
        'effective_policy': dict(effective_policy or {}),
        'policy_source_map': dict(source_map or {}),
        'policy_reason': str(reason or ''),
    }
    if warning:
        out['policy_warning'] = str(warning or '')
    return out


def attach_policy_metadata(target, effective_policy=None, source_map=None, reason='', warning=''):
    if not isinstance(target, dict):
        return target
    env = policy_envelope(effective_policy, source_map, reason, warning)
    target['effective_policy'] = env.get('effective_policy')
    target['policy_source_map'] = env.get('policy_source_map')
    target['policy_reason'] = env.get('policy_reason')
    if env.get('policy_warning'):
        target['policy_warning'] = env.get('policy_warning')
    return target


_POLICY_ATTACHMENT_KEYS = (
    'shadow_startup_policy',
    'discovery_scope_policy',
    'artifact_scope_policy',
    'phase_c_remediation_policy',
    'phase_f_auto_report_policy',
    'layer1_runbook_auto_policy',
    'config_write_policy',
    'json_health_auto_repair',
    'api_resilience_policy',
    'migration_audit_policy',
)


def _safe_text(value, limit=500):
    try:
        if value is None:
            return ''
        if isinstance(value, bytes):
            try:
                value = value.decode('ascii', 'ignore')
            except Exception:
                value = value.decode('utf-8', 'ignore')
        else:
            value = str(value)
        value = value.encode('ascii', 'ignore').decode('ascii', 'ignore')
        if limit and len(value) > limit:
            return value[:limit]
        return value
    except Exception:
        return ''


def _json_safe(value, depth=0, max_depth=5, max_items=40):
    if depth > max_depth:
        return '...'
    if isinstance(value, dict):
        out = {}
        count = 0
        for key in value:
            if count >= max_items:
                out['_truncated'] = True
                break
            out[_safe_text(key, 120)] = _json_safe(value.get(key), depth + 1, max_depth, max_items)
            count += 1
        return out
    if isinstance(value, (list, tuple, set)):
        out_list = []
        count = 0
        for item in value:
            if count >= max_items:
                out_list.append('...')
                break
            out_list.append(_json_safe(item, depth + 1, max_depth, max_items))
            count += 1
        return out_list
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, (int, float)):
        return value
    return _safe_text(value, 500)


def _env_flag_snapshot(env, name):
    env_map = env if isinstance(env, dict) else os.environ
    raw = ''
    try:
        raw = str(env_map.get(name, '') or '').strip()
    except Exception:
        raw = ''
    if raw == '':
        return {
            'effective_value': False,
            'policy_source_map': {'enabled': 'default'},
            'policy_reason': 'not_configured',
        }
    return {
        'effective_value': raw.lower() in ('1', 'true', 'yes', 'on'),
        'policy_source_map': {'enabled': 'env_override'},
        'policy_reason': 'env_override_active',
    }


def _policy_source(snapshot):
    if isinstance(snapshot, dict) and snapshot:
        return 'runtime_policy'
    return 'not_present'


def _copy_if_policy(out, source_map, key, value, source):
    if isinstance(value, dict) and value:
        out[key] = _json_safe(value)
        source_map[key] = source


def _collect_named_policy_blocks(value, out, depth=0):
    if depth > 5 or not isinstance(value, (dict, list, tuple)):
        return
    if isinstance(value, dict):
        for key in value:
            val = value.get(key)
            if key in _POLICY_ATTACHMENT_KEYS and isinstance(val, dict):
                out[key] = _json_safe(val)
            elif key == 'effective_policy' and isinstance(value.get('policy_source_map'), dict):
                out['embedded_effective_policy'] = _json_safe(value)
            elif isinstance(val, (dict, list, tuple)):
                _collect_named_policy_blocks(val, out, depth + 1)
    else:
        for item in value:
            _collect_named_policy_blocks(item, out, depth + 1)


def _read_json_attachment(path_or_content, max_bytes=2000000):
    if isinstance(path_or_content, dict):
        return path_or_content
    if not isinstance(path_or_content, str):
        return None
    if not os.path.isfile(path_or_content):
        return None
    try:
        if os.path.getsize(path_or_content) > max_bytes:
            return None
    except Exception:
        return None
    try:
        with io.open(path_or_content, 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except Exception:
        try:
            with open(path_or_content, 'r') as handle:
                return json.load(handle)
        except Exception:
            return None


def _attachment_policy_refs(attachment_entries, max_artifacts=12):
    refs = []
    for item in attachment_entries or []:
        if len(refs) >= max_artifacts:
            break
        if not isinstance(item, (list, tuple)) or len(item) < 2:
            continue
        name = _safe_text(item[0], 180)
        lower_name = name.lower()
        if not lower_name.endswith('.json') and 'summary' not in lower_name and 'manifest' not in lower_name and 'handoff' not in lower_name and 'report' not in lower_name:
            continue
        payload = _read_json_attachment(item[1])
        if not isinstance(payload, dict):
            continue
        policies = {}
        _collect_named_policy_blocks(payload, policies)
        if policies:
            refs.append({
                'attachment_name': name,
                'policy_keys': sorted(list(policies.keys())),
                'policies': policies,
            })
    return refs


def _extract_context_policies(extra_meta):
    out = {}
    em = extra_meta if isinstance(extra_meta, dict) else {}
    for key in _POLICY_ATTACHMENT_KEYS:
        val = em.get(key)
        if isinstance(val, dict):
            out[key] = _json_safe(val)
    if isinstance(em.get('queue_policy_snapshot'), dict):
        out['support_send_queue_policy'] = _json_safe(em.get('queue_policy_snapshot'))
    job_ctx = em.get('support_send_job_context')
    if isinstance(job_ctx, dict):
        qpol = job_ctx.get('queue_policy_snapshot')
        if isinstance(qpol, dict):
            out['support_send_queue_policy'] = _json_safe(qpol)
        decision = {}
        for key in (
                'job_id',
                'send_type',
                'policy_decision',
                'policy_reason',
                'worker_mode_policy',
                'worker_mode_policy_reason',
                'dedup_key',
                'dedup_key_components',
                'single_flight_policy_decision',
                'pipeline_defer_policy_decision'):
            if key in job_ctx:
                decision[key] = _json_safe(job_ctx.get(key))
        if decision:
            out['support_send_decision'] = decision
    return out


def build_bundle_policy_rollup(config=None, extra_meta=None, json_health_meta=None, attachment_entries=None, env=None):
    """
    Build one stable support-bundle policy index for meta.json.

    Detailed subsystem artifacts remain authoritative.  This rollup gives
    receiving triage a predictable first place to see which policy surfaces
    were active and where to look for the full evidence.
    """
    env_map = env if isinstance(env, dict) else os.environ
    source_map = {}
    rollup = {
        'schema_version': 1,
        'policy_reason': 'bundle_policy_rollup_resolved',
    }

    import_snapshot = {}
    try:
        from MediCafe.import_policy import import_policy_snapshot
        import_snapshot = import_policy_snapshot(env_map)
    except Exception:
        import_snapshot = {}
    _copy_if_policy(rollup, source_map, 'import_policy', import_snapshot, _policy_source(import_snapshot))

    diagnostics_snapshot = {}
    try:
        from MediCafe.diagnostics_policy import resolve_diagnostics_policy
        diagnostics_snapshot = resolve_diagnostics_policy(config, env_map)
    except Exception:
        diagnostics_snapshot = {}
    _copy_if_policy(rollup, source_map, 'diagnostics_policy', diagnostics_snapshot, _policy_source(diagnostics_snapshot))

    context_policies = _extract_context_policies(extra_meta)
    for key in context_policies:
        rollup[key] = context_policies.get(key)
        source_map[key] = 'bundle_extra_context'

    if isinstance(json_health_meta, dict) and json_health_meta:
        rollup['json_health_policy'] = _json_safe(json_health_meta)
        source_map['json_health_policy'] = 'bundle_attachment_builder'

    security_policy = {
        'offline_permissive': _env_flag_snapshot(env_map, 'MEDICAFE_OFFLINE_PERMISSIVE'),
        'xp_allow_insecure_payer_list_tls': _env_flag_snapshot(env_map, 'MEDICAFE_XP_ALLOW_INSECURE_PAYER_LIST_TLS'),
    }
    rollup['security_policy'] = security_policy
    source_map['security_policy'] = 'safety_rule'

    refs = _attachment_policy_refs(attachment_entries)
    if refs:
        rollup['attached_policy_artifacts'] = refs
        source_map['attached_policy_artifacts'] = 'attached_artifact_scan'

    rollup['policy_signal_summary'] = {
        'import_policy_present': bool(rollup.get('import_policy')),
        'diagnostics_policy_present': bool(rollup.get('diagnostics_policy')),
        'support_send_queue_policy_present': bool(rollup.get('support_send_queue_policy')),
        'config_write_policy_present': bool(rollup.get('config_write_policy')),
        'json_health_policy_present': bool(rollup.get('json_health_policy')),
        'attached_policy_artifact_count': len(refs),
        'offline_permissive_active': bool(security_policy.get('offline_permissive', {}).get('effective_value')),
        'insecure_payer_list_tls_active': bool(security_policy.get('xp_allow_insecure_payer_list_tls', {}).get('effective_value')),
    }
    source_map['policy_signal_summary'] = 'bundle_rollup'
    rollup['policy_source_map'] = source_map
    return _json_safe(rollup, max_depth=7, max_items=80)
