# -*- coding: utf-8 -*-
import json
import os
import shutil
import tempfile
import unittest
import zipfile

from MediCafe import xp_package_integrity as xpi
from tools import postbuild_validation as pbv


class PostbuildPackageGuardTests(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix="mc_postbuild_pkg_guard_")

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _write(self, rel_path, body):
        path = os.path.join(self.root, rel_path.replace("/", os.sep))
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        with open(path, "w") as fh:
            fh.write(body)
        return path

    def _archive_with_manifest(self, manifest, file_bodies):
        archive_path = os.path.join(self.root, "medicafe-0.test.1-py3-none-any.whl")
        with zipfile.ZipFile(archive_path, "w") as zf:
            zf.writestr("MediCafe/xp_packaged_file_manifest.json", json.dumps(manifest))
            for rel_path, body in file_bodies.items():
                zf.writestr(rel_path, body)
        return archive_path

    def test_validate_xp_manifest_matches_artifact_accepts_manifest_hashes(self):
        rel = "scripts/unified_model/future_deterministic_step.py"
        body = "print('fresh')"
        self._write(rel, body)
        manifest = xpi.build_expected_manifest(self.root, version="0.test.1", files=(rel,))
        archive_path = self._archive_with_manifest(manifest, {rel: body})

        pbv.validate_xp_manifest_matches_artifact(archive_path)

    def test_validate_xp_manifest_matches_artifact_rejects_stale_member(self):
        rel = "scripts/unified_model/future_deterministic_step.py"
        self._write(rel, "print('fresh')")
        manifest = xpi.build_expected_manifest(self.root, version="0.test.1", files=(rel,))
        archive_path = self._archive_with_manifest(manifest, {rel: "print('stale')"})

        with self.assertRaises(RuntimeError) as ctx:
            pbv.validate_xp_manifest_matches_artifact(archive_path)

        self.assertIn("XP packaged-file manifest mismatch", str(ctx.exception))
        self.assertIn(rel, str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
