# -*- coding: utf-8 -*-
"""Tests for lab shadow.lock acquisition (orphan/corrupt recovery)."""
from __future__ import print_function

import ctypes
import os
import shutil
import sys
import tempfile
import unittest

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
UM = os.path.join(REPO_ROOT, 'scripts', 'unified_model')
if UM not in sys.path:
    sys.path.insert(0, UM)

import lab_lock

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch


class TestShadowLockRecoverCorrupt(unittest.TestCase):
    def setUp(self):
        self.lab = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.lab, ignore_errors=True)

    def test_acquire_after_empty_lock_file(self):
        lock_p = os.path.join(self.lab, 'shadow.lock')
        with open(lock_p, 'w') as f:
            f.write('')
        self.assertTrue(lab_lock.acquire_lock(self.lab))
        try:
            self.assertTrue(os.path.exists(lock_p))
        finally:
            lab_lock.release_lock(self.lab)

    def test_acquire_after_lock_missing_pid_line(self):
        lock_p = os.path.join(self.lab, 'shadow.lock')
        with open(lock_p, 'w') as f:
            f.write('heartbeat_at_utc=2020-01-01T00:00:00Z\n')
        self.assertTrue(lab_lock.acquire_lock(self.lab))
        try:
            self.assertTrue(os.path.exists(lock_p))
        finally:
            lab_lock.release_lock(self.lab)

    def test_pid_running_windows_does_not_call_os_kill(self):
        class FakeKernel32(object):
            STILL_ACTIVE = 259

            def __init__(self):
                self.open_calls = []
                self.close_calls = []

            def OpenProcess(self, access, inherit, pid):
                self.open_calls.append((access, inherit, pid))
                return 123

            def GetExitCodeProcess(self, handle, exit_code_ptr):
                try:
                    exit_code_ptr.contents.value = 259
                except AttributeError:
                    exit_code_ptr._obj.value = 259
                return 1

            def CloseHandle(self, handle):
                self.close_calls.append(handle)
                return True

            def GetLastError(self):
                return 0

        fake_kernel = FakeKernel32()
        import types
        fake_windll = types.SimpleNamespace(kernel32=fake_kernel)
        with patch.object(lab_lock.os, 'name', 'nt'):
            with patch.object(ctypes, 'windll', fake_windll, create=True):
                with patch.object(lab_lock.os, 'kill') as kill_mock:
                    self.assertTrue(lab_lock._pid_running(456))

        self.assertEqual(kill_mock.call_count, 0)
        self.assertEqual(fake_kernel.open_calls[0][0], 0x1000)
        self.assertEqual(fake_kernel.open_calls[0][2], 456)
        self.assertEqual(fake_kernel.close_calls, [123])

    def test_pid_running_windows_access_denied_assumes_live(self):
        """OpenProcess may fail with ERROR_ACCESS_DENIED while the PID is still running."""

        class FakeKernel32(object):
            def OpenProcess(self, access, inherit, pid):
                return 0

            def GetLastError(self):
                return 5

        class FakeCtypes(object):
            pass

        fake_kernel = FakeKernel32()
        fake_ctypes = FakeCtypes()
        fake_ctypes.windll = FakeCtypes()
        fake_ctypes.windll.kernel32 = fake_kernel

        with patch.object(lab_lock.os, 'name', 'nt'):
            with patch.dict('sys.modules', {'ctypes': fake_ctypes}):
                with patch.object(lab_lock.os, 'kill') as kill_mock:
                    self.assertTrue(lab_lock._pid_running(999))

        self.assertEqual(kill_mock.call_count, 0)


if __name__ == '__main__':
    unittest.main()
