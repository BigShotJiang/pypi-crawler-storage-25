#!/usr/bin/env python
"""
Lab lock and safe-write utilities for Phase A bootstrap and diagnostics.
Extracted from bootstrap_lab for reuse by bootstrap_lab and diagnostics_runner.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import calendar
import json
import os
import sys
import time

STALE_THRESHOLD_SEC = 3600
# Refresh heartbeat at least this often during long-held lock (well under STALE_THRESHOLD_SEC).
HEARTBEAT_INTERVAL_SEC = 600  # 10 min


def _iso_utc_now():
    """ISO 8601 UTC timestamp."""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _pid_running(pid):
    """Check if process exists. Returns False if not running or check fails.

    On Windows, be conservative when the OS denies handle open (treat as running)
    so lab/shadow.lock is not stolen from a live owner. Mirrors the logic in
    MediCafe.cloud_readiness_health._pid_running.
    """
    try:
        pid_int = int(pid)
    except (TypeError, ValueError):
        return False
    if pid_int <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            PROCESS_QUERY_INFORMATION = 0x0400
            STILL_ACTIVE = 259

            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid_int)
            if not handle:
                handle = kernel32.OpenProcess(PROCESS_QUERY_INFORMATION, 0, pid_int)
            if not handle:
                try:
                    last_error = kernel32.GetLastError()
                    if int(last_error) == 5:
                        # ACCESS_DENIED: process likely exists; do not treat as dead.
                        return True
                except Exception:
                    pass
                return False
            try:
                exit_code = ctypes.c_ulong(0)
                if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return True
                return int(exit_code.value) == STILL_ACTIVE
            finally:
                kernel32.CloseHandle(handle)
        except Exception:
            # Uncertain: assume running so we do not clear locks out from under peers.
            return True
    try:
        os.kill(pid_int, 0)
        return True
    except OSError:
        return False


def _parse_lock_file(lock_path):
    """Parse lock file. Returns (pid, heartbeat_utc) or (None, None) on failure."""
    try:
        with open(lock_path, "r") as f:
            content = f.read()
        pid = None
        heartbeat = None
        for line in content.splitlines():
            if line.startswith("pid="):
                pid = line[4:].strip()
            elif line.startswith("heartbeat_at_utc="):
                heartbeat = line[17:].strip()
        return (pid, heartbeat)
    except Exception:
        return (None, None)


def _heartbeat_stale(heartbeat_str):
    """True if heartbeat older than STALE_THRESHOLD_SEC or unparseable."""
    if not heartbeat_str:
        return True
    try:
        struct = time.strptime(heartbeat_str.replace("Z", ""), "%Y-%m-%dT%H:%M:%S")
        heartbeat_epoch = calendar.timegm(struct)
        now_epoch = time.time()
        return (now_epoch - heartbeat_epoch) > STALE_THRESHOLD_SEC
    except Exception:
        return True


def acquire_lock(lab_root):
    """Acquire lab/shadow.lock. O_EXCL first; stale handling on failure."""
    lock_path = os.path.join(lab_root, "shadow.lock")
    max_retries = 2
    for attempt in range(max_retries + 1):
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            now = _iso_utc_now()
            content = "pid={0}\nacquired_at_utc={1}\nheartbeat_at_utc={1}\n".format(os.getpid(), now)
            os.write(fd, content.encode("ascii"))
            os.close(fd)
            return True
        except (OSError, IOError) as e:
            errno_val = getattr(e, "errno", None)
            if errno_val not in (17, 183):
                raise
        pid, heartbeat = _parse_lock_file(lock_path)
        # Missing/corrupt pid (empty file, wrong format) is recoverable like a stale lock.
        if pid is None or not str(pid).strip():
            try:
                if os.path.exists(lock_path):
                    os.remove(lock_path)
            except Exception:
                pass
            if attempt >= max_retries:
                print("Failed to acquire lock after {0} retries.".format(max_retries + 1), file=sys.stderr)
                sys.exit(1)
            continue
        pid_running = _pid_running(pid)
        heartbeat_stale = _heartbeat_stale(heartbeat)
        if pid_running and not heartbeat_stale:
            print("Concurrent run rejected: lab/shadow.lock held by another process.", file=sys.stderr)
            sys.exit(1)
        try:
            if os.path.exists(lock_path):
                os.remove(lock_path)
        except Exception:
            pass
        if attempt >= max_retries:
            print("Failed to acquire lock after {0} retries.".format(max_retries + 1), file=sys.stderr)
            sys.exit(1)
    return True


def refresh_heartbeat(lab_root, owner_pid=None):
    """
    Update heartbeat_at_utc in the lock file. Call periodically during long-held lock
    (at least every HEARTBEAT_INTERVAL_SEC) to avoid stale-lock takeover when scans exceed STALE_THRESHOLD_SEC.
    If owner_pid is set, only update when lock is held by that PID.
    """
    lock_path = os.path.join(lab_root, "shadow.lock")
    try:
        if not os.path.exists(lock_path):
            return
        pid, _ = _parse_lock_file(lock_path)
        if owner_pid is not None and pid not in (None, str(owner_pid)):
            return
        now = _iso_utc_now()
        lines = []
        with open(lock_path, "r") as f:
            for line in f:
                if line.startswith("heartbeat_at_utc="):
                    lines.append("heartbeat_at_utc={0}\n".format(now))
                else:
                    lines.append(line)
        with open(lock_path, "w") as f:
            f.writelines(lines)
    except Exception:
        pass


def read_lab_lock_diagnostic_metadata(lab_root):
    """
    Redacted shadow.lock metadata for support bundles (pid + heartbeat only).
    Intended for contention correlation with SQLite busy/lock diagnostics.
    """
    lock_path = os.path.join(lab_root or ".", "shadow.lock")
    out = {
        "lock_path": lock_path,
        "lock_pid": "",
        "lock_heartbeat_at_utc": "",
        "lock_owner_running": None,
    }
    if not lab_root or not os.path.isfile(lock_path):
        return out
    pid, heartbeat = _parse_lock_file(lock_path)
    out["lock_pid"] = str(pid or "").strip()
    out["lock_heartbeat_at_utc"] = str(heartbeat or "").strip()
    if out["lock_pid"]:
        try:
            out["lock_owner_running"] = bool(_pid_running(out["lock_pid"]))
        except Exception:
            out["lock_owner_running"] = None
    return out


def release_lock(lab_root, owner_pid=None):
    """Remove shadow.lock. If owner_pid is set, avoid deleting another process lock."""
    lock_path = os.path.join(lab_root, "shadow.lock")
    try:
        if not os.path.exists(lock_path):
            return
        pid, _heartbeat = _parse_lock_file(lock_path)
        if owner_pid is not None and pid not in (None, str(owner_pid)):
            return
        os.remove(lock_path)
    except Exception:
        pass


def replace_safe_write(path, content):
    """Write to a temp file, then os.replace into place (atomic swap where supported)."""
    tmp_path = path + ".tmp"
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(content, f, indent=2)
    try:
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.remove(tmp_path)
        except Exception:
            pass
        raise


def replace_safe_write_bytes(path, data):
    """Write bytes to a temp file, then os.replace into place (atomic swap where supported)."""
    tmp_path = path + ".tmp"
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(tmp_path, "wb") as f:
        f.write(data)
    try:
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.remove(tmp_path)
        except Exception:
            pass
        raise
