# LinkedIn Blog Post Draft

---

Your ABS light turns on.

The mechanic plugs in a diagnostic tool and it says: "ABS fault."

Cool. You already knew that. The light told you that. What you need to know is *why*.

Turns out it's a dying battery dropping voltage across the CAN bus. The ABS system is fine. The battery is not.

That's exactly what happens every time an engineer gets paged at 2am.

---

The error tracker fires. Stack trace points to `db/pool.py:142`. You open the file. The code looks fine. You start walking backwards — logs, traces, recent deploys — trying to reconstruct what actually happened in the 30 seconds before everything broke.

The real story, buried three layers deep: a recent deploy added a synchronous DB call to a hot path. Under load, 48 of 50 connections filled up. Three TimeoutErrors were silently swallowed. By the time the ConnectionError fired, all the context was gone.

Your monitoring tool showed you the symptom. Not the cause.

---

I built **because** to fix this.

It's a Python library that captures a rolling timeline of recent operations in-process — DB queries, HTTP calls, cache hits, log events — and attaches that context directly to the exception at throw time. Before you ever open a log file.

**Without because:**
```
ConnectionError: connection refused on localhost:5432
  File "db/pool.py", line 142, in execute
```

**With because:**
```
ConnectionError: connection refused on localhost:5432
  File "db/pool.py", line 142, in execute

[because context]
  Likely cause: Database connection pool may be exhausted
    • Exception message contains 'QueuePool limit'
    • 12 DB queries in context window
    • 9/12 recent DB queries failed (75% failure rate)
  Caught-and-swallowed (2):
    OperationalError: server closed the connection unexpectedly  (8s ago)
    OperationalError: server closed the connection unexpectedly  (3s ago)
  Recent operations:
    [ok]   db_query   2.1ms  SELECT * FROM orders WHERE user_id = ?
    [ok]   db_query   1.8ms  SELECT * FROM orders WHERE user_id = ?
    [FAIL] db_query   0.5ms  error=OperationalError
    [FAIL] db_query   0.5ms  error=OperationalError
    ...
```

Two swallowed errors. Pool draining under load. You know exactly where to look — before you've opened a single log.

---

The part I'm most proud of: **swallowed exception tracking.**

The hardest bugs to debug aren't the ones that crash loudly. They're the ones where some upstream error got caught, logged nowhere, and returned None. Then three function calls later something explodes with `AttributeError: 'NoneType' object has no attribute 'email'` — and you have no idea why.

```python
def get_user(user_id):
    with because.catch(Exception):
        return db.query(User).filter_by(id=user_id).one()
    return None  # ← this is the real problem
```

because surfaces that swallowed exception as the likely cause of the downstream crash. Not the AttributeError. The thing that actually broke.

---

It also ships with an optional LLM explainer (powered by @Anthropic Claude or @OpenAI GPT-4o) that reads the full context chain and gives you a plain-English root cause + suggested fix:

```
Root cause (high confidence): The database lookup silently failed due to a
dropped connection, returning None instead of a user object. The downstream
attribute access on that None value then raised AttributeError.

Suggested fix: Re-raise the OperationalError in get_user() rather than
swallowing it, and add a None-check before accessing .email.
```

No hallucinated causes. It's working from the structured context that because already captured — not guessing from a bare stack trace.

---

It plugs into the tools you're already using:

- **@Sentry** — attaches the context chain to every error event as structured extra data
- **@Datadog** — tags the active APM span with because context
- **OpenTelemetry / @CNCF** — emits operations as span events; `record_spans()` creates child spans for full trace detail
- **Flask, FastAPI, Django** — per-request buffer isolation out of the box
- **SQLAlchemy, requests, httpx, redis-py, Python logging** — drop-in instruments, zero config

---

Zero config to start:

```python
import because
because.install()
```

That's it. Any uncaught exception automatically gets enriched context. No platform. No backend. No vendor lock-in. Just a pip package.

```bash
pip install because-py
```

Or use the CLI to analyze any stack trace you paste in — no code changes at all:

```bash
cat error.log | because explain
```

---

I built this because I've spent too many hours staring at stack traces that told me *what* broke but not *why*. The context was always there — it just evaporated before anyone could look at it.

Now it doesn't.

---

GitHub: github.com/jacobthomasmichael/because
PyPI: pypi.org/project/because-py

Would love feedback from anyone who's felt this pain. Drop a comment or open an issue.

#python #debugging #observability #devtools #softwareengineering #opensource
