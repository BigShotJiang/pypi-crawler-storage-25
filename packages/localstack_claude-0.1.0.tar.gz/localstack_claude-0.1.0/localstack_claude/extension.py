"""LocalStack extension that wires the Claude API emulator into LocalStack's gateway."""

from __future__ import annotations

import logging

from localstack import config
from localstack.extensions.api import Extension

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.DEBUG if config.DEBUG else logging.INFO)

CLAUDE_HOST = "claude.localhost.localstack.cloud"
_HOST_PATTERN = f"{CLAUDE_HOST}<port:port>"


class ClaudeExtension(Extension):
    """
    LocalStack extension that exposes the Claude API emulator via LocalStack's
    gateway router.  Once registered, the emulator is reachable at:

        http://claude.localhost.localstack.cloud:<edge-port>

    Configure the Anthropic SDK by setting:

        ANTHROPIC_BASE_URL=http://claude.localhost.localstack.cloud:<edge-port>
        ANTHROPIC_API_KEY=test-key   # any non-empty value
    """

    name = "claude"

    def update_gateway_routes(self, router) -> None:
        from rolo.routing.rules import RuleAdapter, WithHost

        from claude_local.routes import ClaudeRoutes

        router.add(WithHost(_HOST_PATTERN, [RuleAdapter(ClaudeRoutes())]))
        LOG.info("Claude: registered routes on host pattern %s", _HOST_PATTERN)

    def on_platform_ready(self) -> None:
        try:
            from localstack import config, constants

            edge_port = config.get_edge_port_http()
            url = f"http://claude.{constants.LOCALHOST_HOSTNAME}:{edge_port}"
        except Exception:
            url = f"http://{CLAUDE_HOST}"

        LOG.info("Claude API emulator ready: %s", url)
        LOG.info(
            "Set ANTHROPIC_BASE_URL=%s and ANTHROPIC_API_KEY=test-key in your application.",
            url,
        )
