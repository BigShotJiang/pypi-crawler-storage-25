"""Response text generation for the Claude API emulator.

The emulator never calls a real LLM. Instead it produces a deterministic
response based on the request, configurable via env var or the store.
"""

from __future__ import annotations

import os

_DEFAULT_RESPONSE = os.environ.get(
    "CLAUDE_LOCAL_RESPONSE",
    "I'm claude-local, a local Claude API emulator for testing.",
)


def generate_text(_messages: list[dict], override: str | None = None) -> str:
    if override is not None:
        return override
    return _DEFAULT_RESPONSE


def count_tokens(text: str) -> int:
    """Approximate token count: ~4 chars per token."""
    return max(1, len(text) // 4)


def estimate_input_tokens(messages: list[dict], system: str | None) -> int:
    total = 0
    if system:
        total += count_tokens(system)
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total += count_tokens(content)
        elif isinstance(content, list):
            for block in content:
                total += count_tokens(block.get("text", "") or str(block.get("input", "")))
    return max(1, total)
