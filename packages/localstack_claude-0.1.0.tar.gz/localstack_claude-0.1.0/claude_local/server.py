"""Start/stop the Claude API emulator HTTP server."""

from __future__ import annotations

import logging
import os
import threading
from typing import Optional

from rolo import Router
from rolo.routing import handler_dispatcher
from werkzeug.serving import make_server, run_simple

from claude_local.routes import ClaudeRoutes

LOG = logging.getLogger(__name__)

DEFAULT_PORT = int(os.environ.get("CLAUDE_PORT", "5002"))
DEFAULT_HOST = os.environ.get("CLAUDE_HOST", "0.0.0.0")

_server: Optional[object] = None
_thread: Optional[threading.Thread] = None


def get_port() -> int:
    return DEFAULT_PORT


def create_router() -> Router:
    """Build and return a Router pre-loaded with all Claude API route handlers."""
    router = Router(dispatcher=handler_dispatcher())
    router.add(ClaudeRoutes())
    return router


def start(host: str = DEFAULT_HOST, port: int = DEFAULT_PORT) -> None:
    """Start the emulator in a background daemon thread."""
    global _server, _thread

    _server = make_server(host, port, create_router().wsgi())
    _thread = threading.Thread(target=_server.serve_forever, daemon=True, name="claude-local")
    _thread.start()
    LOG.info("Claude API emulator listening on http://%s:%d", host, port)


def stop() -> None:
    """Gracefully stop the emulator."""
    global _server, _thread
    if _server:
        _server.shutdown()
        _server = None
    if _thread:
        _thread.join(timeout=5)
        _thread = None


def main() -> None:
    """CLI entry point: run the emulator in the foreground."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    )
    logging.getLogger("claude_local").setLevel(logging.DEBUG)
    if os.environ.get("LS_LOG", "").lower() == "trace":
        # Lower root handler level so DEBUG messages from claude_local actually appear.
        for handler in logging.root.handlers:
            handler.setLevel(logging.DEBUG)
        LOG.debug("Trace logging enabled (LS_LOG=trace)")
    LOG.info("Starting Claude API emulator on http://%s:%d", DEFAULT_HOST, DEFAULT_PORT)
    run_simple(DEFAULT_HOST, DEFAULT_PORT, create_router().wsgi())


if __name__ == "__main__":
    main()
