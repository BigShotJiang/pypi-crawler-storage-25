"""In-memory store for the Claude API emulator.

The real Anthropic API is stateless (no server-side conversation storage),
so this store is used only for request/response logging and test introspection.
"""

from __future__ import annotations

import threading
from copy import deepcopy
from typing import Any


class ClaudeStore:
    """Thread-safe in-memory store for request history and emulator config."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.reset()

    def reset(self) -> None:
        with self._lock:
            self._request_log: list[dict[str, Any]] = []
            # Optional static response override for tests
            self._response_override: str | None = None

    def log(self, request: dict, response: dict) -> None:
        with self._lock:
            self._request_log.append({"request": deepcopy(request), "response": deepcopy(response)})

    def get_log(self) -> list[dict]:
        with self._lock:
            return deepcopy(self._request_log)

    def set_response_override(self, text: str | None) -> None:
        with self._lock:
            self._response_override = text

    def get_response_override(self) -> str | None:
        with self._lock:
            return self._response_override


store = ClaudeStore()
