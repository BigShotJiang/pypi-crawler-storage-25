"""Rolo route handlers for the Claude API emulator."""

from __future__ import annotations

import json
import logging
import os
import string
import uuid

from rolo import Request, Response
from rolo.routing import route

from claude_local import generator, models
from claude_local.backend import OllamaUnavailableError, get_backend
from claude_local.generator import count_tokens
from claude_local.store import store

LOG = logging.getLogger(__name__)


def _trace() -> bool:
    return os.environ.get("LS_LOG", "").lower() == "trace"

_ALPHABET = string.ascii_letters + string.digits

# The real Anthropic API returns IDs like "msg_01abc..." (base-62-ish, 27 chars after prefix).
_MSG_PREFIX = "msg_01"
_TOOL_PREFIX = "toolu_01"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _msg_id() -> str:
    raw = uuid.uuid4().hex + uuid.uuid4().hex
    encoded = "".join(_ALPHABET[int(raw[i : i + 2], 16) % len(_ALPHABET)] for i in range(0, 50, 2))
    return f"{_MSG_PREFIX}{encoded[:21]}"


def _tool_id() -> str:
    raw = uuid.uuid4().hex  # 32 hex chars → 16 two-char groups
    encoded = "".join(_ALPHABET[int(raw[i : i + 2], 16) % len(_ALPHABET)] for i in range(0, 32, 2))
    return f"{_TOOL_PREFIX}{encoded[:16]}"


def _req_id() -> str:
    """Generate a request ID in the same format as the real Anthropic API (req_...)."""
    raw = uuid.uuid4().hex + uuid.uuid4().hex
    encoded = "".join(_ALPHABET[int(raw[i : i + 2], 16) % len(_ALPHABET)] for i in range(0, 46, 2))
    return f"req_{encoded[:23]}"


def _json(body: dict | list, status: int = 200) -> Response:
    req_id = _req_id()
    return Response(
        json.dumps(body),
        status=status,
        mimetype="application/json",
        headers={"request-id": req_id},
    )


def _error(error_type: str, message: str, status: int) -> Response:
    req_id = _req_id()
    body = {
        "type": "error",
        "error": {"type": error_type, "message": message},
        "request_id": req_id,
    }
    return Response(
        json.dumps(body),
        status=status,
        mimetype="application/json",
        headers={"request-id": req_id},
    )


def _check_auth(request: Request) -> Response | None:
    key = (
        request.headers.get("x-api-key")
        or request.headers.get("X-Api-Key")
        or request.headers.get("Authorization", "").removeprefix("Bearer ").strip()
    )
    if not key:
        return _error("authentication_error", "x-api-key header is required", 401)
    return None


def _should_use_tool(request_body: dict, request: Request) -> str | None:
    """Return the tool name to call, or None if no tool call should be made."""
    tools = request_body.get("tools", [])
    if not tools:
        return None

    # Explicit header for test-driven tool calls
    forced = request.headers.get("X-Claude-Local-Tool") or request.headers.get(
        "x-claude-local-tool"
    )
    if forced:
        return forced

    # tool_choice = {"type": "tool", "name": "..."} forces a specific tool
    tool_choice = request_body.get("tool_choice", {})
    if isinstance(tool_choice, dict):
        if tool_choice.get("type") == "tool":
            return tool_choice.get("name", tools[0]["name"])
        if tool_choice.get("type") == "any":
            return tools[0]["name"]

    return None


def _build_tool_use_content(tool_name: str, tools: list[dict]) -> list[dict]:
    """Build a tool_use content block with stub inputs matching the tool schema."""
    tool_def = next((t for t in tools if t.get("name") == tool_name), {})
    schema = tool_def.get("input_schema", {})
    properties = schema.get("properties", {})
    required = schema.get("required", list(properties.keys()))
    stub_input = {prop: f"<{prop}>" for prop in required}
    return [{"type": "tool_use", "id": _tool_id(), "name": tool_name, "input": stub_input}]


def _build_response(
    msg_id: str,
    model_id: str,
    content_blocks: list[dict],
    stop_reason: str,
    input_tokens: int,
    output_tokens: int,
) -> dict:
    return {
        "id": msg_id,
        "type": "message",
        "role": "assistant",
        "content": content_blocks,
        "model": model_id,
        "stop_reason": stop_reason,
        "stop_sequence": None,
        "stop_details": None,
        "usage": {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 0,
            "cache_creation": {
                "ephemeral_1h_input_tokens": 0,
                "ephemeral_5m_input_tokens": 0,
            },
            "inference_geo": "not_available",
            "service_tier": "standard",
        },
    }


# ---------------------------------------------------------------------------
# Route handlers
# ---------------------------------------------------------------------------


class ClaudeRoutes:
    """All Claude API route handlers.

    In LocalStack extension mode these routes are mounted behind a host matcher
    so that only requests to ``CLAUDE_HOST`` reach them. In standalone mode they
    are served directly on the configured port.
    """

    # -------------------------------------------------------------------------
    # Messages
    # -------------------------------------------------------------------------

    @route("/v1/messages", methods=["POST"])
    def create_message(self, request: Request, **kwargs) -> Response:
        if err := _check_auth(request):
            return err

        body = request.get_json(force=True) or {}

        if _trace():
            LOG.debug("TRACE ← request: %s", json.dumps(body, indent=2)[:8000])

        # --- Validate required fields (error messages match real API exactly) ---
        if not body.get("model"):
            return _error("invalid_request_error", "model: Field required", 400)
        if "messages" not in body:
            return _error("invalid_request_error", "messages: Field required", 400)
        if "max_tokens" not in body:
            return _error("invalid_request_error", "max_tokens: Field required", 400)

        model_id_raw = body["model"]
        resolved_id = models.resolve_id(model_id_raw)
        if not resolved_id:
            return _error(
                "invalid_request_error",
                f"model: {model_id_raw}",
                400,
            )

        max_tokens: int = body["max_tokens"]
        limit = models.max_tokens_limit(model_id_raw)
        if max_tokens > limit:
            msg = (
                f"max_tokens: {max_tokens} > {limit}, which is the maximum allowed"
                f" number of output tokens for {resolved_id}"
            )
            return _error("invalid_request_error", msg, 400)

        messages: list[dict] = body["messages"]
        system: str | None = body.get("system")
        tools: list[dict] | None = body.get("tools") or None
        tool_choice: dict | None = body.get("tool_choice")
        stop_sequences: list[str] = body.get("stop_sequences") or []
        stream: bool = body.get("stream", False)

        # Static-backend shortcut: X-Claude-Local-Tool header forces a tool call
        # without going through the LLM. Useful for deterministic testing.
        forced_tool = _should_use_tool(body, request)
        if forced_tool:
            content_blocks = _build_tool_use_content(forced_tool, tools or [])
            stop_reason = "tool_use"
            input_tokens = generator.estimate_input_tokens(messages, system)
            output_tokens = generator.count_tokens(json.dumps(content_blocks))
            if stream:
                return self._stream_response(
                    resolved_id, content_blocks, stop_reason, input_tokens, output_tokens
                )
            return _json(
                _build_response(
                    _msg_id(), resolved_id, content_blocks, stop_reason, input_tokens, output_tokens
                )
            )

        backend = get_backend()
        try:
            if stream:
                text_gen = backend.stream(messages, system, tools, tool_choice, stop_sequences)
                input_tokens = generator.estimate_input_tokens(messages, system)
                return self._stream_response_from_generator(resolved_id, text_gen, input_tokens)

            response_text, tool_blocks, stop_reason = backend.generate(
                messages, system, tools, tool_choice, stop_sequences
            )
        except OllamaUnavailableError as exc:
            return _error("api_error", f"Backend unavailable: {exc}", 503)

        if tool_blocks:
            content_blocks = tool_blocks
        else:
            content_blocks = [{"type": "text", "text": response_text or ""}]

        input_tokens = generator.estimate_input_tokens(messages, system)
        output_tokens = generator.count_tokens(
            response_text if response_text else json.dumps(content_blocks)
        )
        response_body = _build_response(
            _msg_id(), resolved_id, content_blocks, stop_reason, input_tokens, output_tokens
        )
        store.log(body, response_body)
        if _trace():
            LOG.debug("TRACE → response: %s", json.dumps(response_body, indent=2)[:8000])
        return _json(response_body)

    def _stream_response(
        self,
        model_id: str,
        content_blocks: list[dict],
        stop_reason: str,
        input_tokens: int,
        output_tokens: int,
    ) -> Response:
        msg_id = _msg_id()

        def _sse(event: str, data: dict) -> bytes:
            return f"event: {event}\ndata: {json.dumps(data)}\n\n".encode()

        def generate():
            # message_start
            yield _sse(
                "message_start",
                {
                    "type": "message_start",
                    "message": {
                        "id": msg_id,
                        "type": "message",
                        "role": "assistant",
                        "content": [],
                        "model": model_id,
                        "stop_reason": None,
                        "stop_sequence": None,
                        "usage": {"input_tokens": input_tokens, "output_tokens": 1},
                    },
                },
            )

            for idx, block in enumerate(content_blocks):
                block_type = block["type"]
                if block_type == "text":
                    text = block["text"]
                    # content_block_start
                    yield _sse(
                        "content_block_start",
                        {
                            "type": "content_block_start",
                            "index": idx,
                            "content_block": {"type": "text", "text": ""},
                        },
                    )
                    # ping
                    yield _sse("ping", {"type": "ping"})
                    # stream text in ~20-char chunks
                    chunk_size = 20
                    for i in range(0, len(text), chunk_size):
                        yield _sse(
                            "content_block_delta",
                            {
                                "type": "content_block_delta",
                                "index": idx,
                                "delta": {"type": "text_delta", "text": text[i : i + chunk_size]},
                            },
                        )
                elif block_type == "tool_use":
                    yield _sse(
                        "content_block_start",
                        {
                            "type": "content_block_start",
                            "index": idx,
                            "content_block": {
                                "type": "tool_use",
                                "id": block["id"],
                                "name": block["name"],
                                "input": {},
                            },
                        },
                    )
                    yield _sse("ping", {"type": "ping"})
                    input_json = json.dumps(block.get("input", {}))
                    yield _sse(
                        "content_block_delta",
                        {
                            "type": "content_block_delta",
                            "index": idx,
                            "delta": {"type": "input_json_delta", "partial_json": input_json},
                        },
                    )

                yield _sse("content_block_stop", {"type": "content_block_stop", "index": idx})

            # message_delta
            yield _sse(
                "message_delta",
                {
                    "type": "message_delta",
                    "delta": {"stop_reason": stop_reason, "stop_sequence": None},
                    "usage": {"output_tokens": output_tokens},
                },
            )
            # message_stop
            yield _sse("message_stop", {"type": "message_stop"})

        return Response(
            generate(),
            status=200,
            content_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
                "request-id": str(uuid.uuid4()),
            },
        )

    def _stream_response_from_generator(
        self,
        model_id: str,
        text_chunks: object,
        input_tokens: int,
    ) -> Response:
        """SSE stream fed from an iterable of text chunks (Ollama backend)."""
        msg_id = _msg_id()

        def _sse(event: str, data: dict) -> bytes:
            return f"event: {event}\ndata: {json.dumps(data)}\n\n".encode()

        def generate():
            yield _sse(
                "message_start",
                {
                    "type": "message_start",
                    "message": {
                        "id": msg_id,
                        "type": "message",
                        "role": "assistant",
                        "content": [],
                        "model": model_id,
                        "stop_reason": None,
                        "stop_sequence": None,
                        "usage": {"input_tokens": input_tokens, "output_tokens": 1},
                    },
                },
            )
            yield _sse(
                "content_block_start",
                {
                    "type": "content_block_start",
                    "index": 0,
                    "content_block": {"type": "text", "text": ""},
                },
            )
            yield _sse("ping", {"type": "ping"})

            output_tokens = 0
            try:
                for chunk in text_chunks:
                    if chunk:
                        output_tokens += count_tokens(chunk)
                        yield _sse(
                            "content_block_delta",
                            {
                                "type": "content_block_delta",
                                "index": 0,
                                "delta": {"type": "text_delta", "text": chunk},
                            },
                        )
            except OllamaUnavailableError as exc:
                LOG.warning("Backend stream error: %s", exc)
            except Exception as exc:
                LOG.warning("Backend stream error: %s", exc, exc_info=True)

            yield _sse("content_block_stop", {"type": "content_block_stop", "index": 0})
            yield _sse(
                "message_delta",
                {
                    "type": "message_delta",
                    "delta": {"stop_reason": "end_turn", "stop_sequence": None},
                    "usage": {"output_tokens": max(1, output_tokens)},
                },
            )
            yield _sse("message_stop", {"type": "message_stop"})

        return Response(
            generate(),
            status=200,
            content_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
                "request-id": _req_id(),
            },
        )

    # -------------------------------------------------------------------------
    # Models
    # -------------------------------------------------------------------------

    @route("/v1/models", methods=["GET"])
    def list_models(self, request: Request, **kwargs) -> Response:
        if err := _check_auth(request):
            return err
        model_list = models.list_models()
        return _json(
            {
                "data": model_list,
                "has_more": False,
                "first_id": model_list[0]["id"] if model_list else None,
                "last_id": model_list[-1]["id"] if model_list else None,
            }
        )

    @route("/v1/models/<model_id>", methods=["GET"])
    def get_model(self, request: Request, model_id: str, **kwargs) -> Response:
        if err := _check_auth(request):
            return err
        model = models.resolve(model_id)
        if not model:
            return _error("not_found_error", f"model: {model_id}", 404)
        return _json(model)

    # -------------------------------------------------------------------------
    # Health / Reset / State
    # -------------------------------------------------------------------------

    @route("/_claude/health", methods=["GET"])
    def health(self, request: Request, **kwargs) -> Response:
        return _json({"status": "ok", "service": "claude-local"})

    @route("/_claude/reset", methods=["POST"])
    def reset(self, request: Request, **kwargs) -> Response:
        store.reset()
        return _json({"status": "ok", "message": "store reset"})

    @route("/_claude/state", methods=["GET"])
    def state(self, request: Request, **kwargs) -> Response:
        return _json({"request_log": store.get_log()})

    @route("/_claude/config", methods=["POST"])
    def configure(self, request: Request, **kwargs) -> Response:
        """Override the response text returned by the emulator (for testing)."""
        body = request.get_json(force=True) or {}
        override = body.get("response")
        store.set_response_override(override)
        return _json({"status": "ok", "response_override": override})
