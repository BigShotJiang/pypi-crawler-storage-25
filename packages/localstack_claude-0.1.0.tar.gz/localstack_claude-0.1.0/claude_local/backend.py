"""Backend abstraction for Claude API emulator response generation.

The emulator supports two backends, selected by CLAUDE_LOCAL_BACKEND:

  static (default)  – deterministic canned response; no external dependencies
  ollama            – forwards requests to an Ollama instance and converts the
                      OpenAI-compatible response back into Claude API format
"""

from __future__ import annotations

import json
import logging
import os
from abc import ABC, abstractmethod
from typing import Generator

import requests as _requests

try:
    from transformers import GenerationConfig
    from transformers import pipeline as hf_pipeline
except ImportError:
    GenerationConfig = None  # type: ignore[assignment,misc]
    hf_pipeline = None  # type: ignore[assignment]

from claude_local.generator import generate_text
from claude_local.store import store

LOG = logging.getLogger(__name__)


def _trace() -> bool:
    return os.environ.get("LS_LOG", "").lower() == "trace"

BACKEND_ENV = "CLAUDE_LOCAL_BACKEND"
OLLAMA_URL_ENV = "CLAUDE_LOCAL_OLLAMA_URL"
OLLAMA_MODEL_ENV = "CLAUDE_LOCAL_OLLAMA_MODEL"

_DEFAULT_OLLAMA_URL = "http://localhost:11434"
_DEFAULT_OLLAMA_MODEL = "llama3.2"


# ---------------------------------------------------------------------------
# Shared types
# ---------------------------------------------------------------------------

# generate() return: (text_or_None, tool_blocks_or_None, stop_reason)
GenerateResult = tuple[str | None, list[dict] | None, str]


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------


class Backend(ABC):
    @abstractmethod
    def generate(
        self,
        messages: list[dict],
        system: str | None,
        tools: list[dict] | None,
        tool_choice: dict | None,
        stop_sequences: list[str],
    ) -> GenerateResult:
        """Return (response_text, tool_blocks, stop_reason). Exactly one of
        response_text / tool_blocks is non-None."""

    @abstractmethod
    def stream(
        self,
        messages: list[dict],
        system: str | None,
        tools: list[dict] | None,
        tool_choice: dict | None,
        stop_sequences: list[str],
    ) -> Generator[str, None, None]:
        """Yield text chunks for a streaming response."""


# ---------------------------------------------------------------------------
# Static backend (default)
# ---------------------------------------------------------------------------


class StaticBackend(Backend):
    def generate(self, messages, system=None, tools=None, tool_choice=None, stop_sequences=None):
        text = generate_text(messages, store.get_response_override())
        stop_reason = "end_turn"
        for seq in stop_sequences or []:
            if seq in text:
                text = text[: text.index(seq)]
                stop_reason = "stop_sequence"
                break
        return text, None, stop_reason

    def stream(self, messages, system=None, tools=None, tool_choice=None, stop_sequences=None):
        text, _, _ = self.generate(messages, system, tools, tool_choice, stop_sequences)
        chunk = 20
        for i in range(0, len(text), chunk):
            yield text[i : i + chunk]


# ---------------------------------------------------------------------------
# Ollama backend
# ---------------------------------------------------------------------------


def _claude_tools_to_openai(tools: list[dict]) -> list[dict]:
    return [
        {
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t.get("description", ""),
                "parameters": t.get("input_schema", {"type": "object", "properties": {}}),
            },
        }
        for t in tools
    ]


def _claude_tool_choice_to_openai(tc: dict | None) -> str | dict | None:
    if not tc:
        return None
    kind = tc.get("type", "auto")
    if kind == "any":
        return "required"
    if kind == "none":
        return "none"
    if kind == "tool":
        return {"type": "function", "function": {"name": tc["name"]}}
    return "auto"


def _extract_text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict):
                if block.get("type") == "text":
                    parts.append(block.get("text", ""))
                elif block.get("type") == "tool_result":
                    c = block.get("content", "")
                    parts.append(c if isinstance(c, str) else json.dumps(c))
        return " ".join(parts)
    return ""


def _claude_messages_to_openai(messages: list[dict], system: str | list | None) -> list[dict]:
    result: list[dict] = []
    if system:
        system_text = system if isinstance(system, str) else _blocks_to_text(system)
        result.append({"role": "system", "content": system_text})

    for msg in messages:
        role = msg["role"]
        content = msg.get("content", "")

        if role == "assistant" and isinstance(content, list):
            # Check for tool_use blocks → OpenAI tool_calls
            tool_blocks = [
                b for b in content if isinstance(b, dict) and b.get("type") == "tool_use"
            ]
            text_blocks = [b for b in content if isinstance(b, dict) and b.get("type") == "text"]
            text = " ".join(b.get("text", "") for b in text_blocks)
            if tool_blocks:
                tool_calls = [
                    {
                        "id": b.get("id", f"call_{i}"),
                        "type": "function",
                        "function": {
                            "name": b["name"],
                            "arguments": json.dumps(b.get("input", {})),
                        },
                    }
                    for i, b in enumerate(tool_blocks)
                ]
                out: dict = {"role": "assistant", "content": text or None, "tool_calls": tool_calls}
                result.append(out)
                continue

        if role == "user" and isinstance(content, list):
            # Check for tool_result blocks → OpenAI tool role messages
            tool_results = [
                b for b in content if isinstance(b, dict) and b.get("type") == "tool_result"
            ]
            if tool_results:
                for tr in tool_results:
                    c = tr.get("content", "")
                    result.append(
                        {
                            "role": "tool",
                            "tool_call_id": tr.get("tool_use_id", ""),
                            "content": c if isinstance(c, str) else json.dumps(c),
                        }
                    )
                continue

        result.append({"role": role, "content": _extract_text(content)})

    return result


def _openai_response_to_claude(choice: dict) -> GenerateResult:
    message = choice.get("message", {})
    tool_calls = message.get("tool_calls")

    if tool_calls:
        tool_blocks = []
        for tc in tool_calls:
            fn = tc.get("function", {})
            try:
                inp = json.loads(fn.get("arguments", "{}"))
            except json.JSONDecodeError:
                inp = {}
            tool_blocks.append(
                {
                    "type": "tool_use",
                    "id": tc.get("id", f"toolu_01{len(tool_blocks)}"),
                    "name": fn.get("name", ""),
                    "input": inp,
                }
            )
        return None, tool_blocks, "tool_use"

    text = message.get("content") or ""
    finish = choice.get("finish_reason", "stop")
    stop_reason = "end_turn" if finish in ("stop", "length") else "end_turn"
    return text, None, stop_reason


class OllamaBackend(Backend):
    def __init__(self, url: str, model: str) -> None:
        self.url = url.rstrip("/")
        self.model = model

    def _post(self, payload: dict, stream: bool = False):
        try:
            return _requests.post(
                f"{self.url}/v1/chat/completions",
                json=payload,
                stream=stream,
                timeout=(10, 600),  # (connect, read): be patient for slow/large models
            )
        except Exception as exc:
            raise OllamaUnavailableError(str(exc)) from exc

    def _pull_model(self) -> None:
        """Pull the model from the Ollama registry (blocking, streams progress to logs)."""
        LOG.info("Model '%s' not found — pulling from Ollama registry...", self.model)
        try:
            with _requests.post(
                f"{self.url}/api/pull",
                json={"name": self.model},
                stream=True,
                timeout=600,
            ) as resp:
                resp.raise_for_status()
                last_status = ""
                for raw in resp.iter_lines():
                    if not raw:
                        continue
                    try:
                        data = json.loads(raw)
                        if "error" in data:
                            raise OllamaUnavailableError(
                                f"Failed to pull '{self.model}': {data['error']}"
                            )
                        status = data.get("status", "")
                        if status and status != last_status:
                            LOG.info("Pulling '%s': %s", self.model, status)
                            last_status = status
                    except json.JSONDecodeError:
                        pass
        except OllamaUnavailableError:
            raise
        except Exception as exc:
            raise OllamaUnavailableError(f"Pull request failed: {exc}") from exc
        LOG.info("Model '%s' is ready.", self.model)

    def _post_with_autopull(self, payload: dict, stream: bool = False):
        """POST to Ollama, pulling the model automatically on model-not-found 404."""
        resp = self._post(payload, stream=stream)
        if resp.status_code == 404:
            try:
                msg = resp.json().get("error", {}).get("message", resp.text)
            except Exception:
                msg = resp.text
            if "not found" in msg.lower():
                self._pull_model()
                resp = self._post(payload, stream=stream)
        return resp

    def generate(self, messages, system=None, tools=None, tool_choice=None, stop_sequences=None):
        openai_msgs = _claude_messages_to_openai(messages, system)
        payload: dict = {
            "model": self.model,
            "messages": openai_msgs,
            "stream": False,
            "keep_alive": -1,  # keep model loaded between requests
        }
        if tools:
            payload["tools"] = _claude_tools_to_openai(tools)
        if tool_choice is not None:
            oai_tc = _claude_tool_choice_to_openai(tool_choice)
            if oai_tc is not None:
                payload["tool_choice"] = oai_tc

        n_msgs = len(payload["messages"])
        LOG.info("Calling Ollama model '%s' (%d messages) ...", self.model, n_msgs)
        if _trace():
            LOG.debug("TRACE → Ollama request: %s", json.dumps(payload, indent=2)[:8000])

        resp = self._post_with_autopull(payload)
        if not resp.ok:
            raise OllamaUnavailableError(f"Ollama returned {resp.status_code}: {resp.text[:200]}")

        data = resp.json()
        stop_reason = data.get("choices", [{}])[0].get("finish_reason")
        LOG.info("Ollama response received (stop_reason=%s)", stop_reason)
        if _trace():
            LOG.debug("TRACE ← Ollama response: %s", json.dumps(data, indent=2)[:8000])
        choice = data["choices"][0]
        text, tool_blocks, stop_reason = _openai_response_to_claude(choice)

        # Apply stop sequences (text responses only)
        if text and stop_sequences:
            for seq in stop_sequences:
                if seq in text:
                    text = text[: text.index(seq)]
                    stop_reason = "stop_sequence"
                    break

        return text, tool_blocks, stop_reason

    def stream(self, messages, system=None, tools=None, tool_choice=None, stop_sequences=None):
        openai_msgs = _claude_messages_to_openai(messages, system)
        payload: dict = {
            "model": self.model,
            "messages": openai_msgs,
            "stream": True,
            "keep_alive": -1,  # keep model loaded between requests
        }
        if tools:
            payload["tools"] = _claude_tools_to_openai(tools)

        n_msgs = len(payload["messages"])
        LOG.info("Calling Ollama model '%s' streaming (%d messages) ...", self.model, n_msgs)
        if _trace():
            LOG.debug("TRACE → Ollama stream request: %s", json.dumps(payload, indent=2)[:8000])

        resp = self._post_with_autopull(payload, stream=True)
        if not resp.ok:
            raise OllamaUnavailableError(f"Ollama returned {resp.status_code}: {resp.text[:300]}")

        for raw_line in resp.iter_lines():
            if not raw_line:
                continue
            line = raw_line if isinstance(raw_line, str) else raw_line.decode()
            if not line.startswith("data: "):
                continue
            data_str = line[6:]
            if data_str.strip() == "[DONE]":
                break
            try:
                data = json.loads(data_str)
                delta = data["choices"][0]["delta"].get("content") or ""
                if delta:
                    yield delta
            except (json.JSONDecodeError, KeyError, IndexError):
                pass


class OllamaUnavailableError(Exception):
    pass


# ---------------------------------------------------------------------------
# Transformers (embedded) backend
# ---------------------------------------------------------------------------

MODEL_ID_ENV = "CLAUDE_LOCAL_MODEL_ID"
_DEFAULT_MODEL_ID = "HuggingFaceTB/SmolLM2-360M-Instruct"

# Keyed by model_id so changing the env var mid-process loads a fresh model.
_pipes: dict[str, object] = {}


def _blocks_to_text(blocks: list) -> str:
    """Flatten a list of content blocks to a plain string."""
    return " ".join(
        b.get("text", "") for b in blocks if isinstance(b, dict) and b.get("type") == "text"
    )


def _count_chat_tokens(chat: list[dict]) -> int:
    """Rough token estimate: ~4 chars per token."""
    return sum(len(msg.get("content", "")) for msg in chat) // 4


def _trim_to_fit(chat: list[dict], max_tokens: int = 6144) -> list[dict]:
    """Drop oldest non-system messages until the estimated token count fits."""
    system_msgs = [m for m in chat if m["role"] == "system"]
    other_msgs = [m for m in chat if m["role"] != "system"]
    original_count = len(other_msgs)
    while len(other_msgs) > 1 and _count_chat_tokens(system_msgs + other_msgs) > max_tokens:
        other_msgs.pop(0)
    dropped = original_count - len(other_msgs)
    if dropped:
        LOG.debug("Trimmed %d message(s) to fit within ~%d token budget", dropped, max_tokens)
    return system_msgs + other_msgs


def _to_chat_messages(messages: list[dict], system: str | list | None) -> list[dict]:
    result: list[dict] = []
    if system:
        system_text = system if isinstance(system, str) else _blocks_to_text(system)
        result.append({"role": "system", "content": system_text})
    for msg in messages:
        role = msg["role"]
        content = msg.get("content", "")
        if isinstance(content, str):
            result.append({"role": role, "content": content})
        elif isinstance(content, list):
            parts: list[str] = []
            for b in content:
                if not isinstance(b, dict):
                    continue
                if b.get("type") == "text":
                    parts.append(b.get("text", ""))
                elif b.get("type") == "tool_result":
                    c = b.get("content", "")
                    parts.append(c if isinstance(c, str) else _blocks_to_text(c))
            result.append({"role": role, "content": " ".join(parts)})
    return result


class TransformersBackend(Backend):
    def __init__(self, model_id: str) -> None:
        self.model_id = model_id

    def _get_pipe(self):
        if self.model_id not in _pipes:
            if hf_pipeline is None:
                raise RuntimeError(
                    "transformers not installed. Run: pip install 'localstack-claude[transformers]'"
                )
            LOG.info("Loading model %s (first request — may take a moment)", self.model_id)
            pipe = hf_pipeline("text-generation", model=self.model_id)
            # Replace the model's generation_config entirely (defence-in-depth; the pipeline
            # also caches the original config's do_sample in _default_params at init time,
            # so we must pass do_sample=False explicitly on every call — see generate() below).
            pipe.model.generation_config = GenerationConfig(do_sample=False, max_new_tokens=256)
            LOG.debug(
                "Model %s loaded — generation_config: do_sample=%s max_new_tokens=%s",
                self.model_id,
                pipe.model.generation_config.do_sample,
                pipe.model.generation_config.max_new_tokens,
            )
            _pipes[self.model_id] = pipe
        return _pipes[self.model_id]

    def generate(self, messages, system=None, tools=None, tool_choice=None, stop_sequences=None):
        try:
            pipe = self._get_pipe()
        except RuntimeError as exc:
            raise OllamaUnavailableError(str(exc)) from exc

        chat = _trim_to_fit(_to_chat_messages(messages, system))
        LOG.debug(
            "Calling pipeline with %d messages (est. %d tokens)",
            len(chat),
            _count_chat_tokens(chat),
        )
        try:
            # do_sample=False is passed explicitly on every call: the pipeline caches the
            # original generation_config's do_sample=True in _default_params at init time,
            # so replacing generation_config alone does not prevent sampling-mode execution.
            result = pipe(chat, do_sample=False)
            raw = result[0]["generated_text"][-1]["content"]
            text: str = raw if isinstance(raw, str) else _blocks_to_text(raw)
        except Exception:
            LOG.warning("Transformers generation failed; returning fallback", exc_info=True)
            return "I'm claude-local, a local Claude API emulator for testing.", None, "end_turn"

        stop_reason = "end_turn"
        for seq in stop_sequences or []:
            if seq in text:
                text = text[: text.index(seq)]
                stop_reason = "stop_sequence"
                break

        return text, None, stop_reason

    def stream(self, messages, system=None, tools=None, tool_choice=None, stop_sequences=None):
        text, _, _ = self.generate(messages, system, tools, tool_choice, stop_sequences)
        chunk = 20
        for i in range(0, len(text), chunk):
            yield text[i : i + chunk]


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def get_backend() -> Backend:
    kind = os.environ.get(BACKEND_ENV, "static").lower().strip()
    if kind == "ollama":
        url = os.environ.get(OLLAMA_URL_ENV, _DEFAULT_OLLAMA_URL)
        model = os.environ.get(OLLAMA_MODEL_ENV, _DEFAULT_OLLAMA_MODEL)
        LOG.info("Using Ollama backend: url=%s model=%s", url, model)
        return OllamaBackend(url, model)
    if kind == "transformers":
        model_id = os.environ.get(MODEL_ID_ENV, _DEFAULT_MODEL_ID)
        LOG.info("Using Transformers backend: model=%s", model_id)
        return TransformersBackend(model_id)
    return StaticBackend()
