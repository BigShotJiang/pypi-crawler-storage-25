"""Known Claude models served by the emulator.

Model data is sourced from the real Anthropic API (GET /v1/models) so the
emulator's catalogue stays in sync with what the real API returns.
"""

from __future__ import annotations

_CAP_OPUS_4_7 = {
    "batch": {"supported": True},
    "citations": {"supported": True},
    "code_execution": {"supported": True},
    "context_management": {
        "clear_thinking_20251015": {"supported": True},
        "clear_tool_uses_20250919": {"supported": True},
        "compact_20260112": {"supported": True},
        "supported": True,
    },
    "effort": {
        "high": {"supported": True},
        "low": {"supported": True},
        "max": {"supported": True},
        "medium": {"supported": True},
        "supported": True,
    },
    "image_input": {"supported": True},
    "pdf_input": {"supported": True},
    "structured_outputs": {"supported": True},
    "thinking": {
        "supported": True,
        "types": {"adaptive": {"supported": True}, "enabled": {"supported": False}},
    },
}

_CAP_SONNET_4_6 = {
    "batch": {"supported": True},
    "citations": {"supported": True},
    "code_execution": {"supported": True},
    "context_management": {
        "clear_thinking_20251015": {"supported": True},
        "clear_tool_uses_20250919": {"supported": True},
        "compact_20260112": {"supported": True},
        "supported": True,
    },
    "effort": {
        "high": {"supported": True},
        "low": {"supported": True},
        "max": {"supported": True},
        "medium": {"supported": True},
        "supported": True,
    },
    "image_input": {"supported": True},
    "pdf_input": {"supported": True},
    "structured_outputs": {"supported": True},
    "thinking": {
        "supported": True,
        "types": {"adaptive": {"supported": True}, "enabled": {"supported": True}},
    },
}

_CAP_OPUS_4_6 = _CAP_SONNET_4_6  # identical capability set

_CAP_OLDER_THINKING = {
    "batch": {"supported": True},
    "citations": {"supported": True},
    "code_execution": {"supported": False},
    "context_management": {
        "clear_thinking_20251015": {"supported": True},
        "clear_tool_uses_20250919": {"supported": True},
        "compact_20260112": {"supported": False},
        "supported": True,
    },
    "effort": {
        "high": {"supported": False},
        "low": {"supported": False},
        "max": {"supported": False},
        "medium": {"supported": False},
        "supported": False,
    },
    "image_input": {"supported": True},
    "pdf_input": {"supported": True},
    "structured_outputs": {"supported": True},
    "thinking": {
        "supported": True,
        "types": {"adaptive": {"supported": False}, "enabled": {"supported": True}},
    },
}

_CAP_OPUS_4_5 = {
    **_CAP_OLDER_THINKING,
    "code_execution": {"supported": True},
    # Opus 4.5 supports effort but not the max tier
    "effort": {
        "high": {"supported": True},
        "low": {"supported": True},
        "max": {"supported": False},
        "medium": {"supported": True},
        "supported": True,
    },
}

_CAP_SONNET_4_5 = {**_CAP_OLDER_THINKING, "code_execution": {"supported": True}}

_CAP_LEGACY_NO_STRUCTURED = {
    **_CAP_OLDER_THINKING,
    "structured_outputs": {"supported": False},
}

_MODELS: list[dict] = [
    {
        "type": "model",
        "id": "claude-opus-4-7",
        "display_name": "Claude Opus 4.7",
        "created_at": "2025-05-14T00:00:00Z",
        "max_tokens": 128000,
        "max_input_tokens": 1000000,
        "capabilities": _CAP_OPUS_4_7,
    },
    {
        "type": "model",
        "id": "claude-sonnet-4-6",
        "display_name": "Claude Sonnet 4.6",
        "created_at": "2025-05-14T00:00:00Z",
        "max_tokens": 128000,
        "max_input_tokens": 1000000,
        "capabilities": _CAP_SONNET_4_6,
    },
    {
        "type": "model",
        "id": "claude-opus-4-6",
        "display_name": "Claude Opus 4.6",
        "created_at": "2025-05-14T00:00:00Z",
        "max_tokens": 128000,
        "max_input_tokens": 1000000,
        "capabilities": _CAP_OPUS_4_6,
    },
    {
        "type": "model",
        "id": "claude-opus-4-5-20251101",
        "display_name": "Claude Opus 4.5",
        "created_at": "2025-11-01T00:00:00Z",
        "max_tokens": 64000,
        "max_input_tokens": 200000,
        "capabilities": _CAP_OPUS_4_5,
    },
    {
        "type": "model",
        "id": "claude-haiku-4-5-20251001",
        "display_name": "Claude Haiku 4.5",
        "created_at": "2025-10-01T00:00:00Z",
        "max_tokens": 64000,
        "max_input_tokens": 200000,
        "capabilities": _CAP_OLDER_THINKING,
    },
    {
        "type": "model",
        "id": "claude-sonnet-4-5-20250929",
        "display_name": "Claude Sonnet 4.5",
        "created_at": "2025-09-29T00:00:00Z",
        "max_tokens": 64000,
        "max_input_tokens": 1000000,
        "capabilities": _CAP_SONNET_4_5,
    },
    {
        "type": "model",
        "id": "claude-opus-4-1-20250805",
        "display_name": "Claude Opus 4.1",
        "created_at": "2025-08-05T00:00:00Z",
        "max_tokens": 32000,
        "max_input_tokens": 200000,
        "capabilities": _CAP_OLDER_THINKING,
    },
    {
        "type": "model",
        "id": "claude-opus-4-20250514",
        "display_name": "Claude Opus 4",
        "created_at": "2025-05-14T00:00:00Z",
        "max_tokens": 32000,
        "max_input_tokens": 200000,
        "capabilities": _CAP_LEGACY_NO_STRUCTURED,
    },
    {
        "type": "model",
        "id": "claude-sonnet-4-20250514",
        "display_name": "Claude Sonnet 4",
        "created_at": "2025-05-14T00:00:00Z",
        "max_tokens": 64000,
        "max_input_tokens": 1000000,
        "capabilities": _CAP_LEGACY_NO_STRUCTURED,
    },
]

# Alias → canonical ID
_ALIASES: dict[str, str] = {
    "claude-haiku-4-5": "claude-haiku-4-5-20251001",
    "claude-opus-4-5": "claude-opus-4-5-20251101",
    "claude-sonnet-4-5": "claude-sonnet-4-5-20250929",
    "claude-opus-4-1": "claude-opus-4-1-20250805",
    "claude-opus-4": "claude-opus-4-20250514",
    "claude-sonnet-4": "claude-sonnet-4-20250514",
}

_BY_ID: dict[str, dict] = {m["id"]: m for m in _MODELS}


def list_models() -> list[dict]:
    return list(_MODELS)


def resolve(model_id: str) -> dict | None:
    resolved = _ALIASES.get(model_id, model_id)
    return _BY_ID.get(resolved)


def resolve_id(model_id: str) -> str | None:
    m = resolve(model_id)
    return m["id"] if m else None


def max_tokens_limit(model_id: str) -> int:
    resolved = _ALIASES.get(model_id, model_id)
    m = _BY_ID.get(resolved)
    return m["max_tokens"] if m else 8192
