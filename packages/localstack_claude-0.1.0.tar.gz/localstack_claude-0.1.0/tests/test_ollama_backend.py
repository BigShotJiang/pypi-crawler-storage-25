"""Unit tests for the Ollama backend and the emulator routes when the
Ollama backend is active. Ollama's HTTP calls are intercepted via monkeypatch
so no real Ollama process is required."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from claude_local.backend import (
    OllamaBackend,
    OllamaUnavailableError,
    StaticBackend,
    _claude_messages_to_openai,
    _claude_tools_to_openai,
    get_backend,
)

# ---------------------------------------------------------------------------
# Helper: fake Ollama response
# ---------------------------------------------------------------------------


def _ollama_text_response(text: str, finish_reason: str = "stop") -> MagicMock:
    resp = MagicMock()
    resp.ok = True
    resp.json.return_value = {
        "choices": [
            {"message": {"role": "assistant", "content": text}, "finish_reason": finish_reason}
        ]
    }
    return resp


def _ollama_tool_response(name: str, args: dict) -> MagicMock:
    resp = MagicMock()
    resp.ok = True
    resp.json.return_value = {
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": None,
                    "tool_calls": [
                        {
                            "id": "call_abc",
                            "type": "function",
                            "function": {"name": name, "arguments": json.dumps(args)},
                        }
                    ],
                },
                "finish_reason": "tool_calls",
            }
        ]
    }
    return resp


def _ollama_stream_response(chunks: list[str]) -> MagicMock:
    resp = MagicMock()
    resp.ok = True

    def _lines():
        for i, chunk in enumerate(chunks):
            data = json.dumps({"choices": [{"delta": {"content": chunk}, "finish_reason": None}]})
            yield f"data: {data}".encode()
        yield b"data: [DONE]"

    resp.iter_lines.return_value = _lines()
    return resp


# ---------------------------------------------------------------------------
# get_backend factory
# ---------------------------------------------------------------------------


def test_get_backend_default_is_static(monkeypatch):
    monkeypatch.delenv("CLAUDE_LOCAL_BACKEND", raising=False)
    assert isinstance(get_backend(), StaticBackend)


def test_get_backend_static_explicit(monkeypatch):
    monkeypatch.setenv("CLAUDE_LOCAL_BACKEND", "static")
    assert isinstance(get_backend(), StaticBackend)


def test_get_backend_ollama(monkeypatch):
    monkeypatch.setenv("CLAUDE_LOCAL_BACKEND", "ollama")
    b = get_backend()
    assert isinstance(b, OllamaBackend)
    assert b.url == "http://localhost:11434"
    assert b.model == "llama3.2"


def test_get_backend_ollama_custom(monkeypatch):
    monkeypatch.setenv("CLAUDE_LOCAL_BACKEND", "ollama")
    monkeypatch.setenv("CLAUDE_LOCAL_OLLAMA_URL", "http://gpu-box:11434")
    monkeypatch.setenv("CLAUDE_LOCAL_OLLAMA_MODEL", "qwen2.5-coder")
    b = get_backend()
    assert b.url == "http://gpu-box:11434"
    assert b.model == "qwen2.5-coder"


# ---------------------------------------------------------------------------
# Message format conversion helpers
# ---------------------------------------------------------------------------


def test_claude_messages_to_openai_simple():
    msgs = [{"role": "user", "content": "Hello"}]
    result = _claude_messages_to_openai(msgs, system=None)
    assert result == [{"role": "user", "content": "Hello"}]


def test_claude_messages_to_openai_with_system():
    msgs = [{"role": "user", "content": "Hello"}]
    result = _claude_messages_to_openai(msgs, system="You are helpful.")
    assert result[0] == {"role": "system", "content": "You are helpful."}
    assert result[1]["role"] == "user"


def test_claude_messages_to_openai_system_as_list():
    """Claude Code sends system as a list of content blocks."""
    msgs = [{"role": "user", "content": "Hello"}]
    system = [{"type": "text", "text": "Be helpful."}, {"type": "text", "text": "Be concise."}]
    result = _claude_messages_to_openai(msgs, system=system)
    assert result[0]["role"] == "system"
    assert isinstance(result[0]["content"], str)
    assert "Be helpful." in result[0]["content"]
    assert "Be concise." in result[0]["content"]


def test_claude_messages_to_openai_tool_result_nested_content():
    """tool_result.content may be a list of content blocks."""
    msgs = [
        {"role": "user", "content": "Read it."},
        {
            "role": "assistant",
            "content": [{"type": "tool_use", "id": "toolu_01", "name": "read_file", "input": {}}],
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "toolu_01",
                    "content": [{"type": "text", "text": "file contents"}],
                }
            ],
        },
    ]
    result = _claude_messages_to_openai(msgs, system=None)
    tool_msg = next(m for m in result if m["role"] == "tool")
    assert "file contents" in tool_msg["content"]


def test_claude_messages_to_openai_tool_result():
    msgs = [
        {"role": "user", "content": "What's the weather?"},
        {
            "role": "assistant",
            "content": [
                {
                    "type": "tool_use",
                    "id": "toolu_01",
                    "name": "get_weather",
                    "input": {"location": "Boston"},
                }
            ],
        },
        {
            "role": "user",
            "content": [
                {"type": "tool_result", "tool_use_id": "toolu_01", "content": "72°F and sunny"}
            ],
        },
    ]
    result = _claude_messages_to_openai(msgs, system=None)
    assert result[0]["role"] == "user"
    assert result[1]["role"] == "assistant"
    assert result[1]["tool_calls"][0]["function"]["name"] == "get_weather"
    assert result[2]["role"] == "tool"
    assert result[2]["tool_call_id"] == "toolu_01"
    assert result[2]["content"] == "72°F and sunny"


def test_claude_tools_to_openai():
    tools = [
        {
            "name": "bash",
            "description": "Run a shell command.",
            "input_schema": {
                "type": "object",
                "properties": {"command": {"type": "string"}},
                "required": ["command"],
            },
        }
    ]
    result = _claude_tools_to_openai(tools)
    assert result[0]["type"] == "function"
    assert result[0]["function"]["name"] == "bash"
    assert "command" in result[0]["function"]["parameters"]["properties"]


# ---------------------------------------------------------------------------
# OllamaBackend.generate
# ---------------------------------------------------------------------------


def test_ollama_generate_text():
    backend = OllamaBackend("http://localhost:11434", "llama3.2")
    with patch.object(backend, "_post", return_value=_ollama_text_response("Hello there!")):
        text, tool_blocks, stop_reason = backend.generate(
            [{"role": "user", "content": "Hi"}], system=None
        )
    assert text == "Hello there!"
    assert tool_blocks is None
    assert stop_reason == "end_turn"


def test_ollama_generate_tool_use():
    backend = OllamaBackend("http://localhost:11434", "llama3.2")
    with patch.object(
        backend, "_post", return_value=_ollama_tool_response("bash", {"command": "ls"})
    ):
        text, tool_blocks, stop_reason = backend.generate(
            [{"role": "user", "content": "List files"}],
            system=None,
            tools=[
                {
                    "name": "bash",
                    "description": "Run bash",
                    "input_schema": {
                        "type": "object",
                        "properties": {"command": {"type": "string"}},
                        "required": ["command"],
                    },
                }
            ],
        )
    assert text is None
    assert tool_blocks is not None
    assert tool_blocks[0]["type"] == "tool_use"
    assert tool_blocks[0]["name"] == "bash"
    assert tool_blocks[0]["input"] == {"command": "ls"}
    assert stop_reason == "tool_use"


def test_ollama_generate_stop_sequence():
    backend = OllamaBackend("http://localhost:11434", "llama3.2")
    with patch.object(backend, "_post", return_value=_ollama_text_response("Hello STOP world")):
        text, _, stop_reason = backend.generate(
            [{"role": "user", "content": "Go"}], system=None, stop_sequences=["STOP"]
        )
    assert "STOP" not in text
    assert stop_reason == "stop_sequence"


def test_ollama_unavailable_raises():
    backend = OllamaBackend("http://localhost:19999", "llama3.2")
    with pytest.raises(OllamaUnavailableError):
        backend.generate([{"role": "user", "content": "Hi"}])


def test_ollama_autopull_on_model_not_found():
    """A 404 model-not-found response triggers an automatic pull, then retries."""
    backend = OllamaBackend("http://localhost:11434", "llama3.2")

    not_found = MagicMock()
    not_found.ok = False
    not_found.status_code = 404
    not_found.json.return_value = {"error": {"message": "model 'llama3.2' not found"}}
    not_found.text = '{"error":{"message":"model \'llama3.2\' not found"}}'

    success = _ollama_text_response("Hello after pull!")

    post_side_effects = [not_found, success]

    with patch.object(backend, "_post", side_effect=post_side_effects):
        with patch.object(backend, "_pull_model") as mock_pull:
            text, _, stop_reason = backend.generate([{"role": "user", "content": "Hi"}])

    mock_pull.assert_called_once()
    assert text == "Hello after pull!"
    assert stop_reason == "end_turn"


def test_ollama_autopull_stream_on_model_not_found():
    """Streaming path also triggers autopull on model-not-found 404."""
    backend = OllamaBackend("http://localhost:11434", "llama3.2")

    not_found = MagicMock()
    not_found.ok = False
    not_found.status_code = 404
    not_found.json.return_value = {"error": {"message": "model 'llama3.2' not found"}}
    not_found.text = '{"error":{"message":"model \'llama3.2\' not found"}}'

    stream_resp = _ollama_stream_response(["Hi", " there"])

    with patch.object(backend, "_post", side_effect=[not_found, stream_resp]):
        with patch.object(backend, "_pull_model") as mock_pull:
            chunks = list(backend.stream([{"role": "user", "content": "Hi"}]))

    mock_pull.assert_called_once()
    assert "".join(chunks) == "Hi there"


def test_ollama_non_404_errors_not_pulled():
    """Non-404 errors (e.g. 500) must not trigger a pull."""
    backend = OllamaBackend("http://localhost:11434", "llama3.2")

    server_error = MagicMock()
    server_error.ok = False
    server_error.status_code = 500
    server_error.text = "internal server error"

    with patch.object(backend, "_post", return_value=server_error):
        with patch.object(backend, "_pull_model") as mock_pull:
            with pytest.raises(OllamaUnavailableError, match="500"):
                backend.generate([{"role": "user", "content": "Hi"}])

    mock_pull.assert_not_called()


# ---------------------------------------------------------------------------
# OllamaBackend.stream
# ---------------------------------------------------------------------------


def test_ollama_stream_yields_chunks():
    backend = OllamaBackend("http://localhost:11434", "llama3.2")
    with patch.object(
        backend, "_post", return_value=_ollama_stream_response(["Hello", " world", "!"])
    ):
        chunks = list(backend.stream([{"role": "user", "content": "Hi"}]))
    assert "".join(chunks) == "Hello world!"


# ---------------------------------------------------------------------------
# Route integration: Ollama backend via HTTP client
# ---------------------------------------------------------------------------


def _make_client(monkeypatch):
    from werkzeug.test import Client

    from claude_local.server import create_router

    monkeypatch.setenv("CLAUDE_LOCAL_BACKEND", "ollama")
    monkeypatch.setenv("CLAUDE_LOCAL_OLLAMA_URL", "http://localhost:11434")
    return Client(create_router().wsgi())


def test_route_uses_ollama_backend(monkeypatch):
    client = _make_client(monkeypatch)
    mock_resp = _ollama_text_response("Hi from Ollama!")
    with patch("claude_local.backend.OllamaBackend._post", return_value=mock_resp):
        resp = client.post(
            "/v1/messages",
            data=json.dumps(
                {
                    "model": "claude-haiku-4-5",
                    "max_tokens": 64,
                    "messages": [{"role": "user", "content": "Hello"}],
                }
            ),
            headers={"x-api-key": "test", "Content-Type": "application/json"},
        )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["content"][0]["text"] == "Hi from Ollama!"


def test_route_ollama_tool_use(monkeypatch):
    client = _make_client(monkeypatch)
    mock_resp = _ollama_tool_response("get_weather", {"location": "Boston"})
    with patch("claude_local.backend.OllamaBackend._post", return_value=mock_resp):
        resp = client.post(
            "/v1/messages",
            data=json.dumps(
                {
                    "model": "claude-haiku-4-5",
                    "max_tokens": 128,
                    "tools": [
                        {
                            "name": "get_weather",
                            "description": "Get weather",
                            "input_schema": {
                                "type": "object",
                                "properties": {"location": {"type": "string"}},
                                "required": ["location"],
                            },
                        }
                    ],
                    "tool_choice": {"type": "any"},
                    "messages": [{"role": "user", "content": "Weather in Boston?"}],
                }
            ),
            headers={"x-api-key": "test", "Content-Type": "application/json"},
        )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["stop_reason"] == "tool_use"
    assert data["content"][0]["type"] == "tool_use"
    assert data["content"][0]["name"] == "get_weather"


def test_route_ollama_unavailable_returns_503(monkeypatch):
    client = _make_client(monkeypatch)
    with patch(
        "claude_local.backend.OllamaBackend._post",
        side_effect=OllamaUnavailableError("connection refused"),
    ):
        resp = client.post(
            "/v1/messages",
            data=json.dumps(
                {
                    "model": "claude-haiku-4-5",
                    "max_tokens": 64,
                    "messages": [{"role": "user", "content": "Hello"}],
                }
            ),
            headers={"x-api-key": "test", "Content-Type": "application/json"},
        )
    assert resp.status_code == 503
    data = resp.get_json()
    assert data["type"] == "error"
    assert data["error"]["type"] == "api_error"


def test_route_ollama_streaming(monkeypatch):
    client = _make_client(monkeypatch)
    mock_stream = _ollama_stream_response(["Hello", " from", " Ollama"])
    with patch("claude_local.backend.OllamaBackend._post", return_value=mock_stream):
        resp = client.post(
            "/v1/messages",
            data=json.dumps(
                {
                    "model": "claude-haiku-4-5",
                    "max_tokens": 64,
                    "stream": True,
                    "messages": [{"role": "user", "content": "Hello"}],
                }
            ),
            headers={"x-api-key": "test", "Content-Type": "application/json"},
        )
        # Read response body inside the patch context: the backend stream generator
        # is consumed lazily, so the mock must still be active when we iterate it.
        raw = resp.data.decode()

    assert resp.status_code == 200
    assert "text/event-stream" in resp.content_type

    events = [json.loads(line[6:]) for line in raw.split("\n") if line.strip().startswith("data: ")]
    types = [e["type"] for e in events]
    assert types[0] == "message_start"
    assert types[-1] == "message_stop"
    full_text = "".join(e["delta"]["text"] for e in events if e["type"] == "content_block_delta")
    assert full_text == "Hello from Ollama"


def test_route_ollama_system_as_list(monkeypatch):
    """System prompt as list of content blocks must reach Ollama as a plain string."""
    client = _make_client(monkeypatch)
    mock_resp = _ollama_text_response("OK")
    with patch("claude_local.backend.OllamaBackend._post", return_value=mock_resp) as mock_post:
        resp = client.post(
            "/v1/messages",
            data=json.dumps(
                {
                    "model": "claude-haiku-4-5",
                    "max_tokens": 64,
                    "system": [
                        {"type": "text", "text": "Be helpful."},
                        {"type": "text", "text": "Be concise."},
                    ],
                    "messages": [{"role": "user", "content": "Hello"}],
                }
            ),
            headers={"x-api-key": "test", "Content-Type": "application/json"},
        )
    assert resp.status_code == 200
    payload = mock_post.call_args[0][0]  # first positional arg to _post()
    system_msg = next(m for m in payload["messages"] if m["role"] == "system")
    assert isinstance(system_msg["content"], str)
    assert "Be helpful." in system_msg["content"]


def test_route_ollama_tool_result_nested_content(monkeypatch):
    """Multi-turn with tool_result.content as a list must not crash."""
    client = _make_client(monkeypatch)
    mock_resp = _ollama_text_response("Done.")
    with patch("claude_local.backend.OllamaBackend._post", return_value=mock_resp):
        resp = client.post(
            "/v1/messages",
            data=json.dumps(
                {
                    "model": "claude-haiku-4-5",
                    "max_tokens": 64,
                    "messages": [
                        {"role": "user", "content": "Read the file."},
                        {
                            "role": "assistant",
                            "content": [
                                {
                                    "type": "tool_use",
                                    "id": "toolu_01",
                                    "name": "read_file",
                                    "input": {"path": "README.md"},
                                }
                            ],
                        },
                        {
                            "role": "user",
                            "content": [
                                {
                                    "type": "tool_result",
                                    "tool_use_id": "toolu_01",
                                    "content": [
                                        {"type": "text", "text": "# Project\nThis is the README."}
                                    ],
                                }
                            ],
                        },
                    ],
                }
            ),
            headers={"x-api-key": "test", "Content-Type": "application/json"},
        )
    assert resp.status_code == 200
    assert resp.get_json()["type"] == "message"
