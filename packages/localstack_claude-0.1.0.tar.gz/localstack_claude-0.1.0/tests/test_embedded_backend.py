"""Unit tests for the TransformersBackend (embedded LLM) and the emulator
routes when the transformers backend is active.  The transformers library is
mocked so no real model download or GPU is required."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from claude_local.backend import (
    OllamaUnavailableError,
    StaticBackend,
    TransformersBackend,
    _count_chat_tokens,
    _to_chat_messages,
    _trim_to_fit,
    get_backend,
)

# ---------------------------------------------------------------------------
# Helper: fake pipeline callable
# ---------------------------------------------------------------------------


def _fake_pipe(text: str) -> MagicMock:
    """Return a callable that mimics transformers pipeline output."""
    pipe = MagicMock()
    pipe.return_value = [{"generated_text": [{"role": "assistant", "content": text}]}]
    return pipe


# ---------------------------------------------------------------------------
# get_backend factory
# ---------------------------------------------------------------------------


def test_get_backend_transformers(monkeypatch):
    monkeypatch.setenv("CLAUDE_LOCAL_BACKEND", "transformers")
    monkeypatch.delenv("CLAUDE_LOCAL_MODEL_ID", raising=False)
    b = get_backend()
    assert isinstance(b, TransformersBackend)
    assert b.model_id == "HuggingFaceTB/SmolLM2-360M-Instruct"


def test_get_backend_transformers_custom_model(monkeypatch):
    monkeypatch.setenv("CLAUDE_LOCAL_BACKEND", "transformers")
    monkeypatch.setenv("CLAUDE_LOCAL_MODEL_ID", "Qwen/Qwen2-0.5B-Instruct")
    b = get_backend()
    assert isinstance(b, TransformersBackend)
    assert b.model_id == "Qwen/Qwen2-0.5B-Instruct"


def test_get_backend_default_not_transformers(monkeypatch):
    monkeypatch.delenv("CLAUDE_LOCAL_BACKEND", raising=False)
    assert isinstance(get_backend(), StaticBackend)


# ---------------------------------------------------------------------------
# _to_chat_messages helper
# ---------------------------------------------------------------------------


def test_to_chat_messages_simple():
    msgs = [{"role": "user", "content": "Hello"}]
    result = _to_chat_messages(msgs, system=None)
    assert result == [{"role": "user", "content": "Hello"}]


def test_to_chat_messages_with_system():
    msgs = [{"role": "user", "content": "Hello"}]
    result = _to_chat_messages(msgs, system="You are helpful.")
    assert result[0] == {"role": "system", "content": "You are helpful."}
    assert result[1] == {"role": "user", "content": "Hello"}


def test_to_chat_messages_system_as_list():
    """Claude API allows system to be a list of content blocks (Claude Code sends this)."""
    msgs = [{"role": "user", "content": "Hello"}]
    system = [{"type": "text", "text": "Be concise."}, {"type": "text", "text": "Be helpful."}]
    result = _to_chat_messages(msgs, system=system)
    assert result[0]["role"] == "system"
    assert isinstance(result[0]["content"], str)
    assert "Be concise." in result[0]["content"]
    assert "Be helpful." in result[0]["content"]


def test_to_chat_messages_list_content():
    msgs = [
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "What is"},
                {"type": "text", "text": " the answer?"},
            ],
        }
    ]
    result = _to_chat_messages(msgs, system=None)
    assert "What is" in result[0]["content"]
    assert "the answer?" in result[0]["content"]


def test_to_chat_messages_tool_result():
    msgs = [
        {
            "role": "user",
            "content": [{"type": "tool_result", "tool_use_id": "x", "content": "72°F"}],
        }
    ]
    result = _to_chat_messages(msgs, system=None)
    assert result[0]["role"] == "user"
    assert "72°F" in result[0]["content"]


def test_to_chat_messages_tool_result_nested_list():
    """tool_result content can be a list of content blocks (Claude Code sends these)."""
    msgs = [
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "toolu_01",
                    "content": [{"type": "text", "text": "file1 file2"}],
                }
            ],
        }
    ]
    result = _to_chat_messages(msgs, system=None)
    assert result[0]["role"] == "user"
    assert isinstance(result[0]["content"], str)
    assert "file1 file2" in result[0]["content"]


# ---------------------------------------------------------------------------
# _trim_to_fit context-window helper
# ---------------------------------------------------------------------------


def test_count_chat_tokens_empty():
    assert _count_chat_tokens([]) == 0


def test_count_chat_tokens_estimates():
    chat = [{"role": "user", "content": "a" * 400}]
    assert _count_chat_tokens(chat) == 100  # 400 chars / 4


def test_trim_to_fit_noop_when_small():
    chat = [{"role": "user", "content": "Hello"}]
    assert _trim_to_fit(chat, max_tokens=6144) == chat


def test_trim_to_fit_drops_oldest_messages():
    # 3 non-system messages each ~5000 tokens (20000 chars); total ~15000 > 6144 budget
    big = "x" * 20_000
    chat = [
        {"role": "user", "content": big},
        {"role": "assistant", "content": big},
        {"role": "user", "content": big},
    ]
    trimmed = _trim_to_fit(chat, max_tokens=6144)
    # Should have dropped oldest messages until it fits (or only 1 remains)
    assert len(trimmed) < 3
    assert trimmed[-1]["role"] == "user"  # last message preserved


def test_trim_to_fit_preserves_system_message():
    big = "x" * 6400
    chat = [
        {"role": "system", "content": "Be helpful."},
        {"role": "user", "content": big},
        {"role": "assistant", "content": big},
        {"role": "user", "content": big},
    ]
    trimmed = _trim_to_fit(chat, max_tokens=6144)
    assert trimmed[0]["role"] == "system"
    assert trimmed[0]["content"] == "Be helpful."


def test_trim_to_fit_always_keeps_last_message():
    # Even if the single remaining message exceeds budget, it must be kept
    big = "x" * 100_000
    chat = [{"role": "user", "content": big}]
    trimmed = _trim_to_fit(chat, max_tokens=100)
    assert len(trimmed) == 1
    assert trimmed[0]["role"] == "user"


# ---------------------------------------------------------------------------
# TransformersBackend._get_pipe — generation config
# ---------------------------------------------------------------------------


def test_get_pipe_replaces_generation_config_with_greedy():
    """_get_pipe must replace the model's generation_config with a fresh GenerationConfig
    that has do_sample=False.  Mutating individual attributes is unreliable because
    transformers re-derives do_sample at generate() time, leading to nan/inf crashes."""
    backend = TransformersBackend("greedy-model")

    fake_pipe = _fake_pipe("ok")
    fake_pipe.model = MagicMock()

    gen_config_calls: list[dict] = []

    def fake_gen_config(**kwargs):
        gen_config_calls.append(kwargs)
        return MagicMock(**kwargs)

    fake_pipe_factory = MagicMock(return_value=fake_pipe)

    with patch.dict("claude_local.backend._pipes", {}, clear=True):
        with patch("claude_local.backend.hf_pipeline", fake_pipe_factory):
            with patch("claude_local.backend.GenerationConfig", fake_gen_config):
                backend._get_pipe()

    assert len(gen_config_calls) == 1, "GenerationConfig must be instantiated exactly once"
    assert gen_config_calls[0].get("do_sample") is False
    assert gen_config_calls[0].get("max_new_tokens") == 256
    # The new config must be assigned to the model
    assert fake_pipe.model.generation_config is not None


def test_get_pipe_generate_passes_do_sample_false():
    """pipe() must be called with do_sample=False on every call.
    The pipeline caches the original generation_config's do_sample=True in _default_params
    at init time, so replacing generation_config alone is not enough — the kwarg must be
    passed explicitly to override it and prevent nan/inf RuntimeErrors from sampling."""
    backend = TransformersBackend("test-model")
    pipe = _fake_pipe("answer")
    pipe.model = MagicMock()
    with patch("claude_local.backend._pipes", {"test-model": pipe}):
        backend.generate([{"role": "user", "content": "Hi"}])
    call_kwargs = pipe.call_args[1] if pipe.call_args else {}
    assert call_kwargs.get("do_sample") is False


# ---------------------------------------------------------------------------
# TransformersBackend.generate
# ---------------------------------------------------------------------------


def test_transformers_generate_text():
    backend = TransformersBackend("test-model")
    pipe = _fake_pipe("The answer is 42.")
    with patch("claude_local.backend._pipes", {"test-model": pipe}):
        text, tool_blocks, stop_reason = backend.generate(
            [{"role": "user", "content": "What is 6*7?"}]
        )
    assert text == "The answer is 42."
    assert tool_blocks is None
    assert stop_reason == "end_turn"


def test_transformers_generate_with_system():
    backend = TransformersBackend("test-model")
    pipe = _fake_pipe("Sure, I can help.")
    with patch("claude_local.backend._pipes", {"test-model": pipe}):
        text, _, _ = backend.generate(
            [{"role": "user", "content": "Help me."}],
            system="You are a helpful assistant.",
        )
    # Verify the pipeline was called with a system message prepended
    call_args = pipe.call_args[0][0]
    assert call_args[0] == {"role": "system", "content": "You are a helpful assistant."}
    assert text == "Sure, I can help."


def test_transformers_generate_stop_sequence():
    backend = TransformersBackend("test-model")
    pipe = _fake_pipe("Hello STOP this is extra")
    with patch("claude_local.backend._pipes", {"test-model": pipe}):
        text, _, stop_reason = backend.generate(
            [{"role": "user", "content": "Go"}],
            stop_sequences=["STOP"],
        )
    assert "STOP" not in text
    assert text == "Hello "
    assert stop_reason == "stop_sequence"


def test_transformers_generate_no_stop_when_sequence_absent():
    backend = TransformersBackend("test-model")
    pipe = _fake_pipe("Normal response.")
    with patch("claude_local.backend._pipes", {"test-model": pipe}):
        text, _, stop_reason = backend.generate(
            [{"role": "user", "content": "Go"}],
            stop_sequences=["NEVER_PRESENT"],
        )
    assert text == "Normal response."
    assert stop_reason == "end_turn"


def test_transformers_missing_library_raises():
    backend = TransformersBackend("no-model")
    with patch.dict("claude_local.backend._pipes", {}, clear=True):
        with patch("claude_local.backend.hf_pipeline", None):
            with pytest.raises(OllamaUnavailableError, match="transformers not installed"):
                backend.generate([{"role": "user", "content": "Hi"}])


# ---------------------------------------------------------------------------
# TransformersBackend.stream
# ---------------------------------------------------------------------------


def test_transformers_stream_yields_chunks():
    backend = TransformersBackend("test-model")
    pipe = _fake_pipe("A" * 50)  # 50-char response → at least 2 chunks of 20
    with patch("claude_local.backend._pipes", {"test-model": pipe}):
        chunks = list(backend.stream([{"role": "user", "content": "Hi"}]))
    assert "".join(chunks) == "A" * 50
    assert len(chunks) >= 2


def test_transformers_stream_short_response():
    backend = TransformersBackend("test-model")
    pipe = _fake_pipe("Hi!")
    with patch("claude_local.backend._pipes", {"test-model": pipe}):
        chunks = list(backend.stream([{"role": "user", "content": "Hi"}]))
    assert "".join(chunks) == "Hi!"


# ---------------------------------------------------------------------------
# Route integration: Transformers backend via HTTP client
# ---------------------------------------------------------------------------


def _make_client(monkeypatch):
    from werkzeug.test import Client

    from claude_local.server import create_router

    monkeypatch.setenv("CLAUDE_LOCAL_BACKEND", "transformers")
    monkeypatch.setenv("CLAUDE_LOCAL_MODEL_ID", "test-model")
    return Client(create_router().wsgi())


def test_route_uses_transformers_backend(monkeypatch):
    client = _make_client(monkeypatch)
    pipe = _fake_pipe("Hello from embedded model!")
    with patch("claude_local.backend._pipes", {"test-model": pipe}):
        resp = client.post(
            "/v1/messages",
            data=json.dumps(
                {
                    "model": "claude-haiku-4-5",
                    "max_tokens": 64,
                    "messages": [{"role": "user", "content": "Hello"}],
                }
            ),
            headers={"x-api-key": "test", "Content-Type": "application/json"},
        )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["content"][0]["text"] == "Hello from embedded model!"
    assert data["stop_reason"] == "end_turn"


def test_route_transformers_streaming(monkeypatch):
    client = _make_client(monkeypatch)
    pipe = _fake_pipe("Streaming reply here!")
    with patch("claude_local.backend._pipes", {"test-model": pipe}):
        resp = client.post(
            "/v1/messages",
            data=json.dumps(
                {
                    "model": "claude-haiku-4-5",
                    "max_tokens": 64,
                    "stream": True,
                    "messages": [{"role": "user", "content": "Hello"}],
                }
            ),
            headers={"x-api-key": "test", "Content-Type": "application/json"},
        )
        raw = resp.data.decode()

    assert resp.status_code == 200
    assert "text/event-stream" in resp.content_type

    events = [json.loads(line[6:]) for line in raw.split("\n") if line.strip().startswith("data: ")]
    types = [e["type"] for e in events]
    assert types[0] == "message_start"
    assert types[-1] == "message_stop"
    full_text = "".join(e["delta"]["text"] for e in events if e["type"] == "content_block_delta")
    assert full_text == "Streaming reply here!"


def test_route_transformers_unavailable_returns_503(monkeypatch):
    client = _make_client(monkeypatch)
    with patch("claude_local.backend._pipes", {}):
        with patch(
            "claude_local.backend.TransformersBackend._get_pipe",
            side_effect=OllamaUnavailableError("transformers not installed"),
        ):
            resp = client.post(
                "/v1/messages",
                data=json.dumps(
                    {
                        "model": "claude-haiku-4-5",
                        "max_tokens": 64,
                        "messages": [{"role": "user", "content": "Hello"}],
                    }
                ),
                headers={"x-api-key": "test", "Content-Type": "application/json"},
            )
    assert resp.status_code == 503
    data = resp.get_json()
    assert data["type"] == "error"
    assert data["error"]["type"] == "api_error"


def test_route_transformers_system_as_list(monkeypatch):
    """System prompt as list of content blocks must not crash the transformers backend."""
    client = _make_client(monkeypatch)
    pipe = _fake_pipe("Sure!")
    with patch("claude_local.backend._pipes", {"test-model": pipe}):
        resp = client.post(
            "/v1/messages",
            data=json.dumps(
                {
                    "model": "claude-haiku-4-5",
                    "max_tokens": 64,
                    "system": [
                        {"type": "text", "text": "Be helpful."},
                        {"type": "text", "text": "Be concise."},
                    ],
                    "messages": [{"role": "user", "content": "Hello"}],
                }
            ),
            headers={"x-api-key": "test", "Content-Type": "application/json"},
        )
    assert resp.status_code == 200
    call_args = pipe.call_args[0][0]
    assert call_args[0]["role"] == "system"
    assert isinstance(call_args[0]["content"], str)
    assert "Be helpful." in call_args[0]["content"]


def test_route_transformers_tool_result_nested_content(monkeypatch):
    """Multi-turn with tool_result.content as a list of blocks must not crash."""
    client = _make_client(monkeypatch)
    pipe = _fake_pipe("Done.")
    with patch("claude_local.backend._pipes", {"test-model": pipe}):
        resp = client.post(
            "/v1/messages",
            data=json.dumps(
                {
                    "model": "claude-haiku-4-5",
                    "max_tokens": 64,
                    "messages": [
                        {"role": "user", "content": "Read the file."},
                        {
                            "role": "assistant",
                            "content": [
                                {
                                    "type": "tool_use",
                                    "id": "toolu_01",
                                    "name": "read_file",
                                    "input": {"path": "README.md"},
                                }
                            ],
                        },
                        {
                            "role": "user",
                            "content": [
                                {
                                    "type": "tool_result",
                                    "tool_use_id": "toolu_01",
                                    "content": [
                                        {"type": "text", "text": "# Project\nThis is the README."}
                                    ],
                                }
                            ],
                        },
                    ],
                }
            ),
            headers={"x-api-key": "test", "Content-Type": "application/json"},
        )
    assert resp.status_code == 200
    assert resp.get_json()["type"] == "message"
