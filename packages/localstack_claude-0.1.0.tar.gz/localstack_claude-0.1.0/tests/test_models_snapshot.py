"""
Snapshot tests for the Models API.

Record against real Anthropic API:
    ANTHROPIC_API_KEY=sk-... pytest tests/test_models_snapshot.py --snapshot-update

Verify against emulator:
    pytest tests/test_models_snapshot.py
"""

from __future__ import annotations

import pytest
from localstack_snapshot.snapshots.transformer import KeyValueBasedTransformer, RegexTransformer


def _standard_transformers():
    return [
        RegexTransformer(r"req_[0-9A-Za-z]+", "<req-id>"),
        # Timestamps change over time
        KeyValueBasedTransformer(
            lambda k, v: v if k == "created_at" and isinstance(v, str) else None,
            "<timestamp>",
            replace_reference=False,
        ),
    ]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.snapshot
def test_list_models(claude_http, snapshot):
    """GET /v1/models returns the expected response shape."""
    snapshot.add_transformers_list(_standard_transformers())

    resp = claude_http.get("/v1/models")
    assert resp.status_code == 200
    data = resp.json()
    assert data["has_more"] is False
    assert isinstance(data["data"], list)
    assert len(data["data"]) > 0
    assert data["data"][0]["type"] == "model"
    snapshot.match("list_models", data)


@pytest.mark.snapshot
def test_get_model_haiku(claude_http, snapshot):
    """GET /v1/models/{id} returns the model record."""
    snapshot.add_transformers_list(_standard_transformers())

    resp = claude_http.get("/v1/models/claude-haiku-4-5-20251001")
    assert resp.status_code == 200
    data = resp.json()
    assert data["type"] == "model"
    assert data["id"] == "claude-haiku-4-5-20251001"
    snapshot.match("get_haiku", data)


@pytest.mark.snapshot
def test_get_model_not_found(claude_http, snapshot):
    """GET /v1/models/{unknown} returns 404."""
    snapshot.add_transformers_list(_standard_transformers())
    resp = claude_http.get("/v1/models/claude-does-not-exist")
    assert resp.status_code == 404
    data = resp.json()
    assert data["type"] == "error"
    assert data["error"]["type"] == "not_found_error"
    snapshot.match("not_found", data)


@pytest.mark.snapshot
def test_list_models_no_auth(claude_http, snapshot):
    """GET /v1/models without x-api-key returns 401."""
    snapshot.add_transformers_list(_standard_transformers())
    import requests

    if claude_http.real_api:
        raw_resp = requests.get(
            "https://api.anthropic.com/v1/models",
            headers={"anthropic-version": "2023-06-01"},
            timeout=30,
        )
    else:
        raw_resp = requests.get(
            claude_http.base_url + "/v1/models",
            timeout=30,
        )

    assert raw_resp.status_code == 401
    data = raw_resp.json()
    assert data["type"] == "error"
    assert data["error"]["type"] == "authentication_error"
    snapshot.match("no_auth", data)
