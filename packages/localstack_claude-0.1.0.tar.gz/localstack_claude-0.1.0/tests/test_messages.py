"""Unit tests for the Messages API (POST /v1/messages)."""

from __future__ import annotations

import json


def _auth(extra: dict | None = None) -> dict:
    h = {"x-api-key": "test-key", "Content-Type": "application/json"}
    if extra:
        h.update(extra)
    return h


def _msg(client, body: dict, headers: dict | None = None) -> tuple[int, dict]:
    resp = client.post(
        "/v1/messages",
        data=json.dumps(body),
        headers=headers or _auth(),
    )
    return resp.status_code, resp.get_json()


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------


def test_missing_api_key(client):
    # Pass only Content-Type so auth check fires (empty dict is falsy, so can't use _msg shorthand)
    resp = client.post(
        "/v1/messages",
        data=json.dumps(
            {
                "model": "claude-haiku-4-5",
                "max_tokens": 10,
                "messages": [{"role": "user", "content": "Hi"}],
            }
        ),
        headers={"Content-Type": "application/json"},
    )
    assert resp.status_code == 401
    data = resp.get_json()
    assert data["type"] == "error"
    assert data["error"]["type"] == "authentication_error"


def test_bearer_token_accepted(client):
    body = {
        "model": "claude-haiku-4-5",
        "max_tokens": 10,
        "messages": [{"role": "user", "content": "Hi"}],
    }
    status, _ = _msg(
        client, body, {"Authorization": "Bearer test-key", "Content-Type": "application/json"}
    )
    assert status == 200


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def test_missing_model_returns_400(client):
    status, data = _msg(client, {"max_tokens": 10, "messages": [{"role": "user", "content": "Hi"}]})
    assert status == 400
    assert data["error"]["type"] == "invalid_request_error"


def test_missing_messages_returns_400(client):
    status, data = _msg(client, {"model": "claude-haiku-4-5", "max_tokens": 10})
    assert status == 400
    assert data["error"]["type"] == "invalid_request_error"


def test_missing_max_tokens_returns_400(client):
    status, data = _msg(
        client, {"model": "claude-haiku-4-5", "messages": [{"role": "user", "content": "Hi"}]}
    )
    assert status == 400
    assert data["error"]["type"] == "invalid_request_error"


def test_unknown_model_returns_400(client):
    status, data = _msg(
        client,
        {
            "model": "claude-does-not-exist",
            "max_tokens": 10,
            "messages": [{"role": "user", "content": "Hi"}],
        },
    )
    assert status == 400
    assert data["error"]["type"] == "invalid_request_error"


def test_max_tokens_exceeded_returns_400(client):
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 99999999,
            "messages": [{"role": "user", "content": "Hi"}],
        },
    )
    assert status == 400
    assert data["error"]["type"] == "invalid_request_error"


# ---------------------------------------------------------------------------
# Successful message creation
# ---------------------------------------------------------------------------


def test_create_simple_message(client):
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "messages": [{"role": "user", "content": "Hello"}],
        },
    )
    assert status == 200
    assert data["type"] == "message"
    assert data["role"] == "assistant"
    assert data["stop_reason"] == "end_turn"
    assert data["stop_sequence"] is None
    assert isinstance(data["content"], list)
    assert len(data["content"]) >= 1
    assert data["content"][0]["type"] == "text"
    assert isinstance(data["content"][0]["text"], str)


def test_response_model_is_versioned(client):
    """The response model id must be the full versioned id, not the alias."""
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "messages": [{"role": "user", "content": "Hello"}],
        },
    )
    assert status == 200
    assert data["model"] == "claude-haiku-4-5-20251001"


def test_response_has_usage(client):
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "messages": [{"role": "user", "content": "Hello"}],
        },
    )
    assert status == 200
    usage = data["usage"]
    assert isinstance(usage["input_tokens"], int)
    assert isinstance(usage["output_tokens"], int)
    assert usage["input_tokens"] >= 1
    assert usage["output_tokens"] >= 1


def test_response_id_prefix(client):
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "messages": [{"role": "user", "content": "Hello"}],
        },
    )
    assert status == 200
    assert data["id"].startswith("msg_")


def test_create_message_with_system(client):
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "system": "You are a helpful assistant.",
            "messages": [{"role": "user", "content": "Hello"}],
        },
    )
    assert status == 200
    assert data["type"] == "message"


def test_create_message_system_as_list(client):
    """Claude Code sends its system prompt as a list of content blocks, not a string."""
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "system": [
                {"type": "text", "text": "You are a helpful assistant."},
                {"type": "text", "text": "Be concise."},
            ],
            "messages": [{"role": "user", "content": "Hello"}],
        },
    )
    assert status == 200
    assert data["type"] == "message"


def test_create_message_multi_turn(client):
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "messages": [
                {"role": "user", "content": "My name is Alice."},
                {"role": "assistant", "content": "Nice to meet you, Alice!"},
                {"role": "user", "content": "What is my name?"},
            ],
        },
    )
    assert status == 200
    assert data["type"] == "message"


def test_multi_turn_with_tool_use_and_tool_result(client):
    """Full Claude Code pattern: assistant returns tool_use, user sends tool_result."""
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "messages": [
                {"role": "user", "content": "What files are here?"},
                {
                    "role": "assistant",
                    "content": [
                        {"type": "text", "text": "Let me check."},
                        {
                            "type": "tool_use",
                            "id": "toolu_01",
                            "name": "bash",
                            "input": {"command": "ls"},
                        },
                    ],
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": "toolu_01",
                            "content": "README.md\npyproject.toml",
                        }
                    ],
                },
            ],
        },
    )
    assert status == 200
    assert data["type"] == "message"


def test_multi_turn_tool_result_nested_content(client):
    """tool_result.content can be a list of content blocks (not just a string)."""
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "messages": [
                {"role": "user", "content": "Read the file."},
                {
                    "role": "assistant",
                    "content": [
                        {
                            "type": "tool_use",
                            "id": "toolu_02",
                            "name": "read_file",
                            "input": {"path": "README.md"},
                        }
                    ],
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": "toolu_02",
                            "content": [{"type": "text", "text": "# Project\nThis is the README."}],
                        }
                    ],
                },
            ],
        },
    )
    assert status == 200
    assert data["type"] == "message"


def test_versioned_model_id_accepted(client):
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5-20251001",
            "max_tokens": 64,
            "messages": [{"role": "user", "content": "Hello"}],
        },
    )
    assert status == 200
    assert data["model"] == "claude-haiku-4-5-20251001"


def test_stop_sequence_returns_stop_sequence_reason(client):
    from claude_local.store import store

    store.set_response_override("hello STOP world")
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "stop_sequences": ["STOP"],
            "messages": [{"role": "user", "content": "Go"}],
        },
    )
    assert status == 200
    assert data["stop_reason"] == "stop_sequence"
    assert "STOP" not in data["content"][0]["text"]


# ---------------------------------------------------------------------------
# Response override (for predictable testing)
# ---------------------------------------------------------------------------


def test_response_override(client):
    resp = client.post(
        "/_claude/config",
        data=json.dumps({"response": "custom response text"}),
        headers={"Content-Type": "application/json"},
    )
    assert resp.status_code == 200

    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "messages": [{"role": "user", "content": "Hello"}],
        },
    )
    assert status == 200
    assert data["content"][0]["text"] == "custom response text"


# ---------------------------------------------------------------------------
# Tool use
# ---------------------------------------------------------------------------


_TOOLS = [
    {
        "name": "get_weather",
        "description": "Get the weather for a location.",
        "input_schema": {
            "type": "object",
            "properties": {"location": {"type": "string"}},
            "required": ["location"],
        },
    }
]


def test_tool_use_via_header(client):
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "tools": _TOOLS,
            "messages": [{"role": "user", "content": "What's the weather in Boston?"}],
        },
        _auth({"X-Claude-Local-Tool": "get_weather"}),
    )
    assert status == 200
    assert data["stop_reason"] == "tool_use"
    assert data["content"][0]["type"] == "tool_use"
    assert data["content"][0]["name"] == "get_weather"
    assert "location" in data["content"][0]["input"]


def test_tool_use_via_tool_choice_any(client):
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "tools": _TOOLS,
            "tool_choice": {"type": "any"},
            "messages": [{"role": "user", "content": "What's the weather in Boston?"}],
        },
    )
    assert status == 200
    assert data["stop_reason"] == "tool_use"
    assert data["content"][0]["type"] == "tool_use"


def test_tool_use_tool_id_prefix(client):
    status, data = _msg(
        client,
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 64,
            "tools": _TOOLS,
            "tool_choice": {"type": "any"},
            "messages": [{"role": "user", "content": "Weather in Boston?"}],
        },
    )
    assert status == 200
    assert data["content"][0]["id"].startswith("toolu_")


# ---------------------------------------------------------------------------
# Streaming (SSE)
# ---------------------------------------------------------------------------


def test_streaming_returns_event_stream(client):
    resp = client.post(
        "/v1/messages",
        data=json.dumps(
            {
                "model": "claude-haiku-4-5",
                "max_tokens": 64,
                "stream": True,
                "messages": [{"role": "user", "content": "Hello"}],
            }
        ),
        headers=_auth(),
    )
    assert resp.status_code == 200
    assert "text/event-stream" in resp.content_type


def test_streaming_event_sequence(client):
    resp = client.post(
        "/v1/messages",
        data=json.dumps(
            {
                "model": "claude-haiku-4-5",
                "max_tokens": 64,
                "stream": True,
                "messages": [{"role": "user", "content": "Hello"}],
            }
        ),
        headers=_auth(),
    )
    assert resp.status_code == 200

    events = []
    for line in resp.data.decode().split("\n"):
        line = line.strip()
        if line.startswith("data: "):
            events.append(json.loads(line[6:]))

    event_types = [e["type"] for e in events]
    assert event_types[0] == "message_start"
    assert event_types[-1] == "message_stop"
    assert "content_block_start" in event_types
    assert "content_block_delta" in event_types
    assert "content_block_stop" in event_types
    assert "message_delta" in event_types


def test_streaming_message_start_shape(client):
    resp = client.post(
        "/v1/messages",
        data=json.dumps(
            {
                "model": "claude-haiku-4-5",
                "max_tokens": 64,
                "stream": True,
                "messages": [{"role": "user", "content": "Hello"}],
            }
        ),
        headers=_auth(),
    )
    events = [
        json.loads(line[6:])
        for line in resp.data.decode().split("\n")
        if line.strip().startswith("data: ")
    ]
    start = events[0]
    assert start["type"] == "message_start"
    msg = start["message"]
    assert msg["role"] == "assistant"
    assert msg["id"].startswith("msg_")


def test_streaming_delta_shape(client):
    resp = client.post(
        "/v1/messages",
        data=json.dumps(
            {
                "model": "claude-haiku-4-5",
                "max_tokens": 64,
                "stream": True,
                "messages": [{"role": "user", "content": "Hello"}],
            }
        ),
        headers=_auth(),
    )
    events = [
        json.loads(line[6:])
        for line in resp.data.decode().split("\n")
        if line.strip().startswith("data: ")
    ]
    deltas = [e for e in events if e["type"] == "content_block_delta"]
    assert len(deltas) >= 1
    assert deltas[0]["delta"]["type"] == "text_delta"
    assert isinstance(deltas[0]["delta"]["text"], str)


def test_streaming_message_delta_has_usage(client):
    resp = client.post(
        "/v1/messages",
        data=json.dumps(
            {
                "model": "claude-haiku-4-5",
                "max_tokens": 64,
                "stream": True,
                "messages": [{"role": "user", "content": "Hello"}],
            }
        ),
        headers=_auth(),
    )
    events = [
        json.loads(line[6:])
        for line in resp.data.decode().split("\n")
        if line.strip().startswith("data: ")
    ]
    msg_delta = next(e for e in events if e["type"] == "message_delta")
    assert msg_delta["delta"]["stop_reason"] == "end_turn"
    assert isinstance(msg_delta["usage"]["output_tokens"], int)


def test_streaming_no_auth_returns_401(client):
    resp = client.post(
        "/v1/messages",
        data=json.dumps(
            {
                "model": "claude-haiku-4-5",
                "max_tokens": 64,
                "stream": True,
                "messages": [{"role": "user", "content": "Hello"}],
            }
        ),
        headers={"Content-Type": "application/json"},
    )
    assert resp.status_code == 401
    assert resp.content_type.startswith("application/json")
