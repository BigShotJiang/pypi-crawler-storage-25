"""Unit tests for the Models API."""

from __future__ import annotations


def _auth() -> dict:
    return {"x-api-key": "test-key"}


# ---------------------------------------------------------------------------
# GET /v1/models
# ---------------------------------------------------------------------------


def test_list_models(client):
    resp = client.get("/v1/models", headers=_auth())
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["has_more"] is False
    assert isinstance(data["data"], list)
    assert len(data["data"]) > 0
    assert data["first_id"] is not None
    assert data["last_id"] is not None


def test_list_models_shape(client):
    resp = client.get("/v1/models", headers=_auth())
    data = resp.get_json()
    for model in data["data"]:
        assert model["type"] == "model"
        assert "id" in model
        assert "display_name" in model
        assert "created_at" in model


def test_list_models_contains_haiku(client):
    resp = client.get("/v1/models", headers=_auth())
    data = resp.get_json()
    ids = [m["id"] for m in data["data"]]
    assert "claude-haiku-4-5-20251001" in ids


def test_list_models_no_auth(client):
    resp = client.get("/v1/models")
    assert resp.status_code == 401
    data = resp.get_json()
    assert data["type"] == "error"
    assert data["error"]["type"] == "authentication_error"


# ---------------------------------------------------------------------------
# GET /v1/models/{id}
# ---------------------------------------------------------------------------


def test_get_model_by_versioned_id(client):
    resp = client.get("/v1/models/claude-haiku-4-5-20251001", headers=_auth())
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["type"] == "model"
    assert data["id"] == "claude-haiku-4-5-20251001"
    assert "display_name" in data
    assert "created_at" in data


def test_get_model_by_alias(client):
    # claude-haiku-4-5 is an alias for the versioned id
    resp = client.get("/v1/models/claude-haiku-4-5", headers=_auth())
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["type"] == "model"
    assert data["id"] == "claude-haiku-4-5-20251001"


def test_get_model_not_found(client):
    resp = client.get("/v1/models/claude-does-not-exist", headers=_auth())
    assert resp.status_code == 404
    data = resp.get_json()
    assert data["type"] == "error"
    assert data["error"]["type"] == "not_found_error"


def test_get_model_no_auth(client):
    resp = client.get("/v1/models/claude-haiku-4-5")
    assert resp.status_code == 401


def test_get_opus_model(client):
    # In the real API, the latest opus model has no date suffix
    resp = client.get("/v1/models/claude-opus-4-7", headers=_auth())
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["id"] == "claude-opus-4-7"


# ---------------------------------------------------------------------------
# Health / Reset / State
# ---------------------------------------------------------------------------


def test_health(client):
    resp = client.get("/_claude/health")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "ok"
    assert data["service"] == "claude-local"


def test_reset(client):
    resp = client.post("/_claude/reset")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "ok"


def test_state(client):
    resp = client.get("/_claude/state")
    assert resp.status_code == 200
    data = resp.get_json()
    assert "request_log" in data
    assert isinstance(data["request_log"], list)
