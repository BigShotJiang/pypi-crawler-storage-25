"""
Snapshot tests for the Messages API.

Record against real Anthropic API:
    ANTHROPIC_API_KEY=sk-... pytest tests/test_messages_snapshot.py --snapshot-update

Verify against emulator:
    pytest tests/test_messages_snapshot.py
"""

from __future__ import annotations

import pytest  # noqa: F401 – used for @pytest.mark.snapshot
from localstack_snapshot.snapshots.transformer import KeyValueBasedTransformer, RegexTransformer

_MSG_ID_RE = r"msg_[0-9A-Za-z]+"
_TOOL_ID_RE = r"toolu_[0-9A-Za-z]+"


def _standard_transformers():
    return [
        RegexTransformer(_MSG_ID_RE, "<msg-id>"),
        RegexTransformer(_TOOL_ID_RE, "<tool-id>"),
        RegexTransformer(r"req_[0-9A-Za-z]+", "<req-id>"),
        # Response text is non-deterministic; mask the whole content array
        KeyValueBasedTransformer(
            lambda k, v: v if k == "content" and isinstance(v, list) else None,
            "<content>",
            replace_reference=False,
        ),
        # Token counts vary
        KeyValueBasedTransformer(
            lambda k, v: (
                v if k in ("input_tokens", "output_tokens") and isinstance(v, int) else None
            ),
            "<n>",
            replace_reference=False,
        ),
        # Model may change between recording and playback
        KeyValueBasedTransformer(
            lambda k, v: v if k == "model" and isinstance(v, str) else None,
            "<model>",
            replace_reference=False,
        ),
    ]


def _error_transformers():
    return [RegexTransformer(r"req_[0-9A-Za-z]+", "<req-id>")]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.snapshot
def test_create_simple_message(claude_http, snapshot):
    """POST /v1/messages with a single user turn returns a well-formed response."""
    snapshot.add_transformers_list(_standard_transformers())

    resp = claude_http.post(
        "/v1/messages",
        json={
            "model": "claude-haiku-4-5-20251001",
            "max_tokens": 64,
            "messages": [{"role": "user", "content": "Say exactly: hello"}],
        },
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["type"] == "message"
    assert data["role"] == "assistant"
    assert data["stop_reason"] == "end_turn"
    snapshot.match("create_simple", data)


@pytest.mark.snapshot
def test_create_message_with_system(claude_http, snapshot):
    """POST /v1/messages with a system prompt returns a well-formed response."""
    snapshot.add_transformers_list(_standard_transformers())

    resp = claude_http.post(
        "/v1/messages",
        json={
            "model": "claude-haiku-4-5-20251001",
            "max_tokens": 64,
            "system": "You are a helpful assistant. Be brief.",
            "messages": [{"role": "user", "content": "Say hi"}],
        },
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["type"] == "message"
    snapshot.match("with_system", data)


@pytest.mark.snapshot
def test_create_message_multi_turn(claude_http, snapshot):
    """POST /v1/messages with a multi-turn conversation."""
    snapshot.add_transformers_list(_standard_transformers())

    resp = claude_http.post(
        "/v1/messages",
        json={
            "model": "claude-haiku-4-5-20251001",
            "max_tokens": 64,
            "messages": [
                {"role": "user", "content": "My name is Alice."},
                {"role": "assistant", "content": "Nice to meet you, Alice!"},
                {"role": "user", "content": "What is my name?"},
            ],
        },
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["type"] == "message"
    snapshot.match("multi_turn", data)


@pytest.mark.snapshot
def test_missing_api_key(claude_http, snapshot):
    """Requests without x-api-key return 401."""
    snapshot.add_transformers_list(_error_transformers())
    if claude_http.real_api:
        import requests

        real_resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={"Content-Type": "application/json", "anthropic-version": "2023-06-01"},
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 64,
                "messages": [{"role": "user", "content": "Hello"}],
            },
            timeout=30,
        )
        data = real_resp.json()
    else:
        import requests

        emulator_resp = requests.post(
            claude_http.base_url + "/v1/messages",
            headers={"Content-Type": "application/json"},
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 64,
                "messages": [{"role": "user", "content": "Hello"}],
            },
            timeout=30,
        )
        data = emulator_resp.json()

    assert data["type"] == "error"
    assert data["error"]["type"] == "authentication_error"
    snapshot.match("missing_api_key", data)


@pytest.mark.snapshot
def test_missing_model_returns_400(claude_http, snapshot):
    """Requests without model return 400."""
    snapshot.add_transformers_list(_error_transformers())
    resp = claude_http.post(
        "/v1/messages",
        json={
            "max_tokens": 64,
            "messages": [{"role": "user", "content": "Hello"}],
        },
    )
    assert resp.status_code == 400
    data = resp.json()
    assert data["type"] == "error"
    snapshot.match("missing_model", data)


@pytest.mark.snapshot
def test_max_tokens_exceeded(claude_http, snapshot):
    """Requests with max_tokens exceeding the model limit return 400."""
    snapshot.add_transformers_list(_error_transformers())
    resp = claude_http.post(
        "/v1/messages",
        json={
            "model": "claude-haiku-4-5-20251001",
            "max_tokens": 99999999,
            "messages": [{"role": "user", "content": "Hello"}],
        },
    )
    assert resp.status_code == 400
    data = resp.json()
    assert data["type"] == "error"
    snapshot.match("max_tokens_exceeded", data)


@pytest.mark.snapshot
def test_tool_use_response_shape(claude_http, snapshot):
    """POST /v1/messages with tool_choice=any returns a tool_use content block."""
    snapshot.add_transformers_list(_standard_transformers())

    tools = [
        {
            "name": "get_weather",
            "description": "Get the weather for a location.",
            "input_schema": {
                "type": "object",
                "properties": {"location": {"type": "string", "description": "City name"}},
                "required": ["location"],
            },
        }
    ]

    if claude_http.real_api:
        # Real API: use tool_choice=any to force a tool call
        extra_params: dict = {"tool_choice": {"type": "any"}}
    else:
        # Emulator: use the X-Claude-Local-Tool header to force the call
        claude_http._session.headers["X-Claude-Local-Tool"] = "get_weather"
        extra_params = {}

    resp = claude_http.post(
        "/v1/messages",
        json={
            "model": "claude-haiku-4-5-20251001",
            "max_tokens": 128,
            "tools": tools,
            "messages": [{"role": "user", "content": "What's the weather in Boston?"}],
            **extra_params,
        },
    )

    if not claude_http.real_api:
        claude_http._session.headers.pop("X-Claude-Local-Tool", None)

    assert resp.status_code == 200
    data = resp.json()
    assert data["stop_reason"] == "tool_use"
    assert data["content"][0]["type"] == "tool_use"
    snapshot.match("tool_use_response", data)
