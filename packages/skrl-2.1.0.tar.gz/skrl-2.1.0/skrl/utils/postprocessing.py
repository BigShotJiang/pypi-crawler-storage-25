from __future__ import annotations

from typing import Any

import collections
import csv
import glob
import os

import numpy as np

from skrl import logger


class MemoryFileIterator:
    def __init__(self, pathname: str) -> None:
        """Python iterator for loading data from exported memories.

        The iterator will load the next memory file in the list of path names.
        The output of the iterator is a tuple of the filename and the memory data
        where the memory data is a dictionary of ``torch.Tensor`` (PyTorch), ``numpy.ndarray`` (NumPy)
        or lists (CSV) depending on the format and the keys of the dictionary are the names of the variables.

        Supported formats:

        - PyTorch (pt)
        - NumPy (npz)
        - Comma-separated values (csv)

        Expected output shapes:

        - PyTorch: ``(memory_size, num_envs, data_size)``
        - NumPy: ``(memory_size, num_envs, data_size)``
        - Comma-separated values: ``(memory_size * num_envs, data_size)``

        :param pathname: String containing a path specification for the exported memories.
            Python ``glob`` function is used to find all files matching the path specification.
        """
        self.n = 0
        self.file_paths = sorted(glob.glob(pathname))

    def __iter__(self) -> "MemoryFileIterator":
        """Return self to make iterable."""
        return self

    def __next__(self) -> tuple[str, dict[str, Any]]:
        """Return next batch.

        :return: Tuple of file name and data.
        """
        if self.n >= len(self.file_paths):
            raise StopIteration

        if self.file_paths[self.n].endswith(".pt"):
            return self._format_torch()
        elif self.file_paths[self.n].endswith(".npz"):
            return self._format_numpy()
        elif self.file_paths[self.n].endswith(".csv"):
            return self._format_csv()
        else:
            raise ValueError(f"Unsupported format for {self.file_paths[self.n]}. Available formats: .pt, .csv, .npz")

    def _format_numpy(self) -> tuple[str, dict[str, Any]]:
        """Load NumPy array from file.

        :return: Tuple of file name and data.
        """
        filename = os.path.basename(self.file_paths[self.n])
        data = np.load(self.file_paths[self.n])

        self.n += 1
        return filename, data

    def _format_torch(self) -> tuple[str, dict[str, Any]]:
        """Load PyTorch tensor from file.

        :return: Tuple of file name and data.
        """
        import torch

        filename = os.path.basename(self.file_paths[self.n])
        data = torch.load(self.file_paths[self.n])

        self.n += 1
        return filename, data

    def _format_csv(self) -> tuple[str, dict[str, Any]]:
        """Load CSV file from file.

        :return: Tuple of file name and data.
        """
        filename = os.path.basename(self.file_paths[self.n])

        with open(self.file_paths[self.n], "r") as f:
            reader = csv.reader(f)

            # parse header
            try:
                header = next(reader, None)
                data = collections.defaultdict(int)
                for h in header:
                    h.split(".")[1]  # check header format
                    data[h.split(".")[0]] += 1
                names = sorted(list(data.keys()))
                sizes = [data[name] for name in names]
                indexes = [(low, high) for low, high in zip(np.cumsum(sizes) - np.array(sizes), np.cumsum(sizes))]
            except:
                self.n += 1
                return filename, {}

            # parse data
            data = {name: [] for name in names}
            for row in reader:
                for name, index in zip(names, indexes):
                    data[name].append(
                        [
                            float(item) if item not in ["True", "False"] else bool(item)
                            for item in row[index[0] : index[1]]
                        ]
                    )

        self.n += 1
        return filename, data


class TensorboardFileIterator:
    def __init__(self, pathname: str, tags: str | list[str]) -> None:
        """Python iterator for loading data from TensorBoard files.

        The iterator will load the next TensorBoard file in the list of path names.
        The iterator's output is a tuple of the directory name and the TensorBoard variables selected by the tags.
        The TensorBoard data is returned as a dictionary with the tag as the key and a list of steps and values as the value.

        :param pathname: String containing a path specification for the TensorBoard files.
            Python ``glob`` function is used to find all files matching the path specification.
        :param tags: String or list of strings containing the tags of the variables to load.
        """
        self.n = 0
        self.file_paths = sorted(glob.glob(pathname))
        self.tags = [tags] if isinstance(tags, str) else tags

    def __iter__(self) -> "TensorboardFileIterator":
        """Return self to make iterable."""
        return self

    def __next__(self) -> tuple[str, dict[str, Any]]:
        """Return next batch.

        :return: Tuple of directory name and data.
        """
        from tensorflow.python.summary.summary_iterator import summary_iterator

        if self.n >= len(self.file_paths):
            raise StopIteration

        file_path = self.file_paths[self.n]
        self.n += 1

        data = {}
        try:
            for event in summary_iterator(file_path):
                try:
                    # get TensorBoard data
                    step = event.step
                    tag = event.summary.value[0].tag
                    value = event.summary.value[0].simple_value
                    # record data
                    if tag in self.tags:
                        if not tag in data:
                            data[tag] = []
                        data[tag].append([step, value])
                except Exception as e:
                    pass
        except Exception as e:
            logger.warning(str(e))

        return os.path.dirname(file_path).split(os.sep)[-1], data
