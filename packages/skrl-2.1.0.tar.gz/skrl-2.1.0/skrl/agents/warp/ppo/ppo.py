from __future__ import annotations

from typing import Any

import gymnasium

import numpy as np
import warp as wp
from warp_nn.optimizers import Adam

import skrl.utils.framework.warp as warp_utils
from skrl.agents.warp import Agent
from skrl.memories.warp import Memory
from skrl.models.warp import Model
from skrl.resources.schedulers.warp import KLAdaptiveLR
from skrl.utils import ScopedTimer

from .ppo_cfg import PPO_CFG


def enable_grad(obj, *, enabled: bool):
    if obj is None:
        return
    if isinstance(obj, wp.array):
        obj.requires_grad = enabled
    elif isinstance(obj, dict):
        for item in obj.values():
            enable_grad(item, enabled=enabled)
    else:
        raise ValueError(f"Unsupported type: {type(obj)}")


@wp.kernel(enable_backward=False)
def _time_limit_bootstrap(
    rewards: wp.array2d(dtype=float),
    next_values: wp.array2d(dtype=float),
    truncated: wp.array2d(dtype=wp.int8),
    discount_factor: float,
):
    i = wp.tid()
    rewards[i, 0] = rewards[i, 0] + discount_factor * next_values[i, 0] * wp.float32(truncated[i, 0])


@wp.kernel(enable_backward=False)
def _compute_gae(
    rewards: wp.array3d(dtype=float),
    terminated: wp.array3d(dtype=wp.int8),
    truncated: wp.array3d(dtype=wp.int8),
    values: wp.array3d(dtype=float),
    returns: wp.array3d(dtype=float),
    advantages: wp.array3d(dtype=float),
    last_values: wp.array2d(dtype=float),
    discount_factor: float,
    lambda_coefficient: float,
    time_limit_bootstrap: int,
    memory_size: int,
):
    j = wp.tid()  # number of environments
    advantage = float(0.0)
    not_done = float(0.0)

    for i in reversed(range(memory_size)):
        if time_limit_bootstrap:
            not_done = wp.float(wp.unot(wp.add(terminated[i, j, 0], truncated[i, j, 0])))
        else:
            not_done = wp.float(wp.unot(terminated[i, j, 0]))
        if i < memory_size - 1:
            advantage = (
                rewards[i, j, 0]
                - values[i, j, 0]
                + discount_factor * not_done * (values[i + 1, j, 0] + lambda_coefficient * advantage)
            )
        else:
            advantage = (
                rewards[i, j, 0]
                - values[i, j, 0]
                + discount_factor * not_done * (last_values[j, 0] + lambda_coefficient * advantage)
            )
        advantages[i, j, 0] = advantage
        returns[i, j, 0] = values[i, j, 0] + advantage


@wp.kernel(enable_backward=False)
def _normalize_advantages(
    advantages: wp.array3d(dtype=float),
    advantages_mean: wp.array1d(dtype=float),
    advantages_var: wp.array1d(dtype=float),
):
    i, j = wp.tid()
    advantages[i, j, 0] = (advantages[i, j, 0] - advantages_mean[0]) / (wp.sqrt(advantages_var[0]) + 1e-8)


@wp.kernel
def _entropy_loss(
    entropy: wp.array1d(dtype=float),
    entropy_loss_scale: float,
    n: float,
    loss: wp.array(dtype=float),
):
    wp.atomic_add(loss, 0, -entropy_loss_scale * entropy[wp.tid()] / n)


@wp.kernel
def _policy_value_loss(
    sampled_log_prob: wp.array2d(dtype=float),
    sampled_values: wp.array2d(dtype=float),
    sampled_returns: wp.array2d(dtype=float),
    sampled_advantages: wp.array2d(dtype=float),
    log_prob: wp.array2d(dtype=float),
    predicted_values: wp.array2d(dtype=float),
    ratio_clip: float,
    value_clip: float,
    value_loss_scale: float,
    n: float,
    policy_loss: wp.array1d(dtype=float),
    value_loss: wp.array1d(dtype=float),
    kl_divergence: wp.array1d(dtype=float),
):
    i = wp.tid()
    # compute approximate KL divergence
    wp.atomic_add(
        kl_divergence,
        0,
        ((wp.exp(log_prob[i, 0] - sampled_log_prob[i, 0]) - 1.0) - (log_prob[i, 0] - sampled_log_prob[i, 0])) / n,
    )
    # compute policy loss
    wp.atomic_add(
        policy_loss,
        0,
        -wp.min(
            # surrogate
            sampled_advantages[i, 0] * wp.exp(log_prob[i, 0] - sampled_log_prob[i, 0]),
            # surrogate (clipped)
            sampled_advantages[i, 0]
            * wp.clamp(wp.exp(log_prob[i, 0] - sampled_log_prob[i, 0]), 1.0 - ratio_clip, 1.0 + ratio_clip),
        )
        / n,
    )
    # compute value loss
    if value_clip:
        wp.atomic_add(
            value_loss,
            0,
            value_loss_scale
            * wp.pow(
                sampled_returns[i, 0]
                - (
                    sampled_values[i, 0]
                    + wp.clamp(predicted_values[i, 0] - sampled_values[i, 0], -value_clip, value_clip)
                ),
                2.0,
            )
            / n,
        )
    else:
        wp.atomic_add(value_loss, 0, value_loss_scale * wp.pow(sampled_returns[i, 0] - predicted_values[i, 0], 2.0) / n)


@wp.kernel
def _loss(
    policy_loss: wp.array1d(dtype=float),
    value_loss: wp.array1d(dtype=float),
    entropy_loss: wp.array1d(dtype=float),
    loss: wp.array(dtype=float),
):
    if entropy_loss:
        loss[0] = policy_loss[0] + value_loss[0] + entropy_loss[0]
    else:
        loss[0] = policy_loss[0] + value_loss[0]


class PPO(Agent):
    def __init__(
        self,
        *,
        models: dict[str, Model],
        memory: Memory | None = None,
        observation_space: gymnasium.Space | None = None,
        state_space: gymnasium.Space | None = None,
        action_space: gymnasium.Space | None = None,
        device: str | wp.Device | None = None,
        cfg: PPO_CFG | dict = {},
    ) -> None:
        """Proximal Policy Optimization (PPO).

        https://arxiv.org/abs/1707.06347

        :param models: Agent's models.
        :param memory: Memory to storage agent's data and environment transitions.
        :param observation_space: Observation space.
        :param state_space: State space.
        :param action_space: Action space.
        :param device: Data allocation and computation device. If not specified, the default device will be used.
        :param cfg: Agent's configuration.

        :raises KeyError: If a configuration key is missing.
        """
        self.cfg: PPO_CFG
        super().__init__(
            models=models,
            memory=memory,
            observation_space=observation_space,
            state_space=state_space,
            action_space=action_space,
            device=device,
            cfg=PPO_CFG(**cfg) if isinstance(cfg, dict) else cfg,
        )

        # models
        self.policy = self.models.get("policy", None)
        self.value = self.models.get("value", None)

        # checkpoint models
        self.checkpoint_modules["policy"] = self.policy
        self.checkpoint_modules["value"] = self.value

        # set up optimizer and learning rate scheduler
        if self.policy is not None and self.value is not None:
            self.learning_rate = self.cfg.learning_rate[0]
            # - optimizers
            if self.policy is self.value:
                self.optimizer = Adam(
                    self.policy.parameters(),
                    lr=self.learning_rate,
                    device=self.device,
                    max_norm=self.cfg.grad_norm_clip,
                )
            else:
                self.optimizer = Adam(
                    self.policy.parameters() + self.value.parameters(),
                    lr=self.learning_rate,
                    device=self.device,
                    max_norm=self.cfg.grad_norm_clip,
                )
            # self.checkpoint_modules["optimizer"] = self.optimizer
            # - learning rate schedulers
            self.scheduler = self.cfg.learning_rate_scheduler[0]
            self.scheduler_type = None
            if self.scheduler is not None:
                if "kladaptive" in self.scheduler.__qualname__.lower().replace("_", ""):
                    self.scheduler_type = KLAdaptiveLR
                self.scheduler = self.cfg.learning_rate_scheduler[0](**self.cfg.learning_rate_scheduler_kwargs[0])

            # training variables
            self._loss = wp.zeros((1,), dtype=wp.float32, device=self.device, requires_grad=True)
            self._policy_loss = wp.zeros((1,), dtype=wp.float32, device=self.device, requires_grad=True)
            self._value_loss = wp.zeros((1,), dtype=wp.float32, device=self.device, requires_grad=True)
            self._entropy_loss = wp.zeros((1,), dtype=wp.float32, device=self.device, requires_grad=True)
            self._kl_divergence = wp.zeros((1,), dtype=wp.float32, device=self.device)

        # set up preprocessors
        # - observations
        if self.cfg.observation_preprocessor:
            self._observation_preprocessor = self.cfg.observation_preprocessor(
                **self.cfg.observation_preprocessor_kwargs
            )
            self.checkpoint_modules["observation_preprocessor"] = self._observation_preprocessor
        else:
            self._observation_preprocessor = self._empty_preprocessor
        # - states
        if self.cfg.state_preprocessor:
            self._state_preprocessor = self.cfg.state_preprocessor(**self.cfg.state_preprocessor_kwargs)
            self.checkpoint_modules["state_preprocessor"] = self._state_preprocessor
        else:
            self._state_preprocessor = self._empty_preprocessor
        # - values
        if self.cfg.value_preprocessor:
            self._value_preprocessor = self.cfg.value_preprocessor(**self.cfg.value_preprocessor_kwargs)
            self.checkpoint_modules["value_preprocessor"] = self._value_preprocessor
        else:
            self._value_preprocessor = self._empty_preprocessor

    def init(self, *, trainer_cfg: dict[str, Any] | None = None) -> None:
        """Initialize the agent.

        :param trainer_cfg: Trainer configuration.
        """
        super().init(trainer_cfg=trainer_cfg)
        self.enable_models_training_mode(False)

        # create tensors in memory
        if self.memory is not None:
            self.memory.create_tensor(name="observations", size=self.observation_space, dtype=wp.float32)
            self.memory.create_tensor(name="states", size=self.state_space, dtype=wp.float32)
            self.memory.create_tensor(name="actions", size=self.action_space, dtype=wp.float32)
            self.memory.create_tensor(name="rewards", size=1, dtype=wp.float32)
            self.memory.create_tensor(name="terminated", size=1, dtype=wp.int8)
            self.memory.create_tensor(name="truncated", size=1, dtype=wp.int8)
            self.memory.create_tensor(name="log_prob", size=1, dtype=wp.float32)
            self.memory.create_tensor(name="values", size=1, dtype=wp.float32)
            self.memory.create_tensor(name="returns", size=1, dtype=wp.float32)
            self.memory.create_tensor(name="advantages", size=1, dtype=wp.float32)

            self._tensors_names = ["observations", "states", "actions", "log_prob", "values", "returns", "advantages"]

        # create temporary variables needed for storage and computation
        self._current_next_observations = None
        self._current_next_states = None
        self._current_log_prob = None
        self._current_values = None
        self._rollout = 0

    def act(
        self, observations: wp.array, states: wp.array | None, *, timestep: int, timesteps: int
    ) -> tuple[wp.array, dict[str, Any]]:
        """Process the environment's observations/states to make a decision (actions) using the main policy.

        :param observations: Environment observations.
        :param states: Environment states.
        :param timestep: Current timestep.
        :param timesteps: Number of timesteps.

        :return: Agent output. The first component is the expected action/value returned by the agent.
            The second component is a dictionary containing extra output values according to the model.
        """
        inputs = {
            "observations": self._observation_preprocessor(observations),
            "states": self._state_preprocessor(states),
        }
        # sample random actions
        # TODO, check for stochasticity
        if timestep < self.cfg.random_timesteps:
            return self.policy.random_act(inputs, role="policy")

        # sample stochastic actions
        actions, outputs = self.policy.act(inputs, role="policy")
        self._current_log_prob = outputs["log_prob"]

        # compute values
        if self.training:
            values, _ = self.value.act(inputs, role="value")
            self._current_values = self._value_preprocessor(values, inverse=True, inplace=True)

        return actions, outputs

    def record_transition(
        self,
        *,
        observations: wp.array,
        states: wp.array,
        actions: wp.array,
        rewards: wp.array,
        next_observations: wp.array,
        next_states: wp.array,
        terminated: wp.array,
        truncated: wp.array,
        infos: Any,
        timestep: int,
        timesteps: int,
    ) -> None:
        """Record an environment transition in memory.

        :param observations: Environment observations.
        :param states: Environment states.
        :param actions: Actions taken by the agent.
        :param rewards: Instant rewards achieved by the current actions.
        :param next_observations: Next environment observations.
        :param next_states: Next environment states.
        :param terminated: Signals that indicate episodes have terminated.
        :param truncated: Signals that indicate episodes have been truncated.
        :param infos: Additional information about the environment.
        :param timestep: Current timestep.
        :param timesteps: Number of timesteps.
        """
        super().record_transition(
            observations=observations,
            states=states,
            actions=actions,
            rewards=rewards,
            next_observations=next_observations,
            next_states=next_states,
            terminated=terminated,
            truncated=truncated,
            infos=infos,
            timestep=timestep,
            timesteps=timesteps,
        )

        if self.training:
            self._current_next_observations = next_observations
            self._current_next_states = next_states

            # reward shaping
            if self.cfg.rewards_shaper is not None:
                rewards = self.cfg.rewards_shaper(rewards, timestep, timesteps)

            # time-limit (truncation) bootstrapping
            if self.cfg.time_limit_bootstrap:
                inputs = {
                    "observations": self._observation_preprocessor(next_observations),
                    "states": self._state_preprocessor(next_states),
                }
                next_values, _ = self.value.act(inputs, role="value")
                next_values = self._value_preprocessor(next_values, inverse=True, inplace=True)

                wp.launch(
                    _time_limit_bootstrap,
                    dim=rewards.shape[0],
                    inputs=[rewards, next_values, truncated, self.cfg.discount_factor],
                    device=self.device,
                )

            # storage transition in memory
            self.memory.add_samples(
                observations=observations,
                states=states,
                actions=actions,
                rewards=rewards,
                terminated=terminated,
                truncated=truncated,
                log_prob=self._current_log_prob,
                values=self._current_values,
            )

    def pre_interaction(self, *, timestep: int, timesteps: int) -> None:
        """Method called before the interaction with the environment.

        :param timestep: Current timestep.
        :param timesteps: Number of timesteps.
        """
        pass

    def post_interaction(self, *, timestep: int, timesteps: int) -> None:
        """Method called after the interaction with the environment.

        :param timestep: Current timestep.
        :param timesteps: Number of timesteps.
        """
        if self.training:
            self._rollout += 1
            if not self._rollout % self.cfg.rollouts and timestep >= self.cfg.learning_starts:
                with ScopedTimer() as timer:
                    self.enable_models_training_mode(True)
                    self.update(timestep=timestep, timesteps=timesteps)
                    self.enable_models_training_mode(False)
                    self.track_data("Stats / Algorithm update time (ms)", timer.elapsed_time_ms)

        # write tracking data and checkpoints
        super().post_interaction(timestep=timestep, timesteps=timesteps)

    def update(self, *, timestep: int, timesteps: int) -> None:
        """Algorithm's main update step.

        :param timestep: Current timestep.
        :param timesteps: Number of timesteps.
        """
        # compute returns and advantages
        inputs = {
            "observations": self._observation_preprocessor(self._current_next_observations),
            "states": self._state_preprocessor(self._current_next_states),
        }
        enable_grad(inputs, enabled=False)
        self.value.enable_training_mode(False)
        last_values, _ = self.value.act(inputs, role="value")
        self.value.enable_training_mode(True)
        last_values = self._value_preprocessor(last_values, inverse=True, inplace=True)

        values = self.memory.get_tensor_by_name("values")
        returns = self.memory.get_tensor_by_name("returns")
        advantages = self.memory.get_tensor_by_name("advantages")

        wp.launch(
            _compute_gae,
            dim=values.shape[1],
            inputs=[
                self.memory.get_tensor_by_name("rewards"),
                self.memory.get_tensor_by_name("terminated"),
                self.memory.get_tensor_by_name("truncated"),
                values,
                returns,
                advantages,
                last_values,
                self.cfg.discount_factor,
                self.cfg.gae_lambda,
                int(self.cfg.time_limit_bootstrap),
                values.shape[0],
            ],
            device=self.device,
        )
        wp.launch(
            _normalize_advantages,
            dim=advantages.shape[:2],
            inputs=[advantages, warp_utils.mean(advantages), warp_utils.var(advantages, correction=1)],
            device=self.device,
        )

        # - since update is done in-place, there is no need to set the tensors back
        # -- self.memory.set_tensor_by_name("values", self._value_preprocessor(values, train=True, inplace=True))
        # -- self.memory.set_tensor_by_name("returns", self._value_preprocessor(returns, train=True, inplace=True))
        # -- self.memory.set_tensor_by_name("advantages", advantages)
        self._value_preprocessor(values, train=True, inplace=True)
        self._value_preprocessor(returns, train=True, inplace=True)

        cumulative_policy_loss = 0
        cumulative_entropy_loss = 0
        cumulative_value_loss = 0

        # learning epochs
        for epoch in range(self.cfg.learning_epochs):
            kl_divergences = []

            # mini-batches loop
            for (
                sampled_observations,
                sampled_states,
                sampled_actions,
                sampled_log_prob,
                sampled_values,
                sampled_returns,
                sampled_advantages,
            ) in self.memory.sample(
                names=self._tensors_names, batch_size=len(self.memory), mini_batches=self.cfg.mini_batches
            ):

                inputs = {
                    "observations": (
                        sampled_observations
                        if epoch
                        else self._observation_preprocessor(sampled_observations, train=True, inplace=True)
                    ),
                    "states": (
                        sampled_states if epoch else self._state_preprocessor(sampled_states, train=True, inplace=True)
                    ),
                }

                # compute loss
                enable_grad(inputs, enabled=True)
                sampled_actions.requires_grad = True
                self._loss.zero_()
                self._policy_loss.zero_()
                self._value_loss.zero_()
                self._entropy_loss.zero_()
                self._kl_divergence.zero_()
                with wp.Tape() as tape:
                    _, outputs = self.policy.act({**inputs, "taken_actions": sampled_actions}, role="policy")
                    stddev = outputs["stddev"]
                    predicted_values, _ = self.value.act(inputs, role="value")
                    # compute entropy loss
                    if self.cfg.entropy_loss_scale:
                        entropy = self.policy.get_entropy(stddev, role="policy")
                        wp.launch(
                            _entropy_loss,
                            dim=entropy.shape[0],
                            inputs=[entropy, self.cfg.entropy_loss_scale, entropy.shape[0], self._entropy_loss],
                            device=self.device,
                        )
                    # compute policy/value loss
                    wp.launch(
                        _policy_value_loss,
                        dim=sampled_log_prob.shape[0],
                        inputs=[
                            sampled_log_prob,
                            sampled_values,
                            sampled_returns,
                            sampled_advantages,
                            outputs["log_prob"],
                            predicted_values,
                            self.cfg.ratio_clip,
                            self.cfg.value_clip,
                            self.cfg.value_loss_scale,
                            float(sampled_log_prob.shape[0]),
                            self._policy_loss,
                            self._value_loss,
                            self._kl_divergence,
                        ],
                        device=self.device,
                    )
                    # compute loss
                    wp.launch(
                        _loss,
                        dim=1,
                        inputs=[
                            self._policy_loss,
                            self._value_loss,
                            self._entropy_loss if self.cfg.entropy_loss_scale else None,
                        ],
                        outputs=[self._loss],
                        device=self.device,
                    )

                # early stopping with KL divergence
                kl_divergence = self._kl_divergence.numpy().item()
                kl_divergences.append(kl_divergence)
                if self.cfg.kl_threshold and kl_divergence > self.cfg.kl_threshold:
                    break

                # optimization step
                tape.backward(self._loss)
                self.optimizer.step(lr=self.learning_rate if self.scheduler else None)
                tape.zero()

                # update cumulative losses
                cumulative_policy_loss += self._policy_loss.numpy().item()
                cumulative_value_loss += self._value_loss.numpy().item()
                if self.cfg.entropy_loss_scale:
                    cumulative_entropy_loss += self._entropy_loss.numpy().item()

            # update learning rate
            if self.scheduler:
                if self.scheduler_type is KLAdaptiveLR:
                    kl = np.mean(kl_divergences)
                    self.learning_rate = self.scheduler(timestep, lr=self.learning_rate, kl=kl)
                else:
                    self.learning_rate *= self.scheduler(timestep)

        # record data
        self.track_data(
            "Loss / Policy loss", cumulative_policy_loss / (self.cfg.learning_epochs * self.cfg.mini_batches)
        )
        self.track_data("Loss / Value loss", cumulative_value_loss / (self.cfg.learning_epochs * self.cfg.mini_batches))
        if self.cfg.entropy_loss_scale:
            self.track_data(
                "Loss / Entropy loss", cumulative_entropy_loss / (self.cfg.learning_epochs * self.cfg.mini_batches)
            )

        self.track_data("Policy / Standard deviation", stddev.numpy().mean().item())

        if self.scheduler:
            self.track_data("Learning / Learning rate", self.learning_rate)
