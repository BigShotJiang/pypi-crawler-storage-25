from __future__ import annotations

import copy
import dataclasses
import sys
import tqdm

import torch

from skrl.agents.torch import Agent
from skrl.envs.wrappers.torch import MultiAgentEnvWrapper, Wrapper
from skrl.multi_agents.torch import MultiAgent
from skrl.trainers.torch import Trainer, TrainerCfg
from skrl.utils import ScopedTimer


@dataclasses.dataclass(kw_only=True)
class SequentialTrainerCfg(TrainerCfg):
    """Configuration for the sequential trainer."""


class SequentialTrainer(Trainer):
    def __init__(
        self,
        *,
        env: Wrapper | MultiAgentEnvWrapper,
        agents: Agent | MultiAgent | list[Agent] | list[MultiAgent],
        scopes: list[int] | None = None,
        cfg: SequentialTrainerCfg | dict = {},
    ) -> None:
        """Sequential trainer.

        Train agents sequentially, i.e., one after the other, in each interaction with the environment.

        :param env: Environment to train/evaluate on.
        :param agents: Agent(s) to train/evaluate.
        :param scopes: Number of environments for each simultaneous agent to train/evaluate on.
        :param cfg: Configuration dictionary.
        """
        self.cfg: SequentialTrainerCfg
        super().__init__(
            env=env,
            agents=agents,
            scopes=scopes if scopes is not None else [],
            cfg=SequentialTrainerCfg(**cfg) if isinstance(cfg, dict) else cfg,
        )

        # init agents
        if self.num_simultaneous_agents > 1:
            for agent in self.agents:
                agent.init(trainer_cfg=self.cfg)
        else:
            self.agents.init(trainer_cfg=self.cfg)

    def train(self) -> None:
        """Train agents sequentially.

        This method executes the following steps in loop:

        - Pre-interaction (sequentially)
        - Compute actions (sequentially)
        - Interact with the environments
        - Render environments
        - Record transitions (sequentially)
        - Post-interaction (sequentially)
        - Reset environments
        """
        # set mode
        if self.num_simultaneous_agents > 1:
            for agent in self.agents:
                agent.enable_training_mode(True)
        else:
            self.agents.enable_training_mode(True)

        # non-simultaneous agents
        if self.num_simultaneous_agents == 1:
            super().train()
            return

        # reset the environments
        observations, infos = self.env.reset()
        states = self.env.state()

        for timestep in tqdm.tqdm(range(self.cfg.timesteps), disable=self.cfg.disable_progressbar, file=sys.stdout):

            # pre-interaction
            for agent in self.agents:
                agent.pre_interaction(timestep=timestep, timesteps=self.cfg.timesteps)

            with torch.no_grad():
                # compute actions
                _actions, _outputs = [], []
                for agent, scope in zip(self.agents, self.scopes):
                    with ScopedTimer() as timer:
                        actions, outputs = agent.act(
                            observations[scope[0] : scope[1]],
                            states[scope[0] : scope[1]] if states is not None else None,
                            timestep=timestep,
                            timesteps=self.cfg.timesteps,
                        )
                        agent.track_data("Stats / Inference time (ms)", timer.elapsed_time_ms)
                    _actions.append(actions)
                    _outputs.append(outputs)
                actions = torch.vstack(_actions)

                # step the environments
                with ScopedTimer() as timer:
                    next_observations, rewards, terminated, truncated, infos = self.env.step(actions)
                    next_states = self.env.state()
                    elapsed_time_ms = timer.elapsed_time_ms
                    for agent in self.agents:
                        agent.track_data("Stats / Env stepping time (ms)", elapsed_time_ms)

                # render the environments
                if not self.cfg.headless and not timestep % self.cfg.render_interval:
                    self.env.render()

                # record the environments' transitions
                for agent, scope in zip(self.agents, self.scopes):
                    agent.record_transition(
                        observations=observations[scope[0] : scope[1]],
                        states=states[scope[0] : scope[1]] if states is not None else None,
                        actions=actions[scope[0] : scope[1]],
                        rewards=rewards[scope[0] : scope[1]],
                        next_observations=next_observations[scope[0] : scope[1]],
                        next_states=next_states[scope[0] : scope[1]] if next_states is not None else None,
                        terminated=terminated[scope[0] : scope[1]],
                        truncated=truncated[scope[0] : scope[1]],
                        infos=infos,
                        timestep=timestep,
                        timesteps=self.cfg.timesteps,
                    )

                # log environment info
                if self.cfg.environment_info in infos:
                    for k, v in infos[self.cfg.environment_info].items():
                        if isinstance(v, torch.Tensor) and v.numel() == 1:
                            for agent in self.agents:
                                agent.track_data(k if "/" in k else f"Info / {k}", v.item())

            # post-interaction
            for agent in self.agents:
                agent.post_interaction(timestep=timestep, timesteps=self.cfg.timesteps)

            # reset environments
            # - parallel/vectorized environments (single or multi-agent)
            if self.env.num_envs > 1:
                observations = next_observations
                states = next_states
            # - single environment
            else:
                raise RuntimeError("Sequential trainer is not supported for single environment")

    def eval(self) -> None:
        """Evaluate agents sequentially.

        This method executes the following steps in loop:

        - Pre-interaction
        - Compute actions (sequentially)
        - Interact with the environments
        - Render environments
        - Record transitions
        - Reset environments
        """
        # set running mode
        if self.num_simultaneous_agents > 1:
            for agent in self.agents:
                agent.enable_training_mode(False)
        else:
            self.agents.enable_training_mode(False)

        # non-simultaneous agents
        if self.num_simultaneous_agents == 1:
            super().eval()
            return

        # reset the environments
        observations, infos = self.env.reset()
        states = self.env.state()

        for timestep in tqdm.tqdm(range(self.cfg.timesteps), disable=self.cfg.disable_progressbar, file=sys.stdout):

            # pre-interaction
            for agent in self.agents:
                agent.pre_interaction(timestep=timestep, timesteps=self.cfg.timesteps)

            with torch.no_grad():
                # compute actions
                _actions, _outputs = [], []
                for agent, scope in zip(self.agents, self.scopes):
                    with ScopedTimer() as timer:
                        actions, outputs = agent.act(
                            observations[scope[0] : scope[1]],
                            states[scope[0] : scope[1]] if states is not None else None,
                            timestep=timestep,
                            timesteps=self.cfg.timesteps,
                        )
                        agent.track_data("Stats / Inference time (ms)", timer.elapsed_time_ms)
                    _actions.append(actions if self.cfg.stochastic_evaluation else outputs.get("mean_actions", actions))
                    _outputs.append(outputs)
                actions = torch.vstack(_actions)

                # step the environments
                with ScopedTimer() as timer:
                    next_observations, rewards, terminated, truncated, infos = self.env.step(actions)
                    next_states = self.env.state()
                    elapsed_time_ms = timer.elapsed_time_ms
                    for agent in self.agents:
                        agent.track_data("Stats / Env stepping time (ms)", elapsed_time_ms)

                # render the environments
                if not self.cfg.headless and not timestep % self.cfg.render_interval:
                    self.env.render()

                # write data to TensorBoard
                for agent, scope in zip(self.agents, self.scopes):
                    agent.record_transition(
                        observations=observations[scope[0] : scope[1]],
                        states=states[scope[0] : scope[1]] if states is not None else None,
                        actions=actions[scope[0] : scope[1]],
                        rewards=rewards[scope[0] : scope[1]],
                        next_observations=next_observations[scope[0] : scope[1]],
                        next_states=next_states[scope[0] : scope[1]] if next_states is not None else None,
                        terminated=terminated[scope[0] : scope[1]],
                        truncated=truncated[scope[0] : scope[1]],
                        infos=infos,
                        timestep=timestep,
                        timesteps=self.cfg.timesteps,
                    )

                # log environment info
                if self.cfg.environment_info in infos:
                    for k, v in infos[self.cfg.environment_info].items():
                        if isinstance(v, torch.Tensor) and v.numel() == 1:
                            for agent in self.agents:
                                agent.track_data(k if "/" in k else f"Info / {k}", v.item())

            # post-interaction
            for agent in self.agents:
                super(agent.__class__, agent).post_interaction(timestep=timestep, timesteps=self.cfg.timesteps)

            # reset environments
            # - parallel/vectorized environments (single or multi-agent)
            if self.env.num_envs > 1:
                observations = next_observations
                states = next_states
            # - single environment
            else:
                raise RuntimeError("Sequential trainer is not supported for single environment")
