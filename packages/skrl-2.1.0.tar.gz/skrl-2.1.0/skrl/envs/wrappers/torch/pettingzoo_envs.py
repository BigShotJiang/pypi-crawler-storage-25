from __future__ import annotations

from typing import Any

import collections

import torch

from skrl import config
from skrl.envs.wrappers.torch.base import MultiAgentEnvWrapper
from skrl.utils.spaces.torch import (
    flatten_tensorized_space,
    tensorize_space,
    unflatten_tensorized_space,
    untensorize_space,
)


class PettingZooWrapper(MultiAgentEnvWrapper):
    def __init__(self, env: Any) -> None:
        """PettingZoo (Parallel API) environment wrapper.

        :param env: The environment instance to wrap.
        """
        super().__init__(env)

        self._seed = config.torch.key

    def step(self, actions: dict[str, torch.Tensor]) -> tuple[
        dict[str, torch.Tensor],
        dict[str, torch.Tensor],
        dict[str, torch.Tensor],
        dict[str, torch.Tensor],
        dict[str, Any],
    ]:
        """Perform a step in the environment.

        :param actions: The actions to perform.

        :return: Observation, reward, terminated, truncated, info.
        """
        actions = {
            uid: untensorize_space(self.action_spaces[uid], unflatten_tensorized_space(self.action_spaces[uid], action))
            for uid, action in actions.items()
        }
        observations, rewards, terminated, truncated, infos = self._env.step(actions)

        # convert response to torch
        observations = {
            uid: flatten_tensorized_space(tensorize_space(self.observation_spaces[uid], value, device=self.device))
            for uid, value in observations.items()
        }
        rewards = {
            uid: torch.tensor(value, device=self.device, dtype=torch.float32).view(self.num_envs, -1)
            for uid, value in rewards.items()
        }
        terminated = {
            uid: torch.tensor(value, device=self.device, dtype=torch.bool).view(self.num_envs, -1)
            for uid, value in terminated.items()
        }
        truncated = {
            uid: torch.tensor(value, device=self.device, dtype=torch.bool).view(self.num_envs, -1)
            for uid, value in truncated.items()
        }
        return observations, rewards, terminated, truncated, infos

    def state(self) -> dict[str, torch.Tensor | None]:
        """Get the environment state.

        In PettingZoo, the state is a global view of the environment, so it is the same for all agents.

        :return: State.
        """
        state = flatten_tensorized_space(
            tensorize_space(next(iter(self.state_spaces.values())), self._env.state(), device=self.device)
        )
        return {uid: state for uid in self.possible_agents}

    def reset(self) -> tuple[dict[str, torch.Tensor], dict[str, Any]]:
        """Reset the environment.

        :return: Observation, info.
        """
        outputs = self._env.reset(seed=self._seed)
        if isinstance(outputs, collections.abc.Mapping):
            observations = outputs
            infos = {uid: {} for uid in self.possible_agents}
        else:
            observations, infos = outputs
        self._seed = None

        # convert response to torch
        observations = {
            uid: flatten_tensorized_space(tensorize_space(self.observation_spaces[uid], value, device=self.device))
            for uid, value in observations.items()
        }
        return observations, infos

    def render(self, *args, **kwargs) -> Any:
        """Render the environment."""
        return self._env.render(*args, **kwargs)

    def close(self) -> None:
        """Close the environment."""
        self._env.close()
