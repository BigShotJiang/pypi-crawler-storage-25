from __future__ import annotations

from typing import Any

import collections

import jax
import numpy as np

from skrl import config
from skrl.envs.wrappers.jax.base import MultiAgentEnvWrapper
from skrl.utils.spaces.jax import (
    flatten_tensorized_space,
    tensorize_space,
    unflatten_tensorized_space,
    untensorize_space,
)


class PettingZooWrapper(MultiAgentEnvWrapper):
    def __init__(self, env: Any) -> None:
        """PettingZoo (Parallel API) environment wrapper.

        :param env: The environment instance to wrap.
        """
        super().__init__(env)

        self._seed = np.asarray(jax.device_get(config.jax.key)).sum().item()

    def step(
        self, actions: dict[str, jax.Array]
    ) -> tuple[dict[str, jax.Array], dict[str, jax.Array], dict[str, jax.Array], dict[str, jax.Array], dict[str, Any]]:
        """Perform a step in the environment.

        :param actions: The actions to perform.

        :return: Observation, reward, terminated, truncated, info.
        """
        actions = jax.device_get(actions)
        actions = {
            uid: untensorize_space(self.action_spaces[uid], unflatten_tensorized_space(self.action_spaces[uid], action))
            for uid, action in actions.items()
        }
        observations, rewards, terminated, truncated, infos = self._env.step(actions)

        # convert response to jax
        observations = {
            uid: flatten_tensorized_space(tensorize_space(self.observation_spaces[uid], value, device=self.device))
            for uid, value in observations.items()
        }
        rewards = {
            uid: jax.device_put(np.array(value, dtype=np.float32).reshape(self.num_envs, -1), device=self.device)
            for uid, value in rewards.items()
        }
        terminated = {
            uid: jax.device_put(np.array(value, dtype=np.int8).reshape(self.num_envs, -1), device=self.device)
            for uid, value in terminated.items()
        }
        truncated = {
            uid: jax.device_put(np.array(value, dtype=np.int8).reshape(self.num_envs, -1), device=self.device)
            for uid, value in truncated.items()
        }
        return observations, rewards, terminated, truncated, infos

    def state(self) -> dict[jax.Array | None]:
        """Get the environment state.

        In PettingZoo, the state is a global view of the environment, so it is the same for all agents.

        :return: State.
        """
        state = flatten_tensorized_space(
            tensorize_space(next(iter(self.state_spaces.values())), self._env.state(), device=self.device)
        )
        return {uid: state for uid in self.possible_agents}

    def reset(self) -> tuple[dict[str, jax.Array], dict[str, Any]]:
        """Reset the environment.

        :return: Observation, info.
        """
        outputs = self._env.reset(seed=self._seed)
        if isinstance(outputs, collections.abc.Mapping):
            observations = outputs
            infos = {uid: {} for uid in self.possible_agents}
        else:
            observations, infos = outputs
        self._seed = None

        # convert response to numpy or jax
        observations = {
            uid: flatten_tensorized_space(tensorize_space(self.observation_spaces[uid], value, device=self.device))
            for uid, value in observations.items()
        }
        return observations, infos

    def render(self, *args, **kwargs) -> Any:
        """Render the environment."""
        return self._env.render(*args, **kwargs)

    def close(self) -> None:
        """Close the environment."""
        self._env.close()
