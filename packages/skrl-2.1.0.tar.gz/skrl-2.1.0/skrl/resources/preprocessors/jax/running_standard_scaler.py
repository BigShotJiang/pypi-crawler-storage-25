from __future__ import annotations

import gymnasium

import jax
import jax.numpy as jnp
import numpy as np

from skrl import config
from skrl.utils.spaces.jax import compute_space_size


# https://jax.readthedocs.io/en/latest/faq.html#strategy-1-jit-compiled-helper-function
@jax.jit
def _copyto(dst, src):
    """NumPy function copyto not yet implemented."""
    return dst.at[:].set(src)


@jax.jit
def _parallel_variance(
    running_mean: jax.Array, running_variance: jax.Array, current_count: jax.Array, array: jax.Array
) -> tuple[jax.Array, jax.Array, jax.Array]:
    # ddof = 1: https://github.com/pytorch/pytorch/issues/50010
    if array.ndim == 3:
        input_mean = jnp.mean(array, axis=(0, 1))
        input_var = jnp.var(array, axis=(0, 1), ddof=1)
        input_count = array.shape[0] * array.shape[1]
    else:
        input_mean = jnp.mean(array, axis=0)
        input_var = jnp.var(array, axis=0, ddof=1)
        input_count = array.shape[0]

    delta = input_mean - running_mean
    total_count = current_count + input_count
    M2 = (
        (running_variance * current_count)
        + (input_var * input_count)
        + delta**2 * current_count * input_count / total_count
    )

    return running_mean + delta * input_count / total_count, M2 / total_count, total_count


@jax.jit
def _inverse(
    running_mean: jax.Array, running_variance: jax.Array, clip_threshold: float, array: jax.Array
) -> jax.Array:
    return jnp.sqrt(running_variance) * jnp.clip(array, -clip_threshold, clip_threshold) + running_mean


@jax.jit
def _standardization(
    running_mean: jax.Array, running_variance: jax.Array, clip_threshold: float, epsilon: float, array: jax.Array
) -> jax.Array:
    return jnp.clip((array - running_mean) / (jnp.sqrt(running_variance) + epsilon), -clip_threshold, clip_threshold)


class RunningStandardScaler:
    def __init__(
        self,
        size: int | list[int] | gymnasium.Space,
        *,
        epsilon: float = 1e-8,
        clip_threshold: float = 5.0,
        device: str | jax.Device | None = None,
    ) -> None:
        """Standardize the input data by removing the mean and scaling by the standard deviation.

        :param size: Size of the input space.
        :param epsilon: Small number to avoid division by zero.
        :param clip_threshold: Threshold to clip the data.
        :param device: Data allocation and computation device. If not specified, the default device will be used.

        Example::

            >>> running_standard_scaler = RunningStandardScaler(size=2)
            >>> data = jax.random.uniform(jax.random.PRNGKey(0), (3,2))  # tensor of shape (N, 2)
            >>> running_standard_scaler(data)
            Array([[0.57450044, 0.09968603],
                   [0.7419659 , 0.8941783 ],
                   [0.59656656, 0.45325184]], dtype=float32)
        """
        self.epsilon = epsilon
        self.clip_threshold = clip_threshold

        self.device = config.jax.parse_device(device)

        size = compute_space_size(size, occupied_size=True)
        self.running_mean = jnp.zeros(size, dtype=jnp.float32, device=self.device)
        self.running_variance = jnp.ones(size, dtype=jnp.float32, device=self.device)
        self.current_count = jnp.ones((1,), dtype=jnp.float32, device=self.device)

    @property
    def state_dict(self) -> dict[str, jax.Array]:
        """Dictionary containing references to the whole state of the module."""

        class _StateDict:
            def __init__(self, params):
                self.params = params

            def replace(self, params):
                return params

        return _StateDict(
            {
                "running_mean": self.running_mean,
                "running_variance": self.running_variance,
                "current_count": self.current_count,
            }
        )

    @state_dict.setter
    def state_dict(self, value: dict[str, jax.Array]) -> None:
        self.running_mean = _copyto(self.running_mean, value["running_mean"])
        self.running_variance = _copyto(self.running_variance, value["running_variance"])
        self.current_count = _copyto(self.current_count, value["current_count"])

    def _parallel_variance(self, input_mean: jax.Array, input_var: jax.Array, input_count: int) -> None:
        """Update internal variables using the parallel algorithm for computing variance.

        https://en.wikipedia.org/wiki/Algorithms_for_calculating_variance#Parallel_algorithm

        :param input_mean: Mean of the input data.
        :param input_var: Variance of the input data.
        :param input_count: Batch size of the input data.
        """
        delta = input_mean - self.running_mean
        total_count = self.current_count + input_count
        M2 = (
            (self.running_variance * self.current_count)
            + (input_var * input_count)
            + delta**2 * self.current_count * input_count / total_count
        )

        # update internal variables
        self.running_mean = self.running_mean + delta * input_count / total_count
        self.running_variance = M2 / total_count
        self.current_count = total_count

    def __call__(self, x: jax.Array | None, *, train: bool = False, inverse: bool = False) -> jax.Array | None:
        """Forward pass of the standardizer.

        :param x: Input tensor.
        :param train: Whether to train the standardizer.
        :param inverse: Whether to inverse the standardizer to scale back the data.

        :return: Standardized tensor.

        Example::

            >>> x = jax.random.uniform(jax.random.PRNGKey(0), (3,2))
            >>> running_standard_scaler(x)
            Array([[0.57450044, 0.09968603],
                   [0.7419659 , 0.8941783 ],
                   [0.59656656, 0.45325184]], dtype=float32)

            >>> running_standard_scaler(x, train=True)
            Array([[ 0.167439  , -0.4292293 ],
                   [ 0.45878986,  0.8719094 ],
                   [ 0.20582889,  0.14980486]], dtype=float32)

            >>> running_standard_scaler(x, inverse=True)
            Array([[0.80847514, 0.4226486 ],
                   [0.9047325 , 0.90777594],
                   [0.8211585 , 0.6385405 ]], dtype=float32)
        """
        if x is None:
            return None
        if train:
            self.running_mean, self.running_variance, self.current_count = _parallel_variance(
                self.running_mean, self.running_variance, self.current_count, x
            )

        # scale back the data to the original representation
        if inverse:
            return _inverse(self.running_mean, self.running_variance, self.clip_threshold, x)
        # standardization by centering and scaling
        return _standardization(self.running_mean, self.running_variance, self.clip_threshold, self.epsilon, x)
