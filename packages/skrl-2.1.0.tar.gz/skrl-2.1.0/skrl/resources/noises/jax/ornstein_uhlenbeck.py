from __future__ import annotations

from functools import partial

import jax
import jax.numpy as jnp
import numpy as np

from skrl import config
from skrl.resources.noises.jax import Noise


# https://jax.readthedocs.io/en/latest/faq.html#strategy-1-jit-compiled-helper-function
@partial(jax.jit, static_argnames=("shape"))
def _sample(theta, sigma, state, mean, std, key, iterator, shape):
    subkey = jax.random.fold_in(key, iterator)
    return state * theta + sigma * (2.0 * jax.random.normal(subkey, shape) * std + mean)


class OrnsteinUhlenbeckNoise(Noise):
    def __init__(
        self,
        *,
        theta: float,
        sigma: float,
        base_scale: float,
        mean: float = 0,
        std: float = 1,
        device: str | jax.Device | None = None,
    ) -> None:
        """Ornstein-Uhlenbeck noise.

        :param theta: Factor to apply to current internal state.
        :param sigma: Factor to apply to the normal distribution.
        :param base_scale: Factor to apply to returned noise.
        :param mean: Mean of the normal distribution.
        :param std: Standard deviation of the normal distribution.
        :param device: Data allocation and computation device. If not specified, the default device will be used.

        Example::

            >>> noise = OrnsteinUhlenbeckNoise(theta=0.1, sigma=0.2, base_scale=0.5)
        """
        super().__init__(device=device)

        self.state = 0
        self.theta = theta
        self.sigma = sigma
        self.base_scale = base_scale
        self.mean = mean
        self.std = std
        self._i = 0
        self._key = config.jax.key

    def sample(self, size: list[int]) -> jax.Array:
        """Sample an Ornstein-Uhlenbeck noise.

        :param size: Noise shape.

        :return: Sampled noise.

        Example::

            >>> noise.sample((3, 2))
            Array([[ 0.01878439, -0.12833427],
                   [ 0.06494182,  0.12490594],
                   [ 0.024447  , -0.01174496]], dtype=float32)

            >>> x = jax.random.uniform(jax.random.PRNGKey(0), (3, 2))
            >>> noise.sample(x.shape)
            Array([[ 0.17988093, -1.2289404 ],
                   [ 0.6218886 ,  1.1961104 ],
                   [ 0.23410667, -0.11247082]], dtype=float32)
        """
        if hasattr(self.state, "shape") and self.state.shape != size:
            self.state = 0
        self._i += 1
        self.state = _sample(self.theta, self.sigma, self.state, self.mean, self.std, self._key, self._i, size)
        return self.base_scale * self.state
