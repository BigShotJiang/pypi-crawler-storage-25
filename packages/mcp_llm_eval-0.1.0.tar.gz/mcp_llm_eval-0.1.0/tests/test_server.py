"""MCP tool integration tests: registration, routing, input validation, error handling."""

import json
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from mcp_llm_eval.server import (
    _check_thresholds,
    _get_evaluation,
    _list_evaluations,
    _run_evaluation,
    app,
    call_tool,
    list_tools,
)

FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_DATASET = FIXTURES_DIR / "sample_dataset.json"


# ---------------------------------------------------------------------------
# Tool registration
# ---------------------------------------------------------------------------


class TestToolRegistration:
    async def test_list_tools_returns_four(self):
        tools = await list_tools()
        assert len(tools) == 4

    async def test_tool_names(self):
        tools = await list_tools()
        names = {t.name for t in tools}
        assert names == {"run_evaluation", "check_thresholds", "list_evaluations", "get_evaluation"}

    async def test_run_evaluation_schema(self):
        tools = await list_tools()
        tool = next(t for t in tools if t.name == "run_evaluation")
        schema = tool.inputSchema
        assert "dataset_path" in schema["properties"]
        assert "models" in schema["properties"]
        assert "dataset_path" in schema["required"]
        assert "models" in schema["required"]

    async def test_check_thresholds_schema(self):
        tools = await list_tools()
        tool = next(t for t in tools if t.name == "check_thresholds")
        schema = tool.inputSchema
        assert "results_path" in schema["properties"]
        assert "thresholds" in schema["properties"]
        assert "results_path" in schema["required"]

    async def test_list_evaluations_schema(self):
        tools = await list_tools()
        tool = next(t for t in tools if t.name == "list_evaluations")
        schema = tool.inputSchema
        assert "results_dir" in schema["properties"]
        assert "results_dir" in schema["required"]

    async def test_get_evaluation_schema(self):
        tools = await list_tools()
        tool = next(t for t in tools if t.name == "get_evaluation")
        schema = tool.inputSchema
        assert "results_path" in schema["properties"]
        assert "results_path" in schema["required"]

    async def test_run_evaluation_models_schema(self):
        tools = await list_tools()
        tool = next(t for t in tools if t.name == "run_evaluation")
        models_schema = tool.inputSchema["properties"]["models"]
        assert models_schema["type"] == "array"
        item_props = models_schema["items"]["properties"]
        assert "provider" in item_props
        assert "model" in item_props

    async def test_run_evaluation_optional_fields(self):
        tools = await list_tools()
        tool = next(t for t in tools if t.name == "run_evaluation")
        schema = tool.inputSchema
        assert "judge" in schema["properties"]
        assert "output_dir" in schema["properties"]
        assert "tracing" in schema["properties"]

    async def test_check_thresholds_threshold_properties(self):
        tools = await list_tools()
        tool = next(t for t in tools if t.name == "check_thresholds")
        thresh_props = tool.inputSchema["properties"]["thresholds"]["properties"]
        assert "avg_faithfulness" in thresh_props
        assert "avg_relevance" in thresh_props
        assert "p95_ttft_ms" in thresh_props
        assert "max_cost_per_query" in thresh_props

    async def test_all_tools_have_descriptions(self):
        tools = await list_tools()
        for tool in tools:
            assert len(tool.description) > 10


# ---------------------------------------------------------------------------
# Tool routing
# ---------------------------------------------------------------------------


class TestToolRouting:
    async def test_unknown_tool_raises(self):
        with pytest.raises(ValueError, match="Unknown tool"):
            await call_tool("nonexistent_tool", {})

    @patch("mcp_llm_eval.server.engine")
    async def test_routes_to_run_evaluation(self, mock_engine):
        mock_engine.load_dataset.side_effect = FileNotFoundError("not found")
        result = await call_tool("run_evaluation", {
            "dataset_path": "/fake/path.json",
            "models": [{"provider": "openai", "model": "gpt-4o"}],
        })
        assert "Error" in result[0].text

    async def test_routes_to_check_thresholds(self):
        result = await call_tool("check_thresholds", {
            "results_path": "/nonexistent/results.json",
            "thresholds": {"avg_faithfulness": 0.8},
        })
        assert "not found" in result[0].text.lower() or "File not found" in result[0].text

    async def test_routes_to_list_evaluations(self):
        result = await call_tool("list_evaluations", {
            "results_dir": "/nonexistent/dir",
        })
        assert "not found" in result[0].text.lower() or "Directory not found" in result[0].text

    async def test_routes_to_get_evaluation(self):
        result = await call_tool("get_evaluation", {
            "results_path": "/nonexistent/file.json",
        })
        assert "not found" in result[0].text.lower() or "File not found" in result[0].text


# ---------------------------------------------------------------------------
# _run_evaluation
# ---------------------------------------------------------------------------


class TestRunEvaluationTool:
    async def test_dataset_not_found(self):
        result = await _run_evaluation({
            "dataset_path": "/nonexistent/dataset.json",
            "models": [{"provider": "openai", "model": "gpt-4o"}],
        })
        assert "Error loading dataset" in result[0].text

    @patch("mcp_llm_eval.server.engine")
    async def test_evaluation_error(self, mock_engine):
        mock_engine.load_dataset.return_value = [MagicMock()]
        mock_engine.run_evaluation.side_effect = RuntimeError("boom")
        result = await _run_evaluation({
            "dataset_path": str(SAMPLE_DATASET),
            "models": [{"provider": "openai", "model": "gpt-4o"}],
        })
        assert "Evaluation error" in result[0].text

    @patch("mcp_llm_eval.server.engine")
    async def test_successful_evaluation(self, mock_engine):
        mock_summary = MagicMock()
        mock_summary.to_dict.return_value = {
            "timestamp": "20250101_000000",
            "total_questions": 3,
            "total_model_runs": 3,
        }
        mock_engine.load_dataset.return_value = [MagicMock()]
        mock_engine.run_evaluation.return_value = mock_summary
        result = await _run_evaluation({
            "dataset_path": str(SAMPLE_DATASET),
            "models": [{"provider": "openai", "model": "gpt-4o"}],
        })
        data = json.loads(result[0].text)
        assert data["total_questions"] == 3

    @patch("mcp_llm_eval.server.engine")
    async def test_passes_judge_config(self, mock_engine):
        mock_summary = MagicMock()
        mock_summary.to_dict.return_value = {}
        mock_engine.load_dataset.return_value = [MagicMock()]
        mock_engine.run_evaluation.return_value = mock_summary
        await _run_evaluation({
            "dataset_path": str(SAMPLE_DATASET),
            "models": [{"provider": "openai", "model": "gpt-4o"}],
            "judge": {"model": "gpt-4o", "temperature": 0.5},
        })
        call_kwargs = mock_engine.run_evaluation.call_args[1]
        assert call_kwargs["judge_config"]["model"] == "gpt-4o"

    @patch("mcp_llm_eval.server.engine")
    async def test_passes_output_dir(self, mock_engine):
        mock_summary = MagicMock()
        mock_summary.to_dict.return_value = {}
        mock_engine.load_dataset.return_value = [MagicMock()]
        mock_engine.run_evaluation.return_value = mock_summary
        await _run_evaluation({
            "dataset_path": str(SAMPLE_DATASET),
            "models": [{"provider": "openai", "model": "gpt-4o"}],
            "output_dir": "/tmp/results",
        })
        call_kwargs = mock_engine.run_evaluation.call_args[1]
        assert call_kwargs["output_dir"] == "/tmp/results"


# ---------------------------------------------------------------------------
# _check_thresholds
# ---------------------------------------------------------------------------


class TestCheckThresholdsTool:
    async def test_file_not_found(self):
        result = await _check_thresholds({
            "results_path": "/nonexistent/results.json",
            "thresholds": {"avg_faithfulness": 0.8},
        })
        assert "not found" in result[0].text.lower() or "File not found" in result[0].text

    async def test_valid_results(self):
        summary_data = {
            "timestamp": "20250101_000000",
            "total_questions": 3,
            "total_model_runs": 3,
            "total_errors": 0,
            "total_elapsed_sec": 10.0,
            "total_estimated_cost": 0.01,
            "judge_model": "gpt-4o-mini",
            "overall": {"model-a": {"avg_faithfulness": 0.9, "avg_relevance": 0.85}},
            "results": [],
        }
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(summary_data, f)
            f.flush()
            result = await _check_thresholds({
                "results_path": f.name,
                "thresholds": {"avg_faithfulness": 0.8},
            })
        data = json.loads(result[0].text)
        assert data["overall_pass"] is True

    async def test_invalid_json(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write("not json")
            f.flush()
            result = await _check_thresholds({
                "results_path": f.name,
                "thresholds": {},
            })
        assert "Error" in result[0].text


# ---------------------------------------------------------------------------
# _list_evaluations
# ---------------------------------------------------------------------------


class TestListEvaluationsTool:
    async def test_directory_not_found(self):
        result = await _list_evaluations({"results_dir": "/nonexistent/dir"})
        assert "not found" in result[0].text.lower() or "Directory not found" in result[0].text

    async def test_empty_directory(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            result = await _list_evaluations({"results_dir": tmpdir})
            data = json.loads(result[0].text)
            assert data == []

    async def test_lists_summary_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            summary = {
                "timestamp": "20250101_000000",
                "total_questions": 3,
                "total_model_runs": 6,
                "total_errors": 0,
                "total_estimated_cost": 0.01,
                "judge_model": "gpt-4o-mini",
                "overall": {"model-a": {}},
            }
            p = Path(tmpdir) / "20250101_000000_summary.json"
            p.write_text(json.dumps(summary))

            result = await _list_evaluations({"results_dir": tmpdir})
            data = json.loads(result[0].text)
            assert len(data) == 1
            assert data[0]["timestamp"] == "20250101_000000"
            assert data[0]["models"] == ["model-a"]

    async def test_ignores_non_summary_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / "benchmark.json").write_text("{}")
            (Path(tmpdir) / "random.txt").write_text("hello")
            result = await _list_evaluations({"results_dir": tmpdir})
            data = json.loads(result[0].text)
            assert data == []

    async def test_handles_corrupt_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / "20250101_000000_summary.json").write_text("not json")
            result = await _list_evaluations({"results_dir": tmpdir})
            data = json.loads(result[0].text)
            assert data == []  # corrupt file skipped

    async def test_multiple_runs_sorted(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            for ts in ["20250101_000000", "20250102_000000", "20250103_000000"]:
                p = Path(tmpdir) / f"{ts}_summary.json"
                p.write_text(json.dumps({
                    "timestamp": ts, "total_questions": 1,
                    "total_model_runs": 1, "overall": {},
                }))
            result = await _list_evaluations({"results_dir": tmpdir})
            data = json.loads(result[0].text)
            assert len(data) == 3
            # Should be sorted newest first (reverse)
            assert data[0]["timestamp"] == "20250103_000000"


# ---------------------------------------------------------------------------
# _get_evaluation
# ---------------------------------------------------------------------------


class TestGetEvaluationTool:
    async def test_file_not_found(self):
        result = await _get_evaluation({"results_path": "/nonexistent/file.json"})
        assert "not found" in result[0].text.lower() or "File not found" in result[0].text

    async def test_returns_full_json(self):
        data = {
            "timestamp": "20250101_000000",
            "results": [{"eval_id": "e1", "model": "gpt-4o"}],
        }
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(data, f)
            f.flush()
            result = await _get_evaluation({"results_path": f.name})
        parsed = json.loads(result[0].text)
        assert parsed["timestamp"] == "20250101_000000"
        assert len(parsed["results"]) == 1

    async def test_invalid_json(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write("broken json {")
            f.flush()
            result = await _get_evaluation({"results_path": f.name})
        assert "Error" in result[0].text

    async def test_returns_text_content(self):
        data = {"key": "value"}
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(data, f)
            f.flush()
            result = await _get_evaluation({"results_path": f.name})
        assert result[0].type == "text"


# ---------------------------------------------------------------------------
# Server app
# ---------------------------------------------------------------------------


class TestServerApp:
    def test_app_name(self):
        assert app.name == "mcp-llm-eval"
