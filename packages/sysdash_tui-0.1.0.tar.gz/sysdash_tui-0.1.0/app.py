"""SysDash — Real-time System Monitor Dashboard."""

import psutil


class SystemCollector:
    """Collects system metrics via psutil."""

    def __init__(self):
        self._prev_net = psutil.net_io_counters()
        self._prev_net_time = 0

    def get_cpu(self) -> dict:
        """Return CPU usage percentage and frequency."""
        percent = psutil.cpu_percent(interval=0.1)
        freq = psutil.cpu_freq()
        ghz = round(freq.current / 1000, 1) if freq else 0
        return {"percent": percent, "freq": f"{ghz} GHz"}

    def get_memory(self) -> dict:
        """Return memory usage."""
        mem = psutil.virtual_memory()
        return {
            "percent": mem.percent,
            "used_gb": round(mem.used / (1024**3), 1),
            "total_gb": round(mem.total / (1024**3), 1),
        }

    def get_disk(self) -> dict:
        """Return disk usage for root partition."""
        disk = psutil.disk_usage("/")
        return {
            "percent": disk.percent,
            "used_gb": round(disk.used / (1024**3), 1),
            "total_gb": round(disk.total / (1024**3), 1),
        }

    def get_network(self) -> dict:
        """Return network I/O rates (bytes/sec) since last call."""
        import time

        current = psutil.net_io_counters()
        now = time.time()
        elapsed = now - self._prev_net_time if self._prev_net_time else 1

        if self._prev_net_time == 0:
            self._prev_net = current
            self._prev_net_time = now
            return {"sent_rate": 0, "recv_rate": 0}

        sent = (current.bytes_sent - self._prev_net.bytes_sent) / elapsed
        recv = (current.bytes_recv - self._prev_net.bytes_recv) / elapsed

        self._prev_net = current
        self._prev_net_time = now

        return {"sent_rate": sent, "recv_rate": recv}

    def get_processes(self) -> list[dict]:
        """Return list of top processes sorted by CPU usage."""
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status"]):
            try:
                info = p.info
                procs.append({
                    "pid": info["pid"],
                    "name": info["name"] or "unknown",
                    "cpu": info["cpu_percent"] or 0,
                    "mem": round(info["memory_percent"] or 0, 1),
                    "status": info["status"] or "unknown",
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        procs.sort(key=lambda x: x["cpu"], reverse=True)
        return procs[:50]

    def get_system_info(self) -> dict:
        """Return static system information."""
        import platform

        boot = psutil.boot_time()
        import time
        uptime_sec = time.time() - boot
        days = int(uptime_sec // 86400)
        hours = int((uptime_sec % 86400) // 3600)
        mins = int((uptime_sec % 3600) // 60)

        return {
            "hostname": platform.node(),
            "os": f"{platform.system()} {platform.release()}",
            "uptime": f"{days}d {hours}h {mins}m",
            "cpu_count": psutil.cpu_count(),
        }


from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Header, Footer, Static, DataTable, Input, Label
from textual.reactive import reactive
from textual.widget import Widget
from textual.color import Color


def _format_bytes(b: float) -> str:
    """Format bytes to human-readable string."""
    for unit in ["B", "KB", "MB", "GB"]:
        if abs(b) < 1024:
            return f"{b:.1f} {unit}"
        b /= 1024
    return f"{b:.1f} TB"


class GaugeCard(Widget):
    """A reusable gauge card with title, value, and progress bar."""

    DEFAULT_CSS = """
    GaugeCard {
        height: 7;
        min-width: 18;
        margin: 0 1 1 0;
        padding: 1 2;
        background: #16213e;
        border: solid #2a2a4a;
        layout: vertical;
    }

    GaugeCard:hover {
        background: #1c2844;
        border: solid #3a3a6a;
    }

    GaugeCard:focus {
        border: solid #72efdd;
    }

    #title {
        height: 1;
        color: #a0a0b0;
        text-style: bold;
    }

    #value {
        height: 2;
        color: #ffffff;
        content-align: center middle;
        text-style: bold;
    }

    #bar-container {
        height: 1;
        background: #0d1117;
        margin: 0 0 0 0;
    }

    #bar {
        height: 1;
        background: $primary;
        min-width: 1;
    }

    #subtitle {
        height: 1;
        color: #808090;
        margin-top: 0;
    }
    """

    value: reactive[float] = reactive(0.0)

    def __init__(self, title: str, color: str = "#4cc9f0", **kwargs):
        super().__init__(**kwargs)
        self._title = title
        self._color = color
        self._subtitle = ""

    def compose(self) -> ComposeResult:
        yield Label(self._title, id="title")
        yield Static("0%", id="value")
        with Horizontal(id="bar-container"):
            yield Static("", id="bar")
        yield Static("", id="subtitle")

    def watch_value(self, new_val: float) -> None:
        self.query_one("#value", Static).update(f"{new_val:.1f}%")
        bar = self.query_one("#bar", Static)
        bar.styles.background = Color.parse(self._color)
        bar.styles.width = f"{max(1, int(new_val))}%"

    def set_subtitle(self, text: str) -> None:
        self._subtitle = text
        self.query_one("#subtitle", Static).update(text)


class ProcessTable(Widget):
    """Interactive process list with sort and search."""

    DEFAULT_CSS = """
    ProcessTable {
        height: 1fr;
        background: #16213e;
        border: solid #2a2a4a;
        padding: 0 1;
        layout: vertical;
    }

    #search-box {
        height: 3;
        max-height: 3;
        margin: 0 0 1 0;
    }

    #search-input {
        width: 100%;
        background: #0d1117;
        border: round #3a3a5a;
        color: #e0e0e0;
        padding: 0 1;
    }

    #search-input:focus {
        border: round #72efdd;
    }

    #process-table {
        height: 1fr;
        background: #0d1117;
        border: hidden;
    }

    DataTable > .datatable--header {
        background: #1a1a3e;
        color: #72efdd;
        text-style: bold;
    }

    DataTable > .datatable--cursor {
        background: #2a2a5e;
        color: #ffffff;
    }

    DataTable > .datatable--even-row {
        background: #0d1117;
    }

    DataTable > .datatable--odd-row {
        background: #111827;
    }

    #detail-panel {
        height: auto;
        max-height: 6;
        background: #1a1a2e;
        border-top: solid #2a2a4a;
        padding: 1 2;
        color: #c0c0d0;
    }
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._sort_col = "cpu"
        self._sort_reverse = True
        self._processes: list[dict] = []

    def compose(self) -> ComposeResult:
        with Vertical(id="search-box"):
            yield Input(placeholder="Search processes...", id="search-input")
        yield DataTable(id="process-table")
        yield Static("Select a process to view details", id="detail-panel")

    def on_mount(self) -> None:
        table = self.query_one("#process-table", DataTable)
        table.add_columns("Name", "PID", "CPU%", "MEM%", "Status")
        table.cursor_type = "row"

    def update_processes(self, processes: list[dict]) -> None:
        self._processes = processes
        self._render_table("")

    def _render_table(self, filter_text: str) -> None:
        table = self.query_one("#process-table", DataTable)
        table.clear()

        filtered = self._processes
        if filter_text:
            filter_lower = filter_text.lower()
            filtered = [p for p in filtered if filter_lower in p["name"].lower()]

        # Sort
        filtered.sort(key=lambda x: x[self._sort_col], reverse=self._sort_reverse)

        for p in filtered:
            status_icon = {"running": "●", "sleeping": "○", "zombie": "⚠"}.get(p["status"], "?")
            table.add_row(
                p["name"][:25],
                str(p["pid"]),
                f"{p['cpu']:.1f}",
                f"{p['mem']:.1f}",
                f"{status_icon} {p['status'][:8]}",
            )

    def on_input_changed(self, event: Input.Changed) -> None:
        self._render_table(event.value)

    def on_data_table_header_selected(self, event: DataTable.HeaderSelected) -> None:
        col_map = {0: "name", 1: "pid", 2: "cpu", 3: "mem", 4: "status"}
        col = col_map.get(event.column_index, "cpu")
        if self._sort_col == col:
            self._sort_reverse = not self._sort_reverse
        else:
            self._sort_col = col
            self._sort_reverse = col in ("cpu", "mem")
        self._render_table(self.query_one("#search-input", Input).value)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if event.cursor_row is None:
            return
        table = self.query_one("#process-table", DataTable)
        row_data = table.get_row_at(event.cursor_row)
        if row_data:
            name, pid = row_data[0], row_data[1]
            # Find full info
            for p in self._processes:
                if str(p["pid"]) == str(pid):
                    detail = (
                        f"  PID: {p['pid']}  |  User: {self._get_user(p['pid'])}  |  "
                        f"Status: {p['status']}  |  CPU: {p['cpu']:.1f}%  |  MEM: {p['mem']:.1f}%\n"
                        f"  CMD: {self._get_cmdline(p['pid'])}"
                    )
                    self.query_one("#detail-panel", Static).update(detail)
                    break

    def _get_user(self, pid: int) -> str:
        try:
            p = psutil.Process(pid)
            return p.username() or "N/A"
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return "N/A"

    def _get_cmdline(self, pid: int) -> str:
        try:
            p = psutil.Process(pid)
            cmdline = " ".join(p.cmdline()[:3])
            return cmdline[:60] + "..." if len(cmdline) > 60 else cmdline
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return "N/A"


class StatusBar(Widget):
    """Bottom status bar showing system info."""

    DEFAULT_CSS = """
    StatusBar {
        height: 1;
        background: #0d1117;
        color: #606070;
        padding: 0 2;
        dock: bottom;
    }
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._info: dict = {}

    def compose(self) -> ComposeResult:
        yield Static("Loading...", id="status-text")

    def update_info(self, info: dict) -> None:
        text = (
            f"  {info.get('hostname', '')}  │  "
            f"{info.get('os', '')}  │  "
            f"CPU: {info.get('cpu_count', '')} cores  │  "
            f"Uptime: {info.get('uptime', '')}"
        )
        self.query_one("#status-text", Static).update(text)


class SysDashApp(App):
    """SysDash — Real-time System Monitor Dashboard."""

    TITLE = "SysDash — System Monitor"
    CSS = """
    Screen {
        background: #1a1a2e;
    }

    #dashboard {
        layout: horizontal;
        height: 1fr;
        padding: 1 1;
    }

    #gauges {
        width: 38;
        min-width: 38;
        layout: grid;
        grid-size: 2 2;
        grid-columns: 1fr 1fr;
        grid-rows: 1fr 1fr;
        padding-right: 1;
    }

    #process-panel {
        width: 1fr;
    }

    Header {
        background: #0d1117;
        color: #72efdd;
    }

    Footer {
        background: #0d1117;
        color: #606070;
    }
    """

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("r", "refresh", "Refresh"),
    ]

    def __init__(self):
        super().__init__()
        self.collector = SystemCollector()

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="dashboard"):
            with Vertical(id="gauges"):
                yield GaugeCard("CPU", color="#4cc9f0", id="cpu-gauge")
                yield GaugeCard("MEMORY", color="#80ed99", id="mem-gauge")
                yield GaugeCard("DISK", color="#f4a261", id="disk-gauge")
                yield GaugeCard("NETWORK", color="#b5838d", id="net-gauge")
            with Vertical(id="process-panel"):
                yield ProcessTable(id="process-table")
        yield StatusBar(id="status-bar")
        yield Footer()

    def on_mount(self) -> None:
        self.set_interval(2, self.update_metrics)
        self.set_interval(3, self.update_processes)
        self.set_interval(10, self.update_disk)
        self.set_interval(5, self.update_system_info)
        # Initial load
        self.call_later(self.update_metrics)
        self.call_later(self.update_processes)
        self.call_later(self.update_system_info)

    def update_metrics(self) -> None:
        cpu = self.collector.get_cpu()
        mem = self.collector.get_memory()
        net = self.collector.get_network()

        cpu_gauge = self.query_one("#cpu-gauge", GaugeCard)
        cpu_gauge.value = cpu["percent"]
        cpu_gauge.set_subtitle(cpu["freq"])

        mem_gauge = self.query_one("#mem-gauge", GaugeCard)
        mem_gauge.value = mem["percent"]
        mem_gauge.set_subtitle(f"{mem['used_gb']} / {mem['total_gb']} GB")

        net_gauge = self.query_one("#net-gauge", GaugeCard)
        sent = _format_bytes(net["sent_rate"])
        recv = _format_bytes(net["recv_rate"])
        net_pct = min(100, (net["sent_rate"] + net["recv_rate"]) / 1024 / 1024 * 10)
        net_gauge.value = net_pct
        net_gauge.set_subtitle(f"↑{sent}  ↓{recv}")

    def update_processes(self) -> None:
        procs = self.collector.get_processes()
        self.query_one("#process-table", ProcessTable).update_processes(procs)

    def update_disk(self) -> None:
        disk = self.collector.get_disk()
        disk_gauge = self.query_one("#disk-gauge", GaugeCard)
        disk_gauge.value = disk["percent"]
        disk_gauge.set_subtitle(f"{disk['used_gb']} / {disk['total_gb']} GB")

    def update_system_info(self) -> None:
        info = self.collector.get_system_info()
        self.query_one("#status-bar", StatusBar).update_info(info)

    def action_refresh(self) -> None:
        self.update_metrics()
        self.update_processes()
        self.update_disk()
        self.update_system_info()


def main():
    app = SysDashApp()
    app.run()


if __name__ == "__main__":
    main()
