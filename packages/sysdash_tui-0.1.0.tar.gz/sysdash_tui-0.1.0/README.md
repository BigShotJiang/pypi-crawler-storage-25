# LearnTUI

为 Agent TUI 开发做的学习准备项目。基于 [Textual](https://textual.textualize.io/) 框架，实现了一个实时系统监控仪表盘。

## 安装

```bash
uv sync
```

## 运行

```bash
uv run learntui
```

## 功能

- CPU / 内存 / 磁盘 / 网络 四大指标实时监控
- 进程列表：搜索过滤、点击排序、查看详情
- 底部状态栏：主机名、系统版本、运行时间
- 深色现代主题，hover 交互效果

## 快捷键

| 按键 | 功能 |
|------|------|
| `q` | 退出 |
| `r` | 手动刷新 |
| `Tab` | 切换焦点 |
| `Ctrl+P` | 命令面板 |
