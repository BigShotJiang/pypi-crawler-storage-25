# SysDash — System Monitor Dashboard

A real-time system monitoring dashboard built with Textual, featuring a clean modern aesthetic.

## Overview

Single-file TUI application that displays live system metrics (CPU, memory, disk, network) with elegant gauge cards and an interactive process list.

## Tech Stack

- **Textual** (>=0.80.0) — TUI framework
- **psutil** (>=5.9.0) — System data collection
- Python 3.10+

## Layout

```
┌─────────────────────────────────────────────┐
│  SysDash — System Monitor                   │
├──────────────────┬──────────────────────────┤
│   CPU     RAM    │                          │
│  [═══]   [═══]  │     Process List          │
│  45%     62%    │  (sortable, searchable)   │
│                  │                          │
│  DISK    NET    │                          │
│  [═══]   [═══]  │                          │
│  78%     ↑2.1MB │                          │
│          ↓856KB │                          │
├──────────────────┴──────────────────────────┤
│  Status Bar: CPU freq | OS | Uptime         │
└─────────────────────────────────────────────┘
```

- **Left panel**: 4 gauge cards (2x2 grid) — CPU, Memory, Disk, Network
- **Right panel**: Interactive process list with search and sort
- **Bottom bar**: System info status bar

## Visual Design

### Color Palette (Dark Modern)

| Element | Color |
|---------|-------|
| Background | `#1a1a2e` |
| Card background | `#16213e` |
| CPU gauge | `#4cc9f0` (soft blue) |
| Memory gauge | `#80ed99` (soft green) |
| Disk gauge | `#f4a261` (soft orange) |
| Network gauge | `#b5838d` (soft purple) |
| Text | `#e0e0e0` |
| Accent | `#72efdd` (soft cyan) |

### Card Styling

- Rounded corners with subtle inner shadow
- Large centered value text
- Gradient progress bar fill (soft → bright)
- Gentle breathing animation (opacity pulse)

### Process Table

- Selected row highlighted, alternating row colors
- Sort arrows: `▲` / `▼` unicode characters
- Search box with rounded corners and soft border

### Animations

- Smooth value transitions on data change
- Smooth progress bar fills
- Slight scale effect on card hover

## Components

### 1. GaugeCard (Widget)

Reusable gauge component displaying:
- Title (e.g., "CPU", "RAM")
- Percentage value (large text)
- Progress bar with gradient fill
- Optional subtitle (e.g., "2.4 GHz" for CPU, "↑2.1MB ↓856KB" for network)

Constructor: `GaugeCard(title, value, color, subtitle)`

### 2. ProcessTable (extends DataTable)

- Columns: Name, PID, CPU%, MEM%, Status
- Sorting: click column header to toggle ascending/descending
- Search: text input filters rows by name in real-time (300ms debounce)
- Selection: highlighted row, shows detail panel on select

### 3. StatusBar (Widget)

Bottom bar displaying: CPU frequency, OS name, system uptime

## Data Collection

All data from `psutil`:

| Metric | Source | Refresh Rate |
|--------|--------|-------------|
| CPU usage | `psutil.cpu_percent()` | 2s |
| Memory | `psutil.virtual_memory()` | 2s |
| Disk | `psutil.disk_usage('/')` | 5s |
| Network | `psutil.net_io_counters()` | 2s (delta calculation) |
| Processes | `psutil.process_iter()` | 3s |

## Interactions

1. **Search**: Type in search box → process list filters by name (debounced 300ms)
2. **Sort**: Click column header → toggle sort (CPU↑ → CPU↓ → MEM↑ → MEM↓ → ...)
3. **Select process**: Arrow keys to navigate, Enter to view details
4. **Detail panel**: Shows PID, user, start time, command line for selected process

## Error Handling

- Graceful fallback if psutil can't access certain metrics (show "N/A")
- Network rate calculation handles counter resets
- Process list handles permission errors per-row

## File Structure

```
learnTUI/
├── app.py              # Single file, all logic
├── requirements.txt    # textual, psutil
└── docs/
    └── superpowers/
        └── specs/
            └── 2026-05-03-sysdash-design.md  # This file
```

## Running

```bash
pip install -r requirements.txt
python app.py
```
