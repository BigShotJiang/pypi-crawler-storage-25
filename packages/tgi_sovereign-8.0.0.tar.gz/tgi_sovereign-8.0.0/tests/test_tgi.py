import pytest
import os
from tgi.tgi import TGICognitiveKernel

def test_kernel_initialization():
    kernel = TGICognitiveKernel(m=3, k=3)
    assert kernel.m == 3
    assert kernel.k == 3

def test_layer_1_symbolic_parser():
    kernel = TGICognitiveKernel()
    msg = kernel.layer_1_symbolic_parser("logistics", 101, 3)
    assert kernel.m == 101
    assert kernel.k == 3
    assert "PARSED" in msg

def test_layer_2_knowledge_base():
    kernel = TGICognitiveKernel(m=3, k=3)
    nb, moduli = kernel.layer_2_knowledge_base()
    assert nb == 18 # 3^(3-1) * phi(3) = 9 * 2 = 18
    assert len(kernel.b_vectors) == 3
    for b in kernel.b_vectors:
        assert len(b) == 3

def test_layer_3_parity_verifier():
    kernel = TGICognitiveKernel(m=3, k=3)
    valid, msg, k = kernel.layer_3_parity_verifier()
    assert valid

    kernel_obs = TGICognitiveKernel(m=4, k=3)
    valid, msg, k = kernel_obs.layer_3_parity_verifier()
    assert not valid
    assert k == 4 # Suggested elevation

def test_layer_4_spike_synapse():
    kernel = TGICognitiveKernel(m=3, k=3)
    context = (1, 1, 1)
    deduction = kernel.layer_4_spike_synapse(context)
    assert len(deduction) == 3
    assert all(isinstance(x, int) for x in deduction)

def test_layer_5_silicon_compiler():
    kernel = TGICognitiveKernel(m=3, k=3)
    verilog = kernel.layer_5_silicon_compiler()
    assert "module tgi_engine_3_3" in verilog
    assert "assign raw_sum" in verilog

def test_execute_thought_loop_elevation():
    kernel = TGICognitiveKernel(m=4, k=3)
    context = (1, 1, 1)
    result = kernel.execute_thought_loop(context)
    assert result["state"] == "RESOLVED_VIA_ELEVATION"
    assert kernel.k == 4
    assert "elevation_log" in result
    assert "solution_density" in result

def test_execute_thought_loop_large_context():
    kernel = TGICognitiveKernel(m=7, k=7)
    context = tuple([i % 7 for i in range(128)])
    result = kernel.execute_thought_loop(context)
    assert result["state"] == "CLOSED"
    assert len(result["abstractions"]) > 1
