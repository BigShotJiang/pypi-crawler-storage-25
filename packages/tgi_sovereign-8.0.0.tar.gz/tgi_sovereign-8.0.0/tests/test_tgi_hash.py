import pytest
from tgi.tgi_hash import SESHash

def test_ses_hash_generation():
    # Odd k, Even m = Parity Trapdoor
    hasher = SESHash(m=128, k=3)
    data = "ALGEBRAIC_MIND"
    h1 = hasher.hash(data)
    h2 = hasher.hash(data)
    assert h1 == h2
    assert len(h1) == 64 # SHA-256 length

def test_ses_hash_one_way_property():
    hasher = SESHash(m=128, k=3)
    data = "TEST_DATA"
    h = hasher.hash(data)

    # Attempt inversion in obstructed space (k=3)
    # The kernel would not close the cycle in Z_128^3
    res = hasher.invert(h)
    assert "RECONSTRUCTED" in res
    assert "k=4" in res

def test_ses_hash_collision_resistance():
    hasher = SESHash(m=64, k=3)
    h1 = hasher.hash("Alice")
    h2 = hasher.hash("Bob")
    assert h1 != h2

def test_ses_hash_inversion_fail():
    # Odd m, Odd k = Parity Harmony (Not a trapdoor)
    hasher = SESHash(m=127, k=3)
    data = "ALGEBRAIC_MIND"
    h = hasher.hash(data)
    res = hasher.invert(h)
    assert "FAILED" in res
