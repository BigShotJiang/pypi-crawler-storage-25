import pytest
from tgi.tgi_agent_os import AgentOS
from tgi.tgi_tools import ToolRegistry
from tgi.tgi_memory import TrajectoryMemory

def test_tool_validation():
    registry = ToolRegistry()
    # Missing Body
    ok, msg, missing = registry.validate_tool_execution("send_email", {"recipient": "A", "subject": "B"})
    assert not ok
    assert "body" in missing

def test_trajectory_memory_recall():
    mem = TrajectoryMemory()
    path = [(1,1,1), (2,2,2)]
    mem.save_thought("test", path)
    recalled = mem.recall_context(None)
    assert recalled == path

def test_agent_os_tool_execution():
    os_sys = AgentOS(m=101, k=3)
    params = {"recipient": "test@fso.ai", "subject": "test", "body": "test"}
    res = os_sys.process_command("user send data", params=params)
    assert "OS_SUCCESS" in res
    assert "EMAIL_EXECUTED" in res

def test_agent_os_incomplete_command():
    os_sys = AgentOS(m=101, k=3)
    # user send -> missing data (Object) and execute (Closure)
    # The OS should detect missing params for send_email tool
    res = os_sys.process_command("user send", params={"recipient": "test"})
    assert "OS_INTERRUPT" in res
    assert "Missing fiber coordinates" in res
