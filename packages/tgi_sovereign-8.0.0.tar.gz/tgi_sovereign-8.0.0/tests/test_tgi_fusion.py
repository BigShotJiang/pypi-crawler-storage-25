import pytest
from tgi.tgi_fusion import FusionSim

def test_fusion_stability_odd_m():
    # Odd m is natively stable for k=3
    sim = FusionSim(m=7)
    trajectory, msg = sim.generate_field_line(steps=7**2) # Test a decent slice
    assert "STABLE" in msg
    assert len(trajectory) == (7**2 + 1)

def test_fusion_confinement_density():
    # Test high coverage property
    m = 5
    sim = FusionSim(m=m)
    trajectory, _ = sim.generate_field_line(steps=m**3)
    coverage = sim.calculate_confinement_density(trajectory)
    # Even if not 100%, it should be significantly higher than a random walk
    assert coverage >= 10.0

def test_fusion_unstable_even_m():
    # Even m (like m=6, k=3) is parity obstructed and unstable
    # unless we use the resolution logic.
    sim = FusionSim(m=6)
    trajectory, msg = sim.generate_field_line()
    # GCD resonance for r=(1,1,1) and m=6 is gcd(3,6)=3.
    assert "UNSTABLE" in msg
