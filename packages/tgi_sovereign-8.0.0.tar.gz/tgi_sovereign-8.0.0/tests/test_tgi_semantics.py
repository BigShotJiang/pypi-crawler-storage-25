import pytest
from tgi.tgi_dictionary import LexicalTopology
from tgi.tgi_semantic_router import SemanticRouter
from tgi.tgi_parser import TLMSemanticParser

def test_lexical_topology_mapping():
    lt = LexicalTopology(m=101, k=3)
    data = lt.get_word_data("system")
    assert data["fiber"] == 0
    assert sum(data["coord"]) % 101 == 0

def test_semantic_router_path():
    sr = SemanticRouter(m=101, k=3)
    path, msg = sr.find_semantic_path("user", "calculate")
    assert msg == "SUCCESS"
    assert len(path) > 1
    assert path[0] == sr.lt.get_word_data("user")["coord"]

def test_parser_v2_autocorrect():
    parser = TLMSemanticParser(m=101, k=3)
    res = parser.parse("system")
    assert res["status"] == "ACCEPTED"
    assert len(res["corrections"]) == 4
    assert "EXECUTE" in res["translation"] or "CLOSE" in res["translation"]

def test_parser_v2_paradox():
    parser = TLMSemanticParser(m=101, k=3)
    # data (2) -> user (0) - backwards jump
    res = parser.parse("data user")
    assert res["status"] == "REJECTED"
    assert "H^2 PARADOX" in res["reason"]
