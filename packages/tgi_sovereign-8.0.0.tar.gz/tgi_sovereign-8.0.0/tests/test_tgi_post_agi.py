import pytest
from tgi.tgi_compression import NeuralManifoldCompressor
from tgi.tgi_genomics import GenomicManifold
from tgi.tgi import TGICognitiveKernel

def test_neural_compression_ratio():
    # 1000x1000 matrix = 1,000,000 floats
    compressor = NeuralManifoldCompressor(weights_shape=(1000, 1000), m=101)
    ratio = compressor.calculate_compression_ratio()
    # original: 1M * 4 = 4MB
    # compressed: 2 * 101 * 1 = 202 bytes
    assert ratio > 1000.0

def test_genomic_pathway_stability():
    gm = GenomicManifold(m=101)
    seq = "ATGC" * 10
    path = gm.sequence_to_manifold(seq)
    assert len(path) == len(seq)
    # Theoretically non-intersecting for Hamiltonian generators
    assert not gm.detect_collision(path)

def test_multi_manifold_switching():
    kernel = TGICognitiveKernel(m=3, k=3)
    msg = kernel.switch_manifold("physics", m=101, k=3)
    assert "physics" in msg
    assert kernel.m == 101
    assert kernel.active_manifold == "physics"

    kernel.switch_manifold("base")
    assert kernel.m == 3
