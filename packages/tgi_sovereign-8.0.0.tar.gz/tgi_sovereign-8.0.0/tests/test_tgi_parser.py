import pytest
from tgi.tgi_parser import TLMSemanticParser

def test_parser_lexical_mapping():
    parser = TLMSemanticParser(m=5, k=3)
    assert "user" in parser.lexicon
    assert parser.lt.get_word_data("user")["fiber"] == 0

def test_parser_parity_harmony():
    parser = TLMSemanticParser(m=5, k=3)
    # Valid: Subject (0) -> Action (1)
    is_valid, msg, path = parser.evaluate_parity_harmony(["user", "send"])
    assert is_valid
    assert len(path) == 2

    # Invalid: Object (2) -> Subject (0)
    is_valid, msg, path = parser.evaluate_parity_harmony(["data", "user"])
    assert not is_valid
    assert "H^2 PARADOX" in msg

def test_parser_closure_lemma():
    parser = TLMSemanticParser(m=5, k=3)
    res = parser.parse("user send")
    # Lexicon may return 'route' as Object if 'data' is not first.
    # But it should complete to closure.
    assert "ROUTE" in res["translation"] or "DATA" in res["translation"]
    assert "EXECUTE" in res["translation"] or "CLOSE" in res["translation"]
    assert res["is_complete"]

def test_parser_nonsense_rejection():
    parser = TLMSemanticParser(m=5, k=3)
    res = parser.parse("data calculate system")
    assert res["status"] == "REJECTED"
    assert "H^2 PARADOX" in res["reason"]
