import pytest
from tgi.tgi_router import FSORouter
from tgi.theorems import expected_nb, verify_single_cycle_condition, moduli_space_count, thm_6_1_parity_obstruction, law_of_dimensional_parity_harmony

def is_valid_hamiltonian_cycle(m, k, route):
    """Checks if the given route is a valid Hamiltonian cycle on Z_m^k."""
    if not route: return False, "No route provided"
    expected_length = m ** k
    if len(route) != expected_length:
        return False, f"Expected length {expected_length}, got {len(route)}"

    if len(set(route)) != expected_length:
        return False, "Duplicate nodes found in route"

    for i in range(expected_length):
        curr = route[i]
        nxt = route[(i + 1) % expected_length]
        diff = [(nxt[j] - curr[j]) % m for j in range(k)]
        if sum(diff) != 1 or diff.count(1) != 1:
            return False, f"Invalid step from {curr} to {nxt}"

    return True, "Valid Hamiltonian cycle"

@pytest.mark.parametrize("m, k", [
    (3, 3), # Odd-Odd
    (5, 3), # Odd-Odd
    (6, 2), # Even-Even
    (4, 4), # Even-Even
    (2, 4), # Even-Even
])
def test_hamiltonian_generation(m, k):
    router = FSORouter(m=m, k=k)
    route = router.solve()
    # If route is nested (spike_sigma output), we don't validate as Hamiltonian cycle here
    # solve() for SA returns a flat list of coordinates.
    if isinstance(route, list) and len(route) > 0 and isinstance(route[0], tuple):
        is_valid, msg = is_valid_hamiltonian_cycle(m, k, route)
        assert is_valid, msg

def test_nb_formula():
    assert expected_nb(3) == 18
    assert expected_nb(4) == 128
    assert expected_nb(5) == 2500

def test_moduli_space_count():
    assert moduli_space_count(3, 3) == 648
    assert moduli_space_count(4, 3) == 2 * (128 ** 2)

def test_single_cycle_condition():
    router = FSORouter(m=3, k=3)
    r, b_vectors = router.construct_spike_sigma()
    # verify_single_cycle_condition now returns bool directly
    res = verify_single_cycle_condition(1, b_vectors, 3)
    assert res is False

def test_parity_obstruction_theorem():
    is_obs, msg = thm_6_1_parity_obstruction(4, 3)
    assert is_obs

def test_law_of_dimensional_parity_harmony():
    # Odd m, Odd k -> Solvable
    assert law_of_dimensional_parity_harmony(3, 3)[0] is True
    # Even m, Odd k -> Obstructed
    assert law_of_dimensional_parity_harmony(4, 3)[0] is False
    # Even m, Even k -> Solvable
    assert law_of_dimensional_parity_harmony(4, 4)[0] is True
    # k=2 -> Always Solvable
    assert law_of_dimensional_parity_harmony(3, 2)[0] is True
