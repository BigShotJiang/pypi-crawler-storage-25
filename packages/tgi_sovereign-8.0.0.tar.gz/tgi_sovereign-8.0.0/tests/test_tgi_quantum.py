import pytest
from tgi.tgi_quantum import QuantumSyndromeDecoder

def test_quantum_syndrome_decoding():
    # Odd m, Odd k = Stable Topological Protection
    decoder = QuantumSyndromeDecoder(m=17, k=3)
    loc = (2, 4, 1)
    correction, msg = decoder.decode_syndrome(loc)
    assert msg == "RECOVERY_MAPPED"
    assert len(correction) == 3
    assert all(isinstance(x, int) for x in correction)

def test_quantum_pacemaker_cycle():
    decoder = QuantumSyndromeDecoder(m=17, k=3)
    # Configure kernel with stable r-generators for the pacemaker test
    r_tuple = (1, 2, 3)
    decoder.kernel.b_vectors = []
    for c in range(3):
        b = [r_tuple[c]] * 17
        decoder.kernel.b_vectors.append(tuple(b))

    cycle = decoder.orchestrate_measurement_cycle(steps=10)
    assert len(cycle) == 11
    # Ensure non-colliding (no duplicate nodes in a short cycle)
    assert len(set(cycle)) == 11

def test_quantum_obstructed_syndrome():
    # Even m, Odd k = Obstruction
    decoder = QuantumSyndromeDecoder(m=18, k=3)
    loc = (1, 1, 1)
    correction, msg = decoder.decode_syndrome(loc)
    assert "OBSTRUCTED" in msg
