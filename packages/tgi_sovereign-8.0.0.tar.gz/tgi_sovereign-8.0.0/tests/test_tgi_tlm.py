import pytest
from tgi.tgi_tlm import TopologicalLanguageModel

def test_tlm_initialization():
    tlm = TopologicalLanguageModel(m=256, k=4)
    assert tlm.m == 256
    assert tlm.k == 4

def test_conversational_intelligence():
    tlm = TopologicalLanguageModel(m=256, k=4)
    resp, parse_res = tlm.converse("Can you explain relativity?")
    assert "relativity" in resp.lower()
    assert parse_res["action"] == "explain"
    assert parse_res["object"] == "relativity"

def test_thought_roles():
    tlm = TopologicalLanguageModel(m=256, k=4)
    _, parse_res = tlm.converse("The human architect should deploy a secure backend")
    roles = parse_res["roles"]
    assert "human" in roles["subject"]
    assert "deploy" in roles["verb"]
    assert "secure" in roles["modality"]
