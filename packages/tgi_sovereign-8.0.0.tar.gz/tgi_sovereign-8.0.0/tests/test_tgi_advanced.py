import pytest
from tgi.tgi import TGICognitiveKernel
from tgi.tgi_logic_mapper import TGILogicMapper

def test_knowledge_graph_parsing():
    kernel = TGICognitiveKernel()
    entities = ["NodeA", "NodeB", "NodeC"]
    relations = ["is_related_to", "is_different_from"]
    msg = kernel.layer_1_symbolic_parser("knowledge_graph", entities, relations)
    assert kernel.m == 3
    assert kernel.k == 2
    assert "PARSED GRAPH" in msg

def test_knowledge_manifold_ingestion():
    kernel = TGICognitiveKernel(m=5, k=3)
    semantic_data = {"subject": "AI", "object": "Logic", "predicate": "is"}
    context_vec = kernel.knowledge_manifold_ingestion(semantic_data)
    assert len(context_vec) == 3
    assert all(0 <= x < 5 for x in context_vec)

def test_logic_mapper_utility():
    mapper = TGILogicMapper()
    m, k = mapper.map_knowledge_graph(["A", "B"], ["rel1"])
    # m=2, k=1 -> Odd/Even mismatch -> k elevated to 2
    assert m == 2
    assert k == 2

    vec = mapper.semantic_to_vector({"key": "val"}, 5, 2)
    assert len(vec) == 2
    assert isinstance(vec, tuple)

def test_advanced_execute_thought_loop():
    kernel = TGICognitiveKernel(m=5, k=3)
    semantic_data = {"A": 1, "B": 2, "C": 3}
    # Direct ingestion in thought loop
    result = kernel.execute_thought_loop(semantic_data)
    assert result["state"] == "CLOSED"
    assert "abstractions" in result
