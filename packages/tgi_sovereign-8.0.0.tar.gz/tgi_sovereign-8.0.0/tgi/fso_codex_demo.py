import time
from tgi.tgi_sovereign import SovereignKernel

def run_fso_demo():
    print("=========================================================")
    print(" PROJECT ELECTRICITY: THE FSO CODEX UPGRADE DEMO")
    print("=========================================================")

    # Initialize Kernel (default m=256, k=4)
    kernel = SovereignKernel(m=256, k=4)
    kernel.sovereign_boot()

    print("\n--- VALIDATING OPERATIONS AGAINST THE CODEX ---")

    # 1. Test Law I (Dimensional Parity Harmony)
    # Scenario: Routing a packet on an Even grid (m=4) with Odd dimensionality (k=3)
    print("\n[SCENARIO 1] Routing on m=4, k=3 (H2 Parity Test)")
    ok, msg = kernel.knowledge.consult_codex("LAW_I", 4, 3)
    if not ok:
        print(f"  [!] KERNEL ADVISORY: {msg}")
        print("  [!] ACTION: Operation Blocked by Topological Physics.")
    else:
        print(f"  [+] KERNEL ADVISORY: {msg}")

    # 2. Test Law IV (Canonical Spike Invariant)
    # Scenario: High-speed O(1) routing for m=101
    print("\n[SCENARIO 2] O(1) Spike Generation for m=101")
    r_canonical = (1, 99, 1)
    ok, msg = kernel.knowledge.consult_codex("LAW_IV", 101, r_canonical)
    if ok:
        print(f"  [+] KERNEL ADVISORY: {msg}")
        print(f"  [+] ACTION: Executing O(1) Spike [r={r_canonical}] for Global Closure.")
    else:
        print(f"  [!] KERNEL ADVISORY: {msg}")

    # 3. Test Law VII (The Resonance Law) - New Expansion
    print("\n[SCENARIO 3] Checking Deployment Stability (Resonance Law)")
    ok, msg = kernel.knowledge.consult_codex("LAW_VII")
    print(f"  [+] KERNEL ADVISORY: {msg}")

    print("\n=========================================================")
    print(" THE FOUNDATIONAL PHYSICS OF SOVEREIGN OS ARE ACTIVE")
    print("=========================================================\n")

if __name__ == "__main__":
    run_fso_demo()
