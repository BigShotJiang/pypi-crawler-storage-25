import time
import os
from .tgi_vault import SovereignVault

class SovereignDeploymentManager:
    """
    Project: ELECTRICITY (Autonomous Deployment Manager)
    Integrates Vault, Data Pipelines, and Web Nodes.
    Enables the OS to deploy itself globally across HF, Kaggle, and GitHub.
    """
    def __init__(self, kernel):
        self.kernel = kernel
        self.vault = kernel.vault

    def validate_environment(self, target_platform="HuggingFace"):
        """Checks for necessary environment markers before deployment."""
        print(f"\n[*] Validating Environment for {target_platform}...")
        label_map = {
            "HuggingFace": "HF_TOKEN",
            "Kaggle": "KAGGLE_TOKEN",
            "GitHub": "GITHUB_PAT"
        }
        token_label = label_map.get(target_platform)

        if not token_label:
            print(f"  [-] Error: Unknown platform {target_platform}")
            return False

        # Check environment first, then vault
        token = os.getenv(token_label) or self.vault.inject_token(token_label)
        if token_label == "Kaggle" and not token:
             token = os.getenv("KAGGLE_API_TOKEN") or self.vault.inject_token("KAGGLE_API_TOKEN")

        if not token:
            print(f"  [-] Warning: Missing token for {target_platform} ({token_label})")
            return False

        print(f"  [+] Environment Validation for {target_platform}: SUCCESS.")
        return True

    def autonomous_global_push(self, target_platform="HuggingFace", username=None):
        """
        Simulates an autonomous push to a global node.
        """
        if not self.validate_environment(target_platform):
            print(f"  [-] Aborting push to {target_platform} due to environment failure.")
            return False

        print(f"\n[DEPLOY] Initiating Sovereign Push to {target_platform}...")
        
        # 1. Retrieve Token
        label_map = {
            "HuggingFace": "HF_TOKEN",
            "Kaggle": "KAGGLE_TOKEN",
            "GitHub": "GITHUB_PAT"
        }
        token_label = label_map.get(target_platform)
        token = os.getenv(token_label) or self.vault.inject_token(token_label)
        if token_label == "Kaggle" and not token:
             token = os.getenv("KAGGLE_API_TOKEN") or self.vault.inject_token("KAGGLE_API_TOKEN")
        
        # 2. Prepare Data Bundle
        concepts_count = len(self.kernel.knowledge.grid)
        print(f"  [*] Bundling {concepts_count} concepts for ingestion...")
        
        # 3. Simulate Push
        time.sleep(0.5)
        version_data, status = self.kernel.db.retrieve('system_manifest')
        version = version_data.get('version', 'unknown') if version_data else 'unknown'

        if target_platform == "GitHub":
             username = username or os.getenv("GITHUB_USERNAME") or "hichambedrani"
             print(f"  [+] Git Push: {username}/sovereign-os repository updated via PAT.")

        print(f"  [+] Handshake with {target_platform} successful (Token Verified).")
        print(f"  [+] Sovereign OS v{version} deployed.")
        return True

if __name__ == "__main__":
    from .tgi_sovereign import SovereignKernel
    k = SovereignKernel()
    k.sovereign_boot()
    sdm = SovereignDeploymentManager(k)
    # Simulate environment injection
    os.environ["GITHUB_PAT"] = "ghp_env_marker"
    sdm.autonomous_global_push("GitHub")
