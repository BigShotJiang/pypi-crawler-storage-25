import hashlib

class AlgebraicLexicon:
    """
    Project: ELECTRICITY (Algebraic Lexicon v3.0 - Deep Knowledge Edition)
    Maps words to Z_m^k coordinates across specialized fibers.
    Fiber 1: Subjects (Who), Fiber 2: Actions (What), Fiber 3: Objects (To What/Context)
    Fiber 4: Adjectives/Modality (How/Why), Fiber 5: Time/Sequence (When)
    """
    def __init__(self, m=256, k=4):
        self.m = m
        self.k = k
        self.vocabulary = {} # {word: (coord, fiber)}
        self._initialize_core_vocabulary()

    def _generate_coord(self, word, fiber):
        h = hashlib.sha256(word.encode()).digest()
        coords = [h[i] % self.m for i in range(self.k - 1)]
        curr_sum = sum(coords)
        last_coord = (fiber - curr_sum) % self.m
        return tuple(coords + [last_coord])

    def _initialize_core_vocabulary(self):
        core_terms = [
            # Verbs (Fiber 2: Actions)
            ("deploy", 2), ("generate", 2), ("query", 2), ("listen", 2), ("ingest", 2),
            ("build", 2), ("use", 2), ("encrypt", 2), ("fetch", 2), ("calculate", 2),
            ("route", 2), ("see", 2), ("track", 2), ("fix", 2), ("innovate", 2),
            ("finish", 2), ("execute", 2), ("send", 2), ("hello", 2), ("status", 2),
            ("optimize", 2), ("monitor", 2), ("revolve", 2), ("repair", 2),
            ("push", 2), ("secure", 2), ("process", 2), ("map", 2), ("receive", 2),
            ("think", 2), ("reason", 2), ("understand", 2), ("know", 2), ("explain", 2),
            ("create", 2), ("discover", 2), ("analyze", 2), ("solve", 2), ("verify", 2),
            ("speak", 2), ("write", 2), ("read", 2), ("listen", 2), ("learn", 2),

            # Objects (Fiber 3: Targets)
            ("system", 3), ("logic", 3), ("knowledge", 3), ("concept", 3), ("module", 3),
            ("script", 3), ("backend", 3), ("model", 3), ("data", 3), ("topology", 3),
            ("idea", 3), ("sound", 3), ("image", 3), ("bug", 3), ("network", 3),
            ("dashboard", 3), ("health", 3), ("vault", 3), ("mesh", 3), ("node", 3),
            ("kaggle", 3), ("github", 3), ("huggingface", 3), ("hf", 3), ("token", 3),
            ("message", 3), ("intent", 3), ("natural", 3), ("language", 3),
            ("science", 3), ("physics", 3), ("math", 3), ("philosophy", 3), ("history", 3),
            ("quantum", 3), ("relativity", 3), ("entropy", 3), ("gravity", 3), ("energy", 3),
            ("silicon", 3), ("hardware", 3), ("software", 3), ("intelligence", 3), ("ai", 3),

            # Subjects (Fiber 1: Entities)
            ("user", 1), ("agent", 1), ("stack", 1), ("architect", 1), ("os", 1),
            ("human", 1), ("machine", 1), ("electricity", 1), ("topology", 1), ("kernel", 1),
            ("civilization", 1), ("digital", 1), ("immortal", 1), ("sovereign", 1),

            # Modality/Adjectives (Fiber 4: Properties)
            ("fast", 4), ("secure", 4), ("optimal", 4), ("deep", 4), ("complex", 4),
            ("simple", 4), ("beautiful", 4), ("geometric", 4), ("algebraic", 4), ("true", 4),
            ("false", 4), ("unknown", 4), ("hidden", 4), ("visible", 4), ("locked", 4),

            # Libraries & Tech (Fiber 3)
            ("numpy", 3), ("pandas", 3), ("fastapi", 3), ("torch", 3), ("gradio", 3),
            ("rust", 3), ("python", 3), ("cuda", 3), ("nixos", 3), ("k8s", 3)
        ]

        # Expanded multi-token support
        for word, fiber in core_terms:
             coord = self._generate_coord(word, fiber)
             self.vocabulary[word] = (coord, fiber)

    def lookup(self, word):
        return self.vocabulary.get(word.lower())

class LexicalTopology(AlgebraicLexicon):
    pass

if __name__ == "__main__":
    lex = AlgebraicLexicon()
    print(f"Lexicon initialized with {len(lex.vocabulary)} words.")
