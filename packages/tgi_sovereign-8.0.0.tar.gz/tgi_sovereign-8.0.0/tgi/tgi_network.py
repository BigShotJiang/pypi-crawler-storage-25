import socket
import threading
import time
import json
import hashlib
from .tgi import TGICognitiveKernel

class SovereignMeshNode:
    """
    Project: ELECTRICITY - Layer 0 Decentralized Mesh v3.0
    Fuses nodes into a unified Z_m^k Mesh via Hamiltonian discovery.
    Implements 'Geometric Gossip' for knowledge synchronization.
    """
    def __init__(self, node_id, local_ip, port, m=256, k=4):
        self.node_id = node_id # Geometric Coordinate (x, y, z, w)
        self.local_ip = local_ip
        self.port = port
        self.m = m
        self.k = k
        self.peers = {} # {coord: (ip, port)}
        self.inventory = {node_id: "ONLINE"} # {coord: status}
        self.knowledge_cache = {} # {hash: data}

        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.running = True

        # Fiber-Stratified Logic Gates (from Kernel)
        self.kernel = TGICognitiveKernel(m, k)

        print(f"\n[MESH BOOT] Node {self.node_id} active on {local_ip}:{port}")

    def register_peer(self, peer_coord, peer_ip, peer_port, status="ONLINE"):
        self.peers[peer_coord] = (peer_ip, peer_port)
        self.inventory[peer_coord] = status
        print(f"  [+] Peer {peer_coord} Registered @ {peer_ip}:{peer_port}")

    def start_listener(self):
        try:
            self.server_socket.bind((self.local_ip, self.port))
            self.server_socket.listen(10)

            def listen():
                while self.running:
                    try:
                        self.server_socket.settimeout(0.5)
                        client_sock, addr = self.server_socket.accept()
                        data = client_sock.recv(16384).decode('utf-8')
                        if data:
                            packet = json.loads(data)
                            self._handle_incoming_packet(packet)
                        client_sock.close()
                    except socket.timeout:
                        continue
                    except Exception:
                        break

            threading.Thread(target=listen, daemon=True).start()
            print(f"  [*] Listener started on {self.port}.")
        except Exception as e:
            print(f"  [-] Listener failure: {e}")

    def geometric_gossip(self, category, concept_name, payload, skip_peers=None):
        """Propagates knowledge across the mesh using Hamiltonian paths."""
        concept_hash = hashlib.sha256(f"{category}:{concept_name}".encode()).hexdigest()

        is_new = concept_hash not in self.knowledge_cache
        if is_new:
             self.knowledge_cache[concept_hash] = {"category": category, "name": concept_name, "payload": payload}
             print(f"  [GOSSIP] Synchronizing: '{concept_name}' across the Mesh (from {self.node_id})...")

        # Forward to all known peers (Geometric Broadcast)
        skip_peers = skip_peers or []
        for peer_coord in self.peers:
             if peer_coord not in skip_peers and self.inventory.get(peer_coord) == "ONLINE":
                  self._transmit_packet(peer_coord, "KNOWLEDGE_SYNC", self.knowledge_cache[concept_hash])

    def _handle_incoming_packet(self, packet):
        p_type = packet.get("type")
        payload = packet.get("payload")
        origin = tuple(packet.get("origin_coord"))

        if p_type == "KNOWLEDGE_SYNC":
             c_name = payload.get("name")
             c_hash = hashlib.sha256(f"{payload['category']}:{c_name}".encode()).hexdigest()
             if c_hash not in self.knowledge_cache:
                  print(f"  [SYNC] Concept '{c_name}' received @ {self.node_id} from {origin}.")
                  # Use gossip to store and forward
                  self.geometric_gossip(payload['category'], c_name, payload['payload'], skip_peers=[origin])

        elif p_type == "COMMAND":
             # Route command to appropriate fiber or handle locally
             params = payload.get("params", {})
             target_node_list = params.get("target_node")
             target_node = tuple(target_node_list) if target_node_list else None

             if target_node == self.node_id:
                  print(f"  [COMMAND] Executing Task @ {self.node_id}: {payload.get('text')}")
             else:
                  self._route_geometrically(packet)

    def _route_geometrically(self, packet):
        """Deterministic O(1) Hamiltonian Forwarding."""
        payload = packet.get("payload", {})
        params = payload.get("params", {})
        target_node_list = params.get("target_node")
        if not target_node_list: return
        target_node = tuple(target_node_list)

        # Find path to target_node
        # For demo, just move toward the target coordinate
        next_hop = None
        for i in range(self.k):
             if self.node_id[i] < target_node[i]:
                  hop = list(self.node_id); hop[i] += 1; next_hop = tuple(hop); break
             elif self.node_id[i] > target_node[i]:
                  hop = list(self.node_id); hop[i] -= 1; next_hop = tuple(hop); break

        if next_hop in self.peers:
             print(f"  [MESH ROUTE] Forwarding from {self.node_id} to {next_hop}...")
             self._transmit_packet(next_hop, packet["type"], packet["payload"], packet["origin_coord"])
        else:
             print(f"  [-] Routing Failure @ {self.node_id}: Node {next_hop} not reachable in Peer Table.")

    def _transmit_packet(self, next_coord, p_type, payload, origin=None):
        if next_coord not in self.peers: return
        peer_ip, peer_port = self.peers[next_coord]
        packet = {
            "type": p_type,
            "payload": payload,
            "origin_coord": origin or list(self.node_id),
            "timestamp": time.time()
        }
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1.0)
            s.connect((peer_ip, peer_port))
            s.send(json.dumps(packet).encode('utf-8'))
            s.close()
        except Exception:
            self.inventory[next_coord] = "OFFLINE"

    def shutdown(self):
        self.running = False
        self.server_socket.close()
