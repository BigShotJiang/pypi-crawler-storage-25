import time
from .tgi_dictionary import AlgebraicLexicon

class TLMSemanticParser:
    """
    TGI Semantic Parser (TLM) v4.2 - Enhanced Target Extraction.
    """
    def __init__(self, m=256, k=4):
        self.m = m
        self.k = k
        self.lexicon = AlgebraicLexicon(m, k)

    def parse_advanced(self, text):
        words = text.lower().replace(",", "").replace(".", "").replace("?", "").split()
        roles = {"subject": [], "verb": [], "object": [], "modality": [], "unknown": []}
        trajectory = []

        stop_words = ["the", "a", "an", "this", "that", "these", "those", "can", "you", "should", "wants", "to"]

        for w in words:
            if w in stop_words: continue
            entry = self.lexicon.lookup(w)
            if entry:
                coord, fiber = entry
                trajectory.append(coord)
                if fiber == 1: roles["subject"].append(w)
                elif fiber == 2: roles["verb"].append(w)
                elif fiber == 3: roles["object"].append(w)
                elif fiber == 4: roles["modality"].append(w)
            else:
                roles["unknown"].append(w)

        intent = roles["verb"][0] if roles["verb"] else "query"

        # Priority for Object extraction
        target = "system"
        if roles["object"]:
             for obj in roles["object"]:
                  if obj not in ["system", "logic", "data"]:
                       target = obj
                       break
             else: target = roles["object"][0]
        elif roles["unknown"]:
             target = roles["unknown"][0]

        tuning = roles["modality"][0] if roles["modality"] else "optimal"

        return {
            "status": "ACCEPTED" if roles["verb"] or roles["object"] or roles["unknown"] else "REJECTED",
            "path": trajectory,
            "roles": roles,
            "action": intent,
            "object": target,
            "modality": tuning,
            "translation": f"INTENT: {intent.upper()} | TARGET: {target.upper()}"
        }

    def parse(self, text): return self.parse_advanced(text)

if __name__ == "__main__":
    parser = TLMSemanticParser()
    print(parser.parse_advanced("The human architect should deploy a secure backend system"))
