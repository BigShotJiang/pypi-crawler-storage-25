import time
import json
from .tgi_agent_os import AgentOS

def run_library_mapping_demo():
    print("\n" + "#"*80)
    print(" PROJECT ELECTRICITY: MULTI-LIBRARY MAPPING & SYNTHESIS")
    print(" SCENARIO: AGENT GENERATES CODE FOR DATA SCIENCE & WEB STACKS")
    print("#"*80)

    # 1. Initialize Agent OS
    os_sys = AgentOS(m=256, k=4)
    os_sys.kernel.knowledge.deep_ingestion()

    # 2. Test Phase A: Library Knowledge Retrieval
    print("\n--- [Phase A] Knowledge Retrieval for Popular Libraries ---")
    libraries = ["NumPy", "Pandas", "PyTorch", "FastAPI"]
    for lib in libraries:
         res = os_sys.process_command(f"user query concept", params={"concept": lib})
         print(f"  [KNOWLEDGE] {lib}: {res}")

    # 3. Test Phase B: Library Tool Binding
    print("\n--- [Phase B] Tool Binding for Library API Patterns ---")
    actions = ["numpy_compute", "fastapi_route", "torch_tensor"]
    for action in actions:
         res = os_sys.process_command(f"agent use {action}", params={"input": "[10, 20, 30]"})
         print(f"\n{res}")

    # 4. Test Phase C: Multi-Library Autonomous Synthesis
    print("\n--- [Phase C] Autonomous Code Synthesis for Web & ML ---")
    tasks = [
        {"task": "data_analysis", "prompt": "generate pandas script"},
        {"task": "web_server", "prompt": "build fastapi backend"},
        {"task": "neural_net", "prompt": "generate torch model"}
    ]

    for t in tasks:
         res = os_sys.process_command(t["prompt"], params={"task": t["task"]})
         print(f"\n{res}")

    print("\n" + "="*80)
    print(" CONCLUSION: MULTI-LIBRARY INTEGRATION COMPLETE.")
    print(" THE AGENT SPEAKS DATA SCIENCE, WEB, AND MACHINE LEARNING.")
    print("="*80)

if __name__ == "__main__":
    run_library_mapping_demo()
