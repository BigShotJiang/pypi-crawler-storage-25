import numpy as np
import time
from tgi.tgi_sovereign import SovereignKernel
from tgi.tgi_agent_os import AgentOS

def run_final_synthesis_demo():
    print("=========================================================")
    print(" PROJECT ELECTRICITY: FINAL SYNTHESIS DEMO")
    print(" MACRO-ROUTING (FSO) + MICRO-MEMORY (HRR)")
    print("=========================================================\n")

    # 1. Initialize the Sovereign Stack
    os_sys = AgentOS(m=251, k=4)
    kernel = os_sys.kernel
    
    print("\n[*] Hashing 100 concepts into the HRR Manifold...")
    # Simulate loading 100 concepts distributed across fibers
    for i in range(100):
        fiber = i % 5
        kernel.hrr_memory.ingest(f"Concept_{i}", f"Data_Payload_{i}", target_fiber=fiber)

    # 2. Execute an Agentic Command
    print("\n[+] Executing Agentic Command: 'Generate weather tool'")
    response = os_sys.process_command("Generate weather tool")
    print(response)

    # 3. Direct HRR Retrieval Verification
    print("\n[+] Direct HRR Retrieval Verification (Concept_48)")
    target_concept = "Concept_48"
    target_fiber = 48 % 5
    retrieved_data, confidence = kernel.hrr_memory.retrieve(target_concept, target_fiber)
    
    print(f"    Target:     {target_concept} (Fiber {target_fiber})")
    print(f"    Retrieved:  {retrieved_data}")
    print(f"    Confidence: {confidence:.4f}")

    if retrieved_data == "Data_Payload_48":
        print("\n=========================================================")
        print(" SUCCESS: MACRO-MICRO SYNTHESIS VERIFIED.")
        print(" THE SOVEREIGN AGENT IS FULLY OPERATIONAL.")
        print("=========================================================")
    else:
        print("\n[!] FAILURE: Retrieval Parity Error.")

if __name__ == "__main__":
    run_final_synthesis_demo()
