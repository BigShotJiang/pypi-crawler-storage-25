import requests
from tgi.tgi_agent_os import AgentOS

# =============================================================================
# EXECUTING THE AGENTIC WEB INGESTOR DEMO
# =============================================================================
print("=========================================================")
print(" PROJECT ELECTRICITY: AGENTIC WEB INGESTION")
print("=========================================================\n")

# Mocking requests for a webpage
class MockWebResponse:
    def __init__(self, text, status_code):
        self.text = text
        self.status_code = status_code

original_get = requests.get
def mock_get(url, timeout=10):
    if url == "https://project-electricity.org":
        return MockWebResponse("""
        <html>
            <head><title>Project ELECTRICITY</title></head>
            <body>
                <h1>Sovereign OS</h1>
                <script>console.log('hidden noise');</script>
                <p>Topological General Intelligence is here.</p>
                <div class="ads">Buy more SRAM!</div>
                <style>.ads { color: red; }</style>
            </body>
        </html>
        """, 200)
    return original_get(url, timeout=timeout)

requests.get = mock_get

os_sys = AgentOS(m=256, k=4)

# 1. Ingesting a Webpage via Agent OS
print("\n[*] TRIGGERING AGENTIC WEB INGESTION...")
res = os_sys.process_command("ingest the project documentation", params={"url": "https://project-electricity.org"})
print(f"\n[AGENT OS RESPONSE]: {res}")

# 2. Verifying the Ingested Content in the Torus
print("\n[*] VERIFYING MANIFOLD STATE...")
# We look for the coordinate mapped to the URL (project-electricity.org.txt)
# The ingestor logic uses: filename = url.split("//")[-1].replace("/", "_") + ".txt"
filename = "project-electricity.org.txt"
coord = os_sys.kernel.ingestor._hash_to_coord(filename, 2)
ingested_data = os_sys.kernel.ingestor.topological_file_system.get(coord)

if ingested_data:
    print(f"  [+] Found content at {coord}")
    print(f"  [+] Filename: {ingested_data['filename']}")
    print(f"  [+] Fiber: {ingested_data['fiber']}")
    print(f"  [+] Cleaned Payload: {ingested_data['payload']}")
else:
    print("  [-] ERROR: Content not found in the Torus.")

# Cleanup
requests.get = original_get
