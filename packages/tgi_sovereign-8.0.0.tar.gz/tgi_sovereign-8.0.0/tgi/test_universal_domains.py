import unittest
from .tgi_sovereign import SovereignKernel

class TestUniversalDomains(unittest.TestCase):
    def setUp(self):
        self.k = SovereignKernel(m=256, k=4)
        self.k.sovereign_boot()

    def test_fusion_simulation(self):
        traj, density, msg = self.k.simulate_fusion_plasma(steps=100)
        self.assertEqual(len(traj), 101) # start + 100 steps
        self.assertTrue(density > 0)
        self.assertIn("STABLE", msg)

    def test_genomic_routing(self):
        seq = "ATCGATCG"
        path = self.k.route_genomic_pathway(seq)
        self.assertEqual(len(path), 8)
        # Check non-intersecting
        self.assertEqual(len(path), len(set(path)))

    def test_quantum_decoding(self):
        loc = (5, 10, 15, 20)
        corr, msg = self.k.quantum_syndrome_map(loc)
        self.assertEqual(len(corr), 4)
        self.assertEqual(msg, "RECOVERY_MAPPED")

    def test_neural_compression(self):
        res = self.k.compress_neural_layer("layer_1", (2048, 2048))
        self.assertTrue(res['compression_ratio'] > 1000)
        self.assertEqual(res['status'], "ALGEBRAICALLY_SECURED")

    def test_topological_crypto(self):
        msg = "TOP_SECRET_COORDINATES"
        sig = self.k.secure_communicate(msg)
        self.assertTrue(sig.startswith("SIG_"))
        self.assertTrue(self.k.crypto.verify_signature(msg, sig))

if __name__ == "__main__":
    unittest.main()
