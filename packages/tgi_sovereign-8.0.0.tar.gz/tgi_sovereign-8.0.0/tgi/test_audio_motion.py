import unittest
import math
from .tgi_audio import AlgebraicAudioEngine
from .tgi_motion import MotionTracker

class TestMultimodalSystem(unittest.TestCase):
    def setUp(self):
        self.m = 100
        self.ear = AlgebraicAudioEngine(m=self.m)
        self.tracker = MotionTracker(m=self.m)

    def test_audio_signature_consistency(self):
        # Sine wave
        samples1 = [int(50 + 20 * math.sin(0.1 * i)) for i in range(100)]
        self.ear.ingest_waveform(samples1)
        sig1 = self.ear.extract_frequency_signature()

        # Exact same wave should yield same signature
        self.ear.ingest_waveform(samples1)
        sig2 = self.ear.extract_frequency_signature()
        self.assertEqual(sig1, sig2)

    def test_audio_anomaly_detection(self):
        samples = [10, 20, 30, 20, 10]
        self.ear.ingest_waveform(samples)
        expected_sig = self.ear.extract_frequency_signature()

        # Corrupted sample
        bad_samples = [10, 20, 99, 20, 10]
        self.ear.ingest_waveform(bad_samples)
        is_anomaly, current_sig = self.ear.detect_anomalies(expected_sig)

        self.assertTrue(is_anomaly)
        self.assertNotEqual(expected_sig, current_sig)

    def test_collision_prediction(self):
        # Object 1 moving to (5,5)
        self.tracker.update_shape_position("OBJ_1", [(3,3)])
        self.tracker.update_shape_position("OBJ_1", [(4,4)])

        # Object 2 moving to (5,5)
        self.tracker.update_shape_position("OBJ_2", [(7,7)])
        self.tracker.update_shape_position("OBJ_2", [(6,6)])

        # Both predicted to be at (5,5) in the next frame
        collisions = self.tracker.detect_potential_collisions(threshold=1.0)
        self.assertEqual(len(collisions), 1)
        self.assertEqual(collisions[0][0], "OBJ_1")
        self.assertEqual(collisions[0][1], "OBJ_2")
        self.assertEqual(collisions[0][2], 0.0)

if __name__ == "__main__":
    unittest.main()
