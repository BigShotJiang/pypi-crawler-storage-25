import json
import time
from tgi.tgi_omniscient import OmniscientOntologyGrid
from tgi.tgi_mcp_router import MCP_Ingestion_Router
from tgi.tgi_agentic_app import Sovereign_Agent_Core

def run_verification():
    print("=========================================================")
    print(" PROJECT ELECTRICITY: AGENTIC OMNISCIENT VERIFICATION")
    print("=========================================================\n")

    # 1. Verify Omniscient Ontology
    print("[1] Testing Omniscient Ontology Ingestion...")
    grid = OmniscientOntologyGrid()
    grid.perform_master_ingestion()

    # Verify a vector
    vector = grid.forge_architectural_vector("Rust", "WebAssembly", "Compiles to ultra-secure frontend modules")
    if vector:
        print(f"[SUCCESS] Architectural Vector forged: {vector}")
    else:
        print("[FAILURE] Failed to forge architectural vector.")

    # 2. Verify MCP Ingestion
    print("\n[2] Testing MCP Ingestion Router...")
    router = MCP_Ingestion_Router()
    mock_mcp = {
        "server": "Sovereign_Cloud_Tools",
        "tools": [
            {
                "name": "send_slack_message",
                "description": "Sends a message to a Slack channel",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "channel": {"type": "string"},
                        "message": {"type": "string"}
                    }
                }
            }
        ]
    }
    success = router.ingest_mcp_schema(json.dumps(mock_mcp))
    if success:
        print("[SUCCESS] MCP Schema ingested and mapped to ToolManifold.")
    else:
        print("[FAILURE] MCP Schema ingestion failed.")

    # 3. Verify Agentic Core
    print("\n[3] Testing Agentic Core Execution...")
    agent = Sovereign_Agent_Core()

    print("\n[Test A] Ping Command (Bash Bridge)")
    # Note: In a restricted environment, ping might fail or be blocked.
    # We check if it attempts execution.
    res = agent.process_chat("ping network")
    print(res)

    print("\n[Test B] Fetch Data (Mock API)")
    res = agent.process_chat("fetch metrics")
    print(res)

    print("\n[Test C] Generate Code (Syntax Trace)")
    res = agent.process_chat("generate code for a bridge")
    print(res)

    print("\n=========================================================")
    print(" VERIFICATION COMPLETE")
    print("=========================================================")

if __name__ == "__main__":
    run_verification()
