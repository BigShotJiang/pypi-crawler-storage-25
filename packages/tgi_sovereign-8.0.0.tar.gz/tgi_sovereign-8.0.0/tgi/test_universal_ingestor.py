import unittest
import io
import zipfile
import requests
import hashlib
from tgi.tgi_universal_ingestor import TGI_Universal_Ingestor

class TestTGIUniversalIngestor(unittest.TestCase):
    def setUp(self):
        self.m = 256
        self.k = 4
        self.ingestor = TGI_Universal_Ingestor(m=self.m, k=self.k)

        # Mock ZIP for testing
        self.mock_zip_buffer = io.BytesIO()
        with zipfile.ZipFile(self.mock_zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("test_logic.py", "print('hello')")
            zf.writestr("test_data.json", '{"key": "value"}')
            zf.writestr("test_media.png", b'fake_png_data')
            zf.writestr("test_unknown.bin", b'binary_data')

    def test_determine_fiber(self):
        self.assertEqual(self.ingestor.determine_fiber("code.py"), 1)
        self.assertEqual(self.ingestor.determine_fiber("data.json"), 2)
        self.assertEqual(self.ingestor.determine_fiber("image.png"), 3)
        self.assertEqual(self.ingestor.determine_fiber("raw.bin"), 0)

    def test_hash_to_coord(self):
        filename = "test.txt"
        fiber = 2
        coord = self.ingestor._hash_to_coord(filename, fiber)
        self.assertEqual(len(coord), self.k)
        # Check Closure Lemma: (x + y + z + w) % m == target_fiber
        self.assertEqual(sum(coord) % self.m, fiber)

    def test_ingest_https_zip(self):
        # Mock requests.get
        class MockResponse:
            def __init__(self, content, status_code):
                self.content = content
                self.status_code = status_code

        original_get = requests.get
        requests.get = lambda url, timeout=10: MockResponse(self.mock_zip_buffer.getvalue(), 200)

        try:
            success = self.ingestor.ingest_https_zip("http://example.com/test.zip")
            self.assertTrue(success)
            self.assertEqual(len(self.ingestor.topological_file_system), 4)

            # Verify specific file mapping
            # test_logic.py -> Fiber 1
            # We need to find the coord by hashing "test_logic.py"
            target_fiber = 1
            h = hashlib.sha256("test_logic.py".encode('utf-8')).digest()
            x, y, z = h[0] % self.m, h[1] % self.m, h[2] % self.m
            w = (target_fiber - (x + y + z)) % self.m
            expected_coord = (x, y, z, w)

            self.assertIn(expected_coord, self.ingestor.topological_file_system)
            self.assertEqual(self.ingestor.topological_file_system[expected_coord]["filename"], "test_logic.py")
            self.assertEqual(self.ingestor.topological_file_system[expected_coord]["fiber"], 1)

        finally:
            requests.get = original_get

if __name__ == "__main__":
    unittest.main()
