import time
import hashlib
from .tgi_dictionary import AlgebraicLexicon
from .tgi_parser import TLMSemanticParser

class TopologicalLanguageModel:
    """
    Project: ELECTRICITY (Topological Language Model v5.2).
    Deterministic Conversational Intelligence with collision support.
    """
    def __init__(self, m=251, k=4, kernel=None):
        self.m = m
        self.k = k
        self.kernel = kernel
        self.lexicon = AlgebraicLexicon(m, k)
        self.parser = TLMSemanticParser(m, k)

    def _get_word_coord(self, word):
        entry = self.lexicon.lookup(word)
        return entry[0] if entry else None

    def converse(self, user_input):
        parse_res = self.parser.parse_advanced(user_input)
        roles = parse_res["roles"]

        subject = roles["subject"][-1] if roles["subject"] else "agent"
        intent = roles["verb"][-1] if roles["verb"] else "query"
        target = parse_res["object"]

        if self.kernel:
             coord = self.kernel.knowledge.lexicon.get(target.lower())
             if coord:
                  items = self.kernel.knowledge.get_concept_by_coord(coord)
                  for item in items:
                       if item["name"].lower() == target.lower():
                            payload = item["payload"]
                            return f"Topological Fact [{target}]: {payload}", parse_res

        return f"The {intent} of {subject} on {target} is being processed through the {self.m}^{self.k} manifold.", parse_res

    def process_conversational_input(self, text): return self.converse(text)

if __name__ == "__main__":
    tlm = TopologicalLanguageModel()
    print("[+] TLM v5.2 Active.")
