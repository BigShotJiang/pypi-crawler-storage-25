import unittest
from .tgi_funnel import TopologicalDataFunnel
from .tgi_sovereign import SovereignKernel

class TestTopologicalDataFunnel(unittest.TestCase):
    def setUp(self):
        self.funnel = TopologicalDataFunnel(m=256, k=3)

    def test_parity_filter(self):
        # Valid: 3 components
        # Invalid: 2 or 4 components
        data = [
            ["A", "B", "C"],
            ["X", "Y"],
            ["P", "Q", "R", "S"]
        ]
        results = self.funnel.auto_ingest_raw_data(data)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0][1], ["A", "B", "C"])

    def test_closure_healing(self):
        # Missing 'None' should be healed to a HEALED_ coordinate
        data = [["Humidity", None, "Timestamp_18:36"]]
        results = self.funnel.auto_ingest_raw_data(data)
        healed_val = results[0][1][1]
        self.assertTrue(healed_val.startswith("HEALED_"))

        # Verify it completes a zero-sum parity (conceptually)
        # Note: In our simple mock, we just check it was replaced.
        self.assertIsNotNone(healed_val)

    def test_auto_labeling(self):
        data = [["A", "B", "C"]]
        results = self.funnel.auto_ingest_raw_data(data)
        coord, packet = results[0]
        self.assertEqual(len(coord), 3)
        self.assertEqual(packet, ["A", "B", "C"])

        # Consistent hashing check
        results2 = self.funnel.auto_ingest_raw_data(data)
        coord2, _ = results2[0]
        self.assertEqual(coord, coord2)

    def test_sovereign_integration(self):
        kernel = SovereignKernel(m=256, k=4)
        data = [["Sensor", "Value", "Time"]]
        results = kernel.ingest_raw_stream(data)
        self.assertEqual(len(results), 1)

if __name__ == "__main__":
    unittest.main()
