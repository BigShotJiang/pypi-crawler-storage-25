import io
import zipfile
import requests
from tgi.tgi_universal_ingestor import TGI_Universal_Ingestor

# =============================================================================
# EXECUTING THE UNIVERSAL INGESTOR DEMO
# =============================================================================
print("=========================================================")
print(" PROJECT ELECTRICITY: OMNIVOROUS DATA CONSUMPTION")
print("=========================================================\n")

# Creating a mock tiny ZIP file in memory for the demonstration
mock_zip_buffer = io.BytesIO()
with zipfile.ZipFile(mock_zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
    zf.writestr("core_logic.py", "def execute(): print('Running on TGI')")
    zf.writestr("database.json", '{"users": ["Architect", "TGI"]}')
    zf.writestr("logo.png", b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR...')
    zf.writestr("readme.md", "# Project ELECTRICITY\nThe Sovereign OS.")

# Overriding the requests.get for the demo to return our mock ZIP
class MockResponse:
    def __init__(self, content):
        self.status_code = 200
        self.content = content
requests.get = lambda url, timeout=10: MockResponse(mock_zip_buffer.getvalue())

tgi_io = TGI_Universal_Ingestor(m=256, k=4)

# TGI Reaches out to the "Internet" to consume a repository
tgi_io.ingest_https_zip("https://github.com/Sovereign/ProjectElectricity/archive/main.zip")
