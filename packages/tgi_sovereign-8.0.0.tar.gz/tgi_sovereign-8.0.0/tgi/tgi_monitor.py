import time
import statistics

class SovereignMonitor:
    """
    Project: ELECTRICITY (Sovereign Monitoring Engine)
    Real-time tracking of Parity Integrity, Geometric Latency, and Resource Health.
    """
    def __init__(self, kernel):
        self.kernel = kernel
        self.latency_history = []
        self.start_time = time.time()

    def parity_heartbeat(self):
        """Checks internal integrity and H2 parity obstructions."""
        print(f"\n[{time.strftime('%H:%M:%S')}] --- MONITOR: Parity Heartbeat ---")
        is_stable = self.kernel.self_reflection()
        status = "STABLE" if is_stable else "PARITY OBSTRUCTION DETECTED"
        print(f"  [*] System Status: {status}")
        return is_stable

    def monitor_resources(self):
        """Lists active resources and their health status."""
        print(f"\n[{time.strftime('%H:%M:%S')}] --- MONITOR: Resource Manifold ---")
        online_count = 0
        total_count = 0
        # Access through the correct attribute 'inventory'
        for name, data in self.kernel.resources.inventory.items():
            total_count += 1
            status = data.get('status', 'UNKNOWN')
            if status == "ONLINE":
                online_count += 1
            print(f"  [+] {name:20} | Type: {data['type']:10} | Status: {status}")

        availability = (online_count / total_count * 100) if total_count > 0 else 100
        print(f"  [*] Global Availability: {availability:.1f}%")
        return availability

    def track_geometric_latency(self, func, *args, **kwargs):
        """Measures the execution time of an O(1) manifold operation."""
        start = time.perf_counter()
        result = func(*args, **kwargs)
        end = time.perf_counter()

        latency_ms = (end - start) * 1000
        self.latency_history.append(latency_ms)

        # Keep only last 100 measurements
        if len(self.latency_history) > 100:
            self.latency_history.pop(0)

        return result, latency_ms

    def get_latency_report(self):
        """Generates a summary of geometric performance."""
        if not self.latency_history:
            return "No latency data collected."

        avg = statistics.mean(self.latency_history)
        p95 = sorted(self.latency_history)[int(len(self.latency_history) * 0.95)]
        print(f"\n[{time.strftime('%H:%M:%S')}] --- MONITOR: Performance Report ---")
        print(f"  [*] Avg Latency: {avg:.4f} ms")
        print(f"  [*] P95 Latency: {p95:.4f} ms")
        print(f"  [*] Samples:     {len(self.latency_history)}")
        return avg, p95

    def run_full_diagnostic(self):
        """Executes a complete sweep of the Sovereign stack."""
        print("\n" + "="*80)
        print(" SOVEREIGN OS SYSTEM DIAGNOSTIC")
        print("="*80)

        self.parity_heartbeat()
        self.monitor_resources()

        # Test a coordinate jump (O(1) retrieval)
        print(f"\n[*] Stress Testing Geometric Jump (k={self.kernel.k})...")
        for _ in range(10):
            # Using measure_distance since get_concept_by_coord was missing
            self.track_geometric_latency(self.kernel.knowledge.measure_distance, (0,0,0,0), (0,0,0,1))

        self.get_latency_report()
        uptime = time.time() - self.start_time
        print(f"\n[*] System Uptime: {uptime:.2f} seconds")
        print("="*80)

if __name__ == "__main__":
    from tgi.tgi_sovereign import SovereignKernel
    k = SovereignKernel()
    k.sovereign_boot()

    monitor = SovereignMonitor(k)
    monitor.run_full_diagnostic()
