import json
import hashlib
import time
import os
from .tgi_tool_manifold import ToolManifold

class MCP_Ingestion_Router:
    """
    Project: ELECTRICITY (The MCP Ingestion Router)
    Parses MCP/OpenAPI schemas and hashes them into the Torus coordinates.
    """
    def __init__(self, m=256, k=4, manifold=None):
        self.m = m
        self.k = k
        self.manifold = manifold or ToolManifold(m, k)

    def hash_endpoint(self, endpoint, fiber=4):
        """
        Calculates the permanent (x, y, z, w) coordinate for an API endpoint.
        Uses Closure Lemma for fiber alignment.
        """
        h = hashlib.md5(endpoint.encode('utf-8')).digest()
        x, y, z = h[0] % self.m, h[1] % self.m, h[2] % self.m
        w = (fiber - (x + y + z)) % self.m
        return (x, y, z, w)

    def ingest_mcp_schema(self, schema_json):
        """
        Ingests a standardized MCP JSON file.
        """
        try:
            data = json.loads(schema_json)
            server_name = data.get("server", "unknown_mcp")
            tools = data.get("tools", [])

            print(f"[*] [MCP INGEST] Processing Server: '{server_name}' ({len(tools)} tools)")

            for tool in tools:
                name = tool.get("name")
                description = tool.get("description", "")
                params_schema = tool.get("inputSchema", {}).get("properties", {})
                required = tool.get("inputSchema", {}).get("required", [])

                # Register in manifold
                coord = self.hash_endpoint(name)
                tool_entry = {
                    "action": name,
                    "type": "MCP",
                    "server": server_name,
                    "description": description,
                    "parameters": required, # We use required list for Closure Lemma check
                    "schema": params_schema,
                    "coord": coord
                }
                self.manifold.ingest_tool(tool_entry)
                print(f"  [+] MCP Tool '{name}' locked @ {coord}")

            return True
        except Exception as e:
            print(f"[-] MCP INGEST ERROR: {str(e)}")
            return False

    def scan_directory(self, directory_path):
        """Scans a directory for .json MCP schemas and ingests them."""
        if not os.path.exists(directory_path):
            print(f"[-] Directory not found: {directory_path}")
            return

        for file in os.listdir(directory_path):
            if file.endswith(".json"):
                with open(os.path.join(directory_path, file), 'r') as f:
                    self.ingest_mcp_schema(f.read())

if __name__ == "__main__":
    # Mocking an MCP Ingestion
    router = MCP_Ingestion_Router()

    mock_mcp = {
        "server": "Sovereign_Cloud_Tools",
        "tools": [
            {
                "name": "send_slack_message",
                "description": "Sends a message to a Slack channel",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "channel": {"type": "string"},
                        "message": {"type": "string"}
                    }
                }
            }
        ]
    }

    router.ingest_mcp_schema(json.dumps(mock_mcp))
