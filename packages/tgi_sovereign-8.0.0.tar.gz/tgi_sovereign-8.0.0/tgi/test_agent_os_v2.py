from tgi.tgi_agent_os import AgentOS

def test_comprehensive_workflow():
    os_sys = AgentOS(m=101, k=3)
    # Register required infrastructure for the OS to function
    os_sys.srm.register_resource("Storage_Node", "STORAGE", coord=(0, 1, 1))

    print("\n--- Test 1: Dynamic Tool Resolution (Encrypt) ---")
    encrypt_res = os_sys.process_command("user encrypt data", params={"payload": "TGI_COORDS", "key": "0xSES"})
    print(encrypt_res)
    assert "DATA_ENCRYPTED" in encrypt_res

    print("\n--- Test 2: Multi-Step Hamiltonian Workflow ---")
    workflow = [
        {"command": "user fetch data", "params": {"source_url": "https://api.fso.ai", "query_params": {"grid": 101}}},
        {"command": "user calculate topology", "params": {"grid_m": 101, "dim_k": 3}},
        {"command": "user route data", "params": {"source": "Node A", "destination": "Node B"}},
        {"command": "agent finish execute"}
    ]
    results = os_sys.execute_workflow(workflow)
    for r in results:
        print(r)
    assert any("DATA_FETCHED" in r for r in results)
    assert any("TOPOLOGY_CALCULATED" in r for r in results)
    assert any("SIGNAL_ROUTED" in r for r in results)

    print("\n--- Test 3: Unclosed Cycle (Missing Params) ---")
    missing_res = os_sys.process_command("user send data", params={"recipient": "bob@fso.ai"})
    print(missing_res)
    assert "CYCLE_UNCLOSED" in missing_res

    print("\n--- Test 4: H^2 Paradox Detection (Backward Syntax) ---")
    paradox_res = os_sys.process_command("execute user send")
    print(paradox_res)
    assert "PARADOX DETECTED" in paradox_res

    print("\n--- Test 5: Memory Trace Verification ---")
    footprint = os_sys.memory.get_memory_footprint()
    print(f"Memory Footprint: {footprint} bytes")
    # Total paths saved: 1 (encrypt) + 4 (workflow) + 1 (missing params) = 6
    count = len(os_sys.memory.global_trajectory)
    print(f"Global Trajectory Count: {count}")
    assert count == 6

    print("\n[SUCCESS] Comprehensive Agent OS v2.0 Test Passed.")

if __name__ == "__main__":
    test_comprehensive_workflow()
