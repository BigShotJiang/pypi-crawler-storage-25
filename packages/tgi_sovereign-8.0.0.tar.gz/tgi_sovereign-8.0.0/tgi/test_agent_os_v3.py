import unittest
import math
from .tgi_agent_os import AgentOS

class TestAgentOSV3(unittest.TestCase):
    def setUp(self):
        self.os = AgentOS(m=256, k=4)

    def test_multimodal_vision(self):
        grid = [[0]*10 for _ in range(10)]
        for y in range(2, 6):
            for x in range(2, 6): grid[y][x] = 255
        res = self.os.process_command("user see image", params={"image_grid": grid})
        self.assertTrue(res.startswith("OS_VISION_SUCCESS"))

    def test_multimodal_audio(self):
        samples = [int(128 + 50 * math.sin(0.1 * i)) for i in range(100)]
        res = self.os.process_command("user listen sound", params={"audio_samples": samples})
        self.assertTrue(res.startswith("OS_AUDIO_SUCCESS"))

    def test_multimodal_innovation(self):
        self.os.kernel.sovereign_boot()
        res = self.os.process_command("agent innovate idea", params={"concept1": "Biological_DNA", "concept2": "Silicon_Microchip"})
        self.assertTrue(res.startswith("OS_INNOVATION_SUCCESS"))

    def test_multimodal_repair(self):
        self.os.kernel.sovereign_boot()
        res = self.os.process_command("system fix bug")
        self.assertTrue(res.startswith("OS_REPAIR_SUCCESS"))

    def test_syntax_tori(self):
        prog = [{"type": "SET"}, {"type": "CALC"}, {"type": "RETURN"}]
        res = self.os.compile_and_run(prog)
        self.assertEqual(res, "OS_SUCCESS: Program stable.")

    def test_workflow_execution(self):
        workflow = [
            {"command": "user see image", "params": {"image_grid": [[0]*5 for _ in range(5)]}},
            {"command": "agent innovate idea", "params": {"concept1": "A", "concept2": "B"}}
        ]
        results = self.os.execute_workflow(workflow)
        self.assertEqual(len(results), 2)

if __name__ == "__main__":
    unittest.main()
