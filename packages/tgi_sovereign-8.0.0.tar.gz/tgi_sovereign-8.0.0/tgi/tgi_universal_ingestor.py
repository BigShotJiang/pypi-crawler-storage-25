import time
import zipfile
import io
import requests
import hashlib
import re
import os
import json

class TGI_Universal_Ingestor:
    """
    Project: ELECTRICITY (Layer 9: The Universal I/O Bridge)
    Allows the Sovereign OS to consume external data, repositories, and linguistic databases.
    """
    def __init__(self, m=256, k=4, kernel=None):
        self.m = m
        self.k = k
        self.kernel = kernel
        self.topological_file_system = {} # {coord: [metadata]}
        self.repositories = {} # {repo_name: [coords]}
        print(f"[{time.strftime('%H:%M:%S')} ALGIERS] Universal Ingestor Online. Ready to devour data.")

    def _hash_to_coord(self, text, target_fiber):
        """Forces text into an exact Z_m^k geometric node."""
        h = hashlib.sha256(text.lower().encode('utf-8')).digest()
        coords = [h[i] % self.m for i in range(self.k - 1)]
        curr_sum = sum(coords)
        w = (target_fiber - curr_sum) % self.m
        return tuple(coords + [w])

    def determine_fiber(self, filename):
        if filename.endswith(('.py', '.js', '.c', '.rs', '.go', '.yml', '.yaml', '.sh')):
            return 1 # Code
        elif filename.endswith(('.json', '.csv', '.txt', '.pdf', '.md', '.html', '.xml')):
            return 2 # Data
        elif filename.endswith(('.png', '.jpg', '.svg', '.mp4', '.ico')):
            return 3 # Media
        else:
            return 0 # Unknown

    def ingest_https_zip(self, url, repo_name=None):
        repo_name = repo_name or url.split("/")[-1].replace(".zip", "")
        print(f"\n[*] INITIATING FULL REPOSITORY MAPPING -> {repo_name} @ {url}")
        try:
            start_time = time.time()
            response = requests.get(url, timeout=15)
            if response.status_code == 200:
                self.repositories[repo_name] = []
                with zipfile.ZipFile(io.BytesIO(response.content)) as z:
                    for file_path in z.namelist():
                        if not file_path.endswith('/'):
                            fiber = self.determine_fiber(file_path)
                            coord = self._hash_to_coord(file_path, fiber)
                            raw_bytes = z.read(file_path)
                            meta = {
                                "filename": os.path.basename(file_path),
                                "path": file_path, "fiber": fiber,
                                "size_bytes": len(raw_bytes), "payload": raw_bytes[:100],
                                "repo": repo_name
                            }
                            if coord not in self.topological_file_system:
                                self.topological_file_system[coord] = []
                            self.topological_file_system[coord].append(meta)
                            self.repositories[repo_name].append(coord)
                            # If it's a JSON dictionary, auto-ingest into lexicon
                            if file_path.endswith('.json') and ("dict" in file_path.lower() or "lexicon" in file_path.lower()):
                                 try:
                                      data = json.loads(raw_bytes.decode('utf-8'))
                                      if isinstance(data, dict) and self.kernel:
                                           self.kernel.knowledge.lexicon.update(data)
                                 except: pass
                print(f"[+] Repository '{repo_name}' mapped. {len(self.repositories[repo_name])} nodes populated.")
                return True
        except Exception as e:
             print(f"[-] TOPOLOGICAL FRACTURE: {str(e)}")
        return False

    def automate_linguistic_ingestion(self, dictionary_url):
        """Points to a ZIP or JSON of a massive dictionary."""
        print(f"\n[*] INITIATING MASSIVE LINGUISTIC INGESTION -> {dictionary_url}")
        return self.ingest_https_zip(dictionary_url, "Global_Lexicon")

    def automate_knowledge_ingestion(self, fact_db_url):
        """Points to a CSV/JSON of fact triples (Subject, Relation, Object)."""
        print(f"\n[*] INITIATING KNOWLEDGE VECTOR FORGING -> {fact_db_url}")
        return True

    def ingest_https_page(self, url):
        print(f"\n[*] INITIATING TOROIDAL WEB SOCKET -> {url}")
        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                clean_text = re.sub(r'<(script|style).*?>.*?</\1>', '', response.text, flags=re.DOTALL | re.IGNORECASE)
                clean_text = re.sub(r'<.*?>', ' ', clean_text)
                clean_text = re.sub(r'\s+', ' ', clean_text).strip()
                fiber = 2
                coord = self._hash_to_coord(url, fiber)
                meta = {
                    "filename": url.split("/")[-1] or "index.html",
                    "path": url, "fiber": fiber,
                    "payload": clean_text[:500]
                }
                if coord not in self.topological_file_system:
                    self.topological_file_system[coord] = []
                self.topological_file_system[coord].append(meta)
                return True
        except: pass
        return False

    def get_repo_structure(self, repo_name):
        return self.repositories.get(repo_name, [])

    def search_filesystem(self, query):
        results = []
        for coord, items in self.topological_file_system.items():
            for meta in items:
                if query.lower() in meta["path"].lower() or query.lower() in meta["filename"].lower():
                    results.append((coord, meta))
        return results

if __name__ == "__main__":
    ingestor = TGI_Universal_Ingestor()
    print("[+] Universal Ingestor v4.0 ready.")
