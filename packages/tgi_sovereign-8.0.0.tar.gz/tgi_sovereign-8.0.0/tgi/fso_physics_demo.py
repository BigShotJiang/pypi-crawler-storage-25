import time
from tgi.tgi_sovereign import SovereignKernel
from tgi.tgi_router import FSORouter
from tgi.tgi_tfs import TopologicalFileSystem

def run_physics_demo():
    print("=========================================================")
    print(" PROJECT ELECTRICITY: THE MATHEMATICALLY CONSCIOUS OS")
    print("=========================================================")

    # 1. Booting a Standard Harmonic System (m=256, k=4)
    print("\n[SCENARIO 1] Booting Harmonic System (m=256, k=4)")
    kernel = SovereignKernel(m=256, k=4)
    kernel.sovereign_boot()

    # 2. Attempting to Initialize TFS on an Obstructed Manifold (m=4, k=3)
    print("\n[SCENARIO 2] Attempting TFS on Obstructed Manifold (m=4, k=3)")
    try:
        # We simulate the failure by manually passing an obstructed config to a new TFS instance
        # linked to the same kernel codex
        bad_tfs = TopologicalFileSystem(m=4, k=3, kernel=kernel)
    except Exception as e:
        print(f"  [!] EXPECTED ERROR: {e}")

    # 3. Validating a Router Solve via Codex Consultation
    print("\n[SCENARIO 3] Autonomous Routing (Codex-Validated Spike)")
    # Odd m, k=3 is the "Spike" domain
    router = FSORouter(m=101, k=3, kernel=kernel)
    print("[ROUTER] Solving for m=101, k=3...")
    gates = router.solve()
    if gates:
        print(f"  [+] SUCCESS: Hamiltonian Cycle Generated via Codex Law IV (Spike Invariant).")

    # 4. Attempting to Route on an Obstructed Manifold
    print("\n[SCENARIO 4] Attempting Routing on Obstructed Manifold (m=4, k=3)")
    router_bad = FSORouter(m=4, k=3, kernel=kernel)
    try:
        router_bad.solve()
    except Exception as e:
        print(f"  [!] ACTION BLOCKED: {e}")

    # 5. Writing and Reading Data from the Validated TFS
    print("\n[SCENARIO 5] Data Sharding on Validated TFS")
    test_data = "PROJECT ELECTRICITY: THE CODEX IS ACTIVE"
    kernel.tfs.write_topological_data("codex_test", "txt", test_data)
    retrieved = kernel.tfs.read_topological_data("codex_test", "txt")

    if retrieved == test_data:
        print(f"  [+] DATA INTEGRITY VERIFIED: {retrieved}")
    else:
        print(f"  [!] DATA CORRUPTION DETECTED.")

    print("\n=========================================================")
    print(" THE FOUNDATIONAL PHYSICS OF SOVEREIGN OS ARE ENFORCED")
    print("=========================================================\n")

if __name__ == "__main__":
    run_physics_demo()
