from tgi.tgi import TGICognitiveKernel
from tgi.tgi_dictionary import LexicalTopology

class TopologicalCompiler:
    """
    TopOS Compiler Beta (Syntax Tori).
    Syntax as Geometry: Programming instructions are assigned to toroidal fibers.
    Compilation = Cycle Verification.
    Detects logical errors as H^2 Parity Breaks.
    """
    def __init__(self, m=101, k=3):
        self.m = m
        self.k = k
        self.kernel = TGICognitiveKernel(m, k)
        self.lt = LexicalTopology(m, k)

        # Fiber Mapping for Primitives (Syntax Tori)
        self.SYNTAX_FIBERS = {
            "SET": 0,       # Assignment (Base Layer)
            "CALC": 1,      # Calculation (Operational Layer)
            "IF": 2,        # Conditional (Decision Layer)
            "LOOP": 3,      # Iterative (Temporal Layer)
            "RETURN": 4     # Closure (Law Layer)
        }

    def verify_program_topology(self, instructions):
        """
        Routes the syntax through the Torus.
        Checks for H^2 Parity Breaks (Logical Conflicts).
        """
        print(f"[*] Compiling {len(instructions)} syntax-tori instructions...")

        current_fiber = 0
        execution_path = []

        for i, instr in enumerate(instructions):
            primitive = instr.get("type").upper()
            target_fiber = self.SYNTAX_FIBERS.get(primitive)

            if target_fiber is None:
                 print(f"  [-] H^2 PARITY HALT: Unknown primitive '{primitive}' at instruction {i}")
                 return False, f"SYNTAX_ERROR: {primitive}"

            # Compilation check: Parity Harmony
            # Sequential logic should generally move up the fibers, unless looping back
            # A jump back to fiber 0 (SET) from fiber 4 (RETURN) is an H^2 obstruction
            if target_fiber < current_fiber and primitive != "LOOP":
                 print(f"  [-] H^2 OBSTRUCTION: Syntax jump backwards from {current_fiber} to {target_fiber}")
                 return False, f"LOGIC_BREAK: Jump back from {current_fiber} to {target_fiber}"

            # Map to Coordinate
            coord = self.lt._generate_coord(primitive, target_fiber)
            execution_path.append(coord)
            current_fiber = target_fiber

        # Final Closure Check
        if current_fiber != 4:
            print(f"  [-] CYCLE_UNCLOSED: Missing RETURN fiber at program end.")
            return False, "CYCLE_UNCLOSED: Missing RETURN"

        print(f"  [+] PARITY_HARMONY: Program is mathematically stable. No logical wounds.")
        return True, execution_path

if __name__ == "__main__":
    comp = TopologicalCompiler()

    # 1. Valid Program
    prog = [{"type": "SET"}, {"type": "CALC"}, {"type": "RETURN"}]
    ok, res = comp.verify_program_topology(prog)
    print(f"[*] Program 1 Valid: {ok}")

    # 2. Buggy Program
    prog2 = [{"type": "RETURN"}, {"type": "SET"}]
    ok2, res2 = comp.verify_program_topology(prog2)
    print(f"[*] Program 2 Valid: {ok2}")
