from tgi.tgi_agent_os import AgentOS

def test_os():
    os_sys = AgentOS(m=101, k=3)

    print("\n--- Test 1: Valid Email ---")
    email_params = {"recipient": "alice@fso.ai", "subject": "Project X", "body": "Algebraic Mind is live."}
    res = os_sys.process_command("user send data fast execute", params=email_params)
    print(res)

    print("\n--- Test 2: Incomplete Params ---")
    res2 = os_sys.process_command("user send data", params={"recipient": "bob@fso.ai"})
    print(res2)

    print("\n--- Test 3: Unknown Action ---")
    res3 = os_sys.process_command("user calculate data")
    print(res3)

if __name__ == "__main__":
    test_os()
