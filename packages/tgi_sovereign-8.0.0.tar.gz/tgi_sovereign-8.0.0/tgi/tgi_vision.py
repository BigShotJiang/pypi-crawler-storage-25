import time
import hashlib

class AlgebraicComputerVision:
    """
    Project: ELECTRICITY (Layer 3 - The Algebraic Eye)
    Topological Computer Vision without Neural Networks.
    Detects edges via Parity Gradients and recognizes shapes via
    Hamiltonian perimeter signatures.
    """
    def __init__(self, m_width=256, m_height=256):
        self.m_w = m_width
        self.m_h = m_height
        self.visual_manifold = {} # {(x, y): fiber_s}
        print(f"[{time.strftime('%H:%M:%S')} ALGIERS] Algebraic Eye Booted. Retina Grid: Z_{self.m_w}x{self.m_h}")

    def ingest_image(self, pixel_grid):
        """
        Converts 2D pixel array into the visual manifold.
        0 = Empty space (Fiber 0), 1+ = Object (Fiber s)
        """
        self.visual_manifold = {}
        for y, row in enumerate(pixel_grid):
            if y >= self.m_h: break
            for x, v in enumerate(row):
                if x >= self.m_w: break
                if v > 0:
                    self.visual_manifold[(x, y)] = v

    def extract_topological_edges(self, threshold=128):
        """
        Edge Detection via Parity Gradients.
        O(nodes) complexity. Detects local parity anomalies.
        """
        edges = set()
        for (x, y), fiber in self.visual_manifold.items():
            if fiber < threshold: continue

            # Check neighbors on the Torus
            neighbors = [
                ((x + 1) % self.m_w, y),
                ((x - 1) % self.m_w, y),
                (x, (y + 1) % self.m_h),
                (x, (y - 1) % self.m_h)
            ]

            is_edge = False
            for nx, ny in neighbors:
                neighbor_fiber = self.visual_manifold.get((nx, ny), 0)
                if neighbor_fiber < threshold:
                    is_edge = True
                    break

            if is_edge:
                edges.add((x, y))

        return edges

    def generate_shape_signature(self, edge_coordinates):
        """
        The Hamiltonian Perimeter Trace.
        Calculates a rotation and translation invariant geometric signature.
        """
        if not edge_coordinates:
            return "NULL_SHAPE"

        coords = list(edge_coordinates)
        if not coords: return "NULL_SHAPE"

        # To ensure translation invariance, we normalize coordinates to (0,0)
        min_x = min(p[0] for p in coords)
        min_y = min(p[1] for p in coords)
        normalized = sorted([(p[0] - min_x, p[1] - min_y) for p in coords])

        # Nearest-neighbor walk for continuous perimeter trace
        start = normalized[0]
        current = start
        remaining = set(normalized)
        remaining.remove(start)

        walk = [start]
        while remaining:
            # Find closest neighbor. In a grid, these are distance 1 or sqrt(2)
            next_p = min(remaining, key=lambda p: (p[0]-current[0])**2 + (p[1]-current[1])**2)
            walk.append(next_p)
            remaining.remove(next_p)
            current = next_p

        # Geometric derivative sequence (vectors between consecutive points)
        vectors = []
        for i in range(len(walk)):
            p1 = walk[i]
            p2 = walk[(i + 1) % len(walk)]
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]
            vectors.append(f"{dx},{dy}")

        raw_sig = "|".join(vectors).encode('utf-8')
        return hashlib.md5(raw_sig).hexdigest()[:8].upper()

if __name__ == "__main__":
    cv = AlgebraicComputerVision(10, 10)
    img = [[0]*10 for _ in range(10)]
    for y in range(2, 6):
        for x in range(2, 6): img[y][x] = 255
    cv.ingest_image(img)
    edges = cv.extract_topological_edges()
    sig = cv.generate_shape_signature(edges)
    print(f"[*] Signature: {sig} | Edges: {len(edges)}")
