import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import math
import time
from .theorems import law_of_dimensional_parity_harmony

class TGICognitiveKernel:
    """
    Topological General Intelligence (TGI) - Deterministic Inference Engine v2.8.
    The Algebraic Mind with Multi-Manifold Support.
    """
    def __init__(self, m=3, k=3):
        self.m = m
        self.k = k
        self.nb_density = None
        self.moduli_space_size = None
        self.b_vectors = None
        self.active_manifold = "base"
        self.manifolds = {"base": (m, k)}

    def switch_manifold(self, manifold_name, m=None, k=None):
        if manifold_name in self.manifolds:
            self.m, self.k = self.manifolds[manifold_name]
        elif m and k:
            self.manifolds[manifold_name] = (m, k)
            self.m, self.k = m, k
        self.b_vectors = None
        self.active_manifold = manifold_name
        return f"SWITCHED: Now reasoning on '{manifold_name}' manifold (Z_{self.m}^{self.k})."

    def layer_1_symbolic_parser(self, problem_type, nodes, agents):
        if problem_type == "semantic_coordinate":
            self.m, self.k = nodes, agents
            return f"PARSED TLM: Semantic torus defined with {self.m} concepts across {self.k} grammatical axes."
        if problem_type in ["knowledge_graph", "logic_syllogism"]:
            self.m = len(nodes) if isinstance(nodes, list) else nodes
            self.k = len(agents) if isinstance(agents, list) else agents
            return f"PARSED GRAPH: Mapping to Z_{self.m}^{self.k}." if problem_type == "knowledge_graph" else f"PARSED SYLLOGISM: Mapping to Z_{self.m}^{self.k}."
        self.m, self.k = nodes, agents
        return f"PARSED: Problem mapped to Z_{self.m}^{self.k} Topology."

    def knowledge_manifold_ingestion(self, semantic_data):
        if not semantic_data: return tuple([0]*self.k)
        context = []
        for key, value in semantic_data.items():
            coord = (hash(str(key)) + hash(str(value))) % self.m
            context.append(coord)
        if len(context) < self.k:
            context += [sum(context) % self.m] * (self.k - len(context))
        else:
            context = context[:self.k]
        return tuple(context)

    def layer_2_knowledge_base(self):
        phi_m = sum(1 for i in range(1, self.m + 1) if math.gcd(i, self.m) == 1)
        self.nb_density = (self.m ** (self.m - 1)) * phi_m
        self.moduli_space_size = phi_m * (self.nb_density ** (self.k - 1))
        self.b_vectors = []
        for c in range(self.k):
            b = [0] * self.m
            for s in range(self.m):
                b[s] = (1 if s == (c % self.m) else 0)
            if c == self.k - 1:
                current_sum = sum(b[:-1])
                b[-1] = (2 - current_sum) % self.m if self.m % 2 != 0 else (1 - current_sum) % self.m
            self.b_vectors.append(tuple(b))
        return self.nb_density, self.moduli_space_size

    def layer_3_parity_verifier(self):
        solvable, msg = law_of_dimensional_parity_harmony(self.m, self.k)
        if not solvable:
            new_k = self.k + 1
            return False, f"PARADOX_DETECTED: H^2 Parity Obstruction. (Suggesting k={new_k})", new_k
        return True, "PARITY_HARMONY: Truth-solvable configuration.", self.k

    def layer_4_spike_synapse(self, current_context):
        if not self.b_vectors: self.layer_2_knowledge_base()
        s = sum(current_context) % self.m
        deduction = tuple(self.b_vectors[dim][s] for dim in range(self.k))
        return deduction

    def layer_5_silicon_compiler(self):
        from gen_hdl import generate_verilog
        return generate_verilog(self.m, self.k)

    def generate_thought_stream(self, start_context, steps=10):
        if not self.b_vectors: self.layer_2_knowledge_base()
        stream = [start_context]
        curr = list(start_context)
        if len(curr) < self.k: curr += [0] * (self.k - len(curr))
        for _ in range(steps):
            s = sum(curr) % self.m
            shift = [self.b_vectors[dim][s] for dim in range(self.k)]
            curr = [(curr[i] + shift[i]) % self.m for i in range(self.k)]
            stream.append(tuple(curr))
        return stream

    def trace_cognitive_pathway(self, start_context, steps=100):
        return self.generate_thought_stream(start_context, steps=steps)

    def execute_thought_loop(self, context_vector):
        if isinstance(context_vector, dict):
            context_vector = self.knowledge_manifold_ingestion(context_vector)
        valid, msg, suggested_k = self.layer_3_parity_verifier()
        status = "CLOSED"
        elevation_log = None
        if not valid:
            if suggested_k != self.k:
                elevation_log = f"REVOLVED: {msg} (Lifting k={self.k} -> {suggested_k})"
                self.k = suggested_k
                self.b_vectors = None
                status = "RESOLVED_VIA_ELEVATION"
            else: return {"state": "ABORTED", "reason": msg}
        nb, moduli = self.layer_2_knowledge_base()
        stack, global_state = self._recursive_ses_synthesis(context_vector)
        s_context = [(val + global_state) % self.m for val in context_vector[:self.k]]
        if len(s_context) < self.k: s_context += [global_state] * (self.k - len(s_context))
        deduction = self.layer_4_spike_synapse(s_context)
        return {
            "state": status, "solution_density": nb, "moduli_space": moduli,
            "abstractions": stack, "global_state": global_state,
            "deduction": deduction, "elevation_log": elevation_log
        }

    def _recursive_ses_synthesis(self, context_vector):
        levels = int(math.log2(len(context_vector))) + 1 if len(context_vector) > 0 else 1
        current_g = list(context_vector)
        thought_stack = []
        for level in range(levels):
            if not current_g: break
            abstraction = sum(current_g) % self.m
            thought_stack.append(abstraction)
            if len(current_g) > 1:
                half = len(current_g) // 2
                new_g = [(current_g[i] + abstraction) % self.m for i in range(half)]
                current_g = new_g
            else: break
        return thought_stack, sum(thought_stack) % self.m

ScalableTGICore = TGICognitiveKernel
