import time
from tgi.tgi_agent_os import AgentOS

def run_sovereign_db_demo():
    print("\n" + "#"*80)
    print(" PROJECT ELECTRICITY: SOVEREIGN DATA DEMO (PARITY CORE)")
    print("#"*80)

    # 1. INITIALIZE OS
    os_sys = AgentOS(m=101, k=3)

    # 2. STORE RECORDS (O(1) Insertion)
    print("\n--- [Layer 1] Sovereign Data Storage ---")
    data_points = [
        {"key": "intel_01", "payload": "Coordinates for Node A: (4, 7, 90)"},
        {"key": "intel_02", "payload": "Coordinates for Node B: (92, 76, 35)"},
        {"key": "system_policy", "payload": "Hamiltonian_Closure_Enabled"}
    ]

    for dp in data_points:
        res = os_sys.process_command("user store record", params=dp)
        print(res)

    # 3. O(1) RETRIEVAL JUMP
    print("\n--- [Layer 1] Deterministic Algebraic Retrieval ---")
    keys_to_fetch = ["intel_01", "system_policy"]
    for k in keys_to_fetch:
        t0 = time.perf_counter()
        res = os_sys.process_command("user retrieve record", params={"key": k})
        dt = (time.perf_counter() - t0) * 1e6
        print(f"{res} (Latency: {dt:.2f}µs)")

    # 4. OBSTRUCTION & ELEVATION
    print("\n--- [Self-Healing] Topological Data Recovery ---")
    key = "intel_02"
    print(f"[*] Simulating partition failure (H^2 Obstruction) for '{key}'...")
    os_sys.db.obstruct_data(key)

    # Try retrieve via standard OS command
    res = os_sys.process_command("user retrieve record", params={"key": key})
    print(f"[*] Standard Retrieval: {res}")

    # Recover via Dimension Elevation
    print(f"[*] Attempting Dimension Elevation recovery...")
    recovered = os_sys.db.elevate_retrieval(key)
    print(f"[*] Recovery Success: '{recovered}'")

    print("\n" + "="*80)
    print(" CONCLUSION: DATA IS GEOMETRY. SOVEREIGN RETRIEVAL IS O(1).")
    print("="*80)

if __name__ == "__main__":
    run_sovereign_db_demo()
