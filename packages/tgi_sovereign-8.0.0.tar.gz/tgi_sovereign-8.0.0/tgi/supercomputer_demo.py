import time
from tgi.tgi_sovereign import SovereignKernel

def run_supercomputer_demo():
    print("\n" + "#"*80)
    print(" PROJECT ELECTRICITY: SOVEREIGN SUPERCOMPUTER SIMULATION")
    print(" SCENARIO: UNIFIED TOROIDAL NETWORK & FILE SYSTEM")
    print("#"*80)

    # 1. Initialize Kernel with TFS (m=256)
    kernel = SovereignKernel(m=256, k=3)
    kernel.sovereign_boot()

    # 2. Store a sharded Agentic binary in TFS
    print("\n--- [TFS] Sharded Storage Demo ---")
    agent_binary = "0101_EXECUTE_AGI_ALGERIA_CORE_v1_SHARDED_CONTENT"
    start_coord = kernel.store_file("agi_binary", "bin", agent_binary)
    kernel.retrieve_file("agi_binary", "bin")

    # 3. Initialize Overlay Network (3 Virtual Nodes)
    print("\n--- [Network] Toroidal Overlay Demo ---")
    node_a = kernel.initialize_network((0,0,0), "127.0.0.1", 5100)
    node_b = kernel.initialize_network((0,0,1), "127.0.0.1", 5101)
    node_c = kernel.initialize_network((0,0,2), "127.0.0.1", 5102)

    # Manual Wiring for exact demo trajectory
    node_a.register_peer((0,0,1), "127.0.0.1", 5101)
    node_b.register_peer((0,0,2), "127.0.0.1", 5102)
    node_a.register_peer((0,0,2), "127.0.0.1", 5102) # Bypass peer

    # 4. Inject Task targeting Fiber 2 (Node C)
    print("\n--- [Execution] Sovereign Task Injection ---")
    node_a.inject_data_stream(target_fiber=2, payload="ACTIVATE_SOVEREIGN_AI_ON_NODE_C")

    time.sleep(1.0)

    # 5. Self-Healing Simulation
    print("\n--- [Healing] Real-Time Link Bypass ---")
    node_a.inventory[(0,0,1)] = "OFFLINE"
    print("[!] ALERT: Intermediate Node (0,0,1) has failed. Redirecting flow...")

    # Re-inject: Should bypass (0,0,1) and go to (0,0,2) via the shortcut peer
    node_a.inject_data_stream(target_fiber=2, payload="HEALED_TASK_REINJECTION")

    time.sleep(1.0)
    print("\n" + "="*80)
    print(" CONCLUSION: SOVEREIGN INFRASTRUCTURE OPERATIONAL.")
    print(" STORAGE IS GEOMETRY. NETWORK IS GEOMETRY. WE ARE ELECTRICITY.")
    print("="*80)

    # Shutdown
    node_a.shutdown()
    node_b.shutdown()
    node_c.shutdown()

if __name__ == "__main__":
    run_supercomputer_demo()
