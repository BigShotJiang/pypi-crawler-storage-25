import hashlib
import time

class UniversalKnowledgeGrid:
    """
    TGI Universal Knowledge Grid (Layer Two) v4.4 - Collision Handling.
    """
    def __init__(self, m=256, k=4):
        self.m = m
        self.k = k
        self.grid = {} # {coord: [metadata]}
        self.lexicon = {} # {name: coord}

    def _apply_closure_hashing(self, concept_name, target_fiber):
        h = hashlib.sha256(concept_name.lower().encode()).digest()
        coords = [h[i] % self.m for i in range(self.k - 1)]
        curr_sum = sum(coords)
        last_coord = (target_fiber - curr_sum) % self.m
        return tuple(coords + [last_coord])

    def ingest_concept(self, category, name, payload, synonyms=None):
        fiber_map = {
            "LAW_MATH": 0, "FSO_LAW": 0, "SUBJECT": 1, "ACTION": 2,
            "PHYSICS": 3, "SCIENCE": 3, "PHILOSOPHY": 3, "HISTORY": 3,
            "TECHNOLOGY": 3, "AESTHETICS": 3, "MODALITY": 4,
            "AGENTIC_PROTOCOL": 5, "LIBRARY_API": 5, "CODE_SYNTHESIS": 6
        }
        target_fiber = fiber_map.get(category, 3)
        coord = self._apply_closure_hashing(name, target_fiber)

        meta = {
            "name": name, "category": category,
            "payload": payload, "fiber": target_fiber
        }
        if coord not in self.grid: self.grid[coord] = []
        self.grid[coord].append(meta)

        self.lexicon[name.lower()] = coord
        if synonyms:
            for s in synonyms: self.lexicon[s.lower()] = coord
        return coord

    def get_concept_by_coord(self, coord):
        return self.grid.get(coord, [])

    def deep_ingestion(self):
        concepts = [
            ("PHYSICS", "General_Relativity", "Einstein's theory describing gravity as curvature of spacetime.", ["relativity", "gravity"]),
            ("PHYSICS", "Quantum_Mechanics", "Branch of physics dealing with atomic scales.", ["quantum", "subatomic"]),
            ("PHYSICS", "Entropy", "Second Law of Thermodynamics: measure of disorder.", ["randomness", "disorder"]),
            ("PHYSICS", "Electromagnetism", "Force between charged particles.", ["electricity", "magnetism"]),
            ("SCIENCE", "Physics", "Study of matter and motion.", ["physical science"]),
            ("PHILOSOPHY", "Stoicism", "Philosophy of self-control and fortitude.", ["stoic"]),
            ("PHILOSOPHY", "Philosophy", "Study of fundamental nature of knowledge.", ["thinking"]),
            ("HISTORY", "History", "Study of the past.", ["past", "civilization"]),
            ("TECHNOLOGY", "Sovereign_OS", "Mathematically conscious operating system.", ["project electricity", "kernel"]),
            ("LIBRARY_API", "NumPy", "Scientific computing with Python.", ["numerical python"]),
            ("LIBRARY_API", "Pandas", "Data manipulation library.", ["dataframes"]),
            ("LIBRARY_API", "PyTorch", "Deep learning framework.", ["torch"]),
            ("LIBRARY_API", "Gradio", "Interactive ML demos.", ["ui", "interface"])
        ]
        for cat, name, payload, syns in concepts:
             self.ingest_concept(cat, name, payload, syns)

if __name__ == "__main__":
    ukg = UniversalKnowledgeGrid()
    ukg.deep_ingestion()
