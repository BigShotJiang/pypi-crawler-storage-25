import math
from tgi.tgi_dictionary import LexicalTopology
from tgi.tgi import TGICognitiveKernel

class SemanticRouter:
    """
    Semantic Router v2.0 (Topological Path Routing).
    Routes logical paths between concepts using Hamiltonian segments.
    """
    def __init__(self, m=5, k=3):
        self.m = m
        self.k = k
        self.lt = LexicalTopology(m, k)
        self.kernel = TGICognitiveKernel(m, k)

    def find_semantic_path(self, start_word, end_word):
        """
        Determines the optimal sequence of coordinates between two concepts.
        """
        start_data = self.lt.get_word_data(start_word)
        end_data = self.lt.get_word_data(end_word)

        if not start_data or not end_data:
            return None, "LEXICON_ERROR"

        curr = list(start_data["coord"])
        goal = list(end_data["coord"])
        path = [tuple(curr)]

        # Pre-calc basis
        self.kernel.layer_2_knowledge_base()
        b_vecs = self.kernel.b_vectors

        # We route using the O(1) synapse towards the goal
        max_steps = self.m * 2
        for _ in range(max_steps):
            if curr == goal: break

            s = sum(curr) % self.m
            best_dim = 0
            min_dist = float('inf')

            for d in range(self.k):
                # Try basis step
                shift = b_vecs[d][s]
                temp = list(curr)
                temp[d] = (temp[d] + shift) % self.m

                # Toroidal Manhattan distance
                dist = sum(min(abs(temp[i] - goal[i]), self.m - abs(temp[i] - goal[i])) for i in range(self.k))
                if dist < min_dist:
                    min_dist = dist
                    best_dim = d

            # Apply best move
            curr[best_dim] = (curr[best_dim] + b_vecs[best_dim][s]) % self.m
            path.append(tuple(curr))

        return path, "SUCCESS"

    def map_path_to_words(self, path):
        """Translates coordinate path to semantic concepts."""
        words = []
        for coord in path:
            w = self.lt.get_word_at_coord(coord)
            words.append(w if w else f"CONCEPT({coord})")
        return words
