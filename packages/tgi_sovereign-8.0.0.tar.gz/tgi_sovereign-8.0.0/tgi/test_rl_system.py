import unittest
from .tgi_rl import TopologicalRLEngine

class TestTopologicalRL(unittest.TestCase):
    def setUp(self):
        self.m = 10
        self.rl = TopologicalRLEngine(m=self.m, k=3)

    def test_zero_training_optimization(self):
        # 1. Simulate High Cost area (Friction)
        # We put a friction node at (1,0,0) which is fiber 1
        friction_node = (1, 0, 0)
        self.rl.set_physical_cost(friction_node, 1000)

        # 2. Initial Run
        success, path1, cost1 = self.rl.route_and_measure((0,0,0), 2)
        # Path: (0,0,0) -> (1,0,0) [Fiber 1] -> ...
        self.assertIn(friction_node, path1)

        # 3. Optimize (Mutate Topology of Fiber 0)
        self.rl.mutate_topology(0)

        # 4. Second Run
        success2, path2, cost2 = self.rl.route_and_measure((0,0,0), 2)

        # 5. Verify Friction Bypass
        self.assertNotIn(friction_node, path2)
        self.assertTrue(cost2 < cost1)

        improvement = ((cost1 - cost2) / cost1) * 100
        print(f"[*] FSO-RL Improvement: {improvement:.2f}%")
        self.assertTrue(improvement > 90)

if __name__ == "__main__":
    unittest.main()
