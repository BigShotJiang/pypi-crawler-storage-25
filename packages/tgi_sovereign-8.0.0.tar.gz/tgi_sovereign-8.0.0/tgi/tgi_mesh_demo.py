import time
from .tgi_agent_os import AgentOS

def run_decentralized_mesh_demo():
    print("\n" + "#"*80)
    print(" PROJECT ELECTRICITY: DECENTRALIZED TGI MESH SIMULATION")
    print(" SCENARIO: NODE_1 GOSSIPS KNOWLEDGE -> NODE_2 -> NODE_3")
    print("#"*80)

    # 1. Initialize 3 Nodes in a Toroidal Chain (0,0,0,0) -> (1,0,0,0) -> (2,0,0,0)
    print("\n[*] Initializing Mesh Nodes...")
    node_1 = AgentOS(m=256, k=4, node_id=(0,0,0,0), port=7000)
    node_2 = AgentOS(m=256, k=4, node_id=(1,0,0,0), port=7001)
    node_3 = AgentOS(m=256, k=4, node_id=(2,0,0,0), port=7002)

    time.sleep(1) # Ensure listeners are ready

    # 2. Map Peers (Chain Topology)
    print("\n[*] Connecting Nodes via Geometric Topology...")
    node_1.mesh.register_peer((1,0,0,0), "127.0.0.1", 7001)
    node_2.mesh.register_peer((2,0,0,0), "127.0.0.1", 7002)
    node_2.mesh.register_peer((0,0,0,0), "127.0.0.1", 7000)
    node_3.mesh.register_peer((1,0,0,0), "127.0.0.1", 7001)

    time.sleep(0.5)

    # 3. Geometric Gossip Test
    print("\n--- [Scenario A] Knowledge Gossip (Node 1 -> Mesh) ---")
    node_1.mesh.geometric_gossip("LAW_MATH", "Geometric_Mesh_Integrity", "Mesh stability is proportional to Hamiltonian coverage.")

    time.sleep(2) # Wait for gossip propagation across multiple hops (Node 1 -> Node 2 -> Node 3)

    print("\n[*] Verifying Sync across Mesh...")
    for n in [node_1, node_2, node_3]:
         grid = n.mesh.knowledge_cache
         is_synced = any(c['name'] == "Geometric_Mesh_Integrity" for c in grid.values())
         print(f"  [+] Node {n.node_id} Synced? {is_synced}")

    # 4. Mesh Command Routing Test
    print("\n--- [Scenario B] Remote Command Routing (Node 1 -> Node 3 via Node 2) ---")
    node_1.process_command("user innovate", params={
        "target_node": (2,0,0,0), # Task intended for Node 3
        "target_fiber": 0,
        "concept1": "Algebraic_Eye",
        "concept2": "Geometric_Gossip"
    })

    time.sleep(2) # Wait for hops

    print("\n" + "="*80)
    print(" CONCLUSION: DECENTRALIZED MESH SUCCESSFUL.")
    print(" TGI COORDINATES ACT AS DIRECT ROUTING ADDRESSES.")
    print("="*80)

    # Cleanup
    node_1.shutdown()
    node_2.shutdown()
    node_3.shutdown()

if __name__ == "__main__":
    run_decentralized_mesh_demo()
