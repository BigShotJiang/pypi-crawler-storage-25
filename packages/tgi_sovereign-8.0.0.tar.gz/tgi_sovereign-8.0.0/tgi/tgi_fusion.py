import math
from .tgi import TGICognitiveKernel
from .theorems import fusion_confinement_invariant

class FusionSim:
    """
    FSO Fusion Simulation (The Plasma Router).
    Uses the Spike-Function to generate space-filling field lines.
    """
    def __init__(self, m=101):
        self.m = m
        self.kernel = TGICognitiveKernel(m=m, k=3)

    def generate_field_line(self, start_pos=(0, 0, 0), steps=None):
        if steps is None:
            steps = self.m ** 3

        r_tuple = (1, 1, 1)
        if math.gcd(3, self.m) != 1:
            r_tuple = (1, 2, 1)

        is_stable, msg = fusion_confinement_invariant(self.m, r_tuple)

        self.kernel.b_vectors = []
        for c in range(self.kernel.k):
            b = [r_tuple[c]] * self.m
            if c == self.kernel.k - 1:
                b[-1] = (r_tuple[c] + 1) % self.m
            self.kernel.b_vectors.append(tuple(b))

        trajectory = self.kernel.trace_cognitive_pathway(start_pos, steps=steps)
        return trajectory, f"STABLE: {msg}"

    def calculate_confinement_density(self, trajectory):
        if not trajectory: return 0.0
        unique_nodes = len(set(trajectory))
        total_nodes = self.m ** 3
        coverage = (unique_nodes / total_nodes) * 100
        return coverage

if __name__ == "__main__":
    sim = FusionSim(m=11)
    line, msg = sim.generate_field_line()
    print(f"[*] Plasma Confinement Result: {msg}")
