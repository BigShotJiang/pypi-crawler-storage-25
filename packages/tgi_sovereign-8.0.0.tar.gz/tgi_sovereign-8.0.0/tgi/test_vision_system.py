import unittest
import time
from .tgi_vision import AlgebraicComputerVision
from .tgi_motion import MotionTracker
from .tgi_sovereign import SovereignKernel

class TestTopologicalVision(unittest.TestCase):
    def setUp(self):
        self.m = 20
        self.cv = AlgebraicComputerVision(m_width=self.m, m_height=self.m)
        self.tracker = MotionTracker(m=self.m)

    def create_rect(self, x_start, y_start, width, height):
        grid = [[0]*self.m for _ in range(self.m)]
        for y in range(y_start, y_start + height):
            for x in range(x_start, x_start + width):
                if 0 <= x < self.m and 0 <= y < self.m:
                    grid[y][x] = 255
        return grid

    def test_translation_invariance(self):
        # Square at (2,2)
        grid1 = self.create_rect(2, 2, 4, 4)
        self.cv.ingest_image(grid1)
        edges1 = self.cv.extract_topological_edges()
        sig1 = self.cv.generate_shape_signature(edges1)

        # Same Square at (10,10)
        grid2 = self.create_rect(10, 10, 4, 4)
        self.cv.ingest_image(grid2)
        edges2 = self.cv.extract_topological_edges()
        sig2 = self.cv.generate_shape_signature(edges2)

        self.assertEqual(sig1, sig2, "Signatures should be identical for translated shapes.")

    def test_motion_prediction(self):
        sig = "SQUARE_SIG"
        # Frame 1: centroid at (2.5, 2.5)
        edges1 = [(2,2), (2,3), (3,2), (3,3)]
        self.tracker.update_shape_position(sig, edges1)

        # Frame 2: centroid at (4.5, 4.5) - Velocity is +2, +2
        edges2 = [(4,4), (4,5), (5,4), (5,5)]
        self.tracker.update_shape_position(sig, edges2)

        predicted = self.tracker.predict_next_position(sig)
        # Expected: (4.5+2, 4.5+2) = (6.5, 6.5)
        self.assertEqual(predicted, (6.5, 6.5))

    def test_sovereign_integration(self):
        kernel = SovereignKernel(m=self.m, k=4)
        grid = self.create_rect(5, 5, 3, 3)
        sig, edges = kernel.see_and_track(grid)

        self.assertIsNotNone(sig)
        self.assertTrue(len(edges) > 0)

        # Move it
        grid2 = self.create_rect(6, 6, 3, 3)
        sig2, edges2 = kernel.see_and_track(grid2)

        self.assertEqual(sig, sig2)

        pred = kernel.motion.predict_next_position(sig)
        self.assertIsNotNone(pred)

if __name__ == "__main__":
    unittest.main()
