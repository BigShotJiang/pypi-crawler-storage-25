"""Filesystem locations for config, data, and the SQLite database.

Everything is overridable with the ``WYRD_HOME`` environment variable, which
is handy for development and tests: when set, config and data both live under
``$WYRD_HOME``.
"""

from __future__ import annotations

import os
from pathlib import Path

import platformdirs

__all__ = [
    "config_dir",
    "config_file",
    "data_dir",
    "db_file",
    "research_dir",
]

_APP = "wyrd"


def _home_override() -> Path | None:
    raw = os.environ.get("WYRD_HOME")
    return Path(raw).expanduser() if raw else None


def config_dir() -> Path:
    override = _home_override()
    path = override / "config" if override else Path(platformdirs.user_config_dir(_APP))
    path.mkdir(parents=True, exist_ok=True)
    return path


def data_dir() -> Path:
    override = _home_override()
    path = override / "data" if override else Path(platformdirs.user_data_dir(_APP))
    path.mkdir(parents=True, exist_ok=True)
    return path


def config_file() -> Path:
    return config_dir() / "config.toml"


def db_file() -> Path:
    return data_dir() / "wyrd.db"


def research_dir() -> Path:
    """Default folder for generated research papers (overridable in config.toml)."""
    path = data_dir() / "research"
    path.mkdir(parents=True, exist_ok=True)
    return path
