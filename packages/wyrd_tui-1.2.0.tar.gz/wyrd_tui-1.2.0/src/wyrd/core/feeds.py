"""HTTP + ``feedparser`` verification for candidate RSS/Atom feed URLs.

Used by the setup wizard's "✨ Suggest feeds & keywords with Claude" button
to drop dead-or-empty URLs before showing them to the user — Claude will
sometimes suggest feeds from 2014 that returned 200 OK back then and now
404, or that parse but have no entries. We want only working feeds to land
in the TextArea.

The verifier is intentionally narrow: we don't check recency (some good
feeds publish quarterly), don't check content-type (publishers serve feeds
with all kinds of MIME labels), don't second-guess the URL shape. We only
ask: does the URL fetch, does feedparser get at least one entry out of the
body? If yes, keep it; otherwise drop. ``feedparser`` is forgiving — it
returns entries even when the XML has issues — so the entry-count gate is
a real "this is a feed someone could subscribe to" signal.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass

import feedparser
import httpx

from wyrd.core.http import USER_AGENT

__all__ = [
    "VerifiedFeed",
    "verify_feed_urls",
]

log = logging.getLogger(__name__)

_VERIFY_TIMEOUT = 15.0
_VERIFY_CONCURRENCY = 8


@dataclass(frozen=True, slots=True)
class VerifiedFeed:
    """One feed URL that fetched and parsed cleanly with at least one entry."""

    url: str
    title: str | None  # feed's own <title>, when feedparser surfaces it
    entry_count: int


async def verify_feed_urls(
    urls: list[str], *, timeout: float = _VERIFY_TIMEOUT
) -> list[VerifiedFeed]:
    """Concurrently fetch + parse *urls*; return the survivors.

    A "survivor" is a URL whose response feedparser turns into at least one
    entry. Order of the returned list matches the input order so callers can
    diff "what I asked for" vs "what came back".
    """
    if not urls:
        return []
    sem = asyncio.Semaphore(_VERIFY_CONCURRENCY)
    async with httpx.AsyncClient(
        timeout=timeout,
        follow_redirects=True,
        headers={"User-Agent": USER_AGENT},
    ) as client:
        results = await asyncio.gather(
            *(_verify_one(client, sem, url) for url in urls),
            return_exceptions=True,
        )
    out: list[VerifiedFeed] = []
    for url, result in zip(urls, results, strict=True):
        if isinstance(result, BaseException):
            log.info("feed verify failed for %s: %s", url, result)
            continue
        if result is not None:
            out.append(result)
    return out


async def _verify_one(
    client: httpx.AsyncClient, sem: asyncio.Semaphore, url: str
) -> VerifiedFeed | None:
    if not url.startswith(("http://", "https://")):
        return None
    async with sem:
        try:
            resp = await client.get(url)
        except httpx.HTTPError as exc:
            log.info("feed verify HTTP error for %s: %s", url, exc)
            return None
    if resp.status_code >= 400:
        return None
    body = resp.content
    # ``feedparser`` is synchronous and CPU-bound on large XML — run it off
    # the event loop so we don't stall other verification tasks.
    parsed = await asyncio.to_thread(feedparser.parse, body)
    entries = getattr(parsed, "entries", []) or []
    if not entries:
        return None
    feed_meta = getattr(parsed, "feed", {}) or {}
    title = (feed_meta.get("title") if isinstance(feed_meta, dict) else None) or None
    return VerifiedFeed(url=url, title=title, entry_count=len(entries))
