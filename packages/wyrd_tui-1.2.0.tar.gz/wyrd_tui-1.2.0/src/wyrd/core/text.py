"""Small text-shaping helpers: a one-liner truncator and a slug builder.

These used to live as private ``_shorten`` / ``_short`` / ``slugify`` copies in
half the screens and modules. They are pure functions and the contract is
identical across callers, so they belong in one place.
"""

from __future__ import annotations

import re

__all__ = [
    "shorten",
    "slugify",
]

_SLUG_RE = re.compile(r"[^a-z0-9]+")


def shorten(text: str, limit: int = 72) -> str:
    """Collapse whitespace and truncate to *limit* chars with an ellipsis."""
    text = " ".join(str(text).split())
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def slugify(text: str, *, max_len: int = 60, fallback: str = "untitled") -> str:
    """Turn arbitrary text into a filesystem-safe slug.

    Lowercases, collapses runs of non-alphanumerics into single dashes, trims
    dashes from either end, and caps at *max_len*. Falls back to *fallback*
    when the input is empty, whitespace-only, or all punctuation — and when
    truncation leaves nothing usable.
    """
    s = (text or "").strip().lower()
    if not s:
        return fallback
    slug = _SLUG_RE.sub("-", s).strip("-")
    if not slug:
        return fallback
    if len(slug) > max_len:
        slug = slug[:max_len].rstrip("-") or fallback
    return slug
