"""Thin data-access layer over the SQLite schema in :mod:`wyrd.core.db`.

Keeps all the SQL in one place; the rest of the app calls functions, never
``conn.execute`` directly. Timestamps are stored as ISO-8601 UTC strings.

Concepts:

- ``items.state ∈ {"new", "seen", "liked", "dismissed"}`` — set by the user
  via the feed pane. :data:`FEED_STATES` is the subset shown in the feed
  (``new`` + ``seen``); ``liked`` items move into Saved, ``dismissed`` items
  fall off the list.
- ``saved`` is a 1-to-1 extension of an ``items`` row, keyed by ``item_id``;
  ``saved.full_text`` is the article body lazily fetched by the extraction
  worker.
- ``items_fts`` is a contentless FTS5 index managed by triggers; queries go
  through :func:`search_feed` / :func:`search_saved`, which quote-escape the
  user's input before handing it to MATCH.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import UTC, datetime

from wyrd.core.sources import ContentItem

__all__ = [
    "FEED_STATES",
    "add_feed_suggestion",
    "delete_research",
    "dismiss_feed_suggestion",
    "dismiss_item",
    "ensure_source",
    "finish_run",
    "get_extraction",
    "get_item",
    "get_meta",
    "get_research",
    "get_saved",
    "is_saved",
    "like_item",
    "list_feed_items",
    "list_feed_suggestions",
    "list_research",
    "list_saved_items",
    "mark_source_run",
    "parse_tags",
    "recent_runs",
    "record_research",
    "save_extraction",
    "save_extraction_summary",
    "search_feed",
    "search_saved",
    "set_item_state",
    "set_meta",
    "start_run",
    "unsave_item",
    "update_saved",
    "upsert_item",
]

FEED_STATES = ("new", "seen")


# --- meta -------------------------------------------------------------------
#
# Generic key/value table used for schema_version (managed by ``db.py``) and a
# handful of "remember this user decision" flags — e.g. the one-time discovery
# consent. Values are strings; callers serialise richer shapes themselves.


def get_meta(conn: sqlite3.Connection, key: str) -> str | None:
    row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return row[0] if row is not None else None


def set_meta(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        "INSERT INTO meta(key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _last_insert_id(cur: sqlite3.Cursor) -> int:
    rowid = cur.lastrowid
    assert rowid is not None, "INSERT executed but lastrowid is unset"
    return rowid


# --- sources ----------------------------------------------------------------


def ensure_source(conn: sqlite3.Connection, kind: str) -> int:
    row = conn.execute("SELECT id FROM sources WHERE kind = ?", (kind,)).fetchone()
    if row is not None:
        return int(row[0])
    cur = conn.execute("INSERT INTO sources(kind) VALUES (?)", (kind,))
    return _last_insert_id(cur)


def mark_source_run(conn: sqlite3.Connection, source_id: int) -> None:
    conn.execute("UPDATE sources SET last_run_at = ? WHERE id = ?", (_now(), source_id))


# --- runs -------------------------------------------------------------------


def start_run(conn: sqlite3.Connection, source_id: int) -> int:
    cur = conn.execute("INSERT INTO runs(source_id, started_at) VALUES (?, ?)", (source_id, _now()))
    return _last_insert_id(cur)


def finish_run(
    conn: sqlite3.Connection,
    run_id: int,
    *,
    found: int,
    new: int,
    error: str | None = None,
) -> None:
    conn.execute(
        "UPDATE runs SET finished_at = ?, found = ?, new = ?, error = ? WHERE id = ?",
        (_now(), found, new, error, run_id),
    )


def recent_runs(conn: sqlite3.Connection, limit: int = 50) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT r.*, s.kind AS source_kind FROM runs r "
        "JOIN sources s ON s.id = r.source_id ORDER BY r.id DESC LIMIT ?",
        (limit,),
    ).fetchall()


# --- items ------------------------------------------------------------------


def upsert_item(conn: sqlite3.Connection, source_id: int, item: ContentItem) -> int | None:
    """Insert *item* if its URL hasn't been seen. Returns the new id, or ``None`` if a dupe."""
    published = item.published_at.isoformat() if item.published_at else None
    cur = conn.execute(
        "INSERT OR IGNORE INTO items"
        "(source_id, url, url_hash, title, author, summary, published_at, discovered_at, raw_json, state) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'new')",
        (
            source_id,
            item.url,
            item.url_hash(),
            item.title,
            item.author,
            item.summary,
            published,
            _now(),
            json.dumps(item.raw, default=str),
        ),
    )
    return _last_insert_id(cur) if cur.rowcount else None


def list_feed_items(conn: sqlite3.Connection, limit: int = 200) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT i.*, s.kind AS source_kind FROM items i "
        "JOIN sources s ON s.id = i.source_id "
        f"WHERE i.state IN ({','.join('?' * len(FEED_STATES))}) "
        "ORDER BY COALESCE(i.published_at, i.discovered_at) DESC, i.id DESC LIMIT ?",
        (*FEED_STATES, limit),
    ).fetchall()


def get_item(conn: sqlite3.Connection, item_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT i.*, s.kind AS source_kind FROM items i "
        "JOIN sources s ON s.id = i.source_id WHERE i.id = ?",
        (item_id,),
    ).fetchone()


def set_item_state(conn: sqlite3.Connection, item_id: int, state: str) -> None:
    conn.execute("UPDATE items SET state = ? WHERE id = ?", (state, item_id))


# --- extractions ------------------------------------------------------------


def get_extraction(conn: sqlite3.Connection, item_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM extractions WHERE item_id = ?", (item_id,)).fetchone()


def save_extraction(
    conn: sqlite3.Connection,
    item_id: int,
    *,
    markdown: str | None = None,
    title: str | None = None,
    error: str | None = None,
    word_count: int | None = None,
) -> None:
    """Cache a fetch+extract result for *item_id* (overwrites any previous attempt).

    The ``summary_md`` field is set separately by :func:`save_extraction_summary`
    after the LLM brief lands — extraction is synchronous; summarisation runs
    afterwards in its own worker so the reader doesn't block waiting.
    """
    conn.execute(
        "INSERT INTO extractions(item_id, fetched_at, title, markdown, error, word_count) "
        "VALUES (?, ?, ?, ?, ?, ?) "
        "ON CONFLICT(item_id) DO UPDATE SET "
        "fetched_at = excluded.fetched_at, title = excluded.title, "
        "markdown = excluded.markdown, error = excluded.error, "
        "word_count = excluded.word_count",
        (item_id, _now(), title, markdown, error, word_count),
    )


def save_extraction_summary(conn: sqlite3.Connection, item_id: int, summary_md: str) -> None:
    """Set the brief on an already-extracted row. No-op when no row exists yet."""
    conn.execute(
        "UPDATE extractions SET summary_md = ? WHERE item_id = ?",
        (summary_md, item_id),
    )


# --- saved items ------------------------------------------------------------


def _tags_to_json(tags: list[str] | None) -> str:
    cleaned = []
    for tag in tags or []:
        tag = " ".join(str(tag).split()).strip()
        if tag and tag not in cleaned:
            cleaned.append(tag)
    return json.dumps(cleaned)


def parse_tags(tags_json: str | None) -> list[str]:
    try:
        value = json.loads(tags_json or "[]")
    except (TypeError, json.JSONDecodeError):
        return []
    return [str(t) for t in value] if isinstance(value, list) else []


def is_saved(conn: sqlite3.Connection, item_id: int) -> bool:
    return conn.execute("SELECT 1 FROM saved WHERE item_id = ?", (item_id,)).fetchone() is not None


def like_item(
    conn: sqlite3.Connection,
    item_id: int,
    *,
    full_text: str | None = None,
    tags: list[str] | None = None,
    notes: str | None = None,
) -> None:
    """Mark *item_id* liked and snapshot it into ``saved`` (upsert)."""
    set_item_state(conn, item_id, "liked")
    conn.execute(
        "INSERT INTO saved(item_id, saved_at, full_text, tags_json, notes) "
        "VALUES (?, ?, ?, ?, ?) "
        "ON CONFLICT(item_id) DO UPDATE SET "
        "full_text = COALESCE(excluded.full_text, saved.full_text)",
        (item_id, _now(), full_text, _tags_to_json(tags), notes),
    )


def update_saved(
    conn: sqlite3.Connection,
    item_id: int,
    *,
    tags: list[str] | None = None,
    notes: str | None = None,
    full_text: str | None = None,
) -> None:
    """Patch a saved row. Only the keyword args you pass are touched."""
    sets, params = [], []
    if tags is not None:
        sets.append("tags_json = ?")
        params.append(_tags_to_json(tags))
    if notes is not None:
        sets.append("notes = ?")
        params.append(notes)
    if full_text is not None:
        sets.append("full_text = ?")
        params.append(full_text)
    if not sets:
        return
    params.append(item_id)
    conn.execute(f"UPDATE saved SET {', '.join(sets)} WHERE item_id = ?", params)


def unsave_item(conn: sqlite3.Connection, item_id: int) -> None:
    conn.execute("DELETE FROM saved WHERE item_id = ?", (item_id,))
    set_item_state(conn, item_id, "seen")


def dismiss_item(conn: sqlite3.Connection, item_id: int) -> None:
    set_item_state(conn, item_id, "dismissed")


def get_saved(conn: sqlite3.Connection, item_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT i.*, s.kind AS source_kind, "
        "sv.saved_at, sv.full_text, sv.tags_json, sv.notes "
        "FROM saved sv JOIN items i ON i.id = sv.item_id "
        "JOIN sources s ON s.id = i.source_id WHERE sv.item_id = ?",
        (item_id,),
    ).fetchone()


def list_saved_items(
    conn: sqlite3.Connection, *, query: str | None = None, limit: int = 500
) -> list[sqlite3.Row]:
    if query and query.strip():
        return search_saved(conn, query, limit=limit)
    return conn.execute(
        "SELECT i.*, s.kind AS source_kind, "
        "sv.saved_at, sv.full_text, sv.tags_json, sv.notes "
        "FROM saved sv JOIN items i ON i.id = sv.item_id "
        "JOIN sources s ON s.id = i.source_id "
        "ORDER BY sv.saved_at DESC, sv.item_id DESC LIMIT ?",
        (limit,),
    ).fetchall()


# --- feed suggestions -------------------------------------------------------
#
# Populated by the article extractor when it finds an RSS/Atom ``<link
# rel="alternate">`` in a liked article's <head>. The Feed pane / setup wizard
# surface open suggestions so the user can one-click subscribe or dismiss.


def add_feed_suggestion(
    conn: sqlite3.Connection,
    *,
    feed_url: str,
    site_url: str | None = None,
    site_title: str | None = None,
    source_item_id: int | None = None,
) -> int | None:
    """Insert *feed_url* if we haven't seen it. Returns the new id, or None on dupe.

    Idempotent: ``feed_url`` carries a UNIQUE constraint; calling twice with
    the same URL is a no-op. Doesn't un-dismiss an already-dismissed
    suggestion — that's a deliberate choice; if you said no once we don't
    pester you the next time an article from the same site shows up.
    """
    cur = conn.execute(
        "INSERT OR IGNORE INTO feed_suggestions"
        "(feed_url, site_url, site_title, source_item_id, detected_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (feed_url, site_url, site_title, source_item_id, _now()),
    )
    return _last_insert_id(cur) if cur.rowcount else None


def list_feed_suggestions(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    """Open (un-dismissed) suggestions, newest first."""
    return conn.execute(
        "SELECT * FROM feed_suggestions "
        "WHERE dismissed_at IS NULL "
        "ORDER BY detected_at DESC, id DESC"
    ).fetchall()


def dismiss_feed_suggestion(conn: sqlite3.Connection, suggestion_id: int) -> None:
    """Mark a suggestion as dismissed (without deleting it — so we won't re-suggest)."""
    conn.execute(
        "UPDATE feed_suggestions SET dismissed_at = ? WHERE id = ? AND dismissed_at IS NULL",
        (_now(), suggestion_id),
    )


# --- research ---------------------------------------------------------------


def record_research(
    conn: sqlite3.Connection,
    *,
    topic: str,
    title: str | None = None,
    path: str | None = None,
    markdown: str | None = None,
    source_count: int = 0,
    error: str | None = None,
    sources_json: str | None = None,
) -> int:
    cur = conn.execute(
        "INSERT INTO research"
        "(topic, title, path, markdown, source_count, created_at, error, sources_json) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (topic, title, path, markdown, int(source_count), _now(), error, sources_json),
    )
    return _last_insert_id(cur)


def list_research(conn: sqlite3.Connection, limit: int = 200) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM research ORDER BY created_at DESC, id DESC LIMIT ?", (limit,)
    ).fetchall()


def get_research(conn: sqlite3.Connection, research_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM research WHERE id = ?", (research_id,)).fetchone()


def delete_research(conn: sqlite3.Connection, research_id: int) -> None:
    conn.execute("DELETE FROM research WHERE id = ?", (research_id,))


# --- FTS5 search ------------------------------------------------------------


def _fts_query(raw: str) -> str | None:
    """Turn user input into an FTS5 MATCH expression, or return None if empty.

    Each whitespace-separated token is wrapped in double quotes (with inner ``"``
    doubled) so column filters (``foo:bar``) and operators (``OR``, ``NOT``,
    parens) become literal terms — FTS5 won't crash on hostile input.
    """
    tokens = (raw or "").split()
    if not tokens:
        return None
    quoted = ['"' + tok.replace('"', '""') + '"' for tok in tokens]
    return " ".join(quoted)


def search_feed(conn: sqlite3.Connection, query: str, *, limit: int = 200) -> list[sqlite3.Row]:
    match = _fts_query(query)
    if match is None:
        return []
    placeholders = ",".join("?" * len(FEED_STATES))
    return conn.execute(
        "SELECT i.*, s.kind AS source_kind FROM items_fts f "
        "JOIN items i ON i.id = f.rowid "
        "JOIN sources s ON s.id = i.source_id "
        f"WHERE items_fts MATCH ? AND i.state IN ({placeholders}) "
        "ORDER BY bm25(items_fts) ASC, "
        "COALESCE(i.published_at, i.discovered_at) DESC, i.id DESC "
        "LIMIT ?",
        (match, *FEED_STATES, limit),
    ).fetchall()


def search_saved(conn: sqlite3.Connection, query: str, *, limit: int = 500) -> list[sqlite3.Row]:
    match = _fts_query(query)
    if match is None:
        return []
    return conn.execute(
        "SELECT i.*, s.kind AS source_kind, "
        "sv.saved_at, sv.full_text, sv.tags_json, sv.notes "
        "FROM items_fts f "
        "JOIN saved sv ON sv.item_id = f.rowid "
        "JOIN items i ON i.id = sv.item_id "
        "JOIN sources s ON s.id = i.source_id "
        "WHERE items_fts MATCH ? "
        "ORDER BY bm25(items_fts) ASC, sv.saved_at DESC, sv.item_id DESC "
        "LIMIT ?",
        (match, limit),
    ).fetchall()
