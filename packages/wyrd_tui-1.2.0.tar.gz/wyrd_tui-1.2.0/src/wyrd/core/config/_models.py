"""The frozen dataclasses that make up a parsed :class:`Config`.

One subject per section of the TOML file. Each is independent — no logic
beyond ``KeysConfig.as_dict()`` (which the live-keybinding wiring uses) — so
parsing, rendering, and consumers can all depend on this module without
pulling in tomllib or rendering code.
"""

from __future__ import annotations

from dataclasses import dataclass, field, fields
from pathlib import Path

from ._defaults import DEFAULT_KEYS


@dataclass(frozen=True, slots=True)
class GeneralConfig:
    refresh_interval_minutes: int = 60


@dataclass(frozen=True, slots=True)
class ContentConfig:
    feeds: list[str] = field(default_factory=list)
    keywords: list[str] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class ResearchConfig:
    output_dir: str = ""
    min_sources: int = 8
    max_sources: int = 25
    timeout_seconds: int = 900


@dataclass(frozen=True, slots=True)
class UIConfig:
    theme: str = "textual-dark"


@dataclass(frozen=True, slots=True)
class TasteProfile:
    """One named "what to favor / what to avoid" preset for LLM discovery.

    Slotted into the discovery prompt templates at run time. Users can edit
    the favor/avoid lists in ``config.toml`` under ``[discover.profiles.<name>]``;
    wyrd ships a small set of built-ins (default, engineer, academic, essays).
    A user-defined profile with the same name as a built-in overrides it.
    """

    name: str
    description: str
    favor: tuple[str, ...] = ()
    avoid: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class DiscoverConfig:
    """Settings for the LLM-driven content discovery (``Ctrl+D`` in the Feed pane).

    ``taste_profile`` names the active profile; ``profiles`` is the map of
    available profiles (built-ins merged with user overrides). When the
    named profile isn't in the map we fall back to ``"default"`` — the only
    profile guaranteed to exist.
    """

    taste_profile: str = "default"
    profiles: dict[str, TasteProfile] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ObsidianConfig:
    # Path to an Obsidian vault folder. When set, every liked article and every
    # finished research run lands as Markdown under <vault>/wyrd. Empty = off.
    vault: str = ""
    # The subfolder inside the vault. Defaults to "wyrd"; everything goes here.
    folder: str = "wyrd"


@dataclass(frozen=True, slots=True)
class KeysConfig:
    feed: str = DEFAULT_KEYS["feed"]
    saved: str = DEFAULT_KEYS["saved"]
    research: str = DEFAULT_KEYS["research"]
    terminal: str = DEFAULT_KEYS["terminal"]
    refresh: str = DEFAULT_KEYS["refresh"]
    discover: str = DEFAULT_KEYS["discover"]
    activity: str = DEFAULT_KEYS["activity"]
    setup: str = DEFAULT_KEYS["setup"]
    shell: str = DEFAULT_KEYS["shell"]
    quit: str = DEFAULT_KEYS["quit"]

    def as_dict(self) -> dict[str, str]:
        return {f.name: getattr(self, f.name) for f in fields(self)}


@dataclass(frozen=True, slots=True)
class Config:
    general: GeneralConfig = field(default_factory=GeneralConfig)
    content: ContentConfig = field(default_factory=ContentConfig)
    research: ResearchConfig = field(default_factory=ResearchConfig)
    discover: DiscoverConfig = field(default_factory=DiscoverConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    keys: KeysConfig = field(default_factory=KeysConfig)
    obsidian: ObsidianConfig = field(default_factory=ObsidianConfig)
    path: Path | None = None
