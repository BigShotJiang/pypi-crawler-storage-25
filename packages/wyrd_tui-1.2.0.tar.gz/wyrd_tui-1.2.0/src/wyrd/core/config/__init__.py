"""Config: the TOML file under ``$WYRD_HOME/config.toml``, parsed into dataclasses.

Layout (Kotlin-style — one subject per file):

- :mod:`._defaults` — :data:`DEFAULT_KEYS`, :data:`DEFAULT_CONFIG_TOML`
- :mod:`._models`   — the frozen dataclasses (:class:`Config` and its parts)
- :mod:`._load`     — :func:`load` + private coercion helpers
- :mod:`._render`   — :func:`render_toml` + :func:`write` (hand-written TOML)

Callers should import from ``wyrd.core.config`` (this module) only; the
underscore-prefixed submodules are private. The public surface is declared in
:data:`__all__`.
"""

from __future__ import annotations

from ._defaults import DEFAULT_CONFIG_TOML, DEFAULT_KEYS
from ._load import load
from ._models import (
    Config,
    ContentConfig,
    DiscoverConfig,
    GeneralConfig,
    KeysConfig,
    ObsidianConfig,
    ResearchConfig,
    TasteProfile,
    UIConfig,
)
from ._render import render_toml, write

__all__ = [
    "DEFAULT_CONFIG_TOML",
    "DEFAULT_KEYS",
    "Config",
    "ContentConfig",
    "DiscoverConfig",
    "GeneralConfig",
    "KeysConfig",
    "ObsidianConfig",
    "ResearchConfig",
    "TasteProfile",
    "UIConfig",
    "load",
    "render_toml",
    "write",
]
