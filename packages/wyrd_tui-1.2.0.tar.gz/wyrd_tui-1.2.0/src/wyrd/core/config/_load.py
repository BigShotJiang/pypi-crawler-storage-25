"""Parse a ``config.toml`` into a :class:`Config`.

On first launch (no file present) we write :data:`DEFAULT_CONFIG_TOML` and parse
that — the on-disk file stays friendly to hand-edit, and missing keys fall back
to the dataclass defaults rather than silently disappearing.
"""

from __future__ import annotations

import logging
import tomllib
from pathlib import Path

from wyrd.core import paths

from ._defaults import DEFAULT_CONFIG_TOML, DEFAULT_KEYS
from ._models import (
    Config,
    ContentConfig,
    DiscoverConfig,
    GeneralConfig,
    KeysConfig,
    ObsidianConfig,
    ResearchConfig,
    TasteProfile,
    UIConfig,
)

logger = logging.getLogger(__name__)


def _int(value, default: int, *, minimum: int = 1) -> int:
    try:
        return max(minimum, int(value))
    except (TypeError, ValueError):
        return default


def _coerce_keys(raw: dict) -> KeysConfig:
    values: dict[str, str] = {}
    for name, default in DEFAULT_KEYS.items():
        v = raw.get(name, default)
        if not isinstance(v, str) or not v.strip():
            logger.warning(
                "keys.%s in config is not a non-empty string; using default %r", name, default
            )
            values[name] = default
        else:
            values[name] = v.strip()
    return KeysConfig(**values)


def _coerce_profiles(raw: dict | None) -> dict[str, TasteProfile]:
    """Parse ``[discover.profiles.<name>]`` blocks into ``TasteProfile`` values.

    Only ``favor`` and ``avoid`` (lists of strings) and ``description`` are
    user-controlled; the profile name comes from the table key. Invalid
    entries are dropped with a warning rather than crashing config load.
    """
    if not isinstance(raw, dict):
        return {}
    out: dict[str, TasteProfile] = {}
    for name, block in raw.items():
        if not isinstance(block, dict):
            logger.warning("discover.profiles.%s is not a table; ignoring", name)
            continue
        favor = tuple(str(b) for b in (block.get("favor") or []) if str(b).strip())
        avoid = tuple(str(b) for b in (block.get("avoid") or []) if str(b).strip())
        description = str(block.get("description") or "").strip()
        out[name] = TasteProfile(name=name, description=description, favor=favor, avoid=avoid)
    return out


def _coerce(raw: dict, path: Path | None) -> Config:
    g = raw.get("general", {})
    c = raw.get("content", {})
    r = raw.get("research", {})
    d = raw.get("discover", {}) if isinstance(raw.get("discover", {}), dict) else {}
    u = raw.get("ui", {})
    k = raw.get("keys", {})
    o = raw.get("obsidian", {}) if isinstance(raw.get("obsidian", {}), dict) else {}
    min_sources = _int(r.get("min_sources", 8), 8)
    max_sources = max(min_sources, _int(r.get("max_sources", 25), 25))
    return Config(
        general=GeneralConfig(
            refresh_interval_minutes=int(g.get("refresh_interval_minutes", 60)),
        ),
        content=ContentConfig(
            feeds=list(c.get("feeds", [])),
            keywords=[str(kw).lower() for kw in c.get("keywords", [])],
        ),
        research=ResearchConfig(
            output_dir=str(r.get("output_dir", "") or ""),
            min_sources=min_sources,
            max_sources=max_sources,
            timeout_seconds=_int(r.get("timeout_seconds", 900), 900, minimum=30),
        ),
        discover=DiscoverConfig(
            taste_profile=str(d.get("taste_profile", "default") or "default").strip() or "default",
            profiles=_coerce_profiles(d.get("profiles")),
        ),
        ui=UIConfig(theme=str(u.get("theme", "textual-dark"))),
        keys=_coerce_keys(k if isinstance(k, dict) else {}),
        obsidian=ObsidianConfig(
            vault=str(o.get("vault", "") or "").strip(),
            folder=str(o.get("folder", "wyrd") or "wyrd").strip() or "wyrd",
        ),
        path=path,
    )


def load(create_if_missing: bool = True) -> Config:
    path = paths.config_file()
    if not path.exists():
        if create_if_missing:
            path.write_text(DEFAULT_CONFIG_TOML)
        else:
            return Config(path=path)
    with path.open("rb") as fh:
        raw = tomllib.load(fh)
    return _coerce(raw, path)
