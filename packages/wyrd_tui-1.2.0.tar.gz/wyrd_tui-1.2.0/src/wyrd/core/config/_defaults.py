"""Default keymap and the seed TOML written on first launch.

Two pieces of data, no logic — kept separate so :mod:`._models`, :mod:`._load`,
and :mod:`._render` can each pull what they need without dragging the rest.
"""

from __future__ import annotations

DEFAULT_KEYS: dict[str, str] = {
    "feed": "1",
    "saved": "2",
    "research": "3",
    "terminal": "4",
    "refresh": "ctrl+r",
    "discover": "ctrl+d",
    "activity": "f3",
    "setup": "f2",
    "shell": "f10",
    "quit": "ctrl+q",
}

DEFAULT_CONFIG_TOML = """\
# wyrd configuration. Edit freely; missing keys fall back to built-in defaults.

[general]
# How often the background worker searches for new content.
refresh_interval_minutes = 60

[content]
# RSS / Atom feeds to poll. A few starter suggestions are commented out;
# uncomment any you want, or add your own. The setup wizard's "✨ Suggest
# feeds & keywords with Claude" button can find more based on your interests,
# and wyrd auto-detects RSS feeds from articles you like.
feeds = [
    # Hacker News:
    # "https://hnrss.org/frontpage",
    # "https://hnrss.org/best",
    # "https://hnrss.org/frontpage?points=200",  # only items with 200+ points

    # Long-form journalism / essays:
    # "https://www.theverge.com/rss/index.xml",
    # "https://www.theatlantic.com/feed/all/",
]
# Case-insensitive keywords used to flag items as "interesting".
keywords = []

[research]
# Folder where the deep-research agent writes its Markdown papers.
# Leave blank to use the app data dir (~/.local/share/wyrd/research).
output_dir = ""
# How many peer-reviewed papers to gather (the agent aims for this range).
min_sources = 8
max_sources = 25
# Wall-clock budget for a single research run, in seconds.
timeout_seconds = 900

[discover]
# Active taste profile for Ctrl+D content discovery. Built-ins: "default",
# "engineer", "academic", "essays". Override or add your own below.
taste_profile = "default"

# To define a custom profile, add a block like this and set the name above.
# Profiles ship with built-in defaults (see ``wyrd.core.discover.BUILT_IN_PROFILES``);
# a custom profile with the same name overrides the built-in. Edit lists live,
# next Ctrl+D picks them up.
#
# [discover.profiles.my-profile]
# description = "what this profile is for, one line"
# favor = [
#     "Bullet describing one kind of article you want",
# ]
# avoid = [
#     "Bullet describing one kind of article you don't want",
# ]

[ui]
# Textual theme name (see the command palette > "Change theme").
theme = "textual-dark"

[obsidian]
# Path to an Obsidian vault. When set, every liked article and every finished
# research run lands as Markdown under <vault>/<folder>. Leave blank to disable.
vault = ""
# The folder inside the vault (defaults to "wyrd").
folder = "wyrd"

[keys]
# Override individual key bindings. Use Textual key syntax: "1", "ctrl+r", "f2",
# "shift+a", etc. Invalid values are ignored (falls back to the default).
feed = "1"
saved = "2"
research = "3"
terminal = "4"
refresh = "ctrl+r"
discover = "ctrl+d"
activity = "f3"
setup = "f2"
shell = "f10"
quit = "ctrl+q"
"""
