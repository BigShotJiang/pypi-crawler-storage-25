"""Render a :class:`Config` (or its loose constituent parts) back to TOML.

Hand-written so the file stays commented and human-friendly — round-tripping
through ``tomli_w`` would drop the comments and reshape the layout. ``write()``
is the one entry point the rest of the app uses; ``render_toml()`` is exposed
for tests that want to assert on the produced text without touching disk.
"""

from __future__ import annotations

import json
from pathlib import Path

from wyrd.core import paths

from ._defaults import DEFAULT_KEYS
from ._models import DiscoverConfig, KeysConfig, ObsidianConfig, ResearchConfig, TasteProfile


def _toml_str(value: str) -> str:
    # TOML basic strings accept the same escaping as JSON strings for our purposes.
    return json.dumps(value, ensure_ascii=False)


def _toml_array(values: list[str], indent: str = "    ") -> str:
    if not values:
        return "[]"
    body = ",\n".join(f"{indent}{_toml_str(v)}" for v in values)
    return f"[\n{body},\n]"


def _render_discover_profile(profile: TasteProfile) -> str:
    body = [
        f"[discover.profiles.{profile.name}]",
        f"description = {_toml_str(profile.description)}",
        f"favor = {_toml_array(list(profile.favor))}",
        f"avoid = {_toml_array(list(profile.avoid))}",
        "",
    ]
    return "\n".join(body)


def render_toml(
    *,
    refresh_interval_minutes: int,
    feeds: list[str],
    keywords: list[str],
    theme: str = "textual-dark",
    research: ResearchConfig | None = None,
    discover: DiscoverConfig | None = None,
    keys: KeysConfig | None = None,
    obsidian: ObsidianConfig | None = None,
) -> str:
    research = research or ResearchConfig()
    discover = discover or DiscoverConfig()
    keys = keys or KeysConfig()
    obsidian = obsidian or ObsidianConfig()
    keys_block = "\n".join(f"{name} = {_toml_str(getattr(keys, name))}" for name in DEFAULT_KEYS)
    custom_profiles = "".join(_render_discover_profile(p) for p in discover.profiles.values())
    return (
        "# wyrd configuration. Edit freely; missing keys fall back to built-in defaults.\n\n"
        "[general]\n"
        "# How often the background worker searches for new content.\n"
        f"refresh_interval_minutes = {int(refresh_interval_minutes)}\n\n"
        "[content]\n"
        "# RSS / Atom feed URLs to poll.\n"
        f"feeds = {_toml_array(feeds)}\n"
        '# Case-insensitive keywords used to flag items as "interesting".\n'
        f"keywords = {_toml_array(keywords)}\n\n"
        "[research]\n"
        "# Folder where the deep-research agent writes its Markdown papers.\n"
        "# Leave blank to use the app data dir (or the Obsidian vault, when set).\n"
        f"output_dir = {_toml_str(research.output_dir)}\n"
        "# How many peer-reviewed papers to gather (the agent aims for this range).\n"
        f"min_sources = {int(research.min_sources)}\n"
        f"max_sources = {int(research.max_sources)}\n"
        "# Wall-clock budget for a single research run, in seconds.\n"
        f"timeout_seconds = {int(research.timeout_seconds)}\n\n"
        "[discover]\n"
        "# Active taste profile for Ctrl+D content discovery. Built-ins:\n"
        '# "default", "engineer", "academic", "essays". Define your own below.\n'
        f"taste_profile = {_toml_str(discover.taste_profile)}\n"
        f"\n{custom_profiles}"
        "[ui]\n"
        '# Textual theme name (see the command palette > "Change theme").\n'
        f"theme = {_toml_str(theme)}\n\n"
        "[obsidian]\n"
        "# Path to an Obsidian vault. When set, every liked article and every\n"
        "# finished research run lands as Markdown under <vault>/<folder>. Leave\n"
        "# blank to disable.\n"
        f"vault = {_toml_str(obsidian.vault)}\n"
        '# The folder inside the vault (defaults to "wyrd").\n'
        f"folder = {_toml_str(obsidian.folder)}\n\n"
        "[keys]\n"
        '# Override individual key bindings. Use Textual key syntax ("1", "ctrl+r", "f2", ...).\n'
        f"{keys_block}\n"
    )


def write(
    *,
    refresh_interval_minutes: int,
    feeds: list[str],
    keywords: list[str],
    theme: str = "textual-dark",
    research: ResearchConfig | None = None,
    discover: DiscoverConfig | None = None,
    keys: KeysConfig | None = None,
    obsidian: ObsidianConfig | None = None,
) -> Path:
    """Overwrite the config file with the given values and return its path."""
    path = paths.config_file()
    path.write_text(
        render_toml(
            refresh_interval_minutes=refresh_interval_minutes,
            feeds=feeds,
            keywords=keywords,
            theme=theme,
            research=research,
            discover=discover,
            keys=keys,
            obsidian=obsidian,
        )
    )
    return path
