"""Fetch a web page and turn it into clean Markdown.

Used by the Feed pane to render an item's content in-app instead of opening a
browser. We let trafilatura strip the boilerplate (it returns structured XML),
then build Markdown from that XML ourselves — trafilatura's own Markdown output
loses code-block indentation and mangles inline code, so :mod:`wyrd.core.xml2md`
does the conversion instead. trafilatura's parsing is synchronous, so we fetch
HTML asynchronously with httpx and run the extraction step on a thread.

The same HTML pass also harvests ``<link rel="alternate" type="application/
{rss,atom}+xml">`` URLs from the head — feeds the user can subscribe to —
plus the page's ``<title>`` and any ``og:site_name``. The Feed pane uses
these to populate ``feed_suggestions`` so wyrd can offer "Subscribe to the
site this article came from?" without an explicit user action.
"""

from __future__ import annotations

import asyncio
import io
import re
from dataclasses import dataclass, field
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import httpx
import trafilatura

from wyrd.core.http import USER_AGENT as _USER_AGENT
from wyrd.core.xml2md import xml_to_markdown

__all__ = [
    "ExtractedArticle",
    "FeedLink",
    "fetch_and_extract",
    "fetch_document_markdown",
    "find_feed_links",
]


@dataclass(slots=True)
class FeedLink:
    """One ``<link rel="alternate">`` advertisement, resolved to an absolute URL."""

    feed_url: str
    site_url: str  # the page URL where we found the link
    site_title: str | None = None  # og:site_name if present, else <title>


@dataclass(slots=True)
class ExtractedArticle:
    markdown: str
    title: str | None = None
    feed_links: list[FeedLink] = field(default_factory=list)


async def fetch_and_extract(url: str, *, timeout: float = 25.0) -> ExtractedArticle:
    async with httpx.AsyncClient(
        timeout=timeout, follow_redirects=True, headers={"User-Agent": _USER_AGENT}
    ) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        ctype = resp.headers.get("content-type", "").lower()
        if "html" not in ctype and not ctype.startswith("text/"):
            raise RuntimeError(f"non-text content type: {ctype or 'unknown'}")
        html = resp.text
    return await asyncio.to_thread(_extract_sync, html, url)


def _extract_xml(html: str, *, favor_recall: bool) -> str | None:
    return trafilatura.extract(
        html,
        output_format="xml",
        include_links=True,
        include_formatting=True,
        include_tables=True,
        include_images=False,
        include_comments=False,
        with_metadata=False,
        favor_recall=favor_recall,
    )


def _extract_sync(html: str, url: str) -> ExtractedArticle:
    xml = _extract_xml(html, favor_recall=False)
    markdown = xml_to_markdown(xml) if xml else ""
    if not markdown.strip():
        # Retry with looser heuristics for pages trafilatura is unsure about.
        xml = _extract_xml(html, favor_recall=True)
        markdown = xml_to_markdown(xml) if xml else ""
    if not markdown.strip():
        raise RuntimeError("nothing extractable on the page")

    title: str | None = None
    try:
        meta = trafilatura.extract_metadata(html, default_url=url)
        if meta is not None:
            title = getattr(meta, "title", None)
    except Exception:  # noqa: BLE001 — metadata is a nice-to-have
        pass

    return ExtractedArticle(
        markdown=markdown.strip(),
        title=title,
        feed_links=find_feed_links(html, base_url=url),
    )


# --- feed-link harvest ------------------------------------------------------
#
# Called from ``_extract_sync`` on every successful article extraction, and
# the feed pane stores any results as ``feed_suggestions`` so the wizard can
# offer "subscribe to this site?" without an explicit user action. Cheap —
# we already have the HTML in memory.

_FEED_TYPES = frozenset(
    {
        "application/rss+xml",
        "application/atom+xml",
        "application/feed+json",
    }
)


class _FeedLinkParser(HTMLParser):
    """Stdlib parser to pull head metadata. We stop tracking after </head>."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._in_head = True
        self._in_title = False
        self.title: str | None = None
        self.site_name: str | None = None
        self.feed_hrefs: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if not self._in_head:
            return
        if tag == "title":
            self._in_title = True
            return
        if tag == "link":
            a = dict(attrs)
            rel = (a.get("rel") or "").lower()
            ftype = (a.get("type") or "").lower()
            href = a.get("href")
            if href and "alternate" in rel.split() and ftype in _FEED_TYPES:
                self.feed_hrefs.append(href)
            return
        if tag == "meta":
            a = dict(attrs)
            prop = (a.get("property") or a.get("name") or "").lower()
            if prop == "og:site_name" and a.get("content"):
                self.site_name = a["content"]

    def handle_endtag(self, tag: str) -> None:
        if tag == "head":
            self._in_head = False
        elif tag == "title":
            self._in_title = False

    def handle_data(self, data: str) -> None:
        if self._in_title and self.title is None:
            self.title = data.strip()


def find_feed_links(html: str, *, base_url: str) -> list[FeedLink]:
    """Resolve ``<link rel="alternate" type="application/{rss,atom}+xml">`` URLs.

    Returns ``[]`` when the page advertises no feeds. Each entry's
    ``feed_url`` is resolved against ``base_url`` (relative ``href``s are
    common on small blogs). ``site_title`` prefers ``og:site_name`` and falls
    back to ``<title>``; ``site_url`` is the scheme+host of *base_url* so the
    UI can render "Subscribe to <site>?" without leaking the article path.
    """
    parser = _FeedLinkParser()
    try:
        parser.feed(html)
    except Exception:  # noqa: BLE001 — broken HTML is common; degrade to "no feeds"
        return []
    if not parser.feed_hrefs:
        return []
    parsed = urlparse(base_url)
    site_url = f"{parsed.scheme}://{parsed.netloc}" if parsed.scheme and parsed.netloc else base_url
    site_title = parser.site_name or parser.title
    seen: set[str] = set()
    out: list[FeedLink] = []
    for href in parser.feed_hrefs:
        absolute = urljoin(base_url, href)
        if absolute in seen:
            continue
        seen.add(absolute)
        out.append(FeedLink(feed_url=absolute, site_url=site_url, site_title=site_title))
    return out


# --- full documents (PDF or HTML) ------------------------------------------
#
# Used by the deep-research agent to pull down the full text of a cited paper —
# an open-access PDF or HTML article — and turn it into Markdown for later
# checking. PDF text extraction is layout-imperfect but complete; HTML reuses
# the trafilatura pipeline above.

_MAX_DOC_BYTES = 60 * 1024 * 1024
_ARXIV_ABS_RE = re.compile(r"^https?://arxiv\.org/abs/([^?#]+)$", re.IGNORECASE)


def _normalize_doc_url(url: str) -> str:
    """Small nudges toward the actual document (e.g. an arXiv abstract page → its PDF)."""
    match = _ARXIV_ABS_RE.match(url.strip())
    return f"https://arxiv.org/pdf/{match.group(1)}" if match else url.strip()


def _pdf_to_text(data: bytes) -> str:
    from pypdf import PdfReader

    parts: list[str] = []
    try:
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            try:
                reader.decrypt("")  # many "encrypted" PDFs use an empty password
            except Exception:  # noqa: BLE001
                raise RuntimeError("the PDF is password-protected") from None
        for page in reader.pages:
            try:
                text = (page.extract_text() or "").strip()
            except Exception:  # noqa: BLE001 — one bad page shouldn't sink the rest
                text = ""
            if text:
                parts.append(text)
    except RuntimeError:
        raise
    except Exception as exc:  # noqa: BLE001 — any PDF-parsing failure → a clean error
        raise RuntimeError(f"couldn't parse the PDF: {exc}") from exc
    text = re.sub(r"\n{3,}", "\n\n", "\n\n".join(parts)).strip()
    if not text:
        raise RuntimeError("no extractable text in the PDF (a scanned image?)")
    return text


async def fetch_document_markdown(url: str, *, timeout: float = 45.0) -> str:
    """Fetch *url* — a PDF or an HTML page — and return its full content as Markdown.

    Raises ``RuntimeError`` / ``httpx`` errors on anything we can't fetch or read.
    """
    url = _normalize_doc_url(url)
    async with httpx.AsyncClient(
        timeout=timeout, follow_redirects=True, headers={"User-Agent": _USER_AGENT}
    ) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        declared = resp.headers.get("content-length")
        if declared and declared.isdigit() and int(declared) > _MAX_DOC_BYTES:
            raise RuntimeError(f"document too large ({int(declared) // (1024 * 1024)} MB)")
        ctype = resp.headers.get("content-type", "").split(";", 1)[0].strip().lower()
        body = resp.content
        is_pdf = ctype == "application/pdf" or url.lower().endswith(".pdf") or body[:5] == b"%PDF-"
        if is_pdf:
            if len(body) > _MAX_DOC_BYTES:
                raise RuntimeError(f"document too large ({len(body) // (1024 * 1024)} MB)")
            return await asyncio.to_thread(_pdf_to_text, body)
        if "html" in ctype or ctype.startswith("text/") or not ctype:
            return (await asyncio.to_thread(_extract_sync, resp.text, url)).markdown
        raise RuntimeError(f"unsupported content type: {ctype or 'unknown'}")
