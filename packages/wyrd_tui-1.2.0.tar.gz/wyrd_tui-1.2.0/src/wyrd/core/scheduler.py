"""Runs the registered content sources and records what they find.

M2 ships :meth:`Scheduler.run_once` — a single pass over every source, triggered
manually (Ctrl+R). M4 adds the hourly auto-refresh loop on top of the same
machinery.
"""

from __future__ import annotations

import logging
import sqlite3
from dataclasses import dataclass, field

from wyrd.core import filters, store
from wyrd.core import sources as sources_mod
from wyrd.core.config import Config
from wyrd.core.events import EventBus

log = logging.getLogger(__name__)

__all__ = [
    "RefreshResult",
    "Scheduler",
]


@dataclass(slots=True)
class RefreshResult:
    found: int = 0
    new: int = 0
    errors: list[str] = field(default_factory=list)
    skipped: bool = False


class Scheduler:
    def __init__(self, conn: sqlite3.Connection, config: Config, events: EventBus) -> None:
        self._conn = conn
        self._config = config
        self._events = events
        self._busy = False

    @property
    def busy(self) -> bool:
        return self._busy

    def set_config(self, config: Config) -> None:
        self._config = config

    async def run_once(self) -> RefreshResult:
        if self._busy:
            return RefreshResult(skipped=True)
        self._busy = True
        srcs = sources_mod.all_sources()
        self._events.emit("refresh_started", source_kinds=[s.kind for s in srcs])
        result = RefreshResult()
        try:
            for src in srcs:
                source_id = store.ensure_source(self._conn, src.kind)
                run_id = store.start_run(self._conn, source_id)
                found = new = 0
                err: str | None = None
                try:
                    raw_items = await src.fetch(self._config)
                    items = [i for i in raw_items if not filters.is_av_item(i)]
                    if len(items) != len(raw_items):
                        log.info(
                            "filtered out %d audio/video item(s) from %r",
                            len(raw_items) - len(items),
                            src.kind,
                        )
                    found = len(items)
                    for item in items:
                        item_id = store.upsert_item(self._conn, source_id, item)
                        if item_id is not None:
                            new += 1
                            self._events.emit(
                                "item_discovered", item_id=item_id, source_kind=src.kind
                            )
                except Exception as exc:  # noqa: BLE001 — keep going to the next source
                    err = f"{type(exc).__name__}: {exc}"
                    result.errors.append(f"{src.kind}: {err}")
                    log.exception("source %r failed", src.kind)
                store.finish_run(self._conn, run_id, found=found, new=new, error=err)
                store.mark_source_run(self._conn, source_id)
                result.found += found
                result.new += new
        finally:
            self._busy = False
        self._events.emit(
            "refresh_finished", found=result.found, new=result.new, errors=result.errors
        )
        return result
