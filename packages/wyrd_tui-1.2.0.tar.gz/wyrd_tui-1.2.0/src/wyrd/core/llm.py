"""Optional LLM help, via the ``claude`` CLI (Claude Code in headless mode).

We shell out to ``claude -p <prompt>`` rather than calling an API directly, so
no API key wrangling — if the CLI is on ``PATH`` it works, otherwise these
helpers degrade to ``None`` and callers carry on without them.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import shutil
from collections.abc import Callable

log = logging.getLogger(__name__)

__all__ = [
    "ask",
    "available",
    "deep_research",
    "parse_stream_event",
    "suggest_feeds_and_keywords",
    "summarize_article",
]


def available() -> bool:
    return shutil.which("claude") is not None


async def ask(prompt: str, *, timeout: float = 90.0) -> str | None:
    """Run ``claude -p <prompt>`` and return its stdout, or ``None`` on any failure.

    Handles ``CancelledError`` by terminating the subprocess synchronously
    before re-raising — same shape as :func:`deep_research`. Without this,
    a Textual worker cancellation orphans the child process and Python's
    GC tries to close the transport after the loop is gone ("Event loop is
    closed" stderr trace).
    """
    if not available():
        return None
    try:
        proc = await asyncio.create_subprocess_exec(
            "claude",
            "-p",
            prompt,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except OSError:
        log.exception("failed to launch claude CLI")
        return None
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except TimeoutError:
        proc.kill()
        await proc.wait()
        log.warning("claude CLI timed out after %ss", timeout)
        return None
    except asyncio.CancelledError:
        proc.terminate()
        try:
            await asyncio.shield(asyncio.wait_for(proc.wait(), timeout=2.0))
        except (TimeoutError, asyncio.CancelledError):
            proc.kill()
            try:
                await asyncio.shield(proc.wait())
            except asyncio.CancelledError:
                pass
        raise
    if proc.returncode != 0:
        log.warning("claude CLI exited %s: %s", proc.returncode, err.decode(errors="replace")[:500])
        return None
    return out.decode(errors="replace").strip() or None


def _extract_json(text: str):
    """Pull the first JSON object/array out of *text*, tolerating ``` fences and prose."""
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
    candidates = [fenced.group(1)] if fenced else []
    candidates.append(text)
    for candidate in candidates:
        candidate = candidate.strip()
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            pass
        match = re.search(r"(\{.*\}|\[.*\])", candidate, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                pass
    return None


# --- deep research (streaming) ---------------------------------------------
#
# The deep-research agent leans on Claude Code's own web tools: we run the CLI
# in headless streaming mode so we can surface what it's doing (searching,
# reading papers) as it goes, then keep the final Markdown it produces.

# Web tools we let the headless agent use without prompting. Kept narrow on
# purpose — this agent reads the web and writes a paper, nothing else.
RESEARCH_TOOLS: list[str] = ["WebSearch", "WebFetch"]


def _describe_tool_use(name: str, inp: dict) -> str:
    if name == "WebSearch":
        query = str(inp.get("query") or "").strip()
        return f"🔍 Searching: {query}" if query else "🔍 Searching the web"
    if name == "WebFetch":
        url = str(inp.get("url") or "").strip()
        return f"📄 Reading: {url}" if url else "📄 Reading a page"
    return f"🛠  {name}"


def parse_stream_event(msg: dict) -> list[tuple[str, str]]:
    """Turn one ``stream-json`` line from ``claude`` into ``(kind, text)`` events.

    Kinds: ``"tool"`` (a tool call the agent made), ``"text"`` (assistant prose),
    ``"result"`` (the final output text), ``"error"`` (the run failed; *text* is
    the message). Lines we don't care about yield nothing.
    """
    out: list[tuple[str, str]] = []
    kind = msg.get("type")
    if kind == "assistant":
        for block in (msg.get("message") or {}).get("content") or []:
            if not isinstance(block, dict):
                continue
            if block.get("type") == "tool_use":
                out.append(
                    (
                        "tool",
                        _describe_tool_use(str(block.get("name") or ""), block.get("input") or {}),
                    )
                )
            elif block.get("type") == "text":
                text = " ".join(str(block.get("text") or "").split())
                if text:
                    out.append(("text", text))
    elif kind == "result":
        if msg.get("is_error") or msg.get("subtype") not in (None, "success"):
            out.append(
                ("error", str(msg.get("result") or msg.get("subtype") or "research run failed"))
            )
        else:
            result = msg.get("result")
            if isinstance(result, str) and result.strip():
                out.append(("result", result.strip()))
    return out


async def deep_research(
    prompt: str,
    *,
    timeout: float = 900.0,
    on_event: Callable[[str, str], None] | None = None,
) -> tuple[str | None, str | None]:
    """Run one deep-research pass with the ``claude`` CLI.

    Returns ``(markdown, error)`` with exactly one of them non-``None``.
    *on_event* — if given — is called ``(kind, text)`` for each progress event
    while the agent searches the web and reads sources (see
    :func:`parse_stream_event`); ``"result"`` / ``"error"`` events aren't
    forwarded to it, they become the return value.
    """
    if not available():
        return None, "the `claude` CLI isn't installed or isn't on PATH"
    args = [
        "claude",
        "-p",
        prompt,
        "--output-format",
        "stream-json",
        "--verbose",
        "--allowedTools",
        *RESEARCH_TOOLS,
    ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *args,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=16 * 1024 * 1024,  # a result line carries the whole paper
        )
    except OSError as exc:
        log.exception("failed to launch claude CLI")
        return None, f"couldn't launch claude: {exc}"

    result_md: str | None = None
    err_msg: str | None = None
    stderr_chunks: list[bytes] = []

    async def _drain_stdout() -> None:
        nonlocal result_md, err_msg
        assert proc.stdout is not None
        async for raw in proc.stdout:
            line = raw.decode(errors="replace").strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(msg, dict):
                continue
            for kind, text in parse_stream_event(msg):
                if kind == "result":
                    result_md = text
                elif kind == "error":
                    err_msg = text
                elif on_event is not None:
                    try:
                        on_event(kind, text)
                    except Exception:  # noqa: BLE001 — a bad listener shouldn't kill the run
                        log.exception("research on_event handler failed")

    async def _drain_stderr() -> None:
        assert proc.stderr is not None
        async for chunk in proc.stderr:
            stderr_chunks.append(chunk)

    try:
        await asyncio.wait_for(asyncio.gather(_drain_stdout(), _drain_stderr()), timeout=timeout)
        await asyncio.wait_for(proc.wait(), timeout=10)
    except TimeoutError:
        proc.kill()
        await proc.wait()
        return None, f"research timed out after {int(timeout)}s"
    except asyncio.CancelledError:
        # The caller (typically the research worker) was cancelled — terminate
        # the subprocess synchronously so it doesn't outlive the event loop.
        # Shielded waits below: once we're already cancelling, we must not
        # re-raise CancelledError before the child is reaped, or asyncio will
        # close the loop on top of a still-running subprocess transport.
        proc.terminate()
        try:
            await asyncio.shield(asyncio.wait_for(proc.wait(), timeout=2.0))
        except (TimeoutError, asyncio.CancelledError):
            proc.kill()
            try:
                await asyncio.shield(proc.wait())
            except asyncio.CancelledError:
                pass
        raise

    if result_md:
        return result_md, None
    if err_msg:
        return None, err_msg
    if proc.returncode:
        tail = b"".join(stderr_chunks).decode(errors="replace").strip()
        return None, (f"claude exited {proc.returncode}: {tail[:300]}").strip()
    return None, "the research agent finished without producing anything"


async def suggest_feeds_and_keywords(
    interests: str,
    *,
    existing_feeds: list[str] | None = None,
    existing_keywords: list[str] | None = None,
) -> dict[str, list[str]] | None:
    """Ask the model for RSS feeds + keywords matching a free-text interest description.

    - ``existing_feeds`` is sent as *anti-signal* (URLs uniquely identify a
      feed; we never want duplicates).
    - ``existing_keywords`` is sent as *positive direction* (topics are
      conceptual labels — the user adding "rust" wants MORE rust-shaped
      feeds, not fewer). Earlier versions of this function treated keywords
      as anti-signal and produced the surprising "I added keywords and got
      nothing new" UX. Topics aren't URLs.
    """
    interests = interests.strip()
    have_feeds = [f.strip() for f in (existing_feeds or []) if f and f.strip()]
    have_kws = [k.strip().lower() for k in (existing_keywords or []) if k and k.strip()]
    # Caller has neither free-text interests nor any keyword signal — there's
    # nothing to seed the agent with.
    if not interests and not have_kws:
        return None
    direction = ""
    if have_kws:
        direction += (
            "\n\nThe user has flagged these keywords as interesting — suggest "
            "feeds that publish about these topics specifically (and keep "
            "suggesting more in this direction even on repeat runs):\n"
        )
        direction += ", ".join(have_kws)
    avoid = ""
    if have_feeds:
        avoid += "\n\nThe user already subscribes to these feed URLs — do NOT suggest any of them again:\n"
        avoid += "\n".join(f"- {f}" for f in have_feeds)
    interest_line = f"Interests: {interests}" if interests else "Interests: (none stated)"
    prompt = (
        "I'm setting up a personal content reader. Based on the signal below, "
        "suggest real, working RSS/Atom feed URLs and a short list of keywords "
        "to flag the most interesting items.\n\n"
        f"{interest_line}"
        f"{direction}"
        f"{avoid}\n\n"
        "Respond with ONLY a JSON object, no prose, of the form:\n"
        '{"feeds": ["https://...", ...], "keywords": ["...", ...]}\n'
        "Aim for 5-12 feeds and 5-15 keywords. Prefer well-known, stable feeds. "
        "When the user has existing keywords above, lean into those topics — "
        "their list is a signal of where they want more coverage, not a list "
        "of what's already covered."
    )
    raw = await ask(prompt)
    if raw is None:
        return None
    data = _extract_json(raw)
    if not isinstance(data, dict):
        return None
    feeds = [str(f).strip() for f in data.get("feeds", []) if str(f).strip().startswith("http")]
    keywords = [str(k).strip().lower() for k in data.get("keywords", []) if str(k).strip()]
    if not feeds and not keywords:
        return None
    return {"feeds": feeds, "keywords": keywords}


# ``claude`` accepts a lot of input — but the article body can be huge
# (research papers, long-form journalism). Cap the prompt at ~24k chars
# (~6k tokens) so summarisation stays bounded; the lede + opening sections
# carry most of the signal for a 2-3 sentence brief anyway.
_SUMMARIZE_BODY_CAP = 24_000


async def summarize_article(markdown: str, *, timeout: float = 90.0) -> str | None:
    """Return a 2-3 sentence brief of *markdown*, or ``None`` on any failure.

    Called from the Feed pane's extraction worker after the article body
    lands; result is cached in ``extractions.summary_md``. Degrades silently
    when the ``claude`` CLI isn't on PATH — the reader still shows reading
    time, just without a brief.
    """
    body = (markdown or "").strip()
    if not body or not available():
        return None
    # Keep the prompt bounded; long-form articles get truncated mid-body which
    # is fine for a brief — the opening usually carries the thesis.
    if len(body) > _SUMMARIZE_BODY_CAP:
        body = body[:_SUMMARIZE_BODY_CAP].rstrip() + "\n\n[…body truncated for length…]"
    prompt = (
        "Below is the body of an article (in Markdown). Write a brief that helps "
        "the reader decide whether to read it.\n\n"
        "Requirements:\n"
        "- 2-3 sentences, no more than ~55 words total.\n"
        "- Say what the piece is actually about and what makes it distinctive — "
        "the specific claim, finding, person, or argument. Not a generic "
        "topic-level summary.\n"
        '- Plain prose. No bullets, no headings, no leading "This article ..." '
        'or "The author argues that ...". Just the brief.\n'
        "- Don't include the title; the reader already sees it.\n\n"
        "Return ONLY the brief itself, no preamble.\n\n"
        "=== ARTICLE BODY ===\n"
        f"{body}\n"
    )
    raw = await ask(prompt, timeout=timeout)
    if not raw:
        return None
    text = " ".join(raw.split()).strip()
    # Strip a markdown code fence if Claude wrapped the response.
    text = text.removeprefix("```").removesuffix("```").strip()
    return text or None
