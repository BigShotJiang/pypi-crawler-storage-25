"""Shared HTTP defaults — currently just the User-Agent string.

The UA is derived from :data:`wyrd.__version__` so it stays accurate across
releases instead of drifting (it used to be hand-typed ``wyrd/1.0`` in four
different files).
"""

from __future__ import annotations

from wyrd import __version__

__all__ = [
    "USER_AGENT",
]

USER_AGENT = f"wyrd/{__version__} (+https://codeberg.org/brhodes/wyrd; personal feed reader)"
