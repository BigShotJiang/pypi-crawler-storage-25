"""Render a research-run Markdown file for the in-app reader.

Research-only — the Feed pane renders article Markdown through Textual's
Markdown widget directly, without this preprocessing. We're doing two things
here that the feed doesn't need:

1. Strip external links so a click in the reader doesn't try to follow them
   (Textual reports the click; we can't actually open the URL anyway).
2. Inject one link the pane *can* follow — a ``file://`` URL to the on-disk
   file, which the research pane intercepts and opens in ``$EDITOR``.
"""

from __future__ import annotations

import re
from pathlib import Path

_MD_LINK_RE = re.compile(r"\[([^\]\n]*)\]\((https?://[^)\s]+)\)")
_AUTOLINK_RE = re.compile(r"<(https?://[^>\s]+)>")
_CODE_SPAN_RE = re.compile(r"`[^`\n]*`")
_URL_RE = re.compile(r"https?://[^\s<>)\]`]+")


def _neutralize_links(md: str) -> str:
    """Render external links and bare URLs as inert text — the TUI can't follow them."""

    def _unlink(match: re.Match[str]) -> str:
        label, url = match.group(1).strip(), match.group(2).strip()
        return url if (not label or label == url) else f"{label} ({url})"

    md = _AUTOLINK_RE.sub(lambda m: m.group(1), _MD_LINK_RE.sub(_unlink, md or ""))

    out: list[str] = []
    pos = 0
    for span in _CODE_SPAN_RE.finditer(md):
        out.append(_URL_RE.sub(lambda u: f"`{u.group(0)}`", md[pos : span.start()]))
        out.append(span.group(0))
        pos = span.end()
    out.append(_URL_RE.sub(lambda u: f"`{u.group(0)}`", md[pos:]))
    return "".join(out)


def display_markdown(markdown: str, *, path: Path | str | None = None) -> str:
    """The reader version of a Markdown file: external links de-clicked, a file link added."""
    md = _neutralize_links(markdown or "")
    if not path:
        return md
    path = Path(path)
    return f"📄 **[Open this file]({path.as_uri()})** · `{path}`\n\n---\n\n{md}"
