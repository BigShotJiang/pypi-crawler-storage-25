"""Orchestrate a single research run end-to-end.

This is the glue: build the brief, call the agent, parse the JSON, lay out the
run directory + per-source notes, fetch open-access full texts in parallel,
write everything to disk, and record the run in SQLite. Each step is in its
own sibling module so this file stays close to a list of phases.
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
from datetime import date

from wyrd.core import llm, store
from wyrd.core.config import Config

from ._brief import _build_prompt
from ._fulltext import _fetch_fulltexts
from ._layout import _source_filename, _source_note_text, _unique_run_dir
from ._models import Progress, ResearchResult, ResearchSource, SourceEntry
from ._output_dir import output_dir
from ._parse import _count_references, _parse_agent_output


async def run_research(
    topic: str,
    *,
    db: sqlite3.Connection,
    config: Config,
    on_event: Progress | None = None,
) -> ResearchResult:
    """Research *topic*, lay out the paper + source notes, record the run, and return the result."""
    topic = " ".join(topic.split()).strip()
    title = f"Literature review: {topic}" if topic else ""
    if not topic:
        return ResearchResult(topic="", title="", error="give me a topic to research")

    today = date.today()
    if on_event:
        on_event("status", "Briefing the research agent…")
    prompt = _build_prompt(
        topic,
        min_sources=config.research.min_sources,
        max_sources=config.research.max_sources,
        today=today.isoformat(),
    )
    try:
        raw, error = await llm.deep_research(
            prompt, timeout=float(config.research.timeout_seconds), on_event=on_event
        )
    except asyncio.CancelledError:
        # User quit the app (or otherwise cancelled). Record the interruption
        # so the run shows up in the tree / Activity modal next launch instead
        # of disappearing silently; then re-raise so the worker unwinds.
        store.record_research(db, topic=topic, title=title, error="interrupted by quit")
        raise
    if error or not raw:
        err = error or "the research agent returned nothing"
        rid = store.record_research(db, topic=topic, title=title, error=err)
        return ResearchResult(topic=topic, title=title, error=err, research_id=rid)

    if on_event:
        on_event("status", "Reading the agent's report…")
    paper_md, title, raw_sources = _parse_agent_output(raw, topic=topic)

    run_dir = _unique_run_dir(output_dir(config), topic, when=today)
    sources: list[ResearchSource] = []
    if raw_sources:
        sources_dir = run_dir / "sources"
        sources_dir.mkdir(parents=True, exist_ok=True)
        used: set[str] = set()
        plan: list[tuple[SourceEntry, str]] = []  # (entry, filename within sources/)
        for entry in raw_sources:
            fname = _source_filename(entry["n"], entry["citation"])
            stem, k = fname[:-3], 2
            while fname in used:
                fname = f"{stem}-{k}.md"
                k += 1
            used.add(fname)
            plan.append((entry, fname))

        wanted = sum(1 for e, _ in plan if e["fulltext_url"])
        if on_event and wanted:
            on_event("status", f"Fetching full text for {wanted} source(s)…")
        fulltexts = await _fetch_fulltexts([e for e, _ in plan], on_event=on_event)

        if on_event:
            on_event("status", "Saving the paper and source notes…")
        for entry, fname in plan:
            ft = fulltexts.get(entry["n"])
            (sources_dir / fname).write_text(_source_note_text(entry, ft), encoding="utf-8")
            sources.append(
                ResearchSource(
                    n=entry["n"],
                    citation=entry["citation"],
                    url=entry["url"],
                    fulltext_url=entry["fulltext_url"],
                    file=sources_dir / fname,
                    has_fulltext=ft is not None,
                )
            )
    else:
        run_dir.mkdir(parents=True, exist_ok=True)

    paper_path = run_dir / "paper.md"
    paper_path.write_text(
        paper_md if paper_md.endswith("\n") else paper_md + "\n", encoding="utf-8"
    )

    source_count = len(sources) or _count_references(paper_md)
    sources_json = json.dumps(
        [
            {
                "n": s.n,
                "citation": s.citation,
                "url": s.url,
                "fulltext_url": s.fulltext_url,
                "fulltext": s.has_fulltext,
                "file": s.file.relative_to(run_dir).as_posix(),
            }
            for s in sources
        ]
    )
    rid = store.record_research(
        db,
        topic=topic,
        title=title,
        path=str(paper_path),
        markdown=paper_md,
        source_count=source_count,
        sources_json=sources_json,
    )
    return ResearchResult(
        topic=topic,
        title=title,
        markdown=paper_md,
        path=paper_path,
        source_count=source_count,
        sources=sources,
        research_id=rid,
    )
