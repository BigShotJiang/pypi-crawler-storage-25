"""Lay out the files for one research run on disk.

A run lives in a single dated directory; the paper goes at the top and each
cited source becomes one Markdown file under ``sources/``. The dataclass
:class:`ResearchSource` records what we know about each source for later
display; this module owns the filenames and the on-disk note format.
"""

from __future__ import annotations

from datetime import date
from pathlib import Path

from wyrd.core.text import slugify

from ._models import SourceEntry


def _source_filename(n: int, citation: str) -> str:
    return f"{n:02d}-{slugify(citation, max_len=50, fallback='research')}.md"


def _source_note_text(src: SourceEntry, fulltext_md: str | None = None) -> str:
    today = date.today().isoformat()
    lines = [f"# {src['citation']}", ""]
    if src.get("url"):
        lines.append(f"- **Original:** {src['url']}")
    if src.get("fulltext_url") and fulltext_md is not None:
        lines.append(f"- **Open-access full text:** {src['fulltext_url']}  *(retrieved {today})*")
    elif src.get("fulltext_url"):
        lines.append(
            f"- **Full text:** {src['fulltext_url']}  *(could not be retrieved automatically)*"
        )
    else:
        lines.append("- _Full text: no freely-accessible copy was identified._")
    lines += ["", "## Summary (by the research agent)", "", src["summary"].strip(), ""]
    if fulltext_md is not None:
        lines += [
            "---",
            "",
            "## Full text",
            "",
            f"> Extracted from {src['fulltext_url']} on {today}. "
            "Automatic conversion (PDF→text where applicable) — formatting may be imperfect.",
            "",
            fulltext_md.strip(),
            "",
        ]
    return "\n".join(lines)


def _unique_run_dir(out_dir: Path, topic: str, *, when: date) -> Path:
    slug = slugify(topic, fallback="research")
    path = out_dir / f"{when.isoformat()}-{slug}"
    n = 2
    while path.exists():
        path = out_dir / f"{when.isoformat()}-{slug}-{n}"
        n += 1
    return path
