"""Public result types for a research run, plus internal carriers for cited sources.

- :data:`Progress` — the ``(kind, text)`` callback the pane uses to render
  live agent activity.
- :class:`SourceEntry` — the in-flight dict produced by :mod:`._parse` and
  consumed by :mod:`._fulltext`, :mod:`._layout`, and :mod:`._runner`. It's a
  ``TypedDict`` rather than a dataclass because the data starts life as JSON
  parsed from the agent's reply and stays in that shape end-to-end.
- :class:`ResearchSource` — the dataclass we store on a successful run after
  the on-disk note is written; this is what's exposed to the UI.
- :class:`ResearchResult` — the top-level result of a single run.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TypedDict

# (event_kind, payload) — used by the pane to render live agent activity.
Progress = Callable[[str, str], None]


class SourceEntry(TypedDict):
    """Internal carrier for one cited paper as it moves between phase modules.

    Produced by :func:`wyrd.core.research._parse._parse_agent_output` with these
    invariants the downstream phases rely on:

    - ``n`` is a 1-based integer; the list is sorted ascending and contains no
      duplicates.
    - ``citation`` is non-empty (defaulted to ``"Source <n>"`` if the agent
      omitted one).
    - ``fulltext_url`` is either ``""`` or an ``http://`` / ``https://`` URL —
      anything else is dropped at parse time.
    - ``summary`` is non-empty (defaulted to a placeholder if the agent omitted
      it).
    """

    n: int
    citation: str
    url: str
    fulltext_url: str
    summary: str


@dataclass(slots=True)
class ResearchSource:
    n: int
    citation: str
    url: str  # the DOI / canonical link
    fulltext_url: str  # an open-access full-text URL, if one was found
    file: Path  # the local .md note (summary, plus full text when we got it)
    has_fulltext: bool = False


@dataclass(slots=True)
class ResearchResult:
    topic: str
    title: str
    markdown: str | None = None
    path: Path | None = None  # the run's paper.md
    source_count: int = 0
    sources: list[ResearchSource] = field(default_factory=list)
    error: str | None = None
    research_id: int | None = None

    @property
    def ok(self) -> bool:
        return self.error is None and self.markdown is not None

    @property
    def dir(self) -> Path | None:
        return self.path.parent if self.path else None
