"""Builds the prompt that drives the ``claude`` CLI for a research run.

One function in this file, deliberately. The prompt is long and opinionated
(peer-reviewed only, open-access full text required, strict JSON output) and
keeping it isolated means changing the prompt doesn't touch the orchestration
code or the parser. If the agent's behaviour drifts in a future ``claude``
release, this is the only file you should need to edit.
"""

from __future__ import annotations


def _build_prompt(topic: str, *, min_sources: int, max_sources: int, today: str) -> str:
    return (
        "You are a meticulous academic research assistant. Research the topic below: gather the relevant "
        "peer-reviewed literature, write a literature-review paper, and summarise each paper you cite.\n\n"
        f'TOPIC: "{topic}"\n\n'
        "How to work:\n"
        "- Use web search and page fetches to find the relevant scholarly literature, and read the papers "
        "(at least their abstracts; full text wherever you can reach it).\n"
        "- Cite ONLY peer-reviewed academic papers: journal articles, or papers in peer-reviewed conference "
        "proceedings. Do NOT cite preprints (arXiv, bioRxiv, SSRN working papers, and the like) unless they "
        "were subsequently published in a peer-reviewed venue, and do NOT cite blog posts, news articles, "
        "Wikipedia, vendor or marketing pages, theses, or other non-peer-reviewed material. Before citing a "
        "paper, confirm it really is peer-reviewed; if you can't confirm it, drop it.\n"
        "- For each cited paper, also locate a freely and legally accessible copy of the FULL TEXT — an "
        "open-access PDF or full HTML article (the publisher's open-access version, an arXiv/preprint copy "
        "when it corresponds to the published paper, PubMed Central, an institutional or subject repository, "
        "etc.). Put its URL in `fulltext_url` (prefer a direct PDF link). Do NOT use paywalled, login-walled, "
        "or 'rent this article' pages; if there is genuinely no free full-text copy, leave `fulltext_url` "
        'empty ("").\n'
        "- Prefer well-cited and recent work; cover the major findings, methods, and disagreements.\n"
        f"- Aim for roughly {min_sources}-{max_sources} cited papers (more if the topic clearly warrants it, "
        "but never more than you actually verified).\n\n"
        "Output — return a SINGLE JSON object and NOTHING ELSE (no prose before or after, no code fence). "
        "Shape:\n\n"
        "{\n"
        '  "title": "<a precise, descriptive title for the review>",\n'
        '  "paper": "<the full review, in Markdown — structure described below>",\n'
        '  "sources": [\n'
        "    {\n"
        '      "n": 1,\n'
        '      "citation": "Author(s) (Year). Title. *Venue*. DOI or stable URL.",\n'
        '      "url": "https://doi.org/...  (the DOI or canonical link; \\"\\" if you have none)",\n'
        '      "fulltext_url": "https://...  (a freely/legally accessible full-text URL — open-access PDF or '
        'HTML; \\"\\" if none — never a paywalled or login-walled page)",\n'
        '      "summary": "<Markdown: 2-4 paragraphs on THIS paper — its research question, methods/data, '
        "key findings, and limitations. You may use ### subheadings and bullet lists. Be concrete; do not "
        'just restate the title.>"\n'
        "    }\n"
        '    // one object per cited paper; "n" must run 1, 2, 3, … and match the inline citations\n'
        "  ]\n"
        "}\n\n"
        'The "paper" Markdown must use this structure:\n\n'
        "# <title>\n\n"
        f'*Deep-research review · generated {today} · topic: "{topic}"*\n\n'
        "## Abstract\n"
        "150-250 words on what the literature collectively says.\n\n"
        "## Background\n"
        "Context and why the topic matters; define the key terms.\n\n"
        "## Themes and Findings\n"
        "Several `###` subsections, each on one sub-question or theme, *synthesising* the papers (not a "
        'paper-by-paper recap). Use inline numeric citations like [1], [3] that match the "sources" list.\n\n'
        "## Open Questions and Limitations\n"
        "What's unsettled, contested, or under-studied; weaknesses in the evidence base.\n\n"
        "## References\n"
        "A numbered list, one cited paper per line — `1. Author(s) (Year). Title. *Venue*. DOI or URL.` — "
        'with the numbers matching the "sources" list and the inline citations.\n\n'
        "Make sure the JSON is valid: escape newlines inside string values as \\n.\n"
    )
