"""Parse what the research agent returns — the JSON body and its prose pieces.

The agent is told to return a single JSON object with ``paper``, ``title``, and
``sources``, but it sometimes wraps the JSON in a code fence or returns plain
Markdown instead. The functions here are defensive: every step degrades to "I
got something usable, run with it" rather than failing the whole run.
"""

from __future__ import annotations

import re

from wyrd.core import llm

from ._models import SourceEntry

_FENCE_RE = re.compile(r"^```(?:markdown|md)?\s*\n(.*)\n```\s*$", re.DOTALL)


def _strip_outer_fence(md: str) -> str:
    md = (md or "").strip()
    match = _FENCE_RE.match(md)
    return match.group(1).strip() if match else md


_TITLE_RE = re.compile(r"^\s{0,3}#\s+(.+?)\s*$", re.MULTILINE)


def _extract_title(md: str, topic: str) -> str:
    match = _TITLE_RE.search(md)
    if match:
        title = match.group(1).strip().lstrip("#").strip()
        if title:
            return title
    return f"Literature review: {topic}"


_HEADING_RE = re.compile(r"^\s{0,3}#{1,6}\s+\S")
_REF_HEADING_RE = re.compile(
    r"^\s{0,3}#{1,6}\s+(references|bibliography|works cited|sources|citations)\s*$", re.IGNORECASE
)
_REF_LINE_RE = re.compile(r"^\s*(?:\[?\d+[.)\]]|[-*])\s+\S", re.MULTILINE)


def _count_references(md: str) -> int:
    lines = md.splitlines()
    start = next((i + 1 for i, line in enumerate(lines) if _REF_HEADING_RE.match(line)), None)
    if start is None:
        return 0
    end = next((j for j in range(start, len(lines)) if _HEADING_RE.match(lines[j])), len(lines))
    return len(_REF_LINE_RE.findall("\n".join(lines[start:end])))


def _parse_agent_output(raw: str, *, topic: str) -> tuple[str, str, list[SourceEntry]]:
    """Return ``(paper_markdown, title, sources)``; falls back to treating *raw* as the paper.

    The ``sources`` list is sorted by ``n`` ascending and deduplicated on ``n``;
    every entry meets the invariants documented on :class:`SourceEntry`.
    """
    data = llm._extract_json(raw)
    if isinstance(data, dict) and isinstance(data.get("paper"), str) and data["paper"].strip():
        paper = _strip_outer_fence(str(data["paper"]))
        title = str(data.get("title") or "").strip() or _extract_title(paper, topic)
        sources: list[SourceEntry] = []
        for i, entry in enumerate(data.get("sources") or [], start=1):
            if not isinstance(entry, dict):
                continue
            citation = " ".join(str(entry.get("citation") or "").split())
            summary = str(entry.get("summary") or "").strip()
            if not citation and not summary:
                continue
            try:
                n = int(entry.get("n", i))
            except (TypeError, ValueError):
                n = i
            ft_url = str(entry.get("fulltext_url") or entry.get("full_text_url") or "").strip()
            sources.append(
                SourceEntry(
                    n=n,
                    citation=citation or f"Source {n}",
                    url=str(entry.get("url") or "").strip(),
                    fulltext_url=ft_url
                    if ft_url.lower().startswith(("http://", "https://"))
                    else "",
                    summary=summary or "_(no summary provided)_",
                )
            )
        seen: set[int] = set()
        sources = [
            s
            for s in sorted(sources, key=lambda s: s["n"])
            if not (s["n"] in seen or seen.add(s["n"]))
        ]
        return paper, title, sources
    paper = _strip_outer_fence(raw)
    return paper, _extract_title(paper, topic), []
