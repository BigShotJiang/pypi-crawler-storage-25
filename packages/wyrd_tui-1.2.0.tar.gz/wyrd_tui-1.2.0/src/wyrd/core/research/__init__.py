"""Deep-research agent: drive ``claude`` to find peer-reviewed papers, lay out a literature-review run.

A run produces a single dated directory::

    2026-05-12-microplastics-and-human-health/
        paper.md                      # the review (inline citations: source text, not links)
        sources/
            01-smith-2020-....md      # summary + full text of one cited paper
            02-...

This package is the orchestration — the agent itself does the searching,
reading, and synthesising via the ``claude`` CLI's web tools. Each phase lives
in its own submodule:

- :mod:`._models`     — result dataclasses + the ``Progress`` callback alias
- :mod:`._output_dir` — :func:`output_dir` (Obsidian / override / data-dir resolution)
- :mod:`._brief`      — the prompt that goes to the agent
- :mod:`._parse`      — parse the agent's JSON reply back into Python
- :mod:`._fulltext`   — fetch open-access full texts for each cited paper
- :mod:`._layout`     — name and write the on-disk files
- :mod:`._render`     — format a Markdown file for the in-app reader
- :mod:`._runner`     — :func:`run_research`, the end-to-end orchestrator

Callers should import from ``wyrd.core.research`` (this module) only.
"""

from __future__ import annotations

from ._models import Progress, ResearchResult, ResearchSource
from ._output_dir import output_dir
from ._render import display_markdown
from ._runner import run_research

__all__ = [
    "Progress",
    "ResearchResult",
    "ResearchSource",
    "display_markdown",
    "output_dir",
    "run_research",
]
