"""Resolve where research runs land on disk.

Preference order: Obsidian vault (when configured) > ``[research] output_dir``
override > app data dir. The override is sandboxed under ``$HOME`` so a
copy-pasted config value can't write to system paths — point Obsidian's
``vault`` setting at a different drive if you need that.
"""

from __future__ import annotations

import logging
from pathlib import Path

from wyrd.core import paths
from wyrd.core.config import Config

log = logging.getLogger(__name__)


def _safe_output_dir(raw: str) -> Path | None:
    # The override is a convenience knob, not a "write anywhere on disk" hatch —
    # anything that resolves outside $HOME is treated as a paste accident and
    # falls back to the default. Use the Obsidian `vault` setting if you really
    # do want research files elsewhere (it's a more explicit opt-in).
    candidate = Path(raw).expanduser().resolve()
    home = Path.home().resolve()
    try:
        candidate.relative_to(home)
    except ValueError:
        return None
    return candidate


def output_dir(config: Config) -> Path:
    """Where research runs land — see module docstring for the preference order."""
    from wyrd.core import obsidian  # local import to avoid a config <-> store cycle

    obs_dir = obsidian.research_dir(config)
    if obs_dir is not None:
        obs_dir.mkdir(parents=True, exist_ok=True)
        return obs_dir
    raw = (getattr(getattr(config, "research", None), "output_dir", "") or "").strip()
    if raw:
        path = _safe_output_dir(raw)
        if path is None:
            log.warning(
                "ignoring [research] output_dir=%r (must resolve under $HOME); using default",
                raw,
            )
        else:
            path.mkdir(parents=True, exist_ok=True)
            return path
    return paths.research_dir()
