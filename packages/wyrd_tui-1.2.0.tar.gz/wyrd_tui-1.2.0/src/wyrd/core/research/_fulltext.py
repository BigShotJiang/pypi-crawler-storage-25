"""Best-effort download + Markdown conversion of each source's full-text URL.

Strictly an enhancement: a run is still considered successful if every fetch
here fails. Failures are logged but never propagated. Concurrency is bounded
so we don't hammer a single host (most full-text URLs from one run land on a
small set of OA repositories — arXiv, PubMed Central, a publisher).
"""

from __future__ import annotations

import asyncio
import logging

from wyrd.core import extract as extract_mod
from wyrd.core.text import shorten

from ._models import Progress, SourceEntry

log = logging.getLogger(__name__)

_FULLTEXT_TIMEOUT = 45.0
_FULLTEXT_CONCURRENCY = 4


async def _fetch_fulltexts(
    entries: list[SourceEntry], *, on_event: Progress | None
) -> dict[int, str]:
    """Map ``entry["n"]`` → fetched Markdown for each entry whose fetch succeeded.

    Called from :func:`wyrd.core.research._runner.run_research` after parsing
    the agent's reply and before laying out the per-source notes; the returned
    dict is keyed by the same ``n`` that ends up in the source filename.
    """
    out: dict[int, str] = {}
    sem = asyncio.Semaphore(_FULLTEXT_CONCURRENCY)

    async def _one(entry: SourceEntry) -> None:
        url = entry["fulltext_url"]
        if not url:
            return
        async with sem:
            if on_event:
                on_event("tool", f"📥 Full text: {shorten(entry['citation'], 60)}")
            try:
                md = await extract_mod.fetch_document_markdown(url, timeout=_FULLTEXT_TIMEOUT)
            except Exception as exc:  # noqa: BLE001 — full text is a nice-to-have, never fatal
                log.info("full-text fetch failed for %s: %s", url, exc)
                return
        if md and md.strip():
            out[entry["n"]] = md.strip()

    if entries:
        await asyncio.gather(*(_one(e) for e in entries), return_exceptions=True)
    return out
