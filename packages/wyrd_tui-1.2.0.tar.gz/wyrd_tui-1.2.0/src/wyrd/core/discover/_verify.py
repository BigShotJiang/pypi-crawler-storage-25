"""HEAD-verify candidate URLs in parallel before the critique pass.

Claude will occasionally hallucinate URLs even when told not to. This pass
catches the obvious cases — 404, DNS failure, redirect to an unrelated
domain, non-HTML content type — and drops them so the critique pass and the
user only ever see verified links.

A successful verify here is not a guarantee the article is what the agent
claimed; the critique pass and the user are the real quality filters. This
just drops the dead links.
"""

from __future__ import annotations

import asyncio
import logging
from urllib.parse import urlparse

import httpx

from wyrd.core.http import USER_AGENT

from ._models import Candidate

log = logging.getLogger(__name__)

_VERIFY_TIMEOUT = 10.0
_VERIFY_CONCURRENCY = 8


async def verify_candidates(candidates: list[Candidate]) -> list[Candidate]:
    """Return the subset of *candidates* whose URLs resolve to real HTML pages.

    Drops anything that 404s, doesn't resolve, redirects to a different host
    (a known cloaking pattern for stale URLs), or returns a non-text content
    type. Logs the failures at INFO so a noisy run is debuggable.
    """
    if not candidates:
        return []
    sem = asyncio.Semaphore(_VERIFY_CONCURRENCY)
    async with httpx.AsyncClient(
        timeout=_VERIFY_TIMEOUT,
        follow_redirects=True,
        headers={"User-Agent": USER_AGENT},
    ) as client:
        results = await asyncio.gather(
            *(_verify_one(client, sem, c) for c in candidates),
            return_exceptions=True,
        )
    out: list[Candidate] = []
    for candidate, result in zip(candidates, results, strict=True):
        if isinstance(result, BaseException):
            log.info("verify failed for %s: %s", candidate.url, result)
            continue
        if result:
            out.append(candidate)
    return out


async def _verify_one(
    client: httpx.AsyncClient, sem: asyncio.Semaphore, candidate: Candidate
) -> bool:
    parsed = urlparse(candidate.url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return False
    async with sem:
        # HEAD first — most servers honour it and it's cheap. Some respond 405
        # or 403 to HEAD but accept GET; fall back to a small GET in that case.
        try:
            resp = await client.head(candidate.url)
            if resp.status_code in (405, 403, 501):
                resp = await client.get(candidate.url)
        except httpx.HTTPError as exc:
            log.info("verify HEAD/GET error for %s: %s", candidate.url, exc)
            return False
    if resp.status_code >= 400:
        return False
    # Drop if a redirect carried us to a completely different host (often a
    # parked-domain / link-rot pattern). Allow www. ↔ apex shifts;
    # reject everything else.
    final_host = urlparse(str(resp.url)).netloc.lower()
    original_host = parsed.netloc.lower()
    if (
        final_host
        and original_host != final_host
        and final_host.removeprefix("www.") != original_host.removeprefix("www.")
    ):
        return False
    ctype = resp.headers.get("content-type", "").split(";", 1)[0].strip().lower()
    return not (ctype and "html" not in ctype and not ctype.startswith("text/"))
