"""LLM-driven content discovery, seeded by what the user has saved.

The Feed pane binds ``Ctrl+D`` to this package's :func:`run_discovery`. The
agent (driven through the ``claude`` CLI's WebSearch / WebFetch tools)
proposes ~40 candidate articles based on the user's saved-item history and
the active *taste profile*; we HEAD-verify the URLs, ask the agent to
re-rank in a second pass, and insert the top ~15 into ``items`` as
``source_kind = "discover"`` so they integrate with the existing like /
dismiss / save workflow.

Layout (Kotlin-style one-subject-per-file):

- :mod:`._models`   — :class:`Candidate`, :class:`DiscoveredItem`,
                      :class:`DiscoveryRunResult`, :data:`Progress`
- :mod:`._profiles` — built-in taste profiles + ``profile_hash``
- :mod:`._prompts`  — the two prompt templates (candidates pass + critique)
- :mod:`._verify`   — HEAD-verify candidate URLs before the critique
- :mod:`._runner`   — :func:`run_discovery`, the end-to-end orchestrator

Callers should import from ``wyrd.core.discover`` (this module) only.
"""

from __future__ import annotations

from ._models import Candidate, DiscoveredItem, DiscoveryRunResult, Progress
from ._profiles import BUILT_IN_PROFILES, DEFAULT_PROFILE_NAME, profile_hash
from ._runner import run_discovery

__all__ = [
    "BUILT_IN_PROFILES",
    "Candidate",
    "DEFAULT_PROFILE_NAME",
    "DiscoveredItem",
    "DiscoveryRunResult",
    "Progress",
    "profile_hash",
    "run_discovery",
]
