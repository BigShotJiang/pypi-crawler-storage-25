"""Result types for one LLM-driven discovery run.

Two carriers cross phase boundaries here:

- :class:`Candidate` — what the first-pass agent returned (URL + title + the
  agent's own rationale), before we've verified the URL is real or asked for
  a critique. ``site`` is whatever the agent claims; ``url`` is verbatim from
  the agent and must be HEAD-verified before it's trusted.
- :class:`DiscoveredItem` — a survivor: verified URL, present in the items
  table, ranked by the critique pass. ``item_id`` is set after the row lands
  in SQLite.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

# (event_kind, payload) — used to render live progress in the Feed pane, same
# shape as :data:`wyrd.core.research._models.Progress` (we don't share the
# type because the two pipelines are independent).
Progress = Callable[[str, str], None]


@dataclass(slots=True)
class Candidate:
    """One agent-suggested article, pre-verification."""

    url: str
    title: str
    site: str
    rationale: str


@dataclass(slots=True)
class DiscoveredItem:
    """One verified, critiqued, ranked-and-kept suggestion."""

    url: str
    title: str
    site: str
    rationale: str
    item_id: int | None = None  # set once the row is inserted


@dataclass(slots=True)
class DiscoveryRunResult:
    """Returned by :func:`run_discovery` — what the Feed pane displays after Ctrl+D."""

    run_id: int
    profile_name: str
    seed_count: int
    candidates_count: int
    kept_count: int
    inserted_item_ids: list[int]
    duration_seconds: float
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.error is None
