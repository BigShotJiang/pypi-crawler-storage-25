"""End-to-end orchestrator for one discovery pass — the ``Ctrl+D`` action.

The flow:

1. Pick the active profile (merging user overrides with built-ins; fall back
   to ``default`` if the configured name doesn't exist).
2. Read recent saved + dismissed items as seed material.
3. Open a ``discovery_runs`` row to record the attempt.
4. **Candidates pass:** drive ``claude`` with WebSearch + WebFetch tools to
   produce ~40 candidate URLs.
5. **Verify:** HEAD each candidate in parallel; drop dead links and
   hallucinations.
6. **Critique pass:** non-tool ``claude`` call that re-ranks survivors and
   keeps the top ~15.
7. Insert kept items into ``items`` with ``source_kind = "discover"`` and
   ``discovery_run_id`` linking back to the run row.
8. Close the run row with the final counts and duration.

Progress callbacks fire after each phase so the Feed pane can stream live
status. The runner returns a :class:`DiscoveryRunResult` summarising what
landed — the caller uses it to render the post-run toast and to refresh
the table.
"""

from __future__ import annotations

import asyncio
import logging
import sqlite3
import time

from wyrd.core import llm, store
from wyrd.core.config import Config, TasteProfile
from wyrd.core.sources import ContentItem

from ._models import Candidate, DiscoveredItem, DiscoveryRunResult, Progress
from ._profiles import BUILT_IN_PROFILES, DEFAULT_PROFILE_NAME, profile_hash
from ._prompts import candidates_prompt, critique_prompt
from ._verify import verify_candidates

log = logging.getLogger(__name__)

_SEED_LIMIT = 50
_DISMISSED_LIMIT = 30
_CANDIDATES_TARGET = 40
_KEEP_TARGET = 15
_CANDIDATES_TIMEOUT = 600.0
_CRITIQUE_TIMEOUT = 180.0


def _resolve_profile(config: Config) -> TasteProfile:
    """Look up the configured taste profile, falling back to default if unknown."""
    name = (config.discover.taste_profile or DEFAULT_PROFILE_NAME).strip()
    merged: dict[str, TasteProfile] = {**BUILT_IN_PROFILES, **config.discover.profiles}
    if name in merged:
        return merged[name]
    log.warning("taste profile %r not found; falling back to default", name)
    return merged[DEFAULT_PROFILE_NAME]


def _read_seed(db: sqlite3.Connection) -> tuple[list[sqlite3.Row], list[sqlite3.Row]]:
    """Return ``(saved_rows, dismissed_rows)`` for seeding the prompts."""
    saved = list(store.list_saved_items(db, limit=_SEED_LIMIT))
    dismissed = db.execute(
        "SELECT i.* FROM items i WHERE i.state = 'dismissed' ORDER BY i.id DESC LIMIT ?",
        (_DISMISSED_LIMIT,),
    ).fetchall()
    return saved, dismissed


def _parse_candidates(raw: str) -> list[Candidate]:
    data = llm._extract_json(raw)
    if not isinstance(data, dict):
        return []
    items = data.get("candidates")
    if not isinstance(items, list):
        return []
    out: list[Candidate] = []
    for entry in items:
        if not isinstance(entry, dict):
            continue
        url = str(entry.get("url") or "").strip()
        if not url.startswith(("http://", "https://")):
            continue
        out.append(
            Candidate(
                url=url,
                title=str(entry.get("title") or "").strip() or "(untitled)",
                site=str(entry.get("site") or "").strip(),
                rationale=str(entry.get("rationale") or "").strip(),
            )
        )
    return out


def _parse_kept(raw: str, fallback: list[Candidate]) -> list[Candidate]:
    """Parse the critique pass's reply, falling back to the verified candidates on shape failure."""
    data = llm._extract_json(raw)
    if not isinstance(data, dict):
        return fallback
    items = data.get("kept")
    if not isinstance(items, list) or not items:
        return fallback
    by_url = {c.url: c for c in fallback}
    out: list[Candidate] = []
    for entry in items:
        if not isinstance(entry, dict):
            continue
        url = str(entry.get("url") or "").strip()
        if not url:
            continue
        # Trust the critique pass for ranking + rationale, but cross-check
        # against the verified candidates list: a kept URL we didn't verify
        # is the model inventing things again.
        if url not in by_url:
            continue
        original = by_url[url]
        out.append(
            Candidate(
                url=url,
                title=str(entry.get("title") or "").strip() or original.title,
                site=str(entry.get("site") or "").strip() or original.site,
                rationale=str(entry.get("rationale") or "").strip() or original.rationale,
            )
        )
    return out or fallback


def _insert_items(
    db: sqlite3.Connection, run_id: int, kept: list[Candidate]
) -> list[DiscoveredItem]:
    """Upsert kept candidates as items with ``source_kind = "discover"``.

    Updates ``items.discovery_run_id`` on freshly inserted rows so per-profile
    like-rate stats can JOIN through it. Duplicate URLs (already in items
    from a feed or a previous discovery run) are skipped — discovery never
    re-suggests what the user is already looking at.
    """
    source_id = store.ensure_source(db, "discover")
    out: list[DiscoveredItem] = []
    for candidate in kept:
        item_id = store.upsert_item(
            db,
            source_id,
            ContentItem(
                url=candidate.url,
                title=candidate.title,
                summary=candidate.rationale or None,
                raw={"discovered_via": candidate.site or "unknown"},
            ),
        )
        if item_id is None:
            continue
        db.execute("UPDATE items SET discovery_run_id = ? WHERE id = ?", (run_id, item_id))
        out.append(
            DiscoveredItem(
                url=candidate.url,
                title=candidate.title,
                site=candidate.site,
                rationale=candidate.rationale,
                item_id=item_id,
            )
        )
    return out


def _open_run(db: sqlite3.Connection, *, profile: TasteProfile, seed_count: int) -> int:
    cur = db.execute(
        "INSERT INTO discovery_runs(ran_at, profile_name, profile_hash, seed_count) "
        "VALUES (?, ?, ?, ?)",
        (
            _now_iso(),
            profile.name,
            profile_hash(profile),
            seed_count,
        ),
    )
    rowid = cur.lastrowid
    assert rowid is not None
    return rowid


def _close_run(
    db: sqlite3.Connection,
    run_id: int,
    *,
    candidates_count: int,
    kept_count: int,
    duration_ms: int,
    error: str | None = None,
) -> None:
    db.execute(
        "UPDATE discovery_runs SET candidates_count = ?, kept_count = ?, "
        "duration_ms = ?, error = ? WHERE id = ?",
        (candidates_count, kept_count, duration_ms, error, run_id),
    )


def _now_iso() -> str:
    from datetime import UTC, datetime

    return datetime.now(UTC).isoformat()


async def run_discovery(
    *,
    db: sqlite3.Connection,
    config: Config,
    on_event: Progress | None = None,
    seed_items: list[sqlite3.Row] | None = None,
) -> DiscoveryRunResult:
    """Run one discovery pass and persist results.

    See module docstring for the phase breakdown. ``on_event`` is called as
    ``(kind, text)`` after each phase (and for streaming tool-call updates
    from the candidates pass).

    Pass ``seed_items`` to override the default "all saved items" seed — used
    by per-item discovery (``m`` on a Saved item) where the seed is just that
    one row. Dismissed-item anti-signal is read from the DB regardless.
    """
    started = time.monotonic()

    if not llm.available():
        return DiscoveryRunResult(
            run_id=0,
            profile_name=config.discover.taste_profile,
            seed_count=0,
            candidates_count=0,
            kept_count=0,
            inserted_item_ids=[],
            duration_seconds=0.0,
            error="the `claude` CLI isn't installed or isn't on PATH",
        )

    profile = _resolve_profile(config)
    default_saved, dismissed_rows = _read_seed(db)
    saved_rows = seed_items if seed_items is not None else default_saved
    seed_count = len(saved_rows)
    if seed_count == 0:
        return DiscoveryRunResult(
            run_id=0,
            profile_name=profile.name,
            seed_count=0,
            candidates_count=0,
            kept_count=0,
            inserted_item_ids=[],
            duration_seconds=0.0,
            error="no saved items yet — like a few articles first so discovery has signal to work with",
        )

    run_id = _open_run(db, profile=profile, seed_count=seed_count)
    # Track running counts so a CancelledError mid-run can close the row with
    # whatever progress we made before the user pressed Ctrl+D again.
    running_candidates = 0
    running_kept = 0
    run_closed = False

    try:
        if on_event:
            on_event("status", f"Asking Claude for candidates against {profile.name!r} profile…")

        prompt = candidates_prompt(
            profile=profile,
            saved_rows=saved_rows,
            dismissed_rows=dismissed_rows,
            target_count=_CANDIDATES_TARGET,
        )
        raw, error = await llm.deep_research(prompt, timeout=_CANDIDATES_TIMEOUT, on_event=on_event)
        if error or not raw:
            err = error or "the discovery agent returned nothing"
            duration_ms = int((time.monotonic() - started) * 1000)
            _close_run(
                db, run_id, candidates_count=0, kept_count=0, duration_ms=duration_ms, error=err
            )
            run_closed = True
            return DiscoveryRunResult(
                run_id=run_id,
                profile_name=profile.name,
                seed_count=seed_count,
                candidates_count=0,
                kept_count=0,
                inserted_item_ids=[],
                duration_seconds=time.monotonic() - started,
                error=err,
            )

        candidates = _parse_candidates(raw)
        running_candidates = len(candidates)
        if on_event:
            on_event("status", f"Verifying {len(candidates)} candidate URL(s)…")
        verified = await verify_candidates(candidates)
        if not verified:
            duration_ms = int((time.monotonic() - started) * 1000)
            msg = (
                f"{len(candidates)} candidate(s) from the agent, none verified online."
                if candidates
                else "the agent didn't return a parseable candidate list"
            )
            _close_run(
                db,
                run_id,
                candidates_count=len(candidates),
                kept_count=0,
                duration_ms=duration_ms,
                error=msg,
            )
            run_closed = True
            return DiscoveryRunResult(
                run_id=run_id,
                profile_name=profile.name,
                seed_count=seed_count,
                candidates_count=len(candidates),
                kept_count=0,
                inserted_item_ids=[],
                duration_seconds=time.monotonic() - started,
                error=msg,
            )

        if on_event:
            on_event(
                "status",
                f"Ranking {len(verified)} survivor(s) for fit against your profile…",
            )
        critique = critique_prompt(
            profile=profile,
            saved_rows=saved_rows,
            candidates=verified,
            keep_count=_KEEP_TARGET,
        )
        crit_raw = await llm.ask(critique, timeout=_CRITIQUE_TIMEOUT)
        kept = _parse_kept(crit_raw or "", fallback=verified[:_KEEP_TARGET])

        if on_event:
            on_event("status", f"Saving {len(kept)} discovered item(s)…")
        inserted = _insert_items(db, run_id, kept)
        running_kept = len(inserted)

        duration_ms = int((time.monotonic() - started) * 1000)
        _close_run(
            db,
            run_id,
            candidates_count=len(candidates),
            kept_count=len(inserted),
            duration_ms=duration_ms,
        )
        run_closed = True
    except asyncio.CancelledError:
        # User cancelled (Ctrl+D again). Close the run row with whatever
        # progress we made so the discovery_runs log isn't left half-written.
        if not run_closed:
            duration_ms = int((time.monotonic() - started) * 1000)
            _close_run(
                db,
                run_id,
                candidates_count=running_candidates,
                kept_count=running_kept,
                duration_ms=duration_ms,
                error="cancelled by user",
            )
        raise
    return DiscoveryRunResult(
        run_id=run_id,
        profile_name=profile.name,
        seed_count=seed_count,
        candidates_count=len(candidates),
        kept_count=len(inserted),
        inserted_item_ids=[d.item_id for d in inserted if d.item_id is not None],
        duration_seconds=time.monotonic() - started,
    )
