"""Built-in taste profiles for LLM-driven discovery.

A profile is a *(favor, avoid)* pair of bullet lists slotted into the
discovery prompt templates. Users can override or extend these in
``config.toml`` under ``[discover.profiles.<name>]``; built-ins exist so the
feature works on first launch without configuration.

Pick a profile that's close to what you want, then iterate the lists in
``config.toml`` (they live-reload) until discovery results feel right.
"""

from __future__ import annotations

import hashlib

from wyrd.core.config import TasteProfile

DEFAULT_PROFILE_NAME = "default"

BUILT_IN_PROFILES: dict[str, TasteProfile] = {
    "default": TasteProfile(
        name="default",
        description=(
            "Long-form journalism, original analysis, primary sources. "
            "Avoids SEO listicles and engagement bait."
        ),
        favor=(
            "Long-form journalism and reported features (~2000+ words, on-the-record sources)",
            "Original analysis or argument with new data, interviews, or measurements",
            "Essays and criticism with substantive evidence, not just opinion",
            "Primary sources: papers, datasets, original reports, court filings, government data",
            "Individual writers and independent publications with a track record",
        ),
        avoid=(
            'SEO-optimised listicles ("Top 10 ...", "X Things You Need to Know About ...")',
            "Content marketing pieces whose real purpose is to sell a SaaS or product",
            "News-aggregator clickbait (Yahoo, MSN, syndicated drama)",
            "AI-generated rewrites of other articles without original reporting",
            "Engagement-optimised opinion with no substance (modern op-ed slop)",
            "Pages that gate the article behind a newsletter signup or a hard paywall",
        ),
    ),
    "engineer": TasteProfile(
        name="engineer",
        description=(
            "Technical writing, post-mortems, primary-source engineering content. "
            "Avoids vendor blog spam and rehash content."
        ),
        favor=(
            "Detailed technical post-mortems and incident write-ups",
            "Original analysis with code samples, profiling data, or measurements",
            "Project READMEs, design documents, and architecture decision records",
            "Conference talks and academic papers in systems / programming languages / databases",
            "Long-form blog posts on individual engineers' personal sites with a track record",
        ),
        avoid=(
            'Generic "top 10 tools / frameworks / libraries" listicles',
            "AI-generated tech-stack overviews with no original insight",
            "Vendor blog posts whose real purpose is product marketing",
            "Stack Overflow rehashes and tutorial-mill content",
            '"Hot take" engineering hot-takes with no measurements behind them',
        ),
    ),
    "academic": TasteProfile(
        name="academic",
        description=(
            "Peer-reviewed papers, working papers from credible institutions, "
            "academic-adjacent magazines."
        ),
        favor=(
            "Peer-reviewed papers in established journals",
            "Working papers from credible institutions (NBER, IZA, university research centres)",
            "Academic-adjacent magazines (American Scholar, Aeon, Nautilus, Quanta)",
            "Long essays by domain experts publishing on their personal sites",
            "Conference proceedings and structured literature reviews",
        ),
        avoid=(
            "News-of-science press releases without links to the underlying paper",
            "Pop-science explainers that don't engage with primary sources",
            "Predatory-journal links and pay-to-publish content",
            "AI-summarised paper digests with no original reading",
            "Substack pieces that announce a paper without analysing it",
        ),
    ),
    "essays": TasteProfile(
        name="essays",
        description=(
            "Cultural and intellectual essays, criticism, narrative non-fiction. "
            "Long-form, substantive, voice-driven."
        ),
        favor=(
            "Cultural criticism and essays with a clear authorial voice",
            "Narrative non-fiction and personal essays grounded in reporting",
            "Book reviews and literary criticism from established review venues",
            "Long-form pieces on small magazines (n+1, The Drift, The Point, LARB)",
            "Individual essayists publishing on Substack, their own sites, or boutique outlets",
        ),
        avoid=(
            "Hot-take opinion columns with no underlying argument",
            "Content marketing dressed as personal essay",
            "AI-generated thinkpieces with no specific examples",
            "Engagement-optimised cultural commentary (rage-bait, dunk-tank)",
            "Pages with auto-playing video or aggressive newsletter modals",
        ),
    ),
}


def profile_hash(profile: TasteProfile) -> str:
    """Stable sha256 of a profile's favor + avoid lists.

    Lets the ``discovery_runs`` log distinguish a wyrd-shipped default-named
    profile from a user-edited override of the same name — important once
    we start computing per-profile like-rate stats across versions.
    """
    h = hashlib.sha256()
    for bullet in profile.favor:
        h.update(b"+")
        h.update(bullet.encode("utf-8"))
    for bullet in profile.avoid:
        h.update(b"-")
        h.update(bullet.encode("utf-8"))
    return h.hexdigest()[:16]
