"""Prompt templates for the two LLM passes in a discovery run.

Two passes, two prompts:

1. :func:`candidates_prompt` — driven through ``claude`` with ``WebSearch`` and
   ``WebFetch`` tools enabled. Slots in the user's recent saved items as
   taste signal and the active profile's favor/avoid lists as filter.
   Returns ~40 candidate articles with URLs the agent claims are real.

2. :func:`critique_prompt` — driven through ``claude -p`` with no tools. Takes
   the candidates that survived URL verification, re-reads them against the
   user's taste profile, drops the weak ones, ranks the survivors.

Both prompts demand a single JSON object as output. The runner parses with
``llm._extract_json`` (the same defensive parser the research module uses)
so a fenced ```json block, prose around the JSON, or other agent quirks
degrade gracefully.

The favor/avoid lists are user-tunable; the prompt *templates* themselves
stay in code because their structure (output shape, verify-then-insert,
JSON contract) is implementation detail, not a knob.
"""

from __future__ import annotations

import sqlite3

from wyrd.core.config import TasteProfile

from ._models import Candidate

_SEED_BODY_CHARS = 800
_DISMISSED_LIMIT = 30


def _format_bullets(items: tuple[str, ...] | list[str]) -> str:
    return "\n".join(f"- {b}" for b in items) if items else "- (none specified)"


def _format_saved_row(row: sqlite3.Row) -> str:
    """Render one saved-items row (from :func:`store.list_saved_items`) as prompt fodder.

    Rows here always carry ``tags_json``, ``notes``, and ``full_text`` —
    they come from the saved-pane query which JOINs items + saved. No
    defensive presence checks needed; the schema is the contract.
    """
    import json as _json

    title = (row["title"] or "").strip() or "(untitled)"
    url = (row["url"] or "").strip()
    tags = ""
    try:
        parsed = _json.loads(row["tags_json"] or "[]")
        if isinstance(parsed, list) and parsed:
            tags = f"\n  tags: {', '.join(str(t) for t in parsed)}"
    except (TypeError, ValueError):
        tags = ""
    notes = (row["notes"] or "").strip()
    notes_line = f"\n  user notes: {' '.join(notes.split())[:300]}" if notes else ""
    body = (row["full_text"] or "").strip()
    body_excerpt = " ".join(body.split())[:_SEED_BODY_CHARS]
    excerpt_line = f"\n  body excerpt: {body_excerpt}" if body_excerpt else ""
    return f"- {title}\n  url: {url}{tags}{notes_line}{excerpt_line}"


def _format_dismissed_row(row: sqlite3.Row) -> str:
    title = (row["title"] or "").strip() or "(untitled)"
    url = (row["url"] or "").strip()
    return f"- {title} ({url})"


def candidates_prompt(
    *,
    profile: TasteProfile,
    saved_rows: list[sqlite3.Row],
    dismissed_rows: list[sqlite3.Row],
    target_count: int = 40,
) -> str:
    """First pass: ask the agent to surface candidate articles via web tools."""
    saved_block = (
        "\n\n".join(_format_saved_row(r) for r in saved_rows) if saved_rows else "(none yet)"
    )
    dismissed_block = (
        "\n".join(_format_dismissed_row(r) for r in dismissed_rows[:_DISMISSED_LIMIT])
        if dismissed_rows
        else "(none)"
    )
    return (
        "You are helping a user discover new articles to read. Below is the "
        "user's recent reading history. Find articles on the open web that this "
        "user is likely to also like.\n\n"
        f"=== TASTE PROFILE: {profile.name} ===\n"
        f"{profile.description}\n\n"
        "FAVOR (bias strongly TOWARD pieces that fit):\n"
        f"{_format_bullets(profile.favor)}\n\n"
        "AVOID (do NOT suggest pieces that fit):\n"
        f"{_format_bullets(profile.avoid)}\n\n"
        "=== USER'S RECENTLY SAVED ARTICLES (positive signal) ===\n"
        f"{saved_block}\n\n"
        "=== USER'S RECENTLY DISMISSED ARTICLES (weak negative — may be \"didn't have time\") ===\n"
        f"{dismissed_block}\n\n"
        "=== INSTRUCTIONS ===\n"
        "Use the WebSearch and WebFetch tools to find real, currently-online "
        "articles. Do NOT invent URLs. For each candidate, briefly verify the "
        "URL works (fetch the page or read the search result snippet).\n\n"
        f"Aim for {target_count} candidates. Spread them across multiple "
        "sources — don't suggest 20 pieces from one outlet. Prefer pieces "
        "published in the last few months when relevance is similar, but "
        "older classics are fine if they fit the user's taste especially well.\n\n"
        "Return ONLY a JSON object with this exact shape, no prose around it:\n\n"
        "{\n"
        '  "candidates": [\n'
        '    {"url": "https://...", "title": "...", "site": "Publication or site name", '
        '"rationale": "one sentence on why this fits the user\'s taste"},\n'
        "    ...\n"
        "  ]\n"
        "}\n"
    )


def critique_prompt(
    *,
    profile: TasteProfile,
    saved_rows: list[sqlite3.Row],
    candidates: list[Candidate],
    keep_count: int = 15,
) -> str:
    """Second pass: re-rank verified candidates and drop the weak ones."""
    saved_block = (
        "\n\n".join(_format_saved_row(r) for r in saved_rows) if saved_rows else "(none yet)"
    )
    candidates_block = "\n".join(
        f"{i}. [{c.site}] {c.title}\n   {c.url}\n   agent rationale: {c.rationale}"
        for i, c in enumerate(candidates, start=1)
    )
    return (
        "You are filtering and ranking a list of article candidates against a "
        "user's taste profile. The candidate URLs have already been verified to "
        "exist; your job is to drop ones that don't actually fit and rank the "
        "survivors by how well they match.\n\n"
        f"=== TASTE PROFILE: {profile.name} ===\n"
        f"{profile.description}\n\n"
        "FAVOR:\n"
        f"{_format_bullets(profile.favor)}\n\n"
        "AVOID:\n"
        f"{_format_bullets(profile.avoid)}\n\n"
        "=== USER'S SAVED ARTICLES ===\n"
        f"{saved_block}\n\n"
        f"=== {len(candidates)} CANDIDATES (number them by position) ===\n"
        f"{candidates_block}\n\n"
        "=== INSTRUCTIONS ===\n"
        f"Keep the top {keep_count} candidates that genuinely fit. Drop ones "
        "that look like clickbait, content marketing, or otherwise violate "
        "AVOID. Re-rank by how well each fits the user's taste — best first. "
        "If a candidate's title or URL strongly suggests it doesn't fit (a "
        "listicle URL pattern, a known content-farm domain, etc.) drop it.\n\n"
        "Return ONLY a JSON object with this shape, no prose:\n\n"
        "{\n"
        '  "kept": [\n'
        '    {"url": "https://...", "title": "...", "site": "...", '
        '"rationale": "one sentence on why this fits, refined from the agent rationale"},\n'
        "    ...\n"
        "  ]\n"
        "}\n"
    )
