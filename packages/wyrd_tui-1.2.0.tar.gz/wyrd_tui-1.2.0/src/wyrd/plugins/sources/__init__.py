"""Built-in content sources.

Importing this package walks ``__path__`` with :mod:`pkgutil` and auto-imports
every submodule, so each one's module-scope ``sources.register(...)`` call
runs. Adding a new source is just dropping a ``.py`` file in this directory.
"""

from __future__ import annotations

import importlib
import logging
import pkgutil

log = logging.getLogger(__name__)


def _discover() -> list[str]:
    loaded: list[str] = []
    for info in pkgutil.iter_modules(__path__):
        if info.name.startswith("_"):
            continue
        try:
            importlib.import_module(f"{__name__}.{info.name}")
        except Exception:
            log.exception("failed to load source plugin %r", info.name)
            continue
        loaded.append(info.name)
    return loaded


__all__ = ["_discover"]

_discover()
