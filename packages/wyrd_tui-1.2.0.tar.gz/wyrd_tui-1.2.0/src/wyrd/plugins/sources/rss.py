"""RSS / Atom feed source.

Fetches every feed URL listed in ``config.content.feeds`` concurrently with
httpx, parses each with feedparser (off-thread, since it's synchronous), and
yields one :class:`ContentItem` per entry. A feed that errors is logged and
skipped; if *every* feed fails the source raises so the run is recorded as an
error.
"""

from __future__ import annotations

import asyncio
import html
import logging
import re
from datetime import UTC, datetime

import feedparser
import httpx

from wyrd.core.http import USER_AGENT as _USER_AGENT
from wyrd.core.sources import ContentItem, register

log = logging.getLogger(__name__)

__all__ = [
    "RssSource",
]

_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\s+")


def _clean_summary(entry: dict) -> str | None:
    raw = entry.get("summary") or (entry.get("content") or [{}])[0].get("value")
    if not raw:
        return None
    text = _WS_RE.sub(" ", html.unescape(_TAG_RE.sub(" ", raw))).strip()
    if not text:
        return None
    return text if len(text) <= 600 else text[:597].rstrip() + "…"


def _entry_datetime(entry: dict) -> datetime | None:
    for key in ("published_parsed", "updated_parsed"):
        st = entry.get(key)
        if st:
            try:
                return datetime(*st[:6], tzinfo=UTC)
            except (ValueError, TypeError):
                continue
    return None


class RssSource:
    kind = "rss"

    async def fetch(self, cfg) -> list[ContentItem]:
        feeds: list[str] = list(getattr(getattr(cfg, "content", None), "feeds", []) or [])
        if not feeds:
            return []
        async with httpx.AsyncClient(
            timeout=20.0, follow_redirects=True, headers={"User-Agent": _USER_AGENT}
        ) as client:
            results = await asyncio.gather(
                *(self._fetch_one(client, url) for url in feeds), return_exceptions=True
            )
        items: list[ContentItem] = []
        errors: list[str] = []
        for url, result in zip(feeds, results, strict=True):
            if isinstance(result, BaseException):
                errors.append(f"{url}: {result}")
                log.warning("feed %s failed: %s", url, result)
            else:
                items.extend(result)
        if errors and not items:
            raise RuntimeError(f"all {len(feeds)} feed(s) failed; e.g. {errors[0]}")
        return items

    async def _fetch_one(self, client: httpx.AsyncClient, url: str) -> list[ContentItem]:
        resp = await client.get(url)
        resp.raise_for_status()
        parsed = await asyncio.to_thread(feedparser.parse, resp.content)
        feed_title = parsed.feed.get("title") if parsed.feed else None
        out: list[ContentItem] = []
        for entry in parsed.entries:
            link = entry.get("link")
            if not link:
                continue
            enclosures = [
                {"type": enc.get("type"), "href": enc.get("href"), "length": enc.get("length")}
                for enc in (entry.get("enclosures") or [])
            ]
            out.append(
                ContentItem(
                    url=link,
                    title=entry.get("title"),
                    author=entry.get("author"),
                    summary=_clean_summary(entry),
                    published_at=_entry_datetime(entry),
                    raw={
                        "feed_url": url,
                        "feed_title": feed_title,
                        "guid": entry.get("id"),
                        "enclosures": enclosures,
                    },
                )
            )
        return out


register(RssSource())
