"""The Textual application shell.

Lays out the chrome — header, footer, a tabbed body (Feed / Saved / Research)
and the full-screen embedded terminal. Owns the long-lived objects every
screen reaches for via :attr:`self.app`: the parsed :class:`Config`, the
SQLite :class:`sqlite3.Connection`, the :class:`EventBus`, and the content
:class:`Scheduler`. Each screen overrides its ``app`` property to return
:class:`WyrdApp` so ``self.app.db``, ``self.app.config`` etc. type-check.

Shows the setup wizard on first run (no ``config.toml`` present), and starts
the hourly auto-refresh timer that fires :meth:`_do_refresh` on the same
``set_interval`` whether the user pressed ``Ctrl+R`` or the timer fired.
"""

from __future__ import annotations

import logging
import os
import sqlite3
from pathlib import Path

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.timer import Timer
from textual.widgets import Footer, Header, TabbedContent, TabPane

import wyrd.plugins.sources  # noqa: F401  — importing registers the built-in sources
from wyrd import __version__
from wyrd.core import config as config_mod
from wyrd.core import db as db_mod
from wyrd.core import paths
from wyrd.core.events import EventBus
from wyrd.core.scheduler import Scheduler
from wyrd.ui.screens.feed import FeedPane
from wyrd.ui.screens.research import ResearchPane
from wyrd.ui.screens.runs import RunsScreen
from wyrd.ui.screens.saved import SavedPane
from wyrd.ui.screens.setup import SetupScreen
from wyrd.ui.screens.terminal import TerminalScreen

logger = logging.getLogger(__name__)

__all__ = [
    "WyrdApp",
    "main",
]


def _is_valid_key(key: object) -> bool:
    if not isinstance(key, str):
        return False
    key = key.strip()
    if not key:
        return False
    for part in key.split("+"):
        part = part.strip()
        if not part:
            return False
        if any(c.isspace() or not c.isprintable() for c in part):
            return False
    return True


class WyrdApp(App[None]):
    """Single portal into the digital world."""

    TITLE = "wyrd"
    SUB_TITLE = f"v{__version__}"
    CSS_PATH = "app.tcss"

    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit", id="quit"),
        Binding("1", "show_tab('feed')", "Feed", id="feed"),
        Binding("2", "show_tab('saved')", "Saved", id="saved"),
        Binding("3", "show_tab('research')", "Research", id="research"),
        Binding("4", "open_terminal", "Terminal", id="terminal"),
        Binding("ctrl+r", "refresh_content", "Refresh", id="refresh"),
        # Discover is universal: pressing it from any tab switches to the Feed
        # and runs discovery there. Lives at App level so the user doesn't
        # have to be focused on the Feed pane for it to fire.
        Binding("ctrl+d", "discover", "Discover", id="discover"),
        Binding("f2", "open_setup", "Settings", id="setup"),
        Binding("f3", "open_runs", "Activity", id="activity"),
        Binding("f10", "drop_to_shell", "Shell", id="shell"),
        Binding("ctrl+t", "cycle_theme", "Theme", id="cycle_theme", show=False),
    ]

    def __init__(
        self,
        db_path: Path | None = None,
        *,
        open_setup_wizard: bool = True,
        auto_refresh: bool = True,
    ) -> None:
        super().__init__()
        self._first_run = not paths.config_file().exists()
        self._open_setup_wizard = open_setup_wizard
        self._auto_refresh_enabled = auto_refresh
        self._auto_refresh_timer: Timer | None = None
        self.config: config_mod.Config = config_mod.load()
        self.db: sqlite3.Connection = db_mod.connect(db_path)
        self.events = EventBus()
        self.scheduler = Scheduler(self.db, self.config, self.events)
        self._apply_keymap()

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with TabbedContent(initial="feed"):
            with TabPane("Feed", id="feed"):
                yield FeedPane()
            with TabPane("Saved", id="saved"):
                yield SavedPane()
            with TabPane("Research", id="research"):
                yield ResearchPane()
        yield Footer()

    def on_mount(self) -> None:
        try:
            self.theme = self.config.ui.theme
        except Exception:
            pass  # unknown theme name in config — fall back to the default
        if self._first_run and self._open_setup_wizard:
            self.call_after_refresh(lambda: self.push_screen(SetupScreen(first_run=True)))
        self._restart_auto_refresh()

    async def on_unmount(self) -> None:
        if self._auto_refresh_timer is not None:
            self._auto_refresh_timer.stop()
            self._auto_refresh_timer = None
        # Cancel any in-flight research run *before* closing the DB / event
        # loop so the ``claude`` subprocess is reaped while the loop is still
        # alive — otherwise we get the "Event loop is closed" stderr trace
        # when Python's GC tries to close the subprocess transport later.
        try:
            pane = self.query_one(ResearchPane)
        except Exception:  # noqa: BLE001 — pane may not be mounted (test variants)
            pane = None
        if pane is not None:
            await pane.cancel_in_flight()
        try:
            self.db.close()
        except Exception:
            pass

    # --- config -------------------------------------------------------------

    def reload_config(self) -> None:
        old_interval = self.config.general.refresh_interval_minutes
        self.config = config_mod.load()
        self.scheduler.set_config(self.config)
        self._apply_keymap()
        try:
            self.theme = self.config.ui.theme
        except Exception:
            pass
        if self.config.general.refresh_interval_minutes != old_interval:
            self._restart_auto_refresh()

    # --- auto-refresh -------------------------------------------------------

    def _restart_auto_refresh(self) -> None:
        if self._auto_refresh_timer is not None:
            self._auto_refresh_timer.stop()
            self._auto_refresh_timer = None
        if not self._auto_refresh_enabled:
            return
        minutes = max(1, int(self.config.general.refresh_interval_minutes))
        self._auto_refresh_timer = self.set_interval(minutes * 60, self._auto_refresh_tick)

    def _auto_refresh_tick(self) -> None:
        if self.scheduler.busy or not self.config.content.feeds:
            return
        self.run_worker(self._do_refresh(manual=False), exclusive=True, group="refresh")

    # --- keybindings --------------------------------------------------------

    def _apply_keymap(self) -> None:
        """Apply the user's [keys] overrides to the App's keymap.

        Each Binding above has a stable `id`; Textual's `set_keymap` substitutes the
        key string for those IDs. Malformed entries fall back to the default so a
        bad config string can't make the app unreachable.
        """
        action_ids = {b.id for b in self.BINDINGS if isinstance(b, Binding) and b.id}
        keymap: dict[str, str] = {}
        for name, default in config_mod.DEFAULT_KEYS.items():
            if name not in action_ids:
                continue
            requested = getattr(self.config.keys, name, default)
            if _is_valid_key(requested):
                keymap[name] = requested
            else:
                logger.warning(
                    "Invalid key binding for %r: %r — falling back to %r",
                    name,
                    requested,
                    default,
                )
                keymap[name] = default
        self.set_keymap(keymap)

    # --- actions ------------------------------------------------------------

    def action_show_tab(self, tab: str) -> None:
        self.query_one(TabbedContent).active = tab

    def action_open_terminal(self) -> None:
        self.push_screen(TerminalScreen())

    def action_open_setup(self) -> None:
        self.push_screen(SetupScreen())

    def action_open_runs(self) -> None:
        self.push_screen(RunsScreen())

    def action_drop_to_shell(self) -> None:
        """Suspend the TUI and hand the real terminal to ``$SHELL``."""
        shell = os.environ.get("SHELL") or "/bin/sh"
        with self.suspend():
            os.system(shell)

    def action_refresh_content(self) -> None:
        if self.scheduler.busy:
            self.notify("Already refreshing…", title="wyrd")
            return
        if not self.config.content.feeds:
            self.notify(
                "No feeds configured — press F2 to add some.",
                severity="warning",
            )
            return
        self.notify("Refreshing…", title="wyrd")
        self.run_worker(self._do_refresh(manual=True), exclusive=True, group="refresh")

    def action_discover(self) -> None:
        """Switch to the Feed tab and trigger discovery there.

        Universal binding — fires regardless of focused widget. Delegates to
        :meth:`FeedPane.action_discover` so the consent gate, status row, and
        worker plumbing all live in one place.
        """
        self.query_one(TabbedContent).active = "feed"
        pane = self.query_one(FeedPane)
        pane.action_discover()

    def action_cycle_theme(self) -> None:
        names = list(self.available_themes.keys())
        if not names:
            return
        try:
            i = names.index(self.theme)
        except ValueError:
            i = -1
        new = names[(i + 1) % len(names)]
        self.theme = new
        try:
            config_mod.write(
                refresh_interval_minutes=self.config.general.refresh_interval_minutes,
                feeds=self.config.content.feeds,
                keywords=self.config.content.keywords,
                theme=new,
                research=self.config.research,
                discover=self.config.discover,
                keys=self.config.keys,
                obsidian=self.config.obsidian,
            )
            self.config = config_mod.load()
            self.scheduler.set_config(self.config)
        except Exception:
            logger.exception("Failed to persist cycled theme")
        self.notify(new, title="Theme")

    async def _do_refresh(self, *, manual: bool = True) -> None:
        result = await self.scheduler.run_once()
        if result.skipped:
            return
        # Auto-refresh stays silent when there's nothing to report; manual refresh
        # always confirms it ran.
        if not manual and result.new == 0 and not result.errors:
            return
        msg = f"{result.new} new ({result.found} found)"
        if result.errors:
            msg += f" — {len(result.errors)} error(s)"
        self.notify(
            msg,
            title="Refresh complete",
            severity="warning" if result.errors else "information",
        )


def main() -> None:
    WyrdApp().run()


if __name__ == "__main__":
    main()
