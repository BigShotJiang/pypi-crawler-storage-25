"""Helpers for building the research tree on the left of the pane.

:func:`_parse_source_notes` reads the ``sources_json`` blob stored against a
run and returns ``(label, path)`` pairs for the cited-source notes. For older
runs that predate ``sources_json`` (or whose blob failed to parse), it falls
back to listing the ``sources/`` directory directly.

:func:`_path_from_file_uri` decodes a ``file://`` URI the in-pane Markdown
widget hands us when the user clicks the file link injected by
:func:`wyrd.core.research.display_markdown`.
"""

from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import unquote, urlparse

from wyrd.core.text import shorten


def _parse_source_notes(sources_json: str | None, run_dir: Path) -> list[tuple[str, Path]]:
    """``[(label, absolute path)]`` for each cited-paper note recorded for a run."""
    notes: list[tuple[str, Path]] = []
    parsed = None
    if sources_json:
        try:
            parsed = json.loads(sources_json)
        except (TypeError, json.JSONDecodeError):
            parsed = None
    if isinstance(parsed, list) and parsed:
        for entry in parsed:
            if not isinstance(entry, dict) or not entry.get("file"):
                continue
            cite = shorten(str(entry.get("citation") or entry["file"]), 48)
            n = entry.get("n")
            label = f"[{n}] {cite}" if n is not None else cite
            if entry.get("fulltext"):
                label += "  ✓"
            notes.append((label, run_dir / entry["file"]))
        return notes
    # older runs (or a missing sources_json): fall back to listing the sources/ folder
    folder = run_dir / "sources"
    if folder.is_dir():
        notes = [(p.stem, p) for p in sorted(folder.glob("*.md"))]
    return notes


def _path_from_file_uri(uri: str) -> Path:
    return Path(unquote(urlparse(uri).path))
