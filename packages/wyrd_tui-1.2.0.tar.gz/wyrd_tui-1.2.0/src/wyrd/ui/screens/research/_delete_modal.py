"""Modal confirmation before a research run is deleted.

Yes/no with the obvious shortcuts (``Esc`` cancel, ``y`` confirm) — and a clear
statement of *what* is going to be removed: the whole run folder when we have
one, or a single file as a fallback. Lives in its own file so it isn't visual
noise in the pane module.
"""

from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Label

from wyrd.core.text import shorten


class _ConfirmDelete(ModalScreen[bool]):
    """A small yes/no over the Research pane before we delete a run (paper + source notes)."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
        Binding("y", "confirm", "Delete"),
    ]

    DEFAULT_CSS = """
    _ConfirmDelete { align: center middle; }
    _ConfirmDelete #box {
        width: 70; max-width: 90%; height: auto; padding: 1 2;
        border: round $error; background: $surface;
    }
    _ConfirmDelete #box Label { width: 100%; margin-bottom: 1; }
    _ConfirmDelete .muted { color: $text-muted; }
    _ConfirmDelete #buttons { height: auto; align-horizontal: right; }
    _ConfirmDelete #buttons Button { margin-left: 2; }
    """

    def __init__(self, *, topic: str, target: Path | None) -> None:
        super().__init__()
        self._topic = topic
        self._target = target

    def compose(self) -> ComposeResult:
        with Vertical(id="box"):
            yield Label(f"Delete the research on “{shorten(self._topic, 50)}”?")
            if self._target is None:
                yield Label("(There's nothing on disk for this entry.)", classes="muted")
            elif self._target.is_dir():
                yield Label(
                    f"This permanently deletes the whole folder — the review and every source note:\n{self._target}",
                    classes="muted",
                )
            else:
                yield Label(f"This permanently deletes the file:\n{self._target}", classes="muted")
            with Horizontal(id="buttons"):
                yield Button("Cancel", id="cancel")
                yield Button("Delete", id="confirm", variant="error")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "confirm")

    def action_cancel(self) -> None:
        self.dismiss(False)

    def action_confirm(self) -> None:
        self.dismiss(True)
