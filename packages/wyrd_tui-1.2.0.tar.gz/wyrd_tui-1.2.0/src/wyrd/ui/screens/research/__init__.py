"""Research pane — the deep-research tab.

One Kotlin-style file per subject:

- :mod:`._pane`         — :class:`ResearchPane`, the widget mounted in the tab
- :mod:`._delete_modal` — the yes/no modal that gates run deletion
- :mod:`._tree`         — tree-building helpers (source-note listing, file URIs)

Callers should import :class:`ResearchPane` from ``wyrd.ui.screens.research``.
"""

from __future__ import annotations

from ._pane import ResearchPane

__all__ = ["ResearchPane"]
