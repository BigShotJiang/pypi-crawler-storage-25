"""Feed pane — the stream of discovered content.

Left: a table of items that are `new`/`seen` (newest first). Right: an in-app
reader. Highlighting an item marks it `seen` and (lazily, in the background)
fetches the page and turns it into Markdown with trafilatura so you can read it
without leaving the TUI. Results are cached in the `extractions` table — the
same item never gets fetched twice.

`l` likes the item (snapshots it into the Saved pane), `d` dismisses it, and
`o` opens it in a real browser if the in-app reader can't make sense of the page.
"""

from __future__ import annotations

import asyncio
import logging
import sqlite3
import webbrowser
from typing import TYPE_CHECKING, Literal, cast

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.coordinate import Coordinate
from textual.css.query import NoMatches
from textual.timer import Timer
from textual.widget import Widget
from textual.widgets import DataTable, Input, Markdown, Static

from wyrd.core import discover as discover_mod
from wyrd.core import extract as extract_mod
from wyrd.core import llm, obsidian, store
from wyrd.core.scoring import score_item
from wyrd.core.text import shorten
from wyrd.ui import _reader
from wyrd.ui.screens._discovery import DiscoveryConsentModal

log = logging.getLogger(__name__)

__all__ = [
    "FeedPane",
]

if TYPE_CHECKING:
    from wyrd.ui.app import WyrdApp


ViewMode = Literal["all", "interesting", "ranked"]
_MODE_LABELS: dict[ViewMode, str] = {
    "all": "view: all  ·  press [b]f[/] to filter",
    "interesting": "view: interesting only (★)  ·  press [b]f[/] to cycle",
    "ranked": "view: ranked by keyword score  ·  press [b]f[/] to cycle",
}
_MODE_ORDER: list[ViewMode] = ["all", "interesting", "ranked"]


class FeedPane(Widget):
    @property
    def app(self) -> WyrdApp:  # type: ignore[override]
        return cast("WyrdApp", super().app)

    BINDINGS = [
        Binding("l", "like", "Like / save"),
        Binding("d", "dismiss", "Dismiss"),
        Binding("o", "open_in_browser", "Open in browser"),
        Binding("y", "copy_url", "Copy URL"),
        Binding("ctrl+shift+y", "copy_article_markdown", "Copy article + URL"),
        # ``ctrl+d`` for discovery is at the App level (see ``WyrdApp.BINDINGS``)
        # so it works from any tab — but the implementation lives here.
        Binding("enter", "exit_focus_reader", "Exit reader", show=False),
        # ``f5`` rather than the more mnemonic ``f`` so it can't shadow a user
        # who remaps an App-level tab key onto a single letter. Pending the
        # filter/search redesign (TODO-1.0.1.md) — at that point this binding
        # likely goes away entirely.
        Binding("f5", "cycle_filter", "Filter"),
        Binding("f4", "toggle_focus", "Focus reader"),
        Binding("slash", "focus_search", "Search", show=False),
        Binding("escape", "close_search", "Close search", show=False),
    ]

    DEFAULT_CSS = """
    FeedPane { layout: horizontal; height: 1fr; }
    FeedPane #feed-left { width: 50%; }
    FeedPane #feed-search { margin: 0 0 1 0; }
    FeedPane #feed-mode { height: 1; color: $text-muted; padding: 0 1; }
    FeedPane #feed-table { height: 1fr; }
    FeedPane #feed-reader { width: 1fr; border-left: solid $panel-darken-1; padding: 0 2; }
    FeedPane.focus-reader #feed-left { display: none; }
    FeedPane.focus-reader #feed-reader { border-left: none; }
    """

    def __init__(self) -> None:
        super().__init__()
        self._items: list[sqlite3.Row] = []
        self._unsubs: list = []
        self._extracting: set[int] = set()
        self._search_timer: Timer | None = None
        self._mode: ViewMode = "all"
        self._discover_busy = False
        self._discover_last_status = ""
        # The worker reference is captured in ``_begin_discovery`` so we can
        # ``.cancel()`` it when Ctrl+D fires a second time (toggle semantics).
        self._discover_worker = None

    def compose(self) -> ComposeResult:
        # The search Input is mounted on demand by ``action_focus_search`` so
        # it doesn't sit in the layout (and steal initial focus) when the user
        # isn't actually searching. See :meth:`action_focus_search` for the
        # show path; :meth:`action_close_search` removes it again.
        with Vertical(id="feed-left"):
            yield Static(_MODE_LABELS["all"], id="feed-mode")
            yield DataTable(id="feed-table", cursor_type="row", zebra_stripes=True)
        yield VerticalScroll(Markdown("", id="feed-article"), id="feed-reader")

    def on_mount(self) -> None:
        table = self.query_one("#feed-table", DataTable)
        table.add_columns("", "Title", "Source", "When")
        self._unsubs = [
            self.app.events.subscribe("refresh_finished", self._on_refresh),
            self.app.events.subscribe("item_brief_ready", self._on_brief_ready),
        ]
        self.reload()
        # We don't force focus to the table on mount. Textual lands focus on
        # ContentTabs (the tab strip), where arrow keys cycle tabs and Tab
        # moves focus down into the active pane — both reasonable defaults.
        # An earlier attempt at ``table.focus()`` here let FeedPane's own
        # bindings (e.g., ``f5`` for filter cycle) shadow user-remapped
        # App-level keys in surprising ways. See TODO-1.0.1.md if we revisit.

    def on_unmount(self) -> None:
        for unsub in self._unsubs:
            unsub()
        self._unsubs = []

    def _on_refresh(self, **_) -> None:
        self.call_after_refresh(self.reload)

    def _on_brief_ready(self, *, item_id: int, **_) -> None:
        """Re-render the article if the brief landed for the currently-visible item."""
        if self._highlighted_id() != item_id:
            return
        row = store.get_item(self.app.db, item_id)
        if row is not None:
            self._render_article(row)

    # --- list ---------------------------------------------------------------

    def _keywords(self) -> list[str]:
        return list(getattr(getattr(self.app.config, "content", None), "keywords", []) or [])

    def _marker(self, row: sqlite3.Row) -> str:
        if score_item(row, self._keywords()) > 0:
            return "★"
        return "●" if row["state"] == "new" else " "

    def _apply_mode(self, rows: list[sqlite3.Row]) -> list[sqlite3.Row]:
        if self._mode == "all":
            return rows
        keywords = self._keywords()
        scored = [(score_item(r, keywords), r) for r in rows]
        if self._mode == "interesting":
            return [r for s, r in scored if s > 0]
        # ranked: sort by score desc; Python's sort is stable, so ties keep the
        # fetched (chronological) order.
        return [r for _, r in sorted(scored, key=lambda p: -p[0])]

    def reload(self, *, query: str | None = None) -> None:
        if query is None:
            try:
                query = self.query_one("#feed-search", Input).value
            except Exception:  # noqa: BLE001 — search box may not be mounted yet
                log.debug("reload before #feed-search is mounted; treating query as empty")
                query = ""
        table = self.query_one("#feed-table", DataTable)
        keep_id = self._highlighted_id()
        prev_index = table.cursor_row  # fallback when keep_id is gone (e.g., just liked/dismissed)
        if query and query.strip():
            fetched = list(store.search_feed(self.app.db, query))
        else:
            fetched = list(store.list_feed_items(self.app.db))
        self._items = self._apply_mode(fetched)
        table.clear()
        for row in self._items:
            table.add_row(
                self._marker(row),
                shorten(row["title"] or row["url"]),
                row["source_kind"],
                _reader.feed_when(row),
            )
        self._update_mode_label()
        if not self._items:
            if query and query.strip():
                self._set_article("# No matches\n\nTry a different search.")
            elif self._mode == "interesting" and fetched:
                self._set_article(
                    "# Nothing flagged interesting\n\n"
                    "No items match your configured keywords. "
                    "Press **f** to switch the view, or **F2** to edit keywords."
                )
            else:
                self._set_article(
                    "# No content yet\n\n"
                    "Press **Ctrl+R** to fetch your feeds, or **F2** to add some."
                )
            return
        # If the previously highlighted item still exists, stay on it; otherwise
        # hold the cursor position so the next item drops into view.
        found = next((i for i, r in enumerate(self._items) if r["id"] == keep_id), None)
        if found is not None:
            idx = found
        elif prev_index is not None and prev_index >= 0:
            idx = min(prev_index, len(self._items) - 1)
        else:
            idx = 0
        table.move_cursor(row=idx)
        self._show(idx)

    def _update_mode_label(self) -> None:
        try:
            self.query_one("#feed-mode", Static).update(_MODE_LABELS[self._mode])
        except Exception:  # noqa: BLE001 — mode label may not be mounted yet
            log.debug("#feed-mode not yet mounted; skipping label update")

    def action_cycle_filter(self) -> None:
        i = _MODE_ORDER.index(self._mode)
        self._mode = _MODE_ORDER[(i + 1) % len(_MODE_ORDER)]
        self.reload()

    def action_toggle_focus(self) -> None:
        self.toggle_class("focus-reader")
        # Without the search Input in compose, the table is the only focusable
        # widget in #feed-left — hiding the panel orphans focus (focused=None)
        # which breaks subsequent F4 bubble-ups. Hand focus explicitly so
        # the second F4 still reaches this binding.
        try:
            if self.has_class("focus-reader"):
                self.query_one("#feed-reader", VerticalScroll).focus()
            else:
                self.query_one("#feed-table", DataTable).focus()
        except NoMatches:
            log.debug("focus target missing during F4 toggle")

    def action_exit_focus_reader(self) -> None:
        """Symmetric with the way the user enters: Enter on a row enters focus-reader;
        Enter from focus-reader exits back to the table.

        Only fires when the focus chain doesn't hit the DataTable first (i.e. we're
        already in focus-reader mode and the table is display:none). In normal
        mode the table's own Enter binding consumes the keystroke before this
        FeedPane-level binding gets a chance.
        """
        if not self.has_class("focus-reader"):
            return
        self.action_toggle_focus()

    def _highlighted_id(self) -> int | None:
        table = self.query_one("#feed-table", DataTable)
        i = table.cursor_row
        if i is None or not (0 <= i < len(self._items)):
            return None
        return self._items[i]["id"]

    # --- reader -------------------------------------------------------------

    def _show(self, idx: int) -> None:
        row = self._items[idx]
        if row["state"] == "new":
            store.set_item_state(self.app.db, row["id"], "seen")
            row = self._items[idx] = store.get_item(self.app.db, row["id"]) or row
            try:
                self.query_one("#feed-table", DataTable).update_cell_at(
                    Coordinate(idx, 0), self._marker(row)
                )
            except Exception:
                pass
        self._render_article(row)
        # The reader keeps its own scroll position per article — reset it so the
        # new article starts at the top instead of wherever the last one left off.
        try:
            self.query_one("#feed-reader", VerticalScroll).scroll_home(animate=False)
        except Exception:
            pass

    def _render_article(self, row: sqlite3.Row) -> None:
        extraction = store.get_extraction(self.app.db, row["id"])
        lede = row["summary"]
        word_count = extraction["word_count"] if extraction is not None else None
        brief = extraction["summary_md"] if extraction is not None else None

        if extraction is not None and extraction["markdown"]:
            self._set_article(
                _reader.article_markdown(
                    row,
                    body=extraction["markdown"],
                    lede=lede,
                    word_count=word_count,
                    brief=brief,
                )
            )
            return
        if extraction is not None and extraction["error"]:
            self._set_article(
                _reader.article_markdown(
                    row,
                    body=(
                        "*Couldn't extract this page automatically.*\n\n"
                        f"`{extraction['error']}`\n\n"
                        "_Press_ `o` _to open it in a browser as a fallback._"
                    ),
                    lede=lede,
                )
            )
            return
        # not extracted yet — show what we have and kick off the worker
        self._set_article(_reader.article_markdown(row, body="*Loading article…*", lede=lede))
        self._kick_extraction(row["id"], row["url"])

    def _set_article(self, markdown: str) -> None:
        self.query_one("#feed-article", Markdown).update(markdown)

    def _kick_extraction(self, item_id: int, url: str) -> None:
        if item_id in self._extracting:
            return
        self._extracting.add(item_id)
        self.run_worker(
            self._do_extract(item_id, url),
            exclusive=False,
            group=f"extract-{item_id}",
        )

    async def _do_extract(self, item_id: int, url: str) -> None:
        markdown: str | None = None
        word_count: int | None = None
        try:
            article = await extract_mod.fetch_and_extract(url)
            markdown = article.markdown
            word_count = len(markdown.split()) if markdown else 0
            store.save_extraction(
                self.app.db,
                item_id,
                markdown=markdown,
                title=article.title,
                word_count=word_count,
            )
            self._record_feed_suggestions(item_id, article.feed_links)
        except Exception as exc:  # noqa: BLE001
            store.save_extraction(self.app.db, item_id, error=f"{type(exc).__name__}: {exc}")
        finally:
            self._extracting.discard(item_id)
        # if the user already liked this item, give the saved copy the real text
        if markdown and store.is_saved(self.app.db, item_id):
            store.update_saved(self.app.db, item_id, full_text=markdown)
            self._write_obsidian_note(item_id)
        if self._highlighted_id() == item_id:
            row = store.get_item(self.app.db, item_id)
            if row is not None:
                self._render_article(row)
        # Kick off the LLM brief in the background. The reader already shows
        # the article + reading-time line; the brief lands a few seconds later
        # via the "item_brief_ready" event so the visible pane re-renders.
        if markdown:
            self.run_worker(
                self._do_summarize(item_id, markdown),
                exclusive=False,
                group=f"summarize-{item_id}",
            )

    async def _do_summarize(self, item_id: int, markdown: str) -> None:
        """Generate and persist a brief for *item_id*. No-op when claude is absent."""
        try:
            brief = await llm.summarize_article(markdown)
        except Exception as exc:  # noqa: BLE001 — brief is best-effort
            log.warning("summarize failed for item %d: %s", item_id, exc)
            return
        if not brief:
            return
        store.save_extraction_summary(self.app.db, item_id, brief)
        self.app.events.emit("item_brief_ready", item_id=item_id)

    # --- events / actions ---------------------------------------------------

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if 0 <= event.cursor_row < len(self._items):
            self._show(event.cursor_row)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:  # noqa: ARG002
        # Enter on a row activates reader focus mode — the article fills the
        # pane. Naturally one-way: the left side is hidden, so Enter can't fire
        # again until the user comes back with F4.
        self.add_class("focus-reader")

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id != "feed-search":
            return
        if self._search_timer is not None:
            self._search_timer.stop()
        self._search_timer = self.set_timer(0.25, self.reload)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "feed-search":
            if self._search_timer is not None:
                self._search_timer.stop()
                self._search_timer = None
            self.reload(query=event.value)

    def action_focus_search(self) -> None:
        """Mount the search Input above the table (idempotent) and focus it."""
        try:
            inp = self.query_one("#feed-search", Input)
        except NoMatches:
            inp = Input(placeholder="search feed…", id="feed-search")
            self.query_one("#feed-left", Vertical).mount(inp, before="#feed-mode")
        inp.focus()

    def action_close_search(self) -> None:
        """Tear down the search box and return focus to the table.

        No-op when the search box isn't open, so Escape outside search mode
        falls through harmlessly.
        """
        try:
            inp = self.query_one("#feed-search", Input)
        except NoMatches:
            return
        inp.remove()
        self.query_one("#feed-table", DataTable).focus()
        self.reload(query="")

    def _current_row(self) -> sqlite3.Row | None:
        i = self.query_one("#feed-table", DataTable).cursor_row
        if i is None or not (0 <= i < len(self._items)):
            return None
        return self._items[i]

    def action_like(self) -> None:
        row = self._current_row()
        if row is None:
            return
        extraction = store.get_extraction(self.app.db, row["id"])
        full_text = extraction["markdown"] if extraction else None
        store.like_item(self.app.db, row["id"], full_text=full_text)
        if full_text is None:
            # body not extracted yet; the worker will write the Obsidian note
            # once it lands (see _do_extract).
            self._kick_extraction(row["id"], row["url"])
        else:
            self._write_obsidian_note(row["id"])
        self.app.events.emit("item_saved", item_id=row["id"])
        title = shorten(row["title"] or row["url"], 48)
        self.notify(f"Saved: {title}", title="Liked")
        self.reload()

    def _record_feed_suggestions(
        self, item_id: int, feed_links: list[extract_mod.FeedLink]
    ) -> None:
        """Persist any RSS feeds advertised by the article's <head>.

        Skips feeds the user is already subscribed to (case-insensitive URL
        match) so the wizard's "Suggested feeds" list only contains genuinely
        new candidates. The setup wizard renders open suggestions; one-click
        subscribe / dismiss is wired in phase 3 of the 1.2 work.
        """
        if not feed_links:
            return
        already_subscribed = {f.strip().lower() for f in self.app.config.content.feeds}
        for link in feed_links:
            if link.feed_url.strip().lower() in already_subscribed:
                continue
            store.add_feed_suggestion(
                self.app.db,
                feed_url=link.feed_url,
                site_url=link.site_url,
                site_title=link.site_title,
                source_item_id=item_id,
            )

    def _write_obsidian_note(self, item_id: int) -> None:
        """Mirror the saved snapshot to the Obsidian vault, if one is configured."""
        if not obsidian.enabled(self.app.config):
            return
        item = store.get_item(self.app.db, item_id)
        saved = store.get_saved(self.app.db, item_id)
        if item is None or saved is None or not saved["full_text"]:
            return
        path = obsidian.write_saved_note(self.app.config, item, saved, saved["full_text"])
        if path is not None:
            self.notify(f"Obsidian: {path.name}", title="Vault")

    def action_dismiss(self) -> None:
        row = self._current_row()
        if row is None:
            return
        store.dismiss_item(self.app.db, row["id"])
        self.notify(f"Dismissed: {shorten(row['title'] or row['url'], 48)}")
        self.reload()

    def on_markdown_link_clicked(self, event: Markdown.LinkClicked) -> None:
        """Intercept link clicks in the article reader.

        Textual's default behaviour ``self.app.open_url(href)`` ends up calling
        ``webbrowser.open`` on Linux, which in a TUI terminal can produce a
        flashing notification that's too fast to read (and isn't reliable on
        headless systems anyway). We swap that for an OSC 52 clipboard copy
        plus a longer-lived notify the user can actually catch.
        """
        event.stop()
        href = (event.href or "").strip()
        if not href:
            return
        try:
            self.app.copy_to_clipboard(href)
            self.notify(
                f"Copied: {shorten(href, 60)}",
                title="Link",
                timeout=8.0,
            )
        except Exception as exc:  # noqa: BLE001 — clipboard failures shouldn't crash the pane
            log.warning("OSC 52 copy failed: %s", exc)
            self.notify(href, title="Link (copy failed)", severity="warning", timeout=12.0)

    def action_copy_url(self) -> None:
        row = self._current_row()
        if row is None or not row["url"]:
            return
        url = row["url"]
        self.app.copy_to_clipboard(url)
        self.notify(f"Copied: {shorten(url, 60)}", title="Clipboard")

    def action_copy_article_markdown(self) -> None:
        """Copy the highlighted article (URL + brief + body) to the clipboard as Markdown.

        Different from ``y`` (URL only). Useful when you want to share the
        actual piece — e.g., pasting a misrendered article into a bug report.
        Falls back to URL-only when the article hasn't been extracted yet.
        """
        row = self._current_row()
        if row is None or not row["url"]:
            return
        extraction = store.get_extraction(self.app.db, row["id"])
        body = extraction["markdown"] if extraction and extraction["markdown"] else None
        if not body:
            # Nothing extracted yet — degrade to URL + title so the action still does *something*.
            self.app.copy_to_clipboard(f"# {row['title'] or '(untitled)'}\n\n<{row['url']}>\n")
            self.notify(
                "Copied URL + title (article body not extracted yet)",
                title="Clipboard",
                timeout=6.0,
            )
            return
        brief = extraction["summary_md"] if extraction else None
        word_count = extraction["word_count"] if extraction else None
        markdown = _reader.article_markdown(
            row, body=body, lede=row["summary"], word_count=word_count, brief=brief
        )
        self.app.copy_to_clipboard(markdown)
        n_words = f"~{word_count:,} words" if word_count else "no word count"
        self.notify(
            f"Copied article + URL ({n_words}) to clipboard.",
            title="Clipboard",
            timeout=6.0,
        )

    # --- discovery ----------------------------------------------------------

    def action_discover(self) -> None:
        """Toggle bulk content discovery seeded by the user's saved items.

        Pressing ``Ctrl+D`` while no run is active starts one. Pressing it
        again while a run is in flight cancels it — the worker raises
        ``CancelledError``, ``llm.deep_research`` terminates its subprocess,
        and ``_do_discover`` notifies "Discovery cancelled" before unwinding.

        First-ever press goes through a one-time consent modal that persists
        its answer in ``meta('discovery_consent')``; subsequent presses skip
        the modal and run discovery immediately.
        """
        if self._discover_busy:
            self._cancel_discovery()
            return
        if not store.get_meta(self.app.db, "discovery_consent"):
            self.app.push_screen(DiscoveryConsentModal(), self._on_discover_consent)
            return
        self._begin_discovery(seed_items=None)

    def _on_discover_consent(self, accepted: bool | None) -> None:
        if not accepted:
            return
        store.set_meta(self.app.db, "discovery_consent", "yes")
        self._begin_discovery(seed_items=None)

    def _begin_discovery(self, *, seed_items: list[sqlite3.Row] | None) -> None:
        self._discover_busy = True
        self._discover_last_status = "starting…"
        self._mount_discover_status()
        self._discover_worker = self.run_worker(
            self._do_discover(seed_items),
            exclusive=True,
            group="discover",
        )

    def _cancel_discovery(self) -> None:
        """Cancel the in-flight discovery worker. Safe to call when nothing's running."""
        worker = self._discover_worker
        if worker is None:
            return
        worker.cancel()

    def _mount_discover_status(self) -> None:
        """Insert a Static row at the top of #feed-left to render live progress."""
        try:
            self.query_one("#feed-discover-status", Static)
            return  # already mounted
        except NoMatches:
            pass
        bar = Static(self._format_discover_status(), id="feed-discover-status")
        feed_left = self.query_one("#feed-left", Vertical)
        # Place above the existing mode label so it doesn't shift the table.
        feed_left.mount(bar, before="#feed-mode")

    def _unmount_discover_status(self) -> None:
        try:
            self.query_one("#feed-discover-status", Static).remove()
        except NoMatches:
            pass

    def _format_discover_status(self) -> str:
        return f"🔭 Discover · {self._discover_last_status}"

    def _on_discover_event(self, kind: str, text: str) -> None:
        # Tool-call events stream past quickly (one per WebSearch / WebFetch);
        # status events are the phase markers we actually want pinned.
        if kind == "status" or kind == "tool":
            self._discover_last_status = text
        else:
            return
        try:
            self.query_one("#feed-discover-status", Static).update(self._format_discover_status())
        except NoMatches:
            pass

    async def _do_discover(self, seed_items: list[sqlite3.Row] | None) -> None:
        result = None
        cancelled = False
        try:
            result = await discover_mod.run_discovery(
                db=self.app.db,
                config=self.app.config,
                on_event=self._on_discover_event,
                seed_items=seed_items,
            )
        except asyncio.CancelledError:
            # User pressed Ctrl+D again. The subprocess in llm.deep_research
            # is already terminating via its own CancelledError handler; we
            # just need to surface the cancellation and let the worker unwind.
            cancelled = True
            raise
        except Exception as exc:  # noqa: BLE001
            self.notify(
                f"Discovery crashed: {type(exc).__name__}: {exc}",
                severity="error",
                timeout=12.0,
            )
        finally:
            self._discover_busy = False
            self._discover_worker = None
            self._unmount_discover_status()
            if cancelled:
                self.notify("Discovery cancelled.", title="Discover", timeout=4.0)

        if result is None:
            return
        if result.ok:
            self.notify(
                f"Discovered {result.kept_count} new item(s) via "
                f"'{result.profile_name}' profile · {int(result.duration_seconds)}s",
                title="Discover",
                timeout=8.0,
            )
            self.reload()
        else:
            self.notify(
                f"Discovery: {result.error}",
                severity="warning",
                title="Discover",
                timeout=10.0,
            )

    def action_open_in_browser(self) -> None:
        row = self._current_row()
        if row is None:
            return
        url = row["url"]
        try:
            webbrowser.open(url)
        except Exception as exc:  # noqa: BLE001
            self.notify(f"Couldn't open a browser: {exc}", severity="warning")
        else:
            self.notify(f"Opened {url}", title="Feed")
