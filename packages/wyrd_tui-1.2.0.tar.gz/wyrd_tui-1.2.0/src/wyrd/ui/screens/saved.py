"""Saved pane — items you've liked, with the article snapshot, tags and notes.

Left: a search box over a table of saved items (newest first). Right: editable
**Tags** (comma-separated) and **Notes** fields above the article rendered as
Markdown. Edits are written back when you move to another item, on Ctrl+S, and
when the pane closes. Search (``/`` focuses the box) is FTS5-backed via
:func:`wyrd.core.store.search_saved` and covers title / summary / URL /
article text / notes / tags in one ``MATCH`` query.
"""

from __future__ import annotations

import logging
import sqlite3
from typing import TYPE_CHECKING, cast

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.widget import Widget
from textual.widgets import DataTable, Input, Markdown, TextArea

from wyrd.core import discover as discover_mod
from wyrd.core import store
from wyrd.core.text import shorten
from wyrd.ui import _reader
from wyrd.ui.screens._discovery import DiscoveryConsentModal

log = logging.getLogger(__name__)

__all__ = [
    "SavedPane",
]

if TYPE_CHECKING:
    from wyrd.ui.app import WyrdApp


class SavedPane(Widget):
    @property
    def app(self) -> WyrdApp:  # type: ignore[override]
        return cast("WyrdApp", super().app)

    BINDINGS = [
        Binding("ctrl+s", "save_meta", "Save tags/notes"),
        Binding("y", "copy_url", "Copy URL"),
        Binding("ctrl+shift+y", "copy_article_markdown", "Copy article + URL"),
        Binding("m", "discover_like_this", "Find more like this"),
        Binding("f4", "toggle_focus", "Focus reader"),
        Binding("enter", "exit_focus_reader", "Exit reader", show=False),
        Binding("slash", "focus_search", "Search", show=False),
    ]

    DEFAULT_CSS = """
    SavedPane { layout: horizontal; height: 1fr; }
    SavedPane #saved-left { width: 45%; }
    SavedPane #saved-search { margin: 0 0 1 0; }
    SavedPane #saved-table { height: 1fr; }
    SavedPane #saved-right { width: 1fr; border-left: solid $panel-darken-1; padding: 0 1; }
    SavedPane #saved-tags { border: round $panel; }
    SavedPane #saved-notes { border: round $panel; height: 6; }
    SavedPane #saved-article-wrap { height: 1fr; padding: 0 1; }
    SavedPane.focus-reader #saved-left { display: none; }
    SavedPane.focus-reader #saved-right { border-left: none; }
    """

    def __init__(self) -> None:
        super().__init__()
        self._items: list[sqlite3.Row] = []
        self._discover_busy = False
        self._current_id: int | None = None
        self._unsubs: list = []

    def compose(self) -> ComposeResult:
        with Vertical(id="saved-left"):
            yield Input(placeholder="search saved…", id="saved-search")
            yield DataTable(id="saved-table", cursor_type="row", zebra_stripes=True)
        with Vertical(id="saved-right"):
            tags = Input(id="saved-tags", placeholder="comma, separated, tags")
            tags.border_title = "Tags"
            yield tags
            notes = TextArea(id="saved-notes")
            notes.border_title = "Notes"
            yield notes
            yield VerticalScroll(Markdown("", id="saved-article"), id="saved-article-wrap")

    def on_mount(self) -> None:
        self.query_one("#saved-table", DataTable).add_columns("Title", "Source", "Saved")
        self._unsubs = [
            self.app.events.subscribe(
                "item_saved", lambda **_: self.call_after_refresh(self.reload)
            ),
            self.app.events.subscribe("item_brief_ready", self._on_brief_ready),
        ]
        self.reload()

    def _on_brief_ready(self, *, item_id: int, **_) -> None:
        """Re-render the visible article when its brief finishes generating."""
        if self._current_id != item_id:
            return
        self.call_after_refresh(self._show_current)

    def on_unmount(self) -> None:
        self._flush_current()
        for unsub in self._unsubs:
            unsub()
        self._unsubs = []

    # --- list ---------------------------------------------------------------

    def reload(self, *, query: str | None = None) -> None:
        self._flush_current()
        if query is None:
            query = self.query_one("#saved-search", Input).value
        table = self.query_one("#saved-table", DataTable)
        keep_id = self._current_id
        self._items = list(store.list_saved_items(self.app.db, query=query))
        table.clear()
        for row in self._items:
            table.add_row(
                shorten(row["title"] or row["url"], 64),
                row["source_kind"],
                _reader.fmt_when(row["saved_at"]),
            )
        if not self._items:
            self._current_id = None
            self.query_one("#saved-tags", Input).value = ""
            self.query_one("#saved-notes", TextArea).load_text("")
            empty = "# Nothing matches" if (query or "").strip() else "# Nothing saved yet"
            hint = (
                "Try a different search."
                if (query or "").strip()
                else "Press **l** on an item in the Feed to save it here."
            )
            self.query_one("#saved-article", Markdown).update(f"{empty}\n\n{hint}")
            return
        idx = next((i for i, r in enumerate(self._items) if r["id"] == keep_id), 0)
        table.move_cursor(row=idx)
        self._show(idx)

    def _show(self, idx: int) -> None:
        row = self._items[idx]
        self._current_id = row["id"]
        self.query_one("#saved-tags", Input).value = ", ".join(store.parse_tags(row["tags_json"]))
        self.query_one("#saved-notes", TextArea).load_text(row["notes"] or "")
        body = row["full_text"]
        extraction = store.get_extraction(self.app.db, row["id"])
        if not body:
            body = extraction["markdown"] if extraction and extraction["markdown"] else None
        word_count = extraction["word_count"] if extraction is not None else None
        brief = extraction["summary_md"] if extraction is not None else None
        self.query_one("#saved-article", Markdown).update(
            _reader.article_markdown(
                row,
                body=body or "*(no article text saved)*",
                lede=row["summary"],
                word_count=word_count,
                brief=brief,
            )
        )

    def _show_current(self) -> None:
        """Re-render the article block for ``self._current_id`` — used by the brief-ready event."""
        if self._current_id is None:
            return
        idx = next((i for i, r in enumerate(self._items) if r["id"] == self._current_id), None)
        if idx is not None:
            self._show(idx)

    # --- editing ------------------------------------------------------------

    def _flush_current(self) -> None:
        if self._current_id is None:
            return
        try:
            tags = [
                t.strip()
                for t in self.query_one("#saved-tags", Input).value.split(",")
                if t.strip()
            ]
            notes = self.query_one("#saved-notes", TextArea).text
        except Exception:
            return  # widgets not mounted (e.g. during teardown)
        store.update_saved(self.app.db, self._current_id, tags=tags, notes=notes)

    def action_save_meta(self) -> None:
        if self._current_id is None:
            return
        self._flush_current()
        self.notify("Saved tags & notes.", title="Saved")

    def action_focus_search(self) -> None:
        self.query_one("#saved-search", Input).focus()

    def action_toggle_focus(self) -> None:
        self.toggle_class("focus-reader")

    def action_exit_focus_reader(self) -> None:
        """Enter exits focus-reader (symmetric with how the user got in).

        In normal mode the DataTable's own Enter binding consumes the keystroke
        before this fires; in focus-reader mode the table is display:none and
        Enter bubbles through to this binding.
        """
        if not self.has_class("focus-reader"):
            return
        self.remove_class("focus-reader")

    def on_markdown_link_clicked(self, event: Markdown.LinkClicked) -> None:
        """Intercept link clicks in the article reader (see FeedPane for the full rationale)."""
        event.stop()
        href = (event.href or "").strip()
        if not href:
            return
        try:
            self.app.copy_to_clipboard(href)
            self.notify(f"Copied: {shorten(href, 60)}", title="Link", timeout=8.0)
        except Exception as exc:  # noqa: BLE001
            log.warning("OSC 52 copy failed: %s", exc)
            self.notify(href, title="Link (copy failed)", severity="warning", timeout=12.0)

    def action_copy_url(self) -> None:
        if self._current_id is None:
            return
        row = next((r for r in self._items if r["id"] == self._current_id), None)
        if row is None or not row["url"]:
            return
        url = row["url"]
        self.app.copy_to_clipboard(url)
        self.notify(f"Copied: {url[:60]}", title="Clipboard")

    def action_copy_article_markdown(self) -> None:
        """Copy the visible saved article (URL + brief + body) as Markdown.

        Mirrors the Feed pane's binding; here the body comes from
        ``saved.full_text`` (the snapshot taken when the item was liked)
        rather than the live extraction.
        """
        if self._current_id is None:
            return
        row = next((r for r in self._items if r["id"] == self._current_id), None)
        if row is None or not row["url"]:
            return
        body = row["full_text"]
        extraction = store.get_extraction(self.app.db, row["id"])
        if not body and extraction and extraction["markdown"]:
            body = extraction["markdown"]
        if not body:
            self.app.copy_to_clipboard(f"# {row['title'] or '(untitled)'}\n\n<{row['url']}>\n")
            self.notify(
                "Copied URL + title (no article body saved)", title="Clipboard", timeout=6.0
            )
            return
        brief = extraction["summary_md"] if extraction else None
        word_count = extraction["word_count"] if extraction else None
        markdown = _reader.article_markdown(
            row, body=body, lede=row["summary"], word_count=word_count, brief=brief
        )
        self.app.copy_to_clipboard(markdown)
        n_words = f"~{word_count:,} words" if word_count else "no word count"
        self.notify(
            f"Copied article + URL ({n_words}) to clipboard.",
            title="Clipboard",
            timeout=6.0,
        )

    # --- discovery ---------------------------------------------------------

    def action_discover_like_this(self) -> None:
        """Find more articles like the currently-highlighted saved one (per-item).

        Uses the bulk discovery engine with a one-row seed, so the existing
        prompt + verify + critique pipeline applies. Discovered items land in
        the Feed pane like normal Ctrl+D output; the user reviews them there.
        """
        if self._discover_busy:
            self.notify("Discovery already running.", severity="warning")
            return
        if self._current_id is None:
            return
        row = next((r for r in self._items if r["id"] == self._current_id), None)
        if row is None:
            return
        if not store.get_meta(self.app.db, "discovery_consent"):
            self.app.push_screen(
                DiscoveryConsentModal(),
                lambda accepted: self._on_consent_then_discover(accepted, row),
            )
            return
        self._begin_discover_like_this(row)

    def _on_consent_then_discover(self, accepted: bool | None, row: sqlite3.Row) -> None:
        if not accepted:
            return
        store.set_meta(self.app.db, "discovery_consent", "yes")
        self._begin_discover_like_this(row)

    def _begin_discover_like_this(self, row: sqlite3.Row) -> None:
        self._discover_busy = True
        title = shorten(row["title"] or row["url"], 50)
        self.notify(
            f"Looking for articles like “{title}” — this may take 30-90 seconds.",
            title="Discover",
            timeout=8.0,
        )
        self.run_worker(self._do_discover_like_this(row), exclusive=True, group="discover")

    async def _do_discover_like_this(self, row: sqlite3.Row) -> None:
        result = None
        try:
            result = await discover_mod.run_discovery(
                db=self.app.db,
                config=self.app.config,
                seed_items=[row],
            )
        except Exception as exc:  # noqa: BLE001
            self.notify(
                f"Discovery crashed: {type(exc).__name__}: {exc}",
                severity="error",
                timeout=12.0,
            )
        finally:
            self._discover_busy = False
        if result is None:
            return
        if result.ok:
            self.notify(
                f"Discovered {result.kept_count} new item(s) — open the Feed (1) to review.",
                title="Discover",
                timeout=10.0,
            )
        else:
            self.notify(
                f"Discovery: {result.error}",
                severity="warning",
                title="Discover",
                timeout=10.0,
            )

    # --- events -------------------------------------------------------------

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if (
            0 <= event.cursor_row < len(self._items)
            and self._items[event.cursor_row]["id"] != self._current_id
        ):
            self._flush_current()
            self._show(event.cursor_row)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:  # noqa: ARG002
        # Enter on a row activates reader focus mode (matches the Feed pane).
        self.add_class("focus-reader")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "saved-search":
            self.reload(query=event.value)
        elif event.input.id == "saved-tags":
            self._flush_current()
            self.notify("Tags saved.", title="Saved")
