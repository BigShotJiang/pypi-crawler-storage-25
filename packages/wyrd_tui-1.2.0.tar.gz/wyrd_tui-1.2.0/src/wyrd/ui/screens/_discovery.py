"""First-run consent modal for LLM-driven content discovery.

Shown once, the very first time the user presses ``Ctrl+D`` (Feed) or ``m``
(Saved). Stores its outcome in the ``meta`` table as ``discovery_consent``
so subsequent presses don't re-prompt. Granting is permanent; if the user
ever wants to revoke we can add a config knob later (no UI for that in
1.2).

Why a modal and not a notify? The Feed pane already showed users we
*could* spend a few seconds talking to Claude on their behalf (the
extraction worker, the brief generator). Discovery is materially different
— it sends a digest of the user's reading history out — and that's worth
a deliberate one-time gate the user can read and accept rather than a
toast they might miss.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Label, Static

__all__ = ["DiscoveryConsentModal"]

_BODY = (
    "Wyrd's discovery feature sends a digest of your recent saved articles "
    "(titles, URLs, tags, your notes, and the first ~800 chars of each "
    "body) to Claude so it can suggest related pieces from across the web. "
    "Recently-dismissed item titles + URLs go along as weak negative signal.\n\n"
    "Nothing else is sent. Wyrd itself does not phone home about this — "
    "the only network traffic is the call to the ``claude`` CLI and the "
    "HTTP HEAD requests used to verify candidate URLs.\n\n"
    "Subsequent discovery runs won't re-prompt. To revoke, delete the "
    "``discovery_consent`` row from the SQLite ``meta`` table; we'll add a "
    "config knob in a later release."
)


class DiscoveryConsentModal(ModalScreen[bool]):
    """Yes/no gate before the first discovery run. Returns ``True`` on accept."""

    BINDINGS = [
        Binding("escape", "decline", "Cancel"),
        Binding("y", "accept", "Yes, run discovery"),
    ]

    DEFAULT_CSS = """
    DiscoveryConsentModal { align: center middle; }
    DiscoveryConsentModal #box {
        width: 80; max-width: 95%; height: auto; padding: 1 2;
        border: round $primary; background: $surface;
    }
    DiscoveryConsentModal #title { width: 100%; margin-bottom: 1; text-style: bold; }
    DiscoveryConsentModal #body { width: 100%; margin-bottom: 1; color: $text-muted; }
    DiscoveryConsentModal #buttons { height: auto; align-horizontal: right; }
    DiscoveryConsentModal #buttons Button { margin-left: 2; }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="box"):
            yield Label("Discover content with Claude?", id="title")
            yield Static(_BODY, id="body")
            with Horizontal(id="buttons"):
                yield Button("Cancel", id="cancel")
                yield Button("Yes, continue", id="accept", variant="primary")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "accept")

    def action_accept(self) -> None:
        self.dismiss(True)

    def action_decline(self) -> None:
        self.dismiss(False)
