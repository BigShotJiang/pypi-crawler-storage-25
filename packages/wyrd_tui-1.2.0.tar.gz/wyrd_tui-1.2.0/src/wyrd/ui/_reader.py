"""Helpers shared by the panes that render an item as a Markdown article.

The two readers (Feed pane, Saved pane) compose the same shape: a title +
meta line + an optional reading-time line + an optional Claude-generated
brief, then a horizontal rule, then the extracted article body. This module
owns that layout so the two panes don't drift.

The *reading time* is computed cheaply from the extraction's word count
(225 wpm rule of thumb). The *brief* is an LLM-generated 2-3 sentence
summary, cached in ``extractions.summary_md`` — when it isn't ready yet
(extraction is fresh, or ``claude`` isn't on PATH) the header degrades to
just the meta line plus an optional lede pulled from the RSS summary.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime

__all__ = [
    "article_markdown",
    "estimate_reading_minutes",
    "feed_when",
    "fmt_when",
    "header_markdown",
    "md_escape",
]

# A typical online-reading speed; round up to make the estimate err on the
# side of "this might take a moment" rather than under-promising.
_WORDS_PER_MINUTE = 225


def fmt_when(value: str | None) -> str:
    if not value:
        return ""
    try:
        return datetime.fromisoformat(value).astimezone().strftime("%Y-%m-%d %H:%M")
    except (TypeError, ValueError):
        return value


def feed_when(row: sqlite3.Row) -> str:
    return fmt_when(row["published_at"] or row["discovered_at"])


def md_escape(text: str) -> str:
    """Escape the characters that would otherwise be Markdown syntax in a header line."""
    return text.replace("\\", "\\\\").replace("`", "\\`").replace("*", "\\*").replace("_", "\\_")


def estimate_reading_minutes(word_count: int | None) -> int | None:
    """Return ``ceil(words / 225)`` minutes, or ``None`` when we have no count.

    Returns ``1`` as the floor — a 50-word piece still takes a moment to read
    and "0 min read" looks broken. ``None`` means "we don't know" (extraction
    hasn't landed or failed) and the caller should omit the line entirely.
    """
    if not word_count or word_count <= 0:
        return None
    return max(1, (word_count + _WORDS_PER_MINUTE - 1) // _WORDS_PER_MINUTE)


def header_markdown(
    row: sqlite3.Row,
    *,
    lede: str | None = None,
    word_count: int | None = None,
    brief: str | None = None,
) -> str:
    """Render the article-header block.

    Layout (top to bottom):

        # Title
        *source · author · published-when*
        <url>
        *N min read · ~W words*    ← only when ``word_count`` is provided
        > Brief sentence one. Sentence two.    ← prefers ``brief``, else ``lede``

    ``brief`` (Claude-generated) wins over ``lede`` (RSS summary) when both
    are present — the brief is reliably about what the piece is, the lede
    often duplicates the article's first paragraph.
    """
    title = md_escape(row["title"] or "(untitled)")
    meta = " · ".join(p for p in (row["source_kind"], row["author"], feed_when(row)) if p)
    lines = [f"# {title}", ""]
    if meta:
        lines.append(f"*{md_escape(meta)}*")
    if row["url"]:
        lines.append(f"<{row['url']}>")
    minutes = estimate_reading_minutes(word_count)
    if minutes is not None and word_count is not None:
        lines.append(f"*{minutes} min read · ~{word_count:,} words*")
    summary = (brief or "").strip() or (lede or "").strip()
    if summary:
        lines += ["", f"> {' '.join(summary.split())}"]
    return "\n".join(lines)


def article_markdown(
    row: sqlite3.Row,
    *,
    body: str | None,
    lede: str | None = None,
    word_count: int | None = None,
    brief: str | None = None,
) -> str:
    header = header_markdown(row, lede=lede, word_count=word_count, brief=brief)
    body = (body or "").strip()
    return f"{header}\n\n---\n\n{body}" if body else header
