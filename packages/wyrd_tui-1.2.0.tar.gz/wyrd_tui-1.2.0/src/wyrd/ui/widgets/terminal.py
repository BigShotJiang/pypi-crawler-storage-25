"""Embedded PTY terminal widget, backed by `pyte`.

A pragmatic VT emulator: spawns a child process on a pseudo-terminal, runs its
output through pyte, renders the screen (colours + cursor) line by line, and
forwards keystrokes back to the PTY. Not a pixel-perfect emulator — good enough
for an interactive shell, git, less, etc. For anything fancier (or if this
misbehaves), the app's F10 binding suspends the TUI and drops into a real
``$SHELL``.

Key handling: printable characters and control characters arrive from Textual as
``event.character`` and are written through verbatim; named keys (arrows, F-keys,
Home/End, …) are translated by :func:`encode_key`. F10 and F12 are deliberately
*not* translated so they bubble up to the app / screen bindings.
"""

from __future__ import annotations

import asyncio
import fcntl
import os
import pty
import signal
import struct
import termios

import pyte
from rich.segment import Segment
from rich.style import Style
from textual import events
from textual.message import Message
from textual.strip import Strip
from textual.widget import Widget

__all__ = [
    "TerminalWidget",
    "encode_key",
]

# --- key translation --------------------------------------------------------

_SPECIAL_KEYS: dict[str, str] = {
    "enter": "\r",
    "escape": "\x1b",
    "tab": "\t",
    "shift+tab": "\x1b[Z",
    "backspace": "\x7f",
    "up": "\x1bOA",
    "down": "\x1bOB",
    "right": "\x1bOC",
    "left": "\x1bOD",
    "home": "\x1bOH",
    "end": "\x1bOF",
    "delete": "\x1b[3~",
    "insert": "\x1b[2~",
    "pageup": "\x1b[5~",
    "pagedown": "\x1b[6~",
    "f1": "\x1bOP",
    "f2": "\x1bOQ",
    "f3": "\x1bOR",
    "f4": "\x1bOS",
    "f5": "\x1b[15~",
    "f6": "\x1b[17~",
    "f7": "\x1b[18~",
    "f8": "\x1b[19~",
    "f9": "\x1b[20~",
    "f11": "\x1b[23~",
    # f10 -> app "drop to $SHELL"; f12 -> TerminalScreen "detach". Not forwarded.
}


def encode_key(key: str, character: str | None) -> bytes | None:
    """Translate a Textual key event into the bytes a PTY expects, or ``None``."""
    if key in _SPECIAL_KEYS:
        return _SPECIAL_KEYS[key].encode()
    if character:
        return character.encode("utf-8", errors="replace")
    return None


# --- colour translation -----------------------------------------------------

_PYTE_TO_RICH_COLOR = {
    "black": "black",
    "red": "red",
    "green": "green",
    "brown": "yellow",
    "blue": "blue",
    "magenta": "magenta",
    "cyan": "cyan",
    "white": "white",
    "brightblack": "bright_black",
    "brightred": "bright_red",
    "brightgreen": "bright_green",
    "brightbrown": "bright_yellow",
    "brightblue": "bright_blue",
    "brightmagenta": "bright_magenta",
    "brightcyan": "bright_cyan",
    "brightwhite": "bright_white",
}


def _rich_color(name: str | None) -> str | None:
    if not name or name == "default":
        return None
    if name in _PYTE_TO_RICH_COLOR:
        return _PYTE_TO_RICH_COLOR[name]
    if len(name) == 6:  # pyte emits 24-bit / 256-colour as bare hex
        try:
            int(name, 16)
        except ValueError:
            return None
        return f"#{name}"
    return None


# --- widget -----------------------------------------------------------------


class TerminalWidget(Widget, can_focus=True):
    DEFAULT_CSS = """
    TerminalWidget {
        background: #000000;
        color: #c0c0c0;
    }
    """

    class Exited(Message):
        """Posted when the child process exits (the user typed `exit`, Ctrl+D, etc.)."""

    def __init__(self, command: list[str] | None = None) -> None:
        super().__init__()
        self._command = command or [os.environ.get("SHELL") or "/bin/sh"]
        self._fd: int | None = None
        self._pid: int | None = None
        self._exited = False
        # Replaced by a correctly-sized screen the first time we learn our size
        # (see _sync_size); we must not create it large and shrink it later —
        # pyte.Screen.resize() drops lines off the *top* when shrinking.
        self._screen = pyte.Screen(80, 24)
        self._stream = pyte.ByteStream(self._screen)

    # --- lifecycle ----------------------------------------------------------

    def on_mount(self) -> None:
        # Geometry isn't assigned yet at on_mount; once a layout pass has run,
        # self.size is real and we can size the emulator + start the process.
        self.call_after_refresh(lambda: self._sync_size(self.size.height, self.size.width))

    def on_unmount(self) -> None:
        self._shutdown()

    def on_resize(self, event: events.Resize) -> None:
        self._sync_size(event.size.height, event.size.width)

    def _sync_size(self, height: int, width: int) -> None:
        rows, cols = max(height, 1), max(width, 1)
        if self._exited:
            return
        if self._pid is None:  # first real size — size the emulator and start
            self._screen = pyte.Screen(cols, rows)
            self._stream = pyte.ByteStream(self._screen)
            self._spawn()
            self._set_winsize(rows, cols)
            self.focus()
            return
        if self._fd is None:
            return
        if (self._screen.lines, self._screen.columns) != (rows, cols):
            self._screen.resize(rows, cols)
            self._set_winsize(rows, cols)
            self.refresh()

    def _spawn(self) -> None:
        pid, fd = pty.fork()
        if pid == 0:  # child: become the requested program
            env = dict(os.environ)
            env["TERM"] = "xterm-256color"
            try:
                os.execvpe(self._command[0], self._command, env)
            except OSError:
                pass
            os._exit(127)
        self._pid, self._fd = pid, fd
        flags = fcntl.fcntl(fd, fcntl.F_GETFL)
        fcntl.fcntl(fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
        asyncio.get_running_loop().add_reader(fd, self._on_readable)

    def _set_winsize(self, rows: int, cols: int) -> None:
        if self._fd is None or rows < 1 or cols < 1:
            return
        try:
            fcntl.ioctl(self._fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
        except OSError:
            pass

    def _detach_reader(self) -> None:
        if self._fd is not None:
            try:
                asyncio.get_running_loop().remove_reader(self._fd)
            except (ValueError, OSError, RuntimeError):
                pass

    def _shutdown(self) -> None:
        self._detach_reader()
        if self._pid is not None:
            try:
                os.kill(self._pid, signal.SIGHUP)
            except ProcessLookupError:
                pass
            try:
                os.waitpid(self._pid, 0)
            except (ChildProcessError, OSError):
                pass
            self._pid = None
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = None

    # --- PTY -> screen ------------------------------------------------------

    def _on_readable(self) -> None:
        if self._fd is None:
            return
        try:
            data = os.read(self._fd, 1 << 16)
        except BlockingIOError:
            return
        except OSError:
            data = b""
        if not data:
            self._handle_exit()
            return
        self._stream.feed(data)
        self.refresh()

    def _handle_exit(self) -> None:
        if self._exited:
            return
        self._exited = True
        self._detach_reader()
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = None
        self.refresh()
        self.post_message(self.Exited())

    # --- input --------------------------------------------------------------

    def on_key(self, event: events.Key) -> None:
        if self._fd is None:
            return  # process gone; let bindings (e.g. F12) through
        data = encode_key(event.key, event.character)
        if data is None:
            return
        event.stop()
        event.prevent_default()
        try:
            os.write(self._fd, data)
        except OSError:
            self._handle_exit()

    # --- rendering ----------------------------------------------------------

    def render_line(self, y: int) -> Strip:
        screen = self._screen
        width = self.size.width
        if y >= screen.lines:
            return Strip.blank(width)

        row = screen.buffer[y]
        cursor = screen.cursor
        show_cursor = (not cursor.hidden) and cursor.y == y and self.has_focus

        segments: list[Segment] = []
        run_chars: list[str] = []
        run_style: Style | None = None

        def flush() -> None:
            nonlocal run_chars
            if run_chars:
                segments.append(Segment("".join(run_chars), run_style))
                run_chars = []

        for x in range(screen.columns):
            char = row.get(x)
            if char is None:
                data, style = " ", Style()
            else:
                data = char.data or " "
                style = Style(
                    color=_rich_color(char.fg),
                    bgcolor=_rich_color(char.bg),
                    bold=char.bold,
                    italic=char.italics,
                    underline=char.underscore,
                    strike=char.strikethrough,
                    reverse=char.reverse,
                )
            if show_cursor and x == cursor.x:
                style = style + Style(reverse=True)
            if style != run_style:
                flush()
                run_style = style
            run_chars.append(data)
        flush()
        return Strip(segments).adjust_cell_length(width)
