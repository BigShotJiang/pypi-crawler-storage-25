import os
import re

from setuptools import setup, find_packages


with open(os.path.join(os.path.dirname(__file__), 'README.md')) as readme:
    README = readme.read()


def get_version():
    with open(os.path.join('blacklist', '__init__.py')) as f:
        match = re.search(r"__version__ = '([^']+)'", f.read())
        return match.group(1)


setup(
    name='django-blacklist-cache',

    version=get_version(),

    description='Blacklist users and hosts in Django using the cache framework. Automatically blacklist rate-limited clients.',
    long_description=README,
    long_description_content_type='text/markdown',

    url='https://github.com/diegoamferreira/django-blacklist-cache',

    author='Diego Ferreira',
    author_email='diego.ferreira@solyd.com.br',

    license='MIT',

    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Web Environment',
        'Framework :: Django',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Security'
    ],

    keywords='django blacklist ratelimit firewall cache redis',

    packages=find_packages(),

    python_requires='>=3.8',

    install_requires=[
        'Django'
    ]
)
