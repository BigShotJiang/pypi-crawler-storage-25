from django.core.management.base import BaseCommand

from ...api import unblock_ip, unblock_user, clear_all


class Command(BaseCommand):
    help = 'Clear blacklist rules from the cache'

    def add_arguments(self, parser):
        parser.add_argument(
            '--ip',
            type=str,
            help='Remove the block for a specific IP address',
        )
        parser.add_argument(
            '--user',
            type=int,
            help='Remove the block for a specific user ID',
        )

    def handle(self, *args, **options):
        ip = options['ip']
        user = options['user']

        if ip:
            unblock_ip(ip)
            self.stdout.write(self.style.SUCCESS(f'Unblocked IP: {ip}'))

        elif user:
            unblock_user(user)
            self.stdout.write(self.style.SUCCESS(f'Unblocked user ID: {user}'))

        else:
            clear_all()
            self.stdout.write(self.style.SUCCESS('Cleared all blacklist rules.'))
