import ipaddress
import logging

from django.conf import settings
from django.core.cache import caches
from django.core.exceptions import ImproperlyConfigured
from django.utils.module_loading import import_string


logger = logging.getLogger(__name__)


def get_cache():
    alias = getattr(settings, 'BLACKLIST_CACHE_ALIAS', 'default')
    return caches[alias]


def get_client_address(request):
    source = getattr(settings, 'BLACKLIST_ADDRESS_SOURCE', 'REMOTE_ADDR')

    if source in request.META:
        addr = request.META[source]

    elif callable(source):
        addr = source(request)

    elif isinstance(source, str) and '.' in source:
        func = import_string(source)
        addr = func(request)

    else:
        raise ImproperlyConfigured(
            'Unable to obtain the client address. '
            'Please see the documentation of the BLACKLIST_ADDRESS_SOURCE setting.'
        )

    if not addr:
        raise ImproperlyConfigured(
            'The client address is empty. '
            'Please check the BLACKLIST_ADDRESS_SOURCE setting.'
        )

    return ipaddress.ip_address(addr).compressed
