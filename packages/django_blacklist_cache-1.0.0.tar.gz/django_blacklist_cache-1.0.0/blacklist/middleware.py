import logging

from django.core.exceptions import SuspiciousOperation
from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import render
from django.conf import settings

from .utils import get_cache, get_client_address


logger = logging.getLogger(__name__)


class Blacklisted(SuspiciousOperation):
    pass


class BlacklistMiddleware(MiddlewareMixin):
    def process_request(self, request):
        if not getattr(settings, 'BLACKLIST_ENABLE', True):
            return None

        cache = get_cache()
        keys = []

        user = getattr(request, 'user', None)
        if user and getattr(user, 'is_authenticated', False):
            keys.append(f'bl:user:{user.pk}')

        try:
            addr = get_client_address(request)
            keys.append(f'bl:addr:{addr}')
        except Exception:
            pass

        if not keys:
            return None

        blocked = cache.get_many(keys)

        if not blocked:
            return None

        user_key = keys[0] if user and user.is_authenticated else None
        if user_key and user_key in blocked:
            message = f'Blacklisted user: {user.username}'
        else:
            message = f'Blacklisted address: {addr}'

        exception = Blacklisted(message)

        template_name = getattr(settings, 'BLACKLIST_TEMPLATE', None)
        if template_name:
            if getattr(settings, 'BLACKLIST_LOGGING_ENABLE', True):
                logger.warning(exception)
            context = {'request': request, 'exception': exception}
            return render(request, template_name, context, status=400)

        raise exception
