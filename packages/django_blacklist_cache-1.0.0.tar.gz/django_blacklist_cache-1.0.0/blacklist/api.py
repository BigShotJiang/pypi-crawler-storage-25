import ipaddress

from .utils import get_cache


def block_ip(address, duration):
    """Block an IP address for the given duration (timedelta)."""
    cache = get_cache()
    ip = ipaddress.ip_address(address).compressed
    cache.set(f'bl:addr:{ip}', True, timeout=int(duration.total_seconds()))


def block_user(user_id, duration):
    """Block a user by ID for the given duration (timedelta)."""
    cache = get_cache()
    cache.set(f'bl:user:{user_id}', True, timeout=int(duration.total_seconds()))


def unblock_ip(address):
    """Remove the block for an IP address."""
    cache = get_cache()
    ip = ipaddress.ip_address(address).compressed
    cache.delete(f'bl:addr:{ip}')


def unblock_user(user_id):
    """Remove the block for a user by ID."""
    cache = get_cache()
    cache.delete(f'bl:user:{user_id}')


def is_blocked_ip(address):
    """Check if an IP address is currently blocked."""
    cache = get_cache()
    ip = ipaddress.ip_address(address).compressed
    return cache.get(f'bl:addr:{ip}') is not None


def is_blocked_user(user_id):
    """Check if a user is currently blocked."""
    cache = get_cache()
    return cache.get(f'bl:user:{user_id}') is not None


def clear_all():
    """Clear all blacklist rules.

    This calls cache.clear() on the blacklist cache alias.
    If you are using a dedicated cache alias (recommended), this only affects blacklist data.
    If you are using the 'default' cache, this will clear ALL cached data.
    """
    cache = get_cache()
    cache.clear()
