import logging
from functools import wraps

from django.conf import settings

from django_ratelimit.exceptions import Ratelimited

from .utils import get_cache, get_client_address


logger = logging.getLogger(__name__)


def blacklist_ratelimited(duration, block=True):
    if isinstance(duration, tuple):
        user_duration, ip_duration = duration
    else:
        user_duration = ip_duration = duration

    assert user_duration or ip_duration

    def decorator(fn):
        @wraps(fn)
        def wrapper(request, *args, **kwargs):
            if request.limited:
                if getattr(settings, 'BLACKLIST_ENABLE', True) \
                        and getattr(settings, 'BLACKLIST_RATELIMITED_ENABLE', True):

                    cache = get_cache()

                    if user_duration and request.user.is_authenticated:
                        timeout = int(user_duration.total_seconds())
                        cache.set(f'bl:user:{request.user.pk}', True, timeout=timeout)

                    elif ip_duration:
                        addr = get_client_address(request)
                        timeout = int(ip_duration.total_seconds())
                        cache.set(f'bl:addr:{addr}', True, timeout=timeout)

                    else:
                        logger.warning('Unable to blacklist ratelimited client.')

                if block:
                    raise Ratelimited()

            return fn(request, *args, **kwargs)

        return wrapper

    return decorator
