__version__ = '1.0.0'

from .api import (
    block_ip,
    block_user,
    unblock_ip,
    unblock_user,
    is_blocked_ip,
    is_blocked_user,
    clear_all,
)
