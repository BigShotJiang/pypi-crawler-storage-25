from unittest.mock import Mock

from blocks.repo import Repo
from blocks.config import Config
from blocks.github import GithubRepoProvider
from blocks.gitlab import GitlabRepoProvider
from blocks.bitbucket import BitbucketRepoProvider


class TestRepoFactory:
    def test_factory_returns_github_provider(self):
        config = Mock(spec=Config)
        config.get_repo_provider.return_value = "github"
        repo = Repo(config)
        assert isinstance(repo.repo_provider, GithubRepoProvider)

    def test_factory_returns_gitlab_provider(self):
        config = Mock(spec=Config)
        config.get_repo_provider.return_value = "gitlab"
        repo = Repo(config)
        assert isinstance(repo.repo_provider, GitlabRepoProvider)

    def test_factory_returns_bitbucket_provider(self):
        config = Mock(spec=Config)
        config.get_repo_provider.return_value = "bitbucket"
        repo = Repo(config)
        assert isinstance(repo.repo_provider, BitbucketRepoProvider)

    def test_factory_returns_none_for_unknown_provider(self):
        config = Mock(spec=Config)
        config.get_repo_provider.return_value = "unknown"
        repo = Repo(config)
        assert repo.repo_provider is None

    def test_factory_is_case_insensitive(self):
        config = Mock(spec=Config)
        config.get_repo_provider.return_value = "BITBUCKET"
        repo = Repo(config)
        assert isinstance(repo.repo_provider, BitbucketRepoProvider)
