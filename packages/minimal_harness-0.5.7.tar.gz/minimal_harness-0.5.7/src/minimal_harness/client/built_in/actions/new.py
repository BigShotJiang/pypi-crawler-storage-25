"""New conversation action — handles Ctrl+N."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from minimal_harness.client.built_in.config.agents import load_agents_config
from minimal_harness.client.built_in.modals import AgentSelectScreen, ConfirmScreen

if TYPE_CHECKING:
    from minimal_harness.client.built_in.app import TUIApp


def action_new(app: TUIApp) -> None:
    agents = load_agents_config()

    def _pick_agent() -> None:
        def on_agent(agent: dict[str, Any] | None) -> None:
            if not agent:
                return
            d = app._chat_display
            if d is None:
                return
            d.clear_chat()
            sid = app._ctrl.current_session_id
            if sid:
                app._ctrl.get_buf(sid).clear()
            app._first = True
            app._banner_widget.display = True
            app._chat.display = False

            async def _post_create() -> None:
                await app._ctrl.create_session(
                    agent_name=agent["name"],
                    default_tools=agent.get("default_tools"),
                )
                await app._banner()
                app._update_top_bar()

            asyncio.create_task(_post_create())

        app.push_screen(AgentSelectScreen(agents), on_agent)

    if app._first:
        _pick_agent()
    else:
        app.push_screen(
            ConfirmScreen(
                "Start new chat?",
                "Session is saved.",
                ok="New Chat",
                variant="primary",
            ),
            lambda ok: _pick_agent() if ok else None,
        )
