"""Custom widgets for the TUI."""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.text import Text
from textual import events
from textual.binding import Binding
from textual.widgets import Static, TextArea

if TYPE_CHECKING:
    from textual.timer import Timer

from .messages import (
    ChatInputDump,
    ChatInputSubmit,
    SessionNotificationClicked,
    SlashCommandHide,
    SlashCommandNavigateDown,
    SlashCommandNavigateUp,
    SlashCommandSelect,
    SlashCommandShow,
)


class Banner(Static):
    pass


class SessionNotification(Static):
    """Notification that a background session has finished. Click to jump to it."""

    def __init__(self, session_id: str, session_name: str, **kwargs) -> None:
        self._session_id = session_id
        self._timer: Timer | None = None
        text = Text.assemble(
            ("\u2713 ", "bold bright_green"),
            (f'Session "{session_name}" finished', "bold"),
            ("  (click to switch)", "dim"),
        )
        super().__init__(text, **kwargs)

    @property
    def target_session_id(self) -> str:
        return self._session_id

    def on_click(self) -> None:
        self.post_message(SessionNotificationClicked(self._session_id))


class ChatInput(TextArea):
    BINDINGS = [Binding("ctrl+d", "dump", "Dump", show=True)]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._slash_active: bool = False
        self._input_history: list[str] = []
        self._history_index: int = -1
        self._current_input: str = ""

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        text = self.text
        if text.startswith("/"):
            self.post_message(SlashCommandShow(text))
        elif self._slash_active:
            self.post_message(SlashCommandHide())

    def on_key(self, event: events.Key) -> None:
        if self._slash_active:
            if event.key in ("up", "down"):
                event.stop()
                event.prevent_default()
                if event.key == "up":
                    self.post_message(SlashCommandNavigateUp())
                else:
                    self.post_message(SlashCommandNavigateDown())
                return
            if event.key == "enter":
                event.stop()
                event.prevent_default()
                self.post_message(SlashCommandSelect())
                return
            if event.key == "escape":
                event.stop()
                event.prevent_default()
                self.post_message(SlashCommandHide())
                return
        if event.key == "up":
            if self._input_history:
                event.stop()
                event.prevent_default()
                if self._history_index == -1:
                    self._current_input = self.text
                if self._history_index < len(self._input_history) - 1:
                    self._history_index += 1
                    self.text = self._input_history[-(self._history_index + 1)]
                return
        if event.key == "down":
            if self._input_history:
                event.stop()
                event.prevent_default()
                if self._history_index == -1:
                    return
                if self._history_index == 0:
                    self._history_index = -1
                    self.text = self._current_input
                else:
                    self._history_index -= 1
                    self.text = self._input_history[-(self._history_index + 1)]
                return
        if event.key == "enter":
            event.stop()
            event.prevent_default()
            text = self.text
            if text.strip():
                self._input_history.append(text)
            self.reset_history_index()
            self.post_message(ChatInputSubmit())
        elif event.key in ("ctrl+enter", "ctrl+j"):
            event.stop()
            event.prevent_default()
            self.insert("\n")

    def action_dump(self) -> None:
        self.post_message(ChatInputDump())

    @property
    def input_history(self) -> list[str]:
        return self._input_history

    @input_history.setter
    def input_history(self, value: list[str]) -> None:
        self._input_history = value

    def set_slash_active(self, active: bool) -> None:
        self._slash_active = active

    def reset_history_index(self) -> None:
        self._history_index = -1
        self._current_input = ""
