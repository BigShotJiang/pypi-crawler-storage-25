"""Advisory feed — live compromised package data from multiple sources.

Priority: local cache -> remote JSON -> OSV.dev API -> hardcoded fallback.
Cache TTL: 24 hours. Graceful degradation: if all remote sources fail,
falls back to hardcoded list (never leaves user unprotected).
"""

from __future__ import annotations

import json
import time
import urllib.request
import urllib.error
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Advisory:
    """A known compromised package version."""
    package: str
    version: str
    ecosystem: str  # "npm" | "pypi"
    description: str
    source: str  # "builtin" | "remote" | "osv"


# --- Built-in fallback (always available, updated with each release) ---

_BUILTIN: tuple[Advisory, ...] = (
    Advisory("axios", "1.14.1", "npm", "Remote access trojan via plain-crypto-js postinstall", "builtin"),
    Advisory("axios", "0.30.4", "npm", "Remote access trojan via plain-crypto-js postinstall", "builtin"),
    Advisory("plain-crypto-js", "4.2.1", "npm", "Malicious postinstall drops platform-specific RAT", "builtin"),
    Advisory("telnyx", "4.87.1", "pypi", "WAV steganography payload drops RAT (TeamPCP campaign)", "builtin"),
    Advisory("telnyx", "4.87.2", "pypi", "WAV steganography payload drops RAT (TeamPCP campaign)", "builtin"),
    Advisory("event-stream", "3.3.6", "npm", "Cryptocurrency wallet theft via flatmap-stream", "builtin"),
    Advisory("ua-parser-js", "0.7.29", "npm", "Cryptominer and password stealer injection", "builtin"),
    Advisory("coa", "2.0.3", "npm", "Compromised maintainer account, malicious preinstall", "builtin"),
    Advisory("coa", "2.0.4", "npm", "Compromised maintainer account, malicious preinstall", "builtin"),
    Advisory("rc", "1.2.9", "npm", "Compromised maintainer account, malicious preinstall", "builtin"),
    Advisory("rc", "1.3.9", "npm", "Compromised maintainer account, malicious preinstall", "builtin"),
    Advisory("rc", "2.3.9", "npm", "Compromised maintainer account, malicious preinstall", "builtin"),
    Advisory("node-ipc", "10.1.1", "npm", "Protestware: overwrites files on Russian/Belarusian IPs", "builtin"),
    Advisory("node-ipc", "10.1.2", "npm", "Protestware: overwrites files on Russian/Belarusian IPs", "builtin"),
    Advisory("node-ipc", "10.1.3", "npm", "Protestware: overwrites files on Russian/Belarusian IPs", "builtin"),
    Advisory("colors", "1.4.1", "npm", "Protestware: infinite loop on require", "builtin"),
    Advisory("colors", "1.4.44-liberty-2", "npm", "Protestware: infinite loop on require", "builtin"),
    Advisory("faker", "6.6.6", "npm", "Protestware: prints gibberish on require", "builtin"),
)

# Remote JSON URL (GitHub-hosted, editable without release)
_REMOTE_URL = "https://raw.githubusercontent.com/danielwanwx/leakwall/main/data/compromised.json"

# Cache settings
_CACHE_TTL_SECONDS = 86400  # 24 hours
_FETCH_TIMEOUT = 10  # seconds


class AdvisoryFeed:
    """Aggregates compromised package data from multiple sources."""

    def __init__(self, cache_dir: str | Path | None = None) -> None:
        if cache_dir is None:
            cache_dir = Path.home() / ".cache" / "leakwall"
        self._cache_dir = Path(cache_dir)
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._cache_file = self._cache_dir / "advisories.json"

    def get_advisories(self) -> list[Advisory]:
        """Get all known advisories. Merges builtin + cached remote + OSV."""
        advisories: dict[tuple[str, str], Advisory] = {}

        # Layer 1: builtin (always present)
        for a in _BUILTIN:
            advisories[(a.package, a.version)] = a

        # Layer 2: cached remote feed
        cached = self._load_cache()
        for a in cached:
            advisories[(a.package, a.version)] = a

        return list(advisories.values())

    def refresh(self) -> tuple[int, list[str]]:
        """Refresh advisory cache from remote sources. Returns (count, errors)."""
        new_advisories: list[Advisory] = []
        errors: list[str] = []

        # Source 1: Remote JSON
        remote = self._fetch_remote_json()
        if remote is not None:
            new_advisories.extend(remote)
        else:
            errors.append("remote JSON fetch failed")

        # Source 2: OSV.dev (query known malware-tagged vulns)
        osv = self._fetch_osv()
        if osv is not None:
            new_advisories.extend(osv)
        else:
            errors.append("OSV.dev fetch failed")

        # Merge with builtin and save cache
        all_advisories: dict[tuple[str, str], Advisory] = {}
        for a in _BUILTIN:
            all_advisories[(a.package, a.version)] = a
        for a in new_advisories:
            all_advisories[(a.package, a.version)] = a

        self._save_cache(list(all_advisories.values()))
        return len(all_advisories), errors

    def is_compromised(self, package: str, version: str) -> Advisory | None:
        """Check if a specific package@version is compromised."""
        for a in self.get_advisories():
            if a.package == package and a.version == version:
                return a
        return None

    def _load_cache(self) -> list[Advisory]:
        """Load cached advisories if fresh enough."""
        if not self._cache_file.exists():
            return []
        try:
            age = time.time() - self._cache_file.stat().st_mtime
            if age > _CACHE_TTL_SECONDS:
                return []  # Stale
            data = json.loads(self._cache_file.read_text())
            return [Advisory(**item) for item in data]
        except (json.JSONDecodeError, KeyError, TypeError):
            return []

    def _save_cache(self, advisories: list[Advisory]) -> None:
        """Save advisories to cache file."""
        data = [
            {"package": a.package, "version": a.version, "ecosystem": a.ecosystem,
             "description": a.description, "source": a.source}
            for a in advisories
        ]
        self._cache_file.write_text(json.dumps(data, indent=2))

    def _fetch_remote_json(self) -> list[Advisory] | None:
        """Fetch advisory list from GitHub-hosted JSON."""
        try:
            req = urllib.request.Request(_REMOTE_URL, headers={"User-Agent": "leakwall/0.1"})
            with urllib.request.urlopen(req, timeout=_FETCH_TIMEOUT) as resp:
                data = json.loads(resp.read().decode())
                return [Advisory(
                    package=item["package"], version=item["version"],
                    ecosystem=item.get("ecosystem", "npm"),
                    description=item.get("description", "Known compromised version"),
                    source="remote",
                ) for item in data]
        except (urllib.error.URLError, json.JSONDecodeError, KeyError, OSError):
            return None

    def _fetch_osv(self) -> list[Advisory] | None:
        """Query OSV.dev for MAL-tagged vulnerabilities (known malware)."""
        try:
            # Query for recent malware advisories
            query = json.dumps({
                "query": "MAL-",
                "page_token": "",
            }).encode()
            req = urllib.request.Request(
                "https://api.osv.dev/v1/query",
                data=query,
                headers={"Content-Type": "application/json", "User-Agent": "leakwall/0.1"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=_FETCH_TIMEOUT) as resp:
                data = json.loads(resp.read().decode())
                advisories = []
                for vuln in data.get("vulns", []):
                    for affected in vuln.get("affected", []):
                        pkg = affected.get("package", {})
                        pkg_name = pkg.get("name", "")
                        ecosystem = pkg.get("ecosystem", "").lower()
                        if ecosystem not in ("npm", "pypi"):
                            continue
                        for ver_range in affected.get("versions", []):
                            advisories.append(Advisory(
                                package=pkg_name, version=ver_range,
                                ecosystem=ecosystem,
                                description=vuln.get("summary", "OSV malware advisory"),
                                source="osv",
                            ))
                return advisories
        except (urllib.error.URLError, json.JSONDecodeError, KeyError, OSError):
            return None
