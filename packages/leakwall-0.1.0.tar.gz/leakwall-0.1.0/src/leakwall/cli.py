"""LeakWall CLI — scan packages from the command line."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from leakwall.advisory import AdvisoryFeed
from leakwall.scanner import Scanner, Severity


def main(args: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="leakwall",
        description="Pre-publish security scanner — catch sourcemaps, credentials, and supply chain risks",
    )
    parser.add_argument("target", help="Directory, .tar.gz, .tgz, or .whl to scan")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--fail-on", choices=["critical", "high", "medium"], default="high",
                        help="Exit non-zero if findings at this severity or above (default: high)")
    parser.add_argument("--refresh", action="store_true",
                        help="Refresh advisory feed from remote sources before scanning")
    parser.add_argument("--online", action="store_true",
                        help="Enable online checks (registry version status)")

    parsed = parser.parse_args(args)
    target = Path(parsed.target)

    if not target.exists():
        print(f"Error: {target} does not exist", file=sys.stderr)
        sys.exit(1)

    feed = AdvisoryFeed()

    if parsed.refresh:
        count, errors = feed.refresh()
        print(f"  Advisory feed refreshed: {count} advisories loaded")
        if errors:
            print(f"  Warnings: {', '.join(errors)}")
        print()

    scanner = Scanner(feed=feed, online=parsed.online)

    if target.is_dir():
        result = scanner.scan_directory(target)
    elif target.suffix in (".gz", ".tgz") or ".tar." in target.name:
        result = scanner.scan_tarball(target)
    elif target.suffix == ".whl":
        result = scanner.scan_wheel(target)
    else:
        print(f"Error: unsupported file type: {target.suffix}", file=sys.stderr)
        sys.exit(1)

    if parsed.json:
        import json
        print(json.dumps({
            "target": result.target,
            "passed": result.passed,
            "files_scanned": result.files_scanned,
            "duration_ms": result.duration_ms,
            "findings": [
                {"rule": f.rule, "severity": f.severity.value, "file": f.file_path,
                 "description": f.description, "line": f.line, "match": f.match}
                for f in result.findings
            ],
        }, indent=2))
    else:
        _print_human(result)

    # Exit code based on --fail-on
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    threshold = severity_order[parsed.fail_on]
    for f in result.findings:
        if severity_order[f.severity.value] <= threshold:
            sys.exit(1)


def _print_human(result) -> None:
    print(f"\n  LeakWall Scan: {result.target}")
    print(f"  Files scanned: {result.files_scanned}")
    print(f"  Duration: {result.duration_ms}ms\n")

    if not result.findings:
        print("  No issues found. Safe to publish.\n")
        return

    icons = {
        Severity.CRITICAL: "CRIT",
        Severity.HIGH: "HIGH",
        Severity.MEDIUM: "MED ",
        Severity.LOW: "LOW ",
        Severity.INFO: "INFO",
    }

    for f in sorted(result.findings, key=lambda x: list(Severity).index(x.severity)):
        icon = icons[f.severity]
        loc = f"{f.file_path}:{f.line}" if f.line else f.file_path
        print(f"  [{icon}] [{f.severity.value.upper()}] {f.description}")
        print(f"     {loc}")
        if f.match:
            print(f"     Match: {f.match}")
        print()

    print(f"  {result.summary()}\n")


if __name__ == "__main__":
    main()
