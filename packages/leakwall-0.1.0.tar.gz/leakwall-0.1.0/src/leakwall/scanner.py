"""LeakWall scanner engine — detects supply chain risks in packages."""

from __future__ import annotations

import json
import re
import tarfile
import urllib.request
import urllib.error
import zipfile
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

from leakwall.advisory import AdvisoryFeed


class Severity(Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass(frozen=True)
class Finding:
    """A single security finding."""
    rule: str
    severity: Severity
    file_path: str
    description: str
    line: int | None = None
    match: str | None = None


@dataclass
class ScanResult:
    """Complete scan result."""
    target: str
    findings: list[Finding] = field(default_factory=list)
    files_scanned: int = 0
    duration_ms: int = 0

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.CRITICAL)

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.HIGH)

    @property
    def passed(self) -> bool:
        return self.critical_count == 0 and self.high_count == 0

    def summary(self) -> str:
        counts = {}
        for f in self.findings:
            counts[f.severity.value] = counts.get(f.severity.value, 0) + 1
        parts = [f"{v} {k}" for k, v in sorted(counts.items())]
        status = "PASSED" if self.passed else "FAILED"
        return f"LeakWall [{status}]: {', '.join(parts) or 'clean'} ({self.files_scanned} files)"


# --- Rule Definitions ---

_SOURCEMAP_PATTERNS = (
    re.compile(r"//[#@]\s*sourceMappingURL\s*=\s*data:", re.IGNORECASE),
    re.compile(r"//[#@]\s*sourceMappingURL\s*=\s*\S+\.map", re.IGNORECASE),
)

_CREDENTIAL_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"""(?:api[_-]?key|apikey|secret[_-]?key|auth[_-]?token|access[_-]?token|password)\s*[:=]\s*['"][^'"]{8,}['"]""", re.IGNORECASE), "hardcoded credential"),
    (re.compile(r"sk-[a-zA-Z0-9]{20,}"), "Anthropic/OpenAI API key"),
    (re.compile(r"ghp_[a-zA-Z0-9]{36}"), "GitHub personal access token"),
    (re.compile(r"gho_[a-zA-Z0-9]{36}"), "GitHub OAuth token"),
    (re.compile(r"AKIA[0-9A-Z]{16}"), "AWS access key ID"),
    (re.compile(r"-----BEGIN (RSA |EC |DSA )?PRIVATE KEY-----"), "private key"),
    (re.compile(r"xox[bporas]-[a-zA-Z0-9-]{10,}"), "Slack token"),
    (re.compile(r"npm_[a-zA-Z0-9]{36}"), "npm token"),
)

# Values that are obviously test fixtures, not real credentials
_TEST_FIXTURE_VALUES = re.compile(
    r"""['"](?:test[-_]?key|fake[-_]?key|dummy|placeholder|example|xxx|changeme|"""
    r"""your[-_]?key[-_]?here|replace[-_]?me|my[-_]?\w+-key|k|key|test)['"]""",
    re.IGNORECASE,
)

# File paths that are test files (credential findings demoted to INFO)
_TEST_FILE_PATTERN = re.compile(
    r"(?:^|/)tests?/|test_[^/]+\.py$|_test\.py$|\.test\.[jt]sx?$|__tests__/|/fixtures?/|/mocks?/",
)

_FEATURE_FLAG_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"\bfeature\s*\(\s*['\"]([^'\"]+)['\"]\s*\)", re.IGNORECASE), "feature() gate call"),
    (re.compile(r"FEATURE[_-]FLAG|featureFlag|feature_flag", re.IGNORECASE), "feature flag reference"),
    (re.compile(r"process\.env\.(?:INTERNAL|HIDDEN|DEBUG|SECRET|UNRELEASED)[_A-Z]*", re.IGNORECASE), "internal env var"),
    (re.compile(r"__INTERNAL__|__DEBUG__|__HIDDEN__", re.IGNORECASE), "internal debug constant"),
)

_DANGEROUS_FILE_PATTERNS = (
    "*.map",
    "*.pem",
    "*.key",
    "*.p12",
    "*.pfx",
    ".env",
    ".env.*",
    "credentials.json",
    "credentials.yaml",
    "credentials.yml",
    ".npmrc",
    ".pypirc",
)

_DANGEROUS_SCRIPT_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"curl\s+.*\|\s*(bash|sh)", re.IGNORECASE), "pipe to shell"),
    (re.compile(r"eval\s*\(.*base64", re.IGNORECASE), "eval base64"),
    (re.compile(r"child_process|subprocess|os\.system|exec\(", re.IGNORECASE), "process execution in install script"),
)


# --- Typosquatting Detection ---

_POPULAR_PACKAGES: dict[str, set[str]] = {
    "npm": {"express", "react", "lodash", "axios", "webpack", "typescript", "eslint",
            "prettier", "next", "vue", "angular", "moment", "chalk", "commander",
            "debug", "fs-extra", "glob", "inquirer", "uuid", "dotenv", "cors"},
    "pypi": {"requests", "numpy", "pandas", "flask", "django", "pytest", "boto3",
             "tensorflow", "torch", "scikit-learn", "pillow", "celery", "redis",
             "sqlalchemy", "fastapi", "pydantic", "httpx", "aiohttp", "cryptography"},
}


def _check_typosquat(name: str, ecosystem: str) -> str | None:
    """Check if a package name looks like a typosquat of a popular package."""
    popular = _POPULAR_PACKAGES.get(ecosystem, set())
    for real_name in popular:
        if name == real_name:
            return None  # Exact match, fine
        dist = _edit_distance(name, real_name)
        if 0 < dist <= 2 and len(name) >= 3:
            return real_name
        # Check common typosquat patterns
        if name == real_name.replace("-", ""):  # removing hyphen
            continue
        if name == real_name + "s" or name == real_name + "js" or name == real_name + "-js":
            return real_name
        if name.startswith(real_name + "-") and len(name) - len(real_name) <= 4:
            return None  # Legitimate scoped package
    return None


def _edit_distance(a: str, b: str) -> int:
    """Levenshtein distance."""
    if len(a) < len(b):
        return _edit_distance(b, a)
    if len(b) == 0:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            curr.append(min(prev[j + 1] + 1, curr[j] + 1, prev[j] + (0 if ca == cb else 1)))
        prev = curr
    return prev[len(b)]


# --- Binary Payload Detection ---

_BINARY_SUSPICIOUS_PATTERNS: tuple[tuple[bytes, str], ...] = (
    (b"#!/bin/sh", "Shell script in binary file"),
    (b"#!/bin/bash", "Bash script in binary file"),
    (b"#!/usr/bin/env python", "Python script in binary file"),
    (b"#!/usr/bin/env node", "Node script in binary file"),
    (b"MZ", "Windows PE executable"),  # First 2 bytes of .exe
    (b"\x7fELF", "Linux ELF executable"),
    (b"\xcf\xfa\xed\xfe", "macOS Mach-O executable"),  # Little-endian
    (b"\xfe\xed\xfa\xcf", "macOS Mach-O executable"),  # Big-endian
    (b"eval(", "eval() call in binary"),
    (b"child_process", "child_process reference in binary"),
    (b"require('child_process')", "child_process require in binary"),
)

_BINARY_EXTENSIONS = {".node", ".so", ".dll", ".dylib", ".wasm"}


class Scanner:
    """Package security scanner."""

    def __init__(self, feed: AdvisoryFeed | None = None, online: bool = False) -> None:
        self._feed = feed or AdvisoryFeed()
        self._online = online

    def scan_directory(self, path: str | Path) -> ScanResult:
        """Scan a directory (e.g., unpacked package or project root)."""
        import time
        start = time.monotonic()
        root = Path(path)
        result = ScanResult(target=str(root))

        if not root.is_dir():
            result.findings.append(Finding(
                rule="invalid_target", severity=Severity.CRITICAL,
                file_path=str(root), description="Target is not a directory",
            ))
            return result

        for file_path in _walk_files(root):
            result.files_scanned += 1
            rel = str(file_path.relative_to(root))

            # Check dangerous file patterns
            for pattern in _DANGEROUS_FILE_PATTERNS:
                if file_path.match(pattern):
                    sev = Severity.CRITICAL if pattern == "*.map" else Severity.HIGH
                    result.findings.append(Finding(
                        rule="dangerous_file", severity=sev,
                        file_path=rel,
                        description=f"Dangerous file pattern: {pattern}",
                    ))

            # Check file content (text files)
            if file_path.suffix in (".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs",
                                     ".py", ".json", ".yaml", ".yml", ".toml",
                                     ".sh", ".bash", ".cmd", ".ps1"):
                try:
                    content = file_path.read_text(errors="replace")
                    self._scan_content(content, rel, result)
                except Exception:
                    pass

            # Check binary files for suspicious payloads
            if file_path.suffix in _BINARY_EXTENSIONS or (
                file_path.suffix == "" and not file_path.name.startswith(".")
            ):
                self._check_binary(file_path, rel, result)

        # Check package.json for compromised deps
        pkg_json = root / "package.json"
        if pkg_json.exists():
            self._check_npm_deps(pkg_json, result)

        # Check pyproject.toml / requirements.txt for compromised deps
        for req_file in ("requirements.txt", "requirements-dev.txt"):
            req_path = root / req_file
            if req_path.exists():
                self._check_pip_deps(req_path, result)

        # Check lockfiles
        self._check_lockfiles(root, result)

        result.duration_ms = int((time.monotonic() - start) * 1000)
        return result

    def scan_tarball(self, path: str | Path) -> ScanResult:
        """Scan a .tar.gz / .tgz file (npm pack or pip sdist)."""
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            with tarfile.open(str(path), "r:gz") as tar:
                tar.extractall(td, filter="data")
            return self.scan_directory(td)

    def scan_wheel(self, path: str | Path) -> ScanResult:
        """Scan a .whl file (pip wheel)."""
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            with zipfile.ZipFile(str(path), "r") as zf:
                zf.extractall(td)
            return self.scan_directory(td)

    def _scan_content(self, content: str, rel_path: str, result: ScanResult) -> None:
        lines = content.split("\n")

        for line_num, line in enumerate(lines, 1):
            # Sourcemap detection
            for pattern in _SOURCEMAP_PATTERNS:
                if pattern.search(line):
                    result.findings.append(Finding(
                        rule="sourcemap_leak", severity=Severity.CRITICAL,
                        file_path=rel_path, line=line_num,
                        description="Source map reference found — exposes original source code",
                        match=line.strip()[:120],
                    ))

            # Credential detection
            for pattern, desc in _CREDENTIAL_PATTERNS:
                m = pattern.search(line)
                if m:
                    # Skip obvious test fixture values
                    if _TEST_FIXTURE_VALUES.search(line):
                        continue
                    # Demote to INFO in test files
                    severity = Severity.INFO if _TEST_FILE_PATTERN.search(rel_path) else Severity.CRITICAL
                    result.findings.append(Finding(
                        rule="credential_leak", severity=severity,
                        file_path=rel_path, line=line_num,
                        description=f"Potential {desc}" + (" (test file)" if severity == Severity.INFO else ""),
                        match=_redact(m.group(0)),
                    ))

            # Feature flag detection
            for pattern, desc in _FEATURE_FLAG_PATTERNS:
                m = pattern.search(line)
                if m:
                    result.findings.append(Finding(
                        rule="feature_flag", severity=Severity.MEDIUM,
                        file_path=rel_path, line=line_num,
                        description=f"Internal {desc} — may expose unreleased features",
                        match=m.group(0)[:80],
                    ))

            # Dangerous install scripts
            for pattern, desc in _DANGEROUS_SCRIPT_PATTERNS:
                if pattern.search(line):
                    result.findings.append(Finding(
                        rule="dangerous_script", severity=Severity.HIGH,
                        file_path=rel_path, line=line_num,
                        description=f"Dangerous install pattern: {desc}",
                        match=line.strip()[:120],
                    ))

    def _check_npm_deps(self, pkg_json: Path, result: ScanResult) -> None:
        try:
            data = json.loads(pkg_json.read_text())
            all_deps: dict[str, str] = {}
            for key in ("dependencies", "devDependencies", "optionalDependencies"):
                all_deps.update(data.get(key, {}))

            # Check postinstall scripts
            scripts = data.get("scripts", {})
            for script_name in ("postinstall", "preinstall", "install"):
                if script_name in scripts:
                    result.findings.append(Finding(
                        rule="install_script", severity=Severity.MEDIUM,
                        file_path="package.json",
                        description=f"Package has {script_name} script: {scripts[script_name][:100]}",
                    ))

            # Check compromised versions and typosquats
            for dep, version in all_deps.items():
                clean_ver = version.lstrip("^~>=<!")
                advisory = self._feed.is_compromised(dep, clean_ver)
                if advisory:
                    result.findings.append(Finding(
                        rule="compromised_dependency", severity=Severity.CRITICAL,
                        file_path="package.json",
                        description=f"COMPROMISED: {dep}@{clean_ver} — {advisory.description}",
                    ))

                # Typosquat check
                similar = _check_typosquat(dep, "npm")
                if similar:
                    result.findings.append(Finding(
                        rule="typosquat_suspect", severity=Severity.HIGH,
                        file_path="package.json",
                        description=f"Possible typosquat: '{dep}' looks like '{similar}'",
                    ))
        except (json.JSONDecodeError, Exception):
            pass

    def _check_pip_deps(self, req_path: Path, result: ScanResult) -> None:
        try:
            for line in req_path.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                # Parse package name
                m = re.match(r"([a-zA-Z0-9_-]+)", line)
                if not m:
                    continue
                pkg_name = m.group(1).lower()

                # Check compromised version
                ver_m = re.search(r"==\s*([\d.]+)", line)
                if ver_m:
                    advisory = self._feed.is_compromised(pkg_name, ver_m.group(1))
                    if advisory:
                        result.findings.append(Finding(
                            rule="compromised_dependency", severity=Severity.CRITICAL,
                            file_path=str(req_path.name),
                            description=f"COMPROMISED: {pkg_name}=={ver_m.group(1)} — {advisory.description}",
                        ))

                # Typosquat check
                similar = _check_typosquat(pkg_name, "pypi")
                if similar:
                    result.findings.append(Finding(
                        rule="typosquat_suspect", severity=Severity.HIGH,
                        file_path=str(req_path.name),
                        description=f"Possible typosquat: '{pkg_name}' looks like '{similar}'",
                    ))
        except Exception:
            pass

    def _check_binary(self, file_path: Path, rel_path: str, result: ScanResult) -> None:
        """Check binary files for suspicious patterns."""
        try:
            data = file_path.read_bytes()[:8192]  # First 8KB
            for pattern, desc in _BINARY_SUSPICIOUS_PATTERNS:
                if pattern in data:
                    result.findings.append(Finding(
                        rule="binary_payload", severity=Severity.HIGH,
                        file_path=rel_path,
                        description=f"Suspicious binary content: {desc}",
                    ))
        except Exception:
            pass

    def _check_lockfiles(self, root: Path, result: ScanResult) -> None:
        """Parse lockfiles and check resolved versions against advisory feed."""
        # package-lock.json
        pkg_lock = root / "package-lock.json"
        if pkg_lock.exists():
            self._check_package_lock(pkg_lock, result)

        # pnpm-lock.yaml
        pnpm_lock = root / "pnpm-lock.yaml"
        if pnpm_lock.exists():
            self._check_pnpm_lock(pnpm_lock, result)

        # yarn.lock
        yarn_lock = root / "yarn.lock"
        if yarn_lock.exists():
            self._check_yarn_lock(yarn_lock, result)

        # Pipfile.lock
        pipfile_lock = root / "Pipfile.lock"
        if pipfile_lock.exists():
            self._check_pipfile_lock(pipfile_lock, result)

        # uv.lock
        uv_lock = root / "uv.lock"
        if uv_lock.exists():
            self._check_uv_lock(uv_lock, result)

        # poetry.lock
        poetry_lock = root / "poetry.lock"
        if poetry_lock.exists():
            self._check_poetry_lock(poetry_lock, result)

    def _check_package_lock(self, lock_path: Path, result: ScanResult) -> None:
        """Parse package-lock.json and check resolved versions."""
        try:
            data = json.loads(lock_path.read_text())
            packages = data.get("packages", {})
            for pkg_path, info in packages.items():
                if not pkg_path:  # Root entry
                    continue
                version = info.get("version", "")
                # Extract package name from path like "node_modules/axios"
                name = pkg_path.split("node_modules/")[-1] if "node_modules/" in pkg_path else pkg_path
                self._check_lockfile_entry(name, version, "npm", "package-lock.json", result)
        except (json.JSONDecodeError, Exception):
            pass

    def _check_pnpm_lock(self, lock_path: Path, result: ScanResult) -> None:
        """Parse pnpm-lock.yaml and check resolved versions."""
        try:
            content = lock_path.read_text()
            # Match patterns like "axios@1.14.1:" or "/axios@1.14.1:"
            for m in re.finditer(r"['\"]?/?([a-zA-Z0-9@/_-]+)@(\d+\.\d+\.\d+[^:'\"]*)['\"]?\s*:", content):
                name = m.group(1).lstrip("/")
                version = m.group(2)
                self._check_lockfile_entry(name, version, "npm", "pnpm-lock.yaml", result)
        except Exception:
            pass

    def _check_yarn_lock(self, lock_path: Path, result: ScanResult) -> None:
        """Parse yarn.lock and check resolved versions."""
        try:
            content = lock_path.read_text()
            # Match "name@version:" header lines and "version" fields
            current_names: list[str] = []
            for line in content.splitlines():
                # Header line like: axios@^1.14.0:
                header_m = re.match(r'^["\']?([a-zA-Z0-9@/_-]+)@', line)
                if header_m and not line.startswith(" "):
                    current_names = [header_m.group(1)]
                # Version line like:   version "1.14.1"
                ver_m = re.match(r'^\s+version\s+"([^"]+)"', line)
                if ver_m and current_names:
                    version = ver_m.group(1)
                    for name in current_names:
                        self._check_lockfile_entry(name, version, "npm", "yarn.lock", result)
                    current_names = []
        except Exception:
            pass

    def _check_pipfile_lock(self, lock_path: Path, result: ScanResult) -> None:
        """Parse Pipfile.lock and check resolved versions."""
        try:
            data = json.loads(lock_path.read_text())
            for section in ("default", "develop"):
                packages = data.get(section, {})
                for name, info in packages.items():
                    version = info.get("version", "").lstrip("=")
                    if version:
                        self._check_lockfile_entry(name, version, "pypi", "Pipfile.lock", result)
        except (json.JSONDecodeError, Exception):
            pass

    def _check_uv_lock(self, lock_path: Path, result: ScanResult) -> None:
        """Parse uv.lock and check resolved versions."""
        try:
            content = lock_path.read_text()
            current_name = ""
            for line in content.splitlines():
                name_m = re.match(r'^name\s*=\s*"([^"]+)"', line)
                if name_m:
                    current_name = name_m.group(1)
                ver_m = re.match(r'^version\s*=\s*"([^"]+)"', line)
                if ver_m and current_name:
                    self._check_lockfile_entry(current_name, ver_m.group(1), "pypi", "uv.lock", result)
                if line.strip() == "[[package]]":
                    current_name = ""
        except Exception:
            pass

    def _check_poetry_lock(self, lock_path: Path, result: ScanResult) -> None:
        """Parse poetry.lock and check resolved versions."""
        try:
            content = lock_path.read_text()
            current_name = ""
            for line in content.splitlines():
                name_m = re.match(r'^name\s*=\s*"([^"]+)"', line)
                if name_m:
                    current_name = name_m.group(1)
                ver_m = re.match(r'^version\s*=\s*"([^"]+)"', line)
                if ver_m and current_name:
                    self._check_lockfile_entry(current_name, ver_m.group(1), "pypi", "poetry.lock", result)
                if line.strip() == "[[package]]":
                    current_name = ""
        except Exception:
            pass

    def _check_lockfile_entry(
        self, name: str, version: str, ecosystem: str, lockfile: str, result: ScanResult,
    ) -> None:
        """Check a single lockfile entry against advisory feed and optionally registry."""
        advisory = self._feed.is_compromised(name, version)
        if advisory:
            result.findings.append(Finding(
                rule="compromised_dependency", severity=Severity.CRITICAL,
                file_path=lockfile,
                description=f"COMPROMISED in lockfile: {name}@{version} — {advisory.description}",
            ))

        if self._online:
            reg_finding = self._check_registry_status(name, version, ecosystem)
            if reg_finding:
                result.findings.append(reg_finding)

    def _check_registry_status(
        self, package: str, version: str, ecosystem: str,
    ) -> Finding | None:
        """Check if a version has been unpublished/yanked from the registry."""
        try:
            if ecosystem == "npm":
                url = f"https://registry.npmjs.org/{package}/{version}"
            elif ecosystem == "pypi":
                url = f"https://pypi.org/pypi/{package}/{version}/json"
            else:
                return None

            req = urllib.request.Request(url, headers={"User-Agent": "leakwall/0.1"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                if ecosystem == "pypi":
                    data = json.loads(resp.read().decode())
                    info = data.get("info", {})
                    # Check if yanked
                    if data.get("urls"):
                        for url_info in data["urls"]:
                            if url_info.get("yanked", False):
                                return Finding(
                                    rule="yanked_version", severity=Severity.HIGH,
                                    file_path="lockfile",
                                    description=f"YANKED: {package}=={version} was yanked from PyPI",
                                )
            return None
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return Finding(
                    rule="unpublished_version", severity=Severity.HIGH,
                    file_path="lockfile",
                    description=f"UNPUBLISHED: {package}@{version} returns 404 — may have been removed",
                )
            return None
        except (urllib.error.URLError, OSError):
            return None


def _walk_files(root: Path) -> list[Path]:
    """Walk directory, skip node_modules/.git/.venv."""
    files = []
    skip = {"node_modules", ".git", ".venv", "__pycache__", ".tox", ".mypy_cache"}
    for item in sorted(root.rglob("*")):
        if any(part in skip for part in item.parts):
            continue
        if item.is_file() and item.stat().st_size < 10_000_000:  # Skip >10MB
            files.append(item)
    return files


def _redact(value: str) -> str:
    """Redact sensitive values, keeping first 4 and last 2 chars."""
    if len(value) <= 8:
        return "***"
    return value[:4] + "***" + value[-2:]
