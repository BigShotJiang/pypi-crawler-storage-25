# LeakWall

Pre-publish supply chain security scanner for npm and pip packages. Zero dependencies.

Born from the week that broke the supply chain: **axios trojaned** (RAT via postinstall), **telnyx compromised** (WAV steganography payload), **Claude Code source leaked** (60MB sourcemap in npm) -- all within 7 days. LeakWall catches these before you publish.

## Install

```bash
pip install leakwall
```

## Quick Start

```bash
# Scan your project before publishing
leakwall .

# Scan a built package
leakwall dist/
leakwall my-package-1.0.0.tar.gz
leakwall my_package-1.0.0-py3-none-any.whl

# CI mode (JSON output, fail on high+)
leakwall --json --fail-on high .
```

## What It Detects

### 9 Detection Categories

| Category | What It Catches | Severity |
|----------|----------------|----------|
| **Source Map Leak** | `.js.map` files, inline `sourceMappingURL`, external references | Critical |
| **Credential Leak** | API keys (Anthropic/OpenAI/GitHub/AWS/Slack/npm), private keys, hardcoded passwords | Critical |
| **Compromised Dependencies** | Known malicious versions (axios@1.14.1, telnyx@4.87.1, etc.) via live advisory feed | Critical |
| **Lockfile Audit** | Compromised versions in package-lock.json, pnpm-lock.yaml, yarn.lock, Pipfile.lock, uv.lock, poetry.lock | Critical |
| **Typosquatting** | Suspiciously similar package names (`axois`, `reqeusts`, `lodashe`) via edit distance | High |
| **Binary Payload** | PE/ELF/Mach-O executables, embedded scripts in `.node`/`.so`/`.dll`/`.wasm` files | High |
| **Dangerous Files** | `.env`, `.pem`, `.key`, `.npmrc`, `.pypirc`, `credentials.json` | High |
| **Dangerous Scripts** | `curl \| bash` in postinstall, `eval(base64...)`, `child_process` in install hooks | High |
| **Feature Flags** | `feature("KAIROS")`, `INTERNAL_*` env vars, `__DEBUG__` constants, `dangerouslyDisable*` | Medium |

### Live Advisory Feed

LeakWall doesn't rely on a hardcoded list. It pulls from multiple sources:

```
Built-in (18 known malicious packages)
  + GitHub-hosted JSON (updated without release)
  + OSV.dev API (Google's vulnerability database)
  = Always up-to-date
```

```bash
# Force refresh advisory cache before scanning
leakwall --refresh .

# Check a package version against live registry
leakwall --online .
```

Advisory cache: `~/.cache/leakwall/advisories.json` (24h TTL, auto-refreshes).

### Lockfile Support

Scans **all 6 major lockfile formats** for compromised transitive dependencies:

| Lockfile | Ecosystem |
|----------|-----------|
| `package-lock.json` | npm |
| `pnpm-lock.yaml` | pnpm |
| `yarn.lock` | Yarn |
| `Pipfile.lock` | Pipenv |
| `uv.lock` | uv |
| `poetry.lock` | Poetry |

### Typosquatting Detection

Checks dependency names against 40 popular npm/pypi packages using Levenshtein distance. Catches:
- Character swaps: `axois` (axios), `reqeusts` (requests)
- Suffix attacks: `expresss`, `lodashjs`
- Combined: anything within edit distance 2 of a popular package

### Smart False Positive Reduction

- Test files (`tests/`, `test_*.py`) have credential findings demoted to INFO
- Common fixture values (`"test-key"`, `"placeholder"`, `"example"`) are skipped entirely
- `node_modules/`, `.git/`, `.venv/` directories are always skipped

## CLI Reference

```
leakwall <target>              Scan directory, .tar.gz, .tgz, or .whl

Options:
  --json                       Output results as JSON
  --fail-on {critical,high,medium}
                               Exit non-zero at this severity (default: high)
  --refresh                    Refresh advisory cache before scanning
  --online                     Check registry for yanked/unpublished versions
```

## CI Integration

### GitHub Actions

```yaml
name: Security
on: [push, pull_request]
jobs:
  leakwall:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.11" }
      - run: pip install leakwall
      - run: leakwall --fail-on high .
```

### Pre-publish Hook (npm)

```json
{
  "scripts": {
    "prepublishOnly": "leakwall ."
  }
}
```

### Pre-publish Hook (Python)

```toml
# pyproject.toml (with hatch)
[tool.hatch.build.hooks.custom]
pre-build = "leakwall ."
```

## Example Output

```
  LeakWall Scan: ./my-package
  Files scanned: 142
  Duration: 230ms

  [CRIT] Source map reference found -- exposes original source code
     dist/index.js:7601
     Match: //# sourceMappingURL=index.js.map

  [CRIT] COMPROMISED: axios@1.14.1 is a known malicious version
     package-lock.json (lockfile)

  [HIGH] Possible typosquat of 'requests': reqeusts
     requirements.txt:3

  [HIGH] Windows PE executable found in package
     vendor/helper.node

  LeakWall [FAILED]: 2 critical, 2 high (142 files)
```

## How It's Different

| | LeakWall | npm audit / pip-audit | Snyk / Socket |
|---|---|---|---|
| **Scans your own package** | Yes | No (scans dependencies) | Partial |
| **Source map detection** | Yes | No | No |
| **Credential scanning** | Yes | No | Yes |
| **Typosquatting** | Yes | No | Yes (paid) |
| **Binary payload** | Yes | No | Partial |
| **Lockfile audit** | Yes | Yes | Yes |
| **Feature flag detection** | Yes | No | No |
| **Zero dependencies** | Yes | No | No |
| **Offline capable** | Yes (builtin list) | No | No |
| **Free** | Yes | Yes | Freemium |

## Contributing

Advisory updates welcome. Edit `data/compromised.json` and open a PR -- it takes effect immediately for all `--refresh` users without a new release.

## License

MIT
