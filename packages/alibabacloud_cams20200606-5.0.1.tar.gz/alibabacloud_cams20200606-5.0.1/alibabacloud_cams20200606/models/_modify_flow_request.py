# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from darabonba.model import DaraModel

class ModifyFlowRequest(DaraModel):
    def __init__(
        self,
        categories: List[str] = None,
        cust_space_id: str = None,
        endpoint_uri: str = None,
        flow_id: str = None,
        flow_name: str = None,
        owner_id: int = None,
        resource_owner_account: str = None,
        resource_owner_id: int = None,
    ):
        # The information about the categories of the Flow.
        # 
        # This parameter is required.
        self.categories = categories
        # The space ID of the user within the independent software vendor (ISV) account.
        self.cust_space_id = cust_space_id
        self.endpoint_uri = endpoint_uri
        # The Flow ID.
        self.flow_id = flow_id
        # The name of the Flow.
        # 
        # This parameter is required.
        self.flow_name = flow_name
        self.owner_id = owner_id
        self.resource_owner_account = resource_owner_account
        self.resource_owner_id = resource_owner_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.categories is not None:
            result['Categories'] = self.categories

        if self.cust_space_id is not None:
            result['CustSpaceId'] = self.cust_space_id

        if self.endpoint_uri is not None:
            result['EndpointUri'] = self.endpoint_uri

        if self.flow_id is not None:
            result['FlowId'] = self.flow_id

        if self.flow_name is not None:
            result['FlowName'] = self.flow_name

        if self.owner_id is not None:
            result['OwnerId'] = self.owner_id

        if self.resource_owner_account is not None:
            result['ResourceOwnerAccount'] = self.resource_owner_account

        if self.resource_owner_id is not None:
            result['ResourceOwnerId'] = self.resource_owner_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Categories') is not None:
            self.categories = m.get('Categories')

        if m.get('CustSpaceId') is not None:
            self.cust_space_id = m.get('CustSpaceId')

        if m.get('EndpointUri') is not None:
            self.endpoint_uri = m.get('EndpointUri')

        if m.get('FlowId') is not None:
            self.flow_id = m.get('FlowId')

        if m.get('FlowName') is not None:
            self.flow_name = m.get('FlowName')

        if m.get('OwnerId') is not None:
            self.owner_id = m.get('OwnerId')

        if m.get('ResourceOwnerAccount') is not None:
            self.resource_owner_account = m.get('ResourceOwnerAccount')

        if m.get('ResourceOwnerId') is not None:
            self.resource_owner_id = m.get('ResourceOwnerId')

        return self

