# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class DeletePhoneMessageQrdlRequest(DaraModel):
    def __init__(
        self,
        cust_space_id: str = None,
        owner_id: int = None,
        phone_number: str = None,
        qrdl_code: str = None,
        resource_owner_account: str = None,
        resource_owner_id: int = None,
    ):
        # The space ID of the RAM user within the independent software vendor (ISV) account.
        self.cust_space_id = cust_space_id
        self.owner_id = owner_id
        # The phone number. Add the country code before the phone number.
        # 
        # This parameter is required.
        self.phone_number = phone_number
        # QR code encoding.
        # 
        # This parameter is required.
        self.qrdl_code = qrdl_code
        self.resource_owner_account = resource_owner_account
        self.resource_owner_id = resource_owner_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.cust_space_id is not None:
            result['CustSpaceId'] = self.cust_space_id

        if self.owner_id is not None:
            result['OwnerId'] = self.owner_id

        if self.phone_number is not None:
            result['PhoneNumber'] = self.phone_number

        if self.qrdl_code is not None:
            result['QrdlCode'] = self.qrdl_code

        if self.resource_owner_account is not None:
            result['ResourceOwnerAccount'] = self.resource_owner_account

        if self.resource_owner_id is not None:
            result['ResourceOwnerId'] = self.resource_owner_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CustSpaceId') is not None:
            self.cust_space_id = m.get('CustSpaceId')

        if m.get('OwnerId') is not None:
            self.owner_id = m.get('OwnerId')

        if m.get('PhoneNumber') is not None:
            self.phone_number = m.get('PhoneNumber')

        if m.get('QrdlCode') is not None:
            self.qrdl_code = m.get('QrdlCode')

        if m.get('ResourceOwnerAccount') is not None:
            self.resource_owner_account = m.get('ResourceOwnerAccount')

        if m.get('ResourceOwnerId') is not None:
            self.resource_owner_id = m.get('ResourceOwnerId')

        return self

