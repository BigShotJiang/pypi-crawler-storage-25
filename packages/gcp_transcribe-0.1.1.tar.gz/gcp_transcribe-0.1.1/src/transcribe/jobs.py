from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

JOBS_DIR = Path.home() / ".transcribe" / "jobs"


@dataclass
class JobMetadata:
    job_id: str
    operation_name: str
    project_id: str
    region: str
    bucket: str
    languages: list[str]
    audio_prefix: str
    output_prefix: str
    uri_to_path: dict[str, str]
    submitted_at: str
    state: str = "running"
    completed_at: str | None = None
    error: str | None = None

    @staticmethod
    def now_ts() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _path_for(job_id: str) -> Path:
    return JOBS_DIR / f"{job_id}.json"


def save(job: JobMetadata) -> Path:
    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    path = _path_for(job.job_id)
    path.write_text(json.dumps(asdict(job), indent=2), encoding="utf-8")
    return path


def load(job_id: str) -> JobMetadata:
    path = _path_for(job_id)
    if not path.exists():
        raise FileNotFoundError(f"No job found with id '{job_id}' at {path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    return JobMetadata(**data)


def list_all() -> list[JobMetadata]:
    if not JOBS_DIR.exists():
        return []
    out: list[JobMetadata] = []
    for p in sorted(JOBS_DIR.glob("*.json")):
        try:
            out.append(JobMetadata(**json.loads(p.read_text(encoding="utf-8"))))
        except Exception:
            continue
    return sorted(out, key=lambda j: j.submitted_at, reverse=True)


def delete(job_id: str) -> bool:
    path = _path_for(job_id)
    if path.exists():
        path.unlink()
        return True
    return False
