from __future__ import annotations

import json
from pathlib import Path

from .speech import TranscriptResult


def write_outputs(result: TranscriptResult, out_dir: Path, srt: bool = False) -> list[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    base = out_dir / result.source_path.stem
    written: list[Path] = []

    txt_path = base.with_suffix(".txt")
    txt_path.write_text(result.text + "\n", encoding="utf-8")
    written.append(txt_path)

    json_path = base.with_suffix(".json")
    json_path.write_text(
        json.dumps(result.raw, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    written.append(json_path)

    if srt:
        srt_path = base.with_suffix(".srt")
        srt_path.write_text(_to_srt(result.raw), encoding="utf-8")
        written.append(srt_path)

    return written


def _to_srt(payload: dict) -> str:
    blocks: list[str] = []
    idx = 1
    for r in payload.get("results", []):
        alts = r.get("alternatives") or []
        if not alts:
            continue
        words = alts[0].get("words") or []
        if not words:
            transcript = alts[0].get("transcript", "").strip()
            if not transcript:
                continue
            end = _parse_seconds(r.get("resultEndOffset", "0s"))
            blocks.append(_srt_block(idx, 0.0, end, transcript))
            idx += 1
            continue
        chunk: list[str] = []
        chunk_start = _parse_seconds(words[0].get("startOffset", "0s"))
        chunk_end = chunk_start
        for i, w in enumerate(words):
            chunk.append(w.get("word", ""))
            chunk_end = _parse_seconds(w.get("endOffset", "0s"))
            if len(chunk) >= 10 or i == len(words) - 1:
                blocks.append(_srt_block(idx, chunk_start, chunk_end, " ".join(chunk)))
                idx += 1
                chunk = []
                chunk_start = chunk_end
    return "\n".join(blocks)


def _srt_block(idx: int, start: float, end: float, text: str) -> str:
    return f"{idx}\n{_fmt_ts(start)} --> {_fmt_ts(end)}\n{text}\n"


def _parse_seconds(value) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    s = str(value)
    if s.endswith("s"):
        s = s[:-1]
    try:
        return float(s)
    except ValueError:
        return 0.0


def _fmt_ts(seconds: float) -> str:
    if seconds < 0:
        seconds = 0.0
    ms = int(round((seconds - int(seconds)) * 1000))
    h = int(seconds) // 3600
    m = (int(seconds) % 3600) // 60
    s = int(seconds) % 60
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
