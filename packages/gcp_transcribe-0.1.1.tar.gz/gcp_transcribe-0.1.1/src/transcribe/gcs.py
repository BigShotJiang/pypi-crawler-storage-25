from __future__ import annotations

from pathlib import Path

from google.api_core.exceptions import Conflict, NotFound
from google.cloud import storage


def ensure_bucket(client: storage.Client, name: str, region: str) -> storage.Bucket:
    try:
        return client.get_bucket(name)
    except NotFound:
        bucket = client.bucket(name)
        bucket.location = region
        try:
            return client.create_bucket(bucket)
        except Conflict:
            return client.get_bucket(name)


def upload(client: storage.Client, bucket_name: str, local_path: Path, blob_name: str) -> str:
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(blob_name)
    blob.upload_from_filename(str(local_path))
    return f"gs://{bucket_name}/{blob_name}"


def delete_prefix(client: storage.Client, bucket_name: str, prefix: str) -> None:
    bucket = client.bucket(bucket_name)
    for blob in bucket.list_blobs(prefix=prefix):
        blob.delete()
