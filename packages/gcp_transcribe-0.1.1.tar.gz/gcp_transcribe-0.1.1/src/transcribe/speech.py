from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from google.cloud import speech_v2, storage
from google.cloud.speech_v2.types import cloud_speech

from .config import Config
from .gcs import delete_prefix, ensure_bucket, upload
from .jobs import JobMetadata


@dataclass
class TranscriptResult:
    source_path: Path
    text: str
    raw: dict
    language: str | None


@dataclass
class JobStatus:
    state: str
    progress: int | None
    error: str | None


def _speech_client(config: Config) -> speech_v2.SpeechClient:
    return speech_v2.SpeechClient(
        client_options={"api_endpoint": f"{config.region}-speech.googleapis.com"}
    )


def _build_recognition_config(languages: list[str]) -> cloud_speech.RecognitionConfig:
    return cloud_speech.RecognitionConfig(
        auto_decoding_config=cloud_speech.AutoDetectDecodingConfig(),
        language_codes=languages,
        model="chirp_2",
        features=cloud_speech.RecognitionFeatures(
            enable_automatic_punctuation=True,
            enable_word_time_offsets=True,
        ),
    )


def submit(
    config: Config,
    files: list[Path],
    languages: list[str] | None = None,
    on_progress: Callable[[str], None] | None = None,
) -> JobMetadata:
    languages = languages or config.default_languages
    job_id = uuid.uuid4().hex[:12]

    storage_client = storage.Client(project=config.project_id)
    speech_client = _speech_client(config)

    ensure_bucket(storage_client, config.bucket, config.region)

    audio_prefix = f"jobs/{job_id}/audio"
    output_prefix = f"jobs/{job_id}/output"

    file_metas: list[cloud_speech.BatchRecognizeFileMetadata] = []
    uri_to_path: dict[str, str] = {}
    for f in files:
        if on_progress:
            on_progress(f"Uploading {f.name}…")
        uri = upload(storage_client, config.bucket, f, f"{audio_prefix}/{f.name}")
        file_metas.append(cloud_speech.BatchRecognizeFileMetadata(uri=uri))
        uri_to_path[uri] = str(f.resolve())

    request = cloud_speech.BatchRecognizeRequest(
        recognizer=f"projects/{config.project_id}/locations/{config.region}/recognizers/_",
        config=_build_recognition_config(languages),
        files=file_metas,
        recognition_output_config=cloud_speech.RecognitionOutputConfig(
            gcs_output_config=cloud_speech.GcsOutputConfig(
                uri=f"gs://{config.bucket}/{output_prefix}/"
            ),
        ),
    )

    if on_progress:
        on_progress("Submitting job to Speech-to-Text…")
    operation = speech_client.batch_recognize(request=request)

    return JobMetadata(
        job_id=job_id,
        operation_name=operation.operation.name,
        project_id=config.project_id,
        region=config.region,
        bucket=config.bucket,
        languages=languages,
        audio_prefix=audio_prefix,
        output_prefix=output_prefix,
        uri_to_path=uri_to_path,
        submitted_at=JobMetadata.now_ts(),
    )


def fetch_status(config: Config, job: JobMetadata) -> JobStatus:
    client = _speech_client(config)
    raw_op = client.transport.operations_client.get_operation(name=job.operation_name)

    progress: int | None = None
    if raw_op.metadata and raw_op.metadata.value:
        try:
            meta = cloud_speech.OperationMetadata.deserialize(raw_op.metadata.value)
            if meta.progress_percent:
                progress = int(meta.progress_percent)
        except Exception:
            pass

    if not raw_op.done:
        return JobStatus(state="running", progress=progress, error=None)

    which = raw_op.WhichOneof("result")
    if which == "error":
        return JobStatus(state="failed", progress=progress, error=raw_op.error.message)
    return JobStatus(state="done", progress=100, error=None)


def fetch_results(config: Config, job: JobMetadata) -> list[TranscriptResult]:
    client = _speech_client(config)
    raw_op = client.transport.operations_client.get_operation(name=job.operation_name)

    if not raw_op.done:
        raise RuntimeError(f"Job {job.job_id} is still running.")
    if raw_op.WhichOneof("result") == "error":
        raise RuntimeError(f"Job {job.job_id} failed: {raw_op.error.message}")

    response = cloud_speech.BatchRecognizeResponse.deserialize(raw_op.response.value)

    storage_client = storage.Client(project=config.project_id)
    bucket = storage_client.bucket(config.bucket)

    results: list[TranscriptResult] = []
    for input_uri, file_result in response.results.items():
        out_uri = file_result.uri
        if not out_uri:
            continue
        blob_name = out_uri.replace(f"gs://{config.bucket}/", "", 1)
        payload = json.loads(bucket.blob(blob_name).download_as_text())
        text, lang = _extract_text(payload)
        source = Path(job.uri_to_path.get(input_uri, input_uri))
        results.append(
            TranscriptResult(
                source_path=source, text=text, raw=payload, language=lang
            )
        )

    return results


def cleanup_remote(config: Config, job: JobMetadata) -> None:
    storage_client = storage.Client(project=config.project_id)
    delete_prefix(storage_client, config.bucket, f"jobs/{job.job_id}/")


def _extract_text(payload: dict) -> tuple[str, str | None]:
    parts: list[str] = []
    lang: str | None = None
    for r in payload.get("results", []):
        alts = r.get("alternatives") or []
        if not alts:
            continue
        transcript = alts[0].get("transcript", "").strip()
        if transcript:
            parts.append(transcript)
        if lang is None:
            lang = r.get("languageCode")
    return " ".join(parts), lang
