from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from . import jobs as jobs_store
from . import speech
from .config import Config
from .formatters import write_outputs
from .jobs import JobMetadata

app = typer.Typer(
    add_completion=False,
    help="Cloud transcription via Google Speech-to-Text v2 (Chirp 2).",
)
console = Console()


@app.command()
def submit(
    files: list[Path] = typer.Argument(
        ..., exists=True, dir_okay=False, readable=True, help="MP3 files to transcribe."
    ),
    lang: Optional[list[str]] = typer.Option(
        None,
        "--lang",
        "-l",
        help="BCP-47 language codes, repeatable (e.g. -l am-ET -l en-US). "
        "Defaults to DEFAULT_LANGUAGES from .env.",
    ),
):
    """Upload files and start a transcription job. Returns a job ID immediately."""
    config = Config.load()
    languages = list(lang) if lang else config.default_languages

    console.print(
        f"[bold]Project:[/] {config.project_id}  "
        f"[bold]Region:[/] {config.region}  "
        f"[bold]Bucket:[/] {config.bucket}"
    )
    console.print(f"[bold]Languages:[/] {', '.join(languages)}")
    console.print(f"[bold]Files:[/] {len(files)}")

    with Progress(
        SpinnerColumn(),
        TextColumn("{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("Starting…", total=None)

        def on_progress(msg: str) -> None:
            progress.update(task, description=msg)

        job = speech.submit(config, list(files), languages, on_progress)

    jobs_store.save(job)
    console.print(f"\n[green]✓ Job submitted:[/] [bold]{job.job_id}[/]")
    console.print(f"  Check status: [cyan]transcribe status {job.job_id}[/]")
    console.print(f"  Get result:   [cyan]transcribe result {job.job_id}[/]")


@app.command()
def status(job_id: str = typer.Argument(..., help="Job ID returned by `submit`.")):
    """Check the status of a previously-submitted job."""
    config = Config.load()
    try:
        job = jobs_store.load(job_id)
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    st = speech.fetch_status(config, job)

    if st.state in ("done", "failed") and job.state != st.state:
        job.state = st.state
        job.completed_at = JobMetadata.now_ts()
        job.error = st.error
        jobs_store.save(job)

    state_color = {"running": "yellow", "done": "green", "failed": "red", "fetched": "blue"}.get(
        st.state, "white"
    )
    console.print(f"[bold]Job {job.job_id}[/]")
    console.print(f"  state:     [{state_color}]{st.state}[/]")
    if st.progress is not None:
        console.print(f"  progress:  {st.progress}%")
    console.print(f"  files:     {len(job.uri_to_path)}")
    console.print(f"  languages: {', '.join(job.languages)}")
    console.print(f"  submitted: {job.submitted_at}")
    if job.completed_at:
        console.print(f"  completed: {job.completed_at}")
    if st.error:
        console.print(f"  [red]error:[/]    {st.error}")
    if st.state == "done":
        console.print(f"\n  Get transcript: [cyan]transcribe result {job.job_id}[/]")


@app.command()
def result(
    job_id: str = typer.Argument(..., help="Job ID returned by `submit`."),
    out: Path = typer.Option(
        Path("./transcripts"), "--out", "-o", help="Output directory."
    ),
    srt: bool = typer.Option(False, "--srt", help="Also write .srt subtitles."),
    keep_remote: bool = typer.Option(
        False, "--keep-remote", help="Don't delete GCS staging objects after fetch."
    ),
):
    """Download and write the transcripts for a completed job."""
    config = Config.load()
    try:
        job = jobs_store.load(job_id)
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    try:
        results = speech.fetch_results(config, job)
    except RuntimeError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    out.mkdir(parents=True, exist_ok=True)
    for r in results:
        written = write_outputs(r, out, srt=srt)
        lang_tag = f" [{r.language}]" if r.language else ""
        console.print(
            f"[green]OK[/]{lang_tag} {r.source_path.name} -> "
            f"{', '.join(p.name for p in written)}"
        )

    if not keep_remote:
        speech.cleanup_remote(config, job)

    job.state = "fetched"
    if not job.completed_at:
        job.completed_at = JobMetadata.now_ts()
    jobs_store.save(job)

    console.print(f"\n[bold green]Done.[/] {len(results)} file(s) written to {out}/")


@app.command(name="list")
def list_jobs():
    """List all known jobs."""
    all_jobs = jobs_store.list_all()
    if not all_jobs:
        console.print("No jobs.")
        return
    table = Table(show_header=True, header_style="bold")
    table.add_column("Job ID")
    table.add_column("State")
    table.add_column("Files", justify="right")
    table.add_column("Languages")
    table.add_column("Submitted")
    for j in all_jobs:
        state_color = {
            "running": "yellow",
            "done": "green",
            "failed": "red",
            "fetched": "blue",
        }.get(j.state, "white")
        table.add_row(
            j.job_id,
            f"[{state_color}]{j.state}[/]",
            str(len(j.uri_to_path)),
            ",".join(j.languages),
            j.submitted_at,
        )
    console.print(table)


@app.command()
def forget(job_id: str = typer.Argument(..., help="Job ID to remove from local manifest.")):
    """Remove a job from the local manifest (does not affect GCP)."""
    if jobs_store.delete(job_id):
        console.print(f"Forgot {job_id}.")
    else:
        console.print(f"[yellow]No local manifest for {job_id}.[/]")


@app.command()
def doctor():
    """Print resolved config and verify GCP credentials."""
    try:
        config = Config.load()
    except RuntimeError as e:
        console.print(f"[red]Config error:[/] {e}")
        raise typer.Exit(1)

    console.print("[bold]Resolved config[/]")
    console.print(f"  project: {config.project_id}")
    console.print(f"  region:  {config.region}")
    console.print(f"  bucket:  {config.bucket}")
    console.print(f"  langs:   {', '.join(config.default_languages)}")

    try:
        from google.cloud import storage

        client = storage.Client(project=config.project_id)
        list(client.list_buckets(max_results=1))
        console.print("[green]Auth OK[/] — credentials reach GCS.")
    except Exception as e:
        console.print(f"[red]Auth check failed:[/] {e}")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
