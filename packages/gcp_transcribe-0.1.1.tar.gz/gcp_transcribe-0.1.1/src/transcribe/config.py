from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv


@dataclass(frozen=True)
class Config:
    project_id: str
    region: str
    bucket: str
    default_languages: list[str]

    @classmethod
    def load(cls) -> "Config":
        load_dotenv()
        project_id = os.environ.get("GCP_PROJECT_ID")
        if not project_id:
            raise RuntimeError(
                "GCP_PROJECT_ID is not set. Copy .env.example to .env and fill it in."
            )
        region = os.environ.get("GCP_REGION", "us-central1")
        bucket = os.environ.get("GCS_BUCKET", f"{project_id}-transcription")
        langs = os.environ.get("DEFAULT_LANGUAGES", "am-ET").split(",")
        return cls(
            project_id=project_id,
            region=region,
            bucket=bucket,
            default_languages=[l.strip() for l in langs if l.strip()],
        )
