"""Target-side deletions must round-trip as real changes."""

from __future__ import annotations

import os
from pathlib import Path

import tomlkit

from chameleon import cli
from chameleon.io.json import dump_json, load_json
from chameleon.io.yaml import dump_yaml, load_yaml
from chameleon.schema.neutral import Neutral


def _setup_env(monkeypatch, tmp_path: Path) -> dict[str, Path]:
    state = tmp_path / "state"
    config = tmp_path / "config"
    home = tmp_path / "home"
    state.mkdir()
    config.mkdir()
    home.mkdir()
    monkeypatch.setenv("XDG_STATE_HOME", str(state))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(config))
    monkeypatch.setenv("HOME", str(home))
    return {"state": state, "config": config, "home": home}


def _set_mtime_ns(path: Path, ns: int) -> None:
    os.utime(path, ns=(ns, ns))


def test_newer_codex_config_deletion_clears_catalog_tuning(monkeypatch, tmp_path: Path) -> None:
    paths = _setup_env(monkeypatch, tmp_path)
    neutral_file = paths["config"] / "chameleon" / "neutral.yaml"

    assert cli.main(["init"]) == 0

    neutral_file.write_text(
        dump_yaml(
            {
                "schema_version": 1,
                "identity": {
                    "model": {"codex": "gpt-5.5"},
                    "context_window": 600000,
                    "compact_threshold": 500000,
                    "model_catalog_path": "~/.codex/model-catalog-600k.json",
                },
            }
        ),
        encoding="utf-8",
    )
    assert cli.main(["merge", "--on-conflict=prefer-neutral"]) == 0

    codex_config = paths["home"] / ".codex" / "config.toml"
    doc = tomlkit.parse(codex_config.read_text(encoding="utf-8"))
    for key in (
        "model_context_window",
        "model_auto_compact_token_limit",
        "model_catalog_json",
    ):
        doc.pop(key, None)
    codex_config.write_text(tomlkit.dumps(doc), encoding="utf-8")

    neutral_file.write_text(
        dump_yaml(
            {
                "schema_version": 1,
                "identity": {
                    "model": {"codex": "gpt-5.5"},
                    "context_window": None,
                    "compact_threshold": None,
                    "model_catalog_path": None,
                },
            }
        ),
        encoding="utf-8",
    )

    _set_mtime_ns(neutral_file, 1_000_000_000)
    _set_mtime_ns(codex_config, 2_000_000_000)

    assert cli.main(["merge", "--on-conflict=latest"]) == 0

    after_config = codex_config.read_text(encoding="utf-8")
    assert "model_context_window" not in after_config
    assert "model_auto_compact_token_limit" not in after_config
    assert "model_catalog_json" not in after_config

    after_neutral = Neutral.model_validate(load_yaml(neutral_file))
    assert after_neutral.identity.context_window is None
    assert after_neutral.identity.compact_threshold is None
    assert after_neutral.identity.model_catalog_path is None


def test_newer_claude_marketplace_deletion_clears_neutral(monkeypatch, tmp_path: Path) -> None:
    paths = _setup_env(monkeypatch, tmp_path)
    neutral_file = paths["config"] / "chameleon" / "neutral.yaml"

    assert cli.main(["init"]) == 0

    neutral_file.write_text(
        dump_yaml(
            {
                "schema_version": 1,
                "capabilities": {
                    "plugin_marketplaces": {
                        "zircote-lsp": {
                            "source": {
                                "kind": "github",
                                "repo": "zircote/lsp-marketplace",
                            }
                        }
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    assert cli.main(["merge", "--on-conflict=prefer-neutral"]) == 0

    claude_settings = paths["home"] / ".claude" / "settings.json"
    settings_doc = load_json(claude_settings)
    assert isinstance(settings_doc, dict)
    extra_marketplaces = settings_doc.get("extraKnownMarketplaces")
    assert isinstance(extra_marketplaces, dict)
    assert "zircote-lsp" in extra_marketplaces
    extra_marketplaces.pop("zircote-lsp")
    claude_settings.write_text(dump_json(settings_doc), encoding="utf-8")

    codex_config = paths["home"] / ".codex" / "config.toml"
    codex_doc = tomlkit.parse(codex_config.read_text(encoding="utf-8"))
    codex_marketplaces = codex_doc.get("marketplaces")
    assert isinstance(codex_marketplaces, dict)
    zircote_table = codex_marketplaces.get("zircote-lsp")
    assert isinstance(zircote_table, dict)
    zircote_table["last_updated"] = "2026-05-19T00:00:00Z"
    zircote_table["last_revision"] = "0000000000000000000000000000000000000000"
    codex_config.write_text(tomlkit.dumps(codex_doc), encoding="utf-8")

    _set_mtime_ns(neutral_file, 1_000_000_000)
    _set_mtime_ns(codex_config, 2_000_000_000)
    _set_mtime_ns(claude_settings, 3_000_000_000)

    assert cli.main(["merge", "--on-conflict=latest"]) == 0

    after_settings = load_json(claude_settings)
    assert isinstance(after_settings, dict)
    after_extra = after_settings.get("extraKnownMarketplaces") or {}
    assert isinstance(after_extra, dict)
    assert "zircote-lsp" not in after_extra

    after_neutral = Neutral.model_validate(load_yaml(neutral_file))
    assert "zircote-lsp" not in after_neutral.capabilities.plugin_marketplaces

    after_codex = tomlkit.parse(codex_config.read_text(encoding="utf-8"))
    codex_marketplaces = after_codex.get("marketplaces") or {}
    assert "zircote-lsp" not in codex_marketplaces


def test_claude_plugin_deletion_wins_when_codex_file_is_newer(
    monkeypatch,
    tmp_path: Path,
) -> None:
    paths = _setup_env(monkeypatch, tmp_path)
    neutral_file = paths["config"] / "chameleon" / "neutral.yaml"

    assert cli.main(["init"]) == 0

    plugin_key = "typescript-lsp@claude-plugins-official"
    neutral_file.write_text(
        dump_yaml(
            {
                "schema_version": 1,
                "capabilities": {
                    "plugins": {
                        plugin_key: {
                            "enabled": True,
                        }
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    assert cli.main(["merge", "--on-conflict=prefer-neutral"]) == 0

    claude_settings = paths["home"] / ".claude" / "settings.json"
    settings_doc = load_json(claude_settings)
    assert isinstance(settings_doc, dict)
    enabled_plugins = settings_doc.get("enabledPlugins")
    assert isinstance(enabled_plugins, dict)
    assert plugin_key in enabled_plugins
    enabled_plugins.pop(plugin_key)
    claude_settings.write_text(dump_json(settings_doc), encoding="utf-8")

    codex_config = paths["home"] / ".codex" / "config.toml"
    _set_mtime_ns(neutral_file, 1_000_000_000)
    _set_mtime_ns(claude_settings, 2_000_000_000)
    _set_mtime_ns(codex_config, 3_000_000_000)

    assert cli.main(["merge"]) == 0

    after_settings = load_json(claude_settings)
    assert isinstance(after_settings, dict)
    after_plugins = after_settings.get("enabledPlugins") or {}
    assert isinstance(after_plugins, dict)
    assert plugin_key not in after_plugins

    after_neutral = Neutral.model_validate(load_yaml(neutral_file))
    assert plugin_key not in after_neutral.capabilities.plugins

    after_codex = tomlkit.parse(codex_config.read_text(encoding="utf-8"))
    codex_plugins = after_codex.get("plugins") or {}
    assert plugin_key not in codex_plugins
