from __future__ import annotations

from io import StringIO

from rich.console import Console

from chameleon.render.cli_output import (
    Bucket,
    Finding,
    OpResult,
    Preamble,
    PreambleEntry,
    ToolOutput,
    parse,
    render,
)


def _sample_doc() -> ToolOutput:
    return ToolOutput(
        title="Chameleon Merge",
        subtitle="neutral state reconciled across targets",
        preamble=Preamble(
            entries=(
                PreambleEntry("state_root", "/tmp/state/chameleon"),
                PreambleEntry("targets", "[claude, codex]"),
            )
        ),
        result=OpResult(summary="merge: applied across 2 target(s)", status="ok"),
        findings=(
            Finding(
                severity="warn",
                scope="claude/capabilities",
                message="enabledPlugins: 4 unsupported plugin(s)",
                buckets=(
                    Bucket(
                        name="reason: marketplace not declared",
                        items=("bash-lsp", "python-lsp"),
                    ),
                ),
            ),
        ),
        epilogue=("merge_id=11111111-2222-3333-4444-555555555555",),
    )


def test_render_plain_preserves_structure_without_ansi_or_box_drawing() -> None:
    stream = StringIO()
    render(
        _sample_doc(),
        Console(file=stream, force_terminal=False, color_system=None),
        bling_level="plain",
    )

    out = stream.getvalue()
    assert "CHAMELEON MERGE" in out
    assert "Context" in out
    assert "Result" in out
    assert "Findings" in out
    assert "claude/capabilities" in out
    assert "bash-lsp" in out
    assert "\x1b[" not in out
    assert "╭" not in out
    assert "│" not in out


def test_render_auto_falls_back_to_plain_for_non_terminal_console() -> None:
    stream = StringIO()
    render(_sample_doc(), Console(file=stream, force_terminal=False), bling_level="auto")

    out = stream.getvalue()
    assert "CHAMELEON MERGE" in out
    assert "warning:" not in out
    assert "\x1b[" not in out
    assert "╭" not in out


def test_render_max_builds_composed_rich_page() -> None:
    console = Console(record=True, force_terminal=True, color_system="truecolor", width=100)

    render(_sample_doc(), console, bling_level="max")

    out = console.export_text()
    assert "CHAMELEON MERGE" in out
    assert "neutral state reconciled across targets" in out
    assert "claude/capabilities" in out
    assert "bash-lsp" in out
    assert "╭" in out
    assert "│" in out


def test_parse_groups_verbose_result_and_warning_lines() -> None:
    doc = parse(
        [
            "verbose: state_root=/tmp/state/chameleon",
            "verbose: targets=[claude, codex]",
            "merge: applied across 2 target(s)",
            "warning: 2 warning(s) during merge",
            "  claude/capabilities (2)",
            "    - enabledPlugins: 4 unsupported plugin(s)",
            "      reason: marketplace not declared (4)",
            "        zircote-lsp: bash-lsp, python-lsp",
            "verbose: [claude] 2 LossWarning(s)",
            "verbose: merge_id=11111111-2222-3333-4444-555555555555",
        ],
        title="Chameleon Merge",
    )

    assert doc.result is not None
    assert doc.result.summary == "merge: applied across 2 target(s)"
    assert [entry.key for entry in doc.preamble.entries] == ["state_root", "targets"]
    assert len(doc.findings) == 1
    finding = doc.findings[0]
    assert finding.scope == "claude/capabilities"
    assert finding.message == "enabledPlugins: 4 unsupported plugin(s)"
    assert finding.buckets[0].name == "reason: marketplace not declared (4)"
    assert finding.buckets[0].items == ("zircote-lsp: bash-lsp, python-lsp",)
    assert "merge_id=11111111-2222-3333-4444-555555555555" in doc.epilogue
