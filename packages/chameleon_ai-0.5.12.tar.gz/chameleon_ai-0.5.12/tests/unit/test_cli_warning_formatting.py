"""Human-readable CLI warning rendering."""

from __future__ import annotations

from chameleon._types import FieldPath
from chameleon.cli import _format_warning_lines
from chameleon.codecs._protocol import LossWarning
from chameleon.schema._constants import BUILTIN_CLAUDE, BUILTIN_CODEX, Domains


def test_format_warning_lines_groups_by_target_and_domain() -> None:
    warnings = [
        LossWarning(
            target=BUILTIN_CLAUDE,
            domain=Domains.IDENTITY,
            message="identity.context_window is a Codex-only tuning knob",
            field_path=FieldPath(segments=("identity", "context_window")),
        ),
        LossWarning(
            target=BUILTIN_CODEX,
            domain=Domains.INTERFACE,
            message="interface.voice has no Codex equivalent; dropping voice on encode to Codex",
            field_path=FieldPath(segments=("interface", "voice")),
        ),
    ]

    lines = _format_warning_lines(warnings)

    assert lines[0] == "warning: 2 warning(s) during merge"
    assert "  claude/identity (1)" in lines
    assert "  codex/interface (1)" in lines
    assert any("identity.context_window is a Codex-only tuning knob" in line for line in lines)
    assert any("interface.voice has no Codex equivalent" in line for line in lines)


def test_format_warning_lines_summarizes_enabled_plugin_drop_lists() -> None:
    message = (
        "dropping enabledPlugins entries from source because they are not supported "
        "in this environment: "
        "'bash-lsp@zircote-lsp' (marketplace='zircote-lsp', reason='marketplace not declared'), "
        "'cpp-lsp@zircote-lsp' (marketplace='zircote-lsp', reason='marketplace not declared'), "
        "'json-lsp@zircote-lsp' (marketplace='zircote-lsp', reason='marketplace not declared'), "
        "'context7@openai-curated' (marketplace='openai-curated', "
        "reason='marketplace not declared'), "
        "'ha-config-ha-mcp@ha-agent-marketplace' (marketplace='ha-agent-marketplace', "
        "reason='not cached')"
    )
    warnings = [
        LossWarning(
            target=BUILTIN_CLAUDE,
            domain=Domains.CAPABILITIES,
            message=message,
            field_path=FieldPath(segments=("enabledPlugins",)),
        )
    ]

    lines = _format_warning_lines(warnings, plugin_sample_limit=2)
    rendered = "\n".join(lines)

    assert "enabledPlugins: 5 unsupported plugin(s)" in rendered
    assert "reason: marketplace not declared (4)" in rendered
    assert "openai-curated: context7" in rendered
    assert "zircote-lsp: bash-lsp, cpp-lsp (+1 more)" in rendered
    assert "reason: not cached (1)" in rendered
    assert "ha-agent-marketplace: ha-config-ha-mcp" in rendered
    assert "'bash-lsp@zircote-lsp'" not in rendered


def test_format_warning_lines_keeps_passthrough_action_readable() -> None:
    warnings = [
        LossWarning(
            target=BUILTIN_CLAUDE,
            domain=Domains.AUTHORIZATION,
            message=(
                "could not disassemble authorization: 1 validation error for "
                "ClaudeAuthorizationSection permissions Input should be a valid dictionary; "
                "routing to pass-through"
            ),
        )
    ]

    rendered = "\n".join(_format_warning_lines(warnings, width=72))

    assert "could not disassemble authorization; routing to pass-through" in rendered
    assert "details: 1 validation error for ClaudeAuthorizationSection" in rendered
