"""Composed Rich renderer for static CLI emissions.

The dataclasses in this module intentionally describe generic CLI output:
context, an operation result, grouped findings, and an epilogue. Chameleon
builds these documents from merge/status data, but the renderer does not need
to know about any specific tool domain.
"""

from __future__ import annotations

import colorsys
import re
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from typing import ClassVar, Literal

from rich import box
from rich.align import Align
from rich.columns import Columns
from rich.console import Console, Group, RenderableType
from rich.highlighter import RegexHighlighter
from rich.padding import Padding
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.theme import Theme
from rich.tree import Tree

BlingLevel = Literal["auto", "max", "medium", "plain"]
ResolvedBlingLevel = Literal["max", "medium", "plain"]
Severity = Literal["ok", "info", "warn", "error"]
Status = Literal["ok", "changed", "warn", "error", "info"]
STYLE_OK = "bold #42d392"
STYLE_INFO = "bold #72a7ff"
STYLE_WARN = "bold #f6c177"
STYLE_ERROR = "bold #ff5c7a"
STYLE_PRIMARY = "bold #f6c177"
STYLE_SECONDARY = "#7dcfff"
STYLE_SCOPE = "bold #c4a7e7"
STYLE_MUTED = "dim"


@dataclass(frozen=True)
class PreambleEntry:
    key: str
    value: str
    note: str | None = None


@dataclass(frozen=True)
class Preamble:
    entries: tuple[PreambleEntry, ...] = ()


@dataclass(frozen=True)
class OpResult:
    summary: str
    status: Status = "info"
    detail: str | None = None


@dataclass(frozen=True)
class Bucket:
    name: str
    items: tuple[str, ...] = ()


@dataclass(frozen=True)
class Finding:
    severity: Severity
    scope: str
    message: str
    details: tuple[str, ...] = ()
    buckets: tuple[Bucket, ...] = ()


@dataclass(frozen=True)
class ToolOutput:
    title: str
    subtitle: str | None = None
    preamble: Preamble = Preamble()
    result: OpResult | None = None
    findings: tuple[Finding, ...] = ()
    epilogue: tuple[str, ...] = ()


class LogHighlighter(RegexHighlighter):
    """Highlight structured CLI atoms inside otherwise free-form messages."""

    base_style = "log."
    highlights: ClassVar[list[str]] = [
        r"(?P<uuid>\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
        r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b)",
        r"(?P<path>(?<![A-Za-z0-9_-])(?:~|/)[^\s,;:)]+)",
        r"(?P<dotted>\b[A-Za-z_][\w-]*(?:\.[A-Za-z_][\w-]*)+\b)",
        r"(?P<count>\b\d+\s+(?:target\(s\)|warning\(s\)|plugin\(s\)|"
        r"LossWarning\(s\)|notice\(s\)|transaction\(s\))\b)",
        r"(?P<duration>\b\d+(?:\.\d+)?(?:ms|s|m)\b)",
    ]


@dataclass
class _ParseState:
    preamble: list[PreambleEntry]
    epilogue: list[str]
    findings: list[Finding]
    result: OpResult | None = None
    current_scope: str | None = None
    current_message: str | None = None
    current_details: list[str] | None = None
    current_buckets: list[tuple[str, list[str]]] | None = None

    @classmethod
    def create(cls) -> _ParseState:
        return cls(preamble=[], epilogue=[], findings=[], current_details=[], current_buckets=[])

    def flush_finding(self) -> None:
        if self.current_scope is None:
            return
        details = self.current_details or []
        buckets = self.current_buckets or []
        self.findings.append(
            Finding(
                severity="warn",
                scope=self.current_scope,
                message=self.current_message or "warning",
                details=tuple(details),
                buckets=tuple(Bucket(name, tuple(items)) for name, items in buckets),
            )
        )
        self.current_scope = None
        self.current_message = None
        self.current_details = []
        self.current_buckets = []

    def start_finding(self, scope: str) -> None:
        self.flush_finding()
        self.current_scope = scope

    def add_message(self, message: str) -> None:
        if self.current_message is None:
            self.current_message = message
            return
        self.add_detail(message)

    def add_detail(self, detail: str) -> None:
        if self.current_details is None:
            self.current_details = []
        self.current_details.append(detail)

    def add_bucket(self, name: str) -> None:
        if self.current_buckets is None:
            self.current_buckets = []
        self.current_buckets.append((name, []))

    def add_bucket_item(self, item: str) -> None:
        if not self.current_buckets:
            self.add_detail(item)
            return
        self.current_buckets[-1][1].append(item)


OUTPUT_THEME = Theme(
    {
        "semantic.ok": "bold #42d392",
        "semantic.info": "bold #72a7ff",
        "semantic.warn": "bold #f6c177",
        "semantic.error": "bold #ff5c7a",
        "ornament.primary": "bold #f6c177",
        "ornament.secondary": "#7dcfff",
        "ornament.dim": "#6c7086",
        "section": "bold #f6c177",
        "scope": "bold #c4a7e7",
        "muted": "dim",
        "log.uuid": "bold #c4a7e7",
        "log.path": "#7dcfff",
        "log.dotted": "bold #f6c177",
        "log.count": "bold #42d392",
        "log.duration": "bold #72a7ff",
    }
)


def hsv_rgb(h: float, s: float = 1.0, v: float = 1.0) -> tuple[int, int, int]:
    """Convert HSV values to integer RGB components."""
    r, g, b = colorsys.hsv_to_rgb(h % 1.0, max(0.0, min(s, 1.0)), max(0.0, min(v, 1.0)))
    return round(r * 255), round(g * 255), round(b * 255)


def generated_palette(
    count: int = 7,
    *,
    phase: float = 0.08,
    saturation: float = 0.72,
    value: float = 0.95,
) -> tuple[str, ...]:
    """Generate a quantized ornamental palette as Rich hex color strings."""
    steps = max(count, 1)
    return tuple(
        f"#{r:02x}{g:02x}{b:02x}"
        for r, g, b in (hsv_rgb(phase + (i / steps), saturation, value) for i in range(steps))
    )


def gradient_text(
    value: str,
    *,
    saturation: float = 0.74,
    brightness: float = 0.96,
    phase: float = 0.08,
    frequency: float = 0.72,
    bold: bool = True,
) -> Text:
    """Return text with a generated per-character HSV gradient."""
    text = Text()
    n = max(len(value), 1)
    weight = "bold " if bold else ""
    for i, ch in enumerate(value):
        h = phase + (i / n) * frequency
        r, g, b = hsv_rgb(h, saturation, brightness)
        text.append(ch, style=f"{weight}#{r:02x}{g:02x}{b:02x}")
    return text


def palette_text(value: str, palette: Sequence[str], *, bold: bool = True) -> Text:
    """Return text colored by cycling through a fixed generated palette."""
    text = Text()
    weight = "bold " if bold else ""
    colors = tuple(palette) or generated_palette(1)
    for i, ch in enumerate(value):
        text.append(ch, style=f"{weight}{colors[i % len(colors)]}")
    return text


def _highlight_log_atoms(text: Text) -> None:
    text.highlight_regex(
        r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
        r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b",
        style=STYLE_SCOPE,
    )
    text.highlight_regex(r"(?<![A-Za-z0-9_-])(?:~|/)[^\s,;:)]+", style=STYLE_SECONDARY)
    text.highlight_regex(r"\b[A-Za-z_][\w-]*(?:\.[A-Za-z_][\w-]*)+\b", style=STYLE_WARN)
    text.highlight_regex(
        r"\b\d+\s+(?:target\(s\)|warning\(s\)|plugin\(s\)|LossWarning\(s\)|"
        r"notice\(s\)|transaction\(s\))\b",
        style=STYLE_OK,
    )
    text.highlight_regex(r"\b\d+(?:\.\d+)?(?:ms|s|m)\b", style=STYLE_INFO)


def parse(lines: Iterable[str], *, title: str = "Tool Output") -> ToolOutput:
    """Best-effort tokenizer for legacy line-oriented CLI output."""
    state = _ParseState.create()
    for raw_line in lines:
        _parse_line(state, raw_line.rstrip("\n"))
    state.flush_finding()

    return ToolOutput(
        title=title,
        preamble=Preamble(tuple(state.preamble)),
        result=state.result,
        findings=tuple(state.findings),
        epilogue=tuple(state.epilogue),
    )


def _parse_line(state: _ParseState, line: str) -> None:
    if not line or line.startswith("warning: "):
        return
    if line.startswith("verbose: "):
        _parse_verbose_line(state, line.removeprefix("verbose: "))
    elif line.startswith(("merge: ", "init: ", "status: ", "validate: ")):
        state.result = OpResult(summary=line, status=_status_from_summary(line))
    elif scope_match := re.match(r"^\s{2}(?P<scope>\S+/\S+)(?:\s+\(\d+\))?$", line):
        state.start_finding(scope_match.group("scope"))
    elif line.startswith("    - "):
        message = line[6:]
        state.add_message(message)
        if "routing to pass-through" in message:
            state.add_detail("routing to pass-through")
    elif line.startswith("      reason: "):
        state.add_bucket(line.strip())
    elif line.startswith("        "):
        state.add_bucket_item(line.strip())
    elif state.current_scope is not None:
        state.add_detail(line.strip())


def _parse_verbose_line(state: _ParseState, payload: str) -> None:
    if "=" in payload and not payload.startswith("merge_id="):
        key, value = payload.split("=", 1)
        state.preamble.append(PreambleEntry(key, value))
        return
    state.epilogue.append(payload)


def render(
    doc: ToolOutput,
    console: Console | None = None,
    *,
    bling_level: BlingLevel = "auto",
) -> None:
    """Render a structured CLI document at the requested degradation level."""
    out = (
        console
        if console is not None
        else Console(theme=OUTPUT_THEME, highlighter=LogHighlighter())
    )
    level = _resolve_bling_level(out, bling_level)
    if level == "plain":
        _render_plain(doc, out)
    elif level == "medium":
        _render_medium(doc, out)
    else:
        _render_max(doc, out)


def _resolve_bling_level(console: Console, bling_level: BlingLevel) -> ResolvedBlingLevel:
    if bling_level != "auto":
        return bling_level
    if not console.is_terminal:
        return "plain"
    if console.color_system != "truecolor":
        return "medium"
    return "max"


def _render_plain(doc: ToolOutput, console: Console) -> None:
    write = console.file.write
    write(f"{doc.title.upper()}\n")
    if doc.subtitle:
        write(f"{doc.subtitle}\n")
    if doc.preamble.entries:
        write("\nContext\n")
        for entry in doc.preamble.entries:
            suffix = f" ({entry.note})" if entry.note else ""
            write(f"  {entry.key}: {entry.value}{suffix}\n")
    if doc.result is not None:
        write("\nResult\n")
        write(f"  {doc.result.summary}\n")
        if doc.result.detail:
            write(f"  {doc.result.detail}\n")
    if doc.findings:
        write("\nFindings\n")
        for finding in doc.findings:
            write(f"  [{finding.severity}] {finding.scope}: {finding.message}\n")
            for detail in finding.details:
                write(f"    - {detail}\n")
            for bucket in finding.buckets:
                write(f"    {bucket.name}\n")
                for item in bucket.items:
                    write(f"      - {item}\n")
    if doc.epilogue:
        write("\nEpilogue\n")
        for line in doc.epilogue:
            write(f"  {line}\n")


def _render_medium(doc: ToolOutput, console: Console) -> None:
    renderables: list[RenderableType] = [
        Panel(
            _header_text(doc, gradient=False),
            title="chameleon",
            border_style=STYLE_PRIMARY,
            box=box.ROUNDED,
            padding=(1, 2),
        )
    ]
    body = _medium_body(doc)
    if body is not None:
        renderables.append(Padding(body, (1, 0, 0, 0)))
    console.print(Group(*renderables))


def _render_max(doc: ToolOutput, console: Console) -> None:
    palette = generated_palette(9)
    header = Group(
        Align.center(palette_text("◆◇◆", palette)),
        Align.center(_header_text(doc, gradient=True)),
        Align.center(palette_text("▔" * min(max(len(doc.title), 12), 48), palette, bold=False)),
    )
    sections: list[RenderableType] = [
        Panel(
            header,
            title=gradient_text("CHAMELEON OUTPUT", frequency=0.42),
            subtitle=palette_text("structured merge telemetry", palette),
            border_style=palette[1],
            box=box.ROUNDED,
            padding=(1, 3),
        )
    ]
    body = _max_body(doc, palette)
    if body is not None:
        sections.append(Padding(body, (1, 0, 0, 0)))
    console.print(Group(*sections))


def _header_text(doc: ToolOutput, *, gradient: bool) -> Text:
    title = doc.title.upper()
    text = gradient_text(title, frequency=0.36) if gradient else Text(title, style=STYLE_PRIMARY)
    if doc.subtitle:
        text.append("\n")
        text.append(doc.subtitle, style=STYLE_SECONDARY)
    return text


def _medium_body(doc: ToolOutput) -> Group | None:
    sections = _body_sections(doc, palette=generated_palette(5), max_mode=False)
    return Group(*sections) if sections else None


def _max_body(doc: ToolOutput, palette: Sequence[str]) -> Group | None:
    sections = _body_sections(doc, palette=palette, max_mode=True)
    return Group(*sections) if sections else None


def _body_sections(
    doc: ToolOutput, *, palette: Sequence[str], max_mode: bool
) -> list[RenderableType]:
    sections: list[RenderableType] = []
    summary_cards: list[RenderableType] = []
    if doc.preamble.entries:
        summary_cards.append(_context_panel(doc.preamble, palette=palette, max_mode=max_mode))
    if doc.result is not None:
        summary_cards.append(_result_panel(doc.result, palette=palette, max_mode=max_mode))
    if summary_cards:
        sections.append(Columns(summary_cards, equal=True, expand=True))
    if doc.findings:
        sections.append(_findings_panel(doc.findings, palette=palette, max_mode=max_mode))
    if doc.epilogue:
        sections.append(_epilogue_panel(doc.epilogue, palette=palette, max_mode=max_mode))
    return sections


def _context_panel(preamble: Preamble, *, palette: Sequence[str], max_mode: bool) -> Panel:
    grid = Table.grid(padding=(0, 2))
    grid.add_column(justify="right", style=STYLE_MUTED, no_wrap=True)
    grid.add_column(ratio=1)
    for entry in preamble.entries:
        value = Text(entry.value)
        _highlight_log_atoms(value)
        if entry.note:
            value.append(f" ({entry.note})", style=STYLE_MUTED)
        grid.add_row(entry.key, value)
    return Panel(
        grid,
        title=_section_title("Context", palette, max_mode=max_mode),
        border_style=palette[2 % len(palette)],
        box=box.ROUNDED,
        padding=(1, 2),
    )


def _result_panel(result: OpResult, *, palette: Sequence[str], max_mode: bool) -> Panel:
    style = _semantic_style(result.status)
    text = Text()
    text.append(_status_glyph(result.status), style=style)
    text.append(" ")
    text.append(result.summary, style=style)
    _highlight_log_atoms(text)
    if result.detail:
        text.append("\n")
        text.append(result.detail, style=STYLE_MUTED)
    return Panel(
        text,
        title=_section_title("Result", palette, max_mode=max_mode),
        border_style=style,
        box=box.ROUNDED,
        padding=(1, 2),
    )


def _findings_panel(
    findings: Sequence[Finding],
    *,
    palette: Sequence[str],
    max_mode: bool,
) -> Panel:
    root = Tree(_section_title("Findings", palette, max_mode=max_mode), guide_style=palette[3])
    for finding in findings:
        node_text = Text()
        node_text.append(_severity_glyph(finding.severity), style=_severity_style(finding.severity))
        node_text.append(" ")
        node_text.append(finding.scope, style=STYLE_SCOPE)
        node_text.append(" ")
        node_text.append(finding.message, style=_severity_style(finding.severity))
        _highlight_log_atoms(node_text)
        branch = root.add(node_text)
        for detail in finding.details:
            detail_text = Text(detail)
            _highlight_log_atoms(detail_text)
            branch.add(detail_text)
        for bucket in finding.buckets:
            bucket_branch = branch.add(Text(bucket.name, style=STYLE_PRIMARY))
            for item in bucket.items:
                item_text = Text(item)
                _highlight_log_atoms(item_text)
                bucket_branch.add(item_text)
    return Panel(
        root,
        border_style=palette[4 % len(palette)],
        box=box.ROUNDED,
        padding=(1, 2),
    )


def _epilogue_panel(
    epilogue: Sequence[str],
    *,
    palette: Sequence[str],
    max_mode: bool,
) -> Panel:
    text = Text()
    for i, line in enumerate(epilogue):
        if i:
            text.append("\n")
        text.append(line)
    _highlight_log_atoms(text)
    return Panel(
        text,
        title=_section_title("Epilogue", palette, max_mode=max_mode),
        border_style=palette[5 % len(palette)],
        box=box.ROUNDED,
        padding=(1, 2),
    )


def _section_title(title: str, palette: Sequence[str], *, max_mode: bool) -> Text:
    if not max_mode:
        return Text(title, style=STYLE_PRIMARY)
    return palette_text(f"✦ {title} ✦", palette)


def _status_from_summary(summary: str) -> Status:
    lowered = summary.lower()
    if "error" in lowered or "failed" in lowered:
        return "error"
    if "warning" in lowered or "conflict" in lowered:
        return "warn"
    if "applied" in lowered or summary.startswith("ok"):
        return "ok"
    if "would" in lowered or "dry-run" in lowered:
        return "changed"
    return "info"


def _semantic_style(status: Status) -> str:
    return {
        "ok": STYLE_OK,
        "changed": STYLE_INFO,
        "warn": STYLE_WARN,
        "error": STYLE_ERROR,
        "info": STYLE_INFO,
    }[status]


def _severity_style(severity: Severity) -> str:
    return {
        "ok": STYLE_OK,
        "info": STYLE_INFO,
        "warn": STYLE_WARN,
        "error": STYLE_ERROR,
    }[severity]


def _status_glyph(status: Status) -> str:
    return {
        "ok": "◆",
        "changed": "◇",
        "warn": "▲",
        "error": "■",
        "info": "●",
    }[status]


def _severity_glyph(severity: Severity) -> str:
    return {
        "ok": "◆",
        "info": "●",
        "warn": "▲",
        "error": "■",
    }[severity]


def _demo_doc() -> ToolOutput:
    return ToolOutput(
        title="Prismatic Validator",
        subtitle="synthetic configuration round-trip",
        preamble=Preamble(
            (
                PreambleEntry("state_root", "/var/tmp/example/state"),
                PreambleEntry("inputs", "neutral.yaml, target-a.toml, target-b.json"),
                PreambleEntry("profile", "default"),
            )
        ),
        result=OpResult("validated 3 target(s) in 42ms", status="ok"),
        findings=(
            Finding(
                "warn",
                "target-a/capabilities",
                "4 unsupported extension(s)",
                buckets=(
                    Bucket("reason: provider not declared", ("syntax-lens", "diff-helper")),
                    Bucket("reason: local cache missing", ("schema-scout", "review-kit")),
                ),
            ),
            Finding(
                "info",
                "target-b/lifecycle",
                "hooks preserved through pass-through",
                details=("round_trip.lifecycle.preToolUse kept stable",),
            ),
        ),
        epilogue=("run_id=11111111-2222-3333-4444-555555555555",),
    )


def _demo() -> None:
    for level in ("max", "medium", "plain"):
        console = Console(theme=OUTPUT_THEME, highlighter=LogHighlighter(), force_terminal=True)
        render(_demo_doc(), console, bling_level=level)


if __name__ == "__main__":
    _demo()
