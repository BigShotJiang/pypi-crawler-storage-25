"""Terminal renderers for Chameleon's operator-facing CLI output."""
