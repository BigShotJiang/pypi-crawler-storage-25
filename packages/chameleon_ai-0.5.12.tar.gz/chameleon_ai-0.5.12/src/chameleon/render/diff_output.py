"""Rich renderer for human-readable unified diffs."""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Literal

from rich import box
from rich.align import Align
from rich.console import Console, Group, RenderableType
from rich.padding import Padding
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from chameleon.render.cli_output import (
    STYLE_ERROR,
    STYLE_INFO,
    STYLE_MUTED,
    STYLE_OK,
    STYLE_PRIMARY,
    STYLE_SECONDARY,
    BlingLevel,
    ResolvedBlingLevel,
    generated_palette,
    gradient_text,
    palette_text,
)

DiffLineKind = Literal["hunk", "add", "remove", "context", "meta"]


@dataclass(frozen=True)
class DiffLine:
    kind: DiffLineKind
    text: str
    old_lineno: int | None = None
    new_lineno: int | None = None


@dataclass(frozen=True)
class DiffFile:
    old_label: str
    new_label: str
    path: str
    lines: tuple[DiffLine, ...]
    additions: int
    removals: int


@dataclass(frozen=True)
class DiffOutput:
    title: str
    subtitle: str
    target: str
    raw_diff: str
    files: tuple[DiffFile, ...]
    statuses: tuple[str, ...] = ()


@dataclass
class _MutableFile:
    old_label: str
    new_label: str
    path: str
    lines: list[DiffLine]
    additions: int = 0
    removals: int = 0

    def freeze(self) -> DiffFile:
        return DiffFile(
            old_label=self.old_label,
            new_label=self.new_label,
            path=self.path,
            lines=tuple(self.lines),
            additions=self.additions,
            removals=self.removals,
        )


_HUNK_RE = re.compile(
    r"^@@ -(?P<old_start>\d+)(?:,\d+)? \+(?P<new_start>\d+)(?:,\d+)? @@(?P<trailer>.*)$"
)
_PATH_RE = re.compile(r"^[ab]/(?P<path>.*?)(?:\s+\(.*\))?$")


def parse_unified_diff(
    raw_diff: str,
    *,
    target: str,
    title: str = "Chameleon Diff",
    subtitle: str = "target drift inspection",
    statuses: Sequence[str] = (),
) -> DiffOutput:
    """Parse unified diff text into a structure suitable for terminal rendering."""
    files: list[DiffFile] = []
    current: _MutableFile | None = None
    old_label: str | None = None
    old_lineno: int | None = None
    new_lineno: int | None = None

    for line in raw_diff.splitlines():
        if line.startswith("--- "):
            if current is not None:
                files.append(current.freeze())
            old_label = line[4:]
            current = None
            old_lineno = None
            new_lineno = None
            continue
        if line.startswith("+++ ") and old_label is not None:
            new_label = line[4:]
            current = _MutableFile(
                old_label=old_label,
                new_label=new_label,
                path=_display_path(old_label, new_label),
                lines=[],
            )
            old_label = None
            continue
        if current is None:
            continue

        if hunk_match := _HUNK_RE.match(line):
            old_lineno = int(hunk_match.group("old_start"))
            new_lineno = int(hunk_match.group("new_start"))
            current.lines.append(DiffLine("hunk", line))
            continue
        if line.startswith("+") and not line.startswith("+++"):
            current.lines.append(DiffLine("add", line[1:], new_lineno=new_lineno))
            current.additions += 1
            new_lineno = None if new_lineno is None else new_lineno + 1
            continue
        if line.startswith("-") and not line.startswith("---"):
            current.lines.append(DiffLine("remove", line[1:], old_lineno=old_lineno))
            current.removals += 1
            old_lineno = None if old_lineno is None else old_lineno + 1
            continue
        if line.startswith(" "):
            current.lines.append(
                DiffLine("context", line[1:], old_lineno=old_lineno, new_lineno=new_lineno)
            )
            old_lineno = None if old_lineno is None else old_lineno + 1
            new_lineno = None if new_lineno is None else new_lineno + 1
            continue
        current.lines.append(DiffLine("meta", line))

    if current is not None:
        files.append(current.freeze())

    return DiffOutput(
        title=title,
        subtitle=subtitle,
        target=target,
        raw_diff=raw_diff,
        files=tuple(files),
        statuses=tuple(statuses),
    )


def render(
    doc: DiffOutput,
    console: Console | None = None,
    *,
    bling_level: BlingLevel = "auto",
) -> None:
    """Render a diff document, preserving raw unified diff in plain mode."""
    out = console if console is not None else Console()
    level = _resolve_bling_level(out, bling_level)
    if level == "plain":
        out.file.write(doc.raw_diff)
    elif level == "medium":
        _render_medium(doc, out)
    else:
        _render_max(doc, out)


def _resolve_bling_level(console: Console, bling_level: BlingLevel) -> ResolvedBlingLevel:
    if bling_level != "auto":
        return bling_level
    if not console.is_terminal:
        return "plain"
    if console.color_system != "truecolor":
        return "medium"
    return "max"


def _render_medium(doc: DiffOutput, console: Console) -> None:
    palette = generated_palette(5)
    console.print(
        Group(
            _header_panel(doc, palette=palette, max_mode=False),
            *_file_panels(doc, palette=palette, max_mode=False),
        )
    )


def _render_max(doc: DiffOutput, console: Console) -> None:
    palette = generated_palette(9)
    console.print(
        Group(
            _header_panel(doc, palette=palette, max_mode=True),
            Padding(Group(*_file_panels(doc, palette=palette, max_mode=True)), (1, 0, 0, 0)),
        )
    )


def _header_panel(doc: DiffOutput, *, palette: Sequence[str], max_mode: bool) -> Panel:
    additions = sum(file.additions for file in doc.files)
    removals = sum(file.removals for file in doc.files)
    if max_mode:
        title = gradient_text(doc.title.upper(), frequency=0.36)
        ornament = Align.center(palette_text("◆◇◆", palette))
    else:
        title = Text(doc.title.upper(), style=STYLE_PRIMARY)
        ornament = Text()

    summary = Table.grid(padding=(0, 2))
    summary.add_column(justify="right", style=STYLE_MUTED, no_wrap=True)
    summary.add_column(ratio=1)
    summary.add_row("target", Text(doc.target, style=STYLE_SECONDARY))
    summary.add_row("files", Text(str(len(doc.files)), style=STYLE_INFO))
    summary.add_row("added", Text(f"+{additions}", style=STYLE_OK))
    summary.add_row("removed", Text(f"-{removals}", style=STYLE_ERROR))
    for status in doc.statuses:
        summary.add_row("status", Text(status, style=STYLE_PRIMARY))

    body = Group(
        ornament,
        Align.center(title),
        Align.center(Text(doc.subtitle, style=STYLE_SECONDARY)),
        Padding(summary, (1, 0, 0, 0)),
    )
    return Panel(
        body,
        title=palette_text("DIFF TELEMETRY", palette) if max_mode else "diff telemetry",
        border_style=palette[1 % len(palette)],
        box=box.ROUNDED,
        padding=(1, 3),
    )


def _file_panels(
    doc: DiffOutput, *, palette: Sequence[str], max_mode: bool
) -> list[RenderableType]:
    return [
        _file_panel(file, index=index, palette=palette, max_mode=max_mode)
        for index, file in enumerate(doc.files)
    ]


def _file_panel(
    file: DiffFile,
    *,
    index: int,
    palette: Sequence[str],
    max_mode: bool,
) -> Panel:
    metadata = Table.grid(padding=(0, 2))
    metadata.add_column(justify="right", style=STYLE_MUTED, no_wrap=True)
    metadata.add_column(ratio=1)
    metadata.add_row("from", Text(file.old_label, style=STYLE_ERROR))
    metadata.add_row("to", Text(file.new_label, style=STYLE_OK))
    metadata.add_row("delta", _delta_text(file))

    body = Group(metadata, Padding(_line_table(file), (1, 0, 0, 0)))
    title = (
        palette_text(f"✦ {file.path} ✦", palette)
        if max_mode
        else Text(file.path, style=STYLE_PRIMARY)
    )
    return Panel(
        body,
        title=title,
        border_style=palette[(index + 3) % len(palette)],
        box=box.ROUNDED,
        padding=(1, 1),
    )


def _line_table(file: DiffFile) -> Table:
    table = Table.grid(padding=(0, 1))
    table.add_column("old", justify="right", style=STYLE_MUTED, no_wrap=True)
    table.add_column("new", justify="right", style=STYLE_MUTED, no_wrap=True)
    table.add_column("mark", justify="center", no_wrap=True)
    table.add_column("line", ratio=1, overflow="fold")
    for line in file.lines:
        old_no = "" if line.old_lineno is None else str(line.old_lineno)
        new_no = "" if line.new_lineno is None else str(line.new_lineno)
        mark, style = _line_marker(line.kind)
        content = Text(line.text, style=style)
        table.add_row(old_no, new_no, Text(mark, style=style), content)
    return table


def _line_marker(kind: DiffLineKind) -> tuple[str, str]:
    return {
        "hunk": ("◇", STYLE_INFO),
        "add": ("+", STYLE_OK),
        "remove": ("-", STYLE_ERROR),
        "context": ("│", STYLE_MUTED),
        "meta": ("·", STYLE_PRIMARY),
    }[kind]


def _delta_text(file: DiffFile) -> Text:
    text = Text()
    text.append(f"+{file.additions}", style=STYLE_OK)
    text.append(" / ", style=STYLE_MUTED)
    text.append(f"-{file.removals}", style=STYLE_ERROR)
    return text


def _display_path(old_label: str, new_label: str) -> str:
    for label in (new_label, old_label):
        if match := _PATH_RE.match(label):
            return match.group("path")
    return new_label or old_label
