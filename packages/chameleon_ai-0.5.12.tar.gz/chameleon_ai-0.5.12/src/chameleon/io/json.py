"""Stable-ordered JSON I/O.

Python's stdlib json preserves dict insertion order on dump and
load, which is what we want — the live target file's `git diff`
should be informative, not a noisy reordering.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class JsonLoadError(ValueError):
    """Raised when a JSON document cannot be parsed safely."""


def _source_text_and_label(source: str | bytes | Path) -> tuple[str, str]:
    if isinstance(source, Path):
        return source.read_text(encoding="utf-8"), str(source)
    if isinstance(source, bytes):
        try:
            return source.decode("utf-8"), "<bytes>"
        except UnicodeDecodeError as exc:
            raise JsonLoadError(f"invalid UTF-8 JSON in <bytes>: {exc}") from exc
    return source, "<string>"


def _strip_comments(text: str) -> str:
    """Remove JSONC-style comments without touching string literals."""
    out: list[str] = []
    in_string = False
    escape = False
    i = 0
    while i < len(text):
        char = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if in_string:
            out.append(char)
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == '"':
                in_string = False
            i += 1
            continue
        if char == '"':
            in_string = True
            out.append(char)
            i += 1
            continue
        if char == "/" and nxt == "/":
            i += 2
            while i < len(text) and text[i] not in "\r\n":
                i += 1
            continue
        if char == "/" and nxt == "*":
            i += 2
            while i + 1 < len(text) and not (text[i] == "*" and text[i + 1] == "/"):
                if text[i] in "\r\n":
                    out.append(text[i])
                i += 1
            i += 2 if i + 1 < len(text) else 0
            continue
        out.append(char)
        i += 1
    return "".join(out)


def _strip_trailing_commas(text: str) -> str:
    """Remove commas before ``]`` or ``}`` outside string literals."""
    out: list[str] = []
    in_string = False
    escape = False
    i = 0
    while i < len(text):
        char = text[i]
        if in_string:
            out.append(char)
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == '"':
                in_string = False
            i += 1
            continue
        if char == '"':
            in_string = True
            out.append(char)
            i += 1
            continue
        if char == ",":
            j = i + 1
            while j < len(text) and text[j].isspace():
                j += 1
            if j < len(text) and text[j] in "]}":
                i += 1
                continue
        out.append(char)
        i += 1
    return "".join(out)


def _jsonc_to_json(text: str) -> str:
    return _strip_trailing_commas(_strip_comments(text))


def load_json(source: str | bytes | Path) -> Any:
    """Parse JSON from a string, bytes, or file path.

    Preserves insertion order through stdlib json which maintains
    dict insertion order since Python 3.7.
    """
    text, label = _source_text_and_label(source)
    try:
        return json.loads(text)
    except json.JSONDecodeError as strict_error:
        try:
            return json.loads(_jsonc_to_json(text))
        except json.JSONDecodeError as relaxed_error:
            detail = str(relaxed_error).strip() or str(strict_error).strip()
            raise JsonLoadError(f"invalid JSON in {label}: {detail}") from relaxed_error


def dump_json(data: Any, *, indent: int = 2) -> str:
    """Serialize to JSON. Insertion order is preserved.

    `sort_keys=False` is critical — sorting destroys the operator's
    intended file ordering. Trailing newline is added so the file
    is POSIX-compliant.
    """
    return json.dumps(data, indent=indent, sort_keys=False, ensure_ascii=False) + "\n"


def write_json(data: Any, path: Path, *, indent: int = 2) -> None:
    """Atomically write JSON to a file (write-temp + rename)."""
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(dump_json(data, indent=indent), encoding="utf-8")
    tmp.replace(path)


__all__ = ["JsonLoadError", "dump_json", "load_json", "write_json"]
