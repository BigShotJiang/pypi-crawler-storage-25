# tvip — Beta Fermee

> **BREVET EN COURS DE DEPOT — PATENT PENDING**
>
> Ce SDK est distribue en beta fermee. L'acces necessite une invitation
> et une cle API valide fournie par Missylia Systems.

SDK officiel Python pour le **protocole TVIP** (Transaction-to-Verified-Invoice Protocol).

Correle les autorisations de paiement avec les factures marchands detaillees en temps reel.

## Acces Beta

Ce SDK n'est pas disponible publiquement. Pour demander l'acces :

- Email : contact@missylia.com
- Sujet : "Demande acces SDK TVIP Beta"

## Installation (participants beta uniquement)

```bash
pip install tvip
```

## Quick Start

```python
from tvip import TVIP

# Cle API fournie par VELA Protocol
client = TVIP(api_key="sk_beta_votre_cle")

# 1. Creer une session de correlation
session = client.create_session(
    amount=12450,  # centimes
    currency="EUR",
    merchant_order_id="ord_1001"
)

# 2. Envoyer la facture depuis le POS
client.send_invoice(
    correlation_token=session["correlation_token"],
    invoice_id="inv_1001",
    items=[
        {"name": "Tomates bio", "quantity": 4, "unit_price": 2500, "tax_rate": 0.055},
        {"name": "Pain complet", "quantity": 1, "unit_price": 2450, "tax_rate": 0.055},
    ],
    total=12450,
    currency="EUR"
)

# 3. TVIP cree automatiquement un evenement verifie :
#    -> Signe SHA-256
#    -> Ecritures comptables (PCG)
#    -> Rapprochement bancaire
#    -> Categorisation IA
```

## AI Vision Scanner

```python
import base64

with open("ticket.jpg", "rb") as f:
    image_b64 = base64.b64encode(f.read()).decode()

parsed = client.scan_image(image_b64)
# Retourne : {merchant, items, total, tax, ...}
```

## Verification Webhook

```python
from tvip import TVIP

is_valid = TVIP.verify_webhook(
    payload=request.body.decode(),
    signature=request.headers["X-TVIP-Signature"],
    secret=os.environ["TVIP_WEBHOOK_SECRET"]
)
```

## Context Manager

```python
with TVIP(api_key="sk_beta_xxx") as client:
    events = client.list_events(status="verified", limit=10)
```

## API Reference

| Methode | Description |
|---------|-------------|
| `create_session(amount, currency, ...)` | Creer session de correlation |
| `get_session(token)` | Obtenir session par token |
| `send_invoice(...)` | Envoyer facture marchande |
| `get_event(id)` | Obtenir evenement TVIP |
| `list_events(status?, limit?, offset?)` | Lister evenements |
| `ingest(source, data)` | Ingerer Factur-X/JSON/XML |
| `scan_image(base64)` | Scanner ticket IA Vision |
| `TVIP.verify_webhook(...)` | Verifier signature HMAC-SHA256 |

## Licence

Licence proprietaire — Missylia Systems
Brevet en cours de depot (Patent Pending)
Voir fichier LICENSE pour les conditions d'utilisation.

(c) 2026 Missylia Systems. Tous droits reserves.
