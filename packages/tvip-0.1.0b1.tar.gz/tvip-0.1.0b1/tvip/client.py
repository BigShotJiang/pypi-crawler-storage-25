"""
TVIP SDK Python Client
Transaction-to-Verified-Invoice Protocol
"""

import hashlib
import hmac
from typing import Any, Dict, List, Optional

import httpx


class TVIPError(Exception):
    """TVIP API Error"""

    def __init__(self, message: str, status: int = 0, code: str = ""):
        super().__init__(message)
        self.status = status
        self.code = code


class TVIP:
    """
    TVIP SDK Client

    Args:
        api_key: API key (sk_test_* or sk_live_*)
        base_url: Base URL (default: https://api.tvip.com)
        timeout: Request timeout in seconds (default: 30)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.tvip.com",
        timeout: int = 30,
    ):
        if not api_key:
            raise TVIPError("API key is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.is_sandbox = api_key.startswith("sk_test_")
        self._client = httpx.Client(
            base_url=f"{self.base_url}/sdk/v2",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "X-TVIP-SDK": f"python/{__import__('tvip').__version__}",
            },
            timeout=timeout,
        )

    def _request(self, method: str, path: str, json: Any = None) -> Dict:
        try:
            resp = self._client.request(method, path, json=json)
            data = resp.json()
            if resp.status_code >= 400:
                raise TVIPError(
                    data.get("detail", data.get("message", "API Error")),
                    resp.status_code,
                    data.get("code", ""),
                )
            return data
        except httpx.HTTPError as e:
            raise TVIPError(str(e)) from e

    # ─── Sessions ───

    def create_session(
        self,
        amount: int,
        currency: str,
        merchant_order_id: Optional[str] = None,
    ) -> Dict:
        """Create a TVIP correlation session.

        Args:
            amount: Amount in cents
            currency: ISO 4217 currency code
            merchant_order_id: Optional merchant order reference

        Returns:
            Session dict with correlation_token
        """
        payload = {"amount": amount, "currency": currency}
        if merchant_order_id:
            payload["merchant_order_id"] = merchant_order_id
        return self._request("POST", "/sessions", json=payload)

    def get_session(self, correlation_token: str) -> Dict:
        """Get session by correlation token."""
        return self._request("GET", f"/sessions/{correlation_token}")

    # ─── Invoices ───

    def send_invoice(
        self,
        correlation_token: str,
        invoice_id: str,
        items: List[Dict],
        total: int,
        currency: str,
    ) -> Dict:
        """Send a detailed merchant invoice.

        Args:
            correlation_token: Session correlation token
            invoice_id: Merchant invoice ID
            items: List of {name, quantity, unit_price, tax_rate}
            total: Total in cents
            currency: ISO 4217 currency code
        """
        return self._request(
            "POST",
            "/invoices",
            json={
                "correlation_token": correlation_token,
                "invoice_id": invoice_id,
                "items": items,
                "total": total,
                "currency": currency,
            },
        )

    # ─── Events ───

    def get_event(self, event_id: str) -> Dict:
        """Get TVIP event by ID."""
        return self._request("GET", f"/events/{event_id}")

    def list_events(
        self,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[Dict]:
        """List TVIP events with optional filters."""
        params = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        qs = "&".join(f"{k}={v}" for k, v in params.items())
        return self._request("GET", f"/events?{qs}")

    # ─── Ingestion ───

    def ingest(self, source: str, data: Any) -> Dict:
        """Ingest an invoice (facturx, json, xml).

        Args:
            source: 'facturx' | 'json' | 'xml'
            data: Invoice data
        """
        return self._request("POST", "/ingest", json={"source": source, "data": data})

    def scan_image(self, base64_image: str) -> Dict:
        """Scan invoice image with AI Vision.

        Args:
            base64_image: Base64 encoded image

        Returns:
            Parsed invoice data (merchant, items, total, tax)
        """
        return self._request("POST", "/ingest/scan", json={"image": base64_image})

    # ─── Webhooks ───

    @staticmethod
    def verify_webhook(payload: str, signature: str, secret: str) -> bool:
        """Verify webhook signature (HMAC-SHA256).

        Args:
            payload: Raw request body
            signature: X-TVIP-Signature header value
            secret: Webhook secret

        Returns:
            True if signature is valid
        """
        expected = hmac.new(
            secret.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(signature, expected)

    def close(self):
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
