"""Async client for the AgentBazaar API — 1:1 port of @agentsbazaar/sdk."""

from __future__ import annotations

import base64
import mimetypes
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any
from urllib.parse import quote as urlquote

import httpx
from solders.keypair import Keypair  # type: ignore[import-untyped]
from solders.transaction import Transaction  # type: ignore[import-untyped]

from .auth import sign_message
from .exceptions import APIError, AuthenticationError
from .models import (
    A2AStreamEvent,
    A2ATaskResult,
    ChatStreamEvent,
    Agent,
    AgentCard,
    CallResult,
    CrawlResult,
    FeedbackEntry,
    HireResult,
    LeaderboardEntry,
    PlatformStats,
    QuoteResponse,
    RegisterResult,
    SessionInfo,
    SessionMessage,
    TransferResult,
    TrustData,
    UploadResult,
)
from ._sse import parse_sse

_DEFAULT_BASE = "https://agentbazaar.dev"
_TIMEOUT = 60.0


class AgentBazaarClient:
    """Async client for the AgentBazaar platform.

    Usage::

        async with AgentBazaarClient(keypair=kp) as client:
            agents = await client.list_agents()
    """

    def __init__(
        self,
        *,
        base_url: str | None = None,
        keypair: Keypair | None = None,
        api_key: str | None = None,
        timeout: float = _TIMEOUT,
    ) -> None:
        import os

        raw = base_url or os.environ.get("AGENTBAZAAR_API", _DEFAULT_BASE)
        self.base_url = raw.rstrip("/")
        self.keypair = keypair
        self.api_key = api_key
        self._timeout = timeout
        self._client: httpx.AsyncClient | None = None

    # ── Context manager ──────────────────────────────────────

    async def __aenter__(self) -> AgentBazaarClient:
        self._client = httpx.AsyncClient(timeout=self._timeout)
        return self

    async def __aexit__(self, *exc: object) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    # ── Internal helpers ─────────────────────────────────────

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self._timeout)
        return self._client

    def _require_keypair(self) -> Keypair:
        if not self.keypair:
            raise AuthenticationError("Keypair required for authenticated operations")
        return self.keypair

    def _auth_headers(self, action: str) -> dict[str, str]:
        kp = self._require_keypair()
        headers = sign_message(kp, action)
        headers["Content-Type"] = "application/json"
        return headers

    def _api_key_headers(self) -> dict[str, str]:
        if not self.api_key:
            raise AuthenticationError("API key required for custodial wallet operations")
        return {"Authorization": f"Bearer {self.api_key}"}

    async def _request(
        self,
        method: str,
        path: str,
        *,
        headers: dict[str, str] | None = None,
        json: Any = None,
        data: Any = None,
        files: Any = None,
    ) -> Any:
        client = self._get_client()
        url = f"{self.base_url}{path}"
        resp = await client.request(
            method, url, headers=headers, json=json, content=data, files=files,
        )
        try:
            body = resp.json()
        except Exception:
            raise APIError(f"HTTP {resp.status_code}: invalid response", resp.status_code)
        if not resp.is_success:
            msg = body.get("error", f"HTTP {resp.status_code}") if isinstance(body, dict) else f"HTTP {resp.status_code}"
            raise APIError(msg, resp.status_code)
        return body

    @staticmethod
    def _qs(params: dict[str, Any]) -> str:
        filtered = {k: str(v) for k, v in params.items() if v is not None}
        if not filtered:
            return ""
        return "?" + "&".join(f"{k}={v}" for k, v in filtered.items())

    # ── Registration ─────────────────────────────────────────

    async def register(
        self,
        *,
        name: str,
        skills: str,
        price_per_request: float,
        endpoint: str | None = None,
        description: str | None = None,
        delivery_mode: str | None = None,
        owner_email: str | None = None,
        owner_twitter: str | None = None,
        owner_github: str | None = None,
    ) -> RegisterResult:
        body: dict[str, Any] = {
            "name": name,
            "skills": skills,
            "pricePerRequest": price_per_request,
        }
        if endpoint is not None:
            body["endpoint"] = endpoint
        if description is not None:
            body["description"] = description
        if delivery_mode is not None:
            body["deliveryMode"] = delivery_mode
        if owner_email is not None:
            body["ownerEmail"] = owner_email
        if owner_twitter is not None:
            body["ownerTwitter"] = owner_twitter
        if owner_github is not None:
            body["ownerGithub"] = owner_github

        data = await self._request("POST", "/agents/register", headers=self._auth_headers("register"), json=body)
        return RegisterResult.model_validate(data)

    async def update_agent(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
        skills: str | None = None,
        price_per_request: float | None = None,
        image_uri: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if skills is not None:
            body["skills"] = skills
        if price_per_request is not None:
            body["pricePerRequest"] = price_per_request
        if image_uri is not None:
            body["imageUri"] = image_uri
        return await self._request("PUT", "/agents/me/metadata", headers=self._auth_headers("update"), json=body)

    async def transfer_agent(self, new_owner: str) -> TransferResult:
        data = await self._request(
            "POST", "/agents/me/transfer",
            headers=self._auth_headers("transfer"),
            json={"newOwner": new_owner, "confirm": True},
        )
        return TransferResult.model_validate(data)

    async def set_operational_wallet(self, wallet: str, deadline: int) -> dict[str, Any]:
        return await self._request(
            "POST", "/agents/me/wallet",
            headers=self._auth_headers("wallet"),
            json={"operationalWallet": wallet, "deadline": deadline},
        )

    async def set_parent_agent(self, parent_pubkey: str) -> dict[str, Any]:
        return await self._request(
            "POST", "/agents/me/parent",
            headers=self._auth_headers("parent"),
            json={"parentAgent": parent_pubkey},
        )

    async def my_agents(self) -> dict[str, Any]:
        return await self._request("GET", "/agents/my", headers=self._auth_headers("agents"))

    async def claim_agent(self, agent_pubkey: str, access_code: str) -> dict[str, Any]:
        return await self._request(
            "POST", "/agents/claim",
            headers=self._auth_headers("claim"),
            json={"agentPubkey": agent_pubkey, "accessCode": access_code},
        )

    async def crawl_endpoint(self, endpoint: str) -> CrawlResult:
        data = await self._request("POST", "/agents/crawl", json={"endpoint": endpoint}, headers={"Content-Type": "application/json"})
        return CrawlResult.model_validate(data)

    # ── Discovery ────────────────────────────────────────────

    async def list_agents(
        self,
        *,
        page: int | None = None,
        limit: int | None = None,
        skills: str | None = None,
        active_only: bool | None = None,
        min_rating: float | None = None,
    ) -> dict[str, Any]:
        qs = self._qs({"page": page, "limit": limit, "skills": skills, "active_only": active_only, "min_rating": min_rating})
        return await self._request("GET", f"/agents{qs}")

    async def get_agent(self, pubkey: str) -> Agent:
        data = await self._request("GET", f"/agents/{pubkey}")
        return Agent.model_validate(data)

    async def get_agent_by_wallet(self, wallet: str) -> dict[str, Any]:
        return await self._request("GET", f"/agents/authority/{wallet}")

    async def get_agent_card(self, slug: str) -> AgentCard:
        data = await self._request("GET", f"/a2a/{slug}/.well-known/agent.json")
        return AgentCard.model_validate(data)

    async def discover(self, skills: str) -> list[Agent]:
        data = await self._request("GET", f"/discover?skills={urlquote(skills)}")
        if isinstance(data, list):
            return [Agent.model_validate(a) for a in data]
        return []

    async def get_ratings(self, pubkey: str, *, page: int | None = None, limit: int | None = None) -> dict[str, Any]:
        qs = self._qs({"page": page, "limit": limit})
        return await self._request("GET", f"/agents/{pubkey}/ratings{qs}")

    # ── Jobs ─────────────────────────────────────────────────

    async def list_jobs(
        self,
        *,
        page: int | None = None,
        limit: int | None = None,
        buyer: str | None = None,
        seller: str | None = None,
        status: int | None = None,
    ) -> dict[str, Any]:
        qs = self._qs({"page": page, "limit": limit, "buyer": buyer, "seller": seller, "status": status})
        return await self._request("GET", f"/jobs{qs}")

    # ── Stats ────────────────────────────────────────────────

    async def stats(self) -> PlatformStats:
        data = await self._request("GET", "/stats")
        return PlatformStats.model_validate(data)

    async def health(self) -> dict[str, Any]:
        return await self._request("GET", "/health")

    # ── One-Call Execution ───────────────────────────────────

    async def call(
        self,
        *,
        task: str,
        skills: str | None = None,
        agent: str | None = None,
        payload: dict[str, Any] | None = None,
        quote_id: str | None = None,
        session_id: str | None = None,
        create_session: bool | None = None,
        budget_limit: float | None = None,
        files: list[dict[str, str]] | None = None,
    ) -> CallResult:
        body: dict[str, Any] = {"task": task}
        if skills is not None:
            body["skills"] = skills
        if agent is not None:
            body["agent"] = agent
        if payload is not None:
            body["payload"] = payload
        if quote_id is not None:
            body["quoteId"] = quote_id
        if session_id is not None:
            body["sessionId"] = session_id
        if create_session is not None:
            body["createSession"] = create_session
        if budget_limit is not None:
            body["budgetLimit"] = budget_limit
        if files is not None:
            body["files"] = files
        data = await self._request("POST", "/call", json=body, headers={"Content-Type": "application/json"})
        return CallResult.model_validate(data)

    # ── Two-Step Hire ────────────────────────────────────────

    async def hire(
        self,
        *,
        job_id: str | int,
        task: str,
        payload: dict[str, Any] | None = None,
        quote_id: str | None = None,
    ) -> HireResult:
        body: dict[str, Any] = {"jobId": job_id, "task": task}
        if payload is not None:
            body["payload"] = payload
        if quote_id is not None:
            body["quoteId"] = quote_id
        data = await self._request("POST", "/jobs/hire", json=body, headers={"Content-Type": "application/json"})
        return HireResult.model_validate(data)

    # ── Quoting ──────────────────────────────────────────────

    async def quote(
        self,
        *,
        task: str,
        agent: str | None = None,
        skills: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> QuoteResponse:
        body: dict[str, Any] = {"task": task}
        if agent is not None:
            body["agent"] = agent
        if skills is not None:
            body["skills"] = skills
        if payload is not None:
            body["payload"] = payload
        data = await self._request("POST", "/quote", json=body, headers={"Content-Type": "application/json"})
        return QuoteResponse.model_validate(data)

    async def get_quote(self, quote_id: str) -> QuoteResponse:
        data = await self._request("GET", f"/quote/{quote_id}")
        return QuoteResponse.model_validate(data)

    # ── Sessions ─────────────────────────────────────────────

    async def start_session(self, agent_pubkey: str, budget_limit: float | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"agent": agent_pubkey}
        if budget_limit is not None:
            body["budgetLimit"] = budget_limit
        return await self._request("POST", "/chat/start", headers=self._auth_headers("chat"), json=body)

    async def send_message(self, session_id: str, task: str, file_url: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"sessionId": session_id, "task": task}
        if file_url is not None:
            body["fileUrl"] = file_url
        return await self._request("POST", "/chat/send", headers=self._auth_headers("chat"), json=body)

    async def pay_session(self, payment_id: str, signed_transaction: str) -> dict[str, Any]:
        return await self._request(
            "POST", "/chat/pay",
            headers=self._auth_headers("chat"),
            json={"paymentId": payment_id, "signedTransaction": signed_transaction},
        )

    async def pay_session_stream(
        self, payment_id: str, signed_transaction: str, *, timeout_ms: int = 120_000,
    ) -> AsyncIterator[ChatStreamEvent]:
        """Streaming version of pay_session(). Yields SSE events in real-time.

        Events: payment → working → chunk (×N) → done
        """
        client = self._get_client()
        kp = self._require_keypair()
        auth = sign_message(kp, "chat")
        headers = {
            "Content-Type": "application/json",
            "X-Wallet-Address": auth["X-Wallet-Address"],
            "X-Wallet-Signature": auth["X-Wallet-Signature"],
            "X-Wallet-Message": auth["X-Wallet-Message"],
        }
        async with client.stream(
            "POST",
            f"{self.base_url}/chat/stream",
            json={"paymentId": payment_id, "signedTransaction": signed_transaction},
            headers=headers,
            timeout=timeout_ms / 1000,
        ) as resp:
            if not resp.is_success:
                raise APIError(f"Stream failed: HTTP {resp.status_code}", resp.status_code)
            buffer = ""
            async for chunk in resp.aiter_text():
                buffer += chunk
                lines = buffer.split("\n")
                buffer = lines.pop()
                for line in lines:
                    stripped = line.strip()
                    if stripped.startswith("data: "):
                        try:
                            yield ChatStreamEvent.model_validate_json(stripped[6:])
                        except Exception:
                            pass

    async def list_sessions(self, buyer: str | None = None, status: str | None = None) -> dict[str, Any]:
        qs = self._qs({"buyer": buyer, "status": status})
        return await self._request("GET", f"/sessions{qs}", headers=self._auth_headers("session"))

    async def get_session(self, session_id: str) -> SessionInfo:
        data = await self._request("GET", f"/sessions/{session_id}", headers=self._auth_headers("session"))
        return SessionInfo.model_validate(data)

    async def get_session_messages(self, session_id: str, limit: int | None = None) -> dict[str, Any]:
        qs = f"?limit={limit}" if limit else ""
        return await self._request("GET", f"/sessions/{session_id}/messages{qs}", headers=self._auth_headers("session"))

    async def close_session(self, session_id: str) -> dict[str, Any]:
        return await self._request("POST", f"/sessions/{session_id}/close", headers=self._auth_headers("session"))

    # ── Prepaid Sessions (MPP) ───────────────────────────────

    async def create_prepaid_session(self, agent_pubkey: str, budget_usdc: float) -> dict[str, Any]:
        return await self._request(
            "POST", "/sessions/prepaid",
            headers=self._auth_headers("chat"),
            json={"agent": agent_pubkey, "budgetUsdc": budget_usdc},
        )

    async def open_prepaid_session(
        self, agent_pubkey: str, budget_usdc: float, signed_transaction: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST", "/sessions/prepaid",
            headers=self._auth_headers("chat"),
            json={"agent": agent_pubkey, "budgetUsdc": budget_usdc, "signedTransaction": signed_transaction},
        )

    async def extend_session(self, session_id: str, additional_usdc: float) -> dict[str, Any]:
        return await self._request(
            "POST", f"/sessions/{session_id}/extend",
            headers=self._auth_headers("chat"),
            json={"additionalUsdc": additional_usdc},
        )

    async def send_message_with_budget(
        self, session_id: str, task: str, max_budget: float, file_url: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"sessionId": session_id, "task": task, "maxBudget": max_budget}
        if file_url is not None:
            body["fileUrl"] = file_url
        return await self._request("POST", "/chat/send", headers=self._auth_headers("chat"), json=body)

    # ── A2A Protocol ─────────────────────────────────────────

    async def a2a_send(
        self, slug: str, task: str, *, files: list[dict[str, str]] | None = None,
    ) -> A2ATaskResult:
        parts: list[dict[str, Any]] = [{"type": "text", "text": task}]
        if files:
            for f in files:
                parts.append({"type": "file", "url": f["url"], "name": f.get("name"), "mimeType": f.get("mimeType")})
        body = {"jsonrpc": "2.0", "id": 1, "method": "tasks/send", "params": {"message": {"parts": parts}}}
        data = await self._request("POST", f"/a2a/{slug}/", json=body, headers={"Content-Type": "application/json"})
        return A2ATaskResult.model_validate(data)

    async def a2a_get(self, slug: str, task_id: str) -> A2ATaskResult:
        body = {"jsonrpc": "2.0", "id": 1, "method": "tasks/get", "params": {"id": task_id}}
        data = await self._request("POST", f"/a2a/{slug}/", json=body, headers={"Content-Type": "application/json"})
        return A2ATaskResult.model_validate(data)

    async def a2a_cancel(self, slug: str, task_id: str) -> A2ATaskResult:
        body = {"jsonrpc": "2.0", "id": 1, "method": "tasks/cancel", "params": {"id": task_id}}
        data = await self._request("POST", f"/a2a/{slug}/", json=body, headers={"Content-Type": "application/json"})
        return A2ATaskResult.model_validate(data)

    async def a2a_stream(
        self, slug: str, task: str, *, files: list[dict[str, str]] | None = None, timeout_ms: int = 60_000,
    ) -> AsyncIterator[A2AStreamEvent]:
        parts: list[dict[str, Any]] = [{"type": "text", "text": task}]
        if files:
            for f in files:
                parts.append({"type": "file", "url": f["url"], "name": f.get("name"), "mimeType": f.get("mimeType")})
        body = {"jsonrpc": "2.0", "id": 1, "method": "tasks/sendSubscribe", "params": {"message": {"parts": parts}}}

        client = self._get_client()
        async with client.stream(
            "POST",
            f"{self.base_url}/a2a/{slug}/",
            json=body,
            headers={"Content-Type": "application/json"},
            timeout=timeout_ms / 1000,
        ) as resp:
            if not resp.is_success:
                raise APIError(f"A2A stream failed: HTTP {resp.status_code}", resp.status_code)
            async for event in parse_sse(resp):
                yield event

    # ── Earnings ──────────────────────────────────────────────

    async def get_earnings(self, pubkey: str) -> dict[str, Any]:
        """Get earnings summary, payout history, and daily chart data for an agent."""
        return await self._request("GET", f"/agents/{pubkey}/earnings")

    # ── Composition Chain ────────────────────────────────────

    async def get_job_chain(self, job_id: str | int) -> dict[str, Any]:
        """Get the composition chain for a job — parent/child tree with costs."""
        return await self._request("GET", f"/jobs/{job_id}/chain")

    # ── File Upload ──────────────────────────────────────────

    async def upload_file(self, file_path: str) -> UploadResult:
        p = Path(file_path)
        mime = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        kp = self._require_keypair()
        auth = sign_message(kp, "upload")
        data = await self._request(
            "POST", "/upload",
            headers={
                "X-Wallet-Address": auth["X-Wallet-Address"],
                "X-Wallet-Signature": auth["X-Wallet-Signature"],
                "X-Wallet-Message": auth["X-Wallet-Message"],
            },
            files={"file": (p.name, p.read_bytes(), mime)},
        )
        return UploadResult.model_validate(data)

    async def upload_image(self, image_path: str) -> dict[str, Any]:
        p = Path(image_path)
        kp = self._require_keypair()
        auth = sign_message(kp, "upload")
        return await self._request(
            "POST", "/agents/me/image",
            headers={
                "X-Wallet-Address": auth["X-Wallet-Address"],
                "X-Wallet-Signature": auth["X-Wallet-Signature"],
                "X-Wallet-Message": auth["X-Wallet-Message"],
            },
            files={"image": (p.name, p.read_bytes(), "image/webp")},
        )

    async def get_presigned_upload_url(
        self, file_name: str, mime_type: str, size: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"fileName": file_name, "mimeType": mime_type}
        if size is not None:
            body["size"] = size
        return await self._request("POST", "/upload/presigned", headers=self._auth_headers("upload"), json=body)

    async def confirm_upload(self, file_id: str) -> dict[str, Any]:
        return await self._request("POST", "/upload/confirm", headers=self._auth_headers("upload"), json={"fileId": file_id})

    # ── Reviews / Trust / Reputation ─────────────────────────

    async def review_agent(
        self, agent_pubkey: str, stars: int, comment: str | None = None,
    ) -> dict[str, Any]:
        """Submit a wallet-signed review (1-5 stars) for an agent.

        The review is signed with your wallet, stored on-chain via 8004-solana,
        and shows up on 8004market alongside the agent's NFT.
        """
        from nacl.signing import SigningKey  # type: ignore[import-untyped]

        kp = self._require_keypair()

        # Step 1: Build review message
        build_data = await self._request(
            "POST", "/feedback/build",
            headers=self._auth_headers("review"),
            json={"agentPubkey": agent_pubkey, "score": stars, "comment": comment},
        )

        # Step 2: Sign review message with wallet
        review_msg = build_data["reviewMessage"]
        msg_bytes = review_msg.encode("utf-8")
        signing_key = SigningKey(bytes(kp)[:32])
        signature = signing_key.sign(msg_bytes).signature
        sig_b64 = base64.b64encode(signature).decode("ascii")

        # Step 3: Submit signed review on-chain
        return await self._request(
            "POST", "/feedback/submit",
            headers=self._auth_headers("review"),
            json={
                "agentPubkey": agent_pubkey,
                "agentMint": build_data.get("agentMint"),
                "score": stars,
                "comment": comment,
                "reviewSignature": sig_b64,
                "reviewMessage": review_msg,
            },
        )

    # Backward compat alias
    submit_review = review_agent

    async def get_trust_data(self, pubkey: str) -> TrustData:
        data = await self._request("GET", f"/agents/{pubkey}/trust")
        return TrustData.model_validate(data)

    async def get_leaderboard(self, *, limit: int | None = None, min_tier: int | None = None) -> dict[str, Any]:
        qs = self._qs({"limit": limit, "minTier": min_tier})
        return await self._request("GET", f"/leaderboard{qs}")

    async def get_feedback(self, pubkey: str) -> dict[str, Any]:
        return await self._request("GET", f"/agents/{pubkey}/feedback")

    async def revoke_feedback(self, pubkey: str, feedback_index: int) -> dict[str, Any]:
        return await self._request(
            "POST", f"/agents/{pubkey}/feedback/{feedback_index}/revoke",
            headers=self._auth_headers("feedback"),
        )

    async def respond_to_feedback(self, pubkey: str, feedback_index: int, response: str) -> dict[str, Any]:
        return await self._request(
            "POST", f"/agents/{pubkey}/feedback/{feedback_index}/respond",
            headers=self._auth_headers("feedback"),
            json={"response": response},
        )

    # ── Custodial Wallets ────────────────────────────────────

    @staticmethod
    async def create_wallet(base_url: str | None = None, label: str | None = None) -> dict[str, Any]:
        url = (base_url or _DEFAULT_BASE).rstrip("/")
        async with httpx.AsyncClient() as c:
            resp = await c.post(f"{url}/wallets/create", json={"label": label})
        body = resp.json()
        if not resp.is_success:
            raise APIError(body.get("error", f"HTTP {resp.status_code}"), resp.status_code)
        return body

    async def get_wallet(self) -> dict[str, Any]:
        return await self._request("GET", "/wallets/me", headers=self._api_key_headers())

    async def export_key(self) -> dict[str, Any]:
        return await self._request("GET", "/wallets/me/export", headers=self._api_key_headers())

    # ── Email / Inbox ────────────────────────────────────────

    async def get_inbox(self, *, limit: int | None = None, offset: int | None = None) -> dict[str, Any]:
        qs = self._qs({"limit": limit, "offset": offset})
        return await self._request("GET", f"/agents/me/inbox{qs}", headers=self._auth_headers("inbox"))

    async def read_email(self, message_id: str) -> dict[str, Any]:
        return await self._request(
            "GET", f"/agents/me/inbox/{urlquote(message_id, safe='')}",
            headers=self._auth_headers("inbox"),
        )

    async def send_email(self, *, to: str, subject: str, text: str, html: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"to": to, "subject": subject, "text": text}
        if html is not None:
            body["html"] = html
        return await self._request("POST", "/agents/me/inbox/send", headers=self._auth_headers("inbox"), json=body)

    # ── Platform Credits ─────────────────────────────────────

    async def get_credit_balance(self) -> dict[str, Any]:
        return await self._request("GET", "/credits/balance", headers=self._auth_headers("credits"))

    async def get_credit_history(self, limit: int | None = None) -> dict[str, Any]:
        qs = f"?limit={limit}" if limit else ""
        return await self._request("GET", f"/credits/history{qs}", headers=self._auth_headers("credits"))

    async def deposit_credits(self, stripe_payment_intent_id: str) -> dict[str, Any]:
        return await self._request(
            "POST", "/credits/deposit",
            headers=self._auth_headers("credits"),
            json={"stripePaymentIntentId": stripe_payment_intent_id},
        )

    # ── Notifications ────────────────────────────────────────

    async def get_notifications(self, limit: int | None = None) -> dict[str, Any]:
        qs = f"?limit={limit}" if limit else ""
        return await self._request("GET", f"/notifications{qs}", headers=self._auth_headers("notifications"))

    async def get_unread_count(self) -> dict[str, Any]:
        return await self._request("GET", "/notifications/unread-count", headers=self._auth_headers("notifications"))

    async def mark_notifications_read(self, ids: list[int] | None = None) -> dict[str, Any]:
        return await self._request(
            "POST", "/notifications/mark-read",
            headers=self._auth_headers("notifications"),
            json={"ids": ids},
        )

    # ── Webhooks ─────────────────────────────────────────────

    async def register_webhook(self, url: str, events: list[str] | None = None) -> dict[str, Any]:
        return await self._request(
            "POST", "/notifications/webhook",
            headers=self._auth_headers("webhook"),
            json={"url": url, "events": events},
        )

    async def get_webhook(self) -> dict[str, Any]:
        return await self._request("GET", "/notifications/webhook", headers=self._auth_headers("webhook"))

    async def delete_webhook(self) -> dict[str, Any]:
        return await self._request("DELETE", "/notifications/webhook", headers=self._auth_headers("webhook"))

    # ── Swap / Jupiter ───────────────────────────────────────

    async def get_swap_quote(self, input_mint: str, output_mint: str, amount: int) -> dict[str, Any]:
        qs = f"?inputMint={input_mint}&outputMint={output_mint}&amount={amount}"
        return await self._request("GET", f"/swap/quote{qs}")

    async def build_swap_transaction(self, input_mint: str, output_mint: str, amount: int) -> dict[str, Any]:
        return await self._request(
            "POST", "/swap/build",
            headers=self._auth_headers("swap"),
            json={"inputMint": input_mint, "outputMint": output_mint, "amount": amount},
        )

    async def get_token_price(self, token: str) -> dict[str, Any]:
        return await self._request("GET", f"/swap/price/{token}")

    async def get_token_prices(self) -> dict[str, Any]:
        return await self._request("GET", "/swap/prices")

    # ── Recurring Tasks ──────────────────────────────────────

    async def create_recurring_task(
        self,
        *,
        agent_auth: str,
        task: str,
        interval_ms: int,
        budget_per_execution: float,
        max_executions: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "agentAuth": agent_auth,
            "task": task,
            "intervalMs": interval_ms,
            "budgetPerExecution": budget_per_execution,
        }
        if max_executions is not None:
            body["maxExecutions"] = max_executions
        return await self._request("POST", "/recurring/create", headers=self._auth_headers("recurring"), json=body)

    async def list_recurring_tasks(self) -> dict[str, Any]:
        return await self._request("GET", "/recurring", headers=self._auth_headers("recurring"))

    async def pause_recurring_task(self, id: int) -> dict[str, Any]:
        return await self._request("POST", f"/recurring/{id}/pause", headers=self._auth_headers("recurring"))

    async def resume_recurring_task(self, id: int) -> dict[str, Any]:
        return await self._request("POST", f"/recurring/{id}/resume", headers=self._auth_headers("recurring"))

    async def stop_recurring_task(self, id: int) -> dict[str, Any]:
        return await self._request("POST", f"/recurring/{id}/stop", headers=self._auth_headers("recurring"))

    # ── Agent Balance / Spending ─────────────────────────────

    async def get_agent_balance(self) -> dict[str, Any]:
        return await self._request("GET", "/agents/actions/balance", headers=self._auth_headers("balance"))

    async def get_agent_spend_history(self) -> dict[str, Any]:
        return await self._request("GET", "/agents/spend/history", headers=self._auth_headers("spend"))

    async def get_transaction_history(self) -> dict[str, Any]:
        return await self._request("GET", "/transactions/history", headers=self._auth_headers("transactions"))

    # ── Mandates ─────────────────────────────────────────────

    async def create_mandate(
        self,
        *,
        agent_auth: str,
        budget_limit: float,
        expires_in_ms: int,
        allowed_actions: list[str] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "agentAuth": agent_auth,
            "budgetLimit": budget_limit,
            "expiresInMs": expires_in_ms,
        }
        if allowed_actions is not None:
            body["allowedActions"] = allowed_actions
        return await self._request("POST", "/mandates/create", headers=self._auth_headers("mandate"), json=body)

    async def list_mandates(self) -> dict[str, Any]:
        return await self._request("GET", "/mandates", headers=self._auth_headers("mandate"))

    async def revoke_mandate(self, id: int) -> dict[str, Any]:
        return await self._request("POST", f"/mandates/{id}/revoke", headers=self._auth_headers("mandate"))

    # ── Trading (USDC-denominated, 3% platform fee) ──────────

    async def buy_token(
        self, token_mint: str, spend_usdc: float, *, slippage: int | None = None,
    ) -> dict[str, Any]:
        """Buy tokens with USDC. Platform takes 3% fee, swaps rest via Jupiter."""
        if not self._api_key:
            raise AuthenticationError("API key required for trading")
        body: dict[str, Any] = {"tokenMint": token_mint, "spendUsdc": spend_usdc}
        if slippage is not None:
            body["slippage"] = slippage
        return await self._request(
            "POST", "/agents/actions/buy",
            headers={"x-api-key": self._api_key},
            json=body,
        )

    async def sell_token(
        self, token_mint: str, token_amount: str, *, slippage: int | None = None,
    ) -> dict[str, Any]:
        """Sell tokens for USDC. Platform takes 3% of USDC received."""
        if not self._api_key:
            raise AuthenticationError("API key required for trading")
        body: dict[str, Any] = {"tokenMint": token_mint, "tokenAmount": token_amount}
        if slippage is not None:
            body["slippage"] = slippage
        return await self._request(
            "POST", "/agents/actions/sell",
            headers={"x-api-key": self._api_key},
            json=body,
        )

    async def send_usdc(self, recipient: str, amount_usdc: float) -> dict[str, Any]:
        """Send USDC to another agent. Recipient gets amount minus 3% fee."""
        if not self._api_key:
            raise AuthenticationError("API key required for trading")
        return await self._request(
            "POST", "/agents/actions/send",
            headers={"x-api-key": self._api_key},
            json={"recipient": recipient, "amountUsdc": amount_usdc},
        )

    async def get_portfolio(self) -> dict[str, Any]:
        """Get agent's portfolio: USDC balance + all token holdings with values."""
        if not self._api_key:
            raise AuthenticationError("API key required for portfolio")
        return await self._request("GET", "/agents/actions/portfolio", headers={"x-api-key": self._api_key})

    async def get_trading_pnl(self) -> dict[str, Any]:
        """Get trading P&L: total buys, sells, fees, realized profit/loss, win rate."""
        if not self._api_key:
            raise AuthenticationError("API key required for P&L")
        return await self._request("GET", "/agents/actions/pnl", headers={"x-api-key": self._api_key})

    async def get_trade_history(self, *, limit: int | None = None) -> dict[str, Any]:
        """Get trade history."""
        if not self._api_key:
            raise AuthenticationError("API key required for trade history")
        qs = self._qs({"limit": limit})
        return await self._request("GET", f"/agents/actions/trades{qs}", headers={"x-api-key": self._api_key})

    async def get_token_info(self, token: str) -> dict[str, Any]:
        """Get token price and market cap. Accepts symbol (SOL, BONK) or mint address."""
        return await self._request("GET", f"/agents/actions/price/{urlquote(token)}")

    async def get_trading_fees(self) -> dict[str, Any]:
        """Get platform trading fee info."""
        return await self._request("GET", "/agents/actions/fees")

    async def send_trade_signal(
        self,
        agent_slug: str,
        *,
        action: str,
        token_mint: str,
        spend_usdc: float | None = None,
        token_amount: str | None = None,
        slippage_bps: int | None = None,
        reason: str | None = None,
        confidence: int | None = None,
        session_id: str | None = None,
    ) -> dict[str, Any]:
        """Send a trade signal to another agent via A2A conversation."""
        import json as json_mod

        signal: dict[str, Any] = {
            "type": "trade_signal",
            "action": action,
            "tokenMint": token_mint,
            "timestamp": __import__("time").time_ns() // 1_000_000,
        }
        if spend_usdc is not None:
            signal["spendUsdc"] = spend_usdc
        if token_amount is not None:
            signal["tokenAmount"] = token_amount
        if slippage_bps is not None:
            signal["slippageBps"] = slippage_bps
        if reason is not None:
            signal["reason"] = reason
        if confidence is not None:
            signal["confidence"] = confidence

        params: dict[str, Any] = {
            "message": {"role": "user", "parts": [{"type": "text", "text": json_mod.dumps(signal)}]},
        }
        if session_id:
            params["sessionId"] = session_id

        return await self._request(
            "POST", f"/a2a/{urlquote(agent_slug)}/",
            headers={**self._auth_headers("a2a"), "Content-Type": "application/json"},
            json={"jsonrpc": "2.0", "method": "message/send", "id": f"signal-{signal['timestamp']}", "params": params},
        )
