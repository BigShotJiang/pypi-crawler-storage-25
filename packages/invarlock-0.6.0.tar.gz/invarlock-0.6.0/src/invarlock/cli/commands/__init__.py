"""CLI command package."""
