"""
Canonical evaluation data entrypoint.

Owns the provider registry and the public eval-data import surface.
"""

from __future__ import annotations

from typing import Any

from invarlock.core.exceptions import ValidationError as _ValErr

from .data_providers import (
    DatasetProvider,
    HFSeq2SeqProvider,
    HFTextProvider,
    LocalJSONLPairsProvider,
    LocalJSONLProvider,
    SyntheticProvider,
    WikiText2Provider,
)
from .data_windows import EvaluationWindow, compute_window_hash
from .providers.seq2seq import Seq2SeqProvider
from .providers.vision_text import VisionTextProvider

_PROVIDERS: dict[str, type[object]] = {
    "wikitext2": WikiText2Provider,
    "synthetic": SyntheticProvider,
    "hf_text": HFTextProvider,
    "local_jsonl": LocalJSONLProvider,
    "seq2seq": Seq2SeqProvider,
    "hf_seq2seq": HFSeq2SeqProvider,
    "local_jsonl_pairs": LocalJSONLPairsProvider,
    "vision_text": VisionTextProvider,
}


def get_provider(name: str, **kwargs: Any) -> DatasetProvider:
    if name not in _PROVIDERS:
        available = ", ".join(_PROVIDERS.keys())
        raise _ValErr(
            code="E308",
            message="PROVIDER-NOT-FOUND: unknown dataset provider",
            details={"provider": name, "available": available},
        )

    provider_class = _PROVIDERS[name]
    init_kwargs = dict(kwargs)
    init_kwargs.pop("emit", None)
    return provider_class(**init_kwargs)  # type: ignore[call-arg,return-value]


def list_providers() -> list[str]:
    return list(_PROVIDERS.keys())


__all__ = [
    "DatasetProvider",
    "EvaluationWindow",
    "HFTextProvider",
    "LocalJSONLProvider",
    "LocalJSONLPairsProvider",
    "SyntheticProvider",
    "VisionTextProvider",
    "WikiText2Provider",
    "compute_window_hash",
    "get_provider",
    "list_providers",
]
