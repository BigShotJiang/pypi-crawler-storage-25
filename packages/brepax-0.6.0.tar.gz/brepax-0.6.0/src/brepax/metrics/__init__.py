"""Differentiable geometric metrics computed from SDF grid integration."""

from brepax.metrics.curvature import (
    max_curvature,
    mean_curvature,
    mean_curvature_per_face,
)
from brepax.metrics.draft_angle import (
    draft_angle_violation,
    integrate_sdf_draft_angle_violation,
    min_draft_angle_per_face,
)
from brepax.metrics.inertia import (
    center_of_mass,
    integrate_sdf_center_of_mass,
    integrate_sdf_moment_of_inertia,
    moment_of_inertia,
)
from brepax.metrics.surface_area import (
    integrate_sdf_surface_area,
    surface_area,
    surface_area_per_face,
)
from brepax.metrics.wall_thickness import (
    integrate_sdf_min_wall_thickness,
    integrate_sdf_thin_wall_volume,
    min_wall_thickness,
    min_wall_thickness_per_face,
    thin_wall_volume,
)

__all__ = [
    "center_of_mass",
    "draft_angle_violation",
    "integrate_sdf_center_of_mass",
    "integrate_sdf_draft_angle_violation",
    "integrate_sdf_min_wall_thickness",
    "integrate_sdf_moment_of_inertia",
    "integrate_sdf_surface_area",
    "integrate_sdf_thin_wall_volume",
    "max_curvature",
    "mean_curvature",
    "mean_curvature_per_face",
    "min_draft_angle_per_face",
    "min_wall_thickness",
    "min_wall_thickness_per_face",
    "moment_of_inertia",
    "surface_area",
    "surface_area_per_face",
    "thin_wall_volume",
]
