"""OIDC identity cache management.

Caches the UserInfo response from possibility.space at
~/.pongogo/identity.json. This is non-sensitive data (name, email,
sub) used by `pongogo whoami` and MCP server startup.

Epic #724: Unified Settings & Auth Storage (Task 3)
"""

from __future__ import annotations

import json
import logging
from typing import Any

from auth.config import IDENTITY_CACHE_PATH, PONGOGO_HOME

logger = logging.getLogger(__name__)


def load_cached_identity() -> dict[str, Any] | None:
    """Load cached OIDC UserInfo from ~/.pongogo/identity.json.

    Returns None if the file doesn't exist or is malformed.
    Called by TokenStore.get_state() and `pongogo whoami`.
    """
    try:
        if IDENTITY_CACHE_PATH.exists():
            return json.loads(IDENTITY_CACHE_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        logger.debug("Failed to load cached identity: %s", exc)
    return None


def save_cached_identity(identity: dict[str, Any]) -> None:
    """Save OIDC UserInfo to ~/.pongogo/identity.json.

    Uses atomic write to prevent partial reads on crash.
    Called after successful login and token refresh.
    """
    from mcp_server.database.connection import atomic_json_write

    PONGOGO_HOME.mkdir(parents=True, exist_ok=True)
    atomic_json_write(IDENTITY_CACHE_PATH, identity)
    logger.debug("Cached identity for %s", identity.get("preferred_username", "?"))


def clear_cached_identity() -> None:
    """Remove cached identity file (logout)."""
    try:
        if IDENTITY_CACHE_PATH.exists():
            IDENTITY_CACHE_PATH.unlink()
            logger.debug("Cleared cached identity")
    except OSError as exc:
        logger.debug("Failed to clear cached identity: %s", exc)
