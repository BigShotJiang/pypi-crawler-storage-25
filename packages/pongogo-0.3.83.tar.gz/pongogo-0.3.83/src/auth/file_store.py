"""File-based token storage fallback.

Used when OS keychain is unavailable (headless Linux, CI, etc.).
Stores tokens in ~/.pongogo/pongogo.db using the existing SQLite
infrastructure.

Tokens are stored with restrictive file permissions (0600 on the DB).
Not as secure as OS keychain — use keychain when available.

Epic #724: Unified Settings & Auth Storage (Task 2)
"""

from __future__ import annotations

import contextlib
import logging
import os
import stat
from datetime import UTC, datetime

from auth.config import PONGOGO_DB_PATH, PONGOGO_HOME
from auth.tokens import TokenStore

logger = logging.getLogger(__name__)

_TABLE = "auth_tokens"


def _ensure_schema(db_path=PONGOGO_DB_PATH) -> None:
    """Create auth_tokens table if it doesn't exist."""
    from mcp_server.database.connection import get_connection

    PONGOGO_HOME.mkdir(parents=True, exist_ok=True)

    with get_connection(db_path) as conn:
        conn.execute(f"""
            CREATE TABLE IF NOT EXISTS {_TABLE} (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)

    # Restrict file permissions (owner read/write only)
    with contextlib.suppress(OSError):
        os.chmod(db_path, stat.S_IRUSR | stat.S_IWUSR)


class FileTokenStore(TokenStore):
    """Token storage backed by ~/.pongogo/pongogo.db.

    Fallback for systems without a usable OS keychain.
    Stores tokens in a SQLite table with restrictive file permissions.
    """

    def __init__(self, db_path=PONGOGO_DB_PATH):
        self._db_path = db_path
        _ensure_schema(self._db_path)

    def store(
        self,
        access_token: str,
        refresh_token: str | None = None,
        expires_at: datetime | None = None,
    ) -> None:
        """Store tokens in SQLite."""
        from mcp_server.database.connection import get_connection

        now = datetime.now(UTC).isoformat()

        with get_connection(self._db_path) as conn:
            conn.execute(
                f"INSERT OR REPLACE INTO {_TABLE} (key, value, updated_at) "
                "VALUES (?, ?, ?)",
                ("access_token", access_token, now),
            )
            if refresh_token is not None:
                conn.execute(
                    f"INSERT OR REPLACE INTO {_TABLE} (key, value, updated_at) "
                    "VALUES (?, ?, ?)",
                    ("refresh_token", refresh_token, now),
                )
            if expires_at is not None:
                conn.execute(
                    f"INSERT OR REPLACE INTO {_TABLE} (key, value, updated_at) "
                    "VALUES (?, ?, ?)",
                    ("expires_at", expires_at.isoformat(), now),
                )

        logger.debug("Stored tokens in file store")

    def retrieve(self) -> tuple[str | None, str | None, datetime | None]:
        """Retrieve tokens from SQLite."""
        from mcp_server.database.connection import get_connection

        if not self._db_path.exists():
            return None, None, None

        with get_connection(self._db_path, readonly=True) as conn:
            # Check table exists
            table_check = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                (_TABLE,),
            ).fetchone()
            if not table_check:
                return None, None, None

            rows = conn.execute(
                f"SELECT key, value FROM {_TABLE} WHERE key IN (?, ?, ?)",
                ("access_token", "refresh_token", "expires_at"),
            ).fetchall()

        tokens: dict[str, str] = {row["key"]: row["value"] for row in rows}

        access_token = tokens.get("access_token")
        refresh_token = tokens.get("refresh_token")

        expires_at = None
        if "expires_at" in tokens:
            try:
                expires_at = datetime.fromisoformat(tokens["expires_at"])
            except ValueError:
                logger.debug("Invalid expires_at in file store")

        return access_token, refresh_token, expires_at

    def clear(self) -> None:
        """Remove all tokens from SQLite."""
        from mcp_server.database.connection import get_connection

        if not self._db_path.exists():
            return

        with get_connection(self._db_path) as conn:
            table_check = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                (_TABLE,),
            ).fetchone()
            if table_check:
                conn.execute(f"DELETE FROM {_TABLE}")

        logger.debug("Cleared all tokens from file store")
