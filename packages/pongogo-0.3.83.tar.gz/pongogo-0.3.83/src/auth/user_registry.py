"""Client for the Pongogo User Registry API.

Fetches roles/groups from the central user database and upserts
user records on login. Falls back gracefully if the API is unreachable.

#729: CLI Identity Layer Enhancement + User Registry
"""

from __future__ import annotations

import hashlib
import json
import logging
import urllib.error
import urllib.request

from auth.config import USER_REGISTRY_API_URL

logger = logging.getLogger(__name__)

_TIMEOUT = 5  # seconds — fail fast for CLI responsiveness


def _api_url(path: str) -> str:
    """Build full API URL."""
    base = USER_REGISTRY_API_URL.rstrip("/")
    return f"{base}{path}"


def fetch_user_roles(sub: str) -> tuple[list[str], list[str]] | None:
    """Fetch cli_roles and groups from the user registry.

    Returns (cli_roles, groups) or None if unreachable/not found.
    """
    try:
        req = urllib.request.Request(
            _api_url(f"/users/{sub}/roles"),
            headers={"User-Agent": "pongogo-cli/0.1"},
        )
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            data = json.loads(resp.read())
            return data.get("cli_roles", []), data.get("groups", [])
    except urllib.error.HTTPError as e:
        if e.code == 404:
            logger.debug("User %s not in registry (404)", sub)
        else:
            logger.debug("Registry API error: %s %s", e.code, e.reason)
        return None
    except Exception as e:
        logger.debug("Registry API unreachable: %s", e)
        return None


def upsert_user_on_login(
    sub: str,
    email: str | None = None,
    display_name: str | None = None,
    preferred_username: str | None = None,
    access_token: str | None = None,
) -> tuple[list[str], list[str]] | None:
    """Register or update user in the registry on login.

    Returns (cli_roles, groups) or None if unreachable.
    """
    body: dict = {"sub": sub}
    if email:
        body["email"] = email
    if display_name:
        body["display_name"] = display_name
    if preferred_username:
        body["preferred_username"] = preferred_username
    if access_token:
        body["last_token_hash"] = hashlib.sha256(access_token.encode()).hexdigest()

    try:
        data = json.dumps(body).encode()
        req = urllib.request.Request(
            _api_url("/users"),
            data=data,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "pongogo-cli/0.1",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            result = json.loads(resp.read())
            return result.get("cli_roles", []), result.get("groups", [])
    except Exception as e:
        logger.debug("Registry upsert failed: %s", e)
        return None
