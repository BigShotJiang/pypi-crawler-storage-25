"""JWT verification against possibility.space JWKS.

Validates access tokens by fetching public keys from the JWKS endpoint
and verifying JWT signature (RS256), issuer, and expiry.

JWKS keys are cached in memory with a configurable TTL to avoid
hitting the endpoint on every verification.

Epic #722: MCP Server Auth Gate (Task 1)
"""

from __future__ import annotations

import logging
import threading
from typing import Any

import jwt
from jwt import PyJWKClient

from auth.config import JWKS_URL, OIDC_ISSUER

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# JWKS cache
# ---------------------------------------------------------------------------

_jwks_client: PyJWKClient | None = None
_jwks_lock = threading.Lock()

# Cache TTL in seconds — how often to refetch JWKS keys.
# Keycloak rotates keys infrequently; 1 hour is conservative.
JWKS_CACHE_TTL = 3600


def _get_jwks_client() -> PyJWKClient:
    """Get or create the cached PyJWKClient.

    Thread-safe singleton. PyJWKClient handles its own key caching
    internally via lifespan parameter.
    """
    global _jwks_client
    if _jwks_client is not None:
        return _jwks_client

    with _jwks_lock:
        if _jwks_client is not None:
            return _jwks_client
        _jwks_client = PyJWKClient(JWKS_URL, lifespan=JWKS_CACHE_TTL)
        logger.debug("Created JWKS client for %s", JWKS_URL)
        return _jwks_client


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class JWTVerificationError(Exception):
    """Base error for JWT verification failures."""


class JWTExpiredError(JWTVerificationError):
    """Token has expired."""


class JWTInvalidError(JWTVerificationError):
    """Token is invalid (bad signature, issuer, etc.)."""


class JWKSFetchError(JWTVerificationError):
    """Could not fetch JWKS keys from the auth server."""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def verify_jwt(token: str, audience: str | None = None) -> dict[str, Any]:
    """Verify a JWT access token against possibility.space JWKS.

    Validates:
    - Signature (RS256 via JWKS public key)
    - Issuer matches OIDC_ISSUER
    - Token is not expired
    - Audience (if specified)

    Args:
        token: The JWT access token string.
        audience: Expected audience claim. If None, audience is not checked.
            Keycloak access tokens use ``aud`` for the client or ``account``.

    Returns:
        Decoded JWT claims as a dict.

    Raises:
        JWTExpiredError: Token has expired.
        JWTInvalidError: Signature, issuer, or other validation failed.
        JWKSFetchError: Could not reach JWKS endpoint.
    """
    try:
        client = _get_jwks_client()
        signing_key = client.get_signing_key_from_jwt(token)
    except jwt.PyJWKClientConnectionError as e:
        raise JWKSFetchError(
            f"Cannot reach auth server to verify token. "
            f"Check your network connection. ({e})"
        ) from e
    except jwt.PyJWKClientError as e:
        raise JWTInvalidError(f"Could not find matching key for token: {e}") from e
    except Exception as e:
        raise JWKSFetchError(f"JWKS key fetch failed: {e}") from e

    decode_options: dict[str, Any] = {}
    if audience is None:
        # Keycloak access tokens don't always have a predictable audience.
        # Skip audience validation unless explicitly requested.
        decode_options["verify_aud"] = False

    try:
        claims = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            issuer=OIDC_ISSUER,
            audience=audience,
            options=decode_options,
        )
        logger.debug(
            "JWT verified: sub=%s, iss=%s",
            claims.get("sub"),
            claims.get("iss"),
        )
        return claims
    except jwt.ExpiredSignatureError as e:
        raise JWTExpiredError("Access token has expired.") from e
    except jwt.InvalidIssuerError as e:
        raise JWTInvalidError(f"Token issuer mismatch. Expected {OIDC_ISSUER}.") from e
    except jwt.InvalidSignatureError as e:
        raise JWTInvalidError("Token signature is invalid.") from e
    except jwt.DecodeError as e:
        raise JWTInvalidError(f"Token is malformed: {e}") from e
    except jwt.InvalidTokenError as e:
        raise JWTInvalidError(f"Token validation failed: {e}") from e


def reset_jwks_cache() -> None:
    """Clear the cached JWKS client, forcing a refetch on next verification.

    Useful after key rotation or when troubleshooting auth failures.
    """
    global _jwks_client
    with _jwks_lock:
        _jwks_client = None
        logger.debug("JWKS cache cleared")
