"""Auth configuration constants.

Central location for OIDC endpoints, paths, and auth-related
configuration shared across CLI and MCP server.

Epic #724: Unified Settings & Auth Storage
"""

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# User-level directory
# ---------------------------------------------------------------------------

PONGOGO_HOME = Path.home() / ".pongogo"
"""Canonical user-level directory for all Pongogo state.

Contains pongogo.db (installations, tutorial, settings),
identity.json (cached OIDC user info), and future session state.
Not XDG-compliant by design — single root simplifies CRDT sync.
"""

IDENTITY_CACHE_PATH = PONGOGO_HOME / "identity.json"
"""Cached OIDC UserInfo response (non-sensitive)."""

PONGOGO_DB_PATH = PONGOGO_HOME / "pongogo.db"
"""Consolidated user-level SQLite database."""

# ---------------------------------------------------------------------------
# OIDC / possibility.space endpoints
# ---------------------------------------------------------------------------
# Override all endpoints by setting PONGOGO_OIDC_ISSUER to a full issuer URL.
# Example: PONGOGO_OIDC_ISSUER=https://auth.possibility.space/realms/pspace-pongogo
# This derives all OIDC endpoints from the issuer, bypassing auth.pongogo.com
# if the custom domain proxy is unavailable.
# ---------------------------------------------------------------------------

_OIDC_ISSUER_OVERRIDE = os.environ.get("PONGOGO_OIDC_ISSUER")
_OIDC_BASE = (
    f"{_OIDC_ISSUER_OVERRIDE}/protocol/openid-connect"
    if _OIDC_ISSUER_OVERRIDE
    else None
)

OIDC_ISSUER = _OIDC_ISSUER_OVERRIDE or "https://auth.pongogo.com/realms/pspace-pongogo"
"""OIDC issuer — used for JWT validation (iss claim)."""

OIDC_DISCOVERY_URL = (
    f"{_OIDC_ISSUER_OVERRIDE}/.well-known/openid-configuration"
    if _OIDC_ISSUER_OVERRIDE
    else "https://auth.pongogo.com/.well-known/openid-configuration"
)
"""Standard OIDC discovery endpoint."""

DEVICE_AUTH_URL = (
    f"{_OIDC_BASE}/auth/device"
    if _OIDC_BASE
    else "https://auth.pongogo.com/oauth/auth/device"
)
"""Device Authorization endpoint (RFC 8628)."""

TOKEN_URL = (
    f"{_OIDC_BASE}/token" if _OIDC_BASE else "https://auth.pongogo.com/oauth/token"
)
"""Token endpoint — used for device code polling and refresh."""

USERINFO_URL = (
    f"{_OIDC_BASE}/userinfo"
    if _OIDC_BASE
    else "https://auth.pongogo.com/oauth/userinfo"
)
"""UserInfo endpoint — returns authenticated user profile."""

JWKS_URL = (
    f"{_OIDC_BASE}/certs" if _OIDC_BASE else "https://auth.pongogo.com/oauth/certs"
)
"""JWKS endpoint — public keys for JWT verification."""

LOGOUT_URL = (
    f"{_OIDC_BASE}/logout" if _OIDC_BASE else "https://auth.pongogo.com/oauth/logout"
)
"""End Session (logout) endpoint."""

AUTH_DOMAIN = "auth.pongogo.com"
"""Custom auth domain (Pongogo-branded login page)."""

# Registration: No standalone URL — Keycloak login page has Sign In / Sign Up tabs.
# `pongogo register` runs the device code flow; user clicks Sign Up on the page.
# Custom auth pages tracked in #732.

# ---------------------------------------------------------------------------
# Token configuration
# ---------------------------------------------------------------------------

KEYRING_SERVICE = "pongogo"
"""Service name used in OS keychain (macOS Keychain, etc.)."""

KEYRING_ACCOUNT_ACCESS = "access_token"
"""Keychain account key for the OIDC access token."""

KEYRING_ACCOUNT_REFRESH = "refresh_token"
"""Keychain account key for the OIDC refresh token."""

DEVICE_CODE_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code"
"""Grant type for device code flow (RFC 8628)."""

CLIENT_ID = "pongogo"
"""OIDC client ID for device code flow (CLI) and authorization code flow (Laran).

This is the single Pongogo client provisioned in possibility.space Keycloak
with device authorization grant and authorization code + PKCE enabled.
Realm roles: organizer, member.
"""

DEFAULT_SCOPES = "openid profile email pongogo-api"
"""Default OIDC scopes requested during login.

Matches the auto-assigned client scopes from possibility.space provisioning:
- openid: required for OIDC, returns ID token
- profile: name, preferred_username in ID token
- email: email, email_verified in ID token
- pongogo-api: Pongogo-specific claims (pspace_id, roles)

Source: possibility.space integration guide (recommended_scopes)
"""

# ---------------------------------------------------------------------------
# User Registry API (Azure PostgreSQL-backed)
# ---------------------------------------------------------------------------

USER_REGISTRY_API_URL = "https://users.pongogo.com/v1"
"""User registry API base URL (FastAPI service).

Serves role resolution, subscription info, and account metadata.
CLI calls this after login to merge DB roles with token claims.
Falls back gracefully if unreachable (offline mode = token claims only).
"""
