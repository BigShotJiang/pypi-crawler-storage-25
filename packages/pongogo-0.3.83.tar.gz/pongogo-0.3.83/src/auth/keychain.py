"""Keychain-backed token storage.

Primary token store using OS keychain via the `keyring` library.
Supports macOS Keychain, Linux Secret Service, and Windows
Credential Locker.

Epic #724: Unified Settings & Auth Storage (Task 2)
"""

from __future__ import annotations

import contextlib
import logging
from datetime import datetime

import keyring
import keyring.errors

from auth.config import (
    KEYRING_ACCOUNT_ACCESS,
    KEYRING_ACCOUNT_REFRESH,
    KEYRING_SERVICE,
)
from auth.tokens import TokenStore

logger = logging.getLogger(__name__)

_EXPIRES_ACCOUNT = "expires_at"


class KeychainTokenStore(TokenStore):
    """Token storage backed by OS keychain.

    Stores access_token, refresh_token, and expires_at as separate
    keychain entries under the 'pongogo' service name.

    macOS: Uses Keychain Access (login keychain)
    Linux: Uses Secret Service (GNOME Keyring / KWallet)
    Windows: Uses Windows Credential Locker
    """

    def store(
        self,
        access_token: str,
        refresh_token: str | None = None,
        expires_at: datetime | None = None,
    ) -> None:
        """Store tokens in OS keychain.

        Raises keyring.errors.NoKeyringError if no backend is available.
        Callers (login flow) should catch this and suggest alternatives.
        """
        keyring.set_password(KEYRING_SERVICE, KEYRING_ACCOUNT_ACCESS, access_token)
        logger.debug("Stored access token in keychain")

        if refresh_token is not None:
            keyring.set_password(
                KEYRING_SERVICE, KEYRING_ACCOUNT_REFRESH, refresh_token
            )
            logger.debug("Stored refresh token in keychain")

        if expires_at is not None:
            keyring.set_password(
                KEYRING_SERVICE, _EXPIRES_ACCOUNT, expires_at.isoformat()
            )

    def retrieve(self) -> tuple[str | None, str | None, datetime | None]:
        """Retrieve tokens from OS keychain.

        Returns (None, None, None) if no keyring backend is available
        (headless Linux, Docker containers, CI environments).
        """
        try:
            access_token = keyring.get_password(KEYRING_SERVICE, KEYRING_ACCOUNT_ACCESS)
            refresh_token = keyring.get_password(
                KEYRING_SERVICE, KEYRING_ACCOUNT_REFRESH
            )
        except keyring.errors.NoKeyringError:
            logger.debug("No keyring backend available — treating as unauthenticated")
            return None, None, None

        expires_at = None
        expires_str = keyring.get_password(KEYRING_SERVICE, _EXPIRES_ACCOUNT)
        if expires_str:
            try:
                expires_at = datetime.fromisoformat(expires_str)
            except ValueError:
                logger.debug("Invalid expires_at in keychain: %s", expires_str)

        return access_token, refresh_token, expires_at

    def clear(self) -> None:
        """Remove all tokens from OS keychain."""
        for account in (
            KEYRING_ACCOUNT_ACCESS,
            KEYRING_ACCOUNT_REFRESH,
            _EXPIRES_ACCOUNT,
        ):
            with contextlib.suppress(keyring.errors.PasswordDeleteError):
                keyring.delete_password(KEYRING_SERVICE, account)
        logger.debug("Cleared all tokens from keychain")


def keychain_available() -> bool:
    """Check if a usable keychain backend is available.

    Returns False if the system has no keychain (headless Linux,
    CI environments, etc.) or if keyring falls back to a plaintext
    or null backend.
    """
    try:
        backend = keyring.get_keyring()
        backend_name = type(backend).__name__
        # Reject known non-secure backends
        if backend_name in ("PlaintextKeyring", "NullKeyring", "ChainerBackend"):
            logger.debug("Keyring backend '%s' is not secure", backend_name)
            return False
        return True
    except Exception:
        return False
