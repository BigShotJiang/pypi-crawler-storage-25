"""OAuth 2.0 Device Authorization Grant (RFC 8628).

Implements the device code flow for CLI authentication against
possibility.space Keycloak. Used by `pongogo login`.

Flow:
1. POST /auth/device → get device_code, user_code, verification_uri
2. Display URI + code to user, open browser
3. Poll POST /token with device_code until user approves
4. On success, return tokens (access + refresh + expiry)

Epic #721: CLI Device Code Auth Flow (Task 1)
"""

from __future__ import annotations

import json
import logging
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any

from auth.config import (
    CLIENT_ID,
    DEFAULT_SCOPES,
    DEVICE_AUTH_URL,
    DEVICE_CODE_GRANT_TYPE,
    TOKEN_URL,
    USERINFO_URL,
)

logger = logging.getLogger(__name__)

# Cloudflare (error 1010) blocks Python's default User-Agent.
# Use a descriptive but non-bot UA to avoid WAF rejection.
_USER_AGENT = "pongogo-cli/0.1 (device-code-flow)"


class DeviceFlowError(Exception):
    """Base error for device code flow failures."""


class DeviceCodeExpired(DeviceFlowError):
    """The device code expired before user authorized."""


class DeviceCodeDenied(DeviceFlowError):
    """User explicitly denied the authorization request."""


@dataclass
class DeviceCodeResponse:
    """Response from the device authorization endpoint."""

    device_code: str
    user_code: str
    verification_uri: str
    verification_uri_complete: str | None
    expires_in: int
    interval: int


@dataclass
class TokenResponse:
    """Tokens returned after successful authorization."""

    access_token: str
    refresh_token: str | None
    expires_in: int
    token_type: str


_MAX_RETRIES = 3


def _retry_on_429(url: str, req: urllib.request.Request) -> Any:
    """Execute request with retry on HTTP 429 (rate limited).

    Respects ``Retry-After`` header if present, otherwise uses exponential
    backoff (1s, 2s, 4s). Raises after ``_MAX_RETRIES`` attempts.
    """
    for attempt in range(_MAX_RETRIES):
        try:
            return urllib.request.urlopen(req, timeout=30)
        except urllib.error.HTTPError as e:
            if e.code == 429:
                retry_after = int(e.headers.get("Retry-After", 2**attempt))
                logger.warning(
                    "Rate limited by %s (attempt %d/%d), retrying in %ds",
                    url,
                    attempt + 1,
                    _MAX_RETRIES,
                    retry_after,
                )
                time.sleep(retry_after)
                # Rebuild request (urllib consumes the data on first attempt)
                req = urllib.request.Request(
                    req.full_url,
                    data=req.data,
                    headers=dict(req.headers),
                )
                continue
            raise
    raise DeviceFlowError(f"Rate limited by {url} after {_MAX_RETRIES} retries")


def _post_form(url: str, data: dict[str, str]) -> dict[str, Any]:
    """POST application/x-www-form-urlencoded and parse JSON response."""
    encoded = urllib.parse.urlencode(data).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=encoded,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": _USER_AGENT,
        },
    )
    with _retry_on_429(url, req) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _post_form_allow_error(url: str, data: dict[str, str]) -> dict[str, Any]:
    """POST form data, return JSON body even on HTTP 4xx errors.

    The token endpoint returns 400 with JSON body during polling
    (authorization_pending, slow_down). We need the body, not an exception.
    Retries on HTTP 429 (rate limiting).
    """
    encoded = urllib.parse.urlencode(data).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=encoded,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": _USER_AGENT,
        },
    )
    try:
        with _retry_on_429(url, req) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        try:
            return json.loads(body)
        except json.JSONDecodeError:
            raise DeviceFlowError(f"HTTP {e.code}: {body}") from e


def request_device_code(
    client_id: str = CLIENT_ID,
    scope: str = DEFAULT_SCOPES,
) -> DeviceCodeResponse:
    """Request a device code from the authorization server.

    POST to the device authorization endpoint with client_id and scope.
    Returns device_code, user_code, and verification_uri for display.

    Args:
        client_id: OIDC client identifier.
        scope: Space-separated OIDC scopes.

    Returns:
        DeviceCodeResponse with codes and URIs.

    Raises:
        DeviceFlowError: On network or server error.
    """
    try:
        data = _post_form(
            DEVICE_AUTH_URL,
            {"client_id": client_id, "scope": scope},
        )
    except urllib.error.URLError as e:
        raise DeviceFlowError(f"Failed to reach auth server: {e}") from e

    return DeviceCodeResponse(
        device_code=data["device_code"],
        user_code=data["user_code"],
        verification_uri=data.get("verification_uri", data.get("verification_url", "")),
        verification_uri_complete=data.get("verification_uri_complete"),
        expires_in=data.get("expires_in", 600),
        interval=data.get("interval", 5),
    )


def poll_for_token(
    device_code: str,
    client_id: str = CLIENT_ID,
    interval: int = 5,
    expires_in: int = 600,
    on_poll: Any = None,
) -> TokenResponse:
    """Poll the token endpoint until user authorizes or code expires.

    Implements the polling loop from RFC 8628 Section 3.4-3.5.
    Handles authorization_pending, slow_down, expired_token, and
    access_denied responses.

    Args:
        device_code: The device code from request_device_code().
        client_id: OIDC client identifier.
        interval: Polling interval in seconds (from device code response).
        expires_in: Seconds until code expires (from device code response).
        on_poll: Optional callback called each poll iteration (for UI updates).

    Returns:
        TokenResponse with access and refresh tokens.

    Raises:
        DeviceCodeExpired: Code expired before user authorized.
        DeviceCodeDenied: User denied the request.
        DeviceFlowError: On unexpected error.
    """
    deadline = time.monotonic() + expires_in
    poll_interval = interval

    while time.monotonic() < deadline:
        time.sleep(poll_interval)

        if on_poll is not None:
            on_poll()

        try:
            data = _post_form_allow_error(
                TOKEN_URL,
                {
                    "grant_type": DEVICE_CODE_GRANT_TYPE,
                    "device_code": device_code,
                    "client_id": client_id,
                },
            )
        except DeviceFlowError:
            raise
        except Exception as e:
            logger.debug("Poll error (will retry): %s", e)
            continue

        error = data.get("error")

        if error is None and "access_token" in data:
            # Success
            return TokenResponse(
                access_token=data["access_token"],
                refresh_token=data.get("refresh_token"),
                expires_in=data.get("expires_in", 300),
                token_type=data.get("token_type", "Bearer"),
            )

        if error == "authorization_pending":
            continue

        if error == "slow_down":
            poll_interval += 5
            logger.debug("Slowing down poll interval to %ds", poll_interval)
            continue

        if error == "expired_token":
            raise DeviceCodeExpired("Device code expired. Please try again.")

        if error == "access_denied":
            raise DeviceCodeDenied("Authorization was denied.")

        # Unknown error
        description = data.get("error_description", error)
        raise DeviceFlowError(f"Authorization failed: {description}")

    raise DeviceCodeExpired("Device code expired (timeout). Please try again.")


def refresh_access_token(
    refresh_token: str,
    client_id: str = CLIENT_ID,
) -> TokenResponse:
    """Refresh an access token using the refresh token.

    Args:
        refresh_token: The OIDC refresh token.
        client_id: OIDC client identifier.

    Returns:
        TokenResponse with new access and refresh tokens.

    Raises:
        DeviceFlowError: On network or auth error.
    """
    try:
        data = _post_form_allow_error(
            TOKEN_URL,
            {
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "client_id": client_id,
            },
        )
    except urllib.error.URLError as e:
        raise DeviceFlowError(f"Failed to reach auth server: {e}") from e

    if "error" in data:
        description = data.get("error_description", data["error"])
        raise DeviceFlowError(f"Token refresh failed: {description}")

    return TokenResponse(
        access_token=data["access_token"],
        refresh_token=data.get("refresh_token", refresh_token),
        expires_in=data.get("expires_in", 300),
        token_type=data.get("token_type", "Bearer"),
    )


def fetch_userinfo(access_token: str) -> dict[str, Any]:
    """Fetch user profile from the OIDC UserInfo endpoint.

    Args:
        access_token: Valid OIDC access token.

    Returns:
        Dict with user info (sub, name, email, preferred_username, etc.)

    Raises:
        DeviceFlowError: On network or auth error.
    """
    req = urllib.request.Request(
        USERINFO_URL,
        headers={
            "Authorization": f"Bearer {access_token}",
            "User-Agent": _USER_AGENT,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 401:
            raise DeviceFlowError("Access token is invalid or expired.") from e
        raise DeviceFlowError(f"UserInfo request failed: HTTP {e.code}") from e
    except urllib.error.URLError as e:
        raise DeviceFlowError(f"Failed to reach UserInfo endpoint: {e}") from e
