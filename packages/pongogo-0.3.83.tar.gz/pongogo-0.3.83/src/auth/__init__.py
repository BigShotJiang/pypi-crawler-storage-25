"""Pongogo shared auth module.

Cross-tool authentication for CLI and MCP server. Provides token
management, identity caching, and auth state queries against the
possibility.space OIDC backend.

Epic #724: Unified Settings & Auth Storage
Milestone P11: Auth & Identity
"""

from auth.config import PONGOGO_HOME
from auth.identity import (
    clear_cached_identity,
    load_cached_identity,
    save_cached_identity,
)
from auth.jwt_verify import (
    JWKSFetchError,
    JWTExpiredError,
    JWTInvalidError,
    JWTVerificationError,
    verify_jwt,
)
from auth.tokens import AuthState, TokenStore, get_token_store

__all__ = [
    "AuthState",
    "JWKSFetchError",
    "JWTExpiredError",
    "JWTInvalidError",
    "JWTVerificationError",
    "PONGOGO_HOME",
    "TokenStore",
    "clear_cached_identity",
    "get_token_store",
    "load_cached_identity",
    "save_cached_identity",
    "verify_jwt",
]
