"""Token storage interface and auth state.

Defines the abstract TokenStore interface and AuthState dataclass.
Concrete implementations (keychain, file fallback) are in separate
modules added by Task 2.

Epic #724: Unified Settings & Auth Storage
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class AuthState:
    """Current authentication state.

    Represents the full auth context: tokens, identity, and metadata.
    Created by TokenStore.get_state() and consumed by CLI commands
    and MCP server auth gate.
    """

    authenticated: bool = False
    access_token: str | None = None
    refresh_token: str | None = None
    expires_at: datetime | None = None
    identity: dict[str, Any] | None = None
    """Cached OIDC UserInfo (sub, name, email, preferred_username, roles)."""
    error: str | None = None
    """Human-readable error if auth failed (e.g., 'Token expired')."""

    # Resolved roles/groups from DB (populated by user registry fetch)
    _db_cli_roles: list[str] | None = None
    _db_groups: list[str] | None = None

    @property
    def cli_roles(self) -> list[str]:
        """Client roles for pongogo-cli.

        Resolution order: DB roles (if fetched) → token claims → empty list.
        DB roles take precedence because they allow manual override
        before possibility.space provisions claims in tokens.
        """
        if self._db_cli_roles is not None:
            return self._db_cli_roles
        if self.identity is None:
            return []
        resource_access = self.identity.get("resource_access", {})
        cli_access = resource_access.get("pongogo-cli", {})
        return cli_access.get("roles", [])

    @property
    def groups(self) -> list[str]:
        """Group memberships.

        Resolution order: DB groups (if fetched) → token claims → empty list.
        """
        if self._db_groups is not None:
            return self._db_groups
        if self.identity is None:
            return []
        return self.identity.get("groups", [])

    @property
    def is_expired(self) -> bool:
        """Check if the access token has expired."""
        if self.expires_at is None:
            return False
        return datetime.now(UTC) >= self.expires_at

    @property
    def display_name(self) -> str | None:
        """User's display name from identity, if available."""
        if self.identity is None:
            return None
        return (
            self.identity.get("name")
            or self.identity.get("preferred_username")
            or self.identity.get("email")
        )

    @property
    def email(self) -> str | None:
        """User's email from identity, if available."""
        if self.identity is None:
            return None
        return self.identity.get("email")

    @property
    def subject(self) -> str | None:
        """OIDC subject identifier (unique user ID)."""
        if self.identity is None:
            return None
        return self.identity.get("sub")


class TokenStore(ABC):
    """Abstract interface for token storage.

    Implementations:
    - KeychainTokenStore: OS keychain (macOS Keychain, Linux Secret Service)
    - FileTokenStore: Fallback using ~/.pongogo/pongogo.db

    Both implementations will be added in Task 2 (Keychain integration).
    """

    @abstractmethod
    def store(
        self,
        access_token: str,
        refresh_token: str | None = None,
        expires_at: datetime | None = None,
    ) -> None:
        """Store tokens after successful authentication.

        Args:
            access_token: OIDC access token (JWT).
            refresh_token: OIDC refresh token (opaque).
            expires_at: When the access token expires.
        """

    @abstractmethod
    def retrieve(self) -> tuple[str | None, str | None, datetime | None]:
        """Retrieve stored tokens.

        Returns:
            Tuple of (access_token, refresh_token, expires_at).
            Any value may be None if not stored.
        """

    @abstractmethod
    def clear(self) -> None:
        """Clear all stored tokens (logout)."""

    def get_state(self) -> AuthState:
        """Build full AuthState from stored tokens + cached identity.

        This is the primary entry point for checking auth status.
        Both CLI and MCP server call this.
        """
        access_token, refresh_token, expires_at = self.retrieve()

        if access_token is None:
            return AuthState(
                authenticated=False,
                error="Not logged in. Run 'pongogo login' to authenticate.",
            )

        from auth.identity import load_cached_identity

        identity = load_cached_identity()

        state = AuthState(
            authenticated=True,
            access_token=access_token,
            refresh_token=refresh_token,
            expires_at=expires_at,
            identity=identity,
        )

        if state.is_expired and refresh_token:
            # Attempt silent refresh before reporting expired
            refreshed = self._try_refresh(refresh_token)
            if refreshed is not None:
                return refreshed
            state.error = "Token expired. Run 'pongogo login' to re-authenticate."
        elif state.is_expired:
            state.error = "Token expired. Run 'pongogo login' to re-authenticate."

        return state

    def _try_refresh(self, refresh_token: str) -> AuthState | None:
        """Attempt silent token refresh. Returns new AuthState or None on failure."""
        try:
            from datetime import timedelta

            from auth.device_flow import refresh_access_token
            from auth.identity import load_cached_identity

            token = refresh_access_token(refresh_token)
            expires_at = datetime.now(UTC) + timedelta(seconds=token.expires_in)
            self.store(token.access_token, token.refresh_token, expires_at)
            logger.debug("Silently refreshed access token")

            identity = load_cached_identity()
            return AuthState(
                authenticated=True,
                access_token=token.access_token,
                refresh_token=token.refresh_token,
                expires_at=expires_at,
                identity=identity,
            )
        except Exception as exc:
            logger.debug("Silent refresh failed: %s", exc)
            return None


def get_token_store() -> TokenStore:
    """Get the appropriate TokenStore implementation.

    Tries OS keychain first, falls back to file-based storage.
    """
    from auth.keychain import KeychainTokenStore, keychain_available

    if keychain_available():
        logger.debug("Using keychain token store")
        return KeychainTokenStore()

    from auth.file_store import FileTokenStore

    logger.debug("Keychain unavailable, using file token store")
    return FileTokenStore()
