"""
Copilot Instruction Ingestion Job (Issue #712).

Scans `.github/instructions/` to discover knowledge that exists in Copilot's
instruction space but not in Pongogo's `.pongogo/instructions/`. Surfaces
discoveries as PI entries for user triage.

Design principles:
- Read-only: Never modifies `.github/instructions/` files
- Diff-based: Tracks last scan timestamp to avoid re-processing
- Content dedup: Fuzzy matching against existing Pongogo instructions
- PI integration: Discoveries logged for triage
"""

import hashlib
import json
import logging
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

GITHUB_INSTRUCTIONS_DIR = ".github/instructions"
PONGOGO_INSTRUCTIONS_DIR = ".pongogo/instructions"
SCAN_STATE_FILE = ".pongogo/ingestion_state.json"

# File patterns to scan
INSTRUCTION_PATTERNS = ["*.instructions.md", "*.md"]


def scan_github_instructions(project_root: Path) -> list[dict]:
    """Scan .github/instructions/ for instruction files.

    Returns a list of dicts with file metadata:
    - path: relative path from project root
    - name: filename without extension
    - content_hash: SHA-256 of content (for change detection)
    - size: file size in bytes
    """
    github_dir = project_root / GITHUB_INSTRUCTIONS_DIR
    if not github_dir.exists():
        return []

    files = []
    seen = set()
    for pattern in INSTRUCTION_PATTERNS:
        for path in github_dir.rglob(pattern):
            if path in seen or not path.is_file():
                continue
            seen.add(path)
            content = path.read_text(encoding="utf-8")
            files.append(
                {
                    "path": str(path.relative_to(project_root)),
                    "abs_path": str(path),
                    "name": path.stem,
                    "content_hash": hashlib.sha256(content.encode()).hexdigest(),
                    "size": len(content),
                    "content": content,
                }
            )

    return files


def scan_pongogo_instructions(project_root: Path) -> list[dict]:
    """Scan .pongogo/instructions/ for existing instruction files.

    Returns list of dicts with name and content for comparison.
    """
    pongogo_dir = project_root / PONGOGO_INSTRUCTIONS_DIR
    if not pongogo_dir.exists():
        return []

    files = []
    for path in pongogo_dir.rglob("*.instructions.md"):
        if not path.is_file():
            continue
        content = path.read_text(encoding="utf-8")
        files.append(
            {
                "path": str(path.relative_to(project_root)),
                "name": path.stem,
                "content": content,
            }
        )

    # Also scan plain .md files
    for path in pongogo_dir.rglob("*.md"):
        if not path.is_file() or path.suffix != ".md":
            continue
        rel = str(path.relative_to(project_root))
        if any(f["path"] == rel for f in files):
            continue
        content = path.read_text(encoding="utf-8")
        files.append(
            {
                "path": rel,
                "name": path.stem,
                "content": content,
            }
        )

    return files


def find_duplicates(github_file: dict, pongogo_files: list[dict]) -> dict | None:
    """Check if a GitHub instruction file duplicates a Pongogo instruction.

    Uses name similarity and content overlap to detect duplicates.
    Returns the matching Pongogo file dict if found, None otherwise.
    """
    github_name = github_file["name"].lower().replace("-", "_").replace(" ", "_")
    github_content = github_file["content"].strip().lower()

    for pf in pongogo_files:
        pongogo_name = pf["name"].lower().replace("-", "_").replace(" ", "_")

        # Exact name match
        if github_name == pongogo_name:
            return pf

        # Name contained in the other
        if github_name in pongogo_name or pongogo_name in github_name:
            return pf

        # Content overlap: if >60% of GitHub file content appears in Pongogo file
        if len(github_content) > 50:
            pongogo_content = pf["content"].strip().lower()
            # Simple line-based overlap check
            github_lines = set(github_content.splitlines())
            pongogo_lines = set(pongogo_content.splitlines())
            if github_lines and pongogo_lines:
                overlap = len(github_lines & pongogo_lines) / len(github_lines)
                if overlap > 0.6:
                    return pf

    return None


def load_scan_state(project_root: Path) -> dict:
    """Load previous scan state (timestamps and hashes)."""
    state_path = project_root / SCAN_STATE_FILE
    if not state_path.exists():
        return {"last_scan": None, "scanned_hashes": {}}
    try:
        return json.loads(state_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {"last_scan": None, "scanned_hashes": {}}


def save_scan_state(project_root: Path, state: dict) -> None:
    """Save scan state for diff-based re-scanning."""
    state_path = project_root / SCAN_STATE_FILE
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")


def _find_pi_by_context(pi_system: object, context: str) -> str | None:
    """Find an existing PI by its context field. Returns PI ID or None."""
    try:
        row = pi_system.db.execute_one(
            "SELECT id FROM potential_improvements WHERE context = ?",
            (context,),
        )
        return row[0] if row else None
    except Exception:
        return None


def log_discoveries_to_pi(project_root: Path, new_files: list[dict]) -> list[str]:
    """Log discovered Copilot instructions as PI entries for triage.

    Creates PI entries with type 'ingestion_candidate' so they surface
    for user review and potential promotion into Pongogo.

    Returns list of PI IDs created.
    """
    if not new_files:
        return []

    try:
        from mcp_server.pi_system import PISystem
        from mcp_server.pi_system.models import (
            PIClassification,
            PIConfidence,
            PIStatus,
            PIType,
        )

        pi_db_path = project_root / ".pongogo" / "potential_improvements.db"
        if not pi_db_path.exists():
            return []

        pi_system = PISystem(db_path=pi_db_path)
        pi_ids = []

        for f in new_files:
            title = f"Copilot instruction not in Pongogo: {f['name']}"
            context_tag = f"ingestion_candidate:{f['path']}"
            summary = (
                f"Found in {f['path']}. " f"Content preview: {f['preview'][:100]}..."
            )

            # Check if we already logged this file (by context tag)
            existing = _find_pi_by_context(pi_system, context_tag)
            if existing:
                pi_system.add_evidence(
                    pi_id=existing,
                    source="#712",
                    description=f"Re-discovered at {f['path']}",
                )
                pi_ids.append(existing)
                continue

            pi = pi_system.create_pi(
                pi_id=pi_system.get_next_pi_id(),
                title=title,
                summary=summary,
                status=PIStatus.CANDIDATE,
                confidence=PIConfidence.MEDIUM,
                classification=PIClassification.EXPLORATORY,
                pi_type=PIType.IMPROVEMENT,
                context=context_tag,
                source_task="#712",
            )
            pi_ids.append(pi.id)
            logger.info(f"Ingestion PI created: {pi.id} for {f['path']}")

        return pi_ids

    except Exception as e:
        logger.warning(f"Could not log ingestion discoveries to PI system: {e}")
        return []


INGESTED_CATEGORY = "ingested"


def import_instructions(project_root: Path, new_files: list[dict]) -> list[dict]:
    """Import discovered Copilot instructions into .pongogo/instructions/ingested/.

    Copies unique Copilot instruction files into Pongogo's knowledge base
    so the routing engine can immediately use them. Follows the CLAUDE.md
    bootstrap pattern: scan -> compare -> import -> notify.

    Returns list of dicts with imported file info (dest_path, source_path).
    """
    if not new_files:
        return []

    ingested_dir = project_root / PONGOGO_INSTRUCTIONS_DIR / INGESTED_CATEGORY
    ingested_dir.mkdir(parents=True, exist_ok=True)

    imported = []
    for f in new_files:
        # Determine destination filename
        source_name = Path(f["path"]).name
        # Ensure .instructions.md extension for routing engine compatibility
        if not source_name.endswith(".instructions.md"):
            stem = Path(source_name).stem
            dest_name = f"{stem}.instructions.md"
        else:
            dest_name = source_name

        dest_path = ingested_dir / dest_name

        # Don't overwrite if already imported (idempotent)
        if dest_path.exists():
            existing_content = dest_path.read_text(encoding="utf-8")
            if existing_content.strip() == f["content"].strip():
                imported.append(
                    {
                        "source": f["path"],
                        "dest": str(dest_path.relative_to(project_root)),
                        "action": "already_imported",
                    }
                )
                continue

        # Add provenance header if not already present
        content = f["content"]
        if "Ingested from" not in content:
            provenance = (
                f"<!-- Ingested from {f['path']} by Pongogo (#712) -->\n"
                f"<!-- Original source: .github/instructions/ (Copilot) -->\n\n"
            )
            content = provenance + content

        dest_path.write_text(content, encoding="utf-8")
        imported.append(
            {
                "source": f["path"],
                "dest": str(dest_path.relative_to(project_root)),
                "action": "imported",
            }
        )
        logger.info(f"Ingested: {f['path']} -> {dest_path.relative_to(project_root)}")

    return imported


def run_ingestion(
    project_root: Path,
    *,
    force: bool = False,
    log_pi: bool = False,
    auto_import: bool = False,
) -> dict:
    """Run the Copilot instruction ingestion job.

    Scans .github/instructions/, compares against .pongogo/instructions/,
    and imports unique files into Pongogo's knowledge base.

    Args:
        project_root: Project root directory
        force: If True, re-scan all files regardless of previous state
        log_pi: If True, create PI entries for discovered files
        auto_import: If True, copy discovered files into .pongogo/instructions/ingested/

    Returns:
        Dictionary with:
        - scanned: number of files scanned
        - new: list of unique files not in Pongogo
        - duplicates: list of files that match existing Pongogo instructions
        - unchanged: list of files already seen in previous scan
        - imported: list of files imported (only if auto_import=True)
        - pi_ids: list of PI IDs created (only if log_pi=True)
    """
    github_files = scan_github_instructions(project_root)
    if not github_files:
        return {
            "scanned": 0,
            "new": [],
            "duplicates": [],
            "unchanged": [],
            "github_dir_exists": (project_root / GITHUB_INSTRUCTIONS_DIR).exists(),
        }

    pongogo_files = scan_pongogo_instructions(project_root)
    state = load_scan_state(project_root)
    scanned_hashes = state.get("scanned_hashes", {})

    new_files = []
    duplicate_files = []
    unchanged_files = []

    for gf in github_files:
        # Skip unchanged files (unless force)
        if not force and gf["path"] in scanned_hashes:
            if scanned_hashes[gf["path"]] == gf["content_hash"]:
                unchanged_files.append(gf["path"])
                continue

        # Check for duplicates in Pongogo
        match = find_duplicates(gf, pongogo_files)
        if match:
            duplicate_files.append(
                {
                    "github_path": gf["path"],
                    "pongogo_match": match["path"],
                }
            )
        else:
            new_files.append(
                {
                    "path": gf["path"],
                    "name": gf["name"],
                    "size": gf["size"],
                    "content": gf["content"],
                    "preview": gf["content"][:200].strip(),
                }
            )

        # Record hash for future diff
        scanned_hashes[gf["path"]] = gf["content_hash"]

    # Save state
    state["last_scan"] = datetime.now().isoformat()
    state["scanned_hashes"] = scanned_hashes
    save_scan_state(project_root, state)

    # Import discovered instructions into Pongogo's knowledge base
    imported = []
    if auto_import and new_files:
        imported = import_instructions(project_root, new_files)

    # Log discoveries to PI system for awareness
    pi_ids = []
    if log_pi and new_files:
        pi_ids = log_discoveries_to_pi(project_root, new_files)

    return {
        "scanned": len(github_files),
        "new": new_files,
        "duplicates": duplicate_files,
        "unchanged": unchanged_files,
        "imported": imported,
        "pi_ids": pi_ids,
        "github_dir_exists": True,
    }
