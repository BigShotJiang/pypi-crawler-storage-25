#!/usr/bin/env python3
"""
CLI entry points for Pongogo.

Provides command-line interface for hook-based routing.
The pongogo-route command is called by the UserPromptSubmit hook
to route user messages and return formatted context.

Related: Task #482, Sub-Task #483
Bug #687: Added PONGOGO_DEBUG diagnostic traces
Bug #688: Switched to adapter formatter, added tutorial_nudge check
"""

import json
import os
import sys
from pathlib import Path

import mcp_server.engines  # noqa: F401 - imported for side effect (engine registration)
import mcp_server.pongogo_router  # noqa: F401 - imported for side effect (set_default_engine)
from mcp_server.config import (
    get_core_instructions_path,
    get_knowledge_path,
    get_routing_config,
    load_config,
)
from mcp_server.event_capture import store_routing_event
from mcp_server.hooks.claude_code_adapter import format_routing_results
from mcp_server.instruction_handler import InstructionHandler
from mcp_server.routing_engine import create_router
from mcp_server.tutorial_nudge import check_tutorial_nudge
from mcp_server.upgrade import get_current_version


def _debug(msg: str) -> None:
    """Print debug message to stderr when PONGOGO_DEBUG is set."""
    if os.environ.get("PONGOGO_DEBUG"):
        print(f"[pongogo-route debug] {msg}", file=sys.stderr)


def route_cli() -> None:
    """
    CLI entry point for hook-based routing.

    Reads user message from stdin JSON (UserPromptSubmit hook format)
    or from command line args, routes it through the knowledge base,
    and prints formatted results to stdout.

    UserPromptSubmit hook sends JSON:
        {"prompt": "user message", "session_id": "...", "cwd": "..."}

    Usage:
        # Via UserPromptSubmit hook (JSON on stdin)
        echo '{"prompt": "message"}' | pongogo-route

        # Direct CLI usage (args)
        pongogo-route "user message here"

        # Debug mode (verbose stderr)
        PONGOGO_DEBUG=1 echo '{"prompt": "message"}' | pongogo-route

    Exit codes:
        0: Success (output printed to stdout)
        1: Error during routing
    """
    _debug(f"argv={sys.argv}")
    _debug(f"stdin.isatty={sys.stdin.isatty()}")

    # Read message from args (direct CLI) or stdin JSON (hook)
    session_id = None
    cwd = ""
    if len(sys.argv) > 1:
        # Direct CLI usage: pongogo-route "message"
        message = " ".join(sys.argv[1:])
        _debug(f"source=argv message={message!r}")
    else:
        # Hook usage: JSON on stdin from UserPromptSubmit
        stdin_data = sys.stdin.read().strip()
        _debug(f"stdin_data={stdin_data!r} len={len(stdin_data)}")

        if not stdin_data:
            _debug("exit: empty stdin")
            sys.exit(0)

        try:
            # Parse JSON from hook
            input_data = json.loads(stdin_data)
            message = input_data.get("prompt", "")
            session_id = input_data.get("session_id")
            cwd = input_data.get("cwd", "")
            _debug(f"source=json message={message!r} session_id={session_id}")
        except json.JSONDecodeError:
            # Fallback: treat stdin as plain text (backward compatibility)
            message = stdin_data
            _debug(f"source=plaintext message={message!r}")

    if not message:
        # No message, no output - exit cleanly
        _debug("exit: empty message")
        sys.exit(0)

    try:
        # Load configuration
        server_dir = Path(__file__).parent
        server_config = load_config(server_dir=server_dir)

        # Initialize instruction handler
        knowledge_path = get_knowledge_path(server_config, server_dir)
        core_path = get_core_instructions_path()
        _debug(f"knowledge_path={knowledge_path} exists={knowledge_path.exists()}")
        _debug(
            f"core_path={core_path}"
            f" exists={core_path.exists() if core_path else 'N/A'}"
        )

        handler = InstructionHandler(knowledge_path, core_path=core_path)
        count = handler.load_instructions()
        _debug(f"instructions_loaded={count}")

        # Create router with config
        routing_config = get_routing_config(server_config)
        router = create_router(handler, routing_config)

        # Route the message
        result = router.route(message, limit=5)
        result_count = result.get("count", 0)
        _debug(f"routing_result_count={result_count}")

        # Add routing engine version to result (router doesn't include it)
        result["routing_engine_version"] = router.version

        # Check tutorial nudge (Bug #688: was missing from CLI path)
        try:
            routed_categories = list(
                {
                    inst.get("category", "")
                    for inst in result.get("instructions", [])
                    if inst.get("category")
                }
            )
            nudge = check_tutorial_nudge(
                routed_categories=routed_categories,
                pongogo_version=get_current_version(),
                project_root=Path(cwd) if cwd else None,
            )
            if nudge:
                result["tutorial_nudge"] = nudge
                _debug(f"tutorial_nudge_type={nudge.get('nudge_type')}")
        except Exception as e:
            # Don't fail routing if tutorial check fails
            _debug(f"tutorial_nudge_error: {e}")

        # Capture routing event to database (non-blocking, but fail-loud)
        try:
            instruction_ids = [
                inst.get("id", "") for inst in result.get("instructions", [])
            ]
            engine_version = result.get("routing_engine_version", "unknown")
            captured = store_routing_event(
                user_message=message,
                routed_instructions=instruction_ids,
                engine_version=engine_version,
                context=None,
                session_id=session_id,
            )
            if not captured:
                _debug(
                    "event_capture returned False (warning emitted by store_routing_event)"
                )
        except Exception as e:
            # Don't fail routing if event capture raises
            print(f"[pongogo] WARNING: Event capture exception: {e}", file=sys.stderr)

        # Format and output
        formatted = format_routing_results(result, message=message, cwd=cwd)
        if formatted:
            print(formatted)
        else:
            _debug(f"exit: formatter returned empty (count={result_count})")

    except Exception as e:
        # Log error to stderr, don't pollute stdout
        print(f"pongogo-route: routing error: {e}", file=sys.stderr)
        if os.environ.get("PONGOGO_DEBUG"):
            import traceback

            traceback.print_exc(file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    route_cli()
