"""Project detection guard for Pongogo hooks.

Prevents hooks from creating files in non-Pongogo repositories.
Bug #753: MCP hooks pollute non-Pongogo repos.

This module must be lightweight — no database imports, no file creation,
no heavy dependencies. It runs on every hook invocation.
"""

from pathlib import Path


def is_pongogo_project(cwd: str | Path | None = None) -> bool:
    """Check if the working directory is a Pongogo-managed project.

    A Pongogo-managed project has either:
    - .pongogo/instructions/ directory (initialized via pongogo init)
    - .pongogo-stage0.json file (dev repo bootstrap config)

    Args:
        cwd: Directory to check. Defaults to Path.cwd().

    Returns:
        True if this is a Pongogo-managed project, False otherwise.
    """
    root = Path(cwd) if cwd else Path.cwd()
    return (root / ".pongogo" / "instructions").is_dir() or (
        root / ".pongogo-stage0.json"
    ).is_file()
