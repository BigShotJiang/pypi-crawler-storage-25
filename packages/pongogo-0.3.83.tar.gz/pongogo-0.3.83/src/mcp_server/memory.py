"""
Pongogo Native Memory System (Phase 1).

Provides agent-facing, cross-platform memory via `.pongogo/memory/MEMORY.md`.
Architecture spec: docs/architecture/cross_platform_memory_architecture.md

Issue #700: Pongogo Native Memory System
"""

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

MEMORY_DIR = "memory"
MEMORY_FILE = "MEMORY.md"
MEMORY_AUTO_LOAD_LINES = 200


def get_memory_path(project_root: Path) -> Path:
    """Return the path to the Pongogo memory file."""
    return project_root / ".pongogo" / MEMORY_DIR / MEMORY_FILE


def ensure_memory_dir(project_root: Path) -> Path:
    """Create .pongogo/memory/ directory if it doesn't exist. Returns the directory path."""
    memory_dir = project_root / ".pongogo" / MEMORY_DIR
    memory_dir.mkdir(parents=True, exist_ok=True)
    return memory_dir


def read_memory(project_root: Path) -> str:
    """Read the full contents of .pongogo/memory/MEMORY.md."""
    memory_path = get_memory_path(project_root)
    if not memory_path.exists():
        return ""
    return memory_path.read_text(encoding="utf-8")


def read_memory_auto_load(project_root: Path) -> str:
    """Read the first 200 lines of memory for auto-loading into hook context."""
    memory_path = get_memory_path(project_root)
    if not memory_path.exists():
        return ""
    try:
        with open(memory_path, encoding="utf-8") as f:
            lines = []
            for i, line in enumerate(f):
                if i >= MEMORY_AUTO_LOAD_LINES:
                    break
                lines.append(line)
        return "".join(lines)
    except Exception as e:
        logger.warning(f"Could not read memory file: {e}")
        return ""


def write_memory(project_root: Path, content: str) -> None:
    """Write content to .pongogo/memory/MEMORY.md (full overwrite)."""
    memory_dir = ensure_memory_dir(project_root)
    memory_path = memory_dir / MEMORY_FILE
    memory_path.write_text(content, encoding="utf-8")


def append_memory(project_root: Path, content: str, section: str | None = None) -> None:
    """Append content to .pongogo/memory/MEMORY.md.

    If section is specified, append under that section header.
    If the section doesn't exist, create it at the end.
    """
    memory_path = get_memory_path(project_root)
    existing = ""
    if memory_path.exists():
        existing = memory_path.read_text(encoding="utf-8")

    if section:
        section_header = f"## {section}"
        if section_header in existing:
            # Find the next section header or end of file
            header_pos = existing.index(section_header)
            after_header = existing[header_pos + len(section_header) :]

            next_section = after_header.find("\n## ")
            if next_section == -1:
                # No next section — append at end
                updated = existing.rstrip() + "\n" + content.strip() + "\n"
            else:
                # Insert before next section
                insert_pos = header_pos + len(section_header) + next_section
                updated = (
                    existing[:insert_pos].rstrip()
                    + "\n"
                    + content.strip()
                    + "\n\n"
                    + existing[insert_pos:].lstrip()
                )
        else:
            # Section doesn't exist — create it at the end
            updated = (
                existing.rstrip()
                + "\n\n"
                + section_header
                + "\n\n"
                + content.strip()
                + "\n"
            )
    else:
        if existing:
            updated = existing.rstrip() + "\n\n" + content.strip() + "\n"
        else:
            updated = content.strip() + "\n"

    ensure_memory_dir(project_root)
    memory_path.write_text(updated, encoding="utf-8")


def bootstrap_from_claude_code(project_root: Path) -> bool:
    """Bootstrap Pongogo memory from Claude Code MEMORY.md if it exists.

    Only bootstraps if:
    - Pongogo memory doesn't already exist
    - Claude Code memory exists for this project

    Returns True if bootstrap was performed.
    """
    pongogo_memory = get_memory_path(project_root)
    if pongogo_memory.exists():
        return False

    claude_memory_dir = _find_claude_code_memory(project_root)
    if not claude_memory_dir:
        return False

    claude_memory_path = claude_memory_dir / MEMORY_FILE
    if not claude_memory_path.exists():
        return False

    content = claude_memory_path.read_text(encoding="utf-8")
    if not content.strip():
        return False

    ensure_memory_dir(project_root)
    pongogo_memory.write_text(content, encoding="utf-8")
    logger.info(f"Bootstrapped Pongogo memory from Claude Code: {claude_memory_path}")
    return True


def _find_claude_code_memory(project_root: Path) -> Path | None:
    """Find Claude Code's memory directory for the given project.

    Claude Code sanitizes the project path by replacing '/' with '-'
    and stores memory at ~/.claude/projects/{sanitized}/memory/.
    """
    claude_projects_dir = Path.home() / ".claude" / "projects"
    if not claude_projects_dir.exists():
        return None

    sanitized = str(project_root).replace("/", "-")
    candidate = claude_projects_dir / sanitized / "memory"
    if candidate.exists():
        return candidate

    return None


def should_inject_memory(project_root: Path, platform: str) -> bool:
    """Determine if memory should be injected into hook output.

    Skips injection when running on Claude Code and the Pongogo memory
    is identical to Claude Code's auto-loaded memory (deduplication).
    """
    pongogo_memory = get_memory_path(project_root)
    if not pongogo_memory.exists():
        return False

    pongogo_content = pongogo_memory.read_text(encoding="utf-8").strip()
    if not pongogo_content:
        return False

    if platform == "claude_code":
        claude_memory_dir = _find_claude_code_memory(project_root)
        if claude_memory_dir:
            claude_memory_path = claude_memory_dir / MEMORY_FILE
            if claude_memory_path.exists():
                claude_content = claude_memory_path.read_text(encoding="utf-8").strip()
                if pongogo_content == claude_content:
                    logger.debug(
                        "Memory dedup: Pongogo matches Claude Code, skipping injection"
                    )
                    return False

    return True
