"""Claude Code platform adapter.

Extracts the Claude Code-specific scaffolding logic that previously lived
inline in init_command.py into a PlatformAdapter implementation.

Produces byte-identical output to the original init_command.py code paths.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .base import PlatformAdapter, ScaffoldResult


class ClaudeCodeAdapter(PlatformAdapter):
    """Adapter for Anthropic's Claude Code CLI."""

    def platform_name(self) -> str:
        return "claude_code"

    def detect(self, project_path: Path) -> bool:
        """Detect Claude Code by presence of .claude/ directory or .mcp.json."""
        return (project_path / ".claude").is_dir() or (
            project_path / ".mcp.json"
        ).exists()

    # ------------------------------------------------------------------
    # MCP config
    # ------------------------------------------------------------------

    def scaffold_mcp(
        self,
        project_path: Path,
        *,
        mode: str,
        container_name: str | None,
    ) -> ScaffoldResult:
        """Write .mcp.json at project root.

        Claude Code uses .mcp.json (not .vscode/mcp.json).
        """
        result = ScaffoldResult()
        mcp_config_path = project_path / ".mcp.json"

        if mode == "native":
            mcp_server_config: dict[str, Any] = {
                "command": "pongogo-server",
            }
        else:
            mcp_server_config = {
                "command": "docker",
                "args": ["exec", "-i", container_name, "pongogo-server"],
            }

        mcp_config: dict[str, Any] = {
            "mcpServers": {
                "pongogo-knowledge": mcp_server_config,
            }
        }

        # Merge into existing .mcp.json if present
        if mcp_config_path.exists():
            try:
                existing = json.loads(mcp_config_path.read_text())
                existing.setdefault("mcpServers", {})
                existing["mcpServers"]["pongogo-knowledge"] = mcp_config["mcpServers"][
                    "pongogo-knowledge"
                ]
                mcp_config_path.write_text(json.dumps(existing, indent=2) + "\n")
                result.files_merged.append(mcp_config_path)
            except (json.JSONDecodeError, KeyError):
                mcp_config_path.write_text(json.dumps(mcp_config, indent=2) + "\n")
                result.files_written.append(mcp_config_path)
        else:
            mcp_config_path.write_text(json.dumps(mcp_config, indent=2) + "\n")
            result.files_written.append(mcp_config_path)

        return result

    # ------------------------------------------------------------------
    # Hooks
    # ------------------------------------------------------------------

    def scaffold_hooks(
        self,
        project_path: Path,
        *,
        mode: str,
        container_name: str | None,
    ) -> ScaffoldResult:
        """Write hook config into .claude/settings.json or settings.local.json.

        Delegates to the canonical hook builder in migrations.py to ensure
        the hook definitions stay in a single source of truth.
        """
        from ..migrations import _build_canonical_hooks

        result = ScaffoldResult()

        hook_config = {"hooks": _build_canonical_hooks(mode, container_name)}

        # Native: git-tracked settings.json; Docker: gitignored settings.local.json
        claude_dir = project_path / ".claude"
        claude_dir.mkdir(parents=True, exist_ok=True)

        if mode == "native":
            settings_path = claude_dir / "settings.json"
        else:
            settings_path = claude_dir / "settings.local.json"

        hook_types = [
            "UserPromptSubmit",
            "PreToolUse",
            "PostToolUse",
            "SubagentStart",
            "SubagentStop",
            "Stop",
        ]

        if settings_path.exists():
            try:
                existing = json.loads(settings_path.read_text())
                existing.setdefault("hooks", {})
                for hook_type in hook_types:
                    if hook_type in hook_config["hooks"]:
                        existing["hooks"][hook_type] = hook_config["hooks"][hook_type]
                settings_path.write_text(json.dumps(existing, indent=2) + "\n")
                result.files_merged.append(settings_path)
            except (json.JSONDecodeError, KeyError):
                settings_path.write_text(json.dumps(hook_config, indent=2) + "\n")
                result.files_written.append(settings_path)
        else:
            settings_path.write_text(json.dumps(hook_config, indent=2) + "\n")
            result.files_written.append(settings_path)

        return result

    # ------------------------------------------------------------------
    # Skills (slash commands)
    # ------------------------------------------------------------------

    def scaffold_skills(
        self,
        project_path: Path,
        *,
        source_dir: Path,
    ) -> ScaffoldResult:
        """Copy slash commands to .claude/commands/.

        Claude Code uses .claude/commands/{name}.md format.
        """
        from ..instructions import copy_slash_commands

        result = ScaffoldResult()
        commands_dir = project_path / ".claude" / "commands"
        count, pairs = copy_slash_commands(commands_dir)
        for _key, path in pairs:
            result.files_written.append(path)
        return result

    # ------------------------------------------------------------------
    # Instructions
    # ------------------------------------------------------------------

    def scaffold_instructions(
        self,
        project_path: Path,
        *,
        source_dir: Path,
        manifest: dict[str, Any],
        enabled_categories: list[str],
    ) -> ScaffoldResult:
        """Copy instruction files to .pongogo/instructions/.

        Claude Code discovers instructions via the Pongogo MCP server's
        routing system, not via file glob patterns. The instructions are
        stored in .pongogo/instructions/ (shared across all adapters).
        """
        from ..instructions import copy_instructions, copy_manifest

        result = ScaffoldResult()
        dest_dir = project_path / ".pongogo" / "instructions"

        count, pairs = copy_instructions(
            source_dir=source_dir,
            dest_dir=dest_dir,
            manifest=manifest,
            enabled_categories=enabled_categories,
        )
        for _key, path in pairs:
            result.files_written.append(path)

        copy_manifest(source_dir, dest_dir)
        result.files_written.append(dest_dir / "manifest.yaml")

        return result

    # ------------------------------------------------------------------
    # Agent definition
    # ------------------------------------------------------------------

    def scaffold_agent(
        self,
        project_path: Path,
    ) -> ScaffoldResult:
        """Claude Code doesn't use agent definition files — no-op."""
        return ScaffoldResult()

    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------

    def scaffold_settings(
        self,
        project_path: Path,
        *,
        settings: dict[str, Any] | None = None,
    ) -> ScaffoldResult:
        """Claude Code uses CLAUDE.md for settings, not a settings file — no-op."""
        return ScaffoldResult()

    # ------------------------------------------------------------------
    # Unscaffold (remove platform-specific files)
    # ------------------------------------------------------------------

    def unscaffold(self, project_path: Path) -> ScaffoldResult:
        """Remove Claude Code platform files.

        Surgically removes pongogo entries from .mcp.json and
        .claude/settings.json rather than deleting entire files.
        Removes .claude/commands/ pongogo slash commands.
        """
        result = ScaffoldResult()

        # Remove pongogo-knowledge from .mcp.json
        mcp_path = project_path / ".mcp.json"
        if mcp_path.exists():
            try:
                config = json.loads(mcp_path.read_text())
                if (
                    "mcpServers" in config
                    and "pongogo-knowledge" in config["mcpServers"]
                ):
                    del config["mcpServers"]["pongogo-knowledge"]
                    if not config["mcpServers"]:
                        mcp_path.unlink()
                    else:
                        mcp_path.write_text(json.dumps(config, indent=2) + "\n")
                    result.files_written.append(mcp_path)
            except (json.JSONDecodeError, KeyError):
                pass

        # Remove pongogo hooks from settings files
        hook_types = [
            "UserPromptSubmit",
            "PreToolUse",
            "PostToolUse",
            "SubagentStart",
            "SubagentStop",
            "Stop",
        ]
        for settings_name in ("settings.json", "settings.local.json"):
            settings_path = project_path / ".claude" / settings_name
            if settings_path.exists():
                try:
                    settings = json.loads(settings_path.read_text())
                    if "hooks" in settings:
                        for hook_type in hook_types:
                            # Remove hook entries containing pongogo commands
                            if hook_type in settings["hooks"]:
                                settings["hooks"][hook_type] = [
                                    entry
                                    for entry in settings["hooks"][hook_type]
                                    if not any(
                                        "pongogo" in h.get("command", "")
                                        for h in entry.get("hooks", [])
                                    )
                                ]
                                if not settings["hooks"][hook_type]:
                                    del settings["hooks"][hook_type]
                        if not settings["hooks"]:
                            del settings["hooks"]
                        settings_path.write_text(json.dumps(settings, indent=2) + "\n")
                        result.files_written.append(settings_path)
                except (json.JSONDecodeError, KeyError):
                    pass

        # Remove pongogo slash commands from .claude/commands/
        commands_dir = project_path / ".claude" / "commands"
        if commands_dir.exists():
            for cmd_file in commands_dir.glob("*.md"):
                # Only remove pongogo-seeded commands (check content for pongogo markers)
                content = cmd_file.read_text()
                if "pongogo" in content.lower() or cmd_file.stem.startswith("pongogo-"):
                    cmd_file.unlink()
                    result.files_written.append(cmd_file)

        return result

    def list_artifacts(self, project_path: Path) -> list[Path]:
        """Return Claude Code platform files that exist."""
        artifacts = []

        mcp_path = project_path / ".mcp.json"
        if mcp_path.exists():
            try:
                config = json.loads(mcp_path.read_text())
                if "pongogo-knowledge" in config.get("mcpServers", {}):
                    artifacts.append(mcp_path)
            except (json.JSONDecodeError, KeyError):
                pass

        for settings_name in ("settings.json", "settings.local.json"):
            settings_path = project_path / ".claude" / settings_name
            if settings_path.exists():
                try:
                    settings = json.loads(settings_path.read_text())
                    hooks = settings.get("hooks", {})
                    if any(
                        "pongogo" in json.dumps(hooks.get(ht, []))
                        for ht in ("UserPromptSubmit", "PreToolUse", "PostToolUse")
                    ):
                        artifacts.append(settings_path)
                except (json.JSONDecodeError, KeyError):
                    pass

        commands_dir = project_path / ".claude" / "commands"
        if commands_dir.exists():
            pongogo_cmds = list(commands_dir.glob("pongogo-*.md"))
            artifacts.extend(pongogo_cmds)

        return artifacts
