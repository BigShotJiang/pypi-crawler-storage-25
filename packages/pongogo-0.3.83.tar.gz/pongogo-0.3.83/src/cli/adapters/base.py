"""Platform adapter abstract base class.

Defines the interface that platform-specific adapters must implement to
scaffold hooks, MCP config, skills, instructions, and settings for a
given IDE/agent platform.

Architecture: wiki/Multi-Platform-Adapter-Architecture.md
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class ScaffoldResult:
    """Outcome of a scaffold operation."""

    files_written: list[Path] = field(default_factory=list)
    files_merged: list[Path] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0


class PlatformAdapter(ABC):
    """Abstract base for platform-specific scaffolding adapters.

    Each method receives the project root and relevant configuration,
    then writes platform-native config files. Methods return
    ScaffoldResult describing what was written.

    Adapters are stateless — all configuration is passed in.
    """

    @abstractmethod
    def platform_name(self) -> str:
        """Short identifier for this platform (e.g. 'claude_code', 'vscode')."""
        ...

    @abstractmethod
    def detect(self, project_path: Path) -> bool:
        """Return True if this platform's artifacts exist in the project."""
        ...

    @abstractmethod
    def scaffold_mcp(
        self,
        project_path: Path,
        *,
        mode: str,
        container_name: str | None,
    ) -> ScaffoldResult:
        """Write MCP server configuration for this platform.

        Args:
            project_path: Project root directory.
            mode: "native" or "docker".
            container_name: Docker container name (required when mode="docker").
        """
        ...

    @abstractmethod
    def scaffold_hooks(
        self,
        project_path: Path,
        *,
        mode: str,
        container_name: str | None,
    ) -> ScaffoldResult:
        """Write hook configuration for this platform.

        Args:
            project_path: Project root directory.
            mode: "native" or "docker".
            container_name: Docker container name (required when mode="docker").
        """
        ...

    @abstractmethod
    def scaffold_skills(
        self,
        project_path: Path,
        *,
        source_dir: Path,
    ) -> ScaffoldResult:
        """Copy/transform slash commands or skills for this platform.

        Args:
            project_path: Project root directory.
            source_dir: Directory containing packaged slash command files.
        """
        ...

    @abstractmethod
    def scaffold_instructions(
        self,
        project_path: Path,
        *,
        source_dir: Path,
        manifest: dict[str, Any],
        enabled_categories: list[str],
    ) -> ScaffoldResult:
        """Copy/transform instruction files for this platform.

        Args:
            project_path: Project root directory.
            source_dir: Directory containing packaged instruction files.
            manifest: Instruction manifest dict.
            enabled_categories: List of enabled category names.
        """
        ...

    @abstractmethod
    def scaffold_agent(
        self,
        project_path: Path,
    ) -> ScaffoldResult:
        """Write agent definition file for this platform (if applicable).

        Returns an empty ScaffoldResult if the platform doesn't use agent files.
        """
        ...

    @abstractmethod
    def scaffold_settings(
        self,
        project_path: Path,
        *,
        settings: dict[str, Any] | None = None,
    ) -> ScaffoldResult:
        """Write platform-specific settings (e.g. VS Code settings.json).

        Returns an empty ScaffoldResult if the platform doesn't use settings files.
        """
        ...

    @abstractmethod
    def unscaffold(
        self,
        project_path: Path,
    ) -> ScaffoldResult:
        """Remove all platform-specific files created by scaffold methods.

        Surgically removes pongogo entries from shared config files
        (e.g., .mcp.json, settings.json) rather than deleting the files
        entirely. Returns ScaffoldResult with removed files listed in
        files_written.
        """
        ...

    def list_artifacts(self, project_path: Path) -> list[Path]:
        """Return list of platform-specific files/dirs that exist.

        Used by ``pongogo install --list`` to show what's installed per
        platform. Default implementation returns an empty list; adapters
        should override with their specific file paths.
        """
        return []

    def scaffold_all(
        self,
        project_path: Path,
        *,
        mode: str,
        container_name: str | None,
        source_instructions_dir: Path,
        manifest: dict[str, Any],
        enabled_categories: list[str],
        source_skills_dir: Path,
        settings: dict[str, Any] | None = None,
    ) -> ScaffoldResult:
        """Run all scaffold operations. Convenience method.

        Returns a merged ScaffoldResult across all operations.
        """
        merged = ScaffoldResult()
        for sub in [
            self.scaffold_mcp(project_path, mode=mode, container_name=container_name),
            self.scaffold_hooks(project_path, mode=mode, container_name=container_name),
            self.scaffold_skills(project_path, source_dir=source_skills_dir),
            self.scaffold_instructions(
                project_path,
                source_dir=source_instructions_dir,
                manifest=manifest,
                enabled_categories=enabled_categories,
            ),
            self.scaffold_agent(project_path),
            self.scaffold_settings(project_path, settings=settings),
        ]:
            merged.files_written.extend(sub.files_written)
            merged.files_merged.extend(sub.files_merged)
            merged.errors.extend(sub.errors)
        return merged
