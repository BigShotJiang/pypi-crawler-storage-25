"""Platform adapter registry.

Provides discovery and lookup for platform-specific adapters.
"""

from __future__ import annotations

from pathlib import Path

from .base import PlatformAdapter, ScaffoldResult
from .claude_code import ClaudeCodeAdapter
from .vscode import VsCodeAdapter

__all__ = [
    "ClaudeCodeAdapter",
    "PlatformAdapter",
    "ScaffoldResult",
    "VsCodeAdapter",
    "detect_platforms",
    "get_adapter",
    "list_adapters",
]

# Registry of all known adapters, in detection priority order.
# Claude Code is checked first (most common).
_ADAPTERS: list[PlatformAdapter] = [
    ClaudeCodeAdapter(),
    VsCodeAdapter(),
]


def register_adapter(adapter: PlatformAdapter) -> None:
    """Register a new platform adapter (appended to the end of the list)."""
    _ADAPTERS.append(adapter)


def list_adapters() -> list[str]:
    """Return names of all registered adapters."""
    return [a.platform_name() for a in _ADAPTERS]


def get_adapter(platform_name: str) -> PlatformAdapter:
    """Look up an adapter by platform name.

    Raises:
        ValueError: If no adapter with that name is registered.
    """
    for adapter in _ADAPTERS:
        if adapter.platform_name() == platform_name:
            return adapter
    available = ", ".join(list_adapters())
    raise ValueError(f"Unknown platform '{platform_name}'. Available: {available}")


def detect_platforms(project_path: Path) -> list[PlatformAdapter]:
    """Auto-detect which platforms are present in the project.

    Returns all adapters whose detect() returns True, in registry order.
    If none are detected, defaults to [ClaudeCodeAdapter] (the most common case).
    """
    detected = [a for a in _ADAPTERS if a.detect(project_path)]
    if not detected:
        # Default to Claude Code if nothing else detected
        detected = [get_adapter("claude_code")]
    return detected
