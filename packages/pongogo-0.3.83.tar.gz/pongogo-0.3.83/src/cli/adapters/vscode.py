"""VS Code (Copilot Agent Mode) platform adapter.

Scaffolds configuration files in VS Code's native format:
- `.vscode/mcp.json` — MCP server config (uses `servers` key + `type: "stdio"`)
- `.github/hooks/pongogo.json` — Copilot-compatible hooks
- `.github/skills/{name}/SKILL.md` — Slash command skills
- `.github/agents/pongogo.agent.md` — Agent definition
- `.github/instructions/` — Instruction files with VS Code frontmatter
- `.vscode/settings.json` — VS Code settings for commit messages, code review, etc.

Architecture: wiki/Multi-Platform-Adapter-Architecture.md
POC reference: tmp/vscode-poc/
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

from .base import PlatformAdapter, ScaffoldResult

logger = logging.getLogger(__name__)


class VsCodeAdapter(PlatformAdapter):
    """Adapter for VS Code with GitHub Copilot Agent Mode."""

    def platform_name(self) -> str:
        return "vscode"

    def detect(self, project_path: Path) -> bool:
        """Detect VS Code by presence of .vscode/ directory."""
        return (project_path / ".vscode").is_dir()

    # ------------------------------------------------------------------
    # MCP config
    # ------------------------------------------------------------------

    def scaffold_mcp(
        self,
        project_path: Path,
        *,
        mode: str,
        container_name: str | None,
    ) -> ScaffoldResult:
        """Write .vscode/mcp.json with VS Code format.

        VS Code uses `servers` key (not `mcpServers`) and requires `type: "stdio"`.
        """
        result = ScaffoldResult()
        vscode_dir = project_path / ".vscode"
        vscode_dir.mkdir(parents=True, exist_ok=True)
        mcp_path = vscode_dir / "mcp.json"

        if mode == "native":
            server_config: dict[str, Any] = {
                "type": "stdio",
                "command": "pongogo-server",
            }
        else:
            server_config = {
                "type": "stdio",
                "command": "docker",
                "args": ["exec", "-i", container_name, "pongogo-server"],
            }

        mcp_config: dict[str, Any] = {
            "servers": {
                "pongogo-knowledge": server_config,
            }
        }

        # Merge into existing mcp.json if present
        if mcp_path.exists():
            try:
                existing = json.loads(mcp_path.read_text())
                existing.setdefault("servers", {})
                existing["servers"]["pongogo-knowledge"] = server_config
                mcp_path.write_text(json.dumps(existing, indent=2) + "\n")
                result.files_merged.append(mcp_path)
            except (json.JSONDecodeError, KeyError):
                mcp_path.write_text(json.dumps(mcp_config, indent=2) + "\n")
                result.files_written.append(mcp_path)
        else:
            mcp_path.write_text(json.dumps(mcp_config, indent=2) + "\n")
            result.files_written.append(mcp_path)

        return result

    # ------------------------------------------------------------------
    # Hooks
    # ------------------------------------------------------------------

    def scaffold_hooks(
        self,
        project_path: Path,
        *,
        mode: str,
        container_name: str | None,
    ) -> ScaffoldResult:
        """Write hooks to .github/hooks/pongogo.json.

        VS Code Copilot uses .github/hooks/ directory (not .claude/settings.json).
        The hook format is identical to Claude Code but lives in a different location.
        """
        from ..migrations import _build_canonical_hooks

        result = ScaffoldResult()

        hooks_dir = project_path / ".github" / "hooks"
        hooks_dir.mkdir(parents=True, exist_ok=True)
        hooks_path = hooks_dir / "pongogo.json"

        hook_config = {"hooks": _build_canonical_hooks(mode, container_name)}

        hooks_path.write_text(json.dumps(hook_config, indent=2) + "\n")
        result.files_written.append(hooks_path)

        return result

    # ------------------------------------------------------------------
    # Skills (slash commands)
    # ------------------------------------------------------------------

    def scaffold_skills(
        self,
        project_path: Path,
        *,
        source_dir: Path,
    ) -> ScaffoldResult:
        """Transform slash commands to VS Code formats.

        Generates two parallel sets of files:
        1. `.github/skills/{name}/SKILL.md` — Skill discovery format
        2. `.github/prompts/{name}.prompt.md` — Rich prompt file format
           with MCP tool references and variable substitution

        Task #697: VS Code prompt file + skill mapping.
        """
        result = ScaffoldResult()

        if not source_dir.is_dir():
            return result

        skills_dir = project_path / ".github" / "skills"
        skills_dir.mkdir(parents=True, exist_ok=True)
        prompts_dir = project_path / ".github" / "prompts"
        prompts_dir.mkdir(parents=True, exist_ok=True)

        for cmd_file in sorted(source_dir.glob("*.md")):
            skill_name = cmd_file.stem  # e.g. "pongogo-status"
            content = cmd_file.read_text()

            # Extract existing frontmatter if present
            fm, body = self._parse_frontmatter(content)
            description = fm.get(
                "description",
                f"Pongogo {skill_name.replace('-', ' ').replace('pongogo ', '')} command",
            )

            # --- SKILL.md (skill discovery) ---
            skill_dir = skills_dir / skill_name
            skill_dir.mkdir(parents=True, exist_ok=True)
            skill_path = skill_dir / "SKILL.md"

            skill_content = (
                f"---\n"
                f"name: {skill_name}\n"
                f"description: {description}\n"
                f"user-invocable: true\n"
                f"disable-model-invocation: true\n"
                f"---\n\n"
                f"{body.lstrip()}"
            )
            skill_path.write_text(skill_content)
            result.files_written.append(skill_path)

            # --- .prompt.md (rich prompt file) ---
            prompt_path = prompts_dir / f"{skill_name}.prompt.md"

            prompt_content = (
                f"---\n"
                f"name: {skill_name}\n"
                f"description: {description}\n"
                f"agent: agent\n"
                f"tools:\n"
                f"  - pongogo-knowledge/*\n"
                f"---\n\n"
                f"{body.lstrip()}"
            )
            prompt_path.write_text(prompt_content)
            result.files_written.append(prompt_path)

        logger.debug(
            "VS Code skills: %d skill + prompt files written",
            len(result.files_written),
        )
        return result

    # ------------------------------------------------------------------
    # Instructions
    # ------------------------------------------------------------------

    # YAML frontmatter regex: matches --- ... --- at start of file
    _FRONTMATTER_RE = re.compile(
        r"\A---\s*\n(.*?)\n---\s*\n?",
        re.DOTALL,
    )

    @staticmethod
    def _parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
        """Extract YAML frontmatter and body from an instruction file.

        Uses a lightweight regex parser instead of a full YAML library to
        avoid adding pyyaml as a dependency for the CLI package.

        Returns:
            Tuple of (frontmatter_dict, body_text). If no frontmatter found,
            returns ({}, full_text).
        """
        match = VsCodeAdapter._FRONTMATTER_RE.match(text)
        if not match:
            return {}, text

        raw = match.group(1)
        body = text[match.end() :]
        fm: dict[str, Any] = {}

        for line in raw.splitlines():
            # Skip comments and blank lines
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue

            # Handle simple key: value pairs
            if ":" in line and not line.startswith(" ") and not line.startswith("\t"):
                key, _, value = line.partition(":")
                key = key.strip()
                value = value.strip().strip('"').strip("'")

                if value:
                    fm[key] = value
                else:
                    # Could be start of a list — collect subsequent indented lines
                    items: list[str] = []
                    fm[key] = items
            elif line.lstrip().startswith("- ") and fm:
                # List item belonging to the last key
                last_key = list(fm.keys())[-1]
                item = line.lstrip().removeprefix("- ").strip().strip('"').strip("'")
                val = fm[last_key]
                if isinstance(val, list):
                    val.append(item)

        return fm, body

    def scaffold_instructions(
        self,
        project_path: Path,
        *,
        source_dir: Path,
        manifest: dict[str, Any],
        enabled_categories: list[str],
    ) -> ScaffoldResult:
        """No-op: VS Code instructions are served from .pongogo/instructions/.

        Pongogo maintains a strict containment boundary: all instruction
        files live in .pongogo/instructions/ across ALL platforms. VS Code
        accesses them via the MCP server and hooks (same as Claude Code),
        not through .github/instructions/ file duplication.

        Writing to .github/instructions/ would risk contamination by mixing
        Pongogo-managed files with user/Copilot-generated instruction files.

        See: scaffold_settings() for how VS Code native features reference
        .pongogo/instructions/ files directly via file paths.
        """
        return ScaffoldResult()

    # ------------------------------------------------------------------
    # Agent definition
    # ------------------------------------------------------------------

    def scaffold_agent(
        self,
        project_path: Path,
    ) -> ScaffoldResult:
        """Write .github/agents/pongogo.agent.md.

        Creates a Copilot agent definition that references Pongogo MCP tools.
        """
        result = ScaffoldResult()

        agents_dir = project_path / ".github" / "agents"
        agents_dir.mkdir(parents=True, exist_ok=True)
        agent_path = agents_dir / "pongogo.agent.md"

        agent_content = """\
---
name: pongogo
description: Pongogo knowledge routing agent for development assistance
---

# Pongogo Agent

You have access to the Pongogo knowledge routing system via MCP tools.

## Available Tools

- `route_instructions` — Route user messages to relevant instruction files
- `get_instructions` — Get instructions by topic or category
- `search_instructions` — Full-text search across instructions

## Behavior

When the user asks a question about development practices, project management, or workflows:
1. Use `route_instructions` with the user's message to find relevant guidance
2. Follow the instructions returned by routing
3. If routing returns procedural instructions, read them before acting
"""

        agent_path.write_text(agent_content)
        result.files_written.append(agent_path)

        return result

    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------

    # Mapping of VS Code native settings to instruction file names.
    # Paths are resolved dynamically at scaffold time to handle
    # different category directory structures (dev repo vs distributed).
    SETTINGS_INSTRUCTION_MAP: dict[str, str] = {
        "github.copilot.chat.commitMessageGeneration.instructions": "commit_message_format.instructions.md",
        "github.copilot.chat.reviewSelection.instructions": "code_review_standards.instructions.md",
        "github.copilot.chat.pullRequestDescriptionGeneration.instructions": "pull_request_workflow.instructions.md",
    }

    # Directory for platform-optimized instruction copies (Issue #706)
    OPTIMIZED_DIR = "vscode-optimized"

    @classmethod
    def _optimize_for_native_settings(cls, content: str) -> str:
        """Produce a platform-optimized instruction for VS Code native settings.

        Strips YAML frontmatter (routing metadata irrelevant for native
        delivery) and removes sections that are only useful for routing
        engine context (compliance criteria, enforcement blocks, routing
        metadata sections).

        Issue #706: Platform-specific instruction optimization.

        Args:
            content: Full instruction file content with frontmatter

        Returns:
            Optimized content without frontmatter or routing-only sections
        """
        # Strip frontmatter
        _, body = cls._parse_frontmatter(content)
        body = body.strip()

        # Remove compliance gate sections (STOP blocks that reference
        # routing/preceptor enforcement — not relevant for native delivery)
        lines = body.splitlines(keepends=True)
        optimized_lines: list[str] = []
        skip_until_separator = False

        for line in lines:
            stripped = line.strip()

            # Skip routing-specific sections
            if stripped.startswith("## 🛑 STOP: COMPLIANCE GATE"):
                skip_until_separator = True
                continue
            if skip_until_separator and stripped == "---":
                skip_until_separator = False
                continue
            if skip_until_separator:
                continue

            optimized_lines.append(line)

        return "".join(optimized_lines).strip() + "\n"

    def scaffold_settings(
        self,
        project_path: Path,
        *,
        settings: dict[str, Any] | None = None,
    ) -> ScaffoldResult:
        """Merge optimized Pongogo instruction references into .vscode/settings.json.

        Configures VS Code's native Copilot instruction hooks for commit
        messages, code review, and PR descriptions. Creates optimized copies
        of instruction files (frontmatter stripped, routing-only sections
        removed) so Copilot receives focused, actionable content.

        Issue #706: References point to optimized copies in
        .pongogo/instructions/vscode-optimized/ rather than raw files
        with 50+ lines of routing metadata.

        Existing user settings are preserved (merge, not replace).
        """
        result = ScaffoldResult()

        instructions_dir = project_path / ".pongogo" / "instructions"
        if not instructions_dir.is_dir():
            return result

        optimized_dir = instructions_dir / self.OPTIMIZED_DIR
        optimized_dir.mkdir(parents=True, exist_ok=True)

        # Resolve, optimize, and reference instruction files
        pongogo_settings: dict[str, list[dict[str, str]]] = {}
        for setting_key, filename in self.SETTINGS_INSTRUCTION_MAP.items():
            matches = list(instructions_dir.rglob(filename))
            # Skip matches inside the optimized dir itself
            matches = [m for m in matches if self.OPTIMIZED_DIR not in m.parts]
            if not matches:
                continue

            source_path = matches[0]
            source_content = source_path.read_text(encoding="utf-8")

            # Create optimized copy
            optimized_path = optimized_dir / filename
            optimized_content = self._optimize_for_native_settings(source_content)
            optimized_path.write_text(optimized_content, encoding="utf-8")

            # Reference the optimized copy
            rel_path = optimized_path.relative_to(project_path)
            pongogo_settings[setting_key] = [{"file": str(rel_path)}]

        if not pongogo_settings:
            return result

        # Merge into existing .vscode/settings.json
        vscode_dir = project_path / ".vscode"
        vscode_dir.mkdir(parents=True, exist_ok=True)
        settings_path = vscode_dir / "settings.json"

        if settings_path.exists():
            try:
                existing = json.loads(settings_path.read_text())
            except (json.JSONDecodeError, OSError):
                existing = {}

            for key, value in pongogo_settings.items():
                existing[key] = value

            settings_path.write_text(json.dumps(existing, indent=2) + "\n")
            result.files_merged.append(settings_path)
        else:
            settings_path.write_text(json.dumps(pongogo_settings, indent=2) + "\n")
            result.files_written.append(settings_path)

        return result

    # ------------------------------------------------------------------
    # Unscaffold (remove platform-specific files)
    # ------------------------------------------------------------------

    def unscaffold(self, project_path: Path) -> ScaffoldResult:
        """Remove VS Code platform files.

        Surgically removes pongogo entries from .vscode/mcp.json and
        .vscode/settings.json. Removes .github/hooks/pongogo.json,
        .github/agents/pongogo.agent.md, and pongogo skills/prompts.
        """
        import shutil

        result = ScaffoldResult()

        # Remove pongogo-knowledge from .vscode/mcp.json
        vscode_mcp = project_path / ".vscode" / "mcp.json"
        if vscode_mcp.exists():
            try:
                config = json.loads(vscode_mcp.read_text())
                if "servers" in config and "pongogo-knowledge" in config["servers"]:
                    del config["servers"]["pongogo-knowledge"]
                    if not config["servers"]:
                        vscode_mcp.unlink()
                    else:
                        vscode_mcp.write_text(json.dumps(config, indent=2) + "\n")
                    result.files_written.append(vscode_mcp)
            except (json.JSONDecodeError, KeyError):
                pass

        # Remove .github/hooks/pongogo.json
        hooks_file = project_path / ".github" / "hooks" / "pongogo.json"
        if hooks_file.exists():
            hooks_file.unlink()
            result.files_written.append(hooks_file)

        # Remove .github/agents/pongogo.agent.md
        agent_file = project_path / ".github" / "agents" / "pongogo.agent.md"
        if agent_file.exists():
            agent_file.unlink()
            result.files_written.append(agent_file)

        # Remove pongogo skills from .github/skills/
        skills_dir = project_path / ".github" / "skills"
        if skills_dir.exists():
            for skill_dir in skills_dir.iterdir():
                if skill_dir.is_dir() and skill_dir.name.startswith("pongogo-"):
                    shutil.rmtree(skill_dir)
                    result.files_written.append(skill_dir)

        # Remove pongogo prompts from .github/prompts/
        prompts_dir = project_path / ".github" / "prompts"
        if prompts_dir.exists():
            for prompt_file in prompts_dir.glob("pongogo-*.prompt.md"):
                prompt_file.unlink()
                result.files_written.append(prompt_file)

        # Remove pongogo settings from .vscode/settings.json
        vscode_settings = project_path / ".vscode" / "settings.json"
        if vscode_settings.exists():
            try:
                settings = json.loads(vscode_settings.read_text())
                pongogo_keys = [k for k in settings if "pongogo" in k.lower()]
                for key in pongogo_keys:
                    del settings[key]
                if pongogo_keys:
                    vscode_settings.write_text(json.dumps(settings, indent=2) + "\n")
                    result.files_written.append(vscode_settings)
            except (json.JSONDecodeError, KeyError):
                pass

        # Remove VS Code optimized instruction copies
        optimized_dir = project_path / ".pongogo" / "instructions" / "vscode-optimized"
        if optimized_dir.exists():
            shutil.rmtree(optimized_dir)
            result.files_written.append(optimized_dir)

        return result

    def list_artifacts(self, project_path: Path) -> list[Path]:
        """Return VS Code platform files that exist."""
        artifacts: list[Path] = []

        vscode_mcp = project_path / ".vscode" / "mcp.json"
        if vscode_mcp.exists():
            try:
                config = json.loads(vscode_mcp.read_text())
                if "pongogo-knowledge" in config.get("servers", {}):
                    artifacts.append(vscode_mcp)
            except (json.JSONDecodeError, KeyError):
                pass

        hooks_file = project_path / ".github" / "hooks" / "pongogo.json"
        if hooks_file.exists():
            artifacts.append(hooks_file)

        agent_file = project_path / ".github" / "agents" / "pongogo.agent.md"
        if agent_file.exists():
            artifacts.append(agent_file)

        skills_dir = project_path / ".github" / "skills"
        if skills_dir.exists():
            for skill_dir in skills_dir.iterdir():
                if skill_dir.is_dir() and skill_dir.name.startswith("pongogo-"):
                    artifacts.append(skill_dir)

        prompts_dir = project_path / ".github" / "prompts"
        if prompts_dir.exists():
            artifacts.extend(prompts_dir.glob("pongogo-*.prompt.md"))

        return artifacts
