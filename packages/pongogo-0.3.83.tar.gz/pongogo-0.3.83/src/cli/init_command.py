"""The pongogo init command implementation."""

import json
import os
import re
import subprocess
from pathlib import Path

import typer

from .console import RICH_AVAILABLE, console, print_panel


# Version check import (lazy to avoid import issues)
def _check_for_updates_cli():
    """Check for updates and return message if available.

    Returns:
        Update message string if update available, None otherwise
    """
    # Skip version check if running from installer (we just installed latest)
    if os.environ.get("PONGOGO_FROM_INSTALLER"):
        return None

    try:
        from mcp_server.upgrade import check_for_updates

        if RICH_AVAILABLE:
            with console.status("[dim]Checking for updates...[/dim]", spinner="dots"):
                result = check_for_updates()
        else:
            print("Checking for updates...")
            result = check_for_updates()

        if result.update_available:
            if RICH_AVAILABLE:
                return (
                    f"\n[yellow]Update available:[/yellow] {result.current_version} → {result.latest_version}\n"
                    f"Run: [#5a9ae8]{result.upgrade_command}[/#5a9ae8]"
                )
            else:
                return (
                    f"\nUpdate available: {result.current_version} → {result.latest_version}\n"
                    f"Run: {result.upgrade_command}"
                )
    except Exception:
        pass  # Silently skip if version check fails
    return None


def get_git_root(cwd: Path) -> Path | None:
    """Find the root of the git repository.

    Returns:
        Path to git root, or None if not in a git repository.
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=cwd,
            capture_output=True,
            text=True,
            check=True,
        )
        return Path(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


from .adapters import detect_platforms, get_adapter
from .config import generate_config, write_config
from .instructions import (
    copy_instructions,
    copy_manifest,
    copy_slash_commands,
    get_enabled_categories,
    get_package_commands_dir,
    get_package_instructions_dir,
    load_manifest,
)
from .migrations import CURRENT_CONFIG_VERSION


# Import discovery system (lazy import to avoid circular dependencies)
def get_discovery_system():
    """Lazy import of DiscoverySystem to avoid circular imports."""
    import sys
    from pathlib import Path

    # Add mcp_server to path if needed
    mcp_server_path = Path(__file__).parent.parent / "mcp_server"
    if str(mcp_server_path) not in sys.path:
        sys.path.insert(0, str(mcp_server_path))
    from discovery_system import DiscoverySystem

    return DiscoverySystem


PONGOGO_DIR = ".pongogo"
CONFIG_FILE = "config.yaml"
INSTRUCTIONS_DIR = "instructions"


def ensure_project_venv(
    project_root: Path,
    version: str,
    install_method: str,
    *,
    console_output: bool = True,
) -> bool:
    """Ensure a project-local .venv exists with pongogo installed.

    This is needed for native mode hooks, which reference
    $CLAUDE_PROJECT_DIR/.venv/bin/pongogo-route.

    Args:
        project_root: Absolute path to the project root.
        version: Current pongogo version string.
        install_method: "pip", "homebrew", "docker", or "unknown".
        console_output: Whether to print progress messages.

    Returns:
        True if venv is ready (or not needed), False on failure.
    """
    # Docker mode: hooks use `docker exec`, no venv needed
    if install_method == "docker":
        return True

    # Dev version (editable install): .venv already exists in dev repo
    if version.endswith("-dev"):
        return True

    venv_dir = project_root / ".venv"
    venv_bin = venv_dir / "bin"
    pongogo_route = venv_bin / "pongogo-route"
    pip_path = venv_bin / "pip"

    # Check if venv exists AND is current version (Bug #687)
    # Previously only checked pongogo_route.exists(), which caused the venv
    # to stay at the version from initial `pongogo init` across upgrades.
    if pongogo_route.exists() and pip_path.exists():
        try:
            result = subprocess.run(
                [str(pip_path), "show", "pongogo"],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    if line.startswith("Version:"):
                        installed_version = line.split(":", 1)[1].strip()
                        if installed_version == version:
                            return True  # Version matches — skip
                        if console_output:
                            console.print(
                                f"  Updating project venv ({installed_version} → {version})..."
                            )
                        break
                else:
                    # pongogo not found in venv — fall through to install
                    pass
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass  # Can't check version — fall through to install

    if console_output and not pongogo_route.exists():
        console.print("  Setting up project virtualenv...")

    # Create venv if it doesn't exist yet
    if not venv_dir.exists():
        try:
            subprocess.run(
                ["python3", "-m", "venv", str(venv_dir)],
                capture_output=True,
                text=True,
                check=True,
            )
        except (subprocess.CalledProcessError, FileNotFoundError) as exc:
            if console_output:
                console.print(
                    f"  [yellow]Warning:[/yellow] Could not create .venv: {exc}"
                )
            return False

    # Install/upgrade pongogo into the venv
    if not pip_path.exists():
        if console_output:
            console.print(
                "  [yellow]Warning:[/yellow] .venv/bin/pip not found after venv creation"
            )
        return False

    # Detect PEP 440 pre-release (0.3.59a5, 0.3.59b3) or legacy format (0.3.59-alpha.1)
    is_prerelease = (
        bool(re.search(r"(a|b|rc)\d+", version))
        or "-alpha." in version
        or "-beta." in version
    )

    if version == "unknown":
        # Version undetectable (e.g., Homebrew Cellar where metadata isn't registered).
        # Try installing without version pin — pip will find the latest available.
        install_args = [
            str(pip_path),
            "install",
            "--quiet",
            "--pre",
            "--extra-index-url",
            "https://test.pypi.org/simple/",
            "pongogo",
        ]
        is_prerelease = True  # Enable retry for TestPyPI propagation
    elif is_prerelease:
        install_args = [
            str(pip_path),
            "install",
            "--quiet",
            "--pre",
            "--extra-index-url",
            "https://test.pypi.org/simple/",
            f"pongogo=={version}",
        ]
    else:
        install_args = [str(pip_path), "install", "--quiet", f"pongogo=={version}"]

    # Build install strategies: primary first, then fallbacks.
    # Versions not yet on PyPI (alpha/beta builds) need TestPyPI fallback.
    strategies = [install_args]
    if not is_prerelease and version != "unknown":
        # Stable version may not be on PyPI yet (alpha E2E uses stable version string).
        # Fallback: try TestPyPI with --pre and unpinned version.
        strategies.append(
            [
                str(pip_path),
                "install",
                "--quiet",
                "--pre",
                "--extra-index-url",
                "https://test.pypi.org/simple/",
                "pongogo",
            ]
        )

    # Pre-release installs from TestPyPI may need retries due to CDN propagation
    # delay — the wheel can be published but not yet available for pip resolve.
    max_attempts = 3 if is_prerelease else 1
    last_exc = None
    installed = False

    for strategy_idx, args in enumerate(strategies):
        last_exc = None
        for attempt in range(1, max_attempts + 1):
            try:
                subprocess.run(
                    args,
                    capture_output=True,
                    text=True,
                    check=True,
                )
                installed = True
                break
            except subprocess.CalledProcessError as exc:
                last_exc = exc
                if attempt < max_attempts:
                    import time

                    if console_output:
                        console.print(
                            f"  [dim]Retry {attempt}/{max_attempts}: "
                            f"waiting for TestPyPI propagation...[/dim]"
                        )
                    time.sleep(10 * attempt)  # 10s, 20s backoff
        if installed:
            break
        if strategy_idx < len(strategies) - 1 and console_output:
            console.print(
                "  [dim]Pinned version not found on PyPI, trying TestPyPI...[/dim]"
            )

    if not installed:
        if console_output and last_exc is not None:
            console.print(
                f"  [yellow]Warning:[/yellow] Could not install pongogo into .venv: "
                f"{last_exc.stderr.strip() if last_exc.stderr else last_exc}"
            )
        return False

    if console_output:
        console.print("  [green]Created[/green] .venv/ with pongogo entry points")

    return True


def refresh_hooks(project_root: Path) -> bool:
    """Write/merge hook configuration into the correct settings file.

    Reads mode, container_name, and platforms from .pongogo/config.yaml,
    then delegates to each configured platform adapter.

    Args:
        project_root: Absolute path to the project root.

    Returns:
        True on success, False if config.yaml is missing or unreadable.
    """
    import yaml

    config_path = project_root / ".pongogo" / CONFIG_FILE
    if not config_path.exists():
        return False

    try:
        with open(config_path) as f:
            config = yaml.safe_load(f) or {}
    except Exception:
        return False

    mode = config.get("mode", "native")
    container_name = config.get("container_name")
    platform_names = config.get("platforms", ["claude_code"])

    for name in platform_names:
        try:
            adapter = get_adapter(name)
        except ValueError:
            continue
        adapter.scaffold_hooks(
            project_path=project_root,
            mode=mode,
            container_name=container_name,
        )

    return True


def cleanup_stale_global_config() -> bool:
    """Remove stale pongogo-knowledge entries from ~/.claude.json.

    Old versions may have written config with ${workspaceFolder} to global config.
    This causes 'Missing environment variables' warnings in claude doctor.

    Returns:
        True if any cleanup was performed, False otherwise.
    """
    global_config_path = Path.home() / ".claude.json"
    if not global_config_path.exists():
        return False

    try:
        config = json.loads(global_config_path.read_text())
        modified = False

        # Check top-level mcpServers
        if "mcpServers" in config and "pongogo-knowledge" in config["mcpServers"]:
            del config["mcpServers"]["pongogo-knowledge"]
            modified = True

        # Check project-scoped entries under "projects" dict
        projects = config.get("projects", {})
        if isinstance(projects, dict):
            for project_config in projects.values():
                if isinstance(project_config, dict):
                    if (
                        "mcpServers" in project_config
                        and "pongogo-knowledge" in project_config["mcpServers"]
                    ):
                        del project_config["mcpServers"]["pongogo-knowledge"]
                        modified = True

        if modified:
            global_config_path.write_text(json.dumps(config, indent=2) + "\n")
            return True

    except (json.JSONDecodeError, PermissionError):
        pass  # Silently skip if we can't parse or write

    return False


# Common wiki/docs folder names to detect
WIKI_FOLDER_NAMES = ["wiki", "Wiki", ".wiki"]
DOCS_FOLDER_NAMES = ["docs", "Docs", "documentation", "Documentation"]


def detect_knowledge_folders(
    cwd: Path, git_root: Path | None = None
) -> tuple[Path | None, Path | None]:
    """Detect existing wiki and docs folders in the project.

    Searches both cwd and git root (if different) to find existing folders.
    This prevents creating duplicate wiki/docs when running from a subdirectory.

    Args:
        cwd: Current working directory
        git_root: Git repository root (if in a git repo)

    Returns:
        Tuple of (wiki_path, docs_path) - each is None if not found.
    """
    wiki_path = None
    docs_path = None

    # Search locations: cwd first, then git root if different
    search_locations = [cwd]
    if git_root and git_root != cwd:
        search_locations.append(git_root)

    for location in search_locations:
        if wiki_path is None:
            for name in WIKI_FOLDER_NAMES:
                candidate = location / name
                if candidate.is_dir():
                    wiki_path = candidate
                    break

        if docs_path is None:
            for name in DOCS_FOLDER_NAMES:
                candidate = location / name
                if candidate.is_dir():
                    docs_path = candidate
                    break

    return wiki_path, docs_path


def create_knowledge_folders(
    cwd: Path,
    wiki_path: Path | None,
    docs_path: Path | None,
) -> tuple[Path | None, Path | None]:
    """Create wiki/docs folders if missing.

    These folders are needed for Pongogo to work effectively - just create them
    automatically rather than asking the user.

    Returns:
        Tuple of (created_wiki_path, created_docs_path)

    Raises:
        PermissionError: If unable to create folders (with helpful message)
    """
    created_wiki = None
    created_docs = None

    # Create wiki if missing
    if wiki_path is None:
        created_wiki = cwd / "wiki"
        try:
            created_wiki.mkdir(exist_ok=True)
        except PermissionError:
            console.print(
                "\n[red]Error:[/red] Permission denied creating wiki/ folder.",
                style="bold",
            )
            console.print(
                "\n[yellow]This is likely a Docker volume permission issue.[/yellow]"
            )
            console.print("\nPossible fixes:")
            console.print(
                "  1. Check directory permissions: [#5a9ae8]ls -la $(pwd)[/#5a9ae8]"
            )
            console.print(
                "  2. On SELinux systems (Fedora/RHEL), try: [#5a9ae8]sudo chcon -Rt svirt_sandbox_file_t $(pwd)[/#5a9ae8]"
            )
            console.print("  3. Run with sudo: [#5a9ae8]sudo pongogo init[/#5a9ae8]")
            console.print(
                "\nFor more help, see: https://github.com/pongogo/pongogo/issues"
            )
            raise
        console.print("  [green]Created[/green] wiki/")

        # Create a starter file
        readme = created_wiki / "Home.md"
        if not readme.exists():
            readme.write_text(
                "# Project Wiki\n\n"
                "This folder is for strategic documentation:\n\n"
                "- **Architecture decisions** - Why things are built the way they are\n"
                "- **Strategic context** - High-level project direction\n"
                "- **Onboarding guides** - Help new contributors get started\n"
            )

    # Create docs if missing
    if docs_path is None:
        created_docs = cwd / "docs"
        try:
            created_docs.mkdir(exist_ok=True)
        except PermissionError:
            console.print(
                "\n[red]Error:[/red] Permission denied creating docs/ folder.",
                style="bold",
            )
            console.print(
                "\n[yellow]This is likely a Docker volume permission issue.[/yellow]"
            )
            console.print("\nPossible fixes:")
            console.print(
                "  1. Check directory permissions: [#5a9ae8]ls -la $(pwd)[/#5a9ae8]"
            )
            console.print(
                "  2. On SELinux systems (Fedora/RHEL), try: [#5a9ae8]sudo chcon -Rt svirt_sandbox_file_t $(pwd)[/#5a9ae8]"
            )
            console.print("  3. Run with sudo: [#5a9ae8]sudo pongogo init[/#5a9ae8]")
            console.print(
                "\nFor more help, see: https://github.com/pongogo/pongogo/issues"
            )
            raise
        console.print("  [green]Created[/green] docs/")

        # Create a starter README
        readme = created_docs / "README.md"
        if not readme.exists():
            readme.write_text(
                "# Documentation\n\n"
                "This folder is for technical documentation:\n\n"
                "- **API references** - How to use project APIs\n"
                "- **Setup guides** - Installation and configuration\n"
                "- **Architecture docs** - Technical design documents\n"
            )

    return created_wiki, created_docs


def init_command(
    minimal: bool = typer.Option(
        False,
        "--minimal",
        "-m",
        help="Only install core instruction categories (software_engineering, safety_prevention)",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Overwrite existing .pongogo directory",
    ),
    no_interactive: bool = typer.Option(
        False,
        "--no-interactive",
        "-y",
        help="Accept all defaults without prompting",
    ),
    platform: str = typer.Option(
        "auto",
        "--platform",
        help="Target platform: auto, claude_code, vscode (default: auto)",
    ),
    skip_update_check: bool = typer.Option(
        False,
        "--skip-update-check",
        help="Skip checking for updates (used by installer)",
        hidden=True,
    ),
) -> None:
    """Initialize Pongogo in the current directory.

    Creates a .pongogo/ directory with configuration and seeded instruction files.
    Files are created at the git repository root (if in a repo) or current directory.
    """
    cwd = Path.cwd()

    # Find git root first - all files should be created at repo root, not cwd
    git_root = get_git_root(cwd)
    project_root = git_root if git_root else cwd

    # --- guard: dev repo protection (#707) ---
    if not force:
        from .dev_guard import is_dev_repo

        if is_dev_repo(project_root):
            console.print(
                "[red]Error:[/red] Development repository detected.\n\n"
                "Running 'init' here would overwrite source-of-truth instruction files\n"
                "with distribution copies from the seed. Use --force to override.",
                style="bold",
            )
            raise typer.Exit(1)

    # --- guard: auth required (Epic #722) ---
    # DISABLED: Auth not yet ready for production distribution.
    # Re-enable when P11 auth milestone is complete and tested E2E.
    # See: https://github.com/pongogo/pongogo/issues/722
    # if os.environ.get("PONGOGO_AUTH_DISABLED") != "1":
    #     try:
    #         from auth.tokens import get_token_store
    #
    #         auth_state = get_token_store().get_state()
    #         if not auth_state.authenticated:
    #             console.print(
    #                 "[red]Error:[/red] Authentication required.\n\n"
    #                 "  Run [#5a9ae8]pongogo login[/#5a9ae8] to authenticate, then try again.\n",
    #                 style="bold",
    #             )
    #             raise typer.Exit(1)
    #     except ImportError:
    #         pass  # Auth module not available (shouldn't happen in normal installs)

    # Clean up stale global config from old versions
    # This prevents "Missing environment variables: workspaceFolder" warnings
    if cleanup_stale_global_config():
        console.print("[dim]Cleaned up stale config from ~/.claude.json[/dim]")

    # Inform user if running from subdirectory
    if git_root and git_root != cwd:
        console.print(
            f"[dim]Running from subdirectory, will create files at repo root: {git_root}[/dim]\n"
        )

    pongogo_dir = project_root / PONGOGO_DIR

    # Check for existing installation
    # PONGOGO_DIR_CREATED=1 means the bash wrapper just created .pongogo/ for the
    # daemon volume mount - proceed without requiring --force
    dir_created_by_wrapper = os.environ.get("PONGOGO_DIR_CREATED") == "1"
    if pongogo_dir.exists() and not dir_created_by_wrapper:
        if not force:
            console.print(
                f"[red]Error:[/red] {PONGOGO_DIR}/ already exists. "
                "Use --force to overwrite.",
                style="bold",
            )
            raise typer.Exit(1)
        else:
            console.print(
                f"[yellow]Overwriting existing {PONGOGO_DIR}/ directory...[/yellow]"
            )

            # Stop existing daemon before deleting .pongogo/ directory (Docker mode only).
            # Docker bind mounts reference the directory inode — if we delete
            # and recreate the directory, the running container's mount still
            # points to the old (deleted) inode and can't see new files.
            if os.environ.get("PONGOGO_CONTAINER_NAME"):
                from .container import get_container_name, stop_daemon

                old_container = get_container_name(project_root)
                stop_daemon(old_container)

            import shutil

            shutil.rmtree(pongogo_dir)

    # Resolve platform adapters early (needed for welcome panel)
    if platform == "auto":
        adapters = detect_platforms(project_root)
    else:
        try:
            adapters = [get_adapter(platform)]
        except ValueError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(1)

    has_claude_code = any(a.__class__.__name__ == "ClaudeCodeAdapter" for a in adapters)
    has_vscode = any(a.__class__.__name__ == "VsCodeAdapter" for a in adapters)

    # Detect existing knowledge folders BEFORE showing welcome
    # Check both cwd and git root to avoid creating duplicates when in subdirectory
    wiki_path, docs_path = detect_knowledge_folders(project_root, git_root)
    missing_folders = []
    if wiki_path is None:
        missing_folders.append("wiki/")
    if docs_path is None:
        missing_folders.append("docs/")

    # Build welcome message based on detected platform
    welcome_lines = [
        "[color(208)]Pongogo[/color(208)] - AI agent knowledge routing\n",
        "This will create:",
        "  [#5a9ae8].pongogo/[/#5a9ae8]",
        "    - config.yaml [dim](configuration)[/dim]",
        "    - instructions/ [dim](seeded instruction files)[/dim]",
        "    - pongogo.db [dim](routing events)[/dim]",
        "    - potential_improvements.db [dim](PI system)[/dim]",
    ]

    if has_claude_code:
        welcome_lines.extend(
            [
                "  [#5a9ae8].mcp.json[/#5a9ae8] [dim](MCP server config)[/dim]",
                "  [#5a9ae8].claude/[/#5a9ae8]",
                "    - settings.json [dim](routing hooks, git-tracked)[/dim]",
                "    - commands/ [dim](slash commands)[/dim]",
            ]
        )

    if has_vscode:
        welcome_lines.extend(
            [
                "  [#5a9ae8].vscode/[/#5a9ae8]",
                "    - mcp.json [dim](MCP server config)[/dim]",
                "  [#5a9ae8].github/[/#5a9ae8]",
                "    - hooks/ [dim](Copilot routing hooks)[/dim]",
                "    - agents/ [dim](agent definitions)[/dim]",
                "    - skills/ [dim](slash commands)[/dim]",
            ]
        )

    if missing_folders:
        welcome_lines.append("")
        for folder in missing_folders:
            welcome_lines.append(f"  [#5a9ae8]{folder}[/#5a9ae8]")

    # Show welcome message
    print_panel("Initializing Pongogo", "\n".join(welcome_lines), style="blue")

    # Interactive mode: confirm before proceeding
    if not no_interactive:
        if RICH_AVAILABLE:
            response = (
                console.input("\nContinue? [#5a9ae8][Y/n]:[/#5a9ae8] ").strip().lower()
            )
        else:
            response = input("\nContinue? [Y/n]: ").strip().lower()
        if response and response not in ("y", "yes"):
            console.print("[yellow]Installation cancelled.[/yellow]")
            raise typer.Exit(0)

    # Create wiki/docs folders if missing
    created_wiki, created_docs = create_knowledge_folders(
        project_root, wiki_path, docs_path
    )

    # Track created folders for config
    final_wiki = created_wiki or wiki_path
    final_docs = created_docs or docs_path

    # Generate configuration with detected/created paths
    console.print("\n[bold]Creating configuration...[/bold]")
    config = generate_config(
        minimal=minimal,
        wiki_path=f"{final_wiki.name}/" if final_wiki else None,
        docs_path=f"{final_docs.name}/" if final_docs else None,
        # container_name is set later after daemon starts, then config is re-written
    )

    config_path = pongogo_dir / CONFIG_FILE
    write_config(config_path, config)
    console.print(f"  [green]Created[/green] {PONGOGO_DIR}/{CONFIG_FILE}")

    # Create .gitignore to exclude local databases (contain user-specific data)
    gitignore_path = pongogo_dir / ".gitignore"
    gitignore_content = """# Pongogo local state (not version controlled)
# Main database with routing events, observations, artifacts
pongogo.db
pongogo.db-wal
pongogo.db-shm

# PI system database (user guidance, improvements)
potential_improvements.db
potential_improvements.db-wal
potential_improvements.db-shm

# Seed manifest (tracks which files were seeded, per-machine state)
seed_manifest.json

# Path enforcement index (generated from instruction files)
path_enforcement_index.json

# Ingestion scan state (per-machine, tracks which Copilot files were scanned)
ingestion_state.json

# VS Code optimized instruction copies (generated from source files)
instructions/vscode-optimized/
"""
    gitignore_path.write_text(gitignore_content)
    console.print(f"  [green]Created[/green] {PONGOGO_DIR}/.gitignore")

    # Initialize empty databases with schema (so health checks pass)
    console.print("\n[bold]Initializing databases...[/bold]")

    # Initialize pongogo.db (routing events, observations)
    try:
        from mcp_server.database import PongogoDatabase

        PongogoDatabase(project_root=project_root)
        console.print(f"  [green]Created[/green] {PONGOGO_DIR}/pongogo.db")
        console.print("  [dim]Ready to capture routing events and observations[/dim]")
    except Exception as e:
        # Database init is optional - don't fail init if it errors
        console.print(
            f"  [yellow]Warning:[/yellow] Could not initialize pongogo.db: {e}"
        )
        console.print("  [dim]Database will be created on first routing event[/dim]")

    # Initialize potential_improvements.db (PI system, user guidance)
    try:
        from mcp_server.pi_system import PIDatabase

        pi_db_path = pongogo_dir / "potential_improvements.db"
        PIDatabase(db_path=pi_db_path)
        console.print(
            f"  [green]Created[/green] {PONGOGO_DIR}/potential_improvements.db"
        )
        console.print("  [dim]Ready to track user guidance and improvements[/dim]")
    except Exception as e:
        # Database init is optional - don't fail init if it errors
        console.print(
            f"  [yellow]Warning:[/yellow] Could not initialize potential_improvements.db: {e}"
        )
        console.print("  [dim]Database will be created on first PI operation[/dim]")

    # Eagerly create consolidated user-level DB at ~/.pongogo/pongogo.db (Issue #679)
    # This ensures tutorial tables exist before the MCP server starts,
    # eliminating the lazy-creation failure class exposed by Bug #675.
    try:
        from .installations import (
            ensure_installations_schema as _ensure_user_schema,
        )
        from .installations import (
            get_installations_db_path as _get_user_db_path,
        )
        from .installations import (
            migrate_from_legacy_db as _migrate_legacy,
        )

        user_db = _get_user_db_path()
        _ensure_user_schema(user_db)
        migrated = _migrate_legacy(user_db)
        if migrated > 0:
            console.print(
                f"  [green]Migrated[/green] {migrated} installation(s) from legacy DB"
            )
        console.print(
            "  [green]Created[/green] ~/.pongogo/pongogo.db [dim](user-level)[/dim]"
        )
    except Exception as e:
        console.print(
            f"  [yellow]Warning:[/yellow] Could not initialize user-level DB: {e}"
        )

    # Initialize memory system (Issue #700)
    console.print("\n[bold]Initializing memory system...[/bold]")
    try:
        from mcp_server.memory import bootstrap_from_claude_code, ensure_memory_dir

        ensure_memory_dir(project_root)
        console.print(f"  [green]Created[/green] {PONGOGO_DIR}/memory/")

        bootstrapped = bootstrap_from_claude_code(project_root)
        if bootstrapped:
            console.print(
                "  [green]Bootstrapped[/green] memory from Claude Code MEMORY.md"
            )
        else:
            console.print(
                "  [dim]No existing Claude Code memory found (empty memory initialized)[/dim]"
            )
    except Exception as e:
        console.print(
            f"  [yellow]Warning:[/yellow] Could not initialize memory system: {e}"
        )
        console.print("  [dim]Memory will be created on first use[/dim]")

    # Copy instruction files
    console.print("\n[bold]Copying instruction files...[/bold]")

    try:
        source_dir = get_package_instructions_dir()
        manifest = load_manifest(source_dir)
    except FileNotFoundError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    dest_instructions_dir = pongogo_dir / INSTRUCTIONS_DIR
    enabled_categories = get_enabled_categories(manifest, config["categories"])

    files_copied, instruction_files = copy_instructions(
        source_dir=source_dir,
        dest_dir=dest_instructions_dir,
        manifest=manifest,
        enabled_categories=enabled_categories,
    )

    # Copy manifest
    copy_manifest(source_dir, dest_instructions_dir)

    # Build path enforcement index (Issue #682)
    try:
        from mcp_server.compliance.path_index import build_index, write_index

        path_index = build_index(dest_instructions_dir)
        write_index(pongogo_dir, path_index)
        index_count = len(path_index.get("entries", []))
        if index_count > 0:
            console.print(
                f"  [green]Created[/green] {PONGOGO_DIR}/path_enforcement_index.json "
                f"[dim]({index_count} path-enforced instructions)[/dim]"
            )
    except Exception as e:
        console.print(
            f"  [yellow]Warning:[/yellow] Could not build path enforcement index: {e}"
        )

    # Core instructions (10) are bundled separately, always available
    core_count = 10
    total_count = files_copied + core_count
    console.print(
        f"  [green]Seeded[/green] {total_count} instruction files "
        f"[dim]({files_copied} seeded + {core_count} core)[/dim]"
    )
    console.print(
        "  [dim]Covers: engineering, project management, agentic workflows,[/dim]"
    )
    console.print(
        "  [dim]architecture, quality, security, testing, DevOps, and more.[/dim]"
    )
    console.print(
        "  [dim]Core instructions include enforcement rules for procedural workflows.[/dim]"
    )
    console.print(
        "  [dim]These instructions evolve and adapt organically through usage.[/dim]"
    )

    # Copy slash commands to .claude/commands/ (only for Claude Code adapter)
    commands_copied = 0
    command_files: list[tuple[str, Path]] = []
    if has_claude_code:
        console.print("\n[bold]Installing slash commands...[/bold]")
        claude_commands_dir = project_root / ".claude" / "commands"
        commands_copied, command_files = copy_slash_commands(claude_commands_dir)
        if commands_copied > 0:
            console.print(
                f"  [green]Installed[/green] {commands_copied} slash commands"
            )
            console.print(
                "  Use [#5a9ae8]/pongogo-status[/#5a9ae8], [#5a9ae8]/pongogo-conduct-retro[/#5a9ae8], [#5a9ae8]/pongogo-add-work-log-entry[/#5a9ae8], and more."
            )
        else:
            console.print("  [yellow]No slash commands found in package[/yellow]")

    # Generate seed manifest (tracks which files were seeded with content hashes)
    try:
        from mcp_server.upgrade import get_current_version

        from .seed_manifest import generate_seed_manifest, write_seed_manifest

        all_seeded = instruction_files + command_files
        seed_manifest_data = generate_seed_manifest(all_seeded, get_current_version())
        write_seed_manifest(pongogo_dir, seed_manifest_data)
        console.print(
            f"\n  [green]Created[/green] {PONGOGO_DIR}/seed_manifest.json "
            f"[dim]({len(seed_manifest_data['files'])} files tracked)[/dim]"
        )
    except Exception as e:
        console.print(
            f"  [yellow]Warning:[/yellow] Could not generate seed manifest: {e}"
        )

    # Determine execution mode: native (pip/brew) vs Docker
    # PONGOGO_CONTAINER_NAME is set by the Docker bash wrapper — its presence means Docker mode
    native_mode = os.environ.get("PONGOGO_CONTAINER_NAME") is None
    container_name = os.environ.get("PONGOGO_CONTAINER_NAME")
    mode_str = "native" if native_mode else "docker"

    if native_mode:
        console.print("\n[bold]Running natively (no Docker required)[/bold]")
    else:
        # Docker mode — start/use daemon container
        console.print("\n[bold]Configuring daemon container...[/bold]")

        # Use HOST path for Docker volume mount
        host_project_dir = os.environ.get("HOST_PROJECT_DIR")
        if host_project_dir:
            hook_pongogo_path = f"{host_project_dir}/.pongogo"
        else:
            hook_pongogo_path = str(pongogo_dir.resolve())

        # Get Docker image - baked into image at build time by CI/CD
        # Each release channel (beta/stable) has its identity set at build time
        pongogo_image = os.environ.get(
            "PONGOGO_IMAGE", "pongogo.azurecr.io/pongogo:stable"
        )

        if container_name:
            # Daemon already running (started by bash wrapper)
            console.print(f"  [green]Using[/green] daemon container: {container_name}")
        else:
            # Development mode or direct Python execution - start daemon ourselves
            # Capture uid/gid at init time for proper container permissions
            # When running in Docker, HOST_UID/HOST_GID contain the actual host user's ID
            # (os.getuid() would return container user ID 999, not host user)
            uid = int(os.environ.get("HOST_UID", os.getuid()))
            gid = int(os.environ.get("HOST_GID", os.getgid()))

            from .container import build_labels, get_container_name, start_daemon

            container_name = get_container_name(project_root)
            labels = build_labels(project_root, pongogo_image)

            if start_daemon(
                container_name,
                project_root,
                hook_pongogo_path,
                pongogo_image,
                uid,
                gid,
                labels,
            ):
                console.print(
                    f"  [green]Started[/green] daemon container: {container_name}"
                )
            else:
                console.print(
                    f"  [yellow]Warning:[/yellow] Could not start daemon container: {container_name}"
                )
                console.print(
                    "  [dim]Hooks and MCP will still work but may use ephemeral containers[/dim]"
                )

    # Store mode, container name, and schema version in config
    config["mode"] = "native" if native_mode else "docker"
    config["container_name"] = container_name
    config["config_schema_version"] = CURRENT_CONFIG_VERSION
    config["platforms"] = [a.platform_name() for a in adapters]
    write_config(config_path, config)

    # Create project venv for native mode (Issue #681)
    # Hooks reference $CLAUDE_PROJECT_DIR/.venv/bin/pongogo-route — the venv must exist.
    if native_mode:
        try:
            from mcp_server.upgrade import detect_install_method, get_current_version

            ensure_project_venv(
                project_root,
                get_current_version(),
                detect_install_method().value,
            )
        except Exception:
            pass  # Non-fatal; hooks may still work if pongogo is on PATH

    # Scaffold hooks via platform adapter
    console.print("\n[bold]Configuring automatic routing hook...[/bold]")
    for adapter in adapters:
        hooks_result = adapter.scaffold_hooks(
            project_path=project_root,
            mode=mode_str,
            container_name=container_name,
        )
        for path in hooks_result.files_written + hooks_result.files_merged:
            console.print(
                f"  [green]Configured[/green] {path.relative_to(project_root)}"
            )
    console.print(
        "  [dim]Routing runs automatically on each message - no tool calls needed[/dim]"
    )

    # Scan repository for existing knowledge patterns (silently skip if nothing found)
    try:
        DiscoverySystem = get_discovery_system()
        ds = DiscoverySystem(cwd)
        scan_result = ds.scan_repository()
        # Only show discovery section if we found something interesting
        if scan_result and scan_result.total_discoveries > 0:
            console.print("\n[bold]Discovered repository knowledge:[/bold]")
            discovery_summary = ds.format_scan_summary(scan_result)
            console.print(discovery_summary)
    except Exception:
        pass  # Silently skip - discovery is optional enhancement

    # Scaffold MCP config via platform adapter
    console.print("\n[bold]Configuring MCP server...[/bold]")
    for adapter in adapters:
        mcp_result = adapter.scaffold_mcp(
            project_path=project_root,
            mode=mode_str,
            container_name=container_name,
        )
        for path in mcp_result.files_written:
            console.print(f"  [green]Created[/green] {path.relative_to(project_root)}")
        for path in mcp_result.files_merged:
            console.print(f"  [green]Updated[/green] {path.relative_to(project_root)}")

    # Scaffold platform-specific settings (e.g. VS Code instruction references)
    for adapter in adapters:
        settings_result = adapter.scaffold_settings(project_path=project_root)
        for path in settings_result.files_written:
            console.print(f"  [green]Created[/green] {path.relative_to(project_root)}")
        for path in settings_result.files_merged:
            console.print(f"  [green]Updated[/green] {path.relative_to(project_root)}")

    # Scaffold agent definitions and skills/prompts
    for adapter in adapters:
        try:
            agent_result = adapter.scaffold_agent(project_path=project_root)
            for path in agent_result.files_written:
                console.print(
                    f"  [green]Created[/green] {path.relative_to(project_root)}"
                )
        except Exception:
            pass  # Non-fatal; not all adapters may support agents

        try:
            # Use package source directly (not .claude/commands/ which is Claude Code-specific)
            pkg_commands = get_package_commands_dir()
            if pkg_commands is None:
                continue
            skills_result = adapter.scaffold_skills(
                project_path=project_root,
                source_dir=pkg_commands,
            )
            for path in skills_result.files_written:
                console.print(
                    f"  [green]Created[/green] {path.relative_to(project_root)}"
                )
        except Exception:
            pass  # Non-fatal; not all adapters may support skills

    # Scan for Copilot instruction files (Issue #712)
    github_instructions_dir = project_root / ".github" / "instructions"
    if github_instructions_dir.exists():
        console.print("\n[bold]Scanning Copilot instructions...[/bold]")
        try:
            from mcp_server.ingestion import run_ingestion

            result = run_ingestion(project_root, auto_import=True)
            scanned = result["scanned"]
            new_count = len(result["new"])
            dup_count = len(result["duplicates"])
            imported = [
                i for i in result.get("imported", []) if i["action"] == "imported"
            ]

            if scanned > 0:
                console.print(
                    f"  [green]Scanned[/green] {scanned} file(s) in .github/instructions/"
                )
                if imported:
                    console.print(
                        f"  [green]Imported[/green] {len(imported)} instruction(s) into Pongogo"
                    )
                    for i in imported:
                        console.print(f"    • {i['source']} → {i['dest']}")
                    console.print(
                        "  [dim]Imported files are now routable by Pongogo[/dim]"
                    )
                elif new_count > 0:
                    console.print(
                        f"  [dim]{new_count} instruction(s) already imported[/dim]"
                    )
                if dup_count > 0:
                    console.print(
                        f"  [dim]{dup_count} file(s) already covered by Pongogo instructions[/dim]"
                    )
        except Exception as e:
            console.print(
                f"  [yellow]Warning:[/yellow] Could not scan Copilot instructions: {e}"
            )

    # Register this installation in the machine-wide registry
    try:
        from mcp_server.upgrade import detect_install_method, get_current_version

        from .installations import register_installation

        register_installation(
            project_root=project_root,
            version=get_current_version(),
            install_method=detect_install_method().value,
        )
    except Exception:
        pass  # Registration is best-effort; don't fail init

    # Get repo name from current directory
    repo_name = project_root.name

    # Build success message with created folders and their purposes
    created_lines = [f"[green]Pongogo is now initialized in {repo_name}![/green]\n"]

    created_lines.append(f"Created: {PONGOGO_DIR}/")
    created_lines.append(
        f"  - {CONFIG_FILE} [dim](auto-configured, no edits needed)[/dim]"
    )
    created_lines.append(
        f"  - {INSTRUCTIONS_DIR}/ [dim]({total_count} instructions: {files_copied} seeded + {core_count} core)[/dim]"
    )
    created_lines.append("  - pongogo.db [dim](routing events database)[/dim]")
    created_lines.append(
        "  - potential_improvements.db [dim](PI system database)[/dim]"
    )
    created_lines.append("  - .gitignore [dim](excludes local database)[/dim]")
    # Platform-specific artifacts in success summary
    if has_claude_code:
        created_lines.append("")
        created_lines.append(
            "Created: .mcp.json [dim](MCP server config for Claude Code)[/dim]"
        )
        created_lines.append("")
        if mode_str == "native":
            settings_file = ".claude/settings.json"
        else:
            settings_file = ".claude/settings.local.json"
        created_lines.append(
            f"Created: {settings_file} [dim](automatic routing hook)[/dim]"
        )
        if commands_copied > 0:
            created_lines.append("")
            created_lines.append(
                f"Created: .claude/commands/ ({commands_copied} slash commands)"
            )

    if has_vscode:
        created_lines.append("")
        created_lines.append(
            "Created: .vscode/mcp.json [dim](MCP server config for VS Code)[/dim]"
        )
        created_lines.append(
            "Created: .github/hooks/ [dim](Copilot routing hooks)[/dim]"
        )
        created_lines.append("Created: .github/agents/ [dim](agent definitions)[/dim]")
        created_lines.append("Created: .github/skills/ [dim](slash commands)[/dim]")

    if created_wiki or created_docs:
        created_lines.append("")
        if created_wiki:
            created_lines.append(
                "  - [#5a9ae8]wiki/[/#5a9ae8] - Knowledge repository for institutional learnings"
            )
        if created_docs:
            created_lines.append(
                "  - [#5a9ae8]docs/[/#5a9ae8] - Information to help developers and agents "
                "work effectively"
            )

    created_lines.append("")
    if has_vscode and not has_claude_code:
        created_lines.append(
            "[dim]Next:[/dim] Restart VS Code. The "
            "[#5a9ae8]pongogo-knowledge[/#5a9ae8] MCP server will activate automatically."
        )
    else:
        created_lines.append(
            "[dim]Next:[/dim] Restart Claude Code. When prompted, allow the "
            "[#5a9ae8]pongogo-knowledge[/#5a9ae8] MCP server."
        )
    created_lines.append(
        "[dim]      Run [#5a9ae8]/pongogo-getting-started[/#5a9ae8] for an interactive guide.[/dim]"
    )
    created_lines.append("")
    created_lines.append(
        "[dim]Tip:[/dim]  Run [#5a9ae8]/pongogo-upgrade[/#5a9ae8] periodically to stay up to date."
    )
    created_lines.append("")
    created_lines.append("[dim]Learn more:[/dim] https://pongogo.com")

    # Success message
    print_panel("Ready", "\n".join(created_lines), style="green")

    # Check for updates (non-blocking, fails silently)
    # Skipped if --skip-update-check flag or PONGOGO_FROM_INSTALLER env var is set
    if not skip_update_check:
        update_msg = _check_for_updates_cli()
        if update_msg:
            console.print(update_msg)
