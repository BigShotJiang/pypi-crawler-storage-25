"""Dev source sync — detect and fix stale installs in the dev environment.

PI-472: The running MCP server can silently use stale site-packages code
while unit tests pass (they import from src/ directly). This module
provides detection and auto-fix logic used by:

- `pongogo dev sync` CLI command
- `scripts/dev-server.sh` auto-fix on startup
- `scripts/git-hooks/post-checkout` hook
"""

import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class SyncStatus:
    """Result of checking dev source sync state."""

    is_editable: bool
    module_path: str
    is_stale: bool
    needs_reinstall: bool
    venv_pip: str
    reason: str = ""


def get_venv_pip(project_root: Path | None = None) -> str:
    """Get the path to .venv/bin/pip."""
    root = project_root or Path.cwd()
    return str(root / ".venv" / "bin" / "pip")


def get_venv_python(project_root: Path | None = None) -> str:
    """Get the path to .venv/bin/python."""
    root = project_root or Path.cwd()
    return str(root / ".venv" / "bin" / "python")


def check_sync(project_root: Path | None = None) -> SyncStatus:
    """Check whether the dev install is editable and current.

    Returns a SyncStatus with diagnosis details.
    """
    root = project_root or Path.cwd()
    venv_pip = get_venv_pip(root)
    venv_python = get_venv_python(root)

    if not Path(venv_pip).exists():
        return SyncStatus(
            is_editable=False,
            module_path="",
            is_stale=True,
            needs_reinstall=True,
            venv_pip=venv_pip,
            reason="No .venv found",
        )

    # Check if editable
    is_editable = False
    try:
        result = subprocess.run(
            [venv_pip, "list", "--editable"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        is_editable = "pongogo" in result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    # Check where module loads from
    module_path = "unknown"
    try:
        result = subprocess.run(
            [
                venv_python,
                "-c",
                "import mcp_server.server; print(mcp_server.server.__file__)",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            module_path = result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    is_stale = "site-packages" in module_path
    needs_reinstall = not is_editable or is_stale

    if not is_editable:
        reason = "Not an editable install — server runs from site-packages copy"
    elif is_stale:
        reason = "Editable flag set but module loads from site-packages"
    else:
        reason = ""

    return SyncStatus(
        is_editable=is_editable,
        module_path=module_path,
        is_stale=is_stale,
        needs_reinstall=needs_reinstall,
        venv_pip=venv_pip,
        reason=reason,
    )


def fix_sync(project_root: Path | None = None, quiet: bool = False) -> bool:
    """Run editable install to fix a stale dev environment.

    Returns True if the fix succeeded.
    """
    root = project_root or Path.cwd()
    venv_pip = get_venv_pip(root)

    cmd = [venv_pip, "install", "-e", ".[dev]"]
    if quiet:
        cmd.append("-q")

    try:
        result = subprocess.run(
            cmd,
            cwd=str(root),
            capture_output=not quiet,
            text=True,
            timeout=120,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def sync_if_needed(
    project_root: Path | None = None, quiet: bool = False
) -> tuple[bool, str]:
    """Check and fix sync in one call. Returns (was_fixed, message)."""
    status = check_sync(project_root)

    if not status.needs_reinstall:
        return False, "Dev install is current — source and server in sync."

    success = fix_sync(project_root, quiet=quiet)

    if success:
        return True, f"Fixed: ran editable install. {status.reason}"
    else:
        return (
            False,
            f"Fix failed: could not run editable install. Run manually: {status.venv_pip} install -e '.[dev]'",
        )
