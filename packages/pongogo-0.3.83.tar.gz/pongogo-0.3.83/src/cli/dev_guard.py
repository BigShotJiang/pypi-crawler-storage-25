"""Dev repo detection and dev mode guard.

Prevents seed sync, init, and upgrade from accidentally overwriting
source-of-truth files in the Pongogo development repository.

Also provides identity-aware mode detection (AD-020, #729):
dev mode requires both a developer role AND being in the dev repo.

See #707 for motivation and design.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from auth.tokens import AuthState

logger = logging.getLogger(__name__)

# If 2+ of these exist at project root, this is the dev repo.
DEV_REPO_MARKERS = [
    "src/cli/__init__.py",
    "src/mcp_server/__init__.py",
    "seed/instructions.jsonl",
]

_THRESHOLD = 2


def is_dev_repo(project_path: Path) -> bool:
    """Return True if *project_path* looks like the Pongogo dev repo."""
    count = sum(1 for m in DEV_REPO_MARKERS if (project_path / m).exists())
    return count >= _THRESHOLD


def is_dev_mode(auth_state: AuthState, project_path: Path) -> bool:
    """True only if user has developer role AND is in dev repo.

    Neither signal alone is sufficient:
    - Developer in user project = user mode (no dev commands)
    - Non-developer in dev repo = user mode + warning
    """
    has_dev_role = "developer" in auth_state.cli_roles
    in_dev_repo = is_dev_repo(project_path)

    if not has_dev_role and in_dev_repo:
        logger.warning("Non-developer user in dev repo — operating in user mode")

    return has_dev_role and in_dev_repo
