"""Installation registry and consolidated user-level database for Pongogo.

Tracks all Pongogo installations on the machine so upgrade sync
can propagate updated seed content to every project. Also hosts
tutorial state tables (tutorial_progress, tutorial_nudge_log) in the
same database to eliminate a separate lazy-created DB failure class.

Stored at ~/.pongogo/pongogo.db (machine-wide, not per-project).

Epic #304: Post-Upgrade Seed Sync
Task #666: Installation Registry
Issue #679: Consolidate User-Level Databases
"""

import logging
from datetime import UTC, datetime
from pathlib import Path

from mcp_server.database.connection import get_connection

logger = logging.getLogger(__name__)

SCHEMA_VERSION = 3


def get_installations_db_path() -> Path:
    """Get path to the machine-wide consolidated user database.

    Creates ~/.pongogo/ directory if needed.

    Returns:
        Path to ~/.pongogo/pongogo.db
    """
    home_pongogo = Path.home() / ".pongogo"
    home_pongogo.mkdir(parents=True, exist_ok=True)
    return home_pongogo / "pongogo.db"


def ensure_installations_schema(db_path: Path) -> None:
    """Create all user-level tables if they don't exist.

    Creates the installations table (registry) and tutorial tables
    (tutorial_progress, tutorial_nudge_log) in the consolidated
    ~/.pongogo/pongogo.db database.

    Uses PRAGMA user_version for schema versioning.

    Args:
        db_path: Path to the consolidated user database.
    """
    with get_connection(db_path) as conn:
        # All table creation uses IF NOT EXISTS — safe to run on any version.
        conn.execute("""
            CREATE TABLE IF NOT EXISTS installations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_root TEXT NOT NULL UNIQUE,
                installed_at TEXT NOT NULL,
                last_synced_at TEXT,
                pongogo_version TEXT,
                install_method TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tutorial_progress (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                step_id TEXT NOT NULL UNIQUE,
                step_title TEXT,
                completed_at TEXT,
                evidence TEXT,
                session_id TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tutorial_nudge_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                nudge_type TEXT NOT NULL,
                nudge_timestamp TEXT NOT NULL,
                pongogo_version TEXT
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_nudge_log_session
                ON tutorial_nudge_log(session_id)
        """)
        # v3: User preferences table (Epic #724 - Auth & Settings)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS user_preferences (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")


def migrate_from_legacy_db(db_path: Path) -> int:
    """Migrate data from legacy ~/.pongogo/installations.db if it exists.

    Copies installation rows into the consolidated pongogo.db via
    INSERT OR IGNORE, then renames the legacy file to installations.db.migrated.

    Args:
        db_path: Path to the consolidated user database (pongogo.db).

    Returns:
        Number of rows migrated (0 if no legacy DB found).
    """
    legacy_path = db_path.parent / "installations.db"
    if not legacy_path.exists():
        return 0

    migrated = 0
    try:
        with get_connection(legacy_path, readonly=True) as legacy_conn:
            # Check if installations table exists in legacy DB
            table_check = legacy_conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='installations'"
            ).fetchone()
            if not table_check:
                # No installations table — just rename and return
                legacy_path.rename(legacy_path.with_suffix(".db.migrated"))
                return 0

            rows = legacy_conn.execute(
                "SELECT project_root, installed_at, last_synced_at, pongogo_version, install_method "
                "FROM installations"
            ).fetchall()

        if rows:
            with get_connection(db_path) as conn:
                for row in rows:
                    cursor = conn.execute(
                        """INSERT OR IGNORE INTO installations
                           (project_root, installed_at, last_synced_at, pongogo_version, install_method)
                           VALUES (?, ?, ?, ?, ?)""",
                        (
                            row["project_root"],
                            row["installed_at"],
                            row["last_synced_at"],
                            row["pongogo_version"],
                            row["install_method"],
                        ),
                    )
                    migrated += cursor.rowcount

        legacy_path.rename(legacy_path.with_suffix(".db.migrated"))
        logger.info(
            "Issue #679: Migrated %d row(s) from legacy installations.db", migrated
        )
    except Exception:
        logger.warning("Issue #679: Legacy migration failed", exc_info=True)

    return migrated


def register_installation(
    project_root: Path | str,
    version: str,
    install_method: str,
    db_path: Path | None = None,
) -> None:
    """Register or update a Pongogo installation.

    Args:
        project_root: Absolute path to the project root.
        version: Pongogo version string.
        install_method: How Pongogo was installed (pip, homebrew, docker).
        db_path: Override database path (for testing). Defaults to ~/.pongogo/pongogo.db.
    """
    if db_path is None:
        db_path = get_installations_db_path()
    ensure_installations_schema(db_path)

    now = datetime.now(UTC).isoformat()
    project_root_str = str(Path(project_root).resolve())

    with get_connection(db_path) as conn:
        conn.execute(
            """
            INSERT INTO installations (project_root, installed_at, last_synced_at, pongogo_version, install_method)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(project_root) DO UPDATE SET
                last_synced_at = excluded.last_synced_at,
                pongogo_version = excluded.pongogo_version,
                install_method = excluded.install_method
            """,
            (project_root_str, now, now, version, install_method),
        )


def deregister_installation(
    project_root: Path | str,
    db_path: Path | None = None,
) -> bool:
    """Remove a Pongogo installation from the registry.

    Args:
        project_root: Absolute path to the project root.
        db_path: Override database path (for testing).

    Returns:
        True if a row was deleted, False if not found.
    """
    if db_path is None:
        db_path = get_installations_db_path()
    ensure_installations_schema(db_path)

    project_root_str = str(Path(project_root).resolve())

    with get_connection(db_path) as conn:
        cursor = conn.execute(
            "DELETE FROM installations WHERE project_root = ?",
            (project_root_str,),
        )
        return cursor.rowcount > 0


def list_installations(db_path: Path | None = None) -> list[dict]:
    """List all registered Pongogo installations.

    Args:
        db_path: Override database path (for testing).

    Returns:
        List of installation dicts.
    """
    if db_path is None:
        db_path = get_installations_db_path()
    ensure_installations_schema(db_path)

    with get_connection(db_path, readonly=True) as conn:
        rows = conn.execute(
            "SELECT project_root, installed_at, last_synced_at, pongogo_version, install_method "
            "FROM installations ORDER BY installed_at"
        ).fetchall()
        return [dict(row) for row in rows]


def prune_stale_installations(db_path: Path | None = None) -> int:
    """Remove installations where .pongogo/ no longer exists.

    Args:
        db_path: Override database path (for testing).

    Returns:
        Number of pruned entries.
    """
    if db_path is None:
        db_path = get_installations_db_path()
    ensure_installations_schema(db_path)

    installations = list_installations(db_path)
    pruned = 0

    for inst in installations:
        project_root = Path(inst["project_root"])
        pongogo_dir = project_root / ".pongogo"
        if not pongogo_dir.exists():
            with get_connection(db_path) as conn:
                conn.execute(
                    "DELETE FROM installations WHERE project_root = ?",
                    (str(project_root),),
                )
            pruned += 1

    return pruned
