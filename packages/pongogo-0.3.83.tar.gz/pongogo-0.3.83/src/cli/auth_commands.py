"""Pongogo auth CLI commands: login, logout, whoami, register.

Implements OAuth 2.0 Device Code flow for CLI authentication
against possibility.space Keycloak, and self-service registration
via the possibility.space API.

Epic #721: CLI Device Code Auth Flow (Tasks 2-4)
"""

from __future__ import annotations

import json
import webbrowser

import typer

from .console import RICH_AVAILABLE, console, print_error, print_success, print_warning


def login_command(
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't automatically open browser (just display URL)",
    ),
    output_json: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output result as JSON",
    ),
) -> None:
    """Log in to Pongogo via browser-based authentication.

    Opens your browser to authenticate with possibility.space.
    A one-time code is displayed — enter it in the browser to confirm.

    Same pattern as `gh auth login` and `az login`.
    """
    from datetime import UTC, datetime, timedelta

    from auth.device_flow import (
        DeviceCodeDenied,
        DeviceCodeExpired,
        DeviceFlowError,
        fetch_userinfo,
        poll_for_token,
        request_device_code,
    )
    from auth.identity import save_cached_identity
    from auth.tokens import get_token_store

    # Check if already logged in
    store = get_token_store()
    state = store.get_state()
    if state.authenticated and not state.is_expired:
        if output_json:
            console.print(
                json.dumps({"status": "already_logged_in", "name": state.display_name})
            )
            return
        print_success(f"Already logged in as {state.display_name or 'unknown'}")
        console.print("  Run [bold]pongogo logout[/bold] first to switch accounts.")
        return

    # Step 1: Request device code
    console.print()
    try:
        dc = request_device_code()
    except DeviceFlowError as e:
        print_error(f"Could not start login: {e}")
        raise typer.Exit(1)

    # Step 2: Display code and open browser
    display_uri = dc.verification_uri_complete or dc.verification_uri

    console.print("[bold]Log in to Pongogo[/bold]")
    console.print()
    console.print(f"  1. Open:  [bold]{display_uri}[/bold]")
    console.print(f"  2. Enter: [bold orang]{dc.user_code}[/bold orang]")
    console.print()

    if not no_browser:
        try:
            webbrowser.open(display_uri)
            console.print("  [dim]Browser opened automatically.[/dim]")
        except Exception:
            console.print(
                "  [dim]Could not open browser — please visit the URL above.[/dim]"
            )
    console.print()

    # Step 3: Poll for token
    if RICH_AVAILABLE:
        with console.status(
            "[dim]Waiting for browser authorization...[/dim]", spinner="dots"
        ):
            try:
                token = poll_for_token(
                    device_code=dc.device_code,
                    interval=dc.interval,
                    expires_in=dc.expires_in,
                )
            except DeviceCodeExpired:
                print_error("Login timed out. Please try again.")
                raise typer.Exit(1)
            except DeviceCodeDenied:
                print_error("Login was denied.")
                raise typer.Exit(1)
            except DeviceFlowError as e:
                print_error(f"Login failed: {e}")
                raise typer.Exit(1)
    else:
        console.print("Waiting for browser authorization...")
        try:
            token = poll_for_token(
                device_code=dc.device_code,
                interval=dc.interval,
                expires_in=dc.expires_in,
            )
        except DeviceCodeExpired:
            print_error("Login timed out. Please try again.")
            raise typer.Exit(1)
        except DeviceCodeDenied:
            print_error("Login was denied.")
            raise typer.Exit(1)
        except DeviceFlowError as e:
            print_error(f"Login failed: {e}")
            raise typer.Exit(1)

    # Step 4: Store tokens
    expires_at = datetime.now(UTC) + timedelta(seconds=token.expires_in)
    store.store(
        access_token=token.access_token,
        refresh_token=token.refresh_token,
        expires_at=expires_at,
    )

    # Step 5: Fetch and cache identity
    identity: dict | None = None
    identity_name = "unknown"
    try:
        identity = fetch_userinfo(token.access_token)
        save_cached_identity(identity)
        identity_name = (
            identity.get("name")
            or identity.get("preferred_username")
            or identity.get("email")
            or "unknown"
        )
    except DeviceFlowError:
        print_warning(
            "Logged in but could not fetch profile. Run 'pongogo whoami' later."
        )

    # Step 6: Register/update in user registry (best-effort)
    try:
        from auth.user_registry import upsert_user_on_login

        upsert_user_on_login(
            sub=identity.get("sub", "") if identity else "",
            email=identity.get("email") if identity else None,
            display_name=identity.get("name") if identity else None,
            preferred_username=identity.get("preferred_username") if identity else None,
            access_token=token.access_token,
        )
    except Exception:
        pass  # Registry is best-effort — login succeeds regardless

    if output_json:
        console.print(json.dumps({"status": "logged_in", "name": identity_name}))
        return

    console.print()
    print_success(f"Logged in as [bold]{identity_name}[/bold]")
    console.print()


def logout_command(
    output_json: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output result as JSON",
    ),
) -> None:
    """Log out of Pongogo.

    Clears stored credentials and cached identity.
    """
    from auth.identity import clear_cached_identity
    from auth.tokens import get_token_store

    store = get_token_store()
    state = store.get_state()

    if not state.authenticated:
        if output_json:
            console.print(json.dumps({"status": "not_logged_in"}))
            return
        print_warning("Not currently logged in.")
        return

    name = state.display_name or "unknown"

    store.clear()
    clear_cached_identity()

    if output_json:
        console.print(json.dumps({"status": "logged_out", "name": name}))
        return

    print_success(f"Logged out ({name})")


def whoami_command(
    output_json: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output as JSON",
    ),
) -> None:
    """Show current authenticated identity."""
    from pathlib import Path

    from auth.tokens import get_token_store

    store = get_token_store()
    state = store.get_state()

    # Fetch roles from user registry (best-effort)
    if state.authenticated and state.subject:
        try:
            from auth.user_registry import fetch_user_roles

            result = fetch_user_roles(state.subject)
            if result is not None:
                state._db_cli_roles, state._db_groups = result
        except Exception:
            pass  # Fall through to token claims

    # Resolve mode
    from cli.dev_guard import is_dev_mode, is_dev_repo

    project_path = Path.cwd()
    dev_mode = False
    if state.authenticated:
        dev_mode = is_dev_mode(state, project_path)

    if output_json:
        if not state.authenticated:
            console.print(json.dumps({"status": "not_logged_in"}))
            return
        console.print(
            json.dumps(
                {
                    "status": "expired" if state.is_expired else "authenticated",
                    "name": state.display_name,
                    "email": state.email,
                    "subject": state.subject,
                    "expires_at": state.expires_at.isoformat()
                    if state.expires_at
                    else None,
                    "cli_roles": state.cli_roles,
                    "groups": state.groups,
                    "mode": "dev" if dev_mode else "user",
                },
                default=str,
            )
        )
        return

    if not state.authenticated:
        console.print()
        console.print("  [dim]Not logged in.[/dim]")
        console.print("  Run [bold]pongogo login[/bold] to authenticate.")
        console.print()
        return

    console.print()
    if state.is_expired:
        console.print("  Status:  [yellow]expired[/yellow]")
    else:
        console.print("  Status:  [green]authenticated[/green]")

    if state.display_name:
        console.print(f"  Name:    [bold]{state.display_name}[/bold]")
    if state.email:
        console.print(f"  Email:   {state.email}")
    if state.subject:
        console.print(f"  Subject: {state.subject}")
    if state.expires_at:
        console.print(f"  Expires: {state.expires_at:%Y-%m-%d %H:%M:%S UTC}")

    # Roles and groups
    roles_display = ", ".join(state.cli_roles) if state.cli_roles else "\u2014"
    groups_display = ", ".join(state.groups) if state.groups else "\u2014"
    console.print(f"  Roles:   {roles_display}")
    console.print(f"  Groups:  {groups_display}")

    # Mode
    if dev_mode:
        console.print("  Mode:    [bold orang]dev[/bold orang] (developer + dev repo)")
    elif is_dev_repo(project_path):
        console.print("  Mode:    [yellow]user[/yellow] (dev repo, no developer role)")
    else:
        console.print("  Mode:    user")

    if state.error:
        console.print(f"  [yellow]{state.error}[/yellow]")

    console.print()


def register_command(
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't automatically open browser (just display URL)",
    ),
) -> None:
    """Create a new Pongogo account.

    Starts the device code flow — the browser page that opens has
    Sign In and Sign Up tabs. Use Sign Up to create your account,
    then the CLI login completes automatically.
    """
    console.print()
    console.print("[bold]Register for Pongogo[/bold]")
    console.print()
    console.print(
        "  This will open a login page with [bold]Sign In / Sign Up[/bold] tabs."
    )
    console.print("  Use the [bold]Sign Up[/bold] tab to create your account.")
    console.print()

    # Run the same device code flow as login — the Keycloak page
    # has registration built in via the Sign Up tab.
    login_command(no_browser=no_browser)
