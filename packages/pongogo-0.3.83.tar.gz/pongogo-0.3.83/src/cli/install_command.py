"""Platform install/uninstall commands.

Provides ``pongogo install`` and platform-scoped uninstall to manage
Pongogo's per-IDE configuration independently of the shared scaffolding
created by ``pongogo init``.

Architecture: Epic #778 — In-App Distribution
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import typer
from rich.table import Table

from .adapters import (
    PlatformAdapter,
    ScaffoldResult,
    detect_platforms,
    get_adapter,
)
from .console import console, print_error, print_success, print_warning

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

PONGOGO_DIR = ".pongogo"
CONFIG_FILE = "config.yaml"


def _load_config(project_root: Path) -> dict[str, Any]:
    """Read .pongogo/config.yaml and return as dict."""
    import yaml

    config_path = project_root / PONGOGO_DIR / CONFIG_FILE
    return yaml.safe_load(config_path.read_text()) or {}


def _write_config(project_root: Path, config: dict[str, Any]) -> None:
    """Write config dict back to .pongogo/config.yaml."""
    import yaml

    config_path = project_root / PONGOGO_DIR / CONFIG_FILE
    config_path.write_text(yaml.dump(config, default_flow_style=False, sort_keys=False))


def validate_shared_scaffolding(project_root: Path) -> bool:
    """Check that shared scaffolding (.pongogo/ with config.yaml) exists.

    Returns True if present and valid. Used as a precondition for
    ``pongogo install``.
    """
    config_path = project_root / PONGOGO_DIR / CONFIG_FILE
    return config_path.exists()


def _get_mode_and_container(config: dict[str, Any]) -> tuple[str, str | None]:
    """Extract mode and container_name from config, with env-var fallback."""
    native_mode = os.environ.get("PONGOGO_CONTAINER_NAME") is None
    mode = config.get("mode", "native" if native_mode else "docker")
    container_name = config.get("container_name") or os.environ.get(
        "PONGOGO_CONTAINER_NAME"
    )
    return mode, container_name


# ---------------------------------------------------------------------------
# Core operations
# ---------------------------------------------------------------------------


def install_platform(
    project_root: Path,
    adapter: PlatformAdapter,
    *,
    mode: str,
    container_name: str | None,
) -> ScaffoldResult:
    """Run all platform-specific scaffolding for a single platform.

    Calls scaffold_mcp, scaffold_hooks, scaffold_skills, scaffold_agent,
    and scaffold_settings. Updates config.yaml platforms list.

    This is the function that IDE extensions will call programmatically.
    """
    result = ScaffoldResult()

    # MCP config
    mcp_result = adapter.scaffold_mcp(
        project_path=project_root, mode=mode, container_name=container_name
    )
    result.files_written.extend(mcp_result.files_written)
    result.files_merged.extend(mcp_result.files_merged)
    result.errors.extend(mcp_result.errors)

    # Hooks
    hooks_result = adapter.scaffold_hooks(
        project_path=project_root, mode=mode, container_name=container_name
    )
    result.files_written.extend(hooks_result.files_written)
    result.files_merged.extend(hooks_result.files_merged)
    result.errors.extend(hooks_result.errors)

    # Skills (slash commands)
    try:
        from .instructions import get_package_commands_dir

        pkg_commands = get_package_commands_dir()
        if pkg_commands:
            skills_result = adapter.scaffold_skills(
                project_path=project_root, source_dir=pkg_commands
            )
            result.files_written.extend(skills_result.files_written)
            result.errors.extend(skills_result.errors)
    except Exception:
        pass  # Non-fatal

    # Agent definition
    try:
        agent_result = adapter.scaffold_agent(project_path=project_root)
        result.files_written.extend(agent_result.files_written)
    except Exception:
        pass  # Non-fatal

    # Settings
    try:
        settings_result = adapter.scaffold_settings(project_path=project_root)
        result.files_written.extend(settings_result.files_written)
        result.files_merged.extend(settings_result.files_merged)
    except Exception:
        pass  # Non-fatal

    # Create project venv for native mode (hooks need entry points)
    if mode == "native":
        try:
            from mcp_server.upgrade import detect_install_method, get_current_version

            from .init_command import ensure_project_venv

            ensure_project_venv(
                project_root,
                get_current_version(),
                detect_install_method().value,
            )
        except Exception:
            pass  # Non-fatal

    # Update config.yaml platforms list
    try:
        config = _load_config(project_root)
        platforms = config.get("platforms", [])
        platform_name = adapter.platform_name()
        if platform_name not in platforms:
            platforms.append(platform_name)
            config["platforms"] = platforms
            _write_config(project_root, config)
    except Exception:
        pass  # Non-fatal

    return result


def uninstall_platform(
    project_root: Path,
    adapter: PlatformAdapter,
) -> ScaffoldResult:
    """Remove all platform-specific files for a single platform.

    Delegates to adapter.unscaffold(). Updates config.yaml platforms list.
    """
    result = adapter.unscaffold(project_root)

    # Update config.yaml platforms list
    try:
        config = _load_config(project_root)
        platforms = config.get("platforms", [])
        platform_name = adapter.platform_name()
        if platform_name in platforms:
            platforms.remove(platform_name)
            config["platforms"] = platforms
            _write_config(project_root, config)
    except Exception:
        pass  # Non-fatal

    return result


def list_installed_platforms(project_root: Path) -> list[dict[str, Any]]:
    """Discover which platforms are installed in the project.

    Cross-references config.yaml platforms list with adapter.detect()
    and adapter.list_artifacts() for accuracy.
    """
    from .adapters import _ADAPTERS

    # Read declared platforms from config
    declared: list[str] = []
    try:
        config = _load_config(project_root)
        declared = config.get("platforms", [])
    except Exception:
        pass

    results = []
    for adapter in _ADAPTERS:
        name = adapter.platform_name()
        detected = adapter.detect(project_root)
        artifacts = adapter.list_artifacts(project_root)
        in_config = name in declared
        installed = in_config or (detected and len(artifacts) > 0)

        results.append(
            {
                "name": name,
                "installed": installed,
                "in_config": in_config,
                "detected": detected,
                "artifact_count": len(artifacts),
                "artifacts": artifacts,
            }
        )

    return results


# ---------------------------------------------------------------------------
# CLI commands
# ---------------------------------------------------------------------------


def install_command(
    platform: str = typer.Option(
        "auto",
        "--platform",
        "-p",
        help="Platform to install: auto, claude_code, vscode",
    ),
    list_platforms: bool = typer.Option(
        False,
        "--list",
        "-l",
        help="Show installed platforms and exit",
    ),
) -> None:
    """Install Pongogo into a specific IDE platform.

    Configures MCP server, hooks, and slash commands for the target
    platform. Requires that 'pongogo init' has been run first (shared
    scaffolding must exist).

    \b
    This command is idempotent — safe to run multiple times.

    \b
    Examples:
      pongogo install --platform claude_code
      pongogo install --platform vscode
      pongogo install --list
    """
    from .init_command import get_git_root

    cwd = Path.cwd()
    git_root = get_git_root(cwd)
    project_root = git_root if git_root else cwd

    # Handle --list
    if list_platforms:
        if not validate_shared_scaffolding(project_root):
            print_warning("Pongogo is not initialized in this project.")
            console.print("  Run [#5a9ae8]pongogo init[/#5a9ae8] first.")
            raise typer.Exit(0)

        platforms = list_installed_platforms(project_root)
        table = Table(title="Pongogo Platforms")
        table.add_column("Platform", style="bold")
        table.add_column("Status")
        table.add_column("Files")

        for p in platforms:
            if p["installed"]:
                status = "[green]installed[/green]"
                files = str(p["artifact_count"])
            else:
                status = "[dim]available[/dim]"
                files = "—"
            table.add_row(p["name"], status, files)

        console.print(table)
        console.print("\n[dim]Install with:[/dim] pongogo install --platform <name>")
        raise typer.Exit(0)

    # Validate shared scaffolding exists
    if not validate_shared_scaffolding(project_root):
        print_error(
            "Pongogo is not initialized in this project.\n\n"
            "  Run [#5a9ae8]pongogo init[/#5a9ae8] first to create shared "
            "scaffolding, then use [#5a9ae8]pongogo install[/#5a9ae8] to add "
            "platform-specific config."
        )
        raise typer.Exit(1)

    # Resolve adapter(s)
    if platform == "auto":
        adapters = detect_platforms(project_root)
    else:
        try:
            adapters = [get_adapter(platform)]
        except ValueError as e:
            print_error(str(e))
            raise typer.Exit(1)

    # Read mode from config
    config = _load_config(project_root)
    mode, container_name = _get_mode_and_container(config)

    # Install each platform
    for adapter in adapters:
        name = adapter.platform_name()
        console.print(f"\n[bold]Installing for {name}...[/bold]")

        result = install_platform(
            project_root, adapter, mode=mode, container_name=container_name
        )

        for path in result.files_written:
            try:
                rel = path.relative_to(project_root)
            except ValueError:
                rel = path
            console.print(f"  [green]Created[/green] {rel}")
        for path in result.files_merged:
            try:
                rel = path.relative_to(project_root)
            except ValueError:
                rel = path
            console.print(f"  [green]Updated[/green] {rel}")
        for error in result.errors:
            console.print(f"  [red]Error:[/red] {error}")

        if result.ok:
            print_success(f"Platform {name} installed.")
        else:
            print_error(f"Platform {name} installed with errors.")
