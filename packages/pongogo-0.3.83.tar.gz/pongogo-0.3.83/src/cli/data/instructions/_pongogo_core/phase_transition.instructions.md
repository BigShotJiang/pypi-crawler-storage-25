---
pongogo_instruction_spec: "0.0.2"
title: "Phase Transition"
description: "Review and refine upcoming issues before starting the next Epic or Phase within a Milestone."
applies_to:
  - "**/*"
domains:
  - "core"
  - "project_management"
priority: "P1"
pongogo_version: "2026-03-12"
source: "Original"

id: core:phase_transition
routing:
  protected: true
  priority: 5
  description: Review upcoming issues at Epic/Phase boundaries before starting next phase
  triggers:
    keywords:
      - begin phase
      - begin epic
      - start next phase
      - start next epic
      - phase transition
      - next phase
      - next epic
      - moving to next epic
      - begin milestone work
      - start milestone
    nlp: "Transitioning between phases or epics within a milestone, reviewing upcoming issues before starting next phase"
  includes:
    - _pongogo_core/_pongogo_collaboration.instructions.md
  conditional:
    requires: github_pm
evaluation:
  success_signals:
    - All upcoming issues reviewed before starting new phase
    - Issue bodies updated when revisions needed (not just noted)
    - Task list presented to user for confirmation before execution
    - Learnings from completed phase applied to upcoming issues
  failure_signals:
    - Started new Epic without reviewing upcoming issues
    - Noted needed revisions but did not edit issue bodies
    - Began execution without user confirmation of task list
    - Executed against stale issue descriptions
---


# Phase Transition

**Purpose**: Before starting a new Epic or Phase within a Milestone, review and refine all upcoming issues based on learnings from completed work, then decompose the next phase into a confirmed execution plan.

**Philosophy**: "Look back before moving forward." Planning assumptions drift as implementation reveals reality. A structured review at phase boundaries prevents executing against stale plans.

**Conditional**: This instruction only activates if GitHub PM is detected during .

---

## When to Apply

This instruction triggers when:

- Completing one Epic and starting the next within a Milestone
- Starting the first Epic of a new Milestone
- Resuming Milestone work after a significant pause

---

## Preference-Aware Behavior

**Before executing**, check :



Follow the behavior mode per .

---

## 3-Step Phase Transition

<phase-transition-flow>
<step number="1" action="review">
<description>Review all upcoming issues against recent learnings</description>
<questions>
- What did we learn from the just-completed phase that changes our assumptions?
- Are any upcoming issues now unnecessary, redundant, or mis-scoped?
- Are any issues missing tasks we discovered during implementation?
- Have dependencies shifted — do issues need reordering?
- Do acceptance criteria need updating based on patterns established?
</questions>
<actions>
<action required="true">Review ALL remaining issues in the Milestone</action>
<action required="true">For each issue needing revision, update the issue body on GitHub</action>
<action required="true">Add a comment explaining what changed and why</action>
<action required="conditional">If scope changed significantly, flag to user before proceeding</action>
</actions>
<output>Summary of changes (or confirmation no changes needed)</output>
<gate>User confirmation required before proceeding to Step 2</gate>
</step>

<step number="2" action="refine">
<description>Refine issue ordering and dependencies</description>
<actions>
<action required="conditional">Reorder issues if dependency graph changed</action>
<action required="conditional">Update blocking/blocked-by relationships</action>
<action required="conditional">Move issues between Epics if better fit discovered</action>
</actions>
<gate>This step may be trivial (no changes) or significant (restructuring)</gate>
</step>

<step number="3" action="decompose">
<description>Decompose next phase into granular, actionable tasks</description>
<actions>
<action required="true">Read every issue in the Epic completely</action>
<action required="true">Break each issue into actionable tasks with verifiable outcomes</action>
<action required="true">Identify cross-issue dependencies and execution order</action>
<action required="true">Present complete task list to user for confirmation</action>
</actions>
<task-granularity>
- Each task completable in a single focused session
- Tasks map to verifiable outcomes (not "work on X" but "implement X that does Y")
- Include issue references (e.g., "Implement auth adapter (#381)")
- Include non-code tasks (reading docs, reviewing specs, updating issues)
</task-granularity>
<gate>User confirmation required before starting execution</gate>
</step>
</phase-transition-flow>

---

## For First Phase of a Milestone

Step 1 still applies. Review all issues against:
- The Milestone description and objectives
- Any context gathered during planning
- Current state of the codebase

---

## Execution Principles (Post-Confirmation)

Once the task list is confirmed:

- Plan before implementing — formulate approach before starting each step
- Pause if questions arise — don't assume, ask
- Pause if diverging — unexpected scope expansion = stop and escalate
- Mark work complete as it is completed — don't batch completions
- Ask before committing — never commit without explicit user approval

---

## Common Pitfalls

### Skipping Step 1 for "Simple" Phases
Step 1 always applies. Even "no changes needed" confirmation is valuable.

### Noting Changes Without Editing Issues
Don't just mention needed revisions. Actually edit the issue body on GitHub.

### Starting Without User Confirmation
Step 3 requires explicit user confirmation of the task list before execution begins.

---

## Grounding Rules

<grounding>
<rule id="edit-not-note">When revisions are needed, update the issue body on GitHub. Do not just note changes in conversation.</rule>
<rule id="user-confirmation">User must confirm the task list before execution begins. Do not assume confirmation.</rule>
<rule id="always-review">Step 1 applies even for seemingly simple phases. Assumptions drift.</rule>
<rule id="first-phase-too">First phase of a Milestone still requires Step 1 — review against spec and current codebase state.</rule>
</grounding>

---

## Integration

- **After learning loop/retrospective**: This instruction applies learnings forward to upcoming work
- **Before issue commencement**: Phase transition runs first, then individual issue commencement checklist
- **With strategic checkpoint**: When checkpoint Step 4 (Adapt) identifies course corrections, use this workflow

---

## Related

- [Pongogo Collaboration](./_pongogo_collaboration.instructions.md) - Preference-aware behavior
- [Issue Closure](./issue_closure.instructions.md) - Completing the current phase
- [Learning Loop](./learning_loop.instructions.md) - Capturing learnings before transition
