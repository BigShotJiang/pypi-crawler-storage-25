---
pongogo_instruction_spec: "0.0.1"
title: "Code Review Standards"
description: "Comprehensive code review standards for Pongogo including review checklist, feedback patterns, approval criteria, and systematic quality validation"
applies_to:
  - "**/*"
domains:
  - "quality"
  - "process"
  - "code_review"
priority: "P2"
pongogo_version: "2025-10-27"
source: "Adapted from Google engineering practices"
patterns:
  - "code_review"
  - "quality_gates"
  - "systematic_prevention"
related_instructions:
  - "pull_request_workflow.instructions.md"
  - "refactoring_patterns.instructions.md"
routing:
  priority: 1
  triggers:
    keywords:
      - code_review
      - review_standards
      - PR_review
      - review_checklist
      - feedback_pattern
      - approval_criteria
      - must_fix
      - request_changes
      - constructive_feedback
      - review_severity
    nlp: "Code review standards including review checklist, feedback patterns, approval criteria, and systematic quality validation"
---

# Code Review Standards

**Purpose**: Establish comprehensive code review standards for Pongogo ensuring systematic quality validation, knowledge sharing, and constructive feedback culture.

**Philosophy**: Code review is systematic prevention through collaboration - catch issues before production, share knowledge, improve code quality together.

---

## When to Apply

Use these review standards when:

- Reviewing pull requests
- Providing code review feedback
- Requesting code reviews
- Establishing review culture in team

---

## Quick Reference

**Key Code Review Patterns (Decision Criteria & Feedback)**:

**1. Review Checklist** (What to Check):
```markdown
## Functionality
- [ ] Code does what PR description says
- [ ] Edge cases handled (empty, null, boundary)
- [ ] Error conditions handled gracefully

## Testing
- [ ] Tests added for new functionality
- [ ] Tests cover happy path and errors
- [ ] All tests passing
- [ ] Coverage ≥80%

## Code Quality
- [ ] Functions have single responsibility
- [ ] No code duplication
- [ ] No magic numbers (use constants)

## Type Safety (TypeScript)
- [ ] All functions have type annotations
- [ ] No `any` types
- [ ] Type guards for external data

## Security
- [ ] No secrets in code
- [ ] Input validation at boundaries
- [ ] SQL injection prevented
```

**2. Feedback Severity Levels**:
```
🚨 MUST FIX (Blocks Approval):
- Logic errors breaking functionality
- Security vulnerabilities
- Breaking changes to public APIs
- Memory leaks or critical performance issues

⚠️ SHOULD FIX (Request Changes):
- Missing edge case handling
- Code smells (duplication, complexity)
- Missing tests for important cases

💡 NICE-TO-HAVE (Comment Only):
- Style improvements
- Refactoring opportunities
- Performance micro-optimizations

✅ PRAISE (Positive Feedback):
- Well-written code
- Good test coverage
- Clever solutions
```

**3. Constructive Feedback Pattern**:
```markdown
# ❌ Bad: "This is wrong."

# ✅ Good:
> **[Must Fix]** This condition will fail when `patterns` is empty.
>
> **Problem**: `patterns[0]` will be undefined when array is empty.
>
> **Suggestion**: Add guard clause:
> ```typescript
> if (patterns.length === 0) return null;
> if (patterns[0] === value) { /* ... */ }
> ```
```

**4. Approval Decision Tree**:
```
Should I approve this PR?
├─ Logic errors / security issues? YES → 🔄 REQUEST CHANGES
├─ Missing critical tests? YES → 🔄 REQUEST CHANGES
├─ Breaking changes without migration? YES → 🔄 REQUEST CHANGES
└─ Minor issues only (style, suggestions)? YES → ✅ APPROVE
    └─ Leave comments for future improvements
```

**5. Testing Code Locally**:
```bash
# Quick PR review script
gh pr checkout <pr-number>
npm ci                    # Install dependencies
npm run typecheck         # Check types
npm run lint              # Check style
npm test                  # Run tests
npm run test:coverage     # Check coverage
npm run build             # Build project
docker-compose up -d      # Start services (if needed)
npm run test:integration  # Integration tests
```

**6. Review Timeline**:
```
PR Created → Self-Review → CI Passes → Request Review
                                         ↓
                            Review Within 24 Hours
                                         ↓
                     Approve ✅ / Request Changes 🔄 / Comment 💬
                                         ↓
                            Author Addresses Feedback
                                         ↓
                                  Re-Review → Approve
                                         ↓
                                   Merge to Main
```

---

## Core Principles

- **Review Within 24 Hours**: Fast feedback cycles improve velocity
- **Constructive, Specific Feedback**: Explain why, suggest alternatives
- **Approve if Good Enough**: Perfect is enemy of shipped
- **Check for Patterns, Not Details**: Focus on architecture, not formatting
- **Ask Questions**: "Why" questions foster learning
- **Test the Code**: Pull branch, run tests, try it locally
- **Two Approvals Preferred**: Multiple perspectives catch more issues
- **Block Only for Critical Issues**: Logic errors, security, breaking changes

## Step-by-Step Guidance

### 1. **Read PR Description First**
   - Understand what/why/how before reviewing code
   - Check linked issue for context
   - Review test plan
   - Expected outcome: Clear understanding of PR purpose

### 2. **Check CI Status**
   - Verify all CI gates passing
   - Don't review failing PRs in detail
   - Comment if CI issues need attention
   - Expected outcome: CI green before detailed review

### 3. **Review Code Systematically**
   - Start with tests (what behavior is expected?)
   - Review implementation logic
   - Check error handling
   - Verify edge cases covered
   - Expected outcome: Comprehensive review using checklist

### 4. **Provide Actionable Feedback**
   - Be specific, not vague
   - Explain reasoning
   - Suggest alternatives
   - Categorize: must-fix, nice-to-have, question
   - Expected outcome: Clear, constructive feedback

### 5. **Test Locally (for significant changes)**
   - Pull branch: `git fetch && git checkout feature/branch-name`
   - Run tests: `npm test`
   - Try feature manually
   - Expected outcome: Verification of functionality

### 6. **Approve or Request Changes**
   - Approve if good enough (minor issues = comments only)
   - Request changes for critical issues
   - Re-review after changes
   - Expected outcome: Clear approval decision

### 7. **Follow Up**
   - Check that feedback addressed
   - Answer questions from author
   - Approve when satisfied
   - Expected outcome: Feedback loop closed

## Examples

### Example 1: Review Checklist

Systematic review using checklist:

```markdown
# Code Review Checklist

## Functionality
- [ ] Code does what PR description says
- [ ] Edge cases handled (empty, null, boundary values)
- [ ] Error conditions handled gracefully
- [ ] No hardcoded values (use config/env vars)

## Testing
- [ ] Tests added for new functionality
- [ ] Tests cover happy path and error cases
- [ ] All tests passing
- [ ] Test names descriptive
- [ ] Coverage maintained/improved (≥80%)

## Code Quality
- [ ] Code is readable and maintainable
- [ ] Functions have single responsibility
- [ ] No code duplication
- [ ] No magic numbers (use named constants)
- [ ] Complex logic has comments explaining why

## Type Safety (TypeScript)
- [ ] All functions have type annotations
- [ ] No `any` types
- [ ] Type guards for external data
- [ ] Interfaces defined for public APIs

## Security
- [ ] No secrets in code (use env vars)
- [ ] Input validation at boundaries
- [ ] SQL injection prevented (parameterized queries)
- [ ] XSS prevented (sanitized output)

## Performance
- [ ] No N+1 queries
- [ ] Appropriate caching used
- [ ] Large lists paginated
- [ ] Database indexes for queries

## Documentation
- [ ] Public APIs documented
- [ ] Complex logic explained
- [ ] README updated if needed
- [ ] Breaking changes documented

## Architecture
- [ ] Follows established patterns
- [ ] No circular dependencies
- [ ] Appropriate abstraction level
- [ ] Service boundaries respected
```

**Context**: Checklist ensures systematic, complete review
**Expected Result**: Consistent review quality

### Example 2: Feedback Patterns

Constructive, specific feedback:

```markdown
# ❌ Bad Feedback (Vague, Unhelpful)
> This is wrong.
> Fix this.
> Why did you do it this way?
> This doesn't make sense.

# ✅ Good Feedback (Specific, Constructive)

## Issue: Logic Error
> **[Must Fix]** This condition will fail when `patterns` is empty.
>
> ```typescript
> // Current code
> if (patterns.length && patterns[0] === value) {
> ```
>
> **Problem**: `patterns[0]` will be undefined when array is empty, causing false negatives.
>
> **Suggestion**: Add guard clause:
> ```typescript
> if (patterns.length === 0) {
>   return null;
> }
> if (patterns[0] === value) {
> ```

## Issue: Readability
> **[Nice-to-Have]** This nested conditional is hard to follow. Consider using guard clauses to flatten the logic:
>
> ```typescript
> // Instead of:
> if (a) {
>   if (b) {
>     if (c) {
>       return x;
>     }
>   }
> }
>
> // Consider:
> if (!a) return null;
> if (!b) return null;
> if (!c) return null;
> return x;
> ```
>
> Makes the flow easier to trace.

## Question: Design Decision
> **[Question]** Why did you choose to use a Map here instead of an array?
>
> I'm curious about the performance characteristics - are we expecting O(1) lookups to be important here? Or is there another reason?

## Positive Feedback
> **[Praise]** Great use of type guards here! The runtime validation at the API boundary will catch malformed requests before they reach the business logic.
```

**Context**: Specific feedback is actionable and educational
**Expected Result**: Clear understanding, fast resolution

### Example 3: Review Severity Levels

Categorize feedback by severity:

```markdown
# Severity Levels

## 🚨 MUST FIX (Blocks Approval)
- Logic errors that break functionality
- Security vulnerabilities
- Breaking changes to public APIs
- Memory leaks or performance issues
- Missing critical tests

**Example:**
> 🚨 **[MUST FIX]** This will cause a memory leak. The event listener is never removed.
> Add cleanup in component unmount:
> ```typescript
> useEffect(() => {
>   window.addEventListener('resize', handleResize);
>   return () => window.removeEventListener('resize', handleResize);
> }, []);
> ```

## ⚠️ SHOULD FIX (Request Changes)
- Missing edge case handling
- Poor error messages
- Code smells (duplication, complexity)
- Missing tests for important cases
- Type safety issues

**Example:**
> ⚠️ **[SHOULD FIX]** Missing error handling for network failure.
> Add try-catch and return user-friendly error:
> ```typescript
> try {
>   const response = await fetch(url);
> } catch (err) {
>   throw new ServiceError('Failed to fetch metadata', err);
> }
> ```

## 💡 NICE-TO-HAVE (Comment Only)
- Style improvements
- Refactoring opportunities
- Performance micro-optimizations
- Alternative approaches
- Questions about design

**Example:**
> 💡 **[Nice-to-Have]** Consider extracting this validation logic into a shared utility.
> We're using the same pattern in 3 other files. No need to change now, but good candidate for future refactoring.

## ✅ PRAISE (Positive Feedback)
- Well-written code
- Good test coverage
- Clever solutions
- Following best practices

**Example:**
> ✅ **[Praise]** Excellent use of the strategy pattern here! Makes it easy to add new routing types without modifying existing code.
```

**Context**: Severity levels help author prioritize feedback
**Expected Result**: Clear what must change vs nice-to-have

### Example 4: Testing Code Locally

Actually run the code during review:

```bash
#!/bin/bash
# review-pr.sh - Helper script for reviewing PRs locally

PR_NUMBER=$1

if [ -z "$PR_NUMBER" ]; then
    echo "Usage: ./review-pr.sh <pr-number>"
    exit 1
fi

echo "Reviewing PR #$PR_NUMBER..."

# Fetch PR branch
gh pr checkout "$PR_NUMBER"

# Install dependencies (if changed)
npm ci

# Run type checking
echo "Running type check..."
npm run typecheck

# Run linting
echo "Running lint..."
npm run lint

# Run tests
echo "Running tests..."
npm test

# Run tests with coverage
echo "Checking coverage..."
npm run test:coverage

# Build
echo "Running build..."
npm run build

# Start services (for integration testing)
echo "Starting services..."
docker-compose up -d

# Wait for health checks
sleep 5

# Run integration tests
echo "Running integration tests..."
npm run test:integration

echo "✅ Review checks complete for PR #$PR_NUMBER"
```

**Context**: Running code catches issues tests might miss
**Expected Result**: Confidence in functionality

### Example 5: Approval Criteria

When to approve vs request changes:

```markdown
# Approval Decision Tree

## ✅ APPROVE (Good Enough)
- Functionality correct and tested
- No critical bugs or security issues
- Code follows standards (mostly)
- Minor issues can be addressed later
- Author has context to improve

**Example:**
> ✅ **Approving** - Great work! The core functionality is solid and well-tested.
>
> A few minor suggestions for future iterations:
> - Consider extracting the validation logic
> - Add JSDoc comments for public methods
>
> These aren't blockers. Feel free to address them in a follow-up PR or future work.

## 🔄 REQUEST CHANGES (Critical Issues)
- Logic errors that break functionality
- Missing tests for critical paths
- Security vulnerabilities
- Breaking changes without migration path
- Performance issues in hot path

**Example:**
> 🔄 **Requesting Changes**
>
> Found a critical issue that needs to be fixed before merging:
>
> 1. **[MUST FIX]** Missing null check on line 45 - will crash if metadata is null
> 2. **[MUST FIX]** No tests for error case when service is unavailable
>
> Also a few nice-to-haves:
> - Consider adding JSDoc for the public API
> - Extract magic number on line 78 to constant
>
> Please address the MUST FIX items and I'll re-review. The nice-to-haves are optional.

## 💬 COMMENT (Feedback Without Blocking)
- Questions about design decisions
- Suggestions for future improvements
- Pointing out patterns to consider
- Educational feedback

**Example:**
> 💬 **Commenting** (not blocking approval)
>
> Quick question: Why did you choose async/await here instead of Promises?
>
> Not blocking, just curious about the decision. Code looks good overall!
```

**Context**: Clear criteria reduce review friction
**Expected Result**: Fast, consistent decisions

## Validation Checklist

Before approving PR:

- [ ] PR description explains what/why/how
- [ ] Linked to GitHub issue
- [ ] All CI gates passing
- [ ] Tests added for new functionality
- [ ] Test coverage ≥80%
- [ ] No critical bugs or security issues
- [ ] Code follows Pongogo standards
- [ ] Error handling appropriate
- [ ] Type safety maintained
- [ ] No hardcoded secrets
- [ ] Documentation updated
- [ ] Breaking changes documented
- [ ] Tested locally (for significant changes)

## Common Pitfalls

### Pitfall 1: Nitpicking Style

- ❌ **Problem**: Blocking PR for formatting/style issues
- **Why it happens**: Confusing style with quality
- ✅ **Solution**: Use linters/formatters, focus on logic
- **Example**: "Add space after comma" - automate with Prettier

### Pitfall 2: Not Explaining Why

- ❌ **Problem**: Feedback like "Change this" without reasoning
- **Why it happens**: Assuming reviewer understands
- ✅ **Solution**: Always explain reasoning, suggest alternatives
- **Example**: "Use const" → "Use const to prevent accidental reassignment"

### Pitfall 3: Perfectionism

- ❌ **Problem**: Blocking good PR for minor improvements
- **Why it happens**: Wanting perfect code
- ✅ **Solution**: Approve if good enough, suggest improvements for future
- **Example**: Blocking PR because variable names could be better

### Pitfall 4: Not Testing Code

- ❌ **Problem**: Approving without running tests/trying feature
- **Why it happens**: Trusting CI is sufficient
- ✅ **Solution**: Pull branch, run tests, try feature for significant changes
- **Example**: Missing that feature doesn't work with empty input

### Pitfall 5: Slow Reviews

- ❌ **Problem**: Taking 3+ days to review
- **Why it happens**: Not prioritizing reviews
- ✅ **Solution**: Review within 24 hours, block time for reviews
- **Example**: Author context-switches away, loses momentum

## Edge Cases

### Edge Case 1: Disagreement on Approach

**When**: Reviewer and author disagree on implementation
**Approach**:
- Discuss trade-offs openly
- Consider both perspectives
- Escalate to tech lead if needed
- Author has final decision if no consensus
**Example**: Reviewer prefers inheritance, author prefers composition

### Edge Case 2: Legacy Code Context

**When**: New code follows different patterns than legacy
**Approach**:
- Accept that new code may not match legacy
- Don't block for not refactoring legacy
- Create follow-up issue for future refactoring
**Example**: New code uses TypeScript, legacy uses JavaScript

### Edge Case 3: Emergency Hotfix

**When**: Critical production bug needs immediate fix
**Approach**:
- Fast-track review (1 approver, 1 hour max)
- Focus on fix correctness only
- Skip nice-to-haves
- Create follow-up for proper solution
**Example**: Production routing service down

## Troubleshooting

| Symptom | Cause | Solution |
|---------|-------|----------|
| Reviews taking 3+ days | Not prioritized | Block daily time for reviews, set 24hr SLA |
| Authors defensive about feedback | Feedback too harsh | Use constructive language, explain reasoning |
| Same issues in every PR | Standards unclear | Document standards, share in onboarding |
| Reviewers approving without reading | Rubber-stamping | Require checklist, random spot-checks |
| Too many nitpicks | Focus on style, not substance | Use automated linters, focus on logic |
| PRs too large to review | Poor planning | Enforce PR size limits, break work down |
| Conflicting feedback from reviewers | Inconsistent standards | Align on standards, document decisions |

## Related Instructions

**Review Process**:
- [Pull Request Workflow](pull_request_workflow.instructions.md) - PR creation, CI requirements, merge process
- [GitHub Essentials](github_essentials.instructions.md) - Using GitHub review features effectively

**Code Quality**:
- [Refactoring Patterns](refactoring_patterns.instructions.md) - Code smells to spot in review, refactoring suggestions
- [Test-Driven Development](test_driven_development.instructions.md) - Reviewing test quality and coverage
- [TypeScript Standards](typescript_development_standards.instructions.md) - Type safety, strict mode compliance

**Security & Architecture**:
- [Security Hardening](security_hardening.instructions.md) - Security review checklist, spotting vulnerabilities
- [Microservices Development](microservices_development.instructions.md) - Service boundaries, API contracts
- [Database Migrations](database_migrations.instructions.md) - Migration review checklist, rollback validation

**Validation**:
- [Deterministic Validation Framework](deterministic_validation_framework.instructions.md) - Test requirements before approval
- [CI/CD Pipelines](ci_cd_pipelines.instructions.md) - CI gate requirements

---

**Success Criteria**: All PRs reviewed within 24 hours, feedback is specific and constructive, approval criteria clear, 2 approvals before merge, authors responsive to feedback.

**Confidence Check**: Are reviews completed within 24 hours? Is feedback specific with reasoning? Are approval criteria applied consistently? Is feedback constructive and educational?
