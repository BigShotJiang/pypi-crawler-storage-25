---
pongogo_instruction_spec: "0.0.2"
title: "First User Onboarding"
description: "Welcome new users and mention the interactive tutorial on first interaction."
applies_to:
  - "**/*"
domains:
  - "onboarding"
  - "tutorial"
priority: "P2"
pongogo_version: "2026-03-05"
source: "Original"

id: tutorial:first_user_onboarding
routing:
  protected: false
  priority: 100
  always_include: false
  description: Welcomes new users and directs them to the interactive tutorial
  triggers:
    keywords:
      - getting started
      - how does pongogo work
      - what can pongogo do
      - pongogo tutorial
      - new to pongogo
      - first time
      - onboarding
      - learn pongogo
      - pongogo help
      - how to use pongogo
evaluation:
  success_signals:
    - Tutorial mentioned to new users on first interaction
    - Nudge stops after 3 ignored prompts (decay)
    - Nudge stops entirely when tutorial is complete
    - tutorial_nudge field appears in route_instructions response for new users
  failure_signals:
    - Nudge shown to users who completed the tutorial
    - Nudge blocks or interrupts user workflow after first interaction
    - Nudge shown more than once per session
---

# First User Onboarding

**Purpose**: Welcome new Pongogo users and direct them to the interactive tutorial. First interaction is mandatory; subsequent nudges decay.

## Auto-Triggered Nudge (Issue #674)

The `route_instructions()` response may include a `tutorial_nudge` field. When present, you MUST follow its `directive` to check tutorial progress. The nudge system detects three scenarios:

- **first_run**: Brand new user with no tutorial progress. Welcome them and mention `/pongogo-tutorial`.
- **post_upgrade**: Pongogo was recently upgraded and the user has incomplete steps. Mention available steps.
- **contextual**: The current routing response relates to an incomplete tutorial step. Briefly note the relevant step.

When you see `tutorial_nudge` in a routing response, you MUST follow the `directive` field (call `get_tutorial_progress()`) and include the tutorial mention in your response.

## When This Instruction Routes

This instruction routes when:
1. The user's message matches onboarding-related keywords (above), OR
2. This is one of the user's first few interactions after `pongogo init`

## Behavior

### Step 1: Check Tutorial Progress (MANDATORY)

You MUST call `get_tutorial_progress` MCP tool to check current state. Do not skip this step.

### Step 2: Decide Whether to Nudge

**Do NOT nudge if:**
- `all_complete` is true (user finished the tutorial)
- `completed_count` > 0 AND routing events count > 5 (user is actively using Pongogo and knows about the tutorial)
- User has already been nudged once in this conversation

**Decay rule**: If `completed_count` is 0 and routing event stats show > 3 total events, the user has had multiple interactions without engaging the tutorial. They've chosen not to — stop nudging entirely.

### Step 3: Show Welcome and Tutorial Mention

**If completed_count is 0** (never started — FIRST INTERACTION):

This is the user's first time using Pongogo. Ask if they'd like a guided tour before responding to their message:

> Welcome to Pongogo! I can walk you through a quick setup to configure things the way you like to work. Want to do that now? (You can skip any question or exit anytime.)

If the user agrees, use the Skill tool to invoke "pongogo-tutorial" to begin step 1. If the user declines, say "No problem — run /pongogo-tutorial anytime" then respond to their original message normally.

**If completed_count > 0 but not all complete** (started but stopped):
> You left off at step [next_step.step_number] of the tutorial ([next_step.title]). Run `/pongogo-tutorial` to pick up where you left off.

For subsequent interactions (not the first), answer the user's question first, then append the tutorial mention.

**Important after first interaction**: Once the user has been welcomed, subsequent nudges should not repeat the welcome or dominate the response. The decay rules apply.