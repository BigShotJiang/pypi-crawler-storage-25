"""Pongogo settings command.

View auth state, user preferences, and profile information.
Uses the shared auth module for cross-tool token access.

Epic #724: Unified Settings & Auth Storage (Task 4)
"""

from __future__ import annotations

import json

import typer

from .console import console, print_warning

settings_app = typer.Typer(
    name="settings",
    help="View and manage Pongogo settings, auth state, and profile",
    no_args_is_help=False,
    invoke_without_command=True,
)


@settings_app.callback(invoke_without_command=True)
def settings_default(
    ctx: typer.Context,
    output_json: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output as JSON for programmatic access",
    ),
) -> None:
    """Show current settings summary (auth state + preferences)."""
    if ctx.invoked_subcommand is not None:
        return

    from auth.tokens import get_token_store

    try:
        store = get_token_store()
        state = store.get_state()
    except NotImplementedError:
        state = None

    if output_json:
        _print_json_summary(state)
        return

    _print_rich_summary(state)


@settings_app.command(name="auth")
def settings_auth(
    output_json: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output as JSON",
    ),
) -> None:
    """Show detailed auth status."""
    from auth.tokens import get_token_store

    try:
        store = get_token_store()
        state = store.get_state()
    except NotImplementedError:
        state = None

    if output_json:
        _print_json_auth(state)
        return

    _print_rich_auth(state)


@settings_app.command(name="path")
def settings_path() -> None:
    """Show Pongogo home directory path."""
    from auth.config import PONGOGO_HOME

    console.print(str(PONGOGO_HOME))


def _print_rich_summary(state) -> None:
    """Rich-formatted settings summary."""
    from auth.config import PONGOGO_HOME

    console.print()
    console.print("[bold]Pongogo Settings[/bold]")
    console.print()

    # Auth status
    if state is None:
        console.print("  Auth:  [dim]not configured[/dim]")
    elif state.authenticated and not state.is_expired:
        name = state.display_name or "unknown"
        console.print(f"  Auth:  [green]logged in[/green] as [bold]{name}[/bold]")
        if state.email:
            console.print(f"  Email: {state.email}")
        if state.expires_at:
            console.print(f"  Token: expires {state.expires_at:%Y-%m-%d %H:%M UTC}")
    elif state.authenticated and state.is_expired:
        console.print("  Auth:  [yellow]token expired[/yellow]")
        console.print("  Fix:   [dim]pongogo login[/dim]")
    else:
        console.print("  Auth:  [dim]not logged in[/dim]")
        console.print("  Fix:   [dim]pongogo login[/dim]")

    # Paths
    console.print()
    console.print(f"  Home:  {PONGOGO_HOME}")
    console.print()


def _print_rich_auth(state) -> None:
    """Rich-formatted detailed auth status."""
    console.print()
    console.print("[bold]Auth Status[/bold]")
    console.print()

    if state is None:
        print_warning("Auth module not fully configured")
        return

    if not state.authenticated:
        console.print("  Status: [dim]not logged in[/dim]")
        console.print("  Run:    [bold]pongogo login[/bold]")
        console.print()
        return

    if state.is_expired:
        console.print("  Status:  [yellow]expired[/yellow]")
    else:
        console.print("  Status:  [green]authenticated[/green]")

    if state.display_name:
        console.print(f"  Name:    {state.display_name}")
    if state.email:
        console.print(f"  Email:   {state.email}")
    if state.subject:
        console.print(f"  Subject: {state.subject}")
    if state.expires_at:
        console.print(f"  Expires: {state.expires_at:%Y-%m-%d %H:%M:%S UTC}")

    if state.error:
        console.print(f"  Error:   [yellow]{state.error}[/yellow]")

    console.print()


def _print_json_summary(state) -> None:
    """JSON settings summary."""
    from auth.config import PONGOGO_HOME

    data = {
        "pongogo_home": str(PONGOGO_HOME),
        "auth": _auth_to_dict(state),
    }
    console.print(json.dumps(data, indent=2, default=str))


def _print_json_auth(state) -> None:
    """JSON auth status."""
    console.print(json.dumps(_auth_to_dict(state), indent=2, default=str))


def _auth_to_dict(state) -> dict:
    """Convert AuthState to serializable dict."""
    if state is None:
        return {"status": "not_configured"}

    if not state.authenticated:
        return {"status": "not_logged_in"}

    return {
        "status": "expired" if state.is_expired else "authenticated",
        "display_name": state.display_name,
        "email": state.email,
        "subject": state.subject,
        "expires_at": state.expires_at.isoformat() if state.expires_at else None,
        "error": state.error,
    }
