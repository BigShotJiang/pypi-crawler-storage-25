"""Version information for xeries."""

__version__ = "0.1.0"
