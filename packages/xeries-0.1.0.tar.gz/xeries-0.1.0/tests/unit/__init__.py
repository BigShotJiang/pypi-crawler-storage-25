"""Unit tests for xeries."""
