"""Test suite for xeries."""
