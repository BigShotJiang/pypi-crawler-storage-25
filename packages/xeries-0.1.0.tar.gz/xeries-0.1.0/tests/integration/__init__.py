"""Integration tests for xeries."""
