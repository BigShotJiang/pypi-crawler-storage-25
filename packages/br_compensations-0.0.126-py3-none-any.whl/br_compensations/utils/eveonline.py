from typing import Dict, Optional
from esi.models import Token
from allianceauth.services.hooks import get_extension_logger
from esi.openapi_clients import ESIClientProvider
from eveuniverse.models import EveType, EveEntity
from itertools import islice

from allianceauth.eveonline.providers import Alliance

logger = get_extension_logger(__name__)

class EveCharacterUtils:
   
    @classmethod
    def get_token_for_character(cls, character_id: int, REQUIRED_SCOPES: list[str]) -> Optional[Token]:
        """
        Получить валидный токен для персонажа с нужными скоупами.
        
        Args:
            character_id: ID персонажа
            REQUIRED_SCOPES: Список требуемых разрешений (если пуст, не проверяется)
            
        Returns:
            Token или None если не найден
        """
        try:
            tokens = Token.objects.filter(
                character_id=character_id
            )
            for token in tokens:
                if REQUIRED_SCOPES is not None:
                    # Проверяем наличие нужных скоупов
                    token_scopes = set(token.scopes.values_list('name', flat=True))
                    required_scopes = set(REQUIRED_SCOPES)
                    
                    if not required_scopes.issubset(token_scopes):
                        logger.warning(
                            f'Токен для персонажа {character_id} не имеет нужных скоупов. '
                            f'Требуется: {REQUIRED_SCOPES}, есть: {token_scopes}'
                        )
                        continue
                return token
            return None
            
        except Exception as e:
            logger.error(f'Ошибка при получении токена для персонажа {character_id}: {e}')
            return None

esi = ESIClientProvider(
    compatibility_date = "2025-07-23",
    ua_appname = "BrCompensations",
    ua_version = "0.0.1a1",
    operations=["GetAlliances", "GetAlliancesAllianceId", "GetAlliancesAllianceIdCorporations"]
)       
def get_all_eve_alliances() -> list[int]:
    operation = esi.client.Alliance.GetAlliances()
    alliances = operation.results(use_cache=False,return_response=True,force_refresh=True)
    return alliances[0]

def get_alliance_corporations(allianceid:int) -> list[int]:
    operation = esi.client.Alliance.GetAlliancesAllianceIdCorporations(alliance_id=allianceid)
    result = operation.results(use_cache=False, force_refresh=True,return_response=True)
    return result

def update_alliances(alliances: list[int]):
    resolve_eve_names(alliances)
    
def resolve_eve_names(ids:list[int]):
    try:
        chunk_size = 500
        for i in range(0, len(ids), chunk_size):
            chunk = ids[i:i + chunk_size]
            EveEntity.objects.bulk_resolve_names(chunk)
            logger.info('Corporations for alliance added')
            
    except Exception as e:
        logger.error(e)
        return