from django.core.management.base import BaseCommand
from br_compensations.utils.eveonline import get_all_eve_alliances,update_alliances
from allianceauth.services.hooks import get_extension_logger

logger = get_extension_logger(__name__)

class Command(BaseCommand):
    help = """Load alliances from ESI.
    Recommended scenario - specify alliance id or comma separated list of id's to prevent long running execution.
    """

    def add_arguments(self, parser):
        parser.add_argument("--alliance_id", help="Allicance id (single or comma separated) for wich corporations loads")
        return super().add_arguments(parser)
    
    def handle(self, *args, **options):
        if(options['alliance_id']):
            alliances = options['alliance_id'].split(',')
        else:
            confirm = input("Do you really want to load all alliances from ESI? [y/N]: ")
            if(len(confirm) == 0 or not confirm.strip().lower() == "n"):
                print("exiting...")
                return
            alliances = get_all_eve_alliances()
            
        if(alliances):
            try:
                update_alliances(alliances)
            except Exception as e:
                logger.error(e)