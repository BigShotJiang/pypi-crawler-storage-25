from django.core.management import call_command
from django.core.management.base import BaseCommand
from br_compensations.utils.eveonline import get_alliance_corporations,resolve_eve_names
from allianceauth.services.hooks import get_extension_logger
from eveuniverse.models import EveEntity

logger = get_extension_logger(__name__)


class Command(BaseCommand):
    help = """Preloads corporations data required for this app. If alliance_id not provided, loads corporations for alliances in eveuniverse table.
    """

    def add_arguments(self, parser):
        parser.add_argument("--alliance_id", help="Allicance id for wich corporations loads")
        return super().add_arguments(parser)

    def handle(self, *args, **options):
        if(options['alliance_id']):
            alliances = options.get('alliance_id').split(',')
        else:
            confirm = input("Do you really want to load corporations for all alliances in database? [y/N]: ")
            if(len(confirm) == 0 or not confirm.strip().lower() == "n"):
                print("exiting...")
                return
            alliances = EveEntity.objects.filter(category='alliance').values_list('id', flat= True)
        
        for alliance in alliances:
            corporations = get_alliance_corporations(alliance)
            if(corporations):
                resolve_eve_names(corporations[0])