"""CheckAgent pytest plugin — registers markers, fixtures, and configuration."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest

from checkagent.conversation.session import Conversation
from checkagent.core.config import CheckAgentConfig, load_config
from checkagent.judge.judge import RubricJudge
from checkagent.judge.types import Rubric
from checkagent.mock.fault import FaultInjector
from checkagent.mock.llm import MockLLM
from checkagent.mock.mcp import MockMCPServer
from checkagent.mock.tool import MockTool
from checkagent.safety.injection import PromptInjectionDetector
from checkagent.safety.pii import PIILeakageScanner
from checkagent.safety.refusal import RefusalComplianceChecker
from checkagent.safety.system_prompt import SystemPromptLeakDetector
from checkagent.safety.tool_boundary import ToolCallBoundaryValidator
from checkagent.streaming.collector import StreamCollector

VALID_LAYERS = frozenset({"mock", "replay", "eval", "judge"})


def pytest_addoption(parser: pytest.Parser) -> None:
    """Add CheckAgent CLI options to pytest."""
    group = parser.getgroup("checkagent", "CheckAgent agent testing")
    group.addoption(
        "--agent-layer",
        action="store",
        default=None,
        help="Only run agent tests for the specified layer (mock, replay, eval, judge).",
    )
    group.addoption(
        "--checkagent-config",
        action="store",
        default=None,
        help="Path to checkagent.yml config file (auto-discovered if not set).",
    )


def pytest_configure(config: pytest.Config) -> None:
    """Register custom markers and load CheckAgent configuration."""
    config.addinivalue_line(
        "markers",
        "agent_test(layer): mark a test as an agent test with layer specification",
    )
    config.addinivalue_line(
        "markers",
        "safety(category, severity): mark a test as a safety test",
    )
    config.addinivalue_line(
        "markers",
        "cassette(path): specify a cassette file for record-replay testing",
    )

    # Auto-configure pytest-asyncio to "auto" mode so async tests just work.
    # Only override if the user hasn't explicitly set asyncio_mode in their
    # own pytest config (pyproject.toml, pytest.ini, etc.).
    _auto_configure_asyncio(config)

    # Load configuration
    config_path_str = config.getoption("--checkagent-config", default=None)
    config_path = Path(config_path_str) if config_path_str else None
    ca_config = load_config(config_path)
    config.stash[_config_key] = ca_config


def _auto_configure_asyncio(config: pytest.Config) -> None:
    """Set asyncio_mode=auto if the user hasn't configured it themselves."""
    try:
        # Check if the user explicitly set asyncio_mode in their config file.
        # config.inicfg contains only values from the user's config file.
        inicfg = config.inicfg or {}
        if "asyncio_mode" not in inicfg:
            config._inicache["asyncio_mode"] = "auto"  # noqa: SLF001
    except Exception:  # noqa: BLE001
        # Don't crash if pytest-asyncio isn't installed or API changed
        pass


# Stash key for the CheckAgent config object
config_key = pytest.StashKey[CheckAgentConfig]()
_config_key = config_key  # internal alias


@pytest.fixture
def ca_mock_llm() -> MockLLM:
    """A fresh MockLLM instance for each test.

    Configure with the fluent API::

        async def test_agent(ca_mock_llm):
            ca_mock_llm.on_input(contains="weather").respond("It's sunny")
            response = await ca_mock_llm.complete("What's the weather?")
            assert response == "It's sunny"
            assert ca_mock_llm.call_count == 1
    """
    return MockLLM()


@pytest.fixture
def ca_mock_tool() -> MockTool:
    """A fresh MockTool instance for each test.

    Register tools with the fluent API::

        async def test_agent(ca_mock_tool):
            ca_mock_tool.on_call("get_weather").respond({"temp": 72})
            result = await ca_mock_tool.call("get_weather", {"city": "NYC"})
            ca_mock_tool.assert_tool_called("get_weather")
    """
    return MockTool()


@pytest.fixture
def ca_fault() -> FaultInjector:
    """A fresh FaultInjector instance for each test.

    Configure faults using the fluent API::

        def test_resilience(ca_fault):
            ca_fault.on_tool("search").timeout(5)
            ca_fault.on_llm().rate_limit(after_n=3)
            # ... run agent and assert graceful degradation
    """
    return FaultInjector()


@pytest.fixture
def ca_conversation() -> Conversation:
    """A conversation factory fixture for multi-turn testing.

    Returns a ``Conversation`` constructor. Pass your agent function
    to create a session::

        async def test_multi_turn(ca_conversation):
            conv = ca_conversation(my_agent_fn)
            r1 = await conv.say("Hello")
            r2 = await conv.say("What did I just say?")
            assert conv.total_turns == 2

    The agent function must accept an ``AgentInput`` and return
    an ``AgentRun``.
    """
    return Conversation


@pytest.fixture
def ca_stream_collector() -> StreamCollector:
    """A fresh StreamCollector instance for each test.

    Collects streaming events and provides assertion helpers::

        async def test_streaming(ca_mock_llm, ca_stream_collector):
            ca_mock_llm.on_input(contains="hello").stream(["Hi ", "there!"])
            await ca_stream_collector.collect_from(ca_mock_llm.stream("hello"))
            assert ca_stream_collector.aggregated_text == "Hi there!"
            assert ca_stream_collector.total_chunks == 2
    """
    return StreamCollector()


@pytest.fixture
def ca_mock_mcp_server() -> MockMCPServer:
    """A fresh MockMCPServer instance for each test.

    Simulates an MCP server for testing MCP-aware agents::

        async def test_mcp_agent(ca_mock_mcp_server):
            ca_mock_mcp_server.register_tool("search", response={"results": []})
            resp = await ca_mock_mcp_server.handle_message({
                "jsonrpc": "2.0", "id": 1, "method": "tools/call",
                "params": {"name": "search", "arguments": {"q": "test"}},
            })
            ca_mock_mcp_server.assert_tool_called("search")
    """
    return MockMCPServer()


@pytest.fixture
def ca_safety() -> dict[str, object]:
    """Safety evaluator instances for testing agent outputs.

    Provides all built-in safety evaluators::

        def test_agent_safety(ca_safety):
            result = ca_safety["injection"].evaluate(agent_output)
            assert result.passed

            result = ca_safety["pii"].evaluate(agent_output)
            assert result.passed

            result = ca_safety["tool_boundary"].evaluate_run(agent_run)
            assert result.passed

            result = ca_safety["refusal"].evaluate(agent_output)
            assert result.passed
    """
    return {
        "injection": PromptInjectionDetector(),
        "pii": PIILeakageScanner(),
        "system_prompt": SystemPromptLeakDetector(),
        "tool_boundary": ToolCallBoundaryValidator(),
        "refusal": RefusalComplianceChecker(),
    }


@pytest.fixture
def ca_judge() -> Callable[..., RubricJudge]:
    """Factory fixture for creating RubricJudge instances.

    Returns a factory that creates judges from a rubric and LLM callable::

        async def test_judge(ca_judge):
            rubric = Rubric(name="quality", criteria=[...])
            judge = ca_judge(rubric, my_llm_callable)
            score = await judge.evaluate(run)
            assert score.overall >= 0.7

    The factory accepts:
        rubric: Rubric — the evaluation rubric
        llm: async (system, user) -> str — LLM callable
        model_name: str — optional model identifier
    """

    def _factory(
        rubric: Rubric,
        llm: Callable[..., Any],
        model_name: str = "",
    ) -> RubricJudge:
        return RubricJudge(rubric=rubric, llm=llm, model_name=model_name)

    return _factory


@pytest.fixture
def ca_config(request: pytest.FixtureRequest) -> CheckAgentConfig:
    """Access the loaded CheckAgent configuration."""
    return request.config.stash[_config_key]


def pytest_collection_modifyitems(
    config: pytest.Config, items: list[pytest.Item]
) -> None:
    """Filter tests by --agent-layer if specified."""
    layer_filter = config.getoption("--agent-layer", default=None)
    if layer_filter is None:
        return

    layer_filter = layer_filter.lower()
    if layer_filter not in VALID_LAYERS:
        raise pytest.UsageError(
            f"Invalid --agent-layer '{layer_filter}'. "
            f"Valid layers: {', '.join(sorted(VALID_LAYERS))}"
        )

    selected: list[pytest.Item] = []
    deselected: list[pytest.Item] = []

    for item in items:
        marker = item.get_closest_marker("agent_test")
        if marker is None:
            # Non-agent tests always run
            selected.append(item)
        elif _marker_matches_layer(marker, layer_filter):
            selected.append(item)
        else:
            deselected.append(item)

    if deselected:
        config.hook.pytest_deselected(items=deselected)
    items[:] = selected


def _marker_matches_layer(marker: pytest.Mark, layer: str) -> bool:
    """Check if an agent_test marker matches the requested layer."""
    if marker.args:
        return marker.args[0].lower() == layer
    return marker.kwargs.get("layer", "").lower() == layer
