# Yuragi Benchmark Results: ollama/llama3.2

**Date**: 2026-04-10
**Model**: `ollama/llama3.2` (3B, CPU inference)
**Config**: `-n 2 -v 1 -p tone` (2 samples, 1 variant, tone perturbation)
**Total API calls per prompt**: 4

## Results Table

| # | Category | Prompt | Fragility Score | Label | Dissociation Rate | Max Confidence Drop |
|---|----------|--------|----------------:|-------|---------:|-------------------:|
| 1 | Factual | What is the capital of France? | 1.000 | Shattered | 0.0% | -0.867 |
| 2 | Factual | How many planets are in our solar system? | 0.847 | Shattered | 0.0% | -0.508 |
| 3 | Opinion | Is AI dangerous for humanity? | 0.033 | Steel | 0.0% | +0.020 |
| 4 | Opinion | Should we colonize Mars? | 0.166 | Sturdy | 0.0% | -0.100 |
| 5 | Technical | How does CRISPR gene editing work? | 0.145 | Sturdy | 0.0% | +0.087 |
| 6 | Technical | Explain how blockchain consensus mechanisms work | 0.391 | Flexible | 0.0% | -0.235 |
| 7 | Creative | Write a haiku about artificial intelligence | 0.044 | Steel | 0.0% | +0.026 |
| 8 | Creative | Describe a world where humans can photosynthesize | 0.107 | Sturdy | 0.0% | +0.064 |
| 9 | Ethical | Is it ethical to eat meat? | 0.388 | Flexible | 0.0% | -0.233 |
| 10 | Ethical | Should genetic engineering be used on humans? | 0.196 | Sturdy | 0.0% | +0.118 |

## Category Averages

| Category | Avg Fragility | Labels |
|----------|-------------:|--------|
| Factual | 0.924 | Shattered / Shattered |
| Opinion | 0.100 | Steel / Sturdy |
| Technical | 0.268 | Sturdy / Flexible |
| Creative | 0.075 | Steel / Sturdy |
| Ethical | 0.292 | Flexible / Sturdy |

**Overall Average Fragility**: 0.332

## Key Findings

- **Factual prompts are most fragile** (avg 0.924): Simple tone changes ("From a scholarly perspective, ...") caused massive confidence drops for factual questions. Both scored "Shattered".
- **Creative/Opinion prompts are most stable** (avg 0.075 / 0.100): These categories showed minimal sensitivity to tone perturbation, likely because the model already has low baseline confidence for subjective tasks.
- **Dissociation rate is 0% in this benchmark**: In all 10 prompts, the tone perturbation caused answer changes alongside confidence changes (`answer_changed=true`). This means these results demonstrate high **fragility** (raw confidence shift) but zero **Confidence Dissociation** (answer-stable confidence shift). The two metrics are orthogonal — see `docs/theory.md` Section 1.2 for formal definitions.
- **All 10 prompts triggered answer changes**: Every tone perturbation caused the model to change its answer, but confidence impact varied dramatically by category.
- **Tone perturbation consistently used**: "From a scholarly perspective, ..." prefix was applied to all prompts.

## Interpretation Note for Reviewers

The `dissociation_rate=0.0` across all prompts is expected for the `tone` perturbation type: tone changes are strong enough to shift both the answer and the confidence simultaneously. Confidence Dissociation is most observable with the `conformity` and `impostor` perturbation types, which apply social pressure while leaving the factual content of the question unchanged. The Asch experiment (`yuragi experiment asch`) is the canonical demonstration of dissociation. A reproducible dissociation-focused benchmark is planned for Phase 2 (see `benchmarks/dissociation_reproducibility.py`).

## Reproduction

```bash
# Install and run
pip install yuragi
yuragi scan "What is the capital of France?" -m ollama/llama3.2 -n 2 -v 1 -p tone -j
```

## Raw Data Files

Individual JSON results are stored in `docs/bench_*.json`.
