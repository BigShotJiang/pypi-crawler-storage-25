# Related Work

yuragi builds on and differs from a growing body of 2025–2026 work on LLM confidence,
calibration, and sycophancy. This section establishes the orthogonal axis yuragi measures
(confidence delta when the answer does not change) relative to each prior approach.

---

## 1. Internal Probing & Calibration (White-box)

### CCPS — Calibrating LLM Confidence by Probing Perturbed Representation Stability

**Citation**: Zhang et al. (2025). Calibrating LLM Confidence by Probing Perturbed Representation Stability. arXiv:2505.21772, EMNLP 2025. GitHub: https://github.com/ledengary/CCPS

**Method**: Gradient-based adversarial perturbations applied to final hidden states; a probe trained on the stability of those representations produces calibrated confidence estimates.

**Key findings**: ECE reduction 55%, Brier score improvement 21%, AUROC +6 pp on MMLU/MMLU-Pro with Llama/Qwen/Mistral 8B–32B.

**Relation to yuragi**:
- **Model access**: CCPS is **white-box** (requires hidden state + Jacobian access). yuragi is **black-box** (prompt-level only).
- **Closed APIs**: CCPS cannot work with GPT-4o, Claude, or Gemini. yuragi supports any litellm-compatible model.
- **Training cost**: CCPS requires ~18,650 labeled examples and a 2-stage training procedure per model. yuragi is zero-shot.
- **Objective**: CCPS improves calibration accuracy (ECE/Brier). yuragi diagnoses fragility patterns and confidence dissociation.
- **Complementarity**: Use CCPS to improve calibration scores on models you control. Use yuragi to audit fragility and dissociation on any model — including closed APIs — without training data.

---

### FRS — From Confidence to Collapse in LLM Factual Robustness

**Citation**: Fastowski et al. (2025). From Confidence to Collapse: Analyzing Factual Robustness in LLMs. arXiv:2508.16267, EMNLP 2025 Findings. GitHub: https://github.com/afastowski/frs

**Method**: Token-level entropy + temperature scaling; computes a factual robustness score under decoding-condition variation.

**Relation to yuragi**: FRS measures **decoding-condition fragility** (temperature sweeps, sampling settings). yuragi measures **prompt-content fragility** under 13 perturbation types. FRS operates at fleet level; yuragi is per-prompt. FRS requires model internals for temperature scaling; yuragi is API-compatible. The two are complementary diagnostic lenses.

---

## 2. Sycophancy Benchmarks (Answer-flip oriented)

### SYCON-Bench — Multi-turn Sycophancy (EMNLP 2025 Findings, peer-reviewed)

**Citation**: Hong et al. (2025). SYCON-Bench: Multi-turn Sycophancy Benchmark. arXiv:2505.23840, Findings of EMNLP 2025. GitHub: https://github.com/JiseungHong/SYCON-Bench

**Method**: 5-turn dialogues, 3 scenarios (debate / ethical / false presuppositions), 17 LLMs across 6 model families.

**Metric**: Turn of Flip (ToF) — which turn the model changed stance. Number of Flip (NoF) — total stance changes.

**Key findings**: Alignment tuning amplifies sycophancy. Third-person perspective reduces debate sycophancy by 63.8%.

**Relation to yuragi**:
- **Measurement target**: SYCON-Bench counts **answer changes** (ToF, NoF). yuragi measures **confidence delta when the answer does NOT change**.
- These are **orthogonal axes**. A model can show zero answer sycophancy (NoF = 0) and high confidence dissociation simultaneously.
- **Complementarity**: SYCON-Bench tells you whether the model will fold under multi-turn pressure. yuragi tells you whether the model privately loses confidence even when it holds the line.

---

### TRUTH DECAY — Quantifying Multi-Turn Sycophancy

**Citation**: Liu et al. (2025). TRUTH DECAY: Quantifying Multi-Turn Sycophancy in LLMs. arXiv:2503.11656. OpenReview: https://openreview.net/forum?id=GHUh9O5Im8

**Method**: 7-turn adversarial pressure, 4 sycophancy types (feedback / "are you sure?" / answer / mimicry), Claude Haiku / GPT-4o-mini / Llama 3.1-8B.

**Key findings**: Claude accuracy drop up to 47%; 76.74% → 30.23% after 7 turns in the most severe condition.

**Relation to yuragi**: TRUTH DECAY measures **accuracy drop** (answer correctness). yuragi measures **confidence delta** + exponential decay curve fit + recovery strategy comparison. TRUTH DECAY does not expose the decay rate constant λ, half-life, or plateau fit. yuragi's `trajectory challenge` command fits C(t) = plateau + (C₀ − plateau) · e^(−λt) and then tests 5 recovery strategies (authority / praise / evidence / retry / topic-change-return). These tools address complementary questions.

---

### SycEval — Evaluating LLM Sycophancy

**Citation**: Fanous et al. (2025). SycEval: Evaluating LLM Sycophancy. arXiv:2502.08177, Stanford preprint.

**Method**: 4-level rebuttal escalation (simple / ethos / justification / citation+abstract), AMPS (math) + MedQuad (medical), ChatGPT-4o / Claude-Sonnet / Gemini-1.5-Pro.

**Key findings**: 58.19% overall sycophancy rate; progressive (43.52%) and regressive (14.66%) sycophancy; preemptive rebuttal resistance outperforms in-context.

**Relation to yuragi**: SycEval's rebuttal escalation trigger overlaps with yuragi's `gaslighting` and `authority` experiments. SycEval measures **answer flip (sycophancy rate)**; yuragi measures **confidence level** (not just answer level). SycEval does not release code; yuragi provides an open CLI for the same trigger family plus confidence-level measurement as the primary signal.

---

### syco-bench

**Citation**: Duffy (2025). syco-bench. https://www.syco-bench.com, GitHub: https://github.com/timfduffy/syco-bench.

**Method**: 4 single-turn tests (Picking Sides / Mirror / Who Said It / Delusion). A judge model rates stance sycophancy on a −5 to +5 scale.

**Relation to yuragi**: syco-bench is single-turn only. No confidence measurement. Minimal overlap — yuragi and syco-bench are complementary.

---

## 3. Confidence Stability & Context Sensitivity

### NCB — Illusions of Confidence (Neighborhood Consistency Belief)

**Citation**: Author(s) (2026). Illusions of Confidence: Neighborhood Consistency Belief in LLMs. arXiv:2601.05905.

**Method**: Context interference reveals that models with perfect self-consistency can still collapse under neighborhood perturbations.

**Relation to yuragi**: NCB is primarily theoretical/diagnostic. yuragi operationalizes a similar intuition as `find-weakness` (word-level importance scanning) and `scan --perturbations` (13 perturbation types with per-type confidence delta reporting).

---

### Calibration Is Not Enough

**Citation**: Author(s) (2026). Calibration Is Not Enough: Robustness, Stability, and Sensitivity in LLM Confidence. arXiv:2601.08064.

**Method**: 3-axis framework (robustness / stability / sensitivity) evaluating confidence calibration under language variations.

**Relation to yuragi**: yuragi adds two further dimensions to this framework: word-level load-bearing detection (`find-weakness`) and an 11-experiment psychology stress-test suite as additional measurement axes.

---

### Certainty Robustness Benchmark

**Citation**: Author(s) (2026). Certainty Robustness Benchmark. arXiv:2603.03330.

**Method**: 2-turn "Are you sure?" evaluation protocol across 200 prompts and 4 models.

**Relation to yuragi**: yuragi extends this to 13 perturbation types + 11 psychologically-inspired experiment templates + word-level weakness detection. yuragi's `gaslighting` experiment covers the "Are you sure?" trigger family and escalates through 5 pressure levels.

---

## 4. LLM Psychology Replications

### Conformity in LLMs (Asch replication)

**Citation**: Baltaji et al. (2025). Conformity, Conflict, and Shift: Uncovering LLM Susceptibility to Conformity Bias. ACL 2025, arXiv:2410.12428.

**Method**: Direct Asch (1951) paradigm replication showing majority-opinion shift from correct to incorrect answers.

**Relation to yuragi**: yuragi's `asch` experiment follows this lineage directly. yuragi additionally measures **confidence-level collapse** (not just answer flip), and bundles 11 psychologically-inspired experiment templates into one pip-installable CLI.

---

### ELEPHANT — Social Sycophancy

**Citation**: Cheng et al. (2025). ELEPHANT: Measuring and Understanding Social Sycophancy in LLMs. arXiv:2505.13995.

**Method**: Four-dimensional decomposition of social sycophancy (Validation / Indirectness / Framing / Moral); LLMs preserve user self-image 45 pp more than humans on average.

**Relation to yuragi**: yuragi's `impostor` and `gaslighting` experiment templates are conceptually adjacent to ELEPHANT's framing/validation dimensions. ELEPHANT is a benchmark; yuragi is a CLI diagnostic tool. Confidence-level measurement distinguishes the two approaches.

---

## 5. Surveys

### LLM Uncertainty Quantification Survey

**Citation**: Author(s) (2025). A Comprehensive Survey of Uncertainty Quantification in Large Language Models. arXiv:2503.15850.

A comprehensive 2025 survey of LLM UQ and calibration methods covering 2020–2025. yuragi builds on the post-2024 confidence literature summarized here, and its trilayer decomposition extends the survey's typology with a prompt-fragility axis.

---

## 6. Prior Art (2022–2024)

### SPUQ (Gao et al., EACL 2024)

**Citation**: Gao, T., et al. (2024). SPUQ: Perturbation-based uncertainty quantification for large language models. *Proceedings of EACL 2024*.

**Method**: Output variance across random input perturbations (dummy tokens, paraphrase, system message, temperature). Uncertainty estimated as variance in model outputs.

**Relation to yuragi**: SPUQ measures **output variance** (how often the answer changes). yuragi measures **confidence variance when the answer does not change** — orthogonal axes. SPUQ has no CLI; yuragi is pip-installable. SPUQ does not model psychological mechanisms.

---

### Semantic Entropy (Farquhar et al., *Nature* 2024)

**Citation**: Farquhar, S., Kossen, J., Kuhn, L., & Gal, Y. (2024). Detecting hallucinations in large language models using semantic entropy. *Nature*, 630, 625–630.

**Method**: NLI-based semantic clustering of sampled responses; entropy computed over semantic clusters rather than raw token sequences.

**Relation to yuragi**: Semantic Entropy detects whether a model knows the answer (hallucination detection). yuragi detects whether the model's confidence is stable under framing (fragility/dissociation). A model with low semantic entropy can still exhibit high dissociation.

> **Important caveat**: yuragi's built-in `semantic_entropy()` function uses Jaccard / embedding-cosine fallback clustering, **not** the NLI-based clustering from Farquhar et al. It is a Farquhar-inspired approximation. Users needing the full NLI-based method should use the original Farquhar et al. codebase.

---

### Kadavath et al. — "Language Models (Mostly) Know What They Know" (Anthropic, 2022)

**Citation**: Kadavath, S., et al. (2022). Language models (mostly) know what they know. *arXiv:2207.05221*.

**Relation to yuragi**: Kadavath et al. document that adversarial prompting degrades calibration. yuragi operationalizes this observation into structured perturbation experiments with quantitative per-prompt confidence delta measurement. yuragi's trilayer analysis extends beyond the single P(IK) metric.

---

### lm-polygraph (Vashurin et al., TACL 2024)

**Citation**: Vashurin, R., et al. (2024). Benchmarking LLM uncertainty quantification methods. *TACL*, 12, 1186–1206.

**Relation to yuragi**: lm-polygraph benchmarks 40+ UQ methods on static datasets. yuragi measures dynamic confidence fragility under user-specified perturbations on any prompt, with a CLI designed for practitioners rather than UQ researchers.

---

## 7. yuragi's Contributions (Honest Positioning)

After positioning against the above work:

1. **Confidence Dissociation as a first-class metric**: `docs/theory.md` Section 1 formalizes D(q, q') = sim(a, a') · |C(q) − C(q')| — the phenomenon where the answer stays but confidence collapses. SYCON-Bench / TRUTH DECAY / SycEval all measure answer flip; yuragi measures the orthogonal axis. This operationalizes observations from Kadavath (2022), Kuhn (2023, ICLR), and Farquhar (2024) and extends the sycophancy benchmarks along a confidence-only dimension.

2. **Exponential decay modeling + recovery strategy comparison**: `C(t) = plateau + (C₀ − plateau) · e^(−λt)` fit plus 5 recovery strategies tested sequentially. Not present in TRUTH DECAY or SYCON-Bench.

3. **Test-Time Compute Fragility + trilayer decomposition**: CoT / reasoning inflates confidence without corresponding accuracy gains — flagged via `overconfidence_amplified`. Plus logprob / sampling / verbalized triangulation on the same prompt.

4. **Word-level load-bearing detection × 11-experiment psychology suite**: `find-weakness` identifies the single word whose removal collapses confidence. Combined with 11 psychologically-inspired experiment templates in one pip-installable CLI.

---

## 8. What yuragi does NOT claim

- yuragi is **not a calibration improvement method** (see CCPS for that).
- yuragi's psychology "experiments" are **prompt templates inspired by each cited paper**, not rigorous behavioral replications (e.g., Asch's unanimity design, Tversky-Kahneman anchor calibration, or Dunning-Kruger longitudinal tracking are not faithfully reproduced).
- yuragi's `semantic_entropy()` uses **Jaccard / embedding-cosine clustering**, NOT the NLI-based clustering in Farquhar et al. 2024 *Nature* — it is a loose proxy.
- yuragi's `fragility_score` and `dissociation` metrics are **correlated diagnostic signals**, not validated against human-annotated ground truth (see `KNOWN_LIMITATIONS.md`).
- The empirical numbers in `README.md` come primarily from `ollama/llama3.2` (3B). Claims about `llama-3.1-8b` and `gpt-4o-mini` in earlier documentation were illustrative; reproducible JSON evidence for those models is not shipped in v0.2.0.
