# Quick Start

## Installation

```bash
pip install yuragi
```

With visualization support:

```bash
pip install "yuragi[viz]"
```

With local Ollama support:

```bash
pip install "yuragi[all]"
```

## Set up an API key

```bash
export OPENAI_API_KEY=sk-...
# or
export ANTHROPIC_API_KEY=sk-ant-...
# or
export GROQ_API_KEY=gsk-...
```

No API key needed for local models (Ollama):

```bash
ollama pull llama3.2
```

## First scan

```bash
yuragi scan "Is quantum computing practical?" --model gpt-4o-mini
```

Output:

```
╭──────────────────────────────────── Fragility Summary ────────────────────────────────────╮
│  Fragility Score  0.61 (Glass)    Max Drop  -0.58    Dissociation Rate  45%              │
╰───────────────────────────────────────────────────────────────────────────────────────────╯
⚡ "Experts strongly disagree." collapsed confidence by 58% — the answer never changed.
```

## Find the weakest word

```bash
yuragi find-weakness "Explain the theory of relativity" --model ollama/llama3.2
```

## Run a psychology experiment

```bash
yuragi experiment asch --model ollama/llama3.2
```

## Python API

```python
from yuragi import Scanner

result = Scanner(model="gpt-4o-mini").scan("Is quantum computing practical?")
print(result.fragility_score)       # 0.61 (Glass)
print(result.dissociation_rate)    # 0.45
print(result.weakest_perturbation)  # the prompt that broke confidence
```

## Next steps

- [CLI Reference](cli.md) — all commands and options
- [API Reference](api/scanner.md) — Python API
- [Theory](theory.md) — what fragility means and how it's measured
