# yuragi (揺らぎ)

**One word can break your AI's confidence. yuragi finds which one.**

The first CLI tool for measuring LLM confidence fragility — how one word can collapse AI certainty by 75% without changing the answer.

> *Human confidence is fragile — a single word can shatter it. AI confidence breaks the same way. `yuragi` measures those invisible fractures.*

## What it does

yuragi systematically perturbs your prompts and measures how the model's confidence shifts. It finds the words your AI's certainty depends on, the phrases that trigger doubt, and the moments confidence collapses for no visible reason.

## Install

```bash
pip install yuragi
```

## Quick example

```bash
yuragi scan "Is the Earth round?" --model gpt-4o-mini
```

## Links

- [Quick Start](quickstart.md)
- [CLI Reference](cli.md)
- [API Reference](api/scanner.md)
- [Theory](theory.md)
- [FAQ](faq.md)
- [GitHub](https://github.com/hinanohart/yuragi)
- [PyPI](https://pypi.org/project/yuragi/)
