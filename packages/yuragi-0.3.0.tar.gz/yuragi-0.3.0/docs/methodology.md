# Methodology: Confidence Measurement in yuragi

This document describes the theoretical foundations and implementation details of each confidence measurement method used in yuragi. It is intended for researchers who need to understand what is being measured and why.

## 1. Logprob Entropy (Token Probability Method)

### Theoretical Background

The logprob method derives confidence from the **Shannon entropy** of the token probability distribution produced by the language model at each generation step (Shannon, 1948).

For a vocabulary distribution over tokens at position *t*, the per-token entropy is:

```
H(t) = -∑ p(v) · log₂ p(v)   for all v in top-k candidates
```

The mean entropy across all *T* tokens in the response is:

```
H̄ = (1/T) · ∑_{t=1}^{T} H(t)
```

Confidence is then derived by a monotone decreasing transformation:

```
confidence = max(0, min(1, 1 - H̄/3))
```

The normalization constant 3.0 was chosen empirically: a mean entropy above 3 bits (i.e., systematic uncertainty over 8+ candidates at every token) corresponds to confidence ≤ 0, while deterministic generation (entropy ≈ 0) gives confidence = 1.0.

### Information-Theoretic Interpretation

Low entropy means the model assigns high probability mass to a single token — the response is "predictable" given the context. High entropy means probability is spread across many tokens, indicating genuine uncertainty about the next word. This operationalizes the intuition that **certainty is the absence of ambiguity** in the token distribution.

This approach is theoretically grounded in the connection between entropy and uncertainty quantification established by information theory (Cover & Thomas, 2006). It is the most direct measurement of model internals available through the API.

### Limitations

- Requires logprob access (available on OpenAI GPT-4o family; not available on Anthropic or Google APIs as of April 2026).
- Measures *lexical* uncertainty (word choice), not semantic uncertainty (propositional content).
- Top-k truncation (default k=20 for OpenAI) underestimates true entropy by ignoring the long tail.

### Implementation

See `src/yuragi/providers/adapter.py`: `_complete_with_logprobs()`, `_calculate_entropy()`.

---

## 2. Multi-Sample Agreement (Behavioral Consistency Method)

### Theoretical Background

When logprobs are unavailable, yuragi infers confidence from **behavioral consistency**: the degree to which a model gives the same answer when asked the same question multiple times at nonzero temperature.

The sampling method queries the model *N* times (default N=5) at temperature τ = 0.7 and measures pairwise similarity across responses.

### Similarity Metric: Char-3-Gram Jaccard

The similarity between two responses *a* and *b* is computed using **character-level 3-gram Jaccard similarity**:

```
J(a, b) = |G₃(a) ∩ G₃(b)| / |G₃(a) ∪ G₃(b)|
```

where G₃(·) is the set of all character trigrams in the response (first 300 characters, lowercased).

Mean pairwise Jaccard over all N(N-1)/2 pairs is the confidence estimate.

### Why Character N-grams Instead of Word-Level Jaccard

An earlier version used word-level Jaccard similarity. This was replaced with character 3-grams for the following reasons:

1. **Language-agnosticity**: Word tokenization requires whitespace delimiters, which are absent in Japanese, Chinese, Thai, and other languages. Character n-grams work uniformly across all scripts.
2. **Morphological robustness**: Languages with rich morphology (Finnish, Turkish, Arabic) change word surface forms without changing meaning. Character-level overlap is more stable across morphological variants.
3. **Consistency with the `answer_changed` property**: The same metric is used in `PerturbationResult.answer_changed` and `PerturbationResult.answer_similarity`, so confidence and answer comparison use the same distance function.

### Statistical Properties

The Jaccard index is bounded in [0, 1] and is a valid metric on finite sets under the transformation d(a,b) = 1 − J(a,b) (Kosub, 2019). For the mean over *k* = N(N-1)/2 pairs, variance decreases as O(1/k).

With N=5, k=10 pairs, the standard error on the confidence estimate is approximately σ/√10 where σ is the standard deviation of individual Jaccard scores. Increasing N improves precision quadratically in API cost.

### Implementation

See `src/yuragi/providers/adapter.py`: `_complete_with_sampling()`, `_measure_agreement()`.

---

## 3. Verbalized Confidence (Self-Report Method)

### Theoretical Background

The verbalized method elicits an explicit **self-report** of confidence from the model by appending a structured prompt:

```
After your answer, on a new line write exactly "CONFIDENCE: X"
where X is your confidence level from 0 to 100.
```

The raw integer is parsed and normalized to [0, 1].

### Prior Research on LLM Self-Reported Confidence

Self-reported confidence in LLMs has been studied as a calibration problem. Kadavath et al. (2022) showed that large language models can self-assess answer correctness with above-chance accuracy when given well-formed prompts, but tend toward overconfidence. Xiong et al. (2023) demonstrated systematic miscalibration in verbalized confidence across multiple benchmark tasks. Tian et al. (2023) found that verbalized probabilities are more reliable when elicited numerically than when derived from linguistic hedges ("I think", "I'm fairly sure").

A key finding relevant to yuragi: verbalized confidence **does not reliably match** logprob-derived or sampling-derived confidence. This divergence is itself a signal — the model's explicit self-model disagrees with its implicit behavioral output. yuragi makes this divergence visible through Trilayer Analysis (Section 6).

### Design Choices

- Temperature is set to 0.0 for verbalized queries (deterministic extraction).
- The CONFIDENCE line is parsed with a regex allowing integer or decimal values.
- If parsing fails, confidence defaults to 0.5 (maximum uncertainty).

### Limitations

- Subject to **sycophantic bias**: models may report higher confidence when the user appears to expect confidence.
- **Format compliance**: some models refuse or fail to output the CONFIDENCE line, triggering the 0.5 default.
- Does not capture uncertainty about *why* the model is confident or uncertain.

### Implementation

See `src/yuragi/providers/adapter.py`: `complete_verbalized()`, `_parse_verbalized_confidence()`.

---

## 4. Confidence Dissociation: Formal Definition

### Concept

**Confidence Dissociation** is yuragi's primary novel metric. It captures the phenomenon where the model's answer remains stable under a perturbation but its confidence shifts significantly. This is distinct from standard miscalibration (where confidence doesn't match accuracy) — dissociation is a *dynamic* measure of confidence instability.

### Formal Definition

For a perturbation result (original prompt *q*, perturbed prompt *q'*, original response *r*, perturbed response *r'*):

```
similarity(r, r') = J₃(r[0:300], r'[0:300])       [char-3-gram Jaccard]

confidence_delta = confidence(r') - confidence(r)

dissociation_severity(q, q') =
  0                                           if similarity < 0.6
  0                                           if |confidence_delta| < 0.06
  min(1, similarity × |confidence_delta| × 3)  otherwise
```

A result is **dissociated** if `dissociation_severity > 0`.

The `dissociation_rate` of a scan is the fraction of perturbation results that are dissociated:

```
DR = |{i : dissociation_severity(i) > 0}| / N
```

### Thresholds

- **Similarity threshold 0.6**: Responses with less than 60% character-3-gram overlap are considered semantically different answers. Perturbing an answer that *does* change is expected to change confidence; this is not dissociation.
- **Confidence threshold 0.06**: Fluctuations below 6% confidence are treated as measurement noise. The 0.06 value was chosen based on the empirical standard deviation of confidence estimates for repeated identical queries.
- **Scaling factor 3.0**: Normalizes the product `similarity × |confidence_delta|` (max ≈ 1.0 × 1.0 = 1.0) to [0, 1]. The factor 3 compresses the scale so that a moderate combination (sim=0.8, delta=0.3) gives severity ≈ 0.72, which is qualitatively "high".

### Implementation

See `src/yuragi/core.py`: `PerturbationResult.dissociation_severity`, `PerturbationResult.is_dissociated`, `ScanResult.dissociation_rate`.

---

## 5. Fragility Score: Statistical Grounding

### Definition

The **Fragility Score** summarizes overall confidence instability as the population standard deviation of confidence across the baseline and all perturbed responses, normalized to [0, 1]:

```
C = {c₀, c₁, ..., cₙ}    where c₀ = baseline confidence

μ = (1/|C|) · ∑ cᵢ
σ = sqrt((1/|C|) · ∑ (cᵢ - μ)²)

fragility_score = min(1, σ / 0.3)
```

### Normalization Rationale

The normalization constant 0.3 maps a standard deviation of 0.3 (or greater) to a fragility score of 1.0. For confidence values in [0, 1], the theoretical maximum standard deviation of a Bernoulli-like distribution is 0.5 (achieved by half the values at 0.0 and half at 1.0). A σ of 0.3 corresponds to a model that exhibits major confidence swings (e.g., between 0.2 and 0.8) across routine perturbations — behavior that warrants the "Shattered" label.

### Qualitative Labels

| Fragility Score | Label |
|-----------------|-------|
| < 0.10 | Steel |
| 0.10–0.25 | Sturdy |
| 0.25–0.50 | Flexible |
| 0.50–0.75 | Glass |
| ≥ 0.75 | Shattered |

### Relationship to Other Metrics

Fragility Score measures the *magnitude* of confidence variability. The Fragility Profile (Section 6) measures its *structure*. A model can have high fragility score but low CCI (many moderate swings), or low fragility score but high NLS (rare but chaotic responses).

### Implementation

See `src/yuragi/core.py`: `ScanResult.fragility_score`.

---

## 6. Fragility Profile: CCI, RE, NLS

The **Fragility Profile** (`FragilityProfile`) decomposes confidence fragility into three orthogonal dimensions. These are computed by `src/yuragi/analysis/fragility_profile.py`.

### 6.1 Catastrophic Collapse Index (CCI)

**Concept**: How efficiently can a small edit destroy confidence?

**Definition**:

For each perturbation result, compute the *efficiency* of confidence collapse:

```
efficiency(i) = |confidence_delta(i)| / edit_distance(q, q'ᵢ)
```

where `edit_distance` is the character-level Levenshtein distance between the original and perturbed prompt.

```
CCI = min(1, max_i{efficiency(i)} / 0.05)
```

The normalization constant 0.05 means: if a single character change causes a 5% confidence shift, CCI = 1.0. This is the "one character per 5% confidence" criterion.

**Interpretation**: CCI = 1.0 means removing a single character (or swapping one word) is sufficient to maximally destabilize the model's certainty.

### 6.2 Recovery Elasticity (RE)

**Concept**: After confidence collapses, can it be restored?

**Definition**:

```
drops  = {i : confidence_delta(i) < -0.05}
boosts = {i : confidence_delta(i) > +0.05}

RE =
  1.0                             if no drops exist
  0.0                             if drops exist but no boosts
  min(1, max_boost / |max_drop|)  otherwise
```

**Interpretation**: RE = 1.0 means there exists a perturbation that fully compensates the worst confidence collapse. RE = 0.0 means once confidence is damaged, no perturbation in the tested set can restore it.

This mirrors the psychological concept of **resilience** after confidence undermining: some individuals recover from criticism easily; others show lasting damage.

### 6.3 Non-linearity Score (NLS)

**Concept**: Is the relationship between edit size and confidence shift predictable?

**Definition**:

For each perturbation, compute the normalized efficiency:

```
e(i) = confidence_delta(i) / edit_distance(q, q'ᵢ)
```

NLS is the normalized standard deviation of this efficiency distribution:

```
μ_e = mean{e(i)}
σ_e = std{e(i)}

NLS = min(1, σ_e / 0.03)
```

**Interpretation**: NLS = 0 means all edits of equal size cause equal confidence change (linear response). NLS = 1.0 means edits of the same size cause wildly different confidence changes (chaotic, non-linear response). High NLS makes it impossible to predict how a new perturbation will affect confidence.

### Mathematical Relationship Between CCI, RE, NLS

These three indices are not independent in general:
- High CCI with high NLS suggests a system with a few catastrophic trigger points embedded in otherwise unpredictable behavior.
- High CCI with low NLS suggests consistent sensitivity to all edits.
- Low CCI with high NLS suggests random, small fluctuations without catastrophic collapse.

---

## References

- Cover, T. M., & Thomas, J. A. (2006). *Elements of Information Theory* (2nd ed.). Wiley.
- Kadavath, S., Conerly, T., Askell, A., et al. (2022). Language models (mostly) know what they know. *arXiv:2207.05221*.
- Kosub, S. (2019). A note on the triangle inequality for the Jaccard distance. *Pattern Recognition Letters*, 120, 36–38.
- Shannon, C. E. (1948). A mathematical theory of communication. *Bell System Technical Journal*, 27(3), 379–423.
- Tian, K., Mitchell, E., Zhou, A., et al. (2023). Just ask for calibration: Strategies for eliciting calibrated confidence scores from language models fine-tuned with human feedback. *EMNLP 2023*.
- Xiong, M., Hu, Z., Lu, X., et al. (2023). Can LLMs express their uncertainty? An empirical evaluation of confidence elicitation in LLMs. *ICLR 2024*.
