# Known Limitations

1. **Sampling-based confidence has high variance on small models**
   llama3.2 (3B) shows ~10-15% noise floor. Use 5+ samples.

2. **Japanese word-level operations are approximate**
   Without morphological analysis, word boundaries are estimated.

3. **No streaming support**
   All API calls are synchronous. For high-throughput, use BatchScanner.
