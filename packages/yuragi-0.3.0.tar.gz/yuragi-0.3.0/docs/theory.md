# Theoretical Foundations of yuragi

This document provides the formal theoretical grounding for the concepts implemented in yuragi. It is intended to serve as the theory section of an accompanying research paper.

---

## Section 1: Formal Definition of Confidence Dissociation

### 1.1 Motivation

Existing uncertainty quantification (UQ) research for LLMs has focused primarily on two dimensions: **calibration** (does the model's stated confidence match its empirical accuracy?) and **semantic consistency** (does the model give the same answer across paraphrases?). We operationalize a third, orthogonal dimension — **confidence dissociation** — which neither calibration nor semantic consistency captures. This builds on Kadavath et al. (2022), who show that adversarial prompting degrades calibration; Kuhn et al. (2023, ICLR), who formalize semantic consistency; and Farquhar et al. (2024, *Nature*), who introduce semantic entropy as a clustering-based hallucination signal. It extends the sycophancy benchmarks SycEval (2025), TRUTH DECAY (2025), and SYCON-Bench (2025) along a confidence-only axis orthogonal to answer flip.

**Informal definition**: Confidence dissociation occurs when a model produces semantically equivalent answers to two prompts, but with significantly different confidence. The answer is stable; the confidence is not.

### 1.2 Formal Definitions

Let $M$ be a language model, $q$ a natural language query, and $q'$ a perturbed variant of $q$ (e.g., tone-modified, paraphrased, or with social pressure prepended).

Define:
- $a = M(q)$ — the model's answer to the original prompt
- $a' = M(q')$ — the model's answer to the perturbed prompt
- $C(q) \in [0, 1]$ — model confidence on prompt $q$
- $C(q') \in [0, 1]$ — model confidence on prompt $q'$
- $\text{sim}(a, a') \in [0, 1]$ — semantic similarity between answers (e.g., character n-gram Jaccard similarity)

**Definition 1.1a (Pairwise Fragility)**

$$\text{Fragility}_{\text{pairwise}}(q, q') = |C(q) - C(q')|$$

The raw per-pair confidence shift under a single perturbation. This is the
quantity exposed on each `PerturbationResult.confidence_delta` and is the
atomic building block of all other fragility statistics. It is independent
of whether the answer changed.

**Definition 1.1b (Aggregate Fragility Score)**

For a scan consisting of a baseline confidence $C_0 = C(q)$ and $n$ perturbed
confidences, the aggregate fragility reported on `ScanResult.fragility_score` is:

$$\text{Fragility}_{\text{agg}}(q) = \frac{1}{n} \sum_{i=1}^{n} |C(q) - C(q'_i)|$$

Perturbation-count invariant mean of pairwise fragility. Range $[0, 1]$ by
construction (each $|C(q) - C(q'_i)| \in [0, 1]$). Because the formula is
scale-free and count-invariant, scores from scans with different numbers of
perturbation variants are directly comparable.

**Definition 1.1c (Worst-case Fragility)**

$$\text{Fragility}_{\max}(q) = \max_{i} |C(q) - C(q'_i)|$$

Extreme-value estimator for the single largest perturbation effect. Exposed as
`ScanResult.fragility_max`. Useful for worst-case safety analysis where a single
adversarial perturbation is more relevant than the average.

**Definition 1.1d (Exceedance Rate)**

$$\text{Fragility}_{\text{exceed}}(q;\, \tau) = \frac{1}{n} \sum_{i=1}^{n} \mathbf{1}\!\left[|C(q) - C(q'_i)| > \tau\right]$$

Fraction of perturbations exceeding noise floor $\tau$. Default
$\tau = \texttt{dissociation\_noise\_floor} = 0.06$. Exposed as
`ScanResult.fragility_exceed`. Complements the mean estimator by focusing on the
tail of the distribution rather than the average shift.

**Definition 1.2 (Confidence Dissociation)**

$$\text{Dissociation}(q, q') = \text{sim}(a, a') \cdot |C(q) - C(q')|$$

Range $[0, 1]$ by construction (both factors $\in [0, 1]$). When
$\text{sim}(a, a') \approx 1$ (the answer did not change) and $|C(q) - C(q')|$
is large, dissociation is high. When the answer changed
($\text{sim}(a, a') \approx 0$), dissociation is zero by definition — confidence
shift accompanying an answer change is expected behavior, not dissociation.

> **v0.3.0**: the `scaling_factor = 3.0` multiplier that appeared in the v0.2.0
> reference implementation has been removed. The formula is now applied
> unscaled; the product naturally falls in $[0, 1]$ without clipping.

**Definition 1.3 (Dissociation Rate)**

Given a set of perturbations $\{q'_1, \ldots, q'_k\}$ for a base query $q$:

$$\text{DissociationRate}(q) = \frac{1}{k} \sum_{i=1}^{k} \mathbb{1}\!\left[\text{Dissociation}(q, q'_i) > 0\right]$$

The reference implementation gates on $\text{Dissociation}(q, q'_i) > 0$, which
is equivalent to requiring both $\text{sim}(a, a'_i) > 0$ and
$|C(q) - C(q'_i)| > 0$. The unified answer similarity threshold is
$\tau_{\text{sim}} = \texttt{answer\_similarity\_threshold} = 0.75$ (v0.3.0),
applied consistently for both `answer_changed` classification and dissociation
gating. The dual-threshold design (reporting threshold 0.8 vs detection threshold
0.6) from v0.2.0 has been removed.

### 1.3 Distinction from Prior Metrics

| Metric | What it detects | Answer must change? | Confidence must change? |
|--------|----------------|---------------------|-------------------------|
| Calibration Error (ECE) | Static confidence-accuracy mismatch | N/A | N/A |
| Semantic Consistency (SPUQ) | Answer variability under perturbation | **Yes** | No |
| Confidence Dissociation (yuragi) | Confidence variability without answer change | **No** | **Yes** |

The key insight: a model can be well-calibrated on average, semantically consistent across paraphrases, and still exhibit high dissociation — because dissociation is a *dynamic*, *perturbation-induced* phenomenon that neither static calibration nor output-level consistency captures.

---

## Section 2: Orthogonality of Confidence Dissociation

### 2.1 Dissociation ⊥ Semantic Consistency

**Claim**: High dissociation is compatible with high semantic consistency, and low dissociation is compatible with low semantic consistency.

**Case 1** (High dissociation, High consistency): The model answers "Paris" to both $q$ and $q'$, but with confidences 0.95 and 0.15. Answer: stable. Confidence: not. This is the dissociation case by definition.

**Case 2** (Low dissociation, Low consistency): The model answers "Paris" to $q$ and "Lyon" to $q'$, both with confidence ~0.60. Here $\text{sim}(a, a') \approx 0$, so $\text{Dissociation}(q, q') \approx 0$ — no dissociation despite answer change.

**Case 3** (High dissociation, Low consistency): $\text{sim}(a, a') = 0.2$, $|C(q) - C(q')| = 0.8$. $\text{Dissociation} = 0.16$ — low, because the answer changed.

**Formal statement**: The metrics SPUQ-style semantic uncertainty $U_{\text{sem}}(q) = \mathbb{E}_{q' \sim \mathcal{P}(q)}[1 - \text{sim}(M(q), M(q'))]$ and the dissociation metric $D(q) = \mathbb{E}_{q' \sim \mathcal{P}(q)}[\text{Dissociation}(q, q')]$ are not monotonically related. There exist models and query distributions such that $U_{\text{sem}}$ is arbitrarily high or low independent of $D$.

### 2.2 Dissociation ⊥ Expected Calibration Error

The Expected Calibration Error (ECE) is defined as:

$$\text{ECE} = \sum_{b=1}^{B} \frac{|B_b|}{n} \left| \text{acc}(B_b) - \text{conf}(B_b) \right|$$

where $B_b$ are confidence bins.

**Claim**: Dissociation can be high when ECE is near zero, and low when ECE is high.

**Argument**: ECE measures whether the *average* confidence in a bin matches the empirical accuracy in that bin. It is a population-level, static measure. Dissociation measures the *variance* of confidence across perturbations of a *single prompt*. A model can be perfectly calibrated (ECE = 0) while showing high dissociation: if it answers correctly 80% of the time and reports 0.80 confidence, it is calibrated — but if this 0.80 confidence swings to 0.15 under a tone perturbation while still answering correctly, dissociation is high.

**Corollary**: Optimizing for ECE reduction (e.g., temperature scaling, calibration fine-tuning) does not reduce dissociation. These require different interventions.

---

## Section 3: Three-Layer Confidence Model

### 3.1 Motivation

The term "confidence" is ambiguous in LLM systems. We distinguish three operationally distinct measurements, corresponding to three observable layers of model behavior.

### 3.2 Layer Definitions

**Layer 1 — Logprob Layer** $L_1$

Let $p_1, \ldots, p_k$ be the top-$k$ token probabilities at the first generated
position (softmax-normalized). The entropy is computed in nats (natural logarithm,
following Cover & Thomas 2006):

$$H_{\text{nats}}(p) = -\sum_{j=1}^{k} p_j \ln p_j$$

and confidence is the entropy-normalized complement:

$$C_{L_1}(q) = 1 - \frac{H_{\text{nats}}(p)}{\ln k}$$

where $\ln k$ is the maximum entropy for a $k$-class uniform distribution (Jost
2006 Hill-number normalization). This maps the logprob confidence to $[0, 1]$
regardless of $k$: $C_{L_1} = 1$ when all probability mass is on one token;
$C_{L_1} = 0$ when distribution is uniform over $k$ tokens.

> **Cross-model warning (L10)**: OpenAI uses $k = 20$, Groq $k = 10$, Ollama
> (default) $k = 5$. Because the normalization constant $\ln k$ differs,
> confidence values from different providers are not directly comparable. Use
> `--unify-k` or compare within the same provider family.

Availability: OpenAI API (with `logprobs=True`), local models via Ollama.

**Layer 2 — Sampling Layer** $L_2$

$$C_{L_2}(q) = \frac{1}{N} \sum_{i=1}^{N} \mathbb{1}[\text{sim}(a_i, a_{\text{mode}}) > \tau_{\text{sim}}]$$

where $a_1, \ldots, a_N$ are $N$ independent samples and $a_{\text{mode}}$ is the plurality answer. This measures behavioral consistency — the fraction of samples that agree with the majority response.

Availability: All models (model-agnostic, API-key optional via Ollama).

**Layer 3 — Verbalized Layer** $L_3$

$$C_{L_3}(q) = \frac{\text{VerbConf}(q)}{100}$$

where $\text{VerbConf}(q)$ is the integer 0–100 confidence score elicited by appending "Express your confidence as a single integer from 0 to 100." to the prompt. This measures the model's *self-model* — what it believes its own confidence to be.

### 3.3 Independence and Conflict Detection

The three layers are not constrained to agree. Empirically, we observe significant divergence:

- A model with $C_{L_1} = 0.92$ (high logprob confidence) may produce $C_{L_2} = 0.40$ (inconsistent sampling) — suggesting the first token is high-confidence but subsequent reasoning is not.
- A model with $C_{L_3} = 0.85$ (self-reported high confidence) may exhibit $C_{L_1} = 0.30$ — the model's verbalized self-assessment outpaces its token-level certainty.

**Definition 3.1 (Internal Conflict)**

$$\text{InternalConflict}(q) = \max_{i \neq j} |C_{L_i}(q) - C_{L_j}(q)| > \delta_{\text{conflict}}$$

where $\delta_{\text{conflict}} = 0.20$ by default. A model in internal conflict is analogous to a person who reports high confidence verbally while exhibiting hesitant behavior.

**Definition 3.2 (Linguistic Confidence Gap)**

Let $H(q)$ be the hedge density in the generated response (fraction of hedge-bearing tokens: "I think," "perhaps," "it may be"). The linguistic confidence gap is:

$$\text{LCG}(q) = C_{L_3}(q) - (1 - H(q))$$

A large positive LCG indicates the model hedges in its text while asserting high confidence numerically — an internally inconsistent self-representation.

---

## Section 4: Information-Theoretic Grounding

### 4.1 Fragility as Conditional Entropy

We can frame confidence fragility in information-theoretic terms. Let $Q$ be a random variable over prompts (base query + perturbation), $A$ the answer, and $\mathbf{C}$ the confidence measurement.

The fragility of a query $q$ under perturbation distribution $\mathcal{P}$ is related to the conditional entropy of confidence given the answer:

$$H(\mathbf{C} \mid A = a, Q \sim \mathcal{P}(q))$$

When this quantity is large, the model's confidence varies widely even when the answer is fixed — which is precisely the dissociation regime. A perfectly calibrated, non-fragile model would have $H(\mathbf{C} \mid A) \approx 0$: given that the answer is correct, confidence would be consistently high.

### 4.2 Mutual Information Interpretation

Define the mutual information between the perturbation type $T$ and the confidence response:

$$I(T; \mathbf{C}) = H(\mathbf{C}) - H(\mathbf{C} \mid T)$$

High $I(T; \mathbf{C})$ means perturbation type is informative about the confidence outcome — the model responds to semantic framing rather than to the factual content of the question. This is the "social pressure sensitivity" phenomenon observed in Asch experiments.

Low $I(T; \mathbf{C})$ with high overall $H(\mathbf{C})$ means confidence varies unpredictably regardless of perturbation type — random noise in the confidence mechanism.

### 4.3 Fragility Score as KL Divergence

The fragility score can be interpreted as an approximation to the KL divergence between the confidence distribution under the base prompt and the confidence distribution under perturbation:

$$\text{Fragility}(q, q') \approx D_{\text{KL}}(P_{\mathbf{C}}(q) \| P_{\mathbf{C}}(q'))$$

For the sampling-based confidence measure $C_{L_2}$, this approximation becomes exact when we model confidence as a Bernoulli probability and use the binomial approximation.

---

## Section 5: Experimental Predictions

The dissociation theory makes the following falsifiable predictions, each testable using yuragi's benchmark suite:

**Prediction P1 (Factual Fragility Paradox)**: Factual questions with objectively correct answers should exhibit higher dissociation rates than subjective questions, because social pressure perturbations target the model's uncertainty about definitive claims. Subjective questions have no ground truth to be uncertain about.

**Prediction P2 (Layer Divergence at Phase Transition)**: The discrepancy between $C_{L_1}$ and $C_{L_3}$ should spike near fragility phase transitions — points where small perturbation magnitude causes disproportionate confidence drops. This is analogous to a system near a critical point being maximally susceptible to perturbation.

**Prediction P3 (Recovery Asymmetry)**: Confidence recovery after gaslighting should be asymmetric — recovery should be slower and less complete than the initial decline. If confidence decay follows an exponential model $C(t) = \text{plateau} + (C_0 - \text{plateau}) \cdot e^{-\lambda t}$, the recovery rate constant $\lambda_{\text{recovery}} < \lambda_{\text{decay}}$.

**Prediction P4 (Authority Effect Direction)**: Authority framing should increase verbalized confidence ($C_{L_3}$) more than it increases logprob confidence ($C_{L_1}$), because verbalized confidence is more susceptible to instruction-following than token-level probabilities.

**Prediction P5 (Dissociation-Calibration Independence)**: Models trained with calibration fine-tuning (e.g., temperature scaling post-training) should show similar dissociation rates to uncalibrated models, confirming that calibration interventions do not address the dissociation failure mode.

---

## Section 6: Falsifiability Criteria (Evaluation Protocol)

The following criteria form the evaluation protocol that independent
replications can run against yuragi's core claims. As of v0.2.0 this
protocol is **implemented as an executable script** at
[`benchmarks/falsifiability_check.py`](https://github.com/hinanohart/yuragi/blob/main/benchmarks/falsifiability_check.py),
which supports both a deterministic ``dry_run`` mode (default; no LLM
access, used in CI to validate the protocol itself) and a
``--real`` mode that runs against ollama / litellm providers with a
seeded, reproducible sweep. The script emits a JSON report against the
schema ``yuragi/falsifiability/v1`` and exits with code ``0`` iff every
selected criterion passes its threshold.

> **Important — `dry_run` validates the protocol, not the theory.**
> `dry_run` generates synthetic data that is constructed to pass each
> threshold, so a green `dry_run` run only proves that the script,
> JSON schema, and CLI are intact. **Empirical falsification of any
> `Fi` requires `--real` mode with a seeded multi-model sweep**; CI's
> green badge therefore should not be read as "F1–F5 are empirically
> confirmed." Publications replicating yuragi should always cite a
> real-mode run.

> **F4 is a preliminary proxy, not a λ-fit.** The recovery-asymmetry
> criterion currently approximates $\lambda_\text{recovery}$ via
> ``1 − recovery_after_praise`` (a dimensionless magnitude, not a rate
> constant), because `DecayExperiment` does not yet expose a full
> post-praise curve. The ratio $\lambda_\text{recovery} / \lambda_\text{decay}$
> should therefore be read as a *qualitative* asymmetry indicator;
> a v0.3.0 follow-up is planned to add `recovery_confidences`-based
> exponential fitting and replace this proxy with a proper
> dimensional rate-constant ratio.

Example usage:

```bash
# dry_run: synthetic data, validates the protocol in CI (instant)
python benchmarks/falsifiability_check.py --output tests/fixtures/bench/falsifiability.json

# real: full seeded sweep against a local ollama model
python benchmarks/falsifiability_check.py \
    --real --seed 42 --models ollama/llama3.2 --n-prompts 20 \
    --output tests/fixtures/bench/falsifiability_real.json
```

The thresholds below are the defaults; researchers replicating the
experiments can override them via ``DEFAULT_THRESHOLDS`` or by editing
the script.

**F1**: If dissociation rates correlate strongly (Pearson $r > 0.7$) with calibration error (ECE) across a diverse model set, the claim that dissociation is orthogonal to calibration would be undermined.
> *Note*: This criterion requires `--real` mode against live models. A `dry_run` pass only confirms the script logic; it does not constitute empirical support for the orthogonality claim.

**F2**: If SPUQ semantic uncertainty scores and yuragi dissociation scores are strongly correlated ($r > 0.7$) across a diverse prompt set, the orthogonality claim in Section 2.1 would be undermined.
> *Note*: Requires `--real` mode. See `dry_run` caveat above.

**F3**: If factual questions do not show higher dissociation rates than opinion questions on average (across at least 3 models and 20 prompts per category), Prediction P1 would be falsified.
> *Note*: Requires `--real` mode with at least 3 distinct models and ≥20 prompts per category. The pre-computed demo fixtures (`tests/fixtures/bench/*.json`) use `dry_run: true` and are not empirical evidence for this criterion.

**F4**: If confidence recovery after gaslighting is as fast as or faster than the initial confidence decline (i.e., $\lambda_{\text{recovery}} \geq \lambda_{\text{decay}}$), Prediction P3 would be falsified.
> *Note*: Requires `--real` mode. The current proxy (1 − recovery_after_praise) is a magnitude indicator, not a dimensional rate constant; see the F4 caveat block above.

**F5**: If the three-layer measurements $C_{L_1}, C_{L_2}, C_{L_3}$ are consistently within $\pm 0.05$ of each other across a diverse prompt set, the trilayer decomposition would be empirically unmotivated (though theoretically distinct).
> *Note*: Requires `--real` mode on models that expose logprobs (e.g., `ollama/llama3.2`); closed APIs fall back to two-layer measurement.

---

## Section 7: Limitations and Open Questions

### 7.1 Measurement Validity

The verbalized confidence layer ($C_{L_3}$) relies on the model's ability to accurately introspect and report its own uncertainty. There is substantial evidence that LLMs are poor introspectors (Kadavath et al., 2022; OpenAI, 2023). A model reporting "70% confidence" may not have any internal state that corresponds meaningfully to 70%.

This is a known limitation but does not undermine the dissociation measure: even if verbalized confidence is not "real," the *pattern* of its change under perturbation is observable and diagnostically useful.

### 7.2 Similarity Threshold Sensitivity

The dissociation measure depends critically on the semantic similarity threshold $\tau_{\text{sim}} = 0.8$. Different thresholds will produce different dissociation rates. Future work should:
- Use human judgments to validate the threshold on a benchmark set
- Explore embedding-based similarity (e.g., BERTScore) as an alternative to character n-gram Jaccard

### 7.3 Perturbation Space Coverage

yuragi's 10 perturbation types cover a meaningful but non-exhaustive subset of possible prompt variations. The measured fragility score is a lower bound on true fragility — the perturbation that maximally destabilizes confidence may not be in the default set.

### 7.4 Model Architecture Dependence

The three-layer model assumes logprob availability for Layer 1. Many production APIs (e.g., Claude, Gemini) do not expose logprobs. For such models, yuragi falls back to the sampling layer only, losing the logprob-verbalized divergence signal. The internal conflict detection is thus model-family dependent.

### 7.5 Open Questions

1. **Can dissociation be reduced by training?** If dissociation is a structural property of transformer attention, RLHF may not address it. This is an open empirical question.
2. **Does dissociation scale with model size?** Larger models may have stronger self-models ($C_{L_3}$ accuracy), reducing the linguistic confidence gap, while logprob-level fragility remains unchanged.
3. **Is there a confidence analogue of hallucination detection?** High dissociation on a factual query may be a signal of latent hallucination risk — the model is uncertain but not showing it in its answer.
4. **Cross-lingual dissociation**: Does asking the same question in different languages produce different dissociation profiles? Preliminary results suggest yes, but this requires systematic study.

---

---

## Section 8: Relationship to Sycophancy

### 8.1 Sycophancy as a Special Case

Sycophancy in LLMs — the tendency to agree with user assertions regardless of their truth — is a related but distinct phenomenon from confidence dissociation. The relationship is important to clarify.

**Sycophancy** (Perez et al., 2022; Kadavath et al., 2022) refers to changes in model *outputs* (answers, claims) in response to social pressure. It is an answer-level phenomenon.

**Confidence Dissociation** is a confidence-level phenomenon. The model's answer remains stable, but its expressed certainty changes.

The two can co-occur, occur independently, or oppose each other:

| Scenario | Answer changes? | Confidence changes? | Classification |
|----------|:---:|:---:|---|
| Pure sycophancy | Yes | Yes | Sycophancy |
| Pure dissociation | No | Yes | Confidence Dissociation |
| Resistant response | No | No | Neither (ideal) |
| Backfire effect | No | Increases | Negative dissociation |
| Capitulation with confidence | Yes | No | Sycophancy without dissociation |

The **backfire effect** — where contradiction strengthens rather than weakens confidence — is a negative dissociation case. It is observed empirically in yuragi's Asch experiments when questions with very high baseline certainty are targeted (see `docs/experiments.md`, Experiment 1).

### 8.2 Why Dissociation Matters Beyond Sycophancy

Sycophancy is detectable by checking answer consistency. Confidence Dissociation is invisible if only outputs are monitored. A model that consistently gives correct answers but whose confidence fluctuates 50+ percentage points under social pressure is:

1. **Unreliable as a confidence signal**: downstream systems that use model confidence for routing, abstention, or uncertainty flagging will receive corrupted signals.
2. **Undetectable by accuracy metrics**: MMLU, HellaSwag, and similar benchmarks score answer correctness, not confidence stability.
3. **Potentially more dangerous than sycophancy**: a sycophantic model at least signals its capitulation through answer change; a dissociated model maintains the correct answer while quietly losing confidence, making the failure invisible.

---

## Section 9: Perturbation Taxonomy

### 9.1 Structural Classification

yuragi's 10 perturbation types are organized into three structural classes based on what aspect of the prompt they modify:

**Class I — Lexical Perturbations** (modify word choice without changing propositional content):
- `omit`: remove one word
- `synonym`: replace one word with a near-synonym
- `typo`: introduce a plausible keyboard error

**Class II — Syntactic Perturbations** (modify sentence structure without changing word choice):
- `reorder`: reorder words within the prompt
- `paraphrase`: restate the question in different syntactic form
- `semantic`: apply voice, negation, or abstraction transformations

**Class III — Pragmatic Perturbations** (add pragmatic context that changes the communicative situation):
- `tone`: modify formality or register
- `conformity`: add false social consensus framing
- `impostor`: add self-doubt or difficulty framing
- `anchoring`: introduce an irrelevant numerical value

### 9.2 Predicted Dissociation Sensitivity by Class

A key theoretical prediction (related to H1 in Section 5) is that **Class III perturbations should produce higher dissociation rates than Class I and Class II**, because:

- Class I perturbations change the question's surface form minimally; model confidence should be robust to a single lexical substitution if the answer is certain.
- Class II perturbations test syntactic robustness; most models are trained on diverse syntactic forms of the same question.
- Class III perturbations change the pragmatic framing — they introduce social, epistemic, or evaluative context that targets the model's self-model and uncertainty representation, which are not directly tested by training on factual content.

This is Hypothesis H1 in a more fine-grained form: not just "facts are more fragile" but "pragmatic perturbations cause more dissociation across all question types."

### 9.3 Coverage and Completeness

The 10 perturbations cover a meaningful but non-exhaustive subset. The perturbation space has additional unexplored dimensions:

- **Temporal framing**: "In 2010, X was true" vs. "As of today, X is true"
- **Hedging injection**: inserting uncertainty markers into otherwise confident questions
- **Multi-turn pressure**: sequential challenges within a conversation (partially covered by the `trajectory challenge` command)
- **Cross-lingual framing**: asking the same factual question in a language with different epistemic grammatical markers

Each unexplored dimension represents a potential additional source of dissociation not captured by the current measurement.

---

## Section 10: Implementation Notes for Reproducibility

### 10.1 Confidence Measurement Choices

The implementation of $C_{L_1}$, $C_{L_2}$, and $C_{L_3}$ involves non-trivial decisions that affect reproducibility:

**For $C_{L_1}$ (logprob)**:
- yuragi uses the probability of the *first generated token* (top-1 logprob after softmax)
- This is not equivalent to the probability of the full answer — it is a one-token proxy
- For binary questions ("yes/no"), this approximation is exact; for open-ended questions, it is a lower bound on full-sequence probability
- Models without logprob APIs (Claude, Gemini) fall back to $C_{L_2}$ only

**For $C_{L_2}$ (sampling)**:
- Default: $N = 5$ samples per prompt
- Default similarity threshold: $\tau_{\text{sim}} = 0.8$ (character 3-gram Jaccard)
- The mode answer $a_{\text{mode}}$ is determined by plurality vote; ties are broken by first occurrence
- Confidence is reported as the fraction agreeing with the mode, not the fraction giving the correct answer (ground truth not required)

**For $C_{L_3}$ (verbalized)**:
- Elicitation prompt: "Express your confidence as a single integer from 0 to 100."
- The model's response is parsed with a regex that extracts the first integer in [0, 100]
- If no valid integer is found, the response is logged and a fallback value of 50 is used (unknown confidence, not zero)
- This elicitation prompt is held constant across all experiments for comparability

### 10.2 Similarity Computation

The semantic similarity $\text{sim}(a, a')$ used in the dissociation formula is computed as character-level 3-gram Jaccard similarity:

$$\text{sim}_{\text{Jaccard}}(a, a') = \frac{|\text{3gram}(a) \cap \text{3gram}(a')|}{|\text{3gram}(a) \cup \text{3gram}(a')|}$$

This choice is motivated by:
- **Speed**: no embedding model required; works offline
- **Language agnosticism**: character n-grams generalize across languages without tokenizer dependencies
- **Monotonicity**: longer shared substrings produce higher similarity, which correlates with semantic agreement for factual answers

The threshold $\tau_{\text{sim}} = 0.8$ was chosen empirically to separate near-verbatim repetitions (same answer, different phrasing) from answer changes. Future versions should validate this threshold against human annotations.

### 10.3 Cache Invalidation and Seed Control

Starting in v0.2.0 Phase 0:
- Cache keys include: `(model_id, system_prompt, user_prompt, temperature, max_tokens, seed)` — the system prompt is now part of the cache key (Phase 0 fix)
- Reproducible runs use `--seed` to fix the random seed passed to the model API
- The cache TTL defaults to 24 hours; benchmark runs should use `--no-cache` to ensure fresh measurements

These changes ensure that results reported in papers are reproducible without silent cache contamination from previous runs with different system prompts.

### 10.4 Dissociation Implementation Constants

The Dissociation formula — $\text{Dissociation}(q, q') = \text{sim}(a, a') \cdot |C(q) - C(q')|$ — is applied directly in the reference implementation (`src/yuragi/core.py`). All tunable constants live in `YuragiConfig` (frozen dataclass).

**v0.3.0 constants (active)**:

| Constant | Value | Purpose |
|---|---|---|
| `dissociation_noise_floor` | `0.06` | $\tau$ in Def 1.1d; confidence shifts below this are treated as noise |
| `answer_similarity_threshold` | `0.75` | Unified $\tau_{\text{sim}}$ for `answer_changed` and dissociation gating |
| `top_logprobs_k` | `5` | Default $k$ for entropy normalization: $\ln k$ in $C_{L_1}$ formula |
| `similarity_backend` | `"jaccard"` | Character 3-gram Jaccard used for $\text{sim}(a, a')$ |

**v0.2.0 constants removed in v0.3.0**:

| Removed constant | Previous value | Reason |
|---|---|---|
| `dissociation_scaling_factor` | `3.0` | Dissociation formula is now scale-free; range [0,1] by construction |
| `fragility_normalization_std` | `0.3` | Replaced by mean(|ΔC|) which needs no normalization constant |
| `entropy_max` | (computed) | Replaced by $\ln k$ from `top_logprobs_k`; nats convention (Cover & Thomas 2006) |
| `dissociation_similarity_threshold` | `0.6` | Dual-threshold design eliminated; unified at `answer_similarity_threshold=0.75` |

These constants were tuned against the Asch reproduction so that the classical
`4 → 26%` confidence drop on `"2 + 2"` fires `is_dissociated = True` while a
purely stochastic 3-percentage-point wobble does not.

---

## References

- Asch, S. E. (1951). Effects of group pressure upon the modification and distortion of judgments. In *Groups, leadership and men* (pp. 177–190). Carnegie Press.
- Cover, T. M., & Thomas, J. A. (2006). *Elements of Information Theory* (2nd ed.). Wiley-Interscience. [Nats convention, Chapter 2.]
- Efron, B. (1979). Bootstrap methods: Another look at the jackknife. *Annals of Statistics*, 7(1), 1–26. [Percentile bootstrap used in `fragility_ci_95()`.]
- Efron, B. (1987). Better bootstrap confidence intervals. *Journal of the American Statistical Association*, 82(397), 171–185. [BCa bootstrap — planned for v0.3.1; not yet implemented.]
- Baltaji et al. (2025). Conformity, Conflict, and Shift: Uncovering LLM Susceptibility to Conformity Bias. ACL 2025, arXiv:2410.12428.
- Fanous et al. (2025). SycEval: Evaluating LLM Sycophancy. arXiv:2502.08177.
- Farquhar, S., Kossen, J., Kuhn, L., & Gal, Y. (2024). Detecting hallucinations in large language models using semantic entropy. *Nature*, 630, 625–630. [NLI-based clustering; yuragi uses a Farquhar-inspired approximation with Jaccard/embedding-cosine fallback — not the full NLI method.]
- Fastowski et al. (2025). From Confidence to Collapse: Analyzing Factual Robustness in LLMs. arXiv:2508.16267, EMNLP 2025 Findings.
- Festinger, L. (1957). *A Theory of Cognitive Dissonance*. Stanford University Press.
- Gao, T., et al. (2024). SPUQ: Perturbation-based uncertainty quantification for large language models. *Proceedings of EACL 2024*.
- Hong et al. (2025). SYCON-Bench: Multi-turn Sycophancy Benchmark. arXiv:2505.23840, Findings of EMNLP 2025.
- Kadavath, S., et al. (2022). Language models (mostly) know what they know. *arXiv:2207.05221*.
- Jost, L. (2006). Entropy and diversity. *Oikos*, 113(2), 363–375. [Hill-number / ln(k) normalization for entropy-based confidence.]
- Kahneman, D. (2011). *Thinking, Fast and Slow*. Farrar, Straus and Giroux.
- Kuhn, L., et al. (2023). Semantic uncertainty: Linguistic invariances for uncertainty estimation in natural language generation. ICLR 2023.
- Lin, S., Hilton, J., & Evans, O. (2022). Teaching models to express their uncertainty in words. *Transactions on Machine Learning Research*. arXiv:2205.14334.
- Liu et al. (2025). TRUTH DECAY: Quantifying Multi-Turn Sycophancy in LLMs. arXiv:2503.11656.
- Murdock, B. B., Jr. (1962). The serial position effect of free recall. *Journal of Experimental Psychology*, 64(5), 482–488.
- Nisbett, R. E., & Wilson, T. D. (1977). The halo effect: Evidence for unconscious alteration of judgments. *Journal of Personality and Social Psychology*, 35(4), 250–256.
- Perez, E., Ringer, S., Lukošiūtė, K., et al. (2022). Discovering language model behaviors with model-written evaluations. *arXiv:2212.09251*.
- Thorndike, E. L. (1920). A constant error in psychological ratings. *Journal of Applied Psychology*, 4(1–2), 25–29.
- Tversky, A., & Kahneman, D. (1974). Judgment under uncertainty: Heuristics and biases. *Science*, 185(4157), 1124–1131.
- Vashurin, R., et al. (2024). Benchmarking LLM uncertainty quantification methods. *Transactions of the Association for Computational Linguistics*, 12, 1186–1206.
- Zhang et al. (2025). Calibrating LLM Confidence by Probing Perturbed Representation Stability. arXiv:2505.21772, EMNLP 2025.
