# Architecture

## Module Overview

```
yuragi/
├── cli/                      CLI package (Click commands)
│   ├── __init__.py           Entry point (main group)
│   ├── scan.py               scan, find-weakness commands
│   ├── experiment.py         experiment commands
│   ├── compare.py            compare command
│   ├── analysis.py           stats, trilayer, profile, linguistic, volatility, phase-map
│   ├── advanced.py           trajectory command
│   ├── utility.py            export, demo commands
│   └── helpers.py            Shared CLI utilities
├── core.py                   Scanner, ScanResult, PerturbationResult
├── utils.py                  Shared utilities
├── cache.py                  SQLite response cache with TTL
├── parallel.py               Async parallel API calls
├── badges.py                 Fragility badge generation
├── exceptions.py             Custom exception types
│
├── providers/
│   └── adapter.py            LLMAdapter, CompletionResult, ModelCapabilities
│
├── perturbations/
│   ├── __init__.py           Perturbation enum + generator dispatch (10 types)
│   ├── omit.py               Single-word omission
│   ├── synonym.py            Synonym substitution
│   ├── tone.py               Formality/register shift
│   ├── typo.py               Keyboard-proximity typos
│   ├── reorder.py            Word order permutation
│   ├── paraphrase.py         Full rephrase
│   ├── social.py             Social consensus, impostor, anchoring injection
│   └── semantic.py           Voice/negation/abstraction transforms
│
├── metrics/
│   ├── calibration.py        ECE, Mutual Information, Brier Score
│   └── volatility.py         VIX, Sharpe ratio, drawdown, regime detection
│
├── analysis/
│   ├── fragility_profile.py  FragilityProfile (CCI, RE, NLS)
│   ├── minimal_edit.py       Gradient-style weakest-word search
│   ├── statistics.py         Cohen's d, bootstrap CI, IQR
│   ├── trajectory.py         Confidence over prompt sequences
│   ├── trilayer.py           Three-method simultaneous comparison
│   ├── adversarial.py        Confidence flip, sycophancy, pressure resistance
│   ├── decay.py              Learned helplessness confidence decay
│   ├── recovery.py           Recovery strategy analysis
│   ├── fingerprint.py        Model behavioral fingerprinting
│   ├── linguistics.py        Hedge detection, assertiveness
│   └── phase_transition.py   Critical point detection
│
├── visualize/
│   ├── heatmap.py            Confidence heatmap
│   ├── dashboard.py          Interactive HTML dashboard
│   ├── landscape.py          Confidence landscape
│   ├── comparison.py         Multi-model comparison
│   ├── trajectory_plot.py    Trajectory visualization
│   └── html_report.py        Full HTML report generation
│
└── experiments/
    ├── registry.py           9 ExperimentSpec definitions + registry
    └── runner.py             Experiment execution
```

## Module Dependency Graph

```
cli.py
  ├── core.py (Scanner, ScanResult)
  │     └── providers/adapter.py (LLMAdapter, CompletionResult)
  │           └── litellm  [external]
  │
  ├── analysis/fragility_profile.py
  │     └── core.py
  │
  ├── analysis/minimal_edit.py
  │     └── core.py
  │     └── providers/adapter.py
  │
  ├── analysis/statistics.py
  │     └── core.py
  │
  ├── analysis/trajectory.py
  │     └── providers/adapter.py
  │
  ├── analysis/trilayer.py
  │     └── providers/adapter.py
  │
  ├── experiments/registry.py  (no internal deps)
  │
  ├── experiments/runner.py
  │     ├── experiments/registry.py
  │     └── providers/adapter.py
  │
  └── metrics/calibration.py
        └── core.py
```

Key property: `providers/adapter.py` has no internal dependencies. `core.py` depends only on `providers/adapter.py` and `perturbations/`. All analysis modules depend on `core.py` or `providers/adapter.py`, never on each other. This makes the dependency graph a directed acyclic graph with a single root at `cli.py`.

## Data Flow

### 1. Full Scan (`yuragi scan`)

```
User prompt
    │
    ▼
Scanner.scan(prompt, system)
    │
    ├─ LLMAdapter.complete(prompt)          → CompletionResult  [baseline]
    │
    ├─ For each Perturbation type:
    │     ├─ perturbation.generator(prompt)  → [variant_1, ..., variant_k]
    │     └─ For each variant:
    │           LLMAdapter.complete(variant) → CompletionResult
    │           PerturbationResult(original_response, perturbed_response)
    │
    └─ ScanResult(baseline, [PerturbationResult, ...])
          │
          ├─ .fragility_score               (population std dev, normalized)
          ├─ .dissociation_rate            (fraction of dissociated results)
          ├─ .confidence_range              (max - min confidence)
          └─ .weakest_perturbation          (min confidence_delta)
```

### 2. Confidence Measurement Selection

```
LLMAdapter.complete(prompt)
    │
    ├─ capabilities.supports_logprobs?
    │     YES → _complete_with_logprobs()
    │               → Shannon entropy over top-k logprobs
    │               → confidence = max(0, 1 - H̄/3)
    │
    └─     NO  → _complete_with_sampling()
                    → N queries at τ=0.7
                    → pairwise char-3-gram Jaccard
                    → confidence = mean pairwise similarity
```

### 3. Experiment Flow

```
ExperimentSpec (control/treatment pairs)
    │
    ▼
run_experiment(spec, model, num_samples)
    │
    ├─ For each (control_prompt, treatment_prompt):
    │     ├─ LLMAdapter.complete(control_prompt)   → CompletionResult
    │     └─ LLMAdapter.complete(treatment_prompt) → CompletionResult
    │         ExperimentResult(control, treatment, answer_changed, effect_name)
    │
    └─ Experiment(spec, model, [ExperimentResult, ...])
          ├─ .avg_delta
          ├─ .max_delta
          ├─ .dissociation_rate
          └─ .effect_confirmed  (max_delta >= 0.15)
```

### 4. Trilayer Analysis

```
prompt
    │
    ├─ Layer 1: _complete_with_logprobs()     → logprob_confidence (or None)
    ├─ Layer 2: _complete_with_sampling()     → sampling_confidence
    └─ Layer 3: complete_verbalized()         → verbalized_confidence
          │
          └─ TrilayerResult
                ├─ .max_discrepancy    (max - min across available layers)
                └─ .internal_conflict  (discrepancy > 0.2)
```

## Extension Points

### Adding a Confidence Measurement Method

Implement a new method on `LLMAdapter` in `src/yuragi/providers/adapter.py`. The method must return a `CompletionResult` with a `confidence` value in [0, 1] and an appropriate `confidence_method` string. Then add selection logic to `LLMAdapter.complete()`.

### Adding a Perturbation Type

1. Create `src/yuragi/perturbations/your_type.py` with a function `generate(prompt: str, num_variants: int) -> list[str]`.
2. Add an entry to the `Perturbation` enum in `src/yuragi/perturbations/__init__.py`.
3. Wire the generator in the enum's dispatch map.

No changes to `core.py`, `cli.py`, or analysis modules are needed.

### Adding a Calibration Metric

Add a function to `src/yuragi/metrics/calibration.py` that accepts `list[PerturbationResult]` and returns a `float`. Add the field to `CalibrationReport` and call your function in `compute_calibration()`.

### Adding a CLI Command

yuragi uses [Click](https://click.palletsprojects.com/). Add a command function in the appropriate `src/yuragi/cli/` submodule and register it via `main.add_command()` in `src/yuragi/cli/__init__.py`. The command should call into an existing module; no business logic should live in CLI files.

### Adding an Experiment

Add an `ExperimentSpec` to `src/yuragi/experiments/registry.py` and register it in `_EXPERIMENTS`. See `docs/experiments.md` for protocol requirements.

## Key Design Decisions

**litellm as the single LLM interface**: yuragi uses [litellm](https://docs.litellm.ai/) to abstract over 100+ model providers. This means yuragi works with any model litellm supports without per-provider adapters.

**`drop_params = True`**: litellm is configured to silently drop unsupported parameters (e.g., `logprobs` on Anthropic models). This allows the same code path to handle logprob-capable and logprob-incapable models.

**No async**: All API calls are synchronous. This simplifies the code and avoids event loop management. For high-throughput use cases, callers can parallelize at the Scanner level.

**Char-3-gram for answer comparison**: Language-agnostic; does not require tokenization. Used for both `answer_changed` detection and multi-sample agreement. Consistent metric across the codebase.

**Population (not sample) standard deviation for Fragility Score**: The set of perturbation results is treated as the complete population for a given scan, not a sample. This is the appropriate choice since we are describing the observed variance of a specific scan, not estimating population variance.
