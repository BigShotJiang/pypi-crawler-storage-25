# Frequently Asked Questions

## "Isn't this just an API wrapper?"

No. The novel contribution is the **measurement framework**, not the API calls.

Any script can call an LLM API twice and compare outputs. What yuragi provides that does not exist elsewhere:

1. **Confidence Dissociation as a first-class metric**: The distinction between "answer changed" and "confidence changed without answer change" is not implemented in any other tool. SPUQ measures answer consistency; ProSA measures output variance. Neither measures the confidence-answer decoupling that yuragi defines as dissociation.

2. **Fragility Profile (CCI/RE/NLS)**: These three metrics capture the *structure* of confidence instability — how efficiently a single edit destroys confidence (CCI), whether confidence recovers (RE), and whether the response is predictably or chaotically sensitive (NLS). This tripartite decomposition does not appear in the prior literature.

3. **Systematic perturbation taxonomy**: The ten perturbation types are derived from distinct linguistic and psychological phenomena. Omit tests information load; synonym tests surface vs. semantic anchoring; tone tests register sensitivity; typo tests noise robustness; reorder tests structural vs. content anchoring; paraphrase tests formulation dependence; semantic tests meaning-preserving transformations; social/impostor/anchoring test psychology-inspired manipulations. Running all ten gives a structured profile across multiple dimensions of fragility.

4. **Trilayer Analysis**: Simultaneous measurement via logprobs, sampling, and verbalization reveals disagreement between what the model "internally signals" (token distribution), "behaviorally demonstrates" (sampling consistency), and "explicitly claims" (self-report). This three-way comparison is not available elsewhere.

In short: the API calls are the transport layer. The measurement theory, metric definitions, and experimental protocols are the contribution.

---

## "How is this different from SPUQ?"

[SPUQ](https://github.com/intuit-ai-research/SPUQ) (Semantic Perturbation for Uncertainty Quantification, Intuit Research, EACL 2024) is the closest prior work. Key differences:

| Dimension | SPUQ | yuragi |
|-----------|------|--------|
| Primary metric | Semantic consistency (does answer change?) | Confidence fragility (does *certainty* change?) |
| Confidence Dissociation detection | No | Yes — answer stable but confidence shifted |
| Perturbation types | Paraphrase, system message, dummy tokens, temperature | 13 types including psychology-derived (social pressure, impostor, anchoring, negation, counterfactual, code-switching) |
| Fragility Profile | No | CCI, Recovery Elasticity, Non-linearity Score |
| Trilayer analysis | No | Logprob / sampling / verbalized simultaneously |
| Psychology experiments | No | 11 experiments (Asch, Impostor, Authority, Anchoring, Gaslighting, Framing, Dissonance, Halo, Primacy-Recency, Dunning-Kruger, Test-Time Compute Fragility) |
| CLI interface | No (research code, Jupyter) | Full CLI, pip-installable |
| Model support | Limited (paper uses specific models) | 100+ via litellm, including local models |
| Language support | English-centric | Language-agnostic (char n-gram) |
| Statistical analysis | Basic | Cohen's d, bootstrap CI, IQR |

The core philosophical difference: SPUQ asks "does the model give the same answer under paraphrase?" yuragi asks "does the model's *certainty* remain stable, regardless of whether the answer changes?" These are orthogonal questions. A model can be perfectly consistent (same answer every time) while being catastrophically fragile (confidence swings wildly). SPUQ would rate it reliable; yuragi would flag it as fragile.

---

## "Are you claiming AI has an unconscious?"

No. yuragi makes no claims about consciousness, phenomenal experience, or Freudian-style unconscious processes in AI systems.

The philosophical thesis is strictly structural: **human confidence and AI confidence exhibit the same mathematical properties under perturbation**. Specifically:

- **Fragility**: Both collapse under small inputs.
- **Non-linearity**: Both respond disproportionately to minor changes.
- **Inexplicability**: Neither humans nor interpretability tools can fully explain why specific tokens matter.
- **Confidence Dissociation**: Both exhibit answer-confidence decoupling (humans call this "knowing but doubting"; in AI it has no standard name — yuragi introduces "dissociation").

This structural similarity is a testable empirical claim, not a metaphysical one. It does not require attributing subjective states to the model. The parallel is the same kind of structural analogy made when calling a thermometer "temperature" — the analogy is useful and precise without claiming thermometers *feel* hot.

The psychology experiments in yuragi are named after human psychological phenomena because the experimental *designs* are adapted from those studies. The experiments test whether the *behavioral pattern* — confidence change under social pressure, authority framing, etc. — is structurally similar in LLMs. That is a falsifiable empirical question.

---

## "Which models should I use?"

### For research / highest accuracy

**OpenAI GPT-4o or GPT-4o-mini**: These support logprob access, which gives the most theoretically grounded confidence measurement (Shannon entropy over token distribution). If you are publishing results, this is the recommended configuration.

```bash
yuragi scan "Your question" --model gpt-4o
```

### For local / free usage

**Ollama with llama3.2 or similar**: No API key required, runs on consumer hardware. Uses multi-sample agreement mode (N=5 by default). Results are noisier than logprob mode but sufficient for exploratory analysis.

```bash
ollama pull llama3.2
yuragi scan "Your question" --model ollama/llama3.2
```

### For Anthropic models

**claude-haiku-4-5** (fast, cheap) or **claude-sonnet-4-6** (higher quality): Use multi-sample mode. Note that Anthropic models tend to be more verbose; the char-3-gram similarity threshold (0.6) may need adjustment for very long responses.

```bash
yuragi scan "Your question" --model claude-haiku-4-5
```

### For comparing across models

Use `yuragi compare` with a comma-separated model list:

```bash
yuragi compare "Is AI dangerous?" --model gpt-4o-mini,claude-haiku-4-5,ollama/llama3.2
```

### General recommendations

- For **psychology experiments**: any model works; effect sizes tend to be largest on instruction-tuned models.
- For **fragility profiling**: logprob-capable models (GPT-4o family) give the most precise CCI/NLS values.
- For **trilayer analysis**: logprob-capable models are required to populate Layer 1; otherwise only Layer 2 and 3 are available.
- Increase `--samples` / `-n` (default 5) for more stable multi-sample confidence estimates. 10–20 samples reduces variance significantly at proportional cost.

---

## "How do I cite yuragi in a paper?"

### BibTeX

```bibtex
@software{yuragi2026,
  author       = {hinanohart},
  title        = {yuragi: {LLM} Confidence Fragility Analyzer},
  year         = {2026},
  version      = {0.1.0},
  url          = {https://github.com/hinanohart/yuragi},
  note         = {Measures dissociation, fragility profile, and psychological
                  experiment effects on LLM confidence stability}
}
```

### APA

hinanohart. (2026). *yuragi: LLM Confidence Fragility Analyzer* (Version 0.1.0) [Software]. https://github.com/hinanohart/yuragi

### Citing specific metrics

If citing the Confidence Dissociation metric specifically:

> We measure dissociation as defined in yuragi (hinanohart, 2026): a perturbation is dissociated when answer similarity ≥ 0.6 (char-3-gram Jaccard) but confidence shifts by more than 0.06, with severity = min(1, similarity × |Δconfidence| × 3).

If citing the Fragility Profile:

> We report the Catastrophic Collapse Index (CCI), Recovery Elasticity (RE), and Non-linearity Score (NLS) as defined in yuragi (hinanohart, 2026). CCI = min(1, max|Δconfidence|/edit_distance / 0.05); RE = min(1, max_boost/|max_drop|); NLS = min(1, std(Δconfidence/edit_distance) / 0.03).

See `CITATION.cff` in the repository root for machine-readable citation metadata.
