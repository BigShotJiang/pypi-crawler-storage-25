# CLI Reference

## Global options

```
yuragi [--quiet] <command> [options]
```

| Option | Description |
|--------|-------------|
| `--quiet` | Suppress logo and decorative output |

---

## `scan`

Confidence fragility scan across perturbation types.

```bash
yuragi scan "Is quantum computing practical?" --model gpt-4o-mini
```

| Option | Default | Description |
|--------|---------|-------------|
| `--model`, `-m` | `ollama/llama3.2` | litellm model string |
| `--samples`, `-n` | `5` | Samples per perturbation |
| `--variants`, `-v` | `3` | Variants per perturbation type |
| `--perturbations`, `-p` | all | Comma-separated perturbation types |
| `--json-output`, `-j` | — | Output raw JSON |
| `--html` | — | Save HTML report |
| `--plot` | — | Save PNG confidence chart |
| `--csv-output` | — | Save CSV results |
| `--dashboard` | — | Save interactive HTML dashboard |

---

## `find-weakness`

Pinpoints the single word whose removal causes the largest confidence drop.

```bash
yuragi find-weakness "Explain the theory of relativity" --model ollama/llama3.2
```

| Option | Default | Description |
|--------|---------|-------------|
| `--model`, `-m` | `ollama/llama3.2` | litellm model string |
| `--samples`, `-n` | `5` | Samples per word removal |

---

## `experiment`

Run a psychology experiment.

```bash
yuragi experiment asch --model ollama/llama3.2
```

Available experiments: `asch`, `impostor`, `authority`, `anchoring`, `gaslighting`, `framing`, `dissonance`, `halo`, `primacy`, `dunning_kruger`, `test_time_compute`

| Option | Default | Description |
|--------|---------|-------------|
| `--model`, `-m` | `ollama/llama3.2` | litellm model string |
| `--samples`, `-n` | `5` | Trials per experiment |
| `--json-output`, `-j` | — | Output raw JSON |
| `--markdown` | — | Save Markdown report |

---

## `compare`

Side-by-side confidence fragility comparison across models.

```bash
yuragi compare "Is AI dangerous?" --model ollama/llama3.2,gpt-4o-mini
```

| Option | Default | Description |
|--------|---------|-------------|
| `--model`, `-m` | required | Comma-separated model strings |
| `--samples`, `-n` | `5` | Samples per model |
| `--json-output`, `-j` | — | Output raw JSON |

---

## `compare-models`

Multi-model fragility profile with statistical tests (Cohen's d, paired t-test,
Wilcoxon) and perturbation × model heatmap export. Designed for paper-grade
comparisons across 2+ local or remote models.

```bash
yuragi compare-models \
  --models qwen3:4b,phi4-mini,gemma3:4b,llama3.2:3b \
  -p "Is quantum computing practical?" \
  --output report.json --heatmap heatmap.png
```

| Option | Default | Description |
|--------|---------|-------------|
| `--models` | required | Comma-separated litellm model strings (2+) |
| `--prompts`, `-p` | required | Prompt string (can be repeated for multiple prompts) |
| `--samples`, `-n` | `5` | Samples per model per perturbation |
| `--output` | — | Write JSON report with statistical tests |
| `--heatmap` | — | Save perturbation × model fragility heatmap (PNG) |

---

## `trilayer`

Measures three confidence layers: token logprobs, behavioral consistency, verbalized confidence.

```bash
yuragi trilayer "Is AI dangerous?" --model ollama/llama3.2
```

| Option | Default | Description |
|--------|---------|-------------|
| `--model`, `-m` | `ollama/llama3.2` | litellm model string |
| `--samples`, `-n` | `5` | Samples per layer |

---

## `profile`

Full fragility profile combining scan, trilayer, and linguistic analysis.

```bash
yuragi profile "Is nuclear energy safe?" --model gpt-4o-mini
```

---

## `trajectory`

Confidence trajectory across a sequence of related prompts.

```bash
yuragi trajectory --prompts prompts.txt --model ollama/llama3.2
```

---

## `stats`

Statistical distribution of confidence across many samples.

```bash
yuragi stats "Is Python the best language?" --model ollama/llama3.2
```

---

## `linguistic`

Measures the gap between linguistic hedging in text and numerical confidence.

```bash
yuragi linguistic "Is climate change human-caused?" --model gpt-4o-mini
```

---

## `volatility`

Confidence Volatility Index (VIX) — financial engineering applied to LLM confidence.

```bash
yuragi volatility "Is AGI coming soon?" --model gpt-4o-mini
```

---

## `phase-map`

Detects phase transition critical points in confidence.

```bash
yuragi phase-map "Is quantum computing practical?" --model gpt-4o-mini
```

---

## `export`

Convert a saved JSON result to CSV or Markdown.

```bash
yuragi export --source scan --input result.json --output report.csv --format csv
```

---

## `demo`

Run a built-in demo with pre-recorded data (no API key required).

```bash
yuragi demo
```
