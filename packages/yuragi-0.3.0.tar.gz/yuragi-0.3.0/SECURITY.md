# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability, please report it via [GitHub Private Vulnerability Reporting](https://github.com/hinanohart/yuragi/security/advisories/new).

Do not open a public issue for security vulnerabilities.

## API Key Safety

yuragi uses LLM API keys. Please:

- Never commit API keys to version control
- Use environment variables or `.env` files (`.env` is in `.gitignore`)
- Be aware that prompts are sent to external API providers when using cloud models
- Use `ollama` for fully local, offline operation

## Local Cache Privacy

yuragi caches LLM prompts and responses in plaintext at `~/.yuragi/cache.db`
(SQLite). Cache keys are hashed, but the stored values are not encrypted. When
processing confidential prompts, clear or disable the cache:

```python
from yuragi.cache import ResponseCache
ResponseCache().clear()
```

Or simply `rm -rf ~/.yuragi/` between sessions.

## Supported Versions

| Version | Supported |
|---------|-----------|
| 0.3.x   | Yes       |
| 0.2.x   | Security fixes only |
| 0.1.x   | No        |
