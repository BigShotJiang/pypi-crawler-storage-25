# Roadmap

## v0.2.0 (Current, 2026-04-11) — Empirical Reproducibility & Academic-Grade Foundation

- [x] Semantic Entropy (Farquhar et al., Nature 2024) + Verbalized↔Logit Gap
- [x] 13 perturbation types (added `negation`, `counterfactual`, `code_switching`)
- [x] 11 psychology experiments (added `dunning_kruger`, `test_time_compute`)
- [x] Statistical tests (Cohen's d, paired t-test, Wilcoxon, bootstrap CI)
- [x] Multi-model `compare-models` CLI + perturbation × model heatmap
- [x] Agentic UQ trajectory tracking (`track_agentic_session`)
- [x] TruthfulQA / SimpleQA / HaluEval loaders
- [x] `YuragiConfig` frozen dataclass (40 fields) threaded through all 15 analysis modules
- [x] Lazy litellm loader (PEP 562) — CLI cold start **2.5 s → 0.11 s (22×)**
- [x] `benchmarks/falsifiability_check.py` — executable F1–F5 protocol
- [x] `docs/theory.md` — formal Definitions 1.1a/1.1b/1.2 + Section 10.4 implementation constants
- [x] Narrative / implementation alignment pass (Round 5–9, 16-agent audit)
- [x] 1050 tests passing / 1166 collected / ruff + bandit clean

## v0.1.0 (2026-04-10, Released) — Full Fragility Analysis

- [x] Core scanner with 10 perturbation types
- [x] 3-layer confidence measurement (logprobs, sampling, verbalized)
- [x] 9 psychology experiments (Asch, Impostor, Authority, Anchoring, Gaslighting, Framing, Cognitive Dissonance, Halo Effect, Primacy-Recency)
- [x] Fragility Profile (CCI, Recovery Elasticity, Non-linearity Score)
- [x] Confidence decay (Learned Helplessness) and recovery analysis
- [x] Model behavioral fingerprinting
- [x] Adversarial confidence analysis (flip, sycophancy, pressure resistance)
- [x] Financial-engineering metrics (VIX, Sharpe, drawdown, regime detection)
- [x] Phase transition detection
- [x] Linguistic confidence gap (hedge detection, assertiveness)
- [x] Calibration metrics (ECE, Brier, mutual information)
- [x] 13 CLI commands, Rich TUI
- [x] 978 tests, 95% coverage

## v0.2.0 — Empirical Reproducibility & Academic-Grade Foundation

**Theme**: Move from "working tool" to "research-grade, reproducible, academically credible."

The v0.2.0 cycle is organized into four phases:

### Phase 0: Reproducibility Hardening (infrastructure) — COMPLETE
- [x] Fix cache key to include system prompt (eliminates silent result contamination)
- [x] Deterministic sampling with seed support
- [x] Structured JSON output for all CLI commands
- [x] Data files moved to `data/` directory; log bug fixed

### Phase 1: Dissociation Benchmark (empirical validation)
- [ ] Controlled dissociation benchmark across 3+ models
- [ ] `benchmarks/dissociation_reproducibility.py` — canonical reproducibility script
- [ ] Ground-truth answer similarity validation (human-validated threshold)
- [ ] Formal falsifiability test suite (theory.md Section 6 criteria)

### Phase 2: Academic Documentation — COMPLETE (Phase 3a)
- [x] Expanded `docs/theory.md` (~500 lines, Sections 1–10 including perturbation taxonomy and implementation notes)
- [x] `docs/related_work.md` with quantitative feature comparison matrix (SPUQ, lm-polygraph, Semantic Entropy, Calibration-Tuning, Kadavath, ProSA, TrustLLM, UQ360)
- [x] `docs/experiments.md` Experiments 7–9 (Cognitive Dissonance, Halo Effect, Primacy-Recency) fully documented
- [x] CITATION.cff updated with full academic reference list and version 0.2.0
- [x] `CODE_OF_CONDUCT.md` (Contributor Covenant 2.1)
- [x] README narrative corrected: Fragility Score vs. Confidence Dissociation separated with formal definitions
- [ ] MkDocs documentation site (GitHub Pages) — deferred to Phase 3b

### Phase 3b: Ecosystem & Usability
- [ ] Cross-model benchmark database with shareable results
- [ ] Plugin system for custom perturbation types
- [ ] `yuragi watch` — continuous monitoring mode
- [ ] Pre-built Docker image

## v0.3.0 — Scale & Integration

- [ ] Async Scanner API for batch workloads
- [ ] CI integration (GitHub Action / pre-commit hook)
- [ ] Confidence regression testing ("did this prompt change break confidence?")
- [ ] Export to W&B / MLflow
- [ ] Multi-language prompt support (beyond EN/JA)
