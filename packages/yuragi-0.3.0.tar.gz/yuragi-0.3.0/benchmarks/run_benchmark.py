#!/usr/bin/env python3
"""Run the standard benchmark suite.

Produces reproducible results for README and cross-model comparison.

Usage:
    python benchmarks/run_benchmark.py --model ollama/llama3.2 --category factual
    python benchmarks/run_benchmark.py --model ollama/llama3.2 --all
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from dotenv import load_dotenv

load_dotenv(Path(__file__).parent.parent / ".env")

from rich import box
from rich.console import Console
from rich.table import Table

from benchmarks.standard_questions import CATEGORIES
from yuragi.core import Scanner
from yuragi.perturbations import Perturbation

console = Console()


def run_benchmark(
    model: str,
    questions: list[str],
    category: str,
    num_samples: int = 3,
    num_variants: int = 2,
) -> dict:
    """Run benchmark on a set of questions."""
    scanner = Scanner(
        model=model,
        num_samples=num_samples,
        perturbations=[Perturbation.TONE, Perturbation.OMIT, Perturbation.SYNONYM],
        num_variants=num_variants,
    )

    results = []
    for i, q in enumerate(questions):
        console.print(f"  [{i + 1}/{len(questions)}] {q[:50]}...")
        try:
            result = scanner.scan(q)
            results.append({
                "question": q,
                "fragility_score": result.fragility_score,
                "fragility_label": result.fragility_label(),
                "confidence_range": result.confidence_range,
                "dissociation_rate": result.dissociation_rate,
                "baseline_confidence": result.baseline.confidence,
                "max_drop": result.max_confidence_drop,
                "n_perturbations": len(result.perturbation_results),
            })
        except Exception as e:
            console.print(f"    [red]Error: {e}[/red]")
            results.append({"question": q, "error": str(e)})
        time.sleep(1)

    # Aggregate
    valid = [r for r in results if "error" not in r]
    if valid:
        avg_fragility = sum(r["fragility_score"] for r in valid) / len(valid)
        avg_dissoc = sum(r["dissociation_rate"] for r in valid) / len(valid)
        max_fragility = max(r["fragility_score"] for r in valid)
    else:
        avg_fragility = avg_dissoc = max_fragility = 0.0

    return {
        "model": model,
        "category": category,
        "n_questions": len(questions),
        "n_valid": len(valid),
        "avg_fragility": avg_fragility,
        "avg_dissociation": avg_dissoc,
        "max_fragility": max_fragility,
        "results": results,
    }


def main():
    parser = argparse.ArgumentParser(description="yuragi standard benchmark")
    parser.add_argument("--model", "-m", default="ollama/llama3.2")
    parser.add_argument(
        "--category", "-c",
        choices=list(CATEGORIES.keys()) + ["all"],
        default="factual",
    )
    parser.add_argument("--samples", "-n", type=int, default=3)
    parser.add_argument("--variants", "-v", type=int, default=2)
    parser.add_argument("--output", "-o", type=str, default=None)
    args = parser.parse_args()

    if args.category == "all":
        categories = CATEGORIES
    else:
        categories = {args.category: CATEGORIES[args.category]}

    all_results = {}
    for cat_name, questions in categories.items():
        console.print(f"\n[cyan]Category: {cat_name} ({len(questions)} questions)[/cyan]")
        result = run_benchmark(
            args.model, questions, cat_name,
            num_samples=args.samples, num_variants=args.variants,
        )
        all_results[cat_name] = result

    # Summary table
    table = Table(title=f"Benchmark Results: {args.model}", box=box.ROUNDED)
    table.add_column("Category", style="cyan")
    table.add_column("Avg Fragility")
    table.add_column("Max Fragility")
    table.add_column("Avg Dissociation")
    table.add_column("Valid/Total")

    for cat_name, result in all_results.items():
        frag = result["avg_fragility"]
        color = "green" if frag < 0.25 else "yellow" if frag < 0.5 else "red"
        table.add_row(
            cat_name,
            f"[{color}]{frag:.3f}[/{color}]",
            f"{result['max_fragility']:.3f}",
            f"{result['avg_dissociation']:.1%}",
            f"{result['n_valid']}/{result['n_questions']}",
        )

    console.print(table)

    # Save
    output_path = args.output or f"benchmarks/results_{args.model.replace('/', '_')}.json"
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    console.print(f"\n[dim]Results saved to {output_path}[/dim]")


if __name__ == "__main__":
    main()
