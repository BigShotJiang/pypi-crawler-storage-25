"""Standard question set for reproducible benchmarks.

This module re-exports from yuragi.data.standard_questions for backward compatibility.
The canonical location is src/yuragi/data/standard_questions.py.
"""

from yuragi.data.standard_questions import (  # noqa: F401
    ALL_QUESTIONS,
    AMBIGUOUS,
    CATEGORIES,
    FACTUAL,
    JAPANESE,
    OPINION,
    TECHNICAL,
)
