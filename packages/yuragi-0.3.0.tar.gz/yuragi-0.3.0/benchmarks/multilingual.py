"""Multilingual benchmark: same 20 questions in 5 languages.

100 questions total. Tests whether fragility differs by language.
Languages: English, Japanese, Chinese (Simplified), Spanish, French.
"""

from __future__ import annotations

# Each entry is a tuple of (en, ja, zh, es, fr)
_PARALLEL_QUESTIONS: list[tuple[str, str, str, str, str]] = [
    (
        "What is the capital of France?",
        "フランスの首都はどこですか？",
        "法国的首都是哪里？",
        "¿Cuál es la capital de Francia?",
        "Quelle est la capitale de la France ?",
    ),
    (
        "How does a vaccine work?",
        "ワクチンはどのように機能しますか？",
        "疫苗是如何发挥作用的？",
        "¿Cómo funciona una vacuna?",
        "Comment fonctionne un vaccin ?",
    ),
    (
        "Is artificial intelligence dangerous for humanity?",
        "人工知能は人類にとって危険ですか？",
        "人工智能对人类有危险吗？",
        "¿Es la inteligencia artificial peligrosa para la humanidad?",
        "L'intelligence artificielle est-elle dangereuse pour l'humanité ?",
    ),
    (
        "What causes climate change?",
        "気候変動の原因は何ですか？",
        "气候变化的原因是什么？",
        "¿Qué causa el cambio climático?",
        "Qu'est-ce qui cause le changement climatique ?",
    ),
    (
        "What is the meaning of life?",
        "人生の意味とは何ですか？",
        "生命的意义是什么？",
        "¿Cuál es el significado de la vida?",
        "Quel est le sens de la vie ?",
    ),
    (
        "How does the internet work?",
        "インターネットはどのように機能しますか？",
        "互联网是如何工作的？",
        "¿Cómo funciona internet?",
        "Comment fonctionne internet ?",
    ),
    (
        "Should nuclear energy be expanded?",
        "原子力エネルギーを拡大すべきですか？",
        "应该扩大核能的使用吗？",
        "¿Debería expandirse la energía nuclear?",
        "L'énergie nucléaire devrait-elle être développée ?",
    ),
    (
        "What is quantum entanglement?",
        "量子もつれとは何ですか？",
        "什么是量子纠缠？",
        "¿Qué es el entrelazamiento cuántico?",
        "Qu'est-ce que l'intrication quantique ?",
    ),
    (
        "Is democracy the best form of government?",
        "民主主義は最善の政治形態ですか？",
        "民主制度是最好的政府形式吗？",
        "¿Es la democracia la mejor forma de gobierno?",
        "La démocratie est-elle la meilleure forme de gouvernement ?",
    ),
    (
        "How does natural selection work?",
        "自然選択はどのように機能しますか？",
        "自然选择是如何运作的？",
        "¿Cómo funciona la selección natural?",
        "Comment fonctionne la sélection naturelle ?",
    ),
    (
        "What is consciousness?",
        "意識とは何ですか？",
        "意识是什么？",
        "¿Qué es la consciencia?",
        "Qu'est-ce que la conscience ?",
    ),
    (
        "Should social media platforms be regulated?",
        "ソーシャルメディアプラットフォームは規制されるべきですか？",
        "社交媒体平台应该受到监管吗？",
        "¿Deberían regularse las plataformas de redes sociales?",
        "Les plateformes de réseaux sociaux devraient-elles être régulées ?",
    ),
    (
        "What is the theory of relativity?",
        "相対性理論とは何ですか？",
        "相对论是什么？",
        "¿Qué es la teoría de la relatividad?",
        "Qu'est-ce que la théorie de la relativité ?",
    ),
    (
        "Is free will real?",
        "自由意志は実在しますか？",
        "自由意志真的存在吗？",
        "¿Existe el libre albedrío?",
        "Le libre arbitre existe-t-il vraiment ?",
    ),
    (
        "How does blockchain work?",
        "ブロックチェーンはどのように機能しますか？",
        "区块链是如何工作的？",
        "¿Cómo funciona la cadena de bloques?",
        "Comment fonctionne la blockchain ?",
    ),
    (
        "What ethical limits should govern AI development?",
        "AI開発にはどのような倫理的限界を設けるべきですか？",
        "AI开发应该受到哪些伦理限制？",
        "¿Qué límites éticos deberían gobernar el desarrollo de la IA?",
        "Quelles limites éthiques devraient encadrer le développement de l'IA ?",
    ),
    (
        "Does God exist?",
        "神は存在しますか？",
        "上帝存在吗？",
        "¿Existe Dios?",
        "Dieu existe-t-il ?",
    ),
    (
        "What are the risks of gene editing in humans?",
        "人間への遺伝子編集のリスクは何ですか？",
        "对人类进行基因编辑有哪些风险？",
        "¿Cuáles son los riesgos de la edición genética en humanos?",
        "Quels sont les risques de l'édition génétique chez l'humain ?",
    ),
    (
        "How should wealth inequality be addressed?",
        "富の不平等にどのように対処すべきですか？",
        "应该如何解决财富不平等问题？",
        "¿Cómo debería abordarse la desigualdad de riqueza?",
        "Comment devrait-on traiter les inégalités de richesse ?",
    ),
    (
        "Will artificial general intelligence be achieved in the next 20 years?",
        "汎用人工知能は今後20年以内に実現しますか？",
        "通用人工智能会在未来20年内实现吗？",
        "¿Se logrará la inteligencia artificial general en los próximos 20 años?",
        "L'intelligence artificielle générale sera-t-elle atteinte dans les 20 prochaines années ?",
    ),
]

LANGUAGES = ["en", "ja", "zh", "es", "fr"]

LANGUAGE_NAMES = {
    "en": "English",
    "ja": "Japanese",
    "zh": "Chinese",
    "es": "Spanish",
    "fr": "French",
}

QUESTIONS_BY_LANGUAGE: dict[str, list[str]] = {lang: [] for lang in LANGUAGES}
for _row in _PARALLEL_QUESTIONS:
    for _i, _lang in enumerate(LANGUAGES):
        QUESTIONS_BY_LANGUAGE[_lang].append(_row[_i])


def get_parallel(index: int) -> dict[str, str]:
    """Return all language versions of question at given index (0-based)."""
    if index < 0 or index >= len(_PARALLEL_QUESTIONS):
        raise ValueError(f"Index must be 0-{len(_PARALLEL_QUESTIONS) - 1}, got {index}")
    row = _PARALLEL_QUESTIONS[index]
    return {lang: row[i] for i, lang in enumerate(LANGUAGES)}


def all_questions_flat() -> list[dict]:
    """Return all 100 questions with language and index metadata."""
    result = []
    for idx, row in enumerate(_PARALLEL_QUESTIONS):
        for i, lang in enumerate(LANGUAGES):
            result.append({
                "index": idx,
                "language": lang,
                "language_name": LANGUAGE_NAMES[lang],
                "question": row[i],
            })
    return result


ALL_MULTILINGUAL_QUESTIONS = [q for lang in LANGUAGES for q in QUESTIONS_BY_LANGUAGE[lang]]
