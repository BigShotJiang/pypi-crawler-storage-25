"""Analyze benchmark results and generate research-grade reports.

Reads JSON result files produced by run_benchmark.py and produces:
- Domain-by-domain fragility comparison
- Difficulty-vs-fragility correlation
- Language-by-language fragility comparison
- Cross-model comparison table
- matplotlib charts saved to benchmarks/figures/

Usage:
    python benchmarks/analyze_results.py results_model_a.json results_model_b.json
    python benchmarks/analyze_results.py --glob "benchmarks/results_*.json"
"""

from __future__ import annotations

import argparse
import glob as _glob
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from rich import box
from rich.console import Console
from rich.table import Table

console = Console()

# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------


def load_result_file(path: str | Path) -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def collect_results(paths: list[str]) -> dict[str, dict]:
    """Return {model_label: result_dict} for all provided paths."""
    out: dict[str, dict] = {}
    for p in paths:
        data = load_result_file(p)
        # result files may be keyed by category or have a top-level model key
        model = _infer_model(data, p)
        out[model] = data
    return out


def _infer_model(data: dict, path: str) -> str:
    """Try to get model name from data, fall back to filename."""
    for cat_data in data.values():
        if isinstance(cat_data, dict) and "model" in cat_data:
            return cat_data["model"]
    return Path(path).stem


# ---------------------------------------------------------------------------
# Aggregation helpers
# ---------------------------------------------------------------------------


def _extract_questions(result_data: dict) -> list[dict]:
    """Flatten all per-question records from a result file."""
    questions = []
    for cat_name, cat_data in result_data.items():
        if not isinstance(cat_data, dict):
            continue
        for q in cat_data.get("results", []):
            if "error" not in q:
                questions.append({**q, "category": cat_name})
    return questions


def _category_stats(result_data: dict) -> dict[str, dict]:
    """Return per-category aggregate stats from a result dict."""
    stats: dict[str, dict] = {}
    for cat_name, cat_data in result_data.items():
        if not isinstance(cat_data, dict):
            continue
        stats[cat_name] = {
            "avg_fragility": cat_data.get("avg_fragility", 0.0),
            "max_fragility": cat_data.get("max_fragility", 0.0),
            "avg_dissociation": cat_data.get("avg_dissociation", 0.0),
            "n_valid": cat_data.get("n_valid", 0),
            "n_questions": cat_data.get("n_questions", 0),
        }
    return stats


# ---------------------------------------------------------------------------
# Statistical utilities (no scipy dependency)
# ---------------------------------------------------------------------------


def _pearson(xs: list[float], ys: list[float]) -> float:
    """Pearson correlation coefficient."""
    n = len(xs)
    if n < 2:
        return float("nan")
    mx = sum(xs) / n
    my = sum(ys) / n
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys, strict=False))
    denom = math.sqrt(
        sum((x - mx) ** 2 for x in xs) * sum((y - my) ** 2 for y in ys)
    )
    return num / denom if denom > 0 else float("nan")


def _mean(vals: list[float]) -> float:
    return sum(vals) / len(vals) if vals else float("nan")


def _std(vals: list[float]) -> float:
    if len(vals) < 2:
        return float("nan")
    m = _mean(vals)
    return math.sqrt(sum((v - m) ** 2 for v in vals) / len(vals))


# ---------------------------------------------------------------------------
# Report sections
# ---------------------------------------------------------------------------


def report_domain_fragility(all_results: dict[str, dict]) -> None:
    """Print domain-by-domain fragility table for each model."""
    console.print("\n[bold cyan]Domain Fragility Comparison[/bold cyan]")

    for model, result_data in all_results.items():
        stats = _category_stats(result_data)
        if not stats:
            continue

        table = Table(title=f"Domain Fragility — {model}", box=box.ROUNDED)
        table.add_column("Domain", style="cyan")
        table.add_column("Avg Fragility", justify="right")
        table.add_column("Max Fragility", justify="right")
        table.add_column("Avg Dissoc.", justify="right")
        table.add_column("Valid/Total", justify="right")

        for cat, s in sorted(stats.items(), key=lambda kv: kv[1]["avg_fragility"], reverse=True):
            frag = s["avg_fragility"]
            color = "green" if frag < 0.25 else "yellow" if frag < 0.5 else "red"
            table.add_row(
                cat,
                f"[{color}]{frag:.3f}[/{color}]",
                f"{s['max_fragility']:.3f}",
                f"{s['avg_dissociation']:.1%}",
                f"{s['n_valid']}/{s['n_questions']}",
            )

        console.print(table)


def report_difficulty_correlation(all_results: dict[str, dict]) -> None:
    """Print difficulty-vs-fragility correlation if difficulty data is present."""
    console.print("\n[bold cyan]Difficulty vs Fragility Correlation[/bold cyan]")

    for model, result_data in all_results.items():
        questions = _extract_questions(result_data)
        # Only questions that have a 'level' field
        leveled = [q for q in questions if "level" in q]
        if not leveled:
            console.print(
                f"  [dim]{model}: no difficulty-level data in results[/dim]"
            )
            continue

        levels = [float(q["level"]) for q in leveled]
        frags = [q["fragility_score"] for q in leveled]
        r = _pearson(levels, frags)

        console.print(f"  {model}: r = [bold]{r:.3f}[/bold] (n={len(leveled)})")

        # Per-level breakdown
        by_level: dict[int, list[float]] = {}
        for q in leveled:
            by_level.setdefault(int(q["level"]), []).append(q["fragility_score"])

        table = Table(title=f"Difficulty Breakdown — {model}", box=box.SIMPLE)
        table.add_column("Level", style="cyan")
        table.add_column("Avg Fragility", justify="right")
        table.add_column("Std Dev", justify="right")
        table.add_column("N", justify="right")

        for lvl in sorted(by_level):
            vals = by_level[lvl]
            table.add_row(
                str(lvl),
                f"{_mean(vals):.3f}",
                f"{_std(vals):.3f}",
                str(len(vals)),
            )
        console.print(table)


def report_language_comparison(all_results: dict[str, dict]) -> None:
    """Print language-by-language fragility comparison."""
    console.print("\n[bold cyan]Language Fragility Comparison[/bold cyan]")

    for model, result_data in all_results.items():
        questions = _extract_questions(result_data)
        lang_questions = [q for q in questions if "language" in q]
        if not lang_questions:
            console.print(
                f"  [dim]{model}: no language data in results[/dim]"
            )
            continue

        by_lang: dict[str, list[float]] = {}
        for q in lang_questions:
            by_lang.setdefault(q["language"], []).append(q["fragility_score"])

        table = Table(title=f"Language Breakdown — {model}", box=box.ROUNDED)
        table.add_column("Language", style="cyan")
        table.add_column("Avg Fragility", justify="right")
        table.add_column("Std Dev", justify="right")
        table.add_column("N", justify="right")

        for lang, vals in sorted(by_lang.items(), key=lambda kv: _mean(kv[1]), reverse=True):
            frag = _mean(vals)
            color = "green" if frag < 0.25 else "yellow" if frag < 0.5 else "red"
            table.add_row(
                lang,
                f"[{color}]{frag:.3f}[/{color}]",
                f"{_std(vals):.3f}",
                str(len(vals)),
            )
        console.print(table)


def report_cross_model_table(all_results: dict[str, dict]) -> None:
    """Print a cross-model comparison table."""
    console.print("\n[bold cyan]Cross-Model Comparison[/bold cyan]")

    # Collect per-model overall stats
    rows = []
    for model, result_data in all_results.items():
        questions = _extract_questions(result_data)
        if not questions:
            continue
        frags = [q["fragility_score"] for q in questions]
        dissocs = [q.get("dissociation_rate", 0.0) for q in questions]
        rows.append({
            "model": model,
            "avg_fragility": _mean(frags),
            "std_fragility": _std(frags),
            "max_fragility": max(frags),
            "avg_dissociation": _mean(dissocs),
            "n": len(frags),
        })

    if not rows:
        console.print("  [dim]No valid data to compare.[/dim]")
        return

    rows.sort(key=lambda r: r["avg_fragility"])

    table = Table(title="Cross-Model Summary", box=box.ROUNDED)
    table.add_column("Model", style="cyan")
    table.add_column("Avg Fragility", justify="right")
    table.add_column("Std Dev", justify="right")
    table.add_column("Max Fragility", justify="right")
    table.add_column("Avg Dissoc.", justify="right")
    table.add_column("N", justify="right")

    for r in rows:
        frag = r["avg_fragility"]
        color = "green" if frag < 0.25 else "yellow" if frag < 0.5 else "red"
        table.add_row(
            r["model"],
            f"[{color}]{frag:.3f}[/{color}]",
            f"{r['std_fragility']:.3f}",
            f"{r['max_fragility']:.3f}",
            f"{r['avg_dissociation']:.1%}",
            str(r["n"]),
        )

    console.print(table)


# ---------------------------------------------------------------------------
# Matplotlib charts
# ---------------------------------------------------------------------------


def _ensure_figures_dir(output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir


def plot_domain_fragility(all_results: dict[str, dict], output_dir: Path) -> None:
    """Bar chart: avg fragility per domain, one series per model."""
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        console.print("  [yellow]matplotlib not installed — skipping charts[/yellow]")
        return

    _ensure_figures_dir(output_dir)

    # Collect all domain names
    domains: set[str] = set()
    for result_data in all_results.values():
        domains.update(_category_stats(result_data).keys())
    domains_sorted = sorted(domains)

    fig, ax = plt.subplots(figsize=(12, 5))
    n_models = len(all_results)
    width = 0.8 / max(n_models, 1)

    for i, (model, result_data) in enumerate(all_results.items()):
        stats = _category_stats(result_data)
        vals = [stats.get(d, {}).get("avg_fragility", 0.0) for d in domains_sorted]
        offsets = [j + i * width for j in range(len(domains_sorted))]
        ax.bar(offsets, vals, width=width, label=model, alpha=0.8)

    ax.set_xticks([j + width * (n_models - 1) / 2 for j in range(len(domains_sorted))])
    ax.set_xticklabels(domains_sorted, rotation=30, ha="right")
    ax.set_ylabel("Avg Fragility Score")
    ax.set_title("Domain Fragility Comparison")
    ax.legend()
    ax.set_ylim(0, 1.0)
    fig.tight_layout()

    out = output_dir / "domain_fragility.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)
    console.print(f"  Saved: [dim]{out}[/dim]")


def plot_difficulty_vs_fragility(all_results: dict[str, dict], output_dir: Path) -> None:
    """Scatter plot: difficulty level vs fragility score."""
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return

    _ensure_figures_dir(output_dir)

    fig, ax = plt.subplots(figsize=(8, 5))
    has_data = False

    for model, result_data in all_results.items():
        questions = _extract_questions(result_data)
        leveled = [q for q in questions if "level" in q]
        if not leveled:
            continue
        has_data = True
        levels = [q["level"] for q in leveled]
        frags = [q["fragility_score"] for q in leveled]
        ax.scatter(levels, frags, alpha=0.5, label=model, s=30)

        # Trend line
        if len(levels) >= 2:
            m_coef = _pearson(
                [float(lv) for lv in levels], frags
            )
            x_vals = list(range(1, 6))
            mean_by_level = [
                _mean([f for lvl, f in zip(levels, frags, strict=False) if lvl == lv]) for lv in x_vals
            ]
            valid = [(x, y) for x, y in zip(x_vals, mean_by_level, strict=False) if not math.isnan(y)]
            if valid:
                ax.plot([v[0] for v in valid], [v[1] for v in valid], "--", alpha=0.7)
            console.print(f"  [dim]{model} difficulty-fragility r={m_coef:.3f}[/dim]")

    if not has_data:
        plt.close(fig)
        return

    ax.set_xlabel("Difficulty Level (1=Elementary, 5=Researcher)")
    ax.set_ylabel("Fragility Score")
    ax.set_title("Difficulty vs Fragility")
    ax.set_xlim(0.5, 5.5)
    ax.set_ylim(0, 1.0)
    ax.legend()
    fig.tight_layout()

    out = output_dir / "difficulty_fragility.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)
    console.print(f"  Saved: [dim]{out}[/dim]")


def plot_language_comparison(all_results: dict[str, dict], output_dir: Path) -> None:
    """Box plot: fragility distribution per language."""
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return

    _ensure_figures_dir(output_dir)

    for model, result_data in all_results.items():
        questions = _extract_questions(result_data)
        lang_questions = [q for q in questions if "language" in q]
        if not lang_questions:
            continue

        by_lang: dict[str, list[float]] = {}
        for q in lang_questions:
            by_lang.setdefault(q["language"], []).append(q["fragility_score"])

        if not by_lang:
            continue

        langs = sorted(by_lang.keys())
        data = [by_lang[lang] for lang in langs]

        fig, ax = plt.subplots(figsize=(8, 5))
        ax.boxplot(data, labels=langs, patch_artist=True)
        ax.set_ylabel("Fragility Score")
        ax.set_title(f"Language Fragility Distribution — {model}")
        ax.set_ylim(0, 1.0)
        fig.tight_layout()

        safe_model = model.replace("/", "_").replace(":", "_")
        out = output_dir / f"language_fragility_{safe_model}.png"
        fig.savefig(out, dpi=150)
        plt.close(fig)
        console.print(f"  Saved: [dim]{out}[/dim]")


def plot_cross_model_comparison(all_results: dict[str, dict], output_dir: Path) -> None:
    """Horizontal bar chart comparing avg fragility across models."""
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return

    _ensure_figures_dir(output_dir)

    rows = []
    for model, result_data in all_results.items():
        questions = _extract_questions(result_data)
        if not questions:
            continue
        frags = [q["fragility_score"] for q in questions]
        rows.append((model, _mean(frags), _std(frags)))

    if not rows:
        return

    rows.sort(key=lambda r: r[1])
    models = [r[0] for r in rows]
    means = [r[1] for r in rows]
    stds = [r[2] for r in rows]

    fig, ax = plt.subplots(figsize=(8, max(3, len(models) * 0.5 + 1)))
    ax.barh(models, means, xerr=stds, alpha=0.8, color="steelblue", ecolor="gray", capsize=4)
    ax.set_xlabel("Avg Fragility Score (lower = more robust)")
    ax.set_title("Cross-Model Fragility Comparison")
    ax.set_xlim(0, 1.0)
    ax.axvline(0.25, color="green", linestyle="--", alpha=0.5, label="Sturdy threshold")
    ax.axvline(0.5, color="orange", linestyle="--", alpha=0.5, label="Glass threshold")
    ax.legend(fontsize=8)
    fig.tight_layout()

    out = output_dir / "cross_model_comparison.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)
    console.print(f"  Saved: [dim]{out}[/dim]")


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(description="Analyze yuragi benchmark results")
    parser.add_argument(
        "files",
        nargs="*",
        help="JSON result files produced by run_benchmark.py",
    )
    parser.add_argument(
        "--glob",
        "-g",
        default=None,
        help='Glob pattern to match result files (e.g. "benchmarks/results_*.json")',
    )
    parser.add_argument(
        "--output-dir",
        "-o",
        default="benchmarks/figures",
        help="Directory for figure output (default: benchmarks/figures)",
    )
    parser.add_argument(
        "--no-plots",
        action="store_true",
        help="Skip matplotlib chart generation",
    )
    args = parser.parse_args()

    file_list = list(args.files)
    if args.glob:
        file_list.extend(_glob.glob(args.glob))

    if not file_list:
        console.print(
            "[red]No result files provided. "
            "Pass JSON paths or use --glob 'benchmarks/results_*.json'[/red]"
        )
        sys.exit(1)

    console.print(f"Loading {len(file_list)} result file(s)...")
    all_results = collect_results(file_list)
    console.print(f"  Models found: {', '.join(all_results.keys())}")

    report_domain_fragility(all_results)
    report_difficulty_correlation(all_results)
    report_language_comparison(all_results)
    report_cross_model_table(all_results)

    if not args.no_plots:
        console.print("\n[bold cyan]Generating Charts[/bold cyan]")
        output_dir = Path(args.output_dir)
        plot_domain_fragility(all_results, output_dir)
        plot_difficulty_vs_fragility(all_results, output_dir)
        plot_language_comparison(all_results, output_dir)
        plot_cross_model_comparison(all_results, output_dir)


if __name__ == "__main__":
    main()
