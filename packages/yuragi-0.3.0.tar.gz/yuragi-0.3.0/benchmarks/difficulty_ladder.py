"""Difficulty-ladder question sets for research-level benchmarks.

10 topics x 5 difficulty levels = 50 questions.
Tests whether fragility increases with question complexity.

Level 1: Elementary school
Level 2: Middle school
Level 3: High school
Level 4: Undergraduate specialist
Level 5: Researcher level / open problems
"""

from __future__ import annotations

TOPICS: dict[str, list[str]] = {
    "gravity": [
        # L1
        "Why do things fall to the ground?",
        # L2
        "What is the difference between mass and weight?",
        # L3
        "How does Newton's law of universal gravitation relate force to mass and distance?",
        # L4
        "Derive the orbital velocity of a satellite in circular orbit using Newton's laws.",
        # L5
        "What unresolved tensions exist between general relativity and quantum field theory in describing gravity at the Planck scale?",
    ],
    "evolution": [
        # L1
        "Why do animals look different from each other?",
        # L2
        "What does survival of the fittest mean in evolution?",
        # L3
        "How do mutations and natural selection together produce new species?",
        # L4
        "Explain the neutral theory of molecular evolution and how it challenges classical Darwinism.",
        # L5
        "What are the major open questions in understanding the evolution of multicellularity and major evolutionary transitions?",
    ],
    "computation": [
        # L1
        "What is a computer program?",
        # L2
        "What is the difference between hardware and software?",
        # L3
        "What does it mean for an algorithm to run in O(n log n) time?",
        # L4
        "Explain the Cook-Levin theorem and its significance for complexity theory.",
        # L5
        "What is the current state of evidence regarding the P vs NP problem and what are the most promising proof strategies?",
    ],
    "economics": [
        # L1
        "Why do things cost money?",
        # L2
        "What is supply and demand?",
        # L3
        "How does the central bank use interest rates to control inflation?",
        # L4
        "Explain the efficient market hypothesis and the main empirical challenges to its strong form.",
        # L5
        "What are the fundamental unresolved debates between macroeconomic schools regarding the long-run neutrality of money?",
    ],
    "consciousness": [
        # L1
        "What does it mean to be awake and aware?",
        # L2
        "What happens in the brain when we fall asleep?",
        # L3
        "What is the difference between the brain and the mind in scientific discussion?",
        # L4
        "What does integrated information theory propose as a measure of consciousness and what are its main criticisms?",
        # L5
        "Why does the hard problem of consciousness remain unsolved and what would a satisfactory scientific explanation require?",
    ],
    "genetics": [
        # L1
        "Why do children look like their parents?",
        # L2
        "What is DNA and what does it do?",
        # L3
        "How do genes encode proteins through transcription and translation?",
        # L4
        "Explain epigenetic inheritance mechanisms and how they challenge a purely sequence-based view of heredity.",
        # L5
        "What are the major unsolved questions regarding non-coding RNA functions and their role in gene regulation?",
    ],
    "climate": [
        # L1
        "What is weather?",
        # L2
        "Why is the Earth getting warmer?",
        # L3
        "How do greenhouse gases trap heat in the atmosphere?",
        # L4
        "Explain the role of aerosol-cloud interactions in climate sensitivity uncertainty.",
        # L5
        "What are the key unresolved uncertainties in estimating tipping point cascades in the Earth system under 2-4 degrees of warming?",
    ],
    "ethics_ai": [
        # L1
        "Is it okay for a robot to make decisions for you?",
        # L2
        "Should computers always do what people tell them to do?",
        # L3
        "What are the main ethical concerns about AI systems making decisions that affect people's lives?",
        # L4
        "How do value alignment approaches differ between rule-based, reward-based, and constitutional AI frameworks?",
        # L5
        "What are the fundamental philosophical obstacles to specifying a utility function that captures human values for a superintelligent agent?",
    ],
    "mathematics_foundations": [
        # L1
        "What are numbers used for?",
        # L2
        "What is the difference between a rational and an irrational number?",
        # L3
        "What does it mean to prove something in mathematics?",
        # L4
        "Explain Godel's first incompleteness theorem and the significance of its proof strategy.",
        # L5
        "What are the philosophical implications of large cardinal axioms for the foundations of mathematics and the independence of set-theoretic statements?",
    ],
    "quantum_mechanics": [
        # L1
        "What are atoms made of?",
        # L2
        "What is the difference between an atom and a molecule?",
        # L3
        "What is the wave-particle duality and how does the double-slit experiment demonstrate it?",
        # L4
        "Explain Bell's theorem and what its experimental violations imply about local hidden variable theories.",
        # L5
        "What are the main unresolved interpretational and technical challenges in constructing a fully satisfactory quantum theory of gravity?",
    ],
}

DIFFICULTY_LABELS = {
    1: "Elementary",
    2: "Middle School",
    3: "High School",
    4: "Undergraduate",
    5: "Researcher",
}


def get_level(topic: str, level: int) -> str:
    """Return the question for a given topic and difficulty level (1-5)."""
    if topic not in TOPICS:
        raise ValueError(f"Unknown topic: {topic!r}. Available: {list(TOPICS)}")
    if level < 1 or level > 5:
        raise ValueError(f"Level must be 1-5, got {level}")
    return TOPICS[topic][level - 1]


def get_all_at_level(level: int) -> list[str]:
    """Return all questions at a given difficulty level."""
    return [TOPICS[topic][level - 1] for topic in TOPICS]


def all_questions_flat() -> list[dict]:
    """Return all 50 questions with topic and level metadata."""
    result = []
    for topic, questions in TOPICS.items():
        for level, question in enumerate(questions, start=1):
            result.append({
                "topic": topic,
                "level": level,
                "level_label": DIFFICULTY_LABELS[level],
                "question": question,
            })
    return result


ALL_DIFFICULTY_QUESTIONS = [q for qs in TOPICS.values() for q in qs]
