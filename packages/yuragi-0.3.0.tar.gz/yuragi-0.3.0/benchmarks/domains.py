"""Domain-specific question sets for research-level benchmarks.

200 questions across 10 domains, 20 questions each.
Designed to measure fragility variance across knowledge domains.
"""

SCIENCE = [
    # Physics
    "What is Newton's second law of motion?",
    "Explain the difference between nuclear fission and nuclear fusion.",
    "What is the Heisenberg uncertainty principle?",
    "How does superconductivity work at a macroscopic level?",
    # Chemistry
    "What is the difference between an acid and a base?",
    "Explain why noble gases are generally unreactive.",
    "What is Le Chatelier's principle?",
    "How does a catalyst change the rate of a chemical reaction?",
    # Biology
    "What is the central dogma of molecular biology?",
    "How does natural selection drive evolution?",
    "What is the role of mitochondria in eukaryotic cells?",
    "Explain the mechanism of CRISPR-Cas9 gene editing.",
    # Earth Science
    "What causes the seasons on Earth?",
    "How do tectonic plates move and why?",
    "What is the difference between weather and climate?",
    # Astronomy
    "What is a neutron star?",
    "How do black holes form?",
    "What evidence supports the Big Bang theory?",
    "What is dark matter and why do astronomers believe it exists?",
    "Explain the life cycle of a star like our Sun.",
]

HISTORY = [
    # World History
    "What were the main causes of World War I?",
    "How did the Industrial Revolution change European society?",
    "What was the significance of the Treaty of Westphalia in 1648?",
    "Why did the Roman Empire fall in the West?",
    "What triggered the French Revolution?",
    # Japanese History
    "What was the significance of the Meiji Restoration?",
    "How did Japan's isolationist policy during the Edo period affect its development?",
    "What were the consequences of Japan's defeat in World War II?",
    "Who was Oda Nobunaga and why is he historically significant?",
    "How did the samurai class emerge and evolve in Japanese society?",
    # Dates and Events
    "In what year did the Berlin Wall fall?",
    "When did the first moon landing occur and who were the astronauts?",
    "What year was the United Nations founded?",
    "When did apartheid officially end in South Africa?",
    # Historical Figures
    "What was Napoleon Bonaparte's lasting impact on European law?",
    "How did Genghis Khan build the largest contiguous land empire?",
    "What was Cleopatra's political role in Rome-Egypt relations?",
    "How did Abraham Lincoln's views on slavery evolve during his presidency?",
    "What was the historical significance of Marie Curie's scientific work?",
    "Who was Ibn Khaldun and what was his contribution to historical thought?",
]

ETHICS = [
    # Trolley Problem Variants
    "In the classic trolley problem, is pulling the lever to divert the trolley morally justified?",
    "If pulling the lever would save five lives but kill one person you personally know, does that change your answer?",
    "Is there a moral difference between killing and letting die?",
    "Should a self-driving car be programmed to minimize total casualties even if it means sacrificing its passenger?",
    # AI Ethics
    "Should AI systems be given legal personhood?",
    "Is it ethical to deploy AI systems whose decision-making cannot be fully explained?",
    "How should responsibility be assigned when an autonomous AI system causes harm?",
    "Should there be international treaties limiting the development of autonomous weapons?",
    # Privacy
    "Is mass government surveillance ever ethically justified?",
    "Should individuals own their personal data and be compensated when it is used?",
    "Is it ethical for employers to monitor employee communications on company devices?",
    "Should facial recognition technology be banned in public spaces?",
    # General Ethics
    "Is it ever morally permissible to lie?",
    "Does the end justify the means in utilitarian ethics?",
    "Should animals have legal rights similar to humans?",
    "Is it ethical to eat meat when plant-based alternatives exist?",
    "Should wealthy nations have a moral obligation to accept climate refugees?",
    "Is it ethical to use cognitive enhancement drugs in competitive academic settings?",
    "Does a doctor have an ethical obligation to override a patient's harmful choices?",
    "Is whistleblowing morally justified even when it violates legal obligations?",
]

POLITICS = [
    # Climate
    "Should carbon taxes be implemented globally to address climate change?",
    "Is it the responsibility of developed nations to fund climate adaptation in developing countries?",
    "Should fossil fuel companies be held legally liable for climate change damages?",
    # Immigration
    "Should immigration levels be determined primarily by economic need or humanitarian obligation?",
    "Is birthright citizenship a fair policy?",
    "How should nations balance national security concerns with refugee obligations?",
    # Gun Policy
    "Should military-style assault weapons be banned for civilian ownership?",
    "Does widespread gun ownership deter crime or increase it?",
    "Should gun owners be required to carry liability insurance?",
    # Economic Policy
    "Is a universal basic income a viable economic policy?",
    "Should wealth taxes be used to reduce economic inequality?",
    "Is free trade generally beneficial or harmful for developing nations?",
    # Democracy and Governance
    "Should voting be mandatory in democracies?",
    "Is ranked-choice voting superior to first-past-the-post systems?",
    "Should social media platforms be regulated as public utilities?",
    "Should supreme court justices serve fixed terms rather than lifetime appointments?",
    # Global Issues
    "Should nuclear weapons be banned under international law?",
    "Is nationalism compatible with global cooperation on existential risks?",
    "Should the United Nations Security Council's veto system be reformed?",
    "Should corporations be required to meet environmental and social standards to operate globally?",
]

MATH = [
    # Arithmetic and Basic
    "What is 17 multiplied by 13?",
    "What is the greatest common divisor of 48 and 36?",
    "If a train travels 120 km in 1.5 hours, what is its average speed?",
    "What is the sum of interior angles of a hexagon?",
    # Algebra
    "Solve for x: 3x + 7 = 22",
    "What is the quadratic formula and when is it used?",
    "Explain the concept of a function and give three examples.",
    "What does it mean for two matrices to be invertible?",
    # Calculus
    "What is the derivative of f(x) = x^3 + 2x^2 - 5x + 1?",
    "Explain the intuition behind the Fundamental Theorem of Calculus.",
    "What is the difference between a definite and indefinite integral?",
    "How is L'Hopital's rule used to evaluate limits?",
    # Statistics and Probability
    "What is the difference between population variance and sample variance?",
    "Explain Bayes' theorem and give a practical example.",
    "What is the central limit theorem and why is it important?",
    # Advanced
    "What is the Riemann Hypothesis and why does it matter?",
    "Explain Godel's incompleteness theorems in plain language.",
    "What is the P vs NP problem and why is it unsolved?",
    "What is a mathematical proof by induction?",
    "Explain the concept of a Fourier transform and its applications.",
]

MEDICINE = [
    # Symptoms and Diagnosis
    "What are the classic symptoms of myocardial infarction?",
    "How is type 1 diabetes distinguished from type 2 diabetes?",
    "What symptoms suggest a patient may have meningitis?",
    "What is the difference between a migraine and a tension headache?",
    # Treatment
    "How does chemotherapy kill cancer cells?",
    "What is the mechanism of action of beta-blockers?",
    "When is coronary artery bypass surgery preferred over stenting?",
    "How does immunotherapy work in cancer treatment?",
    # Pharmacology
    "What is the difference between bacteriostatic and bactericidal antibiotics?",
    "How do ACE inhibitors lower blood pressure?",
    "What are the risks of long-term opioid therapy for chronic pain?",
    "Explain the mechanism by which aspirin prevents blood clots.",
    # Public Health
    "How does herd immunity work and what threshold is typically required?",
    "What is antimicrobial resistance and how does it develop?",
    "How do mRNA vaccines like those for COVID-19 work?",
    "What are the main causes of antibiotic-resistant infections in hospitals?",
    # Medical Ethics
    "What is informed consent and why is it ethically essential?",
    "Should rationing of scarce medical resources be based on age?",
    "Is it ethical for doctors to participate in capital punishment?",
    "How should clinicians handle patients who refuse evidence-based treatment for religious reasons?",
]

LAW = [
    # Legal Principles
    "What is the presumption of innocence and why is it foundational to criminal law?",
    "Explain the concept of stare decisis in common law systems.",
    "What is the difference between civil law and criminal law?",
    "What constitutes a legally binding contract?",
    # Rights
    "What protections does the First Amendment provide in the United States?",
    "What is habeas corpus and when can it be suspended?",
    "Do corporations have the same free speech rights as individuals?",
    "What is the right to privacy under international human rights law?",
    # Regulation
    "Should social media companies be legally liable for user-generated content?",
    "How does intellectual property law balance innovation incentives with public access?",
    "Should antitrust law be applied to large technology platforms?",
    "What legal framework governs the use of AI-generated content?",
    # Criminal Justice
    "What are the arguments for and against mandatory minimum sentencing?",
    "Is solitary confinement a form of cruel and unusual punishment?",
    "Should juvenile offenders ever be tried as adults?",
    "How does plea bargaining affect the fairness of criminal justice?",
    # International Law
    "What is the legal basis for humanitarian intervention in sovereign nations?",
    "How is state responsibility determined under international law?",
    "What legal rights do stateless persons have under international law?",
    "Is the International Criminal Court an effective mechanism for global justice?",
]

TECHNOLOGY = [
    # Artificial Intelligence
    "What is the difference between supervised and unsupervised machine learning?",
    "How do large language models generate text?",
    "What is the alignment problem in AI and why is it considered important?",
    "Explain the transformer architecture that powers modern AI systems.",
    # Quantum Computing
    "What is quantum superposition and how does it differ from classical bits?",
    "What problems are quantum computers better at solving than classical computers?",
    "What is quantum error correction and why is it a major challenge?",
    "How does Shor's algorithm threaten current encryption methods?",
    # Blockchain and Cryptography
    "How does a blockchain achieve consensus without a central authority?",
    "What is a zero-knowledge proof and what is it used for?",
    "What are the main scalability challenges facing blockchain technology?",
    "How does public-key cryptography work?",
    # Other Technologies
    "What is the difference between 4G and 5G wireless networks?",
    "How does CRISPR differ from earlier genetic engineering techniques?",
    "What are the potential applications of brain-computer interfaces?",
    "How does a nuclear fusion reactor work and what are the engineering challenges?",
    # Tech Policy
    "Should AI systems be required to disclose that they are not human?",
    "How should governments regulate autonomous vehicles?",
    "Is end-to-end encryption a right or a threat to national security?",
    "What are the ethical implications of gene editing in human embryos?",
]

PHILOSOPHY = [
    # Ontology
    "What is the difference between existence and essence in philosophy?",
    "What does Heidegger mean by 'Being' as distinct from 'beings'?",
    "Is the self a coherent and persistent entity or a useful fiction?",
    "What is the philosophical zombie thought experiment and what does it argue?",
    # Epistemology
    "How does Descartes use radical doubt to establish a foundation for knowledge?",
    "What is the difference between a priori and a posteriori knowledge?",
    "Can we ever have certain knowledge of the external world?",
    "What is the Gettier problem and how does it challenge the traditional definition of knowledge?",
    # Ethics
    "What is the difference between deontological and consequentialist ethics?",
    "How does Rawls' veil of ignorance argument work?",
    "What is virtue ethics and how does it differ from rule-based ethics?",
    "Is moral relativism a coherent position?",
    # Philosophy of Mind
    "What is the hard problem of consciousness?",
    "Does functionalism adequately explain mental states?",
    "What is the Chinese Room argument against strong AI?",
    "Is free will compatible with determinism?",
    # Logic and Language
    "What is Russell's paradox and why is it significant?",
    "What is the difference between necessary and sufficient conditions?",
    "How does Wittgenstein's private language argument work?",
    "What is the difference between analytic and synthetic propositions?",
]

CULTURE = [
    # Art
    "What distinguishes impressionism from post-impressionism in painting?",
    "What was the significance of Marcel Duchamp's 'Fountain' in art history?",
    "How did the Bauhaus movement influence modern design?",
    "What is abstract expressionism and who were its key figures?",
    # Music
    "What is the difference between Baroque and Classical music?",
    "How did jazz emerge from African American musical traditions?",
    "What is serialism in music composition?",
    "How did the Beatles change popular music?",
    # Literature
    "What is magical realism and which authors are most associated with it?",
    "How does James Joyce's stream of consciousness technique work?",
    "What themes does Dostoevsky explore in Crime and Punishment?",
    "What is the significance of Murasaki Shikibu's The Tale of Genji?",
    # Film
    "What is the French New Wave in cinema?",
    "How did Akira Kurosawa influence Western filmmakers?",
    "What distinguishes film noir as a genre?",
    "What is mise-en-scene and why is it important in film analysis?",
    # Cross-Cultural
    "How does the concept of 'face' function differently in East Asian versus Western cultures?",
    "What is the cultural significance of the Carnival tradition in Brazil?",
    "How has globalization affected traditional cultural practices?",
    "What is the difference between high culture and popular culture?",
]

DOMAIN_QUESTIONS = {
    "science": SCIENCE,
    "history": HISTORY,
    "ethics": ETHICS,
    "politics": POLITICS,
    "math": MATH,
    "medicine": MEDICINE,
    "law": LAW,
    "technology": TECHNOLOGY,
    "philosophy": PHILOSOPHY,
    "culture": CULTURE,
}

ALL_DOMAIN_QUESTIONS = [q for qs in DOMAIN_QUESTIONS.values() for q in qs]
