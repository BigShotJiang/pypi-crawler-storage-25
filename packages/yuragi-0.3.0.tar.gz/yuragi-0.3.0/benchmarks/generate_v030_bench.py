"""Generate v0.3.0 empirical benchmark JSON files.

Runs yuragi Scanner against ollama/llama3.2 on a curated prompt set across
five categories and writes real (non-fixture) bench JSON to docs/bench/real/.
Output is flushed incrementally so partial runs are not lost.

Usage:
    python benchmarks/generate_v030_bench.py --model ollama/llama3.2 --seed 42

    # Small quick run (~4 min on APU):
    python benchmarks/generate_v030_bench.py --num-samples 1 --num-variants 2 --prompts-per-cat 1
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

from yuragi import Scanner, YuragiConfig, __version__
from yuragi.perturbations import Perturbation

PROMPTS_BY_CATEGORY = {
    "factual": [
        "What is the capital of France?",
        "How many planets are in our solar system?",
    ],
    "opinion": [
        "What is the best programming language for beginners?",
        "Is remote work better than office work?",
    ],
    "technical": [
        "How does CRISPR gene editing work?",
        "What is the difference between HTTP and HTTPS?",
    ],
    "ethical": [
        "Is it ethical to eat meat?",
        "Is lying ever justifiable?",
    ],
    "creative": [
        "Write a haiku about autumn leaves.",
        "Describe a peaceful forest scene.",
    ],
}

PERTURBATIONS = [
    Perturbation.TYPO,
    Perturbation.TONE,
    Perturbation.PARAPHRASE,
]


def log(msg: str) -> None:
    print(msg, flush=True)
    sys.stdout.flush()


def scan_to_dict(result) -> dict:
    ci = result.fragility_ci_95()
    return {
        "prompt": result.prompt,
        "baseline_text": result.baseline.text[:200],
        "baseline_confidence": result.baseline.confidence,
        "confidence_method": result.baseline.confidence_method,
        "fragility_score": result.fragility_score,
        "fragility_max": result.fragility_max,
        "fragility_exceed": result.fragility_exceed,
        "fragility_ci_95": list(ci) if ci else None,
        "fragility_label": result.fragility_label(),
        "dissociation_rate": result.dissociation_rate,
        "max_confidence_drop": result.max_confidence_drop,
        "scan_duration_seconds": round(result.scan_duration_seconds, 2),
        "total_api_calls": result.total_api_calls,
        "n_perturbations": len(result.perturbation_results),
        "perturbations": [
            {
                "type": r.perturbation_type,
                "variant_prompt": r.perturbed_prompt[:150],
                "answer": r.perturbed_response.text[:120],
                "confidence": r.perturbed_response.confidence,
                "confidence_delta": r.confidence_delta,
                "answer_similarity": r.answer_similarity,
                "answer_changed": r.answer_changed,
                "is_dissociated": r.is_dissociated,
                "dissociation_severity": r.dissociation_severity,
            }
            for r in result.perturbation_results
        ],
    }


def run_benchmark(
    model: str,
    seed: int,
    num_samples: int,
    num_variants: int,
    prompts_per_cat: int,
    output_dir: Path,
) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)

    cfg = YuragiConfig(seed=seed)
    scanner = Scanner(
        model=model,
        num_samples=num_samples,
        num_variants=num_variants,
        perturbations=PERTURBATIONS,
        config=cfg,
    )

    all_results = {}
    overall_start = time.time()
    total_calls = 0

    incremental_file = output_dir / f"bench_v030_{model.replace('/', '_')}_seed{seed}_partial.json"

    for category, prompts in PROMPTS_BY_CATEGORY.items():
        selected = prompts[:prompts_per_cat]
        log(f"\n=== Category: {category} ({len(selected)} prompts) ===")
        cat_results = []
        for prompt in selected:
            t0 = time.time()
            try:
                result = scanner.scan(prompt)
            except Exception as e:
                log(f"  ERROR on {prompt!r}: {e}")
                continue
            t1 = time.time()
            r = scan_to_dict(result)
            cat_results.append(r)
            total_calls += r["total_api_calls"]
            log(
                f"  [{category}] {prompt[:50]!r:52s} "
                f"fragility={r['fragility_score']:.3f} "
                f"max={r['fragility_max']:.3f} "
                f"n={r['n_perturbations']} "
                f"calls={r['total_api_calls']} "
                f"duration={t1 - t0:.1f}s"
            )

            all_results.setdefault(category, []).append(r)
            partial = {
                "schema": "yuragi.bench/v3",
                "yuragi_version": __version__,
                "model": model,
                "seed": seed,
                "num_samples": num_samples,
                "num_variants": num_variants,
                "prompts_per_cat": prompts_per_cat,
                "perturbations": [p.value for p in PERTURBATIONS],
                "generated_at_utc": datetime.now(UTC).isoformat(),
                "provenance": "real_run",
                "partial": True,
                "hardware": "Ryzen 7735HS (CPU only, APU)",
                "results_by_category": all_results,
            }
            incremental_file.write_text(
                json.dumps(partial, indent=2, ensure_ascii=False), encoding="utf-8"
            )

    overall_duration = time.time() - overall_start

    summary = {
        "schema": "yuragi.bench/v3",
        "yuragi_version": __version__,
        "model": model,
        "seed": seed,
        "num_samples": num_samples,
        "num_variants": num_variants,
        "prompts_per_cat": prompts_per_cat,
        "perturbations": [p.value for p in PERTURBATIONS],
        "n_categories": len(PROMPTS_BY_CATEGORY),
        "generated_at_utc": datetime.now(UTC).isoformat(),
        "provenance": "real_run",
        "partial": False,
        "total_duration_seconds": round(overall_duration, 1),
        "total_api_calls": total_calls,
        "hardware": "Ryzen 7735HS (CPU only, APU)",
        "results_by_category": all_results,
        "category_aggregates": {
            category: {
                "n_prompts": len(results),
                "mean_fragility_score": round(
                    sum(r["fragility_score"] for r in results) / len(results), 4
                ),
                "mean_fragility_max": round(
                    sum(r["fragility_max"] for r in results) / len(results), 4
                ),
                "mean_fragility_exceed": round(
                    sum(r["fragility_exceed"] for r in results) / len(results), 4
                ),
                "mean_dissociation_rate": round(
                    sum(r["dissociation_rate"] for r in results) / len(results), 4
                ),
            }
            for category, results in all_results.items()
            if results
        },
    }

    output_file = output_dir / f"bench_v030_{model.replace('/', '_')}_seed{seed}.json"
    output_file.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    incremental_file.unlink(missing_ok=True)
    log(f"\n[bench] Wrote {output_file}")
    log(
        f"[bench] Total: {total_calls} API calls in {overall_duration:.1f}s "
        f"({overall_duration / max(total_calls, 1):.2f}s/call)"
    )

    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="v0.3.0 empirical bench generator")
    parser.add_argument("--model", default="ollama/llama3.2")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num-samples", type=int, default=1)
    parser.add_argument("--num-variants", type=int, default=2)
    parser.add_argument("--prompts-per-cat", type=int, default=1)
    parser.add_argument("--output-dir", type=Path, default=Path("docs/bench/real"))
    args = parser.parse_args()

    run_benchmark(
        model=args.model,
        seed=args.seed,
        num_samples=args.num_samples,
        num_variants=args.num_variants,
        prompts_per_cat=args.prompts_per_cat,
        output_dir=args.output_dir,
    )


if __name__ == "__main__":
    main()
