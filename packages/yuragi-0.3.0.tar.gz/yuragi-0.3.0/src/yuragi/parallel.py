"""Async parallel LLM call utilities.

Dispatches to LLMAdapter.acomplete(), which handles retry, cache, and
confidence measurement.  This module is intentionally thin.

Default concurrency: 3 (configurable via semaphore).
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable

from yuragi.exceptions import MissingDependencyError
from yuragi.providers.adapter import CompletionResult, LLMAdapter
from yuragi.providers.adapter import _get_litellm as _adapter_get_litellm
from yuragi.providers.adapter import _has_litellm as _adapter_has_litellm


def __getattr__(name: str):  # PEP 562
    """Expose ``HAS_LITELLM`` and ``litellm`` as lazy module attributes.

    ``monkeypatch.setattr(par_mod, "HAS_LITELLM", True)`` and
    ``patch("yuragi.parallel.litellm.acompletion", ...)`` both work because a
    ``monkeypatch.setattr`` (or ``mock.patch``) sets a real attribute in the
    module ``__dict__`` which shadows this hook per PEP 562 semantics. Tests
    can therefore keep using the old module-attribute pattern unchanged.
    """
    if name == "HAS_LITELLM":
        return _adapter_has_litellm()
    if name == "litellm":
        return _adapter_get_litellm()
    raise AttributeError(f"module 'yuragi.parallel' has no attribute {name!r}")


async def parallel_complete(
    adapter: LLMAdapter,
    prompts: list[str],
    system: str | None = None,
    concurrency: int = 3,
    on_done: Callable[[int, CompletionResult], None] | None = None,
) -> list[CompletionResult]:
    """Complete multiple prompts in parallel via adapter.acomplete().

    Args:
        adapter: LLMAdapter instance.
        prompts: List of prompts to complete.
        system: Optional system prompt.
        concurrency: Max simultaneous requests.
        on_done: Optional callback(index, result) called as each completes.

    Returns:
        List of CompletionResult in the same order as prompts.
        On failure, the slot contains a sentinel CompletionResult with
        confidence=0.0 and confidence_method="error" instead of None.
    """
    # ``HAS_LITELLM`` resolves via ``__getattr__`` (or a monkey-patched
    # module attribute in tests).
    if not globals().get("HAS_LITELLM", _adapter_has_litellm()):
        raise MissingDependencyError("litellm is required. Install with: pip install yuragi")

    sem = asyncio.Semaphore(concurrency)
    # Use a comprehension so each slot holds its own CompletionResult
    # instance. ``[x] * n`` would create n references to the same object —
    # currently safe because CompletionResult is frozen, but the
    # comprehension form keeps the code robust against future mutations.
    results: list[CompletionResult] = [
        CompletionResult(text="", confidence=0.0, confidence_method="error")
        for _ in range(len(prompts))
    ]

    async def _run(i: int, prompt: str) -> None:
        async with sem:
            try:
                result = await adapter.acomplete(prompt, system=system)
            except Exception as exc:
                result = CompletionResult(
                    text="",
                    confidence=0.0,
                    confidence_method="error",
                    logprob_entropy=None,
                    raw_logprobs=None,
                    token_count=0,
                )
                import logging
                logging.getLogger(__name__).warning(
                    "parallel_complete slot %d failed: %s", i, exc
                )
        results[i] = result
        if on_done:
            on_done(i, result)

    await asyncio.gather(*(_run(i, p) for i, p in enumerate(prompts)))
    return results


def run_parallel_complete(
    adapter: LLMAdapter,
    prompts: list[str],
    system: str | None = None,
    concurrency: int = 3,
    on_done: Callable[[int, CompletionResult], None] | None = None,
) -> list[CompletionResult]:
    """Sync wrapper around parallel_complete."""
    return asyncio.run(
        parallel_complete(adapter, prompts, system=system, concurrency=concurrency, on_done=on_done)
    )
