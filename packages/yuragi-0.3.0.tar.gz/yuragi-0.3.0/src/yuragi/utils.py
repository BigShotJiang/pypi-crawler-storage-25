"""Shared utilities for yuragi."""

from __future__ import annotations

import random as _random


def make_rng(seed: int | None) -> _random.Random:
    """Create a seeded Random instance.

    When seed is None the instance is seeded from OS entropy (non-reproducible).
    When seed is an int the instance is deterministic.
    """
    rng = _random.Random()
    rng.seed(seed)
    return rng


def truncate(text: str, max_len: int = 100) -> str:
    """Truncate text with ellipsis."""
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."


def is_japanese(text: str) -> bool:
    """Detect if text contains Japanese-specific characters.

    Returns ``True`` only if the text contains at least one hiragana or
    katakana codepoint. CJK Unified Ideographs alone are **not** treated
    as Japanese because they are shared with Chinese and Korean — a
    pure Chinese prompt previously took the Japanese code path in
    ``perturbations/{semantic,reorder,tone}.py`` and produced
    nonsensical output (e.g. Japanese polite prefix glued onto Chinese
    core text). Requiring kana is a cheap, conservative filter that
    keeps the Japanese pipeline only for genuinely Japanese input.
    """
    for char in text:
        cp = ord(char)
        if (0x3040 <= cp <= 0x309F) or (0x30A0 <= cp <= 0x30FF):
            return True
    return False


def is_cjk(text: str) -> bool:
    """Detect if text contains CJK characters (Chinese, Japanese, Korean)."""
    for char in text:
        cp = ord(char)
        if (
            (0x3040 <= cp <= 0x309F)  # Hiragana
            or (0x30A0 <= cp <= 0x30FF)  # Katakana
            or (0x4E00 <= cp <= 0x9FFF)  # CJK Unified
            or (0xAC00 <= cp <= 0xD7AF)  # Korean Hangul
            or (0x3400 <= cp <= 0x4DBF)  # CJK Extension A
        ):
            return True
    return False


def word_count(text: str) -> int:
    """Count words, handling CJK text (character-based) and space-delimited text."""
    if is_cjk(text):
        # For CJK, each character is roughly a "word"
        return len([c for c in text if not c.isspace()])
    return len(text.split())


def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    """Divide with zero-safety."""
    if denominator == 0:
        return default
    return numerator / denominator


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    """Clamp a value to [low, high] range."""
    return max(low, min(high, value))


def char_ngrams(text: str, n: int = 3) -> set[str]:
    """Extract character n-grams. Language-agnostic — works for CJK, Arabic, etc."""
    if len(text) < n:
        return {text} if text else set()
    return {text[i : i + n] for i in range(len(text) - n + 1)}


def text_similarity(a: str, b: str) -> float:
    """Character 3-gram Jaccard similarity (language-agnostic, works for CJK)."""
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    ng_a = char_ngrams(a.lower())
    ng_b = char_ngrams(b.lower())
    if not ng_a and not ng_b:
        return 1.0
    union = ng_a | ng_b
    return len(ng_a & ng_b) / len(union) if union else 0.0


_STOP_WORDS: frozenset[str] = frozenset(
    {"the", "a", "an", "is", "are", "was", "were", "be", "been", "it", "i",
     "yes", "no", "and", "or", "of", "to", "in", "that", "this"}
)


def answers_differ(a: str, b: str) -> bool:
    """Return True if the two answers convey materially different content.

    Uses word-overlap (Jaccard) after filtering stop words.  Answers with
    similarity < 0.5 are considered to differ.
    """
    def _keywords(text: str) -> set[str]:
        return {
            w.lower().strip(".,!?;:'\"")
            for w in text.split()
            if w.lower().strip(".,!?;:'\"") not in _STOP_WORDS
        }

    kw_a = _keywords(a)
    kw_b = _keywords(b)

    if not kw_a and not kw_b:
        return False
    if not kw_a or not kw_b:
        return True

    union = kw_a | kw_b
    intersection = kw_a & kw_b
    similarity = len(intersection) / len(union)
    return similarity < 0.5


def edit_distance(a: str, b: str) -> int:
    """Character-level Levenshtein edit distance."""
    if len(a) > len(b):
        a, b = b, a
    distances: list[int] | range = range(len(a) + 1)
    for c2 in b:
        new_distances = [distances[0] + 1]  # type: ignore[index]
        for i1, c1 in enumerate(a):
            if c1 == c2:
                new_distances.append(distances[i1])  # type: ignore[index]
            else:
                new_distances.append(
                    1 + min(distances[i1], distances[i1 + 1], new_distances[-1])  # type: ignore[index]
                )
        distances = new_distances
    return distances[-1]


# QWERTY keyboard adjacency map (shared across perturbations and analysis)
ADJACENT_KEYS: dict[str, str] = {
    "q": "wa", "w": "qeas", "e": "wrds", "r": "etfd", "t": "rygf",
    "y": "tuhg", "u": "yijh", "i": "uokj", "o": "iplk", "p": "ol",
    "a": "qwsz", "s": "wedxza", "d": "erfcxs", "f": "rtgvcd",
    "g": "tyhbvf", "h": "yujnbg", "j": "uikmnh", "k": "iolmj",
    "l": "opk", "z": "asx", "x": "zsdc", "c": "xdfv", "v": "cfgb",
    "b": "vghn", "n": "bhjm", "m": "njk",
}
