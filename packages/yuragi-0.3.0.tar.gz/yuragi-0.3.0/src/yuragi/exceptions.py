"""Custom exception hierarchy for yuragi."""

from __future__ import annotations


class YuragiError(Exception):
    """Base exception for all yuragi errors."""


class ModelNotFoundError(YuragiError):
    """Raised when the specified model is not available."""


class APIKeyMissingError(YuragiError):
    """Raised when required API key is not set."""


class ScanError(YuragiError):
    """Raised when a scan fails."""


class CacheError(YuragiError):
    """Raised when cache operations fail."""


class ExperimentError(YuragiError):
    """Raised when an experiment fails."""


class ConfigurationError(YuragiError):
    """Raised when configuration is invalid (e.g. unknown category, bad parameter)."""


class MissingDependencyError(YuragiError):
    """Raised when an optional dependency is not installed."""
