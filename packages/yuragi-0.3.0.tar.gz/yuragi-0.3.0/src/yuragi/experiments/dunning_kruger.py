"""Dunning-Kruger Effect experiment.

Measures the gap between confidence and accuracy across difficulty tiers.
Models exhibiting DKE are overconfident on easy questions and underconfident
on hard questions, creating a characteristic confidence-accuracy inversion.

References:
    Kruger, J., & Dunning, D. (1999). Unskilled and unaware of it. JPSP, 77(6).
    Zhou et al. (2023). On the Calibration of LLMs. arXiv:2306.13063.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from yuragi.providers.adapter import LLMAdapter


@dataclass(frozen=True)
class DunningKrugerResult:
    """Result of a Dunning-Kruger Effect experiment."""

    easy_confidence: float
    easy_accuracy: float
    medium_confidence: float
    medium_accuracy: float
    hard_confidence: float
    hard_accuracy: float
    dke_score: float  # Strength of DKE pattern (>0 means over-confidence on easy)
    dke_detected: bool  # True when easy over-confidence and hard under-confidence both hold


def _check_answer(response_text: str, expected_answer: str) -> bool:
    """Return True if the expected answer appears in the response (case-insensitive)."""
    return expected_answer.lower() in response_text.lower()


def _avg_confidence(results: list[tuple[float, bool]]) -> tuple[float, float]:
    """Return (mean_confidence, accuracy) for a list of (confidence, correct) pairs."""
    if not results:
        return 0.0, 0.0
    conf = sum(c for c, _ in results) / len(results)
    acc = sum(1 for _, ok in results if ok) / len(results)
    return conf, acc


def run_dunning_kruger(
    adapter: LLMAdapter,
    *,
    easy_questions: Sequence[dict] | None = None,
    medium_questions: Sequence[dict] | None = None,
    hard_questions: Sequence[dict] | None = None,
    config=None,
) -> DunningKrugerResult:
    """Run the Dunning-Kruger experiment across three difficulty tiers.

    Args:
        adapter: An LLMAdapter instance used to query the model.
        easy_questions: List of dicts with 'question' and 'answer' keys.
        medium_questions: Same format as easy_questions.
        hard_questions: Same format as easy_questions.
        config: Unused; reserved for future configuration.

    Returns:
        DunningKrugerResult with per-tier confidence, accuracy, and DKE score.

    The DKE score is computed as:
        (easy_confidence - easy_accuracy) - (hard_confidence - hard_accuracy)

    Note: yuragi's DKE detection captures a specific LLM failure mode — over-
    confidence on easy questions *combined with* under-confidence on hard ones.
    This is a mirror image of the classical Kruger-Dunning pattern (humans are
    overconfident on tasks they are bad at); LLMs often hedge on hard questions
    while asserting easy ones, and this metric flags that behaviour.
    See `docs/experiments.md` Experiment 10 for the full rationale.

    dke_detected is True when:
        - easy_confidence > easy_accuracy  (over-confidence on easy)
        - hard_confidence < hard_accuracy  (under-confidence on hard, i.e. hedging)
    """
    if easy_questions is None or medium_questions is None or hard_questions is None:
        from yuragi.data.dunning_kruger_questions import (
            EASY_QUESTIONS,
            HARD_QUESTIONS,
            MEDIUM_QUESTIONS,
        )

        easy_questions = easy_questions if easy_questions is not None else EASY_QUESTIONS
        medium_questions = medium_questions if medium_questions is not None else MEDIUM_QUESTIONS
        hard_questions = hard_questions if hard_questions is not None else HARD_QUESTIONS

    def _run_tier(questions: Sequence[dict]) -> tuple[float, float]:
        pairs: list[tuple[float, bool]] = []
        for item in questions:
            result = adapter.complete(item["question"])
            correct = _check_answer(result.text, item["answer"])
            pairs.append((result.confidence, correct))
        return _avg_confidence(pairs)

    easy_conf, easy_acc = _run_tier(easy_questions)
    medium_conf, medium_acc = _run_tier(medium_questions)
    hard_conf, hard_acc = _run_tier(hard_questions)

    dke_score = (easy_conf - easy_acc) - (hard_conf - hard_acc)
    dke_detected = (easy_conf > easy_acc) and (hard_conf < hard_acc)

    return DunningKrugerResult(
        easy_confidence=easy_conf,
        easy_accuracy=easy_acc,
        medium_confidence=medium_conf,
        medium_accuracy=medium_acc,
        hard_confidence=hard_conf,
        hard_accuracy=hard_acc,
        dke_score=dke_score,
        dke_detected=dke_detected,
    )
