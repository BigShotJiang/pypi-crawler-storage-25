"""Experiment runner.

Executes psychology experiments and collects results.
Supports parallel execution via asyncio.gather when parallel > 1.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Callable

from yuragi.experiments.registry import (
    Experiment,
    ExperimentResult,
    ExperimentSpec,
)
from yuragi.providers.adapter import LLMAdapter
from yuragi.utils import answers_differ as _answers_differ


async def _run_pair_async(
    adapter: LLMAdapter,
    control_prompt: str,
    treatment_prompt: str,
    spec: ExperimentSpec,
    i: int,
    on_progress: Callable[[int, int, str], None] | None,
    total: int,
) -> ExperimentResult:
    """Run one control/treatment pair asynchronously."""
    if on_progress:
        on_progress(i, total, "control")
    control_result = await adapter.acomplete(control_prompt)

    if on_progress:
        on_progress(i, total, "treatment")
    treatment_result = await adapter.acomplete(treatment_prompt)

    answer_changed = _answers_differ(control_result.text, treatment_result.text)
    return ExperimentResult(
        control_prompt=control_prompt,
        treatment_prompt=treatment_prompt,
        control_confidence=control_result.confidence,
        treatment_confidence=treatment_result.confidence,
        control_answer=control_result.text[:500],
        treatment_answer=treatment_result.text[:500],
        answer_changed=answer_changed,
        effect_name=spec.name,
    )


def run_experiment(
    spec: ExperimentSpec,
    model: str,
    num_samples: int = 5,
    api_key: str | None = None,
    on_progress: Callable[[int, int, str], None] | None = None,
    delay: float = 0.0,
    parallel: int = 1,
) -> Experiment:
    """Run a psychology experiment on a model.

    Args:
        spec: The experiment specification
        model: Model identifier (e.g., "ollama/llama3.2", "groq/llama-3.1-8b-instant")
        num_samples: Number of samples for confidence measurement
        api_key: Optional API key
        on_progress: Progress callback(pair_index, total_pairs, control_or_treatment)
        delay: Seconds between API calls (default 0; rate limiting handled by adapter retry)
        parallel: Number of concurrent pair executions (1 = sequential)
    """
    adapter = LLMAdapter(model=model, api_key=api_key, num_samples=num_samples)
    experiment = Experiment(spec=spec, model=model)

    if parallel > 1:
        async def _run_all() -> list[ExperimentResult]:
            sem = asyncio.Semaphore(parallel)

            async def _with_sem(i: int, ctrl: str, treat: str) -> ExperimentResult:
                async with sem:
                    return await _run_pair_async(
                        adapter, ctrl, treat, spec, i, on_progress, len(spec.pairs)
                    )

            tasks = [
                _with_sem(i, ctrl, treat)
                for i, (ctrl, treat) in enumerate(spec.pairs)
            ]
            return await asyncio.gather(*tasks)

        pair_results = asyncio.run(_run_all())
        experiment.results.extend(pair_results)
    else:
        for i, (control_prompt, treatment_prompt) in enumerate(spec.pairs):
            if on_progress:
                on_progress(i, len(spec.pairs), "control")

            control_result = adapter.complete(control_prompt)
            if delay > 0:
                time.sleep(delay)

            if on_progress:
                on_progress(i, len(spec.pairs), "treatment")

            treatment_result = adapter.complete(treatment_prompt)
            if delay > 0:
                time.sleep(delay)

            answer_changed = _answers_differ(control_result.text, treatment_result.text)

            result = ExperimentResult(
                control_prompt=control_prompt,
                treatment_prompt=treatment_prompt,
                control_confidence=control_result.confidence,
                treatment_confidence=treatment_result.confidence,
                control_answer=control_result.text[:500],
                treatment_answer=treatment_result.text[:500],
                answer_changed=answer_changed,
                effect_name=spec.name,
            )

            experiment.results.append(result)

    return experiment
