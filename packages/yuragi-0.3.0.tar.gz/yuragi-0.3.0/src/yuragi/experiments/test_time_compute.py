"""Test-Time Compute Fragility experiment.

Compares confidence with and without explicit reasoning steps.
Hypothesis (Don't Think Twice, ICLR 2025): more reasoning → higher
overconfidence even though accuracy improves.

Reference: arxiv 2408.03314, OpenReview e7G5aeMOUP.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from yuragi.providers.adapter import LLMAdapter

_DEFAULT_REASONING_SUFFIX = "Think step by step before answering."


@dataclass(frozen=True)
class TestTimeComputeResult:
    __test__ = False  # not a pytest test class
    no_reasoning_confidence: float
    no_reasoning_accuracy: float
    with_reasoning_confidence: float
    with_reasoning_accuracy: float
    confidence_delta: float
    accuracy_delta: float
    overconfidence_amplified: bool  # True if confidence_delta > 0 and accuracy_delta near 0


def _check_answer(response_text: str, expected_answers: list[str]) -> float:
    """Return 1.0 if any expected answer appears in response, else 0.0."""
    if not expected_answers:
        return 0.0
    text_lower = response_text.lower()
    for ans in expected_answers:
        if ans.lower() in text_lower:
            return 1.0
    return 0.0


def run_test_time_compute(
    adapter: LLMAdapter,
    questions: Sequence[dict],
    *,
    reasoning_prompt_suffix: str = _DEFAULT_REASONING_SUFFIX,
) -> TestTimeComputeResult:
    """Run each question with and without reasoning prefix, compare confidence.

    Each question dict must have "question" key; optionally "answers" list for
    accuracy measurement.
    """
    no_reason_confidences: list[float] = []
    no_reason_accuracies: list[float] = []
    with_reason_confidences: list[float] = []
    with_reason_accuracies: list[float] = []

    for q in questions:
        question_text = q.get("question") or q.get("prompt") or str(q)
        expected = q.get("answers", [])

        # Without reasoning
        plain_result = adapter.complete(question_text)
        no_reason_confidences.append(plain_result.confidence)
        no_reason_accuracies.append(_check_answer(plain_result.text, expected))

        # With reasoning
        reasoning_prompt = f"{question_text}\n\n{reasoning_prompt_suffix}"
        reason_result = adapter.complete(reasoning_prompt)
        with_reason_confidences.append(reason_result.confidence)
        with_reason_accuracies.append(_check_answer(reason_result.text, expected))

    if not no_reason_confidences:
        return TestTimeComputeResult(
            no_reasoning_confidence=0.0,
            no_reasoning_accuracy=0.0,
            with_reasoning_confidence=0.0,
            with_reasoning_accuracy=0.0,
            confidence_delta=0.0,
            accuracy_delta=0.0,
            overconfidence_amplified=False,
        )

    avg_no_conf = sum(no_reason_confidences) / len(no_reason_confidences)
    avg_no_acc = sum(no_reason_accuracies) / len(no_reason_accuracies)
    avg_with_conf = sum(with_reason_confidences) / len(with_reason_confidences)
    avg_with_acc = sum(with_reason_accuracies) / len(with_reason_accuracies)

    conf_delta = avg_with_conf - avg_no_conf
    acc_delta = avg_with_acc - avg_no_acc

    # Overconfidence amplified: reasoning raises confidence but accuracy barely changes
    overconfidence_amplified = conf_delta > 0.05 and abs(acc_delta) < 0.1

    return TestTimeComputeResult(
        no_reasoning_confidence=avg_no_conf,
        no_reasoning_accuracy=avg_no_acc,
        with_reasoning_confidence=avg_with_conf,
        with_reasoning_accuracy=avg_with_acc,
        confidence_delta=conf_delta,
        accuracy_delta=acc_delta,
        overconfidence_amplified=overconfidence_amplified,
    )
