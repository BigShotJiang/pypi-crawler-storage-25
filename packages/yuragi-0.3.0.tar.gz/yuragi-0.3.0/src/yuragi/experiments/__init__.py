"""Psychology experiments module.

Pre-built experiments that demonstrate specific confidence phenomena,
inspired by classical psychology research. Each experiment tests a
known human psychological vulnerability on LLMs.
"""

from yuragi.experiments.registry import (
    Experiment,
    ExperimentResult,
    ExperimentSpec,
    get_experiment,
    list_experiments,
)
from yuragi.experiments.runner import run_experiment

__all__ = [
    "Experiment",
    "ExperimentResult",
    "ExperimentSpec",
    "get_experiment",
    "list_experiments",
    "run_experiment",
]
