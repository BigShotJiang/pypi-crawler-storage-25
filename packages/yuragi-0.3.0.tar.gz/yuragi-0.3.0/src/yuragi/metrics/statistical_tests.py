"""Statistical significance tests for fragility analysis.

Provides Cohen's d effect size, paired t-test, Wilcoxon signed-rank,
and bootstrap confidence intervals for comparing perturbation effects.

``numpy`` and ``scipy`` are imported lazily inside each function so that
``from yuragi.metrics import statistical_tests`` does not fail on a bare
``pip install yuragi`` install (both live under the ``[semantic]`` / ``[dev]``
optional extras). A clean :class:`~yuragi.exceptions.MissingDependencyError`
is raised at call time if either library is absent.
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING

from yuragi.exceptions import MissingDependencyError

if TYPE_CHECKING:
    from yuragi.core import ScanResult


def _require_numpy():
    try:
        import numpy as np

        return np
    except ImportError as err:
        raise MissingDependencyError(
            "numpy is required for statistical tests. "
            "Install with: pip install 'yuragi[semantic]' or pip install numpy"
        ) from err


def _require_scipy_stats():
    try:
        from scipy import stats

        return stats
    except ImportError as err:
        raise MissingDependencyError(
            "scipy is required for paired_t_test / wilcoxon. "
            "Install with: pip install 'yuragi[semantic]' or pip install scipy"
        ) from err


@dataclass(frozen=True)
class EffectSizeResult:
    cohens_d: float
    interpretation: str  # "negligible" / "small" / "medium" / "large"
    n: int


@dataclass(frozen=True)
class TestResult:
    __test__ = False  # not a pytest test class
    statistic: float
    p_value: float
    significant: bool  # at alpha=0.05
    test_name: str


@dataclass(frozen=True)
class CIResult:
    lower: float
    upper: float
    confidence_level: float


def cohens_d(group_a: Sequence[float], group_b: Sequence[float]) -> EffectSizeResult:
    """Cohen's d for two independent groups."""
    np = _require_numpy()
    a = np.asarray(group_a, dtype=float)
    b = np.asarray(group_b, dtype=float)
    n_a, n_b = len(a), len(b)
    if n_a < 2 or n_b < 2:
        raise ValueError("Each group must have at least 2 observations")
    pooled_std = math.sqrt(
        ((n_a - 1) * float(a.var(ddof=1)) + (n_b - 1) * float(b.var(ddof=1)))
        / (n_a + n_b - 2)
    )
    if pooled_std == 0:
        return EffectSizeResult(0.0, "negligible", n_a + n_b)
    d = (float(a.mean()) - float(b.mean())) / pooled_std
    if abs(d) < 0.2:
        interp = "negligible"
    elif abs(d) < 0.5:
        interp = "small"
    elif abs(d) < 0.8:
        interp = "medium"
    else:
        interp = "large"
    return EffectSizeResult(float(d), interp, n_a + n_b)


def paired_t_test(
    group_a: Sequence[float],
    group_b: Sequence[float],
    alpha: float = 0.05,
) -> TestResult:
    """Paired t-test for two related groups."""
    np = _require_numpy()
    stats = _require_scipy_stats()
    a = np.asarray(group_a, dtype=float)
    b = np.asarray(group_b, dtype=float)
    if len(a) != len(b):
        raise ValueError("Groups must have equal length for paired t-test")
    if len(a) < 2:
        raise ValueError("At least 2 pairs required")
    result = stats.ttest_rel(a, b)
    return TestResult(
        statistic=float(result.statistic),
        p_value=float(result.pvalue),
        significant=float(result.pvalue) < alpha,
        test_name="paired_t_test",
    )


def wilcoxon_signed_rank(
    group_a: Sequence[float],
    group_b: Sequence[float],
    alpha: float = 0.05,
) -> TestResult:
    """Wilcoxon signed-rank test for two related groups (non-parametric)."""
    np = _require_numpy()
    stats = _require_scipy_stats()
    a = np.asarray(group_a, dtype=float)
    b = np.asarray(group_b, dtype=float)
    if len(a) != len(b):
        raise ValueError("Groups must have equal length for Wilcoxon test")
    if len(a) < 2:
        raise ValueError("At least 2 pairs required")
    differences = a - b
    if np.all(differences == 0):
        return TestResult(
            statistic=0.0,
            p_value=1.0,
            significant=False,
            test_name="wilcoxon_signed_rank",
        )
    result = stats.wilcoxon(a, b)
    return TestResult(
        statistic=float(result.statistic),
        p_value=float(result.pvalue),
        significant=float(result.pvalue) < alpha,
        test_name="wilcoxon_signed_rank",
    )


def bootstrap_ci(
    data: Sequence[float],
    n_iterations: int = 10000,
    ci: float = 0.95,
    seed: int | None = None,
) -> CIResult:
    """Bootstrap confidence interval for the mean of data.

    Vectorised implementation: draws the full ``(n_iterations, n)`` index
    matrix in one call and computes bootstrap means via a single
    ``mean(axis=1)``. This is ~100x faster than the naive Python loop and
    scales to ``n_iterations=10000`` without breaking the interactive
    experience.
    """
    np = _require_numpy()
    arr = np.asarray(data, dtype=float)
    n = len(arr)
    if n == 0:
        raise ValueError("Data must not be empty")
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, n, size=(n_iterations, n))
    bootstrap_means = arr[idx].mean(axis=1)
    alpha = (1.0 - ci) / 2.0
    lower = float(np.quantile(bootstrap_means, alpha))
    upper = float(np.quantile(bootstrap_means, 1.0 - alpha))
    return CIResult(lower=lower, upper=upper, confidence_level=ci)


def compare_fragility(scan_a: ScanResult, scan_b: ScanResult) -> dict:
    """High-level helper: compare two ScanResults with all tests.

    Pairs samples by ``perturbation_type`` and the index within that type
    so that the paired tests compare like with like (scan A's typo-variant-0
    against scan B's typo-variant-0, etc.). Unpaired samples are reported
    under ``unpaired_cohens_d`` on the full lists.

    Returns a dict with cohens_d (unpaired, full lists), paired_t_test,
    wilcoxon, and bootstrap_ci_a / bootstrap_ci_b for the confidence_delta
    distributions.
    """
    deltas_a = [r.confidence_delta for r in scan_a.perturbation_results]
    deltas_b = [r.confidence_delta for r in scan_b.perturbation_results]

    result: dict = {
        "scan_a_fragility": scan_a.fragility_score,
        "scan_b_fragility": scan_b.fragility_score,
        "bootstrap_ci_a": bootstrap_ci(deltas_a) if deltas_a else None,
        "bootstrap_ci_b": bootstrap_ci(deltas_b) if deltas_b else None,
    }

    if len(deltas_a) >= 2 and len(deltas_b) >= 2:
        result["cohens_d"] = cohens_d(deltas_a, deltas_b)

    # Pair samples by (perturbation_type, index-within-type) so paired tests
    # actually compare like with like rather than trusting source order.
    from collections import defaultdict

    def _by_type(results) -> dict[str, list[float]]:
        bucket: dict[str, list[float]] = defaultdict(list)
        for r in results:
            bucket[str(r.perturbation_type)].append(r.confidence_delta)
        return bucket

    bucket_a = _by_type(scan_a.perturbation_results)
    bucket_b = _by_type(scan_b.perturbation_results)

    paired_a: list[float] = []
    paired_b: list[float] = []
    for ptype in sorted(set(bucket_a) & set(bucket_b)):
        n = min(len(bucket_a[ptype]), len(bucket_b[ptype]))
        paired_a.extend(bucket_a[ptype][:n])
        paired_b.extend(bucket_b[ptype][:n])

    if len(paired_a) >= 2:
        result["paired_t_test"] = paired_t_test(paired_a, paired_b)
        result["wilcoxon"] = wilcoxon_signed_rank(paired_a, paired_b)
        result["paired_n"] = len(paired_a)

    return result
