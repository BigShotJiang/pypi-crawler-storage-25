"""Confidence measurement and calibration metrics.

Modules:
- calibration: ECE, mutual information, surface curvature, Brier score
- volatility: Financial-engineering inspired confidence volatility metrics
"""

from yuragi.metrics.calibration import (
    brier_score,
    confidence_surface_curvature,
    expected_calibration_error,
    overconfidence_score,
)
from yuragi.metrics.semantic_entropy import semantic_entropy
from yuragi.metrics.statistical_tests import (
    CIResult,
    EffectSizeResult,
    TestResult,
    bootstrap_ci,
    cohens_d,
    compare_fragility,
    paired_t_test,
    wilcoxon_signed_rank,
)
from yuragi.metrics.verbalized_logit_gap import dissociation_score, verbalized_logit_gap
from yuragi.metrics.volatility import (
    VolatilityReport,
    autocorrelation,
    compute_volatility,
    confidence_sharpe,
    confidence_vix,
    detect_regime,
    max_drawdown_and_duration,
    realized_volatility,
)

__all__ = [
    "CIResult",
    "EffectSizeResult",
    "TestResult",
    "VolatilityReport",
    "autocorrelation",
    "bootstrap_ci",
    "brier_score",
    "cohens_d",
    "compare_fragility",
    "compute_volatility",
    "confidence_sharpe",
    "confidence_surface_curvature",
    "confidence_vix",
    "detect_regime",
    "dissociation_score",
    "expected_calibration_error",
    "max_drawdown_and_duration",
    "overconfidence_score",
    "paired_t_test",
    "realized_volatility",
    "semantic_entropy",
    "verbalized_logit_gap",
    "wilcoxon_signed_rank",
]
