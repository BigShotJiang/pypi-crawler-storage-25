"""Financial-engineering inspired confidence volatility metrics.

Analogous to VIX / historical volatility in equity markets, applied to LLM confidence.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.core import PerturbationResult, ScanResult


@dataclass
class VolatilityReport:
    """Financial-engineering inspired confidence volatility metrics."""

    # Core volatility (analogous to historical volatility)
    realized_volatility: float
    """Annualized std of log-returns of confidence."""

    # VIX-like "fear index" for this prompt
    confidence_vix: float
    """0-100 scale, higher = more volatile."""

    # Drawdown analysis (from finance)
    max_drawdown: float
    """Largest peak-to-trough decline."""

    drawdown_duration: int
    """How many perturbations until recovery."""

    # Sharpe-like ratio: signal (mean confidence) / noise (volatility)
    confidence_sharpe: float
    """Higher = more reliable confidence."""

    # Regime detection: is the model in a "stable" or "volatile" regime?
    regime: str
    """'stable', 'transitional', 'volatile', or 'chaotic'."""

    # Autocorrelation: do consecutive perturbations' deltas correlate?
    autocorrelation: float
    """-1 to 1. High = momentum, low = mean-reverting."""


# ---------------------------------------------------------------------------
# 1. Realized Volatility
# ---------------------------------------------------------------------------

def realized_volatility(results: list[PerturbationResult]) -> float:
    """Annualized std of log-returns of confidence.

    log-return at step i = log(conf[i] / conf[i-1])
    realized_vol = std(log_returns) * sqrt(N)

    Returns 0.0 for fewer than 2 results.
    """
    if len(results) < 2:
        return 0.0

    confidences = [r.perturbed_response.confidence for r in results]
    eps = 1e-9

    log_returns: list[float] = []
    for i in range(1, len(confidences)):
        prev = max(confidences[i - 1], eps)
        curr = max(confidences[i], eps)
        log_returns.append(math.log(curr / prev))

    n = len(log_returns)
    if n == 0:
        return 0.0

    mean = sum(log_returns) / n
    variance = sum((r - mean) ** 2 for r in log_returns) / n
    std = math.sqrt(variance)
    return std * math.sqrt(n)


# ---------------------------------------------------------------------------
# 2. Confidence VIX
# ---------------------------------------------------------------------------

def confidence_vix(
    results: list[PerturbationResult], config: YuragiConfig | None = None
) -> float:
    """VIX-like fear index normalized to 0-100.

    50 = average volatility. <50 = calm, >50 = fearful/volatile.
    Based on the realized_volatility, standardized with empirical baseline stats.

    Returns 50.0 for fewer than 2 results (undefined, treated as average).
    """
    cfg = config or DEFAULT_CONFIG

    if len(results) < 2:
        return 50.0

    rv = realized_volatility(results)
    z = (rv - cfg.vix_baseline_mean) / max(cfg.vix_baseline_std, 1e-9)
    # Map z-score to 0-100 with 50 as center via sigmoid-like scaling
    vix = 50.0 + z * 10.0
    return max(0.0, min(100.0, vix))


# ---------------------------------------------------------------------------
# 3. Drawdown Analysis
# ---------------------------------------------------------------------------

def max_drawdown_and_duration(results: list[PerturbationResult]) -> tuple[float, int]:
    """Compute max drawdown and drawdown duration from perturbation confidence series.

    max_drawdown: largest peak-to-trough decline in the confidence sequence.
    drawdown_duration: number of steps from peak to next recovery above peak.

    Returns (0.0, 0) for empty input.
    """
    if not results:
        return 0.0, 0

    confidences = [r.perturbed_response.confidence for r in results]
    n = len(confidences)

    peak = confidences[0]
    best_drawdown = 0.0
    best_duration = 0

    for i in range(n):
        if confidences[i] > peak:
            peak = confidences[i]

        drawdown = peak - confidences[i]
        if drawdown > best_drawdown:
            best_drawdown = drawdown
            # Count steps until confidence recovers to peak
            duration = 0
            for j in range(i + 1, n):
                duration += 1
                if confidences[j] >= peak:
                    break
            best_duration = duration

    return best_drawdown, best_duration


# ---------------------------------------------------------------------------
# 4. Confidence Sharpe Ratio
# ---------------------------------------------------------------------------

def confidence_sharpe(results: list[PerturbationResult]) -> float:
    """Sharpe-like ratio: mean(confidence) / std(confidence).

    Higher = more reliable signal relative to noise.
    Returns 0.0 for empty input or zero std.
    """
    if not results:
        return 0.0

    confidences = [r.perturbed_response.confidence for r in results]
    n = len(confidences)
    mean = sum(confidences) / n

    if n < 2:
        return 0.0

    variance = sum((c - mean) ** 2 for c in confidences) / n
    std = math.sqrt(variance)

    if std < 1e-9:
        return 0.0

    return mean / std


# ---------------------------------------------------------------------------
# 5. Regime Detection
# ---------------------------------------------------------------------------

def detect_regime(rv: float, config: YuragiConfig | None = None) -> str:
    """Classify volatility regime from realized_volatility value.

    Default thresholds (on 0-1 confidence scale):
    - stable:       rv < 0.10
    - transitional: rv < 0.30
    - volatile:     rv < 0.50
    - chaotic:      rv >= 0.50
    """
    cfg = config or DEFAULT_CONFIG
    if rv < cfg.regime_stable:
        return "stable"
    elif rv < cfg.regime_transitional:
        return "transitional"
    elif rv < cfg.regime_volatile:
        return "volatile"
    else:
        return "chaotic"


# ---------------------------------------------------------------------------
# 6. Autocorrelation
# ---------------------------------------------------------------------------

def autocorrelation(results: list[PerturbationResult]) -> float:
    """Pearson r between consecutive confidence deltas (lag-1 autocorrelation).

    Positive = momentum (big drop followed by big drop).
    Negative = mean-reverting (big drop followed by recovery).

    Returns 0.0 for fewer than 3 results (need at least 2 delta pairs).
    """
    if len(results) < 3:
        return 0.0

    confidences = [r.perturbed_response.confidence for r in results]
    deltas = [confidences[i] - confidences[i - 1] for i in range(1, len(confidences))]

    n = len(deltas)
    if n < 2:
        return 0.0

    x = deltas[:-1]
    y = deltas[1:]
    m = len(x)

    mean_x = sum(x) / m
    mean_y = sum(y) / m

    cov = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(m))
    std_x = math.sqrt(sum((v - mean_x) ** 2 for v in x))
    std_y = math.sqrt(sum((v - mean_y) ** 2 for v in y))

    denom = std_x * std_y
    if denom < 1e-9:
        return 0.0

    return max(-1.0, min(1.0, cov / denom))


# ---------------------------------------------------------------------------
# Aggregate
# ---------------------------------------------------------------------------

def compute_volatility(
    scan: ScanResult, config: YuragiConfig | None = None
) -> VolatilityReport:
    """Compute all volatility metrics from a ScanResult.

    Args:
        scan: A completed ScanResult.
        config: Optional YuragiConfig for threshold overrides.

    Returns:
        VolatilityReport with all volatility metrics.
    """
    cfg = config or getattr(scan, "config", None) or DEFAULT_CONFIG
    results = scan.perturbation_results

    rv = realized_volatility(results)
    vix = confidence_vix(results, config=cfg)
    drawdown, duration = max_drawdown_and_duration(results)
    sharpe = confidence_sharpe(results)
    regime = detect_regime(rv, config=cfg)
    ac = autocorrelation(results)

    return VolatilityReport(
        realized_volatility=rv,
        confidence_vix=vix,
        max_drawdown=drawdown,
        drawdown_duration=duration,
        confidence_sharpe=sharpe,
        regime=regime,
        autocorrelation=ac,
    )
