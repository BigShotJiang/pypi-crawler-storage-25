"""Keyboard-distance based typo generation.

Simulates realistic human typos by replacing characters with
adjacent keys on a QWERTY keyboard layout.
"""

from __future__ import annotations

import random

from yuragi.utils import ADJACENT_KEYS as _ADJACENT_KEYS


def generate_typo(
    text: str, num_variants: int = 3, *, rng: random.Random | None = None
) -> list[str]:
    """Generate variants with realistic keyboard typos.

    Only modifies words longer than 3 characters to keep
    the perturbation subtle.

    Args:
        rng: Optional seeded Random instance for reproducibility.
             If None, uses the global random module.
    """
    _rng = rng if rng is not None else random
    words = text.split()
    if not words:
        return []

    # Find candidate words (length > 3, alphabetic)
    candidates = [
        (i, w)
        for i, w in enumerate(words)
        if len(w) > 3 and any(c.isalpha() for c in w)
    ]

    if not candidates:
        # Fall back to any word with letters
        candidates = [
            (i, w) for i, w in enumerate(words) if any(c.isalpha() for c in w)
        ]

    if not candidates:
        return []

    variants = []
    seen = set()

    for _ in range(num_variants * 3):  # Over-generate to handle duplicates
        if len(variants) >= num_variants:
            break

        idx, word = _rng.choice(candidates)
        typo_word = _make_typo(word, _rng)

        if typo_word == word:
            continue

        new_words = words.copy()
        new_words[idx] = typo_word
        variant = " ".join(new_words)

        if variant not in seen:
            seen.add(variant)
            variants.append(variant)

    return variants


def _make_typo(word: str, rng: random.Random) -> str:
    """Introduce a single typo into a word."""
    chars = list(word)

    # Find positions with alphabetic chars
    positions = [i for i, c in enumerate(chars) if c.isalpha()]
    if not positions:
        return word

    pos = rng.choice(positions)
    char = chars[pos].lower()

    if char in _ADJACENT_KEYS:
        adjacent = _ADJACENT_KEYS[char]
        replacement = rng.choice(adjacent)
        # Preserve case
        if chars[pos].isupper():
            replacement = replacement.upper()
        chars[pos] = replacement

    return "".join(chars)
