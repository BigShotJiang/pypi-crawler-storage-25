"""Synonym replacement perturbation.

Replaces words with semantically similar alternatives.
Uses a built-in synonym map for common words (no external dependencies).
Falls back to simple heuristics for unknown words.
"""

from __future__ import annotations

import random

# Common synonym pairs (bidirectional)
_SYNONYMS: dict[str, list[str]] = {
    # English — Academic
    "analyze": ["examine", "investigate", "assess", "evaluate"],
    "demonstrate": ["illustrate", "prove", "establish", "show"],
    "indicate": ["suggest", "imply", "signify", "denote"],
    "obtain": ["acquire", "gain", "achieve", "attain"],
    "require": ["need", "demand", "necessitate", "call for"],
    "significant": ["notable", "substantial", "meaningful", "considerable"],
    "sufficient": ["adequate", "enough", "satisfactory", "ample"],
    "implement": ["execute", "carry out", "apply", "deploy"],
    "evaluate": ["assess", "measure", "gauge", "appraise"],
    "determine": ["establish", "ascertain", "identify", "find out"],
    "propose": ["suggest", "recommend", "put forward", "advance"],
    "conclude": ["infer", "deduce", "find", "determine"],
    "assume": ["presume", "suppose", "take for granted", "postulate"],
    "evidence": ["proof", "data", "findings", "indication"],
    "method": ["approach", "technique", "procedure", "strategy"],
    # English — Technical
    "error": ["fault", "defect", "bug", "failure"],
    "process": ["procedure", "operation", "workflow", "mechanism"],
    "system": ["framework", "platform", "infrastructure", "architecture"],
    "function": ["operate", "work", "perform", "run"],
    "data": ["information", "input", "records", "values"],
    "output": ["result", "response", "product", "outcome"],
    "input": ["data", "parameters", "arguments", "values"],
    "compute": ["calculate", "process", "derive", "determine"],
    "store": ["save", "persist", "retain", "record"],
    "retrieve": ["fetch", "access", "get", "obtain"],
    "update": ["modify", "change", "revise", "alter"],
    "delete": ["remove", "erase", "eliminate", "discard"],
    "connect": ["link", "integrate", "attach", "join"],
    "optimize": ["improve", "enhance", "refine", "tune"],
    "test": ["verify", "validate", "check", "examine"],
    # English — Daily
    "good": ["great", "excellent", "fine", "nice"],
    "great": ["good", "excellent", "wonderful", "superb"],
    "bad": ["poor", "terrible", "awful", "negative"],
    "big": ["large", "huge", "enormous", "massive"],
    "small": ["tiny", "little", "minor", "compact"],
    "fast": ["quick", "rapid", "swift", "speedy"],
    "slow": ["gradual", "sluggish", "unhurried", "leisurely"],
    "important": ["significant", "crucial", "vital", "essential"],
    "simple": ["easy", "basic", "straightforward", "plain"],
    "difficult": ["hard", "challenging", "complex", "tough"],
    "explain": ["describe", "clarify", "elaborate", "illustrate"],
    "show": ["demonstrate", "display", "present", "reveal"],
    "think": ["believe", "consider", "assume", "suppose"],
    "make": ["create", "build", "produce", "construct"],
    "use": ["utilize", "employ", "apply", "leverage"],
    "help": ["assist", "aid", "support", "guide"],
    "start": ["begin", "commence", "initiate", "launch"],
    "end": ["finish", "conclude", "complete", "terminate"],
    "problem": ["issue", "challenge", "difficulty", "concern"],
    "answer": ["response", "reply", "solution", "result"],
    "question": ["query", "inquiry", "prompt", "request"],
    "very": ["extremely", "highly", "really", "incredibly"],
    "also": ["additionally", "furthermore", "moreover", "too"],
    "however": ["nevertheless", "nonetheless", "yet", "still"],
    "because": ["since", "as", "due to", "given that"],
    "about": ["regarding", "concerning", "related to", "on"],
    "new": ["novel", "fresh", "recent", "modern"],
    "old": ["ancient", "dated", "outdated", "prior"],
    "true": ["correct", "accurate", "valid", "right"],
    "false": ["incorrect", "wrong", "inaccurate", "invalid"],
    "large": ["big", "substantial", "extensive", "broad"],
    "many": ["numerous", "multiple", "various", "several"],
    "few": ["limited", "scarce", "minimal", "a handful of"],
    "always": ["constantly", "invariably", "consistently", "perpetually"],
    "never": ["not once", "at no time", "in no case", "under no circumstances"],
    "often": ["frequently", "commonly", "regularly", "repeatedly"],
    "get": ["obtain", "acquire", "receive", "gain"],
    "give": ["provide", "offer", "supply", "grant"],
    "know": ["understand", "recognize", "realize", "be aware of"],
    "want": ["desire", "wish", "seek", "aim for"],
    "need": ["require", "must have", "depend on", "rely on"],
    "try": ["attempt", "endeavor", "strive", "aim"],
    "change": ["alter", "modify", "adjust", "transform"],
    "keep": ["maintain", "preserve", "retain", "hold"],
    "move": ["shift", "transfer", "relocate", "migrate"],
    "find": ["discover", "locate", "identify", "uncover"],
    "learn": ["study", "acquire", "master", "grasp"],
    "work": ["function", "operate", "perform", "act"],
    "see": ["observe", "notice", "perceive", "detect"],
    "say": ["state", "mention", "declare", "assert"],
    "go": ["proceed", "advance", "move", "head"],
    "come": ["arrive", "approach", "reach", "appear"],
    "take": ["grasp", "obtain", "acquire", "accept"],
    "put": ["place", "position", "set", "locate"],
    "look": ["examine", "inspect", "observe", "review"],
    "call": ["name", "label", "refer to", "designate"],
    "tell": ["inform", "notify", "communicate", "convey"],
    "write": ["compose", "draft", "author", "produce"],
    "read": ["review", "study", "examine", "peruse"],
    "speak": ["talk", "communicate", "articulate", "voice"],
    "build": ["construct", "develop", "create", "assemble"],
    "break": ["shatter", "disrupt", "interrupt", "violate"],
    "join": ["connect", "link", "merge", "combine"],
    "leave": ["depart", "exit", "abandon", "quit"],
    "allow": ["permit", "enable", "authorize", "let"],
    "prevent": ["stop", "block", "prohibit", "hinder"],
    "increase": ["grow", "expand", "rise", "boost"],
    "decrease": ["reduce", "drop", "decline", "diminish"],
    "confirm": ["verify", "validate", "affirm", "establish"],
    "suggest": ["recommend", "propose", "advise", "indicate"],
    "examine": ["inspect", "review", "analyze", "investigate"],
    # Japanese — everyday verbs
    "説明": ["解説", "記述", "紹介", "述べて"],
    "教えて": ["説明して", "示して", "解説して"],
    "思う": ["考える", "推測する", "感じる", "見なす"],
    "考える": ["思う", "検討する", "判断する", "分析する"],
    "感じる": ["思う", "覚える", "意識する", "知覚する"],
    "見る": ["確認する", "観察する", "眺める", "チェックする"],
    "言う": ["述べる", "話す", "語る", "表現する"],
    "聞く": ["尋ねる", "質問する", "伺う", "問い合わせる"],
    "知る": ["理解する", "把握する", "認識する", "気づく"],
    "分かる": ["理解する", "把握する", "察する", "飲み込む"],
    "作る": ["制作する", "生成する", "構築する", "製作する"],
    "使う": ["利用する", "活用する", "用いる", "採用する"],
    "始める": ["開始する", "着手する", "スタートする", "踏み出す"],
    "終わる": ["完了する", "終了する", "締めくくる", "仕上げる"],
    "決める": ["判断する", "決定する", "確定する", "選ぶ"],
    "変える": ["変更する", "修正する", "改める", "転換する"],
    "増やす": ["拡大する", "強化する", "伸ばす", "高める"],
    "減らす": ["削減する", "縮小する", "下げる", "抑える"],
    "調べる": ["確認する", "検索する", "リサーチする", "調査する"],
    "求める": ["要求する", "希望する", "お願いする", "依頼する"],
    # Japanese — adjectives
    "良い": ["素晴らしい", "優れた", "適切な", "望ましい"],
    "悪い": ["不適切な", "問題のある", "望ましくない", "劣った"],
    "大きい": ["巨大な", "大規模な", "広大な", "広い"],
    "小さい": ["微小な", "小規模な", "コンパクトな", "細かい"],
    "重要": ["大切", "肝要", "不可欠", "重大"],
    "簡単": ["容易", "シンプル", "手軽", "平易"],
    "難しい": ["困難", "複雑", "厄介", "至難"],
    "新しい": ["最新の", "新規の", "斬新な", "現代的な"],
    "古い": ["旧来の", "従来の", "伝統的な", "時代遅れの"],
    "速い": ["素早い", "迅速な", "高速な", "敏速な"],
    "遅い": ["緩やかな", "ゆっくりした", "低速な", "のろい"],
    "正しい": ["適切な", "妥当な", "正確な", "妥当"],
    "間違った": ["誤った", "不正確な", "不適切な", "誤り"],
    "多い": ["豊富な", "たくさんの", "数多くの", "膨大な"],
    "少ない": ["わずかな", "乏しい", "限られた", "少数の"],
    "強い": ["力強い", "頑丈な", "強力な", "たくましい"],
    "弱い": ["脆弱な", "もろい", "か細い", "力不足の"],
    "明るい": ["鮮明な", "輝かしい", "光り輝く", "クリアな"],
    "暗い": ["薄暗い", "陰鬱な", "不透明な", "くすんだ"],
    "長い": ["延長した", "長大な", "長期にわたる", "広範な"],
    "短い": ["簡潔な", "短期の", "コンパクトな", "素早い"],
    # Japanese — adverbs and expressions
    "本当に": ["本当のところ", "実際に", "真に", "まさに"],
    "絶対に": ["必ず", "確実に", "間違いなく", "断じて"],
    "たぶん": ["おそらく", "恐らく", "多分", "推測では"],
    "とても": ["非常に", "大変", "極めて", "かなり"],
    "すぐに": ["直ちに", "即座に", "すばやく", "早急に"],
    "ゆっくり": ["徐々に", "段階的に", "慎重に", "じっくりと"],
    "よく": ["頻繁に", "しばしば", "たびたび", "何度も"],
    "少し": ["わずかに", "ほんの少し", "多少", "若干"],
    "全て": ["すべて", "あらゆる", "一切", "全部"],
    "だいたい": ["おおよそ", "概ね", "ほぼ", "大略"],
    "特に": ["とりわけ", "特別に", "格別に", "殊に"],
    "もちろん": ["当然", "確かに", "言うまでもなく", "むろん"],
    "きっと": ["必ず", "確かに", "間違いなく", "確実に"],
    # Japanese — nouns
    "問題": ["課題", "懸念", "難点", "障害"],
    "方法": ["手法", "手段", "やり方", "アプローチ"],
    "理由": ["原因", "根拠", "動機", "訳"],
    "結果": ["成果", "結論", "産物", "帰結"],
    "目的": ["目標", "狙い", "意図", "趣旨"],
    "情報": ["データ", "知識", "資料", "内容"],
    "質問": ["疑問", "問い合わせ", "照会", "問題"],
    "答え": ["回答", "返答", "解答", "解"],
    "意見": ["見解", "考え", "看護", "立場"],
    "例": ["事例", "実例", "ケース", "サンプル"],
    "違い": ["差異", "相違", "差", "ギャップ"],
    "影響": ["効果", "インパクト", "作用", "波及"],
    "仕事": ["業務", "作業", "タスク", "職務"],
    "人": ["人物", "個人", "者", "方"],
}


def generate_synonym(
    text: str, num_variants: int = 3, *, rng: random.Random | None = None
) -> list[str]:
    """Generate variants by replacing words with synonyms.

    Args:
        rng: Optional seeded Random instance for reproducibility.
             If None, uses the global random module.
    """
    _rng = rng if rng is not None else random
    variants = []
    seen = set()

    # Try word-level replacement
    words = text.split()
    replaceable: list[tuple[int, str, str]] = []
    seen_keys: set[str] = set()

    # Precompute which synonym keys actually appear as substrings in the
    # text so we only scan the dictionary once per call instead of
    # O(n_words * n_synonyms). This is the hot path for large prompts.
    substring_keys = [key for key in _SYNONYMS if key in text]

    for i, word in enumerate(words):
        clean = word.strip(".,!?;:\"'()[]{}").lower()
        if clean in _SYNONYMS and clean not in seen_keys:
            replaceable.append((i, word, clean))
            seen_keys.add(clean)

    for key in substring_keys:
        if key not in seen_keys:
            replaceable.append((-1, key, key))  # -1 = substring mode
            seen_keys.add(key)

    if not replaceable:
        return []

    for _ in range(num_variants * 3):
        if len(variants) >= num_variants:
            break

        idx, original, clean = _rng.choice(replaceable)
        syns = _SYNONYMS.get(clean, [])
        if not syns:
            continue

        replacement = _rng.choice(syns)

        if idx == -1:
            # Substring replacement (for Japanese and multi-word)
            variant = text.replace(original, replacement, 1)
        else:
            # Word-level replacement
            new_words = words.copy()
            # Preserve punctuation
            prefix = ""
            suffix = ""
            for c in original:
                if c.isalnum() or c in "ぁ-んァ-ヶ亜-熙":
                    break
                prefix += c
            for c in reversed(original):
                if c.isalnum() or c in "ぁ-んァ-ヶ亜-熙":
                    break
                suffix = c + suffix

            new_words[idx] = prefix + replacement + suffix
            variant = " ".join(new_words)

        if variant != text and variant not in seen:
            seen.add(variant)
            variants.append(variant)

    return variants
