"""Token omission perturbation.

Removes individual words or short phrases from the prompt.
This is the most direct test of confidence fragility:
which word, when removed, causes the biggest confidence shift?
"""

from __future__ import annotations

import re

# Simple POS-tag heuristics (no external deps)
_STOPWORDS_EN = frozenset(
    {
        "a", "an", "the", "is", "are", "was", "were", "be", "been",
        "being", "have", "has", "had", "do", "does", "did", "will",
        "would", "could", "should", "may", "might", "shall", "can",
        "to", "of", "in", "on", "at", "by", "for", "with", "as",
        "and", "or", "but", "if", "so", "yet", "nor",
    }
)

# Words that are likely nouns: title-case or following "the/a"
_LIKELY_VERB_SUFFIXES = ("ed", "ing", "ize", "ise", "ify", "ate")
_LIKELY_ADJ_SUFFIXES = ("ful", "less", "ous", "ive", "ic", "al", "ible", "able")


def _pos_hint(word: str) -> str:
    """Return a rough POS hint: 'noun', 'verb', 'adj', or 'other'."""
    w = word.lower().rstrip(".,!?;:")
    if w in _STOPWORDS_EN:
        return "other"
    if any(w.endswith(s) for s in _LIKELY_VERB_SUFFIXES):
        return "verb"
    if any(w.endswith(s) for s in _LIKELY_ADJ_SUFFIXES):
        return "adj"
    # Fallback: uppercase initial → probable noun (proper or regular)
    if word and word[0].isupper() and len(word) > 1:
        return "noun"
    return "other"


def generate_omit(text: str, num_variants: int = 0, rng=None) -> list[str]:
    """Generate variants by removing one word at a time.

    If num_variants is 0 (default), generates ALL possible single-word
    omissions. This is useful for finding the most fragile token.

    Args:
        rng: accepts rng for API consistency; omission order is deterministic.
    """
    words = text.split()
    if len(words) <= 1:
        return []

    variants = []

    if num_variants == 0:
        # Generate all single-word omissions
        for i in range(len(words)):
            remaining = words[:i] + words[i + 1 :]
            variant = " ".join(remaining)
            if variant.strip():
                variants.append(variant)
    else:
        # Generate a subset of omissions, spread across the text
        step = max(1, len(words) // num_variants)
        indices = list(range(0, len(words), step))[:num_variants]
        for i in indices:
            remaining = words[:i] + words[i + 1 :]
            variant = " ".join(remaining)
            if variant.strip():
                variants.append(variant)

    return variants


def generate_phrase_omit(text: str, phrase_len: int = 2, num_variants: int = 0) -> list[str]:
    """Remove contiguous N-word phrases from the text.

    A step up from single-word omission: removing a 2-3 word chunk
    can collapse more meaning at once, revealing heavier fragility.
    """
    words = text.split()
    if len(words) <= phrase_len:
        return []

    variants = []
    positions = range(len(words) - phrase_len + 1)

    if num_variants == 0:
        indices = positions
    else:
        step = max(1, len(list(positions)) // num_variants)
        indices = list(positions)[::step][:num_variants]

    for i in indices:
        remaining = words[:i] + words[i + phrase_len :]
        variant = " ".join(remaining)
        if variant.strip():
            variants.append(variant)

    return variants


def generate_clause_omit(text: str) -> list[str]:
    """Remove comma- or semicolon-delimited clauses from the text.

    Each variant drops one clause, testing whether peripheral clauses
    carry load-bearing confidence information.
    """
    # Split on comma/semicolon boundaries
    parts = re.split(r"\s*[,;]\s*", text)
    if len(parts) <= 1:
        return []

    variants = []
    for i in range(len(parts)):
        remaining = parts[:i] + parts[i + 1 :]
        variant = ", ".join(remaining).strip()
        if variant:
            variants.append(variant)

    return variants


def generate_selective_omit(
    text: str,
    pos: str = "noun",
    num_variants: int = 0,
) -> list[str]:
    """Remove words of a specific part of speech.

    Args:
        text: The input text.
        pos: One of 'noun', 'verb', 'adj'. Uses lightweight heuristics;
             no external NLP library required.
        num_variants: Maximum variants (0 = all).

    Removing only nouns vs. only verbs reveals which grammatical class
    carries the most weight for the model's confidence.
    """
    words = text.split()
    if len(words) <= 1:
        return []

    target_indices = [i for i, w in enumerate(words) if _pos_hint(w) == pos]
    if not target_indices:
        return []

    if num_variants and num_variants < len(target_indices):
        step = max(1, len(target_indices) // num_variants)
        target_indices = target_indices[::step][:num_variants]

    variants = []
    for i in target_indices:
        remaining = words[:i] + words[i + 1 :]
        variant = " ".join(remaining)
        if variant.strip():
            variants.append(variant)

    return variants


def generate_progressive_omit(text: str, max_words: int = 3) -> list[list[str]]:
    """Return omission variants at increasing depths (1, 2, … max_words removed).

    Each entry in the returned list is itself a list of variants with the
    same number of words removed.  Plotting model confidence against omission
    depth draws a *collapse curve*: abrupt drops signal fragile tokens.

    Example:
        depth_1 = [text minus 1 word, ...]   # mild perturbation
        depth_2 = [text minus 2 words, ...]  # moderate
        depth_3 = [text minus 3 words, ...]  # heavy
    """
    result: list[list[str]] = []
    for depth in range(1, max_words + 1):
        result.append(generate_phrase_omit(text, phrase_len=depth, num_variants=0))
    return result
