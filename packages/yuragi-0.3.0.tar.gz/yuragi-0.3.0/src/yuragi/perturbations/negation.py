"""Negation perturbation.

Inserts negation markers ('not', 'never', 'no longer') into the input
to flip its meaning and measure confidence under semantic inversion.
Reference: arxiv 2311.08662 (EMNLP 2024).
"""

from __future__ import annotations

import random
import re

# Auxiliary verb negation patterns (word -> negated form)
_NEGATION_MAP = {
    r"\bis\b": "is not",
    r"\bare\b": "are not",
    r"\bwas\b": "was not",
    r"\bwere\b": "were not",
    r"\bcan\b": "cannot",
    r"\bcould\b": "could not",
    r"\bshould\b": "should not",
    r"\bwould\b": "would not",
    r"\bwill\b": "will not",
    r"\bdo\b": "do not",
    r"\bdoes\b": "does not",
    r"\bdid\b": "did not",
    r"\bhave\b": "have not",
    r"\bhas\b": "has not",
}

_NEGATION_SUFFIX = " Is this correct?"
_NEVER_PREFIX = "Never "
_NO_LONGER_PREFIX = "This is no longer true: "


def generate_negation(
    text: str,
    num_variants: int = 3,
    *,
    rng: random.Random | None = None,
) -> list[str]:
    """Insert negation into the text in different positions.

    Strategies:
    1. Auxiliary verb substitution (is -> is not, can -> cannot, etc.)
    2. Prepend 'Never ' to the sentence
    3. Append ' Is this correct?' (reversing polarity as a question)
    """
    _rng = rng or random.Random()
    variants: list[str] = []

    # Strategy 1: substitute the first matching auxiliary verb
    for pattern, replacement in _NEGATION_MAP.items():
        negated = re.sub(pattern, replacement, text, count=1, flags=re.IGNORECASE)
        if negated != text:
            variants.append(negated)
            break

    # Strategy 2: prepend 'Never '
    first_word = text.split()[0] if text.split() else ""
    if first_word.lower() not in {"never", "not", "no"}:
        variants.append(_NEVER_PREFIX + text[0].lower() + text[1:] if text else text)

    # Strategy 3: 'This is no longer true: ...' prefix
    variants.append(_NO_LONGER_PREFIX + text)

    # Strategy 4: append ' Is this correct?' if not already a question
    if not text.rstrip().endswith("?"):
        variants.append(text + _NEGATION_SUFFIX)

    # Shuffle and trim to num_variants
    _rng.shuffle(variants)
    return variants[:num_variants]
