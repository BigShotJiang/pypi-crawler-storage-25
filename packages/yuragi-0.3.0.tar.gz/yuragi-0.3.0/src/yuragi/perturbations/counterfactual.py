"""Counterfactual perturbation.

Inserts counterfactual premises (statements that contradict known facts)
to test confidence resilience under false context.
Reference: OpenReview 0P1mkOvFIs.
"""

from __future__ import annotations

import random

_COUNTERFACTUALS = [
    "Assume the sky is green. ",
    "In a world where 2+2=5, ",
    "If gravity pulled objects upward, ",
    "Suppose water freezes at 100°C, ",
    "Imagine the Earth is flat. ",
    "Assume the Sun orbits the Earth. ",
    "In a world where humans have three eyes, ",
    "Suppose the speed of light is 1 km/s. ",
    "Assume there are only 5 continents. ",
    "In a world where the Moon does not exist, ",
]


def generate_counterfactual(
    text: str,
    num_variants: int = 3,
    *,
    rng: random.Random | None = None,
) -> list[str]:
    """Prepend counterfactual statements to the text.

    Each variant prepends a different statement that contradicts a well-known
    fact, forcing the model to reason under a false premise.
    """
    _rng = rng or random.Random()
    pool = list(_COUNTERFACTUALS)
    _rng.shuffle(pool)
    selected = pool[:num_variants]
    return [prefix + text for prefix in selected]
