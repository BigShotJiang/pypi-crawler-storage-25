"""Word reorder perturbation.

Swaps adjacent words or phrases to test if word order
affects confidence. Preserves overall meaning as much as possible.
"""

from __future__ import annotations

import random
import re


def generate_reorder(
    text: str, num_variants: int = 3, *, rng: random.Random | None = None
) -> list[str]:
    """Generate variants by swapping adjacent words.

    Args:
        rng: Optional seeded Random instance for reproducibility.
             If None, uses the global random module.
    """
    _rng = rng if rng is not None else random
    words = text.split()
    if len(words) <= 2:
        return []

    variants = []
    seen = set()

    for _ in range(num_variants * 3):
        if len(variants) >= num_variants:
            break

        new_words = words.copy()
        # Pick a random position and swap with next word
        pos = _rng.randint(0, len(new_words) - 2)
        new_words[pos], new_words[pos + 1] = new_words[pos + 1], new_words[pos]

        variant = " ".join(new_words)
        if variant != text and variant not in seen:
            seen.add(variant)
            variants.append(variant)

    return variants


def generate_clause_reorder(
    text: str, num_variants: int = 3, *, rng: random.Random | None = None
) -> list[str]:
    """Reorder comma-separated clauses/phrases.

    Tests whether the model is sensitive to the ordering of
    logically parallel clauses — a purely structural perturbation.

    Args:
        rng: Optional seeded Random instance for reproducibility.
             If None, uses the global random module.
    """
    _rng = rng if rng is not None else random
    # Split on commas or semicolons, preserving trailing punctuation
    sentence_end = ""
    base = text
    if text and text[-1] in ".?!":
        sentence_end = text[-1]
        base = text[:-1]

    clauses = [c.strip() for c in re.split(r"[,;]", base)]
    if len(clauses) <= 1:
        return []

    variants = []
    seen = {text}

    for _ in range(num_variants * 5):
        if len(variants) >= num_variants:
            break
        shuffled = clauses.copy()
        _rng.shuffle(shuffled)
        variant = ", ".join(shuffled) + sentence_end
        if variant not in seen:
            seen.add(variant)
            variants.append(variant)

    return variants


# Question restructure patterns
_Q_WHAT_IS = re.compile(r"^What is ([^?]+)\?$", re.IGNORECASE)
_Q_IS_X_Y = re.compile(r"^Is ([^?]+?) ([^?]+)\?$", re.IGNORECASE)
_Q_CAN_X = re.compile(r"^Can ([^?]+?) ([^?]+)\?$", re.IGNORECASE)
_Q_DOES_X = re.compile(r"^Does ([^?]+?) ([^?]+)\?$", re.IGNORECASE)


def generate_question_restructure(text: str) -> list[str]:
    """Restructure question syntax while preserving semantic content.

    Examples:
      "What is X?" -> "X is what?"
      "Is X Y?"    -> "Y, is X?"
    """
    variants: list[str] = []

    m = _Q_WHAT_IS.match(text)
    if m:
        subject = m.group(1)
        variants.append(f"{subject} is what?")
        variants.append(f"Tell me what {subject} is.")
        return variants

    m = _Q_IS_X_Y.match(text)
    if m:
        subj, pred = m.group(1), m.group(2)
        variants.append(f"{pred.capitalize()}, is {subj}?")
        variants.append(f"{subj} — is it {pred}?")
        return variants

    m = _Q_CAN_X.match(text)
    if m:
        subj, pred = m.group(1), m.group(2)
        variants.append(f"Is it possible for {subj} to {pred}?")
        return variants

    m = _Q_DOES_X.match(text)
    if m:
        subj, pred = m.group(1), m.group(2)
        variants.append(f"Is it true that {subj} {pred}?")
        return variants

    return variants


def generate_emphasis_shift(text: str, num_variants: int = 3) -> list[str]:
    """Move important words to sentence-initial or sentence-final positions.

    Tests whether emphasis placement (topicalization / focus-fronting)
    affects model confidence. High-fragility models treat "Paris is the
    capital of France" differently from "The capital of France is Paris."
    """
    words = text.split()
    if len(words) <= 3:
        return []

    variants: list[str] = []
    seen = {text}

    # Strategy 1: move last content word(s) to front
    # skip trailing punctuation token
    stripped = words.copy()
    punct = ""
    if stripped[-1] and stripped[-1][-1] in ".?!,":
        punct = stripped[-1][-1]
        stripped[-1] = stripped[-1][:-1]

    # front-focus: last 1-2 words moved to start
    for n in (1, 2):
        if n >= len(stripped):
            continue
        moved = stripped[-n:] + stripped[:-n]
        candidate = " ".join(moved) + punct
        if candidate not in seen:
            seen.add(candidate)
            variants.append(candidate)
            if len(variants) >= num_variants:
                return variants

    # Strategy 2: move first content word(s) to end
    for n in (1, 2):
        if n >= len(stripped):
            continue
        moved = stripped[n:] + stripped[:n]
        candidate = " ".join(moved) + punct
        if candidate not in seen:
            seen.add(candidate)
            variants.append(candidate)
            if len(variants) >= num_variants:
                return variants

    return variants


# Japanese word-order alternations (SOV → OSV etc.)
_JA_SOV = re.compile(r"^(.+)は(.+)を(.+)$")  # S-wa O-wo V


def generate_japanese_reorder(text: str, num_variants: int = 2) -> list[str]:
    """Generate Japanese word-order variants (SOV ↔ OSV etc.).

    Japanese allows relatively free constituent order; scrambling
    tests whether the model's confidence is sensitive to topic/focus
    marking independent of core semantics.
    """
    # Only attempt when text looks Japanese
    from yuragi.utils import is_japanese

    if not is_japanese(text):
        return []

    variants: list[str] = []

    m = _JA_SOV.match(text)
    if m:
        s_part = m.group(1)  # topic (subject without は)
        o_part = m.group(2)  # object (without を)
        v_part = m.group(3)  # verb phrase

        # OSV: object fronted
        osv = f"{o_part}は{s_part}が{v_part}"
        if osv != text:
            variants.append(osv)
        # OVS-ish: topic at end
        ovs = f"{o_part}を{v_part}、{s_part}は"
        if ovs != text and len(variants) < num_variants:
            variants.append(ovs)

    return variants
