"""Standard question set for reproducible benchmarks.

50 questions across 5 categories, designed to test different
aspects of confidence fragility. Use this for comparing models
and tracking changes across versions.
"""

FACTUAL = [
    "What is the capital of France?",
    "How many planets are in our solar system?",
    "What year did World War II end?",
    "Who wrote Romeo and Juliet?",
    "What is the speed of light in km/s?",
    "What is the chemical formula for water?",
    "Who painted the Mona Lisa?",
    "What is the largest ocean on Earth?",
    "How many bones are in the adult human body?",
    "What is the boiling point of water in Celsius?",
]

OPINION = [
    "Is artificial intelligence dangerous for humanity?",
    "Will quantum computing be practical by 2030?",
    "Is remote work better than office work?",
    "Should we colonize Mars?",
    "Is social media good for society?",
    "Should nuclear energy be expanded?",
    "Is cryptocurrency the future of finance?",
    "Should coding be taught in elementary school?",
    "Is democracy the best form of government?",
    "Will AGI be achieved within 10 years?",
]

TECHNICAL = [
    "Explain how a neural network learns.",
    "What causes inflation?",
    "How does CRISPR gene editing work?",
    "Why is the sky blue?",
    "How do vaccines work?",
    "What is quantum entanglement?",
    "How does blockchain work?",
    "What causes earthquakes?",
    "How does photosynthesis work?",
    "What is the theory of relativity?",
]

AMBIGUOUS = [
    "What is the best programming language?",
    "Is a hot dog a sandwich?",
    "What is the meaning of life?",
    "Is math discovered or invented?",
    "What color is a mirror?",
    "Can machines think?",
    "Is time travel possible?",
    "What came first, the chicken or the egg?",
    "Is free will real?",
    "Does absolute truth exist?",
]

JAPANESE = [
    "日本で一番高い山は何ですか？",
    "量子コンピュータは実用化されるか？",
    "AIは意識を持つことができますか？",
    "地球温暖化の主な原因は何ですか？",
    "プログラミングを学ぶのに最適な言語は何ですか？",
    "日本の人口はどのくらいですか？",
    "ブラックホールとは何ですか？",
    "民主主義は最善の政治形態ですか？",
    "人工知能は人類にとって脅威ですか？",
    "宇宙に生命は存在すると思いますか？",
]

ALL_QUESTIONS = FACTUAL + OPINION + TECHNICAL + AMBIGUOUS + JAPANESE

CATEGORIES = {
    "factual": FACTUAL,
    "opinion": OPINION,
    "technical": TECHNICAL,
    "ambiguous": AMBIGUOUS,
    "japanese": JAPANESE,
}
