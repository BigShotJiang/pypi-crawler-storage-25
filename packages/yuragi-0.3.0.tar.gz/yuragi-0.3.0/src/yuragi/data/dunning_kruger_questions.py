"""Default question sets for the Dunning-Kruger experiment.

Three difficulty tiers, 5 questions each.  All questions use
general-knowledge or basic-science topics — no sensitive content.
"""

from __future__ import annotations

EASY_QUESTIONS: list[dict[str, str]] = [
    {"question": "What is 2 + 2?", "answer": "4"},
    {"question": "What is the capital of Japan?", "answer": "Tokyo"},
    {"question": "How many days are in a week?", "answer": "7"},
    {"question": "What color is the sky on a clear day?", "answer": "blue"},
    {"question": "What is the largest planet in our solar system?", "answer": "Jupiter"},
]

MEDIUM_QUESTIONS: list[dict[str, str]] = [
    {"question": "What is the square root of 144?", "answer": "12"},
    {"question": "In what year did the French Revolution begin?", "answer": "1789"},
    {"question": "What is the chemical symbol for gold?", "answer": "Au"},
    {"question": "How many sides does a hexagon have?", "answer": "6"},
    {"question": "What is the powerhouse of the cell?", "answer": "mitochondria"},
]

HARD_QUESTIONS: list[dict[str, str]] = [
    {
        "question": "In what year did the philosopher Gottfried Wilhelm Leibniz die?",
        "answer": "1716",
    },
    {
        "question": "What is the Chandrasekhar limit in solar masses?",
        "answer": "1.4",
    },
    {
        "question": "Which programming language introduced the concept of coroutines in 1958?",
        "answer": "SIMULA",
    },
    {
        "question": "What is the rarest naturally occurring stable element on Earth?",
        "answer": "astatine",
    },
    {
        "question": "In linguistics, what term describes a word that is its own antonym?",
        "answer": "contronym",
    },
]
