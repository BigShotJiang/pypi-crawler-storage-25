"""Multi-model fragility heatmap visualization.

Generates a model x prompt heatmap of fragility scores using
matplotlib and seaborn.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from yuragi.exceptions import MissingDependencyError

if TYPE_CHECKING:
    pass


def plot_multi_model_heatmap(
    scores: dict[str, dict[str, float]],
    save_path: str | None = None,
) -> None:
    """Plot a models x prompts heatmap of fragility scores.

    Args:
        scores: {model_name: {prompt_label: fragility_score}}
        save_path: If provided, save PNG to this path instead of displaying.
    """
    try:
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError as err:
        raise MissingDependencyError(
            "matplotlib is required. Install with: pip install yuragi[viz]"
        ) from err

    models = list(scores.keys())
    prompts = list({p for m in scores.values() for p in m})
    prompts.sort()

    matrix = np.full((len(models), len(prompts)), fill_value=float("nan"))
    for i, model in enumerate(models):
        for j, prompt in enumerate(prompts):
            if prompt in scores[model]:
                matrix[i, j] = scores[model][prompt]

    fig, ax = plt.subplots(figsize=(max(6, len(prompts) * 1.5), max(4, len(models) * 0.8)))

    try:
        import seaborn as sns

        # v0.3.0: fragility_score = mean(|ΔC|) concentrates in [0, 0.5];
        # capping vmax at 0.5 improves perceptual resolution.
        sns.heatmap(
            matrix,
            annot=True,
            fmt=".2f",
            xticklabels=[p[:30] for p in prompts],
            yticklabels=models,
            cmap="viridis_r",
            vmin=0.0,
            vmax=0.5,
            ax=ax,
            cbar_kws={"label": "Fragility Score (v0.3.0 mean|ΔC|, max=0.5)"},
        )
    except ImportError:
        im = ax.imshow(matrix, cmap="viridis_r", vmin=0.0, vmax=0.5, aspect="auto")
        plt.colorbar(im, ax=ax, label="Fragility Score")
        ax.set_xticks(range(len(prompts)))
        ax.set_xticklabels([p[:30] for p in prompts], rotation=45, ha="right")
        ax.set_yticks(range(len(models)))
        ax.set_yticklabels(models)
        for i in range(len(models)):
            for j in range(len(prompts)):
                if matrix[i, j] == matrix[i, j]:  # not NaN
                    ax.text(j, i, f"{matrix[i, j]:.2f}", ha="center", va="center", fontsize=8)

    ax.set_title("Multi-Model Fragility Heatmap")
    ax.set_xlabel("Prompt")
    ax.set_ylabel("Model")
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
    else:
        plt.show()
