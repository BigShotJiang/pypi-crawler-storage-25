"""Cross-model comparison radar chart.

Plots 5-axis radar chart comparing fragility profiles across models.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from yuragi.exceptions import MissingDependencyError

if TYPE_CHECKING:
    from yuragi.core import ScanResult


_AXES = [
    "Fragility Score",
    "Dissociation Rate",
    "Confidence Range",
    "Max Drop",
    "Recovery Elasticity",
]


def _compute_radar_values(result: ScanResult) -> list[float]:
    """Compute normalized [0, 1] values for each radar axis."""
    from yuragi.analysis.fragility_profile import build_profile

    profile = build_profile(result)

    fragility = result.fragility_score  # already 0-1
    dissoc_rate = result.dissociation_rate  # already 0-1
    conf_range = min(1.0, result.confidence_range)  # already 0-1 (max 1)
    max_drop = min(1.0, abs(result.max_confidence_drop))  # 0-1
    recovery = profile.recovery_elasticity  # already 0-1

    return [fragility, dissoc_rate, conf_range, max_drop, recovery]


def plot_model_comparison(
    results: dict[str, ScanResult],
    save_path: str | None = None,
) -> None:
    """Generate a radar chart comparing multiple models across 5 fragility axes.

    Args:
        results: Mapping of model_name -> ScanResult
        save_path: If provided, save PNG to this path instead of displaying
    """
    try:
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError as err:
        raise MissingDependencyError(
            "matplotlib is required for comparison visualization. "
            "Install with: pip install yuragi[viz]"
        ) from err

    if not results:
        return

    n_axes = len(_AXES)
    angles = np.linspace(0, 2 * np.pi, n_axes, endpoint=False).tolist()
    # Close the polygon
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw={"projection": "polar"})
    ax.set_facecolor("#161b22")
    fig.patch.set_facecolor("#0d1117")

    # Color palette
    palette = [
        "#58a6ff", "#2ecc71", "#e74c3c", "#f39c12",
        "#9b59b6", "#1abc9c", "#e67e22", "#e91e63",
    ]

    for idx, (model_name, result) in enumerate(results.items()):
        values = _compute_radar_values(result)
        values += values[:1]  # close polygon
        color = palette[idx % len(palette)]
        ax.plot(angles, values, color=color, linewidth=2, label=model_name)
        ax.fill(angles, values, color=color, alpha=0.12)

    # Grid and labels
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(_AXES, fontsize=10, color="#c9d1d9")
    ax.set_ylim(0, 1)
    ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_yticklabels(
        ["0.2", "0.4", "0.6", "0.8", "1.0"],
        fontsize=7,
        color="#8b949e",
    )
    ax.tick_params(colors="#c9d1d9")
    ax.spines["polar"].set_color("#30363d")
    ax.grid(color="#30363d", linewidth=0.6)

    ax.set_title(
        "yuragi: Cross-Model Fragility Comparison",
        color="#c9d1d9",
        fontsize=13,
        pad=20,
    )

    legend = ax.legend(
        loc="upper right",
        bbox_to_anchor=(1.3, 1.15),
        fontsize=9,
        framealpha=0.2,
        labelcolor="#c9d1d9",
    )
    legend.get_frame().set_edgecolor("#30363d")

    # Axis description annotations
    ax.annotate(
        "outer = worse",
        xy=(0, 0),
        xytext=(0.02, 0.02),
        xycoords="axes fraction",
        fontsize=7,
        color="#484f58",
    )

    plt.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
        plt.close(fig)
    else:
        plt.show()
