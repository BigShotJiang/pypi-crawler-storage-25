"""Confidence trajectory line chart.

Shows how confidence evolves over a sequence of prompts,
highlighting drop points.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from yuragi.exceptions import MissingDependencyError

if TYPE_CHECKING:
    from yuragi.analysis.trajectory import ConfidenceTrajectory


def plot_trajectory(
    trajectory: ConfidenceTrajectory,
    save_path: str | None = None,
) -> None:
    """Plot confidence over a trajectory sequence.

    Drop points (step-to-step decrease > 0.05) are highlighted with red markers.

    Args:
        trajectory: A ConfidenceTrajectory from track_trajectory()
        save_path: If provided, save PNG to this path instead of displaying
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError as err:
        raise MissingDependencyError(
            "matplotlib is required for trajectory visualization. "
            "Install with: pip install yuragi[viz]"
        ) from err

    if not trajectory.points:
        return

    steps = [p.step for p in trajectory.points]
    confs = [p.confidence for p in trajectory.points]

    # Identify drop points: confidence decreases > 0.05 vs previous step
    drop_steps: list[int] = []
    drop_confs: list[float] = []
    for i in range(1, len(trajectory.points)):
        delta = trajectory.points[i].confidence - trajectory.points[i - 1].confidence
        if delta < -0.05:
            drop_steps.append(trajectory.points[i].step)
            drop_confs.append(trajectory.points[i].confidence)

    fig, ax = plt.subplots(figsize=(10, 5))
    fig.patch.set_facecolor("#0d1117")
    ax.set_facecolor("#161b22")

    # Main confidence line
    ax.plot(steps, confs, color="#58a6ff", linewidth=2, marker="o", markersize=5, label="confidence")

    # Shade under line
    ax.fill_between(steps, confs, alpha=0.08, color="#58a6ff")

    # Drop markers
    if drop_steps:
        ax.scatter(
            drop_steps,
            drop_confs,
            color="#e74c3c",
            s=80,
            zorder=5,
            label="drop point",
            marker="v",
        )

    # Reference lines
    ax.axhline(y=0.7, color="#2ecc71", linewidth=0.7, linestyle="--", alpha=0.6, label="high conf (0.7)")
    ax.axhline(y=0.4, color="#e74c3c", linewidth=0.7, linestyle="--", alpha=0.6, label="low conf (0.4)")

    # X-axis labels from prompt text (truncated)
    labels = [f"[{p.step}] {p.prompt[:30]}{'...' if len(p.prompt) > 30 else ''}" for p in trajectory.points]
    ax.set_xticks(steps)
    ax.set_xticklabels(labels, rotation=30, ha="right", fontsize=7, color="#c9d1d9")

    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Confidence", color="#c9d1d9", fontsize=10)
    ax.set_xlabel("Step", color="#c9d1d9", fontsize=10)
    ax.tick_params(colors="#8b949e")
    ax.spines[:].set_color("#30363d")

    trend = trajectory.trend
    ax.set_title(
        f"yuragi: Confidence Trajectory | Model: {trajectory.model} | Trend: {trend}",
        color="#c9d1d9",
        fontsize=11,
    )

    legend = ax.legend(fontsize=8, framealpha=0.2, labelcolor="#c9d1d9")
    legend.get_frame().set_edgecolor("#30363d")

    # Summary annotation
    summary = (
        f"max drop: {trajectory.max_drop:+.2f}  |  "
        f"recovery: {trajectory.recovery_rate:.0%}"
    )
    ax.annotate(
        summary,
        xy=(0.99, 0.02),
        xycoords="axes fraction",
        ha="right",
        fontsize=8,
        color="#8b949e",
    )

    plt.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
        plt.close(fig)
    else:
        plt.show()
