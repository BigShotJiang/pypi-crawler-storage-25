"""Sensitivity heatmap visualization.

Shows which perturbation types cause the most confidence shift,
broken down by individual mutations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from yuragi.exceptions import MissingDependencyError

if TYPE_CHECKING:
    from yuragi.core import ScanResult


def plot_confidence_heatmap(result: ScanResult, save_path: str | None = None) -> None:
    """Generate a true 2D heatmap: perturbation_type x variant, colored by confidence.

    Args:
        result: A completed ScanResult
        save_path: If provided, save to file instead of displaying
    """
    try:
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError as err:
        raise MissingDependencyError(
            "matplotlib is required for visualization. "
            "Install with: pip install yuragi[viz]"
        ) from err

    if not result.perturbation_results:
        return

    # Group by perturbation type
    type_groups: dict[str, list[float]] = {}
    type_labels: dict[str, list[str]] = {}
    for r in result.perturbation_results:
        pt = r.perturbation_type
        if pt not in type_groups:
            type_groups[pt] = []
            type_labels[pt] = []
        type_groups[pt].append(r.perturbed_response.confidence)
        type_labels[pt].append(r.perturbed_prompt[:20])

    types = sorted(type_groups.keys())
    max_variants = max(len(v) for v in type_groups.values())

    # Build matrix: rows=types, cols=variant index
    matrix = np.full((len(types), max_variants), np.nan)
    cell_texts: list[list[str]] = []
    for row_i, pt in enumerate(types):
        row_texts: list[str] = []
        for col_i, conf in enumerate(type_groups[pt]):
            matrix[row_i, col_i] = conf
            row_texts.append(f"{conf:.2f}")
        # pad missing cells
        for _ in range(max_variants - len(type_groups[pt])):
            row_texts.append("")
        cell_texts.append(row_texts)

    fig, ax = plt.subplots(figsize=(max(6, max_variants * 1.2), max(3, len(types) * 0.8 + 1)))
    fig.patch.set_facecolor("#0d1117")
    ax.set_facecolor("#161b22")

    im = ax.imshow(matrix, aspect="auto", cmap="viridis", vmin=0, vmax=1)

    # Colorbar
    cbar = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02)
    cbar.set_label("Confidence", color="#c9d1d9", fontsize=9)
    cbar.ax.tick_params(colors="#8b949e")

    # Axes
    ax.set_yticks(range(len(types)))
    ax.set_yticklabels(types, fontsize=9, color="#c9d1d9")
    ax.set_xticks(range(max_variants))
    ax.set_xticklabels([f"v{i + 1}" for i in range(max_variants)], fontsize=8, color="#c9d1d9")
    ax.tick_params(colors="#8b949e")
    for spine in ax.spines.values():
        spine.set_color("#30363d")

    # Cell annotations
    for row_i in range(len(types)):
        for col_i in range(max_variants):
            text = cell_texts[row_i][col_i]
            if text:
                conf_val = matrix[row_i, col_i]
                txt_color = "#000000" if 0.3 < conf_val < 0.8 else "#ffffff"
                ax.text(
                    col_i,
                    row_i,
                    text,
                    ha="center",
                    va="center",
                    fontsize=7,
                    color=txt_color,
                )

    # Baseline reference line annotation
    ax.annotate(
        f"baseline: {result.baseline.confidence:.2f}",
        xy=(1.0, -0.08),
        xycoords="axes fraction",
        ha="right",
        fontsize=8,
        color="#8b949e",
    )

    ax.set_title(
        f"yuragi: Confidence Heatmap | {result.model} | "
        f'"{result.prompt[:50]}{"..." if len(result.prompt) > 50 else ""}"',
        color="#c9d1d9",
        fontsize=10,
        pad=10,
    )

    plt.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
        plt.close(fig)
    else:
        plt.show()


def plot_sensitivity_heatmap(result: ScanResult, save_path: str | None = None) -> None:
    """Generate a heatmap showing confidence sensitivity by perturbation type.

    Args:
        result: A completed ScanResult
        save_path: If provided, save to file instead of displaying
    """
    try:
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError as err:
        raise MissingDependencyError(
            "matplotlib is required for visualization. "
            "Install with: pip install yuragi[viz]"
        ) from err

    # Group results by perturbation type
    types = []
    deltas = []
    labels = []
    colors = []

    for r in sorted(result.perturbation_results, key=lambda x: x.confidence_delta):
        types.append(r.perturbation_type)
        deltas.append(r.confidence_delta)
        # Truncate label
        diff = r.perturbed_prompt[:40]
        labels.append(diff)

        if r.is_dissociated:
            colors.append("#9b59b6")  # Purple for dissociated
        elif r.confidence_delta < -0.2:
            colors.append("#e74c3c")  # Red for big drop
        elif r.confidence_delta < -0.05:
            colors.append("#e67e22")  # Orange for moderate drop
        elif r.confidence_delta > 0.05:
            colors.append("#2ecc71")  # Green for boost
        else:
            colors.append("#95a5a6")  # Gray for stable

    if not deltas:
        return

    fig, ax = plt.subplots(figsize=(12, max(4, len(deltas) * 0.4)))

    y_pos = np.arange(len(deltas))
    bars = ax.barh(y_pos, deltas, color=colors, edgecolor="white", linewidth=0.5)

    ax.set_yticks(y_pos)
    ax.set_yticklabels(
        [f"[{t}] {label}" for t, label in zip(types, labels, strict=False)],
        fontsize=8,
        fontfamily="monospace",
    )
    ax.set_xlabel("Confidence Delta")
    ax.set_title(
        f"yuragi: Confidence Fragility Map\n"
        f'"{result.prompt[:60]}..." | Model: {result.model} | '
        f"Fragility: {result.fragility_score:.2f} ({result.fragility_label()})",
        fontsize=11,
    )
    ax.axvline(x=0, color="black", linewidth=0.8)
    ax.axvline(x=-0.1, color="red", linewidth=0.5, linestyle="--", alpha=0.5)
    ax.axvline(x=0.1, color="green", linewidth=0.5, linestyle="--", alpha=0.5)

    # Add value labels
    for bar, delta in zip(bars, deltas, strict=False):
        x = bar.get_width()
        ax.text(
            x + (0.01 if x >= 0 else -0.01),
            bar.get_y() + bar.get_height() / 2,
            f"{delta:+.2f}",
            va="center",
            ha="left" if x >= 0 else "right",
            fontsize=7,
        )

    # Legend
    from matplotlib.patches import Patch

    legend_elements = [
        Patch(facecolor="#e74c3c", label="Confidence collapse (< -0.2)"),
        Patch(facecolor="#e67e22", label="Moderate drop"),
        Patch(facecolor="#95a5a6", label="Stable"),
        Patch(facecolor="#2ecc71", label="Confidence boost"),
        Patch(facecolor="#9b59b6", label="Dissociated (answer same, confidence shifted)"),
    ]
    ax.legend(handles=legend_elements, loc="lower right", fontsize=7)

    plt.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
    else:
        plt.show()
