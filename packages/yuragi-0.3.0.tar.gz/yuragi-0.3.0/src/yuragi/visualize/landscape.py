"""3D confidence landscape visualization using Plotly.

Plots confidence as a terrain — valleys are vulnerable points,
ridges are robust regions.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from yuragi.exceptions import MissingDependencyError

if TYPE_CHECKING:
    from yuragi.core import ScanResult


def plot_confidence_landscape(result: ScanResult, save_path: str | None = None) -> None:
    """Generate a 3D confidence landscape.

    X: perturbation_type (categorical)
    Y: edit_distance from original prompt
    Z: confidence (0-1)

    Args:
        result: A completed ScanResult
        save_path: If provided, save HTML to this path instead of displaying
    """
    try:
        import plotly.graph_objects as go
    except ImportError as err:
        raise MissingDependencyError(
            "plotly is required for landscape visualization. "
            "Install with: pip install yuragi[viz]"
        ) from err

    from yuragi.analysis.fragility_profile import _edit_distance

    if not result.perturbation_results:
        return

    # Collect data points
    types_list: list[str] = []
    edit_distances: list[float] = []
    confidences: list[float] = []
    hover_texts: list[str] = []

    unique_types = sorted({r.perturbation_type for r in result.perturbation_results})
    type_index = {t: i for i, t in enumerate(unique_types)}

    # Baseline point
    types_list.append("baseline")
    edit_distances.append(0.0)
    confidences.append(result.baseline.confidence)
    hover_texts.append(
        f"baseline<br>confidence: {result.baseline.confidence:.3f}<br>"
        f"edit_distance: 0<br>{result.prompt[:60]}"
    )

    for r in result.perturbation_results:
        ed = float(_edit_distance(result.prompt, r.perturbed_prompt))
        conf = r.perturbed_response.confidence
        types_list.append(r.perturbation_type)
        edit_distances.append(ed)
        confidences.append(conf)
        hover_texts.append(
            f"{r.perturbation_type}<br>"
            f"confidence: {conf:.3f}<br>"
            f"delta: {r.confidence_delta:+.3f}<br>"
            f"edit_distance: {ed:.0f}<br>"
            f"{r.perturbed_prompt[:60]}"
        )

    # Color by confidence: red (low) → green (high)
    marker_colors = confidences

    # Map perturbation type to numeric x for 3D scatter
    x_numeric = [
        type_index.get(t, -1) + 0.5 if t != "baseline" else -0.5
        for t in types_list
    ]

    scatter = go.Scatter3d(
        x=x_numeric,
        y=edit_distances,
        z=confidences,
        mode="markers",
        marker={
            "size": 6,
            "color": marker_colors,
            "colorscale": "Viridis",
            "cmin": 0.0,
            "cmax": 1.0,
            "colorbar": {"title": "Confidence"},
            "opacity": 0.85,
        },
        text=hover_texts,
        hovertemplate="%{text}<extra></extra>",
        name="perturbations",
    )

    # Baseline marker (distinct)
    baseline_marker = go.Scatter3d(
        x=[-0.5],
        y=[0.0],
        z=[result.baseline.confidence],
        mode="markers",
        marker={"size": 10, "color": "#58a6ff", "symbol": "diamond"},
        name="baseline",
        text=[f"BASELINE<br>confidence: {result.baseline.confidence:.3f}"],
        hovertemplate="%{text}<extra></extra>",
    )

    tick_vals = list(range(len(unique_types)))
    tick_text = unique_types

    layout = go.Layout(
        title={
            "text": (
                f"yuragi: Confidence Landscape<br>"
                f'<sup>"{result.prompt[:70]}" | {result.model} | '
                f"Fragility: {result.fragility_score:.2f}</sup>"
            ),
            "x": 0.5,
        },
        scene={
            "xaxis": {
                "title": "Perturbation Type",
                "tickvals": tick_vals,
                "ticktext": tick_text,
            },
            "yaxis": {"title": "Edit Distance"},
            "zaxis": {"title": "Confidence", "range": [0, 1]},
            "camera": {"eye": {"x": 1.6, "y": 1.6, "z": 1.0}},
        },
        paper_bgcolor="#0d1117",
        plot_bgcolor="#0d1117",
        font={"color": "#c9d1d9"},
        margin={"l": 0, "r": 0, "t": 80, "b": 0},
        legend={"bgcolor": "rgba(0,0,0,0)"},
    )

    fig = go.Figure(data=[scatter, baseline_marker], layout=layout)

    if save_path:
        fig.write_html(save_path)
    else:
        fig.show()
