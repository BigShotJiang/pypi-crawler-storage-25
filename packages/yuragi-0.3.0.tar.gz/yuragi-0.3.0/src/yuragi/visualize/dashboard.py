"""Interactive HTML dashboard generator using Plotly.

Generates a self-contained single-file HTML dashboard with interactive charts.
No external server required — all JS is inlined via CDN.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING

from yuragi.utils import edit_distance as _edit_distance

if TYPE_CHECKING:
    from yuragi.core import ScanResult

_DASHBOARD_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>yuragi dashboard: {prompt_short}</title>
<script src="https://cdn.plot.ly/plotly-2.27.0.min.js"></script>
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
       background: #0d1117; color: #c9d1d9; padding: 2rem; line-height: 1.6; }}
.container {{ max-width: 1200px; margin: 0 auto; }}
h1 {{ color: #58a6ff; font-size: 1.8rem; margin-bottom: 0.5rem; }}
h2 {{ color: #8b949e; font-size: 1.1rem; margin-bottom: 1.5rem; font-weight: normal; }}
.card {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px;
         padding: 1.5rem; margin-bottom: 1.5rem; }}
.stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
               gap: 1rem; margin-bottom: 1.5rem; }}
.stat-card {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px;
              padding: 1.5rem; text-align: center; }}
.stat-value {{ font-size: 2.2rem; font-weight: bold; margin-bottom: 0.25rem; }}
.stat-label {{ font-size: 0.85rem; color: #8b949e; text-transform: uppercase;
               letter-spacing: 0.05em; }}
.stat-sub {{ font-size: 0.8rem; color: #6e7681; margin-top: 0.25rem; }}
.charts-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem; }}
.chart-card {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px;
               padding: 1.5rem; }}
.chart-card h3 {{ color: #58a6ff; margin-bottom: 1rem; font-size: 1rem; }}
.chart-full {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px;
               padding: 1.5rem; margin-bottom: 1.5rem; }}
.chart-full h3 {{ color: #58a6ff; margin-bottom: 1rem; font-size: 1rem; }}
.prompt-box {{ font-family: monospace; background: #1c2128; padding: 0.75rem 1rem;
               border-radius: 4px; margin: 0.5rem 0; word-wrap: break-word;
               color: #e6edf3; font-size: 0.9rem; }}
.meta {{ color: #8b949e; font-size: 0.85rem; }}
.footer {{ text-align: center; color: #484f58; font-size: 0.8rem; margin-top: 2rem; }}
.footer a {{ color: #58a6ff; text-decoration: none; }}
@media (max-width: 768px) {{
  .charts-grid {{ grid-template-columns: 1fr; }}
}}
</style>
</head>
<body>
<div class="container">
  <h1>&#x63FA;&#x3089;&#x304E; yuragi dashboard</h1>
  <h2 class="meta">Model: {model} &nbsp;|&nbsp; Method: {method} &nbsp;|&nbsp; Duration: {duration}s &nbsp;|&nbsp; API calls: {api_calls}</h2>

  <div class="card">
    <div class="meta">PROMPT</div>
    <div class="prompt-box">{prompt}</div>
  </div>

  <!-- Summary Stats Cards -->
  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-value" style="color: {fragility_color};">{fragility_score}</div>
      <div class="stat-label">Fragility Score</div>
      <div class="stat-sub">{fragility_label}</div>
    </div>
    <div class="stat-card">
      <div class="stat-value" style="color: #9b59b6;">{cci}</div>
      <div class="stat-label">CCI</div>
      <div class="stat-sub">Catastrophic Collapse Index</div>
    </div>
    <div class="stat-card">
      <div class="stat-value" style="color: #2ecc71;">{re}</div>
      <div class="stat-label">RE</div>
      <div class="stat-sub">Recovery Elasticity</div>
    </div>
    <div class="stat-card">
      <div class="stat-value" style="color: #f39c12;">{nls}</div>
      <div class="stat-label">NLS</div>
      <div class="stat-sub">Non-Linearity Score</div>
    </div>
    <div class="stat-card">
      <div class="stat-value" style="color: #e74c3c;">{dissoc_rate}</div>
      <div class="stat-label">Dissociation Rate</div>
      <div class="stat-sub">Same answer, shifted confidence</div>
    </div>
    <div class="stat-card">
      <div class="stat-value" style="color: #58a6ff;">{conf_range}</div>
      <div class="stat-label">Confidence Range</div>
      <div class="stat-sub">Max spread across perturbations</div>
    </div>
    <div class="stat-card">
      <div class="stat-value" style="color: #e74c3c;">{fragility_max}</div>
      <div class="stat-label">Worst Perturbation</div>
      <div class="stat-sub">max |&#x0394;C| (Definition 1.1c)</div>
    </div>
    <div class="stat-card">
      <div class="stat-value" style="color: #f39c12;">{fragility_exceed}</div>
      <div class="stat-label">Exceedance Rate</div>
      <div class="stat-sub">Fraction above noise floor &#x03C4;</div>
    </div>
    <div class="stat-card">
      <div class="stat-value" style="color: #8b949e;">{fragility_ci}</div>
      <div class="stat-label">95% CI (Fragility)</div>
      <div class="stat-sub">Percentile bootstrap; n&#x2265;5 required</div>
    </div>
  </div>

  <!-- Confidence Bar Chart + Radar Chart -->
  <div class="charts-grid">
    <div class="chart-card">
      <h3>Confidence by Perturbation</h3>
      <div id="chart-bar"></div>
    </div>
    <div class="chart-card">
      <h3>Fragility Radar by Type</h3>
      <div id="chart-radar"></div>
    </div>
  </div>

  <!-- Scatter: Confidence vs Edit Distance -->
  <div class="chart-full">
    <h3>Confidence vs Edit Distance &nbsp;<span style="font-size:0.8rem;color:#8b949e;font-weight:normal;">(purple = dissociated)</span></h3>
    <div id="chart-scatter"></div>
  </div>

  <div class="footer">
    Generated by <a href="https://github.com/hinanohart/yuragi">yuragi</a> v{version}
    &mdash; LLM Confidence Fragility Analyzer
  </div>
</div>

<script>
var PLOTLY_LAYOUT_BASE = {{
  paper_bgcolor: "#161b22",
  plot_bgcolor: "#161b22",
  font: {{ color: "#c9d1d9", family: "-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif" }},
  margin: {{ t: 20, r: 20, b: 80, l: 60 }},
}};

var CONFIG = {{ displayModeBar: true, responsive: true }};

// --- Chart 1: Confidence Bar Chart ---
(function() {{
  var data = {bar_data};
  var layout = Object.assign({{}}, PLOTLY_LAYOUT_BASE, {{
    xaxis: {{ title: "Perturbation", tickangle: -30, color: "#8b949e" }},
    yaxis: {{ title: "Confidence", range: [0, 1.05], color: "#8b949e", gridcolor: "#21262d" }},
    showlegend: false,
    shapes: [{bar_baseline_shape}],
    annotations: [{bar_baseline_annotation}],
  }});
  Plotly.newPlot("chart-bar", data, layout, CONFIG);
}})();

// --- Chart 2: Fragility Radar Chart ---
(function() {{
  var data = {radar_data};
  var layout = Object.assign({{}}, PLOTLY_LAYOUT_BASE, {{
    polar: {{
      bgcolor: "#161b22",
      radialaxis: {{ visible: true, range: [0, 1], color: "#8b949e", gridcolor: "#30363d" }},
      angularaxis: {{ color: "#8b949e", gridcolor: "#30363d" }},
    }},
    showlegend: true,
    legend: {{ font: {{ color: "#c9d1d9" }} }},
    margin: {{ t: 20, r: 60, b: 20, l: 60 }},
  }});
  Plotly.newPlot("chart-radar", data, layout, CONFIG);
}})();

// --- Chart 3: Confidence vs Edit Distance Scatter ---
(function() {{
  var data = {scatter_data};
  var layout = Object.assign({{}}, PLOTLY_LAYOUT_BASE, {{
    xaxis: {{ title: "Edit Distance (chars)", color: "#8b949e", gridcolor: "#21262d" }},
    yaxis: {{ title: "Confidence", range: [0, 1.05], color: "#8b949e", gridcolor: "#21262d" }},
    showlegend: true,
    legend: {{ font: {{ color: "#c9d1d9" }} }},
    hovermode: "closest",
  }});
  Plotly.newPlot("chart-scatter", data, layout, CONFIG);
}})();
</script>
</body>
</html>"""




def _fragility_color(score: float) -> str:
    if score < 0.1:
        return "#2ecc71"
    elif score < 0.25:
        return "#27ae60"
    elif score < 0.5:
        return "#f39c12"
    elif score < 0.75:
        return "#e74c3c"
    else:
        return "#c0392b"


def _conf_color(conf: float) -> str:
    if conf >= 0.7:
        return "#2ecc71"
    elif conf >= 0.4:
        return "#f39c12"
    return "#e74c3c"


def _escape(text: str) -> str:
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _build_bar_data(result: ScanResult) -> tuple[str, str, str]:
    """Build Plotly bar chart data JSON for confidence by perturbation."""
    labels = []
    values = []
    colors = []
    texts = []

    for r in sorted(result.perturbation_results, key=lambda x: x.confidence_delta):
        short = r.perturbed_prompt[:40] + ("..." if len(r.perturbed_prompt) > 40 else "")
        labels.append(f"{r.perturbation_type}<br><span style='font-size:0.7rem'>{_escape(short)}</span>")
        conf = r.perturbed_response.confidence
        values.append(round(conf, 4))
        colors.append("#9b59b6" if r.is_dissociated else _conf_color(conf))
        delta = r.confidence_delta
        texts.append(f"Type: {r.perturbation_type}<br>Confidence: {conf:.3f}<br>Delta: {delta:+.3f}<br>Dissociated: {r.is_dissociated}")

    trace = {
        "type": "bar",
        "x": labels,
        "y": values,
        "marker": {"color": colors},
        "hovertext": texts,
        "hoverinfo": "text",
        "name": "Confidence",
    }

    baseline = result.baseline.confidence
    baseline_shape = {
        "type": "line",
        "xref": "paper",
        "yref": "y",
        "x0": 0,
        "x1": 1,
        "y0": baseline,
        "y1": baseline,
        "line": {"color": "#58a6ff", "width": 2, "dash": "dash"},
    }
    baseline_annotation = {
        "xref": "paper",
        "yref": "y",
        "x": 1.0,
        "y": baseline,
        "text": f"Baseline {baseline:.2f}",
        "showarrow": False,
        "font": {"color": "#58a6ff", "size": 11},
        "xanchor": "right",
    }

    return (
        json.dumps([trace]),
        json.dumps(baseline_shape),
        json.dumps(baseline_annotation),
    )


def _build_radar_data(result: ScanResult) -> str:
    """Build Plotly radar chart data JSON: mean |delta| per perturbation type."""
    type_deltas: dict[str, list[float]] = {}
    for r in result.perturbation_results:
        type_deltas.setdefault(r.perturbation_type, []).append(abs(r.confidence_delta))

    if not type_deltas:
        return json.dumps([{"type": "scatterpolar", "r": [], "theta": [], "fill": "toself"}])

    categories = sorted(type_deltas.keys())
    # Close the polygon
    values = [sum(type_deltas[t]) / len(type_deltas[t]) for t in categories]
    theta = [*categories, categories[0]]
    r_vals = [*values, values[0]]

    trace = {
        "type": "scatterpolar",
        "r": [round(v, 4) for v in r_vals],
        "theta": theta,
        "fill": "toself",
        "fillcolor": "rgba(155, 89, 182, 0.25)",
        "line": {"color": "#9b59b6", "width": 2},
        "name": "Mean |delta|",
    }
    return json.dumps([trace])


def _build_scatter_data(result: ScanResult) -> str:
    """Build Plotly scatter chart data JSON: confidence vs edit distance."""
    type_groups: dict[str, dict[str, list]] = {}

    for r in result.perturbation_results:
        ed = _edit_distance(result.prompt, r.perturbed_prompt)
        conf = r.perturbed_response.confidence
        short = r.perturbed_prompt[:60] + ("..." if len(r.perturbed_prompt) > 60 else "")
        hover = f"Type: {r.perturbation_type}<br>Edit dist: {ed}<br>Confidence: {conf:.3f}<br>{_escape(short)}"

        grp = "_dissociated" if r.is_dissociated else r.perturbation_type

        if grp not in type_groups:
            type_groups[grp] = {"x": [], "y": [], "text": [], "name": grp}
        type_groups[grp]["x"].append(ed)
        type_groups[grp]["y"].append(round(conf, 4))
        type_groups[grp]["text"].append(hover)

    traces = []
    color_map = {
        "typo": "#58a6ff",
        "synonym": "#2ecc71",
        "omit": "#f39c12",
        "reorder": "#e67e22",
        "tone": "#3498db",
        "paraphrase": "#1abc9c",
        "social": "#e74c3c",
        "_dissociated": "#9b59b6",
    }

    for grp, g in type_groups.items():
        display_name = "Dissociated" if grp == "_dissociated" else grp
        marker_color = color_map.get(grp, "#8b949e")
        marker_symbol = "diamond" if grp == "_dissociated" else "circle"
        marker_size = 12 if grp == "_dissociated" else 9
        traces.append({
            "type": "scatter",
            "mode": "markers",
            "x": g["x"],
            "y": g["y"],
            "hovertext": g["text"],
            "hoverinfo": "text",
            "name": display_name,
            "marker": {
                "color": marker_color,
                "size": marker_size,
                "symbol": marker_symbol,
                "line": {"width": 1, "color": "#0d1117"},
            },
        })

    if not traces:
        traces = [{"type": "scatter", "mode": "markers", "x": [], "y": [], "name": "no data"}]

    return json.dumps(traces)


def generate_dashboard(result: ScanResult, output_path: str) -> str:
    """Generate an interactive HTML dashboard from scan results.

    Args:
        result: Completed ScanResult
        output_path: Where to save the HTML file

    Returns:
        Path to the generated HTML file
    """
    from yuragi import __version__

    # Build chart data
    bar_data, bar_baseline_shape, bar_baseline_annotation = _build_bar_data(result)
    radar_data = _build_radar_data(result)
    scatter_data = _build_scatter_data(result)

    # Fragility profile metrics
    cci_str = "N/A"
    re_str = "N/A"
    nls_str = "N/A"
    try:
        from yuragi.analysis.fragility_profile import build_profile

        fp = build_profile(result)
        cci_str = f"{fp.catastrophic_collapse_index:.2f}"
        re_str = f"{fp.recovery_elasticity:.2f}"
        nls_str = f"{fp.non_linearity_score:.2f}"
    except Exception:
        pass

    score = result.fragility_score

    ci = result.fragility_ci_95()
    ci_str = f"[{ci[0]:.3f}, {ci[1]:.3f}]" if ci is not None else "n/a (n&lt;5)"

    html = _DASHBOARD_TEMPLATE.format(
        prompt=_escape(result.prompt),
        prompt_short=_escape(result.prompt[:50]),
        model=result.model,
        method=result.baseline.confidence_method,
        duration=f"{result.scan_duration_seconds:.1f}",
        api_calls=result.total_api_calls,
        fragility_score=f"{score:.2f}",
        fragility_label=result.fragility_label(),
        fragility_color=_fragility_color(score),
        cci=cci_str,
        re=re_str,
        nls=nls_str,
        dissoc_rate=f"{result.dissociation_rate:.0%}",
        conf_range=f"{result.confidence_range:.2f}",
        fragility_max=f"{result.fragility_max:.3f}",
        fragility_exceed=f"{result.fragility_exceed:.1%}",
        fragility_ci=ci_str,
        bar_data=bar_data,
        bar_baseline_shape=bar_baseline_shape,
        bar_baseline_annotation=bar_baseline_annotation,
        radar_data=radar_data,
        scatter_data=scatter_data,
        version=__version__,
    )

    Path(output_path).write_text(html, encoding="utf-8")
    return output_path
