"""Reliability Diagram for confidence calibration visualization.

Standard tool in calibration literature (Guo et al., 2017).
"""
from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from yuragi.exceptions import MissingDependencyError


def plot_reliability_diagram(
    confidences: Sequence[float],
    accuracies: Sequence[bool],
    *,
    n_bins: int = 10,
    title: str = "Reliability Diagram",
    show_ece: bool = True,
    save_path: str | None = None,
) -> Any:
    """Plot a reliability diagram for binary classification confidences.

    Args:
        confidences: Predicted confidences in [0, 1].
        accuracies: True/False outcomes (same length).
        n_bins: Number of confidence bins.
        title: Plot title.
        show_ece: Annotate ECE in the plot.
        save_path: If provided, save figure to this path.

    Returns:
        matplotlib Figure.
    """
    try:
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError as err:
        raise MissingDependencyError(
            "matplotlib is required. Install with: pip install yuragi[viz]"
        ) from err

    conf_arr = np.asarray(confidences, dtype=float)
    acc_arr = np.asarray(accuracies, dtype=float)

    bin_edges = np.linspace(0.0, 1.0, n_bins + 1)
    bin_mids = (bin_edges[:-1] + bin_edges[1:]) / 2.0
    bin_width = 1.0 / n_bins

    bin_accs = np.zeros(n_bins)
    bin_confs = np.zeros(n_bins)
    bin_counts = np.zeros(n_bins, dtype=int)

    for i in range(n_bins):
        lo, hi = bin_edges[i], bin_edges[i + 1]
        # Include upper edge in last bin
        if i == n_bins - 1:
            mask = (conf_arr >= lo) & (conf_arr <= hi)
        else:
            mask = (conf_arr >= lo) & (conf_arr < hi)
        if mask.sum() > 0:
            bin_accs[i] = acc_arr[mask].mean()
            bin_confs[i] = conf_arr[mask].mean()
            bin_counts[i] = mask.sum()

    ece = float(np.sum(bin_counts * np.abs(bin_accs - bin_confs)) / len(conf_arr)) if len(conf_arr) > 0 else 0.0

    fig, ax = plt.subplots(figsize=(6, 6))

    # Bars: actual accuracy per bin
    bar_colors = np.where(bin_accs >= bin_mids, "#4C72B0", "#DD8452")
    ax.bar(
        bin_mids,
        bin_accs,
        width=bin_width * 0.9,
        color=bar_colors,
        alpha=0.7,
        label="Accuracy",
    )

    # Perfect calibration diagonal
    ax.plot([0, 1], [0, 1], "k--", linewidth=1.5, label="Perfect calibration")

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_xlabel("Confidence")
    ax.set_ylabel("Accuracy")
    ax.set_title(title)
    ax.legend(loc="upper left")

    if show_ece:
        ax.annotate(
            f"ECE = {ece:.4f}",
            xy=(0.98, 0.04),
            xycoords="axes fraction",
            ha="right",
            va="bottom",
            fontsize=10,
            bbox={"boxstyle": "round,pad=0.3", "fc": "white", "ec": "gray", "alpha": 0.8},
        )

    fig.tight_layout()

    if save_path is not None:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
        plt.close(fig)

    return fig
