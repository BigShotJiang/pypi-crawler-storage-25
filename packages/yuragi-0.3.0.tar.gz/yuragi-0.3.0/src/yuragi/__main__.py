"""Allow running yuragi as `python -m yuragi`."""

import sys

from yuragi.cli import main

sys.exit(main())
