"""Shared CLI helper functions for display and text formatting."""

from __future__ import annotations

from rich.text import Text

from yuragi.core import ScanResult


def _confidence_bar(value: float, width: int = 25) -> Text:
    """Create a colored confidence bar."""
    filled = int(value * width)
    empty = width - filled

    if value >= 0.7:
        color = "green"
    elif value >= 0.4:
        color = "yellow"
    else:
        color = "red"

    bar = Text()
    bar.append("\u2588" * filled, style=color)
    bar.append("\u2591" * empty, style="dim")
    bar.append(f" {value:.2f}", style="bold " + color)
    return bar


def _delta_text(delta: float) -> Text:
    """Format a confidence delta with color and symbol."""
    if abs(delta) < 0.05:
        return Text(f"  {delta:+.2f}", style="dim")
    elif delta < -0.2:
        return Text(f"\u26a1\u26a1 {delta:+.2f}", style="bold red")
    elif delta < 0:
        return Text(f"\u26a1  {delta:+.2f}", style="red")
    elif delta > 0.2:
        return Text(f"\u2b06  {delta:+.2f}", style="bold green")
    else:
        return Text(f"\u2b06  {delta:+.2f}", style="green")


def _fragility_color(score: float) -> str:
    if score < 0.1:
        return "bold green"
    elif score < 0.25:
        return "green"
    elif score < 0.5:
        return "yellow"
    elif score < 0.75:
        return "red"
    else:
        return "bold red"


def _severity_color(severity: float) -> str:
    """Color for dissociation severity: higher = more purple."""
    if severity < 0.1:
        return "dim"
    elif severity < 0.3:
        return "blue"
    elif severity < 0.5:
        return "magenta"
    elif severity < 0.7:
        return "bold magenta"
    else:
        return "bold bright_magenta"


def _key_insight(result: ScanResult) -> str:
    """Generate a 1-2 sentence natural-language key insight."""
    dr = result.dissociation_rate
    drop = abs(result.max_confidence_drop)
    fs = result.fragility_score

    if fs >= 0.75:
        insight = (
            f"This model's confidence on this topic is [bold red]shattered[/bold red] — "
            f"{dr:.0%} of surface-level changes shift confidence without changing the answer. "
            f"The model [italic]knows[/italic] the answer but [italic]doubts itself[/italic] based on phrasing alone."
        )
    elif drop > 0.4 and dr > 0.3:
        insight = (
            f"A single phrasing change collapsed confidence by [red]{drop:.0%}[/red] "
            f"while the answer stayed identical. "
            f"This is textbook [bold]dissociation[/bold]: the model's certainty is decorative, not informational."
        )
    elif dr > 0.5:
        insight = (
            f"[bold]{dr:.0%}[/bold] of perturbations shifted confidence without changing the answer. "
            f"The model's stated confidence responds more to [italic]social context[/italic] than to factual accuracy."
        )
    elif fs < 0.1:
        insight = (
            "This prompt shows [bold green]steel-grade stability[/bold green]. "
            "Confidence barely moves across all perturbation types — a rare and trustworthy result."
        )
    else:
        insight = (
            f"Fragility score [cyan]{fs:.2f}[/cyan] — moderate sensitivity to phrasing. "
            f"The {drop:.0%} max confidence drop suggests this topic has [italic]linguistic vulnerabilities[/italic] worth monitoring."
        )
    return insight


def _find_removed_word(original: str, perturbed: str) -> str:
    """Find which word was removed."""
    orig_words = original.split()
    pert_words = perturbed.split()

    for i, word in enumerate(orig_words):
        test = orig_words[:i] + orig_words[i + 1 :]
        if test == pert_words:
            return word
    return ""


# Public aliases for backward compatibility with cli_helpers.py
def confidence_bar(value: float, width: int = 25) -> Text:
    return _confidence_bar(value, width)


def delta_text(delta: float) -> Text:
    return _delta_text(delta)


def fragility_color(score: float) -> str:
    return _fragility_color(score)


def severity_color(severity: float) -> str:
    return _severity_color(severity)


def find_removed_word(original: str, perturbed: str) -> str:
    return _find_removed_word(original, perturbed)


def key_insight(result) -> str:
    """Generate a natural language key insight from scan results."""
    if not result.perturbation_results:
        return "No perturbations tested."

    weakest = result.weakest_perturbation
    if weakest and abs(weakest.confidence_delta) > 0.3:
        pct = abs(weakest.confidence_delta) * 100
        if not weakest.answer_changed:
            return (
                f"A single phrasing change collapsed confidence by {pct:.0f}% "
                f"while the answer stayed identical. This is textbook dissociation: "
                f"the model's certainty is decorative, not informational."
            )
        else:
            return (
                f"A single phrasing change shifted confidence by {pct:.0f}% "
                f"and changed the answer. The model's reasoning is fragile "
                f"to surface-level prompt variations."
            )

    if result.dissociation_rate > 0.3:
        return (
            f"{result.dissociation_rate:.0%} of perturbations changed confidence "
            f"without changing the answer. The model's confidence on this topic "
            f"is unreliable."
        )

    if result.fragility_score < 0.1:
        return (
            "This prompt is remarkably stable — confidence barely shifts "
            "under perturbation. The model's certainty appears well-calibrated "
            "for this specific question."
        )

    return (
        f"Moderate fragility detected (score: {result.fragility_score:.2f}). "
        f"Some perturbations affect confidence more than others."
    )


# Error message constants (shared)
ERR_API_KEY = (
    "[yellow]API key not set. Export one of:[/yellow]\n"
    "  [dim]export OPENAI_API_KEY=sk-...[/dim]\n"
    "  [dim]export ANTHROPIC_API_KEY=sk-ant-...[/dim]\n"
    "  [dim]export GROQ_API_KEY=gsk-...[/dim]\n"
    "Or use a local model: [cyan]yuragi scan '...' -m ollama/llama3[/cyan]"
)

ERR_MODEL = (
    "[yellow]Model not supported or unreachable.[/yellow]\n"
    "  Supported: any litellm model string (openai/*, anthropic/*, ollama/*, groq/*)\n"
    "  Docs: https://docs.litellm.ai/docs/providers"
)

ERR_OLLAMA_NOT_FOUND = (
    "[yellow]Ollama not detected.[/yellow] Install ollama or pass "
    "[cyan]--model gpt-4o-mini[/cyan] (requires [dim]OPENAI_API_KEY[/dim])."
)
