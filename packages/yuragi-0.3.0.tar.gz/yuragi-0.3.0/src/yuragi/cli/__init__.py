"""CLI package for yuragi.

Provides the main Click group and all subcommands.
"""

from __future__ import annotations

from pathlib import Path  # noqa: F401  (kept for patch("yuragi.cli.Path") in tests)

import click

from yuragi import __version__
from yuragi.core import Scanner  # noqa: F401  (kept for patch("yuragi.cli.Scanner") in tests)

from .analysis import linguistic, phase_map_cmd, profile, stats, trajectory, trilayer, volatility
from .compare import compare
from .compare_models import compare_models
from .experiment import experiment
from .helpers import (
    _confidence_bar,
    _delta_text,
    _find_removed_word,
    _fragility_color,
    _key_insight,
    _severity_color,
)
from .scan import find_weakness, scan
from .utility import demo, export


@click.group()
@click.version_option(version=__version__, prog_name="yuragi")
@click.option("--quiet", "-q", is_flag=True, default=False, help="Suppress logo and progress bars")
@click.pass_context
def main(ctx: click.Context, quiet: bool) -> None:
    """yuragi - LLM Confidence Fragility Analyzer.

    Measure how fragile your AI's confidence really is.
    """
    ctx.ensure_object(dict)
    ctx.obj["quiet"] = quiet


main.add_command(scan)
main.add_command(find_weakness)
main.add_command(experiment)
main.add_command(demo)
main.add_command(export)
main.add_command(compare)
main.add_command(compare_models)
main.add_command(trajectory)
main.add_command(stats)
main.add_command(trilayer)
main.add_command(profile)
main.add_command(linguistic)
main.add_command(volatility)
main.add_command(phase_map_cmd)

__all__ = [
    "_confidence_bar",
    "_delta_text",
    "_find_removed_word",
    "_fragility_color",
    "_key_insight",
    "_severity_color",
    "main",
]
