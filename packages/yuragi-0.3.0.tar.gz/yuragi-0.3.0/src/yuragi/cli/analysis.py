"""stats, profile, trilayer, trajectory, linguistic, volatility, phase-map CLI commands."""

from __future__ import annotations

import json
import sys

import click
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.text import Text

from yuragi.config import DEFAULT_CONFIG
from yuragi.core import DEFAULT_PERTURBATIONS, Scanner

from .helpers import (
    ERR_API_KEY,
    ERR_MODEL,
    _confidence_bar,
)

console = Console()


def _print_logo(quiet: bool = False) -> None:
    from yuragi import __version__

    logo = "[bold cyan]揺[/bold cyan][cyan]ら[/cyan][dim cyan]ぎ[/dim cyan]  [bold]yuragi[/bold] [dim]v{version}[/dim]"
    if quiet:
        return
    console.print(logo.format(version=__version__))
    console.print()


@click.command()
@click.argument("prompt")
@click.option("--model", "-m", default=DEFAULT_CONFIG.default_model)
@click.option("--samples", "-n", default=3, type=int)
@click.pass_context
def stats(ctx: click.Context, prompt, model, samples):
    """Show detailed statistical analysis of confidence fragility.

    Includes Cohen's d effect size, bootstrap confidence intervals,
    and coefficient of variation.

    Example:
        yuragi stats "Is AI dangerous?" -m ollama/llama3.2
    """
    from yuragi.analysis.statistics import analyze

    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    _print_logo(quiet)

    console.print(f"[cyan]Statistical analysis:[/cyan] {prompt}")
    console.print(f"[dim]Model: {model}[/dim]\n")

    scanner = Scanner(model=model, num_samples=samples)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=Console(stderr=True),
        disable=quiet,
    ) as progress:
        progress.add_task("Scanning...", total=None)
        result = scanner.scan(prompt)

    report = analyze(result)

    table = Table(title="Statistical Report", box=box.ROUNDED, show_lines=True)
    table.add_column("Metric", style="bold")
    table.add_column("Value")
    table.add_column("Interpretation", style="dim")

    table.add_row("N perturbations", str(report.n_perturbations), "")
    table.add_row("Baseline confidence", f"{report.baseline_confidence:.3f}", "")
    table.add_row("Mean confidence", f"{report.mean_confidence:.3f}", "")
    table.add_row("Median confidence", f"{report.median_confidence:.3f}", "")
    table.add_row("Std deviation", f"{report.std_confidence:.3f}", "")
    table.add_row(
        "Cohen's d",
        f"{report.cohens_d:.3f}",
        f"[{'red' if report.cohens_d > 0.8 else 'yellow' if report.cohens_d > 0.5 else 'green'}]"
        f"{report.effect_size_label}[/]",
    )
    table.add_row(
        "95% CI (delta)",
        f"[{report.ci_lower:+.3f}, {report.ci_upper:+.3f}]",
        "Bootstrap confidence interval",
    )
    table.add_row("Fragility Score", f"{report.fragility_score:.3f}", result.fragility_label())
    table.add_row("Max drop", f"{report.max_drop:+.3f}", "")
    table.add_row("Max boost", f"{report.max_boost:+.3f}", "")
    table.add_row("Confidence Dissociation rate", f"{report.dissociation_rate:.1%}", "")
    table.add_row(
        "Coeff. of variation",
        f"{report.coefficient_of_variation:.3f}",
        "Higher = more non-linear",
    )
    table.add_row("IQR", f"{report.interquartile_range:.3f}", "")

    console.print(table)
    console.print()


@click.command()
@click.argument("prompt")
@click.option("--model", "-m", default=DEFAULT_CONFIG.default_model)
@click.option("--samples", "-n", default=3, type=int)
@click.pass_context
def profile(ctx: click.Context, prompt, model, samples):
    """Show the fragility profile — quantifying how confidence breaks.

    Measures:
    - Catastrophic Collapse Index: How efficiently can one word destroy confidence?
    - Recovery Elasticity: Does confidence bounce back after collapse?
    - Non-linearity Score: Do small changes cause disproportionate effects?

    Example:
        yuragi profile "Explain the theory of relativity" -m ollama/llama3.2
    """
    from yuragi.analysis.fragility_profile import build_profile

    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    _print_logo(quiet)

    console.print(f"[cyan]Fragility profile:[/cyan] {prompt}")
    console.print(f"[dim]Model: {model}[/dim]\n")

    scanner = Scanner(model=model, num_samples=samples)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=Console(stderr=True),
        disable=quiet,
    ) as progress:
        progress.add_task("Building profile...", total=None)
        result = scanner.scan(prompt)

    fp = build_profile(result)

    table = Table(title="Fragility Profile", box=box.ROUNDED, show_lines=True)
    table.add_column("Metric", style="bold")
    table.add_column("Value", width=15)
    table.add_column("Interpretation")

    cci_color = (
        "red" if fp.catastrophic_collapse_index > 0.5
        else "yellow" if fp.catastrophic_collapse_index > 0.2
        else "green"
    )
    table.add_row(
        "Catastrophic Collapse Index",
        f"[{cci_color}]{fp.catastrophic_collapse_index:.3f}[/{cci_color}]",
        "How efficiently can one word destroy confidence",
    )

    re_color = (
        "red" if fp.recovery_elasticity < 0.3
        else "yellow" if fp.recovery_elasticity < 0.6
        else "green"
    )
    table.add_row(
        "Recovery Elasticity",
        f"[{re_color}]{fp.recovery_elasticity:.3f}[/{re_color}]",
        "Does confidence bounce back after collapse",
    )

    nl_color = (
        "red" if fp.non_linearity_score > 0.6
        else "yellow" if fp.non_linearity_score > 0.3
        else "green"
    )
    table.add_row(
        "Non-linearity Score",
        f"[{nl_color}]{fp.non_linearity_score:.3f}[/{nl_color}]",
        "Do small changes cause disproportionate effects",
    )

    console.print(table)

    console.print(f"\n[bold]Profile: {fp.profile_label}[/bold]")

    if fp.collapse_trigger:
        console.print(
            f"\n[red]Collapse trigger:[/red] \"{fp.collapse_trigger[:60]}...\""
            f"\n  Delta: {fp.collapse_trigger_delta:+.2f}"
        )
    if fp.recovery_trigger:
        console.print(
            f"\n[green]Recovery trigger:[/green] \"{fp.recovery_trigger[:60]}...\""
            f"\n  Delta: {fp.recovery_trigger_delta:+.2f}"
        )
    console.print()


@click.command()
@click.argument("prompt")
@click.option("--model", "-m", default=DEFAULT_CONFIG.default_model)
@click.option("--samples", "-n", default=3, type=int)
@click.pass_context
def trilayer(ctx: click.Context, prompt, model, samples):
    """Compare confidence across three measurement layers.

    Shows how logprobs, sampling, and self-reported confidence
    may disagree — revealing the model's internal conflict.

    Example:
        yuragi trilayer "Is AI dangerous?" -m ollama/llama3.2
    """
    from yuragi.analysis.trilayer import measure_trilayer

    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    _print_logo(quiet)

    console.print(f"[cyan]Trilayer confidence analysis:[/cyan] {prompt}")
    console.print(f"[dim]Model: {model}[/dim]\n")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=Console(stderr=True),
        disable=quiet,
    ) as progress:
        progress.add_task("Measuring 3 layers...", total=None)
        result = measure_trilayer(prompt, model, num_samples=samples)

    table = Table(title="Trilayer Confidence", box=box.ROUNDED, show_lines=True)
    table.add_column("Layer", style="bold")
    table.add_column("Method", style="dim")
    table.add_column("Confidence", width=35)
    table.add_column("Status")

    if result.logprob_confidence is not None:
        table.add_row(
            "Layer 1",
            "Token probability (logprobs)",
            _confidence_bar(result.logprob_confidence),
            "Available",
        )
    else:
        table.add_row(
            "Layer 1",
            "Token probability (logprobs)",
            Text("N/A", style="dim"),
            Text("Not supported", style="dim"),
        )

    table.add_row(
        "Layer 2",
        "Behavioral consistency (sampling)",
        _confidence_bar(result.sampling_confidence),
        f"{samples} samples",
    )

    table.add_row(
        "Layer 3",
        "Self-reported (verbalized)",
        _confidence_bar(result.verbalized_confidence),
        "0-100 scale",
    )

    console.print(table)

    disc_color = "red" if result.internal_conflict else "green"
    console.print(
        Panel(
            f"Max discrepancy: [{disc_color}]{result.max_discrepancy:.2f}[/{disc_color}]\n"
            f"Dominant layer: {result.dominant_layer}\n"
            f"\n{result.summary}",
            title="[bold]Layer Analysis[/bold]",
            border_style=disc_color,
        )
    )

    if result.internal_conflict:
        console.print(
            "[bold magenta]The model's different confidence layers disagree.[/bold magenta]\n"
            "This mirrors how humans can feel confident internally\n"
            "while appearing uncertain externally, or vice versa.\n"
        )
    console.print()


@click.command()
@click.argument(
    "sequence",
    type=click.Choice(["challenge", "difficulty", "emotional", "custom"]),
)
@click.option("--model", "-m", default=DEFAULT_CONFIG.default_model)
@click.option("--samples", "-n", default=3, type=int)
@click.option("--prompts", "-p", default=None, help="Comma-separated prompts for custom sequence")
@click.pass_context
def trajectory(ctx: click.Context, sequence, model, samples, prompts):
    """Track confidence over a sequence of prompts.

    Pre-built sequences:
      challenge  — Gradually challenge a correct answer
      difficulty — Escalate question difficulty
      emotional  — Alternate praise and criticism

    Example:
        yuragi trajectory challenge -m ollama/llama3.2
        yuragi trajectory custom -p "Q1,Q2,Q3" -m ollama/llama3.2
    """
    from yuragi.analysis.trajectory import (
        CHALLENGE_SEQUENCE,
        EMOTIONAL_MANIPULATION,
        ESCALATING_DIFFICULTY,
        track_trajectory,
    )

    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    _print_logo(quiet)

    sequences = {
        "challenge": CHALLENGE_SEQUENCE,
        "difficulty": ESCALATING_DIFFICULTY,
        "emotional": EMOTIONAL_MANIPULATION,
    }

    if sequence == "custom":
        if not prompts:
            console.print("[red]--prompts required for custom sequence[/red]")
            sys.exit(1)
        prompt_list = [p.strip() for p in prompts.split(",")]
    else:
        prompt_list = sequences[sequence]

    console.print(f"[cyan]Tracking confidence trajectory: {sequence}[/cyan]")
    console.print(f"[dim]Model: {model} | Steps: {len(prompt_list)}[/dim]\n")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=Console(stderr=True),
        disable=quiet,
    ) as progress:
        task = progress.add_task("Tracking...", total=len(prompt_list))

        result = track_trajectory(prompt_list, model, num_samples=samples)

        for _ in result.points:
            progress.advance(task)

    console.print(f"[bold]Trajectory: {sequence}[/bold] | Trend: [cyan]{result.trend}[/cyan]\n")

    for point in result.points:
        bar = _confidence_bar(point.confidence, width=20)
        prompt_short = point.prompt[:50]
        console.print(f"  Step {point.step + 1}: {bar}  {prompt_short}")

    console.print(
        f"\n  Max single-step drop: [red]{result.max_drop:+.2f}[/red]"
        f"  |  Recovery rate: {result.recovery_rate:.0%}"
        f"  |  Trend: [cyan]{result.trend}[/cyan]"
    )
    console.print()


@click.command()
@click.argument("prompt")
@click.option("--model", "-m", default=DEFAULT_CONFIG.default_model, help="Model to use")
@click.option("--samples", "-n", default=5, type=int, help="Samples for confidence measurement")
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
@click.pass_context
def linguistic(ctx: click.Context, prompt, model, samples, json_output):
    """Analyze linguistic confidence indicators in an LLM response.

    Detects hedge words, assertion words, and compares linguistic confidence
    against the numerical confidence score to find over/under-expression.

    Example:
        yuragi linguistic "Is quantum computing practical?" -m gpt-4o
    """
    from yuragi.analysis.linguistics import analyze_text
    from yuragi.providers.adapter import LLMAdapter

    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    if not json_output and not quiet:
        _print_logo(quiet)

    adapter = LLMAdapter(model=model, num_samples=samples)

    if not json_output and not quiet:
        console.print(f"[cyan]Analyzing:[/cyan] {prompt}")
        console.print(f"[dim]Model: {model}[/dim]\n")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=Console(stderr=True),
        disable=json_output or quiet,
    ) as progress:
        task = progress.add_task("Querying model...", total=None)
        try:
            result = adapter.complete(prompt)
            progress.update(task, description="Analyzing linguistics...")
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]")
            if "api_key" in str(e).lower() or "auth" in str(e).lower():
                console.print(ERR_API_KEY)
            elif "model" in str(e).lower() or "not found" in str(e).lower():
                console.print(ERR_MODEL)
            sys.exit(1)

    report = analyze_text(result.text, result.confidence)

    if json_output:
        output = {
            "prompt": prompt,
            "model": model,
            "response_text": result.text,
            "numerical_confidence": report.numerical_confidence,
            "linguistic_confidence": report.linguistic_confidence,
            "confidence_gap": report.confidence_gap,
            "is_overexpressing": report.is_overexpressing,
            "is_underexpressing": report.is_underexpressing,
            "hedge_count": report.hedge_count,
            "hedge_density": report.hedge_density,
            "hedge_words_found": report.hedge_words_found,
            "assertion_count": report.assertion_count,
            "assertion_density": report.assertion_density,
            "word_count": report.word_count,
            "sentence_count": report.sentence_count,
            "avg_sentence_length": report.avg_sentence_length,
        }
        print(json.dumps(output, indent=2, ensure_ascii=False))
        return

    console.print(
        Panel(
            f"[dim]{result.text[:300]}{'...' if len(result.text) > 300 else ''}[/dim]",
            title="[bold]Response[/bold]",
            border_style="dim",
        )
    )

    table = Table(title="Linguistic Confidence Analysis", box=box.ROUNDED, show_lines=True)
    table.add_column("Metric", style="cyan", width=28)
    table.add_column("Value", width=20)
    table.add_column("Detail", style="dim")

    num_bar = _confidence_bar(report.numerical_confidence)
    ling_bar = _confidence_bar(report.linguistic_confidence)
    table.add_row("Numerical confidence", num_bar, result.confidence_method)
    table.add_row("Linguistic confidence", ling_bar, "derived from text")

    gap = report.confidence_gap
    if abs(gap) < 0.05:
        gap_text = Text(f"{gap:+.2f}", style="green")
        gap_label = "aligned"
    elif gap > 0:
        gap_text = Text(f"{gap:+.2f}", style="bold yellow")
        gap_label = "overexpressing"
    else:
        gap_text = Text(f"{gap:+.2f}", style="bold magenta")
        gap_label = "underexpressing"
    table.add_row("Confidence gap (L-N)", gap_text, gap_label)

    table.add_row("", "", "")
    table.add_row(
        "Hedge count (weighted)",
        str(report.hedge_count),
        f"density {report.hedge_density:.4f}",
    )
    table.add_row(
        "Assertion count",
        str(report.assertion_count),
        f"density {report.assertion_density:.4f}",
    )
    table.add_row(
        "Word count",
        str(report.word_count),
        f"{report.sentence_count} sentence(s), avg {report.avg_sentence_length:.1f} words",
    )
    console.print(table)

    if report.hedge_words_found:
        hedge_list = ", ".join(f'"{w}"' for w in sorted(set(report.hedge_words_found)))
        console.print(f"\n[yellow]Hedge words detected:[/yellow] {hedge_list}")

    if report.is_overexpressing:
        console.print(
            Panel(
                f"[bold yellow]Overexpressing confidence[/bold yellow]\n"
                f"The response uses assertive language (linguistic: {report.linguistic_confidence:.2f}) "
                f"but the numerical score is low ({report.numerical_confidence:.2f}).\n"
                f"The model [italic]sounds[/italic] more certain than it actually is.",
                border_style="yellow",
            )
        )
    elif report.is_underexpressing:
        console.print(
            Panel(
                f"[bold magenta]Underexpressing confidence[/bold magenta]\n"
                f"The response hedges heavily (linguistic: {report.linguistic_confidence:.2f}) "
                f"despite a high numerical score ({report.numerical_confidence:.2f}).\n"
                f"The model [italic]sounds[/italic] less certain than it actually is.",
                border_style="magenta",
            )
        )
    else:
        console.print(
            Panel(
                f"[bold green]Linguistic and numerical confidence are aligned[/bold green]\n"
                f"Gap: {gap:+.2f} (within ±0.15 threshold)",
                border_style="green",
            )
        )
    console.print()


@click.command()
@click.argument("prompt")
@click.option("--model", "-m", default=DEFAULT_CONFIG.default_model, help="Model to test (any litellm-supported model)")
@click.option("--samples", "-n", default=5, type=int, help="Number of samples for confidence measurement")
@click.option("--variants", "-v", default=3, type=int, help="Number of variants per perturbation type")
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
@click.pass_context
def volatility(ctx: click.Context, prompt, model, samples, variants, json_output):
    """Measure confidence volatility using financial-engineering metrics.

    Applies concepts from equity volatility (VIX, realized vol, drawdown, Sharpe)
    to LLM confidence across perturbations.

    Example:
        yuragi volatility "Is quantum computing practical?" -m gpt-4o
    """
    from yuragi.metrics.volatility import compute_volatility

    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    if not json_output and not quiet:
        _print_logo(quiet)

    if not json_output and not quiet:
        console.print(f"[cyan]Volatility scan:[/cyan] {prompt}")
        console.print(f"[dim]Model: {model} | Samples: {samples} | Variants: {variants}[/dim]")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=Console(stderr=True),
        disable=json_output or quiet,
    ) as progress:
        task = progress.add_task("Scanning...", total=None)

        def on_progress(stage, detail):
            progress.update(task, description=f"{stage}: {detail[:40]}")

        scanner = Scanner(
            model=model,
            num_samples=samples,
            perturbations=DEFAULT_PERTURBATIONS,
            num_variants=variants,
            on_progress=on_progress,
        )

        try:
            result = scanner.scan(prompt)
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]")
            if "api_key" in str(e).lower() or "auth" in str(e).lower():
                console.print(ERR_API_KEY)
            elif "model" in str(e).lower() or "not found" in str(e).lower():
                console.print(ERR_MODEL)
            sys.exit(1)

    report = compute_volatility(result)

    if json_output:
        output = {
            "prompt": result.prompt,
            "model": result.model,
            "realized_volatility": report.realized_volatility,
            "confidence_vix": report.confidence_vix,
            "max_drawdown": report.max_drawdown,
            "drawdown_duration": report.drawdown_duration,
            "confidence_sharpe": report.confidence_sharpe,
            "regime": report.regime,
            "autocorrelation": report.autocorrelation,
        }
        print(json.dumps(output, indent=2, ensure_ascii=False))
        return

    regime_color = {
        "stable": "bold green",
        "transitional": "yellow",
        "volatile": "red",
        "chaotic": "bold red",
    }.get(report.regime, "white")

    vix_color = "bold green" if report.confidence_vix < 30 else "yellow" if report.confidence_vix < 60 else "bold red"
    sharpe_color = "bold green" if report.confidence_sharpe > 3 else "yellow" if report.confidence_sharpe > 1 else "red"

    table = Table(
        title="Confidence Volatility Report",
        box=box.ROUNDED,
        show_lines=True,
        title_style="bold",
    )
    table.add_column("Metric", style="cyan", width=22)
    table.add_column("Value", width=16)
    table.add_column("Interpretation", max_width=50)

    table.add_row(
        "Realized Volatility",
        f"{report.realized_volatility:.4f}",
        "Std of log-returns * sqrt(N); lower = more stable",
    )
    table.add_row(
        "Confidence VIX",
        Text(f"{report.confidence_vix:.1f} / 100", style=vix_color),
        "50 = average; >60 = elevated fear; >80 = chaotic",
    )
    table.add_row(
        "Max Drawdown",
        f"{report.max_drawdown:.4f}",
        "Largest peak-to-trough confidence decline",
    )
    table.add_row(
        "Drawdown Duration",
        f"{report.drawdown_duration} steps",
        "Perturbations until recovery from max drawdown",
    )
    table.add_row(
        "Confidence Sharpe",
        Text(f"{report.confidence_sharpe:.4f}", style=sharpe_color),
        "mean / std; higher = more reliable signal",
    )
    table.add_row(
        "Regime",
        Text(report.regime.upper(), style=regime_color),
        "stable <0.10 | transitional <0.30 | volatile <0.50 | chaotic",
    )
    table.add_row(
        "Autocorrelation",
        f"{report.autocorrelation:+.4f}",
        ">0 = momentum (drops cluster); <0 = mean-reverting",
    )

    console.print(table)

    ac_note = (
        "momentum — volatility clusters" if report.autocorrelation > 0.3
        else "mean-reverting — natural recovery" if report.autocorrelation < -0.3
        else "random walk — unpredictable"
    )
    console.print(
        Panel(
            f"Regime: [{regime_color}]{report.regime.upper()}[/{regime_color}]  "
            f"VIX: [{vix_color}]{report.confidence_vix:.1f}[/{vix_color}]  "
            f"Sharpe: [{sharpe_color}]{report.confidence_sharpe:.2f}[/{sharpe_color}]\n"
            f"Autocorrelation pattern: {ac_note}",
            title="[bold yellow]Volatility Summary[/bold yellow]",
            border_style="yellow",
        )
    )
    console.print()


@click.command("phase-map")
@click.argument("prompt")
@click.option("--model", "-m", default=DEFAULT_CONFIG.default_model, help="Model to test (any litellm model)")
@click.option("--samples", "-n", default=3, type=int, help="Samples per step for confidence measurement")
@click.option(
    "--max-param",
    default=5,
    type=int,
    help="Number of doubt-word steps (0..max-param)",
)
@click.option(
    "--threshold",
    default=0.05,
    type=float,
    help="Sharpness threshold for transition detection",
)
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
@click.pass_context
def phase_map_cmd(ctx: click.Context, prompt, model, samples, max_param, threshold, json_output):
    """Map confidence phase transitions across a parameter space.

    Sweeps doubt-word count (0 to max-param) as the order parameter,
    measuring confidence at each step. Detects sharp transitions using
    second-derivative peaks -- analogous to physical phase transitions.

    Example:
        yuragi phase-map "Is quantum computing practical?" -m gpt-4o
    """
    from yuragi.analysis.phase_transition import (
        PhaseMapExperiment,
        _phase_label,
        _transition_summary,
    )

    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    if not json_output and not quiet:
        _print_logo(quiet)

    if not json_output and not quiet:
        console.print(f"[cyan]Phase-map sweep:[/cyan] {prompt}")
        console.print(
            f"[dim]Model: {model} | Steps: 0..{max_param} | "
            f"Samples: {samples} | Threshold: {threshold}[/dim]\n"
        )

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=Console(stderr=True),
        disable=json_output or quiet,
    ) as progress:
        progress.add_task("Sweeping parameter space...", total=None)

        experiment = PhaseMapExperiment(
            model=model,
            max_param=max_param,
            num_samples=samples,
            sharpness_threshold=threshold,
        )

        try:
            pm = experiment.run(prompt)
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]")
            if "api_key" in str(e).lower() or "auth" in str(e).lower():
                console.print(ERR_API_KEY)
            elif "model" in str(e).lower() or "not found" in str(e).lower():
                console.print(ERR_MODEL)
            sys.exit(1)

    if json_output:
        output = {
            "prompt": prompt,
            "model": model,
            "order_parameter": pm.order_parameter,
            "num_phases": pm.num_phases,
            "critical_point": pm.critical_point,
            "num_transitions": len(pm.transitions),
            "transitions": [
                {
                    "transition_prompt": t.transition_prompt,
                    "pre_confidence": t.pre_transition_confidence,
                    "post_confidence": t.post_transition_confidence,
                    "sharpness": t.sharpness,
                    "type": t.transition_type,
                    "trigger": t.trigger,
                }
                for t in pm.transitions
            ],
            "steps": [
                {"param": p, "prompt": pr, "confidence": c}
                for p, pr, c in pm.steps
            ],
        }
        print(json.dumps(output, indent=2, ensure_ascii=False))
        return

    table = Table(
        title=f'Confidence Phase Diagram: "{prompt[:50]}"',
        box=box.ROUNDED,
        show_lines=False,
    )
    table.add_column("Param (p)", style="cyan", width=10)
    table.add_column("Confidence", width=35)
    table.add_column("Phase", width=18)
    table.add_column("Event", width=12)

    transition_prompts = {t.transition_prompt for t in pm.transitions}

    for p, pr, conf in pm.steps:
        label = _phase_label(conf)
        label_color = (
            "green" if label == "high-confidence"
            else "yellow" if label == "intermediate"
            else "red"
        )
        if pr in transition_prompts:
            matched = [t for t in pm.transitions if t.transition_prompt == pr]
            if matched:
                mt = matched[0]
                event_color = "red" if mt.transition_type == "collapse" else "green"
                arrow = "\u26a1 collapse" if mt.transition_type == "collapse" else "\u2b06 surge"
                event_cell: Text = Text(arrow, style=f"bold {event_color}")
            else:
                event_cell = Text("\u2014", style="dim")
        else:
            event_cell = Text("\u2014", style="dim")

        table.add_row(
            f"p={p}",
            _confidence_bar(conf),
            Text(label, style=label_color),
            event_cell,
        )

    console.print(table)

    if pm.transitions:
        transition_lines = []
        for i, t in enumerate(pm.transitions, 1):
            transition_lines.append(f"[{i}] {_transition_summary(t)}")

        if pm.critical_point:
            transition_lines.append(
                f"\n[bold yellow]Critical point:[/bold yellow] "
                f'"{pm.critical_point[:70]}"'
            )

        console.print(
            Panel(
                "\n".join(transition_lines),
                title=f"[bold red]\u26a1 Phase Transitions ({len(pm.transitions)})[/bold red]",
                border_style="red",
            )
        )
    else:
        console.print(
            Panel(
                "[green]No phase transitions detected.[/green]\n"
                "[dim]Confidence changes gradually (no sharp collapse).[/dim]",
                title="[bold green]Phase Stability[/bold green]",
                border_style="green",
            )
        )

    confidences = [c for _, _, c in pm.steps]
    total_drop = (confidences[0] - min(confidences)) if confidences else 0.0
    is_monotone = all(
        confidences[i] >= confidences[i + 1] - 1e-9
        for i in range(len(confidences) - 1)
    )

    console.print(
        Panel(
            f"Order parameter : {pm.order_parameter}\n"
            f"Distinct phases : {pm.num_phases}\n"
            f"Transitions     : {len(pm.transitions)}\n"
            f"Total conf drop : {total_drop:+.2f}\n"
            f"Monotone descent: {'yes' if is_monotone else 'no'}",
            title="[bold]Phase Map Summary[/bold]",
            border_style="cyan",
        )
    )
    console.print()
