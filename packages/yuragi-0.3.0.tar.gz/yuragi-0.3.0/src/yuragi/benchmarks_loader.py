"""Public benchmark dataset loaders.

Loads TruthfulQA, SimpleQA, HaluEval as standardized question dicts
for use with yuragi's fragility scanner.

Datasets are NOT bundled. Loaders fetch from Hugging Face datasets
on first use, with optional caching to ~/.cache/yuragi/benchmarks/.
"""

from __future__ import annotations

from collections.abc import Iterator

_BENCHMARKS = ("truthfulqa", "simpleqa", "halueval")


def _require_datasets():
    try:
        from datasets import load_dataset

        return load_dataset
    except ImportError as err:
        raise ImportError(
            "benchmarks extras required: pip install yuragi[benchmarks]"
        ) from err


def load_truthfulqa(
    *,
    split: str = "validation",
    limit: int | None = None,
) -> list[dict]:
    """Load TruthfulQA. Returns [{"question": str, "answers": list[str]}, ...]."""
    load_dataset = _require_datasets()
    ds = load_dataset("truthful_qa", "generation", split=split, trust_remote_code=False)
    rows = []
    for i, item in enumerate(ds):
        if limit is not None and i >= limit:
            break
        rows.append(
            {
                "question": item["question"],
                "answers": item.get("correct_answers", []) or [],
                "source": "truthfulqa",
            }
        )
    return rows


def load_simpleqa(
    *, limit: int | None = None, dataset_id: str = "basicv8vc/SimpleQA"
) -> list[dict]:
    """Load SimpleQA. Returns [{"question": str, "answers": list[str]}, ...].

    The ``dataset_id`` parameter is exposed because the canonical SimpleQA
    repository has moved between mirrors on Hugging Face. The default points
    at ``basicv8vc/SimpleQA`` (community mirror of the OpenAI release); pass
    an alternative repo id if you prefer a different host.
    """
    load_dataset = _require_datasets()
    ds = load_dataset(dataset_id, split="test", trust_remote_code=False)
    rows = []
    for i, item in enumerate(ds):
        if limit is not None and i >= limit:
            break
        answer = item.get("answer", "") or item.get("correct_answer", "")
        question = item.get("problem") or item.get("question") or ""
        rows.append(
            {
                "question": question,
                "answers": [answer] if answer else [],
                "source": "simpleqa",
            }
        )
    return rows


def load_halueval(*, task: str = "qa", limit: int | None = None) -> list[dict]:
    """Load HaluEval. Returns [{"question": str, "answers": list[str]}, ...]."""
    load_dataset = _require_datasets()
    ds = load_dataset("pminervini/HaluEval", task, split="data", trust_remote_code=False)
    rows = []
    for i, item in enumerate(ds):
        if limit is not None and i >= limit:
            break
        question = item.get("question") or item.get("input") or ""
        answer = item.get("right_answer") or item.get("answer") or ""
        rows.append(
            {
                "question": question,
                "answers": [answer] if answer else [],
                "source": "halueval",
                "task": task,
            }
        )
    return rows


def yield_questions(benchmark: str, **kwargs) -> Iterator[dict]:
    """Generic dispatcher: benchmark in {'truthfulqa', 'simpleqa', 'halueval'}."""
    if benchmark == "truthfulqa":
        yield from load_truthfulqa(**kwargs)
    elif benchmark == "simpleqa":
        yield from load_simpleqa(**kwargs)
    elif benchmark == "halueval":
        yield from load_halueval(**kwargs)
    else:
        raise ValueError(
            f"Unknown benchmark: {benchmark!r}. Available: {', '.join(_BENCHMARKS)}"
        )
