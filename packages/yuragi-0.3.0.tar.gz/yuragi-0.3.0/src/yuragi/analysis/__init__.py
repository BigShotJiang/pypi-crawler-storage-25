"""Analysis modules for confidence fragility measurement.

Modules:
- fragility_profile: CCI, Recovery Elasticity, Non-linearity Score
- statistics: Cohen's d, bootstrap CI, coefficient of variation
- trajectory: Confidence tracking over prompt sequences
- trilayer: 3-layer confidence comparison
- minimal_edit: Gradient-free minimal perturbation search
- decay: Confidence decay under repeated challenges
- recovery: Recovery pattern analysis
- adversarial: Adversarial analysis (flip / sycophancy / pressure resistance)
- agentic_uq: Tool-use multi-step confidence trajectory tracking (v0.2.0)
- fingerprint: Behavioral fingerprint derived from yuragi analysis
- fingerprint_builder: Build fingerprints from scans + experiments
- linguistics: Linguistic confidence analysis (hedge/assertion detection)
- phase_transition: Physics-inspired phase transition detection in confidence
"""

from yuragi.analysis.agentic_uq import AgenticStep, AgenticTrajectory, track_agentic_session
from yuragi.analysis.fingerprint import ModelFingerprint
from yuragi.analysis.fingerprint_builder import build_fingerprint
from yuragi.analysis.fragility_profile import FragilityProfile, build_profile
from yuragi.analysis.linguistics import LinguisticConfidenceReport, analyze_text
from yuragi.analysis.phase_transition import PhaseMap, PhaseTransition, detect_phase_transitions
from yuragi.analysis.statistics import StatisticalReport, analyze
from yuragi.analysis.trajectory import ConfidenceTrajectory, track_trajectory
from yuragi.analysis.trilayer import TrilayerResult, measure_trilayer

__all__ = [
    "AgenticStep",
    "AgenticTrajectory",
    "ConfidenceTrajectory",
    "FragilityProfile",
    "LinguisticConfidenceReport",
    "ModelFingerprint",
    "PhaseMap",
    "PhaseTransition",
    "StatisticalReport",
    "TrilayerResult",
    "analyze",
    "analyze_text",
    "build_fingerprint",
    "build_profile",
    "detect_phase_transitions",
    "measure_trilayer",
    "track_agentic_session",
    "track_trajectory",
]
