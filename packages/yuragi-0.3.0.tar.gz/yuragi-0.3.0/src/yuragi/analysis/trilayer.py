"""Trilayer confidence comparison.

Measures confidence using all three available methods simultaneously
on the same prompt, exposing discrepancies between how different
measurement approaches perceive the model's certainty.

The philosophical insight: just as humans have multiple "types"
of confidence (gut feeling vs rational assessment vs social
performance), LLMs show different confidence signatures depending
on how you measure them.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.providers.adapter import CompletionResult, LLMAdapter

_LAYER_NAMES = ("logprob", "sampling", "verbalized")


@dataclass
class LayerAgreementMatrix:
    """Pairwise agreement (1 - |conf_a - conf_b|) between the three layers."""

    logprob_vs_sampling: float | None    # None when logprobs unavailable
    logprob_vs_verbalized: float | None  # None when logprobs unavailable
    sampling_vs_verbalized: float

    @property
    def mean_agreement(self) -> float:
        """Mean of all available pairwise agreements."""
        values = [self.sampling_vs_verbalized]
        if self.logprob_vs_sampling is not None:
            values.append(self.logprob_vs_sampling)
        if self.logprob_vs_verbalized is not None:
            values.append(self.logprob_vs_verbalized)
        return sum(values) / len(values)

    def as_dict(self) -> dict[str, float | None]:
        return {
            "logprob_vs_sampling": self.logprob_vs_sampling,
            "logprob_vs_verbalized": self.logprob_vs_verbalized,
            "sampling_vs_verbalized": self.sampling_vs_verbalized,
        }


@dataclass
class TrilayerResult:
    """Confidence measured three different ways on the same prompt."""

    prompt: str
    model: str

    # Layer 1: Token probability (most "unconscious" — raw distribution)
    logprob_result: CompletionResult | None  # None if model doesn't support logprobs
    logprob_confidence: float | None

    # Layer 2: Behavioral consistency (sampling agreement)
    sampling_result: CompletionResult
    sampling_confidence: float

    # Layer 3: Self-reported (most "conscious" — explicit self-assessment)
    verbalized_result: CompletionResult
    verbalized_confidence: float

    @property
    def max_discrepancy(self) -> float:
        """Maximum gap between any two measurement methods.

        High discrepancy = the model's different "layers" disagree
        about how confident it is. Analogous to a human who
        feels confident but acts uncertain, or vice versa.
        """
        values = [self.sampling_confidence, self.verbalized_confidence]
        if self.logprob_confidence is not None:
            values.append(self.logprob_confidence)
        return max(values) - min(values)

    @property
    def internal_conflict(self) -> bool:
        """Whether the model's layers significantly disagree (default threshold 0.2)."""
        return self.max_discrepancy > DEFAULT_CONFIG.trilayer_internal_conflict_threshold

    def has_internal_conflict(
        self, threshold: float = DEFAULT_CONFIG.trilayer_internal_conflict_threshold
    ) -> bool:
        """Whether the model's layers significantly disagree at the given threshold."""
        return self.max_discrepancy > threshold

    @property
    def dominant_layer(self) -> str:
        """Which layer shows the highest confidence."""
        layers = {"sampling": self.sampling_confidence, "verbalized": self.verbalized_confidence}
        if self.logprob_confidence is not None:
            layers["logprob"] = self.logprob_confidence
        return max(layers, key=lambda k: layers[k])

    @property
    def outlier_layer(self) -> str:
        """Layer that deviates most from the other two.

        When logprobs are unavailable, falls back to the layer that
        is furthest from the remaining layer's midpoint.
        """
        confs: dict[str, float] = {
            "sampling": self.sampling_confidence,
            "verbalized": self.verbalized_confidence,
        }
        if self.logprob_confidence is not None:
            confs["logprob"] = self.logprob_confidence

        if len(confs) == 2:
            # With two layers, both are equally "outlying"; return dominant
            return self.dominant_layer

        mean = sum(confs.values()) / len(confs)
        return max(confs, key=lambda k: abs(confs[k] - mean))

    @property
    def agreement_matrix(self) -> LayerAgreementMatrix:
        """Pairwise agreement scores between all available layer pairs."""
        s = self.sampling_confidence
        v = self.verbalized_confidence
        lp = self.logprob_confidence

        return LayerAgreementMatrix(
            logprob_vs_sampling=(1.0 - abs(lp - s)) if lp is not None else None,
            logprob_vs_verbalized=(1.0 - abs(lp - v)) if lp is not None else None,
            sampling_vs_verbalized=1.0 - abs(s - v),
        )

    @property
    def summary(self) -> str:
        """Human-readable summary of trilayer analysis."""
        if self.internal_conflict:
            return (
                f"Internal conflict detected (discrepancy: {self.max_discrepancy:.2f}). "
                f"Model appears most confident via {self.dominant_layer} measurement."
            )
        return f"Consistent confidence across layers (discrepancy: {self.max_discrepancy:.2f})."

    def to_record(self) -> dict:
        """Serialisable dict suitable for historical storage."""
        return {
            "timestamp": int(time.time()),
            "prompt": self.prompt,
            "model": self.model,
            "logprob_confidence": self.logprob_confidence,
            "sampling_confidence": self.sampling_confidence,
            "verbalized_confidence": self.verbalized_confidence,
            "max_discrepancy": self.max_discrepancy,
            "internal_conflict": self.internal_conflict,
            "dominant_layer": self.dominant_layer,
            "outlier_layer": self.outlier_layer,
        }


# ---------------------------------------------------------------------------
# Historical comparison helpers
# ---------------------------------------------------------------------------

_DEFAULT_HISTORY_PATH = os.path.expanduser("~/.cache/yuragi/trilayer_history.jsonl")


@dataclass
class HistoricalComparison:
    """Comparison of a current result against past results for the same prompt."""

    current: TrilayerResult
    past_records: list[dict] = field(default_factory=list)

    @property
    def n_past(self) -> int:
        return len(self.past_records)

    @property
    def trend_sampling(self) -> float | None:
        """Mean change in sampling confidence vs the past (positive = increasing)."""
        if not self.past_records:
            return None
        past_mean = sum(r["sampling_confidence"] for r in self.past_records) / len(self.past_records)
        return self.current.sampling_confidence - past_mean

    @property
    def trend_verbalized(self) -> float | None:
        """Mean change in verbalized confidence vs the past."""
        if not self.past_records:
            return None
        past_mean = sum(r["verbalized_confidence"] for r in self.past_records) / len(self.past_records)
        return self.current.verbalized_confidence - past_mean

    @property
    def discrepancy_trend(self) -> float | None:
        """Whether max_discrepancy is increasing (+) or decreasing (-) over time."""
        if not self.past_records:
            return None
        past_mean = sum(r["max_discrepancy"] for r in self.past_records) / len(self.past_records)
        return self.current.max_discrepancy - past_mean

    def summary(self) -> str:
        if not self.past_records:
            return "No historical data available for this prompt."
        lines = [
            f"Historical comparison ({self.n_past} past run(s)):",
            f"  sampling trend:    {self.trend_sampling:+.3f}",
            f"  verbalized trend:  {self.trend_verbalized:+.3f}",
            f"  discrepancy trend: {self.discrepancy_trend:+.3f}",
        ]
        return "\n".join(lines)


def save_result(result: TrilayerResult, path: str = _DEFAULT_HISTORY_PATH) -> None:
    """Append a TrilayerResult to the JSONL history file."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(result.to_record()) + "\n")


def load_history(
    prompt: str,
    model: str,
    path: str = _DEFAULT_HISTORY_PATH,
) -> list[dict]:
    """Load past records matching the given prompt and model from the history file."""
    if not os.path.exists(path):
        return []
    records = []
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if rec.get("prompt") == prompt and rec.get("model") == model:
                records.append(rec)
    return records


def compare_historical(
    result: TrilayerResult,
    path: str = _DEFAULT_HISTORY_PATH,
) -> HistoricalComparison:
    """Return a HistoricalComparison for result against its stored history."""
    past = load_history(result.prompt, result.model, path=path)
    return HistoricalComparison(current=result, past_records=past)


# ---------------------------------------------------------------------------
# Main measurement function
# ---------------------------------------------------------------------------


def measure_trilayer(
    prompt: str,
    model: str,
    num_samples: int = 5,
    api_key: str | None = None,
    config: YuragiConfig | None = None,
) -> TrilayerResult:
    """Measure confidence using all three methods on the same prompt.

    This reveals whether different measurement approaches agree.
    Disagreement suggests the model's "confidence" is not a single
    coherent value — just like human confidence isn't.

    The ``config`` parameter is forwarded to ``LLMAdapter`` so that
    entropy cutoffs and other YuragiConfig-driven thresholds apply
    consistently with the rest of the pipeline.
    """
    cfg = config or DEFAULT_CONFIG
    adapter = LLMAdapter(
        model=model, api_key=api_key, num_samples=num_samples, config=cfg
    )

    # Layer 1: Logprobs (if available)
    logprob_result = None
    logprob_conf = None
    if adapter.capabilities.supports_logprobs:
        logprob_result = adapter._complete_with_logprobs(prompt)
        logprob_conf = logprob_result.confidence

    # Layer 2: Sampling
    sampling_result = adapter._complete_with_sampling(prompt)

    # Layer 3: Verbalized
    verbalized_result = adapter.complete_verbalized(prompt)

    return TrilayerResult(
        prompt=prompt,
        model=model,
        logprob_result=logprob_result,
        logprob_confidence=logprob_conf,
        sampling_result=sampling_result,
        sampling_confidence=sampling_result.confidence,
        verbalized_result=verbalized_result,
        verbalized_confidence=verbalized_result.confidence,
    )
