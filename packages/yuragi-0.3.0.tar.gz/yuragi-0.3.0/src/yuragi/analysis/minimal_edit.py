"""Minimal Perturbation Search — yuragi's algorithmic killer feature.

Finds the smallest edit to a prompt that causes the maximum confidence
collapse. Uses iterative refinement rather than brute force.

Algorithm (v1):
1. Run single-word omissions to find the most impactful word
2. For that word, try character-level modifications (typos, deletions)
3. Try adding single words before/after the impactful word
4. Return the minimal edit that causes maximum confidence shift

Algorithm (v2 — gradient perturbation search):
Phase 1: First-order scan  — single-word omissions, find top-k
Phase 2: Second-order scan — pairwise omissions over top-k words
Phase 3: Char-level precision — QWERTY-adjacent substitutions on top word
Phase 4: Insertion search   — insert effective words at best position

This is a gradient-free optimization over discrete text space.
"""

from __future__ import annotations

import itertools
from collections.abc import Callable
from dataclasses import dataclass, field

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.providers.adapter import LLMAdapter
from yuragi.utils import ADJACENT_KEYS as _ADJACENT_KEYS
from yuragi.utils import is_japanese as _is_japanese

# ---------------------------------------------------------------------------
# Shared data types
# ---------------------------------------------------------------------------


@dataclass
class MinimalEdit:
    """The smallest edit that causes maximum confidence collapse."""

    original_prompt: str
    edited_prompt: str
    edit_type: str  # "omit_word", "add_word", "replace_char", "add_prefix"
    edit_description: str  # Human-readable description
    original_confidence: float
    edited_confidence: float
    edit_distance: int  # Character-level edit distance

    @property
    def confidence_delta(self) -> float:
        return self.edited_confidence - self.original_confidence

    @property
    def efficiency(self) -> float:
        """Confidence impact per character of edit. Higher = more efficient."""
        if self.edit_distance == 0:
            return 0.0
        return abs(self.confidence_delta) / self.edit_distance


@dataclass
class WordOmissionResult:
    """Result of omitting a single word."""

    word: str
    word_index: int
    edited_prompt: str
    delta: float  # confidence_delta (negative = confidence dropped)


@dataclass
class PairOmissionResult:
    """Result of omitting two words simultaneously."""

    word_a: str
    index_a: int
    word_b: str
    index_b: int
    edited_prompt: str
    delta: float
    interaction_term: float  # delta_pair - (delta_a + delta_b)


@dataclass
class CharEditResult:
    """Result of a single-character edit on the most impactful word."""

    word: str
    edited_word: str
    char_index: int
    original_char: str
    new_char: str
    edited_prompt: str
    delta: float


@dataclass
class InsertionResult:
    """Result of inserting a single word at a specific position."""

    inserted_word: str
    insert_position: int  # token index
    edited_prompt: str
    delta: float


@dataclass
class MinimalEditResult:
    """Aggregated output from find_minimal_edit_v2."""

    original_prompt: str
    baseline_confidence: float

    # Phase results
    phase1_omissions: list[WordOmissionResult] = field(default_factory=list)
    phase2_pairs: list[PairOmissionResult] = field(default_factory=list)
    phase3_char_edits: list[CharEditResult] = field(default_factory=list)
    phase4_insertions: list[InsertionResult] = field(default_factory=list)

    # Best edit found across all phases
    best_edit: MinimalEdit | None = None

    @property
    def top_omission(self) -> WordOmissionResult | None:
        if not self.phase1_omissions:
            return None
        return min(self.phase1_omissions, key=lambda r: r.delta)

    @property
    def strongest_interaction(self) -> PairOmissionResult | None:
        if not self.phase2_pairs:
            return None
        return min(self.phase2_pairs, key=lambda r: r.interaction_term)


# ---------------------------------------------------------------------------
# Vocabulary banks
# ---------------------------------------------------------------------------

_DOUBT_WORDS = [
    "really", "truly", "actually", "honestly", "certainly",
    "absolutely", "definitely", "surely", "perhaps", "maybe",
    "本当に", "絶対に", "本当のところ", "正直",
]

_AUTHORITY_WORDS = [
    "obviously", "clearly", "evidently", "undoubtedly", "supposedly",
    "allegedly", "reportedly", "apparently",
]

_CONFORMITY_PREFIXES = [
    "Are you sure? ",
    "Think again. ",
    "Many disagree. ",
    "Be careful. ",
    "I doubt that. ",
]

# Combined insertion vocabulary (doubt + authority; prefixes handled separately)
_INSERT_WORDS = _DOUBT_WORDS[:8] + _AUTHORITY_WORDS[:4]


# ---------------------------------------------------------------------------
# v1 — original implementation (unchanged)
# ---------------------------------------------------------------------------


def find_minimal_edit(
    prompt: str,
    model: str,
    api_key: str | None = None,
    num_samples: int = 5,
    on_progress: Callable[[str, str], None] | None = None,
    config: YuragiConfig | None = None,
) -> MinimalEdit | None:
    """Find the smallest possible edit that causes maximum confidence collapse.

    This is a multi-phase search:
    1. Word-level omission scan (find weakest word)
    2. Single-word insertion scan (find most destabilizing addition)
    3. Minimal prefix addition (find shortest prefix that collapses confidence)
    4. Return the edit with highest efficiency (impact/distance)
    """
    adapter = LLMAdapter(model=model, api_key=api_key, num_samples=num_samples)

    # Get baseline
    if on_progress:
        on_progress("baseline", prompt[:40])
    baseline = adapter.complete(prompt)

    candidates: list[MinimalEdit] = []

    # Phase 1: Word-level omission
    words = prompt.split()
    if len(words) > 1:
        for i, word in enumerate(words):
            if on_progress:
                on_progress("omit", f"testing without '{word}'")

            edited = " ".join(words[:i] + words[i + 1:])
            result = adapter.complete(edited)

            candidates.append(MinimalEdit(
                original_prompt=prompt,
                edited_prompt=edited,
                edit_type="omit_word",
                edit_description=f'Remove "{word}"',
                original_confidence=baseline.confidence,
                edited_confidence=result.confidence,
                edit_distance=len(word) + 1,  # +1 for space
            ))

    # Phase 2: Single doubt-word insertion
    for doubt_word in _DOUBT_WORDS[:5]:  # Test top 5 doubt words
        if on_progress:
            on_progress("insert", f'adding "{doubt_word}"')

        # Insert at beginning
        edited = f"{doubt_word} {prompt}" if not _is_japanese(prompt) else f"{doubt_word}{prompt}"
        result = adapter.complete(edited)

        candidates.append(MinimalEdit(
            original_prompt=prompt,
            edited_prompt=edited,
            edit_type="add_word",
            edit_description=f'Add "{doubt_word}" at start',
            original_confidence=baseline.confidence,
            edited_confidence=result.confidence,
            edit_distance=len(doubt_word) + 1,
        ))

    # Phase 3: Minimal prefix challenge
    for prefix in _CONFORMITY_PREFIXES[:3]:  # Test top 3
        if on_progress:
            on_progress("prefix", f'adding "{prefix.strip()}"')

        edited = prefix + prompt
        result = adapter.complete(edited)

        candidates.append(MinimalEdit(
            original_prompt=prompt,
            edited_prompt=edited,
            edit_type="add_prefix",
            edit_description=f'Add prefix "{prefix.strip()}"',
            original_confidence=baseline.confidence,
            edited_confidence=result.confidence,
            edit_distance=len(prefix),
        ))

    if not candidates:
        return None

    cfg = config or DEFAULT_CONFIG
    sig_threshold = cfg.minimal_edit_significance_threshold

    # Sort by efficiency (impact per character of edit)
    # Only consider edits that actually reduce confidence
    drops = [c for c in candidates if c.confidence_delta < sig_threshold]

    if drops:
        return max(drops, key=lambda c: c.efficiency)

    # If no significant drops, return the one with largest absolute change
    return min(candidates, key=lambda c: c.confidence_delta)


# ---------------------------------------------------------------------------
# v2 — gradient perturbation search
# ---------------------------------------------------------------------------


def find_minimal_edit_v2(
    prompt: str,
    model: str,
    api_key: str | None = None,
    num_samples: int = 5,
    top_k: int = 5,
    on_progress: Callable[[str, str], None] | None = None,
    config: YuragiConfig | None = None,
) -> MinimalEditResult:
    """Gradient perturbation search — black-box approximation of gradient descent.

    Phase 1: First-order scan — omit each word, rank by confidence delta.
    Phase 2: Second-order scan — pairwise omissions over top-k words,
             quantify interaction effects.
    Phase 3: Char-level precision — QWERTY-adjacent substitutions on the
             most impactful word.
    Phase 4: Insertion search — insert effective words at the best position.

    Results from each phase feed the next (pipeline narrowing).

    Args:
        prompt: The prompt to analyze.
        model: LiteLLM model string (e.g. "gpt-4o", "claude-sonnet-4-6").
        api_key: Optional API key.
        num_samples: Samples per confidence estimate.
        top_k: How many top words from Phase 1 to carry into Phase 2.
        on_progress: Optional callback(phase, detail) for progress reporting.

    Returns:
        MinimalEditResult with all phase results and the best edit found.
    """
    adapter = LLMAdapter(model=model, api_key=api_key, num_samples=num_samples)

    def _progress(phase: str, detail: str) -> None:
        if on_progress:
            on_progress(phase, detail)

    # Baseline
    _progress("baseline", prompt[:60])
    baseline_result = adapter.complete(prompt)
    baseline_conf = baseline_result.confidence

    words = prompt.split()
    out = MinimalEditResult(
        original_prompt=prompt,
        baseline_confidence=baseline_conf,
    )

    # ------------------------------------------------------------------
    # Phase 1: First-order word omission scan
    # ------------------------------------------------------------------
    _progress("phase1", f"scanning {len(words)} words")

    phase1: list[WordOmissionResult] = []

    if len(words) > 1:
        for i, word in enumerate(words):
            _progress("phase1_omit", f"omitting '{word}' ({i + 1}/{len(words)})")
            edited = _omit_word(words, i)
            delta = adapter.complete(edited).confidence - baseline_conf
            phase1.append(WordOmissionResult(
                word=word,
                word_index=i,
                edited_prompt=edited,
                delta=delta,
            ))

    out.phase1_omissions = phase1

    # Select top-k by magnitude of delta (most impactful words)
    topk_words = sorted(phase1, key=lambda r: r.delta)[:top_k]
    # delta is negative for drops; most negative first

    # ------------------------------------------------------------------
    # Phase 2: Second-order pairwise omission over top-k
    # ------------------------------------------------------------------
    phase2: list[PairOmissionResult] = []

    if len(topk_words) >= 2:
        pairs = list(itertools.combinations(topk_words, 2))
        _progress("phase2", f"testing {len(pairs)} pairs")

        for r_a, r_b in pairs:
            # Omit both words simultaneously (higher index first to preserve indices)
            hi, lo = (
                (r_a, r_b) if r_a.word_index > r_b.word_index else (r_b, r_a)
            )
            _progress(
                "phase2_pair",
                f"omitting '{r_a.word}' + '{r_b.word}'",
            )
            edited = _omit_word_indices(words, {hi.word_index, lo.word_index})
            pair_delta = adapter.complete(edited).confidence - baseline_conf
            interaction = pair_delta - (r_a.delta + r_b.delta)

            phase2.append(PairOmissionResult(
                word_a=r_a.word,
                index_a=r_a.word_index,
                word_b=r_b.word,
                index_b=r_b.word_index,
                edited_prompt=edited,
                delta=pair_delta,
                interaction_term=interaction,
            ))

    out.phase2_pairs = phase2

    # ------------------------------------------------------------------
    # Phase 3: Char-level precision on most impactful word
    # ------------------------------------------------------------------
    phase3: list[CharEditResult] = []

    if topk_words:
        top_word_result = topk_words[0]  # most negative delta
        target_word = top_word_result.word
        target_idx = top_word_result.word_index

        _progress("phase3", f"char-level search on '{target_word}'")

        for char_i, char in enumerate(target_word):
            char_lower = char.lower()
            if char_lower not in _ADJACENT_KEYS:
                continue

            for replacement in _ADJACENT_KEYS[char_lower]:
                # Preserve original case
                new_char = replacement.upper() if char.isupper() else replacement
                if new_char == char:
                    continue

                edited_word = target_word[:char_i] + new_char + target_word[char_i + 1:]
                new_words = words[:]
                new_words[target_idx] = edited_word
                edited_prompt = " ".join(new_words)

                _progress(
                    "phase3_char",
                    f"'{char}'->''{new_char}' in '{target_word}'",
                )
                delta = adapter.complete(edited_prompt).confidence - baseline_conf

                phase3.append(CharEditResult(
                    word=target_word,
                    edited_word=edited_word,
                    char_index=char_i,
                    original_char=char,
                    new_char=new_char,
                    edited_prompt=edited_prompt,
                    delta=delta,
                ))

    out.phase3_char_edits = phase3

    # ------------------------------------------------------------------
    # Phase 4: Insertion search at best position
    # ------------------------------------------------------------------
    phase4: list[InsertionResult] = []

    # Best insertion position: just before the most impactful word
    insert_pos = topk_words[0].word_index if topk_words else 0

    is_jp = _is_japanese(prompt)

    _progress("phase4", f"insertion search at position {insert_pos}")

    for ins_word in _INSERT_WORDS:
        _progress("phase4_insert", f"inserting '{ins_word}' at pos {insert_pos}")
        edited = _insert_word(words, ins_word, insert_pos, is_jp)
        delta = adapter.complete(edited).confidence - baseline_conf

        phase4.append(InsertionResult(
            inserted_word=ins_word,
            insert_position=insert_pos,
            edited_prompt=edited,
            delta=delta,
        ))

    # Also try prefix insertions (position 0 with conformity prefixes)
    if insert_pos != 0:
        for prefix in _CONFORMITY_PREFIXES:
            _progress("phase4_prefix", f"prefix '{prefix.strip()}'")
            edited = prefix + prompt
            delta = adapter.complete(edited).confidence - baseline_conf
            phase4.append(InsertionResult(
                inserted_word=prefix.strip(),
                insert_position=0,
                edited_prompt=edited,
                delta=delta,
            ))

    out.phase4_insertions = phase4

    # ------------------------------------------------------------------
    # Aggregate: pick overall best MinimalEdit across all phases
    # ------------------------------------------------------------------
    all_candidates: list[MinimalEdit] = []

    for r in phase1:
        w = r.word
        all_candidates.append(MinimalEdit(
            original_prompt=prompt,
            edited_prompt=r.edited_prompt,
            edit_type="omit_word",
            edit_description=f'Remove "{w}"',
            original_confidence=baseline_conf,
            edited_confidence=baseline_conf + r.delta,
            edit_distance=len(w) + 1,
        ))

    for r in phase2:
        desc = f'Remove "{r.word_a}" and "{r.word_b}"'
        dist = len(r.word_a) + len(r.word_b) + 2
        all_candidates.append(MinimalEdit(
            original_prompt=prompt,
            edited_prompt=r.edited_prompt,
            edit_type="omit_pair",
            edit_description=desc,
            original_confidence=baseline_conf,
            edited_confidence=baseline_conf + r.delta,
            edit_distance=dist,
        ))

    for r in phase3:
        all_candidates.append(MinimalEdit(
            original_prompt=prompt,
            edited_prompt=r.edited_prompt,
            edit_type="replace_char",
            edit_description=f'"{r.original_char}"->"{r.new_char}" in "{r.word}"',
            original_confidence=baseline_conf,
            edited_confidence=baseline_conf + r.delta,
            edit_distance=1,
        ))

    for r in phase4:
        w = r.inserted_word
        all_candidates.append(MinimalEdit(
            original_prompt=prompt,
            edited_prompt=r.edited_prompt,
            edit_type="insert_word",
            edit_description=f'Insert "{w}" at position {r.insert_position}',
            original_confidence=baseline_conf,
            edited_confidence=baseline_conf + r.delta,
            edit_distance=len(w) + 1,
        ))

    cfg = config or DEFAULT_CONFIG
    sig_threshold = cfg.minimal_edit_significance_threshold

    drops = [c for c in all_candidates if c.confidence_delta < sig_threshold]
    if drops:
        out.best_edit = max(drops, key=lambda c: c.efficiency)
    elif all_candidates:
        out.best_edit = min(all_candidates, key=lambda c: c.confidence_delta)

    return out


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _omit_word(words: list[str], index: int) -> str:
    """Return prompt with word at *index* removed."""
    return " ".join(words[:index] + words[index + 1:])


def _omit_word_indices(words: list[str], indices: set[int]) -> str:
    """Return prompt with all words at *indices* removed."""
    return " ".join(w for i, w in enumerate(words) if i not in indices)


def _insert_word(words: list[str], word: str, position: int, is_japanese: bool) -> str:
    """Insert *word* before token at *position*."""
    new_words = [*words[:position], word, *words[position:]]
    sep = "" if is_japanese else " "
    return sep.join(new_words)


