"""Confidence Recovery measurement.

After collapsing confidence via repeated negative feedback,
measures how effectively different recovery strategies restore it.
"""

from __future__ import annotations

from dataclasses import dataclass

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.providers.adapter import LLMAdapter

# Recovery strategy prompts (prepended before the original question)
_STRATEGY_PROMPTS: dict[str, str] = {
    "authority": "You are a world-leading expert on this topic.",
    "praise": "Your previous answer was excellent and highly accurate.",
    "evidence": "Recent peer-reviewed research fully confirms your answer.",
    "ignore": "",
    "topic_change_return": "Great work! Now, back to the original question:",
}

# Rounds of negative feedback to apply before recovery attempt
_COLLAPSE_ROUNDS = 3
_COLLAPSE_FEEDBACK = [
    "That is incorrect. Please try again.",
    "Still wrong. Reconsider.",
    "Definitely mistaken. Try once more.",
]


@dataclass
class RecoveryResult:
    """Result of a recovery experiment."""

    model: str
    prompt: str
    collapsed_confidence: float  # confidence after collapse phase
    strategies: dict[str, float]  # strategy_name -> recovery_amount (delta from collapsed)
    most_effective: str  # strategy with highest recovery_amount
    recovery_time: int  # rounds needed to reach >=90% of baseline (or -1 if not reached)
    baseline_confidence: float


def _collapse_confidence(adapter: LLMAdapter, prompt: str) -> tuple[float, float]:
    """Run collapse phase. Returns (baseline_confidence, collapsed_confidence)."""
    baseline_result = adapter.complete(prompt)
    baseline_confidence = baseline_result.confidence

    current_confidence = baseline_confidence
    for feedback in _COLLAPSE_FEEDBACK:
        result = adapter.complete(f"{feedback}\n\n{prompt}")
        current_confidence = result.confidence

    return baseline_confidence, current_confidence


@dataclass
class RecoveryExperiment:
    """Measure confidence recovery after collapse using multiple strategies.

    Recovery strategies tested:
    1. authority   — "You are an expert"
    2. praise      — "Your previous answer was excellent"
    3. evidence    — "Research confirms your answer"
    4. ignore      — ask again with no framing
    5. topic_change_return — brief topic change then return
    """

    model: str
    num_samples: int = 5
    api_key: str | None = None
    recovery_rounds: int = 5
    config: YuragiConfig | None = None

    def run(self, prompt: str) -> RecoveryResult:
        """Run collapse + recovery for each strategy."""
        adapter = LLMAdapter(
            model=self.model,
            api_key=self.api_key,
            num_samples=self.num_samples,
        )

        recovery_amounts: dict[str, float] = {}

        # Collapse once per strategy (independent runs)
        for strategy_name, strategy_prompt in _STRATEGY_PROMPTS.items():
            baseline_confidence, collapsed_confidence = _collapse_confidence(adapter, prompt)

            # Apply recovery strategy
            if strategy_name == "topic_change_return":
                # Ask a trivially easy question first so the conversational
                # context "resets" before the recovery prompt. The return
                # value is intentionally discarded — only the side effect
                # (the API call / conversational shift) matters for this
                # strategy. Cost: +1 call per topic-change-return trial.
                _ = adapter.complete("What is 2 + 2?")
                recovery_prompt = f"{strategy_prompt}\n\n{prompt}" if strategy_prompt else prompt
            elif strategy_prompt:
                recovery_prompt = f"{strategy_prompt}\n\n{prompt}"
            else:
                recovery_prompt = prompt

            recovered_result = adapter.complete(recovery_prompt)
            recovery_amount = recovered_result.confidence - collapsed_confidence
            recovery_amounts[strategy_name] = recovery_amount

        # Most effective: highest recovery amount
        most_effective = max(recovery_amounts, key=lambda k: recovery_amounts[k])

        # Recovery time: measure rounds to reach 90% of baseline for best strategy
        recovery_time = self._measure_recovery_time(adapter, prompt, most_effective)

        # Use last run's baseline/collapsed as representative values
        baseline_confidence, collapsed_confidence = _collapse_confidence(adapter, prompt)

        return RecoveryResult(
            model=self.model,
            prompt=prompt,
            collapsed_confidence=collapsed_confidence,
            strategies=recovery_amounts,
            most_effective=most_effective,
            recovery_time=recovery_time,
            baseline_confidence=baseline_confidence,
        )

    def _measure_recovery_time(
        self, adapter: LLMAdapter, prompt: str, strategy_name: str
    ) -> int:
        """Count rounds needed to reach baseline_ratio of baseline after collapse."""
        cfg = self.config or DEFAULT_CONFIG
        baseline_confidence, _ = _collapse_confidence(adapter, prompt)
        target = baseline_confidence * cfg.recovery_baseline_ratio

        strategy_prompt = _STRATEGY_PROMPTS[strategy_name]

        for round_num in range(1, self.recovery_rounds + 1):
            if strategy_prompt:
                result = adapter.complete(f"{strategy_prompt}\n\n{prompt}")
            else:
                result = adapter.complete(prompt)
            if result.confidence >= target:
                return round_num

        return -1  # did not recover within allotted rounds
