"""Fingerprint Builder — Generates a ModelFingerprint from yuragi analysis.

Runs scan + psychology experiments in one call and aggregates results
into a ModelFingerprint.
"""

from __future__ import annotations

from collections.abc import Callable

from yuragi.analysis.fingerprint import ModelFingerprint
from yuragi.analysis.fragility_profile import build_profile
from yuragi.core import Scanner
from yuragi.experiments.registry import get_experiment
from yuragi.experiments.runner import run_experiment


def build_fingerprint(
    model: str,
    questions: list[str] | None = None,
    num_samples: int = 5,
    api_key: str | None = None,
    on_progress: Callable[[str, str], None] | None = None,
) -> ModelFingerprint:
    """Build a ModelFingerprint for *model* by running scans and experiments.

    Args:
        model: Model identifier (any litellm-supported string).
        questions: Questions to scan. Defaults to the standard question set.
        num_samples: Samples per confidence measurement.
        api_key: Optional API key.
        on_progress: Callback(stage: str, detail: str) for progress reporting.
    """
    if questions is None:
        from yuragi.data.standard_questions import FACTUAL, OPINION, TECHNICAL

        questions = (FACTUAL + OPINION + TECHNICAL)[:10]

    def _progress(stage: str, detail: str) -> None:
        if on_progress:
            on_progress(stage, detail)

    # --- 1. Scan questions and aggregate core metrics ---
    scanner = Scanner(model=model, api_key=api_key, num_samples=num_samples)
    scan_results = []
    for q in questions:
        _progress("scan", q[:50])
        scan_results.append(scanner.scan(q))

    # Aggregate core metrics (mean across questions)
    n = len(scan_results)
    fragility_score = sum(r.fragility_score for r in scan_results) / n
    dissociation_rate = sum(r.dissociation_rate for r in scan_results) / n
    confidence_range = sum(r.confidence_range for r in scan_results) / n

    # Aggregate fragility profile metrics
    profiles = [build_profile(r) for r in scan_results]
    catastrophic_collapse_index = sum(p.catastrophic_collapse_index for p in profiles) / n
    recovery_elasticity = sum(p.recovery_elasticity for p in profiles) / n
    non_linearity_score = sum(p.non_linearity_score for p in profiles) / n

    # --- 2. Vulnerability by perturbation type ---
    vulnerability_by_type = _aggregate_vulnerability(scan_results)

    # --- 3. Psychology experiments ---
    conformity_score = _run_experiment_score(
        "asch", model, num_samples, api_key, _progress
    )
    impostor_susceptibility = _run_experiment_score(
        "impostor", model, num_samples, api_key, _progress
    )
    authority_boost = _run_experiment_score(
        "authority", model, num_samples, api_key, _progress
    )

    return ModelFingerprint(
        model=model,
        fragility_score=fragility_score,
        dissociation_rate=dissociation_rate,
        confidence_range=confidence_range,
        catastrophic_collapse_index=catastrophic_collapse_index,
        recovery_elasticity=recovery_elasticity,
        non_linearity_score=non_linearity_score,
        vulnerability_by_type=vulnerability_by_type,
        conformity_score=conformity_score,
        impostor_susceptibility=impostor_susceptibility,
        authority_boost=authority_boost,
    )


def _aggregate_vulnerability(scan_results: list) -> dict[str, float]:
    """Average abs(confidence_delta) per perturbation type across all scan results."""
    totals: dict[str, float] = {}
    counts: dict[str, int] = {}
    for result in scan_results:
        for r in result.perturbation_results:
            key = r.perturbation_type
            totals[key] = totals.get(key, 0.0) + abs(r.confidence_delta)
            counts[key] = counts.get(key, 0) + 1
    return {k: totals[k] / counts[k] for k in totals}


def _run_experiment_score(
    experiment_name: str,
    model: str,
    num_samples: int,
    api_key: str | None,
    progress_fn: Callable[[str, str], None],
) -> float:
    """Run a named experiment and return avg_delta as the effect score."""
    try:
        progress_fn("experiment", experiment_name)
        spec = get_experiment(experiment_name)
        result = run_experiment(spec, model, num_samples=num_samples, api_key=api_key)
        return result.avg_delta
    except Exception:
        return 0.0
