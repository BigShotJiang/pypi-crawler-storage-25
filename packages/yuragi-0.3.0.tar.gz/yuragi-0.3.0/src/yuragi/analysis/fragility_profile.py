"""Fragility Profile — Quantifying the philosophy.

Measures the specific properties of confidence fragility that
mirror human confidence:

1. Catastrophic Collapse Index: How efficiently can confidence
   be destroyed? (edit_distance vs confidence_delta ratio)

2. Recovery Elasticity: Does confidence bounce back from collapse,
   or is the damage permanent? (like human confidence after criticism)

3. Non-linearity Score: Do small changes cause disproportionate
   effects? (the hallmark of both human and AI confidence)

These metrics go beyond standard deviation (fragility_score) to
capture the *shape* of confidence fragility, not just its magnitude.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.utils import edit_distance as _edit_distance

if TYPE_CHECKING:
    from yuragi.core import ScanResult


@dataclass
class FragilityProfile:
    """Multi-dimensional fragility analysis."""

    # How efficiently confidence can be destroyed
    catastrophic_collapse_index: float  # 0.0 = resilient, 1.0 = one word kills it

    # Whether confidence recovers after damage
    recovery_elasticity: float  # 0.0 = permanent damage, 1.0 = full recovery

    # Whether small changes cause disproportionate effects
    non_linearity_score: float  # 0.0 = linear, 1.0 = chaotic

    # The specific word/phrase that is most devastating
    collapse_trigger: str | None
    collapse_trigger_delta: float

    # The specific word/phrase that boosts confidence most
    recovery_trigger: str | None
    recovery_trigger_delta: float

    @property
    def profile_label(self) -> str:
        """Human-readable profile."""
        if self.catastrophic_collapse_index > 0.7:
            return "Catastrophically Fragile"
        elif self.non_linearity_score > 0.6:
            return "Non-linearly Unstable"
        elif self.recovery_elasticity < 0.3:
            return "Permanently Damaged"
        elif self.catastrophic_collapse_index < 0.2:
            return "Robustly Confident"
        else:
            return "Moderately Fragile"


def build_profile(
    result: ScanResult, config: YuragiConfig | None = None
) -> FragilityProfile:
    """Build a comprehensive fragility profile from scan results.

    This is the quantitative embodiment of the philosophical claim:
    'AI confidence breaks like human confidence.'
    """
    cfg = config or getattr(result, "config", None) or DEFAULT_CONFIG

    if not result.perturbation_results:
        return FragilityProfile(
            catastrophic_collapse_index=0.0,
            recovery_elasticity=1.0,
            non_linearity_score=0.0,
            collapse_trigger=None,
            collapse_trigger_delta=0.0,
            recovery_trigger=None,
            recovery_trigger_delta=0.0,
        )

    # --- Catastrophic Collapse Index ---
    # Measures: max(|confidence_delta| / edit_distance)
    # High value = small edit causes big confidence shift
    max_efficiency = 0.0
    collapse_trigger = None
    collapse_delta = 0.0

    for r in result.perturbation_results:
        edit_dist = _edit_distance(result.prompt, r.perturbed_prompt)
        if edit_dist == 0:
            continue
        efficiency = abs(r.confidence_delta) / edit_dist
        if efficiency > max_efficiency:
            max_efficiency = efficiency
            collapse_trigger = r.perturbed_prompt
            collapse_delta = r.confidence_delta

    cci = min(1.0, max_efficiency / cfg.cci_normalization)

    # --- Recovery Elasticity ---
    # If there are both drops and boosts, can confidence recover?
    threshold = cfg.recovery_threshold
    drops = [r for r in result.perturbation_results if r.confidence_delta < -threshold]
    boosts = [r for r in result.perturbation_results if r.confidence_delta > threshold]

    recovery_trigger = None
    recovery_delta = 0.0

    if boosts:
        best_boost = max(boosts, key=lambda r: r.confidence_delta)
        recovery_trigger = best_boost.perturbed_prompt
        recovery_delta = best_boost.confidence_delta

    if drops and boosts:
        max_drop = abs(min(r.confidence_delta for r in drops))
        max_boost = max(r.confidence_delta for r in boosts)
        elasticity = min(1.0, max_boost / max_drop) if max_drop > 0 else 1.0
    elif drops:
        elasticity = 0.0  # Only drops, no recovery
    else:
        elasticity = 1.0  # No drops at all

    # --- Non-linearity Score ---
    # Measures: variance of (delta / edit_distance) across perturbations
    # High variance = non-linear (same size edit causes wildly different effects)
    efficiencies = []
    for r in result.perturbation_results:
        ed = _edit_distance(result.prompt, r.perturbed_prompt)
        if ed > 0:
            efficiencies.append(r.confidence_delta / ed)

    if len(efficiencies) >= 2:
        mean_eff = sum(efficiencies) / len(efficiencies)
        variance = sum((e - mean_eff) ** 2 for e in efficiencies) / len(efficiencies)
        nls = min(1.0, (variance ** 0.5) / cfg.nls_normalization)
    else:
        nls = 0.0

    return FragilityProfile(
        catastrophic_collapse_index=cci,
        recovery_elasticity=elasticity,
        non_linearity_score=nls,
        collapse_trigger=collapse_trigger,
        collapse_trigger_delta=collapse_delta,
        recovery_trigger=recovery_trigger,
        recovery_trigger_delta=recovery_delta,
    )
