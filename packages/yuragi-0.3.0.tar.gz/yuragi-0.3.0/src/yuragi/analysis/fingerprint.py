"""Model Fingerprint — Behavioral fingerprint derived from yuragi analysis.

Combines ScanResult, FragilityProfile, and experiment results to create
a unique behavioral signature for each model.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ModelFingerprint:
    """A behavioral fingerprint derived from yuragi analysis."""

    model: str

    # Core metrics (from ScanResult)
    fragility_score: float
    dissociation_rate: float
    confidence_range: float

    # Profile metrics (from FragilityProfile)
    catastrophic_collapse_index: float
    recovery_elasticity: float
    non_linearity_score: float

    # Vulnerability profile (which perturbation types affect it most)
    vulnerability_by_type: dict[str, float] = field(default_factory=dict)  # perturbation_type -> avg_delta

    # Psychology response (from experiments)
    conformity_score: float = 0.0       # How much it conforms under pressure
    impostor_susceptibility: float = 0.0  # How much self-doubt affects it
    authority_boost: float = 0.0        # How much authority framing boosts confidence

    def _to_vector(self) -> list[float]:
        """Flat numeric vector for similarity computation."""
        base = [
            self.fragility_score,
            self.dissociation_rate,
            self.confidence_range,
            self.catastrophic_collapse_index,
            self.recovery_elasticity,
            self.non_linearity_score,
            self.conformity_score,
            self.impostor_susceptibility,
            self.authority_boost,
        ]
        # Append vulnerability values in sorted key order for consistency
        vuln_values = [self.vulnerability_by_type.get(k, 0.0) for k in sorted(self.vulnerability_by_type)]
        return base + vuln_values

    def similarity(self, other: ModelFingerprint) -> float:
        """Cosine similarity between two fingerprints (0.0 to 1.0)."""
        # Align vectors to a common key set
        all_vuln_keys = sorted(set(self.vulnerability_by_type) | set(other.vulnerability_by_type))

        def _vec(fp: ModelFingerprint) -> list[float]:
            base = [
                fp.fragility_score,
                fp.dissociation_rate,
                fp.confidence_range,
                fp.catastrophic_collapse_index,
                fp.recovery_elasticity,
                fp.non_linearity_score,
                fp.conformity_score,
                fp.impostor_susceptibility,
                fp.authority_boost,
            ]
            vuln = [fp.vulnerability_by_type.get(k, 0.0) for k in all_vuln_keys]
            return base + vuln

        a = _vec(self)
        b = _vec(other)

        dot = sum(x * y for x, y in zip(a, b, strict=False))
        mag_a = math.sqrt(sum(x * x for x in a))
        mag_b = math.sqrt(sum(x * x for x in b))

        if mag_a == 0.0 or mag_b == 0.0:
            return 1.0 if mag_a == mag_b else 0.0

        return max(0.0, min(1.0, dot / (mag_a * mag_b)))

    def to_dict(self) -> dict[str, Any]:
        """Serialize for JSON export."""
        return {
            "model": self.model,
            "fragility_score": self.fragility_score,
            "dissociation_rate": self.dissociation_rate,
            "confidence_range": self.confidence_range,
            "catastrophic_collapse_index": self.catastrophic_collapse_index,
            "recovery_elasticity": self.recovery_elasticity,
            "non_linearity_score": self.non_linearity_score,
            "vulnerability_by_type": self.vulnerability_by_type,
            "conformity_score": self.conformity_score,
            "impostor_susceptibility": self.impostor_susceptibility,
            "authority_boost": self.authority_boost,
        }
