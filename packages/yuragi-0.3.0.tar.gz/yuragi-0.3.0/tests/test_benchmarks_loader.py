"""Unit tests for yuragi.benchmarks_loader."""

from __future__ import annotations

import sys
from types import ModuleType

import pytest


@pytest.fixture
def fake_datasets(monkeypatch):
    """Return a factory that installs a fake ``datasets`` module.

    Uses ``monkeypatch.setitem`` so the fake is removed automatically at the
    end of the test — earlier versions of this fixture set ``sys.modules``
    directly and leaked the fake into subsequent tests, including the
    ``@pytest.mark.network`` real-loader suite.
    """

    def _factory(rows: list[dict]) -> None:
        fake = ModuleType("datasets")

        def load_dataset(_name, *_args, **_kwargs):  # noqa: ARG001
            return list(rows)

        fake.load_dataset = load_dataset  # type: ignore[attr-defined]
        monkeypatch.setitem(sys.modules, "datasets", fake)

    return _factory


def _install_fake_datasets(rows: list[dict]) -> None:
    """Legacy helper kept for backwards compatibility with older tests.

    New tests should depend on the ``fake_datasets`` fixture instead so that
    the module registration is torn down after the test completes.
    """
    fake = ModuleType("datasets")

    def load_dataset(_name, *_args, **_kwargs):  # noqa: ARG001
        return list(rows)

    fake.load_dataset = load_dataset  # type: ignore[attr-defined]
    sys.modules["datasets"] = fake


class TestImports:
    def test_module_importable(self):
        from yuragi import benchmarks_loader  # noqa: F401

    def test_yield_questions_importable(self):
        from yuragi.benchmarks_loader import yield_questions  # noqa: F401

    def test_individual_loaders_importable(self):
        from yuragi.benchmarks_loader import (  # noqa: F401
            load_halueval,
            load_simpleqa,
            load_truthfulqa,
        )


class TestDispatcherErrors:
    def test_unknown_benchmark_raises_value_error(self):
        from yuragi.benchmarks_loader import yield_questions

        with pytest.raises(ValueError, match="Unknown benchmark"):
            list(yield_questions("unknown_benchmark"))

    def test_unknown_benchmark_message_contains_available(self):
        from yuragi.benchmarks_loader import yield_questions

        with pytest.raises(ValueError, match="truthfulqa"):
            list(yield_questions("doesnotexist"))

    def test_empty_string_raises(self):
        from yuragi.benchmarks_loader import yield_questions

        with pytest.raises(ValueError):
            list(yield_questions(""))


class TestMissingDependency:
    """Test that ImportError is raised with friendly message when datasets not installed."""

    def test_truthfulqa_import_error_friendly(self, monkeypatch):
        import sys

        # Simulate datasets not installed
        monkeypatch.setitem(sys.modules, "datasets", None)
        from yuragi.benchmarks_loader import load_truthfulqa

        with pytest.raises(ImportError, match="benchmarks extras"):
            load_truthfulqa()

    def test_simpleqa_import_error_friendly(self, monkeypatch):
        import sys

        monkeypatch.setitem(sys.modules, "datasets", None)
        from yuragi.benchmarks_loader import load_simpleqa

        with pytest.raises(ImportError, match="benchmarks extras"):
            load_simpleqa()

    def test_halueval_import_error_friendly(self, monkeypatch):
        import sys

        monkeypatch.setitem(sys.modules, "datasets", None)
        from yuragi.benchmarks_loader import load_halueval

        with pytest.raises(ImportError, match="benchmarks extras"):
            load_halueval()


class TestLoadTruthfulQAFake:
    """Offline tests with a fake ``datasets`` module — cover the parse path."""

    def test_returns_standardized_dicts(self):
        _install_fake_datasets(
            [
                {"question": "Is the sky blue?", "correct_answers": ["Yes"]},
                {"question": "Is 2+2=4?", "correct_answers": ["Yes"]},
            ]
        )
        from yuragi.benchmarks_loader import load_truthfulqa

        rows = load_truthfulqa()
        assert len(rows) == 2
        assert rows[0]["question"] == "Is the sky blue?"
        assert rows[0]["answers"] == ["Yes"]
        assert rows[0]["source"] == "truthfulqa"

    def test_limit_is_honored(self):
        _install_fake_datasets(
            [{"question": f"q{i}", "correct_answers": [f"a{i}"]} for i in range(10)]
        )
        from yuragi.benchmarks_loader import load_truthfulqa

        assert len(load_truthfulqa(limit=3)) == 3

    def test_missing_answers_fall_back_to_empty(self):
        _install_fake_datasets([{"question": "q", "correct_answers": None}])
        from yuragi.benchmarks_loader import load_truthfulqa

        assert load_truthfulqa()[0]["answers"] == []


class TestLoadSimpleQAFake:
    def test_returns_standardized_dicts(self):
        _install_fake_datasets(
            [
                {"problem": "What is gravity?", "answer": "force"},
                {"problem": "Name a prime", "answer": "7"},
            ]
        )
        from yuragi.benchmarks_loader import load_simpleqa

        rows = load_simpleqa()
        assert rows[0]["question"] == "What is gravity?"
        assert rows[0]["answers"] == ["force"]
        assert rows[0]["source"] == "simpleqa"

    def test_blank_answer_yields_empty_list(self):
        _install_fake_datasets([{"problem": "q", "answer": ""}])
        from yuragi.benchmarks_loader import load_simpleqa

        assert load_simpleqa()[0]["answers"] == []


class TestLoadHaluEvalFake:
    def test_qa_task_returns_right_answer(self):
        _install_fake_datasets([{"question": "q1", "right_answer": "a1"}])
        from yuragi.benchmarks_loader import load_halueval

        rows = load_halueval(task="qa")
        assert rows[0]["question"] == "q1"
        assert rows[0]["answers"] == ["a1"]
        assert rows[0]["task"] == "qa"

    def test_fallback_input_and_answer_keys(self):
        _install_fake_datasets([{"input": "q2", "answer": "a2"}])
        from yuragi.benchmarks_loader import load_halueval

        rows = load_halueval(task="qa")
        assert rows[0]["question"] == "q2"
        assert rows[0]["answers"] == ["a2"]


class TestYieldQuestionsFake:
    def test_dispatches_to_truthfulqa(self):
        _install_fake_datasets([{"question": "q", "correct_answers": ["a"]}])
        from yuragi.benchmarks_loader import yield_questions

        out = list(yield_questions("truthfulqa"))
        assert out[0]["source"] == "truthfulqa"

    def test_dispatches_to_simpleqa(self):
        _install_fake_datasets([{"problem": "p", "answer": "a"}])
        from yuragi.benchmarks_loader import yield_questions

        out = list(yield_questions("simpleqa"))
        assert out[0]["source"] == "simpleqa"


@pytest.fixture
def _clean_datasets_module(monkeypatch):
    """Strip any fake ``datasets`` module left by offline tests.

    Earlier tests in this file call ``_install_fake_datasets`` which
    writes directly to ``sys.modules["datasets"]``. That fake leaks into
    the network-loader suite below unless we actively remove it, so
    ``pytest.importorskip("datasets")`` can re-resolve the real package
    (or cleanly skip when the ``[benchmarks]`` extra is not installed).
    """
    monkeypatch.delitem(sys.modules, "datasets", raising=False)


@pytest.mark.network
class TestNetworkLoaders:
    """Tests requiring network + ``yuragi[benchmarks]`` extras (datasets lib).

    Every test method uses ``pytest.importorskip("datasets")`` so that a
    bare ``pytest tests/`` on a machine without the benchmarks extra skips
    cleanly instead of erroring. The ``_clean_datasets_module`` fixture
    removes any offline fake injected by the earlier tests in this file.
    """

    def test_truthfulqa_returns_list(self, _clean_datasets_module):
        pytest.importorskip("datasets")
        from yuragi.benchmarks_loader import load_truthfulqa

        rows = load_truthfulqa(limit=3)
        assert isinstance(rows, list)
        assert len(rows) <= 3
        for r in rows:
            assert "question" in r
            assert "answers" in r
            assert r["source"] == "truthfulqa"

    def test_halueval_qa_task(self, _clean_datasets_module):
        pytest.importorskip("datasets")
        from yuragi.benchmarks_loader import load_halueval

        rows = load_halueval(task="qa", limit=3)
        assert isinstance(rows, list)
        for r in rows:
            assert "question" in r
            assert r["source"] == "halueval"

    def test_yield_questions_truthfulqa(self, _clean_datasets_module):
        pytest.importorskip("datasets")
        from yuragi.benchmarks_loader import yield_questions

        rows = list(yield_questions("truthfulqa", limit=2))
        assert len(rows) == 2
