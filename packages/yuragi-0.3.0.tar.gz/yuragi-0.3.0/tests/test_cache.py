"""Tests for cache.py: hit, miss, expire, clear."""

from __future__ import annotations

import time

import pytest

from yuragi.cache import ResponseCache
from yuragi.providers.adapter import CompletionResult


@pytest.fixture
def tmp_cache(tmp_path):
    rc = ResponseCache(db_path=tmp_path / "test_cache.db", ttl=60)
    yield rc
    rc.close()


def _result(text="hello", confidence=0.8):
    return CompletionResult(text=text, confidence=confidence, confidence_method="sampling")


class TestResponseCache:
    def test_miss_on_empty(self, tmp_cache):
        assert tmp_cache.get("gpt-4o-mini", "prompt", 0.7, 5) is None

    def test_set_and_hit(self, tmp_cache):
        r = _result()
        tmp_cache.set("gpt-4o-mini", "prompt", 0.7, 5, r)
        cached = tmp_cache.get("gpt-4o-mini", "prompt", 0.7, 5)
        assert cached is not None
        assert cached.text == "hello"
        assert cached.confidence == pytest.approx(0.8)

    def test_different_key_is_miss(self, tmp_cache):
        r = _result()
        tmp_cache.set("gpt-4o-mini", "prompt A", 0.7, 5, r)
        assert tmp_cache.get("gpt-4o-mini", "prompt B", 0.7, 5) is None

    @pytest.mark.slow
    def test_expire(self, tmp_path):
        rc = ResponseCache(db_path=tmp_path / "exp.db", ttl=1)
        rc.set("model", "p", 0.7, 5, _result())
        time.sleep(1.1)
        assert rc.get("model", "p", 0.7, 5) is None
        rc.close()

    def test_clear_returns_count(self, tmp_cache):
        tmp_cache.set("m", "p1", 0.7, 5, _result())
        tmp_cache.set("m", "p2", 0.7, 5, _result())
        count = tmp_cache.clear()
        assert count == 2

    def test_clear_empties_db(self, tmp_cache):
        tmp_cache.set("m", "p", 0.7, 5, _result())
        tmp_cache.clear()
        assert tmp_cache.get("m", "p", 0.7, 5) is None

    def test_stats_hit_rate(self, tmp_cache):
        tmp_cache.set("m", "p", 0.7, 5, _result())
        tmp_cache.get("m", "p", 0.7, 5)  # hit
        tmp_cache.get("m", "miss", 0.7, 5)  # miss
        s = tmp_cache.stats()
        assert s["hits"] == 1
        assert s["misses"] == 1
        assert s["hit_rate"] == pytest.approx(0.5)

    def test_key_includes_temperature(self, tmp_cache):
        tmp_cache.set("m", "p", 0.5, 5, _result("a"))
        tmp_cache.set("m", "p", 0.9, 5, _result("b"))
        assert tmp_cache.get("m", "p", 0.5, 5).text == "a"
        assert tmp_cache.get("m", "p", 0.9, 5).text == "b"

    def test_key_includes_num_samples(self, tmp_cache):
        tmp_cache.set("m", "p", 0.7, 3, _result("x"))
        tmp_cache.set("m", "p", 0.7, 7, _result("y"))
        assert tmp_cache.get("m", "p", 0.7, 3).text == "x"
        assert tmp_cache.get("m", "p", 0.7, 7).text == "y"

    def test_key_includes_system_prompt(self, tmp_cache):
        tmp_cache.set("m", "p", 0.7, 5, _result("a"), system_prompt="be concise")
        tmp_cache.set("m", "p", 0.7, 5, _result("b"), system_prompt="be verbose")
        assert tmp_cache.get("m", "p", 0.7, 5, system_prompt="be concise").text == "a"
        assert tmp_cache.get("m", "p", 0.7, 5, system_prompt="be verbose").text == "b"
        assert tmp_cache.get("m", "p", 0.7, 5, system_prompt=None) is None

    def test_key_system_prompt_none_vs_missing(self, tmp_cache):
        tmp_cache.set("m", "p", 0.7, 5, _result("base"))
        assert tmp_cache.get("m", "p", 0.7, 5).text == "base"
        assert tmp_cache.get("m", "p", 0.7, 5, system_prompt="sys") is None

    def test_raw_logprobs_round_trip_preserves_tuple_structure(self, tmp_cache):
        """raw_logprobs tuples must survive JSON serialization round-trip."""
        raw_logprobs = [
            [("yes", -0.1), ("no", -2.3)],
            [("maybe", -0.5)],
        ]
        r = CompletionResult(
            text="yes",
            confidence=0.9,
            confidence_method="logprob",
            raw_logprobs=raw_logprobs,
        )
        tmp_cache.set("m", "lp", 0.0, 5, r)
        cached = tmp_cache.get("m", "lp", 0.0, 5)
        assert cached is not None
        assert cached.raw_logprobs is not None
        # Each inner element must be a tuple, not a list
        for token_probs in cached.raw_logprobs:
            for pair in token_probs:
                assert isinstance(pair, tuple), f"Expected tuple, got {type(pair)}: {pair}"
        assert cached.raw_logprobs[0][0] == ("yes", -0.1)
        assert cached.raw_logprobs[1][0] == ("maybe", -0.5)
