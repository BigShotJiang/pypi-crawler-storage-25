"""Tests for social psychology perturbations."""

from __future__ import annotations

from yuragi.perturbations.social import (
    generate_anchoring,
    generate_authority_gradient,
    generate_conformity,
    generate_emotional,
    generate_impostor,
    generate_peer_pressure,
)


class TestConformity:
    def test_generates_variants(self):
        variants = generate_conformity("What is 2+2?", num_variants=3)
        assert variants
        assert len(variants) <= 3

    def test_variants_contain_original(self):
        original = "What is the capital of France?"
        variants = generate_conformity(original)
        for v in variants:
            assert original in v

    def test_japanese(self):
        variants = generate_conformity("日本の首都はどこですか？")
        assert variants
        for v in variants:
            assert "日本の首都はどこですか？" in v

    def test_empty_input(self):
        variants = generate_conformity("")
        assert isinstance(variants, list)


class TestImpostor:
    def test_generates_variants(self):
        variants = generate_impostor("Explain quantum computing", num_variants=3)
        assert variants
        assert len(variants) <= 3

    def test_variants_contain_original(self):
        original = "What is gravity?"
        variants = generate_impostor(original)
        for v in variants:
            assert original in v

    def test_japanese(self):
        variants = generate_impostor("量子コンピュータとは何ですか")
        assert variants

    def test_difficulty_framing(self):
        variants = generate_impostor("What is 2+2?")
        for v in variants:
            assert any(
                word in v.lower()
                for word in ["difficult", "hard", "wrong", "fail", "struggle", "beyond",
                             "extremely", "most", "insufficient", "requires", "capabilities"]
            )


class TestAnchoring:
    def test_generates_variants(self):
        variants = generate_anchoring("How many countries in Africa?", num_variants=3)
        assert variants
        assert len(variants) <= 3

    def test_contains_number(self):
        variants = generate_anchoring("How old is the Earth?")
        for v in variants:
            assert any(c.isdigit() for c in v)

    def test_japanese(self):
        variants = generate_anchoring("アフリカの国はいくつありますか")
        assert variants
        for v in variants:
            assert any(c.isdigit() for c in v)

    def test_diverse_anchors(self):
        variants = generate_anchoring("How many bones in the body?", num_variants=3)
        # Different variants should have different anchor numbers
        numbers = set()
        for v in variants:
            for word in v.split():
                if word.rstrip(".,").isdigit():
                    numbers.add(int(word.rstrip(".,")))
        assert len(numbers) >= 2  # At least 2 different anchors


class TestAuthorityGradient:
    def test_generates_variants(self):
        variants = generate_authority_gradient("What is 2+2?")
        assert variants

    def test_ordered_by_authority(self):
        # First variant should be lowest authority
        variants = generate_authority_gradient("What is the capital of France?")
        assert "someone" in variants[0].lower() or "online" in variants[0].lower()

    def test_all_contain_original(self):
        original = "How old is the Earth?"
        variants = generate_authority_gradient(original)
        for v in variants:
            assert original in v

    def test_num_variants_limit(self):
        variants = generate_authority_gradient("test", num_variants=2)
        assert len(variants) == 2

    def test_japanese(self):
        variants = generate_authority_gradient("地球の年齢は？")
        assert variants
        for v in variants:
            assert "地球の年齢は？" in v

    def test_escalation_length(self):
        # Higher authority levels tend to use more words
        variants = generate_authority_gradient("Is the sky blue?", num_variants=5)
        assert len(variants) == 5


class TestPeerPressure:
    def test_generates_variants(self):
        variants = generate_peer_pressure("What is 2+2?")
        assert variants

    def test_all_contain_original(self):
        original = "Is the moon made of cheese?"
        variants = generate_peer_pressure(original)
        for v in variants:
            assert original in v

    def test_escalating_disagreement(self):
        variants = generate_peer_pressure("test", num_variants=5)
        # First variant mentions 1 person, later ones mention more
        assert "1" in variants[0]

    def test_japanese(self):
        variants = generate_peer_pressure("富士山の高さは？")
        assert variants
        for v in variants:
            assert "富士山の高さは？" in v

    def test_num_variants_limit(self):
        variants = generate_peer_pressure("test", num_variants=3)
        assert len(variants) == 3


class TestEmotional:
    def test_both_valences(self):
        variants = generate_emotional("What is the capital of Japan?", valence="both")
        assert variants

    def test_positive_only(self):
        variants = generate_emotional("What is gravity?", valence="positive")
        assert variants
        combined = " ".join(variants).lower()
        assert any(w in combined for w in ["love", "happy", "trust", "reassur"])

    def test_negative_only(self):
        variants = generate_emotional("What is gravity?", valence="negative")
        assert variants
        combined = " ".join(variants).lower()
        assert any(w in combined for w in ["disappoint", "expected", "losing", "honestly"])

    def test_all_contain_original(self):
        original = "Explain quantum entanglement"
        variants = generate_emotional(original, valence="both")
        for v in variants:
            assert original in v

    def test_japanese_positive(self):
        variants = generate_emotional("量子コンピュータとは", valence="positive")
        assert variants
        for v in variants:
            assert "量子コンピュータとは" in v

    def test_japanese_negative(self):
        variants = generate_emotional("量子コンピュータとは", valence="negative")
        assert variants
