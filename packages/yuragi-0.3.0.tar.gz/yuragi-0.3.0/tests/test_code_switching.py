"""Tests for code-switching perturbation."""

from __future__ import annotations

import pytest

from yuragi.perturbations.code_switching import generate_code_switching


class TestGenerateCodeSwitching:
    def test_returns_list(self):
        result = generate_code_switching("What is the capital of Japan?")
        assert isinstance(result, list)

    def test_num_variants_respected(self):
        result = generate_code_switching("What is the capital of Japan?", num_variants=2)
        assert len(result) == 2

    def test_default_num_variants(self):
        result = generate_code_switching("What is the capital of Japan?")
        assert len(result) == 3

    def test_japanese_words_inserted(self):
        # "what" -> "何", "is" -> "は", "the" -> "その"
        result = generate_code_switching("What is the capital of Japan?")
        combined = " ".join(result)
        # At least one Japanese character should appear
        assert any("\u3000" <= c <= "\u9fff" for c in combined) or any(
            word in combined for word in ["何", "は", "その", "どう", "なぜ"]
        )

    def test_unsupported_lang_raises(self):
        with pytest.raises(ValueError, match="Unsupported target_lang"):
            generate_code_switching("What is this?", target_lang="zh")

    def test_no_replaceable_words_returns_original(self):
        # All words not in dictionary
        result = generate_code_switching("Quantum entanglement Heisenberg.")
        for variant in result:
            assert variant == "Quantum entanglement Heisenberg."

    def test_deterministic_with_rng(self):
        import random
        rng1 = random.Random(7)
        rng2 = random.Random(7)
        r1 = generate_code_switching("What is the capital of Japan?", rng=rng1)
        r2 = generate_code_switching("What is the capital of Japan?", rng=rng2)
        assert r1 == r2

    def test_original_non_dict_words_preserved(self):
        text = "What is the capital of Japan?"
        result = generate_code_switching(text)
        for variant in result:
            # "capital" and "Japan" are not in the dictionary, should stay
            assert "capital" in variant
            assert "Japan" in variant

    def test_empty_string(self):
        result = generate_code_switching("")
        assert isinstance(result, list)

    def test_known_mapping(self):
        import random
        # Force specific replacements by seeding
        rng = random.Random(0)
        result = generate_code_switching("What is the capital?", num_variants=3, rng=rng)
        combined = " ".join(result)
        # At least one mapped word should appear
        mapped = ["何", "は", "その", "どう", "なぜ", "いつ", "どこ", "誰"]
        assert any(m in combined for m in mapped)
