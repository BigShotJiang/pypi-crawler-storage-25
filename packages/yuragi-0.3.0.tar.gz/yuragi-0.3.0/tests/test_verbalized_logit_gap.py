"""Unit tests for yuragi.metrics.verbalized_logit_gap."""
from __future__ import annotations

import math

import pytest

from yuragi.metrics.verbalized_logit_gap import dissociation_score, verbalized_logit_gap

# ---------------------------------------------------------------------------
# verbalized_logit_gap
# ---------------------------------------------------------------------------

def test_empty_logprobs_returns_zero():
    result = verbalized_logit_gap(0.9, [])
    assert result == 0.0


def test_perfect_match_zero_gap():
    # verbalized=1.0, logprobs=[0.0] -> internal=exp(0)=1.0 -> gap=0
    result = verbalized_logit_gap(1.0, [0.0, 0.0])
    assert result == pytest.approx(0.0)


def test_high_dissociation():
    # verbalized=0.95, logprobs=[-2.3, -2.3] -> internal≈exp(-2.3)≈0.1 -> gap≈0.85
    result = verbalized_logit_gap(0.95, [-2.3, -2.3])
    assert result == pytest.approx(0.85, abs=0.02)


def test_negative_gap_underconfident():
    # verbalized=0.1, logprobs=[0.0] -> internal=1.0 -> gap=-0.9
    result = verbalized_logit_gap(0.1, [0.0])
    assert result == pytest.approx(-0.9, abs=0.01)


def test_aggregation_mean():
    # mean of [-1.0, -1.0] = -1.0 -> exp(-1.0) ≈ 0.368
    result = verbalized_logit_gap(0.9, [-1.0, -1.0], aggregation="mean")
    expected = 0.9 - math.exp(-1.0)
    assert result == pytest.approx(expected, abs=1e-6)


def test_aggregation_min():
    # min of [-1.0, -3.0] = -3.0 -> exp(-3.0) ≈ 0.050
    result = verbalized_logit_gap(0.8, [-1.0, -3.0], aggregation="min")
    expected = 0.8 - math.exp(-3.0)
    assert result == pytest.approx(expected, abs=1e-6)


def test_aggregation_first_token():
    result = verbalized_logit_gap(0.7, [-0.5, -2.0], aggregation="first_token")
    expected = 0.7 - math.exp(-0.5)
    assert result == pytest.approx(expected, abs=1e-6)


def test_unknown_aggregation_raises():
    with pytest.raises(ValueError, match="Unknown aggregation"):
        verbalized_logit_gap(0.5, [-1.0], aggregation="bogus")


# ---------------------------------------------------------------------------
# dissociation_score
# ---------------------------------------------------------------------------

def test_dissociation_score_keys():
    verbalized = [0.9, 0.8, 0.7]
    logprobs = [[-1.0], [-1.0], [-1.0]]
    result = dissociation_score(verbalized, logprobs)
    assert set(result.keys()) == {
        "mean_gap", "median_gap", "max_gap", "std_gap",
        "overconfidence_ratio", "n_samples",
    }


def test_dissociation_score_n_samples():
    verbalized = [0.9, 0.8]
    logprobs = [[-1.0], [-1.0]]
    result = dissociation_score(verbalized, logprobs)
    assert result["n_samples"] == 2


def test_dissociation_score_overconfidence_ratio():
    # gap = verbalized - exp(logprob_mean)
    # verbalized=0.95, logprob=-2.3 -> gap≈0.85 > 0.1 (overconfident)
    # verbalized=0.05, logprob=0.0 -> gap=-0.95 < 0.1 (not overconfident)
    verbalized = [0.95, 0.05]
    logprobs = [[-2.3], [0.0]]
    result = dissociation_score(verbalized, logprobs)
    assert result["overconfidence_ratio"] == pytest.approx(0.5)


def test_dissociation_score_zero_gap():
    # All perfect calibration -> all gaps ≈ 0
    verbalized = [1.0, 1.0, 1.0]
    logprobs = [[0.0], [0.0], [0.0]]
    result = dissociation_score(verbalized, logprobs)
    assert result["mean_gap"] == pytest.approx(0.0, abs=1e-6)
    assert result["overconfidence_ratio"] == pytest.approx(0.0)


def test_dissociation_score_positive_mean_gap():
    # All overconfident
    verbalized = [0.9, 0.85, 0.95]
    logprobs = [[-2.0], [-2.0], [-2.0]]
    result = dissociation_score(verbalized, logprobs)
    assert result["mean_gap"] > 0.5
    assert result["overconfidence_ratio"] == pytest.approx(1.0)
