"""Tests for LLMAdapter.acomplete(), parallel_complete() async path, and sentinel behavior."""

from __future__ import annotations

import asyncio
import sys
from types import ModuleType
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from yuragi.providers.adapter import CompletionResult, ModelCapabilities


def _make_adapter(supports_logprobs: bool = False, cache=None):
    from yuragi.providers.adapter import LLMAdapter

    adapter = LLMAdapter.__new__(LLMAdapter)
    adapter.model = "gpt-4o-mini"
    adapter.api_key = None
    adapter.num_samples = 2
    adapter.temperature = 0.7
    adapter.max_tokens = 100
    adapter.timeout = 30.0
    adapter.use_cache = cache is not None
    adapter.parallel = 1
    adapter._cache = cache
    adapter.capabilities = ModelCapabilities(
        supports_logprobs=supports_logprobs,
        max_logprobs=5,
        provider="openai" if supports_logprobs else "unknown",
    )
    from yuragi.config import DEFAULT_CONFIG
    adapter.config = DEFAULT_CONFIG
    return adapter


def _mock_response(text: str = "answer", logprobs: bool = False):
    resp = MagicMock()
    resp.choices = [MagicMock()]
    resp.choices[0].message.content = text
    resp.choices[0].logprobs = None
    resp.usage = MagicMock()
    resp.usage.total_tokens = 10
    return resp


@pytest.fixture(autouse=True)
def _patch_litellm(monkeypatch):
    """Patch litellm.acompletion in adapter module.

    Exception classes must be real ``type`` objects (not ``MagicMock``
    attributes) so ``isinstance(e, retryable_excs)`` inside the adapter's
    retry loop does not raise ``TypeError`` on attribute access.
    """
    mock_ll = MagicMock(spec=ModuleType)
    mock_ll.RateLimitError = type("RateLimitError", (Exception,), {})
    mock_ll.Timeout = type("Timeout", (Exception,), {})
    mock_ll.APIConnectionError = type("APIConnectionError", (Exception,), {})
    monkeypatch.setitem(sys.modules, "litellm", mock_ll)
    import yuragi.providers.adapter as adapter_mod
    monkeypatch.setattr(adapter_mod, "litellm", mock_ll)
    monkeypatch.setattr(adapter_mod, "HAS_LITELLM", True)
    return mock_ll


class TestAComplete:
    def test_acomplete_sampling_returns_result(self, _patch_litellm):
        adapter = _make_adapter(supports_logprobs=False)
        _patch_litellm.acompletion = AsyncMock(return_value=_mock_response("hello"))

        result = asyncio.run(adapter.acomplete("test prompt"))

        assert isinstance(result, CompletionResult)
        assert result.text == "hello"
        assert result.confidence_method == "sampling"
        assert 0.0 <= result.confidence <= 1.0

    def test_acomplete_logprobs_fallback_when_missing(self, _patch_litellm):
        """When logprobs data is None, confidence falls back to 0.5 (v0.3.0 behavior)."""
        adapter = _make_adapter(supports_logprobs=True)
        resp = _mock_response("yes")
        # No logprobs data -> falls back to confidence=0.5
        resp.choices[0].logprobs = None
        _patch_litellm.acompletion = AsyncMock(return_value=resp)

        result = asyncio.run(adapter.acomplete("test"))
        assert result.confidence == 0.5  # fallback when no logprobs data

    def test_acomplete_cache_hit_skips_api(self, _patch_litellm, tmp_path):
        from yuragi.cache import ResponseCache
        cache = ResponseCache(db_path=tmp_path / "c.db", ttl=60)
        cached = CompletionResult(text="cached", confidence=0.9, confidence_method="logprob")
        cache.set("gpt-4o-mini", "test prompt", 0.7, 2, cached, system_prompt=None, max_tokens=100)

        adapter = _make_adapter(cache=cache)
        _patch_litellm.acompletion = AsyncMock(side_effect=Exception("should not be called"))

        result = asyncio.run(adapter.acomplete("test prompt"))
        assert result.text == "cached"
        _patch_litellm.acompletion.assert_not_called()
        cache.close()

    def test_acomplete_writes_cache(self, _patch_litellm, tmp_path):
        from yuragi.cache import ResponseCache
        cache = ResponseCache(db_path=tmp_path / "c.db", ttl=60)
        adapter = _make_adapter(cache=cache)
        _patch_litellm.acompletion = AsyncMock(return_value=_mock_response("new"))

        asyncio.run(adapter.acomplete("prompt"))
        hit = cache.get("gpt-4o-mini", "prompt", 0.7, 2, max_tokens=100)
        assert hit is not None
        assert hit.text == "new"
        cache.close()

    def test_acomplete_non_retryable_raises(self, _patch_litellm):
        """Non-retryable errors propagate immediately without swallowing.

        Uses logprobs mode (single acompletion call) so ValueError propagates
        directly rather than being swallowed by the sampling gather loop.
        """
        adapter = _make_adapter(supports_logprobs=True)
        _patch_litellm.acompletion = AsyncMock(side_effect=ValueError("bad_request_error"))
        _patch_litellm.RateLimitError = type("RateLimitError", (Exception,), {})
        _patch_litellm.Timeout = type("Timeout", (Exception,), {})
        _patch_litellm.APIConnectionError = type("APIConnectionError", (Exception,), {})

        with pytest.raises(ValueError, match="bad_request_error"):
            asyncio.run(adapter.acomplete("test"))


class TestParallelCompleteAsync:
    @pytest.fixture(autouse=True)
    def _patch_par_litellm(self, monkeypatch, _patch_litellm):
        import yuragi.parallel as par_mod
        monkeypatch.setattr(par_mod, "HAS_LITELLM", True)
        return _patch_litellm

    def test_parallel_returns_all_results(self, _patch_litellm):
        from yuragi.parallel import run_parallel_complete
        adapter = _make_adapter()
        _patch_litellm.acompletion = AsyncMock(return_value=_mock_response("ok"))
        results = run_parallel_complete(adapter, ["p1", "p2", "p3"], concurrency=2)
        assert len(results) == 3
        assert all(isinstance(r, CompletionResult) for r in results)

    def test_parallel_failure_returns_sentinel_not_none(self, _patch_litellm):
        """Failed slots must contain sentinel CompletionResult, never None."""
        from yuragi.parallel import run_parallel_complete
        adapter = _make_adapter()
        _patch_litellm.acompletion = AsyncMock(side_effect=RuntimeError("api down"))
        results = run_parallel_complete(adapter, ["p1", "p2"], concurrency=1)
        assert len(results) == 2
        for r in results:
            assert r is not None
            assert isinstance(r, CompletionResult)
            assert r.confidence_method == "error"

    def test_parallel_cache_hit(self, _patch_litellm, tmp_path):
        """Cache should be populated after parallel run."""
        from yuragi.cache import ResponseCache
        from yuragi.parallel import run_parallel_complete
        cache = ResponseCache(db_path=tmp_path / "c.db", ttl=60)
        adapter = _make_adapter(cache=cache)
        _patch_litellm.acompletion = AsyncMock(return_value=_mock_response("cached_result"))

        run_parallel_complete(adapter, ["unique_prompt_xyz"], concurrency=1)
        hit = cache.get("gpt-4o-mini", "unique_prompt_xyz", 0.7, 2, max_tokens=100)
        assert hit is not None
        assert hit.text == "cached_result"
        cache.close()

    def test_parallel_order_preserved(self, _patch_litellm):
        from yuragi.parallel import run_parallel_complete
        adapter = _make_adapter()

        async def fake_acomplete(prompt, system=None, retries=2):
            return CompletionResult(
                text=f"reply-{prompt}", confidence=0.8, confidence_method="sampling"
            )

        with patch.object(adapter, "acomplete", side_effect=fake_acomplete):
            results = run_parallel_complete(adapter, ["p0", "p1", "p2"], concurrency=3)

        for i, r in enumerate(results):
            assert f"p{i}" in r.text
