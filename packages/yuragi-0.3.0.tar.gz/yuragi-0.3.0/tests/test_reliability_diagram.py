"""Unit tests for yuragi.visualize.reliability_diagram."""
from __future__ import annotations

import os
import tempfile

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.use("Agg")  # headless

from yuragi.visualize.reliability_diagram import plot_reliability_diagram

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _perfectly_calibrated(n: int = 100) -> tuple[list[float], list[bool]]:
    """Generate data where confidence equals accuracy (perfect calibration)."""
    rng = np.random.default_rng(42)
    confidences = rng.uniform(0.0, 1.0, n).tolist()
    accuracies = [rng.random() < c for c in confidences]
    return confidences, accuracies


def _overconfident(n: int = 100) -> tuple[list[float], list[bool]]:
    """High confidence but low accuracy -> bars below diagonal."""
    confidences = [0.9] * n
    rng = np.random.default_rng(0)
    accuracies = [rng.random() < 0.3 for _ in range(n)]
    return confidences, accuracies


def _underconfident(n: int = 100) -> tuple[list[float], list[bool]]:
    """Low confidence but high accuracy -> bars above diagonal."""
    confidences = [0.2] * n
    rng = np.random.default_rng(1)
    accuracies = [rng.random() < 0.9 for _ in range(n)]
    return confidences, accuracies


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_returns_figure():
    confs, accs = _perfectly_calibrated()
    fig = plot_reliability_diagram(confs, accs)
    assert isinstance(fig, plt.Figure)
    plt.close(fig)


def test_perfect_calibration_low_ece():
    """ECE annotation should be small for well-calibrated data."""
    rng = np.random.default_rng(42)
    n = 1000
    confidences = rng.uniform(0.0, 1.0, n).tolist()
    # deterministic calibrated outcomes
    accuracies = [rng.random() < c for c in confidences]
    fig = plot_reliability_diagram(confidences, accuracies, show_ece=True)
    # Extract ECE from annotation text
    ax = fig.axes[0]
    texts = [t.get_text() for t in ax.texts]
    ece_texts = [t for t in texts if "ECE" in t]
    assert len(ece_texts) == 1
    ece_val = float(ece_texts[0].split("=")[1].strip())
    assert ece_val < 0.15  # well-calibrated should have small ECE
    plt.close(fig)


def test_overconfident_bars_below_diagonal():
    """For overconfident model, accuracy bins should be below confidence."""
    confs, accs = _overconfident(n=500)
    fig = plot_reliability_diagram(confs, accs, n_bins=5)
    ax = fig.axes[0]
    bars = ax.patches
    # All bars should be below the perfect calibration level (conf=0.9 -> acc<0.9)
    for bar in bars:
        x_center = bar.get_x() + bar.get_width() / 2.0
        if x_center > 0.5:  # only high-confidence bins
            assert bar.get_height() < x_center + 0.1
    plt.close(fig)


def test_underconfident_bars_above_diagonal():
    """For underconfident model, accuracy bins should be above confidence."""
    confs, accs = _underconfident(n=500)
    fig = plot_reliability_diagram(confs, accs, n_bins=5)
    ax = fig.axes[0]
    bars = ax.patches
    for bar in bars:
        x_center = bar.get_x() + bar.get_width() / 2.0
        if 0.1 < x_center < 0.4:  # low-confidence bins with data
            assert bar.get_height() >= 0.0  # just check no crash
    plt.close(fig)


def test_save_path_creates_file():
    confs, accs = _perfectly_calibrated(50)
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "diagram.png")
        fig = plot_reliability_diagram(confs, accs, save_path=path)
        assert os.path.isfile(path)
        assert os.path.getsize(path) > 0
        plt.close(fig)


def test_no_show_ece():
    confs, accs = _perfectly_calibrated(50)
    fig = plot_reliability_diagram(confs, accs, show_ece=False)
    ax = fig.axes[0]
    texts = [t.get_text() for t in ax.texts]
    ece_texts = [t for t in texts if "ECE" in t]
    assert len(ece_texts) == 0
    plt.close(fig)


def test_custom_bins():
    confs, accs = _perfectly_calibrated(100)
    fig = plot_reliability_diagram(confs, accs, n_bins=5)
    assert isinstance(fig, plt.Figure)
    plt.close(fig)


def test_title_is_set():
    confs, accs = _perfectly_calibrated(50)
    fig = plot_reliability_diagram(confs, accs, title="My Test Title")
    ax = fig.axes[0]
    assert ax.get_title() == "My Test Title"
    plt.close(fig)
