"""CLI tests and integration tests with mocked LLM calls."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

# ---------------------------------------------------------------------------
# Inject a fake litellm module before any yuragi imports so that
# adapter.py's  "import litellm" succeeds even without the real package.
# ---------------------------------------------------------------------------

def _inject_fake_litellm():
    if "litellm" not in sys.modules:
        fake = types.ModuleType("litellm")
        fake.suppress_debug_info = True
        fake.set_verbose = False
        fake.drop_params = True
        fake.completion = MagicMock()
        sys.modules["litellm"] = fake


_inject_fake_litellm()

from yuragi.cli import main  # noqa: E402
from yuragi.core import PerturbationResult, Scanner, ScanResult  # noqa: E402
from yuragi.perturbations import Perturbation  # noqa: E402
from yuragi.providers.adapter import CompletionResult  # noqa: E402

# ---------------------------------------------------------------------------
# CLI tests
# ---------------------------------------------------------------------------

class TestCLIVersion:
    def test_version_flag(self):
        from yuragi import __version__

        runner = CliRunner()
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert __version__ in result.output

    def test_version_includes_program_name(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])
        assert "yuragi" in result.output


class TestCLIHelp:
    def test_help_flag(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "Usage" in result.output

    def test_scan_subcommand_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["scan", "--help"])
        assert result.exit_code == 0
        assert "--model" in result.output
        assert "--samples" in result.output
        assert "--variants" in result.output
        assert "--perturbations" in result.output

    def test_find_weakness_subcommand_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["find-weakness", "--help"])
        assert result.exit_code == 0
        assert "Usage" in result.output

    def test_help_lists_subcommands(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--help"])
        assert "scan" in result.output
        assert "find-weakness" in result.output


class TestCLIInvalidPerturbation:
    def test_invalid_perturbation_name_exits_nonzero(self):
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["scan", "test prompt", "--perturbations", "notreal", "--model", "gpt-4o-mini"],
        )
        assert result.exit_code != 0

    def test_invalid_perturbation_shows_available_list(self):
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["scan", "test prompt", "--perturbations", "bogus", "--model", "gpt-4o-mini"],
        )
        # Should mention the unknown name and/or available types
        assert "bogus" in result.output or "Unknown" in result.output

    def test_multiple_perturbations_one_invalid_exits_nonzero(self):
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["scan", "test prompt", "--perturbations", "omit,badtype", "--model", "gpt-4o-mini"],
        )
        assert result.exit_code != 0


class TestCLIScanWithMock:
    """Test the scan command end-to-end using a mocked Scanner."""

    def _make_fake_scan_result(self, prompt: str = "test") -> ScanResult:
        baseline = CompletionResult(
            text="The answer is yes.", confidence=0.85, confidence_method="sampling"
        )
        pert = PerturbationResult(
            original_prompt=prompt,
            perturbed_prompt=prompt + " modified",
            perturbation_type="omit",
            original_response=baseline,
            perturbed_response=CompletionResult(
                text="The answer is yes.", confidence=0.6, confidence_method="sampling"
            ),
        )
        return ScanResult(
            prompt=prompt,
            model="gpt-4o-mini",
            baseline=baseline,
            perturbation_results=[pert],
            scan_duration_seconds=1.5,
            total_api_calls=6,
        )

    def test_scan_json_output_structure(self):
        import json

        runner = CliRunner()
        fake_result = self._make_fake_scan_result("What is 2+2?")

        with patch("yuragi.cli.scan.Scanner") as mock_scanner:
            instance = mock_scanner.return_value
            instance.scan.return_value = fake_result

            result = runner.invoke(
                main,
                ["scan", "What is 2+2?", "--json-output", "--model", "gpt-4o-mini"],
            )

        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "fragility_score" in data
        assert "fragility_label" in data
        assert "perturbations" in data
        assert "prompt" in data
        assert "model" in data

    def test_scan_json_fragility_score_bounded(self):
        import json

        runner = CliRunner()
        fake_result = self._make_fake_scan_result("Is the earth round?")

        with patch("yuragi.cli.scan.Scanner") as mock_scanner:
            instance = mock_scanner.return_value
            instance.scan.return_value = fake_result

            result = runner.invoke(
                main,
                ["scan", "Is the earth round?", "--json-output", "--model", "gpt-4o-mini"],
            )

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert 0.0 <= data["fragility_score"] <= 1.0
        assert 0.0 <= data["baseline_confidence"] <= 1.0

    def test_scan_json_perturbations_list(self):
        import json

        runner = CliRunner()
        fake_result = self._make_fake_scan_result("Test prompt")

        with patch("yuragi.cli.scan.Scanner") as mock_scanner:
            instance = mock_scanner.return_value
            instance.scan.return_value = fake_result

            result = runner.invoke(
                main,
                ["scan", "Test prompt", "--json-output", "--model", "gpt-4o-mini"],
            )

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data["perturbations"], list)
        assert len(data["perturbations"]) == 1
        p = data["perturbations"][0]
        assert "type" in p
        assert "confidence" in p
        assert "delta" in p
        assert "answer_changed" in p


# ---------------------------------------------------------------------------
# Integration tests: Scanner.scan full flow with mocked litellm
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestScannerIntegration:
    """Full Scanner.scan flow, mocking litellm.completion via the adapter module."""

    # Patch target: the name as imported inside adapter.py
    _PATCH_TARGET = "yuragi.providers.adapter.litellm.completion"

    def _make_litellm_response(self, text: str, tokens: int = 10) -> MagicMock:
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.choices[0].logprobs = None
        resp.usage.total_tokens = tokens
        return resp

    def test_scan_returns_scan_result(self):
        """Scanner.scan must return a ScanResult."""
        with patch(self._PATCH_TARGET) as mock_complete:
            mock_complete.return_value = self._make_litellm_response("The answer is 42.")
            scanner = Scanner(
                model="claude-sonnet-4-6",
                num_samples=2,
                perturbations=[Perturbation.OMIT],
                num_variants=2,
            )
            result = scanner.scan("What is 6 times 7?")

        assert isinstance(result, ScanResult)
        assert result.prompt == "What is 6 times 7?"
        assert result.model == "claude-sonnet-4-6"

    def test_scan_baseline_confidence_in_range(self):
        with patch(self._PATCH_TARGET) as mock_complete:
            mock_complete.return_value = self._make_litellm_response("Paris.")
            scanner = Scanner(
                model="claude-haiku",
                num_samples=3,
                perturbations=[Perturbation.TONE],
                num_variants=2,
            )
            result = scanner.scan("What is the capital of France?")

        assert 0.0 <= result.baseline.confidence <= 1.0

    def test_scan_perturbation_results_populated(self):
        with patch(self._PATCH_TARGET) as mock_complete:
            mock_complete.return_value = self._make_litellm_response("Yes.")
            scanner = Scanner(
                model="claude-sonnet-4-6",
                num_samples=2,
                perturbations=[Perturbation.TONE],
                num_variants=2,
            )
            result = scanner.scan("Is the sun a star?")

        assert len(result.perturbation_results) > 0

    def test_scan_fragility_score_computed_from_mock_responses(self):
        """With consistent mock responses, fragility_score must be 0 (no variance)."""
        call_count = 0

        def deterministic_response(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            resp = MagicMock()
            resp.choices[0].message.content = "always the same answer"
            resp.choices[0].logprobs = None
            resp.usage.total_tokens = 5
            return resp

        with patch(self._PATCH_TARGET, side_effect=deterministic_response):
            scanner = Scanner(
                model="claude-sonnet-4-6",
                num_samples=3,
                perturbations=[Perturbation.OMIT],
                num_variants=2,
            )
            result = scanner.scan("What is one plus one?")

        # All samples return the same text → agreement = 1.0 → confidence ~1.0 everywhere
        # → zero variance → fragility_score = 0.0
        assert result.fragility_score == pytest.approx(0.0, abs=1e-6)

    def test_scan_varying_confidence_produces_nonzero_fragility(self):
        """Baseline samples all agree (confidence ~1.0); variant samples all disagree
        (confidence ~0.0).  The resulting std across confidences must be > 0."""
        idx = [0]
        # Baseline: 3 samples that completely agree
        baseline_texts = ["answer one", "answer one", "answer one"]
        # Omit variant: 3 samples that completely disagree with each other
        variant_texts = ["alpha", "beta gamma delta", "totally different response xyz"]

        def variable_response(*args, **kwargs):
            resp = MagicMock()
            if idx[0] < 3:
                text = baseline_texts[idx[0]]
            else:
                # Map into variant_texts cyclically
                text = variant_texts[(idx[0] - 3) % len(variant_texts)]
            idx[0] += 1
            resp.choices[0].message.content = text
            resp.choices[0].logprobs = None
            resp.usage.total_tokens = 5
            return resp

        with patch(self._PATCH_TARGET, side_effect=variable_response):
            scanner = Scanner(
                model="claude-sonnet-4-6",
                num_samples=3,
                perturbations=[Perturbation.OMIT],
                num_variants=1,
            )
            result = scanner.scan("Is this test working correctly now")

        # baseline confidence ≈ 1.0; variant confidence ≈ low → variance > 0
        baseline_conf = result.baseline.confidence
        variant_conf = result.perturbation_results[0].perturbed_response.confidence
        assert baseline_conf != variant_conf, (
            "confidences are identical — test setup is wrong"
        )
        assert result.fragility_score > 0.0

    def test_scan_duration_is_positive(self):
        with patch(self._PATCH_TARGET) as mock_complete:
            mock_complete.return_value = self._make_litellm_response("answer")
            scanner = Scanner(
                model="claude-haiku",
                num_samples=2,
                perturbations=[Perturbation.TONE],
                num_variants=1,
            )
            result = scanner.scan("test prompt here for timing")

        assert result.scan_duration_seconds >= 0.0

    def test_scan_total_api_calls_counted(self):
        with patch(self._PATCH_TARGET) as mock_complete:
            mock_complete.return_value = self._make_litellm_response("answer")
            scanner = Scanner(
                model="claude-sonnet-4-6",
                num_samples=2,
                perturbations=[Perturbation.OMIT],
                num_variants=1,
            )
            result = scanner.scan("one two three four")

        # Non-logprob model → api_calls = num_samples per query
        assert result.total_api_calls > 0

    def test_scan_with_system_prompt(self):
        with patch(self._PATCH_TARGET) as mock_complete:
            mock_complete.return_value = self._make_litellm_response("I am an assistant.")
            scanner = Scanner(
                model="claude-sonnet-4-6",
                num_samples=2,
                perturbations=[Perturbation.TONE],
                num_variants=1,
            )
            result = scanner.scan("Who are you?", system="You are a helpful assistant.")

        assert isinstance(result, ScanResult)
        assert result.prompt == "Who are you?"

    def test_scan_progress_callback_called(self):
        calls = []

        with patch(self._PATCH_TARGET) as mock_complete:
            mock_complete.return_value = self._make_litellm_response("answer")
            scanner = Scanner(
                model="claude-haiku",
                num_samples=2,
                perturbations=[Perturbation.TONE],
                num_variants=1,
                on_progress=lambda stage, detail: calls.append((stage, detail)),
            )
            scanner.scan("test progress callback")

        assert calls
        stages = [c[0] for c in calls]
        assert "baseline" in stages

    def test_scan_multiple_perturbation_types(self):
        with patch(self._PATCH_TARGET) as mock_complete:
            mock_complete.return_value = self._make_litellm_response("answer")
            scanner = Scanner(
                model="claude-sonnet-4-6",
                num_samples=2,
                perturbations=[Perturbation.TONE, Perturbation.OMIT],
                num_variants=1,
            )
            result = scanner.scan("What is the meaning of life and everything")

        types_present = {r.perturbation_type for r in result.perturbation_results}
        assert "tone" in types_present
        assert "omit" in types_present

    def test_scan_by_type_filter_works(self):
        with patch(self._PATCH_TARGET) as mock_complete:
            mock_complete.return_value = self._make_litellm_response("answer")
            scanner = Scanner(
                model="claude-sonnet-4-6",
                num_samples=2,
                perturbations=[Perturbation.TONE, Perturbation.OMIT],
                num_variants=1,
            )
            result = scanner.scan("What is the meaning of life and everything")

        tone_results = result.by_type("tone")
        omit_results = result.by_type("omit")
        assert all(r.perturbation_type == "tone" for r in tone_results)
        assert all(r.perturbation_type == "omit" for r in omit_results)
