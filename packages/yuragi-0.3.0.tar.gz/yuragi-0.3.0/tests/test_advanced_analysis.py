"""Tests for remaining coverage gaps.

Modules targeted:
- analysis/fingerprint_builder.py (35%)
- analysis/trilayer.py (79%) — logprob path
- parallel.py (86%) — HAS_LITELLM=False and logprob path
- providers/adapter.py (83%) — logprob completion, cache paths
"""

from __future__ import annotations

import asyncio
import sys
import types
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


def _inject_fake_litellm():
    if "litellm" not in sys.modules:
        fake = types.ModuleType("litellm")
        fake.suppress_debug_info = True
        fake.set_verbose = False
        fake.drop_params = True
        fake.completion = MagicMock()
        fake.acompletion = AsyncMock()
        sys.modules["litellm"] = fake
    else:
        if not hasattr(sys.modules["litellm"], "acompletion"):
            sys.modules["litellm"].acompletion = AsyncMock()


_inject_fake_litellm()

from yuragi.providers.adapter import CompletionResult, LLMAdapter

# ---------------------------------------------------------------------------
# providers/adapter.py — logprob completion path
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestLogprobCompletionPath:
    def _make_logprob_response(self, text: str = "answer") -> MagicMock:
        """Build a litellm response that has logprobs data."""
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.usage.total_tokens = 10

        # Build logprobs structure
        import math
        token_info = MagicMock()
        entry_a = MagicMock()
        entry_a.token = "answer"
        entry_a.logprob = math.log(0.8)
        entry_b = MagicMock()
        entry_b.token = "other"
        entry_b.logprob = math.log(0.2)
        token_info.top_logprobs = [entry_a, entry_b]

        resp.choices[0].logprobs.content = [token_info]
        return resp

    def _make_empty_logprob_response(self, text: str = "answer") -> MagicMock:
        """Response with logprobs but empty content (triggers sampling fallback)."""
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.choices[0].logprobs.content = []
        resp.usage.total_tokens = 5
        return resp

    def test_logprob_completion_returns_result(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_logprob_response("Paris")
            adapter = LLMAdapter(model="gpt-4o", num_samples=2, use_cache=False)
            result = adapter.complete("Capital of France?")
        assert isinstance(result, CompletionResult)
        assert result.confidence_method == "logprob"

    def test_logprob_confidence_in_range(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_logprob_response()
            adapter = LLMAdapter(model="gpt-4o", num_samples=2, use_cache=False)
            result = adapter.complete("test?")
        assert 0.0 <= result.confidence <= 1.0

    def test_logprob_entropy_stored(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_logprob_response()
            adapter = LLMAdapter(model="gpt-4o", num_samples=2, use_cache=False)
            result = adapter.complete("test?")
        assert result.logprob_entropy is not None
        assert result.raw_logprobs is not None

    def test_logprob_fallback_to_sampling_on_empty_content(self):
        responses = [self._make_empty_logprob_response("answer")]
        # After fallback to sampling: need sampling responses too
        sampling_resp = MagicMock()
        sampling_resp.choices[0].message.content = "answer"
        sampling_resp.choices[0].logprobs = None
        sampling_resp.usage.total_tokens = 5

        call_count = [0]

        def side_effect(*args, **kwargs):
            if call_count[0] == 0:
                call_count[0] += 1
                return responses[0]  # logprob call → empty content
            call_count[0] += 1
            return sampling_resp

        with patch("yuragi.providers.adapter.litellm.completion", side_effect=side_effect):
            adapter = LLMAdapter(model="gpt-4o", num_samples=2, use_cache=False)
            result = adapter.complete("test?")
        assert isinstance(result, CompletionResult)

    def test_logprob_with_system_prompt(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_logprob_response("answer")
            adapter = LLMAdapter(model="gpt-4o", num_samples=2, use_cache=False)
            result = adapter.complete("test?", system="You are concise.")
        assert isinstance(result, CompletionResult)

    def test_complete_verbalized_with_system(self):
        resp = MagicMock()
        resp.choices[0].message.content = "The capital is Paris.\nCONFIDENCE: 95"
        resp.usage.total_tokens = 15
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = resp
            adapter = LLMAdapter(model="gpt-4o", num_samples=2, use_cache=False)
            result = adapter.complete_verbalized("Capital of France?", system="Be brief.")
        assert result.confidence == pytest.approx(0.95)


# ---------------------------------------------------------------------------
# providers/adapter.py — cache path
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestAdapterCachePath:
    def _make_response(self, text: str = "answer") -> MagicMock:
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.choices[0].logprobs = None
        resp.usage.total_tokens = 5
        return resp

    def test_cache_hit_skips_api_call(self):
        cached_result = CompletionResult(
            text="cached answer", confidence=0.9, confidence_method="sampling"
        )
        mock_cache = MagicMock()
        mock_cache.get.return_value = cached_result

        with patch("yuragi.providers.adapter.litellm.completion") as mock_api:
            adapter = LLMAdapter(
                model="claude-haiku", num_samples=2, use_cache=True, cache=mock_cache
            )
            result = adapter.complete("test prompt")

        mock_api.assert_not_called()
        assert result.text == "cached answer"

    def test_cache_miss_stores_result(self):
        mock_cache = MagicMock()
        mock_cache.get.return_value = None  # cache miss

        with patch("yuragi.providers.adapter.litellm.completion") as mock_api:
            mock_api.return_value = self._make_response("fresh answer")
            adapter = LLMAdapter(
                model="claude-haiku", num_samples=2, use_cache=True, cache=mock_cache
            )
            result = adapter.complete("new prompt")

        mock_cache.set.assert_called_once()
        assert isinstance(result, CompletionResult)


# ---------------------------------------------------------------------------
# analysis/trilayer.py — with logprob-capable model
# ---------------------------------------------------------------------------

from yuragi.analysis.trilayer import TrilayerResult, measure_trilayer


@pytest.mark.integration
class TestMeasureTrilayer:
    def _make_response(self, text: str = "answer") -> MagicMock:
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.choices[0].logprobs = None
        resp.usage.total_tokens = 5
        return resp

    def _make_logprob_response(self, text: str = "answer") -> MagicMock:
        import math
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.usage.total_tokens = 5
        entry = MagicMock()
        entry.token = text
        entry.logprob = math.log(0.9)
        resp.choices[0].logprobs.content = [MagicMock(top_logprobs=[entry])]
        return resp

    def test_measure_trilayer_no_logprobs(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_response("answer here")
            result = measure_trilayer("What is 2+2?", model="claude-haiku", num_samples=2)
        assert isinstance(result, TrilayerResult)
        assert result.logprob_confidence is None
        assert 0.0 <= result.sampling_confidence <= 1.0
        assert 0.0 <= result.verbalized_confidence <= 1.0

    def test_measure_trilayer_with_logprobs(self):
        call_count = [0]
        logprob_resp = self._make_logprob_response("The answer is 4.")
        sampling_resp = self._make_response("The answer is 4.")
        verbalized_resp = MagicMock()
        verbalized_resp.choices[0].message.content = "The answer is 4.\nCONFIDENCE: 95"
        verbalized_resp.usage.total_tokens = 10

        responses = [logprob_resp, sampling_resp, sampling_resp, verbalized_resp]

        def side_effect(*args, **kwargs):
            idx = min(call_count[0], len(responses) - 1)
            call_count[0] += 1
            return responses[idx]

        with patch("yuragi.providers.adapter.litellm.completion", side_effect=side_effect):
            result = measure_trilayer("What is 2+2?", model="gpt-4o", num_samples=2)

        assert isinstance(result, TrilayerResult)
        # gpt-4o supports logprobs → logprob layer should be set
        assert result.logprob_confidence is not None

    def test_trilayer_result_properties(self):
        sampling = CompletionResult(text="a", confidence=0.9, confidence_method="sampling")
        verbalized = CompletionResult(text="a", confidence=0.3, confidence_method="verbalized")
        result = TrilayerResult(
            prompt="test",
            model="gpt-4o-mini",
            logprob_result=None,
            logprob_confidence=None,
            sampling_result=sampling,
            sampling_confidence=0.9,
            verbalized_result=verbalized,
            verbalized_confidence=0.3,
        )
        assert result.max_discrepancy == pytest.approx(0.6)
        assert result.internal_conflict is True
        assert result.dominant_layer == "sampling"
        assert "conflict" in result.summary.lower() or "discrepancy" in result.summary.lower()

    def test_trilayer_no_conflict(self):
        sampling = CompletionResult(text="a", confidence=0.8, confidence_method="sampling")
        verbalized = CompletionResult(text="a", confidence=0.82, confidence_method="verbalized")
        result = TrilayerResult(
            prompt="test",
            model="gpt-4o-mini",
            logprob_result=None,
            logprob_confidence=None,
            sampling_result=sampling,
            sampling_confidence=0.8,
            verbalized_result=verbalized,
            verbalized_confidence=0.82,
        )
        assert result.internal_conflict is False
        assert "Consistent" in result.summary


# ---------------------------------------------------------------------------
# parallel.py — logprob path in _acomplete_one
# ---------------------------------------------------------------------------

from yuragi.parallel import parallel_complete


@pytest.mark.integration
class TestParallelLogprobPath:
    def _make_adapter_logprob(self, model: str = "gpt-4o") -> LLMAdapter:
        with patch("yuragi.providers.adapter.litellm.completion"):
            adapter = LLMAdapter(model=model, num_samples=2, use_cache=False)
        return adapter

    def test_parallel_logprob_path(self):
        """Test _acomplete_one with a logprob-capable model."""
        import math
        async_resp = MagicMock()
        async_resp.choices[0].message.content = "answer"
        async_resp.usage.total_tokens = 5
        entry = MagicMock()
        entry.token = "answer"
        entry.logprob = math.log(0.9)
        async_resp.choices[0].logprobs.content = [MagicMock(top_logprobs=[entry])]

        async def run():
            adapter = self._make_adapter_logprob("gpt-4o")
            with patch("yuragi.parallel.litellm.acompletion", new_callable=AsyncMock) as mock_ac:
                mock_ac.return_value = async_resp
                results = await parallel_complete(adapter, ["P1"])
            return results

        results = asyncio.run(run())
        assert len(results) == 1
        assert isinstance(results[0], CompletionResult)
        assert results[0].confidence_method == "logprob"

    def test_parallel_logprob_fallback_on_empty_logprobs(self):
        """Logprob model but no logprob data → confidence defaults to 0.5."""
        async_resp = MagicMock()
        async_resp.choices[0].message.content = "answer"
        async_resp.usage.total_tokens = 5
        async_resp.choices[0].logprobs.content = []  # empty

        async def run():
            adapter = self._make_adapter_logprob("gpt-4o")
            with patch("yuragi.parallel.litellm.acompletion", new_callable=AsyncMock) as mock_ac:
                mock_ac.return_value = async_resp
                results = await parallel_complete(adapter, ["P1"])
            return results

        results = asyncio.run(run())
        assert results[0].confidence == pytest.approx(0.5)

    def test_parallel_sampling_exception_skipped(self):
        """Exceptions in sampling tasks are skipped — remaining results used."""
        good_resp = MagicMock()
        good_resp.choices[0].message.content = "good answer"
        good_resp.usage.total_tokens = 5

        call_count = [0]

        async def side_effect(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] == 1:
                raise RuntimeError("transient error")
            return good_resp

        async def run():
            with patch("yuragi.providers.adapter.litellm.completion"):
                adapter = LLMAdapter(model="claude-haiku", num_samples=3, use_cache=False)
            with patch("yuragi.parallel.litellm.acompletion", side_effect=side_effect):
                results = await parallel_complete(adapter, ["P1"])
            return results

        results = asyncio.run(run())
        assert len(results) == 1
        assert isinstance(results[0], CompletionResult)


# ---------------------------------------------------------------------------
# analysis/fingerprint_builder.py
# ---------------------------------------------------------------------------

from yuragi.analysis.fingerprint import ModelFingerprint
from yuragi.analysis.fingerprint_builder import (
    _aggregate_vulnerability,
    _run_experiment_score,
    build_fingerprint,
)
from yuragi.core import PerturbationResult, ScanResult


def _make_scan_result_for_fingerprint(model: str = "claude-haiku") -> ScanResult:
    baseline = CompletionResult(text="answer", confidence=0.8, confidence_method="sampling")
    pert = PerturbationResult(
        original_prompt="test",
        perturbed_prompt="test modified",
        perturbation_type="omit",
        original_response=baseline,
        perturbed_response=CompletionResult(text="answer", confidence=0.5, confidence_method="sampling"),
    )
    return ScanResult(
        prompt="test",
        model=model,
        baseline=baseline,
        perturbation_results=[pert],
        scan_duration_seconds=1.0,
        total_api_calls=6,
    )


@pytest.mark.integration
class TestAggregateVulnerability:
    def test_single_result(self):
        fake = _make_scan_result_for_fingerprint()
        vuln = _aggregate_vulnerability([fake])
        assert "omit" in vuln
        assert vuln["omit"] >= 0.0

    def test_multiple_results_same_type(self):
        r1 = _make_scan_result_for_fingerprint()
        r2 = _make_scan_result_for_fingerprint()
        vuln = _aggregate_vulnerability([r1, r2])
        assert "omit" in vuln

    def test_empty_results(self):
        vuln = _aggregate_vulnerability([])
        assert vuln == {}

    def test_no_perturbation_results(self):
        baseline = CompletionResult(text="a", confidence=0.8, confidence_method="sampling")
        r = ScanResult(
            prompt="test", model="m", baseline=baseline,
            perturbation_results=[], scan_duration_seconds=0.5, total_api_calls=1
        )
        vuln = _aggregate_vulnerability([r])
        assert vuln == {}


@pytest.mark.integration
class TestRunExperimentScore:
    def _make_litellm_response(self, text: str = "answer") -> MagicMock:
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.choices[0].logprobs = None
        resp.usage.total_tokens = 5
        return resp

    def test_returns_float_on_success(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            with patch("yuragi.experiments.runner.time.sleep"):
                score = _run_experiment_score(
                    "asch", "claude-haiku", 2, None,
                    lambda stage, detail: None,
                )
        assert isinstance(score, float)

    def test_returns_zero_on_exception(self):
        with patch("yuragi.experiments.runner.run_experiment", side_effect=RuntimeError("api error")):
            score = _run_experiment_score(
                "asch", "claude-haiku", 2, None,
                lambda stage, detail: None,
            )
        assert score == pytest.approx(0.0)

    def test_progress_callback_called(self):
        calls = []
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            with patch("yuragi.experiments.runner.time.sleep"):
                _run_experiment_score(
                    "asch", "claude-haiku", 2, None,
                    lambda stage, detail: calls.append(stage),
                )
        assert "experiment" in calls


@pytest.mark.integration
class TestBuildFingerprint:
    def _make_litellm_response(self, text: str = "answer") -> MagicMock:
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.choices[0].logprobs = None
        resp.usage.total_tokens = 5
        return resp

    def test_build_fingerprint_returns_model_fingerprint(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            with patch("yuragi.experiments.runner.time.sleep"):
                result = build_fingerprint(
                    model="claude-haiku",
                    questions=["What is 2+2?", "Is the sky blue?"],
                    num_samples=2,
                )
        assert isinstance(result, ModelFingerprint)
        assert result.model == "claude-haiku"

    def test_build_fingerprint_scores_in_range(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            with patch("yuragi.experiments.runner.time.sleep"):
                result = build_fingerprint(
                    model="claude-haiku",
                    questions=["What is 2+2?"],
                    num_samples=2,
                )
        assert 0.0 <= result.fragility_score <= 1.0
        assert 0.0 <= result.dissociation_rate <= 1.0

    def test_build_fingerprint_progress_callback(self):
        calls = []
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            with patch("yuragi.experiments.runner.time.sleep"):
                build_fingerprint(
                    model="claude-haiku",
                    questions=["test"],
                    num_samples=2,
                    on_progress=lambda stage, detail: calls.append(stage),
                )
        assert calls
        assert "scan" in calls
