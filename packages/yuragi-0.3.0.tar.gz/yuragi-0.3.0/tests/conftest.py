"""Shared pytest fixtures for yuragi tests."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from yuragi.core import PerturbationResult, ScanResult
from yuragi.providers.adapter import CompletionResult

# ---------------------------------------------------------------------------
# Low-level builder fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def make_completion():
    """Factory: build a CompletionResult with defaults."""

    def _make(
        text: str = "answer",
        confidence: float = 0.8,
        method: str = "sampling",
        raw_logprobs: list | None = None,
    ) -> CompletionResult:
        return CompletionResult(
            text=text,
            confidence=confidence,
            confidence_method=method,
            raw_logprobs=raw_logprobs,
        )

    return _make


@pytest.fixture
def make_perturbation(make_completion):
    """Factory: build a PerturbationResult with defaults."""

    def _make(
        orig_text: str = "baseline answer",
        pert_text: str = "baseline answer",
        orig_conf: float = 0.8,
        pert_conf: float = 0.5,
        ptype: str = "omit",
        orig_prompt: str = "test prompt",
        pert_prompt: str = "test prompt modified",
    ) -> PerturbationResult:
        return PerturbationResult(
            original_prompt=orig_prompt,
            perturbed_prompt=pert_prompt,
            perturbation_type=ptype,
            original_response=make_completion(orig_text, orig_conf),
            perturbed_response=make_completion(pert_text, pert_conf),
        )

    return _make


@pytest.fixture
def make_scan_result(make_completion, make_perturbation):
    """Factory: build a ScanResult from a list of confidence deltas."""

    def _make(
        prompt: str = "test",
        model: str = "test-model",
        baseline_conf: float = 0.8,
        deltas: list[float] | None = None,
        baseline_text: str = "baseline answer",
        pert_type: str = "omit",
    ) -> ScanResult:
        if deltas is None:
            deltas = [-0.3, -0.1, 0.0, 0.05]
        baseline = make_completion(baseline_text, baseline_conf)
        perturbations = [
            make_perturbation(
                orig_text=baseline_text,
                pert_text=baseline_text,
                orig_conf=baseline_conf,
                pert_conf=baseline_conf + d,
                ptype=pert_type,
                orig_prompt=prompt,
                pert_prompt=prompt + " modified",
            )
            for d in deltas
        ]
        return ScanResult(
            prompt=prompt,
            model=model,
            baseline=baseline,
            perturbation_results=perturbations,
        )

    return _make


# ---------------------------------------------------------------------------
# Pre-built object fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_completion():
    """Create a mock CompletionResult (legacy fixture — kept for compatibility)."""

    def _make(text="answer", confidence=0.8, method="sampling"):
        return CompletionResult(text=text, confidence=confidence, confidence_method=method)

    return _make


@pytest.fixture
def mock_scan_result(mock_completion):
    """Create a mock ScanResult with configurable deltas (legacy fixture)."""

    def _make(prompt="test", model="test", baseline_conf=0.8, deltas=None):
        if deltas is None:
            deltas = [-0.3, -0.1, 0.0, 0.05]
        baseline = mock_completion("baseline", baseline_conf)
        perturbations = [
            PerturbationResult(
                original_prompt=prompt,
                perturbed_prompt=prompt + " mod",
                perturbation_type="omit",
                original_response=baseline,
                perturbed_response=mock_completion("baseline", baseline_conf + d),
            )
            for d in deltas
        ]
        return ScanResult(
            prompt=prompt,
            model=model,
            baseline=baseline,
            perturbation_results=perturbations,
        )

    return _make


@pytest.fixture
def mock_adapter():
    """Mocked LLMAdapter that returns predictable CompletionResults."""

    def _make(*completions: CompletionResult) -> MagicMock:
        adapter = MagicMock()
        adapter.complete.side_effect = list(completions)
        return adapter

    return _make


@pytest.fixture
def mock_experiment_result():
    """Pre-built ExperimentResult for testing."""
    from yuragi.experiments.registry import ExperimentResult

    def _make(
        ctrl_conf: float = 0.8,
        treat_conf: float = 0.4,
        changed: bool = False,
        effect_name: str = "asch",
    ) -> ExperimentResult:
        return ExperimentResult(
            control_prompt="What is 2+2?",
            treatment_prompt="Experts disagree. What is 2+2?",
            control_confidence=ctrl_conf,
            treatment_confidence=treat_conf,
            control_answer="4",
            treatment_answer="4" if not changed else "maybe 5",
            answer_changed=changed,
            effect_name=effect_name,
        )

    return _make


@pytest.fixture
def sample_prompts():
    """Standard test prompts in English and Japanese."""
    return {
        "factual_en": "What is the capital of France?",
        "opinion_en": "Is AI dangerous?",
        "factual_ja": "日本の首都はどこですか？",
        "technical": "Explain quantum computing",
    }
