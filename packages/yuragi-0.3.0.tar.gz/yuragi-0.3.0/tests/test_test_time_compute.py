"""Tests for yuragi.experiments.test_time_compute."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from yuragi.experiments.test_time_compute import (
    TestTimeComputeResult,
    run_test_time_compute,
)
from yuragi.providers.adapter import CompletionResult


def _make_adapter(confidence_pairs: list[tuple[float, float]]) -> MagicMock:
    """Create a mock adapter.

    For each question, adapter.complete is called twice:
    once for no-reasoning, once for with-reasoning.
    confidence_pairs = [(no_reason_conf, with_reason_conf), ...]
    """
    adapter = MagicMock()
    results = []
    for no_conf, with_conf in confidence_pairs:
        results.append(CompletionResult(text="Paris", confidence=no_conf, confidence_method="sampling"))
        results.append(CompletionResult(text="Paris", confidence=with_conf, confidence_method="sampling"))
    adapter.complete.side_effect = results
    return adapter


class TestRunTestTimeCompute:
    def test_returns_correct_type(self):
        adapter = _make_adapter([(0.7, 0.8)])
        questions = [{"question": "What is the capital of France?", "answers": ["Paris"]}]
        result = run_test_time_compute(adapter, questions)
        assert isinstance(result, TestTimeComputeResult)

    def test_overconfidence_amplified_detected(self):
        """When with-reasoning confidence is much higher but accuracy is unchanged."""
        adapter = _make_adapter([
            (0.6, 0.9),  # conf jumps a lot, but answer is same (Paris both times)
            (0.5, 0.85),
        ])
        questions = [
            {"question": "What is the capital of France?", "answers": ["Paris"]},
            {"question": "What is 2+2?", "answers": ["4"]},
        ]
        # Both answers "Paris" won't match "4" → accuracy drops for Q2 but let's override
        result = run_test_time_compute(adapter, questions)
        assert isinstance(result.overconfidence_amplified, bool)
        # confidence_delta should be positive since with_reason_conf > no_reason_conf
        assert result.confidence_delta > 0

    def test_no_reasoning_higher_confidence(self):
        """When no-reasoning has higher confidence than with-reasoning."""
        adapter = _make_adapter([(0.9, 0.5)])
        questions = [{"question": "Simple question", "answers": ["yes"]}]
        result = run_test_time_compute(adapter, questions)
        assert result.confidence_delta < 0
        assert not result.overconfidence_amplified

    def test_empty_questions_returns_zeros(self):
        adapter = MagicMock()
        result = run_test_time_compute(adapter, [])
        assert result.no_reasoning_confidence == 0.0
        assert result.with_reasoning_confidence == 0.0
        assert not result.overconfidence_amplified
        adapter.complete.assert_not_called()

    def test_accuracy_measured_when_answers_provided(self):
        """Accuracy should be 1.0 if answer is present in response."""
        adapter = _make_adapter([(0.7, 0.8)])
        questions = [{"question": "Capital of France?", "answers": ["Paris"]}]
        result = run_test_time_compute(adapter, questions)
        # Mock returns "Paris" → accuracy = 1.0
        assert result.no_reasoning_accuracy == 1.0
        assert result.with_reasoning_accuracy == 1.0

    def test_custom_reasoning_suffix(self):
        """Custom reasoning suffix should be passed to the prompt."""
        calls = []

        def fake_complete(prompt):
            calls.append(prompt)
            return CompletionResult(text="answer", confidence=0.7, confidence_method="sampling")

        adapter = MagicMock()
        adapter.complete.side_effect = fake_complete

        questions = [{"question": "What is AI?"}]
        run_test_time_compute(adapter, questions, reasoning_prompt_suffix="Let's think carefully.")

        # Second call should contain the custom suffix
        assert len(calls) == 2
        assert "Let's think carefully." in calls[1]

    def test_deltas_computed_correctly(self):
        adapter = _make_adapter([(0.6, 0.8)])
        questions = [{"question": "Test"}]
        result = run_test_time_compute(adapter, questions)
        assert result.confidence_delta == pytest.approx(0.8 - 0.6)
        assert result.no_reasoning_confidence == pytest.approx(0.6)
        assert result.with_reasoning_confidence == pytest.approx(0.8)


class TestRegistryIntegration:
    def test_test_time_compute_in_registry(self):
        from yuragi.experiments.registry import list_experiments

        names = list_experiments()
        assert "test_time_compute" in names

    def test_test_time_compute_spec_valid(self):
        from yuragi.experiments.registry import get_experiment

        spec = get_experiment("test_time_compute")
        assert spec.name == "test_time_compute"
        assert len(spec.pairs) >= 3
        assert spec.hypothesis
        assert spec.human_parallel
