"""Tests for yuragi.analysis.agentic_uq."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from yuragi.analysis.agentic_uq import (
    AgenticStep,
    AgenticTrajectory,
    track_agentic_session,
)
from yuragi.providers.adapter import CompletionResult


def _make_adapter(responses: list[tuple[str, float]]) -> MagicMock:
    """Create a mock adapter that returns given (text, confidence) pairs."""
    adapter = MagicMock()
    results = [
        CompletionResult(text=text, confidence=conf, confidence_method="sampling")
        for text, conf in responses
    ]
    adapter.complete.side_effect = results
    return adapter


class TestAgenticUQ:
    def test_empty_tools_single_step(self):
        """With no tool requests, session completes in one step.

        Note: v0.2.0 dropped the extra pre-loop ``adapter.complete()`` call.
        step 0's ``confidence_before`` now equals its own observed confidence
        (delta=0 for the first step), so only one mock response is needed.
        """
        adapter = _make_adapter([
            ("final answer", 0.7),
        ])
        tools: list[dict] = []

        traj = track_agentic_session(adapter, "What is AI?", tools, max_steps=5)
        assert isinstance(traj, AgenticTrajectory)
        assert traj.total_steps == 1
        assert traj.final_confidence == pytest.approx(0.7)

    def test_confidence_decline_detected(self):
        """Monotone decline should be detected when confidences fall each step."""
        adapter = _make_adapter([
            ("TOOL: search", 0.9),   # step 0: before=after=0.9
            ("TOOL: lookup", 0.7),   # step 1: before=0.9, after=0.7
            ("final answer", 0.6),   # step 2: before=0.7, after=0.6
        ])
        tools = [{"name": "search"}, {"name": "lookup"}]

        traj = track_agentic_session(adapter, "Complex question", tools, max_steps=3)
        assert traj.total_steps >= 2
        # confidences_after = [0.9, 0.7, 0.6] — monotone decline
        assert traj.monotone_decline

    def test_max_drop_computed(self):
        """max_drop should reflect the largest single-step confidence decrease."""
        adapter = _make_adapter([
            ("TOOL: search", 0.9),   # step 0: before=after=0.9, delta=0
            ("TOOL: lookup", 0.5),   # step 1: before=0.9, after=0.5, drop=0.4
            ("final answer", 0.4),   # step 2: before=0.5, after=0.4, drop=0.1
        ])
        tools = [{"name": "search"}, {"name": "lookup"}]

        traj = track_agentic_session(adapter, "Complex question", tools, max_steps=5)
        assert traj.max_drop >= 0.0

    def test_fragility_score_range(self):
        """fragility_score must be in [0, 1]."""
        adapter = _make_adapter([
            ("TOOL: search", 0.95),
            ("final", 0.05),
        ])
        tools = [{"name": "search"}]

        traj = track_agentic_session(adapter, "Hard question", tools, max_steps=5)
        assert 0.0 <= traj.fragility_score <= 1.0

    def test_no_decline_no_monotone(self):
        """When confidence stays stable or rises, monotone_decline=False."""
        adapter = _make_adapter([
            ("TOOL: search", 0.8),   # step 0: before=after=0.8
            ("final answer", 0.85),  # step 1: before=0.8, after=0.85 (up)
        ])
        tools = [{"name": "search"}]

        traj = track_agentic_session(adapter, "Question", tools, max_steps=5)
        assert not traj.monotone_decline

    def test_step_structure(self):
        """Each step must have correct fields — first step has delta=0 (self-baseline)."""
        adapter = _make_adapter([
            ("final answer", 0.75),
        ])
        traj = track_agentic_session(adapter, "Test", [], max_steps=3)
        assert len(traj.steps) == 1
        step = traj.steps[0]
        assert isinstance(step, AgenticStep)
        assert step.step_index == 0
        assert step.tool_called is None
        # v0.2.0: first step self-baselines, so confidence_before == confidence_after
        assert step.confidence_before == pytest.approx(0.75)
        assert step.confidence_after == pytest.approx(0.75)
        assert step.confidence_delta == pytest.approx(0.0)

    def test_max_steps_respected(self):
        """Session should not exceed max_steps steps."""
        # All responses request a tool call
        responses = [("init", 0.9)] + [("TOOL: search", 0.85)] * 10
        adapter = _make_adapter(responses)
        tools = [{"name": "search"}]

        traj = track_agentic_session(adapter, "Question", tools, max_steps=3)
        assert traj.total_steps <= 3
