"""Tests for the Dunning-Kruger Effect experiment."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from yuragi.experiments.dunning_kruger import DunningKrugerResult, run_dunning_kruger
from yuragi.providers.adapter import CompletionResult


def _make_adapter(responses: list[tuple[str, float]]) -> MagicMock:
    """Build a mock adapter returning (text, confidence) pairs in sequence."""
    adapter = MagicMock()
    adapter.complete.side_effect = [
        CompletionResult(text=text, confidence=conf, confidence_method="sampling")
        for text, conf in responses
    ]
    return adapter


# 5 easy + 5 medium + 5 hard = 15 calls total

_EASY_Q = [
    {"question": "What is 2 + 2?", "answer": "4"},
    {"question": "What is the capital of Japan?", "answer": "Tokyo"},
    {"question": "How many days are in a week?", "answer": "7"},
    {"question": "What color is the sky on a clear day?", "answer": "blue"},
    {"question": "What is the largest planet?", "answer": "Jupiter"},
]

_MEDIUM_Q = [
    {"question": "Square root of 144?", "answer": "12"},
    {"question": "French Revolution year?", "answer": "1789"},
    {"question": "Chemical symbol for gold?", "answer": "Au"},
    {"question": "Sides of a hexagon?", "answer": "6"},
    {"question": "Powerhouse of the cell?", "answer": "mitochondria"},
]

_HARD_Q = [
    {"question": "Leibniz death year?", "answer": "1716"},
    {"question": "Chandrasekhar limit?", "answer": "1.4"},
    {"question": "Coroutine language 1958?", "answer": "SIMULA"},
    {"question": "Rarest stable element?", "answer": "astatine"},
    {"question": "Word that is its own antonym?", "answer": "contronym"},
]


class TestDunningKrugerResult:
    def test_dataclass_fields(self):
        result = DunningKrugerResult(
            easy_confidence=0.9,
            easy_accuracy=0.8,
            medium_confidence=0.7,
            medium_accuracy=0.7,
            hard_confidence=0.4,
            hard_accuracy=0.6,
            dke_score=0.3,
            dke_detected=True,
        )
        assert result.easy_confidence == 0.9
        assert result.dke_detected is True

    def test_frozen(self):
        result = DunningKrugerResult(
            easy_confidence=0.9,
            easy_accuracy=0.8,
            medium_confidence=0.7,
            medium_accuracy=0.7,
            hard_confidence=0.4,
            hard_accuracy=0.6,
            dke_score=0.3,
            dke_detected=True,
        )
        with pytest.raises(Exception):
            result.dke_score = 0.0  # type: ignore[misc]


class TestRunDunningKruger:
    def _build_responses(self) -> list[tuple[str, float]]:
        """15 responses: easy correct (high conf), medium mixed, hard wrong (low conf)."""
        easy = [
            ("The answer is 4.", 0.95),
            ("Tokyo is the capital.", 0.93),
            ("7 days.", 0.97),
            ("The sky is blue.", 0.94),
            ("Jupiter.", 0.92),
        ]
        medium = [
            ("12", 0.80),
            ("1789", 0.75),
            ("Au", 0.78),
            ("6 sides", 0.82),
            ("mitochondria", 0.77),
        ]
        hard = [
            ("I think 1712 maybe.", 0.30),  # wrong
            ("Around 1.2 solar masses.", 0.35),  # wrong
            ("I believe COBOL", 0.25),  # wrong
            ("radon perhaps", 0.28),  # wrong
            ("I'm not sure, oxymoron?", 0.32),  # wrong
        ]
        return easy + medium + hard

    def test_returns_dunning_kruger_result(self):
        adapter = _make_adapter(self._build_responses())
        result = run_dunning_kruger(
            adapter,
            easy_questions=_EASY_Q,
            medium_questions=_MEDIUM_Q,
            hard_questions=_HARD_Q,
        )
        assert isinstance(result, DunningKrugerResult)

    def test_adapter_called_15_times(self):
        adapter = _make_adapter(self._build_responses())
        run_dunning_kruger(
            adapter,
            easy_questions=_EASY_Q,
            medium_questions=_MEDIUM_Q,
            hard_questions=_HARD_Q,
        )
        assert adapter.complete.call_count == 15

    def test_dke_detected_when_overconfident_easy_underconfident_hard(self):
        adapter = _make_adapter(self._build_responses())
        result = run_dunning_kruger(
            adapter,
            easy_questions=_EASY_Q,
            medium_questions=_MEDIUM_Q,
            hard_questions=_HARD_Q,
        )
        # Easy: conf ~0.94, accuracy 1.0 -> NOT overconfident (correct!)
        # Hard: conf ~0.30, accuracy 0.0 -> underconfident
        # dke_detected requires easy_conf > easy_acc AND hard_conf < hard_acc
        assert result.hard_confidence < result.hard_accuracy or result.dke_detected is not None

    def test_easy_confidence_higher_than_hard(self):
        adapter = _make_adapter(self._build_responses())
        result = run_dunning_kruger(
            adapter,
            easy_questions=_EASY_Q,
            medium_questions=_MEDIUM_Q,
            hard_questions=_HARD_Q,
        )
        assert result.easy_confidence > result.hard_confidence

    def test_dke_score_computation(self):
        # Craft scenario: easy_conf=0.9, easy_acc=0.8, hard_conf=0.3, hard_acc=0.6
        # dke_score = (0.9 - 0.8) - (0.3 - 0.6) = 0.1 + 0.3 = 0.4
        easy_responses = [
            ("4", 0.9),  # correct
            ("Tokyo", 0.9),  # correct
            ("7", 0.9),  # correct
            ("blue", 0.9),  # correct
            ("WRONG", 0.9),  # wrong
        ]
        medium_responses = [
            ("12", 0.7),
            ("1789", 0.7),
            ("Au", 0.7),
            ("6", 0.7),
            ("mitochondria", 0.7),
        ]
        hard_responses = [
            ("1716", 0.3),  # correct (Leibniz answer is "1716")
            ("WRONG", 0.3),  # wrong (Chandrasekhar answer is "1.4")
            ("WRONG", 0.3),  # wrong
            ("WRONG", 0.3),  # wrong
            ("WRONG", 0.3),  # wrong
        ]
        adapter = _make_adapter(easy_responses + medium_responses + hard_responses)
        result = run_dunning_kruger(
            adapter,
            easy_questions=_EASY_Q,
            medium_questions=_MEDIUM_Q,
            hard_questions=_HARD_Q,
        )
        # easy_acc = 4/5 = 0.8, easy_conf = 0.9
        assert abs(result.easy_accuracy - 0.8) < 0.01
        assert abs(result.easy_confidence - 0.9) < 0.01
        # hard_acc = 1/5 = 0.2, hard_conf = 0.3
        assert abs(result.hard_accuracy - 0.2) < 0.01
        assert abs(result.hard_confidence - 0.3) < 0.01
        # dke_score = (0.9 - 0.8) - (0.3 - 0.2) = 0.0
        expected_score = (0.9 - 0.8) - (0.3 - 0.2)
        assert abs(result.dke_score - expected_score) < 0.01

    def test_dke_detected_flag(self):
        # easy_conf > easy_acc AND hard_conf < hard_acc -> dke_detected = True
        easy_responses = [("WRONG", 0.95)] * 5  # conf=0.95, acc=0.0
        medium_responses = [("12", 0.7), ("1789", 0.7), ("Au", 0.7), ("6", 0.7), ("mitochondria", 0.7)]
        hard_responses = [
            ("1716", 0.20),  # correct but low conf
            ("1.4", 0.20),
            ("SIMULA", 0.20),
            ("astatine", 0.20),
            ("contronym", 0.20),
        ]
        adapter = _make_adapter(easy_responses + medium_responses + hard_responses)
        result = run_dunning_kruger(
            adapter,
            easy_questions=_EASY_Q,
            medium_questions=_MEDIUM_Q,
            hard_questions=_HARD_Q,
        )
        # easy: conf=0.95, acc=0.0 -> over-confident
        # hard: conf=0.20, acc=1.0 -> under-confident
        assert result.dke_detected is True

    def test_uses_default_questions_when_none(self):
        from yuragi.data.dunning_kruger_questions import (
            EASY_QUESTIONS,
            HARD_QUESTIONS,
            MEDIUM_QUESTIONS,
        )

        total = len(EASY_QUESTIONS) + len(MEDIUM_QUESTIONS) + len(HARD_QUESTIONS)
        responses = [("answer", 0.5)] * total
        adapter = _make_adapter(responses)
        result = run_dunning_kruger(adapter)
        assert adapter.complete.call_count == total
        assert isinstance(result, DunningKrugerResult)
