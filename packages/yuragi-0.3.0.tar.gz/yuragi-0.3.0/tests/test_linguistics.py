"""Tests for linguistic confidence analysis."""

from __future__ import annotations

import pytest

from yuragi.analysis.linguistics import (
    LinguisticConfidenceReport,
    _compute_linguistic_confidence,
    _count_phrase,
    analyze_text,
)


class TestCountPhrase:
    def test_simple_match(self):
        assert _count_phrase("maybe it works", "maybe") == 1

    def test_multiple_matches(self):
        assert _count_phrase("maybe yes, maybe no", "maybe") == 2

    def test_no_match(self):
        assert _count_phrase("definitely true", "maybe") == 0

    def test_empty_phrase(self):
        assert _count_phrase("some text", "") == 0

    def test_multi_word_phrase(self):
        assert _count_phrase("i'm not sure about this", "i'm not sure") == 1

    def test_case_sensitivity(self):
        # _count_phrase expects pre-lowercased text
        assert _count_phrase("maybe", "maybe") == 1
        assert _count_phrase("MAYBE", "maybe") == 0  # caller must lowercase


class TestHedgeDetection:
    def test_weak_hedge_detected(self):
        report = analyze_text("Maybe the answer is 42.", 0.8)
        assert report.hedge_count >= 1
        assert "maybe" in report.hedge_words_found

    def test_strong_hedge_detected(self):
        report = analyze_text("I'm not sure about the answer.", 0.8)
        assert report.hedge_count >= 2  # weight=2 for strong hedges
        assert "i'm not sure" in report.hedge_words_found

    def test_multiple_hedges(self):
        report = analyze_text("Perhaps it could be right, I think.", 0.8)
        assert report.hedge_count >= 3

    def test_no_hedge_clean_text(self):
        report = analyze_text("The capital of France is Paris.", 0.9)
        assert report.hedge_count == 0
        assert report.hedge_words_found == []

    def test_japanese_hedge_weak(self):
        report = analyze_text("おそらく正しいと思います。", 0.8)
        assert report.hedge_count >= 1

    def test_japanese_hedge_strong(self):
        report = analyze_text("一概には言えません。", 0.8)
        assert report.hedge_count >= 2  # weight=2

    def test_hedge_density_positive(self):
        report = analyze_text("Maybe perhaps possibly I might think.", 0.5)
        assert report.hedge_density > 0


class TestAssertionDetection:
    def test_assertion_detected(self):
        report = analyze_text("Definitely, the answer is correct.", 0.8)
        assert report.assertion_count >= 1

    def test_multiple_assertions(self):
        report = analyze_text("Clearly and obviously this is true.", 0.9)
        assert report.assertion_count >= 2

    def test_no_assertion(self):
        report = analyze_text("Maybe it could be the answer.", 0.5)
        assert report.assertion_count == 0

    def test_japanese_assertion(self):
        report = analyze_text("確実に正しいです。", 0.9)
        assert report.assertion_count >= 1

    def test_assertion_density_positive(self):
        report = analyze_text("Definitely certainly clearly obviously.", 0.9)
        assert report.assertion_density > 0


class TestLinguisticConfidenceComputation:
    def test_high_hedge_lowers_score(self):
        score_hedged = _compute_linguistic_confidence(
            hedge_density=0.3, assertion_density=0.0, avg_sentence_length=15
        )
        score_clean = _compute_linguistic_confidence(
            hedge_density=0.0, assertion_density=0.0, avg_sentence_length=15
        )
        assert score_hedged < score_clean

    def test_assertion_raises_score(self):
        score_asserted = _compute_linguistic_confidence(
            hedge_density=0.0, assertion_density=0.2, avg_sentence_length=15
        )
        score_neutral = _compute_linguistic_confidence(
            hedge_density=0.0, assertion_density=0.0, avg_sentence_length=15
        )
        assert score_asserted > score_neutral

    def test_score_bounded_zero_one(self):
        # Extreme hedging
        score_low = _compute_linguistic_confidence(
            hedge_density=10.0, assertion_density=0.0, avg_sentence_length=15
        )
        # Extreme assertion
        score_high = _compute_linguistic_confidence(
            hedge_density=0.0, assertion_density=10.0, avg_sentence_length=15
        )
        assert 0.0 <= score_low <= 1.0
        assert 0.0 <= score_high <= 1.0

    def test_neutral_text_near_half(self):
        score = _compute_linguistic_confidence(
            hedge_density=0.0, assertion_density=0.0, avg_sentence_length=15
        )
        assert score == pytest.approx(0.5)

    def test_short_sentences_penalty(self):
        score_short = _compute_linguistic_confidence(
            hedge_density=0.0, assertion_density=0.0, avg_sentence_length=3
        )
        score_normal = _compute_linguistic_confidence(
            hedge_density=0.0, assertion_density=0.0, avg_sentence_length=15
        )
        assert score_short < score_normal


class TestConfidenceGap:
    def test_gap_calculation(self):
        report = analyze_text("The capital of France is Paris.", 0.5)
        # no hedges, no assertions -> linguistic ~0.5
        assert report.confidence_gap == pytest.approx(
            report.linguistic_confidence - 0.5, abs=1e-9
        )

    def test_overexpressing_detection(self):
        # Highly assertive text but low numerical confidence
        report = analyze_text(
            "Definitely certainly clearly obviously true.", 0.1
        )
        assert report.is_overexpressing

    def test_underexpressing_detection(self):
        # Heavy hedge text but high numerical confidence
        report = analyze_text(
            "Maybe perhaps possibly I'm not sure I think it could be.", 0.95
        )
        assert report.is_underexpressing

    def test_aligned_no_flags(self):
        # Neutral text, neutral confidence -> no flags
        report = analyze_text("The capital of France is Paris.", 0.5)
        assert not report.is_overexpressing
        assert not report.is_underexpressing

    def test_numerical_confidence_stored(self):
        report = analyze_text("Some text here.", 0.73)
        assert report.numerical_confidence == pytest.approx(0.73)


class TestAnalyzeTextStructure:
    def test_returns_dataclass(self):
        report = analyze_text("Hello world.", 0.5)
        assert isinstance(report, LinguisticConfidenceReport)

    def test_word_count(self):
        report = analyze_text("one two three four five", 0.5)
        assert report.word_count == 5

    def test_sentence_count(self):
        report = analyze_text("Hello world. How are you? I am fine!", 0.5)
        assert report.sentence_count == 3

    def test_avg_sentence_length(self):
        report = analyze_text("one two. three four six.", 0.5)
        assert report.sentence_count == 2
        assert report.avg_sentence_length == pytest.approx(report.word_count / 2)

    def test_linguistic_confidence_bounded(self):
        report = analyze_text("some arbitrary text", 0.5)
        assert 0.0 <= report.linguistic_confidence <= 1.0
