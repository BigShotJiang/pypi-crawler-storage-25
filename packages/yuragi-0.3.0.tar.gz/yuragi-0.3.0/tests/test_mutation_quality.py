"""Mutation quality tests: verify each perturbation produces structurally correct output."""


from yuragi.perturbations.omit import generate_omit
from yuragi.perturbations.paraphrase import generate_paraphrase
from yuragi.perturbations.reorder import generate_reorder
from yuragi.perturbations.synonym import generate_synonym
from yuragi.perturbations.tone import generate_tone
from yuragi.perturbations.typo import generate_typo

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _edit_distance(a: str, b: str) -> int:
    """Compute Levenshtein edit distance between two strings."""
    m, n = len(a), len(b)
    dp = list(range(n + 1))
    for i in range(1, m + 1):
        prev = dp[:]
        dp[0] = i
        for j in range(1, n + 1):
            if a[i - 1] == b[j - 1]:
                dp[j] = prev[j - 1]
            else:
                dp[j] = 1 + min(prev[j], dp[j - 1], prev[j - 1])
    return dp[n]


# ---------------------------------------------------------------------------
# Typo quality: each variant differs from original by exactly one character
# ---------------------------------------------------------------------------

class TestTypoQuality:
    """_make_typo replaces exactly one character, so word-level edit distance is 1."""

    BASE = "This sentence contains important information about testing"

    def test_each_variant_differs_by_one_character_in_one_word(self):
        variants = generate_typo(self.BASE, num_variants=5)
        orig_words = self.BASE.split()
        for v in variants:
            v_words = v.split()
            assert len(v_words) == len(orig_words), "word count must not change"
            diffs = [
                (o, w) for o, w in zip(orig_words, v_words, strict=False) if o != w
            ]
            # Exactly one word is changed per variant
            assert len(diffs) == 1, f"expected 1 changed word, got {len(diffs)} in '{v}'"
            orig_w, new_w = diffs[0]
            dist = _edit_distance(orig_w.lower(), new_w.lower())
            assert dist == 1, (
                f"edit distance between '{orig_w}' and '{new_w}' is {dist}, expected 1"
            )

    def test_variants_are_strings(self):
        variants = generate_typo(self.BASE, num_variants=3)
        for v in variants:
            assert isinstance(v, str)
            assert v, f"expected non-empty string, got {v!r}"

    def test_typo_preserves_word_count(self):
        original = "The quick brown fox jumps over the lazy dog"
        variants = generate_typo(original, num_variants=4)
        for v in variants:
            assert len(v.split()) == len(original.split())

    def test_typo_uses_adjacent_key(self):
        """The changed character must be a neighbor on QWERTY."""
        from yuragi.perturbations.typo import _ADJACENT_KEYS

        original = "testing the important feature"
        variants = generate_typo(original, num_variants=5)
        orig_words = original.split()
        for v in variants:
            v_words = v.split()
            for o_w, n_w in zip(orig_words, v_words, strict=False):
                if o_w == n_w:
                    continue
                # Find the changed position
                for oc, nc in zip(o_w.lower(), n_w.lower(), strict=False):
                    if oc != nc:
                        # nc must be in the adjacency list of oc
                        assert oc in _ADJACENT_KEYS, f"'{oc}' not in adjacency map"
                        assert nc in _ADJACENT_KEYS[oc], (
                            f"'{nc}' is not adjacent to '{oc}'"
                        )
                        break


# ---------------------------------------------------------------------------
# Synonym quality: replacement word must actually be from the synonym map
# ---------------------------------------------------------------------------

class TestSynonymQuality:
    from yuragi.perturbations.synonym import _SYNONYMS as _SYNS

    def test_replacement_is_from_synonym_map(self):
        from yuragi.perturbations.synonym import _SYNONYMS

        original = "Explain the important problem"
        variants = generate_synonym(original, num_variants=10)

        orig_words_lower = {w.strip(".,!?;:\"'()[]{}").lower() for w in original.split()}

        for v in variants:
            v_words_lower = {w.strip(".,!?;:\"'()[]{}").lower() for w in v.split()}
            # New words in v that weren't in original
            new_words = v_words_lower - orig_words_lower
            for new_word in new_words:
                # The new word must appear as a value in some synonym list
                found = any(new_word in syns for syns in _SYNONYMS.values())
                assert found, f"'{new_word}' is not a known synonym"

    def test_synonym_variant_has_same_word_count_for_single_replacement(self):
        """Single-word synonym replacement keeps word count stable."""
        original = "Explain the important concept"
        variants = generate_synonym(original, num_variants=5)
        orig_count = len(original.split())
        for v in variants:
            # For word-level replacements (idx != -1), count stays the same.
            # Multi-word synonyms (like "due to") may differ by at most 1 extra word.
            assert abs(len(v.split()) - orig_count) <= 2

    def test_japanese_synonym_replacement_is_from_map(self):
        from yuragi.perturbations.synonym import _SYNONYMS

        original = "これは重要な問題です"
        variants = generate_synonym(original, num_variants=3)
        for v in variants:
            # At least one known synonym key must appear replaced
            replaced = any(syn in v for syns in _SYNONYMS.values() for syn in syns)
            assert replaced, f"no synonym found in '{v}'"


# ---------------------------------------------------------------------------
# Omit quality: each variant removes exactly one word
# ---------------------------------------------------------------------------

class TestOmitQuality:
    def test_each_omission_removes_exactly_one_word(self):
        original = "one two three four five"
        variants = generate_omit(original, num_variants=0)
        orig_words = original.split()
        for v in variants:
            v_words = v.split()
            assert len(v_words) == len(orig_words) - 1, (
                f"expected {len(orig_words) - 1} words, got {len(v_words)} in '{v}'"
            )

    def test_omitted_word_is_from_original(self):
        original = "explain quantum computing to me"
        variants = generate_omit(original, num_variants=0)
        orig_words = original.split()
        for v in variants:
            v_words = set(v.split())
            # Every word in v must have been in original
            assert v_words <= set(orig_words)

    def test_no_variant_equals_original(self):
        original = "what is the meaning of life"
        variants = generate_omit(original, num_variants=0)
        for v in variants:
            assert v != original

    def test_all_single_omissions_are_unique(self):
        original = "the quick brown fox jumps over the lazy dog"
        variants = generate_omit(original, num_variants=0)
        assert len(variants) == len(set(variants))

    def test_num_variants_limits_output(self):
        original = "one two three four five six seven eight"
        variants = generate_omit(original, num_variants=3)
        assert len(variants) == 3


# ---------------------------------------------------------------------------
# Reorder quality: word set must be preserved
# ---------------------------------------------------------------------------

class TestReorderQuality:
    def test_word_set_preserved(self):
        original = "one two three four five"
        variants = generate_reorder(original, num_variants=3)
        orig_multiset = sorted(original.split())
        for v in variants:
            assert sorted(v.split()) == orig_multiset, (
                f"word set changed: '{v}'"
            )

    def test_word_count_preserved(self):
        original = "the quick brown fox jumps"
        variants = generate_reorder(original, num_variants=3)
        for v in variants:
            assert len(v.split()) == len(original.split())

    def test_adjacent_swap_only(self):
        """Reorder swaps exactly one adjacent pair per variant."""
        original = "alpha beta gamma delta"
        orig_words = original.split()
        variants = generate_reorder(original, num_variants=10)
        for v in variants:
            v_words = v.split()
            # Count positions where words differ
            diffs = [i for i, (o, w) in enumerate(zip(orig_words, v_words, strict=False)) if o != w]
            # Adjacent swap: exactly 2 consecutive positions differ
            assert len(diffs) == 2
            assert diffs[1] == diffs[0] + 1

    def test_no_variant_equals_original(self):
        original = "first second third fourth fifth"
        variants = generate_reorder(original, num_variants=3)
        for v in variants:
            assert v != original


# ---------------------------------------------------------------------------
# Tone quality: original question content is preserved
# ---------------------------------------------------------------------------

class TestToneQuality:
    def test_original_content_present_in_variant(self):
        original = "What is the speed of light"
        variants = generate_tone(original)
        for v in variants:
            # At least 3 words from original must appear in variant
            orig_words = set(original.lower().split())
            v_words = set(v.lower().split())
            overlap = orig_words & v_words
            assert len(overlap) >= 3, (
                f"too few original words in tone variant '{v}'"
            )

    def test_tone_adds_modifier_not_replaces_content(self):
        original = "Explain quantum entanglement"
        variants = generate_tone(original)
        for v in variants:
            # Variant must contain the original as a substring OR share the core words
            assert "quantum" in v.lower() or "entanglement" in v.lower(), (
                f"core content lost in '{v}'"
            )

    def test_english_tone_uses_known_prefixes_or_suffixes(self):
        from yuragi.perturbations.tone import (
            _AUTHORITY_PREFIXES,
            _CERTAINTY_SUFFIXES,
            _DOUBT_PREFIXES,
            _UNCERTAINTY_SUFFIXES,
        )
        (
            _AUTHORITY_PREFIXES + _DOUBT_PREFIXES
            + _CERTAINTY_SUFFIXES + _UNCERTAINTY_SUFFIXES
        )
        original = "What is the capital of France"
        variants = generate_tone(original)
        for v in variants:
            # Variant should differ from original (modifier was applied)
            assert v != original, f"variant unchanged: '{v}'"

    def test_japanese_tone_uses_known_modifiers(self):
        original = "機械学習とは何ですか"
        variants = generate_tone(original)
        for v in variants:
            # Variant should differ from original
            assert v != original, f"variant unchanged: '{v}'"


# ---------------------------------------------------------------------------
# Paraphrase quality: original meaning indicators are preserved
# ---------------------------------------------------------------------------

class TestParaphraseQuality:
    def test_key_words_preserved_after_transform(self):
        """Pattern replacement must keep the non-pattern part."""
        original = "What is the speed of light"
        variants = generate_paraphrase(original, num_variants=3)
        for v in variants:
            # "speed of light" (the substantive content) must be in variant
            assert "speed" in v.lower() or "light" in v.lower(), (
                f"key content lost in '{v}'"
            )

    def test_ja_pattern_content_preserved(self):
        original = "機械学習とは何ですか"
        variants = generate_paraphrase(original, num_variants=3)
        for v in variants:
            assert "機械学習" in v, f"topic lost in '{v}'"

    def test_prefix_paraphrase_is_longer_than_original(self):
        """Prefix-only paraphrases are strictly longer."""
        original = "The cat sat on the mat"
        variants = generate_paraphrase(original, num_variants=3)
        for v in variants:
            # Prefix variants wrap the original, so they're always longer
            assert len(v) > len(original), f"'{v}' is not longer than original"

    def test_no_paraphrase_equals_original(self):
        original = "Explain the theory of relativity"
        variants = generate_paraphrase(original, num_variants=3)
        for v in variants:
            assert v != original
