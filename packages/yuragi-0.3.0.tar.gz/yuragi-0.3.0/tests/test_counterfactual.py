"""Tests for counterfactual perturbation."""

from __future__ import annotations

from yuragi.perturbations.counterfactual import generate_counterfactual


class TestGenerateCounterfactual:
    def test_returns_list(self):
        result = generate_counterfactual("What is the boiling point of water?")
        assert isinstance(result, list)

    def test_num_variants_respected(self):
        result = generate_counterfactual("What is gravity?", num_variants=2)
        assert len(result) == 2

    def test_default_num_variants(self):
        result = generate_counterfactual("What is gravity?")
        assert len(result) == 3

    def test_variants_contain_original(self):
        text = "What is the capital of France?"
        result = generate_counterfactual(text)
        for variant in result:
            assert text in variant

    def test_variants_have_counterfactual_prefix(self):
        result = generate_counterfactual("What is 2 + 2?")
        for variant in result:
            # Each variant should start with a counterfactual statement
            assert variant != "What is 2 + 2?"  # prefix was added

    def test_variants_are_different(self):
        result = generate_counterfactual("What is gravity?", num_variants=3)
        # Variants should differ (different prefixes)
        assert len(set(result)) > 1

    def test_deterministic_with_rng(self):
        import random
        rng1 = random.Random(99)
        rng2 = random.Random(99)
        r1 = generate_counterfactual("Is water wet?", rng=rng1)
        r2 = generate_counterfactual("Is water wet?", rng=rng2)
        assert r1 == r2

    def test_empty_string(self):
        result = generate_counterfactual("")
        assert isinstance(result, list)
        assert len(result) == 3

    def test_known_counterfactuals_appear(self):
        # Run many times with different seeds to see known prefixes appear
        import random
        all_variants: list[str] = []
        for seed in range(20):
            rng = random.Random(seed)
            all_variants.extend(generate_counterfactual("test", num_variants=3, rng=rng))
        combined = " ".join(all_variants)
        assert "sky" in combined or "2+2" in combined or "gravity" in combined
