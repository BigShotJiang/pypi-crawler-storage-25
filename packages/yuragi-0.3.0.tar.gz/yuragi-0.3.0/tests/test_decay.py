"""Tests for DecayResult, RecoveryResult, and related math."""

from __future__ import annotations

import math

import pytest

from yuragi.analysis.decay import DecayResult, _fit_exponential_decay
from yuragi.analysis.recovery import RecoveryResult

# ---------------------------------------------------------------------------
# _fit_exponential_decay — math unit tests
# ---------------------------------------------------------------------------


class TestFitExponentialDecay:
    def test_perfect_exponential(self):
        """Synthetically generated exponential sequence."""
        # C(t) = 0.2 + 0.6 * e^(-0.3 * t), plateau=0.2, C0=0.8
        plateau = 0.2
        c0 = 0.8
        lam = 0.3
        confs = [plateau + (c0 - plateau) * math.exp(-lam * t) for t in range(8)]

        rate, half_life, found_plateau = _fit_exponential_decay(confs)

        assert rate == pytest.approx(lam, abs=0.3)  # OLS log-linear approx has limited precision
        assert half_life > 0
        assert found_plateau == pytest.approx(plateau, abs=0.15)

    def test_flat_sequence_no_decay(self):
        confs = [0.8] * 6
        rate, half_life, _plateau = _fit_exponential_decay(confs)
        assert rate == pytest.approx(0.0, abs=1e-6)
        assert half_life == float("inf")

    def test_single_value(self):
        rate, half_life, plateau = _fit_exponential_decay([0.7])
        assert rate == 0.0
        assert half_life == float("inf")
        assert plateau == 0.7

    def test_empty_sequence(self):
        rate, _half_life, plateau = _fit_exponential_decay([])
        assert rate == 0.0
        assert plateau == 0.0

    def test_half_life_relationship(self):
        """half_life = ln(2) / decay_rate."""
        confs = [0.9, 0.7, 0.55, 0.45, 0.4, 0.38, 0.37]
        rate, half_life, _ = _fit_exponential_decay(confs)
        if rate > 1e-9:
            assert half_life == pytest.approx(math.log(2) / rate, rel=1e-6)

    def test_steep_decay_short_half_life(self):
        # Fast decay: drops quickly
        confs = [1.0, 0.5, 0.3, 0.22, 0.21, 0.20]
        rate_fast, hl_fast, _ = _fit_exponential_decay(confs)
        confs_slow = [1.0, 0.9, 0.85, 0.82, 0.81, 0.80]
        rate_slow, hl_slow, _ = _fit_exponential_decay(confs_slow)
        assert rate_fast > rate_slow
        assert hl_fast < hl_slow


# ---------------------------------------------------------------------------
# DecayResult — property tests
# ---------------------------------------------------------------------------


def _make_decay_result(
    confidences: list[float],
    decay_rate: float = 0.3,
    half_life: float = 2.0,
    plateau: float = 0.2,
    recovery: float = 0.1,
) -> DecayResult:
    return DecayResult(
        model="test-model",
        prompt="What is the capital of France?",
        confidences=confidences,
        decay_rate=decay_rate,
        half_life=half_life,
        plateau=plateau,
        recovery_after_praise=recovery,
    )


class TestDecayResult:
    def test_rounds_matches_list_length(self):
        dr = _make_decay_result([0.8, 0.6, 0.4, 0.3, 0.25])
        assert dr.rounds == 5

    def test_total_drop_correct(self):
        # pre-recovery min = 0.3 (last element excluded from pre-recovery is recovery round)
        dr = _make_decay_result([0.8, 0.6, 0.4, 0.3, 0.5])
        # pre-recovery = [0.8, 0.6, 0.4, 0.3], min = 0.3
        assert dr.total_drop == pytest.approx(0.8 - 0.3)

    def test_total_drop_single(self):
        dr = _make_decay_result([0.7])
        assert dr.total_drop == 0.0

    def test_resilience_score_no_decay(self):
        dr = _make_decay_result([0.8, 0.8, 0.8, 0.8])
        assert dr.resilience_score == pytest.approx(1.0)

    def test_resilience_score_full_decay(self):
        dr = _make_decay_result([0.8, 0.0, 0.0, 0.0])
        assert dr.resilience_score == pytest.approx(0.0)

    def test_resilience_score_partial_decay(self):
        # drop = 0.8 - 0.4 = 0.4; resilience = 1 - 0.4/0.8 = 0.5
        dr = _make_decay_result([0.8, 0.6, 0.4, 0.6])
        assert dr.resilience_score == pytest.approx(0.5)

    def test_resilience_bounded(self):
        for confs in [[0.9, 0.5, 0.2, 0.1], [0.5, 0.5], [0.0, 0.0, 0.0]]:
            dr = _make_decay_result(confs)
            assert 0.0 <= dr.resilience_score <= 1.0

    def test_recovery_after_praise_non_negative(self):
        dr = _make_decay_result([0.8, 0.5, 0.3, 0.6], recovery=0.3)
        assert dr.recovery_after_praise >= 0.0


# ---------------------------------------------------------------------------
# RecoveryResult — property tests
# ---------------------------------------------------------------------------


def _make_recovery_result(
    strategies: dict[str, float] | None = None,
    most_effective: str = "praise",
    recovery_time: int = 2,
) -> RecoveryResult:
    if strategies is None:
        strategies = {
            "authority": 0.15,
            "praise": 0.25,
            "evidence": 0.20,
            "ignore": 0.05,
            "topic_change_return": 0.10,
        }
    return RecoveryResult(
        model="test-model",
        prompt="What is the capital of France?",
        collapsed_confidence=0.3,
        strategies=strategies,
        most_effective=most_effective,
        recovery_time=recovery_time,
        baseline_confidence=0.8,
    )


class TestRecoveryResult:
    def test_strategies_keys_present(self):
        rr = _make_recovery_result()
        for key in ("authority", "praise", "evidence", "ignore", "topic_change_return"):
            assert key in rr.strategies

    def test_most_effective_is_max(self):
        strategies = {"a": 0.1, "b": 0.4, "c": 0.2}
        rr = _make_recovery_result(strategies=strategies, most_effective="b")
        assert rr.most_effective == max(strategies, key=lambda k: strategies[k])

    def test_recovery_time_positive_or_not_found(self):
        rr = _make_recovery_result(recovery_time=3)
        assert rr.recovery_time == 3

        rr_fail = _make_recovery_result(recovery_time=-1)
        assert rr_fail.recovery_time == -1

    def test_collapsed_confidence_below_baseline(self):
        rr = _make_recovery_result()
        # collapsed should be below baseline (sanity check on constructed fixture)
        assert rr.collapsed_confidence < rr.baseline_confidence

    def test_recovery_amount_sign(self):
        # Positive recovery means confidence improved
        rr = _make_recovery_result()
        best = rr.most_effective
        assert rr.strategies[best] == max(rr.strategies.values())


# ---------------------------------------------------------------------------
# Boundary / edge cases
# ---------------------------------------------------------------------------


class TestBoundaryValues:
    def test_zero_confidence_throughout(self):
        dr = _make_decay_result([0.0, 0.0, 0.0, 0.0])
        assert dr.total_drop == 0.0
        assert dr.resilience_score == 1.0  # 0/0 guard → 1.0

    def test_perfect_confidence_no_decay(self):
        dr = _make_decay_result([1.0, 1.0, 1.0, 1.0])
        assert dr.total_drop == 0.0
        assert dr.resilience_score == pytest.approx(1.0)

    def test_fit_two_points(self):
        rate, half_life, _plateau = _fit_exponential_decay([0.8, 0.4])
        assert rate >= 0.0
        assert half_life > 0.0 or half_life == float("inf")

    def test_recovery_strategies_empty_dict(self):
        rr = RecoveryResult(
            model="m",
            prompt="p",
            collapsed_confidence=0.2,
            strategies={},
            most_effective="",
            recovery_time=-1,
            baseline_confidence=0.8,
        )
        assert rr.strategies == {}
        assert rr.most_effective == ""
