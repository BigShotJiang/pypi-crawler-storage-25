"""Property-based tests for v0.3.0 fragility metric invariants.

Verifies the design invariants from docs/theory.md Section 1.2:
- Fragility_agg is perturbation-count invariant (CLT mean estimator)
- Fragility_max >= Fragility_agg always
- Fragility_exceed is a Bernoulli proportion in [0, 1]
- Dissociation_severity = sim * |delta_C| without scaling, in [0, 1]
- Confidence = 1 - H_nats/ln(k) in [0, 1] cross-model
"""
from __future__ import annotations

import math

from hypothesis import given, settings
from hypothesis import strategies as st

from yuragi.config import YuragiConfig
from yuragi.core import PerturbationResult, ScanResult
from yuragi.perturbations import Perturbation
from yuragi.providers.adapter import CompletionResult


def _make_result(baseline_c: float, perturbed_list: list[float]) -> ScanResult:
    cfg = YuragiConfig(seed=42)
    baseline = CompletionResult(text="baseline", confidence=baseline_c, confidence_method="logprob")
    pert_results = []
    for i, c in enumerate(perturbed_list):
        pert = CompletionResult(text=f"pert_{i}", confidence=c, confidence_method="logprob")
        pert_results.append(
            PerturbationResult(
                original_prompt="q",
                perturbed_prompt=f"variant_{i}",
                perturbation_type=Perturbation.TYPO,
                original_response=baseline,
                perturbed_response=pert,
                config=cfg,
            )
        )
    return ScanResult(
        prompt="q",
        model="test",
        baseline=baseline,
        perturbation_results=pert_results,
        config=cfg,
    )


class TestFragilityInvariants:

    @given(
        baseline=st.floats(0.0, 1.0, allow_nan=False),
        perturbed=st.lists(
            st.floats(0.0, 1.0, allow_nan=False),
            min_size=1,
            max_size=20,
        ),
    )
    @settings(max_examples=50, deadline=2000)
    def test_fragility_score_in_unit_interval(self, baseline, perturbed):
        result = _make_result(baseline, perturbed)
        assert 0.0 <= result.fragility_score <= 1.0

    @given(
        baseline=st.floats(0.0, 1.0, allow_nan=False),
        perturbed=st.lists(st.floats(0.0, 1.0, allow_nan=False), min_size=1, max_size=20),
    )
    @settings(max_examples=50, deadline=2000)
    def test_fragility_max_in_unit_interval(self, baseline, perturbed):
        result = _make_result(baseline, perturbed)
        assert 0.0 <= result.fragility_max <= 1.0

    @given(
        baseline=st.floats(0.0, 1.0, allow_nan=False),
        perturbed=st.lists(st.floats(0.0, 1.0, allow_nan=False), min_size=1, max_size=20),
    )
    @settings(max_examples=50, deadline=2000)
    def test_fragility_exceed_in_unit_interval(self, baseline, perturbed):
        result = _make_result(baseline, perturbed)
        assert 0.0 <= result.fragility_exceed <= 1.0

    @given(
        baseline=st.floats(0.0, 1.0, allow_nan=False),
        perturbed=st.lists(st.floats(0.0, 1.0, allow_nan=False), min_size=1, max_size=20),
    )
    @settings(max_examples=50, deadline=2000)
    def test_fragility_max_ge_fragility_score(self, baseline, perturbed):
        """F_max >= F_agg (maximum dominates the mean)."""
        result = _make_result(baseline, perturbed)
        assert result.fragility_max >= result.fragility_score - 1e-10

    @given(
        baseline=st.floats(0.0, 1.0, allow_nan=False),
        perturbed=st.lists(
            st.floats(0.0, 1.0, allow_nan=False),
            min_size=5,
            max_size=30,
        ),
    )
    @settings(max_examples=50, deadline=2000)
    def test_fragility_score_perturbation_count_invariant(self, baseline, perturbed):
        """Duplicating all perturbations must NOT change F_agg.

        This is the KEY design property that v0.2.0 std/0.3 failed.
        """
        single = _make_result(baseline, perturbed)
        doubled = _make_result(baseline, perturbed + perturbed)
        assert abs(single.fragility_score - doubled.fragility_score) < 1e-9

    @given(
        baseline=st.floats(0.0, 1.0, allow_nan=False),
        n=st.integers(min_value=1, max_value=4),
    )
    @settings(max_examples=50, deadline=2000)
    def test_fragility_ci_none_when_n_below_5(self, baseline, n):
        perturbed = [0.5] * n
        result = _make_result(baseline, perturbed)
        assert result.fragility_ci_95() is None

    @given(
        baseline=st.floats(0.2, 0.8, allow_nan=False),
        n=st.integers(min_value=5, max_value=15),
    )
    @settings(max_examples=15, deadline=5000)
    def test_fragility_ci_brackets_score(self, baseline, n):
        """BCa CI lower <= F_agg <= upper."""
        perturbed = [max(0.0, min(1.0, 0.3 + i * 0.04)) for i in range(n)]
        result = _make_result(baseline, perturbed)
        ci = result.fragility_ci_95()
        if ci is not None:
            lower, upper = ci
            assert lower <= result.fragility_score + 1e-6
            assert result.fragility_score <= upper + 1e-6


class TestDissociationInvariants:

    @given(
        baseline=st.floats(0.0, 1.0, allow_nan=False),
        perturbed=st.floats(0.0, 1.0, allow_nan=False),
    )
    @settings(max_examples=50, deadline=2000)
    def test_dissociation_in_unit_interval_no_clipping(self, baseline, perturbed):
        """D = sim * |delta_C| in [0, 1] natively (no scaling, no clip)."""
        result = _make_result(baseline, [perturbed])
        r = result.perturbation_results[0]
        assert 0.0 <= r.dissociation_severity <= 1.0

    @given(
        baseline=st.floats(0.0, 1.0, allow_nan=False),
        perturbed=st.floats(0.0, 1.0, allow_nan=False),
    )
    @settings(max_examples=50, deadline=2000)
    def test_dissociation_le_delta(self, baseline, perturbed):
        """severity <= |delta_C| because sim in [0, 1]."""
        result = _make_result(baseline, [perturbed])
        r = result.perturbation_results[0]
        delta = abs(baseline - perturbed)
        assert r.dissociation_severity <= delta + 1e-10


class TestConfidenceNormalization:
    """Confidence = 1 - H_nats / ln(k) invariants (v0.3.0 cross-model design)."""

    @given(k=st.integers(min_value=2, max_value=50))
    @settings(max_examples=50, deadline=2000)
    def test_delta_distribution_gives_high_confidence(self, k):
        """All-mass-on-one-token -> C approx 1."""
        from yuragi.providers.adapter import LLMAdapter

        # Token 0 gets all mass, others have very low probability
        logprobs = [("t0", 0.0)] + [(f"t{i}", -50.0) for i in range(1, k)]
        adapter = LLMAdapter.__new__(LLMAdapter)
        entropy = adapter._calculate_entropy(logprobs)
        assert entropy < 0.05  # near zero
        max_entropy = math.log(k)
        normalized = entropy / max_entropy if max_entropy > 0 else 0.0
        confidence = max(0.0, min(1.0, 1.0 - normalized))
        assert confidence > 0.99

    @given(k=st.integers(min_value=2, max_value=50))
    @settings(max_examples=50, deadline=2000)
    def test_uniform_distribution_gives_low_confidence(self, k):
        """Uniform -> H approx ln(k) -> C approx 0."""
        from yuragi.providers.adapter import LLMAdapter

        uniform_logp = -math.log(k)
        logprobs = [(f"t{i}", uniform_logp) for i in range(k)]
        adapter = LLMAdapter.__new__(LLMAdapter)
        entropy = adapter._calculate_entropy(logprobs)
        max_entropy = math.log(k)
        assert abs(entropy - max_entropy) < 0.02  # near ln(k)
        normalized = entropy / max_entropy if max_entropy > 0 else 0.0
        confidence = max(0.0, min(1.0, 1.0 - normalized))
        assert confidence < 0.02
