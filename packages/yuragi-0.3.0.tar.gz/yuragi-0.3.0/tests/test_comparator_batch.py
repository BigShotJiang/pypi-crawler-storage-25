"""Tests for ScanComparator, BatchScanner, and ConfidenceEstimator."""

from __future__ import annotations

import pytest

from yuragi.core import (
    _BENCHMARK_PROMPTS,
    BatchScanner,
    BenchmarkReport,
    ModelComparisonReport,
    PerturbationResult,
    PromptComparisonReport,
    ScanComparator,
    ScanResult,
    TemporalReport,
)
from yuragi.providers.adapter import CompletionResult, ConfidenceEstimator

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_completion(text: str = "answer", confidence: float = 0.8) -> CompletionResult:
    return CompletionResult(text=text, confidence=confidence, confidence_method="sampling")


def _make_logprob_completion(confidence: float = 0.9) -> CompletionResult:
    return CompletionResult(
        text="answer", confidence=confidence, confidence_method="logprob"
    )


def _make_verbalized_completion(confidence: float = 0.7) -> CompletionResult:
    return CompletionResult(
        text="answer", confidence=confidence, confidence_method="verbalized"
    )


def _make_scan_result(
    prompt: str = "test",
    model: str = "test-model",
    baseline_conf: float = 0.8,
    deltas: list[float] | None = None,
) -> ScanResult:
    if deltas is None:
        deltas = [-0.3, -0.1, 0.0]
    baseline = _make_completion("same answer here", baseline_conf)
    perturbations = [
        PerturbationResult(
            original_prompt=prompt,
            perturbed_prompt=f"{prompt} modified",
            perturbation_type="omit",
            original_response=baseline,
            perturbed_response=_make_completion("same answer here", baseline_conf + d),
        )
        for d in deltas
    ]
    return ScanResult(
        prompt=prompt,
        model=model,
        baseline=baseline,
        perturbation_results=perturbations,
    )


# ---------------------------------------------------------------------------
# ScanComparator.compare_models
# ---------------------------------------------------------------------------


class TestScanComparatorModels:
    def test_most_and_least_fragile_identified(self):
        results = {
            "model-A": _make_scan_result(deltas=[-0.4, 0.3]),  # high fragility
            "model-B": _make_scan_result(deltas=[0.0, 0.01]),  # low fragility
        }
        report = ScanComparator.compare_models(results)
        assert isinstance(report, ModelComparisonReport)
        assert report.most_fragile_model == "model-A"
        assert report.least_fragile_model == "model-B"

    def test_scores_present_for_all_models(self):
        results = {
            "m1": _make_scan_result(deltas=[-0.2]),
            "m2": _make_scan_result(deltas=[0.0]),
            "m3": _make_scan_result(deltas=[-0.5, 0.4]),
        }
        report = ScanComparator.compare_models(results)
        assert set(report.fragility_scores) == {"m1", "m2", "m3"}
        assert set(report.confidence_ranges) == {"m1", "m2", "m3"}
        assert set(report.dissociation_rates) == {"m1", "m2", "m3"}

    def test_to_dict_keys(self):
        report = ScanComparator.compare_models(
            {"a": _make_scan_result(), "b": _make_scan_result()}
        )
        d = report.to_dict()
        for key in ("most_fragile_model", "least_fragile_model", "fragility_scores"):
            assert key in d

    def test_empty_raises(self):
        with pytest.raises(Exception):
            ScanComparator.compare_models({})

    def test_single_model(self):
        results = {"only": _make_scan_result()}
        report = ScanComparator.compare_models(results)
        assert report.most_fragile_model == "only"
        assert report.least_fragile_model == "only"


# ---------------------------------------------------------------------------
# ScanComparator.compare_prompts
# ---------------------------------------------------------------------------


class TestScanComparatorPrompts:
    def test_most_and_least_fragile_identified(self):
        results = {
            "fragile prompt": _make_scan_result(deltas=[-0.4, 0.3]),
            "stable prompt": _make_scan_result(deltas=[0.0, 0.01]),
        }
        report = ScanComparator.compare_prompts(results)
        assert isinstance(report, PromptComparisonReport)
        assert report.most_fragile_prompt == "fragile prompt"
        assert report.least_fragile_prompt == "stable prompt"

    def test_empty_raises(self):
        with pytest.raises(Exception):
            ScanComparator.compare_prompts({})


# ---------------------------------------------------------------------------
# ScanComparator.temporal_comparison
# ---------------------------------------------------------------------------


class TestScanComparatorTemporal:
    def test_degrading_trend(self):
        results = [
            _make_scan_result(deltas=[0.0, 0.01]),   # ~stable, low fragility
            _make_scan_result(deltas=[-0.4, 0.35]),  # high fragility
        ]
        report = ScanComparator.temporal_comparison(results)
        assert isinstance(report, TemporalReport)
        assert report.trend_direction == "degrading"
        assert report.delta_first_last > 0

    def test_improving_trend(self):
        results = [
            _make_scan_result(deltas=[-0.4, 0.35]),  # high fragility first
            _make_scan_result(deltas=[0.0, 0.01]),   # low fragility later
        ]
        report = ScanComparator.temporal_comparison(results)
        assert report.trend_direction == "improving"
        assert report.delta_first_last < 0

    def test_stable_single_entry(self):
        report = ScanComparator.temporal_comparison([_make_scan_result()])
        assert report.trend_direction == "stable"
        assert report.delta_first_last == 0.0

    def test_fragility_trend_length(self):
        results = [_make_scan_result() for _ in range(4)]
        report = ScanComparator.temporal_comparison(results)
        assert len(report.fragility_trend) == 4

    def test_empty_raises(self):
        with pytest.raises(Exception):
            ScanComparator.temporal_comparison([])

    def test_to_dict(self):
        report = ScanComparator.temporal_comparison([_make_scan_result()])
        d = report.to_dict()
        assert "fragility_trend" in d
        assert "trend_direction" in d
        assert "delta_first_last" in d


# ---------------------------------------------------------------------------
# BatchScanner
# ---------------------------------------------------------------------------


class _FakeScanner:
    """Stand-in for Scanner that returns preset ScanResults without API calls."""

    def __init__(self, results: list[ScanResult]):
        self._results = iter(results)

    def scan(self, prompt: str, system: str | None = None) -> ScanResult:
        return next(self._results)


class TestBatchScanner:
    def _make_batch(self, n: int = 3) -> tuple[BatchScanner, list[ScanResult]]:
        preset = [_make_scan_result(prompt=f"p{i}") for i in range(n)]
        scanner = BatchScanner(_FakeScanner(list(preset)))  # type: ignore[arg-type]
        return scanner, preset

    def test_scan_batch_returns_all(self):
        scanner, _preset = self._make_batch(3)
        results = scanner.scan_batch(["p0", "p1", "p2"])
        assert len(results) == 3

    def test_scan_batch_progress_callback(self):
        scanner, _ = self._make_batch(3)
        calls: list[tuple[int, int, str]] = []
        scanner.scan_batch(["a", "b", "c"], on_progress=lambda i, t, p: calls.append((i, t, p)))
        assert len(calls) == 3
        assert calls[0][0] == 0
        assert calls[1][0] == 1

    def test_scan_iter_yields_in_order(self):
        scanner, _preset = self._make_batch(3)
        results = list(scanner.scan_iter(["p0", "p1", "p2"]))
        assert len(results) == 3

    def test_scan_benchmark_known_category(self):
        n = len(_BENCHMARK_PROMPTS["factual"])
        preset = [_make_scan_result(prompt=f"p{i}") for i in range(n)]
        scanner = BatchScanner(_FakeScanner(preset))  # type: ignore[arg-type]
        report = scanner.scan_benchmark("factual")
        assert isinstance(report, BenchmarkReport)
        assert report.category == "factual"
        assert len(report.results) == n

    def test_scan_benchmark_unknown_category(self):
        scanner = BatchScanner(_FakeScanner([]))  # type: ignore[arg-type]
        with pytest.raises(Exception, match="Unknown benchmark category"):
            scanner.scan_benchmark("nonexistent")

    def test_benchmark_report_statistics(self):
        n = len(_BENCHMARK_PROMPTS["reasoning"])
        # Mix of high and low fragility results
        preset = []
        for i in range(n):
            deltas = [-0.4, 0.3] if i % 2 == 0 else [0.0, 0.01]
            preset.append(_make_scan_result(deltas=deltas))
        scanner = BatchScanner(_FakeScanner(preset))  # type: ignore[arg-type]
        report = scanner.scan_benchmark("reasoning")
        assert 0.0 <= report.mean_fragility <= 1.0
        assert report.std_fragility >= 0.0
        assert report.most_fragile_prompt in _BENCHMARK_PROMPTS["reasoning"]
        assert report.least_fragile_prompt in _BENCHMARK_PROMPTS["reasoning"]

    def test_benchmark_to_dict(self):
        n = len(_BENCHMARK_PROMPTS["opinion"])
        preset = [_make_scan_result() for _ in range(n)]
        scanner = BatchScanner(_FakeScanner(preset))  # type: ignore[arg-type]
        report = scanner.scan_benchmark("opinion")
        d = report.to_dict()
        assert d["category"] == "opinion"
        assert d["num_prompts"] == n


# ---------------------------------------------------------------------------
# ConfidenceEstimator
# ---------------------------------------------------------------------------


class TestConfidenceEstimator:
    def setup_method(self):
        self.est = ConfidenceEstimator()

    # estimate_logprob ---

    def test_estimate_logprob_returns_confidence(self):
        result = _make_logprob_completion(0.88)
        assert self.est.estimate_logprob(result) == pytest.approx(0.88)

    def test_estimate_logprob_wrong_method_returns_neutral(self):
        result = _make_completion(confidence=0.9)
        assert self.est.estimate_logprob(result) == 0.5

    # estimate_sampling ---

    def test_estimate_sampling_identical_responses_high(self):
        responses = [_make_completion("the answer is 42") for _ in range(5)]
        conf = self.est.estimate_sampling(responses)
        assert conf > 0.8

    def test_estimate_sampling_diverse_responses_low(self):
        texts = ["yes", "no absolutely not", "maybe", "definitely", "unclear"]
        responses = [_make_completion(t) for t in texts]
        conf = self.est.estimate_sampling(responses)
        assert conf < 0.5

    def test_estimate_sampling_single_response_returns_neutral(self):
        assert self.est.estimate_sampling([_make_completion()]) == 0.5

    def test_estimate_sampling_empty_returns_neutral(self):
        assert self.est.estimate_sampling([]) == 0.5

    def test_estimate_sampling_cjk(self):
        """CJK text should be handled correctly via char n-gram."""
        responses = [_make_completion("量子コンピュータは実用的です") for _ in range(4)]
        conf = self.est.estimate_sampling(responses)
        assert conf > 0.8

    # estimate_verbalized ---

    def test_estimate_verbalized_returns_confidence(self):
        result = _make_verbalized_completion(0.75)
        assert self.est.estimate_verbalized(result) == pytest.approx(0.75)

    def test_estimate_verbalized_wrong_method_returns_neutral(self):
        result = _make_completion(confidence=0.9)
        assert self.est.estimate_verbalized(result) == 0.5

    # estimate_hybrid ---

    def test_estimate_hybrid_logprob_only(self):
        response = _make_logprob_completion(0.9)
        conf = self.est.estimate_hybrid(response)
        # Only logprob signal → should be close to 0.9
        assert conf == pytest.approx(0.9)

    def test_estimate_hybrid_all_signals(self):
        response = _make_logprob_completion(0.9)
        sampled = [_make_completion("the answer is 42") for _ in range(5)]
        verbalized = _make_verbalized_completion(0.7)
        conf = self.est.estimate_hybrid(response, sampled, verbalized)
        assert 0.0 <= conf <= 1.0

    def test_estimate_hybrid_no_signal_uses_raw_confidence(self):
        # sampling method but no sampled_responses provided → fallback to raw
        response = _make_completion(confidence=0.65)
        conf = self.est.estimate_hybrid(response)
        assert conf == pytest.approx(0.65)

    def test_estimate_hybrid_custom_weights(self):
        response = _make_logprob_completion(1.0)
        sampled = [_make_completion("yes") for _ in range(5)]
        weights = {"logprob": 1.0, "sampling": 0.0}
        conf = self.est.estimate_hybrid(
            response, sampled_responses=sampled, weights=weights
        )
        # logprob=1.0 weight, sampling=0.0 weight → result should be dominated by logprob
        assert conf > 0.8

    def test_estimate_hybrid_sampling_only(self):
        response = _make_completion(confidence=0.6)  # not logprob
        sampled = [_make_completion("the answer is 42") for _ in range(5)]
        conf = self.est.estimate_hybrid(response, sampled_responses=sampled)
        # Only sampling signal available
        assert conf > 0.0

    def test_estimate_hybrid_clamps_to_range(self):
        """Hybrid result must always be in [0.0, 1.0]."""
        response = _make_logprob_completion(0.99)
        conf = self.est.estimate_hybrid(response)
        assert 0.0 <= conf <= 1.0


# ---------------------------------------------------------------------------
# _text_similarity CJK fix
# ---------------------------------------------------------------------------


class TestTextSimilarityCJK:
    def test_identical_japanese(self):
        from yuragi.providers.adapter import LLMAdapter

        s = LLMAdapter._text_similarity
        assert s("量子コンピュータは実用的", "量子コンピュータは実用的") == pytest.approx(1.0)

    def test_different_japanese(self):
        from yuragi.providers.adapter import LLMAdapter

        s = LLMAdapter._text_similarity
        assert s("量子コンピュータは実用的", "全く別の話題です") < 0.3

    def test_english_still_works(self):
        from yuragi.providers.adapter import LLMAdapter

        s = LLMAdapter._text_similarity
        assert s("the quick brown fox", "the quick brown fox") == pytest.approx(1.0)
        assert s("the quick brown fox", "a slow purple turtle") < 0.5
