"""Edge case tests for all perturbation generators."""


from yuragi.perturbations.omit import generate_omit
from yuragi.perturbations.paraphrase import generate_paraphrase
from yuragi.perturbations.reorder import generate_reorder
from yuragi.perturbations.synonym import generate_synonym
from yuragi.perturbations.tone import generate_tone
from yuragi.perturbations.typo import generate_typo

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _long_prompt(n_words: int = 1000) -> str:
    """Generate a prompt with n_words words."""
    base = "quantum computing artificial intelligence machine learning neural network "
    repeated = (base * ((n_words // len(base.split())) + 1)).split()[:n_words]
    return " ".join(repeated)


# ---------------------------------------------------------------------------
# Long prompts (1000+ words)
# ---------------------------------------------------------------------------

class TestLongPrompt:
    LONG = _long_prompt(1000)

    def test_typo_handles_long_prompt(self):
        variants = generate_typo(self.LONG, num_variants=3)
        assert isinstance(variants, list)
        assert len(variants) <= 3

    def test_synonym_handles_long_prompt(self):
        variants = generate_synonym(self.LONG, num_variants=3)
        assert isinstance(variants, list)

    def test_omit_handles_long_prompt(self):
        variants = generate_omit(self.LONG, num_variants=5)
        assert isinstance(variants, list)
        assert len(variants) <= 5

    def test_reorder_handles_long_prompt(self):
        variants = generate_reorder(self.LONG, num_variants=3)
        assert isinstance(variants, list)
        assert len(variants) <= 3

    def test_tone_handles_long_prompt(self):
        variants = generate_tone(self.LONG)
        assert isinstance(variants, list)

    def test_paraphrase_handles_long_prompt(self):
        variants = generate_paraphrase(self.LONG, num_variants=3)
        assert isinstance(variants, list)


# ---------------------------------------------------------------------------
# Whitespace-only / newline-only / special characters only
# ---------------------------------------------------------------------------

class TestWhitespaceInput:
    def test_typo_whitespace_only(self):
        assert generate_typo("   ") == []

    def test_typo_newlines_only(self):
        assert generate_typo("\n\n\n") == []

    def test_synonym_whitespace_only(self):
        assert generate_synonym("   ") == []

    def test_omit_whitespace_only(self):
        assert generate_omit("   ") == []

    def test_reorder_whitespace_only(self):
        assert generate_reorder("   ") == []

    def test_paraphrase_whitespace_only(self):
        assert generate_paraphrase("   ") == []

    def test_paraphrase_newlines_only(self):
        assert generate_paraphrase("\n\n") == []


class TestSpecialCharInput:
    SPECIAL = "!@#$%^&*()_+-=[]{}|;':\",./<>?"

    def test_typo_special_chars_returns_list(self):
        result = generate_typo(self.SPECIAL, num_variants=2)
        assert isinstance(result, list)

    def test_synonym_special_chars_returns_list(self):
        result = generate_synonym(self.SPECIAL, num_variants=2)
        assert isinstance(result, list)

    def test_omit_special_chars_returns_list(self):
        result = generate_omit(self.SPECIAL, num_variants=2)
        assert isinstance(result, list)

    def test_reorder_special_chars_returns_list(self):
        result = generate_reorder(self.SPECIAL, num_variants=2)
        assert isinstance(result, list)

    def test_tone_special_chars_returns_list(self):
        result = generate_tone(self.SPECIAL)
        assert isinstance(result, list)

    def test_paraphrase_special_chars_returns_list(self):
        result = generate_paraphrase(self.SPECIAL, num_variants=2)
        assert isinstance(result, list)


# ---------------------------------------------------------------------------
# Unicode / emoji prompts
# ---------------------------------------------------------------------------

class TestUnicodeEmoji:
    EMOJI = "What does 🎉 mean? Is 💡 related to 🧠?"
    MIXED = "Tell me about café culture and naïve assumptions"

    def test_typo_emoji_prompt_returns_list(self):
        result = generate_typo(self.EMOJI, num_variants=2)
        assert isinstance(result, list)

    def test_synonym_emoji_prompt_returns_list(self):
        result = generate_synonym(self.EMOJI, num_variants=2)
        assert isinstance(result, list)

    def test_omit_emoji_prompt_returns_list(self):
        result = generate_omit(self.EMOJI, num_variants=2)
        assert isinstance(result, list)

    def test_reorder_emoji_prompt_returns_list(self):
        result = generate_reorder(self.EMOJI, num_variants=2)
        assert isinstance(result, list)

    def test_tone_emoji_prompt_returns_list(self):
        result = generate_tone(self.EMOJI)
        assert isinstance(result, list)

    def test_paraphrase_emoji_prompt_returns_list(self):
        result = generate_paraphrase(self.EMOJI, num_variants=2)
        assert isinstance(result, list)

    def test_typo_latin_extended_chars(self):
        result = generate_typo(self.MIXED, num_variants=2)
        assert isinstance(result, list)

    def test_omit_emoji_word_count_decreases_by_one(self):
        text = "What does mean today"
        variants = generate_omit(text, num_variants=0)
        for v in variants:
            assert len(v.split()) == len(text.split()) - 1


# ---------------------------------------------------------------------------
# Japanese-only prompts
# ---------------------------------------------------------------------------

class TestJapaneseOnly:
    JA_PROMPT = "量子コンピュータは本当に実用化されるのでしょうか"
    JA_QUESTION = "機械学習とは何ですか"

    def test_typo_japanese_returns_list(self):
        result = generate_typo(self.JA_PROMPT, num_variants=2)
        assert isinstance(result, list)

    def test_synonym_japanese_returns_list(self):
        result = generate_synonym(self.JA_PROMPT, num_variants=2)
        assert isinstance(result, list)

    def test_omit_japanese_returns_list(self):
        # Japanese text split by spaces: may be single token
        result = generate_omit(self.JA_PROMPT, num_variants=2)
        assert isinstance(result, list)

    def test_tone_japanese_generates_variants(self):
        result = generate_tone(self.JA_PROMPT)
        assert result

    def test_paraphrase_japanese_uses_ja_transforms(self):
        result = generate_paraphrase(self.JA_QUESTION, num_variants=3)
        # JA_TRANSFORMS includes "とは何ですか" pattern
        assert result

    def test_tone_japanese_variants_differ_from_original(self):
        result = generate_tone(self.JA_PROMPT)
        for v in result:
            assert v != self.JA_PROMPT


# ---------------------------------------------------------------------------
# Single-word prompts
# ---------------------------------------------------------------------------

class TestSingleWord:
    def test_typo_single_word_returns_variants_or_empty(self):
        result = generate_typo("Hello", num_variants=2)
        assert isinstance(result, list)

    def test_synonym_single_word_known(self):
        # "important" is in the synonym map
        result = generate_synonym("important", num_variants=2)
        assert isinstance(result, list)

    def test_omit_single_word_returns_empty(self):
        assert generate_omit("hello") == []

    def test_reorder_single_word_returns_empty(self):
        assert generate_reorder("hello") == []

    def test_tone_single_word_returns_variants(self):
        result = generate_tone("Explain")
        assert isinstance(result, list)
        assert result

    def test_paraphrase_single_word_returns_list(self):
        result = generate_paraphrase("Explain", num_variants=2)
        assert isinstance(result, list)


# ---------------------------------------------------------------------------
# Numbers-only prompts
# ---------------------------------------------------------------------------

class TestNumbersOnly:
    def test_typo_numbers_only_returns_list(self):
        result = generate_typo("123 456 789", num_variants=2)
        assert isinstance(result, list)

    def test_synonym_numbers_only_returns_empty(self):
        result = generate_synonym("123 456 789", num_variants=2)
        # Numbers have no synonyms in the map
        assert isinstance(result, list)

    def test_omit_numbers_only_removes_one_token(self):
        result = generate_omit("100 200 300", num_variants=0)
        assert len(result) == 3

    def test_reorder_numbers_only_swaps_adjacent(self):
        result = generate_reorder("100 200 300 400", num_variants=2)
        assert isinstance(result, list)

    def test_tone_numbers_only_returns_variants(self):
        result = generate_tone("42 is the answer")
        assert isinstance(result, list)

    def test_paraphrase_numbers_only_returns_list(self):
        result = generate_paraphrase("1000000 divided by 1000", num_variants=2)
        assert isinstance(result, list)
