"""Tests for experiments/runner.py: sequential and parallel execution."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

from yuragi.experiments.registry import ExperimentSpec
from yuragi.providers.adapter import CompletionResult


def _make_spec(n_pairs: int = 3) -> ExperimentSpec:
    pairs = [(f"control_{i}", f"treatment_{i}") for i in range(n_pairs)]
    return ExperimentSpec(
        name="test_exp",
        description="test",
        hypothesis="h",
        human_parallel="h",
        pairs=pairs,
    )


def _make_result(text: str = "answer", confidence: float = 0.8) -> CompletionResult:
    return CompletionResult(text=text, confidence=confidence, confidence_method="sampling")


class TestRunExperimentSequential:
    def test_sequential_returns_correct_pair_count(self):
        from yuragi.experiments.runner import run_experiment
        spec = _make_spec(3)

        with patch("yuragi.experiments.runner.LLMAdapter") as mock_adapter_cls:
            instance = mock_adapter_cls.return_value
            instance.complete.return_value = _make_result()
            exp = run_experiment(spec, model="test/model", parallel=1)

        assert len(exp.results) == 3

    def test_sequential_respects_delay_zero(self):
        """delay=0 (default) should not call time.sleep."""
        from yuragi.experiments.runner import run_experiment
        spec = _make_spec(2)

        with patch("yuragi.experiments.runner.LLMAdapter") as mock_adapter_cls, \
             patch("time.sleep") as mock_sleep:
            instance = mock_adapter_cls.return_value
            instance.complete.return_value = _make_result()
            run_experiment(spec, model="test/model", delay=0.0, parallel=1)

        mock_sleep.assert_not_called()


class TestRunExperimentParallel:
    def test_parallel_returns_same_count_as_sequential(self):
        """parallel=4 must return same number of results as sequential."""
        from yuragi.experiments.runner import run_experiment
        spec = _make_spec(5)

        async def fake_acomplete(prompt, system=None, retries=2):
            return _make_result(text=f"reply-{prompt}")

        with patch("yuragi.experiments.runner.LLMAdapter") as mock_adapter_cls:
            instance = mock_adapter_cls.return_value
            instance.acomplete = AsyncMock(side_effect=fake_acomplete)
            exp = run_experiment(spec, model="test/model", parallel=4)

        assert len(exp.results) == 5

    def test_parallel_results_have_correct_effect_name(self):
        from yuragi.experiments.runner import run_experiment
        spec = _make_spec(3)

        async def fake_acomplete(prompt, system=None, retries=2):
            return _make_result()

        with patch("yuragi.experiments.runner.LLMAdapter") as mock_adapter_cls:
            instance = mock_adapter_cls.return_value
            instance.acomplete = AsyncMock(side_effect=fake_acomplete)
            exp = run_experiment(spec, model="test/model", parallel=2)

        for r in exp.results:
            assert r.effect_name == "test_exp"

    def test_parallel_and_sequential_same_structure(self):
        """parallel and sequential paths must produce identical ExperimentResult structure."""
        from yuragi.experiments.runner import run_experiment
        spec = _make_spec(2)

        ctrl_result = _make_result("control_answer", 0.9)
        treat_result = _make_result("treatment_answer", 0.6)

        call_seq = [ctrl_result, treat_result, ctrl_result, treat_result]

        with patch("yuragi.experiments.runner.LLMAdapter") as mock_adapter_cls:
            instance = mock_adapter_cls.return_value
            instance.complete.side_effect = list(call_seq)
            exp_seq = run_experiment(spec, model="test/model", parallel=1)

        async def fake_acomplete_paired(prompt, system=None, retries=2):
            if "control" in prompt:
                return ctrl_result
            return treat_result

        with patch("yuragi.experiments.runner.LLMAdapter") as mock_adapter_cls:
            instance = mock_adapter_cls.return_value
            instance.acomplete = AsyncMock(side_effect=fake_acomplete_paired)
            exp_par = run_experiment(spec, model="test/model", parallel=4)

        assert len(exp_seq.results) == len(exp_par.results)
        for seq_r, par_r in zip(exp_seq.results, exp_par.results, strict=False):
            assert seq_r.control_confidence == par_r.control_confidence
            assert seq_r.treatment_confidence == par_r.treatment_confidence
