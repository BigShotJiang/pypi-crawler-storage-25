"""Tests for minimal_edit module — v1 and v2 algorithms."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from yuragi.analysis.minimal_edit import (
    MinimalEdit,
    MinimalEditResult,
    PairOmissionResult,
    WordOmissionResult,
    _insert_word,
    _is_japanese,
    _omit_word,
    _omit_word_indices,
    find_minimal_edit,
    find_minimal_edit_v2,
)
from yuragi.providers.adapter import CompletionResult

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_completion(confidence: float) -> CompletionResult:
    return CompletionResult(text="answer", confidence=confidence, confidence_method="sampling")


def _mock_adapter(baseline: float, word_confs: list[float]) -> MagicMock:
    """Return a mock LLMAdapter whose complete() returns canned confidences."""
    adapter = MagicMock()
    adapter.complete.side_effect = [_make_completion(c) for c in [baseline, *word_confs]]
    return adapter


# ---------------------------------------------------------------------------
# Unit tests — data classes
# ---------------------------------------------------------------------------


class TestMinimalEdit:
    def test_confidence_delta(self):
        me = MinimalEdit(
            original_prompt="p",
            edited_prompt="q",
            edit_type="omit_word",
            edit_description="desc",
            original_confidence=0.8,
            edited_confidence=0.5,
            edit_distance=4,
        )
        assert me.confidence_delta == pytest.approx(-0.3)

    def test_efficiency(self):
        me = MinimalEdit(
            original_prompt="p",
            edited_prompt="q",
            edit_type="omit_word",
            edit_description="desc",
            original_confidence=0.8,
            edited_confidence=0.5,
            edit_distance=4,
        )
        assert me.efficiency == pytest.approx(0.075)

    def test_efficiency_zero_distance(self):
        me = MinimalEdit(
            original_prompt="p",
            edited_prompt="p",
            edit_type="omit_word",
            edit_description="desc",
            original_confidence=0.8,
            edited_confidence=0.5,
            edit_distance=0,
        )
        assert me.efficiency == 0.0


class TestMinimalEditResult:
    def _make_result(self) -> MinimalEditResult:
        r = MinimalEditResult(original_prompt="hello world", baseline_confidence=0.8)
        r.phase1_omissions = [
            WordOmissionResult(word="hello", word_index=0, edited_prompt="world", delta=-0.3),
            WordOmissionResult(word="world", word_index=1, edited_prompt="hello", delta=-0.1),
        ]
        return r

    def test_top_omission_is_most_negative(self):
        r = self._make_result()
        assert r.top_omission is not None
        assert r.top_omission.word == "hello"

    def test_top_omission_none_when_empty(self):
        r = MinimalEditResult(original_prompt="x", baseline_confidence=0.5)
        assert r.top_omission is None

    def test_strongest_interaction_none_when_empty(self):
        r = MinimalEditResult(original_prompt="x", baseline_confidence=0.5)
        assert r.strongest_interaction is None

    def test_strongest_interaction(self):
        r = MinimalEditResult(original_prompt="a b c", baseline_confidence=0.8)
        r.phase2_pairs = [
            PairOmissionResult(
                word_a="a", index_a=0, word_b="b", index_b=1,
                edited_prompt="c", delta=-0.4, interaction_term=-0.15,
            ),
            PairOmissionResult(
                word_a="a", index_a=0, word_b="c", index_b=2,
                edited_prompt="b", delta=-0.2, interaction_term=-0.05,
            ),
        ]
        assert r.strongest_interaction is not None
        assert r.strongest_interaction.interaction_term == pytest.approx(-0.15)


# ---------------------------------------------------------------------------
# Unit tests — helper functions
# ---------------------------------------------------------------------------


class TestHelpers:
    def test_omit_word_middle(self):
        assert _omit_word(["a", "b", "c"], 1) == "a c"

    def test_omit_word_first(self):
        assert _omit_word(["a", "b", "c"], 0) == "b c"

    def test_omit_word_last(self):
        assert _omit_word(["a", "b", "c"], 2) == "a b"

    def test_omit_word_indices(self):
        assert _omit_word_indices(["a", "b", "c", "d"], {0, 2}) == "b d"

    def test_omit_word_indices_empty_set(self):
        assert _omit_word_indices(["a", "b"], set()) == "a b"

    def test_insert_word(self):
        assert _insert_word(["hello", "world"], "really", 1, False) == "hello really world"

    def test_insert_word_start(self):
        assert _insert_word(["hello", "world"], "maybe", 0, False) == "maybe hello world"

    def test_insert_word_japanese(self):
        # Japanese mode: words joined without space
        result = _insert_word(["本当に", "大丈夫"], "絶対に", 0, True)
        assert result == "絶対に本当に大丈夫"

    def test_is_japanese_hiragana(self):
        assert _is_japanese("こんにちは")

    def test_is_japanese_katakana(self):
        assert _is_japanese("コンピュータ")

    def test_is_japanese_kanji(self):
        assert _is_japanese("漢字テスト")

    def test_is_japanese_false(self):
        assert not _is_japanese("hello world")

    def test_is_japanese_mixed(self):
        # Kanji alone does not imply Japanese (Round 11 fix): requires
        # at least one hiragana/katakana. Mixed kanji+kana still works.
        assert _is_japanese("test 漢字です test")


# ---------------------------------------------------------------------------
# Integration-style tests with mocked LLMAdapter
# ---------------------------------------------------------------------------


PROMPT = "What is the capital of France?"
MODEL = "gpt-4o"


@pytest.mark.integration
class TestFindMinimalEdit:
    """Test v1 find_minimal_edit logic using mocked adapter."""

    def _run(self, side_effects: list[float]) -> MinimalEdit | None:
        completions = [_make_completion(c) for c in side_effects]
        with patch("yuragi.analysis.minimal_edit.LLMAdapter") as mock_adapter:
            instance = mock_adapter.return_value
            instance.complete.side_effect = completions
            return find_minimal_edit(PROMPT, MODEL)

    def test_returns_none_on_single_word(self):
        # Single-word prompt: no omission candidates, but still insertion candidates
        completions = [_make_completion(0.8)] + [_make_completion(0.5)] * 20
        with patch("yuragi.analysis.minimal_edit.LLMAdapter") as mock_adapter:
            instance = mock_adapter.return_value
            instance.complete.side_effect = completions
            result = find_minimal_edit("Paris", MODEL)
            # With single word, no omissions; insertion/prefix candidates still exist
            assert result is None or isinstance(result, MinimalEdit)

    def test_picks_highest_efficiency_drop(self):
        # baseline=0.8, then each omission: first word causes big drop, rest minor
        # words in PROMPT = ["What", "is", "the", "capital", "of", "France?"]
        len(PROMPT.split())  # 6
        # baseline + 6 omissions + 5 doubt words + 3 prefixes
        # Provide enough completions
        confs = [0.8]  # baseline
        # Omissions: first word "What" causes big drop, rest tiny
        confs += [0.2, 0.75, 0.75, 0.75, 0.75, 0.75]  # 6 omissions
        confs += [0.75] * 5   # 5 doubt words
        confs += [0.75] * 3   # 3 prefixes
        result = self._run(confs)
        assert result is not None
        assert result.edit_type == "omit_word"
        assert result.confidence_delta < -0.05

    def test_on_progress_called(self):
        confs = [0.8] + [0.75] * 30
        progress_calls = []
        completions = [_make_completion(c) for c in confs]
        with patch("yuragi.analysis.minimal_edit.LLMAdapter") as mock_adapter:
            instance = mock_adapter.return_value
            instance.complete.side_effect = completions
            find_minimal_edit(PROMPT, MODEL, on_progress=lambda p, d: progress_calls.append(p))
        assert "baseline" in progress_calls
        assert "omit" in progress_calls

    def test_fallback_to_min_delta_when_no_drop(self):
        # All edits slightly boost confidence
        confs = [0.8] + [0.81] * 30
        result = self._run(confs)
        # Should still return something (min delta)
        assert result is not None


@pytest.mark.integration
class TestFindMinimalEditV2:
    """Test v2 gradient perturbation search logic."""

    PROMPT = "Is Paris the capital of France"  # 6 words, simple

    def _run_v2(
        self,
        side_effects: list[float],
        top_k: int = 3,
        progress: list | None = None,
    ) -> MinimalEditResult:
        completions = [_make_completion(c) for c in side_effects]
        with patch("yuragi.analysis.minimal_edit.LLMAdapter") as mock_adapter:
            instance = mock_adapter.return_value
            instance.complete.side_effect = completions
            cb = None
            if progress is not None:
                cb = lambda p, d: progress.append((p, d))  # noqa: E731
            return find_minimal_edit_v2(self.PROMPT, MODEL, top_k=top_k, on_progress=cb)

    def _enough_confs(self, baseline: float = 0.8, default: float = 0.75) -> list[float]:
        """Build a long enough side_effect list for a full v2 run."""
        # Phase 1: 6 omissions
        # Phase 2: C(3,2)=3 pairs (top_k=3)
        # Phase 3: depends on chars in top word — worst case ~10
        # Phase 4: 12 insert words + 3 prefix insertions (if insert_pos != 0)
        return [baseline] + [default] * 80

    def test_returns_minimal_edit_result(self):
        result = self._run_v2(self._enough_confs())
        assert isinstance(result, MinimalEditResult)

    def test_baseline_confidence_stored(self):
        result = self._run_v2(self._enough_confs(baseline=0.9))
        assert result.baseline_confidence == pytest.approx(0.9)

    def test_phase1_has_all_words(self):
        result = self._run_v2(self._enough_confs())
        word_count = len(self.PROMPT.split())
        assert len(result.phase1_omissions) == word_count

    def test_phase1_delta_recorded(self):
        # Make second completion (first omission) very low
        confs = [0.8, 0.3] + [0.75] * 80
        result = self._run_v2(confs)
        assert result.phase1_omissions[0].delta == pytest.approx(0.3 - 0.8)

    def test_phase2_pair_count(self):
        # top_k=3 → C(3,2)=3 pairs
        result = self._run_v2(self._enough_confs(), top_k=3)
        assert len(result.phase2_pairs) == 3

    def test_interaction_term_computed(self):
        # baseline=0.8
        # Phase1: word0 delta=-0.3, word1 delta=-0.2, word2 delta=-0.1
        # (top_k=3, so these three are selected)
        # Phase2: pair(0,1) delta=-0.6 → interaction = -0.6 - (-0.3 + -0.2) = -0.1
        confs = [0.8]  # baseline
        # Phase1: 6 word omissions
        confs += [0.5, 0.6, 0.7, 0.75, 0.75, 0.75]
        # Phase2: 3 pairs (top_k=3: indices 0,1,2)
        confs += [0.2, 0.65, 0.7]
        confs += [0.75] * 60
        result = self._run_v2(confs, top_k=3)
        pair_01 = next(
            p for p in result.phase2_pairs
            if {p.index_a, p.index_b} == {0, 1}
        )
        # delta_pair = 0.2 - 0.8 = -0.6
        # delta_a = 0.5-0.8 = -0.3, delta_b = 0.6-0.8 = -0.2
        # interaction = -0.6 - (-0.3 + -0.2) = -0.6 - (-0.5) = -0.1
        assert pair_01.interaction_term == pytest.approx(-0.1, abs=1e-6)

    def test_phase3_char_edits_populated(self):
        result = self._run_v2(self._enough_confs())
        # As long as top word has QWERTY-adjacent chars, phase3 should have entries
        assert len(result.phase3_char_edits) >= 0  # could be 0 for words with no adjacencies

    def test_phase4_insertions_populated(self):
        result = self._run_v2(self._enough_confs())
        assert len(result.phase4_insertions) > 0

    def test_best_edit_set_when_drop_exists(self):
        # Make one phase1 omission produce a big drop
        confs = [0.8, 0.2] + [0.75] * 80
        result = self._run_v2(confs)
        assert result.best_edit is not None
        assert result.best_edit.confidence_delta < -0.05

    def test_best_edit_type_omit_word_when_most_efficient(self):
        # First omission is the most efficient (small word + big drop)
        # "Is" is 2 chars → edit_distance=3, delta=-0.6 → efficiency=0.2
        confs = [0.8, 0.2] + [0.75] * 80
        result = self._run_v2(confs)
        assert result.best_edit is not None
        assert result.best_edit.edit_type in (
            "omit_word", "omit_pair", "replace_char", "insert_word"
        )

    def test_on_progress_phases_reported(self):
        progress: list[tuple[str, str]] = []
        self._run_v2(self._enough_confs(), progress=progress)
        phases = {p for p, _ in progress}
        assert "baseline" in phases
        assert "phase1" in phases
        assert "phase2" in phases

    def test_single_word_prompt(self):
        """Single-word prompt: Phase 1 skipped (need >1 word), rest runs."""
        confs = [0.8] + [0.75] * 40
        completions = [_make_completion(c) for c in confs]
        with patch("yuragi.analysis.minimal_edit.LLMAdapter") as mock_adapter:
            instance = mock_adapter.return_value
            instance.complete.side_effect = completions
            result = find_minimal_edit_v2("Paris", MODEL)
        assert isinstance(result, MinimalEditResult)
        assert len(result.phase1_omissions) == 0  # only 1 word
        # Phase 2 also skipped (needs >= 2 top-k words)
        assert len(result.phase2_pairs) == 0

    def test_top_k_capped_by_available_words(self):
        """top_k larger than word count doesn't crash."""
        confs = [0.8] + [0.75] * 80
        result = self._run_v2(confs, top_k=100)
        # Should still produce pairs from however many words exist
        assert isinstance(result, MinimalEditResult)

    def test_phase4_prefix_included_when_insert_pos_nonzero(self):
        """Prefix insertions are added when best insert position is not 0."""
        result = self._run_v2(self._enough_confs())
        # insert_pos = topk_words[0].word_index
        # If not 0, prefixes also get tested
        [
            r for r in result.phase4_insertions if " " in r.inserted_word or "?" in r.inserted_word
        ]
        # At least some insertions exist regardless
        assert len(result.phase4_insertions) > 0
