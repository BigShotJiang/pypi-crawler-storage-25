"""Tests for multilingual perturbation enhancements."""

from yuragi.perturbations.paraphrase import generate_paraphrase
from yuragi.perturbations.semantic import generate_semantic
from yuragi.perturbations.synonym import generate_synonym
from yuragi.perturbations.tone import generate_tone


class TestSynonymExpanded:
    def test_english_academic_category(self):
        variants = generate_synonym("analyze the data and evaluate the results")
        assert variants

    def test_english_technical_category(self):
        variants = generate_synonym("there is an error in the system process")
        assert variants

    def test_english_daily_extended(self):
        variants = generate_synonym("I always want to learn new things")
        assert variants

    def test_japanese_verbs(self):
        variants = generate_synonym("この問題を調べて解決方法を考える")
        assert variants

    def test_japanese_adjectives(self):
        variants = generate_synonym("新しい方法は速くて正しい")
        assert variants

    def test_japanese_adverbs(self):
        variants = generate_synonym("すぐに全ての情報を調べる")
        assert variants

    def test_japanese_nouns(self):
        variants = generate_synonym("この問題の答えを求める")
        assert variants

    def test_over_50_japanese_entries(self):
        ja_keys = [
            k
            for k in [
                "説明",
                "教えて",
                "思う",
                "考える",
                "感じる",
                "見る",
                "言う",
                "聞く",
                "知る",
                "分かる",
                "作る",
                "使う",
                "始める",
                "終わる",
                "決める",
                "変える",
                "増やす",
                "減らす",
                "調べる",
                "求める",
                "良い",
                "悪い",
                "大きい",
                "小さい",
                "重要",
                "簡単",
                "難しい",
                "新しい",
                "古い",
                "速い",
                "遅い",
                "正しい",
                "間違った",
                "多い",
                "少ない",
                "強い",
                "弱い",
                "明るい",
                "暗い",
                "長い",
                "短い",
                "本当に",
                "絶対に",
                "たぶん",
                "とても",
                "すぐに",
                "ゆっくり",
                "よく",
                "少し",
                "全て",
                "だいたい",
                "特に",
                "もちろん",
                "きっと",
                "問題",
                "方法",
                "理由",
                "結果",
                "目的",
                "情報",
                "質問",
                "答え",
                "意見",
                "例",
                "違い",
                "影響",
                "仕事",
                "人",
            ]
        ]
        assert len(ja_keys) >= 50

    def test_english_over_100_entries(self):
        from yuragi.perturbations.synonym import _SYNONYMS

        en_keys = [k for k in _SYNONYMS if not any(ord(c) > 127 for c in k)]
        assert len(en_keys) >= 100

    def test_no_duplicates_in_results(self):
        variants = generate_synonym("This is a very important question about the answer")
        assert len(variants) == len(set(variants))


class TestToneExpanded:
    def test_japanese_ultra_polite(self):
        variants = generate_tone("量子コンピュータとは何ですか")
        assert any("誠に恐れ入りますが" in v or "大変お手数" in v for v in variants)

    def test_japanese_5_formality_levels(self):
        variants = generate_tone("これについて教えてください", num_variants=10)
        # Should have variants from multiple formality levels
        assert len(variants) >= 5

    def test_japanese_emotional_angry(self):
        variants = generate_tone("説明してください", num_variants=10)
        assert any("なぜ答えられないんですか" in v or "いい加減にしてください" in v for v in variants)

    def test_japanese_emotional_anxious(self):
        variants = generate_tone("大丈夫でしょうか", num_variants=10)
        assert any("不安なんですが" in v or "心配なので" in v for v in variants)

    def test_japanese_emotional_expectant(self):
        variants = generate_tone("教えてください", num_variants=10)
        assert any("ぜひ教えていただきたい" in v or "楽しみにしている" in v for v in variants)

    def test_english_academic_level(self):
        variants = generate_tone("explain the concept of entropy", num_variants=8)
        assert any("scholarly" in v or "Academically" in v or "academic" in v.lower() for v in variants)

    def test_english_professional_level(self):
        variants = generate_tone("explain quantum computing", num_variants=8)
        assert any("Please" in v or "Could you" in v or "appreciate" in v for v in variants)

    def test_english_casual_level(self):
        variants = generate_tone("explain quantum computing", num_variants=8)
        assert any("Hey" in v or "So," in v or "Quick question" in v for v in variants)

    def test_english_childlike_level(self):
        variants = generate_tone("explain quantum computing", num_variants=8)
        assert any("Can you tell me" in v or "I want to know" in v for v in variants)

    def test_english_4_levels_present(self):
        variants = generate_tone("tell me about gravity", num_variants=8)
        assert len(variants) >= 4


class TestParaphraseExpanded:
    def test_japanese_sentence_ending_desu_to_dearu(self):
        variants = generate_paraphrase("これは重要な問題です。", num_variants=5)
        assert any("である。" in v for v in variants)

    def test_japanese_sentence_ending_desu_to_da(self):
        variants = generate_paraphrase("これは重要な問題です。", num_variants=5)
        assert any("だ。" in v for v in variants)

    def test_japanese_question_desuka_to_deshouka(self):
        variants = generate_paraphrase("これは正しいですか？", num_variants=5)
        assert any("でしょうか？" in v for v in variants)

    def test_japanese_question_desuka_to_nano(self):
        variants = generate_paraphrase("これは正しいですか？", num_variants=5)
        assert any("なの？" in v for v in variants)

    def test_japanese_question_desuka_to_kana(self):
        variants = generate_paraphrase("これは正しいですか？", num_variants=5)
        assert any("かな？" in v for v in variants)

    def test_japanese_connector_tokoro_de(self):
        variants = generate_paraphrase("これは重要です。", num_variants=6)
        assert any("ところで" in v for v in variants)

    def test_japanese_connector_chinamini(self):
        variants = generate_paraphrase("教えてください。", num_variants=8)
        assert any("ちなみに" in v or "実は" in v or "ところで" in v for v in variants)

    def test_japanese_prefix_restructure(self):
        variants = generate_paraphrase("AIとは何ですか")
        assert variants

    def test_english_no_duplicates(self):
        variants = generate_paraphrase("What is the capital of France?", num_variants=5)
        assert len(variants) == len(set(variants))

    def test_empty_unchanged(self):
        assert generate_paraphrase("") == []


class TestSemantic:
    def test_english_active_to_passive(self):
        variants = generate_semantic("The cat ate the fish")
        assert any("was eaten by" in v for v in variants)

    def test_english_passive_to_active(self):
        variants = generate_semantic("The fish was eaten by the cat")
        assert any("ate" in v and "was eaten" not in v for v in variants)

    def test_english_affirmative_to_double_neg(self):
        variants = generate_semantic("It is possible to achieve this goal")
        assert any("not impossible" in v for v in variants)

    def test_english_double_neg_to_affirmative(self):
        variants = generate_semantic("It is not impossible to solve this")
        assert any("is possible" in v for v in variants)

    def test_english_concrete_to_abstract(self):
        variants = generate_semantic("Paris is a beautiful city")
        assert any("capital of France" in v for v in variants)

    def test_english_abstract_to_concrete(self):
        variants = generate_semantic("the capital of France is known for its cuisine")
        assert any("Paris" in v for v in variants)

    def test_japanese_active_to_passive(self):
        variants = generate_semantic("猫が魚を食べた。")
        assert any("食べられた" in v for v in variants)

    def test_japanese_passive_to_active(self):
        variants = generate_semantic("魚が猫に食べられた。")
        assert any("食べた" in v and "食べられた" not in v for v in variants)

    def test_japanese_affirmative_to_double_neg(self):
        variants = generate_semantic("この問題を解決することは可能です。")
        assert any("不可能ではありません" in v for v in variants)

    def test_japanese_double_neg_to_affirmative(self):
        variants = generate_semantic("これは不可能ではありません。")
        assert any("可能です" in v for v in variants)

    def test_japanese_concrete_to_abstract(self):
        variants = generate_semantic("東京は大きな都市です。")
        assert any("日本の首都" in v for v in variants)

    def test_japanese_abstract_to_concrete(self):
        variants = generate_semantic("日本の首都はとても賑やかです。")
        assert any("東京" in v for v in variants)

    def test_empty_input(self):
        assert generate_semantic("") == []

    def test_no_match_returns_empty(self):
        variants = generate_semantic("xyzzy plugh foobar")
        assert variants == []

    def test_no_duplicates(self):
        variants = generate_semantic("The cat ate the fish and Paris is the capital of France")
        assert len(variants) == len(set(variants))

    def test_variants_differ_from_original(self):
        original = "The cat ate the fish"
        variants = generate_semantic(original)
        for v in variants:
            assert v != original

    def test_perturbation_enum_includes_semantic(self):
        from yuragi.perturbations import Perturbation

        assert Perturbation.SEMANTIC in Perturbation
        assert Perturbation.SEMANTIC.value == "semantic"

    def test_semantic_generator_callable(self):
        from yuragi.perturbations import Perturbation

        gen = Perturbation.SEMANTIC.generator
        result = gen("The cat ate the fish")
        assert isinstance(result, list)
