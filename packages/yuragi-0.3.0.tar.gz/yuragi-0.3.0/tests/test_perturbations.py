"""Tests for perturbation generators."""


from yuragi.perturbations.omit import (
    generate_clause_omit,
    generate_omit,
    generate_phrase_omit,
    generate_progressive_omit,
    generate_selective_omit,
)
from yuragi.perturbations.paraphrase import generate_paraphrase
from yuragi.perturbations.reorder import (
    generate_clause_reorder,
    generate_emphasis_shift,
    generate_japanese_reorder,
    generate_question_restructure,
    generate_reorder,
)
from yuragi.perturbations.synonym import generate_synonym
from yuragi.perturbations.tone import generate_tone
from yuragi.perturbations.typo import generate_typo


class TestTypo:
    def test_generates_variants(self):
        variants = generate_typo("This is a simple test sentence", num_variants=3)
        assert variants
        assert len(variants) <= 3

    def test_variants_differ_from_original(self):
        original = "This is a simple test sentence"
        variants = generate_typo(original, num_variants=3)
        for v in variants:
            assert v != original

    def test_preserves_length(self):
        original = "Hello world test"
        variants = generate_typo(original, num_variants=2)
        for v in variants:
            # Typo replaces chars, doesn't add/remove
            assert len(v.split()) == len(original.split())

    def test_empty_input(self):
        assert generate_typo("") == []

    def test_short_words_only(self):
        variants = generate_typo("a b c", num_variants=2)
        # Very short words have limited typo candidates
        assert isinstance(variants, list)

    def test_no_duplicates(self):
        variants = generate_typo("Testing the duplicate detection system", num_variants=5)
        assert len(variants) == len(set(variants))


class TestSynonym:
    def test_generates_variants_english(self):
        variants = generate_synonym("This is a very important question")
        assert variants

    def test_generates_variants_japanese(self):
        variants = generate_synonym("これは本当に重要な問題です")
        assert variants

    def test_empty_input(self):
        assert generate_synonym("") == []

    def test_no_synonyms_available(self):
        # Gibberish has no synonyms
        variants = generate_synonym("xyzzy plugh")
        assert len(variants) == 0

    def test_variants_differ(self):
        original = "Explain the important problem"
        variants = generate_synonym(original)
        for v in variants:
            assert v != original


class TestOmit:
    def test_generates_all_omissions(self):
        text = "one two three four"
        variants = generate_omit(text)
        assert len(variants) == 4
        assert "two three four" in variants
        assert "one three four" in variants
        assert "one two four" in variants
        assert "one two three" in variants

    def test_limited_variants(self):
        text = "one two three four five six"
        variants = generate_omit(text, num_variants=3)
        assert len(variants) == 3

    def test_single_word(self):
        assert generate_omit("hello") == []

    def test_empty(self):
        assert generate_omit("") == []


class TestReorder:
    def test_generates_variants(self):
        variants = generate_reorder("one two three four five", num_variants=3)
        assert variants
        assert len(variants) <= 3

    def test_same_word_count(self):
        original = "one two three four"
        variants = generate_reorder(original, num_variants=2)
        for v in variants:
            assert len(v.split()) == len(original.split())

    def test_short_input(self):
        assert generate_reorder("hi there") == []
        assert generate_reorder("hello") == []


class TestClauseReorder:
    def test_single_clause_returns_empty(self):
        assert generate_clause_reorder("Hello world") == []

    def test_generates_variants(self):
        text = "cats are cute, dogs are loyal, birds can fly"
        variants = generate_clause_reorder(text, num_variants=3)
        assert variants

    def test_same_words_different_order(self):
        text = "first clause, second clause, third clause"
        variants = generate_clause_reorder(text, num_variants=5)
        for v in variants:
            assert v != text
            # All original words should still be present
            for word in ["first", "second", "third", "clause"]:
                assert word in v

    def test_preserves_sentence_end_punctuation(self):
        text = "apples, oranges, bananas."
        variants = generate_clause_reorder(text, num_variants=3)
        for v in variants:
            assert v.endswith(".")


class TestQuestionRestructure:
    def test_what_is(self):
        variants = generate_question_restructure("What is Python?")
        assert variants
        assert any("Python" in v for v in variants)

    def test_is_x_y(self):
        variants = generate_question_restructure("Is Paris a city?")
        assert variants

    def test_can_x(self):
        variants = generate_question_restructure("Can birds fly?")
        assert variants

    def test_unmatched_returns_empty(self):
        assert generate_question_restructure("Tell me everything.") == []

    def test_output_contains_key_words(self):
        variants = generate_question_restructure("What is gravity?")
        combined = " ".join(variants).lower()
        assert "gravity" in combined


class TestEmphasisShift:
    def test_generates_variants(self):
        variants = generate_emphasis_shift("The quick brown fox jumps over", num_variants=2)
        assert variants

    def test_same_word_count(self):
        original = "The capital of France is Paris"
        variants = generate_emphasis_shift(original, num_variants=3)
        orig_count = len(original.split())
        for v in variants:
            assert len(v.split()) == orig_count

    def test_short_input_returns_empty(self):
        assert generate_emphasis_shift("hi") == []
        assert generate_emphasis_shift("hello world") == []

    def test_variants_differ_from_original(self):
        original = "Scientists discovered a new planet recently"
        variants = generate_emphasis_shift(original, num_variants=3)
        for v in variants:
            assert v != original


class TestJapaneseReorder:
    def test_ignores_english(self):
        assert generate_japanese_reorder("Hello world") == []

    def test_generates_variants_for_sov(self):
        # 猫は魚を食べる = "The cat eats fish"
        variants = generate_japanese_reorder("猫は魚を食べる")
        assert variants

    def test_variants_contain_original_morphemes(self):
        variants = generate_japanese_reorder("猫は魚を食べる")
        for v in variants:
            assert "猫" in v or "魚" in v


class TestPhraseOmit:
    def test_two_word_phrase(self):
        text = "one two three four five"
        variants = generate_phrase_omit(text, phrase_len=2)
        assert variants
        for v in variants:
            assert len(v.split()) == 3  # 5 - 2

    def test_three_word_phrase(self):
        text = "one two three four five"
        variants = generate_phrase_omit(text, phrase_len=3)
        for v in variants:
            assert len(v.split()) == 2  # 5 - 3

    def test_too_short_returns_empty(self):
        assert generate_phrase_omit("hello world", phrase_len=3) == []

    def test_num_variants_limit(self):
        text = "a b c d e f g h"
        variants = generate_phrase_omit(text, phrase_len=2, num_variants=2)
        assert len(variants) <= 2


class TestClauseOmit:
    def test_removes_one_clause(self):
        text = "Paris is beautiful, London is rainy, Tokyo is busy"
        variants = generate_clause_omit(text)
        assert len(variants) == 3  # 3 clauses → 3 variants each missing one

    def test_no_clauses_returns_empty(self):
        assert generate_clause_omit("No clauses here") == []

    def test_variants_shorter(self):
        text = "first, second, third"
        variants = generate_clause_omit(text)
        for v in variants:
            assert len(v) < len(text)


class TestSelectiveOmit:
    def test_noun_omission(self):
        # "Python" starts with capital → noun heuristic
        text = "Python is a powerful Language for Data science"
        variants = generate_selective_omit(text, pos="noun")
        assert variants

    def test_adj_omission(self):
        text = "A powerful and beautiful solution"
        variants = generate_selective_omit(text, pos="adj")
        assert isinstance(variants, list)

    def test_no_match_returns_empty(self):
        # All lowercase stopwords → no nouns detected
        assert generate_selective_omit("a the is of", pos="noun") == []

    def test_num_variants_limit(self):
        text = "The Quick Brown Fox Jumps Over The Lazy Dog"
        variants = generate_selective_omit(text, pos="noun", num_variants=2)
        assert len(variants) <= 2


class TestProgressiveOmit:
    def test_returns_list_of_lists(self):
        result = generate_progressive_omit("one two three four five", max_words=3)
        assert len(result) == 3
        assert all(isinstance(level, list) for level in result)

    def test_depths_decrease_word_count(self):
        text = "one two three four five"
        result = generate_progressive_omit(text, max_words=3)
        base_len = len(text.split())
        for depth_idx, variants in enumerate(result, start=1):
            for v in variants:
                assert len(v.split()) == base_len - depth_idx


class TestTone:
    def test_generates_english_variants(self):
        variants = generate_tone("What is the meaning of life?")
        assert variants

    def test_generates_japanese_variants(self):
        variants = generate_tone("量子コンピュータは実用化されるか")
        assert variants

    def test_includes_authority_and_doubt(self):
        variants = generate_tone("Explain quantum computing")
        # Should include both authority-boosting and doubt-inducing variants
        assert len(variants) >= 4

    def test_variants_differ(self):
        original = "Tell me about AI"
        variants = generate_tone(original)
        for v in variants:
            assert v != original


class TestParaphrase:
    def test_generates_english_variants(self):
        variants = generate_paraphrase("What is the meaning of life?")
        assert variants

    def test_generates_japanese_variants(self):
        variants = generate_paraphrase("とは何ですか")
        assert variants

    def test_empty_input(self):
        assert generate_paraphrase("") == []

    def test_no_matching_patterns(self):
        # Should still get prefix-based variants
        variants = generate_paraphrase("The cat sat on the mat")
        assert variants
