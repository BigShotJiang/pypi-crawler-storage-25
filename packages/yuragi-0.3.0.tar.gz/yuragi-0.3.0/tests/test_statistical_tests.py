"""Unit tests for yuragi.metrics.statistical_tests."""

from __future__ import annotations

import pytest

from yuragi.metrics.statistical_tests import (
    CIResult,
    EffectSizeResult,
    TestResult,
    bootstrap_ci,
    cohens_d,
    paired_t_test,
    wilcoxon_signed_rank,
)


class TestCohensD:
    def test_same_distribution_near_zero(self):
        a = [0.5, 0.6, 0.5, 0.6, 0.5]
        b = [0.5, 0.6, 0.5, 0.6, 0.5]
        result = cohens_d(a, b)
        assert isinstance(result, EffectSizeResult)
        assert abs(result.cohens_d) < 1e-9
        assert result.interpretation == "negligible"
        assert result.n == 10

    def test_large_mean_difference(self):
        import numpy as np

        rng = np.random.default_rng(0)
        # Use noisy groups to avoid zero-variance pooled_std
        a = list(rng.normal(0.9, 0.05, 20))
        b = list(rng.normal(0.1, 0.05, 20))
        result = cohens_d(a, b)
        assert result.cohens_d > 0
        assert result.interpretation == "large"

    def test_small_effect(self):
        import numpy as np

        rng = np.random.default_rng(42)
        # Two groups with overlapping distributions → small effect
        a = list(rng.normal(0.52, 0.1, 30))
        b = list(rng.normal(0.50, 0.1, 30))
        result = cohens_d(a, b)
        assert result.interpretation in ("small", "medium", "negligible")

    def test_zero_variance_returns_zero(self):
        a = [0.5, 0.5, 0.5]
        b = [0.5, 0.5, 0.5]
        result = cohens_d(a, b)
        assert result.cohens_d == 0.0
        assert result.interpretation == "negligible"

    def test_insufficient_data_raises(self):
        with pytest.raises(ValueError, match="at least 2"):
            cohens_d([0.5], [0.6, 0.7])

    def test_negative_d_when_b_higher(self):
        a = [0.1, 0.2, 0.1, 0.2]
        b = [0.8, 0.9, 0.8, 0.9]
        result = cohens_d(a, b)
        assert result.cohens_d < 0

    def test_medium_interpretation(self):
        import numpy as np

        rng = np.random.default_rng(42)
        a = list(rng.normal(0.5, 0.1, 50))
        b = list(rng.normal(0.56, 0.1, 50))  # ~0.6 std difference
        result = cohens_d(a, b)
        assert result.interpretation in ("small", "medium", "negligible")


class TestPairedTTest:
    def test_null_hypothesis_not_rejected(self):
        import numpy as np

        rng = np.random.default_rng(0)
        # Two samples from same distribution — differences should be near zero
        base = list(rng.normal(0.5, 0.05, 30))
        noise = [x + rng.normal(0, 0.001) for x in base]
        result = paired_t_test(base, noise)
        assert isinstance(result, TestResult)
        assert result.test_name == "paired_t_test"
        assert not result.significant
        assert result.p_value > 0.05

    def test_significant_difference(self):
        a = [0.9] * 20
        b = [0.1] * 20
        result = paired_t_test(a, b)
        assert result.significant
        assert result.p_value < 0.05

    def test_unequal_length_raises(self):
        with pytest.raises(ValueError, match="equal length"):
            paired_t_test([0.5, 0.6], [0.5])

    def test_custom_alpha(self):
        a = [0.5, 0.6, 0.5, 0.6, 0.5]
        b = [0.4, 0.5, 0.4, 0.5, 0.4]
        # With alpha=0.5, likely significant
        result_lenient = paired_t_test(a, b, alpha=0.5)
        # With alpha=0.001, likely not significant
        result_strict = paired_t_test(a, b, alpha=0.001)
        assert result_lenient.significant or not result_strict.significant


class TestWilcoxon:
    def test_identical_groups(self):
        a = [0.5, 0.6, 0.7, 0.8, 0.9]
        result = wilcoxon_signed_rank(a, a)
        assert result.test_name == "wilcoxon_signed_rank"
        assert not result.significant

    def test_clearly_different(self):
        a = [0.9, 0.85, 0.95, 0.88, 0.92, 0.91, 0.87, 0.93, 0.89, 0.94]
        b = [0.1, 0.15, 0.05, 0.12, 0.08, 0.11, 0.13, 0.07, 0.09, 0.06]
        result = wilcoxon_signed_rank(a, b)
        assert result.significant


class TestBootstrapCI:
    def test_seed_reproducibility(self):
        data = [0.3, 0.5, 0.7, 0.4, 0.6, 0.8, 0.2, 0.9]
        r1 = bootstrap_ci(data, seed=42)
        r2 = bootstrap_ci(data, seed=42)
        assert r1.lower == r2.lower
        assert r1.upper == r2.upper

    def test_different_seeds_differ(self):
        data = [0.3, 0.5, 0.7, 0.4, 0.6, 0.8, 0.2, 0.9]
        r1 = bootstrap_ci(data, seed=1)
        r2 = bootstrap_ci(data, seed=999)
        # Very unlikely to be identical with different seeds
        assert r1.lower != r2.lower or r1.upper != r2.upper

    def test_ci_bounds_ordered(self):
        data = [0.2, 0.4, 0.6, 0.8, 0.5, 0.3, 0.7, 0.9]
        result = bootstrap_ci(data, seed=0)
        assert isinstance(result, CIResult)
        assert result.lower < result.upper
        assert result.confidence_level == 0.95

    def test_custom_ci_level(self):
        data = [0.2, 0.4, 0.6, 0.8, 0.5, 0.3, 0.7, 0.9]
        r99 = bootstrap_ci(data, ci=0.99, seed=0)
        r80 = bootstrap_ci(data, ci=0.80, seed=0)
        assert r99.confidence_level == 0.99
        assert r80.confidence_level == 0.80
        # Wider CI for higher confidence level
        assert (r99.upper - r99.lower) >= (r80.upper - r80.lower)

    def test_empty_raises(self):
        with pytest.raises(ValueError, match="empty"):
            bootstrap_ci([])

    def test_mean_within_ci(self):
        data = [0.3, 0.5, 0.7, 0.4, 0.6, 0.5, 0.4, 0.6]
        result = bootstrap_ci(data, n_iterations=5000, seed=42)
        mean = sum(data) / len(data)
        assert result.lower <= mean <= result.upper
