"""Tests for custom exception hierarchy and ScanResult serialization."""

import json

import pytest

from yuragi.core import ScanResult
from yuragi.exceptions import (
    APIKeyMissingError,
    CacheError,
    ExperimentError,
    ModelNotFoundError,
    ScanError,
    YuragiError,
)


class TestExceptionHierarchy:
    def test_yuragi_error_is_exception(self):
        assert issubclass(YuragiError, Exception)

    def test_model_not_found_is_yuragi_error(self):
        assert issubclass(ModelNotFoundError, YuragiError)

    def test_api_key_missing_is_yuragi_error(self):
        assert issubclass(APIKeyMissingError, YuragiError)

    def test_scan_error_is_yuragi_error(self):
        assert issubclass(ScanError, YuragiError)

    def test_cache_error_is_yuragi_error(self):
        assert issubclass(CacheError, YuragiError)

    def test_experiment_error_is_yuragi_error(self):
        assert issubclass(ExperimentError, YuragiError)

    def test_all_catchable_as_yuragi_error(self):
        for exc_cls in (ModelNotFoundError, APIKeyMissingError, ScanError, CacheError, ExperimentError):
            with pytest.raises(YuragiError):
                raise exc_cls("test")

    def test_importable_from_top_level(self):
        import yuragi

        assert yuragi.YuragiError is YuragiError
        assert yuragi.ScanError is ScanError
        assert yuragi.APIKeyMissingError is APIKeyMissingError


class TestScanResultSerialization:
    def test_to_dict_keys(self, make_scan_result):
        result = make_scan_result(prompt="test prompt", model="test-model")
        d = result.to_dict()
        assert "prompt" in d
        assert "model" in d
        assert "baseline" in d
        assert "perturbation_results" in d

    def test_to_summary_dict_keys(self, make_scan_result):
        result = make_scan_result(prompt="test prompt", model="test-model")
        d = result.to_summary_dict()
        assert d["prompt"] == "test prompt"
        assert d["model"] == "test-model"
        assert "fragility_score" in d
        assert "perturbations" in d
        assert isinstance(d["perturbations"], list)

    def test_to_json_is_valid_json(self, make_scan_result):
        result = make_scan_result(prompt="test prompt")
        raw = result.to_json()
        parsed = json.loads(raw)
        assert parsed["prompt"] == "test prompt"
        assert "fragility_score" in parsed

    def test_to_json_contains_perturbations(self, make_scan_result):
        result = make_scan_result()
        parsed = json.loads(result.to_json())
        assert len(parsed["perturbations"]) >= 1
        p = parsed["perturbations"][0]
        assert p["type"] == "omit"
        assert "delta" in p
        assert "answer_changed" in p

    def test_to_json_ensure_ascii_false(self, make_completion):
        baseline = make_completion("日本語テスト", 0.7)
        result = ScanResult(
            prompt="日本語プロンプト",
            model="test-model",
            baseline=baseline,
        )
        raw = result.to_json()
        assert "日本語" in raw
