"""Tests for the multi-model fragility heatmap visualization."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

# Force non-interactive matplotlib backend before importing anything visual
os.environ.setdefault("MPLBACKEND", "Agg")

pytest.importorskip("matplotlib")

from yuragi.visualize.multi_model_heatmap import plot_multi_model_heatmap


def _sample_scores() -> dict[str, dict[str, float]]:
    return {
        "llama3.2:3b": {"factual": 0.92, "creative": 0.08, "ethical": 0.29},
        "qwen2.5:3b": {"factual": 0.87, "creative": 0.12, "ethical": 0.33},
        "phi4-mini": {"factual": 0.78, "creative": 0.15, "ethical": 0.41},
    }


class TestPlotMultiModelHeatmap:
    def test_saves_png_to_path(self, tmp_path: Path) -> None:
        out = tmp_path / "heatmap.png"
        plot_multi_model_heatmap(_sample_scores(), save_path=str(out))
        assert out.exists()
        assert out.stat().st_size > 0

    def test_handles_missing_prompt_as_nan(self, tmp_path: Path) -> None:
        sparse = {
            "model_a": {"prompt1": 0.5, "prompt2": 0.3},
            "model_b": {"prompt1": 0.4},  # prompt2 missing
        }
        out = tmp_path / "sparse.png"
        plot_multi_model_heatmap(sparse, save_path=str(out))
        assert out.exists()

    def test_empty_scores_produces_empty_figure(self, tmp_path: Path) -> None:
        out = tmp_path / "empty.png"
        plot_multi_model_heatmap({}, save_path=str(out))
        assert out.exists()

    def test_single_model_single_prompt(self, tmp_path: Path) -> None:
        minimal = {"only_model": {"only_prompt": 0.77}}
        out = tmp_path / "single.png"
        plot_multi_model_heatmap(minimal, save_path=str(out))
        assert out.exists()
