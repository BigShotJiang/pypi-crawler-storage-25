"""Tests for fluent (builder) API, Session, and top-level convenience functions."""

import pytest

from yuragi.core import ScannerBuilder, Session
from yuragi.perturbations import Perturbation
from yuragi.providers.adapter import CompletionResult

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fake_scan_result(prompt="test", model="test-model", fragility=0.5):
    from yuragi.core import PerturbationResult, ScanResult

    baseline = CompletionResult(text="yes", confidence=0.8, confidence_method="sampling")
    perturbed = CompletionResult(
        text="yes", confidence=0.8 - fragility, confidence_method="sampling"
    )
    pr = PerturbationResult(
        original_prompt=prompt,
        perturbed_prompt=prompt + " mod",
        perturbation_type="omit",
        original_response=baseline,
        perturbed_response=perturbed,
    )
    return ScanResult(
        prompt=prompt,
        model=model,
        baseline=baseline,
        perturbation_results=[pr],
    )


def _patch_scanner(monkeypatch, fake_result=None):
    """Patch Scanner.__init__ and Scanner.scan so no litellm calls are made."""
    import yuragi.core as core_mod

    if fake_result is None:
        fake_result = _fake_scan_result()

    def _fake_init(self, model="gpt-4o-mini", **kwargs):
        self.model = model
        self.perturbations = kwargs.get("perturbations") or []
        self.num_variants = kwargs.get("num_variants", 3)
        self.verbose = kwargs.get("verbose", False)
        self.on_progress = kwargs.get("on_progress")
        self.parallel = kwargs.get("parallel", 1)

    monkeypatch.setattr(core_mod.Scanner, "__init__", _fake_init)
    monkeypatch.setattr(core_mod.Scanner, "scan", lambda self, p, system=None: fake_result)
    return fake_result


# ---------------------------------------------------------------------------
# ScannerBuilder
# ---------------------------------------------------------------------------


class TestScannerBuilder:
    def test_returns_builder_from_constructor(self):
        b = ScannerBuilder("hello")
        assert isinstance(b, ScannerBuilder)

    def test_fluent_chain_returns_self(self):
        b = ScannerBuilder("hello")
        assert b.model("gpt-4o") is b
        assert b.samples(3) is b
        assert b.variants(2) is b
        assert b.verbose(False) is b
        assert b.cache(True) is b
        assert b.parallel(1) is b
        assert b.system("be concise") is b

    def test_perturbations_by_name(self):
        b = ScannerBuilder("hello")
        b.perturbations("tone", "omit")
        assert b._perturbations == [Perturbation.TONE, Perturbation.OMIT]

    def test_perturbations_by_enum(self):
        b = ScannerBuilder("hello")
        b.perturbations(Perturbation.TYPO, Perturbation.SYNONYM)
        assert b._perturbations == [Perturbation.TYPO, Perturbation.SYNONYM]

    def test_perturbations_mixed(self):
        b = ScannerBuilder("hello")
        b.perturbations("tone", Perturbation.OMIT)
        assert b._perturbations == [Perturbation.TONE, Perturbation.OMIT]

    def test_perturbations_invalid_name_raises(self):
        b = ScannerBuilder("hello")
        with pytest.raises(Exception):
            b.perturbations("not_a_real_perturbation")

    def test_model_sets_attribute(self):
        b = ScannerBuilder("hello").model("ollama/llama3.2")
        assert b._model == "ollama/llama3.2"

    def test_samples_sets_attribute(self):
        b = ScannerBuilder("hello").samples(7)
        assert b._num_samples == 7

    def test_system_sets_attribute(self):
        b = ScannerBuilder("hello").system("you are a helper")
        assert b._system == "you are a helper"

    def test_run_calls_scanner(self, monkeypatch):
        expected = _patch_scanner(monkeypatch)
        result = ScannerBuilder("prompt").model("test-model").run()
        assert result is expected


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------


class TestSession:
    def test_scan_outside_context_raises(self):
        s = Session(model="test")
        with pytest.raises(Exception):
            s.scan("hello")

    def test_scan_inside_context(self, monkeypatch):
        expected = _patch_scanner(monkeypatch)
        with Session(model="test-model") as s:
            result = s.scan("hello")
        assert result is expected

    def test_scanner_none_after_exit(self, monkeypatch):
        _patch_scanner(monkeypatch)
        s = Session(model="test-model")
        with s:
            pass
        assert s._scanner is None

    def test_multiple_scans_use_same_scanner(self, monkeypatch):
        import yuragi.core as core_mod

        scanner_ids: list[int] = []
        fake = _fake_scan_result()

        def _fake_init(self, model="gpt-4o-mini", **kwargs):
            self.model = model

        def _fake_scan(self, prompt, system=None):
            scanner_ids.append(id(self))
            return fake

        monkeypatch.setattr(core_mod.Scanner, "__init__", _fake_init)
        monkeypatch.setattr(core_mod.Scanner, "scan", _fake_scan)

        with Session(model="test-model") as s:
            s.scan("p1")
            s.scan("p2")

        assert len(scanner_ids) == 2
        assert scanner_ids[0] == scanner_ids[1]


# ---------------------------------------------------------------------------
# Top-level convenience functions
# ---------------------------------------------------------------------------


class TestTopLevelAPI:
    def test_scan_no_kwargs_returns_builder(self):
        import yuragi

        b = yuragi.scan("hello")
        assert isinstance(b, ScannerBuilder)

    def test_scan_no_kwargs_model_set(self):
        import yuragi

        b = yuragi.scan("hello", model="ollama/llama3.2")
        assert b._model == "ollama/llama3.2"

    def test_scan_with_kwargs_runs_immediately(self, monkeypatch):
        import yuragi

        expected = _patch_scanner(monkeypatch)
        result = yuragi.scan("hello", model="test-model", num_samples=1)
        assert result is expected

    def test_fragility_score_returns_float(self, monkeypatch):
        import yuragi

        _patch_scanner(monkeypatch, _fake_scan_result(fragility=0.3))
        score = yuragi.fragility_score("hello", model="test-model")
        assert isinstance(score, float)
        assert 0.0 <= score <= 1.0

    def test_find_weakness_returns_perturbation_result_or_none(self, monkeypatch):
        import yuragi
        from yuragi.core import PerturbationResult

        _patch_scanner(monkeypatch)
        weakness = yuragi.find_weakness("hello", model="test-model")
        assert weakness is None or isinstance(weakness, PerturbationResult)

    def test_session_returns_session(self):
        import yuragi

        s = yuragi.session(model="test-model")
        assert isinstance(s, Session)

    def test_scanner_builder_and_session_in_all(self):
        import yuragi

        assert "ScannerBuilder" in yuragi.__all__
        assert "Session" in yuragi.__all__
        assert "scan" in yuragi.__all__
        assert "fragility_score" in yuragi.__all__
        assert "find_weakness" in yuragi.__all__
        assert "session" in yuragi.__all__
