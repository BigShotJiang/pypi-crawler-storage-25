"""Unit tests for yuragi.metrics.calibration."""

from __future__ import annotations

import math

import pytest

from yuragi.core import PerturbationResult, ScanResult
from yuragi.metrics.calibration import (
    CalibrationReport,
    brier_score,
    compute_calibration,
    confidence_surface_curvature,
    expected_calibration_error,
    mutual_information_score,
    overconfidence_score,
)
from yuragi.providers.adapter import CompletionResult

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _cr(
    text: str = "answer",
    confidence: float = 0.8,
    method: str = "sampling",
    raw_logprobs: list | None = None,
) -> CompletionResult:
    return CompletionResult(
        text=text,
        confidence=confidence,
        confidence_method=method,
        raw_logprobs=raw_logprobs,
    )


def _pr(
    orig_conf: float = 0.8,
    pert_conf: float = 0.8,
    orig_text: str = "same answer",
    pert_text: str = "same answer",
    ptype: str = "omit",
    orig_method: str = "sampling",
    pert_method: str = "sampling",
    orig_logprobs: list | None = None,
    pert_logprobs: list | None = None,
) -> PerturbationResult:
    return PerturbationResult(
        original_prompt="prompt",
        perturbed_prompt="prompt modified",
        perturbation_type=ptype,
        original_response=_cr(orig_text, orig_conf, orig_method, orig_logprobs),
        perturbed_response=_cr(pert_text, pert_conf, pert_method, pert_logprobs),
    )


def _scan(perturbation_results: list[PerturbationResult]) -> ScanResult:
    return ScanResult(
        prompt="test",
        model="test-model",
        baseline=_cr("baseline", 0.8),
        perturbation_results=perturbation_results,
    )


# ---------------------------------------------------------------------------
# ECE
# ---------------------------------------------------------------------------

class TestExpectedCalibrationError:
    def test_empty_returns_zero(self):
        assert expected_calibration_error([]) == 0.0

    def test_perfect_calibration(self):
        # conf=1.0, answer_unchanged -> accuracy=1.0: ECE should be 0
        results = [_pr(pert_conf=1.0, orig_text="ans", pert_text="ans") for _ in range(10)]
        ece = expected_calibration_error(results)
        assert ece == pytest.approx(0.0)

    def test_worst_case_calibration(self):
        # conf=1.0 but answer always changes: ECE approaches 1.0
        results = [_pr(pert_conf=1.0, orig_text="yes", pert_text="no absolutely different") for _ in range(10)]
        ece = expected_calibration_error(results)
        assert ece > 0.5

    def test_bounded_zero_one(self):
        results = [_pr(pert_conf=c) for c in [0.1, 0.3, 0.5, 0.7, 0.9]]
        ece = expected_calibration_error(results)
        assert 0.0 <= ece <= 1.0

    def test_single_result(self):
        result = [_pr(pert_conf=0.9, orig_text="ans", pert_text="ans")]
        ece = expected_calibration_error(result)
        assert 0.0 <= ece <= 1.0

    def test_n_bins_parameter(self):
        results = [_pr(pert_conf=c) for c in [0.2, 0.5, 0.8]]
        ece_10 = expected_calibration_error(results, n_bins=10)
        ece_5 = expected_calibration_error(results, n_bins=5)
        # Both should be valid floats in [0, 1]
        assert 0.0 <= ece_10 <= 1.0
        assert 0.0 <= ece_5 <= 1.0

    def test_mixed_outcomes(self):
        # Half correct (answer same) at high conf, half wrong at high conf
        same = [_pr(pert_conf=0.9, orig_text="abc", pert_text="abc") for _ in range(5)]
        diff = [_pr(pert_conf=0.9, orig_text="abc", pert_text="xyz different answer here") for _ in range(5)]
        ece = expected_calibration_error(same + diff)
        # Avg accuracy 0.5 vs conf 0.9 -> gap ~0.4
        assert ece > 0.3


# ---------------------------------------------------------------------------
# Mutual Information Score
# ---------------------------------------------------------------------------

class TestMutualInformationScore:
    def test_empty_returns_none(self):
        assert mutual_information_score([]) is None

    def test_no_logprobs_returns_none(self):
        results = [_pr() for _ in range(5)]
        assert mutual_information_score(results) is None

    def test_identical_distributions_low_jsd(self):
        # Identical logprob distributions -> JSD near 0
        lp = [[("a", math.log(0.9)), ("b", math.log(0.1))]]
        results = [_pr(orig_logprobs=lp, pert_logprobs=lp) for _ in range(3)]
        score = mutual_information_score(results)
        assert score is not None
        assert score == pytest.approx(0.0, abs=1e-6)

    def test_different_distributions_positive_jsd(self):
        lp_orig = [[("a", math.log(0.99)), ("b", math.log(0.01))]]
        lp_pert = [[("a", math.log(0.01)), ("b", math.log(0.99))]]
        results = [_pr(orig_logprobs=lp_orig, pert_logprobs=lp_pert) for _ in range(3)]
        score = mutual_information_score(results)
        assert score is not None
        assert score > 0.1

    def test_non_negative(self):
        lp1 = [[("x", math.log(0.6)), ("y", math.log(0.4))]]
        lp2 = [[("x", math.log(0.3)), ("y", math.log(0.7))]]
        results = [_pr(orig_logprobs=lp1, pert_logprobs=lp2)]
        score = mutual_information_score(results)
        assert score is not None
        assert score >= 0.0

    def test_partial_logprobs_skipped(self):
        # Mix of results with and without logprobs
        lp = [[("a", math.log(0.9))]]
        with_lp = _pr(orig_logprobs=lp, pert_logprobs=lp)
        without_lp = _pr()
        score = mutual_information_score([with_lp, without_lp])
        assert score is not None  # Should use the one valid pair


# ---------------------------------------------------------------------------
# Confidence Surface Curvature
# ---------------------------------------------------------------------------

class TestConfidenceSurfaceCurvature:
    def test_empty_returns_zero(self):
        assert confidence_surface_curvature([]) == 0.0

    def test_fewer_than_three_returns_zero(self):
        results = [_pr(ptype="omit") for _ in range(2)]
        assert confidence_surface_curvature(results) == 0.0

    def test_linear_sequence_low_curvature(self):
        # Linear: 0.5, 0.6, 0.7, 0.8 -> second diffs all 0
        confs = [0.5, 0.6, 0.7, 0.8]
        results = [_pr(pert_conf=c, ptype="omit") for c in confs]
        curv = confidence_surface_curvature(results)
        assert curv == pytest.approx(0.0, abs=1e-10)

    def test_oscillating_high_curvature(self):
        # Sharp oscillation: 0.9, 0.1, 0.9, 0.1
        confs = [0.9, 0.1, 0.9, 0.1]
        results = [_pr(pert_conf=c, ptype="omit") for c in confs]
        curv = confidence_surface_curvature(results)
        assert curv > 0.5

    def test_non_omit_ignored(self):
        # Non-omit results should be ignored
        omit_results = [_pr(pert_conf=0.5, ptype="omit") for _ in range(3)]
        synonym_results = [_pr(pert_conf=0.99, ptype="synonym") for _ in range(5)]
        curv_mixed = confidence_surface_curvature(omit_results + synonym_results)
        curv_omit_only = confidence_surface_curvature(omit_results)
        assert curv_mixed == curv_omit_only

    def test_non_negative(self):
        results = [_pr(pert_conf=c, ptype="omit") for c in [0.3, 0.7, 0.4, 0.8, 0.2]]
        assert confidence_surface_curvature(results) >= 0.0


# ---------------------------------------------------------------------------
# Overconfidence Score
# ---------------------------------------------------------------------------

class TestOverconfidenceScore:
    def test_empty_returns_zero(self):
        assert overconfidence_score([]) == 0.0

    def test_verbalized_vs_sampling_gap(self):
        # verbalized=0.9, sampling=0.4 -> gap 0.5
        results = [
            _pr(orig_conf=0.9, pert_conf=0.4, orig_method="verbalized", pert_method="sampling")
            for _ in range(4)
        ]
        score = overconfidence_score(results)
        assert score == pytest.approx(0.5)

    def test_no_overconfidence(self):
        # verbalized=0.4, sampling=0.9 -> gap negative, not counted
        results = [
            _pr(orig_conf=0.4, pert_conf=0.9, orig_method="verbalized", pert_method="sampling")
        ]
        score = overconfidence_score(results)
        assert score == 0.0

    def test_fallback_confidence_minus_accuracy(self):
        # No verbalized results -> falls back to conf - accuracy
        # conf=0.9, answer_unchanged -> outcome=1 -> gap negative -> 0
        results = [_pr(pert_conf=0.9, orig_text="ans", pert_text="ans")]
        score = overconfidence_score(results)
        assert score == 0.0

    def test_fallback_overconfidence(self):
        # conf=0.9, answer changed -> outcome=0 -> gap 0.9
        results = [
            _pr(pert_conf=0.9, orig_text="yes positive answer here", pert_text="no negative completely different")
        ]
        score = overconfidence_score(results)
        assert score > 0.0

    def test_non_negative(self):
        results = [_pr(pert_conf=c) for c in [0.2, 0.5, 0.8, 1.0]]
        assert overconfidence_score(results) >= 0.0


# ---------------------------------------------------------------------------
# Brier Score
# ---------------------------------------------------------------------------

class TestBrierScore:
    def test_empty_returns_zero(self):
        assert brier_score([]) == 0.0

    def test_perfect_prediction_unchanged(self):
        # conf=1.0, answer_unchanged -> (1-1)^2 = 0
        results = [_pr(pert_conf=1.0, orig_text="abc", pert_text="abc") for _ in range(5)]
        assert brier_score(results) == pytest.approx(0.0)

    def test_perfect_prediction_changed(self):
        # conf=0.0, answer_changed -> (0-0)^2 = 0
        results = [
            _pr(pert_conf=0.0, orig_text="yes", pert_text="no completely different answer here")
            for _ in range(5)
        ]
        assert brier_score(results) == pytest.approx(0.0)

    def test_worst_case(self):
        # conf=1.0, answer_changed -> (1-0)^2 = 1.0 per sample
        results = [
            _pr(pert_conf=1.0, orig_text="yes", pert_text="no completely different answer here")
            for _ in range(5)
        ]
        assert brier_score(results) == pytest.approx(1.0)

    def test_bounded_zero_one(self):
        results = [_pr(pert_conf=c) for c in [0.1, 0.3, 0.5, 0.7, 0.9]]
        bs = brier_score(results)
        assert 0.0 <= bs <= 1.0

    def test_mathematical_correctness(self):
        # Manual: conf=0.7, same answer -> (0.7-1)^2 = 0.09
        results = [_pr(pert_conf=0.7, orig_text="ans", pert_text="ans")]
        assert brier_score(results) == pytest.approx(0.09)

    def test_average_over_results(self):
        # Two results: 0.09 + 0.25 / 2 = 0.17
        r1 = _pr(pert_conf=0.7, orig_text="ans", pert_text="ans")   # (0.7-1)^2 = 0.09
        r2 = _pr(pert_conf=0.5, orig_text="ans", pert_text="ans")   # (0.5-1)^2 = 0.25
        assert brier_score([r1, r2]) == pytest.approx(0.17)


# ---------------------------------------------------------------------------
# compute_calibration (aggregate)
# ---------------------------------------------------------------------------

class TestComputeCalibration:
    def test_returns_calibration_report(self):
        scan = _scan([_pr() for _ in range(5)])
        report = compute_calibration(scan)
        assert isinstance(report, CalibrationReport)

    def test_empty_scan(self):
        scan = _scan([])
        report = compute_calibration(scan)
        assert report.ece == 0.0
        assert report.mutual_information is None
        assert report.surface_curvature == 0.0
        assert report.overconfidence_score == 0.0
        assert report.brier_score == 0.0

    def test_all_metrics_bounded(self):
        results = [_pr(pert_conf=c, ptype="omit") for c in [0.2, 0.5, 0.8, 0.6, 0.4]]
        scan = _scan(results)
        report = compute_calibration(scan)
        assert 0.0 <= report.ece <= 1.0
        assert report.surface_curvature >= 0.0
        assert report.overconfidence_score >= 0.0
        assert 0.0 <= report.brier_score <= 1.0

    def test_with_logprobs(self):
        lp = [[("tok", math.log(0.8)), ("other", math.log(0.2))]]
        results = [_pr(orig_logprobs=lp, pert_logprobs=lp) for _ in range(3)]
        scan = _scan(results)
        report = compute_calibration(scan)
        assert report.mutual_information is not None
        assert report.mutual_information >= 0.0
