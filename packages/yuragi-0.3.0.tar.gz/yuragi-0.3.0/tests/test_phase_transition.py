"""Tests for phase transition detection in LLM confidence."""

from __future__ import annotations

import pytest

from yuragi.analysis.phase_transition import (
    PhaseMap,
    PhaseTransition,
    _build_parameterized_prompts,
    _compute_sharpness_at,
    _count_hedge_density,
    _count_phases,
    _detect_transitions,
    _is_monotone_decrease,
    _is_transition,
    _phase_label,
    _second_derivative,
    _transition_summary,
    phase_map_summary,
)

# ---------------------------------------------------------------------------
# _second_derivative
# ---------------------------------------------------------------------------


class TestSecondDerivative:
    def test_constant_sequence_zero_d2(self):
        d2 = _second_derivative([0.8, 0.8, 0.8, 0.8])
        for val in d2:
            assert val == pytest.approx(0.0, abs=1e-9)

    def test_linear_sequence_zero_d2(self):
        # For a linear sequence the second derivative is zero at all interior points
        vals = [1.0, 0.9, 0.8, 0.7, 0.6]
        d2 = _second_derivative(vals)
        # Interior points should be ~0
        for v in d2[1:-1]:
            assert v == pytest.approx(0.0, abs=1e-9)

    def test_sharp_drop_detected(self):
        # Sudden drop at index 2: [0.9, 0.85, 0.3, 0.28, 0.27]
        vals = [0.9, 0.85, 0.3, 0.28, 0.27]
        d2 = _second_derivative(vals)
        # The sharpest d2 should be around index 2
        max_idx = max(range(len(d2)), key=lambda i: abs(d2[i]))
        assert max_idx in {1, 2, 3}

    def test_length_preserved(self):
        vals = [0.5, 0.4, 0.3, 0.2, 0.1]
        assert len(_second_derivative(vals)) == len(vals)

    def test_two_points_returns_zeros(self):
        d2 = _second_derivative([0.8, 0.4])
        assert len(d2) == 2
        for v in d2:
            assert v == pytest.approx(0.0, abs=1e-9)

    def test_single_point(self):
        d2 = _second_derivative([0.7])
        assert d2 == [0.0]

    def test_empty(self):
        assert _second_derivative([]) == []


# ---------------------------------------------------------------------------
# _detect_transitions
# ---------------------------------------------------------------------------


def _make_steps(confidences: list[float]) -> list[tuple[int, str, float]]:
    return [(i, f"prompt_{i}", c) for i, c in enumerate(confidences)]


class TestDetectTransitions:
    def test_collapse_transition_detected(self):
        # Sharp drop between step 2 and 3
        confidences = [0.85, 0.83, 0.82, 0.30, 0.28, 0.27]
        steps = _make_steps(confidences)
        transitions = _detect_transitions(steps, sharpness_threshold=0.05)
        assert len(transitions) >= 1
        collapse = [t for t in transitions if t.transition_type == "collapse"]
        assert len(collapse) >= 1

    def test_surge_transition_detected(self):
        # Sharp rise between step 2 and 3
        confidences = [0.20, 0.22, 0.21, 0.85, 0.87, 0.86]
        steps = _make_steps(confidences)
        transitions = _detect_transitions(steps, sharpness_threshold=0.05)
        assert len(transitions) >= 1
        surge = [t for t in transitions if t.transition_type == "surge"]
        assert len(surge) >= 1

    def test_monotone_decrease_no_sharp_transition(self):
        # Gradual linear decrease — no phase transition
        confidences = [0.9, 0.82, 0.74, 0.66, 0.58, 0.50]
        steps = _make_steps(confidences)
        transitions = _detect_transitions(steps, sharpness_threshold=0.05)
        # All d2 interior values are zero for linear → no transition expected
        assert len(transitions) == 0

    def test_multiple_transitions(self):
        # Two sharp drops: one at index 2, another at index 5
        confidences = [0.90, 0.88, 0.40, 0.38, 0.37, 0.85, 0.84, 0.83]
        steps = _make_steps(confidences)
        transitions = _detect_transitions(steps, sharpness_threshold=0.05)
        assert len(transitions) >= 2

    def test_too_few_steps_returns_empty(self):
        assert _detect_transitions(_make_steps([0.8, 0.5])) == []
        assert _detect_transitions(_make_steps([0.8])) == []
        assert _detect_transitions([]) == []

    def test_transition_has_correct_type_collapse(self):
        confidences = [0.85, 0.84, 0.83, 0.20, 0.19, 0.18]
        steps = _make_steps(confidences)
        transitions = _detect_transitions(steps, sharpness_threshold=0.05)
        if transitions:
            for t in transitions:
                if t.pre_transition_confidence > t.post_transition_confidence:
                    assert t.transition_type == "collapse"

    def test_transition_sharpness_positive(self):
        confidences = [0.9, 0.88, 0.3, 0.28, 0.27]
        steps = _make_steps(confidences)
        transitions = _detect_transitions(steps, sharpness_threshold=0.0)
        for t in transitions:
            assert t.sharpness >= 0.0

    def test_trigger_set_for_parameterized_step(self):
        # When param_value == 1, trigger should be first doubt word
        # Insert a prior step at param=0 with high confidence
        steps_full = [(0, "question?", 0.85), (1, "maybe, question?", 0.30)]
        transitions = _detect_transitions(steps_full, sharpness_threshold=0.0)
        # trigger should map to _DOUBT_WORDS[0] = "maybe"
        if transitions:
            assert transitions[0].trigger == "maybe"


# ---------------------------------------------------------------------------
# _count_phases
# ---------------------------------------------------------------------------


class TestCountPhases:
    def test_constant_one_phase(self):
        assert _count_phases([0.8, 0.8, 0.8, 0.8]) == 1

    def test_two_clear_phases(self):
        # High then low — should detect 2 phases
        confidences = [0.9, 0.88, 0.87, 0.30, 0.28, 0.29]
        count = _count_phases(confidences, band=0.15)
        assert count >= 2

    def test_three_phases(self):
        # High → mid → low
        confidences = [0.9, 0.88, 0.5, 0.52, 0.2, 0.18, 0.19]
        count = _count_phases(confidences, band=0.15)
        assert count >= 2  # at least 2 distinct plateaus detected

    def test_empty_returns_zero(self):
        assert _count_phases([]) == 0

    def test_single_value_one_phase(self):
        assert _count_phases([0.7]) == 1


# ---------------------------------------------------------------------------
# _count_hedge_density
# ---------------------------------------------------------------------------


class TestCountHedgeDensity:
    def test_no_hedges_zero(self):
        assert _count_hedge_density("The capital of France is Paris.") == pytest.approx(0.0)

    def test_hedges_nonzero(self):
        text = "I think the answer might be Paris, but I'm not sure."
        density = _count_hedge_density(text)
        assert density > 0.0

    def test_many_hedges_capped_at_one(self):
        text = "i think i believe i'm not sure it's possible might be could be not certain unclear uncertain"
        density = _count_hedge_density(text)
        assert density <= 1.0

    def test_empty_text_zero(self):
        assert _count_hedge_density("") == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# _build_parameterized_prompts
# ---------------------------------------------------------------------------


class TestBuildParameterizedPrompts:
    def test_first_prompt_is_original(self):
        base = "What is 2+2?"
        prompts = _build_parameterized_prompts(base, max_param=3)
        assert prompts[0] == base

    def test_length_is_max_param_plus_one(self):
        prompts = _build_parameterized_prompts("Q?", max_param=5)
        assert len(prompts) == 6

    def test_subsequent_prompts_prepend_doubt_words(self):
        prompts = _build_parameterized_prompts("Q?", max_param=3)
        # param=1: "maybe, Q?"
        assert "maybe" in prompts[1]
        # param=2: "maybe perhaps, Q?"
        assert "perhaps" in prompts[2]

    def test_zero_max_param(self):
        prompts = _build_parameterized_prompts("Q?", max_param=0)
        assert prompts == ["Q?"]


# ---------------------------------------------------------------------------
# _is_monotone_decrease
# ---------------------------------------------------------------------------


class TestIsMonotoneDecrease:
    def test_strictly_decreasing(self):
        assert _is_monotone_decrease([0.9, 0.8, 0.7, 0.6]) is True

    def test_flat_is_monotone(self):
        assert _is_monotone_decrease([0.5, 0.5, 0.5]) is True

    def test_increase_not_monotone(self):
        assert _is_monotone_decrease([0.5, 0.6, 0.7]) is False

    def test_mixed_not_monotone(self):
        assert _is_monotone_decrease([0.8, 0.5, 0.9, 0.3]) is False

    def test_single_value(self):
        assert _is_monotone_decrease([0.7]) is True

    def test_empty(self):
        assert _is_monotone_decrease([]) is True


# ---------------------------------------------------------------------------
# PhaseTransition dataclass
# ---------------------------------------------------------------------------


class TestPhaseTransitionDataclass:
    def _make(self, **kwargs) -> PhaseTransition:
        defaults = dict(
            transition_prompt="maybe, What is 2+2?",
            pre_transition_confidence=0.80,
            post_transition_confidence=0.30,
            sharpness=0.42,
            transition_type="collapse",
            trigger="maybe",
        )
        defaults.update(kwargs)
        return PhaseTransition(**defaults)

    def test_transition_type_collapse(self):
        pt = self._make(transition_type="collapse")
        assert pt.transition_type == "collapse"

    def test_transition_type_surge(self):
        pt = self._make(
            pre_transition_confidence=0.3,
            post_transition_confidence=0.8,
            transition_type="surge",
        )
        assert pt.transition_type == "surge"

    def test_sharpness_non_negative(self):
        pt = self._make(sharpness=0.1)
        assert pt.sharpness >= 0.0

    def test_trigger_stored(self):
        pt = self._make(trigger="perhaps")
        assert pt.trigger == "perhaps"


# ---------------------------------------------------------------------------
# PhaseMap dataclass
# ---------------------------------------------------------------------------


class TestPhaseMapDataclass:
    def _make(self, transitions=None, num_phases=2) -> PhaseMap:
        if transitions is None:
            transitions = []
        return PhaseMap(
            transitions=transitions,
            num_phases=num_phases,
            critical_point=None,
            order_parameter="confidence",
        )

    def test_empty_transitions(self):
        pm = self._make(transitions=[])
        assert pm.transitions == []

    def test_num_phases_stored(self):
        pm = self._make(num_phases=3)
        assert pm.num_phases == 3

    def test_order_parameter_default(self):
        pm = self._make()
        assert pm.order_parameter == "confidence"

    def test_critical_point_none_allowed(self):
        pm = self._make()
        assert pm.critical_point is None

    def test_steps_default_empty(self):
        pm = self._make()
        assert pm.steps == []


# ---------------------------------------------------------------------------
# _phase_label
# ---------------------------------------------------------------------------


class TestPhaseLabel:
    def test_high_confidence(self):
        assert _phase_label(0.85) == "high-confidence"

    def test_intermediate(self):
        assert _phase_label(0.55) == "intermediate"

    def test_low_confidence(self):
        assert _phase_label(0.25) == "low-confidence"

    def test_boundary_07(self):
        assert _phase_label(0.70) == "high-confidence"

    def test_boundary_04(self):
        assert _phase_label(0.40) == "intermediate"


# ---------------------------------------------------------------------------
# _compute_sharpness_at and _is_transition
# ---------------------------------------------------------------------------


class TestSharpnessHelpers:
    def test_sharpness_at_collapse_peak(self):
        confs = [0.9, 0.88, 0.3, 0.28, 0.27]
        # Index 2 (or 1) should have high sharpness
        sharpness = _compute_sharpness_at(confs, 2)
        assert sharpness > 0.1

    def test_sharpness_at_flat_region(self):
        confs = [0.5, 0.5, 0.5, 0.5, 0.5]
        assert _compute_sharpness_at(confs, 2) == pytest.approx(0.0, abs=1e-9)

    def test_is_transition_true_at_drop(self):
        confs = [0.9, 0.88, 0.3, 0.28, 0.27]
        # index 2 has drop from 0.88 → 0.3
        assert _is_transition(confs, 2, threshold=0.05) is True

    def test_is_transition_false_for_flat(self):
        confs = [0.5, 0.5, 0.5, 0.5]
        assert _is_transition(confs, 2, threshold=0.05) is False

    def test_is_transition_false_at_index_zero(self):
        confs = [0.9, 0.3, 0.28]
        assert _is_transition(confs, 0) is False

    def test_sharpness_out_of_bounds(self):
        confs = [0.8, 0.5]
        assert _compute_sharpness_at(confs, 99) == 0.0


# ---------------------------------------------------------------------------
# _transition_summary
# ---------------------------------------------------------------------------


class TestTransitionSummary:
    def test_collapse_summary_contains_down_arrow(self):
        pt = PhaseTransition(
            transition_prompt="maybe, Q?",
            pre_transition_confidence=0.8,
            post_transition_confidence=0.3,
            sharpness=0.4,
            transition_type="collapse",
            trigger="maybe",
        )
        summary = _transition_summary(pt)
        assert "\u2193" in summary  # ↓

    def test_surge_summary_contains_up_arrow(self):
        pt = PhaseTransition(
            transition_prompt="Q?",
            pre_transition_confidence=0.3,
            post_transition_confidence=0.8,
            sharpness=0.4,
            transition_type="surge",
            trigger="",
        )
        summary = _transition_summary(pt)
        assert "\u2191" in summary  # ↑

    def test_trigger_shown_in_summary(self):
        pt = PhaseTransition(
            transition_prompt="maybe, Q?",
            pre_transition_confidence=0.8,
            post_transition_confidence=0.3,
            sharpness=0.4,
            transition_type="collapse",
            trigger="maybe",
        )
        assert "maybe" in _transition_summary(pt)


# ---------------------------------------------------------------------------
# phase_map_summary (integration)
# ---------------------------------------------------------------------------


class TestPhaseMapSummary:
    def _make_phase_map_no_transition(self) -> PhaseMap:
        # Monotone decrease — no transition
        steps = [(i, f"p{i}", 0.9 - i * 0.1) for i in range(6)]
        return PhaseMap(
            transitions=[],
            num_phases=1,
            critical_point=None,
            order_parameter="confidence",
            steps=steps,
        )

    def _make_phase_map_with_transition(self) -> PhaseMap:
        steps = [
            (0, "Q?", 0.85),
            (1, "maybe, Q?", 0.83),
            (2, "maybe perhaps, Q?", 0.30),
            (3, "maybe perhaps supposedly, Q?", 0.28),
        ]
        pt = PhaseTransition(
            transition_prompt="maybe perhaps, Q?",
            pre_transition_confidence=0.83,
            post_transition_confidence=0.30,
            sharpness=0.45,
            transition_type="collapse",
            trigger="supposedly",
        )
        return PhaseMap(
            transitions=[pt],
            num_phases=2,
            critical_point="maybe perhaps, Q?",
            order_parameter="confidence",
            steps=steps,
        )

    def test_summary_no_transition_mentions_monotone(self):
        pm = self._make_phase_map_no_transition()
        summary = phase_map_summary(pm)
        assert "Transitions" in summary
        assert "0" in summary  # 0 transitions

    def test_summary_with_transition_mentions_collapse(self):
        pm = self._make_phase_map_with_transition()
        summary = phase_map_summary(pm)
        assert "collapse" in summary.lower() or "\u2193" in summary

    def test_summary_includes_phase_count(self):
        pm = self._make_phase_map_with_transition()
        summary = phase_map_summary(pm)
        assert "2" in summary  # num_phases

    def test_summary_includes_order_parameter(self):
        pm = self._make_phase_map_no_transition()
        summary = phase_map_summary(pm)
        assert "confidence" in summary

    def test_summary_shows_total_drop(self):
        pm = self._make_phase_map_no_transition()
        summary = phase_map_summary(pm)
        assert "Total confidence drop" in summary
