"""Integration tests against real ollama/llama3.2. Skipped by default.

Run with:
    pytest -m integration -v

Requires:
    - ollama running locally
    - llama3.2 model pulled
"""
import pytest

from yuragi import Scanner


@pytest.mark.integration
class TestOllamaIntegration:

    def test_scan_returns_valid_v030_structure(self) -> None:
        scanner = Scanner(model="ollama/llama3.2", num_samples=2, num_variants=2)
        result = scanner.scan("What is the capital of France?")
        # v0.3.0 invariants
        assert 0.0 <= result.fragility_score <= 1.0
        assert result.fragility_max >= result.fragility_score - 1e-10
        assert 0.0 <= result.fragility_exceed <= 1.0
        assert result.baseline.confidence_method in {"logprob", "sampling", "verbalized"}

    def test_ci_none_when_few_perturbations(self) -> None:
        scanner = Scanner(model="ollama/llama3.2", num_samples=2, num_variants=1)
        result = scanner.scan("What year did WWII end?")
        if len(result.perturbation_results) < 5:
            assert result.fragility_ci_95() is None

    def test_ci_bracketing_when_many_perturbations(self) -> None:
        scanner = Scanner(model="ollama/llama3.2", num_samples=2, num_variants=5)
        result = scanner.scan("Explain quantum computing.")
        if len(result.perturbation_results) >= 5:
            ci = result.fragility_ci_95()
            assert ci is not None
            lower, upper = ci
            assert lower <= result.fragility_score + 1e-6
            assert result.fragility_score <= upper + 1e-6
