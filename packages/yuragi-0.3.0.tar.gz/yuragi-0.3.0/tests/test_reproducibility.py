"""Tests for reproducible random state injection (Phase 1a: A1).

Verifies that:
- Same seed → same perturbation variants
- Different seeds → different variants (probabilistic, not guaranteed)
- Bootstrap CI: same seed → same CI bounds
- make_rng helper behaves correctly
"""

from __future__ import annotations

import random

from yuragi.config import YuragiConfig
from yuragi.perturbations.code_switching import generate_code_switching
from yuragi.perturbations.counterfactual import generate_counterfactual
from yuragi.perturbations.negation import generate_negation
from yuragi.perturbations.reorder import generate_reorder
from yuragi.perturbations.synonym import generate_synonym
from yuragi.perturbations.typo import generate_typo
from yuragi.utils import make_rng

# ---------------------------------------------------------------------------
# make_rng helper
# ---------------------------------------------------------------------------


def test_make_rng_seeded_is_deterministic() -> None:
    """Same seed → same sequence."""
    rng1 = make_rng(42)
    rng2 = make_rng(42)
    assert [rng1.random() for _ in range(10)] == [rng2.random() for _ in range(10)]


def test_make_rng_none_is_nondeterministic() -> None:
    """None seed → unseeded (not necessarily different, but different instances)."""
    rng1 = make_rng(None)
    rng2 = make_rng(None)
    # Cannot guarantee different, but both must be usable Random instances
    assert isinstance(rng1, random.Random)
    assert isinstance(rng2, random.Random)


# ---------------------------------------------------------------------------
# typo generator reproducibility
# ---------------------------------------------------------------------------

_TYPO_TEXT = "What is the capital of France, the country in Western Europe?"


def test_typo_same_seed_same_variants() -> None:
    rng1 = make_rng(7)
    rng2 = make_rng(7)
    v1 = generate_typo(_TYPO_TEXT, num_variants=3, rng=rng1)
    v2 = generate_typo(_TYPO_TEXT, num_variants=3, rng=rng2)
    assert v1 == v2


def test_typo_different_seeds_different_variants() -> None:
    """Different seeds should produce different results (highly likely for real text)."""
    variants_per_seed: list[list[str]] = []
    for seed in range(20):
        rng = make_rng(seed)
        variants_per_seed.append(generate_typo(_TYPO_TEXT, num_variants=3, rng=rng))

    # At least some seeds must produce different results
    unique = {tuple(v) for v in variants_per_seed}
    assert len(unique) > 1, "Expected different variants from different seeds"


def test_typo_none_rng_uses_global_random() -> None:
    """rng=None must not raise — falls back to global random."""
    result = generate_typo(_TYPO_TEXT, num_variants=2)
    assert isinstance(result, list)


# ---------------------------------------------------------------------------
# synonym generator reproducibility
# ---------------------------------------------------------------------------

_SYNONYM_TEXT = "Is quantum computing important for future research?"


def test_synonym_same_seed_same_variants() -> None:
    rng1 = make_rng(99)
    rng2 = make_rng(99)
    v1 = generate_synonym(_SYNONYM_TEXT, num_variants=3, rng=rng1)
    v2 = generate_synonym(_SYNONYM_TEXT, num_variants=3, rng=rng2)
    assert v1 == v2


def test_synonym_different_seeds_different_variants() -> None:
    variants_per_seed: list[list[str]] = []
    for seed in range(20):
        rng = make_rng(seed)
        variants_per_seed.append(generate_synonym(_SYNONYM_TEXT, num_variants=3, rng=rng))

    # synonym map may have limited options; just check no errors and returns list
    assert all(isinstance(v, list) for v in variants_per_seed)


# ---------------------------------------------------------------------------
# reorder generator reproducibility
# ---------------------------------------------------------------------------

_REORDER_TEXT = "What is the capital of France the country in Western Europe today"


def test_reorder_same_seed_same_variants() -> None:
    rng1 = make_rng(123)
    rng2 = make_rng(123)
    v1 = generate_reorder(_REORDER_TEXT, num_variants=3, rng=rng1)
    v2 = generate_reorder(_REORDER_TEXT, num_variants=3, rng=rng2)
    assert v1 == v2


def test_reorder_different_seeds_different_variants() -> None:
    variants_per_seed: list[list[str]] = []
    for seed in range(20):
        rng = make_rng(seed)
        variants_per_seed.append(generate_reorder(_REORDER_TEXT, num_variants=3, rng=rng))

    unique = {tuple(v) for v in variants_per_seed}
    assert len(unique) > 1, "Expected different variants from different seeds"


# ---------------------------------------------------------------------------
# bootstrap CI reproducibility
# ---------------------------------------------------------------------------


def test_bootstrap_ci_same_seed_same_result() -> None:
    # _bootstrap_ci was unified with metrics.statistical_tests.bootstrap_ci (Phase A, A-2)
    from yuragi.metrics.statistical_tests import bootstrap_ci

    data = [0.8, 0.7, 0.6, 0.85, 0.75, 0.65, 0.9, 0.5]
    r1 = bootstrap_ci(data, n_iterations=500, seed=42)
    r2 = bootstrap_ci(data, n_iterations=500, seed=42)
    assert r1.lower == r2.lower
    assert r1.upper == r2.upper


def test_bootstrap_ci_different_seeds_different_result() -> None:
    # _bootstrap_ci was unified with metrics.statistical_tests.bootstrap_ci (Phase A, A-2)
    from yuragi.metrics.statistical_tests import bootstrap_ci

    data = [0.8, 0.7, 0.6, 0.85, 0.75, 0.65, 0.9, 0.5]
    results: set[tuple[float, float]] = set()
    for seed in range(30):
        r = bootstrap_ci(data, n_iterations=200, seed=seed)
        results.add((r.lower, r.upper))

    assert len(results) > 1, "Expected different CI bounds from different seeds"


# ---------------------------------------------------------------------------
# YuragiConfig.seed field
# ---------------------------------------------------------------------------


def test_config_seed_field_default_is_none() -> None:
    cfg = YuragiConfig()
    assert cfg.seed is None


def test_config_seed_field_set() -> None:
    cfg = YuragiConfig(seed=42)
    assert cfg.seed == 42


# ---------------------------------------------------------------------------
# v0.2.0 new generators — determinism under seed (tracer audit follow-up)
# ---------------------------------------------------------------------------

_NEGATION_TEXT = "The sky is blue and the ocean is deep. Is this always true?"
_COUNTERFACTUAL_TEXT = "What is the boiling point of water at sea level?"
_CODE_SWITCHING_TEXT = "What is the capital of Japan and why is this city the capital?"


def test_negation_same_seed_same_variants() -> None:
    rng1 = make_rng(314)
    rng2 = make_rng(314)
    v1 = generate_negation(_NEGATION_TEXT, num_variants=3, rng=rng1)
    v2 = generate_negation(_NEGATION_TEXT, num_variants=3, rng=rng2)
    assert v1 == v2


def test_negation_different_seeds_different_variants() -> None:
    variants_per_seed: list[tuple[str, ...]] = []
    for seed in range(20):
        rng = make_rng(seed)
        variants_per_seed.append(
            tuple(generate_negation(_NEGATION_TEXT, num_variants=3, rng=rng))
        )
    assert len({tuple(v) for v in variants_per_seed}) > 1


def test_counterfactual_same_seed_same_variants() -> None:
    rng1 = make_rng(271)
    rng2 = make_rng(271)
    v1 = generate_counterfactual(_COUNTERFACTUAL_TEXT, num_variants=4, rng=rng1)
    v2 = generate_counterfactual(_COUNTERFACTUAL_TEXT, num_variants=4, rng=rng2)
    assert v1 == v2


def test_counterfactual_different_seeds_different_variants() -> None:
    variants_per_seed: list[tuple[str, ...]] = []
    for seed in range(20):
        rng = make_rng(seed)
        variants_per_seed.append(
            tuple(generate_counterfactual(_COUNTERFACTUAL_TEXT, num_variants=4, rng=rng))
        )
    assert len({tuple(v) for v in variants_per_seed}) > 1


def test_code_switching_same_seed_same_variants() -> None:
    rng1 = make_rng(1618)
    rng2 = make_rng(1618)
    v1 = generate_code_switching(_CODE_SWITCHING_TEXT, num_variants=3, rng=rng1)
    v2 = generate_code_switching(_CODE_SWITCHING_TEXT, num_variants=3, rng=rng2)
    assert v1 == v2


def test_code_switching_different_seeds_different_variants() -> None:
    variants_per_seed: list[tuple[str, ...]] = []
    for seed in range(30):
        rng = make_rng(seed)
        variants_per_seed.append(
            tuple(generate_code_switching(_CODE_SWITCHING_TEXT, num_variants=3, rng=rng))
        )
    # code-switching randomly picks how many words to switch — 30 seeds
    # should produce at least 2 distinct variant tuples on a prompt with
    # several matchable words.
    assert len({tuple(v) for v in variants_per_seed}) > 1


# ---------------------------------------------------------------------------
# End-to-end scanner reproducibility (tracer audit follow-up)
# ---------------------------------------------------------------------------


def test_scanner_same_seed_same_perturbation_variants() -> None:
    """With a mocked adapter, ``Scanner.scan()`` must emit the identical
    sequence of ``perturbed_prompt`` values on two runs with the same
    ``YuragiConfig.seed``. Confidences are fixed by the mock so we isolate
    the determinism of the perturbation layer.
    """
    from unittest.mock import MagicMock

    from yuragi.core import Scanner
    from yuragi.providers.adapter import CompletionResult

    def _mock_adapter() -> MagicMock:
        adapter = MagicMock()
        adapter.capabilities.supports_logprobs = False
        adapter.num_samples = 1

        def fake_complete(prompt, system=None, **_kwargs):  # noqa: ARG001
            return CompletionResult(
                text="stub answer",
                confidence=0.5,
                confidence_method="sampling",
                token_count=1,
            )

        adapter.complete.side_effect = fake_complete
        return adapter

    cfg = YuragiConfig(seed=2027)
    # Two independent Scanners with identical seed / adapter / prompt
    s1 = Scanner(model="mock", config=cfg, num_variants=2, parallel=1)
    s2 = Scanner(model="mock", config=cfg, num_variants=2, parallel=1)
    s1.adapter = _mock_adapter()
    s2.adapter = _mock_adapter()

    r1 = s1.scan("What is the capital of France?")
    r2 = s2.scan("What is the capital of France?")

    prompts1 = [r.perturbed_prompt for r in r1.perturbation_results]
    prompts2 = [r.perturbed_prompt for r in r2.perturbation_results]
    assert prompts1 == prompts2
    types1 = [r.perturbation_type for r in r1.perturbation_results]
    types2 = [r.perturbation_type for r in r2.perturbation_results]
    assert types1 == types2
