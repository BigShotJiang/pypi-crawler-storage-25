"""Tests for core scanner and result types."""


import pytest

from yuragi.core import ScanResult


class TestPerturbationResult:
    def test_confidence_delta(self, make_perturbation):
        r = make_perturbation(orig_conf=0.8, pert_conf=0.5)
        assert r.confidence_delta == pytest.approx(-0.3)

    def test_answer_changed_same(self, make_perturbation):
        r = make_perturbation(orig_text="the answer is 42", pert_text="the answer is 42")
        assert not r.answer_changed

    def test_answer_changed_different(self, make_perturbation):
        r = make_perturbation(orig_text="yes definitely", pert_text="no absolutely not")
        assert r.answer_changed

    def test_is_dissociated(self, make_perturbation):
        r = make_perturbation(
            orig_text="same answer here",
            pert_text="same answer here",
            orig_conf=0.9,
            pert_conf=0.5,
        )
        assert r.is_dissociated

    def test_not_dissociated_small_delta(self, make_perturbation):
        # v0.3.0: no noise floor in dissociation_severity; any non-zero delta → is_dissociated=True
        r = make_perturbation(
            orig_text="same answer",
            pert_text="same answer",
            orig_conf=0.8,
            pert_conf=0.75,
        )
        # severity = sim * |delta| = ~1.0 * 0.05 = 0.05 > 0.0 → is_dissociated is True
        assert r.is_dissociated


class TestScanResult:
    def test_fragility_score_stable(self, make_scan_result):
        result = make_scan_result(deltas=[0.0, 0.01, -0.01, 0.02])
        assert result.fragility_score < 0.1

    def test_fragility_score_fragile(self, make_scan_result):
        # v0.3.0: fragility = mean(|ΔC|). deltas=[-0.4, 0.3, -0.3, 0.2] → mean = 0.3
        result = make_scan_result(deltas=[-0.4, 0.3, -0.3, 0.2])
        assert result.fragility_score > 0.2

    def test_confidence_range(self, make_scan_result):
        result = make_scan_result(baseline_conf=0.8, deltas=[-0.3, 0.1])
        assert result.confidence_range == pytest.approx(0.4)

    def test_dissociation_rate(self, make_scan_result):
        result = make_scan_result(deltas=[-0.3, -0.2, 0.0, 0.05])
        # All perturbations have same answer text, deltas > 0.1 are dissociated
        assert result.dissociation_rate > 0

    def test_fragility_label_steel(self, make_scan_result):
        result = make_scan_result(deltas=[0.0, 0.01])
        assert result.fragility_label() == "Steel"

    def test_fragility_label_glass(self, make_scan_result):
        # v0.3.0: fragility = mean|ΔC|. Need score > 0.55 for Glass/Shattered.
        # Use larger deltas: [-0.7, 0.6, -0.65] → mean = 0.65 > 0.55
        result = make_scan_result(deltas=[-0.7, 0.6, -0.65])
        label = result.fragility_label()
        assert label in ("Glass", "Shattered")

    def test_weakest_perturbation(self, make_scan_result):
        result = make_scan_result(deltas=[-0.1, -0.5, -0.2])
        assert result.weakest_perturbation is not None
        assert result.weakest_perturbation.confidence_delta == pytest.approx(-0.5)

    def test_empty_results(self, make_completion):
        result = ScanResult(
            prompt="test",
            model="test",
            baseline=make_completion(confidence=0.5),
        )
        assert result.fragility_score == 0.0
        assert result.confidence_range == 0.0
        assert result.dissociation_rate == 0.0
        assert result.weakest_perturbation is None


class TestModelCapabilities:
    def test_detect_openai(self):
        from yuragi.providers.adapter import detect_capabilities

        caps = detect_capabilities("gpt-4o")
        assert caps.supports_logprobs
        assert caps.provider == "openai"

    def test_detect_claude(self):
        from yuragi.providers.adapter import detect_capabilities

        caps = detect_capabilities("claude-sonnet-4-6")
        assert not caps.supports_logprobs
        assert caps.provider == "anthropic"

    def test_detect_ollama(self):
        from yuragi.providers.adapter import detect_capabilities

        caps = detect_capabilities("ollama/llama3")
        assert not caps.supports_logprobs  # litellm blocks logprobs for ollama
        assert caps.provider == "local"

    def test_detect_unknown(self):
        from yuragi.providers.adapter import detect_capabilities

        caps = detect_capabilities("some-random-model")
        assert not caps.supports_logprobs
