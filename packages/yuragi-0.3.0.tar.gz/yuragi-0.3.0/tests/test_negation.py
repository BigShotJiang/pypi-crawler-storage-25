"""Tests for negation perturbation."""

from __future__ import annotations

from yuragi.perturbations.negation import generate_negation


class TestGenerateNegation:
    def test_returns_list(self):
        result = generate_negation("The sky is blue.")
        assert isinstance(result, list)

    def test_num_variants_respected(self):
        result = generate_negation("The sky is blue.", num_variants=2)
        assert len(result) <= 2

    def test_default_num_variants(self):
        result = generate_negation("The sky is blue.")
        assert len(result) <= 3

    def test_is_negation_applied(self):
        result = generate_negation("The sky is blue.")
        combined = " ".join(result)
        # At least one negation marker should appear
        negation_markers = ["not", "never", "no longer", "cannot"]
        assert any(marker in combined.lower() for marker in negation_markers)

    def test_auxiliary_verb_negated(self):
        # "is" should become "is not" in at least one variant
        result = generate_negation("Water is wet.")
        combined = " ".join(result)
        assert "is not" in combined or "never" in combined.lower() or "no longer" in combined.lower()

    def test_can_negation(self):
        result = generate_negation("Birds can fly.")
        combined = " ".join(result)
        assert "cannot" in combined or "never" in combined.lower() or "no longer" in combined.lower()

    def test_original_content_preserved(self):
        text = "What is the capital of France?"
        result = generate_negation(text)
        # The original question content should still be present in each variant
        for variant in result:
            assert "France" in variant or "capital" in variant or "what" in variant.lower()

    def test_empty_string(self):
        result = generate_negation("")
        assert isinstance(result, list)

    def test_no_aux_verb_falls_back(self):
        # No auxiliary verb: should still produce variants (prefix/suffix strategies)
        result = generate_negation("Quantum entanglement Einstein relativity.")
        assert len(result) >= 1

    def test_deterministic_with_rng(self):
        import random
        rng1 = random.Random(42)
        rng2 = random.Random(42)
        r1 = generate_negation("The cat is on the mat.", rng=rng1)
        r2 = generate_negation("The cat is on the mat.", rng=rng2)
        assert r1 == r2
