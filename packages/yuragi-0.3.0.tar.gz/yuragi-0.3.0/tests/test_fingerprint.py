"""Tests for ModelFingerprint: similarity and vulnerability_by_type aggregation."""

from __future__ import annotations

import pytest

from yuragi.analysis.fingerprint import ModelFingerprint


def _make_fp(**kwargs) -> ModelFingerprint:
    defaults = dict(
        model="test-model",
        fragility_score=0.4,
        dissociation_rate=0.3,
        confidence_range=0.25,
        catastrophic_collapse_index=0.5,
        recovery_elasticity=0.6,
        non_linearity_score=0.3,
        vulnerability_by_type={"omit": 0.2, "typo": 0.15, "tone": 0.1},
        conformity_score=0.1,
        impostor_susceptibility=0.2,
        authority_boost=0.05,
    )
    defaults.update(kwargs)
    return ModelFingerprint(**defaults)


class TestSimilarity:
    def test_identical_fingerprint_similarity_is_one(self):
        fp = _make_fp()
        assert fp.similarity(fp) == pytest.approx(1.0, abs=1e-9)

    def test_same_values_different_instance(self):
        fp1 = _make_fp()
        fp2 = _make_fp()
        assert fp1.similarity(fp2) == pytest.approx(1.0, abs=1e-9)

    def test_orthogonal_vectors_low_similarity(self):
        # One fingerprint with only fragility, other only authority_boost
        fp1 = _make_fp(
            fragility_score=1.0,
            dissociation_rate=0.0,
            confidence_range=0.0,
            catastrophic_collapse_index=0.0,
            recovery_elasticity=0.0,
            non_linearity_score=0.0,
            vulnerability_by_type={},
            conformity_score=0.0,
            impostor_susceptibility=0.0,
            authority_boost=0.0,
        )
        fp2 = _make_fp(
            fragility_score=0.0,
            dissociation_rate=0.0,
            confidence_range=0.0,
            catastrophic_collapse_index=0.0,
            recovery_elasticity=0.0,
            non_linearity_score=0.0,
            vulnerability_by_type={},
            conformity_score=0.0,
            impostor_susceptibility=0.0,
            authority_boost=1.0,
        )
        assert fp1.similarity(fp2) == pytest.approx(0.0, abs=1e-9)

    def test_similarity_is_symmetric(self):
        fp1 = _make_fp(fragility_score=0.3)
        fp2 = _make_fp(fragility_score=0.7)
        assert fp1.similarity(fp2) == pytest.approx(fp2.similarity(fp1), abs=1e-9)

    def test_similarity_bounded(self):
        fp1 = _make_fp(fragility_score=0.1, conformity_score=0.9)
        fp2 = _make_fp(fragility_score=0.9, conformity_score=0.1)
        sim = fp1.similarity(fp2)
        assert 0.0 <= sim <= 1.0

    def test_zero_vector_fingerprint(self):
        fp_zero = _make_fp(
            fragility_score=0.0,
            dissociation_rate=0.0,
            confidence_range=0.0,
            catastrophic_collapse_index=0.0,
            recovery_elasticity=0.0,
            non_linearity_score=0.0,
            vulnerability_by_type={},
            conformity_score=0.0,
            impostor_susceptibility=0.0,
            authority_boost=0.0,
        )
        fp_nonzero = _make_fp()
        # zero vector vs nonzero → 0.0
        assert fp_zero.similarity(fp_nonzero) == 0.0

    def test_two_zero_vectors(self):
        fp_zero1 = _make_fp(
            fragility_score=0.0,
            dissociation_rate=0.0,
            confidence_range=0.0,
            catastrophic_collapse_index=0.0,
            recovery_elasticity=0.0,
            non_linearity_score=0.0,
            vulnerability_by_type={},
            conformity_score=0.0,
            impostor_susceptibility=0.0,
            authority_boost=0.0,
        )
        fp_zero2 = _make_fp(
            model="other",
            fragility_score=0.0,
            dissociation_rate=0.0,
            confidence_range=0.0,
            catastrophic_collapse_index=0.0,
            recovery_elasticity=0.0,
            non_linearity_score=0.0,
            vulnerability_by_type={},
            conformity_score=0.0,
            impostor_susceptibility=0.0,
            authority_boost=0.0,
        )
        # both zero → 1.0 (identical zero fingerprints)
        assert fp_zero1.similarity(fp_zero2) == 1.0

    def test_mismatched_vulnerability_keys(self):
        fp1 = _make_fp(vulnerability_by_type={"omit": 0.5, "typo": 0.3})
        fp2 = _make_fp(vulnerability_by_type={"tone": 0.5, "paraphrase": 0.3})
        sim = fp1.similarity(fp2)
        # They share no vuln overlap on those keys — similarity drops
        assert 0.0 <= sim <= 1.0


class TestVulnerabilityByType:
    def test_to_dict_contains_vulnerability_by_type(self):
        fp = _make_fp()
        d = fp.to_dict()
        assert "vulnerability_by_type" in d
        assert d["vulnerability_by_type"] == {"omit": 0.2, "typo": 0.15, "tone": 0.1}

    def test_empty_vulnerability(self):
        fp = _make_fp(vulnerability_by_type={})
        assert fp.to_dict()["vulnerability_by_type"] == {}

    def test_to_dict_all_keys_present(self):
        fp = _make_fp()
        d = fp.to_dict()
        expected_keys = {
            "model",
            "fragility_score",
            "dissociation_rate",
            "confidence_range",
            "catastrophic_collapse_index",
            "recovery_elasticity",
            "non_linearity_score",
            "vulnerability_by_type",
            "conformity_score",
            "impostor_susceptibility",
            "authority_boost",
        }
        assert set(d.keys()) == expected_keys

    def test_vulnerability_aggregation_logic(self):
        """Verify manual aggregation matches expected averages."""

        from yuragi.analysis.fingerprint_builder import _aggregate_vulnerability
        from yuragi.core import PerturbationResult
        from yuragi.providers.adapter import CompletionResult

        def _cr(conf: float) -> CompletionResult:
            return CompletionResult(text="ans", confidence=conf, confidence_method="sampling")

        def _pr(ptype: str, orig_conf: float, pert_conf: float) -> PerturbationResult:
            return PerturbationResult(
                original_prompt="q",
                perturbed_prompt="q mod",
                perturbation_type=ptype,
                original_response=_cr(orig_conf),
                perturbed_response=_cr(pert_conf),
            )

        from yuragi.core import ScanResult

        baseline = _cr(0.8)
        result = ScanResult(
            prompt="q",
            model="test",
            baseline=baseline,
            perturbation_results=[
                _pr("omit", 0.8, 0.5),   # delta = -0.3, abs = 0.3
                _pr("omit", 0.8, 0.7),   # delta = -0.1, abs = 0.1
                _pr("typo", 0.8, 0.6),   # delta = -0.2, abs = 0.2
            ],
        )

        vuln = _aggregate_vulnerability([result])
        assert vuln["omit"] == pytest.approx(0.2, abs=1e-9)  # (0.3+0.1)/2
        assert vuln["typo"] == pytest.approx(0.2, abs=1e-9)
