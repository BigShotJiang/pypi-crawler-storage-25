"""Unit tests for yuragi.metrics.semantic_entropy."""
from __future__ import annotations

import math

import pytest

from yuragi.metrics.semantic_entropy import _cluster_by_meaning, semantic_entropy

# ---------------------------------------------------------------------------
# semantic_entropy
# ---------------------------------------------------------------------------

def test_empty_samples_returns_zero():
    assert semantic_entropy([]) == 0.0


def test_single_sample_returns_zero():
    result = semantic_entropy(["The capital of France is Paris."])
    assert result == 0.0


def test_identical_samples_low_entropy():
    # Three identical strings -> 1 cluster -> entropy = 0
    samples = ["Paris is the capital of France."] * 3
    result = semantic_entropy(samples, similarity_threshold=0.85)
    assert result == pytest.approx(0.0)


def test_identical_meaning_low_entropy():
    # Very similar strings (high Jaccard similarity)
    samples = [
        "The capital of France is Paris.",
        "The capital of France is Paris.",
        "The capital of France is Paris.",
    ]
    result = semantic_entropy(samples, similarity_threshold=0.5)
    assert result < 0.3


def test_completely_different_samples_high_entropy():
    # Four completely different strings -> 4 clusters -> max entropy
    samples = [
        "Paris is the capital of France.",
        "Quantum mechanics describes subatomic particles.",
        "The Amazon rainforest covers Brazil.",
        "Jazz originated in New Orleans.",
    ]
    result = semantic_entropy(samples, similarity_threshold=0.85)
    # Max entropy for 4 equi-probable clusters = ln(4) ≈ 1.386
    assert result > 1.0


def test_entropy_monotone_with_diversity():
    # 1 cluster < 2 clusters < 4 clusters
    all_same = ["The sky is blue."] * 4
    two_groups = ["The sky is blue.", "The sky is blue.", "Grass is green.", "Grass is green."]
    all_diff = [
        "The sky is blue.",
        "Grass is green.",
        "Water is wet.",
        "Fire is hot.",
    ]
    e_same = semantic_entropy(all_same, similarity_threshold=0.85)
    e_two = semantic_entropy(two_groups, similarity_threshold=0.3)
    e_diff = semantic_entropy(all_diff, similarity_threshold=0.85)
    assert e_same < e_two < e_diff


def test_jaccard_fallback_no_embedding_model():
    # When embedding_model=None (default), Jaccard fallback is used.
    samples = ["hello world", "hello world", "completely different text here"]
    result = semantic_entropy(samples, embedding_model=None)
    assert isinstance(result, float)
    assert result >= 0.0


def test_cluster_by_meaning_returns_list_of_lists():
    samples = ["a b c", "a b c", "x y z"]
    clusters = _cluster_by_meaning(samples, threshold=0.85, embedding_model=None)
    assert isinstance(clusters, list)
    assert all(isinstance(c, list) for c in clusters)
    total = sum(len(c) for c in clusters)
    assert total == len(samples)


def test_entropy_value_two_equal_clusters():
    # 2 samples in cluster A, 2 in cluster B -> entropy = ln(2) ≈ 0.693
    samples = [
        "The sky is blue above us.",
        "The sky is blue above us.",
        "completely different xyz text",
        "completely different xyz text",
    ]
    result = semantic_entropy(samples, similarity_threshold=0.85)
    assert result == pytest.approx(math.log(2), abs=0.05)
