# Test Fixtures for Bench Schema Validation

These JSON files are **not empirical measurements**. They are hand-crafted
fixtures used by `benchmarks/falsifiability_check.py --dry-run` and the
CI schema validation tests to verify that the yuragi/bench JSON schema
accepts structurally-valid inputs.

## Files

- `asch.json` — Fixture for the Asch conformity claim schema
- `dissociation.json` — Fixture for the Confidence Dissociation rate schema
- `factual_shattered.json` — Fixture for the factual fragility claim schema
- `falsifiability.json` — Fixture for the F1-F5 falsifiability protocol schema

All four files have `"model": "fixture"` and `"dry_run": true` in their
`_meta` block. They are **not reproductions** of any yuragi measurement and
**must not be cited** as evidence for any claim in `README.md` or
`docs/theory.md`. Real measurements are stored in `docs/bench_*.json`
(top-level, ollama/llama3.2 real runs) for v0.2.0 and will move to
`docs/bench/real/*.json` in v0.3.0 after the empirical validation round.
