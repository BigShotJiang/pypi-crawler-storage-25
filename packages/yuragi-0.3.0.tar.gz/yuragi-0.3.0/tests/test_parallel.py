"""Tests for parallel.py: concurrent completion with mocked adapter.acomplete."""

from __future__ import annotations

import asyncio
import sys
import threading
from types import ModuleType
from unittest.mock import AsyncMock, MagicMock

import pytest

from yuragi.providers.adapter import CompletionResult, ModelCapabilities


def _make_litellm_mock():
    """Return a MagicMock that stands in for the litellm module."""
    mock = MagicMock(spec=ModuleType)
    return mock


def _make_adapter(supports_logprobs=False):
    """Build a minimal LLMAdapter-like object without a real litellm install."""
    from yuragi.providers.adapter import LLMAdapter

    adapter = LLMAdapter.__new__(LLMAdapter)
    adapter.model = "gpt-4o-mini"
    adapter.api_key = None
    adapter.num_samples = 2
    adapter.temperature = 0.7
    adapter.max_tokens = 100
    adapter.timeout = 30.0
    adapter.use_cache = False
    adapter.parallel = 3
    adapter._cache = None
    adapter.capabilities = ModelCapabilities(
        supports_logprobs=supports_logprobs, provider="openai" if supports_logprobs else "unknown"
    )
    from yuragi.config import DEFAULT_CONFIG
    adapter.config = DEFAULT_CONFIG
    return adapter


def _make_result(text="answer"):
    return CompletionResult(text=text, confidence=0.8, confidence_method="sampling")


@pytest.fixture(autouse=True)
def _inject_litellm(monkeypatch):
    """Inject a fake litellm so parallel.py HAS_LITELLM=True."""
    mock_ll = _make_litellm_mock()
    monkeypatch.setitem(sys.modules, "litellm", mock_ll)
    import yuragi.parallel as par_mod

    monkeypatch.setattr(par_mod, "HAS_LITELLM", True)
    return mock_ll


@pytest.mark.integration
class TestParallelComplete:
    def test_returns_correct_count(self, _inject_litellm):
        adapter = _make_adapter()
        prompts = ["p1", "p2", "p3"]

        from yuragi.parallel import run_parallel_complete

        adapter.acomplete = AsyncMock(return_value=_make_result("result"))
        results = run_parallel_complete(adapter, prompts, concurrency=2)

        assert len(results) == 3
        assert all(isinstance(r, CompletionResult) for r in results)

    def test_order_preserved(self, _inject_litellm):
        adapter = _make_adapter()
        prompts = ["p0", "p1", "p2"]

        from yuragi.parallel import run_parallel_complete

        async def fake_acomplete(prompt, system=None, retries=2):
            return _make_result(f"reply-{prompt}")

        adapter.acomplete = AsyncMock(side_effect=fake_acomplete)
        results = run_parallel_complete(adapter, prompts, concurrency=3)

        for i, r in enumerate(results):
            assert f"p{i}" in r.text

    def test_on_done_callback_called(self, _inject_litellm):
        adapter = _make_adapter()
        prompts = ["x", "y"]
        called = []

        from yuragi.parallel import run_parallel_complete

        adapter.acomplete = AsyncMock(return_value=_make_result("ok"))
        run_parallel_complete(adapter, prompts, concurrency=2, on_done=lambda i, r: called.append(i))

        assert sorted(called) == [0, 1]

    def test_concurrency_respected(self, _inject_litellm):
        """Semaphore limits concurrent acomplete calls to `concurrency`."""
        adapter = _make_adapter(supports_logprobs=True)
        active: list[int] = []
        max_active: list[int] = []
        lock = threading.Lock()

        from yuragi.parallel import run_parallel_complete

        async def fake_acomplete(prompt, system=None, retries=2):
            with lock:
                active.append(1)
                max_active.append(len(active))
            await asyncio.sleep(0)
            with lock:
                active.pop()
            return _make_result("ok")

        adapter.acomplete = AsyncMock(side_effect=fake_acomplete)
        run_parallel_complete(adapter, [str(p) for p in range(6)], concurrency=2)

        assert max(max_active) <= 2
