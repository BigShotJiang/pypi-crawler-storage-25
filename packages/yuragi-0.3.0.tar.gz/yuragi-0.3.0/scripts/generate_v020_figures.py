"""Generate all v0.2.0 figures for docs/figures/.

Usage:
    python scripts/generate_v020_figures.py

Outputs 7 PNG files to docs/figures/ using synthetic data only (no LLM calls).
Seed is fixed at 42 for reproducibility.
"""

from __future__ import annotations

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # non-interactive backend

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import seaborn as sns

# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------

SEED = 42
rng = np.random.default_rng(SEED)

OUT_DIR = Path(__file__).parent.parent / "docs" / "figures"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# Style
sns.set_theme(style="darkgrid", palette="muted")
plt.rcParams.update({"figure.dpi": 300, "font.size": 11})


# ---------------------------------------------------------------------------
# 1. fig_hero.png — OG image: "One word changes AI confidence by 75%"
# ---------------------------------------------------------------------------

def make_fig_hero() -> None:
    fig, ax = plt.subplots(figsize=(12, 6.3))  # 1200x630 px @ 100dpi -> use savefig dpi
    fig.patch.set_facecolor("#0f172a")
    ax.set_facecolor("#0f172a")

    categories = ["Factual\nQuestion", "Opinion\nQuestion", "Technical\nQuestion"]
    before = [0.87, 0.73, 0.81]
    after  = [0.22, 0.08, 0.31]  # after "Are you really sure?"

    x = np.arange(len(categories))
    width = 0.32

    ax.bar(x - width / 2, before, width, label="Baseline Confidence",
           color="#38bdf8", alpha=0.92, zorder=3)
    ax.bar(x + width / 2, after, width, label='After "Are you really sure?"',
           color="#f97316", alpha=0.92, zorder=3)

    # Delta annotations
    for i, (b, a) in enumerate(zip(before, after, strict=False)):
        delta_pct = (b - a) / b * 100
        ax.annotate(
            f"-{delta_pct:.0f}%",
            xy=(x[i] + width / 2, a + 0.02),
            ha="center", fontsize=13, fontweight="bold",
            color="#fde68a",
        )

    ax.set_xticks(x)
    ax.set_xticklabels(categories, color="white", fontsize=13)
    ax.set_ylim(0, 1.15)
    ax.set_ylabel("Model Confidence", color="white", fontsize=13)
    ax.tick_params(colors="white")
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.yaxis.grid(True, color="#334155", linestyle="--", alpha=0.5)
    ax.set_axisbelow(True)

    ax.set_title(
        "One word changes AI confidence by 75%",
        color="white", fontsize=22, fontweight="bold", pad=20,
    )
    ax.text(
        0.5, -0.13,
        "yuragi — LLM Confidence Fragility Analyzer",
        transform=ax.transAxes, ha="center", color="#94a3b8", fontsize=11,
    )

    legend = ax.legend(loc="upper right", framealpha=0.2, labelcolor="white", fontsize=11)
    legend.get_frame().set_facecolor("#1e293b")

    path = OUT_DIR / "fig_hero.png"
    fig.savefig(path, dpi=100, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)
    print(f"  Saved: {path}  ({path.stat().st_size // 1024} KB)")


# ---------------------------------------------------------------------------
# 2. fig_fragility_heatmap.png — 5 questions x 13 perturbations (v0.2.0)
# ---------------------------------------------------------------------------

def make_fig_fragility_heatmap() -> None:
    questions = [
        "Is AI dangerous?",
        "What causes inflation?",
        "Is 17 prime?",
        "Best prog. language?",
        "Is exercise beneficial?",
    ]
    perturbations = [
        "typo", "synonym", "omit", "reorder", "tone", "paraphrase",
        "conformity", "impostor", "anchoring", "semantic",
        "negation", "counterfactual", "code_switch",
    ]

    # Synthetic fragility scores [0,1]
    data = rng.beta(1.5, 3.0, size=(len(questions), len(perturbations)))
    data[2, :] *= 0.3   # math question is less fragile
    data[3, :] = rng.beta(2.5, 1.5, size=len(perturbations))  # opinion very fragile

    fig, ax = plt.subplots(figsize=(14, 5.2))
    im = ax.imshow(data, aspect="auto", cmap="RdYlGn_r", vmin=0, vmax=1)
    ax.set_xticks(range(len(perturbations)))
    ax.set_xticklabels(perturbations, rotation=35, ha="right", fontsize=9)
    ax.set_yticks(range(len(questions)))
    ax.set_yticklabels(questions, fontsize=10)

    for i in range(len(questions)):
        for j in range(len(perturbations)):
            ax.text(j, i, f"{data[i, j]:.2f}", ha="center", va="center",
                    fontsize=7, color="black" if 0.3 < data[i, j] < 0.85 else "white")

    cbar = fig.colorbar(im, ax=ax, pad=0.01)
    cbar.set_label("Fragility Score", fontsize=11)

    ax.set_title("Confidence Fragility Heatmap — 5 Questions × 13 Perturbations",
                 fontsize=13, pad=12)
    ax.set_xlabel("Perturbation Type (v0.2.0: 13 types)", fontsize=11)
    ax.set_ylabel("Question", fontsize=11)

    fig.tight_layout()
    path = OUT_DIR / "fig_fragility_heatmap.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}  ({path.stat().st_size // 1024} KB)")


# ---------------------------------------------------------------------------
# 3. fig_decay_curve.png — Learned helplessness decay (7 rounds)
# ---------------------------------------------------------------------------

def make_fig_decay_curve() -> None:
    rounds = np.arange(1, 8)
    # Exponential decay model: C(r) = C0 * exp(-lambda * r) + noise
    lam = 0.18
    c0 = 0.85
    true_conf = c0 * np.exp(-lam * (rounds - 1))
    noise = rng.normal(0, 0.025, size=len(rounds))
    observed = np.clip(true_conf + noise, 0, 1)

    fit_x = np.linspace(1, 7, 100)
    fit_y = c0 * np.exp(-lam * (fit_x - 1))

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(fit_x, fit_y, "--", color="#94a3b8", linewidth=1.8, label="Decay model $C_0 e^{-\\lambda r}$", zorder=2)
    ax.scatter(rounds, observed, color="#f97316", s=80, zorder=5, label="Observed confidence")
    ax.plot(rounds, observed, color="#f97316", linewidth=1.5, alpha=0.6, zorder=4)

    ax.fill_between(fit_x, fit_y - 0.05, fit_y + 0.05, alpha=0.15, color="#94a3b8")

    # Annotation: Learned helplessness threshold
    ax.axhline(0.4, color="#ef4444", linestyle=":", linewidth=1.5, label="Helplessness threshold (0.40)")
    ax.text(5.5, 0.41, "Helplessness", color="#ef4444", fontsize=10)

    ax.set_xlabel("Pressure Round", fontsize=12)
    ax.set_ylabel("Model Confidence", fontsize=12)
    ax.set_title("Confidence Decay under Repeated Pressure\n(Learned Helplessness Paradigm)", fontsize=13)
    ax.set_xticks(rounds)
    ax.set_xticklabels([f"R{r}" for r in rounds])
    ax.set_ylim(0, 1.0)
    ax.legend(fontsize=10)
    fig.tight_layout()

    path = OUT_DIR / "fig_decay_curve.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}  ({path.stat().st_size // 1024} KB)")


# ---------------------------------------------------------------------------
# 4. fig_asch_backfire.png — Social pressure vs. confidence
# ---------------------------------------------------------------------------

def make_fig_asch_backfire() -> None:
    pressure_levels = ["None\n(control)", "1 peer\nagrees", "3 peers\nagree", "5 peers\nagree", "Unanimous\ngroup"]
    control_conf    = [0.91, 0.87, 0.74, 0.56, 0.31]
    wrong_conf      = [0.00, 0.05, 0.22, 0.38, 0.61]  # confidence in wrong answer

    x = np.arange(len(pressure_levels))

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(x, control_conf, "o-", color="#38bdf8", linewidth=2.2, markersize=8,
            label="Correct answer confidence")
    ax.plot(x, wrong_conf, "s--", color="#f97316", linewidth=2.2, markersize=8,
            label="Wrong answer confidence (social backfire)")

    ax.fill_between(x, control_conf, wrong_conf, alpha=0.08, color="gray")

    # Crossover annotation
    ax.axvline(3.2, color="#a855f7", linestyle=":", linewidth=1.5)
    ax.text(3.25, 0.55, "Backfire\nzone", color="#a855f7", fontsize=10)

    ax.set_xticks(x)
    ax.set_xticklabels(pressure_levels, fontsize=10)
    ax.set_ylim(-0.05, 1.05)
    ax.set_xlabel("Social Pressure Level (Asch paradigm)", fontsize=12)
    ax.set_ylabel("Model Confidence", fontsize=12)
    ax.set_title("Asch Conformity Effect on AI Confidence\n(Correct → Wrong under peer pressure)", fontsize=13)
    ax.legend(fontsize=10)
    fig.tight_layout()

    path = OUT_DIR / "fig_asch_backfire.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}  ({path.stat().st_size // 1024} KB)")


# ---------------------------------------------------------------------------
# 5. fig_dissociation_scatter.png — Answer similarity x |delta_confidence|
# ---------------------------------------------------------------------------

def make_fig_dissociation_scatter() -> None:
    # Most points: high similarity, low delta (normal)
    sim_normal  = rng.beta(9, 1.5, size=140)
    delta_normal = rng.beta(1.5, 8, size=140)

    # Dissociation: high similarity, HIGH delta
    sim_dissoc  = rng.beta(8, 1.2, size=40)
    delta_dissoc = rng.beta(5, 1.5, size=40)

    # Changed answers: low similarity, various delta
    sim_changed  = rng.beta(1.5, 5, size=20)
    delta_changed = rng.uniform(0.1, 0.8, size=20)

    fig, ax = plt.subplots(figsize=(8, 6))

    ax.scatter(sim_normal, delta_normal, color="#38bdf8", alpha=0.5, s=25, label="Normal (stable)")
    ax.scatter(sim_changed, delta_changed, color="#f97316", alpha=0.6, s=35, marker="^",
               label="Answer changed")
    ax.scatter(sim_dissoc, delta_dissoc, color="#ef4444", alpha=0.8, s=50, marker="D",
               label="Dissociation (answer same, confidence collapsed)")

    # Dissociation zone highlight
    rect = mpatches.FancyBboxPatch(
        (0.75, 0.45), 0.24, 0.53,
        boxstyle="round,pad=0.01",
        linewidth=2, edgecolor="#ef4444", facecolor="#ef4444", alpha=0.08,
    )
    ax.add_patch(rect)
    ax.text(0.78, 0.95, "Dissociation\nZone", color="#ef4444", fontsize=11, fontweight="bold")

    ax.set_xlim(0, 1.01)
    ax.set_ylim(0, 1.01)
    ax.set_xlabel("Answer Semantic Similarity (original vs. perturbed)", fontsize=12)
    ax.set_ylabel("|Δ Confidence|", fontsize=12)
    ax.set_title("Confidence Dissociation Map\n(Same answer, collapsed confidence = Dissociation)", fontsize=13)
    ax.legend(fontsize=10, loc="lower left")
    fig.tight_layout()

    path = OUT_DIR / "fig_dissociation_scatter.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}  ({path.stat().st_size // 1024} KB)")


# ---------------------------------------------------------------------------
# 6. fig_trilayer_radar.png — Logprob / Sampling / Verbalized radar
# ---------------------------------------------------------------------------

def make_fig_trilayer_radar() -> None:
    categories = ["Logprob\nConsistency", "Sampling\nDiversity", "Verbalized\nCalibration",
                  "Semantic\nEntropy", "Volatility\n(VIX)"]
    n_cat = len(categories)

    # Three models: llama3.2, phi4-mini, qwen2.5-3b
    models = {
        "llama3.2": [0.72, 0.68, 0.55, 0.61, 0.30],
        "phi4-mini": [0.81, 0.75, 0.63, 0.71, 0.22],
        "qwen2.5-3b": [0.65, 0.59, 0.70, 0.55, 0.41],
    }
    colors = ["#38bdf8", "#a855f7", "#f97316"]

    angles = np.linspace(0, 2 * np.pi, n_cat, endpoint=False).tolist()
    angles += angles[:1]  # close polygon

    fig, ax = plt.subplots(figsize=(7, 7), subplot_kw={"polar": True})

    for (model_name, values), color in zip(models.items(), colors, strict=False):
        vals = values + values[:1]
        ax.plot(angles, vals, "o-", linewidth=2, color=color, label=model_name)
        ax.fill(angles, vals, alpha=0.12, color=color)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, fontsize=10)
    ax.set_ylim(0, 1)
    ax.set_yticks([0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(["0.25", "0.50", "0.75", "1.0"], fontsize=8)
    ax.set_title("Tri-Layer Confidence Radar\n(Model Comparison)", fontsize=13, pad=20)
    ax.legend(loc="upper right", bbox_to_anchor=(1.3, 1.15), fontsize=10)

    fig.tight_layout()
    path = OUT_DIR / "fig_trilayer_radar.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}  ({path.stat().st_size // 1024} KB)")


# ---------------------------------------------------------------------------
# 7. fig_reliability_diagram.png — Calibration reliability diagram
# ---------------------------------------------------------------------------

def make_fig_reliability_diagram() -> None:
    sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
    from yuragi.visualize import plot_reliability_diagram

    n = 300
    # Synthetic: slightly overconfident model
    true_probs = rng.uniform(0.1, 0.95, size=n)
    # Model predicts higher than true
    predicted_conf = np.clip(true_probs + rng.normal(0.07, 0.12, size=n), 0.0, 1.0)
    outcomes = rng.binomial(1, true_probs).astype(bool)

    path = OUT_DIR / "fig_reliability_diagram.png"
    fig = plot_reliability_diagram(
        confidences=predicted_conf.tolist(),
        accuracies=outcomes.tolist(),
        title="Reliability Diagram (Calibration Quality)",
        show_ece=True,
        save_path=str(path),
    )
    plt.close(fig)
    print(f"  Saved: {path}  ({path.stat().st_size // 1024} KB)")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("Generating v0.2.0 figures → docs/figures/")
    make_fig_hero()
    make_fig_fragility_heatmap()
    make_fig_decay_curve()
    make_fig_asch_backfire()
    make_fig_dissociation_scatter()
    make_fig_trilayer_radar()
    make_fig_reliability_diagram()
    print(f"\nDone. {len(list(OUT_DIR.glob('*.png')))} PNG files in {OUT_DIR}")
