#!/bin/bash
# Record demo for README
# Requirements: asciinema (pip install asciinema) or VHS

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(dirname "$SCRIPT_DIR")"
RECORDINGS_DIR="$REPO_ROOT/docs/recordings"

mkdir -p "$RECORDINGS_DIR"

echo "Recording yuragi demo..."

# Demo 1: Basic scan
asciinema rec --command 'yuragi scan "Is AI dangerous for humanity?" -m ollama/llama3.2 -n 2 -v 1 -p tone,omit' \
  --title "yuragi scan demo" \
  --idle-time-limit 2 \
  "$RECORDINGS_DIR/scan_demo.cast"

# Demo 2: Find weakness
asciinema rec --command 'yuragi find-weakness "Explain quantum computing in simple terms" -m ollama/llama3.2 -n 2' \
  --title "yuragi find-weakness demo" \
  --idle-time-limit 2 \
  "$RECORDINGS_DIR/weakness_demo.cast"

# Demo 3: Experiment
asciinema rec --command 'yuragi experiment asch -m ollama/llama3.2 -n 2' \
  --title "yuragi experiment demo" \
  --idle-time-limit 2 \
  "$RECORDINGS_DIR/experiment_demo.cast"

echo "Done. Recordings saved to $RECORDINGS_DIR/"
