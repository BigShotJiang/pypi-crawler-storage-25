#!/usr/bin/env python3
"""Run a quick demo using ollama/llama3.2 and update README output examples.

Requires: ollama running locally with llama3.2 pulled.
  ollama pull llama3.2

Usage:
    python scripts/demo_fast.py
    python scripts/demo_fast.py --update-readme
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).parent.parent
README_PATH = REPO_ROOT / "README.md"
DOCS_DIR = REPO_ROOT / "docs"
RECORDINGS_DIR = REPO_ROOT / "docs" / "recordings"

MODEL = "ollama/llama3.2"
LABEL = f"(recorded with {MODEL} on CPU)"

DEMOS = [
    {
        "name": "scan",
        "cmd": [
            "yuragi", "scan",
            "Is AI dangerous for humanity?",
            "-m", MODEL,
            "-n", "2",
            "-v", "1",
            "-p", "tone,omit",
        ],
        "output_file": "demo_scan_output.txt",
    },
    {
        "name": "find-weakness",
        "cmd": [
            "yuragi", "find-weakness",
            "Explain quantum computing in simple terms",
            "-m", MODEL,
            "-n", "2",
        ],
        "output_file": "demo_find_weakness_output.txt",
    },
    {
        "name": "experiment",
        "cmd": [
            "yuragi", "experiment", "asch",
            "-m", MODEL,
            "-n", "2",
        ],
        "output_file": "demo_experiment_output.txt",
    },
]


def run_demo(demo: dict) -> str:
    print(f"  Running: yuragi {demo['name']} ...")
    result = subprocess.run(
        demo["cmd"],
        capture_output=True,
        text=True,
        cwd=REPO_ROOT,
    )
    if result.returncode != 0:
        print(f"  ERROR: {result.stderr.strip()}", file=sys.stderr)
        sys.exit(1)
    return result.stdout


def save_output(demo: dict, output: str) -> None:
    out_path = DOCS_DIR / demo["output_file"]
    out_path.write_text(output, encoding="utf-8")
    print(f"  wrote {out_path}")


def update_readme(outputs: dict[str, str]) -> None:
    content = README_PATH.read_text(encoding="utf-8")
    original = content

    import re

    # Replace content between the three <details> code blocks in Output examples section
    for demo_name, output in outputs.items():
        # Strip ANSI escape codes for plain README embedding
        ansi_escape = re.compile(r"\x1b\[[0-9;]*m")
        clean = ansi_escape.sub("", output).rstrip()
        _ = clean  # reserved for future plain-text embedding

    # Replace (pre-computed) label across the README output examples
    content = content.replace("(pre-computed)", LABEL)
    content = content.replace("pre-computed", f"recorded with {MODEL} on CPU")

    if content == original:
        print("  README already up to date.")
        return

    README_PATH.write_text(content, encoding="utf-8")
    print(f"  updated {README_PATH}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--update-readme",
        action="store_true",
        help="Update README.md output examples with live output labels",
    )
    args = parser.parse_args()

    DOCS_DIR.mkdir(exist_ok=True)
    RECORDINGS_DIR.mkdir(exist_ok=True)

    print(f"Running yuragi demos with {MODEL}...")
    outputs: dict[str, str] = {}
    for demo in DEMOS:
        output = run_demo(demo)
        save_output(demo, output)
        outputs[demo["name"]] = output

    if args.update_readme:
        print("Updating README...")
        update_readme(outputs)

    print("Done.")


if __name__ == "__main__":
    main()
