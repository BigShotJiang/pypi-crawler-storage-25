#!/usr/bin/env python3
"""Phase 0 Prototype: Validate that confidence fragility is real.

Run this to confirm the core phenomenon:
"Answer stays the same, but confidence collapses."

Supports three backends (in priority order):
1. Ollama (local, free, logprobs) — best
2. Gemini (free tier, no logprobs) — sampling mode
3. Groq (free tier, no logprobs) — sampling mode

Usage:
    # Auto-detect available backend
    python scripts/prototype.py

    # Force a specific backend
    python scripts/prototype.py --backend ollama
    python scripts/prototype.py --backend gemini
    python scripts/prototype.py --backend groq
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from dotenv import load_dotenv

load_dotenv(Path(__file__).parent.parent / ".env")

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


# --- Test questions covering diverse topics ---
TEST_QUESTIONS = [
    # Factual
    "What is the capital of France?",
    "How many planets are in our solar system?",
    "What year did World War II end?",
    "Who wrote Romeo and Juliet?",
    "What is the speed of light?",
    # Opinion / uncertain
    "Is artificial intelligence dangerous?",
    "Will quantum computing be practical by 2030?",
    "Is remote work better than office work?",
    "Should we colonize Mars?",
    "Is social media good for society?",
    # Technical
    "Explain how a neural network learns",
    "What causes inflation?",
    "How does CRISPR gene editing work?",
    "Why is the sky blue?",
    "How do vaccines work?",
    # Japanese
    "日本で一番高い山は何ですか？",
    "量子コンピュータは実用化されるか？",
    "AIは意識を持つことができますか？",
    "地球温暖化の主な原因は何ですか？",
    "プログラミングを学ぶのに最適な言語は何ですか？",
]

# Tone perturbations that should affect confidence but not the answer
TONE_PERTURBATIONS = {
    "doubt": "I'm not sure you can answer this correctly, but: ",
    "authority": "As a world-class expert, answer: ",
    "certainty_demand": " Answer with absolute certainty.",
    "uncertainty_inject": " Are you really sure? Many experts disagree.",
    "casual": "Hey quick question: ",
}

JA_TONE_PERTURBATIONS = {
    "doubt": "間違えそうだけど、",
    "authority": "専門家として答えて。",
    "certainty_demand": " 絶対に正しい答えを出してください。",
    "uncertainty_inject": " 本当にそうですか？多くの専門家は異なる意見を持っています。",
    "casual": "ねえ、",
}


def is_japanese(text: str) -> bool:
    for char in text:
        cp = ord(char)
        if (0x3040 <= cp <= 0x309F) or (0x30A0 <= cp <= 0x30FF) or (0x4E00 <= cp <= 0x9FFF):
            return True
    return False


def detect_backend() -> str:
    """Auto-detect which backend is available."""
    # Check ollama
    import shutil

    if shutil.which("ollama"):
        try:
            import subprocess

            result = subprocess.run(
                ["ollama", "list"], capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0 and "llama" in result.stdout.lower():
                return "ollama"
        except Exception:
            pass

    # Check Gemini
    if os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY"):
        return "gemini"

    # Check Groq
    if os.environ.get("GROQ_API_KEY"):
        return "groq"

    return "none"


def get_model_for_backend(backend: str) -> str:
    if backend == "ollama":
        return "ollama/llama3.2"
    elif backend == "gemini":
        return "gemini/gemini-2.0-flash"
    elif backend == "groq":
        return "groq/llama-3.1-8b-instant"
    else:
        raise ValueError(f"Unknown backend: {backend}")


def measure_confidence_sampling(
    model: str, prompt: str, num_samples: int = 5
) -> tuple[str, float]:
    """Measure confidence via multi-sample agreement."""
    import litellm

    litellm.suppress_debug_info = True

    responses = []
    for _ in range(num_samples):
        try:
            resp = litellm.completion(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=200,
            )
            text = resp.choices[0].message.content or ""
            responses.append(text)
        except Exception as e:
            console.print(f"[dim red]API error: {e}[/dim red]")
            continue

    if not responses:
        return "", 0.0

    # Measure agreement (word-overlap Jaccard)
    n = len(responses)
    if n <= 1:
        return responses[0] if responses else "", 0.5

    similarities = []
    for i in range(n):
        for j in range(i + 1, n):
            words_a = set(responses[i].lower().split())
            words_b = set(responses[j].lower().split())
            union = words_a | words_b
            if union:
                similarities.append(len(words_a & words_b) / len(union))

    confidence = sum(similarities) / len(similarities) if similarities else 0.5
    return responses[0], confidence


def measure_confidence_logprobs(model: str, prompt: str) -> tuple[str, float]:
    """Measure confidence via logprob entropy (ollama)."""
    import math

    import litellm

    litellm.suppress_debug_info = True

    try:
        resp = litellm.completion(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.0,
            max_tokens=200,
            logprobs=True,
            top_logprobs=10,
        )
    except Exception as e:
        console.print(f"[dim red]Logprob error, falling back to sampling: {e}[/dim red]")
        return measure_confidence_sampling(model, prompt)

    text = resp.choices[0].message.content or ""

    # Extract entropy from logprobs
    try:
        content = resp.choices[0].logprobs.content
        if not content:
            return measure_confidence_sampling(model, prompt)

        entropies = []
        for token_info in content:
            if hasattr(token_info, "top_logprobs") and token_info.top_logprobs:
                probs = [math.exp(e.logprob) for e in token_info.top_logprobs]
                total = sum(probs)
                if total > 0:
                    probs = [p / total for p in probs]
                    entropy = -sum(p * math.log2(p) for p in probs if p > 0)
                    entropies.append(entropy)

        if entropies:
            avg_entropy = sum(entropies) / len(entropies)
            confidence = max(0.0, min(1.0, 1.0 - (avg_entropy / 3.0)))
        else:
            return measure_confidence_sampling(model, prompt)
    except (AttributeError, TypeError):
        return measure_confidence_sampling(model, prompt)

    return text, confidence


def answer_similarity(a: str, b: str) -> float:
    """Check if two answers are essentially the same."""
    words_a = set(a.lower().split()[:50])
    words_b = set(b.lower().split()[:50])
    if not words_a or not words_b:
        return 0.0
    union = words_a | words_b
    return len(words_a & words_b) / len(union) if union else 0.0


def run_prototype(backend: str, num_questions: int = 10, num_samples: int = 5):
    """Run the prototype validation experiment."""
    model = get_model_for_backend(backend)
    use_logprobs = backend == "ollama"

    console.print(
        Panel(
            f"[bold]Phase 0: Prototype Validation[/bold]\n"
            f"Backend: {backend} | Model: {model}\n"
            f"Method: {'logprobs' if use_logprobs else 'sampling'} | "
            f"Samples: {num_samples}\n"
            f"Questions: {num_questions}",
            title="[bold cyan]yuragi prototype[/bold cyan]",
            border_style="cyan",
        )
    )

    questions = TEST_QUESTIONS[:num_questions]
    results = []

    for qi, question in enumerate(questions):
        console.print(f"\n[cyan]({qi + 1}/{len(questions)})[/cyan] {question[:60]}...")

        is_ja = is_japanese(question)
        tones = JA_TONE_PERTURBATIONS if is_ja else TONE_PERTURBATIONS

        # Baseline
        if use_logprobs:
            baseline_text, baseline_conf = measure_confidence_logprobs(model, question)
        else:
            baseline_text, baseline_conf = measure_confidence_sampling(
                model, question, num_samples
            )

        console.print(f"  Baseline: {baseline_conf:.2f}")

        question_results = {
            "question": question,
            "baseline_confidence": baseline_conf,
            "baseline_answer": baseline_text[:200],
            "perturbations": [],
        }

        # Test each tone perturbation
        for tone_name, modifier in tones.items():
            if modifier.endswith(": ") or modifier.endswith("。") or modifier.endswith("、"):
                perturbed = modifier + question
            else:
                perturbed = question + modifier

            if use_logprobs:
                pert_text, pert_conf = measure_confidence_logprobs(model, perturbed)
            else:
                pert_text, pert_conf = measure_confidence_sampling(
                    model, perturbed, num_samples
                )

            delta = pert_conf - baseline_conf
            same_answer = answer_similarity(baseline_text, pert_text) > 0.5
            dissociated = same_answer and abs(delta) > 0.1

            # Display
            indicator = ""
            if dissociated:
                indicator = " [bold magenta][DISSOCIATED][/bold magenta]"
            elif abs(delta) > 0.2:
                indicator = " [bold red][BIG SHIFT][/bold red]"

            console.print(
                f"  {tone_name:20s}: {pert_conf:.2f} "
                f"({'same' if same_answer else 'CHANGED':>7s}) "
                f"delta={delta:+.2f}{indicator}"
            )

            question_results["perturbations"].append(
                {
                    "tone": tone_name,
                    "confidence": pert_conf,
                    "delta": delta,
                    "answer_same": same_answer,
                    "dissociated": dissociated,
                }
            )

            # Rate limiting (generous to avoid 429s)
            time.sleep(1.5)

        results.append(question_results)
        time.sleep(1.5)

    # --- Summary ---
    console.print("\n")

    all_deltas = []
    dissociation_count = 0
    total_perturbations = 0

    for r in results:
        for p in r["perturbations"]:
            all_deltas.append(abs(p["delta"]))
            total_perturbations += 1
            if p["dissociated"]:
                dissociation_count += 1

    avg_delta = sum(all_deltas) / len(all_deltas) if all_deltas else 0
    max_delta = max(all_deltas) if all_deltas else 0
    dissoc_rate = dissociation_count / total_perturbations if total_perturbations else 0

    # Find biggest single shift
    biggest_shift = None
    for r in results:
        for p in r["perturbations"]:
            if biggest_shift is None or abs(p["delta"]) > abs(biggest_shift["delta"]):
                biggest_shift = {**p, "question": r["question"]}

    table = Table(title="Prototype Results", box=box.ROUNDED)
    table.add_column("Metric", style="bold")
    table.add_column("Value")
    table.add_column("Assessment")

    # Go/No-Go assessment
    if avg_delta >= 0.1:
        avg_assessment = "[green]PASS[/green]"
    else:
        avg_assessment = "[red]WEAK[/red]"

    if max_delta >= 0.3:
        max_assessment = "[bold green]STRONG PASS[/bold green]"
    elif max_delta >= 0.15:
        max_assessment = "[green]PASS[/green]"
    else:
        max_assessment = "[red]FAIL[/red]"

    if dissoc_rate >= 0.2:
        dissoc_assessment = "[bold green]KEY FINDING[/bold green]"
    elif dissoc_rate >= 0.1:
        dissoc_assessment = "[green]PRESENT[/green]"
    else:
        dissoc_assessment = "[yellow]WEAK[/yellow]"

    table.add_row("Avg |delta|", f"{avg_delta:.3f}", avg_assessment)
    table.add_row("Max |delta|", f"{max_delta:.3f}", max_assessment)
    table.add_row("Confidence Dissociation rate", f"{dissoc_rate:.1%}", dissoc_assessment)
    table.add_row("Total perturbations", str(total_perturbations), "")

    if biggest_shift:
        table.add_row(
            "Biggest shift",
            f"{biggest_shift['tone']}: {biggest_shift['delta']:+.3f}",
            f"Q: {biggest_shift['question'][:40]}...",
        )

    console.print(table)

    # Final verdict
    if max_delta >= 0.3 and dissoc_rate >= 0.1:
        console.print(
            Panel(
                "[bold green]GO[/bold green] — Core phenomenon confirmed.\n"
                f"Max confidence shift: {max_delta:.0%}\n"
                f"Confidence Dissociation rate: {dissoc_rate:.0%}\n"
                "Proceed to full development.",
                title="[bold]Verdict[/bold]",
                border_style="green",
            )
        )
    elif max_delta >= 0.15:
        console.print(
            Panel(
                "[bold yellow]CONDITIONAL GO[/bold yellow] — Phenomenon present but weak.\n"
                "Consider adjusting perturbation strategy.",
                title="[bold]Verdict[/bold]",
                border_style="yellow",
            )
        )
    else:
        console.print(
            Panel(
                "[bold red]NO-GO[/bold red] — Confidence shifts too small.\n"
                "Re-evaluate approach.",
                title="[bold]Verdict[/bold]",
                border_style="red",
            )
        )

    # Save results
    output_path = Path(__file__).parent.parent / "docs" / "prototype_results.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(
            {
                "backend": backend,
                "model": model,
                "method": "logprobs" if use_logprobs else "sampling",
                "num_samples": num_samples,
                "avg_delta": avg_delta,
                "max_delta": max_delta,
                "dissociation_rate": dissoc_rate,
                "results": results,
            },
            f,
            indent=2,
            ensure_ascii=False,
        )
    console.print(f"\n[dim]Results saved to {output_path}[/dim]")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="yuragi Phase 0 prototype")
    parser.add_argument(
        "--backend",
        choices=["ollama", "gemini", "groq", "auto"],
        default="auto",
        help="Which backend to use",
    )
    parser.add_argument("--questions", type=int, default=10, help="Number of questions")
    parser.add_argument("--samples", type=int, default=5, help="Samples per measurement")
    args = parser.parse_args()

    if args.backend == "auto":
        backend = detect_backend()
        if backend == "none":
            console.print(
                "[red]No backend available.[/red]\n"
                "Options:\n"
                "  1. Install ollama: curl -fsSL https://ollama.com/install.sh | sh && ollama pull llama3.2\n"
                "  2. Set GEMINI_API_KEY in ~/oss/yuragi/.env\n"
                "  3. Set GROQ_API_KEY in ~/oss/yuragi/.env"
            )
            sys.exit(1)
    else:
        backend = args.backend

    console.print(f"[cyan]Using backend: {backend}[/cyan]")
    run_prototype(backend, num_questions=args.questions, num_samples=args.samples)
