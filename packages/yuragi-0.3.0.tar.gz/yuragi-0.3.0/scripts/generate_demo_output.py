#!/usr/bin/env python3
"""Generate demo output files for README hero section.

Uses pre-computed data from docs/demo_data.json (no API key needed).
Produces plain-text ANSI output files under docs/.

Usage:
    python scripts/generate_demo_output.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.text import Text

REPO_ROOT = Path(__file__).parent.parent
DEMO_DATA = REPO_ROOT / "docs" / "demo_data.json"
DOCS_DIR = REPO_ROOT / "docs"


def _confidence_bar(value: float, width: int = 25) -> Text:
    filled = int(value * width)
    empty = width - filled
    if value >= 0.7:
        color = "green"
    elif value >= 0.4:
        color = "yellow"
    else:
        color = "red"
    bar = Text()
    bar.append("\u2588" * filled, style=color)
    bar.append("\u2591" * empty, style="dim")
    bar.append(f" {value:.2f}", style="bold " + color)
    return bar


def _delta_text(delta: float) -> Text:
    if abs(delta) < 0.05:
        return Text(f"  {delta:+.2f}", style="dim")
    elif delta < -0.2:
        return Text(f"\u26a1\u26a1 {delta:+.2f}", style="bold red")
    elif delta < 0:
        return Text(f"\u26a1  {delta:+.2f}", style="red")
    elif delta > 0.2:
        return Text(f"\u2b06  {delta:+.2f}", style="bold green")
    else:
        return Text(f"\u2b06  {delta:+.2f}", style="green")


def _severity_label(severity: float) -> Text:
    if severity < 0.1:
        return Text("—", style="dim")
    elif severity < 0.3:
        return Text("low", style="blue")
    elif severity < 0.5:
        return Text("mid", style="magenta")
    elif severity < 0.7:
        return Text("high", style="bold magenta")
    else:
        return Text("CRIT", style="bold bright_magenta")


def generate_scan_output(data: dict) -> None:
    out_path = DOCS_DIR / "demo_scan_output.txt"
    console = Console(file=open(out_path, "w"), highlight=False, width=90)

    scan = data["scan"]
    console.print(
        Panel(
            f"[bold]yuragi[/bold] confidence fragility scan\n"
            f"[dim]Model: {scan['model']} | Method: {scan['confidence_method']} | "
            f"Duration: {scan['scan_duration_seconds']}s | "
            f"API calls: {scan['total_api_calls']}[/dim]",
            title="[bold cyan]\u63fa\u3089\u304e[/bold cyan]",
            border_style="cyan",
        )
    )

    console.print(f"\n[bold]Original:[/bold] {scan['prompt']}")
    console.print(Text.assemble("Confidence: ", _confidence_bar(scan["baseline_confidence"])))
    console.print()

    table = Table(
        title="Perturbation Results",
        box=box.ROUNDED,
        show_lines=True,
        title_style="bold",
    )
    table.add_column("Type", style="cyan", width=11)
    table.add_column("Perturbed Prompt", max_width=36)
    table.add_column("Confidence", width=30)
    table.add_column("\u0394", width=13)
    table.add_column("Severity", width=8)

    for p in sorted(scan["perturbations"], key=lambda x: x["delta"]):
        delta = _delta_text(p["delta"])
        if p["dissociated"]:
            delta.append(" [!]", style="bold magenta")
        table.add_row(
            p["type"],
            p["prompt"],
            _confidence_bar(p["confidence"]),
            delta,
            _severity_label(p["dissociation_severity"]),
        )

    console.print(table)
    console.print()

    fp = scan["fragility_profile"]
    summary = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    summary.add_column(style="dim", width=28)
    summary.add_column(width=16)
    summary.add_row("Fragility Score", f"[bold red]{scan['fragility_score']:.2f}[/bold red]  ({scan['fragility_label']})")
    summary.add_row("Dissociation Rate", f"[yellow]{scan['dissociation_rate']:.0%}[/yellow]")
    summary.add_row("Confidence Range", f"{scan['confidence_range']:.2f}")
    summary.add_row("Max Confidence Drop", f"[red]{scan['max_confidence_drop']:.2f}[/red]")
    summary.add_row("CCI", f"{fp['catastrophic_collapse_index']:.2f}")
    summary.add_row("Recovery Elasticity", f"{fp['recovery_elasticity']:.2f}")
    summary.add_row("Non-linearity Score", f"{fp['non_linearity_score']:.2f}")
    summary.add_row("Profile", f"[bold red]{fp['profile_label']}[/bold red]")
    console.print(Panel(summary, title="[bold]Fragility Summary[/bold]", border_style="red"))

    console.print(
        "\n[bold yellow]\u26a1 Key insight:[/bold yellow] "
        "A single phrasing change collapsed confidence by [red]58%[/red] while the answer stayed identical. "
        "This is textbook [bold]dissociation[/bold]: the model's certainty is decorative, not informational.\n"
    )
    console.file.close()
    print(f"  wrote {out_path}")


def generate_experiment_output(data: dict) -> None:
    out_path = DOCS_DIR / "demo_experiment_output.txt"
    console = Console(file=open(out_path, "w"), highlight=False, width=90)

    exp = data["experiment"]
    console.print(
        Panel(
            f"[bold]yuragi[/bold] psychology experiment\n"
            f"[dim]Model: {exp['model']} | Experiment: {exp['name']} | "
            f"Effect confirmed: {'yes' if exp['effect_confirmed'] else 'no'}[/dim]",
            title="[bold cyan]\u63fa\u3089\u304e[/bold cyan]",
            border_style="cyan",
        )
    )

    console.print(f"\n[bold]Experiment:[/bold] {exp['name'].upper()} — {exp['description']}")
    console.print(f"[dim]Hypothesis:[/dim] {exp['hypothesis']}\n")

    table = Table(
        title="Control vs. Treatment",
        box=box.ROUNDED,
        show_lines=True,
        title_style="bold",
    )
    table.add_column("#", style="dim", width=3)
    table.add_column("Control", max_width=32)
    table.add_column("Control Conf.", width=30)
    table.add_column("Treatment Conf.", width=30)
    table.add_column("\u0394", width=13)

    for i, r in enumerate(exp["results"], 1):
        delta = _delta_text(r["delta"])
        if r["dissociated"]:
            delta.append(" [!]", style="bold magenta")
        table.add_row(
            str(i),
            r["control"],
            _confidence_bar(r["control_confidence"]),
            _confidence_bar(r["treatment_confidence"]),
            delta,
        )

    console.print(table)
    console.print()

    summary = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    summary.add_column(style="dim", width=22)
    summary.add_column(width=16)
    summary.add_row("Avg. Confidence Drop", f"[red]{exp['avg_delta']:.2f}[/red]")
    summary.add_row("Max Drop Observed", f"[bold red]{exp['max_delta']:.2f}[/bold red]")
    summary.add_row("Dissociation Rate", f"[yellow]{exp['dissociation_rate']:.0%}[/yellow]")
    summary.add_row("Effect Confirmed", "[bold green]YES[/bold green]" if exp["effect_confirmed"] else "[dim]no[/dim]")
    console.print(Panel(summary, title="[bold]Experiment Summary[/bold]", border_style="magenta"))

    console.print(
        "\n[bold yellow]\u26a1 Key insight:[/bold yellow] "
        "[bold]75%[/bold] of trials showed confidence collapse under false social pressure — "
        "without a single answer changing. "
        "The model conforms to invented consensus exactly as humans do in Asch's original experiments.\n"
    )
    console.file.close()
    print(f"  wrote {out_path}")


def generate_find_weakness_output(data: dict) -> None:
    out_path = DOCS_DIR / "demo_find_weakness_output.txt"
    console = Console(file=open(out_path, "w"), highlight=False, width=90)

    fw = data["find_weakness"]
    console.print(
        Panel(
            f"[bold]yuragi[/bold] find-weakness\n"
            f"[dim]Model: {fw['model']} | Method: gradient word omission[/dim]",
            title="[bold cyan]\u63fa\u3089\u304e[/bold cyan]",
            border_style="cyan",
        )
    )

    console.print(f"\n[bold]Original:[/bold] {fw['prompt']}")
    console.print(Text.assemble("Baseline Confidence: ", _confidence_bar(fw["baseline_confidence"])))
    console.print()

    table = Table(
        title="Word-level Confidence Impact",
        box=box.ROUNDED,
        show_lines=True,
        title_style="bold",
    )
    table.add_column("Word", width=14)
    table.add_column("Omit Confidence", width=30)
    table.add_column("\u0394 vs. Baseline", width=13)
    table.add_column("Impact", width=8)

    for w in fw["words"]:
        is_weakest = w["word"] == fw["weakest_word"]
        label = Text("WEAK", style="bold red") if is_weakest else _severity_label(abs(w["delta"]))
        word_text = Text(f'"{w["word"]}"', style="bold red" if is_weakest else "")
        table.add_row(
            word_text,
            _confidence_bar(w["confidence"]),
            _delta_text(w["delta"]),
            label,
        )

    console.print(table)
    console.print()

    console.print(
        Panel(
            f'Removing [bold red]"{fw["weakest_word"]}"[/bold red] causes the largest confidence drop: '
            f'[bold red]{fw["weakest_delta"]:.2f}[/bold red]\n\n'
            f'Rewrite suggestion: replace [bold red]"{fw["weakest_word"]}"[/bold red] with a more concrete term\n'
            f'e.g. "[dim]Explain the [bold]scientific[/bold] theory of relativity[/dim]"',
            title="[bold]Weakest Word Detected[/bold]",
            border_style="red",
        )
    )
    console.print()
    console.file.close()
    print(f"  wrote {out_path}")


def main() -> None:
    if not DEMO_DATA.exists():
        print(f"error: {DEMO_DATA} not found", file=sys.stderr)
        sys.exit(1)

    data = json.loads(DEMO_DATA.read_text())
    DOCS_DIR.mkdir(exist_ok=True)

    print("Generating demo output files...")
    generate_scan_output(data)
    generate_experiment_output(data)
    generate_find_weakness_output(data)
    print("Done.")


if __name__ == "__main__":
    main()
