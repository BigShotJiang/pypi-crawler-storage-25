# Work-in-Progress Experiments

Experiments in this directory are **not part of any yuragi release** (including v0.3.0).
They are kept in version control as process-transparency artifacts but
should not be cited as evidence for any claim in README.md or docs/theory.md.

## Current WIP
- `sach_wort_probe/` — Logit-lens probe on pythia-410m. Historical bug 1 (missing ln_f)
  was fixed in commit `603d5b9`. Bug 2 (non-paraphrase perturbation) is still unfixed;
  the current n=3 data does not test the stated Sach/Wort hypothesis. See
  `sach_wort_probe/README.md` for details and the road map in `sach_wort_probe/NEXT_STEPS.md`.
