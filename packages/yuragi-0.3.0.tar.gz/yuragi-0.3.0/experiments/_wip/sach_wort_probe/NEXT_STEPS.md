# Next Steps for sach_wort_probe

## Status
- Bug 1 (ln_f missing): fixed in commit 603d5b9
- Bug 2 (non-paraphrase perturbation): **unfixed**. Current n=3 data cannot test the Sach/Wort hypothesis.
- New probe_paraphrase.py added with n=25 paraphrase-controlled runs, but has not been executed
  on an APU-capable environment as of this commit.

## To actually test the hypothesis (v0.3.0+ roadmap)

1. **Generate a proper paraphrase dataset** (n≥30 per anchor):
   - Use GPT-4 or Claude to generate semantic-preserving rewrites
   - Store in `paraphrase_dataset_v1.jsonl` with fields: {anchor_id, paraphrase, expected_next, source}
   - Human-validate a 10% sample for semantic equivalence

2. **Run probe_paraphrase.py with the real dataset**:
   - Expected APU time: ~15-20 minutes on Ryzen 7735HS (CPU)
   - Output: `results_paraphrase_v1.json` with per-layer entropy per paraphrase

3. **Statistical test**:
   - For each anchor group, compute mean per-layer entropy drift
   - Wilcoxon signed-rank test for early vs late layer drift
   - Bootstrap BCa 95% CI for drift ratio
   - Multiple comparison correction (Bonferroni for 5 anchor groups)

4. **Falsification criterion**:
   - H0: early_drift ≈ late_drift (ratio ∈ [0.8, 1.25])
   - H1: late_drift > early_drift (ratio > 2.0 with p<0.01)
   - If H0 cannot be rejected, the Sach/Wort hypothesis is **not supported** for pythia-410m.

5. **Scale up** (if initial result is positive):
   - Try additional models: gpt-neox-1.4B, opt-1.3b, Llama-3-8B (hidden state layer)
   - Different domains: factual, logical, commonsense
   - Cross-validate with NLI-based similarity check

## Known limitations even if Task 1-5 are completed

- pythia-410m is small; findings may not generalize to production-scale LLMs (7B+)
- Logit lens assumes unembedding matrix is a valid inverse map for all layers, which is only approximately true
- Entropy-based drift is an indirect proxy for "confidence"
- Paraphrase generation quality is a confounder

## Relation to yuragi main claims

This probe is **separate from** yuragi's main `Scanner` / `find-weakness` / `experiment` functionality,
which operates at the prompt/response surface level. The Sach/Wort probe is an exploratory research
direction for a possible v0.3.0 white-box extension. As of v0.2.0, no yuragi claim in README.md or
docs/theory.md depends on the Sach/Wort probe results.
