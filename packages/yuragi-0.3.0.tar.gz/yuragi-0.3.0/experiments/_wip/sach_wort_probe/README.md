# Sach/Wort Layer-wise Probe — pythia-410m

> **HONEST CORRECTION 2026-04-11 (post-audit)**: The first version of this probe had a critical bug — `final_layer_norm` was not applied to intermediate hidden states before logit-lens projection. The original "ratio 78-235x" finding was an **artifact**, not a signal. The corrected probe (this version) **does not support** the original hypothesis. See "Correction" section below.

## Hypothesis (original)

Under prompt perturbation, the **late-layer entropy** of the next-token distribution should fluctuate more than the **early-layer entropy** when projected via the unembedding matrix (logit lens).

In Freud terms: *Wort* (final layer) is unstable; *Sach* (early-mid layers) is stable. In neutral terms: surface lexical predictions move while underlying conceptual representations stay anchored.

## Method

- Model: `EleutherAI/pythia-410m` (24 transformer layers + embed = 25 hidden states; vocab = 50304)
- Probe: logit lens (project each layer's last-token hidden state through `embed_out` weight, compute Shannon entropy of resulting distribution)
- **Critical fix**: pythia (GPTNeoX) has `gpt_neox.final_layer_norm` (ln_f) applied before unembed in the real forward pass. HuggingFace returns `hidden_states[-1]` AFTER ln_f but `hidden_states[0..-2]` BEFORE ln_f. Without applying ln_f to intermediate layers, early-layer entropy gets stuck at `ln(vocab) ≈ 10.83` (uniform distribution) — a pure artifact of basis misalignment between the embedding space and the unembedding space.
- Prompts: 3 (factual, opinion, hallucination-prone), each with one perturbation pair (note: these are reformulations, NOT semantic-preserving paraphrases).

## Results

### Original (BUGGY — `ln_f` not applied)

| prompt | early drift (layers 0-5) | late drift (layers -6:) | ratio |
|---|---:|---:|---:|
| factual | 0.0052 | 0.6140 | 118 |
| opinion | 0.0190 | 1.4829 | 78 |
| hallu_prone | 0.0069 | 1.6305 | 235 |

Early drift values near 0.005-0.02 are **noise around the uniform-distribution floor**. Layer 0 entropy = 10.8257 ≈ ln(50304) = 10.826. The early layers were stuck at uniform, not "stable" in any meaningful sense. The ratio is meaningless because the denominator is artifact noise.

### Corrected (`ln_f` applied to intermediate layers)

| prompt | early drift (layers 0-5) | late drift (layers -6:) | ratio |
|---|---:|---:|---:|
| factual | 0.6668 | 0.9964 | **1.49** |
| opinion | 0.5539 | 2.6200 | **4.73** |
| hallu_prone | 0.7933 | 1.2566 | **1.58** |

When the artifact is removed:
- Early drift becomes the same order of magnitude as late drift (0.55-0.79 vs 0.99-2.62).
- Two of three prompts show ratio ≈ 1.5 — i.e., **early and late layers drift by similar amounts**.
- Only the "opinion" prompt shows weak late-dominance (4.73), but n=1 with a single different prompt is not evidence.

**The original "Sach stable / Wort fluctuating" hypothesis is not supported by this corrected n=3 probe.**

![figure.png](figure.png)

The figure shows TOP row = corrected (with ln_f), BOTTOM row = original buggy version with `ln(vocab)` reference line showing the floor.

## What this means for yuragi v0.3.0

1. The "Grounding Dissociation" research direction is **not falsified by this probe** — n=3 with non-paraphrase perturbations cannot establish or refute the hypothesis. But the probe does **not provide empirical support** either.
2. A real test requires: paraphrase-stable perturbations (semantic-preserving rewrites of the same prompt), n ≥ 30, paired statistical testing, and a control comparing early/late drift on different completions of the same prefix to rule out token-distance confounds.
3. Until such a probe is run, **do not cite this experiment as evidence** for the Sach/Wort or Grounding Dissociation hypothesis. Cite it instead as evidence that **logit-lens probes need careful normalization**, and as a worked example of an artifact that can fool n=3 studies.
4. The architect's "case W1" from the Round 14 audit (logit lens × layer-wise confidence) is still a valid research direction, but its first probe must be done with `ln_f` applied and a proper paraphrase dataset.

## Process notes (for transparency)

- First run (commit `88cc2b3`): claimed "ratio 78-235x supports the hypothesis". This was wrong.
- Final audit by 7 parallel review agents flagged the bug within 30 minutes of publication. Both `critic` and `architect` independently caught it.
- The corrected probe (commit `<this commit>`) refutes the original claim within the same n=3 sample.
- This is documented openly here and in the commit history. The wrong file `results_pythia410m_n3.json` is preserved alongside the corrected `results_pythia410m_n3_lnf_fixed.json` so future readers can see what went wrong.

## Files

- `probe.py` — corrected probe script (applies `ln_f` to intermediate hidden states)
- `results_pythia410m_n3.json` — original buggy results (kept for transparency)
- `results_pythia410m_n3_lnf_fixed.json` — corrected results
- `figure.png` — both versions side by side
- `README.md` — this file

## Reproduction

```bash
/usr/bin/python3 experiments/sach_wort_probe/probe.py
```

Wall-clock: ~1 minute on Ryzen 7735HS APU (CPU only). First run downloads ~800MB.

## Lessons

1. **Always apply the model's final LayerNorm before logit-lens projection.** This is the standard procedure (nostalgebraist 2020). Skipping it makes early layers look like uniform distributions.
2. **n=3 is not just statistically weak — it can be confidently wrong.** Three "positive" results from artifact-corrupted code looked perfectly consistent.
3. **Get adversarial review before publishing.** A 30-minute audit by independent reviewers caught what 1 hour of solo coding missed.
