"""DEPRECATED: see probe_paraphrase.py for the paraphrase-controlled version.

Logit Lens probe — Sach/Wort layer-wise confidence drift on pythia-410m.

Hypothesis (Freud 1915 §VII analogy):
  - Wort (final layer) — token-level confidence
  - Sach (early-mid layers, "concept") — earlier hidden state confidence
  - "Confidence Dissociation" = early layer confidence stable, final layer fluctuates

Test:
  3 prompts (factual / opinion / hallucination-prone)
  baseline + 1 perturbation (mild paraphrase)
  measure entropy at every layer using logit lens
  check: does early-layer entropy stay stable while late-layer entropy jumps?
"""
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer

MODEL_NAME = "EleutherAI/pythia-410m"
OUT_DIR = Path("/tmp/yuragi_probe_out")
OUT_DIR.mkdir(exist_ok=True)

PROMPTS = [
    ("factual", "The capital of France is", "What is the capital of France?"),
    ("opinion", "The best programming language is", "In your opinion, which programming language is best?"),
    ("hallu_prone", "The CEO of Microsoft in 1995 was", "Who was Microsoft CEO in 1995?"),
]


def entropy_from_logits(logits: torch.Tensor) -> float:
    """Shannon entropy (nats) over the next-token distribution at the last position."""
    probs = F.softmax(logits[-1], dim=-1)
    log_probs = torch.log(probs + 1e-12)
    return float(-(probs * log_probs).sum().item())


def layerwise_entropy(model, tokenizer, prompt: str) -> dict:
    """Run prompt through model, project each hidden state via unembed, return per-layer entropy.

    Critical: pythia (GPTNeoX) applies a final_layer_norm before the unembed in the
    real forward pass. HuggingFace returns hidden_states[-1] AFTER ln_f but intermediate
    hidden_states[0..-2] BEFORE ln_f. To do logit lens correctly we must apply ln_f to
    every intermediate hidden state before projecting through embed_out — otherwise the
    early layers will look uniform (entropy ≈ ln(vocab)) purely as an artifact of the
    embedding-space basis being misaligned with the unembed basis.
    """
    enc = tokenizer(prompt, return_tensors="pt")
    with torch.no_grad():
        out = model(**enc, output_hidden_states=True, use_cache=False)
    unembed = model.get_output_embeddings().weight  # [vocab, hidden]
    n_total = len(out.hidden_states)
    # Detect ln_f if available (pythia/GPTNeoX) — else fall back to identity
    ln_f = None
    if hasattr(model, "gpt_neox") and hasattr(model.gpt_neox, "final_layer_norm"):
        ln_f = model.gpt_neox.final_layer_norm
    elif hasattr(model, "transformer") and hasattr(model.transformer, "ln_f"):
        ln_f = model.transformer.ln_f
    layer_entropies = []
    for layer_idx, h in enumerate(out.hidden_states):
        last_hidden = h[0, -1, :]  # [hidden]
        # Apply ln_f to all intermediate layers; the final hidden_states[-1] is already
        # ln_f-applied per HuggingFace convention, so skip it for index n_total-1.
        if ln_f is not None and layer_idx < n_total - 1:
            last_hidden = ln_f(last_hidden.unsqueeze(0)).squeeze(0)
        layer_logits = last_hidden @ unembed.T  # [vocab]
        layer_entropies.append(entropy_from_logits(layer_logits.unsqueeze(0)))
    final_entropy = entropy_from_logits(out.logits[0])
    return {
        "layer_entropies": layer_entropies,
        "final_layer_entropy": final_entropy,
        "n_layers": n_total,
    }


def main():
    print(f"[{time.strftime('%H:%M:%S')}] loading {MODEL_NAME}...")
    t0 = time.time()
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, torch_dtype=torch.float32)
    model.eval()
    print(f"[{time.strftime('%H:%M:%S')}] loaded in {time.time()-t0:.1f}s")

    results = {}
    for label, baseline, perturbed in PROMPTS:
        print(f"\n[{time.strftime('%H:%M:%S')}] === {label} ===")
        print(f"  baseline: {baseline!r}")
        b = layerwise_entropy(model, tokenizer, baseline)
        print(f"  perturbed: {perturbed!r}")
        p = layerwise_entropy(model, tokenizer, perturbed)
        results[label] = {
            "baseline_prompt": baseline,
            "perturbed_prompt": perturbed,
            "baseline": b,
            "perturbed": p,
        }
        # Print key stats
        n = b["n_layers"]
        print(f"  layers: {n}")
        print(f"  baseline final entropy:  {b['final_layer_entropy']:.4f}")
        print(f"  perturbed final entropy: {p['final_layer_entropy']:.4f}")
        # Early layer drift
        early_drift = abs(np.array(b["layer_entropies"][:6]) - np.array(p["layer_entropies"][:6])).mean()
        late_drift = abs(np.array(b["layer_entropies"][-6:]) - np.array(p["layer_entropies"][-6:])).mean()
        print(f"  EARLY layers (0-5) mean entropy drift: {early_drift:.4f}")
        print(f"  LATE  layers (-6:) mean entropy drift: {late_drift:.4f}")
        print(f"  late/early ratio: {late_drift/max(early_drift,1e-6):.2f}")

    out_file = OUT_DIR / "results.json"
    with open(out_file, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\n[{time.strftime('%H:%M:%S')}] saved {out_file}")

    # Final summary
    print("\n=== SUMMARY ===")
    print(f"{'prompt':<14} {'early_drift':>14} {'late_drift':>14} {'ratio':>8}")
    for label, r in results.items():
        b, p = r["baseline"], r["perturbed"]
        early = float(abs(np.array(b["layer_entropies"][:6]) - np.array(p["layer_entropies"][:6])).mean())
        late = float(abs(np.array(b["layer_entropies"][-6:]) - np.array(p["layer_entropies"][-6:])).mean())
        ratio = late / max(early, 1e-6)
        print(f"{label:<14} {early:>14.4f} {late:>14.4f} {ratio:>8.2f}")
    print("\nIf ratio >> 1: late layers drift more than early — Wort-side instability supported.")
    print("If ratio ~~ 1 or < 1: no Sach-Wort separation in this small model.")


if __name__ == "__main__":
    main()
