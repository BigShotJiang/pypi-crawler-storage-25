"""Logit Lens probe — Sach/Wort hypothesis with paraphrase-controlled perturbations.

Bug 2 fix: all anchors within each set are semantic-preserving rewrites (completion-style
only), ensuring that entropy drift reflects concept-level variation rather than
syntactic/structural differences between prompts.

Design:
  - 5 anchor groups x 5 paraphrases = 25 total runs
  - Per group: C(5,2) = 10 pairwise entropy comparisons per layer
  - All prompts are completion-style ("X is ..." / "X was ..." / "X has ...") — no questions
  - ln_f applied to intermediate hidden states (GPTNeoX convention, same as probe.py)
  - Statistics: per-layer mean drift + std + bootstrap CI aggregated over all 50 pairs

CPU-only. Runtime: ~15-20 min on Ryzen 7735HS. Protect under __main__ guard for pytest.
"""

import itertools
import json
import random
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer

MODEL_NAME = "EleutherAI/pythia-410m"
OUT_DIR = Path("/tmp/yuragi_probe_paraphrase_out")
BOOTSTRAP_ITERS = 1000
RANDOM_SEED = 42

PARAPHRASE_SETS = [
    {
        "label": "factual_paris",
        "anchors": [
            "The capital of France is",
            "France's capital city is",
            "The capital city of France is",
            "France has its capital located in",
            "The main capital of France is",
        ],
        "expected_next": "Paris",
    },
    {
        "label": "factual_tokyo",
        "anchors": [
            "The capital of Japan is",
            "Japan's capital city is",
            "The capital city of Japan is",
            "Japan has its capital located in",
            "The main capital of Japan is",
        ],
        "expected_next": "Tokyo",
    },
    {
        "label": "factual_water",
        "anchors": [
            "The chemical formula for water is",
            "Water's chemical formula is",
            "The molecular formula of water is",
            "In chemistry, the formula for water is",
            "The composition formula of water is",
        ],
        "expected_next": "H",
    },
    {
        "label": "factual_einstein",
        "anchors": [
            "The scientist who developed the theory of relativity was",
            "The theory of relativity was developed by",
            "Albert Einstein's famous contribution to physics was",
            "The physicist behind the theory of relativity is known as",
            "The name of the scientist credited with relativity theory is",
        ],
        "expected_next": "Albert",
    },
    {
        "label": "factual_sun",
        "anchors": [
            "The center of our solar system is",
            "Our solar system revolves around",
            "The star at the center of our solar system is",
            "The central body of our solar system is",
            "At the center of our solar system sits",
        ],
        "expected_next": "the",
    },
]


def entropy_from_logits(logits: torch.Tensor) -> float:
    """Shannon entropy (nats) over the next-token distribution at the last position."""
    probs = F.softmax(logits[-1], dim=-1)
    log_probs = torch.log(probs + 1e-12)
    return float(-(probs * log_probs).sum().item())


def layerwise_entropy(model, tokenizer, prompt: str) -> dict:
    """Run prompt through model, project each hidden state via unembed, return per-layer entropy.

    Applies ln_f to intermediate hidden states (GPTNeoX/pythia convention).
    Hidden states from HuggingFace: index 0..n-2 are pre-ln_f, index n-1 is post-ln_f.
    """
    enc = tokenizer(prompt, return_tensors="pt")
    with torch.no_grad():
        out = model(**enc, output_hidden_states=True, use_cache=False)
    unembed = model.get_output_embeddings().weight  # [vocab, hidden]
    n_total = len(out.hidden_states)

    ln_f = None
    if hasattr(model, "gpt_neox") and hasattr(model.gpt_neox, "final_layer_norm"):
        ln_f = model.gpt_neox.final_layer_norm
    elif hasattr(model, "transformer") and hasattr(model.transformer, "ln_f"):
        ln_f = model.transformer.ln_f

    layer_entropies = []
    for layer_idx, h in enumerate(out.hidden_states):
        last_hidden = h[0, -1, :]  # [hidden]
        if ln_f is not None and layer_idx < n_total - 1:
            last_hidden = ln_f(last_hidden.unsqueeze(0)).squeeze(0)
        layer_logits = last_hidden @ unembed.T  # [vocab]
        layer_entropies.append(entropy_from_logits(layer_logits.unsqueeze(0)))

    final_entropy = entropy_from_logits(out.logits[0])
    return {
        "layer_entropies": layer_entropies,
        "final_layer_entropy": final_entropy,
        "n_layers": n_total,
    }


def bootstrap_ci(values: np.ndarray, n_iter: int = BOOTSTRAP_ITERS, ci: float = 0.95) -> tuple:
    """Bootstrap CI for the mean. Returns (lower, upper)."""
    rng = np.random.default_rng(RANDOM_SEED)
    means = [rng.choice(values, size=len(values), replace=True).mean() for _ in range(n_iter)]
    lo = (1.0 - ci) / 2.0
    return float(np.quantile(means, lo)), float(np.quantile(means, 1.0 - lo))


def compute_pairwise_drift(anchor_results: list[dict]) -> dict:
    """Compute per-layer pairwise entropy drift over all C(n,2) pairs.

    anchor_results: list of layerwise_entropy() outputs, one per anchor.
    Returns: {
        "per_layer_mean_drift": [...],
        "per_layer_std_drift": [...],
        "per_layer_ci_lo": [...],
        "per_layer_ci_hi": [...],
        "early_mean_drift": float,
        "late_mean_drift": float,
        "ratio_late_early": float,
        "n_pairs": int,
    }
    """
    n_layers = anchor_results[0]["n_layers"]
    pairs = list(itertools.combinations(range(len(anchor_results)), 2))
    # layer_drifts[l] = list of |entropy_i[l] - entropy_j[l]| over all pairs
    layer_drifts: list[list[float]] = [[] for _ in range(n_layers)]

    for i, j in pairs:
        e_i = np.array(anchor_results[i]["layer_entropies"])
        e_j = np.array(anchor_results[j]["layer_entropies"])
        drift = np.abs(e_i - e_j)
        for l in range(n_layers):
            layer_drifts[l].append(float(drift[l]))

    per_layer_mean = []
    per_layer_std = []
    per_layer_ci_lo = []
    per_layer_ci_hi = []
    for l in range(n_layers):
        arr = np.array(layer_drifts[l])
        per_layer_mean.append(float(arr.mean()))
        per_layer_std.append(float(arr.std()))
        lo, hi = bootstrap_ci(arr)
        per_layer_ci_lo.append(lo)
        per_layer_ci_hi.append(hi)

    early_6 = float(np.mean(per_layer_mean[:6]))
    late_6 = float(np.mean(per_layer_mean[-6:]))
    ratio = late_6 / max(early_6, 1e-6)

    return {
        "per_layer_mean_drift": per_layer_mean,
        "per_layer_std_drift": per_layer_std,
        "per_layer_ci_lo": per_layer_ci_lo,
        "per_layer_ci_hi": per_layer_ci_hi,
        "early_mean_drift": early_6,
        "late_mean_drift": late_6,
        "ratio_late_early": ratio,
        "n_pairs": len(pairs),
    }


def main():
    OUT_DIR.mkdir(exist_ok=True)
    print(f"[{time.strftime('%H:%M:%S')}] loading {MODEL_NAME}...")
    t0 = time.time()
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, torch_dtype=torch.float32)
    model.eval()
    print(f"[{time.strftime('%H:%M:%S')}] loaded in {time.time()-t0:.1f}s")

    results = {}
    all_group_stats = []

    for pset in PARAPHRASE_SETS:
        label = pset["label"]
        anchors = pset["anchors"]
        print(f"\n[{time.strftime('%H:%M:%S')}] === {label} ({len(anchors)} anchors) ===")

        anchor_results = []
        for i, anchor in enumerate(anchors):
            print(f"  [{i+1}/{len(anchors)}] {anchor!r}")
            r = layerwise_entropy(model, tokenizer, anchor)
            anchor_results.append(r)

        stats = compute_pairwise_drift(anchor_results)
        print(f"  pairs: {stats['n_pairs']}")
        print(f"  early_drift (layers 0-5): {stats['early_mean_drift']:.4f}")
        print(f"  late_drift  (layers -6:): {stats['late_mean_drift']:.4f}")
        print(f"  ratio late/early:         {stats['ratio_late_early']:.2f}")

        results[label] = {
            "anchors": anchors,
            "expected_next": pset["expected_next"],
            "anchor_entropies": anchor_results,
            "pairwise_stats": stats,
        }
        all_group_stats.append(stats)

    # Aggregate across all groups
    all_means = np.array([s["per_layer_mean_drift"] for s in all_group_stats])  # [n_groups, n_layers]
    agg_mean = all_means.mean(axis=0).tolist()
    agg_std = all_means.std(axis=0).tolist()

    global_early = float(np.mean([s["early_mean_drift"] for s in all_group_stats]))
    global_late = float(np.mean([s["late_mean_drift"] for s in all_group_stats]))
    global_ratio = global_late / max(global_early, 1e-6)

    aggregate = {
        "n_groups": len(PARAPHRASE_SETS),
        "paraphrases_per_group": len(PARAPHRASE_SETS[0]["anchors"]),
        "total_runs": sum(len(p["anchors"]) for p in PARAPHRASE_SETS),
        "total_pairs": sum(s["n_pairs"] for s in all_group_stats),
        "per_layer_agg_mean_drift": agg_mean,
        "per_layer_agg_std_drift": agg_std,
        "global_early_drift": global_early,
        "global_late_drift": global_late,
        "global_ratio_late_early": global_ratio,
    }
    results["_aggregate"] = aggregate

    out_file = OUT_DIR / "results_paraphrase.json"
    with open(out_file, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\n[{time.strftime('%H:%M:%S')}] saved {out_file}")

    print("\n=== AGGREGATE SUMMARY ===")
    print(f"total runs:  {aggregate['total_runs']}")
    print(f"total pairs: {aggregate['total_pairs']}")
    print(f"{'group':<22} {'early_drift':>12} {'late_drift':>12} {'ratio':>8}")
    for pset in PARAPHRASE_SETS:
        s = results[pset["label"]]["pairwise_stats"]
        print(f"{pset['label']:<22} {s['early_mean_drift']:>12.4f} {s['late_mean_drift']:>12.4f} {s['ratio_late_early']:>8.2f}")
    print(f"{'[global]':<22} {global_early:>12.4f} {global_late:>12.4f} {global_ratio:>8.2f}")
    print()
    if global_ratio > 2.0:
        print("ratio > 2.0: late-layer drift dominates — Wort-side instability tentatively supported.")
    elif global_ratio < 0.8:
        print("ratio < 0.8: early-layer drift dominates — results do not support Sach/Wort separation.")
    else:
        print("ratio in [0.8, 2.0]: inconclusive — no clear Sach/Wort separation at n=25.")
    print("NOTE: bootstrap CI and Wilcoxon test required for statistical claims. See NEXT_STEPS.md.")


if __name__ == "__main__":
    main()
