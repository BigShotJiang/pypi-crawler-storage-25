## Overview

<!-- Describe the changes in this PR. -->

## How to test

<!-- Steps to verify the changes work correctly. -->

```bash
# Example
pip install -e ".[dev]"
pytest tests/
```

## Checklist

- [ ] `ruff check .` passes
- [ ] `pytest` passes
- [ ] `bandit -r src/` passes
- [ ] Docs updated if needed
