# Contributing to yuragi

Thank you for your interest in contributing!

## Development setup

```bash
git clone https://github.com/hinanohart/yuragi.git
cd yuragi
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev,viz]"
pre-commit install
```

## Running tests

```bash
pytest tests/ -v
ruff check .
bandit -r src/yuragi -ll
```

## Adding a new perturbation type

1. Create `src/yuragi/perturbations/your_type.py` with a `generate_your_type(text, num_variants) -> list[str]` function
2. Register it in `src/yuragi/perturbations/__init__.py`
3. Add tests in `tests/test_perturbations.py`

## Adding a new confidence measurement method

1. Add the method to `src/yuragi/providers/adapter.py`
2. Update `detect_capabilities()` for any new model support

## Pull request guidelines

- Include tests for new features
- Run `ruff check .` and `bandit -r src/yuragi -ll` before submitting
- Keep PRs focused on a single change
