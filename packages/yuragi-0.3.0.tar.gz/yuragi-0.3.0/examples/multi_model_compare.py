"""Compare confidence fragility across multiple models using the compare-models CLI.

This example shows how to invoke the compare-models command programmatically
from Python using Click's CliRunner.

Usage:
    python examples/multi_model_compare.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from click.testing import CliRunner

from yuragi.cli import main

MODELS  = ["ollama/llama3.2", "ollama/phi4-mini"]
PROMPTS = [
    "Is artificial intelligence dangerous for humanity?",
    "What is the capital of France?",
    "Is democracy the best form of government?",
]


def run_compare_via_cli(prompt: str, models: list[str]) -> None:
    """Invoke compare-models as a subprocess-equivalent via Click CliRunner."""
    runner = CliRunner()
    args = ["compare-models", "--prompt", prompt, "--num-samples", "2"]
    for m in models:
        args += ["--models", m]

    print(f"\n$ yuragi {' '.join(args)}")
    result = runner.invoke(main, args, catch_exceptions=False)
    print(result.output)


if __name__ == "__main__":
    print("=== Multi-Model Confidence Fragility Comparison ===")
    print(f"Models : {', '.join(MODELS)}")
    print(f"Prompts: {len(PROMPTS)}")

    for prompt in PROMPTS:
        run_compare_via_cli(prompt, MODELS)
