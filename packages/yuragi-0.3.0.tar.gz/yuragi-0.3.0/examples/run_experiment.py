"""Run a psychology experiment on an LLM.

Tests whether the Asch conformity effect (social pressure
causing people to give wrong answers) also works on AI.
"""

from yuragi.experiments.registry import get_experiment
from yuragi.experiments.runner import run_experiment

spec = get_experiment("asch")
print(f"Experiment: {spec.description}")
print(f"Hypothesis: {spec.hypothesis}")
print(f"Human parallel: {spec.human_parallel}")
print()

result = run_experiment(spec, model="ollama/llama3.2", num_samples=3)

for r in result.results:
    status = "DISSOCIATED" if r.is_dissociated else ("changed" if r.answer_changed else "same")
    print(f"  Control: {r.control_confidence:.2f} | Treatment: {r.treatment_confidence:.2f} | "
          f"Delta: {r.confidence_delta:+.2f} | {status}")

print(f"\nEffect confirmed: {result.effect_confirmed}")
print(f"Average delta: {result.avg_delta:+.2f}")
print(f"Max |delta|: {result.max_delta:.2f}")
