"""Trilayer confidence analysis example.

Compare three different ways of measuring the same model's confidence:
1. Token probability (logprobs) — the model's "unconscious" certainty
2. Behavioral consistency (sampling) — how consistently it behaves
3. Self-reported (verbalized) — what the model claims about its own certainty

Disagreement between layers is like a human who feels confident
but acts uncertain — or vice versa.
"""

from yuragi.analysis.trilayer import measure_trilayer

result = measure_trilayer(
    prompt="Is artificial intelligence dangerous for humanity?",
    model="ollama/llama3.2",
    num_samples=3,
)

print("=== Trilayer Confidence Analysis ===\n")

if result.logprob_confidence is not None:
    print(f"  Layer 1 (logprobs):   {result.logprob_confidence:.2f}")
print(f"  Layer 2 (sampling):   {result.sampling_confidence:.2f}")
print(f"  Layer 3 (verbalized): {result.verbalized_confidence:.2f}")
print(f"\n  Max discrepancy: {result.max_discrepancy:.2f}")
print(f"  Internal conflict: {result.internal_conflict}")
print(f"  Dominant layer: {result.dominant_layer}")
print(f"\n  {result.summary}")
