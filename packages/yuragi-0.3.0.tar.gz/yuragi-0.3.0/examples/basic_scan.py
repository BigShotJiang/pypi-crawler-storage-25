"""Basic usage example: scan a prompt for confidence fragility."""

from yuragi import Scanner

# Use any litellm-supported model
# Local (free): "ollama/llama3.2"
# Cloud: "gpt-4o-mini", "groq/llama-3.1-8b-instant", "gemini/gemini-2.0-flash"
scanner = Scanner(model="ollama/llama3.2", num_samples=3)

result = scanner.scan("Is artificial intelligence dangerous for humanity?")

print(f"Fragility Score: {result.fragility_score:.2f} ({result.fragility_label()})")
print(f"Confidence Range: {result.confidence_range:.2f}")
print(f"Dissociation Rate: {result.dissociation_rate:.0%}")
print(f"Baseline Confidence: {result.baseline.confidence:.2f}")

if result.weakest_perturbation:
    w = result.weakest_perturbation
    print(f"\nWeakest point: '{w.perturbed_prompt[:60]}...'")
    print(f"  Delta: {w.confidence_delta:+.2f}")
    print(f"  Answer changed: {w.answer_changed}")
