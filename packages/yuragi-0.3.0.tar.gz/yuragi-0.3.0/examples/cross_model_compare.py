"""Compare confidence fragility across multiple models.

Requires at least ollama installed. For cloud models, set API keys.
"""

from yuragi import Scanner

models = [
    "ollama/llama3.2",
    # Add more models as available:
    # "groq/llama-3.1-8b-instant",
    # "gemini/gemini-2.0-flash",
    # "gpt-4o-mini",
]

prompt = "Will artificial intelligence surpass human intelligence?"

print(f'Prompt: "{prompt}"\n')
print(f"{'Model':<30} {'Fragility':>10} {'Range':>8} {'Dissoc':>8} {'Label':>10}")
print("-" * 70)

for model in models:
    try:
        scanner = Scanner(model=model, num_samples=3, num_variants=2)
        result = scanner.scan(prompt)
        print(
            f"{model:<30} {result.fragility_score:>10.3f} "
            f"{result.confidence_range:>8.3f} "
            f"{result.dissociation_rate:>7.0%} "
            f"{result.fragility_label():>10}"
        )
    except Exception as e:
        print(f"{model:<30} ERROR: {e}")
