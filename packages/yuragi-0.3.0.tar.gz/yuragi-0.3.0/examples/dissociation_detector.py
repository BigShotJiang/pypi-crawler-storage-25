"""Automatically detect Confidence Dissociation cases from a set of prompts.

Confidence Dissociation = the model gives the same answer but with drastically
different confidence when the prompt is perturbed.

Usage (real LLM):
    python examples/dissociation_detector.py

Usage (mock, no LLM required):
    YURAGI_MOCK=1 python examples/dissociation_detector.py

The script scans 10 prompts and prints all detected dissociation events.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

# Allow running from repo root without install
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

MODEL = os.environ.get("YURAGI_MODEL", "ollama/llama3.2")
MOCK  = os.environ.get("YURAGI_MOCK", "0") == "1"

PROMPTS = [
    "Is artificial intelligence dangerous for humanity?",
    "What is the boiling point of water at sea level?",
    "Is democracy the best form of government?",
    "What is the capital of France?",
    "Should we trust machine learning models in medicine?",
    "What is 17 x 13?",
    "Is climate change caused by human activity?",
    "Who wrote Hamlet?",
    "Is Python a good language for data science?",
    "What is the speed of light?",
]

DISSOCIATION_THRESHOLD = 0.3  # |Δconfidence| to flag as dissociation


def run_mock() -> None:
    """Run with synthetic data — no LLM required."""
    import random

    random.seed(42)
    print(f"[MOCK MODE] Simulating dissociation detection over {len(PROMPTS)} prompts\n")

    dissociated = []
    for prompt in PROMPTS:
        baseline_conf = random.uniform(0.6, 0.95)
        perturbed_conf = random.uniform(0.1, 0.95)
        delta = abs(baseline_conf - perturbed_conf)
        answer_same = random.random() > 0.15

        if answer_same and delta >= DISSOCIATION_THRESHOLD:
            dissociated.append({
                "prompt": prompt,
                "baseline_confidence": baseline_conf,
                "perturbed_confidence": perturbed_conf,
                "delta": delta,
                "answer_changed": not answer_same,
            })

    _print_results(dissociated, total=len(PROMPTS))


def run_real() -> None:
    """Run with a real LLM via yuragi Scanner."""
    from yuragi import Scanner

    scanner = Scanner(model=MODEL, num_samples=3, num_variants=2)
    print(f"Model: {MODEL}")
    print(f"Dissociation threshold: |Δconfidence| >= {DISSOCIATION_THRESHOLD}")
    print(f"Scanning {len(PROMPTS)} prompts...\n")

    dissociated = []
    for i, prompt in enumerate(PROMPTS, 1):
        print(f"  [{i}/{len(PROMPTS)}] {prompt[:60]}...")
        result = scanner.scan(prompt)

        for pr in result.perturbation_results:
            if pr.is_dissociated or (not pr.answer_changed and abs(pr.confidence_delta) >= DISSOCIATION_THRESHOLD):
                dissociated.append({
                    "prompt": prompt,
                    "perturbation": pr.perturbation_type,
                    "baseline_confidence": result.baseline.confidence,
                    "perturbed_confidence": pr.perturbed_response.confidence,
                    "delta": abs(pr.confidence_delta),
                    "answer_changed": pr.answer_changed,
                })

    _print_results(dissociated, total=len(PROMPTS))


def _print_results(events: list[dict], total: int) -> None:
    print(f"\n{'=' * 60}")
    print(f"DISSOCIATION EVENTS DETECTED: {len(events)} / {total} prompts")
    print("=" * 60)

    if not events:
        print("No dissociation detected above threshold.")
        return

    for ev in events:
        print(f"\nPrompt   : {ev['prompt'][:70]}")
        if "perturbation" in ev:
            print(f"Perturb  : {ev['perturbation']}")
        print(f"Baseline : {ev['baseline_confidence']:.3f}")
        print(f"Perturbed: {ev['perturbed_confidence']:.3f}")
        print(f"|Delta|  : {ev['delta']:.3f}  ({'DISSOCIATION' if not ev['answer_changed'] else 'answer changed'})")

    dissociation_rate = len(events) / total
    print(f"\nDissociation rate: {dissociation_rate:.0%}")


if __name__ == "__main__":
    if MOCK:
        run_mock()
    else:
        run_real()
