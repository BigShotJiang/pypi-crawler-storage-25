"""Test-Time Compute Fragility experiment demo.

Compares confidence with and without explicit chain-of-thought reasoning.
Hypothesis (Don't Think Twice, ICLR 2025): more reasoning → higher
overconfidence even when accuracy stays constant.

Usage (real LLM):
    python examples/test_time_compute_demo.py

Usage (mock, no LLM required):
    YURAGI_MOCK=1 python examples/test_time_compute_demo.py
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

MODEL = os.environ.get("YURAGI_MODEL", "ollama/llama3.2")
MOCK  = os.environ.get("YURAGI_MOCK", "0") == "1"

QUESTIONS = [
    {"question": "What is 17 multiplied by 13?", "answers": ["221"]},
    {"question": "What is the capital of Australia?", "answers": ["canberra"]},
    {"question": "Is a whale a mammal?", "answers": ["yes", "mammal"]},
    {"question": "Who wrote 'Pride and Prejudice'?", "answers": ["austen", "jane"]},
    {"question": "What is the square root of 144?", "answers": ["12"]},
]


def run_mock() -> None:
    """Simulate test-time compute result without a real LLM."""
    from yuragi.experiments.test_time_compute import TestTimeComputeResult

    result = TestTimeComputeResult(
        no_reasoning_confidence=0.72,
        no_reasoning_accuracy=0.80,
        with_reasoning_confidence=0.91,
        with_reasoning_accuracy=0.82,
        confidence_delta=0.19,
        accuracy_delta=0.02,
        overconfidence_amplified=True,
    )
    _print_result(result)


def run_real() -> None:
    """Run the test-time compute experiment with a real LLM."""
    from yuragi.experiments.test_time_compute import run_test_time_compute
    from yuragi.providers.adapter import LLMAdapter

    print(f"Model    : {MODEL}")
    print(f"Questions: {len(QUESTIONS)}")
    print("Running experiment (with and without chain-of-thought)...\n")

    with LLMAdapter(model=MODEL) as adapter:
        result = run_test_time_compute(adapter, QUESTIONS)

    _print_result(result)


def _print_result(result) -> None:
    print("=" * 50)
    print("TEST-TIME COMPUTE FRAGILITY RESULTS")
    print("=" * 50)
    print(f"\n{'Condition':<20} {'Confidence':>12} {'Accuracy':>10}")
    print("-" * 44)
    print(f"{'No reasoning':<20} {result.no_reasoning_confidence:>12.3f} {result.no_reasoning_accuracy:>10.3f}")
    print(f"{'With CoT':<20} {result.with_reasoning_confidence:>12.3f} {result.with_reasoning_accuracy:>10.3f}")
    print(f"{'Delta':<20} {result.confidence_delta:>+12.3f} {result.accuracy_delta:>+10.3f}")
    print(f"\nOverconfidence amplified: {result.overconfidence_amplified}")
    if result.overconfidence_amplified:
        print("  Chain-of-thought reasoning increased confidence without")
        print("  proportional accuracy improvement — overconfidence amplification.")


if __name__ == "__main__":
    print("=== Test-Time Compute Fragility Demo (yuragi) ===\n")
    if MOCK:
        print("[MOCK MODE] Using synthetic data\n")
        run_mock()
    else:
        run_real()
