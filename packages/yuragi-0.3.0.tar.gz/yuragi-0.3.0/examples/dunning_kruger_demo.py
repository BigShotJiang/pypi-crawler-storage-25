"""Dunning-Kruger Effect experiment demo.

Tests whether an LLM is overconfident on easy questions and underconfident
on hard questions — the hallmark of the Dunning-Kruger Effect.

Usage (real LLM):
    python examples/dunning_kruger_demo.py

Usage (mock, no LLM required):
    YURAGI_MOCK=1 python examples/dunning_kruger_demo.py
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

MODEL = os.environ.get("YURAGI_MODEL", "ollama/llama3.2")
MOCK  = os.environ.get("YURAGI_MOCK", "0") == "1"


def run_mock() -> None:
    """Simulate DKE result without a real LLM."""
    from yuragi.experiments.dunning_kruger import DunningKrugerResult

    result = DunningKrugerResult(
        easy_confidence=0.92,
        easy_accuracy=0.80,
        medium_confidence=0.74,
        medium_accuracy=0.72,
        hard_confidence=0.45,
        hard_accuracy=0.55,
        dke_score=0.24,
        dke_detected=True,
    )
    _print_result(result)


def run_real() -> None:
    """Run the Dunning-Kruger experiment with a real LLM."""
    from yuragi.experiments.dunning_kruger import run_dunning_kruger
    from yuragi.providers.adapter import LLMAdapter

    print(f"Model: {MODEL}")
    print("Running Dunning-Kruger experiment (3 difficulty tiers)...\n")

    with LLMAdapter(model=MODEL) as adapter:
        result = run_dunning_kruger(adapter)

    _print_result(result)


def _print_result(result) -> None:
    print("=" * 50)
    print("DUNNING-KRUGER EXPERIMENT RESULTS")
    print("=" * 50)
    print(f"\n{'Tier':<10} {'Confidence':>12} {'Accuracy':>10} {'Gap':>8}")
    print("-" * 44)

    for tier, conf, acc in [
        ("Easy",   result.easy_confidence,   result.easy_accuracy),
        ("Medium", result.medium_confidence, result.medium_accuracy),
        ("Hard",   result.hard_confidence,   result.hard_accuracy),
    ]:
        gap = conf - acc
        sign = "+" if gap >= 0 else ""
        print(f"{tier:<10} {conf:>12.3f} {acc:>10.3f} {sign}{gap:>7.3f}")

    print(f"\nDKE Score  : {result.dke_score:+.3f}")
    print(f"DKE Detected: {result.dke_detected}")

    if result.dke_detected:
        print("\nInterpretation: Model shows classic Dunning-Kruger pattern.")
        print("  Overconfident on easy tasks, underconfident on hard tasks.")
    else:
        print("\nInterpretation: No clear Dunning-Kruger pattern detected.")


if __name__ == "__main__":
    print("=== Dunning-Kruger Effect Demo (yuragi) ===\n")
    if MOCK:
        print("[MOCK MODE] Using synthetic data\n")
        run_mock()
    else:
        run_real()
