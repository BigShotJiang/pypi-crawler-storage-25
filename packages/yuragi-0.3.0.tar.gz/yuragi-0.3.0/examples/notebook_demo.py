"""Jupyter-style demo script (can be converted to .ipynb with jupytext).

Demonstrates yuragi in a notebook-friendly format with inline visualizations.
Run with: python examples/notebook_demo.py
Or convert: jupytext --to notebook examples/notebook_demo.py
"""

# %% [markdown]
# # yuragi Demo — LLM Confidence Fragility Analysis
#
# This notebook demonstrates how to measure and visualize
# confidence fragility in language models.

# %% Setup
from yuragi import Scanner, Perturbation

MODEL = "ollama/llama3.2"
PROMPT = "Will artificial intelligence surpass human intelligence?"

# %% Basic Scan
print("=== Basic Fragility Scan ===\n")
scanner = Scanner(model=MODEL, num_samples=3, num_variants=2)
result = scanner.scan(PROMPT)

print(f"Prompt: {PROMPT}")
print(f"Baseline confidence: {result.baseline.confidence:.2f}")
print(f"Fragility Score: {result.fragility_score:.2f} ({result.fragility_label()})")
print(f"Dissociation Rate: {result.dissociation_rate:.0%}")
print(f"Confidence Range: {result.confidence_range:.2f}")

# %% Perturbation Details
print("\n=== Perturbation Results ===\n")
for r in sorted(result.perturbation_results, key=lambda x: x.confidence_delta):
    status = "DISSOC" if r.is_dissociated else ("changed" if r.answer_changed else "same")
    print(
        f"  [{r.perturbation_type:12s}] "
        f"conf={r.perturbed_response.confidence:.2f} "
        f"delta={r.confidence_delta:+.2f} "
        f"({status})"
    )

# %% Statistical Analysis
print("\n=== Statistical Analysis ===\n")
from yuragi.analysis.statistics import analyze

report = analyze(result)
print(f"Cohen's d: {report.cohens_d:.3f} ({report.effect_size_label})")
print(f"95% CI: [{report.ci_lower:+.3f}, {report.ci_upper:+.3f}]")

# %% Fragility Profile
print("\n=== Fragility Profile ===\n")
from yuragi.analysis.fragility_profile import build_profile

fp = build_profile(result)
print(f"Catastrophic Collapse Index: {fp.catastrophic_collapse_index:.3f}")
print(f"Recovery Elasticity: {fp.recovery_elasticity:.3f}")
print(f"Non-linearity Score: {fp.non_linearity_score:.3f}")
print(f"Profile: {fp.profile_label}")

# %% Linguistic Analysis
print("\n=== Linguistic Confidence ===\n")
from yuragi.analysis.linguistics import analyze_text

ling = analyze_text(result.baseline.text, result.baseline.confidence)
print(f"Hedge words found: {ling.hedge_count} ({ling.hedge_density:.1%})")
print(f"Assertions found: {ling.assertion_count} ({ling.assertion_density:.1%})")
print(f"Linguistic confidence: {ling.linguistic_confidence:.2f}")
print(f"Numerical confidence: {ling.numerical_confidence:.2f}")
print(f"Gap: {ling.confidence_gap:+.2f}")
if ling.is_overexpressing:
    print("Model uses confident language despite low numerical confidence")
if ling.is_underexpressing:
    print("Model hedges despite high numerical confidence")

# %% Visualization (matplotlib)
print("\n=== Generating Visualizations ===\n")
try:
    from yuragi.visualize.heatmap import plot_sensitivity_heatmap

    plot_sensitivity_heatmap(result, save_path="output/demo_heatmap.png")
    print("Heatmap saved to output/demo_heatmap.png")
except ImportError:
    print("Install matplotlib for visualizations: pip install yuragi[viz]")

# %% HTML Report
from yuragi.visualize.html_report import generate_html_report
from pathlib import Path

Path("output").mkdir(exist_ok=True)
generate_html_report(result, "output/demo_report.html")
print("HTML report saved to output/demo_report.html")

# %% [markdown]
# ## Key Insight
#
# The fragility score tells you how much your AI's confidence
# can be shaken by small prompt changes. A high score means
# the model's certainty is unreliable — it changes its mind
# for no good reason, just like humans do.
