"""Find the smallest possible edit that collapses AI confidence.

This is yuragi's algorithmic killer feature: gradient-free
optimization over discrete text space to find the most
efficient confidence-destroying edit.
"""

from yuragi.analysis.minimal_edit import find_minimal_edit

result = find_minimal_edit(
    prompt="Explain the theory of relativity in simple terms",
    model="ollama/llama3.2",
    num_samples=3,
)

if result:
    print(f"Original confidence: {result.original_confidence:.2f}")
    print(f"Edited confidence:   {result.edited_confidence:.2f}")
    print(f"Delta:               {result.confidence_delta:+.2f}")
    print(f"Edit type:           {result.edit_type}")
    print(f"Edit description:    {result.edit_description}")
    print(f"Edit distance:       {result.edit_distance} chars")
    print(f"Efficiency:          {result.efficiency:.3f} (impact/char)")
    print(f"\nOriginal: {result.original_prompt}")
    print(f"Edited:   {result.edited_prompt}")
else:
    print("No significant confidence shift found.")
