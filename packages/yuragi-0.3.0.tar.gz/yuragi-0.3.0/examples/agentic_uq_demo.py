"""Agentic UQ (Uncertainty Quantification) trajectory demo.

Records how model confidence evolves across multi-step tool-use sessions.
Useful for understanding when agents become overconfident or helpless during
complex workflows.

Usage (real LLM):
    python examples/agentic_uq_demo.py

Usage (mock, no LLM required):
    YURAGI_MOCK=1 python examples/agentic_uq_demo.py
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

MODEL = os.environ.get("YURAGI_MODEL", "ollama/llama3.2")
MOCK  = os.environ.get("YURAGI_MOCK", "0") == "1"

TOOLS = [
    {"name": "search_web", "description": "Search the web for information"},
    {"name": "calculator",  "description": "Perform arithmetic calculations"},
    {"name": "read_file",   "description": "Read contents of a file"},
]

INITIAL_PROMPT = (
    "Research the current inflation rate in Japan, calculate its compound effect "
    "over 5 years at 2.5%, and summarize the findings."
)


def run_mock() -> None:
    """Simulate agentic trajectory without a real LLM."""
    from yuragi.analysis.agentic_uq import AgenticStep, AgenticTrajectory

    steps = [
        AgenticStep(0, "search_web",  confidence_before=0.82, confidence_after=0.76, confidence_delta=-0.06),
        AgenticStep(1, "calculator",  confidence_before=0.76, confidence_after=0.71, confidence_delta=-0.05),
        AgenticStep(2, None,          confidence_before=0.71, confidence_after=0.65, confidence_delta=-0.06),
    ]
    trajectory = AgenticTrajectory(
        steps=steps,
        total_steps=3,
        monotone_decline=True,
        max_drop=0.17,
        final_confidence=0.65,
        fragility_score=0.38,
    )
    _print_trajectory(trajectory)


def run_real() -> None:
    """Run agentic UQ with a real LLM."""
    from yuragi.analysis.agentic_uq import track_agentic_session
    from yuragi.providers.adapter import LLMAdapter

    print(f"Model : {MODEL}")
    print(f"Tools : {[t['name'] for t in TOOLS]}")
    print(f"Task  : {INITIAL_PROMPT[:80]}...\n")

    with LLMAdapter(model=MODEL) as adapter:
        trajectory = track_agentic_session(
            adapter=adapter,
            initial_prompt=INITIAL_PROMPT,
            tools=TOOLS,
            max_steps=5,
        )

    _print_trajectory(trajectory)


def _print_trajectory(trajectory) -> None:
    print("=" * 55)
    print("AGENTIC UQ TRAJECTORY")
    print("=" * 55)
    print(f"\n{'Step':<6} {'Tool':<16} {'Before':>8} {'After':>8} {'Delta':>8}")
    print("-" * 50)

    for step in trajectory.steps:
        tool = step.tool_called or "(no tool)"
        delta_str = f"{step.confidence_delta:+.3f}"
        print(f"{step.step_index:<6} {tool:<16} {step.confidence_before:>8.3f} "
              f"{step.confidence_after:>8.3f} {delta_str:>8}")

    print(f"\nTotal steps       : {trajectory.total_steps}")
    print(f"Final confidence  : {trajectory.final_confidence:.3f}")
    print(f"Max drop          : {trajectory.max_drop:.3f}")
    print(f"Monotone decline  : {trajectory.monotone_decline}")
    print(f"Fragility score   : {trajectory.fragility_score:.3f}")


if __name__ == "__main__":
    print("=== Agentic UQ Trajectory Demo (yuragi) ===\n")
    if MOCK:
        print("[MOCK MODE] Using synthetic data\n")
        run_mock()
    else:
        run_real()
