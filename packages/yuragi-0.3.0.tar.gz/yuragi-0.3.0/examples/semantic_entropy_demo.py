"""Semantic Entropy calculation demo.

Semantic Entropy (Farquhar et al., Nature 2024) measures uncertainty by
clustering multiple generations semantically and computing entropy over clusters.
High entropy → high hallucination risk.

Usage (real LLM):
    python examples/semantic_entropy_demo.py

Usage (mock, no LLM required):
    YURAGI_MOCK=1 python examples/semantic_entropy_demo.py
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

MODEL = os.environ.get("YURAGI_MODEL", "ollama/llama3.2")
MOCK  = os.environ.get("YURAGI_MOCK", "0") == "1"

PROMPTS = [
    {
        "question": "What is the capital of France?",
        "description": "Low entropy expected (factual, single answer)",
    },
    {
        "question": "What is the best programming language for data science?",
        "description": "High entropy expected (opinion, many valid answers)",
    },
    {
        "question": "What is 2 + 2?",
        "description": "Very low entropy expected (trivial math)",
    },
]

MOCK_SAMPLES = {
    "What is the capital of France?": ["Paris", "Paris is the capital.", "The capital is Paris.", "Paris, France."],
    "What is the best programming language for data science?": [
        "Python", "R is the best for statistics.", "Julia is fastest.", "Python, definitely.",
    ],
    "What is 2 + 2?": ["4", "Four", "2+2=4", "The answer is 4."],
}


def run_mock() -> None:
    """Compute semantic entropy from hardcoded samples."""
    from yuragi.metrics.semantic_entropy import semantic_entropy

    print("[MOCK MODE] Using pre-defined samples\n")
    _run_entropy_over(MOCK_SAMPLES)


def run_real() -> None:
    """Generate samples from a real LLM and compute entropy."""
    from yuragi.metrics.semantic_entropy import semantic_entropy
    from yuragi.providers.adapter import LLMAdapter

    print(f"Model: {MODEL}\n")

    with LLMAdapter(model=MODEL) as adapter:
        for entry in PROMPTS:
            question = entry["question"]
            description = entry["description"]
            print(f"Question: {question}")
            print(f"  ({description})")

            samples = []
            for _ in range(5):
                resp = adapter.complete(question)
                samples.append(resp.text)

            from yuragi.metrics.semantic_entropy import semantic_entropy
            entropy = semantic_entropy(samples)
            print(f"  Samples: {samples[:3]}...")
            print(f"  Semantic Entropy: {entropy:.4f} nats")
            print()


def _run_entropy_over(samples_dict: dict[str, list[str]]) -> None:
    from yuragi.metrics.semantic_entropy import semantic_entropy

    for entry in PROMPTS:
        question = entry["question"]
        description = entry["description"]
        samples = samples_dict[question]

        entropy = semantic_entropy(samples)
        print(f"Question: {question}")
        print(f"  ({description})")
        print(f"  Samples: {samples[:3]}")
        print(f"  Semantic Entropy: {entropy:.4f} nats")
        print()


if __name__ == "__main__":
    print("=== Semantic Entropy Demo (yuragi) ===\n")
    if MOCK:
        run_mock()
    else:
        run_real()
