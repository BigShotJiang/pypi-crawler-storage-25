"""Full analysis pipeline example.

Demonstrates all of yuragi's analysis capabilities in one script:
1. Basic scan with all perturbation types
2. Statistical analysis with Cohen's d and bootstrap CI
3. Fragility profile (CCI, Recovery Elasticity, Non-linearity)
4. HTML report export
5. Heatmap visualization
"""

from pathlib import Path

from yuragi import Scanner
from yuragi.analysis.fragility_profile import build_profile
from yuragi.analysis.statistics import analyze

# Configure
MODEL = "ollama/llama3.2"  # Change to your preferred model
PROMPT = "Is artificial intelligence dangerous for humanity?"
OUTPUT_DIR = Path("output")
OUTPUT_DIR.mkdir(exist_ok=True)

print(f"Model: {MODEL}")
print(f"Prompt: {PROMPT}\n")

# 1. Full scan
print("=== Step 1: Full Fragility Scan ===")
scanner = Scanner(model=MODEL, num_samples=3, num_variants=2, verbose=True)
result = scanner.scan(PROMPT)

print(f"\nFragility Score: {result.fragility_score:.3f} ({result.fragility_label()})")
print(f"Confidence Range: {result.confidence_range:.3f}")
print(f"Dissociation Rate: {result.dissociation_rate:.0%}")
print(f"Baseline Confidence: {result.baseline.confidence:.3f}")
print(f"Perturbations tested: {len(result.perturbation_results)}")

# 2. Statistical analysis
print("\n=== Step 2: Statistical Analysis ===")
report = analyze(result)
print(f"Cohen's d: {report.cohens_d:.3f} ({report.effect_size_label})")
print(f"95% CI: [{report.ci_lower:+.3f}, {report.ci_upper:+.3f}]")
print(f"Coefficient of Variation: {report.coefficient_of_variation:.3f}")
print(f"IQR: {report.interquartile_range:.3f}")

# 3. Fragility profile
print("\n=== Step 3: Fragility Profile ===")
fp = build_profile(result)
print(f"Catastrophic Collapse Index: {fp.catastrophic_collapse_index:.3f}")
print(f"Recovery Elasticity: {fp.recovery_elasticity:.3f}")
print(f"Non-linearity Score: {fp.non_linearity_score:.3f}")
print(f"Profile: {fp.profile_label}")
if fp.collapse_trigger:
    print(f"Collapse trigger: '{fp.collapse_trigger[:60]}...' (delta: {fp.collapse_trigger_delta:+.3f})")
if fp.recovery_trigger:
    print(f"Recovery trigger: '{fp.recovery_trigger[:60]}...' (delta: {fp.recovery_trigger_delta:+.3f})")

# 4. HTML report
print("\n=== Step 4: Exports ===")
from yuragi.visualize.html_report import generate_html_report

html_path = str(OUTPUT_DIR / "report.html")
generate_html_report(result, html_path)
print(f"HTML report: {html_path}")

# 5. Heatmap
try:
    from yuragi.visualize.heatmap import plot_sensitivity_heatmap

    heatmap_path = str(OUTPUT_DIR / "heatmap.png")
    plot_sensitivity_heatmap(result, save_path=heatmap_path)
    print(f"Heatmap: {heatmap_path}")
except ImportError:
    print("(matplotlib not installed, skipping heatmap)")

print("\nDone!")
