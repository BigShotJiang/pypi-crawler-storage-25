# Examples

These examples demonstrate yuragi's capabilities. All examples work with local models (no API key needed).

## Prerequisites

```bash
pip install yuragi[all]
ollama pull llama3.2  # Free local model
```

## Examples

| File | Description |
|------|-------------|
| `basic_scan.py` | Basic fragility scan with result inspection |
| `run_experiment.py` | Run Asch conformity experiment on a model |
| `cross_model_compare.py` | Compare fragility across multiple models |
| `minimal_edit_search.py` | Find the smallest edit that breaks confidence |
| `trilayer_analysis.py` | Compare 3 confidence measurement layers |
| `full_analysis.py` | Complete analysis pipeline (scan + stats + profile + export) |

## Running

```bash
cd examples
python basic_scan.py
python run_experiment.py
python full_analysis.py  # Generates output/ directory with reports
```

## Using different models

Replace `"ollama/llama3.2"` with any litellm-supported model:

```python
# Local (free)
scanner = Scanner(model="ollama/llama3.2")
scanner = Scanner(model="ollama/mistral")

# Cloud (API key required)
scanner = Scanner(model="gpt-4o-mini")
scanner = Scanner(model="groq/llama-3.1-8b-instant")
scanner = Scanner(model="gemini/gemini-2.0-flash")
```
