from .init_imports import *
from .exts import *
from .constants import *
# ---------------------------------------------------------------------------
# 1. SITE CONFIG — explicit environment, no smart defaults
# ---------------------------------------------------------------------------

@dataclass
class SiteConfig:
    """All environment-specific values live here. Nothing is inferred."""
    site_name: str
    domain: str
    base_url: str
    site_root: str          # https://thedailydialectics.com
    media_root: str         # /srv/media/thedailydialectics
    output_root: str        # where to write generated files (usually same as media_root)
    pdfs_dir: str
    imgs_dir: str
    videos_dir: str
    home_label:str = "TDD"
    skip_dirs: set = field(default_factory=lambda: {
        "text", "pages", "images", "thumbnails", "pdf_pages", "meta",
        "preprocessed_images", "preprocessed_text",
        "node_modules", ".git", "__pycache__",
    })
    image_exts: tuple = tuple(get_image_exts())
    video_exts: tuple = tuple(get_video_exts())
    max_sitemap_urls: int = 50000


def make_tdd_config():
    """Factory for The Daily Dialectics config."""
    media_root = ROOT_URL
    return SiteConfig(
        base_url=ROOT_URL,
        site_name=SITE_NAME,
        domain=SITE_NAME,
        site_root=ROOT_URL,
        media_root=MEDIA_DIR,
        output_root=MEDIA_DIR,
        pdfs_dir=PDFS_DIR,
        imgs_dir=IMGS_DIR,
        videos_dir=VIDEOS_DIR,
    )
