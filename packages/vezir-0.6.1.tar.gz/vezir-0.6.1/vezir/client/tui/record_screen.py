"""Record screen: start/stop/pause/resume + upload.

Calls into ``meet_record.capture`` directly (the library exposes
``pause()`` / ``resume()`` as of millet-record 0.3.0; we verified
this in the spike at the start of the v0.2.0-tui work).  No subprocess
invocation of ``millet record`` -- that path doesn't expose pause.

State machine (mirrors RecordingState in gui.py):

  idle      no recording in flight
  recording RecordingSession is active and not paused
  paused    RecordingSession.pause() was called; can resume or stop
  draining  user pressed stop; ffmpeg/sidecar flushing remaining samples
  compressing WAV -> OGG re-encoding (only when --compress)
  uploading multipart upload in flight
  queued    server acknowledged upload
  done      server reached terminal status (also: needs_labeling, error)

The screen does work() chains:

  * ``_record_worker`` -- builds a RecordingSession, calls .start(),
    yields each second to update the timer label until stopped.
  * ``_upload_worker`` -- compresses (optionally) then uploads via
    vezir.client.uploader.upload(), reporting progress as a posted
    message back to the screen.
  * ``_poll_worker`` -- after upload, polls /api/sessions/{id} until
    terminal status, surfacing transitions in the status bar.

Worker threads (Textual @work(thread=True)) are used everywhere
blocking I/O happens so the event loop stays responsive.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path

from textual import work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.message import Message
from textual.reactive import reactive
from textual.screen import ModalScreen
from textual.widgets import (
    Button,
    DirectoryTree,
    Input,
    Label,
    Select,
    Static,
)

from .. import config as _client_config_mod
from ..config import load_client_prefs, save_client_prefs


def _vezir_version() -> str:
    """Return the running vezir client version (lazy to avoid import cycles)."""
    try:
        from vezir import __version__
        return __version__
    except Exception:
        return "?"

log = logging.getLogger("vezir.client.tui.record")


_PRESET_OPTIONS = [
    ("High Quality", "high-quality"),
    ("Confidential", "confidential"),
    ("Alternative", "alternative"),
]


def _fmt_elapsed(seconds: float) -> str:
    s = int(seconds)
    return f"{s // 3600:02d}:{(s % 3600) // 60:02d}:{s % 60:02d}"


def _fmt_bytes(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f} KB"
    if n < 1024 * 1024 * 1024:
        return f"{n / (1024 * 1024):.1f} MB"
    return f"{n / (1024 * 1024 * 1024):.1f} GB"


# ─── Messages posted from workers back to the screen ─────────────────────────


@dataclass
class TimerTick(Message):
    elapsed: float
    bytes: int
    paused: bool


@dataclass
class RecorderFailed(Message):
    reason: str


@dataclass
class RecorderFinished(Message):
    audio_path: Path


@dataclass
class UploadProgress(Message):
    sent: int
    total: int
    rate: float


@dataclass
class UploadFinished(Message):
    session_id: str
    dashboard_url: str | None


@dataclass
class UploadFailed(Message):
    error: str
    audio_path: Path | None


@dataclass
class ServerStatus(Message):
    status: str
    extra: str = ""


@dataclass
class SessionUploadComplete(Message):
    """Posted by ``_poll_worker`` when the server reaches a terminal
    status for a freshly uploaded session.  Bubbles up to MainScreen
    so it can refresh the Sessions tab and toast the user.

    Background: PR9 (2026-05-24) — user reported that a session
    recorded in the TUI didn't appear in the Sessions list until the
    TUI was restarted.  Root cause: SessionsBody only refreshed on
    its own ``on_mount``, never reacting to upload completion.
    """
    session_id: str
    status: str  # "done" | "error" | "needs_labeling"


# ─── Import file picker (v0.5.0+) ───────────────────────────────────────────


_AUDIO_EXTS = {".wav", ".ogg"}


class _AudioOnlyDirectoryTree(DirectoryTree):
    """DirectoryTree that hides non-audio non-directory entries.

    Shows directories so the user can navigate; filters files to
    .wav and .ogg only so the picker is uncluttered.  Hidden files
    (dot-prefixed) are also hidden, which matches typical OS file
    pickers and prevents the tree from being dominated by .cache /
    .config / .git noise.
    """

    def filter_paths(self, paths):  # type: ignore[override]
        out = []
        for p in paths:
            try:
                name = p.name
            except Exception:
                continue
            if name.startswith("."):
                continue
            if p.is_dir():
                out.append(p)
                continue
            if p.suffix.lower() in _AUDIO_EXTS:
                out.append(p)
        return out


class ImportScreen(ModalScreen["Path | None"]):
    """Modal file picker for selecting an audio file (.wav/.ogg) to upload.

    Dismisses with the selected ``Path`` on confirmation, or ``None`` on
    cancel.  Validation: only `.wav` and `.ogg` are accepted; invalid
    selections keep the modal open with an inline hint.
    """

    DEFAULT_CSS = """
    ImportScreen {
        align: center middle;
    }
    #picker-box {
        width: 80%;
        height: 80%;
        border: round $primary;
        padding: 1 2;
        background: $surface;
    }
    #picker-title {
        height: 1;
        margin-bottom: 1;
        text-style: bold;
    }
    #picker-tree {
        height: 1fr;
    }
    #picker-hint {
        height: 1;
        margin-top: 1;
        color: $text-muted;
    }
    #picker-hint.error {
        color: $error;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
        Binding("enter", "select", "Select"),
    ]

    def __init__(self, start_path: Path) -> None:
        super().__init__()
        self._start_path = start_path

    def compose(self) -> ComposeResult:
        with Vertical(id="picker-box"):
            yield Static(
                "Import audio file (.wav or .ogg)  —  Enter: select  ·  Esc: cancel",
                id="picker-title",
            )
            yield _AudioOnlyDirectoryTree(str(self._start_path), id="picker-tree")
            yield Static("", id="picker-hint")

    def on_directory_tree_file_selected(
        self, event: DirectoryTree.FileSelected
    ) -> None:
        path = Path(event.path)
        if path.suffix.lower() not in _AUDIO_EXTS:
            hint = self.query_one("#picker-hint", Static)
            hint.add_class("error")
            hint.update(
                f"unsupported file type {path.suffix or '(none)'}; "
                f"expected .wav or .ogg"
            )
            return
        self.dismiss(path)

    def action_cancel(self) -> None:
        self.dismiss(None)

    def action_select(self) -> None:
        """Triggered by Enter; treats the cursor node as the selection."""
        try:
            tree = self.query_one("#picker-tree", _AudioOnlyDirectoryTree)
        except Exception:
            return
        node = tree.cursor_node
        if node is None or node.data is None:
            return
        path = Path(node.data.path)
        if path.is_file() and path.suffix.lower() in _AUDIO_EXTS:
            self.dismiss(path)
        # If it's a directory, the tree's own Enter handling expands it;
        # we noop here.


# ─── Screen ──────────────────────────────────────────────────────────────────


class RecordBody(Vertical):
    """The record-and-upload pane (used inside MainScreen's TabbedContent)."""

    BINDINGS = [
        Binding("ctrl+space", "toggle_record", "Start/Stop"),
        Binding("ctrl+p", "toggle_pause", "Pause/Resume"),
        Binding("ctrl+x", "toggle_personal", "Personal"),
        Binding("ctrl+u", "import_file", "Import"),
    ]

    DEFAULT_CSS = """
    RecordBody {
        padding: 1 2;
    }

    /* ── title row: full-width input, no label ── */
    #title-row {
        height: 3;
        margin-bottom: 1;
    }
    #title-row Input {
        width: 1fr;
    }

    /* ── shared 4-column grid for toggles + controls rows ── */
    #toggles-row,
    #controls-row {
        height: 3;
        margin-bottom: 1;
        align: left middle;
    }
    #toggles-row > *,
    #controls-row > * {
        width: 1fr;
        height: 3;
        margin-right: 1;
        border: round $primary;
        content-align: center middle;
    }
    #toggles-row > :last-child,
    #controls-row > :last-child {
        margin-right: 0;
    }

    /* ── preset Select: strip our outer border so its inner SelectCurrent
       chrome (which has its own border + the ▼ glyph) renders the value
       text without double-bordering collapse.  v0.4.2 forced height: 3
       on every cell, but Select's outer border + inner SelectCurrent
       border consumed 4 rows of chrome on a 3-row cell, hiding the text
       (issue reported in vezir-data/errors/tui_0.4.2.png). */
    #toggles-row Select {
        border: none;
        padding: 0;
    }

    /* ── toggle buttons: green when on, default when off ── */
    .toggle-on {
        background: $success;
        color: $text;
        border: round $success;
    }
    /* Personal uses warning color when on (privacy-mode indicator) */
    .toggle-personal-on {
        background: $warning;
        color: $text;
        border: round $warning;
    }

    /* ── timer label: read-only display cell ── */
    #timer-label {
        text-style: bold;
        color: $accent;
        padding: 0 1;
    }

    /* ── recording / paused state overrides ── */
    Button.recording {
        background: $error;
        color: $text;
        border: round $error;
    }
    Button.paused {
        background: $warning;
        color: $text;
        border: round $warning;
    }

    #status-line {
        height: 1;
        margin-bottom: 1;
        color: $text-muted;
    }
    #error-line {
        color: $error;
        height: auto;
        min-height: 0;
    }
    #version-line {
        height: 1;
        color: $text-muted;
        text-style: italic;
        text-align: right;
    }
    """

    # ── reactive state ──
    # init=False so watchers don't fire before compose() mounts the
    # backing widgets.  Default values are still respected.
    is_recording: reactive[bool] = reactive(False, init=False)
    is_paused: reactive[bool] = reactive(False, init=False)
    is_uploading: reactive[bool] = reactive(False, init=False)
    elapsed_seconds: reactive[float] = reactive(0.0, init=False)
    file_bytes: reactive[int] = reactive(0, init=False)
    status_text: reactive[str] = reactive("ready", init=False)
    error_text: reactive[str] = reactive("", init=False)

    def __init__(self) -> None:
        super().__init__()
        # Library-level session; None when not recording.
        self._session = None  # type: ignore[assignment]
        # Path of the last finished recording (used by upload).
        self._last_audio_path: Path | None = None
        # Last upload session_id (for poll worker).
        self._last_session_id: str | None = None
        # Persisted preferences cache.
        self._prefs = load_client_prefs()

    @classmethod
    def body_widget(cls) -> "RecordBody":
        """Factory used by MainScreen's TabbedContent."""
        return cls()

    # ── compose ──

    def compose(self) -> ComposeResult:
        with Horizontal(id="title-row"):
            yield Input(placeholder="optional meeting title", id="title-input")

        with Horizontal(id="toggles-row"):
            yield Button("Auto-label", id="auto-label-btn")
            yield Button("Sync", id="sync-btn")
            yield Button("Personal", id="personal-btn")
            yield Select(
                options=_PRESET_OPTIONS,
                value=self._prefs.get("preset", "high-quality"),
                allow_blank=False,
                id="preset",
            )

        with Horizontal(id="controls-row"):
            yield Button("● Record", id="record-btn", variant="error")
            yield Button("⏸ Pause", id="pause-btn", disabled=True)
            yield Label(
                "00:00:00",
                id="timer-label",
                classes="timer",
            )
            yield Button("⬆ Upload", id="upload-btn")

        yield Static(f"Status: {self.status_text}", id="status-line")
        yield Static("", id="error-line", classes="error")
        yield Static(f"v{_vezir_version()}", id="version-line")

    # ── mount: apply initial toggle states from prefs ──

    def on_mount(self) -> None:
        """Style toggle-buttons to match persisted preferences."""
        al = self.query_one("#auto-label-btn", Button)
        self._style_toggle(al, bool(self._prefs.get("auto_label", True)))
        sy = self.query_one("#sync-btn", Button)
        self._style_toggle(sy, bool(self._prefs.get("sync", True)))
        # Personal always starts off (not persisted).
        pe = self.query_one("#personal-btn", Button)
        self._style_toggle(pe, False, personal=True)

    # ── reactive watchers ──

    def watch_status_text(self, value: str) -> None:
        try:
            line = self.query_one("#status-line", Static)
        except Exception:
            return  # not mounted yet
        line.update(f"Status: {value}")

    def watch_error_text(self, value: str) -> None:
        try:
            line = self.query_one("#error-line", Static)
        except Exception:
            return
        line.update(value)

    def watch_is_recording(self, value: bool) -> None:
        try:
            btn = self.query_one("#record-btn", Button)
            pause_btn = self.query_one("#pause-btn", Button)
        except Exception:
            return
        if value:
            btn.label = "■ Stop"
            btn.variant = "warning"
            btn.add_class("recording")
            pause_btn.disabled = False
        else:
            btn.label = "● Record"
            btn.variant = "error"
            btn.remove_class("recording")
            pause_btn.disabled = True
            pause_btn.label = "⏸ Pause"

    def watch_is_paused(self, value: bool) -> None:
        try:
            pause_btn = self.query_one("#pause-btn", Button)
        except Exception:
            return
        if value:
            pause_btn.label = "▶ Resume"
            pause_btn.add_class("paused")
        else:
            pause_btn.label = "⏸ Pause"
            pause_btn.remove_class("paused")

    def watch_elapsed_seconds(self, value: float) -> None:
        self._refresh_timer()

    def watch_file_bytes(self, value: int) -> None:
        self._refresh_timer()

    def _refresh_timer(self) -> None:
        try:
            lbl = self.query_one("#timer-label", Label)
        except Exception:
            return
        suffix = "  (paused)" if self.is_paused else ""
        elapsed_str = _fmt_elapsed(self.elapsed_seconds)
        # Hide byte counter until real audio data has accumulated.
        # WAV header alone is ~44 B; show only once we exceed 4 KB.
        if self.file_bytes >= 4096:
            bytes_str = f"  {_fmt_bytes(self.file_bytes)}"
        else:
            bytes_str = ""
        lbl.update(f"{elapsed_str}{bytes_str}{suffix}")

    # ── button + binding handlers ──

    def on_button_pressed(self, event: Button.Pressed) -> None:
        bid = event.button.id
        if bid == "record-btn":
            self.action_toggle_record()
        elif bid == "pause-btn":
            self.action_toggle_pause()
        elif bid == "upload-btn":
            self.action_import_file()
        elif bid == "auto-label-btn":
            self._toggle_pref_button(event.button, "auto_label")
            event.stop()
        elif bid == "sync-btn":
            self._toggle_pref_button(event.button, "sync")
            event.stop()
        elif bid == "personal-btn":
            self.action_toggle_personal()
            event.stop()

    # ── toggle-button helpers ──

    def _toggle_pref_button(self, btn: Button, pref_key: str) -> None:
        """Flip a preference toggle-button on/off, persist, and restyle."""
        current = bool(self._prefs.get(pref_key, True))
        new_val = not current
        self._prefs[pref_key] = new_val
        save_client_prefs(self._prefs)
        self._style_toggle(btn, new_val)

    @staticmethod
    def _style_toggle(btn: Button, is_on: bool, *, personal: bool = False) -> None:
        """Apply visual on/off styling to a toggle-button."""
        if personal:
            if is_on:
                btn.variant = "warning"
                btn.add_class("toggle-personal-on")
                btn.remove_class("toggle-on")
            else:
                btn.variant = "default"
                btn.remove_class("toggle-personal-on")
                btn.remove_class("toggle-on")
        else:
            if is_on:
                btn.variant = "success"
                btn.add_class("toggle-on")
            else:
                btn.variant = "default"
                btn.remove_class("toggle-on")

    def on_select_changed(self, event: Select.Changed) -> None:
        if event.select.id == "preset":
            self._prefs["preset"] = str(event.value)
            save_client_prefs(self._prefs)

    def action_toggle_record(self) -> None:
        if self.is_recording:
            self._stop_recording()
        else:
            self._start_recording()

    def action_toggle_pause(self) -> None:
        if not self.is_recording or self._session is None:
            return
        try:
            if self.is_paused:
                self._session.resume()
                self.is_paused = False
                self.status_text = "recording"
            else:
                self._session.pause()
                self.is_paused = True
                self.status_text = "paused"
        except Exception as exc:
            self.error_text = f"pause/resume failed: {exc}"

    def action_toggle_personal(self) -> None:
        """Toggle personal mode.  When personal is on, force sync off
        and disable the sync button (server enforces this anyway; we
        keep the UI honest).  When personal is off, restore the
        persisted sync preference."""
        btn = self.query_one("#personal-btn", Button)
        is_on = "toggle-personal-on" not in btn.classes
        self._style_toggle(btn, is_on, personal=True)

        sync_btn = self.query_one("#sync-btn", Button)
        if is_on:
            # Force sync off and disable.
            self._prefs["sync"] = False
            save_client_prefs(self._prefs)
            self._style_toggle(sync_btn, False)
            sync_btn.disabled = True
        else:
            # Restore persisted sync pref and re-enable.
            sync_btn.disabled = False
            restored = bool(self._prefs.get("sync", True))
            self._style_toggle(sync_btn, restored)

    def action_import_file(self) -> None:
        """Open a file-picker modal to import an existing .wav/.ogg
        recording from disk and upload it through the same pipeline
        used by in-TUI recordings.

        v0.5.0 repurposed the Upload button + ^u binding from
        "re-upload the last in-TUI recording" to "import a file".
        Auto-upload on Stop is unchanged: fresh in-TUI recordings
        still upload automatically when the recorder finishes.  The
        manual retry path for a failed auto-upload is now: open the
        picker, navigate to the recording (default location
        ~/vezir-data/recordings/), select it.  Or: `vezir upload
        <path>` from the CLI.
        """
        if self.is_uploading:
            self.error_text = "upload in progress; wait for it to finish"
            return
        if self.is_recording:
            self.error_text = "stop the current recording before importing"
            return

        start = self._prefs.get("last_import_dir") or str(Path.home())
        start_path = Path(start)
        if not start_path.is_dir():
            start_path = Path.home()

        def _after_pick(picked: Path | None) -> None:
            if picked is None:
                return  # silent cancel
            # Remember the parent directory for next open.
            try:
                self._prefs["last_import_dir"] = str(picked.parent)
                save_client_prefs(self._prefs)
            except Exception:
                pass  # non-fatal
            self.error_text = ""
            self.status_text = f"importing {picked.name}"
            self._kick_upload(picked)

        self.app.push_screen(ImportScreen(start_path), _after_pick)

    # ── recording lifecycle ──

    def _start_recording(self) -> None:
        # Lazy-import millet-record so a system that only wants to
        # list sessions doesn't pay for the pulseaudio / sidecar import.
        try:
            from millet_record.capture import create_session, check_prerequisites
        except ImportError as exc:
            self.error_text = (
                f"millet-record not installed: {exc}. "
                f"pip install millet-record."
            )
            return

        issues = check_prerequisites()
        if issues:
            self.error_text = " | ".join(issues)
            return

        try:
            self._session = create_session()
        except Exception as exc:
            self.error_text = f"could not create session: {exc}"
            return

        self.error_text = ""
        self.status_text = "starting recorder"
        self._record_worker(self._session)

    def _stop_recording(self) -> None:
        if self._session is None:
            return
        self.status_text = "draining (flushing audio buffer)"
        self._stop_worker(self._session)

    @work(thread=True, exclusive=True, group="recorder")
    def _record_worker(self, session) -> None:
        """Drive the recorder: start, then poll status every second."""
        try:
            session.start()
        except Exception as exc:
            self.post_message(RecorderFailed(reason=str(exc)))
            return
        # Notify the UI to flip into recording mode.
        self.post_message(ServerStatus(status="recording"))
        # Tick loop: poll the session's own status() and emit TimerTick
        # messages.  Stops when the session is no longer alive (i.e.
        # _stop_worker has finalized it).
        while True:
            try:
                st = session.status()
            except Exception as exc:
                self.post_message(RecorderFailed(reason=f"status() raised: {exc}"))
                return
            self.post_message(TimerTick(
                elapsed=st.elapsed_seconds,
                bytes=st.file_size_bytes,
                paused=st.paused,
            ))
            if st.failed:
                self.post_message(RecorderFailed(
                    reason=st.fail_reason or "unknown recorder error",
                ))
                return
            if not st.is_alive and not st.paused:
                # Either we haven't started yet (let the watchdog catch
                # that) or we've finalized.  Loop again briefly and let
                # the stop worker complete; we exit through the explicit
                # return in _stop_worker via session attribute mutation.
                pass
            time.sleep(1.0)

    @work(thread=True, exclusive=True, group="recorder-stop")
    def _stop_worker(self, session) -> None:
        try:
            out = session.stop()
        except Exception as exc:
            self.post_message(RecorderFailed(reason=f"stop() raised: {exc}"))
            return
        self.post_message(RecorderFinished(audio_path=out))

    # ── upload lifecycle ──

    def _kick_upload(self, audio_path: Path) -> None:
        title_widget = self.query_one("#title-input", Input)
        auto_label = "toggle-on" in self.query_one("#auto-label-btn", Button).classes
        sync = "toggle-on" in self.query_one("#sync-btn", Button).classes
        personal = "toggle-personal-on" in self.query_one("#personal-btn", Button).classes
        preset = str(self.query_one("#preset", Select).value)
        title = (title_widget.value or "").strip() or None

        if personal:
            sync = False  # match server-side enforcement

        self.is_uploading = True
        self.status_text = "compressing" if audio_path.suffix.lower() == ".wav" else "uploading"
        self.error_text = ""
        self._upload_worker(audio_path, title, preset, auto_label, sync, personal)

    @work(thread=True, exclusive=True, group="upload")
    def _upload_worker(
        self,
        audio_path: Path,
        title: str | None,
        preset: str,
        auto_label: bool,
        sync: bool,
        personal: bool,
    ) -> None:
        from .. import uploader

        try:
            if audio_path.suffix.lower() == ".wav":
                audio_path = uploader.compress_wav_for_upload(
                    audio_path, keep_wav=True,
                )
        except Exception as exc:
            self.post_message(UploadFailed(
                error=f"compression failed: {exc}",
                audio_path=audio_path,
            ))
            return

        def on_progress(sent: int, total: int, elapsed: float) -> None:
            rate = sent / elapsed if elapsed > 0 else 0.0
            self.post_message(UploadProgress(sent=sent, total=total, rate=rate))

        def on_retry(attempt: int, retries: int, exc: Exception) -> None:
            self.post_message(ServerStatus(
                status="uploading",
                extra=f"attempt {attempt}/{retries} failed; retrying",
            ))

        try:
            result = uploader.upload(
                self.app.server_url,
                self.app.token or "",
                audio_path,
                title=title,
                summary_preset=preset,
                auto_label=auto_label,
                sync=sync,
                personal=personal,
                progress=on_progress,
                on_retry=on_retry,
            )
        except Exception as exc:
            self.post_message(UploadFailed(
                error=f"upload failed: {exc}",
                audio_path=audio_path,
            ))
            return

        self.post_message(UploadFinished(
            session_id=result.get("session_id", ""),
            dashboard_url=result.get("dashboard_url")
                          or result.get("dashboard_login_url"),
        ))

    @work(thread=True, exclusive=True, group="poll")
    def _poll_worker(self, session_id: str) -> None:
        """Poll /api/sessions/{id} until terminal status.

        Terminal statuses include ``needs_labeling`` because the
        server is then waiting on the human; there's nothing more
        for the poll worker to track.  Previously this kept polling
        forever for any session whose auto-label didn't reach
        confident voiceprint matches (PR9 latent bug).
        """
        import time as _t

        terminal = {"done", "error", "needs_labeling"}
        last_status = ""
        deadline = _t.time() + 600
        while _t.time() < deadline:
            result = self.app.api.get_session(session_id)
            if not result.is_ok():
                _t.sleep(5)
                continue
            session = result.ok
            if session.status != last_status:
                last_status = session.status
                self.post_message(ServerStatus(
                    status=session.status,
                    extra=session.error or session.summary_error or "",
                ))
            if session.status in terminal:
                # PR9: notify the rest of the UI that this session is
                # now displayable (done) or failed (error) so the
                # Sessions tab can refresh and the user gets a toast.
                self.post_message(SessionUploadComplete(
                    session_id=session_id,
                    status=session.status,
                ))
                return
            _t.sleep(5)

    # ── message handlers ──

    def on_timer_tick(self, message: TimerTick) -> None:
        self.elapsed_seconds = message.elapsed
        self.file_bytes = message.bytes
        if message.paused != self.is_paused:
            self.is_paused = message.paused

    def on_recorder_failed(self, message: RecorderFailed) -> None:
        self.is_recording = False
        self.is_paused = False
        self.status_text = "recorder failed"
        self.error_text = message.reason

    def on_recorder_finished(self, message: RecorderFinished) -> None:
        self.is_recording = False
        self.is_paused = False
        self._last_audio_path = message.audio_path
        # (Upload button no longer toggles on/off based on _last_audio_path
        # in v0.5.0+; it's always enabled and opens the Import picker.
        # Auto-upload of the just-finished recording still happens below.)
        size = message.audio_path.stat().st_size if message.audio_path.exists() else 0
        self.file_bytes = size
        self.status_text = (
            f"recording finished ({_fmt_bytes(size)}); press u to upload"
        )
        # Auto-kick upload to match gui.py's behavior.
        self._kick_upload(message.audio_path)

    def on_server_status(self, message: ServerStatus) -> None:
        self.is_recording = message.status == "recording"
        text = message.status
        if message.extra:
            text = f"{message.status}  ({message.extra})"
        self.status_text = text

    def on_upload_progress(self, message: UploadProgress) -> None:
        if message.total > 0:
            pct = message.sent / message.total * 100
            self.status_text = (
                f"uploading {pct:5.1f}% "
                f"({_fmt_bytes(message.sent)} / {_fmt_bytes(message.total)} "
                f"@ {_fmt_bytes(int(message.rate))}/s)"
            )

    def on_upload_finished(self, message: UploadFinished) -> None:
        self.is_uploading = False
        self._last_session_id = message.session_id
        self.status_text = f"uploaded as {message.session_id}; polling status"
        self.error_text = ""
        self._poll_worker(message.session_id)

    def on_upload_failed(self, message: UploadFailed) -> None:
        self.is_uploading = False
        self.status_text = "upload failed"
        suffix = ""
        if message.audio_path is not None:
            suffix = (
                f"\nRetry with: vezir upload {message.audio_path}"
            )
        self.error_text = message.error + suffix
