"""Tests for /admin/enroll device-enrollment page."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest


@pytest.fixture
def tmp_data(monkeypatch):
    with tempfile.TemporaryDirectory() as d:
        monkeypatch.setenv("VEZIR_DATA", d)
        yield Path(d)


@pytest.fixture
def client_and_token(tmp_data):
    """Admin-tier token for /admin/enroll happy-path tests."""
    from fastapi.testclient import TestClient
    from vezir.server import auth
    from vezir.server.app import create_app

    # /admin/enroll now requires is_admin=True (0.1.12+).
    token = auth.issue("alice", is_admin=True)
    app = create_app()
    return TestClient(app, follow_redirects=False), token


@pytest.fixture
def client_and_nonadmin_token(tmp_data):
    """Scribe-tier token used to verify /admin/enroll denies non-admins."""
    from fastapi.testclient import TestClient
    from vezir.server import auth
    from vezir.server.app import create_app

    token = auth.issue("bob", is_admin=False)
    app = create_app()
    return TestClient(app, follow_redirects=False), token


def _bearer(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


# ── auth gating ─────────────────────────────────────────────────────────────


def test_enroll_get_requires_auth(client_and_token):
    client, _ = client_and_token
    resp = client.get("/admin/enroll")
    assert resp.status_code == 401


def test_enroll_post_requires_auth(client_and_token):
    client, _ = client_and_token
    resp = client.post(
        "/admin/enroll",
        data={"token": "vzr_x", "url": "http://example.local:8000"},
    )
    assert resp.status_code == 401


def test_enroll_get_requires_admin_role(client_and_nonadmin_token):
    """A valid but non-admin token must be denied with 403, not let in."""
    client, token = client_and_nonadmin_token
    resp = client.get("/admin/enroll", headers=_bearer(token))
    assert resp.status_code == 403


def test_enroll_post_requires_admin_role(client_and_nonadmin_token):
    client, token = client_and_nonadmin_token
    resp = client.post(
        "/admin/enroll",
        headers=_bearer(token),
        data={"token": token, "url": "http://example.local:8000"},
    )
    assert resp.status_code == 403


# ── empty form (just the paste UI) ──────────────────────────────────────────


def test_enroll_get_authed_renders_form(client_and_token):
    client, token = client_and_token
    resp = client.get("/admin/enroll", headers=_bearer(token))
    assert resp.status_code == 200
    body = resp.text
    assert "Enroll a device" in body
    assert "<form" in body
    assert "/admin/enroll" in body
    # No QR yet because no token+url were supplied.
    assert "<svg" not in body


# ── full happy path: GET with token + url renders QR ────────────────────────


def _has_payload_fields(body: str, *, url: str, token: str) -> bool:
    """The QR JSON is rendered inside a <pre> with HTML-entity escaping
    (Jinja autoescape), so don't compare to literal JSON. Compare to the
    HTML-escaped form instead.
    """
    import html as _html
    needle_v = "&#34;v&#34;:1"
    needle_url = f"&#34;url&#34;:&#34;{_html.escape(url)}&#34;"
    needle_token = f"&#34;token&#34;:&#34;{token}&#34;"
    return all(s in body for s in (needle_v, needle_url, needle_token))


def test_enroll_get_with_token_and_url_renders_qr(client_and_token):
    client, token = client_and_token
    url = "http://muscle.tail178bd.ts.net:8000"
    resp = client.get(
        f"/admin/enroll?token={token}&url={url}",
        headers=_bearer(token),
    )
    assert resp.status_code == 200
    body = resp.text
    assert "<svg" in body  # inline SVG QR code
    assert _has_payload_fields(body, url=url, token=token)


def test_enroll_post_with_token_and_url_renders_qr(client_and_token):
    client, token = client_and_token
    url = "http://muscle.tail178bd.ts.net:8000"
    resp = client.post(
        "/admin/enroll",
        headers=_bearer(token),
        data={"token": token, "url": url},
    )
    assert resp.status_code == 200
    body = resp.text
    assert "<svg" in body
    assert _has_payload_fields(body, url=url, token=token)


# ── invalid token must NOT render QR ────────────────────────────────────────


def test_enroll_invalid_token_no_qr(client_and_token):
    client, valid_token = client_and_token
    # Auth with the valid token, but submit a bogus token in the form.
    resp = client.post(
        "/admin/enroll",
        headers=_bearer(valid_token),
        data={"token": "vzr_bogus", "url": "http://x.local:8000"},
    )
    assert resp.status_code == 200
    body = resp.text
    assert "Invalid token" in body
    assert "<svg" not in body


# ── reject obviously bad URLs ───────────────────────────────────────────────


@pytest.mark.parametrize("bad_url", [
    "ftp://example.com",
    "javascript:alert(1)",
    "not-a-url",
])
def test_enroll_post_rejects_unsafe_url(client_and_token, bad_url):
    client, valid_token = client_and_token
    resp = client.post(
        "/admin/enroll",
        headers=_bearer(valid_token),
        data={"token": valid_token, "url": bad_url},
    )
    assert resp.status_code == 200
    body = resp.text
    # The explicit URL-shape error is what `_is_safe_server_url` emits.
    assert "Server URL must be" in body
    assert "<svg" not in body


def test_enroll_post_rejects_empty_url(client_and_token):
    """Empty URL is caught by FastAPI's Form(...) required validation
    layer before our handler runs, so the response is a 422 rather than
    a 200 with our friendly error. Either layer rejecting it cleanly is
    acceptable; the goal is just "no QR rendered for empty URL".
    """
    client, valid_token = client_and_token
    resp = client.post(
        "/admin/enroll",
        headers=_bearer(valid_token),
        data={"token": valid_token, "url": ""},
    )
    # Accept any 4xx status; the contract is "no QR rendered".
    assert 400 <= resp.status_code < 500
    assert "<svg" not in resp.text


# ── payload schema is canonical ─────────────────────────────────────────────


def test_payload_v1_when_no_ca(monkeypatch):
    """Without a CA cert configured, build_payload emits the v1 shape so
    pre-0.1.12 Android/iOS clients keep parsing it unchanged."""
    monkeypatch.delenv("VEZIR_CADDY_ROOT_CERT_PATH", raising=False)
    from vezir.server.enroll import build_payload

    payload = build_payload("http://server.example:8000", "vzr_abc123")
    obj = json.loads(payload)
    assert obj == {
        "v": 1,
        "url": "http://server.example:8000",
        "token": "vzr_abc123",
    }
    # Compact (no spaces) so QR is smaller.
    assert " " not in payload


def test_payload_v2_when_ca_provided():
    """With a CA cert, build_payload bumps to v2 and embeds the PEM."""
    from vezir.server.enroll import build_payload, PAYLOAD_VERSION

    ca = "-----BEGIN CERTIFICATE-----\nABCDEF\n-----END CERTIFICATE-----\n"
    payload = build_payload("https://srv.ts.net", "vzr_abc", ca_pem=ca)
    obj = json.loads(payload)
    assert obj["v"] == PAYLOAD_VERSION == 2
    assert obj["url"] == "https://srv.ts.net"
    assert obj["token"] == "vzr_abc"
    assert obj["ca_pem"] == ca


def test_payload_ca_loaded_from_env(monkeypatch, tmp_path):
    """When VEZIR_CADDY_ROOT_CERT_PATH points at a real PEM, the
    /admin/enroll handler should emit a v2 payload containing it."""
    cert = tmp_path / "vezir-root.crt"
    cert.write_text(
        "-----BEGIN CERTIFICATE-----\nMOCKED\n-----END CERTIFICATE-----\n"
    )
    monkeypatch.setenv("VEZIR_CADDY_ROOT_CERT_PATH", str(cert))

    from vezir.server.enroll import _load_caddy_root_cert
    loaded = _load_caddy_root_cert()
    assert loaded is not None
    assert "MOCKED" in loaded


def test_payload_ca_silently_falls_back_on_bad_path(monkeypatch):
    """A misconfigured cert path must NOT break the enroll form. It
    should fall back to v1 and just log a warning. Operators upgrade
    from no-Caddy to with-Caddy in a sequence, so the intermediate
    state must be benign.
    """
    monkeypatch.setenv("VEZIR_CADDY_ROOT_CERT_PATH", "/does/not/exist.crt")
    from vezir.server.enroll import _load_caddy_root_cert, build_payload

    assert _load_caddy_root_cert() is None
    payload = build_payload("http://srv:8000", "vzr_t")
    assert json.loads(payload)["v"] == 1


def test_payload_ca_rejected_when_not_pem(monkeypatch, tmp_path):
    """If the configured file isn't a PEM cert, fall back to v1 rather
    than dumping garbage into the QR.
    """
    fake = tmp_path / "garbage"
    fake.write_text("this is not a certificate")
    monkeypatch.setenv("VEZIR_CADDY_ROOT_CERT_PATH", str(fake))
    from vezir.server.enroll import _load_caddy_root_cert
    assert _load_caddy_root_cert() is None


def test_payload_ca_rejected_when_too_large(monkeypatch, tmp_path):
    """Hard cap protects QR scannability."""
    big = tmp_path / "huge.crt"
    big.write_text(
        "-----BEGIN CERTIFICATE-----\n"
        + ("A" * 100_000)
        + "\n-----END CERTIFICATE-----\n"
    )
    monkeypatch.setenv("VEZIR_CADDY_ROOT_CERT_PATH", str(big))
    from vezir.server.enroll import _load_caddy_root_cert
    assert _load_caddy_root_cert() is None
