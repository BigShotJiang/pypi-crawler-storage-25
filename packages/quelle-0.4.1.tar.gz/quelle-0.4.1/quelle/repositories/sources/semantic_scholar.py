"""Semantic Scholar client — fallback metadata + citation graph.

Free API. Unauthenticated is fine for single-item usage; an optional
`SEMANTIC_SCHOLAR_API_KEY` unlocks higher rate limits. Docs:
https://api.semanticscholar.org/api-docs/graph
"""

from __future__ import annotations

from typing import Any

import httpx

from quelle.models.publication import Author, Publication
from quelle.models.search import SearchHit
from quelle.repositories.errors import NotFoundError
from quelle.repositories.http_client import get_json
from quelle.settings import Settings

API_BASE = "https://api.semanticscholar.org/graph/v1"
SOURCE_NAME = "semantic_scholar"

_SEARCH_FIELDS = ",".join(
    [
        "paperId",
        "externalIds",
        "title",
        "year",
        "authors.name",
    ]
)

_FIELDS = ",".join(
    [
        "paperId",
        "externalIds",
        "title",
        "abstract",
        "year",
        "authors",
        "authors.name",
        "authors.affiliations",
        "venue",
        "publicationVenue",
        "citationCount",
        "openAccessPdf",
        "url",
        "fieldsOfStudy",
    ]
)


def _auth_headers(settings: Settings) -> dict[str, str]:
    headers: dict[str, str] = {}
    key = getattr(settings, "semantic_scholar_api_key", "")
    if key:
        headers["x-api-key"] = key
    return headers


def search_by_title(client: httpx.Client, settings: Settings, title: str) -> Publication:
    """Return the single best Semantic Scholar match for a title."""
    url = f"{API_BASE}/paper/search/match"
    payload = get_json(
        client,
        url,
        params={"query": title, "fields": _FIELDS},
    )
    data = payload.get("data") or []
    if not data:
        raise NotFoundError(f"no Semantic Scholar match for title: {title!r}")
    return _to_publication(data[0])


def fetch_by_doi(client: httpx.Client, settings: Settings, doi: str) -> Publication:
    """Return the Semantic Scholar record for a specific DOI."""
    url = f"{API_BASE}/paper/DOI:{doi}"
    payload = get_json(client, url, params={"fields": _FIELDS})
    return _to_publication(payload)


def search(
    client: httpx.Client,
    settings: Settings,
    query: str,
    *,
    author: str | None = None,
    kind: str | None = None,
    limit: int = 20,
) -> list[SearchHit]:
    """Return up to `limit` candidate hits for a free-text query.

    Semantic Scholar's `paper/search` endpoint has no separate author
    filter, so an `author` hint is folded into the query string.
    `kind` is accepted for signature uniformity but ignored — the
    endpoint only returns scholarly articles.
    """
    del settings  # auth header path not yet wired through get_json
    del kind
    full_query = f"{query} {author}".strip() if author else query
    url = f"{API_BASE}/paper/search"
    payload = get_json(
        client,
        url,
        params={
            "query": full_query,
            "limit": str(limit),
            "fields": _SEARCH_FIELDS,
        },
    )
    data = payload.get("data") or []
    return [_to_search_hit(paper, rank) for rank, paper in enumerate(data)]


def _to_search_hit(paper: dict[str, Any], rank: int) -> SearchHit:
    """Map a Semantic Scholar paper JSON into a `SearchHit`."""
    authors: list[Author] = []
    for entry in paper.get("authors") or []:
        name = entry.get("name") or ""
        if name:
            authors.append(Author(name=name))

    external = paper.get("externalIds") or {}
    doi = external.get("DOI")
    return SearchHit(
        title=paper.get("title") or "",
        authors=authors,
        year=paper.get("year"),
        type="article",
        doi=(doi or "").lower() or None,
        arxiv_id=external.get("ArXiv"),
        source=SOURCE_NAME,
        source_id=paper.get("paperId") or "",
        raw_rank=rank,
    )


def _to_publication(paper: dict[str, Any]) -> Publication:
    """Map a Semantic Scholar paper JSON into a `Publication`."""
    if not paper or paper.get("error"):
        raise NotFoundError(f"Semantic Scholar error: {paper.get('error') if paper else 'empty'}")

    authors: list[Author] = []
    for entry in paper.get("authors") or []:
        name = entry.get("name") or ""
        if not name:
            continue
        affiliations = entry.get("affiliations") or []
        affiliation = affiliations[0] if affiliations else None
        authors.append(Author(name=name, affiliation=affiliation))

    external = paper.get("externalIds") or {}
    doi = external.get("DOI")
    arxiv_id = external.get("ArXiv")

    venue_block = paper.get("publicationVenue") or {}
    venue = venue_block.get("name") or paper.get("venue") or None
    open_access_pdf = paper.get("openAccessPdf") or {}
    pdf_url = open_access_pdf.get("url")

    return Publication(
        title=paper.get("title") or "",
        authors=authors,
        year=paper.get("year"),
        venue=venue,
        publisher=venue_block.get("publisher"),
        doi=(doi or "").lower() or None,
        arxiv_id=arxiv_id,
        semantic_scholar_id=paper.get("paperId"),
        abstract=paper.get("abstract"),
        citation_count=paper.get("citationCount"),
        is_open_access=bool(pdf_url),
        pdf_url=pdf_url,
        source_url=paper.get("url"),
        topics=paper.get("fieldsOfStudy") or [],
        resolved_from_chain=["semantic_scholar"],
    )
