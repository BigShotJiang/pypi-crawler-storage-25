from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from importlib.metadata import PackageNotFoundError, version
from typing import Any, AsyncIterator, Callable

import mcp.server.stdio
from mcp import types
from mcp.server import Server

from ...config import MemoryConfig
from ...core.service import BreathingMemoryEngine
from ...core.types import (
    FeedbackRequest,
    FetchRequest,
    ReadActiveCollaborationPolicyRequest,
    RecentRequest,
    RememberRequest,
    SearchRequest,
)
from ..serializers import result_to_payload


SERVER_NAME = "breathing-memory"
SERVER_INSTRUCTIONS = (
    "Breathing Memory provides tools for persisting and retrieving collaboration memory. "
    "Use memory_remember to persist a turn, memory_search to retrieve relevant fragments, "
    "memory_read_active_collaboration_policy to load collaboration-policy fragments before answering, "
    "memory_fetch for direct lookup, memory_recent to inspect the latest remembered root fragments, "
    "memory_feedback to record evaluation, and memory_stats for diagnostics."
)

ToolHandler = Callable[[BreathingMemoryEngine, dict[str, Any]], dict[str, Any]]


def _payload(engine: BreathingMemoryEngine, result: Any) -> dict[str, Any]:
    return result_to_payload(result, payload_mode=engine.config.mcp_payload_mode)


def _remember_result(engine: Any, request: RememberRequest) -> Any:
    if hasattr(engine, "remember_typed"):
        return engine.remember_typed(request)
    return engine.remember(request)


def _search_result(engine: Any, request: SearchRequest) -> Any:
    if hasattr(engine, "search_typed"):
        return engine.search_typed(request)
    return engine.search(request)


def _policy_result(engine: Any, request: ReadActiveCollaborationPolicyRequest) -> Any:
    if hasattr(engine, "read_active_collaboration_policy_typed"):
        return engine.read_active_collaboration_policy_typed(request)
    return engine.read_active_collaboration_policy(request)


def _fetch_result(engine: Any, request: FetchRequest) -> Any:
    if hasattr(engine, "fetch_typed"):
        return engine.fetch_typed(request)
    return engine.fetch(request)


def _feedback_result(engine: Any, request: FeedbackRequest) -> Any:
    if hasattr(engine, "feedback_typed"):
        return engine.feedback_typed(request)
    return engine.feedback(request)


def _recent_result(engine: Any, request: RecentRequest) -> Any:
    if hasattr(engine, "recent_typed"):
        return engine.recent_typed(request)
    return engine.recent(request)


def _stats_result(engine: Any) -> Any:
    if hasattr(engine, "stats_typed"):
        return engine.stats_typed()
    return engine.stats()


def _package_version() -> str:
    try:
        return version("breathing-memory")
    except PackageNotFoundError:
        return "0.7.0"


def _tool_definitions() -> list[types.Tool]:
    return [
        types.Tool(
            name="memory_remember",
            description="Persist one remembered fragment and any material references used in the final answer.",
            inputSchema={
                "type": "object",
                "properties": {
                    "content": {"type": "string"},
                    "actor": {"type": "string", "enum": ["user", "agent"]},
                    "reply_to": {"type": ["integer", "null"]},
                    "source_fragment_ids": {"type": "array", "items": {"type": "integer"}},
                    "kind": {"type": ["string", "null"]},
                },
                "required": ["content", "actor"],
            },
        ),
        types.Tool(
            name="memory_search",
            description="Retrieve remembered fragments by lexical match and rerank by search priority.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "result_count": {"type": "integer", "minimum": 4},
                    "search_effort": {"type": "integer", "minimum": 32},
                    "actor": {"type": "string", "enum": ["user", "agent"]},
                    "kind": {"type": ["string", "null"]},
                    "include_diagnostics": {"type": "boolean"},
                },
                "required": ["query"],
            },
        ),
        types.Tool(
            name="memory_read_active_collaboration_policy",
            description="Load active collaboration-policy fragments within a token budget.",
            inputSchema={
                "type": "object",
                "properties": {
                    "token_budget": {"type": "integer", "minimum": 1},
                },
            },
        ),
        types.Tool(
            name="memory_fetch",
            description="Directly fetch remembered fragments by fragment id or anchor id.",
            inputSchema={
                "type": "object",
                "properties": {
                    "fragment_id": {"type": "integer"},
                    "anchor_id": {"type": "integer"},
                },
            },
        ),
        types.Tool(
            name="memory_recent",
            description="Fetch the most recent remembered root fragments, optionally filtered by actor and reply target.",
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {"type": "integer", "minimum": 1},
                    "actor": {"type": "string", "enum": ["user", "agent"]},
                    "reply_to": {"type": "integer"},
                },
            },
        ),
        types.Tool(
            name="memory_feedback",
            description="Record explicit or attributable evaluation of a concrete remembered fragment.",
            inputSchema={
                "type": "object",
                "properties": {
                    "from_anchor_id": {"type": "integer"},
                    "fragment_id": {"type": "integer"},
                    "verdict": {"type": "string", "enum": ["positive", "neutral", "negative"]},
                },
                "required": ["from_anchor_id", "fragment_id", "verdict"],
            },
        ),
        types.Tool(
            name="memory_stats",
            description="Inspect current memory state and effective parameter values.",
            inputSchema={"type": "object", "properties": {}},
        ),
    ]


def _remember_handler(engine: BreathingMemoryEngine, arguments: dict[str, Any]) -> dict[str, Any]:
    request = RememberRequest(
        content=str(arguments["content"]),
        actor=str(arguments["actor"]),
        reply_to=arguments.get("reply_to"),
        source_fragment_ids=tuple(arguments.get("source_fragment_ids", [])),
        kind=arguments.get("kind"),
    )
    return _payload(engine, _remember_result(engine, request))


def _search_handler(engine: BreathingMemoryEngine, arguments: dict[str, Any]) -> dict[str, Any]:
    request = SearchRequest(
        query=str(arguments["query"]),
        result_count=arguments.get("result_count"),
        search_effort=arguments.get("search_effort"),
        actor=arguments.get("actor"),
        kind=arguments.get("kind"),
        include_diagnostics=bool(arguments.get("include_diagnostics", False)),
    )
    return _payload(engine, _search_result(engine, request))


def _read_active_collaboration_policy_handler(
    engine: BreathingMemoryEngine,
    arguments: dict[str, Any],
) -> dict[str, Any]:
    request = ReadActiveCollaborationPolicyRequest(token_budget=arguments.get("token_budget"))
    return _payload(engine, _policy_result(engine, request))


def _fetch_handler(engine: BreathingMemoryEngine, arguments: dict[str, Any]) -> dict[str, Any]:
    request = FetchRequest(
        fragment_id=arguments.get("fragment_id"),
        anchor_id=arguments.get("anchor_id"),
    )
    return _payload(engine, _fetch_result(engine, request))


def _feedback_handler(engine: BreathingMemoryEngine, arguments: dict[str, Any]) -> dict[str, Any]:
    request = FeedbackRequest(
        from_anchor_id=int(arguments["from_anchor_id"]),
        fragment_id=int(arguments["fragment_id"]),
        verdict=str(arguments["verdict"]),
    )
    return _payload(engine, _feedback_result(engine, request))


def _recent_handler(engine: BreathingMemoryEngine, arguments: dict[str, Any]) -> dict[str, Any]:
    request = RecentRequest(
        limit=int(arguments.get("limit", 4)),
        actor=arguments.get("actor"),
        reply_to=arguments.get("reply_to"),
    )
    return _payload(engine, _recent_result(engine, request))


def _stats_handler(engine: BreathingMemoryEngine, arguments: dict[str, Any]) -> dict[str, Any]:
    del arguments
    return _payload(engine, _stats_result(engine))


TOOL_HANDLERS: dict[str, ToolHandler] = {
    "memory_remember": _remember_handler,
    "memory_search": _search_handler,
    "memory_read_active_collaboration_policy": _read_active_collaboration_policy_handler,
    "memory_fetch": _fetch_handler,
    "memory_recent": _recent_handler,
    "memory_feedback": _feedback_handler,
    "memory_stats": _stats_handler,
}


@asynccontextmanager
async def _managed_engine(
    config: MemoryConfig | None = None,
    engine: BreathingMemoryEngine | None = None,
) -> AsyncIterator[BreathingMemoryEngine]:
    if engine is not None:
        yield engine
        return

    managed_engine = BreathingMemoryEngine(config=config or MemoryConfig())
    try:
        yield managed_engine
    finally:
        managed_engine.close()


def create_mcp_server(
    *,
    config: MemoryConfig | None = None,
    engine: BreathingMemoryEngine | None = None,
) -> Server[BreathingMemoryEngine, Any]:
    @asynccontextmanager
    async def lifespan(_server: Server[BreathingMemoryEngine, Any]) -> AsyncIterator[BreathingMemoryEngine]:
        async with _managed_engine(config=config, engine=engine) as active_engine:
            yield active_engine

    server: Server[BreathingMemoryEngine, Any] = Server(
        SERVER_NAME,
        version=_package_version(),
        instructions=SERVER_INSTRUCTIONS,
        lifespan=lifespan,
    )

    @server.list_tools()
    async def handle_list_tools(request: types.ListToolsRequest) -> types.ListToolsResult:
        del request
        server.request_context.lifespan_context.start_background_embedding_warmup()
        return types.ListToolsResult(tools=_tool_definitions())

    @server.call_tool()
    async def handle_call_tool(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        handler = TOOL_HANDLERS.get(name)
        if handler is None:
            raise ValueError(f"Unknown tool: {name}")
        active_engine = server.request_context.lifespan_context
        active_engine.start_background_embedding_warmup()
        return handler(active_engine, arguments)

    return server


async def serve_stdio_server(
    *,
    config: MemoryConfig | None = None,
    engine: BreathingMemoryEngine | None = None,
) -> None:
    server = create_mcp_server(config=config, engine=engine)
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def serve_stdio(
    *,
    config: MemoryConfig | None = None,
    engine: BreathingMemoryEngine | None = None,
) -> None:
    asyncio.run(serve_stdio_server(config=config, engine=engine))
