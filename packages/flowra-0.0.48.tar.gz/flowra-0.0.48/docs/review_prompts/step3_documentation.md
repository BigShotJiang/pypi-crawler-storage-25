# Prompt: Documentation Review

You are reviewing the documentation for a Python package. Your goal is to verify that the documentation exists, follows the project's best practices, and serves as a useful guide for users.

## Context

You will be given:
- The full source code of every file in the package (including `__init__.py`)
- The documentation file(s) that cover this package — docs are organized by topic, not by package (e.g., `docs/llm.md` covers `flowra.llm` and its providers, `docs/agents.md` covers `flowra.agent` and `flowra.lib`, `docs/observability.md` covers hooks and `flowra.ext.*`)
- The package name

This library is brand new with no users — documentation should be written for someone encountering the package for the first time.

## Documentation best practices

### Structure

The documentation must follow this structure:

1. **Title:** a clear topic-oriented title (e.g., `# Working with LLMs`, `# Tools`, `# Agents`)
2. **One-line description:** what this guide covers, in one sentence
3. **Overview:** bullet list or short paragraph summarizing the key concepts covered (not a file tree — a concise content map)
4. **Quick start:** minimal working example that demonstrates the most common use case
5. **Sections organized by user importance:** NOT alphabetically by entity, but as a journey:
   - What you need on day 1 (basic usage, core types)
   - Configuration and customization
   - Advanced features

### Documentation philosophy

Documentation is a story, not a reference. It should read top-to-bottom like a gradual immersion into the topic — the reader starts knowing nothing and finishes with a solid understanding of what the package does, why it exists, how to use it, and what the important nuances are.

The goal is to describe only what the user needs to understand the package and work with it effectively. Internal implementation details belong in the code, not in docs. If an internal concept is important for understanding behavior (e.g., how the execution loop works logically, or what happens on crash recovery), explain the concept at the right point in the narrative — don't create a separate "Internals" section for it.

Every section should flow naturally from the previous one. A reader going top-to-bottom should never feel lost or encounter a term that hasn't been introduced yet. If a concept from another package is referenced (e.g., `InterruptedError` from `flowra.agent`), provide a brief inline explanation or a link — don't assume the reader has read all other docs first.

### Content quality

- **This is NOT a reference manual.** Do NOT require that every internal type, every field of every class, or every method signature is documented. Only document things that matter to a user writing agents or understanding how the system works.
- **No "Internals" dump.** Do not require or recommend an "Internals" section listing internal types (`ExecutionNode`, `RuntimeScope`, `StepMeta`, `AgentDefinition`, etc.) with their full field tables. These are implementation details. If an internal concept is important for understanding behavior (e.g., storage keys, type registry), explain the concept inline where relevant — don't create a reference section for it.
- **`__all__` is not a documentation checklist.** Not every symbol in `__all__` needs its own section. Internal utilities (`collect_dataclass_types`), bridge types (`ChildOutput`), and base classes (`AbstractAgent`) may be exported for technical reasons but don't need user-facing documentation.
- **`async` on methods is not worth documenting.** Python developers know how to call async functions. Don't flag missing `async` in method tables as an error.
- **Completeness:** every public type that a user needs to understand must be documented
- **Examples are valid:** code snippets must use correct imports, types, method signatures, and field names that match the actual API
- **Responsibility is clear:** after reading the doc, you understand what the package does, why it exists, and how to use it
- **Logical flow:** sections follow naturally from each other — no jumping between unrelated topics
- **Tables for fields:** dataclass and config fields use markdown tables with columns: Field | Type | Default | Description (or Field | Type | Default when Description is obvious from the name)
- **No stale info:** documentation matches the current code, not an older version
- **No redundancy:** don't repeat the same information in multiple places
- **No implementation noise:** don't mention obvious Python mechanics like `frozen=True`, `slots=True`, `kw_only=True` on dataclasses, or that a class "inherits from X" when the user doesn't need to know. Document what things *do*, not how they are *implemented*.
- **Examples must be minimal for their purpose.** Each example should use only the concepts necessary to illustrate the point of its section. If a section explains timeouts, the example should show timeout usage — not also demonstrate advanced binding annotations, tag disambiguation, or other unrelated features. Advanced syntax (like `Annotated[T, step_arg.CHILD("tag")]`) should only appear in examples whose purpose is to explain that syntax. Mixing concerns makes examples harder to understand and teaches the reader to use unnecessary complexity by default.

## What to check

1. **Does documentation exist?** If there is no doc file covering this package's functionality, report it as the primary issue. Note: docs are topic-based — a package may be covered by a doc with a different name (e.g., `flowra.lib` is covered by `agents.md` and `observability.md`).

2. **Structure compliance:** does the doc follow the structure above? Missing sections? Wrong order?

3. **Completeness audit:** check that all user-facing concepts are covered. Not every symbol in `__all__` needs its own section — internal utilities, bridge types, and base classes are often exported for technical reasons and don't require documentation.

4. **Example validation:** for each code example in the doc:
   - Are the imports correct? (Right package, right symbol names)
   - Are the API calls correct? (Right method names, right argument names, right types)
   - Does the example make sense as a realistic use case?
   - Would the example actually work if run?

5. **Accuracy:** does the documentation correctly describe what the code does? Look for:
   - Descriptions that don't match the actual behavior
   - Default values that are wrong
   - Type signatures that are incorrect
   - Missing parameters or fields in tables

6. **Clarity:** would a new user understand how to use the package after reading this?

## Output format

```
# Documentation Review: flowra.<package_name>

## Documentation exists: YES / NO (list which doc files cover this package)

## Structure compliance
<List deviations from the expected structure, or "Compliant.">

## Completeness
### Documented symbols
<List of all symbols from __all__ that ARE documented>

### Undocumented symbols
<List of all symbols from __all__ that are NOT documented, or "None.">

## Example validation
### Example 1: <section name>
- **Valid:** YES / NO
- **Issues:** <list issues, or "None">

### Example 2: ...

## Accuracy issues
<List each inaccuracy with the specific documentation text and what the code actually does, or "None found.">

## Clarity issues
<List any sections that are confusing, poorly explained, or missing context, or "None found.">

## Summary
- Documentation exists: YES / NO
- Structure compliant: YES / NO
- Symbols documented: N / M
- Examples valid: N / M
- Accuracy issues: N
- Clarity issues: N
```

## Important

- Compare documentation against actual code — don't trust the documentation at face value.
- Be specific: quote the exact documentation text that's wrong and what it should say.
- Don't review code style or tests here — only documentation quality.
