# Multi-Agent Patterns

Recipes for common multi-agent architectures. All patterns use the same
primitives — `Spawn`, `CallAgent`, `GotoStep`, completion strategies — no special
DSL needed.

See [Agents](agents.md) for the fundamentals of steps, spawn, and control flow.

## Router

Classify input and delegate to a specialized agent:

```python
class Router(Agent[Query, Answer]):
    @step(entry=True)
    async def classify(self, spec: Query) -> Spawn:
        if "calculate" in spec.text.lower():
            agent = MathAgent
        else:
            agent = GeneralAgent

        return Spawn(
            CallAgent(agent=agent, spec=spec),
            then=self.forward,
        )

    @step
    async def forward(self, result: Answer) -> Answer:
        return result
```

The classification can be hard-coded, rule-based, or itself an LLM call.

## Pipeline

Sequential stages — each transforms data and passes it to the next:

```python
class Pipeline(Agent[Document, Report]):
    @step(entry=True)
    async def extract(self, spec: Document) -> GotoStep:
        entities = extract_entities(spec.text)
        return GotoStep(step=self.summarize, spec=Extracted(entities=entities))

    @step
    async def summarize(self, data: Extracted) -> Report:
        return Report(summary=f"Found {len(data.entities)} entities")
```

For heavier stages, delegate to sub-agents via `Spawn` + `CallAgent`.

## Fan-out / Fan-in

Dispatch work to parallel workers, collect all results:

```python
class FanOut(Agent[SearchQuery, MergedResults]):
    @step(entry=True)
    async def search(self, spec: SearchQuery) -> Spawn:
        return Spawn(
            WhenAll(*[
                CallAgent(agent=SearchAgent, spec=SearchSpec(query=spec.query, source=src))
                for src in ["web", "docs", "code"]
            ]),
            then=self.merge,
        )

    @step
    async def merge(self, results: list[SearchResult]) -> MergedResults:
        return MergedResults(all_items=[item for r in results for item in r.items])
```

## Race (first wins)

Launch competing workers, take the first result, cancel the rest:

```python
class Race(Agent[RaceSpec, RaceResult]):
    @step(entry=True)
    async def start(self, spec: RaceSpec) -> Spawn:
        return Spawn(
            WhenAny(
                CallAgent(agent=FastModel, spec=spec, tag="fast"),
                CallAgent(agent=SmartModel, spec=spec, tag="smart"),
                timeout(seconds=30),
            ),
            then=self.finish,
        )

    @step
    async def finish(
        self,
        fast: Annotated[Answer | None, step_arg.CHILD("fast")],
        smart: Annotated[Answer | None, step_arg.CHILD("smart")],
        expired: TimeoutExpired | None,
    ) -> RaceResult:
        if expired:
            return RaceResult(winner="none", answer="Timed out")
        winner = fast or smart
        assert winner is not None
        return RaceResult(winner="fast" if fast else "smart", answer=winner.text)
```

`WhenAny` cancels the losers via cooperative interruption.

## Partial results (WhenN)

Wait for N out of M workers, cancel the rest:

```python
class BestOfThree(Agent[SearchQuery, MergedResults]):
    @step(entry=True)
    async def start(self, spec: SearchQuery) -> Spawn:
        return Spawn(
            WhenN(
                CallAgent(agent=WorkerAgent, spec=WorkSpec(query=spec.query, strategy="a")),
                CallAgent(agent=WorkerAgent, spec=WorkSpec(query=spec.query, strategy="b")),
                CallAgent(agent=WorkerAgent, spec=WorkSpec(query=spec.query, strategy="c")),
                n=2,  # take first 2, cancel the slowest
            ),
            then=self.merge,
        )

    @step
    async def merge(self, results: list[SearchResult]) -> MergedResults:
        return MergedResults(all_items=[item for r in results for item in r.items])
```

`WhenN` is a middle ground between `WhenAll` (wait for everyone) and `WhenAny`
(first wins). Workers that finish after the Nth are cancelled.

## Feedback loop

Writer produces a draft, reviewer critiques it, writer revises — repeat until
approved or max iterations reached:

```python
class FeedbackLoop(Agent[WritingTask, FinalDraft]):
    MAX_ITERATIONS = 3

    def __init__(self, spec: WritingTask, store: AgentStore) -> None:
        self.topic = spec.topic
        self.iteration = store.persistent.slot(Scalar[int], "iteration")
        self.last_feedback = store.persistent.slot(Scalar[str], "last_feedback")

    @step(entry=True)
    async def write(self) -> Spawn:
        feedback = self.last_feedback.get(None)
        return Spawn(
            CallAgent(agent=WriterAgent, spec=Draft(text=self.topic, feedback=feedback)),
            then=self.review,
        )

    @step
    async def review(self, draft: Draft) -> Spawn | FinalDraft:
        n = self.iteration.get(0) + 1
        self.iteration.set(n)
        if n >= self.MAX_ITERATIONS:
            return FinalDraft(text=draft.text, iterations=n)
        return Spawn(
            CallAgent(agent=ReviewerAgent, spec=draft),
            then=self.decide,
        )

    @step
    async def decide(self, review: Review) -> GotoStep | FinalDraft:
        if review.approved:
            return FinalDraft(text="...", iterations=self.iteration.get(0))
        self.last_feedback.set(review.feedback)
        return GotoStep(step=self.write)
```

State (`iteration`, `last_feedback`) is persisted — if the process crashes
mid-loop, it resumes from the last completed step.

## Escalation

Start with a fast (cheap) model. If a tool detects it needs more capability,
it interrupts the current agent tree and the parent retries with a smarter model.

The bridge between tools and the agent is a shared service. Tools call
`request_escalation()`, which sets a reason flag and interrupts all children.
The parent checks the flag to distinguish escalation from other interrupts
(timeouts, user cancellation):

```python
class TierService:
    """Shared service: tools call request_escalation() when they need a smarter model."""

    def __init__(self, interrupt_control: InterruptControl) -> None:
        self.tier = "fast"
        self.escalation_reason: str | None = None
        self.interrupt_control = interrupt_control

    def request_escalation(self, reason: str) -> None:
        self.escalation_reason = reason
        self.interrupt_control.interrupt_children()
```

A tool checks the current tier and escalates if needed:

```python
@tool("analyze")
def analyze(params: AnalyzeParams, tier_service: TierService) -> str:
    """Analyze a document. Deep analysis requires a smart model."""
    if params.depth != "basic" and tier_service.tier == "fast":
        tier_service.request_escalation("deep analysis requires a smart model")
        raise ValueError("need smarter model")
    return f"Analysis result for '{params.topic}'"
```

The orchestrator catches the interruption and retries:

```python
class EscalationAgent(Agent[EscalationSpec, ChatResult]):
    def __init__(
        self,
        store: AgentStore,
        services: ServiceLocator,
        spec: EscalationSpec,
        interrupt_control: InterruptControl,
    ) -> None:
        self.spec = spec
        self.current_model = store.persistent.slot(Scalar[str], "current_model")
        self.tier_service = TierService(interrupt_control=interrupt_control)
        services.provide(self.tier_service)  # tools receive it via DI

    @step(entry=True)
    async def run_fast(self, spec: EscalationSpec) -> Spawn:
        self.current_model.set(spec.fast_model)
        return Spawn(
            CallAgent(agent=ChatAgent, spec=ChatSpec(messages=spec.messages), tag="chat"),
            then=self.check_result,
        )

    @step
    async def check_result(
        self,
        result: Annotated[ChatResult | Interrupted, step_arg.CHILD("chat")],
    ) -> ChatResult | Spawn | Interrupted:
        if not isinstance(result, Interrupted):
            return result
        if self.tier_service.escalation_reason is None:
            return result  # real interrupt (timeout, user cancel) — propagate as-is
        # Escalation requested — switch to smart model
        self.current_model.set(self.spec.smart_model)
        self.tier_service.tier = "smart"
        self.tier_service.escalation_reason = None
        return Spawn(
            CallAgent(agent=ChatAgent, spec=ChatSpec(messages=self.spec.messages), tag="retry"),
            then=self.return_result,
        )

    @step
    async def return_result(self, result: ChatResult) -> ChatResult:
        return result
```

The key primitives: `InterruptControl.interrupt_children()` stops the current
model, `Interrupted` in the result type lets the parent handle it, and DI
connects the `TierService` between the agent and its tools.

## Composing timeouts

Timeouts compose naturally with other strategies:

```python
# Fan-out with global timeout
Spawn(
    WhenAny(
        WhenAll(worker_a, worker_b, worker_c),
        timeout(minutes=5),
    ),
    then=self.collect,
)

# Race with per-contestant + global timeout
Spawn(
    WhenAny(
        WhenAny(contestant_a, timeout(seconds=10)),
        WhenAny(contestant_b, timeout(seconds=10)),
        timeout(seconds=30),
    ),
    then=self.finish,
)
```

---

**Prev:** [Agents](agents.md) | **Next:** [Observability](observability.md)
