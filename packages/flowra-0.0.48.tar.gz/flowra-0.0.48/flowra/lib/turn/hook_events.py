# NOT frozen: handlers can mutate fields to communicate
# outcomes back to the agent.

import dataclasses
from typing import Any

from ...llm import AssistantMessage, LLMRequest, TextBlock, ThinkingBlock, ToolResultBlock, ToolUseBlock, UserMessage
from ...tools import ToolDefinition, ToolErrorKind
from .context import TurnAgentContext

__all__ = [
    "AfterToolCallEvent",
    "BeforeToolCallEvent",
    "MessageAcceptedEvent",
    "PrepareLLMRequestEvent",
    "ResultMessageEvent",
    "ServerToolCallEvent",
    "ServerToolResultEvent",
    "StartIterationEvent",
    "StartTurnEvent",
    "TextReasoningEvent",
    "ThinkingEvent",
]


@dataclasses.dataclass(slots=True, kw_only=True)
class StartTurnEvent:
    """Emitted once at the start of each turn, before the first LLM call.

    ``context`` — inspect or configure the ``TurnAgentContext``
    (e.g. set flags, attach metadata).

    ``messages`` — the messages for this turn. Mutate to augment
    or transform the input (e.g. inject a system reminder, add media blocks).
    """

    context: TurnAgentContext
    messages: list[UserMessage | AssistantMessage]
    metadata: dict[str, Any]


@dataclasses.dataclass(slots=True, kw_only=True)
class MessageAcceptedEvent:
    """Emitted once after messages are accepted (including on resume).

    Observation-only — use for tracking, logging, or UI updates.
    """

    messages: list[UserMessage | AssistantMessage]
    metadata: dict[str, Any]


@dataclasses.dataclass(slots=True, kw_only=True)
class StartIterationEvent:
    """Emitted at the start of each tool loop iteration, before the LLM call.

    Append to ``additional_messages`` to inject dynamic context
    (e.g. current time, remaining budget) before each LLM call.
    """

    iteration: int
    context: TurnAgentContext
    additional_messages: list[UserMessage] = dataclasses.field(default_factory=list)


@dataclasses.dataclass(slots=True, kw_only=True)
class PrepareLLMRequestEvent:
    """Emitted after ``LLMRequest`` is built but before the LLM call.

    Replace ``request`` to modify messages, tools, or any other request field
    (e.g. for prompt caching, tool deferral, or other provider-specific transforms).
    """

    request: LLMRequest


@dataclasses.dataclass(slots=True, kw_only=True)
class ResultMessageEvent:
    """Emitted when LLM returns a final response (END_TURN) with no tool calls.

    Append to ``continue_messages`` to force the loop to continue
    instead of finishing (e.g. for review/feedback cycles).
    """

    message: AssistantMessage
    context: TurnAgentContext
    continue_messages: list[UserMessage] = dataclasses.field(default_factory=list)


@dataclasses.dataclass(slots=True, kw_only=True)
class BeforeToolCallEvent:
    """Emitted before each tool execution.

    Replace ``tool_use`` to modify tool parameters (e.g. sanitize input,
    inject defaults).
    """

    tool_use: ToolUseBlock
    tool_definition: ToolDefinition | None
    context: TurnAgentContext


@dataclasses.dataclass(slots=True, kw_only=True)
class AfterToolCallEvent:
    """Emitted after each tool execution.

    Replace ``result`` to modify tool output (e.g. sanitize errors, redact PII).
    Append to ``additional_messages`` to inject context after the tool call.
    """

    tool_use: ToolUseBlock
    result: ToolResultBlock
    error_kind: ToolErrorKind | None
    context: TurnAgentContext
    additional_messages: list[UserMessage] = dataclasses.field(default_factory=list)


@dataclasses.dataclass(slots=True, kw_only=True)
class ServerToolCallEvent:
    """Emitted for each ``ToolUseBlock`` in an intermediate ``AssistantMessage``.

    Observation-only — fired for server-side tool calls that the provider
    resolved within a single API response (e.g. OpenAI tool search).
    """

    tool_use: ToolUseBlock
    context: TurnAgentContext


@dataclasses.dataclass(slots=True, kw_only=True)
class ServerToolResultEvent:
    """Emitted for each ``ToolResultBlock`` in an intermediate ``UserMessage``.

    Observation-only — fired for server-side tool results that the provider
    resolved within a single API response (e.g. OpenAI tool search output).
    """

    result: ToolResultBlock
    context: TurnAgentContext


@dataclasses.dataclass(slots=True, kw_only=True)
class TextReasoningEvent:
    """Emitted for each ``TextBlock`` in the LLM response.

    Observation-only — use for displaying reasoning text.
    """

    text: TextBlock
    context: TurnAgentContext


@dataclasses.dataclass(slots=True, kw_only=True)
class ThinkingEvent:
    """Emitted for each ``ThinkingBlock`` in the LLM response.

    Observation-only — use for displaying extended thinking.
    """

    thinking: ThinkingBlock
    context: TurnAgentContext
