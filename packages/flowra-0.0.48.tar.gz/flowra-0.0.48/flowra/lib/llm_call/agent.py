import logging
import time

from ...agent import Agent, Hooks, InterruptedError, InterruptToken, step, with_interrupt
from ...llm import ContentComplete, LLMProvider, LLMRequest, TextDelta, ThinkingDelta
from ..config_value import resolve_config_value
from ..llm_config import LLMConfig
from ..observability import LLMCallSpan, TextDeltaEvent, ThinkingDeltaEvent
from .spec import LLMCallResult, LLMCallSpec

__all__ = ["LLMCallAgent"]

logger = logging.getLogger(__name__)


class LLMCallAgent(Agent[LLMCallSpec, LLMCallResult]):
    __slots__ = ("__hooks", "__interrupt", "__llm_config", "__provider")

    def __init__(
        self,
        provider: LLMProvider,
        interrupt: InterruptToken,
        hooks: Hooks,
        llm_config: LLMConfig,
    ) -> None:
        self.__provider = provider
        self.__interrupt = interrupt
        self.__hooks = hooks
        self.__llm_config = llm_config

    @step(entry=True)
    async def call(self, spec: LLMCallSpec) -> LLMCallResult:
        self.__interrupt.check()

        llm_config = await resolve_config_value(self.__llm_config)

        request = LLMRequest(
            model=llm_config.model,
            system=list(spec.system),
            messages=list(spec.messages),
            temperature=llm_config.temperature,
            top_p=llm_config.top_p,
            max_tokens=llm_config.max_tokens,
            stop_sequences=llm_config.stop_sequences,
            extra=llm_config.extra,
        )

        t0 = time.monotonic()
        try:
            async with self.__hooks.span(LLMCallSpan(request=request)) as llm_span:
                if self.__hooks.has_handlers(TextDeltaEvent) or self.__hooks.has_handlers(ThinkingDeltaEvent):
                    response = None
                    async for event in with_interrupt(self.__provider.stream(request), self.__interrupt):
                        match event:
                            case TextDelta(text=text):
                                await self.__hooks.emit(TextDeltaEvent(text=text))
                            case ThinkingDelta(text=text):
                                await self.__hooks.emit(ThinkingDeltaEvent(text=text))
                            case ContentComplete(response=resp):
                                response = resp
                    assert response is not None
                else:
                    response = await self.__provider.call(request)
                llm_span.response = response
        except InterruptedError:
            raise
        except Exception as e:
            logger.exception("LLM call failed")
            elapsed = time.monotonic() - t0
            return LLMCallResult(error=f"LLM call failed: {e}", elapsed=elapsed)
        elapsed = time.monotonic() - t0

        return LLMCallResult(message=response.message, usage=response.usage, elapsed=elapsed)
