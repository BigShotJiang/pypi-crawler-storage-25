import logging
from collections.abc import Awaitable, Callable
from typing import Any, get_args, get_origin

from ..services import ServiceLocator
from ..state import AgentStore, AppendOnlyList, Scalar, Scope
from ..storage import ChangeSet

logger = logging.getLogger(__name__)

__all__ = ["FlushCallback", "NamedScopeRegistry", "RuntimeScope", "ScopeData"]

type FlushCallback = Callable[[], Awaitable[None]]


class ScopeData(Scope):
    """Concrete scope implementation: slot storage, dirty tracking, hydration."""

    __slots__ = (
        "__append_only_lists",
        "__scalars",
        "__slot_value_types",
        "__type_registry",
    )

    def __init__(self) -> None:
        self.__scalars: dict[str, Scalar] = {}
        self.__append_only_lists: dict[str, AppendOnlyList] = {}
        self.__slot_value_types: dict[str, type] = {}
        self.__type_registry: dict[str, type] = {}

    def slot(self, cls: Any, key: str) -> Any:
        origin = get_origin(cls) or cls
        args = get_args(cls)
        if origin is Scalar:
            if args:
                self.__slot_value_types[key] = args[0]
            return self.__create_scalar(key)
        if origin is AppendOnlyList:
            if args:
                self.__slot_value_types[key] = args[0]
            return self.__create_append_only(key)
        raise TypeError(f"slot() cls must be Scalar[T] or AppendOnlyList[T], got {cls!r}")

    def get_slot_value_types(self) -> dict[str, type]:
        return dict(self.__slot_value_types)

    @property
    def type_registry(self) -> dict[str, type]:
        return self.__type_registry

    def __create_scalar(self, key: str) -> Scalar:
        if key in self.__scalars:
            return self.__scalars[key]
        value: Scalar = Scalar()
        self.__scalars[key] = value
        return value

    def __create_append_only(self, key: str) -> AppendOnlyList:
        if key in self.__append_only_lists:
            return self.__append_only_lists[key]
        al: AppendOnlyList = AppendOnlyList()
        self.__append_only_lists[key] = al
        return al

    def fork(self) -> "ScopeData":
        child = ScopeData()
        for key, sv in self.__scalars.items():
            child_sv: Scalar = Scalar()
            if sv.has_value():
                child_sv.restore(sv.get())
            child.__scalars[key] = child_sv
        for key, al in self.__append_only_lists.items():
            child_al: AppendOnlyList = AppendOnlyList()
            child_al.restore(al.get_all())
            child.__append_only_lists[key] = child_al
        return child

    def get_changes(self) -> ChangeSet:
        scalars: dict[str, Any] = {}
        appends: dict[str, list[Any]] = {}
        for key, sv in self.__scalars.items():
            if sv.is_dirty():
                scalars[key] = sv.get()
        for key, al in self.__append_only_lists.items():
            unflushed = al.get_unflushed()
            if unflushed:
                appends[key] = unflushed
        return ChangeSet(scalars=scalars, appends=appends)

    def mark_clean(self) -> None:
        for sv in self.__scalars.values():
            sv.mark_clean()
        for al in self.__append_only_lists.values():
            al.mark_clean()

    def snapshot(self) -> dict[str, Any]:
        data: dict[str, Any] = {}
        for key, sv in self.__scalars.items():
            if sv.has_value():
                data[key] = sv.get()
        for key, al in self.__append_only_lists.items():
            data[key] = al.get_all()
        return data

    def hydrate(self, data: dict[str, Any]) -> None:
        for key, value in data.items():
            if key in self.__scalars:
                self.__scalars[key].restore(value)
            elif key in self.__append_only_lists:
                self.__append_only_lists[key].restore(value)
            else:
                logger.warning("hydrate: unknown key %r (not declared as scalar or append_only), skipping", key)


class NamedScopeRegistry:
    """Session-wide registry of named scopes. Created by AgentRuntime, shared across all RuntimeScope instances."""

    __slots__ = ("__hydrated", "__scopes")

    def __init__(self) -> None:
        self.__scopes: dict[str, ScopeData] = {}
        self.__hydrated: set[str] = set()

    def get_or_create(self, name: str) -> ScopeData:
        if name not in self.__scopes:
            self.__scopes[name] = ScopeData()
        return self.__scopes[name]

    def all_scopes(self) -> dict[str, ScopeData]:
        return dict(self.__scopes)

    def is_hydrated(self, name: str) -> bool:
        return name in self.__hydrated

    def mark_hydrated(self, name: str) -> None:
        self.__hydrated.add(name)


class RuntimeScope(AgentStore, ServiceLocator):
    """AgentStore + ServiceLocator for agents. Provides access to ephemeral, persistent, and named scopes."""

    __slots__ = (
        "__ephemeral",
        "__flush_callback",
        "__named_scope_registry",
        "__parent_services",
        "__persistent",
        "__services",
    )

    def __init__(
        self,
        parent_services: dict[type, Any] | None = None,
        *,
        named_scope_registry: NamedScopeRegistry,
        ephemeral: ScopeData | None = None,
        persistent: ScopeData | None = None,
    ) -> None:
        self.__parent_services: dict[type, Any] = parent_services or {}
        self.__services: dict[type, Any] = {}
        self.__flush_callback: FlushCallback | None = None
        self.__named_scope_registry = named_scope_registry
        self.__ephemeral = ephemeral or ScopeData()
        self.__persistent = persistent or ScopeData()

    @property
    def ephemeral(self) -> ScopeData:
        return self.__ephemeral

    @property
    def persistent(self) -> ScopeData:
        return self.__persistent

    def scope(self, name: str) -> Scope:
        return self.__named_scope_registry.get_or_create(name)

    @property
    def named_scope_registry(self) -> NamedScopeRegistry:
        return self.__named_scope_registry

    def fork_ephemeral(self, parent_services: dict[type, Any] | None = None) -> "RuntimeScope":
        """Create a child scope with forked ephemeral state. Persistent and named scopes stay shared."""
        return RuntimeScope(
            parent_services=parent_services,
            named_scope_registry=self.__named_scope_registry,
            ephemeral=self.__ephemeral.fork(),
            persistent=self.__persistent,
        )

    def _do_provide(self, service_type: type, instance: Any) -> None:
        if not isinstance(instance, service_type):
            raise TypeError(f"Expected instance of {service_type.__name__}, got {type(instance).__name__}")
        self.__services[service_type] = instance

    async def flush(self) -> None:
        if self.__flush_callback is not None:
            await self.__flush_callback()

    @property
    def services(self) -> dict[type, Any]:
        return self.get_services()

    def get_services(self) -> dict[type, Any]:
        return {**self.__parent_services, **self.__services}

    def get_inherited_services(self) -> dict[type, Any]:
        return dict(self.__parent_services)

    def set_flush_callback(self, callback: FlushCallback) -> None:
        self.__flush_callback = callback
