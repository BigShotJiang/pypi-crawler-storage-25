from typing import Any

from ..definition import AgentDefinition, AgentInstance
from ..definition.compile import collect_dataclass_types
from ..services import ServiceLocator
from ..state import AgentStore, Scope
from .scope import RuntimeScope

__all__ = ["create_instance_sealed"]


class _SealedScope(AgentStore, ServiceLocator):
    __slots__ = ("__scope", "__sealed")

    def __init__(self, scope: RuntimeScope) -> None:
        self.__scope = scope
        self.__sealed = False

    def seal(self) -> None:
        self.__sealed = True

    @property
    def ephemeral(self) -> Scope:
        if self.__sealed:
            raise RuntimeError("ephemeral can only be accessed during agent construction")
        return self.__scope.ephemeral

    @property
    def persistent(self) -> Scope:
        if self.__sealed:
            raise RuntimeError("persistent can only be accessed during agent construction")
        return self.__scope.persistent

    def scope(self, name: str) -> Scope:
        if self.__sealed:
            raise RuntimeError("scope() can only be called during agent construction")
        return self.__scope.scope(name)

    def _do_provide(self, service_type: type, instance: Any) -> None:
        if self.__sealed:
            raise RuntimeError("provide() can only be called during agent construction")
        self.__scope.provide(service_type, instance)

    async def flush(self) -> None:
        await self.__scope.flush()

    @property
    def services(self) -> dict[type, Any]:
        return self.__scope.services


def create_instance_sealed(
    defn: AgentDefinition,
    scope: RuntimeScope,
    services: dict[type, Any],
    agent_spec: Any | None = None,
) -> AgentInstance:
    sealed = _SealedScope(scope)
    for st, inst in services.items():
        if st not in (AgentStore, ServiceLocator):
            scope.provide(st, inst)
    scope.provide(AgentStore, sealed)
    scope.provide(ServiceLocator, sealed)
    instance = defn.create_instance(sealed, agent_spec)
    sealed.seal()

    # Collect types for ephemeral scope
    for value_type in scope.ephemeral.get_slot_value_types().values():
        collect_dataclass_types(value_type, defn.type_registry)

    # Collect types for persistent scope
    for value_type in scope.persistent.get_slot_value_types().values():
        collect_dataclass_types(value_type, defn.type_registry)

    # Collect types for named scopes
    for named_scope in scope.named_scope_registry.all_scopes().values():
        for value_type in named_scope.get_slot_value_types().values():
            collect_dataclass_types(value_type, named_scope.type_registry)

    return instance
