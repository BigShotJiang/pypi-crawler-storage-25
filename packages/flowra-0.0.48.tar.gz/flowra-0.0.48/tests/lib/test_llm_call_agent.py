from collections.abc import AsyncIterator

from flowra.agent import AgentRuntime, Event, HookSubscription, Interrupted, SpanExitHandler
from flowra.agent.flow.hooks import HooksImpl
from flowra.lib import LLMConfig
from flowra.lib.llm_call import LLMCallAgent, LLMCallResult, LLMCallSpec
from flowra.lib.observability import LLMCallSpan, TextDeltaEvent, ThinkingDeltaEvent
from flowra.llm import (
    AssistantMessage,
    ContentComplete,
    LLMProvider,
    LLMRequest,
    LLMResponse,
    StopReason,
    StreamEvent,
    SystemMessage,
    TextBlock,
    TextDelta,
    ThinkingDelta,
    Usage,
    UserMessage,
)


class TestLLMCallAgent:
    async def test_simple_call_returns_result(self) -> None:
        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Hello!")])],
                    stop_reason=StopReason.END_TURN,
                )

        runtime = AgentRuntime(
            agents={"llm_call": LLMCallAgent},
            services={LLMProvider: MockProvider(), LLMConfig: LLMConfig(model="test")},
        )

        result = await runtime.run(
            agent=LLMCallAgent,
            spec=LLMCallSpec(messages=[UserMessage(blocks=[TextBlock(text="Hi")])]),
        )

        assert isinstance(result, LLMCallResult)
        assert result.message is not None
        assert isinstance(result.message.blocks[0], TextBlock)
        assert result.message.blocks[0].text == "Hello!"

    async def test_passes_messages_to_provider(self) -> None:
        received_requests: list[LLMRequest] = []

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                received_requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="ok")])],
                    stop_reason=StopReason.END_TURN,
                )

        system = [SystemMessage(blocks=[TextBlock(text="You are helpful.")])]
        messages: list[UserMessage | AssistantMessage] = [
            UserMessage(blocks=[TextBlock(text="Hi")]),
        ]
        runtime = AgentRuntime(
            agents={"llm_call": LLMCallAgent},
            services={LLMProvider: MockProvider(), LLMConfig: LLMConfig(model="test")},
        )

        await runtime.run(agent=LLMCallAgent, spec=LLMCallSpec(system=system, messages=messages))

        assert len(received_requests) == 1
        assert len(received_requests[0].system) == 1
        assert isinstance(received_requests[0].system[0], SystemMessage)
        assert len(received_requests[0].messages) == 1
        assert isinstance(received_requests[0].messages[0], UserMessage)

    async def test_uses_llm_config(self) -> None:
        received_request: list[LLMRequest] = []

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                received_request.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="ok")])],
                    stop_reason=StopReason.END_TURN,
                )

        config = LLMConfig(model="my-model", temperature=0.5, top_p=0.9, max_tokens=100)
        runtime = AgentRuntime(
            agents={"llm_call": LLMCallAgent},
            services={LLMProvider: MockProvider(), LLMConfig: config},
        )

        await runtime.run(
            agent=LLMCallAgent,
            spec=LLMCallSpec(messages=[UserMessage(blocks=[TextBlock(text="Hi")])]),
        )

        assert len(received_request) == 1
        assert received_request[0].model == "my-model"
        assert received_request[0].temperature == 0.5
        assert received_request[0].top_p == 0.9
        assert received_request[0].max_tokens == 100

    async def test_returns_usage(self) -> None:
        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="ok")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        runtime = AgentRuntime(
            agents={"llm_call": LLMCallAgent},
            services={LLMProvider: MockProvider(), LLMConfig: LLMConfig(model="test")},
        )

        result = await runtime.run(
            agent=LLMCallAgent,
            spec=LLMCallSpec(messages=[UserMessage(blocks=[TextBlock(text="Hi")])]),
        )

        assert isinstance(result, LLMCallResult)
        assert result.usage is not None
        assert result.usage.input_tokens == 10
        assert result.usage.output_tokens == 5

    async def test_no_delta_hooks_uses_call(self) -> None:
        class TrackingProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0
                self.stream_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Hello")])],
                    stop_reason=StopReason.END_TURN,
                )

            async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
                self.stream_count += 1
                yield ContentComplete(
                    response=LLMResponse(
                        messages=[AssistantMessage(blocks=[TextBlock(text="Hello")])],
                        stop_reason=StopReason.END_TURN,
                    )
                )

        provider = TrackingProvider()
        runtime = AgentRuntime(
            agents={"llm_call": LLMCallAgent},
            services={LLMProvider: provider, LLMConfig: LLMConfig(model="test")},
        )

        await runtime.run(
            agent=LLMCallAgent,
            spec=LLMCallSpec(messages=[UserMessage(blocks=[TextBlock(text="Hi")])]),
        )

        assert provider.call_count == 1
        assert provider.stream_count == 0

    async def test_text_delta_hook_enables_streaming(self) -> None:
        received_deltas: list[str] = []

        def on_delta(event: Event[TextDeltaEvent]) -> None:
            received_deltas.append(event.data.text)

        class StreamingProvider(LLMProvider):
            def __init__(self) -> None:
                self.stream_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                raise AssertionError("Should use stream()")

            async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
                self.stream_count += 1
                yield TextDelta(text="Hello")
                yield TextDelta(text=" world")
                yield ContentComplete(
                    response=LLMResponse(
                        messages=[AssistantMessage(blocks=[TextBlock(text="Hello world")])],
                        stop_reason=StopReason.END_TURN,
                    )
                )

        provider = StreamingProvider()
        hooks = HooksImpl()
        hooks.on(TextDeltaEvent, on_delta)

        runtime = AgentRuntime(
            agents={"llm_call": LLMCallAgent},
            services={LLMProvider: provider, LLMConfig: LLMConfig(model="test"), HookSubscription: hooks},
        )

        result = await runtime.run(
            agent=LLMCallAgent,
            spec=LLMCallSpec(messages=[UserMessage(blocks=[TextBlock(text="Hi")])]),
        )

        assert isinstance(result, LLMCallResult)
        assert result.message is not None
        block = result.message.blocks[0]
        assert isinstance(block, TextBlock)
        assert block.text == "Hello world"
        assert received_deltas == ["Hello", " world"]
        assert provider.stream_count == 1

    async def test_thinking_delta_hook_enables_streaming(self) -> None:
        received_thinking: list[str] = []

        def on_thinking(event: Event[ThinkingDeltaEvent]) -> None:
            received_thinking.append(event.data.text)

        class StreamingProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                raise AssertionError("Should use stream()")

            async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
                yield ThinkingDelta(text="thinking...")
                yield TextDelta(text="answer")
                yield ContentComplete(
                    response=LLMResponse(
                        messages=[AssistantMessage(blocks=[TextBlock(text="answer")])],
                        stop_reason=StopReason.END_TURN,
                    )
                )

        hooks = HooksImpl()
        hooks.on(ThinkingDeltaEvent, on_thinking)

        runtime = AgentRuntime(
            agents={"llm_call": LLMCallAgent},
            services={LLMProvider: StreamingProvider(), LLMConfig: LLMConfig(model="test"), HookSubscription: hooks},
        )

        await runtime.run(
            agent=LLMCallAgent,
            spec=LLMCallSpec(messages=[UserMessage(blocks=[TextBlock(text="Hi")])]),
        )

        assert received_thinking == ["thinking..."]

    async def test_before_and_after_hooks(self) -> None:
        events_log: list[str] = []

        def llm_span_handler(event: Event[LLMCallSpan]) -> SpanExitHandler:
            span = event.data
            events_log.append(f"before:{span.request.model}")

            def on_exit(error: BaseException | None = None) -> None:
                assert span.response is not None
                block = span.response.message.blocks[0]
                assert isinstance(block, TextBlock)
                events_log.append(f"after:{block.text}")

            return on_exit

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="reply")])],
                    stop_reason=StopReason.END_TURN,
                )

        hooks = HooksImpl()
        hooks.on_span(LLMCallSpan, llm_span_handler)

        runtime = AgentRuntime(
            agents={"llm_call": LLMCallAgent},
            services={LLMProvider: MockProvider(), LLMConfig: LLMConfig(model="my-model"), HookSubscription: hooks},
        )

        await runtime.run(
            agent=LLMCallAgent,
            spec=LLMCallSpec(messages=[UserMessage(blocks=[TextBlock(text="Hi")])]),
        )

        assert events_log == ["before:my-model", "after:reply"]

    async def test_interrupt_during_streaming(self) -> None:
        received_deltas: list[str] = []
        runtime_ref: list[AgentRuntime] = []

        def on_delta(event: Event[TextDeltaEvent]) -> None:
            received_deltas.append(event.data.text)
            if event.data.text == "second":
                runtime_ref[0].interrupt()

        class SlowStreamProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="done")])],
                    stop_reason=StopReason.END_TURN,
                )

            async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
                yield TextDelta(text="first")
                yield TextDelta(text="second")
                yield TextDelta(text="third")
                yield ContentComplete(
                    response=LLMResponse(
                        messages=[AssistantMessage(blocks=[TextBlock(text="first second third")])],
                        stop_reason=StopReason.END_TURN,
                    )
                )

        hooks = HooksImpl()
        hooks.on(TextDeltaEvent, on_delta)

        runtime = AgentRuntime(
            agents={"llm_call": LLMCallAgent},
            services={LLMProvider: SlowStreamProvider(), LLMConfig: LLMConfig(model="test"), HookSubscription: hooks},
        )
        runtime_ref.append(runtime)

        result = await runtime.run(
            agent=LLMCallAgent,
            spec=LLMCallSpec(messages=[UserMessage(blocks=[TextBlock(text="Hi")])]),
        )

        assert isinstance(result, Interrupted)
        assert received_deltas == ["first", "second"]

    async def test_interrupt_before_call(self) -> None:
        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                raise AssertionError("Should not be called")

        runtime = AgentRuntime(
            agents={"llm_call": LLMCallAgent},
            services={LLMProvider: MockProvider(), LLMConfig: LLMConfig(model="test")},
        )
        runtime.interrupt()

        result = await runtime.run(
            agent=LLMCallAgent,
            spec=LLMCallSpec(messages=[UserMessage(blocks=[TextBlock(text="Hi")])]),
        )

        assert isinstance(result, Interrupted)

    async def test_llm_exception_returns_error_result(self) -> None:
        class FailingProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                raise RuntimeError("Connection refused")

        runtime = AgentRuntime(
            agents={"llm_call": LLMCallAgent},
            services={LLMProvider: FailingProvider(), LLMConfig: LLMConfig(model="test")},
        )

        result = await runtime.run(
            agent=LLMCallAgent,
            spec=LLMCallSpec(messages=[UserMessage(blocks=[TextBlock(text="Hi")])]),
        )

        assert isinstance(result, LLMCallResult)
        assert result.message is None
        assert result.error is not None
        assert "Connection refused" in result.error
        assert result.elapsed > 0
