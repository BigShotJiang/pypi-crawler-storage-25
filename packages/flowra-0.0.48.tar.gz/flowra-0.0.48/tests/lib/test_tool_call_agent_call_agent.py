import dataclasses
from typing import Annotated

import pytest

from flowra.agent import Agent, AgentRuntime, InMemorySessionStorage, step, step_arg
from flowra.agent.definition import AgentDefinition
from flowra.lib import LLMConfig
from flowra.lib.turn import TurnConfig
from flowra.lib.turn.tool_call import (
    ToolCallAgent,
    ToolCallAgentContext,
    ToolCallResult,
    ToolCallSpec,
    agent_tool,
    get_agent_tool,
    make_agent_tool,
)
from flowra.llm import ToolUseBlock
from flowra.tools import ToolErrorKind, ToolRegistry, ToolResult, tool

# -- Test agent that will be spawned via call_agent --


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GreetSpec:
    name: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GreetResult:
    greeting: str


class GreetAgent(Agent[GreetSpec, GreetResult]):
    @step(entry=True)
    async def greet(self, spec: Annotated[GreetSpec, step_arg.SPEC]) -> GreetResult:
        return GreetResult(greeting=f"Hello, {spec.name}!")


# -- Tools --


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class DelegateParams:
    name: str


@tool("delegate")
def delegate_tool(params: DelegateParams, ctx: ToolCallAgentContext) -> None:
    """Delegate greeting to GreetAgent."""
    ctx.call_agent(GreetAgent, GreetSpec(name=params.name))


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class NoopParams:
    pass


@tool("noop")
def noop_tool(params: NoopParams) -> str:
    """Simple tool that does not call_agent."""
    return "done"


class TestToolCallAgentCallAgent:
    async def test_call_agent_spawns_and_returns_result(self) -> None:
        registry = ToolRegistry([delegate_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "greet": GreetAgent},
            services={
                TurnConfig: TurnConfig(tools=registry, llm_config=LLMConfig(model="test"), system=[], history=[])
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="delegate", input={"name": "World"})

        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use),
        )

        assert isinstance(result, ToolCallResult)
        assert result.tool_use == tool_use
        assert result.result.tool_use_id == "call_1"
        assert result.result.is_error is False
        assert '"Hello, World!"' in result.result.content

    async def test_no_call_agent_returns_normal_result(self) -> None:
        registry = ToolRegistry([noop_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent},
            services={
                TurnConfig: TurnConfig(tools=registry, llm_config=LLMConfig(model="test"), system=[], history=[])
            },
        )

        tool_use = ToolUseBlock(id="call_2", name="noop", input={})

        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.content == "done"
        assert result.result.is_error is False

    async def test_call_agent_twice_raises(self) -> None:
        """Calling call_agent() twice in one tool execution raises RuntimeError."""
        ctx = ToolCallAgentContext()
        ctx.call_agent(GreetAgent, GreetSpec(name="A"))

        with pytest.raises(RuntimeError, match=r"call_agent.*once"):
            ctx.call_agent(GreetAgent, GreetSpec(name="B"))


class TestMakeAgentTool:
    async def test_make_agent_tool_creates_working_tool(self) -> None:
        local_tool = make_agent_tool(GreetAgent, name="greet", description="Greet someone")
        assert local_tool.definition.name == "greet"
        assert local_tool.definition.description == "Greet someone"
        assert local_tool.definition.input_schema is not None
        assert "name" in local_tool.definition.input_schema.get("properties", {})
        assert local_tool.definition.output_schema is not None
        assert "greeting" in local_tool.definition.output_schema.get("properties", {})

        registry = ToolRegistry([local_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "greet": GreetAgent},
            services={
                TurnConfig: TurnConfig(tools=registry, llm_config=LLMConfig(model="test"), system=[], history=[])
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="greet", input={"name": "Alice"})
        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is False
        assert '"Hello, Alice!"' in result.result.content

    async def test_make_agent_tool_with_string_ref(self) -> None:
        local_tool = make_agent_tool(GreetAgent, name="greet", description="Greet", agent_ref="greet")

        registry = ToolRegistry([local_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "greet": GreetAgent},
            services={
                TurnConfig: TurnConfig(tools=registry, llm_config=LLMConfig(model="test"), system=[], history=[])
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="greet", input={"name": "Bob"})
        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is False
        assert '"Hello, Bob!"' in result.result.content


class TestAgentToolDecorator:
    async def test_decorator_and_get_agent_tool(self) -> None:
        @agent_tool(name="greet2", description="Greet v2")
        class DecoratedGreetAgent(Agent[GreetSpec, GreetResult]):
            @step(entry=True)
            async def greet(self, spec: Annotated[GreetSpec, step_arg.SPEC]) -> GreetResult:
                return GreetResult(greeting=f"Hi, {spec.name}!")

        local_tool = get_agent_tool(DecoratedGreetAgent)
        assert local_tool.definition.name == "greet2"
        assert local_tool.definition.description == "Greet v2"

        registry = ToolRegistry([local_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "greet2": DecoratedGreetAgent},
            services={
                TurnConfig: TurnConfig(tools=registry, llm_config=LLMConfig(model="test"), system=[], history=[])
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="greet2", input={"name": "Eve"})
        result = await runtime.run(
            agent=ToolCallAgent,
            spec=ToolCallSpec(tool_use=tool_use),
        )

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is False
        assert '"Hi, Eve!"' in result.result.content

    def test_get_agent_tool_raises_for_undecorated(self) -> None:
        with pytest.raises(ValueError, match="not decorated"):
            get_agent_tool(GreetAgent)


class TestAgentToolDescriptionFromDocstring:
    def test_make_agent_tool_uses_class_docstring(self) -> None:
        class DocstringAgent(Agent[GreetSpec, GreetResult]):
            """Greet someone nicely."""

            @step(entry=True)
            async def greet(self, spec: Annotated[GreetSpec, step_arg.SPEC]) -> GreetResult:
                return GreetResult(greeting=f"Hello, {spec.name}!")

        local_tool = make_agent_tool(DocstringAgent, name="greet_doc")
        assert local_tool.definition.description == "Greet someone nicely."

    def test_make_agent_tool_explicit_description_overrides_docstring(self) -> None:
        class DocstringAgent2(Agent[GreetSpec, GreetResult]):
            """From docstring."""

            @step(entry=True)
            async def greet(self, spec: Annotated[GreetSpec, step_arg.SPEC]) -> GreetResult:
                return GreetResult(greeting=f"Hello, {spec.name}!")

        local_tool = make_agent_tool(DocstringAgent2, name="greet_explicit", description="Explicit desc")
        assert local_tool.definition.description == "Explicit desc"

    def test_make_agent_tool_no_description_no_docstring_raises(self) -> None:
        with pytest.raises(ValueError, match="must have description or agent class docstring"):
            make_agent_tool(GreetAgent, name="greet_nodesc")

    def test_agent_tool_decorator_uses_class_docstring(self) -> None:
        @agent_tool(name="greet_dec_doc")
        class DecDocAgent(Agent[GreetSpec, GreetResult]):
            """Decorated with docstring."""

            @step(entry=True)
            async def greet(self, spec: Annotated[GreetSpec, step_arg.SPEC]) -> GreetResult:
                return GreetResult(greeting=f"Hello, {spec.name}!")

        local_tool = get_agent_tool(DecDocAgent)
        assert local_tool.definition.description == "Decorated with docstring."

    def test_agent_tool_decorator_explicit_description_overrides(self) -> None:
        @agent_tool(name="greet_dec_explicit", description="Explicit")
        class DecExplicitAgent(Agent[GreetSpec, GreetResult]):
            """From docstring."""

            @step(entry=True)
            async def greet(self, spec: Annotated[GreetSpec, step_arg.SPEC]) -> GreetResult:
                return GreetResult(greeting=f"Hello, {spec.name}!")

        local_tool = get_agent_tool(DecExplicitAgent)
        assert local_tool.definition.description == "Explicit"


class TestAgentToolOutputSchema:
    def test_output_schema_from_single_result_type(self) -> None:
        local_tool = make_agent_tool(GreetAgent, name="greet", description="Greet")
        assert local_tool.definition.output_schema is not None
        assert "greeting" in local_tool.definition.output_schema.get("properties", {})

    def test_output_schema_excludes_tool_result(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class MySpec:
            text: str

        class MyAgent(Agent[MySpec, GreetResult | ToolResult]):
            """Agent with ToolResult."""

            @step(entry=True)
            async def run(self, spec: Annotated[MySpec, step_arg.SPEC]) -> GreetResult | ToolResult:
                return GreetResult(greeting=spec.text)

        local_tool = make_agent_tool(MyAgent, name="my", description="My")
        assert local_tool.definition.output_schema is not None
        assert "greeting" in local_tool.definition.output_schema.get("properties", {})

    def test_output_schema_none_for_only_tool_result(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class MySpec:
            pass

        class MyAgent(Agent[MySpec, ToolResult]):
            """Agent returning only ToolResult."""

            @step(entry=True)
            async def run(self, spec: Annotated[MySpec, step_arg.SPEC]) -> ToolResult:
                return ToolResult(content="ok")

        local_tool = make_agent_tool(MyAgent, name="my", description="My")
        assert local_tool.definition.output_schema is None


class TestAgentToolReturnsToolResult:
    async def test_agent_tool_returns_tool_result_error(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class ValidateSpec:
            text: str

        class ValidateAgent(Agent[ValidateSpec, GreetResult | ToolResult]):
            """Validate text."""

            @step(entry=True)
            async def validate(self, spec: Annotated[ValidateSpec, step_arg.SPEC]) -> GreetResult | ToolResult:
                if spec.text == "bad":
                    return ToolResult(content="Validation failed", is_error=True)
                return GreetResult(greeting=f"Valid: {spec.text}")

        local_tool = make_agent_tool(ValidateAgent, name="validate", description="Validate text")
        registry = ToolRegistry([local_tool])
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "validate": ValidateAgent},
            services={
                TurnConfig: TurnConfig(tools=registry, llm_config=LLMConfig(model="test"), system=[], history=[])
            },
            storage=storage,
        )

        tool_use = ToolUseBlock(id="call_1", name="validate", input={"text": "bad"})
        result = await runtime.run(agent=ToolCallAgent, spec=ToolCallSpec(tool_use=tool_use))

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is True
        assert result.result.content == "Validation failed"

    async def test_agent_tool_returns_tool_result_success(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class ValidateSpec:
            text: str

        class ValidateAgent(Agent[ValidateSpec, GreetResult | ToolResult]):
            """Validate text."""

            @step(entry=True)
            async def validate(self, spec: Annotated[ValidateSpec, step_arg.SPEC]) -> GreetResult | ToolResult:
                if spec.text == "bad":
                    return ToolResult(content="Validation failed", is_error=True)
                return GreetResult(greeting=f"Valid: {spec.text}")

        local_tool = make_agent_tool(ValidateAgent, name="validate", description="Validate text")
        registry = ToolRegistry([local_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "validate": ValidateAgent},
            services={
                TurnConfig: TurnConfig(tools=registry, llm_config=LLMConfig(model="test"), system=[], history=[])
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="validate", input={"text": "good"})
        result = await runtime.run(agent=ToolCallAgent, spec=ToolCallSpec(tool_use=tool_use))

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is False
        assert '"Valid: good"' in result.result.content

    async def test_agent_tool_returns_tool_result_with_error_kind(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class CheckSpec:
            pass

        class CheckAgent(Agent[CheckSpec, ToolResult]):
            """Check something."""

            @step(entry=True)
            async def check(self, spec: Annotated[CheckSpec, step_arg.SPEC]) -> ToolResult:
                return ToolResult(content="Not valid", is_error=True, error_kind=ToolErrorKind.EXECUTION)

        local_tool = make_agent_tool(CheckAgent, name="check", description="Check")
        registry = ToolRegistry([local_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "check": CheckAgent},
            services={
                TurnConfig: TurnConfig(tools=registry, llm_config=LLMConfig(model="test"), system=[], history=[])
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="check", input={})
        result = await runtime.run(agent=ToolCallAgent, spec=ToolCallSpec(tool_use=tool_use))

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is True
        assert result.result.content == "Not valid"
        assert result.error_kind == ToolErrorKind.EXECUTION

    async def test_agent_tool_returns_tool_result_non_error(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class CheckSpec:
            pass

        class CheckAgent(Agent[CheckSpec, ToolResult]):
            """Return non-error ToolResult."""

            @step(entry=True)
            async def check(self, spec: Annotated[CheckSpec, step_arg.SPEC]) -> ToolResult:
                return ToolResult(content="all good")

        local_tool = make_agent_tool(CheckAgent, name="check", description="Check")
        registry = ToolRegistry([local_tool])
        runtime = AgentRuntime(
            agents={"tool_call": ToolCallAgent, "check": CheckAgent},
            services={
                TurnConfig: TurnConfig(tools=registry, llm_config=LLMConfig(model="test"), system=[], history=[])
            },
        )

        tool_use = ToolUseBlock(id="call_1", name="check", input={})
        result = await runtime.run(agent=ToolCallAgent, spec=ToolCallSpec(tool_use=tool_use))

        assert isinstance(result, ToolCallResult)
        assert result.result.is_error is False
        assert result.result.content == "all good"
        assert result.error_kind is None


class TestMakeAgentToolErrors:
    async def test_agent_tool_outside_tool_call_agent_raises(self) -> None:
        local_tool = make_agent_tool(GreetAgent, name="greet", description="Greet")
        registry = ToolRegistry([local_tool])
        result = await registry.execute("greet", {"name": "Alice"}, services={})
        assert result.is_error is True
        assert "ToolCallAgentContext" in result.content

    def test_multiple_spec_types_raises(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class OtherSpec:
            value: int

        agent_def = dataclasses.replace(
            GreetAgent.__agent_definition__,
            spec_types=frozenset({GreetSpec, OtherSpec}),
        )
        with pytest.raises(TypeError, match="exactly one spec type"):
            make_agent_tool(agent_def, name="greet", description="Greet", agent_ref="greet")

    def test_agent_definition_without_agent_ref_raises(self) -> None:
        agent_def = GreetAgent.__agent_definition__
        assert isinstance(agent_def, AgentDefinition)
        with pytest.raises(TypeError, match="agent_ref is required"):
            make_agent_tool(agent_def, name="greet", description="Greet")
