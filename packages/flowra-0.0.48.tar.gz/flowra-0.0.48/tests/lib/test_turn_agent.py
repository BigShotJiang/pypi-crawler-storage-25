import dataclasses
from collections.abc import AsyncIterator

from flowra.agent import AgentRuntime, Event, HookSubscription, SpanExitHandler
from flowra.agent.flow.hooks import HooksImpl
from flowra.lib import LLMConfig
from flowra.lib.observability import LLMCallSpan, TextDeltaEvent, ThinkingDeltaEvent
from flowra.lib.turn import (
    AfterToolCallEvent,
    BeforeToolCallEvent,
    MessageAcceptedEvent,
    ResultMessageEvent,
    StartIterationEvent,
    TextReasoningEvent,
    TurnAgent,
    TurnAgentContext,
    TurnConfig,
    TurnResult,
    TurnSpec,
    TurnStatus,
)
from flowra.lib.turn.tool_call import ToolCallAgent
from flowra.llm import (
    AssistantMessage,
    ContentComplete,
    LLMProvider,
    LLMRequest,
    LLMResponse,
    StopReason,
    StreamEvent,
    TextBlock,
    TextDelta,
    ThinkingBlock,
    ThinkingDelta,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from flowra.tools import ToolRegistry, tool


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class FinishParams:
    pass


@tool("finish")
def finish_tool(params: FinishParams, context: TurnAgentContext) -> str:
    """Tool that requests finish."""
    context.request_finish()
    return "Finishing"


class TestTurnAgentContext:
    async def test_request_finish_in_tool(self) -> None:
        # Mock LLM provider that returns tool use then END_TURN
        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    # First call: return tool use
                    return LLMResponse(
                        messages=[AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="finish", input={})])],
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Should not be called again after tool requests finish
                raise RuntimeError("LLM called after finish requested")

        provider = MockProvider()

        registry = ToolRegistry([finish_tool])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            max_llm_calls=100,
        )
        runtime = AgentRuntime(
            agents={"loop": TurnAgent, "tool_call": ToolCallAgent},
            services={
                TurnConfig: config,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        # Verify that LLM was called only once (tool requested finish)
        assert provider.call_count == 1
        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.FINISH_REQUESTED
        # Messages: user (from spec), assistant (tool use), user (tool result)
        assert len(result.messages) == 3


class TestTurnAgent:
    async def test_max_llm_calls_exceeded(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class NoopParams:
            pass

        @tool("noop")
        def noop_tool(params: NoopParams) -> str:
            """Tool that does nothing."""
            return "OK"

        # Mock LLM provider that always returns tool use
        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                return LLMResponse(
                    messages=[
                        AssistantMessage(blocks=[ToolUseBlock(id=f"call_{self.call_count}", name="noop", input={})])
                    ],
                    stop_reason=StopReason.TOOL_USE,
                )

        provider = MockProvider()

        registry = ToolRegistry([noop_tool])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            max_llm_calls=3,
        )
        runtime = AgentRuntime(
            agents={"loop": TurnAgent, "tool_call": ToolCallAgent},
            services={
                TurnConfig: config,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.MAX_LLM_CALLS
        # Should have called LLM 3 times before hitting limit
        assert provider.call_count == 3

    async def test_simple_end_turn_returns_completed(self) -> None:
        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Hello!")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.COMPLETED
        assert result.stop_reason == StopReason.END_TURN
        assert result.result_message is not None
        assert isinstance(result.result_message.blocks[0], TextBlock)
        assert result.result_message.blocks[0].text == "Hello!"
        # Messages: user + assistant
        assert len(result.messages) == 2

    async def test_no_delta_hooks_uses_call(self) -> None:
        """Without delta hooks, agent uses call() not stream()."""

        class TrackingProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0
                self.stream_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Hello")])],
                    stop_reason=StopReason.END_TURN,
                )

            async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
                self.stream_count += 1
                yield ContentComplete(
                    response=LLMResponse(
                        messages=[AssistantMessage(blocks=[TextBlock(text="Hello")])],
                        stop_reason=StopReason.END_TURN,
                    )
                )

        provider = TrackingProvider()

        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                LLMProvider: provider,
            },
        )

        await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert provider.call_count == 1
        assert provider.stream_count == 0

    async def test_interrupt_during_streaming_stops_early(self) -> None:
        """InterruptToken checked during streaming — breaks out of stream loop."""
        received_deltas: list[str] = []
        runtime_ref: list[AgentRuntime] = []

        def text_delta_hook(event: Event[TextDeltaEvent]) -> None:
            received_deltas.append(event.data.text)
            if event.data.text == "second":
                runtime_ref[0].interrupt()

        class SlowStreamProvider(LLMProvider):
            def __init__(self) -> None:
                self.stream_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="done")])],
                    stop_reason=StopReason.END_TURN,
                )

            async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
                self.stream_count += 1
                yield TextDelta(text="first")
                yield TextDelta(text="second")
                # These should NOT be delivered — interrupt fires after "second"
                yield TextDelta(text="third")
                yield TextDelta(text="fourth")
                yield ContentComplete(
                    response=LLMResponse(
                        messages=[AssistantMessage(blocks=[TextBlock(text="first second third fourth")])],
                        stop_reason=StopReason.END_TURN,
                    )
                )

        provider = SlowStreamProvider()

        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        hooks = HooksImpl()
        hooks.on(TextDeltaEvent, text_delta_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )
        runtime_ref.append(runtime)

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.INTERRUPTED
        # Turn messages include the user message added during start
        assert len(result.messages) == 1
        # "second" triggers interrupt; "third" and "fourth" should not be received
        assert received_deltas == ["first", "second"]
        assert provider.stream_count == 1

    async def test_max_consecutive_errors_replaces_message(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class FailParams:
            pass

        @tool("fail")
        def fail_tool(params: FailParams) -> str:
            """Tool that always fails."""
            raise ValueError("boom")

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count <= 3:
                    return LLMResponse(
                        messages=[
                            AssistantMessage(blocks=[ToolUseBlock(id=f"call_{self.call_count}", name="fail", input={})])
                        ],
                        stop_reason=StopReason.TOOL_USE,
                    )
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([fail_tool])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            max_consecutive_errors=2,
        )
        runtime = AgentRuntime(
            agents={"loop": TurnAgent, "tool_call": ToolCallAgent},
            services={
                TurnConfig: config,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.COMPLETED
        # 3 tool calls + 1 end turn
        assert provider.call_count == 4

        # Third tool result (after 2 consecutive failures) should have replacement message
        # Messages: user, assistant(tool), user(result), assistant(tool), user(result),
        #           assistant(tool), user(result), assistant(done)
        tool_result_messages = [
            m
            for m in result.messages
            if isinstance(m, UserMessage) and m.blocks and isinstance(m.blocks[0], ToolResultBlock)
        ]
        assert len(tool_result_messages) == 3
        third_result = tool_result_messages[2].blocks[0]
        assert isinstance(third_result, ToolResultBlock)
        assert "failed 2 times consecutively" in third_result.content
        assert third_result.is_error is True

    async def test_consecutive_errors_reset_on_success(self) -> None:
        call_count = 0

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class FlakeyParams:
            pass

        @tool("flakey")
        def flakey_tool(params: FlakeyParams) -> str:
            """Tool that fails once, succeeds, then fails once more."""
            nonlocal call_count
            call_count += 1
            if call_count in (1, 3):
                raise ValueError("boom")
            return "OK"

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.llm_calls = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.llm_calls += 1
                if self.llm_calls <= 3:
                    return LLMResponse(
                        messages=[
                            AssistantMessage(
                                blocks=[ToolUseBlock(id=f"call_{self.llm_calls}", name="flakey", input={})]
                            )
                        ],
                        stop_reason=StopReason.TOOL_USE,
                    )
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([flakey_tool])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            max_consecutive_errors=2,
        )
        runtime = AgentRuntime(
            agents={"loop": TurnAgent, "tool_call": ToolCallAgent},
            services={
                TurnConfig: config,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.COMPLETED
        # Pattern: fail(1), success(2), fail(3) — never hits 2 consecutive, no replacement
        tool_result_messages = [
            m
            for m in result.messages
            if isinstance(m, UserMessage) and m.blocks and isinstance(m.blocks[0], ToolResultBlock)
        ]
        assert len(tool_result_messages) == 3
        for trm in tool_result_messages:
            block = trm.blocks[0]
            assert isinstance(block, ToolResultBlock)
            assert "consecutively" not in block.content

    async def test_non_end_turn_stop_reasons_return_completed(self) -> None:
        for stop_reason in (StopReason.MAX_TOKENS, StopReason.STOP_SEQUENCE, StopReason.SCHEMA_VALIDATION_FAILED):

            class MockProvider(LLMProvider):
                async def call(self, request: LLMRequest) -> LLMResponse:
                    return LLMResponse(
                        messages=[AssistantMessage(blocks=[TextBlock(text="partial")])],
                        stop_reason=stop_reason,
                    )

            provider = MockProvider()
            registry = ToolRegistry([])
            config = TurnConfig(
                tools=registry,
                llm_config=LLMConfig(model="test"),
                system=[],
                history=[],
            )
            runtime = AgentRuntime(
                agents={"loop": TurnAgent},
                services={
                    TurnConfig: config,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=TurnAgent,
                spec=TurnSpec.text("Hi"),
            )

            assert isinstance(result, TurnResult), f"Failed for {stop_reason}"
            assert result.status == TurnStatus.COMPLETED
            assert result.stop_reason == stop_reason
            assert result.result_message is not None
            assert isinstance(result.result_message.blocks[0], TextBlock)
            assert result.result_message.blocks[0].text == "partial"

    async def test_interrupt_before_call_llm(self) -> None:
        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Hello")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()

        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                LLMProvider: provider,
            },
        )
        runtime.interrupt()

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.INTERRUPTED
        # User message was added in start step, but LLM was never called
        assert len(result.messages) == 1
        assert provider.call_count == 0

    async def test_multiple_parallel_tool_calls(self) -> None:
        """Multiple ToolUseBlocks in a single response are spawned as parallel children."""
        tool_call_order: list[str] = []

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class AddParams:
            value: int

        @tool("add")
        def add_tool(params: AddParams) -> str:
            """Add tool."""
            tool_call_order.append(f"add:{params.value}")
            return f"Added {params.value}"

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class MulParams:
            value: int

        @tool("mul")
        def mul_tool(params: MulParams) -> str:
            """Multiply tool."""
            tool_call_order.append(f"mul:{params.value}")
            return f"Multiplied {params.value}"

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        messages=[
                            AssistantMessage(
                                blocks=[
                                    ToolUseBlock(id="call_add", name="add", input={"value": 10}),
                                    ToolUseBlock(id="call_mul", name="mul", input={"value": 5}),
                                ]
                            )
                        ],
                        stop_reason=StopReason.TOOL_USE,
                    )
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([add_tool, mul_tool])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        runtime = AgentRuntime(
            agents={"loop": TurnAgent, "tool_call": ToolCallAgent},
            services={
                TurnConfig: config,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.COMPLETED
        assert provider.call_count == 2

        # Both tools were called
        assert len(tool_call_order) == 2
        assert "add:10" in tool_call_order
        assert "mul:5" in tool_call_order

        # Messages: user, assistant(2 tool uses), user(2 tool results), assistant(done)
        assert len(result.messages) == 4
        # The tool result message should contain both results
        tool_result_msg = result.messages[2]
        assert isinstance(tool_result_msg, UserMessage)
        assert len(tool_result_msg.blocks) == 2
        result_blocks = tool_result_msg.blocks
        assert all(isinstance(b, ToolResultBlock) for b in result_blocks)
        result_contents = {b.content for b in result_blocks if isinstance(b, ToolResultBlock)}
        assert "Added 10" in result_contents
        assert "Multiplied 5" in result_contents

    async def test_json_schema_propagated_to_llm_request(self) -> None:
        """json_schema from TurnConfig is passed through to the LLMRequest."""
        captured_requests: list[LLMRequest] = []

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                captured_requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text='{"answer": 42}')])],
                    stop_reason=StopReason.END_TURN,
                )

        schema = {"type": "object", "properties": {"answer": {"type": "integer"}}, "required": ["answer"]}
        provider = MockProvider()
        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            json_schema=schema,
        )
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("What is the answer?"),
        )

        assert isinstance(result, TurnResult)
        assert len(captured_requests) == 1
        assert captured_requests[0].json_schema == schema

    async def test_json_schema_none_by_default(self) -> None:
        """Without json_schema in config, LLMRequest.json_schema is None."""
        captured_requests: list[LLMRequest] = []

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                captured_requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Hello")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                LLMProvider: provider,
            },
        )

        await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert len(captured_requests) == 1
        assert captured_requests[0].json_schema is None

    async def test_allowed_tools_filters_tools_in_llm_request(self) -> None:
        """allowed_tools config filters which tools are sent to the LLM."""
        captured_requests: list[LLMRequest] = []

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Params:
            pass

        @tool("allowed_tool")
        def allowed_tool_fn(params: Params) -> str:
            """Allowed."""
            return "OK"

        @tool("blocked_tool")
        def blocked_tool_fn(params: Params) -> str:
            """Blocked."""
            return "OK"

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                captured_requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([allowed_tool_fn, blocked_tool_fn])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            allowed_tools={"allowed_tool"},
        )
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                LLMProvider: provider,
            },
        )

        await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        assert len(captured_requests) == 1
        tool_names = [t.name for t in (captured_requests[0].tools or [])]
        assert tool_names == ["allowed_tool"]

    async def test_denied_tools_filters_tools_in_llm_request(self) -> None:
        """denied_tools config removes specific tools from the LLM request."""
        captured_requests: list[LLMRequest] = []

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Params:
            pass

        @tool("good_tool")
        def good_tool_fn(params: Params) -> str:
            """Good."""
            return "OK"

        @tool("bad_tool")
        def bad_tool_fn(params: Params) -> str:
            """Bad."""
            return "OK"

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                captured_requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([good_tool_fn, bad_tool_fn])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            denied_tools={"bad_tool"},
        )
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                LLMProvider: provider,
            },
        )

        await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        assert len(captured_requests) == 1
        tool_names = [t.name for t in (captured_requests[0].tools or [])]
        assert tool_names == ["good_tool"]


class TestTurnAgentHooks:
    async def test_on_after_tool_call_amends_result(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class ErrorParams:
            pass

        @tool("error_tool")
        def error_tool(params: ErrorParams) -> str:
            """Tool that returns an error."""
            raise RuntimeError("Internal error")

        # Hook that sanitizes error messages
        def sanitize_errors_hook(event: Event[AfterToolCallEvent]) -> None:
            result = event.data.result
            if result.is_error and "Internal error" in result.content:
                # Replace internal error with user-friendly message
                event.data.result = ToolResultBlock(
                    tool_use_id=result.tool_use_id,
                    content="An error occurred. Please try again.",
                    is_error=True,
                    metadata={"sanitized": True},
                )

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        messages=[AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="error_tool", input={})])],
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Second call - end turn
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])], stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        registry = ToolRegistry([error_tool])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            max_llm_calls=100,
        )
        hooks = HooksImpl()
        hooks.on(AfterToolCallEvent, sanitize_errors_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent, "tool_call": ToolCallAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.COMPLETED
        # Should have 4 messages: user (from spec), assistant (tool use), user (amended result), assistant (done)
        assert len(result.messages) == 4

        # Check that error message was sanitized
        user_msg = result.messages[2]
        assert isinstance(user_msg, UserMessage)
        assert len(user_msg.blocks) == 1
        result_block = user_msg.blocks[0]
        assert isinstance(result_block, ToolResultBlock)
        assert result_block.is_error
        assert result_block.content == "An error occurred. Please try again."
        assert "Internal error" not in result_block.content
        # Check metadata was preserved
        assert result_block.metadata.get("sanitized") is True

    async def test_on_after_tool_call_can_request_finish(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class DoneParams:
            pass

        @tool("done")
        def done_tool(params: DoneParams) -> str:
            """Tool that signals completion."""
            return "Task completed"

        # Hook that requests finish when seeing "done" tool
        def finish_on_done_hook(event: Event[AfterToolCallEvent]) -> None:
            if event.data.tool_use.name == "done":
                event.data.context.request_finish()

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    # First call: return tool use
                    return LLMResponse(
                        messages=[AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="done", input={})])],
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Should not be called again after hook requests finish
                raise RuntimeError("LLM called after finish requested")

        provider = MockProvider()

        registry = ToolRegistry([done_tool])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            max_llm_calls=100,
        )
        hooks = HooksImpl()
        hooks.on(AfterToolCallEvent, finish_on_done_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent, "tool_call": ToolCallAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        # Verify that LLM was called only once (hook requested finish)
        assert provider.call_count == 1
        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.FINISH_REQUESTED
        # Messages: user (from spec), assistant (tool use), user (tool result)
        assert len(result.messages) == 3

    async def test_on_after_tool_call_adds_additional_messages(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class CalculateParams:
            value: int

        @tool("calculate")
        def calculate_tool(params: CalculateParams) -> str:
            """Simple calculation tool."""
            return f"Result: {params.value * 2}"

        # Hook that adds a system reminder as additional message
        def after_tool_hook(event: Event[AfterToolCallEvent]) -> None:
            # Add a system reminder as additional message
            reminder = UserMessage(
                blocks=[TextBlock(text=f"[System: Tool '{event.data.tool_use.name}' executed successfully]")],
                metadata={"transient": True},
            )
            event.data.additional_messages.append(reminder)

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        messages=[
                            AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="calculate", input={"value": 5})])
                        ],
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Second call - end turn
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])], stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        registry = ToolRegistry([calculate_tool])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            max_llm_calls=100,
        )
        hooks = HooksImpl()
        hooks.on(AfterToolCallEvent, after_tool_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent, "tool_call": ToolCallAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        assert isinstance(result, TurnResult)
        # Should have 5 messages:
        # 1. UserMessage (from spec)
        # 2. AssistantMessage (tool use)
        # 3. UserMessage (tool result)
        # 4. UserMessage (additional reminder with metadata)
        # 5. AssistantMessage (done)
        assert len(result.messages) == 5

        # Third message should be UserMessage with tool results
        assert isinstance(result.messages[2], UserMessage)

        # Fourth message should be the additional reminder
        reminder_msg = result.messages[3]
        assert isinstance(reminder_msg, UserMessage)
        # Check metadata was attached to the reminder
        assert reminder_msg.metadata.get("transient") is True
        # Check it's the system reminder
        assert len(reminder_msg.blocks) == 1
        assert isinstance(reminder_msg.blocks[0], TextBlock)
        assert "Tool 'calculate' executed successfully" in reminder_msg.blocks[0].text

    async def test_all_hooks_are_called(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class SimpleParams:
            value: int

        @tool("simple")
        def simple_tool(params: SimpleParams) -> str:
            """Simple tool."""
            return f"Result: {params.value}"

        # Track hook calls
        hook_calls: list[str] = []

        def llm_span_handler(event: Event[LLMCallSpan]) -> SpanExitHandler:
            hook_calls.append("before_llm")

            def on_exit(error: BaseException | None = None) -> None:
                hook_calls.append("after_llm")

            return on_exit

        def before_tool_hook(event: Event[BeforeToolCallEvent]) -> None:
            hook_calls.append(f"before_tool:{event.data.tool_use.name}")

        def after_tool_hook(event: Event[AfterToolCallEvent]) -> None:
            hook_calls.append(f"after_tool:{event.data.tool_use.name}")

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        messages=[
                            AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="simple", input={"value": 42})])
                        ],
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Second call - end turn
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])], stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        registry = ToolRegistry([simple_tool])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            max_llm_calls=100,
        )
        hooks = HooksImpl()
        hooks.on_span(LLMCallSpan, llm_span_handler)
        hooks.on(BeforeToolCallEvent, before_tool_hook)
        hooks.on(AfterToolCallEvent, after_tool_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent, "tool_call": ToolCallAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        assert isinstance(result, TurnResult)
        # Verify all hooks were called in correct order
        assert hook_calls == [
            "before_llm",  # First LLM call
            "after_llm",
            "before_tool:simple",  # Tool execution
            "after_tool:simple",
            "before_llm",  # Second LLM call
            "after_llm",
        ]

    async def test_async_hooks_are_called(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class AsyncParams:
            pass

        @tool("async_op")
        def async_op_tool(params: AsyncParams) -> str:
            """Async operation."""
            return "OK"

        # Track hook calls
        hook_calls: list[str] = []

        async def async_llm_span_handler(event: Event[LLMCallSpan]) -> SpanExitHandler:
            import asyncio

            await asyncio.sleep(0.001)
            hook_calls.append("async_before_llm")

            async def on_exit(error: BaseException | None = None) -> None:
                import asyncio

                await asyncio.sleep(0.001)
                hook_calls.append("async_after_llm")

            return on_exit

        async def async_before_tool_hook(event: Event[BeforeToolCallEvent]) -> None:
            import asyncio

            await asyncio.sleep(0.001)
            hook_calls.append(f"async_before_tool:{event.data.tool_use.name}")

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        messages=[AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="async_op", input={})])],
                        stop_reason=StopReason.TOOL_USE,
                    )
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])], stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        registry = ToolRegistry([async_op_tool])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            max_llm_calls=100,
        )
        hooks = HooksImpl()
        hooks.on_span(LLMCallSpan, async_llm_span_handler)
        hooks.on(BeforeToolCallEvent, async_before_tool_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent, "tool_call": ToolCallAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        assert isinstance(result, TurnResult)
        # Verify async hooks were called
        assert hook_calls == [
            "async_before_llm",
            "async_after_llm",
            "async_before_tool:async_op",
            "async_before_llm",
            "async_after_llm",
        ]

    async def test_before_tool_call_amends_tool_use(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class CalcParams:
            value: int

        @tool("calc")
        def calc_tool(params: CalcParams) -> str:
            """Calculator tool."""
            return f"Calculated: {params.value * 10}"

        # Hook that modifies tool parameters
        def modify_params_hook(event: Event[BeforeToolCallEvent]) -> None:
            tool_use = event.data.tool_use
            # Double the value parameter
            if tool_use.name == "calc" and isinstance(tool_use.input, dict) and "value" in tool_use.input:
                original_value = tool_use.input["value"]
                event.data.tool_use = ToolUseBlock(
                    id=tool_use.id,
                    name=tool_use.name,
                    input={"value": original_value * 2},
                    metadata={**tool_use.metadata, "modified": True},
                )

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    # LLM requests value=5
                    return LLMResponse(
                        messages=[
                            AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="calc", input={"value": 5})])
                        ],
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Second call - end turn
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])], stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        registry = ToolRegistry([calc_tool])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            max_llm_calls=100,
        )
        hooks = HooksImpl()
        hooks.on(BeforeToolCallEvent, modify_params_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent, "tool_call": ToolCallAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        assert isinstance(result, TurnResult)
        # Should have 4 messages: user (from spec), assistant (tool use), user (result), assistant (done)
        assert len(result.messages) == 4

        # Check that tool was executed with modified parameter (5 * 2 = 10)
        user_msg = result.messages[2]
        assert isinstance(user_msg, UserMessage)
        assert len(user_msg.blocks) == 1
        result_block = user_msg.blocks[0]
        assert isinstance(result_block, ToolResultBlock)
        # Tool received doubled value: 10 * 10 = 100
        assert result_block.content == "Calculated: 100"

    async def test_start_iteration_hook_adds_messages(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class SimpleParams:
            pass

        @tool("simple")
        def simple_tool(params: SimpleParams) -> str:
            """Simple tool."""
            return "OK"

        # Hook that adds iteration context
        def start_iteration_hook(event: Event[StartIterationEvent]) -> None:
            # Add a system message with iteration number
            iteration = event.data.iteration
            reminder = UserMessage(
                blocks=[TextBlock(text=f"[Iteration {iteration} started]")],
                metadata={"transient": True, "iteration": iteration},
            )
            event.data.additional_messages.append(reminder)

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        messages=[AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="simple", input={})])],
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Second call - end turn
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])], stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        registry = ToolRegistry([simple_tool])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
            max_llm_calls=100,
        )
        hooks = HooksImpl()
        hooks.on(StartIterationEvent, start_iteration_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent, "tool_call": ToolCallAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("test"),
        )

        assert isinstance(result, TurnResult)
        # Should have 6 messages:
        # 1. UserMessage (from spec)
        # 2. UserMessage (iteration 1 reminder)
        # 3. AssistantMessage (tool use)
        # 4. UserMessage (tool result)
        # 5. UserMessage (iteration 2 reminder)
        # 6. AssistantMessage (done)
        assert len(result.messages) == 6

        # Check user message from spec
        user_msg = result.messages[0]
        assert isinstance(user_msg, UserMessage)
        assert isinstance(user_msg.blocks[0], TextBlock)
        assert user_msg.blocks[0].text == "test"

        # Check first iteration reminder
        reminder1 = result.messages[1]
        assert isinstance(reminder1, UserMessage)
        assert reminder1.metadata.get("transient") is True
        assert reminder1.metadata.get("iteration") == 1
        assert len(reminder1.blocks) == 1
        assert isinstance(reminder1.blocks[0], TextBlock)
        assert "[Iteration 1 started]" in reminder1.blocks[0].text

        # Check second iteration reminder
        reminder2 = result.messages[4]
        assert isinstance(reminder2, UserMessage)
        assert reminder2.metadata.get("iteration") == 2
        assert isinstance(reminder2.blocks[0], TextBlock)
        assert "[Iteration 2 started]" in reminder2.blocks[0].text

        # Verify that LLM received the reminder messages
        assert len(provider.requests) == 2
        # First request should have 2 messages (user message from spec + iteration 1 reminder)
        assert len(provider.requests[0].messages) == 2
        # Second request should have 5 messages (user, reminder1, assistant, user_result, reminder2)
        assert len(provider.requests[1].messages) == 5

    async def test_on_message_accepted_receives_messages_and_metadata(self) -> None:
        received_events: list[MessageAcceptedEvent] = []

        def accepted_hook(event: Event[MessageAcceptedEvent]) -> None:
            received_events.append(event.data)

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        hooks = HooksImpl()
        hooks.on(MessageAcceptedEvent, accepted_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi", metadata={"msg_id": "123"}),
        )

        assert len(received_events) == 1
        assert received_events[0].metadata == {"msg_id": "123"}
        assert len(received_events[0].messages) == 1
        msg = received_events[0].messages[0]
        assert isinstance(msg, UserMessage)
        block = msg.blocks[0]
        assert isinstance(block, TextBlock)
        assert block.text == "Hi"

    async def test_on_message_accepted_async_hook(self) -> None:
        received_events: list[MessageAcceptedEvent] = []

        async def async_accepted_hook(event: Event[MessageAcceptedEvent]) -> None:
            import asyncio

            await asyncio.sleep(0.001)
            received_events.append(event.data)

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        hooks = HooksImpl()
        hooks.on(MessageAcceptedEvent, async_accepted_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi", metadata={"msg_id": "456"}),
        )

        assert len(received_events) == 1
        assert received_events[0].metadata == {"msg_id": "456"}

    async def test_on_text_reasoning_fires_for_text_blocks(self) -> None:
        seen_texts: list[str] = []

        def reasoning_hook(event: Event[TextReasoningEvent]) -> None:
            seen_texts.append(event.data.text.text)

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="First"), TextBlock(text="Second")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        hooks = HooksImpl()
        hooks.on(TextReasoningEvent, reasoning_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert seen_texts == ["First", "Second"]

    async def test_on_thinking_event_fires_for_thinking_blocks(self) -> None:
        from flowra.lib.turn import ThinkingEvent

        seen: list[str] = []

        def thinking_hook(event: Event[ThinkingEvent]) -> None:
            seen.append(event.data.thinking.text)

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[ThinkingBlock(text="thinking..."), TextBlock(text="answer")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        hooks = HooksImpl()
        hooks.on(ThinkingEvent, thinking_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert seen == ["thinking..."]

    async def test_server_tool_call_event_fires_for_intermediate_messages(self) -> None:
        from flowra.lib.turn import ServerToolCallEvent, ServerToolResultEvent

        seen_calls: list[str] = []
        seen_results: list[str] = []

        def call_hook(event: Event[ServerToolCallEvent]) -> None:
            seen_calls.append(event.data.tool_use.name)

        def result_hook(event: Event[ServerToolResultEvent]) -> None:
            seen_results.append(event.data.result.content)

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[
                        AssistantMessage(blocks=[ToolUseBlock(id="ts_1", name="__tool_search__", input=None)]),
                        UserMessage(blocks=[ToolResultBlock(tool_use_id="ts_1", content='["get_weather"]')]),
                        AssistantMessage(blocks=[TextBlock(text="Done")]),
                    ],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        hooks = HooksImpl()
        hooks.on(ServerToolCallEvent, call_hook)
        hooks.on(ServerToolResultEvent, result_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert seen_calls == ["__tool_search__"]
        assert seen_results == ['["get_weather"]']

    async def test_server_tool_call_event_not_fired_for_final_message(self) -> None:
        from flowra.lib.turn import ServerToolCallEvent

        seen_calls: list[str] = []

        def call_hook(event: Event[ServerToolCallEvent]) -> None:
            seen_calls.append(event.data.tool_use.name)

        call_count = 0

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                nonlocal call_count
                call_count += 1
                if call_count == 1:
                    return LLMResponse(
                        messages=[
                            AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="greet", input={"name": "World"})]),
                        ],
                        stop_reason=StopReason.TOOL_USE,
                    )
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])],
                    stop_reason=StopReason.END_TURN,
                )

        @tool("greet", description="Greet someone")
        def greet(name: str) -> str:
            return f"Hello, {name}!"

        provider = MockProvider()
        registry = ToolRegistry([greet])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        hooks = HooksImpl()
        hooks.on(ServerToolCallEvent, call_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert seen_calls == []

    async def test_text_reasoning_fires_from_intermediate_assistant_messages(self) -> None:
        seen_texts: list[str] = []

        def reasoning_hook(event: Event[TextReasoningEvent]) -> None:
            seen_texts.append(event.data.text.text)

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[
                        AssistantMessage(blocks=[TextBlock(text="Searching...")]),
                        UserMessage(blocks=[ToolResultBlock(tool_use_id="ts_1", content="found")]),
                        AssistantMessage(blocks=[TextBlock(text="Done")]),
                    ],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        hooks = HooksImpl()
        hooks.on(TextReasoningEvent, reasoning_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert seen_texts == ["Searching...", "Done"]

    async def test_on_result_message_continues_loop(self) -> None:
        call_count = 0

        def result_hook(event: Event[ResultMessageEvent]) -> None:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                event.data.continue_messages.append(UserMessage(blocks=[TextBlock(text="Continue please")]))

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.llm_calls = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.llm_calls += 1
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text=f"Response {self.llm_calls}")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        hooks = HooksImpl()
        hooks.on(ResultMessageEvent, result_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.COMPLETED
        assert provider.llm_calls == 2

    async def test_on_text_delta_triggers_streaming(self) -> None:
        """Setting on_text_delta hook makes agent use stream() instead of call()."""
        received_deltas: list[str] = []

        def text_delta_hook(event: Event[TextDeltaEvent]) -> None:
            received_deltas.append(event.data.text)

        class StreamingProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0
                self.stream_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Hello world")])],
                    stop_reason=StopReason.END_TURN,
                )

            async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
                self.stream_count += 1
                yield TextDelta(text="Hello ")
                yield TextDelta(text="world")
                yield ContentComplete(
                    response=LLMResponse(
                        messages=[AssistantMessage(blocks=[TextBlock(text="Hello world")])],
                        stop_reason=StopReason.END_TURN,
                    )
                )

        provider = StreamingProvider()

        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        hooks = HooksImpl()
        hooks.on(TextDeltaEvent, text_delta_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.COMPLETED
        # stream() should have been used, not call()
        assert provider.stream_count == 1
        assert provider.call_count == 0
        assert received_deltas == ["Hello ", "world"]

    async def test_on_thinking_delta_alone_triggers_streaming(self) -> None:
        """Setting only on_thinking_delta (without on_text_delta) triggers streaming."""
        received_thinking: list[str] = []

        def thinking_delta_hook(event: Event[ThinkingDeltaEvent]) -> None:
            received_thinking.append(event.data.text)

        class StreamingProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0
                self.stream_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Hello")])],
                    stop_reason=StopReason.END_TURN,
                )

            async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
                self.stream_count += 1
                yield ThinkingDelta(text="Let me ")
                yield ThinkingDelta(text="think...")
                yield TextDelta(text="Hello")
                yield ContentComplete(
                    response=LLMResponse(
                        messages=[
                            AssistantMessage(blocks=[ThinkingBlock(text="Let me think..."), TextBlock(text="Hello")])
                        ],
                        stop_reason=StopReason.END_TURN,
                    )
                )

        provider = StreamingProvider()

        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        hooks = HooksImpl()
        hooks.on(ThinkingDeltaEvent, thinking_delta_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert isinstance(result, TurnResult)
        assert result.status == TurnStatus.COMPLETED
        assert provider.stream_count == 1
        assert provider.call_count == 0
        assert received_thinking == ["Let me ", "think..."]

    async def test_thinking_delta_events_flow_through_agent(self) -> None:
        """Both text and thinking deltas are dispatched to their respective hooks."""
        received_text: list[str] = []
        received_thinking: list[str] = []

        def text_delta_hook(event: Event[TextDeltaEvent]) -> None:
            received_text.append(event.data.text)

        def thinking_delta_hook(event: Event[ThinkingDeltaEvent]) -> None:
            received_thinking.append(event.data.text)

        class StreamingProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                raise AssertionError("call() should not be used when delta hooks are set")

            async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
                yield ThinkingDelta(text="hmm")
                yield TextDelta(text="Hi")
                yield ThinkingDelta(text="ok")
                yield TextDelta(text="there")
                yield ContentComplete(
                    response=LLMResponse(
                        messages=[AssistantMessage(blocks=[ThinkingBlock(text="hmm ok"), TextBlock(text="Hi there")])],
                        stop_reason=StopReason.END_TURN,
                    )
                )

        provider = StreamingProvider()

        registry = ToolRegistry([])
        config = TurnConfig(
            tools=registry,
            llm_config=LLMConfig(model="test"),
            system=[],
            history=[],
        )
        hooks = HooksImpl()
        hooks.on(TextDeltaEvent, text_delta_hook)
        hooks.on(ThinkingDeltaEvent, thinking_delta_hook)
        runtime = AgentRuntime(
            agents={"loop": TurnAgent},
            services={
                TurnConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        result = await runtime.run(
            agent=TurnAgent,
            spec=TurnSpec.text("Hi"),
        )

        assert isinstance(result, TurnResult)
        assert received_text == ["Hi", "there"]
        assert received_thinking == ["hmm", "ok"]
