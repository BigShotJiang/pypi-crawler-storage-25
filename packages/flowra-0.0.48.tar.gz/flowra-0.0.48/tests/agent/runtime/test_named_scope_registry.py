from flowra.agent.runtime.scope import NamedScopeRegistry


class TestGetOrCreate:
    def test_same_name_returns_same_scope(self) -> None:
        registry = NamedScopeRegistry()
        scope_a = registry.get_or_create("session")
        scope_b = registry.get_or_create("session")
        assert scope_a is scope_b

    def test_different_names_return_different_scopes(self) -> None:
        registry = NamedScopeRegistry()
        scope_a = registry.get_or_create("session")
        scope_b = registry.get_or_create("audit")
        assert scope_a is not scope_b

    def test_all_scopes_returns_created(self) -> None:
        registry = NamedScopeRegistry()
        registry.get_or_create("a")
        registry.get_or_create("b")
        scopes = registry.all_scopes()
        assert set(scopes.keys()) == {"a", "b"}


class TestHydration:
    def test_not_hydrated_by_default(self) -> None:
        registry = NamedScopeRegistry()
        registry.get_or_create("session")
        assert not registry.is_hydrated("session")

    def test_mark_hydrated(self) -> None:
        registry = NamedScopeRegistry()
        registry.get_or_create("session")
        registry.mark_hydrated("session")
        assert registry.is_hydrated("session")

    def test_unknown_scope_not_hydrated(self) -> None:
        registry = NamedScopeRegistry()
        assert not registry.is_hydrated("unknown")
