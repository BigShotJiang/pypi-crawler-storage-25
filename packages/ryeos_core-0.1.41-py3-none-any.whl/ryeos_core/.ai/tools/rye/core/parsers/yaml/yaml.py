# rye:signed:2026-04-10T02:20:26Z:72eb70e34d07eb466071a74357fbed98529e14e68947fe2909bf500cf2e41c96:54oZ-rYtCp7NCepFLBTQJUY7NHDwkitSFedxl83yt4x3kwWT-0ADbTRfeYpozEUq4YTs5lfOXejMCPN7XfehDQ:6ea18199041a1ea8
"""YAML parser for RYE."""

__version__ = "1.0.0"
__tool_type__ = "parser"
__category__ = "rye/core/parsers/yaml"
__tool_description__ = "YAML parser - parse YAML content into Python dictionaries"

import yaml


def parse(content):
    """Parse YAML content."""
    try:
        return {"data": yaml.safe_load(content) or {}, "content": content}
    except Exception:
        return {"data": {}, "content": content}
