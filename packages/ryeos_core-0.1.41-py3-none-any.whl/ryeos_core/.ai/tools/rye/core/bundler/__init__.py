# rye:signed:2026-04-10T02:20:26Z:bf580c8cdf1b944e2ab8a446fad5606499ddb6ab1b4b095838d364b5429995fd:iCIIVFThEKGrQmb1SEFIdGrtFvE7I9yjzxGsYvV62mRpKFj_qXDVnXLeNhobh3NmYpzuteJURTSGYdt_1y7uCg:6ea18199041a1ea8
"""Bundler tools package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/bundler"
__tool_description__ = "Bundler tools package"
