# rye:signed:2026-04-10T02:20:26Z:cb77055b635e3d0dac1711a6dece85f5114a0fa394645bc4e9eaad4fb94db385:6ppVj5PdwGPv3CIPjArSSrsYpl8WtdiGzbpJazz7s0tQtDniYoVwDRPAjSoOVqufoa2SxAD6nN7r8mlYHJSQAw:6ea18199041a1ea8
"""Processor tools package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/processors"
__tool_description__ = "Processor tools package"
