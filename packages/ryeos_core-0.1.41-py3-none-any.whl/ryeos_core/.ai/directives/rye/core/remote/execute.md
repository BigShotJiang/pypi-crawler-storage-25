<!-- rye:signed:2026-04-10T02:20:26Z:20d1c57c5c8683c4ef1efe4335cfb07847b4f96290cc8b70723577f688ff5496:WMQIN5pI0TkrzffWyFS8ca5kYj1EjC-T20MCBOyyoBkPyXDOfmY-uc4uZkX1VnTBrhjkRHpZb1pnSH0X1UDEDA:6ea18199041a1ea8 -->
# Remote Execute

Run a tool or graph remotely. Pushes state, executes on server, pulls results.

```xml
<directive name="execute" version="1.0.0">
  <metadata>
    <description>Push + trigger remote execution + pull results.</description>
    <category>rye/core/remote</category>
    <author>rye-os</author>
    <model tier="fast" />
    <limits turns="5" tokens="8192" />
    <permissions>
      <execute>
        <tool>rye.core.remote.*</tool>
      </execute>
    </permissions>
  </metadata>

  <inputs>
    <input name="item_type" type="string" required="true">
      Item type to execute: tool, directive, or knowledge
    </input>
    <input name="item_id" type="string" required="true">
      Item ID to execute on remote
    </input>
    <input name="parameters" type="object" required="false">
      Parameters to pass to the remote execution
    </input>
  </inputs>

  <outputs>
    <output name="execution_result">Remote execution results</output>
  </outputs>
</directive>
```

<process>
  <step name="execute">
    Execute the remote tool with action=execute:
    ```
    rye execute tool rye/core/remote/remote with {
      "action": "execute",
      "item_type": "{input:item_type}",
      "item_id": "{input:item_id}",
      "parameters": {input:parameters}
    }
    ```
  </step>

  <step name="report">
    Report the execution result: status, snapshot hash, any output data.
    If the execution failed, show the error details.
  </step>
</process>
