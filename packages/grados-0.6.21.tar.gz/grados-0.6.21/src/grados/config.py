"""GRaDOS configuration loading and path resolution."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, PrivateAttr, model_validator

from grados.http_limits import (
    DEFAULT_MAX_ASSET_COUNT,
    DEFAULT_MAX_ASSET_FILE_BYTES,
    DEFAULT_MAX_ASSET_INLINE_BYTES,
    DEFAULT_MAX_ASSET_TOTAL_BYTES,
    DEFAULT_MAX_BROWSER_CAPTURE_BYTES,
    DEFAULT_MAX_LOCAL_PDF_BYTES,
    DEFAULT_MAX_MINERU_FULL_MD_BYTES,
    DEFAULT_MAX_MINERU_ZIP_BYTES,
    DEFAULT_MAX_REMOTE_PDF_BYTES,
    DEFAULT_MAX_REMOTE_TEXT_BYTES,
)
from grados.secrets import SecretResolutionSummary, iter_api_key_specs, resolve_api_keys

__all__ = [
    "CodexHandoffConfig",
    "ExternalSynthesisConfig",
    "GRaDOSConfig",
    "GRaDOSPaths",
    "IndexingConfig",
    "generate_default_config",
    "get_secret_summary",
    "load_config",
    "resolve_data_root",
]

# ── Path resolution ──────────────────────────────────────────────────────────


def resolve_data_root() -> Path:
    """Resolve the GRaDOS data root directory.

    Priority:
      1. GRADOS_HOME environment variable
      2. ~/GRaDOS/ (default, non-hidden, cross-platform)
    """
    if env := os.environ.get("GRADOS_HOME"):
        return Path(env).expanduser().resolve()
    return Path.home() / "GRaDOS"


# ── Well-known subdirectories ────────────────────────────────────────────────


class GRaDOSPaths:
    """All well-known paths derived from a single data root."""

    def __init__(self, root: Path | None = None) -> None:
        self.root = root or resolve_data_root()

    @property
    def config_file(self) -> Path:
        return self.root / "config.json"

    @property
    def papers(self) -> Path:
        return self.root / "papers"

    @property
    def downloads(self) -> Path:
        return self.root / "downloads"

    @property
    def database_root(self) -> Path:
        return self.root / "database"

    @property
    def browser_root(self) -> Path:
        return self.root / "browser"

    @property
    def browser_chromium(self) -> Path:
        return self.browser_root / "chromium"

    @property
    def browser_profile(self) -> Path:
        return self.browser_root / "profile"

    @property
    def chatgpt_browser_profile(self) -> Path:
        return self.browser_root / "chatgpt-profile"

    @property
    def chatgpt_browser_sessions(self) -> Path:
        return self.browser_root / "chatgpt-sessions"

    @property
    def browser_pdf_sessions(self) -> Path:
        return self.browser_root / "pdf-sessions"

    @property
    def browser_extensions(self) -> Path:
        return self.browser_root / "extensions"

    @property
    def models_root(self) -> Path:
        return self.root / "models"

    @property
    def models_embedding(self) -> Path:
        return self.models_root / "embedding"

    @property
    def models_ocr(self) -> Path:
        return self.models_root / "ocr"

    @property
    def database_chroma(self) -> Path:
        return self.database_root / "chroma"

    @property
    def database_remote_metadata(self) -> Path:
        return self.database_root / "remote_metadata"

    @property
    def database_state(self) -> Path:
        return self.database_root / "research.sqlite3"

    @property
    def research_checkpoints(self) -> Path:
        return self.root / "research_checkpoints"

    @property
    def paper_summaries(self) -> Path:
        return self.root / "paper_summaries"

    @property
    def logs(self) -> Path:
        return self.root / "logs"

    @property
    def cache(self) -> Path:
        return self.root / "cache"

    def ensure_directories(self) -> None:
        """Create the core directory structure."""
        for d in [
            self.root,
            self.papers,
            self.downloads,
            self.database_root,
            self.research_checkpoints,
            self.paper_summaries,
            self.logs,
            self.cache,
        ]:
            d.mkdir(parents=True, exist_ok=True)

    def all_paths(self) -> list[tuple[str, Path]]:
        """Return label-path pairs for display."""
        return [
            ("数据根目录", self.root),
            ("配置文件", self.config_file),
            ("论文目录", self.papers),
            ("下载目录", self.downloads),
            ("状态数据库", self.database_state),
            ("研究 checkpoint", self.research_checkpoints),
            ("论文 summary", self.paper_summaries),
            ("浏览器二进制", self.browser_chromium),
            ("浏览器配置", self.browser_profile),
            ("PDF 浏览器会话", self.browser_pdf_sessions),
            ("ChatGPT 浏览器配置", self.chatgpt_browser_profile),
            ("ChatGPT 浏览器会话", self.chatgpt_browser_sessions),
            ("浏览器扩展", self.browser_extensions),
            ("嵌入模型", self.models_embedding),
            ("远程元数据", self.database_remote_metadata),
            ("ChromaDB", self.database_chroma),
            ("日志目录", self.logs),
        ]


# ── Pydantic config models (mirrors grados-config.json) ─────────────────────


class SearchConfig(BaseModel):
    order: list[str] = Field(
        default=["Elsevier", "Springer", "WebOfScience", "Crossref", "PubMed"]
    )
    enabled: dict[str, bool] = Field(default_factory=lambda: {
        "Elsevier": True,
        "Springer": True,
        "WebOfScience": True,
        "Crossref": True,
        "PubMed": True,
    })
    connect_timeout: float = Field(
        default=10.0,
        ge=1.0,
        description="TCP connect timeout (seconds) for search API calls.",
    )
    read_timeout: float = Field(
        default=30.0,
        ge=1.0,
        description="Response read timeout (seconds) for search API calls.",
    )


class FetchStrategyConfig(BaseModel):
    order: list[str] = Field(default=["api", "browser", "codex", "scihub"])
    enabled: dict[str, bool] = Field(default_factory=lambda: {
        "api": True,
        "browser": True,
        "codex": False,
        "scihub": True,
    })


class UnpaywallConfig(BaseModel):
    enabled: bool = True


class CodexHandoffConfig(BaseModel):
    download_watch_dir: str = Field(
        default="~/Downloads",
        description=(
            "Directory scanned by ingest_codex_downloaded_pdf after a Codex Chrome Extension "
            "handoff. This does not configure Chrome's download directory."
        ),
    )
    download_max_age_seconds: float = Field(
        default=900.0,
        ge=1.0,
        description="Maximum candidate PDF age, in seconds, after a Codex handoff is issued.",
    )
    download_settle_seconds: float = Field(
        default=2.0,
        ge=0.0,
        description="Seconds a candidate download must remain size/mtime-stable before ingest.",
    )
    download_settle_max_wait_seconds: float = Field(
        default=30.0,
        ge=0.0,
        description="Maximum seconds to wait for a candidate download to settle.",
    )
    download_scan_recursive: bool = Field(
        default=False,
        description="Recursively scan the watch directory for Codex handoff PDFs when true.",
    )


DEFAULT_SCI_HUB_ENDPOINT = "https://sci-hub.se"


class SciHubConfig(BaseModel):
    endpoints: list[str] = Field(default_factory=lambda: [DEFAULT_SCI_HUB_ENDPOINT])
    fallback_mirror: str = DEFAULT_SCI_HUB_ENDPOINT

    @model_validator(mode="before")
    @classmethod
    def _migrate_legacy_fallback_mirror(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        if data.get("endpoints"):
            return data
        fallback = str(data.get("fallback_mirror") or DEFAULT_SCI_HUB_ENDPOINT)
        return {**data, "endpoints": [fallback]}


class HeadlessBrowserConfig(BaseModel):
    browser: str = "chrome"
    prefer_managed_browser: bool = True
    auto_install_managed_browser: bool = True
    use_persistent_profile: bool = True
    executable_path: str = ""
    reuse_interactive_window: bool = True
    keep_interactive_window_open: bool = True
    close_pdf_page_after_capture: bool = True
    deadline_seconds: float = Field(
        default=120.0,
        ge=10.0,
        description="Maximum wall-clock seconds for the main browser polling loop (per DOI).",
    )
    networkidle_timeout: float = Field(
        default=15.0,
        ge=1.0,
        description=(
            "Ceiling (seconds) for wait_for_load_state('networkidle'). SPA "
            "background polling can keep the network busy indefinitely; this "
            "timeout hands control back to the main polling loop instead of "
            "silently eating the deadline."
        ),
    )
    pdf_backfill_timeout: float = Field(
        default=120.0,
        ge=1.0,
        description="Timeout (seconds) for browser context.request direct-PDF backfill.",
    )
    poll_min_seconds: float = Field(
        default=0.5,
        ge=0.1,
        description=(
            "Starting sleep between main-loop iterations. Backs off up to "
            "poll_max_seconds on consecutive idle ticks."
        ),
    )
    poll_max_seconds: float = Field(
        default=2.0,
        ge=0.1,
        description="Upper bound for the main-loop sleep after backoff. Must be >= poll_min_seconds.",
    )


class ParsingConfig(BaseModel):
    order: list[str] = Field(default=["Docling", "MinerU", "PyMuPDF"])
    enabled: dict[str, bool] = Field(default_factory=lambda: {
        "Docling": True,
        "MinerU": True,
        "PyMuPDF": True,
    })
    marker_timeout: int = Field(default=120000, description="Timeout in milliseconds for isolated Marker parser runs.")
    mineru_timeout: int = Field(default=300000, description="Timeout in milliseconds for MinerU cloud parsing.")
    mineru_poll_interval: float = Field(default=3.0, ge=0.5, description="Seconds between MinerU task polls.")
    mineru_model_version: str = Field(default="vlm", description="MinerU model version: pipeline or vlm.")
    mineru_language: str = Field(default="en", description="MinerU document language hint.")
    mineru_enable_formula: bool = True
    mineru_enable_table: bool = True
    mineru_is_ocr: bool = False


class QAConfig(BaseModel):
    min_characters: int = 1500


class AssetsConfig(BaseModel):
    mode: Literal["all", "referenced", "none"] = Field(
        default="all",
        description="Asset persistence mode for parser-generated figures, tables, formulas, pages, and debug files.",
    )
    docling_image_scale: float = Field(
        default=2.0,
        gt=0,
        description="Docling image scale used when generating referenced page, picture, and table images.",
    )
    max_asset_file_bytes: int = Field(
        default=DEFAULT_MAX_ASSET_FILE_BYTES,
        ge=1,
        description="Maximum bytes allowed for one persisted parser asset.",
    )
    max_asset_total_bytes: int = Field(
        default=DEFAULT_MAX_ASSET_TOTAL_BYTES,
        ge=1,
        description="Maximum total bytes allowed for one paper's persisted asset bundle.",
    )
    max_asset_inline_bytes: int = Field(
        default=DEFAULT_MAX_ASSET_INLINE_BYTES,
        ge=1,
        description="Maximum image bytes returned inline by read_paper_asset.",
    )
    max_asset_count: int = Field(
        default=DEFAULT_MAX_ASSET_COUNT,
        ge=1,
        description="Maximum number of assets saved for one paper.",
    )


class ExtractSecurityConfig(BaseModel):
    max_remote_pdf_bytes: int = Field(
        default=DEFAULT_MAX_REMOTE_PDF_BYTES,
        ge=1,
        description="Maximum bytes allowed for remote PDF responses before fetch fallback/failure.",
    )
    max_remote_text_bytes: int = Field(
        default=DEFAULT_MAX_REMOTE_TEXT_BYTES,
        ge=1,
        description="Maximum bytes allowed for remote native text, HTML, XML, and JSON article responses.",
    )
    max_local_pdf_bytes: int = Field(
        default=DEFAULT_MAX_LOCAL_PDF_BYTES,
        ge=1,
        description="Maximum bytes allowed when parsing or importing a local PDF path.",
    )
    max_browser_capture_bytes: int = Field(
        default=DEFAULT_MAX_BROWSER_CAPTURE_BYTES,
        ge=1,
        description="Maximum bytes allowed for browser-captured PDF bodies or download temp files.",
    )
    max_mineru_zip_bytes: int = Field(
        default=DEFAULT_MAX_MINERU_ZIP_BYTES,
        ge=1,
        description="Maximum bytes allowed for MinerU result zip downloads.",
    )
    max_mineru_full_md_bytes: int = Field(
        default=DEFAULT_MAX_MINERU_FULL_MD_BYTES,
        ge=1,
        description="Maximum uncompressed bytes allowed for MinerU full.md inside the result zip.",
    )


class TDMConfig(BaseModel):
    order: list[str] = Field(default=["Elsevier", "Springer"])
    enabled: dict[str, bool] = Field(default_factory=lambda: {
        "Elsevier": True,
        "Springer": True,
    })


class ExtractConfig(BaseModel):
    fetch_strategy: FetchStrategyConfig = Field(default_factory=FetchStrategyConfig)
    unpaywall: UnpaywallConfig = Field(default_factory=UnpaywallConfig)
    codex_handoff: CodexHandoffConfig = Field(default_factory=CodexHandoffConfig)
    tdm: TDMConfig = Field(default_factory=TDMConfig)
    sci_hub: SciHubConfig = Field(default_factory=SciHubConfig)
    headless_browser: HeadlessBrowserConfig = Field(default_factory=HeadlessBrowserConfig)
    parsing: ParsingConfig = Field(default_factory=ParsingConfig)
    qa: QAConfig = Field(default_factory=QAConfig)
    assets: AssetsConfig = Field(default_factory=AssetsConfig)
    security: ExtractSecurityConfig = Field(default_factory=ExtractSecurityConfig)
    fetch_connect_timeout: float = Field(
        default=15.0,
        ge=1.0,
        description="TCP connect timeout (seconds) for api / unpaywall / scihub HTTP calls.",
    )
    fetch_read_timeout: float = Field(
        default=60.0,
        ge=1.0,
        description=(
            "Response read timeout (seconds) for landing-page, HTML, XML, JSON, and non-PDF "
            "full-text fetches."
        ),
    )
    pdf_read_timeout: float = Field(
        default=120.0,
        ge=1.0,
        description="Response read timeout (seconds) for direct remote PDF downloads.",
    )


class IndexingConfig(BaseModel):
    provider: str = "harrier"
    model_id: str = "microsoft/harrier-oss-v1-270m"
    query_prompt_name: str = "web_search_query"
    query_instruction: str = (
        "Given a scientific literature search query, retrieve relevant abstracts and passages that answer the query"
    )
    max_length: int = 4096
    batch_size: int = Field(default=0, ge=0)
    device: str = "auto"
    cache_dir: str = ""
    chunk_min_chars: int = 300
    chunk_max_chars: int = 2000
    chunk_overlap_paragraphs: int = 1


class ZoteroConfig(BaseModel):
    library_id: str = ""
    library_type: str = "user"
    default_collection_key: str = ""


class ApiKeysConfig(BaseModel):
    ELSEVIER_API_KEY: str = ""
    PUBMED_API_KEY: str = ""
    WOS_API_KEY: str = ""
    SPRINGER_meta_API_KEY: str = ""
    SPRINGER_OA_API_KEY: str = ""
    MINERU_API_KEY: str = ""
    ZOTERO_API_KEY: str = ""


class RetryPolicyConfig(BaseModel):
    """Retry knobs for external HTTP calls (ADR-008).

    Retries are triggered by transient failures: 429, 5xx, httpx.ConnectError,
    httpx.ReadTimeout, httpx.WriteError, httpx.PoolTimeout,
    httpx.RemoteProtocolError. Non-retryable errors propagate immediately.
    """

    max_attempts: int = Field(
        default=3,
        ge=1,
        description="Total attempts including the first call. 1 disables retries.",
    )
    max_wait: float = Field(
        default=8.0,
        ge=0.0,
        description="Upper bound (seconds) on a single backoff wait between attempts.",
    )
    respect_retry_after: bool = Field(
        default=True,
        description=(
            "When true, honor Retry-After / X-RateLimit-Reset response "
            "headers if the upstream requests a specific backoff."
        ),
    )


class IndepthConfig(BaseModel):
    enabled: bool = Field(
        default=False,
        description="Enable indepth search by default. The MCP/CLI flag can override this per request.",
    )
    auto_summarize: bool = Field(
        default=True,
        description="Generate reusable paper_summary artifacts after successful full-text materialization.",
    )


class ExternalSynthesisConfig(BaseModel):
    enabled: bool = Field(
        default=False,
        description=(
            "Enable GRaDOS-native ChatGPT Pro browser synthesis after verified evidence "
            "packet preparation. GRaDOS uses a private Chrome profile and still treats "
            "the returned response as advisory until packet audit and canonical reread."
        ),
    )


class ResearchConfig(BaseModel):
    indepth: IndepthConfig = Field(default_factory=IndepthConfig)
    external_synthesis: ExternalSynthesisConfig = Field(default_factory=ExternalSynthesisConfig)


class GRaDOSConfig(BaseModel):
    """Root configuration model."""

    debug: bool = False
    search: SearchConfig = Field(default_factory=SearchConfig)
    extract: ExtractConfig = Field(default_factory=ExtractConfig)
    research: ResearchConfig = Field(default_factory=ResearchConfig)
    indexing: IndexingConfig = Field(default_factory=IndexingConfig)
    zotero: ZoteroConfig = Field(default_factory=ZoteroConfig)
    api_keys: ApiKeysConfig = Field(default_factory=ApiKeysConfig)
    retry_policy: RetryPolicyConfig = Field(default_factory=RetryPolicyConfig)
    academic_etiquette_email: str = "your-email@university.edu"
    _secret_summary: SecretResolutionSummary | None = PrivateAttr(default=None)


# ── Config loading ───────────────────────────────────────────────────────────


def _preserve_literal_config_key(key: str) -> bool:
    """Return true for config keys whose spelling is part of a public contract."""
    if key in {spec.field_name for spec in iter_api_key_specs()}:
        return True
    return any(ch.isalpha() for ch in key) and key.upper() == key


_LITERAL_MAP_PARENT_KEYS = {"enabled"}


def _snake_to_camel_keys(data: Any, *, _parent_key: str = "") -> Any:
    """Recursively convert camelCase JSON keys to snake_case for Pydantic."""
    if isinstance(data, dict):
        if _parent_key in _LITERAL_MAP_PARENT_KEYS:
            return {str(k): _snake_to_camel_keys(v) for k, v in data.items()}

        out: dict[str, Any] = {}
        for k, v in data.items():
            # Strip _comment fields
            if k.startswith("_comment"):
                continue
            # Preserve literal keys such as API-key env names and strategy IDs.
            if _preserve_literal_config_key(k):
                out[k] = _snake_to_camel_keys(v, _parent_key=k)
                continue
            # camelCase → snake_case
            snake = ""
            for i, ch in enumerate(k):
                if ch.isupper() and i > 0:
                    snake += "_"
                snake += ch.lower()
            out[snake] = _snake_to_camel_keys(v, _parent_key=snake)
        return out
    if isinstance(data, list):
        return [_snake_to_camel_keys(item, _parent_key=_parent_key) for item in data]
    return data


def load_config(paths: GRaDOSPaths | None = None) -> GRaDOSConfig:
    """Load config.json, falling back to defaults."""
    paths = paths or GRaDOSPaths()
    config_file = paths.config_file
    if config_file.is_file():
        raw = json.loads(config_file.read_text(encoding="utf-8"))
        normalized = _snake_to_camel_keys(raw)
        config = GRaDOSConfig.model_validate(normalized)
    else:
        config = GRaDOSConfig()

    summary = resolve_api_keys(
        config_file=config_file,
        config_values={k: v for k, v in config.api_keys.model_dump().items() if isinstance(v, str)},
    )
    for field_name, entry in summary.entries.items():
        setattr(config.api_keys, field_name, entry.value)
    config._secret_summary = summary
    return config


def generate_default_config(paths: GRaDOSPaths) -> dict[str, Any]:
    """Generate a default config dict for writing to disk."""
    config = GRaDOSConfig()
    data = config.model_dump()
    # Add helpful comments
    data["_comment_debug"] = "Set to true to enable verbose benchmark logs."
    data["_comment_academic_etiquette_email"] = (
        "Email for academic APIs (Crossref, Unpaywall). Change to your real institutional email."
    )
    data["_comment_api_keys"] = (
        "Plaintext API keys in config.json are a temporary import path only. "
        "GRaDOS will migrate them to the OS keychain on the next run and then clear them from this file."
    )
    data["_comment_indexing"] = (
        "Semantic indexing defaults. Changing model_id or section-aware chunking settings requires `grados reindex`."
    )
    data["indexing"]["_comment_provider"] = "Default local embedding provider used for semantic indexing."
    data["indexing"]["_comment_model_id"] = (
        "Default embedding model. Harrier 270M is the stable local default; use 0.6B only when you have headroom."
    )
    data["indexing"]["_comment_query_prompt_name"] = (
        "Harrier query-side prompt name. Query/document encoding is intentionally asymmetric."
    )
    data["indexing"]["_comment_max_length"] = (
        "Recommended indexing length cap. Model max context is not the same as a safe local indexing length."
    )
    data["indexing"]["_comment_batch_size"] = (
        "Embedding encode batch size. Use 0 for conservative auto-sizing by device."
    )
    data["indexing"]["_comment_cache_dir"] = (
        "Optional model cache override. Leave empty to use GRaDOS_HOME/models/embedding."
    )

    # Research workflow surface
    data["research"]["_comment_indepth"] = (
        "Indepth mode is disabled by default. Enable per request with `--indepth` "
        "or set research.indepth.enabled=true to make search materialize returned candidates."
    )
    data["research"]["indepth"]["_comment_enabled"] = (
        "Default off. When enabled, search uses the same limit for metadata candidates and full-text attempts."
    )
    data["research"]["indepth"]["_comment_auto_summarize"] = (
        "Generate query-independent paper_summary artifacts after successful full-text saves."
    )
    data["research"]["_comment_external_synthesis"] = (
        "Default-off GRaDOS-native ChatGPT Pro browser reviewer/synthesizer. "
        "GRaDOS sends only verified evidence packets, saves advisory output, and audits it."
    )
    data["research"]["external_synthesis"]["_comment_enabled"] = (
        "Default off. When true, GRaDOS may open its private ChatGPT Chrome profile only "
        "after verified evidence preparation; Oracle's current Pro model and Pro Extended thinking route "
        "are protocol defaults recorded as metadata, not config keys."
    )

    # Timeout / retry surface (ADR-008)
    data["search"]["_comment_connect_timeout"] = (
        "TCP connect timeout in seconds for academic search APIs (Crossref, PubMed, WoS, Elsevier, Springer)."
    )
    data["search"]["_comment_read_timeout"] = (
        "Response read timeout in seconds for academic search APIs."
    )
    data["extract"]["_comment_fetch_connect_timeout"] = (
        "TCP connect timeout in seconds for api / unpaywall / scihub HTTP calls."
    )
    data["extract"]["_comment_fetch_read_timeout"] = (
        "Response read timeout in seconds for landing-page, HTML, XML, JSON, and non-PDF full-text fetches."
    )
    data["extract"]["_comment_pdf_read_timeout"] = (
        "Response read timeout in seconds for direct remote PDF downloads. "
        "Size limits still enforce the maximum accepted PDF bytes."
    )
    data["extract"]["assets"]["_comment_mode"] = (
        "Parser asset persistence mode. `all` saves all allowed parser assets, "
        "`referenced` keeps content-linked assets, and `none` disables asset bundles."
    )
    data["extract"]["assets"]["_comment_docling_image_scale"] = (
        "Image scale used by Docling when generating referenced page, picture, and table images."
    )
    data["extract"]["assets"]["_comment_max_asset_file_bytes"] = (
        "Maximum size in bytes for one persisted parser asset file."
    )
    data["extract"]["assets"]["_comment_max_asset_total_bytes"] = (
        "Maximum total size in bytes for one saved paper's asset bundle."
    )
    data["extract"]["assets"]["_comment_max_asset_inline_bytes"] = (
        "Maximum image size in bytes that read_paper_asset may return inline."
    )
    data["extract"]["assets"]["_comment_max_asset_count"] = (
        "Maximum number of parser assets saved for one paper."
    )
    data["extract"]["security"]["_comment_max_remote_pdf_bytes"] = (
        "Maximum remote PDF response size in bytes. The default is intentionally generous for normal papers."
    )
    data["extract"]["security"]["_comment_max_remote_text_bytes"] = (
        "Maximum remote native text, HTML, XML, or JSON article payload size in bytes."
    )
    data["extract"]["security"]["_comment_max_local_pdf_bytes"] = (
        "Maximum local PDF size in bytes for parse_pdf_file and import-pdfs."
    )
    data["extract"]["security"]["_comment_max_browser_capture_bytes"] = (
        "Maximum PDF body or download temp-file size captured by the browser strategy."
    )
    data["extract"]["security"]["_comment_max_mineru_zip_bytes"] = (
        "Maximum MinerU result zip size in bytes before markdown and asset extraction."
    )
    data["extract"]["security"]["_comment_max_mineru_full_md_bytes"] = (
        "Maximum uncompressed full.md size in bytes inside the MinerU result zip."
    )
    data["extract"]["fetch_strategy"]["_comment_order"] = (
        "PDF/full-text retrieval order. `codex` is a disabled-by-default Codex Chrome extension handoff."
    )
    data["extract"]["unpaywall"]["_comment_enabled"] = (
        "When true, resolve DOI to Unpaywall OA locations before codex/browser acquisition. "
        "Unpaywall is not a download strategy and does not affect api or scihub."
    )
    data["extract"]["codex_handoff"]["_comment_download_watch_dir"] = (
        "Directory scanned only by ingest_codex_downloaded_pdf after a Codex Chrome Extension handoff. "
        "Default ~/Downloads follows Chrome's usual per-user download location and does not configure Chrome."
    )
    data["extract"]["codex_handoff"]["_comment_download_max_age_seconds"] = (
        "Maximum candidate PDF age after the handoff receipt is issued."
    )
    data["extract"]["codex_handoff"]["_comment_download_settle_seconds"] = (
        "Seconds a candidate PDF must remain size/mtime-stable before ingest."
    )
    data["extract"]["codex_handoff"]["_comment_download_settle_max_wait_seconds"] = (
        "Maximum seconds to wait for a candidate PDF to settle."
    )
    data["extract"]["codex_handoff"]["_comment_download_scan_recursive"] = (
        "When false, only scan the watch directory root. Recursive scanning is opt-in."
    )
    data["extract"]["tdm"]["_comment_order"] = (
        "Publisher API/TDM providers tried by the api fetch strategy."
    )
    data["extract"]["sci_hub"]["_comment_endpoints"] = (
        "Ordered Sci-Hub access endpoints. The first endpoint is tried first; later endpoints are fallbacks."
    )
    data["extract"]["sci_hub"]["_comment_fallback_mirror"] = (
        "Legacy compatibility endpoint used only when endpoints is omitted or empty."
    )
    data["extract"]["headless_browser"]["_comment_browser"] = (
        "Fallback system browser type when the managed browser is unavailable. Supported value: chrome."
    )
    data["extract"]["headless_browser"]["_comment_prefer_managed_browser"] = (
        "Prefer the GRaDOS-managed Chrome for Testing under GRADOS_HOME/browser/chromium."
    )
    data["extract"]["headless_browser"]["_comment_auto_install_managed_browser"] = (
        "Reserved bootstrap policy flag; run `grados setup` to install/update the managed browser."
    )
    data["extract"]["headless_browser"]["_comment_use_persistent_profile"] = (
        "Use GRADOS_HOME/browser/profile as a persistent browser profile to reduce repeated publisher checks."
    )
    data["extract"]["headless_browser"]["_comment_executable_path"] = (
        "Optional absolute browser executable override used after the managed browser when prefer_managed_browser=true."
    )
    data["extract"]["headless_browser"]["_comment_reuse_interactive_window"] = (
        "Reuse the same visible browser session while the process stays alive."
    )
    data["extract"]["headless_browser"]["_comment_keep_interactive_window_open"] = (
        "Keep the visible browser open after fetch attempts so completed verification can help later requests."
    )
    data["extract"]["headless_browser"]["_comment_close_pdf_page_after_capture"] = (
        "Close captured PDF tabs while keeping the reusable browser window/profile alive."
    )
    data["extract"]["headless_browser"]["_comment_deadline_seconds"] = (
        "Maximum wall-clock seconds for the browser main polling loop per DOI."
    )
    data["extract"]["headless_browser"]["_comment_networkidle_timeout"] = (
        "Ceiling in seconds for wait_for_load_state('networkidle'). See ADR-008."
    )
    data["extract"]["headless_browser"]["_comment_pdf_backfill_timeout"] = (
        "Timeout in seconds for browser context.request direct-PDF backfill; navigation deadlines are separate."
    )
    data["extract"]["headless_browser"]["_comment_poll_min_seconds"] = (
        "Starting sleep between browser main-loop iterations."
    )
    data["extract"]["headless_browser"]["_comment_poll_max_seconds"] = (
        "Upper bound for the browser main-loop sleep after exponential backoff."
    )
    data["extract"]["parsing"]["_comment_marker_timeout"] = (
        "Maximum time in milliseconds to wait for the isolated Marker subprocess."
    )
    data["extract"]["parsing"]["_comment_mineru_timeout"] = (
        "Maximum time in milliseconds to wait for MinerU's authenticated cloud parser."
    )
    data["extract"]["parsing"]["_comment_mineru_model_version"] = (
        "MinerU cloud model version. Use `vlm` for precise PDF parsing, or `pipeline` for the lighter model."
    )
    data["extract"]["parsing"]["_comment_mineru_language"] = (
        "MinerU language hint. Default `en` fits most academic PDFs; use `ch` for Chinese documents."
    )
    data["_comment_retry_policy"] = (
        "Unified retry knobs for external HTTP calls (ADR-008). Retries cover 429, 5xx, network errors."
    )
    data["retry_policy"]["_comment_max_attempts"] = (
        "Total attempts including the first call. 1 disables retries."
    )
    data["retry_policy"]["_comment_max_wait"] = (
        "Upper bound in seconds on a single backoff wait between attempts."
    )
    data["retry_policy"]["_comment_respect_retry_after"] = (
        "Honor Retry-After / X-RateLimit-Reset response headers when true."
    )
    return data


def get_secret_summary(config: GRaDOSConfig) -> SecretResolutionSummary | None:
    """Return the cached API-key resolution summary from `load_config`."""
    return config._secret_summary
