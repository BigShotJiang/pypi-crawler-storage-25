# -*- coding: utf-8 -*-
"""
:Author: CaiYouBin
:Date: 2026-04-28 11:45:38
:LastEditTime: 2026-04-28 12:03:27
:LastEditors: CaiYouBin
:Description: 
"""
from seven_cloudapp_frame.handlers.frame_base import *
class MainBusinessKey(DependencyKey):
    @classmethod
    def user_info_ex(self, act_id, user_id):
        """
        :description: 用户扩展信息
        :param act_id: 活动id
        :return str
        :last_editors: CaiYouBin
        """
        dependency_key = f"user_info_ex:actid_{act_id}_userid_{user_id}"
        return dependency_key
    @classmethod
    def page_info_list(self, act_id):
        """
        :description: 页面信息
        :param act_id: 活动id
        :return str
        :last_editors: CaiYouBin
        """
        dependency_key = f"page_info_list:actid_{act_id}"
        return dependency_key
    @classmethod
    def module_info(self, module_id):
        """
        :description: 模块信息
        :param module_id: 模块标识
        :return str
        :last_editors: CaiYouBin
        """
        dependency_key = f"module_info:moduleid_{module_id}"
        return dependency_key
    @classmethod
    def module_info_list(self, act_id):
        """
        :description: 模块信息列表
        :param act_id: 活动id
        :return str
        :last_editors: CaiYouBin
        """
        dependency_key = f"module_info_list:actid_{act_id}"
        return dependency_key
    @classmethod
    def act_info_ex(self, act_id):
        """
        :description: 活动信息拓展表
        :param act_id: 活动id
        :return str
        :last_editors: WangQiang
        """
        dependency_key = f"act_info_ex:actid_{act_id}"
        return dependency_key
    @classmethod
    def theme_info(self, ascription_type):
        """
        :description: 主题表
        :param ascription_type: 归属类型
        :return: str
        :last_editors: PengJingLing
        """
        dependency_key = f"theme_info:ascriptiontype_{ascription_type}"
        return dependency_key
    @classmethod
    def theme_customize(self, act_id):
        """
        :description: 自定义主题表
        :param act_id: 活动标识
        :return: str
        :last_editors: PengJingLing
        """
        dependency_key = f"theme_customize:actid_{act_id}"
        return dependency_key
    @classmethod
    def nav_menu_list(self, act_id):
        """
        :description: 导航菜单列表
        :param act_id: 活动标识
        :return: str
        :last_editors: CaiYouBin
        """
        dependency_key = f"nav_menu_list:actid_{act_id}"
        return dependency_key
    
    @classmethod
    def page_data_list(self,act_id):
        """
        :description: 页面数据列表
        :param act_id: 活动标识
        :return: str
        :last_editors: CaiYouBin
        """
        dependency_key = f"page_data_list:actid_{act_id}"
        return dependency_key