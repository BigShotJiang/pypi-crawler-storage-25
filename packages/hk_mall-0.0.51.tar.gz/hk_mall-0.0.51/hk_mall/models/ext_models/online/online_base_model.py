# -*- coding: utf-8 -*-
"""
:Author: CaiYouBin
:Date: 2026-04-21 14:40:09
:LastEditTime: 2026-04-22 10:49:05
:LastEditors: CaiYouBin
:Description: 
"""
from hk_mall.models.online_model import OnlineBusinessKey
from seven_cloudapp_frame.handlers.frame_base import *



class OnlineBaseModel:
    def __init__(self, context=None, logging_error=None, logging_info=None):
        """
        @description: 初始化
        @last_editors: CaiYouBin
        """
        self.context = context
        self.logging_link_error = logging_error
        self.logging_link_info = logging_info
        
    def get_cache_version(self, redis_conn, app_id, cache_key):
        """
        :description: 获取缓存版本号
        :param app_id: 店铺app_id
        :param cache_key: 缓存键名
        :return: 缓存版本号
        :last_editors: KangWenBin
        """
        cache_version = redis_conn.hget(OnlineBusinessKey.app_cache_version(app_id), cache_key)
        if cache_version:
            cache_version = int(cache_version)
        else:
            cache_version = 1000  # 初始版本号1000
            # 写入缓存版本号
            redis_conn.hset(OnlineBusinessKey.app_cache_version(app_id), cache_key, cache_version)
        return cache_version
    
    def get_goods_picture(self, goods_main_images):
        """
        :Description: 从多张主图中获取首张作为列表图
        :param goods_main_images: 商品主图JSON字符串
        :return: 首张图片URL
        :last_editors: SunYiTan
        """
        ret = ""
        try:
            ret = json.loads(goods_main_images)[0]
        except Exception:
            ret = ""
        return ret