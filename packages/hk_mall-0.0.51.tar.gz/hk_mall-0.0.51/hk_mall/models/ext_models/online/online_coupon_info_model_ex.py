# -*- coding: utf-8 -*-
"""
:Author: SunYiTan
:Date: 2026-02-06 00:00:00
:LastEditTime: 2026-04-21 11:58:35
:LastEditors: SunYiTan
:Description: 优惠券信息扩展模型
"""

from hk_mall.models.db_models.online.online_coupon_info_model import OnlineCouponInfoModel


class OnlineCouponInfoModelEx(OnlineCouponInfoModel):

    def __init__(self, db_connect_key='db_saas_wx_online', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super().__init__(db_connect_key, sub_table, db_transaction, context, is_auto)
        self.context = context
