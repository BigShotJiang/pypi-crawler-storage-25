# -*- coding: utf-8 -*-
"""
:Author: Kangwenbin
:Date: 2021-11-22 19:28:39
:LastEditTime: 2026-04-21 12:01:09
:LastEditors: SunYiTan
:Description: 商品SKU扩展模型
"""

import json

from hk_mall.models.db_models.online.online_goods_sku_model import OnlineGoodsSkuModel
from seven_cloudapp_frame.libs.customize.seven_helper import SevenHelper
from hk_mall.models.cache_key.online_business_base import OnlineBusinessKey


class OnlineGoodsSkuModelEx(OnlineGoodsSkuModel):
    """
    :Description: 商品SKU扩展模型
    :last_editors: KangWenBin
    """

    def __init__(self, db_connect_key="db_saas_wx_online", sub_table=None, db_transaction=None, context=None):
        super().__init__(db_connect_key, sub_table, db_transaction, context)

    def get_goods_first_level_attrs_batch(self, app_id, goods_ids):
        """
        :Description: 批量获取商品SKU的第一级属性
        :param goods_ids: 商品ID列表
        :return: 字典，key为商品ID，value为该商品所有SKU的第一级属性列表
        :last_editors: SunYiTan
        """
        ret_dict = {}

        if not goods_ids:
            return ret_dict

        # 使用 SevenHelper 生成IN条件，批量查询
        where = SevenHelper.get_condition_by_int_list("goods_id", goods_ids)
        where += " AND status=1"
        field = "goods_id,sku_info,price"  # 额外获取sku价格做最大比对
        sku_list = self.get_cache_dict_list(where=where, field=field, dependency_key=OnlineBusinessKey.goods_ids_sku_list(app_id))

        if not sku_list:
            return ret_dict

        # 处理每个商品的SKU属性
        for sku in sku_list:
            goods_id = sku["goods_id"]
            sku_info = sku["sku_info"]
            price = sku["price"]

            # 初始化商品的属性列表
            if goods_id not in ret_dict:
                ret_dict[goods_id] = {"sku_attr_list": [], "max_price": 0}

            # 解析sku_info
            if not sku_info:
                continue

            try:
                json_sku_list = json.loads(sku_info)
                # 获取第一级属性（第一个属性的值）
                if json_sku_list and len(json_sku_list) > 0:
                    first_attr_value = json_sku_list[0]["model_value"]
                    # 去重添加
                    if first_attr_value not in ret_dict[goods_id]["sku_attr_list"]:
                        ret_dict[goods_id]["sku_attr_list"].append(first_attr_value)
                    # 更新最大价格
                    ret_dict[goods_id]["max_price"] = price if price > ret_dict[goods_id]["max_price"] else ret_dict[goods_id]["max_price"]
            except Exception:
                continue

        return ret_dict
