# -*- coding: utf-8 -*-
"""
:Author: Kangwenbin
:Date: 2021-11-22 18:36:29
:LastEditTime: 2026-04-21 11:59:57
:LastEditors: SunYiTan
:Description: 商品信息扩展模型
"""

import json
from re import T

from hk_mall.libs.customize.member_base_model import MemberBaseModel
from seven_framework.time import *
from hk_mall.models.cache_key.online_business_base import OnlineBusinessKey
from hk_mall.models.db_models.online.online_goods_info_model import OnlineGoodsInfoModel
from hk_mall.models.ext_models.online.online_goods_sku_model_ex import OnlineGoodsSkuModelEx
from hk_mall.models.ext_models.online.online_coupon_info_model_ex import OnlineCouponInfoModelEx
from hk_mall.models.db_models.online.online_coupon_record_model import OnlineCouponRecordModel
from hk_mall.models.db_models.online.online_coupon_goods_model import OnlineCouponGoodsModel
from hk_mall.models.db_models.online.online_hot_sale_rank_model import OnlineHotSaleRankModel


class OnlineGoodsInfoModelEx(OnlineGoodsInfoModel):
    """
    :Description: 商品信息扩展模型
    :last_editors: KangWenBin
    """

    def __init__(self, db_connect_key='db_saas_wx_online', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super().__init__(db_connect_key, sub_table, db_transaction, context, is_auto)
        self.context = context

    def get_goods_picture(self, goods_main_images):
        """
        :Description: 从多张主图中获取首张作为列表图
        :param goods_main_images: 商品主图JSON字符串
        :return: 首张图片URL
        :last_editors: SunYiTan
        """
        ret = ""
        try:
            ret = json.loads(goods_main_images)[0]
        except Exception:
            ret = ""
        return ret

    def enrich_goods_list_with_sku(self, goods_list, app_id):
        """
        :Description: 为商品列表添加SKU属性
        :param goods_list: 商品列表
        :param app_id: 店铺APP ID
        :return: 处理后的商品列表
        :last_editors: SunYiTan
        """
        if not goods_list:
            return goods_list

        goods_ids = [item["id"] for item in goods_list]
        goods_sku_model = OnlineGoodsSkuModelEx(context=self.context)
        sku_attrs_dict = goods_sku_model.get_goods_first_level_attrs_batch(app_id, goods_ids)

        # 为每个商品添加sku_attrs字段
        for item in goods_list:
            sku_attr_info = sku_attrs_dict.get(item["id"], {})
            item["sku_attrs"] = sku_attr_info.get("sku_attr_list", [])
            item["max_price"] = sku_attr_info.get("max_price", item.get("price", 0))

        return goods_list

    def enrich_goods_list_with_coupon(self, redis_conn, goods_list, app_id, user_code, open_id=""):
        """
        :description: 为商品列表添加优惠券信息
        :last_editors: KangWenBin
        """
        if not goods_list:
            return goods_list

        # 获取所有的普通优惠券（查询全部，程序中过滤时间）
        now_date = TimeHelper.get_now_format_time()
        all_coupon_list = OnlineCouponInfoModelEx(context=self.context).get_cache_dict_list(where="app_id = %s and grant_type = 0 and status = 1", params=[app_id], field="id as coupon_id,coupon_name,coupon_type,use_price,coupon_price,coupon_discount,goods_limit,record_number,is_time_limit,use_begin_date,use_end_date,begin_date,vip_limit_level", dependency_key=OnlineBusinessKey.coupon_list(app_id))
        member_level_id = 0
        member_status = 0
        if open_id:
            member_info_dict = MemberBaseModel(context=self.context).get_user_member_info(app_id, one_id=open_id, field="one_id,level_id,member_status")
            if member_info_dict:
                member_level_id = int(member_info_dict.get("level_id", 0) or 0)
                member_status = int(member_info_dict.get("member_status", 0) or 0)

        # 程序中过滤时间条件
        coupon_list = []
        for coupon in all_coupon_list:
            # 检查开始透出时间
            if coupon["begin_date"] > now_date:
                continue
            # 检查使用时间限制
            if coupon["is_time_limit"] == 1:  # 限时
                if coupon["use_begin_date"] > now_date:
                    continue
                if coupon["use_end_date"] < now_date:
                    continue

            vip_limit_level = max(int(coupon.get("vip_limit_level", 1) or 1), 1)
            if vip_limit_level > 1 and (member_status != 1 or member_level_id < vip_limit_level):
                continue

            coupon_list.append(coupon)

        # 获取优惠券商品限制列表
        goods_limit_coupon = [x["coupon_id"] for x in coupon_list if x["goods_limit"] == 1]
        coupon_goods_list = []
        if goods_limit_coupon:
            coupon_goods_list = OnlineCouponGoodsModel(context=self.context).get_cache_dict_list(where="coupon_id IN %s", params=(goods_limit_coupon, ), field="coupon_id,goods_id", dependency_key=OnlineBusinessKey.coupon_goods_list(app_id))
        # 将coupon_goods_list合并到coupon_list中
        coupon_goods_map = {}
        if coupon_goods_list:
            for item in coupon_goods_list:
                coupon_id = item["coupon_id"]
                if coupon_id not in coupon_goods_map:
                    coupon_goods_map[coupon_id] = []
                coupon_goods_map[coupon_id].append(item["goods_id"])

        for coupon in coupon_list:
            coupon["goods_list"] = coupon_goods_map.get(coupon["coupon_id"], [])
            # 判断优惠券在redis中是否还有库存
            coupon["has_inventory"] = 0
            coupon_inventory = redis_conn.hget(f"coupon_inventory_{app_id}", coupon["coupon_id"])
            if coupon_inventory:
                if int(coupon_inventory) > 0:
                    coupon["has_inventory"] = 1

        # 获取用户拥有还未使用的优惠券
        user_coupon_all_list = []
        coupon_id_list = [x["coupon_id"] for x in coupon_list]
        if user_code:
            condition = "app_id = %s and user_code = %s"
            if coupon_id_list:
                condition += "  and (status = 0 or (status = 1 and coupon_id in %s)) "
                params = [app_id, user_code, coupon_id_list]
            else:
                condition += " and status = 0"
                params = [app_id, user_code]

            user_coupon_all_list = OnlineCouponRecordModel(context=self.context).set_sub_table(app_id).get_cache_dict_list(where=condition, params=params, field="coupon_id,coupon_info,use_price,goods_limit,goods_list,is_time_limit,use_begin_date,use_end_date,status", dependency_key=OnlineBusinessKey.coupon_record_list(app_id, user_code))

        user_coupon_list = []
        user_coupon_used_list = [x for x in user_coupon_all_list if x["status"] == 1]  # 已使用的优惠券
        user_coupon_unused_list = [x for x in user_coupon_all_list if x["status"] == 0]  # 未使用的优惠券
        for coupon in user_coupon_unused_list:
            # 检查使用时间限制
            if coupon["is_time_limit"] == 1:  # 限时
                if coupon["use_begin_date"] > now_date:
                    continue
                if coupon["use_end_date"] < now_date:
                    continue
            user_coupon_list.append(coupon)
        # 处理用户优惠券列表，解析JSON字段
        processed_user_coupons = []
        for user_coupon in user_coupon_list:
            # 解析coupon_info
            coupon_info = json.loads(user_coupon.get("coupon_info", "{}"))
            # 解析goods_list
            goods_list_str = user_coupon.get("goods_list", "[]")
            goods_id_list = json.loads(goods_list_str) if goods_list_str else []

            processed_coupon = {
                "coupon_id": user_coupon.get("coupon_id", 0),
                "coupon_name": coupon_info.get("coupon_name", ""),
                "coupon_type": coupon_info.get("coupon_type", 0),
                "use_price": user_coupon.get("use_price", 0),
                "coupon_price": coupon_info.get("coupon_price", 0),
                "coupon_discount": coupon_info.get("coupon_discount", 0),
                "goods_limit": user_coupon.get("goods_limit", 0),
                "goods_list": goods_id_list,
                "has_inventory": 1,  # 用户已领取的优惠券默认有库存
                "user_coupon": 1  # 标识用户优惠券
            }
            processed_user_coupons.append(processed_coupon)

        # 合并优惠券列表
        all_coupons = processed_user_coupons + coupon_list
        all_coupons = [x for x in all_coupons if x["has_inventory"] == 1]

        # 循环优惠券，判断那个优惠券价格最高
        if goods_list:
            for item in goods_list:
                if item["goods_type"] == 2:
                    # 预售商品，不计算优惠券
                    item["discount_price"] = 0
                    item["coupon_id"] = 0
                    item["is_user_coupon"] = 0
                    if item.get("sku_list"):
                        for sku in item["sku_list"]:
                            sku["discount_price"] = 0
                            sku["coupon_id"] = 0
                            sku["is_user_coupon"] = 0
                    continue

                if item.get("sku_list"):
                    discount_price = 0
                    coupon_id = 0
                    is_user_coupon = 0
                    for sku in item["sku_list"]:
                        sku_discount_price, sku_coupon_id, sku_is_user_coupon = self.__get_best_coupon_by_price(item["id"], sku["price"], all_coupons, user_coupon_used_list)
                        sku["discount_price"] = sku_discount_price
                        sku["coupon_id"] = sku_coupon_id
                        sku["is_user_coupon"] = sku_is_user_coupon
                        if sku_discount_price > discount_price:
                            discount_price = sku_discount_price
                            coupon_id = sku_coupon_id
                            is_user_coupon = sku_is_user_coupon
                    item["discount_price"] = discount_price
                    item["coupon_id"] = coupon_id
                    item["is_user_coupon"] = is_user_coupon
                else:
                    discount_price, coupon_id, is_user_coupon = self.__get_best_coupon_by_price(item["id"], item["max_price"], all_coupons, user_coupon_used_list)
                    item["discount_price"] = discount_price
                    item["coupon_id"] = coupon_id
                    item["is_user_coupon"] = is_user_coupon

        return goods_list

    def __get_best_coupon_by_price(self, goods_id, price, all_coupons, user_coupon_used_list):
        """
        :Description: 根据商品ID和价格，匹配当前可用的最优优惠券
        :param goods_id: 商品ID，用于校验商品限制券
        :param price: 商品或SKU价格，用于校验使用门槛并计算优惠金额
        :param all_coupons: 当前可参与匹配的优惠券列表
        :param user_coupon_used_list: 用户已使用优惠券列表，用于校验普通券领取上限
        :return: (discount_price, coupon_id, is_user_coupon)
        :last_editors: SunYiTan
        """
        discount_price = 0
        coupon_id = 0
        is_user_coupon = 0
        for coupon in all_coupons:
            # 检查优惠券是否适用于该商品
            if coupon["goods_limit"] == 1:
                # 有商品限制，检查是否包含该商品
                if goods_id not in coupon["goods_list"]:
                    continue

            # 验证优惠金额是否可用
            if coupon["use_price"] > price:
                continue

            # 检查是否已经到达领取上限
            if coupon.get("user_coupon", 0) == 0:
                used_count = sum([1 for x in user_coupon_used_list if x["coupon_id"] == coupon["coupon_id"]])
                if coupon["record_number"] <= used_count:
                    continue

            # 计算优惠力度
            if coupon["coupon_type"] == 0:
                # 满减券
                discount_value = coupon["coupon_price"]
            else:
                # 折扣券
                discount_value = int(price * (100 - coupon["coupon_discount"]) / 100)

            discount_value = min(discount_value, price)

            # 比较优惠力度
            if discount_value > discount_price:
                discount_price = discount_value
                coupon_id = coupon["coupon_id"]
                is_user_coupon = coupon.get("user_coupon", 0)
        return discount_price, coupon_id, is_user_coupon

    def format_goods_rank_list(self, goods_list, app_id, page_size):
        """
        :Description: 统一处理商品榜单列表数据
        :param goods_list: 商品列表
        :param app_id: 店铺APP ID
        :param page_size: 每页数量
        :return: 商品列表和是否有下一页
        :last_editors: SunYiTan
        """
        is_next = False
        if goods_list:
            for item in goods_list:
                if item.get("deposit_begin_date"):
                    item["deposit_begin_date"] = TimeHelper.datetime_to_format_time(item["deposit_begin_date"])
                if item.get("deposit_end_date"):
                    item["deposit_end_date"] = TimeHelper.datetime_to_format_time(item["deposit_end_date"])
                item["goods_picture"] = self.get_goods_picture(item["goods_picture"])
        else:
            goods_list = []

        if len(goods_list) == page_size + 1:
            goods_list = goods_list[:-1]
            is_next = True

        # 批量获取商品的SKU第一级属性
        goods_list = self.enrich_goods_list_with_sku(goods_list, app_id)
        return goods_list, is_next

    def get_recommend_goods_list(self, app_id, page_index, page_size):
        """
        :Description: 获取推荐商品列表
        :param app_id: 店铺APP ID
        :param page_index: 页码
        :param page_size: 每页数量
        :param user_code: 用户标识（用于查询优惠券）
        :return: 推荐商品列表和是否有下一页
        :last_editors: SunYiTan
        """
        limit = f"LIMIT {page_index * page_size},{page_size + 1}"

        sql = f"SELECT a.id,a.goods_main_images AS goods_picture,a.goods_short_name,a.goods_remark,a.price,a.original_price,a.goods_sold,a.goods_type,a.deposit_price,a.deposit_begin_date,a.deposit_end_date FROM online_goods_info_tb a JOIN online_goods_recommend_tb b ON a.id=b.goods_id WHERE a.status=1 AND b.status=1 AND a.app_id=%s ORDER BY b.sort DESC {limit}"
        goods_list = self.db.fetch_all_rows(sql, app_id)
        return self.format_goods_rank_list(goods_list, app_id, page_size)

    def get_hot_sale_rank_goods_list(self, app_id, rank_id, page_index, page_size):
        """
        :Description: 获取热销排行榜商品列表
        :param app_id: 店铺APP ID
        :param rank_id: 榜单ID
        :param page_index: 页码
        :param page_size: 每页数量
        :return: 热销排行榜商品列表和是否有下一页
        :last_editors: SunYiTan
        """
        rank_info = OnlineHotSaleRankModel(context=self.context).get_cache_dict(where="id=%s AND app_id=%s AND status=1", params=[rank_id, app_id], field="id,rank_type", dependency_key=OnlineBusinessKey.hot_sale_rank_info(app_id, rank_id))
        if not rank_info:
            return None, False

        limit = f"LIMIT {page_index * page_size},{page_size + 1}"
        sql = "SELECT a.id,a.goods_main_images AS goods_picture,a.goods_short_name,a.goods_remark,a.price,a.original_price,a.goods_sold,a.goods_type,a.deposit_price,a.deposit_begin_date,a.deposit_end_date FROM online_goods_info_tb a JOIN online_hot_sale_rank_goods_tb b ON a.id=b.goods_id WHERE a.status=1 AND a.app_id=%s AND b.rank_id=%s"
        order_by = "a.goods_sold DESC,a.id DESC"
        if int(rank_info.get("rank_type", 0) or 0) == 2:
            order_by = "b.sort DESC,b.id DESC"
        goods_list = self.db.fetch_all_rows(f"{sql} ORDER BY {order_by} {limit}", [app_id, rank_id])
        return self.format_goods_rank_list(goods_list, app_id, page_size)

    def get_hot_sale_rank_board_list(self, app_id, goods_limit=3):
        """
        :Description: 获取热销商品榜单列表
        :param app_id: 店铺APP ID
        :param goods_limit: 每个榜单返回的商品数量
        :return: 榜单列表
        :last_editors: SunYiTan
        """
        rank_list = OnlineHotSaleRankModel(context=self.context).get_cache_dict_list(where="app_id=%s AND status=1", params=[app_id], field="id,rank_name,rank_type,banner,sort", order_by="sort DESC,id DESC", dependency_key=OnlineBusinessKey.hot_sale_rank_list(app_id))
        if not rank_list:
            return []

        base_sql = "SELECT a.id,a.goods_main_images AS goods_picture,a.goods_short_name,a.goods_remark,a.price,a.original_price,a.goods_sold,a.goods_type,a.deposit_price,a.deposit_begin_date,a.deposit_end_date FROM online_goods_info_tb a JOIN online_hot_sale_rank_goods_tb b ON a.id=b.goods_id WHERE a.status=1 AND a.app_id=%s AND b.rank_id=%s"
        for item in rank_list:
            item["banner"] = json.loads(item["banner"]) if item.get("banner") else []
            order_by = "a.goods_sold DESC,a.id DESC"
            if int(item.get("rank_type", 0) or 0) == 2:
                order_by = "b.sort DESC,b.id DESC"
            goods_list = self.db.fetch_all_rows(f"{base_sql} ORDER BY {order_by} LIMIT {int(goods_limit)}", [app_id, item["id"]])
            for index, goods in enumerate(goods_list):
                goods["rank_no"] = index + 1
                goods["goods_id"] = goods.get("id", 0)
                goods["goods_picture"] = self.get_goods_picture(goods.get("goods_picture", ""))
                goods["goods_name"] = goods.pop("goods_short_name", "")
            item["goods_list"] = self.enrich_goods_list_with_sku(goods_list, app_id)
        return rank_list
