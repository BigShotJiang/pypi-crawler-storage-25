# -*- coding: utf-8 -*-
"""
:Author: WangQiang
:Date: 2023-02-08 17:03:49
:LastEditTime: 2026-04-21 14:45:24
:LastEditors: CaiYouBin
:Description: Redis缓存key
"""

from seven_cloudapp_frame.handlers.frame_base import *


class OnlineBusinessKey(DependencyKey):

    @classmethod
    def app_cache_version(self, app_id):
        """
        :description: 应用缓存版本号
        :param app_id: 应用标识
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"app_cache_version:{app_id}"
        return dependency_key

    @classmethod
    def coupon_list(self, app_id):
        """
        :description: 普通优惠券列表
        :param app_id: 应用标识
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"coupon_list:appid_{app_id}"
        return dependency_key

    @classmethod
    def coupon_record_list(self, app_id, user_code):
        """
        :description: 用户优惠券记录列表
        :param app_id: 应用标识
        :param user_code: 用户编码
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"coupon_record_list:appid_{app_id}_usercode_{user_code}"
        return dependency_key
    
    @classmethod
    def coupon_record_info(self, app_id, coupon_id):
        """
        :description: 优惠券记录详情
        :param app_id: 应用标识
        :param coupon_id: 优惠券ID
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"coupon_record_info:{app_id}_{coupon_id}"
        return dependency_key

    @classmethod
    def user_comment_list(self, app_id, user_code):
        """
        :description: 用户评论列表
        :param app_id: 应用标识
        :param user_code: 用户编码
        :return: str
        :last_editors: SunYiTan
        """
        dependency_key = f"user_comment_list:appid_{app_id}_usercode_{user_code}"
        return dependency_key

    @classmethod
    def user_comment_reply_list(self, app_id, user_code):
        """
        :description: 用户评论回复列表
        :param app_id: 应用标识
        :param user_code: 用户编码
        :return: str
        :last_editors: SunYiTan
        """
        dependency_key = f"user_comment_reply_list:appid_{app_id}_usercode_{user_code}"
        return dependency_key

    @classmethod
    def goods_comment_list(self, app_id, goods_id):
        """
        :description: 商品评论列表
        :param app_id: 应用标识
        :param goods_id: 商品ID
        :return: str
        :last_editors: SunYiTan
        """
        dependency_key = f"goods_comment_list:appid_{app_id}_goodsid_{goods_id}"
        return dependency_key

    @classmethod
    def goods_comment_reply_list(self, app_id, goods_id):
        """
        :description: 商品评论回复列表
        :param app_id: 应用标识
        :param goods_id: 商品ID
        :return: str
        :last_editors: SunYiTan
        """
        dependency_key = f"goods_comment_reply_list:appid_{app_id}_goodsid_{goods_id}"
        return dependency_key

    @classmethod
    def user_pending_comment_goods_list(self, app_id, user_code):
        """
        :description: 用户待评价商品列表
        :param app_id: 应用标识
        :param user_code: 用户编码
        :return: str
        :last_editors: SunYiTan
        """
        dependency_key = f"user_pending_comment_goods_list:appid_{app_id}_usercode_{user_code}"
        return dependency_key

    @classmethod
    def category_list(self, app_id):
        """
        :description: 分类列表
        :param app_id: 应用标识
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"category_list:{app_id}"
        return dependency_key

    @classmethod
    def shop_info(self, app_id):
        """
        :description: 店铺初始化信息
        :param app_id: 应用标识
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"shop_info:{app_id}"
        return dependency_key

    @classmethod
    def category_info(self, app_id, category_id):
        """
        :description: 分类信息
        :param app_id: 应用标识
        :param category_id: 分类ID
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"category_info:{app_id}_{category_id}"
        return dependency_key
    
    @classmethod
    def series_info(self, app_id, series_id):
        """
        :description: 系列信息
        :param app_id: 应用标识
        :param series_id: 系列ID
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"series_info:{app_id}_{series_id}"
        return dependency_key

    @classmethod
    def coupon_goods_list(self, app_id):
        """
        :description: 优惠券商品列表
        :param app_id: 应用标识
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"coupon_goods_list:{app_id}"
        return dependency_key

    @classmethod
    def goods_list(self, app_id):
        """
        :description: 商品列表
        :param app_id: 应用标识
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"goods_list:{app_id}"
        return dependency_key

    @classmethod
    def goods_ids_sku_list(self, app_id):
        """
        :description: 商品SKU列表
        :param app_id: 应用标识
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"goods_ids_sku_list:{app_id}"
        return dependency_key

    @classmethod
    def goods_info(self, app_id, goods_id):
        """
        :description: 商品信息
        :param app_id: 应用标识
        :param goods_id: 商品ID
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"goods_info:{app_id}_{goods_id}"
        return dependency_key

    @classmethod
    def hot_sale_rank_info(self, app_id, rank_id):
        """
        :description: 热销排行榜信息
        :param app_id: 应用标识
        :param rank_id: 榜单ID
        :return: str
        :last_editors: SunYiTan
        """
        dependency_key = f"hot_sale_rank_info:{app_id}_{rank_id}"
        return dependency_key

    @classmethod
    def hot_sale_rank_list(self, app_id):
        """
        :description: 热销排行榜列表
        :param app_id: 应用标识
        :return: str
        :last_editors: SunYiTan
        """
        dependency_key = f"hot_sale_rank_list:{app_id}"
        return dependency_key

    @classmethod
    def goods_sku_list(self, app_id, goods_id):
        """
        :description: 商品SKU列表
        :param app_id: 应用标识
        :param goods_id: 商品ID
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"goods_sku_list:{app_id}_{goods_id}"
        return dependency_key
    
    @classmethod
    def goods_sku_info(self, app_id, goods_id):
        """
        :description: 商品SKU信息
        :param app_id: 应用标识
        :param goods_id: 商品ID
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"goods_sku_info:{app_id}_{goods_id}"
        return dependency_key

    @classmethod
    def subscribe_template_list(self, app_id):
        """
        :description: 订阅消息模板列表
        :param app_id: 应用标识
        :return: str
        """
        dependency_key = f"subscribe_template_list:{app_id}"
        return dependency_key

    @classmethod
    def postage_template_info(self, app_id, postage_template_id):
        """
        :description: 商品运费模板
        :param app_id: 应用标识
        :param postage_template_id: 运费模板ID
        :return: str
        :last_editors: KangWenBin
        """
        dependency_key = f"postage_template_info:{app_id}_{postage_template_id}"
        return dependency_key
