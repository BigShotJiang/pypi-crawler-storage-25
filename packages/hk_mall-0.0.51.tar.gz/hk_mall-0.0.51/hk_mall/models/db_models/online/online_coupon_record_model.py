# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class OnlineCouponRecordModel(CacheModel):
    def __init__(self, db_connect_key='db_saas_wx_online', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(OnlineCouponRecordModel, self).__init__(OnlineCouponRecord, sub_table)
        self.db = MySQLHelper(self.convert_db_config(db_connect_key,is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context
        self.redis_config_dict = config.get_value("redis_online")

    #方法扩展请继承此类
    
class OnlineCouponRecord:

    def __init__(self):
        super(OnlineCouponRecord, self).__init__()
        self.id = 0  # 
        self.shop_id = 0  # 店铺id
        self.app_id = ""  # app_id
        self.grant_id = 0  # 投放id
        self.coupon_id = 0  # 优惠券id
        self.grant_type = 0  # 投放类型 0 普通 1 定向 2 积分兑券
        self.coupon_info = ""  # 优惠券领取快照
        self.use_price = 0  # 使用条件金额
        self.goods_limit = "0"  # 使用限制 0 关闭 1 开启
        self.goods_list = ""  # 商品列表
        self.is_time_limit = "0"  # 是否限时 0 否 1 是
        self.use_begin_date = "1990-01-01 00:00:00"  # 有效时间开始
        self.use_end_date = "1990-01-01 00:00:00"  # 有效时间结束
        self.user_code = ""  # 用户标识
        self.open_id = ""  # open_id
        self.user_nick = ""  # 用户昵称
        self.user_phone = ""  # 用户电话
        self.order_id = ""  # 订单号
        self.exchange_order_id = ""  # 积分兑换订单关联号
        self.create_date = "1990-01-01 00:00:00"  # 领取时间
        self.modify_date = "1990-01-01 00:00:00"  # 
        self.use_date = "1990-01-01 00:00:00"  # 使用时间
        self.status = 0  # 0 未使用 1 已使用

    @classmethod
    def get_field_list(self):
        return ['id','shop_id','app_id','grant_id','coupon_id','grant_type','coupon_info','use_price','goods_limit','goods_list','is_time_limit','use_begin_date','use_end_date','user_code','open_id','user_nick','user_phone','order_id','exchange_order_id','create_date','modify_date','use_date','status']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "online_coupon_record_tb"
    
