# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class OnlineGoodsInfoModel(CacheModel):
    def __init__(self, db_connect_key='db_saas_wx_online', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(OnlineGoodsInfoModel, self).__init__(OnlineGoodsInfo, sub_table)
        self.db = MySQLHelper(self.convert_db_config(db_connect_key,is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context
        self.redis_config_dict = config.get_value("redis_online")

    #方法扩展请继承此类
    
class OnlineGoodsInfo:

    def __init__(self):
        super(OnlineGoodsInfo, self).__init__()
        self.id = 0  # 
        self.shop_id = 0  # 店铺id
        self.app_id = ""  # 店铺app_id
        self.goods_type = "0"  # 商品类型 1 普通商品 2 预售商品 3 积分商品
        self.exchange_type = 0  # 兑换类型 0 非积分商品 1 积分加钱购 2 积分兑礼 3 积分兑券
        self.exchange_points = 0  # 兑换积分
        self.exchange_coupon_id = 0  # 兑换优惠券id
        self.limit_level = 0  # 限制等级 0 不限制 大于0表示该等级及以上
        self.series_id = 0  # 系列id
        self.goods_video = ""  # 商品视频
        self.goods_main_images = ""  # 商品主图(多张)
        self.goods_detail_images = ""  # 商品详情图(多张)
        self.goods_long_name = ""  # 商品长名称
        self.goods_short_name = ""  # 商品短名称
        self.goods_remark = ""  # 商品备注
        self.goods_explain_title = ""  # 商品说明标题
        self.goods_explain_detail = ""  # 商品说明内容
        self.deposit_price = 0  # 定金价格(预售商品用)
        self.deposit_discount_price = 0  # 定金折扣金额 0 关闭
        self.final_price = 0  # 尾款价格
        self.deposit_begin_date = "1990-01-01 00:00:00"  # 定金支付开始时间
        self.deposit_end_date = "1990-01-01 00:00:00"  # 定金支付结束时间
        self.final_begin_date = "1990-01-01 00:00:00"  # 尾款支付开始时间
        self.final_end_date = "1990-01-01 00:00:00"  # 尾款支付结束时间
        self.goods_sold = 0  # 商品销量
        self.original_price = 0  # 原价
        self.price = 0  # 价格
        self.goods_code = ""  # 商家编码
        self.postage_template_id = 0  # 运费模版id
        self.sort = 0  # 商品排序
        self.status = "0"  # 状态 0 未上架 1 已上架 -1 伪删除
        self.create_date = "1990-01-01 00:00:00"  # 添加时间
        self.modify_date = "1990-01-01 00:00:00"  # 修改时间

    @classmethod
    def get_field_list(self):
        return ['id','shop_id','app_id','goods_type','exchange_type','exchange_points','exchange_coupon_id','limit_level','series_id','goods_video','goods_main_images','goods_detail_images','goods_long_name','goods_short_name','goods_remark','goods_explain_title','goods_explain_detail','deposit_price','deposit_discount_price','final_price','deposit_begin_date','deposit_end_date','final_begin_date','final_end_date','goods_sold','original_price','price','goods_code','postage_template_id','sort','status','create_date','modify_date']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "online_goods_info_tb"
    
