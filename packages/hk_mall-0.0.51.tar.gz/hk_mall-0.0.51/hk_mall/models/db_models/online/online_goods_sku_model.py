# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class OnlineGoodsSkuModel(CacheModel):
    def __init__(self, db_connect_key='db_saas_wx_online', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(OnlineGoodsSkuModel, self).__init__(OnlineGoodsSku, sub_table)
        self.db = MySQLHelper(self.convert_db_config(db_connect_key,is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context
        self.redis_config_dict = config.get_value("redis_online")

    #方法扩展请继承此类
    
class OnlineGoodsSku:

    def __init__(self):
        super(OnlineGoodsSku, self).__init__()
        self.id = 0  # 
        self.goods_id = 0  # 商品id
        self.sku_name = ""  # sku组合名称
        self.sku_picture = ""  # sku图片
        self.sku_info = ""  # sku信息
        self.original_price = 0  # 划线价
        self.price = 0  # 价格
        self.goods_sold = 0  # 销量
        self.goods_code = ""  # 商家编码
        self.create_date = "1990-01-01 00:00:00"  # 创建时间
        self.modify_date = "1990-01-01 00:00:00"  # 修改时间
        self.status = 0  # 1 正常 0 未发布 -1 伪删除

    @classmethod
    def get_field_list(self):
        return ['id','goods_id','sku_name','sku_picture','sku_info','original_price','price','goods_sold','goods_code','create_date','modify_date','status']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "online_goods_sku_tb"
    
