# -*- coding: utf-8 -*-
"""
:Author: SunYiTan
:Date: 2026-04-16 00:00:00
:LastEditTime: 2026-04-16 00:00:00
:LastEditors: SunYiTan
:Description: 热销排行榜模型
"""

from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from seven_framework import config


class OnlineHotSaleRankModel(CacheModel):
    def __init__(self, db_connect_key='db_saas_wx_online', sub_table=None, db_transaction=None, context=None):
        super(OnlineHotSaleRankModel, self).__init__(OnlineHotSaleRank, sub_table)
        self.db = MySQLHelper(config.get_value(db_connect_key))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context
        self.redis_config_dict = config.get_value("redis_online")


class OnlineHotSaleRank:

    def __init__(self):
        super(OnlineHotSaleRank, self).__init__()
        self.id = 0
        self.sort = 0  # 排序
        self.shop_id = 0  # 店铺id
        self.app_id = ""  # 店铺app_id
        self.rank_name = ""  # 排行榜名称
        self.rank_type = 0  # 排行榜类型
        self.banner = ""  # banner
        self.status = 0  # 状态 0 未发布 1 已发布 -1 伪删除
        self.create_date = "1990-01-01 00:00:00"  # 创建时间
        self.modify_date = "1990-01-01 00:00:00"  # 修改时间

    @classmethod
    def get_field_list(self):
        return ['id', 'sort', 'shop_id', 'app_id', 'rank_name', 'rank_type', 'banner', 'status', 'create_date', 'modify_date']

    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "online_hot_sale_rank_tb"
