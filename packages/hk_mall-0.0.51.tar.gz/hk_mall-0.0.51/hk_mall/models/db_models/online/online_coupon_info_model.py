# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class OnlineCouponInfoModel(CacheModel):
    def __init__(self, db_connect_key='db_saas_wx_online', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(OnlineCouponInfoModel, self).__init__(OnlineCouponInfo, sub_table)
        self.db = MySQLHelper(self.convert_db_config(db_connect_key,is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context
        self.redis_config_dict = config.get_value("redis_online")

    #方法扩展请继承此类
    
class OnlineCouponInfo:

    def __init__(self):
        super(OnlineCouponInfo, self).__init__()
        self.id = 0  # 
        self.shop_id = 0  # 店铺id
        self.app_id = ""  # 店铺app_id
        self.coupon_name = ""  # 优惠券名称
        self.coupon_type = "0"  # 优惠券类型 0 满减券 1 折扣券
        self.grant_type = "0"  # 投放类型 0 普通 1 定向
        self.use_price = 0  # 使用条件金额
        self.coupon_price = 0  # 优惠金额
        self.coupon_discount = 0  # 优惠折扣
        self.goods_limit = 0  # 商品使用限制 0 关闭 1 开启
        self.coupon_inventory = 0  # 优惠券数量
        self.record_number = 0  # 领取上限
        self.is_time_limit = "0"  # 使用时间是否限时 0 不限时 1 限时
        self.use_begin_date = "1990-01-01 00:00:00"  # 有效期_开始时间
        self.use_end_date = "1990-01-01 00:00:00"  # 有效期_结束时间
        self.begin_date = "1990-01-01 00:00:00"  # 开始透出时间(C端优惠券展示时间)
        self.use_rule = ""  # 使用规则
        self.create_date = "1990-01-01 00:00:00"  # 添加时间
        self.modify_date = "1990-01-01 00:00:00"  # 修改时间
        self.status = 0  # 优惠券状态 0 未发布 1 已发布 -1 伪删除
        self.vip_limit_level = 1  # 会员等级限制 1及以上

    @classmethod
    def get_field_list(self):
        return ['id','shop_id','app_id','coupon_name','coupon_type','grant_type','use_price','coupon_price','coupon_discount','goods_limit','coupon_inventory','record_number','is_time_limit','use_begin_date','use_end_date','begin_date','use_rule','create_date','modify_date','status','vip_limit_level']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "online_coupon_info_tb"
    
