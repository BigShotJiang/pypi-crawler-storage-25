# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class OnlineCouponGoodsModel(CacheModel):
    def __init__(self, db_connect_key='db_saas_wx_online', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(OnlineCouponGoodsModel, self).__init__(OnlineCouponGoods, sub_table)
        self.db = MySQLHelper(self.convert_db_config(db_connect_key,is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context
        self.redis_config_dict = config.get_value("redis_online")

    #方法扩展请继承此类
    
class OnlineCouponGoods:

    def __init__(self):
        super(OnlineCouponGoods, self).__init__()
        self.id = 0  # 
        self.coupon_id = 0  # 优惠券id
        self.goods_id = 0  # 商品id

    @classmethod
    def get_field_list(self):
        return ['id','coupon_id','goods_id']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "online_coupon_goods_tb"
    
