from pydantic import BaseModel

class Thinking(BaseModel):
    """Defines a thinking output when a language model is configured to use extended thinking.

    Attributes:
        id (str): The ID of the thinking output. Defaults to an empty string.
        thinking (str): The thinking text. Defaults to an empty string.
        type (str): The type of the thinking output. Defaults to an empty string.
        data (str): The additional data of the thinking output. Defaults to an empty string.
    """
    id: str
    thinking: str
    type: str
    data: str
