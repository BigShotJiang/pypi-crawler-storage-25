from _typeshed import Incomplete
from pydantic import BaseModel

class Activity(BaseModel):
    """Base schema for any activity.

    Attributes:
        type (str): The type of activity being performed. Defaults to an empty string.
    """
    model_config: Incomplete
    type: str
