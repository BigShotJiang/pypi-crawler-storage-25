from gllm_core.schema import Tool
from gllm_inference.schema.attachment import Attachment as Attachment, URLAttachment as URLAttachment
from gllm_inference.schema.native_tool import NativeTool as NativeTool
from gllm_inference.schema.thinking import Thinking as Thinking
from gllm_inference.schema.tool_call import ToolCall as ToolCall
from gllm_inference.schema.tool_result import ToolResult as ToolResult
from pydantic import BaseModel
from typing import Any

LMTool = Tool | NativeTool | str | dict[str, Any]
ResponseSchema = dict[str, Any] | type[BaseModel]
MessageContent = str | Attachment | ToolCall | ToolResult | Thinking
EMContent = str | Attachment | URLAttachment | tuple[str | Attachment | URLAttachment, ...]
Vector = list[float]
