from pydantic import BaseModel
from typing import Any

class MCPCall(BaseModel):
    """Defines an MCP call.

    Attributes:
        id (str): The ID of the MCP call. Defaults to an empty string.
        server_name (str): The name of the MCP server. Defaults to an empty string.
        tool_name (str): The name of the tool. Defaults to an empty string.
        args (dict[str, Any]): The arguments of the tool. Defaults to an empty dictionary.
        output (str | None): The output of the tool. Defaults to None.
    """
    id: str
    server_name: str
    tool_name: str
    args: dict[str, Any]
    output: str | None
