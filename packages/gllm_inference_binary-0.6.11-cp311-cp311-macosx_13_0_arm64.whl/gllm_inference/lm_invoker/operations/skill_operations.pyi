from gllm_inference.exceptions import SkillOperationError as SkillOperationError
from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker as BaseLMInvoker
from gllm_inference.schema import Attachment as Attachment, Skill as Skill
from typing import Any, TypeVar

T = TypeVar('T')

class SkillOperation:
    '''Handles skill operations for an LM invoker.

    This class provides a wrapper around the skill operations of an LM invoker.

    Examples:
        1. Create a skill:
        ```python
        file = Attachment.from_path("path/to/file.zip")
        skill = await lm_invoker.skill.create(file=file, name="My Skill")
        ```

        2. List skills:
        ```python
        skills = await lm_invoker.skill.list()
        ```

        3. Retrieve a skill:
        ```python
        skill = await lm_invoker.skill.retrieve(skill_id)
        ```

        4. Delete a skill:
        ```python
        await lm_invoker.skill.delete(skill_id)
        ```

        5. Update a skill:
        ```python
        file = Attachment.from_path("path/to/file.zip")
        skill = await lm_invoker.skill.update(skill_id, file=file)
        ```

        6. Retrieve skill versions:
        ```python
        versions = await lm_invoker.skill.list_versions(skill_id)
        ```
    '''
    def __init__(self, invoker: BaseLMInvoker) -> None:
        """Initializes the skill operations.

        Args:
            invoker (BaseLMInvoker): The LM invoker to use for the skill operations.
        """
    async def create(self, file: Attachment, name: str | None = None, **kwargs: Any) -> Skill:
        """Creates a new skill.

        The name must be unique; the provider rejects creation if a skill with the same name already exists.

        Args:
            file (Attachment): File attachment of the skill.
            name (str | None, optional): Display name of the skill provided by the user. Defaults to None.
            **kwargs (Any): Additional keyword arguments to create a skill.

        Returns:
            Skill: The created skill.

        Raises:
            SkillOperationError: If skill creation or file formatting fails.
        """
    async def list_skill(self) -> list[Skill]:
        """Lists the skills.

        Returns:
            list[Skill]: The list of skills.

        Raises:
            SkillOperationError: If skill listing fails.
        """
    async def retrieve(self, skill_id: str) -> Skill:
        """Retrieves a skill by ID.

        Args:
            skill_id (str): The ID of the skill to retrieve.

        Returns:
            Skill: The retrieved skill.

        Raises:
            SkillOperationError: If skill retrieval fails.
        """
    async def delete(self, skill_id: str) -> None:
        """Deletes a skill by ID.

        Args:
            skill_id (str): The ID of the skill to delete.

        Raises:
            SkillOperationError: If skill deletion fails.
        """
    async def update(self, skill_id: str, file: Attachment, **kwargs: Any) -> Skill:
        """Updates a skill by ID.

        Args:
            skill_id (str): The ID of the skill to update.
            file (Attachment): File attachment of the skill (typically a ZIP archive).
            **kwargs (Any): Additional keyword arguments to update a skill.

        Returns:
            Skill: The updated skill.

        Raises:
            SkillOperationError: If skill update fails.
        """
    async def list_versions(self, skill_id: str) -> list[Skill]:
        """Lists all versions of a skill by ID.

        Args:
            skill_id (str): The ID of the skill.

        Returns:
            list[Skill]: The list of skill versions.

        Raises:
            SkillOperationError: If skill version listing fails.
        """
