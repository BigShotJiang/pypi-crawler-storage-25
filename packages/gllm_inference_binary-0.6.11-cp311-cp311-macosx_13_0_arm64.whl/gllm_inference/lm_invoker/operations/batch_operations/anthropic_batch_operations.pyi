from _typeshed import Incomplete
from gllm_inference.lm_invoker.anthropic_lm_invoker import AnthropicLMInvoker as AnthropicLMInvoker
from gllm_inference.lm_invoker.operations.batch_operations.batch_operations import BatchOperations as BatchOperations
from gllm_inference.lm_invoker.schema.anthropic import Key as Key, OutputType as OutputType
from gllm_inference.schema import BatchStatus as BatchStatus, LMInput as LMInput, LMOutput as LMOutput
from typing import Any

BATCH_STATUS_MAP: Incomplete

class AnthropicBatchOperations(BatchOperations):
    """Handles batch operations for the AnthropicLMInvoker class.

    Examples:
        Invoke the language model in batch mode:
        ```python
        results = await lm_invoker.batch.invoke(...)
        ```

        Standalone batch operations:
        1. Create a batch job:
        ```python
        batch_id = await lm_invoker.batch.create(...)
        ```

        2. Get the status of a batch job:
        ```python
        status = await lm_invoker.batch.status(batch_id)
        ```

        3. Retrieve the results of a batch job:
        ```python
        results = await lm_invoker.batch.retrieve(batch_id)
        ```

        4. List the batch jobs:
        ```python
        batch_jobs = await lm_invoker.batch.list()
        ```

        5. Cancel a batch job:
        ```python
        await lm_invoker.batch.cancel(batch_id)
        ```
    """
    def __init__(self, invoker: AnthropicLMInvoker) -> None:
        """Initializes the batch operations.

        Args:
            invoker (AnthropicLMInvoker): The AnthropicLMInvoker to use for the batch operations.
        """
    async def create(self, requests: dict[str, LMInput], hyperparameters: dict[str, Any] | None = None) -> str:
        """Creates a new batch job.

        Args:
            requests (dict[str, LMInput]): The dictionary of requests that maps request ID to the request.
                Each request must be a valid input for the language model.
                1. If the request is a list of Message objects, it is used as is.
                2. If the request is a list of MessageContent or a string, it is converted into a user message.
            hyperparameters (dict[str, Any] | None, optional): A dictionary of hyperparameters for the language model.
                Defaults to None, in which case the default hyperparameters are used.

        Returns:
            str: The ID of the batch job.
        """
    async def status(self, batch_id: str) -> BatchStatus:
        """Gets the status of a batch job.

        Args:
            batch_id (str): The ID of the batch job to get the status of.

        Returns:
            BatchStatus: The status of the batch job.
        """
    async def retrieve(self, batch_id: str, **kwargs: Any) -> dict[str, LMOutput]:
        """Retrieves the results of a batch job.

        Args:
            batch_id (str): The ID of the batch job to get the results of.
            **kwargs (Any): Additional keyword arguments.

        Returns:
            dict[str, LMOutput]: The results of the batch job.
        """
    async def list(self) -> list[dict[str, Any]]:
        """Lists the batch jobs.

        Returns:
            list[dict[str, Any]]: The list of batch jobs.
        """
    async def cancel(self, batch_id: str) -> None:
        """Cancels a batch job.

        Args:
            batch_id (str): The ID of the batch job to cancel.
        """
