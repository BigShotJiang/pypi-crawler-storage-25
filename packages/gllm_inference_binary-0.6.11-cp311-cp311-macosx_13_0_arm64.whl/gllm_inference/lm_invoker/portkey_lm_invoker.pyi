from _typeshed import Incomplete
from gllm_core.retry import RetryConfig
from gllm_inference.constants import SECONDS_TO_MILLISECONDS as SECONDS_TO_MILLISECONDS
from gllm_inference.lm_invoker.openai_chat_completions_lm_invoker import OpenAIChatCompletionsLMInvoker as OpenAIChatCompletionsLMInvoker
from gllm_inference.lm_invoker.schema.portkey import InputType as InputType, Key as Key
from gllm_inference.output_transformer.output_transformer import BaseOutputTransformer as BaseOutputTransformer
from gllm_inference.schema import AttachmentType as AttachmentType, InputTransformerType as InputTransformerType, LMOutput as LMOutput, LMTool as LMTool, ModelId as ModelId, ModelProvider as ModelProvider, OutputTransformerType as OutputTransformerType, ResponseSchema as ResponseSchema, ThinkingConfig as ThinkingConfig
from typing import Any

MIN_THINKING_BUDGET: int
VALID_AUTH_METHODS: str
logger: Incomplete

class PortkeyLMInvoker(OpenAIChatCompletionsLMInvoker):
    '''A language model invoker to interact with Portkey\'s Universal API.

    This class provides support for Portkey\'s Universal AI Gateway, which enables unified access to
    multiple providers (e.g., OpenAI, Anthropic, Google, Cohere, Bedrock) via a single API key.
    The `PortkeyLMInvoker` is compatible with all Portkey model routing configurations, including
    model catalog entries, direct providers, and pre-defined configs.

    Examples:
        The `PortkeyLMInvoker` supports multiple authentication methods with strict precedence order.
        Authentication methods are mutually exclusive and cannot be combined.

        **Authentication Precedence (Highest to Lowest):**
        1. **Config ID Authentication (Highest precedence)**
           Use a pre-configured routing setup from Portkey’s dashboard.
           ```python
           lm_invoker = PortkeyLMInvoker(
               portkey_api_key="<your-portkey-api-key>",
               config="pc-openai-4f6905",
           )
           ```

        2. **Model Catalog Authentication**
           Provider name must match the provider name set in the model catalog.
           More details to set up the model catalog can be found in https://portkey.ai/docs/product/model-catalog#model-catalog.
           There are two ways to specify the model name:

           2.1. Using Combined Model Name Format
           Specify the `model_name` in \'@provider-name/model-name\' format.
           ```python
           lm_invoker = PortkeyLMInvoker(
               portkey_api_key="<your-portkey-api-key>",
               model_name="@openai-custom/gpt-4o"
           )
           ```

           2.2. Using Separate Provider and Model Name Parameters
           Specify the `provider` in \'@provider-name\' format and `model_name` separately.
           ```python
           lm_invoker = PortkeyLMInvoker(
               portkey_api_key="<your-portkey-api-key>",
               provider="@openai-custom",
               model_name="gpt-4o",
           )
           ```

        3. **Direct Provider Authentication**
           Use the `provider` in \'provider-name\' format and `model_name` parameters.
           ```python
           lm_invoker = PortkeyLMInvoker(
               portkey_api_key="<your-portkey-api-key>",
               provider="openai",
               model_name="gpt-4o",
               api_key="sk-...",
           )
           ```

    Custom Host:
        You can also use the `custom_host` parameter to override the default host. This is available
        for all authentication methods except for Config ID authentication.
        ```python
        lm_invoker = PortkeyLMInvoker(..., custom_host="https://your-custom-endpoint.com")
        ```

    Supported features:
        1. Basic invocation
        2. Streaming output
        3. Message roles
        4. Multimodal input
           a. Text
           b. Audio
           c. Document
           d. Image
        5. Structured output
        6. Tool calling
        7. Thinking
        8. Output analytics
        9. Retry and timeout
        10. Extra capabilities
           a. Input transformer
           b. Output transformer

        For full documentation and examples, please refer to the LM Invoker tutorial:
        https://gdplabs.gitbook.io/sdk/gen-ai-sdk/tutorials/inference/lm-invoker

    Attributes:
        model_id (str): The model ID of the language model.
        model_provider (str): The provider of the language model.
        model_name (str): The catalog name of the language model.
        client_kwargs (dict[str, Any]): The keyword arguments for the Portkey client.
        default_config (dict[str, Any]): Default config for invoking the model.
        tools (list[Tool]): The list of tools provided to the model to enable tool calling.
        response_schema (ResponseSchema | None): The schema of the response. If provided, the model will output a
            structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema dictionary.
        output_analytics (bool): Whether to output the invocation analytics.
        retry_config (RetryConfig): The retry configuration for the language model.
        thinking (ThinkingConfig): The thinking configuration for the language model.
        input_transformer (InputTransformerType): The type of input transformer to use.
        output_transformer (OutputTransformerType): The type of output transformer to use.
    '''
    model_kwargs: Incomplete
    client_kwargs: Incomplete
    client: Incomplete
    def __init__(self, model_name: str | None = None, portkey_api_key: str | None = None, provider: str | None = None, api_key: str | None = None, config: str | None = None, custom_host: str | None = None, model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, tools: list[LMTool] | None = None, response_schema: ResponseSchema | None = None, output_analytics: bool = False, retry_config: RetryConfig | None = None, thinking: bool | ThinkingConfig = False, input_transformer: InputTransformerType = ..., output_transformer: OutputTransformerType = ...) -> None:
        """Initializes a new instance of the PortkeyLMInvoker class.

        Args:
            model_name (str | None, optional): The name of the model to use. Acceptable formats:
                1. 'model' for direct authentication,
                2. '@provider-slug/model' for model catalog authentication.
                Defaults to None.
            portkey_api_key (str | None, optional): The Portkey API key. Defaults to None, in which
                case the `PORTKEY_API_KEY` environment variable will be used.
            provider (str | None, optional): Provider name or catalog slug. Acceptable formats:
                1. '@provider-slug' for model catalog authentication (no api_key needed),
                2. 'provider' for direct authentication (requires api_key).
                Will be combined with model_name if model name is not in the format '@provider-slug/model'.
                Defaults to None.
            api_key (str | None, optional): Provider's API key for direct authentication.
                Must be used with 'provider' parameter (without '@' prefix). Not needed for catalog providers.
                Defaults to None.
            config (str | None, optional): Portkey config ID for complex routing configurations,
                load balancing, or fallback scenarios. Defaults to None.
            custom_host (str | None, optional): Custom host URL for self-hosted or custom endpoints.
                Can be combined with catalog providers. Defaults to None.
            model_kwargs (dict[str, Any] | None, optional): Additional model parameters and authentication.
                Defaults to None.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for model
                invocation (temperature, max_tokens, etc.). Defaults to None.
            tools (list[LMTool] | None, optional): Tools for enabling tool calling functionality.
                Defaults to None.
            response_schema (ResponseSchema | None, optional): Schema for structured output generation.
                Defaults to None.
            output_analytics (bool, optional): Whether to output detailed invocation analytics including
                token usage and timing. Defaults to False.
            retry_config (RetryConfig | None, optional): Configuration for retry behavior on failures.
                Defaults to None.
            thinking (bool | ThinkingConfig, optional): A boolean or ThinkingConfig object to configure thinking.
                Defaults to False.
            input_transformer (InputTransformerType, optional): The type of input transformer to use.
                Defaults to InputTransformerType.IDENTITY, which returns the input without transformation.
            output_transformer (OutputTransformerType, optional): The type of output transformer to use.
                Defaults to OutputTransformerType.IDENTITY, which returns the output without transformation.
        """
