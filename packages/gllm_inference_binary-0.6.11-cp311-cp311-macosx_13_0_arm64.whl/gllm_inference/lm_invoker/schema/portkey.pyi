class Key:
    """Valid keys in Portkey."""
    AUTHORIZATION: str
    BUDGET_TOKENS: str
    CONTENT: str
    CONTENT_BLOCKS: str
    DELTA: str
    MAX_RETRIES: str
    MODEL: str
    RESPONSE_FORMAT: str
    THINKING: str
    TOOLS: str
    TYPE: str
    USAGE: str

class InputType:
    """Valid input types in Portkey."""
    ENABLED: str

class AuthConfig:
    """Authentication configuration keys."""
    CONFIG: str
    PROVIDER_AUTH: str
    PROVIDER_CUSTOM_HOST: str
