from _typeshed import Incomplete
from enum import Enum
from typing import TypeVar

E = TypeVar('E', bound=Enum)
SAFE_URL_SCHEMES: Incomplete
LOCALHOSTS: Incomplete
logger: Incomplete

def is_valid_url(text: str) -> bool:
    """Check if a URL is valid.

    This method validate URL format and rejects dangerous schemes and private/local addresses.

    Args:
        text (str): The URL string to validate.

    Returns:
        bool: True if URL is valid, False otherwise.
    """
