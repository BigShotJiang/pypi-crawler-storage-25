from _typeshed import Incomplete
from enum import StrEnum
from gllm_core.retry import RetryConfig
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker as BaseEMInvoker
from gllm_inference.em_invoker.schema.bedrock import InputType as InputType, Key as Key, OutputType as OutputType
from gllm_inference.em_invoker.vector_fuser.vector_fuser import BaseVectorFuser as BaseVectorFuser
from gllm_inference.schema import Attachment as Attachment, AttachmentType as AttachmentType, EMContent as EMContent, ModelId as ModelId, ModelProvider as ModelProvider, TruncationConfig as TruncationConfig, Vector as Vector, VectorFuserType as VectorFuserType
from typing import Any

class ModelType(StrEnum):
    """Defines the type of the Bedrock embedding model."""
    COHERE: str
    MARENGO: str
    TITAN: str

MODEL_TYPE_PREFIX_MAP: Incomplete
INFERENCE_PROFILE_PREFIX: str
INFERENCE_PROFILE_SUBSTRING: str

class BedrockEMInvoker(BaseEMInvoker):
    '''An embedding model invoker to interact with AWS Bedrock embedding models.

    Examples:
        ```python
        em_invoker = BedrockEMInvoker(model_name="cohere.embed-english-v3")
        result = await em_invoker.invoke("Hi there!")
        ```

    Supported features:
        1. Basic invocation
        2. Batch invocation
        3. Multimodal input
           a. Text
           b. Image (For Marengo models only)
        4. Text truncation
        5. Vector fusion
        6. Retry and timeout

    Attributes:
        model_id (str): The model ID of the embedding model.
        model_provider (str): The provider of the embedding model.
        model_name (str): The name of the embedding model.
        session (Session): The Bedrock client session.
        client_kwargs (dict[str, Any]): The Bedrock client kwargs.
        default_hyperparameters (dict[str, Any]): Default hyperparameters for invoking the embedding model.
        retry_config (RetryConfig): The retry configuration for the embedding model.
        truncation_config (TruncationConfig | None): The truncation configuration for the embedding model.
        vector_fuser (BaseVectorFuser | None): The vector fuser to handle mixed content.
    '''
    session: Incomplete
    client_kwargs: Incomplete
    def __init__(self, model_name: str, access_key_id: str | None = None, secret_access_key: str | None = None, region_name: str = 'us-east-1', model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, retry_config: RetryConfig | None = None, truncation_config: TruncationConfig | None = None, vector_fuser: BaseVectorFuser | VectorFuserType | None = None) -> None:
        '''Initializes a new instance of the BedrockEMInvoker class.

        Args:
            model_name (str): The name of the Bedrock embedding model to be used.
            access_key_id (str | None, optional): The AWS access key ID. Defaults to None, in which case
                the `AWS_ACCESS_KEY_ID` environment variable will be used.
            secret_access_key (str | None, optional): The AWS secret access key. Defaults to None, in which case
                the `AWS_SECRET_ACCESS_KEY` environment variable will be used.
            region_name (str, optional): The AWS region name. Defaults to "us-east-1".
            model_kwargs (dict[str, Any] | None, optional): Additional keyword arguments for the Bedrock client.
                Defaults to None.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            retry_config (RetryConfig | None, optional): The retry configuration for the embedding model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            truncation_config (TruncationConfig | None, optional): Configuration for text truncation behavior.
                Defaults to None, in which case no truncation is applied.
            vector_fuser (BaseVectorFuser | VectorFuserType | None, optional): The vector fuser to handle mixed content.
                Defaults to None, in which case handling the mixed modality content depends on the EM\'s capabilities.

        Raises:
            ValueError: If the model name is not supported.
            ValueError: If `access_key_id` or `secret_access_key` is neither provided nor set in the
                `AWS_ACCESS_KEY_ID` or `AWS_SECRET_ACCESS_KEY` environment variables, respectively.
        '''
