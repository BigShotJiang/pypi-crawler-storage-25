from _typeshed import Incomplete
from gllm_core.retry import RetryConfig
from gllm_inference.constants import EMBEDDING_ENDPOINT as EMBEDDING_ENDPOINT, JINA_DEFAULT_URL as JINA_DEFAULT_URL
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker as BaseEMInvoker
from gllm_inference.em_invoker.schema.jina import Key as Key
from gllm_inference.em_invoker.vector_fuser.vector_fuser import BaseVectorFuser as BaseVectorFuser
from gllm_inference.exceptions import ProviderInternalError as ProviderInternalError
from gllm_inference.schema import Attachment as Attachment, AttachmentType as AttachmentType, EMContent as EMContent, ModelId as ModelId, ModelProvider as ModelProvider, TruncationConfig as TruncationConfig, Vector as Vector, VectorFuserType as VectorFuserType
from typing import Any

MULTIMODAL_MODELS: Incomplete

class JinaEMInvoker(BaseEMInvoker):
    '''An embedding model invoker to interact with Jina AI embedding models.

    Examples:
        ```python
        em_invoker = JinaEMInvoker(model_name="jina-embeddings-v2-large")
        result = await em_invoker.invoke("Hi there!")
        ```

    Supported features:
        1. Basic invocation
        2. Batch invocation
        3. Multimodal input
           a. Text
           b. Image
        4. Text truncation
        5. Vector fusion
        6. Retry and timeout

    Attributes:
        model_id (str): The model ID of the embedding model.
        model_provider (str): The provider of the embedding model.
        model_name (str): The name of the embedding model.
        client (AsyncClient): The client for the Jina AI API.
        default_hyperparameters (dict[str, Any]): Default hyperparameters for invoking the embedding model.
        retry_config (RetryConfig): The retry configuration for the embedding model.
        truncation_config (TruncationConfig | None): The truncation configuration for the embedding model.
        vector_fuser (BaseVectorFuser | None): The vector fuser to handle mixed content.
    '''
    client: Incomplete
    model_kwargs: Incomplete
    def __init__(self, model_name: str, api_key: str | None = None, base_url: str = ..., model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, retry_config: RetryConfig | None = None, truncation_config: TruncationConfig | None = None, vector_fuser: BaseVectorFuser | VectorFuserType | None = None) -> None:
        '''Initializes a new instance of the JinaEMInvoker class.

        Args:
            model_name (str): The name of the Jina embedding model to be used.
            api_key (str | None, optional): The API key for authenticating with Jina AI.
                Defaults to None, in which case the `JINA_API_KEY` environment variable will be used.
            base_url (str, optional): The base URL for the Jina AI API. Defaults to "https://api.jina.ai/v1".
            model_kwargs (dict[str, Any] | None, optional): Additional keyword arguments for the HTTP client.
                Defaults to None.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            retry_config (RetryConfig | None, optional): The retry configuration for the embedding model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            truncation_config (TruncationConfig | None, optional): Configuration for text truncation behavior.
                Defaults to None, in which case no truncation is applied.
            vector_fuser (BaseVectorFuser | VectorFuserType | None, optional): The vector fuser to handle mixed content.
                Defaults to None, in which case handling the mixed modality content depends on the EM\'s capabilities.

        Raises:
            ValueError: If neither `api_key` nor `JINA_API_KEY` environment variable is provided.
        '''
