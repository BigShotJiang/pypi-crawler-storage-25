from _typeshed import Incomplete
from gllm_core.retry import RetryConfig
from gllm_inference.constants import AZURE_OPENAI_URL_SUFFIX as AZURE_OPENAI_URL_SUFFIX, INVOKER_PROPAGATED_MAX_RETRIES as INVOKER_PROPAGATED_MAX_RETRIES
from gllm_inference.em_invoker.openai_em_invoker import OpenAIEMInvoker as OpenAIEMInvoker
from gllm_inference.em_invoker.schema.openai import Key as Key
from gllm_inference.em_invoker.vector_fuser.vector_fuser import BaseVectorFuser as BaseVectorFuser
from gllm_inference.exceptions import ProviderInvalidArgsError as ProviderInvalidArgsError
from gllm_inference.schema import ModelId as ModelId, ModelProvider as ModelProvider, TruncationConfig as TruncationConfig, VectorFuserType as VectorFuserType
from typing import Any

class AzureOpenAIEMInvoker(OpenAIEMInvoker):
    '''An embedding model invoker to interact with Azure OpenAI embedding models.

    Examples:
        ```python
        em_invoker = AzureOpenAIEMInvoker(
            azure_endpoint="https://<your-azure-openai-endpoint>.openai.azure.com/openai/v1",
            azure_deployment="<your-azure-openai-deployment>",
        )
        result = await em_invoker.invoke("Hi there!")
        ```

    Supported features:
        1. Basic invocation
        2. Batch invocation
        3. Text input only
        4. Text truncation
        5. Vector fusion
        6. Retry and timeout

    Attributes:
        model_id (str): The model ID of the embedding model.
        model_provider (str): The provider of the embedding model.
        model_name (str): The name of the Azure OpenAI embedding model deployment.
        client_kwargs (dict[str, Any]): The keyword arguments for the Azure OpenAI client.
        default_hyperparameters (dict[str, Any]): Default hyperparameters for invoking the embedding model.
        retry_config (RetryConfig): The retry configuration for the embedding model.
        truncation_config (TruncationConfig | None): The truncation configuration for the embedding model.
        vector_fuser (BaseVectorFuser | None): The vector fuser to handle mixed content.
    '''
    client_kwargs: Incomplete
    def __init__(self, azure_endpoint: str, azure_deployment: str, api_key: str | None = None, model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, retry_config: RetryConfig | None = None, truncation_config: TruncationConfig | None = None, vector_fuser: BaseVectorFuser | VectorFuserType | None = None) -> None:
        """Initializes a new instance of the AzureOpenAIEMInvoker class.

        Args:
            azure_endpoint (str): The endpoint of the Azure OpenAI service.
            azure_deployment (str): The deployment name of the Azure OpenAI service.
            api_key (str | None, optional): The API key for authenticating with Azure OpenAI. Defaults to None, in
                which case the `AZURE_OPENAI_API_KEY` environment variable will be used.
            model_kwargs (dict[str, Any] | None, optional): Additional model parameters. Defaults to None.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            retry_config (RetryConfig | None, optional): The retry configuration for the embedding model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            truncation_config (TruncationConfig | None, optional): Configuration for text truncation behavior.
                Defaults to None, in which case no truncation is applied.
            vector_fuser (BaseVectorFuser | VectorFuserType | None, optional): The vector fuser to handle mixed content.
                Defaults to None, in which case handling the mixed modality content depends on the EM's capabilities.
        """
