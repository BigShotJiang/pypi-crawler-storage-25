from _typeshed import Incomplete
from gllm_core.retry import RetryConfig
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker as BaseEMInvoker
from gllm_inference.em_invoker.schema.twelvelabs import InputType as InputType, Key as Key, OutputType as OutputType, TaskStatus as TaskStatus, VideoEmbeddingParams as VideoEmbeddingParams, VideoEmbeddingScope as VideoEmbeddingScope
from gllm_inference.em_invoker.vector_fuser.vector_fuser import BaseVectorFuser as BaseVectorFuser
from gllm_inference.schema import Attachment as Attachment, AttachmentType as AttachmentType, EMContent as EMContent, ModelId as ModelId, ModelProvider as ModelProvider, TruncationConfig as TruncationConfig, URLAttachment as URLAttachment, Vector as Vector, VectorFuserType as VectorFuserType
from typing import Any

VIDEO_EMBEDDING_PARAMS: Incomplete

class TwelveLabsEMInvoker(BaseEMInvoker):
    '''An embedding model invoker to interact with TwelveLabs embedding models.

    Examples:
        ```python
        em_invoker = TwelveLabsEMInvoker(model_name="Marengo-retrieval-2.7")
        result = await em_invoker.invoke("Hi there!")
        ```

    Supported features:
        1. Basic invocation
        2. Batch invocation
        3. Multimodal input
           a. Text
           b. Audio
           c. Image
           d. Video
        4. Text truncation
        5. Vector fusion
        6. Retry and timeout

    Video embedding:
        For advanced video embedding customization, you can pass hyperparameters to control the embedding process:
        ```python
        hyperparameters={
            "video_embed_create_params": {}, # optional parameters for EmbedClient.TasksClient.create(),
            "video_embed_retrieve_params": {}, # optional parameters for EmbedClient.TasksClient.retrieve()
            "wait_for_done_params": {}, # optional parameters for EmbedClient.TasksClient.wait_for_done()
        }

        video = Attachment.from_path("path/to/local/video.mp4")
        result = await em_invoker.invoke(video, hyperparameters)
        ```
        For video related hyperparameters, see https://docs.twelvelabs.io/sdk-reference/python/create-embeddings-v-1/create-video-embeddings.

        Furthermore, when embedding video:
        1. The video format should meet the requirements of TwelveLabs embedding model. For more details, see
        [Marengo requirements](https://docs.twelvelabs.io/v1.3/docs/concepts/models/marengo#video-file-requirements)
        2. VectorFuser is required to embed video content.

    Attributes:
        model_id (str): The model ID of the embedding model.
        model_provider (str): The provider of the embedding model.
        model_name (str): The name of the embedding model.
        client (Client): The client for the TwelveLabs API.
        default_hyperparameters (dict[str, Any]): Default hyperparameters for invoking the embedding model.
        retry_config (RetryConfig): The retry configuration for the embedding model.
        truncation_config (TruncationConfig | None): The truncation configuration for the embedding model.
        vector_fuser (BaseVectorFuser | None): The vector fuser to handle mixed content.
    '''
    client: Incomplete
    def __init__(self, model_name: str, api_key: str | None = None, model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, retry_config: RetryConfig | None = None, truncation_config: TruncationConfig | None = None, vector_fuser: BaseVectorFuser | VectorFuserType | None = None) -> None:
        """Initializes a new instance of the TwelveLabsEMInvoker class.

        Args:
            model_name (str): The name of the TwelveLabs embedding model to be used.
            api_key (str | None, optional): The API key for the TwelveLabs API. Defaults to None, in which
                case the `TWELVELABS_API_KEY` environment variable will be used.
            model_kwargs (dict[str, Any] | None, optional): Additional keyword arguments for the TwelveLabs client.
                Defaults to None.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            retry_config (RetryConfig | None, optional): The retry configuration for the embedding model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            truncation_config (TruncationConfig | None, optional): Configuration for text truncation behavior.
                Defaults to None, in which case no truncation is applied.
            vector_fuser (BaseVectorFuser | VectorFuserType | None, optional): The vector fuser to handle mixed content.
                Defaults to None, in which case handling the mixed modality content depends on the EM's capabilities.
        """
