from _typeshed import Incomplete
from gllm_core.retry import RetryConfig
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker as BaseEMInvoker
from gllm_inference.em_invoker.schema.cohere import CohereInputType as CohereInputType, Key as Key
from gllm_inference.em_invoker.vector_fuser.vector_fuser import BaseVectorFuser as BaseVectorFuser
from gllm_inference.schema import Attachment as Attachment, AttachmentType as AttachmentType, EMContent as EMContent, ModelId as ModelId, ModelProvider as ModelProvider, TruncationConfig as TruncationConfig, Vector as Vector, VectorFuserType as VectorFuserType
from typing import Any

MULTIMODAL_MODEL_VERSION: Incomplete

class CohereEMInvoker(BaseEMInvoker):
    '''An embedding model invoker to interact with Cohere embedding models.

    Examples:
        ```python
        em_invoker = CohereEMInvoker(model_name="embed-english-v4.0")
        result = await em_invoker.invoke("Hi there!")
        ```

    Supported features:
        1. Basic invocation
        2. Batch invocation
        3. Multimodal input
           a. Text
           b. Image
        4. Text truncation
        5. Vector fusion
        6. Retry and timeout

    Attributes:
        model_id (str): The model ID of the embedding model.
        model_provider (str): The provider of the embedding model (Cohere).
        model_name (str): The name of the Cohere embedding model.
        client (AsyncClient): The asynchronous client for the Cohere API.
        default_hyperparameters (dict[str, Any]): Default hyperparameters for invoking the embedding model.
        retry_config (RetryConfig): The retry configuration for the embedding model.
        truncation_config (TruncationConfig | None): The truncation configuration for the embedding model.
        vector_fuser (BaseVectorFuser | None): The vector fuser to handle mixed content.
        input_type (CohereInputType): The input type for the embedding model. Supported values include:
            1. `CohereInputType.SEARCH_DOCUMENT`,
            2. `CohereInputType.SEARCH_QUERY`,
            3. `CohereInputType.CLASSIFICATION`,
            4. `CohereInputType.CLUSTERING`,
            5. `CohereInputType.IMAGE`.
    '''
    input_type: Incomplete
    client: Incomplete
    def __init__(self, model_name: str, api_key: str | None = None, base_url: str | None = None, model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, retry_config: RetryConfig | None = None, truncation_config: TruncationConfig | None = None, vector_fuser: BaseVectorFuser | VectorFuserType | None = None, input_type: CohereInputType = ...) -> None:
        '''Initializes a new instance of the CohereEMInvoker class.

        Args:
            model_name (str): The name of the Cohere embedding model to be used.
            api_key (str | None, optional): The API key for authenticating with Cohere. Defaults to None, in which
                case the `COHERE_API_KEY` environment variable will be used.
            base_url (str | None, optional): The base URL for a custom Cohere-compatible endpoint.
                Defaults to None, in which case Cohere\'s default URL will be used.
            model_kwargs (dict[str, Any] | None, optional): Additional keyword arguments for the Cohere client.
                Defaults to None.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            retry_config (RetryConfig | None, optional): The retry configuration for the embedding model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            truncation_config (TruncationConfig | None, optional): Configuration for text truncation behavior.
                Defaults to None, in which case no truncation is applied.
            vector_fuser (BaseVectorFuser | VectorFuserType | None, optional): The vector fuser to handle mixed content.
                Defaults to None, in which case handling the mixed modality content depends on the EM\'s capabilities.
            input_type (CohereInputType, optional): The input type for the embedding model.
                Defaults to `CohereInputType.SEARCH_DOCUMENT`. Valid values are: "search_document", "search_query",
                "classification", "clustering", and "image". For more information about, please refer to
                https://docs.cohere.com/docs/embeddings#the-input_type-parameter.
        '''
