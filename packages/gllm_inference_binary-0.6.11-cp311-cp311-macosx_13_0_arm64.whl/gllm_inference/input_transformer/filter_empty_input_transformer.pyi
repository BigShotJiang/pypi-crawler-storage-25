from gllm_inference.input_transformer.input_transformer import BaseInputTransformer as BaseInputTransformer
from gllm_inference.schema.message import Message as Message

class FilterEmptyInputTransformer(BaseInputTransformer):
    """An input transformer that filters out empty or whitespace-only message contents.

    This transformer removes any message content that is an empty string or
    contains only whitespace characters.
    """
    def transform(self, messages: list[Message]) -> list[Message]:
        """Transforms the input messages by filtering out empty or whitespace-only contents.

        This method filters out any content within a message that is an empty string
        or contains only whitespace characters.

        Args:
            messages (list[Message]): The input messages for the language model.

        Returns:
            list[Message]: The transformed input messages with empty/whitespace contents removed.

        Raises:
            ValueError: If the message has no non-empty contents.
        """
