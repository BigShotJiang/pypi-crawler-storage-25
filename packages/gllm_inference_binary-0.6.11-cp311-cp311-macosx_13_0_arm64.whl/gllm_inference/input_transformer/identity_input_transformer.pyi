from gllm_inference.input_transformer.input_transformer import BaseInputTransformer as BaseInputTransformer
from gllm_inference.schema.message import Message as Message

class IdentityInputTransformer(BaseInputTransformer):
    """An input transformer that transforms the input messages of a language model into an identity function.

    This transformer simply returns the input messages as is.
    """
    def transform(self, messages: list[Message]) -> list[Message]:
        """Transforms the input messages of a language model with an identity function.

        This method simply returns the input messages as is.

        Args:
            messages (list[Message]): The input messages for the language model.

        Returns:
            list[Message]: The transformed input messages for the language model.
        """
