from gllm_inference.realtime_session.constants import OutputAudioConfig as OutputAudioConfig
from gllm_inference.realtime_session.output_streamer.output_streamer import BaseOutputStreamer as BaseOutputStreamer
from gllm_inference.realtime_session.schema import RealtimeDataType as RealtimeDataType, RealtimeEvent as RealtimeEvent, RealtimeState as RealtimeState
from sounddevice import OutputStream

class WindowsSpeakerOutputStreamer(BaseOutputStreamer):
    """[BETA] A Windows speaker output streamer that plays the output audio through the speakers.

    Attributes:
        state (RealtimeState): The state of the output streamer.
        stream (OutputStream | None): The sounddevice output stream.
    """
    stream: OutputStream | None
    async def initialize(self, state: RealtimeState) -> None:
        """Initializes the WindowsSpeakerOutputStreamer.

        Args:
            state (RealtimeState): The state of the output streamer.

        Raises:
            OSError: If the current system is not Windows.
        """
    async def handle(self, event: RealtimeEvent) -> None:
        """Handles the output events.

        This method is used to handle the audio output events and play them through the Windows system speakers.

        Args:
            event (RealtimeEvent): The realtime events to handle.
        """
    async def close(self) -> None:
        """Closes the WindowsSpeakerOutputStreamer.

        This method is used to close the WindowsSpeakerOutputStreamer.
        It is used to clean up playing process.
        """
