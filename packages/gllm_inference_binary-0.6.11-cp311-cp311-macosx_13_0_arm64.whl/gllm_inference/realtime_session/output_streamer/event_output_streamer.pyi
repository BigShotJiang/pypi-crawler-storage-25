from _typeshed import Incomplete
from gllm_core.event import EventEmitter
from gllm_inference.realtime_session.output_streamer.output_streamer import BaseOutputStreamer as BaseOutputStreamer
from gllm_inference.realtime_session.schema import RealtimeDataType as RealtimeDataType, RealtimeEvent as RealtimeEvent, RealtimeEventType as RealtimeEventType
from gllm_inference.schema import Activity as Activity, ActivityEvent as ActivityEvent

ROLE_MAP: Incomplete

class EventOutputStreamer(BaseOutputStreamer):
    """[BETA] An event output streamer that emits output events via an event emitter.

    Attributes:
        state (RealtimeState): The state of the output streamer.
        event_emitter (EventEmitter): The event emitter to emit the output events.
    """
    event_emitter: Incomplete
    def __init__(self, event_emitter: EventEmitter) -> None:
        """Initializes the EventOutputStreamer.

        Args:
            event_emitter (EventEmitter): The event emitter to emit the output events.
        """
    async def handle(self, event: RealtimeEvent) -> None:
        """Handles the output events.

        This method is used to handle and emit the output events via the event emitter.

        Args:
            event (RealtimeEvent): The realtime events to handle.
        """
