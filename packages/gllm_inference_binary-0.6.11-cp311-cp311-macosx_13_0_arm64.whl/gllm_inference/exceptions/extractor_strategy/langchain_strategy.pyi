from gllm_inference.exceptions.exceptions import BaseInvokerError as BaseInvokerError, ModelNotFoundError as ModelNotFoundError, ProviderAuthError as ProviderAuthError, ProviderInternalError as ProviderInternalError, ProviderInvalidArgsError as ProviderInvalidArgsError, ProviderRateLimitError as ProviderRateLimitError
from gllm_inference.exceptions.extractor_strategy.extractor_strategy import BaseExtractionStrategy as BaseExtractionStrategy
from typing import Final

LANGCHAIN_RESPONSE_DETAIL_MAPPING: Final[dict[str, type[BaseInvokerError]]]

class LangChainExtractionStrategy(BaseExtractionStrategy):
    """Extraction strategy for LangChain-specific errors.

    This strategy handles LangChain error patterns including error code extraction.

    Attributes:
        response_detail_mapping (dict[str, type[BaseInvokerError]]): Maps LangChain error
            codes to BaseInvokerError subclasses.
    """
    response_detail_mapping: dict[str, type[BaseInvokerError]]
