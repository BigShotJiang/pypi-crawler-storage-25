from gllm_inference.exceptions.exceptions import APIConnectionError as APIConnectionError, APITimeoutError as APITimeoutError, BaseInvokerError as BaseInvokerError, ContextOverflowError as ContextOverflowError, ModelNotFoundError as ModelNotFoundError, ProviderAuthError as ProviderAuthError, ProviderInternalError as ProviderInternalError, ProviderInvalidArgsError as ProviderInvalidArgsError, ProviderRateLimitError as ProviderRateLimitError
from gllm_inference.exceptions.extractor_strategy.extractor_strategy import BaseExtractionStrategy as BaseExtractionStrategy
from typing import Final

TWELVELABS_EXCEPTION_MAPPING: Final[dict[str, type[BaseInvokerError]]]
TWELVELABS_MESSAGE_PATTERN_MAPPING: Final[dict[str, type[BaseInvokerError]]]

class TwelveLabsExtractionStrategy(BaseExtractionStrategy):
    """Extraction strategy for TwelveLabs-specific errors.

    This strategy handles TwelveLabs error patterns using exception type mapping.

    Attributes:
        exception_mapping (dict[str, type[BaseInvokerError]]): Maps fully qualified
            TwelveLabs exception class names to BaseInvokerError subclasses.
    """
    exception_mapping: dict[str, type[BaseInvokerError]]
    message_pattern_mapping: dict[str, type[BaseInvokerError]]
