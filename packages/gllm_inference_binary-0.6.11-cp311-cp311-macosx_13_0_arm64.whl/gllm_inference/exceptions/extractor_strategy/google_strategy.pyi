from gllm_inference.exceptions.exceptions import APITimeoutError as APITimeoutError, BaseInvokerError as BaseInvokerError, ContextOverflowError as ContextOverflowError, ModelNotFoundError as ModelNotFoundError, ProviderAuthError as ProviderAuthError, ProviderInternalError as ProviderInternalError, ProviderInvalidArgsError as ProviderInvalidArgsError, ProviderRateLimitError as ProviderRateLimitError
from gllm_inference.exceptions.extractor_strategy.extractor_strategy import BaseExtractionStrategy as BaseExtractionStrategy
from typing import Final

GOOGLE_EXCEPTION_MAPPING: Final[dict[str, type[BaseInvokerError]]]
GOOGLE_MESSAGE_PATTERN_MAPPING: Final[dict[str, type[BaseInvokerError]]]

class GoogleExtractionStrategy(BaseExtractionStrategy):
    """Extraction strategy for Google GenAI-specific errors.

    This strategy handles Google error patterns including status code extraction
    from error responses.

    Attributes:
        exception_mapping (dict[str, type[BaseInvokerError]]): Maps fully qualified
            Google GenAI exception class names to BaseInvokerError subclasses.
    """
    exception_mapping: dict[str, type[BaseInvokerError]]
    message_pattern_mapping: dict[str, type[BaseInvokerError]]
