from gllm_inference.exceptions.exceptions import BaseInvokerError as BaseInvokerError, ModelNotFoundError as ModelNotFoundError, ProviderAuthError as ProviderAuthError, ProviderInternalError as ProviderInternalError, ProviderInvalidArgsError as ProviderInvalidArgsError, ProviderOverloadedError as ProviderOverloadedError, ProviderRateLimitError as ProviderRateLimitError
from gllm_inference.exceptions.extractor_strategy.extractor_strategy import BaseExtractionStrategy as BaseExtractionStrategy
from typing import Final

LITELLM_EXCEPTION_MAPPING: Final[dict[str, type[BaseInvokerError]]]

class LiteLLMExtractionStrategy(BaseExtractionStrategy):
    """Extraction strategy for LiteLLM-specific errors.

    This strategy handles LiteLLM error patterns using exception type mapping.

    Attributes:
        exception_mapping (dict[str, type[BaseInvokerError]]): Maps fully qualified
            LiteLLM exception class names to BaseInvokerError subclasses.
    """
    exception_mapping: dict[str, type[BaseInvokerError]]
