from gllm_inference.exceptions.exceptions import APIConnectionError as APIConnectionError, APITimeoutError as APITimeoutError, BaseInvokerError as BaseInvokerError, ContextOverflowError as ContextOverflowError, ProviderAuthError as ProviderAuthError, ProviderInternalError as ProviderInternalError, ProviderInvalidArgsError as ProviderInvalidArgsError, ProviderOverloadedError as ProviderOverloadedError, ProviderRateLimitError as ProviderRateLimitError
from gllm_inference.exceptions.extractor_strategy.extractor_strategy import BaseExtractionStrategy as BaseExtractionStrategy
from typing import Final

VOYAGE_EXCEPTION_MAPPING: Final[dict[str, type[BaseInvokerError]]]
VOYAGE_MESSAGE_PATTERN_MAPPING: Final[dict[str, type[BaseInvokerError]]]

class VoyageExtractionStrategy(BaseExtractionStrategy):
    """Extraction strategy for Voyage AI-specific errors.

    This strategy handles Voyage error patterns using exception type mapping.

    Attributes:
        exception_mapping (dict[str, type[BaseInvokerError]]): Maps fully qualified
            Voyage AI exception class names to BaseInvokerError subclasses.
    """
    exception_mapping: dict[str, type[BaseInvokerError]]
    message_pattern_mapping: dict[str, type[BaseInvokerError]]
