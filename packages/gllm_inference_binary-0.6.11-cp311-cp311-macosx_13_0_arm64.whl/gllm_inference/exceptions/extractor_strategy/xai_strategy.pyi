from gllm_inference.exceptions.exceptions import APIConnectionError as APIConnectionError, APITimeoutError as APITimeoutError, BaseInvokerError as BaseInvokerError, ModelNotFoundError as ModelNotFoundError, ProviderAuthError as ProviderAuthError, ProviderConflictError as ProviderConflictError, ProviderInternalError as ProviderInternalError, ProviderInvalidArgsError as ProviderInvalidArgsError, ProviderRateLimitError as ProviderRateLimitError
from gllm_inference.exceptions.extractor_strategy.extractor_strategy import BaseExtractionStrategy as BaseExtractionStrategy
from typing import Final

GRPC_STATUS_CODE_MAPPING: Final[dict[str, type[BaseInvokerError]]]

class XAIExtractionStrategy(BaseExtractionStrategy):
    """Extraction strategy for xAI (Grok)-specific errors.

    This strategy handles xAI error patterns which use gRPC status codes.

    Attributes:
        response_detail_mapping (dict[str, type[BaseInvokerError]]): Maps gRPC status
            codes to BaseInvokerError subclasses.
    """
    response_detail_mapping: dict[str, type[BaseInvokerError]]
