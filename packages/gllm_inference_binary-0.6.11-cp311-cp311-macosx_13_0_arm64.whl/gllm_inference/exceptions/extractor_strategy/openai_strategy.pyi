from gllm_inference.exceptions.exceptions import APIConnectionError as APIConnectionError, APITimeoutError as APITimeoutError, BaseInvokerError as BaseInvokerError, ContextOverflowError as ContextOverflowError, ModelNotFoundError as ModelNotFoundError, ProviderAuthError as ProviderAuthError, ProviderInternalError as ProviderInternalError, ProviderInvalidArgsError as ProviderInvalidArgsError, ProviderOverloadedError as ProviderOverloadedError, ProviderRateLimitError as ProviderRateLimitError
from gllm_inference.exceptions.extractor_strategy.extractor_strategy import BaseExtractionStrategy as BaseExtractionStrategy
from typing import Final

OPENAI_EXCEPTION_MAPPING: Final[dict[str, type[BaseInvokerError]]]
OPENAI_RESPONSE_DETAIL_MAPPING: Final[dict[str, type[BaseInvokerError]]]
OPENAI_MESSAGE_PATTERN_MAPPING: Final[dict[str, type[BaseInvokerError]]]

class OpenAIExtractionStrategy(BaseExtractionStrategy):
    """Extraction strategy for OpenAI-specific errors.

    This strategy handles OpenAI error patterns including error code extraction,
    message pattern matching, and exception type mapping.

    Attributes:
        exception_mapping (dict[str, type[BaseInvokerError]]): Maps fully qualified
            OpenAI exception class names to BaseInvokerError subclasses.
        response_detail_mapping (dict[str, type[BaseInvokerError]]): Maps OpenAI error
            codes to BaseInvokerError subclasses.
        message_pattern_mapping (dict[str, type[BaseInvokerError]]): Maps regex patterns
            to BaseInvokerError subclasses for OpenAI error messages.
    """
    exception_mapping: dict[str, type[BaseInvokerError]]
    response_detail_mapping: dict[str, type[BaseInvokerError]]
    message_pattern_mapping: dict[str, type[BaseInvokerError]]
