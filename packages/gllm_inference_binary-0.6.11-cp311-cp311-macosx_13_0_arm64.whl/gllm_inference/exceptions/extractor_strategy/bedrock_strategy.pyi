from gllm_inference.exceptions.exceptions import APITimeoutError as APITimeoutError, BaseInvokerError as BaseInvokerError, ContextOverflowError as ContextOverflowError, ModelNotFoundError as ModelNotFoundError, ProviderAuthError as ProviderAuthError, ProviderInternalError as ProviderInternalError, ProviderInvalidArgsError as ProviderInvalidArgsError, ProviderRateLimitError as ProviderRateLimitError
from gllm_inference.exceptions.extractor_strategy.extractor_strategy import BaseExtractionStrategy as BaseExtractionStrategy
from typing import Final

BEDROCK_EXCEPTION_MAPPING: Final[dict[str, type[BaseInvokerError]]]
BEDROCK_MESSAGE_PATTERN_MAPPING: Final[dict[str, type[BaseInvokerError]]]

class BedrockExtractionStrategy(BaseExtractionStrategy):
    """Extraction strategy for AWS Bedrock-specific errors.

    This strategy handles Bedrock error patterns including status code extraction
    from boto3 error responses.

    Attributes:
        exception_mapping (dict[str, type[BaseInvokerError]]): Maps fully qualified
            botocore exception class names to BaseInvokerError subclasses.
        status_code_mapping (dict[int, type[BaseInvokerError]]): Maps HTTP status codes
            to BaseInvokerError subclasses with Bedrock-specific overrides.
    """
    exception_mapping: dict[str, type[BaseInvokerError]]
    message_pattern_mapping: dict[str, type[BaseInvokerError]]
    status_code_mapping: dict[int, type[BaseInvokerError]]
