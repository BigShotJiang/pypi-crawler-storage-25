from gllm_inference.exceptions.exceptions import BaseInvokerError as BaseInvokerError, ContextOverflowError as ContextOverflowError, ProviderAuthError as ProviderAuthError, ProviderInternalError as ProviderInternalError, ProviderInvalidArgsError as ProviderInvalidArgsError, ProviderOverloadedError as ProviderOverloadedError, ProviderRateLimitError as ProviderRateLimitError
from gllm_inference.exceptions.extractor_strategy.extractor_strategy import BaseExtractionStrategy as BaseExtractionStrategy
from typing import Final

COHERE_EXCEPTION_MAPPING: Final[dict[str, type[BaseInvokerError]]]
COHERE_MESSAGE_PATTERN_MAPPING: Final[dict[str, type[BaseInvokerError]]]

class CohereExtractionStrategy(BaseExtractionStrategy):
    """Extraction strategy for Cohere-specific errors.

    This strategy handles Cohere error patterns using exception type mapping.

    Attributes:
        exception_mapping (dict[str, type[BaseInvokerError]]): Maps fully qualified
            Cohere exception class names to BaseInvokerError subclasses.
    """
    exception_mapping: dict[str, type[BaseInvokerError]]
    message_pattern_mapping: dict[str, type[BaseInvokerError]]
