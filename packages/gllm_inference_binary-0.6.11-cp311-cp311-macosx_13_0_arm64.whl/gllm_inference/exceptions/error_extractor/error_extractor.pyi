from gllm_inference.exceptions.exceptions import BaseInvokerError as BaseInvokerError, InvokerRuntimeError as InvokerRuntimeError
from gllm_inference.exceptions.extractor_strategy.common_strategy import CommonExtractionStrategy as CommonExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.extractor_strategy import BaseExtractionStrategy as BaseExtractionStrategy

class BaseErrorExtractor:
    """Error extractor facade.

    This class provides a simple interface for parsing provider errors by delegating
    to a list of extraction strategies. It is the main entry point used by invokers.
    """
    def __init__(self, provider_strategy: list[BaseExtractionStrategy]) -> None:
        """Initialize the error resolver with error extraction strategies.

        Args:
            provider_strategy (list[BaseExtractionStrategy]): List of extraction strategies.
        """
    def resolve(self, error: Exception, class_name: str) -> BaseInvokerError:
        """Resolve a provider error to a BaseInvokerError.

        This is the main method called by invokers to convert provider-specific
        errors into standardized BaseInvokerError subclasses.

        Args:
            error (Exception): The raw provider error to resolve.
            class_name (str): The invoker class name for error context.

        Returns:
            BaseInvokerError: The resolved error with appropriate type and debug info.
        """

def make_provider_extractor(strategy_classes: type[BaseExtractionStrategy] | list[type[BaseExtractionStrategy]]) -> type['BaseErrorExtractor']:
    """Create a BaseErrorExtractor subclass configured with the given provider strategy.

    Args:
        strategy_classes (type[BaseExtractionStrategy] | list[type[BaseExtractionStrategy]]):
            A single strategy class or list of strategy classes. If a single class is provided,
            CommonExtractionStrategy is automatically appended. If a list is provided,
            CommonExtractionStrategy is appended only if not already present.

    Returns:
        type[BaseErrorExtractor]: A configured extractor subclass.

    Raises:
        TypeError:
        1. If strategy_classes is not a class or list of classes.
        2. If any strategy class does not inherit from BaseExtractionStrategy.
        3. If any strategy class cannot be instantiated with no arguments.
        ValueError: If primary strategy class name does not end with 'ExtractionStrategy'.
    """
