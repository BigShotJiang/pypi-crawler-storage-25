from gllm_inference.exceptions.error_extractor.error_extractor import BaseErrorExtractor as BaseErrorExtractor
from gllm_inference.exceptions.extractor_strategy.anthropic_strategy import AnthropicExtractionStrategy as AnthropicExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.bedrock_strategy import BedrockExtractionStrategy as BedrockExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.cohere_strategy import CohereExtractionStrategy as CohereExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.common_strategy import CommonExtractionStrategy as CommonExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.google_strategy import GoogleExtractionStrategy as GoogleExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.langchain_strategy import LangChainExtractionStrategy as LangChainExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.openai_strategy import OpenAIExtractionStrategy as OpenAIExtractionStrategy

class LangChainErrorExtractor(BaseErrorExtractor):
    """LangChain error extractor.

    This class handles LangChain-specific error patterns and supports multiple
    underlying providers since LangChain is a multi-provider wrapper. It tries
    LangChain-specific errors first, then falls back to provider-specific strategies,
    and finally to common cross-provider errors.
    """
    def __init__(self) -> None:
        """Initialize the LangChain error extractor.

        This extractor uses multiple strategies in order:
        1. LangChainExtractionStrategy for LangChain-specific errors
        2. Provider-specific strategies (OpenAI, Anthropic, Bedrock, Cohere, Google)
        3. CommonExtractionStrategy for cross-provider errors
        """
