from gllm_inference.exceptions.error_extractor.common_extractor import CommonErrorExtractor as CommonErrorExtractor
from gllm_inference.exceptions.error_extractor.error_extractor import BaseErrorExtractor as BaseErrorExtractor, make_provider_extractor as make_provider_extractor
from gllm_inference.exceptions.extractor_strategy.anthropic_strategy import AnthropicExtractionStrategy as AnthropicExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.bedrock_strategy import BedrockExtractionStrategy as BedrockExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.cohere_strategy import CohereExtractionStrategy as CohereExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.google_strategy import GoogleExtractionStrategy as GoogleExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.langchain_strategy import LangChainExtractionStrategy as LangChainExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.litellm_strategy import LiteLLMExtractionStrategy as LiteLLMExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.openai_strategy import OpenAIExtractionStrategy as OpenAIExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.twelvelabs_strategy import TwelveLabsExtractionStrategy as TwelveLabsExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.voyage_strategy import VoyageExtractionStrategy as VoyageExtractionStrategy
from gllm_inference.exceptions.extractor_strategy.xai_strategy import XAIExtractionStrategy as XAIExtractionStrategy
from gllm_inference.schema import ModelProvider as ModelProvider

EXTRACTOR_MAP: dict[ModelProvider, type[BaseErrorExtractor]]

def get_error_extractor(provider: ModelProvider) -> type[BaseErrorExtractor]:
    """Get the registered provider error extractor class.

    Args:
        provider (ModelProvider): The provider name.

    Returns:
        type[BaseErrorExtractor]: The registered provider error extractor class.
    """
def get_all_provider_extractors() -> list[BaseErrorExtractor]:
    """Get all registered provider error extractor instances.

    Returns:
        list[BaseErrorExtractor]: List of all provider extractor instances.
    """
