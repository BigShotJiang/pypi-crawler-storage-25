class VoyageEM:
    '''Defines Voyage embedding model names constants.

    Usage example:
    ```python
    from gllm_inference.model import VoyageEM
    from gllm_inference.em_invoker import VoyageEMInvoker

    em_invoker = VoyageEMInvoker(VoyageEM.VOYAGE_4_LITE)
    result = await em_invoker.invoke("Hello, world!")
    ```
    '''
    VOYAGE_4_LARGE: str
    VOYAGE_4: str
    VOYAGE_4_LITE: str
    VOYAGE_CODE_3: str
    VOYAGE_CODE_2: str
    VOYAGE_FINANCE_2: str
    VOYAGE_LAW_2: str
    VOYAGE_MULTIMODAL_3_5: str
