class AnthropicLM:
    '''Defines Anthropic language model names constants.

    Usage example:
    ```python
    from gllm_inference.model import AnthropicLM
    from gllm_inference.lm_invoker import AnthropicLMInvoker

    lm_invoker = AnthropicLMInvoker(AnthropicLM.CLAUDE_SONNET_4_6)
    response = await lm_invoker.invoke("Hello, world!")
    ```
    '''
    CLAUDE_OPUS_4_6: str
    CLAUDE_SONNET_4_6: str
    CLAUDE_OPUS_4_5: str
    CLAUDE_SONNET_4_5: str
    CLAUDE_HAIKU_4_5: str
    CLAUDE_OPUS_4_1: str
    CLAUDE_OPUS_4: str
    CLAUDE_SONNET_4: str
