"""High-level worker lifecycle management."""

import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from clm.infrastructure.config import WorkersManagementConfig
from clm.infrastructure.workers.discovery import WorkerDiscovery
from clm.infrastructure.workers.event_logger import WorkerEventLogger
from clm.infrastructure.workers.pool_manager import WorkerPoolManager
from clm.infrastructure.workers.worker_executor import (
    DirectWorkerExecutor,
    DockerWorkerExecutor,
    WorkerConfig,
    WorkerExecutor,
)

logger = logging.getLogger(__name__)


class WorkerInfo(BaseModel):
    """Information about a worker."""

    worker_type: str
    execution_mode: str
    executor_id: str  # Container ID or direct-worker-id
    db_worker_id: int
    started_at: str
    config: dict[str, Any]


class WorkerLifecycleManager:
    """Manage worker lifecycle based on configuration.

    This class provides high-level orchestration of worker lifecycle:
    - Starting and stopping managed workers (auto-lifecycle with clm build)
    - Worker discovery and health checking
    - Lifecycle event logging
    """

    def __init__(
        self,
        config: WorkersManagementConfig,
        db_path: Path,
        workspace_path: Path,
        session_id: str | None = None,
        cache_db_path: Path | None = None,
        data_dir: Path | None = None,
    ):
        """Initialize lifecycle manager.

        Args:
            config: Worker management configuration
            db_path: Path to database
            workspace_path: Path to workspace directory (output)
            session_id: Optional session ID for event logging
            cache_db_path: Path to executed notebook cache database
            data_dir: Path to source data directory (for Docker workers to mount)
        """
        self.config = config
        self.db_path = db_path
        self.workspace_path = workspace_path
        self.cache_db_path = cache_db_path
        self.data_dir = data_dir
        self.session_id = session_id or f"session-{datetime.now().strftime('%Y%m%d-%H%M%S')}"

        # Worker pool manager (used for actual worker start/stop)
        self.pool_manager: WorkerPoolManager | None = None

        # Event logger
        self.event_logger = WorkerEventLogger(db_path, session_id=self.session_id)

        # Worker discovery
        # Create executors for health checking
        executors: dict[str, WorkerExecutor] = {
            "direct": DirectWorkerExecutor(
                db_path=db_path,
                workspace_path=workspace_path,
                log_level="INFO",
            ),
        }

        # Try to create Docker executor if Docker is available
        try:
            import docker

            docker_client = docker.from_env()  # type: ignore[attr-defined]
            executors["docker"] = DockerWorkerExecutor(
                docker_client=docker_client,
                db_path=db_path,
                workspace_path=workspace_path,
                data_dir=data_dir,
                network_name=config.network_name,
                log_level="INFO",
            )
        except Exception:
            # Docker not available, only direct executor will be used
            logger.debug("Docker not available, Docker executor not created")

        self.discovery = WorkerDiscovery(db_path, executors=executors)

        # Track managed workers (for cleanup)
        self.managed_workers: list[WorkerInfo] = []

    def close(self):
        """Close all database connections.

        This method should be called when the lifecycle manager is no longer needed
        to avoid ResourceWarning about unclosed database connections.
        """
        # Close event logger
        if hasattr(self, "event_logger") and self.event_logger is not None:
            self.event_logger.close()

        # Close discovery
        if hasattr(self, "discovery") and self.discovery is not None:
            self.discovery.close()

        # Close pool manager
        if hasattr(self, "pool_manager") and self.pool_manager is not None:
            self.pool_manager.close()

    def should_start_workers(self) -> bool:
        """Determine if we need to start new workers.

        Returns:
            True if workers should be started
        """
        if not self.config.auto_start:
            logger.info("Auto-start is disabled")
            return False

        if not self.config.reuse_workers:
            logger.info("Worker reuse is disabled, will start fresh workers")
            return True

        # Check if we have sufficient healthy workers for each type.
        # JupyterLite is opt-in: only checked when its count has been
        # explicitly enabled (mirroring get_all_worker_configs).
        required_types = ["notebook", "plantuml", "drawio"]
        if self.config.jupyterlite.count is not None and self.config.jupyterlite.count > 0:
            required_types.append("jupyterlite")

        for worker_type in required_types:
            required_config = self.config.get_worker_config(worker_type)
            required_count = required_config.count

            healthy_count = self.discovery.count_healthy_workers(worker_type)

            if healthy_count < required_count:
                logger.info(
                    f"Need {required_count} {worker_type} worker(s), "
                    f"found {healthy_count} healthy worker(s)"
                )
                return True

        logger.info("Sufficient healthy workers already running")
        return False

    def start_managed_workers(self) -> list[WorkerInfo]:
        """Start workers that will be managed (auto-stopped) by this instance.

        Returns:
            List of started worker information
        """
        start_time = time.time()

        logger.info("Starting managed workers...")

        # Get worker configurations
        worker_configs = self.config.get_all_worker_configs()

        # If reusing workers, adjust counts based on existing workers
        if self.config.reuse_workers:
            worker_configs = self._adjust_configs_for_reuse(worker_configs)

        if not worker_configs:
            logger.info("No workers to start (sufficient workers already running)")
            # Return information about existing healthy workers
            return self._collect_reused_worker_info()

        total_workers = sum(c.count for c in worker_configs)

        # Log pool starting
        self.event_logger.log_pool_starting(worker_configs, total_workers)

        # Create pool manager
        self.pool_manager = WorkerPoolManager(
            db_path=self.db_path,
            workspace_path=self.workspace_path,
            data_dir=self.data_dir,
            worker_configs=worker_configs,
            network_name=self.config.network_name,
            log_level=logging.getLevelName(logger.getEffectiveLevel()),
            cache_db_path=self.cache_db_path,
        )

        # Update discovery to use pool_manager's executors for accurate health checks
        # This ensures we check the actual process/container state
        self.discovery.executors = self.pool_manager.executors

        # Start pools
        self.pool_manager.start_pools()

        # Collect worker info for tracking
        self.managed_workers = self._collect_worker_info()

        # Log pool started
        duration = time.time() - start_time
        self.event_logger.log_pool_started(len(self.managed_workers), duration)

        logger.info(f"Started {len(self.managed_workers)} managed worker(s)")
        return self.managed_workers

    def stop_managed_workers(self, workers: list[WorkerInfo]) -> None:
        """Stop managed workers.

        Args:
            workers: List of workers to stop
        """
        if not self.config.auto_stop:
            logger.info("Auto-stop is disabled, keeping workers running")
            return

        if not workers:
            logger.debug("No workers to stop")
            return

        if not self.pool_manager:
            logger.debug("No pool manager to stop")
            return

        start_time = time.time()

        self.event_logger.log_pool_stopping()
        logger.info(f"Stopping {len(workers)} worker(s)...")

        # Stop pools
        self.pool_manager.stop_pools()

        # Detect jobs that were in flight when the pool stopped. Any row
        # with ``started_at`` set but no terminal state is an orphan — the
        # worker died before finishing the job. We mark those rows failed
        # here, after stop_pools() has returned (no worker is alive to
        # race with us) and before log_pool_stopped() so the orphan count
        # can be included in the pool_stopped event metadata. Without this
        # pass, orphans would stay stuck in "processing" status forever and
        # ``clm status`` would silently under-report failures.
        orphans: list[dict[str, Any]] = []
        try:
            orphans = self.event_logger.job_queue.mark_orphaned_jobs_failed()
        except Exception as exc:
            # Never let orphan detection break pool teardown — downstream
            # cleanup (log_pool_stopped, managed_workers clearing) must
            # still run. Log at warning and keep going with an empty list.
            logger.warning(f"Failed to scan for orphan jobs at pool stop: {exc}")
            orphans = []

        if orphans:
            orphan_files = ", ".join(f"#{o['id']} ({o['input_file']})" for o in orphans)
            logger.warning(
                f"Pool stopped with {len(orphans)} in-flight job(s) orphaned; "
                f"marked as failed: {orphan_files}"
            )

        # Log pool stopped (with orphan metadata for audit trails)
        duration = time.time() - start_time
        self.event_logger.log_pool_stopped(
            len(workers),
            duration,
            orphan_count=len(orphans),
            orphan_job_ids=[o["id"] for o in orphans],
        )

        # Clear tracked workers if they match
        if self.managed_workers == workers:
            self.managed_workers.clear()

    def _adjust_configs_for_reuse(self, configs: list[WorkerConfig]) -> list[WorkerConfig]:
        """Adjust worker counts based on existing healthy workers.

        Args:
            configs: Original worker configurations

        Returns:
            Adjusted configurations (may be empty if no workers needed)
        """
        adjusted = []

        for config in configs:
            healthy_count = self.discovery.count_healthy_workers(config.worker_type)
            needed_count = max(0, config.count - healthy_count)

            if needed_count > 0:
                # Create new config with adjusted count
                new_config = WorkerConfig(
                    worker_type=config.worker_type,
                    execution_mode=config.execution_mode,
                    count=needed_count,
                    image=config.image,
                    memory_limit=config.memory_limit,
                    max_job_time=config.max_job_time,
                )
                adjusted.append(new_config)

                logger.info(
                    f"Adjusted {config.worker_type}: "
                    f"needed={config.count}, healthy={healthy_count}, "
                    f"starting={needed_count}"
                )
            else:
                logger.info(
                    f"Skipping {config.worker_type}: {healthy_count} healthy worker(s) already available"
                )

        return adjusted

    def _collect_worker_info(self) -> list[WorkerInfo]:
        """Collect information about workers from pool manager.

        Returns:
            List of worker information
        """
        if not self.pool_manager:
            return []

        workers_info = []

        for worker_type, workers in self.pool_manager.workers.items():
            for worker_dict in workers:
                info = WorkerInfo(
                    worker_type=worker_type,
                    execution_mode=worker_dict["config"].execution_mode,
                    executor_id=worker_dict["executor_id"],
                    db_worker_id=worker_dict["db_worker_id"],
                    started_at=worker_dict["started_at"].isoformat(),
                    config={
                        "execution_mode": worker_dict["config"].execution_mode,
                        "image": worker_dict["config"].image,
                        "memory_limit": worker_dict["config"].memory_limit,
                        "max_job_time": worker_dict["config"].max_job_time,
                    },
                )
                workers_info.append(info)

        return workers_info

    def _collect_reused_worker_info(self) -> list[WorkerInfo]:
        """Collect information about existing healthy workers being reused.

        Returns:
            List of worker information for reused workers
        """
        workers_info = []

        # Get all worker configs to know what types we need
        all_configs = self.config.get_all_worker_configs()

        for config in all_configs:
            if config.count == 0:
                continue

            # Discover healthy workers of this type
            discovered = self.discovery.discover_workers(
                worker_type=config.worker_type, status_filter=["idle", "busy"]
            )

            # Take up to config.count healthy workers
            healthy_workers = [w for w in discovered if w.is_healthy][: config.count]

            for worker in healthy_workers:
                info = WorkerInfo(
                    worker_type=worker.worker_type,
                    execution_mode="docker" if worker.is_docker else "direct",
                    executor_id=worker.executor_id,
                    db_worker_id=worker.db_id,
                    started_at=worker.started_at.isoformat(),
                    config={
                        "execution_mode": "docker" if worker.is_docker else "direct",
                        "image": None,  # Unknown for reused workers
                        "memory_limit": config.memory_limit,
                        "max_job_time": config.max_job_time,
                    },
                )
                workers_info.append(info)

        return workers_info
