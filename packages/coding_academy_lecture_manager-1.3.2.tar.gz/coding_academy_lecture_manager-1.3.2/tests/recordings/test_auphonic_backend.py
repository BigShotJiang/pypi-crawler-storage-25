"""Tests for :class:`AuphonicBackend` using a fake HTTP client.

The fake client plays back scripted Auphonic responses and records the
requests the backend makes. The tests drive a job through all lifecycle
transitions (QUEUED → UPLOADING → PROCESSING → DOWNLOADING → COMPLETED)
and the failure paths (submit error, poll error, timeout, cancel).
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import pytest

from clm.recordings.workflow.backends.auphonic import (
    AUPHONIC_POLL_TIMEOUT_MINUTES,
    DEFAULT_INLINE_ALGORITHMS,
    AuphonicBackend,
)
from clm.recordings.workflow.backends.auphonic_client import (
    AuphonicError,
    AuphonicOutputFile,
    AuphonicPreset,
    AuphonicProduction,
    AuphonicStatus,
)
from clm.recordings.workflow.backends.base import JobContext
from clm.recordings.workflow.directories import ensure_root, to_process_dir
from clm.recordings.workflow.jobs import (
    JobState,
    ProcessingJob,
    ProcessingOptions,
)

# ---------------------------------------------------------------------
# Fakes
# ---------------------------------------------------------------------


class _RecordingContext:
    """JobContext stub that records every call to :meth:`report`."""

    def __init__(self, work_dir: Path) -> None:
        self._work_dir = work_dir
        self.reports: list[ProcessingJob] = []
        self.poll_soon_calls = 0

    @property
    def work_dir(self) -> Path:
        return self._work_dir

    def report(self, job: ProcessingJob) -> None:
        # Record a snapshot so downstream assertions see each transition,
        # not just the final state of the shared mutable job object.
        self.reports.append(job.model_copy(deep=True))

    def request_poll_soon(self) -> None:
        self.poll_soon_calls += 1


class _FakeAuphonicClient:
    """Scripted Auphonic HTTP client used by backend tests.

    Tracks every method call on ``self.calls`` and cycles through a
    scripted list of responses for ``get_production``. Methods raise if
    the test asks for behaviour that wasn't wired up, so missing stubs
    fail loudly instead of silently returning None.
    """

    def __init__(
        self,
        *,
        production_uuid: str = "prod-1",
        get_responses: list[AuphonicProduction] | None = None,
        list_responses: list[list[AuphonicProduction]] | None = None,
        download_fn: Callable[[str, Path], None] | None = None,
    ) -> None:
        self.calls: list[tuple[str, tuple[Any, ...], dict[str, Any]]] = []
        self._production_uuid = production_uuid
        self._get_responses = list(get_responses or [])
        self._list_responses = list(list_responses or [])
        self._download_fn = download_fn or (lambda url, dest: dest.write_bytes(b"fake-video"))
        # Track state for optional multi-call scripts.
        self.deleted = False

    def _record(self, name: str, args: tuple[Any, ...], kwargs: dict[str, Any]) -> None:
        self.calls.append((name, args, kwargs))

    def create_production(self, **kwargs) -> AuphonicProduction:
        self._record("create_production", (), kwargs)
        return AuphonicProduction(uuid=self._production_uuid, status=AuphonicStatus.INCOMPLETE_FORM)

    def upload_input(self, uuid, file_path, *, on_progress=None):
        self._record("upload_input", (uuid, file_path), {})
        if on_progress is not None:
            on_progress(0.25)
            on_progress(0.75)
            on_progress(1.0)
        return AuphonicProduction(uuid=uuid, status=AuphonicStatus.FILE_UPLOAD)

    def start_production(self, uuid):
        self._record("start_production", (uuid,), {})
        return AuphonicProduction(uuid=uuid, status=AuphonicStatus.AUDIO_PROCESSING)

    def get_production(self, uuid) -> AuphonicProduction:
        self._record("get_production", (uuid,), {})
        if not self._get_responses:
            raise AssertionError("No scripted get_production responses remain")
        return self._get_responses.pop(0)

    def list_productions(self, *, title=None, limit=None):
        self._record("list_productions", (), {"title": title, "limit": limit})
        if not self._list_responses:
            return []
        return self._list_responses.pop(0)

    def download(self, url, dest, *, on_progress=None):
        self._record("download", (url, dest), {})
        self._download_fn(url, dest)
        if on_progress is not None:
            on_progress(1.0)

    def delete_production(self, uuid):
        self._record("delete_production", (uuid,), {})
        self.deleted = True

    def list_presets(self):
        self._record("list_presets", (), {})
        return []

    def create_preset(self, **kwargs):
        self._record("create_preset", (), kwargs)
        return AuphonicPreset(uuid="new", preset_name=kwargs["preset_data"]["preset_name"])

    def update_preset(self, uuid, **kwargs):
        self._record("update_preset", (uuid,), kwargs)
        return AuphonicPreset(uuid=uuid, preset_name=kwargs["preset_data"]["preset_name"])


# ---------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------


@pytest.fixture()
def root(tmp_path: Path) -> Path:
    """Initialize the to-process/final/archive tree for a test."""
    root_dir = tmp_path / "recordings"
    ensure_root(root_dir)
    return root_dir


@pytest.fixture()
def raw_file(root: Path) -> Path:
    """Place a pretend raw recording in to-process/."""
    tp = to_process_dir(root) / "python-basics" / "week-01"
    tp.mkdir(parents=True, exist_ok=True)
    video = tp / "topic-one--RAW.mp4"
    video.write_bytes(b"pretend video bytes")
    return video


@pytest.fixture()
def ctx(tmp_path: Path) -> _RecordingContext:
    return _RecordingContext(work_dir=tmp_path / "work")


def _final_path_for(root: Path, raw: Path) -> Path:
    tp = to_process_dir(root)
    rel = raw.parent.relative_to(tp)
    return root / "final" / rel / "topic-one.mp4"


def _make_backend(
    client: _FakeAuphonicClient,
    root: Path,
    **overrides: Any,
) -> AuphonicBackend:
    return AuphonicBackend(
        client=client,  # type: ignore[arg-type]
        root_dir=root,
        **overrides,
    )


# ---------------------------------------------------------------------
# accepts_file / capabilities
# ---------------------------------------------------------------------


class TestAcceptsFile:
    def test_accepts_raw_video(self, root: Path) -> None:
        backend = _make_backend(_FakeAuphonicClient(), root)
        assert backend.accepts_file(Path("topic--RAW.mp4")) is True
        assert backend.accepts_file(Path("topic--RAW.mkv")) is True

    def test_rejects_non_video_or_non_raw(self, root: Path) -> None:
        backend = _make_backend(_FakeAuphonicClient(), root)
        assert backend.accepts_file(Path("topic--RAW.wav")) is False
        assert backend.accepts_file(Path("topic.mp4")) is False
        assert backend.accepts_file(Path("notes.txt")) is False

    def test_honours_custom_raw_suffix(self, root: Path) -> None:
        backend = _make_backend(_FakeAuphonicClient(), root, raw_suffix="--SRC")
        assert backend.accepts_file(Path("topic--SRC.mp4")) is True
        assert backend.accepts_file(Path("topic--RAW.mp4")) is False

    def test_capabilities_declare_async_cloud(self, root: Path) -> None:
        backend = _make_backend(_FakeAuphonicClient(), root)
        caps = backend.capabilities
        assert caps.name == "auphonic"
        assert caps.is_synchronous is False
        assert caps.video_in_video_out is True
        assert caps.requires_internet is True
        assert caps.requires_api_key is True
        assert caps.supports_cut_lists is True


# ---------------------------------------------------------------------
# submit
# ---------------------------------------------------------------------


class TestSubmit:
    def test_happy_path_transitions_to_processing(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        client = _FakeAuphonicClient()
        backend = _make_backend(client, root)
        final = _final_path_for(root, raw_file)

        job = backend.submit(raw_file, final, options=ProcessingOptions(), ctx=ctx)

        assert job.state == JobState.PROCESSING
        assert job.backend_ref == "prod-1"
        assert job.backend_name == "auphonic"
        assert job.started_at is not None
        assert job.progress == pytest.approx(0.4)
        # Raw file should still exist — it's archived only on finalize.
        assert raw_file.exists()

        # The method should have called create / upload / start in order.
        call_names = [name for name, _, _ in client.calls]
        assert call_names == ["create_production", "upload_input", "start_production"]

        # Inline algorithms should be sent when no preset is configured.
        create_kwargs = client.calls[0][2]
        assert create_kwargs["algorithms"] == DEFAULT_INLINE_ALGORITHMS
        assert create_kwargs["preset"] is None
        assert create_kwargs["metadata"] == {"title": "topic-one"}
        # One video output, no cut list by default.
        assert len(create_kwargs["output_files"]) == 1

    def test_preset_mode_skips_inline_algorithms(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        client = _FakeAuphonicClient()
        backend = _make_backend(client, root, preset="CLM Lecture Recording")
        final = _final_path_for(root, raw_file)

        backend.submit(raw_file, final, options=ProcessingOptions(), ctx=ctx)

        create_kwargs = client.calls[0][2]
        assert create_kwargs["preset"] == "CLM Lecture Recording"
        assert create_kwargs["algorithms"] is None

    def test_cut_list_option_adds_output(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        client = _FakeAuphonicClient()
        backend = _make_backend(client, root)
        final = _final_path_for(root, raw_file)

        backend.submit(
            raw_file,
            final,
            options=ProcessingOptions(request_cut_list=True),
            ctx=ctx,
        )

        outputs = client.calls[0][2]["output_files"]
        formats = [o["format"] for o in outputs]
        assert "video" in formats
        assert "cut-list" in formats

    def test_backend_level_cut_list_default(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        """When backend is constructed with request_cut_list_default=True."""
        client = _FakeAuphonicClient()
        backend = _make_backend(client, root, request_cut_list_default=True)
        final = _final_path_for(root, raw_file)

        backend.submit(raw_file, final, options=ProcessingOptions(), ctx=ctx)

        formats = [o["format"] for o in client.calls[0][2]["output_files"]]
        assert "cut-list" in formats

    def test_submit_failure_marks_failed_and_cleans_up(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        class _FlakyClient(_FakeAuphonicClient):
            def upload_input(self, uuid, file_path, *, on_progress=None):
                self._record("upload_input", (uuid, file_path), {})
                raise AuphonicError("upload dropped the connection")

        client = _FlakyClient()
        backend = _make_backend(client, root)
        final = _final_path_for(root, raw_file)

        job = backend.submit(raw_file, final, options=ProcessingOptions(), ctx=ctx)

        assert job.state == JobState.FAILED
        assert "upload" in (job.error or "")
        # We should have attempted to delete the orphan production.
        assert client.deleted

    def test_submit_reports_upload_progress(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        client = _FakeAuphonicClient()
        backend = _make_backend(client, root)
        final = _final_path_for(root, raw_file)

        backend.submit(raw_file, final, options=ProcessingOptions(), ctx=ctx)

        # Upload occupies the 0.0 → 0.4 slice. Collect reported progress
        # values from the ctx transcript and verify it reaches 0.4 and
        # never exceeds it during upload.
        uploading = [j.progress for j in ctx.reports if j.state == JobState.UPLOADING]
        assert any(p > 0 for p in uploading)
        assert all(p <= 0.4 + 1e-9 for p in uploading)


# ---------------------------------------------------------------------
# poll
# ---------------------------------------------------------------------


class TestPoll:
    def _make_in_flight_job(self, root: Path, raw: Path) -> ProcessingJob:
        return ProcessingJob(
            backend_name="auphonic",
            raw_path=raw,
            final_path=_final_path_for(root, raw),
            relative_dir=raw.parent.relative_to(to_process_dir(root)),
            state=JobState.PROCESSING,
            progress=0.4,
            backend_ref="prod-1",
            started_at=datetime.now(timezone.utc),
        )

    def test_in_progress_updates_message_and_progress(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        client = _FakeAuphonicClient(
            get_responses=[
                AuphonicProduction(
                    uuid="prod-1",
                    status=AuphonicStatus.AUDIO_PROCESSING,
                    status_string="Audio Processing",
                )
            ]
        )
        backend = _make_backend(client, root)
        job = self._make_in_flight_job(root, raw_file)

        updated = backend.poll(job, ctx=ctx)

        assert updated.state == JobState.PROCESSING
        assert "Audio Processing" in updated.message
        assert updated.progress >= 0.4

    def test_done_downloads_and_completes(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        done = AuphonicProduction(
            uuid="prod-1",
            status=AuphonicStatus.DONE,
            output_files=[
                AuphonicOutputFile(
                    format="video",
                    ending="mp4",
                    download_url="https://cdn/prod-1.mp4",
                )
            ],
        )
        client = _FakeAuphonicClient(get_responses=[done])
        backend = _make_backend(client, root)
        job = self._make_in_flight_job(root, raw_file)

        updated = backend.poll(job, ctx=ctx)

        assert updated.state == JobState.COMPLETED
        assert updated.progress == pytest.approx(1.0)
        assert updated.final_path.exists(), "Final file should be downloaded"
        assert updated.final_path.read_bytes() == b"fake-video"
        # Raw file is archived off the to-process tree.
        assert not raw_file.exists()
        archive_file = (
            root / "archive" / raw_file.parent.relative_to(to_process_dir(root)) / raw_file.name
        )
        assert archive_file.exists()

    def test_done_with_cut_list_downloads_both(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        def _write(url: str, dest: Path) -> None:
            dest.write_bytes(b"video" if dest.suffix == ".mp4" else b"cuts")

        done = AuphonicProduction(
            uuid="prod-1",
            status=AuphonicStatus.DONE,
            output_files=[
                AuphonicOutputFile(format="video", ending="mp4", download_url="https://cdn/v.mp4"),
                AuphonicOutputFile(
                    format="cut-list",
                    ending="DaVinciResolve.edl",
                    download_url="https://cdn/v.edl",
                ),
            ],
        )
        client = _FakeAuphonicClient(get_responses=[done], download_fn=_write)
        backend = _make_backend(client, root)
        job = self._make_in_flight_job(root, raw_file)

        updated = backend.poll(job, ctx=ctx)

        assert updated.state == JobState.COMPLETED
        assert "cut_list" in updated.artifacts
        assert updated.artifacts["cut_list"].suffix == ".edl"
        assert updated.artifacts["cut_list"].read_bytes() == b"cuts"

    def test_error_status_marks_failed(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        err = AuphonicProduction(
            uuid="prod-1",
            status=AuphonicStatus.ERROR,
            error_message="Input file corrupt",
        )
        client = _FakeAuphonicClient(get_responses=[err])
        backend = _make_backend(client, root)
        job = self._make_in_flight_job(root, raw_file)

        updated = backend.poll(job, ctx=ctx)

        assert updated.state == JobState.FAILED
        assert "corrupt" in (updated.error or "")

    def test_poll_error_does_not_fail_job(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        class _TransientClient(_FakeAuphonicClient):
            def get_production(self, uuid):
                self._record("get_production", (uuid,), {})
                raise AuphonicError("temporary network blip")

        client = _TransientClient()
        backend = _make_backend(client, root)
        job = self._make_in_flight_job(root, raw_file)

        updated = backend.poll(job, ctx=ctx)

        # Transient errors should not fail the job — the next poll will
        # retry. The job stays in its current state with a diagnostic
        # message.
        assert updated.state == JobState.PROCESSING
        assert "network blip" in updated.message

    def test_stale_warn_flags_but_does_not_fail(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        """Past the stale-warn window the job gets flagged, not failed.

        Auphonic credits and time are too expensive to discard; a soft
        warning lets the user click Verify while the production keeps
        running upstream.
        """
        still_going = AuphonicProduction(
            uuid="prod-x",
            status=AuphonicStatus.AUDIO_PROCESSING,
            status_string="Audio Processing",
        )
        client = _FakeAuphonicClient(get_responses=[still_going])
        backend = _make_backend(client, root, poll_timeout_minutes=1)
        job = self._make_in_flight_job(root, raw_file)
        job.started_at = datetime.now(timezone.utc) - timedelta(minutes=2)

        updated = backend.poll(job, ctx=ctx)

        assert updated.state == JobState.PROCESSING
        assert updated.stale is True
        # Upstream was still contacted — we don't short-circuit anymore.
        assert any(name == "get_production" for name, _, _ in client.calls)

    def test_hard_giveup_fails_job(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        """Past the hard giveup window the job is auto-failed as a safety net.

        At this point the Auphonic production has almost certainly been
        garbage-collected, so keeping the job alive is pointless.
        """
        from clm.recordings.workflow.backends.auphonic import AUPHONIC_HARD_GIVEUP_DAYS

        client = _FakeAuphonicClient()
        backend = _make_backend(client, root)
        job = self._make_in_flight_job(root, raw_file)
        job.started_at = datetime.now(timezone.utc) - timedelta(days=AUPHONIC_HARD_GIVEUP_DAYS + 1)

        updated = backend.poll(job, ctx=ctx)

        assert updated.state == JobState.FAILED
        assert "unfinished" in (updated.error or "").lower() or "days" in (updated.error or "")
        # Hard-giveup must short-circuit before talking to Auphonic.
        assert not any(name == "get_production" for name, _, _ in client.calls)

    def test_successful_poll_clears_stale_flag(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        """A fresh poll within the stale window leaves the flag off."""
        still_going = AuphonicProduction(
            uuid="prod-x",
            status=AuphonicStatus.AUDIO_PROCESSING,
            status_string="Audio Processing",
        )
        client = _FakeAuphonicClient(get_responses=[still_going])
        backend = _make_backend(client, root, poll_timeout_minutes=60)
        job = self._make_in_flight_job(root, raw_file)
        job.stale = True  # lingering from a prior poll
        job.started_at = datetime.now(timezone.utc) - timedelta(minutes=5)

        updated = backend.poll(job, ctx=ctx)

        assert updated.stale is False

    def test_missing_backend_ref_fails_immediately(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        client = _FakeAuphonicClient()
        backend = _make_backend(client, root)
        job = self._make_in_flight_job(root, raw_file)
        job.backend_ref = None

        updated = backend.poll(job, ctx=ctx)

        assert updated.state == JobState.FAILED
        assert "production reference" in (updated.error or "")

    def test_terminal_job_is_returned_untouched(
        self, root: Path, raw_file: Path, ctx: _RecordingContext
    ) -> None:
        client = _FakeAuphonicClient()
        backend = _make_backend(client, root)
        job = self._make_in_flight_job(root, raw_file)
        job.state = JobState.COMPLETED

        updated = backend.poll(job, ctx=ctx)

        assert updated is job
        # Terminal jobs are never polled on the server.
        assert not client.calls


# ---------------------------------------------------------------------
# cancel
# ---------------------------------------------------------------------


class TestCancel:
    def test_cancel_deletes_production(self, root: Path, raw_file: Path, ctx) -> None:
        client = _FakeAuphonicClient()
        backend = _make_backend(client, root)
        job = ProcessingJob(
            backend_name="auphonic",
            raw_path=raw_file,
            final_path=_final_path_for(root, raw_file),
            relative_dir=Path(),
            backend_ref="prod-9",
        )

        backend.cancel(job, ctx=ctx)

        assert client.deleted

    def test_cancel_without_backend_ref_is_noop(self, root: Path, raw_file: Path, ctx) -> None:
        client = _FakeAuphonicClient()
        backend = _make_backend(client, root)
        job = ProcessingJob(
            backend_name="auphonic",
            raw_path=raw_file,
            final_path=_final_path_for(root, raw_file),
            relative_dir=Path(),
        )

        backend.cancel(job, ctx=ctx)

        assert not client.deleted
        assert not client.calls


class TestMessageElapsed:
    """``_message_for`` appends elapsed time when a job is provided."""

    def test_without_job_argument_returns_bare_status(self) -> None:
        production = AuphonicProduction(
            uuid="p",
            status=AuphonicStatus.AUDIO_PROCESSING,
            status_string="Audio Processing",
        )
        assert AuphonicBackend._message_for(production) == "Auphonic: Audio Processing"

    def test_with_job_appends_elapsed_time(self, raw_file: Path, root: Path) -> None:
        production = AuphonicProduction(
            uuid="p",
            status=AuphonicStatus.AUDIO_PROCESSING,
            status_string="Audio Processing",
        )
        job = ProcessingJob(
            backend_name="auphonic",
            raw_path=raw_file,
            final_path=_final_path_for(root, raw_file),
            relative_dir=Path(),
            started_at=datetime.now(timezone.utc) - timedelta(minutes=3, seconds=47),
        )
        msg = AuphonicBackend._message_for(production, job)
        assert msg.startswith("Auphonic: Audio Processing — ")
        # Minute/second boundaries drift by a few ms during the test,
        # but the "3m Ns" shape should hold.
        assert "3m" in msg and msg.endswith("s")

    def test_with_job_without_started_at_is_bare(self, raw_file: Path, root: Path) -> None:
        production = AuphonicProduction(
            uuid="p",
            status=AuphonicStatus.AUDIO_PROCESSING,
            status_string="Audio Processing",
        )
        job = ProcessingJob(
            backend_name="auphonic",
            raw_path=raw_file,
            final_path=_final_path_for(root, raw_file),
            relative_dir=Path(),
            # started_at left at default None.
        )
        assert AuphonicBackend._message_for(production, job) == "Auphonic: Audio Processing"

    def test_humanize_duration_formats(self) -> None:
        from clm.recordings.workflow.backends.auphonic import _humanize_duration

        assert _humanize_duration(timedelta(seconds=45)) == "45s"
        assert _humanize_duration(timedelta(minutes=3, seconds=47)) == "3m 47s"
        assert _humanize_duration(timedelta(hours=1, minutes=5)) == "1h 5m"
        assert _humanize_duration(timedelta(seconds=-10)) == "0s"


class TestReconcile:
    """``AuphonicBackend.reconcile`` rescues jobs whose displayed state drifted."""

    def _make_job(
        self,
        root: Path,
        raw_file: Path,
        *,
        state: JobState = JobState.FAILED,
        backend_ref: str | None = None,
        error: str | None = None,
    ) -> ProcessingJob:
        return ProcessingJob(
            backend_name="auphonic",
            raw_path=raw_file,
            final_path=_final_path_for(root, raw_file),
            relative_dir=Path(),
            state=state,
            backend_ref=backend_ref,
            error=error,
            started_at=datetime.now(timezone.utc) - timedelta(minutes=5),
        )

    def test_local_final_already_exists_marks_completed(
        self, root: Path, raw_file: Path, ctx
    ) -> None:
        """Filesystem check is the cheapest and highest-priority signal."""
        backend = _make_backend(_FakeAuphonicClient(), root)
        job = self._make_job(root, raw_file, backend_ref="prod-1")

        job.final_path.parent.mkdir(parents=True, exist_ok=True)
        job.final_path.write_bytes(b"final-bytes")

        updated = backend.reconcile(job, ctx=ctx)

        assert updated.state == JobState.COMPLETED
        assert updated.progress == 1.0
        assert "Recovered" in updated.message
        assert updated.error is None
        assert updated.completed_at is not None
        # Raw should be archived if it was still present.
        archived = (
            root / "archive" / raw_file.parent.relative_to(root / "to-process") / raw_file.name
        )
        assert archived.exists() or not raw_file.exists()

    def test_backend_ref_done_triggers_finalize(self, root: Path, raw_file: Path, ctx) -> None:
        """A DONE Auphonic production drives full finalization."""
        done_production = AuphonicProduction(
            uuid="prod-x",
            status=AuphonicStatus.DONE,
            output_files=[
                AuphonicOutputFile(
                    format="video",
                    ending="mp4",
                    download_url="https://cdn.test/p.mp4",
                )
            ],
        )
        client = _FakeAuphonicClient(get_responses=[done_production])
        backend = _make_backend(client, root)
        job = self._make_job(root, raw_file, backend_ref="prod-x")

        updated = backend.reconcile(job, ctx=ctx)

        assert updated.state == JobState.COMPLETED
        # Final should now exist on disk (downloaded by _finalize).
        assert updated.final_path.exists()
        call_names = [c[0] for c in client.calls]
        assert "get_production" in call_names
        assert "download" in call_names

    def test_backend_ref_error_fails_job(self, root: Path, raw_file: Path, ctx) -> None:
        """A production in ERROR state transitions the job to FAILED with a clear message."""
        err_production = AuphonicProduction(
            uuid="prod-x",
            status=AuphonicStatus.ERROR,
            error_message="Upload truncated",
        )
        client = _FakeAuphonicClient(get_responses=[err_production])
        backend = _make_backend(client, root)
        job = self._make_job(root, raw_file, state=JobState.PROCESSING, backend_ref="prod-x")

        updated = backend.reconcile(job, ctx=ctx)

        assert updated.state == JobState.FAILED
        assert updated.error == "Upload truncated"

    def test_resurrects_failed_job_when_upstream_still_processing(
        self, root: Path, raw_file: Path, ctx
    ) -> None:
        """A FAILED local job whose upstream is still working comes back to PROCESSING."""
        still_going = AuphonicProduction(
            uuid="prod-x",
            status=AuphonicStatus.AUDIO_PROCESSING,
            status_string="Audio Processing",
        )
        client = _FakeAuphonicClient(get_responses=[still_going])
        backend = _make_backend(client, root)
        job = self._make_job(
            root,
            raw_file,
            state=JobState.FAILED,
            backend_ref="prod-x",
            error="120-min timeout",
        )

        updated = backend.reconcile(job, ctx=ctx)

        assert updated.state == JobState.PROCESSING
        assert updated.error is None
        assert updated.last_poll_error is None
        assert updated.stale is False
        assert "Audio Processing" in updated.message

    def test_backend_ref_network_error_records_last_poll_error(
        self, root: Path, raw_file: Path, ctx
    ) -> None:
        """Transient errors are surfaced on last_poll_error, not raised."""

        class _FlakyClient(_FakeAuphonicClient):
            def get_production(self, uuid):
                raise AuphonicError("network unreachable")

        backend = _make_backend(_FlakyClient(), root)
        job = self._make_job(root, raw_file, backend_ref="prod-x")

        updated = backend.reconcile(job, ctx=ctx)

        assert updated.last_poll_error == "network unreachable"
        # State unchanged (still FAILED from the fixture) — caller decides.
        assert updated.state == JobState.FAILED

    def test_title_fallback_single_match_adopts_uuid(self, root: Path, raw_file: Path, ctx) -> None:
        """When backend_ref is missing, a single title match is adopted."""
        match = AuphonicProduction(
            uuid="found-uuid",
            status=AuphonicStatus.AUDIO_PROCESSING,
            status_string="Audio Processing",
        )
        still_going = AuphonicProduction(
            uuid="found-uuid",
            status=AuphonicStatus.AUDIO_PROCESSING,
            status_string="Audio Processing",
        )
        client = _FakeAuphonicClient(
            get_responses=[still_going],
            list_responses=[[match]],
        )
        backend = _make_backend(client, root)
        job = self._make_job(root, raw_file, backend_ref=None)

        updated = backend.reconcile(job, ctx=ctx)

        assert updated.backend_ref == "found-uuid"
        assert updated.state == JobState.PROCESSING

    def test_title_fallback_multiple_matches_leaves_alone(
        self, root: Path, raw_file: Path, ctx
    ) -> None:
        """Ambiguous title matches stay a no-op with a resolvable message."""
        match_a = AuphonicProduction(uuid="a", status=AuphonicStatus.DONE)
        match_b = AuphonicProduction(uuid="b", status=AuphonicStatus.DONE)
        client = _FakeAuphonicClient(list_responses=[[match_a, match_b]])
        backend = _make_backend(client, root)
        job = self._make_job(root, raw_file, backend_ref=None)

        updated = backend.reconcile(job, ctx=ctx)

        assert updated.backend_ref is None  # unchanged — ambiguous
        assert "Multiple" in updated.message

    def test_title_fallback_no_matches_is_noop_with_message(
        self, root: Path, raw_file: Path, ctx
    ) -> None:
        client = _FakeAuphonicClient(list_responses=[[]])
        backend = _make_backend(client, root)
        job = self._make_job(root, raw_file, backend_ref=None, state=JobState.FAILED)

        updated = backend.reconcile(job, ctx=ctx)

        assert updated.state == JobState.FAILED  # untouched
        assert "Nothing to reconcile" in updated.message


class TestSubmitRequestsPollSoon:
    """After transitioning to PROCESSING, submit nudges the poller."""

    def test_submit_calls_request_poll_soon(self, root: Path, raw_file: Path, ctx) -> None:
        backend = _make_backend(_FakeAuphonicClient(), root)
        options = ProcessingOptions()
        backend.submit(
            raw_file,
            _final_path_for(root, raw_file),
            options=options,
            ctx=ctx,
        )
        assert ctx.poll_soon_calls == 1
