"""Behavior-focused tests for notebook_processor module.

These tests verify the observable behavior of notebook processing:
- Which cells appear in the output based on tags and output spec
- How cell content is transformed (notes styling, answer prefixes, code clearing)
- What output format is produced (HTML, code, notebook)
- Caching behavior for executed notebooks

Tests are designed to enable refactoring by focusing on inputs/outputs
rather than internal implementation details.
"""

import json
import time
import uuid
from base64 import b64encode
from unittest.mock import AsyncMock, MagicMock, patch

import psutil
import pytest
from nbformat import NotebookNode

from clm.infrastructure.messaging.notebook_classes import NotebookPayload
from clm.workers.notebook.notebook_processor import (
    CellIdGenerator,
    NotebookProcessor,
    TrackingExecutePreprocessor,
)
from clm.workers.notebook.output_spec import (
    CodeAlongOutput,
    CompletedOutput,
    PartialOutput,
    SpeakerOutput,
    create_output_spec,
)

# ============================================================================
# Test Fixtures - Notebook Creation Helpers
# ============================================================================


def make_cell(
    cell_type: str, source: str, tags: list[str] | None = None, lang: str | None = None
) -> NotebookNode:
    """Create a notebook cell as NotebookNode.

    Args:
        cell_type: "code" or "markdown"
        source: Cell content
        tags: Optional list of cell tags
        lang: Optional language code (e.g., "en", "de") for language-specific cells

    Returns:
        NotebookNode cell
    """
    metadata: dict = {"tags": tags or []}
    if lang:
        metadata["lang"] = lang
    cell = NotebookNode(
        {
            "id": uuid.uuid4().hex[:16],  # Generate unique cell ID (required by nbformat 5+)
            "cell_type": cell_type,
            "source": source,
            "metadata": metadata,
        }
    )
    if cell_type == "code":
        cell["outputs"] = []
        cell["execution_count"] = None
    return cell


def make_notebook_node(cells: list[NotebookNode]) -> NotebookNode:
    """Create a NotebookNode from cells.

    Args:
        cells: List of NotebookNode cells

    Returns:
        NotebookNode notebook
    """
    return NotebookNode(
        {
            "cells": cells,
            "metadata": {
                "kernelspec": {"name": "python3", "display_name": "Python 3"},
                "language_info": {"name": "python"},
            },
            "nbformat": 4,
            "nbformat_minor": 5,
        }
    )


def make_notebook_json(cells: list[dict]) -> str:
    """Create a notebook JSON string from cell dicts.

    Args:
        cells: List of cell dictionaries

    Returns:
        JSON string of the notebook
    """
    notebook = {
        "cells": cells,
        "metadata": {
            "kernelspec": {"name": "python3", "display_name": "Python 3"},
            "language_info": {"name": "python"},
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }
    return json.dumps(notebook)


def make_payload(
    notebook_data: str,
    format_: str = "notebook",
    kind: str = "completed",
    language: str = "en",
    prog_lang: str = "python",
    other_files: dict | None = None,
) -> NotebookPayload:
    """Create a NotebookPayload for testing.

    Args:
        notebook_data: JSON string of notebook content
        format_: Output format (notebook, html, code)
        kind: Output kind (completed, code-along, speaker)
        language: Human language (en, de)
        prog_lang: Programming language
        other_files: Dict of filename -> base64-encoded content

    Returns:
        NotebookPayload instance
    """
    return NotebookPayload(
        input_file="/test/notebook.ipynb",
        input_file_name="notebook.ipynb",
        output_file="/test/output/notebook",
        data=notebook_data,
        format=format_,
        kind=kind,
        language=language,
        prog_lang=prog_lang,
        correlation_id="test-correlation-id",
        other_files=other_files or {},
    )


# ============================================================================
# Cell Filtering Tests - Which cells appear in output based on tags
# ============================================================================


class TestCellFilteringByTag:
    """Test that cells are correctly filtered based on their tags.

    These tests verify the observable behavior of cell filtering by testing
    the _process_notebook_node method with NotebookNode inputs.
    """

    @pytest.mark.asyncio
    async def test_del_tagged_cells_removed_from_completed(self):
        """Cells tagged with 'del' should be removed from completed output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "# This should be deleted", tags=["del"]),
                make_cell("code", "print('hello')"),
            ]
        )

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="completed", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        # Check the resulting cells
        cell_sources = [cell["source"] for cell in result["cells"]]
        assert "# This should be deleted" not in cell_sources
        assert "# Title" in cell_sources
        assert "print('hello')" in cell_sources

    @pytest.mark.asyncio
    async def test_del_tagged_cells_removed_from_speaker(self):
        """Cells tagged with 'del' should be removed from speaker output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "# This should be deleted", tags=["del"]),
                make_cell("code", "print('hello')"),
            ]
        )

        spec = SpeakerOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="speaker", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        assert "# This should be deleted" not in cell_sources

    @pytest.mark.asyncio
    async def test_del_tagged_cells_removed_from_codealong(self):
        """Cells tagged with 'del' should be removed from code-along output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "# This should be deleted", tags=["del"]),
                make_cell("code", "print('hello')"),
            ]
        )

        spec = CodeAlongOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="code-along", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        assert "# This should be deleted" not in cell_sources

    @pytest.mark.asyncio
    async def test_notes_cells_included_in_speaker_output(self):
        """Notes cells should appear in speaker output with yellow styling."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "Speaker notes here", tags=["notes"]),
                make_cell("code", "print('hello')"),
            ]
        )

        spec = SpeakerOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="speaker", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        # Find the notes cell
        notes_cells = [
            cell for cell in result["cells"] if "notes" in cell.get("metadata", {}).get("tags", [])
        ]
        assert len(notes_cells) == 1
        # Should have yellow background styling
        assert "background: yellow" in notes_cells[0]["source"]
        assert "Speaker notes here" in notes_cells[0]["source"]

    @pytest.mark.asyncio
    async def test_notes_cells_excluded_from_completed_output(self):
        """Notes cells should be removed from completed output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "Speaker notes here", tags=["notes"]),
                make_cell("code", "print('hello')"),
            ]
        )

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="completed", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        # Notes should be excluded - check none of the sources contain it
        assert not any("Speaker notes here" in src for src in cell_sources)

    @pytest.mark.asyncio
    async def test_notes_cells_excluded_from_codealong_output(self):
        """Notes cells should be removed from code-along output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "Speaker notes here", tags=["notes"]),
                make_cell("code", "print('hello')"),
            ]
        )

        spec = CodeAlongOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="code-along", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        assert not any("Speaker notes here" in src for src in cell_sources)

    @pytest.mark.asyncio
    async def test_voiceover_cells_included_in_speaker_output(self):
        """Voiceover cells should appear in speaker output with amber styling."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "Voiceover transcript here", tags=["voiceover"]),
                make_cell("code", "print('hello')"),
            ]
        )

        spec = SpeakerOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="speaker", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        voiceover_cells = [
            cell
            for cell in result["cells"]
            if "voiceover" in cell.get("metadata", {}).get("tags", [])
        ]
        assert len(voiceover_cells) == 1
        assert "background: #FFEEBA" in voiceover_cells[0]["source"]
        assert "Voiceover transcript here" in voiceover_cells[0]["source"]

    @pytest.mark.asyncio
    async def test_voiceover_cells_excluded_from_completed_output(self):
        """Voiceover cells should be removed from completed output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "Voiceover transcript here", tags=["voiceover"]),
                make_cell("code", "print('hello')"),
            ]
        )

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="completed", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        assert not any("Voiceover transcript here" in src for src in cell_sources)

    @pytest.mark.asyncio
    async def test_voiceover_cells_excluded_from_codealong_output(self):
        """Voiceover cells should be removed from code-along output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "Voiceover transcript here", tags=["voiceover"]),
                make_cell("code", "print('hello')"),
            ]
        )

        spec = CodeAlongOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="code-along", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        assert not any("Voiceover transcript here" in src for src in cell_sources)

    @pytest.mark.asyncio
    async def test_start_cells_excluded_from_completed(self):
        """Cells tagged with 'start' should be removed from completed output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "# Starting code template", tags=["start"]),
                make_cell("code", "print('hello')"),
            ]
        )

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="completed", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        assert "# Starting code template" not in cell_sources

    @pytest.mark.asyncio
    async def test_start_cells_excluded_from_speaker(self):
        """Cells tagged with 'start' should be removed from speaker output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "# Starting code template", tags=["start"]),
                make_cell("code", "print('hello')"),
            ]
        )

        spec = SpeakerOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="speaker", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        assert "# Starting code template" not in cell_sources

    @pytest.mark.asyncio
    async def test_alt_cells_excluded_from_codealong(self):
        """Cells tagged with 'alt' should be removed from code-along output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "# Alternative solution", tags=["alt"]),
                make_cell("code", "print('hello')"),
            ]
        )

        spec = CodeAlongOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="code-along", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        assert "# Alternative solution" not in cell_sources

    @pytest.mark.asyncio
    async def test_alt_cells_included_in_completed(self):
        """Cells tagged with 'alt' should be included in completed output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "# Alternative solution", tags=["alt"]),
            ]
        )

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="completed", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        assert "# Alternative solution" in cell_sources


class TestCellFilteringByLanguage:
    """Test that cells are filtered based on language metadata."""

    @pytest.mark.asyncio
    async def test_english_only_cells_excluded_from_german_output(self):
        """Cells with lang='en' metadata should be excluded from German output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "English only content", lang="en"),
                make_cell("markdown", "Universal content"),
            ]
        )

        spec = CompletedOutput(language="de", format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", language="de", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        assert "English only content" not in cell_sources
        assert "Universal content" in cell_sources

    @pytest.mark.asyncio
    async def test_german_only_cells_excluded_from_english_output(self):
        """Cells with lang='de' metadata should be excluded from English output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "German only content", lang="de"),
                make_cell("markdown", "Universal content"),
            ]
        )

        spec = CompletedOutput(language="en", format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", language="en", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        assert "German only content" not in cell_sources
        assert "Universal content" in cell_sources

    @pytest.mark.asyncio
    async def test_english_cells_included_in_english_output(self):
        """Cells with lang='en' metadata should be included in English output."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "English only content", lang="en"),
            ]
        )

        spec = CompletedOutput(language="en", format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", language="en", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        assert "English only content" in cell_sources


# ============================================================================
# Cell Content Transformation Tests
# ============================================================================


class TestCodeCellContentClearing:
    """Test code cell content clearing in code-along output."""

    @pytest.mark.asyncio
    async def test_codealong_clears_regular_code_cells(self):
        """Code-along should clear contents of regular code cells."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "print('this should be cleared')"),
            ]
        )

        spec = CodeAlongOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="code-along", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        # Find the code cell and verify it's cleared
        code_cells = [c for c in result["cells"] if c["cell_type"] == "code"]
        assert len(code_cells) == 1
        assert code_cells[0]["source"] == ""

    @pytest.mark.asyncio
    async def test_codealong_preserves_keep_tagged_code(self):
        """Code-along should preserve code in cells tagged 'keep'."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "# This code should be kept", tags=["keep"]),
                make_cell("code", "# This should be cleared"),
            ]
        )

        spec = CodeAlongOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="code-along", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        code_cells = [c for c in result["cells"] if c["cell_type"] == "code"]
        # Keep cell should have content
        keep_cell = [c for c in code_cells if "keep" in c.get("metadata", {}).get("tags", [])]
        assert len(keep_cell) == 1
        assert "This code should be kept" in keep_cell[0]["source"]

        # Regular cell should be cleared
        regular_cells = [
            c for c in code_cells if "keep" not in c.get("metadata", {}).get("tags", [])
        ]
        assert len(regular_cells) == 1
        assert regular_cells[0]["source"] == ""

    @pytest.mark.asyncio
    async def test_codealong_preserves_start_tagged_code(self):
        """Code-along should preserve code in cells tagged 'start'."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "# Starting template code", tags=["start"]),
            ]
        )

        spec = CodeAlongOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="code-along", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        code_cells = [c for c in result["cells"] if c["cell_type"] == "code"]
        assert len(code_cells) == 1
        assert "Starting template code" in code_cells[0]["source"]

    @pytest.mark.asyncio
    async def test_completed_preserves_all_code_content(self):
        """Completed output should preserve all code cell contents."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "print('all code preserved')"),
            ]
        )

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="completed", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        code_cells = [c for c in result["cells"] if c["cell_type"] == "code"]
        assert len(code_cells) == 1
        assert "all code preserved" in code_cells[0]["source"]


class TestAnswerCellFormatting:
    """Test answer cell prefix formatting."""

    @pytest.mark.asyncio
    async def test_answer_cell_gets_english_prefix(self):
        """Answer cells in English output get 'Answer:' prefix."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "The solution is 42", tags=["answer"]),
            ]
        )

        spec = CompletedOutput(language="en", format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", language="en", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        answer_cells = [
            c for c in result["cells"] if "answer" in c.get("metadata", {}).get("tags", [])
        ]
        assert len(answer_cells) == 1
        assert "*Answer:*" in answer_cells[0]["source"]
        assert "The solution is 42" in answer_cells[0]["source"]

    @pytest.mark.asyncio
    async def test_answer_cell_gets_german_prefix(self):
        """Answer cells in German output get 'Antwort:' prefix."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "Die Lösung ist 42", tags=["answer"]),
            ]
        )

        spec = CompletedOutput(language="de", format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", language="de", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        answer_cells = [
            c for c in result["cells"] if "answer" in c.get("metadata", {}).get("tags", [])
        ]
        assert len(answer_cells) == 1
        assert "*Antwort:*" in answer_cells[0]["source"]
        assert "Die Lösung ist 42" in answer_cells[0]["source"]

    @pytest.mark.asyncio
    async def test_codealong_clears_answer_cell_content(self):
        """Code-along should show only prefix for answer cells, not content."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "The detailed answer", tags=["answer"]),
            ]
        )

        spec = CodeAlongOutput(language="en", format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="code-along", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        answer_cells = [
            c for c in result["cells"] if "answer" in c.get("metadata", {}).get("tags", [])
        ]
        assert len(answer_cells) == 1
        # Should have the prefix but not the content
        assert "*Answer:*" in answer_cells[0]["source"]
        assert "The detailed answer" not in answer_cells[0]["source"]


class TestNotesCellStyling:
    """Test notes cell styling in speaker output."""

    @pytest.mark.asyncio
    async def test_notes_cell_wrapped_in_yellow_div(self):
        """Notes cells should be wrapped in yellow background div."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "Important speaker note", tags=["notes"]),
            ]
        )

        spec = SpeakerOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="speaker", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        notes_cells = [
            c for c in result["cells"] if "notes" in c.get("metadata", {}).get("tags", [])
        ]
        assert len(notes_cells) == 1
        # Check for yellow background styling
        assert "background: yellow" in notes_cells[0]["source"]
        assert "Important speaker note" in notes_cells[0]["source"]
        assert "</div>" in notes_cells[0]["source"]


class TestVoiceoverCellStyling:
    """Test voiceover cell styling in speaker output."""

    @pytest.mark.asyncio
    async def test_voiceover_cell_wrapped_in_amber_div(self):
        """Voiceover cells should be wrapped in amber background div."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("markdown", "Voiceover transcript", tags=["voiceover"]),
            ]
        )

        spec = SpeakerOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="speaker", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        voiceover_cells = [
            c for c in result["cells"] if "voiceover" in c.get("metadata", {}).get("tags", [])
        ]
        assert len(voiceover_cells) == 1
        assert "background: #FFEEBA" in voiceover_cells[0]["source"]
        assert "Voiceover transcript" in voiceover_cells[0]["source"]
        assert "</div>" in voiceover_cells[0]["source"]


# ============================================================================
# Output Format Tests
# ============================================================================


class TestOutputFormatNotebook:
    """Test notebook (ipynb) format output via create_contents."""

    @pytest.mark.asyncio
    async def test_notebook_format_via_jupytext(self):
        """Notebook format should produce ipynb output via jupytext."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Test"),
                make_cell("code", "x = 1"),
            ]
        )

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", format_="notebook")

        result = await processor.create_contents(notebook, payload)

        # Should be valid JSON containing notebook structure
        parsed = json.loads(result)
        assert "cells" in parsed
        assert "metadata" in parsed


class TestOutputFormatCode:
    """Test code format output (Python script)."""

    @pytest.mark.asyncio
    async def test_code_format_produces_python_script(self):
        """Code format should produce a Python script via jupytext."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Test Notebook"),
                make_cell("code", "x = 1\nprint(x)"),
            ]
        )

        spec = CompletedOutput(format="code", prog_lang="python")
        processor = NotebookProcessor(spec)
        payload = make_payload("", format_="code", prog_lang="python")

        result = await processor.create_contents(notebook, payload)

        # Should contain the code
        assert "x = 1" in result
        assert "print(x)" in result
        # Should end with newline
        assert result.endswith("\n")


class TestOutputFormatHtml:
    """Test HTML format output."""

    @pytest.mark.asyncio
    async def test_html_format_uses_html_exporter(self):
        """HTML format should use HTMLExporter."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Test"),
            ]
        )

        # For testing HTML without execution, we mock both the exporter and ExecutePreprocessor
        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)
        payload = make_payload("", format_="html", kind="speaker")

        with (
            patch("clm.workers.notebook.notebook_processor.HTMLExporter") as MockExporter,
            patch("clm.workers.notebook.notebook_processor.TrackingExecutePreprocessor") as MockEP,
        ):
            mock_exporter = MagicMock()
            mock_exporter.from_notebook_node.return_value = (
                "<html><body>Test</body></html>",
                {},
            )
            MockExporter.return_value = mock_exporter
            # Mock ExecutePreprocessor to avoid actual notebook execution
            MockEP.return_value = MagicMock()

            result = await processor.create_contents(notebook, payload)

        assert "<html>" in result
        MockExporter.assert_called_once()


# ============================================================================
# Jinja Template Expansion Tests
# ============================================================================


class TestJinjaExpansion:
    """Test Jinja2 template expansion in notebooks."""

    @pytest.mark.asyncio
    async def test_jinja_globals_available_in_template(self):
        """Jinja globals (is_notebook, is_html, lang) should be available."""
        # Create a notebook that uses Jinja variables
        notebook_content = """# j2 if is_notebook
Notebook mode content
# j2 endif
# j2 if lang == "en"
English content
# j2 endif"""

        # This tests that the Jinja environment is correctly set up
        spec = CompletedOutput(format="notebook", language="en")
        processor = NotebookProcessor(spec)

        # Test the globals creation
        globals_ = processor._create_jinja_globals(spec)
        assert globals_["is_notebook"] is True
        assert globals_["is_html"] is False
        assert globals_["lang"] == "en"

    @pytest.mark.asyncio
    async def test_html_format_sets_is_html_true(self):
        """HTML format should set is_html=True in Jinja globals."""
        spec = CompletedOutput(format="html", language="de")

        globals_ = NotebookProcessor._create_jinja_globals(spec)
        assert globals_["is_html"] is True
        assert globals_["is_notebook"] is False
        assert globals_["lang"] == "de"

    @pytest.mark.asyncio
    async def test_jinja_globals_include_author_and_organization(self):
        """Jinja globals should include author and organization."""
        spec = CompletedOutput(format="notebook", language="en")

        globals_ = NotebookProcessor._create_jinja_globals(
            spec, author="Dr. Jane Smith", organization="My Academy"
        )
        assert globals_["author"] == "Dr. Jane Smith"
        assert globals_["organization"] == "My Academy"

    @pytest.mark.asyncio
    async def test_jinja_globals_default_author(self):
        """Jinja globals should use default author when not specified."""
        spec = CompletedOutput(format="notebook", language="en")

        globals_ = NotebookProcessor._create_jinja_globals(spec)
        assert globals_["author"] == "Dr. Matthias Hölzl"
        assert globals_["organization"] == ""


# ============================================================================
# Cell ID Generation Tests
# ============================================================================


class TestCellIdGeneration:
    """Test unique cell ID generation."""

    def test_cell_id_generator_creates_unique_ids(self):
        """CellIdGenerator should create unique IDs for different content."""
        generator = CellIdGenerator()

        cell1 = make_cell("code", "x = 1")
        cell2 = make_cell("code", "y = 2")
        cell3 = make_cell("markdown", "# Title")

        generator.set_cell_id(cell1, 0)
        generator.set_cell_id(cell2, 1)
        generator.set_cell_id(cell3, 2)

        ids = [cell1.id, cell2.id, cell3.id]

        # All IDs should be unique
        assert len(ids) == len(set(ids))
        # All IDs should be 16 characters (hex from sha3_224)
        assert all(len(id_) == 16 for id_ in ids)

    def test_duplicate_content_cells_get_different_ids(self):
        """Cells with identical content should still get different IDs."""
        generator = CellIdGenerator()

        cells = [
            make_cell("code", "x = 1"),
            make_cell("code", "x = 1"),  # Same content
            make_cell("code", "x = 1"),  # Same content again
        ]

        for i, cell in enumerate(cells):
            generator.set_cell_id(cell, i)

        ids = [cell.id for cell in cells]

        # All IDs should still be unique despite identical content
        assert len(ids) == len(set(ids))

    @pytest.mark.asyncio
    async def test_process_notebook_node_assigns_cell_ids(self):
        """Processing a notebook should assign IDs to all cells."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "x = 1"),
                make_cell("code", "y = 2"),
            ]
        )

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        # All cells should have IDs
        for cell in result["cells"]:
            assert cell.id is not None
            assert len(cell.id) == 16


# ============================================================================
# Slide Tag Processing Tests
# ============================================================================


class TestSlideTagProcessing:
    """Test slide tag processing for presentations."""

    @pytest.mark.asyncio
    async def test_slide_tag_creates_slideshow_metadata(self):
        """Cells with slide tags should get slideshow metadata."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# New Slide", tags=["slide"]),
                make_cell("markdown", "Content"),
            ]
        )

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        first_cell = result["cells"][0]

        # Should have slideshow metadata
        assert "slideshow" in first_cell.get("metadata", {})
        assert first_cell["metadata"]["slideshow"]["slide_type"] == "slide"

    @pytest.mark.asyncio
    async def test_subslide_tag_creates_subslide_metadata(self):
        """Cells with subslide tags should get subslide slideshow metadata."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Sub Slide", tags=["subslide"]),
            ]
        )

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        first_cell = result["cells"][0]
        assert first_cell["metadata"]["slideshow"]["slide_type"] == "subslide"


# ============================================================================
# Caching Behavior Tests
# ============================================================================


class TestExecutionCaching:
    """Test notebook execution caching behavior.

    These tests verify the caching contract between Speaker and Completed outputs:
    - Speaker HTML caches executed notebooks for reuse
    - Completed HTML reuses cached notebooks when available
    """

    def test_speaker_html_should_cache_property(self):
        """Speaker HTML spec should indicate caching is enabled."""
        spec = SpeakerOutput(format="html")
        assert spec.should_cache_execution is True

    def test_speaker_notebook_should_not_cache_property(self):
        """Speaker notebook spec should not cache."""
        spec = SpeakerOutput(format="notebook")
        assert spec.should_cache_execution is False

    def test_completed_html_can_reuse_property(self):
        """Completed HTML spec should indicate it can reuse cache."""
        spec = CompletedOutput(format="html")
        assert spec.can_reuse_execution is True

    def test_completed_notebook_cannot_reuse_property(self):
        """Completed notebook spec should not reuse cache."""
        spec = CompletedOutput(format="notebook")
        assert spec.can_reuse_execution is False

    def test_codealong_never_caches_or_reuses(self):
        """CodeAlong outputs should never cache or reuse."""
        for format_ in ["notebook", "code", "html"]:
            spec = CodeAlongOutput(format=format_)
            assert spec.should_cache_execution is False
            assert spec.can_reuse_execution is False


# ============================================================================
# Other Files Handling Tests
# ============================================================================


class TestOtherFilesHandling:
    """Test handling of additional files (other_files payload attribute)."""

    def test_payload_can_contain_other_files(self):
        """NotebookPayload should support other_files for auxiliary data."""
        # Encode some test data
        test_data = b"test content"
        encoded_data = b64encode(test_data).decode("utf-8")

        payload = make_payload(
            "",
            kind="speaker",
            format_="html",
            other_files={"data.txt": encoded_data},
        )

        assert "data.txt" in payload.other_files
        # Note: other_files values are stored as bytes (base64 encoded)
        assert payload.other_files["data.txt"] == encoded_data.encode("utf-8")


# ============================================================================
# Error Handling Tests
# ============================================================================


class TestErrorHandling:
    """Test error handling in notebook processing."""

    @pytest.mark.asyncio
    async def test_invalid_cell_type_handled_gracefully(self):
        """Unknown cell types should not crash processing."""
        # Create a notebook with an unusual cell type
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Test"),
            ]
        )
        # Add a weird cell type
        notebook["cells"].append(
            NotebookNode(
                {
                    "cell_type": "raw",
                    "source": "raw content",
                    "metadata": {"tags": []},
                }
            )
        )

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", format_="notebook")

        # Should not raise - raw cells are passed through
        result = await processor._process_notebook_node(notebook, payload)
        assert len(result["cells"]) == 2


# ============================================================================
# Integration-style Tests (Still Unit Tests but More Realistic)
# ============================================================================


class TestRealisticScenarios:
    """Test realistic notebook processing scenarios."""

    @pytest.mark.asyncio
    async def test_workshop_notebook_produces_correct_completed_output(self):
        """A typical workshop notebook should produce correct completed output."""
        # A realistic workshop notebook with various cell types
        workshop_notebook = make_notebook_node(
            [
                make_cell("markdown", "# Workshop: Introduction to Python"),
                make_cell("markdown", "Remember to pace yourself", tags=["notes"]),
                make_cell("code", "# Import libraries\nimport math", tags=["keep"]),
                make_cell("markdown", "## Exercise 1"),
                make_cell("code", "# Calculate area\nradius = 5\narea = math.pi * radius**2"),
                make_cell("markdown", "The area is calculated using πr²", tags=["answer"]),
                make_cell("code", "# Alternative using lambda", tags=["alt"]),
                make_cell("code", "# Template for students", tags=["start"]),
                make_cell("code", "# This cell should be removed", tags=["del"]),
            ]
        )

        # Test completed output
        spec = CompletedOutput(format="notebook", language="en")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="completed", format_="notebook", language="en")

        result = await processor._process_notebook_node(workshop_notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        all_sources = " ".join(cell_sources)

        # Verify completed output characteristics
        assert "Workshop: Introduction to Python" in all_sources
        assert "Remember to pace yourself" not in all_sources  # notes excluded
        assert "Import libraries" in all_sources  # keep cell included
        assert "Calculate area" in all_sources  # regular code included
        assert "*Answer:*" in all_sources  # answer prefix added
        assert "Alternative using lambda" in all_sources  # alt cell included in completed
        assert "Template for students" not in all_sources  # start excluded
        assert "This cell should be removed" not in all_sources  # del excluded

    @pytest.mark.asyncio
    async def test_workshop_notebook_produces_correct_codealong_output(self):
        """Code-along should clear code but preserve structure."""
        workshop_notebook = make_notebook_node(
            [
                make_cell("markdown", "# Workshop"),
                make_cell("code", "# Keep this setup", tags=["keep"]),
                make_cell("markdown", "## Try it yourself"),
                make_cell("code", "# Student should write this\nresult = 42"),
                make_cell("markdown", "The answer is 42", tags=["answer"]),
            ]
        )

        spec = CodeAlongOutput(format="notebook", language="en")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="code-along", format_="notebook", language="en")

        result = await processor._process_notebook_node(workshop_notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        all_sources = " ".join(cell_sources)

        # Structure preserved
        assert "Workshop" in all_sources
        assert "Try it yourself" in all_sources

        # Keep cell preserved
        assert "Keep this setup" in all_sources

        # Student code cleared - find the code cell without keep tag
        code_cells = [c for c in result["cells"] if c["cell_type"] == "code"]
        regular_code_cells = [
            c for c in code_cells if "keep" not in c.get("metadata", {}).get("tags", [])
        ]
        assert len(regular_code_cells) == 1
        assert regular_code_cells[0]["source"] == ""

        # Answer shows only prefix
        answer_cells = [
            c for c in result["cells"] if "answer" in c.get("metadata", {}).get("tags", [])
        ]
        assert len(answer_cells) == 1
        assert "*Answer:*" in answer_cells[0]["source"]
        assert "The answer is 42" not in answer_cells[0]["source"]

    @pytest.mark.asyncio
    async def test_workshop_notebook_produces_correct_speaker_output(self):
        """Speaker output should include notes with yellow styling."""
        workshop_notebook = make_notebook_node(
            [
                make_cell("markdown", "# Workshop"),
                make_cell("markdown", "Important notes for speaker", tags=["notes"]),
                make_cell("code", "print('example')"),
                make_cell("code", "# Deleted cell", tags=["del"]),
            ]
        )

        spec = SpeakerOutput(format="notebook", language="en")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="speaker", format_="notebook", language="en")

        result = await processor._process_notebook_node(workshop_notebook, payload)

        cell_sources = [cell["source"] for cell in result["cells"]]
        all_sources = " ".join(cell_sources)

        # Notes should be included with styling
        assert "Important notes for speaker" in all_sources
        assert "background: yellow" in all_sources

        # Code preserved
        assert "print('example')" in all_sources

        # Del cell excluded
        assert "Deleted cell" not in all_sources

    @pytest.mark.asyncio
    async def test_partial_output_splits_at_workshop_boundary(self):
        """Partial output: Completed behaviour before the first ``workshop``
        heading, CodeAlong behaviour for every cell from that heading to
        end-of-notebook. Exercises a realistic shape with a multi-slide
        workshop at the end."""
        notebook = make_notebook_node(
            [
                # ----- Pre-workshop demonstration section -----
                make_cell("markdown", "# Intro", tags=["slide"]),
                make_cell("markdown", "Speaker note about intro", tags=["notes"]),
                make_cell("code", "# Demo setup\nimport math", tags=["keep"]),
                make_cell("code", "# Worked demo\narea = math.pi * 5**2"),
                make_cell("markdown", "The demo answer is 78.5", tags=["answer"]),
                make_cell("code", "# Alternative demo approach", tags=["alt"]),
                make_cell("code", "# Deleted cell", tags=["del"]),
                make_cell("code", "# Starter scaffold", tags=["start"]),
                make_cell("code", "# Full solution for demo", tags=["completed"]),
                # ----- Workshop section (runs to EOF) -----
                make_cell("markdown", "## Workshop: Exercises", tags=["subslide", "workshop"]),
                make_cell("markdown", "## Task 1", tags=["subslide"]),
                make_cell("code", "# Student writes this\nresult = ..."),
                make_cell("markdown", "Workshop answer text", tags=["answer"]),
                make_cell("code", "# Required setup line", tags=["keep"]),
                make_cell("code", "# Hint scaffold", tags=["start"]),
                make_cell("code", "# Hidden workshop solution", tags=["completed"]),
                make_cell("markdown", "Alt workshop prose", tags=["alt"]),
                make_cell("markdown", "## Task 2", tags=["subslide"]),
                make_cell("code", "# Second student exercise\nvalue = None"),
            ]
        )

        spec = PartialOutput(format="notebook", language="en")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="partial", format_="notebook", language="en")

        result = await processor._process_notebook_node(notebook, payload)
        cells = result["cells"]
        sources = [c["source"] for c in cells]
        joined = " ".join(sources)

        # --- Pre-workshop: Completed behaviour ---
        assert "Intro" in joined, "markdown slide heading retained"
        assert "Speaker note about intro" not in joined, "notes excluded"
        assert "Demo setup" in joined, "keep cell retained with contents"
        assert "Worked demo" in joined, "regular demo code retained"
        assert "area = math.pi * 5**2" in joined, "demo code body retained"
        assert "*Answer:*" in joined, "answer prefix added pre-workshop"
        assert "The demo answer is 78.5" in joined, "answer body retained pre-workshop"
        assert "Alternative demo approach" in joined, "alt cell kept pre-workshop"
        assert "Deleted cell" not in joined, "del cell removed"
        assert "Starter scaffold" not in joined, "start cell removed pre-workshop"
        assert "Full solution for demo" in joined, "completed cell kept pre-workshop"

        # --- Workshop heading: kept, contents intact ---
        assert "Workshop: Exercises" in joined, "workshop heading retained"
        assert "Task 1" in joined, "later workshop slide heading retained"
        assert "Task 2" in joined, "multi-slide workshop fully included"

        # --- Post-workshop: CodeAlong behaviour ---
        # Student code cleared
        student_exercise_cells = [
            c
            for c in cells
            if c["cell_type"] == "code"
            and not {"keep", "start"}.intersection(c.get("metadata", {}).get("tags", []))
            and "_post_workshop" not in c.get("metadata", {}).get("tags", [])  # noqa: SIM118
        ]
        # The only un-cleared post-workshop code cells must be keep/start ones.
        # After tag stripping, _post_workshop is removed; use the fact that
        # cleared cells have empty source.
        post_workshop_code_cells = [
            c
            for c in cells
            if c["cell_type"] == "code"
            and any(
                src_fragment in c["source"]
                for src_fragment in ("Student writes this", "Second student exercise")
            )
        ]
        # Should be empty because those sources were cleared.
        assert post_workshop_code_cells == [], "post-workshop student code cleared"

        # keep/start in workshop are preserved as scaffolding
        assert "Required setup line" in joined, "post-workshop keep cell retained"
        assert "Hint scaffold" in joined, "post-workshop start cell retained (CodeAlong rule)"

        # completed/alt in workshop are dropped
        assert "Hidden workshop solution" not in joined, "completed cell dropped post-workshop"
        assert "Alt workshop prose" not in joined, "alt cell dropped post-workshop"

        # answer markdown: both pre- and post-workshop answer cells survive
        # (CompletedOutput and CodeAlongOutput both keep the cell); the
        # post-workshop one has its body cleared, leaving only the "*Answer:*"
        # prefix.
        answer_cells = [
            c
            for c in cells
            if c["cell_type"] == "markdown" and "answer" in c.get("metadata", {}).get("tags", [])
        ]
        assert len(answer_cells) == 2, "one pre-workshop + one post-workshop answer cell"
        # Post-workshop answer body is cleared; pre-workshop keeps its body.
        pre_workshop_answer = next(c for c in answer_cells if "The demo answer" in c["source"])
        post_workshop_answer = next(c for c in answer_cells if c is not pre_workshop_answer)
        assert post_workshop_answer["source"].strip() == "*Answer:*"
        assert "Workshop answer text" not in post_workshop_answer["source"]

        # --- Synthetic _post_workshop tag is stripped from output ---
        for cell in cells:
            tags = cell.get("metadata", {}).get("tags", [])
            assert "_post_workshop" not in tags, (
                f"Synthetic tag must not appear in output; saw tags={tags} on cell "
                f"{cell.get('cell_type')!r} with source={cell.get('source')[:40]!r}"
            )

    @pytest.mark.asyncio
    async def test_partial_without_workshop_behaves_like_completed(self):
        """When no ``workshop`` heading is present, Partial output matches
        Completed output — every cell stays in the pre-workshop branch."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Demo", tags=["slide"]),
                make_cell("code", "x = 1"),
                make_cell("code", "# Starter", tags=["start"]),
                make_cell("code", "# Solution", tags=["completed"]),
                make_cell("markdown", "Answer text", tags=["answer"]),
            ]
        )

        spec = PartialOutput(format="notebook", language="en")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="partial", format_="notebook", language="en")

        result = await processor._process_notebook_node(notebook, payload)
        joined = " ".join(c["source"] for c in result["cells"])

        # Completed-style: code retained, start dropped, completed kept,
        # answer prose shown.
        assert "x = 1" in joined
        assert "Starter" not in joined
        assert "Solution" in joined
        assert "Answer text" in joined


# ============================================================================
# Kernel Cleanup Tests
# ============================================================================


class TestKernelCleanup:
    """Test kernel resource cleanup behavior.

    These tests verify that kernel resources (ZMQ sockets, kernel processes)
    are properly cleaned up to prevent "Connection reset by peer [10054]"
    errors on Windows.
    """

    @pytest.mark.asyncio
    async def test_cleanup_handles_missing_km_kc(self):
        """Verify cleanup handles case where km/kc are None.

        When an ExecutePreprocessor is created but preprocess() is never
        called (or fails very early), km and kc will be None.
        """
        from nbconvert.preprocessors import ExecutePreprocessor

        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)

        # Create EP but don't call preprocess - km/kc will be None
        ep = ExecutePreprocessor(timeout=None, startup_timeout=300)

        # Should not raise even though km/kc are None
        await processor._cleanup_kernel_resources(ep, "test-cid")

    @pytest.mark.asyncio
    async def test_cleanup_handles_ep_without_km_attribute(self):
        """Verify cleanup handles EP that doesn't have km attribute at all."""
        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)

        # Create a mock object that doesn't have km/kc attributes
        class FakeEP:
            pass

        fake_ep = FakeEP()

        # Should not raise
        await processor._cleanup_kernel_resources(fake_ep, "test-cid")  # type: ignore[arg-type]

    @pytest.mark.asyncio
    async def test_fresh_preprocessor_each_retry(self):
        """Verify new ExecutePreprocessor is created for each retry attempt.

        This test mocks ExecutePreprocessor to track how many instances
        are created when kernel dies repeatedly.
        """
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Test"),
                make_cell("code", "x = 1"),
            ]
        )

        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)
        payload = make_payload("", format_="html", kind="speaker")

        ep_instances: list = []
        original_ep_class = None

        # We need to track EP creation and make preprocess fail
        with patch("clm.workers.notebook.notebook_processor.TrackingExecutePreprocessor") as MockEP:
            # Make preprocess always raise RuntimeError (kernel died)
            def create_mock_ep(*args, **kwargs):
                mock_ep = MagicMock()
                mock_ep.preprocess.side_effect = RuntimeError("Kernel died")
                mock_ep.km = None
                mock_ep.kc = None
                ep_instances.append(mock_ep)
                return mock_ep

            MockEP.side_effect = create_mock_ep

            # Also mock HTMLExporter since we won't get there
            with patch("clm.workers.notebook.notebook_processor.HTMLExporter") as MockHTML:
                mock_exporter = MagicMock()
                mock_exporter.from_notebook_node.return_value = ("<html></html>", {})
                MockHTML.return_value = mock_exporter

                # Skip the exponential backoff sleeps between retries
                with patch(
                    "clm.workers.notebook.notebook_processor.asyncio.sleep", new_callable=AsyncMock
                ):
                    # This should try multiple times then raise
                    with pytest.raises(RuntimeError, match="Kernel died"):
                        await processor.create_contents(notebook, payload)

        # Should have created NUM_RETRIES_FOR_HTML (6) separate EP instances
        from clm.workers.notebook.notebook_processor import NUM_RETRIES_FOR_HTML

        assert len(ep_instances) == NUM_RETRIES_FOR_HTML

    @pytest.mark.asyncio
    async def test_cleanup_called_on_success(self):
        """Verify cleanup is called after successful notebook execution."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Test"),
                make_cell("code", "x = 1"),
            ]
        )

        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)
        payload = make_payload("", format_="html", kind="speaker")

        cleanup_calls: list = []

        # Patch the cleanup method to track calls
        original_cleanup = processor._cleanup_kernel_resources

        async def tracked_cleanup(ep, cid):
            cleanup_calls.append((ep, cid))
            await original_cleanup(ep, cid)

        processor._cleanup_kernel_resources = tracked_cleanup  # type: ignore[method-assign]

        with (
            patch("clm.workers.notebook.notebook_processor.TrackingExecutePreprocessor") as MockEP,
            patch("clm.workers.notebook.notebook_processor.HTMLExporter") as MockHTML,
        ):
            mock_ep = MagicMock()
            mock_ep.preprocess.return_value = (notebook, {})
            mock_ep.km = None
            mock_ep.kc = None
            MockEP.return_value = mock_ep

            mock_exporter = MagicMock()
            mock_exporter.from_notebook_node.return_value = ("<html></html>", {})
            MockHTML.return_value = mock_exporter

            await processor.create_contents(notebook, payload)

        # Cleanup should have been called exactly once (success on first try)
        assert len(cleanup_calls) == 1

    def test_reaping_kernel_manager_kills_grandchild_on_success(self, tmp_path):
        """Grandchildren spawned by a cell must die on kernel shutdown (happy path).

        Regression test for the Windows orphan-python.exe incident
        documented in docs/proposals/WORKER_CLEANUP_RELIABILITY.md.
        ``jupyter_client.LocalProvisioner.kill`` is ``TerminateProcess`` on
        Windows, which only kills the kernel pid. Any subprocesses the
        kernel spawned (cells using ``subprocess.Popen``, ``multiprocessing``,
        etc.) survive as orphans unless
        :class:`clm.workers.notebook.notebook_processor._ReapingKernelManager`
        walks the tree and reaps survivors.

        Without the ``_ReapingKernelManager`` hook the sleeping ``python.exe``
        grandchild outlives the kernel and this test fails; with the hook,
        the grandchild is gone by the time ``preprocess`` returns.
        """
        pid_file = tmp_path / "grandchild.pid"
        # The cell spawns a 120-second-sleep child process and records its
        # pid to a file so the test can check it after the kernel shuts down.
        # Using a file (rather than parsing cell output) keeps the test robust
        # against nbconvert output formatting changes.
        cell_source = (
            "import subprocess, sys\n"
            "p = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(120)'])\n"
            f"open({str(pid_file)!r}, 'w').write(str(p.pid))\n"
        )
        notebook = make_notebook_node([make_cell("code", cell_source)])

        processor = NotebookProcessor(SpeakerOutput(format="html"))
        ep = TrackingExecutePreprocessor(processor, timeout=60, startup_timeout=60)

        ep.preprocess(notebook, resources={"metadata": {"path": str(tmp_path)}})

        assert pid_file.exists(), "Cell did not spawn the grandchild subprocess"
        grandchild_pid = int(pid_file.read_text())

        try:
            # _ReapingKernelManager runs inside nbclient's setup_kernel finally,
            # so by the time preprocess returns the grandchild should already
            # be gone. Allow a generous grace window — under xdist parallel
            # load on Windows, many concurrent subprocess spawns can delay
            # the OS's report of process exit.
            deadline = time.monotonic() + 15.0
            while time.monotonic() < deadline:
                if not psutil.pid_exists(grandchild_pid):
                    break
                time.sleep(0.05)

            assert not psutil.pid_exists(grandchild_pid), (
                f"Grandchild pid {grandchild_pid} survived kernel shutdown — "
                f"_ReapingKernelManager did not reap it"
            )
        finally:
            # Belt-and-braces cleanup if the test failed, so we do not leak
            # a 120-second sleeper across the rest of the test run.
            if psutil.pid_exists(grandchild_pid):
                try:
                    psutil.Process(grandchild_pid).kill()
                except psutil.NoSuchProcess:
                    pass

    def test_reaping_kernel_manager_kills_grandchild_on_cell_error(self, tmp_path):
        """Grandchildren must be reaped even when a later cell raises.

        Same regression as ``test_reaping_kernel_manager_kills_grandchild_on_success``
        but exercises the error path: cell 0 spawns a grandchild, cell 1
        raises, ``preprocess`` re-raises as ``CellExecutionError``. The
        reap must still run — it lives in the ``finally`` of nbclient's
        ``setup_kernel`` context manager, so it happens regardless of
        whether execution succeeded.
        """
        pid_file = tmp_path / "grandchild.pid"
        spawn_source = (
            "import subprocess, sys\n"
            "p = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(120)'])\n"
            f"open({str(pid_file)!r}, 'w').write(str(p.pid))\n"
        )
        notebook = make_notebook_node(
            [
                make_cell("code", spawn_source),
                make_cell("code", "raise RuntimeError('boom')"),
            ]
        )

        processor = NotebookProcessor(SpeakerOutput(format="html"))
        ep = TrackingExecutePreprocessor(processor, timeout=60, startup_timeout=60)

        with pytest.raises(Exception):  # nbconvert wraps this as CellExecutionError
            ep.preprocess(notebook, resources={"metadata": {"path": str(tmp_path)}})

        assert pid_file.exists(), "Cell did not spawn the grandchild subprocess"
        grandchild_pid = int(pid_file.read_text())

        try:
            # Generous deadline — error-path cleanup unwinds more nbclient
            # state before reaping, and xdist parallel load on Windows can
            # delay the OS's report of process exit.
            deadline = time.monotonic() + 15.0
            while time.monotonic() < deadline:
                if not psutil.pid_exists(grandchild_pid):
                    break
                time.sleep(0.05)

            assert not psutil.pid_exists(grandchild_pid), (
                f"Grandchild pid {grandchild_pid} survived error-path shutdown — "
                f"_ReapingKernelManager did not reap it"
            )
        finally:
            if psutil.pid_exists(grandchild_pid):
                try:
                    psutil.Process(grandchild_pid).kill()
                except psutil.NoSuchProcess:
                    pass


# ============================================================================
# Source Directory Handling Tests (Docker Mode with Source Mount)
# ============================================================================


class TestSourceDirectoryHandling:
    """Test handling of source_dir parameter for Docker mode with source mount.

    In Docker mode with source mount, supporting files (data.csv, model.pkl, etc.)
    are available directly from the mounted /source directory, eliminating the need
    to decode base64-encoded other_files from the payload.
    """

    @pytest.mark.asyncio
    async def test_write_other_files_skips_when_source_dir_provided(self, tmp_path):
        """When source_dir is provided, write_other_files should skip writing."""
        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)

        # Create a payload with some other_files
        test_data = b"test content"
        encoded_data = b64encode(test_data).decode("utf-8")
        payload = make_payload(
            "",
            kind="speaker",
            format_="html",
            other_files={"data.txt": encoded_data},
        )

        # Create a temp directory to be our "source" mount
        source_dir = tmp_path / "source"
        source_dir.mkdir()

        # Create another temp directory that would be written to
        write_dir = tmp_path / "write"
        write_dir.mkdir()

        # Call write_other_files with source_dir provided
        await processor.write_other_files("test-cid", write_dir, payload, source_dir=source_dir)

        # No files should have been written to write_dir
        assert list(write_dir.iterdir()) == []

    @pytest.mark.asyncio
    async def test_write_other_files_writes_when_no_source_dir(self, tmp_path):
        """When source_dir is None, write_other_files should write files."""
        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)

        # Create a payload with some other_files
        test_data = b"test content"
        encoded_data = b64encode(test_data).decode("utf-8")
        payload = make_payload(
            "",
            kind="speaker",
            format_="html",
            other_files={"data.txt": encoded_data},
        )

        # Create temp directory to write to
        write_dir = tmp_path / "write"
        write_dir.mkdir()

        # Call write_other_files without source_dir
        await processor.write_other_files("test-cid", write_dir, payload, source_dir=None)

        # File should have been written
        written_file = write_dir / "data.txt"
        assert written_file.exists()
        assert written_file.read_bytes() == test_data

    @pytest.mark.asyncio
    async def test_process_notebook_accepts_source_dir_parameter(self):
        """process_notebook should accept source_dir parameter."""
        from pathlib import Path

        notebook = make_notebook_node([make_cell("markdown", "# Test")])

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload(
            make_notebook_json([{"cell_type": "markdown", "source": "# Test"}]),
            format_="notebook",
        )

        # Should be able to call with source_dir parameter
        # (notebook format doesn't use write_other_files, so this should work)
        result = await processor.process_notebook(payload, source_dir=Path("/tmp/source"))
        assert result  # Should return something

    def test_payload_source_topic_dir_field(self):
        """NotebookPayload should have source_topic_dir field."""
        payload = make_payload(
            "",
            kind="speaker",
            format_="html",
        )

        # source_topic_dir should exist and default to empty string
        assert hasattr(payload, "source_topic_dir")
        assert payload.source_topic_dir == ""

        # Should be able to set it
        payload_with_source = NotebookPayload(
            data="",
            input_file="/test/notebook.ipynb",
            input_file_name="notebook.ipynb",
            output_file="/output/notebook.html",
            kind="speaker",
            prog_lang="python",
            language="en",
            format="html",
            correlation_id="test-123",
            source_topic_dir="/home/user/courses/slides/topic1",
        )

        assert payload_with_source.source_topic_dir == "/home/user/courses/slides/topic1"

    @pytest.mark.asyncio
    async def test_write_other_files_handles_nested_files(self, tmp_path):
        """write_other_files should create nested directories when needed."""
        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)

        # Create a payload with nested other_files
        test_data = b"nested content"
        encoded_data = b64encode(test_data).decode("utf-8")
        payload = make_payload(
            "",
            kind="speaker",
            format_="html",
            other_files={"subdir/nested/data.txt": encoded_data},
        )

        write_dir = tmp_path / "write"
        write_dir.mkdir()

        # Call write_other_files without source_dir
        await processor.write_other_files("test-cid", write_dir, payload, source_dir=None)

        # Nested file should have been written with directories created
        written_file = write_dir / "subdir" / "nested" / "data.txt"
        assert written_file.exists()
        assert written_file.read_bytes() == test_data


# ============================================================================
# Metadata Stripping Tests — slide_id and for_slide
# ============================================================================


class TestMetadataStripping:
    """Test that slide_id and for_slide are stripped from output cells."""

    @pytest.mark.asyncio
    async def test_slide_id_stripped_from_completed_output(self):
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title", tags=["slide"]),
                make_cell("code", "x = 1"),
            ]
        )
        # Inject slide_id into cell metadata
        notebook.cells[0]["metadata"]["slide_id"] = "title-slide"
        notebook.cells[1]["metadata"]["slide_id"] = "code-cell"

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="completed", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        for cell in result["cells"]:
            assert "slide_id" not in cell["metadata"]

    @pytest.mark.asyncio
    async def test_for_slide_stripped_from_speaker_output(self):
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title", tags=["slide"]),
                make_cell("markdown", "Speaker notes here", tags=["voiceover"]),
            ]
        )
        notebook.cells[0]["metadata"]["slide_id"] = "title-slide"
        notebook.cells[1]["metadata"]["for_slide"] = "title-slide"

        spec = SpeakerOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="speaker", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        for cell in result["cells"]:
            assert "slide_id" not in cell["metadata"]
            assert "for_slide" not in cell["metadata"]

    @pytest.mark.asyncio
    async def test_slide_id_stripped_from_codealong_output(self):
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title", tags=["slide"]),
                make_cell("code", "x = 1", tags=["keep"]),
            ]
        )
        notebook.cells[0]["metadata"]["slide_id"] = "intro"
        notebook.cells[1]["metadata"]["slide_id"] = "code-1"

        spec = CodeAlongOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="code-along", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        for cell in result["cells"]:
            assert "slide_id" not in cell["metadata"]

    @pytest.mark.asyncio
    async def test_other_metadata_preserved(self):
        """Stripping slide_id/for_slide should not affect other metadata."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title", tags=["slide"]),
            ]
        )
        notebook.cells[0]["metadata"]["slide_id"] = "title"
        notebook.cells[0]["metadata"]["lang"] = "en"

        spec = SpeakerOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="speaker", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        cell = result["cells"][0]
        assert "slide_id" not in cell["metadata"]
        assert cell["metadata"].get("lang") == "en"

    @pytest.mark.asyncio
    async def test_cells_without_metadata_keys_unaffected(self):
        """Cells that don't have slide_id/for_slide should process normally."""
        notebook = make_notebook_node(
            [
                make_cell("markdown", "# Title", tags=["slide"]),
                make_cell("code", "x = 1"),
            ]
        )

        spec = CompletedOutput(format="notebook")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="completed", format_="notebook")

        result = await processor._process_notebook_node(notebook, payload)

        assert len(result["cells"]) == 2
        for cell in result["cells"]:
            assert "slide_id" not in cell["metadata"]
            assert "for_slide" not in cell["metadata"]


# ============================================================================
# skip_errors post-execution cleanup
# ============================================================================


def _error_output() -> dict:
    """An nbformat-shaped error output."""
    return {
        "output_type": "error",
        "ename": "RuntimeError",
        "evalue": "service down",
        "traceback": ["Traceback (most recent call last):", "RuntimeError: service down"],
    }


def _stream_output(text: str = "ok\n") -> dict:
    return {"output_type": "stream", "name": "stdout", "text": text}


class TestSkipErrorsPostExecutionCleanup:
    """``_clear_error_outputs`` strips error tracebacks and records warnings."""

    def test_clears_error_outputs_and_records_warning(self):
        cells = [
            make_cell("markdown", "# Title"),
            make_cell("code", "ok = 1"),
            make_cell("code", "raise RuntimeError('service down')"),
            make_cell("code", "use(ok)"),
        ]
        cells[1]["outputs"] = [_stream_output()]
        cells[1]["execution_count"] = 1
        cells[2]["outputs"] = [_error_output()]
        cells[2]["execution_count"] = 2
        cells[3]["outputs"] = [_error_output()]
        cells[3]["execution_count"] = 3
        notebook = make_notebook_node(cells)

        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="speaker", format_="html").model_copy(
            update={"skip_errors": True}
        )

        processor._clear_error_outputs(notebook, payload)

        # Unrelated cells are untouched.
        assert notebook["cells"][1]["outputs"] == [_stream_output()]
        assert notebook["cells"][1]["execution_count"] == 1

        # Error-bearing cells are cleared.
        for idx in (2, 3):
            assert notebook["cells"][idx]["outputs"] == []
            assert notebook["cells"][idx]["execution_count"] is None

        warnings = processor.get_warnings()
        assert len(warnings) == 1
        warning = warnings[0]
        assert warning.category == "skip_errors_cell_failed"
        assert warning.details["cell_indices"] == [2, 3]
        assert warning.severity == "low"

    def test_no_warning_when_no_errors_present(self):
        cells = [make_cell("code", "x = 1")]
        cells[0]["outputs"] = [_stream_output()]
        cells[0]["execution_count"] = 1
        notebook = make_notebook_node(cells)

        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="speaker", format_="html").model_copy(
            update={"skip_errors": True}
        )

        processor._clear_error_outputs(notebook, payload)

        assert notebook["cells"][0]["outputs"] == [_stream_output()]
        assert processor.get_warnings() == []

    def test_markdown_cells_are_ignored(self):
        notebook = make_notebook_node([make_cell("markdown", "# Title")])

        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)
        payload = make_payload("", kind="speaker", format_="html").model_copy(
            update={"skip_errors": True}
        )

        processor._clear_error_outputs(notebook, payload)

        assert processor.get_warnings() == []


# ============================================================================
# HTTP replay bootstrap injection/strip
# ============================================================================


class TestHttpReplayBootstrap:
    """Injecting and stripping the vcrpy bootstrap cell."""

    def test_inject_prepends_cell_with_marker_metadata(self):
        from clm.workers.notebook.notebook_processor import (
            _inject_http_replay_bootstrap,
        )

        nb = make_notebook_node([make_cell("code", "import requests; requests.get('http://x')")])

        _inject_http_replay_bootstrap(nb, "slides_test.http-cassette.yaml", "replay")

        assert len(nb["cells"]) == 2
        injected = nb["cells"][0]
        assert injected["cell_type"] == "code"
        assert injected["metadata"]["clm_injected"] == "http_replay"
        assert "del" in injected["metadata"]["tags"]
        assert "import vcr" in injected["source"]
        # record_mode maps replay -> vcrpy's "none"
        assert "'none'" in injected["source"]
        assert "slides_test.http-cassette.yaml" in injected["source"]

    def test_inject_uses_vcr_mode_mapping(self):
        from clm.workers.notebook.notebook_processor import (
            _inject_http_replay_bootstrap,
        )

        nb = make_notebook_node([make_cell("code", "pass")])
        _inject_http_replay_bootstrap(nb, "c.yaml", "refresh")

        # refresh maps to vcrpy's "all"
        assert "'all'" in nb["cells"][0]["source"]

    def test_strip_removes_only_marker_cells(self):
        from clm.workers.notebook.notebook_processor import (
            _inject_http_replay_bootstrap,
            _strip_injected_cells,
        )

        nb = make_notebook_node(
            [
                make_cell("markdown", "# Title"),
                make_cell("code", "x = 1"),
            ]
        )
        _inject_http_replay_bootstrap(nb, "c.yaml", "replay")
        assert len(nb["cells"]) == 3

        _strip_injected_cells(nb)

        assert len(nb["cells"]) == 2
        assert nb["cells"][0]["cell_type"] == "markdown"
        assert nb["cells"][1]["source"] == "x = 1"

    def test_strip_is_noop_when_no_injection(self):
        from clm.workers.notebook.notebook_processor import _strip_injected_cells

        nb = make_notebook_node([make_cell("code", "x = 1"), make_cell("markdown", "done")])
        original = [dict(c) for c in nb["cells"]]

        _strip_injected_cells(nb)

        assert len(nb["cells"]) == 2
        assert nb["cells"][0]["source"] == original[0]["source"]
        assert nb["cells"][1]["source"] == original[1]["source"]

    def test_maybe_inject_skips_without_mode(self):
        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)
        nb = make_notebook_node([make_cell("code", "x = 1")])
        payload = make_payload("", kind="speaker", format_="html")

        injected = processor._maybe_inject_http_replay(nb, payload)

        assert injected is False
        assert len(nb["cells"]) == 1

    def test_maybe_inject_skips_disabled_mode(self):
        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)
        nb = make_notebook_node([make_cell("code", "x = 1")])
        payload = make_payload("", kind="speaker", format_="html").model_copy(
            update={
                "http_replay_mode": "disabled",
                "http_replay_cassette_name": "c.yaml",
            }
        )

        injected = processor._maybe_inject_http_replay(nb, payload)

        assert injected is False
        assert len(nb["cells"]) == 1

    def test_maybe_inject_skips_without_cassette_name(self):
        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)
        nb = make_notebook_node([make_cell("code", "x = 1")])
        payload = make_payload("", kind="speaker", format_="html").model_copy(
            update={"http_replay_mode": "replay"}
        )

        injected = processor._maybe_inject_http_replay(nb, payload)

        assert injected is False
        assert len(nb["cells"]) == 1

    def test_maybe_inject_injects_when_mode_and_cassette_set(self):
        spec = SpeakerOutput(format="html")
        processor = NotebookProcessor(spec)
        nb = make_notebook_node([make_cell("code", "x = 1")])
        payload = make_payload("", kind="speaker", format_="html").model_copy(
            update={
                "http_replay_mode": "once",
                "http_replay_cassette_name": "_cassettes/slides.http-cassette.yaml",
            }
        )

        injected = processor._maybe_inject_http_replay(nb, payload)

        assert injected is True
        assert len(nb["cells"]) == 2
        assert nb["cells"][0]["metadata"]["clm_injected"] == "http_replay"
        assert "_cassettes/slides.http-cassette.yaml" in nb["cells"][0]["source"]
