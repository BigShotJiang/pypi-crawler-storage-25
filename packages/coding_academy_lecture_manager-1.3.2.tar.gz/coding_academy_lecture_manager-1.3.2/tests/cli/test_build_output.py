"""Tests for build output formatting and reporting components."""

import json
from datetime import datetime

import pytest

from clm.cli.build_data_classes import BuildError, BuildSummary, BuildWarning
from clm.cli.build_reporter import BuildReporter
from clm.cli.error_categorizer import ErrorCategorizer
from clm.cli.output_formatter import (
    DefaultOutputFormatter,
    JSONOutputFormatter,
    QuietOutputFormatter,
    VerboseOutputFormatter,
)


class TestBuildDataClasses:
    """Test data classes for build reporting."""

    def test_build_error_creation(self):
        """Test creating a build error."""
        error = BuildError(
            error_type="user",
            category="notebook_compilation",
            severity="error",
            file_path="test.py",
            message="SyntaxError",
            actionable_guidance="Fix the syntax error",
        )
        assert error.error_type == "user"
        assert error.category == "notebook_compilation"
        assert error.severity == "error"
        assert str(error)  # Should have string representation

    def test_build_warning_creation(self):
        """Test creating a build warning."""
        warning = BuildWarning(
            category="duplicate_topic_id",
            message="Duplicate ID found",
            severity="high",
        )
        assert warning.category == "duplicate_topic_id"
        assert warning.severity == "high"
        assert str(warning)  # Should have string representation

    def test_build_summary_creation(self):
        """Test creating a build summary."""
        summary = BuildSummary(
            duration=120.5,
            total_files=100,
        )
        assert summary.duration == 120.5
        assert summary.total_files == 100
        assert summary.successful_files == 100
        assert not summary.has_errors()
        assert not summary.has_fatal_errors()

    def test_build_summary_with_errors(self):
        """Test build summary with errors."""
        error = BuildError(
            error_type="user",
            category="notebook_compilation",
            severity="error",
            file_path="test.py",
            message="Error",
            actionable_guidance="Fix it",
        )
        summary = BuildSummary(
            duration=120.5,
            total_files=100,
            errors=[error],
        )
        assert summary.has_errors()
        assert summary.failed_files == 1
        assert summary.successful_files == 99


class TestErrorCategorizer:
    """Test error categorization logic."""

    def test_categorize_notebook_syntax_error(self):
        """Test categorizing notebook syntax error as user error."""
        error = ErrorCategorizer.categorize_job_error(
            job_type="notebook",
            input_file="test.py",
            error_message="SyntaxError: invalid syntax",
            job_payload={},
        )
        assert error.error_type == "user"
        assert error.category == "notebook_compilation"
        assert error.severity == "error"

    def test_categorize_plantuml_missing_jar(self):
        """Test categorizing missing PlantUML JAR as configuration error."""
        error = ErrorCategorizer.categorize_job_error(
            job_type="plantuml",
            input_file="diagram.puml",
            error_message="PLANTUML_JAR environment variable not set",
            job_payload={},
        )
        assert error.error_type == "configuration"
        assert error.category == "missing_plantuml"
        assert error.severity == "error"

    def test_categorize_drawio_missing_executable(self):
        """Test categorizing missing DrawIO executable as configuration error."""
        error = ErrorCategorizer.categorize_job_error(
            job_type="drawio",
            input_file="diagram.drawio",
            error_message="DrawIO executable not found",
            job_payload={},
        )
        assert error.error_type == "configuration"
        assert error.category == "missing_drawio"
        assert error.severity == "error"

    def test_categorize_no_workers_error(self):
        """Test categorizing no workers error as infrastructure error."""
        error = ErrorCategorizer.categorize_no_workers_error("notebook")
        assert error.error_type == "infrastructure"
        assert error.category == "no_workers"
        assert error.severity == "fatal"


class TestOutputFormatter:
    """Test output formatting."""

    def test_default_formatter_creation(self):
        """Test creating default output formatter."""
        formatter = DefaultOutputFormatter(show_progress=True, use_color=True)
        assert formatter.show_progress is True
        assert formatter.use_color is True

    def test_quiet_formatter_creation(self):
        """Test creating quiet output formatter."""
        formatter = QuietOutputFormatter()
        assert formatter is not None

    def test_formatter_error_display_logic(self):
        """Test error display logic in formatters."""
        default_formatter = DefaultOutputFormatter()
        quiet_formatter = QuietOutputFormatter()

        error = BuildError(
            error_type="user",
            category="test",
            severity="error",
            file_path="test.py",
            message="Test error",
            actionable_guidance="Fix it",
        )

        # Default formatter should show errors
        assert default_formatter.should_show_error(error)

        # Quiet formatter should show errors
        assert quiet_formatter.should_show_error(error)


class TestBuildReporter:
    """Test build reporter."""

    def test_build_reporter_creation(self):
        """Test creating build reporter."""
        formatter = QuietOutputFormatter()
        reporter = BuildReporter(output_formatter=formatter)
        assert reporter is not None
        assert reporter.errors == []
        assert reporter.warnings == []

    def test_build_reporter_error_collection(self):
        """Test error collection in build reporter."""
        formatter = QuietOutputFormatter()
        reporter = BuildReporter(output_formatter=formatter)

        error = BuildError(
            error_type="user",
            category="test",
            severity="error",
            file_path="test.py",
            message="Test error",
            actionable_guidance="Fix it",
        )

        reporter.report_error(error)
        assert len(reporter.errors) == 1
        assert reporter.errors[0] == error

    def test_build_reporter_warning_collection(self):
        """Test warning collection in build reporter."""
        formatter = QuietOutputFormatter()
        reporter = BuildReporter(output_formatter=formatter)

        warning = BuildWarning(
            category="test",
            message="Test warning",
            severity="high",
        )

        reporter.report_warning(warning)
        assert len(reporter.warnings) == 1
        assert reporter.warnings[0] == warning


class TestEnhancedErrorParsing:
    """Test enhanced error parsing capabilities."""

    def test_parse_notebook_error_with_cell_number(self):
        """Test parsing cell number from error message."""
        error_msg = "SyntaxError in cell #5: invalid syntax"
        traceback_msg = "  File 'test.ipynb', line 2"

        details = ErrorCategorizer._parse_notebook_error(error_msg, traceback_msg)

        assert details.get("cell_number") == 5
        assert details.get("error_class") == "SyntaxError"

    def test_parse_notebook_error_with_line_number(self):
        """Test parsing line number from error message."""
        error_msg = "NameError at line 3: name 'x' is not defined"

        details = ErrorCategorizer._parse_notebook_error(error_msg)

        assert details.get("line_number") == 3
        assert details.get("error_class") == "NameError"

    def test_parse_notebook_error_with_code_snippet(self):
        """Test extracting code snippet from traceback."""
        error_msg = "SyntaxError: invalid syntax"
        traceback_msg = """
  File "test.ipynb", line 2
    1: x = 1
    2: y =
    3: z = 3
SyntaxError: invalid syntax
"""

        details = ErrorCategorizer._parse_notebook_error(error_msg, traceback_msg)

        assert "code_snippet" in details
        assert "x = 1" in details["code_snippet"]
        assert "y =" in details["code_snippet"]

    def test_parse_notebook_error_extracts_file_path(self):
        """Test extracting source file path from error."""
        error_msg = "Error occurred"
        traceback_msg = 'File "/path/to/notebook.ipynb", line 5'

        details = ErrorCategorizer._parse_notebook_error(error_msg, traceback_msg)

        assert details.get("source_file") == "/path/to/notebook.ipynb"

    def test_parse_notebook_error_extracts_short_message(self):
        """Test extracting short error message."""
        error_msg = "ValueError: invalid literal for int() with base 10: 'abc'"

        details = ErrorCategorizer._parse_notebook_error(error_msg)

        assert details.get("error_class") == "ValueError"
        assert "short_message" in details
        assert "invalid literal" in details["short_message"]

    def test_categorize_notebook_with_parsed_details(self):
        """Test that categorized errors include parsed details."""
        error_msg = "NameError in cell #3: name 'undefined_var' is not defined"

        error = ErrorCategorizer.categorize_job_error(
            job_type="notebook",
            input_file="test.ipynb",
            error_message=error_msg,
            job_payload={},
        )

        assert error.error_type == "user"
        assert error.details.get("cell_number") == 3
        assert error.details.get("error_class") == "NameError"

    def test_parse_cpp_xeus_cling_error(self):
        """Test parsing C++ xeus-cling compiler error."""
        error_msg = """An error occurred while executing the following code:
class BrokenClass {
public:
    void DoNothing() {}
}

input_line_8:5:2: error: expected ';' after class
}
 ^
 ;
"""

        details = ErrorCategorizer._parse_notebook_error(error_msg)

        assert details.get("error_class") == "CompilationError"
        assert details.get("line_number") == 5
        assert details.get("column_number") == 2
        assert "expected ';' after class" in details.get("short_message", "")

    def test_parse_cpp_clang_style_error(self):
        """Test parsing generic clang-style compiler error."""
        error_msg = """Compilation error:
test.cpp:10:5: error: use of undeclared identifier 'foo'
    foo();
    ^
"""

        details = ErrorCategorizer._parse_notebook_error(error_msg)

        assert details.get("error_class") == "CompilationError"
        assert details.get("line_number") == 10
        assert details.get("column_number") == 5
        assert "use of undeclared identifier" in details.get("short_message", "")

    def test_parse_cell_content_from_enhanced_error(self):
        """Test parsing cell content from enhanced notebook error."""
        error_msg = """Notebook execution failed: test.cpp
  Cell: #3
  Cell content:
    class BrokenClass {
    public:
        void DoNothing() {}
    }
  Error: CompilationError: expected ';' after class
  Line: 5, Column: 2
"""

        details = ErrorCategorizer._parse_notebook_error(error_msg)

        assert details.get("cell_number") == 3
        assert "code_snippet" in details
        assert "BrokenClass" in details.get("code_snippet", "")

    def test_parse_error_with_colon_cell_format(self):
        """Test parsing cell number from 'Cell: #N' format."""
        error_msg = "Cell: #7\nError: SyntaxError"

        details = ErrorCategorizer._parse_notebook_error(error_msg)

        assert details.get("cell_number") == 7

    def test_categorize_cpp_compilation_error(self):
        """Test that C++ compilation errors are categorized correctly."""
        error_msg = """Notebook execution failed: observer.cpp
  Cell: #5
  Cell content:
    class StockObserver {
    public:
        virtual ~StockObserver() = default;
    }
  Error: CompilationError: expected ';' after class
input_line_8:5:2: error: expected ';' after class
"""

        error = ErrorCategorizer.categorize_job_error(
            job_type="notebook",
            input_file="observer.cpp",
            error_message=error_msg,
            job_payload={},
        )

        assert error.error_type == "user"
        assert error.details.get("cell_number") == 5
        assert error.details.get("error_class") == "CompilationError"
        assert "expected ';' after class" in error.details.get("short_message", "")

    def test_no_verbose_in_default_guidance(self):
        """Test that the guidance doesn't suggest --verbose (it's not a valid flag)."""
        error_msg = "Some unknown error"

        error = ErrorCategorizer.categorize_job_error(
            job_type="notebook",
            input_file="test.ipynb",
            error_message=error_msg,
            job_payload={},
        )

        # Should not contain the old misleading message
        assert "--verbose" not in error.actionable_guidance
        # Should contain helpful cell-specific guidance
        assert "Check your notebook" in error.actionable_guidance

    def test_does_not_extract_python_traceback_as_code(self):
        """Test that Python traceback lines are not extracted as code context."""
        # This simulates an error where there's no Cell content section
        # but there is a Python traceback with caret markers
        error_msg = """Notebook execution failed: slides_static_strategy.cpp
  Error: CompilationError: expected ';' after top level declarator
           ^^^^^^^^^^^^^^^
result = await processor.process_notebook(payload, source_dir=source_dir)
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
result = await self.create_contents(processed_nb, payload, source_dir=source_dir)
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
result = await self._create_using_nbconvert(
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
await self._execute_notebook_with_path(
await loop.run_in_executor(None, run_preprocess)
result = self.fn(*self.args, **self.kwargs)
"""

        details = ErrorCategorizer._parse_notebook_error(error_msg)

        # Should NOT have extracted Python traceback as code snippet
        code_snippet = details.get("code_snippet", "")
        assert "await processor" not in code_snippet
        assert "await self.create_contents" not in code_snippet
        assert "result = " not in code_snippet

    def test_extracts_cell_content_over_traceback(self):
        """Test that Cell content section is preferred over traceback patterns."""
        error_msg = """Notebook execution failed: test.cpp
  Cell: #5
  Cell content:
    class BrokenClass {
    public:
        void DoNothing() {}
    }
  Error: CompilationError: expected ';' after class
           ^^^^^^^^^^^^^^^
result = await processor.process_notebook(payload)
"""

        details = ErrorCategorizer._parse_notebook_error(error_msg)

        # Should have extracted the cell content, not the traceback
        code_snippet = details.get("code_snippet", "")
        assert "BrokenClass" in code_snippet
        assert "await processor" not in code_snippet


class TestJSONOutputFormatter:
    """Test JSON output formatter for CI/CD integration."""

    def test_json_formatter_creation(self):
        """Test creating JSON output formatter."""
        formatter = JSONOutputFormatter()
        assert formatter is not None
        assert formatter.output_data["status"] == "in_progress"
        assert formatter.output_data["errors"] == []
        assert formatter.output_data["warnings"] == []

    def test_json_formatter_build_start(self):
        """Test recording build start in JSON formatter."""
        formatter = JSONOutputFormatter()
        formatter.show_build_start("Test Course", 10)

        assert formatter.output_data["course_name"] == "Test Course"
        assert formatter.output_data["total_files"] == 10

    def test_json_formatter_stage_tracking(self):
        """Test stage tracking in JSON formatter."""
        formatter = JSONOutputFormatter()
        formatter.show_stage_start("Notebooks", 1, 3, 5)

        assert len(formatter.output_data["stages"]) == 1
        stage = formatter.output_data["stages"][0]
        assert stage["name"] == "Notebooks"
        assert stage["stage_num"] == 1
        assert stage["total_stages"] == 3
        assert stage["num_jobs"] == 5

    def test_json_formatter_never_shows_errors_immediately(self):
        """Test that JSON formatter never shows errors immediately."""
        formatter = JSONOutputFormatter()
        error = BuildError(
            error_type="user",
            category="test",
            severity="error",
            file_path="test.py",
            message="Test error",
            actionable_guidance="Fix it",
        )

        assert not formatter.should_show_error(error)

    def test_json_formatter_never_shows_warnings_immediately(self):
        """Test that JSON formatter never shows warnings immediately."""
        formatter = JSONOutputFormatter()
        warning = BuildWarning(
            category="test",
            message="Test warning",
            severity="high",
        )

        assert not formatter.should_show_warning(warning)

    def test_json_formatter_summary_with_success(self, capsys):
        """Test JSON output with successful build."""
        formatter = JSONOutputFormatter()
        formatter.show_build_start("Test Course", 10)

        summary = BuildSummary(
            duration=120.5,
            total_files=10,
            errors=[],
            warnings=[],
            start_time=datetime(2025, 1, 1, 12, 0, 0),
            end_time=datetime(2025, 1, 1, 12, 2, 0),
        )

        formatter.show_summary(summary)

        # Capture stdout output
        captured = capsys.readouterr()
        output_data = json.loads(captured.out)

        assert output_data["status"] == "success"
        assert output_data["duration_seconds"] == 120.5
        assert output_data["files_processed"] == 10
        assert output_data["files_succeeded"] == 10
        assert output_data["files_failed"] == 0
        assert output_data["error_count"] == 0
        assert output_data["warning_count"] == 0
        assert output_data["start_time"] == "2025-01-01T12:00:00"
        assert output_data["end_time"] == "2025-01-01T12:02:00"

    def test_json_formatter_summary_with_errors(self, capsys):
        """Test JSON output with build errors."""
        formatter = JSONOutputFormatter()
        formatter.show_build_start("Test Course", 10)

        error = BuildError(
            error_type="user",
            category="notebook_compilation",
            severity="error",
            file_path="test.py",
            message="SyntaxError: invalid syntax",
            actionable_guidance="Fix the syntax error",
            job_id=123,
            correlation_id="abc-123",
            details={"cell_number": 5},
        )

        summary = BuildSummary(
            duration=120.5,
            total_files=10,
            errors=[error],
            warnings=[],
        )

        formatter.show_summary(summary)

        # Capture stdout output
        captured = capsys.readouterr()
        output_data = json.loads(captured.out)

        assert output_data["status"] == "failed"
        assert output_data["error_count"] == 1
        assert len(output_data["errors"]) == 1

        error_dict = output_data["errors"][0]
        assert error_dict["error_type"] == "user"
        assert error_dict["category"] == "notebook_compilation"
        assert error_dict["severity"] == "error"
        assert error_dict["file_path"] == "test.py"
        assert error_dict["message"] == "SyntaxError: invalid syntax"
        assert error_dict["actionable_guidance"] == "Fix the syntax error"
        assert error_dict["job_id"] == 123
        assert error_dict["correlation_id"] == "abc-123"
        assert error_dict["details"]["cell_number"] == 5

    def test_json_formatter_summary_with_fatal_errors(self, capsys):
        """Test JSON output with fatal errors."""
        formatter = JSONOutputFormatter()

        fatal_error = BuildError(
            error_type="infrastructure",
            category="no_workers",
            severity="fatal",
            file_path="",
            message="No workers available",
            actionable_guidance="Start workers",
        )

        summary = BuildSummary(
            duration=10.0,
            total_files=10,
            errors=[fatal_error],
            warnings=[],
        )

        formatter.show_summary(summary)

        # Capture stdout output
        captured = capsys.readouterr()
        output_data = json.loads(captured.out)

        assert output_data["status"] == "fatal"
        assert output_data["error_count"] == 1

    def test_json_formatter_summary_with_warnings(self, capsys):
        """Test JSON output with warnings."""
        formatter = JSONOutputFormatter()

        warning = BuildWarning(
            category="duplicate_topic_id",
            message="Duplicate ID found",
            severity="high",
            file_path="test.py",
        )

        summary = BuildSummary(
            duration=120.5,
            total_files=10,
            errors=[],
            warnings=[warning],
        )

        formatter.show_summary(summary)

        # Capture stdout output
        captured = capsys.readouterr()
        output_data = json.loads(captured.out)

        assert output_data["status"] == "success"
        assert output_data["warning_count"] == 1
        assert len(output_data["warnings"]) == 1

        warning_dict = output_data["warnings"][0]
        assert warning_dict["category"] == "duplicate_topic_id"
        assert warning_dict["message"] == "Duplicate ID found"
        assert warning_dict["severity"] == "high"
        assert warning_dict["file_path"] == "test.py"


class TestCIDetection:
    """Test CI environment detection."""

    def test_ci_detection_github_actions(self, monkeypatch):
        """Test detection of GitHub Actions CI environment."""
        from clm.cli.main import _is_ci_environment

        monkeypatch.setenv("GITHUB_ACTIONS", "true")
        assert _is_ci_environment() is True

    def test_ci_detection_gitlab_ci(self, monkeypatch):
        """Test detection of GitLab CI environment."""
        from clm.cli.main import _is_ci_environment

        monkeypatch.setenv("GITLAB_CI", "true")
        assert _is_ci_environment() is True

    def test_ci_detection_generic_ci(self, monkeypatch):
        """Test detection of generic CI environment."""
        from clm.cli.main import _is_ci_environment

        monkeypatch.setenv("CI", "true")
        assert _is_ci_environment() is True

    def test_ci_detection_no_ci(self, monkeypatch):
        """Test no CI environment detected."""
        from clm.cli.main import _is_ci_environment

        # Clear all CI environment variables
        for var in [
            "CI",
            "GITHUB_ACTIONS",
            "GITLAB_CI",
            "JENKINS_HOME",
            "CIRCLECI",
            "TRAVIS",
            "BUILDKITE",
            "DRONE",
        ]:
            monkeypatch.delenv(var, raising=False)

        assert _is_ci_environment() is False


class TestVerboseOutputFormatter:
    """Test verbose output formatter for detailed error reporting."""

    def test_verbose_formatter_creation(self):
        """Test creating verbose output formatter."""
        formatter = VerboseOutputFormatter(show_progress=True, use_color=True)
        assert formatter is not None
        assert formatter.show_progress is True
        assert formatter.use_color is True
        assert formatter._files_started == {}
        assert formatter._files_completed == 0
        assert formatter._files_failed == 0

    def test_verbose_formatter_always_shows_errors(self):
        """Test that verbose formatter always shows errors regardless of severity."""
        formatter = VerboseOutputFormatter()

        # Test error with severity "error"
        error = BuildError(
            error_type="user",
            category="test",
            severity="error",
            file_path="test.py",
            message="Test error",
            actionable_guidance="Fix it",
        )
        assert formatter.should_show_error(error) is True

        # Test error with severity "warning" - verbose should still show it
        warning_error = BuildError(
            error_type="user",
            category="test",
            severity="warning",
            file_path="test.py",
            message="Warning error",
            actionable_guidance="Fix it",
        )
        assert formatter.should_show_error(warning_error) is True

    def test_verbose_formatter_always_shows_warnings(self):
        """Test that verbose formatter always shows warnings regardless of severity."""
        formatter = VerboseOutputFormatter()

        # Test warning with severity "high"
        high_warning = BuildWarning(
            category="test",
            message="High warning",
            severity="high",
        )
        assert formatter.should_show_warning(high_warning) is True

        # Test warning with severity "low" - verbose should still show it
        low_warning = BuildWarning(
            category="test",
            message="Low warning",
            severity="low",
        )
        assert formatter.should_show_warning(low_warning) is True

        # Test warning with severity "medium"
        medium_warning = BuildWarning(
            category="test",
            message="Medium warning",
            severity="medium",
        )
        assert formatter.should_show_warning(medium_warning) is True

    def test_verbose_formatter_vs_default_error_display(self):
        """Test verbose shows all errors vs default which filters by severity."""
        verbose = VerboseOutputFormatter()
        default = DefaultOutputFormatter()

        # Low severity warning error - default should NOT show, verbose should
        warning_error = BuildError(
            error_type="user",
            category="test",
            severity="warning",
            file_path="test.py",
            message="Warning",
            actionable_guidance="Fix it",
        )

        assert verbose.should_show_error(warning_error) is True
        assert default.should_show_error(warning_error) is False

    def test_verbose_formatter_vs_default_warning_display(self):
        """Test verbose shows all warnings vs default which filters by severity."""
        verbose = VerboseOutputFormatter()
        default = DefaultOutputFormatter()

        # Low priority warning - default should NOT show, verbose should
        low_warning = BuildWarning(
            category="test",
            message="Low warning",
            severity="low",
        )

        assert verbose.should_show_warning(low_warning) is True
        assert default.should_show_warning(low_warning) is False

    def test_verbose_formatter_file_started(self):
        """Test verbose formatter tracks file processing start."""
        formatter = VerboseOutputFormatter()

        # Call show_file_started
        formatter.show_file_started("test.ipynb", "notebook", job_id=123)

        # Check that the file is being tracked
        assert "test.ipynb" in formatter._files_started

    def test_verbose_formatter_file_completed_success(self):
        """Test verbose formatter tracks file processing completion (success)."""
        formatter = VerboseOutputFormatter()

        # First start the file
        formatter.show_file_started("test.ipynb", "notebook", job_id=123)

        # Then complete it successfully
        formatter.show_file_completed("test.ipynb", "notebook", job_id=123, success=True)

        # Check that tracking was updated
        assert "test.ipynb" not in formatter._files_started
        assert formatter._files_completed == 1
        assert formatter._files_failed == 0

    def test_verbose_formatter_file_completed_failure(self):
        """Test verbose formatter tracks file processing completion (failure)."""
        formatter = VerboseOutputFormatter()

        # First start the file
        formatter.show_file_started("test.ipynb", "notebook", job_id=123)

        # Then mark it as failed
        formatter.show_file_completed("test.ipynb", "notebook", job_id=123, success=False)

        # Check that tracking was updated
        assert "test.ipynb" not in formatter._files_started
        assert formatter._files_completed == 0
        assert formatter._files_failed == 1

    def test_verbose_summary_shows_all_errors(self, capsys):
        """Test verbose summary shows all errors, not just first 5."""
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)

        # Create 10 errors
        errors = []
        for i in range(10):
            errors.append(
                BuildError(
                    error_type="user",
                    category="test",
                    severity="error",
                    file_path=f"test{i}.py",
                    message=f"Error {i}",
                    actionable_guidance=f"Fix {i}",
                )
            )

        summary = BuildSummary(
            duration=10.0,
            total_files=10,
            errors=errors,
            warnings=[],
        )

        formatter.show_summary(summary)

        captured = capsys.readouterr()
        # Check that all 10 errors are mentioned (not just first 5)
        for i in range(10):
            assert f"test{i}.py" in captured.err, f"Error {i} should appear in verbose output"

        # Should NOT contain "... and X more errors"
        assert "more errors" not in captured.err

    def test_verbose_summary_shows_all_warnings(self, capsys):
        """Test verbose summary shows all warnings, not just first 3."""
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)

        # Create 7 warnings
        warnings = []
        for i in range(7):
            warnings.append(
                BuildWarning(
                    category="test",
                    message=f"Warning {i}",
                    severity="high",
                    file_path=f"test{i}.py",
                )
            )

        summary = BuildSummary(
            duration=10.0,
            total_files=10,
            errors=[],
            warnings=warnings,
        )

        formatter.show_summary(summary)

        captured = capsys.readouterr()
        # Check that all 7 warnings are mentioned (not just first 3)
        for i in range(7):
            assert f"Warning {i}" in captured.err, f"Warning {i} should appear in verbose output"

        # Should NOT contain "... and X more warnings"
        assert "more warnings" not in captured.err


class TestDefaultOutputFormatterProgressBar:
    """Test DefaultOutputFormatter progress bar behavior.

    These tests verify the fix for the IndexError that occurred when
    update_progress was called after task removal or progress bar stop.
    The issue was that TaskID was incorrectly used as a list index into
    self.progress.tasks, which fails after remove_task() is called.
    """

    def test_update_progress_finds_task_by_id_not_index(self):
        """Test that update_progress correctly finds task by ID, not list index.

        This is the core regression test for the IndexError fix.
        When tasks are removed, using TaskID as a list index fails.
        """
        formatter = DefaultOutputFormatter(show_progress=True, use_color=False)

        # Start the build (initializes progress bar)
        formatter.show_build_start("Test Course", 100)

        # Start first stage - creates task with ID 0
        formatter.show_stage_start("Stage 1", 1, 3, 50)
        first_task_id = formatter.current_task

        # Update progress for first stage - should work
        formatter.update_progress(completed=25, total=50, cached=5)

        # Start second stage - this removes task 0 and creates task with ID 1
        formatter.show_stage_start("Stage 2", 2, 3, 30)
        second_task_id = formatter.current_task

        # The tasks list now has only 1 element at index 0,
        # but the current_task ID is 1
        assert second_task_id != first_task_id

        # This update would fail with IndexError if we used TaskID as list index
        # because tasks[1] doesn't exist - only tasks[0] does
        formatter.update_progress(completed=15, total=30, cached=10)

        # Clean up
        formatter.cleanup()

    def test_update_progress_handles_multiple_stage_transitions(self):
        """Test progress updates across many stage transitions."""
        formatter = DefaultOutputFormatter(show_progress=True, use_color=False)

        formatter.show_build_start("Test Course", 100)

        # Simulate multiple stage transitions
        for stage_num in range(1, 6):  # 5 stages
            formatter.show_stage_start(f"Stage {stage_num}", stage_num, 5, 20)

            # Multiple progress updates per stage
            for completed in range(0, 21, 5):
                formatter.update_progress(completed=completed, total=20, cached=2)

        # All updates should complete without IndexError
        formatter.cleanup()

    def test_update_progress_after_progress_bar_stopped(self):
        """Test that update_progress safely handles stopped progress bar."""
        formatter = DefaultOutputFormatter(show_progress=True, use_color=False)

        formatter.show_build_start("Test Course", 100)
        formatter.show_stage_start("Stage 1", 1, 1, 50)

        # Stop the progress bar (simulates what happens in show_summary)
        assert formatter.progress is not None
        formatter.progress.stop()
        formatter._is_started = False

        # This should not raise an error - it should be a no-op
        formatter.update_progress(completed=25, total=50, cached=5)

    def test_update_progress_with_no_current_task(self):
        """Test that update_progress safely handles None current_task."""
        formatter = DefaultOutputFormatter(show_progress=True, use_color=False)

        formatter.show_build_start("Test Course", 100)

        # Don't start a stage, so current_task is None
        assert formatter.current_task is None

        # This should not raise an error - it should be a no-op
        formatter.update_progress(completed=25, total=50, cached=5)

        formatter.cleanup()

    def test_update_progress_with_progress_disabled(self):
        """Test that update_progress works when show_progress is False."""
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)

        formatter.show_build_start("Test Course", 100)
        formatter.show_stage_start("Stage 1", 1, 1, 50)

        # Progress bar is not created when show_progress=False
        assert formatter.progress is None

        # This should not raise an error - it should be a no-op
        formatter.update_progress(completed=25, total=50, cached=5)

    def test_update_progress_cached_description_update(self):
        """Test that cached count is correctly shown in task description."""
        formatter = DefaultOutputFormatter(show_progress=True, use_color=False)

        formatter.show_build_start("Test Course", 100)
        formatter.show_stage_start("Stage 1", 1, 2, 50)

        # Update with cached items
        formatter.update_progress(completed=25, total=50, cached=10)

        # Find the task and check its description includes cached count
        assert formatter.progress is not None
        task_found = False
        for task in formatter.progress.tasks:
            if task.id == formatter.current_task:
                task_found = True
                assert "cached" in task.description.lower()
                break

        assert task_found, "Current task should be found in progress.tasks"

        formatter.cleanup()

    def test_update_progress_zero_cached_no_description_change(self):
        """Test that description is not modified when cached=0."""
        formatter = DefaultOutputFormatter(show_progress=True, use_color=False)

        formatter.show_build_start("Test Course", 100)
        formatter.show_stage_start("Stage 1", 1, 2, 50)

        assert formatter.progress is not None
        original_description = None
        for task in formatter.progress.tasks:
            if task.id == formatter.current_task:
                original_description = task.description
                break

        # Update without cached items
        formatter.update_progress(completed=25, total=50, cached=0)

        # Description should not have changed
        for task in formatter.progress.tasks:
            if task.id == formatter.current_task:
                assert task.description == original_description
                break

        formatter.cleanup()


class TestBuildReporterProgressIntegration:
    """Test BuildReporter integration with progress updates.

    These tests verify that the BuildReporter correctly interacts with
    the OutputFormatter for progress updates, especially during cache hits.
    """

    def test_report_cache_hit_updates_progress(self):
        """Test that cache hits trigger progress updates without errors."""
        formatter = DefaultOutputFormatter(show_progress=True, use_color=False)
        reporter = BuildReporter(output_formatter=formatter)

        reporter.start_build("Test Course", 100, total_stages=2)
        reporter.start_stage("Stage 1", num_jobs=50, num_cached=20)

        # Simulate cache hits - these call update_progress internally
        for _ in range(5):
            reporter.report_cache_hit("test.ipynb", "notebook")

        # Progress should reflect cached count
        assert reporter._stage_cached_count == 25  # 20 initial + 5 reported

        formatter.cleanup()

    def test_report_cache_hit_after_stage_transition(self):
        """Test cache hits work correctly after stage transition."""
        formatter = DefaultOutputFormatter(show_progress=True, use_color=False)
        reporter = BuildReporter(output_formatter=formatter)

        reporter.start_build("Test Course", 100, total_stages=3)

        # First stage
        reporter.start_stage("Stage 1", num_jobs=30)
        reporter.report_cache_hit("file1.ipynb", "notebook")

        # Second stage - this causes task removal and new task creation
        reporter.start_stage("Stage 2", num_jobs=40)
        # This cache hit would cause IndexError with the old buggy code
        reporter.report_cache_hit("file2.ipynb", "notebook")

        # Third stage
        reporter.start_stage("Stage 3", num_jobs=30)
        reporter.report_cache_hit("file3.ipynb", "notebook")

        # All cache hits should work without errors
        formatter.cleanup()

    def test_on_progress_update_after_multiple_stages(self):
        """Test on_progress_update callback works across multiple stages."""
        from clm.cli.build_data_classes import ProgressUpdate

        formatter = DefaultOutputFormatter(show_progress=True, use_color=False)
        reporter = BuildReporter(output_formatter=formatter)

        reporter.start_build("Test Course", 100, total_stages=3)

        # Simulate progress updates across stages
        for stage_num in range(1, 4):
            reporter.start_stage(f"Stage {stage_num}", num_jobs=30)

            # Simulate progress updates from ProgressTracker
            for i in range(10):
                update = ProgressUpdate(
                    completed=(stage_num - 1) * 30 + i,
                    total=90,
                    active=2,
                    failed=0,
                )
                reporter.on_progress_update(update)

        formatter.cleanup()


class TestBuildReporterFileEvents:
    """Test build reporter file event methods."""

    def test_build_reporter_file_started(self):
        """Test build reporter forwards file started events to formatter."""
        formatter = VerboseOutputFormatter()
        reporter = BuildReporter(output_formatter=formatter)

        reporter.report_file_started("test.ipynb", "notebook", job_id=123)

        # Check that the formatter received the event
        assert "test.ipynb" in formatter._files_started

    def test_build_reporter_file_completed(self):
        """Test build reporter forwards file completed events to formatter."""
        formatter = VerboseOutputFormatter()
        reporter = BuildReporter(output_formatter=formatter)

        # Start and complete a file
        reporter.report_file_started("test.ipynb", "notebook", job_id=123)
        reporter.report_file_completed("test.ipynb", "notebook", job_id=123, success=True)

        # Check that the formatter received the events
        assert "test.ipynb" not in formatter._files_started
        assert formatter._files_completed == 1

    def test_default_formatter_ignores_file_events(self):
        """Test that default formatter no-ops on file events."""
        formatter = DefaultOutputFormatter()
        reporter = BuildReporter(output_formatter=formatter)

        # These should not raise errors even though DefaultOutputFormatter
        # doesn't track file events
        reporter.report_file_started("test.ipynb", "notebook", job_id=123)
        reporter.report_file_completed("test.ipynb", "notebook", job_id=123, success=True)


# ---------------------------------------------------------------------------
# PR 2: additional coverage for verbose formatter detail paths, default
# summary rendering, quiet + JSON formatters.
# ---------------------------------------------------------------------------


def _make_error(
    *,
    error_type: str = "user",
    severity: str = "error",
    category: str = "notebook_compilation",
    file_path: str = "slides/ex.py",
    message: str = "boom",
    actionable_guidance: str = "Fix the cell that is failing",
    details: dict | None = None,
    job_id: int | None = None,
    correlation_id: str | None = None,
) -> BuildError:
    return BuildError(
        error_type=error_type,
        category=category,
        severity=severity,
        file_path=file_path,
        message=message,
        actionable_guidance=actionable_guidance,
        details=details or {},
        job_id=job_id,
        correlation_id=correlation_id,
    )


class TestVerboseShowErrorDetail:
    """Exercise every branch of ``VerboseOutputFormatter._show_error_detail``."""

    def _capture(self, formatter, error, index=1):
        formatter._show_error_detail(index, error)

    def test_cell_and_line_number_both_rendered(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(details={"cell_number": 7, "line_number": 42})
        self._capture(formatter, err)
        out = capsys.readouterr().err
        assert "cell #7" in out
        assert "line 42" in out

    def test_cell_only_renders_without_line(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(details={"cell_number": 3})
        self._capture(formatter, err)
        out = capsys.readouterr().err
        assert "cell #3" in out
        assert "line" not in out

    def test_error_class_and_short_message(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(
            details={
                "error_class": "SyntaxError",
                "short_message": "invalid syntax at col 4",
            }
        )
        self._capture(formatter, err)
        out = capsys.readouterr().err
        assert "SyntaxError" in out
        assert "invalid syntax at col 4" in out

    def test_error_class_without_short_message(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(details={"error_class": "ValueError"})
        self._capture(formatter, err)
        out = capsys.readouterr().err
        assert "ValueError" in out

    def test_fallback_message_when_no_error_class(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(message="plain old error message")
        self._capture(formatter, err)
        out = capsys.readouterr().err
        assert "plain old error message" in out

    def test_code_snippet_rendered_when_present(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(details={"code_snippet": "def foo():\n    return 1/0"})
        self._capture(formatter, err)
        out = capsys.readouterr().err
        assert "Code context" in out

    def test_empty_code_snippet_suppresses_context_header(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(details={"code_snippet": ""})
        self._capture(formatter, err)
        out = capsys.readouterr().err
        assert "Code context" not in out

    def test_job_and_correlation_ids_rendered(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(job_id=99, correlation_id="abc-123")
        self._capture(formatter, err)
        out = capsys.readouterr().err
        assert "Job ID: #99" in out
        assert "Correlation ID: abc-123" in out

    @pytest.mark.parametrize(
        "error_type",
        ["user", "configuration", "infrastructure"],
    )
    def test_all_error_types_supported(self, capsys, error_type):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(error_type=error_type)
        self._capture(formatter, err)
        out = capsys.readouterr().err
        assert error_type.title() in out


class TestVerboseShowFileCompletedEdgeCases:
    """Cover the duration + started/not-started branches of show_file_completed."""

    def test_completed_without_prior_started(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        # No show_file_started call — duration_str stays empty.
        formatter.show_file_completed("orphan.ipynb", "notebook", success=True)
        assert formatter._files_completed == 1

    def test_completed_with_prior_started_includes_duration(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        formatter.show_file_started("t.ipynb", "notebook", job_id=5)
        formatter.show_file_completed("t.ipynb", "notebook", job_id=5, success=True)
        out = capsys.readouterr().err
        # Duration marker "(0.00s)" format — at least one digit + s.
        assert "s)" in out

    def test_failed_without_job_id(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        formatter.show_file_completed("x.ipynb", "notebook", success=False)
        out = capsys.readouterr().err
        assert "Failed notebook" in out
        # No " (job #" fragment because job_id is None.
        assert "job #" not in out


class TestVerboseShowStageStart:
    """Cover the verbose-specific show_stage_start printout."""

    def test_with_cached_jobs(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        formatter.show_stage_start("Notebooks", 2, 4, num_jobs=10, num_cached=3)
        out = capsys.readouterr().err
        assert "Stage 2/4" in out
        assert "Notebooks" in out
        assert "3 from cache" in out

    def test_without_cached_jobs(self, capsys):
        formatter = VerboseOutputFormatter(show_progress=False, use_color=False)
        formatter.show_stage_start("Plantuml", 1, 3, num_jobs=5, num_cached=0)
        out = capsys.readouterr().err
        assert "Stage 1/3" in out
        assert "from cache" not in out


class TestDefaultFormatterSummary:
    """Exercise DefaultOutputFormatter.show_summary across error/warning mixes."""

    def _make_errors(self, n, error_type="user"):
        return [
            _make_error(
                error_type=error_type,
                file_path=f"file{i}.py",
                message=f"err {i}",
                actionable_guidance=("x" * 30),  # >20 chars so branch triggers
            )
            for i in range(n)
        ]

    def _make_warnings(self, n, severity="medium"):
        return [
            BuildWarning(
                category="c",
                message=f"warn {i}",
                severity=severity,
                file_path=f"w{i}.py" if i % 2 else None,
            )
            for i in range(n)
        ]

    def test_summary_all_clean(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        summary = BuildSummary(duration=1.0, total_files=5)
        formatter.show_summary(summary)
        out = capsys.readouterr().err
        assert "successfully" in out
        assert "5 files processed" in out
        assert "0 errors" in out

    def test_summary_errors_over_cap_shows_overflow(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        errors = self._make_errors(12)
        summary = BuildSummary(duration=2.5, total_files=12, errors=errors)
        formatter.show_summary(summary)
        out = capsys.readouterr().err
        assert "and 2 more errors" in out
        assert "verbose" in out

    @pytest.mark.parametrize("severity", ["high", "medium", "low"])
    def test_summary_warning_severity_branches(self, capsys, severity):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        warnings = self._make_warnings(2, severity=severity)
        summary = BuildSummary(duration=1.0, total_files=2, errors=[], warnings=warnings)
        formatter.show_summary(summary)
        out = capsys.readouterr().err
        # File-path location branch is exercised for the odd-indexed warning.
        assert "w1.py" in out

    def test_summary_warnings_over_cap_shows_overflow(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        warnings = self._make_warnings(8, severity="high")
        summary = BuildSummary(duration=1.0, total_files=8, errors=[], warnings=warnings)
        formatter.show_summary(summary)
        out = capsys.readouterr().err
        assert "more warnings" in out

    def test_summary_error_without_long_guidance_uses_error_class(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(
            actionable_guidance="short",  # <20 chars, falls through
            details={"error_class": "ValueError", "short_message": "bad input"},
        )
        summary = BuildSummary(duration=1.0, total_files=1, errors=[err])
        formatter.show_summary(summary)
        out = capsys.readouterr().err
        assert "ValueError" in out
        assert "bad input" in out

    def test_summary_error_with_cell_number_adds_location(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(
            actionable_guidance="s",
            details={"cell_number": 4},
            message="something failed",
        )
        summary = BuildSummary(duration=1.0, total_files=1, errors=[err])
        formatter.show_summary(summary)
        out = capsys.readouterr().err
        assert "cell #4" in out


class TestDefaultShowError:
    """Exercise DefaultOutputFormatter.show_error detail branches (lines 289-342)."""

    def test_show_error_with_cell_and_line(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(details={"cell_number": 2, "line_number": 17})
        formatter.show_error(err)
        out = capsys.readouterr().err
        assert "#2" in out
        assert "line 17" in out

    def test_show_error_with_error_class(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(details={"error_class": "RuntimeError", "short_message": "kaboom"})
        formatter.show_error(err)
        out = capsys.readouterr().err
        assert "RuntimeError" in out
        assert "kaboom" in out

    def test_show_error_with_code_snippet(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(details={"code_snippet": "x = 1 / 0"})
        formatter.show_error(err)
        out = capsys.readouterr().err
        assert "Code context" in out

    def test_show_error_with_job_id(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        err = _make_error(job_id=77)
        formatter.show_error(err)
        out = capsys.readouterr().err
        assert "Job ID: #77" in out

    def test_show_error_configuration_and_infrastructure_colors(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        for t in ("configuration", "infrastructure"):
            formatter.show_error(_make_error(error_type=t))
        out = capsys.readouterr().err
        assert "Configuration Error" in out
        assert "Infrastructure Error" in out

    def test_show_warning(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        w = BuildWarning(category="c", message="hey", severity="high")
        formatter.show_warning(w)
        out = capsys.readouterr().err
        assert "hey" in out


class TestQuietFormatter:
    """QuietOutputFormatter has large no-op surface — cover every method."""

    def test_all_noop_methods_run(self):
        from clm.cli.output_formatter import QuietOutputFormatter

        formatter = QuietOutputFormatter()
        # These should all be silent and not raise.
        formatter.show_build_start("course", 10, ["out1", "out2"])
        formatter.show_stage_start("Stage", 1, 2, num_jobs=5, num_cached=1)
        formatter.update_progress(3, 5, active_workers=1, cached=1)
        formatter.show_warning(BuildWarning(category="c", message="m", severity="low"))
        assert (
            formatter.should_show_warning(BuildWarning(category="c", message="m", severity="high"))
            is False
        )
        formatter.cleanup()

    def test_show_error_only_for_error_and_fatal(self, capsys):
        from clm.cli.output_formatter import QuietOutputFormatter

        formatter = QuietOutputFormatter()
        err = _make_error(severity="error", file_path="q.py", message="die")
        assert formatter.should_show_error(err)
        formatter.show_error(err)
        out = capsys.readouterr().err
        assert "ERROR" in out
        assert "die" in out

    def test_show_error_skipped_for_warning_severity(self):
        from clm.cli.output_formatter import QuietOutputFormatter

        formatter = QuietOutputFormatter()
        err = _make_error(severity="warning")
        assert not formatter.should_show_error(err)

    def test_summary_with_errors_prints_red_line_and_log_dir(self, capsys):
        from clm.cli.output_formatter import QuietOutputFormatter

        formatter = QuietOutputFormatter()
        summary = BuildSummary(duration=1.5, total_files=1, errors=[_make_error()])
        formatter.show_summary(summary)
        out = capsys.readouterr().err
        assert "Build failed" in out
        assert "logs" in out.lower()

    def test_summary_without_errors(self, capsys):
        from clm.cli.output_formatter import QuietOutputFormatter

        formatter = QuietOutputFormatter()
        summary = BuildSummary(duration=0.5, total_files=0)
        formatter.show_summary(summary)
        out = capsys.readouterr().err
        assert "successfully" in out


class TestJSONFormatter:
    """JSONOutputFormatter structured output shape."""

    def test_full_roundtrip(self, capsys):
        formatter = JSONOutputFormatter()
        formatter.show_build_start("course-x", 3, ["out-de", "out-en"])
        formatter.show_stage_start("Notebooks", 1, 2, num_jobs=3, num_cached=1)
        formatter.update_progress(2, 3, active_workers=1, cached=1)

        # These are silent but must not raise.
        formatter.show_error(_make_error())
        formatter.show_warning(BuildWarning(category="c", message="w", severity="low"))
        assert not formatter.should_show_error(_make_error())
        assert not formatter.should_show_warning(
            BuildWarning(category="c", message="w", severity="high")
        )

        summary = BuildSummary(
            duration=1.0,
            total_files=3,
            errors=[_make_error(details={"a_string": "x", "a_number": 42})],
            warnings=[BuildWarning(category="c", message="w", severity="low", file_path="w.py")],
            start_time=datetime(2026, 4, 17, 10, 0, 0),
            end_time=datetime(2026, 4, 17, 10, 0, 1),
        )
        formatter.show_summary(summary)
        formatter.cleanup()

        captured = capsys.readouterr().out
        data = json.loads(captured)
        assert data["status"] == "failed"
        assert data["course_name"] == "course-x"
        assert data["output_dirs"] == ["out-de", "out-en"]
        assert data["stages"][0]["num_cached"] == 1
        assert data["stages"][0]["cached_completed"] == 1
        assert data["error_count"] == 1
        assert data["warning_count"] == 1
        assert "log_directory" in data
        assert "start_time" in data and "end_time" in data
        # Non-string details preserved verbatim; strings ANSI-stripped.
        assert data["errors"][0]["details"]["a_number"] == 42

    def test_status_success_when_no_errors(self, capsys):
        formatter = JSONOutputFormatter()
        formatter.show_build_start("ok", 1)
        summary = BuildSummary(duration=0.1, total_files=1)
        formatter.show_summary(summary)
        data = json.loads(capsys.readouterr().out)
        assert data["status"] == "success"

    def test_status_fatal_when_fatal_error(self, capsys):
        formatter = JSONOutputFormatter()
        formatter.show_build_start("x", 1)
        fatal = _make_error(severity="fatal")
        summary = BuildSummary(duration=0.1, total_files=1, errors=[fatal])
        formatter.show_summary(summary)
        data = json.loads(capsys.readouterr().out)
        assert data["status"] == "fatal"


class TestDefaultFormatterMisc:
    """Small remaining DefaultOutputFormatter branches."""

    def test_show_build_start_prints_output_dirs(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        formatter.show_build_start("C", 2, output_dirs=["a", "b"])
        out = capsys.readouterr().err
        assert "a" in out and "b" in out

    def test_stage_start_without_progress_prints_line(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        formatter.show_stage_start("S", 1, 1, num_jobs=4, num_cached=2)
        out = capsys.readouterr().err
        assert "4 jobs" in out
        assert "2 cached" in out

    def test_startup_message(self, capsys):
        formatter = DefaultOutputFormatter(show_progress=False, use_color=False)
        formatter.show_startup_message("warming up")
        out = capsys.readouterr().err
        assert "warming up" in out
