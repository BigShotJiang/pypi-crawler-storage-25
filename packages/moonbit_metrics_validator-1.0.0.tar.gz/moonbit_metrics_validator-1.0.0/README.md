# moonbit-metrics-validator

Schema validation for MoonBit dashboard metric snapshots.

Ensures that automatically fetched metric payloads conform to the expected
schema before they are persisted to the database, preventing data corruption
from malformed API responses.

## Installation

```bash
pip install moonbit-metrics-validator
```

## Usage

```python
from moonbit_metrics_validator import validate_snapshot, validate_payload

# Validate a single snapshot dict
validate_snapshot(snapshot)

# Validate the full metrics payload (with snapshots list)
validate_payload(payload)
```

## License

MIT
