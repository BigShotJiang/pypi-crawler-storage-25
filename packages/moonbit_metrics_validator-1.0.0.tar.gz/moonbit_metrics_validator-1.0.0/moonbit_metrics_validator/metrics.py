"""Validation schemas and helpers for MoonBit dashboard metrics."""
from __future__ import annotations

import re
from moonbit_schema_utils import SchemaError, validate

_ISO_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

SNAPSHOT_SCHEMA: dict = {
    "type": "object",
    "required": ["date", "generated_at"],
    "properties": {
        "date": {"type": "string", "pattern": r"^\d{4}-\d{2}-\d{2}$"},
        "generated_at": {"type": "string"},
        "values": {"type": "object"},
        "statuses": {"type": "object"},
        "errors": {"type": "object"},
    },
}

PAYLOAD_SCHEMA: dict = {
    "type": "object",
    "required": ["generated_at", "snapshots"],
    "properties": {
        "generated_at": {"type": "string"},
        "snapshots": {
            "type": "array",
            "items": SNAPSHOT_SCHEMA,
        },
    },
}

_VALID_STATUSES = {"ok", "stale", "error"}


def validate_snapshot(data: dict) -> None:
    """Validate a single metric snapshot.

    Raises ``SchemaError`` if the snapshot does not match the expected schema.
    """
    validate(data, SNAPSHOT_SCHEMA)

    date = data.get("date", "")
    if not _ISO_DATE_RE.match(str(date)):
        raise SchemaError(f"Invalid date format: {date!r}, expected YYYY-MM-DD", "date")

    values = data.get("values")
    if isinstance(values, dict):
        for key, value in values.items():
            if not isinstance(key, str) or not key.strip():
                raise SchemaError(f"Invalid metric key: {key!r}", "values")
            if isinstance(value, bool):
                raise SchemaError(
                    f"Metric '{key}' must be numeric, got bool", f"values.{key}"
                )
            if not isinstance(value, (int, float)):
                raise SchemaError(
                    f"Metric '{key}' must be numeric, got {type(value).__name__}",
                    f"values.{key}",
                )

    statuses = data.get("statuses")
    if isinstance(statuses, dict):
        for key, status in statuses.items():
            if status not in _VALID_STATUSES:
                raise SchemaError(
                    f"Invalid status '{status}' for '{key}', "
                    f"expected one of {_VALID_STATUSES}",
                    f"statuses.{key}",
                )


def validate_payload(data: dict) -> None:
    """Validate the full metrics payload including all snapshots.

    Raises ``SchemaError`` on the first violation.
    """
    validate(data, PAYLOAD_SCHEMA)

    snapshots = data.get("snapshots", [])
    if not snapshots:
        raise SchemaError("Payload must contain at least one snapshot")

    seen_dates: set[str] = set()
    prev_date = ""
    for index, snapshot in enumerate(snapshots):
        validate_snapshot(snapshot)
        date = snapshot.get("date", "")
        if date in seen_dates:
            raise SchemaError(
                f"Duplicate snapshot date: {date}", f"snapshots[{index}]"
            )
        if date < prev_date:
            raise SchemaError(
                f"Snapshots not sorted: '{date}' appears after '{prev_date}'",
                f"snapshots[{index}]",
            )
        seen_dates.add(date)
        prev_date = date
