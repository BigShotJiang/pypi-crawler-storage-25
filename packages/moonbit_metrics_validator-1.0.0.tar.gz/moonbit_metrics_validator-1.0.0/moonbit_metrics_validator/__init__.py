"""Schema validation for MoonBit dashboard metric snapshots."""
from .metrics import validate_payload, validate_snapshot

__version__ = "1.0.0"
__all__ = ["validate_payload", "validate_snapshot"]
