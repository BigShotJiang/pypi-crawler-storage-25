from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable
from zoneinfo import ZoneInfo

from sluice.builders import (
    build_fetcher_chain,
    build_processors,
    build_sinks,
    build_sources,
)
from sluice.config import (
    FetcherApplyConfig,
    GlobalConfig,
    LLMStageConfig,
    PipelineConfig,
    ScoreTagConfig,
)
from sluice.context import PipelineContext, RunStats
from sluice.core.errors import ConfigError as _ConfigError
from sluice.llm.budget import RunBudget
from sluice.llm.pool import ProviderPool
from sluice.loader import ConfigBundle
from sluice.logging_setup import get_logger
from sluice.pricing import model_price
from sluice.processors.dedupe import item_key
from sluice.run_key import render_run_key
from sluice.state.cache import UrlCacheStore
from sluice.state.db import open_db
from sluice.state.delivery_log import DeliveryLog
from sluice.state.emissions import EmissionStore
from sluice.state.failures import FailureStore
from sluice.state.run_log import RunLog
from sluice.state.seen import SeenStore
from sluice.window import compute_window

log = get_logger(__name__)


@dataclass
class RunResult:
    pipeline_id: str
    run_key: str
    status: str
    items_in: int = 0
    items_out: int = 0
    error: str | None = None


def _resolve_db_path(global_cfg: GlobalConfig, pipe: PipelineConfig) -> str:
    db_path = pipe.state.db_path
    if db_path is None:
        db_path = global_cfg.state.db_path
    if db_path is None:
        raise _ConfigError(
            f"pipeline {pipe.id!r}: state.db_path must be configured "
            f"in [state] or per-pipeline [pipeline.state]"
        )
    return db_path


def _resolve_tz(global_cfg: GlobalConfig, pipe: PipelineConfig) -> ZoneInfo:
    return ZoneInfo(pipe.timezone or global_cfg.runtime.timezone)


async def run_pipeline(
    bundle: ConfigBundle,
    *,
    pipeline_id: str,
    now: datetime | None = None,
    dry_run: bool = False,
    progress: Callable[..., None] | None = None,
) -> RunResult:
    pipe = bundle.pipelines[pipeline_id]
    global_cfg = bundle.global_cfg
    tz = _resolve_tz(global_cfg, pipe)
    now = now or datetime.now(timezone.utc)
    local_now = now.astimezone(tz)
    run_date = local_now.date().isoformat()
    run_key = render_run_key(pipe.run_key_template, pipe.id, local_now)

    def emit(event: str, **data) -> None:
        if progress is not None:
            progress(event, **data)

    emit("run_started", pipeline_id=pipe.id, run_key=run_key, run_date=run_date, dry_run=dry_run)
    log.bind(
        pipeline_id=pipe.id,
        run_key=run_key,
        run_date=run_date,
        dry_run=dry_run,
    ).info("run.started")
    emit(
        "plan",
        sources=len(pipe.sources),
        stages=len(pipe.stages),
        sinks=0 if dry_run else len(pipe.sinks),
        total=len(pipe.sources) + len(pipe.stages) + (0 if dry_run else len(pipe.sinks)),
    )
    log.bind(
        pipeline_id=pipe.id,
        sources=len(pipe.sources),
        stages=len(pipe.stages),
        sinks=0 if dry_run else len(pipe.sinks),
    ).info("run.plan")

    db_path = _resolve_db_path(global_cfg, pipe)
    async with open_db(db_path) as db:
        seen = SeenStore(db)
        failures = FailureStore(db)
        emissions = EmissionStore(db)
        cache = UrlCacheStore(db)
        runlog = RunLog(db)
        await runlog.start(pipe.id, run_key)

        pool: ProviderPool | None = None
        try:
            budget = RunBudget(
                max_calls=pipe.limits.max_llm_calls_per_run,
                max_usd=pipe.limits.max_estimated_cost_usd,
            )
            pool = ProviderPool(bundle.providers)
            needs_fetcher_chain = any(isinstance(st, FetcherApplyConfig) for st in pipe.stages)
            chain = build_fetcher_chain(global_cfg, pipe, cache) if needs_fetcher_chain else None

            if pipe.limits.max_estimated_cost_usd > 0:
                for st in pipe.stages:
                    if not isinstance(st, (LLMStageConfig, ScoreTagConfig)):
                        continue
                    ip, op = model_price(pool, st.model)
                    if ip == 0.0 and op == 0.0:
                        raise _ConfigError(
                            f"pipeline {pipe.id!r}: max_estimated_cost_usd "
                            f"is set but primary model {st.model!r} has no "
                            f"input/output_price_per_1k in providers.toml "
                            f"— cost cap would silently never trip. "
                            f"Set prices or set max_estimated_cost_usd = 0 "
                            f"to disable the USD cap explicitly."
                        )
                    for spec in (st.retry_model, st.fallback_model, st.fallback_model_2):
                        if spec is None:
                            continue
                        ip, op = model_price(pool, spec)
                        if ip == 0.0 and op == 0.0:
                            log.bind(pipeline_id=pipe.id, model=spec).warning(
                                "llm.fallback_model_missing_price"
                            )

            window_start, window_end = compute_window(
                now=now, window=pipe.window, lookback_overlap=pipe.lookback_overlap
            )

            sources = build_sources(pipe)
            collected = []
            for i, src in enumerate(sources, start=1):
                source_name = getattr(src, "source_id", f"source_{i}")
                emit("source_started", index=i, total=len(sources), name=source_name)
                log.bind(
                    pipeline_id=pipe.id,
                    source=source_name,
                    index=i,
                    total=len(sources),
                ).info("source.started")
                before = len(collected)
                async for it in src.fetch(window_start, window_end):
                    collected.append(it)
                items_out = len(collected) - before
                emit(
                    "source_done",
                    index=i,
                    total=len(sources),
                    name=source_name,
                    items_in=0,
                    items_out=items_out,
                    total_items=len(collected),
                    advance=1,
                )
                log.bind(
                    pipeline_id=pipe.id,
                    source=source_name,
                    items_out=items_out,
                    total_items=len(collected),
                ).info("source.done")

            requeue = await failures.requeue(pipe.id)
            requeued_keys = {item_key(it) for it in requeue}
            items_in = len(collected) + len(requeue)
            if requeued_keys:
                log.bind(pipeline_id=pipe.id, requeued=len(requeued_keys)).info("failures.requeued")
            if requeued_keys:
                collected = [it for it in collected if item_key(it) not in requeued_keys]

            ctx = PipelineContext(
                pipeline_id=pipe.id,
                run_key=run_key,
                run_date=run_date,
                items=[*collected, *requeue],
                context={},
                stats=RunStats(items_in=items_in),
                items_resolved_from_failures=list(requeue),
            )

            procs = build_processors(
                pipe=pipe,
                global_cfg=global_cfg,
                seen=seen,
                failures=failures,
                fetcher_chain=chain,
                llm_pool=pool,
                budget=budget,
                dry_run=dry_run,
                requeued_keys=requeued_keys,
                db=db,
            )

            cap = pipe.limits.max_items_per_run
            policy = pipe.limits.item_overflow_policy
            min_dt = datetime.min.replace(tzinfo=timezone.utc)

            from sluice.processors.dedupe import DedupeProcessor

            def sync_run_stats() -> None:
                ctx.stats.items_out = len(ctx.items)
                ctx.stats.llm_calls = budget.calls
                ctx.stats.est_cost_usd = budget.spent_usd

            def apply_item_cap() -> None:
                if len(ctx.items) <= cap:
                    return
                before_cap = len(ctx.items)
                ctx.items.sort(
                    key=lambda i: i.published_at or min_dt,
                    reverse=(policy == "drop_oldest"),
                )
                ctx.items = ctx.items[:cap]
                log.bind(
                    pipeline_id=pipe.id,
                    cap=cap,
                    policy=policy,
                    items_in=before_cap,
                    items_out=len(ctx.items),
                ).info("limits.item_cap_applied")

            has_dedupe = any(isinstance(p, DedupeProcessor) for p in procs)
            if not has_dedupe:
                apply_item_cap()
            sync_run_stats()

            for p in procs:
                sync_run_stats()
                before = len(ctx.items)
                emit("processor_started", name=p.name, items_in=before)
                log.bind(
                    pipeline_id=pipe.id,
                    stage=p.name,
                    items_in=before,
                ).info("processor.started")
                try:
                    ctx = await p.process(ctx)
                finally:
                    if hasattr(p, "aclose"):
                        await p.aclose()
                if isinstance(p, DedupeProcessor):
                    apply_item_cap()
                sync_run_stats()
                stage_details = ctx.context.get("_stage_stats", {}).get(p.name)
                emit(
                    "processor_done",
                    name=p.name,
                    items_in=before,
                    items_out=len(ctx.items),
                    details=stage_details,
                    advance=1,
                )
                log.bind(
                    pipeline_id=pipe.id,
                    stage=p.name,
                    items_in=before,
                    items_out=len(ctx.items),
                    details=stage_details,
                ).info("processor.done")

            sync_run_stats()

            if not dry_run:
                delivery_log = DeliveryLog(db_path=db_path)
                sinks = build_sinks(pipe, delivery_log=delivery_log, root=bundle.root)
                for sink in sinks:
                    emit("sink_started", id=sink.id, type=sink.type, items_in=len(ctx.items))
                    log.bind(
                        pipeline_id=pipe.id,
                        sink_id=sink.id,
                        sink_type=sink.type,
                        items_in=len(ctx.items),
                    ).info("sink.started")
                    sink_error: str | None = None
                    emitted = None
                    try:
                        emitted = await sink.emit(ctx, emissions=emissions)
                    except Exception as _sink_exc:
                        sink_error = str(_sink_exc)
                        log.bind(
                            pipeline_id=pipe.id,
                            sink_id=sink.id,
                            sink_type=sink.type,
                        ).exception("sink.failed")
                    finally:
                        if hasattr(sink, "aclose"):
                            await sink.aclose()
                    emit(
                        "sink_done",
                        id=sink.id,
                        type=sink.type,
                        items_in=len(ctx.items),
                        emitted=emitted is not None,
                        error=sink_error,
                        advance=1,
                    )
                    log.bind(
                        pipeline_id=pipe.id,
                        sink_id=sink.id,
                        sink_type=sink.type,
                        items_in=len(ctx.items),
                        emitted=emitted is not None,
                        error=sink_error,
                    ).info("sink.done")

            if not dry_run:
                kept = [(it, item_key(it)) for it in ctx.items]
                await seen.mark_seen_batch(pipe.id, kept)
                surviving_keys = {item_key(it) for it in ctx.items}
                for k in requeued_keys & surviving_keys:
                    await failures.mark_resolved(pipe.id, k)

            await runlog.update_stats(
                pipe.id,
                run_key,
                items_in=ctx.stats.items_in,
                items_out=ctx.stats.items_out,
                llm_calls=ctx.stats.llm_calls,
                est_cost_usd=ctx.stats.est_cost_usd,
            )
            await runlog.finish(pipe.id, run_key, status="success")
            emit(
                "run_finished",
                status="success",
                pipeline_id=pipe.id,
                run_key=run_key,
                items_in=ctx.stats.items_in,
                items_out=ctx.stats.items_out,
            )
            log.bind(
                pipeline_id=pipe.id,
                run_key=run_key,
                items_in=ctx.stats.items_in,
                items_out=ctx.stats.items_out,
                llm_calls=ctx.stats.llm_calls,
                est_cost_usd=ctx.stats.est_cost_usd,
            ).info("run.finished")
            return RunResult(
                pipeline_id=pipe.id,
                run_key=run_key,
                status="success",
                items_in=ctx.stats.items_in,
                items_out=ctx.stats.items_out,
            )
        except Exception as e:
            log.bind(pipeline_id=pipe.id, run_key=run_key).exception("run.failed")
            await runlog.finish(pipe.id, run_key, status="failed", error_msg=str(e))
            emit("run_failed", status="failed", pipeline_id=pipe.id, run_key=run_key, error=str(e))
            return RunResult(pipeline_id=pipe.id, run_key=run_key, status="failed", error=str(e))
        finally:
            if pool is not None:
                await pool.aclose()
