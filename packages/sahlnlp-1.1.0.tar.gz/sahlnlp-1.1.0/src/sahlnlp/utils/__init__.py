"""Utility modules and constants."""
