""" memorph-bin-darwin-x64 """


def main() -> None:
    print("  memorph-bin-darwin-x64  ")
