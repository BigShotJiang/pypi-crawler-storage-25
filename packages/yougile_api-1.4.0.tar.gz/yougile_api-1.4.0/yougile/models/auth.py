from pydantic import BaseModel


class getCompanies(BaseModel):
    """
    Получить список компаний

    Args:
        login (str): Логин пользователя
        password (str): Пароль пользователя
        name (str, optional): Название компании

        limit (int): Количество элементов, которые хочется получить. Максимум 1000 (По умолчанию = 50)
        offset (int): Индекс первого элемента страницы (По умолчанию = 0)

    https://ru.yougile.com/api-v2#/operations/getCompanies
    """

    _method: str = "post"
    _url: str = "/api-v2/auth/companies"
    _url_params: tuple = ("limit", "offset")
    login: str
    password: str
    name: str | None = None

    limit: int = 50
    offset: int = 0


class AuthKeyController_companiesList(getCompanies):
    """
    Получить список компаний

    Args:
        login (str): Логин пользователя
        password (str): Пароль пользователя
        name (str, optional): Название компании
        limit (int): Количество элементов, которые хочется получить. Максимум 1000 (По умолчанию = 50)
        offset (int): Индекс первого элемента страницы (По умолчанию = 0)

    https://ru.yougile.com/api-v2#/operations/getCompanies
    """

    pass


class AuthKeyController_search(BaseModel):
    """
    Получить список ключей

    Args:
        login (str): Логин пользователя
        password (str): Пароль пользователя
        companyId (str): ID компании

    https://ru.yougile.com/api-v2#/operations/AuthKeyController_search
    """

    _method: str = "post"
    _url: str = "/api-v2/auth/keys/get"
    login: str
    password: str
    companyId: str


class AuthKeyController_create(BaseModel):
    """
    Создать ключ

    Args:
        login (str): Логин пользователя
        password (str): Пароль пользователя
        companyId (str): ID компании

    https://ru.yougile.com/api-v2#/operations/AuthKeyController_create
    """

    _method: str = "post"
    _url: str = "/api-v2/auth/keys"
    login: str
    password: str
    companyId: str


class AuthKeyController_delete(BaseModel):
    """
    Удалить ключ

    Args:
        key (str): Ключ

    https://ru.yougile.com/api-v2#/operations/AuthKeyController_delete
    """

    _method: str = "delete"
    _url: str = "/api-v2/auth/keys/{key}"
    _url_parse: tuple = ("key",)
    key: str
