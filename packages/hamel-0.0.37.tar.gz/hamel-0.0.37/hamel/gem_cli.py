"""CLI for Google Gemini API interactions via hamel.gem."""

from datetime import datetime
from typing import Annotated, Optional, List
from pathlib import Path
import typer
from hamel.gem import gem as hamel_gem
from hamel.cli_utils import die, require_env, read_stdin_if_none

app = typer.Typer()

IMAGE_MODEL = "gemini-3.1-flash-image-preview"
ASPECT_RATIOS = ["1:1", "1:4", "1:8", "2:3", "3:2", "3:4", "4:1", "4:3", "4:5", "5:4", "8:1", "9:16", "16:9", "21:9"]


def _generate_image(prompt, output, model, aspect_ratio, attachments=None):
    """Generate an image using Gemini's image generation models."""
    from google import genai
    from google.genai import types

    client = genai.Client()

    _IMAGE_EXTS = {'.png', '.jpg', '.jpeg', '.gif', '.webp'}

    contents = [prompt]
    if attachments:
        for attachment in attachments:
            p = Path(attachment)
            if p.exists() and p.suffix.lower() in _IMAGE_EXTS:
                mime = {'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
                        '.gif': 'image/gif', '.webp': 'image/webp'}[p.suffix.lower()]
                contents.insert(0, types.Part.from_bytes(mime_type=mime, data=p.read_bytes()))
            else:
                contents.insert(0, attachment)

    config_kwargs = {
        'response_modalities': ['IMAGE'],
    }
    if aspect_ratio:
        config_kwargs['image_config'] = types.ImageConfig(aspect_ratio=aspect_ratio)
    cfg = types.GenerateContentConfig(**config_kwargs)

    response = client.models.generate_content(
        model=model,
        contents=contents,
        config=cfg,
    )

    for part in response.candidates[0].content.parts:
        if part.inline_data is not None:
            image = part.as_image()
            image.save(output)
            return output

    raise RuntimeError("No image was returned in the response")


@app.command()
def gem(
    prompt: Annotated[Optional[str], typer.Argument(help="Text prompt (reads from stdin if not provided)")] = None,
    attachments: Annotated[Optional[List[str]], typer.Argument(help="File paths or URLs to analyze")] = None,
    model: Annotated[str, typer.Option("--model", "-m", help="Gemini model to use")] = "gemini-3-flash-preview",
    thinking: Annotated[int, typer.Option("--thinking", "-t", help="Thinking budget (-1 for default)")] = -1,
    search: Annotated[bool, typer.Option("--search", "-s", help="Enable grounded Google search")] = False,
    image: Annotated[bool, typer.Option("--image", "-i", help="Generate an image instead of text")] = False,
    output: Annotated[Optional[str], typer.Option("--output", "-o", help="Output file path for generated image")] = None,
    aspect_ratio: Annotated[Optional[str], typer.Option("--aspect-ratio", "-a", help=f"Aspect ratio for image generation ({', '.join(ASPECT_RATIOS)})")] = None,
):
    """Generate content with Google Gemini API.

    Examples:
        ai-gem "Write a haiku"
        ai-gem "Summarize this" document.pdf
        ai-gem "Compare these" file1.pdf file2.png
        echo "Some text" | ai-gem "Analyze this"
        ai-gem --image "A cat wearing a tiny hat"
        ai-gem --image "A landscape at sunset" --aspect-ratio 16:9
        ai-gem --image "A cat wearing a tiny hat" -o cat.png
        ai-gem --image "Edit this photo to add sunglasses" reference.jpg
    """
    require_env("GEMINI_API_KEY")
    prompt = read_stdin_if_none(prompt)

    if aspect_ratio and not image:
        die("Error: --aspect-ratio requires --image flag")

    if output and not image:
        die("Error: --output requires --image flag")

    if aspect_ratio and aspect_ratio not in ASPECT_RATIOS:
        die(f"Error: Invalid aspect ratio '{aspect_ratio}'. Must be one of: {', '.join(ASPECT_RATIOS)}")

    try:
        if attachments:
            for attachment in attachments:
                p = Path(attachment)
                if not p.exists() and not attachment.startswith(('http://', 'https://', 'www.')) and 'youtube.com' not in attachment and 'youtu.be' not in attachment:
                    die(f"Error: File not found: {attachment}")

        if image:
            img_model = model if model != "gemini-3-flash-preview" else IMAGE_MODEL
            if output is None:
                output = f"gem_image_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            result = _generate_image(
                prompt=prompt,
                output=output,
                model=img_model,
                aspect_ratio=aspect_ratio,
                attachments=attachments,
            )
            print(result)
        else:
            result = hamel_gem(
                prompt=prompt,
                o=attachments if attachments else None,
                model=model,
                thinking=thinking,
                search=search
            )
            print(result)

    except Exception as e:
        die(f"Error: {str(e)}")

def main():
    app()
