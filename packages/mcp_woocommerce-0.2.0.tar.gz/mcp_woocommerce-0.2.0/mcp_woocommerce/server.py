"""MCP server for the WooCommerce REST API — 73 tools."""

import functools
import json
import os
from typing import Any

from mcp.server.fastmcp import FastMCP

from mcp_woocommerce.client import WooCommerceClient, WooCommerceError

mcp = FastMCP(
    "mcp-woocommerce",
    instructions=(
        "Production-grade MCP server for the WooCommerce REST API v3. "
        "73 tools for products, variations, attributes, orders, customers, "
        "coupons, reviews, reports, shipping, payments, webhooks, batch "
        "operations, inventory, and system management."
    ),
)

# ── Helpers ──────────────────────────────────────────────────────────

_client: WooCommerceClient | None = None


def get_client() -> WooCommerceClient:
    global _client
    if _client is None:
        store_url = os.environ.get("WOOCOMMERCE_URL", "")
        key = os.environ.get("WOOCOMMERCE_KEY", "")
        secret = os.environ.get("WOOCOMMERCE_SECRET", "")
        if not store_url or not key or not secret:
            raise ValueError(
                "Required environment variables: WOOCOMMERCE_URL, "
                "WOOCOMMERCE_KEY, WOOCOMMERCE_SECRET. "
                "Generate keys at: WordPress Admin → WooCommerce → "
                "Settings → Advanced → REST API"
            )
        _client = WooCommerceClient(store_url, key, secret)
    return _client


def _fmt(data: Any) -> str:
    """Format response data as indented JSON string."""
    return json.dumps(data, indent=2, default=str)


def _safe(fn):
    """Catch WooCommerce API errors and return JSON instead of crashing."""
    @functools.wraps(fn)
    async def wrapper(*args, **kwargs):
        try:
            return await fn(*args, **kwargs)
        except WooCommerceError as e:
            return _fmt({"error": str(e), "code": e.code, "status": e.status})
        except Exception as e:
            return _fmt({"error": str(e)})
    return wrapper


def _list(data: Any) -> list:
    """Safely extract a list from API responses."""
    return data if isinstance(data, list) else []


# ══════════════════════════════════════════════════════════════════════
# STORE
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def ping() -> str:
    """Validate WooCommerce connection and get store info (name, URL, currency, version, timezone)."""
    wc = get_client()
    data = await wc.get("/system_status")
    env = data.get("environment", {})
    settings = data.get("settings", {})
    return _fmt({
        "status": "connected",
        "store_url": wc.store_url,
        "wc_version": env.get("version", ""),
        "wp_version": env.get("wp_version", ""),
        "currency": settings.get("currency", ""),
        "currency_symbol": settings.get("currency_symbol", ""),
        "timezone": settings.get("timezone", ""),
        "weight_unit": settings.get("weight_unit", ""),
        "dimension_unit": settings.get("dimension_unit", ""),
    })


# ══════════════════════════════════════════════════════════════════════
# PRODUCTS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_products(
    status: str = "",
    category: str = "",
    search: str = "",
    on_sale: bool = False,
    per_page: int = 20,
    page: int = 1,
    orderby: str = "date",
    order: str = "desc",
) -> str:
    """List products. Filter by status (publish, draft, pending, private), category ID, search term, or on_sale flag. Orderby: date, id, title, price, popularity, rating."""
    wc = get_client()
    params: dict[str, Any] = {
        "per_page": min(per_page, 100),
        "page": page,
        "orderby": orderby,
        "order": order,
    }
    if status:
        params["status"] = status
    if category:
        params["category"] = category
    if search:
        params["search"] = search
    if on_sale:
        params["on_sale"] = True
    data = await wc.get("/products", params=params)
    products = []
    for p in _list(data):
        products.append({
            "id": p.get("id", 0),
            "name": p.get("name", ""),
            "slug": p.get("slug", ""),
            "status": p.get("status", ""),
            "type": p.get("type", ""),
            "price": p.get("price", ""),
            "regular_price": p.get("regular_price", ""),
            "sale_price": p.get("sale_price", ""),
            "stock_status": p.get("stock_status", ""),
            "stock_quantity": p.get("stock_quantity"),
            "categories": [c.get("name", "") for c in p.get("categories", [])],
            "sku": p.get("sku", ""),
        })
    return _fmt({"count": len(products), "products": products})


@mcp.tool()
@_safe
async def get_product(product_id: int) -> str:
    """Get full details for a product including pricing, inventory, categories, images, and attributes."""
    wc = get_client()
    p = await wc.get(f"/products/{product_id}")
    return _fmt({
        "id": p.get("id", 0),
        "name": p.get("name", ""),
        "slug": p.get("slug", ""),
        "permalink": p.get("permalink", ""),
        "type": p.get("type", ""),
        "status": p.get("status", ""),
        "description": p.get("short_description", "") or p.get("description", "")[:500],
        "sku": p.get("sku", ""),
        "price": p.get("price", ""),
        "regular_price": p.get("regular_price", ""),
        "sale_price": p.get("sale_price", ""),
        "on_sale": p.get("on_sale", False),
        "stock_status": p.get("stock_status", ""),
        "stock_quantity": p.get("stock_quantity"),
        "manage_stock": p.get("manage_stock", False),
        "weight": p.get("weight", ""),
        "dimensions": p.get("dimensions", {}),
        "categories": [
            {"id": c.get("id", 0), "name": c.get("name", "")}
            for c in p.get("categories", [])
        ],
        "tags": [
            {"id": t.get("id", 0), "name": t.get("name", "")}
            for t in p.get("tags", [])
        ],
        "images": [
            {"id": i.get("id", 0), "src": i.get("src", "")}
            for i in p.get("images", [])[:5]
        ],
        "attributes": [
            {"name": a.get("name", ""), "options": a.get("options", [])}
            for a in p.get("attributes", [])
        ],
        "variations": p.get("variations", []),
        "total_sales": p.get("total_sales", 0),
        "average_rating": p.get("average_rating", ""),
        "rating_count": p.get("rating_count", 0),
        "created_at": p.get("date_created", ""),
    })


@mcp.tool()
@_safe
async def create_product(
    name: str,
    product_type: str = "simple",
    regular_price: str = "",
    description: str = "",
    short_description: str = "",
    sku: str = "",
    manage_stock: bool = False,
    stock_quantity: int = 0,
    categories: str = "",
    status: str = "publish",
) -> str:
    """Create a product. Type: simple, grouped, external, variable. Categories: comma-separated IDs."""
    wc = get_client()
    body: dict[str, Any] = {
        "name": name,
        "type": product_type,
        "status": status,
    }
    if regular_price:
        body["regular_price"] = regular_price
    if description:
        body["description"] = description
    if short_description:
        body["short_description"] = short_description
    if sku:
        body["sku"] = sku
    if manage_stock:
        body["manage_stock"] = True
        body["stock_quantity"] = stock_quantity
    if categories:
        body["categories"] = [
            {"id": int(c.strip())} for c in categories.split(",") if c.strip()
        ]
    p = await wc.post("/products", json=body)
    return _fmt({
        "id": p.get("id", 0),
        "name": p.get("name", ""),
        "status": p.get("status", ""),
        "type": p.get("type", ""),
        "permalink": p.get("permalink", ""),
        "message": "Product created.",
    })


@mcp.tool()
@_safe
async def update_product(
    product_id: int,
    name: str = "",
    regular_price: str = "",
    sale_price: str | None = None,
    status: str = "",
    stock_quantity: int = -1,
    description: str = "",
    sku: str = "",
) -> str:
    """Update a product. Only provide fields you want to change. Set sale_price to empty string to remove sale."""
    wc = get_client()
    body: dict[str, Any] = {}
    if name:
        body["name"] = name
    if regular_price:
        body["regular_price"] = regular_price
    if sale_price is not None:
        body["sale_price"] = sale_price
    if status:
        body["status"] = status
    if stock_quantity >= 0:
        body["stock_quantity"] = stock_quantity
        body["manage_stock"] = True
    if description:
        body["description"] = description
    if sku:
        body["sku"] = sku
    if not body:
        return "No fields provided to update."
    p = await wc.put(f"/products/{product_id}", json=body)
    return _fmt({
        "id": p.get("id", 0),
        "name": p.get("name", ""),
        "status": p.get("status", ""),
        "updated_fields": list(body.keys()),
        "message": "Product updated.",
    })


@mcp.tool()
@_safe
async def delete_product(product_id: int, force: bool = False) -> str:
    """Delete a product. Set force=True for permanent deletion (bypass trash)."""
    wc = get_client()
    await wc.delete(f"/products/{product_id}", params={"force": force})
    return _fmt({
        "product_id": product_id,
        "permanent": force,
        "message": "Product deleted." if force else "Product moved to trash.",
    })


@mcp.tool()
@_safe
async def search_products(query: str, per_page: int = 20) -> str:
    """Search products by name or SKU."""
    wc = get_client()
    data = await wc.get("/products", params={
        "search": query,
        "per_page": min(per_page, 100),
    })
    products = []
    for p in _list(data):
        products.append({
            "id": p.get("id", 0),
            "name": p.get("name", ""),
            "sku": p.get("sku", ""),
            "price": p.get("price", ""),
            "stock_status": p.get("stock_status", ""),
            "status": p.get("status", ""),
        })
    return _fmt({"query": query, "count": len(products), "products": products})


@mcp.tool()
@_safe
async def list_low_stock_products(
    stock_status: str = "outofstock",
    per_page: int = 50,
    page: int = 1,
) -> str:
    """List products by stock status for inventory management. stock_status: outofstock, onbackorder, instock. Use 'outofstock' to find items needing restocking."""
    wc = get_client()
    data = await wc.get("/products", params={
        "stock_status": stock_status,
        "per_page": min(per_page, 100),
        "page": page,
    })
    products = []
    for p in _list(data):
        products.append({
            "id": p.get("id", 0),
            "name": p.get("name", ""),
            "sku": p.get("sku", ""),
            "stock_status": p.get("stock_status", ""),
            "stock_quantity": p.get("stock_quantity"),
            "manage_stock": p.get("manage_stock", False),
            "price": p.get("price", ""),
            "status": p.get("status", ""),
        })
    return _fmt({"stock_status": stock_status, "count": len(products), "products": products})


# ══════════════════════════════════════════════════════════════════════
# PRODUCT CATEGORIES
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_product_categories(
    per_page: int = 50,
    page: int = 1,
    parent: int = -1,
) -> str:
    """List product categories. Set parent=0 for top-level only."""
    wc = get_client()
    params: dict[str, Any] = {"per_page": min(per_page, 100), "page": page}
    if parent >= 0:
        params["parent"] = parent
    data = await wc.get("/products/categories", params=params)
    cats = []
    for c in _list(data):
        cats.append({
            "id": c.get("id", 0),
            "name": c.get("name", ""),
            "slug": c.get("slug", ""),
            "parent": c.get("parent", 0),
            "count": c.get("count", 0),
            "description": c.get("description", ""),
        })
    return _fmt({"count": len(cats), "categories": cats})


@mcp.tool()
@_safe
async def create_product_category(
    name: str,
    parent: int = 0,
    description: str = "",
    slug: str = "",
) -> str:
    """Create a product category. Set parent ID for subcategories."""
    wc = get_client()
    body: dict[str, Any] = {"name": name}
    if parent:
        body["parent"] = parent
    if description:
        body["description"] = description
    if slug:
        body["slug"] = slug
    c = await wc.post("/products/categories", json=body)
    return _fmt({
        "id": c.get("id", 0),
        "name": c.get("name", ""),
        "slug": c.get("slug", ""),
        "parent": c.get("parent", 0),
        "message": "Category created.",
    })


@mcp.tool()
@_safe
async def update_product_category(
    category_id: int,
    name: str = "",
    description: str = "",
    slug: str = "",
    parent: int = -1,
) -> str:
    """Update a product category. Only provide fields to change."""
    wc = get_client()
    body: dict[str, Any] = {}
    if name:
        body["name"] = name
    if description:
        body["description"] = description
    if slug:
        body["slug"] = slug
    if parent >= 0:
        body["parent"] = parent
    if not body:
        return "No fields provided to update."
    c = await wc.put(f"/products/categories/{category_id}", json=body)
    return _fmt({
        "id": c.get("id", 0),
        "name": c.get("name", ""),
        "slug": c.get("slug", ""),
        "message": "Category updated.",
    })


@mcp.tool()
@_safe
async def delete_product_category(category_id: int) -> str:
    """Delete a product category. Products in this category are not deleted."""
    wc = get_client()
    await wc.delete(f"/products/categories/{category_id}", params={"force": True})
    return _fmt({"category_id": category_id, "message": "Category deleted."})


# ══════════════════════════════════════════════════════════════════════
# PRODUCT VARIATIONS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_product_variations(
    product_id: int,
    per_page: int = 20,
    page: int = 1,
) -> str:
    """List all variations for a variable product."""
    wc = get_client()
    data = await wc.get(
        f"/products/{product_id}/variations",
        params={"per_page": min(per_page, 100), "page": page},
    )
    variations = []
    for v in _list(data):
        variations.append({
            "id": v.get("id", 0),
            "sku": v.get("sku", ""),
            "price": v.get("price", ""),
            "regular_price": v.get("regular_price", ""),
            "sale_price": v.get("sale_price", ""),
            "stock_status": v.get("stock_status", ""),
            "stock_quantity": v.get("stock_quantity"),
            "status": v.get("status", ""),
            "attributes": [
                {"name": a.get("name", ""), "option": a.get("option", "")}
                for a in v.get("attributes", [])
            ],
        })
    return _fmt({"product_id": product_id, "count": len(variations), "variations": variations})


@mcp.tool()
@_safe
async def get_product_variation(product_id: int, variation_id: int) -> str:
    """Get full details for a specific product variation."""
    wc = get_client()
    v = await wc.get(f"/products/{product_id}/variations/{variation_id}")
    return _fmt({
        "id": v.get("id", 0),
        "product_id": product_id,
        "sku": v.get("sku", ""),
        "price": v.get("price", ""),
        "regular_price": v.get("regular_price", ""),
        "sale_price": v.get("sale_price", ""),
        "on_sale": v.get("on_sale", False),
        "status": v.get("status", ""),
        "stock_status": v.get("stock_status", ""),
        "stock_quantity": v.get("stock_quantity"),
        "manage_stock": v.get("manage_stock", False),
        "weight": v.get("weight", ""),
        "dimensions": v.get("dimensions", {}),
        "attributes": [
            {"name": a.get("name", ""), "option": a.get("option", "")}
            for a in v.get("attributes", [])
        ],
        "image": v.get("image", {}).get("src", "") if v.get("image") else "",
        "created_at": v.get("date_created", ""),
    })


@mcp.tool()
@_safe
async def create_product_variation(
    product_id: int,
    regular_price: str = "",
    sku: str = "",
    status: str = "publish",
    manage_stock: bool = False,
    stock_quantity: int = 0,
    attributes: str = "",
) -> str:
    """Create a product variation. attributes: JSON array of {name, option} objects. Example: '[{"name": "Color", "option": "Blue"}]'"""
    wc = get_client()
    body: dict[str, Any] = {"status": status}
    if regular_price:
        body["regular_price"] = regular_price
    if sku:
        body["sku"] = sku
    if manage_stock:
        body["manage_stock"] = True
        body["stock_quantity"] = stock_quantity
    if attributes:
        try:
            body["attributes"] = json.loads(attributes)
        except json.JSONDecodeError as e:
            return f"Invalid attributes JSON: {e}"
    v = await wc.post(f"/products/{product_id}/variations", json=body)
    return _fmt({
        "id": v.get("id", 0),
        "product_id": product_id,
        "sku": v.get("sku", ""),
        "price": v.get("price", ""),
        "status": v.get("status", ""),
        "message": "Variation created.",
    })


@mcp.tool()
@_safe
async def update_product_variation(
    product_id: int,
    variation_id: int,
    regular_price: str = "",
    sale_price: str | None = None,
    sku: str = "",
    status: str = "",
    stock_quantity: int = -1,
) -> str:
    """Update a product variation. Only provide fields to change."""
    wc = get_client()
    body: dict[str, Any] = {}
    if regular_price:
        body["regular_price"] = regular_price
    if sale_price is not None:
        body["sale_price"] = sale_price
    if sku:
        body["sku"] = sku
    if status:
        body["status"] = status
    if stock_quantity >= 0:
        body["stock_quantity"] = stock_quantity
        body["manage_stock"] = True
    if not body:
        return "No fields provided to update."
    v = await wc.put(f"/products/{product_id}/variations/{variation_id}", json=body)
    return _fmt({
        "id": v.get("id", 0),
        "product_id": product_id,
        "updated_fields": list(body.keys()),
        "message": "Variation updated.",
    })


@mcp.tool()
@_safe
async def delete_product_variation(
    product_id: int,
    variation_id: int,
    force: bool = True,
) -> str:
    """Delete a product variation."""
    wc = get_client()
    await wc.delete(
        f"/products/{product_id}/variations/{variation_id}",
        params={"force": force},
    )
    return _fmt({
        "product_id": product_id,
        "variation_id": variation_id,
        "message": "Variation deleted.",
    })


# ══════════════════════════════════════════════════════════════════════
# PRODUCT ATTRIBUTES
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_product_attributes() -> str:
    """List all product attributes (e.g. Color, Size) defined in the store."""
    wc = get_client()
    data = await wc.get("/products/attributes")
    attrs = []
    for a in _list(data):
        attrs.append({
            "id": a.get("id", 0),
            "name": a.get("name", ""),
            "slug": a.get("slug", ""),
            "type": a.get("type", ""),
            "order_by": a.get("order_by", ""),
            "has_archives": a.get("has_archives", False),
        })
    return _fmt({"count": len(attrs), "attributes": attrs})


@mcp.tool()
@_safe
async def get_product_attribute(attribute_id: int) -> str:
    """Get details for a product attribute including its terms/options."""
    wc = get_client()
    a = await wc.get(f"/products/attributes/{attribute_id}")
    terms = await wc.get(
        f"/products/attributes/{attribute_id}/terms",
        params={"per_page": 100},
    )
    return _fmt({
        "id": a.get("id", 0),
        "name": a.get("name", ""),
        "slug": a.get("slug", ""),
        "type": a.get("type", ""),
        "order_by": a.get("order_by", ""),
        "terms": [
            {"id": t.get("id", 0), "name": t.get("name", ""), "slug": t.get("slug", ""), "count": t.get("count", 0)}
            for t in _list(terms)
        ],
    })


@mcp.tool()
@_safe
async def create_product_attribute(
    name: str,
    slug: str = "",
    attribute_type: str = "select",
    order_by: str = "menu_order",
    has_archives: bool = False,
) -> str:
    """Create a product attribute. type: select, text. order_by: menu_order, name, name_num, id."""
    wc = get_client()
    body: dict[str, Any] = {
        "name": name,
        "type": attribute_type,
        "order_by": order_by,
        "has_archives": has_archives,
    }
    if slug:
        body["slug"] = slug
    a = await wc.post("/products/attributes", json=body)
    return _fmt({
        "id": a.get("id", 0),
        "name": a.get("name", ""),
        "slug": a.get("slug", ""),
        "message": "Attribute created.",
    })


@mcp.tool()
@_safe
async def update_product_attribute(
    attribute_id: int,
    name: str = "",
    slug: str = "",
    order_by: str = "",
) -> str:
    """Update a product attribute. Only provide fields to change."""
    wc = get_client()
    body: dict[str, Any] = {}
    if name:
        body["name"] = name
    if slug:
        body["slug"] = slug
    if order_by:
        body["order_by"] = order_by
    if not body:
        return "No fields provided to update."
    a = await wc.put(f"/products/attributes/{attribute_id}", json=body)
    return _fmt({
        "id": a.get("id", 0),
        "name": a.get("name", ""),
        "slug": a.get("slug", ""),
        "message": "Attribute updated.",
    })


@mcp.tool()
@_safe
async def delete_product_attribute(attribute_id: int) -> str:
    """Delete a product attribute. This also removes it from all products."""
    wc = get_client()
    await wc.delete(f"/products/attributes/{attribute_id}", params={"force": True})
    return _fmt({"attribute_id": attribute_id, "message": "Attribute deleted."})


# ═════════════════════════════════════════════════════════════════════��
# PRODUCT ATTRIBUTE TERMS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_attribute_terms(
    attribute_id: int,
    per_page: int = 50,
    page: int = 1,
) -> str:
    """List terms for a product attribute (e.g. 'Red', 'Blue' for Color). Get attribute IDs from list_product_attributes."""
    wc = get_client()
    data = await wc.get(
        f"/products/attributes/{attribute_id}/terms",
        params={"per_page": min(per_page, 100), "page": page},
    )
    terms = []
    for t in _list(data):
        terms.append({
            "id": t.get("id", 0),
            "name": t.get("name", ""),
            "slug": t.get("slug", ""),
            "description": t.get("description", ""),
            "count": t.get("count", 0),
            "menu_order": t.get("menu_order", 0),
        })
    return _fmt({"attribute_id": attribute_id, "count": len(terms), "terms": terms})


@mcp.tool()
@_safe
async def create_attribute_term(
    attribute_id: int,
    name: str,
    slug: str = "",
    description: str = "",
) -> str:
    """Add a term to a product attribute (e.g. add 'Red' to Color). Get attribute IDs from list_product_attributes."""
    wc = get_client()
    body: dict[str, Any] = {"name": name}
    if slug:
        body["slug"] = slug
    if description:
        body["description"] = description
    t = await wc.post(f"/products/attributes/{attribute_id}/terms", json=body)
    return _fmt({
        "id": t.get("id", 0),
        "attribute_id": attribute_id,
        "name": t.get("name", ""),
        "slug": t.get("slug", ""),
        "message": "Attribute term created.",
    })


@mcp.tool()
@_safe
async def update_attribute_term(
    attribute_id: int,
    term_id: int,
    name: str = "",
    slug: str = "",
    description: str = "",
) -> str:
    """Update a product attribute term. Only provide fields to change."""
    wc = get_client()
    body: dict[str, Any] = {}
    if name:
        body["name"] = name
    if slug:
        body["slug"] = slug
    if description:
        body["description"] = description
    if not body:
        return "No fields provided to update."
    t = await wc.put(f"/products/attributes/{attribute_id}/terms/{term_id}", json=body)
    return _fmt({
        "id": t.get("id", 0),
        "attribute_id": attribute_id,
        "name": t.get("name", ""),
        "message": "Attribute term updated.",
    })


@mcp.tool()
@_safe
async def delete_attribute_term(attribute_id: int, term_id: int) -> str:
    """Delete a product attribute term."""
    wc = get_client()
    await wc.delete(
        f"/products/attributes/{attribute_id}/terms/{term_id}",
        params={"force": True},
    )
    return _fmt({"attribute_id": attribute_id, "term_id": term_id, "message": "Attribute term deleted."})


# ══════════════════════════════════════════════════════════════════════
# PRODUCT TAGS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_product_tags(
    search: str = "",
    per_page: int = 50,
    page: int = 1,
) -> str:
    """List product tags. Optionally search by name."""
    wc = get_client()
    params: dict[str, Any] = {"per_page": min(per_page, 100), "page": page}
    if search:
        params["search"] = search
    data = await wc.get("/products/tags", params=params)
    tags = []
    for t in _list(data):
        tags.append({
            "id": t.get("id", 0),
            "name": t.get("name", ""),
            "slug": t.get("slug", ""),
            "count": t.get("count", 0),
        })
    return _fmt({"count": len(tags), "tags": tags})


@mcp.tool()
@_safe
async def create_product_tag(
    name: str,
    slug: str = "",
    description: str = "",
) -> str:
    """Create a product tag."""
    wc = get_client()
    body: dict[str, Any] = {"name": name}
    if slug:
        body["slug"] = slug
    if description:
        body["description"] = description
    t = await wc.post("/products/tags", json=body)
    return _fmt({
        "id": t.get("id", 0),
        "name": t.get("name", ""),
        "slug": t.get("slug", ""),
        "message": "Tag created.",
    })


@mcp.tool()
@_safe
async def delete_product_tag(tag_id: int) -> str:
    """Delete a product tag."""
    wc = get_client()
    await wc.delete(f"/products/tags/{tag_id}", params={"force": True})
    return _fmt({"tag_id": tag_id, "message": "Tag deleted."})


# ══════════════════════════════════════════════════════════════════════
# PRODUCT REVIEWS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_product_reviews(
    product_id: int = 0,
    status: str = "",
    per_page: int = 20,
    page: int = 1,
) -> str:
    """List product reviews. Optionally filter by product_id or status (approved, hold, spam, unspam, trash, untrash)."""
    wc = get_client()
    params: dict[str, Any] = {"per_page": min(per_page, 100), "page": page}
    if product_id:
        params["product"] = [product_id]
    if status:
        params["status"] = status
    data = await wc.get("/products/reviews", params=params)
    reviews = []
    for r in _list(data):
        reviews.append({
            "id": r.get("id", 0),
            "product_id": r.get("product_id", 0),
            "reviewer": r.get("reviewer", ""),
            "reviewer_email": r.get("reviewer_email", ""),
            "review": r.get("review", ""),
            "rating": r.get("rating", 0),
            "verified": r.get("verified", False),
            "status": r.get("status", ""),
            "created_at": r.get("date_created", ""),
        })
    return _fmt({"count": len(reviews), "reviews": reviews})


@mcp.tool()
@_safe
async def get_product_review(review_id: int) -> str:
    """Get full details for a product review."""
    wc = get_client()
    r = await wc.get(f"/products/reviews/{review_id}")
    return _fmt({
        "id": r.get("id", 0),
        "product_id": r.get("product_id", 0),
        "reviewer": r.get("reviewer", ""),
        "reviewer_email": r.get("reviewer_email", ""),
        "review": r.get("review", ""),
        "rating": r.get("rating", 0),
        "verified": r.get("verified", False),
        "status": r.get("status", ""),
        "created_at": r.get("date_created", ""),
    })


@mcp.tool()
@_safe
async def create_product_review(
    product_id: int,
    review: str,
    reviewer: str,
    reviewer_email: str,
    rating: int = 5,
) -> str:
    """Create a product review. Rating: 1-5."""
    wc = get_client()
    r = await wc.post("/products/reviews", json={
        "product_id": product_id,
        "review": review,
        "reviewer": reviewer,
        "reviewer_email": reviewer_email,
        "rating": min(max(rating, 1), 5),
    })
    return _fmt({
        "id": r.get("id", 0),
        "product_id": product_id,
        "rating": r.get("rating", 0),
        "message": "Review created.",
    })


@mcp.tool()
@_safe
async def delete_product_review(review_id: int, force: bool = True) -> str:
    """Delete a product review."""
    wc = get_client()
    await wc.delete(f"/products/reviews/{review_id}", params={"force": force})
    return _fmt({"review_id": review_id, "message": "Review deleted."})


# ══════════════════════════════════════════════════════════════════════
# ORDERS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_orders(
    status: str = "",
    customer: int = 0,
    after: str = "",
    before: str = "",
    per_page: int = 20,
    page: int = 1,
) -> str:
    """List orders. Filter by status (pending, processing, on-hold, completed, cancelled, refunded, failed), customer ID, or date range (ISO 8601)."""
    wc = get_client()
    params: dict[str, Any] = {"per_page": min(per_page, 100), "page": page}
    if status:
        params["status"] = status
    if customer:
        params["customer"] = customer
    if after:
        params["after"] = after
    if before:
        params["before"] = before
    data = await wc.get("/orders", params=params)
    orders = []
    for o in _list(data):
        billing = o.get("billing", {})
        orders.append({
            "id": o.get("id", 0),
            "number": o.get("number", ""),
            "status": o.get("status", ""),
            "total": o.get("total", ""),
            "currency": o.get("currency", ""),
            "customer_id": o.get("customer_id", 0),
            "billing_email": billing.get("email", ""),
            "billing_name": f"{billing.get('first_name', '')} {billing.get('last_name', '')}".strip(),
            "items_count": len(o.get("line_items", [])),
            "payment_method": o.get("payment_method_title", ""),
            "created_at": o.get("date_created", ""),
        })
    return _fmt({"count": len(orders), "orders": orders})


@mcp.tool()
@_safe
async def get_order(order_id: int) -> str:
    """Get full details for an order including line items, shipping, billing, and payment info."""
    wc = get_client()
    o = await wc.get(f"/orders/{order_id}")
    billing = o.get("billing", {})
    shipping = o.get("shipping", {})
    items = []
    for li in o.get("line_items", []):
        items.append({
            "product_id": li.get("product_id", 0),
            "name": li.get("name", ""),
            "quantity": li.get("quantity", 0),
            "subtotal": li.get("subtotal", ""),
            "total": li.get("total", ""),
            "sku": li.get("sku", ""),
        })
    return _fmt({
        "id": o.get("id", 0),
        "number": o.get("number", ""),
        "status": o.get("status", ""),
        "total": o.get("total", ""),
        "subtotal": o.get("subtotal", ""),
        "total_tax": o.get("total_tax", ""),
        "discount_total": o.get("discount_total", ""),
        "shipping_total": o.get("shipping_total", ""),
        "currency": o.get("currency", ""),
        "payment_method": o.get("payment_method_title", ""),
        "transaction_id": o.get("transaction_id", ""),
        "customer_id": o.get("customer_id", 0),
        "billing": {
            "name": f"{billing.get('first_name', '')} {billing.get('last_name', '')}".strip(),
            "email": billing.get("email", ""),
            "phone": billing.get("phone", ""),
            "address": billing.get("address_1", ""),
            "city": billing.get("city", ""),
            "state": billing.get("state", ""),
            "postcode": billing.get("postcode", ""),
            "country": billing.get("country", ""),
        },
        "shipping": {
            "name": f"{shipping.get('first_name', '')} {shipping.get('last_name', '')}".strip(),
            "address": shipping.get("address_1", ""),
            "city": shipping.get("city", ""),
            "state": shipping.get("state", ""),
            "postcode": shipping.get("postcode", ""),
            "country": shipping.get("country", ""),
        },
        "line_items": items,
        "coupon_lines": [
            {"code": c.get("code", ""), "discount": c.get("discount", "")}
            for c in o.get("coupon_lines", [])
        ],
        "customer_note": o.get("customer_note", ""),
        "created_at": o.get("date_created", ""),
        "completed_at": o.get("date_completed"),
    })


@mcp.tool()
@_safe
async def create_order(
    customer_id: int = 0,
    status: str = "pending",
    line_items: str = "",
    billing_email: str = "",
    billing_first_name: str = "",
    billing_last_name: str = "",
    payment_method: str = "",
    note: str = "",
) -> str:
    """Create an order. line_items: JSON array of {product_id, quantity} objects. Example: '[{"product_id": 42, "quantity": 2}]'"""
    wc = get_client()
    body: dict[str, Any] = {"status": status}
    if customer_id:
        body["customer_id"] = customer_id
    if line_items:
        try:
            body["line_items"] = json.loads(line_items)
        except json.JSONDecodeError as e:
            return f"Invalid line_items JSON: {e}"
    billing: dict[str, str] = {}
    if billing_email:
        billing["email"] = billing_email
    if billing_first_name:
        billing["first_name"] = billing_first_name
    if billing_last_name:
        billing["last_name"] = billing_last_name
    if billing:
        body["billing"] = billing
    if payment_method:
        body["payment_method"] = payment_method
    if note:
        body["customer_note"] = note
    o = await wc.post("/orders", json=body)
    return _fmt({
        "id": o.get("id", 0),
        "number": o.get("number", ""),
        "status": o.get("status", ""),
        "total": o.get("total", ""),
        "message": "Order created.",
    })


@mcp.tool()
@_safe
async def update_order_status(order_id: int, status: str) -> str:
    """Update an order's status. Status: pending, processing, on-hold, completed, cancelled, refunded, failed."""
    wc = get_client()
    o = await wc.put(f"/orders/{order_id}", json={"status": status})
    return _fmt({
        "id": o.get("id", 0),
        "number": o.get("number", ""),
        "status": o.get("status", ""),
        "message": f"Order status updated to '{status}'.",
    })


@mcp.tool()
@_safe
async def update_order(
    order_id: int,
    billing: str = "",
    shipping: str = "",
    customer_note: str = "",
) -> str:
    """Update an order's billing/shipping addresses or customer note. billing/shipping: JSON objects with address fields. Example: '{"email": "new@email.com", "phone": "555-0123", "address_1": "123 Main St"}'"""
    wc = get_client()
    body: dict[str, Any] = {}
    if billing:
        try:
            body["billing"] = json.loads(billing)
        except json.JSONDecodeError as e:
            return f"Invalid billing JSON: {e}"
    if shipping:
        try:
            body["shipping"] = json.loads(shipping)
        except json.JSONDecodeError as e:
            return f"Invalid shipping JSON: {e}"
    if customer_note:
        body["customer_note"] = customer_note
    if not body:
        return "No fields provided to update. Use update_order_status to change status."
    o = await wc.put(f"/orders/{order_id}", json=body)
    return _fmt({
        "id": o.get("id", 0),
        "number": o.get("number", ""),
        "status": o.get("status", ""),
        "updated_fields": list(body.keys()),
        "message": "Order updated.",
    })


@mcp.tool()
@_safe
async def delete_order(order_id: int, force: bool = False) -> str:
    """Delete an order. Set force=True for permanent deletion (bypass trash)."""
    wc = get_client()
    await wc.delete(f"/orders/{order_id}", params={"force": force})
    return _fmt({
        "order_id": order_id,
        "permanent": force,
        "message": "Order deleted." if force else "Order moved to trash.",
    })


@mcp.tool()
@_safe
async def list_order_notes(order_id: int) -> str:
    """List all notes on an order (internal staff notes and customer-facing notes)."""
    wc = get_client()
    data = await wc.get(f"/orders/{order_id}/notes")
    notes = []
    for n in _list(data):
        notes.append({
            "id": n.get("id", 0),
            "note": n.get("note", ""),
            "customer_note": n.get("customer_note", False),
            "author": n.get("author", ""),
            "created_at": n.get("date_created", ""),
        })
    return _fmt({"order_id": order_id, "count": len(notes), "notes": notes})


@mcp.tool()
@_safe
async def create_order_note(
    order_id: int,
    note: str,
    customer_note: bool = False,
) -> str:
    """Add a note to an order. Set customer_note=True to make it visible to the customer."""
    wc = get_client()
    n = await wc.post(
        f"/orders/{order_id}/notes",
        json={"note": note, "customer_note": customer_note},
    )
    return _fmt({
        "id": n.get("id", 0),
        "order_id": order_id,
        "customer_note": customer_note,
        "message": "Note added.",
    })


@mcp.tool()
@_safe
async def create_refund(
    order_id: int,
    amount: str,
    reason: str = "",
) -> str:
    """Create a refund for an order. Amount as string (e.g. '25.00')."""
    wc = get_client()
    body: dict[str, Any] = {"amount": amount}
    if reason:
        body["reason"] = reason
    r = await wc.post(f"/orders/{order_id}/refunds", json=body)
    return _fmt({
        "id": r.get("id", 0),
        "order_id": order_id,
        "amount": r.get("amount", ""),
        "reason": r.get("reason", ""),
        "message": "Refund created.",
    })


@mcp.tool()
@_safe
async def list_refunds(order_id: int) -> str:
    """List all refunds for an order."""
    wc = get_client()
    data = await wc.get(f"/orders/{order_id}/refunds")
    refunds = []
    for r in _list(data):
        refunds.append({
            "id": r.get("id", 0),
            "amount": r.get("amount", ""),
            "reason": r.get("reason", ""),
            "refunded_by": r.get("refunded_by", 0),
            "created_at": r.get("date_created", ""),
        })
    return _fmt({"order_id": order_id, "count": len(refunds), "refunds": refunds})


# ══════════════════════════════════════════════════════════════════════
# CUSTOMERS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_customers(
    role: str = "",
    search: str = "",
    per_page: int = 20,
    page: int = 1,
    orderby: str = "registered_date",
    order: str = "desc",
) -> str:
    """List customers. Filter by role (all, administrator, customer) or search by name/email. Orderby: id, include, name, registered_date."""
    wc = get_client()
    params: dict[str, Any] = {
        "per_page": min(per_page, 100),
        "page": page,
        "orderby": orderby,
        "order": order,
    }
    if role:
        params["role"] = role
    if search:
        params["search"] = search
    data = await wc.get("/customers", params=params)
    customers = []
    for c in _list(data):
        customers.append({
            "id": c.get("id", 0),
            "email": c.get("email", ""),
            "name": f"{c.get('first_name', '')} {c.get('last_name', '')}".strip(),
            "username": c.get("username", ""),
            "orders_count": c.get("orders_count", 0),
            "total_spent": c.get("total_spent", ""),
            "avatar_url": c.get("avatar_url", ""),
            "registered_at": c.get("date_created", ""),
        })
    return _fmt({"count": len(customers), "customers": customers})


@mcp.tool()
@_safe
async def get_customer(customer_id: int) -> str:
    """Get full details for a customer including billing/shipping addresses and order stats."""
    wc = get_client()
    c = await wc.get(f"/customers/{customer_id}")
    billing = c.get("billing", {})
    shipping = c.get("shipping", {})
    return _fmt({
        "id": c.get("id", 0),
        "email": c.get("email", ""),
        "first_name": c.get("first_name", ""),
        "last_name": c.get("last_name", ""),
        "username": c.get("username", ""),
        "role": c.get("role", ""),
        "orders_count": c.get("orders_count", 0),
        "total_spent": c.get("total_spent", ""),
        "billing": {
            "email": billing.get("email", ""),
            "phone": billing.get("phone", ""),
            "address": billing.get("address_1", ""),
            "city": billing.get("city", ""),
            "state": billing.get("state", ""),
            "postcode": billing.get("postcode", ""),
            "country": billing.get("country", ""),
        },
        "shipping": {
            "address": shipping.get("address_1", ""),
            "city": shipping.get("city", ""),
            "state": shipping.get("state", ""),
            "postcode": shipping.get("postcode", ""),
            "country": shipping.get("country", ""),
        },
        "registered_at": c.get("date_created", ""),
        "last_active": c.get("date_modified", ""),
    })


@mcp.tool()
@_safe
async def create_customer(
    email: str,
    first_name: str = "",
    last_name: str = "",
    username: str = "",
) -> str:
    """Create a new customer. Only email is required."""
    wc = get_client()
    body: dict[str, Any] = {"email": email}
    if first_name:
        body["first_name"] = first_name
    if last_name:
        body["last_name"] = last_name
    if username:
        body["username"] = username
    c = await wc.post("/customers", json=body)
    return _fmt({
        "id": c.get("id", 0),
        "email": c.get("email", ""),
        "username": c.get("username", ""),
        "message": "Customer created.",
    })


@mcp.tool()
@_safe
async def update_customer(
    customer_id: int,
    email: str = "",
    first_name: str = "",
    last_name: str = "",
    billing: str = "",
    shipping: str = "",
) -> str:
    """Update a customer. billing/shipping: JSON objects with address fields. Example: '{"phone": "555-0123", "address_1": "123 Main St", "city": "Austin"}'"""
    wc = get_client()
    body: dict[str, Any] = {}
    if email:
        body["email"] = email
    if first_name:
        body["first_name"] = first_name
    if last_name:
        body["last_name"] = last_name
    if billing:
        try:
            body["billing"] = json.loads(billing)
        except json.JSONDecodeError as e:
            return f"Invalid billing JSON: {e}"
    if shipping:
        try:
            body["shipping"] = json.loads(shipping)
        except json.JSONDecodeError as e:
            return f"Invalid shipping JSON: {e}"
    if not body:
        return "No fields provided to update."
    c = await wc.put(f"/customers/{customer_id}", json=body)
    return _fmt({
        "id": c.get("id", 0),
        "email": c.get("email", ""),
        "name": f"{c.get('first_name', '')} {c.get('last_name', '')}".strip(),
        "updated_fields": list(body.keys()),
        "message": "Customer updated.",
    })


@mcp.tool()
@_safe
async def delete_customer(customer_id: int, reassign: int = 0) -> str:
    """Delete a customer. Set reassign to another customer ID to transfer their orders."""
    wc = get_client()
    params: dict[str, Any] = {"force": True}
    if reassign:
        params["reassign"] = reassign
    await wc.delete(f"/customers/{customer_id}", params=params)
    return _fmt({"customer_id": customer_id, "message": "Customer deleted."})


@mcp.tool()
@_safe
async def search_customers(query: str, per_page: int = 20) -> str:
    """Search customers by name or email."""
    wc = get_client()
    data = await wc.get("/customers", params={
        "search": query,
        "per_page": min(per_page, 100),
    })
    customers = []
    for c in _list(data):
        customers.append({
            "id": c.get("id", 0),
            "email": c.get("email", ""),
            "name": f"{c.get('first_name', '')} {c.get('last_name', '')}".strip(),
            "orders_count": c.get("orders_count", 0),
            "total_spent": c.get("total_spent", ""),
        })
    return _fmt({"query": query, "count": len(customers), "customers": customers})


# ══════════════════════════════════════════════════════════════════════
# COUPONS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_coupons(
    search: str = "",
    per_page: int = 20,
    page: int = 1,
) -> str:
    """List coupons. Optionally search by code."""
    wc = get_client()
    params: dict[str, Any] = {"per_page": min(per_page, 100), "page": page}
    if search:
        params["search"] = search
    data = await wc.get("/coupons", params=params)
    coupons = []
    for c in _list(data):
        coupons.append({
            "id": c.get("id", 0),
            "code": c.get("code", ""),
            "discount_type": c.get("discount_type", ""),
            "amount": c.get("amount", ""),
            "usage_count": c.get("usage_count", 0),
            "usage_limit": c.get("usage_limit"),
            "expiry_date": c.get("date_expires"),
            "free_shipping": c.get("free_shipping", False),
        })
    return _fmt({"count": len(coupons), "coupons": coupons})


@mcp.tool()
@_safe
async def get_coupon(coupon_id: int) -> str:
    """Get full details for a coupon."""
    wc = get_client()
    c = await wc.get(f"/coupons/{coupon_id}")
    return _fmt({
        "id": c.get("id", 0),
        "code": c.get("code", ""),
        "discount_type": c.get("discount_type", ""),
        "amount": c.get("amount", ""),
        "free_shipping": c.get("free_shipping", False),
        "expiry_date": c.get("date_expires"),
        "minimum_amount": c.get("minimum_amount", ""),
        "maximum_amount": c.get("maximum_amount", ""),
        "usage_count": c.get("usage_count", 0),
        "usage_limit": c.get("usage_limit"),
        "usage_limit_per_user": c.get("usage_limit_per_user"),
        "individual_use": c.get("individual_use", False),
        "exclude_sale_items": c.get("exclude_sale_items", False),
        "product_ids": c.get("product_ids", []),
        "excluded_product_ids": c.get("excluded_product_ids", []),
        "email_restrictions": c.get("email_restrictions", []),
        "created_at": c.get("date_created", ""),
    })


@mcp.tool()
@_safe
async def create_coupon(
    code: str,
    discount_type: str = "percent",
    amount: str = "10",
    free_shipping: bool = False,
    expiry_date: str = "",
    usage_limit: int = 0,
    minimum_amount: str = "",
    individual_use: bool = False,
) -> str:
    """Create a coupon. discount_type: percent, fixed_cart, fixed_product. Amount as string (e.g. '10' for 10% or $10)."""
    wc = get_client()
    body: dict[str, Any] = {
        "code": code,
        "discount_type": discount_type,
        "amount": amount,
    }
    if free_shipping:
        body["free_shipping"] = True
    if expiry_date:
        body["date_expires"] = expiry_date
    if usage_limit:
        body["usage_limit"] = usage_limit
    if minimum_amount:
        body["minimum_amount"] = minimum_amount
    if individual_use:
        body["individual_use"] = True
    c = await wc.post("/coupons", json=body)
    return _fmt({
        "id": c.get("id", 0),
        "code": c.get("code", ""),
        "discount_type": c.get("discount_type", ""),
        "amount": c.get("amount", ""),
        "message": "Coupon created.",
    })


@mcp.tool()
@_safe
async def update_coupon(
    coupon_id: int,
    code: str = "",
    amount: str = "",
    discount_type: str = "",
    expiry_date: str = "",
    usage_limit: int = -1,
    minimum_amount: str = "",
    free_shipping: bool | None = None,
    individual_use: bool | None = None,
) -> str:
    """Update a coupon. Only provide fields to change. Use this to extend expiry dates, change amounts, etc."""
    wc = get_client()
    body: dict[str, Any] = {}
    if code:
        body["code"] = code
    if amount:
        body["amount"] = amount
    if discount_type:
        body["discount_type"] = discount_type
    if expiry_date:
        body["date_expires"] = expiry_date
    if usage_limit >= 0:
        body["usage_limit"] = usage_limit
    if minimum_amount:
        body["minimum_amount"] = minimum_amount
    if free_shipping is not None:
        body["free_shipping"] = free_shipping
    if individual_use is not None:
        body["individual_use"] = individual_use
    if not body:
        return "No fields provided to update."
    c = await wc.put(f"/coupons/{coupon_id}", json=body)
    return _fmt({
        "id": c.get("id", 0),
        "code": c.get("code", ""),
        "amount": c.get("amount", ""),
        "discount_type": c.get("discount_type", ""),
        "updated_fields": list(body.keys()),
        "message": "Coupon updated.",
    })


@mcp.tool()
@_safe
async def delete_coupon(coupon_id: int, force: bool = True) -> str:
    """Delete a coupon. force=True for permanent deletion."""
    wc = get_client()
    await wc.delete(f"/coupons/{coupon_id}", params={"force": force})
    return _fmt({"coupon_id": coupon_id, "message": "Coupon deleted."})


# ══════════════════════════════════════════════════════════════════════
# REPORTS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def get_sales_report(
    period: str = "month",
    date_min: str = "",
    date_max: str = "",
) -> str:
    """Get sales report. Period: week, month, last_month, year. Or provide date_min/date_max (YYYY-MM-DD)."""
    wc = get_client()
    params: dict[str, Any] = {"period": period}
    if date_min:
        params["date_min"] = date_min
    if date_max:
        params["date_max"] = date_max
    data = await wc.get("/reports/sales", params=params)
    r = data[0] if isinstance(data, list) and data else data if isinstance(data, dict) else {}
    return _fmt({
        "total_sales": r.get("total_sales", ""),
        "net_sales": r.get("net_sales", ""),
        "average_sales": r.get("average_sales", ""),
        "total_orders": r.get("total_orders", 0),
        "total_items": r.get("total_items", 0),
        "total_tax": r.get("total_tax", ""),
        "total_shipping": r.get("total_shipping", ""),
        "total_refunds": r.get("total_refunds", 0),
        "total_discount": r.get("total_discount", ""),
        "total_customers": r.get("total_customers", 0),
        "period": period,
    })


@mcp.tool()
@_safe
async def get_top_sellers(period: str = "month") -> str:
    """Get top-selling products. Period: week, month, last_month, year."""
    wc = get_client()
    data = await wc.get("/reports/top_sellers", params={"period": period})
    products = []
    for p in _list(data):
        products.append({
            "product_id": p.get("product_id", 0),
            "title": p.get("title", ""),
            "quantity": p.get("quantity", 0),
        })
    return _fmt({"period": period, "count": len(products), "top_sellers": products})


@mcp.tool()
@_safe
async def get_order_totals() -> str:
    """Get order counts by status (pending, processing, completed, etc.)."""
    wc = get_client()
    data = await wc.get("/reports/orders/totals")
    totals = []
    for t in _list(data):
        totals.append({
            "slug": t.get("slug", ""),
            "name": t.get("name", ""),
            "total": t.get("total", 0),
        })
    return _fmt({"order_totals": totals})


@mcp.tool()
@_safe
async def get_product_totals() -> str:
    """Get product counts by type (simple, variable, grouped, external)."""
    wc = get_client()
    data = await wc.get("/reports/products/totals")
    totals = []
    for t in _list(data):
        totals.append({
            "slug": t.get("slug", ""),
            "name": t.get("name", ""),
            "total": t.get("total", 0),
        })
    return _fmt({"product_totals": totals})


# ══════════════════════════════════════════════════════════════════════
# SETTINGS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def get_store_settings(group: str = "general") -> str:
    """Read store settings by group. Groups: general, products, tax, shipping, checkout, account, email, advanced."""
    wc = get_client()
    data = await wc.get(f"/settings/{group}")
    settings = []
    for s in _list(data):
        settings.append({
            "id": s.get("id", ""),
            "label": s.get("label", ""),
            "value": s.get("value", ""),
            "type": s.get("type", ""),
            "description": s.get("description", ""),
        })
    return _fmt({"group": group, "count": len(settings), "settings": settings})


# ══════════════════════════════════════════════════════════════════════
# SHIPPING & PAYMENTS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_shipping_zones() -> str:
    """List all shipping zones with their methods."""
    wc = get_client()
    zones = await wc.get("/shipping/zones")
    result = []
    for z in _list(zones):
        zone_id = z.get("id", 0)
        methods = await wc.get(f"/shipping/zones/{zone_id}/methods")
        result.append({
            "id": zone_id,
            "name": z.get("name", ""),
            "order": z.get("order", 0),
            "methods": [
                {
                    "id": m.get("id", 0),
                    "title": m.get("title", ""),
                    "method_id": m.get("method_id", ""),
                    "enabled": m.get("enabled", False),
                }
                for m in _list(methods)
            ],
        })
    return _fmt({"count": len(result), "shipping_zones": result})


@mcp.tool()
@_safe
async def list_payment_gateways() -> str:
    """List all payment gateways with their enabled status and settings."""
    wc = get_client()
    data = await wc.get("/payment_gateways")
    gateways = []
    for g in _list(data):
        gateways.append({
            "id": g.get("id", ""),
            "title": g.get("title", ""),
            "description": g.get("description", ""),
            "enabled": g.get("enabled", False),
            "method_title": g.get("method_title", ""),
            "order": g.get("order", ""),
        })
    return _fmt({"count": len(gateways), "payment_gateways": gateways})


@mcp.tool()
@_safe
async def list_tax_rates(per_page: int = 50, page: int = 1) -> str:
    """List all tax rates."""
    wc = get_client()
    data = await wc.get("/taxes", params={
        "per_page": min(per_page, 100),
        "page": page,
    })
    rates = []
    for r in _list(data):
        rates.append({
            "id": r.get("id", 0),
            "country": r.get("country", ""),
            "state": r.get("state", ""),
            "postcode": r.get("postcode", ""),
            "city": r.get("city", ""),
            "rate": r.get("rate", ""),
            "name": r.get("name", ""),
            "shipping": r.get("shipping", False),
            "class": r.get("class", "standard"),
        })
    return _fmt({"count": len(rates), "tax_rates": rates})


@mcp.tool()
@_safe
async def list_tax_classes() -> str:
    """List all tax classes (e.g. Standard, Reduced rate, Zero rate)."""
    wc = get_client()
    data = await wc.get("/taxes/classes")
    classes = []
    for c in _list(data):
        classes.append({
            "slug": c.get("slug", ""),
            "name": c.get("name", ""),
        })
    return _fmt({"count": len(classes), "tax_classes": classes})


@mcp.tool()
@_safe
async def list_shipping_classes() -> str:
    """List all product shipping classes (e.g. Bulky, Fragile, Standard)."""
    wc = get_client()
    data = await wc.get("/products/shipping_classes")
    classes = []
    for c in _list(data):
        classes.append({
            "id": c.get("id", 0),
            "name": c.get("name", ""),
            "slug": c.get("slug", ""),
            "description": c.get("description", ""),
            "count": c.get("count", 0),
        })
    return _fmt({"count": len(classes), "shipping_classes": classes})


# ══════════════════════════════════════════════════════════════════════
# WEBHOOKS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_webhooks(per_page: int = 20, page: int = 1) -> str:
    """List all webhooks."""
    wc = get_client()
    data = await wc.get("/webhooks", params={
        "per_page": min(per_page, 100),
        "page": page,
    })
    hooks = []
    for h in _list(data):
        hooks.append({
            "id": h.get("id", 0),
            "name": h.get("name", ""),
            "status": h.get("status", ""),
            "topic": h.get("topic", ""),
            "delivery_url": h.get("delivery_url", ""),
            "created_at": h.get("date_created", ""),
        })
    return _fmt({"count": len(hooks), "webhooks": hooks})


@mcp.tool()
@_safe
async def create_webhook(
    name: str,
    topic: str,
    delivery_url: str,
    secret: str = "",
    status: str = "active",
) -> str:
    """Create a webhook. Topics: order.created, order.updated, order.deleted, product.created, product.updated, product.deleted, customer.created, customer.updated, coupon.created, coupon.updated, etc."""
    wc = get_client()
    body: dict[str, Any] = {
        "name": name,
        "topic": topic,
        "delivery_url": delivery_url,
        "status": status,
    }
    if secret:
        body["secret"] = secret
    h = await wc.post("/webhooks", json=body)
    return _fmt({
        "id": h.get("id", 0),
        "name": h.get("name", ""),
        "topic": h.get("topic", ""),
        "delivery_url": h.get("delivery_url", ""),
        "status": h.get("status", ""),
        "message": "Webhook created.",
    })


@mcp.tool()
@_safe
async def update_webhook(
    webhook_id: int,
    name: str = "",
    delivery_url: str = "",
    topic: str = "",
    status: str = "",
    secret: str = "",
) -> str:
    """Update a webhook. Only provide fields to change. Status: active, paused, disabled."""
    wc = get_client()
    body: dict[str, Any] = {}
    if name:
        body["name"] = name
    if delivery_url:
        body["delivery_url"] = delivery_url
    if topic:
        body["topic"] = topic
    if status:
        body["status"] = status
    if secret:
        body["secret"] = secret
    if not body:
        return "No fields provided to update."
    h = await wc.put(f"/webhooks/{webhook_id}", json=body)
    return _fmt({
        "id": h.get("id", 0),
        "name": h.get("name", ""),
        "topic": h.get("topic", ""),
        "status": h.get("status", ""),
        "updated_fields": list(body.keys()),
        "message": "Webhook updated.",
    })


@mcp.tool()
@_safe
async def delete_webhook(webhook_id: int, force: bool = True) -> str:
    """Delete a webhook."""
    wc = get_client()
    await wc.delete(f"/webhooks/{webhook_id}", params={"force": force})
    return _fmt({"webhook_id": webhook_id, "message": "Webhook deleted."})


# ══════════════════════════════════════════════════════════════════════
# BATCH OPERATIONS
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def batch_update_products(updates: str) -> str:
    """Bulk update products. updates: JSON array of objects with 'id' and fields to change. Example: '[{"id": 1, "regular_price": "19.99"}, {"id": 2, "status": "draft"}]'"""
    wc = get_client()
    try:
        items = json.loads(updates)
    except json.JSONDecodeError as e:
        return f"Invalid JSON: {e}"
    if not isinstance(items, list):
        return "updates must be a JSON array."
    result = await wc.post("/products/batch", json={"update": items})
    updated = result.get("update", []) if isinstance(result, dict) else []
    return _fmt({
        "updated": len(updated),
        "products": [
            {"id": p.get("id", 0), "name": p.get("name", ""), "status": p.get("status", "")}
            for p in updated
        ],
        "message": f"Batch updated {len(updated)} products.",
    })


@mcp.tool()
@_safe
async def batch_update_orders(updates: str) -> str:
    """Bulk update orders. updates: JSON array of objects with 'id' and fields to change. Example: '[{"id": 100, "status": "completed"}, {"id": 101, "status": "processing"}]'"""
    wc = get_client()
    try:
        items = json.loads(updates)
    except json.JSONDecodeError as e:
        return f"Invalid JSON: {e}"
    if not isinstance(items, list):
        return "updates must be a JSON array."
    result = await wc.post("/orders/batch", json={"update": items})
    updated = result.get("update", []) if isinstance(result, dict) else []
    return _fmt({
        "updated": len(updated),
        "orders": [
            {"id": o.get("id", 0), "number": o.get("number", ""), "status": o.get("status", "")}
            for o in updated
        ],
        "message": f"Batch updated {len(updated)} orders.",
    })


# ══════════════════════════════════════════════════════════════════════
# DATA
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def list_currencies() -> str:
    """List all currencies supported by WooCommerce with codes and symbols."""
    wc = get_client()
    data = await wc.get("/data/currencies")
    currencies = []
    for c in _list(data):
        currencies.append({
            "code": c.get("code", ""),
            "name": c.get("name", ""),
            "symbol": c.get("symbol", ""),
        })
    return _fmt({"count": len(currencies), "currencies": currencies})


@mcp.tool()
@_safe
async def list_countries() -> str:
    """List all countries with their states/provinces. Useful for configuring shipping zones and tax rates."""
    wc = get_client()
    data = await wc.get("/data/countries")
    countries = []
    for c in _list(data):
        countries.append({
            "code": c.get("code", ""),
            "name": c.get("name", ""),
            "states": [
                {"code": s.get("code", ""), "name": s.get("name", "")}
                for s in c.get("states", [])
            ],
        })
    return _fmt({"count": len(countries), "countries": countries})


# ══════════════════════════════════════════════════════════════════════
# SYSTEM
# ══════════════════════════════════════════════════════════════════════


@mcp.tool()
@_safe
async def get_system_status() -> str:
    """Get WooCommerce system status — versions, database, active plugins, server environment, and store diagnostics."""
    wc = get_client()
    data = await wc.get("/system_status")
    env = data.get("environment", {})
    db = data.get("database", {})
    settings = data.get("settings", {})
    active_plugins = [
        {"name": p.get("name", ""), "version": p.get("version", "")}
        for p in data.get("active_plugins", [])
    ]
    return _fmt({
        "environment": {
            "wc_version": env.get("version", ""),
            "wp_version": env.get("wp_version", ""),
            "php_version": env.get("php_version", ""),
            "server_info": env.get("server_info", ""),
            "max_upload_size": env.get("max_upload_size", 0),
            "wp_memory_limit": env.get("wp_memory_limit", 0),
            "wp_debug_mode": env.get("wp_debug_mode", False),
        },
        "database": {
            "wc_database_version": db.get("wc_database_version", ""),
            "database_size": db.get("database_size", {}),
        },
        "store_settings": {
            "currency": settings.get("currency", ""),
            "currency_symbol": settings.get("currency_symbol", ""),
            "taxonomies": settings.get("taxonomies", {}),
        },
        "active_plugins_count": len(active_plugins),
        "active_plugins": active_plugins[:20],
    })


# ══════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════════════════════════════


def main() -> None:
    standby_port = os.environ.get("ACTOR_STANDBY_PORT")
    if standby_port:
        os.environ.setdefault("FASTMCP_HOST", "0.0.0.0")
        os.environ.setdefault("FASTMCP_PORT", standby_port)
        os.environ.setdefault("FASTMCP_STREAMABLE_HTTP_PATH", "/mcp")
        mcp.run(transport="streamable-http")
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
