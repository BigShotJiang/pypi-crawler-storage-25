"""Allow running as: python -m mcp_woocommerce"""

import os


def _load_apify_input() -> None:
    """Load credentials from Apify actor input when running on the platform."""
    token = os.environ.get("APIFY_TOKEN", "")
    store_id = os.environ.get("APIFY_DEFAULT_KEY_VALUE_STORE_ID", "")
    if not (token and store_id):
        return

    import httpx

    try:
        resp = httpx.get(
            f"https://api.apify.com/v2/key-value-stores/{store_id}/records/INPUT",
            headers={"Authorization": f"Bearer {token}"},
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            if data.get("woocommerceUrl"):
                os.environ["WOOCOMMERCE_URL"] = data["woocommerceUrl"]
            if data.get("woocommerceKey"):
                os.environ["WOOCOMMERCE_KEY"] = data["woocommerceKey"]
            if data.get("woocommerceSecret"):
                os.environ["WOOCOMMERCE_SECRET"] = data["woocommerceSecret"]
    except Exception:
        pass


if os.environ.get("ACTOR_STANDBY_PORT"):
    _load_apify_input()

from mcp_woocommerce.server import main

main()
