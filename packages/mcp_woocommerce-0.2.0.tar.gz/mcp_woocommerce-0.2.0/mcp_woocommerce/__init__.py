"""MCP server for the WooCommerce REST API."""

__version__ = "0.2.0"
