"""Tests for mcp-woocommerce server — tool registration, client validation, and helpers."""

import json
import os
import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from mcp_woocommerce.client import WooCommerceClient, WooCommerceError
from mcp_woocommerce import server


# ── Client Tests ─────────────────────────────────────────────────────


class TestWooCommerceClient:
    def test_base_url_construction(self):
        client = WooCommerceClient(
            "https://mystore.com", "ck_test", "cs_test"
        )
        assert client.base_url == "https://mystore.com/wp-json/wc/v3"

    def test_base_url_trailing_slash(self):
        client = WooCommerceClient(
            "https://mystore.com/", "ck_test", "cs_test"
        )
        assert client.base_url == "https://mystore.com/wp-json/wc/v3"

    def test_base_url_already_has_api_path(self):
        client = WooCommerceClient(
            "https://mystore.com/wp-json/wc/v3", "ck_test", "cs_test"
        )
        assert client.base_url == "https://mystore.com/wp-json/wc/v3"

    def test_store_url_stored(self):
        client = WooCommerceClient(
            "https://mystore.com/", "ck_test", "cs_test"
        )
        assert client.store_url == "https://mystore.com"

    def test_bare_domain_gets_https(self):
        client = WooCommerceClient(
            "mystore.com", "ck_test", "cs_test"
        )
        assert client.base_url == "https://mystore.com/wp-json/wc/v3"


class TestWooCommerceError:
    def test_error_format(self):
        err = WooCommerceError("woocommerce_rest_invalid_id", "Invalid ID.", 404)
        assert err.code == "woocommerce_rest_invalid_id"
        assert err.message == "Invalid ID."
        assert err.status == 404
        assert "404" in str(err)


# ── Server Singleton Tests ───────────────────────────────────────────


class TestGetClient:
    def setup_method(self):
        server._client = None

    def teardown_method(self):
        server._client = None

    def test_missing_env_vars_raises(self):
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ValueError, match="WOOCOMMERCE_URL"):
                server.get_client()

    def test_valid_env_vars(self):
        with patch.dict(os.environ, {
            "WOOCOMMERCE_URL": "https://test.com",
            "WOOCOMMERCE_KEY": "ck_test",
            "WOOCOMMERCE_SECRET": "cs_test",
        }):
            client = server.get_client()
            assert isinstance(client, WooCommerceClient)
            assert client.store_url == "https://test.com"

    def test_singleton_returns_same_instance(self):
        with patch.dict(os.environ, {
            "WOOCOMMERCE_URL": "https://test.com",
            "WOOCOMMERCE_KEY": "ck_test",
            "WOOCOMMERCE_SECRET": "cs_test",
        }):
            c1 = server.get_client()
            c2 = server.get_client()
            assert c1 is c2


# ── Tool Registration Tests ──────────────────────────────────────────


class TestToolRegistration:
    """Verify all 73 tools are registered on the FastMCP instance."""

    def test_tool_count(self):
        tools = server.mcp._tool_manager._tools
        assert len(tools) == 73, f"Expected 73 tools, got {len(tools)}: {sorted(tools.keys())}"

    def test_original_tools_exist(self):
        tools = server.mcp._tool_manager._tools
        expected = [
            "ping",
            "list_products", "get_product", "create_product", "update_product",
            "delete_product", "search_products", "list_product_categories",
            "list_orders", "get_order", "create_order", "update_order_status",
            "list_order_notes", "create_order_note", "create_refund",
            "list_customers", "get_customer", "create_customer", "search_customers",
            "list_coupons", "get_coupon", "create_coupon", "delete_coupon",
            "get_sales_report", "get_top_sellers", "get_order_totals", "get_product_totals",
            "list_shipping_zones", "list_payment_gateways", "list_tax_rates",
            "list_webhooks", "create_webhook", "delete_webhook",
            "get_system_status",
        ]
        for name in expected:
            assert name in tools, f"Missing original tool: {name}"

    def test_new_v02_tools_exist(self):
        tools = server.mcp._tool_manager._tools
        new_tools = [
            # Categories CRUD
            "create_product_category", "update_product_category", "delete_product_category",
            # Variations
            "list_product_variations", "get_product_variation", "create_product_variation",
            "update_product_variation", "delete_product_variation",
            # Attributes
            "list_product_attributes", "get_product_attribute", "create_product_attribute",
            "update_product_attribute", "delete_product_attribute",
            # Attribute Terms
            "list_attribute_terms", "create_attribute_term", "update_attribute_term",
            "delete_attribute_term",
            # Tags
            "list_product_tags", "create_product_tag", "delete_product_tag",
            # Reviews
            "list_product_reviews", "get_product_review", "create_product_review",
            "delete_product_review",
            # Inventory
            "list_low_stock_products",
            # Orders CRUD completion
            "update_order", "delete_order",
            # Customers CRUD completion
            "update_customer", "delete_customer",
            # Coupons CRUD completion
            "update_coupon",
            # Refunds
            "list_refunds",
            # Settings
            "get_store_settings",
            # Shipping & Tax classes
            "list_tax_classes", "list_shipping_classes",
            # Webhooks CRUD completion
            "update_webhook",
            # Data
            "list_currencies", "list_countries",
            # Batch
            "batch_update_products", "batch_update_orders",
        ]
        for name in new_tools:
            assert name in tools, f"Missing new tool: {name}"


# ── Helper Tests ─────────────────────────────────────────────────────


class TestFormat:
    def test_fmt_returns_json(self):
        result = server._fmt({"key": "value"})
        assert '"key": "value"' in result

    def test_fmt_handles_non_serializable(self):
        from datetime import datetime
        result = server._fmt({"dt": datetime(2026, 1, 1)})
        assert "2026" in result


class TestList:
    def test_list_with_list(self):
        assert server._list([1, 2, 3]) == [1, 2, 3]

    def test_list_with_dict(self):
        assert server._list({"key": "value"}) == []

    def test_list_with_none(self):
        assert server._list(None) == []

    def test_list_with_string(self):
        assert server._list("not a list") == []


class TestSafeDecorator:
    """Test _safe decorator catches errors and returns JSON."""

    @pytest.mark.asyncio
    async def test_safe_catches_woocommerce_error(self):
        @server._safe
        async def failing_tool():
            raise WooCommerceError("test_error", "Something broke", 500)

        result = await failing_tool()
        data = json.loads(result)
        assert data["code"] == "test_error"
        assert data["status"] == 500
        assert "Something broke" in data["error"]

    @pytest.mark.asyncio
    async def test_safe_catches_generic_error(self):
        @server._safe
        async def failing_tool():
            raise RuntimeError("unexpected")

        result = await failing_tool()
        data = json.loads(result)
        assert "unexpected" in data["error"]

    @pytest.mark.asyncio
    async def test_safe_passes_through_on_success(self):
        @server._safe
        async def good_tool():
            return server._fmt({"ok": True})

        result = await good_tool()
        data = json.loads(result)
        assert data["ok"] is True
