# Changelog

All notable changes to `semantic-cache-lib` will be documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
This project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [0.1.0] - 2026-05-09

### Added
- `SemanticCache` core class with decorator and `get_or_set` / `aget_or_set` API
- Sync and async decorator support (auto-detects `async def`)
- `MemoryBackend` — in-memory brute-force cosine search with optional pickle persistence
- `RedisBackend` — Redis with HNSW vector index via RedisVL
- `FAISSBackend` — FAISS flat index with optional disk persistence
- `ChromaBackend` — Chroma HTTP client or in-process client
- `OpenAIEmbedder` — OpenAI text-embedding models with native async
- `HuggingFaceEmbedder` — HF Inference API (sync via requests, async via httpx)
- `SentenceTransformerEmbedder` — local on-device models via sentence-transformers
- Configurable `threshold`, `ttl`, `top_k`
- `CacheStats` dataclass with hit rate and average similarity
- `on_hit` / `on_miss` callbacks for observability
- Structured logging via `logging.getLogger("semantic_cache")`
- Env-var fallbacks for all API credentials
- Optional extras: `[openai]`, `[huggingface]`, `[transformers]`, `[redis]`, `[faiss]`, `[chroma]`, `[all]`
