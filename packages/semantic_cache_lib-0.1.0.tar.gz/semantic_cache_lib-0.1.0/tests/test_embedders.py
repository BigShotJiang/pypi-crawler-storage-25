"""Tests for embedder implementations (using mocks for external APIs)."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from semantic_cache.exceptions import EmbedderError


class TestHuggingFaceEmbedder:
    def test_requires_token(self) -> None:
        from semantic_cache.embedders.huggingface import HuggingFaceEmbedder

        with pytest.raises(EmbedderError, match="token"):
            HuggingFaceEmbedder(model="some/model", token=None)

    def test_embed_returns_flat_list(self) -> None:
        from semantic_cache.embedders.huggingface import HuggingFaceEmbedder

        mock_response = MagicMock()
        mock_response.json.return_value = [0.1, 0.2, 0.3]
        mock_response.raise_for_status = MagicMock()

        with patch("requests.post", return_value=mock_response):
            embedder = HuggingFaceEmbedder(model="some/model", token="hf_test")
            result = embedder.embed("hello")

        assert result == [0.1, 0.2, 0.3]

    def test_embed_handles_nested_list(self) -> None:
        """HF returns [[token_vec, ...]] for some models — should be averaged."""
        import numpy as np
        from semantic_cache.embedders.huggingface import HuggingFaceEmbedder

        mock_response = MagicMock()
        # Two token embeddings of dim 3
        mock_response.json.return_value = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]]
        mock_response.raise_for_status = MagicMock()

        with patch("requests.post", return_value=mock_response):
            embedder = HuggingFaceEmbedder(model="some/model", token="hf_test")
            result = embedder.embed("hello")

        expected = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=np.float32).mean(0).tolist()
        assert result == pytest.approx(expected)

    @pytest.mark.asyncio
    async def test_aembed_returns_vector(self) -> None:
        from semantic_cache.embedders.huggingface import HuggingFaceEmbedder

        mock_response = MagicMock()
        mock_response.json.return_value = [0.4, 0.5, 0.6]
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.post = AsyncMock(return_value=mock_response)

        with patch("httpx.AsyncClient", return_value=mock_client):
            embedder = HuggingFaceEmbedder(model="some/model", token="hf_test")
            result = await embedder.aembed("hello")

        assert result == [0.4, 0.5, 0.6]

    def test_api_error_raises_embedder_error(self) -> None:
        import requests
        from semantic_cache.embedders.huggingface import HuggingFaceEmbedder

        with patch("requests.post", side_effect=requests.ConnectionError("timeout")):
            embedder = HuggingFaceEmbedder(model="some/model", token="hf_test")
            with pytest.raises(EmbedderError):
                embedder.embed("hello")


class TestOpenAIEmbedder:
    def test_requires_api_key(self) -> None:
        from semantic_cache.embedders.openai import OpenAIEmbedder

        with pytest.raises(EmbedderError, match="API key"):
            OpenAIEmbedder(api_key=None)

    def test_embed_returns_vector(self) -> None:
        from semantic_cache.embedders.openai import OpenAIEmbedder

        mock_client = MagicMock()
        mock_client.embeddings.create.return_value.data = [
            MagicMock(embedding=[0.1, 0.2, 0.3])
        ]

        embedder = OpenAIEmbedder(api_key="sk-test")
        with patch.object(embedder, "_client", return_value=mock_client):
            result = embedder.embed("hello")

        assert result == [0.1, 0.2, 0.3]

    @pytest.mark.asyncio
    async def test_aembed_returns_vector(self) -> None:
        from semantic_cache.embedders.openai import OpenAIEmbedder

        mock_client = AsyncMock()
        mock_client.embeddings.create.return_value.data = [
            MagicMock(embedding=[0.7, 0.8, 0.9])
        ]

        embedder = OpenAIEmbedder(api_key="sk-test")
        with patch.object(embedder, "_async_client", return_value=mock_client):
            result = await embedder.aembed("hello")

        assert result == [0.7, 0.8, 0.9]


class TestSentenceTransformerEmbedder:
    def test_embed_returns_vector(self) -> None:
        import numpy as np
        from semantic_cache.embedders.sentence_transformers import SentenceTransformerEmbedder

        mock_model = MagicMock()
        mock_model.encode.return_value = np.array([0.1, 0.2, 0.3])

        embedder = SentenceTransformerEmbedder(model="all-MiniLM-L6-v2")
        embedder._model = mock_model

        result = embedder.embed("hello")
        assert result == pytest.approx([0.1, 0.2, 0.3])

    def test_embed_batch_calls_encode_once(self) -> None:
        import numpy as np
        from semantic_cache.embedders.sentence_transformers import SentenceTransformerEmbedder

        mock_model = MagicMock()
        mock_model.encode.return_value = np.array([[0.1, 0.2], [0.3, 0.4]])

        embedder = SentenceTransformerEmbedder()
        embedder._model = mock_model

        results = embedder.embed_batch(["hello", "world"])
        mock_model.encode.assert_called_once()
        assert len(results) == 2
