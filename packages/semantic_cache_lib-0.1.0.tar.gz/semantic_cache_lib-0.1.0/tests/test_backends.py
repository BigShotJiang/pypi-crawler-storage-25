"""Tests for backend implementations."""
from __future__ import annotations

import time

import pytest

from semantic_cache.backends.memory import MemoryBackend
from semantic_cache.similarity import cosine_similarity


class TestMemoryBackend:
    def test_store_and_search_returns_hit(self) -> None:
        backend = MemoryBackend()
        vec = [1.0, 0.0, 0.0]
        backend.store(key="k1", vector=vec, response="hello")
        results = backend.search(vec, top_k=1)
        assert len(results) == 1
        assert results[0][0] == "hello"
        assert results[0][1] == pytest.approx(1.0)

    def test_search_empty_returns_empty(self) -> None:
        backend = MemoryBackend()
        results = backend.search([1.0, 0.0], top_k=1)
        assert results == []

    def test_results_sorted_by_descending_similarity(self) -> None:
        backend = MemoryBackend()
        backend.store(key="a", vector=[1.0, 0.0, 0.0], response="a")
        backend.store(key="b", vector=[0.9, 0.1, 0.0], response="b")
        backend.store(key="c", vector=[0.0, 1.0, 0.0], response="c")

        results = backend.search([1.0, 0.0, 0.0], top_k=3)
        scores = [r[1] for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_ttl_expiry(self) -> None:
        backend = MemoryBackend()
        backend.store(key="k1", vector=[1.0, 0.0], response="expired", ttl=1)
        time.sleep(1.1)
        results = backend.search([1.0, 0.0], top_k=1)
        assert results == []

    def test_ttl_none_does_not_expire(self) -> None:
        backend = MemoryBackend()
        backend.store(key="k1", vector=[1.0, 0.0], response="forever", ttl=None)
        results = backend.search([1.0, 0.0], top_k=1)
        assert results[0][0] == "forever"

    def test_delete_removes_entry(self) -> None:
        backend = MemoryBackend()
        backend.store(key="k1", vector=[1.0, 0.0], response="to delete")
        backend.delete("k1")
        results = backend.search([1.0, 0.0], top_k=1)
        assert results == []

    def test_clear_removes_all(self) -> None:
        backend = MemoryBackend()
        backend.store(key="a", vector=[1.0, 0.0], response="a")
        backend.store(key="b", vector=[0.0, 1.0], response="b")
        backend.clear()
        assert backend.search([1.0, 0.0], top_k=5) == []

    def test_top_k_limits_results(self) -> None:
        backend = MemoryBackend()
        for i in range(5):
            backend.store(key=f"k{i}", vector=[1.0, 0.0], response=f"r{i}")
        results = backend.search([1.0, 0.0], top_k=2)
        assert len(results) == 2

    def test_persist_and_reload(self, tmp_path) -> None:
        path = str(tmp_path / "cache.pkl")
        backend = MemoryBackend(save_path=path)
        backend.store(key="k1", vector=[1.0, 0.0], response="persisted")

        reloaded = MemoryBackend(save_path=path)
        results = reloaded.search([1.0, 0.0], top_k=1)
        assert results[0][0] == "persisted"


class TestSimilarityUtil:
    def test_identical_vectors(self) -> None:
        assert cosine_similarity([1.0, 0.0], [1.0, 0.0]) == pytest.approx(1.0)

    def test_orthogonal_vectors(self) -> None:
        assert cosine_similarity([1.0, 0.0], [0.0, 1.0]) == pytest.approx(0.0)

    def test_opposite_vectors(self) -> None:
        assert cosine_similarity([1.0, 0.0], [-1.0, 0.0]) == pytest.approx(-1.0)

    def test_zero_vector_returns_zero(self) -> None:
        assert cosine_similarity([0.0, 0.0], [1.0, 0.0]) == 0.0


class TestChromaBackend:
    """Uses Chroma's ephemeral in-process client — no server required."""

    def _backend(self, name: str) -> "ChromaBackend":
        from semantic_cache.backends.chroma import ChromaBackend
        # Unique collection per test to avoid dimension conflicts in-process
        return ChromaBackend(url=None, collection=name)

    def test_store_and_search(self) -> None:
        pytest.importorskip("chromadb")
        backend = self._backend("test_store")
        vec = [1.0, 0.0, 0.0]
        backend.store(key="k1", vector=vec, response="chroma hit")
        results = backend.search(vec, top_k=1)
        assert len(results) == 1
        assert results[0][0] == "chroma hit"
        assert results[0][1] == pytest.approx(1.0, abs=1e-3)

    def test_clear(self) -> None:
        pytest.importorskip("chromadb")
        backend = self._backend("test_clear")
        vec = [1.0, 0.0, 0.0]
        backend.store(key="k1", vector=vec, response="x")
        backend.clear()
        assert backend.search(vec, top_k=1) == []

    def test_delete(self) -> None:
        pytest.importorskip("chromadb")
        backend = self._backend("test_delete")
        vec = [1.0, 0.0, 0.0]
        backend.store(key="k1", vector=vec, response="to delete")
        backend.delete("k1")
        results = backend.search(vec, top_k=1)
        assert results == []


class TestFAISSBackend:
    def test_store_and_search(self) -> None:
        pytest.importorskip("faiss")
        from semantic_cache.backends.faiss import FAISSBackend

        backend = FAISSBackend(vector_dim=3)
        vec = [1.0, 0.0, 0.0]
        backend.store(key="k1", vector=vec, response="faiss hit")
        results = backend.search(vec, top_k=1)
        assert len(results) == 1
        assert results[0][0] == "faiss hit"
        assert results[0][1] == pytest.approx(1.0, abs=1e-5)

    def test_empty_search(self) -> None:
        pytest.importorskip("faiss")
        from semantic_cache.backends.faiss import FAISSBackend

        backend = FAISSBackend(vector_dim=3)
        assert backend.search([1.0, 0.0, 0.0], top_k=1) == []

    def test_clear(self) -> None:
        pytest.importorskip("faiss")
        from semantic_cache.backends.faiss import FAISSBackend

        backend = FAISSBackend(vector_dim=2)
        backend.store(key="k1", vector=[1.0, 0.0], response="x")
        backend.clear()
        assert backend.search([1.0, 0.0], top_k=1) == []

    def test_persist_and_reload(self, tmp_path) -> None:
        pytest.importorskip("faiss")
        from semantic_cache.backends.faiss import FAISSBackend

        path = str(tmp_path / "faiss_cache")
        backend = FAISSBackend(vector_dim=3, save_path=path)
        backend.store(key="k1", vector=[1.0, 0.0, 0.0], response="persisted")

        reloaded = FAISSBackend(vector_dim=3, save_path=path)
        results = reloaded.search([1.0, 0.0, 0.0], top_k=1)
        assert results[0][0] == "persisted"

    def test_ttl_expiry(self) -> None:
        pytest.importorskip("faiss")
        from semantic_cache.backends.faiss import FAISSBackend

        backend = FAISSBackend(vector_dim=2)
        backend.store(key="k1", vector=[1.0, 0.0], response="expired", ttl=1)
        time.sleep(1.1)
        results = backend.search([1.0, 0.0], top_k=1)
        assert results == []
