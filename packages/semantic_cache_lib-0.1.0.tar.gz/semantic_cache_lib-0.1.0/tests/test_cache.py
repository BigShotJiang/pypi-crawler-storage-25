"""Tests for SemanticCache core logic."""
from __future__ import annotations

import asyncio
import time

import pytest

from semantic_cache.backends.memory import MemoryBackend
from semantic_cache.cache import SemanticCache
from semantic_cache.embedders.base import AbstractEmbedder
from semantic_cache.exceptions import CacheConfigError
from semantic_cache.stats import CacheStats


class FixedEmbedder(AbstractEmbedder):
    """Returns a deterministic vector based on the input string."""

    def embed(self, text: str) -> list[float]:
        # identical strings → same vector; different strings → orthogonal vectors
        if text == "hello world":
            return [1.0, 0.0, 0.0]
        if text == "hi world":
            return [0.99, 0.1, 0.0]  # very similar to "hello world"
        return [0.0, 1.0, 0.0]  # orthogonal — dissimilar


@pytest.fixture
def cache() -> SemanticCache:
    return SemanticCache(
        embedder=FixedEmbedder(),
        backend=MemoryBackend(),
        threshold=0.90,
    )


# ------------------------------------------------------------------
# Basic hit / miss
# ------------------------------------------------------------------

def test_cache_miss_calls_fallback(cache: SemanticCache) -> None:
    called = []

    def fallback() -> str:
        called.append(True)
        return "the answer"

    result = cache.get_or_set("hello world", fallback)
    assert result == "the answer"
    assert called == [True]


def test_cache_hit_skips_fallback(cache: SemanticCache) -> None:
    cache.get_or_set("hello world", lambda: "cached response")

    called = []
    result = cache.get_or_set("hello world", lambda: called.append(True) or "new response")
    assert result == "cached response"
    assert called == []


def test_semantically_similar_query_hits_cache(cache: SemanticCache) -> None:
    cache.get_or_set("hello world", lambda: "cached response")
    # "hi world" has cosine similarity ~0.995 with "hello world" → should hit
    result = cache.get_or_set("hi world", lambda: "should not reach")
    assert result == "cached response"


def test_dissimilar_query_misses_cache(cache: SemanticCache) -> None:
    cache.get_or_set("hello world", lambda: "cached response")
    # orthogonal vector → similarity = 0.0 → miss
    result = cache.get_or_set("something completely different", lambda: "different answer")
    assert result == "different answer"


# ------------------------------------------------------------------
# Threshold boundary
# ------------------------------------------------------------------

def test_threshold_exactly_met_is_hit() -> None:
    class ExactEmbedder(AbstractEmbedder):
        def embed(self, text: str) -> list[float]:
            return [1.0, 0.0] if text == "a" else [1.0, 0.0]  # identical

    cache = SemanticCache(embedder=ExactEmbedder(), threshold=1.0)
    cache.get_or_set("a", lambda: "hit")
    result = cache.get_or_set("a", lambda: "miss")
    assert result == "hit"


def test_below_threshold_is_miss() -> None:
    class LowSimEmbedder(AbstractEmbedder):
        def embed(self, text: str) -> list[float]:
            return [1.0, 0.0] if text == "a" else [0.0, 1.0]

    cache = SemanticCache(embedder=LowSimEmbedder(), threshold=0.90)
    cache.get_or_set("a", lambda: "stored")
    result = cache.get_or_set("b", lambda: "fresh")
    assert result == "fresh"


# ------------------------------------------------------------------
# TTL expiry
# ------------------------------------------------------------------

def test_ttl_expiry_causes_miss() -> None:
    cache = SemanticCache(
        embedder=FixedEmbedder(),
        backend=MemoryBackend(),
        threshold=0.90,
        ttl=1,
    )
    cache.get_or_set("hello world", lambda: "cached")
    time.sleep(1.1)
    result = cache.get_or_set("hello world", lambda: "fresh after expiry")
    assert result == "fresh after expiry"


# ------------------------------------------------------------------
# Stats
# ------------------------------------------------------------------

def test_stats_hit_and_miss(cache: SemanticCache) -> None:
    cache.get_or_set("hello world", lambda: "first")
    cache.get_or_set("hello world", lambda: "second")  # hit
    cache.get_or_set("something completely different", lambda: "third")  # miss

    stats = cache.stats()
    assert isinstance(stats, CacheStats)
    assert stats.hits == 1
    assert stats.misses == 2
    assert stats.total == 3
    assert abs(stats.hit_rate - 1 / 3) < 1e-6
    assert stats.avg_similarity > 0


def test_stats_reset(cache: SemanticCache) -> None:
    cache.get_or_set("hello world", lambda: "x")
    cache.reset_stats()
    stats = cache.stats()
    assert stats.hits == 0
    assert stats.misses == 0
    assert stats.total == 0


# ------------------------------------------------------------------
# Observability callbacks
# ------------------------------------------------------------------

def test_on_hit_callback_fires() -> None:
    hits = []
    cache = SemanticCache(
        embedder=FixedEmbedder(),
        backend=MemoryBackend(),
        threshold=0.90,
        on_hit=lambda q, r, s: hits.append((q, r, s)),
    )
    cache.get_or_set("hello world", lambda: "resp")
    cache.get_or_set("hello world", lambda: "resp2")
    assert len(hits) == 1
    assert hits[0][1] == "resp"
    assert hits[0][2] >= 0.90


def test_on_miss_callback_fires() -> None:
    misses = []
    cache = SemanticCache(
        embedder=FixedEmbedder(),
        backend=MemoryBackend(),
        threshold=0.90,
        on_miss=lambda q: misses.append(q),
    )
    cache.get_or_set("hello world", lambda: "resp")
    assert misses == ["hello world"]


# ------------------------------------------------------------------
# Async decorator
# ------------------------------------------------------------------

@pytest.mark.asyncio
async def test_async_decorator_cache_hit() -> None:
    cache = SemanticCache(
        embedder=FixedEmbedder(),
        backend=MemoryBackend(),
        threshold=0.90,
    )

    call_count = 0

    @cache
    async def ask(prompt: str) -> str:
        nonlocal call_count
        call_count += 1
        return f"answer to {prompt}"

    r1 = await ask("hello world")
    r2 = await ask("hello world")

    assert r1 == r2 == "answer to hello world"
    assert call_count == 1  # second call served from cache


@pytest.mark.asyncio
async def test_async_aget_or_set() -> None:
    cache = SemanticCache(embedder=FixedEmbedder(), threshold=0.90)

    async def llm() -> str:
        return "async response"

    r1 = await cache.aget_or_set("hello world", llm)
    r2 = await cache.aget_or_set("hello world", llm)
    assert r1 == r2 == "async response"


# ------------------------------------------------------------------
# Config validation
# ------------------------------------------------------------------

def test_invalid_threshold_raises() -> None:
    with pytest.raises(CacheConfigError):
        SemanticCache(embedder=FixedEmbedder(), threshold=1.5)


def test_invalid_top_k_raises() -> None:
    with pytest.raises(CacheConfigError):
        SemanticCache(embedder=FixedEmbedder(), top_k=0)


# ------------------------------------------------------------------
# clear / invalidate
# ------------------------------------------------------------------

def test_clear_removes_all_entries(cache: SemanticCache) -> None:
    cache.get_or_set("hello world", lambda: "resp")
    cache.clear()
    cache.reset_stats()
    result = cache.get_or_set("hello world", lambda: "after clear")
    assert result == "after clear"
    assert cache.stats().misses == 1
