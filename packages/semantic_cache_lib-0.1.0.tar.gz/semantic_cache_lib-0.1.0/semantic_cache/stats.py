from __future__ import annotations

import threading
from dataclasses import dataclass, field


@dataclass
class CacheStats:
    hits: int = 0
    misses: int = 0
    total: int = 0
    hit_rate: float = 0.0
    avg_similarity: float = 0.0

    def __repr__(self) -> str:
        return (
            f"CacheStats(hits={self.hits}, misses={self.misses}, "
            f"total={self.total}, hit_rate={self.hit_rate:.2%}, "
            f"avg_similarity={self.avg_similarity:.4f})"
        )


class StatsTracker:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0
        self._similarity_sum = 0.0

    def record_hit(self, similarity: float) -> None:
        with self._lock:
            self._hits += 1
            self._similarity_sum += similarity

    def record_miss(self) -> None:
        with self._lock:
            self._misses += 1

    def snapshot(self) -> CacheStats:
        with self._lock:
            total = self._hits + self._misses
            hit_rate = self._hits / total if total > 0 else 0.0
            avg_sim = self._similarity_sum / self._hits if self._hits > 0 else 0.0
            return CacheStats(
                hits=self._hits,
                misses=self._misses,
                total=total,
                hit_rate=hit_rate,
                avg_similarity=avg_sim,
            )

    def reset(self) -> None:
        with self._lock:
            self._hits = 0
            self._misses = 0
            self._similarity_sum = 0.0
