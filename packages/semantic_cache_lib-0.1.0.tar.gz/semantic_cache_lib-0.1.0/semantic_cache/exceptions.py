class SemanticCacheError(Exception):
    """Base exception for semantic-cache-lib."""


class CacheConfigError(SemanticCacheError):
    """Raised when SemanticCache is misconfigured."""


class EmbedderError(SemanticCacheError):
    """Raised when an embedder fails to produce a vector."""


class BackendError(SemanticCacheError):
    """Raised when a backend store/search operation fails."""
