from __future__ import annotations

import pickle
import time
import uuid
from pathlib import Path

from semantic_cache.backends.base import AbstractBackend
from semantic_cache.exceptions import BackendError
from semantic_cache.similarity import cosine_similarity


class MemoryBackend(AbstractBackend):
    """
    In-memory backend using brute-force cosine similarity search.

    Suitable for development, testing, and small workloads (<10k entries).
    Set save_path to persist the cache across restarts via pickle.
    """

    def __init__(self, save_path: str | None = None) -> None:
        self._save_path = Path(save_path) if save_path else None
        self._entries: list[dict] = []
        if self._save_path and self._save_path.exists():
            self._load()

    def store(
        self,
        key: str | None = None,
        vector: list[float] = [],
        response: str = "",
        ttl: int | None = None,
    ) -> None:
        expires_at = time.time() + ttl if ttl is not None else None
        self._entries.append(
            {
                "key": key or str(uuid.uuid4()),
                "vector": vector,
                "response": response,
                "expires_at": expires_at,
            }
        )
        if self._save_path:
            self._persist()

    def search(
        self,
        vector: list[float],
        top_k: int = 1,
    ) -> list[tuple[str, float]]:
        now = time.time()
        scored: list[tuple[str, float]] = []
        for entry in self._entries:
            if entry["expires_at"] is not None and entry["expires_at"] < now:
                continue
            score = cosine_similarity(vector, entry["vector"])
            scored.append((entry["response"], score))
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]

    def delete(self, key: str) -> None:
        self._entries = [e for e in self._entries if e["key"] != key]
        if self._save_path:
            self._persist()

    def clear(self) -> None:
        self._entries = []
        if self._save_path and self._save_path.exists():
            self._save_path.unlink()

    def _persist(self) -> None:
        try:
            assert self._save_path is not None
            self._save_path.write_bytes(pickle.dumps(self._entries))
        except Exception as e:
            raise BackendError(f"Failed to persist memory cache: {e}") from e

    def _load(self) -> None:
        try:
            assert self._save_path is not None
            self._entries = pickle.loads(self._save_path.read_bytes())
        except Exception as e:
            raise BackendError(f"Failed to load memory cache from disk: {e}") from e
