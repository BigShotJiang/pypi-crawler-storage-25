from __future__ import annotations

import json
import uuid

from semantic_cache.backends.base import AbstractBackend
from semantic_cache.exceptions import BackendError


class RedisBackend(AbstractBackend):
    """
    Redis backend using HNSW vector search via RedisVL.

    Requires Redis Stack (which includes the vector search module).

    Args:
        url: Redis connection URL, e.g. "redis://localhost:6379".
        index_name: Name of the RedisVL search index.
        vector_dim: Dimensionality of the embedding vectors. Must match your embedder.
    """

    def __init__(
        self,
        url: str = "redis://localhost:6379",
        index_name: str = "semantic_cache",
        vector_dim: int = 384,
    ) -> None:
        self._url = url
        self._index_name = index_name
        self._vector_dim = vector_dim
        self._index = None

    def _get_index(self):  # type: ignore[return]
        if self._index is not None:
            return self._index
        try:
            from redisvl.index import SearchIndex
            from redisvl.schema import IndexSchema
        except ImportError as e:
            raise BackendError(
                "Install the redis extra: pip install semantic-cache-lib[redis]"
            ) from e

        schema = IndexSchema.from_dict(
            {
                "index": {"name": self._index_name, "prefix": f"{self._index_name}:"},
                "fields": [
                    {"name": "response", "type": "text"},
                    {"name": "metadata", "type": "text"},
                    {
                        "name": "vector",
                        "type": "vector",
                        "attrs": {
                            "dims": self._vector_dim,
                            "distance_metric": "cosine",
                            "algorithm": "hnsw",
                            "datatype": "float32",
                        },
                    },
                ],
            }
        )
        try:
            index = SearchIndex(schema=schema, redis_url=self._url)
            index.create(overwrite=False)
            self._index = index
            return self._index
        except Exception as e:
            raise BackendError(f"Failed to connect to Redis: {e}") from e

    def store(
        self,
        key: str | None = None,
        vector: list[float] = [],
        response: str = "",
        ttl: int | None = None,
    ) -> None:
        index = self._get_index()
        entry_key = key or str(uuid.uuid4())
        metadata = json.dumps({"ttl": ttl})
        try:
            import numpy as np
            vec_bytes = np.array(vector, dtype=np.float32).tobytes()
            data = [{"id": entry_key, "response": response, "metadata": metadata, "vector": vec_bytes}]
            index.load(data, id_field="id")
            if ttl is not None:
                client = index.client
                full_key = f"{self._index_name}:{entry_key}"
                client.expire(full_key, ttl)
        except BackendError:
            raise
        except Exception as e:
            raise BackendError(f"Redis store failed: {e}") from e

    def search(
        self,
        vector: list[float],
        top_k: int = 1,
    ) -> list[tuple[str, float]]:
        index = self._get_index()
        try:
            import numpy as np
            from redisvl.query import VectorQuery

            vec_bytes = np.array(vector, dtype=np.float32).tobytes()
            query = VectorQuery(
                vector=vec_bytes,
                vector_field_name="vector",
                return_fields=["response", "vector_distance"],
                num_results=top_k,
            )
            results = index.query(query)
            out: list[tuple[str, float]] = []
            for r in results:
                # RedisVL returns cosine distance (0=identical, 2=opposite)
                distance = float(r.get("vector_distance", 1.0))
                similarity = 1.0 - (distance / 2.0)
                out.append((r["response"], similarity))
            return out
        except BackendError:
            raise
        except Exception as e:
            raise BackendError(f"Redis search failed: {e}") from e

    def delete(self, key: str) -> None:
        index = self._get_index()
        try:
            index.client.delete(f"{self._index_name}:{key}")
        except Exception as e:
            raise BackendError(f"Redis delete failed: {e}") from e

    def clear(self) -> None:
        index = self._get_index()
        try:
            index.clear()
        except Exception as e:
            raise BackendError(f"Redis clear failed: {e}") from e
