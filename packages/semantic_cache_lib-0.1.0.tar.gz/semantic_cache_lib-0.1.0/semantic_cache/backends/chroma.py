from __future__ import annotations

import uuid

from semantic_cache.backends.base import AbstractBackend
from semantic_cache.exceptions import BackendError


class ChromaBackend(AbstractBackend):
    """
    Backend using ChromaDB for vector storage and similarity search.

    Supports both remote (HTTP) and in-process (ephemeral) modes.

    Args:
        url: ChromaDB server URL, e.g. "http://localhost:8000".
             If None, uses an ephemeral in-process client (good for testing).
        collection: Name of the Chroma collection to use.
    """

    def __init__(
        self,
        url: str | None = None,
        collection: str = "semantic_cache",
    ) -> None:
        self._url = url
        self._collection_name = collection
        self._collection = None

    def _get_collection(self):  # type: ignore[return]
        if self._collection is not None:
            return self._collection
        try:
            import chromadb
        except ImportError as e:
            raise BackendError(
                "Install the chroma extra: pip install semantic-cache-lib[chroma]"
            ) from e

        try:
            if self._url:
                from urllib.parse import urlparse
                parsed = urlparse(self._url)
                client = chromadb.HttpClient(
                    host=parsed.hostname or "localhost",
                    port=parsed.port or 8000,
                )
            else:
                client = chromadb.EphemeralClient()

            self._collection = client.get_or_create_collection(
                name=self._collection_name,
                metadata={"hnsw:space": "cosine"},
            )
            return self._collection
        except Exception as e:
            raise BackendError(f"Failed to connect to ChromaDB: {e}") from e

    def store(
        self,
        key: str | None = None,
        vector: list[float] = [],
        response: str = "",
        ttl: int | None = None,
    ) -> None:
        collection = self._get_collection()
        entry_id = key or str(uuid.uuid4())
        try:
            collection.add(
                ids=[entry_id],
                embeddings=[vector],
                documents=[response],
                metadatas=[{"ttl": ttl or -1}],
            )
        except Exception as e:
            raise BackendError(f"ChromaDB store failed: {e}") from e

    def search(
        self,
        vector: list[float],
        top_k: int = 1,
    ) -> list[tuple[str, float]]:
        collection = self._get_collection()
        try:
            count = collection.count()
            if count == 0:
                return []
            results = collection.query(
                query_embeddings=[vector],
                n_results=min(top_k, count),
                include=["documents", "distances"],
            )
            out: list[tuple[str, float]] = []
            docs = results.get("documents") or [[]]
            dists = results.get("distances") or [[]]
            for doc, dist in zip(docs[0], dists[0]):
                # Chroma cosine space returns distance in [0, 2]; convert to similarity
                similarity = 1.0 - (dist / 2.0)
                out.append((doc, similarity))
            return out
        except Exception as e:
            raise BackendError(f"ChromaDB search failed: {e}") from e

    def delete(self, key: str) -> None:
        collection = self._get_collection()
        try:
            collection.delete(ids=[key])
        except Exception as e:
            raise BackendError(f"ChromaDB delete failed: {e}") from e

    def clear(self) -> None:
        collection = self._get_collection()
        try:
            all_ids = collection.get()["ids"]
            if all_ids:
                collection.delete(ids=all_ids)
        except Exception as e:
            raise BackendError(f"ChromaDB clear failed: {e}") from e
