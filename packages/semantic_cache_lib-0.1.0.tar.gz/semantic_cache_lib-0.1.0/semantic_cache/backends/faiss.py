from __future__ import annotations

import json
import time
import uuid
from pathlib import Path

from semantic_cache.backends.base import AbstractBackend
from semantic_cache.exceptions import BackendError
from semantic_cache.similarity import normalize


class FAISSBackend(AbstractBackend):
    """
    FAISS backend using a flat inner-product index (cosine similarity via L2 normalization).

    Scales well up to millions of vectors. No native TTL — expiry is enforced at query time.
    Set save_path to persist the index and metadata across restarts.

    Args:
        vector_dim: Dimensionality of embedding vectors. Must match your embedder.
        save_path: Optional directory path to persist the FAISS index and metadata.
    """

    def __init__(self, vector_dim: int, save_path: str | None = None) -> None:
        self._dim = vector_dim
        self._save_dir = Path(save_path) if save_path else None
        self._index = None
        # Parallel metadata store: FAISS int ID → {response, key, expires_at}
        self._meta: dict[int, dict] = {}
        self._next_id = 0

        if self._save_dir and self._save_dir.exists():
            self._load()

    def _get_index(self):  # type: ignore[return]
        if self._index is not None:
            return self._index
        try:
            import faiss
            self._index = faiss.IndexFlatIP(self._dim)
            return self._index
        except ImportError as e:
            raise BackendError(
                "Install the faiss extra: pip install semantic-cache-lib[faiss]"
            ) from e

    def store(
        self,
        key: str | None = None,
        vector: list[float] = [],
        response: str = "",
        ttl: int | None = None,
    ) -> None:
        import numpy as np

        index = self._get_index()
        normed = normalize(vector)
        arr = np.array([normed], dtype=np.float32)
        try:
            index.add(arr)
        except Exception as e:
            raise BackendError(f"FAISS store failed: {e}") from e

        fid = self._next_id
        self._next_id += 1
        expires_at = time.time() + ttl if ttl is not None else None
        self._meta[fid] = {
            "key": key or str(uuid.uuid4()),
            "response": response,
            "expires_at": expires_at,
        }
        if self._save_dir:
            self._persist()

    def search(
        self,
        vector: list[float],
        top_k: int = 1,
    ) -> list[tuple[str, float]]:
        import numpy as np

        index = self._get_index()
        if index.ntotal == 0:
            return []

        normed = normalize(vector)
        arr = np.array([normed], dtype=np.float32)
        k = min(top_k * 4, index.ntotal)  # over-fetch to account for expired entries
        try:
            scores, ids = index.search(arr, k)
        except Exception as e:
            raise BackendError(f"FAISS search failed: {e}") from e

        now = time.time()
        results: list[tuple[str, float]] = []
        for score, fid in zip(scores[0], ids[0]):
            if fid == -1:
                continue
            meta = self._meta.get(int(fid))
            if meta is None:
                continue
            if meta["expires_at"] is not None and meta["expires_at"] < now:
                continue
            results.append((meta["response"], float(score)))
            if len(results) == top_k:
                break

        return results

    def delete(self, key: str) -> None:
        # FAISS flat index doesn't support in-place deletion; mark as expired instead
        for fid, meta in self._meta.items():
            if meta["key"] == key:
                meta["expires_at"] = 0.0  # expire immediately
                break

    def clear(self) -> None:
        try:
            import faiss
            self._index = faiss.IndexFlatIP(self._dim)
        except ImportError as e:
            raise BackendError(
                "Install the faiss extra: pip install semantic-cache-lib[faiss]"
            ) from e
        self._meta.clear()
        self._next_id = 0
        if self._save_dir:
            self._persist()

    def _persist(self) -> None:
        try:
            import faiss
            assert self._save_dir is not None
            self._save_dir.mkdir(parents=True, exist_ok=True)
            faiss.write_index(self._index, str(self._save_dir / "index.faiss"))
            (self._save_dir / "meta.json").write_text(
                json.dumps({str(k): v for k, v in self._meta.items()})
            )
            (self._save_dir / "next_id.txt").write_text(str(self._next_id))
        except Exception as e:
            raise BackendError(f"FAISS persist failed: {e}") from e

    def _load(self) -> None:
        try:
            import faiss
            assert self._save_dir is not None
            index_path = self._save_dir / "index.faiss"
            meta_path = self._save_dir / "meta.json"
            if index_path.exists():
                self._index = faiss.read_index(str(index_path))
            if meta_path.exists():
                raw = json.loads(meta_path.read_text())
                self._meta = {int(k): v for k, v in raw.items()}
            nid_path = self._save_dir / "next_id.txt"
            if nid_path.exists():
                self._next_id = int(nid_path.read_text())
        except Exception as e:
            raise BackendError(f"FAISS load failed: {e}") from e
