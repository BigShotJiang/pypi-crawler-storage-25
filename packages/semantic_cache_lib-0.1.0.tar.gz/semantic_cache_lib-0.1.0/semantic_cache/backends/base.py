from __future__ import annotations

from abc import ABC, abstractmethod


class AbstractBackend(ABC):
    """Base class for all cache backends. Subclass and implement all methods."""

    @abstractmethod
    def store(
        self,
        key: str,
        vector: list[float],
        response: str,
        ttl: int | None = None,
    ) -> None:
        """Store a query vector and its LLM response."""
        ...

    @abstractmethod
    def search(
        self,
        vector: list[float],
        top_k: int = 1,
    ) -> list[tuple[str, float]]:
        """
        Find the closest cached entries to the given vector.

        Returns a list of (response, similarity_score) tuples sorted
        by descending similarity. Expired entries must not be returned.
        """
        ...

    @abstractmethod
    def delete(self, key: str) -> None:
        """Remove a specific entry by its key."""
        ...

    @abstractmethod
    def clear(self) -> None:
        """Remove all entries from the cache."""
        ...
