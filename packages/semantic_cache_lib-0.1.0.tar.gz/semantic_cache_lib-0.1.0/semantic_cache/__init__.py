"""
semantic-cache-lib
~~~~~~~~~~~~~~~~~~

Semantic caching for LLM calls via vector similarity search.

Basic usage::

    from semantic_cache import SemanticCache
    from semantic_cache.embedders import HuggingFaceEmbedder
    from semantic_cache.backends import MemoryBackend

    cache = SemanticCache(
        embedder=HuggingFaceEmbedder(
            token="hf_...",
            model="sentence-transformers/all-MiniLM-L6-v2",
        ),
        threshold=0.90,
    )

    @cache
    def call_llm(prompt: str) -> str:
        ...  # your LLM call here
"""

from semantic_cache.backends.chroma import ChromaBackend
from semantic_cache.backends.faiss import FAISSBackend
from semantic_cache.backends.memory import MemoryBackend
from semantic_cache.backends.redis import RedisBackend
from semantic_cache.cache import SemanticCache
from semantic_cache.embedders.huggingface import HuggingFaceEmbedder
from semantic_cache.embedders.openai import OpenAIEmbedder
from semantic_cache.embedders.sentence_transformers import SentenceTransformerEmbedder
from semantic_cache.exceptions import BackendError, CacheConfigError, EmbedderError
from semantic_cache.stats import CacheStats

__version__ = "0.1.0"

__all__ = [
    "SemanticCache",
    "CacheStats",
    # Embedders
    "HuggingFaceEmbedder",
    "OpenAIEmbedder",
    "SentenceTransformerEmbedder",
    # Backends
    "MemoryBackend",
    "RedisBackend",
    "FAISSBackend",
    "ChromaBackend",
    # Exceptions
    "CacheConfigError",
    "EmbedderError",
    "BackendError",
]
