from __future__ import annotations

import os

from semantic_cache.embedders.base import AbstractEmbedder
from semantic_cache.exceptions import EmbedderError


class OpenAIEmbedder(AbstractEmbedder):
    """
    Embedder using OpenAI text-embedding models.

    Args:
        model: OpenAI embedding model ID. Default: "text-embedding-3-small".
        api_key: OpenAI API key. Falls back to OPENAI_API_KEY env var.
    """

    def __init__(
        self,
        model: str = "text-embedding-3-small",
        api_key: str | None = None,
    ) -> None:
        self.model = model
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not self._api_key:
            raise EmbedderError(
                "OpenAIEmbedder requires an API key. "
                "Pass api_key= or set the OPENAI_API_KEY environment variable."
            )

    def _client(self):  # type: ignore[return]
        try:
            from openai import OpenAI
            return OpenAI(api_key=self._api_key)
        except ImportError as e:
            raise EmbedderError(
                "Install the openai extra: pip install semantic-cache-lib[openai]"
            ) from e

    def _async_client(self):  # type: ignore[return]
        try:
            from openai import AsyncOpenAI
            return AsyncOpenAI(api_key=self._api_key)
        except ImportError as e:
            raise EmbedderError(
                "Install the openai extra: pip install semantic-cache-lib[openai]"
            ) from e

    def embed(self, text: str) -> list[float]:
        try:
            response = self._client().embeddings.create(input=text, model=self.model)
            return response.data[0].embedding
        except Exception as e:
            raise EmbedderError(f"OpenAI embedding failed: {e}") from e

    async def aembed(self, text: str) -> list[float]:
        try:
            response = await self._async_client().embeddings.create(
                input=text, model=self.model
            )
            return response.data[0].embedding
        except Exception as e:
            raise EmbedderError(f"OpenAI async embedding failed: {e}") from e
