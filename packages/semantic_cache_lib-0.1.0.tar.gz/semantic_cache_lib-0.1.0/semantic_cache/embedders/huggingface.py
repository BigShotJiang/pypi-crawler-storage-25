from __future__ import annotations

import os

from semantic_cache.embedders.base import AbstractEmbedder
from semantic_cache.exceptions import EmbedderError

_HF_API_URL = "https://api-inference.huggingface.co/pipeline/feature-extraction/{model}"


class HuggingFaceEmbedder(AbstractEmbedder):
    """
    Embedder using the HuggingFace Inference API.

    No GPU required — calls the remote HF API.
    Sync via requests, async via httpx.

    Args:
        model: HuggingFace model ID, e.g. "sentence-transformers/all-MiniLM-L6-v2"
        token: HF API token. Falls back to HF_TOKEN env var.
    """

    def __init__(self, model: str, token: str | None = None) -> None:
        self.model = model
        self._token = token or os.environ.get("HF_TOKEN")
        if not self._token:
            raise EmbedderError(
                "HuggingFaceEmbedder requires a token. "
                "Pass token= or set the HF_TOKEN environment variable."
            )

    @property
    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._token}"}

    @property
    def _url(self) -> str:
        return _HF_API_URL.format(model=self.model)

    def embed(self, text: str) -> list[float]:
        try:
            import requests
        except ImportError as e:
            raise EmbedderError(
                "Install the huggingface extra: pip install semantic-cache-lib[huggingface]"
            ) from e

        try:
            resp = requests.post(
                self._url,
                headers=self._headers,
                json={"inputs": text, "options": {"wait_for_model": True}},
                timeout=30,
            )
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            raise EmbedderError(f"HuggingFace API call failed: {e}") from e

        return self._parse(data)

    async def aembed(self, text: str) -> list[float]:
        try:
            import httpx
        except ImportError as e:
            raise EmbedderError(
                "Install the huggingface extra: pip install semantic-cache-lib[huggingface]"
            ) from e

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.post(
                    self._url,
                    headers=self._headers,
                    json={"inputs": text, "options": {"wait_for_model": True}},
                )
                resp.raise_for_status()
                data = resp.json()
        except Exception as e:
            raise EmbedderError(f"HuggingFace async API call failed: {e}") from e

        return self._parse(data)

    def _parse(self, data: object) -> list[float]:
        """HF returns either [float, ...] or [[float, ...]] depending on model."""
        if isinstance(data, list):
            if data and isinstance(data[0], list):
                # pooled representation: average token embeddings
                import numpy as np
                arr = np.array(data, dtype=np.float32)
                return arr.mean(axis=0).tolist()
            return [float(x) for x in data]
        raise EmbedderError(f"Unexpected HuggingFace response format: {type(data)}")
