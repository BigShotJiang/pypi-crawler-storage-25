from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod


class AbstractEmbedder(ABC):
    """Base class for all embedders. Subclass and implement `embed`."""

    @abstractmethod
    def embed(self, text: str) -> list[float]:
        """Embed a single text string into a float vector."""
        ...

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Embed multiple texts. Override for native batching support."""
        return [self.embed(t) for t in texts]

    async def aembed(self, text: str) -> list[float]:
        """Async embed. Override for native async support."""
        return await asyncio.to_thread(self.embed, text)

    async def aembed_batch(self, texts: list[str]) -> list[list[float]]:
        """Async batch embed."""
        return await asyncio.to_thread(self.embed_batch, texts)
