from __future__ import annotations

from semantic_cache.embedders.base import AbstractEmbedder
from semantic_cache.exceptions import EmbedderError


class SentenceTransformerEmbedder(AbstractEmbedder):
    """
    Embedder using a local SentenceTransformers model (runs on-device).

    Downloads the model from HuggingFace Hub on first use.

    Args:
        model: Model name or path. Default: "all-MiniLM-L6-v2".
        device: Compute device. Default: "cpu". Use "cuda" for GPU.
    """

    def __init__(
        self,
        model: str = "all-MiniLM-L6-v2",
        device: str = "cpu",
    ) -> None:
        self.model_name = model
        self.device = device
        self._model = None

    def _load(self):  # type: ignore[return]
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer
                self._model = SentenceTransformer(self.model_name, device=self.device)
            except ImportError as e:
                raise EmbedderError(
                    "Install the transformers extra: "
                    "pip install semantic-cache-lib[transformers]"
                ) from e
        return self._model

    def embed(self, text: str) -> list[float]:
        try:
            model = self._load()
            vector = model.encode(text, convert_to_numpy=True)
            return vector.tolist()
        except EmbedderError:
            raise
        except Exception as e:
            raise EmbedderError(f"SentenceTransformer embedding failed: {e}") from e

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        try:
            model = self._load()
            vectors = model.encode(texts, convert_to_numpy=True)
            return [v.tolist() for v in vectors]
        except EmbedderError:
            raise
        except Exception as e:
            raise EmbedderError(f"SentenceTransformer batch embedding failed: {e}") from e
