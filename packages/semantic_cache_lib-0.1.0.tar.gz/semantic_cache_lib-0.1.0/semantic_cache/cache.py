from __future__ import annotations

import asyncio
import functools
import inspect
import logging
import uuid
from collections.abc import Callable
from typing import Any, TypeVar

from semantic_cache.backends.base import AbstractBackend
from semantic_cache.backends.memory import MemoryBackend
from semantic_cache.embedders.base import AbstractEmbedder
from semantic_cache.exceptions import CacheConfigError
from semantic_cache.stats import CacheStats, StatsTracker

logger = logging.getLogger("semantic_cache")

F = TypeVar("F", bound=Callable[..., Any])


class SemanticCache:
    """
    Semantic cache for LLM calls.

    Intercepts calls, embeds the query, searches for similar past queries,
    and returns a cached response when similarity meets the threshold.

    Usage as a decorator:

        cache = SemanticCache(embedder=MyEmbedder())

        @cache
        def call_llm(prompt: str) -> str:
            ...

        @cache
        async def call_llm_async(prompt: str) -> str:
            ...

    Usage programmatically:

        response = cache.get_or_set("my query", lambda: llm("my query"))
        response = await cache.aget_or_set("my query", async_llm("my query"))
    """

    def __init__(
        self,
        embedder: AbstractEmbedder,
        backend: AbstractBackend | None = None,
        threshold: float = 0.85,
        ttl: int | None = None,
        top_k: int = 1,
        on_hit: Callable[[str, str, float], None] | None = None,
        on_miss: Callable[[str], None] | None = None,
    ) -> None:
        if not 0.0 <= threshold <= 1.0:
            raise CacheConfigError(f"threshold must be between 0.0 and 1.0, got {threshold}")
        if top_k < 1:
            raise CacheConfigError(f"top_k must be >= 1, got {top_k}")

        self._embedder = embedder
        self._backend = backend or MemoryBackend()
        self._threshold = threshold
        self._ttl = ttl
        self._top_k = top_k
        self._on_hit = on_hit
        self._on_miss = on_miss
        self._tracker = StatsTracker()

    # ------------------------------------------------------------------
    # Decorator interface
    # ------------------------------------------------------------------

    def __call__(self, fn: F) -> F:
        if inspect.iscoroutinefunction(fn):
            return self._wrap_async(fn)  # type: ignore[return-value]
        return self._wrap_sync(fn)  # type: ignore[return-value]

    def _wrap_sync(self, fn: Callable[..., str]) -> Callable[..., str]:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> str:
            query = self._extract_query(args, kwargs)
            return self.get_or_set(query, lambda: fn(*args, **kwargs))

        return wrapper

    def _wrap_async(self, fn: Callable[..., Any]) -> Callable[..., Any]:
        @functools.wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> str:
            query = self._extract_query(args, kwargs)
            return await self.aget_or_set(query, lambda: fn(*args, **kwargs))

        return wrapper

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    def get_or_set(self, query: str, fallback: Callable[[], str]) -> str:
        """Sync: return cached response or call fallback and cache the result."""
        vector = self._embedder.embed(query)
        hit = self._find_hit(vector)
        if hit is not None:
            response, score = hit
            self._tracker.record_hit(score)
            logger.debug("Cache HIT (similarity=%.4f) for query: %.80s", score, query)
            if self._on_hit:
                self._on_hit(query, response, score)
            return response

        self._tracker.record_miss()
        logger.debug("Cache MISS for query: %.80s", query)
        if self._on_miss:
            self._on_miss(query)

        response = fallback()
        self._backend.store(
            key=str(uuid.uuid4()),
            vector=vector,
            response=response,
            ttl=self._ttl,
        )
        return response

    async def aget_or_set(self, query: str, fallback: Callable[[], Any]) -> str:
        """Async: return cached response or call fallback and cache the result."""
        vector = await self._embedder.aembed(query)
        hit = self._find_hit(vector)
        if hit is not None:
            response, score = hit
            self._tracker.record_hit(score)
            logger.debug("Cache HIT (similarity=%.4f) for query: %.80s", score, query)
            if self._on_hit:
                self._on_hit(query, response, score)
            return response

        self._tracker.record_miss()
        logger.debug("Cache MISS for query: %.80s", query)
        if self._on_miss:
            self._on_miss(query)

        result = fallback()
        response = await result if asyncio.iscoroutine(result) else result
        self._backend.store(
            key=str(uuid.uuid4()),
            vector=vector,
            response=response,
            ttl=self._ttl,
        )
        return response

    def _find_hit(self, vector: list[float]) -> tuple[str, float] | None:
        candidates = self._backend.search(vector, top_k=self._top_k)
        for response, score in candidates:
            if score >= self._threshold:
                return response, score
        return None

    # ------------------------------------------------------------------
    # Management
    # ------------------------------------------------------------------

    def clear(self) -> None:
        """Remove all entries from the cache."""
        self._backend.clear()
        logger.info("Cache cleared.")

    def invalidate(self, query: str) -> None:
        """Remove the cache entry for a specific query (uses query as key)."""
        self._backend.delete(query)

    def stats(self) -> CacheStats:
        """Return a snapshot of cache hit/miss statistics."""
        return self._tracker.snapshot()

    def reset_stats(self) -> None:
        """Reset hit/miss counters."""
        self._tracker.reset()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_query(args: tuple[Any, ...], kwargs: dict[str, Any]) -> str:
        """
        Extract the query string from decorated function arguments.

        Expects the first positional arg or a 'prompt'/'query'/'text' kwarg
        to be the string passed to the LLM.
        """
        for key in ("prompt", "query", "text", "message"):
            if key in kwargs:
                return str(kwargs[key])
        if args:
            return str(args[0])
        raise CacheConfigError(
            "SemanticCache could not determine the query string from the function arguments. "
            "Pass the query as the first positional argument or as a keyword argument "
            "named 'prompt', 'query', 'text', or 'message'."
        )
