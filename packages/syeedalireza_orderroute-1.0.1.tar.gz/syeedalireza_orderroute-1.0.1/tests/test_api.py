import pytest
from httpx import AsyncClient, ASGITransport
from src.main import app
import pytest_asyncio

@pytest_asyncio.fixture
async def async_client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client

@pytest.mark.asyncio
async def test_health_check(async_client):
    response = await async_client.get("/health")
    assert response.status_code == 200

@pytest.mark.asyncio
async def test_calculate_route_success(async_client):
    payload = {
        "order_id": "ORD-123",
        "customer_lat": 35.6892,
        "customer_lng": 51.3890, # Tehran
        "required_quantity": 2,
        "warehouses": [
            {"id": "WH-1", "lat": 35.7000, "lng": 51.4000, "stock": 5}, # Close
            {"id": "WH-2", "lat": 31.8333, "lng": 54.3667, "stock": 10} # Far (Yazd)
        ]
    }
    
    response = await async_client.post("/api/v1/route", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["routing_decision"]["selected_warehouse_id"] == "WH-1"

@pytest.mark.asyncio
async def test_calculate_route_no_stock(async_client):
    payload = {
        "order_id": "ORD-124",
        "customer_lat": 35.6892,
        "customer_lng": 51.3890,
        "required_quantity": 20,
        "warehouses": [
            {"id": "WH-1", "lat": 35.7000, "lng": 51.4000, "stock": 5}
        ]
    }
    
    response = await async_client.post("/api/v1/route", json=payload)
    assert response.status_code == 400
    assert "Split fulfillment required" in response.json()["detail"]