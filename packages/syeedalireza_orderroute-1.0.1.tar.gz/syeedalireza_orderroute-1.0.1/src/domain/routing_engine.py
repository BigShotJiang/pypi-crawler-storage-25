import math

def haversine_distance(lat1, lon1, lat2, lon2):
    """Calculate the great circle distance in kilometers between two points on the earth."""
    R = 6371.0 # Earth radius in kilometers
    
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    
    a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    return R * c

def optimize_routing(customer_loc: tuple, warehouses: list, required_qty: int) -> dict:
    """
    Determines the best warehouse to fulfill an order.
    Uses a simple heuristic: closest warehouse that has enough stock.
    For more complex multi-vehicle routing, Google OR-Tools (ortools) would be used here.
    """
    best_warehouse = None
    min_distance = float('inf')
    
    for wh in warehouses:
        if wh['stock'] >= required_qty:
            dist = haversine_distance(customer_loc[0], customer_loc[1], wh['lat'], wh['lng'])
            if dist < min_distance:
                min_distance = dist
                best_warehouse = wh['id']
                
    if not best_warehouse:
        raise ValueError("No single warehouse can fulfill this order. Split fulfillment required.")
        
    return {
        "selected_warehouse_id": best_warehouse,
        "distance_km": round(min_distance, 2),
        "status": "routed"
    }