from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict
from src.domain.routing_engine import optimize_routing

app = FastAPI(
    title="OrderRoute API",
    description="Distributed Order Management & Routing (DOMS)",
    version="1.0.0"
)

class Location(BaseModel):
    id: str
    lat: float
    lng: float
    stock: int

class OrderRequest(BaseModel):
    order_id: str
    customer_lat: float
    customer_lng: float
    required_quantity: int
    warehouses: List[Location]

@app.get("/health", tags=["System"])
async def health_check():
    return {"status": "healthy"}

@app.post("/api/v1/route", tags=["Routing"])
async def calculate_route(request: OrderRequest):
    """
    Calculate the optimal warehouse to fulfill the order based on distance and stock.
    In a real scenario, this would use PostGIS for accurate road distances.
    """
    try:
        result = optimize_routing(
            customer_loc=(request.customer_lat, request.customer_lng),
            warehouses=[w.model_dump() for w in request.warehouses],
            required_qty=request.required_quantity
        )
        return {"order_id": request.order_id, "routing_decision": result}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal routing error")