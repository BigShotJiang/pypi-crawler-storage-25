# ==============================================================================
#
# Copyright (C) 2022 bigtpu Technologies Inc.  All rights reserved.
#
# TPU-MLIR is licensed under the 2-Clause BSD License except for the
# third-party components.
#
# ==============================================================================
import pandas as pd
import os
from decimal import Decimal
import sys

from ..utils.utils import data_type_dict, data_size_dict
from ..utils.utils import *
from shared_parser import parse_header, parse_records, apply_layer_map_full

class TIU:
    def __init__(self, dirpath):
        self.dirpath = dirpath
        self.chipArgs = dict()
        self.linecount = 0
        self.frequency = 0
        self.actual_corenum = 0
        self.regList=[]
        self.tiu_working_ratio_list = []
        self.total_time_dict = {"start":[], "end":[]}
        self.tiu_cycle_list = []
        self.total_alg_cycle_list = []
        self.total_alg_ops_list = []
        self.uArach_rate_list = []
        self.total_uarch_ops_list = []
        self.columns = ['Engine Id', 'Core Id', 'Global Idx', 'Cmd Id', 'Layer Id', 'Layer Name', 'Subnet Id', 'Subnet Type', 'File Line',
                        'Function Type', 'Function Name',
                        'Alg Cycle', 'Alg Ops','Asic Cycle', 'Start Cycle', 'End Cycle',
                        'uArch Ops', 'uArch Rate', 'Data Type','des_cmd_id_dep',
                        'des_res0_n', 'des_res0_c', 'des_res0_h', 'des_res0_w',
                        'des_res0_n_str', 'des_res0_c_str', 'des_res0_h_str', 'des_res0_w_str',
                        'des_opd0_n', 'des_opd0_c', 'des_opd0_h', 'des_opd0_w',
                        'des_opd0_n_str', 'des_opd0_c_str', 'des_opd0_h_str', 'des_opd0_w_str',
                        'des_opd1_c', 'des_opd1_h', 'des_opd1_w', 'des_opd1_n_str', 'des_opd1_c_str', 'des_opd1_h_str',
                        'des_opd1_w_str',
                        'des_opd2_n_str', 'des_res0_addr', 'des_res1_addr', 'des_opd0_addr', 'des_opd1_addr',
                        'des_opd2_addr',
                        'des_opd3_addr', 'des_tsk_typ', 'des_tsk_eu_typ', 'des_cmd_short',
                        'des_opt_res0_prec', 'des_opt_opd0_prec', 'des_opt_opd1_prec', 'des_opt_opd2_prec',
                        'des_short_opd0_str',
                        'des_opt_opd0_const', 'des_opt_opd1_const', 'des_opt_opd2_const', 'des_opt_opd3_const',
                        'des_opt_opd4_const', 'des_opt_opd5_const',
                        'des_opt_res_add', 'des_opt_res0_sign', 'des_opt_opd0_sign', 'des_opt_opd1_sign',
                        'des_opt_opd2_sign',
                        'des_opd0_rt_pad', 'des_opd1_x_ins0', 'des_opd0_up_pad', 'des_opd0_lf_pad', 'des_opt_left_tran',
                        'des_pad_mode', 'des_opd0_y_ins0', 'des_opd1_y_ins0',
                        'des_short_res0_str', 'des_short_opd1_str', 'des_sym_range', 'des_opt_rq', 'des_op_code',
                        'des_opt_kernel_rotate', 'des_res_op_x_str', 'des_res_op_y_str', 'des_opd0_x_ins0',
                        'des_tsk_opd_num', 'des_opd0_dn_pad', 'des_intr_en', 'des_opt_relu', 'des_pwr_step', 'is_local']

    def process_file(self, layer_map):
        # file_name = f"{self.dirpath}/tiuRegInfo_0.txt"
        file_name = os.path.join(self.dirpath,'tiuRegInfo_0.txt')
        if os.path.exists(file_name) and os.path.getsize(file_name) > 0:
            self.chipArgs, self.linecount = parse_header(file_name, '__TIU_REG_INFO__')
            self.frequency = int(self.chipArgs['TIU Frequency(MHz)'])
            coreNum = int(self.chipArgs['Core Num'])
            for coreId in range(int(coreNum)):
                curTiuRegFile = f"{self.dirpath}/tiuRegInfo" + '_' + str(coreId) + '.txt'
                if os.path.exists(curTiuRegFile) and os.path.getsize(curTiuRegFile) != 0:
                    self.actual_corenum += 1
            # self.actual_corelist = [str[i] for i in range(0, actualCoreNum)]
            tiuDf_list = [] #list of tiu dataframes
            for coreId in range(self.actual_corenum):
                tiuDf_list.append(self.process_data(coreId, layer_map))
            return tiuDf_list
        else:
            self.tiu_cycle_list.append(0)
            return []

    def process_data(self, coreId, layer_map):
        TiuCycle = 0
        algTotalCycle = 0
        algTotalOps = 0
        uArchTotalOps = 0
        lane_num = int(self.chipArgs['NPU Num'])
        totalInstRegList = []
        startTime = sys.maxsize
        endTime = 0

        curTiuRegFile = f"{self.dirpath}/tiuRegInfo" + '_' + str(coreId) + '.txt'
        _, new_regList = parse_records(
            curTiuRegFile, '__TIU_REG_INFO__', self.columns,
            skip_lines=self.linecount, has_func_type=True
        )
        apply_layer_map_full(new_regList, layer_map, coreId)

        for i in range(len(new_regList)):
            regDict = new_regList[i] #tiuRegDict
            if regDict['Asic Cycle'].isnumeric() and not (regDict['des_tsk_typ'] == '15' and regDict['des_tsk_eu_typ'] == '9'):
                TiuCycle += int(regDict['Asic Cycle'])
            if regDict['Alg Cycle'].isnumeric():
                algTotalCycle += int(regDict['Alg Cycle'])
            if regDict['Alg Ops'].isnumeric():
                algTotalOps += int(regDict['Alg Ops'])
            if regDict['uArch Ops'].isnumeric():
                uArchTotalOps += int(regDict['uArch Ops'])
            if regDict['des_opt_opd0_prec'].isnumeric():
                regDict['Data Type'] = data_type_dict[regDict['des_opt_opd0_prec']] + \
                                        ' -> ' + data_type_dict[regDict['des_opt_res0_prec']]
            else:
                regDict['Data Type'] = data_type_dict[regDict['des_opt_res0_prec']] + \
                                        ' -> ' + data_type_dict[regDict['des_opt_res0_prec']]
            regDict['Start Cycle'] = int(regDict['Start Cycle'])
            regDict['End Cycle'] = int(regDict['End Cycle'])
            regDict['Asic Cycle'] = int(regDict['Asic Cycle'])
            # regDict['Start Time'] = get_realtime_from_cycle(regDict['Start Cycle'],self.frequency) #ns
            # regDict['End Time'] = get_realtime_from_cycle(regDict['End Cycle'],self.frequency) #ns

            startTime = min(startTime, get_time_by_cycle(regDict['Start Cycle'], self.frequency))
            endTime = max(endTime, get_time_by_cycle(regDict['End Cycle'], self.frequency))
            totalInstRegList.append(regDict)
        self.total_time_dict["start"].append(startTime)
        self.total_time_dict["end"].append(endTime)
        self.tiu_cycle_list.append(TiuCycle)
        # self.tiu_working_ratio_list.append('0.00%' if simTotalCycle == 0 else
        #                                str(Decimal((TiuCycle / simTotalCycle * 100)).quantize(
        #                                    Decimal("0.00"))) + '%')
        self.total_alg_cycle_list.append(algTotalCycle)
        self.total_alg_ops_list.append(algTotalOps)
        self.total_uarch_ops_list.append(uArchTotalOps)
        self.uArach_rate_list.append('0.00%' if uArchTotalOps == 0 else str(
                        Decimal((algTotalOps / uArchTotalOps * 100)).quantize(Decimal("0.00"))) + '%')
        self.regList.append(totalInstRegList)

        tiuDf = pd.DataFrame(totalInstRegList)
        tiuCols = self.columns
        newTiuCols = []
        for tiuCol in tiuCols:
            if tiuCol in tiuDf.columns.values.tolist():
                newTiuCols.append(tiuCol)
        tiuCols = newTiuCols
        tiuDf = tiuDf[tiuCols]
        for col in tiuCols:
            if 'addr' in col or 'mask' in col:
                tiuDf[col] = intToHex(tiuDf[col].values)
        #process tiu compute tensor size (vectorized)
        groups = [
            ['des_res0_n', 'des_res0_c', 'des_res0_h', 'des_res0_w', 'des_opt_res0_prec', 'des_res0_size'],
            ['des_opd0_n', 'des_opd0_c', 'des_opd0_h', 'des_opd0_w', 'des_opt_opd0_prec', 'des_opd0_size'],
            ['des_opd1_n', 'des_opd1_c', 'des_opd1_h', 'des_opd1_w', 'des_opt_opd1_prec', 'des_opd1_size']
        ]

        for n_col, c_col, h_col, w_col, prec_col, new_col in groups:
            if prec_col not in tiuDf.columns:
                tiuDf[new_col] = None
                continue
            byte_sizes = tiuDf[prec_col].map(data_size_dict)
            valid = byte_sizes.notna()
            if not valid.any():
                tiuDf[new_col] = None
                continue
            product = byte_sizes.copy()
            any_dim_valid = pd.Series(False, index=tiuDf.index)
            for dim_col in [n_col, c_col, h_col, w_col]:
                if dim_col not in tiuDf.columns:
                    continue
                dim_vals = pd.to_numeric(tiuDf[dim_col], errors='coerce')
                dim_valid = dim_vals.notna() & (dim_vals != 0)
                any_dim_valid = any_dim_valid | dim_valid
                # Skip zero/empty dims (identity=1) instead of propagating NaN
                dim_vals = dim_vals.where(dim_valid, other=1.0)
                product = product * dim_vals
            result = product.where(valid & any_dim_valid)
            # Convert NaN to None for downstream compatibility
            tiuDf[new_col] = result.astype(object).where(result.notna(), other=None)
        return tiuDf
