# ==============================================================================
#
# Copyright (C) 2022 bigtpu Technologies Inc.  All rights reserved.
#
# TPU-MLIR is licensed under the 2-Clause BSD License except for the
# third-party components.
#
# ==============================================================================

import pandas as pd
from decimal import Decimal
import os
import sys
import glob, re

from ..utils.utils import *
from shared_parser import parse_header, parse_records, apply_layer_map_full, filter_by_engine_id

class DMA(): #GDMA/SDMA/CDMA
    def __init__(self, dirpath, dmaType):
        self.dirpath = dirpath
        self.dmaType = dmaType
        self.chipArgs = dict()
        self.linecount = 0
        self.actual_corenum = 0
        self.regList = []
        self.total_time_dict = {"start":[], "end":[]}
        self.dma_cycle_list = []
        self.dma_ddr_total_datasize_list = []
        self.dma_l2_total_datasize_list = []
        self.dma_ddr_avg_bw_list = []
        self.dma_l2_avg_bw_list = []
        self.ddr_total_cycle = 0
        self.l2_total_cycle = 0
        self.frequency = 0
        self.columns = ['Engine Id', 'Core Id', 'Global Idx', 'Cmd Id', 'Layer Id', 'Layer Name', 'Subnet Id', 'Subnet Type', 'File Line',
                        'Function Type', 'Function Name', 'DMA data size(B)', 'Start Cycle', 'End Cycle',
                        'Asic Cycle', 'Stall Cycle', 'DDR Bandwidth(GB/s)','L2M Bandwidth(GB/s)', 'Direction', 'Data Type',
                        'cmd_id_dep', 'cmd_special_function', 'src_start_addr', 'dst_start_addr',
                        'index_shape', 'src_shape', 'dst_shape',
                        'src_nsize', 'src_csize', 'src_hsize', 'src_wsize',
                        'dst_nsize', 'dst_csize', 'dst_hsize', 'dst_wsize',
                        'src_nstride', 'src_cstride', 'src_wstride', 'src_hstride',
                        'dst_nstride', 'dst_cstride', 'dst_hstride', 'dst_wstride',
                        'nchw_copy', 'stride_enable', 'src_data_format', 'cmd_type',
                        'index_csize', 'index_hsize', 'index_cstride', 'index_hstride',
                        'mask_start_addr_h8', 'mask_start_addr_l32', 'mask_data_format', 'localmem_mask_h32',
                        'localmem_mask_l32',
                        'fill_constant_en', 'constant_value', 'index', 'cmd_short', 'intr_en', 'is_local']
        self.sys_cmd_id = '6';
        self.sys_wait_id = ['4']
        if self.dmaType == 'CDMA':
            self.sys_cmd_id = '7'
            self.sys_wait_id = ['4', '6']

    def dma_engine_type(self):
        if self.dmaType == 'CDMA':
            return '4'
        elif self.dmaType == 'GDMA':
            self.dmaType = 'TDMA'
            return '1'
        elif self.dmaType == 'SDMA':
            self.dmaType = 'TDMA'
            return '3'

    # def process_file(self, layer_map):
    #     engineId = self.dma_engine_type()
    #     # file_name = f"{self.dirpath}/{self.dmaType.lower()}RegInfo_0.txt"
    #     file_name = os.path.join(self.dirpath,f'{self.dmaType.lower()}RegInfo_0.txt')
    #     if os.path.exists(file_name) and os.path.getsize(file_name) > 0:
    #         with open(file_name, "r") as f:
    #             lines = f.readlines()
    #             for line in lines:
    #                 self.linecount += 1
    #                 if "\t" in line:
    #                     fields = line.split(': ')
    #                     attr = fields[0][1:]
    #                     val = fields[1][:-1]
    #                     self.chipArgs[attr] = val
    #                 if f'__{self.dmaType}_REG_INFO__' in line:
    #                     break
    #         self.frequency = int(self.chipArgs['DMA Frequency(MHz)'])
    #         coreNum = int(self.chipArgs['Core Num'])
    #         for coreId in range(int(coreNum)):
    #             curDmaRegFile = f"{self.dirpath}/{self.dmaType.lower()}RegInfo" + '_' + str(coreId) + '.txt'
    #             if os.path.exists(curDmaRegFile) and os.path.getsize(curDmaRegFile) != 0:
    #                 self.actual_corenum += 1
    #         dmaDf_list = [] #list of tiu dataframes
    #         for coreId in range(self.actual_corenum):
    #             dmaDf_list.append(self.process_data(coreId,engineId,layer_map))
    #         return dmaDf_list
    #     else:
    #         self.dma_cycle_list.append(0)
    #         return []
    def process_file(self, layer_map):
        engineId = self.dma_engine_type()
        # file_name = f"{self.dirpath}/{self.dmaType.lower()}RegInfo_0.txt"
        # file_name = os.path.join(self.dirpath,f'{self.dmaType.lower()}RegInfo_0.txt')
        file_names = sorted(glob.glob(self.dirpath + f"{self.dmaType.lower()}RegInfo_*.txt"))
        if file_names and os.path.exists(file_names[0]) and os.path.getsize(file_names[0]) > 0:
            self.chipArgs, self.linecount = parse_header(file_names[0], f'__{self.dmaType}_REG_INFO__')
            self.frequency = int(self.chipArgs['DMA Frequency(MHz)'])
            coreNum = int(self.chipArgs['Core Num'])
            if engineId != '4':
                for coreId in range(int(coreNum)):
                    curDmaRegFile = f"{self.dirpath}/{self.dmaType.lower()}RegInfo" + '_' + str(coreId) + '.txt'
                    if os.path.exists(curDmaRegFile) and os.path.getsize(curDmaRegFile) != 0:
                        self.actual_corenum += 1
                dmaDf_list = [] #list of tiu dataframes
                for coreId in range(self.actual_corenum):
                    dmaDf_list.append(self.process_data(coreId,engineId,layer_map))
                return dmaDf_list
            else:
                self.actual_corenum = 1
                dmaDf_list = []
                for f in file_names:
                    port = eval(re.search(rf"{self.dmaType.lower()}RegInfo_(\d+)\.txt", f).group(1))
                    data = self.process_data(port,engineId,layer_map)
                    data.port = port
                    dmaDf_list.append(data)
                return dmaDf_list

        else:
            self.dma_cycle_list.append(0)
            return []

    def process_data(self, coreId, engineId, layer_map):
        curDmaRegFile = f"{self.dirpath}/{self.dmaType.lower()}RegInfo" + '_' + str(coreId) + '.txt'
        _, new_reglist = parse_records(
            curDmaRegFile, f'__{self.dmaType}_REG_INFO__', self.columns,
            skip_lines=self.linecount, has_func_type=False
        )
        apply_layer_map_full(new_reglist, layer_map, coreId)
        new_reglist = filter_by_engine_id(new_reglist, engineId)
        startTime = sys.maxsize
        endTime = 0
        DmaCycle = 0
        dmaDdrTotalDataSize = 0
        dmaL2TotalDataSize = 0
        dmaWaitMsgTotalTime = 0
        dmaDdrCycle = 0
        dmaL2Cycle = 0
        dmaDdrBurstLength = 0
        dmaDdrXactCnt = 0
        totalInstRegList = []
        for i in range(len(new_reglist)):
            regDict = new_reglist[i]
            # dma_sys do not transfer data
            if regDict['cmd_type'] == self.sys_cmd_id:
                regDict['Data Type'] = 'None'
                regDict['Direction'] = '-'
            transfer_bytes = 0
            if regDict['DMA data size(B)'].isnumeric():
                transfer_bytes = int(regDict['DMA data size(B)'])
            if regDict['Asic Cycle'].isnumeric():
                DmaCycle += int(regDict['Asic Cycle'])
            if 'DDR' in regDict['Direction'] and regDict['DMA data size(B)'].isnumeric():
                if self.dmaType != 'CDMA' or transfer_bytes:
                    dmaDdrTotalDataSize += transfer_bytes
                    dmaDdrCycle += float(regDict['Asic Cycle'])
            elif 'L2' in regDict['Direction'] and regDict['DMA data size(B)'].isnumeric():
                if self.dmaType != 'CDMA' or transfer_bytes:
                    dmaL2TotalDataSize += transfer_bytes
                    dmaL2Cycle += float(regDict['Asic Cycle'])
            if regDict['cmd_type'] == self.sys_cmd_id and regDict['cmd_special_function'] in self.sys_wait_id:
                dmaWaitMsgTotalTime += eval(regDict['Asic Cycle'])
            regDict['Start Cycle'] = int(regDict['Start Cycle'])
            regDict['End Cycle'] = int(regDict['End Cycle'])
            regDict['Asic Cycle'] = int(regDict['Asic Cycle'])
            # regDict['Start Cycle'] = get_realtime_from_cycle(int(regDict['Start Cycle']),self.frequency)
            # regDict['End Cycle'] = get_realtime_from_cycle(int(regDict['End Cycle']),self.frequency)
            regDict['DDR Bandwidth(GB/s)'] = round(float(regDict['DDR Bandwidth(GB/s)']), 2)
            regDict['L2M Bandwidth(GB/s)'] = round(float(regDict['L2M Bandwidth(GB/s)']), 2)
            startTime = min(startTime, get_time_by_cycle(regDict['Start Cycle'], self.frequency))
            endTime = max(endTime, get_time_by_cycle(regDict['End Cycle'], self.frequency))
            totalInstRegList.append(regDict)

        self.regList.append(totalInstRegList)
        self.total_time_dict["start"].append(startTime)
        self.total_time_dict["end"].append(endTime)
        self.dma_cycle_list.append(DmaCycle - dmaWaitMsgTotalTime)
        self.dma_ddr_total_datasize_list.append(dmaDdrTotalDataSize)
        self.dma_l2_total_datasize_list.append(dmaL2TotalDataSize)
        if dmaDdrCycle > 0:
            dmaDdrTotalBandWidth = str(Decimal((dmaDdrTotalDataSize / dmaDdrCycle * self.frequency / 1000)).quantize(Decimal("0.00")))
        else:
            dmaDdrTotalBandWidth = 0
        if dmaL2Cycle > 0:
            dmaL2TotalBandWidth = str(Decimal((dmaL2TotalDataSize / dmaL2Cycle * self.frequency / 1000)).quantize(Decimal("0.00")))
        else:
            dmaL2TotalBandWidth = 0
        self.ddr_total_cycle += dmaDdrCycle
        self.l2_total_cycle += dmaL2Cycle
        self.dma_ddr_avg_bw_list.append(dmaDdrTotalBandWidth)
        self.dma_l2_avg_bw_list.append(dmaL2TotalBandWidth)

        dmaDf = pd.DataFrame(totalInstRegList)
        new_df = pd.DataFrame()
        if len(dmaDf) > 0:
            for column in self.columns:
                if column in dmaDf.columns:
                    new_df[column] = dmaDf[column]
                else:
                    new_df[column] = None
            pre_clos = dmaDf.columns
            dmaDf = new_df
            for col in self.columns:
                if ('addr' in col or 'mask' in col) and col in pre_clos:
                    dmaDf[col] = intToHex(dmaDf[col].values)
        return dmaDf
