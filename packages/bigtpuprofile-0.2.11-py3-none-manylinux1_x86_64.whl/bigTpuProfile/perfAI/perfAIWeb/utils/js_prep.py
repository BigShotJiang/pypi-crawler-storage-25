# ==============================================================================
#
# Copyright (C) 2022 bigtpu Technologies Inc.  All rights reserved.
#
# TPU-MLIR is licensed under the 2-Clause BSD License except for the
# third-party components.
#
# ==============================================================================
import pandas as pd
from decimal import Decimal
from numpy import transpose
import os
from functools import reduce
from collections import defaultdict
import math
from concurrent.futures import ThreadPoolExecutor

from ..src.tiu import TIU
from ..src.dma import DMA
from ..src.summary import SummaryProcessor
from ..src.mlir_json import *
from ..src.mlir_json import GlobalProfileParser
from ..utils.utils import *


def generate_jsfile(dirpath, name, out_path, file_path, layerinfo_path):
    include_layer = False
    parser = GlobalProfileParser()
    result = parser.parse(layerinfo_path)
    if result is not None:
        mlir_info, file_line_dict = result
        tiu_layer_map, dma_layer_map = get_engine_layer(mlir_info)
    else:
        mlir_info = None
        file_line_dict = None
    tiu_layer_map, dma_layer_map = get_engine_layer(mlir_info)
    # Parallelize engine file processing (each reads different files)
    tiuProcessor = TIU(dirpath)
    gdmaProcessor = DMA(dirpath, "GDMA")
    sdmaProcessor = DMA(dirpath, "SDMA")
    cdmaProcessor = DMA(dirpath, "CDMA")
    with ThreadPoolExecutor(max_workers=4) as executor:
        tiu_future = executor.submit(tiuProcessor.process_file, tiu_layer_map)
        gdma_future = executor.submit(gdmaProcessor.process_file, dma_layer_map)
        sdma_future = executor.submit(sdmaProcessor.process_file, dma_layer_map)
        cdma_future = executor.submit(cdmaProcessor.process_file, dma_layer_map)
        tiu_instance = tiu_future.result()
        gdma_instances = gdma_future.result()
        sdma_instances = sdma_future.result()
        cdma_instances = cdma_future.result()
    processors = [tiuProcessor, gdmaProcessor, sdmaProcessor, cdmaProcessor]
    chipArchArgs = None
    for processor in processors:
        if processor.chipArgs:
            chipArchArgs = processor.chipArgs
            break
    global CHIP_ARCH
    CHIP_ARCH = chipArchArgs['Chip Arch']
    print("CHIP_ARCH:",CHIP_ARCH)
    # core_num = int(chipArchArgs['Core Num'])
    core_num = max(tiuProcessor.actual_corenum, gdmaProcessor.actual_corenum, sdmaProcessor.actual_corenum, cdmaProcessor.actual_corenum)
    ddrBw = pd.to_numeric(chipArchArgs['DDR Max BW(GB/s/Core)'])
    L2Bw = pd.to_numeric(chipArchArgs['L2 Max BW(GB/s)'])
    dependCmds = parse_cmdgroups(file_path)
    time_header = ["category", "begin_time", "end_time", "Duration", "stall_time", "func_type", "height", "cmd", "func_name", "global_idx", "uArchRate/BW", "Data Type", "Info","is_local"]
    filter_cols = [time_header.index(c) for c in ["category", "func_type"]]
    # time_header = ["category", "begin_time", "end_time", "Duration", "stall_time", "func_type", "height", "cmd", "func_name", 'layer_id','layer_name','subnet_id','subnet_type',"uArchRate/BW", "Data Type", "Info","Msg_Id","Sd/Wt_Count"]
    # filter_cols.extend([time_header.index(c) for c in ['layer_id','layer_name','subnet_id','subnet_type']])

    categories = ["TPU_BD", "TPU_GDMA"]
    if any([len(i) for i in sdma_instances]):
        categories.append("TPU_SDMA")
    if len(cdma_instances) > 0:
        for inst in cdma_instances:
            categories.append(f"TPU_CDMA_PORT{inst.port}")
    if tiu_layer_map or dma_layer_map:
        include_layer = True
        categories.append("TPU_LAYER")
        categories.append("TPU_GROUP_LAYER")
        time_header = ["category", "begin_time", "end_time", "Duration", "stall_time", "func_type", "height", "cmd", "func_name", 'layer_id','layer_name','subnet_id','subnet_type', "global_idx", "uArchRate/BW", "Data Type", "Info","is_local"]
        filter_cols.extend([time_header.index(c) for c in ['layer_id','layer_name','subnet_id','subnet_type']])
    lmem_size = int(chipArchArgs['TPU Lmem Size(MiB)'])
    lane_num = int(chipArchArgs['NPU Num'])
    lane_size  = lmem_size // lane_num
    lmem_partition = generate_partition(lmem_size,lane_num,'BANK')

    cycle_data_dict = {f"time_data{i}": [] for i in range(0, core_num)}
    lmem_op_dict = {f"lmem_op_record{i}": [] for i in range(0, core_num)}

    max_corenum = max(len(tiu_instance), len(gdma_instances), len(sdma_instances), len(cdma_instances))
    for idx in range(max_corenum):
        if idx < len(tiu_instance):
            tiudf = tiu_instance[idx]
            prepare_data(include_layer, tiudf, tiuProcessor.frequency, idx, 0, [ddrBw, L2Bw], lane_num, cycle_data_dict, lmem_op_dict, lane_size)

        if idx < len(gdma_instances):
            gdmadf = gdma_instances[idx]
            prepare_data(include_layer, gdmadf, gdmaProcessor.frequency, idx, 1, [ddrBw, L2Bw], lane_num, cycle_data_dict, lmem_op_dict, lane_size)

        if idx < len(sdma_instances):
            sdmadf = sdma_instances[idx]
            if not sdmadf.empty:
                prepare_data(include_layer, sdmadf, sdmaProcessor.frequency, idx, categories.index("TPU_SDMA"), [ddrBw, L2Bw], lane_num, cycle_data_dict, lmem_op_dict, lane_size)

        if idx == max_corenum - 1:
            for i in range(len(cdma_instances)):
                cdmadf = cdma_instances[i]
                prepare_data(include_layer, cdmadf, cdmaProcessor.frequency,idx, categories.index(f"TPU_CDMA_PORT{cdmadf.port}"), [ddrBw, L2Bw], lane_num, cycle_data_dict, lmem_op_dict, lane_size)

    for keyname in cycle_data_dict.keys():
        cycle_data_dict[keyname] = deduplicate_ordered_list(cycle_data_dict[keyname])
    for lmem_op in lmem_op_dict.keys():
        lmem_op_dict[lmem_op] = deduplicate_ordered_list(lmem_op_dict[lmem_op])

    cycle_data_dict = merge_layer_data(cycle_data_dict, categories)
    cycle_data_dict = merge_group_layer_data(cycle_data_dict, categories, file_line_dict)

    summary = SummaryProcessor(tiuProcessor, gdmaProcessor, sdmaProcessor,cdmaProcessor)
    summarydf = summary.make_summary()
    summary_data =[[str(x) if isinstance(x,Decimal) else x for x in lst] for lst in summarydf.values.tolist()]

    # if CHIP_ARCH == 'sg2260':
    #     ddr_ratios, l2m_ratios = calculate_ratios(cycle_data_dict)
    # else:
    #     ddr_ratios, l2m_ratios = [], []
    data_filepath = f"{out_path}/profile_data.js"
    with open(data_filepath, "w") as js:
        js.write(f'let page_caption = "PerfAI: {name}"\n')
        js.write(f'let platform = "Platform: {CHIP_ARCH}"\n')
        js.write(f'let configs = {chipArchArgs}\n')
        js.write('let summary_caption= "Summary Table"\n')
        js.write(f'let summary_header =  {summarydf.columns.tolist()}\n')
        js.write(f'let summary_data = {summary_data}\n')
        js.write(f'let ddr_bandwidth = {ddrBw}\n')
        js.write(f'let l2_bandwidth = {L2Bw}\n')
        # js.write(f'let ddr_ratios = {ddr_ratios}\n')
        # js.write(f'let l2m_ratios = {l2m_ratios}\n')
        js.write(f'let dependCmds = {dependCmds}\n')
        js.write(f'let categories = {categories}\n')
        js.write(f'let filter_cols = {filter_cols}\n')
        js.write(f'let lmem_partition = {lmem_partition}\n')
        js.write(f'let time_header = {time_header}\n')
        js.write(f'let actual_core_num = {len(cycle_data_dict.keys())}')
    for lmem_op in lmem_op_dict.keys():
        js_content = "\n".join(f"{sublist}," for sublist in lmem_op_dict[lmem_op])
        with open(f"{out_path}/{lmem_op}.js", "w") as js:
            js.write(f'window.{lmem_op} = [{js_content}]\n')

    for keyname in cycle_data_dict.keys():
        js_content = "\n".join(f"{sublist}," for sublist in cycle_data_dict[keyname])
        with open(f"{out_path}/{keyname}.js", "w") as js:
            js.write(f'window.{keyname} = [{js_content}]\n')

def prepare_data(if_layer, data, frequency, idx, ip_type, bwlist, lane_num, cycle_data_dict, lmem_op_dict, lane_size):
    if data is None or data.empty:
        return
    read_directions = ['DDR->LMEM'] + [f'DDR->LMEM{i}' for i in range(8)] + [f'L2M->LMEM{i}' for i in range(8)] + [f'L2M{i}->LMEM{i}' for i in range(8)]
    write_directions = ['LMEM->DDR'] + [f'LMEM{i}->DDR' for i in range(8)] + [f'LMEM{i}->L2M' for i in range(8)] + [f'LMEM{i}->L2M{i}' for i in range(8)]
    lmem_temp = []
    frequency = int(frequency)

    # Pre-check columns existence
    has_ddr_bw = 'DDR Bandwidth(GB/s)' in data.columns
    has_uarch_rate = 'uArch Rate' in data.columns
    has_function_type = 'Function Type' in data.columns
    has_stall_cycle = 'Stall Cycle' in data.columns
    has_direction = 'Direction' in data.columns
    has_bank_conflict = 'Bank Conflict Ratio' in data.columns

    # Pre-convert all needed columns to lists (avoid repeated DataFrame indexing)
    start_cycle_col = data['Start Cycle'].tolist()
    end_cycle_col = data['End Cycle'].tolist()
    asic_cycle_col = data['Asic Cycle'].tolist()
    cmd_id_col = data['Cmd Id'].tolist()
    func_name_col = data['Function Name'].tolist()
    global_idx_col = data['Global Idx'].tolist()
    data_type_col = data['Data Type'].tolist()
    is_local_col = data['is_local'].tolist()

    # Conditionally cache columns
    if has_uarch_rate:
        uarch_rate_col = data['uArch Rate'].tolist()
    if has_function_type:
        func_type_col = data['Function Type'].tolist()
    if has_stall_cycle:
        stall_cycle_col = data['Stall Cycle'].tolist()
    if if_layer:
        layer_id_col = data['Layer Id'].tolist()
        layer_name_col = data['Layer Name'].tolist()
        subnet_id_col = data['Subnet Id'].tolist()
        subnet_type_col = data['Subnet Type'].tolist()
        file_line_col = data['File Line'].tolist()
    if has_direction:
        direction_col = data['Direction'].tolist()
        src_addr_col = data['src_start_addr'].tolist()
        dst_addr_col = data['dst_start_addr'].tolist()
        dma_size_col = data['DMA data size(B)'].tolist()
        dst_shape_col = data['dst_shape'].tolist()
        src_shape_col = data['src_shape'].tolist()
    if has_bank_conflict:
        bank_conflict_col = data['Bank Conflict Ratio'].tolist()
    if has_ddr_bw:
        ddr_bw_col = data['DDR Bandwidth(GB/s)'].apply(lambda x: str(x) if isinstance(x, Decimal) else x).tolist()
        l2m_bw_col = data['L2M Bandwidth(GB/s)'].apply(lambda x: str(x) if isinstance(x, Decimal) else x).tolist()
    if 'des_res0_c' in data.columns:
        des_res0_c_col = data['des_res0_c'].tolist()
    if 'des_res0_size' in data.columns:
        des_res0_size_col = data['des_res0_size'].tolist()
        des_res0_addr_col = data['des_res0_addr'].tolist()
    if 'des_opd0_size' in data.columns:
        des_opd0_size_col = data['des_opd0_size'].tolist()
        des_opd0_addr_col = data['des_opd0_addr'].tolist()
        if 'des_opd1_size' in data.columns:
            des_opd1_size_col = data['des_opd1_size'].tolist()
        else:
            des_opd1_size_col = None

    time_data_list = []
    n_rows = len(data)

    for i in range(n_rows):
        cmd = int(cmd_id_col[i])

        # Calculate height
        if has_ddr_bw:
            direction_val = direction_col[i] if has_direction else ''
            if 'L2M' in direction_val:
                height = float(round(pd.to_numeric(l2m_bw_col[i]) / bwlist[1], 2))
            else:
                height = float(round(pd.to_numeric(ddr_bw_col[i]) / (bwlist[0] + 1e-6), 2))
        elif has_uarch_rate:
            uarch_rate_str = uarch_rate_col[i]
            uarch_rate = pd.to_numeric(str(uarch_rate_str)[:-1]) if uarch_rate_str else None
            height = float(round(uarch_rate / 100, 2)) if uarch_rate else 0
        else:
            height = 0

        # Build main record
        tmp = [
            ip_type,
            get_realtime_from_cycle(start_cycle_col[i], frequency),
            get_realtime_from_cycle(end_cycle_col[i], frequency),
            get_realtime_from_cycle(asic_cycle_col[i], frequency),
            int(stall_cycle_col[i]) if has_stall_cycle and stall_cycle_col[i] is not None else '',
            func_type_col[i] if has_function_type else '',
            height,
            cmd,
            func_name_col[i]
        ]

        if if_layer:
            tmp.extend([
                layer_id_col[i],
                layer_name_col[i],
                subnet_id_col[i],
                subnet_type_col[i],
                file_line_col[i],
            ])

        # Add remaining fields
        if has_uarch_rate:
            uarch_str = uarch_rate_col[i]
        else:
            uarch_str = f"DDR:{ddr_bw_col[i]},L2M:{l2m_bw_col[i]}"

        direction_info = f"Direction:{direction_col[i]}" if has_direction else ""

        tmp.extend([
            global_idx_col[i],
            uarch_str,
            data_type_col[i],
            direction_info,
            int(is_local_col[i]),
        ])
        time_data_list.append(tmp)

        # Prepare memory graph data
        if has_direction:
            direction = direction_col[i]
            src = src_addr_col[i]
            dst = dst_addr_col[i]
            datasize = pd.to_numeric(dma_size_col[i])
            op_type = 0 if direction in read_directions else 1

            if direction in read_directions:
                size = float(datasize / lane_num)
                info = f'{type}{cmd},physical start addr:{dst}<br>{direction},{dst_shape_col[i]}'
                lmem_temp.append([int(start_cycle_col[i]), int(end_cycle_col[i]), op_type, dst, size, info])
            elif direction in write_directions:
                size = float(datasize / lane_num)
                info = f'{type}{cmd},physical start addr:{src}<br>{direction},{src_shape_col[i]}'
                lmem_temp.append([int(start_cycle_col[i]), int(end_cycle_col[i]), op_type, src, size, info])

        # Handle descriptor data
        if 'des_res0_c' in data.columns:
            des_res0_c_val = des_res0_c_col[i] if des_res0_c_col[i] else 0
            worklane = int(des_res0_c_val) if (int(des_res0_c_val) and int(des_res0_c_val) < lane_num) else lane_num
        else:
            worklane = lane_num

        if 'des_res0_size' in data.columns and des_res0_size_col[i] is not None:
            size = float(des_res0_size_col[i] / worklane)
            info = f'{type}{cmd},physical start addr:{des_res0_addr_col[i]}'
            lmem_temp.append([int(start_cycle_col[i]), int(end_cycle_col[i]), 0, des_res0_addr_col[i], size, info])

        if 'des_opd0_size' in data.columns and des_opd0_size_col[i] is not None:
            opd1_val = des_opd1_size_col[i] if des_opd1_size_col else None
            total_size = des_opd0_size_col[i] + (opd1_val if opd1_val is not None else 0)
            size = float(total_size / worklane)
            info = f'{type}{cmd},physical start addr:{des_opd0_addr_col[i]}'
            lmem_temp.append([int(start_cycle_col[i]), int(end_cycle_col[i]), 1, des_opd0_addr_col[i], size, info])

    # Batch append to cycle_data_dict (single extend instead of multiple appends)
    cycle_data_dict[f'time_data{idx}'].extend(time_data_list)

    # Process lmem data once at the end
    process_lmem = processAddr(lmem_temp, lane_size) if len(lmem_temp) > 0 else lmem_temp
    lmem_op_dict[f'lmem_op_record{idx}'].extend(process_lmem)


def merge_layer_data(cycle_data_dict, categories):
    if "TPU_LAYER" not in categories:
        return cycle_data_dict  # 如果categories中不包含TPU_LAYER，则不进行任何操作

    ip_type = categories.index("TPU_LAYER")
    half_height_layers = ['Store', 'Load']
    for key in cycle_data_dict.keys():
        data = cycle_data_dict[key]
        layer_data = {}

        # group by layer_id
        for entry in data:
            layer_id = entry[9]
            if layer_id == '-':
                continue
            if layer_id not in layer_data:
                layer_data[layer_id] = []
            layer_data[layer_id].append(entry)
        for layer_id, entries in layer_data.items():
            if entries[0][5] == 'SYS_TR_ACC':
                entries.pop(0)
            layer_name = entries[0][10]
            subnet_id = entries[0][11]
            subnet_type = entries[0][12]

            is_local = entries[0][18]
            height = 0.5 if layer_name in half_height_layers else 1.0
            if not is_local:
                start_times = [int(e[1]) for e in entries]
                end_times = [int(e[2]) for e in entries]
                earliest_start = min(start_times)
                latest_end = max(end_times)
                duration = latest_end - earliest_start

                merged_entry = [
                    ip_type, earliest_start, latest_end, duration, '', layer_name, height,
                    '', layer_name, layer_id, layer_name, subnet_id, subnet_type,
                    '', '', '', '',''
                ] ##info: to be filled
                data.append(merged_entry)
            else:
                entries.sort(key = lambda x: int(x[7]))
                merged_ranges = []
                curr_range = [int(entries[0][1]), int(entries[0][2])]
                prev_cmd = int(entries[0][7])
                for entry in entries[1:]:
                    curr_cmd = int(entry[7])
                    curr_start = int(entry[1])
                    curr_end = int(entry[2])
                    if curr_cmd == prev_cmd + 1:
                        curr_range[1] = max(curr_range[1], curr_end)
                    else:
                        merged_ranges.append(curr_range)
                        curr_range = [curr_start, curr_end]
                    prev_cmd = curr_cmd
                merged_ranges.append(curr_range)
                for start_time, end_time in merged_ranges:
                    duration = end_time - start_time
                    merged_entry = [
                        ip_type, start_time, end_time, duration, '', layer_name, height,
                        '', layer_name, layer_id, layer_name, subnet_id, subnet_type,
                        '', '', '', '',''
                    ] ##info: to be filled
                    data.append(merged_entry)

        cycle_data_dict[key] = data
    return cycle_data_dict


def merge_group_layer_data(cycle_data_dict, categories, file_line_dict):
    if "TPU_GROUP_LAYER" not in categories:
        return cycle_data_dict  # If the categories do not include TPU_GROUP-LAYER, no action will be taken

    ip_type = categories.index("TPU_GROUP_LAYER")
    for key in cycle_data_dict.keys():
        data = cycle_data_dict[key]
        group_data = {}
        group_num = 1
        # group by group
        for entry in data:
            file_line = entry[13]
            if type(file_line) != str and file_line is not None and not math.isnan(file_line):
                for file_line_dict_key in file_line_dict:
                    if file_line in file_line_dict[file_line_dict_key]:
                        if file_line_dict_key not in group_data:
                            group_data[file_line_dict_key] = []
                        group_data[file_line_dict_key].append(entry)

        for group_id, entries in group_data.items():
            start_times = [int(e[1]) for e in entries]
            end_times = [int(e[2]) for e in entries]
            earliest_start = min(start_times)
            latest_end = max(end_times)
            duration = latest_end - earliest_start
            layer_name = f'Group{group_num}  L{group_id}'
            subnet_id = entries[0][11]
            subnet_type = entries[0][12]
            group_num += 1

            merged_entry = [
                ip_type, earliest_start, latest_end, duration, '', layer_name, 0.5,
                '', '', '', '', subnet_id, subnet_type,
                '', '', '', '',''
            ] ##info: to be filled
            data.append(merged_entry)

        cycle_data_dict[key] = data

    for key in cycle_data_dict:
        for entry in cycle_data_dict[key]:
            del entry[13]

    return cycle_data_dict


def parse_cmdgroups(file_path):
    mapped_lines = []
    if file_path:
        try:
            with open(file_path, 'r') as file:
                lines = file.readlines()
                for line in lines:
                    components = line.strip().split()
                    mapped_components = [component.replace('T', 'TIU').replace('G', 'GDMA').replace('S', 'SDMA') for component in components]
                    mapped_lines.append(mapped_components)
                return mapped_lines
        except FileNotFoundError:
            raise FileNotFoundError("The specified file does not exist. Please check the path.")
    else:
        return mapped_lines

def generate_partition(lmem_size, lane_num, type_name):
    partition = []
    start_value = 0
    divisor = 1 if type_name == 'LANE' else 16
    partition_size = lmem_size // lane_num // divisor
    num = lane_num if type_name == 'LANE' else 16
    for i in range(num):
        sublist = [start_value, partition_size, f'{type_name}[{i}]']
        partition.append(sublist)
        start_value += partition_size
    return partition

def multiply_non_zero_numbers(input_str):
    nums = input_str.split(')')[0][1:].split(',')
    result = reduce(lambda x, y: x * y, [int(n) for n in nums if int(n) != 0])
    return result

def deduplicate_ordered_list(lst):
    seen = set()
    deduped = []
    for item in sorted(lst, key=lambda x: x[0]):
        t_item = tuple(item)
        if t_item not in seen:
            seen.add(t_item)
            deduped.append(item)
    return deduped

def processAddr(lst, lane_size):
    dec_addr = [int(sublist[3], 16) for sublist in lst]
    new_lst = []
    min_value = min(dec_addr) # Aling the address for different cores
    for i, sublist in enumerate(lst):
        # Calculate the converted address value
        shifted_addr = dec_addr[i] - min_value
        new_shifted_addr = shifted_addr % lane_size
        lane_occupied = math.ceil(shifted_addr / lane_size)
        sublist[3] = new_shifted_addr
        sublist[-1] += f"<br>Occupied Lane#:{lane_occupied}" # add the num of lane used
        new_lst.append(sublist)
        # new_lst.append(lane_occupied) #modify the javascript
    return new_lst


def calculate_ratios(cycle_data_dict):
    ddr_ratios_dict = defaultdict(float)
    l2m_ratios_dict = defaultdict(float)
    prev_ddr_ratio, prev_l2m_ratio = None, None
    ddr_ratios, l2m_ratios = [], []

    for data in cycle_data_dict.values():
        # 使用生成器表达式进行过滤
        filtered_data = (
            record for record in data
            if record[0] in [1, 2] and "SYS" not in record[5] #GDMA/SDMA
        )

        for record in filtered_data:
            category, begin_time, end_time, _, _, _, _, _, _, uarch_bw, _, info, _, _ = record

            for time in range(begin_time + 1, end_time + 1):
                bw = float(uarch_bw)
                if 'DDR' in info and bw:
                    ddr_ratios_dict[time] += bw
                if 'L2M' in info and bw:
                    l2m_ratios_dict[time] += bw

    for time, bw in sorted(ddr_ratios_dict.items()):
        new_ddr_ratio = bw / 546
        if new_ddr_ratio != prev_ddr_ratio:
            ddr_ratios.append([time, new_ddr_ratio])
            prev_ddr_ratio = new_ddr_ratio

    for time, bw in sorted(l2m_ratios_dict.items()):
        new_l2m_ratio = bw / 1024
        if new_l2m_ratio != prev_l2m_ratio:
            l2m_ratios.append([time, new_l2m_ratio])
            prev_l2m_ratio = new_l2m_ratio

    return ddr_ratios, l2m_ratios
