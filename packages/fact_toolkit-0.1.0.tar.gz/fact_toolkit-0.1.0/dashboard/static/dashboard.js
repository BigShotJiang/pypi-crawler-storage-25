// FACT dashboard — vanilla JS, no framework.

(() => {
  let state = null;
  let ws = null;
  let reconnectTimer = null;
  const filters = { search: '', section: '', tag: '', hidePhase: false };
  let selectedFeature = null;

  // ---- i18n -------------------------------------------------------------
  const STRINGS = {
    en: {
      tasks: 'Tasks', cost: 'Cost', saved_vs_opus: 'Saved vs Opus',
      tokens_cumulative: 'Tokens (cumulative)', context_now: 'Context now',
      files: 'Files', by_model: 'By model',
      kanban_label: 'Kanban —', all_features: 'All features', all_filters: 'All filters',
      hide_workflow: 'Hide workflow', tags_btn: 'tags?',
      pending: 'Pending', in_progress: 'In Progress', done: 'Done',
      connecting: 'connecting…', reconnecting: 'reconnecting…', live: 'live',
      no_active_feature: 'no active feature', no_feature_yet: 'no feature yet',
      updated: 'updated', stories: 'stories', of: 'of',
      search_placeholder: 'Search story or task…',
      // Tooltips
      tip_tokens_cumulative: 'Cumulative tokens — these are what you actually paid for. They never decrease.',
      tip_input: 'Input — fresh tokens you sent the model. Tiny in long sessions.',
      tip_output: 'Output — what the agent generated. Reflects real work.',
      tip_cache: "Cache reads — re-reading the conversation from Anthropic's prompt cache (cheap, ~1/10 of input). Dominates long sessions.",
      tip_ctx_now: 'Size of the conversation cache RIGHT NOW (latest turn cache_read). Drops after /compact.',
      tip_feature_picker: 'Switch between features',
      tip_filter_tag: 'Filter by kind, priority, or task tag',
      tip_hide_workflow: 'Hide foundation / workflow stories',
      tip_legend: 'Tag legend',
      tip_lang: 'Toggle language / Cambiar idioma',
      // Context-now color tooltip pieces
      ctx_latest_turn: 'Latest turn cache_read', ctx_model: 'Model', ctx_window: 'window',
      ctx_usage: 'Usage', ctx_of_window: 'of context window',
      ctx_last_compaction: 'Last compaction', ctx_ago: 'ago',
      ctx_legend: 'Green <30% · Yellow 30-50% · Red ≥50%.',
      ctx_safety_note: 'Safety-net compaction trigger fires at 60%.',
      // Filter dropdown groups
      story_kind: 'Story kind', priority: 'Priority', task_tag: 'Task tag',
      kind_user_story: 'User Story', kind_phase: 'Phase',
      kind_workflow: 'Workflow', kind_foundation: 'Foundation',
      // Kanban
      no_tasks_yet: 'No tasks tracked yet. Open /fact-start to begin.',
      // Tag glossary fallbacks
      tg_parallel: 'Parallel', tg_parallel_help: 'Can run in parallel with other [P] tasks (Spec Kit convention).',
      tg_review: 'Needs review', tg_review_help: 'Marked for human review before continuing.',
      tg_blocked: 'Blocked', tg_blocked_help: 'Blocked by an external dependency or unresolved question.',
      tg_todo: 'TODO', tg_todo_help: 'Placeholder — needs further definition.',
      tg_us: 'User Story', tg_us_help: 'Implements User Story #N from spec.md.',
    },
    es: {
      tasks: 'Tareas', cost: 'Costo', saved_vs_opus: 'Ahorro vs Opus',
      tokens_cumulative: 'Tokens (acumulado)', context_now: 'Contexto actual',
      files: 'Archivos', by_model: 'Por modelo',
      kanban_label: 'Kanban —', all_features: 'Todas las features', all_filters: 'Todos los filtros',
      hide_workflow: 'Ocultar workflow', tags_btn: '¿tags?',
      pending: 'Pendientes', in_progress: 'En progreso', done: 'Hechas',
      connecting: 'conectando…', reconnecting: 'reconectando…', live: 'en vivo',
      no_active_feature: 'sin feature activa', no_feature_yet: 'sin features todavía',
      updated: 'actualizado', stories: 'stories', of: 'de',
      search_placeholder: 'Buscar story o task…',
      tip_tokens_cumulative: 'Tokens acumulados — esto es lo que realmente pagaste. Nunca bajan.',
      tip_input: 'Input — tokens nuevos que enviaste al modelo. Pocos en sesiones largas.',
      tip_output: 'Output — lo que el agente generó. Refleja trabajo real.',
      tip_cache: 'Cache reads — re-lectura de la conversación desde el cache de Anthropic (barato, ~1/10 de input). Domina las sesiones largas.',
      tip_ctx_now: 'Tamaño del cache de conversación AHORA (cache_read del último turn). Baja después de /compact.',
      tip_feature_picker: 'Cambiar entre features',
      tip_filter_tag: 'Filtrar por tipo, prioridad o tag',
      tip_hide_workflow: 'Ocultar stories de foundation / workflow',
      tip_legend: 'Leyenda de tags',
      tip_lang: 'Toggle language / Cambiar idioma',
      ctx_latest_turn: 'Cache_read del último turn', ctx_model: 'Modelo', ctx_window: 'ventana',
      ctx_usage: 'Uso', ctx_of_window: 'de la ventana de contexto',
      ctx_last_compaction: 'Última compactación', ctx_ago: 'atrás',
      ctx_legend: 'Verde <30% · Amarillo 30-50% · Rojo ≥50%.',
      ctx_safety_note: 'Trigger de compactación dispara a 60%.',
      story_kind: 'Tipo de story', priority: 'Prioridad', task_tag: 'Tag de task',
      kind_user_story: 'User Story', kind_phase: 'Phase',
      kind_workflow: 'Workflow', kind_foundation: 'Foundation',
      no_tasks_yet: 'No hay tareas todavía. Corré /fact-start para empezar.',
      tg_parallel: 'Paralelizable', tg_parallel_help: 'Puede correr en paralelo con otras [P] (convención Spec Kit).',
      tg_review: 'Requiere revisión', tg_review_help: 'Marcado para revisión humana antes de continuar.',
      tg_blocked: 'Bloqueado', tg_blocked_help: 'Bloqueado por dependencia externa o decisión pendiente.',
      tg_todo: 'TODO', tg_todo_help: 'Placeholder — necesita más definición.',
      tg_us: 'User Story', tg_us_help: 'Implementa el User Story #N de spec.md.',
    },
  };
  let LANG = localStorage.getItem('fact-lang') || 'en';
  if (!STRINGS[LANG]) LANG = 'en';
  const t = (key) => (STRINGS[LANG] && STRINGS[LANG][key]) || STRINGS.en[key] || key;

  function applyStaticI18n() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const k = el.getAttribute('data-i18n');
      el.textContent = t(k);
    });
    // Placeholder + tooltip attributes that aren't simple textContent.
    const search = document.getElementById('search');
    if (search) search.placeholder = t('search_placeholder');
    const fp = document.getElementById('feature-picker');
    if (fp) fp.title = t('tip_feature_picker');
    const ft = document.getElementById('filter-tag');
    if (ft) ft.title = t('tip_filter_tag');
    const tg = document.querySelector('.kanban-toolbar .toggle');
    if (tg) tg.title = t('tip_hide_workflow');
    const lb = document.getElementById('legend-btn');
    if (lb) lb.title = t('tip_legend');
    const lt = document.getElementById('lang-toggle');
    if (lt) { lt.textContent = LANG.toUpperCase(); lt.title = t('tip_lang'); }
    const tg2 = document.getElementById('tokens-group');
    if (tg2) tg2.title = t('tip_tokens_cumulative');
    document.getElementById('tk-input').title = t('tip_input');
    document.getElementById('tk-output').title = t('tip_output');
    document.getElementById('tk-cache').title = t('tip_cache');
    // ws status: only swap if not currently "live"
    const ws = document.getElementById('ws-status');
    if (ws) {
      if (ws.classList.contains('ws-connected')) ws.textContent = t('live');
      else if (ws.textContent.match(/conn|conec/i)) {
        ws.textContent = ws.classList.contains('ws-disconnected') && state ? t('reconnecting') : t('connecting');
      }
    }
  }
  applyStaticI18n();

  function tagInfo(tag) {
    const map = {
      P:       { label: t('tg_parallel'), help: t('tg_parallel_help') },
      REVIEW:  { label: t('tg_review'),   help: t('tg_review_help') },
      BLOCKED: { label: t('tg_blocked'),  help: t('tg_blocked_help') },
      TODO:    { label: t('tg_todo'),     help: t('tg_todo_help') },
    };
    if (map[tag]) return map[tag];
    const m = tag.match(/^US(\d+)$/);
    if (m) return {
      label: `${t('tg_us')} ${m[1]}`,
      help: t('tg_us_help').replace('#N', `#${m[1]}`),
    };
    return { label: tag, help: '' };
  }

  // ---- WebSocket ---------------------------------------------------------
  function connect() {
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    ws = new WebSocket(`${proto}//${location.host}/ws`);
    ws.onopen = () => setWsStatus(true);
    ws.onclose = () => {
      setWsStatus(false);
      reconnectTimer && clearTimeout(reconnectTimer);
      reconnectTimer = setTimeout(connect, 1500);
    };
    ws.onerror = () => ws.close();
    ws.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        if (msg.kind === 'snapshot') {
          state = msg.data;
          render();
          touchLastEvent();
        }
      } catch (err) {
        console.error('ws parse', err);
      }
    };
  }

  function setWsStatus(connected) {
    const el = document.getElementById('ws-status');
    el.textContent = connected ? t('live') : t('reconnecting');
    el.className = connected ? 'ws-connected' : 'ws-disconnected';
  }
  function touchLastEvent() {
    document.getElementById('last-event').textContent = `${t('updated')} ${new Date().toLocaleTimeString()}`;
  }

  // ---- Render -------------------------------------------------------------
  function render() {
    if (!state) return;
    const p = state.project || {};
    document.getElementById('proj-name').textContent = p.name || '—';
    document.getElementById('phase-pill').textContent = p.phase || '—';

    refreshFeaturePicker(p);

    // Resolve which stories to render based on the picker selection.
    const stories = pickKanbanStories(p);

    // Header counter sums every task across every story so it always
    // matches what the user sees on the kanban. The breakdown — phase work
    // vs actual T-NNN implementation tasks — is in the tooltip.
    const allDone = stories.reduce((acc, s) => acc + s.done_count, 0);
    const allTotal = stories.reduce((acc, s) => acc + s.total_count, 0);
    const realStories = stories.filter(s => s.kind !== 'foundation' && s.kind !== 'workflow');
    const realDone = realStories.reduce((acc, s) => acc + s.done_count, 0);
    const realTotal = realStories.reduce((acc, s) => acc + s.total_count, 0);
    const phaseDone = allDone - realDone;
    const phaseTotal = allTotal - realTotal;

    const tasksEl = document.getElementById('tasks-progress');
    tasksEl.textContent = allTotal > 0 ? `${allDone}/${allTotal}` : '—';
    tasksEl.title = allTotal === 0
        ? 'No tasks tracked yet. Open /fact-start to begin.'
        : realTotal > 0
            ? `${allDone}/${allTotal} total\n` +
              `  · ${realDone}/${realTotal} implementation (T-NNN tasks)\n` +
              `  · ${phaseDone}/${phaseTotal} phase (foundation + workflow)`
            : `${allDone}/${allTotal} phase tasks done (foundation + workflow).\n` +
              `Run /speckit.tasks to generate implementation tasks (T-NNN); they'll show separately here.`;

    const m = state.metrics || {};
    document.getElementById('cost-total').textContent = formatUsd(m.cost_usd || 0, !m.cost_complete);
    document.getElementById('cost-savings').textContent = formatUsd(m.savings_vs_opus || 0);

    // Cumulative breakdown (these never decrease — it's what was paid).
    document.getElementById('tk-input').textContent = formatTokens(m.total_input || 0);
    document.getElementById('tk-output').textContent = formatTokens(m.total_output || 0);
    document.getElementById('tk-cache').textContent = formatTokens(m.total_cache_read || 0);

    // Context now — size of the cache for the LATEST turn. Drops after /compact.
    // Color thresholds use the % of the model's context window, not absolute
    // tokens — 97K is 9.7% on Opus 4.7 (1M) but 48% on Sonnet (200K).
    const ctxEl = document.getElementById('ctx-now');
    const ctxWrap = document.getElementById('ctx-metric');
    const ctxNow = m.current_context_size || 0;
    const ctxWindow = m.current_context_window || 200_000;
    const ctxModel = m.current_context_model || 'unknown';
    const ctxPct = m.current_context_pct || 0;

    ctxEl.textContent = ctxNow > 0 ? `${formatTokens(ctxNow)} (${Math.round(ctxPct * 100)}%)` : '—';
    ctxWrap.classList.remove('ctx-small', 'ctx-medium', 'ctx-large');
    if (ctxNow > 0) {
      // Aligned with the safety-net trigger: fires at 60%, so we paint red
      // a bit before. <30% = green, 30-50% = yellow, ≥50% = red.
      if (ctxPct < 0.30) ctxWrap.classList.add('ctx-small');
      else if (ctxPct < 0.50) ctxWrap.classList.add('ctx-medium');
      else ctxWrap.classList.add('ctx-large');
    }
    const lastTs = m.last_compaction_at;
    const compactNote = lastTs ? `Last compaction: ${timeAgo(lastTs)} ago.\n` : '';
    ctxWrap.title =
      `Latest turn cache_read: ${ctxNow.toLocaleString()} tokens\n` +
      `Model: ${ctxModel}, window: ${ctxWindow.toLocaleString()}\n` +
      `Usage: ${Math.round(ctxPct * 100)}% of context window\n` +
      compactNote +
      `\nGreen <30% · Yellow 30-50% · Red ≥50%.\n` +
      `Safety-net compaction trigger fires at 60%.`;

    refreshFilterOptions(stories);
    renderKanban(stories);
    renderTree(state.tree);
    renderByModel(m.by_model || {});
  }
  // Audits intentionally don't render in the dashboard — they're handled in
  // the conversation between the agent and the user (per fact-audit skill).
  // The audit reports still get written to .specify/fact/audits/*.md for
  // record-keeping; the file tree in the sidebar surfaces them.

  function refreshFeaturePicker(p) {
    const picker = document.getElementById('feature-picker');
    const fallback = document.getElementById('active-feature-fallback');
    const features = p.all_features || [];

    if (features.length === 0) {
      picker.style.display = 'none';
      fallback.textContent = t('no_feature_yet');
      return;
    }
    picker.style.display = '';
    fallback.textContent = '';

    const current = picker.value;
    picker.innerHTML = '';
    for (const f of features) {
      const o = document.createElement('option');
      o.value = f.slug;
      o.textContent = `${f.slug}  (${f.done}/${f.total})`;
      picker.appendChild(o);
    }
    if (features.length > 1) {
      const all = document.createElement('option');
      all.value = '__ALL__';
      const totDone = features.reduce((s, f) => s + f.done, 0);
      const totAll = features.reduce((s, f) => s + f.total, 0);
      all.textContent = `${t('all_features')} (${totDone}/${totAll})`;
      picker.appendChild(all);
    }
    let target = selectedFeature || current;
    if (!target) target = features.length > 1 ? '__ALL__' : features[0].slug;
    if (target === '__ALL__' && features.length <= 1) target = features[0].slug;
    if (!(features.some(f => f.slug === target) || target === '__ALL__')) {
      target = features.length > 1 ? '__ALL__' : features[0].slug;
    }
    picker.value = target;
    selectedFeature = target;
  }

  function pickKanbanStories(p) {
    const all = p.kanban_stories || [];
    if (!selectedFeature || selectedFeature === '__ALL__') return all;
    // Show project-level (foundation) + the picked feature's stories.
    return all.filter(s => s.feature_slug === null || s.feature_slug === selectedFeature);
  }

  function refreshFilterOptions(stories) {
    const sel = document.getElementById('filter-tag');
    const kinds = new Set();
    const priorities = new Set();
    const tags = new Set();
    for (const s of stories) {
      if (s.kind) kinds.add(s.kind);
      if (s.priority) priorities.add(s.priority);
      for (const t of (s.tasks || [])) {
        for (const tg of (t.tags || [])) tags.add(tg);
      }
    }

    const current = sel.value;
    sel.innerHTML = `<option value="">${t('all_filters')}</option>`;

    const KIND_LABELS = {
      user_story: t('kind_user_story'),
      phase: t('kind_phase'),
      workflow: t('kind_workflow'),
      foundation: t('kind_foundation'),
    };
    const KIND_ORDER = ['user_story', 'phase', 'workflow', 'foundation'];

    if (kinds.size) {
      const g = document.createElement('optgroup');
      g.label = t('story_kind');
      for (const k of KIND_ORDER) {
        if (!kinds.has(k)) continue;
        const o = document.createElement('option');
        o.value = `kind:${k}`;
        o.textContent = KIND_LABELS[k];
        g.appendChild(o);
      }
      sel.appendChild(g);
    }

    if (priorities.size) {
      const g = document.createElement('optgroup');
      g.label = t('priority');
      for (const p of [...priorities].sort()) {
        const o = document.createElement('option');
        o.value = `prio:${p}`;
        o.textContent = p;
        g.appendChild(o);
      }
      sel.appendChild(g);
    }

    if (tags.size) {
      const g = document.createElement('optgroup');
      g.label = t('task_tag');
      for (const tg of [...tags].sort()) {
        const o = document.createElement('option');
        o.value = `tag:${tg}`;
        const info = tagInfo(tg);
        o.textContent = info.label && info.label !== tg ? `${tg} — ${info.label}` : tg;
        g.appendChild(o);
      }
      sel.appendChild(g);
    }

    if (current) sel.value = current;
  }

  function syncSelectOptions(select, values, allLabel) {
    const current = select.value;
    select.innerHTML = `<option value="">${allLabel}</option>`;
    for (const v of values) {
      const o = document.createElement('option');
      o.value = v; o.textContent = v;
      select.appendChild(o);
    }
    if (values.includes(current)) select.value = current;
  }

  function passFilters(story) {
    if (filters.hidePhase && (story.kind === 'foundation' || story.kind === 'workflow')) return false;
    if (filters.tag) {
      const v = filters.tag;
      if (v.startsWith('kind:')) {
        if (story.kind !== v.slice(5)) return false;
      } else if (v.startsWith('prio:')) {
        if (story.priority !== v.slice(5)) return false;
      } else if (v.startsWith('tag:')) {
        const want = v.slice(4);
        if (!(story.tasks || []).some(t => (t.tags || []).includes(want))) return false;
      } else {
        // Legacy: bare tag value (back-compat).
        if (!(story.tasks || []).some(t => (t.tags || []).includes(v))) return false;
      }
    }
    if (filters.search) {
      const q = filters.search.toLowerCase();
      const titleMatch = (story.title || '').toLowerCase().includes(q);
      const taskMatch = (story.tasks || []).some(t => {
        const hay = [
          t.id, t.title, t.section,
          ...(t.files || []),
          ...(t.tags || []),
          ...(t.deps || []),
        ].filter(Boolean).join(' ').toLowerCase();
        return hay.includes(q);
      });
      if (!titleMatch && !taskMatch) return false;
    }
    return true;
  }

  function renderKanban(allStories) {
    const stories = allStories.filter(passFilters);
    document.getElementById('filter-count').textContent =
      stories.length === allStories.length
        ? `${stories.length} ${t('stories')}`
        : `${stories.length} ${t('of')} ${allStories.length}`;
    return _renderColumns(stories);
  }

  function _renderColumns(stories) {
    const pending = document.getElementById('col-pending');
    const progress = document.getElementById('col-progress');
    const done = document.getElementById('col-done');
    pending.innerHTML = progress.innerHTML = done.innerHTML = '';
    let cP = 0, cI = 0, cD = 0;
    for (const s of stories) {
      const card = buildStoryCard(s);
      if (s.status === 'done') { done.appendChild(card); cD++; }
      else if (s.status === 'in_progress') { progress.appendChild(card); cI++; }
      else { pending.appendChild(card); cP++; }
    }
    document.getElementById('count-pending').textContent = cP;
    document.getElementById('count-progress').textContent = cI;
    document.getElementById('count-done').textContent = cD;
  }

  function buildStoryCard(s) {
    const card = document.createElement('div');
    const status = s.status === 'in_progress' ? 'in-progress' : s.status;
    card.className = `card story-card ${status} kind-${s.kind}`;
    if (s.kind === 'foundation' || s.kind === 'workflow') card.classList.add('phase');

    const featureBadge = s.feature_slug
      ? `<span class="feature-badge" title="Feature: ${escape(s.feature_slug)}">${escape(shortFeatureSlug(s.feature_slug))}</span>`
      : `<span class="feature-badge feature-project" title="Project-level">project</span>`;

    const kindBadge = (() => {
      if (s.kind === 'workflow')   return `<span class="kind-badge kind-workflow" title="Pre-implement workflow tasks">workflow</span>`;
      if (s.kind === 'foundation') return `<span class="kind-badge kind-foundation" title="Project foundation">foundation</span>`;
      if (s.kind === 'user_story') return `<span class="kind-badge kind-us" title="User Story ${s.user_story_number}">US ${s.user_story_number}</span>`;
      if (s.kind === 'phase')      return `<span class="kind-badge kind-phase" title="Spec Kit phase — infrastructure / cross-cutting work, not tied to a single user story">phase</span>`;
      return '';
    })();

    const priorityBadge = s.priority
      ? `<span class="priority-badge priority-${s.priority.toLowerCase()}" title="Priority ${s.priority}">${escape(s.priority)}</span>`
      : '';

    const pendingN = Math.max(0, s.total_count - s.done_count - s.in_progress_count);
    const counter = `<span class="story-counter" title="${s.done_count} done · ${s.in_progress_count} in progress · ${pendingN} pending">${s.done_count}/${s.total_count}</span>`;
    const dot = status === 'in-progress' ? '<span class="working-dot" title="agent working in this story"></span>' : '';

    // Counts row — replaces the per-task list. Click the card to see details.
    const countsRow = `
      <div class="story-counts" title="Click for details">
        <span class="count-pill done"><span class="count-dot">✓</span><span class="count-num">${s.done_count}</span> done</span>
        <span class="count-pill in-progress"><span class="count-dot">●</span><span class="count-num">${s.in_progress_count}</span> in progress</span>
        <span class="count-pill pending"><span class="count-dot">○</span><span class="count-num">${pendingN}</span> pending</span>
      </div>`;

    // Mini progress bar (visual, only when there's >1 task in the story).
    const progressBar = s.total_count > 1 ? `
      <div class="story-progress" aria-hidden="true">
        <div class="bar-segment done" style="flex:${s.done_count}"></div>
        <div class="bar-segment in-progress" style="flex:${s.in_progress_count}"></div>
        <div class="bar-segment pending" style="flex:${pendingN}"></div>
      </div>` : '';

    card.innerHTML = `
      <div class="card-header story-header">
        <div class="card-header-left">${featureBadge}${kindBadge}${priorityBadge}${dot}</div>
        ${counter}
      </div>
      <div class="story-title">${escape(s.title)}</div>
      ${progressBar}
      ${countsRow}
    `;

    // Whole card clickable → opens story detail with full task list.
    card.tabIndex = 0;
    card.addEventListener('click', () => openStoryDetail(s));
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openStoryDetail(s); }
    });
    return card;
  }

  function openStoryDetail(s) {
    const status = s.status === 'in_progress' ? 'In Progress' : (s.status === 'done' ? 'Done' : 'Pending');
    const featureBadge = s.feature_slug
      ? `<span class="feature-badge">${escape(shortFeatureSlug(s.feature_slug))}</span>  <span class="dim">${escape(s.feature_slug)}</span>`
      : '<span class="feature-badge feature-project">project</span>';
    const tasksBlocks = (s.tasks || []).map(t => {
      const sym = t.done ? '✓' : (t.in_progress ? '●' : '○');
      const klass = t.done ? 'done' : (t.in_progress ? 'in-progress' : 'pending');
      const tags = (t.tags || []).map(tg => `<span class="chip chip-tag chip-mini" title="${escape(tagInfo(tg).help)}">${escape(tg)}</span>`).join(' ');
      const files = (t.files || []).slice(0, 6).map(f => `<a class="chip chip-file chip-mini" href="#" data-path="${escape(f)}">${escape(f.split('/').slice(-2).join('/'))}</a>`).join(' ');
      const deps = (t.deps || []).map(d => `<a class="chip chip-dep chip-mini" href="#" data-dep="${escape(d)}">↳ ${escape(d)}</a>`).join(' ');
      const idLabel = t.id.startsWith('Φ-')
        ? `<span class="phase-badge phase-badge-mini">phase</span>`
        : `<span class="task-id">${escape(t.id)}</span>`;
      const title = t.id.startsWith('Φ-') ? `<strong>${escape(t.title)}</strong>` : escape(truncate(t.title, 200));
      return `<div class="story-task-block ${klass}">
        <div class="story-task-head">
          <span class="task-row-status">${sym}</span>
          ${idLabel}
          <span class="story-task-title">${title}</span>
        </div>
        ${(tags || files || deps) ? `<div class="story-task-chips">${tags} ${files} ${deps}</div>` : ''}
      </div>`;
    }).join('');

    document.getElementById('modal-path').textContent = s.title;
    document.getElementById('modal-body').innerHTML = `
      <div class="detail-id">${featureBadge} <span class="status-pill status-${status.toLowerCase().replace(' ','-')}">${status}</span> <span class="dim mono">${s.done_count}/${s.total_count} tasks</span></div>
      <h3 class="detail-title">${escape(s.title)}</h3>
      <div class="story-tasks">${tasksBlocks}</div>
    `;
    document.querySelectorAll('#modal-body .chip-file').forEach(a => {
      a.addEventListener('click', (e) => { e.preventDefault(); openFile(a.dataset.path); });
    });
    document.querySelectorAll('#modal-body .chip-dep').forEach(a => {
      a.addEventListener('click', (e) => {
        e.preventDefault();
        const tid = a.dataset.dep;
        const target = (state && state.project.kanban_tasks || []).find(x => x.id === tid);
        if (target) openTaskDetail(target);
      });
    });
    document.querySelectorAll('#modal-body .story-task-block').forEach(b => {
      b.addEventListener('click', () => {
        const id = b.querySelector('.task-id, .phase-badge')?.textContent;
        if (!id) return;
        const target = (s.tasks || []).find(x => x.id === id || x.title === id);
        if (target) openTaskDetail(target);
      });
    });
    document.getElementById('modal').classList.remove('hidden');
  }

  function buildCard(t, status) {
    const card = document.createElement('div');
    card.className = `card ${status === 'in-progress' ? 'in-progress' : status}`;
    if (t.synthetic) card.classList.add('phase');
    card.tabIndex = 0;

    // Header — id + tag chips + working dot
    const headerLeft = t.synthetic
      ? `<span class="phase-badge" title="Workflow phase task — auto-tracked from .md file state">phase</span><span class="phase-name">${escape(t.title)}</span>`
      : `<span class="task-id">${escape(t.id)}</span>${t.position ? `<span class="task-pos">${t.position}</span>` : ''}`;
    const tagChips = (t.tags || []).map(tag => {
      const info = tagInfo(tag);
      const titleAttr = info.help ? `${info.label} — ${info.help}` : info.label;
      return `<span class="chip chip-tag" title="${escape(titleAttr)}">${escape(tag)}</span>`;
    }).join('');
    const subagentChip = t.subagent
      ? `<span class="chip chip-subagent" title="Running in a sub-agent${t.subagent.model ? ' — model: ' + t.subagent.model : ''}${t.subagent.id ? ' — id: ' + t.subagent.id : ''}">⤵ subagent${t.subagent.model ? ' · ' + shortModel(t.subagent.model) : ''}</span>`
      : '';
    const workingDot = status === 'in-progress'
      ? `<span class="working-dot${t.subagent ? ' subagent' : ''}" title="${t.subagent ? 'sub-agent working' : 'agent working now'}"></span>`
      : '';

    // Feature badge — always shown when the task belongs to a feature, so the
    // user can identify which feature each card is from regardless of picker.
    const featureBadge = t.feature_slug
      ? `<span class="feature-badge" title="Feature: ${escape(t.feature_slug)}">${escape(shortFeatureSlug(t.feature_slug))}</span>`
      : '';
    const sectionText = (!t.synthetic && t.section)
      ? `<span class="section-text">${escape(t.section)}</span>`
      : '';
    const sectionHtml = (featureBadge || sectionText)
      ? `<div class="card-section">${featureBadge}${sectionText}</div>`
      : '';

    // Title (real tasks only)
    const titleHtml = (!t.synthetic && t.title)
      ? `<div class="card-title">${escape(truncate(t.title, 180))}</div>`
      : '';

    // Files chips (max 4 in card; full list shows in detail modal)
    const visibleFiles = (t.files || []).slice(0, 4);
    const moreFiles = (t.files || []).length - visibleFiles.length;
    const fileChips = visibleFiles.map(f => {
      const short = f.split('/').slice(-2).join('/');
      return `<a class="chip chip-file" href="#" data-path="${escape(f)}" title="${escape(f)}">${escape(short)}</a>`;
    }).join('') + (moreFiles > 0 ? `<span class="chip chip-more" title="${moreFiles} more file(s) — click card to expand">+${moreFiles}</span>` : '');

    // Dependency chips
    const depChips = (t.deps || []).map(d =>
      `<span class="chip chip-dep" data-dep="${escape(d)}" title="Depends on ${escape(d)} — click to jump">↳ ${escape(d)}</span>`
    ).join('');

    const footer = renderFooter(t, status);

    card.innerHTML = `
      <div class="card-header">
        <div class="card-header-left">${headerLeft}${workingDot}</div>
        <div class="card-tags">${subagentChip}${tagChips}</div>
      </div>
      ${sectionHtml}
      ${titleHtml}
      ${(fileChips || depChips) ? `<div class="card-chips">${fileChips}${depChips}</div>` : ''}
      ${footer ? `<div class="card-footer">${footer}</div>` : ''}
    `;

    // Click on a file chip → open the file (don't bubble to card click)
    card.querySelectorAll('.chip-file').forEach(a => {
      a.addEventListener('click', (e) => { e.stopPropagation(); e.preventDefault(); openFile(a.dataset.path); });
    });
    // Click on a dep chip → open that task's detail modal
    card.querySelectorAll('.chip-dep').forEach(c => {
      c.addEventListener('click', (e) => {
        e.stopPropagation();
        const tid = c.dataset.dep;
        const target = (state && state.project.kanban_tasks || []).find(x => x.id === tid);
        if (target) openTaskDetail(target);
      });
    });
    // Click on the rest of the card → detail modal
    card.addEventListener('click', () => openTaskDetail(t));
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openTaskDetail(t); }
    });

    if (t.active_task_started_at) card.dataset.startedAt = t.active_task_started_at;
    if (t.file_mtime) card.dataset.mtime = t.file_mtime;

    return card;
  }

  function truncate(s, n) {
    if (!s) return '';
    return s.length > n ? s.slice(0, n - 1) + '…' : s;
  }

  function renderFooter(t, status) {
    const parts = [];
    if (status === 'in-progress') {
      const started = t.active_task_started_at || t.file_mtime;
      if (started) parts.push(`<span class="footer-time" data-since="${escape(started)}">started ${timeAgo(started)}</span>`);
      else parts.push('<span class="footer-time">working now</span>');
    } else if (status === 'done' && t.file_mtime) {
      parts.push(`<span class="footer-time" data-since="${escape(t.file_mtime)}">updated ${timeAgo(t.file_mtime)}</span>`);
    } else if (status === 'pending' && (t.deps || []).length === 0 && !t.file_path) {
      // nothing — keep card compact
    } else if (status === 'pending' && t.file_path && !t.file_size) {
      parts.push('<span class="footer-time dim">file not created yet</span>');
    }
    if (t.file_size != null) {
      parts.push(`<span class="footer-size">${formatBytes(t.file_size)}</span>`);
    }
    return parts.join(' · ');
  }

  // Tick relative timestamps every 20s without rebuilding cards.
  setInterval(() => {
    document.querySelectorAll('.footer-time[data-since]').forEach(el => {
      const since = el.dataset.since;
      const verb = el.textContent.startsWith('updated') ? 'updated' : 'started';
      el.textContent = `${verb} ${timeAgo(since)}`;
    });
  }, 20000);

  function timeAgo(iso) {
    if (!iso) return '';
    const t = new Date(iso).getTime();
    if (isNaN(t)) return '';
    const s = Math.max(0, Math.floor((Date.now() - t) / 1000));
    if (s < 60) return `${s}s ago`;
    if (s < 3600) return `${Math.floor(s/60)}m ago`;
    if (s < 86400) return `${Math.floor(s/3600)}h ago`;
    return `${Math.floor(s/86400)}d ago`;
  }

  function formatBytes(n) {
    if (n < 1024) return `${n} B`;
    if (n < 1024 * 1024) return `${(n/1024).toFixed(1)} KB`;
    return `${(n/1024/1024).toFixed(2)} MB`;
  }

  // Persist which folders the user has expanded across re-renders.
  const expandedDirs = new Set(['.', '.specify', '.specify/specs', '.specify/fact', '.specify/fact/sessions', '.specify/memory']);

  function renderTree(tree) {
    const root = document.getElementById('tree');
    root.innerHTML = '';
    if (!tree || !tree.children || !tree.children.length) {
      const empty = document.createElement('div');
      empty.className = 'missing';
      empty.textContent = '(no .md files yet)';
      root.appendChild(empty);
      return;
    }
    // Render the root's children directly (skip the "." label).
    const ul = document.createElement('ul');
    ul.className = 'tree';
    for (const child of tree.children) {
      ul.appendChild(treeNode(child));
    }
    root.appendChild(ul);
  }

  function treeNode(node) {
    const li = document.createElement('li');
    if (node.type === 'dir') {
      const open = expandedDirs.has(node.path);
      const details = document.createElement('details');
      details.open = open;
      details.addEventListener('toggle', () => {
        if (details.open) expandedDirs.add(node.path);
        else expandedDirs.delete(node.path);
      });
      const summary = document.createElement('summary');
      summary.className = 'dir';
      summary.innerHTML = `<span class="caret"></span><span class="name">${escape(node.name)}/</span>`;
      details.appendChild(summary);
      const ul = document.createElement('ul');
      for (const child of node.children) ul.appendChild(treeNode(child));
      details.appendChild(ul);
      li.appendChild(details);
    } else {
      const a = document.createElement('a');
      a.className = 'file';
      a.textContent = node.name;
      a.title = node.path;
      a.href = '#';
      a.addEventListener('click', (e) => { e.preventDefault(); openFile(node.path); });
      li.appendChild(a);
    }
    return li;
  }

  function renderByModel(byModel) {
    const ul = document.getElementById('by-model');
    ul.innerHTML = '';
    const entries = Object.entries(byModel).sort((a, b) => (b[1].cost_usd || 0) - (a[1].cost_usd || 0));
    if (!entries.length) {
      const li = document.createElement('li');
      li.className = 'k';
      li.textContent = 'waiting for events…';
      ul.appendChild(li);
      return;
    }
    for (const [model, b] of entries) {
      const inp = b.input || 0;
      const out = b.output || 0;
      const cache = b.cache_read || 0;
      const total = inp + out + cache;
      // Tooltip with the breakdown so the number on the line and the header always match.
      const tip = `input ${inp.toLocaleString()}  ·  output ${out.toLocaleString()}  ·  cache ${cache.toLocaleString()}`;
      const li = document.createElement('li');
      li.title = tip;
      li.innerHTML = `<span class="k">${escape(short(model))}</span><span class="v">${formatUsd(b.cost_usd)} · ${formatTokens(total)}</span>`;
      ul.appendChild(li);
    }
  }

  // ---- Task detail modal -------------------------------------------------
  function openTaskDetail(t) {
    const status = t.done ? 'Done' : (t.in_progress ? 'In Progress' : 'Pending');
    const tagsBlock = (t.tags || []).map(tag => {
      const info = tagInfo(tag);
      return `<span class="chip chip-tag" title="${escape(info.help)}">${escape(tag)}</span> <span class="dim">${escape(info.label)}</span>`;
    }).join('<br/>');

    const filesBlock = (t.files || []).map(f =>
      `<a class="chip chip-file" href="#" data-path="${escape(f)}" title="${escape(f)}">${escape(f)}</a>`
    ).join(' ');

    const depsBlock = (t.deps || []).map(d =>
      `<a class="chip chip-dep" href="#" data-dep="${escape(d)}">↳ ${escape(d)}</a>`
    ).join(' ');

    const fileMeta = t.file_path
      ? `<dt>File</dt><dd><a class="chip chip-file" href="#" data-path="${escape(t.file_path)}">${escape(t.file_path)}</a> ${t.file_size != null ? `<span class="dim">${formatBytes(t.file_size)}</span>` : ''}</dd>`
      : '';

    const positionBlock = (!t.synthetic && t.position)
      ? `<dt>Position</dt><dd>${t.position} of ${(state.project.kanban_tasks || []).filter(x => !x.synthetic).length}</dd>`
      : '';

    const sectionBlock = t.section
      ? `<dt>Section</dt><dd>${escape(t.section)}</dd>`
      : '';

    const startedBlock = t.active_task_started_at
      ? `<dt>Started</dt><dd>${escape(t.active_task_started_at)} <span class="dim">(${timeAgo(t.active_task_started_at)})</span></dd>`
      : '';

    const subagentBlock = t.subagent
      ? `<dt>Running in</dt><dd><span class="chip chip-subagent">⤵ subagent</span>${t.subagent.model ? ` <span class="dim">${escape(shortModel(t.subagent.model))}</span>` : ''}${t.subagent.id ? ` <span class="dim mono">${escape(t.subagent.id)}</span>` : ''}</dd>`
      : '';

    const updatedBlock = t.file_mtime
      ? `<dt>Last update</dt><dd>${escape(t.file_mtime)} <span class="dim">(${timeAgo(t.file_mtime)})</span></dd>`
      : '';

    const idLine = t.synthetic
      ? `<span class="phase-badge">phase</span> <span class="phase-name">${escape(t.title)}</span>`
      : `<span class="task-id">${escape(t.id)}</span>`;

    const titleBlock = (!t.synthetic && t.title)
      ? `<h3 class="detail-title">${escape(t.title)}</h3>`
      : '';

    const rawBlock = t.raw_line
      ? `<details class="raw-block"><summary>raw line</summary><pre><code>${escape(t.raw_line)}</code></pre></details>`
      : '';

    document.getElementById('modal-path').textContent = t.id;
    document.getElementById('modal-body').innerHTML = `
      <div class="detail-id">${idLine} <span class="status-pill status-${status.toLowerCase().replace(' ','-')}">${status}</span></div>
      ${titleBlock}
      <dl class="detail-list">
        ${sectionBlock}
        ${positionBlock}
        ${(t.tags && t.tags.length) ? `<dt>Tags</dt><dd>${tagsBlock}</dd>` : ''}
        ${subagentBlock}
        ${(t.files && t.files.length) ? `<dt>Files referenced</dt><dd>${filesBlock}</dd>` : ''}
        ${(t.deps && t.deps.length) ? `<dt>Depends on</dt><dd>${depsBlock}</dd>` : ''}
        ${fileMeta}
        ${startedBlock}
        ${updatedBlock}
      </dl>
      ${rawBlock}
    `;
    // Wire chip clicks inside the modal too.
    document.querySelectorAll('#modal-body .chip-file').forEach(a => {
      a.addEventListener('click', (e) => { e.preventDefault(); openFile(a.dataset.path); });
    });
    document.querySelectorAll('#modal-body .chip-dep').forEach(a => {
      a.addEventListener('click', (e) => {
        e.preventDefault();
        const tid = a.dataset.dep;
        const target = (state && state.project.kanban_tasks || []).find(x => x.id === tid);
        if (target) openTaskDetail(target);
      });
    });
    document.getElementById('modal').classList.remove('hidden');
  }

  // ---- File modal --------------------------------------------------------
  document.getElementById('modal-close').addEventListener('click', closeModal);
  document.getElementById('modal').addEventListener('click', (e) => {
    if (e.target.id === 'modal') closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });

  async function openFile(path) {
    if (!path) return;
    const r = await fetch(`/api/file?p=${encodeURIComponent(path)}`);
    const body = document.getElementById('modal-body');
    document.getElementById('modal-path').textContent = path;
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      body.innerHTML = `<p class="dim">not found: ${escape(err.path || path)}</p>`;
    } else {
      const data = await r.json();
      body.innerHTML = data.html;
    }
    document.getElementById('modal').classList.remove('hidden');
  }
  function closeModal() {
    document.getElementById('modal').classList.add('hidden');
  }

  // ---- Helpers -----------------------------------------------------------
  function formatTokens(n) {
    if (n < 1000) return String(n);
    if (n < 1_000_000) return (n / 1000).toFixed(1) + 'K';
    return (n / 1_000_000).toFixed(2) + 'M';
  }
  function formatUsd(n, partial = false) {
    const s = '$' + (Number(n) || 0).toFixed(2);
    return partial ? s + '?' : s;
  }
  function short(model) {
    return (model || '').replace(/^claude-/, '');
  }
  function shortModel(model) {
    // Drop the "claude-" prefix and any -YYYYMMDD date suffix.
    return (model || '').replace(/^claude-/, '').replace(/-\d{8}$/, '');
  }
  function shortFeatureSlug(slug) {
    // "001-team-tasks-dashboard" → "001". Keeps cards compact; full slug is in the tooltip.
    if (!slug) return '';
    const m = slug.match(/^(\d{2,4})(?:-(.{1,8}))?/);
    if (m) return m[2] ? `${m[1]}·${m[2]}` : m[1];
    return slug.slice(0, 8);
  }
  function escape(s) {
    return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  }

  // ---- Filter wiring -----------------------------------------------------
  const reapply = () => {
    if (state) renderKanban(pickKanbanStories(state.project));
  };
  document.getElementById('search').addEventListener('input', (e) => {
    filters.search = e.target.value.trim();
    reapply();
  });
  document.getElementById('filter-tag').addEventListener('change', (e) => {
    filters.tag = e.target.value;
    reapply();
  });
  document.getElementById('hide-phase').addEventListener('change', (e) => {
    filters.hidePhase = e.target.checked;
    reapply();
  });
  document.getElementById('feature-picker').addEventListener('change', (e) => {
    selectedFeature = e.target.value;
    if (state) render();
  });

  // ---- Tag legend --------------------------------------------------------
  document.getElementById('legend-btn').addEventListener('click', () => {
    document.getElementById('modal-path').textContent = 'Tag legend';
    document.getElementById('modal-body').innerHTML = `
      <p class="dim">Tags come from <code>tasks.md</code> conventions used by Spec Kit and FACT.</p>
      <dl class="detail-list">
        <dt><span class="chip chip-tag">P</span></dt>
        <dd>Parallelizable — this task can run in parallel with other <code>[P]</code> tasks. The agent uses this hint to spawn sub-agents concurrently.</dd>
        <dt><span class="chip chip-tag">US1</span> · <span class="chip chip-tag">US2</span> · …</dt>
        <dd>User Story group — links the task to a numbered user story in <code>spec.md</code>. Filter by US to see all the work for one story.</dd>
        <dt><span class="chip chip-tag">REVIEW</span></dt>
        <dd>Needs human review before continuing.</dd>
        <dt><span class="chip chip-tag">BLOCKED</span></dt>
        <dd>Blocked by an external dependency or unresolved decision.</dd>
        <dt><span class="chip chip-tag">TODO</span></dt>
        <dd>Placeholder — needs further definition.</dd>
        <dt><span class="phase-badge">phase</span></dt>
        <dd>Synthetic card representing a workflow stage (Constitution / Research / Spec / Plan / Tasks). Tracked from the corresponding <code>.md</code> file's content and edit times.</dd>
      </dl>
    `;
    document.getElementById('modal').classList.remove('hidden');
  });

  // ---- Keyboard shortcut: "/" focuses search -----------------------------
  document.addEventListener('keydown', (e) => {
    if (e.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) {
      e.preventDefault();
      document.getElementById('search').focus();
    }
  });

  // ---- Language toggle ---------------------------------------------------
  document.getElementById('lang-toggle').addEventListener('click', () => {
    LANG = LANG === 'en' ? 'es' : 'en';
    localStorage.setItem('fact-lang', LANG);
    applyStaticI18n();
    if (state) render();
    closeModal();
  });

  // ---- Boot --------------------------------------------------------------
  fetch('/api/state').then((r) => r.json()).then((d) => { state = d; render(); });
  connect();
})();
