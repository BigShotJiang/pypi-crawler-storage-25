---
description: Start (or resume) a FACT workflow.
---

Load the `fact-rpi-harness` skill first (40% rule, sub-agents, intentional
compaction, session-summary format) — keep it active for the whole session.

Then load the `fact-onboarding` skill and follow its protocol:

1. If `.specify/fact/session_state.json` or files under
   `.specify/fact/sessions/` exist, this is a **resumed session** — apply the
   "resume protocol" (§3 of fact-onboarding). Do NOT greet with "hi, I'm
   FACT"; jump straight into presenting continuity.

2. If no prior state exists, this is a **fresh project** — ask greenfield /
   brownfield / demo and delegate to the matching skill.

If a workflow is already in progress (`.specify/specs/<feature>/` exists) and
the user invoked `/fact-start` anyway, suggest `/fact-next` as an alternative.
