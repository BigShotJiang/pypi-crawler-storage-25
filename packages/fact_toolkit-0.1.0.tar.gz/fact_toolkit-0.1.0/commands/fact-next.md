---
description: Continue the current FACT phase or advance to the next.
---

Load `fact-rpi-harness` if you haven't already in this session.

Identify the current phase from the state of files under `.specify/`:

- No `constitution.md` → phase **constitution** (`/speckit.constitution`).
- Constitution but no `spec.md` → phase **specify** (load `fact-discovery` or
  `fact-research` depending on workflow type).
- Spec but no `plan.md` → phase **plan** (`/speckit.plan`).
- Plan but no `tasks.md` → phase **tasks** (`/speckit.tasks`).
- `tasks.md` with pending tasks → phase **implement** (load `fact-implement`).
- All tasks done → ask whether to start another feature, refactor, or wrap up.

Before starting:
1. Read `.specify/fact/session_state.json` to know which task was active.
2. Read the latest file in `.specify/fact/sessions/` (semantic summary).
3. If the active task was abandoned mid-flight, apply fact-onboarding §3b
   ("abandoned task" case).

Be brief. The user wants to make progress, not read a status report.
