---
description: Run a security / architecture / quality audit on demand.
---

Load the `fact-audit` skill and run an audit.

The user may pass a dimension as argument:
- `/fact-audit security`
- `/fact-audit architecture`
- `/fact-audit quality`
- `/fact-audit` or `/fact-audit all` → run all three in parallel

Use sub-agents per fact-audit §3 (Sonnet for deep reviews, Haiku for
narrow per-task checks). Confirm any skill installation with the user
before downloading.

Write each audit report to `.specify/fact/audits/<UTC>-<dimension>.md`
with the YAML frontmatter described in fact-audit §4 so the dashboard
can render the severity badges.

After the run:
- If any critical finding → halt and present.
- Otherwise summarize counts in chat and tell the user where each
  full report lives.
