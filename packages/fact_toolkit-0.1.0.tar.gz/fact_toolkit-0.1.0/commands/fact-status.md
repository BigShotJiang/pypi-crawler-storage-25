---
description: Print a quick status report — phase, tasks, last activity, next step.
---

Print a project status summary in chat. Be concise (10 lines max).

Read only headers / metadata, not full files:

- Project type (greenfield / brownfield / demo) — infer from
  `.specify/specs/` structure or prior session summaries.
- Active feature (most recently modified subdir of `.specify/specs/`).
- Current phase (which files exist: constitution / spec / plan / tasks).
- Tasks: `<done>/<total>` parsed from `tasks.md`.
- Last activity: `updated_at` from `.specify/fact/session_state.json`, or the
  most recent file in `.specify/fact/sessions/`.
- Next recommended step in one line.

Suggested format:

```
Project:    <name>  •  <type>
Phase:      <phase>
Feature:    <slug>
Tasks:      <done>/<total>  ([x] T-007 last done)
Last act:   <iso>
Next:       <one line>
```

Do not open large files. If something can't be determined, show `?` — never
fabricate (P10).
