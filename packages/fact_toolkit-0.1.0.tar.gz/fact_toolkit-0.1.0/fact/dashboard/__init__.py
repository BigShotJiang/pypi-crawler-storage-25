"""FACT dashboard — local FastAPI server with WebSocket + file watcher."""
