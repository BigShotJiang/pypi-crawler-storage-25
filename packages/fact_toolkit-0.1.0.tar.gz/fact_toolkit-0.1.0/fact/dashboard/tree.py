"""Recursive .md-file tree of the project — what the dashboard sidebar shows."""

from __future__ import annotations

from pathlib import Path


IGNORED_DIRS = {
    ".git",
    ".venv",
    "venv",
    ".tox",
    "node_modules",
    "__pycache__",
    "dist",
    "build",
    ".pytest_cache",
    ".ruff_cache",
    ".mypy_cache",
    ".idea",
    ".vscode",
    ".next",
    ".turbo",
    ".cache",
    ".DS_Store",
}


def _is_ignored_dir(name: str) -> bool:
    return name in IGNORED_DIRS or name.endswith(".egg-info")


def build_tree(root: Path) -> dict:
    """Walk root, return only directories that contain .md files (recursively)."""

    def walk(d: Path, rel: str) -> dict | None:
        children: list[dict] = []
        try:
            entries = list(d.iterdir())
        except (PermissionError, OSError):
            return None
        # Sort: dirs first, then files, alphabetical case-insensitive.
        entries.sort(key=lambda p: (not p.is_dir(), p.name.lower()))
        for entry in entries:
            if entry.is_symlink():
                continue
            if entry.is_dir():
                if _is_ignored_dir(entry.name):
                    continue
                sub_rel = f"{rel}/{entry.name}" if rel else entry.name
                sub = walk(entry, sub_rel)
                if sub:
                    children.append(sub)
            elif entry.is_file() and entry.suffix.lower() in (".md", ".markdown"):
                file_rel = f"{rel}/{entry.name}" if rel else entry.name
                children.append({"type": "file", "name": entry.name, "path": file_rel})
        if not children:
            return None
        return {"type": "dir", "name": d.name if rel else ".", "path": rel or ".", "children": children}

    return walk(root, "") or {"type": "dir", "name": ".", "path": ".", "children": []}
