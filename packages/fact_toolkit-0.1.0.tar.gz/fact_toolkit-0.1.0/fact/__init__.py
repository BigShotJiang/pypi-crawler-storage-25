"""FACT — Focused Agentic Context Toolkit."""

__version__ = "0.1.0"
