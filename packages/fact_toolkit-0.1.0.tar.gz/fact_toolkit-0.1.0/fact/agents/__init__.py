"""Agent adapters — abstraction for talking to coding agents.

P9 (extensible barato): a single concrete adapter today (Claude Code), with a
narrow Protocol so a second one can be slotted in without refactoring callers.
No plugin registry, no dynamic loading. When a second adapter exists, import it
explicitly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol


@dataclass
class ParsedEvent:
    """Normalized event from any agent's hooks."""

    kind: str  # "pre_tool", "post_tool", "session_start", "session_end", "subagent_start", "subagent_end"
    timestamp: str
    model: str | None = None
    tool: str | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    files_modified: list[str] = field(default_factory=list)
    raw: dict = field(default_factory=dict)


class AgentAdapter(Protocol):
    """Minimal interface FACT expects from a coding agent."""

    name: str

    def detect(self) -> bool:
        """Return True if this agent is installed and usable on the current host."""
        ...

    def install_skills(self, source_dir: Path, target_dir: Path) -> list[str]: ...

    def install_commands(self, source_dir: Path, target_dir: Path) -> list[str]: ...

    def install_hooks(self, target_dir: Path, dashboard_url: str) -> None: ...

    def session_command(self) -> str:
        """Shell command the user runs to start a session, e.g. 'claude'."""
        ...

    def parse_event(self, raw_event: dict) -> ParsedEvent: ...


from fact.agents.claude_code import ClaudeCodeAdapter  # noqa: E402


def get_adapter(name: str = "claude-code") -> AgentAdapter:
    if name in ("claude-code", "claude"):
        return ClaudeCodeAdapter()
    raise ValueError(f"Unknown agent adapter: {name}")
