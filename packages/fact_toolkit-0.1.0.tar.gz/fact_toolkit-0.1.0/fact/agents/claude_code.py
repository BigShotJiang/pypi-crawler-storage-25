"""Claude Code adapter.

D1: hook names and payload formats can drift between Claude Code versions.
This module is the only place that knows about Claude Code specifics; the
rest of FACT consumes ParsedEvent.
"""

from __future__ import annotations

import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

from fact.agents import ParsedEvent


HOOK_EVENTS = (
    "PreToolUse",
    "PostToolUse",
    "SessionStart",
    "SessionEnd",
    "SubagentStart",
    "SubagentStop",
    "Stop",
)


class ClaudeCodeAdapter:
    name = "claude-code"

    def detect(self) -> bool:
        return shutil.which("claude") is not None

    def install_skills(self, source_dir: Path, target_dir: Path) -> list[str]:
        installed: list[str] = []
        target_dir.mkdir(parents=True, exist_ok=True)
        for skill_dir in sorted(p for p in source_dir.iterdir() if p.is_dir()):
            dest = target_dir / skill_dir.name
            if dest.exists():
                shutil.rmtree(dest)
            shutil.copytree(skill_dir, dest)
            installed.append(skill_dir.name)
        return installed

    def install_commands(self, source_dir: Path, target_dir: Path) -> list[str]:
        installed: list[str] = []
        target_dir.mkdir(parents=True, exist_ok=True)
        for cmd in sorted(source_dir.glob("*.md")):
            dest = target_dir / cmd.name
            shutil.copy2(cmd, dest)
            installed.append(cmd.stem)
        return installed

    def install_hooks(self, target_dir: Path, dashboard_url: str) -> None:
        """Wire Claude Code hooks into .claude/settings.json.

        Each hook is registered as a direct call to the Python interpreter
        that has FACT installed (`sys.executable`) running the corresponding
        helper in `.claude/hooks/`. No bash shim — works on Windows out of
        the box. Paths are absolute and use forward slashes so the same
        command string is valid on POSIX and Windows.
        """
        target_dir.mkdir(parents=True, exist_ok=True)
        settings_path = target_dir.parent / "settings.json"
        existing: dict = {}
        if settings_path.exists():
            try:
                existing = json.loads(settings_path.read_text())
            except json.JSONDecodeError:
                existing = {}

        py = _norm(sys.executable)

        def _cmd(script: str, *args: str) -> str:
            path = _norm(str(target_dir / script))
            tail = (" " + " ".join(args)) if args else ""
            return f'"{py}" "{path}"{tail}'

        hooks_cfg = existing.get("hooks", {})

        # Event forwarders — all delegate to fact_hook.py, passing the event
        # name as argv[1]. Stop reuses the SessionEnd codepath.
        for event in HOOK_EVENTS:
            arg = "SessionEnd" if event == "Stop" else event
            entry = {
                "matcher": "*",
                "hooks": [{"type": "command", "command": _cmd("fact_hook.py", arg)}],
            }
            hooks_cfg.setdefault(event, [])
            # Replace any prior FACT entry (covers upgrades from the
            # bash-shimmed era — its marker was /hooks/<event>.sh).
            hooks_cfg[event] = [e for e in hooks_cfg[event] if not _is_fact_entry(e)]
            hooks_cfg[event].append(entry)

        # Per-file audit trigger on PostToolUse.
        audit_entry = {
            "matcher": "*",
            "hooks": [{"type": "command", "command": _cmd("fact_audit.py")}],
        }
        hooks_cfg["PostToolUse"] = [
            e for e in hooks_cfg["PostToolUse"] if not _is_audit_entry(e)
        ]
        hooks_cfg["PostToolUse"].append(audit_entry)

        # Mid-session compaction trigger — fires at 60% context window.
        compact_progress_entry = {
            "matcher": "*",
            "hooks": [{"type": "command", "command": _cmd("fact_compact_progress.py")}],
        }
        hooks_cfg["PostToolUse"] = [
            e for e in hooks_cfg["PostToolUse"] if not _is_compact_progress_entry(e)
        ]
        hooks_cfg["PostToolUse"].append(compact_progress_entry)

        # Session-resume nudge on SessionStart.
        resume_entry = {
            "matcher": "*",
            "hooks": [{"type": "command", "command": _cmd("fact_session_resume.py")}],
        }
        hooks_cfg.setdefault("SessionStart", [])
        hooks_cfg["SessionStart"] = [
            e for e in hooks_cfg["SessionStart"] if not _is_session_resume_entry(e)
        ]
        hooks_cfg["SessionStart"].append(resume_entry)

        # Cleanup of legacy entries from older FACT versions:
        #  - Stop-time audit/compact (removed; audits are /fact-audit only,
        #    and compact-on-Stop was too frequent — only the 60% trigger remains).
        #  - SubagentEnd key (Claude Code renamed it to SubagentStop).
        if "Stop" in hooks_cfg:
            hooks_cfg["Stop"] = [
                e for e in hooks_cfg["Stop"]
                if not _is_stop_audit_entry(e) and not _is_compact_entry(e)
            ]
        hooks_cfg.pop("SubagentEnd", None)

        existing["hooks"] = hooks_cfg

        env = existing.get("env", {})
        env["FACT_DASHBOARD_URL"] = dashboard_url
        existing["env"] = env

        settings_path.write_text(json.dumps(existing, indent=2) + "\n")

    def session_command(self) -> str:
        return "claude"

    def parse_event(self, raw: dict) -> ParsedEvent:
        kind_raw = raw.get("hook_event_name") or raw.get("event") or ""
        kind_map = {
            "PreToolUse": "pre_tool",
            "PostToolUse": "post_tool",
            "SessionStart": "session_start",
            "SessionEnd": "session_end",
            "SubagentStart": "subagent_start",
            "SubagentStop": "subagent_end",
            "Stop": "session_end",
        }
        kind = kind_map.get(kind_raw, kind_raw.lower() or "unknown")

        usage = raw.get("usage") or {}
        timestamp = raw.get("timestamp") or datetime.now(timezone.utc).isoformat()

        files = []
        tool_input = raw.get("tool_input") or {}
        if isinstance(tool_input, dict):
            for key in ("file_path", "path", "filePath"):
                if key in tool_input and isinstance(tool_input[key], str):
                    files.append(tool_input[key])
                    break

        return ParsedEvent(
            kind=kind,
            timestamp=timestamp,
            model=raw.get("model"),
            tool=raw.get("tool_name") or raw.get("tool"),
            input_tokens=int(usage.get("input_tokens", 0) or 0),
            output_tokens=int(usage.get("output_tokens", 0) or 0),
            cache_read_tokens=int(usage.get("cache_read_input_tokens", 0) or 0),
            files_modified=files,
            raw=raw,
        )


def _norm(p: str) -> str:
    """Normalize a filesystem path to forward slashes so the same command
    string is valid on POSIX and Windows when written to settings.json."""
    return p.replace("\\", "/")


# Markers cover BOTH the current Python-direct shape and the legacy bash-shim
# shape, so `fact upgrade` correctly identifies and replaces old entries.
_FACT_FORWARDER_MARKERS = (
    "fact_hook.py",                # current
    "/hooks/pre_tool_use.sh",      # legacy
    "/hooks/post_tool_use.sh",
    "/hooks/session_start.sh",
    "/hooks/session_end.sh",
    "/hooks/subagent_start.sh",
    "/hooks/subagent_end.sh",
)
_AUDIT_MARKERS = ("fact_audit.py", "/hooks/audit_post_tool_use.sh")
_STOP_AUDIT_MARKERS = ("fact_audit_stop.py", "/hooks/audit_stop.sh")
_COMPACT_MARKERS = ("fact_compact.py", "/hooks/compact_stop.sh")
_COMPACT_PROGRESS_MARKERS = ("fact_compact_progress.py", "/hooks/compact_progress.sh")
_SESSION_RESUME_MARKERS = ("fact_session_resume.py", "/hooks/session_resume.sh")


def _entry_matches(entry: dict, markers: tuple[str, ...]) -> bool:
    if not isinstance(entry, dict):
        return False
    for h in entry.get("hooks", []):
        if not isinstance(h, dict):
            continue
        cmd = h.get("command", "")
        if any(m in cmd for m in markers):
            return True
    return False


def _is_fact_entry(entry: dict) -> bool:
    return _entry_matches(entry, _FACT_FORWARDER_MARKERS)


def _is_audit_entry(entry: dict) -> bool:
    return _entry_matches(entry, _AUDIT_MARKERS)


def _is_stop_audit_entry(entry: dict) -> bool:
    return _entry_matches(entry, _STOP_AUDIT_MARKERS)


def _is_compact_entry(entry: dict) -> bool:
    return _entry_matches(entry, _COMPACT_MARKERS)


def _is_compact_progress_entry(entry: dict) -> bool:
    return _entry_matches(entry, _COMPACT_PROGRESS_MARKERS)


def _is_session_resume_entry(entry: dict) -> bool:
    return _entry_matches(entry, _SESSION_RESUME_MARKERS)
