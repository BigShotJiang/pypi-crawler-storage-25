"""Centralized path conventions for a FACT-managed project."""

from __future__ import annotations

from pathlib import Path


class ProjectPaths:
    """All filesystem locations FACT cares about, derived from a project root."""

    def __init__(self, root: Path):
        self.root = Path(root).resolve()

    # Spec Kit
    @property
    def specify_dir(self) -> Path:
        return self.root / ".specify"

    @property
    def specify_memory(self) -> Path:
        return self.specify_dir / "memory"

    @property
    def constitution(self) -> Path:
        return self.specify_memory / "constitution.md"

    @property
    def project_research(self) -> Path:
        """Brownfield codebase research lives at project level, alongside the
        constitution. Per-feature research (when a specific feature needs its
        own deep dive) goes inside .specify/specs/<feature>/research.md."""
        return self.specify_memory / "research.md"

    @property
    def specs_dir(self) -> Path:
        return self.specify_dir / "specs"

    @property
    def alt_specs_dir(self) -> Path:
        """Some projects (notably anything that follows AGENTS.md's
        "specs/" convention) put feature folders at the project root
        instead of under .specify/. FACT reads both."""
        return self.root / "specs"

    # FACT operational state lives under .specify/fact/
    @property
    def fact_dir(self) -> Path:
        return self.specify_dir / "fact"

    @property
    def config_file(self) -> Path:
        return self.fact_dir / "config.json"

    @property
    def dashboard_pid(self) -> Path:
        return self.fact_dir / "dashboard.pid"

    @property
    def events_file(self) -> Path:
        return self.fact_dir / "events.jsonl"

    @property
    def session_state(self) -> Path:
        return self.fact_dir / "session_state.json"

    @property
    def sessions_dir(self) -> Path:
        return self.fact_dir / "sessions"

    @property
    def audits_dir(self) -> Path:
        return self.fact_dir / "audits"

    # Claude Code
    @property
    def claude_dir(self) -> Path:
        return self.root / ".claude"

    @property
    def skills_dir(self) -> Path:
        return self.claude_dir / "skills"

    @property
    def commands_dir(self) -> Path:
        return self.claude_dir / "commands"

    @property
    def hooks_dir(self) -> Path:
        return self.claude_dir / "hooks"

    @property
    def settings_file(self) -> Path:
        return self.claude_dir / "settings.json"

    @property
    def claude_md(self) -> Path:
        return self.root / "CLAUDE.md"

    def ensure_dirs(self) -> None:
        for d in (
            self.specify_dir,
            self.specify_memory,
            self.specs_dir,
            self.fact_dir,
            self.sessions_dir,
            self.audits_dir,
            self.claude_dir,
            self.skills_dir,
            self.commands_dir,
            self.hooks_dir,
        ):
            d.mkdir(parents=True, exist_ok=True)
