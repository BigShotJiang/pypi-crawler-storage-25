"""Locate FACT's bundled data (skills, commands, hooks, dashboard assets).

Two modes:
  - Installed (wheel): files live under ``fact/_data/``.
  - Source checkout (developer): files live at the repo root.

Either way, callers get a Path.
"""

from __future__ import annotations

from pathlib import Path


def _candidates(name: str) -> list[Path]:
    here = Path(__file__).parent
    return [
        here / "_data" / name,
        here.parent / name,
    ]


def data_path(name: str) -> Path:
    for c in _candidates(name):
        if c.exists():
            return c
    raise FileNotFoundError(f"FACT data not found: {name} (looked in {_candidates(name)})")


def skills_dir() -> Path:
    return data_path("skills")


def commands_dir() -> Path:
    return data_path("commands")


def hooks_dir() -> Path:
    return data_path("hooks")


def dashboard_static_dir() -> Path:
    return data_path("dashboard/static")


def dashboard_templates_dir() -> Path:
    return data_path("dashboard/templates")


def pricing_path() -> Path:
    return data_path("pricing.json")
