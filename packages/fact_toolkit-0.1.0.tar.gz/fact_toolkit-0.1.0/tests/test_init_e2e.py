"""End-to-end smoke test for `fact init` against a temp project."""

from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from fact.cli import app
from fact.paths import ProjectPaths


runner = CliRunner()


def test_init_produces_expected_layout(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["init", "--no-browser", "--no-dashboard"])
    assert result.exit_code == 0, result.output

    paths = ProjectPaths(tmp_path)
    # Skills
    for s in (
        "fact-onboarding",
        "fact-rpi-harness",
        "fact-discovery",
        "fact-research",
        "fact-implement",
        "fact-skill-installer",
        "fact-audit",
    ):
        assert (paths.skills_dir / s / "SKILL.md").exists(), s

    # Commands
    for c in ("fact-start.md", "fact-next.md", "fact-status.md", "fact-audit.md"):
        assert (paths.commands_dir / c).exists(), c

    # Hooks — pure-Python helpers, no bash shim.
    for h in (
        "fact_hook.py",
        "fact_audit.py",
        "fact_audit_stop.py",
        "fact_compact.py",
        "fact_compact_progress.py",
        "fact_session_resume.py",
    ):
        assert (paths.hooks_dir / h).exists(), h
    # No legacy .sh wrappers should be left behind.
    assert list(paths.hooks_dir.glob("*.sh")) == []

    # Settings + CLAUDE.md + config
    settings = json.loads(paths.settings_file.read_text())
    assert "PostToolUse" in settings["hooks"]
    assert settings["env"]["FACT_DASHBOARD_URL"].startswith("http://")
    # Hook commands point at Python helpers directly (no `bash ...`).
    sample_cmd = settings["hooks"]["PreToolUse"][0]["hooks"][0]["command"]
    assert "fact_hook.py" in sample_cmd
    assert not sample_cmd.startswith("bash ")
    assert paths.claude_md.exists()
    cfg = json.loads(paths.config_file.read_text())
    assert cfg["agent"] == "claude-code"


def test_init_idempotent(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    r1 = runner.invoke(app, ["init", "--no-browser", "--no-dashboard"])
    r2 = runner.invoke(app, ["init", "--no-browser", "--no-dashboard"])
    assert r1.exit_code == 0 and r2.exit_code == 0
    settings = json.loads((tmp_path / ".claude" / "settings.json").read_text())
    # PostToolUse has three entries: FACT observation + audit trigger + compact-progress
    # trigger. They should each appear exactly once after re-init.
    assert len(settings["hooks"]["PostToolUse"]) == 3
    # Stop only has the FACT session_end observation; compact-stop was removed.
    assert len(settings["hooks"]["Stop"]) == 1
    # SessionStart has two entries: FACT observation + resume nudge.
    assert len(settings["hooks"]["SessionStart"]) == 2
    # And there should be one entry per other event.
    for event in ("PreToolUse", "SessionEnd", "SubagentStart", "SubagentStop"):
        assert len(settings["hooks"][event]) == 1, event
