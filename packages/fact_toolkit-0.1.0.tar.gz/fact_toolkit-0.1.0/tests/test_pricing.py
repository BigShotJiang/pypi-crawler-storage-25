from fact import pricing


def test_cost_of_event_known_model():
    cb = pricing.cost_of_event(
        {
            "model": "claude-sonnet-4-6",
            "input_tokens": 1_000_000,
            "output_tokens": 1_000_000,
            "cache_read_tokens": 0,
        }
    )
    assert cb.is_complete
    assert cb.cost_usd == 18.0  # 3 + 15


def test_cost_of_event_unknown_model():
    cb = pricing.cost_of_event(
        {"model": "fake", "input_tokens": 100, "output_tokens": 100, "cache_read_tokens": 0}
    )
    assert not cb.is_complete
    assert cb.cost_usd == 0.0


def test_counterfactual_uses_opus():
    events = [
        {"input_tokens": 1_000_000, "output_tokens": 0, "cache_read_tokens": 0},
        {"input_tokens": 0, "output_tokens": 1_000_000, "cache_read_tokens": 0},
    ]
    assert pricing.counterfactual_opus_cost(events) == 15.0 + 75.0
