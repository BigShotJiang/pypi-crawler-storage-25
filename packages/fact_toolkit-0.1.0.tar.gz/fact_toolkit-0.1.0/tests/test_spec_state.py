from pathlib import Path

import pytest

from fact.paths import ProjectPaths
from fact.spec_state import derive_phase, parse_tasks, read_project_state


@pytest.fixture()
def project(tmp_path: Path) -> ProjectPaths:
    p = ProjectPaths(tmp_path)
    p.ensure_dirs()
    return p


def test_parse_tasks_basic(tmp_path: Path):
    f = tmp_path / "tasks.md"
    f.write_text(
        "# Tasks\n\n"
        "- [x] **T-001** First task\n"
        "- [ ] **T-002**: Second task\n"
        "- [X] T003 — Third task\n"
        "Some other line\n"
        "- [ ] T-007 Implement POST /api/tasks\n"
    )
    tasks = parse_tasks(f)
    assert [t.id for t in tasks] == ["T-001", "T-002", "T-003", "T-007"]
    assert [t.done for t in tasks] == [True, False, True, False]
    assert tasks[3].title == "Implement POST /api/tasks"


def test_derive_phase_progression(project: ProjectPaths):
    state = read_project_state(project)
    assert state.current_phase == "constitution"

    project.constitution.write_text("# Const")
    state = read_project_state(project)
    assert state.current_phase == "specify"

    feat = project.specs_dir / "001-x"
    feat.mkdir()
    (feat / "spec.md").write_text("spec")
    state = read_project_state(project)
    assert state.current_phase == "plan"

    (feat / "plan.md").write_text("plan")
    state = read_project_state(project)
    assert state.current_phase == "tasks"

    (feat / "tasks.md").write_text("- [ ] **T-001** A\n- [ ] **T-002** B\n")
    state = read_project_state(project)
    assert state.current_phase == "implement"
    assert state.active_feature.done_tasks == 0

    (feat / "tasks.md").write_text("- [x] **T-001** A\n- [x] **T-002** B\n")
    state = read_project_state(project)
    assert state.current_phase == "done"


def test_derive_phase_explicit():
    assert derive_phase(None, has_constitution=False) == "constitution"
    assert derive_phase(None, has_constitution=True) == "specify"
