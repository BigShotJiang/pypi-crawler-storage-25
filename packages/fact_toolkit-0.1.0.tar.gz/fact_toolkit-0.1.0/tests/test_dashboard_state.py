import json
from pathlib import Path

from fact.dashboard.state import build_snapshot, aggregate_events
from fact.paths import ProjectPaths


def _write_event(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as f:
        f.write(json.dumps(payload) + "\n")


def test_snapshot_empty(tmp_path: Path):
    paths = ProjectPaths(tmp_path)
    paths.ensure_dirs()
    snap = build_snapshot(paths)
    assert snap["project"]["active_feature"] is None
    assert snap["metrics"]["event_count"] == 0
    assert snap["metrics"]["cost_usd"] == 0.0


def test_aggregate_events_with_costs(tmp_path: Path):
    paths = ProjectPaths(tmp_path)
    paths.ensure_dirs()
    _write_event(
        paths.events_file,
        {
            "hook_event_name": "PostToolUse",
            "model": "claude-haiku-4-5",
            "usage": {"input_tokens": 100_000, "output_tokens": 10_000},
        },
    )
    _write_event(
        paths.events_file,
        {
            "hook_event_name": "PostToolUse",
            "model": "claude-opus-4-7",
            "usage": {"input_tokens": 100_000, "output_tokens": 10_000},
        },
    )
    stats = aggregate_events(paths.events_file, "implement")
    assert stats.event_count == 2
    assert stats.total_input == 200_000
    assert stats.total_output == 20_000
    assert stats.cost_complete
    # Haiku event: 100K * 1$/M + 10K * 5$/M = 0.10 + 0.05 = 0.15
    # Opus event:  100K * 15$/M + 10K * 75$/M = 1.50 + 0.75 = 2.25
    assert round(stats.cost_usd, 4) == 2.40
    assert stats.counterfactual_opus > stats.cost_usd  # haiku event would have cost more on opus


def test_parallel_tasks_mark_multiple_in_progress(tmp_path: Path):
    paths = ProjectPaths(tmp_path)
    paths.ensure_dirs()
    # Constitution + a feature with 4 tasks, none done.
    paths.constitution.write_text("# Constitution\n\nEnough body content here to qualify as substantive — at least 120 chars total in the body section, padding padding padding padding padding.\n")
    feat = paths.specs_dir / "001-x"
    feat.mkdir()
    (feat / "spec.md").write_text("# Spec — body\n\n" + ("body. " * 50))
    (feat / "plan.md").write_text("# Plan — body\n\n" + ("plan. " * 50))
    (feat / "tasks.md").write_text(
        "# Tasks\n\n"
        "- [ ] **T-001** Setup\n"
        "- [ ] **T-002** [P] Build module A\n"
        "- [ ] **T-003** [P] Build module B\n"
        "- [ ] **T-004** [P] Build module C\n"
    )
    paths.session_state.write_text(json.dumps({
        "updated_at": "2026-04-30T00:00:00Z",
        "active_task_id": "T-001",
        "active_task_started_at": "2026-04-30T00:00:00Z",
        "parallel_tasks": [
            {"id": "T-002", "started_at": "2026-04-30T00:00:05Z", "subagent_id": "sa_a", "model": "claude-haiku-4-5"},
            {"id": "T-003", "started_at": "2026-04-30T00:00:06Z", "subagent_id": "sa_b", "model": "claude-sonnet-4-6"},
        ],
    }))

    snap = build_snapshot(paths)
    by_id = {t["id"]: t for t in snap["project"]["kanban_tasks"]}

    assert by_id["T-001"]["in_progress"] is True
    assert by_id["T-001"]["subagent"] is None  # main agent, not delegated
    assert by_id["T-002"]["in_progress"] is True
    assert by_id["T-002"]["subagent"] == {"id": "sa_a", "model": "claude-haiku-4-5"}
    assert by_id["T-003"]["in_progress"] is True
    assert by_id["T-003"]["subagent"]["model"] == "claude-sonnet-4-6"
    # T-004 has no entry → still pending
    assert by_id["T-004"]["in_progress"] is False
    assert by_id["T-004"]["subagent"] is None


def test_parallel_entries_use_their_own_started_at(tmp_path: Path):
    paths = ProjectPaths(tmp_path)
    paths.ensure_dirs()
    paths.constitution.write_text("# C\n\n" + ("x" * 200))
    feat = paths.specs_dir / "001-x"
    feat.mkdir()
    (feat / "spec.md").write_text("# Spec\n\n" + ("x" * 200))
    (feat / "tasks.md").write_text("- [ ] **T-005** [P] thing\n")
    paths.session_state.write_text(json.dumps({
        "active_task_id": "T-other",
        "active_task_started_at": "2026-04-30T00:00:00Z",
        "parallel_tasks": [{"id": "T-005", "started_at": "2026-04-30T00:05:00Z"}],
    }))

    snap = build_snapshot(paths)
    by_id = {t["id"]: t for t in snap["project"]["kanban_tasks"]}
    assert by_id["T-005"]["in_progress"] is True
    assert by_id["T-005"]["active_task_started_at"] == "2026-04-30T00:05:00Z"


def test_inferred_in_progress_picks_lowest_position(tmp_path: Path):
    """When two pending tasks reference the same recent file, only the
    lowest-position one should be marked in_progress — the others stay
    pending until the agent gets to them."""
    paths = ProjectPaths(tmp_path)
    paths.ensure_dirs()
    paths.constitution.write_text("# C\n\n" + ("x" * 200))
    feat = paths.specs_dir / "001-x"
    feat.mkdir()
    (feat / "spec.md").write_text("# Spec\n\n" + ("x" * 200))
    # Two pending tasks share the same file.
    (feat / "tasks.md").write_text(
        "## Implementation for User Story 1\n\n"
        "- [ ] **T-022** Create `partials/task_card.html` (read-only version)\n\n"
        "## Implementation for User Story 2\n\n"
        "- [ ] **T-032** Update `partials/task_card.html` with HTMX buttons\n"
    )
    from datetime import datetime, timezone
    paths.session_state.write_text(json.dumps({
        "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "files_modified_this_turn": [
            "/abs/path/to/partials/task_card.html",
        ],
    }))

    snap = build_snapshot(paths)
    by_id = {t["id"]: t for t in snap["project"]["kanban_tasks"] if t["id"].startswith("T-")}

    # Lowest-position pending wins.
    assert by_id["T-022"]["in_progress"] is True
    assert by_id["T-022"]["inferred_in_progress"] is True
    # Other pending match stays pending despite sharing the file.
    assert by_id["T-032"]["in_progress"] is False
    assert by_id["T-032"]["inferred_in_progress"] is False


def test_skill_installed_event_appears_in_snapshot(tmp_path: Path):
    paths = ProjectPaths(tmp_path)
    paths.ensure_dirs()
    _write_event(paths.events_file, {"kind": "skill_installed", "name": "stripe-best-practices"})
    snap = build_snapshot(paths)
    # Skills installed via event are aggregated into TokenStats; the dashboard
    # also displays skills present on disk (none here). Both paths exist.
    stats = aggregate_events(paths.events_file, "specify")
    assert "stripe-best-practices" in stats.skills_installed
