#!/usr/bin/env python3
"""Audit trigger — fires when the agent edits a file that warrants a review.

The hook itself runs no linters and produces no findings. It only decides
*when* an audit is warranted, then writes a structured prompt to stderr and
exits with code 2. Claude Code surfaces the stderr to the agent's next turn,
which loads the `fact-audit` skill and orchestrates the actual audit through
sub-agents loaded with domain skills from skills.sh.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

# Source files that should be audited per-edit.
SOURCE_EXTENSIONS = {
    ".py", ".ts", ".tsx", ".js", ".jsx", ".rs", ".go", ".java", ".kt",
    ".rb", ".php", ".c", ".cpp", ".h", ".hpp", ".cs", ".swift", ".scala",
    ".ex", ".exs", ".clj", ".sh",
}

TASKS_FILENAME = "tasks.md"
TASKS_PATH_FRAGMENT = os.sep + ".specify" + os.sep + "specs" + os.sep


def _project_root() -> Path:
    return Path(os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd()))


def _read_payload() -> dict:
    raw = sys.stdin.read().strip()
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def _file_from_payload(p: dict) -> str | None:
    ti = p.get("tool_input") or {}
    if not isinstance(ti, dict):
        return None
    for k in ("file_path", "path", "filePath"):
        v = ti.get(k)
        if isinstance(v, str):
            return v
    return None


def _decide(file_str: str, root: Path) -> tuple[str, list[str]] | None:
    """Decide whether this edit warrants an audit.

    Returns (trigger_kind, dimensions) or None.

      - tasks.md edit  → ("task-close", [security, architecture, quality])
                         A task was likely just closed; run a full review.
      - source-file    → ("source-edit", [security, quality])
                         Fast focused review on the file just changed.
    """
    file_path = Path(file_str)

    if file_path.name == TASKS_FILENAME and TASKS_PATH_FRAGMENT in file_str:
        return ("task-close", ["security", "architecture", "quality"])

    if file_path.suffix.lower() in SOURCE_EXTENSIONS:
        try:
            file_path.resolve().relative_to(root.resolve())
        except (ValueError, OSError):
            return None
        return ("source-edit", ["security", "quality"])

    return None


def _trigger_message(trigger_kind: str, dimensions: list[str], scope: str) -> str:
    section = {
        "source-edit": "§Per-edit review",
        "task-close":  "§Per-task review",
    }[trigger_kind]
    return "\n".join([
        f"🔒 FACT AUDIT — workflow halted ({trigger_kind})",
        f"Scope:      {scope}",
        f"Dimensions: {', '.join(dimensions)}",
        "",
        f"PROTOCOL — load the `fact-audit` skill and follow {section}.",
        "",
        f"  1. For each of [{', '.join(dimensions)}], get a domain skill from",
        "     `.claude/skills/` (or install via fact-skill-installer with user",
        "     confirmation). Search queries are listed in fact-audit §Domain skills.",
        "",
        "  2. Spawn one sub-agent per dimension (parallel where possible):",
        "       - source-edit:  Haiku sub-agent, narrow file scope",
        "       - task-close:   Sonnet sub-agent, files modified since last audit",
        "     Each sub-agent loaded with the domain skill returns structured",
        "     findings (severity / location / fix).",
        "",
        "  3. Aggregate findings. Show them to the user **verbatim** — don't",
        "     summarize away severity.",
        "",
        "  4. Ask the user: fix automatically · I'll fix manually · override",
        "     (with logged reason) · rollback.",
        "",
        "  5. Do NOT proceed until the user has decided.",
        "",
        "  6. After fixing, the next file write re-triggers this audit; it must",
        "     come back clean (no critical / high) before workflow resumes.",
    ])


def main() -> int:
    payload = _read_payload()
    if (payload.get("hook_event_name") or "") != "PostToolUse":
        return 0
    if (payload.get("tool_name") or "") not in ("Edit", "Write", "MultiEdit"):
        return 0

    file_str = _file_from_payload(payload)
    if not file_str:
        return 0

    root = _project_root()
    decision = _decide(file_str, root)
    if not decision:
        return 0

    trigger_kind, dimensions = decision

    file_path = Path(file_str)
    try:
        rel = file_path.resolve().relative_to(root.resolve())
        scope = (
            "files modified since the last audit"
            if trigger_kind == "task-close"
            else f"the file `{rel}`"
        )
    except (ValueError, OSError):
        scope = file_str

    print(_trigger_message(trigger_kind, dimensions, scope), file=sys.stderr)
    return 2


if __name__ == "__main__":
    # Fail-soft: clamp exit to {0, 2}. Anything else (uncaught exception,
    # unexpected return value) becomes 0 so a hook bug never blocks the agent.
    try:
        rc = main()
    except Exception:
        rc = 0
    sys.exit(rc if rc in (0, 2) else 0)
