#!/usr/bin/env python3
"""PostToolUse compaction trigger — fires once when the active context cache
reaches 60% of the model's context window. That's the only signal: no
section-closure / feature-complete / phase-transition triggers, no Stop
auto-fire. The user found those too frequent.

Loop safety: 5-min cooldown after each fire so the hook doesn't re-prompt
on every PostToolUse while the context stays full. Once the agent (or
user) actually compacts, cache drops and the cycle resumes from below
the threshold.
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path


CONTEXT_WINDOW_PCT = 0.60      # fire when current context ≥ 60% of window
COOLDOWN_SECONDS = 300         # 5 min between successive safety-net fires
DEFAULT_CONTEXT_WINDOW = 200_000
PRICING_PATH_CANDIDATES = (
    Path(__file__).parent.parent / "pricing.json",
    Path(__file__).parent / "pricing.json",
)


def _project_root() -> Path:
    return Path(os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd()))


def _read_payload() -> dict:
    raw = sys.stdin.read().strip()
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def _file_from_payload(p: dict) -> str | None:
    ti = p.get("tool_input") or {}
    if not isinstance(ti, dict):
        return None
    for k in ("file_path", "path", "filePath"):
        v = ti.get(k)
        if isinstance(v, str):
            return v
    return None


def _latest_context_size_and_model(events_file: Path, session_id: str) -> tuple[int, str | None]:
    """Walk events.jsonl, return the most recent unique assistant message's
    cache_read (proxy for current context size) plus its model id."""
    if not events_file.exists():
        return 0, None
    seen: set[str] = set()
    last_cache = 0
    last_model: str | None = None
    try:
        with events_file.open() as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if e.get("session_id") != session_id:
                    continue
                uid = e.get("message_uuid")
                if not uid or uid in seen:
                    continue
                seen.add(uid)
                u = e.get("usage") or {}
                cache = int(u.get("cache_read_input_tokens", 0) or 0)
                if cache > 0:
                    last_cache = cache
                    last_model = e.get("model") or last_model
    except OSError:
        return 0, None
    return last_cache, last_model


def _context_window_for(model: str | None) -> int:
    if not model:
        return DEFAULT_CONTEXT_WINDOW
    for p in PRICING_PATH_CANDIDATES:
        if not p.exists():
            continue
        try:
            data = json.loads(p.read_text())
        except (json.JSONDecodeError, OSError):
            continue
        models = data.get("models", {})
        m = models.get(model)
        if not isinstance(m, dict):
            # try stripping a -YYYYMMDD date suffix
            import re
            stripped = re.sub(r"-\d{8}$", "", model)
            m = models.get(stripped) if stripped != model else None
        if isinstance(m, dict) and isinstance(m.get("context_window"), int):
            return int(m["context_window"])
    return DEFAULT_CONTEXT_WINDOW


def _trigger_message(reason: str, scope: str, suggested_path: str) -> str:
    return "\n".join([
        f"📦 FACT COMPACTION — {reason}",
        f"Scope: {scope}",
        f"Suggested file: {suggested_path}",
        "",
        "PROTOCOL — load `fact-rpi-harness` and follow §1 (Intentional compaction):",
        "",
        "  1. Pick a natural seam — finish what you were saying.",
        "  2. Write a summary to the suggested path with the §4 sections:",
        "       ## What was done",
        "       ## What was decided",
        "       ## What's pending / next",
        "",
        "  3. Tell the user, in one short message, with three options:",
        "       (a) Run /compact here — Claude Code summarizes in place.",
        "       (b) Close + reopen Claude Code with the summary as primer.",
        "       (c) Keep going — accept cache_read on the full transcript.",
        "",
        "  4. CRITICAL — close with a 'how to wake me up' hint:",
        '       "After /compact, just type your next instruction — I\'ll',
        '        pick up from <next concrete step>."',
    ])


def main() -> int:
    payload = _read_payload()
    if (payload.get("hook_event_name") or "") != "PostToolUse":
        return 0

    # Only count actual modifications when checking — Reads shouldn't bump
    # the trigger evaluation cadence (although they don't grow context much
    # either).
    tool_name = payload.get("tool_name") or ""
    if tool_name not in ("Edit", "Write", "MultiEdit", "Bash"):
        # Bash included so post-compact `cat`s and similar still trigger
        # the check; the cache_read calculation depends on transcript
        # snapshots, not on this hook's tool_name filter.
        return 0

    session_id = payload.get("session_id") or "unknown"
    if session_id == "unknown":
        return 0

    # Don't self-trigger while writing the compaction summary.
    file_path = _file_from_payload(payload) or ""
    if "/.specify/fact/sessions/" in file_path:
        return 0

    root = _project_root()
    fact_dir = root / ".specify" / "fact"

    cache_now, model = _latest_context_size_and_model(fact_dir / "events.jsonl", session_id)
    window = _context_window_for(model)
    pct = cache_now / window if window else 0
    if pct < CONTEXT_WINDOW_PCT:
        return 0

    last_fire_path = fact_dir / f".compact-window-{session_id}.last_fire"
    now = datetime.now(timezone.utc).timestamp()
    if last_fire_path.exists():
        try:
            last_fire = float(last_fire_path.read_text().strip())
            if now - last_fire < COOLDOWN_SECONDS:
                return 0  # still in cooldown
        except (OSError, ValueError):
            pass
    last_fire_path.parent.mkdir(parents=True, exist_ok=True)
    last_fire_path.write_text(f"{now:.3f}")

    pct_label = f"{int(pct * 100)}%"
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H%M")
    suggested = f".specify/fact/sessions/{ts}-compact.md"
    print(_trigger_message(
        f"context at {pct_label} of window — compact recommended",
        f"current cache: {cache_now:,} / {window:,} ({model or 'unknown model'})",
        suggested,
    ), file=sys.stderr)
    return 2


if __name__ == "__main__":
    # Fail-soft: clamp exit to {0, 2}. A hook crash must never block the agent.
    try:
        rc = main()
    except Exception:
        rc = 0
    sys.exit(rc if rc in (0, 2) else 0)
