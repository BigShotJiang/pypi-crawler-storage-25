#!/usr/bin/env python3
"""FACT hook helper — invoked by .claude/hooks/*.sh on every Claude Code event.

Reads the JSON payload from stdin (Claude Code's hook contract), POSTs it to
the dashboard server, and on PostToolUse also updates session_state.json.

Designed to fail silently: a hook MUST NOT block or break the user's session.
If the dashboard is down, the script exits 0 with a warning to stderr (which
Claude Code typically suppresses for non-blocking hooks).
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


def _project_root() -> Path:
    env = os.environ.get("CLAUDE_PROJECT_DIR")
    if env:
        return Path(env)
    return Path.cwd()


def _dashboard_url() -> str:
    return os.environ.get("FACT_DASHBOARD_URL", "http://127.0.0.1:7842")


def _read_payload() -> dict:
    raw = sys.stdin.read().strip()
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"_unparsed": raw}


def _last_assistant_usage(transcript_path: str | None) -> dict | None:
    """Walk the Claude Code transcript backwards, return the most recent
    assistant record's model + usage + message uuid (for dedup).

    Claude Code's PostToolUse payload doesn't include token info, but the
    transcript file does. Reading it from the hook means each event we POST
    to the dashboard already carries the cost data.
    """
    if not transcript_path:
        return None
    try:
        import os.path as op
        if not op.exists(transcript_path):
            return None
        with open(transcript_path, "rb") as f:
            # Read tail efficiently for large transcripts.
            try:
                f.seek(0, 2)
                size = f.tell()
                start = max(0, size - 64 * 1024)
                f.seek(start)
                tail = f.read().decode("utf-8", errors="replace")
            except OSError:
                f.seek(0)
                tail = f.read().decode("utf-8", errors="replace")
        lines = [ln for ln in tail.splitlines() if ln.strip()]
        for ln in reversed(lines):
            try:
                rec = json.loads(ln)
            except Exception:
                continue
            if rec.get("type") != "assistant":
                continue
            msg = rec.get("message") or {}
            if not isinstance(msg, dict):
                continue
            usage = msg.get("usage")
            if not usage:
                continue
            return {
                "model": msg.get("model"),
                "usage": usage,
                "message_uuid": msg.get("id") or rec.get("uuid"),
            }
    except Exception as e:
        print(f"[fact-hook] transcript read failed: {e}", file=sys.stderr)
    return None


def _post_event(event: dict) -> None:
    url = _dashboard_url().rstrip("/") + "/event"
    body = json.dumps(event).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        urllib.request.urlopen(req, timeout=0.5)
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        print(f"[fact-hook] dashboard unreachable: {e}", file=sys.stderr)


def _update_session_state(event_name: str, payload: dict) -> None:
    """Mechanical state — written every PostToolUse, no agent tokens spent."""
    if event_name != "PostToolUse":
        return
    root = _project_root()
    state_path = root / ".specify" / "fact" / "session_state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if state_path.exists():
        try:
            existing = json.loads(state_path.read_text())
        except json.JSONDecodeError:
            existing = {}

    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    tool_input = payload.get("tool_input") or {}
    tool_name = payload.get("tool_name") or ""

    # Only count actual *modifications* toward the recent-edits buffer. The
    # agent reading spec.md to remember its content shouldn't make the
    # dashboard think it's actively editing it. Edit / Write / MultiEdit
    # are the only tools that change file contents.
    file_path = None
    if tool_name in ("Edit", "Write", "MultiEdit"):
        if isinstance(tool_input, dict):
            for key in ("file_path", "path", "filePath"):
                v = tool_input.get(key)
                if isinstance(v, str):
                    file_path = v
                    break

    # Track only the most recent few files. The buffer is meant to answer
    # "what is the agent touching right now", not "what has it ever touched".
    # Larger windows confuse in-progress inference with stale state.
    files_this_turn = list(existing.get("files_modified_this_turn", []))
    if file_path and file_path not in files_this_turn:
        files_this_turn.append(file_path)
    files_this_turn = files_this_turn[-5:]

    existing.update(
        {
            "updated_at": now,
            "session_id": payload.get("session_id") or existing.get("session_id"),
            "model": payload.get("model") or existing.get("model"),
            "files_modified_this_turn": files_this_turn,
        }
    )
    # active_feature / active_task_id / active_task_started_at are written by
    # the agent itself (per fact-implement §2). We don't overwrite them here.

    tmp = state_path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(existing, indent=2) + "\n")
    tmp.replace(state_path)


def main() -> int:
    if len(sys.argv) < 2:
        print("usage: fact_hook.py <event-name>", file=sys.stderr)
        return 0  # never block the session

    event_name = sys.argv[1]
    payload = _read_payload()

    payload = {
        **payload,
        "hook_event_name": event_name,
        "fact_received_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }

    # Attach token usage by reading the latest assistant record from the
    # transcript referenced in the payload. Cheap (~64KB tail read) and runs
    # only on PostToolUse / SessionEnd / Subagent* — never blocks the user.
    if event_name in ("PostToolUse", "SessionEnd", "SubagentStop"):
        extra = _last_assistant_usage(payload.get("transcript_path"))
        if extra:
            payload.setdefault("model", extra["model"])
            payload.setdefault("usage", extra["usage"])
            payload["message_uuid"] = extra["message_uuid"]

    _update_session_state(event_name, payload)
    _post_event(payload)
    return 0


if __name__ == "__main__":
    # Fail-soft: an exception in this hook must never block the agent.
    try:
        main()
    except Exception:
        pass
    sys.exit(0)
