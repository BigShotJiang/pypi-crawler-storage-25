#!/usr/bin/env python3
"""SessionStart hook — when there's prior session state on disk, emit a
stderr nudge so the agent loads `fact-onboarding` before answering the
user's first message.

Without this, a user who closes Claude Code and reopens it sees the agent
greet them blank ("hola, how can I help?") even though there's a summary
on disk that says "we were in the middle of LinkedIn publish, plan template
just copied". The CLAUDE.md template tells the agent the same thing, but
this hook is a hard nudge that's harder to ignore.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path


def _project_root() -> Path:
    return Path(os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd()))


def _read_payload() -> dict:
    raw = sys.stdin.read().strip()
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def main() -> int:
    payload = _read_payload()
    if (payload.get("hook_event_name") or "") != "SessionStart":
        return 0

    root = _project_root()
    sessions_dir = root / ".specify" / "fact" / "sessions"
    state_file = root / ".specify" / "fact" / "session_state.json"

    has_summaries = sessions_dir.exists() and any(sessions_dir.glob("*.md"))
    has_state = state_file.exists()
    if not has_summaries and not has_state:
        return 0  # truly empty project; nothing to resume

    # Find the most recent summary so the agent has a concrete file to read.
    latest = None
    if has_summaries:
        try:
            latest = max(sessions_dir.glob("*.md"), key=lambda p: p.stat().st_mtime)
        except (OSError, ValueError):
            latest = None

    msg = [
        "🔄 FACT — resumed session detected",
        "",
        "PROTOCOL — before answering the user's first message:",
        "",
        "  1. Load `fact-onboarding` skill: read",
        "     `.claude/skills/fact-onboarding/SKILL.md`.",
        "  2. Load `fact-rpi-harness` skill (always-on rules).",
        "  3. Read `.specify/fact/session_state.json` and the most recent",
        "     summary file. The latest is:",
        f"        {latest.relative_to(root) if latest else '(no summary file yet)'}",
        "  4. Present continuity per fact-onboarding §3 (Resume protocol):",
        "     a one-paragraph 'we were working on X, last task was Y, next",
        "     pending is Z — continue?' message.",
        "  5. Do NOT respond with a generic 'how can I help?' — the user just",
        "     reopened a session in progress.",
        "",
        "If the user already typed something, weave their message into your",
        "continuity reply (e.g. they typed 'continuar' → \"Yes, continuing",
        "from <last task>; the next step is <next>.\").",
    ]
    print("\n".join(msg), file=sys.stderr)
    # Exit 0 (not 2) — SessionStart shouldn't block. Stderr still shows up to
    # the agent's first turn in Claude Code's transcript.
    return 0


if __name__ == "__main__":
    # Fail-soft: a session-resume nudge must never block SessionStart.
    try:
        main()
    except Exception:
        pass
    sys.exit(0)
