---
name: fact-discovery
description: Greenfield discovery — structured conversation to capture vision, then hand off to constitution → specify → plan.
---

# fact-discovery

Loaded when the user picks "greenfield" in `/fact-start`. Your goal is to extract enough vision in **one short conversation** that `/speckit.specify` can produce a useful first spec.

## Phase 1 — Discover

Ask, one question at a time (don't dump the list):

1. **What do you want to build?** (one-paragraph answer)
2. **Who is it for?** (target users, not "everyone")
3. **What problem does it solve?** (in their words)
4. **What are the 3-5 core features for v1?** (cut, don't add)
5. **Anything similar you admire or want to avoid?** (references)
6. **Constraints** — budget, deadline, deployment target, product language.
7. **Preferred stack** (if they have one; otherwise suggest in §3).

Stop asking once the picture is clear. Six questions is usually enough; ten is too many.

## Phase 2 — Investigate references (if any)

If the user mentioned a reference ("something like Notion", "like Linear but…"), spawn a **sub-agent** (model: Haiku or Sonnet — see fact-rpi-harness §3) with a focused prompt:

> Investigate in one pass the typical features and value proposition of <reference>. Return 5-10 bullets, no more.

Don't read the response into the main context until the sub-agent returns its summary.

## Phase 3 — Draft vision

Synthesize a vision draft and present it to the user verbatim, as a block:

```markdown
# Vision — <project-name>

## For whom
<1-2 lines>

## Problem it solves
<1-2 lines>

## Core features v1
- <feature 1>
- <feature 2>
- ...

## Tentative stack
<one line>

## Constraints
<one line>
```

Ask: "does this capture what you want? Tell me what you'd change."

Iterate at most twice. If the user keeps adding scope, push back: "is this v1 or are you already imagining v2? FACT separates phases."

## Phase 4 — Skill suggestion (with confirmation)

Once vision is approved, scan the proposed stack for technologies that benefit from procedural skills (e.g. Next.js, Supabase, Stripe, Tailwind, Postgres patterns). If you identify candidates, **load the skill `fact-skill-installer`** and follow its protocol — ask the user before downloading anything.

## Phase 5 — Hand-off

Trigger Spec Kit in this order:
1. `/speckit.constitution` — derive 4-6 principles from the vision (taste, scope discipline, target users).
2. `/speckit.specify` — feed it the approved vision.
3. `/speckit.clarify` — let it surface ambiguities; resolve them with the user.
4. `/speckit.plan` — with the agreed stack.
5. **Pre-implementation audit gate (mandatory).** Load `fact-audit` and run its pre-implement gate against `constitution.md` + `spec.md` + `plan.md`. If any critical findings, return to step 4 to revise the plan. Only proceed past the gate when no critical finding remains.
6. `/speckit.tasks`.

Between each step: write a short summary to `.specify/fact/sessions/` (per fact-rpi-harness §4) and ask the user if they want to review the generated file before continuing.

After `/speckit.tasks`: load `fact-implement` and stop narrating from this skill.
