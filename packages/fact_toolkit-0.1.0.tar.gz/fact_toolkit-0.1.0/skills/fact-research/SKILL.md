---
name: fact-research
description: Brownfield research — parallel sub-agents map an existing codebase into research.md, then hand off to constitution → specify (delta).
---

# fact-research

Loaded when the user picks "brownfield" in `/fact-start`. Your job is to understand the codebase **enough to produce a faithful `research.md`** without reading every file yourself.

## 1. Spawn parallel sub-agents (vertical slices)

Spawn 7 `Explore` sub-agents **in parallel** (one message, multiple
`Agent` tool calls). Each reports 10-30 lines, no more.

**Critical — pass `model="haiku"` on every call**. Without it the
sub-agents inherit Opus and the brownfield mapping pass costs 10×
what it should. Only the synthesis step in §2 below justifies
Sonnet. See fact-rpi-harness §3 for the rationale.

Concrete shape per slice:

```
Agent(
  description="map folder structure",
  subagent_type="Explore",
  model="haiku",
  prompt="List the top-level folders in <project root> and one-line
          their role. Don't open more than ~5 files. Return ≤25 lines."
)
```

Default slice list (skip slices that obviously don't apply):

| Slice                  | Sub-agent task                                                  | Model    |
| ---------------------- | --------------------------------------------------------------- | -------- |
| Folder structure       | Map top-level dirs and their roles                              | Haiku    |
| Stack & dependencies   | Read `package.json` / `pyproject.toml` / `Cargo.toml` / `go.mod` | Haiku    |
| Code conventions       | Read 3-5 representative files; report style, patterns, idioms   | Sonnet   |
| Main modules           | Identify entry points and the 3-5 most central modules          | Sonnet   |
| Tests                  | What test framework, what's tested, what coverage looks like    | Haiku    |
| Build & deploy         | CI configs, Dockerfile, deploy scripts                          | Haiku    |
| Existing docs          | README, ARCHITECTURE.md, ADRs                                   | Haiku    |

**Important**: do NOT also do the work yourself. Wait for the sub-agents to return their summaries.

## 2. Compose `research.md`

Once all sub-agents return, compose a single project-level research file at **`.specify/memory/research.md`** (alongside `constitution.md`). Brownfield research describes the existing codebase as a whole — it is not feature-specific, so it does NOT go inside `.specify/specs/<feature>/`.

```markdown
# Research — <project>

## Structure
<3-7 bullets from folder slice>

## Stack
<3-5 bullets: language, framework, key libs>

## Conventions
<3-5 bullets>

## Core modules
- `<path>` — <one-line role>
- ...

## Tests
<2-3 bullets>

## Build & deploy
<2-3 bullets>

## Notes / risks
<observations the user should know before changing things>
```

Length target: under 200 lines. If you can't fit it, you didn't compress enough.

## 3. Present and validate

Show `research.md` to the user. Ask: "anything I'm missing or got wrong?"

Iterate once if needed. The point of this step is shared ground truth, not a perfect map.

## 4. Constitution

When the user picked FACT, they put FACT in charge of project
governance and layout. FACT's locations are **canonical and
non-negotiable**:

- Constitution → `.specify/memory/constitution.md`
- Project research → `.specify/memory/research.md`
- Specs / plans / tasks → `.specify/specs/<feature>/...`
- Operational state → `.specify/fact/...`

The agent **MUST** write to these paths. AGENTS.md / CLAUDE.md /
GEMINI.md or any other doc that says otherwise is **superseded by
FACT** for layout and process decisions. They may still hold useful
domain knowledge — the absorption rule below covers that.

### 4a. No pre-existing governance doc

Run `/speckit.constitution` normally. Derive principles from what
you observed during research (testing style, error handling,
layering, naming). Don't invent principles the codebase doesn't
already follow.

### 4b. Pre-existing governance doc found (brownfield with AGENTS.md / CLAUDE.md / GEMINI.md / similar)

The previous doc has domain knowledge worth keeping (e.g. "use the
Gemini fallback chain", "uploads land in `source/public/generated/`",
"never store secrets in code"). Absorb it; do not honor it as a
parallel authority.

Steps, in order, no user dialog needed for choice:

1. Read `<X>.md` and identify what's actually project-specific
   knowledge versus what's generic process / layout language. The
   former goes into the constitution; the latter is dropped because
   FACT already governs process and layout.

2. Run `/speckit.constitution`. The constitution lives at
   `.specify/memory/constitution.md`. Include the absorbed domain
   principles + whatever you observed during research.

3. Replace `<X>.md` with a thin one-paragraph pointer back to the
   constitution (so anything that links to it still works), e.g.:
   ```
   # AGENTS.md
   This project uses FACT. Project governance now lives in
   .specify/memory/constitution.md. See that file for principles
   and conventions. This stub remains so external links don't
   break.
   ```

4. Tell the user, in one short message: "I absorbed `<X>.md` into
   the constitution and turned `<X>.md` into a pointer. FACT is
   the single source of truth from here. Layout follows FACT's
   conventions (`.specify/specs/`, `.specify/memory/`), regardless
   of what `<X>.md` used to say."

5. **Do not** offer the user a choice about which file should be
   authoritative. They already chose by using FACT. Past versions
   of this skill offered three options here; that produced
   constitutions that contradicted themselves and features written
   to `specs/` (legacy convention) instead of `.specify/specs/`
   (where FACT looks). Don't repeat that.

## 5. Spec, plan, audit gate, tasks

- Ask the user what change they want to make. Run `/speckit.specify` — the spec is a **delta** over the current state, not a clean-slate spec.
- Continue with `/speckit.clarify`, `/speckit.plan`.
- **Pre-implementation audit gate (mandatory).** Load `fact-audit` and run its pre-implement gate. Do not proceed to `/speckit.tasks` if any critical finding stands. For brownfield, the audit also gets `research.md` so it can flag misalignments with existing conventions.
- Then run `/speckit.tasks`.

## 6. Skill suggestion

Based on the detected stack, consider whether procedural skills exist that would help. Load `fact-skill-installer` and follow its protocol (always with user confirmation).

## 7. Hand-off

After `/speckit.tasks`: write a session summary (fact-rpi-harness §4), load `fact-implement`, stop narrating.
