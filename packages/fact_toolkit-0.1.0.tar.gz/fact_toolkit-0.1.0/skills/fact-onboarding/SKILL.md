---
name: fact-onboarding
description: First skill loaded after /fact-start. Detects continuity, asks for project type if new, and hands off to the right workflow skill.
---

# fact-onboarding

You are about to onboard the user into the FACT workflow. Follow this protocol exactly.

## 1. Always check for continuity first

Before saying anything to the user, read these files (skip silently if absent):

- `.specify/fact/session_state.json` — last mechanical snapshot (active task, files, model).
- `.specify/fact/sessions/` — list the directory; read the **last 1-3** session summaries (most recent first).
- `.specify/specs/` — list features. The most recently modified one is likely active.

If `session_state.json` exists AND there is at least one session summary:

> This is a **resumed** session. Skip the welcome. Go to **§3 Resume protocol**.

If neither exists:

> This is a **fresh** project. Go to **§2 Fresh project**.

## 2. Fresh project

Greet the user briefly (one sentence) and ask which workflow to use:

```
[You]: FACT is ready. Before we start, what kind of project is this?

  1. greenfield — building from scratch
  2. brownfield — working on an existing codebase
  3. demo       — quick experiment (TinySpec, no discovery)

(pick 1, 2, or 3)
```

Once chosen, **load the corresponding skill** (read its SKILL.md with the file tool and follow its instructions):

- `1` → load `fact-discovery` (greenfield workflow).
- `2` → load `fact-research` (brownfield workflow).
- `3` → run `/speckit.specify` directly with the `tinyspec` extension; the user will write a one-shot spec.

Then yield control to that skill — don't keep narrating from this one.

## 3. Resume protocol

Read `session_state.json`. Read the most recent file under `.specify/fact/sessions/`. Compare the active task ID against `tasks.md` of `active_feature`.

Three cases:

**3a. Last session ended cleanly** — `active_task_id` in `session_state.json` is marked `[x]` in `tasks.md`, OR there is no `active_task_id`. Present:

```
[You]: We were working on "<feature>" (<workflow type>).
The last session ended <when> after completing <task or phase>.
<one-line summary of last "decisions" if present>

The next pending task is <next pending task>.

Continue from there, or do you want to review/change something first?
```

**3b. Task was abandoned mid-flight** — `active_task_id` is `[ ]` (still pending) but `files_modified_this_turn` is non-empty:

```
[You]: <task_id> was left in progress in the previous session. I see
<files> were modified. Comparing against the plan, it looks like
<inferred remaining work> is missing.
Continue from there, or reset <task_id> and start over?
```

Wait for the user. Never assume.

**3c. State files corrupted or partial** — degrade gracefully. Read what you can from the Spec Kit files (`spec.md`, `plan.md`, `tasks.md`) and tell the user honestly:

```
[You]: I have the project context but lost the details of the last
session. We're in phase <phase>, with <N>/<M> tasks done. Do you remember
what we were doing, or should we start from the next pending task?
```

## 4. After onboarding

Once you've handed off to a workflow skill (or the user has chosen "continue"), **stop narrating from this skill**. The user shouldn't see meta-commentary; they should just see the workflow proceed naturally.
