---
name: fact-skill-installer
description: Search skills.sh for a relevant skill, present it to the user, and install with explicit confirmation. Never installs without an explicit "yes".
---

# fact-skill-installer

Loaded when another skill (or you) decides procedural knowledge from skills.sh would help. **You never download anything without explicit user confirmation in chat** (P7 in the FACT spec).

## 1. Identify the need

You should know:
- The technology or domain that needs the skill (e.g. "Stripe integration", "Next.js routing").
- Why now (which task or step would benefit).

If the need is fuzzy ("maybe a skill would help generally"), don't proceed. Skills are specific.

## 2. Search skills.sh

Search the public catalog at https://skills.sh. Two methods, in order of preference:

1. **API**: GET `https://skills.sh/api/skills?q=<query>` if the API exists at runtime (verify before assuming).
2. **Page fetch**: WebFetch the search URL `https://skills.sh/search?q=<query>` and parse results.

Pick the top **one** candidate. Filter by:
- **Popularity** — install count, stars on the source repo.
- **Org reputation** — official orgs (vendor-published) > established orgs > random users.
- **Recency** — repo updated in the last few months.

If nothing meets a reasonable bar, tell the user "couldn't find a worthwhile skill — proceeding with general knowledge."

## 3. Present and ask

Format (verbatim):

```
[You]: For <task or step>, I found a relevant skill:

  Skill: <name>
  Org: <org>
  Installs: <count if known, else "—">
  Last updated: <date>
  Repo: <url>

Install it? (yes/no)
```

**Wait for an explicit "yes" / "sí" / "ok, install it"**. Anything ambiguous → ask again, don't assume.

If the answer is "no" → say "ok, proceeding without it" and continue with general knowledge.

## 4. Install (only after "yes")

1. Clone the source repo to a temp directory (e.g. `/tmp/fact-skill-<random>`).
2. Find the skill's directory inside (it's the directory containing `SKILL.md`).
3. Copy that directory to `.claude/skills/<skill-name>/`.
4. Verify `SKILL.md` exists at the destination.

Implementation note: prefer `git clone --depth=1` and `cp -r`. If anything fails, report the failure clearly and don't leave a half-copied skill behind (`rm -rf` the destination on error).

## 5. Use the skill inline (same session)

You don't need to restart Claude Code:

1. Read `.claude/skills/<skill-name>/SKILL.md` with your file tool.
2. Apply its instructions to the current task.

In future sessions, the skill loads automatically with the others.

## 6. Notify the dashboard

POST to `${FACT_DASHBOARD_URL}/event` with:

```json
{
  "kind": "skill_installed",
  "name": "<skill-name>",
  "source": "<repo url>",
  "timestamp": "<UTC iso>"
}
```

Don't fail the install if the dashboard isn't running — the skill is on disk, that's what matters.

## 7. One skill at a time

If you identify two candidate skills, install one, use it, and only install the second if it's still genuinely needed. Don't bulk-install — each install is a separate user confirmation.
