from __future__ import annotations

import argparse
import json
from pathlib import Path

from .client import NeurovnClient


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="neurovn")
    parser.add_argument("--backend-url", default=None, help="Backend base URL (defaults to NEUROVN_API_URL or localhost)")
    subparsers = parser.add_subparsers(dest="command", required=True)

    trace_parser = subparsers.add_parser("trace", help="Emit a workflow JSON file to the backend trace session API")
    trace_parser.add_argument("workflow_file", type=Path, help="Path to a .json workflow file")
    trace_parser.add_argument("--workflow-name", default=None, help="Workflow name for the trace session")
    trace_parser.add_argument("--canvas-name", default=None, help="Canvas name to create/update")
    trace_parser.add_argument("--source", default="cli", choices=["sdk", "decorator", "cli", "manual"], help="Trace source label")
    trace_parser.add_argument("--backend-url", default=None, help="Backend base URL (defaults to NEUROVN_API_URL or localhost)")
    return parser


def _run_trace(args: argparse.Namespace) -> int:
    payload = json.loads(Path(args.workflow_file).read_text(encoding="utf-8"))
    nodes = payload.get("nodes", [])
    edges = payload.get("edges", [])
    workflow_name = args.workflow_name or payload.get("name") or args.workflow_file.stem

    client = NeurovnClient(base_url=args.backend_url)
    estimation = client.estimate(nodes, edges, recursion_limit=payload.get("recursion_limit", 25))
    trace = client.create_trace_session(
        {
            "source": args.source,
            "workflow_name": workflow_name,
            "canvas_name": args.canvas_name or workflow_name,
            "nodes": nodes,
            "edges": edges,
            "estimation": estimation,
            "metadata": {
                "workflow_file": str(args.workflow_file),
                "entrypoint": "cli",
            },
        }
    )

    canvas_id = trace.get("canvas_id")
    print(json.dumps({
        "workflow_name": workflow_name,
        "canvas_id": canvas_id,
        "trace_session_id": trace.get("id"),
        "estimate_total_cost": estimation.get("total_cost"),
        "estimate_total_latency": estimation.get("total_latency"),
    }, indent=2))
    editor_url = client.editor_url(canvas_id)
    if editor_url:
        print(f"Open: {editor_url}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command == "trace":
        return _run_trace(args)
    parser.error("Unknown command")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
