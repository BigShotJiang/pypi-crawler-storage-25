from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any
from urllib import error, request
from urllib.parse import urlparse

_DEFAULT_API_URL = "http://localhost:8000"
_DEFAULT_HOSTED_APP_URL = "https://neurovn-alpha.vercel.app"


def _normalize_url(value: str | None) -> str | None:
    if not value:
        return None
    return value.rstrip("/")


def _is_local_url(value: str | None) -> bool:
    if not value:
        return False
    hostname = urlparse(value).hostname or ""
    return hostname in {"localhost", "127.0.0.1"}


@dataclass
class NeurovnClient:
    base_url: str | None = None
    app_url: str | None = None
    timeout: float = 15.0

    def __post_init__(self) -> None:
        if not self.base_url:
            self.base_url = os.environ.get("NEUROVN_API_URL") or os.environ.get("NEXT_PUBLIC_API_URL") or _DEFAULT_API_URL
        self.base_url = _normalize_url(self.base_url) or _DEFAULT_API_URL

        if not self.app_url:
            self.app_url = (
                os.environ.get("NEUROVN_APP_URL")
                or os.environ.get("NEUROVN_FRONTEND_URL")
                or os.environ.get("FRONTEND_URL")
            )

        self.app_url = _normalize_url(self.app_url)
        if self.app_url is None:
            if self.base_url == "https://agentic-flow.onrender.com":
                self.app_url = _DEFAULT_HOSTED_APP_URL
            elif _is_local_url(self.base_url):
                self.app_url = self.base_url

    def _post_json(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        data = json.dumps(payload).encode("utf-8")
        req = request.Request(
            f"{self.base_url}{path}",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=self.timeout) as resp:
                body = resp.read().decode("utf-8")
                return json.loads(body) if body else {}
        except error.HTTPError as exc:
            body = exc.read().decode("utf-8")
            raise RuntimeError(body or exc.reason) from exc

    def estimate(self, nodes: list[dict[str, Any]], edges: list[dict[str, Any]], recursion_limit: int = 25) -> dict[str, Any]:
        return self._post_json(
            "/api/estimate",
            {
                "nodes": nodes,
                "edges": edges,
                "recursion_limit": recursion_limit,
            },
        )

    def create_trace_session(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._post_json("/api/traces/sessions", payload)

    def editor_url(self, canvas_id: str | None) -> str | None:
        if not canvas_id:
            return None
        base = self.app_url or self.base_url
        if not base:
            return None
        return f"{base}/editor/{canvas_id}"
