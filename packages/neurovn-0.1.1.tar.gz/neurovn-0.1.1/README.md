# Neurovn SDK

Python SDK and CLI for tracing agentic AI workflows.

## Installation

The package is published on PyPI as `neurovn`.

```bash
python -m venv .venv
source .venv/bin/activate
pip install --upgrade neurovn
```

Verified release: `neurovn==0.1.1`.

If you are contributing from this monorepo and need an editable install:

```bash
cd neurovn-sdk
pip install -e .
```

Point the SDK at the hosted Neurovn backend:

```bash
export NEUROVN_API_URL=https://agentic-flow.onrender.com
```

## Quick Start

### CLI Integration

```bash
NEUROVN_API_URL=https://agentic-flow.onrender.com neurovn trace ./workflow.json --workflow-name "My Workflow" --canvas-name "My Workflow" --source cli
```

Module entrypoint fallback:

```bash
NEUROVN_API_URL=https://agentic-flow.onrender.com python -m neurovn trace ./workflow.json --workflow-name "My Workflow" --canvas-name "My Workflow" --source cli
```

### Decorator Integration

```python
from neurovn import trace

@trace.agent(name="Research Agent", model="gpt-4o", provider="OpenAI")
async def research(query: str):
    response = await openai.chat.completions.create(...)
    return response

@trace.tool(name="Web Search", tool_id="mcp_web_search", tool_category="mcp_server")
async def web_search(query: str) -> str:
    return "search results"

with trace.session("My Workflow", source="decorator", canvas_name="My Workflow"):
    result = await research("latest AI updates")

if trace.last_result:
    print(trace.last_result["canvas_id"])
```

## Features

- **Trace Decorators**: Instrument Python functions with `@trace.agent` and `@trace.tool`
- **CLI**: Emit workflow JSON files to Neurovn backend
- **Session Management**: Group multiple calls into a workflow session and print a terminal summary for explicit sessions
- **Usage Tracking**: Capture token usage from LLM responses

## Documentation

For full integration guides and examples, visit [Neurovn Docs](https://neurovn.com/docs).

## Notes

- External users should install from PyPI. The editable install path is contributor-only.
- `neurovn trace ...` and `python -m neurovn trace ...` are equivalent entrypoints.
- Local trace persistence depends on the backend being reachable and configured with a valid Supabase service-role key.

## License

MIT
