"""Tests for PyPI package structure and installation."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest


def test_package_name_in_pyproject():
    """Verify the package name is 'neurovn' not 'neurovn-sdk'."""
    pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
    content = pyproject_path.read_text()

    # Should contain name = "neurovn"
    assert 'name = "neurovn"' in content, "Package name should be 'neurovn'"

    # Should NOT contain name = "neurovn-sdk"
    assert 'name = "neurovn-sdk"' not in content, "Package name should not be 'neurovn-sdk'"


def test_pyproject_has_required_metadata():
    """Verify pyproject.toml has all required PyPI metadata."""
    pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
    content = pyproject_path.read_text()

    required_fields = [
        'name = "neurovn"',
        'description =',
        'authors =',
        'readme =',
        'requires-python =',
    ]

    for field in required_fields:
        assert field in content, f"Required field '{field}' missing from pyproject.toml"


def test_package_has_cli_entry_point():
    """Verify the package has a CLI entry point configured."""
    pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
    content = pyproject_path.read_text()

    # Should have a [project.scripts] section with neurovn CLI
    assert "[project.scripts]" in content, "Missing [project.scripts] section"
    assert "neurovn" in content, "CLI entry point 'neurovn' not found"


def test_package_imports_work():
    """Verify the package can be imported as 'neurovn'."""
    # Test that we can import the main module
    import neurovn

    # Test that trace is exported
    assert hasattr(neurovn, "trace"), "neurovn module should export 'trace'"


def test_trace_decorator_is_accessible():
    """Verify trace decorator can be imported and used."""
    from neurovn import trace

    # Should have the main methods
    assert hasattr(trace, "agent"), "trace should have 'agent' method"
    assert hasattr(trace, "tool"), "trace should have 'tool' method"
    assert hasattr(trace, "session"), "trace should have 'session' method"


def test_cli_module_exists():
    """Verify the CLI module can be imported."""
    from neurovn import cli

    # Should have the main function
    assert hasattr(cli, "main"), "cli module should have 'main' function"


def test_client_module_exists():
    """Verify the client module can be imported."""
    from neurovn import client

    # Should have the NeurovnClient class
    assert hasattr(client, "NeurovnClient"), "client module should have 'NeurovnClient' class"


def test_package_can_be_invoked_as_module():
    """Verify the package can be invoked as `python -m neurovn`."""
    result = subprocess.run(
        [sys.executable, "-m", "neurovn", "--help"],
        capture_output=True,
        text=True,
        timeout=5,
    )

    assert result.returncode == 0, f"CLI help failed: {result.stderr}"
    assert "usage:" in result.stdout or "trace" in result.stdout.lower(), "Expected help output not found"


def test_package_files_are_included():
    """Verify all necessary Python files are included in the package."""
    neurovn_dir = Path(__file__).parent.parent / "neurovn"

    required_files = [
        "__init__.py",
        "trace.py",
        "cli.py",
        "client.py",
        "__main__.py",
    ]

    for filename in required_files:
        file_path = neurovn_dir / filename
        assert file_path.exists(), f"Required file '{filename}' not found in neurovn package"


def test_package_has_readme():
    """Verify the package has a README file referenced in pyproject.toml."""
    pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
    content = pyproject_path.read_text()

    # Should reference a readme file
    assert 'readme = "' in content or "readme =" in content, "Package should have a readme specified"


@pytest.mark.skipif(
    sys.version_info < (3, 9),
    reason="Python 3.9+ required for this test"
)
def test_minimum_python_version():
    """Verify the package declares Python 3.9+ as minimum."""
    pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
    content = pyproject_path.read_text()

    assert 'requires-python = ">=3.9"' in content, "Package should require Python 3.9+"
