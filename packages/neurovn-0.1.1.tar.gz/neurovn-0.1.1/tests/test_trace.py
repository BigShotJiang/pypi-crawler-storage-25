from __future__ import annotations

import asyncio
import json
from pathlib import Path
import warnings

from neurovn import trace
from neurovn.cli import main


class DummyClient:
    def __init__(self):
        self.estimated = None
        self.session = None

    def estimate(self, nodes, edges, recursion_limit=25):
        self.estimated = {"nodes": nodes, "edges": edges, "recursion_limit": recursion_limit}
        return {"total_cost": 1.23, "total_latency": 4.56}

    def create_trace_session(self, payload):
        self.session = payload
        return {"id": "trace-123", "canvas_id": "canvas-123", **payload}

    def editor_url(self, canvas_id):
        if not canvas_id:
            return None
        return f"https://neurovn-alpha.vercel.app/editor/{canvas_id}"


class DummyUsage:
    def __init__(self, prompt_tokens: int, completion_tokens: int):
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens
        self.total_tokens = prompt_tokens + completion_tokens


class DummyLLMResponse:
    def __init__(self, prompt_tokens: int, completion_tokens: int):
        self.usage = DummyUsage(prompt_tokens, completion_tokens)

    def __repr__(self) -> str:
        return "DummyLLMResponse()"


class FailingClient(DummyClient):
    def create_trace_session(self, payload):
        self.session = payload
        raise RuntimeError("backend unavailable")


async def _run_decorated_flow():
    dummy = DummyClient()
    original_client = trace.client
    trace.client = dummy

    try:
        @trace.agent(name="Research Agent", model="gpt-4o")
        async def research(query: str) -> str:
            return f"answer:{query}"

        @trace.tool(name="Web Search", tool_id="mcp_web_search", tool_category="mcp_server")
        async def web_search(query: str) -> str:
            return f"results:{query}"

        async with trace.session("Research Run", source="sdk", canvas_name="Research Canvas"):
            result = await research("neurovn")
            assert result == "answer:neurovn"
            tool_result = await web_search("neurovn")
            assert tool_result == "results:neurovn"

        return dummy
    finally:
        trace.client = original_client


def test_agent_and_tool_decorators_emit_trace_graph(monkeypatch, capsys):
    dummy = DummyClient()
    original_client = trace.client
    trace.client = dummy
    trace.last_result = None
    monkeypatch.setenv("NEUROVN_APP_URL", "https://neurovn-alpha.vercel.app")

    @trace.agent(name="Research Agent", model="gpt-4o")
    async def research(query: str) -> str:
        return f"answer:{query}"

    @trace.tool(name="Web Search", tool_id="mcp_web_search", tool_category="mcp_server")
    async def web_search(query: str) -> str:
        return f"results:{query}"

    async def run_flow():
        async with trace.session("Research Run", source="sdk", canvas_name="Research Canvas"):
            result = await research("neurovn")
            assert result == "answer:neurovn"
            tool_result = await web_search("neurovn")
            assert tool_result == "results:neurovn"

    try:
        asyncio.run(run_flow())
    finally:
        trace.client = original_client

    assert dummy.estimated is not None
    assert dummy.session is not None
    assert trace.last_result is not None
    assert trace.last_result["canvas_id"] == "canvas-123"
    assert dummy.session["workflow_name"] == "Research Run"
    assert dummy.session["canvas_name"] == "Research Canvas"
    assert dummy.session["source"] == "sdk"
    node_types = [node["type"] for node in dummy.session["nodes"]]
    assert "startNode" in node_types
    assert "agentNode" in node_types
    assert "toolNode" in node_types
    assert "finishNode" in node_types
    assert any(edge["source"] == "start" for edge in dummy.session["edges"])
    assert any(edge["target"] == "finish" for edge in dummy.session["edges"])
    output = capsys.readouterr().out
    assert '"canvas_id": "canvas-123"' in output
    assert "Open: https://neurovn-alpha.vercel.app/editor/canvas-123" in output


def test_cli_trace_command_emits_file_workflow(tmp_path: Path, monkeypatch, capsys):
    dummy = DummyClient()
    monkeypatch.setattr("neurovn.cli.NeurovnClient", lambda base_url=None: dummy)
    monkeypatch.setenv("NEUROVN_APP_URL", "https://neurovn-alpha.vercel.app")

    workflow = {
        "name": "CLI Workflow",
        "nodes": [
            {"id": "start", "type": "startNode", "label": "Start"},
            {"id": "agent", "type": "agentNode", "label": "Agent", "model_provider": "OpenAI", "model_name": "GPT-4o", "context": "hello"},
            {"id": "finish", "type": "finishNode", "label": "Finish"},
        ],
        "edges": [
            {"source": "start", "target": "agent"},
            {"source": "agent", "target": "finish"},
        ],
    }
    workflow_file = tmp_path / "workflow.json"
    workflow_file.write_text(json.dumps(workflow), encoding="utf-8")

    exit_code = main(["trace", str(workflow_file), "--workflow-name", "CLI Workflow", "--canvas-name", "CLI Canvas", "--backend-url", "http://localhost:8000"])
    assert exit_code == 0
    assert dummy.session is not None
    assert dummy.session["workflow_name"] == "CLI Workflow"
    assert dummy.session["canvas_name"] == "CLI Canvas"
    output = capsys.readouterr().out
    assert '"canvas_id": "canvas-123"' in output
    assert "Open: https://neurovn-alpha.vercel.app/editor/canvas-123" in output


def test_agent_decorator_captures_usage_metadata():
    dummy = DummyClient()
    original_client = trace.client
    trace.client = dummy

    @trace.agent(name="Usage Agent", model="gpt-4o")
    async def usage_agent(_query: str):
        return DummyLLMResponse(prompt_tokens=321, completion_tokens=123)

    async def run_flow():
        async with trace.session("Usage Session", source="sdk", canvas_name="Usage Canvas"):
            await usage_agent("hello")

    try:
        asyncio.run(run_flow())
    finally:
        trace.client = original_client

    assert dummy.session is not None
    metadata = dummy.session.get("metadata", {})
    usage_map = metadata.get("actual_usage", {})
    assert usage_map

    usage_entry = next(iter(usage_map.values()))
    assert usage_entry["prompt_tokens"] == 321
    assert usage_entry["completion_tokens"] == 123
    assert usage_entry["total_tokens"] == 444


def test_implicit_decorator_session_does_not_announce(monkeypatch, capsys):
    dummy = DummyClient()
    original_client = trace.client
    trace.client = dummy
    trace.last_result = None
    monkeypatch.setenv("NEUROVN_APP_URL", "https://neurovn-alpha.vercel.app")

    @trace.agent(name="Planner", model="gpt-4o")
    def planner(query: str) -> str:
        return f"planned:{query}"

    try:
        result = planner("hello")
    finally:
        trace.client = original_client

    assert result == "planned:hello"
    assert trace.last_result is not None
    assert capsys.readouterr().out == ""


def test_backend_failure_warns_without_suppressing_result():
    failing = FailingClient()
    original_client = trace.client
    trace.client = failing
    trace.last_result = None

    @trace.agent(name="Planner", model="gpt-4o")
    def planner(query: str) -> str:
        return f"planned:{query}"

    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            result = planner("hello")
    finally:
        trace.client = original_client

    assert result == "planned:hello"
    assert trace.last_result is None
    assert any("Failed to persist trace session" in str(item.message) for item in caught)
