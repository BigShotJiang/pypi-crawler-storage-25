"""PE operations tools — protection domains and tasks."""

from nutanix_mcp.app import mcp
from nutanix_mcp.client import pe_get
from nutanix_mcp.registry import json_response, resolve_cluster


@mcp.tool()
def list_protection_domains(cluster_name=None, limit: int = 50, page: int = 1) -> str:
    """
    List protection domains (DR / backup configurations) in a Prism Element cluster.

    Returns each protection domain's name, type, active/standby state,
    and associated VMs or volume groups.

    Args:
        cluster_name: Name from inventory.yaml. Omit to use the default cluster.
        limit: Maximum number of results to return (default 50).
        page: Page number for pagination (1-based).
    """
    return json_response(pe_get("/protection_domains/", {"count": limit, "page": page}, **resolve_cluster(cluster_name)))


@mcp.tool()
def list_tasks(cluster_name=None, limit: int = 50, include_completed: bool = False) -> str:
    """
    List recent tasks on a Prism Element cluster.

    Returns each task's UUID, type, status (Running/Succeeded/Failed),
    progress percentage, start time, and completion time.

    Args:
        cluster_name: Name from inventory.yaml. Omit to use the default cluster.
        limit: Maximum number of results to return (default 50).
        include_completed: Include completed/failed tasks in addition to running ones (default False).
    """
    # v2.0 /tasks/ is not available on AOS 6.x; use the v0.8 ergon endpoint.
    # Note: v0.8 uses camelCase params and 'grandTotalEntities' in metadata.
    params = {"count": limit, "includeCompleted": str(include_completed).lower()}
    if not include_completed:
        params["filterCriteria"] = "status!=kSucceeded;status!=kFailed;status!=kAborted"
    return json_response(pe_get("/tasks", params, base_path="/api/nutanix/v0.8", **resolve_cluster(cluster_name)))
