"""
================================================================================
📦 ПОМОЩНИК ДЛЯ PYTHON (help_manager.py)
================================================================================
Всё в одном файле: голос, базы данных, музыка, парсинг, автоматизация и ИИ.
Автор: Юсуф
================================================================================
"""

# =============================================================================
# ВСТРОЕННЫЕ МОДУЛИ (лёгкие, импортируем сразу)
# =============================================================================
import os
import sys
import time
import random
import functools
import threading
import json
from datetime import datetime
import socket
import subprocess
import webbrowser
import tempfile
import sqlite3
import math
import statistics
import string
from typing import Any, Callable, Optional, Tuple, List, Union
from urllib.parse import quote
import shutil

# =============================================================================
# КЛАСС Manager – 30+ УНИВЕРСАЛЬНЫХ ФУНКЦИЙ
# =============================================================================
class Manager:
    """
    ⚡ СТАТИЧЕСКИЕ МЕТОДЫ — вызывай напрямую без создания объекта:
       Manager.название_функции()

    🎯 Возможности класса:
        - Парсинг веб-страниц и получение погоды
        - Голосовой ввод и озвучка текста
        - Воспроизведение музыки и звуковые сигналы
        - Работа с файлами и JSON
        - Время и дата в любом формате
        - Генерация случайных чисел и выбор случайных элементов
        - Проверка интернета и скачивание файлов
        - Очистка консоли и задержки
        - Поиск и открытие видео на YouTube
    """

    # ------------------------------ 🌐 ПАРСИНГ И ПОГОДА ------------------------------
    @staticmethod
    def get_text_with_url(url, class_name):
        """
        🔍 ПАРСИНГ: Извлекает текст элемента по CSS-классу со страницы.

        Параметры:
            url (str): полный URL страницы (например, "https://example.com")
            class_name (str): имя CSS-класса, содержимое которого нужно извлечь

        Возвращает:
            str: текст элемента или сообщение об ошибке

        📝 Пример:
            text = Manager.get_text_with_url("https://example.com", "article__title")
            print(text)  # Заголовок статьи

        🎯 Возможности:
            - Извлечение цен, названий, описаний с сайтов
            - Сбор информации для ботов и парсеров
        """
        import requests
        from bs4 import BeautifulSoup

        try:
            encoded_url = quote(url, safe=':/?&=')
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
            response = requests.get(encoded_url, headers=headers, timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.content, 'html.parser')
            element = soup.find(class_=class_name)
            return element.text.strip() if element else f"❌ Класс '{class_name}' не найден"
        except Exception as e:
            return f"❌ Ошибка: {e}"

    @staticmethod
    def get_weather(city="Москва", api="28c9d95c5e0b423d23e81c1d43c10cf0"):
        """
        ☁️ ПОГОДА: Возвращает словарь с температурой, ветром, влажностью.

        Параметры:
            city (str): название города (по умолчанию "Москва")
            api (str): API-ключ OpenWeatherMap (встроен запасной)

        Возвращает:
            dict: словарь с ключами "Температура", "Ощущается", "Описание",
                  "Влажность", "Ветер" или строку с ошибкой

        📝 Пример:
            weather = Manager.get_weather("Москва")
            print(weather["Температура"])  # +15 °C
            print(weather["Влажность"])    # 65 %

        🎯 Возможности:
            - Прогноз для любого города мира
            - Можно встроить в голосового ассистента
            - Автоматические уведомления о погоде
        """
        import requests

        url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api}&units=metric&lang=ru"
        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            data = response.json()
            return {
                "Температура": f"{round(data['main']['temp'])} °C",
                "Ощущается": f"{round(data['main']['feels_like'])} °C",
                "Описание": data['weather'][0]['description'],
                "Влажность": f"{data['main']['humidity']} %",
                "Ветер": f"{data['wind']['speed']} м/с"
            }
        except Exception as e:
            return f"❌ Ошибка погоды: {e}"

    # ------------------------------ 🎙️ ГОЛОС И ЗВУК ------------------------------
    @staticmethod
    def listen_text(seconds=5):
        """
        🎤 ГОЛОСОВОЙ ВВОД: Слушает микрофон и возвращает распознанный текст.

        Параметры:
            seconds (int): сколько секунд слушать (по умолчанию 5)

        Возвращает:
            str: распознанный текст или пустую строку, если ничего не услышано

        📝 Пример:
            command = Manager.listen_text(5)
            if command:
                print(f"Вы сказали: {command}")
            else:
                print("Ничего не услышано")

        🎯 Возможности:
            - Голосовое управление ботом
            - Команды для ассистента
            - Распознавание русского языка
            - Автоматическая настройка шумоподавления
        """
        import speech_recognition as sr

        r = sr.Recognizer()
        try:
            with sr.Microphone() as source:
                r.adjust_for_ambient_noise(source)
                audio = r.listen(source, timeout=seconds, phrase_time_limit=seconds)
            return r.recognize_google(audio, language="ru-RU")
        except:
            return ""

    @staticmethod
    def say(text, lang='ru'):
        """
        🔊 ОЗВУЧКА: Превращает текст в речь с помощью Google TTS.

        Параметры:
            text (str): текст для озвучки
            lang (str): язык ('ru' — русский, 'en' — английский)

        📝 Пример:
            Manager.say("Привет, я твой помощник!")
            Manager.say("Hello, I am your assistant!", lang='en')

        🎯 Возможности:
            - Голосовые подсказки и приветствия
            - Озвучка уведомлений
            - Поддержка множества языков
            - Автоматическое удаление временных файлов
        """
        from gtts import gTTS
        from pydub import AudioSegment
        from pydub.playback import play

        temp_file = None
        try:
            with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as fp:
                temp_file = fp.name
            tts = gTTS(text=text, lang=lang)
            tts.save(temp_file)
            sound = AudioSegment.from_mp3(temp_file)
            play(sound)
        finally:
            if temp_file and os.path.exists(temp_file):
                os.unlink(temp_file)

    @staticmethod
    def play_music(file_path):
        """
        🎵 МУЗЫКА: Воспроизводит аудиофайл (MP3, WAV, OGG) и ждёт окончания.

        Параметры:
            file_path (str): полный путь к аудиофайлу

        📝 Пример:
            Manager.play_music("C:/Music/song.mp3")
            Manager.play_music("background.wav")

        🎯 Возможности:
            - Фоновое воспроизведение музыки
            - Поддержка основных аудиоформатов (MP3, WAV, OGG)
            - Блокирует выполнение до окончания трека
        """
        import pygame

        try:
            pygame.mixer.init()
            pygame.mixer.music.load(file_path)
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                time.sleep(0.1)
        except Exception as e:
            print(f"❌ Ошибка воспроизведения: {e}")

    # ------------------------------ 📂 ФАЙЛЫ И ПУТИ ------------------------------
    @staticmethod
    def search_file_path(relative_path):
        """
        📁 ПОИСК ФАЙЛА: Возвращает полный путь к файлу относительно папки скрипта.

        Параметры:
            relative_path (str): относительный путь к файлу (например, "config.json")

        Возвращает:
            str: полный абсолютный путь к файлу

        📝 Пример:
            full_path = Manager.search_file_path("config.json")
            # Вернёт что-то вроде: C:\\Users\\Yusuf\\Programming\\Пайтон\\projects\\config.json

        🎯 Возможности:
            - Удобная работа с файлами в проекте
            - Не нужно прописывать длинные абсолютные пути
            - Кроссплатформенность (Windows/Linux/Mac)
        """
        base = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(base, relative_path)

    @staticmethod
    def open_file(relative_path):
        """
        🚀 ЗАПУСК ФАЙЛА: Открывает Python-скрипт в новом окне консоли.

        Параметры:
            relative_path (str): путь к Python-файлу относительно папки скрипта

        📝 Пример:
            Manager.open_file("bot.py")
            Manager.open_file("utils/helper.py")

        🎯 Возможности:
            - Запуск модулей из главного скрипта
            - Параллельная работа нескольких программ
            - Новое окно консоли для каждого запуска
        """
        full = Manager.search_file_path(relative_path)
        os.system(f'start cmd /k python "{full}"')

    @staticmethod
    def search_and_open_youtube(query, max_results=1):
        """
        🔍 ОТКРЫТЬ ВИДЕО НА YOUTUBE: Ищет видео по запросу и открывает в браузере.

        Параметры:
            query (str): строка для поиска (название песни, видео и т.д.)
            max_results (int): сколько результатов искать (по умолчанию 1)

        Возвращает:
            str или False: URL открытого видео или False, если ничего не найдено

        📝 Пример:
            url = Manager.search_and_open_youtube("Morgenshtern Cadillac")
            if url:
                print(f"Открыто: {url}")

        🎯 Возможности:
            - Быстрый доступ к музыке и видео
            - Можно использовать в голосовом ассистенте
        """
        from youtube_search import YoutubeSearch

        results = YoutubeSearch(query, max_results=max_results).to_dict()
        if results:
            video_url = f"https://youtube.com{results[0]['url_suffix']}"
            webbrowser.open(video_url)
            return video_url
        return False

    @staticmethod
    def load_json(relative_path):
        """
        📂 ЗАГРУЗКА JSON: Читает JSON-файл и возвращает словарь.

        Параметры:
            relative_path (str): путь к JSON-файлу относительно папки скрипта

        Возвращает:
            dict или None: содержимое JSON-файла в виде словаря, или None при ошибке

        📝 Пример:
            data = Manager.load_json("settings.json")
            if data:
                print(data["theme"])  # "dark"
                print(data["volume"])  # 80

        🎯 Возможности:
            - Хранение настроек приложения
            - Сохранение данных бота
            - Чтение конфигурационных файлов
        """
        full = Manager.search_file_path(relative_path)
        try:
            with open(full, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"❌ Ошибка загрузки JSON: {e}")
            return None

    @staticmethod
    def save_json(relative_path, data, mode="w"):
        """
        💾 СОХРАНЕНИЕ JSON: Записывает данные в JSON-файл.

        Параметры:
            relative_path (str): путь к JSON-файлу относительно папки скрипта
            data (dict): данные для сохранения
            mode (str): режим записи ("w" — перезапись, "a" — добавление)

        Возвращает:
            bool: True при успехе, False при ошибке

        📝 Пример:
            settings = {"theme": "dark", "volume": 80}
            Manager.save_json("settings.json", settings)
            print("Настройки сохранены!")

        🎯 Возможности:
            - Сохранение прогресса игрока
            - Экспорт данных
            - Создание резервных копий
        """
        full = Manager.search_file_path(relative_path)
        try:
            with open(full, mode, encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
            return True
        except Exception as e:
            print(f"❌ Ошибка сохранения JSON: {e}")
            return False

    # ------------------------------ ⏰ ВРЕМЯ И ДАТА ------------------------------
    @staticmethod
    def now(format="%Y-%m-%d %H:%M:%S"):
        """
        🕐 ТЕКУЩЕЕ ВРЕМЯ: Возвращает дату и время в нужном формате.

        Параметры:
            format (str): формат даты/времени (по умолчанию "ГГГГ-ММ-ДД ЧЧ:ММ:СС")

        Возвращает:
            str: отформатированная строка с текущим временем

        📝 Пример:
            print(Manager.now())          # 2026-04-03 15:30:00
            print(Manager.now("%H:%M"))   # 15:30
            print(Manager.now("%d.%m.%Y"))  # 03.04.2026

        🎯 Возможности:
            - Логирование событий с временными метками
            - Отображение времени в интерфейсе
            - Создание уникальных имён файлов
        """
        return datetime.now().strftime(format)

    @staticmethod
    def today():
        """
        📅 СЕГОДНЯШНЯЯ ДАТА: Возвращает строку в формате ГГГГ-ММ-ДД.

        Возвращает:
            str: сегодняшняя дата (например, "2026-04-03")

        📝 Пример:
            date = Manager.today()
            print(f"Сегодня: {date}")  # Сегодня: 2026-04-03

            # Использование в имени файла
            backup_name = f"backup_{Manager.today()}.json"
            Manager.save_json(backup_name, data)

        🎯 Возможности:
            - Формирование ежедневных отчётов
            - Именование бэкапов по дате
            - Проверка актуальности данных
        """
        return datetime.now().strftime("%Y-%m-%d")

    # ------------------------------ 🎲 СЛУЧАЙНОСТИ ------------------------------
    @staticmethod
    def randint(a, b):
        """
        🎲 СЛУЧАЙНОЕ ЧИСЛО: Возвращает случайное целое число в диапазоне от a до b (включительно).

        Параметры:
            a (int): нижняя граница диапазона
            b (int): верхняя граница диапазона

        Возвращает:
            int: случайное целое число

        📝 Пример:
            dice = Manager.randint(1, 6)
            print(f"На кубике выпало: {dice}")

            bonus = Manager.randint(10, 50)
            print(f"Случайный бонус: +{bonus} золота")

        🎯 Возможности:
            - Генерация бонусов в игре
            - Создание случайных паролей
            - Случайные задержки в автоматизации
        """
        return random.randint(a, b)

    @staticmethod
    def choice(seq):
        """
        🎲 СЛУЧАЙНЫЙ ВЫБОР: Возвращает случайный элемент из последовательности.

        Параметры:
            seq (list/tuple/str): последовательность элементов

        Возвращает:
            любой тип: случайный элемент из последовательности

        📝 Пример:
            fruit = Manager.choice(["яблоко", "банан", "груша"])
            print(f"Сегодня едим: {fruit}")

            # Случайный ответ бота
            answers = ["Привет!", "Здравствуй!", "Рад тебя видеть!"]
            greeting = Manager.choice(answers)

        🎯 Возможности:
            - Случайные ответы бота
            - Выбор случайного задания или уровня
            - Разнообразие в автоматических сообщениях
        """
        return random.choice(seq)

    # ------------------------------ 🌐 СЕТЬ ------------------------------
    @staticmethod
    def is_connected():
        """
        🌐 ПРОВЕРКА ИНТЕРНЕТА: Проверяет наличие интернет-соединения.

        Возвращает:
            bool: True если интернет есть, False если нет

        📝 Пример:
            if Manager.is_connected():
                weather = Manager.get_weather("Москва")
                print(weather)
            else:
                print("Нет интернета, работаем офлайн")

        🎯 Возможности:
            - Проверка перед API-запросами
            - Переключение в офлайн-режим
            - Диагностика сетевых проблем
        """
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except:
            return False

    @staticmethod
    def download_file(url, save_path):
        """
        📥 СКАЧИВАНИЕ ФАЙЛА: Загружает файл из интернета и сохраняет локально.

        Параметры:
            url (str): прямая ссылка на файл
            save_path (str): путь для сохранения относительно папки скрипта

        Возвращает:
            bool: True при успешном скачивании, False при ошибке

        📝 Пример:
            success = Manager.download_file(
                "https://site.com/photo.jpg",
                "images/photo.jpg"
            )
            if success:
                print("Файл скачан!")

        🎯 Возможности:
            - Обновление данных бота
            - Скачивание обновлений программы
            - Сохранение изображений и документов
        """
        import requests

        try:
            response = requests.get(url, stream=True, timeout=15)
            response.raise_for_status()
            full = Manager.search_file_path(save_path)
            with open(full, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            return True
        except Exception as e:
            print(f"❌ Ошибка скачивания: {e}")
            return False

    # ------------------------------ 🛠️ ПРОЧЕЕ ------------------------------
    @staticmethod
    def clear_console():
        """
        🧹 ОЧИСТКА КОНСОЛИ: Очищает экран терминала.

        📝 Пример:
            Manager.clear_console()
            print("Новый чистый вывод!")

        🎯 Возможности:
            - Красивый интерфейс командной строки
            - Скрытие старых сообщений
            - Подготовка к новому выводу
        """
        os.system('cls' if os.name == 'nt' else 'clear')

    @staticmethod
    def wait(seconds, message="Ждём..."):
        """
        ⏳ ЗАДЕРЖКА: Пауза на указанное время с отображением сообщения.

        Параметры:
            seconds (int/float): время задержки в секундах
            message (str): сообщение, которое будет показано на время ожидания

        📝 Пример:
            Manager.wait(3, "Загрузка данных...")
            print("Готово!")

            Manager.wait(1.5)  # просто подождать полторы секунды

        🎯 Возможности:
            - Паузы между действиями в автоматизации
            - Ожидание загрузки данных
            - Таймеры обратного отсчёта
        """
        print(message)
        time.sleep(seconds)

    @staticmethod
    def beep(Gh=1000, time=500):
        """
        🔊 СИГНАЛ: Издаёт системный звуковой сигнал.

        Параметры:
            Gh (int): частота звука в Герцах (по умолчанию 1000)
            time (int): длительность в миллисекундах (по умолчанию 500)

        📝 Пример:
            Manager.beep(1000, 500)  # звук 1000 Гц длительностью 500 мс
            Manager.beep(500, 200)   # низкий короткий сигнал
            Manager.beep(2000, 1000)  # высокий длинный сигнал

        🎯 Возможности:
            - Звуковые уведомления об ошибках
            - Сигналы о завершении длительных операций
            - Звуковая обратная связь в программах
        """
        from winsound import Beep

        try:
            Beep(Gh, time)
        except:
            print("❌ Не удалось воспроизвести звуковой сигнал")

# =============================================================================
# КЛАСС GigaChat – ИИ ОТ СБЕРБАНКА ДЛЯ ЧИСТКИ РЕЧИ И ОБЩЕНИЯ
# =============================================================================
class GigaChat:
    def __init__(self, client_id: str, client_secret: str, verify_ssl: bool = False):
        self.client_id = client_id
        self.client_secret = client_secret
        self.verify_ssl = verify_ssl
        self._token = None

    def _get_token(self):
        import base64
        import uuid
        from urllib.parse import urlencode
        import requests
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        credentials = f"{self.client_id}:{self.client_secret}"
        encoded = base64.b64encode(credentials.encode()).decode()
        url = "https://ngw.devices.sberbank.ru:9443/api/v2/oauth"
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
            "Authorization": f"Basic {encoded}",
            "RqUID": str(uuid.uuid4()),
        }
        data = {"scope": "GIGACHAT_API_PERS"}

        resp = requests.post(url, headers=headers, data=urlencode(data),
                             verify=self.verify_ssl, timeout=30)
        if resp.status_code == 200:
            self._token = resp.json().get("access_token")
        else:
            raise Exception(f"Token error {resp.status_code}: {resp.text}")

    def chat(self, user_text: str, system_text: str = "",
             temperature: float = 0.7, max_tokens: int = 500) -> str:
        import requests
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        if not self._token:
            self._get_token()

        messages = []
        if system_text:
            messages.append({"role": "system", "content": system_text})
        messages.append({"role": "user", "content": user_text})

        url = "https://gigachat.devices.sberbank.ru/api/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._token}"
        }
        payload = {
            "model": "GigaChat",
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens
        }

        resp = requests.post(url, headers=headers, json=payload,
                             verify=self.verify_ssl, timeout=30)
        if resp.status_code == 200:
            return resp.json()["choices"][0]["message"]["content"]
        else:
            raise Exception(f"GigaChat API error {resp.status_code}: {resp.text}")

    def clean_speech(self, raw_text: str) -> str:
        """
        Очищает сырую речь от заиканий, слов-паразитов и шума микрофона.
        Возвращает грамматически правильный текст.
        """
        system_prompt = """
            Ты — аудио-корректор. Получив текст, который может содержать:
            - запинки и заикания («э-э-э», «ну-у-у»),
            - слова-паразиты («вот», «короче», «типа»),
            - ошибки распознавания речи (шум микрофона).

            Верни ТОЛЬКО чистый, грамматически правильный русский текст.
            Не добавляй ничего от себя.
            """
        return self.chat(
            user_text=raw_text,
            system_text=system_prompt,
            temperature=0.2,
            max_tokens=200
        )

# =============================================================================
# КЛАСС FolderUtils – РАБОТА С ПАПКАМИ И ФАЙЛОВОЙ СИСТЕМОЙ
# =============================================================================
class FolderUtils:
    """
    📁 РАБОТА С ПАПКАМИ: создание, перемещение, поиск, информация.

    📝 Примеры:
        # Создать папку
        FolderUtils.create("my_project/scripts")

        # Переместить файл
        FolderUtils.move("old.txt", "archive/old.txt")

        # Найти все Python-файлы
        py_files = FolderUtils.find_files(".", ".py")

        # Получить имя файла из пути
        name = FolderUtils.get_filename("C:/Users/file.txt")  # "file.txt"

        # Текущая директория
        print(FolderUtils.current_dir())

        # Размер папки
        size = FolderUtils.get_size("my_project")  # в байтах

    🎯 Возможности:
        - Создание и удаление папок
        - Перемещение и копирование файлов/папок
        - Поиск файлов по расширению
        - Получение информации о файлах и папках
        - Работа с путями
    """

    @staticmethod
    def create(path):
        """
        📂 СОЗДАТЬ ПАПКУ: Создаёт папку (и все промежуточные, если нужно).

        Параметры:
            path (str): путь к создаваемой папке

        Возвращает:
            bool: True если создана, False если уже существует

        📝 Пример:
            FolderUtils.create("my_project/data")
            FolderUtils.create("backups/2024/январь")
        """
        import os
        if not os.path.exists(path):
            os.makedirs(path)
            print(f"📂 Папка создана: {path}")
            return True
        else:
            print(f"📂 Папка уже существует: {path}")
            return False

    @staticmethod
    def delete(path):
        """
        🗑️ УДАЛИТЬ ПАПКУ: Удаляет папку со всем содержимым (осторожно!).

        Параметры:
            path (str): путь к папке

        Возвращает:
            bool: True если удалена, False если ошибка

        📝 Пример:
            FolderUtils.delete("temp_files")
        """
        import shutil
        try:
            if os.path.exists(path):
                shutil.rmtree(path)
                print(f"🗑️ Папка удалена: {path}")
                return True
            else:
                print(f"❌ Папка не найдена: {path}")
                return False
        except Exception as e:
            print(f"❌ Ошибка удаления: {e}")
            return False

    @staticmethod
    def move(src, dst):
        """
        📦 ПЕРЕМЕСТИТЬ: Перемещает файл или папку в новое место.

        Параметры:
            src (str): исходный путь
            dst (str): путь назначения

        Возвращает:
            bool: True при успехе

        📝 Пример:
            FolderUtils.move("old_file.txt", "archive/old_file.txt")
            FolderUtils.move("my_folder", "backup/my_folder")
        """
        import shutil
        try:
            shutil.move(src, dst)
            print(f"📦 Перемещено: {src} → {dst}")
            return True
        except Exception as e:
            print(f"❌ Ошибка перемещения: {e}")
            return False

    @staticmethod
    def copy(src, dst):
        """
        📋 КОПИРОВАТЬ: Копирует файл или папку.

        Параметры:
            src (str): исходный путь
            dst (str): путь назначения

        Возвращает:
            bool: True при успехе

        📝 Пример:
            FolderUtils.copy("config.json", "backup/config.json")
        """
        import shutil
        try:
            if os.path.isdir(src):
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
            print(f"📋 Скопировано: {src} → {dst}")
            return True
        except Exception as e:
            print(f"❌ Ошибка копирования: {e}")
            return False

    @staticmethod
    def find_files(directory, extension=None):
        """
        🔍 НАЙТИ ФАЙЛЫ: Ищет все файлы в папке (и подпапках).

        Параметры:
            directory (str): папка для поиска
            extension (str, optional): фильтр по расширению (например, ".py", ".txt")

        Возвращает:
            list[str]: список полных путей к найденным файлам

        📝 Пример:
            # Все файлы
            all_files = FolderUtils.find_files("my_project")

            # Только Python-файлы
            py_files = FolderUtils.find_files("my_project", ".py")

            # Только текстовые
            txt_files = FolderUtils.find_files("my_project", ".txt")
        """
        import os
        result = []
        for root, dirs, files in os.walk(directory):
            for file in files:
                if extension is None or file.endswith(extension):
                    result.append(os.path.join(root, file))
        print(f"🔍 Найдено {len(result)} файлов" + (f" с расширением {extension}" if extension else ""))
        return result

    @staticmethod
    def find_folders(directory):
        """
        📁 НАЙТИ ПАПКИ: Возвращает список всех подпапок.

        Параметры:
            directory (str): папка для поиска

        Возвращает:
            list[str]: список путей к подпапкам

        📝 Пример:
            folders = FolderUtils.find_folders("my_project")
            for folder in folders:
                print(folder)
        """
        import os
        result = []
        for root, dirs, files in os.walk(directory):
            for d in dirs:
                result.append(os.path.join(root, d))
        print(f"📁 Найдено {len(result)} подпапок")
        return result

    @staticmethod
    def current_dir():
        """
        📍 ТЕКУЩАЯ ПАПКА: Возвращает путь к текущей рабочей директории.

        Возвращает:
            str: полный путь

        📝 Пример:
            where_am_i = FolderUtils.current_dir()
            print(f"Скрипт запущен из: {where_am_i}")
        """
        import os
        return os.getcwd()

    @staticmethod
    def get_filename(path):
        """
        📄 ИМЯ ФАЙЛА: Извлекает имя файла из полного пути.

        Параметры:
            path (str): полный путь к файлу

        Возвращает:
            str: имя файла с расширением

        📝 Пример:
            name = FolderUtils.get_filename("C:/Users/Yusuf/doc.txt")  # "doc.txt"
            name = FolderUtils.get_filename("/home/user/file.py")      # "file.py"
        """
        import os
        return os.path.basename(path)

    @staticmethod
    def get_extension(path):
        """
        🔤 РАСШИРЕНИЕ ФАЙЛА: Извлекает расширение файла.

        Параметры:
            path (str): путь к файлу

        Возвращает:
            str: расширение с точкой (например, ".txt", ".py")

        📝 Пример:
            ext = FolderUtils.get_extension("photo.jpg")  # ".jpg"
            ext = FolderUtils.get_extension("script.py")  # ".py"
        """
        import os
        return os.path.splitext(path)[1]

    @staticmethod
    def get_filename_without_ext(path):
        """
        📄 ИМЯ БЕЗ РАСШИРЕНИЯ: Извлекает имя файла без расширения.

        Параметры:
            path (str): путь к файлу

        Возвращает:
            str: имя файла без расширения

        📝 Пример:
            name = FolderUtils.get_filename_without_ext("photo.jpg")  # "photo"
            name = FolderUtils.get_filename_without_ext("script.py")  # "script"
        """
        import os
        return os.path.splitext(os.path.basename(path))[0]

    @staticmethod
    def get_parent(path):
        """
        📂 РОДИТЕЛЬСКАЯ ПАПКА: Возвращает путь к родительской папке.

        Параметры:
            path (str): путь к файлу или папке

        Возвращает:
            str: путь к родительской папке

        📝 Пример:
            parent = FolderUtils.get_parent("C:/Users/Yusuf/doc.txt")  # "C:/Users/Yusuf"
            parent = FolderUtils.get_parent("/home/user/projects")     # "/home/user"
        """
        import os
        return os.path.dirname(path)

    @staticmethod
    def get_size(path):
        """
        📏 РАЗМЕР: Вычисляет размер файла или папки (всего содержимого).

        Параметры:
            path (str): путь к файлу или папке

        Возвращает:
            int: размер в байтах

        📝 Пример:
            size_bytes = FolderUtils.get_size("my_project")
            size_mb = size_bytes / (1024 * 1024)
            print(f"Размер проекта: {size_mb:.2f} MB")
        """
        import os
        total = 0
        if os.path.isfile(path):
            return os.path.getsize(path)
        elif os.path.isdir(path):
            for root, dirs, files in os.walk(path):
                for f in files:
                    fp = os.path.join(root, f)
                    if os.path.exists(fp):
                        total += os.path.getsize(fp)
        return total

    @staticmethod
    def format_size(size_bytes):
        """
        📊 ФОРМАТИРОВАТЬ РАЗМЕР: Превращает байты в читаемую строку.

        Параметры:
            size_bytes (int): размер в байтах

        Возвращает:
            str: читаемая строка (например, "2.5 MB")

        📝 Пример:
            size = FolderUtils.get_size("my_project")
            print(FolderUtils.format_size(size))  # "145.3 MB"
        """
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f} PB"

    @staticmethod
    def exists(path):
        """
        ❓ СУЩЕСТВУЕТ?: Проверяет, существует ли файл или папка.

        Параметры:
            path (str): путь для проверки

        Возвращает:
            bool: True если существует

        📝 Пример:
            if FolderUtils.exists("config.json"):
                print("Конфиг найден!")
            else:
                print("Конфиг отсутствует")
        """
        import os
        return os.path.exists(path)

    @staticmethod
    def is_file(path):
        """
        📄 ЭТО ФАЙЛ?: Проверяет, является ли путь файлом.

        Параметры:
            path (str): путь для проверки

        Возвращает:
            bool: True если это файл

        📝 Пример:
            if FolderUtils.is_file("script.py"):
                print("Это файл, можно читать")
        """
        import os
        return os.path.isfile(path)

    @staticmethod
    def is_folder(path):
        """
        📁 ЭТО ПАПКА?: Проверяет, является ли путь папкой.

        Параметры:
            path (str): путь для проверки

        Возвращает:
            bool: True если это папка

        📝 Пример:
            if FolderUtils.is_folder("my_project"):
                contents = FolderUtils.find_files("my_project")
        """
        import os
        return os.path.isdir(path)

    @staticmethod
    def list_contents(directory):
        """
        📋 СОДЕРЖИМОЕ ПАПКИ: Возвращает список файлов и папок в директории.

        Параметры:
            directory (str): путь к папке

        Возвращает:
            dict: {"files": [...], "folders": [...]}

        📝 Пример:
            contents = FolderUtils.list_contents("my_project")
            print(f"Файлов: {len(contents['files'])}")
            print(f"Папок: {len(contents['folders'])}")
        """
        import os
        files = []
        folders = []
        try:
            for item in os.listdir(directory):
                full_path = os.path.join(directory, item)
                if os.path.isfile(full_path):
                    files.append(item)
                elif os.path.isdir(full_path):
                    folders.append(item)
        except Exception as e:
            print(f"❌ Ошибка чтения папки: {e}")
        return {"files": files, "folders": folders}

# =============================================================================
# КЛАСС Console – РАБОТА С КОНСОЛЬЮ (ЦВЕТА, КУРСОР, ПРОГРЕСС)
# =============================================================================
class Console:
    """
    🖥️ РАБОТА С КОНСОЛЬЮ: цвета, управление курсором, прогресс-бары и скрытие окна.

    Все методы статические — вызывай напрямую:
        Console.hide()
        Console.success("Готово!")
        Console.progress_bar(100, "Загрузка")

    🎯 Возможности класса:
        - Скрытие и показ консольного окна
        - Цветной вывод текста (16 цветов + стили)
        - Управление положением курсора
        - Прогресс-бары для длительных операций
        - Быстрые сообщения: success, error, warning, info
        - Красивые заголовки на всю ширину консоли
    """

    # ──────────────────────────────────────────────
    #  СКРЫТИЕ / ПОКАЗ КОНСОЛИ
    # ──────────────────────────────────────────────
    @staticmethod
    def hide():
        """
        👻 СКРЫТЬ КОНСОЛЬ: Мгновенно скрывает окно консоли, перезапуская скрипт в фоне.

        📝 Пример:
            Console.hide()
            # Скрипт продолжит работу, но окна не будет видно

        🎯 Возможности:
            - Создание фоновых сервисов
            - Скрытие технического вывода от пользователя
            - Работа программы в трее
        """
        if '--hidden' not in sys.argv:
            pythonw_path = sys.executable.replace('python.exe', 'pythonw.exe')
            if os.path.exists(pythonw_path):
                subprocess.Popen(
                    [pythonw_path] + sys.argv + ['--hidden'],
                    creationflags=0x00000008 | 0x08000000,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    stdin=subprocess.DEVNULL
                )
                sys.exit(0)

    @staticmethod
    def show():
        """
        📺 ПОКАЗАТЬ КОНСОЛЬ: Создаёт новую консоль и привязывает к ней процесс.

        📝 Пример:
            Console.show()
            print("Консоль снова видна!")

        🎯 Возможности:
            - Восстановление скрытой консоли
            - Отладка фоновых процессов
        """
        import ctypes

        kernel32 = ctypes.WinDLL('kernel32')
        kernel32.AllocConsole()

    # ──────────────────────────────────────────────
    #  ЦВЕТА И СТИЛИ
    # ──────────────────────────────────────────────
    @staticmethod
    def color(text, fg=None, bg=None, style=None):
        """
        🎨 ЦВЕТНОЙ ТЕКСТ: Окрашивает текст для вывода в консоль.

        Параметры:
            text (str): текст для окрашивания
            fg (str): цвет текста ('red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white')
            bg (str): цвет фона ('bg_red', 'bg_green', 'bg_blue', ...)
            style (str): стиль текста ('bold', 'underline', 'italic', 'blink', ...)

        Возвращает:
            str: строка с ANSI-кодами для цветного вывода

        📝 Пример:
            print(Console.color("Ошибка!", "red", style="bold"))
            print(Console.color("Успех!", "green"))
            print(Console.color("Важно", "yellow", "bg_blue", "underline"))

        🎯 Возможности:
            - Выделение важных сообщений
            - Цветные логи и отчёты
            - Красивый интерфейс командной строки
        """
        colors = {
            'black': '30', 'red': '31', 'green': '32', 'yellow': '33',
            'blue': '34', 'magenta': '35', 'cyan': '36', 'white': '37',
            'bright_black': '90', 'bright_red': '91', 'bright_green': '92',
            'bright_yellow': '93', 'bright_blue': '94', 'bright_magenta': '95',
            'bright_cyan': '96', 'bright_white': '97',
            'bg_black': '40', 'bg_red': '41', 'bg_green': '42', 'bg_yellow': '43',
            'bg_blue': '44', 'bg_magenta': '45', 'bg_cyan': '46', 'bg_white': '47',
            'bg_bright_black': '100', 'bg_bright_red': '101', 'bg_bright_green': '102',
            'bg_bright_yellow': '103', 'bg_bright_blue': '104', 'bg_bright_magenta': '105',
            'bg_bright_cyan': '106', 'bg_bright_white': '107',
            'bold': '1', 'dim': '2', 'italic': '3', 'underline': '4',
            'blink': '5', 'reverse': '7', 'hidden': '8', 'strikethrough': '9'
        }
        codes = []
        if fg and fg in colors:
            codes.append(colors[fg])
        if bg and bg in colors:
            codes.append(colors[bg])
        if style and style in colors:
            codes.append(colors[style])
        if codes:
            return f'\033[{";".join(codes)}m{text}\033[0m'
        return text

    # ──────────────────────────────────────────────
    #  УПРАВЛЕНИЕ КОНСОЛЬЮ
    # ──────────────────────────────────────────────
    @staticmethod
    def clear():
        """
        🧹 ОЧИСТКА: Полностью очищает экран консоли.

        📝 Пример:
            Console.clear()
            print("Чистый экран!")

        🎯 Возможности:
            - Очистка перед новым выводом
            - Удаление старых сообщений
        """
        os.system('cls' if os.name == 'nt' else 'clear')

    @staticmethod
    def move_to(x, y):
        """
        ➡️ ПЕРЕМЕСТИТЬ КУРСОР: Перемещает курсор в указанную позицию (x, y).

        Параметры:
            x (int): столбец (начиная с 1)
            y (int): строка (начиная с 1)

        📝 Пример:
            Console.move_to(10, 5)
            print("Текст в позиции 10,5")

        🎯 Возможности:
            - Создание интерфейсов в консоли
            - Обновление данных на экране без очистки
        """
        sys.stdout.write(f'\033[{y};{x}H')
        sys.stdout.flush()

    @staticmethod
    def move_up(n=1):
        """
        ⬆️ ВВЕРХ: Перемещает курсор вверх на n строк.

        Параметры:
            n (int): количество строк для перемещения

        📝 Пример:
            Console.move_up(3)
            print("Этот текст будет на 3 строки выше")
        """
        sys.stdout.write(f'\033[{n}A')
        sys.stdout.flush()

    @staticmethod
    def move_down(n=1):
        """
        ⬇️ ВНИЗ: Перемещает курсор вниз на n строк.

        Параметры:
            n (int): количество строк для перемещения

        📝 Пример:
            Console.move_down(2)
            print("Этот текст будет на 2 строки ниже")
        """
        sys.stdout.write(f'\033[{n}B')
        sys.stdout.flush()

    @staticmethod
    def hide_cursor():
        """
        🙈 СКРЫТЬ КУРСОР: Делает мигающий курсор невидимым.

        📝 Пример:
            Console.hide_cursor()
            # Курсор исчезнет

        🎯 Возможности:
            - Улучшение визуала для анимаций
            - Скрытие курсора во время загрузки
        """
        sys.stdout.write('\033[?25l')
        sys.stdout.flush()

    @staticmethod
    def show_cursor():
        """
        👁️ ПОКАЗАТЬ КУРСОР: Возвращает видимость мигающего курсора.

        📝 Пример:
            Console.show_cursor()
            # Курсор снова виден
        """
        sys.stdout.write('\033[?25h')
        sys.stdout.flush()

    @staticmethod
    def save_pos():
        """
        💾 СОХРАНИТЬ ПОЗИЦИЮ: Сохраняет текущую позицию курсора.

        📝 Пример:
            Console.save_pos()
            Console.move_to(1, 10)
            print("Временный вывод")
            Console.restore_pos()
            print("Вернулись обратно")

        🎯 Возможности:
            - Временный вывод без потери позиции
            - Создание сложных консольных интерфейсов
        """
        sys.stdout.write('\033[s')
        sys.stdout.flush()

    @staticmethod
    def restore_pos():
        """
        🔄 ВОССТАНОВИТЬ ПОЗИЦИЮ: Возвращает курсор на сохранённую позицию.

        📝 Пример:
            Console.restore_pos()
        """
        sys.stdout.write('\033[u')
        sys.stdout.flush()

    # ──────────────────────────────────────────────
    #  ПОЛЕЗНЫЕ УТИЛИТЫ
    # ──────────────────────────────────────────────
    @staticmethod
    def size():
        """
        📏 РАЗМЕР КОНСОЛИ: Возвращает размер консоли (ширина, высота).

        Возвращает:
            tuple: (ширина, высота) в символах

        📝 Пример:
            w, h = Console.size()
            print(f"Консоль: {w}x{h} символов")

        🎯 Возможности:
            - Адаптивный вывод под размер окна
            - Центрирование текста
        """
        try:
            return os.get_terminal_size().columns, os.get_terminal_size().lines
        except:
            return 80, 24

    @staticmethod
    def center(text):
        """
        🎯 ЦЕНТРИРОВАНИЕ: Центрирует текст по ширине консоли.

        Параметры:
            text (str): текст для центрирования

        Возвращает:
            str: текст, дополненный пробелами до ширины консоли

        📝 Пример:
            centered = Console.center("Добро пожаловать!")
            print(centered)
        """
        w, h = Console.size()
        return text.center(w)

    @staticmethod
    def progress_bar(total, prefix="", suffix="", length=50, fill="█"):
        """
        📊 ПРОГРЕСС-БАР: Показывает анимированный индикатор выполнения.

        Параметры:
            total (int): общее количество итераций
            prefix (str): текст перед прогресс-баром
            suffix (str): текст после прогресс-бара
            length (int): длина прогресс-бара в символах
            fill (str): символ заполнения

        📝 Пример:
            Console.progress_bar(100, "Загрузка:", "Пожалуйста, подождите")
            # Выведет: Загрузка: [████████████░░░░░░░░░░░░░░░░░░░░░░░░] 40.0% Пожалуйста, подождите

        🎯 Возможности:
            - Отображение прогресса загрузки
            - Визуализация выполнения длительных операций
            - Информирование пользователя о статусе
        """
        for i in range(total + 1):
            percent = i / total
            filled = int(length * percent)
            bar = fill * filled + "░" * (length - filled)
            sys.stdout.write(f"\r{prefix} [{bar}] {percent:.1%} {suffix}")
            sys.stdout.flush()
            if i < total:
                time.sleep(0.05)
        print()

    # ──────────────────────────────────────────────
    #  ОФОРМЛЕНИЕ ТЕКСТА (быстрые сообщения)
    # ──────────────────────────────────────────────
    @staticmethod
    def success(text):
        """
        ✅ УСПЕХ: Выводит зелёное сообщение об успехе.

        Параметры:
            text (str): текст сообщения

        📝 Пример:
            Console.success("Файл сохранён!")
            # Выведет: ✓ Файл сохранён! (зелёным цветом)

        🎯 Возможности:
            - Уведомления об успешных операциях
            - Позитивная обратная связь пользователю
        """
        print(Console.color(f"✓ {text}", "green"))

    @staticmethod
    def error(text):
        """
        ❌ ОШИБКА: Выводит красное сообщение об ошибке.

        Параметры:
            text (str): текст сообщения

        📝 Пример:
            Console.error("Не удалось подключиться к серверу!")
            # Выведет: ✗ Не удалось подключиться к серверу! (красным цветом)

        🎯 Возможности:
            - Отображение критических ошибок
            - Привлечение внимания к проблемам
        """
        print(Console.color(f"✗ {text}", "red"))

    @staticmethod
    def warning(text):
        """
        ⚠️ ПРЕДУПРЕЖДЕНИЕ: Выводит жёлтое предупреждение.

        Параметры:
            text (str): текст предупреждения

        📝 Пример:
            Console.warning("Батарея ниже 10%!")
            # Выведет: ⚠ Батарея ниже 10%! (жёлтым цветом)

        🎯 Возможности:
            - Некритичные предупреждения
            - Напоминания и советы
        """
        print(Console.color(f"⚠ {text}", "yellow"))

    @staticmethod
    def info(text):
        """
        ℹ️ ИНФОРМАЦИЯ: Выводит голубое информационное сообщение.

        Параметры:
            text (str): текст сообщения

        📝 Пример:
            Console.info("Сервер запущен на порту 8080")
            # Выведет: ℹ Сервер запущен на порту 8080 (голубым цветом)

        🎯 Возможности:
            - Информационные сообщения
            - Статус выполнения операций
        """
        print(Console.color(f"ℹ {text}", "cyan"))

    @staticmethod
    def header(text, symbol="="):
        """
        📌 ЗАГОЛОВОК: Выводит жирный заголовок на всю ширину консоли.

        Параметры:
            text (str): текст заголовка
            symbol (str): символ для линии (по умолчанию "=")

        📝 Пример:
            Console.header("МОЯ ПРОГРАММА")
            # Выведет:
            # ============================================
            #               МОЯ ПРОГРАММА
            # ============================================

        🎯 Возможности:
            - Оформление разделов программы
            - Красивые заголовки в отчётах
        """
        w, h = Console.size()
        line = symbol * w
        print(Console.color(line, "blue", style="bold"))
        print(Console.color(text.center(w), "blue", style="bold"))
        print(Console.color(line, "blue", style="bold"))


# =============================================================================
# КЛАСС BazaDB – УНИВЕРСАЛЬНАЯ РАБОТА С SQLite
# =============================================================================
class BazaDB:
    """
    🗄️ БАЗА ДАННЫХ SQLite — лёгкая, быстрая, без сервера.

    📝 Пример использования:
        db = BazaDB("mybase.db")
        db.create_table("users", ["name", "age"])
        db.insert("users", {"name": "Юсуф", "age": 12})
        users = db.get_all("users")
        db.close()

    🎯 Возможности класса:
        - Создание и удаление таблиц
        - Добавление, поиск, обновление и удаление записей
        - Поиск по точному совпадению и по части текста
        - Статистика и список таблиц
        - Полная очистка и удаление таблиц
    """

    def __init__(self, db_name):
        """
        🚀 ПОДКЛЮЧЕНИЕ: Открывает или создаёт файл базы данных SQLite.

        Параметры:
            db_name (str): имя файла базы данных (например, "mybase.db")

        📝 Пример:
            db = BazaDB("shop.db")
            db = BazaDB(":memory:")  # база в оперативной памяти

        🎯 Возможности:
            - Автоматическое создание файла, если его нет
            - Поддержка баз в памяти (для тестов)
        """
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        print(f"✅ Подключено к базе: {db_name}")

    def create_table(self, table_name, columns, drop_if_exists=False):
        """
        📦 СОЗДАТЬ ТАБЛИЦУ: Создаёт новую таблицу с указанными колонками.

        Параметры:
            table_name (str): имя таблицы
            columns (list): список имён колонок (id добавится автоматически)
            drop_if_exists (bool): удалить таблицу, если она уже существует

        📝 Пример:
            db.create_table("products", ["name", "price", "quantity"])
            db.create_table("users", ["email", "password"], drop_if_exists=True)

        🎯 Возможности:
            - Автоматическое добавление PRIMARY KEY колонки id
            - Все колонки создаются с типом TEXT (для универсальности)
            - Опциональное удаление существующей таблицы
        """
        if drop_if_exists:
            self.cursor.execute(f'DROP TABLE IF EXISTS {table_name}')
        cols = "id INTEGER PRIMARY KEY AUTOINCREMENT"
        for col in columns:
            cols += f", {col} TEXT"
        self.cursor.execute(f'CREATE TABLE IF NOT EXISTS {table_name} ({cols})')
        self.conn.commit()
        print(f"   📦 Таблица '{table_name}' создана")

    def insert(self, table_name, data):
        """
        ➕ ДОБАВИТЬ ЗАПИСЬ: Вставляет новую строку в таблицу.

        Параметры:
            table_name (str): имя таблицы
            data (dict): словарь {колонка: значение}

        Возвращает:
            int: ID добавленной записи

        📝 Пример:
            new_id = db.insert("users", {"name": "Анна", "age": "25"})
            print(f"Добавлен пользователь с ID={new_id}")

        🎯 Возможности:
            - Автоматическая генерация ID
            - Частичное заполнение (можно указать не все колонки)
        """
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['?' for _ in data])
        values = tuple(data.values())
        query = f'INSERT INTO {table_name} ({columns}) VALUES ({placeholders})'
        self.cursor.execute(query, values)
        self.conn.commit()
        last_id = self.cursor.lastrowid
        print(f"   ➕ Добавлена запись ID={last_id} в '{table_name}'")
        return last_id

    def get_all(self, table_name):
        """
        📋 ПОЛУЧИТЬ ВСЁ: Возвращает все записи из таблицы.

        Параметры:
            table_name (str): имя таблицы

        Возвращает:
            list[dict]: список словарей с данными

        📝 Пример:
            all_users = db.get_all("users")
            for user in all_users:
                print(f"{user['id']}: {user['name']}, {user['age']} лет")

        🎯 Возможности:
            - Выгрузка всех данных для отчётов
            - Отображение содержимого таблицы
        """
        self.cursor.execute(f'SELECT * FROM {table_name}')
        rows = self.cursor.fetchall()
        self.cursor.execute(f'PRAGMA table_info({table_name})')
        columns = [col[1] for col in self.cursor.fetchall()]
        result = [dict(zip(columns, row)) for row in rows]
        print(f"   📋 Получено {len(result)} записей из '{table_name}'")
        return result

    def find(self, table_name, column, value):
        """
        🔍 ПОИСК ПО ТОЧНОМУ ЗНАЧЕНИЮ: Ищет записи, где column = value.

        Параметры:
            table_name (str): имя таблицы
            column (str): имя колонки для поиска
            value (str): точное значение для поиска

        Возвращает:
            list[dict]: список найденных записей

        📝 Пример:
            adults = db.find("users", "age", "18")
            for adult in adults:
                print(adult["name"])

        🎯 Возможности:
            - Фильтрация по точному значению
            - Поиск пользователей по email, имени и т.д.
        """
        query = f'SELECT * FROM {table_name} WHERE {column} = ?'
        self.cursor.execute(query, (value,))
        rows = self.cursor.fetchall()
        self.cursor.execute(f'PRAGMA table_info({table_name})')
        columns = [col[1] for col in self.cursor.fetchall()]
        result = [dict(zip(columns, row)) for row in rows]
        print(f"   🔍 Найдено {len(result)} записей")
        return result

    def search(self, table_name, column, text):
        """
        🔎 ПОИСК ПО ЧАСТИ ТЕКСТА: Ищет записи, где column содержит text.

        Параметры:
            table_name (str): имя таблицы
            column (str): имя колонки для поиска
            text (str): текст для поиска (регистр важен!)

        Возвращает:
            list[dict]: список найденных записей

        📝 Пример:
            results = db.search("users", "name", "юс")
            # Найдёт: Юсуф, Люся и т.д.

        🎯 Возможности:
            - Нечёткий поиск по подстроке
            - Автодополнение и подсказки
        """
        query = f'SELECT * FROM {table_name} WHERE {column} LIKE ?'
        self.cursor.execute(query, (f'%{text}%',))
        rows = self.cursor.fetchall()
        self.cursor.execute(f'PRAGMA table_info({table_name})')
        columns = [col[1] for col in self.cursor.fetchall()]
        result = [dict(zip(columns, row)) for row in rows]
        print(f"   🔎 Найдено {len(result)} записей")
        return result

    def update(self, table_name, id, data):
        """
        ✏️ ОБНОВИТЬ ЗАПИСЬ: Обновляет данные в строке по ID.

        Параметры:
            table_name (str): имя таблицы
            id (int): ID записи для обновления
            data (dict): словарь {колонка: новое_значение}

        Возвращает:
            bool: True если обновлено, False если запись не найдена

        📝 Пример:
            db.update("users", 1, {"age": "13", "name": "Юсуф"})
            # Обновит возраст и имя у пользователя с ID=1

        🎯 Возможности:
            - Частичное обновление (только указанные поля)
            - Массовое обновление при необходимости
        """
        set_clause = ', '.join([f'{col} = ?' for col in data])
        values = tuple(data.values()) + (id,)
        query = f'UPDATE {table_name} SET {set_clause} WHERE id = ?'
        self.cursor.execute(query, values)
        self.conn.commit()
        if self.cursor.rowcount:
            print(f"   ✏️ Обновлена запись ID={id}")
            return True
        print(f"   ❌ Запись ID={id} не найдена")
        return False

    def delete(self, table_name, id):
        """
        🗑️ УДАЛИТЬ ПО ID: Удаляет запись с указанным ID.

        Параметры:
            table_name (str): имя таблицы
            id (int): ID записи для удаления

        Возвращает:
            bool: True если удалено, False если запись не найдена

        📝 Пример:
            if db.delete("users", 5):
                print("Пользователь удалён")
            else:
                print("Пользователь не найден")

        🎯 Возможности:
            - Точечное удаление записей
            - Очистка устаревших данных
        """
        self.cursor.execute(f'DELETE FROM {table_name} WHERE id = ?', (id,))
        self.conn.commit()
        if self.cursor.rowcount:
            print(f"   🗑️ Удалена запись ID={id}")
            return True
        print(f"   ❌ Запись ID={id} не найдена")
        return False

    def clear_table(self, table_name):
        """
        🧹 ОЧИСТИТЬ ТАБЛИЦУ: Удаляет все записи, но структура таблицы остаётся.

        Параметры:
            table_name (str): имя таблицы

        📝 Пример:
            db.clear_table("temp_logs")
            print("Временные логи очищены")

        🎯 Возможности:
            - Быстрая очистка всех данных
            - Сохранение структуры таблицы для дальнейшего использования
        """
        self.cursor.execute(f'DELETE FROM {table_name}')
        self.conn.commit()
        print(f"   🧹 Таблица '{table_name}' очищена")

    def drop_table(self, table_name):
        """
        💥 УДАЛИТЬ ТАБЛИЦУ: Полностью удаляет таблицу со всеми данными и структурой.

        Параметры:
            table_name (str): имя таблицы для удаления

        📝 Пример:
            db.drop_table("old_backups")
            # Таблица old_backups полностью удалена

        🎯 Возможности:
            - Удаление устаревших таблиц
            - Очистка схемы базы данных
        """
        self.cursor.execute(f'DROP TABLE IF EXISTS {table_name}')
        self.conn.commit()
        print(f"   💥 Таблица '{table_name}' удалена")

    def stats(self, table_name):
        """
        📊 СТАТИСТИКА: Показывает количество записей и список колонок таблицы.

        Параметры:
            table_name (str): имя таблицы

        Возвращает:
            dict: словарь с ключами "total" (количество записей) и "columns" (список колонок)

        📝 Пример:
            stats = db.stats("users")
            print(f"Всего пользователей: {stats['total']}")
            print(f"Поля: {', '.join(stats['columns'])}")

        🎯 Возможности:
            - Мониторинг размера таблиц
            - Проверка структуры данных
        """
        self.cursor.execute(f'SELECT COUNT(*) FROM {table_name}')
        total = self.cursor.fetchone()[0]
        self.cursor.execute(f'PRAGMA table_info({table_name})')
        columns = [col[1] for col in self.cursor.fetchall()]
        print(f"\n📊 Статистика '{table_name}':")
        print(f"   Записей: {total}")
        print(f"   Колонки: {', '.join(columns)}")
        return {"total": total, "columns": columns}

    def show_tables(self):
        """
        📁 ПОКАЗАТЬ ТАБЛИЦЫ: Выводит список всех таблиц в базе данных.

        📝 Пример:
            db.show_tables()
            # Выведет:
            # 📋 Таблицы в базе:
            #    📁 users
            #    📁 products
            #    📁 orders

        🎯 Возможности:
            - Просмотр структуры базы данных
            - Проверка наличия нужных таблиц
        """
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = self.cursor.fetchall()
        print("\n📋 Таблицы в базе:")
        for t in tables:
            print(f"   📁 {t[0]}")

    def close(self):
        """
        🔌 ЗАКРЫТЬ СОЕДИНЕНИЕ: Обязательно вызывать в конце работы с базой.

        📝 Пример:
            db.close()
            print("Работа с базой завершена")

        🎯 Возможности:
            - Корректное завершение работы
            - Сохранение всех изменений
            - Освобождение системных ресурсов
        """
        self.conn.close()
        print("🔌 Соединение закрыто")


# =============================================================================
# КЛАСС Music – МУЗЫКАЛЬНЫЙ ПЛЕЕР С ЯНДЕКС МУЗЫКОЙ
# =============================================================================
class Music:
    """
    🎵 МУЗЫКАЛЬНЫЙ ПЛЕЕР — управление Яндекс.Музыкой через VLC.
    """

    def __init__(self, token=None):
        from yandex_music import Client

        self.token = token or "y0__xDMkd7CBhje-AYg2Zr6-xYw3peC3QeDw6D9crPyCF1q5ruJOitnYr6esA"
        if not self.token:
            raise ValueError("❌ Токен не найден! Укажи token или создай .env файл")

        self.client = Client(self.token).init()
        self.player = None
        self.current_track = None
        self._is_playing = False
        self.paused = False
        self.volume_level = 50
        self.queue = []
        self.queue_index = 0
        self._cache = {}
        import vlc
        self.vlc_instance = vlc.Instance('--quiet')
        self._cache_file = "track_cache.json"
        self._load_cache()
        print("✅ Музыкальный плеер готов")

    # ---------- Внутренние методы ----------
    def _load_cache(self):
        if os.path.exists(self._cache_file):
            try:
                with open(self._cache_file, 'r', encoding='utf-8') as f:
                    raw_cache = json.load(f)
                now = time.time()
                self._cache = {}
                for query, data in raw_cache.items():
                    if isinstance(data, dict) and now - data.get('timestamp', 0) < 10800:
                        self._cache[query] = data['url']
                print(f"📦 Загружен кэш: {len(self._cache)} треков")
            except:
                self._cache = {}
        else:
            self._cache = {}

    def _save_cache(self):
        try:
            data_to_save = {}
            now = time.time()
            for query, url in self._cache.items():
                data_to_save[query] = {'url': url, 'timestamp': now}
            with open(self._cache_file, 'w', encoding='utf-8') as f:
                json.dump(data_to_save, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print(f"⚠️ Не удалось сохранить кэш: {e}")

    def _get_track_url(self, query):
        if query in self._cache:
            return self._cache[query]

        search = self.client.search(query)
        if not search.tracks or not search.tracks.results:
            return None

        track = search.tracks.results[0]
        # Защита от отсутствия трека
        try:
            full_track = self.client.tracks([track.id])[0]
        except (IndexError, AttributeError):
            return None

        url = None
        try:
            info = full_track.get_download_info()
            if info:
                url = info[0].get_direct_link()
        except:
            pass
        if not url:
            try:
                url = full_track.download_url
            except:
                pass

        if url:
            self._cache[query] = url
            self._save_cache()
        return url

    def _play_url(self, url, track_name):
        if self.player:
            self.player.stop()
        self.player = self.vlc_instance.media_player_new()
        media = self.vlc_instance.media_new(url)
        self.player.set_media(media)
        self.player.play()
        self.player.audio_set_volume(self.volume_level)
        self._is_playing = True
        self.paused = False
        self.current_track = track_name
        print(f"▶️ Сейчас играет: {track_name}")

    def _wait_for_end(self):
        import vlc
        if not self.player:
            return
        for _ in range(50):
            if self.player.get_state() == vlc.State.Playing:
                break
            time.sleep(0.1)
        while True:
            state = self.player.get_state()
            if state in (vlc.State.Ended, vlc.State.Stopped, vlc.State.Error):
                break
            time.sleep(0.3)
        time.sleep(0.2)

    # ---------- Базовое управление ----------
    def play(self, query, wait=True):
        url = self._get_track_url(query)
        if not url:
            print(f"❌ Не найден: {query}")
            return False
        self.queue = [{'name': query, 'url': url}]
        self.queue_index = 0
        self._play_url(url, query)
        if wait:
            self._wait_for_end()
        return True

    def pause(self):
        if self.player:
            if self._is_playing:
                self.player.pause()
                self._is_playing = False
                self.paused = True
                print("⏸️ Пауза")
            else:
                self.player.play()
                self._is_playing = True
                self.paused = False
                print("▶️ Продолжение")

    def stop(self):
        if self.player:
            self.player.stop()
            self._is_playing = False
            self.paused = False
            self.current_track = None
            print("⏹️ Остановлено")

    def next(self, wait=True):
        if not self.queue or self.queue_index + 1 >= len(self.queue):
            self.stop()
            print("⏹️ Это был последний трек в очереди")
            return False
        self.queue_index += 1
        track = self.queue[self.queue_index]
        self._play_url(track['url'], track['name'])
        if wait:
            self._wait_for_end()
        return True

    def prev(self, wait=True):
        if not self.queue or self.queue_index <= 0:
            print("⏮️ Это первый трек в очереди")
            return False
        self.queue_index -= 1
        track = self.queue[self.queue_index]
        self._play_url(track['url'], track['name'])
        if wait:
            self._wait_for_end()
        return True

    def volume(self, level):
        self.volume_level = max(0, min(100, level))
        if self.player:
            self.player.audio_set_volume(self.volume_level)
        print(f"🔊 Громкость: {self.volume_level}%")

    def volume_up(self, step=10):
        self.volume(self.volume_level + step)

    def volume_down(self, step=10):
        self.volume(self.volume_level - step)

    # ---------- Очередь ----------
    def add_to_queue(self, query):
        url = self._get_track_url(query)
        if not url:
            print(f"❌ Не найден: {query}")
            return False
        self.queue.append({'name': query, 'url': url})
        print(f"➕ В очередь добавлен: {query}")
        return True

    def show_queue(self):
        if not self.queue:
            print("📭 Очередь пуста")
            return
        print(f"\n📋 ОЧЕРЕДЬ ({len(self.queue)} треков):")
        for i, track in enumerate(self.queue):
            mark = "▶️" if i == self.queue_index else "  "
            print(f"   {mark} {i+1}. {track['name']}")

    def clear_queue(self):
        self.queue = []
        self.queue_index = 0
        print("🧹 Очередь очищена")

    # ---------- Моя волна (рекомендации) ----------
    def play_my_wave(self, limit=10, wait=True):
        """
        🌊 НАСТОЯЩАЯ МОЯ ВОЛНА: рекомендации Яндекс.Музыки на основе вкусов.
        """
        try:
            print("🎵 Загружаю «Мою волну» (рекомендации)...")
            dashboard = self.client.rotor_station_info_dashboard()
            if not dashboard or not dashboard.stations:
                print("⚠️ Станция не найдена, использую избранное")
                return self.play_favorites(limit, wait)

            # Ищем станцию с типом 'personal' (Моя волна)
            my_wave = None
            for s in dashboard.stations:
                if hasattr(s, 'station') and s.station and s.station.id == 'wave':
                    my_wave = s
                    break
            if not my_wave:
                # fallback: берём первую станцию (часто это и есть Моя волна)
                my_wave = dashboard.stations[0]

            # Получаем треки станции
            queue_data = self.client.rotor_station_tracks(my_wave.station)
            if not queue_data or not hasattr(queue_data, 'sequence'):
                print("⚠️ Не удалось загрузить треки, использую избранное")
                return self.play_favorites(limit, wait)

            self.queue = []
            for track_item in list(queue_data.sequence)[:limit]:
                try:
                    track = track_item.track
                    artist_name = track.artists[0].name if track.artists else "Unknown"
                    name = f"{track.title} — {artist_name}"
                    url = self._get_track_url(name)
                    if url:
                        self.queue.append({'name': name, 'url': url})
                except Exception:
                    continue

            if not self.queue:
                print("⚠️ Не удалось загрузить ссылки, использую избранное")
                return self.play_favorites(limit, wait)

            self.queue_index = 0
            self._play_url(self.queue[0]['url'], self.queue[0]['name'])
            print(f"✅ Загружено {len(self.queue)} треков из «Моей волны»")
            if wait:
                self._wait_for_end()
            return True

        except Exception as e:
            print(f"⚠️ Ошибка загрузки рекомендаций: {e}")
            print("🔄 Переключаюсь на избранное...")
            return self.play_favorites(limit, wait)

    # ---------- Избранное (лайкнутые треки) ----------
    def play_favorites(self, limit=10, wait=True):
        """
        ❤️ ИЗБРАННОЕ: треки, которые вы лайкнули в Яндекс.Музыке.
        """
        try:
            print("🎵 Загружаю избранные треки...")
            likes = self.client.users_likes_tracks()
            if not likes:
                print("❌ Нет избранных треков.")
                return False

            self.queue = []
            for like in likes[:limit]:
                try:
                    track = like.fetch_track()
                    artist_name = track.artists[0].name if track.artists else "Unknown"
                    name = f"{track.title} — {artist_name}"
                    url = self._get_track_url(name)
                    if url:
                        self.queue.append({'name': name, 'url': url})
                except Exception:
                    continue

            if not self.queue:
                print("❌ Не удалось загрузить треки из избранного")
                return False

            self.queue_index = 0
            self._play_url(self.queue[0]['url'], self.queue[0]['name'])
            print(f"✅ Загружено {len(self.queue)} избранных треков")
            if wait:
                self._wait_for_end()
            return True
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            return False

    # Для обратной совместимости
    def play_liked_tracks(self, limit=10, wait=True):
        return self.play_favorites(limit, wait)

    # ---------- Плейлисты ----------
    def search_playlist(self, query, limit=10, wait=True):
        try:
            print(f"🔍 Ищу плейлист: {query}")
            search = self.client.search(query)
            if not search.playlists or not search.playlists.results:
                print("❌ Плейлист не найден")
                return False

            playlist = search.playlists.results[0]
            print(f"✅ Найден плейлист: {playlist.title}")

            self.queue = []
            try:
                if hasattr(playlist, 'fetch_tracks'):
                    tracks_data = playlist.fetch_tracks()
                elif hasattr(playlist, 'tracks'):
                    tracks_data = playlist.tracks
                else:
                    print("❌ Не удалось получить треки")
                    return False

                for item in list(tracks_data)[:limit]:
                    try:
                        if hasattr(item, 'track') and item.track:
                            track_info = item.track
                        elif hasattr(item, 'fetch_track'):
                            track_info = item.fetch_track()
                        else:
                            continue

                        title = getattr(track_info, 'title', None)
                        artists = getattr(track_info, 'artists', None)
                        if title and artists:
                            artist_name = artists[0].name if artists else "Неизвестен"
                            name = f"{title} — {artist_name}"
                        elif title:
                            name = title
                        else:
                            continue

                        url = self._get_track_url(name)
                        if url:
                            self.queue.append({'name': name, 'url': url})
                    except Exception:
                        continue
            except Exception as e:
                print(f"⚠️ Ошибка загрузки треков: {e}")
                return False

            if not self.queue:
                print("❌ Не удалось загрузить треки из плейлиста")
                return False

            self.queue_index = 0
            self._play_url(self.queue[0]['url'], self.queue[0]['name'])
            print(f"✅ Загружено {len(self.queue)} треков из «{playlist.title}»")
            if wait:
                self._wait_for_end()
            return True
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            return False

    def mood(self, mood_name, limit=5, wait=True):
        print(f"🎭 Включаю музыку под настроение: {mood_name}")
        result = self.search_playlist(mood_name, limit, wait)
        if not result:
            print(f"⚠️ Плейлист '{mood_name}' не загрузился, включаю Мою волну")
            result = self.play_my_wave(limit, wait)
        return result

    # ---------- Информационные методы ----------
    def is_now_playing(self):
        return self._is_playing

    def get_current_track(self):
        return self.current_track

    def get_volume(self):
        return self.volume_level

    def get_queue_length(self):
        return len(self.queue)


# =============================================================================
# КЛАСС Face – РАСПОЗНАВАНИЕ ЛИЦ И ЭМОЦИЙ
# =============================================================================
class Face:
    """
    🧠 РАСПОЗНАВАНИЕ ЛИЦ И ЭМОЦИЙ — анализ через веб-камеру.

    📝 Пример использования:
        emotion = Face.detect_emotion()
        if emotion == 'happy':
            print("Ты счастлив!")
        is_smiling = Face.detect_smile()
        Face.music_by_mood()  # включит музыку под настроение

    🎯 Возможности класса:
        - Определение эмоций (7 базовых эмоций)
        - Обнаружение улыбки
        - Автоматический запуск музыки по настроению
    """

    @staticmethod
    def detect_emotion():
        """
        🎭 ОПРЕДЕЛИТЬ ЭМОЦИЮ: Анализирует лицо через веб-камеру с помощью DeepFace.

        Возвращает:
            str или None: одна из эмоций ('happy', 'sad', 'angry', 'surprise', 'fear', 'disgust', 'neutral')
                         или None, если лицо не найдено

        📝 Пример:
            emotion = Face.detect_emotion()
            if emotion == 'happy':
                print("Ты сегодня в хорошем настроении!")
            elif emotion == 'sad':
                print("Может, включить музыку?")

        🎯 Возможности:
            - Определение настроения пользователя
            - Адаптация интерфейса под эмоции
            - Использование в играх и интерактивных приложениях
        """
        import cv2
        from deepface import DeepFace

        cap = cv2.VideoCapture(0)
        ret, frame = cap.read()
        cap.release()

        if not ret:
            print("❌ Не удалось получить кадр с камеры")
            return None

        try:
            result = DeepFace.analyze(
                img_path=frame,
                actions=['emotion'],
                enforce_detection=False,
                silent=True
            )
            emotion = result[0]['dominant_emotion']
            return emotion
        except Exception as e:
            print(f"❌ Ошибка DeepFace: {e}")
            return None

    @staticmethod
    def detect_smile():
        """
        😁 ОБНАРУЖЕНИЕ УЛЫБКИ: Проверяет, улыбается ли человек в кадре.

        Возвращает:
            bool: True если обнаружена улыбка, False если нет или ошибка

        📝 Пример:
            if Face.detect_smile():
                print("Отличная улыбка!")
                Auto.screenshot("smile_capture.png")

        🎯 Возможности:
            - Автоматическая фотосъёмка при улыбке
            - Игровые механики с отслеживанием улыбки
            - Интерактивные приложения
        """
        import cv2

        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        smile_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_smile.xml')

        cap = cv2.VideoCapture(0)
        ret, frame = cap.read()
        cap.release()

        if not ret:
            return False

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            roi = gray[y:y+h, x:x+w]
            smiles = smile_cascade.detectMultiScale(roi, 1.8, 20)
            if len(smiles) > 0:
                return True

        return False

    @staticmethod
    def music_by_mood():
        """
        🎵 МУЗЫКА ПО НАСТРОЕНИЮ: Определяет эмоцию и включает подходящий плейлист.

        📝 Пример:
            Face.music_by_mood()
            # Определит, что ты грустишь, и включит спокойную музыку

        🎯 Возможности:
            - Автоматический подбор музыки
            - Создание атмосферы под настроение

        Таблица соответствия эмоций и плейлистов:
            - happy    → happy (весёлая музыка)
            - sad      → sad (грустная музыка)
            - angry    → energy (энергичная музыка)
            - surprise → happy (весёлая музыка)
            - fear     → calm (спокойная музыка)
            - neutral  → calm (спокойная музыка)
        """
        emotion = Face.detect_emotion()
        if not emotion:
            print("Не удалось определить эмоцию")
            return

        mood_map = {
            'happy': 'happy',
            'sad': 'sad',
            'angry': 'energy',
            'surprise': 'happy',
            'fear': 'calm',
            'neutral': 'calm'
        }

        music = Music()
        music.mood(mood_map.get(emotion, 'calm'))


# =============================================================================
# КЛАСС Auto – АВТОМАТИЗАЦИЯ КЛАВИШ И МЫШИ
# =============================================================================
class Auto:
    """
    🖱️ АВТОМАТИЗАЦИЯ: клики, клавиши, скриншоты, уведомления.

    Все методы статические — вызывай напрямую:
        Auto.click()
        Auto.press('enter')
        Auto.write("Привет!")

    🎯 Возможности класса:
        - Эмуляция клавиатуры (нажатие, удержание, печать текста)
        - Эмуляция мыши (клики, двойные клики, перетаскивание, скроллинг)
        - Создание скриншотов
        - Системные уведомления
    """

    # =========================== КЛАВИАТУРА ===========================

    @staticmethod
    def key_down(key: str):
        """
        ⬇️ ЗАЖАТЬ КЛАВИШУ: Зажимает и удерживает клавишу (не отпускает, пока не вызван key_up).

        Параметры:
            key (str): название клавиши, например 'shift', 'ctrl', 'a', 'win'

        📝 Пример:
            Auto.key_down('ctrl')   # зажали Ctrl
            Auto.click(100, 200)    # кликнули мышью с зажатым Ctrl
            Auto.key_up('ctrl')     # отпустили Ctrl

        🎯 Возможности:
            - Создание горячих клавиш (Ctrl+C, Alt+Tab)
            - Комбинации с мышью
        """
        import keyboard
        keyboard.press(key)

    @staticmethod
    def key_up(key: str):
        """
        ⬆️ ОТПУСТИТЬ КЛАВИШУ: Отпускает указанную клавишу, которая была зажата через key_down.

        Параметры:
            key (str): название клавиши, которую нужно отпустить

        📝 Пример:
            Auto.key_down('shift')
            # ... что-то делаем ...
            Auto.key_up('shift')

        🎯 Возможности:
            - Завершение комбинаций клавиш
            - Возврат клавиатуры в обычный режим
        """
        import keyboard
        keyboard.release(key)

    @staticmethod
    def press(key: str, duration: float = 0.05):
        """
        ⌨️ НАЖАТЬ КЛАВИШУ: Нажимает и сразу отпускает клавишу. Аналог быстрого тыка по кнопке.

        Параметры:
            key (str): клавиша (например, 'enter', 'tab', 'esc', 'win+r')
            duration (float): время в секундах между нажатием и отпусканием

        📝 Пример:
            Auto.press('enter')           # быстрый Enter
            Auto.press('win+r', 0.1)      # открыть окно «Выполнить»
            Auto.press('volume_up')       # увеличить громкость

        🎯 Возможности:
            - Имитация нажатий пользователя
            - Управление системой через скрипт
        """
        import keyboard
        keyboard.press(key)
        time.sleep(duration)
        keyboard.release(key)

    @staticmethod
    def is_pressed(key: str) -> bool:
        """
        ❓ ПРОВЕРИТЬ НАЖАТИЕ: Проверяет, зажата ли клавиша в данный момент.

        Параметры:
            key (str): название клавиши

        Возвращает:
            bool: True, если клавиша нажата

        📝 Пример:
            if Auto.is_pressed('esc'):
                print("Клавиша Escape нажата! Выходим...")
                break

        🎯 Возможности:
            - Создание горячих клавиш выхода
            - Обработка пользовательского ввода в реальном времени
        """
        import keyboard
        return keyboard.is_pressed(key)

    @staticmethod
    def write(text: str, delay: float = 0.05):
        """
        📝 ПЕЧАТАТЬ ТЕКСТ: Печатает текст так, как будто его вводит человек с клавиатуры.

        Параметры:
            text (str): строка для ввода
            delay (float): задержка между нажатиями символов в секундах

        📝 Пример:
            Auto.write("Привет, мир!")
            Auto.click(200, 300)  # клик в поле ввода
            Auto.write("username")
            Auto.press('tab')
            Auto.write("password123")
            Auto.press('enter')

        🎯 Возможности:
            - Автозаполнение форм
            - Ввод логинов и паролей
            - Имитация живого пользователя (можно менять delay)
        """
        import keyboard
        for ch in text:
            keyboard.write(ch)
            time.sleep(delay)

    # =========================== МЫШЬ ===========================

    @staticmethod
    def mouse_down(button: str = 'left'):
        """
        🖱️⬇️ ЗАЖАТЬ КНОПКУ МЫШИ: Зажимает кнопку мыши (не отпускает, пока не вызван mouse_up).

        Параметры:
            button (str): 'left', 'right' или 'middle'

        📝 Пример:
            Auto.mouse_down('left')             # зажали левую кнопку
            Auto.move(0, 0, 100, 100, 0.5)      # перетащили объект
            Auto.mouse_up('left')               # отпустили

        🎯 Возможности:
            - Перетаскивание объектов
            - Выделение текста мышью
        """
        import pyautogui
        pyautogui.mouseDown(button=button)

    @staticmethod
    def mouse_up(button: str = 'left'):
        """
        🖱️⬆️ ОТПУСТИТЬ КНОПКУ МЫШИ: Отпускает ранее зажатую кнопку мыши.

        Параметры:
            button (str): 'left', 'right' или 'middle'

        📝 Пример:
            Auto.mouse_down('left')
            # ... перетаскивание ...
            Auto.mouse_up('left')

        🎯 Возможности:
            - Завершение перетаскивания
            - Отпускание после длительного удержания
        """
        import pyautogui
        pyautogui.mouseUp(button=button)

    @staticmethod
    def click(x=None, y=None, button: str = 'left', clicks: int = 1):
        """
        🖱️ КЛИК МЫШЬЮ: Кликает в указанных координатах или в текущем положении.

        Параметры:
            x, y (int, optional): координаты клика. Можно передать кортеж (x, y) в x.
            button (str): 'left', 'right', 'middle'
            clicks (int): количество кликов (1 — одиночный, 2 — двойной)

        📝 Пример:
            Auto.click()                           # клик левой в текущей позиции
            Auto.click(500, 300)                   # клик в точку (500, 300)
            Auto.click((500, 300), button='right') # правый клик туда же
            Auto.click(clicks=2)                   # двойной клик в текущей позиции

        🎯 Возможности:
            - Автоматизация интерфейсов
            - Клики по кнопкам и ссылкам
            - Поддержка двойных и правых кликов
        """
        import pyautogui
        if x is not None and y is not None:
            pyautogui.click(x, y, button=button, clicks=clicks)
        elif isinstance(x, (tuple, list)) and len(x) >= 2:
            pyautogui.click(x[0], x[1], button=button, clicks=clicks)
        elif x is None and y is None:
            pyautogui.click(button=button, clicks=clicks)
        else:
            raise ValueError("Передай и x, и y, или кортеж (x, y), или ничего")

    @staticmethod
    def double_click(x=None, y=None, button: str = 'left'):
        """
        🖱️🖱️ ДВОЙНОЙ КЛИК: Делает двойной клик мышью.

        Параметры:
            x, y (int, optional): координаты клика
            button (str): 'left', 'right', 'middle'

        📝 Пример:
            Auto.double_click()                # двойной клик в текущей позиции
            Auto.double_click(400, 250)        # двойной клик в точку

        🎯 Возможности:
            - Открытие файлов и папок
            - Выделение слов двойным кликом
        """
        Auto.click(x, y, button, clicks=2)

    @staticmethod
    def move(x, y=None, duration: float = 0.0):
        """
        ➡️ ДВИЖЕНИЕ МЫШЬЮ: Перемещает курсор в указанную точку.

        Параметры:
            x, y (int): координаты (или кортеж (x, y) в параметре x)
            duration (float): время перемещения в секундах (0 — мгновенно, 0.5 — плавно)

        📝 Пример:
            Auto.move(300, 400)             # мгновенно в (300, 400)
            Auto.move((300, 400))           # то же самое кортежем
            Auto.move(300, 400, 0.5)        # плавно за полсекунды

        🎯 Возможности:
            - Плавная анимация движения
            - Точное позиционирование мыши
        """
        import pyautogui
        if isinstance(x, (tuple, list)) and len(x) >= 2:
            pyautogui.moveTo(x[0], x[1], duration=duration)
        elif y is not None:
            pyautogui.moveTo(x, y, duration=duration)
        else:
            print("⚠️ Координаты не указаны")

    @staticmethod
    def scroll(amount: int, x=None, y=None):
        """
        🖱️🔄 ПРОКРУТКА: Прокручивает колёсико мыши.

        Параметры:
            amount (int): положительное — вверх, отрицательное — вниз
            x, y (int, optional): координаты курсора перед прокруткой

        📝 Пример:
            Auto.scroll(3)      # прокрутить вверх на 3 щелчка
            Auto.scroll(-5)     # прокрутить вниз на 5 щелчков
            Auto.scroll(2, 500, 300)  # переместиться в (500, 300) и прокрутить вверх

        🎯 Возможности:
            - Скроллинг веб-страниц
            - Навигация по спискам
        """
        import pyautogui
        pyautogui.scroll(amount, x, y)

    @staticmethod
    def drag(start_x, start_y, end_x, end_y, button='left', duration=0.5):
        """
        🖱️↔️ ПЕРЕТАСКИВАНИЕ: Перетаскивает объект от начальных координат к конечным.

        Параметры:
            start_x, start_y (int): начальные координаты
            end_x, end_y (int): конечные координаты
            button (str): кнопка мыши для перетаскивания
            duration (float): время перетаскивания в секундах

        📝 Пример:
            Auto.drag(100, 100, 300, 300)                # перетащить по диагонали
            Auto.drag(100, 100, 300, 300, duration=0.2)  # быстро

        🎯 Возможности:
            - Перемещение окон и файлов
            - Drag-and-drop интерфейсы
        """
        import pyautogui
        pyautogui.moveTo(start_x, start_y)
        pyautogui.drag(end_x - start_x, end_y - start_y, duration=duration, button=button)

    # =========================== ПРОЧЕЕ ===========================

    @staticmethod
    def screenshot(save_path: str = "screen.png"):
        """
        📸 СКРИНШОТ: Делает снимок всего экрана и сохраняет в файл.

        Параметры:
            save_path (str): путь для сохранения относительно папки скрипта

        📝 Пример:
            Auto.screenshot()                    # screen.png в папке скрипта
            Auto.screenshot("my_screen.png")     # своё имя файла
            Auto.screenshot("screenshots/game.png")  # в подпапке

        🎯 Возможности:
            - Сохранение состояний интерфейса
            - Создание отчётов с картинками
            - Отладка автоматизации
        """
        import pyautogui
        full = Manager.search_file_path(save_path)
        img = pyautogui.screenshot()
        img.save(full)

    @staticmethod
    def notify(title: str, message: str, timeout: int = 5):
        """
        🔔 УВЕДОМЛЕНИЕ: Показывает системное уведомление в правом нижнем углу экрана.

        Параметры:
            title (str): заголовок уведомления
            message (str): текст уведомления
            timeout (int): сколько секунд показывать

        📝 Пример:
            Auto.notify("Напоминание", "Пора сделать зарядку!")
            Auto.notify("Кеша", "Музыка поставлена на паузу", 3)
            Auto.notify("Загрузка", "Файл успешно скачан!", 5)

        🎯 Возможности:
            - Ненавязчивые оповещения
            - Уведомления о завершении операций
            - Напоминания пользователю
        """
        try:
            from plyer import notification
            notification.notify(title=title, message=message, timeout=timeout)
        except:
            print(f"⚠️ {title}: {message}")


# =============================================================================
# КЛАСС Web – БРАУЗЕР И ОТКРЫТИЕ ССЫЛОК
# =============================================================================
class Web:
    """
    🌐 РАБОТА С БРАУЗЕРОМ: открытие ссылок, поиск в Яндексе и на YouTube.

    Все методы статические — вызывай напрямую:
        Web.open("https://google.com")
        Web.search("погода Москва")
        Web.youtube("python уроки")

    🎯 Возможности класса:
        - Открытие любых URL в браузере по умолчанию
        - Быстрый поиск в Яндексе
        - Открытие результатов поиска на YouTube
    """

    @staticmethod
    def open(url):
        """
        🌐 ОТКРЫТЬ ССЫЛКУ: Открывает URL в браузере по умолчанию.

        Параметры:
            url (str): полный URL для открытия

        📝 Пример:
            Web.open("https://google.com")
            Web.open("https://github.com/Naruto456y")

        🎯 Возможности:
            - Быстрый переход на сайты
            - Интеграция с веб-сервисами
        """
        webbrowser.open(url)
        print(f"🌐 Открыто: {url}")

    @staticmethod
    def search(query):
        """
        🔍 ПОИСК В ЯНДЕКСЕ: Открывает результаты поиска в Яндексе.

        Параметры:
            query (str): поисковый запрос

        📝 Пример:
            Web.search("как сделать бота на Python")
            Web.search("погода в Москве")

        🎯 Возможности:
            - Быстрый поиск информации
            - Голосовой ассистент может искать в интернете
        """
        url = f"https://yandex.ru/search/?text={quote(query)}"
        webbrowser.open(url)
        print(f"🔍 Поиск: {query}")

    @staticmethod
    def youtube(query):
        """
        🎬 ПОИСК НА YOUTUBE: Открывает результаты поиска видео на YouTube.

        Параметры:
            query (str): поисковый запрос

        📝 Пример:
            Web.youtube("python для начинающих")
            Web.youtube("Morgenshtern последний клип")

        🎯 Возможности:
            - Быстрый поиск видео
            - Интеграция с голосовым ассистентом
        """
        url = f"https://www.youtube.com/results?search_query={quote(query)}"
        webbrowser.open(url)
        print(f"🎬 YouTube: {query}")


# =============================================================================
# КЛАСС System – СИСТЕМНЫЕ КОМАНДЫ
# =============================================================================
class System:
    """
    💻 СИСТЕМНЫЕ КОМАНДЫ: выключение, перезагрузка, сон, блокировка.

    Все методы статические. Будь осторожен с shutdown и restart!

    🎯 Возможности класса:
        - Выключение компьютера
        - Перезагрузка системы
        - Переход в спящий режим
        - Блокировка экрана
    """

    @staticmethod
    def shutdown(delay=0):
        """
        🔌 ВЫКЛЮЧЕНИЕ КОМПЬЮТЕРА: Выключает ПК через указанное количество секунд.

        Параметры:
            delay (int): задержка в секундах перед выключением

        📝 Пример:
            System.shutdown(10)  # Выключится через 10 секунд
            System.shutdown()    # Выключится немедленно

        ⚠️ Внимание: Эта команда реально выключает компьютер! Сохраните все данные.
        """
        if delay > 0:
            print(f"⚠️ Выключение через {delay} секунд...")
            time.sleep(delay)
        os.system("shutdown /s /t 0")
        print("🔌 Выключение...")

    @staticmethod
    def restart(delay=0):
        """
        🔄 ПЕРЕЗАГРУЗКА: Перезагружает компьютер через указанное количество секунд.

        Параметры:
            delay (int): задержка в секундах перед перезагрузкой

        📝 Пример:
            System.restart(30)  # Перезагрузится через 30 секунд
            System.restart()    # Перезагрузится немедленно

        ⚠️ Внимание: Эта команда реально перезагружает компьютер! Сохраните все данные.
        """
        if delay > 0:
            print(f"⚠️ Перезагрузка через {delay} секунд...")
            time.sleep(delay)
        os.system("shutdown /r /t 0")
        print("🔄 Перезагрузка...")

    @staticmethod
    def sleep():
        """
        💤 СПЯЩИЙ РЕЖИМ: Переводит компьютер в спящий режим.

        📝 Пример:
            System.sleep()
            # Компьютер уснёт

        🎯 Возможности:
            - Экономия энергии
            - Быстрое прерывание работы с сохранением состояния
        """
        os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
        print("💤 Спящий режим")

    @staticmethod
    def lock():
        """
        🔒 ЗАБЛОКИРОВАТЬ ЭКРАН: Блокирует рабочую станцию (экран входа в систему).

        📝 Пример:
            System.lock()
            # Экран заблокирован, нужно ввести пароль для входа

        🎯 Возможности:
            - Быстрая блокировка при отходе от компьютера
            - Безопасность данных
        """
        os.system("rundll32.exe user32.dll,LockWorkStation")
        print("🔒 Экран заблокирован")


# =============================================================================
# КЛАСС Info – ИНФОРМАЦИЯ О СИСТЕМЕ
# =============================================================================
class Info:
    """
    ℹ️ ИНФОРМАЦИЯ О СИСТЕМЕ: ОС, батарея, процессор, память.

    Все методы статические — вызывай напрямую:
        battery, plugged = Info.battery()
        os_name = Info.os()
        cpu_load = Info.cpu()
        ram_used, ram_total = Info.ram()

    🎯 Возможности класса:
        - Мониторинг заряда батареи ноутбука
        - Определение операционной системы
        - Загрузка процессора в процентах
        - Использование оперативной памяти
    """

    @staticmethod
    def battery():
        """
        🔋 БАТАРЕЯ: Возвращает уровень заряда и статус подключения к сети.

        Возвращает:
            tuple: (процент заряда, подключена ли зарядка) или (None, None) при ошибке

        📝 Пример:
            percent, plugged = Info.battery()
            if percent is not None:
                print(f"Заряд: {percent}%")
                if plugged:
                    print("Ноутбук на зарядке")
                elif percent < 20:
                    print("⚠️ Пора заряжать!")

        🎯 Возможности:
            - Мониторинг батареи в приложениях
            - Предупреждения о низком заряде
        """
        try:
            import psutil
            battery = psutil.sensors_battery()
            if battery:
                return battery.percent, battery.power_plugged
        except:
            pass
        return None, None

    @staticmethod
    def os():
        """
        🖥️ ОПЕРАЦИОННАЯ СИСТЕМА: Возвращает тип операционной системы.

        Возвращает:
            str: 'win32' для Windows, 'linux' для Linux, 'darwin' для Mac

        📝 Пример:
            os_name = Info.os()
            if os_name == 'win32':
                print("Работаем на Windows")
            elif os_name == 'linux':
                print("Работаем на Linux")

        🎯 Возможности:
            - Кроссплатформенная разработка
            - Выбор системных команд под ОС
        """
        return sys.platform

    @staticmethod
    def cpu():
        """
        🧠 ПРОЦЕССОР: Возвращает загрузку CPU в процентах.

        Возвращает:
            float или None: процент загрузки процессора (измеряется 1 секунду)

        📝 Пример:
            cpu_load = Info.cpu()
            if cpu_load and cpu_load > 90:
                print(f"⚠️ Процессор сильно загружен: {cpu_load}%")
            else:
                print(f"CPU: {cpu_load}%")

        🎯 Возможности:
            - Мониторинг производительности
            - Оптимизация тяжёлых вычислений
        """
        try:
            import psutil
            return psutil.cpu_percent(interval=1)
        except:
            return None

    @staticmethod
    def ram():
        """
        💾 ОПЕРАТИВНАЯ ПАМЯТЬ: Возвращает использование RAM в мегабайтах.

        Возвращает:
            tuple: (использовано МБ, всего МБ) или (None, None) при ошибке

        📝 Пример:
            used, total = Info.ram()
            if used and total:
                print(f"RAM: {used}/{total} MB")
                print(f"Свободно: {total - used} MB ({100 - used/total*100:.0f}%)")

        🎯 Возможности:
            - Мониторинг потребления памяти
            - Диагностика утечек памяти
        """
        try:
            import psutil
            mem = psutil.virtual_memory()
            return mem.used // (1024*1024), mem.total // (1024*1024)
        except:
            return None, None


# =============================================================================
# КЛАСС ThreadManager – УПРАВЛЕНИЕ ПОТОКАМИ
# =============================================================================
class ThreadManager:
    """
    🧵 УПРАВЛЕНИЕ ПОТОКАМИ — запуск, остановка, мониторинг фоновых задач.

    📝 Пример:
        tm = ThreadManager()
        tm.start(my_function, args=(1,2))
        tm.stop_all()

    🎯 Возможности:
        - Запуск фоновых задач без блокировки основного кода
        - Остановка потоков по ID или всех сразу
        - Мониторинг активных потоков
        - Автоматическая обработка событий остановки
    """

    def __init__(self):
        """
        🏗️ ИНИЦИАЛИЗАЦИЯ: Создаёт менеджер потоков с пустыми словарями.
        """
        self.threads = {}
        self.stop_events = {}

    def start(self, target, args=(), name=None, daemon=True):
        """
        ▶️ ЗАПУСК ПОТОКА: Запускает функцию в отдельном фоновом потоке.

        Параметры:
            target (callable): функция для выполнения
            args (tuple): кортеж аргументов функции
            name (str, optional): имя потока (если не указано, генерируется автоматически)
            daemon (bool): фоновый поток (умрёт при завершении программы)

        Возвращает:
            str: ID потока

        📝 Пример:
            def worker(stop_event):
                while not stop_event.is_set():
                    print("Работаю...")
                    time.sleep(1)

            tm = ThreadManager()
            thread_id = tm.start(worker, name="my_worker")
            time.sleep(5)
            tm.stop(thread_id)

        🎯 Возможности:
            - Фоновая обработка данных
            - Параллельное выполнение задач
        """
        stop_event = threading.Event()
        thread_id = name or f"Thread_{len(self.threads) + 1}"

        def wrapper():
            target(*args, stop_event=stop_event)

        thread = threading.Thread(target=wrapper, name=thread_id, daemon=daemon)
        self.threads[thread_id] = thread
        self.stop_events[thread_id] = stop_event
        thread.start()
        print(f"✅ Поток '{thread_id}' запущен")
        return thread_id

    def stop(self, thread_id):
        """
        ⏹️ ОСТАНОВИТЬ ПОТОК: Останавливает поток по его ID.

        Параметры:
            thread_id (str): ID потока, который нужно остановить

        Возвращает:
            bool: True если поток остановлен, False если не найден

        📝 Пример:
            tm.stop("my_worker")
        """
        if thread_id in self.stop_events:
            self.stop_events[thread_id].set()
            print(f"⏹️ Поток '{thread_id}' остановлен")
            return True
        print(f"❌ Поток '{thread_id}' не найден")
        return False

    def stop_all(self):
        """
        ⏹️⏹️ ОСТАНОВИТЬ ВСЁ: Останавливает все запущенные потоки.

        📝 Пример:
            tm.stop_all()
            print("Все фоновые задачи остановлены")
        """
        for thread_id in self.stop_events:
            self.stop_events[thread_id].set()
        print(f"⏹️ Остановлено {len(self.stop_events)} потоков")

    def is_alive(self, thread_id):
        """
        ❓ ПОТОК ЖИВ?: Проверяет, активен ли поток.

        Параметры:
            thread_id (str): ID потока

        Возвращает:
            bool: True если поток жив, False если завершился или не найден

        📝 Пример:
            if tm.is_alive("my_worker"):
                print("Поток ещё работает")
            else:
                print("Поток завершён")
        """
        return thread_id in self.threads and self.threads[thread_id].is_alive()

    def list_threads(self):
        """
        📋 СПИСОК ПОТОКОВ: Возвращает список имён всех активных потоков.

        Возвращает:
            list[str]: имена активных потоков

        📝 Пример:
            active = tm.list_threads()
            print(f"Активных потоков: {len(active)}")
            for name in active:
                print(f"  - {name}")
        """
        return [name for name, t in self.threads.items() if t.is_alive()]

    def active_count(self):
        """
        🔢 КОЛИЧЕСТВО ПОТОКОВ: Возвращает общее количество активных потоков в программе.

        Возвращает:
            int: количество активных потоков

        📝 Пример:
            total = tm.active_count()
            print(f"Всего потоков в программе: {total}")
        """
        return threading.active_count()


# =============================================================================
# КЛАСС ScreenReader – РАСПОЗНАВАНИЕ ЭКРАНА
# =============================================================================
class ScreenReader:
    """
    🖥️ РАСПОЗНАВАНИЕ ЭКРАНА — поиск изображений, цветов, текста на экране.

    Требуется установка: opencv-python, pillow, easyocr, mss, numpy

    📝 Примеры:
        # Найти картинку на экране
        pos = ScreenReader.find_image("button.png")
        if pos:
            pyautogui.click(pos)

        # Найти цвет
        pos = ScreenReader.find_color((255, 0, 0))  # красный

        # Прочитать текст с экрана
        result = ScreenReader.find_text_coordinates("Принять")
        if result['found']:
            pyautogui.click(result['x'], result['y'])

    🎯 Возможности:
        - Поиск изображения на экране (для автоматизации кликов)
        - Поиск пикселя по цвету
        - Чтение текста с экрана (OCR)
        - Получение цвета пикселя в координатах
        - Ожидание появления изображения
        - Выделение найденных изображений рамкой
    """

    @staticmethod
    def find_image(template_path, confidence=0.8, region=None):
        """
        🔍 НАЙТИ ИЗОБРАЖЕНИЕ: Ищет изображение-шаблон на текущем экране.

        Параметры:
            template_path (str): путь к файлу-шаблону (.png рекомендуется)
            confidence (float): порог совпадения (0.7–0.95, чем выше — тем точнее)
            region (tuple): область поиска (x, y, width, height)

        Возвращает:
            tuple или None: (x, y) — центр найденного изображения, или None если не найдено

        📝 Пример:
            pos = ScreenReader.find_image("button.png", confidence=0.9)
            if pos:
                print(f"Кнопка найдена в {pos}")
                Auto.click(pos)

            # Искать только в левом верхнем углу
            pos = ScreenReader.find_image("icon.png", region=(0, 0, 500, 500))

        🎯 Возможности:
            - Автоматизация кликов по кнопкам
            - Проверка наличия элементов интерфейса
            - Поиск в ограниченной области для ускорения
        """
        import cv2
        import numpy as np
        import pyautogui

        if region:
            screenshot = pyautogui.screenshot(region=region)
        else:
            screenshot = pyautogui.screenshot()

        screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        template = cv2.imread(template_path)

        if template is None:
            print(f"❌ Не удалось загрузить {template_path}")
            return None

        result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)

        if max_val >= confidence:
            h, w = template.shape[:2]
            center_x = max_loc[0] + w // 2
            center_y = max_loc[1] + h // 2
            if region:
                center_x += region[0]
                center_y += region[1]
            print(f"✅ Изображение найдено в ({center_x}, {center_y}) (совпадение: {max_val:.2f})")
            return (center_x, center_y)
        else:
            print(f"❌ Изображение не найдено (совпадение: {max_val:.2f})")
            return None

    @staticmethod
    def find_color(target_color, tolerance=30, region=None):
        """
        🎨 НАЙТИ ЦВЕТ: Ищет первый пиксель заданного цвета на экране.

        Параметры:
            target_color (tuple): кортеж (R, G, B) — цвет для поиска
            tolerance (int): допустимое отклонение (0 — точное совпадение, 30 — похожий оттенок)
            region (tuple): область поиска (x, y, width, height)

        Возвращает:
            tuple или None: (x, y) координаты пикселя, или None если не найден

        📝 Пример:
            # Найти красный крестик закрытия окна
            pos = ScreenReader.find_color((255, 0, 0), tolerance=20)
            if pos:
                Auto.click(pos)

            # Искать только в строке состояния
            pos = ScreenReader.find_color((0, 255, 0), region=(0, 900, 1920, 1080))

        🎯 Возможности:
            - Поиск элементов по цвету
            - Проверка статусов (красный/зелёный индикатор)
        """
        import pyautogui
        import numpy as np

        screenshot = pyautogui.screenshot(region=region) if region else pyautogui.screenshot()
        offset_x = region[0] if region else 0
        offset_y = region[1] if region else 0

        img = np.array(screenshot)
        for y in range(img.shape[0]):
            for x in range(img.shape[1]):
                pixel = img[y, x][:3]
                if all(abs(pixel[i] - target_color[i]) <= tolerance for i in range(3)):
                    result_x = x + offset_x
                    result_y = y + offset_y
                    print(f"✅ Цвет найден в ({result_x}, {result_y})")
                    return (result_x, result_y)

        print(f"❌ Цвет {target_color} не найден")
        return None

    @staticmethod
    def get_pixel_color(x, y):
        """
        🎨 ЦВЕТ ПИКСЕЛЯ: Получает цвет пикселя в указанных координатах.

        Параметры:
            x (int): координата X
            y (int): координата Y

        Возвращает:
            tuple: (R, G, B) — цвет пикселя

        📝 Пример:
            color = ScreenReader.get_pixel_color(100, 200)
            print(f"Цвет в (100, 200): {color}")
            # Цвет в (100, 200): (255, 128, 64)
        """
        import pyautogui
        pixel = pyautogui.pixel(x, y)
        print(f"🖱️ Цвет в ({x}, {y}): {pixel}")
        return pixel

    @staticmethod
    def find_text_coordinates(search_text, languages=['en', 'ru'], monitor_index=1, confidence_threshold=0.5, partial_match=True):
        """
        📖 НАЙТИ ТЕКСТ: Ищет координаты текста на экране с помощью OCR.

        Параметры:
            search_text (str): текст для поиска на экране
            languages (list): языки распознавания (по умолчанию ['en', 'ru'])
            monitor_index (int): индекс монитора (1 — основной)
            confidence_threshold (float): минимальная уверенность распознавания (0.0–1.0)
            partial_match (bool): искать частичное совпадение (True) или точное (False)

        Возвращает:
            dict: {'found': True/False, 'x': ..., 'y': ..., 'confidence': ...}

        📝 Пример:
            result = ScreenReader.find_text_coordinates("Принять")
            if result['found']:
                Auto.click(result['x'], result['y'])
                print(f"Нажали на текст (уверенность: {result['confidence']:.2f})")

        🎯 Возможности:
            - Поиск текста в интерфейсах
            - Автоклики по надписям
            - Многоязычное распознавание
        """
        import easyocr
        import mss
        import numpy as np
        from PIL import Image

        reader = easyocr.Reader(languages)

        with mss.mss() as sct:
            monitor = sct.monitors[monitor_index]
            screenshot = sct.grab(monitor)
            img = Image.frombytes("RGB", screenshot.size, screenshot.bgra, "raw", "BGRX")
            img_array = np.array(img)

        results = reader.readtext(img_array, detail=1, text_threshold=0.7)

        best_match = None
        for detection in results:
            bbox = detection[0]
            text = detection[1].lower()
            confidence = detection[2]

            match = False
            if partial_match:
                if search_text in text:
                    match = True
            else:
                if search_text == text:
                    match = True

            if match and confidence >= confidence_threshold:
                x_coords = [point[0] for point in bbox]
                y_coords = [point[1] for point in bbox]
                center_x = int(sum(x_coords) / len(x_coords))
                center_y = int(sum(y_coords) / len(y_coords))

                if best_match is None or confidence > best_match['confidence']:
                    best_match = {
                        'found': True,
                        'x': center_x,
                        'y': center_y,
                        'confidence': confidence,
                        'matched_text': detection[1],
                        'bbox': bbox
                    }

        if best_match:
            return best_match
        return {'found': False, 'error': f'Текст "{search_text}" не найден'}

    @staticmethod
    def wait_for_image(template_path, timeout=30, confidence=0.8):
        """
        ⏳ ЖДАТЬ ИЗОБРАЖЕНИЕ: Ждёт появления изображения на экране в течение заданного времени.

        Параметры:
            template_path (str): путь к изображению
            timeout (int): максимальное время ожидания в секундах
            confidence (float): порог совпадения

        Возвращает:
            tuple или None: (x, y) центр найденного изображения, или None если таймаут

        📝 Пример:
            print("Ждём загрузку...")
            pos = ScreenReader.wait_for_image("loading_complete.png", timeout=60)
            if pos:
                print("Загрузка завершена!")
            else:
                print("Таймаут!")

        🎯 Возможности:
            - Ожидание загрузки интерфейса
            - Синхронизация с медленными программами
        """
        start = time.time()
        while time.time() - start < timeout:
            pos = ScreenReader.find_image(template_path, confidence)
            if pos:
                print(f"✅ Изображение появилось через {time.time() - start:.1f} сек")
                return pos
            time.sleep(0.5)
        print(f"❌ Изображение не появилось за {timeout} сек")
        return None

    @staticmethod
    def highlight_image(template_path, confidence=0.8, duration=2000, color='lime', thickness=4):
        """
        🟩 ВЫДЕЛИТЬ ИЗОБРАЖЕНИЕ: Находит изображение на экране и обводит его рамкой.

        Параметры:
            template_path (str): путь к картинке-образцу (png)
            confidence (float): порог совпадения (0.7–0.95)
            duration (int): сколько миллисекунд держать рамку
            color (str): цвет рамки ('lime', 'red', 'blue', ...)
            thickness (int): толщина линии рамки в пикселях

        Возвращает:
            tuple или None: (x, y) координаты найденного изображения

        📝 Пример:
            ScreenReader.highlight_image("button.png", duration=3000, color='red')
            # Найдёт кнопку и обведёт её красной рамкой на 3 секунды

        🎯 Возможности:
            - Визуальная отладка поиска изображений
            - Демонстрация найденных элементов
        """
        import cv2
        import numpy as np
        import pyautogui
        import tkinter as tk

        screenshot = pyautogui.screenshot()
        screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        template = cv2.imread(template_path)

        if template is None:
            print(f"❌ Не найден файл: {template_path}")
            return

        result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(result)

        if max_val < confidence:
            print(f"❌ Изображение не найдено (совпадение {max_val:.2f})")
            return

        h, w = template.shape[:2]
        x, y = max_loc
        print(f"✅ Найдено: ({x}, {y}) размер {w}x{h} (совпадение {max_val:.2f})")

        root = tk.Tk()
        root.overrideredirect(True)
        root.lift()
        root.wm_attributes("-topmost", True)
        root.wm_attributes("-transparentcolor", "white")

        canvas = tk.Canvas(root, width=w, height=h, highlightthickness=0, bg='white')
        canvas.pack()
        canvas.create_rectangle(0, 0, w-1, h-1, outline=color, width=thickness)

        root.geometry(f"{w}x{h}+{x}+{y}")
        root.after(duration, root.destroy)
        root.mainloop()

        return (x, y)


# =============================================================================
# КЛАСС Clipboard – БУФЕР ОБМЕНА
# =============================================================================
class Clipboard:
    """
    📋 РАБОТА С БУФЕРОМ ОБМЕНА: копирование и вставка текста.

    Требуется установка: pip install pyperclip

    📝 Пример:
        Clipboard.copy("Привет, мир!")
        text = Clipboard.paste()
        print(text)  # "Привет, мир!"
    """

    @staticmethod
    def copy(text: str):
        """
        📋📤 КОПИРОВАТЬ: Копирует текст в буфер обмена.

        Параметры:
            text (str): текст для копирования

        📝 Пример:
            Clipboard.copy("Важный текст")
            # Теперь можно вставить его через Ctrl+V где угодно

        🎯 Возможности:
            - Программное копирование текста
            - Подготовка данных для вставки
        """
        import pyperclip
        pyperclip.copy(text)

    @staticmethod
    def paste() -> str:
        """
        📋📥 ВСТАВИТЬ: Извлекает текст из буфера обмена.

        Возвращает:
            str: текст из буфера обмена

        📝 Пример:
            text = Clipboard.paste()
            print(f"В буфере: {text}")

        🎯 Возможности:
            - Получение скопированных данных
            - Автоматическая обработка текста из буфера
        """
        import pyperclip
        return pyperclip.paste()


# =============================================================================
# КЛАСС MathHelper – БЫСТРЫЕ ВЫЧИСЛЕНИЯ
# =============================================================================
class MathHelper:
    """
    🧮 ПРОСТЫЕ МАТЕМАТИЧЕСКИЕ ОПЕРАЦИИ: факториал, среднее, медиана.

    📝 Примеры:
        MathHelper.factorial(5)          # 120
        MathHelper.mean([1, 2, 3])       # 2.0
        MathHelper.median([1, 2, 3, 4])  # 2.5
        MathHelper.to_binary(42)         # '101010'
        MathHelper.to_hex(42)            # '2a'
        MathHelper.school_round(3.5)     # 4
    """

    @staticmethod
    def factorial(n: int) -> int:
        """
        🔢 ФАКТОРИАЛ: Вычисляет факториал числа n! = 1 × 2 × ... × n.

        Параметры:
            n (int): неотрицательное целое число

        Возвращает:
            int: значение факториала

        📝 Пример:
            MathHelper.factorial(5)  # 120 (1×2×3×4×5)
            MathHelper.factorial(0)  # 1
        """
        return math.factorial(n)

    @staticmethod
    def mean(numbers: list) -> float:
        """
        📊 СРЕДНЕЕ АРИФМЕТИЧЕСКОЕ: Сумма элементов, делённая на их количество.

        Параметры:
            numbers (list): список чисел

        Возвращает:
            float: среднее значение

        📝 Пример:
            MathHelper.mean([1, 2, 3, 4, 5])  # 3.0
            MathHelper.mean([10, 20])          # 15.0
        """
        return sum(numbers) / len(numbers)

    @staticmethod
    def median(numbers: list) -> float:
        """
        📈 МЕДИАНА: Значение, которое находится посередине отсортированного списка.

        Параметры:
            numbers (list): список чисел

        Возвращает:
            float: медиана

        📝 Пример:
            MathHelper.median([1, 2, 3, 4, 5])   # 3
            MathHelper.median([1, 2, 3, 4])      # 2.5
        """
        return statistics.median(numbers)

    @staticmethod
    def to_binary(n: int) -> str:
        """
        0️⃣1️⃣ В ДВОИЧНУЮ: Переводит целое число в двоичную систему счисления.

        Параметры:
            n (int): целое число

        Возвращает:
            str: строка с двоичным представлением

        📝 Пример:
            MathHelper.to_binary(42)   # '101010'
            MathHelper.to_binary(255)  # '11111111'
        """
        return bin(n)[2:]

    @staticmethod
    def to_hex(n: int) -> str:
        """
        🔣 В ШЕСТНАДЦАТЕРИЧНУЮ: Переводит целое число в шестнадцатеричную систему.

        Параметры:
            n (int): целое число

        Возвращает:
            str: строка с шестнадцатеричным представлением

        📝 Пример:
            MathHelper.to_hex(42)   # '2a'
            MathHelper.to_hex(255)  # 'ff'
        """
        return hex(n)[2:]

    @staticmethod
    def school_round(number, digits=0):
        """
        🎓 ШКОЛЬНОЕ ОКРУГЛЕНИЕ: Работает как на уроках математики.
        3.5 → 4, 3.15 (до десятых) → 3.2

        Отличается от встроенного round(), который использует банковское округление.

        Параметры:
            number (float): число для округления
            digits (int): сколько знаков после запятой оставить (по умолчанию 0)

        Возвращает:
            float: округлённое число

        📝 Пример:
            MathHelper.school_round(3.5)        # 4.0
            MathHelper.school_round(4.5)        # 5.0
            MathHelper.school_round(3.15, 1)    # 3.2
            MathHelper.school_round(3.14, 1)    # 3.1

        🎯 Возможности:
            - Правильное округление для школьных задач
            - Финансовые расчёты
        """
        multiplier = 10 ** digits
        return (number * multiplier + 0.5 * (1 if number >= 0 else -1)) // 1 * (1 / multiplier)


# =============================================================================
# КЛАСС FileUtils – ПРОСТЫЕ ОПЕРАЦИИ С ФАЙЛАМИ
# =============================================================================
class FileUtils:
    """
    📄 ЧТЕНИЕ, ЗАПИСЬ И ПОДСЧЁТ СТРОК.

    📝 Примеры:
        content = FileUtils.read_text("notes.txt")
        FileUtils.write_text("hello.txt", "Привет!")
        lines = FileUtils.count_lines("log.txt")
    """

    @staticmethod
    def read_text(path: str) -> str:
        """
        📖 ЧИТАТЬ ФАЙЛ: Читает весь текстовый файл и возвращает содержимое.

        Параметры:
            path (str): путь к текстовому файлу

        Возвращает:
            str: содержимое файла

        📝 Пример:
            content = FileUtils.read_text("config.txt")
            print(content)

        🎯 Возможности:
            - Чтение конфигурационных файлов
            - Загрузка текстовых данных
        """
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()

    @staticmethod
    def write_text(path: str, content: str):
        """
        ✍️ ЗАПИСАТЬ ФАЙЛ: Записывает текст в файл (перезаписывает, если существует).

        Параметры:
            path (str): путь к файлу
            content (str): текст для записи

        📝 Пример:
            FileUtils.write_text("output.txt", "Результаты:\\n...")
            print("Файл сохранён!")

        🎯 Возможности:
            - Сохранение отчётов и логов
            - Создание новых текстовых файлов
        """
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)

    @staticmethod
    def count_lines(path: str) -> int:
        """
        🔢 ПОДСЧЁТ СТРОК: Считает количество строк в текстовом файле.

        Параметры:
            path (str): путь к файлу

        Возвращает:
            int: количество строк

        📝 Пример:
            lines = FileUtils.count_lines("log.txt")
            print(f"В лог-файле {lines} строк")

        🎯 Возможности:
            - Анализ размера логов
            - Проверка количества записей
        """
        with open(path, 'r', encoding='utf-8') as f:
            return sum(1 for _ in f)


# =============================================================================
# КЛАСС ImageUtils – ПРОСТЫЕ ОПЕРАЦИИ С ИЗОБРАЖЕНИЯМИ (Pillow)
# =============================================================================
class ImageUtils:
    """
    🖼️ ИЗМЕНЕНИЕ РАЗМЕРА, ОБРЕЗКА, ПОВОРОТ ИЗОБРАЖЕНИЙ.

    Требуется установка: pip install pillow

    📝 Примеры:
        ImageUtils.resize("input.jpg", "small.jpg", 100, 100)
        ImageUtils.crop("input.jpg", "cropped.jpg", 10, 10, 50, 50)
        ImageUtils.rotate("input.jpg", "rotated.jpg", 90)
    """

    @staticmethod
    def resize(input_path, output_path, width, height):
        """
        📏 ИЗМЕНИТЬ РАЗМЕР: Изменяет размер изображения.

        Параметры:
            input_path (str): путь к исходному изображению
            output_path (str): путь для сохранения
            width (int): новая ширина в пикселях
            height (int): новая высота в пикселях

        📝 Пример:
            ImageUtils.resize("photo.jpg", "photo_small.jpg", 200, 150)
            print("Миниатюра создана!")

        🎯 Возможности:
            - Создание миниатюр
            - Оптимизация размера для веба
        """
        from PIL import Image
        img = Image.open(input_path)
        img = img.resize((width, height))
        img.save(output_path)

    @staticmethod
    def crop(input_path, output_path, left, top, right, bottom):
        """
        ✂️ ОБРЕЗАТЬ: Обрезает изображение по указанным границам.

        Параметры:
            input_path (str): путь к исходному изображению
            output_path (str): путь для сохранения
            left, top, right, bottom (int): границы обрезки в пикселях

        📝 Пример:
            ImageUtils.crop("photo.jpg", "face.jpg", 100, 50, 300, 300)
            print("Обрезано!")

        🎯 Возможности:
            - Вырезание фрагментов изображений
            - Удаление лишних краёв
        """
        from PIL import Image
        img = Image.open(input_path)
        cropped = img.crop((left, top, right, bottom))
        cropped.save(output_path)

    @staticmethod
    def rotate(input_path, output_path, degrees):
        """
        🔄 ПОВЕРНУТЬ: Поворачивает изображение на указанный угол.

        Параметры:
            input_path (str): путь к исходному изображению
            output_path (str): путь для сохранения
            degrees (int): угол поворота в градусах

        📝 Пример:
            ImageUtils.rotate("photo.jpg", "photo_90.jpg", 90)
            ImageUtils.rotate("photo.jpg", "photo_flip.jpg", 180)

        🎯 Возможности:
            - Исправление ориентации фото
            - Создание повёрнутых копий
        """
        from PIL import Image
        img = Image.open(input_path)
        rotated = img.rotate(degrees, expand=True)
        rotated.save(output_path)


# =============================================================================
# КЛАСС PDFUtils – ИЗВЛЕЧЕНИЕ ТЕКСТА ИЗ PDF (PyPDF2)
# =============================================================================
class PDFUtils:
    """
    📑 ЧТЕНИЕ ТЕКСТА ИЗ PDF-ФАЙЛОВ.

    Требуется установка: pip install PyPDF2

    📝 Пример:
        text = PDFUtils.extract_text("document.pdf")
        print(text)
    """

    @staticmethod
    def extract_text(pdf_path: str) -> str:
        """
        📄 ИЗВЛЕЧЬ ТЕКСТ: Извлекает весь текст из PDF-файла.

        Параметры:
            pdf_path (str): путь к PDF-файлу

        Возвращает:
            str: извлечённый текст (страницы разделены переносом строки)

        📝 Пример:
            text = PDFUtils.extract_text("report.pdf")
            print(f"В документе {len(text)} символов")
            print(text[:200])  # первые 200 символов

        🎯 Возможности:
            - Обработка документов
            - Извлечение данных из PDF-отчётов
        """
        import PyPDF2
        text = []
        with open(pdf_path, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                text.append(page.extract_text() or '')
        return '\n'.join(text)


# =============================================================================
# КЛАСС PasswordGen – ГЕНЕРАТОР ПАРОЛЕЙ
# =============================================================================
class PasswordGen:
    """
    🔐 ГЕНЕРАЦИЯ СЛУЧАЙНЫХ ПАРОЛЕЙ.

    📝 Примеры:
        PasswordGen.generate()          # 12 символов, с цифрами и спецсимволами
        PasswordGen.generate(8, False)  # только буквы, 8 символов
        PasswordGen.generate(16)        # длинный надёжный пароль
    """

    @staticmethod
    def generate(length=12, use_digits=True, use_special=True) -> str:
        """
        🔑 СОЗДАТЬ ПАРОЛЬ: Генерирует случайный пароль из букв, цифр и спецсимволов.

        Параметры:
            length (int): длина пароля (по умолчанию 12)
            use_digits (bool): включать ли цифры (0-9)
            use_special (bool): включать ли спецсимволы (!@#$%^&*)

        Возвращает:
            str: сгенерированный пароль

        📝 Пример:
            pwd1 = PasswordGen.generate()            # "aB3$xK9@mP2q"
            pwd2 = PasswordGen.generate(8, False)     # "aBcDeFgH" (только буквы)
            pwd3 = PasswordGen.generate(16)           # 16 символов, надёжный

        🎯 Возможности:
            - Создание паролей для новых аккаунтов
            - Генерация токенов и ключей
            - Настраиваемая сложность
        """
        chars = string.ascii_letters
        if use_digits:
            chars += string.digits
        if use_special:
            chars += "!@#$%^&*"
        return ''.join(random.choice(chars) for _ in range(length))


# =============================================================================
# КЛАСС UnitConverter – КОНВЕРТАЦИЯ ВЕЛИЧИН
# =============================================================================
class UnitConverter:
    """
    📏 КОНВЕРТАЦИЯ МЕЖДУ ЕДИНИЦАМИ ИЗМЕРЕНИЯ.

    📝 Примеры:
        UnitConverter.celsius_to_fahrenheit(0)   # 32.0
        UnitConverter.km_to_miles(10)             # 6.21371
        UnitConverter.kg_to_lbs(5)                # 11.0231
    """

    @staticmethod
    def celsius_to_fahrenheit(c: float) -> float:
        """
        🌡️ °C → °F: Переводит температуру из Цельсия в Фаренгейт.

        Формула: F = C × 9/5 + 32

        Параметры:
            c (float): температура в градусах Цельсия

        Возвращает:
            float: температура в градусах Фаренгейта

        📝 Пример:
            UnitConverter.celsius_to_fahrenheit(0)    # 32.0 (замерзание воды)
            UnitConverter.celsius_to_fahrenheit(100)  # 212.0 (кипение воды)
            UnitConverter.celsius_to_fahrenheit(37)   # 98.6 (температура тела)
        """
        return c * 9/5 + 32

    @staticmethod
    def fahrenheit_to_celsius(f: float) -> float:
        """
        🌡️ °F → °C: Переводит температуру из Фаренгейта в Цельсий.

        Формула: C = (F - 32) × 5/9

        Параметры:
            f (float): температура в градусах Фаренгейта

        Возвращает:
            float: температура в градусах Цельсия

        📝 Пример:
            UnitConverter.fahrenheit_to_celsius(32)    # 0.0
            UnitConverter.fahrenheit_to_celsius(212)   # 100.0
        """
        return (f - 32) * 5/9

    @staticmethod
    def km_to_miles(km: float) -> float:
        """
        🛣️ КМ → МИЛИ: Переводит километры в мили.

        Параметры:
            km (float): расстояние в километрах

        Возвращает:
            float: расстояние в милях

        📝 Пример:
            UnitConverter.km_to_miles(10)   # 6.21371
            UnitConverter.km_to_miles(100)  # 62.1371
        """
        return km * 0.621371

    @staticmethod
    def miles_to_km(miles: float) -> float:
        """
        🛣️ МИЛИ → КМ: Переводит мили в километры.

        Параметры:
            miles (float): расстояние в милях

        Возвращает:
            float: расстояние в километрах

        📝 Пример:
            UnitConverter.miles_to_km(10)  # 16.0934
        """
        return miles / 0.621371

    @staticmethod
    def kg_to_lbs(kg: float) -> float:
        """
        ⚖️ КГ → ФУНТЫ: Переводит килограммы в фунты.

        Параметры:
            kg (float): вес в килограммах

        Возвращает:
            float: вес в фунтах

        📝 Пример:
            UnitConverter.kg_to_lbs(5)   # 11.0231
            UnitConverter.kg_to_lbs(70)  # 154.3234
        """
        return kg * 2.20462

    @staticmethod
    def lbs_to_kg(lbs: float) -> float:
        """
        ⚖️ ФУНТЫ → КГ: Переводит фунты в килограммы.

        Параметры:
            lbs (float): вес в фунтах

        Возвращает:
            float: вес в килограммах

        📝 Пример:
            UnitConverter.lbs_to_kg(10)  # 4.5359
        """
        return lbs / 2.20462


# =============================================================================
# ПРИМЕРЫ ИСПОЛЬЗОВАНИЯ
# =============================================================================
if __name__ == "__main__":
    Manager.open_file("test_help_manager.py")