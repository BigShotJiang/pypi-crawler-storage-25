from setuptools import setup

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="pycraft-tools",
    version="1.0.2",  # Обновлено
    author="Yusuf Guseinov",
    author_email="yusufvaleh@gmail.com",
    description="Удобные инструменты на Python: голос, музыка, автоматизация, базы данных и ИИ",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Naruto456y/help-tools",
    py_modules=["help_manager"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Utilities",
        "Natural Language :: Russian",
    ],
    python_requires=">=3.7",
    install_requires=[
        "gtts", "pydub", "SpeechRecognition", "pygame", "requests",
        "beautifulsoup4", "python-vlc", "opencv-python-headless",
        "keyboard", "mouse", "pyautogui", "yandex-music",
        "python-dotenv", "deepface", "easyocr", "mss", "Pillow",
        "numpy", "psutil", "youtube-search", "pyperclip", "PyPDF2", "plyer",
    ],
)