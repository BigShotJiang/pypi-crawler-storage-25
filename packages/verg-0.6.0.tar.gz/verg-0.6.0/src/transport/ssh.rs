use std::path::PathBuf;

use tokio::io::AsyncWriteExt;
use tokio::process::Command;

use crate::bundle::Bundle;
use crate::error::Error;
use crate::resources::RunSummary;

use super::ExecResult;

const AGENT_PATH: &str = "/usr/local/bin/verg-agent";
const VERSION_PATH: &str = "/usr/local/share/verg/version";

pub struct SshTransport {
    pub agent_dir: PathBuf,
    pub version: String,
    pub ssh_config: Option<PathBuf>,
}

impl SshTransport {
    pub fn new(agent_dir: PathBuf, version: String) -> Self {
        Self {
            agent_dir,
            version,
            ssh_config: None,
        }
    }

    fn ssh_base_args(&self) -> Vec<String> {
        let mut args = vec!["-o".into(), "BatchMode=yes".into()];
        if let Some(config) = &self.ssh_config {
            args.push("-F".into());
            args.push(config.to_string_lossy().into_owned());
        }
        args
    }

    /// Gather basic system facts from the target in a single SSH command.
    /// Returns a HashMap with keys like "fact.arch", "fact.hostname", etc.
    pub async fn gather_facts(
        &self,
        user: &str,
        address: &str,
        port: Option<u16>,
    ) -> Result<std::collections::HashMap<String, String>, Error> {
        let target = format!("{user}@{address}");
        let mut args = self.ssh_base_args();
        if let Some(p) = port {
            args.extend(["-p".into(), p.to_string()]);
        }
        args.extend(["-o".into(), "ConnectTimeout=10".into(), target]);
        args.push(
            "echo \"arch=$(uname -m)\" && \
             echo \"hostname=$(hostname)\" && \
             echo \"os=$(. /etc/os-release 2>/dev/null && echo $ID)\" && \
             echo \"os_release=$(. /etc/os-release 2>/dev/null && echo $VERSION_CODENAME)\" && \
             echo \"os_version=$(. /etc/os-release 2>/dev/null && echo $VERSION_ID)\""
                .into(),
        );

        let output = Command::new("ssh")
            .args(&args)
            .output()
            .await
            .map_err(|e| Error::Connection(format!("ssh facts: {e}")))?;

        if !output.status.success() {
            return Err(Error::Connection(
                "failed to gather facts from target".into(),
            ));
        }

        let mut facts = std::collections::HashMap::new();
        for line in String::from_utf8_lossy(&output.stdout).lines() {
            if let Some((key, val)) = line.split_once('=') {
                facts.insert(format!("fact.{key}"), val.to_string());
            }
        }

        Ok(facts)
    }

    fn arch_to_target(arch: &str) -> Result<&'static str, Error> {
        match arch {
            "x86_64" => Ok("x86_64-unknown-linux-gnu"),
            "aarch64" => Ok("aarch64-unknown-linux-gnu"),
            other => Err(Error::Config(format!(
                "unsupported target architecture: {other}"
            ))),
        }
    }

    async fn agent_binary_for_arch(&self, arch: &str) -> Result<PathBuf, Error> {
        let target = Self::arch_to_target(arch)?;
        let version_dir = self.agent_dir.join(&self.version);
        let cached = version_dir.join(format!("verg-agent-{target}"));

        // Check versioned cache first
        if cached.exists() {
            return Ok(cached);
        }

        // Download from GitHub releases
        eprintln!("Downloading verg-agent v{} for {target}...", self.version);
        let url = format!(
            "https://github.com/rvben/verg/releases/download/v{}/verg-agent-{target}",
            self.version
        );

        std::fs::create_dir_all(&version_dir).map_err(|e| {
            Error::Config(format!(
                "failed to create agents dir {}: {e}",
                version_dir.display()
            ))
        })?;

        let output = Command::new("curl")
            .args(["-fSL", "--progress-bar", "-o"])
            .arg(&cached)
            .arg(&url)
            .output()
            .await
            .map_err(|e| Error::Connection(format!("curl: {e}")))?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            // Clean up partial download
            let _ = std::fs::remove_file(&cached);
            return Err(Error::Config(format!(
                "failed to download agent binary from {url}\n{stderr}\n\
                 Hint: the release v{} may not exist yet. \
                 Build locally with `cargo build --release --target {target} --bin verg-agent`",
                self.version
            )));
        }

        // Make executable
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(&cached, std::fs::Permissions::from_mode(0o755))
                .map_err(|e| Error::Config(format!("failed to chmod agent binary: {e}")))?;
        }

        // Clean up old versions
        if let Ok(entries) = std::fs::read_dir(&self.agent_dir) {
            for entry in entries.flatten() {
                let path = entry.path();
                if path.is_dir() && path != version_dir {
                    let _ = std::fs::remove_dir_all(&path);
                }
            }
        }

        eprintln!("Cached at {}", cached.display());
        Ok(cached)
    }

    async fn check_version(
        &self,
        user: &str,
        address: &str,
        port: Option<u16>,
    ) -> Result<bool, Error> {
        let target = format!("{user}@{address}");
        let mut args = self.ssh_base_args();
        if let Some(p) = port {
            args.extend(["-p".into(), p.to_string()]);
        }
        args.extend(["-o".into(), "ConnectTimeout=10".into(), target]);
        args.push(format!("cat {VERSION_PATH} 2>/dev/null"));

        let output = Command::new("ssh")
            .args(&args)
            .output()
            .await
            .map_err(|e| Error::Connection(format!("ssh to {address}: {e}")))?;

        let remote_version = String::from_utf8_lossy(&output.stdout).trim().to_string();
        Ok(remote_version == self.version)
    }

    async fn push_binary(
        &self,
        user: &str,
        address: &str,
        port: Option<u16>,
        agent_binary: &std::path::Path,
    ) -> Result<(), Error> {
        let target = format!("{user}@{address}");

        // Create directories
        let mut args = self.ssh_base_args();
        if let Some(p) = port {
            args.extend(["-p".into(), p.to_string()]);
        }
        args.extend([
            target.clone(),
            "mkdir -p /usr/local/bin /usr/local/share/verg".into(),
        ]);
        let output = Command::new("ssh")
            .args(&args)
            .output()
            .await
            .map_err(|e| Error::Connection(format!("ssh mkdir: {e}")))?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(Error::Connection(format!(
                "failed to create dirs: {stderr}"
            )));
        }

        // Copy binary
        let mut scp_args = self.ssh_base_args();
        if let Some(p) = port {
            scp_args.extend(["-P".into(), p.to_string()]);
        }
        scp_args.push(agent_binary.to_string_lossy().into_owned());
        scp_args.push(format!("{target}:{AGENT_PATH}"));
        let output = Command::new("scp")
            .args(&scp_args)
            .output()
            .await
            .map_err(|e| Error::Connection(format!("scp: {e}")))?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(Error::Connection(format!(
                "failed to push binary: {stderr}"
            )));
        }

        // Set permissions and write version
        let mut args = self.ssh_base_args();
        if let Some(p) = port {
            args.extend(["-p".into(), p.to_string()]);
        }
        args.extend([
            target,
            format!(
                "chmod +x {AGENT_PATH} && echo '{}' > {VERSION_PATH}",
                self.version
            ),
        ]);
        let output = Command::new("ssh")
            .args(&args)
            .output()
            .await
            .map_err(|e| Error::Connection(format!("ssh chmod: {e}")))?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(Error::Connection(format!(
                "failed to set up agent: {stderr}"
            )));
        }

        Ok(())
    }

    pub async fn execute(
        &self,
        user: &str,
        address: &str,
        port: Option<u16>,
        bundle: &Bundle,
        dry_run: bool,
    ) -> Result<ExecResult, Error> {
        let facts = self.gather_facts(user, address, port).await?;
        let arch = facts
            .get("fact.arch")
            .cloned()
            .unwrap_or_else(|| "x86_64".into());

        let has_version = self.check_version(user, address, port).await?;
        if !has_version {
            let agent_binary = self.agent_binary_for_arch(&arch).await?;
            self.push_binary(user, address, port, &agent_binary).await?;
        }

        let target = format!("{user}@{address}");
        let bundle_toml = bundle.to_toml()?;

        let mut cmd_str = AGENT_PATH.to_string();
        if dry_run {
            cmd_str.push_str(" --dry-run");
        }

        let mut args = self.ssh_base_args();
        if let Some(p) = port {
            args.extend(["-p".into(), p.to_string()]);
        }
        args.extend([target, cmd_str]);

        let mut child = Command::new("ssh")
            .args(&args)
            .stdin(std::process::Stdio::piped())
            .stdout(std::process::Stdio::piped())
            .stderr(std::process::Stdio::piped())
            .spawn()
            .map_err(|e| Error::Connection(format!("ssh spawn: {e}")))?;

        if let Some(mut stdin) = child.stdin.take() {
            stdin
                .write_all(bundle_toml.as_bytes())
                .await
                .map_err(|e| Error::Connection(format!("write to ssh stdin: {e}")))?;
            drop(stdin);
        }

        let output = child
            .wait_with_output()
            .await
            .map_err(|e| Error::Connection(format!("ssh wait: {e}")))?;

        let stdout = String::from_utf8_lossy(&output.stdout);
        let summary: RunSummary = serde_json::from_str(&stdout).map_err(|e| {
            Error::Other(format!(
                "failed to parse agent output: {e}\nraw output: {stdout}"
            ))
        })?;

        Ok(ExecResult { summary })
    }
}
