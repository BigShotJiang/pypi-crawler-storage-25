use std::path::Path;

use crate::engine::{Engine, EngineResult};
use crate::error::Error;
use crate::output::OutputConfig;
use crate::resources::ResourceStatus;

pub async fn run(
    engine: &Engine,
    base_dir: &Path,
    targets: &str,
    output: &OutputConfig,
) -> Result<i32, Error> {
    let result = engine.run(base_dir, targets, false).await?;
    print_result(&result, output);

    if let Err(e) = crate::changelog::write_log(base_dir, &result.summaries) {
        eprintln!("Warning: failed to write change log: {e}");
    }

    Ok(result.exit_code())
}

pub fn print_result(result: &EngineResult, output: &OutputConfig) {
    if output.json {
        let json = serde_json::to_string_pretty(&result.summaries).unwrap();
        println!("{json}");
    } else {
        for summary in &result.summaries {
            for r in &summary.resources {
                let (symbol, status_text) = match r.status {
                    ResourceStatus::Ok => ("✓", "already ok"),
                    ResourceStatus::Changed => ("✗", "changed"),
                    ResourceStatus::Failed => ("✗", "FAILED"),
                    ResourceStatus::Skipped => ("-", "skipped"),
                };
                let detail = match &r.diff {
                    Some(d) => format!(" → {d}"),
                    None => match &r.error {
                        Some(e) => format!(" ({e})"),
                        None => String::new(),
                    },
                };
                if output.color {
                    use owo_colors::OwoColorize;
                    let colored_symbol = match r.status {
                        ResourceStatus::Ok => symbol.green().to_string(),
                        ResourceStatus::Changed => symbol.yellow().to_string(),
                        ResourceStatus::Failed => symbol.red().to_string(),
                        ResourceStatus::Skipped => symbol.dimmed().to_string(),
                    };
                    eprintln!(
                        "{}: {}.{} {} {status_text}{detail}",
                        summary.host, r.resource_type, r.name, colored_symbol
                    );
                } else {
                    eprintln!(
                        "{}: {}.{} {symbol} {status_text}{detail}",
                        summary.host, r.resource_type, r.name
                    );
                }
            }
            eprintln!(
                "{}: {} changed, {} ok, {} failed, {} skipped\n",
                summary.host,
                summary.summary.changed,
                summary.summary.ok,
                summary.summary.failed,
                summary.summary.skipped
            );
        }
    }
}
