import { HTMLAttributes, ReactNode } from "react";

type CardVariant = "default" | "elevated" | "glass";

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  variant?: CardVariant;
  glow?: boolean;
}

const variantClasses: Record<CardVariant, string> = {
  default:
    "bg-[var(--bg-surface)] border-[var(--border-dim)] shadow-card",
  elevated:
    "bg-[var(--bg-elevated)] border-[var(--border-mid)] shadow-elevated",
  glass:
    "bg-[var(--glass-bg)] backdrop-blur-[12px] border-[var(--glass-border)] shadow-card",
};

export function Card({
  children,
  className = "",
  variant = "default",
  glow = false,
  ...rest
}: CardProps) {
  const glowClasses = glow
    ? "hover:border-[var(--border-strong)] hover:shadow-accent"
    : "hover:border-[var(--border-mid)]";

  return (
    <div
      {...rest}
      className={`rounded-lg border transition-all duration-200 ${variantClasses[variant]} ${glowClasses} ${className}`}
    >
      {children}
    </div>
  );
}
