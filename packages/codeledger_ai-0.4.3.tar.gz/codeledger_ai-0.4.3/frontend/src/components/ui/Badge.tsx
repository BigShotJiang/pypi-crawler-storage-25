import { HTMLAttributes, ReactNode } from "react";

export type BadgeVariant =
  | "success"
  | "warning"
  | "danger"
  | "info"
  | "accent"
  | "cyan"
  | "ghost"
  | "pending"
  | "unverified";

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  children: ReactNode;
  variant?: BadgeVariant;
}

const variantClasses: Record<BadgeVariant, string> = {
  success:
    "bg-[var(--success-dim)] text-[var(--success)] border-[rgba(16,185,129,0.25)]",
  warning:
    "bg-[var(--warning-dim)] text-[var(--warning)] border-[rgba(245,158,11,0.25)]",
  danger:
    "bg-[var(--danger-dim)] text-[var(--danger)] border-[rgba(239,68,68,0.25)]",
  info:
    "bg-[var(--info-dim)] text-[var(--info)] border-[rgba(59,130,246,0.25)]",
  accent:
    "bg-[var(--accent-dim)] text-[var(--accent-bright)] border-[var(--border-mid)]",
  cyan:
    "bg-[var(--cyan-dim)] text-[var(--cyan)] border-[rgba(0,212,255,0.25)]",
  ghost:
    "bg-[var(--bg-elevated)] text-[var(--text-secondary)] border-[var(--border-dim)]",
  pending:
    "bg-[rgba(245,158,11,0.10)] text-[var(--warning)] border-[rgba(245,158,11,0.25)]",
  unverified:
    "bg-[var(--bg-elevated)] text-[var(--text-tertiary)] border-[var(--border-dim)]",
};

export function Badge({
  children,
  variant = "ghost",
  className = "",
  ...rest
}: BadgeProps) {
  return (
    <span
      {...rest}
      className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium border ${variantClasses[variant]} ${className}`}
    >
      {children}
    </span>
  );
}
