import { useEffect, useState } from "react";
import { AlertTriangle, KeyRound } from "lucide-react";
import { Button, Card, Input } from "../components/ui";

type ProviderState = {
  configured: boolean;
  setup_command: string;
};

type ProvidersResponse = {
  google?: ProviderState;
  github?: ProviderState;
};

const OAUTH_ERROR_MESSAGES: Record<string, string> = {
  oauth_denied: "Login cancelled at the provider.",
  oauth_csrf: "Security check failed. Start the sign-in again.",
  oauth_invalid: "Invalid response from the provider. Try again.",
  oauth_exchange_failed:
    "Could not complete the sign-in. Check the server logs for details.",
  oauth_userinfo_failed:
    "Provider did not return a profile. Try again or use a bearer token.",
  oauth_no_email:
    "Provider did not return a verified email address for this account.",
  oauth_not_configured:
    "OAuth is not configured on the server. Run codeledger config set-oauth.",
};

export function LoginView({ onLogin }: { onLogin: (token: string) => void }) {
  const [token, setToken] = useState("");
  const [providers, setProviders] = useState<ProvidersResponse | null>(null);
  const [oauthHint, setOauthHint] = useState<string | null>(null);

  useEffect(() => {
    // Handle a return trip from /api/auth/oauth/{provider}/callback.
    // The callback writes the JWT to an HttpOnly codeledger_session
    // cookie, so the SPA only needs a local marker to flip its auth
    // gate — the cookie itself is invisible to JS by design.
    const params = new URLSearchParams(window.location.search);
    const oauth = params.get("oauth");
    const oauthError = params.get("oauth_error");

    if (oauth === "success") {
      localStorage.setItem("cl.cookie_session", "1");
      localStorage.removeItem("cl.token");
      // Strip the marker so a manual refresh doesn't re-trigger.
      window.history.replaceState(null, "", window.location.pathname);
      onLogin("");
      return;
    }

    if (oauthError) {
      setOauthHint(
        OAUTH_ERROR_MESSAGES[oauthError] ?? "Sign-in failed. Try again.",
      );
      window.history.replaceState(null, "", window.location.pathname);
    }
  }, [onLogin]);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/auth/oauth/providers")
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (!cancelled && data) setProviders(data);
      })
      .catch(() => {
        if (!cancelled) setProviders(null);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  function startOAuth(provider: "google" | "github") {
    const state = providers?.[provider];
    if (state && !state.configured) {
      setOauthHint(
        `${provider[0].toUpperCase()}${provider.slice(1)} OAuth is not configured. Run: ${state.setup_command}`,
      );
      return;
    }
    window.location.href = `/api/auth/oauth/${provider}`;
  }

  const googleConfigured = providers?.google?.configured ?? true;
  const githubConfigured = providers?.github?.configured ?? true;

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative">
      <Card variant="glass" className="w-full max-w-md p-8 space-y-5">
        <div className="flex flex-col items-center space-y-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[var(--accent)] to-[var(--accent-mid)] flex items-center justify-center shadow-accent">
            <svg width="22" height="22" viewBox="0 0 14 14" fill="none" aria-hidden="true">
              <rect x="1" y="2" width="12" height="2" rx="1" fill="white" opacity="0.9" />
              <rect x="1" y="6" width="8" height="2" rx="1" fill="white" opacity="0.7" />
              <rect x="1" y="10" width="10" height="2" rx="1" fill="white" opacity="0.5" />
            </svg>
          </div>
          <h1 className="font-display text-2xl font-semibold text-[var(--text-primary)] tracking-tight">
            Sign in to CodeLedger
          </h1>
          <p className="text-xs text-[var(--text-secondary)] text-center max-w-xs">
            Paste your solo bearer token, or sign in with OAuth. Run{" "}
            <code className="font-mono text-[var(--accent-bright)]">
              codeledger token show
            </code>{" "}
            to see your token.
          </p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            const trimmed = token.trim();
            if (trimmed) {
              localStorage.setItem("cl.token", trimmed);
              onLogin(trimmed);
            }
          }}
          className="space-y-3"
        >
          <label
            htmlFor="solo-token"
            className="block text-xs font-medium uppercase tracking-widest text-[var(--text-secondary)]"
          >
            Solo bearer token
          </label>
          <Input
            id="solo-token"
            type="password"
            placeholder="cl_solo_…"
            value={token}
            onChange={(e) => setToken(e.target.value)}
          />
          <Button type="submit" variant="primary" size="md" className="w-full">
            <KeyRound size={14} strokeWidth={2} />
            Sign in with token
          </Button>
        </form>

        <div className="flex items-center gap-3 text-xs text-[var(--text-tertiary)]">
          <div className="flex-1 h-px bg-[var(--border-dim)]" />
          <span>or continue with</span>
          <div className="flex-1 h-px bg-[var(--border-dim)]" />
        </div>

        <div className="grid grid-cols-2 gap-2">
          <Button
            type="button"
            variant="secondary"
            size="md"
            disabled={!googleConfigured}
            onClick={() => startOAuth("google")}
          >
            Google
          </Button>
          <Button
            type="button"
            variant="secondary"
            size="md"
            disabled={!githubConfigured}
            onClick={() => startOAuth("github")}
          >
            GitHub
          </Button>
        </div>

        {oauthHint && (
          <div className="flex items-start gap-2 text-xs text-[var(--warning)] bg-[var(--warning-dim)] border border-[rgba(245,158,11,0.25)] rounded-md p-3">
            <AlertTriangle size={13} strokeWidth={2} className="flex-shrink-0 mt-0.5" />
            <span>{oauthHint}</span>
          </div>
        )}
      </Card>
    </div>
  );
}
