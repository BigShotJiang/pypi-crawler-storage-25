import { useState } from "react";
import {
  CheckCircle2,
  CircleDot,
  Database,
  ExternalLink,
  MessageSquare,
  Plug,
  Briefcase,
  Folder,
  type LucideIcon,
} from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "../api/client";
import { Badge, Button, Card, Input } from "../components/ui";

type AuthType = "oauth2" | "api_key" | "connection_string" | "basic";

interface ConnectorRow {
  slug: string;
  display_name: string;
  category: string;
  description: string;
  auth_type: AuthType;
  configured: boolean;
  connect_url: string | null;
}

const CATEGORY_ICON: Record<string, LucideIcon> = {
  communication: MessageSquare,
  project_management: Briefcase,
  cloud_storage: Folder,
  database: Database,
  ci_cd: Plug,
  analytics: Plug,
};

const CATEGORY_LABEL: Record<string, string> = {
  communication: "Communication",
  project_management: "Project management",
  cloud_storage: "Cloud storage",
  database: "Database",
  ci_cd: "CI / CD",
  analytics: "Analytics",
};

const CATEGORY_ORDER = [
  "communication",
  "project_management",
  "cloud_storage",
  "database",
  "ci_cd",
  "analytics",
];

function groupByCategory(
  connectors: ConnectorRow[],
): Array<[string, ConnectorRow[]]> {
  const groups = new Map<string, ConnectorRow[]>();
  for (const c of connectors) {
    const key = c.category || "other";
    const bucket = groups.get(key) ?? [];
    bucket.push(c);
    groups.set(key, bucket);
  }
  return CATEGORY_ORDER.filter((c) => groups.has(c)).map(
    (c) => [c, groups.get(c)!] as [string, ConnectorRow[]],
  );
}

function ConnectorCard({
  row,
  onChanged,
}: {
  row: ConnectorRow;
  onChanged: () => void;
}) {
  const [setupOpen, setSetupOpen] = useState(false);
  const [credentialValue, setCredentialValue] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const Icon = CATEGORY_ICON[row.category] ?? Plug;

  const startOAuth = () => {
    if (!row.connect_url) return;
    window.location.href = row.connect_url;
  };

  const handleSubmitSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!credentialValue.trim()) {
      setError("Value is required");
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      const field =
        row.auth_type === "api_key" ? "api_key" : "connection_string";
      await api.connectors.setup(row.slug, { [field]: credentialValue });
      setCredentialValue("");
      setSetupOpen(false);
      onChanged();
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Setup failed";
      setError(message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDisconnect = async () => {
    if (
      !window.confirm(
        `Disconnect ${row.display_name}? Stored credentials will be cleared.`,
      )
    ) {
      return;
    }
    try {
      await api.connectors.disconnect(row.slug);
      onChanged();
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Disconnect failed";
      setError(message);
    }
  };

  const placeholder =
    row.auth_type === "api_key"
      ? "Paste API key"
      : "JSON config or DSN (see connector docs)";

  return (
    <Card glow className="p-4 flex flex-col gap-3">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-lg bg-[var(--accent-dim)] border border-[var(--border-dim)] flex items-center justify-center">
          <Icon
            size={16}
            className="text-[var(--accent-bright)]"
            aria-hidden="true"
          />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-[var(--text-primary)] truncate">
              {row.display_name}
            </span>
            {row.configured && (
              <CheckCircle2
                size={14}
                className="text-[var(--success)] shrink-0"
                aria-label="Configured"
              />
            )}
          </div>
          <div className="text-xs text-[var(--text-secondary)] mt-0.5 line-clamp-2">
            {row.description || row.slug}
          </div>
        </div>
        <Badge variant="ghost" title={row.auth_type}>
          <span className="font-mono text-[10px]">{row.auth_type}</span>
        </Badge>
      </div>

      <div className="flex items-center gap-2">
        {row.configured ? (
          <Button
            type="button"
            variant="secondary"
            size="sm"
            onClick={handleDisconnect}
          >
            Disconnect
          </Button>
        ) : row.auth_type === "oauth2" ? (
          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={startOAuth}
            disabled={!row.connect_url}
          >
            <ExternalLink size={11} strokeWidth={2} />
            Connect
          </Button>
        ) : (
          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={() => setSetupOpen((v) => !v)}
          >
            <Plug size={11} strokeWidth={2} />
            {setupOpen ? "Cancel" : "Connect"}
          </Button>
        )}
      </div>

      {setupOpen && !row.configured && row.auth_type !== "oauth2" && (
        <form onSubmit={handleSubmitSetup} className="space-y-2">
          <Input
            type="password"
            autoComplete="off"
            placeholder={placeholder}
            value={credentialValue}
            onChange={(e) => setCredentialValue(e.target.value)}
            aria-label={`${row.display_name} credential`}
          />
          <div className="flex items-center gap-2">
            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={submitting}
            >
              {submitting ? "Connecting…" : "Save"}
            </Button>
            <p className="text-[10px] text-[var(--text-tertiary)]">
              Stored encrypted in the local vault — never sent to third parties.
            </p>
          </div>
          {error && (
            <p className="text-xs text-[var(--danger)]">{error}</p>
          )}
        </form>
      )}

      {error && !setupOpen && (
        <p className="text-xs text-[var(--danger)]">{error}</p>
      )}
    </Card>
  );
}

export function ConnectorsView() {
  const queryClient = useQueryClient();
  const { data, isLoading, error } = useQuery({
    queryKey: ["connectors-status"],
    queryFn: () => api.connectors.status(),
    retry: false,
  });

  const refresh = () =>
    queryClient.invalidateQueries({ queryKey: ["connectors-status"] });

  if (isLoading) {
    return (
      <div className="p-6 text-sm text-[var(--text-secondary)]">
        Loading connectors…
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="p-6 text-sm text-[var(--danger)]">
        Failed to load connectors. Is the server reachable?
      </div>
    );
  }

  const connectors = data.connectors;
  const connected = connectors.filter((c) => c.configured);
  const available = connectors.filter((c) => !c.configured);
  const availableGrouped = groupByCategory(available);

  return (
    <div className="space-y-8">
      {connected.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-[var(--text-secondary)] flex items-center gap-2">
            <CircleDot
              size={13}
              className="text-[var(--success)]"
              aria-hidden="true"
            />
            Connected ({connected.length})
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {connected.map((row) => (
              <ConnectorCard key={row.slug} row={row} onChanged={refresh} />
            ))}
          </div>
        </section>
      )}

      <section className="space-y-5">
        <h2 className="text-xs font-semibold uppercase tracking-widest text-[var(--text-secondary)] flex items-center gap-2">
          <Plug
            size={13}
            className="text-[var(--accent-bright)]"
            aria-hidden="true"
          />
          Available ({available.length})
        </h2>
        {availableGrouped.length === 0 && (
          <p className="text-sm text-[var(--text-secondary)]">
            Every registered connector is already configured.
          </p>
        )}
        {availableGrouped.map(([category, rows]) => (
          <div key={category} className="space-y-2">
            <h3 className="text-xs font-medium text-[var(--text-tertiary)]">
              {CATEGORY_LABEL[category] ?? category}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {rows.map((row) => (
                <ConnectorCard key={row.slug} row={row} onChanged={refresh} />
              ))}
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}
