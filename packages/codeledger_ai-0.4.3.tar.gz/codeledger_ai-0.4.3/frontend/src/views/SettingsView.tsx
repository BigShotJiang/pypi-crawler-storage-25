import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Copy,
  ExternalLink,
  HelpCircle,
  Moon,
  Palette,
  Shield,
  Sun,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { api } from "../api/client";
import { useAppStore } from "../store/appStore";
import { useProjectStore } from "../store/projectStore";
import { Badge, Button, Card } from "../components/ui";

const SEC_DESCRIPTIONS: Record<string, string> = {
  "SEC-01":
    "No credentials stored in the database — only one-way hashes (Argon2id, SHA-256).",
  "SEC-02":
    "No credentials leaked in logs — all log output passes through a redactor.",
  "SEC-03": "No credentials returned from MCP tool responses.",
  "SEC-04":
    "Plaintext credentials never written to disk outside the OS keyring.",
  "SEC-05":
    "Authentication required on every HTTP endpoint and MCP tool call.",
  "SEC-06":
    "OAuth flows enforce state parameter and PKCE with S256 challenge.",
  "SEC-07":
    "Password hashing uses Argon2id (64MB, 3 iterations, parallelism 4).",
  "SEC-08": "JWT signing key lives exclusively in the credential vault.",
  "SEC-09": "Config, vault, and database files are not world-readable.",
  "SEC-10": "Personal access tokens are SHA-256 hashed before storage.",
  "SEC-11":
    "Every structural AST change produces a linked decision or an audit record.",
};

// Short list surfaced on the Settings page for common integrations. The
// slug on each row matches the backend connector slug registered in
// backend/connectors/bootstrap.py. Full connector management lives in the
// dedicated Connectors tab — this section is just a quick-access shortcut.
const AVAILABLE_SERVICES = [
  {
    id: "github_issues",
    name: "GitHub",
    hint: "Link GitHub issues and PRs to decisions",
  },
  {
    id: "linear",
    name: "Linear",
    hint: "Link Linear issues to decisions",
  },
  {
    id: "jira",
    name: "Jira",
    hint: "Link Jira tickets to decisions",
  },
  {
    id: "slack",
    name: "Slack",
    hint: "Search Slack messages, link threads to decisions",
  },
];

function CopyButton({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      /* clipboard API unavailable — leave state as-is */
    }
  };
  return (
    <button
      type="button"
      onClick={copy}
      aria-label={label ?? "Copy to clipboard"}
      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium border border-[var(--border-mid)] bg-[var(--bg-elevated)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--border-strong)] transition-all focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
    >
      {copied ? (
        <>
          <Check size={11} strokeWidth={2.5} className="text-[var(--success)]" />
          <span className="text-[var(--success)]">Copied</span>
        </>
      ) : (
        <>
          <Copy size={11} strokeWidth={2} />
          <span>Copy</span>
        </>
      )}
    </button>
  );
}

function SectionHeading({
  icon: Icon,
  children,
}: {
  icon: LucideIcon;
  children: React.ReactNode;
}) {
  return (
    <h2 className="text-xs font-semibold uppercase tracking-widest text-[var(--text-secondary)] flex items-center gap-2">
      <Icon size={13} className="text-[var(--accent-bright)]" aria-hidden={true} />
      {children}
    </h2>
  );
}

export function SettingsView() {
  const { data: status } = useQuery({
    queryKey: ["security-status"],
    queryFn: () => api.security.status(),
    retry: false,
  });
  const {
    data: connectorStatus,
    refetch: refetchConnectors,
  } = useQuery({
    queryKey: ["connectors-status"],
    queryFn: () => api.connectors.status(),
    retry: false,
  });
  const {
    data: setupStatus,
    refetch: refetchSetup,
  } = useQuery({
    queryKey: ["setup-status"],
    queryFn: () => api.setup.status(),
    retry: false,
  });
  const theme = useAppStore((s) => s.theme);
  const toggleTheme = useAppStore((s) => s.toggleTheme);
  const setBackend = useProjectStore((s) => s.setBackend);
  const queryClient = useQueryClient();

  const currentBackend =
    setupStatus?.change_detection_backend ??
    useProjectStore.getState().changeDetectionBackend;
  const gitAvailable = setupStatus?.git_available ?? true;
  const [switching, setSwitching] = useState<"git" | "file_watcher" | null>(
    null,
  );
  const [switchResult, setSwitchResult] = useState<{
    ok: boolean;
    message: string;
  } | null>(null);

  const switchBackend = async (next: "git" | "file_watcher") => {
    if (next === currentBackend || switching) return;
    setSwitching(next);
    setSwitchResult(null);
    try {
      const res = await api.server.setChangeDetectionBackend(next);
      setBackend(res.backend);
      setSwitchResult({ ok: true, message: res.message });
      await refetchSetup();
      queryClient.invalidateQueries({ queryKey: ["security-status"] });
    } catch (err) {
      const detail =
        err instanceof Error ? err.message : "Backend switch failed";
      setSwitchResult({ ok: false, message: detail });
    } finally {
      setSwitching(null);
    }
  };

  const [openSec, setOpenSec] = useState<Set<string>>(new Set());

  const connectorBySlug = (slug: string) =>
    connectorStatus?.connectors.find((c) => c.slug === slug) ?? null;

  const handleConnect = (slug: string) => {
    // Navigate to the real connector OAuth flow — server-side redirect
    // handles state cookie + PKCE + provider handoff. No fake client-only
    // "connected" state: the truth comes from /api/connectors/status.
    const conn = connectorBySlug(slug);
    if (conn?.connect_url) {
      window.location.href = conn.connect_url;
    }
  };

  const handleDisconnect = async (slug: string) => {
    if (!window.confirm("Clear stored credentials for this service?")) return;
    try {
      await api.connectors.disconnect(slug);
    } finally {
      await refetchConnectors();
    }
  };

  const toggleSec = (id: string) =>
    setOpenSec((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  return (
    <div className="grid grid-cols-3 gap-6">
      <div className="space-y-6">
        <section className="space-y-3">
          <SectionHeading icon={ExternalLink}>Connected services</SectionHeading>
          <div className="space-y-2">
            {AVAILABLE_SERVICES.map((svc) => {
              const conn = connectorBySlug(svc.id);
              const isConnected = Boolean(conn?.configured);
              const canConnect = Boolean(conn?.connect_url);
              return (
                <Card key={svc.id} glow className="p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm text-[var(--text-primary)]">
                          {svc.name}
                        </span>
                        {isConnected && <Badge variant="success">Connected</Badge>}
                      </div>
                      <div className="text-xs text-[var(--text-secondary)] mt-0.5">
                        {svc.hint}
                      </div>
                    </div>
                    {isConnected ? (
                      <Button
                        type="button"
                        variant="secondary"
                        size="sm"
                        onClick={() => handleDisconnect(svc.id)}
                      >
                        Disconnect
                      </Button>
                    ) : (
                      <Button
                        type="button"
                        variant="primary"
                        size="sm"
                        onClick={() => handleConnect(svc.id)}
                        disabled={!canConnect}
                        title={
                          canConnect
                            ? undefined
                            : "Connector backend not available"
                        }
                      >
                        Connect
                      </Button>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
          <p className="text-[10px] text-[var(--text-tertiary)] mt-1">
            For the full marketplace (databases, more SaaS), use the Connectors
            tab.
          </p>
        </section>

        <section className="space-y-3">
          <SectionHeading icon={Zap}>Personal access tokens</SectionHeading>
          <Card className="p-4 space-y-3">
            <p className="text-xs text-[var(--text-secondary)]">
              Manage PATs from the CLI.
            </p>
            <div className="flex items-center gap-2">
              <code className="flex-1 text-xs font-mono bg-[var(--bg-elevated)] border border-[var(--border-dim)] rounded-md px-3 py-2 text-[var(--accent-bright)] overflow-x-auto">
                codeledger token generate
              </code>
              <CopyButton
                text="codeledger token generate"
                label="Copy token generate command"
              />
            </div>
            <a
              href="https://github.com/deepsaini80537/codeledge#personal-access-tokens"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-xs text-[var(--accent-bright)] hover:text-[var(--accent)] underline focus:ring-2 focus:ring-[var(--accent)] focus:outline-none rounded"
            >
              View token documentation
              <ExternalLink size={11} strokeWidth={2} />
            </a>
          </Card>
        </section>
      </div>

      <div className="space-y-6">
        <section className="space-y-3">
          <SectionHeading icon={Palette}>Appearance</SectionHeading>
          <Card className="p-4 space-y-3">
            <div className="text-xs text-[var(--text-secondary)]">
              Current theme:{" "}
              <span className="text-[var(--text-primary)] font-medium">
                {theme === "dark" ? "Dark" : "Light"}
              </span>
            </div>
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={
                theme === "dark" ? "Switch to light mode" : "Switch to dark mode"
              }
              className="inline-flex items-center gap-2 rounded-lg border border-[var(--border-mid)] bg-[var(--bg-elevated)] text-[var(--text-primary)] px-3 py-2 text-sm hover:border-[var(--border-strong)] hover:shadow-glow-sm transition-all focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
            >
              {theme === "dark" ? (
                <Moon size={14} className="text-[var(--accent-bright)]" />
              ) : (
                <Sun size={14} className="text-[var(--warning)]" />
              )}
              <span>{theme === "dark" ? "Dark mode" : "Light mode"}</span>
            </button>
          </Card>
        </section>

        <section className="space-y-3">
          <SectionHeading icon={HelpCircle}>Project</SectionHeading>
          <Card className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-[var(--text-secondary)]">
                Change detection backend
              </span>
              <Badge variant={currentBackend === "git" ? "cyan" : "warning"}>
                <span className="font-mono">{currentBackend}</span>
              </Badge>
            </div>
            <div className="space-y-2">
              {(["git", "file_watcher"] as const).map((option) => {
                const selected = option === currentBackend;
                const disabled =
                  (option === "git" && !gitAvailable) || switching !== null;
                const disabledReason =
                  option === "git" && !gitAvailable
                    ? "No .git/ directory in the project root."
                    : undefined;
                return (
                  <label
                    key={option}
                    className={`flex items-start gap-2 p-2 rounded-md border ${
                      selected
                        ? "border-[var(--accent)] bg-[var(--bg-elevated)]"
                        : "border-[var(--border-dim)]"
                    } ${
                      disabled
                        ? "opacity-50 cursor-not-allowed"
                        : "cursor-pointer hover:border-[var(--border-strong)]"
                    }`}
                    title={disabledReason}
                  >
                    <input
                      type="radio"
                      name="change-detection-backend"
                      value={option}
                      checked={selected}
                      disabled={disabled}
                      onChange={() => switchBackend(option)}
                      className="mt-0.5"
                    />
                    <span className="text-xs">
                      <span className="font-mono text-[var(--text-primary)]">
                        {option}
                      </span>
                      <span className="block text-[var(--text-secondary)] mt-0.5">
                        {option === "git"
                          ? "Post-commit hooks. Commit hashes anchor provenance. Enables CI verification and rollback-by-commit."
                          : "watchdog file observer. Snapshot IDs anchor provenance. Works in non-git directories. CI verification unavailable."}
                      </span>
                    </span>
                  </label>
                );
              })}
            </div>
            {switching !== null && (
              <p className="text-xs text-[var(--text-secondary)]">
                Switching to{" "}
                <code className="font-mono">{switching}</code>…
              </p>
            )}
            {switchResult && (
              <p
                className={`text-xs ${
                  switchResult.ok
                    ? "text-[var(--accent-bright)]"
                    : "text-[var(--danger)]"
                }`}
              >
                {switchResult.message}
              </p>
            )}
            {currentBackend === "file_watcher" && (
              <p className="text-xs text-[var(--warning)]">
                CI verification unavailable in file-watcher mode.
              </p>
            )}
          </Card>
        </section>
      </div>

      <section className="space-y-3">
        <SectionHeading icon={Shield}>Security status</SectionHeading>
        <div className="space-y-1.5">
          {status?.invariants.map((inv) => {
            const isOpen = openSec.has(inv.id);
            const passed = inv.status === "pass";
            return (
              <Card key={inv.id} className="overflow-hidden p-0">
                <button
                  type="button"
                  onClick={() => toggleSec(inv.id)}
                  aria-expanded={isOpen}
                  className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-[var(--bg-hover)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)]"
                >
                  <span className="flex items-center gap-2">
                    {isOpen ? (
                      <ChevronDown size={12} className="text-[var(--text-tertiary)]" />
                    ) : (
                      <ChevronRight size={12} className="text-[var(--text-tertiary)]" />
                    )}
                    <span className="font-mono text-[var(--text-primary)]">
                      {inv.id}
                    </span>
                  </span>
                  <span className="flex items-center gap-2">
                    {inv.id === "SEC-11" && inv.total_unlinked !== undefined && (
                      <span className="text-xs font-mono text-[var(--text-tertiary)]">
                        {inv.total_unlinked} total (
                        {inv.unlinked_commits ?? 0} git,{" "}
                        {inv.unlinked_file_changes ?? 0} file watcher)
                      </span>
                    )}
                    <Badge variant={passed ? "success" : "warning"}>
                      {passed && (
                        <CheckCircle2 size={10} strokeWidth={2.5} className="mr-1" />
                      )}
                      {inv.status}
                    </Badge>
                  </span>
                </button>
                {isOpen && (
                  <div className="px-3 pb-3 pt-1 border-t border-[var(--border-dim)] text-xs text-[var(--text-secondary)] leading-relaxed">
                    {SEC_DESCRIPTIONS[inv.id] ?? "No description available."}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      </section>
    </div>
  );
}
