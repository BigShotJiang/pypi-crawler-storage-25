import { useEffect, useState } from "react";
import { CheckCircle2, Circle, SkipForward } from "lucide-react";
import { Button, Card } from "../components/ui";

type SetupStatus = {
  setup_complete: boolean;
  step_reached: number;
  project_name: string;
  change_detection_backend: "git" | "file_watcher";
  mode: "solo" | "team";
  port: number;
  decisions_count: number;
  sessions_count: number;
};

async function fetchStatus(): Promise<SetupStatus> {
  const res = await fetch("/api/setup/status");
  return res.json();
}

async function postComplete(step: number, complete: boolean): Promise<void> {
  await fetch("/api/setup/complete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ step_reached: step, complete }),
  });
}

function StepIndicator({ current, total }: { current: number; total: number }) {
  return (
    <div className="flex items-center gap-2 mb-6">
      {Array.from({ length: total }, (_, i) => {
        const active = i < current;
        return (
          <div
            key={i}
            className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${
              active
                ? "bg-gradient-to-r from-[var(--accent)] to-[var(--accent-bright)] shadow-glow-sm"
                : "bg-[var(--bg-elevated)]"
            }`}
          />
        );
      })}
      <span className="text-xs font-mono text-[var(--text-tertiary)] ml-2">
        {current}/{total}
      </span>
    </div>
  );
}

function CodeBlock({ children }: { children: React.ReactNode }) {
  return (
    <pre className="bg-[var(--bg-elevated)] border border-[var(--border-dim)] rounded-md px-4 py-3 text-xs font-mono text-[var(--accent-bright)] whitespace-pre-wrap overflow-x-auto">
      {children}
    </pre>
  );
}

function StatusPill({ ok, children }: { ok: boolean; children: React.ReactNode }) {
  return (
    <div
      className={`flex items-center gap-2 text-sm ${
        ok ? "text-[var(--success)]" : "text-[var(--text-secondary)]"
      }`}
    >
      {ok ? (
        <CheckCircle2 size={14} strokeWidth={2} />
      ) : (
        <Circle size={14} strokeWidth={2} className="text-[var(--text-tertiary)]" />
      )}
      {children}
    </div>
  );
}

function StepWelcome({
  status,
  onNext,
}: {
  status: SetupStatus;
  onNext: () => void;
}) {
  return (
    <div className="space-y-5">
      <div className="space-y-2">
        <h1 className="font-display text-2xl font-semibold text-[var(--text-primary)] tracking-tight">
          Welcome to CodeLedger
        </h1>
        <p className="text-sm text-[var(--text-secondary)]">
          Ask why any function exists. Get the decision that created it.
        </p>
      </div>
      <p className="text-sm text-[var(--text-primary)]">
        CodeLedger is running. Your MCP server is live at{" "}
        <code className="font-mono text-[var(--accent-bright)] bg-[var(--bg-elevated)] px-1.5 py-0.5 rounded-md">
          http://localhost:{status.port}/mcp
        </code>
        .
      </p>
      <div className="space-y-2">
        <StatusPill ok>Server running on port {status.port}</StatusPill>
        <StatusPill ok>
          {status.mode === "team" ? "Team mode configured" : "Claude Code configured"}
        </StatusPill>
        <StatusPill ok={false}>
          Change detection:{" "}
          <span className="font-mono text-[var(--text-primary)]">
            {status.change_detection_backend}
          </span>
        </StatusPill>
      </div>
      <Button variant="primary" size="md" onClick={onNext}>
        Next
      </Button>
    </div>
  );
}

function StepConnectIDE({
  onNext,
  mode,
  port,
}: {
  onNext: () => void;
  mode: "solo" | "team";
  port: number;
}) {
  const [rescans, setRescans] = useState(0);
  return (
    <div className="space-y-5">
      <h1 className="font-display text-2xl font-semibold text-[var(--text-primary)] tracking-tight">
        {mode === "team" ? "Tell your team" : "Connect your IDE"}
      </h1>
      {mode === "team" ? (
        <div className="space-y-3">
          <p className="text-sm text-[var(--text-secondary)]">
            Open <code className="font-mono text-[var(--accent-bright)]">team-setup.md</code> in
            this project root and share it with your team. Each developer runs:
          </p>
          <CodeBlock>
            codeledger login --server http://&lt;your-ip&gt;:{port}
            {"\n"}codeledger connect --server http://&lt;your-ip&gt;:{port}
          </CodeBlock>
        </div>
      ) : (
        <div className="space-y-3">
          <p className="text-sm text-[var(--text-secondary)]">
            CodeLedger created{" "}
            <code className="font-mono text-[var(--accent-bright)]">CLAUDE.md</code>,{" "}
            <code className="font-mono text-[var(--accent-bright)]">.cursorrules</code>, and{" "}
            <code className="font-mono text-[var(--accent-bright)]">.windsurfrules</code>{" "}
            in your project root. Commit these so teammates get the same instructions.
          </p>
          <div className="grid grid-cols-3 gap-3">
            {[
              { name: "Claude Code", primary: true, note: "Restart Claude Code — MCP + hooks auto-connect." },
              { name: "Cursor", primary: false, note: ".cursorrules loaded automatically on project open." },
              { name: "Windsurf", primary: false, note: ".windsurfrules loaded automatically on project open." },
            ].map((client) => (
              <Card
                key={client.name}
                glow
                className={`p-3 ${
                  client.primary
                    ? "border-[var(--border-strong)] shadow-accent"
                    : ""
                }`}
              >
                <div className="font-medium text-sm text-[var(--text-primary)]">
                  {client.name}
                </div>
                <div className="text-xs text-[var(--text-secondary)] mt-1">
                  {client.note}
                </div>
              </Card>
            ))}
          </div>
          <Card className="p-3 border-[var(--border-dim)]">
            <div className="font-medium text-sm text-[var(--text-primary)]">
              Claude Desktop
            </div>
            <div className="text-xs text-[var(--text-secondary)] mt-1">
              Claude Desktop does not read project files. Run{" "}
              <code className="font-mono text-[var(--accent-bright)]">
                codeledger desktop-guide
              </code>{" "}
              and paste the output at the start of each conversation.
            </div>
          </Card>
          <p className="text-xs text-[var(--text-tertiary)]">
            Need to refresh the files later? Run{" "}
            <code className="font-mono text-[var(--accent-bright)]">
              codeledger sync
            </code>
            .
          </p>
        </div>
      )}
      <div className="flex gap-2">
        <Button
          variant="secondary"
          size="sm"
          onClick={() => setRescans(rescans + 1)}
        >
          Re-scan for clients
        </Button>
        <Button variant="primary" size="md" onClick={onNext} className="ml-auto">
          Next
        </Button>
      </div>
    </div>
  );
}

function StepFirstDecision({
  onNext,
  onStatusPoll,
}: {
  onNext: () => void;
  onStatusPoll: () => Promise<SetupStatus>;
}) {
  const [count, setCount] = useState(0);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const poll = async () => {
      const status = await onStatusPoll().catch(() => null);
      if (cancelled || !status) return;
      setCount(status.decisions_count);
      if (status.decisions_count > 0) setReady(true);
    };
    poll();
    const id = window.setInterval(poll, 3000);
    const fallback = window.setTimeout(() => setReady(true), 30000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
      window.clearTimeout(fallback);
    };
  }, [onStatusPoll]);

  return (
    <div className="space-y-5">
      <h1 className="font-display text-2xl font-semibold text-[var(--text-primary)] tracking-tight">
        Make your first decision
      </h1>
      <p className="text-sm text-[var(--text-secondary)]">
        Start a session in Claude Code and type:
      </p>
      <CodeBlock>
        {`"Use decision.create to record that we use Python 3.11
with FastAPI for this project's backend."`}
      </CodeBlock>
      <p className="text-sm text-[var(--text-secondary)]">Then come back here.</p>
      <Card
        className={`p-3 ${
          count > 0
            ? "border-[rgba(16,185,129,0.3)] shadow-[0_0_20px_rgba(16,185,129,0.08)]"
            : ""
        }`}
      >
        <StatusPill ok={count > 0}>Decisions recorded: {count}</StatusPill>
      </Card>
      <Button variant="primary" size="md" disabled={!ready} onClick={onNext}>
        Next
      </Button>
    </div>
  );
}

function StepFirstCommit({
  onNext,
  onStatusPoll,
  changeDetection,
}: {
  onNext: () => void;
  onStatusPoll: () => Promise<SetupStatus>;
  changeDetection: "git" | "file_watcher";
}) {
  const [count, setCount] = useState(0);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const poll = async () => {
      const status = await onStatusPoll().catch(() => null);
      if (cancelled || !status) return;
      setCount(status.sessions_count);
      if (status.sessions_count > 0) setReady(true);
    };
    poll();
    const id = window.setInterval(poll, 3000);
    const fallback = window.setTimeout(() => setReady(true), 30000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
      window.clearTimeout(fallback);
    };
  }, [onStatusPoll]);

  return (
    <div className="space-y-5">
      <h1 className="font-display text-2xl font-semibold text-[var(--text-primary)] tracking-tight">
        Make your first commit
      </h1>
      {changeDetection === "git" ? (
        <CodeBlock>
          {`Make any code change and commit it:

  git add . && git commit -m "first tracked commit"

CodeLedger will link it to your decision automatically.`}
        </CodeBlock>
      ) : (
        <p className="text-sm text-[var(--text-secondary)]">
          Save any <code className="font-mono text-[var(--accent-bright)]">.py</code> or{" "}
          <code className="font-mono text-[var(--accent-bright)]">.ts</code> file — CodeLedger
          will detect the change automatically.
        </p>
      )}
      <Card
        className={`p-3 ${
          count > 0
            ? "border-[rgba(16,185,129,0.3)] shadow-[0_0_20px_rgba(16,185,129,0.08)]"
            : ""
        }`}
      >
        <StatusPill ok={count > 0}>
          {changeDetection === "git" ? "Commits detected" : "File changes detected"}:{" "}
          {count}
        </StatusPill>
      </Card>
      <Button variant="primary" size="md" disabled={!ready} onClick={onNext}>
        Next
      </Button>
    </div>
  );
}

function StepFirstQuery({ onFinish }: { onFinish: () => void }) {
  return (
    <div className="space-y-5">
      <h1 className="font-display text-2xl font-semibold text-[var(--text-primary)] tracking-tight">
        Run your first provenance query
      </h1>
      <p className="text-sm text-[var(--text-secondary)]">In Claude Code, type:</p>
      <CodeBlock>
        {`"Run decision.list and show me what decisions
CodeLedger has recorded."

Or try the reverse trace — find any function in your
codebase and run:

provenance.reverse("path/to/file.py", "function_name")`}
      </CodeBlock>
      <div className="flex items-center gap-2">
        <Button variant="primary" size="md" onClick={onFinish}>
          Go to dashboard
        </Button>
        <Button variant="ghost" size="sm" onClick={onFinish} className="ml-auto">
          <SkipForward size={12} strokeWidth={2} />
          Skip setup
        </Button>
      </div>
    </div>
  );
}

export function OnboardingView({ onComplete }: { onComplete: () => void }) {
  const [status, setStatus] = useState<SetupStatus | null>(null);
  const [step, setStep] = useState<number>(1);

  useEffect(() => {
    fetchStatus().then((s) => {
      setStatus(s);
      setStep(Math.max(1, Math.min(5, s.step_reached)));
    });
  }, []);

  if (!status) {
    return (
      <div className="min-h-screen flex items-center justify-center text-[var(--text-secondary)]">
        Loading…
      </div>
    );
  }

  const advance = async (next: number) => {
    setStep(next);
    await postComplete(next, false);
  };

  const finish = async () => {
    await postComplete(5, true);
    onComplete();
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      <Card variant="glass" className="w-full max-w-xl p-8 space-y-4">
        <StepIndicator current={step} total={5} />
        {step === 1 && <StepWelcome status={status} onNext={() => advance(2)} />}
        {step === 2 && (
          <StepConnectIDE
            mode={status.mode}
            port={status.port}
            onNext={() => advance(3)}
          />
        )}
        {step === 3 && (
          <StepFirstDecision
            onStatusPoll={fetchStatus}
            onNext={() => advance(4)}
          />
        )}
        {step === 4 && (
          <StepFirstCommit
            onStatusPoll={fetchStatus}
            changeDetection={status.change_detection_backend}
            onNext={() => advance(5)}
          />
        )}
        {step === 5 && <StepFirstQuery onFinish={finish} />}
      </Card>
    </div>
  );
}
