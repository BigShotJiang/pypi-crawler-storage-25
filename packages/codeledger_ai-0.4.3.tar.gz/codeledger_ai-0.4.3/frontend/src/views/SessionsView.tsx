import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, CircleSlash, Terminal } from "lucide-react";
import { api } from "../api/client";
import { useProjectStore } from "../store/projectStore";
import { Badge, Button, Card, type BadgeVariant } from "../components/ui";

const STATUS_VARIANT: Record<string, BadgeVariant> = {
  active: "success",
  completed: "ghost",
  completed_forced: "unverified",
  completed_with_warnings: "warning",
};

function statusVariant(status: string): BadgeVariant {
  return STATUS_VARIANT[status] ?? "warning";
}

function SessionCard({
  sid,
  agent,
  status,
  startedAt,
  endedAt,
}: {
  sid: string;
  agent: string;
  status: string;
  startedAt: string;
  endedAt: string | null;
}) {
  const backend = useProjectStore((s) => s.changeDetectionBackend);
  const { data: score } = useQuery({
    queryKey: ["harness-score", sid],
    queryFn: () => api.harness.score(sid),
    retry: false,
  });
  const { data: conflictsResp } = useQuery({
    queryKey: ["conflicts", sid],
    queryFn: () => api.sessions.conflicts(sid),
    retry: false,
  });

  const critical = score?.decision_density_status === "critical";
  const hasConflict = Boolean(conflictsResp?.conflicts?.length);

  const accentBar = critical
    ? "before:bg-[var(--danger)]"
    : hasConflict
      ? "before:bg-[var(--warning)]"
      : "before:bg-transparent";

  return (
    <Card
      glow
      className={`relative overflow-hidden p-4 pl-5 space-y-2 before:content-[''] before:absolute before:left-0 before:top-0 before:h-full before:w-1 ${accentBar}`}
    >
      <div className="flex items-center gap-2 flex-wrap">
        <Badge variant={statusVariant(status)}>{status}</Badge>
        {backend === "file_watcher" && (
          <Badge variant="warning">file watcher</Badge>
        )}
        {critical && (
          <Badge variant="danger">
            <AlertTriangle size={10} strokeWidth={2.5} className="mr-1" />
            no decisions recorded
          </Badge>
        )}
        {hasConflict && (
          <Badge variant="warning">
            <CircleSlash size={10} strokeWidth={2.5} className="mr-1" />
            conflict
          </Badge>
        )}
        <span className="ml-auto text-xs font-mono text-[var(--text-tertiary)]">
          {new Date(startedAt).toLocaleString()}
          {endedAt ? ` → ${new Date(endedAt).toLocaleTimeString()}` : ""}
        </span>
      </div>
      <div className="flex items-center gap-2 font-medium text-[var(--text-primary)]">
        <Terminal size={14} className="text-[var(--accent-bright)]" aria-hidden="true" />
        {agent}
      </div>
      {score && (
        <div className="text-xs text-[var(--text-secondary)] flex gap-4 font-mono">
          <span>
            density:{" "}
            <span className="text-[var(--text-primary)]">
              {score.decision_density.toFixed(2)}
            </span>
          </span>
          <span>
            status:{" "}
            <span className="text-[var(--text-primary)]">{score.harness_status}</span>
          </span>
          <span>
            changes:{" "}
            <span className="text-[var(--text-primary)]">{score.structural_changes}</span>
          </span>
        </div>
      )}
      {hasConflict && (
        <p className="text-xs italic text-[var(--warning)]">
          Overlaps with {conflictsResp?.conflicts.length} other session(s).
        </p>
      )}
    </Card>
  );
}

export function SessionsView() {
  const { data: sessions = [], isLoading, refetch } = useQuery({
    queryKey: ["sessions"],
    queryFn: () => api.sessions.list(),
  });

  if (isLoading) {
    return (
      <div
        role="status"
        className="flex items-center justify-center h-48 text-[var(--text-secondary)]"
      >
        Loading sessions…
      </div>
    );
  }

  if (sessions.length === 0) {
    return (
      <div
        role="status"
        className="flex flex-col items-center justify-center py-20 space-y-3"
      >
        <div className="w-12 h-12 rounded-xl bg-[var(--accent-dim)] border border-[var(--border-mid)] flex items-center justify-center">
          <Terminal size={20} className="text-[var(--accent-bright)]" aria-hidden="true" />
        </div>
        <div className="text-sm font-medium text-[var(--text-primary)]">
          No sessions recorded yet
        </div>
        <p className="text-xs text-[var(--text-secondary)] max-w-md text-center">
          Sessions are automatically captured when Claude runs a task via the
          MCP server.
        </p>
        <Button variant="secondary" size="sm" onClick={() => refetch()}>
          Refresh
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {sessions.map((s) => (
        <SessionCard
          key={s.id}
          sid={s.id}
          agent={s.agent_name}
          status={s.status}
          startedAt={s.started_at}
          endedAt={s.ended_at}
        />
      ))}
    </div>
  );
}
