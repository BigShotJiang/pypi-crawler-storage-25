import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Brain,
  FileText,
  GitBranch,
  Search,
  Terminal as TerminalIcon,
  type LucideIcon,
} from "lucide-react";
import { api } from "../api/client";
import { Badge, Button, Card, Input, Select, type BadgeVariant } from "../components/ui";

type Filter = "all" | "decision" | "story" | "session";
type Sort = "relevance" | "type";

type Item = {
  item_id: string;
  item_type: string;
  score: number;
  token_count: number;
};

const PAGE_SIZES = [10, 25, 50];

const TYPE_META: Record<
  string,
  { icon: LucideIcon; variant: BadgeVariant }
> = {
  decision: { icon: GitBranch, variant: "accent" },
  story: { icon: FileText, variant: "info" },
  session: { icon: TerminalIcon, variant: "ghost" },
};

function typeMeta(t: string) {
  return TYPE_META[t] ?? { icon: FileText, variant: "ghost" as BadgeVariant };
}

function Highlight({ text, term }: { text: string; term: string }) {
  if (!term.trim()) return <>{text}</>;
  const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const parts = text.split(new RegExp(`(${escaped})`, "ig"));
  return (
    <>
      {parts.map((p, i) =>
        p.toLowerCase() === term.toLowerCase() ? (
          <mark
            key={i}
            className="bg-[var(--accent-dim)] text-[var(--accent-bright)] rounded px-0.5"
          >
            {p}
          </mark>
        ) : (
          <span key={i}>{p}</span>
        ),
      )}
    </>
  );
}

export function MemoryView() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  const [submitted, setSubmitted] = useState("");
  const [sort, setSort] = useState<Sort>("relevance");
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(10);

  const { data, isLoading, isError } = useQuery({
    queryKey: ["context-relevant", submitted],
    queryFn: () =>
      submitted
        ? api.context.relevant({ query: submitted, token_budget: 8000 })
        : Promise.resolve(null),
    enabled: Boolean(submitted),
  });

  const allItems: Item[] = useMemo(
    () => [
      ...(data?.included_items ?? []),
      ...(data?.summarized_items ?? []),
    ],
    [data],
  );

  const filtered = useMemo(
    () => allItems.filter((i) => filter === "all" || i.item_type === filter),
    [allItems, filter],
  );

  const sorted = useMemo(() => {
    const arr = [...filtered];
    if (sort === "type") arr.sort((a, b) => a.item_type.localeCompare(b.item_type));
    else arr.sort((a, b) => b.score - a.score);
    return arr;
  }, [filtered, sort]);

  const total = sorted.length;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const safePage = Math.min(page, pages - 1);
  const pageStart = safePage * pageSize;
  const visible = sorted.slice(pageStart, pageStart + pageSize);

  const usage = data
    ? Math.round((data.total_tokens_used / data.token_budget) * 100)
    : 0;
  const budgetBarColor =
    usage > 80 ? "bg-[var(--danger)]" : "bg-gradient-to-r from-[var(--accent)] to-[var(--accent-bright)]";

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(query);
    setPage(0);
  };

  return (
    <div className="space-y-6">
      <form onSubmit={onSubmit} className="flex gap-3">
        <div className="relative flex-1">
          <Search
            size={15}
            className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-tertiary)]"
            aria-hidden="true"
          />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Escape") {
                setQuery("");
                setSubmitted("");
              }
            }}
            placeholder="Search memory — decisions, stories, sessions…"
            aria-label="Search memory"
            className="pl-10 h-11"
          />
        </div>
        <Select
          value={filter}
          onChange={(e) => {
            setFilter(e.target.value as Filter);
            setPage(0);
          }}
          aria-label="Filter by type"
          className="w-36 h-11"
        >
          <option value="all">All types</option>
          <option value="decision">Decisions</option>
          <option value="story">Stories</option>
          <option value="session">Sessions</option>
        </Select>
        <Select
          value={sort}
          onChange={(e) => setSort(e.target.value as Sort)}
          aria-label="Sort order"
          className="w-40 h-11"
        >
          <option value="relevance">Sort: Relevance</option>
          <option value="type">Sort: Type</option>
        </Select>
        <Button type="submit" variant="primary" size="md" className="h-11 px-6">
          <Search size={14} strokeWidth={2} />
          Search
        </Button>
      </form>

      {data && (
        <Card className="p-4">
          <div className="flex justify-between text-xs text-[var(--text-secondary)] mb-2">
            <span className="uppercase tracking-widest font-medium">
              Token budget
            </span>
            <span className="font-mono">
              {data.total_tokens_used.toLocaleString()} /{" "}
              {data.token_budget.toLocaleString()} ({usage}%)
            </span>
          </div>
          <div className="h-2 w-full bg-[var(--bg-elevated)] rounded-full overflow-hidden">
            <div
              className={`h-2 rounded-full transition-all duration-500 ${budgetBarColor}`}
              style={{ width: `${Math.min(usage, 100)}%` }}
            />
          </div>
        </Card>
      )}

      {!submitted && !isLoading && (
        <div
          role="status"
          className="flex flex-col items-center justify-center py-20 space-y-3"
        >
          <div className="w-12 h-12 rounded-xl bg-[var(--accent-dim)] border border-[var(--border-mid)] flex items-center justify-center">
            <Brain size={22} className="text-[var(--accent-bright)]" aria-hidden="true" />
          </div>
          <p className="text-[var(--text-secondary)] text-sm text-center max-w-sm">
            Search your project's persistent memory — decisions, user stories,
            and session logs from every Claude run.
          </p>
        </div>
      )}

      {submitted && isLoading && (
        <div role="status" className="space-y-3">
          {[0, 1, 2].map((i) => (
            <Card key={i} className="p-4 animate-pulse">
              <div className="h-3 w-1/4 bg-[var(--bg-elevated)] rounded" />
              <div className="h-3 w-3/5 bg-[var(--bg-elevated)] rounded mt-2" />
            </Card>
          ))}
        </div>
      )}

      {isError && (
        <Card className="p-4" role="alert">
          <p className="text-sm text-[var(--danger)]">Search failed.</p>
        </Card>
      )}

      {submitted && !isLoading && !isError && total === 0 && (
        <div
          role="status"
          className="flex flex-col items-center justify-center py-20 space-y-3"
        >
          <div className="w-12 h-12 rounded-xl bg-[var(--bg-elevated)] border border-[var(--border-dim)] flex items-center justify-center">
            <Search size={20} className="text-[var(--text-tertiary)]" aria-hidden="true" />
          </div>
          <div className="text-sm text-[var(--text-primary)]">
            No results for <span className="font-mono text-[var(--accent-bright)]">"{submitted}"</span>
          </div>
          <p className="text-xs text-[var(--text-secondary)] max-w-md text-center">
            Try different keywords or change the type filter.
          </p>
        </div>
      )}

      {submitted && !isLoading && total > 0 && (
        <>
          <div className="flex items-center justify-between text-xs text-[var(--text-secondary)]">
            <span>
              Showing{" "}
              <span className="text-[var(--text-primary)] font-mono">
                {pageStart + 1}–{Math.min(pageStart + pageSize, total)}
              </span>{" "}
              of <span className="text-[var(--text-primary)] font-mono">{total}</span> results
            </span>
            <label className="flex items-center gap-2">
              <span>Per page</span>
              <Select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setPage(0);
                }}
                aria-label="Results per page"
                className="w-20 py-1.5"
              >
                {PAGE_SIZES.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </Select>
            </label>
          </div>

          <div className="space-y-3">
            {visible.map((item) => {
              const { icon: Icon, variant } = typeMeta(item.item_type);
              return (
                <Card key={item.item_id} glow className="p-4 cursor-pointer group">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <div className="mt-0.5 w-8 h-8 rounded-lg flex-shrink-0 flex items-center justify-center bg-[var(--accent-dim)] border border-[var(--border-dim)]">
                        <Icon
                          size={14}
                          strokeWidth={2}
                          className="text-[var(--accent-bright)]"
                          aria-hidden="true"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-mono text-[var(--text-primary)] truncate group-hover:text-[var(--accent-bright)] transition-colors">
                          <Highlight text={item.item_id} term={submitted} />
                        </p>
                        <p className="text-xs text-[var(--text-secondary)] mt-1 font-mono">
                          score: {item.score.toFixed(3)} · tokens: {item.token_count}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Badge variant={variant}>{item.item_type}</Badge>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-xs text-[var(--text-secondary)]">
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={safePage === 0}
            >
              Previous
            </Button>
            <span>
              Page <span className="text-[var(--text-primary)] font-mono">{safePage + 1}</span> of{" "}
              <span className="text-[var(--text-primary)] font-mono">{pages}</span>
            </span>
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={() => setPage((p) => Math.min(pages - 1, p + 1))}
              disabled={safePage >= pages - 1}
            >
              Next
            </Button>
          </div>
        </>
      )}

      {data?.excluded_summary && (
        <Card className="p-3">
          <p className="text-xs text-[var(--text-secondary)] italic">
            {data.excluded_summary}
          </p>
        </Card>
      )}
    </div>
  );
}
