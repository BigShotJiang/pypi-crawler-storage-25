import ReactECharts from "echarts-for-react";
import { AlertTriangle, Compass } from "lucide-react";
import { Card } from "../components/ui";

const TYPES = [
  { name: "decisions", color: "#9b7fff" },
  { name: "stories", color: "#00d4ff" },
  { name: "sessions", color: "#10b981" },
] as const;

export function ExplorerView() {
  const series = TYPES.map((t) => ({
    name: t.name,
    type: "scatter" as const,
    symbolSize: 10,
    data: Array.from({ length: 20 }, () => [
      Math.random() * 10 - 5,
      Math.random() * 10 - 5,
    ]),
    itemStyle: {
      color: t.color,
      opacity: 0.85,
      shadowBlur: 10,
      shadowColor: t.color,
    },
  }));

  const option = {
    backgroundColor: "transparent",
    textStyle: { color: "var(--text-secondary)", fontFamily: "Inter, sans-serif" },
    tooltip: {
      backgroundColor: "rgba(15, 31, 58, 0.95)",
      borderColor: "rgba(124, 92, 255, 0.25)",
      textStyle: { color: "#e8f0fe" },
      formatter: (p: { seriesName: string; data: number[] }) =>
        `${p.seriesName}<br/>(${p.data[0].toFixed(2)}, ${p.data[1].toFixed(2)})`,
    },
    legend: {
      data: TYPES.map((t) => t.name),
      top: 0,
      textStyle: { color: "var(--text-secondary)" },
      itemStyle: { opacity: 0.8 },
    },
    grid: { left: 60, right: 32, top: 40, bottom: 48 },
    xAxis: {
      type: "value",
      name: "UMAP Dimension 1",
      nameLocation: "middle",
      nameGap: 28,
      axisLine: { lineStyle: { color: "rgba(124, 92, 255, 0.18)" } },
      axisLabel: { color: "var(--text-secondary)" },
      splitLine: { lineStyle: { color: "rgba(124, 92, 255, 0.08)" } },
    },
    yAxis: {
      type: "value",
      name: "UMAP Dimension 2",
      nameLocation: "middle",
      nameGap: 40,
      axisLine: { lineStyle: { color: "rgba(124, 92, 255, 0.18)" } },
      axisLabel: { color: "var(--text-secondary)" },
      splitLine: { lineStyle: { color: "rgba(124, 92, 255, 0.08)" } },
    },
    series,
  };

  return (
    <div className="space-y-4">
      <Card
        role="alert"
        className="flex items-center gap-3 px-4 py-3 border-[rgba(245,158,11,0.3)] bg-[var(--warning-dim)]"
      >
        <AlertTriangle
          size={16}
          className="text-[var(--warning)] flex-shrink-0"
          aria-hidden="true"
        />
        <p className="text-sm text-[var(--warning)]">
          Projection endpoint not yet connected — chart shows placeholder data only.
        </p>
      </Card>

      <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
        <Compass size={14} className="text-[var(--accent-bright)]" aria-hidden="true" />
        2D UMAP projection of embedded context items. Hover a point for metadata.
      </div>

      <Card className="p-3">
        <ReactECharts option={option} style={{ height: 500 }} />
      </Card>
    </div>
  );
}
