import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import ReactECharts from "echarts-for-react";
import {
  BarChart2,
  CheckCircle,
  List,
  Plus,
  TrendingUp,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { api } from "../api/client";
import { Button, Card, Input, Select, Textarea } from "../components/ui";

type Lane = "backlog" | "in_progress" | "review" | "done";

type StatColor = "accent" | "ghost" | "cyan" | "warning" | "success";

const STATUS_LABELS: Record<Lane, string> = {
  backlog: "Backlog",
  in_progress: "In Progress",
  review: "In Review",
  done: "Done",
};

const LANES: Lane[] = ["backlog", "in_progress", "review", "done"];

const LANE_STYLES: Record<Lane, { label: string; dot: string }> = {
  backlog: { label: "text-[var(--text-tertiary)]", dot: "bg-[var(--text-tertiary)]" },
  in_progress: { label: "text-[var(--cyan)]", dot: "bg-[var(--cyan)]" },
  review: { label: "text-[var(--warning)]", dot: "bg-[var(--warning)]" },
  done: { label: "text-[var(--success)]", dot: "bg-[var(--success)]" },
};

const STAT_ICON_STYLES: Record<StatColor, string> = {
  accent: "bg-[var(--accent-dim)] text-[var(--accent-bright)]",
  ghost: "bg-[var(--bg-elevated)] text-[var(--text-tertiary)]",
  cyan: "bg-[var(--cyan-dim)] text-[var(--cyan)]",
  warning: "bg-[var(--warning-dim)] text-[var(--warning)]",
  success: "bg-[var(--success-dim)] text-[var(--success)]",
};

interface StoryRow {
  id?: unknown;
  title?: unknown;
  status?: unknown;
}

interface AddStoryInput {
  title: string;
  description: string;
  points: number;
  priority: string;
}

function AddStoryModal({
  onClose,
  onSubmit,
}: {
  onClose: () => void;
  onSubmit: (input: AddStoryInput) => void;
}) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [points, setPoints] = useState(3);
  const [priority, setPriority] = useState("medium");

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Add story"
      className="fixed inset-0 z-30 flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <form
        onClick={(e) => e.stopPropagation()}
        onSubmit={(e) => {
          e.preventDefault();
          if (!title.trim()) return;
          onSubmit({ title: title.trim(), description, points, priority });
        }}
        className="bg-[var(--bg-surface)] border border-[var(--border-mid)] shadow-elevated rounded-lg p-5 w-full max-w-md space-y-4"
      >
        <h3 className="font-display text-lg font-semibold text-[var(--text-primary)]">
          Add story
        </h3>
        <Input
          autoFocus
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Title"
          aria-label="Story title"
        />
        <Textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          placeholder="Description"
          aria-label="Story description"
        />
        <div className="grid grid-cols-2 gap-3">
          <label className="text-xs text-[var(--text-secondary)] flex flex-col gap-1.5">
            <span className="uppercase tracking-widest font-medium">Story points</span>
            <Input
              type="number"
              min={1}
              max={13}
              value={points}
              onChange={(e) => setPoints(Number(e.target.value))}
              className="py-2"
            />
          </label>
          <label className="text-xs text-[var(--text-secondary)] flex flex-col gap-1.5">
            <span className="uppercase tracking-widest font-medium">Priority</span>
            <Select
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              className="py-2"
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </Select>
          </label>
        </div>
        <div className="flex justify-end gap-2">
          <Button type="button" variant="ghost" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" variant="primary" size="sm">
            Add
          </Button>
        </div>
      </form>
    </div>
  );
}

export function SprintView() {
  const queryClient = useQueryClient();
  const [showAdd, setShowAdd] = useState(false);
  const [dragId, setDragId] = useState<string | null>(null);

  const { data: velocity } = useQuery({
    queryKey: ["sprint-velocity"],
    queryFn: () => api.sprints.velocity(),
  });
  const { data: stories = [] } = useQuery<StoryRow[]>({
    queryKey: ["stories"],
    queryFn: () => api.stories.list() as unknown as Promise<StoryRow[]>,
  });

  const addStory = useMutation({
    mutationFn: (input: AddStoryInput) =>
      api.stories.create({
        title: input.title,
        description: input.description,
        points: input.points,
        status: "backlog",
      }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["stories"] }),
  });

  const moveStory = useMutation({
    mutationFn: (vars: { id: string; status: Lane }) =>
      api.stories.update(vars.id, { status: vars.status }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["stories"] }),
  });

  const buckets: Record<Lane, StoryRow[]> = {
    backlog: [],
    in_progress: [],
    review: [],
    done: [],
  };
  for (const s of stories) {
    const status = String(s.status ?? "backlog") as Lane;
    if (buckets[status]) buckets[status].push(s);
  }

  const hasVelocityData = (velocity?.series ?? []).some(
    (s) => (s.points_done ?? 0) > 0,
  );

  const velocityOption = {
    backgroundColor: "transparent",
    textStyle: { color: "var(--text-secondary)", fontFamily: "Inter, sans-serif" },
    tooltip: {
      trigger: "axis",
      backgroundColor: "rgba(15, 31, 58, 0.95)",
      borderColor: "rgba(124, 92, 255, 0.25)",
      textStyle: { color: "#e8f0fe" },
    },
    grid: { left: 48, right: 16, top: 16, bottom: 36 },
    xAxis: {
      type: "category",
      name: "Sprint",
      nameLocation: "middle",
      nameGap: 28,
      axisLine: { lineStyle: { color: "rgba(124, 92, 255, 0.18)" } },
      axisLabel: { color: "var(--text-secondary)" },
      data: velocity?.series.map((s) => s.sprint_name ?? "sprint") ?? [],
    },
    yAxis: {
      type: "value",
      name: "Points",
      nameLocation: "middle",
      nameGap: 36,
      axisLine: { lineStyle: { color: "rgba(124, 92, 255, 0.18)" } },
      axisLabel: { color: "var(--text-secondary)" },
      splitLine: { lineStyle: { color: "rgba(124, 92, 255, 0.08)" } },
    },
    series: [
      {
        type: "bar",
        data: velocity?.series.map((s) => s.points_done) ?? [],
        barMaxWidth: 32,
        itemStyle: {
          color: {
            type: "linear",
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              { offset: 0, color: "#9b7fff" },
              { offset: 1, color: "#7c5cff" },
            ],
          },
          borderRadius: [6, 6, 0, 0],
        },
      },
    ],
  };

  const stats: Array<{
    label: string;
    value: string | number;
    icon: LucideIcon;
    color: StatColor;
  }> = [
    {
      label: "Avg velocity",
      value: velocity?.average_velocity.toFixed(1) ?? "—",
      icon: TrendingUp,
      color: "accent",
    },
    { label: "In backlog", value: buckets.backlog.length, icon: List, color: "ghost" },
    { label: "In progress", value: buckets.in_progress.length, icon: Zap, color: "cyan" },
    { label: "In review", value: buckets.review.length, icon: BarChart2, color: "warning" },
    { label: "Done", value: buckets.done.length, icon: CheckCircle, color: "success" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {stats.map((s) => (
          <Card key={s.label} variant="glass" glow className="p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium uppercase tracking-widest text-[var(--text-secondary)]">
                {s.label}
              </span>
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center ${STAT_ICON_STYLES[s.color]}`}
              >
                <s.icon size={13} strokeWidth={2} aria-hidden="true" />
              </div>
            </div>
            <p className="stat-number text-3xl text-[var(--text-primary)]">
              {String(s.value)}
            </p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-4 gap-4">
        {LANES.map((lane) => {
          const laneStyle = LANE_STYLES[lane];
          return (
            <Card
              key={lane}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => {
                if (dragId) {
                  moveStory.mutate({ id: dragId, status: lane });
                  setDragId(null);
                }
              }}
              className="p-3 min-h-[220px] flex flex-col"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span
                    aria-hidden="true"
                    className={`w-2 h-2 rounded-full ${laneStyle.dot}`}
                  />
                  <span
                    className={`text-xs font-semibold uppercase tracking-widest ${laneStyle.label}`}
                  >
                    {STATUS_LABELS[lane]}
                  </span>
                  <span className="text-xs text-[var(--text-tertiary)] font-mono">
                    {buckets[lane].length}
                  </span>
                </div>
                {lane === "backlog" && (
                  <button
                    type="button"
                    onClick={() => setShowAdd(true)}
                    aria-label="Add story"
                    className="w-6 h-6 rounded-md flex items-center justify-center text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-elevated)] transition-all duration-150 focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
                  >
                    <Plus size={13} strokeWidth={2} />
                  </button>
                )}
              </div>
              <div className="flex-1 space-y-2">
                {buckets[lane].map((s) => (
                  <div
                    key={String(s.id)}
                    draggable
                    onDragStart={() => setDragId(String(s.id))}
                    className="rounded-md border border-[var(--border-dim)] bg-[var(--bg-elevated)] hover:border-[var(--border-strong)] hover:shadow-glow-sm text-sm text-[var(--text-primary)] px-3 py-2 cursor-grab active:cursor-grabbing transition-all duration-150"
                  >
                    {String(s.title ?? "(untitled)")}
                  </div>
                ))}
                {buckets[lane].length === 0 && (
                  <p className="text-xs text-[var(--text-tertiary)] italic px-1 py-2">
                    Empty
                  </p>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-[var(--text-primary)] flex items-center gap-2">
            <BarChart2 size={15} className="text-[var(--accent-bright)]" aria-hidden="true" />
            Velocity — last 6 sprints
          </h3>
        </div>
        {hasVelocityData ? (
          <ReactECharts option={velocityOption} style={{ height: 240 }} />
        ) : (
          <div
            role="status"
            className="flex items-center justify-center text-sm text-[var(--text-secondary)]"
            style={{ height: 240 }}
          >
            No sprint history yet — velocity will appear here once sprints are
            completed.
          </div>
        )}
      </Card>

      {showAdd && (
        <AddStoryModal
          onClose={() => setShowAdd(false)}
          onSubmit={(input) => {
            addStory.mutate(input);
            setShowAdd(false);
          }}
        />
      )}
    </div>
  );
}
