import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, ChevronDown, ChevronRight, X } from "lucide-react";
import { api } from "../api/client";
import { useAppStore } from "../store/appStore";
import { useProjectStore } from "../store/projectStore";
import {
  Badge,
  Button,
  Card,
  Textarea,
  type BadgeVariant,
} from "../components/ui";

type StatusFilter = "all" | "unverified" | "pending" | "passed" | "failed";

const FILTERS: StatusFilter[] = ["all", "unverified", "pending", "passed", "failed"];

const STATUS_BADGE: Record<string, BadgeVariant> = {
  passed: "success",
  failed: "danger",
  pending: "pending",
  unverified: "unverified",
};

const STATUS_DOT: Record<string, string> = {
  passed: "bg-[var(--success)]",
  failed: "bg-[var(--danger)]",
  pending: "bg-[var(--warning)]",
  unverified: "bg-[var(--text-tertiary)]",
};

function filterPillClasses(filter: StatusFilter, active: boolean): string {
  if (!active) {
    return "bg-transparent text-[var(--text-secondary)] border-[var(--border-dim)] hover:border-[var(--border-mid)] hover:text-[var(--text-primary)]";
  }
  switch (filter) {
    case "passed":
      return "bg-[var(--success-dim)] text-[var(--success)] border-[rgba(16,185,129,0.3)]";
    case "failed":
      return "bg-[var(--danger-dim)] text-[var(--danger)] border-[rgba(239,68,68,0.3)]";
    case "pending":
      return "bg-[var(--warning-dim)] text-[var(--warning)] border-[rgba(245,158,11,0.3)]";
    case "unverified":
      return "bg-[var(--bg-elevated)] text-[var(--text-secondary)] border-[var(--border-mid)]";
    default:
      return "bg-[var(--accent-dim)] text-[var(--accent-bright)] border-[var(--border-mid)]";
  }
}

export function DecisionsView() {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [selected, setSelected] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [notesById, setNotesById] = useState<Record<string, string>>({});
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const backend = useProjectStore((s) => s.changeDetectionBackend);
  const setActiveTab = useAppStore((s) => s.setActiveTab);

  const { data: decisions = [] } = useQuery({
    queryKey: ["decisions"],
    queryFn: () => api.decisions.list(),
  });

  const { data: trace } = useQuery({
    queryKey: ["decision-trace", selected],
    queryFn: () =>
      selected ? api.decisions.trace(selected) : Promise.resolve(null),
    enabled: Boolean(selected),
  });

  const { data: verifyStatus } = useQuery({
    queryKey: ["verify", selected],
    queryFn: () =>
      selected ? api.verify.status(selected) : Promise.resolve(null),
    enabled: Boolean(selected),
  });

  const visible = decisions.filter(
    (d) => statusFilter === "all" || d.status === statusFilter,
  );

  const selectedDecision = decisions.find((d) => d.id === selected);

  const openProvenance = () => {
    if (selected) setActiveTab("provenance");
  };

  const saveNote = () => {
    if (!selected) return;
    setNotesById((prev) => ({ ...prev, [selected]: note }));
  };

  const toggleExpand = (id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="grid grid-cols-5 gap-5 h-full">
      <div className="col-span-2 flex flex-col gap-3">
        <div
          className="flex flex-wrap gap-1.5"
          role="group"
          aria-label="Decision status filter"
        >
          {FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setStatusFilter(f)}
              aria-pressed={statusFilter === f}
              className={`px-3 py-1 rounded-full text-xs font-medium border transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-[var(--accent)] ${filterPillClasses(
                f,
                statusFilter === f,
              )}`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>

        {visible.length === 0 ? (
          <Card
            role="status"
            className="flex flex-col items-center justify-center py-16 px-4 space-y-2 border-dashed"
          >
            <div className="w-12 h-12 rounded-xl bg-[var(--bg-elevated)] border border-[var(--border-dim)] flex items-center justify-center">
              <ChevronRight
                size={20}
                className="text-[var(--text-tertiary)]"
                aria-hidden="true"
              />
            </div>
            {statusFilter === "all" ? (
              <>
                <div className="text-sm font-medium text-[var(--text-primary)]">
                  No decisions yet
                </div>
                <p className="text-xs text-[var(--text-secondary)] max-w-xs text-center">
                  Decisions are logged automatically when Claude makes a
                  significant architectural or code choice.
                </p>
              </>
            ) : (
              <>
                <div className="text-sm font-medium text-[var(--text-primary)]">
                  No {f(statusFilter)} decisions
                </div>
                <button
                  type="button"
                  onClick={() => setStatusFilter("all")}
                  className="text-xs text-[var(--accent-bright)] underline focus:outline-none focus:ring-2 focus:ring-[var(--accent)] rounded"
                >
                  Clear filter
                </button>
              </>
            )}
          </Card>
        ) : (
          <div className="space-y-2">
            {visible.map((d) => {
              const active = selected === d.id;
              return (
                <Card
                  key={d.id}
                  glow
                  onClick={() => {
                    setSelected(d.id);
                    setNote(notesById[d.id] ?? "");
                  }}
                  className={`p-4 cursor-pointer ${
                    active
                      ? "border-[var(--border-strong)] shadow-accent"
                      : ""
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <span
                      aria-hidden="true"
                      className={`w-2 h-2 rounded-full ${STATUS_DOT[d.status] ?? "bg-[var(--text-tertiary)]"}`}
                    />
                    <span className="text-sm font-medium text-[var(--text-primary)] truncate">
                      {d.title}
                    </span>
                    <Badge variant={STATUS_BADGE[d.status] ?? "unverified"} className="ml-auto">
                      {d.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-[var(--text-secondary)] font-mono">
                    {d.tags?.join(", ") || "—"} ·{" "}
                    {new Date(d.created_at).toLocaleDateString()}
                  </p>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <div className="col-span-3 flex flex-col gap-3 min-h-0">
        {selected && selectedDecision && trace ? (
          <>
            <div className="sticky top-0 z-10 bg-[var(--bg-base)]/95 backdrop-blur-sm pb-3 border-b border-[var(--border-dim)] flex items-start gap-3">
              <div className="flex-1 min-w-0">
                <div className="text-xs font-mono text-[var(--text-tertiary)]">
                  {selectedDecision.id}
                </div>
                <h2 className="font-display text-lg font-semibold text-[var(--text-primary)] tracking-tight">
                  {trace.decision.title}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setSelected(null)}
                aria-label="Close detail"
                className="w-8 h-8 rounded-lg flex items-center justify-center border border-[var(--border-dim)] bg-[var(--bg-elevated)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--border-strong)] transition-all focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
              >
                <X size={14} strokeWidth={2} />
              </button>
            </div>

            <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
              {trace.decision.description}
            </p>

            <div className="flex flex-wrap items-center gap-2">
              <Badge variant={STATUS_BADGE[selectedDecision.status] ?? "unverified"}>
                {selectedDecision.status}
              </Badge>
              <span className="text-xs text-[var(--text-tertiary)] font-mono">
                {new Date(selectedDecision.created_at).toLocaleString()}
              </span>
              {selectedDecision.tags?.map((t) => (
                <Badge key={t} variant="ghost">
                  {t}
                </Badge>
              ))}
              <div className="ml-auto">
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={openProvenance}
                >
                  View provenance
                  <ArrowRight size={12} strokeWidth={2} />
                </Button>
              </div>
            </div>

            {verifyStatus && (
              <Card
                variant={verifyStatus.verification_available ? "default" : "elevated"}
                className={`p-3 text-xs ${
                  verifyStatus.verification_available
                    ? "text-[var(--text-secondary)]"
                    : "text-[var(--warning)] border-[rgba(245,158,11,0.25)]"
                }`}
              >
                {verifyStatus.verification_available
                  ? `Verification: ${verifyStatus.status}`
                  : verifyStatus.message ??
                    "CI verification unavailable (file watcher mode)."}
              </Card>
            )}

            <h3 className="text-xs font-semibold uppercase tracking-widest text-[var(--text-secondary)] mt-2">
              Change events
            </h3>
            <div className="space-y-2">
              {trace.change_events.map((e) => {
                const isOpen = expanded.has(e.change_event_id);
                // v11: three sources — git commits render their hash,
                // file snapshots show the timestamp, agent reports
                // show the session id (carried on actor_id).
                const label =
                  e.change_event_source === "git_commit"
                    ? `commit ${e.change_event_id.slice(0, 8)}`
                    : e.change_event_source === "agent_reported"
                      ? `agent ${e.actor_id ?? e.change_event_id.slice(0, 8)}`
                      : `snapshot ${e.date}`;
                return (
                  <Card key={e.change_event_id} className="p-3">
                    <button
                      type="button"
                      onClick={() => toggleExpand(e.change_event_id)}
                      className="w-full flex items-center justify-between gap-3 text-xs focus:outline-none"
                    >
                      <span className="flex items-center gap-2">
                        {isOpen ? (
                          <ChevronDown size={12} className="text-[var(--text-tertiary)]" />
                        ) : (
                          <ChevronRight size={12} className="text-[var(--text-tertiary)]" />
                        )}
                        <span className="font-mono text-[var(--text-primary)]">{label}</span>
                      </span>
                      <Badge variant="ghost">
                        {e.ast_changes.length} AST changes
                      </Badge>
                    </button>
                    {isOpen && (
                      <ul className="mt-3 space-y-1 pl-5 border-l border-[var(--border-dim)]">
                        {e.ast_changes.map((a, i) => (
                          <li
                            key={i}
                            className="font-mono text-xs text-[var(--text-secondary)]"
                          >
                            <span className="text-[var(--accent-bright)]">
                              {String(a.change_type)}
                            </span>{" "}
                            · {String(a.entity_name)} ·{" "}
                            <span className="text-[var(--text-tertiary)]">
                              {String(a.file_path)}
                            </span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </Card>
                );
              })}
            </div>

            <div className="space-y-2 mt-2">
              <label
                htmlFor="decision-note"
                className="text-xs font-semibold uppercase tracking-widest text-[var(--text-secondary)]"
              >
                Note
              </label>
              <Textarea
                id="decision-note"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={3}
                placeholder="Add a manual annotation…"
              />
              <div className="flex justify-end">
                <Button type="button" variant="primary" size="sm" onClick={saveNote}>
                  Save note
                </Button>
              </div>
            </div>

            <p className="text-xs text-[var(--text-tertiary)] italic mt-2">
              Backend: <span className="font-mono">{backend}</span>
            </p>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 space-y-3">
            <div className="w-12 h-12 rounded-xl bg-[var(--accent-dim)] border border-[var(--border-mid)] flex items-center justify-center">
              <ArrowRight size={20} className="text-[var(--accent-bright)]" aria-hidden="true" />
            </div>
            <p className="text-sm text-[var(--text-secondary)] text-center max-w-xs">
              Select a decision on the left to view its provenance trace.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function f(s: StatusFilter): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
