import { create } from "zustand";

export type Tab =
  | "memory"
  | "decisions"
  | "sprint"
  | "sessions"
  | "explorer"
  | "provenance"
  | "mcp"
  | "connectors"
  | "settings";

export type Theme = "light" | "dark";

const VALID_TABS: Tab[] = [
  "memory",
  "decisions",
  "sprint",
  "sessions",
  "explorer",
  "provenance",
  "mcp",
  "connectors",
  "settings",
];

interface AppState {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
  theme: Theme;
  toggleTheme: () => void;
}

function tabFromHash(): Tab {
  if (typeof window === "undefined") return "memory";
  const raw = window.location.hash.replace(/^#/, "").replace(/^\//, "");
  const key = raw === "mcp-servers" ? "mcp" : raw;
  return (VALID_TABS as string[]).includes(key) ? (key as Tab) : "memory";
}

const LS_THEME = "cl.theme";

function loadTheme(): Theme {
  if (typeof window === "undefined") return "light";
  try {
    const saved = window.localStorage.getItem(LS_THEME);
    if (saved === "light" || saved === "dark") return saved;
  } catch {
    // storage unavailable — fall through to OS preference
  }
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

const initialTheme: Theme = loadTheme();

function writeHash(tab: Tab) {
  if (typeof window === "undefined") return;
  const slug = tab === "mcp" ? "mcp-servers" : tab;
  const target = `#${slug}`;
  if (window.location.hash !== target) {
    window.history.pushState(null, "", target);
  }
}

export const useAppStore = create<AppState>((set, get) => ({
  activeTab: tabFromHash(),
  setActiveTab: (tab) => {
    writeHash(tab);
    set({ activeTab: tab });
  },
  theme: initialTheme,
  toggleTheme: () => {
    const next = get().theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    try {
      window.localStorage.setItem(LS_THEME, next);
    } catch {
      // storage quota / disabled — non-fatal, in-memory state still flips
    }
    set({ theme: next });
  },
}));

if (typeof window !== "undefined") {
  window.addEventListener("popstate", () => {
    useAppStore.setState({ activeTab: tabFromHash() });
  });
  window.addEventListener("hashchange", () => {
    useAppStore.setState({ activeTab: tabFromHash() });
  });
}
