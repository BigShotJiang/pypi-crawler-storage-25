import { create } from "zustand";
import { api } from "../api/client";

export type ChangeDetectionBackend = "git" | "file_watcher";

interface ProjectState {
  activeProjectId: string;
  projects: string[];
  changeDetectionBackend: ChangeDetectionBackend;
  setActiveProjectId: (id: string) => void;
  addProject: (id: string) => Promise<void>;
  renameActiveProject: (name: string) => void;
  setBackend: (b: ChangeDetectionBackend) => void;
}

const LS_PROJECTS = "cl.projects";
const LS_ACTIVE = "cl.activeProjectId";

function loadProjects(): string[] {
  try {
    const raw = localStorage.getItem(LS_PROJECTS);
    if (!raw) return ["default"];
    const arr = JSON.parse(raw);
    if (Array.isArray(arr) && arr.every((x) => typeof x === "string") && arr.length > 0) {
      return arr as string[];
    }
  } catch {
    // fall through to default
  }
  return ["default"];
}

function loadActive(projects: string[]): string {
  try {
    const v = localStorage.getItem(LS_ACTIVE);
    if (v && projects.includes(v)) return v;
  } catch {
    // fall through
  }
  return projects[0] ?? "default";
}

function persistProjects(projects: string[]): void {
  try {
    localStorage.setItem(LS_PROJECTS, JSON.stringify(projects));
  } catch {
    // storage quota / disabled — non-fatal
  }
}

function persistActive(id: string): void {
  try {
    localStorage.setItem(LS_ACTIVE, id);
  } catch {
    // non-fatal
  }
}

const initialProjects = loadProjects();
const initialActive = loadActive(initialProjects);

export const useProjectStore = create<ProjectState>((set, get) => ({
  activeProjectId: initialActive,
  projects: initialProjects,
  changeDetectionBackend: "git",
  setActiveProjectId: (id) => {
    persistActive(id);
    set({ activeProjectId: id });
  },
  addProject: async (id) => {
    const trimmed = id.trim();
    if (!trimmed) return;
    // Optimistic local update so the dropdown reflects the new project
    // before the network round-trip completes.
    const { projects } = get();
    if (!projects.includes(trimmed)) {
      const next = [...projects, trimmed];
      persistProjects(next);
      set({ projects: next });
    }
    persistActive(trimmed);
    set({ activeProjectId: trimmed });
    try {
      await api.projects.create(trimmed, trimmed);
    } catch (err) {
      // Backend project_create is idempotent and informational; log so
      // users aren't left silently wondering, but keep the optimistic
      // state because the project_id still functions locally as a tag.
      console.warn("projects.create failed", err);
    }
  },
  renameActiveProject: (name) =>
    set((s) => {
      const next = s.projects.map((p) => (p === s.activeProjectId ? name : p));
      persistProjects(next);
      persistActive(name);
      return { activeProjectId: name, projects: next };
    }),
  setBackend: (b) => set({ changeDetectionBackend: b }),
}));
