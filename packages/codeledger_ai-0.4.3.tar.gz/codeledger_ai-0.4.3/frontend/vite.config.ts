import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": "http://localhost:8100",
      "/mcp": "http://localhost:8100",
    },
  },
  build: {
    outDir: "dist",
    emptyOutDir: true,
  },
});
