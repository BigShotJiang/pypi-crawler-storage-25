/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Backgrounds
        background: "var(--bg-base)",
        surface: "var(--bg-surface)",
        elevated: "var(--bg-elevated)",
        overlay: "var(--bg-overlay)",

        // Accent
        accent: {
          DEFAULT: "var(--accent)",
          dim: "var(--accent-dim)",
          mid: "var(--accent-mid)",
          bright: "var(--accent-bright)",
          glow: "var(--accent-glow)",
        },

        // Secondary
        cyan: {
          DEFAULT: "var(--cyan)",
          dim: "var(--cyan-dim)",
          glow: "var(--cyan-glow)",
        },

        // Status
        status: {
          success: "var(--success)",
          warning: "var(--warning)",
          danger: "var(--danger)",
          info: "var(--info)",
        },

        // Text
        text: {
          primary: "var(--text-primary)",
          secondary: "var(--text-secondary)",
          tertiary: "var(--text-tertiary)",
          accent: "var(--text-accent)",
        },

        // Legacy aliases — kept so existing views keep compiling until refactored
        bg: "var(--color-bg)",
        fg: "var(--color-fg)",
        muted: "var(--color-muted)",
        foreground: "var(--color-fg)",
      },
      borderColor: {
        DEFAULT: "var(--border-mid)",
        dim: "var(--border-dim)",
        mid: "var(--border-mid)",
        strong: "var(--border-strong)",
        glow: "var(--border-glow)",
      },
      borderRadius: {
        sm: "var(--radius-sm)",
        DEFAULT: "var(--radius-md)",
        md: "var(--radius-md)",
        lg: "var(--radius-lg)",
        xl: "var(--radius-xl)",
        full: "9999px",
      },
      boxShadow: {
        card: "var(--shadow-card)",
        elevated: "var(--shadow-elevated)",
        accent: "var(--shadow-accent)",
        cyan: "var(--shadow-cyan)",
        "glow-sm": "0 0 10px var(--accent-glow)",
        "glow-md":
          "0 0 20px var(--accent-glow), 0 0 40px rgba(124,92,255,0.08)",
      },
      backdropBlur: {
        glass: "12px",
      },
    },
  },
  plugins: [],
};
