# Coverage Carve-outs

## Summary

- **Total statements:** 6787
- **Covered statements:** 5584
- **Overall coverage:** 82%
- **Coverage on reachable code** (excluding the three infrastructure-gated modules below): **87%**

## Why three modules are gated

The following modules have coverage below the project's 88% target because
they require external infrastructure that is not present in the test
environment. They remain tested through higher-level integration tests that
exercise the SQLite and FastMCP stdio code paths; the uncovered lines are
entirely in the asyncpg/pgvector and FastMCP-HTTP-transport branches.

### 1. `backend/db/db_backend.py` — 60%

The missing 40% is the `PostgreSQLBackend` subclass. Every CRUD method has
both a `SQLiteBackend` and a `PostgreSQLBackend` implementation; we exercise
the SQLite path through the full test suite but the asyncpg path needs a
running PostgreSQL instance to meaningfully test — mocking asyncpg deeply
enough to exercise the queries would verify SQL formatting, not behavior.

### 2. `backend/db/vector_store.py` — 59%

Same story: the `SqliteVssStore` is covered by our embedding-pipeline and
semantic-search tests; the `PgVectorStore` requires Postgres with the
`pgvector` extension installed.

### 3. `backend/mcp/mcp_server.py` — 27%

This module is the FastMCP tool-registration layer. Every registered tool
is a thin wrapper around a `ToolHandlers` method (which IS covered at 78%+).
Hitting coverage on the decorator bodies requires invoking the FastMCP HTTP
transport, which lives outside the unit-test loop.

## Everything else

| Module | Coverage |
|---|---|
| `backend/auth/auth_service.py` | 98% |
| `backend/auth/auth_middleware.py` | 98% |
| `backend/auth/credential_manager.py` | 94% |
| `backend/auth/oauth_manager.py` | 83% |
| `backend/auth/license.py` | 88% |
| `backend/advanced/drift_detector.py` | 96% |
| `backend/advanced/rollback_planner.py` | 96% |
| `backend/advanced/tautology_detector.py` | 92% |
| `backend/advanced/agent_profiler.py` | 88% |
| `backend/advanced/knowledge_packs.py` | 86% |
| `backend/intelligence/ast_tracker.py` | 86% |
| `backend/intelligence/context_triage.py` | 95% |
| `backend/intelligence/decision_inferrer.py` | 92% |
| `backend/intelligence/embedder.py` | 87% |
| `backend/intelligence/semantic_search.py` | 91% |
| `backend/intelligence/staleness_scorer.py` | 85% |
| `backend/intelligence/tree_sitter_langs.py` | 91% |
| `backend/mcp/tool_handlers.py` | 78% |
| `backend/api/routes.py` | 86% |
| `backend/cli.py` | 82% |
| `backend/config.py` | 83% |
| `backend/main.py` | 82% |
| `backend/middleware/security.py` | 91% |
| `backend/models.py` | 99% |
| `backend/db/migrations.py` | 93% |
| `backend/utils/file_watcher.py` | 81% |
| `backend/utils/git_hooks.py` | 95% |
| `backend/utils/log_sanitizer.py` | 100% |
| `backend/utils/project_claude_md.py` | 87% |
| `backend/utils/snapshot_store.py` | 84% |
| `backend/utils/token_counter.py` | 100% |
| `backend/verification/conflict_detector.py` | 94% |
| `backend/verification/harness.py` | 96% |
| `backend/verification/provenance.py` | 97% |
| `backend/verification/verifier.py` | 93% |

## Raising coverage further

Reaching 90%+ total coverage requires running:
- A PostgreSQL instance with the `pgvector` extension for `db_backend.py`
  and `vector_store.py` coverage.
- The full FastMCP HTTP transport for `mcp_server.py` coverage.

Both are reasonable for a CI environment but impractical for the local
unit-test loop. Consider adding a docker-compose Postgres service to CI.
