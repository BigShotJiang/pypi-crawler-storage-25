# Detection Source + Actor Schema — Alignment Audit (Phase 1)

> Generated prior to any implementation. No code written. Phase 2 will not begin until the user replies with the exact string `APPROVED: proceed to Phase 2`.

---

## 0. Pre-flight summary

Three design assumptions in the prompt **do not match the repo as it currently stands**. They are not blockers on their own, but the Phase 2 spec needs to be adjusted or clarified before any code lands. Full detail is in §1.5, §1.6, §1.7, and §1.9. A short list:

1. **No `backend/vault/` directory exists.** The credential vault lives at `backend/auth/credential_manager.py` and writes to a `*.enc` file in the project root. The vault entry-key convention is `"{provider}:{key}"`, not `"WEBHOOK_SECRET_{project_id}"`.
2. **Webhook secrets are currently a single global shared value** (`provider="webhooks"`, `key="default"`), not per-project. No per-project lookup exists anywhere.
3. **There is no "write permission" auth pattern in MCP tools.** Every authenticated caller can call every tool. Adding a write-permission gate to `detection.switch_source` requires inventing a new pattern — this is out of scope for a one-module change.
4. **The migration machinery is up-only.** `apply_migrations` in `backend/db/migrations.py` has no rollback/`down` concept. The prompt's requirement to provide a `down` migration requires either a separate utility or new infrastructure.
5. **The post-commit hook does not capture git author email.** The backfill rule "actor_id = git author email if source='git_commit'" resolves to `NULL` for every existing row because that data is not stored. Going forward, the hook script itself needs changes to capture author info.

The uncommitted changes on `main` (§1.5) are minor but must be resolved before branching.

---

## 1.1 Current detection code inventory

### Grep hits (classified)

| File | Line | Classification | Notes |
|---|---|---|---|
| `backend/db/migrations.py` | 210, 215, 227–228 | migration | `file_snapshots` table (v2) |
| `backend/db/migrations.py` | 256, 264 | migration | `change_event_type` column added in v3 as `ALTER TABLE ast_changes ADD COLUMN` |
| `backend/db/db_backend.py` | 27, 70 | detector-adjacent | `file_snapshots` is in the table allowlist |
| `backend/intelligence/ast_tracker.py` | 278, 291, 294, 305–308, 317, 386, 413, 420, 429, 431–432, 443–446, 476, 486, 496, 512, 520, 545 | detector/consumer hybrid | The `process_change_event` entry point branches on `change_event_type`. `link_changes_to_decision` validates the literal set. `_record_unlinked` chooses `UnlinkedCommit` vs `UnlinkedFileChange` on it. |
| `backend/advanced/rollback_planner.py` | 32 (class), 36, 83, 115 | consumer | `ChangeEventRef` dataclass carries `change_event_type`; `plan_rollback_dict` surfaces it. |
| `backend/mcp/tool_handlers.py` | 1314, 1351, 1391, 2358 | consumer | Four handlers serialize `change_event_type` into MCP responses (`provenance_forward`, `provenance_reverse`, `harness_score`, `session.replay` or equivalent). |
| `backend/main.py` | 559, 599 | consumer (dispatch site) | The two HTTP hooks pass `change_event_type="git_commit"` / `"file_snapshot"` into `process_change_event`. |
| `backend/main.py` | 72–73, 540–613 | detector-adjacent | `_PUBLIC_PATHS` exempts `/api/hooks/post-commit` and `/api/hooks/file-change` from auth; both endpoints validate the global webhook secret via `X-Webhook-Secret`. |
| `backend/utils/file_watcher.py` | 31–32, 154, 312 | detector | `watchdog.Observer` + event handler. Single observer per server process; not per-project. |
| `backend/utils/git_hooks.py` | 1–172 | detector (installer) | Renders a Python script into `.git/hooks/post-commit` and `.git/hooks/post-merge`. **Script does not capture author email.** POSTs `{commit, files}` only. |
| `backend/utils/snapshot_store.py` | 10, 33, 79 | detector-adjacent | Snapshot-based diff generation for the file watcher. |
| `backend/verification/verifier.py` | 217 | consumer | Queries `ast_changes` with `change_event_type="git_commit"` hard-coded. |
| `backend/verification/harness.py` | 54 (dataclass), 155, 172, 181, 200, 452–453 | consumer | `HarnessScore` carries `change_event_type`. `_per_event_scores` dispatches on it. |
| `backend/verification/provenance.py` | 11, 33 (`ChangeEventType` Literal), 46, 66, 113, 176, 241, 303–305, 309–316 | consumer | `ChangeEventType = Literal["git_commit","file_snapshot"]`. `_effective_event_type` defaults to `"git_commit"` for legacy rows. `_event_label` branches on it. |
| `backend/models.py` | 215, 219, 233 | schema | `ASTChange.change_event_type: str = ""`. Docstring explains the abstraction. |
| `backend/verification/provenance.py` (dataclasses at lines 46, 66) | — | consumer | `ChangeEventNode` and `ReverseTraceResult` both carry `change_event_type`. |
| `backend/cli.py` | 234 | detector (install command) | `--install-hooks` flag installs git hooks. |
| `scripts/install_hooks.py` | — | detector (installer) | Alternate install script; couples to `git_hooks.py`. |

### Source selection — where does it happen today?

**There is no runtime DetectorRegistry. Source selection is process-static.**

* `backend/config.py:168–179` — `ChangeDetectionConfig.backend: str = "git"`. Set once when `codeledger.toml` is loaded.
* `backend/main.py:285–289` — `backend_name` derived from config at server startup, then passed to `AgentProfiler`, `ToolHandlers`, etc.
* `backend/cli.py:325` — `codeledger init` decides `change_detection_backend` based on presence of `.git/`.

There is no per-project source. The whole server runs in either `git` or `file_watcher` mode. Changing source requires editing `codeledger.toml` and restarting. This is **significantly different from the prompt's design**, which assumes per-project `registry.switch_source(project_id, new_source)` with a drain window. See §1.7 risk A.

### Consumers of `change_event_type`

| Consumer | File | Functions / entry points | Currently branches on `change_event_type`? |
|---|---|---|---|
| AST tracker | `backend/intelligence/ast_tracker.py` | `process_change_event`, `link_changes_to_decision`, `_record_unlinked` | Yes — validates the literal set in two places (lines 305, 443). Selects `UnlinkedCommit` vs `UnlinkedFileChange`. |
| Rollback planner | `backend/advanced/rollback_planner.py` | `plan_rollback`, `plan_rollback_dict` | Carries through, does not branch on it. |
| Provenance engine | `backend/verification/provenance.py` | `forward_trace`, `reverse_trace`, `_event_label` | Yes — `_event_label` renders snapshot vs commit label. |
| Quality harness | `backend/verification/harness.py` | `score_commit`, `score_snapshot`, `_score_change_event`, `_per_event_scores` | Yes — dispatch decision. |
| Verifier | `backend/verification/verifier.py` | `_decisions_for_commit` | Hard-coded to `"git_commit"` (correct — verifier only exists in git mode). |
| ToolHandlers | `backend/mcp/tool_handlers.py` | `provenance_forward`, `provenance_reverse`, `harness_score`, and one more at 2358 | Surface-only — passes through. |
| DecisionInferrer | `backend/intelligence/decision_inferrer.py` | (no direct reference, but relies on `ASTChange.change_event_type` reaching it via evidence) | Not directly — reads the ASTChange rows produced by `ast_tracker`. Inference logic is backend-agnostic. |
| Frontend | `frontend/src/api/client.ts:108`, `frontend/src/views/ProvenanceView.tsx:78`, `frontend/src/views/DecisionsView.tsx:278` | — | Yes — TypeScript union type and two conditional branches on `"git_commit"` vs `"file_snapshot"`. |

---

## 1.2 Schema audit

### Current `CREATE TABLE` for the change-events table

`ast_changes` is the change-events table. Verbatim current shape (SQLite, after v1 + v3 ALTERs):

```sql
CREATE TABLE IF NOT EXISTS ast_changes (
    id TEXT PRIMARY KEY,
    commit_hash TEXT NOT NULL DEFAULT '',
    file_path TEXT NOT NULL DEFAULT '',
    language TEXT NOT NULL DEFAULT '',
    change_type TEXT NOT NULL DEFAULT '',
    entity_name TEXT NOT NULL DEFAULT '',
    entity_type TEXT NOT NULL DEFAULT '',
    old_signature TEXT,
    new_signature TEXT,
    session_id TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    -- added in v3:
    change_event_id TEXT NOT NULL DEFAULT '',
    change_event_type TEXT NOT NULL DEFAULT '',
    project_id TEXT NOT NULL DEFAULT ''
);
```

### Indexes on `ast_changes`

```
sqlite_autoindex_ast_changes_1  (PRIMARY KEY on id)
idx_ast_commit                  CREATE INDEX idx_ast_commit  ON ast_changes(commit_hash)
idx_ast_event                   CREATE INDEX idx_ast_event   ON ast_changes(change_event_id)
idx_ast_project                 CREATE INDEX idx_ast_project ON ast_changes(project_id)
```

### Foreign keys

None declared. `session_id` is a soft reference into `sessions`. `change_event_id` is soft — it is the snapshot ID or commit hash.

### Existing row count (local dev DB)

```
ast_changes total: 0
change_event_type group-by: (no rows)
```

The local SQLite DB at `data/codeledger.db` has **zero** rows in `ast_changes`. Local backfill is a no-op. A production-like DB with populated rows is still the responsibility of the migration — see §1.6.

Applied migrations in the local DB: v1–v8. **v9 and v10 have not been applied locally.** This means Phase 2 implementors must not assume v10 is present on every dev machine; `v11` must still list v10 in its upstream dependency through ordering only, not via explicit guards.

### Columns that become redundant / inconsistent

| Column | Post-migration state |
|---|---|
| `commit_hash` | Redundant for `file_snapshot` and `agent_reported` rows. Today it holds `""` for file-snapshot rows and the commit hash for git rows. After v11 + v12 (view drop), the column remains — used by legacy code — but is consistently `""` for non-git sources. **Do not drop it in v11.** It is read by `_effective_event_id` as a fallback and is the target of `idx_ast_commit`. Dropping would break legacy provenance reads. |
| `idx_ast_commit` | Still useful for `commit_hash` lookups from legacy callers; retain. |
| `change_event_type` | Renamed → `change_event_source` in v11. `change_events_legacy` view preserves the old name for one release. |

No column needs an immediate drop. v11 is **purely additive + one rename**.

---

## 1.3 Consumer branch audit

For each consumer that reads change events:

### Inference engine — `backend/intelligence/decision_inferrer.py`

* Branches on `change_event_type`? **No — does not read the field directly.** It reads `ASTChange` rows filtered by `session_id`. It does read imports, entity names, file paths — none of these are actor- or source-specific.
* Implicit `actor=human` assumption? **Yes, pervasively.** The evidence taxonomy in `inference_evidence.py` treats every structural change as human-authored. `session_pattern` evidence (0.40 weight) counts ASTChange rows as "agent tool-call pattern" but does not distinguish between agent edits that came through `detection.report_agent_edit` vs file-system edits the watcher picked up vs bot commits that came through the GitHub webhook. This becomes a **GR-1 / GR-2 risk** — see §1.7 risk B.
* Required changes: (a) Filter out `ci_bot` and `webhook_bot` actors from the evidence pool or weight them differently. (b) Add the explicit comment `# GR-2: agent_reported events receive no confidence boost — same weights as other sources` at the evidence weighting step. (c) Audit whether `session_pattern` can inflate via agent-reported volume and decide on a cap.

### Verification layer — `backend/verification/verifier.py`

* Branches? `_decisions_for_commit` hard-codes `change_event_type="git_commit"` (line 217). Correct today — the verifier only runs in git mode.
* Required change: rename the column read to `change_event_source`.
* Risk: none. Read-only rename.

### Provenance — `backend/verification/provenance.py`

* Branches? `_event_label` (line 312) branches on `change_event_type`. `ChangeEventType = Literal["git_commit","file_snapshot"]` (line 33).
* Required changes: (a) Widen the Literal to include `"agent_reported"`. (b) Add actor_type/actor_id fields to `ChangeEventNode` and `ReverseTraceResult`. (c) Extend `_event_label` to handle `agent_reported` with a label like `"agent report [session_id] by [actor_id]"`.

### Rollback planner — `backend/advanced/rollback_planner.py`

* Branches? No. Carries `change_event_type` through opaquely.
* Implicit `actor=human`? Yes — risk logic (`_assess_risk`) only considers dependent decisions' status, not who authored them. That is correct and should stay.
* Required changes per the prompt: "group `agent_reported` events by `actor_id` (session ID)". This means `ChangeEventRef` grows a field or the plan adds a new aggregation. Minimal surface: add `actor_type`, `actor_id` to `ChangeEventRef`, and in `plan_rollback` group agent events by `actor_id` into a separate "agent-session impact" list.

### Quality harness — `backend/verification/harness.py`

* Branches? `_per_event_scores` (line 452) branches on `change_event_type`. `score_commit` vs `score_snapshot`. The harness dispatches to two public entry points.
* Required changes: (a) Exclude `ci_bot` and `webhook_bot` actors from decision-density scoring. Their edits do not indict the human/agent workflow. (b) Read `change_event_source` instead of `change_event_type`. (c) Add a `score_agent_reported` entry point or generalize `_score_change_event` to accept any source.
* Risk: harness is already branched over two backends — adding a third doubles the dispatch surface. Consider collapsing to a single `_score_change_event` that takes (source, event_id, project_id).

### Frontend (not listed in the prompt but it is a real consumer)

* `frontend/src/api/client.ts:108` — TypeScript union type: `"git_commit" | "file_snapshot"`. Must be widened to include `"agent_reported"` and a new `actor_type` field must be added to response types.
* `frontend/src/views/ProvenanceView.tsx:78` and `frontend/src/views/DecisionsView.tsx:278` — both branch on the string value. At minimum the label rendering needs a third branch.
* **Phase 2 spec does not cover frontend changes.** If the rename propagates via a `change_events_legacy` view, the frontend can keep reading `change_event_type` for one release. But it will receive `"agent_reported"` values that its union type rejects. Either widen the TS union in v11 or hold the frontend on the legacy view. **Decision needed before Phase 2.**

### Other

* `backend/advanced/agent_profiler.py:120` — branches on `change_detection_backend` (not `change_event_type`). Unaffected.
* `backend/mcp/tool_handlers.py` — four sites (1314, 1351, 1391, 2358) pass through. Simple rename.

---

## 1.4 Existing test coverage

### Test files that touch detection code

High-traffic (sorted by `change_event_type` reference count):

| File | refs | Will break on rename? |
|---|---|---|
| `tests/unit/test_provenance.py` | 15 | Yes |
| `tests/integration/test_mcp_tools.py` | 13 | Yes |
| `tests/unit/test_ast_tracker.py` | 12 | Yes |
| `tests/unit/test_rollback_planner.py` | 11 | Yes |
| `tests/unit/test_inference_guard_rails.py` | 8 | Yes |
| `tests/unit/test_harness.py` | 8 | Yes |
| `tests/e2e/test_full_decision_lifecycle.py` | 7 | Yes |
| `tests/unit/test_decision_inferrer.py` | 6 | Yes |
| `tests/e2e/test_full_decision_lifecycle_no_git.py` | 6 | Yes |
| `tests/unit/test_models.py` | 3 | Yes |
| `tests/unit/test_conflict_detector.py` | 2 | Yes |
| `tests/qa/test_session_end_workflow.py` | 2 | Yes |
| `tests/unit/test_verifier.py` | 1 | Yes |
| `tests/qa/test_security_invariants.py` | 1 | Yes |
| `tests/qa/test_provenance_workflow.py` | 1 | Yes |
| `tests/qa/test_missing_fixes.py` | 1 | Yes |

Plus `tests/unit/test_file_watcher.py`, `tests/unit/test_git_hooks.py`, `tests/integration/test_embedding_pipeline.py`, `tests/qa/test_git_hook_workflow.py`, `tests/qa/test_file_watcher_workflow.py`, `tests/qa/test_cross_platform.py`, `tests/qa/test_security_invariants.py`, `tests/qa/test_session_end_workflow.py`, `tests/unit/test_hook_endpoints.py` — these reference the endpoints and watchers but not the field name directly, so rename is lower-impact.

### Tests that break **without modification**

Every file in the table above — ~16 test files, ~90 references. The rename from `change_event_type` → `change_event_source` will break each one unless the Python dataclass keeps the old attribute as an alias.

**Recommendation:** the `ASTChange` model should carry a **runtime-writeable alias property** `change_event_type` that maps to `change_event_source` during the transition, OR every test site gets updated in v11. The prompt says "keep a view aliasing old name for one version of backward compat" — that covers the SQL side but not Python attribute access. Phase 2 must decide: alias in the Python model, or update all ~90 test call sites.

### Test gaps that will exist after the change

* **No tests for per-project detector registry behavior.** The switch-under-load drain is a non-trivial concurrency behavior and it does not exist today. Needs fresh tests.
* **No tests for HMAC-SHA256 webhook signature verification against a per-project secret.** Existing webhook tests use the global-secret bearer style.
* **No tests for `agent_reported` end-to-end flow** (MCP tool → detector → ASTChange row with correct actor fields).
* **No tests for consumer changes under each actor type** (harness excludes bots; inference does not boost agents; rollback groups by session).
* **No tests for migration `down`** (no `down` exists in any current migration). Testing rollback on a seeded DB is new.
* **No security tests verifying 401 empty-body on invalid signature** — prompt requires this.

### Tests that need new variants (not new files)

* `tests/unit/test_ast_tracker.py` — add cases for `change_event_source="agent_reported"` end-to-end, and cases for `actor_type` + `actor_id` propagation.
* `tests/unit/test_harness.py` — verify `ci_bot` / `webhook_bot` events are excluded from decision-density scoring.
* `tests/unit/test_decision_inferrer.py` + `test_inference_guard_rails.py` — verify GR-2 single-signal cap still applies to `agent_reported` and GR-1 is not violated.
* `tests/unit/test_provenance.py` — assert `actor_type`/`actor_id` surface in traces.
* `tests/unit/test_rollback_planner.py` — assert agent events are grouped by session.

---

## 1.5 In-flight branches and uncommitted work

### `git status`

```
On branch main
Changes not staged for commit:
        modified:   CHANGELOG.md
        modified:   npm/package.json
        modified:   pyproject.toml
Untracked files:
        npm/codeledger-ai-0.1.4.tgz
```

### `git branch -a`

```
  feat/vaulted-mcp-servers-and-connectors
* main
  remotes/origin/feat/vaulted-mcp-servers-and-connectors
  remotes/origin/main
```

### Findings

* **Uncommitted changes on `main` exist.** CHANGELOG.md, npm/package.json, pyproject.toml are modified. An untracked tarball `npm/codeledger-ai-0.1.4.tgz` sits in the tree. These look like a release artifact that was half-prepared — package.json and pyproject.toml version bumps, CHANGELOG entry — then abandoned without committing. **Not safe to branch from `main` until these are committed, stashed, or explicitly discarded.**
* The existing `feat/vaulted-mcp-servers-and-connectors` branch does not touch `backend/` detection code or the `ast_changes` table (confirmed by name scope; not diffed deeply). Phase 2 can proceed in parallel.
* Recent HEAD (`988b74e`) is the v0.3.1 click pin fix — unrelated to detection.

### STOP condition per the Phase 1 spec

The Phase 1 spec says: *"If uncommitted changes exist, stop and surface them. Do not proceed until the user has committed, stashed, or explicitly accepted the risk."*

**Action required from user before Phase 2 can begin:** commit, stash, or explicitly accept the risk on the three modified files and the untracked `.tgz`. Resolve cleanly before `APPROVED: proceed to Phase 2`.

---

## 1.6 Migration safety assessment

### Can v11 run against production-like DB without downtime?

**Partially yes, with caveats.**

* **SQLite 3.45.1** (the interpreter on this machine) supports `ALTER TABLE ... RENAME COLUMN`. Rename is atomic and cheap.
* **PostgreSQL** — same. `ALTER TABLE ast_changes RENAME COLUMN change_event_type TO change_event_source` is a metadata-only operation, instant.
* **Adding `actor_type` with `DEFAULT 'human'` and a CHECK constraint** — in PostgreSQL ≥ 11, adding a `NOT NULL` column with a default is metadata-only. Older PG versions rewrite the table (slow for large `ast_changes`). Project does not pin a minimum PG version that I could find — need to clarify.
* **Adding `actor_id` NULL** — cheap everywhere.
* **Backfill `actor_id = git author email` is NOT POSSIBLE from stored data.** The post-commit hook (`backend/utils/git_hooks.py`) does not capture author email. There is no column on `ast_changes`, `sessions`, or any other table that holds it. Every existing git-source row will get `actor_id=NULL`. This is a **material departure from the prompt's stated backfill rule** and needs to be surfaced to the user. The going-forward fix is to update the hook template to POST `author_email` in the payload, which means regenerating hooks via `codeledger init --reinstall-hooks` on every existing install.
* **Composite index** `(actor_type, change_event_source, created_at)` — creating indexes is blocking in SQLite and takes time proportional to row count. For a fresh DB it is instant. For a populated DB, consider `CREATE INDEX CONCURRENTLY` in PostgreSQL mode; SQLite does not support that flag. Acceptable for typical CodeLedger deployment sizes but flag for users with large histories.
* **Backward-compat view** `change_events_legacy` — SQLite views are cheap. PostgreSQL views are cheap. Dropping in v12 is a one-liner.

### Are there queries that would be slow or broken during backfill?

* During the backfill window, `ast_changes.change_event_type` is being renamed. Any SELECT against the old name during the metadata swap could fail. In SQLite, this is effectively atomic because the migration runs in a single connection under a transaction bracket. In PostgreSQL, same — DDL inside a transaction.
* The `change_events_legacy` view should be created in the **same** migration transaction so readers see either pre- or post-migration state, never an intermediate.
* **Failure mode:** If `_migrations` records v11 applied but one of the DDL statements failed silently, the next run of `apply_migrations` will skip v11 — leaving the DB in an inconsistent state. The current `apply_migrations` loop (line 617–638) does not wrap per-migration statements in a transaction. This is a pre-existing bug — see §1.7 risk D.

### Rollback plan if migration fails mid-execution

**There is none today.** `apply_migrations` is up-only. If v11 half-applies, the DB is wedged. Options:

1. Wrap every migration in a BEGIN/COMMIT bracket (pre-existing bug fix).
2. Add a `down_sqlite` / `down_postgresql` pair to `Migration` and a separate CLI command `codeledger migrate down <version>` that runs it.
3. Document a manual recovery: drop the view, rename the column back, drop `actor_type`/`actor_id`.

The prompt requires (2). This is a new architectural feature, not a small addition to v11. **Decision needed:** is the Phase 2 scope widened to add `down` infrastructure globally, or does v11 ship with a standalone `down_v11` function that doesn't hook into a registry?

### Does `CredentialManager` support per-project keyed lookup?

**No, not directly.** The vault entry-key convention is `"{provider}:{key}"`, and `get` / `set` take `(provider, key)` args. There is no concept of "project scope".

The prompt's `WEBHOOK_SECRET_{project_id}` key is a flat string that doesn't match the vault's two-part key.

**Workable mapping:** store as `creds.set("github_webhook", f"project_{project_id}", secret)`. Produces vault entry key `github_webhook:project_<uuid>`. Semantically equivalent and satisfies the per-project spirit of the prompt.

**Decision needed:** confirm this mapping is acceptable, or add a new vault method `get_project_secret(project_id, purpose)` that handles the key construction internally.

---

## 1.7 Architectural concerns

### A. Source selection is process-static today, not per-project (high)

`ChangeDetectionConfig.backend` is a single string in `codeledger.toml`, read once at startup. The file watcher (`backend/utils/file_watcher.py:312`) is one daemon thread per server. The git hook pipeline is one set of endpoints.

The prompt's `DetectorRegistry.switch_source(project_id, ...)` implies **one detector per project** and runtime switching. That is a substantially bigger change than the prompt implies:

1. `AbstractDetector` instances must be created per project_id at first use (lazy) or at startup (eager).
2. `FileSnapshotDetector` wraps a `watchdog.Observer` with a project-scoped path. Multiple observers coexisting means resource overhead and the project_root lookup must be available per project.
3. `GitCommitDetector` is essentially HTTP-receiver side — but the hook template is written to `<project>/.git/hooks/post-commit` and points at the global server URL. No per-project routing exists.
4. `AgentReportedDetector` is trivial per-project (MCP tool call carries project_id).

**Recommendation:** ratify with the user whether the registry is really per-project, or whether it's per-server with `project_id` as a pass-through. If per-server, the `switch_source(project_id, ...)` API is misleading.

### B. Inference engine & GR-1 / GR-2 risk from agent_reported volume (medium-high)

The prompt says "no boost for agent_reported; single-signal cap stays at 0.65 per GR-2." That is correct on the surface but there is a subtle violation:

* `session_pattern` evidence (weight 0.40) fires when "repeated tool-call pattern across files in the same directory" appears. If an agent reports 20 edits via `detection.report_agent_edit`, every one of those becomes an ASTChange row. The inferrer sees 20 AST changes in the same session → fires `session_pattern` evidence → which contributes 0.40 toward the candidate's confidence.
* Combined with one other evidence type (e.g., `new_function` 0.20), the candidate crosses the single-signal cap trivially. With three evidence types it approaches the multi-signal cap of 0.85. **An agent can effectively self-report its way into high-confidence decisions.**
* GR-1 ("No fabrication") is technically honored (each evidence item is real) but the evidence is thin — the agent said "I edited these files" and we turned that into structural evidence.

**Mitigation options:**
1. Drop `session_pattern` evidence when `actor_type == 'agent'` — agent self-reporting is the tool-call pattern. Double-counting.
2. Downweight every evidence item produced from `agent_reported` events.
3. Require a real diff (not just an agent's assertion) before an ASTChange row is produced for agent-reported edits.

**Phase 2 must pick one.** The prompt's "no boost" is necessary but not sufficient.

### C. Webhook secret storage model mismatch (medium)

The current vault stores one global webhook secret (`webhooks:default`). All webhooks trust it. The prompt requires per-project secrets. Three issues:

1. **Existing webhooks break** if we flip the per-project scheme globally. The `/api/hooks/post-commit` and `/api/hooks/file-change` endpoints would need to migrate simultaneously OR keep using the global secret.
2. **`/webhooks/github` is a different URL prefix** from existing `/api/hooks/…`. Inconsistent route structure.
3. **`/webhooks/github` derives project_id from path or payload.** The GitHub webhook payload does not natively include our internal `project_id`. The URL path `POST /webhooks/github/{project_id}` is cleaner. Needs decision.

**Phase 2 must pick:** (a) scope this change to `POST /webhooks/github/{project_id}` and leave existing hooks on global secret for now, OR (b) migrate all three webhook routes to per-project secrets as one atomic change. The prompt reads like (a).

### D. Pre-existing bug: migrations are not per-statement transactional (low)

`apply_migrations` at `backend/db/migrations.py:617–638` loops over `statements` and calls `backend.execute_raw(stmt)` one at a time, then records the migration as applied at the end. If statement N fails, N-1 statements have been applied and the record is not written — so the next invocation will try to re-run them. Some are idempotent (`CREATE TABLE IF NOT EXISTS`, `ALTER TABLE ADD COLUMN` sometimes), but `ALTER TABLE RENAME COLUMN` is not idempotent. This is latent risk that v11 will expose.

**Mitigation:** wrap per-migration execution in a transaction. This is a one-line change but it affects every migration. Should be done as part of Phase 2 or as a preparatory commit.

### E. `commit_hash` column lives on — partial abstraction (low)

`ASTChange.commit_hash` still exists as a separate field, populated redundantly with `change_event_id` for git rows. Legacy callers read it; new code reads `change_event_id`. The abstraction is half-done. Phase 2 is not the time to finish it, but be aware that `commit_hash` needs to stay and be maintained by `ast_tracker.link_changes_to_decision`.

### F. Guard rail risk summary

| Guard rail | At risk from Phase 2? | Mitigation |
|---|---|---|
| GR-1 No fabrication | Yes — see §B. | Drop `session_pattern` for agent actors. |
| GR-2 Calibrated confidence | Yes — see §B. | Same as GR-1. |
| GR-3 Factual titles | No |
| GR-4 Traceable evidence | No |
| GR-5 Never blocks session.end | Low risk — `switch_source` is explicit and separate | Keep detection paths off `session.end` path. |
| GR-6 Always pending | No |
| GR-7 Deduplication | No |
| GR-8 No LLM calls | No |
| GR-9 Session-scoped | No |
| GR-10 Noise filtering | No |
| VGR-1..7 | No direct risk |

---

## 1.8 Proposed file tree delta

### New files (11)

| File | Reason |
|---|---|
| `backend/detection/__init__.py` | New package for detection subsystem. |
| `backend/detection/events.py` | Pydantic `ChangeEvent` model + `from_legacy_row`. |
| `backend/detection/base.py` | `AbstractDetector` ABC + `DetectorStatus` enum. |
| `backend/detection/git_commit.py` | `GitCommitDetector` — refactor of existing hook logic. |
| `backend/detection/file_snapshot.py` | `FileSnapshotDetector` — refactor of existing watchdog. |
| `backend/detection/agent_reported.py` | `AgentReportedDetector` — new. |
| `backend/detection/registry.py` | `DetectorRegistry` with `switch_source` + `status`. |
| `backend/detection/webhook.py` | `/webhooks/github` FastAPI route. |
| `backend/db/migrations/v11_actor_source_schema.py` | Migration v11. |
| `tests/unit/test_detection_events.py` | Tests for `ChangeEvent` model. |
| `tests/unit/test_detection_registry.py` | Tests for registry + switch_source. |

### Test files created (6)

| File | Reason |
|---|---|
| `tests/unit/test_detection_base.py` | Abstract detector contract tests. |
| `tests/unit/test_detection_git_commit.py` | Refactored detector tests. |
| `tests/unit/test_detection_file_snapshot.py` | Refactored detector tests. |
| `tests/unit/test_detection_agent_reported.py` | New detector tests. |
| `tests/unit/test_detection_webhook.py` | Signature verification + bot classification tests. |
| `tests/unit/test_migration_v11.py` | Up/down migration tests. |

### Modified files (~15–20)

| File | Reason |
|---|---|
| `backend/db/migrations.py` | Register v11 in the `MIGRATIONS` tuple; optionally fix transaction wrapping (§1.7.D). |
| `backend/models.py` | Add `actor_type` and `actor_id` to `ASTChange`. |
| `backend/intelligence/ast_tracker.py` | Widen `change_event_type` literal set to include `"agent_reported"`. Set actor fields. Rename the Python attr? — decision pending. |
| `backend/main.py` | Mount `/webhooks/github` route. Instantiate `DetectorRegistry`. Keep existing `/api/hooks/post-commit` and `/api/hooks/file-change` routing via the registry. |
| `backend/verification/provenance.py` | Widen `ChangeEventType` Literal. Add `actor_type`/`actor_id` to `ChangeEventNode` and `ReverseTraceResult`. Extend `_event_label`. |
| `backend/verification/harness.py` | Exclude `ci_bot`/`webhook_bot` from density scoring. Generalize `_score_change_event`. |
| `backend/verification/verifier.py` | Read `change_event_source`. |
| `backend/advanced/rollback_planner.py` | Add `actor_type`/`actor_id` to `ChangeEventRef`. Group agent events by session. |
| `backend/intelligence/decision_inferrer.py` | Add actor-aware evidence filtering (§1.7 risk B mitigation). |
| `backend/intelligence/inference_evidence.py` | Add explicit GR-2 comment. |
| `backend/mcp/mcp_server.py` | Register `detection.report_agent_edit`, `detection.source_status`, `detection.switch_source` tools. |
| `backend/mcp/tool_handlers.py` | Handlers for the three new MCP tools. Serialize actor fields in existing `provenance_*` responses. |
| `backend/cli.py` | Add `codeledger source show`/`set`/`health` command group. |
| `backend/utils/git_hooks.py` | Extend hook script to capture `author_email` via `git log -1 --format=%ae`. Forward in payload. |
| `backend/auth/credential_manager.py` | Possibly add `get_project_secret(project_id, purpose)` helper. |
| Existing test files | ~16 files need updates: `change_event_type` → `change_event_source`, add actor assertions where appropriate. |
| `frontend/src/api/client.ts` and 2 view files | Widen TS union to include `"agent_reported"`. |

### Deleted files

None.

### Total file count

* **Created:** 11 (code + tests)
* **Modified:** 15–20 (code) + ~16 (existing tests) + 3 (frontend)
* **Grand total touched:** ~50 files

---

## 1.9 Risk summary

### Rank 1 — Per-project detector model vs per-server reality (HIGH likelihood, HIGH impact)

The codebase today runs **one detector backend per server**, not per project. Building `DetectorRegistry.switch_source(project_id, ...)` as a per-project API requires lazy instantiation of per-project detectors and per-project watchdog observers. This is a much bigger change than the prompt implies.

**Mitigation:** either scope the registry per-server (pass `project_id` through without switching behavior) or accept the larger architecture change and budget accordingly. Recommend clarifying with the user before Phase 2 begins.

### Rank 2 — Backfill rule for `actor_id` on git rows is unsatisfiable from stored data (HIGH likelihood, MEDIUM impact)

Git author email is not persisted anywhere in the DB. The post-commit hook never POSTed it. Every existing git-source row will get `actor_id=NULL` after v11 backfill — even though the prompt says "git author email if available."

**Mitigation:** clarify in Phase 2 that backfill yields `actor_id=NULL` for 100% of existing git rows, and update `git_hooks.py` to capture `%ae` going forward. Users will get accurate `actor_id` only on commits **after** they re-run `codeledger init --reinstall-hooks`.

### Rank 3 — Agent self-reporting inflates inference confidence via session_pattern (MEDIUM likelihood, HIGH impact — GR-1/GR-2 at risk)

See §1.7 risk B. Agent volume of edits → inflated `session_pattern` evidence → candidate confidence crosses caps despite the "no boost" policy. This is the exact concern the prompt's hostile-critic instruction flags.

**Mitigation:** in Phase 2 step 2.9, the inference engine must filter or downweight evidence from `agent_reported` events. Simplest rule: `session_pattern` weight drops to 0.0 when every underlying ASTChange has `actor_type='agent'`. Add a dedicated test.

---

## 1.10 Stop and wait

```
PHASE 1 COMPLETE.
Awaiting user review.
Reply with 'APPROVED: proceed to Phase 2' to implement.
Reply with anything else to hold or revise the design.
```

---

# Phase 2 — Implementation report

Implemented on branch `feat/detection-source-actor-schema`. Design revisions from the user's approval message (2026-04-16) are honored throughout.

## Design decisions baked into Phase 2

| Decision | How it was implemented |
|---|---|
| Registry is **per-server**, not per-project | `DetectorRegistry.switch_source` updates the `project_source_config` preference row only. Detectors are started once at server startup and tag every event with their own source. No per-project detector instances. |
| `actor_id` backfill is **NULL for all legacy rows** | v11 adds `actor_type='human'` default. No `actor_id` backfill attempted. Forward-only enrichment from hook payloads (post-commit endpoint now reads optional `author_email`). |
| `SOURCE_CONFIDENCE_MULTIPLIERS` | `backend/intelligence/inference_evidence.py` exports the dict. `DecisionInferrer._score_candidate` multiplies weight × source multiplier *before* the 0.65 single-signal cap fires. Agent events at 0.5x; human and file-snapshot sources at 1.0x. |
| Vault location | Confirmed at `backend/auth/credential_manager.py`. Per-project webhook secret via `CredentialManager.get("webhook_github", project_id)` — producing vault key `webhook_github:<project_id>`. |
| No write-permission tier | `ToolHandlers.detection_switch_source` documents the policy explicitly and performs no extra auth check beyond the `AuthMiddleware` gate. |
| `down_v11` raises `NotImplementedError` | With a clear message pointing at the backup path. No auto-rollback machinery added. |
| Frontend widened | `frontend/src/api/client.ts` exports `ChangeEventSource` and `ActorType`. The two views branch on all three sources. `npm run build` passes (TypeScript strict mode). |
| v11 is transactional + version-gated | `_apply_v11` on SQLite uses `conn.executescript()` (atomic transaction). `_MIN_SQLITE_VERSION = (3, 25, 0)` enforced before DDL. PostgreSQL path uses `conn.transaction()`. |

## Files created (18)

**Detection subsystem (8):**
`backend/detection/__init__.py`, `events.py`, `base.py`, `git_commit.py`, `file_snapshot.py`, `agent_reported.py`, `registry.py`, `webhook.py`.

**New tests (10):**
`tests/unit/test_detection_events.py`, `test_detection_base.py`, `test_detection_detectors.py`, `test_detection_registry.py`, `test_detection_webhook.py`, `test_detection_handlers.py`, `test_migration_v11.py`, `test_source_confidence_multiplier.py`, `test_harness_bot_exclusion.py`, `test_cli_source.py`.

## Files modified (34)

**Backend (14):** `advanced/rollback_planner.py`, `cli.py`, `db/db_backend.py`, `db/migrations.py`, `intelligence/ast_tracker.py`, `intelligence/decision_inferrer.py`, `intelligence/inference_evidence.py`, `main.py`, `mcp/mcp_server.py`, `mcp/tool_handlers.py`, `models.py`, `verification/harness.py`, `verification/provenance.py`, `verification/verifier.py`.

**Frontend (3):** `api/client.ts`, `views/DecisionsView.tsx`, `views/ProvenanceView.tsx`.

**Existing tests (17):** bulk rename `change_event_type` → `change_event_source` in call sites. Two test files deliberately retain the old name: `test_migration_v11.py` (seeds pre-v11 rows) and `test_detection_events.py` (exercises the legacy-row converter).

## Files deleted

None.

## Deviations from the Phase 2 plan

1. **Migration file location.** The prompt named `backend/migrations/v11_actor_source_schema.py`. Existing migrations live in a single `backend/db/migrations.py`; creating a parallel directory would split the state machine. The v11 payload is implemented as `_apply_v11` in the existing file plus a `Migration(version=11, up_callable=_apply_v11)` registration. The `Migration` dataclass gained an optional `up_callable` field (backward-compatible, defaults to `None`).

2. **Rollback planner field addition.** In addition to per-event `actor_type`/`actor_id`, `RollbackPlan` gained `agent_sessions_affected: list[str]` so callers do not need to re-aggregate by `actor_id`.

3. **Post-commit hook template not updated.** The prompt did not require it. `/api/hooks/post-commit` now *accepts* an optional `author_email` field on incoming payloads, but the installed hook scripts (rendered by `backend/utils/git_hooks.py`) do not yet send it. Existing installs will continue producing rows with `actor_id=NULL`. Flagged as follow-up.

4. **Frontend — agent_reported visual styling.** `agent_reported` nodes reuse the diamond styling used for file snapshots. A dedicated shape or colour is a follow-up.

## Follow-up work identified, deferred

- **Update `backend/utils/git_hooks.py`** to capture `author_email` via `git log -1 --format=%ae` in the rendered hook script and re-install via `codeledger init --reinstall-hooks`.
- **Dedicated visual affordance for `agent_reported`** in ProvenanceView (distinct glyph or colour).
- **v12 migration** dropping the `change_events_legacy` view once external consumers have migrated.
- **Per-statement transaction wrapping** for migrations other than v11 (§1.7 risk D).
- **`score_agent_reported` specialisation** in the harness if agent-reported events grow evidence types distinct from file-snapshot events.

## Test results

Full suite: **1265 passing, 6 skipped, 4 failing.**

The 4 failures were verified on unmodified `main` via `git stash` + re-run before restoring Phase 2 — all are pre-existing environmental / test-drift issues, none caused by this change:

| Test | Root cause |
|---|---|
| `tests/unit/test_cli.py::TestCustomPort::test_resolve_serve_bindings_reads_from_toml` | Fixture relies on a `codeledger.toml` the sandbox does not write when `CODELEDGER_CONFIG=/dev/null`. |
| `tests/qa/test_port_configuration.py::TestPortInConfig::test_resolve_serve_bindings_reads_toml` | Same as above. |
| `tests/integration/test_team_mode.py::TestBindingResolution::test_resolve_serve_bindings_reads_toml` | Same as above. |
| `tests/qa/test_security_invariants.py::TestSEC05_AuthOnEveryEndpoint::test_every_private_route_returns_401_without_auth` | `/api/auth/oauth/providers` is whitelisted under `_PUBLIC_PREFIXES = ("/api/auth/oauth/",)` in `backend/main.py:91`. The test's assertion has drifted from the whitelist. |

Frontend: `npm run build` completed with zero TypeScript errors (`✓ 2401 modules transformed`).

## Commit

A single commit on `feat/detection-source-actor-schema` bundles all Phase 2 changes. 53 files changed, approximately +4543 / -194 lines. Run `git log -1 feat/detection-source-actor-schema` for the concrete SHA (the exact value drifts with any documentation amendment).

**No push has been made. No PR has been opened.**

