# Connector Framework — Phase 1 Alignment Audit

Scope: align the proposed connector marketplace (external tools + databases)
with the current CodeLedger codebase. No code has been written. This
document surfaces what exists, what is missing, what is risky, and what
would need to be built.

Repo state at audit time:
- Branch: `feat/detection-source-actor-schema`
- Version: `0.3.4` (pyproject.toml)
- HEAD: `810c2f5` (Google + GitHub OAuth browser redirect flow)
- Python: 3.12, `.venv/` in-place
- Tests passing: 1282 / 1288 (6 platform-skip, 0 failures) — confirmed this run

---

## 1.1 — Existing connector / integration code

Grep scope: `grep -rn "\\bconnector\\b|gmail|jira|slack|notion|linear|asana|mongodb|databricks|snowflake|bigquery|clickhouse|cassandra" backend/`

**Result: effectively zero prior art.** Two incidental hits:

| File | Line | Nature |
|---|---|---|
| `backend/models.py:263` | `ServiceConnection` dataclass — docstring mentions GitHub/Jira/Slack | scaffold only, no readers/writers |
| `backend/utils/log_sanitizer.py:27` | Slack-token redaction regex | logging hygiene, unrelated to an SDK connector |

**Pre-built scaffolding worth reusing:**

- `backend/models.py:261-272` — `ServiceConnection` dataclass (fields: `user_id`, `provider`, `status`, `scopes`, `expires_at`). Has no writes from any code path today.
- `backend/db/migrations.py:173-184` — `service_connections` SQLite table created unconditionally at migration time, plus `idx_svc_user` index on `user_id`.

Net: the domain slot exists at model + migration level but nothing populates it. No abstract connector base, no registry, no per-connector tool files, no `connectors/` package.

---

## 1.2 — Existing OAuth infrastructure

`backend/auth/oauth_manager.py` already implements a substantial OAuth layer. Key surface:

| Capability | Location | Notes |
|---|---|---|
| Provider registry (TOML) | `providers.toml` | ships Google, GitHub, GitLab, Atlassian (Jira/Confluence), Slack, Linear, Notion. Marked `use_for_service` per provider. |
| `load_providers(path)` | `oauth_manager.py:131` | returns `dict[str, ProviderConfig]` |
| `ProviderConfig` | `oauth_manager.py:50` | fields: `authorize_url`, `token_url`, `userinfo_url`, `scopes`, `pkce`, `client_id_env`, `client_secret_env`, `device_code_url` |
| `OAuthManager.get_client_credentials` | `oauth_manager.py:235` | env-var first, vault fallback via `_creds.get(provider, "client_id")` |
| `OAuthManager.browser_flow` | `oauth_manager.py:259` | desktop-style flow — binds a local HTTP listener, opens `webbrowser`. Not suitable for server-hosted redirect flow. |
| `OAuthManager.device_flow` | `oauth_manager.py:307` | RFC 8628 headless flow with polling |
| `OAuthManager.store_api_key` | `oauth_manager.py:369` | persists manual API keys via `_creds.set(provider, f"api_key:{user_id}", key)` |
| `OAuthManager.get_access_token` | `oauth_manager.py:377` | returns cached in-memory token or refreshes via stored refresh token — handles expiry. Returns `None` on failure. |
| `_store_tokens` | `oauth_manager.py:413` | refresh_token persisted, access_token held in `self._tokens` dict only. |
| CSRF state / PKCE helpers | `oauth_manager.py:93,98,110` | `generate_state`, `generate_pkce`, `build_auth_url` — already module-level reusable. |
| Dashboard OAuth login | `backend/main.py:418-778` | `/api/auth/oauth/providers`, `/api/auth/oauth/{provider}`, `/api/auth/oauth/{provider}/callback` — landed earlier in this branch for dashboard sign-in, use cookie-based state/PKCE persistence. |

**Shared token-refresh mechanism:** `get_access_token` exists, with refresh via stored refresh token. A connector framework can call `OAuthManager.get_access_token(provider_name, user_id)` on every outbound request and get automatic refresh. This satisfies the prompt's "refresh automatically before each API call" requirement without a new OAuthManager class.

**Token storage format today:** `refresh_token:{user_id}` and `api_key:{user_id}` keyed per provider. The prompt proposes a per-connector prefix `connector_{slug}_{credential_name}`. The two naming schemes would coexist — no conflict, but a decision is needed on which the new framework standardizes on.

**`httpx` is already a dependency** (`httpx~=0.28.0`, pyproject.toml:54) — all connectors can use it without adding a new dep.

---

## 1.3 — MCP tool registration pattern

**Location:** `backend/mcp/mcp_server.py`, function `create_mcp_server(handlers)`.

**Pattern — manual registration, single entry per namespace:**

```python
@mcp.tool()
async def context(method: str, user_id: str | None = None, ...) -> Any:
    """Context operations. Methods: create|read|update|delete|list|get_relevant|..."""
    uid = _resolve_user_id(user_id)
    ctx = await _bootstrap_session(...)   # universal session hook
    if method == "create":  ...
    if method == "read":    ...
```

Key properties:

- Every MCP tool is a single `@mcp.tool()` function; dispatch is internal by a `method: str` parameter.
- 17 `@mcp.tool()` decorators at `mcp_server.py` lines 103, 219, 355, 409, 450, 506, 525, 553, 568, 583, 597, 631, 661, 686, 700, 724, 738.
- Business logic lives in `backend/mcp/tool_handlers.py` (`ToolHandlers` class) — `mcp_server.py` just normalizes inputs and delegates.
- User resolution via `_resolve_user_id` — accepts explicit `user_id` or pulls from `AuthMiddleware` ContextVar.
- A "universal session bootstrap" hook (`_bootstrap_session`) is called from every tool so any MCP client auto-creates a session on its first call.

**Impact on connector framework:**
- A single `connectors` MCP tool with `method: str` dispatch matches existing style.
- Sub-methods from the prompt (`search_all`, `search`, `get_item`, `link_to_decision`, `status`, `list_tables`, `describe_table`, `sample_rows`, `db_allow_write`, `get_schema_summary`) fit cleanly under one decorated function.
- Business logic should go in `ToolHandlers` — not in mcp_server — to mirror the existing pattern.
- Tools are NOT auto-discovered — each must be explicitly registered in `create_mcp_server`. Adding one tool = one decorated function; that is the total integration surface.

---

## 1.4 — Frontend connector surface

| Surface | Status |
|---|---|
| Dedicated `ConnectorsView` | **Does not exist** |
| Tab routing | Zustand store `appStore.ts` with hash-based routes and `Tab` enum: `memory \| decisions \| sprint \| sessions \| explorer \| provenance \| mcp \| settings` |
| Tab nav | `frontend/src/components/Layout.tsx:22-29` — 8 tabs |
| Reusable UI components | `frontend/src/components/ui/` — `Card`, `Button`, `Input`, `Badge`, `Select` (already used by `MCPServersView`) |
| `MCPServersView.tsx` | **Name is a false friend** — this manages MCP *servers CodeLedger can connect to* (HTTP/SSE/stdio, auth=oauth/api_key/none), not external tool connectors. It is a closer analogue of what a `ConnectorsView` needs than the other views; worth referencing for card layout. |
| OAuth button + status-check pattern | `frontend/src/views/LoginView.tsx` — shows provider buttons, queries `/api/auth/oauth/providers` for configured state, disables unconfigured. Template for per-connector buttons. |

**Adding a Connectors tab requires:**

- Extend `Tab` enum + `VALID_TABS` in `appStore.ts` (2 lines).
- Add nav entry in `Layout.tsx` (1 line).
- Create `views/ConnectorsView.tsx` (new file).
- Add render branch in `App.tsx` (1 line).

No existing views need to be displaced.

---

## 1.5 — Database dependency audit

Probed via `.venv/bin/python` `importlib.import_module`:

| Driver | State today | Per-prompt plan |
|---|---|---|
| `asyncpg` | **installed** (0.30, part of `[postgres]` extra) | reuse for PostgreSQL + TimescaleDB connectors |
| `aiosqlite` | installed (core dep) | SQLite already supported; external-SQLite connector would reuse |
| `httpx` | installed (core dep) | all HTTP-based connectors |
| `psycopg2`, `pymysql`, `aiomysql` | missing | add as optional `[mysql]` (aiomysql) |
| `motor`, `pymongo` | missing | add as optional `[mongodb]` (motor) |
| `redis` | missing | add as optional `[redis-connector]` |
| `influxdb_client` | missing | add as optional `[influxdb]` |
| `databricks` | missing | add as optional `[databricks]` |
| `snowflake.connector` | missing | add as optional `[snowflake]` |
| `google.cloud.bigquery` | missing | add as optional `[bigquery]` |
| `elasticsearch` | missing | add as optional `[elasticsearch]` |
| `boto3` / `aioboto3` | missing | add as optional `[dynamodb]` |
| `cassandra` | missing | add as optional `[cassandra]` |
| `clickhouse_driver` | missing | add as optional `[clickhouse]` |

**Takeaway:** PostgreSQL + TimescaleDB can ship immediately reusing `asyncpg`. Every other database driver requires opting in via `pip install codeledger-ai[...]`. The import-guard pattern (each connector wraps its driver import in `try/except ImportError`, raises `RuntimeError` with install instructions on construction when absent) matches the prompt's requirement.

---

## 1.6 — Proposed connector inventory

External tools:

| Slug | Auth | Required credentials | Python library | Optional extra |
|---|---|---|---|---|
| `gmail` | oauth2 | client_id, client_secret | `httpx` (REST) | — (core) |
| `drive` | oauth2 | client_id, client_secret | `httpx` | — |
| `calendar` | oauth2 | client_id, client_secret | `httpx` | — |
| `slack` | oauth2 | client_id, client_secret | `httpx` | — |
| `jira` | oauth2 | client_id, client_secret, cloud_id | `httpx` | — |
| `confluence` | oauth2 | client_id, client_secret, cloud_id | `httpx` | — |
| `linear` | oauth2 | client_id, client_secret | `httpx` (GraphQL) | — |
| `notion` | oauth2 | client_id, client_secret | `httpx` | — |
| `github_issues` | oauth2 | reuse existing GitHub OAuth | `httpx` | — |
| `asana` | oauth2 | client_id, client_secret | `httpx` | — |

Primary MCP tools per external connector: `search(query)`, `get_item(id)`, plus the shared `link_to_decision`. No per-connector MCP tools — a single `connectors` tool dispatches by slug.

Databases:

| Slug | Auth | Required credentials | Python library | Optional extra |
|---|---|---|---|---|
| `postgresql` | connection_string | DSN | `asyncpg` | `[postgres]` *(exists)* |
| `mysql` | connection_string | host/user/pass/db | `aiomysql` | `[mysql]` *(new)* |
| `mongodb` | connection_string | URI | `motor` | `[mongodb]` *(new)* |
| `redis` | connection_string | URL | `redis` (asyncio) | `[redis-connector]` *(new, avoid clobbering the redis package name)* |
| `influxdb` | api_key + url + org + bucket | token, org, bucket | `influxdb-client` | `[influxdb]` *(new)* |
| `timescaledb` | connection_string | DSN | `asyncpg` | `[postgres]` *(reuse)* |
| `databricks` | api_key + hostname + http_path | PAT, hostname, http_path | `databricks-sql-connector` | `[databricks]` *(new)* |
| `snowflake` | account + user + pass/key | account/user/pass | `snowflake-connector-python` | `[snowflake]` *(new)* |
| `bigquery` | service_account_json OR reuse Google OAuth | credentials JSON | `google-cloud-bigquery` | `[bigquery]` *(new)* |
| `elasticsearch` | api_key + url | api_key, hosts | `elasticsearch[async]` | `[elasticsearch]` *(new)* |
| `dynamodb` | aws_access_key + secret + region | AWS creds | `aioboto3` | `[dynamodb]` *(new)* |
| `clickhouse` | host + port + user + pass | host/port/user/pass | `clickhouse-driver` | `[clickhouse]` *(new)* |
| `cassandra` | contact_points + keyspace + user + pass | hosts, keyspace | `cassandra-driver` | `[cassandra]` *(new, sync-only driver — see risk #1)* |

Primary database MCP tools: `list_tables`, `describe_table`, `sample_rows`, `get_schema_summary`, `db_allow_write` (admin gate).

---

## 1.7 — File tree delta

New files (42):

```
backend/connectors/__init__.py
backend/connectors/base.py                       AbstractConnector + dataclasses + enums
backend/connectors/registry.py                   ConnectorRegistry w/ parallel search_all + timeout
backend/connectors/routes.py                     /connectors/{slug}/connect|callback|setup|disconnect|status
backend/connectors/google/__init__.py
backend/connectors/google/gmail.py
backend/connectors/google/drive.py
backend/connectors/google/calendar.py
backend/connectors/slack/__init__.py
backend/connectors/slack/slack.py
backend/connectors/atlassian/__init__.py
backend/connectors/atlassian/jira.py
backend/connectors/atlassian/confluence.py
backend/connectors/linear/__init__.py
backend/connectors/linear/linear.py
backend/connectors/notion/__init__.py
backend/connectors/notion/notion.py
backend/connectors/github/__init__.py
backend/connectors/github/issues.py
backend/connectors/asana/__init__.py
backend/connectors/asana/asana.py
backend/connectors/databases/__init__.py
backend/connectors/databases/base.py             AbstractDatabaseConnector w/ write gate
backend/connectors/databases/postgresql.py
backend/connectors/databases/mysql.py
backend/connectors/databases/mongodb.py
backend/connectors/databases/redis.py
backend/connectors/databases/influxdb.py
backend/connectors/databases/timescaledb.py
backend/connectors/databases/databricks.py
backend/connectors/databases/snowflake.py
backend/connectors/databases/bigquery.py
backend/connectors/databases/elasticsearch.py
backend/connectors/databases/dynamodb.py
backend/connectors/databases/clickhouse.py
backend/connectors/databases/cassandra.py
frontend/src/views/ConnectorsView.tsx
tests/unit/connectors/__init__.py
tests/unit/connectors/test_base.py
tests/unit/connectors/test_registry.py
tests/unit/connectors/test_gmail.py
tests/unit/connectors/test_jira.py
tests/unit/connectors/test_postgresql.py
tests/unit/connectors/test_mysql.py               import-guard regression
tests/unit/connectors/test_influxdb.py
tests/integration/test_connector_routes.py
tests/integration/test_connector_mcp_tools.py
```

Files modified (8):

```
backend/main.py                     register ConnectorRegistry, mount routes, add CSRF cookies for connector OAuth
backend/mcp/mcp_server.py           add single `connectors` tool with method dispatch
backend/mcp/tool_handlers.py        add handler methods behind the `connectors` tool
backend/cli.py                      add `connectors` command group
backend/models.py                   extend ServiceConnection or introduce ProvenanceEdge source type "connector_{slug}"
frontend/src/store/appStore.ts      add "connectors" to Tab enum + VALID_TABS
frontend/src/components/Layout.tsx  add nav entry
frontend/src/App.tsx                render branch
frontend/src/api/client.ts          typed connector endpoints
pyproject.toml                      add optional extras [mysql], [mongodb], [redis-connector], [influxdb], [databricks], [snowflake], [bigquery], [elasticsearch], [dynamodb], [clickhouse], [cassandra], [all-databases], [all]
```

**Total:** 42 created + 10 modified = **52 files**. Sensible to split into 4–6 PRs (base+registry, google+github+slack, atlassian+linear+notion+asana, sql databases, nosql databases, frontend). The prompt's Step 2.15 asks for a single commit — consider splitting.

---

## 1.8 — Risk summary

| # | Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| 1 | **`cassandra-driver` is sync-only.** Running it blocks the event loop; `ConnectorRegistry.search_all` uses `asyncio.gather`, so a hung Cassandra query stalls the executor. | Medium | High (single slow connector can block all searches) | Run all Cassandra calls via `loop.run_in_executor` with a dedicated thread pool. Enforce the 10s timeout on the executor-wrapped future, not inside the driver. Document this in the Cassandra connector module. |
| 2 | **DB "read-only by default" is hard to enforce generically.** The prompt promises reads only; the connection itself has write authority. A buggy `sample_rows` or an operator who calls `sample_rows(table="users WHERE 1=1; DROP TABLE users")` could execute writes. | Medium | Critical (data loss) | Parameterize *all* DB calls. Validate table/column names against `information_schema` / `SHOW TABLES` whitelists before interpolating into SQL. For Postgres use a read-only transaction (`BEGIN READ ONLY`) per session. For databases without read-only txn support (Redis/Mongo/Dynamo/Cassandra/Influx), refuse to register the connector in write mode unless `write_allowed=True`. Add a regression test that attempts injection in every connector. |
| 3 | **PII passthrough via `get_item`.** `search()` returns 500-char summaries, but `get_item` returns the full record. Decision-linking legitimately needs this, but the agent (or any downstream logger) then has PII in its context. | Medium | Medium/High (regulatory — GDPR/HIPAA surfaces) | PII redaction pass in `get_item` for known PII fields (email/phone/SSN regex) before returning. Log all `get_item` calls with connector_slug + item_id (but not body) so audit is possible. Document that raw content should not be stored in decisions, only links. |
| 4 | **OAuth CSRF gap across multiple in-flight connectors.** User opens Slack + Jira connect flows in two tabs; state cookies overwrite each other if the same cookie name is reused. | Medium | Medium (CSRF bypass potential) | Already addressed for dashboard OAuth via per-provider cookie names (`codeledger_oauth_state_{provider}`). Extend the same pattern to connector cookies: `codeledger_connector_state_{slug}`. Never use a generic name. |
| 5 | **Optional-import race in `ConnectorRegistry` registration.** The prompt's registration loop does `try: __import__(...); except (ImportError, RuntimeError): pass`. RuntimeError from inside `__init__` when a driver is missing would be caught, but any *other* RuntimeError (configuration bug, missing credentials key) would also be silently swallowed — the connector disappears from the dashboard with no trace. | High | Medium (debug nightmare) | Narrow the except clause to `ImportError` only. Move the "driver missing" check into a `cls.is_available()` class method that returns `bool`, not a constructor that raises. Registry logs a WARNING when a connector is skipped and why. |

---

## 1.9 — Stop and wait

```
PHASE 1 COMPLETE.
Awaiting user review.
Reply 'APPROVED: proceed to Phase 2' to implement.
```
