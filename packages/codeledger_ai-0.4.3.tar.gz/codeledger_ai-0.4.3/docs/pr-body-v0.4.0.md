## Summary

Adds a full connector marketplace: 26 connectors (12 external + 14 database) wired through MCP tools, HTTP API, CLI, and dashboard. One `build_default_registry` populates every entry point with the same connector set.

Also fixes 8 pre-existing UX bugs on the MCP Servers and Settings pages (surfaced during the same design review) and closes 4 critical path-traversal findings from the pre-merge security review.

Version bump: **0.3.4 → 0.4.0**. See CHANGELOG for full details.

## What ships

**External connectors (12, httpx-only):** Gmail, Drive, Calendar, Slack, Jira, Confluence, Linear, Notion, GitHub Issues, Asana, Teams, Outlook.

**Database connectors (14, each opt-in via optional extra):** PostgreSQL, TimescaleDB, MySQL, MongoDB, Redis, Elasticsearch, InfluxDB 2, InfluxDB 3, DynamoDB, Databricks, Snowflake, BigQuery, ClickHouse, Cassandra. Sync drivers funnel through `run_in_executor` so the MCP event loop stays free even under Cassandra's blocking driver.

**New public surface:**
- `/api/connectors/status`, `/{slug}/health`, `/{slug}/setup`, `/{slug}/disconnect` (auth-required) + `/oauth/{slug}/connect` and `/callback` (public, per-slug CSRF cookies)
- MCP `connectors` tool — 9 methods, 10s timeout per call
- `codeledger connectors list|status|connect|disconnect|test` + `codeledger connectors db schema`
- Dashboard **Connectors** tab with Connected / Available sections by category
- Settings "Connect" buttons now drive the real OAuth flow

## Security invariants upheld

- **SEC-02** — all connector error logs use `exc.__class__.__name__`, never `str(exc)`
- **SEC-03** — `ConnectorResult.summary` hard-capped at 500 chars (`__post_init__`); explicit PII boundary tests on Gmail, Calendar, Outlook, Teams, Confluence, Slack
- **SEC-04** — every connector credential routes through `CredentialManager` under `connector_{slug}` namespace; no SQL column, no disk file
- **SEC-05** — MCP `connectors.*` resolves `user_id` first; write endpoints sit behind `AuthMiddleware`
- **SEC-06** — per-slug state + PKCE verifier cookies on every OAuth flow
- **SQL injection** — every DB connector whitelist-validates table names via `_validate_table()` before interpolation
- **Path traversal** — `get_item` rejects `..` and `/` across Confluence, Drive, GCal, Jira, Notion, Outlook, Teams, Asana

## UX bug fixes (MCP Servers + Settings)

- MCP Servers: API-key input field, stdio auth hiding, form validation, edit-mode visual distinction, edit preserves `toolCount`/`status`/`tools`, list persisted to localStorage
- Appearance: theme preference persisted to localStorage
- Connected services: Connect buttons now drive real OAuth flow instead of faking local `{connected: true}` state

## Test plan

- [x] `ruff check backend/connectors/` — clean
- [x] `mypy --strict backend/connectors/` — clean (38 source files)
- [x] `tsc --noEmit` — clean
- [x] `vite build` — clean
- [x] `pytest` — **1648 passed, 6 skipped, 0 failures** (+362 connector-specific tests)
- [x] Live `create_app()` composition — 6 connector routes registered, 14 default connectors registered, 12 optional drivers skipped at INFO with install instructions
- [x] CLI smoke (`connectors list|status|test`) — tabular output, correct exit codes
- [x] Pre-merge security review — 4 Critical findings fixed in `7aa33ea` before this PR was opened

## Commit list

18 commits: `578ad93..a3b661c`. Sub-phase boundaries preserved (A-2 base → A-13 finalization) for easier review.
