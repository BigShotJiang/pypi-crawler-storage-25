"""Tests for migration v11 — actor + source schema.

Covers:

* A fresh database can migrate to v11 and the resulting ``ast_changes``
  carries ``change_event_source``, ``actor_type``, and ``actor_id``.
* A seeded v10 database migrates cleanly: existing rows backfill to
  ``actor_type='human'`` and ``actor_id=NULL`` without losing data.
* ``apply_migrations`` is idempotent — running it twice does not
  re-apply v11 or duplicate rows.
* The ``change_events_legacy`` view surfaces the old
  ``change_event_type`` column name for external consumers.
* ``project_source_config`` table exists with the expected columns.
* ``down_v11`` raises ``NotImplementedError`` with a pointer to the
  backup-based recovery path — no auto-rollback is attempted.
* The SQLite version guard trips when the runtime is below 3.25.0.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import (
    _apply_v11,
    _parse_sqlite_version,
    apply_migrations,
    down_v11,
)

if TYPE_CHECKING:
    from pathlib import Path


pytestmark = pytest.mark.asyncio


@pytest.fixture
async def fresh_backend(tmp_path: Path) -> SQLiteBackend:
    """Empty SQLite backend with no migrations applied yet."""
    backend = SQLiteBackend(tmp_path / "fresh.db")
    await backend.connect()
    yield backend
    await backend.close()


async def _table_info(backend: SQLiteBackend, table: str) -> list[dict]:
    """Return sqlite ``PRAGMA table_info`` rows for ``table``."""
    return await backend.execute_raw(f"PRAGMA table_info({table})")


async def _index_list(backend: SQLiteBackend, table: str) -> set[str]:
    """Return the set of index names defined on ``table``."""
    rows = await backend.execute_raw(f"PRAGMA index_list({table})")
    return {str(r["name"]) for r in rows}


async def _columns(backend: SQLiteBackend, table: str) -> set[str]:
    """Return the set of column names on ``table``."""
    rows = await _table_info(backend, table)
    return {str(r["name"]) for r in rows}


class TestFreshMigration:
    """Run v11 on an empty schema and assert the target shape."""

    async def test_full_migration_chain_includes_v11(
        self, fresh_backend: SQLiteBackend
    ) -> None:
        applied = await apply_migrations(fresh_backend)
        assert 11 in applied

    async def test_change_event_source_column_present(
        self, fresh_backend: SQLiteBackend
    ) -> None:
        await apply_migrations(fresh_backend)
        cols = await _columns(fresh_backend, "ast_changes")
        assert "change_event_source" in cols
        assert "change_event_type" not in cols

    async def test_actor_columns_present(
        self, fresh_backend: SQLiteBackend
    ) -> None:
        await apply_migrations(fresh_backend)
        info = await _table_info(fresh_backend, "ast_changes")
        actor_type = next(r for r in info if r["name"] == "actor_type")
        actor_id = next(r for r in info if r["name"] == "actor_id")
        assert actor_type["notnull"] == 1
        assert actor_type["dflt_value"] == "'human'"
        assert actor_id["notnull"] == 0

    async def test_project_source_config_table(
        self, fresh_backend: SQLiteBackend
    ) -> None:
        await apply_migrations(fresh_backend)
        cols = await _columns(fresh_backend, "project_source_config")
        # ``id`` is the PK column — per this table's convention, it
        # holds the project_id value directly.
        assert cols == {
            "id",
            "preferred_source",
            "created_at",
            "updated_at",
        }

    async def test_composite_index_present(
        self, fresh_backend: SQLiteBackend
    ) -> None:
        await apply_migrations(fresh_backend)
        indexes = await _index_list(fresh_backend, "ast_changes")
        assert "idx_ast_actor_source_created" in indexes

    async def test_legacy_view_exposes_old_name(
        self, fresh_backend: SQLiteBackend
    ) -> None:
        await apply_migrations(fresh_backend)
        rows = await fresh_backend.execute_raw(
            "SELECT name FROM sqlite_master "
            "WHERE type = 'view' AND name = 'change_events_legacy'"
        )
        assert rows and rows[0]["name"] == "change_events_legacy"


class TestSeededMigration:
    """Start at v10, seed rows, then apply v11 and verify backfill."""

    async def _seed_pre_v11(self, backend: SQLiteBackend) -> None:
        """Apply v1–v10 without v11 by temporarily trimming MIGRATIONS."""
        from backend.db import migrations as mig

        original = mig.MIGRATIONS
        try:
            mig.MIGRATIONS = tuple(m for m in original if m.version <= 10)
            await apply_migrations(backend)
        finally:
            mig.MIGRATIONS = original

    async def test_existing_rows_backfill_to_human_null(
        self, fresh_backend: SQLiteBackend
    ) -> None:
        from datetime import UTC, datetime

        await self._seed_pre_v11(fresh_backend)
        seeded = {
            "id": "change-1",
            "commit_hash": "abc123",
            "file_path": "main.py",
            "language": "python",
            "change_type": "added",
            "entity_name": "main",
            "entity_type": "function",
            "session_id": None,
            "created_at": datetime.now(UTC).isoformat(),
            "updated_at": datetime.now(UTC).isoformat(),
            "change_event_id": "abc123",
            "change_event_type": "git_commit",
            "project_id": "proj",
        }
        await fresh_backend.insert("ast_changes", seeded)

        applied = await apply_migrations(fresh_backend)
        assert 11 in applied

        rows = await fresh_backend.execute_raw(
            "SELECT id, change_event_source, actor_type, actor_id "
            "FROM ast_changes WHERE id = ?",
            ("change-1",),
        )
        assert len(rows) == 1
        row = rows[0]
        assert row["change_event_source"] == "git_commit"
        assert row["actor_type"] == "human"
        assert row["actor_id"] is None

    async def test_rerun_is_idempotent(
        self, fresh_backend: SQLiteBackend
    ) -> None:
        await apply_migrations(fresh_backend)
        second = await apply_migrations(fresh_backend)
        assert second == []


class TestSourceCheckConstraints:
    """The widened source enum accepts the three legal values only."""

    async def test_accepts_agent_reported(
        self, fresh_backend: SQLiteBackend
    ) -> None:
        from datetime import UTC, datetime

        await apply_migrations(fresh_backend)
        now = datetime.now(UTC).isoformat()
        await fresh_backend.insert(
            "project_source_config",
            {
                "id": "proj-a",
                "preferred_source": "agent_reported",
                "created_at": now,
                "updated_at": now,
            },
        )
        rows = await fresh_backend.query(
            "project_source_config", where={"id": "proj-a"}
        )
        assert rows[0]["preferred_source"] == "agent_reported"

    async def test_rejects_unknown_actor_type(
        self, fresh_backend: SQLiteBackend
    ) -> None:
        from datetime import UTC, datetime

        from backend.db.db_backend import DatabaseError

        await apply_migrations(fresh_backend)
        now = datetime.now(UTC).isoformat()
        with pytest.raises(DatabaseError):
            await fresh_backend.insert(
                "ast_changes",
                {
                    "id": "bad",
                    "commit_hash": "",
                    "file_path": "x.py",
                    "language": "python",
                    "change_type": "added",
                    "entity_name": "x",
                    "entity_type": "function",
                    "session_id": None,
                    "created_at": now,
                    "updated_at": now,
                    "change_event_id": "s1",
                    "change_event_source": "agent_reported",
                    "project_id": "proj",
                    "actor_type": "alien",
                    "actor_id": "agent-1",
                },
            )


class TestDownMigration:
    """``down_v11`` is a deliberate no-op that refuses to auto-rollback."""

    async def test_down_raises_not_implemented(
        self, fresh_backend: SQLiteBackend
    ) -> None:
        await apply_migrations(fresh_backend)
        with pytest.raises(NotImplementedError, match="restore.*backup"):
            await down_v11(fresh_backend)


class TestVersionGuard:
    """Version parsing and the >= 3.25.0 SQLite requirement."""

    async def test_parse_version(self) -> None:
        assert _parse_sqlite_version("3.45.1") == (3, 45, 1)
        assert _parse_sqlite_version("3.25.0") == (3, 25, 0)
        assert _parse_sqlite_version("3.40") == (3, 40, 0)

    async def test_parse_version_rejects_garbage(self) -> None:
        with pytest.raises(RuntimeError, match="Unrecognized"):
            _parse_sqlite_version("banana")

    async def test_old_sqlite_is_rejected(
        self, fresh_backend: SQLiteBackend, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # First drag the DB up to v10 so _apply_v11 is what trips.
        from backend.db import migrations as mig

        original = mig.MIGRATIONS
        mig.MIGRATIONS = tuple(m for m in original if m.version <= 10)
        try:
            await apply_migrations(fresh_backend)
        finally:
            mig.MIGRATIONS = original

        real_execute = fresh_backend.execute_raw

        async def fake_execute(sql, params=None):
            if "sqlite_version" in sql:
                return [{"v": "3.24.0"}]
            return await real_execute(sql, params)

        monkeypatch.setattr(fresh_backend, "execute_raw", fake_execute)
        with pytest.raises(RuntimeError, match="SQLite >= 3.25.0"):
            await _apply_v11(fresh_backend, "sqlite")
