"""Tests for backend.auth.license."""

from __future__ import annotations

import time

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from backend.auth.license import (
    LicenseError,
    LicenseValidator,
    generate_license_token,
)


@pytest.fixture
def keypair() -> tuple[str, str]:
    """Generate a fresh Ed25519 keypair for testing."""
    private = Ed25519PrivateKey.generate()
    public = private.public_key()
    private_pem = private.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")
    public_pem = public.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")
    return private_pem, public_pem


class TestCommunity:
    def test_no_key_returns_community(self) -> None:
        validator = LicenseValidator()
        info = validator.validate(None)
        assert info.tier == "community"
        assert validator.has_feature(info, "semantic_retrieval")
        assert not validator.has_feature(info, "rbac")

    def test_empty_key_returns_community(self) -> None:
        validator = LicenseValidator()
        info = validator.validate("")
        assert info.tier == "community"

    def test_team_features_rejected_without_key(self) -> None:
        validator = LicenseValidator()
        info = validator.validate(None)
        assert not validator.has_feature(info, "multi_user")


class TestOpenBeta:
    def test_open_beta_unlocks_all_features_without_key(self) -> None:
        """When open_beta is true, a missing key still yields every feature."""
        validator = LicenseValidator(open_beta=True)
        info = validator.validate(None)
        assert info.tier == "beta"
        assert validator.has_feature(info, "semantic_retrieval")
        assert validator.has_feature(info, "multi_user")
        assert validator.has_feature(info, "rbac")
        assert info.max_seats >= 1000

    def test_open_beta_default_is_off(self) -> None:
        """Without explicit open_beta, behaviour matches the paid tier model."""
        validator = LicenseValidator()
        info = validator.validate(None)
        assert info.tier == "community"


class TestSignedToken:
    def test_valid_team_token_unlocks_team_features(
        self, keypair: tuple[str, str]
    ) -> None:
        private_pem, public_pem = keypair
        token = generate_license_token(private_pem, tier="team", seats=10)
        validator = LicenseValidator(public_key_pem=public_pem)
        info = validator.validate(token)
        assert info.tier == "team"
        assert info.max_seats == 10
        assert validator.has_feature(info, "multi_user")
        assert validator.has_feature(info, "agent_profiling")
        # Enterprise features still locked.
        assert not validator.has_feature(info, "rbac")

    def test_enterprise_token_unlocks_all(
        self, keypair: tuple[str, str]
    ) -> None:
        private_pem, public_pem = keypair
        token = generate_license_token(private_pem, tier="enterprise")
        validator = LicenseValidator(public_key_pem=public_pem)
        info = validator.validate(token)
        assert info.tier == "enterprise"
        assert validator.has_feature(info, "rbac")
        assert validator.has_feature(info, "sso_saml")

    def test_expired_token_rejected(
        self, keypair: tuple[str, str]
    ) -> None:
        private_pem, public_pem = keypair
        past = int(time.time()) - 60
        token = generate_license_token(
            private_pem, tier="team", expires_at=past
        )
        validator = LicenseValidator(public_key_pem=public_pem)
        with pytest.raises(LicenseError, match="expired"):
            validator.validate(token)

    def test_malformed_token_rejected(self) -> None:
        validator = LicenseValidator()
        with pytest.raises(LicenseError):
            validator.validate("not-a-token")

    def test_signature_mismatch_rejected(
        self, keypair: tuple[str, str]
    ) -> None:
        private_pem, _ = keypair
        token = generate_license_token(private_pem, tier="team")
        # Different keypair for verification.
        other = Ed25519PrivateKey.generate()
        other_public_pem = other.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode("utf-8")
        validator = LicenseValidator(public_key_pem=other_public_pem)
        with pytest.raises(LicenseError):
            validator.validate(token)
