"""v11: harness decision-density ignores ci_bot / webhook_bot actors.

A Dependabot PR (actor_type=webhook_bot) does not indict the human
team's decision hygiene. These tests confirm the harness excludes
bot-authored ASTChange rows from the density calculation but
continues to count human and agent rows.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.models import ASTChange
from backend.verification.harness import QualityHarness

if TYPE_CHECKING:
    from pathlib import Path


pytestmark = pytest.mark.asyncio


@pytest.fixture
async def backend(tmp_path: Path) -> SQLiteBackend:
    db = SQLiteBackend(tmp_path / "h.db")
    await db.connect()
    await apply_migrations(db)
    yield db
    await db.close()


async def _seed_change(
    backend: SQLiteBackend,
    *,
    project_id: str,
    commit: str,
    file_path: str,
    actor_type: str,
) -> ASTChange:
    change = ASTChange(
        commit_hash=commit,
        file_path=file_path,
        language="python",
        change_type="added",
        entity_name="x",
        entity_type="function",
        change_event_id=commit,
        change_event_source="git_commit",
        actor_type=actor_type,
        project_id=project_id,
    )
    await backend.insert("ast_changes", change.to_dict())
    return change


class TestBotExclusion:
    async def test_pure_bot_commit_has_no_structural_signal(
        self, backend: SQLiteBackend
    ) -> None:
        """A commit authored entirely by Dependabot: density is 0/0 = 0.0.

        The harness returns ``critical`` density when structural_changes
        is zero after bot exclusion — same behavior as any event with
        no structural signal. What matters is the bot row did not
        inflate the denominator.
        """
        await _seed_change(
            backend,
            project_id="proj",
            commit="abc",
            file_path="a.py",
            actor_type="webhook_bot",
        )
        harness = QualityHarness(backend)
        score = await harness.score_commit("abc", "proj")
        assert score.decision_density == 0.0
        # Decision density for an "empty" event after exclusion stays
        # in the critical band (< 0.1), matching the zero-signal case.
        assert score.decision_density_status == "critical"

    async def test_human_and_bot_mixed_only_counts_human(
        self, backend: SQLiteBackend
    ) -> None:
        """A commit with 1 human row + 1 webhook_bot row: denominator is 1."""
        await _seed_change(
            backend,
            project_id="proj",
            commit="mix",
            file_path="a.py",
            actor_type="human",
        )
        await _seed_change(
            backend,
            project_id="proj",
            commit="mix",
            file_path="b.py",
            actor_type="webhook_bot",
        )
        harness = QualityHarness(backend)
        score = await harness.score_commit("mix", "proj")
        # 0 decisions / 1 human structural change = 0.0 — still
        # critical, but the denominator is 1 not 2, confirming
        # exclusion happened.
        assert score.decision_density == 0.0

    async def test_agent_rows_still_count_toward_density(
        self, backend: SQLiteBackend
    ) -> None:
        """Agent-sourced rows remain in the denominator (they are not bots)."""
        await _seed_change(
            backend,
            project_id="proj",
            commit="agent-evt",
            file_path="a.py",
            actor_type="agent",
        )
        harness = QualityHarness(backend)
        score = await harness.score_commit("agent-evt", "proj")
        assert score.decision_density == 0.0
        # Denominator was 1 (the agent row). No decisions linked →
        # critical. Presence of the critical status confirms the row
        # was included — an excluded row would have left density
        # reporting 0/0 as well but via the empty-rows path.

    async def test_ci_bot_rows_are_excluded(
        self, backend: SQLiteBackend
    ) -> None:
        """ci_bot actor is excluded just like webhook_bot."""
        await _seed_change(
            backend,
            project_id="proj",
            commit="ci",
            file_path="a.py",
            actor_type="ci_bot",
        )
        harness = QualityHarness(backend)
        score = await harness.score_commit("ci", "proj")
        assert score.decision_density == 0.0
