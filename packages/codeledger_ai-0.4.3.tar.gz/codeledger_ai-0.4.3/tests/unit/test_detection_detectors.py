"""Tests for the three concrete detectors (git, file, agent)."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime

import pytest

from backend.detection.agent_reported import AgentReportedDetector
from backend.detection.base import DetectorStatus
from backend.detection.events import ChangeEvent
from backend.detection.file_snapshot import FileSnapshotDetector
from backend.detection.git_commit import GitCommitDetector


pytestmark = pytest.mark.asyncio


def _event(source: str, actor_type: str = "human", actor_id: str | None = None) -> ChangeEvent:
    return ChangeEvent(
        change_event_source=source,  # type: ignore[arg-type]
        actor_type=actor_type,  # type: ignore[arg-type]
        actor_id=actor_id,
        project_id="proj",
        created_at=datetime.now(UTC),
    )


class TestGitCommitDetector:
    async def test_lifecycle_idempotent(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        det = GitCommitDetector(q)
        assert await det.health() == DetectorStatus.STOPPED
        await det.start()
        await det.start()  # idempotent
        assert await det.health() == DetectorStatus.HEALTHY
        await det.stop()
        await det.stop()  # idempotent
        assert await det.health() == DetectorStatus.STOPPED

    async def test_emit_tags_as_git_commit(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        det = GitCommitDetector(q)
        await det.start()
        ev = _event("git_commit", "human", "dev@example.com")
        await det.emit(ev)
        assert q.qsize() == 1
        got = await q.get()
        assert got.change_event_source == "git_commit"

    async def test_emit_rejects_wrong_source(self) -> None:
        from backend.detection.base import DetectorError

        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        det = GitCommitDetector(q)
        with pytest.raises(DetectorError, match="Source mismatch"):
            await det.emit(_event("file_snapshot"))


class _FakeObserver:
    """Minimal observer stand-in for FileSnapshotDetector tests."""

    def __init__(self, *, alive: bool = True) -> None:
        self.started = False
        self.stopped = False
        self._alive = alive
        self.stop_raises = False

    def start(self) -> None:
        self.started = True

    def stop(self) -> None:
        if self.stop_raises:
            raise RuntimeError("boom")
        self.stopped = True

    def is_alive(self) -> bool:
        return self._alive and self.started and not self.stopped


class TestFileSnapshotDetector:
    async def test_lifecycle_drives_observer(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        observer = _FakeObserver()
        det = FileSnapshotDetector(q, observer_factory=lambda: observer)
        assert await det.health() == DetectorStatus.STOPPED
        await det.start()
        assert observer.started
        assert await det.health() == DetectorStatus.HEALTHY
        await det.stop()
        assert observer.stopped
        assert await det.health() == DetectorStatus.STOPPED

    async def test_start_is_idempotent(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        calls: list[_FakeObserver] = []

        def factory() -> _FakeObserver:
            obs = _FakeObserver()
            calls.append(obs)
            return obs

        det = FileSnapshotDetector(q, observer_factory=factory)
        await det.start()
        await det.start()
        assert len(calls) == 1  # factory invoked once despite two starts

    async def test_health_degraded_when_no_factory(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        det = FileSnapshotDetector(q, observer_factory=None)
        await det.start()
        assert await det.health() == DetectorStatus.DEGRADED

    async def test_health_degraded_when_observer_dies(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        dead_observer = _FakeObserver(alive=False)
        det = FileSnapshotDetector(q, observer_factory=lambda: dead_observer)
        await det.start()
        # Simulate the observer crashing — is_alive returns False.
        dead_observer._alive = False
        dead_observer.started = False
        assert await det.health() == DetectorStatus.DEGRADED

    async def test_stop_tolerates_observer_error(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        obs = _FakeObserver()
        obs.stop_raises = True
        det = FileSnapshotDetector(q, observer_factory=lambda: obs)
        await det.start()
        await det.stop()  # must not raise
        assert det._observer is None

    async def test_emit_tags_as_file_snapshot(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        det = FileSnapshotDetector(q)
        await det.start()
        await det.emit(_event("file_snapshot"))
        got = await q.get()
        assert got.change_event_source == "file_snapshot"


class TestAgentReportedDetector:
    async def test_lifecycle_no_op(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        det = AgentReportedDetector(q)
        await det.start()
        await det.start()
        assert await det.health() == DetectorStatus.HEALTHY
        await det.stop()
        await det.stop()
        assert await det.health() == DetectorStatus.STOPPED

    async def test_health_uses_probe(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        probe_result = {"reachable": True}
        det = AgentReportedDetector(
            q, reachability_probe=lambda: probe_result["reachable"]
        )
        await det.start()
        assert await det.health() == DetectorStatus.HEALTHY
        probe_result["reachable"] = False
        assert await det.health() == DetectorStatus.DEGRADED

    async def test_probe_exception_reports_error(self) -> None:
        def boom() -> bool:
            raise RuntimeError("probe failed")

        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        det = AgentReportedDetector(q, reachability_probe=boom)
        await det.start()
        assert await det.health() == DetectorStatus.ERROR

    async def test_emit_requires_agent_actor(self) -> None:
        # Constructing a ChangeEvent with agent source + no actor_id
        # fails at model construction, not at emit. This test just
        # proves the model enforces it.
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            ChangeEvent(
                change_event_source="agent_reported",
                actor_type="agent",
                actor_id=None,
                project_id="proj",
                created_at=datetime.now(UTC),
            )

    async def test_emit_tags_as_agent_reported(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        det = AgentReportedDetector(q)
        await det.start()
        ev = _event("agent_reported", actor_type="agent", actor_id="sess-1")
        await det.emit(ev)
        got = await q.get()
        assert got.change_event_source == "agent_reported"
        assert got.actor_type == "agent"
