"""Coverage tests for backend.mcp.tool_handlers validation and error paths.

Hits the error branches on sprint/story/context/decision/session/knowledge
tools that the happy-path integration tests skip.
"""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, Any

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.mcp.tool_handlers import HandlerError, ToolHandlers

if TYPE_CHECKING:
    from pathlib import Path


async def _mk_handlers(tmp_path: Path) -> tuple[ToolHandlers, SQLiteBackend]:
    db = SQLiteBackend(tmp_path / "th.db")
    await db.connect()
    await apply_migrations(db)
    return ToolHandlers(db=db), db


class TestContextEdgeCases:
    async def test_read_nonexistent_raises_not_found(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Not found"):
                await h.context_read(
                    user_id=uuid.uuid4(), item_id=uuid.uuid4()
                )
        finally:
            await db.close()

    async def test_update_nonexistent_raises(self, tmp_path: Path) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Not found"):
                await h.context_update(
                    user_id=uuid.uuid4(),
                    item_id=uuid.uuid4(),
                    content="new",
                )
        finally:
            await db.close()

    async def test_delete_nonexistent_returns_not_deleted(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Not found"):
                await h.context_delete(
                    user_id=uuid.uuid4(), item_id=uuid.uuid4()
                )
        finally:
            await db.close()


class TestDecisionEdgeCases:
    async def test_read_nonexistent_raises(self, tmp_path: Path) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Not found"):
                await h.decision_read(
                    user_id=uuid.uuid4(), decision_id=uuid.uuid4()
                )
        finally:
            await db.close()

    async def test_list_invalid_status_rejected(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Invalid decision status"):
                await h.decision_list(user_id=uuid.uuid4(), status="bogus")
        finally:
            await db.close()


class TestStoryEdgeCases:
    async def test_invalid_points_rejected(self, tmp_path: Path) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="non-negative"):
                await h.story_create(
                    user_id=uuid.uuid4(), title="Test", points=-5
                )
        finally:
            await db.close()

    async def test_nonexistent_story_update_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Not found"):
                await h.story_update(
                    user_id=uuid.uuid4(),
                    story_id=uuid.uuid4(),
                    status="in_progress",
                )
        finally:
            await db.close()

    async def test_empty_title_rejected(self, tmp_path: Path) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="non-empty"):
                await h.story_create(user_id=uuid.uuid4(), title="")
        finally:
            await db.close()


class TestSprintEdgeCases:
    async def test_sprint_status_unknown_id_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Not found"):
                await h.sprint_status(
                    user_id=uuid.uuid4(), sprint_id=uuid.uuid4()
                )
        finally:
            await db.close()

    async def test_sprint_burndown_unknown_id_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Not found"):
                await h.sprint_burndown(
                    user_id=uuid.uuid4(), sprint_id=uuid.uuid4()
                )
        finally:
            await db.close()

    async def test_velocity_with_no_sprints_returns_zero(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            result = await h.sprint_velocity(user_id=uuid.uuid4())
            assert result["average_velocity"] == 0.0
            assert result["series"] == []
        finally:
            await db.close()

    async def test_retrospective_unknown_sprint_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Not found"):
                await h.sprint_retrospective(
                    user_id=uuid.uuid4(), sprint_id=uuid.uuid4()
                )
        finally:
            await db.close()


class TestSessionEdgeCases:
    async def test_end_nonexistent_session_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Not found"):
                await h.session_end(
                    user_id=uuid.uuid4(), session_id=uuid.uuid4()
                )
        finally:
            await db.close()

    async def test_idempotent_close_returns_completed(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            uid = uuid.uuid4()
            s = await h.session_start(user_id=uid, agent_name="qa")
            sid = uuid.UUID(s["id"])
            first = await h.session_end(user_id=uid, session_id=sid)
            assert first["status"].startswith("completed")
            second = await h.session_end(user_id=uid, session_id=sid)
            assert second["status"].startswith("completed")
        finally:
            await db.close()

    async def test_conflicts_without_detector_returns_empty(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            # No conflict_detector wired; handler returns empty view.
            uid = uuid.uuid4()
            s = await h.session_start(user_id=uid, agent_name="qa")
            sid = uuid.UUID(s["id"])
            result = await h.session_conflicts(user_id=uid, session_id=sid)
            assert result.get("conflicts") == []
        finally:
            await db.close()


class TestContextGetRelevantGating:
    async def test_requires_semantic_search(self, tmp_path: Path) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Semantic retrieval"):
                await h.context_get_relevant(
                    user_id=uuid.uuid4(), query="x"
                )
        finally:
            await db.close()

    async def test_get_for_file_requires_semantic_search(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Semantic retrieval"):
                await h.context_get_for_file(
                    user_id=uuid.uuid4(), file_path="a.py"
                )
        finally:
            await db.close()


class TestProvenanceGating:
    async def test_without_engine_raises(self, tmp_path: Path) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Provenance"):
                await h.provenance_forward(
                    user_id=uuid.uuid4(), decision_id=uuid.uuid4()
                )
        finally:
            await db.close()

    async def test_reverse_without_engine_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Provenance"):
                await h.provenance_reverse(
                    user_id=uuid.uuid4(),
                    file_path="a.py",
                    entity_name="fn",
                )
        finally:
            await db.close()


class TestAdvancedHandlerGating:
    async def test_drift_without_engine_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError):
                await h.drift_check(
                    user_id=uuid.uuid4(),
                    project_id="p1",
                    repo_path="/tmp/x",
                )
        finally:
            await db.close()

    async def test_rollback_without_engine_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError):
                await h.rollback_plan(
                    user_id=uuid.uuid4(), decision_id=uuid.uuid4()
                )
        finally:
            await db.close()

    async def test_tautology_without_engine_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError):
                await h.test_check_tautology(
                    user_id=uuid.uuid4(),
                    project_id="p1",
                    repo_path=str(tmp_path),
                )
        finally:
            await db.close()


class TestInferenceEdgeCases:
    async def test_confirm_inferred_unknown_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Not found"):
                await h.decision_confirm_inferred(
                    user_id=uuid.uuid4(),
                    inferred_decision_id=uuid.uuid4(),
                )
        finally:
            await db.close()

    async def test_reject_inferred_unknown_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError, match="Not found"):
                await h.decision_reject_inferred(
                    user_id=uuid.uuid4(),
                    inferred_decision_id=uuid.uuid4(),
                    reason="spurious",
                )
        finally:
            await db.close()

    async def test_list_pending_inferred_empty(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            result = await h.decision_list_pending_inferred(
                user_id=uuid.uuid4()
            )
            assert result == []
        finally:
            await db.close()


class TestKnowledgeHandlerGating:
    async def test_knowledge_export_without_mgr_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError):
                await h.knowledge_export(
                    user_id=uuid.uuid4(),
                    project_id="p1",
                    decision_ids=[uuid.uuid4()],
                    pack_name="test",
                )
        finally:
            await db.close()

    async def test_knowledge_list_packs_without_mgr_returns_empty(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            result = await h.knowledge_list_packs(user_id=uuid.uuid4())
            assert result == {"packs": [], "project_id": "default"}
        finally:
            await db.close()


class TestAgentProfilerGating:
    async def test_agent_profile_without_profiler_raises(
        self, tmp_path: Path
    ) -> None:
        h, db = await _mk_handlers(tmp_path)
        try:
            with pytest.raises(HandlerError):
                await h.agent_profile(
                    user_id=uuid.uuid4(), agent_name="claude"
                )
        finally:
            await db.close()
