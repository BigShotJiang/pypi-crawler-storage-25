"""Tests for SOURCE_CONFIDENCE_MULTIPLIERS (GR-2 mitigation, v11).

The multiplier scales evidence weight *before* the single-signal cap
fires, so agent_reported events (0.5x) cannot inflate candidate
confidence through volume. This test file covers only the scoring
math — the full inference pipeline is already covered in
``test_decision_inferrer`` and ``test_inference_guard_rails``.
"""

from __future__ import annotations

from backend.intelligence.decision_inferrer import (
    MAX_CONFIDENCE,
    MAX_SINGLE_SIGNAL_CONFIDENCE,
    DecisionInferrer,
    EvidenceItem,
    InferenceCandidate,
)
from backend.intelligence.inference_evidence import (
    EVIDENCE_WEIGHTS,
    SOURCE_CONFIDENCE_MULTIPLIERS,
)


def _candidate(evidence: list[EvidenceItem]) -> InferenceCandidate:
    return InferenceCandidate(
        title="test",
        description="test",
        evidence=evidence,
        tags=[],
        files_affected=[],
    )


class TestMultipliersConfig:
    def test_agent_reported_is_half(self) -> None:
        assert SOURCE_CONFIDENCE_MULTIPLIERS["agent_reported"] == 0.5

    def test_git_and_file_snapshot_are_one(self) -> None:
        assert SOURCE_CONFIDENCE_MULTIPLIERS["git_commit"] == 1.0
        assert SOURCE_CONFIDENCE_MULTIPLIERS["file_snapshot"] == 1.0


class TestScoringMath:
    """The scorer applies the multiplier *before* the single-signal cap."""

    def _scorer(self) -> DecisionInferrer:
        # The scoring helper is a pure method on the instance; we can
        # construct the inferrer without any collaborators.
        return DecisionInferrer(db=None)  # type: ignore[arg-type]

    def test_single_human_signal_uses_full_weight(self) -> None:
        """A single git-sourced new_class_inherits (weight 0.45) stays 0.45."""
        ev = EvidenceItem(
            evidence_type="new_class_inherits",
            description="",
            source_id="x",
            source_type="ast_change",
            file_path="x.py",
            change_event_source="git_commit",
        )
        candidate = self._scorer()._score_candidate(_candidate([ev]))
        assert candidate.confidence == 0.45

    def test_single_agent_signal_halved(self) -> None:
        """An agent-sourced new_class_inherits (0.45 * 0.5) = 0.23."""
        ev = EvidenceItem(
            evidence_type="new_class_inherits",
            description="",
            source_id="x",
            source_type="ast_change",
            file_path="x.py",
            change_event_source="agent_reported",
        )
        candidate = self._scorer()._score_candidate(_candidate([ev]))
        # 0.45 * 0.5 = 0.225 → rounded to 0.23 (below 0.65 cap).
        assert candidate.confidence == 0.23

    def test_high_weight_human_evidence_hits_single_signal_cap(self) -> None:
        """A 0.65-weight human signal stays at the cap."""
        ev = EvidenceItem(
            evidence_type="dependency_added",  # weight 0.65
            description="",
            source_id="x",
            source_type="ast_change",
            file_path="pyproject.toml",
            change_event_source="git_commit",
        )
        candidate = self._scorer()._score_candidate(_candidate([ev]))
        assert candidate.confidence == MAX_SINGLE_SIGNAL_CONFIDENCE  # 0.65

    def test_high_weight_agent_evidence_cannot_reach_cap(self) -> None:
        """Agent signal of 0.65 weight scales to 0.325 — far below 0.65."""
        ev = EvidenceItem(
            evidence_type="dependency_added",
            description="",
            source_id="x",
            source_type="ast_change",
            file_path="pyproject.toml",
            change_event_source="agent_reported",
        )
        candidate = self._scorer()._score_candidate(_candidate([ev]))
        assert candidate.confidence < MAX_SINGLE_SIGNAL_CONFIDENCE
        assert candidate.confidence == round(
            EVIDENCE_WEIGHTS["dependency_added"].weight * 0.5, 2
        )

    def test_mixed_evidence_scores_per_source_weight(self) -> None:
        """Human + agent evidence mix scales each term independently."""
        human = EvidenceItem(
            evidence_type="new_function",  # 0.20
            description="",
            source_id="a",
            source_type="ast_change",
            file_path="a.py",
            change_event_source="git_commit",
        )
        agent = EvidenceItem(
            evidence_type="new_function",  # 0.20 * 0.5 = 0.10
            description="",
            source_id="b",
            source_type="ast_change",
            file_path="b.py",
            change_event_source="agent_reported",
        )
        candidate = self._scorer()._score_candidate(_candidate([human, agent]))
        # score = 0.20 + 0.10 * 0.3 = 0.23
        assert candidate.confidence == 0.23
        assert candidate.confidence < MAX_CONFIDENCE

    def test_agent_only_multi_signal_stays_small(self) -> None:
        """Two 0.45-weight agent signals: 0.225 + 0.225 * 0.3 = 0.2925 → 0.29."""
        a = EvidenceItem(
            evidence_type="new_class_inherits",
            description="",
            source_id="1",
            source_type="ast_change",
            file_path="a.py",
            change_event_source="agent_reported",
        )
        b = EvidenceItem(
            evidence_type="new_class_inherits",
            description="",
            source_id="2",
            source_type="ast_change",
            file_path="b.py",
            change_event_source="agent_reported",
        )
        candidate = self._scorer()._score_candidate(_candidate([a, b]))
        assert candidate.confidence == 0.29
