"""Tests for the three detection-related MCP handler methods.

Covers ``detection.report_agent_edit``, ``detection.source_status``,
and ``detection.switch_source`` through :class:`ToolHandlers`. The
registry is wired with live detectors and a live SQLite backend so the
full path — handler → registry → DB / queue — is exercised.

The handlers do NOT enforce a write-permission tier; this is the
documented policy. A test case asserts that an otherwise-valid
``switch_source`` call succeeds without any additional authorization
ceremony.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.detection.agent_reported import AgentReportedDetector
from backend.detection.events import ChangeEvent
from backend.detection.file_snapshot import FileSnapshotDetector
from backend.detection.git_commit import GitCommitDetector
from backend.detection.registry import DetectorRegistry
from backend.mcp.tool_handlers import HandlerError, ToolHandlers

if TYPE_CHECKING:
    from pathlib import Path


pytestmark = pytest.mark.asyncio


@pytest.fixture
async def handlers(tmp_path: Path) -> ToolHandlers:
    db = SQLiteBackend(tmp_path / "h.db")
    await db.connect()
    await apply_migrations(db)

    q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
    detectors = {
        "git_commit": GitCommitDetector(q),
        "file_snapshot": FileSnapshotDetector(q),
        "agent_reported": AgentReportedDetector(q),
    }
    for d in detectors.values():
        await d.start()
    registry = DetectorRegistry(db, q, detectors)

    h = ToolHandlers(db=db, detector_registry=registry)
    yield h
    await db.close()


def _uid() -> uuid.UUID:
    return uuid.uuid4()


# ---------------------------------------------------------------------------
# report_agent_edit
# ---------------------------------------------------------------------------


class TestReportAgentEdit:
    async def test_happy_path(self, handlers: ToolHandlers) -> None:
        result = await handlers.detection_report_agent_edit(
            user_id=_uid(),
            agent_id="claude-sess-1",
            files=["backend/foo.py", "backend/bar.py"],
            session_id="sess-xyz",
            project_id="proj",
        )
        assert result == {
            "reported": True,
            "files_count": 2,
            "session_id": "sess-xyz",
        }

    async def test_pushes_event_with_correct_fields(
        self, handlers: ToolHandlers
    ) -> None:
        await handlers.detection_report_agent_edit(
            user_id=_uid(),
            agent_id="claude-sess-1",
            files=["x.py"],
            session_id="sess-1",
            project_id="proj",
            change_summary="adding a function",
        )
        registry = handlers.detector_registry
        assert registry is not None
        queue = registry._queue
        assert queue.qsize() == 1
        ev = await queue.get()
        assert ev.change_event_source == "agent_reported"
        assert ev.actor_type == "agent"
        assert ev.actor_id == "claude-sess-1"
        assert ev.payload["session_id"] == "sess-1"
        assert ev.payload["files"] == ["x.py"]

    async def test_empty_agent_id_rejected(self, handlers: ToolHandlers) -> None:
        with pytest.raises(HandlerError, match="agent_id"):
            await handlers.detection_report_agent_edit(
                user_id=_uid(),
                agent_id="",
                files=["x.py"],
                session_id="s",
            )

    async def test_empty_files_rejected(self, handlers: ToolHandlers) -> None:
        with pytest.raises(HandlerError, match="files"):
            await handlers.detection_report_agent_edit(
                user_id=_uid(),
                agent_id="a",
                files=[],
                session_id="s",
            )

    async def test_files_must_be_strings(
        self, handlers: ToolHandlers
    ) -> None:
        with pytest.raises(HandlerError, match="files\\[0\\]"):
            await handlers.detection_report_agent_edit(
                user_id=_uid(),
                agent_id="a",
                files=[""],
                session_id="s",
            )

    async def test_missing_registry_surfaces_error(
        self, tmp_path: Path
    ) -> None:
        db = SQLiteBackend(tmp_path / "no_reg.db")
        await db.connect()
        await apply_migrations(db)
        try:
            h = ToolHandlers(db=db)  # no detector_registry
            with pytest.raises(HandlerError, match="not enabled"):
                await h.detection_report_agent_edit(
                    user_id=_uid(),
                    agent_id="a",
                    files=["x.py"],
                    session_id="s",
                )
        finally:
            await db.close()


# ---------------------------------------------------------------------------
# source_status
# ---------------------------------------------------------------------------


class TestSourceStatus:
    async def test_returns_shape(self, handlers: ToolHandlers) -> None:
        status = await handlers.detection_source_status(
            user_id=_uid(), project_id="proj"
        )
        assert set(status) == {
            "project_id",
            "current_source",
            "actor_config",
            "detector_health",
            "queue_depth",
        }
        assert status["project_id"] == "proj"
        assert status["current_source"] == "git_commit"


# ---------------------------------------------------------------------------
# switch_source
# ---------------------------------------------------------------------------


class TestSwitchSource:
    async def test_any_authenticated_user_can_switch(
        self, handlers: ToolHandlers
    ) -> None:
        """No write-permission tier — documented handler policy."""
        result = await handlers.detection_switch_source(
            user_id=_uid(),
            new_source="file_snapshot",
            project_id="proj",
        )
        assert result["success"]
        assert result["previous_source"] == "git_commit"
        assert result["new_source"] == "file_snapshot"

    async def test_rejects_invalid_source(
        self, handlers: ToolHandlers
    ) -> None:
        result = await handlers.detection_switch_source(
            user_id=_uid(),
            new_source="svn",
            project_id="proj",
        )
        assert not result["success"]
        assert result["reason"] == "invalid_source"

    async def test_empty_new_source_rejected_at_handler(
        self, handlers: ToolHandlers
    ) -> None:
        with pytest.raises(HandlerError, match="new_source"):
            await handlers.detection_switch_source(
                user_id=_uid(),
                new_source="",
                project_id="proj",
            )
