"""Tests for backend.detection.webhook — the GitHub webhook receiver.

**Replay semantics:** this module does not dedup on GitHub's
``X-GitHub-Delivery`` header. Duplicate deliveries (retries, manual
re-sends) will produce duplicate events. Downstream dedup is out of
scope for v11 and is explicitly documented here.
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
from typing import TYPE_CHECKING

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.detection.agent_reported import AgentReportedDetector
from backend.detection.events import ChangeEvent
from backend.detection.file_snapshot import FileSnapshotDetector
from backend.detection.git_commit import GitCommitDetector
from backend.detection.registry import DetectorRegistry
from backend.detection.webhook import (
    _classify_actor,
    _verify_signature,
    build_github_webhook_router,
)

if TYPE_CHECKING:
    from pathlib import Path


pytestmark = pytest.mark.asyncio


# ---------------------------------------------------------------------------
# Fakes + fixtures
# ---------------------------------------------------------------------------


class _FakeCreds:
    """Minimal credential manager stub keyed on (provider, key)."""

    def __init__(self) -> None:
        self.values: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.values.get((provider, key))


@pytest.fixture
async def backend(tmp_path: Path) -> SQLiteBackend:
    db = SQLiteBackend(tmp_path / "wh.db")
    await db.connect()
    await apply_migrations(db)
    yield db
    await db.close()


async def _make_registry(
    backend: SQLiteBackend,
) -> tuple[DetectorRegistry, asyncio.Queue[ChangeEvent]]:
    q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
    detectors = {
        "git_commit": GitCommitDetector(q),
        "file_snapshot": FileSnapshotDetector(q),
        "agent_reported": AgentReportedDetector(q),
    }
    for d in detectors.values():
        await d.start()
    return DetectorRegistry(backend, q, detectors), q


def _sign(secret: str, body: bytes) -> str:
    return "sha256=" + hmac.new(
        secret.encode("utf-8"), body, hashlib.sha256
    ).hexdigest()


def _app_with_router(
    creds: _FakeCreds, registry: DetectorRegistry
) -> FastAPI:
    app = FastAPI()
    app.include_router(build_github_webhook_router(creds, registry))  # type: ignore[arg-type]
    return app


# ---------------------------------------------------------------------------
# Signature verification
# ---------------------------------------------------------------------------


class TestSignatureHelper:
    """``_verify_signature`` is the core security primitive."""

    async def test_valid_signature_accepts(self) -> None:
        body = b'{"foo": 1}'
        sig = _sign("secret", body)
        assert _verify_signature("secret", body, sig) is True

    async def test_wrong_secret_rejects(self) -> None:
        body = b'{"foo": 1}'
        sig = _sign("secret", body)
        assert _verify_signature("other", body, sig) is False

    async def test_mutated_body_rejects(self) -> None:
        body = b'{"foo": 1}'
        sig = _sign("secret", body)
        assert _verify_signature("secret", body + b"x", sig) is False

    async def test_missing_prefix_rejects(self) -> None:
        body = b"{}"
        assert _verify_signature("secret", body, "badhex") is False


# ---------------------------------------------------------------------------
# Actor classification
# ---------------------------------------------------------------------------


class TestActorClassification:
    """_classify_actor reports webhook_bot for any of the bot signals."""

    async def test_sender_type_bot(self) -> None:
        actor_type, actor_id = _classify_actor(
            {"login": "weird", "type": "Bot"}
        )
        assert actor_type == "webhook_bot"
        assert actor_id == "weird"

    async def test_bot_suffix_login(self) -> None:
        actor_type, actor_id = _classify_actor(
            {"login": "fancy-thing[bot]", "type": "User"}
        )
        assert actor_type == "webhook_bot"
        assert actor_id == "fancy-thing[bot]"

    async def test_known_bot_login(self) -> None:
        actor_type, actor_id = _classify_actor(
            {"login": "dependabot[bot]", "type": "User"}
        )
        assert actor_type == "webhook_bot"

    async def test_human_with_email(self) -> None:
        actor_type, actor_id = _classify_actor(
            {"login": "alice", "type": "User", "email": "alice@example.com"}
        )
        assert actor_type == "human"
        assert actor_id == "alice@example.com"

    async def test_human_without_email(self) -> None:
        actor_type, actor_id = _classify_actor(
            {"login": "bob", "type": "User"}
        )
        assert actor_type == "human"
        assert actor_id == "bob"

    async def test_empty_sender_falls_back(self) -> None:
        actor_type, actor_id = _classify_actor({})
        assert actor_type == "human"
        assert actor_id == "unknown_human"


# ---------------------------------------------------------------------------
# End-to-end routing
# ---------------------------------------------------------------------------


class TestWebhookSignature:
    """Route-level behavior: signatures, 401 emptiness, event emission.

    Replay behavior: duplicate deliveries are NOT deduplicated. This is
    intentional for v11 and documented in the module docstring.
    """

    async def test_valid_signature_accepted_and_event_emitted(
        self, backend: SQLiteBackend
    ) -> None:
        registry, queue = await _make_registry(backend)
        creds = _FakeCreds()
        creds.values[("webhook_github", "proj-1")] = "top_secret"
        app = _app_with_router(creds, registry)

        body_obj = {
            "sender": {
                "login": "alice",
                "type": "User",
                "email": "alice@example.com",
            }
        }
        body = json.dumps(body_obj).encode("utf-8")
        sig = _sign("top_secret", body)

        with TestClient(app) as client:
            resp = client.post(
                "/webhooks/github/proj-1",
                content=body,
                headers={
                    "X-Hub-Signature-256": sig,
                    "X-GitHub-Event": "push",
                    "X-GitHub-Delivery": "abc-123",
                },
            )
        assert resp.status_code == 200
        assert resp.content == b"OK"
        assert queue.qsize() == 1
        event = await queue.get()
        assert event.change_event_source == "git_commit"
        assert event.actor_type == "human"
        assert event.actor_id == "alice@example.com"
        assert event.project_id == "proj-1"

    async def test_invalid_signature_returns_401_empty_body(
        self, backend: SQLiteBackend
    ) -> None:
        registry, queue = await _make_registry(backend)
        creds = _FakeCreds()
        creds.values[("webhook_github", "proj-1")] = "top_secret"
        app = _app_with_router(creds, registry)

        body = b'{"sender": {"login": "alice", "type": "User"}}'
        with TestClient(app) as client:
            resp = client.post(
                "/webhooks/github/proj-1",
                content=body,
                headers={"X-Hub-Signature-256": "sha256=deadbeef"},
            )
        assert resp.status_code == 401
        assert resp.content == b""
        assert queue.qsize() == 0

    async def test_missing_signature_returns_401(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        creds = _FakeCreds()
        creds.values[("webhook_github", "proj-1")] = "top_secret"
        app = _app_with_router(creds, registry)

        with TestClient(app) as client:
            resp = client.post("/webhooks/github/proj-1", content=b"{}")
        assert resp.status_code == 401
        assert resp.content == b""

    async def test_missing_project_secret_returns_401(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        creds = _FakeCreds()
        # Deliberately don't populate creds for proj-2.
        app = _app_with_router(creds, registry)

        body = b"{}"
        sig = _sign("whatever", body)
        with TestClient(app) as client:
            resp = client.post(
                "/webhooks/github/proj-2",
                content=body,
                headers={"X-Hub-Signature-256": sig},
            )
        assert resp.status_code == 401
        assert resp.content == b""

    async def test_malformed_json_returns_400(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        creds = _FakeCreds()
        creds.values[("webhook_github", "proj-1")] = "top_secret"
        app = _app_with_router(creds, registry)

        body = b"{not valid json"
        sig = _sign("top_secret", body)
        with TestClient(app) as client:
            resp = client.post(
                "/webhooks/github/proj-1",
                content=body,
                headers={"X-Hub-Signature-256": sig},
            )
        assert resp.status_code == 400
        assert resp.content == b"Bad Request"

    async def test_non_dict_payload_returns_400(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        creds = _FakeCreds()
        creds.values[("webhook_github", "proj-1")] = "top_secret"
        app = _app_with_router(creds, registry)

        body = b'"just a string"'
        sig = _sign("top_secret", body)
        with TestClient(app) as client:
            resp = client.post(
                "/webhooks/github/proj-1",
                content=body,
                headers={"X-Hub-Signature-256": sig},
            )
        assert resp.status_code == 400

    async def test_payload_missing_sender_returns_400(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        creds = _FakeCreds()
        creds.values[("webhook_github", "proj-1")] = "top_secret"
        app = _app_with_router(creds, registry)

        body = b'{"not_sender": true}'
        sig = _sign("top_secret", body)
        with TestClient(app) as client:
            resp = client.post(
                "/webhooks/github/proj-1",
                content=body,
                headers={"X-Hub-Signature-256": sig},
            )
        assert resp.status_code == 400

    async def test_bot_sender_tagged_as_webhook_bot(
        self, backend: SQLiteBackend
    ) -> None:
        registry, queue = await _make_registry(backend)
        creds = _FakeCreds()
        creds.values[("webhook_github", "proj-1")] = "top_secret"
        app = _app_with_router(creds, registry)

        body = json.dumps(
            {"sender": {"login": "dependabot[bot]", "type": "User"}}
        ).encode("utf-8")
        sig = _sign("top_secret", body)
        with TestClient(app) as client:
            resp = client.post(
                "/webhooks/github/proj-1",
                content=body,
                headers={"X-Hub-Signature-256": sig},
            )
        assert resp.status_code == 200
        assert queue.qsize() == 1
        ev = await queue.get()
        assert ev.actor_type == "webhook_bot"
        assert ev.actor_id == "dependabot[bot]"

    async def test_per_project_secret_isolation(
        self, backend: SQLiteBackend
    ) -> None:
        """Signature for proj-1's secret must not authenticate proj-2's route."""
        registry, _ = await _make_registry(backend)
        creds = _FakeCreds()
        creds.values[("webhook_github", "proj-1")] = "proj1_secret"
        creds.values[("webhook_github", "proj-2")] = "proj2_secret"
        app = _app_with_router(creds, registry)

        body = json.dumps(
            {"sender": {"login": "alice", "type": "User"}}
        ).encode("utf-8")
        sig_for_proj1 = _sign("proj1_secret", body)

        with TestClient(app) as client:
            resp = client.post(
                "/webhooks/github/proj-2",
                content=body,
                headers={"X-Hub-Signature-256": sig_for_proj1},
            )
        assert resp.status_code == 401
        assert resp.content == b""
