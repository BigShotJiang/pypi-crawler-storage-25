"""Tests for backend.advanced.knowledge_packs."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from backend.advanced.knowledge_packs import (
    KnowledgePackError,
    KnowledgePackManager,
)
from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.models import Decision

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
async def db(tmp_path: Path) -> SQLiteBackend:
    backend = SQLiteBackend(tmp_path / "pack.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def manager(db: SQLiteBackend) -> KnowledgePackManager:
    return KnowledgePackManager(db=db)


async def _seed_decision(db: SQLiteBackend, *, status: str = "passed") -> str:
    d = Decision(
        title="Cache-first retrieval",
        description="Decisions about the cache path",
        tags=["perf", "cache"],
        status=status,
    )
    await db.insert("decisions", d.to_dict())
    return str(d.id)


class TestExport:
    async def test_export_verified_decision(
        self, db: SQLiteBackend, manager: KnowledgePackManager
    ) -> None:
        did = await _seed_decision(db, status="passed")
        pack = await manager.export_pack(
            project_id="p1", decision_ids=[did], pack_name="pack-one"
        )
        assert pack.pack_name == "pack-one"
        assert len(pack.decisions) == 1
        assert pack.decisions[0]["id"] == did
        assert pack.decisions[0]["status"] == "passed"
        # Sanitisation — no project identifiers.
        assert "recorded_by_user_id" not in pack.decisions[0]
        assert "recorded_in_session_id" not in pack.decisions[0]

    async def test_export_unverified_rejected(
        self, db: SQLiteBackend, manager: KnowledgePackManager
    ) -> None:
        did = await _seed_decision(db, status="unverified")
        with pytest.raises(KnowledgePackError):
            await manager.export_pack("p1", [did], "pack-x")

    async def test_export_failed_rejected(
        self, db: SQLiteBackend, manager: KnowledgePackManager
    ) -> None:
        did = await _seed_decision(db, status="failed")
        with pytest.raises(KnowledgePackError):
            await manager.export_pack("p1", [did], "pack-x")

    async def test_export_empty_rejected(
        self, manager: KnowledgePackManager
    ) -> None:
        with pytest.raises(KnowledgePackError):
            await manager.export_pack("p1", [], "pack-x")

    async def test_list_exportable_only_passed(
        self, db: SQLiteBackend, manager: KnowledgePackManager
    ) -> None:
        await _seed_decision(db, status="passed")
        await _seed_decision(db, status="unverified")
        exportable = await manager.list_exportable("p1")
        assert len(exportable) == 1
        assert exportable[0]["status"] == "passed"


class TestImport:
    async def test_import_creates_imported_decisions(
        self, db: SQLiteBackend, manager: KnowledgePackManager
    ) -> None:
        did = await _seed_decision(db, status="passed")
        pack = await manager.export_pack("p1", [did], "p-1")
        # Import into another project (same DB for simplicity).
        result = await manager.import_pack("p2", pack)
        assert result["imported_decision_count"] == 1
        new_ids = result["imported_decision_ids"]
        row = await db.get_by_id("decisions", new_ids[0])
        assert row is not None
        assert "imported" in row["tags"]


class TestSerialization:
    async def test_round_trip(
        self, db: SQLiteBackend, manager: KnowledgePackManager
    ) -> None:
        did = await _seed_decision(db, status="passed")
        pack = await manager.export_pack("p1", [did], "p-2")
        blob = manager.serialize_pack(pack)
        assert isinstance(blob, bytes)
        restored = manager.deserialize_pack(blob)
        assert restored.pack_name == pack.pack_name
        assert len(restored.decisions) == len(pack.decisions)

    async def test_invalid_blob_raises(
        self, manager: KnowledgePackManager
    ) -> None:
        with pytest.raises(KnowledgePackError):
            manager.deserialize_pack(b"not gzip content")
