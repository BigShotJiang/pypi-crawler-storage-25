"""Coverage tests for backend.advanced.knowledge_packs error paths.

Covers empty-input validation, decision-not-found, bad-status rejection,
unsupported-format import, malformed serialized blobs.
"""

from __future__ import annotations

import gzip
import json
from typing import TYPE_CHECKING

import pytest

from backend.advanced.knowledge_packs import (
    KnowledgePack,
    KnowledgePackError,
    KnowledgePackManager,
)
from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.models import Decision

if TYPE_CHECKING:
    from pathlib import Path


async def _mk_manager(tmp_path: Path) -> tuple[KnowledgePackManager, SQLiteBackend]:
    db = SQLiteBackend(tmp_path / "kp.db")
    await db.connect()
    await apply_migrations(db)
    return KnowledgePackManager(db=db), db


class TestExportValidation:
    async def test_empty_pack_name_rejected(self, tmp_path: Path) -> None:
        mgr, db = await _mk_manager(tmp_path)
        try:
            with pytest.raises(KnowledgePackError, match="pack_name"):
                await mgr.export_pack("p1", ["d1"], "")
        finally:
            await db.close()

    async def test_empty_decision_list_rejected(
        self, tmp_path: Path
    ) -> None:
        mgr, db = await _mk_manager(tmp_path)
        try:
            with pytest.raises(KnowledgePackError, match="decision_id"):
                await mgr.export_pack("p1", [], "pack")
        finally:
            await db.close()

    async def test_unknown_decision_rejected(
        self, tmp_path: Path
    ) -> None:
        mgr, db = await _mk_manager(tmp_path)
        try:
            with pytest.raises(KnowledgePackError, match="Decision not found"):
                await mgr.export_pack(
                    "p1", ["00000000-0000-0000-0000-000000000000"], "pack"
                )
        finally:
            await db.close()

    async def test_unverified_decision_cannot_export(
        self, tmp_path: Path
    ) -> None:
        mgr, db = await _mk_manager(tmp_path)
        try:
            d = Decision(title="WIP", description="not yet verified")
            await db.insert("decisions", d.to_dict())
            with pytest.raises(KnowledgePackError, match="only 'passed'"):
                await mgr.export_pack("p1", [str(d.id)], "pack")
        finally:
            await db.close()


class TestImportValidation:
    async def test_wrong_format_version_rejected(
        self, tmp_path: Path
    ) -> None:
        mgr, db = await _mk_manager(tmp_path)
        try:
            pack = KnowledgePack(pack_name="p", format_version=99)
            with pytest.raises(KnowledgePackError, match="Unsupported pack format"):
                await mgr.import_pack("p1", pack)
        finally:
            await db.close()

    async def test_import_marks_decisions_imported(
        self, tmp_path: Path
    ) -> None:
        mgr, db = await _mk_manager(tmp_path)
        try:
            pack = KnowledgePack(pack_name="p")
            pack.decisions = [
                {
                    "id": "src-1",
                    "title": "Pinned",
                    "description": "desc",
                    "tags": ["auth"],
                    "status": "passed",
                }
            ]
            result = await mgr.import_pack("p2", pack)
            assert result["imported_decision_count"] == 1
            rows = await db.query("decisions")
            assert any("imported" in (r.get("tags") or "") for r in rows)
        finally:
            await db.close()


class TestSerialization:
    def test_invalid_gzip_rejected(self, tmp_path: Path) -> None:
        mgr = KnowledgePackManager(db=None)  # type: ignore[arg-type]
        with pytest.raises(KnowledgePackError, match="gzip"):
            mgr.deserialize_pack(b"not-a-gzip-stream")

    def test_invalid_json_inside_gzip_rejected(
        self, tmp_path: Path
    ) -> None:
        mgr = KnowledgePackManager(db=None)  # type: ignore[arg-type]
        blob = gzip.compress(b"{not valid json")
        with pytest.raises(KnowledgePackError, match="JSON"):
            mgr.deserialize_pack(blob)

    def test_bad_embedding_rejected(self, tmp_path: Path) -> None:
        mgr = KnowledgePackManager(db=None)  # type: ignore[arg-type]
        payload = {
            "pack_name": "p",
            "format_version": 1,
            "decisions": [],
            "embeddings": {"dec1": "not-valid-base64!!"},
        }
        blob = gzip.compress(json.dumps(payload).encode("utf-8"))
        with pytest.raises(KnowledgePackError, match="decode embedding"):
            mgr.deserialize_pack(blob)
