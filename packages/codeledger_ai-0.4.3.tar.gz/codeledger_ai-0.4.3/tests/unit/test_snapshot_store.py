"""Tests for backend.utils.snapshot_store — file content snapshotting.

Covers: first-call insertion, dedup on unchanged content, insertion on change,
unified diff correctness, pruning of old snapshots, and missing-file errors.
"""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.utils.snapshot_store import SnapshotStore, SnapshotStoreError

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
async def store(tmp_path: Path) -> SnapshotStore:
    """A SnapshotStore wired to a fresh SQLite database."""
    backend = SQLiteBackend(tmp_path / "snap.db")
    await backend.connect()
    await apply_migrations(backend)
    yield SnapshotStore(backend)
    await backend.close()


def _write(tmp_path: Path, name: str, body: str) -> str:
    """Write ``body`` to ``tmp_path/name`` and return the absolute path."""
    target = tmp_path / name
    target.write_text(body, encoding="utf-8")
    return str(target)


# ---------------------------------------------------------------------------
# take_snapshot
# ---------------------------------------------------------------------------


class TestTakeSnapshot:
    """Insert a new snapshot on first call; dedup on unchanged content."""

    @pytest.mark.asyncio
    async def test_first_call_creates_snapshot(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        path = _write(tmp_path, "a.py", "print('hi')\n")
        snap = await store.take_snapshot(path, "proj")
        assert snap.file_path == path
        assert snap.project_id == "proj"
        assert snap.content == "print('hi')\n"
        assert len(snap.content_hash) == 64  # SHA-256 hex

    @pytest.mark.asyncio
    async def test_same_content_returns_existing(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        path = _write(tmp_path, "a.py", "x = 1\n")
        first = await store.take_snapshot(path, "proj")
        second = await store.take_snapshot(path, "proj")
        assert first.id == second.id

    @pytest.mark.asyncio
    async def test_content_change_inserts_new(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        path = _write(tmp_path, "a.py", "x = 1\n")
        first = await store.take_snapshot(path, "proj")

        _write(tmp_path, "a.py", "x = 2\n")
        second = await store.take_snapshot(path, "proj")
        assert first.id != second.id
        assert first.content_hash != second.content_hash

    @pytest.mark.asyncio
    async def test_session_id_persisted(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        path = _write(tmp_path, "a.py", "ok\n")
        sid = uuid.uuid4()
        snap = await store.take_snapshot(path, "proj", session_id=sid)
        assert snap.session_id == sid

    @pytest.mark.asyncio
    async def test_missing_file_raises(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        with pytest.raises(FileNotFoundError):
            await store.take_snapshot(
                str(tmp_path / "nope.py"), "proj"
            )

    @pytest.mark.asyncio
    async def test_empty_project_id_rejected(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        path = _write(tmp_path, "a.py", "x\n")
        with pytest.raises(SnapshotStoreError):
            await store.take_snapshot(path, "")

    @pytest.mark.asyncio
    async def test_empty_file_path_rejected(
        self, store: SnapshotStore
    ) -> None:
        with pytest.raises(SnapshotStoreError):
            await store.take_snapshot("", "proj")

    @pytest.mark.asyncio
    async def test_project_isolation(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        """Two projects sharing a path each get their own first-snapshot."""
        path = _write(tmp_path, "a.py", "shared\n")
        snap_a = await store.take_snapshot(path, "proj-a")
        snap_b = await store.take_snapshot(path, "proj-b")
        assert snap_a.id != snap_b.id
        assert snap_a.project_id == "proj-a"
        assert snap_b.project_id == "proj-b"


# ---------------------------------------------------------------------------
# get_last_snapshot
# ---------------------------------------------------------------------------


class TestGetLastSnapshot:
    """Return the most recent snapshot or None."""

    @pytest.mark.asyncio
    async def test_returns_none_when_empty(
        self, store: SnapshotStore
    ) -> None:
        result = await store.get_last_snapshot("src/x.py", "proj")
        assert result is None

    @pytest.mark.asyncio
    async def test_returns_most_recent(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        path = _write(tmp_path, "a.py", "v1\n")
        await store.take_snapshot(path, "proj")
        _write(tmp_path, "a.py", "v2\n")
        latest = await store.take_snapshot(path, "proj")

        result = await store.get_last_snapshot(path, "proj")
        assert result is not None
        assert result.id == latest.id
        assert result.content == "v2\n"


# ---------------------------------------------------------------------------
# diff_snapshots
# ---------------------------------------------------------------------------


class TestDiffSnapshots:
    """Unified diff is compatible with ast_tracker.parse_diff."""

    @pytest.mark.asyncio
    async def test_diff_between_changes(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        path = _write(tmp_path, "a.py", "def foo():\n    return 1\n")
        before = await store.take_snapshot(path, "proj")

        _write(tmp_path, "a.py", "def foo():\n    return 2\n")
        after = await store.take_snapshot(path, "proj")

        diff = await store.diff_snapshots(str(before.id), str(after.id))
        assert diff  # non-empty
        assert "-    return 1" in diff
        assert "+    return 2" in diff

    @pytest.mark.asyncio
    async def test_identical_content_empty_string(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        """Two snapshots with the same content produce no diff."""
        path_a = _write(tmp_path, "a.py", "same\n")
        path_b = _write(tmp_path, "b.py", "same\n")  # different path, same content
        snap_a = await store.take_snapshot(path_a, "proj")
        snap_b = await store.take_snapshot(path_b, "proj")

        diff = await store.diff_snapshots(str(snap_a.id), str(snap_b.id))
        assert diff == ""

    @pytest.mark.asyncio
    async def test_missing_snapshot_raises(
        self, store: SnapshotStore
    ) -> None:
        with pytest.raises(SnapshotStoreError):
            await store.diff_snapshots(str(uuid.uuid4()), str(uuid.uuid4()))

    @pytest.mark.asyncio
    async def test_empty_id_rejected(self, store: SnapshotStore) -> None:
        with pytest.raises(SnapshotStoreError):
            await store.diff_snapshots("", "")


# ---------------------------------------------------------------------------
# delete_old_snapshots
# ---------------------------------------------------------------------------


class TestDeleteOldSnapshots:
    """Keep only the requested count; drop everything older."""

    @pytest.mark.asyncio
    async def test_keeps_last_n(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        path = tmp_path / "a.py"
        ids: list[str] = []
        for i in range(5):
            path.write_text(f"v{i}\n", encoding="utf-8")
            snap = await store.take_snapshot(str(path), "proj")
            ids.append(str(snap.id))

        deleted = await store.delete_old_snapshots(
            str(path), "proj", keep_last_n=2
        )
        assert deleted == 3

        latest = await store.get_last_snapshot(str(path), "proj")
        assert latest is not None
        assert str(latest.id) == ids[-1]

    @pytest.mark.asyncio
    async def test_keep_more_than_exists_noop(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        path = tmp_path / "a.py"
        path.write_text("only\n", encoding="utf-8")
        await store.take_snapshot(str(path), "proj")
        deleted = await store.delete_old_snapshots(
            str(path), "proj", keep_last_n=10
        )
        assert deleted == 0

    @pytest.mark.asyncio
    async def test_negative_keep_rejected(
        self, store: SnapshotStore, tmp_path: Path
    ) -> None:
        with pytest.raises(SnapshotStoreError):
            await store.delete_old_snapshots(
                "src/x.py", "proj", keep_last_n=-1
            )
