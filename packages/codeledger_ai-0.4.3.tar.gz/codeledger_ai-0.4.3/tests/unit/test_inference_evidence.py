"""Tests for backend.intelligence.inference_evidence.

Covers the noise filter and import classifier used by guard rails GR-10
(noise filtering) and GR-2 (evidence-weight calibration).
"""

from __future__ import annotations

import typing

import pytest

from backend.intelligence.inference_evidence import (
    EVIDENCE_WEIGHTS,
    EvidenceType,
    classify_import,
    is_noise_import,
    is_stdlib_module,
)

# ---------------------------------------------------------------------------
# GR-10 — stdlib imports are noise
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "module",
    [
        "os",
        "sys",
        "json",
        "re",
        "math",
        "datetime",
        "pathlib",
        "typing",
        "collections",
        "asyncio",
        "threading",
        "hashlib",
        "logging",
        "os.path",
        "urllib.request",
        "collections.abc",
    ],
)
def test_GR10_stdlib_imports_are_noise(module: str) -> None:
    assert is_stdlib_module(module)
    assert is_noise_import(module)


@pytest.mark.parametrize(
    "module",
    [
        "typing_extensions",
        "six",
        "attrs",
        "pkg_resources",
        "setuptools",
        "wheel",
        "importlib_metadata",
    ],
)
def test_GR10_packaging_noise_is_filtered(module: str) -> None:
    assert not is_stdlib_module(module)
    assert is_noise_import(module)


@pytest.mark.parametrize(
    "module",
    [
        "argon2",
        "fastapi",
        "sqlalchemy",
        "httpx",
        "pydantic",
        "numpy",
        "pandas",
        "redis",
    ],
)
def test_GR10_third_party_packages_pass(module: str) -> None:
    assert not is_noise_import(module)
    assert classify_import(module) == "new_import_third_party"


def test_GR10_empty_module_name_treated_as_noise() -> None:
    assert is_noise_import("")
    assert is_noise_import("   ")
    assert classify_import("") is None


# ---------------------------------------------------------------------------
# classify_import — project-local top-levels promoted to new_import_internal
# ---------------------------------------------------------------------------


def test_classify_import_respects_project_top_levels() -> None:
    top = frozenset({"backend", "frontend"})
    assert (
        classify_import("backend.auth", project_top_levels=top)
        == "new_import_internal"
    )
    assert (
        classify_import("frontend.cli", project_top_levels=top)
        == "new_import_internal"
    )
    assert (
        classify_import("argon2", project_top_levels=top)
        == "new_import_third_party"
    )
    assert (
        classify_import("os", project_top_levels=top) == "new_import_stdlib"
    )


# ---------------------------------------------------------------------------
# GR-2 — weights stay within the documented band
# ---------------------------------------------------------------------------


def test_GR2_no_weight_exceeds_single_signal_cap() -> None:
    """Weights respect the 0.65 single-signal cap even before aggregation.

    The engine clamps at ``MAX_SINGLE_SIGNAL_CONFIDENCE`` anyway, but
    the table itself should respect the cap so reviewers scanning the
    taxonomy never see a value that would over-promote a bare,
    single-signal inference.
    """
    for etype, meta in EVIDENCE_WEIGHTS.items():
        assert 0.0 < meta.weight <= 0.65, (
            f"{etype} weight {meta.weight} violates the "
            "single-signal cap of 0.65"
        )


def test_GR2_every_evidence_type_has_a_weight() -> None:
    """Every EvidenceType value must appear in EVIDENCE_WEIGHTS."""
    literals = typing.get_args(EvidenceType)
    for value in literals:
        assert value in EVIDENCE_WEIGHTS, (
            f"EvidenceType literal {value!r} has no entry in "
            "EVIDENCE_WEIGHTS"
        )
