"""Tests for backend.verification.provenance — forward/reverse graph walks.

Covers: forward trace for git_commit, forward trace for file_snapshot,
reverse trace for both event types, dependency graph, impact graph,
empty trace, unknown decision.
"""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.ast_tracker import ASTTracker
from backend.models import Decision
from backend.verification.provenance import ProvenanceEngine, ProvenanceError

if TYPE_CHECKING:
    from pathlib import Path


_DIFF_ADD_FN = (
    "diff --git a/p.py b/p.py\n"
    "--- a/p.py\n"
    "+++ b/p.py\n"
    "@@ -0,0 +1,2 @@\n"
    "+def provenance_fn(x):\n"
    "+    return x\n"
)


@pytest.fixture
async def db(tmp_path: Path) -> SQLiteBackend:
    backend = SQLiteBackend(tmp_path / "prov.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def engine(db: SQLiteBackend) -> ProvenanceEngine:
    return ProvenanceEngine(db)


@pytest.fixture
def tracker(db: SQLiteBackend) -> ASTTracker:
    return ASTTracker(db=db)


async def _seed_decision_with_event(
    db: SQLiteBackend,
    tracker: ASTTracker,
    *,
    change_event_id: str,
    change_event_source: str,
    title: str = "Provenance touch p.py",
) -> uuid.UUID:
    decision = Decision(title=title, description="Adds provenance_fn in p.py")
    await db.insert("decisions", decision.to_dict())
    await tracker.process_change_event(
        change_event_id=change_event_id,
        change_event_source=change_event_source,
        diff_text=_DIFF_ADD_FN,
        project_id="proj-1",
    )
    return decision.id


class TestForwardTrace:
    async def test_forward_trace_for_git_commit(
        self,
        db: SQLiteBackend,
        engine: ProvenanceEngine,
        tracker: ASTTracker,
    ) -> None:
        decision_id = await _seed_decision_with_event(
            db, tracker, change_event_id="cmt-1", change_event_source="git_commit"
        )
        tree = await engine.forward_trace(decision_id)
        assert tree.decision["id"] == str(decision_id)
        assert len(tree.change_events) == 1
        event = tree.change_events[0]
        assert event.change_event_source == "git_commit"
        assert event.change_event_id == "cmt-1"
        assert event.label == "commit cmt-1"
        assert len(event.ast_changes) >= 1

    async def test_forward_trace_for_file_snapshot(
        self,
        db: SQLiteBackend,
        engine: ProvenanceEngine,
        tracker: ASTTracker,
    ) -> None:
        decision_id = await _seed_decision_with_event(
            db,
            tracker,
            change_event_id="snap-1",
            change_event_source="file_snapshot",
        )
        tree = await engine.forward_trace(decision_id)
        assert len(tree.change_events) == 1
        event = tree.change_events[0]
        assert event.change_event_source == "file_snapshot"
        assert event.change_event_id == "snap-1"
        assert event.label.startswith("Snapshot ")
        assert "p.py" in event.label

    async def test_forward_trace_unknown_raises(
        self, engine: ProvenanceEngine
    ) -> None:
        with pytest.raises(ProvenanceError):
            await engine.forward_trace(uuid.uuid4())

    async def test_forward_trace_empty_for_decision_without_edges(
        self, db: SQLiteBackend, engine: ProvenanceEngine
    ) -> None:
        d = Decision(title="Orphan")
        await db.insert("decisions", d.to_dict())
        tree = await engine.forward_trace(d.id)
        assert tree.change_events == []


class TestReverseTrace:
    async def test_reverse_trace_returns_decision_for_git_commit(
        self,
        db: SQLiteBackend,
        engine: ProvenanceEngine,
        tracker: ASTTracker,
    ) -> None:
        decision_id = await _seed_decision_with_event(
            db, tracker, change_event_id="cmt-2", change_event_source="git_commit"
        )
        results = await engine.reverse_trace(
            file_path="p.py", entity_name="provenance_fn", project_id="proj-1"
        )
        assert len(results) >= 1
        assert any(r.decision["id"] == str(decision_id) for r in results)
        assert all(r.change_event_source == "git_commit" for r in results)

    async def test_reverse_trace_handles_file_snapshot(
        self,
        db: SQLiteBackend,
        engine: ProvenanceEngine,
        tracker: ASTTracker,
    ) -> None:
        await _seed_decision_with_event(
            db,
            tracker,
            change_event_id="snap-2",
            change_event_source="file_snapshot",
        )
        results = await engine.reverse_trace(
            file_path="p.py", entity_name="provenance_fn", project_id="proj-1"
        )
        assert all(r.change_event_source == "file_snapshot" for r in results)
        assert all(r.change_event_label.startswith("Snapshot ") for r in results)

    async def test_reverse_trace_unknown_entity_is_empty(
        self, engine: ProvenanceEngine
    ) -> None:
        results = await engine.reverse_trace(
            file_path="nope.py", entity_name="ghost", project_id="proj-1"
        )
        assert results == []

    async def test_reverse_trace_rejects_empty_inputs(
        self, engine: ProvenanceEngine
    ) -> None:
        with pytest.raises(ProvenanceError):
            await engine.reverse_trace("", "x", "proj-1")
        with pytest.raises(ProvenanceError):
            await engine.reverse_trace("f", "", "proj-1")


class TestDependencyAndImpact:
    async def test_dependencies_include_overlapping_decisions(
        self,
        db: SQLiteBackend,
        engine: ProvenanceEngine,
        tracker: ASTTracker,
    ) -> None:
        d1 = await _seed_decision_with_event(
            db, tracker, change_event_id="cmt-3a", change_event_source="git_commit"
        )
        d2 = await _seed_decision_with_event(
            db,
            tracker,
            change_event_id="cmt-3b",
            change_event_source="git_commit",
            title="Second decision touches p.py provenance_fn",
        )
        deps = await engine.get_decision_dependencies(d1)
        ids = {d["id"] for d in deps}
        assert str(d2) in ids

    async def test_impact_graph_shape(
        self,
        db: SQLiteBackend,
        engine: ProvenanceEngine,
        tracker: ASTTracker,
    ) -> None:
        decision_id = await _seed_decision_with_event(
            db, tracker, change_event_id="cmt-4", change_event_source="git_commit"
        )
        graph = await engine.get_impact_graph(decision_id)
        assert graph["decision"]["id"] == str(decision_id)
        assert isinstance(graph["change_events"], list)
        assert isinstance(graph["ast_changes"], list)
        assert isinstance(graph["dependents"], list)
        # Every change_event_source appears in the serialised dicts.
        assert all(
            "change_event_source" in e for e in graph["change_events"]
        )
