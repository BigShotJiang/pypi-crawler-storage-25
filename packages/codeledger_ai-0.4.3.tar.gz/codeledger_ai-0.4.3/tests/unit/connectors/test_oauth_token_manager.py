"""Unit tests for ``backend.connectors.oauth_token_manager``."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.oauth_token_manager import (
    TOKEN_REFRESH_BUFFER_SECONDS,
    ConnectorOAuthConfig,
    OAuthTokenManager,
    _coerce_expiry_seconds,
)

if TYPE_CHECKING:
    import pytest


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}
        self.deleted: list[tuple[str, str]] = []

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.deleted.append((provider, key))
        self.store.pop((provider, key), None)


def _cfg(
    slug: str = "fake",
    token_url: str = "https://provider.example/oauth/token",
) -> ConnectorOAuthConfig:
    return ConnectorOAuthConfig(
        slug=slug,
        authorize_url="https://provider.example/oauth/authorize",
        token_url=token_url,
        scopes=["read"],
        client_id_env="FAKE_CLIENT_ID",
        client_secret_env="FAKE_CLIENT_SECRET",
    )


def _resp(status_code: int = 200, body: dict | None = None) -> MagicMock:
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body if body is not None else {}
    return r


# -------------------------- client credentials -------------------------- #


def test_get_client_credentials_prefers_env_over_vault(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    cm = _FakeCM()
    cm.set("connector_fake", "client_id", "vault-id")
    cm.set("connector_fake", "client_secret", "vault-secret")
    monkeypatch.setenv("FAKE_CLIENT_ID", "env-id")
    monkeypatch.setenv("FAKE_CLIENT_SECRET", "env-secret")

    mgr = OAuthTokenManager(cm)
    assert mgr.get_client_credentials(_cfg()) == ("env-id", "env-secret")


def test_get_client_credentials_falls_back_to_vault(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    cm = _FakeCM()
    cm.set("connector_fake", "client_id", "vault-id")
    cm.set("connector_fake", "client_secret", "vault-secret")
    monkeypatch.delenv("FAKE_CLIENT_ID", raising=False)
    monkeypatch.delenv("FAKE_CLIENT_SECRET", raising=False)

    mgr = OAuthTokenManager(cm)
    assert mgr.get_client_credentials(_cfg()) == ("vault-id", "vault-secret")


def test_get_client_credentials_missing_returns_empty_pair(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    cm = _FakeCM()
    monkeypatch.delenv("FAKE_CLIENT_ID", raising=False)
    monkeypatch.delenv("FAKE_CLIENT_SECRET", raising=False)

    mgr = OAuthTokenManager(cm)
    assert mgr.get_client_credentials(_cfg()) == ("", "")


# -------------------------- store / clear ------------------------------- #


def test_store_tokens_writes_all_fields() -> None:
    cm = _FakeCM()
    mgr = OAuthTokenManager(cm)
    before = time.time()

    mgr.store_tokens(
        "fake",
        {
            "access_token": "at-1",
            "refresh_token": "rt-1",
            "expires_in": 3600,
        },
    )

    assert cm.store[("connector_fake", "access_token")] == "at-1"
    assert cm.store[("connector_fake", "refresh_token")] == "rt-1"
    stored_expiry = float(cm.store[("connector_fake", "token_expiry")])
    assert before + 3595 <= stored_expiry <= before + 3605


def test_store_tokens_skips_missing_fields() -> None:
    cm = _FakeCM()
    mgr = OAuthTokenManager(cm)

    mgr.store_tokens("fake", {"access_token": "at-2"})

    assert cm.store[("connector_fake", "access_token")] == "at-2"
    assert ("connector_fake", "refresh_token") not in cm.store
    assert ("connector_fake", "token_expiry") not in cm.store


def test_store_tokens_ignores_non_string_access_token() -> None:
    cm = _FakeCM()
    mgr = OAuthTokenManager(cm)
    mgr.store_tokens("fake", {"access_token": 12345})  # type: ignore[dict-item]
    assert ("connector_fake", "access_token") not in cm.store


def test_store_tokens_handles_numeric_string_expires_in() -> None:
    cm = _FakeCM()
    mgr = OAuthTokenManager(cm)
    mgr.store_tokens("fake", {"access_token": "at", "expires_in": "7200"})
    assert ("connector_fake", "token_expiry") in cm.store


def test_clear_tokens_removes_all_three_keys() -> None:
    cm = _FakeCM()
    cm.set("connector_fake", "access_token", "at")
    cm.set("connector_fake", "refresh_token", "rt")
    cm.set("connector_fake", "token_expiry", "123")

    OAuthTokenManager(cm).clear_tokens("fake")

    assert ("connector_fake", "access_token") not in cm.store
    assert ("connector_fake", "refresh_token") not in cm.store
    assert ("connector_fake", "token_expiry") not in cm.store
    assert ("connector_fake", "access_token") in cm.deleted


def test_clear_tokens_swallows_delete_errors() -> None:
    cm = MagicMock()
    cm.delete.side_effect = RuntimeError("vault down")
    # Must not raise.
    OAuthTokenManager(cm).clear_tokens("fake")


# -------------------------- get_valid_token ----------------------------- #


async def test_get_valid_token_returns_none_when_no_access_token() -> None:
    cm = _FakeCM()
    mgr = OAuthTokenManager(cm)
    assert await mgr.get_valid_token(_cfg()) is None


async def test_get_valid_token_returns_stored_token_when_no_expiry() -> None:
    cm = _FakeCM()
    cm.set("connector_fake", "access_token", "at-live")
    mgr = OAuthTokenManager(cm)
    assert await mgr.get_valid_token(_cfg()) == "at-live"


async def test_get_valid_token_returns_stored_when_well_within_lifetime() -> None:
    cm = _FakeCM()
    cm.set("connector_fake", "access_token", "at-live")
    # Expires in 1 hour — far outside refresh buffer.
    cm.set("connector_fake", "token_expiry", str(time.time() + 3600))
    mgr = OAuthTokenManager(cm)
    assert await mgr.get_valid_token(_cfg()) == "at-live"


async def test_get_valid_token_refreshes_when_within_buffer(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    cm = _FakeCM()
    cm.set("connector_fake", "access_token", "at-old")
    cm.set("connector_fake", "refresh_token", "rt-old")
    # Expires in 2 minutes — inside the 5-minute refresh buffer.
    cm.set(
        "connector_fake",
        "token_expiry",
        str(time.time() + 120),
    )
    monkeypatch.setenv("FAKE_CLIENT_ID", "cid")
    monkeypatch.setenv("FAKE_CLIENT_SECRET", "csec")

    mgr = OAuthTokenManager(cm)
    fake_post = AsyncMock(
        return_value=_resp(
            200,
            {"access_token": "at-new", "refresh_token": "rt-new", "expires_in": 3600},
        )
    )
    with patch.object(OAuthTokenManager, "_http_post", new=fake_post):
        result = await mgr.get_valid_token(_cfg())

    assert result == "at-new"
    assert cm.store[("connector_fake", "access_token")] == "at-new"
    assert cm.store[("connector_fake", "refresh_token")] == "rt-new"
    # post was called with the refresh_token grant payload
    sent_data = fake_post.await_args.kwargs["data"]
    assert sent_data["grant_type"] == "refresh_token"
    assert sent_data["refresh_token"] == "rt-old"
    assert sent_data["client_id"] == "cid"


async def test_get_valid_token_refresh_returns_none_when_provider_errors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    cm = _FakeCM()
    cm.set("connector_fake", "access_token", "at-old")
    cm.set("connector_fake", "refresh_token", "rt-old")
    cm.set("connector_fake", "token_expiry", str(time.time() + 60))
    monkeypatch.setenv("FAKE_CLIENT_ID", "cid")
    monkeypatch.setenv("FAKE_CLIENT_SECRET", "csec")

    with patch.object(
        OAuthTokenManager,
        "_http_post",
        new=AsyncMock(return_value=_resp(400, {"error": "invalid_grant"})),
    ):
        result = await OAuthTokenManager(cm).get_valid_token(_cfg())

    assert result is None
    # Stale access_token is NOT cleared on a failed refresh — avoids flapping.
    assert cm.store[("connector_fake", "access_token")] == "at-old"


async def test_get_valid_token_refresh_swallows_http_errors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    cm = _FakeCM()
    cm.set("connector_fake", "access_token", "at-old")
    cm.set("connector_fake", "refresh_token", "rt-old")
    cm.set("connector_fake", "token_expiry", str(time.time() + 60))
    monkeypatch.setenv("FAKE_CLIENT_ID", "cid")
    monkeypatch.setenv("FAKE_CLIENT_SECRET", "csec")

    with patch.object(
        OAuthTokenManager,
        "_http_post",
        new=AsyncMock(side_effect=httpx.ConnectError("network down")),
    ):
        result = await OAuthTokenManager(cm).get_valid_token(_cfg())
    assert result is None


async def test_get_valid_token_refresh_skipped_without_refresh_token() -> None:
    cm = _FakeCM()
    cm.set("connector_fake", "access_token", "at-old")
    cm.set("connector_fake", "token_expiry", str(time.time() + 60))
    # No refresh_token, no client creds.

    fake_post = AsyncMock()
    with patch.object(OAuthTokenManager, "_http_post", new=fake_post):
        result = await OAuthTokenManager(cm).get_valid_token(_cfg())

    assert result is None
    fake_post.assert_not_awaited()


async def test_get_valid_token_returns_stored_on_malformed_expiry() -> None:
    cm = _FakeCM()
    cm.set("connector_fake", "access_token", "at-live")
    cm.set("connector_fake", "token_expiry", "not-a-number")
    mgr = OAuthTokenManager(cm)
    assert await mgr.get_valid_token(_cfg()) == "at-live"


async def test_get_valid_token_refresh_non_json_body_returns_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    cm = _FakeCM()
    cm.set("connector_fake", "access_token", "at-old")
    cm.set("connector_fake", "refresh_token", "rt-old")
    cm.set("connector_fake", "token_expiry", str(time.time() + 60))
    monkeypatch.setenv("FAKE_CLIENT_ID", "cid")
    monkeypatch.setenv("FAKE_CLIENT_SECRET", "csec")

    bad = _resp(200, {})
    bad.json.side_effect = ValueError("not json")

    with patch.object(OAuthTokenManager, "_http_post", new=AsyncMock(return_value=bad)):
        assert await OAuthTokenManager(cm).get_valid_token(_cfg()) is None


# -------------------------- helper -------------------------------------- #


def test_coerce_expiry_seconds_variants() -> None:
    assert _coerce_expiry_seconds(3600) == 3600.0
    assert _coerce_expiry_seconds(3600.5) == 3600.5
    assert _coerce_expiry_seconds("3600") == 3600.0
    assert _coerce_expiry_seconds("not a number") is None
    assert _coerce_expiry_seconds(None) is None
    assert _coerce_expiry_seconds(True) is None
    assert _coerce_expiry_seconds({"x": 1}) is None


def test_refresh_buffer_constant_is_five_minutes() -> None:
    assert TOKEN_REFRESH_BUFFER_SECONDS == 300
