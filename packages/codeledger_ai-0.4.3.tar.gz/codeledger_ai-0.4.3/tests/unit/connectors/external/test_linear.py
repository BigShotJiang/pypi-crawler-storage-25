"""Unit tests for ``backend.connectors.external.linear.LinearConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.base import ConnectorStatus
from backend.connectors.external.linear import LinearConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _response(status_code: int = 200, body=None) -> MagicMock:  # type: ignore[no-untyped-def]
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body
    return r


def _configured() -> LinearConnector:
    cm = _FakeCM()
    cm.set("connector_linear", "access_token", "tok")
    return LinearConnector(cm)


async def test_search_maps_issue_nodes() -> None:
    body = {
        "data": {
            "issueSearch": {
                "nodes": [
                    {
                        "id": "uuid-1",
                        "identifier": "ENG-42",
                        "title": "Add caching",
                        "priority": 2,
                        "url": "https://linear.app/eng/issue/ENG-42/add-caching",
                        "state": {"name": "In Progress"},
                    }
                ]
            }
        }
    }
    with patch.object(
        LinearConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        [r] = await _configured().search("caching", "p")

    assert r.item_id == "uuid-1"
    assert r.title.startswith("ENG-42:")
    assert "Add caching" in r.title
    assert "state=In Progress" in r.summary
    assert "priority=2" in r.summary
    assert r.metadata["identifier"] == "ENG-42"


async def test_search_empty_when_graphql_errors_present() -> None:
    body = {"errors": [{"message": "field not found"}], "data": {"issueSearch": {"nodes": []}}}
    with patch.object(
        LinearConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        assert await _configured().search("q", "p") == []


async def test_search_empty_on_non_200() -> None:
    with patch.object(
        LinearConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(500)),
    ):
        assert await _configured().search("q", "p") == []


async def test_search_empty_on_malformed_payload() -> None:
    body = {"data": "not a dict"}
    with patch.object(
        LinearConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        assert await _configured().search("q", "p") == []


async def test_get_item_maps_issue() -> None:
    body = {
        "data": {
            "issue": {
                "id": "u1",
                "identifier": "ENG-1",
                "title": "Thing",
                "priority": 1,
                "url": "https://linear.app/x/issue/ENG-1",
                "state": {"name": "Todo"},
            }
        }
    }
    with patch.object(
        LinearConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        r = await _configured().get_item("u1", "p")
    assert r is not None
    assert r.item_id == "u1"


async def test_get_item_none_when_issue_missing() -> None:
    body = {"data": {"issue": None}}
    with patch.object(
        LinearConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        assert await _configured().get_item("u1", "p") is None


async def test_get_item_empty_id() -> None:
    assert await _configured().get_item("", "p") is None


async def test_health_connected_when_viewer_returns_user() -> None:
    body = {"data": {"viewer": {"id": "u1", "name": "Alice"}}}
    with patch.object(
        LinearConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        h = await _configured().health()
    assert h.status == ConnectorStatus.CONNECTED


async def test_health_auth_expired_when_viewer_empty() -> None:
    body = {"data": {"viewer": None}}
    with patch.object(
        LinearConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        h = await _configured().health()
    assert h.status == ConnectorStatus.AUTH_EXPIRED


async def test_health_error_on_graphql_errors() -> None:
    body = {"errors": [{"message": "bad token"}]}
    with patch.object(
        LinearConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        h = await _configured().health()
    assert h.status == ConnectorStatus.ERROR


async def test_health_not_configured_without_token() -> None:
    h = await LinearConnector(_FakeCM()).health()
    assert h.status == ConnectorStatus.NOT_CONFIGURED


def test_oauth_config_linear_shape() -> None:
    cfg = LinearConnector.oauth_config
    assert cfg is not None
    assert cfg.token_url == "https://api.linear.app/oauth/token"
    assert cfg.pkce is True
    assert cfg.scopes == ["read"]
