"""Unit tests for ``backend.connectors.external.slack.SlackConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.external.slack import SlackConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _response(status_code: int = 200, body=None) -> MagicMock:  # type: ignore[no-untyped-def]
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body
    return r


def _configured() -> SlackConnector:
    cm = _FakeCM()
    cm.set("connector_slack", "access_token", "tok")
    return SlackConnector(cm)


async def test_search_maps_matches() -> None:
    body = {
        "ok": True,
        "messages": {
            "matches": [
                {
                    "type": "message",
                    "channel": {"id": "C1", "name": "eng"},
                    "user": "U42",
                    "username": "alice",
                    "text": "let's ship the launch",
                    "ts": "1.2",
                    "permalink": "https://ws.slack.com/archives/C1/p1",
                }
            ]
        },
    }
    with patch.object(
        SlackConnector, "_http_get", new=AsyncMock(return_value=_response(200, body))
    ):
        [r] = await _configured().search("launch", "p")

    assert r.item_id == "C1:1.2"
    assert "#eng" in r.title
    assert "alice" in r.title
    assert "ship the launch" in r.summary
    assert r.url == "https://ws.slack.com/archives/C1/p1"
    assert r.metadata["channel"] == "eng"


async def test_search_empty_when_ok_is_false() -> None:
    # Slack returns HTTP 200 for many error conditions — must treat ok=false as failure.
    with patch.object(
        SlackConnector,
        "_http_get",
        new=AsyncMock(
            return_value=_response(200, {"ok": False, "error": "rate_limited"})
        ),
    ):
        assert await _configured().search("q", "p") == []


async def test_search_empty_on_non_200() -> None:
    with patch.object(
        SlackConnector, "_http_get", new=AsyncMock(return_value=_response(500))
    ):
        assert await _configured().search("q", "p") == []


async def test_search_summary_truncated_by_result_cap() -> None:
    body = {
        "ok": True,
        "messages": {
            "matches": [
                {
                    "channel": {"id": "C1", "name": "eng"},
                    "text": "message body " * 100,
                    "ts": "1.1",
                    "permalink": "https://s",
                }
            ]
        },
    }
    with patch.object(
        SlackConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        [r] = await _configured().search("q", "p")
    assert len(r.summary) <= 500


async def test_get_item_requires_channel_ts_id() -> None:
    conn = _configured()
    assert await conn.get_item("", "p") is None
    assert await conn.get_item("no-colon", "p") is None
    assert await conn.get_item(":missing-channel", "p") is None
    assert await conn.get_item("C1:", "p") is None


async def test_get_item_fetches_thread_root() -> None:
    body = {
        "ok": True,
        "messages": [
            {"ts": "1.2", "user": "U1", "text": "root message"},
        ],
    }
    with patch.object(
        SlackConnector, "_http_get", new=AsyncMock(return_value=_response(200, body))
    ):
        r = await _configured().get_item("C1:1.2", "p")
    assert r is not None
    assert r.item_id == "C1:1.2"
    assert "root message" in r.summary


async def test_get_item_none_when_not_ok() -> None:
    with patch.object(
        SlackConnector,
        "_http_get",
        new=AsyncMock(
            return_value=_response(200, {"ok": False, "error": "channel_not_found"})
        ),
    ):
        assert await _configured().get_item("C1:1.2", "p") is None


def test_oauth_config_slack_shape() -> None:
    cfg = SlackConnector.oauth_config
    assert cfg is not None
    assert cfg.token_url == "https://slack.com/api/oauth.v2.access"
    assert cfg.pkce is False
    assert "search:read" in cfg.scopes
