"""Unit tests for ``backend.connectors.external._base.ExternalConnector``."""

from __future__ import annotations

from typing import ClassVar
from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorStatus,
)
from backend.connectors.external._base import ExternalConnector
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


_PROBE_OAUTH_CFG = ConnectorOAuthConfig(
    slug="probe",
    authorize_url="https://example.test/authorize",
    token_url="https://example.test/token",
    scopes=[],
)


class _OAuthProbe(ExternalConnector):
    slug = "probe"
    display_name = "Probe"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.COMMUNICATION
    oauth_scopes: ClassVar[list[str]] = []
    description = "probe"
    health_probe_url: ClassVar[str | None] = "https://example.test/health"
    oauth_config: ClassVar[ConnectorOAuthConfig | None] = _PROBE_OAUTH_CFG

    async def search(self, query, project_id, max_results=10):  # type: ignore[no-untyped-def]
        return []

    async def get_item(self, item_id, project_id):  # type: ignore[no-untyped-def]
        return None


def _response(status_code: int = 200, body: dict | None = None) -> MagicMock:
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = body or {}
    return resp


# -------------------------- bearer token ------------------------------- #


async def test_bearer_token_for_oauth_without_otm_falls_back_to_vault() -> None:
    cm = _FakeCM()
    cm.set("connector_probe", "access_token", "vault-token")
    conn = _OAuthProbe(cm)
    assert await conn._bearer_token() == "vault-token"


async def test_bearer_token_uses_otm_when_provided() -> None:
    cm = _FakeCM()
    otm = MagicMock()
    otm.get_valid_token = AsyncMock(return_value="refreshed-token")
    conn = _OAuthProbe(cm, oauth_token_manager=otm)
    assert await conn._bearer_token() == "refreshed-token"
    otm.get_valid_token.assert_awaited_once()


async def test_bearer_token_for_api_key_connector() -> None:
    class _ApiKeyProbe(_OAuthProbe):
        auth_type = AuthType.API_KEY

    cm = _FakeCM()
    cm.set("connector_probe", "api_key", "secret-key")
    assert await _ApiKeyProbe(cm)._bearer_token() == "secret-key"


async def test_bearer_token_none_for_unconfigured_connection_string() -> None:
    class _ConnStrProbe(_OAuthProbe):
        auth_type = AuthType.CONNECTION_STRING

    assert await _ConnStrProbe(_FakeCM())._bearer_token() is None


# -------------------------- _http_get / _http_post --------------------- #


async def test_http_get_returns_none_without_token() -> None:
    conn = _OAuthProbe(_FakeCM())
    assert await conn._http_get("https://x.test/") is None


async def test_http_get_attaches_bearer_header_and_returns_response() -> None:
    cm = _FakeCM()
    cm.set("connector_probe", "access_token", "tok")
    conn = _OAuthProbe(cm)

    captured: dict = {}

    class _FakeClient:
        def __init__(self, *args, **kwargs):  # type: ignore[no-untyped-def]
            pass

        async def __aenter__(self):  # type: ignore[no-untyped-def]
            return self

        async def __aexit__(self, *args, **kwargs):  # type: ignore[no-untyped-def]
            return False

        async def get(self, url, params=None, headers=None):  # type: ignore[no-untyped-def]
            captured["url"] = url
            captured["params"] = params
            captured["headers"] = headers
            return _response(200, {"ok": True})

    with patch("backend.connectors.external._base.httpx.AsyncClient", _FakeClient):
        resp = await conn._http_get("https://x.test/", params={"q": "hi"})

    assert resp is not None and resp.status_code == 200
    assert captured["url"] == "https://x.test/"
    assert captured["params"] == {"q": "hi"}
    assert captured["headers"]["Authorization"] == "Bearer tok"
    assert captured["headers"]["Accept"] == "application/json"


async def test_http_get_swallows_httpx_error() -> None:
    cm = _FakeCM()
    cm.set("connector_probe", "access_token", "tok")
    conn = _OAuthProbe(cm)

    class _ErrClient:
        def __init__(self, *args, **kwargs):  # type: ignore[no-untyped-def]
            pass

        async def __aenter__(self):  # type: ignore[no-untyped-def]
            return self

        async def __aexit__(self, *args, **kwargs):  # type: ignore[no-untyped-def]
            return False

        async def get(self, url, params=None, headers=None):  # type: ignore[no-untyped-def]
            raise httpx.ConnectError("no route")

    with patch("backend.connectors.external._base.httpx.AsyncClient", _ErrClient):
        assert await conn._http_get("https://x.test/") is None


async def test_http_post_includes_headers_extra() -> None:
    cm = _FakeCM()
    cm.set("connector_probe", "access_token", "tok")
    conn = _OAuthProbe(cm)

    captured: dict = {}

    class _FakeClient:
        def __init__(self, *args, **kwargs):  # type: ignore[no-untyped-def]
            pass

        async def __aenter__(self):  # type: ignore[no-untyped-def]
            return self

        async def __aexit__(self, *args, **kwargs):  # type: ignore[no-untyped-def]
            return False

        async def post(self, url, json=None, data=None, params=None, headers=None):  # type: ignore[no-untyped-def]
            captured["headers"] = headers
            captured["json"] = json
            return _response(200, {})

    with patch("backend.connectors.external._base.httpx.AsyncClient", _FakeClient):
        await conn._http_post(
            "https://x.test/", json={"a": 1}, headers_extra={"X-Custom": "yes"}
        )
    assert captured["headers"]["X-Custom"] == "yes"
    assert captured["headers"]["Authorization"] == "Bearer tok"


# -------------------------- default health ----------------------------- #


async def test_health_reports_not_configured_when_no_token() -> None:
    health = await _OAuthProbe(_FakeCM()).health()
    assert health.status == ConnectorStatus.NOT_CONFIGURED
    assert health.configured is False


async def test_health_connected_on_200() -> None:
    cm = _FakeCM()
    cm.set("connector_probe", "access_token", "tok")
    conn = _OAuthProbe(cm)
    with patch.object(
        ExternalConnector, "_http_get", new=AsyncMock(return_value=_response(200))
    ):
        health = await conn.health()
    assert health.status == ConnectorStatus.CONNECTED


async def test_health_auth_expired_on_401() -> None:
    cm = _FakeCM()
    cm.set("connector_probe", "access_token", "tok")
    conn = _OAuthProbe(cm)
    with patch.object(
        ExternalConnector, "_http_get", new=AsyncMock(return_value=_response(401))
    ):
        health = await conn.health()
    assert health.status == ConnectorStatus.AUTH_EXPIRED


async def test_health_error_on_network_failure() -> None:
    cm = _FakeCM()
    cm.set("connector_probe", "access_token", "tok")
    conn = _OAuthProbe(cm)
    with patch.object(
        ExternalConnector, "_http_get", new=AsyncMock(return_value=None)
    ):
        health = await conn.health()
    assert health.status == ConnectorStatus.ERROR
    assert "network" in health.message


async def test_health_degraded_when_no_probe_url_defined() -> None:
    class _NoProbe(_OAuthProbe):
        slug = "noprobe"
        health_probe_url: ClassVar[str | None] = None

    cm = _FakeCM()
    cm.set("connector_noprobe", "access_token", "tok")
    health = await _NoProbe(cm).health()
    assert health.status == ConnectorStatus.DEGRADED
