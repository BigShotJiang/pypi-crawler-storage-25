"""Unit tests for ``backend.connectors.external.drive.DriveConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.external.drive import DriveConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _response(status_code: int = 200, body: dict | None = None) -> MagicMock:
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body or {}
    return r


def _configured() -> DriveConnector:
    cm = _FakeCM()
    cm.set("connector_drive", "access_token", "tok")
    return DriveConnector(cm)


async def test_search_maps_files_to_results() -> None:
    body = {
        "files": [
            {
                "id": "abc",
                "name": "Architecture.md",
                "webViewLink": "https://drive.google.com/file/d/abc/view",
                "modifiedTime": "2026-04-10T12:00:00Z",
                "mimeType": "text/markdown",
                "owners": [{"emailAddress": "e@x.test"}],
            }
        ]
    }
    with patch.object(
        DriveConnector, "_http_get", new=AsyncMock(return_value=_response(200, body))
    ):
        [r] = await _configured().search("architecture", "p")

    assert r.item_id == "abc"
    assert r.title == "Architecture.md"
    assert r.url == "https://drive.google.com/file/d/abc/view"
    assert r.connector_slug == "drive"
    assert r.item_type == "file"
    assert r.metadata["mime_type"] == "text/markdown"
    assert "modified 2026-04-10" in r.summary


async def test_search_escapes_single_quote_in_query() -> None:
    captured: dict = {}

    async def fake_get(self, url, *, params=None, headers_extra=None):  # type: ignore[no-untyped-def]
        captured["params"] = params
        return _response(200, {"files": []})

    with patch.object(DriveConnector, "_http_get", new=fake_get):
        await _configured().search("alice's notes", "p")

    assert "alice\\'s notes" in captured["params"]["q"]


async def test_search_returns_empty_on_error() -> None:
    with patch.object(DriveConnector, "_http_get", new=AsyncMock(return_value=_response(500))):
        assert await _configured().search("q", "p") == []


async def test_search_skips_files_without_id() -> None:
    body = {"files": [{"name": "no-id"}, {"id": "x", "name": "ok"}]}
    with patch.object(
        DriveConnector, "_http_get", new=AsyncMock(return_value=_response(200, body))
    ):
        results = await _configured().search("q", "p")
    assert [r.item_id for r in results] == ["x"]


async def test_get_item_returns_file_result() -> None:
    body = {
        "id": "f1",
        "name": "Design.pdf",
        "webViewLink": "https://drive.google.com/file/d/f1/view",
        "modifiedTime": "2026-04-15T08:30:00Z",
        "mimeType": "application/pdf",
    }
    with patch.object(
        DriveConnector, "_http_get", new=AsyncMock(return_value=_response(200, body))
    ):
        r = await _configured().get_item("f1", "p")
    assert r is not None
    assert r.title == "Design.pdf"


async def test_get_item_none_on_empty_payload() -> None:
    with patch.object(DriveConnector, "_http_get", new=AsyncMock(return_value=_response(200, {}))):
        assert await _configured().get_item("f1", "p") is None


async def test_get_item_none_for_empty_id() -> None:
    assert await _configured().get_item("", "p") is None


async def test_get_item_rejects_path_traversal() -> None:
    conn = _configured()
    assert await conn.get_item("../secret", "p") is None
    assert await conn.get_item("a/b", "p") is None
