"""Unit tests for ``backend.connectors.external.gcal.CalendarConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.external.gcal import CalendarConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _response(status_code: int = 200, body: dict | None = None) -> MagicMock:
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body or {}
    return r


def _configured() -> CalendarConnector:
    cm = _FakeCM()
    cm.set("connector_calendar", "access_token", "tok")
    return CalendarConnector(cm)


async def test_search_maps_event_summary_start_attendees() -> None:
    body = {
        "items": [
            {
                "id": "e1",
                "summary": "Sprint planning",
                "start": {"dateTime": "2026-04-20T10:00:00Z"},
                "end": {"dateTime": "2026-04-20T11:00:00Z"},
                "attendees": [{"email": "a@x"}, {"email": "b@x"}, {"email": "c@x"}],
                "htmlLink": "https://calendar.google.com/event?eid=e1",
            }
        ]
    }
    with patch.object(
        CalendarConnector, "_http_get", new=AsyncMock(return_value=_response(200, body))
    ):
        [r] = await _configured().search("sprint", "p")

    assert r.title == "Sprint planning"
    assert r.item_id == "e1"
    assert r.metadata["attendee_count"] == 3
    assert "3 attendees" in r.summary
    assert r.url == "https://calendar.google.com/event?eid=e1"


async def test_search_omits_attendee_names_and_description() -> None:
    body = {
        "items": [
            {
                "id": "e2",
                "summary": "1:1",
                "start": {"dateTime": "2026-04-20T10:00:00Z"},
                "end": {"dateTime": "2026-04-20T11:00:00Z"},
                "attendees": [
                    {"email": "alice@corp.example", "displayName": "Alice"},
                ],
                "description": "PRIVATE NOTES DO NOT LEAK",
            }
        ]
    }
    with patch.object(
        CalendarConnector, "_http_get", new=AsyncMock(return_value=_response(200, body))
    ):
        [r] = await _configured().search("q", "p")

    # PII guarantee — neither attendee emails nor description text can appear
    # in the summary/title/metadata surfaced to the agent.
    blob = f"{r.title} {r.summary} {r.metadata!s}"
    assert "alice@corp.example" not in blob
    assert "PRIVATE NOTES" not in blob


async def test_search_handles_all_day_event() -> None:
    body = {
        "items": [
            {
                "id": "ad",
                "summary": "Team offsite",
                "start": {"date": "2026-04-22"},
                "end": {"date": "2026-04-23"},
            }
        ]
    }
    with patch.object(
        CalendarConnector, "_http_get", new=AsyncMock(return_value=_response(200, body))
    ):
        [r] = await _configured().search("offsite", "p")
    assert r.metadata["start"] == "2026-04-22"


async def test_search_empty_on_api_error() -> None:
    with patch.object(CalendarConnector, "_http_get", new=AsyncMock(return_value=_response(500))):
        assert await _configured().search("q", "p") == []


async def test_get_item_none_for_empty_id() -> None:
    assert await _configured().get_item("", "p") is None


async def test_get_item_rejects_path_traversal() -> None:
    conn = _configured()
    assert await conn.get_item("../acl", "p") is None
    assert await conn.get_item("a/b", "p") is None


async def test_get_item_returns_event() -> None:
    body = {
        "id": "e9",
        "summary": "Retro",
        "start": {"dateTime": "2026-04-25T15:00:00Z"},
        "end": {"dateTime": "2026-04-25T16:00:00Z"},
    }
    with patch.object(
        CalendarConnector, "_http_get", new=AsyncMock(return_value=_response(200, body))
    ):
        r = await _configured().get_item("e9", "p")
    assert r is not None
    assert r.title == "Retro"
