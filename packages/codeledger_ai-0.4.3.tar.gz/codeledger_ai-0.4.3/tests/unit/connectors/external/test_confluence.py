"""Unit tests for ``backend.connectors.external.confluence.ConfluenceConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.base import ConnectorStatus
from backend.connectors.external.confluence import ConfluenceConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _response(status_code: int = 200, body=None) -> MagicMock:  # type: ignore[no-untyped-def]
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body
    return r


def _configured() -> ConfluenceConnector:
    cm = _FakeCM()
    cm.set("connector_confluence", "access_token", "tok")
    cm.set("connector_confluence", "cloud_id", "cid-1")
    cm.set("connector_confluence", "site_url", "https://acme.atlassian.net")
    return ConfluenceConnector(cm)


async def test_search_maps_content_results() -> None:
    conn = _configured()
    body = {
        "results": [
            {
                "id": "p1",
                "title": "Architecture Decisions",
                "space": {"key": "ENG", "name": "Engineering"},
                "history": {"lastUpdated": {"when": "2026-04-15T10:00:00Z"}},
                "_links": {"webui": "/spaces/ENG/pages/p1"},
            }
        ]
    }
    with patch.object(
        ConfluenceConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        [r] = await conn.search("architecture", "p")

    assert r.item_id == "p1"
    assert r.title == "Architecture Decisions"
    assert "Engineering" in r.summary
    assert "2026-04-15" in r.summary
    assert r.url == "https://acme.atlassian.net/wiki/spaces/ENG/pages/p1"
    assert r.metadata["space"] == "Engineering"


async def test_search_escapes_double_quote_in_cql() -> None:
    conn = _configured()
    captured: dict = {}

    async def fake_get(self, url, *, params=None, headers_extra=None):  # type: ignore[no-untyped-def]
        captured["params"] = params
        return _response(200, {"results": []})

    with patch.object(ConfluenceConnector, "_http_get", new=fake_get):
        await conn.search('bug with "quote"', "p")

    # The CQL must not contain an unescaped embedded double-quote.
    cql = captured["params"]["cql"]
    assert cql.startswith('text ~ "')
    assert cql.endswith('"')
    assert '\\"quote\\"' in cql


async def test_search_empty_on_non_200() -> None:
    conn = _configured()
    with patch.object(
        ConfluenceConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(500)),
    ):
        assert await conn.search("q", "p") == []


async def test_search_skips_entries_without_id() -> None:
    conn = _configured()
    body = {"results": [{"title": "no id"}, {"id": "x", "title": "ok"}]}
    with patch.object(
        ConfluenceConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        results = await conn.search("q", "p")
    assert [r.item_id for r in results] == ["x"]


async def test_search_does_not_include_page_body() -> None:
    # Important PII guarantee — even if the API returns a body.view, we must
    # never surface raw page HTML in the ConnectorResult.
    conn = _configured()
    body = {
        "results": [
            {
                "id": "p1",
                "title": "Quarterly Goals",
                "space": {"name": "HR"},
                "body": {
                    "view": {
                        "value": "<p>SENSITIVE COMP DATA</p>",
                    }
                },
            }
        ]
    }
    with patch.object(
        ConfluenceConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        [r] = await conn.search("goals", "p")
    combined = f"{r.title} {r.summary} {r.metadata!s}"
    assert "SENSITIVE COMP DATA" not in combined


async def test_get_item_returns_page_metadata() -> None:
    conn = _configured()
    body = {
        "id": "p2",
        "title": "Runbook",
        "space": {"name": "Ops"},
        "history": {"lastUpdated": {"when": "2026-04-01T08:00:00Z"}},
        "_links": {"webui": "/spaces/OPS/pages/p2"},
    }
    with patch.object(
        ConfluenceConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        r = await conn.get_item("p2", "p")
    assert r is not None
    assert r.title == "Runbook"


async def test_get_item_empty_id() -> None:
    assert await _configured().get_item("", "p") is None


async def test_get_item_rejects_path_traversal() -> None:
    # Authenticated MCP callers must not be able to reach arbitrary
    # Confluence endpoints by embedding "/" or ".." in the content id.
    conn = _configured()
    assert await conn.get_item("../admin", "p") is None
    assert await conn.get_item("foo/bar", "p") is None
    assert await conn.get_item("..", "p") is None


async def test_get_item_none_on_missing_id_in_payload() -> None:
    conn = _configured()
    with patch.object(
        ConfluenceConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, {"title": "no id"})),
    ):
        assert await conn.get_item("whatever", "p") is None


async def test_health_connected_on_200() -> None:
    conn = _configured()
    with patch.object(
        ConfluenceConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, {"results": []})),
    ):
        h = await conn.health()
    assert h.status == ConnectorStatus.CONNECTED


async def test_oauth_config_atlassian_shape() -> None:
    cfg = ConfluenceConnector.oauth_config
    assert cfg is not None
    assert cfg.extra_authorize_params["audience"] == "api.atlassian.com"
    assert "read:confluence-content.all" in cfg.scopes
