"""Unit tests for ``backend.connectors.external.outlook.OutlookConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.external.outlook import OutlookConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _response(status_code: int = 200, body=None) -> MagicMock:  # type: ignore[no-untyped-def]
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body
    return r


def _configured() -> OutlookConnector:
    cm = _FakeCM()
    cm.set("connector_outlook", "access_token", "tok")
    return OutlookConnector(cm)


async def test_search_maps_messages() -> None:
    body = {
        "value": [
            {
                "id": "m1",
                "subject": "Release notes",
                "from": {
                    "emailAddress": {
                        "name": "Alice",
                        "address": "alice@x.com",
                    }
                },
                "receivedDateTime": "2026-04-17T09:00:00Z",
                "bodyPreview": "Here is the April release summary",
                "webLink": "https://outlook.office.com/mail/m1",
            }
        ]
    }
    with patch.object(
        OutlookConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        [r] = await _configured().search("release", "p")

    assert r.item_id == "m1"
    assert r.title == "Release notes"
    assert "Alice" in r.summary
    assert "April release" in r.summary
    assert r.url == "https://outlook.office.com/mail/m1"
    assert r.metadata["sender_name"] == "Alice"
    assert r.metadata["sender_address"] == "alice@x.com"


async def test_search_escapes_double_quote() -> None:
    captured: dict = {}

    async def fake_get(self, url, *, params=None, headers_extra=None):  # type: ignore[no-untyped-def]
        captured["params"] = params
        return _response(200, {"value": []})

    with patch.object(OutlookConnector, "_http_get", new=fake_get):
        await _configured().search('bug with "quotes"', "p")

    search_param = captured["params"]["$search"]
    assert search_param.startswith('"')
    assert search_param.endswith('"')
    assert '\\"' in search_param


async def test_search_empty_on_non_200() -> None:
    with patch.object(
        OutlookConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(500)),
    ):
        assert await _configured().search("q", "p") == []


async def test_search_skips_entries_without_id() -> None:
    body = {"value": [{"subject": "no id"}, {"id": "x", "subject": "ok"}]}
    with patch.object(
        OutlookConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        assert [r.item_id for r in await _configured().search("q", "p")] == ["x"]


async def test_search_does_not_include_full_body() -> None:
    # bodyPreview is the Graph-provided safe summary; the full message body
    # is deliberately not requested via $select — verify one doesn't slip in.
    body = {
        "value": [
            {
                "id": "m9",
                "subject": "Private",
                "bodyPreview": "meeting recap",
                "body": {"content": "<p>SENSITIVE</p>", "contentType": "html"},
                "from": {"emailAddress": {"name": "x", "address": "x@y"}},
            }
        ]
    }
    with patch.object(
        OutlookConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        [r] = await _configured().search("q", "p")
    combined = f"{r.title} {r.summary} {r.metadata!s}"
    assert "SENSITIVE" not in combined


async def test_get_item_returns_message() -> None:
    body = {
        "id": "m2",
        "subject": "Q3 plan",
        "from": {"emailAddress": {"name": "Bob", "address": "bob@x"}},
        "receivedDateTime": "2026-04-15T12:00:00Z",
        "bodyPreview": "draft plan attached",
        "webLink": "https://outlook.office.com/mail/m2",
    }
    with patch.object(
        OutlookConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        r = await _configured().get_item("m2", "p")
    assert r is not None
    assert r.title == "Q3 plan"
    assert r.metadata["sender_name"] == "Bob"


async def test_get_item_rejects_path_like_id() -> None:
    assert await _configured().get_item("../admin", "p") is None
    assert await _configured().get_item("a/b", "p") is None


async def test_get_item_empty_id() -> None:
    assert await _configured().get_item("", "p") is None


async def test_get_item_missing_id_in_payload() -> None:
    with patch.object(
        OutlookConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, {"subject": "no id"})),
    ):
        assert await _configured().get_item("m3", "p") is None


async def test_oauth_config_microsoft_shape() -> None:
    cfg = OutlookConnector.oauth_config
    assert cfg is not None
    assert cfg.authorize_url.endswith("/oauth2/v2.0/authorize")
    assert cfg.client_id_env == "CODELEDGER_MICROSOFT_CLIENT_ID"
    # Mail.Read is fully-qualified
    assert any("Mail.Read" in s for s in cfg.scopes)
