"""Unit tests for ``backend.connectors.external.asana.AsanaConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.base import ConnectorStatus
from backend.connectors.external.asana import AsanaConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _response(status_code: int = 200, body=None) -> MagicMock:  # type: ignore[no-untyped-def]
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body
    return r


def _configured_with_workspace() -> tuple[AsanaConnector, _FakeCM]:
    cm = _FakeCM()
    cm.set("connector_asana", "access_token", "tok")
    cm.set("connector_asana", "workspace_gid", "ws-1")
    return AsanaConnector(cm), cm


async def test_workspace_gid_cached_after_first_lookup() -> None:
    cm = _FakeCM()
    cm.set("connector_asana", "access_token", "tok")
    body = {"data": {"workspaces": [{"gid": "ws-xyz", "name": "Acme"}]}}
    call_count = {"n": 0}

    async def fake_get(self, url, *, params=None, headers_extra=None):  # type: ignore[no-untyped-def]
        call_count["n"] += 1
        return _response(200, body)

    with patch.object(AsanaConnector, "_http_get", new=fake_get):
        conn = AsanaConnector(cm)
        gid1 = await conn._workspace_gid()
        gid2 = await conn._workspace_gid()

    assert gid1 == "ws-xyz"
    assert gid2 == "ws-xyz"
    # Second call should hit the cache, not the API again.
    assert call_count["n"] == 1
    assert cm.store[("connector_asana", "workspace_gid")] == "ws-xyz"


async def test_workspace_gid_none_when_no_workspaces() -> None:
    cm = _FakeCM()
    cm.set("connector_asana", "access_token", "tok")
    body = {"data": {"workspaces": []}}
    with patch.object(
        AsanaConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        assert await AsanaConnector(cm)._workspace_gid() is None


async def test_workspace_gid_none_on_api_error() -> None:
    cm = _FakeCM()
    cm.set("connector_asana", "access_token", "tok")
    with patch.object(
        AsanaConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(500)),
    ):
        assert await AsanaConnector(cm)._workspace_gid() is None


async def test_search_returns_tasks() -> None:
    conn, _ = _configured_with_workspace()
    body = {
        "data": [
            {"gid": "t1", "name": "Write spec", "completed": False},
            {"gid": "t2", "name": "Review PR", "completed": True},
        ]
    }
    with patch.object(
        AsanaConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        results = await conn.search("spec", "p")
    assert [r.item_id for r in results] == ["t1", "t2"]
    assert results[0].title == "Write spec"
    assert "completed=False" in results[0].summary


async def test_search_empty_without_workspace() -> None:
    cm = _FakeCM()
    cm.set("connector_asana", "access_token", "tok")
    # No cached workspace_gid; /users/me returns no workspaces
    with patch.object(
        AsanaConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, {"data": {"workspaces": []}})),
    ):
        assert await AsanaConnector(cm).search("q", "p") == []


async def test_search_empty_on_non_200() -> None:
    conn, _ = _configured_with_workspace()
    with patch.object(
        AsanaConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(500)),
    ):
        assert await conn.search("q", "p") == []


async def test_get_item_rejects_bad_ids() -> None:
    conn, _ = _configured_with_workspace()
    assert await conn.get_item("", "p") is None
    assert await conn.get_item("t/1", "p") is None
    assert await conn.get_item("../admin", "p") is None


async def test_get_item_returns_full_task() -> None:
    conn, _ = _configured_with_workspace()
    body = {
        "data": {
            "gid": "t99",
            "name": "Ship launch",
            "completed": False,
            "due_on": "2026-05-01",
            "assignee": {"name": "Alice"},
            "permalink_url": "https://app.asana.com/0/1/t99",
        }
    }
    with patch.object(
        AsanaConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        r = await conn.get_item("t99", "p")
    assert r is not None
    assert "due=2026-05-01" in r.summary
    assert "assignee=Alice" in r.summary
    assert r.url == "https://app.asana.com/0/1/t99"


async def test_health_auth_expired_when_workspace_unresolved() -> None:
    cm = _FakeCM()
    cm.set("connector_asana", "access_token", "tok")
    with patch.object(
        AsanaConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(401)),
    ):
        h = await AsanaConnector(cm).health()
    assert h.status == ConnectorStatus.AUTH_EXPIRED


async def test_health_connected_when_workspace_resolved() -> None:
    conn, _ = _configured_with_workspace()
    h = await conn.health()
    assert h.status == ConnectorStatus.CONNECTED


async def test_health_not_configured_without_token() -> None:
    h = await AsanaConnector(_FakeCM()).health()
    assert h.status == ConnectorStatus.NOT_CONFIGURED


def test_oauth_config_asana_shape() -> None:
    cfg = AsanaConnector.oauth_config
    assert cfg is not None
    assert cfg.token_url == "https://app.asana.com/-/oauth_token"
    assert cfg.pkce is True
    assert cfg.scopes == ["default"]
