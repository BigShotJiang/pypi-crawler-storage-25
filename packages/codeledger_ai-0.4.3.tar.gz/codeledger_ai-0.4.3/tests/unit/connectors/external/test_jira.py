"""Unit tests for ``backend.connectors.external.jira.JiraConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.base import ConnectorStatus
from backend.connectors.external.jira import JiraConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _response(status_code: int = 200, body=None) -> MagicMock:  # type: ignore[no-untyped-def]
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body
    return r


def _configured_with_site() -> tuple[JiraConnector, _FakeCM]:
    cm = _FakeCM()
    cm.set("connector_jira", "access_token", "tok")
    cm.set("connector_jira", "cloud_id", "cid-1")
    cm.set("connector_jira", "site_url", "https://acme.atlassian.net")
    return JiraConnector(cm), cm


# ------------------------------- search -------------------------------- #


async def test_search_flattens_picker_sections() -> None:
    conn, _ = _configured_with_site()
    body = {
        "sections": [
            {
                "label": "History",
                "issues": [
                    {"key": "ENG-1", "summaryText": "Fix login"},
                    {"key": "ENG-2", "summaryText": "Ship dashboard"},
                ],
            },
            {
                "label": "Current",
                "issues": [
                    {"key": "ENG-3", "summaryText": "Refactor auth"},
                ],
            },
        ]
    }
    with patch.object(
        JiraConnector, "_http_get", new=AsyncMock(return_value=_response(200, body))
    ):
        results = await conn.search("login", "p")

    assert [r.item_id for r in results] == ["ENG-1", "ENG-2", "ENG-3"]
    assert results[0].title == "ENG-1: Fix login"
    assert results[0].url == "https://acme.atlassian.net/browse/ENG-1"
    assert results[0].connector_slug == "jira"
    assert results[0].item_type == "issue"


async def test_search_respects_max_results() -> None:
    conn, _ = _configured_with_site()
    body = {
        "sections": [
            {
                "issues": [
                    {"key": f"X-{i}", "summaryText": f"t{i}"} for i in range(20)
                ]
            }
        ]
    }
    with patch.object(
        JiraConnector, "_http_get", new=AsyncMock(return_value=_response(200, body))
    ):
        results = await conn.search("q", "p", max_results=5)
    assert len(results) == 5


async def test_search_empty_when_site_cannot_be_resolved() -> None:
    cm = _FakeCM()
    cm.set("connector_jira", "access_token", "tok")
    # No cloud_id cached — accessible-resources will be called and returns []
    with patch.object(
        JiraConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, [])),
    ):
        assert await JiraConnector(cm).search("q", "p") == []


async def test_search_empty_on_non_200() -> None:
    conn, _ = _configured_with_site()
    with patch.object(
        JiraConnector, "_http_get", new=AsyncMock(return_value=_response(500))
    ):
        assert await conn.search("q", "p") == []


async def test_search_empty_when_sections_missing() -> None:
    conn, _ = _configured_with_site()
    with patch.object(
        JiraConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, {"other": "shape"})),
    ):
        assert await conn.search("q", "p") == []


# ------------------------------- get_item ------------------------------ #


async def test_get_item_returns_issue_with_status_priority() -> None:
    conn, _ = _configured_with_site()
    body = {
        "key": "ENG-42",
        "fields": {
            "summary": "Add caching",
            "status": {"name": "In Progress"},
            "priority": {"name": "High"},
        },
    }
    with patch.object(
        JiraConnector, "_http_get", new=AsyncMock(return_value=_response(200, body))
    ):
        r = await conn.get_item("ENG-42", "p")

    assert r is not None
    assert r.item_id == "ENG-42"
    assert r.title == "ENG-42: Add caching"
    assert "status=In Progress" in r.summary
    assert "priority=High" in r.summary
    assert r.url == "https://acme.atlassian.net/browse/ENG-42"
    assert r.metadata == {"status": "In Progress", "priority": "High"}


async def test_get_item_empty_id_returns_none() -> None:
    conn, _ = _configured_with_site()
    assert await conn.get_item("", "p") is None


async def test_get_item_rejects_path_traversal() -> None:
    conn, _ = _configured_with_site()
    assert await conn.get_item("../myself", "p") is None
    assert await conn.get_item("ENG/1", "p") is None


async def test_get_item_none_on_missing_key() -> None:
    conn, _ = _configured_with_site()
    with patch.object(
        JiraConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, {"fields": {}})),
    ):
        assert await conn.get_item("ENG-9", "p") is None


# ------------------------------- health -------------------------------- #


async def test_health_connected_when_myself_ok() -> None:
    conn, _ = _configured_with_site()
    with patch.object(
        JiraConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, {"accountId": "1"})),
    ):
        health = await conn.health()
    assert health.status == ConnectorStatus.CONNECTED


async def test_health_auth_expired_when_site_unresolvable() -> None:
    cm = _FakeCM()
    cm.set("connector_jira", "access_token", "tok")
    with patch.object(
        JiraConnector, "_http_get", new=AsyncMock(return_value=_response(401))
    ):
        health = await JiraConnector(cm).health()
    assert health.status == ConnectorStatus.AUTH_EXPIRED


async def test_health_not_configured_without_token() -> None:
    health = await JiraConnector(_FakeCM()).health()
    assert health.status == ConnectorStatus.NOT_CONFIGURED


# ------------------------------- oauth config --------------------------- #


def test_oauth_config_atlassian_shape() -> None:
    cfg = JiraConnector.oauth_config
    assert cfg is not None
    assert cfg.authorize_url == "https://auth.atlassian.com/authorize"
    assert cfg.extra_authorize_params["audience"] == "api.atlassian.com"
    assert cfg.extra_authorize_params["prompt"] == "consent"
    assert "offline_access" in cfg.scopes
