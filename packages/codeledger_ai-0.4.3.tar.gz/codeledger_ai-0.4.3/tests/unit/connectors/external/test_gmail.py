"""Unit tests for ``backend.connectors.external.gmail.GmailConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.external.gmail import GmailConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _response(status_code: int = 200, body: dict | None = None) -> MagicMock:
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = body or {}
    return resp


def _configured() -> GmailConnector:
    cm = _FakeCM()
    cm.set("connector_gmail", "access_token", "tok")
    return GmailConnector(cm)


async def test_search_returns_empty_when_unauthenticated() -> None:
    # No token → _http_get returns None
    assert await GmailConnector(_FakeCM()).search("q", "p") == []


async def test_search_returns_empty_on_non_200() -> None:
    conn = _configured()
    with patch.object(
        GmailConnector, "_http_get", new=AsyncMock(return_value=_response(500))
    ):
        assert await conn.search("q", "p") == []


async def test_search_fans_out_metadata_calls() -> None:
    list_resp = _response(
        200, {"messages": [{"id": "m1"}, {"id": "m2"}]}
    )
    meta_m1 = _response(
        200,
        {
            "snippet": "Let's ship the launch",
            "payload": {
                "headers": [
                    {"name": "Subject", "value": "Launch update"},
                    {"name": "From", "value": "alice@example.com"},
                    {"name": "Date", "value": "Thu, 17 Apr 2026 10:00:00 +0000"},
                ]
            },
        },
    )
    meta_m2 = _response(
        200,
        {
            "snippet": "Follow-up notes",
            "payload": {
                "headers": [
                    {"name": "Subject", "value": "Follow-up"},
                    {"name": "From", "value": "bob@example.com"},
                ]
            },
        },
    )
    # First call = list, next two = metadata fetches (order depends on asyncio.gather
    # but for the fake the call list order is deterministic: list, m1, m2).
    http_mock = AsyncMock(side_effect=[list_resp, meta_m1, meta_m2])
    with patch.object(GmailConnector, "_http_get", new=http_mock):
        results = await _configured().search("launch", "p")

    assert len(results) == 2
    titles = sorted(r.title for r in results)
    assert titles == ["Follow-up", "Launch update"]
    launch = next(r for r in results if r.title == "Launch update")
    assert "alice@example.com" in launch.summary
    assert "Let's ship the launch" in launch.summary
    assert launch.url == "https://mail.google.com/mail/u/0/#inbox/m1"
    assert launch.connector_slug == "gmail"
    assert launch.item_type == "email"
    assert launch.metadata["sender"] == "alice@example.com"


async def test_search_summary_is_pii_safe_and_bounded() -> None:
    # Ensure the 500-char summary cap still applies — a malicious snippet can't
    # push the whole email body through.
    huge_snippet = "body content " * 100
    list_resp = _response(200, {"messages": [{"id": "m1"}]})
    meta = _response(
        200,
        {
            "snippet": huge_snippet,
            "payload": {
                "headers": [{"name": "From", "value": "x@y.test"}]
            },
        },
    )
    with patch.object(
        GmailConnector,
        "_http_get",
        new=AsyncMock(side_effect=[list_resp, meta]),
    ):
        [r] = await _configured().search("q", "p")
    assert len(r.summary) <= 500
    # The raw snippet is >1000 chars; truncation must be in effect.
    assert len(huge_snippet) > 500


async def test_search_skips_messages_missing_ids() -> None:
    list_resp = _response(200, {"messages": [{"id": ""}, {"no_id": True}]})
    http_mock = AsyncMock(side_effect=[list_resp])
    with patch.object(GmailConnector, "_http_get", new=http_mock):
        assert await _configured().search("q", "p") == []


async def test_search_empty_list_returns_empty() -> None:
    list_resp = _response(200, {})  # no "messages" key
    with patch.object(GmailConnector, "_http_get", new=AsyncMock(return_value=list_resp)):
        assert await _configured().search("q", "p") == []


async def test_get_item_fetches_metadata_only() -> None:
    meta = _response(
        200,
        {
            "snippet": "hi",
            "payload": {
                "headers": [
                    {"name": "Subject", "value": "Hello"},
                    {"name": "From", "value": "s@x.com"},
                ]
            },
        },
    )
    with patch.object(GmailConnector, "_http_get", new=AsyncMock(return_value=meta)):
        result = await _configured().get_item("m42", "p")
    assert result is not None
    assert result.title == "Hello"
    assert result.item_id == "m42"


async def test_get_item_none_for_empty_id() -> None:
    assert await _configured().get_item("", "p") is None


async def test_oauth_config_uses_google_endpoints() -> None:
    cfg = GmailConnector.oauth_config
    assert cfg is not None
    assert cfg.token_url == "https://oauth2.googleapis.com/token"
    assert cfg.pkce is True
    assert "access_type" in cfg.extra_authorize_params
    assert cfg.extra_authorize_params["access_type"] == "offline"
