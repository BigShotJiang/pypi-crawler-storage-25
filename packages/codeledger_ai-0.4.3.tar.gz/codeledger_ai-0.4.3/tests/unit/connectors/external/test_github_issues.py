"""Unit tests for ``backend.connectors.external.github_issues.GitHubIssuesConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.base import ConnectorStatus
from backend.connectors.external.github_issues import (
    GitHubIssuesConnector,
    _parse_issue_ref,
)


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _response(status_code: int = 200, body=None) -> MagicMock:  # type: ignore[no-untyped-def]
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body
    return r


def _configured() -> GitHubIssuesConnector:
    cm = _FakeCM()
    cm.set("connector_github_issues", "access_token", "tok")
    return GitHubIssuesConnector(cm)


# ----------------------------- _parse_issue_ref ----------------------------


def test_parse_issue_ref_valid() -> None:
    assert _parse_issue_ref("octocat/hello-world#42") == ("octocat", "hello-world", 42)


def test_parse_issue_ref_rejects_bad_inputs() -> None:
    assert _parse_issue_ref("") is None
    assert _parse_issue_ref("nohash") is None
    assert _parse_issue_ref("/#1") is None
    assert _parse_issue_ref("a/b#notnum") is None
    assert _parse_issue_ref("../evil/foo#1") is None
    assert _parse_issue_ref("a//b#1") is None
    assert _parse_issue_ref("a/b#0") is None
    assert _parse_issue_ref("a/b#-3") is None


# ----------------------------- search --------------------------------------


async def test_search_sends_user_agent_header() -> None:
    captured: dict = {}

    async def fake_get(self, url, *, params=None, headers_extra=None):  # type: ignore[no-untyped-def]
        captured["headers_extra"] = headers_extra
        return _response(200, {"items": []})

    with patch.object(GitHubIssuesConnector, "_http_get", new=fake_get):
        await _configured().search("q", "p")

    assert captured["headers_extra"]["User-Agent"] == "CodeLedger"
    assert "vnd.github" in captured["headers_extra"]["Accept"]


async def test_search_maps_issue_items() -> None:
    body = {
        "items": [
            {
                "number": 42,
                "title": "Fix login bug",
                "state": "open",
                "html_url": "https://github.com/octocat/hello/issues/42",
                "repository_url": "https://api.github.com/repos/octocat/hello",
                "labels": [{"name": "bug"}, {"name": "priority"}],
            }
        ]
    }
    with patch.object(
        GitHubIssuesConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        [r] = await _configured().search("login", "p")
    assert r.item_id == "octocat/hello#42"
    assert r.title == "#42: Fix login bug"
    assert "state=open" in r.summary
    assert "labels=bug,priority" in r.summary
    assert r.metadata["owner"] == "octocat"


async def test_search_empty_on_non_200() -> None:
    with patch.object(
        GitHubIssuesConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(500)),
    ):
        assert await _configured().search("q", "p") == []


async def test_search_skips_items_missing_number() -> None:
    body = {"items": [{"title": "no number"}, {"number": 1, "title": "ok"}]}
    with patch.object(
        GitHubIssuesConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        results = await _configured().search("q", "p")
    assert [r.title for r in results] == ["#1: ok"]


# ----------------------------- get_item ------------------------------------


async def test_get_item_valid_ref() -> None:
    body = {
        "number": 9,
        "title": "add caching",
        "state": "closed",
        "html_url": "https://github.com/o/r/issues/9",
        "repository_url": "https://api.github.com/repos/o/r",
        "labels": [],
    }
    with patch.object(
        GitHubIssuesConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        r = await _configured().get_item("o/r#9", "p")
    assert r is not None
    assert r.item_id == "o/r#9"


async def test_get_item_rejects_malformed_ref() -> None:
    conn = _configured()
    assert await conn.get_item("no slash no hash", "p") is None
    assert await conn.get_item("../evil/foo#1", "p") is None


async def test_get_item_none_when_number_missing_in_payload() -> None:
    with patch.object(
        GitHubIssuesConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, {"title": "huh"})),
    ):
        assert await _configured().get_item("o/r#1", "p") is None


# ----------------------------- health --------------------------------------


async def test_health_connected_on_200() -> None:
    with patch.object(
        GitHubIssuesConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, {"login": "alice"})),
    ):
        h = await _configured().health()
    assert h.status == ConnectorStatus.CONNECTED


async def test_health_auth_expired_on_401() -> None:
    with patch.object(
        GitHubIssuesConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(401)),
    ):
        h = await _configured().health()
    assert h.status == ConnectorStatus.AUTH_EXPIRED


def test_oauth_config_github_shape() -> None:
    cfg = GitHubIssuesConnector.oauth_config
    assert cfg is not None
    assert cfg.authorize_url == "https://github.com/login/oauth/authorize"
    assert cfg.pkce is True
    assert "repo" in cfg.scopes
