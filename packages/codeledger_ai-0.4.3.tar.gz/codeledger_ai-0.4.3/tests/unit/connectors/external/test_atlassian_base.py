"""Unit tests for ``backend.connectors.external._atlassian.AtlassianConnector``."""

from __future__ import annotations

from typing import ClassVar
from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
)
from backend.connectors.external._atlassian import (
    ACCESSIBLE_RESOURCES_URL,
    AtlassianConnector,
)
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


_CFG = ConnectorOAuthConfig(
    slug="atlq",
    authorize_url="https://auth.atlassian.com/authorize",
    token_url="https://auth.atlassian.com/oauth/token",
    scopes=[],
)


class _AtlProbe(AtlassianConnector):
    slug = "atlq"
    display_name = "Atlassian Probe"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.PROJECT_MANAGEMENT
    oauth_scopes: ClassVar[list[str]] = []
    description = "probe"
    oauth_config: ClassVar[ConnectorOAuthConfig | None] = _CFG

    async def search(self, query, project_id, max_results=10):  # type: ignore[no-untyped-def]
        return []

    async def get_item(self, item_id, project_id):  # type: ignore[no-untyped-def]
        return None


def _response(status_code: int = 200, body=None) -> MagicMock:  # type: ignore[no-untyped-def]
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body
    return r


async def test_site_info_returns_cached_values() -> None:
    cm = _FakeCM()
    cm.set("connector_atlq", "access_token", "tok")
    cm.set("connector_atlq", "cloud_id", "uuid-1")
    cm.set("connector_atlq", "site_url", "https://x.atlassian.net")
    conn = _AtlProbe(cm)

    fake_get = AsyncMock()
    with patch.object(AtlassianConnector, "_http_get", new=fake_get):
        site = await conn._site_info()

    assert site == ("uuid-1", "https://x.atlassian.net")
    fake_get.assert_not_awaited()


async def test_site_info_looks_up_and_caches_on_first_call() -> None:
    cm = _FakeCM()
    cm.set("connector_atlq", "access_token", "tok")
    body = [
        {"id": "uuid-1", "url": "https://first.atlassian.net/", "name": "First"},
        {"id": "uuid-2", "url": "https://second.atlassian.net/", "name": "Second"},
    ]

    captured: dict = {}

    async def fake_get(self, url, *, params=None, headers_extra=None):  # type: ignore[no-untyped-def]
        captured["url"] = url
        return _response(200, body)

    with patch.object(AtlassianConnector, "_http_get", new=fake_get):
        result = await _AtlProbe(cm)._site_info()

    assert result == ("uuid-1", "https://first.atlassian.net")
    assert captured["url"] == ACCESSIBLE_RESOURCES_URL
    # Trailing slash stripped
    assert cm.store[("connector_atlq", "cloud_id")] == "uuid-1"
    assert cm.store[("connector_atlq", "site_url")] == "https://first.atlassian.net"


async def test_site_info_returns_none_on_http_error() -> None:
    cm = _FakeCM()
    cm.set("connector_atlq", "access_token", "tok")
    with patch.object(
        AtlassianConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(500, None)),
    ):
        assert await _AtlProbe(cm)._site_info() is None


async def test_site_info_returns_none_on_none_response() -> None:
    cm = _FakeCM()
    cm.set("connector_atlq", "access_token", "tok")
    with patch.object(
        AtlassianConnector, "_http_get", new=AsyncMock(return_value=None)
    ):
        assert await _AtlProbe(cm)._site_info() is None


async def test_site_info_returns_none_on_empty_list() -> None:
    cm = _FakeCM()
    cm.set("connector_atlq", "access_token", "tok")
    with patch.object(
        AtlassianConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, [])),
    ):
        assert await _AtlProbe(cm)._site_info() is None


async def test_site_info_returns_none_on_malformed_entry() -> None:
    cm = _FakeCM()
    cm.set("connector_atlq", "access_token", "tok")
    with patch.object(
        AtlassianConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, [{"name": "no id or url"}])),
    ):
        assert await _AtlProbe(cm)._site_info() is None
