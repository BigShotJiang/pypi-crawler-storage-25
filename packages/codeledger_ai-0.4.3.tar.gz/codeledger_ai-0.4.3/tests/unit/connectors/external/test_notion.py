"""Unit tests for ``backend.connectors.external.notion.NotionConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.external.notion import NotionConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _response(status_code: int = 200, body=None) -> MagicMock:  # type: ignore[no-untyped-def]
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body
    return r


def _configured() -> NotionConnector:
    cm = _FakeCM()
    cm.set("connector_notion", "access_token", "tok")
    return NotionConnector(cm)


async def test_search_sends_notion_version_header() -> None:
    captured: dict = {}

    async def fake_post(
        self, url, *, json=None, data=None, params=None, headers_extra=None
    ):  # type: ignore[no-untyped-def]
        captured["headers_extra"] = headers_extra
        captured["json"] = json
        return _response(200, {"results": []})

    with patch.object(NotionConnector, "_http_post", new=fake_post):
        await _configured().search("design", "p")

    assert captured["headers_extra"]["Notion-Version"] == "2022-06-28"
    assert captured["json"]["query"] == "design"


async def test_search_parses_page_title_from_properties() -> None:
    body = {
        "results": [
            {
                "object": "page",
                "id": "page-1",
                "url": "https://notion.so/page-1",
                "last_edited_time": "2026-04-15T10:00:00Z",
                "properties": {
                    "Name": {
                        "type": "title",
                        "title": [
                            {"plain_text": "Design "},
                            {"plain_text": "Doc"},
                        ],
                    }
                },
            }
        ]
    }
    with patch.object(
        NotionConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        [r] = await _configured().search("q", "p")
    assert r.title == "Design Doc"
    assert r.item_type == "page"


async def test_search_parses_database_title_from_top_level() -> None:
    body = {
        "results": [
            {
                "object": "database",
                "id": "db-1",
                "url": "https://notion.so/db-1",
                "last_edited_time": "2026-04-10T00:00:00Z",
                "title": [{"plain_text": "Roadmap"}],
            }
        ]
    }
    with patch.object(
        NotionConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        [r] = await _configured().search("q", "p")
    assert r.title == "Roadmap"
    assert r.item_type == "database"


async def test_search_untitled_fallback() -> None:
    body = {"results": [{"object": "page", "id": "p1"}]}
    with patch.object(
        NotionConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        [r] = await _configured().search("q", "p")
    assert r.title == "(untitled)"


async def test_search_empty_on_non_200() -> None:
    with patch.object(
        NotionConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(500)),
    ):
        assert await _configured().search("q", "p") == []


async def test_get_item_rejects_traversal_id() -> None:
    conn = _configured()
    assert await conn.get_item("../admin", "p") is None
    assert await conn.get_item("pages/p1", "p") is None
    assert await conn.get_item("", "p") is None


async def test_get_item_tries_page_then_database() -> None:
    # First call: page 404. Second call: database 200.
    page_resp = _response(404, {})
    db_resp = _response(
        200,
        {
            "object": "database",
            "id": "db-1",
            "title": [{"plain_text": "Sprint"}],
        },
    )
    mock = AsyncMock(side_effect=[page_resp, db_resp])
    with patch.object(NotionConnector, "_http_get", new=mock):
        r = await _configured().get_item("db-1", "p")
    assert r is not None
    assert r.title == "Sprint"
    assert r.item_type == "database"


async def test_get_item_returns_none_when_both_endpoints_fail() -> None:
    fail = _response(404, {})
    mock = AsyncMock(side_effect=[fail, fail])
    with patch.object(NotionConnector, "_http_get", new=mock):
        assert await _configured().get_item("any", "p") is None


def test_oauth_config_notion_shape() -> None:
    cfg = NotionConnector.oauth_config
    assert cfg is not None
    assert cfg.authorize_url == "https://api.notion.com/v1/oauth/authorize"
    assert cfg.pkce is False
    assert cfg.scopes == []
