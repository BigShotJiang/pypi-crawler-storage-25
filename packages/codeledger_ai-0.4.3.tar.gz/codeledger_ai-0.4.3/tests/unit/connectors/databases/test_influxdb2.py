"""Unit tests for ``backend.connectors.databases.influxdb2.InfluxDB2Connector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from backend.connectors.databases import influxdb2 as ifx_mod
from backend.connectors.databases.influxdb2 import (
    InfluxDB2Connector,
    _escape_flux,
)


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _cm() -> _FakeCM:
    cm = _FakeCM()
    cm.set(
        "connector_influxdb2",
        "connection_string",
        '{"url": "http://h:8086", "token": "t", "org": "o", "bucket": "b"}',
    )
    return cm


def test_import_guard() -> None:
    with pytest.raises(RuntimeError, match=r"codeledger-ai\[influxdb2\]"):
        InfluxDB2Connector(_cm())


def test_class_attributes() -> None:
    assert InfluxDB2Connector.slug == "influxdb2"


def test_escape_flux_escapes_quotes_and_backslashes() -> None:
    assert _escape_flux('bucket "foo"') == r'bucket \"foo\"'
    assert _escape_flux(r"path\to\bucket") == r"path\\to\\bucket"


async def test_list_tables_returns_measurement_names() -> None:
    rec1 = MagicMock()
    rec1.get_value.return_value = "cpu"
    rec2 = MagicMock()
    rec2.get_value.return_value = "mem"
    table_obj = MagicMock()
    table_obj.records = [rec1, rec2]
    qapi = MagicMock()
    qapi.query = AsyncMock(return_value=[table_obj])
    client = MagicMock()
    client.query_api = MagicMock(return_value=qapi)
    client.close = AsyncMock()
    fake_driver = MagicMock(return_value=client)

    with (
        patch.object(ifx_mod, "_driver", fake_driver),
        patch.object(ifx_mod, "_AVAILABLE", True),
    ):
        names = await InfluxDB2Connector(_cm()).list_tables()
    assert names == ["cpu", "mem"]


async def test_list_tables_empty_without_bucket() -> None:
    cm = _FakeCM()
    cm.set(
        "connector_influxdb2",
        "connection_string",
        '{"url": "http://h", "token": "t", "org": "o"}',
    )
    with (
        patch.object(ifx_mod, "_driver", MagicMock()),
        patch.object(ifx_mod, "_AVAILABLE", True),
    ):
        assert await InfluxDB2Connector(cm).list_tables() == []
