"""Unit tests for ``backend.connectors.databases.cassandra_connector``.

Verifies the critical invariant from A-1 §1.8 risk #1: every
cassandra-driver call routes through ``run_in_executor`` so the sync
driver never blocks the MCP event loop.
"""

from __future__ import annotations

import asyncio
import time
from unittest.mock import MagicMock, patch

import pytest

from backend.connectors.databases import cassandra_connector as cas_mod
from backend.connectors.databases.cassandra_connector import CassandraConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _cm() -> _FakeCM:
    cm = _FakeCM()
    cm.set(
        "connector_cassandra",
        "connection_string",
        '{"contact_points": ["10.0.0.1"], "keyspace": "app", '
        '"username": "u", "password": "p"}',
    )
    return cm


def test_import_guard() -> None:
    with pytest.raises(RuntimeError, match=r"codeledger-ai\[cassandra\]"):
        CassandraConnector(_cm())


def test_class_attributes() -> None:
    assert CassandraConnector.slug == "cassandra"
    assert CassandraConnector.display_name == "Apache Cassandra"


async def test_list_tables_with_mocked_driver() -> None:
    row_a = MagicMock(table_name="orders")
    row_b = MagicMock(table_name="users")
    session = MagicMock()
    session.execute = MagicMock(return_value=[row_a, row_b])
    session.shutdown = MagicMock()
    cluster = MagicMock()
    cluster.connect = MagicMock(return_value=session)
    cluster.shutdown = MagicMock()

    fake_cluster_cls = MagicMock(return_value=cluster)
    fake_auth_cls = MagicMock(return_value="auth")

    with (
        patch.object(cas_mod, "_driver", fake_cluster_cls),
        patch.object(cas_mod, "_auth_cls", fake_auth_cls),
        patch.object(cas_mod, "_AVAILABLE", True),
    ):
        tables = await CassandraConnector(_cm()).list_tables()

    assert tables == ["orders", "users"]
    # Shutdown called on both session and cluster — no zombie connections
    session.shutdown.assert_called_once()
    cluster.shutdown.assert_called_once()


async def test_list_tables_empty_without_contact_points() -> None:
    cm = _FakeCM()
    cm.set(
        "connector_cassandra",
        "connection_string",
        '{"keyspace": "app"}',  # no contact_points
    )
    with (
        patch.object(cas_mod, "_driver", MagicMock()),
        patch.object(cas_mod, "_auth_cls", MagicMock()),
        patch.object(cas_mod, "_AVAILABLE", True),
    ):
        assert await CassandraConnector(cm).list_tables() == []


async def test_blocking_driver_does_not_stall_event_loop() -> None:
    """The critical A-1 §1.8 invariant: sync driver runs in executor.

    Simulate a cassandra-driver call that blocks for 400ms. Kick off a
    concurrent 10ms asyncio.sleep. If Cassandra calls ran on the loop,
    the sleep would wait ~400ms. With run_in_executor, it should finish
    in ~10-20ms.
    """
    session = MagicMock()
    cluster = MagicMock()
    cluster.connect = MagicMock(return_value=session)
    cluster.shutdown = MagicMock()
    session.shutdown = MagicMock()

    def slow_execute(*a, **kw):  # type: ignore[no-untyped-def]
        time.sleep(0.4)  # blocking call inside executor thread
        return []

    session.execute = MagicMock(side_effect=slow_execute)
    fake_cluster_cls = MagicMock(return_value=cluster)
    fake_auth_cls = MagicMock(return_value="auth")

    with (
        patch.object(cas_mod, "_driver", fake_cluster_cls),
        patch.object(cas_mod, "_auth_cls", fake_auth_cls),
        patch.object(cas_mod, "_AVAILABLE", True),
    ):
        conn = CassandraConnector(_cm())

        async def measure_sleep_latency() -> float:
            start = time.monotonic()
            await asyncio.sleep(0.01)
            return time.monotonic() - start

        list_task = asyncio.create_task(conn.list_tables())
        sleep_latency = await measure_sleep_latency()
        await list_task

    # The sleep started while the Cassandra call was running in a thread.
    # If the loop were blocked, sleep_latency would be ≥ 0.4s.
    assert sleep_latency < 0.2
