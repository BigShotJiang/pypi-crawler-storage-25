"""Unit tests for ``backend.connectors.databases.snowflake_connector``."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from backend.connectors.databases import snowflake_connector as sf_mod
from backend.connectors.databases.snowflake_connector import SnowflakeConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _cm() -> _FakeCM:
    cm = _FakeCM()
    cm.set(
        "connector_snowflake",
        "connection_string",
        '{"account": "xy12345", "user": "u", "password": "p", '
        '"database": "ANALYTICS", "schema": "PUBLIC", "warehouse": "WH"}',
    )
    return cm


def test_import_guard() -> None:
    with pytest.raises(RuntimeError, match=r"codeledger-ai\[snowflake\]"):
        SnowflakeConnector(_cm())


def test_class_attributes() -> None:
    assert SnowflakeConnector.slug == "snowflake"


async def test_list_tables_uses_information_schema() -> None:
    cursor = MagicMock()
    cursor.execute = MagicMock()
    cursor.fetchall = MagicMock(return_value=[("ORDERS",), ("USERS",)])
    cursor.close = MagicMock()
    conn = MagicMock()
    conn.cursor = MagicMock(return_value=cursor)
    conn.close = MagicMock()
    fake_driver = MagicMock()
    fake_driver.connect = MagicMock(return_value=conn)

    with (
        patch.object(sf_mod, "_driver", fake_driver),
        patch.object(sf_mod, "_AVAILABLE", True),
    ):
        tables = await SnowflakeConnector(_cm()).list_tables()

    assert tables == ["ORDERS", "USERS"]
    sql = cursor.execute.call_args.args[0]
    assert "INFORMATION_SCHEMA.TABLES" in sql
    params = cursor.execute.call_args.args[1]
    assert params == ("ANALYTICS", "PUBLIC")  # upper-cased


async def test_list_tables_empty_without_required_config() -> None:
    cm = _FakeCM()
    cm.set(
        "connector_snowflake",
        "connection_string",
        '{"account": "xy", "user": "u"}',
    )
    fake_driver = MagicMock()
    with (
        patch.object(sf_mod, "_driver", fake_driver),
        patch.object(sf_mod, "_AVAILABLE", True),
    ):
        assert await SnowflakeConnector(cm).list_tables() == []
    fake_driver.connect.assert_not_called()
