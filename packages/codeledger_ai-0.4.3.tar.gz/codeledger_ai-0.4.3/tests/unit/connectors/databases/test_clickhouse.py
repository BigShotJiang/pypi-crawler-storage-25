"""Unit tests for ``backend.connectors.databases.clickhouse_connector``."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from backend.connectors.databases import clickhouse_connector as ch_mod
from backend.connectors.databases.clickhouse_connector import (
    ClickHouseConnector,
)


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _cm() -> _FakeCM:
    cm = _FakeCM()
    cm.set(
        "connector_clickhouse",
        "connection_string",
        '{"host": "ch.local", "port": 9000, "user": "default", '
        '"password": "", "database": "default"}',
    )
    return cm


def test_import_guard() -> None:
    with pytest.raises(RuntimeError, match=r"codeledger-ai\[clickhouse\]"):
        ClickHouseConnector(_cm())


def test_class_attributes() -> None:
    assert ClickHouseConnector.slug == "clickhouse"


async def test_list_tables_uses_system_tables() -> None:
    client = MagicMock()
    client.execute = MagicMock(return_value=[("orders",), ("users",)])
    client.disconnect = MagicMock()
    fake_driver = MagicMock(return_value=client)

    with (
        patch.object(ch_mod, "_driver", fake_driver),
        patch.object(ch_mod, "_AVAILABLE", True),
    ):
        tables = await ClickHouseConnector(_cm()).list_tables()

    assert tables == ["orders", "users"]
    sql = client.execute.call_args.args[0]
    assert "system.tables" in sql
    params = client.execute.call_args.args[1]
    assert params == {"db": "default"}


async def test_list_tables_empty_without_required_config() -> None:
    cm = _FakeCM()
    cm.set(
        "connector_clickhouse",
        "connection_string",
        '{"port": 9000}',  # missing host + database
    )
    fake_driver = MagicMock()
    with (
        patch.object(ch_mod, "_driver", fake_driver),
        patch.object(ch_mod, "_AVAILABLE", True),
    ):
        assert await ClickHouseConnector(cm).list_tables() == []
    fake_driver.assert_not_called()
