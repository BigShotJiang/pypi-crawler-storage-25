"""Unit tests for ``backend.connectors.databases.timescaledb.TimescaleDBConnector``."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import asyncpg

from backend.connectors.databases.timescaledb import TimescaleDBConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _configured() -> TimescaleDBConnector:
    cm = _FakeCM()
    cm.set(
        "connector_timescaledb",
        "connection_string",
        "postgres://user:pass@host/db",
    )
    return TimescaleDBConnector(cm)


def _fake_conn(
    fetch_side_effect: list[Any] | None = None,
) -> MagicMock:
    conn = MagicMock()
    conn.fetch = AsyncMock(side_effect=fetch_side_effect or [])
    conn.fetchval = AsyncMock()
    conn.close = AsyncMock()
    return conn


async def test_slug_and_display() -> None:
    conn = _configured()
    assert conn.slug == "timescaledb"
    assert conn.display_name == "TimescaleDB"


async def test_list_tables_unions_hypertables() -> None:
    fake = _fake_conn(
        fetch_side_effect=[
            [
                {"table_name": "orders"},
                {"table_name": "events"},
                {"table_name": "metrics"},
            ]
        ]
    )
    with patch(
        "backend.connectors.databases.postgresql.asyncpg.connect",
        return_value=fake,
    ):
        tables = await _configured().list_tables()

    assert tables == ["orders", "events", "metrics"]
    # Verify the union SQL was actually used, not the vanilla pg query
    sent_sql = fake.fetch.await_args.args[0]
    assert "timescaledb_information.hypertables" in sent_sql
    assert "UNION" in sent_sql


async def test_list_tables_falls_back_when_hypertables_view_missing() -> None:
    # First attempt raises (missing view). Second attempt returns plain tables.
    first_conn = _fake_conn(
        fetch_side_effect=[asyncpg.PostgresError("relation does not exist")]
    )
    fallback_conn = _fake_conn(fetch_side_effect=[[{"table_name": "orders"}]])

    with patch(
        "backend.connectors.databases.postgresql.asyncpg.connect",
        side_effect=[first_conn, fallback_conn],
    ):
        tables = await _configured().list_tables()

    assert tables == ["orders"]
    # First conn was closed before fallback opened a new connection
    first_conn.close.assert_awaited()


async def test_list_tables_empty_when_connect_fails() -> None:
    with patch(
        "backend.connectors.databases.postgresql.asyncpg.connect",
        side_effect=OSError("no route"),
    ):
        assert await _configured().list_tables() == []
