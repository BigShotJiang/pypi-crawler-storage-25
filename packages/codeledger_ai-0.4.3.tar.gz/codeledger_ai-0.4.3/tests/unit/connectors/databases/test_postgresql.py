"""Unit tests for ``backend.connectors.databases.postgresql.PostgreSQLConnector``."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import asyncpg
import pytest

from backend.connectors.databases.postgresql import PostgreSQLConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _configured() -> PostgreSQLConnector:
    cm = _FakeCM()
    cm.set(
        "connector_postgresql",
        "connection_string",
        "postgres://user:pass@host/db",
    )
    return PostgreSQLConnector(cm)


def _fake_conn(
    fetchval_return: Any = None,
    fetch_return: list[Any] | None = None,
    fetchval_raises: Exception | None = None,
    fetch_raises: Exception | None = None,
) -> MagicMock:
    conn = MagicMock()
    if fetchval_raises:
        conn.fetchval = AsyncMock(side_effect=fetchval_raises)
    else:
        conn.fetchval = AsyncMock(return_value=fetchval_return)
    if fetch_raises:
        conn.fetch = AsyncMock(side_effect=fetch_raises)
    else:
        conn.fetch = AsyncMock(return_value=fetch_return or [])
    conn.close = AsyncMock()
    return conn


@pytest.fixture
def patch_connect():  # type: ignore[no-untyped-def]
    """Patch ``asyncpg.connect`` at the module where the connector references it."""
    with patch(
        "backend.connectors.databases.postgresql.asyncpg.connect"
    ) as mock:
        yield mock


# ----------------------- _connect -------------------------------------- #


async def test_connect_returns_none_without_dsn(patch_connect) -> None:  # type: ignore[no-untyped-def]
    cm = _FakeCM()
    conn = PostgreSQLConnector(cm)
    assert await conn._connect() is None
    patch_connect.assert_not_called()


async def test_connect_handles_asyncpg_error(patch_connect) -> None:  # type: ignore[no-untyped-def]
    patch_connect.side_effect = asyncpg.PostgresError("nope")
    assert await _configured()._connect() is None


async def test_connect_handles_network_error(patch_connect) -> None:  # type: ignore[no-untyped-def]
    patch_connect.side_effect = OSError("no route")
    assert await _configured()._connect() is None


async def test_connect_handles_timeout(patch_connect) -> None:  # type: ignore[no-untyped-def]
    patch_connect.side_effect = TimeoutError()
    assert await _configured()._connect() is None


# ----------------------- test_connection ------------------------------- #


async def test_test_connection_true_on_select_1(patch_connect) -> None:  # type: ignore[no-untyped-def]
    fake = _fake_conn(fetchval_return=1)
    patch_connect.return_value = fake
    assert await _configured().test_connection() is True
    fake.close.assert_awaited()


async def test_test_connection_false_when_select_returns_other(patch_connect) -> None:  # type: ignore[no-untyped-def]
    patch_connect.return_value = _fake_conn(fetchval_return=0)
    assert await _configured().test_connection() is False


async def test_test_connection_false_on_pg_error(patch_connect) -> None:  # type: ignore[no-untyped-def]
    patch_connect.return_value = _fake_conn(
        fetchval_raises=asyncpg.PostgresError("query failed")
    )
    assert await _configured().test_connection() is False


async def test_test_connection_false_when_connect_none(patch_connect) -> None:  # type: ignore[no-untyped-def]
    patch_connect.side_effect = OSError("down")
    assert await _configured().test_connection() is False


# ----------------------- list_tables ----------------------------------- #


async def test_list_tables_returns_names_in_order(patch_connect) -> None:  # type: ignore[no-untyped-def]
    patch_connect.return_value = _fake_conn(
        fetch_return=[
            {"table_name": "alpha"},
            {"table_name": "beta"},
        ]
    )
    assert await _configured().list_tables() == ["alpha", "beta"]


async def test_list_tables_empty_on_pg_error(patch_connect) -> None:  # type: ignore[no-untyped-def]
    patch_connect.return_value = _fake_conn(
        fetch_raises=asyncpg.PostgresError("schema denied")
    )
    assert await _configured().list_tables() == []


# ----------------------- describe_table -------------------------------- #


async def test_describe_table_rejects_unknown(patch_connect) -> None:  # type: ignore[no-untyped-def]
    # First call (list_tables) returns only "users"; describe_table is asked
    # about "secret_table" which isn't there, so the validation gate fires.
    patch_connect.return_value = _fake_conn(
        fetch_return=[{"table_name": "users"}]
    )
    assert await _configured().describe_table("secret_table") == {"columns": []}


async def test_describe_table_returns_columns_for_known(patch_connect) -> None:  # type: ignore[no-untyped-def]
    # _validate_table runs list_tables, then describe_table runs its own fetch.
    # Use side_effect to return the correct thing for each invocation.
    conn = MagicMock()
    conn.fetch = AsyncMock(
        side_effect=[
            [{"table_name": "users"}],  # list_tables
            [
                {"column_name": "id", "data_type": "integer"},
                {"column_name": "email", "data_type": "text"},
            ],  # describe_table
        ]
    )
    conn.close = AsyncMock()
    patch_connect.return_value = conn
    result = await _configured().describe_table("users")
    assert result == {
        "columns": [
            {"name": "id", "type": "integer"},
            {"name": "email", "type": "text"},
        ]
    }


# ----------------------- sample_rows ----------------------------------- #


async def test_sample_rows_rejects_bad_limit(patch_connect) -> None:  # type: ignore[no-untyped-def]
    conn = _configured()
    assert await conn.sample_rows("users", limit=0) == []
    assert await conn.sample_rows("users", limit=-1) == []
    assert await conn.sample_rows("users", limit=10_000) == []
    patch_connect.assert_not_called()


async def test_sample_rows_rejects_unknown_table(patch_connect) -> None:  # type: ignore[no-untyped-def]
    # _validate_table calls list_tables once.
    patch_connect.return_value = _fake_conn(
        fetch_return=[{"table_name": "users"}]
    )
    # "evil_table" is not in the whitelist → refuse without executing SELECT
    assert await _configured().sample_rows("evil_table", limit=5) == []


async def test_sample_rows_returns_rows_for_valid_table(patch_connect) -> None:  # type: ignore[no-untyped-def]
    conn = MagicMock()
    conn.fetch = AsyncMock(
        side_effect=[
            [{"table_name": "users"}],  # list_tables during _validate_table
            [{"id": 1, "email": "a@x"}, {"id": 2, "email": "b@x"}],  # real sample
        ]
    )
    conn.close = AsyncMock()
    patch_connect.return_value = conn
    rows = await _configured().sample_rows("users", limit=2)
    assert rows == [{"id": 1, "email": "a@x"}, {"id": 2, "email": "b@x"}]
    # Second call should have used the SELECT * FROM "users" LIMIT $1 pattern
    sample_call = conn.fetch.await_args_list[1]
    sql = sample_call.args[0]
    assert 'SELECT * FROM "users"' in sql
    assert sample_call.args[1] == 2
