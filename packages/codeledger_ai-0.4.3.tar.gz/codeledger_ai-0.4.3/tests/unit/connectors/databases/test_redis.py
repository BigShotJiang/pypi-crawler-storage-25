"""Unit tests for ``backend.connectors.databases.redis_connector.RedisConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from backend.connectors.databases import redis_connector as redis_mod
from backend.connectors.databases.redis_connector import (
    RedisConnector,
    _truncate,
)


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _cm() -> _FakeCM:
    cm = _FakeCM()
    cm.set(
        "connector_redis",
        "connection_string",
        "redis://host:6379/0",
    )
    return cm


def test_import_guard() -> None:
    with pytest.raises(RuntimeError, match=r"codeledger-ai\[redis-connector\]"):
        RedisConnector(_cm())


def test_class_attributes() -> None:
    assert RedisConnector.slug == "redis"


def test_truncate_bounds_value() -> None:
    assert _truncate("x" * 1000).endswith("…")
    assert len(_truncate("x" * 1000)) == 501  # 500 chars + "…"
    assert _truncate("short") == "short"
    assert _truncate(None) == ""


async def test_test_connection_true_on_pong() -> None:
    client = MagicMock()
    client.ping = AsyncMock(return_value=True)
    client.aclose = AsyncMock()
    fake_driver = MagicMock()
    fake_driver.from_url = MagicMock(return_value=client)
    with (
        patch.object(redis_mod, "_driver", fake_driver),
        patch.object(redis_mod, "_AVAILABLE", True),
    ):
        assert await RedisConnector(_cm()).test_connection() is True


async def test_test_connection_false_when_ping_raises() -> None:
    client = MagicMock()
    client.ping = AsyncMock(side_effect=OSError("conn lost"))
    client.aclose = AsyncMock()
    fake_driver = MagicMock()
    fake_driver.from_url = MagicMock(return_value=client)
    with (
        patch.object(redis_mod, "_driver", fake_driver),
        patch.object(redis_mod, "_AVAILABLE", True),
    ):
        assert await RedisConnector(_cm()).test_connection() is False
