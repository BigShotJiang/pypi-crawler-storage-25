"""Unit tests for ``backend.connectors.databases.mongodb.MongoDBConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from backend.connectors.databases import mongodb as mongo_mod
from backend.connectors.databases.mongodb import MongoDBConnector, _sanitize_doc


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _cm() -> _FakeCM:
    cm = _FakeCM()
    cm.set(
        "connector_mongodb",
        "connection_string",
        "mongodb://u:p@host:27017/app",
    )
    return cm


def test_import_guard() -> None:
    with pytest.raises(RuntimeError, match=r"codeledger-ai\[mongodb\]"):
        MongoDBConnector(_cm())


def test_class_attributes() -> None:
    assert MongoDBConnector.slug == "mongodb"
    assert MongoDBConnector.display_name == "MongoDB"


def test_sanitize_doc_converts_objectid() -> None:
    # Match by class name "ObjectId" — that's how _sanitize_doc detects it.
    object_id_cls = type(
        "ObjectId", (), {"__str__": lambda self: "64abc"}
    )
    out = _sanitize_doc({"_id": object_id_cls(), "name": "alice"})
    assert out["_id"] == "64abc"
    assert out["name"] == "alice"


async def test_list_tables_with_mocked_driver() -> None:
    db_handle = MagicMock()
    db_handle.list_collection_names = AsyncMock(return_value=["users", "orders"])
    client = MagicMock()
    client.get_default_database = MagicMock(return_value=db_handle)
    client.close = MagicMock()

    fake_driver = MagicMock()
    fake_driver.AsyncIOMotorClient = MagicMock(return_value=client)

    with (
        patch.object(mongo_mod, "_driver", fake_driver),
        patch.object(mongo_mod, "_AVAILABLE", True),
    ):
        tables = await MongoDBConnector(_cm()).list_tables()
    assert tables == ["users", "orders"]


async def test_list_tables_empty_when_connect_raises() -> None:
    fake_driver = MagicMock()
    fake_driver.AsyncIOMotorClient = MagicMock(side_effect=OSError("no route"))
    with (
        patch.object(mongo_mod, "_driver", fake_driver),
        patch.object(mongo_mod, "_AVAILABLE", True),
    ):
        assert await MongoDBConnector(_cm()).list_tables() == []
