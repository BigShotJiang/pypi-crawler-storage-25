"""Unit tests for ``backend.connectors.databases._base.AbstractDatabaseConnector``."""

from __future__ import annotations

from typing import Any

import pytest

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorStatus,
)
from backend.connectors.databases._base import AbstractDatabaseConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


class _StubDB(AbstractDatabaseConnector):
    """Concrete subclass with canned driver responses."""

    slug = "stub"
    display_name = "Stub DB"
    description = "stub"

    def __init__(
        self,
        cm: _FakeCM,
        *,
        tables: list[str] | None = None,
        describe: dict[str, dict[str, Any]] | None = None,
        rows: dict[str, list[dict[str, Any]]] | None = None,
        connection_ok: bool = True,
        list_tables_raises: Exception | None = None,
        describe_raises: Exception | None = None,
        sample_raises: Exception | None = None,
        test_raises: Exception | None = None,
    ) -> None:
        super().__init__(cm)
        self._tables = tables or []
        self._describe = describe or {}
        self._rows = rows or {}
        self._connection_ok = connection_ok
        self._list_tables_raises = list_tables_raises
        self._describe_raises = describe_raises
        self._sample_raises = sample_raises
        self._test_raises = test_raises

    async def test_connection(self) -> bool:
        if self._test_raises:
            raise self._test_raises
        return self._connection_ok

    async def list_tables(self) -> list[str]:
        if self._list_tables_raises:
            raise self._list_tables_raises
        return list(self._tables)

    async def describe_table(self, table: str) -> dict[str, Any]:
        if self._describe_raises:
            raise self._describe_raises
        return self._describe.get(table, {"columns": []})

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if self._sample_raises:
            raise self._sample_raises
        return list(self._rows.get(table, []))[:limit]


def _cm_with_conn_string() -> _FakeCM:
    cm = _FakeCM()
    cm.set("connector_stub", "connection_string", "postgres://x")
    return cm


# ----------------------- class attributes ------------------------------ #


def test_default_auth_type_and_category() -> None:
    cm = _cm_with_conn_string()
    conn = _StubDB(cm)
    assert conn.auth_type == AuthType.CONNECTION_STRING
    assert conn.category == ConnectorCategory.DATABASE
    assert conn.write_allowed is False


# ----------------------- health ---------------------------------------- #


async def test_health_not_configured_without_connection_string() -> None:
    cm = _FakeCM()
    h = await _StubDB(cm).health()
    assert h.status == ConnectorStatus.NOT_CONFIGURED
    assert h.configured is False


async def test_health_connected_when_test_connection_true() -> None:
    conn = _StubDB(_cm_with_conn_string(), connection_ok=True)
    h = await conn.health()
    assert h.status == ConnectorStatus.CONNECTED


async def test_health_error_when_test_connection_false() -> None:
    conn = _StubDB(_cm_with_conn_string(), connection_ok=False)
    h = await conn.health()
    assert h.status == ConnectorStatus.ERROR
    assert "failed" in h.message


async def test_health_error_when_test_connection_raises() -> None:
    conn = _StubDB(
        _cm_with_conn_string(),
        test_raises=RuntimeError("boom"),
    )
    h = await conn.health()
    assert h.status == ConnectorStatus.ERROR


# ----------------------- search ---------------------------------------- #


async def test_search_matches_substring_case_insensitive() -> None:
    conn = _StubDB(
        _cm_with_conn_string(),
        tables=["Users", "Orders", "products"],
        describe={
            "Users": {"columns": [{"name": "id"}, {"name": "email"}]},
            "Orders": {"columns": [{"name": "id"}]},
            "products": {"columns": [{"name": "sku"}]},
        },
    )
    results = await conn.search("user", "p")
    assert [r.title for r in results] == ["Users"]


async def test_search_empty_query_returns_all_tables_capped() -> None:
    conn = _StubDB(
        _cm_with_conn_string(),
        tables=[f"t{i}" for i in range(15)],
    )
    results = await conn.search("", "p", max_results=5)
    assert len(results) == 5


async def test_search_sets_perfect_relevance_on_exact_match() -> None:
    conn = _StubDB(
        _cm_with_conn_string(),
        tables=["orders", "order_items"],
        describe={"orders": {"columns": []}, "order_items": {"columns": []}},
    )
    # "order" is a substring of both; only "orders" is an exact match of the
    # query word used for the relevance boost.
    results = await conn.search("order", "p")
    by_title = {r.title: r for r in results}
    assert by_title["orders"].relevance_score == 0.5
    assert by_title["order_items"].relevance_score == 0.5

    # Exact-match case bumps relevance to 1.0.
    [exact] = await conn.search("orders", "p")
    assert exact.relevance_score == 1.0


async def test_search_columns_preview_and_ellipsis() -> None:
    conn = _StubDB(
        _cm_with_conn_string(),
        tables=["big"],
        describe={
            "big": {
                "columns": [{"name": f"c{i}"} for i in range(12)]
            }
        },
    )
    [r] = await conn.search("big", "p")
    assert "12 columns" in r.summary
    assert "c0" in r.summary
    assert r.summary.endswith("…")
    assert r.metadata["column_count"] == 12


async def test_search_empty_when_list_tables_raises() -> None:
    conn = _StubDB(
        _cm_with_conn_string(),
        list_tables_raises=RuntimeError("db down"),
    )
    assert await conn.search("q", "p") == []


async def test_search_continues_when_describe_raises_for_a_table() -> None:
    conn = _StubDB(
        _cm_with_conn_string(),
        tables=["a", "b"],
        describe_raises=RuntimeError("bad describe"),
    )
    results = await conn.search("", "p")
    # Both tables still appear with column_count=0
    assert sorted(r.title for r in results) == ["a", "b"]
    assert all(r.metadata["column_count"] == 0 for r in results)


# ----------------------- get_item -------------------------------------- #


async def test_get_item_bad_formats_return_none() -> None:
    conn = _StubDB(_cm_with_conn_string(), tables=["users"])
    assert await conn.get_item("", "p") is None
    assert await conn.get_item("no-scheme", "p") is None
    assert await conn.get_item("other::users", "p") is None  # wrong slug
    assert await conn.get_item("stub::", "p") is None


async def test_get_item_rejects_unknown_table() -> None:
    conn = _StubDB(_cm_with_conn_string(), tables=["users"])
    assert await conn.get_item("stub::secret", "p") is None


async def test_get_item_returns_sample_summary() -> None:
    conn = _StubDB(
        _cm_with_conn_string(),
        tables=["users"],
        describe={
            "users": {
                "columns": [{"name": "id"}, {"name": "email"}]
            }
        },
        rows={"users": [{"id": 1, "email": "a@x"}]},
    )
    r = await conn.get_item("stub::users", "p")
    assert r is not None
    assert r.title == "users"
    assert "2 columns" in r.summary
    assert "Sample:" in r.summary
    assert r.metadata["column_count"] == 2
    assert r.metadata["sample_count"] == 1


async def test_get_item_handles_empty_table() -> None:
    conn = _StubDB(
        _cm_with_conn_string(),
        tables=["empty"],
        describe={"empty": {"columns": [{"name": "c1"}]}},
        rows={"empty": []},
    )
    r = await conn.get_item("stub::empty", "p")
    assert r is not None
    assert "(empty table)" in r.summary


async def test_get_item_none_when_sample_raises() -> None:
    conn = _StubDB(
        _cm_with_conn_string(),
        tables=["users"],
        describe={"users": {"columns": []}},
        sample_raises=RuntimeError("permission denied"),
    )
    assert await conn.get_item("stub::users", "p") is None


# ----------------------- _validate_table -------------------------------- #


@pytest.mark.parametrize("bad", ["", None, 123, 0])
async def test_validate_table_rejects_non_strings_and_empty(bad: Any) -> None:
    conn = _StubDB(_cm_with_conn_string(), tables=["users"])
    assert await conn._validate_table(bad) is False  # type: ignore[arg-type]


async def test_validate_table_false_on_list_tables_error() -> None:
    conn = _StubDB(
        _cm_with_conn_string(),
        list_tables_raises=RuntimeError("x"),
    )
    assert await conn._validate_table("users") is False


# ----------------------- get_schema_summary ---------------------------- #


async def test_get_schema_summary_caps_tables_and_columns() -> None:
    tables = [f"t{i}" for i in range(25)]
    describe = {
        t: {"columns": [{"name": f"c{i}"} for i in range(15)]}
        for t in tables
    }
    conn = _StubDB(
        _cm_with_conn_string(),
        tables=tables,
        describe=describe,
    )
    snap = await conn.get_schema_summary()
    assert len(snap["tables"]) == 20
    assert len(snap["tables"][0]["columns"]) == 10


async def test_get_schema_summary_empty_on_list_tables_error() -> None:
    conn = _StubDB(
        _cm_with_conn_string(),
        list_tables_raises=RuntimeError("down"),
    )
    assert await conn.get_schema_summary() == {"tables": []}
