"""Unit tests for ``backend.connectors.databases.elasticsearch_connector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from backend.connectors.databases import (
    elasticsearch_connector as es_mod,
)
from backend.connectors.databases.elasticsearch_connector import (
    ElasticsearchConnector,
)


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _cm() -> _FakeCM:
    cm = _FakeCM()
    cm.set(
        "connector_elasticsearch",
        "connection_string",
        '{"hosts": ["https://es:9200"], "api_key": "k"}',
    )
    return cm


def test_import_guard() -> None:
    with pytest.raises(
        RuntimeError, match=r"codeledger-ai\[elasticsearch\]"
    ):
        ElasticsearchConnector(_cm())


def test_class_attributes() -> None:
    assert ElasticsearchConnector.slug == "elasticsearch"


async def test_list_tables_with_mocked_driver() -> None:
    client = MagicMock()
    client.cat = MagicMock()
    client.cat.indices = AsyncMock(
        return_value=[{"index": "users"}, {"index": "orders"}]
    )
    client.close = AsyncMock()
    fake_driver = MagicMock(return_value=client)

    with (
        patch.object(es_mod, "_driver", fake_driver),
        patch.object(es_mod, "_AVAILABLE", True),
    ):
        tables = await ElasticsearchConnector(_cm()).list_tables()
    assert tables == ["users", "orders"]


async def test_list_tables_empty_without_hosts() -> None:
    cm = _FakeCM()
    cm.set(
        "connector_elasticsearch",
        "connection_string",
        '{"api_key": "k"}',
    )
    fake_driver = MagicMock()
    with (
        patch.object(es_mod, "_driver", fake_driver),
        patch.object(es_mod, "_AVAILABLE", True),
    ):
        assert await ElasticsearchConnector(cm).list_tables() == []
    fake_driver.assert_not_called()


async def test_list_tables_empty_on_malformed_config() -> None:
    cm = _FakeCM()
    cm.set("connector_elasticsearch", "connection_string", "not json")
    fake_driver = MagicMock()
    with (
        patch.object(es_mod, "_driver", fake_driver),
        patch.object(es_mod, "_AVAILABLE", True),
    ):
        assert await ElasticsearchConnector(cm).list_tables() == []
