"""Unit tests for ``backend.connectors.databases.influxdb3.InfluxDB3Connector``."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from backend.connectors.databases import influxdb3 as ifx3_mod
from backend.connectors.databases.influxdb3 import (
    InfluxDB3Connector,
    _column_to_list,
    _rows_from_result,
)


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _cm() -> _FakeCM:
    cm = _FakeCM()
    cm.set(
        "connector_influxdb3",
        "connection_string",
        '{"host": "https://h", "token": "t", "database": "d"}',
    )
    return cm


def test_import_guard() -> None:
    with pytest.raises(RuntimeError, match=r"codeledger-ai\[influxdb3\]"):
        InfluxDB3Connector(_cm())


def test_class_attributes() -> None:
    assert InfluxDB3Connector.slug == "influxdb3"


def test_rows_from_arrow_table_via_to_pylist() -> None:
    arrow_table = MagicMock()
    arrow_table.to_pylist.return_value = [{"a": 1}, {"a": 2}, "bad"]
    rows = _rows_from_result(arrow_table)
    assert rows == [{"a": 1}, {"a": 2}]


def test_rows_from_plain_list() -> None:
    assert _rows_from_result([{"a": 1}, "bad"]) == [{"a": 1}]


def test_rows_from_none_returns_empty() -> None:
    assert _rows_from_result(None) == []


def test_column_to_list_filters_empty_values() -> None:
    result = MagicMock()
    result.to_pylist.return_value = [
        {"table_name": "cpu"},
        {"table_name": ""},
        {"other": "x"},
        {"table_name": "mem"},
    ]
    assert _column_to_list(result, "table_name") == ["cpu", "mem"]


async def test_list_tables_issues_sql_query_not_flux() -> None:
    arrow = MagicMock()
    arrow.to_pylist.return_value = [
        {"table_name": "cpu"},
        {"table_name": "mem"},
    ]
    client = MagicMock()
    client.query.return_value = arrow
    client.close = MagicMock()
    fake_driver = MagicMock(return_value=client)

    with (
        patch.object(ifx3_mod, "_driver", fake_driver),
        patch.object(ifx3_mod, "_AVAILABLE", True),
    ):
        tables = await InfluxDB3Connector(_cm()).list_tables()
    assert tables == ["cpu", "mem"]
    # Critical: InfluxDB 3 dropped Flux. Ensure language="sql".
    call_kwargs = client.query.call_args.kwargs
    assert call_kwargs.get("language") == "sql"
    call_sql = client.query.call_args.args[0]
    assert "information_schema" in call_sql
