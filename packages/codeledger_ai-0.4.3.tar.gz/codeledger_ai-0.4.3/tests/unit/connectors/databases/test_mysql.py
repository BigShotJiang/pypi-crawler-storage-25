"""Unit tests for ``backend.connectors.databases.mysql.MySQLConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from backend.connectors.base import AuthType, ConnectorCategory
from backend.connectors.databases import mysql as mysql_mod
from backend.connectors.databases.mysql import MySQLConnector, _parse_dsn


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _cm() -> _FakeCM:
    cm = _FakeCM()
    cm.set("connector_mysql", "connection_string", "mysql://u:p@host:3306/db")
    return cm


# ----------------------- import guard ---------------------------------- #


def test_import_guard_raises_runtime_error_when_driver_missing() -> None:
    # aiomysql is not installed in the test env → construction must refuse.
    with pytest.raises(RuntimeError, match=r"codeledger-ai\[mysql\]"):
        MySQLConnector(_cm())


# ----------------------- class attributes ------------------------------ #


def test_class_attributes() -> None:
    # These are readable without instantiation.
    assert MySQLConnector.slug == "mysql"
    assert MySQLConnector.display_name == "MySQL / MariaDB"
    assert MySQLConnector.auth_type == AuthType.CONNECTION_STRING
    assert MySQLConnector.category == ConnectorCategory.DATABASE


# ----------------------- DSN parsing ----------------------------------- #


def test_parse_dsn_valid() -> None:
    parsed = _parse_dsn("mysql://alice:pw@db.example:3307/orders")
    assert parsed == {
        "host": "db.example",
        "port": 3307,
        "user": "alice",
        "password": "pw",
        "db": "orders",
    }


def test_parse_dsn_default_port() -> None:
    parsed = _parse_dsn("mysql://u:p@host/db")
    assert parsed is not None
    assert parsed["port"] == 3306


def test_parse_dsn_url_decodes_credentials() -> None:
    parsed = _parse_dsn("mysql://user%40x:p%2Fw@host/db")
    assert parsed is not None
    assert parsed["user"] == "user@x"
    assert parsed["password"] == "p/w"


@pytest.mark.parametrize(
    "bad",
    [
        "",
        "postgres://u:p@h/d",  # wrong scheme
        "mysql://h/",  # no db
        "mysql://",  # no host
        "mariadb://h",  # no db
        "not a url at all",
    ],
)
def test_parse_dsn_rejects_bad(bad: str) -> None:
    # urlparse generally doesn't raise — invalid shapes return None.
    assert _parse_dsn(bad) is None


def test_parse_dsn_accepts_mariadb_scheme() -> None:
    assert _parse_dsn("mariadb://u:p@h/d") is not None


# ----------------------- happy path with mocked driver ----------------- #


async def test_list_tables_with_mocked_driver() -> None:
    cm = _cm()
    cursor = MagicMock()
    cursor.execute = AsyncMock()
    cursor.fetchall = AsyncMock(return_value=[("users",), ("orders",)])
    cursor_cm = MagicMock()
    cursor_cm.__aenter__ = AsyncMock(return_value=cursor)
    cursor_cm.__aexit__ = AsyncMock(return_value=False)
    conn = MagicMock()
    conn.cursor = MagicMock(return_value=cursor_cm)
    conn.close = MagicMock()

    fake_driver = MagicMock()
    fake_driver.connect = AsyncMock(return_value=conn)

    with (
        patch.object(mysql_mod, "_driver", fake_driver),
        patch.object(mysql_mod, "_AVAILABLE", True),
    ):
        tables = await MySQLConnector(cm).list_tables()

    assert tables == ["users", "orders"]
    # Verify the DSN parts made it to the driver
    connect_call = fake_driver.connect.await_args.kwargs
    assert connect_call["host"] == "host"
    assert connect_call["db"] == "db"


async def test_sample_rows_rejects_bad_limit_without_driver_call() -> None:
    cm = _cm()
    fake_driver = MagicMock()
    fake_driver.connect = AsyncMock()
    with (
        patch.object(mysql_mod, "_driver", fake_driver),
        patch.object(mysql_mod, "_AVAILABLE", True),
    ):
        assert await MySQLConnector(cm).sample_rows("any", limit=0) == []
        assert await MySQLConnector(cm).sample_rows("any", limit=10_000) == []
    fake_driver.connect.assert_not_called()
