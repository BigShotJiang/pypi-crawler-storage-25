"""Unit tests for ``backend.connectors.registry``."""

from __future__ import annotations

import asyncio

from backend.connectors.base import (
    AbstractConnector,
    AuthType,
    ConnectorCategory,
    ConnectorHealth,
    ConnectorResult,
    ConnectorStatus,
)
from backend.connectors.registry import ConnectorRegistry


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


class _BaseStub(AbstractConnector):
    """Configurable connector stub used throughout these tests."""

    display_name = "Stub"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.COMMUNICATION
    description = "stub connector"

    def __init__(
        self,
        cm: _FakeCM,
        *,
        slug: str,
        configured: bool = True,
        search_result: list[ConnectorResult] | None = None,
        search_delay: float = 0.0,
        search_raises: Exception | None = None,
        health_result: ConnectorHealth | None = None,
        health_raises: Exception | None = None,
        is_configured_raises: Exception | None = None,
    ) -> None:
        super().__init__(cm)
        self.slug = slug
        self._configured = configured
        self._search_result = search_result or []
        self._search_delay = search_delay
        self._search_raises = search_raises
        self._health_result = health_result or ConnectorHealth(
            slug=slug,
            status=ConnectorStatus.CONNECTED,
            message="ok",
            configured=configured,
        )
        self._health_raises = health_raises
        self._is_configured_raises = is_configured_raises

    def is_configured(self) -> bool:
        if self._is_configured_raises:
            raise self._is_configured_raises
        return self._configured

    async def health(self) -> ConnectorHealth:
        if self._health_raises:
            raise self._health_raises
        return self._health_result

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        if self._search_delay:
            await asyncio.sleep(self._search_delay)
        if self._search_raises:
            raise self._search_raises
        return self._search_result

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        return None


def _result(slug: str, score: float, title: str = "t") -> ConnectorResult:
    return ConnectorResult(
        item_id=f"{slug}-{title}",
        title=title,
        summary="",
        url=None,
        connector_slug=slug,
        item_type="doc",
        relevance_score=score,
    )


# ----------------------------- registration ---------------------------- #


def test_register_and_get_roundtrip() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    stub = _BaseStub(cm, slug="a")
    reg.register(stub)
    assert reg.get("a") is stub
    assert reg.get("missing") is None


def test_register_replaces_duplicate_slug() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    first = _BaseStub(cm, slug="a")
    second = _BaseStub(cm, slug="a")
    reg.register(first)
    reg.register(second)
    assert reg.get("a") is second
    assert len(reg.all()) == 1


def test_all_returns_registered_connectors_in_order() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    a = _BaseStub(cm, slug="a")
    b = _BaseStub(cm, slug="b")
    reg.register(a)
    reg.register(b)
    assert reg.all() == [a, b]


def test_configured_filters_unconfigured() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_BaseStub(cm, slug="on", configured=True))
    reg.register(_BaseStub(cm, slug="off", configured=False))
    slugs = [c.slug for c in reg.configured()]
    assert slugs == ["on"]


def test_configured_tolerates_is_configured_raising() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(
        _BaseStub(cm, slug="broken", is_configured_raises=RuntimeError("boom"))
    )
    reg.register(_BaseStub(cm, slug="ok", configured=True))
    slugs = [c.slug for c in reg.configured()]
    assert slugs == ["ok"]


# ----------------------------- health_all ------------------------------ #


async def test_health_all_returns_entry_per_connector() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_BaseStub(cm, slug="a"))
    reg.register(_BaseStub(cm, slug="b"))
    healths = await reg.health_all()
    assert sorted(h.slug for h in healths) == ["a", "b"]
    assert all(h.status == ConnectorStatus.CONNECTED for h in healths)


async def test_health_all_isolates_connector_exception() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_BaseStub(cm, slug="bad", health_raises=RuntimeError("down")))
    reg.register(_BaseStub(cm, slug="good"))
    healths = {h.slug: h for h in await reg.health_all()}
    assert healths["bad"].status == ConnectorStatus.ERROR
    assert "RuntimeError" in healths["bad"].message
    assert healths["good"].status == ConnectorStatus.CONNECTED


async def test_health_all_isolates_slow_connector_with_timeout() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry(timeout=0.05)

    class _SlowHealth(_BaseStub):
        async def health(self) -> ConnectorHealth:  # type: ignore[override]
            await asyncio.sleep(1.0)
            return self._health_result

    reg.register(_SlowHealth(cm, slug="slow"))
    reg.register(_BaseStub(cm, slug="fast"))
    healths = {h.slug: h for h in await reg.health_all()}
    assert healths["slow"].status == ConnectorStatus.ERROR
    assert "timed out" in healths["slow"].message
    assert healths["fast"].status == ConnectorStatus.CONNECTED


async def test_health_all_empty_registry_returns_empty_list() -> None:
    assert await ConnectorRegistry().health_all() == []


# ----------------------------- search_all ------------------------------ #


async def test_search_all_empty_when_nothing_configured() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_BaseStub(cm, slug="a", configured=False))
    assert await reg.search_all("q", "p") == []


async def test_search_all_merges_and_sorts_by_relevance() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(
        _BaseStub(
            cm,
            slug="a",
            search_result=[_result("a", 0.3), _result("a", 0.9)],
        )
    )
    reg.register(
        _BaseStub(cm, slug="b", search_result=[_result("b", 0.5)])
    )
    merged = await reg.search_all("q", "p")
    scores = [r.relevance_score for r in merged]
    assert scores == [0.9, 0.5, 0.3]


async def test_search_all_restricts_to_connector_slugs() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_BaseStub(cm, slug="a", search_result=[_result("a", 0.9)]))
    reg.register(_BaseStub(cm, slug="b", search_result=[_result("b", 0.5)]))
    merged = await reg.search_all("q", "p", connector_slugs=["b"])
    assert [r.connector_slug for r in merged] == ["b"]


async def test_search_all_timeout_isolates_one_connector() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry(timeout=0.05)
    reg.register(
        _BaseStub(
            cm,
            slug="slow",
            search_delay=1.0,
            search_result=[_result("slow", 0.9)],
        )
    )
    reg.register(
        _BaseStub(cm, slug="fast", search_result=[_result("fast", 0.5)])
    )
    merged = await reg.search_all("q", "p")
    # Slow one timed out → returns []; fast one made it through.
    assert [r.connector_slug for r in merged] == ["fast"]


async def test_search_all_exception_isolates_one_connector() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(
        _BaseStub(
            cm, slug="crash", search_raises=RuntimeError("kaboom")
        )
    )
    reg.register(
        _BaseStub(cm, slug="fine", search_result=[_result("fine", 0.5)])
    )
    merged = await reg.search_all("q", "p")
    assert [r.connector_slug for r in merged] == ["fine"]


async def test_search_all_skips_unconfigured_connectors() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(
        _BaseStub(
            cm,
            slug="off",
            configured=False,
            search_result=[_result("off", 0.99)],
        )
    )
    reg.register(
        _BaseStub(cm, slug="on", search_result=[_result("on", 0.1)])
    )
    merged = await reg.search_all("q", "p")
    assert [r.connector_slug for r in merged] == ["on"]


# ----------------------------- dashboard_status ------------------------ #


def test_dashboard_status_shape_for_oauth_connector() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_BaseStub(cm, slug="gmail"))
    [entry] = reg.dashboard_status()
    assert entry == {
        "slug": "gmail",
        "display_name": "Stub",
        "category": "communication",
        "description": "stub connector",
        "auth_type": "oauth2",
        "configured": True,
        "connect_url": "/api/connectors/gmail/connect",
    }


def test_dashboard_status_connect_url_none_for_non_oauth() -> None:
    cm = _FakeCM()

    class _ApiKeyConn(_BaseStub):
        auth_type = AuthType.API_KEY
        category = ConnectorCategory.DATABASE

    reg = ConnectorRegistry()
    reg.register(_ApiKeyConn(cm, slug="influx"))
    [entry] = reg.dashboard_status()
    assert entry["auth_type"] == "api_key"
    assert entry["connect_url"] is None


def test_dashboard_status_tolerates_is_configured_raising() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(
        _BaseStub(
            cm, slug="broken", is_configured_raises=RuntimeError("boom")
        )
    )
    [entry] = reg.dashboard_status()
    assert entry["configured"] is False
