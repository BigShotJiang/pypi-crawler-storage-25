"""Unit tests for ``backend.connectors.base``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from backend.connectors.base import (
    MAX_SUMMARY_CHARS,
    AbstractConnector,
    AuthType,
    ConnectorCategory,
    ConnectorHealth,
    ConnectorResult,
    ConnectorStatus,
)


class _ConcreteConnector(AbstractConnector):
    """Minimal concrete subclass used to test the non-abstract surface."""

    slug = "fake"
    display_name = "Fake"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.COMMUNICATION

    async def health(self) -> ConnectorHealth:
        return ConnectorHealth(
            slug=self.slug,
            status=ConnectorStatus.CONNECTED,
            message="ok",
            configured=True,
        )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        return []

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        return None


class _FakeCM:
    """In-memory stand-in for :class:`CredentialManager`."""

    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def test_abstract_connector_cannot_be_instantiated() -> None:
    with pytest.raises(TypeError):
        AbstractConnector(_FakeCM())  # type: ignore[abstract]


def test_result_summary_truncated_when_over_cap() -> None:
    result = ConnectorResult(
        item_id="1",
        title="t",
        summary="x" * 600,
        url=None,
        connector_slug="fake",
        item_type="doc",
    )
    assert len(result.summary) == MAX_SUMMARY_CHARS
    assert result.summary.endswith("\u2026")


def test_result_summary_untouched_when_within_cap() -> None:
    result = ConnectorResult(
        item_id="1",
        title="t",
        summary="short",
        url=None,
        connector_slug="fake",
        item_type="doc",
    )
    assert result.summary == "short"


def test_credential_helpers_scope_key_to_connector_slug() -> None:
    cm = _FakeCM()
    conn = _ConcreteConnector(cm)
    conn._set_credential("access_token", "abc")
    assert cm.store[("connector_fake", "access_token")] == "abc"
    assert conn._get_credential("access_token") == "abc"
    conn._delete_credential("access_token")
    assert conn._get_credential("access_token") is None


def test_delete_credential_swallows_errors() -> None:
    cm = MagicMock()
    cm.get.return_value = None
    cm.delete.side_effect = RuntimeError("vault unavailable")
    conn = _ConcreteConnector(cm)
    # Must not raise even though the underlying manager blew up.
    conn._delete_credential("access_token")


def test_is_configured_oauth2_requires_access_token() -> None:
    cm = _FakeCM()
    conn = _ConcreteConnector(cm)
    assert conn.is_configured() is False
    conn._set_credential("access_token", "tok")
    assert conn.is_configured() is True


def test_is_configured_api_key() -> None:
    class _ApiKeyConn(_ConcreteConnector):
        slug = "apikey_conn"
        auth_type = AuthType.API_KEY

    cm = _FakeCM()
    conn = _ApiKeyConn(cm)
    assert conn.is_configured() is False
    conn._set_credential("api_key", "k")
    assert conn.is_configured() is True


def test_is_configured_connection_string() -> None:
    class _ConnStrConn(_ConcreteConnector):
        slug = "connstr"
        auth_type = AuthType.CONNECTION_STRING

    cm = _FakeCM()
    conn = _ConnStrConn(cm)
    assert conn.is_configured() is False
    conn._set_credential("connection_string", "postgres://user:pw@h/db")
    assert conn.is_configured() is True


def test_is_configured_basic_requires_both_fields() -> None:
    class _BasicConn(_ConcreteConnector):
        slug = "basic_conn"
        auth_type = AuthType.BASIC

    cm = _FakeCM()
    conn = _BasicConn(cm)
    assert conn.is_configured() is False
    conn._set_credential("username", "u")
    assert conn.is_configured() is False
    conn._set_credential("password", "p")
    assert conn.is_configured() is True


async def test_link_to_decision_returns_false_without_db_backend() -> None:
    conn = _ConcreteConnector(_FakeCM())
    assert await conn.link_to_decision("item_1", "decision_1", "proj_1") is False


async def test_link_to_decision_inserts_provenance_edge_row() -> None:
    db = MagicMock()
    db.insert = AsyncMock()
    conn = _ConcreteConnector(_FakeCM(), db=db)

    ok = await conn.link_to_decision("msg_abc", "dec_xyz", "proj_1")

    assert ok is True
    db.insert.assert_awaited_once()
    table_name, row = db.insert.await_args.args
    assert table_name == "provenance_edges"
    assert row["source_type"] == "connector_fake"
    assert row["source_id"] == "msg_abc"
    assert row["target_type"] == "decision"
    assert row["target_id"] == "dec_xyz"
    assert row["relationship"] == "linked"
    assert row["id"]  # non-empty
    assert row["created_at"] == row["updated_at"]


async def test_link_to_decision_swallows_db_exception() -> None:
    db = MagicMock()
    db.insert = AsyncMock(side_effect=RuntimeError("boom"))
    conn = _ConcreteConnector(_FakeCM(), db=db)
    assert await conn.link_to_decision("i", "d", "p") is False
