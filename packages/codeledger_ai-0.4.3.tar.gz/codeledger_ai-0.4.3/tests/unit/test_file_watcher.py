"""Tests for backend.utils.file_watcher — non-git change detection.

The unit tests never rely on real filesystem events or a running CodeLedger
server: the ``watchdog.Observer`` and the HTTP POST call are both injected
as test doubles. Real SQLite is used for :class:`SnapshotStore` because it
is an in-process sqlite backend with no external dependency.

Covers:

* Lifecycle — ``start`` / ``stop`` / ``is_running``.
* Extension filtering — ``.py`` files trigger; ``.json`` and directories do not.
* Ignore-pattern filtering — paths inside ``.git`` and ``node_modules`` skip.
* Debounce — rapid repeated modifications collapse to a single fire.
* Connection failure — an HTTP client that raises does not propagate.
* No-change path — an unchanged file never triggers an HTTP POST.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any
from unittest.mock import MagicMock

import pytest
from watchdog.events import FileModifiedEvent

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.utils.file_watcher import (
    CodeLedgerEventHandler,
    CodeLedgerFileWatcher,
)
from backend.utils.snapshot_store import SnapshotStore

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Test doubles + fixtures
# ---------------------------------------------------------------------------


@dataclass
class _CapturingPost:
    """Test-double HTTP POST that records calls in memory."""

    calls: list[tuple[str, dict[str, Any], dict[str, str]]]

    def __call__(
        self, url: str, payload: dict[str, Any], headers: dict[str, str]
    ) -> None:
        self.calls.append((url, payload, headers))


@dataclass
class _Config:
    """Minimal ``_WatcherConfig`` implementation for tests."""

    watch_extensions: tuple[str, ...] = (".py",)
    debounce_ms: int = 10
    ignore_patterns: tuple[str, ...] = (".git", "node_modules")


@pytest.fixture
async def snapshot_store(tmp_path: Path) -> SnapshotStore:
    backend = SQLiteBackend(tmp_path / "fw.db")
    await backend.connect()
    await apply_migrations(backend)
    yield SnapshotStore(backend)
    await backend.close()


def _write(path: Path, body: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body, encoding="utf-8")


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------


class TestLifecycle:
    """start/stop/is_running interact with the injected Observer."""

    def test_start_creates_observer_and_schedules_handler(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        fake_observer = MagicMock()
        fake_observer.is_alive.return_value = True

        watcher = CodeLedgerFileWatcher(
            project_root=tmp_path,
            project_id="proj",
            server_url="http://localhost:8100",
            config=_Config(),
            snapshot_store=snapshot_store,
            observer_factory=lambda: fake_observer,
        )
        assert watcher.is_running() is False

        watcher.start()
        fake_observer.schedule.assert_called_once()
        _, args, kwargs = fake_observer.schedule.mock_calls[0]
        assert args[1] == str(tmp_path)
        assert kwargs.get("recursive", args[2] if len(args) > 2 else None) is True
        fake_observer.start.assert_called_once()
        assert watcher.is_running() is True

    def test_stop_is_idempotent(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        fake_observer = MagicMock()
        fake_observer.is_alive.return_value = True

        watcher = CodeLedgerFileWatcher(
            project_root=tmp_path,
            project_id="proj",
            server_url="http://localhost:8100",
            config=_Config(),
            snapshot_store=snapshot_store,
            observer_factory=lambda: fake_observer,
        )
        watcher.start()
        watcher.stop()
        watcher.stop()  # second call is a no-op
        fake_observer.stop.assert_called_once()

    def test_start_is_idempotent(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        fake_observer = MagicMock()
        watcher = CodeLedgerFileWatcher(
            project_root=tmp_path,
            project_id="proj",
            server_url="http://localhost:8100",
            config=_Config(),
            snapshot_store=snapshot_store,
            observer_factory=lambda: fake_observer,
        )
        watcher.start()
        watcher.start()
        assert fake_observer.start.call_count == 1

    def test_invalid_project_id_rejected(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        with pytest.raises(ValueError):
            CodeLedgerFileWatcher(
                project_root=tmp_path,
                project_id="",
                server_url="http://localhost:8100",
                config=_Config(),
                snapshot_store=snapshot_store,
            )


# ---------------------------------------------------------------------------
# on_modified filtering
# ---------------------------------------------------------------------------


class TestFiltering:
    """Non-Python events, ignored directories, and directory events all drop."""

    def _handler(
        self, tmp_path: Path, snapshot_store: SnapshotStore, post: _CapturingPost
    ) -> CodeLedgerEventHandler:
        return CodeLedgerEventHandler(
            project_root=tmp_path,
            project_id="proj",
            server_url="http://localhost:8100",
            config=_Config(),
            snapshot_store=snapshot_store,
            http_post=post,
        )

    def test_non_python_extension_dropped(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        post = _CapturingPost(calls=[])
        handler = self._handler(tmp_path, snapshot_store, post)

        target = tmp_path / "data.json"
        _write(target, '{"x": 1}')
        handler.on_modified(FileModifiedEvent(str(target)))
        _wait_for_debounce(handler)
        assert post.calls == []

    def test_git_directory_ignored(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        post = _CapturingPost(calls=[])
        handler = self._handler(tmp_path, snapshot_store, post)

        target = tmp_path / ".git" / "HEAD.py"  # contrived — still under .git
        _write(target, "x = 1\n")
        handler.on_modified(FileModifiedEvent(str(target)))
        _wait_for_debounce(handler)
        assert post.calls == []

    def test_node_modules_ignored(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        post = _CapturingPost(calls=[])
        handler = self._handler(tmp_path, snapshot_store, post)

        target = tmp_path / "node_modules" / "pkg" / "index.py"
        _write(target, "x = 1\n")
        handler.on_modified(FileModifiedEvent(str(target)))
        _wait_for_debounce(handler)
        assert post.calls == []

    def test_directory_events_dropped(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        post = _CapturingPost(calls=[])
        handler = self._handler(tmp_path, snapshot_store, post)

        event = FileModifiedEvent(str(tmp_path / "some_dir"))
        event.is_directory = True  # type: ignore[attr-defined]
        handler.on_modified(event)
        _wait_for_debounce(handler)
        assert post.calls == []


# ---------------------------------------------------------------------------
# Debounce
# ---------------------------------------------------------------------------


class TestDebounce:
    """Rapid saves collapse to a single processing event."""

    def test_rapid_events_collapse(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        post = _CapturingPost(calls=[])
        cfg = _Config(debounce_ms=80)
        handler = CodeLedgerEventHandler(
            project_root=tmp_path,
            project_id="proj",
            server_url="http://localhost:8100",
            config=cfg,
            snapshot_store=snapshot_store,
            http_post=post,
        )
        target = tmp_path / "x.py"
        _write(target, "x = 1\n")

        for _ in range(5):
            handler.on_modified(FileModifiedEvent(str(target)))
            time.sleep(0.005)
        _wait_for_debounce(handler, timeout_s=2.0)

        assert len(post.calls) == 1


# ---------------------------------------------------------------------------
# Processing pipeline
# ---------------------------------------------------------------------------


class TestProcessing:
    """_process_modification takes a snapshot and POSTs the diff."""

    def test_first_modification_posts_with_none_before(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        post = _CapturingPost(calls=[])
        handler = CodeLedgerEventHandler(
            project_root=tmp_path,
            project_id="proj",
            server_url="http://localhost:8100",
            config=_Config(),
            snapshot_store=snapshot_store,
            http_post=post,
        )
        target = tmp_path / "a.py"
        _write(target, "def foo():\n    return 1\n")

        handler._process_modification(str(target))

        assert len(post.calls) == 1
        url, payload, headers = post.calls[0]
        assert url == "http://localhost:8100/api/hooks/file-change"
        assert payload["file_path"] == str(target)
        assert payload["project_id"] == "proj"
        assert payload["before_snapshot_id"] is None
        assert payload["after_snapshot_id"]
        assert payload["active_session_id"] is None
        assert headers["Content-Type"] == "application/json"

    def test_subsequent_change_includes_before_id(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        post = _CapturingPost(calls=[])
        handler = CodeLedgerEventHandler(
            project_root=tmp_path,
            project_id="proj",
            server_url="http://localhost:8100",
            config=_Config(),
            snapshot_store=snapshot_store,
            http_post=post,
        )
        target = tmp_path / "a.py"
        _write(target, "def foo():\n    return 1\n")
        handler._process_modification(str(target))
        _write(target, "def foo():\n    return 2\n")
        handler._process_modification(str(target))

        assert len(post.calls) == 2
        _, first, _ = post.calls[0]
        _, second, _ = post.calls[1]
        assert first["before_snapshot_id"] is None
        assert second["before_snapshot_id"] == first["after_snapshot_id"]
        assert second["after_snapshot_id"] != first["after_snapshot_id"]

    def test_unchanged_content_does_not_post(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        post = _CapturingPost(calls=[])
        handler = CodeLedgerEventHandler(
            project_root=tmp_path,
            project_id="proj",
            server_url="http://localhost:8100",
            config=_Config(),
            snapshot_store=snapshot_store,
            http_post=post,
        )
        target = tmp_path / "a.py"
        _write(target, "stable\n")
        handler._process_modification(str(target))
        handler._process_modification(str(target))

        assert len(post.calls) == 1

    def test_webhook_secret_included_when_set(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        post = _CapturingPost(calls=[])
        handler = CodeLedgerEventHandler(
            project_root=tmp_path,
            project_id="proj",
            server_url="http://localhost:8100",
            config=_Config(),
            snapshot_store=snapshot_store,
            webhook_secret="s3cret",
            http_post=post,
        )
        target = tmp_path / "a.py"
        _write(target, "x = 1\n")
        handler._process_modification(str(target))

        _, _, headers = post.calls[0]
        assert headers["X-Webhook-Secret"] == "s3cret"

    def test_active_session_provider_applied(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        post = _CapturingPost(calls=[])
        handler = CodeLedgerEventHandler(
            project_root=tmp_path,
            project_id="proj",
            server_url="http://localhost:8100",
            config=_Config(),
            snapshot_store=snapshot_store,
            http_post=post,
            active_session_provider=lambda: "sess-123",
        )
        target = tmp_path / "a.py"
        _write(target, "x = 1\n")
        handler._process_modification(str(target))

        _, payload, _ = post.calls[0]
        assert payload["active_session_id"] == "sess-123"

    def test_http_error_swallowed(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        def failing_post(
            url: str, payload: dict[str, Any], headers: dict[str, str]
        ) -> None:
            raise ConnectionError("server unreachable")

        handler = CodeLedgerEventHandler(
            project_root=tmp_path,
            project_id="proj",
            server_url="http://localhost:8100",
            config=_Config(),
            snapshot_store=snapshot_store,
            http_post=failing_post,
        )
        target = tmp_path / "a.py"
        _write(target, "x = 1\n")
        # Must not raise.
        handler._process_modification(str(target))

    def test_missing_file_swallowed(
        self, tmp_path: Path, snapshot_store: SnapshotStore
    ) -> None:
        post = _CapturingPost(calls=[])
        handler = CodeLedgerEventHandler(
            project_root=tmp_path,
            project_id="proj",
            server_url="http://localhost:8100",
            config=_Config(),
            snapshot_store=snapshot_store,
            http_post=post,
        )
        # Target does not exist — must not raise and must not POST.
        handler._process_modification(str(tmp_path / "never.py"))
        assert post.calls == []


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _wait_for_debounce(
    handler: CodeLedgerEventHandler, timeout_s: float = 1.0
) -> None:
    """Block until every pending debounce timer has fired, or timeout."""
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        with handler._timers_lock:  # type: ignore[attr-defined]
            pending = list(handler._timers.values())  # type: ignore[attr-defined]
        if not pending:
            return
        for timer in pending:
            # Join each live timer so the test waits for its callback to finish.
            if isinstance(timer, threading.Timer):
                timer.join(timeout=max(deadline - time.time(), 0.01))
        time.sleep(0.01)
