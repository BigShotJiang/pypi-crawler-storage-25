"""Unit tests for ``backend.connectors.bootstrap.build_default_registry``."""

from __future__ import annotations

import logging
from unittest.mock import patch

from backend.connectors.bootstrap import build_default_registry


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def test_registers_all_12_external_connectors() -> None:
    registry = build_default_registry(_FakeCM())
    external_slugs = {
        "gmail", "drive", "calendar", "slack", "jira", "confluence",
        "linear", "notion", "github_issues", "asana", "teams", "outlook",
    }
    registered = {c.slug for c in registry.all()}
    assert external_slugs.issubset(registered)


def test_registers_postgres_when_asyncpg_installed() -> None:
    # asyncpg is part of the [postgres] extra and installed in the dev venv.
    registry = build_default_registry(_FakeCM())
    assert registry.get("postgresql") is not None
    assert registry.get("timescaledb") is not None


def test_optional_driver_skipped_silently_at_info_level(
    caplog: object,
) -> None:
    # The 12 optional-driver connectors (mysql, motor, redis, ...) aren't
    # installed in the dev venv. The bootstrap should log at INFO (not
    # WARNING) and continue rather than crashing or noisily failing.
    import pytest

    assert isinstance(caplog, pytest.LogCaptureFixture)
    caplog.set_level(logging.INFO, logger="backend.connectors.bootstrap")
    registry = build_default_registry(_FakeCM())

    # None of the skipped connectors register.
    for slug in ("mysql", "mongodb", "redis", "influxdb2", "cassandra"):
        assert registry.get(slug) is None

    info_messages = [
        r.getMessage()
        for r in caplog.records
        if r.levelno == logging.INFO
    ]
    # At least one skip logged at INFO — confirms the log-level contract.
    assert any("not registered" in m for m in info_messages)

    warning_messages = [
        r.getMessage()
        for r in caplog.records
        if r.levelno == logging.WARNING
    ]
    # No WARNING spam from missing-driver skips.
    assert not any("MySQLConnector" in m for m in warning_messages)


def test_config_bug_logged_at_warning_not_swallowed(
    caplog: object,
) -> None:
    """Unexpected exceptions during registration are logged at WARNING.

    Mitigates A-1 §1.8 risk #5: missing-driver paths silence themselves at
    INFO, but any other error must surface so config bugs don't vanish.
    """
    import pytest

    assert isinstance(caplog, pytest.LogCaptureFixture)

    # Force the PostgreSQL connector's __init__ to raise a ValueError (not
    # RuntimeError, which would be treated as "driver missing"). Bootstrap
    # must log at WARNING and continue.
    def _boom(*_args, **_kwargs):  # type: ignore[no-untyped-def]
        raise ValueError("simulated config bug")

    caplog.set_level(logging.WARNING, logger="backend.connectors.bootstrap")
    with patch(
        "backend.connectors.databases.postgresql.PostgreSQLConnector.__init__",
        new=_boom,
    ):
        registry = build_default_registry(_FakeCM())

    assert registry.get("postgresql") is None
    messages = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert any("PostgreSQLConnector" in m for m in messages)


def test_no_duplicate_slugs() -> None:
    registry = build_default_registry(_FakeCM())
    slugs = [c.slug for c in registry.all()]
    assert len(slugs) == len(set(slugs)), f"duplicates in: {slugs}"
