"""Tests for the Phase 3 active-context-injection hook endpoints.

Exercises :class:`ToolHandlers` directly (handler-level) so the same
latency budgets can be measured without FastAPI overhead. The REST
layer is a thin wrapper — covered by :mod:`tests.integration.test_main_app`.
"""

from __future__ import annotations

import asyncio
import time
import uuid
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.db.vector_store import SqliteVssStore
from backend.intelligence.context_triage import ContextTriage
from backend.intelligence.semantic_search import SemanticSearch
from backend.mcp.tool_handlers import ToolHandlers
from backend.models import Decision, Session
from backend.utils.token_counter import count_tokens
from backend.verification.conflict_detector import ConflictDetector

if TYPE_CHECKING:
    from pathlib import Path


class _FakeEmbedder:
    """Deterministic 16-dim embedder for hook tests — no Ollama needed."""

    async def embed_text(self, text: str) -> list[float]:
        # Stable hash-derived vector; irrelevant-but-deterministic ordering
        # lets the triage path run without blowing up.
        base = [0.0] * 16
        for i, ch in enumerate(text):
            base[i % 16] += (ord(ch) % 13) / 13.0
        # Normalise so vectors always fit in the valid range.
        total = max(sum(abs(x) for x in base), 1.0)
        return [x / total for x in base]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [await self.embed_text(t) for t in texts]


@pytest.fixture
async def project_dir(tmp_path: Path) -> Path:
    """A project root with a minimal codeledger.toml so hooks detect it."""
    proj = tmp_path / "demo-project"
    proj.mkdir()
    (proj / "codeledger.toml").write_text("# minimal\n", encoding="utf-8")
    return proj


@pytest.fixture
async def hook_handlers(tmp_path: Path) -> ToolHandlers:
    db = SQLiteBackend(tmp_path / "hooks.db")
    await db.connect()
    await apply_migrations(db)
    store = SqliteVssStore(tmp_path / "hooks-vec.db", dim=16)
    await store.connect()
    semantic = SemanticSearch(
        embedder=_FakeEmbedder(), vector_store=store, db=db
    )
    yield ToolHandlers(
        db=db,
        semantic_search=semantic,
        context_triage=ContextTriage(count_tokens),
        conflict_detector=ConflictDetector(db),
    )
    await store.close()
    await db.close()


# ---------------------------------------------------------------------------
# session-context
# ---------------------------------------------------------------------------


class TestSessionContext:
    async def test_unknown_cwd_returns_empty_block(
        self, hook_handlers: ToolHandlers, tmp_path: Path
    ) -> None:
        result = await hook_handlers.hooks_session_context(
            user_id=uuid.uuid4(),
            cwd=str(tmp_path / "not-a-project"),
            prompt="anything",
        )
        assert result["context_block"] == ""
        assert result["project_id"] is None

    async def test_known_project_returns_formatted_block(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        await hook_handlers.decision_create(
            user_id=uuid.uuid4(),
            title="Use Argon2id for password hashing",
            description="Security decision for authentication.",
        )
        result = await hook_handlers.hooks_session_context(
            user_id=uuid.uuid4(),
            cwd=str(project_dir),
            prompt="how should we hash passwords?",
        )
        assert result["project_id"] == project_dir.name
        # The triage block may be empty when the fake embedder doesn't
        # produce strong similarity; what matters is that the endpoint
        # returned a well-formed response.
        assert "context_block" in result

    async def test_walks_up_to_find_project(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        nested = project_dir / "src" / "nested"
        nested.mkdir(parents=True)
        result = await hook_handlers.hooks_session_context(
            user_id=uuid.uuid4(),
            cwd=str(nested),
            prompt="query from nested dir",
        )
        assert result["project_id"] == project_dir.name


# ---------------------------------------------------------------------------
# file-context
# ---------------------------------------------------------------------------


class TestFileContext:
    async def test_returns_block_for_known_file(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        target = project_dir / "auth.py"
        target.write_text("def hash_password(pw):\n    return pw\n", encoding="utf-8")
        await hook_handlers.decision_create(
            user_id=uuid.uuid4(),
            title="Hash passwords in auth.py",
            description="auth.py hash_password must use Argon2id.",
        )
        result = await hook_handlers.hooks_file_context(
            user_id=uuid.uuid4(),
            file_path=str(target),
            cwd=str(project_dir),
        )
        assert result["project_id"] == project_dir.name
        assert result["file_path"] == str(target)
        assert "context_block" in result

    async def test_missing_file_returns_block_without_error(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        result = await hook_handlers.hooks_file_context(
            user_id=uuid.uuid4(),
            file_path=str(project_dir / "nonexistent.py"),
            cwd=str(project_dir),
        )
        assert "context_block" in result


# ---------------------------------------------------------------------------
# conflict-check
# ---------------------------------------------------------------------------


class TestConflictCheck:
    async def test_no_conflict_when_alone(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        sid = uuid.uuid4()
        result = await hook_handlers.hooks_conflict_check(
            user_id=uuid.uuid4(),
            file_path="auth.py",
            session_id=sid,
            cwd=str(project_dir),
        )
        assert result["conflict"] is False

    async def test_conflict_detected(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        # Register a competing session on the same file.
        assert hook_handlers.conflict_detector is not None
        hook_handlers.conflict_detector.register_session(
            session_id="other-session",
            project_id=project_dir.name,
            agent_name="other-agent",
            files=["auth.py"],
        )
        sid = uuid.uuid4()
        result = await hook_handlers.hooks_conflict_check(
            user_id=uuid.uuid4(),
            file_path="auth.py",
            session_id=sid,
            cwd=str(project_dir),
        )
        assert result["conflict"] is True
        assert "auth.py" in result["overlapping_files"]

    async def test_missing_session_returns_false(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        result = await hook_handlers.hooks_conflict_check(
            user_id=uuid.uuid4(),
            file_path="auth.py",
            session_id=None,
            cwd=str(project_dir),
        )
        assert result["conflict"] is False


# ---------------------------------------------------------------------------
# import-check
# ---------------------------------------------------------------------------


class TestImportCheck:
    async def test_violation_when_import_matches_constraint(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        # Seed a verified decision with a "must not import" constraint.
        d = Decision(
            title="Layering",
            description="backend.api must not import backend.db directly.",
            status="passed",
        )
        await hook_handlers.db.insert("decisions", d.to_dict())
        result = await hook_handlers.hooks_import_check(
            user_id=uuid.uuid4(),
            content="from backend.db import routes\n",
            file_path="backend/api/auth.py",
            cwd=str(project_dir),
        )
        assert result["violations"]
        v = result["violations"][0]
        assert v["import"] == "backend.db"
        assert v["decision_id"] == str(d.id)

    async def test_no_violation_when_conformant(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        d = Decision(
            title="Layering",
            description="backend.api must not import backend.db directly.",
            status="passed",
        )
        await hook_handlers.db.insert("decisions", d.to_dict())
        result = await hook_handlers.hooks_import_check(
            user_id=uuid.uuid4(),
            content="from backend.mcp.tool_handlers import ToolHandlers\n",
            file_path="backend/api/auth.py",
            cwd=str(project_dir),
        )
        assert result["violations"] == []

    async def test_no_constraints_no_violations(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        result = await hook_handlers.hooks_import_check(
            user_id=uuid.uuid4(),
            content="import os\n",
            file_path="backend/api/auth.py",
            cwd=str(project_dir),
        )
        assert result["violations"] == []


# ---------------------------------------------------------------------------
# ensure-session
# ---------------------------------------------------------------------------


class TestEnsureSession:
    async def test_first_call_creates_session(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        result = await hook_handlers.hooks_ensure_session(
            user_id=uuid.uuid4(),
            cwd=str(project_dir),
            agent="claude-code",
        )
        assert result["created"] is True
        assert result["session_id"]

    async def test_subsequent_calls_return_same_session(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        uid = uuid.uuid4()
        first = await hook_handlers.hooks_ensure_session(
            user_id=uid, cwd=str(project_dir), agent="claude-code"
        )
        second = await hook_handlers.hooks_ensure_session(
            user_id=uid, cwd=str(project_dir), agent="claude-code"
        )
        third = await hook_handlers.hooks_ensure_session(
            user_id=uid, cwd=str(project_dir), agent="claude-code"
        )
        assert first["session_id"] == second["session_id"] == third["session_id"]
        assert second["created"] is False
        assert third["created"] is False

    async def test_different_agents_get_different_sessions(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        uid = uuid.uuid4()
        a = await hook_handlers.hooks_ensure_session(
            user_id=uid, cwd=str(project_dir), agent="claude-code"
        )
        b = await hook_handlers.hooks_ensure_session(
            user_id=uid, cwd=str(project_dir), agent="cursor"
        )
        assert a["session_id"] != b["session_id"]


# ---------------------------------------------------------------------------
# close-session
# ---------------------------------------------------------------------------


class TestCloseSession:
    async def test_close_session_marks_completed(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        uid = uuid.uuid4()
        ensured = await hook_handlers.hooks_ensure_session(
            user_id=uid, cwd=str(project_dir), agent="claude-code"
        )
        result = await hook_handlers.hooks_close_session(
            user_id=uid, cwd=str(project_dir)
        )
        assert result["status"] == "closed"
        row = await hook_handlers.db.get_by_id("sessions", ensured["session_id"])
        assert row["status"].startswith("completed")

    async def test_close_session_never_raises_on_missing_cwd(
        self,
        hook_handlers: ToolHandlers,
    ) -> None:
        result = await hook_handlers.hooks_close_session(
            user_id=uuid.uuid4(), cwd="/no/such/project"
        )
        assert result["status"] == "closed"


# ---------------------------------------------------------------------------
# Performance — all hooks under 300ms with 500 decisions + 100 sessions
# ---------------------------------------------------------------------------


async def _seed_perf_dataset(handlers: ToolHandlers) -> None:
    """Seed 500 decisions and 100 completed sessions."""
    rows: list[dict] = []
    for i in range(500):
        d = Decision(
            title=f"Decision {i}",
            description=(
                f"Decision {i} about feature {i % 10} covering "
                "authentication, persistence, or retrieval."
            ),
            status="passed" if i % 3 == 0 else "unverified",
        )
        rows.append(d.to_dict())
    # Use raw execute for speed — insert_many isn't on the backend.
    for row in rows:
        await handlers.db.insert("decisions", row)
    for i in range(100):
        s = Session(agent_name=f"agent-{i % 5}", status="completed")
        await handlers.db.insert("sessions", s.to_dict())


class TestHookPerformance:
    @pytest.mark.asyncio
    async def test_all_hooks_under_budget(
        self,
        hook_handlers: ToolHandlers,
        project_dir: Path,
    ) -> None:
        await _seed_perf_dataset(hook_handlers)
        uid = uuid.uuid4()

        # ensure-session — idempotent, one DB query per existing session.
        start = time.perf_counter()
        ensured = await hook_handlers.hooks_ensure_session(
            user_id=uid, cwd=str(project_dir), agent="perf-agent"
        )
        ensure_ms = (time.perf_counter() - start) * 1000
        assert ensure_ms < 300, f"ensure-session: {ensure_ms:.1f}ms"

        # session-context — semantic search + triage.
        start = time.perf_counter()
        await hook_handlers.hooks_session_context(
            user_id=uid,
            cwd=str(project_dir),
            prompt="retrieve context for auth decisions",
        )
        session_ms = (time.perf_counter() - start) * 1000
        assert session_ms < 300, f"session-context: {session_ms:.1f}ms"

        # file-context — same pipeline scoped to a file.
        start = time.perf_counter()
        await hook_handlers.hooks_file_context(
            user_id=uid,
            file_path=str(project_dir / "nonexistent.py"),
            cwd=str(project_dir),
        )
        file_ms = (time.perf_counter() - start) * 1000
        assert file_ms < 300, f"file-context: {file_ms:.1f}ms"

        # conflict-check — in-memory detector.
        start = time.perf_counter()
        await hook_handlers.hooks_conflict_check(
            user_id=uid,
            file_path="auth.py",
            session_id=uuid.UUID(ensured["session_id"]),
            cwd=str(project_dir),
        )
        conflict_ms = (time.perf_counter() - start) * 1000
        assert conflict_ms < 300, f"conflict-check: {conflict_ms:.1f}ms"

        # import-check — constraint extraction + line scan.
        start = time.perf_counter()
        await hook_handlers.hooks_import_check(
            user_id=uid,
            content="import os\nimport sys\n",
            file_path="backend/api/auth.py",
            cwd=str(project_dir),
        )
        import_ms = (time.perf_counter() - start) * 1000
        assert import_ms < 300, f"import-check: {import_ms:.1f}ms"

        # close-session — runs inference; covered by the 300ms budget.
        start = time.perf_counter()
        await hook_handlers.hooks_close_session(
            user_id=uid, cwd=str(project_dir)
        )
        close_ms = (time.perf_counter() - start) * 1000
        assert close_ms < 300, f"close-session: {close_ms:.1f}ms"


_ = asyncio  # keep the import alive for readers even though fixtures use await
