"""Unit tests for the ``codeledger connectors`` CLI command group."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from click.testing import CliRunner

from backend.cli import cli


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def fake_cm() -> _FakeCM:
    return _FakeCM()


@pytest.fixture(autouse=True)
def _patch_cm_loader(fake_cm: _FakeCM) -> None:
    """Redirect `_cli_credential_manager` to an in-memory _FakeCM.

    Prevents the CLI from touching the real vault during tests.
    """
    with (
        patch("backend.cli._cli_credential_manager", return_value=fake_cm),
        patch(
            "backend.cli._load_credential_manager_for_cli",
            return_value=fake_cm,
        ),
    ):
        yield


# ----------------------- list ------------------------------------------ #


def test_list_shows_all_shipped_connectors(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["connectors", "list"])
    assert result.exit_code == 0
    # External connectors always register.
    for slug in ("gmail", "slack", "jira", "notion"):
        assert slug in result.output
    assert "not configured" in result.output


# ----------------------- status ---------------------------------------- #


def test_status_runs_health_on_each(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["connectors", "status"])
    assert result.exit_code == 0
    # Each line is "<slug> <status> <message>"
    assert "gmail" in result.output
    assert "not_configured" in result.output  # nothing is configured


# ----------------------- connect: unknown slug ------------------------- #


def test_connect_unknown_slug_exits_nonzero(runner: CliRunner) -> None:
    result = runner.invoke(
        cli, ["connectors", "connect", "--connector", "madeup"]
    )
    assert result.exit_code == 1
    assert "Unknown connector" in result.output


# ----------------------- connect: OAuth prints URL --------------------- #


def test_connect_oauth_prints_url(runner: CliRunner) -> None:
    result = runner.invoke(
        cli, ["connectors", "connect", "--connector", "gmail"]
    )
    assert result.exit_code == 0
    assert "/api/connectors/oauth/gmail/connect" in result.output
    assert "authorize" in result.output.lower()


# ----------------------- connect: API key prompt ----------------------- #


def test_connect_connection_string_stores_in_vault(
    runner: CliRunner, fake_cm: _FakeCM
) -> None:
    # postgresql uses CONNECTION_STRING auth
    result = runner.invoke(
        cli,
        ["connectors", "connect", "--connector", "postgresql"],
        input="postgres://u:p@h/d\n",
    )
    assert result.exit_code == 0, result.output
    assert (
        fake_cm.store[("connector_postgresql", "connection_string")]
        == "postgres://u:p@h/d"
    )


# ----------------------- disconnect ------------------------------------ #


def test_disconnect_clears_multiple_credential_keys(
    runner: CliRunner, fake_cm: _FakeCM
) -> None:
    fake_cm.set("connector_gmail", "access_token", "tok")
    fake_cm.set("connector_gmail", "refresh_token", "rt")
    fake_cm.set("connector_gmail", "token_expiry", "9999")

    result = runner.invoke(
        cli,
        ["connectors", "disconnect", "--connector", "gmail"],
        input="y\n",
    )
    assert result.exit_code == 0, result.output
    for key in ("access_token", "refresh_token", "token_expiry"):
        assert ("connector_gmail", key) not in fake_cm.store


def test_disconnect_respects_abort(
    runner: CliRunner, fake_cm: _FakeCM
) -> None:
    fake_cm.set("connector_gmail", "access_token", "tok")
    result = runner.invoke(
        cli,
        ["connectors", "disconnect", "--connector", "gmail"],
        input="n\n",
    )
    # Click's confirmation_option exits with 1 on refusal
    assert result.exit_code != 0
    # Token remains untouched
    assert fake_cm.store[("connector_gmail", "access_token")] == "tok"


# ----------------------- test ------------------------------------------ #


def test_test_prints_health_and_nonzero_on_error(
    runner: CliRunner,
) -> None:
    from backend.connectors.base import ConnectorHealth, ConnectorStatus

    health = ConnectorHealth(
        slug="gmail",
        status=ConnectorStatus.AUTH_EXPIRED,
        message="token expired",
        configured=True,
    )

    # Replace gmail's health() with a mock that returns AUTH_EXPIRED.
    async def _h() -> ConnectorHealth:
        return health

    # Reach into the module-bound class to patch its method for the call.
    from backend.connectors.external.gmail import GmailConnector

    with patch.object(GmailConnector, "health", new=AsyncMock(side_effect=_h)):
        result = runner.invoke(
            cli, ["connectors", "test", "--connector", "gmail"]
        )

    assert result.exit_code == 1
    assert "auth_expired" in result.output


def test_test_unknown_slug(runner: CliRunner) -> None:
    result = runner.invoke(
        cli, ["connectors", "test", "--connector", "nope"]
    )
    assert result.exit_code == 1
    assert "Unknown connector" in result.output


# ----------------------- db schema ------------------------------------- #


def test_db_schema_rejects_non_db_connector(runner: CliRunner) -> None:
    result = runner.invoke(
        cli, ["connectors", "db", "schema", "--connector", "gmail"]
    )
    assert result.exit_code == 1
    assert "not a database connector" in result.output


def test_db_schema_prints_tables_on_known_connector(
    runner: CliRunner,
) -> None:
    from backend.connectors.databases.postgresql import PostgreSQLConnector

    async def _summary() -> dict:
        return {
            "tables": [
                {"name": "users", "columns": ["id", "email"]},
                {"name": "orders", "columns": ["id", "user_id"]},
            ]
        }

    with patch.object(
        PostgreSQLConnector, "get_schema_summary", new=AsyncMock(side_effect=_summary)
    ):
        result = runner.invoke(
            cli,
            ["connectors", "db", "schema", "--connector", "postgresql"],
        )
    assert result.exit_code == 0, result.output
    assert "users" in result.output
    assert "orders" in result.output
    assert "id" in result.output


def test_db_schema_unknown_slug(runner: CliRunner) -> None:
    result = runner.invoke(
        cli, ["connectors", "db", "schema", "--connector", "nope"]
    )
    assert result.exit_code == 1
    assert "Unknown connector" in result.output


# ----------------------- help surface ---------------------------------- #


def test_connectors_help_lists_all_subcommands(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["connectors", "--help"])
    assert result.exit_code == 0
    for sub in (
        "list", "status", "connect", "disconnect", "test", "db",
    ):
        assert sub in result.output
