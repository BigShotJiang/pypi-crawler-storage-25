"""Unit tests for the ``connectors`` MCP tool dispatch layer.

The underlying ``handlers.connectors_*`` methods are covered in
``test_tool_handlers_connectors.py``. Here we only verify the dispatch
shape: method names map to the right handler call, missing required
parameters raise ``HandlerError``, and unknown methods are rejected.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from backend.mcp.mcp_server import create_mcp_server
from backend.mcp.tool_handlers import HandlerError, ToolHandlers
from backend.models import User


async def _call_connectors_tool(
    handlers: ToolHandlers, **kwargs: Any
) -> Any:
    """Invoke the ``connectors`` MCP tool as FastMCP would.

    FastMCP's test surface makes direct dispatch awkward; we reach into the
    wrapped coroutine via the tool name. Bypasses schema introspection and
    calls the raw function.
    """
    mcp = create_mcp_server(handlers)
    tools = await mcp.list_tools()
    tool = next(t for t in tools if t.name == "connectors")
    # FastMCP stores the coroutine under .fn (or .func, depending on version).
    target = getattr(tool, "fn", None) or getattr(tool, "func", None)
    if target is None:
        # Fallback — pull from the registry directly.
        tool_dict = getattr(mcp, "_tools", None) or getattr(
            mcp, "tools", None
        )
        if isinstance(tool_dict, dict):
            entry = tool_dict["connectors"]
            target = getattr(entry, "fn", None) or getattr(entry, "func", None)
    assert target is not None, "Could not locate dispatch function for connectors tool"
    return await target(**kwargs)


def _fake_user() -> User:
    return User(email="u@x", name="U", provider="solo", password_hash=None)


def _handlers_with_mocked_connectors() -> ToolHandlers:
    handlers = ToolHandlers(db=MagicMock())
    # Patch handler methods directly; they are async.
    handlers.connectors_status = AsyncMock(  # type: ignore[method-assign]
        return_value={"connectors": [{"slug": "a"}]}
    )
    handlers.connectors_search_all = AsyncMock(  # type: ignore[method-assign]
        return_value={"results": []}
    )
    handlers.connectors_search = AsyncMock(  # type: ignore[method-assign]
        return_value={"results": []}
    )
    handlers.connectors_get_item = AsyncMock(  # type: ignore[method-assign]
        return_value={"item": None}
    )
    handlers.connectors_link_to_decision = AsyncMock(  # type: ignore[method-assign]
        return_value={"linked": True}
    )
    handlers.connectors_list_tables = AsyncMock(  # type: ignore[method-assign]
        return_value={"tables": []}
    )
    handlers.connectors_describe_table = AsyncMock(  # type: ignore[method-assign]
        return_value={"columns": []}
    )
    handlers.connectors_sample_rows = AsyncMock(  # type: ignore[method-assign]
        return_value={"rows": []}
    )
    handlers.connectors_get_schema_summary = AsyncMock(  # type: ignore[method-assign]
        return_value={"tables": []}
    )
    return handlers


@pytest.fixture
def handlers() -> ToolHandlers:
    return _handlers_with_mocked_connectors()


# ----------------------- registration ---------------------------------- #


async def test_connectors_tool_is_registered(handlers: ToolHandlers) -> None:
    mcp = create_mcp_server(handlers)
    names = {t.name for t in await mcp.list_tools()}
    assert "connectors" in names


# ----------------------- dispatch -------------------------------------- #


async def test_status_method_dispatch(handlers: ToolHandlers) -> None:
    with patch(
        "backend.mcp.mcp_server.get_current_user", return_value=_fake_user()
    ):
        out = await _call_connectors_tool(handlers, method="status")
    assert out["connectors"][0]["slug"] == "a"
    handlers.connectors_status.assert_awaited_once()


async def test_search_all_requires_query_and_project(
    handlers: ToolHandlers,
) -> None:
    with (
        patch(
            "backend.mcp.mcp_server.get_current_user",
            return_value=_fake_user(),
        ),
        pytest.raises(HandlerError, match="query and project_id"),
    ):
        await _call_connectors_tool(handlers, method="search_all")


async def test_search_requires_slug_query_project(
    handlers: ToolHandlers,
) -> None:
    with (
        patch(
            "backend.mcp.mcp_server.get_current_user",
            return_value=_fake_user(),
        ),
        pytest.raises(HandlerError, match="connector_slug, query"),
    ):
        await _call_connectors_tool(handlers, method="search", query="q")


async def test_search_dispatch_passes_params(
    handlers: ToolHandlers,
) -> None:
    with patch(
        "backend.mcp.mcp_server.get_current_user", return_value=_fake_user()
    ):
        await _call_connectors_tool(
            handlers,
            method="search",
            connector_slug="gmail",
            query="q",
            project_id="p",
            max_results=20,
        )
    handlers.connectors_search.assert_awaited_once_with(
        connector_slug="gmail",
        query="q",
        project_id="p",
        max_results=20,
    )


async def test_get_item_dispatch(handlers: ToolHandlers) -> None:
    with patch(
        "backend.mcp.mcp_server.get_current_user", return_value=_fake_user()
    ):
        await _call_connectors_tool(
            handlers,
            method="get_item",
            connector_slug="gmail",
            item_id="m1",
            project_id="p",
        )
    handlers.connectors_get_item.assert_awaited_once_with(
        connector_slug="gmail", item_id="m1", project_id="p"
    )


async def test_link_to_decision_requires_all_four(
    handlers: ToolHandlers,
) -> None:
    with (
        patch(
            "backend.mcp.mcp_server.get_current_user",
            return_value=_fake_user(),
        ),
        pytest.raises(HandlerError, match="connector_slug, item_id, decision_id"),
    ):
        await _call_connectors_tool(
            handlers,
            method="link_to_decision",
            connector_slug="gmail",
            item_id="m",
            # decision_id missing
            project_id="p",
        )


async def test_list_tables_requires_slug(handlers: ToolHandlers) -> None:
    with (
        patch(
            "backend.mcp.mcp_server.get_current_user",
            return_value=_fake_user(),
        ),
        pytest.raises(HandlerError, match="connector_slug"),
    ):
        await _call_connectors_tool(handlers, method="list_tables")


async def test_describe_table_requires_slug_and_table(
    handlers: ToolHandlers,
) -> None:
    with (
        patch(
            "backend.mcp.mcp_server.get_current_user",
            return_value=_fake_user(),
        ),
        pytest.raises(HandlerError, match="connector_slug and table"),
    ):
        await _call_connectors_tool(
            handlers, method="describe_table", connector_slug="pg"
        )


async def test_sample_rows_dispatch(handlers: ToolHandlers) -> None:
    with patch(
        "backend.mcp.mcp_server.get_current_user", return_value=_fake_user()
    ):
        await _call_connectors_tool(
            handlers,
            method="sample_rows",
            connector_slug="pg",
            table="users",
            limit=7,
        )
    handlers.connectors_sample_rows.assert_awaited_once_with(
        connector_slug="pg", table="users", limit=7
    )


async def test_unknown_method_raises(handlers: ToolHandlers) -> None:
    with (
        patch(
            "backend.mcp.mcp_server.get_current_user",
            return_value=_fake_user(),
        ),
        pytest.raises(HandlerError, match="Unknown connectors method"),
    ):
        await _call_connectors_tool(handlers, method="nope")


async def test_missing_auth_raises(handlers: ToolHandlers) -> None:
    # No user in ContextVar and no explicit user_id — SEC-05 enforces auth.
    with (
        patch(
            "backend.mcp.mcp_server.get_current_user", return_value=None
        ),
        pytest.raises(HandlerError, match="user_id is required"),
    ):
        await _call_connectors_tool(handlers, method="status")
