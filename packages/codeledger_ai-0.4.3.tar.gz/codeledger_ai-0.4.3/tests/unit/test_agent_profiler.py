"""Tests for backend.advanced.agent_profiler."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from backend.advanced.agent_profiler import AgentProfiler
from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.models import Decision, Session, Story

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
async def db(tmp_path: Path) -> SQLiteBackend:
    backend = SQLiteBackend(tmp_path / "profiler.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def profiler(db: SQLiteBackend) -> AgentProfiler:
    return AgentProfiler(db=db)


async def _seed_sessions_with_decisions(
    db: SQLiteBackend,
    *,
    agent: str,
    n: int,
    decision_status: str = "passed",
    tags: list[str] | None = None,
) -> None:
    for _ in range(n):
        session = Session(agent_name=agent, status="completed")
        await db.insert("sessions", session.to_dict())
        d = Decision(
            title=f"{agent} decision",
            status=decision_status,
            tags=list(tags or []),
            recorded_in_session_id=session.id,
        )
        await db.insert("decisions", d.to_dict())


class TestGetProfile:
    async def test_insufficient_data(
        self, db: SQLiteBackend, profiler: AgentProfiler
    ) -> None:
        await _seed_sessions_with_decisions(db, agent="a", n=2)
        profile = await profiler.get_profile("a", "p1")
        assert profile.insufficient_data is True

    async def test_profile_basic(
        self, db: SQLiteBackend, profiler: AgentProfiler
    ) -> None:
        await _seed_sessions_with_decisions(
            db, agent="claude", n=5, decision_status="passed", tags=["auth"]
        )
        profile = await profiler.get_profile("claude", "p1")
        assert profile.insufficient_data is False
        assert profile.total_sessions == 5
        assert profile.verification_pass_rate == 1.0
        assert "auth" in profile.strong_domains

    async def test_file_watcher_pass_rate_none(
        self, db: SQLiteBackend
    ) -> None:
        await _seed_sessions_with_decisions(
            db, agent="claude", n=5, decision_status="passed"
        )
        fw_profiler = AgentProfiler(db, change_detection_backend="file_watcher")
        profile = await fw_profiler.get_profile("claude", "p1")
        assert profile.verification_pass_rate is None

    async def test_profile_dict(
        self, db: SQLiteBackend, profiler: AgentProfiler
    ) -> None:
        await _seed_sessions_with_decisions(db, agent="claude", n=5)
        payload = await profiler.get_profile_dict("claude", "p1")
        assert payload["agent_name"] == "claude"
        assert "strong_domains" in payload
        assert payload["verification_pass_rate"] is not None


class TestRecommend:
    async def test_recommend_story_returns_ranked(
        self, db: SQLiteBackend, profiler: AgentProfiler
    ) -> None:
        # Two agents, one is good at "auth".
        await _seed_sessions_with_decisions(
            db, agent="claude", n=5, tags=["auth"], decision_status="passed"
        )
        await _seed_sessions_with_decisions(
            db, agent="cursor", n=5, tags=["ui"], decision_status="passed"
        )
        story = Story(title="Add OAuth", acceptance_criteria=["auth"])
        await db.insert("stories", story.to_dict())
        recs = await profiler.recommend_agent(str(story.id), "p1")
        # At least the agents with sufficient data appear in the ranking.
        assert any(r.agent_name == "claude" for r in recs)
        assert any(r.agent_name == "cursor" for r in recs)

    async def test_recommend_unknown_story_returns_empty(
        self, profiler: AgentProfiler
    ) -> None:
        import uuid

        assert await profiler.recommend_agent(str(uuid.uuid4()), "p1") == []


class TestContextAdjustment:
    async def test_context_adjustment_shape(
        self, db: SQLiteBackend, profiler: AgentProfiler
    ) -> None:
        await _seed_sessions_with_decisions(
            db, agent="claude", n=5, tags=["auth"], decision_status="passed"
        )
        story = Story(title="Work item")
        await db.insert("stories", story.to_dict())
        adj = await profiler.get_context_adjustment("claude", str(story.id))
        assert adj["agent_name"] == "claude"
        assert "weak_domain_overlap" in adj
        assert "strong_domain_overlap" in adj
