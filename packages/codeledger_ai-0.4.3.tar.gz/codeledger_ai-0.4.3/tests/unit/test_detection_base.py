"""Tests for backend.detection.base — :class:`AbstractDetector`."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime

import pytest

from backend.detection.base import (
    AbstractDetector,
    DetectorError,
    DetectorStatus,
)
from backend.detection.events import ChangeEvent


pytestmark = pytest.mark.asyncio


def _event(source: str = "git_commit") -> ChangeEvent:
    return ChangeEvent(
        change_event_source=source,  # type: ignore[arg-type]
        actor_type="human",
        actor_id=None,
        project_id="proj",
        created_at=datetime.now(UTC),
    )


class _StubDetector(AbstractDetector):
    """Minimal concrete implementation for exercising the base class."""

    source = "git_commit"

    def __init__(self, queue: asyncio.Queue[ChangeEvent]) -> None:
        super().__init__(queue)
        self.started = False
        self.stopped = False

    async def start(self) -> None:
        self.started = True

    async def stop(self) -> None:
        self.stopped = True

    async def health(self) -> DetectorStatus:
        if self.started and not self.stopped:
            return DetectorStatus.HEALTHY
        return DetectorStatus.STOPPED


class TestSubclassContract:
    """Instantiation catches concrete subclasses that forgot to set source."""

    async def test_concrete_without_source_rejected_at_init(self) -> None:
        class _Bad(AbstractDetector):
            async def start(self) -> None: ...
            async def stop(self) -> None: ...
            async def health(self) -> DetectorStatus:
                return DetectorStatus.HEALTHY

        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        with pytest.raises(TypeError, match="non-empty class.*source"):
            _Bad(q)

    async def test_abstract_intermediate_cannot_be_instantiated(self) -> None:
        # Pure ABC: still has abstract methods, cannot be instantiated.
        class _Intermediate(AbstractDetector):
            pass

        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        with pytest.raises(TypeError, match="abstract"):
            _Intermediate(q)  # type: ignore[abstract]


class TestConstruction:
    """Queue injection is required and must be an asyncio.Queue."""

    async def test_accepts_asyncio_queue(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        detector = _StubDetector(q)
        assert detector._queue is q

    async def test_rejects_non_queue(self) -> None:
        with pytest.raises(DetectorError, match="asyncio.Queue"):
            _StubDetector([])  # type: ignore[arg-type]


class TestEmit:
    """emit() validates event type and source matching."""

    async def test_emit_pushes_to_queue(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        detector = _StubDetector(q)
        ev = _event("git_commit")
        await detector.emit(ev)
        assert q.qsize() == 1
        assert await q.get() is ev

    async def test_emit_rejects_non_change_event(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        detector = _StubDetector(q)
        with pytest.raises(DetectorError, match="ChangeEvent"):
            await detector.emit({"not": "an event"})  # type: ignore[arg-type]

    async def test_emit_rejects_source_mismatch(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        detector = _StubDetector(q)
        ev = _event("file_snapshot")
        with pytest.raises(DetectorError, match="Source mismatch"):
            await detector.emit(ev)


class TestLifecycle:
    """start / stop / health round-trip."""

    async def test_lifecycle_round_trip(self) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        detector = _StubDetector(q)
        assert await detector.health() == DetectorStatus.STOPPED
        await detector.start()
        assert await detector.health() == DetectorStatus.HEALTHY
        await detector.stop()
        assert await detector.health() == DetectorStatus.STOPPED
