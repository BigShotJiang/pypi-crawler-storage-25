"""Tests for backend.auth.credential_manager — credential storage backends.

Covers: all three backends (env, keyring, file vault), priority ordering,
rotation atomicity, missing key handling, and error conditions.
"""

from __future__ import annotations

from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

from backend.auth.credential_manager import (
    CredentialError,
    CredentialManager,
    FileVault,
)
from backend.config import CredentialConfig

if TYPE_CHECKING:
    from pathlib import Path

    import pytest

# Low iterations for fast test execution
_TEST_ITERATIONS = 1000


def _file_config(tmp_path: Path) -> CredentialConfig:
    return CredentialConfig(backend="file", vault_path=str(tmp_path / "vault.enc"))


def _keyring_config() -> CredentialConfig:
    return CredentialConfig(backend="keyring")


def _env_config() -> CredentialConfig:
    return CredentialConfig(backend="env")


# ---------------------------------------------------------------------------
# FileVault direct tests
# ---------------------------------------------------------------------------


class TestFileVault:
    """AES-256-GCM encrypted file vault operations."""

    def test_set_and_get(self, tmp_path: Path) -> None:
        vault = FileVault(tmp_path / "v.enc", "pass", iterations=_TEST_ITERATIONS)
        vault.set("github:secret", "my-secret")
        assert vault.get("github:secret") == "my-secret"

    def test_get_missing_key(self, tmp_path: Path) -> None:
        vault = FileVault(tmp_path / "v.enc", "pass", iterations=_TEST_ITERATIONS)
        assert vault.get("missing:key") is None

    def test_get_from_empty_vault(self, tmp_path: Path) -> None:
        vault = FileVault(tmp_path / "v.enc", "pass", iterations=_TEST_ITERATIONS)
        assert vault.get("any:key") is None

    def test_overwrite_value(self, tmp_path: Path) -> None:
        vault = FileVault(tmp_path / "v.enc", "pass", iterations=_TEST_ITERATIONS)
        vault.set("k", "v1")
        vault.set("k", "v2")
        assert vault.get("k") == "v2"

    def test_multiple_entries(self, tmp_path: Path) -> None:
        vault = FileVault(tmp_path / "v.enc", "pass", iterations=_TEST_ITERATIONS)
        vault.set("a", "alpha")
        vault.set("b", "beta")
        assert vault.get("a") == "alpha"
        assert vault.get("b") == "beta"

    def test_delete_entry(self, tmp_path: Path) -> None:
        vault = FileVault(tmp_path / "v.enc", "pass", iterations=_TEST_ITERATIONS)
        vault.set("k", "v")
        vault.delete("k")
        assert vault.get("k") is None

    def test_delete_nonexistent_no_error(self, tmp_path: Path) -> None:
        vault = FileVault(tmp_path / "v.enc", "pass", iterations=_TEST_ITERATIONS)
        vault.delete("nonexistent")

    def test_persistence_across_instances(self, tmp_path: Path) -> None:
        path = tmp_path / "v.enc"
        FileVault(path, "pass", iterations=_TEST_ITERATIONS).set("k", "persistent")
        assert FileVault(path, "pass", iterations=_TEST_ITERATIONS).get("k") == "persistent"

    def test_wrong_passphrase_fails(self, tmp_path: Path) -> None:
        path = tmp_path / "v.enc"
        FileVault(path, "correct", iterations=_TEST_ITERATIONS).set("k", "v")
        import pytest

        with pytest.raises(CredentialError, match="Failed to decrypt"):
            FileVault(path, "wrong", iterations=_TEST_ITERATIONS).get("k")


# ---------------------------------------------------------------------------
# Env backend
# ---------------------------------------------------------------------------


class TestEnvBackend:
    """Environment variable credential backend."""

    def test_get_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("CODELEDGER_CRED_GITHUB_CLIENT_SECRET", "env-secret")
        cm = CredentialManager(_env_config())
        assert cm.get("github", "client_secret") == "env-secret"

    def test_env_not_set_returns_none(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("CODELEDGER_CRED_GITHUB_MISSING", raising=False)
        cm = CredentialManager(_env_config())
        assert cm.get("github", "missing") is None

    def test_env_write_raises(self) -> None:
        import pytest

        cm = CredentialManager(_env_config())
        with pytest.raises(CredentialError, match="env-only"):
            cm.set("github", "key", "value")

    def test_env_delete_raises(self) -> None:
        import pytest

        cm = CredentialManager(_env_config())
        with pytest.raises(CredentialError, match="env-only"):
            cm.delete("github", "key")


# ---------------------------------------------------------------------------
# Keyring backend (mocked)
# ---------------------------------------------------------------------------


class TestKeyringBackend:
    """OS keyring credential backend (all keyring calls mocked)."""

    @patch("backend.auth.credential_manager.keyring_lib")
    def test_get(self, mock_kr: MagicMock) -> None:
        mock_kr.get_password.return_value = "kr-secret"
        cm = CredentialManager(_keyring_config())
        assert cm.get("github", "client_secret") == "kr-secret"
        mock_kr.get_password.assert_called_with("codeledger:github", "client_secret")

    @patch("backend.auth.credential_manager.keyring_lib")
    def test_set(self, mock_kr: MagicMock) -> None:
        cm = CredentialManager(_keyring_config())
        cm.set("github", "token", "new-token")
        mock_kr.set_password.assert_called_with(
            "codeledger:github", "token", "new-token"
        )

    @patch("backend.auth.credential_manager.keyring_lib")
    def test_delete(self, mock_kr: MagicMock) -> None:
        cm = CredentialManager(_keyring_config())
        cm.delete("github", "token")
        mock_kr.delete_password.assert_called_with("codeledger:github", "token")

    @patch("backend.auth.credential_manager.keyring_lib")
    def test_get_missing_via_fallback(
        self, mock_kr: MagicMock, tmp_path: Path
    ) -> None:
        # Keyring unavailable (probe raises). Unknown key → None via the
        # encrypted file fallback rather than a crash.
        mock_kr.get_password.side_effect = Exception("NoKeyringError")
        cfg = CredentialConfig(
            backend="keyring", vault_path=str(tmp_path / "vault.enc")
        )
        cm = CredentialManager(cfg, _iterations=_TEST_ITERATIONS)
        assert cm.get("github", "missing") is None

    @patch("backend.auth.credential_manager.keyring_lib")
    def test_set_writes_to_fallback_when_keyring_unavailable(
        self, mock_kr: MagicMock, tmp_path: Path
    ) -> None:
        # Keyring unavailable (probe + set both fail). set() must not crash —
        # it falls back to the encrypted file vault. This is the regression
        # fix: clean installs on headless Linux were crashing here.
        mock_kr.get_password.side_effect = Exception("NoKeyringError")
        mock_kr.set_password.side_effect = Exception("NoKeyringError")
        cfg = CredentialConfig(
            backend="keyring", vault_path=str(tmp_path / "vault.enc")
        )
        cm = CredentialManager(cfg, _iterations=_TEST_ITERATIONS)
        cm.set("github", "key", "value")
        assert cm.get("github", "key") == "value"

    @patch("backend.auth.credential_manager.keyring_lib")
    def test_delete_falls_back_when_keyring_unavailable(
        self, mock_kr: MagicMock, tmp_path: Path
    ) -> None:
        mock_kr.get_password.side_effect = Exception("NoKeyringError")
        mock_kr.delete_password.side_effect = Exception("NoKeyringError")
        cfg = CredentialConfig(
            backend="keyring", vault_path=str(tmp_path / "vault.enc")
        )
        cm = CredentialManager(cfg, _iterations=_TEST_ITERATIONS)
        cm.set("github", "key", "value")
        cm.delete("github", "key")
        assert cm.get("github", "key") is None


# ---------------------------------------------------------------------------
# File vault via CredentialManager
# ---------------------------------------------------------------------------


class TestFileVaultBackend:
    """File vault backend accessed through CredentialManager."""

    def test_set_and_get(self, tmp_path: Path) -> None:
        cm = CredentialManager(
            _file_config(tmp_path), passphrase="p", _iterations=_TEST_ITERATIONS
        )
        cm.set("github", "secret", "my-secret")
        assert cm.get("github", "secret") == "my-secret"

    def test_delete(self, tmp_path: Path) -> None:
        cm = CredentialManager(
            _file_config(tmp_path), passphrase="p", _iterations=_TEST_ITERATIONS
        )
        cm.set("github", "secret", "val")
        cm.delete("github", "secret")
        assert cm.get("github", "secret") is None

    def test_missing_passphrase_raises(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import pytest

        monkeypatch.delenv("CODELEDGER_VAULT_PASSPHRASE", raising=False)
        with pytest.raises(CredentialError, match="passphrase"):
            CredentialManager(_file_config(tmp_path))


# ---------------------------------------------------------------------------
# Priority ordering
# ---------------------------------------------------------------------------


class TestPriorityOrder:
    """Env vars override keyring, keyring overrides file vault."""

    @patch("backend.auth.credential_manager.keyring_lib")
    def test_env_overrides_keyring(
        self, mock_kr: MagicMock, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("CODELEDGER_CRED_GITHUB_TOKEN", "from-env")
        mock_kr.get_password.return_value = "from-keyring"
        cm = CredentialManager(_keyring_config())
        assert cm.get("github", "token") == "from-env"
        mock_kr.get_password.assert_not_called()

    @patch("backend.auth.credential_manager.keyring_lib")
    def test_env_overrides_file_vault(
        self, mock_kr: MagicMock, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("CODELEDGER_CRED_GITHUB_TOKEN", "from-env")
        cm = CredentialManager(
            _file_config(tmp_path), passphrase="p", _iterations=_TEST_ITERATIONS
        )
        cm.set("github", "token", "from-vault")
        assert cm.get("github", "token") == "from-env"

    @patch("backend.auth.credential_manager.keyring_lib")
    def test_keyring_fallback_to_file_vault(
        self, mock_kr: MagicMock, tmp_path: Path
    ) -> None:
        mock_kr.get_password.return_value = None
        cm = CredentialManager(
            _file_config(tmp_path), passphrase="p", _iterations=_TEST_ITERATIONS
        )
        cm.set("github", "token", "from-vault")
        assert cm.get("github", "token") == "from-vault"


# ---------------------------------------------------------------------------
# Rotation atomicity
# ---------------------------------------------------------------------------


class TestRotation:
    """Credential rotation preserves old value on write failure."""

    def test_rotation_updates_value(self, tmp_path: Path) -> None:
        cm = CredentialManager(
            _file_config(tmp_path), passphrase="p", _iterations=_TEST_ITERATIONS
        )
        cm.set("github", "token", "old")
        cm.rotate("github", "token", "new")
        assert cm.get("github", "token") == "new"

    def test_rotation_failure_preserves_old(self, tmp_path: Path) -> None:
        import pytest

        cm = CredentialManager(
            _file_config(tmp_path), passphrase="p", _iterations=_TEST_ITERATIONS
        )
        cm.set("github", "token", "old")

        assert cm._file_vault is not None
        with (
            patch.object(
                cm._file_vault, "_write_all", side_effect=OSError("disk full")
            ),
            pytest.raises(OSError, match="disk full"),
        ):
            cm.rotate("github", "token", "new")

        assert cm.get("github", "token") == "old"

    @patch("backend.auth.credential_manager.keyring_lib")
    def test_rotation_keyring(self, mock_kr: MagicMock) -> None:
        cm = CredentialManager(_keyring_config())
        cm.rotate("github", "token", "rotated")
        mock_kr.set_password.assert_called_with(
            "codeledger:github", "token", "rotated"
        )


class TestVaultPathResolution:
    """Relative ``vault_path`` must anchor to ``project_root``, not CWD.

    Regression guard for deployments where the server is launched from
    a directory other than the project root. Before the fix, a relative
    ``vault.enc`` would silently resolve to ``CWD/vault.enc`` and every
    token lookup returned None → 401 on every login.
    """

    def test_relative_vault_resolves_against_project_root(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        project_dir = tmp_path / "proj"
        project_dir.mkdir()
        elsewhere = tmp_path / "elsewhere"
        elsewhere.mkdir()
        monkeypatch.chdir(elsewhere)

        cfg = CredentialConfig(backend="file", vault_path="vault.enc")
        cm = CredentialManager(
            cfg,
            passphrase="p",
            project_root=project_dir,
            _iterations=_TEST_ITERATIONS,
        )
        cm.set("solo", "token", "cl_solo_abc")
        assert (project_dir / "vault.enc").is_file()
        assert not (elsewhere / "vault.enc").exists()
        assert cm.get("solo", "token") == "cl_solo_abc"
