"""Tests for backend.advanced.tautology_detector."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from backend.advanced.tautology_detector import TautologyDetector
from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.ast_tracker import ASTTracker
from backend.models import Story

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
async def db(tmp_path: Path) -> SQLiteBackend:
    backend = SQLiteBackend(tmp_path / "taut.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def detector(db: SQLiteBackend) -> TautologyDetector:
    return TautologyDetector(db=db, ast_tracker=ASTTracker(db=db))


async def _seed_story(db: SQLiteBackend, criteria: list[str]) -> str:
    story = Story(
        title="Authentication enforcement",
        description="Users must be authenticated to access protected routes.",
        acceptance_criteria=criteria,
    )
    await db.insert("stories", story.to_dict())
    return str(story.id)


class TestCheckTests:
    async def test_grounded_test_is_not_flagged(
        self,
        db: SQLiteBackend,
        detector: TautologyDetector,
        tmp_path: Path,
    ) -> None:
        await _seed_story(
            db,
            [
                "Unauthenticated requests return 401.",
                "Valid bearer tokens succeed with 200.",
            ],
        )
        proj = tmp_path / "proj"
        (proj / "tests").mkdir(parents=True)
        (proj / "tests" / "test_auth.py").write_text(
            "def test_unauthenticated_returns_401():\n"
            "    response = call_endpoint_unauthenticated()\n"
            "    assert response.status_code == 401\n"
            "    assert response.authenticated is False\n"
        )
        report = await detector.check_tests("p1", str(proj))
        # Some flags may come from other heuristics; verify the grounded test
        # is not in the flags list.
        flagged_names = {f.test_function for f in report.flags}
        assert "test_unauthenticated_returns_401" not in flagged_names

    async def test_empty_assertions_flagged(
        self, db: SQLiteBackend, detector: TautologyDetector, tmp_path: Path
    ) -> None:
        await _seed_story(db, ["Some criterion."])
        proj = tmp_path / "proj"
        (proj / "tests").mkdir(parents=True)
        (proj / "tests" / "test_empty.py").write_text(
            "def test_no_assertions():\n    do_something()\n"
        )
        report = await detector.check_tests("p1", str(proj))
        assert any(
            f.test_function == "test_no_assertions"
            and f.reason.startswith("Test has no assertions")
            for f in report.flags
        )

    async def test_ungrounded_assertion_flagged(
        self, db: SQLiteBackend, detector: TautologyDetector, tmp_path: Path
    ) -> None:
        await _seed_story(
            db, ["Invoice totals must match the sum of line items."]
        )
        proj = tmp_path / "proj"
        (proj / "tests").mkdir(parents=True)
        (proj / "tests" / "test_trivial.py").write_text(
            "def test_addition_is_commutative():\n"
            "    assert 1 + 2 == 2 + 1\n"
        )
        report = await detector.check_tests("p1", str(proj))
        assert any(
            f.test_function == "test_addition_is_commutative"
            for f in report.flags
        )

    async def test_no_stories_flags_everything(
        self, detector: TautologyDetector, tmp_path: Path
    ) -> None:
        proj = tmp_path / "proj"
        (proj / "tests").mkdir(parents=True)
        (proj / "tests" / "test_any.py").write_text(
            "def test_a():\n    assert True\n"
        )
        report = await detector.check_tests("p1", str(proj))
        assert any(f.test_function == "test_a" for f in report.flags)

    async def test_missing_tests_dir_returns_empty(
        self, detector: TautologyDetector, tmp_path: Path
    ) -> None:
        proj = tmp_path / "proj"
        proj.mkdir()
        report = await detector.check_tests("p1", str(proj))
        assert report.flags == []

    async def test_report_shape(
        self, detector: TautologyDetector, tmp_path: Path
    ) -> None:
        proj = tmp_path / "proj"
        (proj / "tests").mkdir(parents=True)
        (proj / "tests" / "test_x.py").write_text(
            "def test_x():\n    assert 1 == 1\n"
        )
        report = await detector.check_tests_report("p1", str(proj))
        assert report["project_id"] == "p1"
        assert "flags" in report
        assert "inspected_tests" in report
