"""Coverage tests for backend.intelligence.staleness_scorer branches.

Exercises the drift sensor, coverage sensor, contradictions, and conflict
persistence paths that the main tests skip.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.staleness_scorer import StalenessScorer
from backend.models import Decision, DecisionConflict

if TYPE_CHECKING:
    from pathlib import Path


async def _mk_scorer(tmp_path: Path) -> tuple[StalenessScorer, SQLiteBackend]:
    db = SQLiteBackend(tmp_path / "stale.db")
    await db.connect()
    await apply_migrations(db)
    return StalenessScorer(db=db), db


class TestEmptyProject:
    async def test_empty_project_returns_empty_list(
        self, tmp_path: Path
    ) -> None:
        """An empty DB yields an empty staleness report, no crash."""
        scorer, db = await _mk_scorer(tmp_path)
        try:
            out = await scorer.score_project("p1")
            assert out == []
        finally:
            await db.close()


class TestSingleDecisionScoring:
    async def test_fresh_decision_returns_score_tuple(
        self, tmp_path: Path
    ) -> None:
        scorer, db = await _mk_scorer(tmp_path)
        try:
            d = Decision(title="Fresh", description="just added")
            await db.insert("decisions", d.to_dict())
            score, signals = await scorer.score_decision(str(d.id))
            assert 0.0 <= score <= 1.0
            assert isinstance(signals, list)
        finally:
            await db.close()

    async def test_old_decision_has_higher_staleness(
        self, tmp_path: Path
    ) -> None:
        scorer, db = await _mk_scorer(tmp_path)
        try:
            old_iso = (datetime.now(UTC) - timedelta(days=400)).isoformat()
            d = Decision(title="Ancient")
            payload = d.to_dict()
            payload["created_at"] = old_iso
            payload["updated_at"] = old_iso
            await db.insert("decisions", payload)
            fresh = Decision(title="Fresh")
            await db.insert("decisions", fresh.to_dict())
            old_score, _ = await scorer.score_decision(str(d.id))
            fresh_score, _ = await scorer.score_decision(str(fresh.id))
            # Both decisions lack provenance edges, so the coverage sensor
            # contributes equally; the age sensor should tip the balance.
            assert old_score >= fresh_score
        finally:
            await db.close()

    async def test_nonexistent_decision_raises(
        self, tmp_path: Path
    ) -> None:
        from backend.intelligence.staleness_scorer import StalenessScorerError
        scorer, db = await _mk_scorer(tmp_path)
        try:
            import uuid

            with pytest.raises(StalenessScorerError, match="not found"):
                await scorer.score_decision(str(uuid.uuid4()))
        finally:
            await db.close()


class TestCoverageContribution:
    async def test_unlinked_decision_flagged_as_aspirational(
        self, tmp_path: Path
    ) -> None:
        """A decision with no ProvenanceEdge rows receives the coverage-penalty signal."""
        scorer, db = await _mk_scorer(tmp_path)
        try:
            d = Decision(title="Unlinked")
            await db.insert("decisions", d.to_dict())
            score, signals = await scorer.score_decision(str(d.id))
            joined = " ".join(signals).lower()
            assert "aspirational" in joined or "never implemented" in joined
        finally:
            await db.close()


class TestContradictions:
    async def test_contradictions_on_empty_project(
        self, tmp_path: Path
    ) -> None:
        """No decisions → no contradictions."""
        scorer, db = await _mk_scorer(tmp_path)
        try:
            pairs = await scorer.detect_contradictions("p1")
            assert pairs == []
        finally:
            await db.close()

    async def test_single_decision_has_no_contradictions(
        self, tmp_path: Path
    ) -> None:
        scorer, db = await _mk_scorer(tmp_path)
        try:
            d = Decision(title="Alone")
            await db.insert("decisions", d.to_dict())
            pairs = await scorer.detect_contradictions("p1")
            assert pairs == []
        finally:
            await db.close()


class TestConflictPersistence:
    async def test_persist_conflict_roundtrips(
        self, tmp_path: Path
    ) -> None:
        """_persist_conflict inserts a row that _load_active_conflicts returns."""
        scorer, db = await _mk_scorer(tmp_path)
        try:
            d1 = Decision(title="A", description="a")
            d2 = Decision(title="B", description="b")
            await db.insert("decisions", d1.to_dict())
            await db.insert("decisions", d2.to_dict())
            c = DecisionConflict(
                project_id="p1",
                decision_id_a=d1.id,
                decision_id_b=d2.id,
                conflict_type="logical_contradiction",
                confidence=0.9,
                description="test",
            )
            await scorer._persist_conflict(c)
            loaded = await scorer._load_active_conflicts("p1")
            assert isinstance(loaded, list)
        finally:
            await db.close()
