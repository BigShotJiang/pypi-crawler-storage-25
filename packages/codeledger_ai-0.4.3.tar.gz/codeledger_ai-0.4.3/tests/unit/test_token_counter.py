"""Unit tests for backend/utils/token_counter.py.

Verifies tiktoken wrapper behaviour: single counts, batch counts, budget
estimation with varied fit scenarios, and Unicode/edge-case handling.
"""

from __future__ import annotations

import pytest

from backend.utils.token_counter import (
    count_tokens,
    count_tokens_batch,
    estimate_budget_usage,
)


class TestCountTokens:
    """Single-string token counting."""

    def test_empty_string_returns_zero(self) -> None:
        assert count_tokens("") == 0

    def test_simple_ascii_returns_positive_int(self) -> None:
        n = count_tokens("hello world")
        assert isinstance(n, int)
        assert n > 0

    def test_known_short_phrase(self) -> None:
        # "hello world" encodes to exactly 2 tokens in cl100k_base.
        assert count_tokens("hello world") == 2

    def test_longer_text_produces_more_tokens(self) -> None:
        short = count_tokens("one")
        long = count_tokens("one two three four five six seven eight nine ten")
        assert long > short

    def test_unicode_text_counts_correctly(self) -> None:
        # Non-ASCII characters typically require multiple byte-level tokens
        ascii_n = count_tokens("hello")
        unicode_n = count_tokens("héllo 你好 🌍")
        assert ascii_n > 0
        assert unicode_n > 0

    def test_repeated_calls_return_same_count(self) -> None:
        n1 = count_tokens("deterministic output check")
        n2 = count_tokens("deterministic output check")
        assert n1 == n2

    def test_non_string_raises_type_error(self) -> None:
        with pytest.raises(TypeError):
            count_tokens(123)  # type: ignore[arg-type]

    def test_none_raises_type_error(self) -> None:
        with pytest.raises(TypeError):
            count_tokens(None)  # type: ignore[arg-type]


class TestCountTokensBatch:
    """Batch token counting."""

    def test_empty_list_returns_empty_list(self) -> None:
        assert count_tokens_batch([]) == []

    def test_single_item_batch(self) -> None:
        result = count_tokens_batch(["hello world"])
        assert result == [2]

    def test_batch_preserves_order(self) -> None:
        texts = ["a", "a b c d e", "hi"]
        result = count_tokens_batch(texts)
        assert len(result) == 3
        assert result[1] > result[0]
        assert result[1] > result[2]

    def test_batch_matches_individual_counts(self) -> None:
        texts = ["first sample", "second sample with more words", "third"]
        batch_counts = count_tokens_batch(texts)
        individual = [count_tokens(t) for t in texts]
        assert batch_counts == individual

    def test_batch_with_empty_strings(self) -> None:
        result = count_tokens_batch(["", "hello", ""])
        assert result[0] == 0
        assert result[1] > 0
        assert result[2] == 0

    def test_non_list_raises(self) -> None:
        with pytest.raises(TypeError):
            count_tokens_batch("not a list")  # type: ignore[arg-type]

    def test_list_with_non_string_raises(self) -> None:
        with pytest.raises(TypeError):
            count_tokens_batch(["ok", 123])  # type: ignore[list-item]


class TestEstimateBudgetUsage:
    """Budget estimation across context item lists."""

    def test_all_items_fit_within_budget(self) -> None:
        items = [{"text": "short one"}, {"text": "short two"}]
        result = estimate_budget_usage(items, budget=1000)
        assert result["items_that_fit"] == 2
        assert result["total_tokens"] > 0
        assert result["remaining_budget"] < 1000
        assert result["remaining_budget"] == 1000 - result["total_tokens"]

    def test_items_exceed_budget(self) -> None:
        items = [{"text": "word " * 100} for _ in range(5)]
        result = estimate_budget_usage(items, budget=50)
        assert result["items_that_fit"] < 5
        assert result["remaining_budget"] >= 0

    def test_zero_budget_fits_nothing(self) -> None:
        items = [{"text": "any"}]
        result = estimate_budget_usage(items, budget=0)
        assert result["items_that_fit"] == 0
        assert result["remaining_budget"] == 0

    def test_empty_items_list(self) -> None:
        result = estimate_budget_usage([], budget=100)
        assert result["total_tokens"] == 0
        assert result["items_that_fit"] == 0
        assert result["remaining_budget"] == 100

    def test_items_missing_text_field_contribute_zero(self) -> None:
        items = [{"text": "real"}, {"other": "nope"}, {"text": "real again"}]
        result = estimate_budget_usage(items, budget=1000)
        # The item without "text" contributes 0 but still "fits"
        assert result["items_that_fit"] == 3

    def test_exact_fit(self) -> None:
        # Build a budget that exactly matches first item
        items = [{"text": "hello world"}, {"text": "extra"}]
        first_count = count_tokens("hello world")
        result = estimate_budget_usage(items, budget=first_count)
        assert result["items_that_fit"] == 1
        assert result["remaining_budget"] == 0

    def test_negative_budget_raises(self) -> None:
        with pytest.raises(ValueError):
            estimate_budget_usage([], budget=-1)

    def test_non_int_budget_raises(self) -> None:
        with pytest.raises(TypeError):
            estimate_budget_usage([], budget="100")  # type: ignore[arg-type]

    def test_non_list_items_raises(self) -> None:
        with pytest.raises(TypeError):
            estimate_budget_usage("not a list", budget=10)  # type: ignore[arg-type]

    def test_total_tokens_counts_all_regardless_of_fit(self) -> None:
        items = [{"text": "word " * 50} for _ in range(3)]
        result = estimate_budget_usage(items, budget=10)
        # total_tokens should be the sum over all items, even though only
        # some fit
        assert result["total_tokens"] > 10
        assert result["items_that_fit"] <= 3

    def test_budget_stops_at_first_overflow(self) -> None:
        small = count_tokens("tiny")
        big_text = "word " * 200
        items = [
            {"text": "tiny"},
            {"text": big_text},
            {"text": "tiny"},
        ]
        # Budget fits only the first tiny item
        result = estimate_budget_usage(items, budget=small)
        assert result["items_that_fit"] == 1
