"""Tests for backend.detection.registry — :class:`DetectorRegistry`.

Covers: idempotent same-source switch, happy-path preference update,
drain-under-load timeout, serialised concurrent switches, invalid
inputs, and the ``status`` response shape.
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.detection.agent_reported import AgentReportedDetector
from backend.detection.events import ChangeEvent
from backend.detection.file_snapshot import FileSnapshotDetector
from backend.detection.git_commit import GitCommitDetector
from backend.detection.registry import (
    DetectorRegistry,
    DetectorRegistryError,
    SwitchResult,
)

if TYPE_CHECKING:
    from pathlib import Path


pytestmark = pytest.mark.asyncio


@pytest.fixture
async def backend(tmp_path: Path) -> SQLiteBackend:
    db = SQLiteBackend(tmp_path / "reg.db")
    await db.connect()
    await apply_migrations(db)
    yield db
    await db.close()


async def _make_registry(
    db: SQLiteBackend, *, queue: asyncio.Queue[ChangeEvent] | None = None
) -> tuple[DetectorRegistry, asyncio.Queue[ChangeEvent]]:
    q: asyncio.Queue[ChangeEvent] = queue or asyncio.Queue()
    detectors = {
        "git_commit": GitCommitDetector(q),
        "file_snapshot": FileSnapshotDetector(q),
        "agent_reported": AgentReportedDetector(q),
    }
    for d in detectors.values():
        await d.start()
    return DetectorRegistry(db, q, detectors), q


def _event(source: str = "git_commit") -> ChangeEvent:
    return ChangeEvent(
        change_event_source=source,  # type: ignore[arg-type]
        actor_type="human",
        actor_id=None,
        project_id="proj",
        created_at=datetime.now(UTC),
    )


class TestConstruction:
    async def test_requires_all_three_sources(
        self, backend: SQLiteBackend
    ) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        with pytest.raises(DetectorRegistryError, match="allowed sources"):
            DetectorRegistry(backend, q, {"git_commit": GitCommitDetector(q)})

    async def test_rejects_extra_sources(
        self, backend: SQLiteBackend
    ) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        detectors = {
            "git_commit": GitCommitDetector(q),
            "file_snapshot": FileSnapshotDetector(q),
            "agent_reported": AgentReportedDetector(q),
            "svn": GitCommitDetector(q),  # extraneous
        }
        with pytest.raises(DetectorRegistryError, match="allowed sources"):
            DetectorRegistry(backend, q, detectors)


class TestDefaultPreference:
    async def test_unknown_project_defaults_to_git_commit(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        assert await registry.get_preferred_source("new-proj") == "git_commit"


class TestSwitchSource:
    async def test_first_switch_persists_preference(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        result = await registry.switch_source("proj", "file_snapshot")
        assert result.success
        assert result.previous_source == "git_commit"
        assert result.new_source == "file_snapshot"
        assert await registry.get_preferred_source("proj") == "file_snapshot"

    async def test_switch_to_same_source_is_noop_success(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        await registry.switch_source("proj", "file_snapshot")
        result = await registry.switch_source("proj", "file_snapshot")
        assert result.success and result.reason == "noop"

    async def test_switch_to_agent_reported(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        result = await registry.switch_source("proj", "agent_reported")
        assert result.success
        assert await registry.get_preferred_source("proj") == "agent_reported"

    async def test_invalid_source_rejected(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        result = await registry.switch_source("proj", "nope")
        assert not result.success
        assert result.reason == "invalid_source"

    async def test_empty_project_id_rejected(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        result = await registry.switch_source("   ", "file_snapshot")
        assert not result.success
        assert result.reason == "invalid_project_id"


class TestDrainPolicy:
    async def test_queue_empty_drains_immediately(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        result = await registry.switch_source(
            "proj", "file_snapshot", drain_timeout_s=1
        )
        assert result.success

    async def test_queue_not_drained_refuses_switch(
        self, backend: SQLiteBackend
    ) -> None:
        q: asyncio.Queue[ChangeEvent] = asyncio.Queue()
        registry, _ = await _make_registry(backend, queue=q)
        # Fill the queue and never drain it.
        await q.put(_event())
        result = await registry.switch_source(
            "proj", "file_snapshot", drain_timeout_s=1
        )
        assert not result.success
        assert result.reason == "queue_not_drained"
        assert result.events_remaining == 1
        # Preference unchanged.
        assert await registry.get_preferred_source("proj") == "git_commit"


class TestConcurrentSwitches:
    async def test_serialised_per_project(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        # Launch two switches on the same project concurrently. Both
        # should succeed; the final preference is whichever ran last,
        # but neither should corrupt the DB row.
        results = await asyncio.gather(
            registry.switch_source("proj", "file_snapshot"),
            registry.switch_source("proj", "agent_reported"),
        )
        assert all(isinstance(r, SwitchResult) for r in results)
        assert all(r.success for r in results)
        final = await registry.get_preferred_source("proj")
        assert final in {"file_snapshot", "agent_reported"}


class TestStatus:
    async def test_status_shape(self, backend: SQLiteBackend) -> None:
        registry, q = await _make_registry(backend)
        status = await registry.status("proj")
        assert set(status) == {
            "project_id",
            "current_source",
            "actor_config",
            "detector_health",
            "queue_depth",
        }
        assert status["current_source"] == "git_commit"
        assert status["actor_config"] == {
            "types_allowed": [
                "agent",
                "ci_bot",
                "human",
                "webhook_bot",
            ]
        }
        assert status["queue_depth"] == q.qsize()
        assert status["detector_health"] in {
            "healthy",
            "degraded",
            "stopped",
            "error",
        }

    async def test_status_reflects_new_preference(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        await registry.switch_source("proj", "file_snapshot")
        status = await registry.status("proj")
        assert status["current_source"] == "file_snapshot"


class TestAuditLog:
    async def test_successful_switch_records_audit(
        self, backend: SQLiteBackend
    ) -> None:
        registry, _ = await _make_registry(backend)
        await registry.switch_source("proj", "file_snapshot")
        log = registry.audit_log
        assert len(log) == 1
        assert log[0].previous_source == "git_commit"
        assert log[0].new_source == "file_snapshot"
