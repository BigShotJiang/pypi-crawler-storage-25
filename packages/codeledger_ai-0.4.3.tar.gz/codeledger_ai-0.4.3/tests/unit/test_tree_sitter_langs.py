"""Unit tests for backend/intelligence/tree_sitter_langs.py."""

from __future__ import annotations

import pytest

from backend.intelligence.tree_sitter_langs import (
    LanguageNotSupportedError,
    LanguageRegistry,
)


class TestDetectLanguage:
    @pytest.mark.parametrize(
        ("file_path", "expected"),
        [
            ("foo.py", "python"),
            ("foo.pyi", "python"),
            ("src/foo.ts", "typescript"),
            ("src/Foo.tsx", "typescript"),
            ("bar.js", "javascript"),
            ("bar.jsx", "javascript"),
            ("bar.mjs", "javascript"),
            ("main.go", "go"),
            ("mod.rs", "rust"),
            ("Main.java", "java"),
            ("lib.c", "c"),
            ("lib.h", "c"),
            ("main.cpp", "cpp"),
            ("main.hpp", "cpp"),
            ("main.cc", "cpp"),
            ("main.rb", "ruby"),
            ("Program.cs", "csharp"),
        ],
    )
    def test_detects_language_from_extension(
        self, file_path: str, expected: str
    ) -> None:
        registry = LanguageRegistry()
        assert registry.detect_language(file_path) == expected

    def test_unknown_extension_raises(self) -> None:
        registry = LanguageRegistry()
        with pytest.raises(LanguageNotSupportedError):
            registry.detect_language("README.md")

    def test_empty_path_raises(self) -> None:
        registry = LanguageRegistry()
        with pytest.raises(LanguageNotSupportedError):
            registry.detect_language("")


class TestGetParser:
    @pytest.mark.parametrize(
        "language",
        [
            "python",
            "typescript",
            "javascript",
            "go",
            "rust",
            "java",
            "c",
            "cpp",
            "ruby",
            "csharp",
        ],
    )
    def test_all_supported_languages_load(self, language: str) -> None:
        registry = LanguageRegistry()
        parser = registry.get_parser(language)
        # Parser should actually be able to parse something.
        tree = parser.parse(b" ")
        assert tree.root_node is not None

    def test_case_insensitive(self) -> None:
        registry = LanguageRegistry()
        registry.get_parser("PYTHON")  # must not raise

    def test_unsupported_language_raises(self) -> None:
        registry = LanguageRegistry()
        with pytest.raises(LanguageNotSupportedError):
            registry.get_parser("cobol")


class TestSupportedLists:
    def test_supported_languages_has_ten(self) -> None:
        registry = LanguageRegistry()
        assert len(registry.supported_languages()) == 10
        assert "python" in registry.supported_languages()
        assert "csharp" in registry.supported_languages()

    def test_supported_extensions_include_common(self) -> None:
        registry = LanguageRegistry()
        exts = registry.supported_extensions()
        for ext in [".py", ".ts", ".go", ".rs", ".java", ".cs"]:
            assert ext in exts
