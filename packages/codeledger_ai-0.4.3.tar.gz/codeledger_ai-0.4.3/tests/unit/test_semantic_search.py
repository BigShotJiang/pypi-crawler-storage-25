"""Unit tests for backend/intelligence/semantic_search.py.

The Embedder is stubbed with a deterministic text-to-vector mapping so the
tests control exactly which items rank near which queries. The real
:class:`SqliteVssStore` is used so that these tests also double as an
integration check for semantic_search ↔ vector_store.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pytest

from backend.db.vector_store import DEFAULT_DIM, SqliteVssStore, VectorStoreError
from backend.intelligence.semantic_search import (
    SearchResult,
    SemanticSearch,
    SemanticSearchError,
)

if TYPE_CHECKING:
    from pathlib import Path


def _basis(index: int, dim: int = DEFAULT_DIM) -> list[float]:
    vec = [0.0] * dim
    vec[index] = 1.0
    return vec


def _blend(a: list[float], b: list[float], weight_a: float) -> list[float]:
    weight_b = 1.0 - weight_a
    return [weight_a * x + weight_b * y for x, y in zip(a, b, strict=True)]


class FakeEmbedder:
    """Deterministic embedder keyed on exact-string matches.

    Falls back to a constant vector so unknown strings still produce a
    valid embedding, letting tests assert that they rank below known items
    without raising.
    """

    def __init__(self, mapping: dict[str, list[float]]) -> None:
        self._mapping = mapping
        self.embed_calls: list[str] = []
        # Seed fallback uses the LAST basis vector so it is orthogonal to
        # any test vector that uses the first handful of dimensions.
        self._fallback = _basis(DEFAULT_DIM - 1)

    async def embed_text(self, text: str) -> list[float]:
        self.embed_calls.append(text)
        for key, vector in self._mapping.items():
            if key == text:
                return list(vector)
        return list(self._fallback)

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [await self.embed_text(t) for t in texts]


@pytest.fixture
async def store(tmp_path: Path) -> Any:
    store = SqliteVssStore(tmp_path / "v.db")
    await store.connect()
    yield store
    await store.close()


@pytest.fixture
def embedder() -> FakeEmbedder:
    return FakeEmbedder(
        {
            "authentication and password hashing": _basis(0),
            "Argon2id password storage decision": _blend(
                _basis(0), _basis(1), 0.9
            ),
            "database migrations": _basis(2),
            "vector search with sqlite-vss": _basis(3),
            "how do we store passwords?": _blend(
                _basis(0), _basis(1), 0.85
            ),
        }
    )


@pytest.fixture
async def search(store: SqliteVssStore, embedder: FakeEmbedder) -> SemanticSearch:
    return SemanticSearch(embedder=embedder, vector_store=store)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


class TestIndexItemValidation:
    async def test_empty_item_id_rejected(
        self, search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await search.index_item(
                "", "text", "decision", "proj"
            )

    async def test_non_string_text_rejected(
        self, search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await search.index_item(
                "id-1", 123, "decision", "proj"  # type: ignore[arg-type]
            )

    async def test_empty_item_type_rejected(
        self, search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await search.index_item(
                "id-1", "text", "", "proj"
            )

    async def test_empty_project_id_rejected(
        self, search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await search.index_item(
                "id-1", "text", "decision", ""
            )

    async def test_invalid_metadata_type_rejected(
        self, search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await search.index_item(
                "id-1", "text", "decision", "proj",
                metadata="bad",  # type: ignore[arg-type]
            )


class TestSearchValidation:
    async def test_empty_query_rejected(
        self, search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await search.search("", "proj")

    async def test_empty_project_id_rejected(
        self, search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await search.search("query", "")

    async def test_non_positive_top_k_rejected(
        self, search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await search.search("query", "proj", top_k=0)
        with pytest.raises(SemanticSearchError):
            await search.search("query", "proj", top_k=-5)


# ---------------------------------------------------------------------------
# index_item + search
# ---------------------------------------------------------------------------


class TestIndexAndSearch:
    async def test_indexed_item_is_retrievable(
        self, search: SemanticSearch, embedder: FakeEmbedder
    ) -> None:
        await search.index_item(
            item_id="d-auth",
            text="Argon2id password storage decision",
            item_type="decision",
            project_id="proj-1",
            metadata={"tags": ["auth", "security"]},
        )
        results = await search.search(
            "authentication and password hashing",
            project_id="proj-1",
            top_k=5,
        )
        assert len(results) == 1
        assert isinstance(results[0], SearchResult)
        assert results[0].item_id == "d-auth"
        assert results[0].item_type == "decision"
        assert results[0].metadata["tags"] == ["auth", "security"]
        assert results[0].metadata["text"] == "Argon2id password storage decision"
        # item_type and project_id are NOT in the metadata dict
        assert "item_type" not in results[0].metadata
        assert "project_id" not in results[0].metadata
        # Score is cosine-ish and positive since texts are related
        assert results[0].score > 0.5

    async def test_ranking_matches_cosine_similarity(
        self, search: SemanticSearch
    ) -> None:
        await search.index_item(
            "d-auth",
            "Argon2id password storage decision",
            "decision",
            "proj-1",
        )
        await search.index_item(
            "d-db",
            "database migrations",
            "decision",
            "proj-1",
        )
        await search.index_item(
            "d-vec",
            "vector search with sqlite-vss",
            "decision",
            "proj-1",
        )
        results = await search.search(
            "how do we store passwords?",
            project_id="proj-1",
            top_k=3,
        )
        # d-auth is unambiguously the closest match (blended into the e0/e1
        # plane as the query). d-db and d-vec are both orthogonal to the
        # query (cosine similarity 0), so their relative order is a
        # backend tie-breaking artifact, not a semantic contract.
        assert results[0].item_id == "d-auth"
        assert {r.item_id for r in results[1:]} == {"d-db", "d-vec"}

    async def test_project_isolation(self, search: SemanticSearch) -> None:
        await search.index_item(
            "a", "database migrations", "decision", "proj-A"
        )
        await search.index_item(
            "b", "database migrations", "decision", "proj-B"
        )
        results = await search.search(
            "database migrations", project_id="proj-A", top_k=5
        )
        assert [r.item_id for r in results] == ["a"]

    async def test_reserved_metadata_keys_cannot_be_overridden(
        self, search: SemanticSearch, store: SqliteVssStore
    ) -> None:
        await search.index_item(
            item_id="d-1",
            text="database migrations",
            item_type="decision",
            project_id="proj-real",
            metadata={
                "project_id": "proj-spoofed",
                "item_type": "story",
                "text": "spoofed body",
                "title": "ok",
            },
        )
        raw = await store.get("d-1")
        assert raw is not None
        assert raw["project_id"] == "proj-real"
        assert raw["item_type"] == "decision"
        assert raw["text"] == "database migrations"
        assert raw["title"] == "ok"

    async def test_search_uses_embedder_for_query_text(
        self,
        search: SemanticSearch,
        embedder: FakeEmbedder,
    ) -> None:
        await search.index_item(
            "d-1", "authentication and password hashing",
            "decision", "proj-1",
        )
        embedder.embed_calls.clear()
        await search.search(
            "authentication and password hashing",
            project_id="proj-1",
            top_k=1,
        )
        assert "authentication and password hashing" in embedder.embed_calls


# ---------------------------------------------------------------------------
# search_by_file
# ---------------------------------------------------------------------------


class TestSearchByFile:
    async def test_file_search_uses_path_and_content(
        self, store: SqliteVssStore, embedder: FakeEmbedder
    ) -> None:
        # Extend the fake embedder so the combined file query has a known
        # vector — we mutate the mapping so the fixture still applies.
        path = "backend/auth/credential_manager.py"
        content = "Argon2id password hashing implementation"
        combined = f"{path}\n\n{content}"
        embedder._mapping[combined] = _basis(0)  # type: ignore[attr-defined]

        search = SemanticSearch(embedder=embedder, vector_store=store)
        await search.index_item(
            "d-auth",
            "authentication and password hashing",
            "decision",
            "proj-1",
        )
        await search.index_item(
            "d-db", "database migrations", "decision", "proj-1"
        )
        results = await search.search_by_file(
            file_path=path,
            file_content=content,
            project_id="proj-1",
            top_k=2,
        )
        assert results[0].item_id == "d-auth"

    async def test_file_search_accepts_empty_content(
        self, search: SemanticSearch
    ) -> None:
        # Should not raise even if file content is empty (new file being
        # created). The path alone is the query.
        await search.index_item(
            "d-1", "database migrations", "decision", "proj-1"
        )
        results = await search.search_by_file(
            file_path="db/migrations.py",
            file_content="",
            project_id="proj-1",
            top_k=1,
        )
        assert len(results) == 1

    async def test_empty_file_path_rejected(
        self, search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await search.search_by_file(
                file_path="",
                file_content="body",
                project_id="proj-1",
                top_k=1,
            )


# ---------------------------------------------------------------------------
# reindex_item / remove_item
# ---------------------------------------------------------------------------


class TestReindexItem:
    async def test_reindex_replaces_embedding(
        self,
        store: SqliteVssStore,
        embedder: FakeEmbedder,
    ) -> None:
        search = SemanticSearch(embedder=embedder, vector_store=store)
        # Start: text = "database migrations", vector = _basis(2)
        await search.index_item(
            "d-1", "database migrations", "decision", "proj-1",
            metadata={"tags": ["db"]},
        )
        # Re-index to something that maps to a different vector.
        await search.reindex_item(
            "d-1", "authentication and password hashing"
        )
        # Query close to the old text should no longer rank d-1 first
        results_old = await search.search(
            "database migrations", project_id="proj-1", top_k=1
        )
        assert not results_old or results_old[0].score < 0.99
        # Query close to the new text should now rank d-1 first with high score
        results_new = await search.search(
            "authentication and password hashing",
            project_id="proj-1",
            top_k=1,
        )
        assert results_new[0].item_id == "d-1"
        assert results_new[0].score == pytest.approx(1.0, abs=1e-5)

    async def test_reindex_preserves_metadata(
        self,
        store: SqliteVssStore,
        embedder: FakeEmbedder,
    ) -> None:
        search = SemanticSearch(embedder=embedder, vector_store=store)
        await search.index_item(
            "d-1", "database migrations", "decision", "proj-1",
            metadata={"tags": ["db"], "title": "Migrations plan"},
        )
        await search.reindex_item(
            "d-1", "authentication and password hashing"
        )
        raw = await store.get("d-1")
        assert raw is not None
        assert raw["item_type"] == "decision"
        assert raw["project_id"] == "proj-1"
        assert raw["tags"] == ["db"]
        assert raw["title"] == "Migrations plan"
        assert raw["text"] == "authentication and password hashing"

    async def test_reindex_unknown_item_raises(
        self, search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await search.reindex_item("nope", "new text")

    async def test_reindex_empty_item_id_rejected(
        self, search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await search.reindex_item("", "new text")


class TestRemoveItem:
    async def test_remove_deletes_from_store(
        self, search: SemanticSearch, store: SqliteVssStore
    ) -> None:
        await search.index_item(
            "d-1", "database migrations", "decision", "proj-1"
        )
        assert await store.count(project_id="proj-1") == 1
        await search.remove_item("d-1")
        assert await store.count(project_id="proj-1") == 0

    async def test_remove_missing_is_silent(
        self, search: SemanticSearch
    ) -> None:
        await search.remove_item("never-existed")

    async def test_remove_empty_id_rejected(
        self, search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await search.remove_item("")


# ---------------------------------------------------------------------------
# Duplicate indexing
# ---------------------------------------------------------------------------


class TestDuplicateIndex:
    async def test_duplicate_item_id_raises(
        self, search: SemanticSearch
    ) -> None:
        # The vector store enforces uniqueness; verify the error surfaces.
        await search.index_item(
            "d-1", "database migrations", "decision", "proj-1"
        )
        with pytest.raises(VectorStoreError):
            await search.index_item(
                "d-1", "database migrations", "decision", "proj-1"
            )


# ---------------------------------------------------------------------------
# SearchResult conversion
# ---------------------------------------------------------------------------


class TestSearchResultShape:
    async def test_result_has_expected_fields(
        self, search: SemanticSearch
    ) -> None:
        await search.index_item(
            "d-1",
            "database migrations",
            "decision",
            "proj-1",
            metadata={"tags": ["db"]},
        )
        results = await search.search(
            "database migrations", project_id="proj-1", top_k=1
        )
        r = results[0]
        assert r.item_id == "d-1"
        assert r.item_type == "decision"
        assert r.score == pytest.approx(1.0, abs=1e-5)
        assert r.metadata["tags"] == ["db"]
        assert r.metadata["text"] == "database migrations"


# ---------------------------------------------------------------------------
# Hybrid search (BM25 + vector) + recency decay
# ---------------------------------------------------------------------------


@pytest.fixture
async def hybrid_search(
    tmp_path: Path, embedder: FakeEmbedder
) -> SemanticSearch:
    """SemanticSearch wired with a real SQLite DB so BM25 can build."""
    from backend.db.db_backend import SQLiteBackend
    from backend.db.migrations import apply_migrations

    db = SQLiteBackend(tmp_path / "hybrid.db")
    await db.connect()
    await apply_migrations(db)

    store = SqliteVssStore(tmp_path / "hybrid_vec.db")
    await store.connect()

    yield SemanticSearch(embedder=embedder, vector_store=store, db=db)

    await store.close()
    await db.close()


async def _seed_decision(
    search: SemanticSearch, *, id_: str, text: str, project_id: str = "proj-1"
) -> None:
    assert search._db is not None  # test harness invariant
    import uuid as _uuid
    from datetime import UTC, datetime

    now = datetime.now(UTC).isoformat()
    title, _, desc = text.partition("\n")
    await search._db.insert(
        "decisions",
        {
            "id": id_,
            "title": title,
            "description": desc,
            "tags": "[]",
            "status": "unverified",
            "recorded_by_user_id": None,
            "recorded_in_session_id": None,
            "inference_status": "explicit",
            "inference_confidence": 1.0,
            "created_at": now,
            "updated_at": now,
        },
    )
    _ = _uuid  # keep imported symbol
    await search.index_item(id_, text, "decision", project_id)


class TestHybridSearch:
    async def test_bm25_surfaces_exact_match_missed_by_vector(
        self, hybrid_search: SemanticSearch
    ) -> None:
        # A decision whose body contains the exact term "argon2id" but whose
        # vector sits on the fallback. Seed a few distractors so the BM25
        # IDF has enough corpus to differentiate.
        await _seed_decision(
            hybrid_search, id_="d-argon", text="argon2id password hashing rule"
        )
        await _seed_decision(
            hybrid_search, id_="d-auth", text="authentication and password hashing"
        )
        await _seed_decision(
            hybrid_search, id_="d-db", text="database migrations"
        )
        await _seed_decision(
            hybrid_search, id_="d-vec", text="vector search with sqlite-vss"
        )
        results = await hybrid_search.search(
            "argon2id", project_id="proj-1", top_k=3, blend_weight=0.5
        )
        ids = [r.item_id for r in results]
        assert "d-argon" in ids[:3]

    async def test_pure_vector_misses_keyword_item(
        self, hybrid_search: SemanticSearch
    ) -> None:
        # d-auth embeds on basis-0; d-argon sits on the fallback vector that
        # the FakeEmbedder returns for every unknown string. Pure vector
        # retrieval with the exact-match query "authentication and password
        # hashing" ranks d-auth first, leaving d-argon off the top-1.
        await _seed_decision(
            hybrid_search, id_="d-argon", text="argon2id password hashing rule"
        )
        await _seed_decision(
            hybrid_search,
            id_="d-auth",
            text="authentication and password hashing",
        )
        results = await hybrid_search.search(
            "authentication and password hashing",
            project_id="proj-1",
            top_k=1,
            blend_weight=1.0,
        )
        ids = [r.item_id for r in results]
        assert ids[0] == "d-auth"

    async def test_hybrid_blend_returns_both_types(
        self, hybrid_search: SemanticSearch
    ) -> None:
        await _seed_decision(
            hybrid_search, id_="d-vec", text="authentication and password hashing"
        )
        await _seed_decision(
            hybrid_search, id_="d-kw", text="argon2id password hashing rule"
        )
        results = await hybrid_search.search(
            "authentication and password hashing",
            project_id="proj-1",
            top_k=5,
            blend_weight=0.6,
        )
        methods = {r.retrieval_method for r in results}
        assert methods & {"vector", "bm25", "both"}

    async def test_recency_decay_newer_ranks_higher(
        self, hybrid_search: SemanticSearch
    ) -> None:
        from datetime import UTC, datetime, timedelta

        assert hybrid_search._db is not None
        now = datetime.now(UTC)
        # Two identical items — one fresh, one 180 days old.
        old_ts = (now - timedelta(days=180)).isoformat()
        new_ts = now.isoformat()
        for id_, ts in (("d-old", old_ts), ("d-new", new_ts)):
            await hybrid_search._db.insert(
                "decisions",
                {
                    "id": id_,
                    "title": "password hashing",
                    "description": "argon2id",
                    "tags": "[]",
                    "status": "unverified",
                    "recorded_by_user_id": None,
                    "recorded_in_session_id": None,
                    "inference_status": "explicit",
                    "inference_confidence": 1.0,
                    "created_at": ts,
                    "updated_at": ts,
                },
            )
            await hybrid_search.index_item(
                id_,
                "password hashing argon2id",
                "decision",
                "proj-1",
                metadata={"created_at": ts},
            )
        results = await hybrid_search.search(
            "password hashing argon2id",
            project_id="proj-1",
            top_k=5,
            blend_weight=0.5,
        )
        ids = [r.item_id for r in results]
        assert ids.index("d-new") < ids.index("d-old")

    async def test_bm25_index_invalidation_on_remove(
        self, hybrid_search: SemanticSearch
    ) -> None:
        # BM25 IDF degenerates with very small corpora. Seed a few
        # distractors so the keyword-only scoring returns a positive
        # score for "argon2id" — which only appears in d-gone.
        await _seed_decision(
            hybrid_search, id_="d-other-1", text="feature flags and rollout plan"
        )
        await _seed_decision(
            hybrid_search, id_="d-other-2", text="database migration strategy"
        )
        await _seed_decision(
            hybrid_search, id_="d-other-3", text="api throttling policy"
        )
        await _seed_decision(
            hybrid_search, id_="d-gone", text="argon2id password hashing"
        )
        first = await hybrid_search.search(
            "argon2id", project_id="proj-1", top_k=3, blend_weight=0.0
        )
        assert any(r.item_id == "d-gone" for r in first)

        await hybrid_search.remove_item("d-gone")
        assert hybrid_search._db is not None
        await hybrid_search._db.delete("decisions", "d-gone")

        second = await hybrid_search.search(
            "argon2id", project_id="proj-1", top_k=3, blend_weight=0.0
        )
        assert all(r.item_id != "d-gone" for r in second)

    async def test_bm25_build_under_200ms_for_5000_items(
        self, tmp_path: Path, embedder: FakeEmbedder
    ) -> None:
        import time

        from backend.db.db_backend import SQLiteBackend
        from backend.db.migrations import apply_migrations
        from backend.intelligence.semantic_search import BM25Index

        db = SQLiteBackend(tmp_path / "perf.db")
        await db.connect()
        await apply_migrations(db)
        try:
            now = "2026-01-01T00:00:00+00:00"
            for i in range(5000):
                await db.insert(
                    "decisions",
                    {
                        "id": f"d-{i}",
                        "title": f"Decision {i} about password hashing",
                        "description": f"Body for decision {i}",
                        "tags": "[]",
                        "status": "unverified",
                        "recorded_by_user_id": None,
                        "recorded_in_session_id": None,
                        "inference_status": "explicit",
                        "inference_confidence": 1.0,
                        "created_at": now,
                        "updated_at": now,
                    },
                )
            index = BM25Index(db, "proj-1")
            start = time.perf_counter()
            await index.build()
            elapsed_ms = (time.perf_counter() - start) * 1000
            # Record in the failure message so the benchmark is observable.
            assert elapsed_ms < 200, f"BM25 build took {elapsed_ms:.1f}ms"
        finally:
            await db.close()

    async def test_retrieval_method_field_is_set(
        self, hybrid_search: SemanticSearch
    ) -> None:
        await _seed_decision(
            hybrid_search, id_="d-kw", text="argon2id password hashing"
        )
        await _seed_decision(
            hybrid_search, id_="d-vec", text="authentication and password hashing"
        )
        results = await hybrid_search.search(
            "argon2id", project_id="proj-1", top_k=5, blend_weight=0.5
        )
        for r in results:
            assert r.retrieval_method in {"vector", "bm25", "both"}

    async def test_blend_weight_validation(
        self, hybrid_search: SemanticSearch
    ) -> None:
        with pytest.raises(SemanticSearchError):
            await hybrid_search.search(
                "x", project_id="proj-1", top_k=3, blend_weight=1.5
            )
        with pytest.raises(SemanticSearchError):
            await hybrid_search.search(
                "x", project_id="proj-1", top_k=3, blend_weight=-0.1
            )


# ---------------------------------------------------------------------------
# Staleness penalty in ranking (Prompt 3 upgrade)
# ---------------------------------------------------------------------------


class TestStalenessPenalty:
    """Stale decisions rank lower than identical fresh decisions, but remain visible."""

    async def test_stale_decision_ranks_below_fresh(
        self, hybrid_search: SemanticSearch
    ) -> None:
        assert hybrid_search._db is not None
        # Two decisions with identical text; one carries a staleness_score
        # of 0.9, the other zero.
        now_iso = "2026-01-01T00:00:00+00:00"
        for id_, score in (("d-stale", 0.9), ("d-fresh", 0.0)):
            await hybrid_search._db.insert(
                "decisions",
                {
                    "id": id_,
                    "title": "password hashing rule",
                    "description": "argon2id",
                    "tags": "[]",
                    "status": "unverified",
                    "recorded_by_user_id": None,
                    "recorded_in_session_id": None,
                    "inference_status": "explicit",
                    "inference_confidence": 1.0,
                    "last_accessed_at": None,
                    "access_count": 0,
                    "staleness_score": score,
                    "staleness_signals": "[]",
                    "superseded_by": None,
                    "supersedes": None,
                    "created_at": now_iso,
                    "updated_at": now_iso,
                },
            )
            await hybrid_search.index_item(
                id_,
                "password hashing rule argon2id",
                "decision",
                "proj-1",
                metadata={"created_at": now_iso, "staleness_score": score},
            )
        # Add distractors so BM25 differentiates.
        for i in range(3):
            await _seed_decision(
                hybrid_search,
                id_=f"d-distr-{i}",
                text=f"unrelated filler content number {i}",
            )

        results = await hybrid_search.search(
            "password hashing argon2id",
            project_id="proj-1",
            top_k=5,
            blend_weight=0.5,
        )
        ids = [r.item_id for r in results]
        assert "d-stale" in ids
        assert "d-fresh" in ids
        assert ids.index("d-fresh") < ids.index("d-stale")

    async def test_superseded_decision_still_appears(
        self, hybrid_search: SemanticSearch
    ) -> None:
        assert hybrid_search._db is not None
        now_iso = "2026-01-01T00:00:00+00:00"
        await hybrid_search._db.insert(
            "decisions",
            {
                "id": "d-sup",
                "title": "old password rule",
                "description": "",
                "tags": "[]",
                "status": "unverified",
                "recorded_by_user_id": None,
                "recorded_in_session_id": None,
                "inference_status": "explicit",
                "inference_confidence": 1.0,
                "last_accessed_at": None,
                "access_count": 0,
                "staleness_score": 1.0,
                "staleness_signals": "[]",
                "superseded_by": "d-new",
                "supersedes": None,
                "created_at": now_iso,
                "updated_at": now_iso,
            },
        )
        await hybrid_search.index_item(
            "d-sup",
            "old password rule",
            "decision",
            "proj-1",
            metadata={"staleness_score": 1.0, "superseded_by": "d-new"},
        )
        # Distractors.
        for i in range(2):
            await _seed_decision(
                hybrid_search, id_=f"d-fill-{i}", text=f"filler {i}"
            )
        results = await hybrid_search.search(
            "old password rule",
            project_id="proj-1",
            top_k=5,
            blend_weight=0.5,
        )
        assert any(r.item_id == "d-sup" for r in results)

    async def test_staleness_metadata_applied_from_vector_store(
        self, hybrid_search: SemanticSearch
    ) -> None:
        # When the metadata is in the vector store, the penalty is applied
        # without hitting the database again.
        assert hybrid_search._db is not None
        now_iso = "2026-01-01T00:00:00+00:00"
        await hybrid_search.index_item(
            "d-vec-only",
            "direct from vector store",
            "decision",
            "proj-1",
            metadata={"staleness_score": 0.5, "created_at": now_iso},
        )
        # Minimal DB row so the BM25 rebuild has content.
        await hybrid_search._db.insert(
            "decisions",
            {
                "id": "d-vec-only",
                "title": "direct from vector store",
                "description": "",
                "tags": "[]",
                "status": "unverified",
                "recorded_by_user_id": None,
                "recorded_in_session_id": None,
                "inference_status": "explicit",
                "inference_confidence": 1.0,
                "last_accessed_at": None,
                "access_count": 0,
                "staleness_score": 0.5,
                "staleness_signals": "[]",
                "superseded_by": None,
                "supersedes": None,
                "created_at": now_iso,
                "updated_at": now_iso,
            },
        )
        for i in range(2):
            await _seed_decision(
                hybrid_search, id_=f"d-fill-s-{i}", text=f"x{i}"
            )
        results = await hybrid_search.search(
            "direct from vector store",
            project_id="proj-1",
            top_k=3,
            blend_weight=0.5,
        )
        # Just assert the penalty path did not crash and results is non-empty.
        assert results


# ---------------------------------------------------------------------------
# Conflict warnings in search results (Prompt 6)
# ---------------------------------------------------------------------------


class TestConflictWarnings:
    async def test_conflict_warning_attached_when_both_decisions_retrieved(
        self, hybrid_search: SemanticSearch
    ) -> None:
        assert hybrid_search._db is not None
        from backend.models import DecisionConflict

        now_iso = "2026-01-01T00:00:00+00:00"
        for id_ in ("d-a", "d-b"):
            await hybrid_search._db.insert(
                "decisions",
                {
                    "id": id_,
                    "title": f"Decision {id_}",
                    "description": "argon2id password hashing",
                    "tags": "[]",
                    "status": "passed",
                    "recorded_by_user_id": None,
                    "recorded_in_session_id": None,
                    "inference_status": "explicit",
                    "inference_confidence": 1.0,
                    "last_accessed_at": None,
                    "access_count": 0,
                    "staleness_score": 0.0,
                    "staleness_signals": "[]",
                    "superseded_by": None,
                    "supersedes": None,
                    "created_at": now_iso,
                    "updated_at": now_iso,
                },
            )
            await hybrid_search.index_item(
                id_,
                "argon2id password hashing",
                "decision",
                "proj-1",
                metadata={"created_at": now_iso},
            )
        conflict = DecisionConflict(
            project_id="proj-1",
            decision_id_a="d-a",
            decision_id_b="d-b",
            conflict_type="direct_contradiction",
            confidence=0.85,
            description="opposing directives",
            status="active",
        )
        await hybrid_search._db.insert(
            "decision_conflicts", conflict.to_dict()
        )
        # Filler to give BM25 something to work with.
        for i in range(2):
            await _seed_decision(
                hybrid_search, id_=f"d-filler-{i}", text=f"unrelated {i}"
            )
        results = await hybrid_search.search(
            "argon2id password hashing",
            project_id="proj-1",
            top_k=5,
            blend_weight=0.5,
        )
        warned = [r for r in results if r.conflict_warning is not None]
        assert len(warned) == 2
        ids_with_warnings = {r.item_id for r in warned}
        assert ids_with_warnings == {"d-a", "d-b"}
