"""Unit tests for the ``connectors_*`` handler methods on ``ToolHandlers``.

The MCP tool surface is a thin dispatch over these — tested separately in
``test_mcp_server_connectors.py`` — so these tests exercise the business
logic directly against a real ``ConnectorRegistry`` populated with stub
connectors.
"""

from __future__ import annotations

import asyncio
from typing import Any, ClassVar
from unittest.mock import MagicMock

import pytest

from backend.connectors.base import (
    AbstractConnector,
    AuthType,
    ConnectorCategory,
    ConnectorHealth,
    ConnectorResult,
    ConnectorStatus,
)
from backend.connectors.databases._base import AbstractDatabaseConnector
from backend.connectors.registry import ConnectorRegistry
from backend.mcp.tool_handlers import (
    HandlerError,
    ToolHandlers,
    _connector_result_to_dict,
)


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


class _StubConnector(AbstractConnector):
    slug = "stub"
    display_name = "Stub"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.COMMUNICATION
    oauth_scopes: ClassVar[list[str]] = []
    description = "stub"

    def __init__(
        self,
        cm: _FakeCM,
        *,
        search_results: list[ConnectorResult] | None = None,
        item: ConnectorResult | None = None,
        search_delay: float = 0.0,
        link_returns: bool = True,
    ) -> None:
        super().__init__(cm)
        self._search_results = search_results or []
        self._item = item
        self._search_delay = search_delay
        self._link_returns = link_returns

    def is_configured(self) -> bool:
        return True

    async def health(self) -> ConnectorHealth:
        return ConnectorHealth(
            slug=self.slug,
            status=ConnectorStatus.CONNECTED,
            message="ok",
            configured=True,
        )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        if self._search_delay:
            await asyncio.sleep(self._search_delay)
        return list(self._search_results)

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        return self._item

    async def link_to_decision(
        self, item_id: str, decision_id: str, project_id: str
    ) -> bool:
        return self._link_returns


class _StubDBConnector(AbstractDatabaseConnector):
    slug = "stubdb"
    display_name = "Stub DB"
    description = "stub"

    def __init__(
        self,
        cm: _FakeCM,
        *,
        tables: list[str] | None = None,
        describe: dict[str, dict[str, Any]] | None = None,
        sample: list[dict[str, Any]] | None = None,
    ) -> None:
        super().__init__(cm)
        cm.set("connector_stubdb", "connection_string", "db://x")
        self._tables = tables or []
        self._describe = describe or {}
        self._sample = sample or []

    async def test_connection(self) -> bool:
        return True

    async def list_tables(self) -> list[str]:
        return list(self._tables)

    async def describe_table(self, table: str) -> dict[str, Any]:
        return self._describe.get(table, {"columns": []})

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        return list(self._sample)[:limit]


def _result(title: str, slug: str = "stub", score: float = 0.5) -> ConnectorResult:
    return ConnectorResult(
        item_id=f"{slug}::{title}",
        title=title,
        summary="summary",
        url=None,
        connector_slug=slug,
        item_type="thing",
        relevance_score=score,
    )


def _handlers(
    registry: ConnectorRegistry | None,
) -> ToolHandlers:
    return ToolHandlers(db=MagicMock(), connector_registry=registry)


# ----------------------- _connector_result_to_dict --------------------- #


def test_result_to_dict_preserves_fields() -> None:
    r = _result("launch", score=0.9)
    d = _connector_result_to_dict(r)
    assert d is not None
    assert d["item_id"] == "stub::launch"
    assert d["title"] == "launch"
    assert d["connector_slug"] == "stub"
    assert d["relevance_score"] == 0.9


def test_result_to_dict_none_passes_through() -> None:
    assert _connector_result_to_dict(None) is None


# ----------------------- registry-missing error path ------------------- #


async def test_status_raises_when_registry_missing() -> None:
    with pytest.raises(HandlerError, match="Connector registry"):
        await _handlers(None).connectors_status()


async def test_search_all_raises_when_registry_missing() -> None:
    with pytest.raises(HandlerError):
        await _handlers(None).connectors_search_all(
            query="q", project_id="p"
        )


# ----------------------- status ---------------------------------------- #


async def test_status_returns_dashboard_rows() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_StubConnector(cm))
    out = await _handlers(reg).connectors_status()
    assert out["connectors"][0]["slug"] == "stub"


# ----------------------- search_all / search --------------------------- #


async def test_search_all_merges_and_dicts() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(
        _StubConnector(cm, search_results=[_result("a", score=0.3), _result("b", score=0.9)])
    )
    out = await _handlers(reg).connectors_search_all(
        query="q", project_id="p"
    )
    # Registry sorts by relevance_score descending
    assert [r["title"] for r in out["results"]] == ["b", "a"]
    assert out["results"][0]["relevance_score"] == 0.9


async def test_search_single_connector() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_StubConnector(cm, search_results=[_result("x")]))
    out = await _handlers(reg).connectors_search(
        connector_slug="stub", query="q", project_id="p"
    )
    assert out["results"][0]["title"] == "x"


async def test_search_unknown_slug_raises() -> None:
    reg = ConnectorRegistry()
    with pytest.raises(HandlerError, match="Unknown connector"):
        await _handlers(reg).connectors_search(
            connector_slug="missing", query="q", project_id="p"
        )


async def test_search_timeout_returns_empty() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    # Connector sleeps 0.2s; we patch timeout to 0.05s.
    reg.register(_StubConnector(cm, search_delay=0.2))

    from backend.mcp import tool_handlers as th_module

    original = th_module.CONNECTOR_CALL_TIMEOUT_SECONDS
    try:
        th_module.CONNECTOR_CALL_TIMEOUT_SECONDS = 0.05
        out = await _handlers(reg).connectors_search(
            connector_slug="stub", query="q", project_id="p"
        )
    finally:
        th_module.CONNECTOR_CALL_TIMEOUT_SECONDS = original
    assert out == {"results": []}


# ----------------------- get_item -------------------------------------- #


async def test_get_item_wraps_result_in_dict() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_StubConnector(cm, item=_result("detail")))
    out = await _handlers(reg).connectors_get_item(
        connector_slug="stub", item_id="detail", project_id="p"
    )
    assert out["item"]["title"] == "detail"


async def test_get_item_none_when_connector_returns_none() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_StubConnector(cm))  # item=None by default
    out = await _handlers(reg).connectors_get_item(
        connector_slug="stub", item_id="x", project_id="p"
    )
    assert out == {"item": None}


# ----------------------- link_to_decision ------------------------------ #


async def test_link_to_decision_returns_status() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_StubConnector(cm, link_returns=True))
    out = await _handlers(reg).connectors_link_to_decision(
        connector_slug="stub",
        item_id="i",
        decision_id="d",
        project_id="p",
    )
    assert out == {"linked": True}


# ----------------------- DB handlers ----------------------------------- #


async def test_list_tables_requires_db_connector() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_StubConnector(cm))  # not a DB connector
    with pytest.raises(HandlerError, match="not a database connector"):
        await _handlers(reg).connectors_list_tables(connector_slug="stub")


async def test_list_tables_returns_names() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(_StubDBConnector(cm, tables=["users", "orders"]))
    out = await _handlers(reg).connectors_list_tables(
        connector_slug="stubdb"
    )
    assert out == {"tables": ["users", "orders"]}


async def test_describe_table_returns_columns() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(
        _StubDBConnector(
            cm,
            tables=["users"],
            describe={"users": {"columns": [{"name": "id"}]}},
        )
    )
    out = await _handlers(reg).connectors_describe_table(
        connector_slug="stubdb", table="users"
    )
    assert out["columns"] == [{"name": "id"}]


async def test_sample_rows_returns_rows() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(
        _StubDBConnector(
            cm,
            tables=["users"],
            sample=[{"id": 1}, {"id": 2}, {"id": 3}],
        )
    )
    out = await _handlers(reg).connectors_sample_rows(
        connector_slug="stubdb", table="users", limit=2
    )
    assert out == {"rows": [{"id": 1}, {"id": 2}]}


async def test_get_schema_summary_returns_dict() -> None:
    cm = _FakeCM()
    reg = ConnectorRegistry()
    reg.register(
        _StubDBConnector(
            cm,
            tables=["users"],
            describe={"users": {"columns": [{"name": "id"}]}},
        )
    )
    out = await _handlers(reg).connectors_get_schema_summary(
        connector_slug="stubdb"
    )
    assert out["tables"][0]["name"] == "users"
