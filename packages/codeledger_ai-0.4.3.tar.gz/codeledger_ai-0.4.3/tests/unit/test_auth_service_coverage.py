"""Coverage tests for backend.auth.auth_service error and lifecycle paths.

Covers login_email_user, upsert_oauth_user, expired JWT, expired PAT,
orphaned PAT, revoke_pat, and re-registration.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

import pytest

from backend.auth.auth_service import (
    AuthError,
    AuthService,
    AuthSettings,
    UserExistsError,
)
from backend.auth.oauth_manager import OAuthUserInfo
from backend.auth.credential_manager import CredentialManager
from backend.config import CredentialConfig
from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations

if TYPE_CHECKING:
    from pathlib import Path


async def _mk_auth(tmp_path: Path) -> tuple[AuthService, Any]:
    db = SQLiteBackend(tmp_path / "auth.db")
    await db.connect()
    await apply_migrations(db)
    creds = CredentialManager(
        CredentialConfig(
            backend="file", vault_path=str(tmp_path / "auth-vault.enc")
        ),
        passphrase="auth-test",
    )
    svc = AuthService(
        db,
        creds,
        AuthSettings(
            jwt_expiry_hours=1,
            argon2_memory_cost_kb=512,
            argon2_time_cost=1,
            argon2_parallelism=1,
        ),
    )
    return svc, db


class TestEmailLogin:
    async def test_login_success_returns_user(self, tmp_path: Path) -> None:
        svc, db = await _mk_auth(tmp_path)
        try:
            await svc.register_email_user("a@b.com", "A", "password123")
            user = await svc.login_email_user("a@b.com", "password123")
            assert user.email == "a@b.com"
        finally:
            await db.close()

    async def test_login_unknown_email_is_auth_error(
        self, tmp_path: Path
    ) -> None:
        svc, db = await _mk_auth(tmp_path)
        try:
            with pytest.raises(AuthError, match="Invalid email or password"):
                await svc.login_email_user("ghost@x.com", "whatever")
        finally:
            await db.close()

    async def test_login_wrong_password_is_auth_error(
        self, tmp_path: Path
    ) -> None:
        svc, db = await _mk_auth(tmp_path)
        try:
            await svc.register_email_user("a@b.com", "A", "correct")
            with pytest.raises(AuthError, match="Invalid email or password"):
                await svc.login_email_user("a@b.com", "wrong")
        finally:
            await db.close()

    async def test_login_user_without_password_hash_rejected(
        self, tmp_path: Path
    ) -> None:
        """An OAuth-only user has password_hash=None; login_email must reject."""
        svc, db = await _mk_auth(tmp_path)
        try:
            # Upsert an OAuth user (no password).
            info = OAuthUserInfo(
                provider="google",
                provider_user_id="goog-1",
                email="oauth@x.com",
                name="OA",
                avatar_url=None,
            )
            await svc.upsert_oauth_user(info)
            with pytest.raises(AuthError):
                await svc.login_email_user("oauth@x.com", "anything")
        finally:
            await db.close()

    async def test_duplicate_registration_raises(
        self, tmp_path: Path
    ) -> None:
        svc, db = await _mk_auth(tmp_path)
        try:
            await svc.register_email_user("dup@x.com", "D", "pw")
            with pytest.raises(UserExistsError):
                await svc.register_email_user("dup@x.com", "D", "pw")
        finally:
            await db.close()


class TestOAuthUpsert:
    async def test_missing_email_rejected(self, tmp_path: Path) -> None:
        svc, db = await _mk_auth(tmp_path)
        try:
            info = OAuthUserInfo(
                provider="google",
                provider_user_id="x",
                email="",
                name="",
                avatar_url=None,
            )
            with pytest.raises(AuthError, match="did not return an email"):
                await svc.upsert_oauth_user(info)
        finally:
            await db.close()

    async def test_first_upsert_creates_user(
        self, tmp_path: Path
    ) -> None:
        svc, db = await _mk_auth(tmp_path)
        try:
            info = OAuthUserInfo(
                provider="github",
                provider_user_id="gh-1",
                email="gh@x.com",
                name="G",
                avatar_url="https://x/a.png",
            )
            user1 = await svc.upsert_oauth_user(info)
            assert user1.provider == "github"
            # Second call finds existing row, returns same id.
            user2 = await svc.upsert_oauth_user(info)
            assert user2.id == user1.id
        finally:
            await db.close()


class TestJwtExpiry:
    async def test_expired_jwt_rejected(self, tmp_path: Path) -> None:
        svc, db = await _mk_auth(tmp_path)
        try:
            from backend.models import User

            u = User(email="jwt@x.com", name="J")
            # Issue a token, then reject by mutating the service settings to
            # verify against an expired token manually.
            import jwt

            signing_key = svc._signing_key  # type: ignore[attr-defined]
            expired = jwt.encode(
                {
                    "sub": str(u.id),
                    "email": u.email,
                    "iat": int(
                        (datetime.now(UTC) - timedelta(hours=2)).timestamp()
                    ),
                    "exp": int(
                        (datetime.now(UTC) - timedelta(hours=1)).timestamp()
                    ),
                },
                signing_key,
                algorithm="HS256",
            )
            with pytest.raises(AuthError, match="expired"):
                svc.verify_jwt(expired)
        finally:
            await db.close()

    async def test_garbage_jwt_rejected(self, tmp_path: Path) -> None:
        svc, db = await _mk_auth(tmp_path)
        try:
            with pytest.raises(AuthError, match="Invalid JWT"):
                svc.verify_jwt("not.a.jwt")
        finally:
            await db.close()


class TestPATLifecycle:
    async def test_expired_pat_rejected(self, tmp_path: Path) -> None:
        svc, db = await _mk_auth(tmp_path)
        try:
            u = await svc.register_email_user("pat@x.com", "P", "pw")
            result = await svc.create_pat(
                u.id,
                "short",
                expires_at=datetime.now(UTC) - timedelta(hours=1),
            )
            with pytest.raises(AuthError, match="expired"):
                await svc.validate_pat(result.plaintext)
        finally:
            await db.close()

    async def test_orphan_pat_rejected(self, tmp_path: Path) -> None:
        """If the owning user is deleted, PAT validation fails cleanly."""
        svc, db = await _mk_auth(tmp_path)
        try:
            u = await svc.register_email_user("orphan@x.com", "O", "pw")
            result = await svc.create_pat(u.id, "orphan-pat")
            await db.delete("users", str(u.id))
            with pytest.raises(AuthError, match="no owner"):
                await svc.validate_pat(result.plaintext)
        finally:
            await db.close()

    async def test_revoke_pat(self, tmp_path: Path) -> None:
        svc, db = await _mk_auth(tmp_path)
        try:
            u = await svc.register_email_user("rv@x.com", "R", "pw")
            result = await svc.create_pat(u.id, "revokable")
            await svc.revoke_pat(uuid.UUID(result.record.id.hex))
            with pytest.raises(AuthError, match="Invalid personal access token"):
                await svc.validate_pat(result.plaintext)
        finally:
            await db.close()

    async def test_invalid_pat_plaintext_rejected(
        self, tmp_path: Path
    ) -> None:
        svc, db = await _mk_auth(tmp_path)
        try:
            with pytest.raises(AuthError, match="Invalid personal access token"):
                await svc.validate_pat("cl_pat_notreal")
        finally:
            await db.close()
