"""Tests for the onboarding walkthrough endpoints.

`GET /api/setup/status` and `POST /api/setup/complete` are the only
unauthenticated routes the frontend relies on before the user has
configured auth. The contract: fresh installs start at step 1 with
``setup_complete: false``; ``/complete`` flips the flag and persists
``step_reached``.
"""

from __future__ import annotations

import sys
import textwrap
from typing import TYPE_CHECKING

import pytest
from fastapi.testclient import TestClient

from backend.config import load_config
from backend.main import create_app

if TYPE_CHECKING:
    from pathlib import Path


def _write_config(tmp_path: Path) -> Path:
    content = textwrap.dedent(
        """\
        [server]
        mode = "solo"
        host = "127.0.0.1"
        port = 8100
        log_level = "info"

        [database]
        backend = "sqlite"
        sqlite_path = "data/codeledger.db"

        [vault]
        backend = "file"
        vault_path = "vault.enc"

        [auth]
        jwt_expiry_hours = 24
        argon2_memory_cost_kb = 512
        argon2_time_cost = 1
        argon2_parallelism = 1
        """
    )
    target = tmp_path / "codeledger.toml"
    target.write_text(content, encoding="utf-8")
    if sys.platform != "win32":
        target.chmod(0o600)
    return target


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> TestClient:
    monkeypatch.setenv("CODELEDGER_VAULT_PASSPHRASE", "test-passphrase")
    cfg_path = _write_config(tmp_path)
    config = load_config(cfg_path, project_root=tmp_path)
    app = create_app(config)
    return TestClient(app)


class TestSetupStatus:
    def test_fresh_install_returns_incomplete(
        self, client: TestClient
    ) -> None:
        with client:
            resp = client.get("/api/setup/status")
        assert resp.status_code == 200
        body = resp.json()
        assert body["setup_complete"] is False
        assert body["step_reached"] == 1
        assert body["decisions_count"] == 0
        assert body["sessions_count"] == 0

    def test_status_includes_mode_and_port(self, client: TestClient) -> None:
        with client:
            body = client.get("/api/setup/status").json()
        assert body["mode"] == "solo"
        assert body["port"] == 8100

    def test_status_is_unauthenticated(self, client: TestClient) -> None:
        # No Authorization header sent; endpoint still returns 200.
        with client:
            resp = client.get("/api/setup/status")
        assert resp.status_code == 200


class TestSetupComplete:
    def test_marks_complete(self, client: TestClient) -> None:
        with client:
            resp = client.post(
                "/api/setup/complete",
                json={"step_reached": 5, "complete": True},
            )
            assert resp.status_code == 200
            assert resp.json()["setup_complete"] is True
            # Subsequent status reflects the new state.
            status = client.get("/api/setup/status").json()
            assert status["setup_complete"] is True
            assert status["step_reached"] == 5

    def test_persists_step_reached_without_completing(
        self, client: TestClient
    ) -> None:
        with client:
            client.post(
                "/api/setup/complete",
                json={"step_reached": 3, "complete": False},
            )
            status = client.get("/api/setup/status").json()
        assert status["setup_complete"] is False
        assert status["step_reached"] == 3

    def test_subsequent_complete_is_idempotent(
        self, client: TestClient
    ) -> None:
        with client:
            for _ in range(3):
                client.post(
                    "/api/setup/complete",
                    json={"step_reached": 5, "complete": True},
                )
            status = client.get("/api/setup/status").json()
        assert status["setup_complete"] is True
        assert status["step_reached"] == 5
