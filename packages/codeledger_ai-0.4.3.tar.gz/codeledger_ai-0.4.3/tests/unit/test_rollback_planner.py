"""Tests for backend.advanced.rollback_planner."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from backend.advanced.rollback_planner import RollbackPlanner
from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.ast_tracker import ASTTracker
from backend.models import Decision
from backend.verification.provenance import ProvenanceEngine

if TYPE_CHECKING:
    from pathlib import Path


_DIFF = (
    "diff --git a/r.py b/r.py\n"
    "--- a/r.py\n"
    "+++ b/r.py\n"
    "@@ -0,0 +1,2 @@\n"
    "+def r_fn(x):\n"
    "+    return x\n"
)


@pytest.fixture
async def db(tmp_path: Path) -> SQLiteBackend:
    backend = SQLiteBackend(tmp_path / "rollback.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def planner(db: SQLiteBackend) -> RollbackPlanner:
    return RollbackPlanner(db=db, provenance=ProvenanceEngine(db))


async def _seed_decision_and_event(
    db: SQLiteBackend,
    *,
    change_event_id: str,
    change_event_source: str,
    title: str = "Touch r.py for r_fn",
) -> str:
    tracker = ASTTracker(db=db)
    d = Decision(title=title, description="Adds r_fn in r.py")
    await db.insert("decisions", d.to_dict())
    await tracker.process_change_event(
        change_event_id=change_event_id,
        change_event_source=change_event_source,
        diff_text=_DIFF,
        project_id="proj-1",
    )
    return str(d.id)


class TestPlanRollback:
    async def test_low_risk_with_no_dependents(
        self, db: SQLiteBackend, planner: RollbackPlanner
    ) -> None:
        did = await _seed_decision_and_event(
            db, change_event_id="cmt-lo", change_event_source="git_commit"
        )
        plan = await planner.plan_rollback(did)
        assert plan.risk_assessment == "low"
        assert plan.dependent_decisions == []
        assert plan.affected_files == ["r.py"]
        assert plan.affected_change_events[0].change_event_source == "git_commit"
        assert plan.affected_change_events[0].label.startswith("commit ")

    async def test_file_snapshot_event_label(
        self, db: SQLiteBackend, planner: RollbackPlanner
    ) -> None:
        did = await _seed_decision_and_event(
            db, change_event_id="snap-x", change_event_source="file_snapshot"
        )
        plan = await planner.plan_rollback(did)
        ev = plan.affected_change_events[0]
        assert ev.change_event_source == "file_snapshot"
        assert ev.label.startswith("Snapshot ")
        assert "r.py" in ev.label

    async def test_medium_risk_with_unverified_dependent(
        self, db: SQLiteBackend, planner: RollbackPlanner
    ) -> None:
        did = await _seed_decision_and_event(
            db,
            change_event_id="cmt-med",
            change_event_source="git_commit",
            title="First touches r.py r_fn",
        )
        # A second decision that will get linked to the same file/entity.
        await _seed_decision_and_event(
            db,
            change_event_id="cmt-med-2",
            change_event_source="git_commit",
            title="Second also touches r.py r_fn",
        )
        plan = await planner.plan_rollback(did)
        assert plan.dependent_decisions
        # All seeded decisions default to "unverified" status.
        assert plan.risk_assessment == "medium"

    async def test_high_risk_with_verified_dependent(
        self, db: SQLiteBackend, planner: RollbackPlanner
    ) -> None:
        did = await _seed_decision_and_event(
            db,
            change_event_id="cmt-hi",
            change_event_source="git_commit",
            title="Target touches r.py r_fn",
        )
        dep_id = await _seed_decision_and_event(
            db,
            change_event_id="cmt-hi-2",
            change_event_source="git_commit",
            title="Dependent also touches r.py r_fn",
        )
        # Mark the dependent as passed.
        await db.update("decisions", dep_id, {"status": "passed"})
        plan = await planner.plan_rollback(did)
        assert plan.risk_assessment == "high"

    async def test_dict_shape(
        self, db: SQLiteBackend, planner: RollbackPlanner
    ) -> None:
        did = await _seed_decision_and_event(
            db, change_event_id="cmt-dict", change_event_source="git_commit"
        )
        payload = await planner.plan_rollback_dict(did)
        assert payload["target_decision"]["id"] == did
        assert "risk_assessment" in payload
        assert "affected_change_events" in payload
