"""Tests for the universal active-context helpers on ToolHandlers.

Exercises:
* :func:`ensure_session_and_inject_context` — auto session creation,
  re-use of existing active sessions within the inactivity window,
  first-call-only ``session_context`` injection.
* :meth:`context_before_edit` — file-relevant decisions, conflicts,
  import warnings.
* :meth:`close_inactive_sessions` — auto-close when ``last_tool_call_at``
  is older than the configured window, with inference run on the way.

All tests use the real SQLite + sqlite-vss stack and a deterministic
in-process fake embedder so no Ollama or HuggingFace download is
required.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.db.vector_store import SqliteVssStore
from backend.intelligence.ast_tracker import ASTTracker
from backend.intelligence.context_triage import ContextTriage
from backend.intelligence.decision_inferrer import DecisionInferrer
from backend.intelligence.semantic_search import SemanticSearch
from backend.mcp.tool_handlers import ToolHandlers
from backend.models import Decision
from backend.utils.token_counter import count_tokens
from backend.verification.conflict_detector import ConflictDetector

if TYPE_CHECKING:
    from pathlib import Path


class _FakeEmbedder:
    """Deterministic 16-dim embedder."""

    async def embed_text(self, text: str) -> list[float]:
        base = [0.0] * 16
        for i, ch in enumerate(text):
            base[i % 16] += (ord(ch) % 13) / 13.0
        total = max(sum(abs(x) for x in base), 1.0)
        return [x / total for x in base]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [await self.embed_text(t) for t in texts]


@pytest.fixture
async def handlers(tmp_path: Path) -> ToolHandlers:
    db = SQLiteBackend(tmp_path / "active.db")
    await db.connect()
    await apply_migrations(db)
    store = SqliteVssStore(tmp_path / "active-vec.db", dim=16)
    await store.connect()
    semantic = SemanticSearch(
        embedder=_FakeEmbedder(), vector_store=store, db=db
    )
    tracker = ASTTracker(db=db)
    yield ToolHandlers(
        db=db,
        semantic_search=semantic,
        context_triage=ContextTriage(count_tokens),
        conflict_detector=ConflictDetector(db),
        decision_inferrer=DecisionInferrer(db=db, ast_tracker=tracker),
    )
    await store.close()
    await db.close()


# ---------------------------------------------------------------------------
# ensure_session_and_inject_context
# ---------------------------------------------------------------------------


class TestEnsureSession:
    async def test_first_call_creates_session_and_returns_context(
        self, handlers: ToolHandlers
    ) -> None:
        await handlers.decision_create(
            user_id=uuid.uuid4(),
            title="Use Argon2id for password hashing",
            description="Security decision.",
        )
        result = await handlers.ensure_session_and_inject_context(
            cwd="/tmp/proj",
            agent_name="cursor",
            project_id="proj-a",
            first_message="how should we hash passwords?",
        )
        assert result is not None
        assert result.is_new_session is True
        assert result.session_id
        # Context block may be empty when the deterministic embedder
        # doesn't produce strong similarity — what matters is that the
        # pipeline ran and a session was persisted.
        row = await handlers.db.get_by_id("sessions", result.session_id)
        assert row is not None
        assert row["project_id"] == "proj-a"
        assert row["cwd"] == "/tmp/proj"
        assert row["status"] == "active"
        assert row["last_tool_call_at"] is not None

    async def test_subsequent_call_reuses_session(
        self, handlers: ToolHandlers
    ) -> None:
        first = await handlers.ensure_session_and_inject_context(
            cwd="/tmp/proj",
            agent_name="cursor",
            project_id="proj-a",
        )
        second = await handlers.ensure_session_and_inject_context(
            cwd="/tmp/proj",
            agent_name="cursor",
            project_id="proj-a",
        )
        assert first is not None and second is not None
        assert first.session_id == second.session_id
        assert second.is_new_session is False
        assert second.context_block is None

    async def test_different_agents_get_different_sessions(
        self, handlers: ToolHandlers
    ) -> None:
        a = await handlers.ensure_session_and_inject_context(
            cwd="/tmp/proj",
            agent_name="cursor",
            project_id="proj-a",
        )
        b = await handlers.ensure_session_and_inject_context(
            cwd="/tmp/proj",
            agent_name="windsurf",
            project_id="proj-a",
        )
        assert a is not None and b is not None
        assert a.session_id != b.session_id

    async def test_missing_context_fields_is_noop(
        self, handlers: ToolHandlers
    ) -> None:
        assert (
            await handlers.ensure_session_and_inject_context(
                cwd=None, agent_name="x", project_id="x"
            )
            is None
        )
        assert (
            await handlers.ensure_session_and_inject_context(
                cwd="x", agent_name=None, project_id="x"
            )
            is None
        )
        assert (
            await handlers.ensure_session_and_inject_context(
                cwd="x", agent_name="x", project_id=None
            )
            is None
        )

    async def test_last_tool_call_at_refreshed_on_reuse(
        self, handlers: ToolHandlers
    ) -> None:
        first = await handlers.ensure_session_and_inject_context(
            cwd="/tmp/proj",
            agent_name="cursor",
            project_id="proj-a",
        )
        assert first is not None
        # Rewind ``last_tool_call_at`` to simulate some time passing.
        old_ts = (datetime.now(UTC) - timedelta(minutes=5)).isoformat()
        await handlers.db.update(
            "sessions",
            first.session_id,
            {"last_tool_call_at": old_ts},
        )
        second = await handlers.ensure_session_and_inject_context(
            cwd="/tmp/proj",
            agent_name="cursor",
            project_id="proj-a",
        )
        assert second is not None
        row = await handlers.db.get_by_id("sessions", second.session_id)
        assert row["last_tool_call_at"] > old_ts

    async def test_stale_session_not_reused(
        self, handlers: ToolHandlers
    ) -> None:
        first = await handlers.ensure_session_and_inject_context(
            cwd="/tmp/proj",
            agent_name="cursor",
            project_id="proj-a",
            inactivity_timeout_minutes=1,
        )
        assert first is not None
        # Simulate 10 minutes of inactivity — longer than the 1-min window.
        old_ts = (datetime.now(UTC) - timedelta(minutes=10)).isoformat()
        await handlers.db.update(
            "sessions",
            first.session_id,
            {"last_tool_call_at": old_ts},
        )
        second = await handlers.ensure_session_and_inject_context(
            cwd="/tmp/proj",
            agent_name="cursor",
            project_id="proj-a",
            inactivity_timeout_minutes=1,
        )
        assert second is not None
        assert second.session_id != first.session_id
        assert second.is_new_session is True


# ---------------------------------------------------------------------------
# context.before_edit
# ---------------------------------------------------------------------------


class TestContextBeforeEdit:
    async def test_returns_decisions_conflicts_and_import_warnings(
        self, handlers: ToolHandlers
    ) -> None:
        # Seed a verified drift constraint.
        d = Decision(
            title="Layering",
            description="backend.api must not import backend.db directly.",
            status="passed",
        )
        await handlers.db.insert("decisions", d.to_dict())

        # Simulate a competing session on the same file.
        assert handlers.conflict_detector is not None
        handlers.conflict_detector.register_session(
            session_id="other-sess",
            project_id="proj-a",
            agent_name="other-agent",
            files=["backend/api/routes.py"],
        )

        result = await handlers.context_before_edit(
            user_id=uuid.uuid4(),
            file_path="backend/api/routes.py",
            file_content="from backend.db import models\n",
            cwd="/tmp/proj",
            agent_name="cursor",
            project_id="proj-a",
        )
        assert result["session_id"]
        assert "decisions" in result
        assert any(
            v["import"] == "backend.db" for v in result["import_warnings"]
        )
        assert result["conflicts"]
        assert result["conflicts"][0]["conflicting_session_id"] == "other-sess"

    async def test_first_call_also_triggers_session_context(
        self, handlers: ToolHandlers
    ) -> None:
        result = await handlers.context_before_edit(
            user_id=uuid.uuid4(),
            file_path="a.py",
            file_content="import os\n",
            cwd="/tmp/proj",
            agent_name="cursor",
            project_id="proj-a",
        )
        # The first call from this agent/project pair should attach
        # session_context with the new session id.
        assert "session_context" in result
        assert result["session_context"]["session_id"] == result["session_id"]

    async def test_no_constraints_empty_warnings(
        self, handlers: ToolHandlers
    ) -> None:
        result = await handlers.context_before_edit(
            user_id=uuid.uuid4(),
            file_path="a.py",
            file_content="import os\n",
            cwd="/tmp/proj",
            agent_name="cursor",
            project_id="proj-a",
        )
        assert result["import_warnings"] == []


# ---------------------------------------------------------------------------
# file_context side effect
# ---------------------------------------------------------------------------


class TestFileContextSideEffect:
    async def test_context_get_for_file_includes_file_context(
        self, handlers: ToolHandlers
    ) -> None:
        await handlers.decision_create(
            user_id=uuid.uuid4(),
            title="Hash passwords in auth.py",
            description="auth.py hash_password must use Argon2id.",
        )
        result = await handlers.context_get_for_file(
            user_id=uuid.uuid4(),
            file_path="auth.py",
            file_content="def hash_password(pw):\n    return pw\n",
        )
        assert "file_context" in result
        assert isinstance(result["file_context"], list)

    async def test_decision_reverse_trace_includes_file_context(
        self, handlers: ToolHandlers
    ) -> None:
        result = await handlers.decision_reverse_trace(
            user_id=uuid.uuid4(),
            file_path="nonexistent.py",
            entity_name="ghost",
        )
        # Empty changes but file_context key is present.
        assert "file_context" in result

    async def test_decision_trace_includes_file_context(
        self, handlers: ToolHandlers
    ) -> None:
        d = await handlers.decision_create(
            user_id=uuid.uuid4(),
            title="Test decision",
        )
        tree = await handlers.decision_trace(
            user_id=uuid.uuid4(),
            decision_id=uuid.UUID(d["id"]),
        )
        assert "file_context" in tree


# ---------------------------------------------------------------------------
# close_inactive_sessions
# ---------------------------------------------------------------------------


class TestCloseInactiveSessions:
    async def test_closes_sessions_past_timeout(
        self, handlers: ToolHandlers
    ) -> None:
        # Seed an active session old enough to be idle.
        old_ts = (datetime.now(UTC) - timedelta(minutes=120)).isoformat()
        sid = str(uuid.uuid4())
        await handlers.db.insert(
            "sessions",
            {
                "id": sid,
                "user_id": None,
                "agent_name": "cursor",
                "started_at": old_ts,
                "ended_at": None,
                "status": "active",
                "files_touched": "[]",
                "project_id": "proj-a",
                "cwd": "/tmp/proj",
                "last_tool_call_at": old_ts,
                "created_at": old_ts,
                "updated_at": old_ts,
            },
        )
        closed = await handlers.close_inactive_sessions(
            inactivity_timeout_minutes=30
        )
        assert sid in closed
        row = await handlers.db.get_by_id("sessions", sid)
        assert row["status"] == "completed"

    async def test_recent_session_not_closed(
        self, handlers: ToolHandlers
    ) -> None:
        fresh = await handlers.ensure_session_and_inject_context(
            cwd="/tmp/proj",
            agent_name="cursor",
            project_id="proj-a",
        )
        assert fresh is not None
        closed = await handlers.close_inactive_sessions(
            inactivity_timeout_minutes=30
        )
        assert fresh.session_id not in closed

    async def test_timeout_zero_disables_closure(
        self, handlers: ToolHandlers
    ) -> None:
        closed = await handlers.close_inactive_sessions(
            inactivity_timeout_minutes=0
        )
        assert closed == []
