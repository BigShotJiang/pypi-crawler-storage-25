"""Tests for the context verification layer (VGR-1..VGR-7).

Each test names the guard rail it enforces. A failure here is a
blocking bug — the verifier's contract is load-bearing for the
agent's trust in retrieved decisions.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any
from unittest.mock import patch

import pytest

from backend.advanced.drift_detector import DriftDetector, DriftViolation
from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.ast_tracker import ASTTracker
from backend.intelligence.semantic_search import SearchResult
from backend.models import Decision
from backend.verification.context_verifier import (
    STATUS_GUIDANCE,
    ContextVerifier,
    VerificationOutcome,
    VerifiedDecision,
)

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
async def db(tmp_path: Path) -> SQLiteBackend:
    backend = SQLiteBackend(tmp_path / "verifier.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def tracker(db: SQLiteBackend) -> ASTTracker:
    return ASTTracker(db=db)


@pytest.fixture
def drift_detector(db: SQLiteBackend, tracker: ASTTracker) -> DriftDetector:
    return DriftDetector(db=db, ast_tracker=tracker)


@pytest.fixture
def verifier(
    db: SQLiteBackend, drift_detector: DriftDetector
) -> ContextVerifier:
    return ContextVerifier(db=db, drift_detector=drift_detector)


def _result(
    item_id: str,
    title: str,
    score: float = 0.9,
    item_type: str = "decision",
) -> SearchResult:
    return SearchResult(
        item_id=item_id,
        score=score,
        item_type=item_type,
        metadata={"title": title, "project_id": "p"},
        retrieval_method="vector",
    )


async def _seed_decision(
    db: SQLiteBackend,
    *,
    decision_id: str,
    title: str,
    description: str = "",
    status: str = "passed",
    staleness: float = 0.0,
    superseded_by: str | None = None,
    inference_status: str = "explicit",
) -> None:
    decision = Decision(
        title=title,
        description=description,
        status=status,
        inference_status=inference_status,
        staleness_score=staleness,
        superseded_by=superseded_by,
    )
    row = decision.to_dict()
    row["id"] = decision_id
    await db.insert("decisions", row)


# ---------------------------------------------------------------------------
# VGR-1 — Never blocks
# ---------------------------------------------------------------------------


async def test_VGR1_db_crash_returns_unverified_not_exception(
    verifier: ContextVerifier,
) -> None:
    async def exploder(*_a: Any, **_k: Any) -> Any:
        raise RuntimeError("simulated DB crash")

    original = verifier._db.get_by_id
    verifier._db.get_by_id = exploder  # type: ignore[method-assign]
    try:
        outcome = await verifier.verify_batch(
            [_result("d1", "Use argon2")], project_id="p"
        )
    finally:
        verifier._db.get_by_id = original  # type: ignore[method-assign]
    assert outcome.all_verified[0].status == "UNVERIFIED"
    assert outcome.all_verified[0].include_in_context is True
    assert len(outcome.kept) == 1


async def test_VGR1_timeout_returns_unverified(
    verifier: ContextVerifier,
) -> None:
    async def slow(*_a: Any, **_k: Any) -> Any:
        await asyncio.sleep(5)
        return None

    original = verifier._db.get_by_id
    verifier._db.get_by_id = slow  # type: ignore[method-assign]
    try:
        with patch(
            "backend.verification.context_verifier.VERIFICATION_TIMEOUT_SECONDS",
            0.02,
        ):
            outcome = await verifier.verify_batch(
                [_result("d1", "Use argon2")], project_id="p"
            )
    finally:
        verifier._db.get_by_id = original  # type: ignore[method-assign]
    assert outcome.all_verified[0].status == "UNVERIFIED"
    assert outcome.kept == [outcome.kept[0]]  # still kept — VGR-1/4


async def test_VGR1_drift_reader_exception_still_verifies(
    db: SQLiteBackend, drift_detector: DriftDetector
) -> None:
    async def boom(*_a: Any, **_k: Any) -> list[DriftViolation]:
        raise RuntimeError("drift cache unreachable")

    drift_detector.get_violations_for_decision = boom  # type: ignore[method-assign]
    await _seed_decision(db, decision_id="d1", title="Use argon2")
    verifier = ContextVerifier(db=db, drift_detector=drift_detector)
    outcome = await verifier.verify_batch(
        [_result("d1", "Use argon2")], project_id="p"
    )
    # Falls through to VERIFIED because staleness is 0, no supersession,
    # and the drift check failure is swallowed by _verify_one.
    assert outcome.all_verified[0].status == "VERIFIED"


# ---------------------------------------------------------------------------
# VGR-2 — Status explicit in output
# ---------------------------------------------------------------------------


async def test_VGR2_status_stamped_on_every_kept_result(
    db: SQLiteBackend, verifier: ContextVerifier
) -> None:
    await _seed_decision(db, decision_id="d1", title="Use argon2")
    await _seed_decision(
        db, decision_id="d2", title="Use Redis", staleness=0.9
    )
    outcome = await verifier.verify_batch(
        [_result("d1", "Use argon2"), _result("d2", "Use Redis")],
        project_id="p",
    )
    statuses = [
        r.metadata.get("verification_status") for r in outcome.kept
    ]
    assert "VERIFIED" in statuses
    assert "STALE" in statuses
    for r in outcome.kept:
        assert r.metadata.get("verification_guidance")


# ---------------------------------------------------------------------------
# VGR-3 — Fast, cached only, under 50 ms per decision
# ---------------------------------------------------------------------------


async def test_VGR3_batch_of_ten_completes_well_under_budget(
    db: SQLiteBackend, verifier: ContextVerifier
) -> None:
    for i in range(10):
        await _seed_decision(db, decision_id=f"d{i}", title=f"Decision {i}")
    results = [_result(f"d{i}", f"Decision {i}") for i in range(10)]
    import time

    start = time.perf_counter()
    outcome = await verifier.verify_batch(results, project_id="p")
    elapsed_ms = (time.perf_counter() - start) * 1000
    # 10 decisions at 50 ms budget each = 500 ms upper bound for the batch.
    assert elapsed_ms < 500, (
        f"batch of 10 took {elapsed_ms:.1f}ms, exceeds 500ms budget"
    )
    assert len(outcome.all_verified) == 10


# ---------------------------------------------------------------------------
# VGR-4 — DRIFTED included with warnings
# ---------------------------------------------------------------------------


async def test_VGR4_drifted_decision_included_with_violation(
    db: SQLiteBackend, drift_detector: DriftDetector
) -> None:
    await _seed_decision(db, decision_id="d1", title="No asyncpg imports")

    async def stub(
        *, decision_id: str, project_id: str
    ) -> list[DriftViolation]:
        if decision_id == "d1":
            return [
                DriftViolation(
                    decision_id="d1",
                    decision_title="No asyncpg imports",
                    constraint_description="cache.py must not import asyncpg",
                    violating_file="backend/cache/redis_cache.py",
                    violating_line=12,
                    violation_description="redis_cache.py imports asyncpg directly",
                    severity="high",
                )
            ]
        return []

    drift_detector.get_violations_for_decision = stub  # type: ignore[method-assign]
    verifier = ContextVerifier(db=db, drift_detector=drift_detector)
    outcome = await verifier.verify_batch(
        [_result("d1", "No asyncpg imports")], project_id="p"
    )
    assert outcome.all_verified[0].status == "DRIFTED"
    assert outcome.all_verified[0].include_in_context is True
    assert outcome.kept, "DRIFTED items must not be excluded"
    kept = outcome.kept[0]
    violations = kept.metadata.get("verification_drift_violations")
    assert isinstance(violations, list) and violations
    assert violations[0]["file"] == "backend/cache/redis_cache.py"


# ---------------------------------------------------------------------------
# VGR-5 — SUPERSEDED excluded with logging
# ---------------------------------------------------------------------------


async def test_VGR5_superseded_excluded(
    db: SQLiteBackend, verifier: ContextVerifier, caplog: Any
) -> None:
    await _seed_decision(db, decision_id="d_new", title="Use in-memory cache")
    await _seed_decision(
        db, decision_id="d_old", title="Use Redis", superseded_by="d_new"
    )
    import logging

    caplog.set_level(logging.INFO, logger="backend.verification.context_verifier")
    outcome = await verifier.verify_batch(
        [_result("d_old", "Use Redis"), _result("d_new", "Use in-memory cache")],
        project_id="p",
    )
    statuses = {r.decision_id: r.status for r in outcome.all_verified}
    assert statuses["d_old"] == "SUPERSEDED"
    assert statuses["d_new"] == "VERIFIED"
    assert len(outcome.kept) == 1
    assert outcome.kept[0].item_id == "d_new"
    assert len(outcome.excluded) == 1
    assert outcome.excluded[0].superseded_by_title == "Use in-memory cache"
    # Log record written so ops can observe the exclusion.
    assert any(
        "excluded" in rec.getMessage().lower() for rec in caplog.records
    )


# ---------------------------------------------------------------------------
# VGR-6 — Feeds harness (verification_health sensor)
# ---------------------------------------------------------------------------


async def test_VGR6_harness_reads_context_retrieval_events(
    db: SQLiteBackend,
) -> None:
    """Harness scores this synthetic session as 'critical' when drift is
    present and ``drift.check`` was never called.
    """
    from backend.models import Session
    from backend.verification.harness import QualityHarness

    session = Session(agent_name="gr-test", status="active")
    await db.insert("sessions", session.to_dict())

    # One retrieval surfaced a drifted decision.
    import json
    import uuid as _uuid

    await db.insert(
        "session_events",
        {
            "id": str(_uuid.uuid4()),
            "session_id": str(session.id),
            "event_type": "context_retrieval",
            "payload": json.dumps(
                {
                    "counts": {
                        "VERIFIED": 1,
                        "DRIFTED": 1,
                        "STALE": 0,
                        "SUPERSEDED": 0,
                        "UNVERIFIED": 0,
                        "INFERRED": 0,
                    },
                    "drifted_decision_ids": ["d1"],
                    "stale_decision_ids": [],
                }
            ),
            "created_at": session.created_at.isoformat(),
            "updated_at": session.created_at.isoformat(),
        },
    )

    harness = QualityHarness(db)
    health = await harness.score_verification_health(
        session_id=str(session.id), project_id="p"
    )
    assert health.status == "critical"
    assert health.score == 0.4
    assert health.drifted_retrievals == 1
    assert health.drift_check_called is False


async def test_VGR6_drift_check_softens_score_to_warning(
    db: SQLiteBackend,
) -> None:
    from backend.models import Session
    from backend.verification.harness import QualityHarness

    session = Session(agent_name="gr-test", status="active")
    await db.insert("sessions", session.to_dict())

    import json
    import uuid as _uuid

    await db.insert(
        "session_events",
        {
            "id": str(_uuid.uuid4()),
            "session_id": str(session.id),
            "event_type": "context_retrieval",
            "payload": json.dumps(
                {
                    "counts": {
                        "VERIFIED": 0,
                        "DRIFTED": 2,
                        "STALE": 0,
                        "SUPERSEDED": 0,
                        "UNVERIFIED": 0,
                        "INFERRED": 0,
                    },
                    "drifted_decision_ids": ["d1", "d2"],
                    "stale_decision_ids": [],
                }
            ),
            "created_at": session.created_at.isoformat(),
            "updated_at": session.created_at.isoformat(),
        },
    )
    await db.insert(
        "session_events",
        {
            "id": str(_uuid.uuid4()),
            "session_id": str(session.id),
            "event_type": "tool_call",
            "payload": json.dumps({"tool": "drift.check"}),
            "created_at": session.created_at.isoformat(),
            "updated_at": session.created_at.isoformat(),
        },
    )

    harness = QualityHarness(db)
    health = await harness.score_verification_health(
        session_id=str(session.id), project_id="p"
    )
    assert health.status == "warning"
    assert health.score == 0.7
    assert health.drift_check_called is True


async def test_VGR6_no_retrievals_returns_unavailable(
    db: SQLiteBackend,
) -> None:
    from backend.models import Session
    from backend.verification.harness import QualityHarness

    session = Session(agent_name="gr-test", status="active")
    await db.insert("sessions", session.to_dict())

    harness = QualityHarness(db)
    health = await harness.score_verification_health(
        session_id=str(session.id), project_id="p"
    )
    assert health.status == "unavailable"
    assert health.score is None


# ---------------------------------------------------------------------------
# VGR-7 — Action guidance per status
# ---------------------------------------------------------------------------


def test_VGR7_every_status_has_meaningful_guidance() -> None:
    for status, guidance in STATUS_GUIDANCE.items():
        assert len(guidance) > 20, f"{status} has no meaningful guidance"
        lowered = guidance.lower()
        assert any(
            marker in lowered
            for marker in (
                "follow",
                "do not",
                "confirm",
                "verify",
                "treat",
                "review",
                "resolve",
            )
        ), f"{status} guidance lacks an imperative: {guidance!r}"


async def test_VGR7_guidance_stamped_on_metadata(
    db: SQLiteBackend, verifier: ContextVerifier
) -> None:
    await _seed_decision(db, decision_id="d1", title="Use argon2")
    outcome = await verifier.verify_batch(
        [_result("d1", "Use argon2")], project_id="p"
    )
    assert outcome.kept[0].metadata["verification_guidance"] == (
        STATUS_GUIDANCE["VERIFIED"]
    )


# ---------------------------------------------------------------------------
# Inferred decisions surface as INFERRED
# ---------------------------------------------------------------------------


async def test_inferred_decision_flagged_as_inferred(
    db: SQLiteBackend, verifier: ContextVerifier
) -> None:
    await _seed_decision(
        db,
        decision_id="d1",
        title="Inferred argon2 usage",
        inference_status="pending",
    )
    outcome = await verifier.verify_batch(
        [_result("d1", "Inferred argon2 usage")], project_id="p"
    )
    assert outcome.all_verified[0].status == "INFERRED"
    assert outcome.kept[0].metadata["verification_status"] == "INFERRED"


# ---------------------------------------------------------------------------
# VerifiedDecision.__post_init__ respects VGR-5
# ---------------------------------------------------------------------------


def test_superseded_verified_decision_filters_itself() -> None:
    vd = VerifiedDecision(
        decision_id="d1",
        title="Use Redis",
        status="SUPERSEDED",
        relevance_score=0.8,
        superseded_by_id="d2",
    )
    assert vd.include_in_context is False
    assert vd.guidance == STATUS_GUIDANCE["SUPERSEDED"]


def test_verification_outcome_empty_when_no_results(
    verifier: ContextVerifier,
) -> None:
    async def run() -> VerificationOutcome:
        return await verifier.verify_batch([], project_id="p")

    outcome = asyncio.run(run())
    assert outcome.kept == []
    assert outcome.excluded == []
    assert outcome.all_verified == []
