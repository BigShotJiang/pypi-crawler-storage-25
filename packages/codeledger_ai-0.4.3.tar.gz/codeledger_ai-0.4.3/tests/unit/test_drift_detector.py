"""Tests for backend.advanced.drift_detector."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from backend.advanced.drift_detector import DriftDetector
from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.ast_tracker import ASTTracker
from backend.models import Decision

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
async def db(tmp_path: Path) -> SQLiteBackend:
    backend = SQLiteBackend(tmp_path / "drift.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def detector(db: SQLiteBackend) -> DriftDetector:
    return DriftDetector(db=db, ast_tracker=ASTTracker(db=db))


async def _seed_verified_decision(
    db: SQLiteBackend, title: str, description: str
) -> str:
    d = Decision(title=title, description=description, status="passed")
    await db.insert("decisions", d.to_dict())
    return str(d.id)


class TestCheckDrift:
    async def test_no_constraints_no_violations(
        self, db: SQLiteBackend, detector: DriftDetector, tmp_path: Path
    ) -> None:
        proj = tmp_path / "proj"
        proj.mkdir()
        (proj / "a.py").write_text("import os\n")
        report = await detector.check_drift("p1", str(proj))
        assert report.violations == []
        assert report.checked_files >= 1

    async def test_violation_detected(
        self, db: SQLiteBackend, detector: DriftDetector, tmp_path: Path
    ) -> None:
        await _seed_verified_decision(
            db,
            "Layering: api must not import db",
            "The backend.api module must not import backend.db directly.",
        )
        proj = tmp_path / "proj"
        (proj / "backend" / "api").mkdir(parents=True)
        (proj / "backend" / "api" / "routes.py").write_text(
            "from backend.db import something\n"
            "def x():\n    return 1\n"
        )
        report = await detector.check_drift("p1", str(proj))
        assert len(report.violations) >= 1
        v = report.violations[0]
        assert v.violating_line == 1
        assert "backend.api" in v.constraint_description.lower() or v.decision_title
        assert v.severity == "high"

    async def test_no_violation_when_conformant(
        self, db: SQLiteBackend, detector: DriftDetector, tmp_path: Path
    ) -> None:
        await _seed_verified_decision(
            db,
            "Layering: api must not import db",
            "The backend.api module must not import backend.db directly.",
        )
        proj = tmp_path / "proj"
        (proj / "backend" / "api").mkdir(parents=True)
        (proj / "backend" / "api" / "routes.py").write_text(
            "from backend.mcp.tool_handlers import ToolHandlers\n"
        )
        report = await detector.check_drift("p1", str(proj))
        assert report.violations == []

    async def test_unverified_decisions_ignored(
        self, db: SQLiteBackend, detector: DriftDetector, tmp_path: Path
    ) -> None:
        # Unverified decisions must NOT generate constraints.
        d = Decision(
            title="Should be ignored",
            description="backend.api must not import backend.db",
            status="unverified",
        )
        await db.insert("decisions", d.to_dict())
        proj = tmp_path / "proj"
        (proj / "backend" / "api").mkdir(parents=True)
        (proj / "backend" / "api" / "routes.py").write_text(
            "from backend.db import X\n"
        )
        report = await detector.check_drift("p1", str(proj))
        assert report.violations == []

    async def test_missing_path_returns_empty_report(
        self, detector: DriftDetector
    ) -> None:
        report = await detector.check_drift("p1", "/nonexistent/path")
        assert report.violations == []

    async def test_drift_report_shape(
        self, detector: DriftDetector, tmp_path: Path
    ) -> None:
        proj = tmp_path / "proj"
        proj.mkdir()
        report = await detector.drift_report("p1", str(proj))
        assert report["project_id"] == "p1"
        assert "violations" in report
        assert "checked_files" in report
