"""Tests for backend.intelligence.staleness_scorer."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.staleness_scorer import (
    StalenessScorer,
    StalenessScorerError,
)
from backend.models import Decision, ProvenanceEdge

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
async def db(tmp_path: Path) -> SQLiteBackend:
    backend = SQLiteBackend(tmp_path / "stale.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def scorer(db: SQLiteBackend) -> StalenessScorer:
    return StalenessScorer(db=db)


async def _seed_decision(
    db: SQLiteBackend,
    *,
    last_accessed: datetime | None = None,
    has_provenance: bool = True,
    superseded_by: str | None = None,
) -> str:
    d = Decision(
        title="Test decision",
        last_accessed_at=last_accessed,
        superseded_by=superseded_by,
    )
    await db.insert("decisions", d.to_dict())
    if has_provenance:
        edge = ProvenanceEdge(
            source_type="decision",
            source_id=d.id,
            target_type="ast_change",
            target_id=uuid.uuid4(),
            relationship="touches",
        )
        await db.insert("provenance_edges", edge.to_dict())
    return str(d.id)


class TestSensors:
    async def test_fresh_decision_scores_zero(
        self, db: SQLiteBackend, scorer: StalenessScorer
    ) -> None:
        did = await _seed_decision(
            db, last_accessed=datetime.now(UTC) - timedelta(days=1)
        )
        score, signals = await scorer.score_decision(did)
        assert score == 0.0
        assert signals == []

    async def test_never_accessed_old_decision_scores_access_recency(
        self, db: SQLiteBackend, scorer: StalenessScorer
    ) -> None:
        did = await _seed_decision(
            db, last_accessed=datetime.now(UTC) - timedelta(days=91)
        )
        score, signals = await scorer.score_decision(did)
        # 0.4 from access recency + 0.0 from drift + 0.0 from coverage (has edge)
        assert score == pytest.approx(0.4, abs=1e-6)
        assert any("Not retrieved in" in s for s in signals)

    async def test_never_accessed_decision_with_no_coverage(
        self, db: SQLiteBackend, scorer: StalenessScorer
    ) -> None:
        did = await _seed_decision(
            db,
            last_accessed=datetime.now(UTC) - timedelta(days=91),
            has_provenance=False,
        )
        score, signals = await scorer.score_decision(did)
        # 0.4 (access) + 0.2 (coverage) = 0.6
        assert score == pytest.approx(0.6, abs=1e-6)
        assert any("No code changes linked" in s for s in signals)

    async def test_superseded_decision_scores_one(
        self, db: SQLiteBackend, scorer: StalenessScorer
    ) -> None:
        sup_id = str(uuid.uuid4())
        did = await _seed_decision(db, superseded_by=sup_id)
        score, signals = await scorer.score_decision(did)
        assert score == 1.0
        assert any("superseded" in s.lower() for s in signals)

    async def test_score_decision_missing_raises(
        self, scorer: StalenessScorer
    ) -> None:
        with pytest.raises(StalenessScorerError):
            await scorer.score_decision(str(uuid.uuid4()))

    async def test_contributions_cap_at_one(
        self, db: SQLiteBackend, scorer: StalenessScorer
    ) -> None:
        # Very old (0.4) + no coverage (0.2) still below 1.0 for raw sensors,
        # so we verify the combined sum is reported correctly.
        did = await _seed_decision(
            db,
            last_accessed=datetime.now(UTC) - timedelta(days=365),
            has_provenance=False,
        )
        score, _ = await scorer.score_decision(did)
        assert 0.0 <= score <= 1.0


class TestProjectScoring:
    async def test_score_project_persists(
        self, db: SQLiteBackend, scorer: StalenessScorer
    ) -> None:
        did_fresh = await _seed_decision(
            db, last_accessed=datetime.now(UTC) - timedelta(days=1)
        )
        did_old = await _seed_decision(
            db,
            last_accessed=datetime.now(UTC) - timedelta(days=120),
            has_provenance=False,
        )
        results = await scorer.score_project("default")
        ids = {did for did, _s, _sig in results}
        assert did_fresh in ids
        assert did_old in ids

        fresh_row = await db.get_by_id("decisions", did_fresh)
        old_row = await db.get_by_id("decisions", did_old)
        assert fresh_row is not None and old_row is not None
        assert float(fresh_row["staleness_score"]) == 0.0
        assert float(old_row["staleness_score"]) > 0.3

    async def test_score_decision_matches_project_scan(
        self, db: SQLiteBackend, scorer: StalenessScorer
    ) -> None:
        did = await _seed_decision(
            db, last_accessed=datetime.now(UTC) - timedelta(days=95)
        )
        single_score, _ = await scorer.score_decision(did)
        results = await scorer.score_project("default")
        match = next(s for i, s, _ in results if i == did)
        assert match == pytest.approx(single_score, abs=1e-6)


# ---------------------------------------------------------------------------
# Contradiction detection (Prompt 6)
# ---------------------------------------------------------------------------


class _FakeEmbedder:
    """Deterministic embedder producing in-band similarity for shared topics.

    Vectors for documents that share ``overlap_seed`` have cosine similarity
    inside the ``[0.55, 0.80]`` topic band by construction — the topic
    dimension contributes a large common component, and each doc's unique
    dimension contributes noise orthogonal to the other.
    """

    def __init__(self, overlap_seed: str) -> None:
        self._seed = overlap_seed.lower()
        self._unique_axes: dict[str, int] = {}

    async def embed_text(self, text: str) -> list[float]:
        has_topic = self._seed in text.lower()
        # 16-dim vector. Axis 0 is the shared "topic". Axes 1..15 are reserved
        # for per-doc "unique" components; we assign a distinct axis per new text
        # so two different docs with the same topic get orthogonal uniqueness.
        vec = [0.0] * 16
        if has_topic:
            vec[0] = 1.0
            axis = self._unique_axes.setdefault(
                text, 1 + len(self._unique_axes) % 14
            )
            vec[axis] = 0.8
        else:
            # Non-topic documents park far away on a dedicated axis.
            vec[15] = 1.0
        return vec


class TestDetectContradictions:
    async def test_direct_contradiction_flagged(
        self, db: SQLiteBackend
    ) -> None:
        from backend.intelligence.staleness_scorer import StalenessScorer

        # Two decisions in the same topic (cache) with opposing polarity.
        await _seed_text_decision(
            db,
            "use Redis for all caching",
            "Use Redis for all caching across every service — never skip the cache layer.",
        )
        await _seed_text_decision(
            db,
            "avoid external caching",
            "Avoid external cache dependencies; always use in-memory caching.",
        )
        scorer = StalenessScorer(
            db=db, embedder=_FakeEmbedder(overlap_seed="caching")
        )
        conflicts = await scorer.detect_contradictions("default")
        assert any(c.conflict_type == "direct_contradiction" for c in conflicts)

    async def test_scope_overlap_flagged(
        self, db: SQLiteBackend
    ) -> None:
        from backend.intelligence.staleness_scorer import StalenessScorer

        # Same topic, no polarity — should surface as scope_overlap.
        await _seed_text_decision(
            db,
            "cache tuning A",
            "Tune the cache TTL at 15 minutes for the product listings page.",
        )
        await _seed_text_decision(
            db,
            "cache tuning B",
            "Review cache key hashing for product listing invalidation.",
        )
        scorer = StalenessScorer(
            db=db, embedder=_FakeEmbedder(overlap_seed="cache")
        )
        conflicts = await scorer.detect_contradictions("default")
        assert any(c.conflict_type == "scope_overlap" for c in conflicts)

    async def test_constraint_conflict_detected(
        self, db: SQLiteBackend
    ) -> None:
        from backend.intelligence.staleness_scorer import StalenessScorer

        await _seed_text_decision(
            db,
            "layering",
            "backend.api must not import backend.db — route through handlers.",
        )
        await _seed_text_decision(
            db,
            "direct db access",
            "backend.api must import backend.db directly to avoid handler overhead.",
        )
        scorer = StalenessScorer(db=db)
        conflicts = await scorer.detect_contradictions("default")
        assert any(c.conflict_type == "constraint_conflict" for c in conflicts)

    async def test_duplicate_detection_runs_do_not_duplicate_conflicts(
        self, db: SQLiteBackend
    ) -> None:
        from backend.intelligence.staleness_scorer import StalenessScorer

        await _seed_text_decision(
            db,
            "use redis",
            "use Redis for all caching across the platform.",
        )
        await _seed_text_decision(
            db,
            "avoid redis",
            "avoid external caching — use in-memory caching only.",
        )
        scorer = StalenessScorer(
            db=db, embedder=_FakeEmbedder(overlap_seed="caching")
        )
        first = await scorer.detect_contradictions("default")
        second = await scorer.detect_contradictions("default")
        assert len(first) == len(second)

    async def test_no_contradictions_returns_empty(
        self, db: SQLiteBackend
    ) -> None:
        from backend.intelligence.staleness_scorer import StalenessScorer

        # Single decision — no pair to compare.
        await _seed_text_decision(db, "lone", "Only decision in the project.")
        scorer = StalenessScorer(db=db)
        assert await scorer.detect_contradictions("default") == []


async def _seed_text_decision(
    db: SQLiteBackend, title: str, description: str
) -> str:
    d = Decision(title=title, description=description, status="passed")
    await db.insert("decisions", d.to_dict())
    return str(d.id)
