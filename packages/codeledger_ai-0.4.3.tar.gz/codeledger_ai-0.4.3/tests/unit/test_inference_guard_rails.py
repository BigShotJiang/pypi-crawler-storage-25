"""End-to-end guard-rail tests for the passive inference engine.

Each test in this module exercises one of the ten documented guard rails
(GR-1..GR-10). Failures here indicate a guard-rail regression and must
be treated as blockers, not flaky behaviour.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from unittest.mock import patch

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.ast_tracker import ASTTracker
from backend.intelligence.decision_inferrer import (
    DEDUP_SIMILARITY_THRESHOLD,
    MAX_CONFIDENCE,
    MAX_SINGLE_SIGNAL_CONFIDENCE,
    DecisionInferrer,
    EvidenceItem,
    InferenceCandidate,
)
from backend.intelligence.semantic_search import SearchResult
from backend.models import Session

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


_DIFF_IMPORT_THIRD_PARTY = (
    "diff --git a/backend/auth/auth_service.py "
    "b/backend/auth/auth_service.py\n"
    "--- a/backend/auth/auth_service.py\n"
    "+++ b/backend/auth/auth_service.py\n"
    "@@ -0,0 +1,3 @@\n"
    "+import argon2\n"
    "+def hash_password(pw):\n"
    "+    return argon2.hash(pw)\n"
)

_DIFF_IMPORT_STDLIB = (
    "diff --git a/app.py b/app.py\n"
    "--- a/app.py\n"
    "+++ b/app.py\n"
    "@@ -0,0 +1,3 @@\n"
    "+import json\n"
    "+def dumps(x):\n"
    "+    return json.dumps(x)\n"
)


@pytest.fixture
async def db(tmp_path: Path) -> SQLiteBackend:
    backend = SQLiteBackend(tmp_path / "gr.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def tracker(db: SQLiteBackend) -> ASTTracker:
    return ASTTracker(db=db)


@pytest.fixture
def inferrer(db: SQLiteBackend, tracker: ASTTracker) -> DecisionInferrer:
    return DecisionInferrer(db=db, ast_tracker=tracker)


async def _start_session(db: SQLiteBackend) -> Session:
    session = Session(agent_name="gr-test", status="active")
    await db.insert("sessions", session.to_dict())
    return session


class _StubSearch:
    """Minimal stub of :class:`SemanticSearch` for GR-7 tests.

    The real class needs an embedder, a vector store, and a DB. For GR-7
    we only need the ``search(query, project_id, top_k, blend_weight)``
    surface; everything else is unused by the inferrer's dedup path.
    """

    def __init__(
        self,
        results: list[SearchResult] | None = None,
        *,
        raise_on_search: bool = False,
    ) -> None:
        self._results = list(results or [])
        self._raise = raise_on_search
        self.calls: list[dict[str, Any]] = []

    async def search(
        self,
        query: str,
        project_id: str,
        top_k: int = 10,
        *,
        persona: str | None = None,
        blend_weight: float = 0.6,
    ) -> list[SearchResult]:
        self.calls.append(
            {
                "query": query,
                "project_id": project_id,
                "top_k": top_k,
                "blend_weight": blend_weight,
            }
        )
        if self._raise:
            raise RuntimeError("stubbed failure")
        return list(self._results)


# ---------------------------------------------------------------------------
# GR-1 — Never fabricate
# ---------------------------------------------------------------------------


async def test_GR1_empty_session_produces_no_candidates(
    db: SQLiteBackend, inferrer: DecisionInferrer
) -> None:
    session = await _start_session(db)
    result = await inferrer.infer_from_session(
        session_id=str(session.id), project_id="p"
    )
    assert result == []


def test_GR1_candidate_without_evidence_scores_zero(
    inferrer: DecisionInferrer,
) -> None:
    candidate = InferenceCandidate(
        title="ghost",
        description="ghost",
        evidence=[],
        tags=[],
        files_affected=[],
    )
    scored = inferrer._score_candidate(candidate)
    assert scored.confidence == 0.0


# ---------------------------------------------------------------------------
# GR-2 — Calibrated confidence
# ---------------------------------------------------------------------------


def test_GR2_single_signal_capped_at_065(
    inferrer: DecisionInferrer,
) -> None:
    candidate = InferenceCandidate(
        title="add dep",
        description="desc",
        evidence=[
            EvidenceItem(
                evidence_type="dependency_added",  # weight 0.65
                description="dep",
                source_id="s1",
                source_type="file_change",
                file_path="pyproject.toml",
            )
        ],
        tags=[],
        files_affected=["pyproject.toml"],
    )
    scored = inferrer._score_candidate(candidate)
    assert scored.confidence == pytest.approx(MAX_SINGLE_SIGNAL_CONFIDENCE)


def test_GR2_multi_signal_capped_at_max_confidence(
    inferrer: DecisionInferrer,
) -> None:
    candidate = InferenceCandidate(
        title="broad change",
        description="desc",
        evidence=[
            EvidenceItem(
                "dependency_added", "d", "s1", "file_change", "pyproject.toml"
            ),
            EvidenceItem(
                "new_import_third_party", "d", "s2", "ast_change", "app.py"
            ),
            EvidenceItem(
                "config_file_modified", "d", "s3", "file_change", "setup.cfg"
            ),
            EvidenceItem(
                "new_class_inherits", "d", "s4", "ast_change", "app.py"
            ),
        ],
        tags=[],
        files_affected=[],
    )
    scored = inferrer._score_candidate(candidate)
    assert scored.confidence <= MAX_CONFIDENCE


# ---------------------------------------------------------------------------
# GR-3 — Factual titles, no fabricated rationale
# ---------------------------------------------------------------------------


async def test_GR3_title_describes_observable_fact_not_rationale(
    db: SQLiteBackend,
    tracker: ASTTracker,
    inferrer: DecisionInferrer,
) -> None:
    session = await _start_session(db)
    await tracker.process_change_event(
        change_event_id="c1",
        change_event_source="git_commit",
        diff_text=_DIFF_IMPORT_THIRD_PARTY,
        project_id="p",
        active_session_id=str(session.id),
    )
    candidates = await inferrer.infer_from_session(
        session_id=str(session.id), project_id="p"
    )
    assert candidates, "expected at least one candidate from a third-party import"
    for c in candidates:
        blob = f"{c.candidate_title} {c.candidate_description}".lower()
        # Rationale-language check: inferred records must not claim to
        # know *why* the change was made.
        for banned in ("because", "recommend", "best practice", "should use"):
            assert banned not in blob, (
                f"candidate contains rationale language {banned!r}: {blob!r}"
            )
        # Affirmative check: the description ends with the standard
        # 'verify and add rationale' note.
        assert "verify and add rationale" in c.candidate_description


# ---------------------------------------------------------------------------
# GR-4 — Traceable evidence
# ---------------------------------------------------------------------------


async def test_GR4_every_inferred_decision_carries_its_evidence(
    db: SQLiteBackend,
    tracker: ASTTracker,
    inferrer: DecisionInferrer,
) -> None:
    session = await _start_session(db)
    await tracker.process_change_event(
        change_event_id="c1",
        change_event_source="git_commit",
        diff_text=_DIFF_IMPORT_THIRD_PARTY,
        project_id="p",
        active_session_id=str(session.id),
    )
    candidates = await inferrer.infer_from_session(
        session_id=str(session.id), project_id="p"
    )
    assert candidates
    for c in candidates:
        assert c.evidence, "evidence list must not be empty (GR-1/GR-4)"
        for item in c.evidence:
            # Every item is a dict with the documented shape.
            assert item.get("evidence_type"), item
            assert item.get("source_id"), item
            assert item.get("source_type"), item
            assert item.get("file_path"), item


# ---------------------------------------------------------------------------
# GR-5 — Never blocks session.end
# ---------------------------------------------------------------------------


async def test_GR5_db_query_exception_returns_empty_list(
    db: SQLiteBackend, inferrer: DecisionInferrer
) -> None:
    session = await _start_session(db)

    async def exploder(*_args: Any, **_kwargs: Any) -> list[Any]:
        raise RuntimeError("simulated DB failure")

    # Monkeypatch the first DB call the inferrer makes.
    original = db.query
    db.query = exploder  # type: ignore[method-assign]
    try:
        result = await inferrer.infer_from_session(
            session_id=str(session.id), project_id="p"
        )
    finally:
        db.query = original  # type: ignore[method-assign]
    assert result == []


async def test_GR5_timeout_returns_empty_list(
    db: SQLiteBackend, inferrer: DecisionInferrer
) -> None:
    session = await _start_session(db)

    import asyncio

    async def slow(*_args: Any, **_kwargs: Any) -> list[Any]:
        await asyncio.sleep(5)
        return []

    original = db.query
    db.query = slow  # type: ignore[method-assign]
    try:
        with patch(
            "backend.intelligence.decision_inferrer.INFERENCE_TIMEOUT_SECONDS",
            0.1,
        ):
            result = await inferrer.infer_from_session(
                session_id=str(session.id), project_id="p"
            )
    finally:
        db.query = original  # type: ignore[method-assign]
    assert result == []


async def test_GR5_dedup_failure_still_yields_candidates(
    db: SQLiteBackend,
    tracker: ASTTracker,
) -> None:
    """When the vector store raises during dedup, candidates still flow."""
    session = await _start_session(db)
    await tracker.process_change_event(
        change_event_id="c1",
        change_event_source="git_commit",
        diff_text=_DIFF_IMPORT_THIRD_PARTY,
        project_id="p",
        active_session_id=str(session.id),
    )
    stub = _StubSearch(raise_on_search=True)
    inferrer = DecisionInferrer(db=db, ast_tracker=tracker, semantic_search=stub)
    candidates = await inferrer.infer_from_session(
        session_id=str(session.id), project_id="p"
    )
    assert candidates, "dedup failure must not drop valid candidates"


# ---------------------------------------------------------------------------
# GR-6 — Always pending
# ---------------------------------------------------------------------------


async def test_GR6_inferred_status_is_pending(
    db: SQLiteBackend,
    tracker: ASTTracker,
    inferrer: DecisionInferrer,
) -> None:
    session = await _start_session(db)
    await tracker.process_change_event(
        change_event_id="c1",
        change_event_source="git_commit",
        diff_text=_DIFF_IMPORT_THIRD_PARTY,
        project_id="p",
        active_session_id=str(session.id),
    )
    candidates = await inferrer.infer_from_session(
        session_id=str(session.id), project_id="p"
    )
    assert candidates
    for c in candidates:
        assert c.status == "pending"


# ---------------------------------------------------------------------------
# GR-7 — Deduplication
# ---------------------------------------------------------------------------


async def test_GR7_similar_existing_decision_deduplicates(
    db: SQLiteBackend, tracker: ASTTracker
) -> None:
    session = await _start_session(db)
    await tracker.process_change_event(
        change_event_id="c1",
        change_event_source="git_commit",
        diff_text=_DIFF_IMPORT_THIRD_PARTY,
        project_id="p",
        active_session_id=str(session.id),
    )
    duplicate = SearchResult(
        item_id="existing-decision-id",
        score=0.92,  # above DEDUP_SIMILARITY_THRESHOLD
        item_type="decision",
        metadata={"title": "Add argon2 dependency to project"},
    )
    stub = _StubSearch(results=[duplicate])
    inferrer = DecisionInferrer(
        db=db, ast_tracker=tracker, semantic_search=stub
    )
    candidates = await inferrer.infer_from_session(
        session_id=str(session.id), project_id="p"
    )
    # The argon2 candidate should be deduplicated. Other candidates
    # (if any) may still come through.
    for c in candidates:
        assert "argon2" not in c.candidate_title.lower()


async def test_GR7_score_below_threshold_keeps_candidate(
    db: SQLiteBackend, tracker: ASTTracker
) -> None:
    session = await _start_session(db)
    await tracker.process_change_event(
        change_event_id="c1",
        change_event_source="git_commit",
        diff_text=_DIFF_IMPORT_THIRD_PARTY,
        project_id="p",
        active_session_id=str(session.id),
    )
    weak = SearchResult(
        item_id="existing",
        score=DEDUP_SIMILARITY_THRESHOLD - 0.1,  # 0.75 — below threshold
        item_type="decision",
        metadata={"title": "something else"},
    )
    stub = _StubSearch(results=[weak])
    inferrer = DecisionInferrer(
        db=db, ast_tracker=tracker, semantic_search=stub
    )
    candidates = await inferrer.infer_from_session(
        session_id=str(session.id), project_id="p"
    )
    assert any(
        "argon2" in c.candidate_title.lower() for c in candidates
    ), "weak similarity must not drop the candidate"


# ---------------------------------------------------------------------------
# GR-8 — No LLM calls in the inference hot path
# ---------------------------------------------------------------------------


def test_GR8_extract_evidence_is_synchronous_and_free_of_network(
    inferrer: DecisionInferrer,
) -> None:
    """``_extract_evidence`` is a pure function — not even ``async``.

    Any LLM or embedding call would need to be awaited, which the method
    signature forbids. We assert that here to guard against regression.
    """
    import inspect

    assert not inspect.iscoroutinefunction(inferrer._extract_evidence)


def test_GR8_score_candidate_is_pure(inferrer: DecisionInferrer) -> None:
    import inspect

    assert not inspect.iscoroutinefunction(inferrer._score_candidate)


# ---------------------------------------------------------------------------
# GR-9 — Session-scoped queries only
# ---------------------------------------------------------------------------


async def test_GR9_queries_filter_on_session_id(
    db: SQLiteBackend, inferrer: DecisionInferrer
) -> None:
    session = await _start_session(db)
    calls: list[tuple[str, dict[str, Any] | None]] = []
    original = db.query

    async def spy(table: str, **kwargs: Any) -> list[Any]:
        calls.append((table, kwargs.get("where")))
        return await original(table, **kwargs)

    db.query = spy  # type: ignore[method-assign]
    try:
        await inferrer.infer_from_session(
            session_id=str(session.id), project_id="p"
        )
    finally:
        db.query = original  # type: ignore[method-assign]

    # Every query against session_events / ast_changes / unlinked_*
    # must scope on this session id.
    scoped_tables = {
        "session_events",
        "ast_changes",
        "unlinked_commits",
        "unlinked_file_changes",
        "inferred_decisions",
    }
    sid = str(session.id)
    for table, where in calls:
        if (
            table in scoped_tables
            and where is not None
            and "session_id" in where
        ):
            assert where["session_id"] == sid, (
                f"query against {table} scoped on wrong session_id: {where}"
            )


# ---------------------------------------------------------------------------
# GR-10 — Noise import filtering
# ---------------------------------------------------------------------------


async def test_GR10_stdlib_import_does_not_generate_candidate(
    db: SQLiteBackend,
    tracker: ASTTracker,
    inferrer: DecisionInferrer,
) -> None:
    session = await _start_session(db)
    await tracker.process_change_event(
        change_event_id="c-stdlib",
        change_event_source="git_commit",
        diff_text=_DIFF_IMPORT_STDLIB,
        project_id="p",
        active_session_id=str(session.id),
    )
    candidates = await inferrer.infer_from_session(
        session_id=str(session.id), project_id="p"
    )
    # No candidate should be titled around the stdlib ``json`` import.
    # A function-add candidate for ``dumps`` may still appear — that's
    # legitimate structural evidence. What's forbidden is treating
    # ``import json`` as a technology decision.
    for c in candidates:
        assert "add `json`" not in c.candidate_title.lower()
        assert "json dependency" not in c.candidate_title.lower()


async def test_GR10_third_party_import_does_generate_candidate(
    db: SQLiteBackend,
    tracker: ASTTracker,
    inferrer: DecisionInferrer,
) -> None:
    session = await _start_session(db)
    await tracker.process_change_event(
        change_event_id="c-3p",
        change_event_source="git_commit",
        diff_text=_DIFF_IMPORT_THIRD_PARTY,
        project_id="p",
        active_session_id=str(session.id),
    )
    candidates = await inferrer.infer_from_session(
        session_id=str(session.id), project_id="p"
    )
    assert any(
        "argon2" in c.candidate_title.lower() for c in candidates
    ), "third-party import must produce a candidate"
