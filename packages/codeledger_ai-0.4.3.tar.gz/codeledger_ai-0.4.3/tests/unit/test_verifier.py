"""Tests for backend.verification.verifier — CI webhook status transitions.

Covers: status transitions (unverified→pending→passed/failed/pending again),
webhook payload validation, file_watcher mode fallback, persistence of
Verification rows, and graceful handling of missing decisions.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.ast_tracker import ASTTracker
from backend.models import Decision
from backend.verification.verifier import Verifier, VerifierError

if TYPE_CHECKING:
    from pathlib import Path


_DIFF_ADD_FN = (
    "diff --git a/v.py b/v.py\n"
    "--- a/v.py\n"
    "+++ b/v.py\n"
    "@@ -0,0 +1,2 @@\n"
    "+def verified_fn(n):\n"
    "+    return n\n"
)


@pytest.fixture
async def db(tmp_path: Path) -> SQLiteBackend:
    backend = SQLiteBackend(tmp_path / "verifier.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def verifier(db: SQLiteBackend) -> Verifier:
    return Verifier(db)


@pytest.fixture
def tracker(db: SQLiteBackend) -> ASTTracker:
    return ASTTracker(db=db)


async def _seed_decision_linked_to_commit(
    db: SQLiteBackend, tracker: ASTTracker, commit_hash: str, project_id: str
) -> uuid.UUID:
    """Create a decision and a linked AST change for ``commit_hash``."""
    decision = Decision(
        title="Touch v.py",
        description="Adds verified_fn in v.py",
    )
    decision.created_at = datetime.now(UTC)
    await db.insert("decisions", decision.to_dict())

    await tracker.process_change_event(
        change_event_id=commit_hash,
        change_event_source="git_commit",
        diff_text=_DIFF_ADD_FN,
        project_id=project_id,
    )
    return decision.id


# ---------------------------------------------------------------------------
# process_webhook
# ---------------------------------------------------------------------------


class TestProcessWebhook:
    """Webhook payload processing and status transitions."""

    async def test_passed_transitions_linked_decision(
        self,
        db: SQLiteBackend,
        verifier: Verifier,
        tracker: ASTTracker,
    ) -> None:
        decision_id = await _seed_decision_linked_to_commit(
            db, tracker, "commit-a", "proj-1"
        )
        result = await verifier.process_webhook(
            {"commit_hash": "commit-a", "status": "passed"},
            provider="github",
            project_id="proj-1",
        )
        assert result["received"] is True
        assert str(decision_id) in result["transitioned_decisions"]

        row = await db.get_by_id("decisions", str(decision_id))
        assert row is not None
        assert row["status"] == "passed"

        verifications = await db.query("verifications")
        assert len(verifications) == 1
        assert verifications[0]["status"] == "passed"

    async def test_failed_after_pending_transitions_to_failed(
        self,
        db: SQLiteBackend,
        verifier: Verifier,
        tracker: ASTTracker,
    ) -> None:
        decision_id = await _seed_decision_linked_to_commit(
            db, tracker, "commit-b", "proj-1"
        )
        await verifier.process_webhook(
            {"commit_hash": "commit-b", "status": "pending"},
            provider="github",
            project_id="proj-1",
        )
        await verifier.process_webhook(
            {"commit_hash": "commit-b", "status": "failed"},
            provider="github",
            project_id="proj-1",
        )
        row = await db.get_by_id("decisions", str(decision_id))
        assert row is not None
        assert row["status"] == "failed"

    async def test_failed_then_pending_allows_rerun(
        self,
        db: SQLiteBackend,
        verifier: Verifier,
        tracker: ASTTracker,
    ) -> None:
        decision_id = await _seed_decision_linked_to_commit(
            db, tracker, "commit-c", "proj-1"
        )
        await verifier.process_webhook(
            {"commit_hash": "commit-c", "status": "failed"},
            provider="github",
            project_id="proj-1",
        )
        await verifier.process_webhook(
            {"commit_hash": "commit-c", "status": "pending"},
            provider="github",
            project_id="proj-1",
        )
        row = await db.get_by_id("decisions", str(decision_id))
        assert row is not None
        assert row["status"] == "pending"

    async def test_same_status_is_noop(
        self,
        db: SQLiteBackend,
        verifier: Verifier,
        tracker: ASTTracker,
    ) -> None:
        await _seed_decision_linked_to_commit(
            db, tracker, "commit-d", "proj-1"
        )
        first = await verifier.process_webhook(
            {"commit_hash": "commit-d", "status": "pending"},
            provider="github",
            project_id="proj-1",
        )
        second = await verifier.process_webhook(
            {"commit_hash": "commit-d", "status": "pending"},
            provider="github",
            project_id="proj-1",
        )
        assert first["transitioned_decisions"]
        assert second["transitioned_decisions"] == []

    async def test_invalid_status_rejected(self, verifier: Verifier) -> None:
        with pytest.raises(VerifierError):
            await verifier.process_webhook(
                {"commit_hash": "x", "status": "weird"},
                provider="github",
                project_id="proj-1",
            )

    async def test_missing_commit_hash_rejected(self, verifier: Verifier) -> None:
        with pytest.raises(VerifierError):
            await verifier.process_webhook(
                {"status": "passed"},
                provider="github",
                project_id="proj-1",
            )

    async def test_no_matching_commit_returns_empty(
        self, verifier: Verifier
    ) -> None:
        result = await verifier.process_webhook(
            {"commit_hash": "nonexistent", "status": "passed"},
            provider="github",
            project_id="proj-1",
        )
        assert result["transitioned_decisions"] == []


# ---------------------------------------------------------------------------
# file_watcher fallback
# ---------------------------------------------------------------------------


class TestFileWatcherMode:
    """All public methods degrade gracefully for file_watcher projects."""

    async def test_process_webhook_returns_unavailable(
        self, verifier: Verifier
    ) -> None:
        result = await verifier.process_webhook(
            {"commit_hash": "c", "status": "passed"},
            provider="github",
            project_id="proj-1",
            change_detection_backend="file_watcher",
        )
        assert result["verification_available"] is False
        assert result["change_detection_backend"] == "file_watcher"

    async def test_get_status_returns_unavailable(
        self, verifier: Verifier
    ) -> None:
        result = await verifier.get_status(
            uuid.uuid4(),
            change_detection_backend="file_watcher",
        )
        assert result["verification_available"] is False

    async def test_get_unverified_returns_unavailable(
        self, verifier: Verifier
    ) -> None:
        result = await verifier.get_unverified(
            "proj-1", change_detection_backend="file_watcher"
        )
        assert result["verification_available"] is False


# ---------------------------------------------------------------------------
# get_status / listing helpers
# ---------------------------------------------------------------------------


class TestStatusQueries:
    async def test_get_status_for_known_decision(
        self,
        db: SQLiteBackend,
        verifier: Verifier,
        tracker: ASTTracker,
    ) -> None:
        decision_id = await _seed_decision_linked_to_commit(
            db, tracker, "commit-e", "proj-1"
        )
        result = await verifier.get_status(decision_id)
        assert result["status"] == "unverified"
        assert result["verification_available"] is True

    async def test_get_status_unknown_raises(
        self, verifier: Verifier
    ) -> None:
        with pytest.raises(VerifierError):
            await verifier.get_status(uuid.uuid4())

    async def test_get_unverified_excludes_passed(
        self,
        db: SQLiteBackend,
        verifier: Verifier,
    ) -> None:
        # Directly insert two decisions in each target state — the link
        # pipeline is covered elsewhere; here we only verify the state
        # filter in ``get_unverified``.
        d_unv = Decision(title="Still open")
        d_pass = Decision(title="Passed", status="passed")
        d_pend = Decision(title="Pending", status="pending")
        for d in (d_unv, d_pass, d_pend):
            await db.insert("decisions", d.to_dict())

        result = await verifier.get_unverified("proj-1")
        ids = {d["id"] for d in result["decisions"]}
        assert str(d_unv.id) in ids
        assert str(d_pend.id) in ids
        assert str(d_pass.id) not in ids
