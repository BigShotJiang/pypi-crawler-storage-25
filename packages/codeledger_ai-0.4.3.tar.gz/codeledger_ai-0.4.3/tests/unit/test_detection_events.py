"""Tests for backend.detection.events — :class:`ChangeEvent` model."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest
from pydantic import ValidationError

from backend.detection.events import ALLOWED_ACTOR_TYPES, ChangeEvent


def _now() -> datetime:
    return datetime.now(UTC)


class TestValidConstruction:
    """Happy-path construction for each source + actor combination."""

    def test_human_git_commit(self) -> None:
        ev = ChangeEvent(
            change_event_source="git_commit",
            actor_type="human",
            actor_id="dev@example.com",
            project_id="proj",
            created_at=_now(),
        )
        assert ev.actor_id == "dev@example.com"

    def test_file_snapshot_human_no_actor_id(self) -> None:
        ev = ChangeEvent(
            change_event_source="file_snapshot",
            actor_type="human",
            actor_id=None,
            project_id="proj",
            created_at=_now(),
        )
        assert ev.actor_id is None

    def test_agent_reported_requires_actor_id(self) -> None:
        ev = ChangeEvent(
            change_event_source="agent_reported",
            actor_type="agent",
            actor_id="session-123",
            project_id="proj",
            created_at=_now(),
        )
        assert ev.actor_type == "agent"

    def test_webhook_bot_requires_actor_id(self) -> None:
        ev = ChangeEvent(
            change_event_source="git_commit",
            actor_type="webhook_bot",
            actor_id="dependabot[bot]",
            project_id="proj",
            created_at=_now(),
        )
        assert ev.actor_id == "dependabot[bot]"


class TestInvalidConstruction:
    """Every rejection path must surface a pydantic ValidationError."""

    def test_unknown_actor_type(self) -> None:
        with pytest.raises(ValidationError):
            ChangeEvent(
                change_event_source="git_commit",
                actor_type="alien",  # type: ignore[arg-type]
                actor_id="x",
                project_id="proj",
                created_at=_now(),
            )

    def test_unknown_source(self) -> None:
        with pytest.raises(ValidationError):
            ChangeEvent(
                change_event_source="svn_commit",  # type: ignore[arg-type]
                actor_type="human",
                actor_id=None,
                project_id="proj",
                created_at=_now(),
            )

    def test_missing_actor_id_for_agent(self) -> None:
        with pytest.raises(ValidationError, match="actor_id is required"):
            ChangeEvent(
                change_event_source="agent_reported",
                actor_type="agent",
                actor_id=None,
                project_id="proj",
                created_at=_now(),
            )

    def test_empty_actor_id_for_bot(self) -> None:
        with pytest.raises(ValidationError):
            ChangeEvent(
                change_event_source="git_commit",
                actor_type="ci_bot",
                actor_id="   ",
                project_id="proj",
                created_at=_now(),
            )

    def test_empty_project_id(self) -> None:
        with pytest.raises(ValidationError):
            ChangeEvent(
                change_event_source="git_commit",
                actor_type="human",
                actor_id=None,
                project_id="   ",
                created_at=_now(),
            )

    def test_payload_rejects_secret_keys(self) -> None:
        with pytest.raises(ValidationError, match="secret-like names"):
            ChangeEvent(
                change_event_source="git_commit",
                actor_type="human",
                actor_id=None,
                project_id="proj",
                payload={"token": "oops"},
                created_at=_now(),
            )

    def test_extra_fields_forbidden(self) -> None:
        with pytest.raises(ValidationError):
            ChangeEvent(
                change_event_source="git_commit",
                actor_type="human",
                actor_id=None,
                project_id="proj",
                created_at=_now(),
                surprise="boom",  # type: ignore[call-arg]
            )


class TestFromLegacyRow:
    """Legacy v10-era rows must map cleanly to the modern model."""

    def test_git_commit_row(self) -> None:
        now_iso = _now().isoformat()
        ev = ChangeEvent.from_legacy_row(
            {
                "change_event_type": "git_commit",
                "project_id": "proj",
                "created_at": now_iso,
            }
        )
        assert ev.change_event_source == "git_commit"
        assert ev.actor_type == "human"
        assert ev.actor_id is None
        assert ev.payload == {}

    def test_file_snapshot_row(self) -> None:
        ev = ChangeEvent.from_legacy_row(
            {
                "change_event_type": "file_snapshot",
                "project_id": "proj",
                "created_at": _now(),
            }
        )
        assert ev.change_event_source == "file_snapshot"
        assert ev.actor_type == "human"

    def test_row_missing_project_id_rejected(self) -> None:
        with pytest.raises(ValueError, match="missing project_id"):
            ChangeEvent.from_legacy_row(
                {"change_event_type": "git_commit", "created_at": _now()}
            )

    def test_row_missing_created_at_rejected(self) -> None:
        with pytest.raises(ValueError, match="missing created_at"):
            ChangeEvent.from_legacy_row(
                {"change_event_type": "git_commit", "project_id": "proj"}
            )

    def test_row_with_unknown_source_rejected(self) -> None:
        with pytest.raises(ValueError, match="Unknown change_event_source"):
            ChangeEvent.from_legacy_row(
                {
                    "change_event_type": "svn_commit",
                    "project_id": "proj",
                    "created_at": _now(),
                }
            )

    def test_row_already_modern_shape(self) -> None:
        ev = ChangeEvent.from_legacy_row(
            {
                "change_event_source": "agent_reported",
                "project_id": "proj",
                "created_at": _now(),
            }
        )
        # Legacy converter always strips actor info regardless of shape;
        # downstream callers re-enrich from the new columns separately.
        assert ev.change_event_source == "agent_reported"
        # But agent source with no actor_id would be a cross-field
        # error — legacy converter is for ``human`` rows only.
        # (The test proves the converter refuses to invent actor_id.)
        assert ev.actor_type == "human"


class TestConstants:
    """Exported literal sets are consistent with the Literal types."""

    def test_actor_types(self) -> None:
        assert ALLOWED_ACTOR_TYPES == {
            "human",
            "ci_bot",
            "webhook_bot",
            "agent",
        }
