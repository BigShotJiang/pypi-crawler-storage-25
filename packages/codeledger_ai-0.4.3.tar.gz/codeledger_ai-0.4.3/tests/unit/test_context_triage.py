"""Unit tests for backend/intelligence/context_triage.py.

Tests use a deterministic counter function (``len(text.split())``) by
default so budgets and expectations are predictable, plus a handful of
tests against the real ``tiktoken``-backed counter to verify integration.
"""

from __future__ import annotations

from typing import Any

import pytest

from backend.intelligence.context_triage import (
    ContextTriage,
    ContextTriageError,
    TriageResult,
    format_context_block,
)
from backend.intelligence.semantic_search import SearchResult
from backend.utils.token_counter import count_tokens


def _word_counter(text: str) -> int:
    """Deterministic token counter used across tests.

    A word count (whitespace-delimited) gives predictable totals without
    depending on tiktoken's BPE behaviour, letting tests exercise the
    triage algorithm directly.
    """
    return len(text.split()) if text else 0


def _make_result(
    item_id: str,
    text: str,
    *,
    score: float,
    item_type: str = "decision",
    project_id: str = "proj",
    title: str | None = None,
    verification: str | None = None,
) -> SearchResult:
    metadata: dict[str, Any] = {"text": text, "project_id": project_id}
    if title:
        metadata["title"] = title
    if verification:
        metadata["verification_status"] = verification
    return SearchResult(
        item_id=item_id,
        score=score,
        item_type=item_type,
        metadata=metadata,
    )


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


class TestValidation:
    def test_items_must_be_list(self) -> None:
        triage = ContextTriage(counter=_word_counter)
        with pytest.raises(ContextTriageError):
            triage.triage("not-a-list", 100)  # type: ignore[arg-type]

    def test_budget_must_be_int(self) -> None:
        triage = ContextTriage(counter=_word_counter)
        with pytest.raises(ContextTriageError):
            triage.triage([], 100.5)  # type: ignore[arg-type]

    def test_negative_budget_rejected(self) -> None:
        triage = ContextTriage(counter=_word_counter)
        with pytest.raises(ContextTriageError):
            triage.triage([], -1)

    def test_invalid_summary_ratio_rejected(self) -> None:
        with pytest.raises(ContextTriageError):
            ContextTriage(counter=_word_counter, summary_ratio=0.0)
        with pytest.raises(ContextTriageError):
            ContextTriage(counter=_word_counter, summary_ratio=1.0)


# ---------------------------------------------------------------------------
# Triage: include band
# ---------------------------------------------------------------------------


class TestIncludeAllFits:
    def test_empty_items_returns_empty_result(self) -> None:
        triage = ContextTriage(counter=_word_counter)
        result = triage.triage([], 100)
        assert isinstance(result, TriageResult)
        assert result.included_items == []
        assert result.summarized_items == []
        assert result.excluded_summary == ""
        assert result.total_tokens_used == 0
        assert result.budget_remaining == 100

    def test_all_items_fit_within_budget(self) -> None:
        items = [
            _make_result("a", "one two three", score=0.9),
            _make_result("b", "four five", score=0.8),
        ]
        triage = ContextTriage(counter=_word_counter)
        result = triage.triage(items, 10)
        assert [t.item_id for t in result.included_items] == ["a", "b"]
        assert result.summarized_items == []
        assert result.excluded_summary == ""
        assert result.total_tokens_used == 5
        assert result.budget_remaining == 5

    def test_items_are_sorted_by_score_descending(self) -> None:
        # Highest score must appear first regardless of input order.
        items = [
            _make_result("low", "one", score=0.3),
            _make_result("high", "two", score=0.9),
            _make_result("mid", "three", score=0.6),
        ]
        triage = ContextTriage(counter=_word_counter)
        result = triage.triage(items, 10)
        assert [t.item_id for t in result.included_items] == [
            "high",
            "mid",
            "low",
        ]

    def test_items_without_text_metadata_are_skipped(self) -> None:
        items = [
            SearchResult(
                item_id="a", score=0.9, item_type="decision", metadata={}
            ),
            _make_result("b", "has text", score=0.8),
        ]
        triage = ContextTriage(counter=_word_counter)
        result = triage.triage(items, 10)
        assert [t.item_id for t in result.included_items] == ["b"]


# ---------------------------------------------------------------------------
# Triage: summarise band
# ---------------------------------------------------------------------------


class TestSummarisation:
    def test_overflow_under_50pct_triggers_summary(self) -> None:
        # Budget 10. First item uses 7 (fits). Second item is 6 tokens,
        # remaining is 3; overflow = 3/6 = 0.5 — NOT strictly less than,
        # so this should excluded. Instead, use overflow < 50%:
        #
        # Item 2 is 5 tokens, remaining 3. overflow = 2/5 = 0.4 → summarise.
        items = [
            _make_result(
                "a",
                "one two three four five six seven",  # 7 words
                score=0.95,
            ),
            _make_result(
                "b",
                "First sentence here. Second sentence here. Trailing words.",
                score=0.85,
            ),
        ]
        # Item b: 9 words. Budget 10, a uses 7, remaining 3.
        # overflow = (9 - 3) / 9 = 0.666... → NOT summarised → excluded.
        triage = ContextTriage(counter=_word_counter, min_summary_tokens=2)
        result = triage.triage(items, 10)
        assert [t.item_id for t in result.included_items] == ["a"]
        # Since overflow is >= 50%, b is excluded, not summarised.
        assert result.summarized_items == []
        assert len(result.excluded_items) == 1
        assert result.excluded_items[0].item_id == "b"

    def test_summarisation_preserves_first_sentence_when_it_fits(self) -> None:
        # Design: item has a short first sentence that fits the summary
        # target, and a longer tail that doesn't.
        items = [
            _make_result(
                "a",
                "Short first sentence. This is a much longer trailing tail"
                " with many extra words that will never fit.",
                score=0.9,
            ),
        ]
        triage = ContextTriage(counter=_word_counter, min_summary_tokens=2)
        # Budget 5: the full text is 20 words, doesn't fit. overflow=15/20=0.75 — excluded.
        # Budget 16: full text is 20 words, overflow = 4/20 = 0.2 → summarise.
        # Summary target = max(2, int(20*0.3)) = 6, capped at remaining (16). = 6.
        # First sentence "Short first sentence." = 3 words, fits in 6 → use it.
        result = triage.triage(items, 16)
        assert len(result.summarized_items) == 1
        summary = result.summarized_items[0]
        assert summary.was_summarised is True
        assert summary.text == "Short first sentence."
        assert summary.token_count == 3

    def test_summarisation_respects_remaining_budget(self) -> None:
        # Verify the summary never exceeds the remaining budget.
        long_text = " ".join(f"word{i}" for i in range(100))  # 100 words
        items = [
            _make_result("a", long_text, score=0.9),
        ]
        # Budget 60: overflow = 40/100 = 0.4 → summarise.
        # target = max(10, int(100*0.3)) = 30. Remaining 60, fits.
        triage = ContextTriage(counter=_word_counter, min_summary_tokens=10)
        result = triage.triage(items, 60)
        assert len(result.summarized_items) == 1
        assert result.summarized_items[0].token_count <= 30
        assert result.total_tokens_used <= 60


# ---------------------------------------------------------------------------
# Triage: exclude band and collapse
# ---------------------------------------------------------------------------


class TestExclusion:
    def test_items_that_cannot_even_summarise_are_excluded(self) -> None:
        items = [
            _make_result(
                "a",
                "ten nine eight seven six five four three two one",
                score=0.9,
            ),
            _make_result(
                "b",
                "too big to fit here at all",  # 7 words
                score=0.8,
                title="B topic",
            ),
        ]
        # Budget 11. a=10 fits. Remaining=1. b=7. overflow=6/7=0.857 → no summary.
        triage = ContextTriage(counter=_word_counter)
        result = triage.triage(items, 11)
        assert [t.item_id for t in result.included_items] == ["a"]
        assert result.summarized_items == []
        assert len(result.excluded_items) == 1
        assert result.excluded_items[0].item_id == "b"
        assert result.excluded_items[0].topic == "B topic"
        assert "B topic" in result.excluded_summary
        assert "decision" in result.excluded_summary

    def test_once_excluded_all_tail_items_collapse(self) -> None:
        # Once one item cannot fit, every lower-ranked item is lumped in
        # even if individually it would fit — preserves relevance ordering.
        items = [
            _make_result(
                "big", "ten nine eight seven six five four three two one",
                score=0.95,
            ),
            _make_result(
                "too-big",
                "also too large to fit anywhere here today",
                score=0.90,
                title="Big",
            ),
            _make_result(
                "tiny", "a", score=0.50, title="Tiny"
            ),
        ]
        triage = ContextTriage(counter=_word_counter)
        result = triage.triage(items, 11)
        assert [t.item_id for t in result.included_items] == ["big"]
        excluded_ids = [e.item_id for e in result.excluded_items]
        assert "too-big" in excluded_ids
        assert "tiny" in excluded_ids
        assert "Tiny" in result.excluded_summary

    def test_relevance_percentage_in_excluded_summary(self) -> None:
        items = [
            _make_result("a", "one two three", score=0.9),
            _make_result(
                "b",
                "too many words here to ever fit anywhere",
                score=0.75,
                title="Topic B",
            ),
        ]
        triage = ContextTriage(counter=_word_counter)
        result = triage.triage(items, 3)
        assert "75%" in result.excluded_summary
        assert "Topic B" in result.excluded_summary


# ---------------------------------------------------------------------------
# Budget tolerance
# ---------------------------------------------------------------------------


class TestBudgetTolerance:
    def test_total_tokens_never_exceeds_budget(self) -> None:
        # Stress: many items of varied sizes with random-ish scores.
        items = []
        for i in range(20):
            text = " ".join(f"w{j}" for j in range(5 + (i % 7)))
            items.append(_make_result(f"id-{i}", text, score=1.0 - i * 0.04))
        triage = ContextTriage(counter=_word_counter)
        for budget in (0, 5, 30, 100, 500):
            result = triage.triage(items, budget)
            assert result.total_tokens_used <= budget
            assert result.budget_remaining == max(
                0, budget - result.total_tokens_used
            )

    def test_zero_budget_excludes_everything(self) -> None:
        items = [
            _make_result("a", "one two three", score=0.9),
            _make_result("b", "four", score=0.8),
        ]
        triage = ContextTriage(counter=_word_counter)
        result = triage.triage(items, 0)
        assert result.included_items == []
        assert result.summarized_items == []
        assert result.total_tokens_used == 0
        assert len(result.excluded_items) == 2

    def test_real_tiktoken_budget_within_five_percent(self) -> None:
        # Use the real counter and verify the 5%-tolerance phase-gate claim.
        items = [
            _make_result(
                f"id-{i}",
                (
                    "Security consideration: we store password hashes using "
                    "Argon2id with a 64 MiB memory cost. Migrations never "
                    "drop columns."
                )
                * 3,
                score=0.9 - i * 0.1,
            )
            for i in range(6)
        ]
        triage = ContextTriage()
        budget = 200
        result = triage.triage(items, budget)
        # Recount with the real counter as a cross-check.
        recount = sum(
            count_tokens(t.text)
            for t in (
                *result.included_items,
                *result.summarized_items,
            )
        )
        assert recount <= budget
        # Within 5% under — no huge slack left unused for items that would fit
        # when the budget is plentiful.
        assert recount >= int(budget * 0.75) or not result.excluded_items


# ---------------------------------------------------------------------------
# format_context_block
# ---------------------------------------------------------------------------


class TestFormatContextBlock:
    def test_block_contains_header_and_items(self) -> None:
        items = [
            _make_result(
                "d-1",
                "Use Argon2id for password hashing.",
                score=0.92,
                title="Argon2id adoption",
                verification="verified",
            ),
            _make_result(
                "s-1",
                "As a user I want to reset my password.",
                score=0.71,
                item_type="story",
                title="Password reset",
            ),
        ]
        triage = ContextTriage(counter=_word_counter)
        result = triage.triage(items, 100)
        block = format_context_block(result, context_for="auth.py")
        assert "# Context for: auth.py" in block
        assert "[DECISION]" in block
        assert "[STORY]" in block
        assert "92% relevance" in block
        assert "71% relevance" in block
        assert "verified" in block
        assert "Argon2id adoption" in block
        assert "Password reset" in block

    def test_block_includes_excluded_summary(self) -> None:
        items = [
            _make_result("a", "one two three", score=0.9),
            _make_result(
                "b",
                "too big for the budget in question",
                score=0.7,
                title="Leftover",
            ),
        ]
        triage = ContextTriage(counter=_word_counter)
        result = triage.triage(items, 3)
        block = format_context_block(result, context_for="file.py")
        assert "Excluded" in block
        assert "Leftover" in block

    def test_block_with_no_items(self) -> None:
        triage = ContextTriage(counter=_word_counter)
        result = triage.triage([], 100)
        block = format_context_block(result, context_for="nothing.py")
        assert "# Context for: nothing.py" in block
        assert "included=0" in block
        assert "summarised=0" in block
        assert "excluded=0" in block

    def test_block_includes_summarised_marker(self) -> None:
        long_text = "First sentence here. " + " ".join(
            f"w{i}" for i in range(50)
        )
        items = [
            _make_result("a", long_text, score=0.9, title="Topic A")
        ]
        triage = ContextTriage(counter=_word_counter, min_summary_tokens=2)
        # Budget well above the summary target, below the full text.
        result = triage.triage(items, 40)
        assert len(result.summarized_items) == 1
        block = format_context_block(result, context_for="x.py")
        assert "summarised" in block

    def test_empty_context_for_rejected(self) -> None:
        result = TriageResult(
            included_items=[],
            summarized_items=[],
            excluded_summary="",
            excluded_items=[],
            total_tokens_used=0,
            budget_remaining=0,
        )
        with pytest.raises(ContextTriageError):
            format_context_block(result, context_for="")
