"""Integration test for the OAuth device authorization flow.

Drives OAuthManager.device_flow against a mock provider that issues a device
code, simulates authorization_pending polling, and finally returns an access
token.
"""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any
from unittest.mock import MagicMock
from urllib.parse import parse_qs, urlparse

import pytest

from backend.auth.oauth_manager import (
    OAuthError,
    OAuthManager,
    ProviderConfig,
)

# ---------------------------------------------------------------------------
# Mock device-flow provider
# ---------------------------------------------------------------------------


class _MockDeviceProvider:
    """Mock that issues a device code and authorizes after N polls."""

    def __init__(self, *, authorize_after_polls: int = 2) -> None:
        self.device_code_requests: list[dict[str, list[str]]] = []
        self.token_requests: list[dict[str, list[str]]] = []
        self.userinfo_requests: list[dict[str, str]] = []
        self._authorize_after = authorize_after_polls
        self._poll_count = 0
        self.device_code = "DEVICE-CODE-ABC"
        self.user_code = "WDJB-MJHT"
        self.access_token = "DEVICE-ACCESS-TOKEN"
        self.refresh_token = "DEVICE-REFRESH-TOKEN"

    def handle_device_code(self, params: dict[str, list[str]]) -> dict[str, Any]:
        self.device_code_requests.append(params)
        return {
            "device_code": self.device_code,
            "user_code": self.user_code,
            "verification_uri": "https://mock/device",
            "expires_in": 1800,
            "interval": 0,  # test overrides poll_interval
        }

    def handle_token(
        self, params: dict[str, list[str]]
    ) -> tuple[int, dict[str, Any]]:
        self.token_requests.append(params)
        self._poll_count += 1
        if self._poll_count < self._authorize_after:
            return 400, {"error": "authorization_pending"}
        return 200, {
            "access_token": self.access_token,
            "refresh_token": self.refresh_token,
            "expires_in": 3600,
        }


def _run_mock_server(provider: _MockDeviceProvider) -> HTTPServer:
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length).decode("utf-8") if length else ""
            params = parse_qs(body)

            if parsed.path == "/device":
                payload = provider.handle_device_code(params)
                self._send_json(200, payload)
            elif parsed.path == "/token":
                status, payload = provider.handle_token(params)
                self._send_json(status, payload)
            else:
                self.send_response(404)
                self.end_headers()

        def do_GET(self) -> None:  # noqa: N802
            if urlparse(self.path).path == "/userinfo":
                provider.userinfo_requests.append(dict(self.headers))
                self._send_json(
                    200,
                    {
                        "sub": "device-user-1",
                        "email": "device@example.com",
                        "name": "Device User",
                    },
                )
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(
            self,
            format: str,  # noqa: A002 — name comes from parent class signature
            *args: object,
        ) -> None:
            pass

        def _send_json(self, status: int, payload: dict[str, Any]) -> None:
            data = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    server = HTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_credential_manager() -> MagicMock:
    storage: dict[tuple[str, str], str] = {}

    def fake_get(provider: str, key: str) -> str | None:
        return storage.get((provider, key))

    def fake_set(provider: str, key: str, value: str) -> None:
        storage[(provider, key)] = value

    mgr = MagicMock()
    mgr.get.side_effect = fake_get
    mgr.set.side_effect = fake_set
    mgr._storage = storage
    return mgr


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestDeviceFlow:
    """Full device authorization flow with polling."""

    @pytest.mark.asyncio
    async def test_device_flow_end_to_end(
        self,
        mock_credential_manager: MagicMock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("DEV_CLIENT_ID", "dev-cid")
        monkeypatch.setenv("DEV_CLIENT_SECRET", "dev-csecret")

        mock = _MockDeviceProvider(authorize_after_polls=2)
        server = _run_mock_server(mock)
        try:
            port = server.server_address[1]
            base = f"http://127.0.0.1:{port}"

            provider = ProviderConfig(
                name="dev",
                token_url=f"{base}/token",
                userinfo_url=f"{base}/userinfo",
                device_code_url=f"{base}/device",
                scopes=["openid"],
                client_id_env="DEV_CLIENT_ID",
                client_secret_env="DEV_CLIENT_SECRET",
            )
            manager = OAuthManager({"dev": provider}, mock_credential_manager)

            displayed: dict[str, str] = {}

            def display(uri: str, code: str) -> None:
                displayed["uri"] = uri
                displayed["code"] = code

            user = await manager.device_flow(
                "dev",
                user_id="eve",
                display_fn=display,
                poll_interval=0.01,
                timeout=5,
            )
        finally:
            server.shutdown()
            server.server_close()

        # User info is correct
        assert user.email == "device@example.com"
        assert user.provider_user_id == "device-user-1"

        # Display callback was invoked with URI and code
        assert displayed["uri"] == "https://mock/device"
        assert displayed["code"] == mock.user_code

        # At least one device_code request, and two token requests
        # (first = authorization_pending, second = success)
        assert len(mock.device_code_requests) == 1
        assert mock.device_code_requests[0]["client_id"] == ["dev-cid"]
        assert len(mock.token_requests) == 2
        assert (
            mock.token_requests[0]["grant_type"]
            == ["urn:ietf:params:oauth:grant-type:device_code"]
        )
        assert mock.token_requests[0]["device_code"] == [mock.device_code]

        # Refresh token persisted
        assert (
            mock_credential_manager._storage[("dev", "refresh_token:eve")]
            == mock.refresh_token
        )

    @pytest.mark.asyncio
    async def test_device_flow_unsupported_provider(
        self,
        mock_credential_manager: MagicMock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("X_CLIENT_ID", "cid")
        monkeypatch.setenv("X_CLIENT_SECRET", "cs")

        provider = ProviderConfig(
            name="x",
            token_url="http://unused",
            userinfo_url="http://unused",
            device_code_url="",  # empty → not supported
            client_id_env="X_CLIENT_ID",
            client_secret_env="X_CLIENT_SECRET",
        )
        manager = OAuthManager({"x": provider}, mock_credential_manager)

        with pytest.raises(OAuthError, match="Device flow not supported"):
            await manager.device_flow("x")

    @pytest.mark.asyncio
    async def test_device_flow_timeout(
        self,
        mock_credential_manager: MagicMock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("T_CLIENT_ID", "cid")
        monkeypatch.setenv("T_CLIENT_SECRET", "cs")

        # authorize_after_polls is very high so we'll never succeed
        mock = _MockDeviceProvider(authorize_after_polls=10_000)
        server = _run_mock_server(mock)
        try:
            port = server.server_address[1]
            base = f"http://127.0.0.1:{port}"

            provider = ProviderConfig(
                name="t",
                token_url=f"{base}/token",
                userinfo_url=f"{base}/userinfo",
                device_code_url=f"{base}/device",
                client_id_env="T_CLIENT_ID",
                client_secret_env="T_CLIENT_SECRET",
            )
            manager = OAuthManager({"t": provider}, mock_credential_manager)

            with pytest.raises(OAuthError, match="timed out"):
                await manager.device_flow(
                    "t", poll_interval=0.01, timeout=0.1
                )
        finally:
            server.shutdown()
            server.server_close()
