"""Integration tests for the fully-wired FastAPI application.

Builds the full app via ``create_app`` with a temporary config and exercises
the public ``/health`` endpoint, unauthenticated rejection on protected
routes, and end-to-end authenticated usage through REST. Also verifies the
MCP server is mounted at ``/mcp``.
"""

from __future__ import annotations

import sys
import textwrap
from typing import TYPE_CHECKING

import pytest
from fastapi.testclient import TestClient

from backend.config import load_config
from backend.main import create_app

if TYPE_CHECKING:
    from pathlib import Path


def _write_config(tmp_path: Path) -> Path:
    """Write a minimal codeledger.toml for testing into tmp_path."""
    content = textwrap.dedent("""\
        [server]
        mode = "solo"
        host = "127.0.0.1"
        port = 8100
        log_level = "info"

        [database]
        backend = "sqlite"
        sqlite_path = "data/codeledger.db"

        [vault]
        backend = "file"
        vault_path = "vault.enc"

        [auth]
        jwt_expiry_hours = 24
        argon2_memory_cost_kb = 512
        argon2_time_cost = 1
        argon2_parallelism = 1
    """)
    config_file = tmp_path / "codeledger.toml"
    config_file.write_text(content, encoding="utf-8")
    if sys.platform != "win32":
        config_file.chmod(0o600)
    return config_file


@pytest.fixture
def app_with_config(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> TestClient:
    """Spin up the app with a sandboxed config and a file-backed vault."""
    monkeypatch.setenv("CODELEDGER_VAULT_PASSPHRASE", "test-passphrase")
    config_file = _write_config(tmp_path)
    config = load_config(config_file, project_root=tmp_path)
    app = create_app(config)
    return TestClient(app)


# ---------------------------------------------------------------------------
# /health — the single unauthenticated endpoint
# ---------------------------------------------------------------------------


class TestHealthEndpoint:
    """GET /health returns 200 without any credentials."""

    def test_health_no_auth(self, app_with_config: TestClient) -> None:
        response = app_with_config.get("/health")
        assert response.status_code == 200
        assert response.json() == {"status": "ok"}


# ---------------------------------------------------------------------------
# SEC-05: every non-public route rejects unauthenticated requests
# ---------------------------------------------------------------------------


class TestAuthEnforcementOnFullApp:
    """Every non-public route returns 401 without credentials."""

    @pytest.mark.parametrize(
        "path",
        [
            "/api/decisions",
            "/api/stories",
            "/api/sessions",
            "/api/context",
            "/api/standup",
        ],
    )
    def test_unauth_returns_401(
        self, app_with_config: TestClient, path: str
    ) -> None:
        response = app_with_config.get(path)
        assert response.status_code == 401

    def test_mcp_path_requires_auth(
        self, app_with_config: TestClient
    ) -> None:
        response = app_with_config.get("/mcp/")
        assert response.status_code == 401


# ---------------------------------------------------------------------------
# MCP initialize — regression for the FastMCP lifespan nesting fix
#
# FastAPI does not propagate lifespan events to mounted sub-apps, so
# FastMCP's streamable-HTTP session manager must be entered from the parent
# app's lifespan. Before the fix, POST /mcp/ initialize returned 500.
# ---------------------------------------------------------------------------


class TestMcpInitialize:
    """POST /mcp/ initialize returns 200 with an mcp-session-id header."""

    def test_initialize_returns_session(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("CODELEDGER_VAULT_PASSPHRASE", "test-passphrase")
        config_file = _write_config(tmp_path)
        config = load_config(config_file, project_root=tmp_path)
        app = create_app(config)

        with TestClient(app) as client:
            auth = app.state.auth
            import anyio

            async def setup_user() -> str:
                user = await auth.register_email_user(
                    "mcp@test.com", "MCP User", "password-abc"
                )
                return auth.issue_jwt(user)

            jwt_token = anyio.run(setup_user)

            response = client.post(
                "/mcp/",
                json={
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "initialize",
                    "params": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {},
                        "clientInfo": {"name": "regression-test", "version": "0"},
                    },
                },
                headers={
                    "Authorization": f"Bearer {jwt_token}",
                    "Accept": "application/json, text/event-stream",
                    "Content-Type": "application/json",
                },
            )

            assert response.status_code == 200, response.text
            assert response.headers.get("mcp-session-id")


# ---------------------------------------------------------------------------
# Authenticated round-trip: register user → issue JWT → hit API
# ---------------------------------------------------------------------------


class TestAuthenticatedRoundTrip:
    """A valid JWT is accepted by the full app and routes to the handler."""

    def test_register_login_and_call_api(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("CODELEDGER_VAULT_PASSPHRASE", "test-passphrase")
        config_file = _write_config(tmp_path)
        config = load_config(config_file, project_root=tmp_path)
        app = create_app(config)

        # Using TestClient triggers lifespan (DB connect + migrations)
        with TestClient(app) as client:
            auth = app.state.auth
            import anyio

            async def setup_user() -> str:
                user = await auth.register_email_user(
                    "api@test.com", "API User", "password-abc"
                )
                return auth.issue_jwt(user)

            jwt_token = anyio.from_thread.run(setup_user) if False else anyio.run(setup_user)  # noqa: RUF100

            response = client.post(
                "/api/decisions",
                json={"title": "First decision", "description": "via API"},
                headers={"Authorization": f"Bearer {jwt_token}"},
            )
            assert response.status_code == 200
            created = response.json()
            assert created["title"] == "First decision"

            list_resp = client.get(
                "/api/decisions",
                headers={"Authorization": f"Bearer {jwt_token}"},
            )
            assert list_resp.status_code == 200
            assert len(list_resp.json()) == 1


# ---------------------------------------------------------------------------
# App wiring sanity checks
# ---------------------------------------------------------------------------


class TestAppWiring:
    """app.state exposes the subsystems for introspection."""

    def test_app_state_has_subsystems(
        self, app_with_config: TestClient
    ) -> None:
        app = app_with_config.app
        # TestClient entered the lifespan context already
        with app_with_config:
            assert app.state.db is not None
            assert app.state.auth is not None
            assert app.state.handlers is not None
            assert app.state.mcp.name == "codeledger"

    def test_openapi_includes_api_routes(
        self, app_with_config: TestClient
    ) -> None:
        response = app_with_config.get("/openapi.json")
        assert response.status_code in (200, 401)
        # OpenAPI is served by FastAPI itself; our auth middleware only
        # triggers on paths not in _PUBLIC_PATHS. The key assertion is the
        # app accepts requests and returns a routed response.


# ---------------------------------------------------------------------------
# Webhook endpoints — post-commit and file-change
# ---------------------------------------------------------------------------


_WEBHOOK_SECRET = "webhook-test-secret"


_DIFF_ADD_FN = (
    "diff --git a/hooks_x.py b/hooks_x.py\n"
    "--- a/hooks_x.py\n"
    "+++ b/hooks_x.py\n"
    "@@ -0,0 +1,2 @@\n"
    "+def added_fn(n):\n"
    "+    return n\n"
)


@pytest.fixture
def app_with_webhook_secret(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> TestClient:
    """App configured with a webhook secret provisioned in the vault."""
    monkeypatch.setenv("CODELEDGER_VAULT_PASSPHRASE", "test-passphrase")
    config_file = _write_config(tmp_path)
    config = load_config(config_file, project_root=tmp_path)
    app = create_app(config)
    app.state.credentials.set("webhooks", "default", _WEBHOOK_SECRET)
    return TestClient(app)


class TestPostCommitHook:
    """``/api/hooks/post-commit`` requires a matching webhook secret."""

    def test_missing_secret_returns_401(
        self, app_with_webhook_secret: TestClient
    ) -> None:
        with app_with_webhook_secret as client:
            response = client.post(
                "/api/hooks/post-commit",
                json={
                    "commit_hash": "deadbeef",
                    "diff_text": _DIFF_ADD_FN,
                    "project_id": "proj-1",
                },
            )
            assert response.status_code == 401

    def test_wrong_secret_returns_401(
        self, app_with_webhook_secret: TestClient
    ) -> None:
        with app_with_webhook_secret as client:
            response = client.post(
                "/api/hooks/post-commit",
                headers={"X-Webhook-Secret": "wrong"},
                json={
                    "commit_hash": "deadbeef",
                    "diff_text": _DIFF_ADD_FN,
                    "project_id": "proj-1",
                },
            )
            assert response.status_code == 401

    def test_correct_secret_processes_commit(
        self, app_with_webhook_secret: TestClient
    ) -> None:
        with app_with_webhook_secret as client:
            response = client.post(
                "/api/hooks/post-commit",
                headers={"X-Webhook-Secret": _WEBHOOK_SECRET},
                json={
                    "commit_hash": "deadbeef",
                    "diff_text": _DIFF_ADD_FN,
                    "project_id": "proj-1",
                },
            )
            assert response.status_code == 200
            body = response.json()
            assert body["received"] is True
            assert body["unlinked_changes"] == ["added_fn"]

    def test_missing_commit_hash_returns_400(
        self, app_with_webhook_secret: TestClient
    ) -> None:
        with app_with_webhook_secret as client:
            response = client.post(
                "/api/hooks/post-commit",
                headers={"X-Webhook-Secret": _WEBHOOK_SECRET},
                json={"diff_text": _DIFF_ADD_FN, "project_id": "proj-1"},
            )
            assert response.status_code == 400


class TestFileChangeHook:
    """``/api/hooks/file-change`` round-trips via the SnapshotStore."""

    def test_missing_secret_returns_401(
        self, app_with_webhook_secret: TestClient
    ) -> None:
        with app_with_webhook_secret as client:
            response = client.post(
                "/api/hooks/file-change",
                json={
                    "file_path": "x.py",
                    "project_id": "proj-1",
                    "after_snapshot_id": "abc",
                },
            )
            assert response.status_code == 401

    def test_missing_after_snapshot_id_returns_400(
        self, app_with_webhook_secret: TestClient
    ) -> None:
        with app_with_webhook_secret as client:
            response = client.post(
                "/api/hooks/file-change",
                headers={"X-Webhook-Secret": _WEBHOOK_SECRET},
                json={"file_path": "x.py", "project_id": "proj-1"},
            )
            assert response.status_code == 400

    def test_end_to_end_via_snapshots(
        self,
        tmp_path: Path,
        app_with_webhook_secret: TestClient,
    ) -> None:
        """Seed two snapshots, then POST the file-change hook and verify audit."""
        import anyio

        from backend.utils.snapshot_store import SnapshotStore

        with app_with_webhook_secret as client:
            app = client.app
            db = app.state.db

            # Write a file, take a baseline snapshot, then change content.
            source = tmp_path / "watched.py"
            source.write_text("def foo():\n    return 1\n", encoding="utf-8")

            async def seed() -> tuple[str, str]:
                store = SnapshotStore(db)
                before = await store.take_snapshot(str(source), "proj-1")
                source.write_text(
                    "def foo():\n    return 1\n\ndef added_fn(n):\n    return n\n",
                    encoding="utf-8",
                )
                after = await store.take_snapshot(str(source), "proj-1")
                return str(before.id), str(after.id)

            before_id, after_id = anyio.run(seed)

            response = client.post(
                "/api/hooks/file-change",
                headers={"X-Webhook-Secret": _WEBHOOK_SECRET},
                json={
                    "file_path": str(source),
                    "project_id": "proj-1",
                    "before_snapshot_id": before_id,
                    "after_snapshot_id": after_id,
                },
            )
            assert response.status_code == 200
            body = response.json()
            assert body["received"] is True
            assert "added_fn" in body["unlinked_changes"]

            # Audit records present.
            async def counts() -> tuple[int, int]:
                ast_rows = await db.query("ast_changes")
                unlinked_rows = await db.query("unlinked_file_changes")
                return len(ast_rows), len(unlinked_rows)

            ast_count, unlinked_count = anyio.run(counts)
            assert ast_count >= 1
            assert unlinked_count == 1


# ---------------------------------------------------------------------------
# Active context hooks — REST layer (Phase 3)
# ---------------------------------------------------------------------------


class TestContextHookEndpointsAuth:
    """Every context-injection hook endpoint requires bearer auth (SEC-05)."""

    @pytest.mark.parametrize(
        "path,body",
        [
            ("/api/hooks/session-context", {"cwd": "/tmp", "prompt": "x"}),
            ("/api/hooks/file-context", {"cwd": "/tmp", "file_path": "x.py"}),
            (
                "/api/hooks/conflict-check",
                {"cwd": "/tmp", "file_path": "x.py"},
            ),
            (
                "/api/hooks/import-check",
                {"cwd": "/tmp", "file_path": "x.py", "content": "import os"},
            ),
            (
                "/api/hooks/ensure-session",
                {"cwd": "/tmp", "agent": "claude"},
            ),
            ("/api/hooks/close-session", {"cwd": "/tmp"}),
        ],
    )
    def test_unauth_returns_401(
        self, app_with_config: TestClient, path: str, body: dict
    ) -> None:
        response = app_with_config.post(path, json=body)
        assert response.status_code == 401


class TestContextHookEndpointsAuthed:
    """Authenticated round-trip over the REST hook endpoints."""

    def test_full_hook_cycle(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("CODELEDGER_VAULT_PASSPHRASE", "test-passphrase")
        config_file = _write_config(tmp_path)
        config = load_config(config_file, project_root=tmp_path)
        app = create_app(config)

        # The project root for the hooks lives under the temp directory so
        # ``/api/hooks/session-context`` can find a ``codeledger.toml``.
        project_root = tmp_path / "demo-project"
        project_root.mkdir()
        (project_root / "codeledger.toml").write_text(
            "# minimal\n", encoding="utf-8"
        )

        with TestClient(app) as client:
            import anyio

            async def setup_user() -> str:
                user = await app.state.auth.register_email_user(
                    "hook@test.com", "Hook User", "password-abc"
                )
                return app.state.auth.issue_jwt(user)

            jwt_token = anyio.run(setup_user)
            auth = {"Authorization": f"Bearer {jwt_token}"}

            # ensure-session creates a session.
            r = client.post(
                "/api/hooks/ensure-session",
                json={"cwd": str(project_root), "agent": "claude"},
                headers=auth,
            )
            assert r.status_code == 200
            sid = r.json()["session_id"]

            # Second call is idempotent.
            r2 = client.post(
                "/api/hooks/ensure-session",
                json={"cwd": str(project_root), "agent": "claude"},
                headers=auth,
            )
            assert r2.json()["session_id"] == sid

            # conflict-check returns False when alone.
            r3 = client.post(
                "/api/hooks/conflict-check",
                json={
                    "cwd": str(project_root),
                    "file_path": "a.py",
                    "session_id": sid,
                },
                headers=auth,
            )
            assert r3.status_code == 200
            assert r3.json()["conflict"] is False

            # import-check with no constraints returns empty.
            r4 = client.post(
                "/api/hooks/import-check",
                json={
                    "cwd": str(project_root),
                    "file_path": "a.py",
                    "content": "import os\n",
                },
                headers=auth,
            )
            assert r4.status_code == 200
            assert r4.json()["violations"] == []

            # close-session never raises.
            r5 = client.post(
                "/api/hooks/close-session",
                json={"cwd": str(project_root)},
                headers=auth,
            )
            assert r5.status_code == 200
            assert r5.json()["status"] == "closed"
