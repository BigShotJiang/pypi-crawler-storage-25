"""Integration test for the browser-based OAuth flow.

Runs a mock provider (fake authorize + token + userinfo endpoints) and drives
the full OAuthManager.browser_flow() flow end-to-end: redirect with state/PKCE,
code exchange, userinfo fetch, refresh token persistence.
"""

from __future__ import annotations

import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any
from unittest.mock import MagicMock, patch
from urllib.parse import parse_qs, urlparse

import pytest

from backend.auth.oauth_manager import (
    OAuthManager,
    ProviderConfig,
    load_providers,
)

# ---------------------------------------------------------------------------
# Mock OAuth provider server
# ---------------------------------------------------------------------------


class _MockProviderState:
    """Shared state for the mock provider: records requests, issues tokens."""

    def __init__(self) -> None:
        self.authorize_requests: list[dict[str, list[str]]] = []
        self.token_requests: list[dict[str, list[str]]] = []
        self.userinfo_requests: list[dict[str, str]] = []
        self.issued_code: str = "MOCK-AUTH-CODE"
        self.access_token: str = "MOCK-ACCESS-TOKEN"
        self.refresh_token: str = "MOCK-REFRESH-TOKEN"


def _make_mock_provider_server(state: _MockProviderState) -> HTTPServer:
    """Start a mock HTTP server emulating /authorize, /token, /userinfo."""

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            params = parse_qs(parsed.query)

            if parsed.path == "/authorize":
                state.authorize_requests.append(params)
                self.send_response(302)
                self.end_headers()
            elif parsed.path == "/userinfo":
                state.userinfo_requests.append(dict(self.headers))
                self._send_json(
                    200,
                    {
                        "sub": "user-42",
                        "email": "test@example.com",
                        "name": "Test User",
                        "picture": "https://mock/avatar.png",
                    },
                )
            else:
                self.send_response(404)
                self.end_headers()

        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length).decode("utf-8") if length else ""
            params = parse_qs(body)

            if parsed.path == "/token":
                state.token_requests.append(params)
                self._send_json(
                    200,
                    {
                        "access_token": state.access_token,
                        "refresh_token": state.refresh_token,
                        "expires_in": 3600,
                        "token_type": "Bearer",
                    },
                )
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(
            self,
            format: str,  # noqa: A002 — name comes from parent class signature
            *args: object,
        ) -> None:
            pass  # silence test logs

        def _send_json(self, status: int, payload: dict[str, Any]) -> None:
            import json

            data = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    server = HTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_state() -> _MockProviderState:
    return _MockProviderState()


@pytest.fixture
def mock_server(
    mock_state: _MockProviderState,
) -> Any:  # yields (server, base_url)
    server = _make_mock_provider_server(mock_state)
    base = f"http://127.0.0.1:{server.server_address[1]}"
    try:
        yield server, base
    finally:
        server.shutdown()
        server.server_close()


@pytest.fixture
def mock_credential_manager() -> MagicMock:
    storage: dict[tuple[str, str], str] = {}

    def fake_get(provider: str, key: str) -> str | None:
        return storage.get((provider, key))

    def fake_set(provider: str, key: str, value: str) -> None:
        storage[(provider, key)] = value

    mgr = MagicMock()
    mgr.get.side_effect = fake_get
    mgr.set.side_effect = fake_set
    mgr._storage = storage  # for test assertions
    return mgr


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestProvidersToml:
    """Verify the shipped providers.toml is loadable."""

    def test_load_shipped_providers(self) -> None:
        providers = load_providers("providers.toml")
        assert "google" in providers
        assert "github" in providers
        assert providers["google"].pkce is True
        assert providers["google"].authorize_url.startswith("https://")


class TestBrowserFlowEndToEnd:
    """OAuthManager.browser_flow drives a mock provider to completion."""

    @pytest.mark.asyncio
    async def test_full_browser_flow(
        self,
        mock_server: Any,
        mock_state: _MockProviderState,
        mock_credential_manager: MagicMock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        _server, base = mock_server
        monkeypatch.setenv("MOCK_CLIENT_ID", "client-id-123")
        monkeypatch.setenv("MOCK_CLIENT_SECRET", "client-secret-456")

        provider = ProviderConfig(
            name="mock",
            authorize_url=f"{base}/authorize",
            token_url=f"{base}/token",
            userinfo_url=f"{base}/userinfo",
            scopes=["openid", "email"],
            pkce=True,
            client_id_env="MOCK_CLIENT_ID",
            client_secret_env="MOCK_CLIENT_SECRET",
        )
        manager = OAuthManager({"mock": provider}, mock_credential_manager)

        # Arrange: simulate the browser callback by driving _CallbackServer
        captured_state: dict[str, str] = {}

        with (
            patch("backend.auth.oauth_manager.webbrowser.open", return_value=True),
            patch("backend.auth.oauth_manager._CallbackServer") as cb_cls,
        ):
            cb = cb_cls.return_value
            cb.start.return_value = 0  # port
            cb.code = mock_state.issued_code
            cb.error = None

            original_build = (
                __import__("backend.auth.oauth_manager", fromlist=["build_auth_url"])
                .build_auth_url
            )

            def capturing_build(
                provider: ProviderConfig,
                client_id: str,
                redirect_uri: str,
                state: str,
                code_challenge: str | None = None,
            ) -> str:
                captured_state["state"] = state
                return original_build(
                    provider, client_id, redirect_uri, state, code_challenge
                )

            def reflect_state() -> None:
                cb.state = captured_state["state"]

            cb.wait_for_callback = MagicMock(side_effect=reflect_state)

            with patch(
                "backend.auth.oauth_manager.build_auth_url",
                side_effect=capturing_build,
            ):
                user = await manager.browser_flow("mock", user_id="alice")

        # Assert: user info is correct
        assert user.provider == "mock"
        assert user.email == "test@example.com"
        assert user.name == "Test User"
        assert user.provider_user_id == "user-42"
        assert user.avatar_url == "https://mock/avatar.png"

        # Assert: token endpoint received correct grant + PKCE verifier
        assert len(mock_state.token_requests) == 1
        token_req = mock_state.token_requests[0]
        assert token_req["grant_type"] == ["authorization_code"]
        assert token_req["code"] == [mock_state.issued_code]
        assert token_req["client_id"] == ["client-id-123"]
        assert token_req["client_secret"] == ["client-secret-456"]
        assert "code_verifier" in token_req

        # Assert: userinfo endpoint received Bearer token
        assert len(mock_state.userinfo_requests) == 1
        assert (
            mock_state.userinfo_requests[0].get("Authorization")
            == f"Bearer {mock_state.access_token}"
        )

        # Assert: refresh token was persisted to the credential vault
        assert (
            mock_credential_manager._storage[("mock", "refresh_token:alice")]
            == mock_state.refresh_token
        )


class TestTokenRefresh:
    """get_access_token refreshes an expired token via the provider."""

    @pytest.mark.asyncio
    async def test_refresh_when_expired(
        self,
        mock_server: Any,
        mock_state: _MockProviderState,
        mock_credential_manager: MagicMock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        _server, base = mock_server
        monkeypatch.setenv("MOCK_CLIENT_ID", "cid")
        monkeypatch.setenv("MOCK_CLIENT_SECRET", "csecret")

        provider = ProviderConfig(
            name="mock",
            authorize_url=f"{base}/authorize",
            token_url=f"{base}/token",
            userinfo_url=f"{base}/userinfo",
            scopes=["openid"],
            pkce=True,
            client_id_env="MOCK_CLIENT_ID",
            client_secret_env="MOCK_CLIENT_SECRET",
        )
        manager = OAuthManager({"mock": provider}, mock_credential_manager)

        # Seed a refresh token in the vault (no access token in memory yet)
        mock_credential_manager._storage[("mock", "refresh_token:bob")] = "OLD-RT"
        mock_state.access_token = "NEW-ACCESS-TOKEN"

        access = await manager.get_access_token("mock", user_id="bob")
        assert access == "NEW-ACCESS-TOKEN"

        # The token endpoint should have received a refresh_token grant
        assert len(mock_state.token_requests) == 1
        assert mock_state.token_requests[0]["grant_type"] == ["refresh_token"]
        assert mock_state.token_requests[0]["refresh_token"] == ["OLD-RT"]

    @pytest.mark.asyncio
    async def test_no_refresh_token_returns_none(
        self,
        mock_credential_manager: MagicMock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("MOCK_CLIENT_ID", "cid")
        monkeypatch.setenv("MOCK_CLIENT_SECRET", "csecret")

        provider = ProviderConfig(
            name="mock",
            token_url="http://unused",
            userinfo_url="http://unused",
            client_id_env="MOCK_CLIENT_ID",
            client_secret_env="MOCK_CLIENT_SECRET",
        )
        manager = OAuthManager({"mock": provider}, mock_credential_manager)

        # No seeded refresh token → should return None
        result = await manager.get_access_token("mock", user_id="charlie")
        assert result is None


class TestManualApiKey:
    """Manual API key path stores directly into the credential vault."""

    def test_store_api_key(self, mock_credential_manager: MagicMock) -> None:
        provider = ProviderConfig(
            name="mock",
            client_id_env="X",
            client_secret_env="Y",
        )
        manager = OAuthManager({"mock": provider}, mock_credential_manager)
        manager.store_api_key("mock", "sk-live-abcdef", user_id="dave")
        assert (
            mock_credential_manager._storage[("mock", "api_key:dave")]
            == "sk-live-abcdef"
        )
