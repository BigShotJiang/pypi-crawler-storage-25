"""Integration test: embed a decision, store it, and retrieve via query.

Requires a running Ollama instance with the configured embedding model.
The test is skipped when Ollama is unreachable so CI environments that
lack Ollama do not fail. Run with:

    ollama serve
    ollama pull nomic-embed-text

and then ``pytest tests/integration/test_embedding_pipeline.py``.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

import httpx
import pytest

from backend.config import EmbeddingConfig
from backend.db.vector_store import SqliteVssStore
from backend.intelligence.embedder import Embedder
from backend.intelligence.semantic_search import SemanticSearch

if TYPE_CHECKING:
    from pathlib import Path

_OLLAMA_URL = os.environ.get(
    "OLLAMA_URL", "http://localhost:11434"
)
_EMBEDDING_MODEL = os.environ.get(
    "OLLAMA_EMBEDDING_MODEL", "nomic-embed-text"
)


def _ollama_reachable() -> bool:
    try:
        with httpx.Client(timeout=2.0) as client:
            response = client.get(f"{_OLLAMA_URL}/api/tags")
            response.raise_for_status()
            data = response.json()
    except (httpx.HTTPError, httpx.HTTPStatusError, OSError):
        return False
    models = {
        m.get("name", "").split(":")[0] for m in data.get("models", [])
    }
    return _EMBEDDING_MODEL in models


pytestmark = pytest.mark.skipif(
    not _ollama_reachable(),
    reason=(
        f"Requires Ollama at {_OLLAMA_URL} with {_EMBEDDING_MODEL}. "
        "Run `ollama serve` and `ollama pull nomic-embed-text`."
    ),
)


async def test_end_to_end_semantic_retrieval(tmp_path: Path) -> None:
    config = EmbeddingConfig(
        ollama_url=_OLLAMA_URL,
        model=_EMBEDDING_MODEL,
        batch_size=4,
    )
    embedder = Embedder(config)
    store = SqliteVssStore(tmp_path / "v.db")
    await store.connect()
    try:
        search = SemanticSearch(embedder=embedder, vector_store=store)

        # Seed some decisions across unrelated topics.
        await search.index_item(
            "d-auth",
            "Use Argon2id for password hashing in auth_service.py",
            item_type="decision",
            project_id="proj-1",
        )
        await search.index_item(
            "d-db",
            "Store user records in PostgreSQL with asyncpg connection pool",
            item_type="decision",
            project_id="proj-1",
        )
        await search.index_item(
            "d-ui",
            "Dashboard uses React 18 with Zustand state management",
            item_type="decision",
            project_id="proj-1",
        )
        await search.index_item(
            "d-other",
            "Stories are tracked in a kanban board with four lanes",
            item_type="story",
            project_id="proj-1",
        )

        # A query semantically close to the auth decision should rank it first.
        results = await search.search(
            "How should we store passwords securely?",
            project_id="proj-1",
            top_k=3,
        )
        assert results
        assert results[0].item_id == "d-auth"
    finally:
        await store.close()
