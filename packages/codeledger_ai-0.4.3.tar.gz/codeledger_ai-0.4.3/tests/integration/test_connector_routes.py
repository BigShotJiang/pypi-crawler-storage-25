"""Integration tests for ``backend.connectors.routes``.

Stand up a minimal FastAPI app with just the connector router attached.
A real ``create_app()`` is too heavy for this test surface and would pull
in unrelated startup failures; the router itself only depends on
``request.app.state.connector_registry`` and
``request.app.state.connector_oauth_manager``, so we inject stubs.
"""

from __future__ import annotations

from typing import ClassVar
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from backend.connectors.base import (
    AbstractConnector,
    AuthType,
    ConnectorCategory,
    ConnectorHealth,
    ConnectorResult,
    ConnectorStatus,
)
from backend.connectors.oauth_token_manager import (
    ConnectorOAuthConfig,
    OAuthTokenManager,
)
from backend.connectors.registry import ConnectorRegistry
from backend.connectors.routes import (
    ConnectorsRouterConfig,
    create_connectors_router,
)

# ------------------------------- fixtures ------------------------------- #


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


_OAUTH_CFG = ConnectorOAuthConfig(
    slug="fakeoauth",
    authorize_url="https://provider.example/authorize",
    token_url="https://provider.example/token",
    scopes=["read"],
    pkce=True,
    client_id_env="FAKE_CLIENT_ID",
    client_secret_env="FAKE_CLIENT_SECRET",
    extra_authorize_params={"prompt": "consent"},
)


class _StubOAuthConnector(AbstractConnector):
    slug = "fakeoauth"
    display_name = "Fake OAuth"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.COMMUNICATION
    oauth_scopes: ClassVar[list[str]] = ["read"]
    description = "test"
    oauth_config: ClassVar[ConnectorOAuthConfig | None] = _OAUTH_CFG

    async def health(self) -> ConnectorHealth:
        return ConnectorHealth(
            slug=self.slug,
            status=(
                ConnectorStatus.CONNECTED
                if self.is_configured()
                else ConnectorStatus.NOT_CONFIGURED
            ),
            message="ok" if self.is_configured() else "unconfigured",
            configured=self.is_configured(),
        )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        return []

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        return None


class _StubApiKeyConnector(_StubOAuthConnector):
    slug = "fakeapikey"
    display_name = "Fake API Key"
    auth_type = AuthType.API_KEY
    oauth_config: ClassVar[ConnectorOAuthConfig | None] = None


class _StubConnStrConnector(_StubOAuthConnector):
    slug = "fakedb"
    display_name = "Fake DB"
    auth_type = AuthType.CONNECTION_STRING
    category = ConnectorCategory.DATABASE
    oauth_config: ClassVar[ConnectorOAuthConfig | None] = None


def _make_app(
    registry: ConnectorRegistry | None,
    token_manager: OAuthTokenManager | None,
) -> FastAPI:
    app = FastAPI()
    app.state.connector_registry = registry
    app.state.connector_oauth_manager = token_manager
    app.include_router(
        create_connectors_router(
            ConnectorsRouterConfig(
                server_host="localhost",
                server_port=8100,
                cookie_secure=False,
            )
        )
    )
    return app


@pytest.fixture
def cm() -> _FakeCM:
    return _FakeCM()


@pytest.fixture
def registry_and_cm(cm: _FakeCM) -> tuple[ConnectorRegistry, _FakeCM]:
    reg = ConnectorRegistry()
    reg.register(_StubOAuthConnector(cm))
    reg.register(_StubApiKeyConnector(cm))
    reg.register(_StubConnStrConnector(cm))
    return reg, cm


@pytest.fixture
def client(
    registry_and_cm: tuple[ConnectorRegistry, _FakeCM],
) -> TestClient:
    reg, cm = registry_and_cm
    tm = OAuthTokenManager(cm)
    return TestClient(_make_app(reg, tm))


# ------------------------------- /status -------------------------------- #


def test_status_returns_connector_metadata(client: TestClient) -> None:
    r = client.get("/api/connectors/status")
    assert r.status_code == 200
    data = r.json()
    slugs = sorted(c["slug"] for c in data["connectors"])
    assert slugs == ["fakeapikey", "fakedb", "fakeoauth"]


def test_status_503_when_registry_missing() -> None:
    app = _make_app(None, None)
    r = TestClient(app).get("/api/connectors/status")
    assert r.status_code == 503


# ------------------------------- /health -------------------------------- #


def test_health_unknown_slug_404(client: TestClient) -> None:
    r = client.get("/api/connectors/nope/health")
    assert r.status_code == 404


def test_health_returns_connector_health(client: TestClient) -> None:
    r = client.get("/api/connectors/fakeoauth/health")
    assert r.status_code == 200
    body = r.json()
    assert body["slug"] == "fakeoauth"
    assert body["status"] == "not_configured"
    assert body["configured"] is False


# ------------------------------- /setup --------------------------------- #


def test_setup_api_key_connector(
    client: TestClient, registry_and_cm: tuple[ConnectorRegistry, _FakeCM]
) -> None:
    _, cm = registry_and_cm
    r = client.post(
        "/api/connectors/fakeapikey/setup",
        json={"credentials": {"api_key": "secret-123"}},
    )
    assert r.status_code == 200
    assert cm.store[("connector_fakeapikey", "api_key")] == "secret-123"
    assert r.json()["connected"] is True


def test_setup_connection_string_connector(
    client: TestClient, registry_and_cm: tuple[ConnectorRegistry, _FakeCM]
) -> None:
    _, cm = registry_and_cm
    r = client.post(
        "/api/connectors/fakedb/setup",
        json={"credentials": {"connection_string": "postgres://u:p@h/d"}},
    )
    assert r.status_code == 200
    assert cm.store[("connector_fakedb", "connection_string")] == "postgres://u:p@h/d"


def test_setup_400_on_missing_credentials(client: TestClient) -> None:
    r = client.post(
        "/api/connectors/fakeapikey/setup", json={"credentials": {}}
    )
    assert r.status_code == 400
    assert "api_key" in r.json()["detail"]


def test_setup_400_on_oauth_connector(client: TestClient) -> None:
    r = client.post(
        "/api/connectors/fakeoauth/setup",
        json={"credentials": {"api_key": "x"}},
    )
    assert r.status_code == 400
    assert "oauth" in r.json()["detail"].lower()


def test_setup_404_unknown_slug(client: TestClient) -> None:
    r = client.post(
        "/api/connectors/missing/setup",
        json={"credentials": {"api_key": "x"}},
    )
    assert r.status_code == 404


def test_setup_400_non_json_body(client: TestClient) -> None:
    r = client.post(
        "/api/connectors/fakeapikey/setup",
        content="not json",
        headers={"content-type": "application/json"},
    )
    assert r.status_code == 400


# ------------------------------- /disconnect ---------------------------- #


def test_disconnect_clears_credentials(
    client: TestClient, registry_and_cm: tuple[ConnectorRegistry, _FakeCM]
) -> None:
    _, cm = registry_and_cm
    cm.set("connector_fakeoauth", "access_token", "tok")
    cm.set("connector_fakeoauth", "refresh_token", "rt")
    cm.set("connector_fakeoauth", "token_expiry", "9999")

    r = client.post("/api/connectors/fakeoauth/disconnect")
    assert r.status_code == 200
    assert r.json() == {"disconnected": True}
    assert ("connector_fakeoauth", "access_token") not in cm.store
    assert ("connector_fakeoauth", "refresh_token") not in cm.store
    assert ("connector_fakeoauth", "token_expiry") not in cm.store


def test_disconnect_unknown_slug_404(client: TestClient) -> None:
    r = client.post("/api/connectors/missing/disconnect")
    assert r.status_code == 404


# ------------------------------- /oauth/connect ------------------------- #


def test_oauth_connect_404_unknown(client: TestClient) -> None:
    r = client.get(
        "/api/connectors/oauth/missing/connect", follow_redirects=False
    )
    assert r.status_code == 404


def test_oauth_connect_400_non_oauth(client: TestClient) -> None:
    r = client.get(
        "/api/connectors/oauth/fakeapikey/connect", follow_redirects=False
    )
    assert r.status_code == 400


def test_oauth_connect_503_without_client_credentials(
    client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("FAKE_CLIENT_ID", raising=False)
    monkeypatch.delenv("FAKE_CLIENT_SECRET", raising=False)
    r = client.get(
        "/api/connectors/oauth/fakeoauth/connect", follow_redirects=False
    )
    assert r.status_code == 503
    assert "not configured" in r.json()["detail"]


def test_oauth_connect_happy_path_sets_cookies(
    client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("FAKE_CLIENT_ID", "cid")
    monkeypatch.setenv("FAKE_CLIENT_SECRET", "csec")

    r = client.get(
        "/api/connectors/oauth/fakeoauth/connect", follow_redirects=False
    )
    assert r.status_code == 302
    location = r.headers["location"]
    # Authorize URL is built correctly
    assert location.startswith("https://provider.example/authorize")
    assert "state=" in location
    assert "code_challenge=" in location
    assert "prompt=consent" in location  # extra_authorize_params merged in

    # State + verifier cookies both set under the connector OAuth prefix
    cookie_headers = [
        h for h in r.headers.raw if h[0].decode().lower() == "set-cookie"
    ]
    cookie_blob = "\n".join(v.decode() for _, v in cookie_headers).lower()
    assert "codeledger_connector_state_fakeoauth=" in cookie_blob
    assert "codeledger_connector_verifier_fakeoauth=" in cookie_blob
    # HttpOnly set
    assert "httponly" in cookie_blob


# ------------------------------- /oauth/callback ------------------------ #


def test_callback_provider_error_redirects(client: TestClient) -> None:
    r = client.get(
        "/api/connectors/oauth/fakeoauth/callback?error=access_denied",
        follow_redirects=False,
    )
    assert r.status_code == 302
    assert "connector_error=oauth_denied" in r.headers["location"]


def test_callback_missing_code_redirects_invalid(client: TestClient) -> None:
    r = client.get(
        "/api/connectors/oauth/fakeoauth/callback?state=x",
        follow_redirects=False,
    )
    assert r.status_code == 302
    assert "oauth_invalid" in r.headers["location"]


def test_callback_state_mismatch_is_rejected_as_csrf(
    client: TestClient,
) -> None:
    client.cookies.set("codeledger_connector_state_fakeoauth", "real-state")
    r = client.get(
        "/api/connectors/oauth/fakeoauth/callback?code=c&state=wrong",
        follow_redirects=False,
    )
    assert r.status_code == 302
    assert "oauth_csrf" in r.headers["location"]


def test_callback_pkce_verifier_missing(client: TestClient) -> None:
    client.cookies.set("codeledger_connector_state_fakeoauth", "s")
    # verifier cookie NOT set — PKCE provider should refuse.
    r = client.get(
        "/api/connectors/oauth/fakeoauth/callback?code=c&state=s",
        follow_redirects=False,
    )
    assert r.status_code == 302
    assert "oauth_pkce_missing" in r.headers["location"]


def test_callback_happy_path_stores_tokens_and_redirects(
    client: TestClient,
    registry_and_cm: tuple[ConnectorRegistry, _FakeCM],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _, cm = registry_and_cm
    monkeypatch.setenv("FAKE_CLIENT_ID", "cid")
    monkeypatch.setenv("FAKE_CLIENT_SECRET", "csec")

    # Pre-seed state + verifier cookies as if /connect had run.
    client.cookies.set("codeledger_connector_state_fakeoauth", "s-ok")
    client.cookies.set("codeledger_connector_verifier_fakeoauth", "v-ok")

    # Mock the token exchange HTTP call.
    token_response = MagicMock()
    token_response.status_code = 200
    token_response.json.return_value = {
        "access_token": "AT",
        "refresh_token": "RT",
        "expires_in": 3600,
    }
    with patch.object(
        OAuthTokenManager,
        "_http_post",
        new=AsyncMock(return_value=token_response),
    ):
        r = client.get(
            "/api/connectors/oauth/fakeoauth/callback?code=c&state=s-ok",
            follow_redirects=False,
        )

    assert r.status_code == 302
    assert "connector_connected=fakeoauth" in r.headers["location"]
    assert cm.store[("connector_fakeoauth", "access_token")] == "AT"
    assert cm.store[("connector_fakeoauth", "refresh_token")] == "RT"


def test_callback_exchange_failure_redirects_error(
    client: TestClient,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("FAKE_CLIENT_ID", "cid")
    monkeypatch.setenv("FAKE_CLIENT_SECRET", "csec")
    client.cookies.set("codeledger_connector_state_fakeoauth", "s-ok")
    client.cookies.set("codeledger_connector_verifier_fakeoauth", "v-ok")

    token_response = MagicMock()
    token_response.status_code = 400
    token_response.json.return_value = {"error": "invalid_grant"}
    with patch.object(
        OAuthTokenManager,
        "_http_post",
        new=AsyncMock(return_value=token_response),
    ):
        r = client.get(
            "/api/connectors/oauth/fakeoauth/callback?code=c&state=s-ok",
            follow_redirects=False,
        )
    assert r.status_code == 302
    assert "oauth_exchange_failed" in r.headers["location"]
