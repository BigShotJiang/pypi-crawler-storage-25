"""Provenance query failure points F6.1 — F6.6.

Verifies ``provenance.reverse`` / ``provenance.forward`` behaviour on
missing entities, deleted decisions, and deep graphs.
"""

from __future__ import annotations

import uuid
from typing import Any

import pytest

from backend.intelligence.ast_tracker import ASTTracker
from backend.models import Decision
from backend.verification.provenance import (
    ProvenanceEngine,
    ProvenanceError,
)


class TestReverseTraceNotFound:
    async def test_unknown_entity_returns_empty(self, db: Any) -> None:
        """F6.1 — entity not in any ASTChange returns empty list."""
        engine = ProvenanceEngine(db=db)
        results = await engine.reverse_trace(
            file_path="any.py",
            entity_name="no_such_function",
            project_id="qa",
        )
        assert results == []

    async def test_unknown_file_returns_empty(self, db: Any) -> None:
        """F6.2 — file path not in any ASTChange returns empty list."""
        engine = ProvenanceEngine(db=db)
        results = await engine.reverse_trace(
            file_path="does/not/exist.py",
            entity_name="x",
            project_id="qa",
        )
        assert results == []

    async def test_empty_inputs_raise(self, db: Any) -> None:
        """F6 validation — empty file_path or entity_name raises."""
        engine = ProvenanceEngine(db=db)
        with pytest.raises(ProvenanceError):
            await engine.reverse_trace("", "x", "qa")
        with pytest.raises(ProvenanceError):
            await engine.reverse_trace("x.py", "", "qa")


class TestForwardTraceNotFound:
    async def test_unknown_decision_raises(self, db: Any) -> None:
        """F6 validation — forward_trace on a missing decision raises."""
        engine = ProvenanceEngine(db=db)
        with pytest.raises(ProvenanceError):
            await engine.forward_trace(uuid.uuid4())

    async def test_decision_without_edges_returns_empty_events(
        self, db: Any
    ) -> None:
        """F6 — decision with no ProvenanceEdge rows has empty change_events."""
        d = Decision(title="orphan")
        await db.insert("decisions", d.to_dict())
        engine = ProvenanceEngine(db=db)
        tree = await engine.forward_trace(d.id)
        assert tree.change_events == []


class TestProvenanceGraphIntegrity:
    async def test_deleted_decision_gracefully_absent_from_reverse(
        self, db: Any
    ) -> None:
        """F6.3 — when the decision is deleted, reverse_trace yields no row
        for it rather than crashing with a missing foreign key."""
        diff_text = (
            "diff --git a/prov.py b/prov.py\n"
            "--- a/prov.py\n"
            "+++ b/prov.py\n"
            "@@ -0,0 +1,2 @@\n"
            "+def prov_fn(x):\n"
            "+    return x\n"
        )
        tracker = ASTTracker(db=db)
        d = Decision(
            title="Touches prov.py for prov_fn",
            description="adds prov_fn in prov.py",
        )
        await db.insert("decisions", d.to_dict())
        await tracker.process_change_event(
            change_event_id="cmt-q",
            change_event_source="git_commit",
            diff_text=diff_text,
            project_id="qa",
        )
        # Now delete the decision directly.
        await db.delete("decisions", str(d.id))
        engine = ProvenanceEngine(db=db)
        results = await engine.reverse_trace(
            file_path="prov.py",
            entity_name="prov_fn",
            project_id="qa",
        )
        # The dangling edge silently drops its row — no crash.
        assert isinstance(results, list)


class TestImpactGraphDepth:
    async def test_impact_graph_returns_structured_dict(
        self, db: Any
    ) -> None:
        """F6.6 — impact graph has stable keys even for shallow graphs."""
        d = Decision(title="orphan2")
        await db.insert("decisions", d.to_dict())
        engine = ProvenanceEngine(db=db)
        graph = await engine.get_impact_graph(d.id)
        assert "decision" in graph
        assert "change_events" in graph
        assert "ast_changes" in graph
        assert "dependents" in graph
