"""Cross-platform compatibility tests (Linux/macOS/Windows branching)."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

from backend.utils.git_hooks import install_hooks


class TestHookScriptPurePython:
    def test_hook_has_python_shebang(
        self, tmp_path: Path
    ) -> None:
        """Installed hook starts with a Python shebang, never /bin/bash."""
        repo = tmp_path / "repo"
        repo.mkdir()
        subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
        installed = install_hooks(
            repo,
            server_url="http://127.0.0.1:59000",
            token_file=str(tmp_path / "tok"),
        )
        content = installed[0].read_text(encoding="utf-8")
        if sys.platform == "win32":
            assert content.startswith("#!")
            assert "python" in content.splitlines()[0].lower()
        else:
            assert content.startswith("#!/usr/bin/env python3")

    def test_hook_has_no_bash_constructs(self, tmp_path: Path) -> None:
        """Generated hook has no shell syntax anywhere in its body."""
        repo = tmp_path / "repo"
        repo.mkdir()
        subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
        installed = install_hooks(
            repo,
            server_url="http://127.0.0.1:59000",
            token_file=str(tmp_path / "tok"),
        )
        content = installed[0].read_text(encoding="utf-8")
        assert "#!/bin/sh" not in content
        assert "#!/bin/bash" not in content
        assert "set -eu" not in content
        assert "curl -sS" not in content


class TestInstallServiceBranching:
    def test_linux_install_service_shows_systemd(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Linux branch prints a systemd unit file."""
        from click.testing import CliRunner

        from backend.cli import cli

        monkeypatch.setattr("platform.system", lambda: "Linux")
        result = CliRunner().invoke(cli, ["install-service"])
        assert result.exit_code == 0
        assert "[Unit]" in result.output
        assert "systemctl" in result.output

    def test_macos_install_service_shows_launchd(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """macOS branch prints a launchd plist."""
        from click.testing import CliRunner

        from backend.cli import cli

        monkeypatch.setattr("platform.system", lambda: "Darwin")
        result = CliRunner().invoke(cli, ["install-service"])
        assert result.exit_code == 0
        assert "com.codeledger.server" in result.output
        assert "launchctl" in result.output


class TestPathBuildingUsesPathlib:
    def test_no_os_path_join_in_core_modules(self) -> None:
        """Core modules use pathlib.Path, not os.path.join."""
        root = Path(__file__).resolve().parents[2] / "backend"
        offenders: list[str] = []
        for py in root.rglob("*.py"):
            text = py.read_text(encoding="utf-8", errors="replace")
            # Skip files where os.path.join is intentional (tests, CLI
            # wrapper, os-specific helpers).
            if py.name in {"cli.py"}:
                continue
            if "os.path.join(" in text:
                offenders.append(str(py.relative_to(root.parent)))
        # We allow one or two legacy usages — document them here.
        assert len(offenders) <= 3, f"os.path.join leaked into {offenders}"
