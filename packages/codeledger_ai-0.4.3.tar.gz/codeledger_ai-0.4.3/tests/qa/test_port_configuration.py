"""Custom port propagation tests.

``--port N`` must flow through init → config → connect → hooks →
CLAUDE.md → npm wrapper. No hardcoded 8100 anywhere downstream.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest
from click.testing import CliRunner

from backend.cli import (
    _resolve_serve_bindings,
    _save_port_to_toml,
    cli,
    write_claude_code_settings,
)


class TestPortInConfig:
    def test_init_writes_requested_port(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """codeledger init --port N sets port N in codeledger.toml."""
        monkeypatch.setenv("CODELEDGER_VAULT_PASSPHRASE", "qa")
        monkeypatch.setattr(
            "backend.cli.DEFAULT_VAULT_DIR", tmp_path / ".codeledger"
        )
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE",
            tmp_path / ".codeledger" / "hook_token",
        )
        result = CliRunner().invoke(
            cli,
            [
                "init",
                "--port",
                "9000",
                "--project-root",
                str(tmp_path),
                "--vault-backend",
                "file",
                "--no-install-hooks",
            ],
        )
        assert result.exit_code == 0, result.output
        body = (tmp_path / "codeledger.toml").read_text(encoding="utf-8")
        assert "port = 9000" in body

    def test_resolve_serve_bindings_reads_toml(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """_resolve_serve_bindings reads host/port/mode from codeledger.toml."""
        cfg = tmp_path / "codeledger.toml"
        cfg.write_text(
            "[server]\n"
            'mode = "solo"\n'
            'host = "127.0.0.1"\n'
            "port = 7777\n"
            'log_level = "info"\n',
            encoding="utf-8",
        )
        if sys.platform != "win32":
            cfg.chmod(0o600)
        monkeypatch.chdir(tmp_path)
        host, port, mode = _resolve_serve_bindings()
        assert port == 7777
        assert host == "127.0.0.1"
        assert mode == "solo"

    def test_save_port_rewrites_existing_config(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--save-port rewrites the ``port =`` line in place."""
        target = tmp_path / "codeledger.toml"
        target.write_text(
            "[server]\nmode = \"solo\"\nport = 8100\n", encoding="utf-8"
        )
        monkeypatch.chdir(tmp_path)
        _save_port_to_toml(9988)
        assert "port = 9988" in target.read_text(encoding="utf-8")


class TestPortInConnect:
    def test_hooks_config_uses_configured_server_port(
        self, tmp_path: Path
    ) -> None:
        """write_claude_code_settings carries the requested port through to
        every hook curl command."""
        target = tmp_path / ".claude" / "settings.json"
        write_claude_code_settings(
            target, server_url="http://127.0.0.1:7777", token="tok"
        )
        body = target.read_text(encoding="utf-8")
        assert "http://127.0.0.1:7777" in body
        assert "/api/hooks/session-context" in body
        assert "http://127.0.0.1:8100" not in body

    def test_claude_code_settings_preserves_user_content(
        self, tmp_path: Path
    ) -> None:
        """Re-writing the config keeps unrelated keys intact."""
        target = tmp_path / ".claude" / "settings.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(
                {
                    "someOtherKey": "preserved",
                    "mcpServers": {"other": {"url": "x"}},
                    "hooks": {
                        "PostToolUse": [
                            {"hooks": [{"type": "command", "command": "echo hi"}]}
                        ]
                    },
                }
            ),
            encoding="utf-8",
        )
        write_claude_code_settings(
            target, server_url="http://127.0.0.1:7777", token="tok"
        )
        parsed = json.loads(target.read_text(encoding="utf-8"))
        assert parsed["someOtherKey"] == "preserved"
        assert "other" in parsed["mcpServers"]
        assert "PostToolUse" in parsed["hooks"]
        assert "UserPromptSubmit" in parsed["hooks"]
