"""Decision-workflow failure points F2.1 — F2.12.

Exercises ``decision.create`` input validation, auth, and auto-session
bootstrap behaviour.
"""

from __future__ import annotations

import uuid
from typing import Any

import pytest

from backend.mcp.tool_handlers import (
    MAX_DESCRIPTION_LEN,
    MAX_TAG_LEN,
    MAX_TAGS_COUNT,
    MAX_TITLE_LEN,
    HandlerError,
    ToolHandlers,
)


class TestDecisionValidation:
    async def test_title_at_limit_allowed(
        self, db: Any
    ) -> None:
        """F2.3 boundary — MAX_TITLE_LEN characters is accepted."""
        handlers = ToolHandlers(db=db)
        result = await handlers.decision_create(
            user_id=uuid.uuid4(),
            title="x" * MAX_TITLE_LEN,
            description="ok",
        )
        assert result["id"]

    async def test_title_over_limit_rejected(
        self, db: Any
    ) -> None:
        """F2.3 — title over MAX_TITLE_LEN raises HandlerError."""
        handlers = ToolHandlers(db=db)
        with pytest.raises(HandlerError, match="title"):
            await handlers.decision_create(
                user_id=uuid.uuid4(),
                title="x" * (MAX_TITLE_LEN + 1),
            )

    async def test_description_over_limit_rejected(
        self, db: Any
    ) -> None:
        """F2.4 — description over MAX_DESCRIPTION_LEN rejected."""
        handlers = ToolHandlers(db=db)
        with pytest.raises(HandlerError, match="description"):
            await handlers.decision_create(
                user_id=uuid.uuid4(),
                title="valid",
                description="x" * (MAX_DESCRIPTION_LEN + 1),
            )

    async def test_too_many_tags_rejected(self, db: Any) -> None:
        """F2.5 — more than MAX_TAGS_COUNT tags rejected."""
        handlers = ToolHandlers(db=db)
        with pytest.raises(HandlerError, match="tags"):
            await handlers.decision_create(
                user_id=uuid.uuid4(),
                title="valid",
                tags=[f"t{i}" for i in range(MAX_TAGS_COUNT + 1)],
            )

    async def test_single_tag_over_limit_rejected(self, db: Any) -> None:
        """F2.5 — individual tag over MAX_TAG_LEN rejected."""
        handlers = ToolHandlers(db=db)
        with pytest.raises(HandlerError, match="tags"):
            await handlers.decision_create(
                user_id=uuid.uuid4(),
                title="valid",
                tags=["x" * (MAX_TAG_LEN + 1)],
            )

    async def test_empty_title_rejected(self, db: Any) -> None:
        """F2.3 — empty title is HandlerError, not a silent record."""
        handlers = ToolHandlers(db=db)
        with pytest.raises(HandlerError, match="non-empty"):
            await handlers.decision_create(
                user_id=uuid.uuid4(), title=""
            )

    async def test_whitespace_title_rejected(self, db: Any) -> None:
        """Whitespace-only title fails the non-empty check."""
        handlers = ToolHandlers(db=db)
        with pytest.raises(HandlerError, match="non-empty"):
            await handlers.decision_create(
                user_id=uuid.uuid4(), title="   \t\n  "
            )


class TestDecisionPersistence:
    async def test_decision_create_sets_unverified_status(
        self, db: Any
    ) -> None:
        """F2 baseline — decision.create stores status=unverified."""
        handlers = ToolHandlers(db=db)
        result = await handlers.decision_create(
            user_id=uuid.uuid4(),
            title="Test",
        )
        assert result["status"] == "unverified"

    async def test_decision_create_returns_id(self, db: Any) -> None:
        """F2 baseline — every created decision has a UUID."""
        handlers = ToolHandlers(db=db)
        result = await handlers.decision_create(
            user_id=uuid.uuid4(), title="Test"
        )
        uuid.UUID(result["id"])  # raises if not a valid UUID


class TestDecisionAuthEnforcement:
    def test_rest_decision_create_requires_auth(
        self, client: Any
    ) -> None:
        """F2.10 — the REST endpoint is auth-gated."""
        with client:
            resp = client.post(
                "/api/decisions",
                json={"title": "x"},
            )
        assert resp.status_code == 401

    def test_rest_decision_create_expired_token_rejected(
        self, client: Any
    ) -> None:
        """F2.11 — an expired bearer token is rejected."""
        with client:
            resp = client.post(
                "/api/decisions",
                json={"title": "x"},
                headers={"Authorization": "Bearer expired.token.here"},
            )
        assert resp.status_code == 401


class TestDecisionAutoSession:
    async def test_ensure_session_creates_on_first_call(
        self, db: Any
    ) -> None:
        """F2.1 — first tool call with cwd/agent/project bootstraps a session."""
        handlers = ToolHandlers(db=db)
        ctx = await handlers.ensure_session_and_inject_context(
            cwd="/tmp/project",
            agent_name="qa",
            project_id="qa-project",
        )
        assert ctx is not None
        assert ctx.is_new_session is True
        # Session row actually persisted.
        rows = await db.query("sessions", where={"agent_name": "qa"})
        assert len(rows) == 1
