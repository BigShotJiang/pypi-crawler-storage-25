"""Git-hook-workflow failure points F3.1 — F3.12.

The generated hook script is pure Python (no bash). These tests
exercise the runtime contract — hooks must exit 0 on every failure,
never block a commit, and degrade gracefully when the server is
unreachable.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Any

from backend.utils.git_hooks import install_hooks


class TestHookRendering:
    def test_hook_uses_python_shebang_on_posix(
        self, git_repo: Path, tmp_path: Path
    ) -> None:
        """F3 cross-platform — POSIX hooks use ``#!/usr/bin/env python3``."""
        token_file = tmp_path / "hook_token"
        token_file.write_text("secret", encoding="utf-8")
        installed = install_hooks(
            git_repo,
            server_url="http://127.0.0.1:59000",
            token_file=str(token_file),
        )
        assert installed
        content = installed[0].read_text(encoding="utf-8")
        if sys.platform != "win32":
            assert content.startswith("#!/usr/bin/env python3")
        else:
            assert content.startswith("#!")
            assert "python" in content.splitlines()[0].lower()

    def test_hook_has_no_bash_syntax(
        self, git_repo: Path, tmp_path: Path
    ) -> None:
        """F3 Windows compat — generated hook script contains no bash syntax."""
        token_file = tmp_path / "hook_token"
        token_file.write_text("secret", encoding="utf-8")
        installed = install_hooks(
            git_repo,
            server_url="http://127.0.0.1:59000",
            token_file=str(token_file),
        )
        content = installed[0].read_text(encoding="utf-8")
        assert "#!/bin/bash" not in content
        assert "#!/bin/sh" not in content
        assert "set -eu" not in content
        # Subprocess / urllib calls only — no shell pipelines.
        assert "urllib.request" in content
        assert "subprocess" in content


class TestHookRuntimeBehaviour:
    def test_hook_never_blocks_commit_when_server_unreachable(
        self, git_repo: Path, tmp_path: Path
    ) -> None:
        """F3.1 — a commit still succeeds even when the server is down."""
        token_file = tmp_path / "hook_token"
        token_file.write_text("secret", encoding="utf-8")
        install_hooks(
            git_repo,
            # Almost certainly unbound port.
            server_url="http://127.0.0.1:59123",
            token_file=str(token_file),
        )
        # Stage and commit — the hook fires automatically.
        (git_repo / "x.py").write_text("x = 1\n", encoding="utf-8")
        subprocess.run(
            ["git", "add", "x.py"],
            cwd=git_repo,
            check=True,
            capture_output=True,
        )
        result = subprocess.run(
            ["git", "-c", "user.email=qa@test.com",
             "-c", "user.name=QA", "commit", "-m", "hook-test",
             "-q"],
            cwd=git_repo,
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0, (
            f"git commit failed with hook active: {result.stderr}"
        )

    def test_hook_handles_missing_token_file(
        self, git_repo: Path, tmp_path: Path
    ) -> None:
        """F3 — hook silently no-ops when the token file is absent."""
        token_file = tmp_path / "missing_hook_token"
        install_hooks(
            git_repo,
            server_url="http://127.0.0.1:59123",
            token_file=str(token_file),
        )
        (git_repo / "y.py").write_text("y = 2\n", encoding="utf-8")
        subprocess.run(
            ["git", "add", "y.py"],
            cwd=git_repo,
            check=True,
            capture_output=True,
        )
        result = subprocess.run(
            ["git", "-c", "user.email=qa@test.com",
             "-c", "user.name=QA", "commit", "-m", "no-token",
             "-q"],
            cwd=git_repo,
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0


class TestHookPayloadSecurity:
    def test_webhook_without_secret_returns_401(
        self, client: Any
    ) -> None:
        """F3.3 — direct POST without X-Webhook-Secret is rejected."""
        with client:
            resp = client.post(
                "/api/hooks/post-commit",
                json={"commit_hash": "abc", "project_id": "qa"},
            )
        assert resp.status_code == 401

    def test_post_commit_missing_fields_returns_400(
        self, client: Any
    ) -> None:
        """F3 validation — missing commit_hash returns 400."""
        with client:
            client.app.state.credentials.set(
                "webhooks", "default", "qa-secret"
            )
            resp = client.post(
                "/api/hooks/post-commit",
                json={},
                headers={"X-Webhook-Secret": "qa-secret"},
            )
        assert resp.status_code == 400

    def test_file_change_missing_fields_returns_400(
        self, client: Any
    ) -> None:
        """F3 validation — missing required fields rejected on file-change hook."""
        with client:
            client.app.state.credentials.set(
                "webhooks", "default", "qa-secret"
            )
            resp = client.post(
                "/api/hooks/file-change",
                json={"project_id": "qa"},  # missing after_snapshot_id
                headers={"X-Webhook-Secret": "qa-secret"},
            )
        assert resp.status_code == 400

    def test_empty_diff_accepted_no_crash(
        self, client: Any
    ) -> None:
        """F3.4 — empty-commit diff is processed without crashing."""
        with client:
            client.app.state.credentials.set(
                "webhooks", "default", "qa-secret"
            )
            resp = client.post(
                "/api/hooks/post-commit",
                json={
                    "commit_hash": "deadbeef",
                    "diff_text": "",
                    "project_id": "qa",
                },
                headers={"X-Webhook-Secret": "qa-secret"},
            )
        assert resp.status_code == 200
        body = resp.json()
        assert body["received"] is True
