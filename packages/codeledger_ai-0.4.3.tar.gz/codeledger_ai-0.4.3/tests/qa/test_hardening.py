"""Runtime hardening checks: headers, error handler, CORS, banner hiding."""

from __future__ import annotations

from typing import Any


class TestSecurityHeadersOnEveryResponse:
    def test_public_response_carries_headers(
        self, client: Any
    ) -> None:
        """Defence-in-depth headers attached to /health."""
        with client:
            resp = client.get("/health")
        assert resp.headers["X-Content-Type-Options"] == "nosniff"
        assert resp.headers["X-Frame-Options"] == "DENY"
        assert "Referrer-Policy" in resp.headers
        assert "Permissions-Policy" in resp.headers

    def test_protected_401_carries_headers(
        self, client: Any
    ) -> None:
        """401 responses still get the full header set."""
        with client:
            resp = client.get("/api/decisions")
        assert resp.status_code == 401
        assert resp.headers.get("X-Content-Type-Options") == "nosniff"

    def test_no_hsts_on_plain_http(self, client: Any) -> None:
        """HSTS is only attached when the request came in over TLS."""
        with client:
            resp = client.get("/health")
        assert "Strict-Transport-Security" not in resp.headers

    def test_server_header_hidden(self, client: Any) -> None:
        """No Server banner leaks the uvicorn/starlette version."""
        with client:
            resp = client.get("/health")
        # uvicorn was started with server_header=False; middleware strips
        # any lingering Server header on the way out.
        assert "Server" not in resp.headers or not resp.headers["Server"]


class TestGlobalErrorHandling:
    def test_404_is_generic(self, client: Any) -> None:
        """Missing routes return 404 without leaking filesystem paths."""
        with client:
            resp = client.get("/api/this/does/not/exist")
        assert resp.status_code in (401, 404)
        body = resp.text
        # Route paths are acceptable; absolute filesystem paths are not.
        assert "/home/" not in body
        assert "/root/" not in body


class TestCORSSoloMode:
    def test_solo_mode_does_not_allow_wildcard(self, client: Any) -> None:
        """Evil origin does not receive an Allow-Origin echo."""
        with client:
            resp = client.options(
                "/api/decisions",
                headers={
                    "Origin": "http://evil.example.com",
                    "Access-Control-Request-Method": "GET",
                },
            )
        assert (
            resp.headers.get("access-control-allow-origin")
            != "http://evil.example.com"
        )
        assert resp.headers.get("access-control-allow-origin") != "*"
