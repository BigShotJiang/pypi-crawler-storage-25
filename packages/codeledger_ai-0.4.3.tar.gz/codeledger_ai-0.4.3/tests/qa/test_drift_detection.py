"""Drift-detection workflow failure points F9.1 — F9.6.

Exercises ``DriftDetector.check_drift`` on empty projects, non-existent
paths, projects without constraints, and the empty-input validation path.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pytest

from backend.advanced.drift_detector import DriftDetector, DriftReport
from backend.intelligence.ast_tracker import ASTTracker

if TYPE_CHECKING:
    from pathlib import Path


class TestDriftInputValidation:
    async def test_empty_project_id_rejected(self, db: Any) -> None:
        """F9.1 — empty project_id raises ValueError before any work."""
        tracker = ASTTracker(db=db)
        detector = DriftDetector(db=db, ast_tracker=tracker)
        with pytest.raises(ValueError, match="project_id"):
            await detector.check_drift(project_id="", repo_path="/tmp")


class TestDriftMissingPath:
    async def test_nonexistent_repo_path_returns_empty(
        self, db: Any
    ) -> None:
        """F9.2 — a missing path yields an empty report, not a crash."""
        tracker = ASTTracker(db=db)
        detector = DriftDetector(db=db, ast_tracker=tracker)
        report = await detector.check_drift(
            project_id="p1", repo_path="/definitely/not/here"
        )
        assert isinstance(report, DriftReport)
        assert report.violations == []
        assert report.checked_files == 0

    async def test_file_path_instead_of_dir_returns_empty(
        self, db: Any, tmp_path: Path
    ) -> None:
        """F9.3 — pointing at a file instead of a dir yields empty report."""
        f = tmp_path / "not-a-dir.py"
        f.write_text("pass\n")
        tracker = ASTTracker(db=db)
        detector = DriftDetector(db=db, ast_tracker=tracker)
        report = await detector.check_drift(
            project_id="p1", repo_path=str(f)
        )
        assert report.violations == []


class TestDriftNoConstraints:
    async def test_project_without_decisions_yields_no_violations(
        self, db: Any, tmp_path: Path
    ) -> None:
        """F9.4 — no recorded decisions → no constraints → no violations."""
        # Populate the project dir with a real .py file so the walker sees it.
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text(
            "import os\nimport sys\n", encoding="utf-8"
        )
        tracker = ASTTracker(db=db)
        detector = DriftDetector(db=db, ast_tracker=tracker)
        report = await detector.check_drift(
            project_id="qa-drift-empty", repo_path=str(tmp_path)
        )
        assert report.violations == []
        assert report.checked_files >= 1
        assert report.decisions_considered == 0


class TestDriftReportShape:
    async def test_drift_report_returns_stable_keys(
        self, db: Any, tmp_path: Path
    ) -> None:
        """F9.5 — the serialized report always has the documented keys."""
        (tmp_path / "pkg").mkdir()
        (tmp_path / "pkg" / "m.py").write_text("import os\n")
        tracker = ASTTracker(db=db)
        detector = DriftDetector(db=db, ast_tracker=tracker)
        out = await detector.drift_report(
            project_id="qa-drift-keys", repo_path=str(tmp_path)
        )
        assert set(out.keys()) >= {
            "project_id",
            "checked_files",
            "decisions_considered",
            "violations",
        }
        assert out["project_id"] == "qa-drift-keys"
        assert isinstance(out["violations"], list)


class TestDriftHandlesUnreadableFile:
    async def test_binary_file_walked_but_not_flagged(
        self, db: Any, tmp_path: Path
    ) -> None:
        """F9.6 — files that decode with replacement still do not crash."""
        (tmp_path / "pkg").mkdir()
        (tmp_path / "pkg" / "bin.py").write_bytes(b"\xff\xfe\x00\x01not-python\n")
        tracker = ASTTracker(db=db)
        detector = DriftDetector(db=db, ast_tracker=tracker)
        report = await detector.check_drift(
            project_id="qa-drift-bin", repo_path=str(tmp_path)
        )
        assert isinstance(report, DriftReport)
        assert report.violations == []
