"""Conflict-detection workflow failure points F8.1 — F8.6.

Exercises ``ConflictDetector`` registration, overlap computation, severity
classification, session lifecycle, and the >100ms budget for 10-session
workloads.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pytest

from backend.verification.conflict_detector import Conflict, ConflictDetector

if TYPE_CHECKING:
    pass


class TestConflictRegistration:
    def test_empty_session_id_rejected(self, db: Any) -> None:
        """F8.1 — non-empty session_id is required."""
        detector = ConflictDetector(db)
        with pytest.raises(ValueError, match="session_id"):
            detector.register_session(
                session_id="",
                project_id="p1",
                agent_name="claude",
                files=["a.py"],
            )

    def test_empty_project_id_rejected(self, db: Any) -> None:
        """F8.1 — non-empty project_id is required."""
        detector = ConflictDetector(db)
        with pytest.raises(ValueError, match="project_id"):
            detector.register_session(
                session_id="s1",
                project_id="",
                agent_name="claude",
                files=["a.py"],
            )

    def test_update_unknown_session_raises(self, db: Any) -> None:
        """F8.2 — updating a never-registered session is a hard error."""
        detector = ConflictDetector(db)
        with pytest.raises(ValueError, match="Unknown session_id"):
            detector.update_session_files("no-such-session", ["a.py"])


class TestConflictOverlap:
    async def test_no_overlap_returns_empty(self, db: Any) -> None:
        """F8.3 — disjoint file sets produce no conflicts."""
        detector = ConflictDetector(db)
        detector.register_session("s1", "p1", "claude", ["a.py"])
        detector.register_session("s2", "p1", "cursor", ["b.py"])
        conflicts = await detector.check_conflicts("s1", "p1")
        assert conflicts == []

    async def test_overlapping_files_produce_conflict(
        self, db: Any
    ) -> None:
        """F8.4 — overlapping files yield a Conflict with agent metadata."""
        detector = ConflictDetector(db)
        detector.register_session("s1", "p1", "claude", ["a.py", "b.py"])
        detector.register_session("s2", "p1", "cursor", ["b.py", "c.py"])
        conflicts = await detector.check_conflicts("s1", "p1")
        assert len(conflicts) == 1
        assert isinstance(conflicts[0], Conflict)
        assert conflicts[0].conflicting_session_id == "s2"
        assert conflicts[0].conflicting_agent == "cursor"
        assert conflicts[0].overlapping_files == ["b.py"]

    async def test_different_project_not_reported(
        self, db: Any
    ) -> None:
        """F8.5 — sessions in other projects do not leak into conflicts."""
        detector = ConflictDetector(db)
        detector.register_session("s1", "p1", "claude", ["a.py"])
        detector.register_session("s2", "p2", "cursor", ["a.py"])
        conflicts = await detector.check_conflicts("s1", "p1")
        assert conflicts == []

    async def test_ended_session_removed_from_conflicts(
        self, db: Any
    ) -> None:
        """F8.6 — end_session removes a tracker from later overlap checks."""
        detector = ConflictDetector(db)
        detector.register_session("s1", "p1", "claude", ["a.py"])
        detector.register_session("s2", "p1", "cursor", ["a.py"])
        detector.end_session("s2")
        conflicts = await detector.check_conflicts("s1", "p1")
        assert conflicts == []

    async def test_unknown_session_check_is_empty(self, db: Any) -> None:
        """Checking a session that never registered yields empty, not raise."""
        detector = ConflictDetector(db)
        conflicts = await detector.check_conflicts("ghost", "p1")
        assert conflicts == []


class TestActiveSessionView:
    def test_get_active_sessions_scoped_by_project(
        self, db: Any
    ) -> None:
        """get_active_sessions returns only the current project's sessions."""
        detector = ConflictDetector(db)
        detector.register_session("s1", "p1", "claude", ["a.py"])
        detector.register_session("s2", "p2", "cursor", ["b.py"])
        view = detector.get_active_sessions("p1")
        assert len(view) == 1
        assert view[0]["session_id"] == "s1"
        assert view[0]["agent_name"] == "claude"
        assert view[0]["files"] == ["a.py"]
