"""Onboarding walkthrough tests.

The unauthenticated ``/api/setup/status`` and ``/api/setup/complete``
endpoints drive the first-run browser experience. These tests verify
the contract App.tsx relies on.
"""

from __future__ import annotations

from typing import Any


class TestOnboardingContract:
    def test_fresh_install_setup_complete_is_false(
        self, client: Any
    ) -> None:
        """A brand-new install reports setup_complete = false."""
        with client:
            resp = client.get("/api/setup/status")
        assert resp.status_code == 200
        body = resp.json()
        assert body["setup_complete"] is False
        assert body["step_reached"] >= 1

    def test_status_is_unauthenticated(self, client: Any) -> None:
        """/api/setup/status does not require an Authorization header."""
        with client:
            resp = client.get("/api/setup/status")
        assert resp.status_code == 200

    def test_status_exposes_mode_and_port(self, client: Any) -> None:
        """The status payload surfaces mode and port for the welcome card."""
        with client:
            body = client.get("/api/setup/status").json()
        assert body["mode"] == "solo"
        assert body["port"] == 9999

    def test_complete_marks_setup(self, client: Any) -> None:
        """POST /api/setup/complete flips setup_complete and persists step_reached."""
        with client:
            resp = client.post(
                "/api/setup/complete",
                json={"step_reached": 5, "complete": True},
            )
            assert resp.status_code == 200
            payload = resp.json()
            assert payload["setup_complete"] is True
            assert payload["step_reached"] == 5
            status = client.get("/api/setup/status").json()
            assert status["setup_complete"] is True
            assert status["step_reached"] == 5

    def test_step_reached_persists_without_completing(
        self, client: Any
    ) -> None:
        """Posting complete=False records progress without closing onboarding."""
        with client:
            client.post(
                "/api/setup/complete",
                json={"step_reached": 3, "complete": False},
            )
            status = client.get("/api/setup/status").json()
        assert status["setup_complete"] is False
        assert status["step_reached"] == 3

    def test_multiple_completes_are_idempotent(
        self, client: Any
    ) -> None:
        """Hitting complete twice does not create duplicate _setup rows."""
        with client:
            for _ in range(3):
                client.post(
                    "/api/setup/complete",
                    json={"step_reached": 5, "complete": True},
                )
            status = client.get("/api/setup/status").json()
        assert status["setup_complete"] is True
