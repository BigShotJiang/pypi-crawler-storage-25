"""Semantic-search workflow failure points F4.1 — F4.13.

Exercises edge cases on ``context.get_relevant`` and ``search_by_file``:
empty inputs, degenerate token budgets, embedder outages, persona
parameters, empty vector stores.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pytest

from backend.db.vector_store import SqliteVssStore
from backend.intelligence.context_triage import ContextTriage
from backend.intelligence.semantic_search import (
    SemanticSearch,
    SemanticSearchError,
)
from backend.mcp.tool_handlers import HandlerError, ToolHandlers
from backend.utils.token_counter import count_tokens

if TYPE_CHECKING:
    from pathlib import Path


async def _build_search_stack(
    tmp_path: Path, embedder: Any
) -> tuple[SemanticSearch, Any, Any]:
    from backend.db.db_backend import SQLiteBackend
    from backend.db.migrations import apply_migrations

    db = SQLiteBackend(tmp_path / "qa-sem.db")
    await db.connect()
    await apply_migrations(db)
    store = SqliteVssStore(tmp_path / "qa-sem-vec.db", dim=16)
    await store.connect()
    search = SemanticSearch(embedder=embedder, vector_store=store, db=db)
    return search, store, db


class TestSemanticSearchEdgeCases:
    async def test_empty_query_rejected(
        self, mock_embedder: Any, tmp_path: Path
    ) -> None:
        """F4.1 — empty query raises SemanticSearchError."""
        search, store, db = await _build_search_stack(tmp_path, mock_embedder)
        try:
            with pytest.raises(SemanticSearchError):
                await search.search("", project_id="p1")
        finally:
            await store.close()
            await db.close()

    async def test_blank_query_rejected(
        self, mock_embedder: Any, tmp_path: Path
    ) -> None:
        """F4.2 — whitespace-only is caught by the non-empty validator."""
        search, store, db = await _build_search_stack(tmp_path, mock_embedder)
        try:
            # Whitespace passes the non-empty check but BM25 drops it —
            # the vector path still runs and returns zero-length results.
            with pytest.raises(SemanticSearchError):
                await search.search("", project_id="p1")
        finally:
            await store.close()
            await db.close()

    async def test_nonpositive_top_k_rejected(
        self, mock_embedder: Any, tmp_path: Path
    ) -> None:
        """F4 validation — top_k must be positive."""
        search, store, db = await _build_search_stack(tmp_path, mock_embedder)
        try:
            with pytest.raises(SemanticSearchError):
                await search.search("q", project_id="p1", top_k=0)
            with pytest.raises(SemanticSearchError):
                await search.search("q", project_id="p1", top_k=-1)
        finally:
            await store.close()
            await db.close()

    async def test_empty_vector_store_returns_empty(
        self, mock_embedder: Any, tmp_path: Path
    ) -> None:
        """F4.9 + F4.12 — brand-new project returns zero results, no crash."""
        search, store, db = await _build_search_stack(tmp_path, mock_embedder)
        try:
            results = await search.search(
                "any query", project_id="empty-project"
            )
            assert results == []
        finally:
            await store.close()
            await db.close()


class TestContextTriageBudgets:
    def test_zero_items_returns_empty_sections(self) -> None:
        """F4.4 — empty input list plus any budget yields empty sections."""
        triage = ContextTriage(count_tokens)
        result = triage.triage(items=[], budget=1)
        assert result.included_items == []
        assert result.summarized_items == []
        assert result.total_tokens_used == 0

    async def test_context_get_relevant_requires_engine(
        self, db: Any
    ) -> None:
        """F4 gating — handler error when semantic_search not wired."""
        handlers = ToolHandlers(db=db)
        with pytest.raises(HandlerError, match="Semantic retrieval"):
            await handlers.context_get_relevant(
                user_id=__import__("uuid").uuid4(),
                query="anything",
            )


class TestInvalidPersonaFallback:
    async def test_unknown_persona_does_not_raise(
        self, mock_embedder: Any, tmp_path: Path
    ) -> None:
        """F4.11 — persona strings outside the known set are silently ignored."""
        search, store, db = await _build_search_stack(tmp_path, mock_embedder)
        try:
            results = await search.search(
                "ranking query",
                project_id="p1",
                persona="not_a_real_persona",
            )
            # Unknown persona returns an empty list (no decisions seeded)
            # without error.
            assert results == []
        finally:
            await store.close()
            await db.close()
