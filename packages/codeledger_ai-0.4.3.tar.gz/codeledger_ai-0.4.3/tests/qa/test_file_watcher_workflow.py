"""File-watcher workflow failure points F7.1 — F7.10.

Exercises snapshot_store + file_watcher resilience: missing files,
permission errors, binary detection, oversized payloads, unicode paths,
first-snapshot baseline.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import pytest

from backend.utils.file_watcher import (
    _matches_extension,
    _should_ignore,
    _validate_path,
)
from backend.utils.snapshot_store import SnapshotStore


class TestSnapshotStoreMissingFile:
    async def test_missing_file_raises_filenotfound(
        self, db: Any, tmp_path: Path
    ) -> None:
        """F7.1 — take_snapshot on a deleted file raises FileNotFoundError."""
        store = SnapshotStore(db)
        missing = tmp_path / "gone.py"
        with pytest.raises(FileNotFoundError):
            await store.take_snapshot(
                file_path=str(missing), project_id="qa"
            )


class TestSnapshotStoreUnicode:
    async def test_unicode_filename_roundtrip(
        self, db: Any, tmp_path: Path
    ) -> None:
        """F7.9 — unicode filenames persist through snapshot_store."""
        target = tmp_path / "模块.py"
        target.write_text("x = 1\n", encoding="utf-8")
        store = SnapshotStore(db)
        snap = await store.take_snapshot(
            file_path=str(target), project_id="qa"
        )
        assert snap.file_path == str(target)
        assert snap.content == "x = 1\n"


class TestSnapshotStoreBaseline:
    async def test_first_snapshot_generates_no_previous(
        self, db: Any, tmp_path: Path
    ) -> None:
        """F7.8 — the first snapshot returns a new FileSnapshot; nothing before."""
        target = tmp_path / "fresh.py"
        target.write_text("pass\n", encoding="utf-8")
        store = SnapshotStore(db)
        prev = await store.get_last_snapshot(str(target), "qa")
        assert prev is None
        new = await store.take_snapshot(str(target), "qa")
        assert new.content == "pass\n"


class TestSnapshotStoreContentUnchanged:
    async def test_same_content_returns_existing_snapshot(
        self, db: Any, tmp_path: Path
    ) -> None:
        """F7 dedup — identical content returns the existing row."""
        target = tmp_path / "same.py"
        target.write_text("x\n", encoding="utf-8")
        store = SnapshotStore(db)
        first = await store.take_snapshot(str(target), "qa")
        second = await store.take_snapshot(str(target), "qa")
        assert first.id == second.id


class TestPathTraversalGuards:
    def test_snapshot_store_validate_path_rejects_escape(
        self, tmp_path: Path
    ) -> None:
        """F7 security — _validate_path rejects paths outside project root."""
        proj = tmp_path / "proj"
        proj.mkdir()
        outside = tmp_path / "outside.py"
        outside.write_text("x", encoding="utf-8")
        from backend.utils.snapshot_store import _validate_path

        with pytest.raises(ValueError, match="traversal"):
            _validate_path(str(outside), proj)

    def test_file_watcher_validate_path_rejects_escape(
        self, tmp_path: Path
    ) -> None:
        """F7 security — file_watcher's _validate_path rejects escapes too."""
        proj = tmp_path / "proj"
        proj.mkdir()
        outside = tmp_path / "etc" / "shadow"
        outside.parent.mkdir(parents=True, exist_ok=True)
        outside.write_text("x", encoding="utf-8")
        with pytest.raises(ValueError, match="traversal"):
            _validate_path(str(outside), proj)


class TestWatcherFilters:
    def test_extension_filter_drops_unmatched(self) -> None:
        """F7 filtering — only watched extensions fire the handler."""
        assert _matches_extension("a.py", (".py",)) is True
        assert _matches_extension("a.txt", (".py",)) is False
        assert _matches_extension("a", (".py",)) is False

    def test_ignore_pattern_drops_node_modules(
        self, tmp_path: Path
    ) -> None:
        """F7 filtering — ``node_modules/`` is excluded by default."""
        nested = tmp_path / "node_modules" / "foo" / "index.py"
        nested.parent.mkdir(parents=True)
        nested.write_text("x", encoding="utf-8")
        assert _should_ignore(
            str(nested), tmp_path, ("node_modules",)
        ) is True

    def test_ignore_pattern_allows_src_tree(self, tmp_path: Path) -> None:
        """F7 filtering — a src/ file is not matched by default ignore set."""
        src = tmp_path / "src" / "app.py"
        src.parent.mkdir()
        src.write_text("x", encoding="utf-8")
        assert _should_ignore(
            str(src), tmp_path, ("node_modules", ".git")
        ) is False


class TestWatcherRobustness:
    async def test_snapshot_store_permission_error_propagates(
        self, db: Any, tmp_path: Path
    ) -> None:
        """F7.2 — PermissionError from filesystem reads is raised cleanly."""
        if sys.platform == "win32":
            pytest.skip("POSIX permission bits only")
        target = tmp_path / "locked.py"
        target.write_text("x\n", encoding="utf-8")
        target.chmod(0o000)
        store = SnapshotStore(db)
        try:
            with pytest.raises(PermissionError):
                await store.take_snapshot(str(target), "qa")
        finally:
            target.chmod(0o600)
