"""Security test: SEC-10 — PATs are hashed before storage.

Creates personal access tokens and verifies: (1) only the SHA-256 hash is
stored in the database; (2) the plaintext PAT does not appear in any column of
any table; (3) validation works by hashing the incoming plaintext.
"""

from __future__ import annotations

import hashlib
from typing import TYPE_CHECKING

import pytest

from backend.auth.auth_service import AuthService, AuthSettings
from backend.auth.credential_manager import CredentialManager
from backend.config import CredentialConfig
from backend.db.db_backend import ALLOWED_TABLES, SQLiteBackend
from backend.db.migrations import apply_migrations

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
async def auth_service(
    tmp_path: Path,
) -> tuple[AuthService, SQLiteBackend]:
    db = SQLiteBackend(tmp_path / "pat.db")
    await db.connect()
    await apply_migrations(db)

    creds = CredentialManager(
        CredentialConfig(
            backend="file",
            vault_path=str(tmp_path / "vault.enc"),
        ),
        passphrase="test-passphrase",
        _iterations=1000,
    )
    # Low memory_cost keeps the fixture fast
    auth = AuthService(db, creds, AuthSettings(argon2_memory_cost_kb=512))
    yield auth, db
    await db.close()


async def _scan_every_column_for(
    backend: SQLiteBackend, needle: str
) -> list[tuple[str, str]]:
    """Return (table, column) pairs where ``needle`` appears verbatim."""
    matches: list[tuple[str, str]] = []
    for table in sorted(ALLOWED_TABLES):
        if table == "_migrations":
            continue
        rows = await backend.execute_raw(f"SELECT * FROM {table}")
        for row in rows:
            for col, value in row.items():
                if value is None:
                    continue
                if needle in str(value):
                    matches.append((table, col))
    return matches


# ---------------------------------------------------------------------------
# SEC-10 invariants
# ---------------------------------------------------------------------------


class TestPatHashing:
    """PATs are stored only as SHA-256 hashes; plaintext never appears in DB."""

    @pytest.mark.asyncio
    async def test_plaintext_not_in_any_table(
        self, auth_service: tuple[AuthService, SQLiteBackend]
    ) -> None:
        auth, db = auth_service
        user = await auth.register_email_user(
            "pat@example.com", "Pat", "password-abc"
        )
        result = await auth.create_pat(user.id, "scan-token")

        matches = await _scan_every_column_for(db, result.plaintext)
        assert matches == [], (
            f"Plaintext PAT leaked in: {matches}"
        )

    @pytest.mark.asyncio
    async def test_stored_pat_hash_is_sha256(
        self, auth_service: tuple[AuthService, SQLiteBackend]
    ) -> None:
        auth, db = auth_service
        user = await auth.register_email_user(
            "hash@example.com", "Hash", "password-abc"
        )
        result = await auth.create_pat(user.id, "hash-token")

        expected_hash = hashlib.sha256(result.plaintext.encode()).hexdigest()
        rows = await db.execute_raw(
            "SELECT pat_hash FROM personal_access_tokens WHERE id = ?",
            (str(result.record.id),),
        )
        assert rows
        stored = rows[0]["pat_hash"]
        assert stored == expected_hash
        assert stored != result.plaintext
        assert len(stored) == 64  # SHA-256 hex

    @pytest.mark.asyncio
    async def test_validation_works_via_hash_compare(
        self, auth_service: tuple[AuthService, SQLiteBackend]
    ) -> None:
        auth, _db = auth_service
        user = await auth.register_email_user(
            "val@example.com", "Val", "password-abc"
        )
        result = await auth.create_pat(user.id, "validate-token")

        validated = await auth.validate_pat(result.plaintext)
        assert validated.id == user.id

    @pytest.mark.asyncio
    async def test_tampered_pat_rejected(
        self, auth_service: tuple[AuthService, SQLiteBackend]
    ) -> None:
        from backend.auth.auth_service import AuthError

        auth, _db = auth_service
        user = await auth.register_email_user(
            "tamper@example.com", "Tamper", "password-abc"
        )
        result = await auth.create_pat(user.id, "tamper-token")
        tampered = result.plaintext[:-1] + (
            "X" if result.plaintext[-1] != "X" else "Y"
        )

        with pytest.raises(AuthError, match="Invalid personal access token"):
            await auth.validate_pat(tampered)

    @pytest.mark.asyncio
    async def test_multiple_pats_each_unique_hash(
        self, auth_service: tuple[AuthService, SQLiteBackend]
    ) -> None:
        auth, db = auth_service
        user = await auth.register_email_user(
            "multi@example.com", "Multi", "password-abc"
        )
        a = await auth.create_pat(user.id, "token-a")
        b = await auth.create_pat(user.id, "token-b")

        assert a.plaintext != b.plaintext
        assert a.record.pat_hash != b.record.pat_hash

        rows = await db.execute_raw(
            "SELECT COUNT(*) AS n FROM personal_access_tokens"
        )
        assert rows[0]["n"] == 2

    @pytest.mark.asyncio
    async def test_password_hash_is_argon2id_not_plain(
        self, auth_service: tuple[AuthService, SQLiteBackend]
    ) -> None:
        """SEC-07: password_hash must be an Argon2id hash, not plaintext."""
        auth, db = auth_service
        await auth.register_email_user(
            "pw@example.com", "PW", "rawpassword"
        )

        rows = await db.execute_raw(
            "SELECT password_hash FROM users WHERE email = ?",
            ("pw@example.com",),
        )
        stored = rows[0]["password_hash"]
        assert stored != "rawpassword"
        assert stored.startswith("$argon2id$"), (
            f"Password hash must be Argon2id, got: {stored[:30]}..."
        )
