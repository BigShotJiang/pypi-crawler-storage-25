"""Security test: SEC-09 — Vault files must not be world-readable.

Verifies that vault files created by FileVault have 0o600 permissions
(owner read/write only), preventing other users from reading secrets.
"""

from __future__ import annotations

import stat
import sys
from typing import TYPE_CHECKING

import pytest

from backend.auth.credential_manager import FileVault

if TYPE_CHECKING:
    from pathlib import Path

_TEST_ITERATIONS = 1000


@pytest.mark.skipif(sys.platform == "win32", reason="POSIX permissions only")
class TestVaultFilePermissions:
    """Vault files must be created with 0o600 permissions."""

    def test_new_vault_file_permissions(self, tmp_path: Path) -> None:
        vault = FileVault(tmp_path / "vault.enc", "pass", iterations=_TEST_ITERATIONS)
        vault.set("test:key", "test-value")

        mode = (tmp_path / "vault.enc").stat().st_mode
        assert mode & stat.S_IROTH == 0, "Vault file is world-readable"
        assert mode & stat.S_IWOTH == 0, "Vault file is world-writable"
        assert mode & stat.S_IXOTH == 0, "Vault file is world-executable"
        assert mode & stat.S_IRGRP == 0, "Vault file is group-readable"
        assert mode & stat.S_IWGRP == 0, "Vault file is group-writable"

    def test_permissions_preserved_after_update(self, tmp_path: Path) -> None:
        vault = FileVault(tmp_path / "vault.enc", "pass", iterations=_TEST_ITERATIONS)
        vault.set("key1", "value1")
        vault.set("key2", "value2")

        mode = (tmp_path / "vault.enc").stat().st_mode
        assert mode & stat.S_IROTH == 0, "Vault file is world-readable after update"
        assert mode & stat.S_IWOTH == 0, "Vault file is world-writable after update"

    def test_permissions_preserved_after_delete(self, tmp_path: Path) -> None:
        vault = FileVault(tmp_path / "vault.enc", "pass", iterations=_TEST_ITERATIONS)
        vault.set("key1", "value1")
        vault.set("key2", "value2")
        vault.delete("key1")

        mode = (tmp_path / "vault.enc").stat().st_mode
        assert mode & stat.S_IROTH == 0, "Vault file is world-readable after delete"
        assert mode & stat.S_IWOTH == 0, "Vault file is world-writable after delete"

    def test_no_temp_file_left_behind(self, tmp_path: Path) -> None:
        vault = FileVault(tmp_path / "vault.enc", "pass", iterations=_TEST_ITERATIONS)
        vault.set("key", "value")
        assert not (tmp_path / "vault.tmp").exists(), "Temp file was not cleaned up"
