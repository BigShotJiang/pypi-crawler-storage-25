"""Security test: SEC-01 — No credentials in the database.

Scans every column in every table after inserting rows that include credential
material. Asserts that the plaintext credentials do not appear in any row of
any table. Hashed fields (``password_hash``, ``pat_hash``) are permitted to
contain hash output, but the plaintext inputs must never appear.
"""

from __future__ import annotations

import hashlib
import secrets
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import ALLOWED_TABLES, SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.models import PersonalAccessToken, User

if TYPE_CHECKING:
    from pathlib import Path


# Known plaintext secrets we will try to leak — none of these strings should
# appear in any row of any table at the end of the test.
_PLAINTEXT_PASSWORD = "correct horse battery staple"
_PLAINTEXT_PAT = "cl_pat_" + secrets.token_urlsafe(24)
_BEARER_TOKEN = "Bearer eyJhbGciOiJIUzI1NiJ9.abc.def"
_API_KEY = "sk-live-1234567890abcdef"
_OAUTH_REFRESH = "1//0abc-refresh-token-xyz"


async def _scan_all_rows(backend: SQLiteBackend) -> list[tuple[str, dict[str, object]]]:
    """Return every (table_name, row) pair from every domain table."""
    results: list[tuple[str, dict[str, object]]] = []
    for table in sorted(ALLOWED_TABLES):
        if table == "_migrations":
            continue
        rows = await backend.execute_raw(f"SELECT * FROM {table}")
        for row in rows:
            results.append((table, row))
    return results


@pytest.fixture
async def seeded_backend(tmp_path: Path) -> SQLiteBackend:
    """Backend seeded with rows carrying credentials only in the safe ways."""
    backend = SQLiteBackend(tmp_path / "seed.db")
    await backend.connect()
    await apply_migrations(backend)

    # Seed a user whose password is stored as an Argon2-style hash.
    # The hashed form here is sha256(password) as a stand-in; the key property
    # we verify is that the *plaintext* never appears anywhere.
    hashed_password = hashlib.sha256(_PLAINTEXT_PASSWORD.encode()).hexdigest()
    user = User(
        email="test@example.com",
        name="Test User",
        provider="local",
        password_hash=f"$argon2id${hashed_password}",
    )
    await backend.insert("users", user.to_dict())

    # Seed a PAT — only the hash is stored.
    pat_hash = hashlib.sha256(_PLAINTEXT_PAT.encode()).hexdigest()
    pat = PersonalAccessToken(
        user_id=user.id, name="ci-token", pat_hash=pat_hash
    )
    await backend.insert("personal_access_tokens", pat.to_dict())

    yield backend
    await backend.close()


# ---------------------------------------------------------------------------
# Invariant: plaintext credentials never appear in any table
# ---------------------------------------------------------------------------


class TestNoPlaintextInDatabase:
    """SEC-01 enforcement: database contains no plaintext credentials."""

    @pytest.mark.asyncio
    async def test_no_plaintext_password(
        self, seeded_backend: SQLiteBackend
    ) -> None:
        rows = await _scan_all_rows(seeded_backend)
        for table, row in rows:
            for col, value in row.items():
                if value is None:
                    continue
                text = str(value)
                assert _PLAINTEXT_PASSWORD not in text, (
                    f"Plaintext password found in {table}.{col}"
                )

    @pytest.mark.asyncio
    async def test_no_plaintext_pat(
        self, seeded_backend: SQLiteBackend
    ) -> None:
        rows = await _scan_all_rows(seeded_backend)
        for table, row in rows:
            for col, value in row.items():
                if value is None:
                    continue
                text = str(value)
                assert _PLAINTEXT_PAT not in text, (
                    f"Plaintext PAT found in {table}.{col}"
                )

    @pytest.mark.asyncio
    async def test_hash_columns_contain_hashes(
        self, seeded_backend: SQLiteBackend
    ) -> None:
        """password_hash and pat_hash must be non-empty, and not equal to plaintext."""
        users = await seeded_backend.execute_raw(
            "SELECT password_hash FROM users"
        )
        assert users
        for row in users:
            assert row["password_hash"]
            assert row["password_hash"] != _PLAINTEXT_PASSWORD

        pats = await seeded_backend.execute_raw(
            "SELECT pat_hash FROM personal_access_tokens"
        )
        assert pats
        for row in pats:
            assert row["pat_hash"]
            assert row["pat_hash"] != _PLAINTEXT_PAT

    @pytest.mark.asyncio
    async def test_attempting_to_insert_token_field_fails(
        self, seeded_backend: SQLiteBackend
    ) -> None:
        """The schema has no column for raw tokens; insert with such a column fails."""
        import aiosqlite

        # Try inserting a row into users with a hypothetical 'api_key' column
        # (which does not exist). The DB should refuse the insert.
        with pytest.raises((Exception, aiosqlite.Error)):
            await seeded_backend.execute_raw(
                "INSERT INTO users (id, email, api_key, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?)",
                ("x", "e@e.com", _API_KEY, "2026-01-01T00:00:00+00:00",
                 "2026-01-01T00:00:00+00:00"),
            )

    @pytest.mark.asyncio
    async def test_no_token_like_patterns_in_any_row(
        self, seeded_backend: SQLiteBackend
    ) -> None:
        """Scan all tables for strings that look like common credential patterns."""
        rows = await _scan_all_rows(seeded_backend)
        for table, row in rows:
            for col, value in row.items():
                if value is None:
                    continue
                text = str(value)
                # None of the probe strings should be in the data.
                assert _BEARER_TOKEN not in text, (
                    f"Bearer token leaked in {table}.{col}"
                )
                assert _API_KEY not in text, (
                    f"API key leaked in {table}.{col}"
                )
                assert _OAUTH_REFRESH not in text, (
                    f"Refresh token leaked in {table}.{col}"
                )
