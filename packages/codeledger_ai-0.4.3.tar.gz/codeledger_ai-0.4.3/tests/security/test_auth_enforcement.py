"""Security test: SEC-05 — Authentication enforced on every endpoint.

Mounts the ``AuthMiddleware`` on a FastAPI app with a representative route set
and verifies that every route except explicit public paths returns HTTP 401
when called without credentials, and HTTP 200 when a valid JWT or PAT is
supplied.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from backend.auth.auth_middleware import AuthMiddleware
from backend.auth.auth_service import AuthService, AuthSettings
from backend.auth.credential_manager import CredentialManager
from backend.config import CredentialConfig
from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations

if TYPE_CHECKING:
    from pathlib import Path


_PROTECTED_ROUTES = [
    ("GET", "/api/decisions"),
    ("POST", "/api/decisions"),
    ("GET", "/api/stories"),
    ("POST", "/api/stories"),
    ("GET", "/api/sessions"),
    ("POST", "/api/sessions"),
    ("GET", "/api/users/me"),
    ("GET", "/mcp/tools"),
]

_PUBLIC_ROUTES = [
    ("GET", "/health"),
]


async def _build_stack(
    tmp_path: Path,
) -> tuple[FastAPI, AuthService, SQLiteBackend, CredentialManager]:
    db = SQLiteBackend(tmp_path / "auth.db")
    await db.connect()
    await apply_migrations(db)

    creds = CredentialManager(
        CredentialConfig(
            backend="file",
            vault_path=str(tmp_path / "vault.enc"),
        ),
        passphrase="test-passphrase",
        _iterations=1000,
    )

    auth = AuthService(db, creds, AuthSettings(argon2_memory_cost_kb=512))

    app = FastAPI()

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    def _make_handler(p: str):
        def route_handler() -> dict[str, str]:
            return {"path": p}

        return route_handler

    for method, path in _PROTECTED_ROUTES:
        handler = _make_handler(path)
        if method == "GET":
            app.get(path)(handler)
        elif method == "POST":
            app.post(path)(handler)

    app.add_middleware(AuthMiddleware, auth_service=auth)
    return app, auth, db, creds


@pytest.fixture
async def stack(
    tmp_path: Path,
) -> tuple[FastAPI, AuthService, SQLiteBackend, CredentialManager]:
    app, auth, db, creds = await _build_stack(tmp_path)
    yield app, auth, db, creds
    await db.close()


# ---------------------------------------------------------------------------
# 401 on every protected route without auth
# ---------------------------------------------------------------------------


class TestNoAuthReturns401:
    """Every protected endpoint rejects unauthenticated requests."""

    @pytest.mark.parametrize(
        "method,path", _PROTECTED_ROUTES, ids=lambda p: str(p)
    )
    def test_unauth_returns_401(
        self,
        stack: tuple[FastAPI, AuthService, SQLiteBackend, CredentialManager],
        method: str,
        path: str,
    ) -> None:
        app, *_ = stack
        client = TestClient(app, raise_server_exceptions=True)
        response = client.request(method, path)
        assert response.status_code == 401, (
            f"{method} {path} returned {response.status_code}, expected 401"
        )
        assert "detail" in response.json()

    def test_invalid_bearer_returns_401(
        self,
        stack: tuple[FastAPI, AuthService, SQLiteBackend, CredentialManager],
    ) -> None:
        app, *_ = stack
        client = TestClient(app)
        response = client.get(
            "/api/decisions",
            headers={"Authorization": "Bearer invalid-token"},
        )
        assert response.status_code == 401

    def test_invalid_cookie_returns_401(
        self,
        stack: tuple[FastAPI, AuthService, SQLiteBackend, CredentialManager],
    ) -> None:
        app, *_ = stack
        client = TestClient(app, cookies={"codeledger_session": "bad"})
        response = client.get("/api/decisions")
        assert response.status_code == 401


# ---------------------------------------------------------------------------
# Public routes stay public
# ---------------------------------------------------------------------------


class TestPublicRoutesOpen:
    """Health-check and other explicitly public routes need no auth."""

    @pytest.mark.parametrize(
        "method,path", _PUBLIC_ROUTES, ids=lambda p: str(p)
    )
    def test_public_routes_no_auth(
        self,
        stack: tuple[FastAPI, AuthService, SQLiteBackend, CredentialManager],
        method: str,
        path: str,
    ) -> None:
        app, *_ = stack
        client = TestClient(app)
        response = client.request(method, path)
        assert response.status_code == 200


# ---------------------------------------------------------------------------
# Valid credentials accepted
# ---------------------------------------------------------------------------


class TestValidAuthAccepted:
    """Valid JWT and PAT credentials pass through to the handler."""

    @pytest.mark.asyncio
    async def test_valid_jwt_accepted(
        self,
        stack: tuple[FastAPI, AuthService, SQLiteBackend, CredentialManager],
    ) -> None:
        app, auth, _db, _creds = stack
        user = await auth.register_email_user(
            "alice@example.com", "Alice", "password123"
        )
        token = auth.issue_jwt(user)

        client = TestClient(app)
        response = client.get(
            "/api/decisions", headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_valid_pat_accepted(
        self,
        stack: tuple[FastAPI, AuthService, SQLiteBackend, CredentialManager],
    ) -> None:
        app, auth, _db, _creds = stack
        user = await auth.register_email_user(
            "bob@example.com", "Bob", "password456"
        )
        result = await auth.create_pat(user.id, "ci-token")

        client = TestClient(app)
        response = client.get(
            "/api/decisions",
            headers={"Authorization": f"Bearer {result.plaintext}"},
        )
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_env_token_accepted(
        self,
        stack: tuple[FastAPI, AuthService, SQLiteBackend, CredentialManager],
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        app, auth, _db, _creds = stack
        user = await auth.register_email_user(
            "carol@example.com", "Carol", "password789"
        )
        result = await auth.create_pat(user.id, "env-token")

        monkeypatch.setenv("CODELEDGER_TOKEN", result.plaintext)
        client = TestClient(app)
        response = client.get("/api/decisions")
        assert response.status_code == 200
