"""Security test: SEC-02 — No credentials in log output.

Logs messages containing fake credentials through the sanitizing formatter and
asserts the output contains [REDACTED] and not the original secret values.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from backend.utils.log_sanitizer import SanitizingFormatter, redact, setup_logging

if TYPE_CHECKING:
    import pytest

_REDACTED = "[REDACTED]"


# ---------------------------------------------------------------------------
# Direct redaction tests
# ---------------------------------------------------------------------------


class TestRedactPatterns:
    """Test the redact() function against all credential patterns."""

    def test_bearer_token(self) -> None:
        msg = "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.payload.signature"
        result = redact(msg)
        assert "eyJhbGciOiJIUzI1NiJ9" not in result
        assert _REDACTED in result

    def test_bearer_case_insensitive(self) -> None:
        msg = "bearer abc123def456ghi789"
        result = redact(msg)
        assert "abc123def456ghi789" not in result

    def test_jwt_token(self) -> None:
        jwt = (
            "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0"
            ".dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
        )
        msg = f"Token issued: {jwt}"
        result = redact(msg)
        assert "eyJhbGciOiJIUzI1NiJ9" not in result
        assert "dozjgNryP4J3jVmNHl0w5N" not in result
        assert _REDACTED in result

    def test_github_pat(self) -> None:
        msg = "Using token ghp_1234567890abcdefABCDEF1234567890abcd"
        result = redact(msg)
        assert "ghp_1234567890" not in result
        assert _REDACTED in result

    def test_github_oauth_token(self) -> None:
        msg = "OAuth: gho_abcdefghijklmnopqrstuvwxyz"
        result = redact(msg)
        assert "gho_abcdefghijklmnop" not in result

    def test_github_user_to_server_token(self) -> None:
        msg = "ghu_abcdefghij1234567890"
        result = redact(msg)
        assert "ghu_abcdefghij" not in result

    def test_github_server_to_server_token(self) -> None:
        msg = "ghs_abcdefghij1234567890"
        result = redact(msg)
        assert "ghs_abcdefghij" not in result

    def test_slack_bot_token(self) -> None:
        msg = "SLACK_TOKEN=xoxb-123456789-123456789-abcdefghijklmnop"
        result = redact(msg)
        assert "xoxb-123456789" not in result
        assert _REDACTED in result

    def test_slack_user_token(self) -> None:
        msg = "xoxp-111-222-333-abcdef"
        result = redact(msg)
        assert "xoxp-111" not in result

    def test_openai_api_key(self) -> None:
        msg = "key: sk-proj-1234567890abcdefghijklmnop"
        result = redact(msg)
        assert "sk-proj-1234567890" not in result

    def test_anthropic_api_key(self) -> None:
        msg = "sk_ant_1234567890abcdefghijklmnop"
        result = redact(msg)
        assert "sk_ant_1234567890" not in result

    def test_generic_token_equals(self) -> None:
        msg = 'Connected with token=mysecrettoken123456'
        result = redact(msg)
        assert "mysecrettoken123456" not in result
        assert _REDACTED in result

    def test_generic_password_equals(self) -> None:
        msg = 'password=SuperSecret123!'
        result = redact(msg)
        assert "SuperSecret123!" not in result

    def test_generic_secret_colon(self) -> None:
        msg = 'secret: "my_super_secret_value_here"'
        result = redact(msg)
        assert "my_super_secret_value_here" not in result

    def test_generic_api_key(self) -> None:
        msg = "api_key=abcdef1234567890abcdef"
        result = redact(msg)
        assert "abcdef1234567890" not in result

    def test_access_token_field(self) -> None:
        msg = "access_token=eyJhbGciOiJIUzI1NiJ9.payload.sig"
        result = redact(msg)
        assert "eyJhbGciOiJIUzI1NiJ9" not in result

    def test_refresh_token_field(self) -> None:
        msg = "refresh_token=1//0abcdefghijklmnopqrstuvwxyz"
        result = redact(msg)
        assert "1//0abcdefghijklmno" not in result

    def test_multiple_secrets_in_one_message(self) -> None:
        msg = (
            "Auth: Bearer eyJhbG.eyJzdW.sig123 "
            "with ghp_aaaaaaaaaaaaaaaa and password=hunter2x"
        )
        result = redact(msg)
        assert "eyJhbG" not in result
        assert "ghp_aaaaaaaaaaaaaaaa" not in result
        assert "hunter2x" not in result

    def test_clean_message_unchanged(self) -> None:
        msg = "Processing 42 records from table decisions"
        assert redact(msg) == msg


# ---------------------------------------------------------------------------
# Formatter integration
# ---------------------------------------------------------------------------


class TestSanitizingFormatter:
    """SanitizingFormatter redacts credentials from log records."""

    def _make_record(self, msg: str) -> logging.LogRecord:
        return logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg=msg,
            args=(),
            exc_info=None,
        )

    def test_formatter_redacts_bearer(self) -> None:
        fmt = SanitizingFormatter("%(message)s")
        record = self._make_record("Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.sig")
        output = fmt.format(record)
        assert "eyJhbGciOiJIUzI1NiJ9" not in output
        assert _REDACTED in output

    def test_formatter_redacts_in_full_format(self) -> None:
        fmt = SanitizingFormatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
        record = self._make_record("token=supersecretvalue123")
        output = fmt.format(record)
        assert "supersecretvalue123" not in output
        assert _REDACTED in output


# ---------------------------------------------------------------------------
# setup_logging integration
# ---------------------------------------------------------------------------


class TestSetupLogging:
    """setup_logging configures the root logger with sanitization."""

    def test_setup_installs_sanitizing_handler(self) -> None:
        setup_logging("DEBUG")
        root = logging.getLogger()
        assert len(root.handlers) == 1
        handler = root.handlers[0]
        assert isinstance(handler.formatter, SanitizingFormatter)

    def test_setup_idempotent(self) -> None:
        setup_logging("INFO")
        setup_logging("INFO")
        root = logging.getLogger()
        assert len(root.handlers) == 1

    def test_log_output_redacted(self, capfd: pytest.CaptureFixture[str]) -> None:
        setup_logging("INFO")
        logger = logging.getLogger("test.creds")
        logger.info("Using ghp_abcdefghijklmnop1234567890")
        captured = capfd.readouterr()
        assert "ghp_abcdefghijklmnop" not in captured.err
        assert _REDACTED in captured.err
