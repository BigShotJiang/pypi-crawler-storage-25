"""Security test: SEC-06 — PKCE S256 challenge enforced on OAuth flows.

Verifies the PKCE code_verifier is cryptographically random, the S256 challenge
derivation is correct (challenge = base64url(sha256(verifier))), the challenge
is included in authorization URLs when required, and the verifier is sent
during token exchange.
"""

from __future__ import annotations

import base64
import hashlib
from unittest.mock import AsyncMock, MagicMock, patch
from urllib.parse import parse_qs, urlparse

import pytest

from backend.auth.oauth_manager import (
    OAuthManager,
    ProviderConfig,
    build_auth_url,
    generate_pkce,
)


def _mock_provider(*, pkce: bool) -> ProviderConfig:
    return ProviderConfig(
        name="mock",
        authorize_url="https://mock.example/authorize",
        token_url="https://mock.example/token",
        userinfo_url="https://mock.example/userinfo",
        scopes=["read"],
        pkce=pkce,
        client_id_env="MOCK_CLIENT_ID",
        client_secret_env="MOCK_CLIENT_SECRET",
    )


def _mock_creds() -> MagicMock:
    mgr = MagicMock()
    mgr.get.return_value = None
    return mgr


# ---------------------------------------------------------------------------
# PKCE generation correctness
# ---------------------------------------------------------------------------


class TestPkceGeneration:
    """generate_pkce() produces a correct S256 verifier/challenge pair."""

    def test_returns_tuple_of_strings(self) -> None:
        verifier, challenge = generate_pkce()
        assert isinstance(verifier, str)
        assert isinstance(challenge, str)

    def test_verifier_is_high_entropy(self) -> None:
        verifier, _ = generate_pkce()
        assert len(verifier) >= 32

    def test_challenge_is_s256_of_verifier(self) -> None:
        """Challenge must equal base64url(sha256(verifier)) with no padding."""
        verifier, challenge = generate_pkce()
        expected_digest = hashlib.sha256(verifier.encode("ascii")).digest()
        expected_challenge = (
            base64.urlsafe_b64encode(expected_digest).rstrip(b"=").decode("ascii")
        )
        assert challenge == expected_challenge

    def test_challenge_has_no_padding(self) -> None:
        _, challenge = generate_pkce()
        assert "=" not in challenge

    def test_challenge_is_urlsafe(self) -> None:
        _, challenge = generate_pkce()
        # base64url uses [A-Za-z0-9\-_]
        assert all(c.isalnum() or c in "-_" for c in challenge)

    def test_pairs_are_unique(self) -> None:
        pairs = {generate_pkce() for _ in range(100)}
        assert len(pairs) == 100

    def test_challenge_length_is_43(self) -> None:
        """SHA-256 digest is 32 bytes; base64url without padding is 43 chars."""
        _, challenge = generate_pkce()
        assert len(challenge) == 43


# ---------------------------------------------------------------------------
# Challenge in authorization URL
# ---------------------------------------------------------------------------


class TestPkceInAuthUrl:
    """Authorization URL must include challenge + method when PKCE is required."""

    def test_challenge_included_when_pkce_enabled(self) -> None:
        provider = _mock_provider(pkce=True)
        url = build_auth_url(
            provider,
            "cid",
            "http://127.0.0.1/cb",
            "state",
            code_challenge="abc123",
        )
        params = parse_qs(urlparse(url).query)
        assert params["code_challenge"] == ["abc123"]
        assert params["code_challenge_method"] == ["S256"]

    def test_challenge_omitted_when_pkce_disabled(self) -> None:
        provider = _mock_provider(pkce=False)
        url = build_auth_url(
            provider,
            "cid",
            "http://127.0.0.1/cb",
            "state",
            code_challenge="abc123",
        )
        params = parse_qs(urlparse(url).query)
        assert "code_challenge" not in params
        assert "code_challenge_method" not in params

    def test_challenge_omitted_when_none(self) -> None:
        provider = _mock_provider(pkce=True)
        url = build_auth_url(
            provider, "cid", "http://127.0.0.1/cb", "state", code_challenge=None
        )
        params = parse_qs(urlparse(url).query)
        assert "code_challenge" not in params


# ---------------------------------------------------------------------------
# PKCE verifier in token exchange
# ---------------------------------------------------------------------------


class TestPkceInTokenExchange:
    """Token exchange must include code_verifier when PKCE is enabled."""

    @pytest.mark.asyncio
    async def test_verifier_sent_to_token_endpoint(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("MOCK_CLIENT_ID", "cid")
        monkeypatch.setenv("MOCK_CLIENT_SECRET", "csecret")

        manager = OAuthManager({"mock": _mock_provider(pkce=True)}, _mock_creds())

        token_response = MagicMock()
        token_response.status_code = 200
        token_response.json.return_value = {
            "access_token": "AT",
            "refresh_token": "RT",
            "expires_in": 3600,
        }
        userinfo_response = MagicMock()
        userinfo_response.status_code = 200
        userinfo_response.json.return_value = {
            "sub": "uid",
            "email": "e@x.com",
            "name": "E",
        }

        captured_state: dict[str, str] = {}

        original_build = build_auth_url

        def capturing_build(
            provider: ProviderConfig,
            client_id: str,
            redirect_uri: str,
            state: str,
            code_challenge: str | None = None,
        ) -> str:
            captured_state["state"] = state
            captured_state["challenge"] = code_challenge or ""
            return original_build(provider, client_id, redirect_uri, state, code_challenge)

        http_post_mock = AsyncMock(return_value=token_response)

        with (
            patch("backend.auth.oauth_manager.webbrowser.open", return_value=True),
            patch(
                "backend.auth.oauth_manager.build_auth_url",
                side_effect=capturing_build,
            ),
            patch("backend.auth.oauth_manager._CallbackServer") as cb_cls,
            patch.object(OAuthManager, "_http_post", new=http_post_mock),
            patch.object(
                OAuthManager,
                "_http_get",
                new=AsyncMock(return_value=userinfo_response),
            ),
        ):
            cb = cb_cls.return_value
            cb.start.return_value = 40000
            cb.code = "authcode"
            cb.error = None

            def reflect_state() -> None:
                cb.state = captured_state["state"]

            cb.wait_for_callback = MagicMock(side_effect=reflect_state)
            await manager.browser_flow("mock")

        # Verify token exchange was called with a code_verifier
        http_post_mock.assert_called_once()
        kwargs = http_post_mock.call_args.kwargs or {}
        args = http_post_mock.call_args.args
        data = kwargs.get("data") or (args[1] if len(args) > 1 else None)
        assert data is not None
        assert "code_verifier" in data
        assert data["code_verifier"]  # non-empty
        # And the sent challenge should be base64url(sha256(verifier))
        expected = (
            base64.urlsafe_b64encode(
                hashlib.sha256(data["code_verifier"].encode("ascii")).digest()
            )
            .rstrip(b"=")
            .decode("ascii")
        )
        assert captured_state["challenge"] == expected

    @pytest.mark.asyncio
    async def test_verifier_omitted_when_pkce_disabled(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("MOCK_CLIENT_ID", "cid")
        monkeypatch.setenv("MOCK_CLIENT_SECRET", "csecret")

        manager = OAuthManager({"mock": _mock_provider(pkce=False)}, _mock_creds())

        token_response = MagicMock()
        token_response.status_code = 200
        token_response.json.return_value = {
            "access_token": "AT",
            "refresh_token": "RT",
            "expires_in": 3600,
        }
        userinfo_response = MagicMock()
        userinfo_response.status_code = 200
        userinfo_response.json.return_value = {
            "sub": "uid",
            "email": "e@x.com",
            "name": "E",
        }

        captured_state: dict[str, str] = {}

        def capturing_build(
            provider: ProviderConfig,
            client_id: str,
            redirect_uri: str,
            state: str,
            code_challenge: str | None = None,
        ) -> str:
            captured_state["state"] = state
            return "https://fake/auth"

        http_post_mock = AsyncMock(return_value=token_response)

        with (
            patch("backend.auth.oauth_manager.webbrowser.open", return_value=True),
            patch(
                "backend.auth.oauth_manager.build_auth_url",
                side_effect=capturing_build,
            ),
            patch("backend.auth.oauth_manager._CallbackServer") as cb_cls,
            patch.object(OAuthManager, "_http_post", new=http_post_mock),
            patch.object(
                OAuthManager,
                "_http_get",
                new=AsyncMock(return_value=userinfo_response),
            ),
        ):
            cb = cb_cls.return_value
            cb.start.return_value = 40000
            cb.code = "authcode"
            cb.error = None

            def reflect_state() -> None:
                cb.state = captured_state["state"]

            cb.wait_for_callback = MagicMock(side_effect=reflect_state)
            await manager.browser_flow("mock")

        http_post_mock.assert_called_once()
        kwargs = http_post_mock.call_args.kwargs or {}
        args = http_post_mock.call_args.args
        data = kwargs.get("data") or (args[1] if len(args) > 1 else None)
        assert data is not None
        assert "code_verifier" not in data
