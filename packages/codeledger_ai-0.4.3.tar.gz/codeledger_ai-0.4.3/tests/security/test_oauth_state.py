"""Security test: SEC-06 — OAuth state parameter generated and validated.

Verifies the state parameter is cryptographically random, unique per invocation,
included in the authorization URL, and rejected when mismatched on callback
(CSRF protection).
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from urllib.parse import parse_qs, urlparse

import pytest

from backend.auth.oauth_manager import (
    OAuthError,
    OAuthManager,
    ProviderConfig,
    build_auth_url,
    generate_state,
)


def _mock_provider(*, pkce: bool = True) -> ProviderConfig:
    return ProviderConfig(
        name="mock",
        authorize_url="https://mock.example/authorize",
        token_url="https://mock.example/token",
        userinfo_url="https://mock.example/userinfo",
        scopes=["read"],
        pkce=pkce,
        client_id_env="MOCK_CLIENT_ID",
        client_secret_env="MOCK_CLIENT_SECRET",
    )


def _mock_creds() -> MagicMock:
    mgr = MagicMock()
    mgr.get.return_value = None
    return mgr


# ---------------------------------------------------------------------------
# State generation
# ---------------------------------------------------------------------------


class TestStateGeneration:
    """generate_state() produces high-entropy unique values."""

    def test_state_is_string(self) -> None:
        assert isinstance(generate_state(), str)

    def test_state_has_sufficient_entropy(self) -> None:
        # token_urlsafe(32) yields 43 base64url characters
        state = generate_state()
        assert len(state) >= 32

    def test_state_values_are_unique(self) -> None:
        values = {generate_state() for _ in range(200)}
        assert len(values) == 200

    def test_state_is_urlsafe(self) -> None:
        state = generate_state()
        # token_urlsafe uses [-A-Za-z0-9_]
        assert all(c.isalnum() or c in "-_" for c in state)


# ---------------------------------------------------------------------------
# State in authorization URL
# ---------------------------------------------------------------------------


class TestStateInAuthUrl:
    """Authorization URL must always include the state parameter."""

    def test_state_included_in_url(self) -> None:
        provider = _mock_provider()
        state = "fixed-state-value"
        url = build_auth_url(provider, "cid", "http://127.0.0.1/cb", state)
        params = parse_qs(urlparse(url).query)
        assert params["state"] == [state]

    def test_state_included_even_without_pkce(self) -> None:
        provider = _mock_provider(pkce=False)
        state = "csrf-token"
        url = build_auth_url(provider, "cid", "http://127.0.0.1/cb", state)
        params = parse_qs(urlparse(url).query)
        assert params["state"] == [state]


# ---------------------------------------------------------------------------
# State validation on callback (CSRF protection)
# ---------------------------------------------------------------------------


class TestStateValidation:
    """Callback must reject requests with mismatched state (CSRF)."""

    @pytest.mark.asyncio
    async def test_mismatched_state_rejected(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("MOCK_CLIENT_ID", "cid")
        monkeypatch.setenv("MOCK_CLIENT_SECRET", "csecret")

        manager = OAuthManager({"mock": _mock_provider()}, _mock_creds())

        # Fake a callback that returns a different state than what was sent
        with patch("backend.auth.oauth_manager._CallbackServer") as cb_cls:
            cb = cb_cls.return_value
            cb.start.return_value = 40000
            cb.wait_for_callback = MagicMock()
            cb.code = "authcode"
            cb.state = "attacker-controlled-state"  # mismatched
            cb.error = None

            with (
                patch(
                    "backend.auth.oauth_manager.webbrowser.open",
                    return_value=True,
                ),
                pytest.raises(OAuthError, match="State parameter mismatch"),
            ):
                await manager.browser_flow("mock")

    @pytest.mark.asyncio
    async def test_missing_state_rejected(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("MOCK_CLIENT_ID", "cid")
        monkeypatch.setenv("MOCK_CLIENT_SECRET", "csecret")

        manager = OAuthManager({"mock": _mock_provider()}, _mock_creds())

        with patch("backend.auth.oauth_manager._CallbackServer") as cb_cls:
            cb = cb_cls.return_value
            cb.start.return_value = 40000
            cb.wait_for_callback = MagicMock()
            cb.code = "authcode"
            cb.state = None  # provider omitted state
            cb.error = None

            with (
                patch(
                    "backend.auth.oauth_manager.webbrowser.open",
                    return_value=True,
                ),
                pytest.raises(OAuthError, match="State parameter mismatch"),
            ):
                await manager.browser_flow("mock")

    @pytest.mark.asyncio
    async def test_matching_state_accepted(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("MOCK_CLIENT_ID", "cid")
        monkeypatch.setenv("MOCK_CLIENT_SECRET", "csecret")

        manager = OAuthManager({"mock": _mock_provider()}, _mock_creds())

        # Capture the state sent to build_auth_url, echo it back in the callback
        captured: dict[str, str] = {}

        def fake_build_auth_url(
            provider: ProviderConfig,
            client_id: str,
            redirect_uri: str,
            state: str,
            code_challenge: str | None = None,
        ) -> str:
            captured["state"] = state
            return "https://fake/auth"

        token_response = MagicMock()
        token_response.status_code = 200
        token_response.json.return_value = {
            "access_token": "AT",
            "refresh_token": "RT",
            "expires_in": 3600,
        }
        userinfo_response = MagicMock()
        userinfo_response.status_code = 200
        userinfo_response.json.return_value = {
            "sub": "uid",
            "email": "e@x.com",
            "name": "E",
        }

        with (
            patch(
                "backend.auth.oauth_manager.build_auth_url",
                side_effect=fake_build_auth_url,
            ),
            patch(
                "backend.auth.oauth_manager.webbrowser.open", return_value=True
            ),
            patch("backend.auth.oauth_manager._CallbackServer") as cb_cls,
            patch.object(
                OAuthManager, "_http_post", new=AsyncMock(return_value=token_response)
            ),
            patch.object(
                OAuthManager, "_http_get", new=AsyncMock(return_value=userinfo_response)
            ),
        ):
            cb = cb_cls.return_value
            cb.start.return_value = 40000
            cb.wait_for_callback = MagicMock()
            cb.code = "authcode"
            cb.error = None

            # Arrange: the server echoes back the state we just generated
            def set_state_after_wait() -> None:
                cb.state = captured["state"]

            cb.wait_for_callback.side_effect = set_state_after_wait

            user = await manager.browser_flow("mock")

        assert user.email == "e@x.com"
        # Confirm state actually came back matching
        assert captured["state"] == cb.state
