"""End-to-end decision lifecycle test for the file_watcher backend.

Covers the file-watcher variant of the Phase 3 lifecycle path:

1. Create project with no git repo, start a session, record a decision.
2. Simulate a file change event (what the file watcher emits for a save).
3. ASTChange records stamped with ``change_event_source: "file_snapshot"``.
4. ProvenanceEdge links the decision to the snapshot event.
5. Forward trace renders snapshot labels (not commit hashes).
6. Reverse trace locates the decision from the file+entity name.
7. ``verify.status`` returns ``verification_available: false``.
8. ``session.end`` behaves identically to the git backend.
"""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.ast_tracker import ASTTracker
from backend.mcp.tool_handlers import ToolHandlers
from backend.verification.conflict_detector import ConflictDetector
from backend.verification.harness import QualityHarness
from backend.verification.provenance import ProvenanceEngine
from backend.verification.verifier import Verifier

if TYPE_CHECKING:
    from pathlib import Path


_DIFF_ADD_FN = (
    "diff --git a/ng.py b/ng.py\n"
    "--- a/ng.py\n"
    "+++ b/ng.py\n"
    "@@ -0,0 +1,2 @@\n"
    "+def ng_fn(payload):\n"
    "+    return payload\n"
)


@pytest.fixture
async def handlers(tmp_path: Path) -> ToolHandlers:
    db = SQLiteBackend(tmp_path / "e2e_no_git.db")
    await db.connect()
    await apply_migrations(db)
    yield ToolHandlers(
        db=db,
        verifier=Verifier(db),
        harness=QualityHarness(db),
        conflict_detector=ConflictDetector(db),
        provenance=ProvenanceEngine(db),
        change_detection_backend="file_watcher",
    )
    await db.close()


class TestFileWatcherDecisionLifecycle:
    @pytest.mark.asyncio
    async def test_full_flow_file_snapshot(
        self, handlers: ToolHandlers
    ) -> None:
        tracker = ASTTracker(db=handlers.db)
        user_id = uuid.uuid4()

        session = await handlers.session_start(
            user_id=user_id, agent_name="claude-opus"
        )
        sid = uuid.UUID(session["id"])

        decision = await handlers.decision_create(
            user_id=user_id,
            title="Add ng_fn in ng.py",
            description="New entry in ng.py for the non-git flow.",
            session_id=sid,
        )
        did = uuid.UUID(decision["id"])

        # File watcher emits process_change_event with file_snapshot.
        snapshot_id = "snap-ng-1"
        result = await tracker.process_change_event(
            change_event_id=snapshot_id,
            change_event_source="file_snapshot",
            diff_text=_DIFF_ADD_FN,
            project_id="default",
            active_session_id=str(sid),
        )
        assert "ng_fn" in result["linked_changes"]

        ast_rows = await handlers.db.query(
            "ast_changes", where={"change_event_id": snapshot_id}
        )
        assert ast_rows
        assert all(
            r["change_event_source"] == "file_snapshot" for r in ast_rows
        )

        # Forward trace renders snapshot label.
        tree = await handlers.provenance_forward(
            user_id=user_id, decision_id=did
        )
        assert len(tree["change_events"]) == 1
        event = tree["change_events"][0]
        assert event["change_event_source"] == "file_snapshot"
        assert event["label"].startswith("Snapshot ")
        assert "ng.py" in event["label"]

        # Reverse trace handles file_snapshot event types.
        reverse = await handlers.provenance_reverse(
            user_id=user_id, file_path="ng.py", entity_name="ng_fn"
        )
        assert reverse["results"]
        assert all(
            r["change_event_source"] == "file_snapshot"
            for r in reverse["results"]
        )

        # verify.status returns the file-watcher advisory.
        status = await handlers.verify_status(
            user_id=user_id, decision_id=did
        )
        assert status["verification_available"] is False
        assert status["change_detection_backend"] == "file_watcher"

        # verify.list_unverified short-circuits similarly.
        unverified = await handlers.verify_list_unverified(user_id=user_id)
        assert unverified["verification_available"] is False

        # session.end behaves identically to git mode.
        ended = await handlers.session_end(
            user_id=user_id, session_id=sid
        )
        assert ended["status"] == "completed"

    @pytest.mark.asyncio
    async def test_unlinked_file_change_recorded_without_session(
        self, handlers: ToolHandlers
    ) -> None:
        tracker = ASTTracker(db=handlers.db)
        await tracker.process_change_event(
            change_event_id="snap-orphan",
            change_event_source="file_snapshot",
            diff_text=_DIFF_ADD_FN,
            project_id="default",
        )
        orphans = await handlers.db.query(
            "unlinked_file_changes", where={"snapshot_id": "snap-orphan"}
        )
        assert orphans
        assert any(
            "ng_fn" in str(o["structurally_changed_symbols"]) for o in orphans
        )
