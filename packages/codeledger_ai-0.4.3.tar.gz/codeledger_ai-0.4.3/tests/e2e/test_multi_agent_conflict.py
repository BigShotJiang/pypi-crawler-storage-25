"""End-to-end multi-agent conflict flow.

Covers the conflict lifecycle expected in Phase 3:

1. Two sessions register with overlapping files → conflict detected.
2. Removing the overlap clears the conflict.
3. Ending a session removes it from the active set.
"""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.mcp.tool_handlers import ToolHandlers
from backend.verification.conflict_detector import ConflictDetector

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
async def handlers(tmp_path: Path) -> ToolHandlers:
    db = SQLiteBackend(tmp_path / "multi_agent.db")
    await db.connect()
    await apply_migrations(db)
    yield ToolHandlers(db=db, conflict_detector=ConflictDetector(db))
    await db.close()


class TestMultiAgentConflict:
    @pytest.mark.asyncio
    async def test_conflict_then_clear(self, handlers: ToolHandlers) -> None:
        user_a = uuid.uuid4()
        user_b = uuid.uuid4()

        # Two sessions opened concurrently.
        session_a = await handlers.session_start(
            user_id=user_a, agent_name="claude"
        )
        session_b = await handlers.session_start(
            user_id=user_b, agent_name="cursor"
        )
        sa = uuid.UUID(session_a["id"])
        sb = uuid.UUID(session_b["id"])

        assert handlers.conflict_detector is not None
        handlers.conflict_detector.update_session_files(str(sa), ["shared.py"])
        handlers.conflict_detector.update_session_files(str(sb), ["shared.py", "b.py"])

        conflicts_a = await handlers.session_conflicts(
            user_id=user_a, session_id=sa
        )
        assert conflicts_a["conflicts"]
        assert conflicts_a["conflicts"][0]["conflicting_session_id"] == str(sb)

        # Remove overlap — A moves off shared.py.
        handlers.conflict_detector.update_session_files(str(sa), ["a_only.py"])
        conflicts_a = await handlers.session_conflicts(
            user_id=user_a, session_id=sa
        )
        assert conflicts_a["conflicts"] == []

        # End session B — it disappears from the active list.
        await handlers.session_end(user_id=user_b, session_id=sb)
        active = handlers.conflict_detector.get_active_sessions("default")
        assert all(a["session_id"] != str(sb) for a in active)
