"""Default connector registration — shared by HTTP/MCP and CLI entry points.

Keeping the "which connectors ship in the box" decision in one place means
the dashboard, the MCP surface, and the ``codeledger connectors list`` CLI
never drift out of sync.

Error handling follows the A-1 §1.8 risk-#5 mitigation:

- ``ImportError`` at module import = the connector module itself is broken
  → log at WARNING (it is a bug in our own tree, not a user-install issue).
- ``RuntimeError`` at instantiation = the optional driver extra (``aiomysql``,
  ``motor``, …) is not installed → log at INFO and skip (expected).
- Any other ``Exception`` at instantiation = unexpected config bug →
  log at WARNING so it is visible instead of being silently swallowed.
"""

from __future__ import annotations

import importlib
import logging
from typing import TYPE_CHECKING

from backend.connectors.registry import ConnectorRegistry

if TYPE_CHECKING:
    from backend.auth.credential_manager import CredentialManager
    from backend.connectors.oauth_token_manager import OAuthTokenManager
    from backend.db.db_backend import DatabaseBackend

logger = logging.getLogger(__name__)


# ``(module_path, class_name)`` pairs. External connectors only need httpx
# (always a core dep); database connectors may RuntimeError on construction
# if their optional driver isn't installed.
_EXTERNAL_CONNECTORS: tuple[tuple[str, str], ...] = (
    ("backend.connectors.external.gmail", "GmailConnector"),
    ("backend.connectors.external.drive", "DriveConnector"),
    ("backend.connectors.external.gcal", "CalendarConnector"),
    ("backend.connectors.external.slack", "SlackConnector"),
    ("backend.connectors.external.jira", "JiraConnector"),
    ("backend.connectors.external.confluence", "ConfluenceConnector"),
    ("backend.connectors.external.linear", "LinearConnector"),
    ("backend.connectors.external.notion", "NotionConnector"),
    ("backend.connectors.external.github_issues", "GitHubIssuesConnector"),
    ("backend.connectors.external.asana", "AsanaConnector"),
    ("backend.connectors.external.teams", "TeamsConnector"),
    ("backend.connectors.external.outlook", "OutlookConnector"),
)

_DATABASE_CONNECTORS: tuple[tuple[str, str], ...] = (
    ("backend.connectors.databases.postgresql", "PostgreSQLConnector"),
    ("backend.connectors.databases.timescaledb", "TimescaleDBConnector"),
    ("backend.connectors.databases.mysql", "MySQLConnector"),
    ("backend.connectors.databases.mongodb", "MongoDBConnector"),
    ("backend.connectors.databases.redis_connector", "RedisConnector"),
    (
        "backend.connectors.databases.elasticsearch_connector",
        "ElasticsearchConnector",
    ),
    ("backend.connectors.databases.influxdb2", "InfluxDB2Connector"),
    ("backend.connectors.databases.influxdb3", "InfluxDB3Connector"),
    ("backend.connectors.databases.dynamodb", "DynamoDBConnector"),
    (
        "backend.connectors.databases.databricks_connector",
        "DatabricksConnector",
    ),
    (
        "backend.connectors.databases.snowflake_connector",
        "SnowflakeConnector",
    ),
    ("backend.connectors.databases.bigquery_connector", "BigQueryConnector"),
    (
        "backend.connectors.databases.clickhouse_connector",
        "ClickHouseConnector",
    ),
    ("backend.connectors.databases.cassandra_connector", "CassandraConnector"),
)


def build_default_registry(
    credential_manager: CredentialManager,
    *,
    db: DatabaseBackend | None = None,
    oauth_token_manager: OAuthTokenManager | None = None,
) -> ConnectorRegistry:
    """Return a ``ConnectorRegistry`` populated with the shipped connectors.

    External connectors are always registered — they ride on httpx which is
    a core dependency. Database connectors are registered only when their
    optional driver is installed; missing drivers are logged at INFO and
    silently skipped, config bugs are logged at WARNING.
    """
    registry = ConnectorRegistry()

    for module_path, class_name in _EXTERNAL_CONNECTORS:
        _register_external(
            registry,
            module_path,
            class_name,
            credential_manager=credential_manager,
            db=db,
            oauth_token_manager=oauth_token_manager,
        )

    for module_path, class_name in _DATABASE_CONNECTORS:
        _register_database(
            registry,
            module_path,
            class_name,
            credential_manager=credential_manager,
            db=db,
        )

    return registry


def _register_external(
    registry: ConnectorRegistry,
    module_path: str,
    class_name: str,
    *,
    credential_manager: CredentialManager,
    db: DatabaseBackend | None,
    oauth_token_manager: OAuthTokenManager | None,
) -> None:
    try:
        module = importlib.import_module(module_path)
    except ImportError:
        logger.warning(
            "[bootstrap] external connector module missing: %s", module_path,
            exc_info=True,
        )
        return
    cls = getattr(module, class_name, None)
    if cls is None:
        logger.warning(
            "[bootstrap] %s does not expose %s", module_path, class_name
        )
        return
    try:
        registry.register(
            cls(
                credential_manager,
                db=db,
                oauth_token_manager=oauth_token_manager,
            )
        )
    except Exception:
        logger.warning(
            "[bootstrap] failed to register %s", class_name, exc_info=True
        )


def _register_database(
    registry: ConnectorRegistry,
    module_path: str,
    class_name: str,
    *,
    credential_manager: CredentialManager,
    db: DatabaseBackend | None,
) -> None:
    try:
        module = importlib.import_module(module_path)
    except ImportError:
        logger.warning(
            "[bootstrap] database connector module missing: %s", module_path,
            exc_info=True,
        )
        return
    cls = getattr(module, class_name, None)
    if cls is None:
        logger.warning(
            "[bootstrap] %s does not expose %s", module_path, class_name
        )
        return
    try:
        registry.register(cls(credential_manager, db=db))
    except RuntimeError as exc:
        # Optional driver not installed — require_driver fired in __init__.
        logger.info(
            "[bootstrap] %s not registered — %s", class_name, exc
        )
    except Exception:
        logger.warning(
            "[bootstrap] failed to register %s", class_name, exc_info=True
        )
