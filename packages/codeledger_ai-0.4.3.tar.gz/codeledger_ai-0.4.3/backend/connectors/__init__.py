"""CodeLedger connector framework.

External-tool and database connectors that expose third-party systems to
AI agents via the MCP surface. Submodules:

- ``base``: ``AbstractConnector`` interface + shared dataclasses/enums.
- (future) ``registry``: parallel search + health-check registry.
- (future) ``oauth_token_manager``: connector-scoped OAuth token refresh.
- (future) ``external/``, ``databases/``: concrete connector implementations.
"""
