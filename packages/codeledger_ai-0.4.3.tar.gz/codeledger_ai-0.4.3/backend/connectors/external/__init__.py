"""External tool connectors (REST / GraphQL third-party APIs).

Every connector here subclasses
:class:`backend.connectors.external._base.ExternalConnector` — never
``AbstractConnector`` directly — so each gets bearer-auth, HTTP fetch
helpers, and a default health probe for free.
"""
