"""Outlook connector — link emails to decisions.

Uses Microsoft Graph ``/me/messages`` with ``$search`` for full-text
query. Only subject, sender, received timestamp, and the Graph-provided
``bodyPreview`` are surfaced; the message body HTML is never returned.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorResult,
)
from backend.connectors.external._base import ExternalConnector
from backend.connectors.external._microsoft import (
    GRAPH_API_V1,
    microsoft_oauth_config,
)

if TYPE_CHECKING:
    from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

_OUTLOOK_SCOPES: list[str] = [
    "https://graph.microsoft.com/Mail.Read",
    "offline_access",
]

_MAIL_FIELDS = "subject,from,receivedDateTime,bodyPreview,webLink"


class OutlookConnector(ExternalConnector):
    slug = "outlook"
    display_name = "Outlook"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.COMMUNICATION
    oauth_scopes: ClassVar[list[str]] = _OUTLOOK_SCOPES
    description = "Search Outlook emails and link threads to decisions"
    health_probe_url: ClassVar[str | None] = f"{GRAPH_API_V1}/me"

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = microsoft_oauth_config(
        "outlook", _OUTLOOK_SCOPES
    )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        # $search requires a double-quoted argument per the Graph spec.
        escaped = query.replace('"', r"\"")
        resp = await self._http_get(
            f"{GRAPH_API_V1}/me/messages",
            params={
                "$search": f'"{escaped}"',
                "$top": max_results,
                "$select": _MAIL_FIELDS,
            },
        )
        if resp is None or resp.status_code != 200:
            return []
        try:
            data = resp.json()
        except ValueError:
            return []
        items = data.get("value") or []
        if not isinstance(items, list):
            return []
        return [
            _message_to_result(m)
            for m in items
            if isinstance(m, dict) and m.get("id")
        ]

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        if not item_id or "/" in item_id or ".." in item_id:
            return None
        resp = await self._http_get(
            f"{GRAPH_API_V1}/me/messages/{item_id}",
            params={"$select": _MAIL_FIELDS},
        )
        if resp is None or resp.status_code != 200:
            return None
        try:
            data = resp.json()
        except ValueError:
            return None
        if not data.get("id"):
            return None
        return _message_to_result(data)


def _message_to_result(data: dict[str, Any]) -> ConnectorResult:
    message_id = str(data.get("id") or "")
    subject = str(data.get("subject") or "(no subject)")
    sender_name, sender_addr = _sender(data.get("from"))
    received = str(data.get("receivedDateTime") or "")
    preview = str(data.get("bodyPreview") or "")
    url = str(data.get("webLink") or "") or None

    sender_display = sender_name or sender_addr
    summary = (
        f"From: {sender_display} — {preview}"
        if preview
        else f"From: {sender_display}"
    ) if sender_display else preview

    return ConnectorResult(
        item_id=message_id,
        title=subject,
        summary=summary,
        url=url,
        connector_slug="outlook",
        item_type="email",
        metadata={
            "sender_name": sender_name,
            "sender_address": sender_addr,
            "received": received,
        },
    )


def _sender(from_field: Any) -> tuple[str, str]:
    if not isinstance(from_field, dict):
        return "", ""
    email = from_field.get("emailAddress") or {}
    if not isinstance(email, dict):
        return "", ""
    name = str(email.get("name") or "")
    addr = str(email.get("address") or "")
    return name, addr
