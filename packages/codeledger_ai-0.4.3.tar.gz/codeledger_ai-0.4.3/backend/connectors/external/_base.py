"""Shared base for HTTP-backed external tool connectors.

``ExternalConnector`` extends :class:`AbstractConnector` with:

- Automatic bearer-token resolution — OAuth connectors fetch a fresh access
  token via :class:`OAuthTokenManager`; API-key connectors use the stored
  ``api_key`` credential.
- ``_http_get`` / ``_http_post`` helpers that return ``None`` on any HTTP
  error so callers can short-circuit with a single ``if resp is None``
  guard. Per-request timeout is 10 s.
- A default ``health()`` implementation that probes
  ``health_probe_url`` (a class attribute on concrete subclasses).

Security invariants:
- SEC-02: only the URL path (no query string) is logged — query strings
  may carry tokens, message IDs, or user email addresses.
- SEC-03: helpers never return credentials in the ``ConnectorResult``
  payload they bubble up; that's the caller's job.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, ClassVar

import httpx

from backend.connectors.base import (
    AbstractConnector,
    AuthType,
    ConnectorHealth,
    ConnectorStatus,
)

if TYPE_CHECKING:
    from backend.auth.credential_manager import CredentialManager
    from backend.connectors.oauth_token_manager import (
        ConnectorOAuthConfig,
        OAuthTokenManager,
    )
    from backend.db.db_backend import DatabaseBackend

logger = logging.getLogger(__name__)

_HTTP_TIMEOUT_SECONDS = 10.0


class ExternalConnector(AbstractConnector):
    """HTTP-backed base for third-party API connectors."""

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = None
    """Required for ``auth_type == OAUTH2``; left ``None`` for API-key connectors."""

    health_probe_url: ClassVar[str | None] = None
    """Optional probe endpoint used by the default ``health()`` implementation."""

    def __init__(
        self,
        credential_manager: CredentialManager,
        db: DatabaseBackend | None = None,
        *,
        oauth_token_manager: OAuthTokenManager | None = None,
    ) -> None:
        super().__init__(credential_manager, db)
        self._otm = oauth_token_manager

    # ------------------------------------------------------------------ #
    # Bearer-token resolution                                            #
    # ------------------------------------------------------------------ #

    async def _bearer_token(self) -> str | None:
        """Return a valid bearer token or ``None`` if unconfigured."""
        if self.auth_type == AuthType.OAUTH2:
            if self._otm is not None and self.oauth_config is not None:
                return await self._otm.get_valid_token(self.oauth_config)
            return self._get_credential("access_token")
        if self.auth_type == AuthType.API_KEY:
            return self._get_credential("api_key")
        return None

    # ------------------------------------------------------------------ #
    # HTTP fetch helpers                                                 #
    # ------------------------------------------------------------------ #

    async def _http_get(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        headers_extra: dict[str, str] | None = None,
    ) -> httpx.Response | None:
        token = await self._bearer_token()
        if not token:
            return None
        headers = _auth_headers(token, headers_extra)
        try:
            async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT_SECONDS) as client:
                return await client.get(url, params=params, headers=headers)
        except httpx.HTTPError:
            logger.warning(
                "[%s] GET %s failed", self.slug, _redact(url), exc_info=True
            )
            return None

    async def _http_post(
        self,
        url: str,
        *,
        json: Any = None,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers_extra: dict[str, str] | None = None,
    ) -> httpx.Response | None:
        token = await self._bearer_token()
        if not token:
            return None
        headers = _auth_headers(token, headers_extra)
        try:
            async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT_SECONDS) as client:
                return await client.post(
                    url,
                    json=json,
                    data=data,
                    params=params,
                    headers=headers,
                )
        except httpx.HTTPError:
            logger.warning(
                "[%s] POST %s failed", self.slug, _redact(url), exc_info=True
            )
            return None

    # ------------------------------------------------------------------ #
    # Default health probe                                               #
    # ------------------------------------------------------------------ #

    async def health(self) -> ConnectorHealth:
        if not self.is_configured():
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.NOT_CONFIGURED,
                message="connector not configured",
                configured=False,
            )
        if self.health_probe_url is None:
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.DEGRADED,
                message="no health probe configured",
                configured=True,
            )
        return await self._probe_health(self.health_probe_url)

    async def _probe_health(self, probe_url: str) -> ConnectorHealth:
        """Probe ``probe_url`` and map the HTTP status to a health record.

        Exposed so subclasses whose probe URL depends on runtime state
        (e.g. Atlassian connectors needing a resolved ``cloud_id``) can
        reuse the same mapping without duplicating it.
        """
        resp = await self._http_get(probe_url)
        if resp is None:
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.ERROR,
                message="network error",
                configured=True,
            )
        if resp.status_code == 200:
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.CONNECTED,
                message="ok",
                configured=True,
            )
        if resp.status_code in (401, 403):
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.AUTH_EXPIRED,
                message=f"auth rejected ({resp.status_code})",
                configured=True,
            )
        return ConnectorHealth(
            slug=self.slug,
            status=ConnectorStatus.ERROR,
            message=f"probe returned {resp.status_code}",
            configured=True,
        )


# ---------------------------------------------------------------------- #
# Internal helpers                                                       #
# ---------------------------------------------------------------------- #


def _auth_headers(
    token: str, extra: dict[str, str] | None
) -> dict[str, str]:
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
    if extra:
        headers.update(extra)
    return headers


def _redact(url: str) -> str:
    """Strip any query string before logging a URL — it may carry tokens/PII."""
    idx = url.find("?")
    return url[:idx] if idx >= 0 else url
