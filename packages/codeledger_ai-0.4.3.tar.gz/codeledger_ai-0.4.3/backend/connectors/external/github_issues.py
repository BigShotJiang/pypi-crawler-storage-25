"""GitHub Issues connector — link issues and PRs to decisions.

Uses the GitHub REST API v3 (``api.github.com``). GitHub treats issues
and pull requests as the same underlying resource for search purposes,
so this connector covers both.

Item IDs use the human-friendly ``{owner}/{repo}#{number}`` form so
``get_item`` can round-trip without having to store per-row state.
GitHub's API requires a ``User-Agent`` header on every request.
"""

from __future__ import annotations

from typing import Any, ClassVar

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorResult,
)
from backend.connectors.external._base import ExternalConnector
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

_GH_SCOPES: list[str] = ["repo", "read:user"]

_GH_HEADERS = {
    "Accept": "application/vnd.github+json",
    "User-Agent": "CodeLedger",
    "X-GitHub-Api-Version": "2022-11-28",
}


class GitHubIssuesConnector(ExternalConnector):
    slug = "github_issues"
    display_name = "GitHub Issues"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.PROJECT_MANAGEMENT
    oauth_scopes: ClassVar[list[str]] = _GH_SCOPES
    description = "Link GitHub issues and pull requests to decisions"
    health_probe_url: ClassVar[str | None] = "https://api.github.com/user"

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = ConnectorOAuthConfig(
        slug="github_issues",
        authorize_url="https://github.com/login/oauth/authorize",
        token_url="https://github.com/login/oauth/access_token",
        scopes=_GH_SCOPES,
        pkce=True,
        client_id_env="CODELEDGER_GITHUB_CLIENT_ID",
        client_secret_env="CODELEDGER_GITHUB_CLIENT_SECRET",
    )

    async def health(self):  # type: ignore[no-untyped-def]
        # Override only to inject the GitHub-specific User-Agent header on the
        # probe call; the status-mapping logic comes from _probe_health.
        from backend.connectors.base import ConnectorHealth, ConnectorStatus

        if not self.is_configured():
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.NOT_CONFIGURED,
                message="connector not configured",
                configured=False,
            )
        resp = await self._http_get(
            "https://api.github.com/user", headers_extra=_GH_HEADERS
        )
        if resp is None:
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.ERROR,
                message="network error",
                configured=True,
            )
        if resp.status_code == 200:
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.CONNECTED,
                message="ok",
                configured=True,
            )
        if resp.status_code in (401, 403):
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.AUTH_EXPIRED,
                message=f"auth rejected ({resp.status_code})",
                configured=True,
            )
        return ConnectorHealth(
            slug=self.slug,
            status=ConnectorStatus.ERROR,
            message=f"probe returned {resp.status_code}",
            configured=True,
        )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        resp = await self._http_get(
            "https://api.github.com/search/issues",
            params={"q": query, "per_page": max_results},
            headers_extra=_GH_HEADERS,
        )
        if resp is None or resp.status_code != 200:
            return []
        try:
            data = resp.json()
        except ValueError:
            return []
        items = data.get("items") or []
        if not isinstance(items, list):
            return []
        return [
            _issue_to_result(i)
            for i in items
            if isinstance(i, dict) and i.get("number") is not None
        ]

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        parsed = _parse_issue_ref(item_id)
        if parsed is None:
            return None
        owner, repo, number = parsed
        resp = await self._http_get(
            f"https://api.github.com/repos/{owner}/{repo}/issues/{number}",
            headers_extra=_GH_HEADERS,
        )
        if resp is None or resp.status_code != 200:
            return None
        try:
            data = resp.json()
        except ValueError:
            return None
        if data.get("number") is None:
            return None
        return _issue_to_result(data)


def _parse_issue_ref(ref: str) -> tuple[str, str, int] | None:
    """Parse ``owner/repo#number`` → ``(owner, repo, number)``.

    Rejects path-traversal tokens and non-numeric issue numbers.
    """
    if not ref or "#" not in ref:
        return None
    path_part, _, num_part = ref.partition("#")
    if "/" not in path_part:
        return None
    owner, _, repo = path_part.partition("/")
    if not owner or not repo or ".." in owner or ".." in repo:
        return None
    if "/" in owner or "/" in repo:
        return None
    try:
        number = int(num_part)
    except ValueError:
        return None
    if number <= 0:
        return None
    return owner, repo, number


def _issue_to_result(data: dict[str, Any]) -> ConnectorResult:
    number = int(data.get("number") or 0)
    title = str(data.get("title") or "")
    state = str(data.get("state") or "")
    html_url = str(data.get("html_url") or "")
    labels_raw = data.get("labels") or []
    labels: list[str] = []
    if isinstance(labels_raw, list):
        for label in labels_raw:
            if isinstance(label, dict):
                name = label.get("name")
                if isinstance(name, str):
                    labels.append(name)
    owner, repo = _owner_repo_from_url(
        str(data.get("repository_url") or html_url)
    )
    item_id = f"{owner}/{repo}#{number}" if owner and repo else str(number)
    summary_parts: list[str] = []
    if state:
        summary_parts.append(f"state={state}")
    if labels:
        summary_parts.append(f"labels={','.join(labels)}")
    return ConnectorResult(
        item_id=item_id,
        title=f"#{number}: {title}" if title else f"#{number}",
        summary=" ".join(summary_parts),
        url=html_url or None,
        connector_slug="github_issues",
        item_type="issue",
        metadata={
            "state": state,
            "labels": labels,
            "owner": owner,
            "repo": repo,
        },
    )


def _owner_repo_from_url(url: str) -> tuple[str, str]:
    """Extract ``(owner, repo)`` from either API or HTML GitHub URLs."""
    if not url:
        return "", ""
    # API: https://api.github.com/repos/{owner}/{repo}
    # HTML: https://github.com/{owner}/{repo}/issues/{n}
    parts = url.rstrip("/").split("/")
    if "repos" in parts:
        idx = parts.index("repos")
        if idx + 2 < len(parts):
            return parts[idx + 1], parts[idx + 2]
    # HTML form: owner and repo are at positions 3 and 4 when scheme://host is 0..2
    if len(parts) >= 5 and parts[2].endswith("github.com"):
        return parts[3], parts[4]
    return "", ""
