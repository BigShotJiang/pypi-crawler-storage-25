"""Shared base for Atlassian OAuth connectors (Jira, Confluence).

Atlassian OAuth 2.0 access tokens are workspace-scoped: the bearer token
alone is not enough to call the Jira or Confluence REST APIs — the
workspace ``cloud_id`` must be spliced into every API path:

    https://api.atlassian.com/ex/jira/{cloud_id}/rest/api/3/...
    https://api.atlassian.com/ex/confluence/{cloud_id}/wiki/rest/api/...

The ``cloud_id`` is discovered by calling ``/oauth/token/accessible-resources``
after the OAuth callback. Browser URLs additionally need the workspace's
human-readable ``url`` (``https://mysite.atlassian.net``). Both values are
cached in the vault under the connector slug.

Security invariant: ``cloud_id`` is treated like a credential — it's a
tenant identifier — and stored in the vault, not the SQL database.
"""

from __future__ import annotations

import logging
from typing import Any

from backend.connectors.external._base import ExternalConnector

logger = logging.getLogger(__name__)


ACCESSIBLE_RESOURCES_URL = "https://api.atlassian.com/oauth/token/accessible-resources"


class AtlassianConnector(ExternalConnector):
    """Base for connectors that target the api.atlassian.com proxy.

    Subclasses only need to set the standard ``ExternalConnector`` class
    attributes (``slug``, ``oauth_config``, etc.) and implement ``search`` /
    ``get_item`` / ``health`` using :meth:`_site_info` to locate the target
    workspace.
    """

    async def _site_info(self) -> tuple[str, str] | None:
        """Return ``(cloud_id, site_url)`` for the workspace this token grants.

        Reads from the vault when cached; otherwise calls
        ``/oauth/token/accessible-resources`` and caches the first workspace
        returned. Returns ``None`` on network/auth failure.
        """
        cached_cid = self._get_credential("cloud_id")
        cached_url = self._get_credential("site_url")
        if cached_cid and cached_url:
            return cached_cid, cached_url

        resp = await self._http_get(ACCESSIBLE_RESOURCES_URL)
        if resp is None or resp.status_code != 200:
            logger.info(
                "[%s] accessible-resources lookup failed (status=%s)",
                self.slug,
                None if resp is None else resp.status_code,
            )
            return None
        try:
            data: Any = resp.json()
        except ValueError:
            return None
        if not isinstance(data, list) or not data:
            return None

        first = data[0]
        if not isinstance(first, dict):
            return None
        cid = first.get("id")
        url = first.get("url")
        if not (isinstance(cid, str) and cid and isinstance(url, str) and url):
            return None

        # Normalize site URL — strip trailing slash so downstream concatenation
        # doesn't produce "…atlassian.net//browse/…".
        url = url.rstrip("/")

        self._set_credential("cloud_id", cid)
        self._set_credential("site_url", url)
        return cid, url
