"""Notion connector — search pages and databases.

Notion's OAuth access tokens are workspace-scoped and do not expire, so
no refresh flow is exercised here. Every request must carry the
``Notion-Version`` header; the search endpoint returns both pages and
databases and this connector exposes both as :class:`ConnectorResult`
records with distinct ``item_type`` values.
"""

from __future__ import annotations

from typing import Any, ClassVar

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorResult,
)
from backend.connectors.external._base import ExternalConnector
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

# Notion's OAuth grant is workspace-level; scope strings aren't used.
_NOTION_SCOPES: list[str] = []
_NOTION_VERSION_HEADER = {"Notion-Version": "2022-06-28"}


class NotionConnector(ExternalConnector):
    slug = "notion"
    display_name = "Notion"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.CLOUD_STORAGE
    oauth_scopes: ClassVar[list[str]] = _NOTION_SCOPES
    description = "Search Notion pages and databases"
    health_probe_url: ClassVar[str | None] = "https://api.notion.com/v1/users/me"

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = ConnectorOAuthConfig(
        slug="notion",
        authorize_url="https://api.notion.com/v1/oauth/authorize",
        token_url="https://api.notion.com/v1/oauth/token",
        scopes=_NOTION_SCOPES,
        pkce=False,
        client_id_env="CODELEDGER_NOTION_CLIENT_ID",
        client_secret_env="CODELEDGER_NOTION_CLIENT_SECRET",
    )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        resp = await self._http_post(
            "https://api.notion.com/v1/search",
            json={"query": query, "page_size": max_results},
            headers_extra=_NOTION_VERSION_HEADER,
        )
        if resp is None or resp.status_code != 200:
            return []
        try:
            data = resp.json()
        except ValueError:
            return []
        results = data.get("results") or []
        if not isinstance(results, list):
            return []
        return [
            _entry_to_result(e)
            for e in results
            if isinstance(e, dict) and e.get("id")
        ]

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        if not item_id or "/" in item_id or ".." in item_id:
            return None
        # Try page first; fall back to database. Notion's page/db URLs are
        # symmetric but require knowing which kind of object it is.
        for endpoint in ("pages", "databases"):
            resp = await self._http_get(
                f"https://api.notion.com/v1/{endpoint}/{item_id}",
                headers_extra=_NOTION_VERSION_HEADER,
            )
            if resp is None:
                return None
            if resp.status_code == 200:
                try:
                    data = resp.json()
                except ValueError:
                    return None
                if data.get("id"):
                    return _entry_to_result(data)
        return None


def _entry_to_result(entry: dict[str, Any]) -> ConnectorResult:
    object_type = str(entry.get("object") or "")
    entry_id = str(entry.get("id") or "")
    title = _title_from_entry(entry)
    url = str(entry.get("url") or "")
    last_edited = str(entry.get("last_edited_time") or "")
    item_type = "page" if object_type == "page" else (
        "database" if object_type == "database" else object_type or "page"
    )
    summary = f"last_edited={last_edited}" if last_edited else ""
    return ConnectorResult(
        item_id=entry_id,
        title=title or "(untitled)",
        summary=summary,
        url=url or None,
        connector_slug="notion",
        item_type=item_type,
        metadata={"object": object_type, "last_edited": last_edited},
    )


def _title_from_entry(entry: dict[str, Any]) -> str:
    """Extract a plain-text title from a Notion page/database record."""
    # Notion's title is buried in one of two shapes:
    #   page:     properties.{Name|Title}.title[*].plain_text
    #   database: title[*].plain_text
    direct = entry.get("title")
    text = _title_rich_text(direct)
    if text:
        return text

    props = entry.get("properties")
    if isinstance(props, dict):
        for prop_value in props.values():
            if not isinstance(prop_value, dict):
                continue
            if prop_value.get("type") == "title":
                text = _title_rich_text(prop_value.get("title"))
                if text:
                    return text
    return ""


def _title_rich_text(value: Any) -> str:
    if not isinstance(value, list):
        return ""
    parts: list[str] = []
    for seg in value:
        if isinstance(seg, dict):
            text = seg.get("plain_text")
            if isinstance(text, str):
                parts.append(text)
    return "".join(parts)
