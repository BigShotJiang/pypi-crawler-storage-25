"""Google Drive connector — search files, link design docs to decisions.

Uses Drive v3 REST API. Only file metadata is returned to callers —
never file contents.
"""

from __future__ import annotations

from typing import Any, ClassVar

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorResult,
)
from backend.connectors.external._base import ExternalConnector
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

_DRIVE_SCOPES: list[str] = [
    "https://www.googleapis.com/auth/drive.readonly",
]

_API_ROOT = "https://www.googleapis.com/drive/v3"
_FIELDS = "files(id,name,webViewLink,modifiedTime,mimeType,owners(emailAddress))"


class DriveConnector(ExternalConnector):
    slug = "drive"
    display_name = "Google Drive"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.CLOUD_STORAGE
    oauth_scopes: ClassVar[list[str]] = _DRIVE_SCOPES
    description = "Search documents and link design docs to decisions"
    health_probe_url: ClassVar[str | None] = f"{_API_ROOT}/about?fields=user"

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = ConnectorOAuthConfig(
        slug="drive",
        authorize_url="https://accounts.google.com/o/oauth2/v2/auth",
        token_url="https://oauth2.googleapis.com/token",
        scopes=_DRIVE_SCOPES,
        pkce=True,
        client_id_env="CODELEDGER_GOOGLE_CLIENT_ID",
        client_secret_env="CODELEDGER_GOOGLE_CLIENT_SECRET",
        extra_authorize_params={"access_type": "offline", "prompt": "consent"},
    )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        # Escape single quotes in the user query per Drive v3 query syntax
        safe_query = query.replace("'", r"\'")
        resp = await self._http_get(
            f"{_API_ROOT}/files",
            params={
                "q": f"fullText contains '{safe_query}' and trashed=false",
                "pageSize": max_results,
                "fields": _FIELDS,
                "orderBy": "modifiedTime desc",
            },
        )
        if resp is None or resp.status_code != 200:
            return []
        try:
            data = resp.json()
        except ValueError:
            return []
        files = data.get("files") or []
        return [_file_to_result(f) for f in files if isinstance(f, dict) and f.get("id")]

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        if not item_id or "/" in item_id or ".." in item_id:
            return None
        resp = await self._http_get(
            f"{_API_ROOT}/files/{item_id}",
            params={
                "fields": "id,name,webViewLink,modifiedTime,mimeType,owners(emailAddress)",
            },
        )
        if resp is None or resp.status_code != 200:
            return None
        try:
            data = resp.json()
        except ValueError:
            return None
        if not data.get("id"):
            return None
        return _file_to_result(data)


def _file_to_result(data: dict[str, Any]) -> ConnectorResult:
    file_id = str(data.get("id", ""))
    name = str(data.get("name") or "(untitled)")
    url = str(data.get("webViewLink") or f"https://drive.google.com/file/d/{file_id}")
    modified = str(data.get("modifiedTime") or "")
    mime_type = str(data.get("mimeType") or "")
    summary = f"{mime_type}" + (f" — modified {modified}" if modified else "")
    return ConnectorResult(
        item_id=file_id,
        title=name,
        summary=summary,
        url=url,
        connector_slug="drive",
        item_type="file",
        metadata={"mime_type": mime_type, "modified_time": modified},
    )
