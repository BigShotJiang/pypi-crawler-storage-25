"""Jira connector — link tickets to decisions and code changes.

Uses the Atlassian cloud REST v3 API via the api.atlassian.com proxy.
Search uses the ``issue/picker`` endpoint for low-latency prefix matching;
``get_item`` fetches the full issue.

Every API path requires the workspace ``cloud_id`` resolved lazily by
:meth:`AtlassianConnector._site_info`; browser URLs use the workspace's
site URL (``https://mysite.atlassian.net``).
"""

from __future__ import annotations

from typing import Any, ClassVar

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorHealth,
    ConnectorResult,
    ConnectorStatus,
)
from backend.connectors.external._atlassian import AtlassianConnector
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

_JIRA_SCOPES: list[str] = [
    "read:jira-work",
    "read:jira-user",
    "offline_access",
]


def _jira_api(cloud_id: str) -> str:
    return f"https://api.atlassian.com/ex/jira/{cloud_id}/rest/api/3"


class JiraConnector(AtlassianConnector):
    slug = "jira"
    display_name = "Jira"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.PROJECT_MANAGEMENT
    oauth_scopes: ClassVar[list[str]] = _JIRA_SCOPES
    description = "Link Jira tickets to decisions and code changes"

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = ConnectorOAuthConfig(
        slug="jira",
        authorize_url="https://auth.atlassian.com/authorize",
        token_url="https://auth.atlassian.com/oauth/token",
        scopes=_JIRA_SCOPES,
        pkce=True,
        client_id_env="CODELEDGER_ATLASSIAN_CLIENT_ID",
        client_secret_env="CODELEDGER_ATLASSIAN_CLIENT_SECRET",
        extra_authorize_params={
            "audience": "api.atlassian.com",
            "prompt": "consent",
        },
    )

    async def health(self) -> ConnectorHealth:
        if not self.is_configured():
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.NOT_CONFIGURED,
                message="connector not configured",
                configured=False,
            )
        site = await self._site_info()
        if site is None:
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.AUTH_EXPIRED,
                message="could not resolve Atlassian workspace",
                configured=True,
            )
        cid, _ = site
        return await self._probe_health(f"{_jira_api(cid)}/myself")

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        site = await self._site_info()
        if site is None:
            return []
        cid, site_url = site
        resp = await self._http_get(
            f"{_jira_api(cid)}/issue/picker",
            params={"query": query, "showSubTasks": "true"},
        )
        if resp is None or resp.status_code != 200:
            return []
        try:
            data = resp.json()
        except ValueError:
            return []
        issues = _flatten_picker_sections(data, max_results)
        return [_picker_issue_to_result(issue, site_url) for issue in issues]

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        if not item_id or "/" in item_id or ".." in item_id:
            return None
        site = await self._site_info()
        if site is None:
            return None
        cid, site_url = site
        resp = await self._http_get(
            f"{_jira_api(cid)}/issue/{item_id}",
            params={"fields": "summary,status,priority,assignee"},
        )
        if resp is None or resp.status_code != 200:
            return None
        try:
            data = resp.json()
        except ValueError:
            return None
        return _full_issue_to_result(data, site_url)


def _flatten_picker_sections(
    data: dict[str, Any], max_results: int
) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    sections = data.get("sections") or []
    if not isinstance(sections, list):
        return []
    for section in sections:
        if not isinstance(section, dict):
            continue
        for issue in section.get("issues") or []:
            if isinstance(issue, dict):
                issues.append(issue)
                if len(issues) >= max_results:
                    return issues
    return issues


def _picker_issue_to_result(
    issue: dict[str, Any], site_url: str
) -> ConnectorResult:
    key = str(issue.get("key") or "")
    summary_text = str(
        issue.get("summaryText") or issue.get("summary") or ""
    )
    return ConnectorResult(
        item_id=key,
        title=f"{key}: {summary_text}" if summary_text else key,
        summary=summary_text,
        url=f"{site_url}/browse/{key}" if key else None,
        connector_slug="jira",
        item_type="issue",
    )


def _full_issue_to_result(
    data: dict[str, Any], site_url: str
) -> ConnectorResult | None:
    key = str(data.get("key") or "")
    if not key:
        return None
    fields = data.get("fields") or {}
    if not isinstance(fields, dict):
        fields = {}
    summary = str(fields.get("summary") or "")
    status_block = fields.get("status") or {}
    status_name = (
        str(status_block.get("name")) if isinstance(status_block, dict) else ""
    )
    priority_block = fields.get("priority") or {}
    priority_name = (
        str(priority_block.get("name"))
        if isinstance(priority_block, dict)
        else ""
    )
    summary_parts: list[str] = []
    if status_name:
        summary_parts.append(f"status={status_name}")
    if priority_name:
        summary_parts.append(f"priority={priority_name}")
    return ConnectorResult(
        item_id=key,
        title=f"{key}: {summary}" if summary else key,
        summary=" ".join(summary_parts) if summary_parts else summary,
        url=f"{site_url}/browse/{key}",
        connector_slug="jira",
        item_type="issue",
        metadata={"status": status_name, "priority": priority_name},
    )
