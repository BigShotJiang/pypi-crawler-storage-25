"""Microsoft Teams connector — link chat and channel messages to decisions.

Uses the Microsoft Graph Search API (``POST /search/query``) with
``entityTypes=['chatMessage']``. Search results expose the Graph-provided
preview ``summary`` only — never the full message body HTML.

Item IDs are the Graph resource path for the message (``chats/{chatId}/
messages/{id}`` or ``teams/{teamId}/channels/{channelId}/messages/{id}``)
so ``get_item`` can round-trip to the exact resource.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorResult,
)
from backend.connectors.external._base import ExternalConnector
from backend.connectors.external._microsoft import (
    GRAPH_API_V1,
    microsoft_oauth_config,
)

if TYPE_CHECKING:
    from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

_TEAMS_SCOPES: list[str] = [
    "https://graph.microsoft.com/Chat.Read",
    "https://graph.microsoft.com/ChannelMessage.Read.All",
    "offline_access",
]

_SEARCH_URL = f"{GRAPH_API_V1}/search/query"


class TeamsConnector(ExternalConnector):
    slug = "teams"
    display_name = "Microsoft Teams"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.COMMUNICATION
    oauth_scopes: ClassVar[list[str]] = _TEAMS_SCOPES
    description = "Search Teams messages and link threads to decisions"
    health_probe_url: ClassVar[str | None] = f"{GRAPH_API_V1}/me"

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = microsoft_oauth_config(
        "teams", _TEAMS_SCOPES
    )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        resp = await self._http_post(
            _SEARCH_URL,
            json={
                "requests": [
                    {
                        "entityTypes": ["chatMessage"],
                        "query": {"queryString": query},
                        "from": 0,
                        "size": max_results,
                    }
                ]
            },
        )
        if resp is None or resp.status_code != 200:
            return []
        try:
            data = resp.json()
        except ValueError:
            return []
        return _hits_to_results(data)

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        # item_id is a Graph resource path (no leading slash).
        if not item_id or item_id.startswith("/") or ".." in item_id:
            return None
        resp = await self._http_get(f"{GRAPH_API_V1}/{item_id.lstrip('/')}")
        if resp is None or resp.status_code != 200:
            return None
        try:
            data = resp.json()
        except ValueError:
            return None
        return _message_resource_to_result(item_id, data)


def _hits_to_results(data: dict[str, Any]) -> list[ConnectorResult]:
    """Flatten Graph Search ``hitsContainers → hits`` into ConnectorResults."""
    results: list[ConnectorResult] = []
    top = data.get("value") or []
    if not isinstance(top, list):
        return results
    for entry in top:
        if not isinstance(entry, dict):
            continue
        containers = entry.get("hitsContainers") or []
        if not isinstance(containers, list):
            continue
        for container in containers:
            if not isinstance(container, dict):
                continue
            for hit in container.get("hits") or []:
                if isinstance(hit, dict):
                    result = _hit_to_result(hit)
                    if result is not None:
                        results.append(result)
    return results


def _hit_to_result(hit: dict[str, Any]) -> ConnectorResult | None:
    resource = hit.get("resource") or {}
    if not isinstance(resource, dict):
        return None
    message_id = str(resource.get("id") or "")
    if not message_id:
        return None

    chat_id = resource.get("chatId")
    channel = resource.get("channelIdentity") or {}
    if isinstance(chat_id, str) and chat_id:
        path = f"chats/{chat_id}/messages/{message_id}"
        title_prefix = "chat"
    elif isinstance(channel, dict) and channel.get("teamId") and channel.get("channelId"):
        path = (
            f"teams/{channel['teamId']}"
            f"/channels/{channel['channelId']}/messages/{message_id}"
        )
        title_prefix = "channel"
    else:
        # Unrecognized message resource shape — skip rather than guess.
        return None

    summary_html = str(hit.get("summary") or "")
    sender = _sender_name(resource.get("from"))
    created = str(resource.get("createdDateTime") or "")

    return ConnectorResult(
        item_id=path,
        title=f"[{title_prefix}] {sender}" if sender else f"[{title_prefix}] message",
        summary=_strip_tags(summary_html),
        url=str(resource.get("webUrl") or "") or None,
        connector_slug="teams",
        item_type="message",
        metadata={"sender": sender, "created": created},
    )


def _message_resource_to_result(
    item_id: str, data: dict[str, Any]
) -> ConnectorResult | None:
    message_id = str(data.get("id") or "")
    if not message_id:
        return None
    sender = _sender_name(data.get("from"))
    created = str(data.get("createdDateTime") or "")
    body = data.get("body") or {}
    preview = ""
    if isinstance(body, dict):
        preview = _strip_tags(str(body.get("content") or ""))
    return ConnectorResult(
        item_id=item_id,
        title=f"Teams message from {sender}" if sender else "Teams message",
        summary=preview,
        url=str(data.get("webUrl") or "") or None,
        connector_slug="teams",
        item_type="message",
        metadata={"sender": sender, "created": created},
    )


def _sender_name(from_field: Any) -> str:
    if not isinstance(from_field, dict):
        return ""
    user = from_field.get("user") or {}
    if isinstance(user, dict):
        name = user.get("displayName")
        if isinstance(name, str):
            return name
    return ""


def _strip_tags(text: str) -> str:
    """Quick-and-good-enough tag stripper.

    Graph Search wraps matched terms in ``<c0>…</c0>`` markers; message
    bodies are HTML. We remove anything between ``<`` and ``>`` — this is
    acceptable because we only surface a short preview, never execute it.
    """
    out: list[str] = []
    depth = 0
    for ch in text:
        if ch == "<":
            depth += 1
        elif ch == ">":
            if depth > 0:
                depth -= 1
        elif depth == 0:
            out.append(ch)
    return "".join(out).strip()
