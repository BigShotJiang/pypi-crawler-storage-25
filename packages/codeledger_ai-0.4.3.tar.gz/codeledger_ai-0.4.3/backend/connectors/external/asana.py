"""Asana connector — link tasks to decisions.

Asana tokens are workspace-scoped at the app-registration level but
multi-workspace at the account level: after sign-in, the user grants
the app access to one or more workspaces. This connector targets the
*first* workspace returned by ``/users/me`` and caches its GID in the
vault under ``connector_asana:workspace_gid`` — symmetrical to the
Atlassian ``cloud_id`` pattern.
"""

from __future__ import annotations

from typing import Any, ClassVar

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorHealth,
    ConnectorResult,
    ConnectorStatus,
)
from backend.connectors.external._base import ExternalConnector
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

_ASANA_SCOPES: list[str] = ["default"]
_API_ROOT = "https://app.asana.com/api/1.0"


class AsanaConnector(ExternalConnector):
    slug = "asana"
    display_name = "Asana"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.PROJECT_MANAGEMENT
    oauth_scopes: ClassVar[list[str]] = _ASANA_SCOPES
    description = "Link Asana tasks to decisions"
    health_probe_url: ClassVar[str | None] = f"{_API_ROOT}/users/me"

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = ConnectorOAuthConfig(
        slug="asana",
        authorize_url="https://app.asana.com/-/oauth_authorize",
        token_url="https://app.asana.com/-/oauth_token",
        scopes=_ASANA_SCOPES,
        pkce=True,
        client_id_env="CODELEDGER_ASANA_CLIENT_ID",
        client_secret_env="CODELEDGER_ASANA_CLIENT_SECRET",
    )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        gid = await self._workspace_gid()
        if not gid:
            return []
        resp = await self._http_get(
            f"{_API_ROOT}/workspaces/{gid}/tasks/search",
            params={"text": query, "limit": max_results},
        )
        if resp is None or resp.status_code != 200:
            return []
        try:
            data = resp.json()
        except ValueError:
            return []
        items = data.get("data") or []
        if not isinstance(items, list):
            return []
        return [
            _task_summary_to_result(t) for t in items if isinstance(t, dict) and t.get("gid")
        ]

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        if not item_id or "/" in item_id or ".." in item_id:
            return None
        resp = await self._http_get(f"{_API_ROOT}/tasks/{item_id}")
        if resp is None or resp.status_code != 200:
            return None
        try:
            data = resp.json()
        except ValueError:
            return None
        task = data.get("data")
        if not isinstance(task, dict) or not task.get("gid"):
            return None
        return _task_full_to_result(task)

    async def health(self) -> ConnectorHealth:
        # We want health to also verify workspace resolution, not just token
        # validity — a valid token with no workspace access is unusable.
        if not self.is_configured():
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.NOT_CONFIGURED,
                message="connector not configured",
                configured=False,
            )
        gid = await self._workspace_gid()
        if not gid:
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.AUTH_EXPIRED,
                message="could not resolve workspace",
                configured=True,
            )
        return ConnectorHealth(
            slug=self.slug,
            status=ConnectorStatus.CONNECTED,
            message="ok",
            configured=True,
        )

    async def _workspace_gid(self) -> str | None:
        cached = self._get_credential("workspace_gid")
        if cached:
            return cached
        resp = await self._http_get(f"{_API_ROOT}/users/me")
        if resp is None or resp.status_code != 200:
            return None
        try:
            data = resp.json()
        except ValueError:
            return None
        user = data.get("data")
        if not isinstance(user, dict):
            return None
        workspaces = user.get("workspaces") or []
        if not isinstance(workspaces, list) or not workspaces:
            return None
        first = workspaces[0]
        if not isinstance(first, dict):
            return None
        gid = first.get("gid")
        if not isinstance(gid, str) or not gid:
            return None
        self._set_credential("workspace_gid", gid)
        return gid


def _task_summary_to_result(task: dict[str, Any]) -> ConnectorResult:
    gid = str(task.get("gid") or "")
    name = str(task.get("name") or "")
    completed = bool(task.get("completed"))
    return ConnectorResult(
        item_id=gid,
        title=name or f"task {gid}",
        summary=f"completed={completed}",
        url=f"https://app.asana.com/0/0/{gid}/f" if gid else None,
        connector_slug="asana",
        item_type="task",
        metadata={"completed": completed},
    )


def _task_full_to_result(task: dict[str, Any]) -> ConnectorResult:
    gid = str(task.get("gid") or "")
    name = str(task.get("name") or "")
    completed = bool(task.get("completed"))
    due = str(task.get("due_on") or "")
    assignee_block = task.get("assignee") or {}
    assignee = ""
    if isinstance(assignee_block, dict):
        assignee = str(assignee_block.get("name") or "")
    permalink = str(task.get("permalink_url") or "")
    summary_parts: list[str] = [f"completed={completed}"]
    if due:
        summary_parts.append(f"due={due}")
    if assignee:
        summary_parts.append(f"assignee={assignee}")
    return ConnectorResult(
        item_id=gid,
        title=name or f"task {gid}",
        summary=" ".join(summary_parts),
        url=permalink or (f"https://app.asana.com/0/0/{gid}/f" if gid else None),
        connector_slug="asana",
        item_type="task",
        metadata={
            "completed": completed,
            "due": due,
            "assignee": assignee,
        },
    )
