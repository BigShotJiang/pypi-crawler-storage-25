"""HTTP routes for the connector marketplace.

Exposes six endpoints under ``/api/connectors``:

Public (reached before the auth middleware runs):
- ``GET  /oauth/{slug}/connect``   — initiate OAuth (state + PKCE cookie set)
- ``GET  /oauth/{slug}/callback``  — provider redirect, exchange code, store tokens

Auth-required (normal middleware applies):
- ``GET  /status``                  — dashboard metadata, never credentials
- ``GET  /{slug}/health``           — live connector health check
- ``POST /{slug}/setup``            — API-key / connection-string submit
- ``POST /{slug}/disconnect``       — clear stored credentials

CSRF defense: per-slug cookies ``codeledger_connector_state_{slug}`` and
``codeledger_connector_verifier_{slug}`` so two in-flight connector flows
in separate browser tabs do not stomp on each other (A-1 §1.8 risk #4).
"""

from __future__ import annotations

import hmac
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, RedirectResponse

from backend.auth.oauth_manager import (
    ProviderConfig,
    build_auth_url,
    generate_pkce,
    generate_state,
)
from backend.connectors.base import AuthType
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

if TYPE_CHECKING:
    from backend.connectors.base import AbstractConnector
    from backend.connectors.oauth_token_manager import OAuthTokenManager
    from backend.connectors.registry import ConnectorRegistry

logger = logging.getLogger(__name__)


_COOKIE_MAX_AGE = 600
_COOKIE_PATH = "/api/connectors/oauth/"
_DASHBOARD_SUCCESS_URL = "/?connector_connected={slug}"
_DASHBOARD_ERROR_URL = "/?connector_error={reason}&connector={slug}"


@dataclass(frozen=True)
class ConnectorsRouterConfig:
    """Knobs a caller (usually ``main.py``) passes in at router construction.

    Keeping these as a frozen dataclass makes the factory contract explicit
    and avoids loading the full ``CodeLedgerConfig`` inside this module.
    """

    server_host: str
    server_port: int
    cookie_secure: bool


def _state_cookie(slug: str) -> str:
    return f"codeledger_connector_state_{slug}"


def _verifier_cookie(slug: str) -> str:
    return f"codeledger_connector_verifier_{slug}"


def _redirect_uri(cfg: ConnectorsRouterConfig, slug: str) -> str:
    return (
        f"http://{cfg.server_host}:{cfg.server_port}"
        f"/api/connectors/oauth/{slug}/callback"
    )


def _error_redirect(slug: str, reason: str) -> RedirectResponse:
    resp = RedirectResponse(
        url=_DASHBOARD_ERROR_URL.format(reason=reason, slug=slug),
        status_code=302,
    )
    resp.delete_cookie(_state_cookie(slug), path=_COOKIE_PATH)
    resp.delete_cookie(_verifier_cookie(slug), path=_COOKIE_PATH)
    return resp


def _get_registry(request: Request) -> ConnectorRegistry | None:
    registry: ConnectorRegistry | None = getattr(
        request.app.state, "connector_registry", None
    )
    return registry


def _get_token_manager(request: Request) -> OAuthTokenManager | None:
    tm: OAuthTokenManager | None = getattr(
        request.app.state, "connector_oauth_manager", None
    )
    return tm


def create_connectors_router(
    cfg: ConnectorsRouterConfig,
) -> APIRouter:
    """Build the connector marketplace router.

    The connector registry and OAuth token manager are read from
    ``request.app.state`` at request time so the same router plays nicely
    with the rest of the FastAPI app's startup lifecycle.
    """
    router = APIRouter(prefix="/api/connectors", tags=["connectors"])

    # ------------------------------------------------------------------ #
    # GET /status                                                        #
    # ------------------------------------------------------------------ #
    @router.get("/status", include_in_schema=False)
    async def connectors_status(request: Request) -> Any:
        registry = _get_registry(request)
        if registry is None:
            return JSONResponse(
                status_code=503,
                content={"detail": "Connector registry not initialized"},
            )
        return {"connectors": registry.dashboard_status()}

    # ------------------------------------------------------------------ #
    # GET /{slug}/health                                                 #
    # ------------------------------------------------------------------ #
    @router.get("/{slug}/health", include_in_schema=False)
    async def connector_health(slug: str, request: Request) -> Any:
        registry = _get_registry(request)
        if registry is None:
            return JSONResponse(status_code=503, content={"detail": "registry unavailable"})
        connector = registry.get(slug)
        if connector is None:
            return JSONResponse(status_code=404, content={"detail": f"Unknown connector: {slug}"})
        try:
            health = await connector.health()
        except Exception:
            logger.warning("[%s] health raised during route call", slug, exc_info=True)
            return JSONResponse(status_code=500, content={"detail": "health check failed"})
        return {
            "slug": health.slug,
            "status": health.status.value,
            "message": health.message,
            "configured": health.configured,
        }

    # ------------------------------------------------------------------ #
    # POST /{slug}/setup                                                 #
    # ------------------------------------------------------------------ #
    @router.post("/{slug}/setup", include_in_schema=False)
    async def connector_setup(slug: str, request: Request) -> Any:
        registry = _get_registry(request)
        if registry is None:
            return JSONResponse(status_code=503, content={"detail": "registry unavailable"})
        connector = registry.get(slug)
        if connector is None:
            return JSONResponse(status_code=404, content={"detail": f"Unknown connector: {slug}"})

        try:
            body = await request.json()
        except Exception:
            return JSONResponse(status_code=400, content={"detail": "Body must be JSON"})
        credentials = body.get("credentials") if isinstance(body, dict) else None
        if not isinstance(credentials, dict):
            return JSONResponse(
                status_code=400,
                content={"detail": "credentials must be an object"},
            )

        auth_type = connector.auth_type
        if auth_type == AuthType.API_KEY:
            api_key = credentials.get("api_key")
            if not isinstance(api_key, str) or not api_key:
                return JSONResponse(
                    status_code=400, content={"detail": "api_key required"}
                )
            connector._set_credential("api_key", api_key)
        elif auth_type == AuthType.CONNECTION_STRING:
            conn_str = credentials.get("connection_string")
            if not isinstance(conn_str, str) or not conn_str:
                return JSONResponse(
                    status_code=400,
                    content={"detail": "connection_string required"},
                )
            connector._set_credential("connection_string", conn_str)
        else:
            return JSONResponse(
                status_code=400,
                content={
                    "detail": (
                        f"{slug} uses {auth_type.value} auth — "
                        f"use /api/connectors/oauth/{slug}/connect instead"
                    )
                },
            )

        try:
            health = await connector.health()
        except Exception:
            logger.warning("[%s] health raised after setup", slug, exc_info=True)
            return {"connected": True, "health": None}
        return {
            "connected": health.configured,
            "health": {
                "status": health.status.value,
                "message": health.message,
            },
        }

    # ------------------------------------------------------------------ #
    # POST /{slug}/disconnect                                            #
    # ------------------------------------------------------------------ #
    @router.post("/{slug}/disconnect", include_in_schema=False)
    async def connector_disconnect(slug: str, request: Request) -> Any:
        registry = _get_registry(request)
        token_manager = _get_token_manager(request)
        if registry is None:
            return JSONResponse(status_code=503, content={"detail": "registry unavailable"})
        connector = registry.get(slug)
        if connector is None:
            return JSONResponse(status_code=404, content={"detail": f"Unknown connector: {slug}"})

        for key in (
            "access_token",
            "refresh_token",
            "token_expiry",
            "api_key",
            "connection_string",
            "cloud_id",
            "site_url",
            "workspace_gid",
            "db_name",
        ):
            connector._delete_credential(key)

        # Token manager is a no-op for non-OAuth connectors; call anyway to
        # keep behavior uniform across auth types.
        if token_manager is not None:
            token_manager.clear_tokens(slug)

        return {"disconnected": True}

    # ------------------------------------------------------------------ #
    # GET /oauth/{slug}/connect                                          #
    # ------------------------------------------------------------------ #
    @router.get("/oauth/{slug}/connect", include_in_schema=False)
    async def oauth_connect(slug: str, request: Request) -> Any:
        registry = _get_registry(request)
        token_manager = _get_token_manager(request)
        if registry is None or token_manager is None:
            return JSONResponse(
                status_code=503, content={"detail": "connector framework unavailable"}
            )
        connector = registry.get(slug)
        if connector is None:
            return JSONResponse(
                status_code=404, content={"detail": f"Unknown connector: {slug}"}
            )
        if connector.auth_type != AuthType.OAUTH2:
            return JSONResponse(
                status_code=400,
                content={
                    "detail": f"{slug} does not use OAuth — POST to /setup instead"
                },
            )
        oauth_config = _connector_oauth_config(connector)
        if oauth_config is None:
            return JSONResponse(
                status_code=500,
                content={"detail": f"{slug} missing oauth_config"},
            )

        client_id, client_secret = token_manager.get_client_credentials(oauth_config)
        if not client_id or not client_secret:
            return JSONResponse(
                status_code=503,
                content={
                    "detail": (
                        f"{slug} OAuth client credentials not configured. "
                        f"Store them via /api/connectors/{slug}/setup or the CLI."
                    ),
                    "configured": False,
                },
            )

        state = generate_state()
        code_verifier: str | None = None
        code_challenge: str | None = None
        if oauth_config.pkce:
            code_verifier, code_challenge = generate_pkce()

        # build_auth_url reads name / authorize_url / scopes / pkce from a
        # ProviderConfig — build a lightweight one just for that call.
        provider_shim = ProviderConfig(
            name=slug,
            authorize_url=oauth_config.authorize_url,
            scopes=oauth_config.scopes,
            pkce=oauth_config.pkce,
        )
        url = build_auth_url(
            provider_shim,
            client_id,
            _redirect_uri(cfg, slug),
            state,
            code_challenge,
        )
        # Append connector-specific extra authorize params (e.g. Atlassian's
        # audience=api.atlassian.com, Google's access_type=offline).
        if oauth_config.extra_authorize_params:
            from urllib.parse import urlencode

            sep = "&" if "?" in url else "?"
            url = f"{url}{sep}{urlencode(oauth_config.extra_authorize_params)}"

        response = RedirectResponse(url=url, status_code=302)
        response.set_cookie(
            _state_cookie(slug),
            state,
            max_age=_COOKIE_MAX_AGE,
            httponly=True,
            samesite="lax",
            secure=cfg.cookie_secure,
            path=_COOKIE_PATH,
        )
        if code_verifier:
            response.set_cookie(
                _verifier_cookie(slug),
                code_verifier,
                max_age=_COOKIE_MAX_AGE,
                httponly=True,
                samesite="lax",
                secure=cfg.cookie_secure,
                path=_COOKIE_PATH,
            )
        return response

    # ------------------------------------------------------------------ #
    # GET /oauth/{slug}/callback                                         #
    # ------------------------------------------------------------------ #
    @router.get("/oauth/{slug}/callback", include_in_schema=False)
    async def oauth_callback(
        slug: str,
        request: Request,
        code: str | None = None,
        state: str | None = None,
        error: str | None = None,
    ) -> Any:
        if error:
            logger.info("[%s] OAuth provider error: %s", slug, error)
            return _error_redirect(slug, "oauth_denied")
        if not code or not state:
            return _error_redirect(slug, "oauth_invalid")

        stored_state = request.cookies.get(_state_cookie(slug))
        if not stored_state or not hmac.compare_digest(
            stored_state.encode(), state.encode()
        ):
            logger.warning("[%s] OAuth state mismatch — possible CSRF", slug)
            return _error_redirect(slug, "oauth_csrf")

        registry = _get_registry(request)
        token_manager = _get_token_manager(request)
        if registry is None or token_manager is None:
            return _error_redirect(slug, "oauth_unconfigured")
        connector = registry.get(slug)
        if connector is None:
            return _error_redirect(slug, "oauth_unknown_connector")
        oauth_config = _connector_oauth_config(connector)
        if oauth_config is None:
            return _error_redirect(slug, "oauth_unconfigured")

        code_verifier: str | None = None
        if oauth_config.pkce:
            code_verifier = request.cookies.get(_verifier_cookie(slug))
            if not code_verifier:
                return _error_redirect(slug, "oauth_pkce_missing")

        redirect_uri = _redirect_uri(cfg, slug)
        ok = await token_manager.exchange_code(
            oauth_config, code, redirect_uri, code_verifier
        )
        if not ok:
            return _error_redirect(slug, "oauth_exchange_failed")

        response = RedirectResponse(
            url=_DASHBOARD_SUCCESS_URL.format(slug=slug),
            status_code=302,
        )
        response.delete_cookie(_state_cookie(slug), path=_COOKIE_PATH)
        response.delete_cookie(_verifier_cookie(slug), path=_COOKIE_PATH)
        return response

    return router


# ---------------------------------------------------------------------- #
# Helpers                                                                #
# ---------------------------------------------------------------------- #


def _connector_oauth_config(
    connector: AbstractConnector,
) -> ConnectorOAuthConfig | None:
    """Safely pull the connector's ``oauth_config`` class attribute."""
    cfg = getattr(connector, "oauth_config", None)
    return cfg if isinstance(cfg, ConnectorOAuthConfig) else None
