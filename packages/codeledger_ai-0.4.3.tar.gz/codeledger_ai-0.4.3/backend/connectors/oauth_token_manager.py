"""Connector-scoped OAuth 2.0 token lifecycle.

The identity-login :class:`backend.auth.oauth_manager.OAuthManager` keys tokens
by ``(provider_name, user_id)`` and assumes every provider is declared in
``providers.toml``. Connector tokens have different requirements:

- Keyed purely by connector ``slug`` — connectors need not appear in
  ``providers.toml`` (e.g. Notion, Linear, Asana as marketplace connectors).
- Each connector persists its own ``client_id`` / ``client_secret`` in the
  vault namespace ``connector_{slug}``.
- OAuth flows run via server-side HTTP redirects (``/api/connectors/{slug}/...``),
  not the local ``HTTPServer`` loopback listener used by desktop identity login.

This module is a self-contained manager for the connector namespace; it
neither wraps nor mutates the identity ``OAuthManager``.

Security invariants:
- SEC-04: access / refresh tokens go only into :class:`CredentialManager`.
- SEC-02: token values never appear in log output; log statements include the
  connector slug and status codes only.
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import httpx

if TYPE_CHECKING:
    from backend.auth.credential_manager import CredentialManager

logger = logging.getLogger(__name__)


TOKEN_REFRESH_BUFFER_SECONDS = 300
"""Refresh an access token when its remaining lifetime drops below this."""

HTTP_TIMEOUT_SECONDS = 10.0
"""Per-request timeout on token exchange / refresh HTTP calls."""


@dataclass(frozen=True)
class ConnectorOAuthConfig:
    """OAuth 2.0 endpoints and client-identity env wiring for one connector."""

    slug: str
    authorize_url: str
    token_url: str
    scopes: list[str]
    pkce: bool = True
    client_id_env: str = ""
    client_secret_env: str = ""
    extra_authorize_params: dict[str, str] = field(default_factory=dict)


class OAuthTokenManager:
    """Per-connector access / refresh token storage and lifecycle."""

    def __init__(self, credential_manager: CredentialManager) -> None:
        self._cm = credential_manager

    # ------------------------------------------------------------------ #
    # Vault namespacing                                                  #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _ns(slug: str) -> str:
        return f"connector_{slug}"

    # ------------------------------------------------------------------ #
    # Client credentials                                                 #
    # ------------------------------------------------------------------ #

    def get_client_credentials(
        self, config: ConnectorOAuthConfig
    ) -> tuple[str, str]:
        """Return ``(client_id, client_secret)`` from env then vault.

        Missing values come back as empty strings; the caller decides whether
        an empty pair is fatal (most initiate routes treat it as "not
        configured — show the setup prompt").
        """
        ns = self._ns(config.slug)
        client_id = os.environ.get(config.client_id_env, "") or (
            self._cm.get(ns, "client_id") or ""
        )
        client_secret = os.environ.get(config.client_secret_env, "") or (
            self._cm.get(ns, "client_secret") or ""
        )
        return client_id, client_secret

    # ------------------------------------------------------------------ #
    # Token lifecycle                                                    #
    # ------------------------------------------------------------------ #

    async def get_valid_token(self, config: ConnectorOAuthConfig) -> str | None:
        """Return a currently-valid access token, refreshing if near expiry.

        Returns ``None`` when no access token is stored or refresh fails.
        Never raises.
        """
        ns = self._ns(config.slug)
        access_token = self._cm.get(ns, "access_token")
        if not access_token:
            return None

        expiry_str = self._cm.get(ns, "token_expiry")
        if expiry_str:
            try:
                expires_at = float(expiry_str)
            except ValueError:
                # Malformed expiry — serve the stored token unchanged rather
                # than refuse outright; next successful exchange will fix it.
                logger.debug(
                    "[%s] malformed token_expiry in vault: %r",
                    config.slug,
                    expiry_str,
                )
                return access_token
            if time.time() >= expires_at - TOKEN_REFRESH_BUFFER_SECONDS:
                return await self._refresh(config)

        return access_token

    async def _refresh(self, config: ConnectorOAuthConfig) -> str | None:
        """Exchange the stored refresh token for a new access token."""
        ns = self._ns(config.slug)
        refresh_token = self._cm.get(ns, "refresh_token")
        client_id, client_secret = self.get_client_credentials(config)
        if not (refresh_token and client_id and client_secret):
            logger.info(
                "[%s] refresh skipped — missing refresh_token or client creds",
                config.slug,
            )
            return None

        try:
            resp = await self._http_post(
                config.token_url,
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,
                    "client_id": client_id,
                    "client_secret": client_secret,
                },
                headers={"Accept": "application/json"},
            )
        except httpx.HTTPError:
            logger.warning(
                "[%s] token refresh HTTP error", config.slug, exc_info=True
            )
            return None

        if resp.status_code != 200:
            logger.warning(
                "[%s] token refresh failed: status=%s",
                config.slug,
                resp.status_code,
            )
            return None

        try:
            tokens = resp.json()
        except ValueError:
            logger.warning("[%s] token refresh returned non-JSON body", config.slug)
            return None

        self.store_tokens(config.slug, tokens)
        access_token = tokens.get("access_token")
        return access_token if isinstance(access_token, str) else None

    async def exchange_code(
        self,
        config: ConnectorOAuthConfig,
        code: str,
        redirect_uri: str,
        code_verifier: str | None = None,
    ) -> bool:
        """Exchange a one-shot authorization code for access + refresh tokens.

        Stores the resulting tokens via :meth:`store_tokens` and returns
        ``True`` on success. Any failure (missing client creds, non-200
        response, malformed body) yields ``False`` without raising — the
        caller (usually an OAuth callback route) redirects to an error
        URL from there.
        """
        client_id, client_secret = self.get_client_credentials(config)
        if not (client_id and client_secret):
            return False

        payload: dict[str, str] = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
            "client_id": client_id,
            "client_secret": client_secret,
        }
        if config.pkce and code_verifier:
            payload["code_verifier"] = code_verifier

        try:
            resp = await self._http_post(
                config.token_url,
                data=payload,
                headers={"Accept": "application/json"},
            )
        except httpx.HTTPError:
            logger.warning(
                "[%s] token exchange HTTP error", config.slug, exc_info=True
            )
            return False
        if resp.status_code != 200:
            logger.warning(
                "[%s] token exchange failed: status=%s",
                config.slug,
                resp.status_code,
            )
            return False
        try:
            tokens = resp.json()
        except ValueError:
            logger.warning(
                "[%s] token exchange returned non-JSON body", config.slug
            )
            return False
        if not isinstance(tokens, dict):
            return False

        self.store_tokens(config.slug, tokens)
        return True

    def store_tokens(self, slug: str, tokens: dict[str, Any]) -> None:
        """Persist access / refresh / expiry fields from an OAuth token response.

        Missing fields are simply skipped — some providers rotate the refresh
        token on every exchange, others do not; some return an ``expires_in``,
        others do not.
        """
        ns = self._ns(slug)
        access_token = tokens.get("access_token")
        if isinstance(access_token, str) and access_token:
            self._cm.set(ns, "access_token", access_token)

        refresh_token = tokens.get("refresh_token")
        if isinstance(refresh_token, str) and refresh_token:
            self._cm.set(ns, "refresh_token", refresh_token)

        expires_in = tokens.get("expires_in")
        expiry_seconds = _coerce_expiry_seconds(expires_in)
        if expiry_seconds is not None:
            self._cm.set(
                ns, "token_expiry", str(time.time() + expiry_seconds)
            )

    def clear_tokens(self, slug: str) -> None:
        """Remove all stored tokens for a connector (used on disconnect)."""
        ns = self._ns(slug)
        for key in ("access_token", "refresh_token", "token_expiry"):
            try:
                self._cm.delete(ns, key)
            except Exception:
                logger.debug(
                    "[%s] clear_tokens: delete %s failed",
                    slug,
                    key,
                    exc_info=True,
                )

    # ------------------------------------------------------------------ #
    # HTTP — seam for test monkey-patching                               #
    # ------------------------------------------------------------------ #

    async def _http_post(
        self,
        url: str,
        data: dict[str, str],
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT_SECONDS) as client:
            return await client.post(url, data=data, headers=headers)


def _coerce_expiry_seconds(value: Any) -> float | None:
    """Normalize an ``expires_in`` value (int, float, or numeric string) to float."""
    if isinstance(value, bool):
        # bool is a subclass of int; reject it to avoid weird token lifetimes
        return None
    if isinstance(value, int | float):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            return None
    return None
