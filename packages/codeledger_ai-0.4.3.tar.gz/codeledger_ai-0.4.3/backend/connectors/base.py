"""Abstract base for all CodeLedger connectors.

Every connector — external tool or database — implements this interface.
Connector failures are isolated: ``health``, ``search``, and ``get_item``
never raise and never crash the MCP server. All credentials flow through
:class:`CredentialManager` under the provider namespace ``connector_{slug}``.

Security invariants:
- SEC-03: ``ConnectorResult`` carries no credentials; the summary field is
  hard-capped by :data:`MAX_SUMMARY_CHARS` to bound PII exposure.
- SEC-04: Credentials live exclusively in the vault; this module only
  reads/writes via :class:`CredentialManager`.
- SEC-11: ``link_to_decision`` records an audit row in ``provenance_edges``
  rather than mutating a decision directly.
"""

from __future__ import annotations

import logging
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import TYPE_CHECKING, ClassVar

if TYPE_CHECKING:
    from backend.auth.credential_manager import CredentialManager
    from backend.db.db_backend import DatabaseBackend

logger = logging.getLogger(__name__)


CONNECTOR_TIMEOUT_SECONDS = 10
"""Per-call timeout the registry will enforce on every connector method."""

MAX_SUMMARY_CHARS = 500
"""Hard cap on ``ConnectorResult.summary`` — bounds PII surface area."""


class AuthType(Enum):
    OAUTH2 = "oauth2"
    API_KEY = "api_key"
    CONNECTION_STRING = "connection_string"
    BASIC = "basic"


class ConnectorStatus(Enum):
    CONNECTED = "connected"
    NOT_CONFIGURED = "not_configured"
    AUTH_EXPIRED = "auth_expired"
    DEGRADED = "degraded"
    ERROR = "error"


class ConnectorCategory(Enum):
    COMMUNICATION = "communication"
    PROJECT_MANAGEMENT = "project_management"
    CLOUD_STORAGE = "cloud_storage"
    DATABASE = "database"
    CI_CD = "ci_cd"
    ANALYTICS = "analytics"


@dataclass
class ConnectorResult:
    """PII-safe summary record returned from ``search``/``get_item``."""

    item_id: str
    title: str
    summary: str
    url: str | None
    connector_slug: str
    item_type: str
    metadata: dict[str, object] = field(default_factory=dict)
    relevance_score: float = 0.0

    def __post_init__(self) -> None:
        # Enforce the summary cap at construction so every call site is safe.
        if len(self.summary) > MAX_SUMMARY_CHARS:
            self.summary = self.summary[: MAX_SUMMARY_CHARS - 1] + "\u2026"


@dataclass
class ConnectorHealth:
    slug: str
    status: ConnectorStatus
    message: str
    configured: bool
    last_checked: str | None = None


class AbstractConnector(ABC):
    """Interface every connector implements.

    Subclasses declare identity via class-level attributes
    (``slug``, ``display_name``, ``auth_type``, ``category``, ...) and
    implement ``health``, ``search``, and ``get_item``.
    """

    slug: str
    display_name: str
    auth_type: AuthType
    category: ConnectorCategory
    oauth_scopes: ClassVar[list[str]] = []
    description: str = ""

    def __init__(
        self,
        credential_manager: CredentialManager,
        db: DatabaseBackend | None = None,
    ) -> None:
        self._cm = credential_manager
        self._db = db

    # ------------------------------------------------------------------ #
    # Abstract surface                                                   #
    # ------------------------------------------------------------------ #

    @abstractmethod
    async def health(self) -> ConnectorHealth:
        """Report connector health. MUST NOT raise — return ERROR status instead."""

    @abstractmethod
    async def search(
        self,
        query: str,
        project_id: str,
        max_results: int = 10,
    ) -> list[ConnectorResult]:
        """Search items matching ``query``. MUST NOT raise — return ``[]``."""

    @abstractmethod
    async def get_item(
        self,
        item_id: str,
        project_id: str,
    ) -> ConnectorResult | None:
        """Fetch a specific item by id. MUST NOT raise — return ``None``."""

    # ------------------------------------------------------------------ #
    # Concrete helpers                                                   #
    # ------------------------------------------------------------------ #

    async def link_to_decision(
        self,
        item_id: str,
        decision_id: str,
        project_id: str,
    ) -> bool:
        """Record a provenance edge from this connector item to a decision.

        ``project_id`` is accepted for call-site symmetry with the MCP tool
        signature but is not persisted: ``provenance_edges`` has no project
        column today.

        Returns ``True`` on success, ``False`` if no backend is attached or
        the insert fails (caller never sees an exception).
        """
        if self._db is None:
            logger.warning("[%s] link_to_decision called without db backend", self.slug)
            return False
        now = datetime.now(UTC).isoformat()
        try:
            await self._db.insert(
                "provenance_edges",
                {
                    "id": uuid.uuid4().hex,
                    "source_type": f"connector_{self.slug}",
                    "source_id": item_id,
                    "target_type": "decision",
                    "target_id": decision_id,
                    "relationship": "linked",
                    "created_at": now,
                    "updated_at": now,
                },
            )
            return True
        except Exception:
            logger.warning(
                "[%s] link_to_decision failed (item=%s decision=%s)",
                self.slug,
                item_id,
                decision_id,
                exc_info=True,
            )
            return False

    def _get_credential(self, key: str) -> str | None:
        return self._cm.get(f"connector_{self.slug}", key)

    def _set_credential(self, key: str, value: str) -> None:
        self._cm.set(f"connector_{self.slug}", key, value)

    def _delete_credential(self, key: str) -> None:
        try:
            self._cm.delete(f"connector_{self.slug}", key)
        except Exception:
            logger.debug(
                "[%s] delete credential %s failed", self.slug, key, exc_info=True
            )

    def is_configured(self) -> bool:
        """True iff the minimum credentials for this auth type are stored."""
        if self.auth_type == AuthType.OAUTH2:
            return bool(self._get_credential("access_token"))
        if self.auth_type == AuthType.API_KEY:
            return bool(self._get_credential("api_key"))
        if self.auth_type == AuthType.CONNECTION_STRING:
            return bool(self._get_credential("connection_string"))
        if self.auth_type == AuthType.BASIC:
            return bool(
                self._get_credential("username")
                and self._get_credential("password")
            )
        return False
