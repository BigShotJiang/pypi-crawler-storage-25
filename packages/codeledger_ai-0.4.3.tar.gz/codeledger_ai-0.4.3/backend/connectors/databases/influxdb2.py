"""InfluxDB 2.x connector via the official ``influxdb-client`` async API.

Expects JSON in ``connection_string``::

    {"url": "http://host:8086", "token": "...", "org": "...", "bucket": "..."}

Buckets map to "tables"; measurements within a bucket map to sub-tables
via describe/sample. Queries use Flux, which is the native language of
InfluxDB 2.x (InfluxDB 3 uses SQL and is implemented in ``influxdb3.py``).
"""

from __future__ import annotations

import logging
from typing import Any

from backend.connectors.databases._base import (
    AbstractDatabaseConnector,
    parse_json_config,
    require_driver,
)

logger = logging.getLogger(__name__)

try:
    from influxdb_client.client.influxdb_client_async import (
        InfluxDBClientAsync as _Client,
    )

    _driver: Any = _Client
    _AVAILABLE = True
except ImportError:
    _driver = None
    _AVAILABLE = False


class InfluxDB2Connector(AbstractDatabaseConnector):
    slug = "influxdb2"
    display_name = "InfluxDB 2"
    description = "Query InfluxDB 2.x buckets and measurements (Flux)"

    def __init__(self, credential_manager, db=None):  # type: ignore[no-untyped-def]
        require_driver(_driver, self.slug, "influxdb2")
        super().__init__(credential_manager, db)

    def _config(self) -> dict[str, Any]:
        return parse_json_config(self._get_credential("connection_string"))

    def _client(self) -> Any:
        cfg = self._config()
        if not all(cfg.get(k) for k in ("url", "token", "org")):
            return None
        try:
            return _driver(url=cfg["url"], token=cfg["token"], org=cfg["org"])
        except Exception as exc:
            logger.info(
                "[%s] client init failed: %s", self.slug, exc.__class__.__name__
            )
            return None

    async def test_connection(self) -> bool:
        client = self._client()
        if client is None:
            return False
        try:
            ok = await client.ping()
            return bool(ok)
        except Exception:
            return False
        finally:
            await _close(client)

    async def list_tables(self) -> list[str]:
        # Measurements within the configured bucket = "tables"
        cfg = self._config()
        bucket = cfg.get("bucket")
        if not bucket:
            return []
        client = self._client()
        if client is None:
            return []
        try:
            flux = (
                f'import "influxdata/influxdb/schema"\n'
                f'schema.measurements(bucket: "{_escape_flux(bucket)}")'
            )
            qapi = client.query_api()
            tables = await qapi.query(flux)
            names: list[str] = []
            for t in tables or []:
                for rec in getattr(t, "records", []):
                    value = rec.get_value()
                    if isinstance(value, str):
                        names.append(value)
            return names
        except Exception:
            return []
        finally:
            await _close(client)

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        cfg = self._config()
        bucket = cfg.get("bucket")
        client = self._client()
        if client is None or not bucket:
            await _close(client)
            return {"columns": []}
        try:
            flux = (
                f'import "influxdata/influxdb/schema"\n'
                f'schema.measurementFieldKeys('
                f'bucket: "{_escape_flux(bucket)}", '
                f'measurement: "{_escape_flux(table)}")'
            )
            tables = await client.query_api().query(flux)
            columns: list[dict[str, str]] = []
            for t in tables or []:
                for rec in getattr(t, "records", []):
                    v = rec.get_value()
                    if isinstance(v, str):
                        columns.append({"name": v, "type": "field"})
            return {"columns": columns}
        except Exception:
            return {"columns": []}
        finally:
            await _close(client)

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > 1000:
            return []
        if not await self._validate_table(table):
            return []
        cfg = self._config()
        bucket = cfg.get("bucket")
        client = self._client()
        if client is None or not bucket:
            await _close(client)
            return []
        try:
            flux = (
                f'from(bucket: "{_escape_flux(bucket)}")\n'
                f'  |> range(start: -7d)\n'
                f'  |> filter(fn: (r) => r._measurement == '
                f'"{_escape_flux(table)}")\n'
                f'  |> limit(n: {int(limit)})'
            )
            tables = await client.query_api().query(flux)
            rows: list[dict[str, Any]] = []
            for t in tables or []:
                for rec in getattr(t, "records", []):
                    rows.append(
                        {
                            "_time": str(rec.get_time() or ""),
                            "_field": str(rec.get_field() or ""),
                            "_value": rec.get_value(),
                        }
                    )
                    if len(rows) >= limit:
                        return rows
            return rows
        except Exception:
            return []
        finally:
            await _close(client)


async def _close(client: Any) -> None:
    if client is None:
        return
    try:
        await client.close()
    except Exception:
        logger.debug("influxdb2 close failed", exc_info=True)


def _escape_flux(value: str) -> str:
    """Escape a value for safe interpolation into a Flux string literal."""
    return value.replace("\\", "\\\\").replace('"', '\\"')
