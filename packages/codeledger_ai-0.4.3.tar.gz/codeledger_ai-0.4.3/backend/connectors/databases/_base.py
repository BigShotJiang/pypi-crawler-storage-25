"""Shared base + helpers for database connectors.

Every concrete database connector implements four operations:

- ``test_connection``: cheap round-trip used for ``health``
- ``list_tables``: enumerate collections/tables/indices
- ``describe_table``: column / field names + types
- ``sample_rows``: parameterized SELECT * LIMIT N

This base fills in ``health``, ``search``, ``get_item``, and
``get_schema_summary`` on top of those primitives so concrete connectors
stay small and focused.

Security invariants:
- SEC-03: ``sample_rows`` is the only path that can expose row content to
  callers. ``get_item`` limits the surfaced sample to 3 rows and the
  summary is bounded by the ``ConnectorResult`` 500-char cap.
- SQL-injection defense: the default ``search`` and ``get_item`` never
  interpolate user input into SQL. Concrete connectors that do interpolate
  a table name into SQL must validate it against ``list_tables()`` first
  (see :meth:`_validate_table`).
- ``write_allowed`` is ``False`` by default and no write primitive exists
  in the abstract surface; enabling writes requires an explicit subclass
  method and (per A-1 §2) an admin-gated MCP tool that is not delivered
  in this phase.
"""

from __future__ import annotations

import asyncio
import logging
from abc import abstractmethod
from typing import TYPE_CHECKING, Any, ClassVar, TypeVar

if TYPE_CHECKING:
    from collections.abc import Callable

from backend.connectors.base import (
    AbstractConnector,
    AuthType,
    ConnectorCategory,
    ConnectorHealth,
    ConnectorResult,
    ConnectorStatus,
)

logger = logging.getLogger(__name__)

MAX_SCHEMA_TABLES = 20
MAX_SCHEMA_COLUMNS = 10
MAX_SEARCH_COLUMNS_IN_SUMMARY = 5
MAX_SAMPLE_ROWS_IN_GET_ITEM = 3
SAMPLE_VALUE_CHARS = 300


def require_driver(driver: object, slug: str, extra_name: str) -> None:
    """Raise ``RuntimeError`` with install instructions when driver is absent.

    Called from concrete connector constructors that wrap an optional
    third-party library. Keeps the install-instructions string consistent
    across connectors and keeps the import-guard pattern three lines long.
    """
    if driver is None:
        raise RuntimeError(
            f"{slug} connector requires an optional dependency. "
            f"Install with: pip install codeledger-ai[{extra_name}]"
        )


def parse_json_config(raw: str | None) -> dict[str, Any]:
    """Parse a JSON-shaped connection string into a dict. ``{}`` on failure."""
    if not raw:
        return {}
    try:
        import json

        data = json.loads(raw)
    except (ValueError, TypeError):
        return {}
    return data if isinstance(data, dict) else {}


_T = TypeVar("_T")


async def run_sync(fn: Callable[[], _T]) -> _T:
    """Run a blocking function in the default thread pool executor.

    Sync-only drivers (Databricks, Snowflake, BigQuery, ClickHouse,
    Cassandra) use this to avoid blocking the MCP event loop. Callers
    typically wrap a full connect/query/close sequence in a closure so
    the thread lifetime matches the operation lifetime.
    """
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, fn)


class AbstractDatabaseConnector(AbstractConnector):
    """Base class for SQL, NoSQL, warehouse, and time-series connectors."""

    auth_type = AuthType.CONNECTION_STRING
    category = ConnectorCategory.DATABASE
    write_allowed: ClassVar[bool] = False

    # ------------------------------------------------------------------ #
    # Driver-specific abstract surface                                   #
    # ------------------------------------------------------------------ #

    @abstractmethod
    async def test_connection(self) -> bool:
        """Return ``True`` if a trivial round-trip succeeds. Never raises."""

    @abstractmethod
    async def list_tables(self) -> list[str]:
        """Return table / collection / index names. ``[]`` on failure."""

    @abstractmethod
    async def describe_table(self, table: str) -> dict[str, Any]:
        """Return ``{"columns": [{"name": str, "type": str}, ...]}``."""

    @abstractmethod
    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        """Return up to ``limit`` rows as plain dicts. ``[]`` on failure."""

    # ------------------------------------------------------------------ #
    # Shared helpers                                                     #
    # ------------------------------------------------------------------ #

    async def _validate_table(self, table: str) -> bool:
        """``True`` iff ``table`` is in the current ``list_tables()`` output.

        Concrete connectors that splice a table name into SQL must call this
        *before* the interpolation — this is the injection boundary.
        """
        if not table or not isinstance(table, str):
            return False
        try:
            tables = await self.list_tables()
        except Exception:
            logger.warning(
                "[%s] list_tables raised during validation", self.slug,
                exc_info=True,
            )
            return False
        return table in tables

    # ------------------------------------------------------------------ #
    # Default AbstractConnector implementations                          #
    # ------------------------------------------------------------------ #

    async def health(self) -> ConnectorHealth:
        if not self.is_configured():
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.NOT_CONFIGURED,
                message="no connection string configured",
                configured=False,
            )
        try:
            ok = await self.test_connection()
        except Exception:
            logger.warning(
                "[%s] test_connection raised", self.slug, exc_info=True
            )
            ok = False
        return ConnectorHealth(
            slug=self.slug,
            status=ConnectorStatus.CONNECTED if ok else ConnectorStatus.ERROR,
            message="ok" if ok else "connection failed",
            configured=True,
        )

    async def search(
        self,
        query: str,
        project_id: str,
        max_results: int = 10,
    ) -> list[ConnectorResult]:
        try:
            tables = await self.list_tables()
        except Exception:
            return []
        if query:
            query_lower = query.lower()
            matched = [t for t in tables if query_lower in t.lower()]
        else:
            matched = list(tables)
        matched = matched[:max_results]

        results: list[ConnectorResult] = []
        for table in matched:
            try:
                desc = await self.describe_table(table)
            except Exception:
                desc = {"columns": []}
            columns = desc.get("columns") or []
            if not isinstance(columns, list):
                columns = []
            preview_names = [
                str(c.get("name", ""))
                for c in columns[:MAX_SEARCH_COLUMNS_IN_SUMMARY]
                if isinstance(c, dict)
            ]
            suffix = "…" if len(columns) > MAX_SEARCH_COLUMNS_IN_SUMMARY else ""
            summary = (
                f"{len(columns)} columns: {', '.join(preview_names)}{suffix}"
                if preview_names
                else f"{len(columns)} columns"
            )
            relevance = (
                1.0 if query and query.lower() == table.lower() else 0.5
            )
            results.append(
                ConnectorResult(
                    item_id=f"{self.slug}::{table}",
                    title=table,
                    summary=summary,
                    url=None,
                    connector_slug=self.slug,
                    item_type="table",
                    relevance_score=relevance,
                    metadata={"column_count": len(columns)},
                )
            )
        return results

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        if not item_id or "::" not in item_id:
            return None
        prefix, _, table = item_id.partition("::")
        if prefix != self.slug or not table:
            return None
        if not await self._validate_table(table):
            return None
        try:
            desc = await self.describe_table(table)
            rows = await self.sample_rows(
                table, limit=MAX_SAMPLE_ROWS_IN_GET_ITEM
            )
        except Exception:
            return None
        columns = desc.get("columns") or []
        column_count = len(columns) if isinstance(columns, list) else 0
        if rows:
            sample_summary = str(rows[0])[:SAMPLE_VALUE_CHARS]
            summary = f"{column_count} columns. Sample: {sample_summary}"
        else:
            summary = f"{column_count} columns. (empty table)"
        return ConnectorResult(
            item_id=item_id,
            title=table,
            summary=summary,
            url=None,
            connector_slug=self.slug,
            item_type="table",
            metadata={
                "column_count": column_count,
                "sample_count": len(rows),
            },
        )

    async def get_schema_summary(self) -> dict[str, Any]:
        """Compact schema snapshot for agent context injection."""
        try:
            tables = await self.list_tables()
        except Exception:
            return {"tables": []}
        summary: dict[str, Any] = {"tables": []}
        for table in tables[:MAX_SCHEMA_TABLES]:
            try:
                desc = await self.describe_table(table)
            except Exception:
                desc = {"columns": []}
            columns = desc.get("columns") or []
            if not isinstance(columns, list):
                columns = []
            col_names = [
                str(c.get("name", ""))
                for c in columns[:MAX_SCHEMA_COLUMNS]
                if isinstance(c, dict)
            ]
            summary["tables"].append(
                {"name": table, "columns": col_names}
            )
        return summary
