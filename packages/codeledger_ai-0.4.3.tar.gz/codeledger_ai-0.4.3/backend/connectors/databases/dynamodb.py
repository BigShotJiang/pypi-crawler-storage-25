"""DynamoDB connector via ``aioboto3``.

Expects JSON in ``connection_string``::

    {"region": "us-east-1",
     "access_key": "...",
     "secret_key": "...",
     "session_token": "..." (optional, for temporary creds)}

Tables map to "tables". ``describe_table`` returns the attribute
definitions (only the declared key attributes — DynamoDB is schemaless
outside those). ``sample_rows`` does a bounded ``scan``.
"""

from __future__ import annotations

import logging
from typing import Any

from backend.connectors.databases._base import (
    AbstractDatabaseConnector,
    parse_json_config,
    require_driver,
)

logger = logging.getLogger(__name__)

try:
    import aioboto3 as _driver
    _AVAILABLE = True
except ImportError:
    _driver = None
    _AVAILABLE = False


class DynamoDBConnector(AbstractDatabaseConnector):
    slug = "dynamodb"
    display_name = "AWS DynamoDB"
    description = "Query AWS DynamoDB tables (read-only by default)"

    def __init__(self, credential_manager, db=None):  # type: ignore[no-untyped-def]
        require_driver(_driver, self.slug, "dynamodb")
        super().__init__(credential_manager, db)

    def _config(self) -> dict[str, Any]:
        return parse_json_config(self._get_credential("connection_string"))

    def _session(self) -> Any:
        cfg = self._config()
        if not all(cfg.get(k) for k in ("region", "access_key", "secret_key")):
            return None
        try:
            return _driver.Session(
                aws_access_key_id=cfg["access_key"],
                aws_secret_access_key=cfg["secret_key"],
                aws_session_token=cfg.get("session_token"),
                region_name=cfg["region"],
            )
        except Exception as exc:
            logger.info(
                "[%s] session init failed: %s",
                self.slug,
                exc.__class__.__name__,
            )
            return None

    async def test_connection(self) -> bool:
        session = self._session()
        if session is None:
            return False
        try:
            async with session.client("dynamodb") as client:
                await client.list_tables(Limit=1)
                return True
        except Exception:
            return False

    async def list_tables(self) -> list[str]:
        session = self._session()
        if session is None:
            return []
        try:
            async with session.client("dynamodb") as client:
                out = await client.list_tables()
                names = out.get("TableNames") or []
                return [str(n) for n in names if isinstance(n, str)]
        except Exception:
            return []

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        session = self._session()
        if session is None:
            return {"columns": []}
        try:
            async with session.client("dynamodb") as client:
                out = await client.describe_table(TableName=table)
                attrs = (out.get("Table") or {}).get("AttributeDefinitions") or []
                return {
                    "columns": [
                        {
                            "name": str(a.get("AttributeName", "")),
                            "type": str(a.get("AttributeType", "")),
                        }
                        for a in attrs
                        if isinstance(a, dict)
                    ]
                }
        except Exception:
            return {"columns": []}

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > 1000:
            return []
        if not await self._validate_table(table):
            return []
        session = self._session()
        if session is None:
            return []
        try:
            async with session.resource("dynamodb") as resource:
                ddb_table = await resource.Table(table)
                out = await ddb_table.scan(Limit=limit)
                items = out.get("Items") or []
                return [dict(i) for i in items if isinstance(i, dict)]
        except Exception:
            return []
