r"""MySQL / MariaDB connector via ``aiomysql``.

Accepts a ``mysql://user:pass@host:port/dbname`` DSN in the vault's
``connection_string`` slot. The DSN is parsed with ``urllib.parse`` — no
DSN-specific parsing library is pulled in.

Table names are whitelist-validated against ``SHOW TABLES`` before being
spliced into ``SELECT * FROM \`{table}\` LIMIT %s``.
"""

from __future__ import annotations

import logging
from typing import Any
from urllib.parse import unquote, urlparse

from backend.connectors.databases._base import (
    AbstractDatabaseConnector,
    require_driver,
)

logger = logging.getLogger(__name__)

try:
    import aiomysql as _driver
    _AVAILABLE = True
except ImportError:
    _driver = None
    _AVAILABLE = False

_MAX_SAMPLE_LIMIT = 1000
_CONNECT_TIMEOUT_SECONDS = 10.0


class MySQLConnector(AbstractDatabaseConnector):
    slug = "mysql"
    display_name = "MySQL / MariaDB"
    description = "Query MySQL or MariaDB databases (read-only by default)"

    def __init__(self, credential_manager, db=None):  # type: ignore[no-untyped-def]
        require_driver(_driver, self.slug, "mysql")
        super().__init__(credential_manager, db)

    async def _connect(self) -> Any:
        dsn = self._get_credential("connection_string")
        if not dsn:
            return None
        params = _parse_dsn(dsn)
        if params is None:
            return None
        try:
            return await _driver.connect(
                host=params["host"],
                port=params["port"],
                user=params["user"],
                password=params["password"],
                db=params["db"],
                connect_timeout=_CONNECT_TIMEOUT_SECONDS,
                autocommit=True,
            )
        except Exception as exc:
            logger.info(
                "[%s] connect failed: %s", self.slug, exc.__class__.__name__
            )
            return None

    @staticmethod
    async def _close(conn: Any) -> None:
        if conn is None:
            return
        try:
            conn.close()
        except Exception:
            logger.debug("aiomysql close failed", exc_info=True)

    async def test_connection(self) -> bool:
        conn = await self._connect()
        if conn is None:
            return False
        try:
            async with conn.cursor() as cur:
                await cur.execute("SELECT 1")
                row = await cur.fetchone()
                return bool(row and row[0] == 1)
        except Exception:
            return False
        finally:
            await self._close(conn)

    async def list_tables(self) -> list[str]:
        conn = await self._connect()
        if conn is None:
            return []
        try:
            async with conn.cursor() as cur:
                await cur.execute("SHOW TABLES")
                rows = await cur.fetchall()
                return [str(r[0]) for r in rows if r]
        except Exception:
            return []
        finally:
            await self._close(conn)

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        conn = await self._connect()
        if conn is None:
            return {"columns": []}
        try:
            async with conn.cursor() as cur:
                await cur.execute(f"SHOW COLUMNS FROM `{table}`")
                rows = await cur.fetchall()
                return {
                    "columns": [
                        {"name": str(r[0]), "type": str(r[1])}
                        for r in rows
                        if r
                    ]
                }
        except Exception:
            return {"columns": []}
        finally:
            await self._close(conn)

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > _MAX_SAMPLE_LIMIT:
            return []
        if not await self._validate_table(table):
            return []
        conn = await self._connect()
        if conn is None:
            return []
        try:
            async with conn.cursor(_driver.DictCursor) as cur:
                await cur.execute(f"SELECT * FROM `{table}` LIMIT %s", (limit,))
                rows = await cur.fetchall()
                return [dict(r) for r in rows]
        except Exception:
            return []
        finally:
            await self._close(conn)


def _parse_dsn(dsn: str) -> dict[str, Any] | None:
    """Parse a ``mysql://user:pass@host:port/db`` DSN into kwargs.

    Returns ``None`` for malformed input; callers treat that as "not
    configured" rather than raising.
    """
    try:
        u = urlparse(dsn)
    except ValueError:
        return None
    if u.scheme not in {"mysql", "mariadb"}:
        return None
    if not u.hostname or not u.path or u.path == "/":
        return None
    return {
        "host": u.hostname,
        "port": u.port or 3306,
        "user": unquote(u.username or ""),
        "password": unquote(u.password or ""),
        "db": u.path.lstrip("/"),
    }
