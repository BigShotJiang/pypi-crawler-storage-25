"""ClickHouse connector via ``clickhouse-driver`` (sync driver).

Expects JSON in ``connection_string``::

    {"host": "localhost", "port": 9000,
     "user": "default", "password": "", "database": "default"}

All blocking driver calls go through :func:`run_sync`.
"""

from __future__ import annotations

import logging
from typing import Any

from backend.connectors.databases._base import (
    AbstractDatabaseConnector,
    parse_json_config,
    require_driver,
    run_sync,
)

logger = logging.getLogger(__name__)

try:
    from clickhouse_driver import Client as _Client
    _driver: Any = _Client
    _AVAILABLE = True
except ImportError:
    _driver = None
    _AVAILABLE = False


_DEFAULT_PORT = 9000


class ClickHouseConnector(AbstractDatabaseConnector):
    slug = "clickhouse"
    display_name = "ClickHouse"
    description = "Query ClickHouse analytical database (read-only by default)"

    def __init__(self, credential_manager, db=None):  # type: ignore[no-untyped-def]
        require_driver(_driver, self.slug, "clickhouse")
        super().__init__(credential_manager, db)

    def _config(self) -> dict[str, Any]:
        return parse_json_config(self._get_credential("connection_string"))

    def _has_connection_params(self) -> bool:
        cfg = self._config()
        return bool(cfg.get("host") and cfg.get("database"))

    def _client(self) -> Any:
        """Construct the ClickHouse ``Client``. Sync — wrap in ``run_sync``."""
        cfg = self._config()
        return _driver(
            host=cfg["host"],
            port=int(cfg.get("port") or _DEFAULT_PORT),
            user=cfg.get("user") or "default",
            password=cfg.get("password") or "",
            database=cfg["database"],
        )

    async def test_connection(self) -> bool:
        if not self._has_connection_params():
            return False

        def _sync() -> bool:
            client = self._client()
            try:
                result = client.execute("SELECT 1")
                return bool(result and result[0][0] == 1)
            finally:
                client.disconnect()

        try:
            return await run_sync(_sync)
        except Exception:
            return False

    async def list_tables(self) -> list[str]:
        if not self._has_connection_params():
            return []
        cfg = self._config()
        database = cfg["database"]

        def _sync() -> list[str]:
            client = self._client()
            try:
                rows = client.execute(
                    "SELECT name FROM system.tables WHERE database = %(db)s",
                    {"db": database},
                )
                return [str(r[0]) for r in rows if r]
            finally:
                client.disconnect()

        try:
            return await run_sync(_sync)
        except Exception:
            return []

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        cfg = self._config()
        database = cfg["database"]

        def _sync() -> list[dict[str, str]]:
            client = self._client()
            try:
                rows = client.execute(
                    "SELECT name, type FROM system.columns "
                    "WHERE database = %(db)s AND table = %(tbl)s "
                    "ORDER BY position",
                    {"db": database, "tbl": table},
                )
                return [
                    {"name": str(r[0]), "type": str(r[1])}
                    for r in rows
                    if r
                ]
            finally:
                client.disconnect()

        try:
            columns = await run_sync(_sync)
            return {"columns": columns}
        except Exception:
            return {"columns": []}

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > 1000:
            return []
        if not await self._validate_table(table):
            return []
        cfg = self._config()
        database = cfg["database"]

        def _sync() -> list[dict[str, Any]]:
            client = self._client()
            try:
                sql = f"SELECT * FROM `{database}`.`{table}` LIMIT {int(limit)}"
                rows, meta = client.execute(sql, with_column_types=True)
                col_names = [c[0] for c in meta]
                return [dict(zip(col_names, r, strict=False)) for r in rows]
            finally:
                client.disconnect()

        try:
            return await run_sync(_sync)
        except Exception:
            return []
