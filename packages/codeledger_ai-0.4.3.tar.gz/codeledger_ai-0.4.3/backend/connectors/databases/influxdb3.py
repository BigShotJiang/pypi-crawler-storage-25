"""InfluxDB 3 connector via ``influxdb3-python``.

InfluxDB 3 dropped Flux and adopted SQL. This connector only uses the
SQL query mode (``language="sql"``).

Expects JSON in ``connection_string``::

    {"host": "https://host:8086", "token": "...", "database": "..."}
"""

from __future__ import annotations

import logging
from typing import Any

from backend.connectors.databases._base import (
    AbstractDatabaseConnector,
    parse_json_config,
    require_driver,
)

logger = logging.getLogger(__name__)

try:
    from influxdb_client_3 import InfluxDBClient3 as _Client

    _driver: Any = _Client
    _AVAILABLE = True
except ImportError:
    _driver = None
    _AVAILABLE = False


class InfluxDB3Connector(AbstractDatabaseConnector):
    slug = "influxdb3"
    display_name = "InfluxDB 3"
    description = "Query InfluxDB 3 databases (SQL, not Flux)"

    def __init__(self, credential_manager, db=None):  # type: ignore[no-untyped-def]
        require_driver(_driver, self.slug, "influxdb3")
        super().__init__(credential_manager, db)

    def _client(self) -> Any:
        cfg = parse_json_config(self._get_credential("connection_string"))
        if not all(cfg.get(k) for k in ("host", "token", "database")):
            return None
        try:
            return _driver(
                host=cfg["host"], token=cfg["token"], database=cfg["database"]
            )
        except Exception as exc:
            logger.info(
                "[%s] client init failed: %s", self.slug, exc.__class__.__name__
            )
            return None

    async def test_connection(self) -> bool:
        client = self._client()
        if client is None:
            return False
        try:
            # Minimal SQL — any database supports SELECT 1
            await _run_sql(client, "SELECT 1")
            return True
        except Exception:
            return False
        finally:
            _close(client)

    async def list_tables(self) -> list[str]:
        client = self._client()
        if client is None:
            return []
        try:
            result = await _run_sql(
                client,
                "SELECT table_name FROM information_schema.tables "
                "WHERE table_schema = 'iox'",
            )
            return _column_to_list(result, "table_name")
        except Exception:
            return []
        finally:
            _close(client)

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        client = self._client()
        if client is None:
            return {"columns": []}
        try:
            result = await _run_sql(
                client,
                "SELECT column_name, data_type FROM information_schema.columns "
                "WHERE table_schema = 'iox' AND table_name = ?",
                [table],
            )
            rows = _rows_from_result(result)
            return {
                "columns": [
                    {
                        "name": str(r.get("column_name", "")),
                        "type": str(r.get("data_type", "")),
                    }
                    for r in rows
                ]
            }
        except Exception:
            return {"columns": []}
        finally:
            _close(client)

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > 1000:
            return []
        if not await self._validate_table(table):
            return []
        client = self._client()
        if client is None:
            return []
        try:
            # Table name is whitelist-validated above; limit is int-clamped.
            result = await _run_sql(
                client,
                f'SELECT * FROM "{table}" ORDER BY time DESC LIMIT {int(limit)}',
            )
            return _rows_from_result(result)
        except Exception:
            return []
        finally:
            _close(client)


async def _run_sql(client: Any, sql: str, params: list[Any] | None = None) -> Any:
    """Thin wrapper over ``client.query(..., language="sql")``.

    The InfluxDBClient3 ``.query`` method is synchronous in the official
    library but returns a PyArrow table. We keep the signature async so
    future versions (or subclasses) can override without a breaking change.
    """
    return client.query(sql, language="sql", params=params or [])


def _close(client: Any) -> None:
    if client is None:
        return
    try:
        client.close()
    except Exception:
        logger.debug("influxdb3 close failed", exc_info=True)


def _rows_from_result(result: Any) -> list[dict[str, Any]]:
    """Convert a PyArrow ``Table`` (or list-of-dicts) to plain dicts."""
    if result is None:
        return []
    if hasattr(result, "to_pylist"):
        out = result.to_pylist()
        return [row for row in out if isinstance(row, dict)]
    if isinstance(result, list):
        return [row for row in result if isinstance(row, dict)]
    return []


def _column_to_list(result: Any, column: str) -> list[str]:
    rows = _rows_from_result(result)
    return [str(r[column]) for r in rows if r.get(column)]
