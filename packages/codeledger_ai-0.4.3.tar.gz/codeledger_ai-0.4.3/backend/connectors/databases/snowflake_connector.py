"""Snowflake connector via ``snowflake-connector-python`` (sync driver).

Expects JSON in ``connection_string``::

    {"account": "xy12345.us-east-1",
     "user": "...",
     "password": "...",
     "warehouse": "COMPUTE_WH",
     "database": "ANALYTICS",
     "schema": "PUBLIC"}

All blocking driver calls go through :func:`run_sync`.
"""

from __future__ import annotations

import logging
from typing import Any

from backend.connectors.databases._base import (
    AbstractDatabaseConnector,
    parse_json_config,
    require_driver,
    run_sync,
)

logger = logging.getLogger(__name__)

try:
    import snowflake.connector as _driver
    _AVAILABLE = True
except ImportError:
    _driver = None
    _AVAILABLE = False


_REQUIRED_KEYS = ("account", "user", "password", "database", "schema")


class SnowflakeConnector(AbstractDatabaseConnector):
    slug = "snowflake"
    display_name = "Snowflake"
    description = "Query Snowflake data warehouse (read-only by default)"

    def __init__(self, credential_manager, db=None):  # type: ignore[no-untyped-def]
        require_driver(_driver, self.slug, "snowflake")
        super().__init__(credential_manager, db)

    def _config(self) -> dict[str, Any]:
        return parse_json_config(self._get_credential("connection_string"))

    def _has_connection_params(self) -> bool:
        cfg = self._config()
        return all(cfg.get(k) for k in _REQUIRED_KEYS)

    def _connect_kwargs(self) -> dict[str, Any]:
        cfg = self._config()
        kw: dict[str, Any] = {k: cfg[k] for k in _REQUIRED_KEYS}
        if cfg.get("warehouse"):
            kw["warehouse"] = cfg["warehouse"]
        if cfg.get("role"):
            kw["role"] = cfg["role"]
        return kw

    async def test_connection(self) -> bool:
        if not self._has_connection_params():
            return False
        connect_kwargs = self._connect_kwargs()

        def _sync() -> bool:
            conn = _driver.connect(**connect_kwargs)
            try:
                cur = conn.cursor()
                cur.execute("SELECT 1")
                row = cur.fetchone()
                cur.close()
                return bool(row and row[0] == 1)
            finally:
                conn.close()

        try:
            return await run_sync(_sync)
        except Exception:
            return False

    async def list_tables(self) -> list[str]:
        if not self._has_connection_params():
            return []
        cfg = self._config()
        connect_kwargs = self._connect_kwargs()
        database = cfg["database"]
        schema = cfg["schema"]

        def _sync() -> list[str]:
            conn = _driver.connect(**connect_kwargs)
            try:
                cur = conn.cursor()
                # INFORMATION_SCHEMA is the parameter-safe enumeration path.
                cur.execute(
                    "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES "
                    "WHERE TABLE_CATALOG = %s AND TABLE_SCHEMA = %s "
                    "ORDER BY TABLE_NAME",
                    (database.upper(), schema.upper()),
                )
                rows = cur.fetchall()
                cur.close()
                return [str(r[0]) for r in rows if r]
            finally:
                conn.close()

        try:
            return await run_sync(_sync)
        except Exception:
            return []

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        cfg = self._config()
        connect_kwargs = self._connect_kwargs()
        database = cfg["database"]
        schema = cfg["schema"]

        def _sync() -> list[dict[str, str]]:
            conn = _driver.connect(**connect_kwargs)
            try:
                cur = conn.cursor()
                cur.execute(
                    "SELECT COLUMN_NAME, DATA_TYPE "
                    "FROM INFORMATION_SCHEMA.COLUMNS "
                    "WHERE TABLE_CATALOG = %s AND TABLE_SCHEMA = %s "
                    "AND TABLE_NAME = %s "
                    "ORDER BY ORDINAL_POSITION",
                    (database.upper(), schema.upper(), table.upper()),
                )
                rows = cur.fetchall()
                cur.close()
                return [
                    {"name": str(r[0]), "type": str(r[1])}
                    for r in rows
                    if r
                ]
            finally:
                conn.close()

        try:
            columns = await run_sync(_sync)
            return {"columns": columns}
        except Exception:
            return {"columns": []}

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > 1000:
            return []
        if not await self._validate_table(table):
            return []
        cfg = self._config()
        connect_kwargs = self._connect_kwargs()
        database = cfg["database"]
        schema = cfg["schema"]

        def _sync() -> list[dict[str, Any]]:
            conn = _driver.connect(**connect_kwargs)
            try:
                cur = conn.cursor()
                # table name is whitelist-validated; use quoted identifier.
                cur.execute(
                    f'SELECT * FROM "{database}"."{schema}"."{table}" '
                    f"LIMIT {int(limit)}"
                )
                cols = [d[0] for d in (cur.description or [])]
                rows = cur.fetchall()
                cur.close()
                return [dict(zip(cols, r, strict=False)) for r in rows]
            finally:
                conn.close()

        try:
            return await run_sync(_sync)
        except Exception:
            return []
