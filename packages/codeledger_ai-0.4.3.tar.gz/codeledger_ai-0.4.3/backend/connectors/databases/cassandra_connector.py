"""Apache Cassandra connector via ``cassandra-driver`` (sync driver).

``cassandra-driver`` is fully blocking and has no async API; the Phase 1
audit flagged this as the single highest risk for event-loop health. Every
driver call is wrapped in :func:`run_sync` — including connection setup
and teardown — so the MCP event loop stays free.

Expects JSON in ``connection_string``::

    {"contact_points": ["10.0.0.1", "10.0.0.2"],
     "port": 9042,
     "keyspace": "app",
     "username": "...",
     "password": "..."}
"""

from __future__ import annotations

import contextlib
import logging
from typing import Any

from backend.connectors.databases._base import (
    AbstractDatabaseConnector,
    parse_json_config,
    require_driver,
    run_sync,
)

logger = logging.getLogger(__name__)

try:
    from cassandra.auth import PlainTextAuthProvider as _AuthProvider
    from cassandra.cluster import Cluster as _Cluster

    _driver: Any = _Cluster
    _auth_cls: Any = _AuthProvider
    _AVAILABLE = True
except ImportError:
    _driver = None
    _auth_cls = None
    _AVAILABLE = False


_DEFAULT_PORT = 9042


class CassandraConnector(AbstractDatabaseConnector):
    slug = "cassandra"
    display_name = "Apache Cassandra"
    description = "Query Cassandra keyspaces and tables (read-only by default)"

    def __init__(self, credential_manager, db=None):  # type: ignore[no-untyped-def]
        require_driver(_driver, self.slug, "cassandra")
        super().__init__(credential_manager, db)

    def _config(self) -> dict[str, Any]:
        return parse_json_config(self._get_credential("connection_string"))

    def _has_connection_params(self) -> bool:
        cfg = self._config()
        cp = cfg.get("contact_points")
        return bool(
            isinstance(cp, list) and cp and cfg.get("keyspace")
        )

    def _cluster_session(self) -> tuple[Any, Any] | None:
        """Construct a (cluster, session) pair. Sync — caller wraps."""
        cfg = self._config()
        auth = None
        if cfg.get("username") and cfg.get("password"):
            auth = _auth_cls(username=cfg["username"], password=cfg["password"])
        cluster = _driver(
            contact_points=cfg["contact_points"],
            port=int(cfg.get("port") or _DEFAULT_PORT),
            auth_provider=auth,
            connect_timeout=10.0,
        )
        try:
            session = cluster.connect(cfg["keyspace"])
        except Exception:
            with _suppress():
                cluster.shutdown()
            raise
        return cluster, session

    async def test_connection(self) -> bool:
        if not self._has_connection_params():
            return False

        def _sync() -> bool:
            pair = self._cluster_session()
            if pair is None:
                return False
            cluster, session = pair
            try:
                result = session.execute("SELECT now() FROM system.local")
                return any(True for _ in result)
            finally:
                with _suppress():
                    session.shutdown()
                with _suppress():
                    cluster.shutdown()

        try:
            return await run_sync(_sync)
        except Exception:
            return False

    async def list_tables(self) -> list[str]:
        if not self._has_connection_params():
            return []
        cfg = self._config()
        keyspace = cfg["keyspace"]

        def _sync() -> list[str]:
            pair = self._cluster_session()
            if pair is None:
                return []
            cluster, session = pair
            try:
                rows = session.execute(
                    "SELECT table_name FROM system_schema.tables "
                    "WHERE keyspace_name = %s",
                    [keyspace],
                )
                return [str(r.table_name) for r in rows]
            finally:
                with _suppress():
                    session.shutdown()
                with _suppress():
                    cluster.shutdown()

        try:
            return await run_sync(_sync)
        except Exception:
            return []

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        cfg = self._config()
        keyspace = cfg["keyspace"]

        def _sync() -> list[dict[str, str]]:
            pair = self._cluster_session()
            if pair is None:
                return []
            cluster, session = pair
            try:
                rows = session.execute(
                    "SELECT column_name, type FROM system_schema.columns "
                    "WHERE keyspace_name = %s AND table_name = %s",
                    [keyspace, table],
                )
                return [
                    {"name": str(r.column_name), "type": str(r.type)}
                    for r in rows
                ]
            finally:
                with _suppress():
                    session.shutdown()
                with _suppress():
                    cluster.shutdown()

        try:
            columns = await run_sync(_sync)
            return {"columns": columns}
        except Exception:
            return {"columns": []}

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > 1000:
            return []
        if not await self._validate_table(table):
            return []
        cfg = self._config()
        keyspace = cfg["keyspace"]

        def _sync() -> list[dict[str, Any]]:
            pair = self._cluster_session()
            if pair is None:
                return []
            cluster, session = pair
            try:
                # Identifier is whitelist-validated; wrap in double-quotes per CQL.
                statement = (
                    f'SELECT * FROM "{keyspace}"."{table}" LIMIT {int(limit)}'
                )
                rows = session.execute(statement)
                return [
                    dict(row._asdict()) if hasattr(row, "_asdict") else dict(row)
                    for row in rows
                ]
            finally:
                with _suppress():
                    session.shutdown()
                with _suppress():
                    cluster.shutdown()

        try:
            return await run_sync(_sync)
        except Exception:
            return []


def _suppress() -> contextlib.AbstractContextManager[None]:
    """Tiny contextlib.suppress stand-in to keep teardown errors non-fatal."""
    return contextlib.suppress(Exception)
