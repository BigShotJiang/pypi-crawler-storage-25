"""PostgreSQL connector via ``asyncpg``.

``asyncpg`` ships as the ``[postgres]`` extra on the core package so this
connector does not need an import guard — if the install includes it,
so does this connector.

SQL injection defense: table names are whitelist-validated against
``list_tables()`` before being spliced into ``SELECT * FROM "..." LIMIT $1``.
All parameter values are bound through ``asyncpg`` placeholders.
"""

from __future__ import annotations

import logging
from typing import Any

import asyncpg  # type: ignore[import-untyped]  # asyncpg ships no py.typed marker

from backend.connectors.databases._base import AbstractDatabaseConnector

logger = logging.getLogger(__name__)

_CONNECT_TIMEOUT_SECONDS = 10.0
_MAX_SAMPLE_LIMIT = 1000


class PostgreSQLConnector(AbstractDatabaseConnector):
    slug = "postgresql"
    display_name = "PostgreSQL"
    description = "Query PostgreSQL databases (read-only by default)"

    # ------------------------------------------------------------------ #
    # Connection lifecycle                                               #
    # ------------------------------------------------------------------ #

    async def _connect(self) -> asyncpg.Connection | None:
        dsn = self._get_credential("connection_string")
        if not dsn:
            return None
        try:
            return await asyncpg.connect(dsn=dsn, timeout=_CONNECT_TIMEOUT_SECONDS)
        except (asyncpg.PostgresError, OSError, TimeoutError) as exc:
            logger.info(
                "[%s] connect failed: %s", self.slug, exc.__class__.__name__
            )
            return None

    @staticmethod
    async def _close(conn: asyncpg.Connection | None) -> None:
        if conn is None:
            return
        try:
            await conn.close()
        except Exception:
            logger.debug("asyncpg close failed", exc_info=True)

    # ------------------------------------------------------------------ #
    # AbstractDatabaseConnector surface                                  #
    # ------------------------------------------------------------------ #

    async def test_connection(self) -> bool:
        conn = await self._connect()
        if conn is None:
            return False
        try:
            result = await conn.fetchval("SELECT 1")
            return bool(result == 1)
        except asyncpg.PostgresError:
            return False
        finally:
            await self._close(conn)

    async def list_tables(self) -> list[str]:
        conn = await self._connect()
        if conn is None:
            return []
        try:
            rows = await conn.fetch(
                "SELECT table_name FROM information_schema.tables "
                "WHERE table_schema = 'public' "
                "AND table_type = 'BASE TABLE' "
                "ORDER BY table_name"
            )
            return [str(r["table_name"]) for r in rows]
        except asyncpg.PostgresError:
            return []
        finally:
            await self._close(conn)

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        conn = await self._connect()
        if conn is None:
            return {"columns": []}
        try:
            rows = await conn.fetch(
                "SELECT column_name, data_type "
                "FROM information_schema.columns "
                "WHERE table_schema = 'public' AND table_name = $1 "
                "ORDER BY ordinal_position",
                table,
            )
            return {
                "columns": [
                    {
                        "name": str(r["column_name"]),
                        "type": str(r["data_type"]),
                    }
                    for r in rows
                ]
            }
        except asyncpg.PostgresError:
            return {"columns": []}
        finally:
            await self._close(conn)

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > _MAX_SAMPLE_LIMIT:
            return []
        if not await self._validate_table(table):
            return []
        conn = await self._connect()
        if conn is None:
            return []
        try:
            # Identifier is whitelist-validated above; double-quote for safety.
            rows = await conn.fetch(
                f'SELECT * FROM "{table}" LIMIT $1', limit
            )
            return [dict(r) for r in rows]
        except asyncpg.PostgresError:
            return []
        finally:
            await self._close(conn)


