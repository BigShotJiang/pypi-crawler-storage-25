"""Database connectors — SQL, NoSQL, time-series, search, warehouse.

Every connector here subclasses
:class:`backend.connectors.databases._base.AbstractDatabaseConnector`.
Read-only by default; write access is gated via the ``write_allowed``
class attribute and currently has no callers (no write methods are
defined on the base — a deliberate choice for the MVP).
"""
