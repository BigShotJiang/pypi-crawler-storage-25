"""OAuth manager supporting browser flow, device flow, and manual API keys.

Loads provider configurations from providers.toml and orchestrates OAuth 2.0
authorization flows with PKCE and CSRF protection. Access tokens are held in
memory only; refresh tokens are persisted in the credential vault.

Security invariants enforced:
- SEC-06: OAuth state parameter generated and validated on every flow (CSRF).
- SEC-06: PKCE with S256 challenge enforced when the provider requires it.
- Credentials by reference: client IDs and secrets loaded from env vars or vault.
- Access tokens never written to disk (memory-only cache).
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import logging
import os
import secrets
import tomllib
import webbrowser
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import parse_qs, urlencode, urlparse

import httpx

if TYPE_CHECKING:
    from collections.abc import Callable

    from backend.auth.credential_manager import CredentialManager

logger = logging.getLogger(__name__)


class OAuthError(Exception):
    """Raised for OAuth flow failures."""


# ---------------------------------------------------------------------------
# Provider configuration
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ProviderConfig:
    """OAuth provider settings loaded from providers.toml."""

    name: str
    display_name: str = ""
    auth_type: str = "oauth2"
    authorize_url: str = ""
    token_url: str = ""
    userinfo_url: str = ""
    scopes: list[str] = field(default_factory=list)
    use_for_identity: bool = False
    use_for_service: bool = False
    pkce: bool = False
    client_id_env: str = ""
    client_secret_env: str = ""
    device_code_url: str = ""


@dataclass
class OAuthUserInfo:
    """User profile returned after a successful OAuth flow."""

    provider: str
    provider_user_id: str
    email: str
    name: str
    avatar_url: str | None = None


@dataclass
class _TokenEntry:
    """In-memory access token with expiry tracking."""

    access_token: str
    expires_at: datetime


# ---------------------------------------------------------------------------
# Cryptographic helpers (module-level for independent testing)
# ---------------------------------------------------------------------------


def generate_state() -> str:
    """Generate a cryptographically random state parameter (CSRF protection)."""
    return secrets.token_urlsafe(32)


def generate_pkce() -> tuple[str, str]:
    """Generate PKCE code_verifier and code_challenge using S256.

    Returns:
        (code_verifier, code_challenge) tuple.
    """
    code_verifier = secrets.token_urlsafe(32)
    digest = hashlib.sha256(code_verifier.encode("ascii")).digest()
    code_challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return code_verifier, code_challenge


def build_auth_url(
    provider: ProviderConfig,
    client_id: str,
    redirect_uri: str,
    state: str,
    code_challenge: str | None = None,
) -> str:
    """Construct the OAuth authorization URL with all required parameters."""
    params: dict[str, str] = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": " ".join(provider.scopes),
        "state": state,
    }
    if code_challenge and provider.pkce:
        params["code_challenge"] = code_challenge
        params["code_challenge_method"] = "S256"
    return f"{provider.authorize_url}?{urlencode(params)}"


def load_providers(path: str | Path) -> dict[str, ProviderConfig]:
    """Load all provider configurations from a TOML file."""
    resolved = Path(path)
    if not resolved.is_file():
        logger.warning("Providers file not found: %s", resolved)
        return {}
    with open(resolved, "rb") as f:
        raw = tomllib.load(f)
    providers: dict[str, ProviderConfig] = {}
    for name, data in raw.items():
        if not isinstance(data, dict):
            continue
        providers[name] = ProviderConfig(
            name=name,
            display_name=data.get("display_name", name),
            auth_type=data.get("auth_type", "oauth2"),
            authorize_url=data.get("authorize_url", ""),
            token_url=data.get("token_url", ""),
            userinfo_url=data.get("userinfo_url", ""),
            scopes=data.get("scopes", []),
            use_for_identity=data.get("use_for_identity", False),
            use_for_service=data.get("use_for_service", False),
            pkce=data.get("pkce", True),
            client_id_env=data.get("client_id_env", ""),
            client_secret_env=data.get("client_secret_env", ""),
            device_code_url=data.get("device_code_url", ""),
        )
    return providers


# ---------------------------------------------------------------------------
# Callback server for browser OAuth flow
# ---------------------------------------------------------------------------


class _CallbackServer:
    """Temporary localhost HTTP server that receives the OAuth redirect."""

    def __init__(self) -> None:
        self.code: str | None = None
        self.state: str | None = None
        self.error: str | None = None
        self.port: int = 0
        self._server: HTTPServer | None = None

    def start(self) -> int:
        """Bind to a random port and return it."""
        outer = self

        class _Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:  # noqa: N802 — required by BaseHTTPRequestHandler API
                params = parse_qs(urlparse(self.path).query)
                outer.code = params.get("code", [None])[0]
                outer.state = params.get("state", [None])[0]
                outer.error = params.get("error", [None])[0]
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    b"<html><body>Authorization complete. You may close this tab.</body></html>"
                )

            def log_message(
                self,
                format: str,  # noqa: A002 — name comes from parent class signature
                *args: object,
            ) -> None:
                pass  # suppress default request logging

        self._server = HTTPServer(("127.0.0.1", 0), _Handler)
        self.port = self._server.server_address[1]
        return self.port

    def wait_for_callback(self, timeout: float = 300) -> None:
        """Handle exactly one request, then shut down."""
        if self._server:
            self._server.timeout = timeout
            self._server.handle_request()
            self._server.server_close()


# ---------------------------------------------------------------------------
# OAuthManager
# ---------------------------------------------------------------------------


class OAuthManager:
    """Orchestrates OAuth flows and manages access/refresh token lifecycle."""

    def __init__(
        self,
        providers: dict[str, ProviderConfig],
        credential_manager: CredentialManager,
    ) -> None:
        self._providers = providers
        self._creds = credential_manager
        self._tokens: dict[str, _TokenEntry] = {}

    def get_provider(self, name: str) -> ProviderConfig:
        """Look up a provider by name, raising OAuthError if unknown."""
        if name not in self._providers:
            raise OAuthError(f"Unknown provider: {name}")
        return self._providers[name]

    def get_client_credentials(
        self, provider: ProviderConfig
    ) -> tuple[str, str]:
        """Load client_id and client_secret from env vars or credential vault."""
        client_id = os.environ.get(provider.client_id_env, "") or (
            self._creds.get(provider.name, "client_id") or ""
        )
        client_secret = os.environ.get(provider.client_secret_env, "") or (
            self._creds.get(provider.name, "client_secret") or ""
        )
        if not client_id:
            raise OAuthError(
                f"Client ID not found for {provider.name}. "
                f"Set {provider.client_id_env} or store via credential vault."
            )
        if not client_secret:
            raise OAuthError(
                f"Client secret not found for {provider.name}. "
                f"Set {provider.client_secret_env} or store via credential vault."
            )
        return client_id, client_secret

    # -- Browser OAuth flow ------------------------------------------------

    async def browser_flow(
        self, provider_name: str, user_id: str = "default"
    ) -> OAuthUserInfo:
        """Run the full browser-based OAuth flow with PKCE and state validation."""
        provider = self.get_provider(provider_name)
        client_id, client_secret = self.get_client_credentials(provider)

        state = generate_state()
        code_verifier: str | None = None
        code_challenge: str | None = None
        if provider.pkce:
            code_verifier, code_challenge = generate_pkce()

        callback = _CallbackServer()
        port = callback.start()
        redirect_uri = f"http://127.0.0.1:{port}/callback"

        auth_url = build_auth_url(
            provider, client_id, redirect_uri, state, code_challenge
        )
        webbrowser.open(auth_url)

        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, callback.wait_for_callback)

        if callback.state != state:
            raise OAuthError("State parameter mismatch (possible CSRF attack)")
        if callback.error:
            raise OAuthError(f"Authorization failed: {callback.error}")
        if not callback.code:
            raise OAuthError("No authorization code received")

        token_data: dict[str, str] = {
            "grant_type": "authorization_code",
            "code": callback.code,
            "redirect_uri": redirect_uri,
            "client_id": client_id,
            "client_secret": client_secret,
        }
        if code_verifier:
            token_data["code_verifier"] = code_verifier

        tokens = await self._exchange_tokens(provider.token_url, token_data)
        self._store_tokens(provider_name, user_id, tokens)
        return await self._fetch_userinfo(provider, tokens["access_token"])

    # -- Device authorization flow -----------------------------------------

    async def device_flow(
        self,
        provider_name: str,
        user_id: str = "default",
        display_fn: Callable[[str, str], None] | None = None,
        poll_interval: float = 5,
        timeout: float = 300,
    ) -> OAuthUserInfo:
        """Run the device authorization flow for headless environments."""
        provider = self.get_provider(provider_name)
        if not provider.device_code_url:
            raise OAuthError(f"Device flow not supported for {provider.name}")

        client_id, _ = self.get_client_credentials(provider)

        resp = await self._http_post(
            provider.device_code_url,
            data={"client_id": client_id, "scope": " ".join(provider.scopes)},
        )
        if resp.status_code != 200:
            raise OAuthError(f"Device code request failed: {resp.text}")

        device_data: dict[str, Any] = resp.json()
        device_code: str = device_data["device_code"]
        user_code: str = device_data["user_code"]
        verification_uri: str = device_data.get(
            "verification_uri", device_data.get("verification_url", "")
        )

        if display_fn:
            display_fn(verification_uri, user_code)

        deadline = asyncio.get_event_loop().time() + timeout
        while asyncio.get_event_loop().time() < deadline:
            await asyncio.sleep(poll_interval)
            resp = await self._http_post(
                provider.token_url,
                data={
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                    "device_code": device_code,
                    "client_id": client_id,
                },
            )
            if resp.status_code == 200:
                tokens: dict[str, Any] = resp.json()
                self._store_tokens(provider_name, user_id, tokens)
                return await self._fetch_userinfo(
                    provider, tokens["access_token"]
                )

            error = self._extract_error(resp)
            if error == "authorization_pending":
                continue
            if error == "slow_down":
                poll_interval += 5
                continue
            raise OAuthError(f"Device flow failed: {error or resp.text}")

        raise OAuthError("Device flow timed out waiting for authorization")

    # -- Manual API key ----------------------------------------------------

    def store_api_key(
        self, provider_name: str, key: str, user_id: str = "default"
    ) -> None:
        """Store a manually provided API key in the credential vault."""
        self._creds.set(provider_name, f"api_key:{user_id}", key)

    # -- Token lifecycle ---------------------------------------------------

    async def get_access_token(
        self, provider_name: str, user_id: str = "default"
    ) -> str | None:
        """Return a valid access token, refreshing automatically if expired."""
        cache_key = f"{provider_name}:{user_id}"
        entry = self._tokens.get(cache_key)
        if entry and entry.expires_at > datetime.now(UTC):
            return entry.access_token

        refresh_token = self._creds.get(
            provider_name, f"refresh_token:{user_id}"
        )
        if not refresh_token:
            return None

        provider = self.get_provider(provider_name)
        client_id, client_secret = self.get_client_credentials(provider)

        resp = await self._http_post(
            provider.token_url,
            data={
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "client_id": client_id,
                "client_secret": client_secret,
            },
        )
        if resp.status_code != 200:
            return None

        tokens: dict[str, Any] = resp.json()
        self._store_tokens(provider_name, user_id, tokens)
        return str(tokens["access_token"])

    # -- Internal helpers --------------------------------------------------

    def _store_tokens(
        self,
        provider_name: str,
        user_id: str,
        tokens: dict[str, Any],
    ) -> None:
        if tokens.get("refresh_token"):
            self._creds.set(
                provider_name,
                f"refresh_token:{user_id}",
                tokens["refresh_token"],
            )
        self._tokens[f"{provider_name}:{user_id}"] = _TokenEntry(
            access_token=tokens["access_token"],
            expires_at=datetime.now(UTC)
            + timedelta(seconds=int(tokens.get("expires_in", 3600))),
        )

    @staticmethod
    def _extract_error(resp: httpx.Response) -> str:
        content_type = resp.headers.get("content-type", "")
        if "json" in content_type:
            return str(resp.json().get("error", ""))
        return ""

    async def _exchange_tokens(
        self, token_url: str, data: dict[str, str]
    ) -> dict[str, Any]:
        resp = await self._http_post(token_url, data=data)
        if resp.status_code != 200:
            raise OAuthError(f"Token exchange failed: {resp.text}")
        result: dict[str, Any] = resp.json()
        return result

    async def _fetch_userinfo(
        self, provider: ProviderConfig, access_token: str
    ) -> OAuthUserInfo:
        resp = await self._http_get(
            provider.userinfo_url,
            headers={"Authorization": f"Bearer {access_token}"},
        )
        if resp.status_code != 200:
            raise OAuthError(f"Failed to fetch user info: {resp.text}")
        data: dict[str, Any] = resp.json()
        return OAuthUserInfo(
            provider=provider.name,
            provider_user_id=str(data.get("sub") or data.get("id", "")),
            email=data.get("email", ""),
            name=data.get("name", ""),
            avatar_url=data.get("picture") or data.get("avatar_url"),
        )

    async def _http_post(
        self,
        url: str,
        data: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        async with httpx.AsyncClient() as client:
            return await client.post(url, data=data, headers=headers)

    async def _http_get(
        self,
        url: str,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        async with httpx.AsyncClient() as client:
            return await client.get(url, headers=headers)
