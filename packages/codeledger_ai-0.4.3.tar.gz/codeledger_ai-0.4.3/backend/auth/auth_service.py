"""Authentication service: user registration, login, JWT, and PAT lifecycle.

Provides the core identity operations used by the API and MCP layers.
OAuth identity sign-in (Google, GitHub) is delegated to ``OAuthManager`` for
the token exchange; this module consumes the returned ``OAuthUserInfo`` and
upserts a user record.

Security invariants enforced:
- SEC-01: Database stores only one-way hashes — Argon2id for passwords,
  SHA-256 for PATs. No plaintext credentials persisted.
- SEC-07: Passwords are hashed with Argon2id. bcrypt and plain SHA are rejected.
- SEC-08: JWT signing key lives in the credential vault only; loaded at init,
  never written anywhere else.
- SEC-10: PAT plaintext is returned once at creation; only the SHA-256 hash is
  stored.
"""

from __future__ import annotations

import hashlib
import logging
import secrets
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

from backend.models import PersonalAccessToken, User

if TYPE_CHECKING:
    import uuid

    from backend.auth.credential_manager import CredentialManager
    from backend.auth.oauth_manager import OAuthUserInfo
    from backend.db.db_backend import DatabaseBackend

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class AuthError(Exception):
    """Raised for authentication failures (bad password, invalid token, etc.)."""


class UserExistsError(AuthError):
    """Raised when attempting to register an email that already exists."""


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AuthSettings:
    """Tunable parameters for the auth service.

    Defaults match SEC-07 and CLAUDE.md's AuthConfig spec.
    """

    jwt_expiry_hours: int = 24
    argon2_memory_cost_kb: int = 65536
    argon2_time_cost: int = 3
    argon2_parallelism: int = 4


# ---------------------------------------------------------------------------
# Token pair returned from PAT creation
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PATCreationResult:
    """Returned once when a PAT is created: plaintext + metadata."""

    plaintext: str
    record: PersonalAccessToken


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------


_JWT_ALGORITHM = "HS256"
_JWT_SIGNING_KEY_PROVIDER = "codeledger"
_JWT_SIGNING_KEY_NAME = "jwt_signing_key"


class AuthService:
    """Handles identity, password verification, JWT issuance, and PAT lifecycle."""

    def __init__(
        self,
        db: DatabaseBackend,
        credentials: CredentialManager,
        settings: AuthSettings | None = None,
        server_instance_id: str | None = None,
    ) -> None:
        self._db = db
        self._creds = credentials
        self._settings = settings or AuthSettings()
        self._hasher = PasswordHasher(
            memory_cost=self._settings.argon2_memory_cost_kb,
            time_cost=self._settings.argon2_time_cost,
            parallelism=self._settings.argon2_parallelism,
        )
        self._signing_key = self._load_or_create_signing_key()
        # Bind every JWT to the current server process. A restart
        # regenerates this id and makes pre-restart JWTs 401 immediately,
        # without rotating the vault-stored signing key (SEC-08 unchanged).
        self._server_instance_id = server_instance_id or secrets.token_urlsafe(16)

    # -- JWT signing key ---------------------------------------------------

    def _load_or_create_signing_key(self) -> str:
        """Fetch the JWT signing key from the vault, generating one if absent."""
        key = self._creds.get(_JWT_SIGNING_KEY_PROVIDER, _JWT_SIGNING_KEY_NAME)
        if key:
            return key
        new_key = secrets.token_urlsafe(64)
        self._creds.set(_JWT_SIGNING_KEY_PROVIDER, _JWT_SIGNING_KEY_NAME, new_key)
        return new_key

    # -- Email/password auth -----------------------------------------------

    async def register_email_user(
        self, email: str, name: str, password: str
    ) -> User:
        """Register a new email/password user with Argon2id-hashed password."""
        existing = await self._db.query("users", {"email": email})
        if existing:
            raise UserExistsError(f"User already exists: {email}")

        password_hash = self._hasher.hash(password)
        user = User(
            email=email,
            name=name,
            provider="local",
            password_hash=password_hash,
        )
        await self._db.insert("users", user.to_dict())
        return user

    async def login_email_user(self, email: str, password: str) -> User:
        """Verify credentials and return the user, or raise AuthError."""
        rows = await self._db.query("users", {"email": email})
        if not rows:
            # Hash a dummy password to keep timing constant against enumeration.
            self._hasher.hash("timing-constant-dummy")
            raise AuthError("Invalid email or password")

        user = User.from_dict(rows[0])
        if not user.password_hash:
            raise AuthError("Invalid email or password")

        try:
            self._hasher.verify(user.password_hash, password)
        except VerifyMismatchError as exc:
            raise AuthError("Invalid email or password") from exc

        # Re-hash if Argon2 parameters have changed (defense in depth).
        if self._hasher.check_needs_rehash(user.password_hash):
            new_hash = self._hasher.hash(password)
            await self._db.update(
                "users",
                str(user.id),
                {
                    "password_hash": new_hash,
                    "updated_at": datetime.now(UTC).isoformat(),
                },
            )

        return user

    # -- OAuth identity sign-in --------------------------------------------

    async def upsert_oauth_user(self, info: OAuthUserInfo) -> User:
        """Create or find a user from OAuth provider profile info."""
        if not info.email:
            raise AuthError("OAuth provider did not return an email")
        rows = await self._db.query("users", {"email": info.email})
        if rows:
            return User.from_dict(rows[0])

        user = User(
            email=info.email,
            name=info.name or info.email,
            provider=info.provider,
            avatar_url=info.avatar_url,
            password_hash=None,
        )
        await self._db.insert("users", user.to_dict())
        return user

    # -- JWT session tokens ------------------------------------------------

    def issue_jwt(self, user: User) -> str:
        """Create a signed JWT session token for the given user."""
        now = datetime.now(UTC)
        expiry = now + timedelta(hours=self._settings.jwt_expiry_hours)
        payload: dict[str, Any] = {
            "sub": str(user.id),
            "email": user.email,
            "iss": self._server_instance_id,
            "iat": int(now.timestamp()),
            "exp": int(expiry.timestamp()),
        }
        return jwt.encode(payload, self._signing_key, algorithm=_JWT_ALGORITHM)

    def verify_jwt(self, token: str) -> dict[str, Any]:
        """Decode and validate a JWT. Raises AuthError on failure."""
        try:
            payload: dict[str, Any] = jwt.decode(
                token, self._signing_key, algorithms=[_JWT_ALGORITHM]
            )
        except jwt.ExpiredSignatureError as exc:
            raise AuthError("JWT has expired") from exc
        except jwt.InvalidTokenError as exc:
            raise AuthError(f"Invalid JWT: {exc}") from exc
        # Reject tokens bound to a previous server process. The claim is
        # absent on legacy tokens issued before this check existed; treat
        # absence as mismatch so a deploy clears every stale session.
        if payload.get("iss") != self._server_instance_id:
            raise AuthError("server_restarted")
        return payload

    # -- Personal Access Tokens --------------------------------------------

    @staticmethod
    def _hash_pat(plaintext: str) -> str:
        """Produce the storage-safe hash for a PAT."""
        return hashlib.sha256(plaintext.encode("utf-8")).hexdigest()

    @staticmethod
    def _generate_pat_plaintext() -> str:
        """Generate a new PAT plaintext string. Prefix makes them identifiable."""
        return "cl_pat_" + secrets.token_urlsafe(32)

    async def create_pat(
        self,
        user_id: uuid.UUID,
        name: str,
        expires_at: datetime | None = None,
    ) -> PATCreationResult:
        """Create a PAT. Returns plaintext once; only the hash is persisted."""
        plaintext = self._generate_pat_plaintext()
        pat_hash = self._hash_pat(plaintext)

        record = PersonalAccessToken(
            user_id=user_id,
            name=name,
            pat_hash=pat_hash,
            expires_at=expires_at,
        )
        await self._db.insert("personal_access_tokens", record.to_dict())
        return PATCreationResult(plaintext=plaintext, record=record)

    async def validate_pat(self, plaintext: str) -> User:
        """Look up a PAT by its hash and return the owning user."""
        pat_hash = self._hash_pat(plaintext)
        rows = await self._db.query(
            "personal_access_tokens", {"pat_hash": pat_hash}
        )
        if not rows:
            raise AuthError("Invalid personal access token")

        pat = PersonalAccessToken.from_dict(rows[0])
        if pat.expires_at and pat.expires_at < datetime.now(UTC):
            raise AuthError("Personal access token has expired")

        user_rows = await self._db.query("users", {"id": str(pat.user_id)})
        if not user_rows:
            raise AuthError("Personal access token has no owner")

        # Opportunistically record last_used_at
        await self._db.update(
            "personal_access_tokens",
            str(pat.id),
            {
                "last_used_at": datetime.now(UTC).isoformat(),
                "updated_at": datetime.now(UTC).isoformat(),
            },
        )

        return User.from_dict(user_rows[0])

    async def revoke_pat(self, pat_id: uuid.UUID) -> None:
        """Delete a PAT by id."""
        await self._db.delete("personal_access_tokens", str(pat_id))
