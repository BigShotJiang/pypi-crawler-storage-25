"""Domain model dataclasses for CodeLedger.

Defines all persistent domain objects used across the system. Each model includes
UUID-based identity, UTC timestamps, and serialization to/from dict for database
storage.

Security invariants enforced:
- SEC-01: No credentials in the database. password_hash stores Argon2id hashes
  only. pat_hash stores SHA-256 hashes only. No model field carries plaintext
  secrets.
"""

from __future__ import annotations

import dataclasses
import json
import types
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Self, get_args, get_origin, get_type_hints


def _now() -> datetime:
    """Current UTC timestamp for default field values."""
    return datetime.now(UTC)


def _serialize_value(value: object) -> str | int | float | bool | None:
    """Convert a field value to a database-compatible primitive."""
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, list):
        return json.dumps(value)
    if isinstance(value, str | int | float | bool):
        return value
    return str(value)


def _unwrap_optional(hint: Any) -> Any:  # Any: type hints from get_type_hints()
    """Unwrap ``X | None`` to ``X`` for deserialization dispatch."""
    origin = get_origin(hint)
    if origin is types.UnionType:
        non_none = [a for a in get_args(hint) if a is not type(None)]
        if len(non_none) == 1:
            return non_none[0]
    return hint


def _deserialize_value(
    raw: str | int | float | bool | None,
    hint: Any,  # Any: type hints from get_type_hints()
) -> Any:  # Any: returns dynamically-typed model field values
    """Convert a database primitive back to the target Python type."""
    if raw is None:
        return None
    actual = _unwrap_optional(hint)
    if actual is uuid.UUID and isinstance(raw, str):
        return uuid.UUID(raw)
    if actual is datetime and isinstance(raw, str):
        return datetime.fromisoformat(raw)
    if get_origin(actual) is list and isinstance(raw, str):
        return json.loads(raw)
    return raw


@dataclass
class Model:
    """Base for all domain models with common identity and serialization."""

    def to_dict(self) -> dict[str, str | int | float | bool | None]:
        """Serialize all fields to database-compatible primitives."""
        return {
            f.name: _serialize_value(getattr(self, f.name))
            for f in dataclasses.fields(self)
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:  # Any: raw DB row values
        """Construct a model instance from a database row dict.

        Unknown keys are ignored. Missing keys fall back to field defaults.
        """
        hints = get_type_hints(cls)
        kwargs: dict[str, Any] = {}  # Any: dynamic construction for varied field types
        for f in dataclasses.fields(cls):
            if f.name in data:
                kwargs[f.name] = _deserialize_value(data[f.name], hints[f.name])
        return cls(**kwargs)


@dataclass
class User(Model):
    """A registered user (team mode) or implied user (solo mode)."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    email: str = ""
    name: str = ""
    provider: str = ""
    avatar_url: str | None = None
    password_hash: str | None = None
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class Decision(Model):
    """An architectural or implementation decision recorded by an agent."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    title: str = ""
    description: str = ""
    tags: list[str] = field(default_factory=list)
    status: str = "unverified"
    recorded_by_user_id: uuid.UUID | None = None
    recorded_in_session_id: uuid.UUID | None = None
    inference_status: str = "explicit"
    inference_confidence: float = 1.0
    last_accessed_at: datetime | None = None
    access_count: int = 0
    staleness_score: float = 0.0
    staleness_signals: list[str] = field(default_factory=list)
    superseded_by: str | None = None
    supersedes: str | None = None
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class Story(Model):
    """A user story or task tracked across sprints."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    title: str = ""
    description: str = ""
    acceptance_criteria: list[str] = field(default_factory=list)
    status: str = "backlog"
    points: int | None = None
    sprint_id: uuid.UUID | None = None
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class Sprint(Model):
    """A time-boxed development iteration."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    name: str = ""
    start_date: datetime | None = None
    end_date: datetime | None = None
    status: str = "planning"
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class Session(Model):
    """An active agent session tracked for conflict detection and replay."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    user_id: uuid.UUID | None = None
    agent_name: str = ""
    started_at: datetime = field(default_factory=_now)
    ended_at: datetime | None = None
    status: str = "active"
    files_touched: list[str] = field(default_factory=list)
    project_id: str | None = None
    cwd: str | None = None
    last_tool_call_at: datetime | None = None
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class ContextItem(Model):
    """A piece of context stored for semantic retrieval."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    content: str = ""
    source: str = ""
    tags: list[str] = field(default_factory=list)
    embedding_id: str | None = None
    token_count: int = 0
    session_id: uuid.UUID | None = None
    last_accessed_at: datetime | None = None
    access_count: int = 0
    staleness_score: float = 0.0
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class Verification(Model):
    """CI verification status for a decision."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    decision_id: uuid.UUID = field(default_factory=uuid.uuid4)
    status: str = "unverified"
    ci_provider: str | None = None
    ci_run_url: str | None = None
    verified_at: datetime | None = None
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class ASTChange(Model):
    """A structural code change detected by AST diffing.

    ``change_event_id`` and ``change_event_source`` are the abstraction
    that lets the same record shape cover git commits, file-watcher
    snapshots, and MCP-reported agent edits. For backward compatibility
    with pre-v3 callers, the legacy ``commit_hash`` field is still
    populated whenever the event source is ``"git_commit"``.

    ``actor_type`` and ``actor_id`` (v11) are orthogonal to the source
    and record who caused the change. See
    :mod:`backend.detection.events` for the canonical enumeration.
    Legacy v10-era rows backfill to ``actor_type='human'`` and
    ``actor_id=None``.
    """

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    commit_hash: str = ""
    file_path: str = ""
    language: str = ""
    change_type: str = ""
    entity_name: str = ""
    entity_type: str = ""
    old_signature: str | None = None
    new_signature: str | None = None
    session_id: uuid.UUID | None = None
    change_event_id: str = ""
    change_event_source: str = ""
    actor_type: str = "human"
    actor_id: str | None = None
    project_id: str = ""
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class ProvenanceEdge(Model):
    """A directed edge in the decision-to-code provenance graph."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    source_type: str = ""
    source_id: uuid.UUID = field(default_factory=uuid.uuid4)
    target_type: str = ""
    target_id: uuid.UUID = field(default_factory=uuid.uuid4)
    relationship: str = ""
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class ServiceConnection(Model):
    """An OAuth service connection for a user (e.g. GitHub, Jira, Slack)."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    user_id: uuid.UUID = field(default_factory=uuid.uuid4)
    provider: str = ""
    status: str = "disconnected"
    scopes: list[str] = field(default_factory=list)
    expires_at: datetime | None = None
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class PersonalAccessToken(Model):
    """A hashed personal access token for MCP client authentication."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    user_id: uuid.UUID = field(default_factory=uuid.uuid4)
    name: str = ""
    pat_hash: str = ""
    expires_at: datetime | None = None
    last_used_at: datetime | None = None
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class UnlinkedCommit(Model):
    """A structural git commit with no linked decision (SEC-11)."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    commit_hash: str = ""
    project_id: str = ""
    detected_at: datetime = field(default_factory=_now)
    structurally_changed_symbols: list[str] = field(default_factory=list)
    session_id: uuid.UUID | None = None
    override_reason: str | None = None
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class FileSnapshot(Model):
    """A point-in-time content snapshot used by the non-git change detector.

    ``content_hash`` is a SHA-256 of ``content`` and is used to short-circuit
    duplicate snapshots for files that have not actually changed.
    """

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    project_id: str = ""
    file_path: str = ""
    content_hash: str = ""
    content: str = ""
    snapshot_at: datetime = field(default_factory=_now)
    session_id: uuid.UUID | None = None
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class InferredDecision(Model):
    """A candidate decision inferred from session activity.

    Produced by :class:`DecisionInferrer` when ``session.end`` detects
    structural changes with no linked :class:`Decision`. Candidates are
    persisted with ``status='pending'`` and surfaced to the agent so it
    can confirm or reject them via the MCP ``decision.confirm_inferred``
    / ``decision.reject_inferred`` tools.

    ``evidence`` (guard rail GR-4) stores the list of evidence items
    that produced this candidate. Each dict has the shape
    ``{"evidence_type": str, "source_id": str, "source_type": str,
    "file_path": str, "detail": dict}``. A reviewer inspecting the
    record can see exactly why it was generated.
    """

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    session_id: uuid.UUID = field(default_factory=uuid.uuid4)
    project_id: str = ""
    candidate_title: str = ""
    candidate_description: str = ""
    candidate_tags: list[str] = field(default_factory=list)
    files_affected: list[str] = field(default_factory=list)
    inference_source: str = "ast_change"
    confidence: float = 0.0
    status: str = "pending"
    evidence: list[dict[str, Any]] = field(default_factory=list)
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class DecisionConflict(Model):
    """A detected contradiction between two decisions in the same project.

    Produced by :class:`StalenessScorer.detect_contradictions`. Stored
    in the ``decision_conflicts`` table and surfaced to the agent
    inline with ``context.get_relevant`` results and via the
    ``decision.list_conflicts`` MCP tool.
    """

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    project_id: str = ""
    decision_id_a: str = ""
    decision_id_b: str = ""
    conflict_type: str = "scope_overlap"
    confidence: float = 0.0
    description: str = ""
    detected_at: datetime = field(default_factory=_now)
    status: str = "active"
    resolved_by_decision_id: str | None = None
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class UnlinkedFileChange(Model):
    """A structural file-watcher change with no linked decision (SEC-11)."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    snapshot_id: str = ""
    file_path: str = ""
    project_id: str = ""
    detected_at: datetime = field(default_factory=_now)
    structurally_changed_symbols: list[str] = field(default_factory=list)
    session_id: uuid.UUID | None = None
    override_reason: str | None = None
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)
