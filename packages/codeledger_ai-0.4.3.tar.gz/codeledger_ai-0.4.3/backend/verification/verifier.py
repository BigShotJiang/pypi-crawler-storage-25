"""CI verification engine.

Links CI webhook results back to the decisions recorded in CodeLedger by
walking the ProvenanceEdge → ASTChange → change_event_id chain. Works
only in git mode: file-watcher projects never receive a CI webhook
because there is no commit to anchor against — these projects get a
graceful ``verification_available: false`` response instead.

Security invariants enforced:
- SEC-03: Responses never return the raw CI webhook payload.
- SEC-05: The webhook endpoint itself is authenticated by a per-provider
  webhook secret stored in the credential vault, not by a bearer token.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Literal

from backend.models import Verification

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend


ChangeDetectionBackend = Literal["git", "file_watcher"]

_VALID_STATUSES: frozenset[str] = frozenset(
    {"pending", "passed", "failed"}
)

_FILE_WATCHER_MESSAGE = (
    "CI verification requires a git repository. Run `git init` and "
    "`codeledger init --reinstall-hooks` to enable."
)


class VerifierError(Exception):
    """Raised for verifier input or persistence failures."""


class Verifier:
    """Transition decision verification status from CI webhook payloads.

    Parameters:
        db: A connected :class:`DatabaseBackend` instance.
    """

    def __init__(self, db: DatabaseBackend) -> None:
        self._db = db

    async def process_webhook(
        self,
        payload: dict[str, Any],
        provider: str,
        project_id: str,
        *,
        change_detection_backend: ChangeDetectionBackend = "git",
    ) -> dict[str, Any]:
        """Apply a CI run result to every decision linked to the commit.

        ``payload`` is a provider-neutral dict with at least:

        * ``commit_hash`` — the commit the CI run built.
        * ``status`` — one of ``"pending"``, ``"passed"``, ``"failed"``.
        * Optional ``ci_run_url`` — URL to the CI run for dashboard links.

        Returns a dict summarizing the transition. Raises
        :class:`VerifierError` for missing fields or persistence errors.
        """
        if change_detection_backend == "file_watcher":
            return self._unavailable_response()

        if not isinstance(payload, dict):
            raise VerifierError(
                f"payload must be dict, got {type(payload).__name__}"
            )
        commit_hash = str(payload.get("commit_hash", ""))
        status = str(payload.get("status", ""))
        ci_run_url = payload.get("ci_run_url")
        if not commit_hash:
            raise VerifierError("payload is missing commit_hash")
        if status not in _VALID_STATUSES:
            raise VerifierError(
                f"Invalid status {status!r}. Must be one of {sorted(_VALID_STATUSES)}"
            )

        decisions = await self._decisions_for_commit(commit_hash, project_id)
        transitioned: list[str] = []
        for decision_row in decisions:
            decision_id = str(decision_row["id"])
            new_status = self._next_status(
                str(decision_row.get("status", "unverified")), status
            )
            if new_status is None:
                continue
            await self._db.update(
                "decisions",
                decision_id,
                {
                    "status": new_status,
                    "updated_at": datetime.now(UTC).isoformat(),
                },
            )
            await self._persist_verification_record(
                decision_id=decision_id,
                status=new_status,
                provider=provider,
                ci_run_url=(
                    str(ci_run_url) if ci_run_url else None
                ),
            )
            transitioned.append(decision_id)

        return {
            "received": True,
            "commit_hash": commit_hash,
            "status": status,
            "transitioned_decisions": transitioned,
            "change_detection_backend": change_detection_backend,
        }

    async def get_status(
        self,
        decision_id: uuid.UUID | str,
        *,
        change_detection_backend: ChangeDetectionBackend = "git",
    ) -> dict[str, Any]:
        """Return the current verification status for a decision.

        File-watcher projects short-circuit with an explanatory
        ``verification_available: false`` response instead of raising.
        """
        if change_detection_backend == "file_watcher":
            return self._unavailable_response()

        row = await self._db.get_by_id(
            "decisions", str(decision_id)
        )
        if row is None:
            raise VerifierError(f"Decision not found: {decision_id}")
        return {
            "decision_id": str(decision_id),
            "status": row.get("status", "unverified"),
            "verification_available": True,
        }

    async def get_unverified(
        self,
        project_id: str,
        *,
        change_detection_backend: ChangeDetectionBackend = "git",
    ) -> dict[str, Any]:
        """List decisions whose status is not yet ``"passed"``."""
        if change_detection_backend == "file_watcher":
            return self._unavailable_response()
        return {
            "verification_available": True,
            "project_id": project_id,
            "decisions": await self._decisions_in_states(
                ("unverified", "pending", "failed")
            ),
        }

    async def get_failed(
        self,
        project_id: str,
        *,
        change_detection_backend: ChangeDetectionBackend = "git",
    ) -> dict[str, Any]:
        """List decisions whose most recent CI run failed."""
        if change_detection_backend == "file_watcher":
            return self._unavailable_response()
        return {
            "verification_available": True,
            "project_id": project_id,
            "decisions": await self._decisions_in_states(("failed",)),
        }

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _unavailable_response(self) -> dict[str, Any]:
        return {
            "verification_available": False,
            "change_detection_backend": "file_watcher",
            "message": _FILE_WATCHER_MESSAGE,
        }

    def _next_status(
        self, current: str, incoming: str
    ) -> str | None:
        """Compute the next decision status per the Phase 3 transition rules.

        * unverified → pending / passed / failed (any CI outcome)
        * pending → passed / failed (terminal result)
        * passed → pending (a re-run was triggered)
        * failed → pending (a re-run was triggered)

        Returns None when the current → incoming transition is a no-op
        (e.g. ``pending → pending``) so we don't churn updated_at.
        """
        if current == incoming:
            return None
        return incoming

    async def _decisions_for_commit(
        self, commit_hash: str, project_id: str
    ) -> list[dict[str, Any]]:
        """Walk ASTChange → ProvenanceEdge to collect decisions for ``commit_hash``."""
        ast_rows = await self._db.query(
            "ast_changes",
            where={
                "change_event_id": commit_hash,
                "change_event_source": "git_commit",
                "project_id": project_id,
            },
        )
        if not ast_rows:
            return []
        decision_ids: set[str] = set()
        for row in ast_rows:
            edges = await self._db.query(
                "provenance_edges",
                where={"target_id": str(row["id"])},
            )
            for edge in edges:
                if edge.get("source_type") == "decision":
                    decision_ids.add(str(edge["source_id"]))
        decisions: list[dict[str, Any]] = []
        for decision_id in decision_ids:
            decision_row = await self._db.get_by_id("decisions", decision_id)
            if decision_row is not None:
                decisions.append(decision_row)
        return decisions

    async def _decisions_in_states(
        self, states: tuple[str, ...]
    ) -> list[dict[str, Any]]:
        """Return decisions whose current ``status`` is one of ``states``."""
        results: list[dict[str, Any]] = []
        # ``db.query`` does not support IN clauses — issue one query per state.
        for state in states:
            rows = await self._db.query(
                "decisions", where={"status": state}
            )
            results.extend(rows)
        return results

    async def _persist_verification_record(
        self,
        *,
        decision_id: str,
        status: str,
        provider: str,
        ci_run_url: str | None,
    ) -> None:
        """Insert a :class:`Verification` row for the transition."""
        record = Verification(
            decision_id=uuid.UUID(decision_id),
            status=status,
            ci_provider=provider,
            ci_run_url=ci_run_url,
            verified_at=datetime.now(UTC) if status == "passed" else None,
        )
        try:
            await self._db.insert("verifications", record.to_dict())
        except Exception as exc:
            raise VerifierError(
                f"Failed to persist verification for {decision_id}: {exc}"
            ) from exc
