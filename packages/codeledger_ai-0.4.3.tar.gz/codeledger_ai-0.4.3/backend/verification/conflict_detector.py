"""Multi-agent conflict detector.

Tracks active agent sessions, the files each session is currently
touching, and surfaces real-time overlap warnings so two agents editing
the same file concurrently can be reconciled before divergent decisions
land in the ledger.

Conflict severity:

* ``low`` — file overlap only, no shared decision domain.
* ``medium`` — file overlap plus overlapping decisions linked to those files.
* ``high`` — file overlap plus import dependency coupling (imports of
  symbols added or modified in another active session's files).

Security invariants enforced:
- SEC-03: Conflict objects carry session IDs and file paths, never
  credentials or raw file content.
- SEC-05: This class is never called without a valid authenticated user
  session — the tool layer gates access.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend


_logger = logging.getLogger(__name__)


Severity = Literal["low", "medium", "high"]


@dataclass(frozen=True)
class Conflict:
    """A single overlap between two active sessions."""

    conflicting_session_id: str
    conflicting_agent: str
    overlapping_files: list[str]
    overlapping_decisions: list[str]
    severity: Severity


@dataclass
class _SessionTracker:
    """In-memory state for one registered session."""

    session_id: str
    project_id: str
    agent_name: str
    files: frozenset[str]
    registered_at: float = field(default_factory=time.monotonic)


class ConflictDetector:
    """Track active sessions and compute real-time conflicts between them.

    The detector keeps a small in-memory index for fast overlap checks
    (target: ≤100ms for 10 concurrent sessions) and consults the database
    only when resolving decision and import dependencies.
    """

    def __init__(self, db: DatabaseBackend) -> None:
        self._db = db
        self._sessions: dict[str, _SessionTracker] = {}

    # ------------------------------------------------------------------
    # Registration lifecycle
    # ------------------------------------------------------------------

    def register_session(
        self,
        session_id: str,
        project_id: str,
        agent_name: str,
        files: list[str],
    ) -> None:
        """Announce a session's initial file set."""
        if not session_id:
            raise ValueError("session_id must be non-empty")
        if not project_id:
            raise ValueError("project_id must be non-empty")
        self._sessions[session_id] = _SessionTracker(
            session_id=session_id,
            project_id=project_id,
            agent_name=agent_name,
            files=frozenset(files or []),
        )

    def update_session_files(
        self, session_id: str, files: list[str]
    ) -> None:
        """Replace the tracked file set for an already-registered session."""
        tracker = self._sessions.get(session_id)
        if tracker is None:
            raise ValueError(f"Unknown session_id: {session_id}")
        self._sessions[session_id] = _SessionTracker(
            session_id=tracker.session_id,
            project_id=tracker.project_id,
            agent_name=tracker.agent_name,
            files=frozenset(files or []),
            registered_at=tracker.registered_at,
        )

    def end_session(self, session_id: str) -> None:
        """Remove a session from tracking. Safe to call repeatedly."""
        self._sessions.pop(session_id, None)

    def get_active_sessions(self, project_id: str) -> list[dict[str, Any]]:
        """Return a serialisable view of every active session for the project."""
        result: list[dict[str, Any]] = []
        for tracker in self._sessions.values():
            if tracker.project_id != project_id:
                continue
            result.append(
                {
                    "session_id": tracker.session_id,
                    "agent_name": tracker.agent_name,
                    "files": sorted(tracker.files),
                    "project_id": tracker.project_id,
                }
            )
        return result

    # ------------------------------------------------------------------
    # Conflict computation
    # ------------------------------------------------------------------

    async def check_conflicts(
        self, session_id: str, project_id: str
    ) -> list[Conflict]:
        """Return a list of overlapping sessions for ``session_id``."""
        me = self._sessions.get(session_id)
        if me is None:
            return []
        if me.project_id != project_id:
            return []
        conflicts: list[Conflict] = []
        for other in self._sessions.values():
            if other.session_id == session_id:
                continue
            if other.project_id != project_id:
                continue
            overlap = sorted(me.files & other.files)
            if not overlap:
                continue
            overlapping_decisions = await self._overlapping_decisions(
                session_id, other.session_id
            )
            severity = await self._severity(
                my_files=me.files,
                other_files=other.files,
                overlapping_files=overlap,
                overlapping_decisions=overlapping_decisions,
            )
            conflicts.append(
                Conflict(
                    conflicting_session_id=other.session_id,
                    conflicting_agent=other.agent_name,
                    overlapping_files=overlap,
                    overlapping_decisions=overlapping_decisions,
                    severity=severity,
                )
            )
        return conflicts

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _overlapping_decisions(
        self, session_a: str, session_b: str
    ) -> list[str]:
        """Find decision ids recorded in either session that target the same file set."""
        decisions_a = await self._safe_query(
            "decisions", {"recorded_in_session_id": session_a}
        )
        decisions_b = await self._safe_query(
            "decisions", {"recorded_in_session_id": session_b}
        )
        ids_a = {str(d["id"]) for d in decisions_a}
        ids_b = {str(d["id"]) for d in decisions_b}
        return sorted(ids_a & ids_b)

    async def _severity(
        self,
        *,
        my_files: frozenset[str],
        other_files: frozenset[str],
        overlapping_files: list[str],
        overlapping_decisions: list[str],
    ) -> Severity:
        """Classify an overlap into low / medium / high."""
        if not overlapping_files:
            return "low"
        if await self._has_import_coupling(my_files, other_files):
            return "high"
        if overlapping_decisions:
            return "medium"
        return "low"

    async def _has_import_coupling(
        self, a: frozenset[str], b: frozenset[str]
    ) -> bool:
        """True when one side imports a symbol added/changed on the other.

        Uses ast_changes with ``change_type`` matching ``import_*`` as the
        signal — this is the tree-sitter-level import entity record.
        """
        touched_in_b = await self._imports_for_files(b)
        touched_in_a = await self._imports_for_files(a)
        return bool(touched_in_a & touched_in_b)

    async def _imports_for_files(
        self, files: frozenset[str]
    ) -> set[str]:
        """Return the set of import entity names recorded for the given files."""
        names: set[str] = set()
        for file_path in files:
            rows = await self._safe_query(
                "ast_changes", {"file_path": file_path}
            )
            for row in rows:
                if str(row.get("entity_type", "")) == "import":
                    name = str(row.get("entity_name", ""))
                    if name:
                        names.add(name)
        return names

    async def _safe_query(
        self, table: str, where: dict[str, Any]
    ) -> list[dict[str, Any]]:
        """DB query guarded to never raise out of the hot conflict path."""
        try:
            return await self._db.query(table, where=where)
        except Exception as exc:
            _logger.warning("ConflictDetector query(%s) failed: %s", table, exc)
            return []
