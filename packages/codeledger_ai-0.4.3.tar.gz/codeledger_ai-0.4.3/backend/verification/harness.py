"""Quality harness — independent sensors over commits, snapshots, sessions.

The harness produces numeric signals that feed the dashboard's session
status badges and the ``harness.score`` MCP tool. Sensors included:

* ``complexity_score`` — a crude cyclomatic proxy over the changed text.
* ``import_health`` — circular-dependency probe over the project's
  current import graph.
* ``drift_violations`` — decisions that verified but whose constraints
  are now violated; stubbed at zero until Phase 5 wires the real
  :class:`backend.advanced.drift_detector.DriftDetector`.
* ``decision_density`` — recorded decisions per structural AST change
  (per session or per project). ``0.0`` with structural changes present
  is a SEC-11 critical finding.

Security invariants enforced:
- SEC-03: ``HarnessScore`` values are numeric or small enumerated
  strings; they never carry file content or credential material.
- The harness only reads from the existing DB tables through the
  :class:`DatabaseBackend` interface — it never opens new sockets.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    import uuid

    from backend.db.db_backend import DatabaseBackend


DensityStatus = Literal["critical", "low", "adequate"]
HarnessStatusLiteral = Literal["passing", "warning", "failing"]
ChangeDetectionBackend = Literal["git", "file_watcher"]


# Bucket thresholds for decision_density.
_DENSITY_CRITICAL = 0.1
_DENSITY_LOW = 0.3


class HarnessError(Exception):
    """Raised for harness input or persistence failures."""


@dataclass(frozen=True)
class HarnessScore:
    """A single change-event (commit, snapshot, or agent report) quality snapshot."""

    change_event_id: str
    change_event_source: str
    change_detection_backend: ChangeDetectionBackend
    coverage_delta: float | None
    complexity_score: float
    import_health: float
    drift_violations: int
    decision_density: float
    decision_density_status: DensityStatus
    harness_status: HarnessStatusLiteral
    coverage_status: str = "unavailable"


# v11: bot actors author changes that do not reflect the engineering
# team's decision hygiene. Excluding them from density scoring keeps
# the harness honest when Dependabot or Renovate floods a repo.
_EXCLUDED_ACTOR_TYPES_FROM_DENSITY: frozenset[str] = frozenset(
    {"ci_bot", "webhook_bot"}
)


@dataclass(frozen=True)
class VerificationHealth:
    """VGR-6 signal: how the session acted on verified context.

    Scoring bands (the ``reason`` carries the plain-English narrative):

    * ``1.0`` / ``healthy``   — every retrieval produced only VERIFIED
      decisions (no DRIFTED, STALE, or UNVERIFIED).
    * ``0.7`` / ``warning``   — DRIFTED decisions were retrieved and the
      agent subsequently called ``drift.check`` in the same session.
    * ``0.4`` / ``critical``  — DRIFTED decisions were retrieved but
      ``drift.check`` was never called.
    * ``0.5`` / ``warning``   — majority of retrievals were STALE.
    * ``None`` / ``unavailable`` — no context retrievals observed for
      this session; the sensor cannot score.
    """

    score: float | None
    status: Literal["healthy", "warning", "critical", "unavailable"]
    reason: str
    retrievals: int
    drifted_retrievals: int
    stale_retrievals: int
    drift_check_called: bool


@dataclass(frozen=True)
class SessionHarnessScore:
    """Aggregated harness score for an entire session."""

    session_id: str
    change_detection_backend: ChangeDetectionBackend
    structural_changes: int
    decisions_recorded: int
    decision_density: float
    decision_density_status: DensityStatus
    harness_status: HarnessStatusLiteral
    session_coverage_metric: float
    per_event_scores: list[HarnessScore] = field(default_factory=list)
    verification_health: VerificationHealth | None = None


def _classify_density(density: float) -> DensityStatus:
    """Map a density value to its Phase 3 bucket."""
    if density < _DENSITY_CRITICAL:
        return "critical"
    if density < _DENSITY_LOW:
        return "low"
    return "adequate"


def _status_from_density(density_status: DensityStatus) -> HarnessStatusLiteral:
    """A critical density is an immediate failing signal."""
    if density_status == "critical":
        return "failing"
    if density_status == "low":
        return "warning"
    return "passing"


class QualityHarness:
    """Run independent quality sensors over commits, snapshots, and sessions."""

    def __init__(self, db: DatabaseBackend) -> None:
        self._db = db

    # ------------------------------------------------------------------
    # Per-event scoring
    # ------------------------------------------------------------------

    async def score_commit(
        self,
        commit_hash: str,
        project_id: str,
        *,
        change_detection_backend: ChangeDetectionBackend = "git",
    ) -> HarnessScore:
        """Score a single git commit. Only valid in git mode.

        Raises:
            ValueError: Called on a file-watcher project.
        """
        if change_detection_backend != "git":
            raise ValueError(
                "score_commit requires git backend. "
                "Use score_snapshot for file watcher projects."
            )
        return await self._score_change_event(
            change_event_id=commit_hash,
            change_event_source="git_commit",
            change_detection_backend="git",
            project_id=project_id,
        )

    async def score_snapshot(
        self,
        after_snapshot_id: str,
        project_id: str,
    ) -> HarnessScore:
        """Score a file-watcher snapshot event.

        Coverage delta is always ``None`` in this mode — there is no
        stash-based before/after state to compare against.
        """
        return await self._score_change_event(
            change_event_id=after_snapshot_id,
            change_event_source="file_snapshot",
            change_detection_backend="file_watcher",
            project_id=project_id,
        )

    async def _score_change_event(
        self,
        *,
        change_event_id: str,
        change_event_source: str,
        change_detection_backend: ChangeDetectionBackend,
        project_id: str,
    ) -> HarnessScore:
        """Shared scoring logic for commits, snapshots, and agent reports."""
        ast_rows = await self._db.query(
            "ast_changes",
            where={
                "change_event_id": change_event_id,
                "project_id": project_id,
            },
        )
        # v11: bot-authored rows (ci_bot, webhook_bot) do not count
        # toward decision density. A Dependabot commit is not a
        # decision the engineering team owes evidence for. Human and
        # agent rows continue to count.
        density_rows = [
            r for r in ast_rows
            if str(r.get("actor_type") or "human")
            not in _EXCLUDED_ACTOR_TYPES_FROM_DENSITY
        ]
        decisions_linked = await self._linked_decision_count(density_rows)
        structural_changes = len(density_rows)
        density = _safe_density(decisions_linked, structural_changes)
        density_status = _classify_density(density)

        return HarnessScore(
            change_event_id=change_event_id,
            change_event_source=change_event_source,
            change_detection_backend=change_detection_backend,
            coverage_delta=None,
            complexity_score=await self._complexity_for(ast_rows),
            import_health=1.0,  # Stub: no circular-dependency probe yet.
            drift_violations=0,  # Stub until Phase 5 wires DriftDetector.
            decision_density=density,
            decision_density_status=density_status,
            harness_status=_status_from_density(density_status),
        )

    # ------------------------------------------------------------------
    # Session aggregation
    # ------------------------------------------------------------------

    async def score_session(
        self,
        session_id: uuid.UUID | str,
        project_id: str,
        *,
        change_detection_backend: ChangeDetectionBackend = "git",
    ) -> SessionHarnessScore:
        """Aggregate harness signals across every change event in a session."""
        session_row = await self._db.get_by_id("sessions", str(session_id))
        if session_row is None:
            raise HarnessError(f"Session not found: {session_id}")

        ast_rows = await self._db.query(
            "ast_changes", where={"session_id": str(session_id)}
        )
        structural_changes = len(ast_rows)
        decisions_linked = await self._linked_decision_count(ast_rows)
        density = _safe_density(decisions_linked, structural_changes)
        density_status = _classify_density(density)

        per_event = await self._per_event_scores(
            ast_rows,
            project_id=project_id,
            change_detection_backend=change_detection_backend,
        )
        coverage_metric = await self._session_coverage_metric(project_id)
        verification_health = await self.score_verification_health(
            session_id=str(session_id), project_id=project_id
        )

        return SessionHarnessScore(
            session_id=str(session_id),
            change_detection_backend=change_detection_backend,
            structural_changes=structural_changes,
            decisions_recorded=decisions_linked,
            decision_density=density,
            decision_density_status=density_status,
            harness_status=_status_from_density(density_status),
            session_coverage_metric=coverage_metric,
            per_event_scores=per_event,
            verification_health=verification_health,
        )

    async def score_verification_health(
        self,
        *,
        session_id: str,
        project_id: str,
    ) -> VerificationHealth:
        """VGR-6: score how the session engaged with verified context.

        Mines ``session_events`` for two event types:

        - ``context_retrieval`` — one per context call, with a payload
          carrying the :func:`_summarise_verification` counts plus the
          list of drifted/stale decision ids.
        - ``tool_call`` with ``payload.tool == 'drift.check'`` — the
          agent's acknowledgement that drift was investigated.

        Returns an :class:`unavailable` signal when no retrievals are
        recorded, so a silent session does not pull down the harness.
        """
        _ = project_id  # per-project scoring reserved for future work
        retrievals = await self._db.query(
            "session_events",
            where={
                "session_id": session_id,
                "event_type": "context_retrieval",
            },
        )
        if not retrievals:
            return VerificationHealth(
                score=None,
                status="unavailable",
                reason="No context retrievals recorded for this session.",
                retrievals=0,
                drifted_retrievals=0,
                stale_retrievals=0,
                drift_check_called=False,
            )

        drifted = 0
        stale = 0
        for evt in retrievals:
            payload = _safe_payload(evt.get("payload"))
            counts = payload.get("counts") if isinstance(payload, dict) else None
            if isinstance(counts, dict):
                if int(counts.get("DRIFTED") or 0) > 0:
                    drifted += 1
                if int(counts.get("STALE") or 0) > 0:
                    stale += 1

        drift_check_called = await self._drift_check_called(session_id)
        total = len(retrievals)

        if drifted == 0 and stale == 0:
            return VerificationHealth(
                score=1.0,
                status="healthy",
                reason="All context verified — no drifted or stale decisions.",
                retrievals=total,
                drifted_retrievals=drifted,
                stale_retrievals=stale,
                drift_check_called=drift_check_called,
            )

        if drifted > 0 and drift_check_called:
            return VerificationHealth(
                score=0.7,
                status="warning",
                reason=(
                    "Drifted decisions retrieved — drift.check was called. "
                    "Resolve the flagged violations before completing the "
                    "session."
                ),
                retrievals=total,
                drifted_retrievals=drifted,
                stale_retrievals=stale,
                drift_check_called=True,
            )

        if drifted > 0:
            return VerificationHealth(
                score=0.4,
                status="critical",
                reason=(
                    "Drifted decisions retrieved — drift.check was NOT "
                    "called. Run drift.check to investigate and record "
                    "resolving decisions."
                ),
                retrievals=total,
                drifted_retrievals=drifted,
                stale_retrievals=stale,
                drift_check_called=False,
            )

        if stale * 2 >= total:
            return VerificationHealth(
                score=0.5,
                status="warning",
                reason=(
                    "Majority of retrievals surfaced STALE decisions. "
                    "Review and either confirm or supersede them."
                ),
                retrievals=total,
                drifted_retrievals=drifted,
                stale_retrievals=stale,
                drift_check_called=drift_check_called,
            )

        return VerificationHealth(
            score=0.85,
            status="healthy",
            reason="A minority of retrievals were stale; no drift observed.",
            retrievals=total,
            drifted_retrievals=drifted,
            stale_retrievals=stale,
            drift_check_called=drift_check_called,
        )

    async def _drift_check_called(self, session_id: str) -> bool:
        """True when the agent called ``drift.check`` in this session."""
        events = await self._db.query(
            "session_events",
            where={"session_id": session_id, "event_type": "tool_call"},
        )
        for evt in events:
            payload = _safe_payload(evt.get("payload"))
            tool = (
                str(payload.get("tool", "")).strip()
                if isinstance(payload, dict)
                else ""
            )
            if tool in ("drift.check", "drift_check"):
                return True
        return False

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _linked_decision_count(
        self, ast_rows: list[dict[str, Any]]
    ) -> int:
        """Count distinct decisions linked to the given AST changes."""
        decision_ids: set[str] = set()
        for row in ast_rows:
            edges = await self._db.query(
                "provenance_edges",
                where={"target_id": str(row["id"])},
            )
            for edge in edges:
                if edge.get("source_type") == "decision":
                    decision_ids.add(str(edge["source_id"]))
        return len(decision_ids)

    async def _complexity_for(
        self, ast_rows: list[dict[str, Any]]
    ) -> float:
        """Very rough complexity proxy: number of structural changes, capped."""
        if not ast_rows:
            return 0.0
        # Normalize to [0, 1]: 0 changes → 0.0; 20+ → 1.0.
        return min(len(ast_rows) / 20.0, 1.0)

    async def _session_coverage_metric(self, project_id: str) -> float:
        """Fraction of completed sessions that recorded at least one decision."""
        _ = project_id
        sessions = await self._db.query(
            "sessions", where={"status": "completed"}
        )
        if not sessions:
            return 0.0
        covered = 0
        for session in sessions:
            ast_rows = await self._db.query(
                "ast_changes", where={"session_id": str(session["id"])}
            )
            if await self._linked_decision_count(ast_rows) > 0:
                covered += 1
        return covered / len(sessions)

    async def _per_event_scores(
        self,
        ast_rows: list[dict[str, Any]],
        *,
        project_id: str,
        change_detection_backend: ChangeDetectionBackend,
    ) -> list[HarnessScore]:
        """Score each unique change event once, not once per AST row."""
        seen: set[str] = set()
        scores: list[HarnessScore] = []
        for row in ast_rows:
            event_id = str(row.get("change_event_id", ""))
            if not event_id or event_id in seen:
                continue
            seen.add(event_id)
            # Legacy rows carry ``change_event_type``; v11+ rows carry
            # ``change_event_source``. Prefer the new column.
            event_source = str(
                row.get("change_event_source")
                or row.get("change_event_type")
                or "git_commit"
            )
            if event_source == "git_commit":
                scores.append(
                    await self.score_commit(
                        event_id,
                        project_id,
                        change_detection_backend=change_detection_backend,
                    )
                )
            else:
                # file_snapshot and agent_reported both route through
                # score_snapshot — the density math is identical.
                scores.append(await self.score_snapshot(event_id, project_id))
        return scores


def _safe_density(decisions: int, changes: int) -> float:
    """Return decisions / max(changes, 1) guarded against division by zero."""
    return decisions / changes if changes > 0 else 0.0


def _safe_payload(raw: Any) -> dict[str, Any]:
    """Best-effort parse of a ``session_events`` payload column."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            loaded = json.loads(raw)
        except json.JSONDecodeError:
            return {}
        if isinstance(loaded, dict):
            return loaded
    return {}
