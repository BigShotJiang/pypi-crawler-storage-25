"""Provenance engine — walk the decision-to-code graph in both directions.

Given the provenance edges persisted by :class:`ASTTracker`, this engine
answers:

* Forward: for a decision, what change events and AST changes trace back to it?
* Reverse: for a file and entity, what decisions motivated the change?
* Dependencies: which decisions reference the same entities?
* Impact: the full (decision → change-event → AST change) graph.

All three change-event sources (``git_commit``, ``file_snapshot``,
``agent_reported``) are handled uniformly. The event label differs:
commits use their hash; snapshots render as
``"Snapshot [file_path] at [timestamp]"``; agent reports render as
``"Agent report [actor_id] at [timestamp]"``.

``ChangeEventNode`` and ``ReverseTraceResult`` carry the v11 actor
fields (``actor_type``, ``actor_id``) so consumers can distinguish
human commits, bot commits (via webhook), and agent-reported edits
without a second query.

Security invariants enforced:
- SEC-03: No credential material ever flows through provenance responses.
- SEC-01: All reads go through the validated ``DatabaseBackend`` API.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from backend.models import Decision

if TYPE_CHECKING:
    import uuid

    from backend.db.db_backend import DatabaseBackend


ChangeEventSource = Literal["git_commit", "file_snapshot", "agent_reported"]


# ---------------------------------------------------------------------------
# Dataclasses returned to callers
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ChangeEventNode:
    """A single change event (commit, snapshot, or agent report)."""

    change_event_id: str
    change_event_source: str
    label: str
    date: str
    actor_type: str = "human"
    actor_id: str | None = None
    ast_changes: list[dict[str, Any]] = field(default_factory=list)


@dataclass(frozen=True)
class ProvenanceTree:
    """The forward trace result for a decision."""

    decision: dict[str, Any]
    change_events: list[ChangeEventNode]


@dataclass(frozen=True)
class ReverseTraceResult:
    """A single (decision, change event, AST change) reverse trace row."""

    decision: dict[str, Any]
    change_event_id: str
    change_event_source: str
    change_event_label: str
    ast_change: dict[str, Any]
    confidence_score: float
    actor_type: str = "human"
    actor_id: str | None = None


class ProvenanceError(Exception):
    """Raised for provenance input or persistence failures."""


class ProvenanceEngine:
    """Answer graph queries over the persisted ProvenanceEdge records."""

    def __init__(self, db: DatabaseBackend) -> None:
        self._db = db

    # ------------------------------------------------------------------
    # Forward trace (decision → changes)
    # ------------------------------------------------------------------

    async def forward_trace(
        self, decision_id: uuid.UUID | str
    ) -> ProvenanceTree:
        """Return the decision plus every linked change event."""
        decision_row = await self._require_decision(decision_id)
        edges = await self._db.query(
            "provenance_edges",
            where={
                "source_type": "decision",
                "source_id": str(decision_id),
                "target_type": "ast_change",
            },
        )
        events: dict[str, ChangeEventNode] = {}
        ordered_keys: list[str] = []
        for edge in edges:
            change = await self._db.get_by_id(
                "ast_changes", str(edge["target_id"])
            )
            if change is None:
                continue
            event_id = _effective_event_id(change)
            event_source = _effective_event_source(change)
            if event_id not in events:
                label = _event_label(event_source, event_id, change)
                events[event_id] = ChangeEventNode(
                    change_event_id=event_id,
                    change_event_source=event_source,
                    label=label,
                    date=str(change.get("created_at") or ""),
                    actor_type=str(change.get("actor_type") or "human"),
                    actor_id=(
                        str(change.get("actor_id"))
                        if change.get("actor_id")
                        else None
                    ),
                    ast_changes=[],
                )
                ordered_keys.append(event_id)
            events[event_id].ast_changes.append(dict(change))
        return ProvenanceTree(
            decision=Decision.from_dict(decision_row).to_dict(),
            change_events=[events[k] for k in ordered_keys],
        )

    # ------------------------------------------------------------------
    # Reverse trace (file + entity → decisions)
    # ------------------------------------------------------------------

    async def reverse_trace(
        self, file_path: str, entity_name: str, project_id: str
    ) -> list[ReverseTraceResult]:
        """Find decisions that authored changes to ``file_path::entity_name``.

        The lookup matches AST changes on ``file_path`` and ``entity_name``;
        the ``project_id`` scopes multi-project installs.
        """
        if not file_path:
            raise ProvenanceError("file_path is required")
        if not entity_name:
            raise ProvenanceError("entity_name is required")
        where: dict[str, Any] = {
            "file_path": file_path,
            "entity_name": entity_name,
        }
        if project_id:
            where["project_id"] = project_id
        changes = await self._db.query(
            "ast_changes",
            where=where,
            order_by="created_at DESC",
        )
        results: list[ReverseTraceResult] = []
        for change in changes:
            edges = await self._db.query(
                "provenance_edges",
                where={
                    "target_type": "ast_change",
                    "target_id": str(change["id"]),
                    "source_type": "decision",
                },
            )
            for edge in edges:
                decision_row = await self._db.get_by_id(
                    "decisions", str(edge["source_id"])
                )
                if decision_row is None:
                    continue
                event_id = _effective_event_id(change)
                event_source = _effective_event_source(change)
                relationship = str(edge.get("relationship") or "")
                confidence = _relationship_confidence(relationship)
                results.append(
                    ReverseTraceResult(
                        decision=Decision.from_dict(decision_row).to_dict(),
                        change_event_id=event_id,
                        change_event_source=event_source,
                        change_event_label=_event_label(
                            event_source, event_id, change
                        ),
                        ast_change=dict(change),
                        confidence_score=confidence,
                        actor_type=str(change.get("actor_type") or "human"),
                        actor_id=(
                            str(change.get("actor_id"))
                            if change.get("actor_id")
                            else None
                        ),
                    )
                )
        return results

    # ------------------------------------------------------------------
    # Dependency and impact graphs
    # ------------------------------------------------------------------

    async def get_decision_dependencies(
        self, decision_id: uuid.UUID | str
    ) -> list[dict[str, Any]]:
        """Decisions that touched any of the same AST entities as this one."""
        await self._require_decision(decision_id)
        my_changes = await self._linked_ast_changes(str(decision_id))
        entity_keys: set[tuple[str, str]] = {
            (str(c.get("file_path")), str(c.get("entity_name")))
            for c in my_changes
            if c.get("file_path") and c.get("entity_name")
        }
        if not entity_keys:
            return []

        seen: set[str] = {str(decision_id)}
        dependencies: list[dict[str, Any]] = []
        for file_path, entity_name in entity_keys:
            rows = await self._db.query(
                "ast_changes",
                where={"file_path": file_path, "entity_name": entity_name},
            )
            for row in rows:
                edges = await self._db.query(
                    "provenance_edges",
                    where={
                        "target_type": "ast_change",
                        "target_id": str(row["id"]),
                        "source_type": "decision",
                    },
                )
                for edge in edges:
                    dep_id = str(edge["source_id"])
                    if dep_id in seen:
                        continue
                    seen.add(dep_id)
                    dep_row = await self._db.get_by_id("decisions", dep_id)
                    if dep_row is not None:
                        dependencies.append(
                            Decision.from_dict(dep_row).to_dict()
                        )
        return dependencies

    async def get_impact_graph(
        self, decision_id: uuid.UUID | str
    ) -> dict[str, Any]:
        """Full (decision → change_events → ast_changes) graph view."""
        tree = await self.forward_trace(decision_id)
        dependents = await self.get_decision_dependencies(decision_id)
        change_events_payload = [
            {
                "change_event_id": ev.change_event_id,
                "change_event_source": ev.change_event_source,
                "label": ev.label,
                "date": ev.date,
                "actor_type": ev.actor_type,
                "actor_id": ev.actor_id,
                "ast_changes": ev.ast_changes,
            }
            for ev in tree.change_events
        ]
        ast_changes_flat = [
            ast for ev in tree.change_events for ast in ev.ast_changes
        ]
        return {
            "decision": tree.decision,
            "dependents": dependents,
            "change_events": change_events_payload,
            "ast_changes": ast_changes_flat,
        }

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _require_decision(
        self, decision_id: uuid.UUID | str
    ) -> dict[str, Any]:
        row = await self._db.get_by_id("decisions", str(decision_id))
        if row is None:
            raise ProvenanceError(f"Decision not found: {decision_id}")
        return row

    async def _linked_ast_changes(
        self, decision_id: str
    ) -> list[dict[str, Any]]:
        edges = await self._db.query(
            "provenance_edges",
            where={
                "source_type": "decision",
                "source_id": decision_id,
                "target_type": "ast_change",
            },
        )
        changes: list[dict[str, Any]] = []
        for edge in edges:
            row = await self._db.get_by_id("ast_changes", str(edge["target_id"]))
            if row is not None:
                changes.append(row)
        return changes


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _effective_event_id(change: dict[str, Any]) -> str:
    """Prefer the v3 change_event_id, falling back to commit_hash for legacy rows."""
    candidate = str(change.get("change_event_id") or "")
    if candidate:
        return candidate
    return str(change.get("commit_hash") or "")


def _effective_event_source(change: dict[str, Any]) -> str:
    """Prefer the v11 change_event_source; fall back to legacy column name."""
    candidate = str(
        change.get("change_event_source")
        or change.get("change_event_type")
        or ""
    )
    return candidate if candidate else "git_commit"


def _event_label(
    change_event_source: str, change_event_id: str, change: dict[str, Any]
) -> str:
    """Render a human-readable label for a change event node."""
    if change_event_source == "file_snapshot":
        file_path = str(change.get("file_path") or "")
        timestamp = str(change.get("created_at") or "")
        return f"Snapshot {file_path} at {timestamp}".strip()
    if change_event_source == "agent_reported":
        actor = str(change.get("actor_id") or "unknown_agent")
        timestamp = str(change.get("created_at") or "")
        return f"Agent report {actor} at {timestamp}".strip()
    return f"commit {change_event_id}"


def _relationship_confidence(relationship: str) -> float:
    """Map edge relationship strings to numeric confidence scores."""
    if relationship == "touches":
        return 0.9
    if relationship == "temporally_related":
        return 0.5
    return 0.3
