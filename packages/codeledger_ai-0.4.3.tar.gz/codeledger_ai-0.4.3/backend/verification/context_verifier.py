"""Context verification layer.

Every decision retrieved via semantic search is passed through
:class:`ContextVerifier` before the :class:`ContextTriage` step. The
verifier stamps each :class:`SearchResult`'s metadata with:

- ``verification_status``       — one of the statuses defined below.
- ``verification_guidance``     — single-sentence action guidance the agent
  can surface (VGR-7).
- ``verification_drift_violations`` — at most the two most relevant
  violation dicts when the status is ``DRIFTED`` (VGR-4).
- ``verification_superseded_by_title`` — when ``SUPERSEDED``, the title of
  the decision that replaced it (VGR-5).

The wire shape stays ``list[SearchResult]`` so the existing
:class:`ContextTriage` + :func:`format_context_block` pipeline can
consume the output unchanged. The triage formatter already reads
``metadata["verification_status"]`` and an extended block renders the
guidance + drift violations.

Guard rails:
  VGR-1: Never blocks — returns ``UNVERIFIED`` on any error.
  VGR-2: Verification status explicit in each stamped metadata dict.
  VGR-3: Per-decision work capped at ``VERIFICATION_TIMEOUT_SECONDS``;
         the hot path reads only from the DB.
  VGR-4: ``DRIFTED`` decisions are kept (``include_in_context=True``)
         with violation dicts attached.
  VGR-5: ``SUPERSEDED`` decisions are filtered from ``kept_results`` and
         reported via ``VerificationOutcome.excluded``; exclusion is
         logged.
  VGR-6: :class:`QualityHarness` reads ``verification_status`` from
         context-retrieval events to score session health.
  VGR-7: Guidance per status lives in :data:`STATUS_GUIDANCE`.

Security invariants enforced:
- SEC-03: No credential values flow through this module. Only the
  domain fields on :class:`SearchResult.metadata` are echoed back.
"""

from __future__ import annotations

import asyncio
import dataclasses
import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from backend.advanced.drift_detector import DriftDetector, DriftViolation
    from backend.db.db_backend import DatabaseBackend
    from backend.intelligence.semantic_search import SearchResult


_logger = logging.getLogger(__name__)


VerificationStatus = Literal[
    "VERIFIED",
    "DRIFTED",
    "STALE",
    "SUPERSEDED",
    "UNVERIFIED",
    "INFERRED",
]


# VGR-3: per-decision budget. Each ``_verify_one`` call is wrapped in
# :func:`asyncio.wait_for` with this timeout; on timeout the item falls
# through to ``UNVERIFIED`` and the retrieval proceeds.
VERIFICATION_TIMEOUT_SECONDS: float = 0.050


# VGR-7: human-readable action guidance per status. Strings are copied
# into each stamped metadata dict so the agent can render them without
# another lookup.
STATUS_GUIDANCE: dict[VerificationStatus, str] = {
    "VERIFIED": "Follow this decision — verified against current code.",
    "DRIFTED": (
        "This decision has violations. Review drift.check for details "
        "and resolve them before following it."
    ),
    "STALE": (
        "This decision has not been referenced recently. Confirm it is "
        "still relevant before following it."
    ),
    "SUPERSEDED": (
        "Do not follow — this decision was replaced by a newer one. "
        "See the superseding decision instead."
    ),
    "UNVERIFIED": (
        "Verification unavailable — treat as guidance, not a constraint."
    ),
    "INFERRED": (
        "Inferred from code structure — not yet human-verified. Review "
        "the source evidence before following it."
    ),
}

# Items with ``decisions.staleness_score`` at or above this threshold
# are labelled ``STALE``. The figure matches the staleness scorer's own
# high-water mark used on the dashboard.
_STALE_THRESHOLD: float = 0.75


@dataclass
class VerifiedDecision:
    """In-memory view of one decision's verification outcome.

    Exposed for tests and for callers that prefer a structured form over
    the stamped-metadata wire shape. The engine itself hands back
    :class:`VerificationOutcome` where the ``kept`` field is the
    list of ready-to-triage :class:`SearchResult` objects.
    """

    decision_id: str
    title: str
    status: VerificationStatus
    relevance_score: float
    confidence: float = 0.0
    drift_violations: list[dict[str, Any]] = field(default_factory=list)
    superseded_by_id: str | None = None
    superseded_by_title: str | None = None
    staleness_score: float = 0.0
    guidance: str = ""
    include_in_context: bool = True

    def __post_init__(self) -> None:
        if not self.guidance:
            self.guidance = STATUS_GUIDANCE.get(self.status, "")
        # VGR-5
        if self.status == "SUPERSEDED":
            self.include_in_context = False


@dataclass
class VerificationOutcome:
    """What the verifier hands back to the handler layer.

    Attributes:
        kept: ``SearchResult`` list (with stamped metadata) ready to go
            into :class:`ContextTriage`. SUPERSEDED items are *not*
            here — per VGR-5.
        excluded: :class:`VerifiedDecision` records for SUPERSEDED items
            so the handler can log / surface them separately without
            needing to re-verify.
        all_verified: Full :class:`VerifiedDecision` list, one entry per
            input result, preserving order. Used by tests and by the
            harness sensor.
    """

    kept: list[SearchResult]
    excluded: list[VerifiedDecision]
    all_verified: list[VerifiedDecision]


class ContextVerifier:
    """Verify retrieved decisions against cached codebase state.

    ``staleness_scorer`` is currently unused — staleness is read
    directly from the ``decisions`` row. The parameter is kept in the
    constructor signature so future fine-grained logic (e.g. treating a
    low-confidence inferrer hit as automatically stale) can wire in
    without another constructor revision.
    """

    def __init__(
        self,
        db: DatabaseBackend,
        drift_detector: DriftDetector | None = None,
        staleness_scorer: Any = None,
    ) -> None:
        self._db = db
        self._drift_detector = drift_detector
        self._staleness_scorer = staleness_scorer

    async def verify_batch(
        self,
        results: list[SearchResult],
        *,
        project_id: str,
    ) -> VerificationOutcome:
        """Verify every decision-typed result and stamp its metadata.

        Non-decision items (stories, context items, sessions) are passed
        through unchanged with ``verification_status='UNVERIFIED'`` — we
        can only meaningfully verify domain decisions. VGR-1 means this
        method returns normally under every failure mode: DB outage,
        verifier bug, timeout.
        """
        if not results:
            return VerificationOutcome(kept=[], excluded=[], all_verified=[])

        verified: list[VerifiedDecision] = []
        kept: list[SearchResult] = []
        excluded: list[VerifiedDecision] = []

        for result in results:
            try:
                decision = await asyncio.wait_for(
                    self._verify_one(result=result, project_id=project_id),
                    timeout=VERIFICATION_TIMEOUT_SECONDS,
                )
            except TimeoutError:
                _logger.debug(
                    "verification: timeout for %s — marking UNVERIFIED",
                    result.item_id,
                )
                decision = _unverified(result)
            except Exception:
                _logger.warning(
                    "verification: error for %s — marking UNVERIFIED",
                    result.item_id,
                    exc_info=True,
                )
                decision = _unverified(result)

            verified.append(decision)
            stamped = _stamp_metadata(result=result, verified=decision)
            if decision.include_in_context:
                kept.append(stamped)
            else:
                excluded.append(decision)

        if excluded:
            _logger.info(
                "context verification excluded %d decision(s): %s",
                len(excluded),
                [d.status for d in excluded],
            )

        return VerificationOutcome(
            kept=kept, excluded=excluded, all_verified=verified
        )

    async def _verify_one(
        self, *, result: SearchResult, project_id: str
    ) -> VerifiedDecision:
        """Classify a single search result. Reads cached state only (VGR-3)."""
        if result.item_type != "decision":
            # Non-decision items still flow through the pipeline but
            # the "verified" concept only applies to architectural
            # decisions. Mark UNVERIFIED so the agent knows not to
            # treat them as constraints.
            return VerifiedDecision(
                decision_id=result.item_id,
                title=_title_of(result),
                status="UNVERIFIED",
                relevance_score=float(result.score),
            )

        # Pull the authoritative decision row — has superseded_by,
        # staleness_score, inference_status.
        try:
            row = await self._db.get_by_id("decisions", result.item_id)
        except Exception:
            row = None

        if row is None:
            # Indexed but no longer in the decisions table — the most
            # likely cause is a stale vector. Treat as UNVERIFIED so
            # downstream code doesn't hide it.
            return VerifiedDecision(
                decision_id=result.item_id,
                title=_title_of(result),
                status="UNVERIFIED",
                relevance_score=float(result.score),
            )

        title = (
            str(row.get("title") or "").strip()
            or _title_of(result)
            or result.item_id
        )
        confidence = float(row.get("inference_confidence") or 1.0)

        # Inferred — VGR-6 treats these as pending review, not as
        # constraints. Honour the ``inference_status`` bookkeeping.
        if str(row.get("inference_status") or "") == "confirmed":
            pass  # treat as a normal decision from here on
        elif str(row.get("inference_status") or "") not in ("", "explicit"):
            return VerifiedDecision(
                decision_id=result.item_id,
                title=title,
                status="INFERRED",
                relevance_score=float(result.score),
                confidence=confidence,
            )

        # VGR-5: supersession.
        superseded_by = str(row.get("superseded_by") or "").strip()
        if superseded_by:
            superseded_by_title: str | None = None
            try:
                parent = await self._db.get_by_id("decisions", superseded_by)
                if parent is not None:
                    superseded_by_title = str(parent.get("title") or "") or None
            except Exception:
                pass
            return VerifiedDecision(
                decision_id=result.item_id,
                title=title,
                status="SUPERSEDED",
                relevance_score=float(result.score),
                confidence=confidence,
                superseded_by_id=superseded_by,
                superseded_by_title=superseded_by_title,
            )

        # VGR-4: drift.
        violations: list[DriftViolation] = []
        if self._drift_detector is not None:
            try:
                violations = await self._drift_detector.get_violations_for_decision(
                    decision_id=result.item_id, project_id=project_id
                )
            except Exception:
                violations = []
        if violations:
            return VerifiedDecision(
                decision_id=result.item_id,
                title=title,
                status="DRIFTED",
                relevance_score=float(result.score),
                confidence=confidence,
                drift_violations=[
                    {
                        "file": v.violating_file,
                        "line": v.violating_line,
                        "violation": v.violation_description,
                        "severity": v.severity,
                    }
                    for v in violations[:5]
                ],
            )

        # Staleness (no further network I/O: value is on the row).
        staleness = float(row.get("staleness_score") or 0.0)
        if staleness >= _STALE_THRESHOLD:
            return VerifiedDecision(
                decision_id=result.item_id,
                title=title,
                status="STALE",
                relevance_score=float(result.score),
                confidence=confidence,
                staleness_score=staleness,
            )

        return VerifiedDecision(
            decision_id=result.item_id,
            title=title,
            status="VERIFIED",
            relevance_score=float(result.score),
            confidence=confidence,
        )


# ---------------------------------------------------------------------------
# Stamping helpers
# ---------------------------------------------------------------------------


def _title_of(result: SearchResult) -> str:
    """Extract a best-effort title from ``result.metadata``."""
    if isinstance(result.metadata, dict):
        title = result.metadata.get("title")
        if isinstance(title, str) and title.strip():
            return title.strip()
    return result.item_id


def _unverified(result: SearchResult) -> VerifiedDecision:
    """Fallback decision used when verification fails — VGR-1."""
    return VerifiedDecision(
        decision_id=result.item_id,
        title=_title_of(result),
        status="UNVERIFIED",
        relevance_score=float(result.score),
    )


def _stamp_metadata(
    *, result: SearchResult, verified: VerifiedDecision
) -> SearchResult:
    """Return a new :class:`SearchResult` with verification metadata merged in."""
    existing = (
        dict(result.metadata) if isinstance(result.metadata, dict) else {}
    )
    existing["verification_status"] = verified.status
    existing["verification_guidance"] = verified.guidance
    if verified.drift_violations:
        existing["verification_drift_violations"] = list(
            verified.drift_violations
        )
    if verified.superseded_by_title is not None:
        existing["verification_superseded_by_title"] = (
            verified.superseded_by_title
        )
    if verified.superseded_by_id is not None:
        existing["verification_superseded_by_id"] = verified.superseded_by_id
    if verified.staleness_score:
        existing["verification_staleness_score"] = round(
            verified.staleness_score, 3
        )
    return dataclasses.replace(result, metadata=existing)
