"""Agent capability profiler.

Builds an :class:`AgentProfile` for each agent name: total sessions, CI
verification pass rate (unavailable in file_watcher mode), average
harness score, strong domains (pass rate >85%) vs weak domains
(<70%), and recent session history. Feeds dashboard agent cards and the
``agent.recommend`` tool.

Minimum 5 completed sessions required before a profile is returned;
fewer produces an ``insufficient data`` response so early adoption
doesn't produce noisy statistics.

Security invariants enforced:
- SEC-01: Reads via :class:`DatabaseBackend`.
- SEC-03: Profiles carry aggregated numeric metrics and agent names
  only.
"""

from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend


_MIN_SESSIONS_FOR_PROFILE = 5
_STRONG_THRESHOLD = 0.85
_WEAK_THRESHOLD = 0.70


ChangeDetectionBackend = Literal["git", "file_watcher"]


@dataclass(frozen=True)
class AgentProfile:
    """Aggregate stats for one agent within a project."""

    agent_name: str
    project_id: str
    total_sessions: int
    verification_pass_rate: float | None
    average_harness_score: float
    strong_domains: list[str] = field(default_factory=list)
    weak_domains: list[str] = field(default_factory=list)
    session_history: list[dict[str, Any]] = field(default_factory=list)
    change_detection_backend: ChangeDetectionBackend = "git"
    insufficient_data: bool = False
    insufficient_data_note: str = ""


@dataclass(frozen=True)
class AgentRecommendation:
    """Ranked recommendation for which agent to assign a story."""

    agent_name: str
    score: float
    reason: str


class AgentProfileError(Exception):
    """Raised on profile lookup failures."""


class AgentProfiler:
    """Aggregate session and verification data into agent capability profiles."""

    def __init__(
        self,
        db: DatabaseBackend,
        change_detection_backend: ChangeDetectionBackend = "git",
    ) -> None:
        self._db = db
        self._change_detection_backend = change_detection_backend

    async def get_profile(
        self, agent_name: str, project_id: str
    ) -> AgentProfile:
        if not agent_name:
            raise AgentProfileError("agent_name must be non-empty")
        sessions = await self._completed_sessions(agent_name)
        if len(sessions) < _MIN_SESSIONS_FOR_PROFILE:
            return AgentProfile(
                agent_name=agent_name,
                project_id=project_id,
                total_sessions=len(sessions),
                verification_pass_rate=None,
                average_harness_score=0.0,
                change_detection_backend=self._change_detection_backend,
                insufficient_data=True,
                insufficient_data_note=(
                    f"Agent has {len(sessions)} completed sessions; at "
                    f"least {_MIN_SESSIONS_FOR_PROFILE} are required."
                ),
            )

        pass_rate = await self._verification_pass_rate(sessions)
        domain_rates = await self._domain_rates(sessions)
        strong = [d for d, r in domain_rates.items() if r >= _STRONG_THRESHOLD]
        weak = [d for d, r in domain_rates.items() if r < _WEAK_THRESHOLD]
        history = [
            {
                "session_id": str(s["id"]),
                "started_at": str(s.get("started_at") or ""),
                "ended_at": str(s.get("ended_at") or ""),
                "status": str(s.get("status") or ""),
            }
            for s in sessions[-10:]
        ]
        avg = await self._average_harness_score(sessions)
        return AgentProfile(
            agent_name=agent_name,
            project_id=project_id,
            total_sessions=len(sessions),
            verification_pass_rate=(
                pass_rate
                if self._change_detection_backend == "git"
                else None
            ),
            average_harness_score=avg,
            strong_domains=sorted(strong),
            weak_domains=sorted(weak),
            session_history=history,
            change_detection_backend=self._change_detection_backend,
        )

    async def get_profile_dict(
        self, agent_name: str, project_id: str
    ) -> dict[str, Any]:
        profile = await self.get_profile(agent_name, project_id)
        payload: dict[str, Any] = {
            "agent_name": profile.agent_name,
            "project_id": profile.project_id,
            "total_sessions": profile.total_sessions,
            "verification_pass_rate": profile.verification_pass_rate,
            "average_harness_score": profile.average_harness_score,
            "strong_domains": profile.strong_domains,
            "weak_domains": profile.weak_domains,
            "session_history": profile.session_history,
            "change_detection_backend": profile.change_detection_backend,
        }
        if profile.insufficient_data:
            payload["insufficient_data"] = True
            payload["note"] = profile.insufficient_data_note
        if self._change_detection_backend == "file_watcher":
            payload["verification_note"] = (
                "CI verification unavailable in file_watcher mode; "
                "verification_pass_rate is null."
            )
        return payload

    async def recommend_agent(
        self, story_id: str, project_id: str
    ) -> list[AgentRecommendation]:
        """Recommend agents ranked by domain strength for a story's tags."""
        story = await self._db.get_by_id("stories", str(story_id))
        if story is None:
            return []
        story_tags = _parse_tags(story.get("tags"))
        if not story_tags:
            story_tags = _parse_tags(story.get("acceptance_criteria"))
        # Agents we know anything about:
        agent_names = await self._known_agents()
        recommendations: list[AgentRecommendation] = []
        for agent in agent_names:
            profile = await self.get_profile(agent, project_id)
            if profile.insufficient_data:
                continue
            overlap = len(set(story_tags) & set(profile.strong_domains))
            weak_overlap = len(set(story_tags) & set(profile.weak_domains))
            score = profile.average_harness_score + 0.1 * overlap - 0.1 * weak_overlap
            reason = (
                f"Strong match on {overlap} tag(s)"
                if overlap > 0
                else "General fit"
            )
            recommendations.append(
                AgentRecommendation(
                    agent_name=agent, score=score, reason=reason
                )
            )
        recommendations.sort(key=lambda r: r.score, reverse=True)
        return recommendations

    async def get_context_adjustment(
        self, agent_name: str, story_id: str
    ) -> dict[str, Any]:
        """Advice for how to frame a story's context for a specific agent."""
        profile = await self.get_profile(agent_name, "default")
        story = await self._db.get_by_id("stories", str(story_id))
        tags = _parse_tags(story.get("tags")) if story else []
        weak_overlap = sorted(set(tags) & set(profile.weak_domains))
        strong_overlap = sorted(set(tags) & set(profile.strong_domains))
        return {
            "agent_name": agent_name,
            "story_id": str(story_id),
            "weak_domain_overlap": weak_overlap,
            "strong_domain_overlap": strong_overlap,
            "extra_context_suggested": bool(weak_overlap),
        }

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _completed_sessions(self, agent_name: str) -> list[dict[str, Any]]:
        rows = await self._db.query(
            "sessions", where={"agent_name": agent_name}
        )
        return [
            r
            for r in rows
            if str(r.get("status") or "").startswith("completed")
        ]

    async def _verification_pass_rate(
        self, sessions: list[dict[str, Any]]
    ) -> float | None:
        # Pass rate = fraction of decisions recorded in these sessions with
        # status == "passed".
        session_ids = {str(s["id"]) for s in sessions}
        if not session_ids:
            return 0.0
        passed = 0
        total = 0
        for sid in session_ids:
            decisions = await self._db.query(
                "decisions", where={"recorded_in_session_id": sid}
            )
            for d in decisions:
                total += 1
                if str(d.get("status") or "") == "passed":
                    passed += 1
        if total == 0:
            return 0.0
        return passed / total

    async def _domain_rates(
        self, sessions: list[dict[str, Any]]
    ) -> dict[str, float]:
        """Pass rate per tag across decisions recorded in these sessions."""
        session_ids = {str(s["id"]) for s in sessions}
        passed_by_tag: dict[str, int] = defaultdict(int)
        total_by_tag: dict[str, int] = defaultdict(int)
        for sid in session_ids:
            decisions = await self._db.query(
                "decisions", where={"recorded_in_session_id": sid}
            )
            for d in decisions:
                tags = _parse_tags(d.get("tags"))
                is_passed = str(d.get("status") or "") == "passed"
                for tag in tags:
                    total_by_tag[tag] += 1
                    if is_passed:
                        passed_by_tag[tag] += 1
        return {
            tag: passed_by_tag[tag] / total_by_tag[tag]
            for tag in total_by_tag
            if total_by_tag[tag] > 0
        }

    async def _average_harness_score(
        self, sessions: list[dict[str, Any]]
    ) -> float:
        # Proxy: fraction of sessions that have at least one linked decision.
        if not sessions:
            return 0.0
        with_link = 0
        for s in sessions:
            ast_rows = await self._db.query(
                "ast_changes", where={"session_id": str(s["id"])}
            )
            if not ast_rows:
                continue
            for row in ast_rows:
                edges = await self._db.query(
                    "provenance_edges",
                    where={
                        "target_type": "ast_change",
                        "target_id": str(row["id"]),
                        "source_type": "decision",
                    },
                )
                if edges:
                    with_link += 1
                    break
        return with_link / len(sessions)

    async def _known_agents(self) -> list[str]:
        rows = await self._db.query("sessions")
        return sorted(
            {str(r.get("agent_name") or "") for r in rows if r.get("agent_name")}
        )


def _parse_tags(raw: Any) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(t) for t in raw]
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                return [str(t) for t in parsed]
        except json.JSONDecodeError:
            pass
    return []
