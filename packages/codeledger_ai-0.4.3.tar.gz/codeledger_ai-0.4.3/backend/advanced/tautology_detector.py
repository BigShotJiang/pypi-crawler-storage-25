"""Tautological test detector.

Flags unit tests whose assertions are merely restating what the code does
instead of exercising acceptance criteria from a linked story. A test is
*tautological* when its assertion text has low semantic similarity to
every acceptance criterion of the nearest matching story.

Works for both change-detection backends — operates on the current file
system, not on commit history.

Security invariants enforced:
- SEC-01: All decision / story data comes through :class:`DatabaseBackend`.
- SEC-03: Flags carry file paths and short assertion summaries only.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend
    from backend.intelligence.ast_tracker import ASTTracker
    from backend.intelligence.semantic_search import SemanticSearch


_logger = logging.getLogger(__name__)


# Confidence floor for a test being considered "grounded" in a criterion.
_GROUNDED_SIMILARITY = 0.3


@dataclass(frozen=True)
class TautologyFlag:
    """A single flagged test and the story we expected it to ground against."""

    test_file: str
    test_function: str
    assertion_summary: str
    linked_story_id: str | None
    linked_acceptance_criteria: list[str]
    confidence: float
    reason: str


@dataclass(frozen=True)
class TautologyReport:
    """Result of :meth:`TautologyDetector.check_tests`."""

    project_id: str
    flags: list[TautologyFlag] = field(default_factory=list)
    inspected_tests: int = 0


# Regex matchers over Python test bodies — other languages can be added
# later without altering the public API.
_TEST_FN_RX = re.compile(
    r"^\s*(?:async\s+)?def\s+(test_[A-Za-z_0-9]+)\s*\(", re.MULTILINE
)
_ASSERTION_RX = re.compile(r"assert\s+(.+)")


class TautologyDetector:
    """Detect tests whose assertions do not relate to a story's acceptance criteria."""

    def __init__(
        self,
        db: DatabaseBackend,
        ast_tracker: ASTTracker,
        semantic_search: SemanticSearch | None = None,
    ) -> None:
        self._db = db
        self._ast_tracker = ast_tracker
        self._semantic_search = semantic_search

    async def check_tests(
        self, project_id: str, repo_path: str
    ) -> TautologyReport:
        """Inspect ``repo_path/tests`` and flag tautological tests."""
        if not project_id:
            raise ValueError("project_id must be non-empty")
        root = Path(repo_path)
        tests_dir = root / "tests"
        if not tests_dir.exists() or not tests_dir.is_dir():
            return TautologyReport(project_id=project_id)

        stories = await self._load_stories_with_criteria()
        inspected = 0
        flags: list[TautologyFlag] = []
        for test_file in tests_dir.rglob("test_*.py"):
            try:
                content = test_file.read_text(encoding="utf-8", errors="replace")
            except OSError as exc:
                _logger.warning(
                    "tautology: cannot read %s: %s", test_file, exc
                )
                continue
            rel = test_file.relative_to(root).as_posix()
            for fn_name, fn_body in _iter_test_functions(content):
                inspected += 1
                assertions = _extract_assertions(fn_body)
                if not assertions:
                    flags.append(
                        TautologyFlag(
                            test_file=rel,
                            test_function=fn_name,
                            assertion_summary="",
                            linked_story_id=None,
                            linked_acceptance_criteria=[],
                            confidence=1.0,
                            reason="Test has no assertions.",
                        )
                    )
                    continue
                summary = assertions[0][:160]
                best = _best_story_match(assertions, stories)
                if best is None:
                    flags.append(
                        TautologyFlag(
                            test_file=rel,
                            test_function=fn_name,
                            assertion_summary=summary,
                            linked_story_id=None,
                            linked_acceptance_criteria=[],
                            confidence=0.2,
                            reason=(
                                "No story with acceptance criteria "
                                "relates to these assertions."
                            ),
                        )
                    )
                    continue
                story_id, score, criteria = best
                if score < _GROUNDED_SIMILARITY:
                    flags.append(
                        TautologyFlag(
                            test_file=rel,
                            test_function=fn_name,
                            assertion_summary=summary,
                            linked_story_id=story_id,
                            linked_acceptance_criteria=criteria,
                            confidence=1.0 - score,
                            reason=(
                                f"Assertion similarity {score:.2f} is below "
                                f"the grounded threshold "
                                f"{_GROUNDED_SIMILARITY}."
                            ),
                        )
                    )
        return TautologyReport(
            project_id=project_id,
            flags=flags,
            inspected_tests=inspected,
        )

    async def check_tests_report(
        self, project_id: str, repo_path: str
    ) -> dict[str, Any]:
        """Serialisable view of :meth:`check_tests`."""
        report = await self.check_tests(project_id, repo_path)
        return {
            "project_id": report.project_id,
            "inspected_tests": report.inspected_tests,
            "flags": [
                {
                    "test_file": f.test_file,
                    "test_function": f.test_function,
                    "assertion_summary": f.assertion_summary,
                    "linked_story_id": f.linked_story_id,
                    "linked_acceptance_criteria": f.linked_acceptance_criteria,
                    "confidence": f.confidence,
                    "reason": f.reason,
                }
                for f in report.flags
            ],
        }

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _load_stories_with_criteria(self) -> list[dict[str, Any]]:
        rows = await self._db.query("stories")
        out: list[dict[str, Any]] = []
        for row in rows:
            import json

            raw = row.get("acceptance_criteria") or "[]"
            try:
                criteria = (
                    json.loads(raw) if isinstance(raw, str) else list(raw or [])
                )
            except json.JSONDecodeError:
                criteria = []
            if criteria:
                out.append(
                    {
                        "id": str(row["id"]),
                        "title": str(row.get("title") or ""),
                        "description": str(row.get("description") or ""),
                        "criteria": [str(c) for c in criteria],
                    }
                )
        return out


# ---------------------------------------------------------------------------
# Free functions
# ---------------------------------------------------------------------------


def _iter_test_functions(content: str) -> list[tuple[str, str]]:
    """Yield ``(name, body_text)`` pairs for every ``test_*`` function."""
    positions = [
        (m.group(1), m.start())
        for m in _TEST_FN_RX.finditer(content)
    ]
    if not positions:
        return []
    results: list[tuple[str, str]] = []
    for i, (name, start) in enumerate(positions):
        end = positions[i + 1][1] if i + 1 < len(positions) else len(content)
        results.append((name, content[start:end]))
    return results


def _extract_assertions(body: str) -> list[str]:
    """Return the text of every ``assert`` statement in the function body."""
    return [m.group(1).strip() for m in _ASSERTION_RX.finditer(body)]


def _best_story_match(
    assertions: list[str],
    stories: list[dict[str, Any]],
) -> tuple[str, float, list[str]] | None:
    """Return the story with the highest Jaccard similarity to the assertions.

    Returns ``(story_id, similarity_score, matched_criteria)`` or ``None``
    when no story has any acceptance criteria.
    """
    if not stories:
        return None
    assertion_blob = " ".join(assertions).lower()
    assertion_tokens = _tokenize(assertion_blob)
    if not assertion_tokens:
        return None
    best_id: str | None = None
    best_score: float = 0.0
    best_criteria: list[str] = []
    for story in stories:
        criterion_blob = " ".join(story["criteria"]).lower()
        criterion_tokens = _tokenize(criterion_blob)
        if not criterion_tokens:
            continue
        intersection = len(assertion_tokens & criterion_tokens)
        # Use overlap coefficient so short assertions with a few related
        # tokens aren't penalised by the long criterion vocabulary.
        smallest = min(len(assertion_tokens), len(criterion_tokens))
        score = intersection / smallest if smallest else 0.0
        if score > best_score:
            best_score = score
            best_id = story["id"]
            best_criteria = story["criteria"]
    if best_id is None:
        return None
    return (best_id, best_score, best_criteria)


def _tokenize(text: str) -> set[str]:
    """Lower-case word/number token set for similarity scoring."""
    tokens = {
        tok for tok in re.findall(r"[a-z_0-9]+", text.lower()) if len(tok) > 2
    }
    # A tautology check should see ``authenticated`` as related to
    # ``unauthenticated`` — strip common English prefixes when computing
    # the token set so "unauthenticated" counts as "authenticated".
    prefixes = ("un", "re", "in", "dis", "pre", "post")
    expanded = set(tokens)
    for tok in tokens:
        for p in prefixes:
            if tok.startswith(p) and len(tok) > len(p) + 2:
                expanded.add(tok[len(p) :])
    return expanded
