"""Knowledge pack export / import.

A :class:`KnowledgePack` is a portable bundle of verified decisions that
can be moved between CodeLedger installs without leaking project-local
identifiers. The exporter strips file paths, commit hashes, and
embedding IDs; only decision text, tags, status, and pre-computed
embeddings travel with the pack.

Packs are serialised as gzipped JSON for on-wire transport and for
storage as knowledge artifacts.

Backend-agnostic — identical output for git and file_watcher projects.

Security invariants enforced:
- SEC-01: The exporter validates every selected decision is already
  ``"passed"`` — exports fail loudly rather than silently smuggling
  unverified or failed decisions.
- SEC-03: File paths, session IDs, and commit hashes are stripped
  before the pack is written.
"""

from __future__ import annotations

import base64
import gzip
import json
import uuid as _uuid_mod
from contextlib import suppress
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from backend.models import Decision

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend
    from backend.intelligence.embedder import Embedder
    from backend.intelligence.semantic_search import SemanticSearch


_PACK_FORMAT_VERSION = 1


@dataclass
class KnowledgePack:
    """A portable knowledge bundle."""

    pack_name: str
    format_version: int = _PACK_FORMAT_VERSION
    created_at: str = field(
        default_factory=lambda: datetime.now(UTC).isoformat()
    )
    decisions: list[dict[str, Any]] = field(default_factory=list)
    embeddings: dict[str, list[float]] = field(default_factory=dict)
    source_project_id: str | None = None


class KnowledgePackError(Exception):
    """Raised for export/import validation failures."""


class KnowledgePackManager:
    """Export, import, serialise, and list knowledge packs."""

    def __init__(
        self,
        db: DatabaseBackend,
        semantic_search: SemanticSearch | None = None,
        embedder: Embedder | None = None,
    ) -> None:
        self._db = db
        self._semantic_search = semantic_search
        self._embedder = embedder

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    async def list_exportable(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        """Return decisions eligible for export (status == 'passed')."""
        _ = project_id
        rows = await self._db.query("decisions", where={"status": "passed"})
        return [
            {
                "id": str(r["id"]),
                "title": r.get("title", ""),
                "description": r.get("description", ""),
                "tags": _parse_tags(r.get("tags")),
                "status": r.get("status", "unverified"),
            }
            for r in rows
        ]

    async def export_pack(
        self,
        project_id: str,
        decision_ids: list[str],
        pack_name: str,
    ) -> KnowledgePack:
        """Export a named pack. Raises if any decision is unverified/failed."""
        if not pack_name:
            raise KnowledgePackError("pack_name must be non-empty")
        if not decision_ids:
            raise KnowledgePackError("At least one decision_id is required")
        pack = KnowledgePack(
            pack_name=pack_name, source_project_id=project_id
        )
        for did in decision_ids:
            row = await self._db.get_by_id("decisions", str(did))
            if row is None:
                raise KnowledgePackError(f"Decision not found: {did}")
            status = str(row.get("status") or "unverified")
            if status != "passed":
                raise KnowledgePackError(
                    f"Cannot export decision {did}: status is {status!r}, "
                    "only 'passed' decisions are exportable."
                )
            pack.decisions.append(_sanitise_decision(row))
            if self._embedder is not None:
                text = f"{row.get('title', '')}\n\n{row.get('description', '')}".strip()
                if text:
                    try:
                        vec = await self._embedder.embed_text(text)
                    except Exception:
                        vec = []
                    if vec:
                        pack.embeddings[str(did)] = list(vec)
        return pack

    # ------------------------------------------------------------------
    # Import
    # ------------------------------------------------------------------

    async def import_pack(
        self, project_id: str, pack: KnowledgePack
    ) -> dict[str, Any]:
        """Import a pack into ``project_id``. Imported decisions are tagged 'imported'."""
        if pack.format_version != _PACK_FORMAT_VERSION:
            raise KnowledgePackError(
                f"Unsupported pack format version: {pack.format_version}"
            )
        created: list[str] = []
        for payload in pack.decisions:
            tags = list(payload.get("tags", []))
            if "imported" not in tags:
                tags.append("imported")
            new_id = _uuid_mod.uuid4()
            decision = Decision(
                id=new_id,
                title=str(payload.get("title") or ""),
                description=str(payload.get("description") or ""),
                tags=tags,
                status="unverified",
            )
            await self._db.insert("decisions", decision.to_dict())
            created.append(str(new_id))
            # Propagate embedding if provided and a store is wired.
            embed = pack.embeddings.get(str(payload.get("id") or ""))
            if embed and self._semantic_search is not None:
                with suppress(Exception):
                    await self._semantic_search._vector_store.insert(
                        str(new_id),
                        list(embed),
                        {
                            "item_type": "decision",
                            "project_id": project_id,
                            "text": f"{decision.title}\n\n{decision.description}",
                            "title": decision.title,
                            "tags": tags,
                            "imported": True,
                        },
                    )
        return {
            "pack_name": pack.pack_name,
            "imported_decision_count": len(created),
            "imported_decision_ids": created,
        }

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def serialize_pack(self, pack: KnowledgePack) -> bytes:
        """Gzip-compressed JSON for on-wire/off-disk transport."""
        payload = {
            "format_version": pack.format_version,
            "pack_name": pack.pack_name,
            "created_at": pack.created_at,
            "decisions": pack.decisions,
            "embeddings": {
                did: base64.b64encode(
                    json.dumps(vec).encode("utf-8")
                ).decode("ascii")
                for did, vec in pack.embeddings.items()
            },
            "source_project_id": pack.source_project_id,
        }
        raw = json.dumps(payload, separators=(",", ":"), sort_keys=True)
        return gzip.compress(raw.encode("utf-8"))

    def deserialize_pack(self, blob: bytes) -> KnowledgePack:
        """Inverse of :meth:`serialize_pack`."""
        try:
            raw = gzip.decompress(blob).decode("utf-8")
        except OSError as exc:
            raise KnowledgePackError(f"Invalid gzip payload: {exc}") from exc
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise KnowledgePackError(f"Invalid JSON payload: {exc}") from exc

        embeddings_raw = payload.get("embeddings") or {}
        embeddings: dict[str, list[float]] = {}
        for did, encoded in embeddings_raw.items():
            try:
                embeddings[str(did)] = json.loads(
                    base64.b64decode(encoded).decode("utf-8")
                )
            except Exception as exc:
                raise KnowledgePackError(
                    f"Failed to decode embedding for {did}: {exc}"
                ) from exc

        return KnowledgePack(
            pack_name=str(payload.get("pack_name") or ""),
            format_version=int(
                payload.get("format_version", _PACK_FORMAT_VERSION)
            ),
            created_at=str(payload.get("created_at") or ""),
            decisions=list(payload.get("decisions") or []),
            embeddings=embeddings,
            source_project_id=payload.get("source_project_id"),
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


_STRIP_FIELDS = frozenset(
    {
        "recorded_by_user_id",
        "recorded_in_session_id",
        "created_at",
        "updated_at",
    }
)


def _sanitise_decision(row: dict[str, Any]) -> dict[str, Any]:
    """Drop project-local identifiers from a decision row."""
    return {
        "id": str(row.get("id") or ""),
        "title": row.get("title", ""),
        "description": row.get("description", ""),
        "tags": _parse_tags(row.get("tags")),
        "status": row.get("status", "unverified"),
    }


def _parse_tags(raw: Any) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(t) for t in raw]
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                return [str(t) for t in parsed]
        except json.JSONDecodeError:
            pass
    return []
