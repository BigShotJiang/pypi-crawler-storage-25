"""Memory staleness scorer.

Runs four independent sensors over each decision and produces a
:class:`float` staleness score in ``[0.0, 1.0]`` alongside the
human-readable signals that explain it. The caller (usually the
``decision.staleness_report`` MCP tool or the scheduled background
task in ``backend/main.py``) persists the score back to the
``decisions`` table so the semantic-search ranker and the dashboard
panel can reuse it.

Sensors:
1. Access recency — decisions not retrieved in > 30 days accrue decay.
2. Drift violation linkage — active drift violations add pressure.
3. Supersede chain — ``superseded_by`` immediately scores 1.0.
4. Codebase coverage — decisions with zero provenance edges may be
   aspirational.

Security invariants enforced:
- SEC-01: Reads go through :class:`DatabaseBackend`. No credential
  material is introduced.
- SEC-03: Signals carry short human-readable strings — never file
  content or raw credential patterns.
"""

from __future__ import annotations

import json
import math
import re
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from backend.models import DecisionConflict

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend
    from backend.intelligence.embedder import BaseEmbedder


# Cosine similarity thresholds for the semantic contradiction sensor.
_SIM_TOPIC_MIN = 0.55
_SIM_TOPIC_MAX = 0.80

_CONFIDENCE_DIRECT = 0.85
_CONFIDENCE_SCOPE_OVERLAP = 0.55
_CONFIDENCE_CONSTRAINT = 0.90

# Polarity markers that flag a direct contradiction when both appear in the
# same pair of decisions. Each tuple is (positive_marker_regex, opposing_marker_regex).
_POLARITY_PAIRS: tuple[tuple[str, str], ...] = (
    (r"\buse\b", r"\bavoid\b"),
    (r"\buse\b", r"\bdo not use\b"),
    (r"\balways\b", r"\bnever\b"),
    (r"\brequire[ds]?\b", r"\bprohibit(?:s|ed)?\b"),
    (r"\badd\b", r"\bremove\b"),
    (r"\benable\b", r"\bdisable\b"),
    (r"\ballow\b", r"\bforbid\b"),
    (r"\binclude\b", r"\bexclude\b"),
)


# Sensor caps — individual sensors contribute at most this much.
_ACCESS_RECENCY_CAP = 0.4
_DRIFT_CAP = 0.4
_DRIFT_PER_VIOLATION = 0.2
_COVERAGE_CONTRIBUTION = 0.2

# Access recency thresholds (days).
_ACCESS_RECENCY_FRESH_DAYS = 30
_ACCESS_RECENCY_MAX_DAYS = 90


class StalenessScorerError(Exception):
    """Raised on persistence or input failures."""


class StalenessScorer:
    """Combine the four staleness sensors into per-decision scores.

    When ``embedder`` is supplied, :meth:`detect_contradictions` uses it
    to compute semantic similarity between decisions. Without an embedder
    the method still works — it relies on the keyword-level polarity
    heuristic alone.
    """

    def __init__(
        self,
        db: DatabaseBackend,
        embedder: BaseEmbedder | None = None,
    ) -> None:
        self._db = db
        self._embedder = embedder

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def score_project(
        self, project_id: str
    ) -> list[tuple[str, float, list[str]]]:
        """Score every decision in the project; persist the result inline.

        Returns a list of ``(decision_id, score, signals)`` tuples. The
        caller is not required to use the return value — the scores are
        already written back to the ``decisions`` table.
        """
        _ = project_id  # reserved for multi-project installs
        decisions = await self._db.query("decisions")
        now = datetime.now(UTC)
        out: list[tuple[str, float, list[str]]] = []
        for row in decisions:
            score, signals = await self._score_row(row, now=now)
            did = str(row["id"])
            await self._persist_score(did, score, signals)
            out.append((did, score, signals))
        return out

    async def score_decision(
        self, decision_id: str
    ) -> tuple[float, list[str]]:
        """Score a single decision without touching the rest of the project."""
        row = await self._db.get_by_id("decisions", decision_id)
        if row is None:
            raise StalenessScorerError(
                f"Decision not found: {decision_id}"
            )
        now = datetime.now(UTC)
        score, signals = await self._score_row(row, now=now)
        await self._persist_score(decision_id, score, signals)
        return score, signals

    # ------------------------------------------------------------------
    # Sensor runners
    # ------------------------------------------------------------------

    async def _score_row(
        self, row: dict[str, Any], *, now: datetime
    ) -> tuple[float, list[str]]:
        signals: list[str] = []
        contributions: list[float] = []

        # Sensor 3 short-circuit — superseded decisions score 1.0 immediately.
        superseded_by = row.get("superseded_by")
        if isinstance(superseded_by, str) and superseded_by:
            return (
                1.0,
                [f"Explicitly superseded by decision {superseded_by}"],
            )

        # Sensor 1 — access recency.
        recency_score, recency_signal = _access_recency(row, now=now)
        if recency_score > 0:
            contributions.append(recency_score)
        if recency_signal:
            signals.append(recency_signal)

        # Sensor 2 — drift violation linkage.
        drift_score, drift_signals = await self._drift_contribution(row)
        if drift_score > 0:
            contributions.append(drift_score)
        signals.extend(drift_signals)

        # Sensor 4 — codebase coverage.
        coverage_score, coverage_signal = await self._coverage_contribution(row)
        if coverage_score > 0:
            contributions.append(coverage_score)
        if coverage_signal:
            signals.append(coverage_signal)

        total = min(1.0, sum(contributions))
        return total, signals

    async def _drift_contribution(
        self, row: dict[str, Any]
    ) -> tuple[float, list[str]]:
        """Sensor 2 — Phase 5 DriftViolation linkage.

        The drift_violations table does not exist in every install; when
        absent the sensor is a no-op.
        """
        try:
            rows = await self._db.execute_raw(
                "SELECT description, status FROM drift_violations "
                "WHERE decision_id = ? AND status = 'active'",
                (str(row["id"]),),
            )
        except Exception:
            return 0.0, []
        if not rows:
            return 0.0, []
        signals = [
            f"Active drift violation: {r.get('description', '')}".strip()
            for r in rows
        ]
        score = min(_DRIFT_CAP, _DRIFT_PER_VIOLATION * len(rows))
        return score, signals

    async def _coverage_contribution(
        self, row: dict[str, Any]
    ) -> tuple[float, str | None]:
        """Sensor 4 — decisions with no ProvenanceEdge may be aspirational."""
        edges = await self._db.query(
            "provenance_edges",
            where={
                "source_type": "decision",
                "source_id": str(row["id"]),
            },
        )
        if edges:
            return 0.0, None
        return (
            _COVERAGE_CONTRIBUTION,
            "No code changes linked — may be aspirational or never implemented",
        )

    # ------------------------------------------------------------------
    # Contradiction detection (Phase 3)
    # ------------------------------------------------------------------

    async def detect_contradictions(
        self, project_id: str
    ) -> list[DecisionConflict]:
        """Find pairs of decisions that contradict each other in the project.

        Two-step detection:

        1. Semantic contradiction — embed each pair; if their cosine
           similarity is in ``[0.55, 0.80]`` and both texts carry
           opposing polarity markers (``use`` vs ``avoid``, ``always``
           vs ``never``, …), flag as ``direct_contradiction`` with 0.85
           confidence. When similarity sits in the same band but no
           opposing markers are found, flag as ``scope_overlap`` at
           0.55.
        2. Constraint conflict — for pairs where both decisions extract
           module-level ``must not import`` style constraints (shared
           with :class:`DriftDetector`), flag contradicting constraints
           as ``constraint_conflict`` at 0.90.

        Persists new conflicts; returns the full active list. Repeated
        runs do not re-insert conflicts for the same ordered pair.
        """
        decisions = await self._db.query("decisions")
        decisions = [
            d
            for d in decisions
            if str(d.get("status") or "") != "superseded"
            and not d.get("superseded_by")
        ]
        if len(decisions) < 2:
            return await self._load_active_conflicts(project_id)

        existing_pairs = await self._existing_conflict_pairs(project_id)

        # Pre-compute embeddings if available.
        embeddings: dict[str, list[float]] = {}
        if self._embedder is not None:
            for d in decisions:
                did = str(d["id"])
                text = f"{d.get('title', '')}\n{d.get('description', '')}"
                try:
                    embeddings[did] = await self._embedder.embed_text(text)
                except Exception:
                    embeddings[did] = []

        new_conflicts: list[DecisionConflict] = []
        for i, row_a in enumerate(decisions):
            for row_b in decisions[i + 1 :]:
                id_a, id_b = str(row_a["id"]), str(row_b["id"])
                pair = _canonical_pair(id_a, id_b)
                if pair in existing_pairs:
                    continue

                conflict = await self._compare_pair(
                    row_a=row_a,
                    row_b=row_b,
                    embeddings=embeddings,
                    project_id=project_id,
                )
                if conflict is None:
                    continue
                await self._persist_conflict(conflict)
                new_conflicts.append(conflict)
                existing_pairs.add(pair)

        # Return all active conflicts for the project, not just newly created.
        _ = new_conflicts  # reported via return list below
        return await self._load_active_conflicts(project_id)

    async def _compare_pair(
        self,
        *,
        row_a: dict[str, Any],
        row_b: dict[str, Any],
        embeddings: dict[str, list[float]],
        project_id: str,
    ) -> DecisionConflict | None:
        """Return a DecisionConflict for ``row_a`` vs ``row_b`` if one exists."""
        id_a, id_b = str(row_a["id"]), str(row_b["id"])
        text_a = f"{row_a.get('title', '')}\n{row_a.get('description', '')}"
        text_b = f"{row_b.get('title', '')}\n{row_b.get('description', '')}"
        title_a = str(row_a.get("title", "")) or id_a
        title_b = str(row_b.get("title", "")) or id_b

        # Sensor 2 (constraint conflict) runs first — it has higher
        # confidence and the cheaper signal to compute.
        constraint_description = _constraint_conflict(text_a, text_b)
        if constraint_description is not None:
            return DecisionConflict(
                project_id=project_id,
                decision_id_a=id_a,
                decision_id_b=id_b,
                conflict_type="constraint_conflict",
                confidence=_CONFIDENCE_CONSTRAINT,
                description=(
                    f"Constraint conflict between '{title_a}' and "
                    f"'{title_b}': {constraint_description}"
                ),
            )

        # Sensor 1 (semantic contradiction) — requires embeddings.
        vec_a = embeddings.get(id_a) or []
        vec_b = embeddings.get(id_b) or []
        similarity = _cosine(vec_a, vec_b) if vec_a and vec_b else 0.0
        if vec_a and vec_b and not (
            _SIM_TOPIC_MIN <= similarity <= _SIM_TOPIC_MAX
        ):
            return None
        # When no embedder is available, still let polarity alone flag
        # strong contradictions — but only if the texts also share a
        # distinctive keyword token so we don't flag unrelated decisions.
        if (not vec_a or not vec_b) and not _shares_content_token(
            text_a, text_b
        ):
            return None

        if _has_opposing_polarity(text_a, text_b):
            return DecisionConflict(
                project_id=project_id,
                decision_id_a=id_a,
                decision_id_b=id_b,
                conflict_type="direct_contradiction",
                confidence=_CONFIDENCE_DIRECT,
                description=(
                    f"Direct contradiction between '{title_a}' and "
                    f"'{title_b}': opposing directives detected."
                ),
            )
        if vec_a and vec_b:
            return DecisionConflict(
                project_id=project_id,
                decision_id_a=id_a,
                decision_id_b=id_b,
                conflict_type="scope_overlap",
                confidence=_CONFIDENCE_SCOPE_OVERLAP,
                description=(
                    f"Scope overlap between '{title_a}' and '{title_b}': "
                    f"similar topic but no direct contradiction found."
                ),
            )
        return None

    async def _existing_conflict_pairs(
        self, project_id: str
    ) -> set[tuple[str, str]]:
        rows = await self._db.query(
            "decision_conflicts", where={"project_id": project_id}
        )
        return {
            _canonical_pair(
                str(r["decision_id_a"]), str(r["decision_id_b"])
            )
            for r in rows
        }

    async def _persist_conflict(self, conflict: DecisionConflict) -> None:
        try:
            await self._db.insert("decision_conflicts", conflict.to_dict())
        except Exception:
            # Unique-index collision means another run already recorded
            # this pair — safe to ignore.
            return

    async def _load_active_conflicts(
        self, project_id: str
    ) -> list[DecisionConflict]:
        rows = await self._db.query(
            "decision_conflicts",
            where={"project_id": project_id, "status": "active"},
        )
        rows.sort(key=lambda r: float(r.get("confidence") or 0.0), reverse=True)
        return [DecisionConflict.from_dict(r) for r in rows]

    async def _persist_score(
        self, decision_id: str, score: float, signals: list[str]
    ) -> None:
        try:
            await self._db.update(
                "decisions",
                decision_id,
                {
                    "staleness_score": float(score),
                    "staleness_signals": json.dumps(signals),
                    "updated_at": datetime.now(UTC).isoformat(),
                },
            )
        except Exception as exc:
            raise StalenessScorerError(
                f"Failed to persist staleness for {decision_id}: {exc}"
            ) from exc


# ---------------------------------------------------------------------------
# Free helpers
# ---------------------------------------------------------------------------


def _access_recency(
    row: dict[str, Any], *, now: datetime
) -> tuple[float, str | None]:
    """Sensor 1 contribution + signal for this decision."""
    last_raw = row.get("last_accessed_at")
    if not last_raw:
        # Never retrieved — treat as "never" (same as very old).
        days = 365
    else:
        try:
            last = datetime.fromisoformat(str(last_raw))
        except ValueError:
            return 0.0, None
        if last.tzinfo is None:
            last = last.replace(tzinfo=UTC)
        delta = now - last
        days = max(0, int(delta.total_seconds() // 86400))

    if days <= _ACCESS_RECENCY_FRESH_DAYS:
        return 0.0, None
    if days >= _ACCESS_RECENCY_MAX_DAYS:
        return _ACCESS_RECENCY_CAP, f"Not retrieved in {days} days"
    ramp = (days - _ACCESS_RECENCY_FRESH_DAYS) / (
        _ACCESS_RECENCY_MAX_DAYS - _ACCESS_RECENCY_FRESH_DAYS
    )
    return _ACCESS_RECENCY_CAP * ramp, f"Not retrieved in {days} days"


# ---------------------------------------------------------------------------
# Contradiction helpers
# ---------------------------------------------------------------------------


def _canonical_pair(a: str, b: str) -> tuple[str, str]:
    """Return the ordered pair used as the conflict dedup key."""
    return (a, b) if a <= b else (b, a)


def _cosine(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two non-empty float vectors."""
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = 0.0
    norm_a = 0.0
    norm_b = 0.0
    for x, y in zip(a, b, strict=True):
        dot += x * y
        norm_a += x * x
        norm_b += y * y
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return dot / (math.sqrt(norm_a) * math.sqrt(norm_b))


def _has_opposing_polarity(text_a: str, text_b: str) -> bool:
    """True when ``text_a`` and ``text_b`` each carry opposing markers."""
    lower_a = text_a.lower()
    lower_b = text_b.lower()
    for positive, negative in _POLARITY_PAIRS:
        a_pos = re.search(positive, lower_a) is not None
        b_neg = re.search(negative, lower_b) is not None
        if a_pos and b_neg:
            return True
        # Symmetry — either decision can carry either half.
        b_pos = re.search(positive, lower_b) is not None
        a_neg = re.search(negative, lower_a) is not None
        if b_pos and a_neg:
            return True
    return False


def _shares_content_token(text_a: str, text_b: str) -> bool:
    """At least one >3-char token appears in both texts."""
    tokens_a = {t for t in re.findall(r"[a-zA-Z_][a-zA-Z0-9_]+", text_a.lower()) if len(t) > 3}
    tokens_b = {t for t in re.findall(r"[a-zA-Z_][a-zA-Z0-9_]+", text_b.lower()) if len(t) > 3}
    return bool(tokens_a & tokens_b)


_CONSTRAINT_RX = re.compile(
    r"(?P<lhs>[A-Za-z_][\w./\-]*)\s+must\s+not\s+"
    r"(?:import|depend on)\s+(?P<rhs>[A-Za-z_][\w./\-]*)",
    re.IGNORECASE,
)
_REQUIRE_RX = re.compile(
    r"(?P<lhs>[A-Za-z_][\w./\-]*)\s+must\s+"
    r"(?:import|depend on)\s+(?P<rhs>[A-Za-z_][\w./\-]*)",
    re.IGNORECASE,
)


def _constraint_conflict(text_a: str, text_b: str) -> str | None:
    """Return a description when A's forbids/B's requires the same (lhs, rhs)."""
    # Forbid rules vs require rules.
    forbids = set()
    requires = set()
    for match in _CONSTRAINT_RX.finditer(text_a):
        forbids.add((match.group("lhs").lower(), match.group("rhs").lower()))
    for match in _CONSTRAINT_RX.finditer(text_b):
        forbids.add((match.group("lhs").lower(), match.group("rhs").lower()))
    for match in _REQUIRE_RX.finditer(text_a):
        if " not " in match.group(0).lower():
            continue
        requires.add((match.group("lhs").lower(), match.group("rhs").lower()))
    for match in _REQUIRE_RX.finditer(text_b):
        if " not " in match.group(0).lower():
            continue
        requires.add((match.group("lhs").lower(), match.group("rhs").lower()))
    overlap = forbids & requires
    if overlap:
        lhs, rhs = next(iter(overlap))
        return f"{lhs} both must and must not depend on {rhs}"

    # Forbid rule from A vs forbid rule from B on the same lhs but different rhs
    # is not a conflict — both rules can coexist. The real conflict for the
    # "opposing import rules" case is captured above.
    return None
