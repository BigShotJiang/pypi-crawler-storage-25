"""Passive decision inference.

Inspects a session's tool-call timeline and structural AST changes and
produces candidate :class:`InferredDecision` records for file-level
changes that have no linked :class:`Decision`. The inferrer never
persists records itself — the caller (``session.end`` in
``tool_handlers``) decides whether to save the candidates and return
them to the agent.

Guard rails (all ten) are documented at the top of
``inference_evidence.py`` and in CLAUDE.md. This file satisfies them as
follows:

- GR-1 No fabrication: candidates require at least one evidence item;
  empty-evidence candidates are scored ``0.0`` and filtered out.
- GR-2 Calibrated confidence: single-signal scores cap at
  :data:`MAX_SINGLE_SIGNAL_CONFIDENCE` (0.65); multi-signal aggregates
  cap at :data:`MAX_CONFIDENCE` (0.85). Weights come from
  :data:`EVIDENCE_WEIGHTS`.
- GR-3 Factual titles: templates describe the observable change
  (``Add <import> dependency`` / ``Add <entity> in <file>``); no
  rationale language.
- GR-4 Traceable evidence: every :class:`InferredDecision` now stores
  the list of evidence items in the ``evidence`` JSON column.
- GR-5 Never blocks session.end: :meth:`infer_from_session` wraps the
  core pipeline in :func:`asyncio.wait_for` with a 10-second budget
  and catches every exception — always returning a list.
- GR-6 Always pending: candidates are emitted with ``status='pending'``;
  promotion happens only via :meth:`auto_confirm_high_confidence`.
- GR-7 Deduplication: when a :class:`SemanticSearch` instance is wired
  in, candidate titles are compared against existing decisions and
  duplicates above :data:`DEDUP_SIMILARITY_THRESHOLD` are dropped.
- GR-8 No LLM calls: extraction is string/dict/regex work; the only
  model call is the embedding used for dedup, which is a local
  deterministic embedding model (not an LLM).
- GR-9 Session-scoped: every DB query filters on ``session_id``.
- GR-10 Noise filtering: stdlib and packaging-noise imports never
  contribute evidence.

Security invariants enforced:
- SEC-01: Reads are scoped to the validated :class:`DatabaseBackend`
  API. No credential material is introduced.
- SEC-03: Candidate titles and descriptions are derived from AST entity
  names and change types — never from credentials or raw file content.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import uuid as uuid_mod
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from backend.intelligence.inference_evidence import (
    EVIDENCE_WEIGHTS,
    SOURCE_CONFIDENCE_MULTIPLIERS,
    EvidenceType,
    classify_import,
)
from backend.models import Decision, InferredDecision

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend
    from backend.intelligence.ast_tracker import ASTTracker
    from backend.intelligence.semantic_search import SemanticSearch


logger = logging.getLogger(__name__)


# Guard rail GR-2: single-signal inferences cap at this value.
MAX_SINGLE_SIGNAL_CONFIDENCE: float = 0.65
# Guard rail GR-2: no inference ever exceeds this value, even with many signals.
MAX_CONFIDENCE: float = 0.85
# Guard rail GR-7: cosine-similarity threshold above which a candidate is
# considered a duplicate of an existing decision.
DEDUP_SIMILARITY_THRESHOLD: float = 0.85
# Guard rail GR-5: inference must complete within this wall-clock budget.
INFERENCE_TIMEOUT_SECONDS: float = 10.0
# Minimum confidence required to emit a candidate at all.
MIN_VIABLE_CONFIDENCE: float = 0.20
# Pattern-detection threshold: N repeated context reads on the same
# directory promote a module-level candidate.
_MODULE_PATTERN_MIN_HITS = 3

# Config-file basenames whose modification is itself architectural
# evidence (dependency / build-system / project metadata).
_CONFIG_FILE_NAMES: frozenset[str] = frozenset(
    {
        "pyproject.toml",
        "package.json",
        "requirements.txt",
        "requirements-dev.txt",
        "Pipfile",
        "setup.py",
        "setup.cfg",
        "pom.xml",
        "build.gradle",
        "Cargo.toml",
        "go.mod",
        "Gemfile",
        "composer.json",
    }
)


# ---------------------------------------------------------------------------
# Evidence + result dataclasses
# ---------------------------------------------------------------------------


@dataclass
class EvidenceItem:
    """One concrete fact supporting an inferred decision (GR-4)."""

    evidence_type: EvidenceType
    description: str
    source_id: str
    source_type: str
    file_path: str
    detail: dict[str, Any] = field(default_factory=dict)
    # v11 (GR-2 mitigation): the detector source that produced the
    # underlying ASTChange. Used by :meth:`_score_candidate` to scale
    # confidence via :data:`SOURCE_CONFIDENCE_MULTIPLIERS`.
    change_event_source: str = "git_commit"

    def to_dict(self) -> dict[str, Any]:
        return {
            "evidence_type": self.evidence_type,
            "description": self.description,
            "source_id": self.source_id,
            "source_type": self.source_type,
            "file_path": self.file_path,
            "detail": dict(self.detail),
            "change_event_source": self.change_event_source,
        }


@dataclass
class InferenceCandidate:
    """Working-copy candidate before persistence / scoring."""

    title: str
    description: str
    evidence: list[EvidenceItem]
    tags: list[str]
    files_affected: list[str]
    inference_source: str = "ast_change"
    confidence: float = 0.0
    rationale_note: str = (
        "Inferred from code structure — verify and add rationale."
    )


@dataclass
class InferenceResult:
    """Outcome of running a candidate through the dedup + persist step."""

    candidate: InferenceCandidate
    action: str  # "created" | "skipped_duplicate" | "skipped_no_evidence"
    existing_decision_id: str | None = None
    inferred_decision: InferredDecision | None = None


# ---------------------------------------------------------------------------
# Legacy internal shape retained for back-compat with pre-refactor callers.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _UnlinkedChange:
    file_path: str
    entity_name: str
    change_type: str
    change_event_id: str
    ast_change_id: str = ""
    # v11: carry the source + actor so _score_candidate can apply the
    # per-source confidence multiplier (GR-2 mitigation for
    # agent-volume inflation).
    change_event_source: str = "git_commit"
    actor_type: str = "human"


# ---------------------------------------------------------------------------
# DecisionInferrer
# ---------------------------------------------------------------------------


class DecisionInferrer:
    """Produce candidate decisions from a session's unlinked AST changes.

    ``semantic_search`` is optional — when absent, deduplication (GR-7)
    is skipped and every viable candidate is emitted. Existing callers
    that instantiate the inferrer without the search instance continue
    to work; tests and production both pass it in explicitly.
    """

    def __init__(
        self,
        db: DatabaseBackend,
        ast_tracker: ASTTracker | None = None,
        semantic_search: SemanticSearch | None = None,
    ) -> None:
        self._db = db
        self._ast_tracker = ast_tracker
        self._semantic_search = semantic_search

    # ------------------------------------------------------------------
    # Public API — preserved signatures
    # ------------------------------------------------------------------

    async def infer_from_session(
        self, session_id: str, project_id: str
    ) -> list[InferredDecision]:
        """Return candidate :class:`InferredDecision` records.

        Guard rail GR-5: wrapped in :func:`asyncio.wait_for` + a broad
        ``except`` so a slow DB, vector-store failure, or timeout never
        blocks ``session.end``. Always returns a list.

        The caller is responsible for persisting the candidates — this
        method inspects state only.
        """
        if not session_id:
            return []
        try:
            return await asyncio.wait_for(
                self._infer(session_id=session_id, project_id=project_id),
                timeout=INFERENCE_TIMEOUT_SECONDS,
            )
        except TimeoutError:
            logger.warning(
                "Inference timed out after %.1fs for session %s; returning []",
                INFERENCE_TIMEOUT_SECONDS,
                session_id,
            )
            return []
        except Exception:
            logger.warning(
                "Inference pipeline failed for session %s; returning []",
                session_id,
                exc_info=True,
            )
            return []

    async def auto_confirm_high_confidence(
        self,
        session_id: str,
        project_id: str,
        threshold: float = 0.75,
        *,
        recorded_by_user_id: uuid_mod.UUID | None = None,
    ) -> list[Decision]:
        """Promote every pending InferredDecision with confidence ≥ threshold.

        Semantics match the previous implementation — promoted records
        become real :class:`Decision` rows with
        ``inference_status='confirmed'`` and the source candidate's
        ``status`` flips to ``'confirmed'``. Guard rail GR-6 means the
        promoted record is still ``status='unverified'`` on the decisions
        table; a human review step promotes it to ``'verified'``.
        """
        if not 0.0 <= threshold <= 1.0:
            raise ValueError(
                f"threshold must be between 0.0 and 1.0, got {threshold!r}"
            )
        rows = await self._db.query(
            "inferred_decisions",
            where={"session_id": session_id, "status": "pending"},
        )
        promoted: list[Decision] = []
        _ = project_id  # reserved for per-project promotion caps later.
        now_iso = datetime.now(UTC).isoformat()
        for row in rows:
            if float(row.get("confidence") or 0.0) < threshold:
                continue
            inferred = InferredDecision.from_dict(row)
            decision = Decision(
                title=inferred.candidate_title,
                description=(
                    "Auto-confirmed from passive inference. Review and "
                    "update description if rationale is known.\n\n"
                    f"{inferred.candidate_description}"
                ),
                tags=[t for t in inferred.candidate_tags if t != "inferred"],
                status="unverified",
                recorded_by_user_id=recorded_by_user_id,
                recorded_in_session_id=inferred.session_id,
                inference_status="confirmed",
                inference_confidence=inferred.confidence,
            )
            try:
                await self._db.insert("decisions", decision.to_dict())
                await self._db.update(
                    "inferred_decisions",
                    str(inferred.id),
                    {"status": "confirmed", "updated_at": now_iso},
                )
            except Exception:
                # Best-effort — skip this candidate and continue.
                continue
            promoted.append(decision)
        return promoted

    # ------------------------------------------------------------------
    # Core pipeline (called under a timeout + exception guard)
    # ------------------------------------------------------------------

    async def _infer(
        self, *, session_id: str, project_id: str
    ) -> list[InferredDecision]:
        """Core inference pipeline — see class docstring for guard rails."""
        # Step 1 — session events and pre-declared context.
        session_events = await self._db.query(
            "session_events", where={"session_id": session_id}
        )
        explicit_files = self._files_with_explicit_decisions(session_events)

        # Step 2 — unlinked AST changes for this session only (GR-9).
        ast_rows = await self._db.query(
            "ast_changes", where={"session_id": session_id}
        )
        unlinked_changes = await self._filter_unlinked(
            ast_rows, explicit_files=explicit_files
        )

        # Step 3 — unlinked file-change / commit records for this session (GR-9).
        unlinked_commits = await self._db.query(
            "unlinked_commits", where={"session_id": session_id}
        )
        unlinked_file_changes = await self._db.query(
            "unlinked_file_changes", where={"session_id": session_id}
        )

        # Step 4 — extract typed evidence.
        evidence = self._extract_evidence(
            unlinked_changes=unlinked_changes,
            unlinked_commits=unlinked_commits,
            unlinked_file_changes=unlinked_file_changes,
        )

        # Step 5 — group evidence into candidate decisions.
        candidates = self._group_into_candidates(evidence)

        # Step 6 — add session-pattern candidates (module-level work).
        rejected_files = await self._previously_rejected_file_set(session_id)
        candidates.extend(
            self._infer_session_patterns(
                session_id=session_id,
                project_id=project_id,
                session_events=session_events,
                exclude_files=explicit_files
                | {f for c in candidates for f in c.files_affected}
                | rejected_files,
            )
        )

        # Step 7 — score each candidate (GR-2).
        scored = [self._score_candidate(c) for c in candidates]

        # Step 8 — drop anything below the viable floor (GR-1).
        viable = [c for c in scored if c.confidence >= MIN_VIABLE_CONFIDENCE]
        if not viable:
            return []

        # Step 9 — dedup against existing decisions (GR-7).
        kept: list[InferenceCandidate] = []
        for candidate in viable:
            if await self._is_duplicate(candidate, project_id=project_id):
                continue
            kept.append(candidate)

        # Step 10 — skip candidates whose files were rejected previously.
        kept = [
            c
            for c in kept
            if not any(f in rejected_files for f in c.files_affected)
        ]

        # Step 11 — convert to :class:`InferredDecision` objects (persisted by caller).
        return [
            self._candidate_to_inferred(
                candidate=c, session_id=session_id, project_id=project_id
            )
            for c in kept
        ]

    # ------------------------------------------------------------------
    # Step helpers
    # ------------------------------------------------------------------

    async def _filter_unlinked(
        self, ast_rows: list[dict[str, Any]], *, explicit_files: set[str]
    ) -> list[_UnlinkedChange]:
        """Return AST changes from this session with no linking provenance edge."""
        unlinked: list[_UnlinkedChange] = []
        for row in ast_rows:
            file_path = str(row.get("file_path") or "")
            if not file_path or file_path in explicit_files:
                continue
            edges = await self._db.query(
                "provenance_edges",
                where={
                    "target_type": "ast_change",
                    "target_id": str(row["id"]),
                    "source_type": "decision",
                },
            )
            if edges:
                continue
            unlinked.append(
                _UnlinkedChange(
                    file_path=file_path,
                    entity_name=str(row.get("entity_name") or ""),
                    change_type=str(row.get("change_type") or ""),
                    change_event_id=str(row.get("change_event_id") or ""),
                    ast_change_id=str(row.get("id") or ""),
                    # Prefer v11+ column; fall back to legacy name.
                    change_event_source=str(
                        row.get("change_event_source")
                        or row.get("change_event_type")
                        or "git_commit"
                    ),
                    actor_type=str(row.get("actor_type") or "human"),
                )
            )
        return unlinked

    def _extract_evidence(
        self,
        *,
        unlinked_changes: list[_UnlinkedChange],
        unlinked_commits: list[dict[str, Any]],
        unlinked_file_changes: list[dict[str, Any]],
    ) -> list[EvidenceItem]:
        """Translate raw change records into typed evidence items.

        Guard rail GR-8: every branch is string or dict logic — no
        network or model calls. Guard rail GR-10: stdlib/noise imports
        are dropped at the front door.
        """
        evidence: list[EvidenceItem] = []

        for change in unlinked_changes:
            if change.change_type == "import_added":
                module = change.entity_name
                etype = classify_import(module)
                if etype is None or etype == "new_import_stdlib":
                    # GR-10 — stdlib + noise packages contribute nothing.
                    continue
                evidence.append(
                    EvidenceItem(
                        evidence_type=etype,
                        description=(
                            f"New import `{module}` in `{change.file_path}`"
                        ),
                        source_id=change.ast_change_id,
                        source_type="ast_change",
                        file_path=change.file_path,
                        detail={"module": module},
                        change_event_source=change.change_event_source,
                    )
                )
            elif change.change_type == "function_added":
                evidence.append(
                    EvidenceItem(
                        evidence_type="new_function",
                        description=(
                            f"Function `{change.entity_name or 'anonymous'}` "
                            f"added in `{change.file_path}`"
                        ),
                        source_id=change.ast_change_id,
                        source_type="ast_change",
                        file_path=change.file_path,
                        detail={"function": change.entity_name},
                        change_event_source=change.change_event_source,
                    )
                )
            elif change.change_type == "class_added":
                evidence.append(
                    EvidenceItem(
                        evidence_type="new_class_inherits",
                        description=(
                            f"Class `{change.entity_name or 'anonymous'}` "
                            f"added in `{change.file_path}`"
                        ),
                        source_id=change.ast_change_id,
                        source_type="ast_change",
                        file_path=change.file_path,
                        detail={"class": change.entity_name},
                        change_event_source=change.change_event_source,
                    )
                )
            elif change.change_type in {
                "function_modified",
                "signature_changed",
            }:
                evidence.append(
                    EvidenceItem(
                        evidence_type="function_signature_change",
                        description=(
                            f"Signature of `{change.entity_name}` changed "
                            f"in `{change.file_path}`"
                        ),
                        source_id=change.ast_change_id,
                        source_type="ast_change",
                        file_path=change.file_path,
                        detail={"function": change.entity_name},
                        change_event_source=change.change_event_source,
                    )
                )

        # File-change evidence — config files, migrations, new files.
        for fc in unlinked_file_changes:
            file_path = str(fc.get("file_path") or "")
            if not file_path:
                continue
            fc_id = str(fc.get("id") or "")
            basename = os.path.basename(file_path)
            lowered = file_path.lower()

            if basename in _CONFIG_FILE_NAMES:
                evidence.append(
                    EvidenceItem(
                        evidence_type="config_file_modified",
                        description=f"Project config `{basename}` modified",
                        source_id=fc_id,
                        source_type="file_change",
                        file_path=file_path,
                        detail={"filename": basename},
                    )
                )
            if (
                "migration" in lowered
                or "/alembic/" in lowered
                or lowered.startswith("alembic/")
            ):
                evidence.append(
                    EvidenceItem(
                        evidence_type="migration_file_created",
                        description=(
                            f"Database migration created: `{file_path}`"
                        ),
                        source_id=fc_id,
                        source_type="file_change",
                        file_path=file_path,
                        detail={},
                    )
                )

        _ = unlinked_commits  # Reserved — commit-level evidence deferred.
        return evidence

    def _group_into_candidates(
        self, evidence: list[EvidenceItem]
    ) -> list[InferenceCandidate]:
        """Group evidence into coherent candidates.

        Library evidence (import + classification) groups per module.
        Every other evidence item becomes a standalone candidate.
        Guard rail GR-3: titles describe observable facts only.
        """
        candidates: list[InferenceCandidate] = []

        library_groups: dict[str, list[EvidenceItem]] = defaultdict(list)
        standalone: list[EvidenceItem] = []
        for item in evidence:
            module = item.detail.get("module")
            if (
                item.evidence_type in {"new_import_third_party", "new_import_internal"}
                and isinstance(module, str)
                and module
            ):
                library_groups[module].append(item)
            else:
                standalone.append(item)

        for module, items in library_groups.items():
            files = sorted({i.file_path for i in items})
            source_kind = (
                "third-party library"
                if items[0].evidence_type == "new_import_third_party"
                else "internal module"
            )
            title = f"Add `{module}` dependency to project"
            description = (
                f"`{module}` was imported for the first time in: "
                f"{', '.join(f'`{fp}`' for fp in files)} ({source_kind}). "
                "Inferred from code structure — verify and add rationale."
            )
            candidates.append(
                InferenceCandidate(
                    title=title,
                    description=description,
                    evidence=list(items),
                    tags=["inferred", module],
                    files_affected=files,
                    inference_source="ast_change",
                )
            )

        for item in standalone:
            title = _title_for_standalone(item)
            candidates.append(
                InferenceCandidate(
                    title=title,
                    description=(
                        f"{item.description}. "
                        "Inferred from code structure — verify and add rationale."
                    ),
                    evidence=[item],
                    tags=["inferred"],
                    files_affected=[item.file_path],
                    inference_source=(
                        "file_change"
                        if item.source_type == "file_change"
                        else "ast_change"
                    ),
                )
            )

        return candidates

    def _infer_session_patterns(
        self,
        *,
        session_id: str,
        project_id: str,
        session_events: list[dict[str, Any]],
        exclude_files: set[str],
    ) -> list[InferenceCandidate]:
        """Detect tool-call repetition patterns and emit module candidates."""
        _ = session_id, project_id
        per_dir: dict[str, int] = defaultdict(int)
        for evt in session_events:
            if str(evt.get("event_type", "")) != "tool_call":
                continue
            payload = _parse_payload(evt.get("payload"))
            tool = str(payload.get("tool", ""))
            if tool not in ("context.get_for_file", "context_get_for_file"):
                continue
            file_path = str(payload.get("file_path", ""))
            if not file_path or file_path in exclude_files:
                continue
            directory = os.path.dirname(file_path) or "."
            per_dir[directory] += 1

        candidates: list[InferenceCandidate] = []
        for directory, hits in per_dir.items():
            if hits < _MODULE_PATTERN_MIN_HITS:
                continue
            description = (
                f"Session activity touched {hits} files under "
                f"`{directory}`. Inferred from code structure — verify and "
                "add rationale."
            )
            # Synthetic evidence — the session_events query is itself
            # the audit trail, so the source_id points at the directory.
            synthetic = EvidenceItem(
                evidence_type="session_pattern",
                description=f"{hits} context reads under `{directory}`",
                source_id=f"pattern::{directory}",
                source_type="session_pattern",
                file_path=directory,
                detail={"hits": hits},
            )
            candidates.append(
                InferenceCandidate(
                    title=(
                        f"Work on {os.path.basename(directory) or directory}"
                        " module"
                    ),
                    description=description,
                    evidence=[synthetic],
                    tags=["inferred", "module"],
                    files_affected=[directory],
                    inference_source="session_pattern",
                )
            )
        return candidates

    def _score_candidate(
        self, candidate: InferenceCandidate
    ) -> InferenceCandidate:
        """Assign a confidence score to ``candidate`` (GR-1, GR-2).

        GR-2: SOURCE_CONFIDENCE_MULTIPLIERS are applied to each
        evidence weight *before* the single-signal cap fires so
        agent_reported events (0.5x multiplier) receive no confidence
        boost relative to their raw weight — the cap enforces a
        per-signal ceiling regardless of how many events an agent
        reports. Without this pre-cap scaling, a high-weight single
        piece of agent-reported evidence would saturate at 0.65, which
        is the same outcome as a human-authored signal; the multiplier
        ensures agent-only evidence remains proportionally weaker.
        """
        if not candidate.evidence:
            candidate.confidence = 0.0
            return candidate
        # GR-2: agent_reported events receive no confidence boost —
        # same weights as other sources, then scaled by the source's
        # multiplier. See inference_evidence.SOURCE_CONFIDENCE_MULTIPLIERS.
        weights = [
            EVIDENCE_WEIGHTS[e.evidence_type].weight
            * SOURCE_CONFIDENCE_MULTIPLIERS.get(e.change_event_source, 1.0)
            for e in candidate.evidence
            if e.evidence_type in EVIDENCE_WEIGHTS
        ]
        if not weights:
            candidate.confidence = 0.0
            return candidate
        if len(weights) == 1:
            candidate.confidence = round(
                min(weights[0], MAX_SINGLE_SIGNAL_CONFIDENCE), 2
            )
        else:
            ordered = sorted(weights, reverse=True)
            score = ordered[0]
            for w in ordered[1:]:
                score += w * 0.3  # Diminishing-returns aggregation.
            candidate.confidence = round(min(score, MAX_CONFIDENCE), 2)
        return candidate

    async def _is_duplicate(
        self, candidate: InferenceCandidate, *, project_id: str
    ) -> bool:
        """Guard rail GR-7: skip candidates similar to existing decisions.

        Uses :class:`SemanticSearch` when available. A search failure is
        treated as ``False`` (not a duplicate) so the candidate still
        flows through — we'd rather have a reviewable duplicate than
        silently drop valid inference because the vector store hiccuped.
        """
        if self._semantic_search is None:
            return False
        try:
            results = await self._semantic_search.search(
                query=candidate.title,
                project_id=project_id,
                top_k=3,
                blend_weight=1.0,  # Pure vector dedup; BM25 would leak names.
            )
        except Exception:
            logger.warning(
                "Semantic dedup failed for candidate '%s'; keeping candidate",
                candidate.title,
                exc_info=True,
            )
            return False
        for res in results:
            score = getattr(res, "score", None)
            item_type = getattr(res, "item_type", None)
            if item_type != "decision":
                continue
            if isinstance(score, float | int) and float(score) >= DEDUP_SIMILARITY_THRESHOLD:
                logger.info(
                    "Inference dedup: candidate '%s' matches decision %s "
                    "at score %.2f",
                    candidate.title,
                    getattr(res, "item_id", "?"),
                    float(score),
                )
                return True
        return False

    def _candidate_to_inferred(
        self,
        *,
        candidate: InferenceCandidate,
        session_id: str,
        project_id: str,
    ) -> InferredDecision:
        """Materialise an :class:`InferredDecision` from a candidate (GR-4, GR-6)."""
        return InferredDecision(
            session_id=uuid_mod.UUID(session_id),
            project_id=project_id,
            candidate_title=candidate.title,
            candidate_description=candidate.description,
            candidate_tags=list(candidate.tags),
            files_affected=list(candidate.files_affected),
            inference_source=candidate.inference_source,
            confidence=candidate.confidence,
            status="pending",  # GR-6
            evidence=[e.to_dict() for e in candidate.evidence],  # GR-4
        )

    # ------------------------------------------------------------------
    # Session event helpers (retained)
    # ------------------------------------------------------------------

    def _files_with_explicit_decisions(
        self, session_events: list[dict[str, Any]]
    ) -> set[str]:
        """Files referenced by ``decision.create`` tool calls in the session."""
        files: set[str] = set()
        for evt in session_events:
            if str(evt.get("event_type", "")) != "tool_call":
                continue
            payload = _parse_payload(evt.get("payload"))
            tool = str(payload.get("tool", ""))
            if tool not in ("decision.create", "decision_create"):
                continue
            affected = payload.get("files_affected") or []
            if isinstance(affected, list):
                files.update(str(f) for f in affected)
        return files

    async def _previously_rejected_file_set(
        self, session_id: str
    ) -> set[str]:
        """Files whose candidates were previously rejected in this session."""
        rows = await self._db.query(
            "inferred_decisions",
            where={"session_id": session_id, "status": "rejected"},
        )
        rejected: set[str] = set()
        for row in rows:
            raw = row.get("files_affected") or "[]"
            try:
                files = (
                    json.loads(raw) if isinstance(raw, str) else list(raw)
                )
            except json.JSONDecodeError:
                files = []
            rejected.update(str(f) for f in files)
        return rejected


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _parse_payload(raw: Any) -> dict[str, Any]:
    """Best-effort parse of a SessionEvent payload."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            loaded = json.loads(raw)
            if isinstance(loaded, dict):
                return loaded
        except json.JSONDecodeError:
            return {}
    return {}


def _title_for_standalone(item: EvidenceItem) -> str:
    """Factual title for a single non-library evidence item (GR-3)."""
    if item.evidence_type == "config_file_modified":
        basename = item.detail.get("filename") or os.path.basename(
            item.file_path
        )
        return f"Modify project config `{basename}`"
    if item.evidence_type == "migration_file_created":
        return f"Add database migration `{item.file_path}`"
    if item.evidence_type == "new_function":
        func = item.detail.get("function") or "function"
        return f"Add {func} in `{item.file_path}`"
    if item.evidence_type == "new_class_inherits":
        cls = item.detail.get("class") or "class"
        return f"Add class `{cls}` in `{item.file_path}`"
    if item.evidence_type == "function_signature_change":
        func = item.detail.get("function") or "function"
        return f"Change signature of `{func}` in `{item.file_path}`"
    if item.evidence_type == "file_created":
        return f"Create file `{item.file_path}`"
    if item.evidence_type == "file_deleted":
        return f"Delete file `{item.file_path}`"
    return item.description


# re is imported for potential future regex-based extractors; keep the
# import alive so the module compiles cleanly when extractors are added.
_ = re
