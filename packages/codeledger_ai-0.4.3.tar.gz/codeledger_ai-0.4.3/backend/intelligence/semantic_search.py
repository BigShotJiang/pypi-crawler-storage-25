"""Semantic retrieval built on :class:`Embedder` + :class:`VectorStore`.

Bridges raw text (queries, decisions, stories, file contents) with the
backend-agnostic vector store. The class exposes a small, agent-facing
surface that the MCP tool handlers and internal pipelines consume:

* ``index_item`` — embed text and store it under a caller-supplied id,
  tagged with ``item_type`` and ``project_id``.
* ``search`` — embed a query and return ranked :class:`SearchResult`.
* ``search_by_file`` — ranked context for the file currently being edited.
* ``reindex_item`` — replace an item's embedding when its text changes.
* ``remove_item`` — delete an item's embedding.

Security invariants enforced:
- SEC-03: Results carry stored metadata and relevance scores only. No
  credential material is introduced by this module; metadata passed in by
  callers is assumed to be free of secrets (the Phase 1 domain models
  never populate metadata with token/key fields).
- Item IDs, project IDs, and types are validated as non-empty strings so
  downstream filtering is deterministic.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Literal

from rank_bm25 import BM25Okapi  # type: ignore[import-untyped]

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend
    from backend.db.vector_store import VectorStore
    from backend.intelligence.embedder import Embedder


RetrievalMethod = Literal["vector", "bm25", "both"]


# 150-word English stopword list for the BM25 tokenizer. Small enough to
# ship inline; avoids adding an NLP dependency for this single purpose.
_STOPWORDS: frozenset[str] = frozenset(
    {
        "a", "about", "above", "after", "again", "against", "all", "am",
        "an", "and", "any", "are", "as", "at", "be", "because", "been",
        "before", "being", "below", "between", "both", "but", "by", "can",
        "could", "did", "do", "does", "doing", "don", "down", "during",
        "each", "few", "for", "from", "further", "had", "has", "have",
        "having", "he", "her", "here", "hers", "herself", "him", "himself",
        "his", "how", "i", "if", "in", "into", "is", "it", "its", "itself",
        "just", "me", "more", "most", "my", "myself", "no", "nor", "not",
        "now", "of", "off", "on", "once", "only", "or", "other", "our",
        "ours", "ourselves", "out", "over", "own", "re", "s", "same",
        "she", "should", "so", "some", "such", "t", "than", "that", "the",
        "their", "theirs", "them", "themselves", "then", "there", "these",
        "they", "this", "those", "through", "to", "too", "under", "until",
        "up", "very", "was", "we", "were", "what", "when", "where",
        "which", "while", "who", "whom", "why", "will", "with", "would",
        "you", "your", "yours", "yourself", "yourselves", "also", "across",
        "among", "behind", "beyond", "except", "inside",
        "near", "since", "though", "unless", "upon", "within", "without",
        "shall", "may", "might", "must", "let", "lets",
    }
)

_TOKEN_RX = re.compile(r"[a-z][a-z0-9_]+")


def _tokenize_for_bm25(text: str) -> list[str]:
    """Lowercase, split on non-word chars, drop stopwords, keep ≥3-char tokens."""
    return [
        tok
        for tok in _TOKEN_RX.findall(text.lower())
        if tok not in _STOPWORDS and len(tok) > 2
    ]


# Reserved keys are set by ``index_item`` and must not be overridden by the
# caller's ``metadata`` argument — they are load-bearing for retrieval and
# for the :class:`SearchResult` shape exposed to consumers.
_RESERVED_METADATA_KEYS = frozenset({"item_type", "project_id", "text"})


class SemanticSearchError(Exception):
    """Raised for semantic-search operation failures and invalid input."""


@dataclass(frozen=True)
class SearchResult:
    """One ranked semantic-search result.

    Attributes:
        item_id: Caller-supplied identifier passed into ``index_item``.
        score: Blended score in ``[0.0, ~1.0]`` — higher is more relevant.
            Under the hybrid pipeline this is the combined vector+BM25
            score after recency decay. Under pure vector mode it is the
            raw cosine similarity.
        item_type: The ``item_type`` recorded when the item was indexed
            (e.g. ``"decision"``, ``"story"``, ``"session"``).
        metadata: The remaining metadata fields the caller stored alongside
            the item, with retrieval keys (``item_type``, ``project_id``)
            excluded — those are promoted to first-class fields or used
            internally for filtering.
        retrieval_method: Which retrieval path produced this result —
            ``"vector"`` (cosine only), ``"bm25"`` (keyword only), or
            ``"both"`` (the item scored in both paths and the blended
            score is reported).
        conflict_warning: Populated when another decision in the same
            result set has an active ``DecisionConflict`` with this one.
            Agents see this inline so they can reconcile contradictions
            before applying either decision.
    """

    item_id: str
    score: float
    item_type: str
    metadata: dict[str, Any]
    retrieval_method: RetrievalMethod = "vector"
    conflict_warning: dict[str, Any] | None = None


def _validate_non_empty(value: object, name: str) -> str:
    if not isinstance(value, str) or not value:
        raise SemanticSearchError(f"{name} must be a non-empty string")
    return value


def _validate_text(value: object, name: str) -> str:
    """Accept any string (including empty) but reject non-str types."""
    if not isinstance(value, str):
        raise SemanticSearchError(
            f"{name} must be a string, got {type(value).__name__}"
        )
    return value


def _validate_metadata(metadata: object) -> dict[str, Any]:
    if metadata is None:
        return {}
    if not isinstance(metadata, dict):
        raise SemanticSearchError(
            f"metadata must be dict or None, got {type(metadata).__name__}"
        )
    return dict(metadata)


class BM25Index:
    """Lazy, in-memory BM25 index over a project's text corpus.

    Build is synchronous — the index is assembled on the first query and
    invalidated whenever an item is added, reindexed, or removed in the
    owning project.
    """

    def __init__(self, db: DatabaseBackend, project_id: str) -> None:
        self._db = db
        self._project_id = project_id
        self._tokenized: list[list[str]] = []
        self._item_ids: list[str] = []
        self._bm25: BM25Okapi | None = None
        self._built: bool = False

    async def build(self, project_id: str | None = None) -> None:
        """Rebuild the BM25 index over all context_items + decisions for the project."""
        _ = project_id  # project scope is fixed at construction time
        self._tokenized = []
        self._item_ids = []
        # Context items — store raw content.
        context_rows = await self._db.query("context_items")
        for row in context_rows:
            content = str(row.get("content") or "")
            if not content.strip():
                continue
            self._item_ids.append(str(row["id"]))
            self._tokenized.append(_tokenize_for_bm25(content))
        # Decisions — concatenate title + description.
        decision_rows = await self._db.query("decisions")
        for row in decision_rows:
            blob = f"{row.get('title', '')}\n{row.get('description', '')}"
            if not blob.strip():
                continue
            self._item_ids.append(str(row["id"]))
            self._tokenized.append(_tokenize_for_bm25(blob))

        if self._tokenized:
            self._bm25 = BM25Okapi(self._tokenized)
        else:
            self._bm25 = None
        self._built = True

    async def _ensure_built(self) -> None:
        if not self._built:
            await self.build()

    async def search(
        self, query: str, top_k: int
    ) -> list[tuple[str, float]]:
        """Return ``(item_id, bm25_score)`` pairs for the top ``top_k`` matches."""
        await self._ensure_built()
        if self._bm25 is None or not self._item_ids:
            return []
        tokens = _tokenize_for_bm25(query)
        if not tokens:
            return []
        scores = self._bm25.get_scores(tokens)
        ranked = sorted(
            zip(self._item_ids, scores, strict=True),
            key=lambda pair: pair[1],
            reverse=True,
        )
        return [(item_id, float(score)) for item_id, score in ranked[:top_k] if score > 0.0]

    def invalidate(self) -> None:
        """Drop the index so the next search rebuilds it."""
        self._tokenized = []
        self._item_ids = []
        self._bm25 = None
        self._built = False


def _normalize_scores(scores: dict[str, float]) -> dict[str, float]:
    """Normalize a ``{id: score}`` map to ``[0, 1]`` by its maximum."""
    if not scores:
        return {}
    max_score = max(scores.values())
    if max_score <= 0.0:
        # All-zero input means nothing ranks above another — return zeros
        # so the missing-score fallback in the blender still works.
        return dict.fromkeys(scores, 0.0)
    return {k: v / max_score for k, v in scores.items()}


def _recency_weight(created_at_raw: Any, now: datetime) -> float:
    """Compute the decay factor for an item based on its ``created_at``.

    Returns ``1.0 / (1.0 + 0.005 * days_since_created)``. Missing or
    unparseable timestamps return ``1.0`` (no decay).
    """
    if not created_at_raw:
        return 1.0
    try:
        dt = (
            datetime.fromisoformat(str(created_at_raw))
            if not isinstance(created_at_raw, datetime)
            else created_at_raw
        )
    except ValueError:
        return 1.0
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    days = max(0.0, (now - dt).total_seconds() / 86400.0)
    return 1.0 / (1.0 + 0.005 * days)


class SemanticSearch:
    """Embed-then-store-or-query façade over :class:`VectorStore`.

    The caller owns both the embedder and the vector store and is
    responsible for calling ``connect`` / ``close`` on them. This class
    holds no connection state of its own.

    When a :class:`DatabaseBackend` is supplied via ``db``, the hybrid
    BM25 + cosine retrieval path is enabled. Without ``db``, the class
    falls back to pure vector search (legacy behaviour).
    """

    def __init__(
        self,
        embedder: Embedder,
        vector_store: VectorStore,
        db: DatabaseBackend | None = None,
    ) -> None:
        self._embedder = embedder
        self._vector_store = vector_store
        self._db = db
        self._bm25_indexes: dict[str, BM25Index] = {}

    async def index_item(
        self,
        item_id: str,
        text: str,
        item_type: str,
        project_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Embed ``text`` and persist the resulting vector under ``item_id``.

        The stored metadata is the merge of the caller-supplied ``metadata``
        (minus any reserved keys) plus ``item_type``, ``project_id``, and
        a ``text`` field holding the source string. The ``text`` field lets
        downstream callers materialise context without a second lookup in
        the application database.
        """
        item_id = _validate_non_empty(item_id, "item_id")
        text = _validate_text(text, "text")
        item_type = _validate_non_empty(item_type, "item_type")
        project_id = _validate_non_empty(project_id, "project_id")
        extra = _validate_metadata(metadata)
        merged: dict[str, Any] = {
            k: v for k, v in extra.items() if k not in _RESERVED_METADATA_KEYS
        }
        merged["item_type"] = item_type
        merged["project_id"] = project_id
        merged["text"] = text

        vector = await self._embedder.embed_text(text)
        await self._vector_store.insert(item_id, vector, merged)
        self._invalidate_project(project_id)

    async def search(
        self,
        query: str,
        project_id: str,
        top_k: int = 10,
        *,
        persona: str | None = None,
        blend_weight: float = 0.6,
    ) -> list[SearchResult]:
        """Embed ``query`` and return the top-K most similar indexed items.

        When ``blend_weight`` < 1.0 and a :class:`DatabaseBackend` is wired,
        BM25 keyword retrieval runs in parallel with vector retrieval and
        the scores are blended. A recency decay factor then adjusts the
        final score so newer items rank ~10% higher than identical older
        items. Results are scoped to ``project_id`` so items from other
        projects never leak into the response.

        ``blend_weight``:
            * ``1.0`` — pure vector (legacy behaviour).
            * ``0.0`` — pure BM25 keyword search.
            * ``0.6`` — default (60% vector, 40% BM25).
        """
        query = _validate_non_empty(query, "query")
        project_id = _validate_non_empty(project_id, "project_id")
        if not isinstance(top_k, int) or isinstance(top_k, bool) or top_k <= 0:
            raise SemanticSearchError(
                f"top_k must be a positive int, got {top_k!r}"
            )
        if not 0.0 <= blend_weight <= 1.0:
            raise SemanticSearchError(
                f"blend_weight must be between 0.0 and 1.0, got {blend_weight!r}"
            )

        vector_map: dict[str, float] = {}
        vector_records: dict[str, SearchResult] = {}
        if blend_weight > 0.0:
            query_vector = await self._embedder.embed_text(query)
            raw_results = await self._vector_store.search(
                query_vector, top_k=top_k * 2, project_id=project_id
            )
            for raw in raw_results:
                result = _to_search_result(raw)
                vector_map[result.item_id] = max(0.0, result.score)
                vector_records[result.item_id] = result

        bm25_map: dict[str, float] = {}
        if blend_weight < 1.0 and self._db is not None:
            bm25_pairs = await self._bm25_search(
                project_id=project_id, query=query, top_k=top_k * 2
            )
            for item_id, score in bm25_pairs:
                bm25_map[item_id] = score

        # Pure vector fast-path: keep raw cosine scores (no normalisation,
        # no blending, no recency decay) so legacy callers that never
        # opted into hybrid retrieval see identical output. Conflict
        # annotation still applies when a db is wired.
        if self._db is None or (not bm25_map and not vector_records):
            results = sorted(
                vector_records.values(), key=lambda r: r.score, reverse=True
            )[:top_k]
            if persona:
                results = _apply_persona_reranking(results, persona)
            results = await self._annotate_conflicts(results)
            return results

        norm_vector = _normalize_scores(vector_map)
        norm_bm25 = _normalize_scores(bm25_map)
        all_ids = set(norm_vector) | set(norm_bm25)
        now = datetime.now(UTC)
        blended: list[SearchResult] = []
        for item_id in all_ids:
            v = norm_vector.get(item_id, 0.0)
            b = norm_bm25.get(item_id, 0.0)
            combined = blend_weight * v + (1.0 - blend_weight) * b
            # Recency decay — pulled from vector metadata when available,
            # otherwise from a DB lookup (at most once per result).
            metadata = await self._hydrate_metadata(item_id, vector_records)
            weight = _recency_weight(metadata.get("created_at"), now)
            final = combined * (0.85 + 0.15 * weight)
            # Staleness penalty — a decision with staleness_score: 1.0
            # ranks 30% lower than an identical fresh decision.
            staleness = metadata.get("staleness_score")
            if isinstance(staleness, int | float):
                final *= max(0.0, 1.0 - 0.3 * float(staleness))
            method: RetrievalMethod = (
                "both" if item_id in norm_vector and item_id in norm_bm25
                else ("vector" if item_id in norm_vector else "bm25")
            )
            item_type = str(metadata.get("item_type", "")) or "decision"
            visible_metadata = {
                k: v for k, v in metadata.items()
                if k not in {"item_type", "project_id"}
            }
            blended.append(
                SearchResult(
                    item_id=item_id,
                    score=final,
                    item_type=item_type,
                    metadata=visible_metadata,
                    retrieval_method=method,
                )
            )

        blended.sort(key=lambda r: r.score, reverse=True)
        results = blended[:top_k]
        if persona:
            results = _apply_persona_reranking(results, persona)
        results = await self._annotate_conflicts(results)
        return results

    async def _annotate_conflicts(
        self, results: list[SearchResult]
    ) -> list[SearchResult]:
        """Attach ``conflict_warning`` when two decisions in the set are in conflict."""
        if self._db is None or len(results) < 2:
            return results
        decision_ids = {
            r.item_id for r in results if r.item_type == "decision"
        }
        if len(decision_ids) < 2:
            return results
        try:
            conflict_rows = await self._db.query(
                "decision_conflicts", where={"status": "active"}
            )
        except Exception:
            return results
        warnings: dict[str, dict[str, Any]] = {}
        for row in conflict_rows:
            a = str(row.get("decision_id_a") or "")
            b = str(row.get("decision_id_b") or "")
            if a in decision_ids and b in decision_ids:
                warnings[a] = {
                    "conflict_id": str(row.get("id") or ""),
                    "conflicts_with": b,
                    "conflict_type": row.get("conflict_type", ""),
                    "description": row.get("description", ""),
                }
                warnings[b] = {
                    "conflict_id": str(row.get("id") or ""),
                    "conflicts_with": a,
                    "conflict_type": row.get("conflict_type", ""),
                    "description": row.get("description", ""),
                }
        if not warnings:
            return results
        return [
            SearchResult(
                item_id=r.item_id,
                score=r.score,
                item_type=r.item_type,
                metadata=r.metadata,
                retrieval_method=r.retrieval_method,
                conflict_warning=warnings.get(r.item_id),
            )
            for r in results
        ]

    async def _bm25_search(
        self, *, project_id: str, query: str, top_k: int
    ) -> list[tuple[str, float]]:
        """Ensure the per-project index is fresh, then run BM25."""
        if self._db is None:
            return []
        index = self._bm25_indexes.get(project_id)
        if index is None:
            index = BM25Index(self._db, project_id)
            self._bm25_indexes[project_id] = index
        return await index.search(query, top_k)

    async def _hydrate_metadata(
        self, item_id: str, vector_records: dict[str, SearchResult]
    ) -> dict[str, Any]:
        """Pull metadata from the vector-store record or fall back to DB."""
        record = vector_records.get(item_id)
        if record is not None:
            meta = dict(record.metadata)
            meta.setdefault("item_type", record.item_type)
            return meta
        if self._db is None:
            return {}
        for table in ("decisions", "context_items"):
            row = await self._db.get_by_id(table, item_id)
            if row is None:
                continue
            return {
                "item_type": "decision" if table == "decisions" else "context",
                "title": row.get("title", ""),
                "created_at": row.get("created_at"),
                "staleness_score": row.get("staleness_score", 0.0),
                "superseded_by": row.get("superseded_by"),
            }
        return {}

    def _invalidate_project(self, project_id: str) -> None:
        """Drop the BM25 index for a project so the next search rebuilds it."""
        index = self._bm25_indexes.get(project_id)
        if index is not None:
            index.invalidate()

    async def search_by_file(
        self,
        file_path: str,
        file_content: str,
        project_id: str,
        top_k: int = 10,
        *,
        persona: str | None = None,
        blend_weight: float = 0.5,
    ) -> list[SearchResult]:
        """Return context relevant to the file currently being edited.

        Uses a 50/50 vector/BM25 blend by default — file-scoped queries
        benefit more from exact-token matching than free-form queries do.
        """
        file_path = _validate_non_empty(file_path, "file_path")
        file_content = _validate_text(file_content, "file_content")
        project_id = _validate_non_empty(project_id, "project_id")
        combined = f"{file_path}\n\n{file_content}" if file_content else file_path
        return await self.search(
            combined,
            project_id,
            top_k=top_k,
            persona=persona,
            blend_weight=blend_weight,
        )

    async def reindex_item(self, item_id: str, new_text: str) -> None:
        """Replace the stored embedding for ``item_id`` with one for ``new_text``.

        Raises :class:`SemanticSearchError` if ``item_id`` is not already
        indexed — callers should use ``index_item`` for first-time inserts.
        The existing ``item_type``, ``project_id`` and any additional
        caller-supplied metadata are preserved.
        """
        item_id = _validate_non_empty(item_id, "item_id")
        new_text = _validate_text(new_text, "new_text")

        stored = await self._vector_store.get(item_id)
        if stored is None:
            raise SemanticSearchError(
                f"Cannot reindex unknown item_id {item_id!r}"
            )
        item_type = stored.get("item_type")
        project_id = stored.get("project_id")
        if not isinstance(item_type, str) or not item_type:
            raise SemanticSearchError(
                f"Stored metadata for {item_id!r} is missing item_type"
            )
        if not isinstance(project_id, str) or not project_id:
            raise SemanticSearchError(
                f"Stored metadata for {item_id!r} is missing project_id"
            )
        preserved = {
            k: v for k, v in stored.items() if k not in _RESERVED_METADATA_KEYS
        }

        await self._vector_store.delete(item_id)
        await self.index_item(
            item_id=item_id,
            text=new_text,
            item_type=item_type,
            project_id=project_id,
            metadata=preserved,
        )

    async def remove_item(self, item_id: str) -> None:
        """Delete the embedding for ``item_id``. Silent no-op when absent."""
        item_id = _validate_non_empty(item_id, "item_id")
        existing = await self._vector_store.get(item_id)
        await self._vector_store.delete(item_id)
        if existing is not None:
            stored_project = existing.get("project_id")
            if isinstance(stored_project, str) and stored_project:
                self._invalidate_project(stored_project)


# ---------------------------------------------------------------------------
# Persona re-ranking
# ---------------------------------------------------------------------------


# Persona multiplier table: each persona has a set of "preferred" item types
# that get a 1.3x score boost; all other types get a 0.7x dampener. No items
# are filtered — only the score field is adjusted for ordering purposes.
_PERSONA_PREFERENCES: dict[str, frozenset[str]] = {
    "architect": frozenset({"decision"}),
    "reviewer": frozenset({"decision", "verification", "ast_change"}),
    "planner": frozenset({"story", "sprint"}),
    "implementer": frozenset({"story", "ast_change", "context"}),
}

_PERSONA_BOOST = 1.3
_PERSONA_DAMPEN = 0.7


def _apply_persona_reranking(
    results: list[SearchResult], persona: str
) -> list[SearchResult]:
    """Adjust result scores per :data:`_PERSONA_PREFERENCES` and re-sort."""
    preferred = _PERSONA_PREFERENCES.get(persona.lower(), frozenset())
    if not preferred:
        return results
    adjusted: list[SearchResult] = []
    for r in results:
        multiplier = _PERSONA_BOOST if r.item_type in preferred else _PERSONA_DAMPEN
        adjusted.append(
            SearchResult(
                item_id=r.item_id,
                score=r.score * multiplier,
                item_type=r.item_type,
                metadata=r.metadata,
            )
        )
    adjusted.sort(key=lambda r: r.score, reverse=True)
    return adjusted


def _to_search_result(raw: dict[str, Any]) -> SearchResult:
    """Convert a :class:`VectorStore.search` row into a :class:`SearchResult`.

    ``item_type`` is promoted to a top-level field and removed from the
    metadata dict. ``project_id`` is also dropped from the visible metadata
    since it is a retrieval key, not application state.
    """
    metadata = raw.get("metadata", {})
    if not isinstance(metadata, dict):
        metadata = {}
    item_type_raw = metadata.get("item_type", "")
    item_type = item_type_raw if isinstance(item_type_raw, str) else ""
    visible = {
        k: v
        for k, v in metadata.items()
        if k not in {"item_type", "project_id"}
    }
    item_id_raw = raw.get("item_id", "")
    score_raw = raw.get("score", 0.0)
    return SearchResult(
        item_id=str(item_id_raw),
        score=float(score_raw),
        item_type=item_type,
        metadata=visible,
    )
