"""Token-budget-aware context triage with summarisation fallback.

Given a list of :class:`SearchResult` ranked by relevance and a token
budget, :class:`ContextTriage` produces a :class:`TriageResult` with
three bands:

* ``included_items`` — full text, fits within the remaining budget.
* ``summarized_items`` — compressed text for items that overflow by less
  than half; the summary keeps the first sentence and trims to ~30% of
  the original token count.
* ``excluded_summary`` — a single descriptive line listing every item
  cut after the budget is exhausted, including each item's topic and
  relevance score.

Security invariants enforced:
- No credentials or network I/O. This module processes strings already
  pulled from the domain database and returns a shorter string.
- The rendering helper ``format_context_block`` echoes back only the
  item text, relevance score, ``item_type``, and optional metadata
  fields already present on the caller-supplied :class:`SearchResult`
  (``title``, ``tags``, ``verification_status``). It never synthesises
  secret material or reads any external source.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from functools import lru_cache
from typing import TYPE_CHECKING, Any

try:
    import tiktoken  # type: ignore[import-untyped]
    _TIKTOKEN_AVAILABLE = True
except ImportError:
    tiktoken = None  # type: ignore[assignment]
    _TIKTOKEN_AVAILABLE = False

from backend.utils.token_counter import count_tokens

if TYPE_CHECKING:
    from collections.abc import Callable

    from backend.intelligence.semantic_search import SearchResult


# Default summary keeps roughly 30% of the original token count, per the
# design spec in PHASE_GUIDE Module 2.5. A minimum floor prevents very
# short items from being chopped below a usable signal.
_SUMMARY_RATIO = 0.30
_SUMMARY_MIN_TOKENS = 10

# Summarisation is only attempted if the item overflows the remaining
# budget by strictly less than half — otherwise the summary itself would
# be too lossy to justify the slot.
_SUMMARISE_MAX_OVERFLOW_RATIO = 0.50

_SENTENCE_END_RE = re.compile(r"([.!?])(\s|$)")


@dataclass(frozen=True)
class TriagedItem:
    """One item that passed triage as either full-text or summarised.

    Attributes:
        item_id: Caller-provided identifier (from :class:`SearchResult`).
        item_type: The item type string (``"decision"``, ``"story"``, etc.).
        score: Cosine similarity at retrieval time, in ``[-1.0, 1.0]``.
        text: Either the full item text or a summarised version — see
            ``was_summarised``.
        token_count: Token count of ``text`` (not the original if summarised).
        was_summarised: ``True`` when ``text`` is a compressed form.
        metadata: The source item's metadata dict (sans retrieval keys).
    """

    item_id: str
    item_type: str
    score: float
    text: str
    token_count: int
    was_summarised: bool
    metadata: dict[str, Any] = field(default_factory=dict)
    retrieval_method: str = "vector"
    conflict_warning: dict[str, Any] | None = None


@dataclass(frozen=True)
class ExcludedItem:
    """One item cut from the context block after the budget was exhausted."""

    item_id: str
    item_type: str
    score: float
    topic: str


@dataclass(frozen=True)
class TriageResult:
    """The outcome of a single call to :meth:`ContextTriage.triage`.

    Attributes:
        included_items: Items kept at full text, in relevance-sorted order.
        summarized_items: Items compressed to a short summary, in order.
        excluded_summary: A single-line string listing every item that was
            cut, in the format ``"Excluded: <topic> (N% · type); ..."``.
            Empty string when nothing was excluded.
        excluded_items: The full structured record of excluded items —
            useful for the REST/MCP surface where a formatted string is
            not enough.
        total_tokens_used: Sum of ``token_count`` across included and
            summarised items.
        budget_remaining: ``max(0, budget - total_tokens_used)``.
    """

    included_items: list[TriagedItem]
    summarized_items: list[TriagedItem]
    excluded_summary: str
    excluded_items: list[ExcludedItem]
    total_tokens_used: int
    budget_remaining: int


class ContextTriageError(Exception):
    """Raised for invalid input to :class:`ContextTriage`."""


@lru_cache(maxsize=1)
def _encoder() -> Any:
    """Return the cached ``cl100k_base`` encoder used for token truncation.

    Only called when ``_TIKTOKEN_AVAILABLE`` is True.
    """
    return tiktoken.get_encoding("cl100k_base")


def _truncate_to_tokens(text: str, max_tokens: int) -> str:
    """Truncate ``text`` to at most ``max_tokens`` tokens.

    Uses tiktoken when available. Falls back to a character-based
    approximation (~4 chars/token for cl100k_base English) when tiktoken
    is not installed — truncation happens at a character boundary rather
    than a token boundary, which may split mid-word.
    """
    if max_tokens <= 0:
        return ""
    if _TIKTOKEN_AVAILABLE:
        enc = _encoder()
        tokens = enc.encode(text)
        if len(tokens) <= max_tokens:
            return text
        return enc.decode(tokens[:max_tokens])
    # Fallback: ~4 chars/token average for cl100k_base English prose.
    max_chars = max_tokens * 4
    if len(text) <= max_chars:
        return text
    return text[:max_chars]


def _first_sentence(text: str) -> str:
    """Return the first sentence from ``text``, or the whole string if none."""
    stripped = text.strip()
    if not stripped:
        return ""
    match = _SENTENCE_END_RE.search(stripped)
    if match is None:
        return stripped
    end = match.end(1)
    return stripped[:end].strip()


def _topic(item: SearchResult | TriagedItem | ExcludedItem) -> str:
    """Best-effort topic label for an item: title when set, else the id."""
    metadata = getattr(item, "metadata", None)
    if isinstance(metadata, dict):
        title = metadata.get("title")
        if isinstance(title, str) and title.strip():
            return title.strip()
    return item.item_id


def _item_text(item: SearchResult) -> str:
    """Pull the full text out of a :class:`SearchResult`'s metadata."""
    if not isinstance(item.metadata, dict):
        return ""
    text = item.metadata.get("text", "")
    return text if isinstance(text, str) else ""


def _relevance_percent(score: float) -> int:
    """Map a cosine score in ``[-1, 1]`` to an integer ``[0, 100]`` percent."""
    if score <= 0.0:
        return 0
    if score >= 1.0:
        return 100
    return int(round(score * 100))


class ContextTriage:
    """Walk ranked items in order and pack them within a token budget.

    Parameters:
        counter: Optional callable returning the token count of a string.
            Defaults to :func:`backend.utils.token_counter.count_tokens`.
            Injecting a counter is useful in tests where deterministic
            budgeting matters more than exact tiktoken equivalence.
        summary_ratio: Fraction of the original token count to target for
            summaries (default ``0.30``).
        min_summary_tokens: Floor for the summary target; prevents very
            short items from being chopped below usability.
    """

    def __init__(
        self,
        counter: Callable[[str], int] | None = None,
        *,
        summary_ratio: float = _SUMMARY_RATIO,
        min_summary_tokens: int = _SUMMARY_MIN_TOKENS,
    ) -> None:
        if summary_ratio <= 0.0 or summary_ratio >= 1.0:
            raise ContextTriageError(
                f"summary_ratio must be in (0, 1), got {summary_ratio}"
            )
        if min_summary_tokens < 1:
            raise ContextTriageError(
                f"min_summary_tokens must be >= 1, got {min_summary_tokens}"
            )
        self._counter: Callable[[str], int] = counter or count_tokens
        self._summary_ratio = summary_ratio
        self._min_summary_tokens = min_summary_tokens

    def triage(
        self, items: list[SearchResult], budget: int
    ) -> TriageResult:
        """Pack ``items`` into ``budget`` tokens using include/summarise/exclude.

        Items are sorted by relevance score descending. Stable: ties
        preserve caller-supplied order.

        Raises:
            ContextTriageError: If ``items`` is not a list or ``budget``
                is not a non-negative int.
        """
        if not isinstance(items, list):
            raise ContextTriageError(
                f"items must be list, got {type(items).__name__}"
            )
        if not isinstance(budget, int) or isinstance(budget, bool):
            raise ContextTriageError(
                f"budget must be int, got {type(budget).__name__}"
            )
        if budget < 0:
            raise ContextTriageError(f"budget must be >= 0, got {budget}")

        # Stable sort preserves the relative order of equally-scored items.
        sorted_items = sorted(items, key=lambda x: x.score, reverse=True)

        included: list[TriagedItem] = []
        summarised: list[TriagedItem] = []
        excluded: list[ExcludedItem] = []
        tokens_used = 0

        for i, item in enumerate(sorted_items):
            text = _item_text(item)
            if not text:
                # Items without stored text cannot contribute; skip without
                # counting them as excluded either (nothing to exclude).
                continue

            item_tokens = self._counter(text)
            remaining = budget - tokens_used

            if item_tokens <= remaining:
                included.append(
                    TriagedItem(
                        item_id=item.item_id,
                        item_type=item.item_type,
                        score=item.score,
                        text=text,
                        token_count=item_tokens,
                        was_summarised=False,
                        metadata=dict(item.metadata)
                        if isinstance(item.metadata, dict)
                        else {},
                        retrieval_method=getattr(item, "retrieval_method", "vector"),
                        conflict_warning=getattr(item, "conflict_warning", None),
                    )
                )
                tokens_used += item_tokens
                continue

            overflow = item_tokens - remaining
            # Summarise only when we can keep at least half the original —
            # anything less produces a summary too lossy to be useful.
            can_summarise = (
                item_tokens > 0
                and remaining > 0
                and (overflow / item_tokens) < _SUMMARISE_MAX_OVERFLOW_RATIO
            )
            if can_summarise:
                target = max(
                    self._min_summary_tokens,
                    int(item_tokens * self._summary_ratio),
                )
                # Cap target at the remaining budget to guarantee it fits.
                target = min(target, remaining)
                summary_text = self._summarise(text, target)
                summary_tokens = self._counter(summary_text)
                if 0 < summary_tokens <= remaining:
                    summarised.append(
                        TriagedItem(
                            item_id=item.item_id,
                            item_type=item.item_type,
                            score=item.score,
                            text=summary_text,
                            token_count=summary_tokens,
                            was_summarised=True,
                            metadata=dict(item.metadata)
                            if isinstance(item.metadata, dict)
                            else {},
                            retrieval_method=getattr(item, "retrieval_method", "vector"),
                            conflict_warning=getattr(item, "conflict_warning", None),
                        )
                    )
                    tokens_used += summary_tokens
                    continue

            # This item (and everything after it) cannot fit even as a
            # summary — collapse the tail into the excluded list.
            excluded.extend(
                ExcludedItem(
                    item_id=it.item_id,
                    item_type=it.item_type,
                    score=it.score,
                    topic=_topic(it),
                )
                for it in sorted_items[i:]
                if _item_text(it)
            )
            break

        excluded_summary = _format_excluded_summary(excluded)
        return TriageResult(
            included_items=included,
            summarized_items=summarised,
            excluded_summary=excluded_summary,
            excluded_items=excluded,
            total_tokens_used=tokens_used,
            budget_remaining=max(0, budget - tokens_used),
        )

    def _summarise(self, text: str, target_tokens: int) -> str:
        """Build a summary of ``text`` with at most ``target_tokens`` tokens."""
        if target_tokens <= 0:
            return ""
        first = _first_sentence(text)
        if not first:
            return _truncate_to_tokens(text, target_tokens)
        if self._counter(first) <= target_tokens:
            return first
        return _truncate_to_tokens(first, target_tokens)


def _format_excluded_summary(excluded: list[ExcludedItem]) -> str:
    """Render the single-line summary of excluded items."""
    if not excluded:
        return ""
    parts = [
        f"{item.topic} ({_relevance_percent(item.score)}% · {item.item_type})"
        for item in excluded
    ]
    return f"Excluded {len(excluded)} item(s): " + "; ".join(parts)


def format_context_block(
    triage_result: TriageResult,
    context_for: str,
) -> str:
    """Render a :class:`TriageResult` as an agent-facing context block.

    Output shape::

        # Context for: <context_for>
        # Tokens: <used>/<used+remaining> · included=<n> summarised=<m>

        [DECISION] (87% relevance | verified) Use Argon2id for passwords
        <full text>

        [STORY] (72% relevance | summarised) Add password reset flow
        <summary text>

        Excluded 2 item(s): Legacy hashing (41% · decision); …

    Sections are separated by blank lines. The header summarises the
    triage outcome in a form easy for downstream prompts to include
    verbatim.
    """
    if not isinstance(context_for, str) or not context_for:
        raise ContextTriageError("context_for must be a non-empty string")

    total = (
        triage_result.total_tokens_used + triage_result.budget_remaining
    )
    header = [
        f"# Context for: {context_for}",
        f"# Tokens: {triage_result.total_tokens_used}/{total} · "
        f"included={len(triage_result.included_items)} "
        f"summarised={len(triage_result.summarized_items)} "
        f"excluded={len(triage_result.excluded_items)}",
    ]

    blocks: list[str] = ["\n".join(header)]
    for item in triage_result.included_items:
        blocks.append(_render_triaged_item(item))
    for item in triage_result.summarized_items:
        blocks.append(_render_triaged_item(item))
    if triage_result.excluded_summary:
        blocks.append(triage_result.excluded_summary)

    return "\n\n".join(blocks)


_METHOD_ANNOTATION: dict[str, str] = {
    "vector": "[vector]",
    "bm25": "[keyword]",
    "both": "[vector+keyword]",
}


def _render_triaged_item(item: TriagedItem) -> str:
    """Render one :class:`TriagedItem` as a two-part section.

    Verification metadata stamped by
    :class:`backend.verification.context_verifier.ContextVerifier` is
    rendered here so the agent can see each decision's status, the
    action guidance, and (when present) the specific drift violations
    that caused the status.
    """
    tag = (item.item_type or "item").upper()
    pct = _relevance_percent(item.score)
    method_label = _METHOD_ANNOTATION.get(item.retrieval_method, "")
    relevance = f"{pct}% relevance"
    if method_label:
        relevance = f"{relevance} {method_label}"
    notes: list[str] = [relevance]
    verification = item.metadata.get("verification_status")
    if isinstance(verification, str) and verification:
        notes.append(verification)
    if item.was_summarised:
        notes.append("summarised")
    header = f"[{tag}] ({' | '.join(notes)})"
    topic = _topic(item)
    if topic and topic != item.item_id:
        header += f" {topic}"
    sections: list[str] = [header]
    if item.conflict_warning:
        cw = item.conflict_warning
        sections.append(
            f"[CONFLICT WARNING: This decision contradicts "
            f"{cw.get('conflicts_with', '')} — "
            f"{cw.get('conflict_type', '')}. "
            f"Review before applying.]"
        )
    # VGR-4: surface drift violations inline.
    drift_violations = item.metadata.get("verification_drift_violations")
    if isinstance(drift_violations, list) and drift_violations:
        for v in drift_violations[:2]:
            if not isinstance(v, dict):
                continue
            vfile = str(v.get("file", ""))
            vline = v.get("line")
            vtext = str(v.get("violation", ""))
            loc = f"{vfile}:{vline}" if vline else vfile
            sections.append(f"[DRIFT] {loc} — {vtext}")
    # VGR-5: when a superseding decision is known, point at it.
    superseded_title = item.metadata.get("verification_superseded_by_title")
    if isinstance(superseded_title, str) and superseded_title:
        sections.append(f"[SUPERSEDED BY] {superseded_title}")
    # VGR-7: action guidance. Stamped by the verifier; rendered as a
    # prefix line so the agent can act on it without scrolling.
    guidance = item.metadata.get("verification_guidance")
    if isinstance(guidance, str) and guidance:
        sections.append(f"[→] {guidance}")
    sections.append(item.text)
    return "\n".join(sections)
