"""Tree-sitter language registry for CodeLedger's AST pipeline.

Maps file extensions to grammar names and exposes cached
:class:`tree_sitter.Parser` instances for the 10 languages listed in
CLAUDE.md: Python, TypeScript, JavaScript, Go, Rust, Java, C, C++,
Ruby, C#.

Grammars are loaded on demand through ``tree-sitter-language-pack``.
Parsers are cached so repeat calls — typical during AST tracking of a
multi-language commit — avoid the grammar setup cost each time.

Security invariants enforced:
- No file I/O and no dynamic grammar loading from attacker-controlled
  paths. Language resolution is keyed on a fixed extension map and the
  language name is never passed through from untrusted input without
  going through :meth:`LanguageRegistry.detect_language`.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import TYPE_CHECKING, cast

from tree_sitter_language_pack import SupportedLanguage, get_parser

if TYPE_CHECKING:
    from tree_sitter import Parser


# Canonical language names used throughout CodeLedger. These match the
# ``tree-sitter-language-pack`` identifiers so ``get_parser`` accepts them
# directly.
_SUPPORTED: tuple[str, ...] = (
    "python",
    "typescript",
    "javascript",
    "go",
    "rust",
    "java",
    "c",
    "cpp",
    "ruby",
    "csharp",
)

_SUPPORTED_SET = frozenset(_SUPPORTED)

# File extension → language name. Lowercased keys. Extensions include the
# leading dot so ``Path.suffix`` lookup works directly.
_EXTENSION_MAP: dict[str, str] = {
    ".py": "python",
    ".pyi": "python",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".c": "c",
    ".h": "c",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".cxx": "cpp",
    ".hpp": "cpp",
    ".hh": "cpp",
    ".hxx": "cpp",
    ".rb": "ruby",
    ".cs": "csharp",
}


class LanguageNotSupportedError(Exception):
    """Raised when the caller asks for a language not on the supported list."""


class LanguageRegistry:
    """Resolve file paths to languages and supply cached parsers.

    All methods are instance methods so multiple registries can coexist
    (useful in tests), but the underlying parser cache is a class-level
    :func:`functools.lru_cache` since grammars are process-wide.
    """

    def get_parser(self, language: str) -> Parser:
        """Return a :class:`Parser` configured for ``language``.

        Args:
            language: One of the supported language names, e.g. ``"python"``.

        Raises:
            LanguageNotSupportedError: ``language`` is not recognised.
        """
        if not isinstance(language, str):
            raise LanguageNotSupportedError(
                f"language must be str, got {type(language).__name__}"
            )
        normalised = language.lower()
        if normalised not in _SUPPORTED_SET:
            raise LanguageNotSupportedError(
                f"Unsupported language: {language!r}. "
                f"Supported: {sorted(_SUPPORTED_SET)}"
            )
        return _cached_parser(normalised)

    def detect_language(self, file_path: str) -> str:
        """Return the language name matching ``file_path`` by extension.

        Args:
            file_path: File path or bare name. Only the suffix is inspected.

        Raises:
            LanguageNotSupportedError: The extension is not in the registry.
        """
        if not isinstance(file_path, str) or not file_path:
            raise LanguageNotSupportedError(
                "file_path must be a non-empty string"
            )
        suffix = Path(file_path).suffix.lower()
        if suffix not in _EXTENSION_MAP:
            raise LanguageNotSupportedError(
                f"No language registered for extension {suffix!r} "
                f"(file: {file_path!r})"
            )
        return _EXTENSION_MAP[suffix]

    def supported_languages(self) -> list[str]:
        """Return the full list of supported language names."""
        return list(_SUPPORTED)

    def supported_extensions(self) -> list[str]:
        """Return the full list of supported file extensions (leading dot)."""
        return list(_EXTENSION_MAP.keys())


@lru_cache(maxsize=len(_SUPPORTED))
def _cached_parser(language: str) -> Parser:
    """Per-language parser cache. Populated on first request."""
    try:
        # ``language`` is gated by ``_SUPPORTED_SET`` above, so it is
        # always a valid :data:`SupportedLanguage` — the cast tells mypy
        # that without losing the runtime check.
        return get_parser(cast(SupportedLanguage, language))
    except Exception as exc:
        raise LanguageNotSupportedError(
            f"Failed to load grammar for {language!r}: {exc}"
        ) from exc
