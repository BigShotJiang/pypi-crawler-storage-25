"""Evidence taxonomy for passive decision inference.

Each :class:`EvidenceType` has a :class:`EvidenceWeight` whose ``weight``
field is the contribution to a candidate's confidence score.

These weights are intentionally conservative (guard rail GR-2). They are
module-level constants — not configurable per request — so that inference
behaviour is deterministic and reproducible across runs.

The module also exports the noise-filter used by guard rail GR-10:
stdlib modules and a curated list of packaging/compat utilities never
trigger inference on their own.

Security invariants enforced:
- SEC-03: Every field is a literal string or float — no external data
  flows through this module and no credentials can be embedded.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final, Literal

EvidenceType = Literal[
    "new_import_third_party",
    "new_import_internal",
    "new_import_stdlib",
    "new_function",
    "new_class_inherits",
    "function_signature_change",
    "file_created",
    "file_deleted",
    "config_file_modified",
    "test_file_created",
    "migration_file_created",
    "dependency_added",
    "session_pattern",
]


# GR-2 mitigation for agent-volume inflation: multiplying every
# evidence weight by the source's multiplier BEFORE the single-signal
# cap fires preserves calibration regardless of how many events an
# agent chooses to self-report. Human-authored sources keep the full
# 1.0x weight. Agent-reported sources land at 0.5x so one agent
# signal caps at 0.325 (below the 0.65 single-signal ceiling) and
# even a dense multi-signal agent session cannot cross the 0.85
# multi-signal ceiling without corroborating human or file-snapshot
# evidence. See docs/audits/detection-source-actor-audit.md §1.7.B.
SOURCE_CONFIDENCE_MULTIPLIERS: Final[dict[str, float]] = {
    "git_commit": 1.0,
    "file_snapshot": 1.0,
    "agent_reported": 0.5,
}


@dataclass(frozen=True)
class EvidenceWeight:
    """Weight + metadata for one :class:`EvidenceType`."""

    evidence_type: EvidenceType
    weight: float
    description: str
    requires_verification: bool = True


# Guard rail GR-2: single-signal inferences cap at 0.65. These weights
# are the *base* contribution — the engine applies the cap in
# :func:`DecisionInferrer._score_candidate`, so raising a value here above
# 0.65 still only lifts multi-signal combinations.
EVIDENCE_WEIGHTS: Final[dict[EvidenceType, EvidenceWeight]] = {
    "new_import_third_party": EvidenceWeight(
        "new_import_third_party",
        0.55,
        "New third-party library imported — likely a technology choice",
    ),
    "new_import_internal": EvidenceWeight(
        "new_import_internal",
        0.30,
        "New internal module imported — structural dependency added",
    ),
    "new_import_stdlib": EvidenceWeight(
        "new_import_stdlib",
        0.05,
        "New stdlib import — rarely architectural on its own",
    ),
    "new_function": EvidenceWeight(
        "new_function",
        0.20,
        "New function added — surface-area change",
    ),
    "new_class_inherits": EvidenceWeight(
        "new_class_inherits",
        0.45,
        "New class added — structural pattern decision",
    ),
    "function_signature_change": EvidenceWeight(
        "function_signature_change",
        0.35,
        "Existing function signature changed — API decision",
    ),
    "file_created": EvidenceWeight(
        "file_created",
        0.25,
        "New source file created — structural decision",
    ),
    "file_deleted": EvidenceWeight(
        "file_deleted",
        0.20,
        "File deleted — removal decision",
    ),
    "config_file_modified": EvidenceWeight(
        "config_file_modified",
        0.45,
        "Project configuration file modified — setup decision",
    ),
    "test_file_created": EvidenceWeight(
        "test_file_created",
        0.30,
        "New test file created — testing-strategy decision",
    ),
    "migration_file_created": EvidenceWeight(
        "migration_file_created",
        0.60,
        "New database migration file — schema decision",
    ),
    "dependency_added": EvidenceWeight(
        "dependency_added",
        0.65,
        "New dependency declared in project config — explicit tech choice",
    ),
    "session_pattern": EvidenceWeight(
        "session_pattern",
        0.40,
        "Repeated tool-call pattern across files in the same directory",
    ),
}


# Guard rail GR-10: stdlib roots never trigger inference on their own.
# Derived from the Python 3.12 standard library module index. Sub-modules
# of these roots (``os.path``, ``urllib.request`` etc.) are classified via
# the root name so we do not need to enumerate every sub-module.
STDLIB_MODULES: Final[frozenset[str]] = frozenset(
    {
        "__future__",
        "_thread",
        "abc",
        "argparse",
        "array",
        "ast",
        "asyncio",
        "atexit",
        "base64",
        "bisect",
        "builtins",
        "bz2",
        "calendar",
        "cmath",
        "cmd",
        "code",
        "codecs",
        "collections",
        "concurrent",
        "configparser",
        "contextlib",
        "contextvars",
        "copy",
        "copyreg",
        "csv",
        "ctypes",
        "curses",
        "dataclasses",
        "datetime",
        "decimal",
        "difflib",
        "dis",
        "doctest",
        "email",
        "enum",
        "errno",
        "faulthandler",
        "fcntl",
        "filecmp",
        "fileinput",
        "fnmatch",
        "fractions",
        "ftplib",
        "functools",
        "gc",
        "getopt",
        "getpass",
        "gettext",
        "glob",
        "grp",
        "gzip",
        "hashlib",
        "heapq",
        "hmac",
        "html",
        "http",
        "imaplib",
        "importlib",
        "inspect",
        "io",
        "ipaddress",
        "itertools",
        "json",
        "keyword",
        "linecache",
        "locale",
        "logging",
        "lzma",
        "mailbox",
        "marshal",
        "math",
        "mimetypes",
        "mmap",
        "multiprocessing",
        "netrc",
        "numbers",
        "operator",
        "os",
        "pathlib",
        "pickle",
        "pkgutil",
        "platform",
        "plistlib",
        "poplib",
        "posixpath",
        "pprint",
        "profile",
        "pstats",
        "pty",
        "pwd",
        "py_compile",
        "pyclbr",
        "pydoc",
        "queue",
        "quopri",
        "random",
        "re",
        "readline",
        "reprlib",
        "resource",
        "runpy",
        "sched",
        "secrets",
        "select",
        "selectors",
        "shelve",
        "shlex",
        "shutil",
        "signal",
        "site",
        "smtplib",
        "socket",
        "socketserver",
        "sqlite3",
        "ssl",
        "stat",
        "statistics",
        "string",
        "stringprep",
        "struct",
        "subprocess",
        "sunau",
        "symtable",
        "sys",
        "sysconfig",
        "syslog",
        "tabnanny",
        "tarfile",
        "telnetlib",
        "tempfile",
        "termios",
        "test",
        "textwrap",
        "threading",
        "time",
        "timeit",
        "token",
        "tokenize",
        "tomllib",
        "trace",
        "traceback",
        "tracemalloc",
        "tty",
        "turtle",
        "types",
        "typing",
        "unicodedata",
        "unittest",
        "urllib",
        "uuid",
        "venv",
        "warnings",
        "wave",
        "weakref",
        "webbrowser",
        "wsgiref",
        "xml",
        "xmlrpc",
        "zipfile",
        "zipimport",
        "zlib",
        "zoneinfo",
    }
)

# Packaging/compat utilities that are architectural noise — their
# presence tells us nothing interesting about the project's design.
NOISE_PACKAGES: Final[frozenset[str]] = frozenset(
    {
        "typing_extensions",
        "six",
        "attrs",
        "attr",
        "pkg_resources",
        "setuptools",
        "wheel",
        "importlib_metadata",
        "importlib_resources",
        "backports",
    }
)


def _root_module(module_name: str) -> str:
    """Return the leftmost dotted segment (``a.b.c`` → ``a``)."""
    name = module_name.strip()
    if not name:
        return ""
    return name.split(".", 1)[0]


def is_stdlib_module(module_name: str) -> bool:
    """Return True if ``module_name``'s root is a Python standard-library module."""
    return _root_module(module_name) in STDLIB_MODULES


def is_noise_import(module_name: str) -> bool:
    """Return True if this import should never trigger inference.

    Guard rail GR-10: stdlib modules and curated noise packages are
    excluded from inference so ``import json`` does not masquerade as a
    technology decision.
    """
    root = _root_module(module_name)
    if not root:
        return True
    return root in STDLIB_MODULES or root in NOISE_PACKAGES


def classify_import(
    module_name: str, *, project_top_levels: frozenset[str] = frozenset()
) -> EvidenceType | None:
    """Classify a single import into an evidence type.

    Returns ``None`` when the import is noise (GR-10). Otherwise returns
    one of ``new_import_third_party``, ``new_import_internal``, or
    ``new_import_stdlib``. ``project_top_levels`` is the set of
    top-level packages that belong to the user's project — when the
    import root matches one of these, it is classified as internal.
    """
    root = _root_module(module_name)
    if not root:
        return None
    if root in NOISE_PACKAGES:
        return None
    if root in project_top_levels:
        return "new_import_internal"
    if root in STDLIB_MODULES:
        # Stdlib imports are low-signal but not hard-filtered — the
        # engine uses is_noise_import to drop them from candidate
        # groupings. We classify them here so tests can observe the
        # taxonomy explicitly.
        return "new_import_stdlib"
    return "new_import_third_party"
