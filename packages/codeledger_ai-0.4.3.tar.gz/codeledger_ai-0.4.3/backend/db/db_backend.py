"""Database backend abstraction with SQLite and PostgreSQL implementations.

Defines an async interface for persistence operations over CodeLedger's domain
tables. The abstraction is a thin CRUD layer: callers pass a table name and a
field dict produced by ``Model.to_dict()``. All queries are parameterized.

Security invariants enforced:
- SEC-01: Table names are validated against a whitelist before query assembly.
- No SQL string concatenation of user-supplied values: every value is bound
  through a ``?`` (SQLite) or ``$N`` (PostgreSQL) placeholder.

Tables covered by this module (all on the ``ALLOWED_TABLES`` whitelist and
all exclusively accessed through parameterized queries):

    users
    decisions
    stories
    sprints
    sessions
    context_items
    verifications
    ast_changes
    provenance_edges
    service_connections
    personal_access_tokens
    session_events
    file_snapshots
    unlinked_file_changes
    unlinked_commits
    inferred_decisions
    decision_conflicts
    project_source_config
    _setup
    _migrations

Anywhere this module composes a SQL string (e.g. ``INSERT INTO <table>
(col1, col2) VALUES (?, ?)``), only the whitelisted table name and the
column names from ``data`` are interpolated. Column names are separately
validated by ``_validate_column`` so an attacker cannot inject through
``data`` keys either.
"""

from __future__ import annotations

import abc
from typing import TYPE_CHECKING, Any

import aiosqlite

if TYPE_CHECKING:
    from pathlib import Path


# Tables whitelisted for use with the CRUD methods. Any table referenced by
# insert/query/update/delete must appear here — otherwise the operation is
# rejected, preventing injection via an attacker-controlled table name.
ALLOWED_TABLES: frozenset[str] = frozenset(
    {
        "users",
        "decisions",
        "stories",
        "sprints",
        "sessions",
        "context_items",
        "verifications",
        "ast_changes",
        "provenance_edges",
        "service_connections",
        "personal_access_tokens",
        "session_events",
        "file_snapshots",
        "unlinked_file_changes",
        "unlinked_commits",
        "inferred_decisions",
        "decision_conflicts",
        "project_source_config",
        "_setup",
        "_migrations",
    }
)


class DatabaseError(Exception):
    """Raised for database operation failures."""


def _validate_table(table: str) -> None:
    """Reject any table name not on the approved whitelist (SEC-01)."""
    if table not in ALLOWED_TABLES:
        raise DatabaseError(f"Unknown or disallowed table: {table!r}")


def _validate_column(name: str) -> None:
    """Reject column names containing anything but [A-Za-z0-9_] (SEC-01)."""
    if not name.replace("_", "").isalnum():
        raise DatabaseError(f"Invalid column name: {name!r}")


class DatabaseBackend(abc.ABC):
    """Abstract async database interface for CodeLedger persistence."""

    @abc.abstractmethod
    async def connect(self) -> None:
        """Open the connection or connection pool."""

    @abc.abstractmethod
    async def close(self) -> None:
        """Release all connections held by the backend."""

    @abc.abstractmethod
    async def insert(self, table: str, data: dict[str, Any]) -> None:
        """Insert a single row. Field names become columns verbatim."""

    @abc.abstractmethod
    async def get_by_id(
        self, table: str, row_id: str
    ) -> dict[str, Any] | None:
        """Return the row with matching ``id``, or None if absent."""

    @abc.abstractmethod
    async def query(
        self,
        table: str,
        where: dict[str, Any] | None = None,
        *,
        order_by: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return all rows matching simple AND-joined equality predicates."""

    @abc.abstractmethod
    async def update(
        self, table: str, row_id: str, data: dict[str, Any]
    ) -> None:
        """Overwrite the given fields on the row with matching ``id``."""

    @abc.abstractmethod
    async def delete(self, table: str, row_id: str) -> None:
        """Remove the row with matching ``id``. No error if absent."""

    @abc.abstractmethod
    async def execute_raw(
        self, sql: str, params: tuple[Any, ...] | None = None
    ) -> list[dict[str, Any]]:
        """Run a parameterized SQL statement and return rows (if any)."""


# ---------------------------------------------------------------------------
# SQLite backend
# ---------------------------------------------------------------------------


class SQLiteBackend(DatabaseBackend):
    """aiosqlite-based backend with WAL mode enabled."""

    def __init__(self, db_path: str | Path) -> None:
        self._db_path = str(db_path)
        self._conn: aiosqlite.Connection | None = None

    async def connect(self) -> None:
        self._conn = await aiosqlite.connect(self._db_path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute("PRAGMA journal_mode=WAL")
        await self._conn.execute("PRAGMA foreign_keys=ON")
        await self._conn.commit()

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    def _require_conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise DatabaseError("SQLiteBackend is not connected")
        return self._conn

    async def insert(self, table: str, data: dict[str, Any]) -> None:
        _validate_table(table)
        if not data:
            raise DatabaseError("Cannot insert empty row")
        for col in data:
            _validate_column(col)
        columns = ", ".join(data.keys())
        placeholders = ", ".join("?" for _ in data)
        sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
        conn = self._require_conn()
        try:
            await conn.execute(sql, tuple(data.values()))
            await conn.commit()
        except aiosqlite.Error as exc:
            raise DatabaseError(f"Insert into {table} failed: {exc}") from exc

    async def get_by_id(
        self, table: str, row_id: str
    ) -> dict[str, Any] | None:
        _validate_table(table)
        sql = f"SELECT * FROM {table} WHERE id = ?"
        conn = self._require_conn()
        async with conn.execute(sql, (row_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

    async def query(
        self,
        table: str,
        where: dict[str, Any] | None = None,
        *,
        order_by: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        _validate_table(table)
        params: list[Any] = []
        sql = f"SELECT * FROM {table}"
        if where:
            for col in where:
                _validate_column(col)
            clauses = " AND ".join(f"{col} = ?" for col in where)
            sql += f" WHERE {clauses}"
            params.extend(where.values())
        if order_by:
            _validate_column(order_by.replace(" DESC", "").replace(" ASC", "").strip())
            sql += f" ORDER BY {order_by}"
        if limit is not None:
            sql += " LIMIT ?"
            params.append(int(limit))
        conn = self._require_conn()
        async with conn.execute(sql, tuple(params)) as cursor:
            rows = await cursor.fetchall()
            return [dict(r) for r in rows]

    async def update(
        self, table: str, row_id: str, data: dict[str, Any]
    ) -> None:
        _validate_table(table)
        if not data:
            return
        for col in data:
            _validate_column(col)
        set_clause = ", ".join(f"{col} = ?" for col in data)
        sql = f"UPDATE {table} SET {set_clause} WHERE id = ?"
        conn = self._require_conn()
        params = (*data.values(), row_id)
        try:
            await conn.execute(sql, params)
            await conn.commit()
        except aiosqlite.Error as exc:
            raise DatabaseError(f"Update on {table} failed: {exc}") from exc

    async def delete(self, table: str, row_id: str) -> None:
        _validate_table(table)
        sql = f"DELETE FROM {table} WHERE id = ?"
        conn = self._require_conn()
        try:
            await conn.execute(sql, (row_id,))
            await conn.commit()
        except aiosqlite.Error as exc:
            raise DatabaseError(f"Delete from {table} failed: {exc}") from exc

    async def execute_raw(
        self, sql: str, params: tuple[Any, ...] | None = None
    ) -> list[dict[str, Any]]:
        conn = self._require_conn()
        try:
            async with conn.execute(sql, params or ()) as cursor:
                if cursor.description is None:
                    await conn.commit()
                    return []
                rows = await cursor.fetchall()
                return [dict(r) for r in rows]
        except aiosqlite.Error as exc:
            raise DatabaseError(f"Raw query failed: {exc}") from exc


# ---------------------------------------------------------------------------
# PostgreSQL backend
# ---------------------------------------------------------------------------


class PostgreSQLBackend(DatabaseBackend):
    """asyncpg-based backend with a connection pool."""

    def __init__(self, dsn: str, *, min_size: int = 1, max_size: int = 10) -> None:
        self._dsn = dsn
        self._min_size = min_size
        self._max_size = max_size
        # Type ignored: asyncpg.Pool is only imported when needed (below)
        self._pool: Any = None  # Any: asyncpg optional; type resolved at runtime

    async def connect(self) -> None:
        try:
            import asyncpg  # type: ignore[import-untyped]  # lazy, optional
        except ImportError as exc:
            raise DatabaseError(
                "PostgreSQL backend requires asyncpg. "
                "Install with: pip install codeledger-ai[postgres]"
            ) from exc

        self._pool = await asyncpg.create_pool(
            self._dsn, min_size=self._min_size, max_size=self._max_size
        )

    async def close(self) -> None:
        if self._pool is not None:
            await self._pool.close()
            self._pool = None

    def _require_pool(self) -> Any:  # Any: asyncpg.Pool; see _pool field
        if self._pool is None:
            raise DatabaseError("PostgreSQLBackend is not connected")
        return self._pool

    async def insert(self, table: str, data: dict[str, Any]) -> None:
        _validate_table(table)
        if not data:
            raise DatabaseError("Cannot insert empty row")
        for col in data:
            _validate_column(col)
        columns = ", ".join(data.keys())
        placeholders = ", ".join(f"${i + 1}" for i in range(len(data)))
        sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
        pool = self._require_pool()
        async with pool.acquire() as conn:
            try:
                await conn.execute(sql, *data.values())
            except Exception as exc:
                raise DatabaseError(f"Insert into {table} failed: {exc}") from exc

    async def get_by_id(
        self, table: str, row_id: str
    ) -> dict[str, Any] | None:
        _validate_table(table)
        sql = f"SELECT * FROM {table} WHERE id = $1"
        pool = self._require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(sql, row_id)
            return dict(row) if row else None

    async def query(
        self,
        table: str,
        where: dict[str, Any] | None = None,
        *,
        order_by: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        _validate_table(table)
        params: list[Any] = []
        sql = f"SELECT * FROM {table}"
        if where:
            for col in where:
                _validate_column(col)
            clauses = " AND ".join(
                f"{col} = ${i + 1}" for i, col in enumerate(where)
            )
            sql += f" WHERE {clauses}"
            params.extend(where.values())
        if order_by:
            _validate_column(order_by.replace(" DESC", "").replace(" ASC", "").strip())
            sql += f" ORDER BY {order_by}"
        if limit is not None:
            sql += f" LIMIT ${len(params) + 1}"
            params.append(int(limit))
        pool = self._require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
            return [dict(r) for r in rows]

    async def update(
        self, table: str, row_id: str, data: dict[str, Any]
    ) -> None:
        _validate_table(table)
        if not data:
            return
        for col in data:
            _validate_column(col)
        set_clause = ", ".join(
            f"{col} = ${i + 1}" for i, col in enumerate(data)
        )
        sql = f"UPDATE {table} SET {set_clause} WHERE id = ${len(data) + 1}"
        pool = self._require_pool()
        async with pool.acquire() as conn:
            try:
                await conn.execute(sql, *data.values(), row_id)
            except Exception as exc:
                raise DatabaseError(f"Update on {table} failed: {exc}") from exc

    async def delete(self, table: str, row_id: str) -> None:
        _validate_table(table)
        sql = f"DELETE FROM {table} WHERE id = $1"
        pool = self._require_pool()
        async with pool.acquire() as conn:
            try:
                await conn.execute(sql, row_id)
            except Exception as exc:
                raise DatabaseError(f"Delete from {table} failed: {exc}") from exc

    async def execute_raw(
        self, sql: str, params: tuple[Any, ...] | None = None
    ) -> list[dict[str, Any]]:
        pool = self._require_pool()
        async with pool.acquire() as conn:
            try:
                if sql.strip().upper().startswith("SELECT"):
                    rows = await conn.fetch(sql, *(params or ()))
                    return [dict(r) for r in rows]
                await conn.execute(sql, *(params or ()))
                return []
            except Exception as exc:
                raise DatabaseError(f"Raw query failed: {exc}") from exc
