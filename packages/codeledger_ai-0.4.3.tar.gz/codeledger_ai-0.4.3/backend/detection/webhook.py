"""GitHub webhook receiver — per-project HMAC-SHA256 signed payloads.

Exposes ``POST /webhooks/github/{project_id}``. Every request is
authenticated by an HMAC-SHA256 signature over the raw request body,
keyed by a per-project secret stored in the credential vault under
``webhook_github:<project_id>``.

Authentication flow:

1. Read ``X-Hub-Signature-256`` header (format ``sha256=<hex>``).
2. Look up the per-project secret via
   :meth:`CredentialManager.get("webhook_github", project_id)`.
3. Compute ``hmac.new(secret, body, sha256).hexdigest()`` and compare
   using :func:`hmac.compare_digest`.
4. Reject with ``401`` and empty body on any failure — no detail leaks.

Actor classification from the GitHub payload:

* ``sender.type == 'Bot'`` → ``webhook_bot``
* ``sender.login`` ends in ``[bot]`` → ``webhook_bot``
* ``sender.login`` is a known bot (dependabot, renovate, etc.)
  → ``webhook_bot``
* Otherwise → ``human`` with ``actor_id = sender.email or sender.login``

A single successful request produces one :class:`ChangeEvent` which is
emitted through the shared detector queue via
:class:`GitCommitDetector`. The event carries the source
``git_commit`` regardless of actor type — the commit reached us via
GitHub's push event, so the source is still git.

Security invariants enforced:
- SEC-05: Signature verification gates every request. No bearer or
  cookie auth is consulted here; the caller must be configured as a
  public path in :mod:`backend.main`.
- SEC-02: Signature-failure responses have empty bodies — the caller
  learns only that authentication failed, never why.
- SEC-03: The event payload surfaces only identifiers extracted from
  the GitHub body; commit diffs and tokens are excluded.

**Replay semantics:** this module does not dedup on GitHub's delivery
UUID. Duplicate deliveries (GitHub retries) will produce duplicate
events. Dedup is out of scope for the v11 change — see the test
docstring for :class:`TestWebhookSignature`.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from fastapi import APIRouter, Request, Response

from backend.detection.events import ChangeEvent

if TYPE_CHECKING:
    from backend.auth.credential_manager import CredentialManager
    from backend.detection.registry import DetectorRegistry

logger = logging.getLogger(__name__)


_WEBHOOK_VAULT_PROVIDER = "webhook_github"
_SIGNATURE_HEADER = "X-Hub-Signature-256"
_SIGNATURE_PREFIX = "sha256="

# Curated list of known GitHub bot account logins. Any of these wins
# the classifier straight away; the generic ``*[bot]`` pattern and the
# ``sender.type`` check cover everything else.
_KNOWN_BOT_LOGINS: frozenset[str] = frozenset(
    {
        "dependabot[bot]",
        "renovate[bot]",
        "github-actions[bot]",
        "gitauto-ai[bot]",
        "mergify[bot]",
        "codecov[bot]",
    }
)


def _classify_actor(sender: dict[str, Any]) -> tuple[str, str]:
    """Return ``(actor_type, actor_id)`` from a GitHub ``sender`` object.

    ``actor_id`` is always non-empty — a commit without any sender
    identity cannot reach this function because the webhook payload
    is rejected earlier.
    """
    login = str(sender.get("login") or "").strip()
    sender_type = str(sender.get("type") or "").strip()
    email = str(sender.get("email") or "").strip()

    if sender_type == "Bot" or login in _KNOWN_BOT_LOGINS or login.endswith("[bot]"):
        return "webhook_bot", login or "unknown_bot"
    return "human", email or login or "unknown_human"


def _verify_signature(secret: str, body: bytes, header: str) -> bool:
    """Timing-safe HMAC-SHA256 verification of ``X-Hub-Signature-256``."""
    if not header.startswith(_SIGNATURE_PREFIX):
        return False
    expected = hmac.new(
        secret.encode("utf-8"), body, hashlib.sha256
    ).hexdigest()
    provided = header[len(_SIGNATURE_PREFIX):]
    return hmac.compare_digest(expected, provided)


def _unauthorized() -> Response:
    """Return a 401 with an empty body — never leak cause of failure."""
    return Response(status_code=401, content=b"")


def build_github_webhook_router(
    creds: CredentialManager,
    registry: DetectorRegistry,
) -> APIRouter:
    """Create the ``/webhooks/github`` router bound to the given dependencies.

    ``creds`` resolves per-project webhook secrets.
    ``registry`` is used to reach the ``git_commit`` detector and emit
    the resulting :class:`ChangeEvent`.
    """
    router = APIRouter()

    @router.post("/webhooks/github/{project_id}")
    async def github_webhook(
        project_id: str, request: Request
    ) -> Response:
        if not project_id or not project_id.strip():
            return _unauthorized()

        body = await request.body()
        signature = request.headers.get(_SIGNATURE_HEADER, "")
        if not signature:
            return _unauthorized()

        try:
            secret = creds.get(_WEBHOOK_VAULT_PROVIDER, project_id)
        except Exception:
            # Credential manager failure is indistinguishable from a
            # missing secret as far as the caller is concerned.
            logger.warning(
                "webhook secret lookup failed for project=%s",
                project_id,
                exc_info=True,
            )
            return _unauthorized()
        if not secret:
            return _unauthorized()

        if not _verify_signature(secret, body, signature):
            return _unauthorized()

        # Past signature verification: the body is trusted enough to
        # parse. A malformed payload from a signed source is still a
        # client error, but the signature check was our only auth.
        try:
            payload = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return Response(status_code=400, content=b"Bad Request")
        if not isinstance(payload, dict):
            return Response(status_code=400, content=b"Bad Request")

        sender = payload.get("sender")
        if not isinstance(sender, dict):
            return Response(status_code=400, content=b"Bad Request")

        actor_type, actor_id = _classify_actor(sender)
        event = ChangeEvent(
            change_event_source="git_commit",
            actor_type=actor_type,  # type: ignore[arg-type]
            actor_id=actor_id,
            project_id=project_id,
            payload={
                "delivery_id": request.headers.get(
                    "X-GitHub-Delivery", ""
                ),
                "event_type": request.headers.get("X-GitHub-Event", ""),
                "sender_login": str(sender.get("login") or ""),
            },
            created_at=datetime.now(UTC),
        )
        detector = registry.detector("git_commit")
        await detector.emit(event)
        return Response(status_code=200, content=b"OK")

    return router
