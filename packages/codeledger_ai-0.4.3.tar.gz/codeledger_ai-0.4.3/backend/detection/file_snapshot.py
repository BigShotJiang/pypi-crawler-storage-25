"""File-snapshot detector — registry adapter for the watchdog-based path.

The actual filesystem observation lives in
:mod:`backend.utils.file_watcher`. This detector exposes the
:class:`AbstractDetector` lifecycle so the :class:`DetectorRegistry`
can start, stop, and health-check the watcher through a uniform
interface. Events emitted by the file watcher come through the HTTP
``/api/hooks/file-change`` endpoint, which builds a
:class:`ChangeEvent` tagged with ``change_event_source="file_snapshot"``
and calls :meth:`emit`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from backend.detection.base import AbstractDetector, DetectorStatus

if TYPE_CHECKING:
    import asyncio
    from collections.abc import Callable

    from backend.detection.events import ChangeEvent


class FileSnapshotDetector(AbstractDetector):
    """Tag file-watcher events. ``start``/``stop`` toggle the watcher.

    ``observer_factory`` is a callable that returns an object exposing
    ``start()`` and ``stop()`` methods (typically a
    ``watchdog.observers.Observer``). The factory lets tests inject a
    fake observer without instantiating the real filesystem watcher.
    """

    source = "file_snapshot"

    def __init__(
        self,
        queue: asyncio.Queue[ChangeEvent],
        *,
        observer_factory: Callable[[], object] | None = None,
    ) -> None:
        super().__init__(queue)
        self._observer_factory = observer_factory
        self._observer: object | None = None
        self._running = False

    async def start(self) -> None:
        """Spin up the underlying observer, if one was configured."""
        if self._running:
            return
        if self._observer_factory is not None:
            observer = self._observer_factory()
            start = getattr(observer, "start", None)
            if callable(start):
                start()
            self._observer = observer
        self._running = True

    async def stop(self) -> None:
        """Halt and release the observer."""
        if not self._running:
            return
        if self._observer is not None:
            stop = getattr(self._observer, "stop", None)
            if callable(stop):
                try:
                    stop()
                except Exception:
                    # Observer shutdown is best-effort — if the watcher
                    # is already dead, we still want to clear state.
                    pass
            self._observer = None
        self._running = False

    async def health(self) -> DetectorStatus:
        if not self._running:
            return DetectorStatus.STOPPED
        if self._observer is None:
            # Running without an observer means no filesystem events
            # will ever arrive — treat as degraded rather than healthy.
            return DetectorStatus.DEGRADED
        is_alive = getattr(self._observer, "is_alive", None)
        if callable(is_alive) and not is_alive():
            return DetectorStatus.DEGRADED
        return DetectorStatus.HEALTHY
