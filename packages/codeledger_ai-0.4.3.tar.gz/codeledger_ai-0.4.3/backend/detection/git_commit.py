"""Git-commit detector — thin wrapper around the HTTP hook pipeline.

The git detection path already exists: ``.git/hooks/post-commit`` POSTs
to ``/api/hooks/post-commit``, which runs AST analysis. This detector
is the registry-facing adapter that tags events with
``change_event_source="git_commit"`` and routes them through the
shared detector queue for any downstream consumer that is listening.

The detector itself owns no transport; it is driven by the HTTP
endpoint calling :meth:`emit` after the hook payload has been parsed
and actor information extracted. ``start``/``stop`` are state flags
used by :meth:`health` to signal whether the hook endpoint is
currently accepting events.
"""

from __future__ import annotations

from backend.detection.base import AbstractDetector, DetectorStatus


class GitCommitDetector(AbstractDetector):
    """Tag git-hook events and feed them into the shared detector queue."""

    source = "git_commit"

    def __init__(self, queue) -> None:  # type: ignore[no-untyped-def]
        super().__init__(queue)
        self._running = False

    async def start(self) -> None:
        """Mark the detector as accepting events. Idempotent."""
        self._running = True

    async def stop(self) -> None:
        """Stop accepting events. Idempotent."""
        self._running = False

    async def health(self) -> DetectorStatus:
        """HEALTHY when running; STOPPED otherwise.

        There is no probe into the HTTP hook endpoint itself — the
        endpoint's own health is observable through the standard
        ``/health`` route and the server's uvicorn worker status.
        """
        return DetectorStatus.HEALTHY if self._running else DetectorStatus.STOPPED
