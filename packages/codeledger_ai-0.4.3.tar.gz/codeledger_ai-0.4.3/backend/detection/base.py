"""Abstract detector contract — every detector implements this.

:class:`AbstractDetector` is a thin ABC that captures the detector
lifecycle (``start`` / ``stop``), event routing (``emit``), and health
reporting (``health``). Concrete detectors — :class:`GitCommitDetector`,
:class:`FileSnapshotDetector`, :class:`AgentReportedDetector` — all
push events into the same injected :class:`asyncio.Queue` so the
downstream pipeline does not care which detector observed the change.

The queue is **injected** in the constructor rather than created
internally so tests can supply a deterministic queue, and so multiple
detectors can share one queue at runtime (which is the production
configuration).

Security invariants enforced:
- SEC-03: :class:`ChangeEvent` payloads are the only values a detector
  may emit. The base class refuses to emit anything else.
"""

from __future__ import annotations

import abc
import asyncio
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from backend.detection.events import ChangeEvent


class DetectorStatus(str, Enum):
    """Lifecycle-ish health signal returned by :meth:`AbstractDetector.health`."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    STOPPED = "stopped"
    ERROR = "error"


class DetectorError(Exception):
    """Raised when a detector cannot honor its lifecycle contract."""


class AbstractDetector(abc.ABC):
    """Base class for every detection source.

    Subclasses must set the class attribute ``source`` to one of the
    values in :data:`backend.detection.events.ALLOWED_SOURCES`. The
    shared queue is passed in at construction time so the registry can
    wire every detector to the same downstream consumer.
    """

    # Subclasses MUST override this with one of the ALLOWED_SOURCES
    # values. The check runs at instantiation so abstract-intermediate
    # subclasses — which can never be instantiated anyway — do not
    # trip it.
    source: str = ""

    def __init__(self, queue: asyncio.Queue[ChangeEvent]) -> None:
        if not self.source:
            raise TypeError(
                f"{type(self).__name__} must set a non-empty class "
                "attribute ``source`` before instantiation"
            )
        if not isinstance(queue, asyncio.Queue):
            raise DetectorError(
                "AbstractDetector requires an asyncio.Queue; got "
                f"{type(queue).__name__}"
            )
        self._queue: asyncio.Queue[ChangeEvent] = queue

    @abc.abstractmethod
    async def start(self) -> None:
        """Begin observation. Idempotent: a second call is a no-op."""

    @abc.abstractmethod
    async def stop(self) -> None:
        """Halt observation. Idempotent: a second call is a no-op."""

    @abc.abstractmethod
    async def health(self) -> DetectorStatus:
        """Return the current :class:`DetectorStatus` for this detector."""

    async def emit(self, event: ChangeEvent) -> None:
        """Enqueue a :class:`ChangeEvent` for downstream consumers.

        Validates that the event's source matches this detector's
        declared source, catching the case where a detector accidentally
        forwards an event produced by a peer.
        """
        from backend.detection.events import ChangeEvent as _ChangeEvent

        if not isinstance(event, _ChangeEvent):
            raise DetectorError(
                "emit() requires a ChangeEvent instance; got "
                f"{type(event).__name__}"
            )
        if event.change_event_source != self.source:
            raise DetectorError(
                f"Source mismatch: detector={self.source!r} "
                f"event={event.change_event_source!r}"
            )
        await self._queue.put(event)
