"""Detection subsystem — sources, actors, and event routing.

Exposes the Pydantic :class:`ChangeEvent` model and the
:class:`AbstractDetector` contract implemented by
:class:`GitCommitDetector`, :class:`FileSnapshotDetector`, and
:class:`AgentReportedDetector`. The :class:`DetectorRegistry` coordinates
project-level source preferences without owning the detectors
themselves — every detector runs server-wide and tags the events it
emits with its own source value.

Security invariants enforced:
- SEC-03: Events carry only identifiers, paths, and short labels. File
  contents and credential material never flow through :class:`ChangeEvent`.
"""
