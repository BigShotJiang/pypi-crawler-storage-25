"""Agent-reported detector — MCP-tool-driven, no background threads.

The MCP tool ``detection.report_agent_edit`` constructs a
:class:`ChangeEvent` with ``change_event_source="agent_reported"``
and ``actor_type="agent"`` and calls :meth:`emit`. There is no
polling or filesystem observation here — the detector is passive by
construction.

``start`` and ``stop`` are idempotent no-ops because there is no
background state to toggle; they exist only to satisfy the
:class:`AbstractDetector` contract.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from backend.detection.base import AbstractDetector, DetectorStatus

if TYPE_CHECKING:
    import asyncio
    from collections.abc import Callable

    from backend.detection.events import ChangeEvent


class AgentReportedDetector(AbstractDetector):
    """Tag MCP-reported edits. No background thread required."""

    source = "agent_reported"

    def __init__(
        self,
        queue: asyncio.Queue[ChangeEvent],
        *,
        reachability_probe: Callable[[], bool] | None = None,
    ) -> None:
        super().__init__(queue)
        self._running = False
        self._reachability_probe = reachability_probe

    async def start(self) -> None:
        """Idempotent no-op — there is nothing to start."""
        self._running = True

    async def stop(self) -> None:
        """Idempotent no-op — there is nothing to stop."""
        self._running = False

    async def health(self) -> DetectorStatus:
        """HEALTHY when started and the MCP transport probe succeeds.

        ``reachability_probe`` is an optional callable injected by the
        server; it returns ``True`` when the MCP server is reachable.
        With no probe configured, we assume HEALTHY when started — this
        is safe for solo-mode where the MCP server is in-process.
        """
        if not self._running:
            return DetectorStatus.STOPPED
        if self._reachability_probe is None:
            return DetectorStatus.HEALTHY
        try:
            reachable = bool(self._reachability_probe())
        except Exception:
            return DetectorStatus.ERROR
        return DetectorStatus.HEALTHY if reachable else DetectorStatus.DEGRADED
