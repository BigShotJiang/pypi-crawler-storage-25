"""Detector registry — per-server lifecycle with per-project source preference.

**Fallback is explicit per project policy.** Use ``codeledger source
set`` (CLI) or ``detection.switch_source`` (MCP) to switch. No
auto-fallback is implemented: when a source degrades, the registry
reports it via :meth:`status` but does not swap behind the user's back.

The registry owns no detector logic of its own. It:

1. Holds references to the three detectors (git_commit, file_snapshot,
   agent_reported) instantiated at server start and running globally —
   every event is tagged with its detector's source and routed by
   ``project_id`` via the shared queue.
2. Reads and writes ``project_source_config`` — the per-project row
   that records which source a project considers authoritative.
3. Coordinates :meth:`switch_source`: waits for the shared queue to
   drain so in-flight events reach the downstream consumer before the
   preference flips.

``switch_source`` is strictly a preference update. Detectors are not
stopped or started. If the drain window expires before the queue is
empty, the preference is not updated and the caller receives a
:class:`SwitchResult` with ``success=False`` and
``reason="queue_not_drained"``. This preserves in-flight events at
the cost of the switch being deferred.

Security invariants enforced:
- SEC-01: The preference row is written through the standard
  :class:`DatabaseBackend` CRUD layer — no ad-hoc SQL.
- SEC-03: :meth:`status` responses carry only project metadata and
  enum values. No credential material crosses this boundary.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from backend.detection.events import ALLOWED_ACTOR_TYPES, ALLOWED_SOURCES

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend
    from backend.detection.base import AbstractDetector
    from backend.detection.events import ChangeEvent

logger = logging.getLogger(__name__)


_DEFAULT_DRAIN_TIMEOUT_S = 10
_DRAIN_POLL_INTERVAL_S = 0.05


@dataclass(frozen=True)
class SwitchResult:
    """Outcome of a :meth:`DetectorRegistry.switch_source` call."""

    success: bool
    reason: str = ""
    events_remaining: int = 0
    previous_source: str = ""
    new_source: str = ""


@dataclass
class _AuditRecord:
    """A single source-switch audit trail entry.

    Collected in memory for in-process inspection (the persisted audit
    path goes through ``session_events`` elsewhere).
    """

    project_id: str
    previous_source: str
    new_source: str
    at: datetime = field(default_factory=lambda: datetime.now(UTC))


class DetectorRegistryError(Exception):
    """Raised for registry invariant violations."""


class DetectorRegistry:
    """Server-wide registry: per-project source preference + detector health.

    Fallback is explicit per project policy. Use
    ``codeledger source set`` to switch. No auto-fallback.
    """

    def __init__(
        self,
        db: DatabaseBackend,
        queue: asyncio.Queue[ChangeEvent],
        detectors: dict[str, AbstractDetector],
    ) -> None:
        missing = ALLOWED_SOURCES - set(detectors)
        extra = set(detectors) - ALLOWED_SOURCES
        if missing or extra:
            raise DetectorRegistryError(
                "Detectors dict must cover exactly the allowed sources. "
                f"Missing={sorted(missing)} extra={sorted(extra)}"
            )
        self._db = db
        self._queue = queue
        self._detectors = detectors
        # Concurrency gate: serialises switch_source calls so two
        # concurrent switches on the same project cannot interleave.
        self._switch_locks: dict[str, asyncio.Lock] = {}
        self._audit_log: list[_AuditRecord] = []

    # ------------------------------------------------------------------
    # Preference reads
    # ------------------------------------------------------------------

    async def get_preferred_source(self, project_id: str) -> str:
        """Return the preferred source for ``project_id``.

        Defaults to ``"git_commit"`` when no preference row exists so
        fresh projects behave the same as before v11.
        """
        if not project_id:
            raise DetectorRegistryError("project_id must be non-empty")
        row = await self._db.get_by_id("project_source_config", project_id)
        if row is None:
            return "git_commit"
        return str(row.get("preferred_source") or "git_commit")

    # ------------------------------------------------------------------
    # Source switching
    # ------------------------------------------------------------------

    async def switch_source(
        self,
        project_id: str,
        new_source: str,
        drain_timeout_s: int = _DEFAULT_DRAIN_TIMEOUT_S,
    ) -> SwitchResult:
        """Update ``project_source_config.preferred_source`` for ``project_id``.

        Returns :class:`SwitchResult`:

        * ``success=True`` — the preference was updated (or was already
          the requested value).
        * ``success=False, reason="queue_not_drained"`` — in-flight
          events did not process within ``drain_timeout_s`` seconds;
          the preference is unchanged.
        * ``success=False, reason="invalid_source"`` — ``new_source``
          is not one of :data:`ALLOWED_SOURCES`.
        * ``success=False, reason="invalid_project_id"`` —
          ``project_id`` was empty or whitespace.
        """
        if not project_id or not project_id.strip():
            return SwitchResult(success=False, reason="invalid_project_id")
        if new_source not in ALLOWED_SOURCES:
            return SwitchResult(success=False, reason="invalid_source")

        lock = self._switch_locks.setdefault(project_id, asyncio.Lock())
        async with lock:
            current = await self.get_preferred_source(project_id)
            if current == new_source:
                return SwitchResult(
                    success=True,
                    reason="noop",
                    previous_source=current,
                    new_source=new_source,
                )

            drained = await self._wait_for_drain(drain_timeout_s)
            if not drained:
                return SwitchResult(
                    success=False,
                    reason="queue_not_drained",
                    events_remaining=self._queue.qsize(),
                    previous_source=current,
                    new_source=new_source,
                )

            await self._persist_preference(project_id, new_source)
            self._audit_log.append(
                _AuditRecord(
                    project_id=project_id,
                    previous_source=current,
                    new_source=new_source,
                )
            )
            logger.info(
                "source switch: project=%s %s -> %s",
                project_id,
                current,
                new_source,
            )
            return SwitchResult(
                success=True,
                previous_source=current,
                new_source=new_source,
            )

    async def _wait_for_drain(self, timeout_s: int) -> bool:
        """Poll until the shared queue reaches empty, or timeout expires."""
        if timeout_s <= 0:
            return self._queue.qsize() == 0
        deadline = asyncio.get_event_loop().time() + float(timeout_s)
        while asyncio.get_event_loop().time() < deadline:
            if self._queue.qsize() == 0:
                return True
            await asyncio.sleep(_DRAIN_POLL_INTERVAL_S)
        return self._queue.qsize() == 0

    async def _persist_preference(
        self, project_id: str, new_source: str
    ) -> None:
        """Upsert the per-project preference row."""
        now_iso = datetime.now(UTC).isoformat()
        existing = await self._db.get_by_id(
            "project_source_config", project_id
        )
        # NB: the table's PK column is named ``id`` to match the
        # CodeLedger CRUD convention; for this table, ``id`` IS the
        # project_id. The registry uses "project_id" in its public
        # API to keep the semantic clear to callers.
        if existing is None:
            await self._db.insert(
                "project_source_config",
                {
                    "id": project_id,
                    "preferred_source": new_source,
                    "created_at": now_iso,
                    "updated_at": now_iso,
                },
            )
        else:
            await self._db.update(
                "project_source_config",
                project_id,
                {"preferred_source": new_source, "updated_at": now_iso},
            )

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    async def status(self, project_id: str) -> dict[str, Any]:
        """Return a status snapshot for ``project_id``.

        Shape:
        ``{"project_id", "current_source", "actor_config", "detector_health",
        "queue_depth"}``. ``detector_health`` is the detector matching the
        project's current preferred source.
        """
        if not project_id:
            raise DetectorRegistryError("project_id must be non-empty")
        current = await self.get_preferred_source(project_id)
        detector = self._detectors[current]
        health = await detector.health()
        return {
            "project_id": project_id,
            "current_source": current,
            "actor_config": {
                "types_allowed": sorted(ALLOWED_ACTOR_TYPES),
            },
            "detector_health": health.value,
            "queue_depth": self._queue.qsize(),
        }

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def audit_log(self) -> tuple[_AuditRecord, ...]:
        """Read-only tuple of in-memory audit records."""
        return tuple(self._audit_log)

    def detector(self, source: str) -> AbstractDetector:
        """Return the registered detector instance for ``source``."""
        if source not in self._detectors:
            raise DetectorRegistryError(f"Unknown source: {source!r}")
        return self._detectors[source]
