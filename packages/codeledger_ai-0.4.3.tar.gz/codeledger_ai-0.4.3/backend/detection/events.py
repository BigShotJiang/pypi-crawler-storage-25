"""Change-event payload model — orthogonal source and actor.

:class:`ChangeEvent` is the single canonical payload every detector
emits. It carries:

* ``change_event_source`` — which detector observed the change
  (``git_commit``, ``file_snapshot``, ``agent_reported``).
* ``actor_type`` — who or what caused the change
  (``human``, ``ci_bot``, ``webhook_bot``, ``agent``).
* ``actor_id`` — a detector-supplied identifier for the actor
  (git author email, bot login, agent session id).

The two dimensions are orthogonal. A human commit arrives as
``(git_commit, human, <email>)``. A Dependabot commit via webhook is
``(git_commit, webhook_bot, dependabot[bot])``. An MCP-reported edit is
``(agent_reported, agent, <session_id>)``. A file-watcher save is
``(file_snapshot, human, None)`` — the filesystem does not identify the
author.

``from_legacy_row`` converts a pre-v11 ``ast_changes`` database row —
which still uses ``change_event_type`` and knows nothing about actors —
into the modern :class:`ChangeEvent` shape. Legacy rows are always
treated as ``actor_type='human'``, ``actor_id=None``, per the v11
backfill policy.

Security invariants enforced:
- SEC-03: No credential material appears on any field. ``payload`` is
  an opaque dict but validators reject obviously-sensitive keys
  (``token``, ``password``, etc.) so a careless caller cannot smuggle
  secrets through detection logging.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, ClassVar, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


SourceLiteral = Literal["git_commit", "file_snapshot", "agent_reported"]
ActorLiteral = Literal["human", "ci_bot", "webhook_bot", "agent"]


ALLOWED_SOURCES: frozenset[str] = frozenset(
    {"git_commit", "file_snapshot", "agent_reported"}
)
ALLOWED_ACTOR_TYPES: frozenset[str] = frozenset(
    {"human", "ci_bot", "webhook_bot", "agent"}
)


# Payload keys we refuse to accept even in the free-form ``payload``
# dict. Detection logs otherwise propagate untouched, so this is the
# last barrier protecting SEC-03.
_FORBIDDEN_PAYLOAD_KEYS: frozenset[str] = frozenset(
    {
        "token",
        "access_token",
        "refresh_token",
        "secret",
        "password",
        "api_key",
        "private_key",
        "authorization",
    }
)


class ChangeEvent(BaseModel):
    """A single structural change, tagged with source and actor.

    Detector implementations construct this model and push it into the
    registry's queue via :meth:`AbstractDetector.emit`. Downstream
    consumers receive the event, persist the underlying AST changes
    (via :class:`backend.intelligence.ast_tracker.ASTTracker`), and
    stamp each row with the actor fields.
    """

    # Pydantic V2 config — forbid extra keys so field drift is caught
    # at construction rather than silently persisted.
    model_config: ClassVar[ConfigDict] = ConfigDict(extra="forbid")

    change_event_source: SourceLiteral
    actor_type: ActorLiteral
    actor_id: str | None = None
    project_id: str
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime

    @field_validator("project_id")
    @classmethod
    def _project_id_non_empty(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("project_id must be a non-empty string")
        return value

    @field_validator("actor_id")
    @classmethod
    def _actor_id_shape(cls, value: str | None) -> str | None:
        if value is None:
            return None
        if not value.strip():
            raise ValueError("actor_id must be a non-empty string or None")
        return value

    @field_validator("payload")
    @classmethod
    def _payload_no_secrets(
        cls, value: dict[str, Any]
    ) -> dict[str, Any]:
        lowered = {str(k).lower() for k in value}
        bad = lowered & _FORBIDDEN_PAYLOAD_KEYS
        if bad:
            raise ValueError(
                "payload keys contain secret-like names: "
                f"{sorted(bad)}. Redact before emitting."
            )
        return value

    def model_post_init(self, _context: Any) -> None:
        """Enforce cross-field rules that field_validator cannot express."""
        if self.actor_type != "human" and not self.actor_id:
            raise ValueError(
                f"actor_id is required when actor_type='{self.actor_type}'"
            )

    @classmethod
    def from_legacy_row(cls, row: dict[str, Any]) -> ChangeEvent:
        """Construct a :class:`ChangeEvent` from a pre-v11 ``ast_changes`` row.

        The legacy row carries ``change_event_type`` (renamed to
        ``change_event_source`` in v11) and no actor information.
        Every legacy row is treated as human-authored per the v11
        backfill rule. ``actor_id`` is always ``None`` for legacy
        rows because the data was never captured.
        """
        raw_source = str(
            row.get("change_event_source")
            or row.get("change_event_type")
            or "git_commit"
        )
        if raw_source not in ALLOWED_SOURCES:
            raise ValueError(
                f"Unknown change_event_source in legacy row: {raw_source!r}"
            )
        project_id = str(row.get("project_id") or "")
        if not project_id:
            raise ValueError(
                "Legacy row is missing project_id; cannot construct "
                "ChangeEvent"
            )
        created_raw = row.get("created_at")
        if isinstance(created_raw, str):
            created_at = datetime.fromisoformat(created_raw)
        elif isinstance(created_raw, datetime):
            created_at = created_raw
        else:
            raise ValueError(
                "Legacy row is missing created_at; cannot construct "
                "ChangeEvent"
            )
        return cls(
            change_event_source=raw_source,  # type: ignore[arg-type]
            actor_type="human",
            actor_id=None,
            project_id=project_id,
            payload={},
            created_at=created_at,
        )
