"""Security-headers middleware for the CodeLedger FastAPI application.

Attaches OWASP-recommended response headers to every HTTP response that
passes through the middleware. The headers applied are deliberately
conservative — they match the ``solo`` and ``team`` modes' typical
deployment where the dashboard is served over HTTP on localhost or over
an HTTPS reverse proxy in team mode. HSTS is only added when the
request came in over TLS so local HTTP development is unaffected.

Security invariants enforced:
- SEC-03: No response carries a secret, but these headers are an
  additional defence-in-depth against clickjacking, MIME confusion,
  referrer leakage, and XSS.
- SEC-05: Response headers never overwrite user-supplied values — they
  are added only when absent.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

if TYPE_CHECKING:
    from starlette.requests import Request
    from starlette.responses import Response
    from starlette.types import ASGIApp


# Each ``(name, value, tls_only)`` tuple is applied once per response.
# ``tls_only=True`` means the header is attached only when the request
# reached the server over TLS (or when an upstream proxy signalled it
# via the ``X-Forwarded-Proto`` header).
_HEADER_SPEC: tuple[tuple[str, str, bool], ...] = (
    ("X-Content-Type-Options", "nosniff", False),
    ("X-Frame-Options", "DENY", False),
    ("X-XSS-Protection", "1; mode=block", False),
    ("Referrer-Policy", "strict-origin-when-cross-origin", False),
    (
        "Permissions-Policy",
        "accelerometer=(), camera=(), geolocation=(), gyroscope=(), "
        "magnetometer=(), microphone=(), payment=(), usb=()",
        False,
    ),
    (
        "Strict-Transport-Security",
        "max-age=63072000; includeSubDomains",
        True,
    ),
)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Attach security headers to every response."""

    def __init__(self, app: ASGIApp) -> None:
        super().__init__(app)

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        response: Response = await call_next(request)
        tls = _request_is_tls(request)
        for name, value, tls_only in _HEADER_SPEC:
            if tls_only and not tls:
                continue
            if name not in response.headers:
                response.headers[name] = value
        # Deterministically strip the default server banner; uvicorn's
        # ``server_header=False`` already drops this but some deployments
        # sit behind proxies that re-inject it.
        if "server" in response.headers:
            del response.headers["server"]
        return response


def _request_is_tls(request: Request) -> bool:
    """Return True when the caller reached the app over HTTPS.

    Covers both the direct-TLS case (``request.url.scheme``) and the
    reverse-proxy case (``X-Forwarded-Proto: https``) without trusting
    arbitrary headers — the proxy is expected to set the forwarded
    header before the request hits this middleware.
    """
    if request.url.scheme == "https":
        return True
    proto = request.headers.get("x-forwarded-proto", "").lower()
    return proto == "https"
