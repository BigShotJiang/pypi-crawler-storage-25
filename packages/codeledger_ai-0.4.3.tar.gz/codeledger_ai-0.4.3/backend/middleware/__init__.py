"""Custom ASGI middleware used by the CodeLedger FastAPI app."""
