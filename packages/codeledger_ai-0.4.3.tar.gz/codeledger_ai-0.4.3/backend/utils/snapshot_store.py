"""File content snapshotting for the non-git change detection backend.

Captures before/after snapshots of source files so the file-watcher backend
can produce a unified diff compatible with :class:`ASTTracker.parse_diff`.
Snapshots are content-addressed (SHA-256) so repeated saves that do not
actually change the file are deduplicated.

Security invariants enforced:
- SEC-01: Only file paths, content, and one-way content hashes are written
  to the ``file_snapshots`` table. No credential material is introduced.
- SEC-02: Read errors from disk are logged through the sanitizer to avoid
  leaking unexpected payloads (hash-like strings) in raw form.
- Inputs are validated before hitting the database — empty project IDs
  or non-string file paths raise ``SnapshotStoreError``.
"""

from __future__ import annotations

import difflib
import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from backend.models import FileSnapshot

if TYPE_CHECKING:
    import uuid

    from backend.db.db_backend import DatabaseBackend


_TABLE = "file_snapshots"


class SnapshotStoreError(Exception):
    """Raised for invalid input or persistence failures in the snapshot store."""


@dataclass(frozen=True)
class _SnapshotInputs:
    """Validated inputs for a snapshot operation."""

    file_path: str
    project_id: str


def _validate(file_path: str, project_id: str) -> _SnapshotInputs:
    """Normalize and validate snapshot inputs."""
    if not isinstance(file_path, str) or not file_path:
        raise SnapshotStoreError("file_path must be a non-empty string")
    if not isinstance(project_id, str) or not project_id:
        raise SnapshotStoreError("project_id must be a non-empty string")
    return _SnapshotInputs(file_path=file_path, project_id=project_id)


def _content_hash(content: str) -> str:
    """Return the SHA-256 hex digest of UTF-8 encoded content."""
    return hashlib.sha256(content.encode("utf-8", errors="replace")).hexdigest()


def _validate_path(file_path: str, project_root: Path) -> Path:
    """Reject resolved paths that escape ``project_root`` (path traversal)."""
    try:
        resolved = Path(file_path).expanduser().resolve()
        root_resolved = Path(project_root).expanduser().resolve()
    except OSError as exc:
        raise ValueError(f"Cannot resolve {file_path!r}: {exc}") from exc
    try:
        resolved.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(
            f"Path traversal attempt: {resolved} is outside {root_resolved}"
        ) from exc
    return resolved


class SnapshotStore:
    """Persist and diff file content snapshots for watchdog-based change detection.

    Parameters:
        db: A connected :class:`DatabaseBackend` used for all persistence.
        project_root: Optional root directory. When supplied, every
            file read is validated against it — :meth:`take_snapshot`
            raises :class:`ValueError` on any path that resolves
            outside the root (SEC: path-traversal defence).
    """

    def __init__(
        self, db: DatabaseBackend, project_root: Path | None = None
    ) -> None:
        self._db = db
        self._project_root = project_root

    async def take_snapshot(
        self,
        file_path: str,
        project_id: str,
        session_id: uuid.UUID | None = None,
    ) -> FileSnapshot:
        """Read ``file_path`` and persist a new snapshot if content changed.

        If the on-disk content matches the hash of the most recent stored
        snapshot for ``(project_id, file_path)``, the existing snapshot is
        returned unchanged — no duplicate row is inserted.

        Raises:
            FileNotFoundError: ``file_path`` does not exist on disk.
            PermissionError: The file exists but cannot be read.
            SnapshotStoreError: Invalid input or database persistence failed.
            ValueError: The path escapes the configured project root.
        """
        inputs = _validate(file_path, project_id)
        if self._project_root is not None:
            _validate_path(inputs.file_path, self._project_root)
        path = Path(inputs.file_path)
        if not path.exists():
            raise FileNotFoundError(f"Snapshot target does not exist: {path}")
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except PermissionError:
            raise
        except OSError as exc:
            raise SnapshotStoreError(
                f"Unable to read {path}: {exc}"
            ) from exc

        new_hash = _content_hash(content)
        previous = await self.get_last_snapshot(
            inputs.file_path, inputs.project_id
        )
        if previous is not None and previous.content_hash == new_hash:
            return previous

        snapshot = FileSnapshot(
            project_id=inputs.project_id,
            file_path=inputs.file_path,
            content_hash=new_hash,
            content=content,
            session_id=session_id,
        )
        try:
            await self._db.insert(_TABLE, snapshot.to_dict())
        except Exception as exc:
            raise SnapshotStoreError(
                f"Failed to persist snapshot for {inputs.file_path}: {exc}"
            ) from exc
        return snapshot

    async def get_last_snapshot(
        self, file_path: str, project_id: str
    ) -> FileSnapshot | None:
        """Return the most recent snapshot for ``(project_id, file_path)``.

        Returns ``None`` if no snapshot has ever been taken for this pair.
        """
        inputs = _validate(file_path, project_id)
        try:
            rows = await self._db.query(
                _TABLE,
                where={
                    "project_id": inputs.project_id,
                    "file_path": inputs.file_path,
                },
                order_by="snapshot_at DESC",
                limit=1,
            )
        except Exception as exc:
            raise SnapshotStoreError(
                f"Failed to query snapshots for {inputs.file_path}: {exc}"
            ) from exc
        if not rows:
            return None
        return FileSnapshot.from_dict(rows[0])

    async def diff_snapshots(
        self, before_snapshot_id: str, after_snapshot_id: str
    ) -> str:
        """Produce a unified diff between two stored snapshots.

        The output format matches what :meth:`ASTTracker.parse_diff` expects,
        so it can be passed straight through to the change-event pipeline.

        Returns:
            Unified diff string. Empty string when the two snapshots have
            identical content.

        Raises:
            SnapshotStoreError: Either snapshot ID is missing or invalid.
        """
        if not isinstance(before_snapshot_id, str) or not before_snapshot_id:
            raise SnapshotStoreError(
                "before_snapshot_id must be a non-empty string"
            )
        if not isinstance(after_snapshot_id, str) or not after_snapshot_id:
            raise SnapshotStoreError(
                "after_snapshot_id must be a non-empty string"
            )
        before = await self._fetch_snapshot(before_snapshot_id)
        after = await self._fetch_snapshot(after_snapshot_id)

        if before.content == after.content:
            return ""

        diff_lines = difflib.unified_diff(
            before.content.splitlines(keepends=True),
            after.content.splitlines(keepends=True),
            fromfile=f"a/{before.file_path}",
            tofile=f"b/{after.file_path}",
            n=3,
        )
        return "".join(diff_lines)

    async def delete_old_snapshots(
        self,
        file_path: str,
        project_id: str,
        keep_last_n: int = 10,
    ) -> int:
        """Delete all but the most recent ``keep_last_n`` snapshots.

        Returns:
            The number of snapshot rows deleted.

        Raises:
            SnapshotStoreError: ``keep_last_n`` is negative or inputs are
                invalid.
        """
        inputs = _validate(file_path, project_id)
        if not isinstance(keep_last_n, int) or keep_last_n < 0:
            raise SnapshotStoreError(
                "keep_last_n must be a non-negative integer"
            )
        try:
            rows = await self._db.query(
                _TABLE,
                where={
                    "project_id": inputs.project_id,
                    "file_path": inputs.file_path,
                },
                order_by="snapshot_at DESC",
            )
        except Exception as exc:
            raise SnapshotStoreError(
                f"Failed to list snapshots for {inputs.file_path}: {exc}"
            ) from exc

        to_delete = rows[keep_last_n:]
        for row in to_delete:
            row_id = row.get("id")
            if not isinstance(row_id, str):
                continue
            try:
                await self._db.delete(_TABLE, row_id)
            except Exception as exc:
                raise SnapshotStoreError(
                    f"Failed to prune snapshot {row_id}: {exc}"
                ) from exc
        return len(to_delete)

    async def _fetch_snapshot(self, snapshot_id: str) -> FileSnapshot:
        """Load a snapshot by id or raise :class:`SnapshotStoreError`."""
        try:
            row = await self._db.get_by_id(_TABLE, snapshot_id)
        except Exception as exc:
            raise SnapshotStoreError(
                f"Failed to load snapshot {snapshot_id}: {exc}"
            ) from exc
        if row is None:
            raise SnapshotStoreError(f"Snapshot not found: {snapshot_id}")
        return FileSnapshot.from_dict(row)
