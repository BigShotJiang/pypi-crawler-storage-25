"""Generator for the per-project ``CLAUDE.md`` written during ``codeledger init``.

The file instructs Claude Code (and other MCP clients) how to collaborate
with CodeLedger inside a user's project: when to start and end sessions,
when to record decisions, how to pull context, and what actions are
prohibited. Re-running ``codeledger init`` is safe: the user-authored
portion below the ``## Project-Specific Instructions`` delimiter is
preserved, while the CodeLedger-managed header is refreshed.

Security invariants enforced:
- SEC-02: Template strings never embed secrets — only project metadata
  provided by the caller.
- SEC-09: File is written with 0o644 permissions; it is expected to be
  human-readable (and typically checked into source control).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Final

if TYPE_CHECKING:
    from pathlib import Path

_DELIMITER: Final[str] = "## Project-Specific Instructions"

_VALID_BACKENDS: Final[frozenset[str]] = frozenset({"git", "file_watcher"})


def _backend_description(change_detection_backend: str) -> str:
    """Return the human-facing sentence describing the active backend."""
    if change_detection_backend == "git":
        return (
            "Change detection backend: **git**. Structural changes are anchored "
            "to commit hashes; CI verification, provenance traces, and rollback "
            "plans are fully available."
        )
    return (
        "Change detection backend: **file watcher**. Structural changes are "
        "anchored to file snapshots rather than commit hashes. CI-linked "
        "verification is unavailable in this mode — run `git init && "
        "codeledger init --reinstall-hooks` to upgrade."
    )


def generate_project_claude_md(
    project_name: str,
    server_url: str,
    change_detection_backend: str,
) -> str:
    """Render the full CodeLedger CLAUDE.md template.

    Args:
        project_name: Human-readable name of the user's project. Used only
            in the header; empty strings are tolerated.
        server_url: The base URL for the running CodeLedger server, e.g.
            ``http://localhost:8100``. Included verbatim in MCP examples.
        change_detection_backend: One of ``"git"`` or ``"file_watcher"``.

    Returns:
        The rendered CLAUDE.md body (does not include the delimiter or
        user content section — callers assemble those separately when
        creating or updating the file).

    Raises:
        ValueError: ``change_detection_backend`` is not a supported value.
    """
    if change_detection_backend not in _VALID_BACKENDS:
        raise ValueError(
            f"Invalid change_detection_backend: {change_detection_backend!r}. "
            f"Expected one of: {sorted(_VALID_BACKENDS)}"
        )
    display_name = project_name or "this project"
    backend_blurb = _backend_description(change_detection_backend)

    return f"""# CLAUDE.md — {display_name}

<!-- This section is managed by CodeLedger. Do not edit above the delimiter -->

## CodeLedger is active

CodeLedger is connected at `{server_url}`. All CodeLedger MCP tools are
available and **must** be used throughout every session on this project.
{backend_blurb}

CodeLedger injects context automatically at session start and before
file edits. You do not need to call `session.start`,
`context.get_relevant`, or `session.end` manually — these are handled
by hooks. You still need to call `decision.create` before architectural
changes. The hooks handle context retrieval; you handle decision
recording.

## Client-specific behaviour

CodeLedger adapts its lifecycle to the MCP client you are running in,
detected from the `agent_name` parameter on your first tool call.

### Claude Code

Hooks handle session lifecycle automatically. You do not need to call
`session.start` or `session.end` manually. A `UserPromptSubmit` hook
injects context before every prompt, a `PreToolUse` hook runs conflict
and drift checks before every file edit, and a `Stop` hook closes the
session with passive inference.

### Cursor, Windsurf, and all other clients

These clients do not support client-side hooks, so CodeLedger maintains
session lifecycle on the server. Your first tool call with `cwd`,
`agent_name`, and `project_id` automatically starts a session and
injects a relevant context block under the `session_context` field of
the response. Before editing any file, call `context.before_edit` with
the file path and current content. This single tool returns relevant
decisions, active conflicts on the file, and any import constraints
that apply. You do not need to call `session.start` — it fires on your
first tool call. The session closes automatically after 30 minutes of
inactivity (configurable in `codeledger.toml` under `[session]
inactivity_timeout_minutes`).

## Session lifecycle

Call `session.start` at the beginning of every coding session, with
`agent_name` and any initial files you plan to touch.

Call `session.end` when the work is complete. If `session.end` returns
`status: "completed_with_warnings"` with an `unlinked_files` list, you
have two options:

1. Call `decision.create` for each unlinked file, then call `session.end`
   again.
2. Call `session.end` with `force: true` and an `override_reason`
   explaining why no decision is needed (e.g. "formatting-only change").

If `session.end` returns `inferred_decisions` in the response, review
each candidate. Call `decision.confirm_inferred` for changes that
warrant a decision record. Call `decision.reject_inferred` for cosmetic
or trivial changes. You do not need to write decisions from scratch —
confirm or reject the inferred candidates.

To enable fully passive memory capture with zero interaction, call
`session.end` with `auto_confirm_threshold: 0.75`. Decisions above this
confidence will be recorded automatically. Set the threshold lower
(`0.5`) for more aggressive capture or higher (`0.9`) for more
conservative. Confirmed decisions will have
`inference_status: "confirmed"` and can be reviewed and enriched later
with `decision.update`. The threshold can also be set project-wide in
`codeledger.toml` under `[session] auto_confirm_threshold = 0.75`.

**Never exit a session without calling `session.end`.**

## Decision recording

Call `decision.create` *before* writing any new function, class, module,
or architectural change — record *during* the work, not after.

Every decision must include:

- `title` — imperative, under 72 characters.
- `description` — the *why*, not the *what*.
- `tags` — short labels (e.g. `["auth", "security"]`).
- `files_affected` — the files that will change as a result.

When starting work on a module you have not touched recently, call
`decision.staleness_report` to identify decisions that may be outdated.
Call `decision.supersede` when you make a decision that explicitly
replaces a prior one. Call `decision.confirm_fresh` after reviewing a
flagged decision that is still accurate.

Call `decision.list_conflicts` at session start to identify decisions
in the project that contradict each other. Call
`decision.resolve_conflict` to mark which decision takes precedence.
The context block will warn you when contradicting decisions are both
retrieved.

Example call (MCP):

```json
{{
  "tool": "decision",
  "arguments": {{
    "method": "create",
    "title": "Switch session cookie to SameSite=strict",
    "description": "Mitigate CSRF on the dashboard login flow.",
    "tags": ["auth", "security"],
    "files_affected": ["backend/auth/auth_middleware.py"]
  }}
}}
```

Server: `{server_url}`

## Context retrieval

Call `context.get_relevant` at the start of every session. Call
`context.get_for_file` before editing a specific file. Always review
the injected context block before making changes — the token budget
triage may have summarized or excluded content that is still relevant.

## Explicit prohibitions

- Do not add new imports without calling `decision.reverse_trace` on
  the target file first.
- Do not skip `session.end`.
- Do not record decisions in bulk retroactively.
- Do not record trivial decisions to satisfy tooling — use
  `session.end` with `force: true` and an `override_reason` instead.

<!-- End of CodeLedger-managed section -->
"""


def _has_delimiter(existing: str) -> bool:
    """Return True when ``existing`` already has the user-content delimiter."""
    return _DELIMITER in existing


def _split_on_delimiter(existing: str) -> tuple[str, str]:
    """Return ``(before, from_delimiter)`` split at the first delimiter line."""
    idx = existing.find(_DELIMITER)
    return existing[:idx], existing[idx:]


def write_project_claude_md(
    project_root: Path,
    project_name: str,
    server_url: str,
    change_detection_backend: str,
) -> Path:
    """Write or refresh ``project_root/CLAUDE.md`` safely.

    Behavior:

    * No existing file → create it. Content is the rendered template,
      followed by a ``## Project-Specific Instructions`` delimiter with
      an empty placeholder beneath.
    * Existing file with the delimiter present → replace everything
      above the delimiter with the freshly rendered template. User
      content at and below the delimiter is preserved verbatim.
    * Existing file without the delimiter → prepend the template, insert
      the delimiter, and place the existing content below as the user
      section. No content is lost.

    Args:
        project_root: Directory to receive the CLAUDE.md file.
        project_name: Human-readable project name.
        server_url: Running CodeLedger server base URL.
        change_detection_backend: ``"git"`` or ``"file_watcher"``.

    Returns:
        The resolved path of the written file.

    Raises:
        ValueError: ``change_detection_backend`` is invalid.
        OSError: ``project_root`` is not writable.
    """
    if not project_root.exists():
        raise OSError(f"Project root does not exist: {project_root}")
    if not project_root.is_dir():
        raise OSError(f"Project root is not a directory: {project_root}")

    rendered = generate_project_claude_md(
        project_name=project_name,
        server_url=server_url,
        change_detection_backend=change_detection_backend,
    )

    target = project_root / "CLAUDE.md"
    user_section_default = (
        f"\n{_DELIMITER}\n\n"
        "<!-- Add project-specific instructions for Claude below this line. "
        "This section is preserved across codeledger init runs. -->\n"
    )

    if not target.exists():
        final_text = rendered + user_section_default
    else:
        try:
            existing = target.read_text(encoding="utf-8")
        except OSError as exc:
            raise OSError(f"Cannot read {target}: {exc}") from exc

        if _has_delimiter(existing):
            _, from_delimiter = _split_on_delimiter(existing)
            # ``from_delimiter`` starts with ``## Project-Specific Instructions``
            # — preserve it verbatim.
            final_text = rendered + "\n" + from_delimiter
            if not final_text.endswith("\n"):
                final_text += "\n"
        else:
            # Preserve the existing body underneath a freshly inserted delimiter.
            preserved = existing.rstrip("\n") + "\n"
            final_text = (
                rendered
                + f"\n{_DELIMITER}\n\n"
                + preserved
            )

    try:
        target.write_text(final_text, encoding="utf-8")
    except OSError as exc:
        raise OSError(f"Cannot write {target}: {exc}") from exc
    return target
