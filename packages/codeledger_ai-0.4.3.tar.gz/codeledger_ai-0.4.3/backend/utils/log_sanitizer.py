"""Log sanitizer with credential pattern redaction.

Wraps Python's logging module to automatically redact any string matching known
credential patterns before it reaches log output. All log statements throughout
CodeLedger pass through this sanitizing formatter.

Security invariants enforced:
- SEC-02: No credentials in logs. Every log record is scrubbed for Bearer tokens,
  API keys, JWTs, OAuth tokens, passwords, and generic secret patterns.
"""

from __future__ import annotations

import logging
import re

_REDACTED = "[REDACTED]"

# Patterns ordered from most specific to least specific to avoid partial matches.
_CREDENTIAL_PATTERNS: list[re.Pattern[str]] = [
    # JWTs: three base64url segments separated by dots (header.payload.signature)
    re.compile(r"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+"),
    # Bearer tokens in Authorization headers
    re.compile(r"Bearer\s+[A-Za-z0-9_\-.~+/]+=*", re.IGNORECASE),
    # GitHub tokens (PATs, OAuth, app tokens)
    re.compile(r"gh[pous]_[A-Za-z0-9_]{16,}"),
    # Slack tokens
    re.compile(r"xox[bpas]-[A-Za-z0-9\-]+"),
    # OpenAI / Anthropic style API keys
    re.compile(r"sk[-_][A-Za-z0-9_\-]{20,}"),
    # Generic key=value secret patterns (token=, key=, secret=, password=, passwd=)
    re.compile(
        r"(?:token|key|secret|password|passwd|api_key|apikey|access_token|refresh_token)"
        r"\s*[=:]\s*[\"']?[^\s\"',;]{8,}[\"']?",
        re.IGNORECASE,
    ),
]


def redact(message: str) -> str:
    """Replace all credential patterns in a string with [REDACTED]."""
    result = message
    for pattern in _CREDENTIAL_PATTERNS:
        result = pattern.sub(_REDACTED, result)
    return result


class SanitizingFormatter(logging.Formatter):
    """Logging formatter that redacts credential patterns from all output."""

    def format(self, record: logging.LogRecord) -> str:
        original = super().format(record)
        return redact(original)


def setup_logging(level: str = "INFO") -> None:
    """Configure the root logger with the sanitizing formatter.

    Removes existing handlers and installs a single StreamHandler with
    SanitizingFormatter. Safe to call multiple times.

    Args:
        level: Log level string (DEBUG, INFO, WARNING, ERROR).
    """
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))

    # Remove existing handlers to avoid duplicate output on repeated calls
    for handler in root.handlers[:]:
        root.removeHandler(handler)

    handler = logging.StreamHandler()
    handler.setFormatter(
        SanitizingFormatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    )
    root.addHandler(handler)
