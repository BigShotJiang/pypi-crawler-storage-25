"""Configuration loader for CodeLedger.

Loads and validates codeledger.toml, providing typed frozen dataclasses for all
configuration sections. Resolves the config file path from an explicit argument,
the CODELEDGER_CONFIG environment variable, or the default ./codeledger.toml.

Security invariants enforced:
- SEC-09: Config file must not be world-readable on POSIX systems.
- Path traversal prevention: relative paths in config cannot escape the project root.
- Secrets by reference: credential fields store environment variable names, not values.
"""

from __future__ import annotations

import dataclasses
import os
import stat
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any  # tomllib.load returns dict[str, Any]; unavoidable per stdlib typing


class ConfigError(Exception):
    """Raised for configuration validation failures."""


_VALID_MODES = frozenset({"solo", "team"})
_VALID_LOG_LEVELS = frozenset({"debug", "info", "warning", "error"})
_VALID_DB_BACKENDS = frozenset({"sqlite", "postgresql"})
_VALID_VAULT_BACKENDS = frozenset({"keyring", "file", "env"})
_VALID_CHANGE_DETECTION_BACKENDS = frozenset({"git", "file_watcher"})
_VALID_EMBEDDING_BACKENDS = frozenset({"ollama", "local"})


_DEFAULT_WATCH_EXTENSIONS: tuple[str, ...] = (
    ".py",
    ".ts",
    ".tsx",
    ".js",
    ".go",
    ".rs",
    ".java",
    ".c",
    ".cpp",
    ".rb",
    ".cs",
)


_DEFAULT_IGNORE_PATTERNS: tuple[str, ...] = (
    ".git",
    "node_modules",
    "dist",
    "__pycache__",
    "data",
)


@dataclass(frozen=True)
class ServerConfig:
    """Server operating mode, network binding, and log level."""

    mode: str = "solo"
    host: str = "127.0.0.1"
    port: int = 8100
    log_level: str = "info"


@dataclass(frozen=True)
class DatabaseConfig:
    """Database backend type, SQLite path, and PostgreSQL DSN env var reference."""

    backend: str = "sqlite"
    sqlite_path: str = "data/codeledger.db"
    pg_dsn_env: str = "CODELEDGER_PG_DSN"


@dataclass(frozen=True)
class CredentialConfig:
    """Credential vault backend type and encrypted file path."""

    backend: str = "keyring"
    vault_path: str = "~/.codeledger/vault.enc"


@dataclass(frozen=True)
class EmbeddingConfig:
    """Embedding backend selection, Ollama settings, and vector dimension.

    ``backend`` selects the embedding implementation:

    * ``"ollama"`` — Ollama server at ``ollama_url`` with ``model`` pulled.
      Produces 768-dim vectors for ``nomic-embed-text``.
    * ``"local"`` — in-process ``sentence-transformers`` with
      ``all-MiniLM-L6-v2``. No separate server; ships as a Python wheel.
      Produces 384-dim vectors.

    ``vector_dim`` is the vector-store column width. Defaults to 768 for
    Ollama and 384 for local; callers that override the backend should
    override this too, but ``get_embedder`` sets a sensible default at
    runtime when the value doesn't match the selected backend.
    """

    backend: str = "ollama"
    ollama_url: str = "http://localhost:11434"
    model: str = "nomic-embed-text"
    local_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    batch_size: int = 32
    vector_dim: int = 768


@dataclass(frozen=True)
class OAuthProviderConfig:
    """OAuth provider credential env var references (names only, never values)."""

    client_id_env: str = ""
    client_secret_env: str = ""


@dataclass(frozen=True)
class AuthConfig:
    """JWT, cookie, Argon2id, and OAuth provider settings."""

    jwt_expiry_hours: int = 24
    cookie_secure: bool = True
    cookie_samesite: str = "strict"
    argon2_memory_cost_kb: int = 65536
    argon2_time_cost: int = 3
    argon2_parallelism: int = 4
    google: OAuthProviderConfig = field(default_factory=OAuthProviderConfig)
    github: OAuthProviderConfig = field(default_factory=OAuthProviderConfig)


@dataclass(frozen=True)
class ContextConfig:
    """Token budget settings for context retrieval."""

    default_token_budget: int = 8000
    max_token_budget: int = 32000


@dataclass(frozen=True)
class GitConfig:
    """Git integration settings."""

    install_hooks: bool = True


@dataclass(frozen=True)
class SessionConfig:
    """Session lifecycle settings, including passive-inference auto-confirm.

    ``auto_confirm_threshold`` — when set to a float in ``[0.0, 1.0]``,
    ``session.end`` will promote every inferred candidate at or above
    this confidence to a full :class:`Decision` without asking the agent
    to confirm. ``None`` preserves the manual-review queue behaviour.

    ``inactivity_timeout_minutes`` — sessions idle for longer than this
    are auto-closed by the background task in ``main.py``. Set to ``0``
    to disable inactivity-based closure.
    """

    auto_confirm_threshold: float | None = None
    inactivity_timeout_minutes: int = 30


@dataclass(frozen=True)
class ChangeDetectionConfig:
    """Change detection backend selection and file-watcher tuning.

    ``backend`` is set automatically by ``codeledger init`` to ``"git"`` when
    a ``.git/`` directory is present and ``"file_watcher"`` otherwise.
    """

    backend: str = "git"
    watch_extensions: tuple[str, ...] = _DEFAULT_WATCH_EXTENSIONS
    debounce_ms: int = 100
    ignore_patterns: tuple[str, ...] = _DEFAULT_IGNORE_PATTERNS


@dataclass(frozen=True)
class ProvidersConfig:
    """Provider registry file location."""

    registry_path: str = "providers.toml"


@dataclass(frozen=True)
class CodeLedgerConfig:
    """Top-level configuration aggregating all sections."""

    server: ServerConfig = field(default_factory=ServerConfig)
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    vault: CredentialConfig = field(default_factory=CredentialConfig)
    embeddings: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    auth: AuthConfig = field(default_factory=AuthConfig)
    context: ContextConfig = field(default_factory=ContextConfig)
    git: GitConfig = field(default_factory=GitConfig)
    providers: ProvidersConfig = field(default_factory=ProvidersConfig)
    change_detection: ChangeDetectionConfig = field(
        default_factory=ChangeDetectionConfig
    )
    session: SessionConfig = field(default_factory=SessionConfig)
    project_root: Path = field(default_factory=Path.cwd)

    def resolve_path(self, path_str: str) -> Path:
        """Resolve a config path string to an absolute ``Path``.

        Expands ``~``; absolute paths are returned as-is; relative paths
        are anchored to ``project_root`` rather than the process CWD.
        This prevents deployments from silently breaking (missing
        providers.toml, missing vault) when the server is launched from
        a directory other than the project root.
        """
        expanded = Path(os.path.expanduser(path_str))
        if expanded.is_absolute():
            return expanded
        return self.project_root / expanded


def _validate_permissions(config_path: Path) -> None:
    """Branch by platform to verify ``config_path`` is not world-readable.

    POSIX: check ``stat`` mode bits. Windows: query the DACL via
    ``pywin32`` and reject when the ``Everyone`` SID has a read ACE.
    Either branch degrades to a warning rather than a crash when the
    platform API is unavailable (tested without ``pywin32`` installed).
    """
    import platform

    system = platform.system()
    if system == "Windows":
        _check_windows_permissions(config_path)
        return
    _check_posix_permissions(config_path)


def _check_posix_permissions(config_path: Path) -> None:
    try:
        mode = config_path.stat().st_mode
    except OSError as exc:
        raise ConfigError(f"Cannot stat config file {config_path}: {exc}") from exc
    if mode & stat.S_IROTH:
        raise ConfigError(
            f"Config file {config_path} is world-readable (mode {oct(mode)}). "
            f"Run: chmod 600 {config_path}"
        )


def _check_windows_permissions(config_path: Path) -> None:
    """Reject config files with an Everyone-readable DACL on Windows."""
    import logging

    logger = logging.getLogger(__name__)
    try:
        import ntsecuritycon  # type: ignore[import-not-found]
        import win32security  # type: ignore[import-not-found]
    except ImportError:
        logger.warning(
            "pywin32 is not installed; skipping Windows ACL check on %s. "
            "Install with: pip install 'codeledger[windows]'",
            config_path,
        )
        return
    try:
        sd = win32security.GetFileSecurity(
            str(config_path), win32security.DACL_SECURITY_INFORMATION
        )
        dacl = sd.GetSecurityDescriptorDacl()
        if dacl is None:
            return
        everyone_sid, _, _ = win32security.LookupAccountName("", "Everyone")
        for i in range(dacl.GetAceCount()):
            ace = dacl.GetAce(i)
            ace_sid = ace[2]
            mask = ace[1] if isinstance(ace[1], int) else 0
            if ace_sid == everyone_sid and mask & ntsecuritycon.FILE_GENERIC_READ:
                raise ConfigError(
                    f"Config file {config_path} is readable by Everyone. "
                    f"Restrict ACL with: icacls {config_path} /inheritance:r "
                    f"/grant:r \"%USERNAME%:F\""
                )
    except ConfigError:
        raise
    except Exception as exc:
        logger.warning(
            "Windows DACL check on %s failed: %s", config_path, exc
        )


def _validate_path(path_str: str, project_root: Path, field_name: str) -> None:
    """Reject relative paths that escape the project root via directory traversal."""
    expanded = Path(os.path.expanduser(path_str))
    if expanded.is_absolute():
        return
    resolved = (project_root / expanded).resolve()
    root_resolved = project_root.resolve()
    if not resolved.is_relative_to(root_resolved):
        raise ConfigError(
            f"Path traversal in {field_name}: '{path_str}' resolves to "
            f"{resolved}, outside project root {root_resolved}"
        )


def _section(raw: dict[str, Any], key: str) -> dict[str, Any]:
    """Extract a TOML table section, raising ConfigError for non-table values."""
    value = raw.get(key, {})
    if not isinstance(value, dict):
        raise ConfigError(
            f"Config section [{key}] must be a TOML table, got {type(value).__name__}"
        )
    return value


def _pick(data: dict[str, Any], cls: type) -> dict[str, Any]:
    """Filter dict to keys matching fields of the given dataclass class."""
    valid = {f.name for f in dataclasses.fields(cls)}
    return {k: v for k, v in data.items() if k in valid}


def _validate_enum(value: object, valid: frozenset[str], field_name: str) -> None:
    """Raise ConfigError if value is not a string in the valid set."""
    if not isinstance(value, str):
        raise ConfigError(f"{field_name} must be a string, got {type(value).__name__}")
    if value not in valid:
        raise ConfigError(
            f"Invalid {field_name}: '{value}'. Must be one of: {sorted(valid)}"
        )


def _validate_port(port: object) -> None:
    """Raise ConfigError if port is not an integer in range 1-65535."""
    if not isinstance(port, int) or isinstance(port, bool):
        raise ConfigError(f"server.port must be an integer, got {type(port).__name__}")
    if not 1 <= port <= 65535:
        raise ConfigError(f"Invalid server.port: {port}. Must be between 1 and 65535")


def load_config(
    config_path: str | Path | None = None,
    project_root: Path | None = None,
) -> CodeLedgerConfig:
    """Load, validate, and return CodeLedger configuration.

    Resolution order for config_path: explicit argument, then CODELEDGER_CONFIG
    env var, then ./codeledger.toml in the current directory.

    Args:
        config_path: Explicit path to codeledger.toml.
        project_root: Project root for path traversal validation. Defaults to the
            config file's parent directory.

    Returns:
        Frozen CodeLedgerConfig with all settings validated.

    Raises:
        FileNotFoundError: Config file does not exist.
        ConfigError: Validation failed (permissions, path traversal, invalid values,
            malformed TOML, or unexpected section types).
    """
    if config_path is None:
        config_path = os.environ.get("CODELEDGER_CONFIG", "codeledger.toml")
    path = Path(config_path).resolve()

    if not path.is_file():
        raise FileNotFoundError(f"Config file not found: {path}")

    if project_root is None:
        project_root = path.parent

    _validate_permissions(path)

    try:
        with open(path, "rb") as f:
            raw = tomllib.load(f)
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"Malformed TOML in {path}: {exc}") from exc
    except PermissionError as exc:
        raise ConfigError(f"Cannot read config file {path}: {exc}") from exc

    # Build section configs, ignoring unrecognized keys for forward compatibility
    server = ServerConfig(**_pick(_section(raw, "server"), ServerConfig))
    database = DatabaseConfig(**_pick(_section(raw, "database"), DatabaseConfig))
    vault = CredentialConfig(**_pick(_section(raw, "vault"), CredentialConfig))
    embeddings = EmbeddingConfig(**_pick(_section(raw, "embeddings"), EmbeddingConfig))
    context = ContextConfig(**_pick(_section(raw, "context"), ContextConfig))
    git = GitConfig(**_pick(_section(raw, "git"), GitConfig))
    session_cfg = SessionConfig(
        **_pick(_section(raw, "session"), SessionConfig)
    )
    providers = ProvidersConfig(**_pick(_section(raw, "providers"), ProvidersConfig))
    change_detection_raw = _pick(
        _section(raw, "change_detection"), ChangeDetectionConfig
    )
    # TOML arrays come through as lists; normalize to tuples to match the
    # frozen-dataclass field type.
    for key in ("watch_extensions", "ignore_patterns"):
        if key in change_detection_raw and isinstance(
            change_detection_raw[key], list
        ):
            change_detection_raw[key] = tuple(change_detection_raw[key])
    change_detection = ChangeDetectionConfig(**change_detection_raw)

    # Auth has nested sub-tables for OAuth providers
    auth_raw = _section(raw, "auth")
    google = OAuthProviderConfig(**_pick(_section(auth_raw, "google"), OAuthProviderConfig))
    github = OAuthProviderConfig(**_pick(_section(auth_raw, "github"), OAuthProviderConfig))
    auth_fields = {
        k: v for k, v in _pick(auth_raw, AuthConfig).items() if k not in ("google", "github")
    }
    auth = AuthConfig(**auth_fields, google=google, github=github)

    # Validate constrained fields
    _validate_enum(server.mode, _VALID_MODES, "server.mode")
    _validate_enum(server.log_level, _VALID_LOG_LEVELS, "server.log_level")
    _validate_enum(database.backend, _VALID_DB_BACKENDS, "database.backend")
    _validate_enum(vault.backend, _VALID_VAULT_BACKENDS, "vault.backend")
    _validate_enum(
        change_detection.backend,
        _VALID_CHANGE_DETECTION_BACKENDS,
        "change_detection.backend",
    )
    _validate_enum(
        embeddings.backend,
        _VALID_EMBEDDING_BACKENDS,
        "embeddings.backend",
    )
    if (
        not isinstance(change_detection.debounce_ms, int)
        or isinstance(change_detection.debounce_ms, bool)
        or change_detection.debounce_ms < 0
    ):
        raise ConfigError(
            "change_detection.debounce_ms must be a non-negative integer"
        )
    _validate_port(server.port)

    # Validate paths against project root (relative paths must not escape)
    _validate_path(database.sqlite_path, project_root, "database.sqlite_path")
    _validate_path(vault.vault_path, project_root, "vault.vault_path")
    _validate_path(providers.registry_path, project_root, "providers.registry_path")

    return CodeLedgerConfig(
        server=server,
        database=database,
        vault=vault,
        embeddings=embeddings,
        auth=auth,
        context=context,
        git=git,
        providers=providers,
        change_detection=change_detection,
        session=session_cfg,
        project_root=project_root,
    )
