import functools
from typing import Any, Callable

from .client import TBV


def verified(
    allowed_verdicts: list[str],
    confidence_threshold: float = 0.8,
    task_type: str = "decide",
    touchpoint: str = "chat",
    source: str | None = None,
    base_url: str | None = None,
    timeout: float = 300.0,
) -> Callable[..., Any]:
    """Wrap a function so its output is verified by TBV before being returned.

    The wrapped function must return a dict containing at least a "prompt"
    key. Any other keys are sent as context. The decorator submits a
    verification task, waits for completion, and returns the final verdict
    string plus the tier that produced it.

    `touchpoint` and `source` route the event in the Control Tower stream.
    `source` defaults to the wrapped function's qualified name.
    """

    def decorator(fn: Callable[..., dict[str, Any]]) -> Callable[..., dict[str, Any]]:
        client = TBV(base_url=base_url)
        resolved_source = source or fn.__qualname__

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> dict[str, Any]:
            payload = fn(*args, **kwargs)
            if not isinstance(payload, dict) or "prompt" not in payload:
                raise TypeError(
                    "@verified function must return a dict containing a 'prompt' key"
                )
            prompt = payload.pop("prompt")
            task = client.verify(
                prompt=prompt,
                allowed_verdicts=allowed_verdicts,
                context=payload,
                confidence_threshold=confidence_threshold,
                touchpoint=touchpoint,
                source=resolved_source,
                timeout=timeout,
            )
            return {
                "verdict": task["final_verdict"],
                "tier": task["final_tier"],
                "task_id": task["id"],
            }

        return wrapper

    return decorator
