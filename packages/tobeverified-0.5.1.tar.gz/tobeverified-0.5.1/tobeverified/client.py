import os
import time
from typing import Any

import httpx


class TBVError(Exception):
    pass


class TBVTimeoutError(TBVError):
    pass


class TBV:
    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.base_url = (
            base_url or os.getenv("TBV_BASE_URL", "https://api.tobeverified.com")
        ).rstrip("/")
        self.api_key = api_key or os.getenv("TBV_API_KEY")
        self._http = httpx.Client(timeout=timeout)

    def _headers(self) -> dict[str, str]:
        h: dict[str, str] = {}
        if self.api_key:
            h["authorization"] = f"Bearer {self.api_key}"
        return h

    def submit(
        self,
        prompt: str,
        allowed_verdicts: list[str],
        context: dict[str, Any] | None = None,
        task_type: str = "decide",
        confidence_threshold: float = 0.8,
        touchpoint: str = "chat",
        source: str = "sdk",
    ) -> dict[str, Any]:
        resp = self._http.post(
            f"{self.base_url}/v1/tasks",
            headers=self._headers(),
            json={
                "task_type": task_type,
                "prompt": prompt,
                "context": context or {},
                "allowed_verdicts": allowed_verdicts,
                "confidence_threshold": confidence_threshold,
                "touchpoint": touchpoint,
                "source": source,
            },
        )
        if resp.status_code >= 400:
            raise TBVError(f"submit failed {resp.status_code}: {resp.text}")
        return resp.json()

    def get(self, task_id: str) -> dict[str, Any]:
        resp = self._http.get(
            f"{self.base_url}/v1/tasks/{task_id}",
            headers=self._headers(),
        )
        if resp.status_code >= 400:
            raise TBVError(f"get failed {resp.status_code}: {resp.text}")
        return resp.json()

    def wait(
        self,
        task_id: str,
        timeout: float = 300.0,
        poll_interval: float = 1.5,
    ) -> dict[str, Any]:
        deadline = time.time() + timeout
        while time.time() < deadline:
            task = self.get(task_id)
            if task["status"] == "completed":
                return task
            time.sleep(poll_interval)
        raise TBVTimeoutError(f"task {task_id} did not complete within {timeout}s")

    def verify(
        self,
        prompt: str,
        allowed_verdicts: list[str],
        context: dict[str, Any] | None = None,
        confidence_threshold: float = 0.8,
        touchpoint: str = "chat",
        source: str = "sdk",
        timeout: float = 300.0,
    ) -> dict[str, Any]:
        submitted = self.submit(
            prompt=prompt,
            allowed_verdicts=allowed_verdicts,
            context=context,
            confidence_threshold=confidence_threshold,
            touchpoint=touchpoint,
            source=source,
        )
        return self.wait(submitted["id"], timeout=timeout)
