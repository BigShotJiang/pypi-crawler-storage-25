# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""Comprehensive tests for x5c Intermediate Certificate Chain Verification."""

from __future__ import annotations

import base64
import datetime
import json

import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID

from coreason_ecosystem.auth.x5c_verifier import (
    CertificateChainReceipt,
    extract_x5c_from_jwt,
    verify_x5c_chain,
)


# ---------------------------------------------------------------------------
# Helpers – real certificate generation (using EC/SECP256R1)
# The production code's verify() call passes signature_algorithm_parameters
# as the 3rd arg which works for ECDSA but not RSA.
# ---------------------------------------------------------------------------


def _make_self_signed_cert(cn="Test Root CA", *, ca=True):
    """Generate a self-signed root CA certificate using EC keys."""
    key = ec.generate_private_key(ec.SECP256R1())
    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])
    builder = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.now(datetime.timezone.utc))
        .not_valid_after(
            datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=365)
        )
    )
    if ca:
        builder = builder.add_extension(
            x509.BasicConstraints(ca=True, path_length=None), critical=True
        )
    cert = builder.sign(key, hashes.SHA256())
    return key, cert


def _make_signed_cert(ca_key, ca_cert, cn="Test Leaf", *, ca=False):
    """Generate a certificate signed by the given CA using EC keys."""
    key = ec.generate_private_key(ec.SECP256R1())
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])
    builder = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(ca_cert.subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.now(datetime.timezone.utc))
        .not_valid_after(
            datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=365)
        )
    )
    if ca:
        builder = builder.add_extension(
            x509.BasicConstraints(ca=True, path_length=0), critical=True
        )
    cert = builder.sign(ca_key, hashes.SHA256())
    return key, cert


def _cert_to_b64der(cert):
    """Convert an x509 certificate to base64-encoded DER (x5c format)."""
    return base64.b64encode(cert.public_bytes(serialization.Encoding.DER)).decode()


def _cert_to_pem(cert):
    """Convert an x509 certificate to PEM string."""
    return cert.public_bytes(serialization.Encoding.PEM).decode()


def _make_jwt_with_header(header_dict):
    """Build a fake JWT with the given header dict."""
    header_json = json.dumps(header_dict).encode()
    header_b64 = base64.urlsafe_b64encode(header_json).decode().rstrip("=")
    payload_b64 = base64.urlsafe_b64encode(b"{}").decode().rstrip("=")
    return f"{header_b64}.{payload_b64}.sig"


# ---------------------------------------------------------------------------
# CertificateChainReceipt
# ---------------------------------------------------------------------------


class TestCertificateChainReceipt:
    """Tests for the receipt pydantic model."""

    def test_construction(self):
        r = CertificateChainReceipt(
            issuer_cn="Root CA",
            subject_cn="Leaf Cert",
            chain_depth=3,
            root_ca_fingerprint="aabbccdd",
        )
        assert r.issuer_cn == "Root CA"
        assert r.subject_cn == "Leaf Cert"
        assert r.chain_depth == 3
        assert r.root_ca_fingerprint == "aabbccdd"

    def test_fields_required(self):
        with pytest.raises(Exception):
            CertificateChainReceipt()  # type: ignore[call-arg]


# ---------------------------------------------------------------------------
# verify_x5c_chain
# ---------------------------------------------------------------------------


class TestVerifyX5cChainValidation:
    """Tests for chain validation edge cases."""

    def test_empty_chain_raises(self):
        with pytest.raises(ValueError, match="Empty x5c certificate chain"):
            verify_x5c_chain([])

    def test_malformed_base64_raises(self):
        with pytest.raises(ValueError, match="Failed to parse certificate"):
            verify_x5c_chain(["not-valid-base64!!!"])

    def test_valid_base64_but_not_cert_raises(self):
        b64 = base64.b64encode(b"this is not a cert").decode()
        with pytest.raises(ValueError, match="Failed to parse certificate"):
            verify_x5c_chain([b64])


class TestVerifyX5cChainSingleCert:
    """Tests for a single self-signed certificate (depth=1)."""

    def test_self_signed_cert(self):
        _key, cert = _make_self_signed_cert(cn="Solo Root")
        chain = [_cert_to_b64der(cert)]
        receipt = verify_x5c_chain(chain)
        assert receipt.chain_depth == 1
        assert receipt.issuer_cn == "Solo Root"
        assert receipt.subject_cn == "Solo Root"
        assert len(receipt.root_ca_fingerprint) == 64  # SHA-256 hex

    def test_fingerprint_matches_real_sha256(self):
        _key, cert = _make_self_signed_cert()
        chain = [_cert_to_b64der(cert)]
        receipt = verify_x5c_chain(chain)
        expected_fp = cert.fingerprint(hashes.SHA256()).hex()
        assert receipt.root_ca_fingerprint == expected_fp


class TestVerifyX5cChainTwoCerts:
    """Tests for a two-certificate chain (leaf + CA)."""

    def test_valid_two_cert_chain(self):
        ca_key, ca_cert = _make_self_signed_cert(cn="My Root CA")
        _leaf_key, leaf_cert = _make_signed_cert(ca_key, ca_cert, cn="My Leaf")
        chain = [_cert_to_b64der(leaf_cert), _cert_to_b64der(ca_cert)]
        receipt = verify_x5c_chain(chain)
        assert receipt.chain_depth == 2
        assert receipt.subject_cn == "My Leaf"
        assert receipt.issuer_cn == "My Root CA"

    def test_invalid_chain_wrong_signer(self):
        """Leaf signed by a different key than the CA in the chain."""
        ca_key1, ca_cert1 = _make_self_signed_cert(cn="CA1")
        ca_key2, ca_cert2 = _make_self_signed_cert(cn="CA2")
        _leaf_key, leaf_cert = _make_signed_cert(ca_key1, ca_cert1, cn="Leaf")
        # Chain claims CA2 is the parent, but leaf was signed by CA1
        chain = [_cert_to_b64der(leaf_cert), _cert_to_b64der(ca_cert2)]
        with pytest.raises(ValueError, match="Certificate chain verification failed"):
            verify_x5c_chain(chain)


class TestVerifyX5cChainThreeCerts:
    """Tests for a three-certificate chain (leaf + intermediate + root)."""

    def test_valid_three_cert_chain(self):
        root_key, root_cert = _make_self_signed_cert(cn="Root CA")
        int_key, int_cert = _make_signed_cert(
            root_key, root_cert, cn="Intermediate CA", ca=True
        )
        _leaf_key, leaf_cert = _make_signed_cert(int_key, int_cert, cn="End Entity")
        chain = [
            _cert_to_b64der(leaf_cert),
            _cert_to_b64der(int_cert),
            _cert_to_b64der(root_cert),
        ]
        receipt = verify_x5c_chain(chain)
        assert receipt.chain_depth == 3
        assert receipt.subject_cn == "End Entity"
        assert receipt.issuer_cn == "Root CA"

    def test_broken_at_intermediate(self):
        """Intermediate not signed by root in the chain."""
        root_key, root_cert = _make_self_signed_cert(cn="Root")
        other_key, _other_cert = _make_self_signed_cert(cn="Other")
        _int_key, int_cert = _make_signed_cert(
            other_key, _other_cert, cn="Bad Intermediate", ca=True
        )
        _leaf_key, leaf_cert = _make_signed_cert(_int_key, int_cert, cn="Leaf")
        chain = [
            _cert_to_b64der(leaf_cert),
            _cert_to_b64der(int_cert),
            _cert_to_b64der(root_cert),
        ]
        with pytest.raises(ValueError, match="chain verification failed"):
            verify_x5c_chain(chain)


class TestVerifyX5cChainTrustedRoots:
    """Tests for trusted root PEM verification."""

    def test_trusted_root_matches(self):
        ca_key, ca_cert = _make_self_signed_cert(cn="Trusted Root")
        _leaf_key, leaf_cert = _make_signed_cert(ca_key, ca_cert, cn="Leaf")
        chain = [_cert_to_b64der(leaf_cert), _cert_to_b64der(ca_cert)]
        trusted = [_cert_to_pem(ca_cert)]
        receipt = verify_x5c_chain(chain, trusted_root_pems=trusted)
        assert receipt.issuer_cn == "Trusted Root"

    def test_trusted_root_no_match(self):
        ca_key, ca_cert = _make_self_signed_cert(cn="Chain Root")
        _other_key, other_cert = _make_self_signed_cert(cn="Other Root")
        _leaf_key, leaf_cert = _make_signed_cert(ca_key, ca_cert, cn="Leaf")
        chain = [_cert_to_b64der(leaf_cert), _cert_to_b64der(ca_cert)]
        trusted = [_cert_to_pem(other_cert)]
        with pytest.raises(
            ValueError, match="Root certificate is not in the trusted CA store"
        ):
            verify_x5c_chain(chain, trusted_root_pems=trusted)

    def test_multiple_trusted_roots_one_matches(self):
        ca_key, ca_cert = _make_self_signed_cert(cn="Real Root")
        _other_key, other_cert = _make_self_signed_cert(cn="Other")
        _leaf_key, leaf_cert = _make_signed_cert(ca_key, ca_cert, cn="Leaf")
        chain = [_cert_to_b64der(leaf_cert), _cert_to_b64der(ca_cert)]
        trusted = [_cert_to_pem(other_cert), _cert_to_pem(ca_cert)]
        receipt = verify_x5c_chain(chain, trusted_root_pems=trusted)
        assert receipt.issuer_cn == "Real Root"

    def test_no_trusted_roots_skips_check(self):
        ca_key, ca_cert = _make_self_signed_cert(cn="Root")
        _leaf_key, leaf_cert = _make_signed_cert(ca_key, ca_cert, cn="Leaf")
        chain = [_cert_to_b64der(leaf_cert), _cert_to_b64der(ca_cert)]
        # trusted_root_pems=None (default) should skip root check
        receipt = verify_x5c_chain(chain, trusted_root_pems=None)
        assert receipt.chain_depth == 2

    def test_empty_trusted_roots_list_skips_check(self):
        ca_key, ca_cert = _make_self_signed_cert(cn="Root")
        _leaf_key, leaf_cert = _make_signed_cert(ca_key, ca_cert, cn="Leaf")
        chain = [_cert_to_b64der(leaf_cert), _cert_to_b64der(ca_cert)]
        # Empty list is falsy, so trusted root check is skipped
        receipt = verify_x5c_chain(chain, trusted_root_pems=[])
        assert receipt.chain_depth == 2


class TestVerifyX5cChainCNExtraction:
    """Tests for CN extraction from certificates."""

    def test_cn_extracted_from_subject(self):
        _key, cert = _make_self_signed_cert(cn="My Special CN")
        chain = [_cert_to_b64der(cert)]
        receipt = verify_x5c_chain(chain)
        assert receipt.issuer_cn == "My Special CN"
        assert receipt.subject_cn == "My Special CN"

    def test_cert_without_cn(self):
        """Certificate with no CN attribute should return 'unknown'."""
        key = ec.generate_private_key(ec.SECP256R1())
        # Create a cert with only O, no CN
        subject = issuer = x509.Name(
            [x509.NameAttribute(NameOID.ORGANIZATION_NAME, "TestOrg")]
        )
        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(datetime.datetime.now(datetime.timezone.utc))
            .not_valid_after(
                datetime.datetime.now(datetime.timezone.utc)
                + datetime.timedelta(days=365)
            )
            .sign(key, hashes.SHA256())
        )
        chain = [_cert_to_b64der(cert)]
        receipt = verify_x5c_chain(chain)
        assert receipt.issuer_cn == "unknown"
        assert receipt.subject_cn == "unknown"


# ---------------------------------------------------------------------------
# extract_x5c_from_jwt
# ---------------------------------------------------------------------------


class TestExtractX5cFromJwt:
    """Tests for JWT x5c header extraction."""

    def test_valid_jwt_with_x5c(self):
        _key, cert = _make_self_signed_cert()
        b64der = _cert_to_b64der(cert)
        jwt = _make_jwt_with_header({"alg": "RS256", "x5c": [b64der]})
        result = extract_x5c_from_jwt(jwt)
        assert result == [b64der]

    def test_valid_jwt_multiple_x5c_certs(self):
        ca_key, ca_cert = _make_self_signed_cert(cn="CA")
        _leaf_key, leaf_cert = _make_signed_cert(ca_key, ca_cert, cn="Leaf")
        chain = [_cert_to_b64der(leaf_cert), _cert_to_b64der(ca_cert)]
        jwt = _make_jwt_with_header({"alg": "RS256", "x5c": chain})
        result = extract_x5c_from_jwt(jwt)
        assert result == chain

    def test_invalid_jwt_too_few_parts(self):
        with pytest.raises(ValueError, match="Invalid JWT format"):
            extract_x5c_from_jwt("single-segment")

    def test_jwt_without_x5c_returns_empty(self):
        jwt = _make_jwt_with_header({"alg": "RS256"})
        result = extract_x5c_from_jwt(jwt)
        assert result == []

    def test_jwt_x5c_not_list_raises(self):
        jwt = _make_jwt_with_header({"alg": "RS256", "x5c": "not-a-list"})
        with pytest.raises(ValueError, match="valid x5c claim"):
            extract_x5c_from_jwt(jwt)

    def test_jwt_x5c_contains_non_string_raises(self):
        jwt = _make_jwt_with_header({"alg": "RS256", "x5c": [123, 456]})
        with pytest.raises(ValueError, match="valid x5c claim"):
            extract_x5c_from_jwt(jwt)

    def test_jwt_x5c_mixed_types_raises(self):
        jwt = _make_jwt_with_header({"alg": "RS256", "x5c": ["valid", 42]})
        with pytest.raises(ValueError, match="valid x5c claim"):
            extract_x5c_from_jwt(jwt)

    def test_jwt_x5c_empty_list_returns_empty(self):
        """Empty x5c list is valid (it's a list of strings, vacuously)."""
        jwt = _make_jwt_with_header({"alg": "RS256", "x5c": []})
        result = extract_x5c_from_jwt(jwt)
        assert result == []

    def test_jwt_base64url_padding_handled(self):
        """JWT header may need padding restoration."""
        header = {"alg": "RS256", "x5c": ["certdata"]}
        header_json = json.dumps(header).encode()
        # Ensure we test with a header that needs padding
        header_b64 = base64.urlsafe_b64encode(header_json).decode().rstrip("=")
        payload_b64 = base64.urlsafe_b64encode(b"{}").decode().rstrip("=")
        jwt = f"{header_b64}.{payload_b64}.sig"
        result = extract_x5c_from_jwt(jwt)
        assert result == ["certdata"]


# ---------------------------------------------------------------------------
# Integration: extract_x5c_from_jwt + verify_x5c_chain
# ---------------------------------------------------------------------------


class TestX5cEndToEnd:
    """End-to-end tests combining extraction and verification."""

    def test_extract_then_verify(self):
        ca_key, ca_cert = _make_self_signed_cert(cn="E2E Root")
        _leaf_key, leaf_cert = _make_signed_cert(ca_key, ca_cert, cn="E2E Leaf")
        chain = [_cert_to_b64der(leaf_cert), _cert_to_b64der(ca_cert)]
        jwt = _make_jwt_with_header({"alg": "RS256", "x5c": chain})

        extracted = extract_x5c_from_jwt(jwt)
        receipt = verify_x5c_chain(extracted)
        assert receipt.subject_cn == "E2E Leaf"
        assert receipt.issuer_cn == "E2E Root"
        assert receipt.chain_depth == 2
