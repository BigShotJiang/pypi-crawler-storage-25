# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""Comprehensive tests for OPA License Verifier."""

from __future__ import annotations

from typing import Any

import io
import json
import urllib.request

import pytest

from coreason_ecosystem.auth.opa_license_verifier import (
    LICENSE_POLICY_REGO,
    LicenseVerificationReceipt,
    OPALicenseVerifier,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FakeResponse(io.BytesIO):
    """Context-manager wrapper around BytesIO simulating urlopen response."""

    def __enter__(self):
        return self

    def __exit__(self, *_a):
        pass


def _make_urlopen(response_data):
    """Return a callable replacing urllib.request.urlopen with canned JSON."""

    def _fake_urlopen(_req, timeout=None):  # noqa: ARG001
        return _FakeResponse(json.dumps(response_data).encode())

    return _fake_urlopen


def _make_urlopen_error(exc_cls=ConnectionError, msg="OPA unreachable"):
    """Return a callable that raises on every call."""

    def _fake_urlopen(_req, timeout=None):  # noqa: ARG001
        raise exc_cls(msg)

    return _fake_urlopen


# ---------------------------------------------------------------------------
# LicenseVerificationReceipt
# ---------------------------------------------------------------------------


class TestLicenseVerificationReceipt:
    """Tests for the receipt pydantic model."""

    def test_construction(self):
        r = LicenseVerificationReceipt(
            tenant_cid="tenant-1",
            license_tier="commercial",
            capabilities_granted=["cap:read", "cap:write"],
            policy_version="v2",
        )
        assert r.tenant_cid == "tenant-1"
        assert r.license_tier == "commercial"
        assert r.capabilities_granted == ["cap:read", "cap:write"]
        assert r.policy_version == "v2"

    def test_defaults(self):
        r = LicenseVerificationReceipt(
            tenant_cid="t",
            license_tier="prosperity-3.0",
        )
        assert r.capabilities_granted == []
        assert r.policy_version == "v1"

    def test_fields_required(self):
        with pytest.raises(Exception):
            LicenseVerificationReceipt()  # type: ignore[call-arg]


# ---------------------------------------------------------------------------
# OPALicenseVerifier.__init__
# ---------------------------------------------------------------------------


class TestOPALicenseVerifierInit:
    """Tests for verifier construction."""

    def test_defaults(self, monkeypatch):
        monkeypatch.delenv("OPA_URL", raising=False)
        v = OPALicenseVerifier()
        assert v.opa_url == "http://localhost:8181"
        assert v.policy_path == "v1/data/coreason/license"

    def test_custom_opa_url(self):
        v = OPALicenseVerifier(opa_url="http://opa:9999")
        assert v.opa_url == "http://opa:9999"

    def test_env_var_opa_url(self, monkeypatch):
        monkeypatch.setenv("OPA_URL", "http://env-opa:7777")
        v = OPALicenseVerifier()
        assert v.opa_url == "http://env-opa:7777"

    def test_explicit_overrides_env(self, monkeypatch):
        monkeypatch.setenv("OPA_URL", "http://env:1")
        v = OPALicenseVerifier(opa_url="http://explicit:2")
        assert v.opa_url == "http://explicit:2"

    def test_custom_policy_path(self):
        v = OPALicenseVerifier(policy_path="v2/data/custom")
        assert v.policy_path == "v2/data/custom"


# ---------------------------------------------------------------------------
# verify_license – OPA reachable
# ---------------------------------------------------------------------------


class TestVerifyLicenseOPAReachable:
    """Tests where OPA responds successfully."""

    def test_valid_license(self, monkeypatch):
        opa_result = {
            "result": {
                "valid": True,
                "license_tier": "commercial",
                "capability_allowed": True,
            }
        }
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen(opa_result))
        v = OPALicenseVerifier(opa_url="http://opa:8181")
        receipt = v.verify_license(
            jwt_claims={
                "exp": 9999999999,
                "license_tier": "commercial",
                "capabilities": ["cap:a"],
            },
            tenant_cid="t-1",
            current_epoch=1000,
        )
        assert receipt.tenant_cid == "t-1"
        assert receipt.license_tier == "commercial"
        assert receipt.capabilities_granted == ["cap:a"]

    def test_invalid_license_raises(self, monkeypatch):
        opa_result = {"result": {"valid": False}}
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen(opa_result))
        v = OPALicenseVerifier(opa_url="http://opa:8181")
        with pytest.raises(PermissionError, match="License verification failed"):
            v.verify_license(
                jwt_claims={"exp": 100},
                tenant_cid="t-expired",
                current_epoch=999,
            )

    def test_opa_returns_no_valid_key(self, monkeypatch):
        """When OPA result has no 'valid' key, it's falsy -> PermissionError."""
        opa_result = {"result": {"other": "data"}}
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen(opa_result))
        v = OPALicenseVerifier(opa_url="http://opa:8181")
        with pytest.raises(PermissionError):
            v.verify_license(
                jwt_claims={"exp": 9999999999},
                tenant_cid="t",
                current_epoch=1000,
            )

    def test_opa_returns_empty_result(self, monkeypatch):
        """When OPA result is empty dict."""
        opa_result: dict[str, Any] = {"result": {}}
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen(opa_result))
        v = OPALicenseVerifier(opa_url="http://opa:8181")
        with pytest.raises(PermissionError):
            v.verify_license(
                jwt_claims={"exp": 9999999999},
                tenant_cid="t",
                current_epoch=1000,
            )

    def test_default_tier_when_not_in_result(self, monkeypatch):
        opa_result = {"result": {"valid": True}}
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen(opa_result))
        v = OPALicenseVerifier(opa_url="http://opa:8181")
        receipt = v.verify_license(
            jwt_claims={"exp": 9999999999},
            tenant_cid="t-1",
            current_epoch=1000,
        )
        assert receipt.license_tier == "prosperity-3.0"

    def test_capabilities_from_claims(self, monkeypatch):
        opa_result = {"result": {"valid": True, "license_tier": "commercial"}}
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen(opa_result))
        v = OPALicenseVerifier(opa_url="http://opa:8181")
        receipt = v.verify_license(
            jwt_claims={
                "exp": 9999999999,
                "capabilities": ["read", "write", "admin"],
            },
            tenant_cid="t-1",
            current_epoch=1000,
        )
        assert receipt.capabilities_granted == ["read", "write", "admin"]

    def test_no_capabilities_in_claims(self, monkeypatch):
        opa_result = {"result": {"valid": True}}
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen(opa_result))
        v = OPALicenseVerifier(opa_url="http://opa:8181")
        receipt = v.verify_license(
            jwt_claims={"exp": 9999999999},
            tenant_cid="t",
            current_epoch=1000,
        )
        assert receipt.capabilities_granted == []

    def test_input_doc_construction(self, monkeypatch):
        """Verify the input document sent to OPA."""
        captured = {}

        def _capture_urlopen(req, timeout=None):  # noqa: ARG001
            captured["body"] = json.loads(req.data.decode())
            return _FakeResponse(json.dumps({"result": {"valid": True}}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _capture_urlopen)
        v = OPALicenseVerifier(opa_url="http://opa:8181")
        v.verify_license(
            jwt_claims={"exp": 5000},
            tenant_cid="t-42",
            requested_capability="cap:exec",
            current_epoch=1000,
        )
        doc = captured["body"]["input"]
        assert doc["claims"] == {"exp": 5000}
        assert doc["tenant_cid"] == "t-42"
        assert doc["requested_capability"] == "cap:exec"
        assert doc["current_epoch"] == 1000


# ---------------------------------------------------------------------------
# verify_license – OPA unreachable (fallback to local)
# ---------------------------------------------------------------------------


class TestVerifyLicenseFallback:
    """Tests where OPA is unreachable and fallback to _evaluate_locally."""

    def test_fallback_valid_license(self, monkeypatch):
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen_error())
        v = OPALicenseVerifier(opa_url="http://opa:8181")
        receipt = v.verify_license(
            jwt_claims={"exp": 9999999999, "license_tier": "commercial"},
            tenant_cid="t-1",
            current_epoch=1000,
        )
        assert receipt.tenant_cid == "t-1"
        assert receipt.license_tier == "commercial"

    def test_fallback_expired_license(self, monkeypatch):
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen_error())
        v = OPALicenseVerifier(opa_url="http://opa:8181")
        with pytest.raises(PermissionError, match="License verification failed"):
            v.verify_license(
                jwt_claims={"exp": 500},
                tenant_cid="t-expired",
                current_epoch=1000,
            )

    def test_fallback_with_timeout(self, monkeypatch):
        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            _make_urlopen_error(TimeoutError, "timed out"),
        )
        v = OPALicenseVerifier(opa_url="http://opa:8181")
        receipt = v.verify_license(
            jwt_claims={"exp": 9999999999},
            tenant_cid="t",
            current_epoch=1000,
        )
        assert receipt.tenant_cid == "t"


# ---------------------------------------------------------------------------
# _evaluate_locally
# ---------------------------------------------------------------------------


class TestEvaluateLocally:
    """Tests for the local fallback evaluator."""

    def _verifier(self):
        return OPALicenseVerifier(opa_url="http://unused:0")

    def test_exp_greater_than_epoch(self):
        v = self._verifier()
        result = v._evaluate_locally({"exp": 2000}, 1000, "")
        assert result["valid"] is True

    def test_exp_less_than_epoch(self):
        v = self._verifier()
        result = v._evaluate_locally({"exp": 500}, 1000, "")
        assert result["valid"] is False

    def test_exp_equal_to_epoch(self):
        v = self._verifier()
        result = v._evaluate_locally({"exp": 1000}, 1000, "")
        assert result["valid"] is False  # not strictly greater

    def test_expires_at_epoch_legacy(self):
        v = self._verifier()
        result = v._evaluate_locally({"expires_at_epoch": 2000}, 1000, "")
        assert result["valid"] is True

    def test_exp_takes_precedence_over_legacy(self):
        v = self._verifier()
        result = v._evaluate_locally({"exp": 2000, "expires_at_epoch": 500}, 1000, "")
        assert result["valid"] is True

    def test_no_exp_fields(self):
        v = self._verifier()
        result = v._evaluate_locally({}, 1000, "")
        assert result["valid"] is False

    def test_license_tier_from_claims(self):
        v = self._verifier()
        result = v._evaluate_locally(
            {"exp": 2000, "license_tier": "enterprise"}, 1000, ""
        )
        assert result["license_tier"] == "enterprise"

    def test_default_license_tier(self):
        v = self._verifier()
        result = v._evaluate_locally({"exp": 2000}, 1000, "")
        assert result["license_tier"] == "prosperity-3.0"

    def test_capability_in_list(self):
        v = self._verifier()
        result = v._evaluate_locally(
            {"exp": 2000, "capabilities": ["read", "write"]}, 1000, "read"
        )
        assert result["capability_allowed"] is True

    def test_capability_not_in_list(self):
        v = self._verifier()
        result = v._evaluate_locally(
            {"exp": 2000, "capabilities": ["read"]}, 1000, "write"
        )
        assert result["capability_allowed"] is False

    def test_capability_wildcard(self):
        v = self._verifier()
        result = v._evaluate_locally(
            {"exp": 2000, "capabilities": ["*"]}, 1000, "anything"
        )
        assert result["capability_allowed"] is True

    def test_capability_empty_list(self):
        v = self._verifier()
        result = v._evaluate_locally(
            {"exp": 2000, "capabilities": []}, 1000, "something"
        )
        assert result["capability_allowed"] is True

    def test_capability_no_capabilities_key(self):
        v = self._verifier()
        result = v._evaluate_locally({"exp": 2000}, 1000, "something")
        assert result["capability_allowed"] is True

    def test_no_requested_capability(self):
        v = self._verifier()
        result = v._evaluate_locally({"exp": 2000, "capabilities": ["read"]}, 1000, "")
        assert result["capability_allowed"] is True

    def test_exp_as_string(self):
        """exp might come as a string from some JWT decoders."""
        v = self._verifier()
        result = v._evaluate_locally({"exp": "2000"}, 1000, "")
        assert result["valid"] is True


# ---------------------------------------------------------------------------
# verify_license – current_epoch default
# ---------------------------------------------------------------------------


class TestVerifyLicenseCurrentEpochDefault:
    """Tests that current_epoch defaults to int(time.time()) when not passed."""

    def test_default_epoch_is_near_now(self, monkeypatch):
        """When current_epoch is None, it should be close to time.time()."""
        import time

        captured = {}

        def _capture_urlopen(req, timeout=None):  # noqa: ARG001
            captured["body"] = json.loads(req.data.decode())
            return _FakeResponse(json.dumps({"result": {"valid": True}}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _capture_urlopen)
        v = OPALicenseVerifier(opa_url="http://opa:8181")
        before = int(time.time())
        v.verify_license(
            jwt_claims={"exp": 9999999999},
            tenant_cid="t",
        )
        after = int(time.time())
        epoch = captured["body"]["input"]["current_epoch"]
        assert before <= epoch <= after


# ---------------------------------------------------------------------------
# write_rego_policy
# ---------------------------------------------------------------------------


class TestWriteRegoPolicy:
    """Tests for Rego policy file writing."""

    def test_writes_file(self, tmp_path):
        v = OPALicenseVerifier()
        result = v.write_rego_policy(tmp_path / "policy.rego")
        assert result.exists()
        assert result.name == "policy.rego"

    def test_content_matches(self, tmp_path):
        v = OPALicenseVerifier()
        result = v.write_rego_policy(tmp_path / "policy.rego")
        content = result.read_text(encoding="utf-8")
        assert content == LICENSE_POLICY_REGO

    def test_creates_parent_dirs(self, tmp_path):
        v = OPALicenseVerifier()
        result = v.write_rego_policy(tmp_path / "a" / "b" / "c" / "policy.rego")
        assert result.exists()
        assert result.parent.name == "c"

    def test_returns_path_object(self, tmp_path):
        from pathlib import Path

        v = OPALicenseVerifier()
        result = v.write_rego_policy(tmp_path / "policy.rego")
        assert isinstance(result, Path)

    def test_string_path_accepted(self, tmp_path):
        v = OPALicenseVerifier()
        result = v.write_rego_policy(str(tmp_path / "policy.rego"))
        assert result.exists()

    def test_overwrite_existing(self, tmp_path):
        v = OPALicenseVerifier()
        path = tmp_path / "policy.rego"
        path.write_text("old content")
        result = v.write_rego_policy(path)
        assert result.read_text(encoding="utf-8") == LICENSE_POLICY_REGO

    def test_contains_rego_package(self, tmp_path):
        v = OPALicenseVerifier()
        result = v.write_rego_policy(tmp_path / "policy.rego")
        content = result.read_text(encoding="utf-8")
        assert "package coreason.license" in content

    def test_contains_valid_rule(self, tmp_path):
        v = OPALicenseVerifier()
        result = v.write_rego_policy(tmp_path / "policy.rego")
        content = result.read_text(encoding="utf-8")
        assert "default valid := false" in content
        assert "input.claims.exp" in content


# ---------------------------------------------------------------------------
# LICENSE_POLICY_REGO constant
# ---------------------------------------------------------------------------


class TestLicensePolicyRego:
    """Tests for the Rego policy constant."""

    def test_is_string(self):
        assert isinstance(LICENSE_POLICY_REGO, str)

    def test_contains_package(self):
        assert "package coreason.license" in LICENSE_POLICY_REGO

    def test_contains_capability_rules(self):
        assert "capability_allowed" in LICENSE_POLICY_REGO

    def test_contains_legacy_support(self):
        assert "expires_at_epoch" in LICENSE_POLICY_REGO

    def test_contains_future_keywords(self):
        assert "import future.keywords.if" in LICENSE_POLICY_REGO
        assert "import future.keywords.in" in LICENSE_POLICY_REGO
