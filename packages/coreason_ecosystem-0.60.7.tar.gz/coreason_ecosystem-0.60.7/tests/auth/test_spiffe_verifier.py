# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""Comprehensive tests for SPIFFE/SPIRE Certificate Verification."""

from __future__ import annotations

from typing import Any

import datetime
import hashlib
import ssl

import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID

from coreason_ecosystem.auth.spiffe_verifier import (
    SPIFFEIdentityReceipt,
    SPIFFEVerifier,
)


# ---------------------------------------------------------------------------
# Helpers – generate real X.509 certificates
# ---------------------------------------------------------------------------


def _generate_test_ca_cert(tmp_path, cn="Test SPIFFE CA"):
    """Generate a self-signed CA certificate + key and write PEM files."""
    key = ec.generate_private_key(ec.SECP256R1())
    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.now(datetime.timezone.utc))
        .not_valid_after(
            datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=365)
        )
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .sign(key, hashes.SHA256())
    )
    bundle_path = tmp_path / "bundle.crt"
    cert_path = tmp_path / "svid.crt"
    key_path = tmp_path / "svid.key"

    bundle_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        )
    )
    return bundle_path, cert_path, key_path


# ---------------------------------------------------------------------------
# SPIFFEIdentityReceipt
# ---------------------------------------------------------------------------


class TestSPIFFEIdentityReceipt:
    """Tests for the receipt pydantic model."""

    def test_construction(self):
        r = SPIFFEIdentityReceipt(
            spiffe_id="spiffe://example.com/workload/api",
            trust_domain="example.com",
            workload_path="/workload/api",
            certificate_fingerprint="abcdef1234567890",
        )
        assert r.spiffe_id == "spiffe://example.com/workload/api"
        assert r.trust_domain == "example.com"
        assert r.workload_path == "/workload/api"
        assert r.certificate_fingerprint == "abcdef1234567890"

    def test_fields_required(self):
        with pytest.raises(Exception):
            SPIFFEIdentityReceipt()  # type: ignore[call-arg]


# ---------------------------------------------------------------------------
# SPIFFEVerifier.__init__
# ---------------------------------------------------------------------------


class TestSPIFFEVerifierInit:
    """Tests for verifier construction and path resolution."""

    def test_default_paths(self, monkeypatch):
        monkeypatch.delenv("SPIFFE_BUNDLE_PATH", raising=False)
        monkeypatch.delenv("SPIFFE_SVID_CERT", raising=False)
        monkeypatch.delenv("SPIFFE_SVID_KEY", raising=False)
        v = SPIFFEVerifier()
        assert (
            str(v.trust_bundle_path).replace("\\", "/")
            == "/run/spire/bundle/bundle.crt"
        )
        assert str(v.svid_cert_path).replace("\\", "/") == "/run/spire/svid/svid.crt"
        assert str(v.svid_key_path).replace("\\", "/") == "/run/spire/svid/svid.key"

    def test_custom_paths(self, tmp_path):
        bundle = tmp_path / "bundle.pem"
        cert = tmp_path / "cert.pem"
        key = tmp_path / "key.pem"
        v = SPIFFEVerifier(
            trust_bundle_path=bundle,
            svid_cert_path=cert,
            svid_key_path=key,
        )
        assert v.trust_bundle_path == bundle
        assert v.svid_cert_path == cert
        assert v.svid_key_path == key

    def test_env_var_paths(self, monkeypatch, tmp_path):
        monkeypatch.setenv("SPIFFE_BUNDLE_PATH", str(tmp_path / "env_bundle.crt"))
        monkeypatch.setenv("SPIFFE_SVID_CERT", str(tmp_path / "env_cert.crt"))
        monkeypatch.setenv("SPIFFE_SVID_KEY", str(tmp_path / "env_key.key"))
        v = SPIFFEVerifier()
        assert v.trust_bundle_path.name == "env_bundle.crt"
        assert v.svid_cert_path.name == "env_cert.crt"
        assert v.svid_key_path.name == "env_key.key"

    def test_explicit_paths_override_env(self, monkeypatch, tmp_path):
        monkeypatch.setenv("SPIFFE_BUNDLE_PATH", "/env/path")
        explicit = tmp_path / "explicit.crt"
        v = SPIFFEVerifier(trust_bundle_path=explicit)
        assert v.trust_bundle_path == explicit

    def test_string_path_converted_to_pathlib(self):
        v = SPIFFEVerifier(trust_bundle_path="/some/path.crt")
        from pathlib import Path

        assert isinstance(v.trust_bundle_path, Path)


# ---------------------------------------------------------------------------
# create_ssl_context
# ---------------------------------------------------------------------------


class TestCreateSSLContext:
    """Tests for SSL context creation."""

    def test_client_side_protocol(self, tmp_path):
        v = SPIFFEVerifier(
            trust_bundle_path=tmp_path / "nonexistent",
            svid_cert_path=tmp_path / "nonexistent",
            svid_key_path=tmp_path / "nonexistent",
        )
        ctx = v.create_ssl_context(server_side=False)
        assert isinstance(ctx, ssl.SSLContext)
        assert ctx.verify_mode == ssl.CERT_REQUIRED
        assert ctx.minimum_version == ssl.TLSVersion.TLSv1_3

    def test_server_side_protocol(self, tmp_path):
        v = SPIFFEVerifier(
            trust_bundle_path=tmp_path / "nonexistent",
            svid_cert_path=tmp_path / "nonexistent",
            svid_key_path=tmp_path / "nonexistent",
        )
        ctx = v.create_ssl_context(server_side=True)
        assert isinstance(ctx, ssl.SSLContext)

    def test_loads_trust_bundle(self, tmp_path):
        bundle, cert, key = _generate_test_ca_cert(tmp_path)
        v = SPIFFEVerifier(
            trust_bundle_path=bundle,
            svid_cert_path=cert,
            svid_key_path=key,
        )
        # Should not raise – loads the real cert files
        ctx = v.create_ssl_context(server_side=True)
        assert isinstance(ctx, ssl.SSLContext)

    def test_missing_cert_files_no_error(self, tmp_path):
        """When cert files don't exist, context is still created."""
        v = SPIFFEVerifier(
            trust_bundle_path=tmp_path / "no_bundle.crt",
            svid_cert_path=tmp_path / "no_cert.crt",
            svid_key_path=tmp_path / "no_key.key",
        )
        ctx = v.create_ssl_context()
        assert isinstance(ctx, ssl.SSLContext)

    def test_partial_cert_files(self, tmp_path):
        """When only bundle exists but cert/key don't, still works."""
        bundle, _, _ = _generate_test_ca_cert(tmp_path)
        v = SPIFFEVerifier(
            trust_bundle_path=bundle,
            svid_cert_path=tmp_path / "missing_cert.crt",
            svid_key_path=tmp_path / "missing_key.key",
        )
        ctx = v.create_ssl_context(server_side=True)
        assert isinstance(ctx, ssl.SSLContext)


# ---------------------------------------------------------------------------
# verify_peer_spiffe_id
# ---------------------------------------------------------------------------


class TestVerifyPeerSPIFFEId:
    """Tests for SPIFFE ID extraction from peer certificates."""

    def test_happy_path(self):
        peer_cert = {
            "subjectAltName": [
                ("URI", "spiffe://coreason.ai/workload/gateway"),
            ],
            "serialNumber": "ABC123",
        }
        v = SPIFFEVerifier()
        receipt = v.verify_peer_spiffe_id(peer_cert)
        assert receipt.spiffe_id == "spiffe://coreason.ai/workload/gateway"
        assert receipt.trust_domain == "coreason.ai"
        assert receipt.workload_path == "/workload/gateway"
        expected_fp = hashlib.sha256(b"ABC123").hexdigest()
        assert receipt.certificate_fingerprint == expected_fp

    def test_no_san_raises(self):
        peer_cert: dict[str, Any] = {"serialNumber": "ABC"}
        v = SPIFFEVerifier()
        with pytest.raises(ValueError, match="does not contain a SPIFFE ID"):
            v.verify_peer_spiffe_id(peer_cert)

    def test_empty_san_raises(self):
        peer_cert = {"subjectAltName": [], "serialNumber": "X"}
        v = SPIFFEVerifier()
        with pytest.raises(ValueError):
            v.verify_peer_spiffe_id(peer_cert)

    def test_san_without_spiffe_uri_raises(self):
        peer_cert = {
            "subjectAltName": [
                ("DNS", "example.com"),
                ("URI", "https://not-spiffe.example.com"),
            ],
            "serialNumber": "X",
        }
        v = SPIFFEVerifier()
        with pytest.raises(ValueError):
            v.verify_peer_spiffe_id(peer_cert)

    def test_multiple_sans_picks_first_spiffe(self):
        peer_cert = {
            "subjectAltName": [
                ("DNS", "example.com"),
                ("URI", "https://other.example.com"),
                ("URI", "spiffe://first.domain/svc/a"),
                ("URI", "spiffe://second.domain/svc/b"),
            ],
            "serialNumber": "SN42",
        }
        v = SPIFFEVerifier()
        receipt = v.verify_peer_spiffe_id(peer_cert)
        assert receipt.spiffe_id == "spiffe://first.domain/svc/a"
        assert receipt.trust_domain == "first.domain"
        assert receipt.workload_path == "/svc/a"

    def test_trust_domain_only_no_workload(self):
        """spiffe://domain with no path -> workload_path = '/'."""
        peer_cert = {
            "subjectAltName": [("URI", "spiffe://standalone.domain")],
            "serialNumber": "0",
        }
        v = SPIFFEVerifier()
        receipt = v.verify_peer_spiffe_id(peer_cert)
        assert receipt.trust_domain == "standalone.domain"
        assert receipt.workload_path == "/"

    def test_deep_workload_path(self):
        peer_cert = {
            "subjectAltName": [
                ("URI", "spiffe://prod.coreason.ai/ns/default/sa/api-gateway"),
            ],
            "serialNumber": "DEEP",
        }
        v = SPIFFEVerifier()
        receipt = v.verify_peer_spiffe_id(peer_cert)
        assert receipt.trust_domain == "prod.coreason.ai"
        assert receipt.workload_path == "/ns/default/sa/api-gateway"

    def test_fingerprint_from_serial_number(self):
        peer_cert = {
            "subjectAltName": [("URI", "spiffe://d/w")],
            "serialNumber": "SERIAL999",
        }
        v = SPIFFEVerifier()
        receipt = v.verify_peer_spiffe_id(peer_cert)
        assert (
            receipt.certificate_fingerprint == hashlib.sha256(b"SERIAL999").hexdigest()
        )

    def test_fingerprint_unknown_when_no_serial(self):
        peer_cert = {
            "subjectAltName": [("URI", "spiffe://d/w")],
        }
        v = SPIFFEVerifier()
        receipt = v.verify_peer_spiffe_id(peer_cert)
        assert receipt.certificate_fingerprint == hashlib.sha256(b"unknown").hexdigest()

    def test_receipt_is_immutable_model(self):
        peer_cert = {
            "subjectAltName": [("URI", "spiffe://d/w")],
            "serialNumber": "1",
        }
        v = SPIFFEVerifier()
        receipt = v.verify_peer_spiffe_id(peer_cert)
        assert isinstance(receipt, SPIFFEIdentityReceipt)
