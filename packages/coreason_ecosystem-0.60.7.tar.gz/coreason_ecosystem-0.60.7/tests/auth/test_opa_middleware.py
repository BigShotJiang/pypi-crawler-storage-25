# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""Comprehensive tests for OPA Role-Check Middleware."""

from __future__ import annotations

import io
import json
import urllib.request

import pytest

from coreason_ecosystem.auth.opa_middleware import (
    OPAPolicyDecision,
    OPARoleCheckMiddleware,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FakeResponse(io.BytesIO):
    """Minimal context-manager wrapper around BytesIO to simulate urlopen."""

    def __enter__(self):
        return self

    def __exit__(self, *_a):
        pass


def _make_urlopen(response_data):
    """Return a callable that replaces urllib.request.urlopen."""

    def _fake_urlopen(_req, timeout=None):  # noqa: ARG001
        return _FakeResponse(json.dumps(response_data).encode())

    return _fake_urlopen


def _make_urlopen_error(exc_cls=ConnectionError, msg="OPA unreachable"):
    """Return a callable that raises on every call."""

    def _fake_urlopen(_req, timeout=None):  # noqa: ARG001
        raise exc_cls(msg)

    return _fake_urlopen


# ---------------------------------------------------------------------------
# OPAPolicyDecision
# ---------------------------------------------------------------------------


class TestOPAPolicyDecision:
    """Tests for OPAPolicyDecision data class."""

    def test_defaults(self):
        d = OPAPolicyDecision(allowed=True)
        assert d.allowed is True
        assert d.reason == ""
        assert d.evaluated_rules == []

    def test_all_args(self):
        d = OPAPolicyDecision(
            allowed=False,
            reason="policy X",
            evaluated_rules=["rule/a", "rule/b"],
        )
        assert d.allowed is False
        assert d.reason == "policy X"
        assert d.evaluated_rules == ["rule/a", "rule/b"]

    def test_slots(self):
        d = OPAPolicyDecision(allowed=True)
        assert "__dict__" not in dir(d)
        with pytest.raises(AttributeError):
            d.extra = "boom"  # type: ignore[attr-defined]

    def test_evaluated_rules_none_becomes_empty_list(self):
        d = OPAPolicyDecision(allowed=True, evaluated_rules=None)
        assert d.evaluated_rules == []


# ---------------------------------------------------------------------------
# OPARoleCheckMiddleware.__init__
# ---------------------------------------------------------------------------


class TestOPARoleCheckMiddlewareInit:
    """Tests for middleware construction and defaults."""

    def test_defaults(self, monkeypatch):
        monkeypatch.delenv("OPA_URL", raising=False)
        m = OPARoleCheckMiddleware()
        assert m.opa_url == "http://localhost:8181"
        assert m.policy_path == "v1/data/coreason/authz/allow"
        assert m.default_deny is True

    def test_custom_opa_url(self):
        m = OPARoleCheckMiddleware(opa_url="http://opa:9999")
        assert m.opa_url == "http://opa:9999"

    def test_env_var_opa_url(self, monkeypatch):
        monkeypatch.setenv("OPA_URL", "http://env-opa:4444")
        m = OPARoleCheckMiddleware()
        assert m.opa_url == "http://env-opa:4444"

    def test_explicit_url_overrides_env(self, monkeypatch):
        monkeypatch.setenv("OPA_URL", "http://env-opa:4444")
        m = OPARoleCheckMiddleware(opa_url="http://explicit:5555")
        assert m.opa_url == "http://explicit:5555"

    def test_custom_policy_path(self):
        m = OPARoleCheckMiddleware(policy_path="v2/data/custom/policy")
        assert m.policy_path == "v2/data/custom/policy"

    def test_default_deny_false(self):
        m = OPARoleCheckMiddleware(default_deny=False)
        assert m.default_deny is False


# ---------------------------------------------------------------------------
# OPARoleCheckMiddleware.evaluate
# ---------------------------------------------------------------------------


class TestEvaluateHappyPath:
    """Tests for successful OPA evaluation."""

    def test_allowed_true(self, monkeypatch):
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen({"result": True}))
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181")
        decision = m.evaluate(method="GET", path="/api/v1/resource")
        assert decision.allowed is True
        assert decision.reason == "OPA policy evaluation"
        assert decision.evaluated_rules == ["v1/data/coreason/authz/allow"]

    def test_allowed_false(self, monkeypatch):
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen({"result": False}))
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181")
        decision = m.evaluate(method="POST", path="/api/v1/resource")
        assert decision.allowed is False
        assert decision.reason == "Denied by OPA policy"

    def test_result_key_missing(self, monkeypatch):
        """When OPA returns no 'result' key, decision is denied (falsy default)."""
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen({"other": "data"}))
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181")
        decision = m.evaluate(method="GET", path="/health")
        assert decision.allowed is False
        assert decision.reason == "Denied by OPA policy"

    def test_result_truthy_nonbool(self, monkeypatch):
        """OPA returning a truthy non-bool (e.g. a dict) should be coerced to True."""
        monkeypatch.setattr(
            urllib.request, "urlopen", _make_urlopen({"result": {"allow": True}})
        )
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181")
        decision = m.evaluate(method="GET", path="/api")
        assert decision.allowed is True


class TestEvaluateInputConstruction:
    """Tests that the input document sent to OPA is constructed correctly."""

    def test_method_uppercased(self, monkeypatch):
        captured = {}

        def _capture_urlopen(req, timeout=None):  # noqa: ARG001
            captured["body"] = json.loads(req.data.decode())
            return _FakeResponse(json.dumps({"result": True}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _capture_urlopen)
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181")
        m.evaluate(method="get", path="/api")
        assert captured["body"]["input"]["method"] == "GET"

    def test_path_normalized(self, monkeypatch):
        captured = {}

        def _capture_urlopen(req, timeout=None):  # noqa: ARG001
            captured["body"] = json.loads(req.data.decode())
            return _FakeResponse(json.dumps({"result": True}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _capture_urlopen)
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181")
        m.evaluate(method="GET", path="/api/v1/resource/")
        assert captured["body"]["input"]["path"] == ["api", "v1", "resource"]

    def test_jwt_claims_and_roles(self, monkeypatch):
        captured = {}

        def _capture_urlopen(req, timeout=None):  # noqa: ARG001
            captured["body"] = json.loads(req.data.decode())
            return _FakeResponse(json.dumps({"result": True}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _capture_urlopen)
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181")
        claims = {"sub": "user1", "roles": ["admin", "operator"]}
        m.evaluate(method="POST", path="/api", jwt_claims=claims)
        assert captured["body"]["input"]["claims"] == claims
        assert captured["body"]["input"]["roles"] == ["admin", "operator"]

    def test_jwt_claims_none(self, monkeypatch):
        captured = {}

        def _capture_urlopen(req, timeout=None):  # noqa: ARG001
            captured["body"] = json.loads(req.data.decode())
            return _FakeResponse(json.dumps({"result": True}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _capture_urlopen)
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181")
        m.evaluate(method="GET", path="/api")
        assert captured["body"]["input"]["claims"] == {}
        assert captured["body"]["input"]["roles"] == []

    def test_tenant_cid_passed(self, monkeypatch):
        captured = {}

        def _capture_urlopen(req, timeout=None):  # noqa: ARG001
            captured["body"] = json.loads(req.data.decode())
            return _FakeResponse(json.dumps({"result": True}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _capture_urlopen)
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181")
        m.evaluate(method="GET", path="/api", tenant_cid="tenant-abc")
        assert captured["body"]["input"]["tenant_cid"] == "tenant-abc"

    def test_custom_policy_path_in_url(self, monkeypatch):
        captured = {}

        def _capture_urlopen(req, timeout=None):  # noqa: ARG001
            captured["url"] = req.full_url
            return _FakeResponse(json.dumps({"result": True}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _capture_urlopen)
        m = OPARoleCheckMiddleware(
            opa_url="http://opa:8181/", policy_path="v2/custom/path"
        )
        m.evaluate(method="GET", path="/api")
        assert captured["url"] == "http://opa:8181/v2/custom/path"

    def test_trailing_slash_stripped_from_opa_url(self, monkeypatch):
        captured = {}

        def _capture_urlopen(req, timeout=None):  # noqa: ARG001
            captured["url"] = req.full_url
            return _FakeResponse(json.dumps({"result": True}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _capture_urlopen)
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181///")
        m.evaluate(method="GET", path="/api")
        assert "///" not in captured["url"]


class TestEvaluateFailure:
    """Tests for OPA communication failures."""

    def test_default_deny_on_error(self, monkeypatch):
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen_error())
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181", default_deny=True)
        decision = m.evaluate(method="GET", path="/api")
        assert decision.allowed is False
        assert "default-deny" in decision.reason
        assert "OPA unreachable" in decision.reason

    def test_default_allow_on_error(self, monkeypatch):
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen_error())
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181", default_deny=False)
        decision = m.evaluate(method="GET", path="/api")
        assert decision.allowed is True
        assert "default-allow" in decision.reason

    def test_timeout_error(self, monkeypatch):
        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            _make_urlopen_error(TimeoutError, "timed out"),
        )
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181")
        decision = m.evaluate(method="GET", path="/api")
        assert decision.allowed is False
        assert "timed out" in decision.reason

    def test_evaluated_rules_empty_on_error(self, monkeypatch):
        monkeypatch.setattr(urllib.request, "urlopen", _make_urlopen_error())
        m = OPARoleCheckMiddleware(opa_url="http://opa:8181")
        decision = m.evaluate(method="GET", path="/api")
        assert decision.evaluated_rules == []


# ---------------------------------------------------------------------------
# create_rego_policy
# ---------------------------------------------------------------------------


class TestCreateRegoPolicy:
    """Tests for Rego policy generation."""

    def test_returns_string(self):
        m = OPARoleCheckMiddleware()
        policy = m.create_rego_policy()
        assert isinstance(policy, str)

    def test_contains_package(self):
        m = OPARoleCheckMiddleware()
        policy = m.create_rego_policy()
        assert "package coreason.authz" in policy

    def test_contains_allow_rules(self):
        m = OPARoleCheckMiddleware()
        policy = m.create_rego_policy()
        assert "default allow := false" in policy
        assert '"operator" in input.roles' in policy

    def test_contains_health_check_rule(self):
        m = OPARoleCheckMiddleware()
        policy = m.create_rego_policy()
        assert 'input.path[0] == "health"' in policy

    def test_contains_tenant_rules(self):
        m = OPARoleCheckMiddleware()
        policy = m.create_rego_policy()
        assert "input.tenant_cid" in policy
        assert "deny if" in policy

    def test_contains_future_keywords(self):
        m = OPARoleCheckMiddleware()
        policy = m.create_rego_policy()
        assert "import future.keywords.if" in policy
        assert "import future.keywords.in" in policy


# ---------------------------------------------------------------------------
# Sprint C: _sanitize_claims tests
# ---------------------------------------------------------------------------


class TestSanitizeClaims:
    """Tests for JWT claims depth sanitization (Sprint C: C1.4)."""

    def test_flat_claims_unchanged(self):
        claims = {"sub": "user1", "iss": "coreason", "exp": 9999999}
        result = OPARoleCheckMiddleware._sanitize_claims(claims)
        assert result == claims

    def test_two_level_nesting_preserved(self):
        claims = {"sub": "user1", "org": {"name": "CoReason", "tier": "enterprise"}}
        result = OPARoleCheckMiddleware._sanitize_claims(claims)
        assert result == claims

    def test_deep_nesting_truncated(self):
        claims = {"level1": {"level2": {"level3": {"level4": "should be gone"}}}}
        result = OPARoleCheckMiddleware._sanitize_claims(claims)
        # At depth 3, the level3 dict should be empty (level4 truncated)
        assert result["level1"]["level2"]["level3"] == {}

    def test_lists_preserved(self):
        claims = {"roles": ["admin", "operator"], "groups": [1, 2, 3]}
        result = OPARoleCheckMiddleware._sanitize_claims(claims)
        assert result["roles"] == ["admin", "operator"]
        assert result["groups"] == [1, 2, 3]

    def test_lists_with_nested_dicts_truncated(self):
        claims = {
            "items": [
                {"name": "a", "nested": {"deep": {"too_deep": "gone"}}},
                "plain_string",
            ]
        }
        result = OPARoleCheckMiddleware._sanitize_claims(claims)
        assert result["items"][0]["name"] == "a"
        # The deep nesting within list items should also be truncated
        assert result["items"][1] == "plain_string"

    def test_custom_max_depth(self):
        claims = {"a": {"b": "should be truncated"}}
        result = OPARoleCheckMiddleware._sanitize_claims(claims, max_depth=1)
        assert result["a"] == {}

    def test_empty_claims(self):
        assert OPARoleCheckMiddleware._sanitize_claims({}) == {}

    def test_none_and_bool_values_preserved(self):
        claims = {"flag": True, "empty": None, "count": 0}
        result = OPARoleCheckMiddleware._sanitize_claims(claims)
        assert result == claims


# ---------------------------------------------------------------------------
# Sprint D: OPA TTL Cache Tests (D5.3)
# ---------------------------------------------------------------------------


class TestOPACacheBehavior:
    """Tests for the policy decision TTL cache."""

    def test_cache_hit_returns_same_decision(self, monkeypatch):
        """Identical inputs should return cached decision on second call."""
        call_count = 0

        def _counting_urlopen(_req, timeout=None):
            nonlocal call_count
            call_count += 1
            return _FakeResponse(json.dumps({"result": True}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _counting_urlopen)

        mw = OPARoleCheckMiddleware(cache_ttl_seconds=60.0)
        d1 = mw.evaluate(
            method="GET", path="/api/test", jwt_claims={"sub": "u1"}, tenant_cid="t1"
        )
        d2 = mw.evaluate(
            method="GET", path="/api/test", jwt_claims={"sub": "u1"}, tenant_cid="t1"
        )

        assert d1.allowed is True
        assert d2.allowed is True
        assert call_count == 1  # Only one HTTP call — second was cached

    def test_cache_expires_after_ttl(self, monkeypatch):
        """Expired entries should be re-fetched."""
        import time

        call_count = 0

        def _counting_urlopen(_req, timeout=None):
            nonlocal call_count
            call_count += 1
            return _FakeResponse(json.dumps({"result": True}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _counting_urlopen)

        mw = OPARoleCheckMiddleware(cache_ttl_seconds=0.05)  # 50ms
        mw.evaluate(
            method="GET", path="/api/test", jwt_claims={"sub": "u1"}, tenant_cid="t1"
        )
        time.sleep(0.1)  # Wait for expiry
        mw.evaluate(
            method="GET", path="/api/test", jwt_claims={"sub": "u1"}, tenant_cid="t1"
        )

        assert call_count == 2  # Both calls hit OPA

    def test_different_inputs_not_shared(self, monkeypatch):
        """Different inputs should get separate cache entries."""
        call_count = 0

        def _counting_urlopen(_req, timeout=None):
            nonlocal call_count
            call_count += 1
            return _FakeResponse(json.dumps({"result": True}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _counting_urlopen)

        mw = OPARoleCheckMiddleware(cache_ttl_seconds=60.0)
        mw.evaluate(
            method="GET", path="/api/a", jwt_claims={"sub": "u1"}, tenant_cid="t1"
        )
        mw.evaluate(
            method="GET", path="/api/b", jwt_claims={"sub": "u1"}, tenant_cid="t1"
        )

        assert call_count == 2  # Different paths = different cache keys

    def test_clear_cache_empties_all(self, monkeypatch):
        """clear_cache() should force re-fetch on next call."""
        call_count = 0

        def _counting_urlopen(_req, timeout=None):
            nonlocal call_count
            call_count += 1
            return _FakeResponse(json.dumps({"result": True}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _counting_urlopen)

        mw = OPARoleCheckMiddleware(cache_ttl_seconds=60.0)
        mw.evaluate(
            method="GET", path="/api/test", jwt_claims={"sub": "u1"}, tenant_cid="t1"
        )
        mw.clear_cache()
        mw.evaluate(
            method="GET", path="/api/test", jwt_claims={"sub": "u1"}, tenant_cid="t1"
        )

        assert call_count == 2

    def test_cache_bounded_at_max_size(self, monkeypatch):
        """Cache should evict oldest when at max capacity."""
        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            _make_urlopen({"result": True}),
        )

        mw = OPARoleCheckMiddleware(cache_ttl_seconds=60.0)
        # Fill cache beyond _MAX_CACHE_SIZE
        for i in range(mw._MAX_CACHE_SIZE + 10):
            mw.evaluate(
                method="GET",
                path=f"/api/path_{i}",
                jwt_claims={"sub": "u1"},
                tenant_cid="t1",
            )

        assert len(mw._cache) <= mw._MAX_CACHE_SIZE

    def test_cache_disabled_with_zero_ttl(self, monkeypatch):
        """Setting ttl=0 should disable caching entirely."""
        call_count = 0

        def _counting_urlopen(_req, timeout=None):
            nonlocal call_count
            call_count += 1
            return _FakeResponse(json.dumps({"result": True}).encode())

        monkeypatch.setattr(urllib.request, "urlopen", _counting_urlopen)

        mw = OPARoleCheckMiddleware(cache_ttl_seconds=0)
        mw.evaluate(
            method="GET", path="/api/test", jwt_claims={"sub": "u1"}, tenant_cid="t1"
        )
        mw.evaluate(
            method="GET", path="/api/test", jwt_claims={"sub": "u1"}, tenant_cid="t1"
        )

        assert call_count == 2  # No caching

    def test_ttl_from_env_var(self, monkeypatch):
        """OPA_CACHE_TTL_SECONDS env var configures TTL."""
        monkeypatch.setenv("OPA_CACHE_TTL_SECONDS", "120")
        mw = OPARoleCheckMiddleware()
        assert mw.cache_ttl_seconds == 120.0

    def test_ttl_default_30_when_no_env(self, monkeypatch):
        """Default TTL is 30s when no env var and no constructor arg."""
        monkeypatch.delenv("OPA_CACHE_TTL_SECONDS", raising=False)
        mw = OPARoleCheckMiddleware()
        assert mw.cache_ttl_seconds == 30.0

    def test_constructor_arg_overrides_env(self, monkeypatch):
        """Constructor argument takes precedence over env var."""
        monkeypatch.setenv("OPA_CACHE_TTL_SECONDS", "120")
        mw = OPARoleCheckMiddleware(cache_ttl_seconds=5.0)
        assert mw.cache_ttl_seconds == 5.0
