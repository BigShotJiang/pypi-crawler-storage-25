# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""Tests for coreason_ecosystem.auth.vault_transit module.

Covers CrossTenantTransferReceipt model and VaultTransitReEncryptor
including re_encrypt, transfer, and Vault Transit HTTP interactions.
Uses monkeypatch and real fake objects — no unittest.mock.
"""

from __future__ import annotations

import io
import json
import time
from typing import Any

import pytest

from coreason_ecosystem.auth.vault_transit import (
    CrossTenantTransferReceipt,
    VaultTransitReEncryptor,
)


# ---------------------------------------------------------------------------
# Helpers: fake urllib response objects
# ---------------------------------------------------------------------------


class FakeHTTPResponse:
    """Fake response for urllib.request.urlopen that acts as a context manager."""

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = json.dumps(data).encode("utf-8")

    def read(self) -> bytes:
        return self._data

    def __enter__(self) -> "FakeHTTPResponse":
        return self

    def __exit__(self, *args: Any) -> None:
        pass


class FakeHTTPErrorResponse:
    """Fake response that raises on read."""

    def __init__(self, exc: Exception) -> None:
        self._exc = exc

    def read(self) -> bytes:
        raise self._exc

    def __enter__(self) -> "FakeHTTPErrorResponse":
        return self

    def __exit__(self, *args: Any) -> None:
        pass


# ---------------------------------------------------------------------------
# CrossTenantTransferReceipt model tests
# ---------------------------------------------------------------------------


class TestCrossTenantTransferReceipt:
    """Tests for the CrossTenantTransferReceipt pydantic model."""

    def test_receipt_all_fields(self) -> None:
        ts = time.time()
        receipt = CrossTenantTransferReceipt(
            source_tenant_cid="tenant-a",
            target_tenant_cid="tenant-b",
            transfer_hash="abc123",
            re_encryption_key_version=3,
            timestamp=ts,
            authorized_by="admin@coreason.ai",
        )
        assert receipt.source_tenant_cid == "tenant-a"
        assert receipt.target_tenant_cid == "tenant-b"
        assert receipt.transfer_hash == "abc123"
        assert receipt.re_encryption_key_version == 3
        assert receipt.timestamp == ts
        assert receipt.authorized_by == "admin@coreason.ai"

    def test_receipt_defaults(self) -> None:
        receipt = CrossTenantTransferReceipt(
            source_tenant_cid="s",
            target_tenant_cid="t",
            transfer_hash="h",
            timestamp=0.0,
        )
        assert receipt.re_encryption_key_version == 1
        assert receipt.authorized_by == "system"

    def test_receipt_serialization_roundtrip(self) -> None:
        receipt = CrossTenantTransferReceipt(
            source_tenant_cid="a",
            target_tenant_cid="b",
            transfer_hash="deadbeef",
            timestamp=1234567890.0,
        )
        data = receipt.model_dump()
        assert isinstance(data, dict)
        assert data["source_tenant_cid"] == "a"
        assert data["transfer_hash"] == "deadbeef"

        # Roundtrip back
        restored = CrossTenantTransferReceipt(**data)
        assert restored.source_tenant_cid == receipt.source_tenant_cid
        assert restored.transfer_hash == receipt.transfer_hash

    def test_receipt_json_serialization(self) -> None:
        receipt = CrossTenantTransferReceipt(
            source_tenant_cid="x",
            target_tenant_cid="y",
            transfer_hash="fff",
            timestamp=99.9,
        )
        json_str = receipt.model_dump_json()
        assert (
            '"source_tenant_cid":"x"' in json_str
            or '"source_tenant_cid": "x"' in json_str
        )


# ---------------------------------------------------------------------------
# VaultTransitReEncryptor.__init__ tests
# ---------------------------------------------------------------------------


class TestVaultTransitReEncryptorInit:
    """Tests for VaultTransitReEncryptor initialization."""

    def test_explicit_params(self) -> None:
        enc = VaultTransitReEncryptor(
            vault_addr="https://vault.example.com",
            vault_token="s.mytoken",
        )
        assert enc.vault_addr == "https://vault.example.com"
        assert enc.vault_token == "s.mytoken"

    def test_defaults_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("VAULT_ADDR", "http://env-vault:8200")
        monkeypatch.setenv("VAULT_TOKEN", "env-token")

        enc = VaultTransitReEncryptor()
        assert enc.vault_addr == "http://env-vault:8200"
        assert enc.vault_token == "env-token"

    def test_defaults_fallback_missing_token_raises(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Sprint C: vault_token is now required — no more dev-only-token default."""
        monkeypatch.delenv("VAULT_ADDR", raising=False)
        monkeypatch.delenv("VAULT_TOKEN", raising=False)

        with pytest.raises(ValueError, match="vault_token is required"):
            VaultTransitReEncryptor()

    def test_defaults_fallback_addr_only(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Default vault_addr is still http://127.0.0.1:8200."""
        monkeypatch.delenv("VAULT_ADDR", raising=False)
        monkeypatch.setenv("VAULT_TOKEN", "my-token")

        enc = VaultTransitReEncryptor()
        assert enc.vault_addr == "http://127.0.0.1:8200"
        assert enc.vault_token == "my-token"

    def test_explicit_overrides_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("VAULT_ADDR", "http://env-vault:8200")
        monkeypatch.setenv("VAULT_TOKEN", "env-token")

        enc = VaultTransitReEncryptor(
            vault_addr="https://explicit.vault",
            vault_token="explicit-token",
        )
        assert enc.vault_addr == "https://explicit.vault"
        assert enc.vault_token == "explicit-token"

    def test_invalid_url_scheme_ftp_raises(self) -> None:
        """Sprint C: vault_addr must be http:// or https://."""
        with pytest.raises(ValueError, match="http:// or https://"):
            VaultTransitReEncryptor(vault_addr="ftp://vault:8200", vault_token="t")

    def test_invalid_url_scheme_no_scheme_raises(self) -> None:
        with pytest.raises(ValueError, match="http:// or https://"):
            VaultTransitReEncryptor(vault_addr="vault:8200", vault_token="t")

    def test_valid_http_scheme(self) -> None:
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")
        assert enc.vault_addr == "http://v:8200"

    def test_valid_https_scheme(self) -> None:
        enc = VaultTransitReEncryptor(vault_addr="https://v:8200", vault_token="t")
        assert enc.vault_addr == "https://v:8200"


# ---------------------------------------------------------------------------
# VaultTransitReEncryptor._transit_encrypt / _transit_decrypt tests
# ---------------------------------------------------------------------------


class TestTransitEncryptDecrypt:
    """Tests for the private _transit_encrypt and _transit_decrypt methods."""

    def test_transit_encrypt_success(self, monkeypatch: pytest.MonkeyPatch) -> None:
        enc = VaultTransitReEncryptor(
            vault_addr="http://fake-vault:8200",
            vault_token="test-token",
        )

        captured_requests: list[Any] = []

        def fake_urlopen(req: Any, timeout: float = 5.0) -> FakeHTTPResponse:
            captured_requests.append(req)
            return FakeHTTPResponse({"data": {"ciphertext": "vault:v1:encrypted"}})

        monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

        result = enc._transit_encrypt("my-key", "cGxhaW50ZXh0")
        assert result == "vault:v1:encrypted"

        # Verify request was properly constructed
        assert len(captured_requests) == 1
        req = captured_requests[0]
        assert "/v1/transit/encrypt/my-key" in req.full_url
        assert req.get_header("X-vault-token") == "test-token"
        body = json.loads(req.data.decode())
        assert body["plaintext"] == "cGxhaW50ZXh0"

    def test_transit_encrypt_strips_trailing_slash(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        enc = VaultTransitReEncryptor(
            vault_addr="http://fake-vault:8200/",
            vault_token="t",
        )

        def fake_urlopen(req: Any, timeout: float = 5.0) -> FakeHTTPResponse:
            # Should not have double slash
            assert "//" not in req.full_url.replace("http://", "")
            return FakeHTTPResponse({"data": {"ciphertext": "vault:v1:c"}})

        monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)
        enc._transit_encrypt("key", "data")

    def test_transit_encrypt_non_string_ciphertext_raises(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        def fake_urlopen(req: Any, timeout: float = 5.0) -> FakeHTTPResponse:
            return FakeHTTPResponse({"data": {"ciphertext": 12345}})

        monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

        with pytest.raises(TypeError, match="Expected string ciphertext"):
            enc._transit_encrypt("key", "data")

    def test_transit_decrypt_success(self, monkeypatch: pytest.MonkeyPatch) -> None:
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        captured_requests: list[Any] = []

        def fake_urlopen(req: Any, timeout: float = 5.0) -> FakeHTTPResponse:
            captured_requests.append(req)
            return FakeHTTPResponse({"data": {"plaintext": "cGxhaW50ZXh0"}})

        monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

        result = enc._transit_decrypt("my-key", "vault:v1:ciphertext")
        assert result == "cGxhaW50ZXh0"

        req = captured_requests[0]
        assert "/v1/transit/decrypt/my-key" in req.full_url
        body = json.loads(req.data.decode())
        assert body["ciphertext"] == "vault:v1:ciphertext"

    def test_transit_decrypt_non_string_plaintext_raises(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        def fake_urlopen(req: Any, timeout: float = 5.0) -> FakeHTTPResponse:
            return FakeHTTPResponse({"data": {"plaintext": None}})

        monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

        with pytest.raises(TypeError, match="Expected string plaintext"):
            enc._transit_decrypt("key", "vault:v1:ct")

    def test_transit_encrypt_http_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        def fake_urlopen(req: Any, timeout: float = 5.0) -> Any:
            import urllib.error

            raise urllib.error.HTTPError(
                url=req.full_url,
                code=403,
                msg="permission denied",
                hdrs=None,  # type: ignore[arg-type]
                fp=io.BytesIO(b"forbidden"),
            )

        monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

        with pytest.raises(Exception):
            enc._transit_encrypt("key", "data")

    def test_transit_decrypt_http_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        def fake_urlopen(req: Any, timeout: float = 5.0) -> Any:
            import urllib.error

            raise urllib.error.URLError("connection refused")

        monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

        with pytest.raises(Exception):
            enc._transit_decrypt("key", "vault:v1:ct")


# ---------------------------------------------------------------------------
# VaultTransitReEncryptor.re_encrypt tests
# ---------------------------------------------------------------------------


class TestReEncrypt:
    """Tests for re_encrypt method (decrypt source, encrypt target)."""

    def test_re_encrypt_happy_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        call_log: list[str] = []

        def fake_urlopen(req: Any, timeout: float = 5.0) -> FakeHTTPResponse:
            url = req.full_url
            call_log.append(url)
            if "decrypt" in url:
                return FakeHTTPResponse({"data": {"plaintext": "dGVzdA=="}})
            else:
                return FakeHTTPResponse({"data": {"ciphertext": "vault:v1:new-ct"}})

        monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

        result = enc.re_encrypt(
            ciphertext="vault:v1:old-ct",
            source_key_name="source-key",
            target_key_name="target-key",
        )
        assert result == "vault:v1:new-ct"
        assert len(call_log) == 2
        assert "decrypt/source-key" in call_log[0]
        assert "encrypt/target-key" in call_log[1]

    def test_re_encrypt_decrypt_failure_propagates(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        def fake_urlopen(req: Any, timeout: float = 5.0) -> Any:
            raise ConnectionError("vault unreachable")

        monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

        with pytest.raises(ConnectionError, match="vault unreachable"):
            enc.re_encrypt("vault:v1:ct", "src", "tgt")

    def test_re_encrypt_encrypt_failure_propagates(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        call_count = 0

        def fake_urlopen(req: Any, timeout: float = 5.0) -> Any:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # Decrypt succeeds
                return FakeHTTPResponse({"data": {"plaintext": "cGxhaW50ZXh0"}})
            # Encrypt fails
            raise ConnectionError("vault down on encrypt")

        monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

        with pytest.raises(ConnectionError, match="vault down on encrypt"):
            enc.re_encrypt("vault:v1:ct", "src", "tgt")


# ---------------------------------------------------------------------------
# VaultTransitReEncryptor.transfer tests
# ---------------------------------------------------------------------------


class TestTransfer:
    """Tests for the transfer method with cross-tenant authorization."""

    def test_transfer_happy_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COREASON_CROSS_TENANT_ENABLED", "true")

        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        receipt = enc.transfer(
            payload={"key": "value", "number": 42},
            source_tenant_cid="tenant-a",
            target_tenant_cid="tenant-b",
            authorized_by="admin",
        )

        assert isinstance(receipt, CrossTenantTransferReceipt)
        assert receipt.source_tenant_cid == "tenant-a"
        assert receipt.target_tenant_cid == "tenant-b"
        assert receipt.authorized_by == "admin"
        assert len(receipt.transfer_hash) == 64  # SHA-256 hex
        assert receipt.timestamp > 0

    def test_transfer_deterministic_hash(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COREASON_CROSS_TENANT_ENABLED", "true")
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        receipt1 = enc.transfer(
            payload={"a": 1, "b": 2},
            source_tenant_cid="s",
            target_tenant_cid="t",
        )
        receipt2 = enc.transfer(
            payload={"b": 2, "a": 1},  # Different key order, same content
            source_tenant_cid="s",
            target_tenant_cid="t",
        )
        # sort_keys=True means same payload => same hash
        assert receipt1.transfer_hash == receipt2.transfer_hash

    def test_transfer_different_payloads_different_hashes(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("COREASON_CROSS_TENANT_ENABLED", "true")
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        receipt1 = enc.transfer(
            payload={"x": 1}, source_tenant_cid="s", target_tenant_cid="t"
        )
        receipt2 = enc.transfer(
            payload={"x": 2}, source_tenant_cid="s", target_tenant_cid="t"
        )
        assert receipt1.transfer_hash != receipt2.transfer_hash

    def test_transfer_same_tenant_raises_value_error(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("COREASON_CROSS_TENANT_ENABLED", "true")
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        with pytest.raises(ValueError, match="different source and target"):
            enc.transfer(
                payload={"data": "test"},
                source_tenant_cid="same-tenant",
                target_tenant_cid="same-tenant",
            )

    def test_transfer_prohibited_by_default(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("COREASON_CROSS_TENANT_ENABLED", raising=False)
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        with pytest.raises(PermissionError, match="prohibited"):
            enc.transfer(
                payload={"data": "test"},
                source_tenant_cid="a",
                target_tenant_cid="b",
            )

    def test_transfer_prohibited_when_false(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("COREASON_CROSS_TENANT_ENABLED", "false")
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        with pytest.raises(PermissionError, match="prohibited"):
            enc.transfer(
                payload={"data": "test"},
                source_tenant_cid="a",
                target_tenant_cid="b",
            )

    def test_transfer_prohibited_when_env_is_not_true(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("COREASON_CROSS_TENANT_ENABLED", "yes")
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        with pytest.raises(PermissionError, match="prohibited"):
            enc.transfer(
                payload={},
                source_tenant_cid="a",
                target_tenant_cid="b",
            )

    def test_transfer_enabled_case_insensitive(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("COREASON_CROSS_TENANT_ENABLED", "True")
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        receipt = enc.transfer(
            payload={"data": "test"},
            source_tenant_cid="a",
            target_tenant_cid="b",
        )
        assert isinstance(receipt, CrossTenantTransferReceipt)

    def test_transfer_enabled_uppercase(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COREASON_CROSS_TENANT_ENABLED", "TRUE")
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        receipt = enc.transfer(
            payload={"data": "test"},
            source_tenant_cid="x",
            target_tenant_cid="y",
        )
        assert isinstance(receipt, CrossTenantTransferReceipt)

    def test_transfer_default_authorized_by(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("COREASON_CROSS_TENANT_ENABLED", "true")
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        receipt = enc.transfer(
            payload={"x": 1},
            source_tenant_cid="a",
            target_tenant_cid="b",
        )
        assert receipt.authorized_by == "system"

    def test_transfer_empty_payload(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COREASON_CROSS_TENANT_ENABLED", "true")
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        receipt = enc.transfer(payload={}, source_tenant_cid="a", target_tenant_cid="b")
        assert len(receipt.transfer_hash) == 64

    def test_transfer_complex_payload(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COREASON_CROSS_TENANT_ENABLED", "true")
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        payload = {
            "nested": {"key": [1, 2, 3]},
            "unicode": "héllo wörld",
            "number": 3.14,
            "null": None,
            "bool": True,
        }
        receipt = enc.transfer(
            payload=payload, source_tenant_cid="a", target_tenant_cid="b"
        )
        assert len(receipt.transfer_hash) == 64

    def test_transfer_value_error_before_permission_check(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """ValueError for same tenant is checked before permission check."""
        monkeypatch.delenv("COREASON_CROSS_TENANT_ENABLED", raising=False)
        enc = VaultTransitReEncryptor(vault_addr="http://v:8200", vault_token="t")

        with pytest.raises(ValueError, match="different source and target"):
            enc.transfer(
                payload={},
                source_tenant_cid="same",
                target_tenant_cid="same",
            )
