# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-ecosystem

"""Unit tests for OpenShell Translator Sidecar using dependency injection."""

import json
import pytest
from typing import Any

from nats.aio.msg import Msg
from coreason_ecosystem.wasmcloud.openshell_translator_sidecar import (
    OpenShellSidecarTranslator,
)


class FakeMsg(Msg):
    """Fake NATS message implementation for deterministic unit testing."""

    def __init__(self, data: bytes, reply: str = "") -> None:
        self.data = data
        self.reply = reply


class FakeNatsClient:
    """Fake NATS client for capturing published messages without socket communication."""

    def __init__(self) -> None:
        self.published: list[tuple[str, bytes]] = []

    async def publish(self, subject: str, payload: bytes) -> None:
        """Capture published subject and message payload."""
        self.published.append((subject, payload))


class FakeHTTPResponse:
    """Fake HTTP response mimicking httpx.Response behavior."""

    def __init__(self, status_code: int, json_data: Any) -> None:
        self.status_code = status_code
        self._json_data = json_data

    def json(self) -> Any:
        """Retrieve simulated JSON payload."""
        if isinstance(self._json_data, Exception):
            raise self._json_data
        return self._json_data


class FakeHTTPClient:
    """Fake HTTP client to record outgoing POST requests and supply pre-configured responses."""

    def __init__(self, status_code: int, json_data: Any) -> None:
        self.status_code = status_code
        self.json_data = json_data
        self.posts: list[tuple[str, Any]] = []

    async def post(
        self, url: str, json: Any, headers: Any, timeout: float
    ) -> FakeHTTPResponse:
        """Log the URL and JSON payload, returning the pre-configured response."""
        self.posts.append((url, json))
        return FakeHTTPResponse(self.status_code, self.json_data)


@pytest.mark.asyncio
async def test_translator_success() -> None:
    """Verify translator successfully maps a valid JSON-RPC request to OpenShell and back."""
    fake_nats = FakeNatsClient()
    fake_http = FakeHTTPClient(
        status_code=200, json_data={"execution_result": "success"}
    )

    translator = OpenShellSidecarTranslator(
        nats_url="nats://localhost:4222",
        openshell_url="http://openshell:8080",
        nats_client=fake_nats,
        http_client=fake_http,
    )

    request_payload = {
        "jsonrpc": "2.0",
        "method": "coreason.tool.some_tool.invoke",
        "params": {
            "name": "some_tool",
            "arguments": {"script": "print('hello')"},
            "security_context": {
                "authorized": True,
                "spiffe_id": "spiffe://coreason.ai/ns/default/sa/runtime",
                "verified_capability_receipt": "vcr_valid_mock_receipt",
            },
        },
        "id": 123,
    }

    msg = FakeMsg(
        data=json.dumps(request_payload).encode("utf-8"), reply="reply.subject"
    )

    await translator.handle_message(msg)

    # Check HTTP post parameters
    assert len(fake_http.posts) == 1
    url, post_body = fake_http.posts[0]
    assert url == "http://openshell:8080/v1/mcp/execute"
    assert post_body["script_payload"] == "print('hello')"
    assert post_body["security_context"]["authorized"] is True
    assert (
        post_body["security_context"]["spiffe_id"]
        == "spiffe://coreason.ai/ns/default/sa/runtime"
    )
    assert (
        post_body["security_context"]["verified_capability_receipt"]
        == "vcr_valid_mock_receipt"
    )

    # Check NATS reply message
    assert len(fake_nats.published) == 1
    subject, response_bytes = fake_nats.published[0]
    assert subject == "reply.subject"

    response = json.loads(response_bytes.decode("utf-8"))
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == 123
    assert response["result"]["execution_result"] == "success"


@pytest.mark.asyncio
async def test_translator_invalid_json() -> None:
    """Verify translator handles malformed JSON input with a parsing error response."""
    fake_nats = FakeNatsClient()
    fake_http = FakeHTTPClient(status_code=200, json_data={})

    translator = OpenShellSidecarTranslator(
        nats_url="nats://localhost:4222",
        openshell_url="http://openshell:8080",
        nats_client=fake_nats,
        http_client=fake_http,
    )

    msg = FakeMsg(data=b"invalid json data", reply="reply.subject")

    await translator.handle_message(msg)

    # No HTTP post should be triggered
    assert len(fake_http.posts) == 0

    assert len(fake_nats.published) == 1
    subject, response_bytes = fake_nats.published[0]
    assert subject == "reply.subject"

    response = json.loads(response_bytes.decode("utf-8"))
    assert response["jsonrpc"] == "2.0"
    assert response["id"] is None
    assert response["error"]["code"] == -32600


@pytest.mark.asyncio
async def test_translator_missing_script() -> None:
    """Verify translator handles missing script parameter with an invalid payload structure response."""
    fake_nats = FakeNatsClient()
    fake_http = FakeHTTPClient(status_code=200, json_data={})

    translator = OpenShellSidecarTranslator(
        nats_url="nats://localhost:4222",
        openshell_url="http://openshell:8080",
        nats_client=fake_nats,
        http_client=fake_http,
    )

    request_payload = {
        "jsonrpc": "2.0",
        "method": "coreason.tool.some_tool.invoke",
        "params": {
            "name": "some_tool",
            "arguments": {},  # Missing "script"
        },
        "id": 456,
    }

    msg = FakeMsg(
        data=json.dumps(request_payload).encode("utf-8"), reply="reply.subject"
    )

    await translator.handle_message(msg)

    assert len(fake_http.posts) == 0

    assert len(fake_nats.published) == 1
    subject, response_bytes = fake_nats.published[0]
    assert subject == "reply.subject"

    response = json.loads(response_bytes.decode("utf-8"))
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == 456
    assert response["error"]["code"] == -32600
    assert "Invalid JSON-RPC payload structure" in response["error"]["message"]


@pytest.mark.asyncio
async def test_translator_openshell_non_200() -> None:
    """Verify translator maps non-200 OpenShell response to an internal error response."""
    fake_nats = FakeNatsClient()
    fake_http = FakeHTTPClient(status_code=500, json_data={"error": "failed"})

    translator = OpenShellSidecarTranslator(
        nats_url="nats://localhost:4222",
        openshell_url="http://openshell:8080",
        nats_client=fake_nats,
        http_client=fake_http,
    )

    request_payload = {
        "jsonrpc": "2.0",
        "method": "coreason.tool.some_tool.invoke",
        "params": {
            "name": "some_tool",
            "arguments": {"script": "print('hello')"},
            "security_context": {
                "authorized": True,
                "spiffe_id": "spiffe://coreason.ai/ns/default/sa/runtime",
                "verified_capability_receipt": "vcr_valid_mock_receipt",
            },
        },
        "id": 789,
    }

    msg = FakeMsg(
        data=json.dumps(request_payload).encode("utf-8"), reply="reply.subject"
    )

    await translator.handle_message(msg)

    assert len(fake_http.posts) == 1

    assert len(fake_nats.published) == 1
    subject, response_bytes = fake_nats.published[0]
    assert subject == "reply.subject"

    response = json.loads(response_bytes.decode("utf-8"))
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == 789
    assert response["error"]["code"] == -32603
    assert "OpenShell returned non-200 status: 500" in response["error"]["message"]


# ---------------------------------------------------------------------------
# Epic 0: Security Denial Tests (#263)
# ---------------------------------------------------------------------------


def _make_translator() -> tuple[
    OpenShellSidecarTranslator, FakeNatsClient, FakeHTTPClient
]:
    """Create a translator instance with fake dependencies."""
    nats = FakeNatsClient()
    http = FakeHTTPClient(status_code=200, json_data={})
    translator = OpenShellSidecarTranslator(
        nats_url="nats://localhost:4222",
        openshell_url="http://openshell:8080",
        nats_client=nats,
        http_client=http,
    )
    return translator, nats, http


@pytest.mark.asyncio
async def test_translator_security_denied_no_context() -> None:
    """Reject requests with no security_context at all."""
    translator, nats, http = _make_translator()

    request_payload = {
        "jsonrpc": "2.0",
        "method": "coreason.tool.some_tool.invoke",
        "params": {"name": "some_tool", "arguments": {"script": "print('pwned')"}},
        "id": 900,
    }

    msg = FakeMsg(
        data=json.dumps(request_payload).encode("utf-8"), reply="reply.subject"
    )
    await translator.handle_message(msg)

    assert len(http.posts) == 0
    assert len(nats.published) == 1
    response = json.loads(nats.published[0][1].decode("utf-8"))
    assert response["error"]["code"] == -32001
    assert "unauthorized" in response["error"]["message"].lower()


@pytest.mark.asyncio
async def test_translator_security_denied_unauthorized() -> None:
    """Reject requests where authorized is explicitly False."""
    translator, nats, http = _make_translator()

    request_payload = {
        "jsonrpc": "2.0",
        "method": "coreason.tool.some_tool.invoke",
        "params": {
            "name": "some_tool",
            "arguments": {"script": "print('pwned')"},
            "security_context": {
                "authorized": False,
                "spiffe_id": "spiffe://coreason.ai/ns/default/sa/runtime",
                "verified_capability_receipt": "vcr_receipt",
            },
        },
        "id": 901,
    }

    msg = FakeMsg(
        data=json.dumps(request_payload).encode("utf-8"), reply="reply.subject"
    )
    await translator.handle_message(msg)

    assert len(http.posts) == 0
    response = json.loads(nats.published[0][1].decode("utf-8"))
    assert response["error"]["code"] == -32001


@pytest.mark.asyncio
async def test_translator_security_denied_bad_spiffe() -> None:
    """Reject requests with SPIFFE ID outside the coreason.ai trust domain."""
    translator, nats, http = _make_translator()

    request_payload = {
        "jsonrpc": "2.0",
        "method": "coreason.tool.some_tool.invoke",
        "params": {
            "name": "some_tool",
            "arguments": {"script": "print('pwned')"},
            "security_context": {
                "authorized": True,
                "spiffe_id": "spiffe://evil.com/ns/attacker/sa/root",
                "verified_capability_receipt": "vcr_receipt",
            },
        },
        "id": 902,
    }

    msg = FakeMsg(
        data=json.dumps(request_payload).encode("utf-8"), reply="reply.subject"
    )
    await translator.handle_message(msg)

    assert len(http.posts) == 0
    response = json.loads(nats.published[0][1].decode("utf-8"))
    assert response["error"]["code"] == -32002
    assert "SPIFFE" in response["error"]["message"]


@pytest.mark.asyncio
async def test_translator_security_denied_missing_receipt() -> None:
    """Reject requests that lack a VerifiedCapabilityReceipt."""
    translator, nats, http = _make_translator()

    request_payload = {
        "jsonrpc": "2.0",
        "method": "coreason.tool.some_tool.invoke",
        "params": {
            "name": "some_tool",
            "arguments": {"script": "print('pwned')"},
            "security_context": {
                "authorized": True,
                "spiffe_id": "spiffe://coreason.ai/ns/default/sa/runtime",
                # No verified_capability_receipt!
            },
        },
        "id": 903,
    }

    msg = FakeMsg(
        data=json.dumps(request_payload).encode("utf-8"), reply="reply.subject"
    )
    await translator.handle_message(msg)

    assert len(http.posts) == 0
    response = json.loads(nats.published[0][1].decode("utf-8"))
    assert response["error"]["code"] == -32003
    assert "VerifiedCapabilityReceipt" in response["error"]["message"]
