# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""Tests for coreason_ecosystem.orchestration.cost_tracker module.

Covers ThermodynamicCostRecord model and ThermodynamicCostTracker
including record_cost, budget enforcement, get_tenant_total,
get_tenant_records, get_summary, and the POSTGRES_SCHEMA constant.
Uses real objects and fixture-based testing — no unittest.mock.
"""

from __future__ import annotations

import time

import pytest

from coreason_ecosystem.orchestration.cost_tracker import (
    ThermodynamicCostRecord,
    ThermodynamicCostTracker,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def tracker() -> ThermodynamicCostTracker:
    """A cost tracker with default $100 budget."""
    return ThermodynamicCostTracker()


@pytest.fixture
def low_budget_tracker() -> ThermodynamicCostTracker:
    """A cost tracker with a tight $1 budget."""
    return ThermodynamicCostTracker(budget_limit_usd=1.0)


@pytest.fixture
def sample_record() -> ThermodynamicCostRecord:
    return ThermodynamicCostRecord(
        tenant_cid="tenant-a",
        workflow_id="wf-001",
        agent_cid="agent-1",
        input_tokens=100,
        output_tokens=50,
        total_tokens=150,
        cost_usd=0.015,
        gpu_seconds=1.5,
    )


# ---------------------------------------------------------------------------
# ThermodynamicCostRecord model tests
# ---------------------------------------------------------------------------


class TestThermodynamicCostRecord:
    """Tests for the ThermodynamicCostRecord pydantic model."""

    def test_all_fields(self) -> None:
        ts = time.time()
        record = ThermodynamicCostRecord(
            tenant_cid="t1",
            workflow_id="wf-1",
            agent_cid="agent-1",
            input_tokens=100,
            output_tokens=50,
            total_tokens=150,
            cost_usd=0.01,
            gpu_seconds=2.5,
            timestamp=ts,
        )
        assert record.tenant_cid == "t1"
        assert record.workflow_id == "wf-1"
        assert record.agent_cid == "agent-1"
        assert record.input_tokens == 100
        assert record.output_tokens == 50
        assert record.total_tokens == 150
        assert record.cost_usd == 0.01
        assert record.gpu_seconds == 2.5
        assert record.timestamp == ts

    def test_defaults(self) -> None:
        record = ThermodynamicCostRecord(
            tenant_cid="t1",
            workflow_id="wf-1",
        )
        assert record.agent_cid == ""
        assert record.input_tokens == 0
        assert record.output_tokens == 0
        assert record.total_tokens == 0
        assert record.cost_usd == 0.0
        assert record.gpu_seconds == 0.0
        assert record.timestamp > 0  # default_factory=time.time

    def test_timestamp_default_factory_varies(self) -> None:
        r1 = ThermodynamicCostRecord(tenant_cid="t", workflow_id="w")
        # Small sleep not needed — just verify timestamp is a positive float
        r2 = ThermodynamicCostRecord(tenant_cid="t", workflow_id="w")
        assert r1.timestamp > 0
        assert r2.timestamp >= r1.timestamp

    def test_serialization_roundtrip(self) -> None:
        record = ThermodynamicCostRecord(
            tenant_cid="t1",
            workflow_id="wf-1",
            cost_usd=0.05,
        )
        data = record.model_dump()
        restored = ThermodynamicCostRecord(**data)
        assert restored.tenant_cid == record.tenant_cid
        assert restored.cost_usd == record.cost_usd

    def test_zero_cost_record(self) -> None:
        record = ThermodynamicCostRecord(
            tenant_cid="t",
            workflow_id="wf",
            cost_usd=0.0,
        )
        assert record.cost_usd == 0.0


# ---------------------------------------------------------------------------
# ThermodynamicCostTracker.__init__ tests
# ---------------------------------------------------------------------------


class TestCostTrackerInit:
    """Tests for ThermodynamicCostTracker initialization."""

    def test_default_budget(self) -> None:
        tracker = ThermodynamicCostTracker()
        assert tracker.budget_limit_usd == 100.0

    def test_custom_budget(self) -> None:
        tracker = ThermodynamicCostTracker(budget_limit_usd=50.0)
        assert tracker.budget_limit_usd == 50.0

    def test_zero_budget(self) -> None:
        tracker = ThermodynamicCostTracker(budget_limit_usd=0.0)
        assert tracker.budget_limit_usd == 0.0

    def test_postgres_schema_exists(self) -> None:
        """Verify the SQL schema constant is present and well-formed."""
        assert "CREATE TABLE" in ThermodynamicCostTracker.POSTGRES_SCHEMA
        assert "thermodynamic_costs" in ThermodynamicCostTracker.POSTGRES_SCHEMA
        assert "tenant_cid" in ThermodynamicCostTracker.POSTGRES_SCHEMA
        assert "CREATE INDEX" in ThermodynamicCostTracker.POSTGRES_SCHEMA
        assert "MATERIALIZED VIEW" in ThermodynamicCostTracker.POSTGRES_SCHEMA


# ---------------------------------------------------------------------------
# ThermodynamicCostTracker.record_cost tests
# ---------------------------------------------------------------------------


class TestRecordCost:
    """Tests for the record_cost method with budget enforcement."""

    def test_record_single_cost(
        self, tracker: ThermodynamicCostTracker, sample_record: ThermodynamicCostRecord
    ) -> None:
        tracker.record_cost(sample_record)
        assert tracker.get_tenant_total("tenant-a") == 0.015

    def test_record_multiple_costs_same_tenant(
        self, tracker: ThermodynamicCostTracker
    ) -> None:
        for i in range(5):
            record = ThermodynamicCostRecord(
                tenant_cid="t1",
                workflow_id=f"wf-{i}",
                cost_usd=10.0,
            )
            tracker.record_cost(record)
        assert tracker.get_tenant_total("t1") == 50.0

    def test_record_different_tenants(self, tracker: ThermodynamicCostTracker) -> None:
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="a", workflow_id="w1", cost_usd=30.0)
        )
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="b", workflow_id="w2", cost_usd=40.0)
        )
        assert tracker.get_tenant_total("a") == 30.0
        assert tracker.get_tenant_total("b") == 40.0

    def test_budget_exceeded_raises(
        self, low_budget_tracker: ThermodynamicCostTracker
    ) -> None:
        low_budget_tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t", workflow_id="w1", cost_usd=0.8)
        )
        with pytest.raises(PermissionError, match="budget exceeded"):
            low_budget_tracker.record_cost(
                ThermodynamicCostRecord(tenant_cid="t", workflow_id="w2", cost_usd=0.3)
            )

    def test_budget_exactly_at_limit(
        self, low_budget_tracker: ThermodynamicCostTracker
    ) -> None:
        """Cost exactly at limit should still be allowed (not > limit)."""
        low_budget_tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t", workflow_id="w1", cost_usd=1.0)
        )
        assert low_budget_tracker.get_tenant_total("t") == 1.0

    def test_budget_exceeded_does_not_add_record(
        self, low_budget_tracker: ThermodynamicCostTracker
    ) -> None:
        low_budget_tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t", workflow_id="w1", cost_usd=0.9)
        )
        with pytest.raises(PermissionError):
            low_budget_tracker.record_cost(
                ThermodynamicCostRecord(tenant_cid="t", workflow_id="w2", cost_usd=0.2)
            )
        # Record should NOT have been added
        assert low_budget_tracker.get_tenant_total("t") == 0.9
        records = low_budget_tracker.get_tenant_records("t")
        assert len(records) == 1

    def test_zero_cost_record_always_allowed(
        self, low_budget_tracker: ThermodynamicCostTracker
    ) -> None:
        low_budget_tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t", workflow_id="w1", cost_usd=1.0)
        )
        # Zero cost should be fine even at limit
        low_budget_tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t", workflow_id="w2", cost_usd=0.0)
        )
        assert low_budget_tracker.get_tenant_total("t") == 1.0

    def test_budget_exceeded_error_message_format(
        self, low_budget_tracker: ThermodynamicCostTracker
    ) -> None:
        with pytest.raises(PermissionError, match=r"\$1\.5000 > \$1\.00 limit"):
            low_budget_tracker.record_cost(
                ThermodynamicCostRecord(tenant_cid="t", workflow_id="w", cost_usd=1.5)
            )

    def test_zero_budget_rejects_any_cost(self) -> None:
        tracker = ThermodynamicCostTracker(budget_limit_usd=0.0)
        with pytest.raises(PermissionError, match="budget exceeded"):
            tracker.record_cost(
                ThermodynamicCostRecord(tenant_cid="t", workflow_id="w", cost_usd=0.001)
            )

    def test_multiple_tenants_independent_budgets(
        self, low_budget_tracker: ThermodynamicCostTracker
    ) -> None:
        """Each tenant has their own budget limit."""
        low_budget_tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="a", workflow_id="w1", cost_usd=0.9)
        )
        # Tenant "b" should still be within budget
        low_budget_tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="b", workflow_id="w2", cost_usd=0.9)
        )
        assert low_budget_tracker.get_tenant_total("a") == 0.9
        assert low_budget_tracker.get_tenant_total("b") == 0.9


# ---------------------------------------------------------------------------
# ThermodynamicCostTracker.get_tenant_total tests
# ---------------------------------------------------------------------------


class TestGetTenantTotal:
    """Tests for the get_tenant_total method."""

    def test_unknown_tenant(self, tracker: ThermodynamicCostTracker) -> None:
        assert tracker.get_tenant_total("nonexistent") == 0.0

    def test_accumulated_total(self, tracker: ThermodynamicCostTracker) -> None:
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t", workflow_id="w1", cost_usd=1.0)
        )
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t", workflow_id="w2", cost_usd=2.5)
        )
        assert tracker.get_tenant_total("t") == pytest.approx(3.5)


# ---------------------------------------------------------------------------
# ThermodynamicCostTracker.get_tenant_records tests
# ---------------------------------------------------------------------------


class TestGetTenantRecords:
    """Tests for the get_tenant_records method."""

    def test_no_records(self, tracker: ThermodynamicCostTracker) -> None:
        assert tracker.get_tenant_records("t") == []

    def test_returns_correct_records(self, tracker: ThermodynamicCostTracker) -> None:
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="a", workflow_id="w1", cost_usd=1.0)
        )
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="b", workflow_id="w2", cost_usd=2.0)
        )
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="a", workflow_id="w3", cost_usd=3.0)
        )

        records_a = tracker.get_tenant_records("a")
        assert len(records_a) == 2
        assert all(r.tenant_cid == "a" for r in records_a)

        records_b = tracker.get_tenant_records("b")
        assert len(records_b) == 1
        assert records_b[0].workflow_id == "w2"

    def test_record_order_preserved(self, tracker: ThermodynamicCostTracker) -> None:
        for i in range(3):
            tracker.record_cost(
                ThermodynamicCostRecord(
                    tenant_cid="t", workflow_id=f"wf-{i}", cost_usd=0.01
                )
            )
        records = tracker.get_tenant_records("t")
        assert [r.workflow_id for r in records] == ["wf-0", "wf-1", "wf-2"]


# ---------------------------------------------------------------------------
# ThermodynamicCostTracker.get_summary tests
# ---------------------------------------------------------------------------


class TestGetSummary:
    """Tests for the get_summary method."""

    def test_empty_summary(self, tracker: ThermodynamicCostTracker) -> None:
        assert tracker.get_summary() == {}

    def test_single_tenant_summary(self, tracker: ThermodynamicCostTracker) -> None:
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t1", workflow_id="w1", cost_usd=10.0)
        )
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t1", workflow_id="w2", cost_usd=5.0)
        )

        summary = tracker.get_summary()
        assert "t1" in summary
        assert summary["t1"]["total_cost_usd"] == 15.0
        assert summary["t1"]["budget_remaining_usd"] == 85.0
        assert summary["t1"]["invocations"] == 2

    def test_multi_tenant_summary(self, tracker: ThermodynamicCostTracker) -> None:
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="a", workflow_id="w1", cost_usd=20.0)
        )
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="b", workflow_id="w2", cost_usd=30.0)
        )

        summary = tracker.get_summary()
        assert len(summary) == 2
        assert summary["a"]["total_cost_usd"] == 20.0
        assert summary["a"]["budget_remaining_usd"] == 80.0
        assert summary["a"]["invocations"] == 1
        assert summary["b"]["total_cost_usd"] == 30.0

    def test_summary_budget_remaining_correct(self) -> None:
        tracker = ThermodynamicCostTracker(budget_limit_usd=50.0)
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t", workflow_id="w", cost_usd=12.5)
        )
        summary = tracker.get_summary()
        assert summary["t"]["budget_remaining_usd"] == pytest.approx(37.5)

    def test_summary_zero_cost(self, tracker: ThermodynamicCostTracker) -> None:
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t", workflow_id="w", cost_usd=0.0)
        )
        summary = tracker.get_summary()
        assert summary["t"]["total_cost_usd"] == 0.0
        assert summary["t"]["budget_remaining_usd"] == 100.0
        assert summary["t"]["invocations"] == 1


# ---------------------------------------------------------------------------
# Sprint C: Negative cost validation tests
# ---------------------------------------------------------------------------


class TestNegativeCostRejection:
    """Tests for negative cost_usd rejection (Sprint C: C1.2)."""

    def test_negative_cost_raises_value_error(
        self, tracker: ThermodynamicCostTracker
    ) -> None:
        with pytest.raises(ValueError, match="non-negative"):
            tracker.record_cost(
                ThermodynamicCostRecord(tenant_cid="t", workflow_id="w", cost_usd=-0.01)
            )

    def test_large_negative_cost_raises(
        self, tracker: ThermodynamicCostTracker
    ) -> None:
        with pytest.raises(ValueError, match="non-negative"):
            tracker.record_cost(
                ThermodynamicCostRecord(
                    tenant_cid="t", workflow_id="w", cost_usd=-100.0
                )
            )

    def test_negative_cost_does_not_modify_state(
        self, tracker: ThermodynamicCostTracker
    ) -> None:
        """Negative cost should not affect tenant totals or records."""
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t", workflow_id="w1", cost_usd=5.0)
        )
        with pytest.raises(ValueError):
            tracker.record_cost(
                ThermodynamicCostRecord(tenant_cid="t", workflow_id="w2", cost_usd=-1.0)
            )
        assert tracker.get_tenant_total("t") == 5.0
        assert len(tracker.get_tenant_records("t")) == 1

    def test_zero_cost_accepted(self, tracker: ThermodynamicCostTracker) -> None:
        """Zero cost should be allowed — it's non-negative."""
        tracker.record_cost(
            ThermodynamicCostRecord(tenant_cid="t", workflow_id="w", cost_usd=0.0)
        )
        assert tracker.get_tenant_total("t") == 0.0
