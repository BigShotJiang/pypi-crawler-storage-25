# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""Tests for coreason_ecosystem.orchestration.capability_ledger module.

Covers CapabilityLedgerEntry model and CapabilityLedger class including
register, lookup, check_access, list_capabilities, and to_dict.
Uses real objects and fixture-based testing — no unittest.mock.
"""

from __future__ import annotations

import pytest

from coreason_ecosystem.orchestration.capability_ledger import (
    CapabilityLedger,
    CapabilityLedgerEntry,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def free_entry() -> CapabilityLedgerEntry:
    """A free-tier, prosperity-licensed capability."""
    return CapabilityLedgerEntry(
        capability_urn="urn:coreason:solver:basic",
        oci_uri="ghcr.io/coreason-ai/solver-basic:latest",
        license_class="prosperity-3.0",
        minimum_tier="free",
        cost_per_invocation=0.0,
    )


@pytest.fixture
def standard_entry() -> CapabilityLedgerEntry:
    """A standard-tier, prosperity-licensed capability."""
    return CapabilityLedgerEntry(
        capability_urn="urn:coreason:solver:advanced",
        oci_uri="ghcr.io/coreason-ai/solver-advanced:latest",
        license_class="prosperity-3.0",
        minimum_tier="standard",
        cost_per_invocation=0.01,
    )


@pytest.fixture
def enterprise_commercial_entry() -> CapabilityLedgerEntry:
    """An enterprise-tier, commercially-licensed capability."""
    return CapabilityLedgerEntry(
        capability_urn="urn:coreason:solver:enterprise",
        oci_uri="ghcr.io/coreason-ai/solver-enterprise:latest",
        license_class="commercial",
        minimum_tier="enterprise",
        cost_per_invocation=0.10,
        authorized_signer_did="did:web:coreason.ai",
    )


@pytest.fixture
def research_entry() -> CapabilityLedgerEntry:
    """A research-licensed capability."""
    return CapabilityLedgerEntry(
        capability_urn="urn:coreason:solver:research",
        oci_uri="ghcr.io/coreason-ai/solver-research:latest",
        license_class="research",
        minimum_tier="free",
        cost_per_invocation=0.0,
    )


@pytest.fixture
def ledger(
    free_entry: CapabilityLedgerEntry,
    standard_entry: CapabilityLedgerEntry,
    enterprise_commercial_entry: CapabilityLedgerEntry,
    research_entry: CapabilityLedgerEntry,
) -> CapabilityLedger:
    """A pre-populated ledger with all entry types."""
    ledger = CapabilityLedger()
    ledger.register(free_entry)
    ledger.register(standard_entry)
    ledger.register(enterprise_commercial_entry)
    ledger.register(research_entry)
    return ledger


# ---------------------------------------------------------------------------
# CapabilityLedgerEntry model tests
# ---------------------------------------------------------------------------


class TestCapabilityLedgerEntry:
    """Tests for the CapabilityLedgerEntry pydantic model."""

    def test_all_fields(self) -> None:
        entry = CapabilityLedgerEntry(
            capability_urn="urn:coreason:solver:test",
            oci_uri="ghcr.io/test:v1",
            license_class="commercial",
            minimum_tier="enterprise",
            cost_per_invocation=1.5,
            authorized_signer_did="did:web:example.com",
        )
        assert entry.capability_urn == "urn:coreason:solver:test"
        assert entry.oci_uri == "ghcr.io/test:v1"
        assert entry.license_class == "commercial"
        assert entry.minimum_tier == "enterprise"
        assert entry.cost_per_invocation == 1.5
        assert entry.authorized_signer_did == "did:web:example.com"

    def test_defaults(self) -> None:
        entry = CapabilityLedgerEntry(
            capability_urn="urn:coreason:solver:minimal",
            oci_uri="ghcr.io/min:latest",
        )
        assert entry.license_class == "prosperity-3.0"
        assert entry.minimum_tier == "free"
        assert entry.cost_per_invocation == 0.0
        assert entry.authorized_signer_did == ""

    def test_serialization_roundtrip(self) -> None:
        entry = CapabilityLedgerEntry(
            capability_urn="urn:coreason:solver:rt",
            oci_uri="ghcr.io/rt:v2",
            license_class="research",
            minimum_tier="standard",
        )
        data = entry.model_dump()
        restored = CapabilityLedgerEntry(**data)
        assert restored.capability_urn == entry.capability_urn
        assert restored.license_class == entry.license_class

    def test_invalid_license_class_raises(self) -> None:
        with pytest.raises(Exception):  # Pydantic validation error
            CapabilityLedgerEntry(
                capability_urn="urn:test",
                oci_uri="ghcr.io/test",
                license_class="invalid",  # type: ignore[arg-type]
            )

    def test_invalid_minimum_tier_raises(self) -> None:
        with pytest.raises(Exception):  # Pydantic validation error
            CapabilityLedgerEntry(
                capability_urn="urn:test",
                oci_uri="ghcr.io/test",
                minimum_tier="premium",  # type: ignore[arg-type]
            )


# ---------------------------------------------------------------------------
# CapabilityLedger.register / lookup tests
# ---------------------------------------------------------------------------


class TestRegisterAndLookup:
    """Tests for register and lookup methods."""

    def test_register_and_lookup(self, free_entry: CapabilityLedgerEntry) -> None:
        ledger = CapabilityLedger()
        ledger.register(free_entry)
        result = ledger.lookup("urn:coreason:solver:basic")
        assert result is not None
        assert result.capability_urn == "urn:coreason:solver:basic"

    def test_lookup_not_found(self) -> None:
        ledger = CapabilityLedger()
        assert ledger.lookup("urn:nonexistent") is None

    def test_register_overwrites(self, free_entry: CapabilityLedgerEntry) -> None:
        ledger = CapabilityLedger()
        ledger.register(free_entry)

        updated = CapabilityLedgerEntry(
            capability_urn="urn:coreason:solver:basic",
            oci_uri="ghcr.io/coreason-ai/solver-basic:v2",
            license_class="commercial",
            minimum_tier="standard",
        )
        ledger.register(updated)

        result = ledger.lookup("urn:coreason:solver:basic")
        assert result is not None
        assert result.oci_uri == "ghcr.io/coreason-ai/solver-basic:v2"
        assert result.license_class == "commercial"

    def test_empty_ledger(self) -> None:
        ledger = CapabilityLedger()
        assert ledger.lookup("anything") is None


# ---------------------------------------------------------------------------
# CapabilityLedger.check_access tests
# ---------------------------------------------------------------------------


class TestCheckAccess:
    """Tests for the check_access method."""

    def test_free_tier_access_free_cap(self, ledger: CapabilityLedger) -> None:
        assert ledger.check_access("urn:coreason:solver:basic", "free") is True

    def test_free_tier_denied_standard_cap(self, ledger: CapabilityLedger) -> None:
        assert ledger.check_access("urn:coreason:solver:advanced", "free") is False

    def test_standard_tier_access_standard_cap(self, ledger: CapabilityLedger) -> None:
        assert ledger.check_access("urn:coreason:solver:advanced", "standard") is True

    def test_enterprise_tier_access_all_non_commercial(
        self, ledger: CapabilityLedger
    ) -> None:
        assert ledger.check_access("urn:coreason:solver:basic", "enterprise") is True
        assert ledger.check_access("urn:coreason:solver:advanced", "enterprise") is True

    def test_commercial_cap_denied_without_commercial_license(
        self, ledger: CapabilityLedger
    ) -> None:
        # Enterprise tier but prosperity license — commercial cap denied
        assert (
            ledger.check_access(
                "urn:coreason:solver:enterprise",
                "enterprise",
                tenant_license="prosperity-3.0",
            )
            is False
        )

    def test_commercial_cap_granted_with_commercial_license(
        self, ledger: CapabilityLedger
    ) -> None:
        assert (
            ledger.check_access(
                "urn:coreason:solver:enterprise",
                "enterprise",
                tenant_license="commercial",
            )
            is True
        )

    def test_unknown_capability_denied(self, ledger: CapabilityLedger) -> None:
        assert ledger.check_access("urn:nonexistent", "enterprise") is False

    def test_unknown_tier_treated_as_free(self, ledger: CapabilityLedger) -> None:
        # Unknown tier defaults to level 0 (free)
        assert ledger.check_access("urn:coreason:solver:basic", "unknown") is True
        assert ledger.check_access("urn:coreason:solver:advanced", "unknown") is False

    def test_standard_tier_cannot_access_enterprise(
        self, ledger: CapabilityLedger
    ) -> None:
        assert (
            ledger.check_access(
                "urn:coreason:solver:enterprise",
                "standard",
                tenant_license="commercial",
            )
            is False
        )

    def test_research_cap_access(self, ledger: CapabilityLedger) -> None:
        """Research license class does NOT require commercial license."""
        assert ledger.check_access("urn:coreason:solver:research", "free") is True

    def test_default_tenant_license(self, ledger: CapabilityLedger) -> None:
        """Default tenant_license is prosperity-3.0."""
        # Free-tier prosperity cap with default license should work
        assert ledger.check_access("urn:coreason:solver:basic", "free") is True


# ---------------------------------------------------------------------------
# CapabilityLedger.list_capabilities tests
# ---------------------------------------------------------------------------


class TestListCapabilities:
    """Tests for the list_capabilities method."""

    def test_list_all(self, ledger: CapabilityLedger) -> None:
        results = ledger.list_capabilities()
        assert len(results) == 4

    def test_filter_by_license_class(self, ledger: CapabilityLedger) -> None:
        results = ledger.list_capabilities(license_class="commercial")
        assert len(results) == 1
        assert results[0].capability_urn == "urn:coreason:solver:enterprise"

    def test_filter_by_prosperity_license(self, ledger: CapabilityLedger) -> None:
        results = ledger.list_capabilities(license_class="prosperity-3.0")
        assert len(results) == 2

    def test_filter_by_minimum_tier(self, ledger: CapabilityLedger) -> None:
        results = ledger.list_capabilities(minimum_tier="free")
        assert len(results) == 2  # basic + research

    def test_filter_by_standard_tier(self, ledger: CapabilityLedger) -> None:
        results = ledger.list_capabilities(minimum_tier="standard")
        assert len(results) == 1
        assert results[0].capability_urn == "urn:coreason:solver:advanced"

    def test_filter_both(self, ledger: CapabilityLedger) -> None:
        results = ledger.list_capabilities(
            license_class="prosperity-3.0", minimum_tier="free"
        )
        assert len(results) == 1
        assert results[0].capability_urn == "urn:coreason:solver:basic"

    def test_filter_no_match(self, ledger: CapabilityLedger) -> None:
        results = ledger.list_capabilities(
            license_class="commercial", minimum_tier="free"
        )
        assert len(results) == 0

    def test_list_empty_ledger(self) -> None:
        ledger = CapabilityLedger()
        assert ledger.list_capabilities() == []


# ---------------------------------------------------------------------------
# CapabilityLedger.to_dict tests
# ---------------------------------------------------------------------------


class TestToDict:
    """Tests for the to_dict method."""

    def test_to_dict_structure(self, ledger: CapabilityLedger) -> None:
        d = ledger.to_dict()
        assert isinstance(d, dict)
        assert len(d) == 4
        assert "urn:coreason:solver:basic" in d
        assert "urn:coreason:solver:enterprise" in d

    def test_to_dict_values_are_dicts(self, ledger: CapabilityLedger) -> None:
        d = ledger.to_dict()
        for urn, entry_dict in d.items():
            assert isinstance(entry_dict, dict)
            assert "capability_urn" in entry_dict
            assert "oci_uri" in entry_dict
            assert "license_class" in entry_dict

    def test_to_dict_empty_ledger(self) -> None:
        ledger = CapabilityLedger()
        assert ledger.to_dict() == {}

    def test_to_dict_single_entry(self, free_entry: CapabilityLedgerEntry) -> None:
        ledger = CapabilityLedger()
        ledger.register(free_entry)
        d = ledger.to_dict()
        assert len(d) == 1
        assert (
            d["urn:coreason:solver:basic"]["oci_uri"]
            == "ghcr.io/coreason-ai/solver-basic:latest"
        )
