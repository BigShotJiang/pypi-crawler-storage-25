# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import json
import subprocess
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse

app = FastAPI(title="Claw Bridge Sandbox Bypass")


@app.post("/mcp/{server_cid}/tools/list")
async def tools_catalog_transmutation(server_cid: str) -> JSONResponse:
    """Provide the catalog of cognitive tools available to the sandbox."""
    try:
        process_receipt = subprocess.run(
            ["/app/claw", "list"], capture_output=True, text=True, check=True
        )
        catalog_envelope = json.loads(process_receipt.stdout)
        return JSONResponse(content=catalog_envelope)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to query tools: {exc}")


@app.post("/mcp/{server_cid}/tools/call")
async def tool_execution_intent(server_cid: str, request: Request) -> JSONResponse:
    """Execute a cognitive tool in the sandbox subprocess."""
    try:
        payload_envelope = await request.json()
        tool_identity = payload_envelope.get("name")
        arguments_envelope = payload_envelope.get("arguments") or {}

        if not tool_identity:
            raise HTTPException(status_code=400, detail="Missing tool name identity")

        # Run the claw binary as a subprocess and pass the arguments to it via stdin
        process_receipt = subprocess.run(
            ["/app/claw", "execute", tool_identity],
            input=json.dumps(arguments_envelope),
            capture_output=True,
            text=True,
            check=True,
        )
        execution_receipt = json.loads(process_receipt.stdout)
        return JSONResponse(content=execution_receipt)
    except subprocess.CalledProcessError as exc:
        raise HTTPException(
            status_code=500, detail=f"Claw execution crash: {exc.stderr}"
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Claw bridge error: {exc}")
