# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""OPA Integration for JWT License Verification (#244).

Provides a Rego policy and evaluation bridge that validates JWT license
claims (exp, iat, license_tier, capabilities) using OPA, replacing
hardcoded Rust/Python checks.
"""

from __future__ import annotations

import json
import os
import urllib.request
from pathlib import Path
from typing import Any

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field


class LicenseVerificationReceipt(CoreasonBaseState):
    """Frozen receipt from OPA-based license verification."""

    tenant_cid: str = Field(description="The verified tenant CID")
    license_tier: str = Field(
        description="The license tier (prosperity-3.0, commercial)"
    )
    capabilities_granted: list[str] = Field(
        default_factory=list,
        description="List of capability URNs granted by this license",
    )
    policy_version: str = Field(
        default="v1", description="Version of the Rego policy used"
    )


LICENSE_POLICY_REGO = """package coreason.license

import future.keywords.if
import future.keywords.in

default valid := false

# License is valid if not expired
valid if {
    input.claims.exp > input.current_epoch
}

# Legacy field support
valid if {
    input.claims.expires_at_epoch > input.current_epoch
    not input.claims.exp
}

# Extract license tier
license_tier := tier if {
    tier := input.claims.license_tier
}

license_tier := "prosperity-3.0" if {
    not input.claims.license_tier
}

# Capability access check
capability_allowed if {
    valid
    input.requested_capability in input.claims.capabilities
}

capability_allowed if {
    valid
    "*" in input.claims.capabilities
}

capability_allowed if {
    valid
    not input.claims.capabilities
}
"""


class OPALicenseVerifier:
    """Evaluates JWT license claims against OPA Rego policies.

    Replaces hardcoded license checks with policy-driven validation.
    """

    def __init__(
        self,
        opa_url: str | None = None,
        policy_path: str = "v1/data/coreason/license",
    ) -> None:
        self.opa_url = opa_url or os.environ.get("OPA_URL", "http://localhost:8181")
        self.policy_path = policy_path

    def verify_license(
        self,
        jwt_claims: dict[str, Any],
        tenant_cid: str,
        requested_capability: str = "",
        current_epoch: int | None = None,
    ) -> LicenseVerificationReceipt:
        """Verify a license JWT against OPA policies.

        Args:
            jwt_claims: Decoded JWT claims.
            tenant_cid: The tenant CID to verify.
            requested_capability: Optional capability URN being accessed.
            current_epoch: Current Unix epoch (defaults to time.time()).

        Returns:
            LicenseVerificationReceipt on success.

        Raises:
            PermissionError: If the license is invalid or expired.
        """
        import time

        if current_epoch is None:
            current_epoch = int(time.time())

        input_doc = {
            "input": {
                "claims": jwt_claims,
                "tenant_cid": tenant_cid,
                "requested_capability": requested_capability,
                "current_epoch": current_epoch,
            }
        }

        query_url = f"{self.opa_url.rstrip('/')}/{self.policy_path}"
        try:
            req_body = json.dumps(input_doc).encode("utf-8")
            req = urllib.request.Request(  # nosec B310 # noqa: S310
                query_url,
                data=req_body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=2.0) as resp:  # nosec B310 # noqa: S310
                result = json.loads(resp.read().decode()).get("result", {})
        except Exception:
            # Fallback: evaluate locally
            result = self._evaluate_locally(
                jwt_claims, current_epoch, requested_capability
            )

        if not result.get("valid", False):
            raise PermissionError(
                f"License verification failed for tenant '{tenant_cid}': "
                f"License expired or claims invalid."
            )

        return LicenseVerificationReceipt(
            tenant_cid=tenant_cid,
            license_tier=result.get("license_tier", "prosperity-3.0"),
            capabilities_granted=jwt_claims.get("capabilities", []),
        )

    def _evaluate_locally(
        self,
        claims: dict[str, Any],
        current_epoch: int,
        requested_capability: str,
    ) -> dict[str, Any]:
        """Fallback local evaluation without OPA server."""
        exp = claims.get("exp", claims.get("expires_at_epoch", 0))
        valid = int(exp) > current_epoch if exp else False

        tier = claims.get("license_tier", "prosperity-3.0")

        capabilities = claims.get("capabilities", [])
        cap_allowed = (
            not requested_capability
            or requested_capability in capabilities
            or "*" in capabilities
            or not capabilities
        )

        return {
            "valid": valid,
            "license_tier": tier,
            "capability_allowed": cap_allowed,
        }

    def write_rego_policy(self, output_path: str | Path) -> Path:
        """Write the Rego policy file for OPA deployment.

        Args:
            output_path: Path to write the .rego file.

        Returns:
            Path to the written file.
        """
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(LICENSE_POLICY_REGO, encoding="utf-8")
        return path
