# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""SPIFFE/SPIRE Certificate Verification (#254).

Implements mTLS validation using SPIFFE/SPIRE identity certificates
for inter-service authentication on internal gateway routes.
"""

from __future__ import annotations

import os
import ssl
from pathlib import Path
from typing import Any

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field


class SPIFFEIdentityReceipt(CoreasonBaseState):
    """Frozen receipt proving SPIFFE identity verification."""

    spiffe_id: str = Field(
        description="The verified SPIFFE ID (spiffe://<trust-domain>/<workload>)"
    )
    trust_domain: str = Field(description="The SPIFFE trust domain")
    workload_path: str = Field(description="The workload path within the trust domain")
    certificate_fingerprint: str = Field(
        description="SHA-256 fingerprint of the peer certificate"
    )


class SPIFFEVerifier:
    """Validates SPIFFE/SPIRE identity certificates for mTLS.

    Reads the SVID (SPIFFE Verifiable Identity Document) bundle from the
    Workload API or from local PEM files, and verifies peer certificates
    against the trust bundle.
    """

    def __init__(
        self,
        trust_bundle_path: str | Path | None = None,
        svid_cert_path: str | Path | None = None,
        svid_key_path: str | Path | None = None,
    ) -> None:
        self.trust_bundle_path = Path(
            trust_bundle_path
            or os.environ.get("SPIFFE_BUNDLE_PATH", "/run/spire/bundle/bundle.crt")
        )
        self.svid_cert_path = Path(
            svid_cert_path
            or os.environ.get("SPIFFE_SVID_CERT", "/run/spire/svid/svid.crt")
        )
        self.svid_key_path = Path(
            svid_key_path
            or os.environ.get("SPIFFE_SVID_KEY", "/run/spire/svid/svid.key")
        )

    def create_ssl_context(self, *, server_side: bool = False) -> ssl.SSLContext:
        """Create an SSL context configured for SPIFFE mTLS.

        Args:
            server_side: True for server-side context, False for client-side.

        Returns:
            Configured ssl.SSLContext for mTLS with SPIFFE certificates.
        """
        ctx = ssl.SSLContext(
            ssl.PROTOCOL_TLS_CLIENT if not server_side else ssl.PROTOCOL_TLS_SERVER
        )
        ctx.verify_mode = ssl.CERT_REQUIRED
        ctx.minimum_version = ssl.TLSVersion.TLSv1_3

        if self.trust_bundle_path.exists():
            ctx.load_verify_locations(str(self.trust_bundle_path))

        if self.svid_cert_path.exists() and self.svid_key_path.exists():
            ctx.load_cert_chain(str(self.svid_cert_path), str(self.svid_key_path))

        return ctx

    def verify_peer_spiffe_id(self, peer_cert: dict[str, Any]) -> SPIFFEIdentityReceipt:
        """Extract and verify the SPIFFE ID from a peer's X.509 certificate.

        Args:
            peer_cert: The peer certificate dict (from ssl.SSLSocket.getpeercert()).

        Returns:
            SPIFFEIdentityReceipt with the verified SPIFFE ID.

        Raises:
            ValueError: If the certificate does not contain a valid SPIFFE ID.
        """
        import hashlib

        spiffe_id = ""
        for san_type, san_value in peer_cert.get("subjectAltName", []):
            if san_type == "URI" and san_value.startswith("spiffe://"):
                spiffe_id = san_value
                break

        if not spiffe_id:
            raise ValueError(
                "Peer certificate does not contain a SPIFFE ID in SAN URIs"
            )

        # Parse trust domain and workload path
        # Format: spiffe://<trust-domain>/<workload-path>
        parts = spiffe_id.replace("spiffe://", "").split("/", 1)
        trust_domain = parts[0]
        workload_path = f"/{parts[1]}" if len(parts) > 1 else "/"

        # Compute certificate fingerprint
        cert_der = peer_cert.get("serialNumber", "unknown")
        fingerprint = hashlib.sha256(str(cert_der).encode()).hexdigest()

        return SPIFFEIdentityReceipt(
            spiffe_id=spiffe_id,
            trust_domain=trust_domain,
            workload_path=workload_path,
            certificate_fingerprint=fingerprint,
        )
