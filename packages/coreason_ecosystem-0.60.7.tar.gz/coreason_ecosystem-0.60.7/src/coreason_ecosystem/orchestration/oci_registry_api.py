# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""OCI Registry Query API for Capability Discovery (#252).

Exposes a /api/capabilities endpoint that queries the OCI artifact
ledger and returns registered capabilities for the template builder
carousel and capability discovery workflows.
"""

from __future__ import annotations

import json
import os
import urllib.request

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field


class CapabilityDiscoveryResult(CoreasonBaseState):
    """A discovered capability from the OCI registry."""

    urn: str = Field(description="Capability URN")
    oci_uri: str = Field(description="OCI artifact URI")
    version: str = Field(default="latest", description="Capability version")
    description: str = Field(default="", description="Human-readable description")
    license_tier: str = Field(
        default="prosperity-3.0", description="License classification"
    )
    tags: list[str] = Field(default_factory=list, description="Discovery tags")


class OCIRegistryQueryAPI:
    """Queries OCI registries and the URN authority ledger for capability discovery.

    Supports:
    - Local ledger YAML scanning
    - OCI registry tag listing via the Distribution Spec API
    - Filtering by URN prefix, license tier, and tags
    """

    def __init__(
        self,
        registry_url: str | None = None,
        ledger_path: str | None = None,
    ) -> None:
        self.registry_url = registry_url or os.environ.get(
            "COREASON_OCI_REGISTRY", "ghcr.io/coreason-ai"
        )
        self.ledger_path = ledger_path

    def discover(
        self,
        *,
        urn_prefix: str = "urn:coreason:",
        license_tier: str | None = None,
        tags: list[str] | None = None,
    ) -> list[CapabilityDiscoveryResult]:
        """Discover available capabilities.

        Args:
            urn_prefix: Filter by URN prefix.
            license_tier: Filter by license tier.
            tags: Filter by tags.

        Returns:
            List of discovered capabilities.
        """
        results: list[CapabilityDiscoveryResult] = []

        # Source 1: Local ledger
        if self.ledger_path:
            results.extend(self._scan_ledger(urn_prefix))

        # Source 2: OCI registry
        results.extend(self._scan_registry(urn_prefix))

        # Apply filters
        if license_tier:
            results = [r for r in results if r.license_tier == license_tier]
        if tags:
            tag_set = set(tags)
            results = [r for r in results if tag_set.intersection(set(r.tags))]

        # Deduplicate by URN
        seen: set[str] = set()
        deduped: list[CapabilityDiscoveryResult] = []
        for r in results:
            if r.urn not in seen:
                seen.add(r.urn)
                deduped.append(r)

        return deduped

    def _scan_ledger(self, urn_prefix: str) -> list[CapabilityDiscoveryResult]:
        """Scan the local URN authority ledger YAML."""
        from pathlib import Path

        results: list[CapabilityDiscoveryResult] = []
        ledger_file = Path(self.ledger_path) if self.ledger_path else None

        if not ledger_file or not ledger_file.exists():
            return results

        try:
            import yaml

            with open(ledger_file, encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}

            for entry in data.get("capabilities", []):
                urn = entry.get("urn", "")
                if urn.startswith(urn_prefix):
                    results.append(
                        CapabilityDiscoveryResult(
                            urn=urn,
                            oci_uri=entry.get("oci_uri", ""),
                            version=entry.get("version", "latest"),
                            description=entry.get("description", ""),
                            license_tier=entry.get("license_tier", "prosperity-3.0"),
                            tags=entry.get("tags", []),
                        )
                    )
        except Exception:
            pass

        return results

    def _scan_registry(self, urn_prefix: str) -> list[CapabilityDiscoveryResult]:
        """Query OCI registry for available artifacts via Distribution Spec."""
        results: list[CapabilityDiscoveryResult] = []

        catalog_url = f"https://{self.registry_url}/v2/_catalog"
        try:
            req = urllib.request.Request(catalog_url)  # nosec B310 # noqa: S310
            token = os.environ.get("COREASON_OCI_TOKEN")
            if token:
                req.add_header("Authorization", f"Bearer {token}")

            with urllib.request.urlopen(req, timeout=5.0) as resp:  # nosec B310 # noqa: S310
                catalog = json.loads(resp.read().decode())

            for repo_name in catalog.get("repositories", []):
                if "coreason" in repo_name:
                    urn = f"urn:coreason:solver:{repo_name.split('/')[-1]}"
                    if urn.startswith(urn_prefix):
                        results.append(
                            CapabilityDiscoveryResult(
                                urn=urn,
                                oci_uri=f"{self.registry_url}/{repo_name}:latest",
                                description=f"Auto-discovered from {repo_name}",
                                tags=["auto-discovered"],
                            )
                        )
        except Exception:
            pass

        return results
