# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""Thermodynamic Cost Tracking Database and Schema (#253).

Tracks compute expenditures (token costs, GPU time, API calls)
per tenant for billing enforcement and resource governance.
"""

from __future__ import annotations

import time
from typing import Any

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field


class ThermodynamicCostRecord(CoreasonBaseState):
    """A single cost record for a workflow execution."""

    tenant_cid: str = Field(description="Tenant identifier")
    workflow_id: str = Field(description="The Temporal workflow ID")
    agent_cid: str = Field(default="", description="Agent that incurred the cost")
    input_tokens: int = Field(default=0, description="Input tokens consumed")
    output_tokens: int = Field(default=0, description="Output tokens generated")
    total_tokens: int = Field(default=0, description="Total tokens (input + output)")
    cost_usd: float = Field(default=0.0, description="Estimated cost in USD")
    gpu_seconds: float = Field(default=0.0, description="GPU compute seconds used")
    timestamp: float = Field(
        default_factory=time.time, description="Unix epoch timestamp"
    )


class ThermodynamicCostTracker:
    """Tracks and enforces thermodynamic (compute) cost limits per tenant.

    Provides SQL schema for PostgreSQL persistence and in-memory
    tracking for real-time budget enforcement.
    """

    POSTGRES_SCHEMA = """
    CREATE TABLE IF NOT EXISTS thermodynamic_costs (
        id BIGSERIAL PRIMARY KEY,
        tenant_cid VARCHAR(128) NOT NULL,
        workflow_id VARCHAR(256) NOT NULL,
        agent_cid VARCHAR(256) DEFAULT '',
        input_tokens INTEGER DEFAULT 0,
        output_tokens INTEGER DEFAULT 0,
        total_tokens INTEGER DEFAULT 0,
        cost_usd NUMERIC(12, 6) DEFAULT 0.0,
        gpu_seconds NUMERIC(12, 4) DEFAULT 0.0,
        timestamp TIMESTAMPTZ DEFAULT NOW(),
        CONSTRAINT idx_tenant_workflow UNIQUE (tenant_cid, workflow_id, timestamp)
    );

    CREATE INDEX IF NOT EXISTS idx_costs_tenant ON thermodynamic_costs(tenant_cid);
    CREATE INDEX IF NOT EXISTS idx_costs_timestamp ON thermodynamic_costs(timestamp);

    -- Materialized view for tenant billing summaries
    CREATE MATERIALIZED VIEW IF NOT EXISTS tenant_cost_summary AS
    SELECT
        tenant_cid,
        SUM(total_tokens) as total_tokens,
        SUM(cost_usd) as total_cost_usd,
        SUM(gpu_seconds) as total_gpu_seconds,
        COUNT(*) as total_invocations,
        MAX(timestamp) as last_activity
    FROM thermodynamic_costs
    GROUP BY tenant_cid;
    """

    def __init__(self, budget_limit_usd: float = 100.0) -> None:
        self.budget_limit_usd = budget_limit_usd
        self._records: list[ThermodynamicCostRecord] = []
        self._tenant_totals: dict[str, float] = {}

    def record_cost(self, record: ThermodynamicCostRecord) -> None:
        """Record a cost event.

        Raises:
            ValueError: If the cost is negative.
            PermissionError: If the tenant has exceeded their budget.
        """
        if record.cost_usd < 0:
            raise ValueError(f"Cost must be non-negative, got {record.cost_usd}")
        current = self._tenant_totals.get(record.tenant_cid, 0.0)
        if current + record.cost_usd > self.budget_limit_usd:
            raise PermissionError(
                f"Tenant '{record.tenant_cid}' budget exceeded: "
                f"${current + record.cost_usd:.4f} > ${self.budget_limit_usd:.2f} limit"
            )

        self._records.append(record)
        self._tenant_totals[record.tenant_cid] = current + record.cost_usd

    def get_tenant_total(self, tenant_cid: str) -> float:
        """Get total cost for a tenant."""
        return self._tenant_totals.get(tenant_cid, 0.0)

    def get_tenant_records(self, tenant_cid: str) -> list[ThermodynamicCostRecord]:
        """Get all cost records for a tenant."""
        return [r for r in self._records if r.tenant_cid == tenant_cid]

    def get_summary(self) -> dict[str, Any]:
        """Get billing summary across all tenants."""
        return {
            tenant: {
                "total_cost_usd": total,
                "budget_remaining_usd": self.budget_limit_usd - total,
                "invocations": len(
                    [r for r in self._records if r.tenant_cid == tenant]
                ),
            }
            for tenant, total in self._tenant_totals.items()
        }
