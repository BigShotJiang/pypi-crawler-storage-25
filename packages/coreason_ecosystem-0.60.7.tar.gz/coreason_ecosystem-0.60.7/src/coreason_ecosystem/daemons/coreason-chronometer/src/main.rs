// Copyright (c) 2026 CoReason, Inc
//
// This software is proprietary and dual-licensed
// Licensed under the Prosperity Public License 3.0 (the "License")
// A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
// For details, see the LICENSE file
// Commercial use beyond a 30-day trial requires a separate license
//
// Source Code: <https://github.com/CoReason-AI/coreason-runtime>

use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

const SOVEREIGN_WINDOW_SECONDS: u64 = 30 * 24 * 60 * 60; // 30 days

#[derive(Serialize, Deserialize, Debug, Clone)]
struct MonotonicTemporalState {
    genesis_time: f64,
    highest_known_time: f64,
    tamper_lockout: bool,
}

impl MonotonicTemporalState {
    fn load(path: &Path) -> Self {
        if path.exists() {
            if let Ok(content) = fs::read_to_string(path) {
                if let Ok(state) = serde_json::from_str::<MonotonicTemporalState>(&content) {
                    return state;
                }
            }
        }

        // Backward compatibility migration from genesis_time.txt
        let mut old_path = PathBuf::from(".");
        old_path.push("registry");
        old_path.push("vault");
        old_path.push("genesis_time.txt");

        let genesis = if old_path.exists() {
            if let Ok(content) = fs::read_to_string(&old_path) {
                content.trim().parse::<f64>().unwrap_or_else(|_| {
                    SystemTime::now()
                        .duration_since(UNIX_EPOCH)
                        .unwrap_or_default()
                        .as_secs_f64()
                })
            } else {
                SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .unwrap_or_default()
                    .as_secs_f64()
            }
        } else {
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs_f64()
        };

        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs_f64();

        let state = MonotonicTemporalState {
            genesis_time: genesis,
            highest_known_time: now,
            tamper_lockout: false,
        };
        state.save(path);
        state
    }

    fn save(&self, path: &Path) {
        if let Some(parent) = path.parent() {
            let _ = fs::create_dir_all(parent);
        }
        if let Ok(content) = serde_json::to_string_pretty(self) {
            let _ = fs::write(path, content);
        }
    }
}

async fn verify_and_sever_expired_credentials(
    client: &reqwest::Client,
    vault_url: &str,
    vault_token: &str,
    now: f64,
) {
    let enumerate_url = format!("{}/v1/secret/metadata/coreason/license?list=true", vault_url);
    let mut tenant_keys = Vec::new();

    if let Ok(res) = client
        .get(&enumerate_url)
        .header("X-Vault-Token", vault_token)
        .send()
        .await
    {
        if res.status().is_success() {
            if let Ok(json_payload) = res.json::<Value>().await {
                if let Some(keys_arr) = json_payload["data"]["keys"].as_array() {
                    for k in keys_arr {
                        if let Some(k_str) = k.as_str() {
                            tenant_keys.push(k_str.to_string());
                        }
                    }
                }
            }
        }
    }

    // Fix #245: Resolve Root CA key with production safety guards.
    // In production, COREASON_DEV_KEY is forbidden and missing keys fail-closed.
    let is_production = env::var("COREASON_ENV")
        .map(|v| v == "production")
        .unwrap_or(false);

    let root_ca_key = if is_production {
        match env::var("COREASON_ROOT_CA_KEY") {
            Ok(key) if !key.is_empty() => key,
            _ => {
                eprintln!(
                    "[Chronometer] CRITICAL: COREASON_ROOT_CA_KEY is not set in production. \
                     License verification is fail-closed. Skipping credential verification."
                );
                return;
            }
        }
    } else {
        env::var("COREASON_ROOT_CA_KEY")
            .or_else(|_| env::var("COREASON_DEV_KEY"))
            .unwrap_or_default()
    };

    for key in tenant_keys {
        let secret_url = format!("{}/v1/secret/data/coreason/license/{}", vault_url, key);
        let res = match client
            .get(&secret_url)
            .header("X-Vault-Token", vault_token)
            .send()
            .await
        {
            Ok(r) => r,
            Err(_) => continue,
        };

        if !res.status().is_success() {
            continue;
        }

        let json_payload = match res.json::<Value>().await {
            Ok(json) => json,
            Err(_) => continue,
        };

        let envelope = &json_payload["data"]["data"];
        if envelope.is_null() {
            continue;
        }

        let token_opt = envelope["token"].as_str();
        let claims = if let Some(token_str) = token_opt {
            match coreason_license::verify_token_signature(token_str, &root_ca_key) {
                Ok(c) => c,
                Err(e) => {
                    eprintln!("[Chronometer] Warning: License token signature verification failed: {}", e);
                    continue;
                }
            }
        } else {
            if envelope["claims"].is_null() {
                envelope.clone()
            } else {
                envelope["claims"].clone()
            }
        };

        if let Some(exp_val) = claims["exp"].as_f64().or_else(|| claims["exp"].as_str().and_then(|s| s.parse::<f64>().ok())) {
            if exp_val <= now {
                println!("[Chronometer] Evicting expired license for tenant: {}", key);
                let sever_url = format!("{}/v1/secret/metadata/coreason/license/{}", vault_url, key);
                let _ = client
                    .request(reqwest::Method::from_bytes(b"DELETE").unwrap(), &sever_url)
                    .header("X-Vault-Token", vault_token)
                    .send()
                    .await;
            }
        }
    }
}

async fn mutate_guillotine_status(
    client: &reqwest::Client,
    vault_url: &str,
    vault_token: &str,
    active: bool,
) {
    let status_str = if active { "True" } else { "False" };
    println!("[Chronometer] AST Guillotine status mutated: {}", status_str);

    let write_url = format!("{}/v1/secret/data/coreason/governance", vault_url);
    let payload = serde_json::json!({
        "data": {
            "ast_guillotine_active": status_str
        }
    });

    let _ = client
        .post(&write_url)
        .header("X-Vault-Token", vault_token)
        .json(&payload)
        .send()
        .await;
}

/// Checks Vault for any valid (unexpired) commercial license.
///
/// Returns `true` if at least one tenant holds a license with an `exp` claim
/// that is still in the future. This prevents the AST Guillotine from
/// activating when a paying commercial tenant has a valid license installed,
/// preserving their IP sovereignty even after the 30-day sovereign window.
async fn has_valid_commercial_license(
    client: &reqwest::Client,
    vault_url: &str,
    vault_token: &str,
    now: f64,
) -> bool {
    let enumerate_url = format!("{}/v1/secret/metadata/coreason/license?list=true", vault_url);

    let res = match client
        .get(&enumerate_url)
        .header("X-Vault-Token", vault_token)
        .send()
        .await
    {
        Ok(r) => r,
        Err(_) => return false,
    };

    if !res.status().is_success() {
        return false;
    }

    let json_payload = match res.json::<Value>().await {
        Ok(json) => json,
        Err(_) => return false,
    };

    let keys = match json_payload["data"]["keys"].as_array() {
        Some(keys) => keys,
        None => return false,
    };

    for key in keys {
        let key_str = match key.as_str() {
            Some(k) => k,
            None => continue,
        };

        let secret_url = format!("{}/v1/secret/data/coreason/license/{}", vault_url, key_str);
        let res = match client
            .get(&secret_url)
            .header("X-Vault-Token", vault_token)
            .send()
            .await
        {
            Ok(r) => r,
            Err(_) => continue,
        };

        if !res.status().is_success() {
            continue;
        }

        let json_payload = match res.json::<Value>().await {
            Ok(json) => json,
            Err(_) => continue,
        };

        let envelope = &json_payload["data"]["data"];
        if envelope.is_null() {
            continue;
        }

        // Extract claims — either from a verified JWT token or raw envelope
        let claims = if let Some(token_str) = envelope["token"].as_str() {
            // Fix #245: Apply production guard for Root CA key resolution
            let is_production = env::var("COREASON_ENV")
                .map(|v| v == "production")
                .unwrap_or(false);

            let root_ca_key = if is_production {
                match env::var("COREASON_ROOT_CA_KEY") {
                    Ok(key) if !key.is_empty() => key,
                    _ => continue, // Fail-closed: skip this license in production
                }
            } else {
                env::var("COREASON_ROOT_CA_KEY")
                    .or_else(|_| env::var("COREASON_DEV_KEY"))
                    .unwrap_or_default()
            };
            match coreason_license::verify_token_signature(token_str, &root_ca_key) {
                Ok(c) => c,
                Err(_) => continue,
            }
        } else if envelope["claims"].is_null() {
            envelope.clone()
        } else {
            envelope["claims"].clone()
        };

        // Check if the license has a valid (future) expiration
        if let Some(exp_val) = claims["exp"]
            .as_f64()
            .or_else(|| claims["exp"].as_str().and_then(|s| s.parse::<f64>().ok()))
        {
            if exp_val > now {
                println!(
                    "[Chronometer] Valid commercial license found for tenant '{}' (expires at {}). Guillotine will NOT activate.",
                    key_str, exp_val
                );
                return true;
            }
        }
    }

    false
}

#[tokio::main]
async fn main() {
    let args: Vec<String> = env::args().collect();

    // Command line license installation mode
    if args.len() > 1 && (args[1] == "install" || args[1] == "install-license") {
        if args.len() < 3 {
            eprintln!("Error: Missing JWT token argument");
            std::process::exit(1);
        }
        let token = &args[2];
        let vault_url = env::var("VAULT_ADDR").unwrap_or_else(|_| "http://127.0.0.1:8200".to_string());
        let vault_token = env::var("VAULT_TOKEN").unwrap_or_else(|_| "dev-only-token".to_string());
        let env_name = env::var("COREASON_ENV").unwrap_or_else(|_| "development".to_string());

        // Fix #245: Reject COREASON_DEV_KEY fallback in production mode
        let root_ca_key = if env_name == "production" {
            match env::var("COREASON_ROOT_CA_KEY") {
                Ok(key) if !key.is_empty() => key,
                _ => {
                    eprintln!("✗ CRITICAL: COREASON_ROOT_CA_KEY must be set in production. Dev key fallback is forbidden.");
                    std::process::exit(1);
                }
            }
        } else {
            env::var("COREASON_ROOT_CA_KEY").or_else(|_| env::var("COREASON_DEV_KEY")).unwrap_or_default()
        };

        match coreason_license::install_license(token, &vault_url, &vault_token, &root_ca_key, &env_name).await {
            Ok(_) => {
                println!("✓ Commercial License installed and mathematically verified.");
                std::process::exit(0);
            }
            Err(e) => {
                eprintln!("✗ License Installation Failed: {}", e);
                std::process::exit(1);
            }
        }
    }

    println!("[Chronometer] Autonomic Timeline Monitoring Daemon starting...");

    let vault_url = env::var("VAULT_ADDR").unwrap_or_else(|_| "http://127.0.0.1:8200".to_string());
    let vault_token = env::var("VAULT_TOKEN").unwrap_or_else(|_| "dev-only-token".to_string());

    let state_path = PathBuf::from("registry/vault/temporal_state.json");
    let mut state = MonotonicTemporalState::load(&state_path);
    println!("[Chronometer] Cluster Genesis Time: {}", state.genesis_time);
    println!("[Chronometer] Cluster Highest Known Time: {}", state.highest_known_time);

    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(2))
        .build()
        .unwrap();

    if state.tamper_lockout {
        eprintln!("[Chronometer] CRITICAL ERROR: TemporalTamperError: Host-clock rollback detected! Cluster is locked into Prosperity 3.0 mode.");
        mutate_guillotine_status(&client, &vault_url, &vault_token, true).await;
        loop {
            tokio::time::sleep(std::time::Duration::from_secs(3600)).await;
        }
    }

    let mut last_write_time = state.highest_known_time;

    loop {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs_f64();

        if now < state.highest_known_time {
            eprintln!(
                "[Chronometer] CRITICAL ERROR: TemporalTamperError: Host clock rollback detected! Current time {} is less than last known time {}.",
                now, state.highest_known_time
            );
            state.tamper_lockout = true;
            state.save(&state_path);
            mutate_guillotine_status(&client, &vault_url, &vault_token, true).await;
            panic!("TemporalTamperError: Host-clock rollback detected!");
        }

        if now > state.highest_known_time {
            state.highest_known_time = now;
            if now - last_write_time >= 3600.0 {
                state.save(&state_path);
                last_write_time = now;
            }
        }

        // Fix #242: Check for valid commercial licenses BEFORE activating the guillotine.
        // The sovereign window (30 days) only applies to unlicensed/trial usage.
        // If any tenant has a valid unexpired commercial license, the guillotine
        // must remain inactive to preserve their IP sovereignty.
        let elapsed = now - state.genesis_time;
        let past_sovereign_window = elapsed > SOVEREIGN_WINDOW_SECONDS as f64;

        let should_be_active = if past_sovereign_window {
            // Only activate if NO valid commercial license exists
            !has_valid_commercial_license(&client, &vault_url, &vault_token, now).await
        } else {
            false
        };

        mutate_guillotine_status(&client, &vault_url, &vault_token, should_be_active).await;

        verify_and_sever_expired_credentials(&client, &vault_url, &vault_token, now).await;

        tokio::time::sleep(std::time::Duration::from_secs(60)).await;
    }
}
