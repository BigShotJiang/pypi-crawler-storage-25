# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-ecosystem

"""OpenShell Translator Sidecar.

Translates inbound NATS JSON-RPC invocation requests into structured OpenShell payloads,
dispatches them to the OpenShell manager, and responds with standard JSON-RPC envelopes.
"""

import asyncio
import json
import os
import sys
from typing import Any

import httpx
import nats
from nats.aio.msg import Msg
from loguru import logger


class OpenShellSidecarTranslator:
    """Sidecar translator routing tool invocations from NATS lattice to OpenShell execution."""

    def __init__(
        self,
        nats_url: str,
        openshell_url: str,
        nats_client: Any = None,
        http_client: Any = None,
    ) -> None:
        """Initialize the translator with service locations and optional dependency overrides."""
        self.nats_url = nats_url
        self.openshell_url = openshell_url
        self.nc = nats_client
        self.http_client = http_client

    async def run(self) -> None:
        """Establish connections and subscribe to the designated tool invocation subjects."""
        logger.info("Initializing OpenShell sidecar connection to {}", self.nats_url)
        if self.nc is None:
            self.nc = await nats.connect(
                self.nats_url,
                name="openshell-translator-sidecar",
            )

        subject = "coreason.tool.*.invoke"
        logger.info("Subscribing to subject: {}", subject)
        await self.nc.subscribe(subject, cb=self.handle_message)

        # Keep running until cancelled
        try:
            while True:
                await asyncio.sleep(3600)
        except asyncio.CancelledError:
            logger.info("Sidecar execution cancelled")
        finally:
            # Only close if we created the client instance internally
            if not self.http_client and self.nc:
                await self.nc.close()
            logger.info("NATS client connection closed")

    async def handle_message(self, msg: Msg) -> None:
        """Process an incoming broker message and dispatch to OpenShell."""
        reply_subject = msg.reply
        if not reply_subject:
            # Fire-and-forget requests do not expect an execution reply
            return

        try:
            body_str = msg.data.decode("utf-8")
        except Exception as err:
            await self.send_error(
                reply_subject,
                None,
                -32700,
                f"Invalid UTF-8: {err}",
            )
            return

        try:
            req = json.loads(body_str)
        except Exception as err:
            await self.send_error(
                reply_subject,
                None,
                -32600,
                f"Invalid JSON-RPC: {err}",
            )
            return

        req_id = req.get("id")

        try:
            # Safely navigate JSON-RPC params
            params = req.get("params", {})
            arguments = params.get("arguments", {})
            script = arguments.get("script")
            if not isinstance(script, str):
                raise ValueError("Payload script must be a string")
        except Exception as err:
            await self.send_error(
                reply_subject,
                req_id,
                -32600,
                f"Invalid JSON-RPC payload structure: {err}",
            )
            return

        # ── Security Context Extraction & Validation (Fix #263) ──────────
        # Extract the security context from inbound JSON-RPC parameters.
        # Fail-closed: reject if any guard is violated.
        security_context = params.get("security_context", {})
        authorized = security_context.get("authorized", False)
        spiffe_id = security_context.get("spiffe_id")
        receipt = security_context.get("verified_capability_receipt")

        # Guard 1: Enforce explicit authorized bit
        if not authorized:
            await self.send_error(
                reply_subject,
                req_id,
                -32001,
                "Security Exception: Inbound script execution is unauthorized.",
            )
            return

        # Guard 2: Enforce valid SPIFFE trust domain context
        if not spiffe_id or not spiffe_id.startswith("spiffe://coreason.ai/"):
            await self.send_error(
                reply_subject,
                req_id,
                -32002,
                "Security Exception: Invalid or missing SPIFFE identity context.",
            )
            return

        # Guard 3: Enforce presence of VerifiedCapabilityReceipt for audit
        if not receipt:
            await self.send_error(
                reply_subject,
                req_id,
                -32003,
                "Security Exception: Missing required VerifiedCapabilityReceipt.",
            )
            return

        # Prepare payload forwarding the verified context to OpenShell
        payload = {
            "security_context": {
                "authorized": authorized,
                "spiffe_id": spiffe_id,
                "verified_capability_receipt": receipt,
            },
            "script_payload": script,
        }

        # Dispatch HTTP request to OpenShell gateway endpoint
        try:
            if self.http_client is not None:
                res = await self.http_client.post(
                    f"{self.openshell_url}/v1/mcp/execute",
                    json=payload,
                    headers={"Content-Type": "application/json"},
                    timeout=60.0,
                )
            else:
                async with httpx.AsyncClient() as client:
                    res = await client.post(
                        f"{self.openshell_url}/v1/mcp/execute",
                        json=payload,
                        headers={"Content-Type": "application/json"},
                        timeout=60.0,
                    )
        except Exception as err:
            await self.send_error(
                reply_subject,
                req_id,
                -32603,
                f"OpenShell execution failed: {err}",
            )
            return

        if res.status_code != 200:
            await self.send_error(
                reply_subject,
                req_id,
                -32603,
                f"OpenShell returned non-200 status: {res.status_code}",
            )
            return

        try:
            res_val = res.json()
        except Exception as err:
            await self.send_error(
                reply_subject,
                req_id,
                -32603,
                f"Invalid response from OpenShell: {err}",
            )
            return

        # Construct success response envelop
        rpc_res = {
            "jsonrpc": "2.0",
            "result": res_val,
            "id": req_id,
        }

        try:
            await self.nc.publish(
                reply_subject,
                json.dumps(rpc_res).encode("utf-8"),
            )
        except Exception as err:
            logger.error("Failed to publish reply response: {}", err)

    async def send_error(
        self,
        reply_to: str,
        req_id: Any,
        code: int,
        message: str,
    ) -> None:
        """Send a formatted JSON-RPC error back to the reply subject."""
        err_res = {
            "jsonrpc": "2.0",
            "error": {
                "code": code,
                "message": message,
            },
            "id": req_id,
        }
        try:
            if self.nc:
                await self.nc.publish(
                    reply_to,
                    json.dumps(err_res).encode("utf-8"),
                )
        except Exception as err:
            logger.error("Failed to dispatch error response: {}", err)


if __name__ == "__main__":
    nats_env = os.environ.get(
        "NATS_URL",
        "nats://wasmcloud-host:dev-password-change-in-prod@localhost:4222",
    )
    openshell_env = os.environ.get(
        "OPENSHELL_URL",
        "http://openshell-manager:8080",
    )

    translator = OpenShellSidecarTranslator(
        nats_url=nats_env,
        openshell_url=openshell_env,
    )

    try:
        asyncio.run(translator.run())
    except KeyboardInterrupt:
        logger.info("Shutting down sidecar via interrupt")
        sys.exit(0)
