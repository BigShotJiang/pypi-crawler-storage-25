# Changelog

## [0.60.7](https://github.com/CoReason-AI/coreason-ecosystem/compare/v0.60.6...v0.60.7) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.60.7 ([91b2e56](https://github.com/CoReason-AI/coreason-ecosystem/commit/91b2e5695a600c9a1adecd34bdaad5f4411bd707))

## [0.60.6](https://github.com/CoReason-AI/coreason-ecosystem/compare/v0.60.5...v0.60.6) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.60.6 ([adfd6fb](https://github.com/CoReason-AI/coreason-ecosystem/commit/adfd6fb37ac7e5dc5ac655a65b75157e4b7d0374))

## [0.60.5](https://github.com/CoReason-AI/coreason-ecosystem/compare/v0.60.4...v0.60.5) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.60.5 ([1a8b4f2](https://github.com/CoReason-AI/coreason-ecosystem/commit/1a8b4f23c6fd12f7ef9471c4c4ce8c594dccfe60))

## [0.60.4](https://github.com/CoReason-AI/coreason-ecosystem/compare/v0.60.3...v0.60.4) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.60.4 ([8e01a9b](https://github.com/CoReason-AI/coreason-ecosystem/commit/8e01a9b159b6b84d5132effce4e6652b7ace7e8c))

## [0.60.3](https://github.com/CoReason-AI/coreason-ecosystem/compare/v0.60.2...v0.60.3) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.60.3 ([de8b8f1](https://github.com/CoReason-AI/coreason-ecosystem/commit/de8b8f110d5f508ad3e3ad13ed524c4cfdc847e0))

## [0.60.2](https://github.com/CoReason-AI/coreason-ecosystem/compare/v0.60.1...v0.60.2) (2026-05-22)


### Documentation

* sync RELEASE.md with updated infrastructure release policy ([554c449](https://github.com/CoReason-AI/coreason-ecosystem/commit/554c449cc85c3f503640c16848b549f2dc36de34))

## [0.60.1](https://github.com/CoReason-AI/coreason-ecosystem/compare/v0.60.0...v0.60.1) (2026-05-22)


### Bug Fixes

* clarify release-please Conventional Commits trigger requirement ([fd577c1](https://github.com/CoReason-AI/coreason-ecosystem/commit/fd577c1eaafe4b8433b05232b5f00a23d9633b65))
* clarify release-please Conventional Commits trigger requirement ([492ade3](https://github.com/CoReason-AI/coreason-ecosystem/commit/492ade369b50894b7a3622adf2e36c13843268e6))

## [0.60.0](https://github.com/CoReason-AI/coreason-ecosystem/compare/v0.59.1...v0.60.0) (2026-05-22)


### Features

* **opa:** make cache TTL configurable via OPA_CACHE_TTL_SECONDS env var ([2ea6ca7](https://github.com/CoReason-AI/coreason-ecosystem/commit/2ea6ca757866756080400ae7c1ce0d1bfddc1bda))


### Bug Fixes

* **auth:** correct Python 2-style except syntax in identity_manager ([9d2fc3b](https://github.com/CoReason-AI/coreason-ecosystem/commit/9d2fc3b12a12dcec955127fd7a36d1a16e17d818))
* **ci:** handle policy-blocked release-please merge gracefully ([14dcfce](https://github.com/CoReason-AI/coreason-ecosystem/commit/14dcfcee731f138ab69090d38464ae39a2d4b6f8))
* **ci:** remediate Ruff and Mypy issues in test files and format codebase ([e96dca4](https://github.com/CoReason-AI/coreason-ecosystem/commit/e96dca4c37952ba1e52d71201ee797e371b98fb3))
* **release:** prevent fromJSON parser error when release PR is empty ([265d1a2](https://github.com/CoReason-AI/coreason-ecosystem/commit/265d1a2cb9d0fa501bdffd330a54271f3dc05268))
* **security:** input validation and insecure defaults hardening (Sprint C) ([a7fd5be](https://github.com/CoReason-AI/coreason-ecosystem/commit/a7fd5be9bba501acd21f777d95a0abe533d3738e))


### Performance Improvements

* **opa:** bounded TTL cache for OPA policy decisions (Sprint D) ([64efc7e](https://github.com/CoReason-AI/coreason-ecosystem/commit/64efc7e9051a5d7deb6731ab84cf4096ac1ff561))

## [0.59.1](https://github.com/CoReason-AI/coreason-ecosystem/compare/v0.59.0...v0.59.1) (2026-05-22)


### Bug Fixes

* **ci:** remove unused hashlib import in x5c_verifier.py ([e489d53](https://github.com/CoReason-AI/coreason-ecosystem/commit/e489d532299f13aeebf9f6f1a4a81a0b5bb9b739))

## [0.59.0](https://github.com/CoReason-AI/coreason-ecosystem/compare/v0.58.0...v0.59.0) (2026-05-22)


### Features

* **security:** replay prevention, ML-DSA, and DLP scanning ([#248](https://github.com/CoReason-AI/coreason-ecosystem/issues/248), [#249](https://github.com/CoReason-AI/coreason-ecosystem/issues/249), [#240](https://github.com/CoReason-AI/coreason-ecosystem/issues/240)) ([be43297](https://github.com/CoReason-AI/coreason-ecosystem/commit/be43297ff8d7d1fbe87f2c73047a865ac9c1f676))
* Sprint 6 ecosystem security and capability features ([#241](https://github.com/CoReason-AI/coreason-ecosystem/issues/241), [#244](https://github.com/CoReason-AI/coreason-ecosystem/issues/244), [#246](https://github.com/CoReason-AI/coreason-ecosystem/issues/246), [#251](https://github.com/CoReason-AI/coreason-ecosystem/issues/251), [#252](https://github.com/CoReason-AI/coreason-ecosystem/issues/252), [#253](https://github.com/CoReason-AI/coreason-ecosystem/issues/253), [#254](https://github.com/CoReason-AI/coreason-ecosystem/issues/254), [#255](https://github.com/CoReason-AI/coreason-ecosystem/issues/255)) ([e4ad482](https://github.com/CoReason-AI/coreason-ecosystem/commit/e4ad4829bfd1adc9c49c0ada25b77e65604c4a25))


### Bug Fixes

* **chronometer:** check license validity before activating AST Guillotine ([#242](https://github.com/CoReason-AI/coreason-ecosystem/issues/242), [#245](https://github.com/CoReason-AI/coreason-ecosystem/issues/245)) ([eefff18](https://github.com/CoReason-AI/coreason-ecosystem/commit/eefff1858c12537e52f3379be61d049ea031d86c))
* **ci:** create external wasmcloud-lattice network prior to compose setup ([6caf866](https://github.com/CoReason-AI/coreason-ecosystem/commit/6caf8667e2ea0e30ace3da6d987eedc72c2fe808))
* **ci:** resolve code formatting and mypy typechecking issues ([12e4e59](https://github.com/CoReason-AI/coreason-ecosystem/commit/12e4e59e7cd5246d8365890b8537df797b2c6b58))
* **ci:** resolve unused import lints ([3fff210](https://github.com/CoReason-AI/coreason-ecosystem/commit/3fff21006f5d9c0ec4cac2dccf7b4a12c0fb1845))
* **daemons:** inject COREASON_DEFAULT_TENANT_ID into MCP server environment ([abc4f1b](https://github.com/CoReason-AI/coreason-ecosystem/commit/abc4f1b8b390f8e06ba986da30be339931fe5a69))
* **release:** remove GHCR_PAT fallback from release-please workflow to prevent 404 ([28fa302](https://github.com/CoReason-AI/coreason-ecosystem/commit/28fa30261e0538e64886d0e7b6b76a4766e6eb50))
* **release:** resolve blocked release-please pipeline ([db73987](https://github.com/CoReason-AI/coreason-ecosystem/commit/db73987294798d2027b6cca608ff58ce7d1a6161))
* **release:** trigger auto-merge testing ([c472de2](https://github.com/CoReason-AI/coreason-ecosystem/commit/c472de2510e96da2d9322ab902f909acd2aab40a))
* **wasmcloud:** resolve mypy typechecking errors in sidecar and unit tests ([14ced41](https://github.com/CoReason-AI/coreason-ecosystem/commit/14ced412c70cded3d1451dc7fa92ca40d5d3942e))

## [0.11.1](https://github.com/CoReason-AI/coreason-ecosystem/compare/v0.11.0...v0.11.1) (2026-05-13)


### Features

* add CI workflow to automate documentation deployment and package publishing ([64991ee](https://github.com/CoReason-AI/coreason-ecosystem/commit/64991ee19eebf468097c2318b24aaceae04477dc))
* add CI workflow to automate documentation deployment and package publishing ([4490a95](https://github.com/CoReason-AI/coreason-ecosystem/commit/4490a95d36085e55b2d779854df6159dacdfb42e))
* formalize Neurosymbolic Caging Protocol and Epistemic Quarantine directives across agent configuration rules ([603912c](https://github.com/CoReason-AI/coreason-ecosystem/commit/603912c7ed49b20b1b18a535948af9d4fe50a602))
* **governance:** provision thermodynamic boundaries for chaos mesh via RBAC and deployment scripts ([90053a2](https://github.com/CoReason-AI/coreason-ecosystem/commit/90053a2a280fa487d1a23f01b94208605ec4d315))
* implement fleet scaling infrastructure including Skypilot actuator, expansion loop, and mesh injector with aiohttp support. ([26618a1](https://github.com/CoReason-AI/coreason-ecosystem/commit/26618a12e5b0084bfbb10def0a07191c7ef356da))
* implement master MCP gateway and establish comprehensive test suite ([26a5f58](https://github.com/CoReason-AI/coreason-ecosystem/commit/26a5f58714b7ae98e690945167542b2bc5d5d360))
* implement master MCP gateway for federated actuator discovery and execution with comprehensive test suite ([30562be](https://github.com/CoReason-AI/coreason-ecosystem/commit/30562be9b54c5acb39a9374ff8807168d1fa69d5))
* implement MCP gateway module and semantic router with arrow support ([60a39a4](https://github.com/CoReason-AI/coreason-ecosystem/commit/60a39a4a6b0792e4f9b223a231d05bd0dd12e29c))
* implement SemanticRouter and add ML-related dependencies to support intent-based routing ([2fda4ba](https://github.com/CoReason-AI/coreason-ecosystem/commit/2fda4ba4fa5aa9e202024ea14f2d93b8927744ec))
* implement Von Neumann expansion loop, Sovereign MCP registry, and master MCP orchestration modules. ([0632087](https://github.com/CoReason-AI/coreason-ecosystem/commit/063208783eb4b227dda8c4534fbf123d5a5639fd))
* remove deprecated proprietary chaos components ([#133](https://github.com/CoReason-AI/coreason-ecosystem/issues/133)) ([64d4b4e](https://github.com/CoReason-AI/coreason-ecosystem/commit/64d4b4ebc34b71857c8ae50dca4c803e76970eca))
* remove deprecated proprietary chaos components ([#133](https://github.com/CoReason-AI/coreason-ecosystem/issues/133)) ([2f5f2f9](https://github.com/CoReason-AI/coreason-ecosystem/commit/2f5f2f90f68545d5d75cc011ab2beaf016ed40b5))


### Bug Fixes

* add mypy type annotations and fix ruff lint in coverage tests ([36ae316](https://github.com/CoReason-AI/coreason-ecosystem/commit/36ae3166db8b431fe75a035a535944885094865b))
* **ci:** formatting fixes for remaining test files ([b71e876](https://github.com/CoReason-AI/coreason-ecosystem/commit/b71e87629b696a1acb13512e71b7e17e6f5b2063))
* **ci:** resolve deptry and mypy failures in lint-and-audit pipeline ([1da3d25](https://github.com/CoReason-AI/coreason-ecosystem/commit/1da3d25637df3614fbb37b721cc8fb02d73269db))
* **ci:** ruff format to resolve pre-commit failure ([350a9d0](https://github.com/CoReason-AI/coreason-ecosystem/commit/350a9d0a41878cd8af64ef5736ab8c257acec088))
* **ci:** sync release-please manifest version to v0.11.0 ([f76efc9](https://github.com/CoReason-AI/coreason-ecosystem/commit/f76efc95da5c9ed564570224e429f10d8b8ef9a1))
* **ci:** sync release-please manifest version to v0.11.0 ([b5e4e4c](https://github.com/CoReason-AI/coreason-ecosystem/commit/b5e4e4cbb15e1f7e72c64cf30ca6a2c25767cbea))
* **deps:** remove unused prometheus-client and networkx from pyproject ([67795df](https://github.com/CoReason-AI/coreason-ecosystem/commit/67795df40e96296c09140d53ddbadf316909e5c2))
* **fleet:** resolve formatting, whitespace, and Bandit B110 security issue in SkyPilotActuator ([ecf4df0](https://github.com/CoReason-AI/coreason-ecosystem/commit/ecf4df09dbdcb31c703628a7476776a3371dd7e8))
* resolve linting, typing, and security errors in ecosystem ([6337321](https://github.com/CoReason-AI/coreason-ecosystem/commit/63373217851d94ec71db2a60c98c14871f192050))
* Resolve missing mock unused variables ([a1a41cb](https://github.com/CoReason-AI/coreason-ecosystem/commit/a1a41cb3fc2a96bf2bebf85c8b7bf86225830f37))
* Resolve mypy typing issues in tests and master_mcp.py ([f61cc6a](https://github.com/CoReason-AI/coreason-ecosystem/commit/f61cc6a6591d664700ddeae33fa0cb799583f159))
* Resolve pre-commit (whitespace and ruff-format) failures in ecosystem. ([9eb02eb](https://github.com/CoReason-AI/coreason-ecosystem/commit/9eb02eb4eec907a7f21679749bc838f23ecaa7d0))
* **security:** ignore B501 on intentional internal mTLS without verify ([9049e0b](https://github.com/CoReason-AI/coreason-ecosystem/commit/9049e0b1fc25409332d6415668d5901e62d387dc))


### Refactoring

* Finalize Proxy-First amputation by hollowing gateway filtering and substrate resolution. ([b872df1](https://github.com/CoReason-AI/coreason-ecosystem/commit/b872df17c4f1380e02333854e5318a74eebe2275))
* fully delegate OpenShell mTLS and security bounds to sidecar proxy in master_mcp.py ([ddf9e70](https://github.com/CoReason-AI/coreason-ecosystem/commit/ddf9e70919680c51df55775ae37a303e661e2253))
* Just-in-Time Cognition via NemoClaw ([#120](https://github.com/CoReason-AI/coreason-ecosystem/issues/120)) ([99fc088](https://github.com/CoReason-AI/coreason-ecosystem/commit/99fc0883d0f2e932a8d887eef576ba9c0bc6ea37))
* simplify identity logic and remove custom RBAC layer ([#118](https://github.com/CoReason-AI/coreason-ecosystem/issues/118)) ([#119](https://github.com/CoReason-AI/coreason-ecosystem/issues/119)) ([b11a900](https://github.com/CoReason-AI/coreason-ecosystem/commit/b11a90024d03969f4c6f4c48f84b7fc6af8bbc19))


### Tests

* add comprehensive test suite for orchestration, gateway, fleet, and utility modules ([73d12a3](https://github.com/CoReason-AI/coreason-ecosystem/commit/73d12a37a69c52c6e243ea75f7f75c9d8898e904))
* add comprehensive unit and integration test suite for CLI, fleet daemon, and expansion logic ([25aa4b9](https://github.com/CoReason-AI/coreason-ecosystem/commit/25aa4b94cd823e5ee6e7f01f67776fad0d79d49e))
* add comprehensive unit tests and scratch scripts for gateway master MCP integration ([e3f6c15](https://github.com/CoReason-AI/coreason-ecosystem/commit/e3f6c157deec623df94e109afabb8083b1611114))
* add unit and fleet coverage for semantic router error handling and daemon reconciliation logic ([f545271](https://github.com/CoReason-AI/coreason-ecosystem/commit/f545271f51aebd42c7519496c661615ee66ce415))
* **ecosystem:** fix mypy errors in SkyPilotActuator tests ([2f7bcf2](https://github.com/CoReason-AI/coreason-ecosystem/commit/2f7bcf2b31a8775120c4e7e728e79f7e6e9f4280))
* expand coverage for semantic router to 98% ([1d31c43](https://github.com/CoReason-AI/coreason-ecosystem/commit/1d31c43b03ee3335485c2c071c26a486fec75623))
* **fleet:** add unit tests for SkyPilotActuator to ensure 100% coverage ([67f3acf](https://github.com/CoReason-AI/coreason-ecosystem/commit/67f3acf0f330dffa603c7324860187f2e25f9441))
