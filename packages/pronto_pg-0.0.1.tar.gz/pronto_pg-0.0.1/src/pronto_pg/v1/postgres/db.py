"""
Database connection pool
"""

import os
from contextlib import asynccontextmanager

from psycopg_pool import AsyncConnectionPool

_pool: AsyncConnectionPool | None = None


async def init_pool(dsn: str, min_size: int = 2, max_size: int = 10) -> None:
    global _pool
    _pool = AsyncConnectionPool(dsn, min_size=min_size, max_size=max_size, open=False)
    await _pool.open()


async def init_pool_from_env(
    env_var: str = "DATABASE_URL",
    min_size: int = 2,
    max_size: int = 10,
) -> None:
    dsn = os.environ.get(env_var)
    if not dsn:
        raise RuntimeError(f"Environment variable '{env_var}' is not set or empty")
    await init_pool(dsn=dsn, min_size=min_size, max_size=max_size)


async def close_pool() -> None:
    global _pool
    if _pool:
        await _pool.close()
        _pool = None


@asynccontextmanager
async def get_connection():
    """
    Yields a psycopg AsyncConnection in autocommit mode.

    Connections are in autocommit so bare SELECTs don't hold implicit row locks.
    Use ``async with conn.transaction():`` for explicit transactions.
    """
    if _pool is None:
        raise RuntimeError(
            "Pool is not initialised — call init_pool() or init_pool_from_env() first"
        )
    async with _pool.connection() as conn:
        if not conn.autocommit:
            await conn.set_autocommit(True)
        yield conn


def make_lifespan(
    env_var: str = "DATABASE_URL",
    min_size: int = 2,
    max_size: int = 10,
):
    """
    Returns a FastAPI-compatible lifespan context manager.

    Reads the DSN from the named environment variable, opens the pool on
    startup, and closes it on shutdown::

        app = FastAPI(lifespan=make_lifespan("PG_DATABASE_URL"))
    """

    @asynccontextmanager
    async def _lifespan(_app):
        await init_pool_from_env(env_var=env_var, min_size=min_size, max_size=max_size)
        yield
        await close_pool()

    return _lifespan
