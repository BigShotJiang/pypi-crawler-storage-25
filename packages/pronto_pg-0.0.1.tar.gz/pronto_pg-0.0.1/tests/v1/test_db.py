import os

import pytest

import pronto_pg.v1.postgres.db as db_module
from pronto_pg.v1 import close_pool, get_connection, init_pool_from_env, make_lifespan


@pytest.fixture(autouse=True)
async def reset_pool():
    yield
    # ensure each test starts and ends with a clean slate
    if db_module._pool is not None:
        await close_pool()


# ---------------------------------------------------------------------------
# Unit tests — no real database required
# ---------------------------------------------------------------------------


async def test_get_connection_raises_before_init():
    with pytest.raises(RuntimeError, match="not initialised"):
        async with get_connection():
            pass


async def test_init_pool_from_env_missing_var():
    var = "PRONTO_PG_NONEXISTENT_12345"
    os.environ.pop(var, None)
    with pytest.raises(RuntimeError, match=var):
        await init_pool_from_env(var)


async def test_init_pool_from_env_empty_var():
    var = "PRONTO_PG_EMPTY_URL"
    os.environ[var] = ""
    try:
        with pytest.raises(RuntimeError, match=var):
            await init_pool_from_env(var)
    finally:
        del os.environ[var]


# ---------------------------------------------------------------------------
# Integration tests — skipped when DATABASE_URL is not set
# ---------------------------------------------------------------------------

_dsn = os.environ.get("DATABASE_URL", "")
needs_db = pytest.mark.skipif(
    not _dsn, reason="DATABASE_URL not set — skipping integration tests"
)


@needs_db
async def test_init_pool_from_env_connects():
    await init_pool_from_env("DATABASE_URL")
    assert db_module._pool is not None


@needs_db
async def test_get_connection_executes_query():
    await init_pool_from_env("DATABASE_URL")
    async with get_connection() as conn:
        result = await conn.execute("SELECT 1 AS val")
        row = await result.fetchone()
    assert row[0] == 1


@needs_db
async def test_get_connection_is_autocommit():
    await init_pool_from_env("DATABASE_URL")
    async with get_connection() as conn:
        assert conn.autocommit is True


@needs_db
async def test_close_pool_resets_state():
    await init_pool_from_env("DATABASE_URL")
    assert db_module._pool is not None
    await close_pool()
    assert db_module._pool is None


@needs_db
async def test_make_lifespan_opens_and_closes_pool():
    lifespan = make_lifespan("DATABASE_URL")
    async with lifespan(None):
        async with get_connection() as conn:
            result = await conn.execute("SELECT 42 AS val")
            row = await result.fetchone()
        assert row[0] == 42
    # pool must be closed and nulled after lifespan exits
    assert db_module._pool is None


@needs_db
async def test_make_lifespan_custom_env_var():
    os.environ["MY_PG_URL"] = _dsn
    try:
        lifespan = make_lifespan("MY_PG_URL")
        async with lifespan(None):
            async with get_connection() as conn:
                result = await conn.execute("SELECT 'ok' AS status")
                row = await result.fetchone()
            assert row[0] == "ok"
    finally:
        del os.environ["MY_PG_URL"]
