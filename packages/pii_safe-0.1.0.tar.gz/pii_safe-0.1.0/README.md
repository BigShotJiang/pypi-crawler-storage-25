# pii-safe — Redact PII from text

[![PyPI](https://img.shields.io/pypi/v/pii-safe.svg)](https://pypi.org/project/pii-safe/)
[![Python](https://img.shields.io/pypi/pyversions/pii-safe.svg)](https://pypi.org/project/pii-safe/)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

## Install

```bash
pip install pii-safe
```

## Usage

```python
from pii_safe import redact_text

text = "mi nombre es Dario Clavijo"
redacted = redact_text(text)
print(redacted)  # mi nombre es[REDACTED_10eda051]
```

### Using the Redacter class

```python
from pii_safe import Redacter

redacter = Redacter()
result1 = redacter.redact("mi nombre es Dario Clavijo")
result2 = redacter.redact("el es Dario Clavijo")

# Same PII gets consistent hash
hash_map = redacter.get_hash_map()
print(hash_map)  # {'Dario Clavijo': '10eda051'}
```

## CLI

```bash
pii-safe input.txt
pii-safe input.txt -o output.txt
```

## Development

```bash
git clone https://github.com/daedalus/pii-safe.git
cd pii-safe
pip install -e ".[test]"

# run tests
pytest

# format
ruff format src/ tests/

# lint
ruff check src/ tests/

# type check
mypy src/
```

## API

### `redact_text(text: str) -> str`

Redacts PII from text using the openai/privacy-filter model.

### `class Redacter`

Context manager for consistent PII-to-hash mapping across calls.

- `redact(text: str) -> str`: Redact PII from text
- `get_hash_map() -> dict[str, str]`: Get PII-to-hash mapping