"""CLI entry point for pii-safe."""

from __future__ import annotations

import sys
from pathlib import Path

from pii_safe._core import ModelError, redact_text


def main() -> int:
    """Run the CLI.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    args = sys.argv[1:]

    if not args or "-h" in args or "--help" in args:
        print("Usage: pii-safe <input_file> [--output <output_file>]")
        print("       pii-safe --help")
        print()
        print("Redact PII from text files.")
        print()
        print("Options:")
        print("  -o, --output  Output file (default: stdout)")
        return 0

    input_file = Path(args[0])
    output_file = None

    if "--output" in args or "-o" in args:
        idx = args.index("--output") if "--output" in args else args.index("-o")
        if idx + 1 < len(args):
            output_file = Path(args[idx + 1])

    if not input_file.exists():
        print(f"Error: File not found: {input_file}", file=sys.stderr)
        return 1

    try:
        text = input_file.read_text(encoding="utf-8")
    except OSError as e:
        print(f"Error: Failed to read file: {e}", file=sys.stderr)
        return 1

    try:
        redacted = redact_text(text)
    except ModelError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    if output_file:
        try:
            output_file.write_text(redacted, encoding="utf-8")
        except OSError as e:
            print(f"Error: Failed to write file: {e}", file=sys.stderr)
            return 1
    else:
        print(redacted)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
