"""Core redacting functionality for PII from text."""

from __future__ import annotations

import hashlib
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable

from transformers import pipeline


class ModelError(Exception):
    """Raised when the privacy filter model fails to load or run."""

    pass


class Redacter:
    """PII redacting context manager for consistent hash mappings across calls.

    This class loads the openai/privacy-filter model once and maintains a mapping
    of PII values to their hashes, ensuring consistent redaction across
    multiple calls.

    Attributes:
        _classifier: The transformers pipeline for token classification.
        _pii_map: Dictionary mapping original PII values to their hashes.
    """

    def __init__(self) -> None:
        """Initialize the redacter with privacy filter model."""
        self._classifier: Callable[[Any], list[dict[str, Any]]] | None = None
        self._pii_map: dict[str, str] = {}

    def _get_classifier(self) -> Callable[[Any], list[dict[str, Any]]]:
        """Lazy-load the classifier pipeline.

        Returns:
            The transformers pipeline for token classification.

        Raises:
            ModelError: If the model fails to load.
        """
        if self._classifier is None:
            try:
                self._classifier = pipeline(
                    task="token-classification",
                    model="openai/privacy-filter",
                )
            except Exception as e:
                msg = f"Failed to load privacy-filter model: {e}"
                raise ModelError(msg) from e
        return self._classifier

    def _get_pii_hash(self, pii_text: str) -> str:
        """Generate a hash for the given PII text.

        Args:
            pii_text: The PII text to hash.

        Returns:
            First 8 characters of SHA256 hash of the PII text.
        """
        return hashlib.sha256(pii_text.encode()).hexdigest()[:8]

    def _reconstruct_pii(
        self, tokens: list[dict[str, Any]]
    ) -> list[tuple[int, int, str]]:
        """Reconstruct PII entities from tokens.

        Args:
            tokens: List of tokens from the classifier.

        Returns:
            List of (start, end, pii_text) tuples for detected PII.
        """
        pii_entities: list[tuple[int, int, str]] = []
        current_pii: str = ""
        current_start: int = -1
        current_end: int = -1

        for token in tokens:
            entity = token.get("entity", "")
            start = token["start"]
            end = token["end"]
            word = token["word"].replace("Ġ", " ")

            if entity.startswith("B-"):
                if current_pii and current_start >= 0:
                    pii_entities.append((current_start, current_end, current_pii))
                current_pii = word
                current_start = start
                current_end = end
            elif entity.startswith(("I-", "E-", "S-")) and current_start >= 0:
                current_pii += word
                current_end = end
            else:
                if current_pii and current_start >= 0:
                    pii_entities.append((current_start, current_end, current_pii))
                current_pii = ""
                current_start = -1
                current_end = -1

        if current_pii and current_start >= 0:
            pii_entities.append((current_start, current_end, current_pii))

        return pii_entities

    def redact(self, text: str) -> str:
        """Redact PII from text.

        Args:
            text: Input text containing PII.

        Returns:
            Text with PII replaced by [REDACTED_<hash>].

        Raises:
            TypeError: If text is not a string.
            ModelError: If the model fails to process the text.
        """
        if not isinstance(text, str):
            msg = f"Expected str, got {type(text).__name__}"
            raise TypeError(msg)

        if not text:
            return text

        classifier = self._get_classifier()

        try:
            results = classifier(text)
        except Exception as e:
            msg = f"Failed to process text: {e}"
            raise ModelError(msg) from e

        pii_entities = self._reconstruct_pii(results)

        if not pii_entities:
            return text

        redacted_parts: list[str] = []
        current_pos = 0

        for start, end, pii_text in pii_entities:
            pii_hash = self._pii_map.get(pii_text)
            if pii_hash is None:
                pii_hash = self._get_pii_hash(pii_text)
                self._pii_map[pii_text] = pii_hash

            redacted_parts.append(text[current_pos:start])
            redacted_parts.append(f"[REDACTED_{pii_hash}]")
            current_pos = end

        redacted_parts.append(text[current_pos:])

        return "".join(redacted_parts)

    def get_hash_map(self) -> dict[str, str]:
        """Get the mapping of PII values to hashes.

        Returns:
            Dictionary mapping original PII to its hash.
        """
        return dict(self._pii_map)


_default_redacter: Redacter | None = None


def redact_text(text: str) -> str:
    """Redact PII from text.

    Uses a shared Redacter instance for consistent hashing.

    Args:
        text: Input text containing PII.

    Returns:
        Text with PII replaced by [REDACTED_<hash>].

    Example:
        >>> redact_text("mi nombre es Dario Clavijo")
        "mi nombre es[REDACTED_10eda051]"

    Raises:
        TypeError: If text is not a string.
        ModelError: If the model fails to process the text.
    """
    global _default_redacter
    if _default_redacter is None:
        _default_redacter = Redacter()
    return _default_redacter.redact(text)
