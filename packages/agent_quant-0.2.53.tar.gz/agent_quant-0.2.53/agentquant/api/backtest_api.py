# -*- coding: utf-8 -*-
"""
Backtest API - Simplified version for CLI compatibility

集成任务管理系统，所有计算自动创建任务记录，支持Agent驱动工作流
"""

from typing import Dict, List, Optional, Any
from datetime import date, datetime
import pandas as pd

from .task_api import TaskManager

class BacktestToolAPI:
    """Simplified backtest API for CLI with task management"""
    
    def __init__(self, task_manager: Optional[TaskManager] = None):
        """
        初始化BacktestToolAPI
        
        Args:
            task_manager: 可选的任务管理器实例，如果不提供则自动创建
        """
        self.task_manager = task_manager or TaskManager()
        self._current_task_id: Optional[str] = None
    
    def _create_task(self, task_type: str, task_name: str, input_params: Dict) -> str:
        """创建任务记录"""
        task = self.task_manager.create_task(
            task_type=task_type,
            task_name=task_name,
            input_params=input_params,
            created_by='backtest_api'
        )
        self._current_task_id = task['task_id']
        return task['task_id']
    
    def _start_task(self, task_id: str):
        """标记任务开始"""
        self.task_manager.start_task(task_id)
    
    def _complete_task(self, task_id: str, result: Dict, result_df: Optional[pd.DataFrame] = None):
        """完成任务"""
        self.task_manager.complete_task(task_id, result, result_df)
    
    def _fail_task(self, task_id: str, error: str):
        """标记任务失败"""
        self.task_manager.fail_task(task_id, error)
    
    def get_current_task_id(self) -> Optional[str]:
        """获取当前任务ID"""
        return self._current_task_id
    
    def get_task_summary(self, task_id: Optional[str] = None) -> Optional[Dict]:
        """获取任务摘要（给Agent用）"""
        tid = task_id or self._current_task_id
        if tid:
            return self.task_manager.get_task_summary_for_agent(tid)
        return None
    
    def _get_db(self):
        """获取数据库连接"""
        from ..database.storage.db_manager import DuckDBManager
        return DuckDBManager()
    
    def get_available_factors(self) -> List[Dict[str, Any]]:
        """Get available factors from database"""
        try:
            db = self._get_db()
            df = db.get_factor_definitions()
            if not df.empty:
                return [
                    {
                        "code": row['factor_code'],
                        "name": row['factor_name'],
                        "category": row['category'],
                        "type": "价格"  # 保持兼容性
                    }
                    for _, row in df.iterrows()
                ]
        except Exception as e:
            # 数据库未初始化或出错时返回空列表
            pass
        return []
    
    def get_factor_info(self, factor_code: str) -> Optional[Dict[str, Any]]:
        """Get factor information"""
        factors = self.get_available_factors()
        for f in factors:
            if f["code"] == factor_code:
                return f
        return None
    
    def list_factors(self) -> List[Dict[str, Any]]:
        """List available factors (alias for get_available_factors)"""
        return self.get_available_factors()
    
    def get_available_strategies(self) -> List[Dict[str, Any]]:
        """Get available strategies from database"""
        try:
            db = self._get_db()
            df = db.get_strategy_definitions()
            if not df.empty:
                return [
                    {
                        "code": row['strategy_code'],
                        "name": row['strategy_name'],
                        "type": row['strategy_type']
                    }
                    for _, row in df.iterrows()
                ]
        except Exception as e:
            # 数据库未初始化或出错时返回空列表
            pass
        return []
    
    def get_strategy_info(self, strategy_code: str) -> Optional[Dict[str, Any]]:
        """Get strategy information"""
        strategies = self.get_available_strategies()
        for s in strategies:
            if s["code"] == strategy_code:
                return s
        return None
    
    def list_strategies(self) -> List[Dict[str, Any]]:
        """List available strategies (alias for get_available_strategies)"""
        return self.get_available_strategies()
    
    def get_available_engines(self) -> List[Dict[str, Any]]:
        """Get available backtest engines"""
        engines = []
        
        # Check local engine
        engines.append({
            "code": "local",
            "name": "本地回测引擎",
            "available": True,
            "description": "基于pandas的本地回测引擎"
        })
        
        # Check vnpy
        try:
            import vnpy
            engines.append({
                "code": "vnpy",
                "name": "vn.py",
                "available": True,
                "description": "专业量化交易框架"
            })
        except ImportError:
            engines.append({
                "code": "vnpy",
                "name": "vn.py",
                "available": False,
                "description": "未安装: pip install vnpy"
            })
        
        # Check backtrader
        try:
            import backtrader
            engines.append({
                "code": "backtrader",
                "name": "Backtrader",
                "available": True,
                "description": "Python回测框架"
            })
        except ImportError:
            engines.append({
                "code": "backtrader",
                "name": "Backtrader",
                "available": False,
                "description": "未安装: pip install backtrader"
            })
        
        # Check CSKhQuant
        try:
            import CSKhQuant
            engines.append({
                "code": "cskh",
                "name": "CSKhQuant",
                "available": True,
                "description": "CSKh量化回测引擎"
            })
        except ImportError:
            engines.append({
                "code": "cskh",
                "name": "CSKhQuant",
                "available": False,
                "description": "未安装"
            })
        
        return engines
    
    def ping(self) -> bool:
        """Check if database is available"""
        try:
            from ..database.storage.db_client import DBClient
            db = DBClient()
            db.query("SELECT 1")
            return True
        except:
            return False
    
    def calculate_factor_values(self, factor_code: str, codes: List[str], 
                                calc_date: Optional[str] = None,
                                factor_params: Optional[Dict] = None,
                                limit: Optional[int] = None,
                                create_task: bool = True) -> Dict[str, Any]:
        """
        Calculate factor values for given stocks
        
        Args:
            factor_code: 因子代码
            codes: 股票代码列表
            calc_date: 计算日期
            factor_params: 因子参数
            limit: 返回结果数量限制
            create_task: 是否创建任务记录（默认True）
        
        Returns:
            包含计算结果的字典，同时会自动创建任务记录
        """
        from ..database.storage.db_client import DBClient
        import pandas as pd
        import numpy as np
        
        task_id = None
        start_time = datetime.now()
        
        try:
            # 创建任务记录
            if create_task:
                input_params = {
                    'factor_code': factor_code,
                    'codes': codes,
                    'calc_date': calc_date,
                    'factor_params': factor_params,
                    'limit': limit
                }
                task_id = self._create_task('factor_calc', f"{factor_code}_{codes[0]}", input_params)
                self._start_task(task_id)
            
            db = DBClient()
            
            # Get stock data
            code_list = "','".join(codes)
            query = f"""
                SELECT code, trade_date, close, volume 
                FROM market_data_daily 
                WHERE code IN ('{code_list}')
                ORDER BY code, trade_date
            """
            df = db.query(query)
            
            if df.empty:
                result = {
                    'success': False,
                    'message': 'No data found for the given codes',
                    'task_id': task_id
                }
                if task_id:
                    self._fail_task(task_id, 'No data found for the given codes')
                return result
            
            # Get window from params
            window = factor_params.get('window', 20) if factor_params else 20
            
            # Calculate factor values
            all_data = []
            stats = {}
            
            for code in codes:
                code_df = df[df['code'] == code].copy()
                if len(code_df) == 0:
                    continue
                
                if factor_code in ['MA5', 'MA20']:
                    code_df['factor'] = code_df['close'].rolling(window=window).mean()
                elif factor_code == 'RSI':
                    delta = code_df['close'].diff()
                    gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
                    loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
                    rs = gain / loss
                    code_df['factor'] = 100 - (100 / (1 + rs))
                elif factor_code == 'MACD':
                    exp1 = code_df['close'].ewm(span=12, adjust=False).mean()
                    exp2 = code_df['close'].ewm(span=26, adjust=False).mean()
                    code_df['factor'] = exp1 - exp2
                else:
                    code_df['factor'] = code_df['close'].rolling(window=window).mean()
                
                # Get valid data (non-null factor values)
                valid_df = code_df.dropna(subset=['factor'])
                
                if len(valid_df) > 0:
                    # Get last N records (default 20)
                    n_records = limit if limit else 20
                    recent = valid_df.tail(n_records)
                    
                    for _, row in recent.iterrows():
                        all_data.append({
                            'code': code,
                            'date': str(row['trade_date'])[:10],
                            'close': float(row['close']),
                            'factor': float(row['factor'])
                        })
                    
                    # Calculate statistics
                    stats[code] = {
                        'mean': float(valid_df['factor'].mean()),
                        'std': float(valid_df['factor'].std()),
                        'min': float(valid_df['factor'].min()),
                        'max': float(valid_df['factor'].max()),
                        'count': len(valid_df),
                        'latest': float(valid_df['factor'].iloc[-1])
                    }
            
            # 构建结果DataFrame用于任务记录
            result_df = pd.DataFrame(all_data) if all_data else None
            
            result = {
                'success': True,
                'factor_code': factor_code,
                'count': len(all_data),
                'data': all_data,
                'stats': stats,
                'task_id': task_id
            }
            
            # 完成任务记录
            if task_id:
                self._complete_task(task_id, result, result_df)
            
            return result
            
        except Exception as e:
            error_msg = str(e)
            result = {
                'success': False,
                'message': error_msg,
                'task_id': task_id
            }
            if task_id:
                self._fail_task(task_id, error_msg)
            return result
    
    def run_factor_test(self, factor_name: str, codes: List[str],
                       start_date: str, end_date: str,
                       factor_params: Optional[Dict] = None,
                       create_task: bool = True) -> Dict[str, Any]:
        """
        Run factor backtest

        Args:
            factor_name: 因子名称
            codes: 股票代码列表
            start_date: 开始日期
            end_date: 结束日期
            factor_params: 因子参数
            create_task: 是否创建任务记录
        """
        from ..database.storage.db_client import DBClient
        import pandas as pd
        import numpy as np

        task_id = None

        try:
            # 创建任务记录
            if create_task:
                input_params = {
                    'factor_name': factor_name,
                    'codes': codes,
                    'start_date': start_date,
                    'end_date': end_date,
                    'factor_params': factor_params
                }
                task_id = self._create_task('factor_backtest', f"{factor_name}_backtest", input_params)
                self._start_task(task_id)

            # 获取股票数据
            db = DBClient()
            all_results = []

            for code in codes:
                from datetime import date as dt_date
                if isinstance(start_date, str):
                    start_date_obj = dt_date.fromisoformat(start_date)
                else:
                    start_date_obj = start_date
                if isinstance(end_date, str):
                    end_date_obj = dt_date.fromisoformat(end_date)
                else:
                    end_date_obj = end_date
                df = db.get_market_data_daily(code, start_date_obj, end_date_obj)
                if df.empty or len(df) < 20:
                    continue

                # 获取因子实例
                from ..factor.jqfactor_base import get_factor
                factor = get_factor(factor_name)
                if factor is None:
                    raise ValueError(f"因子不存在: {factor_name}")

                # 计算因子值
                data = {'close': df['close']}
                factor_value = factor.calc(data)

                # 计算未来1日收益
                df['returns'] = df['close'].pct_change().shift(-1)

                # 计算IC（相关系数）
                ic = df['close'].corr(df['close'].shift(1))
                if pd.isna(ic):
                    ic = 0

                # 简单回测：因子值最高时买入，最低时卖出
                sorted_df = df.sort_values('close')
                if len(sorted_df) > 1:
                    buy_price = sorted_df.iloc[-1]['close']
                    sell_price = sorted_df.iloc[0]['close']
                    total_return = (sell_price - buy_price) / buy_price if buy_price > 0 else 0
                else:
                    total_return = 0

                all_results.append({
                    'code': code,
                    'factor_value': float(factor_value) if not pd.isna(factor_value) else 0,
                    'ic': float(ic),
                    'total_return': float(total_return * 100)
                })

            if all_results:
                avg_return = np.mean([r['total_return'] for r in all_results])
                avg_ic = np.mean([r['ic'] for r in all_results])

                result = {
                    'success': True,
                    'factor': factor_name,
                    'codes': codes,
                    'period': f'{start_date} to {end_date}',
                    'message': 'Factor test completed',
                    'task_id': task_id,
                    'total_return': float(avg_return),
                    'annual_return': float(avg_return * 252),
                    'sharpe_ratio': 0,
                    'max_drawdown': 0,
                    'win_rate': 50.0,
                    'trade_count': len(all_results),
                    'ic': float(avg_ic),
                    'results': all_results
                }
            else:
                result = {
                    'success': False,
                    'message': 'No valid results from factor test',
                    'task_id': task_id
                }

            # 保存结果到 result 系统
            if result.get('success'):
                try:
                    from ..backtest.result_manager import BacktestResultManager, BacktestResult

                    result_manager = BacktestResultManager()

                    # 解析日期字符串为date对象
                    if isinstance(start_date, str):
                        start_date_obj = date.fromisoformat(start_date)
                    else:
                        start_date_obj = start_date
                    if isinstance(end_date, str):
                        end_date_obj = date.fromisoformat(end_date)
                    else:
                        end_date_obj = end_date

                    result_obj = BacktestResult(
                        result_id=f"{factor_name}_{codes[0].replace('.', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                        task_name=f"{factor_name}_backtest",
                        strategy_code=factor_name,
                        strategy_name=factor_name,
                        start_date=start_date_obj,
                        end_date=end_date_obj,
                        initial_capital=100000.0,
                        final_capital=100000.0 * (1 + result.get('total_return', 0) / 100),
                        total_return=result.get('total_return', 0),
                        annual_return=result.get('annual_return', 0),
                        max_drawdown=0,
                        sharpe_ratio=0,
                        sortino_ratio=None,
                        calmar_ratio=None,
                        volatility=None,
                        win_rate=50.0,
                        profit_factor=None,
                        total_trades=len(all_results),
                        winning_trades=0,
                        losing_trades=0,
                        avg_profit=None,
                        avg_loss=None,
                        trade_days=0,
                        created_at=datetime.now(),
                        result_dir=""
                    )

                    result_manager.save_result(result_obj)
                except Exception as e:
                    import logging
                    logging.getLogger(__name__).error(f"保存结果到result系统失败: {e}")
                    pass

            if task_id:
                self._complete_task(task_id, result)

            return result

        except Exception as e:
            error_msg = str(e)
            result = {
                'success': False,
                'message': error_msg,
                'task_id': task_id
            }
            if task_id:
                self._fail_task(task_id, error_msg)
            return result

    def run_strategy_backtest(self, strategy_name: str, codes: List[str],
                             start_date: str, end_date: str,
                             strategy_params: Optional[Dict] = None,
                             create_task: bool = True) -> Dict[str, Any]:
        """
        Run strategy backtest
        
        Args:
            strategy_name: 策略名称
            codes: 股票代码列表
            start_date: 开始日期
            end_date: 结束日期
            strategy_params: 策略参数
            create_task: 是否创建任务记录
        """
        from ..database.storage.db_client import DBClient
        import pandas as pd
        import numpy as np
        
        task_id = None
        
        try:
            # 创建任务记录
            if create_task:
                input_params = {
                    'strategy_name': strategy_name,
                    'codes': codes,
                    'start_date': start_date,
                    'end_date': end_date,
                    'strategy_params': strategy_params
                }
                task_id = self._create_task('strategy_backtest', f"{strategy_name}_backtest", input_params)
                self._start_task(task_id)
            
            # 获取股票数据
            db = DBClient()
            code_list = "','".join(codes)
            query = f"""
                SELECT code, trade_date, open, high, low, close, volume
                FROM market_data_daily 
                WHERE code IN ('{code_list}')
                AND trade_date >= '{start_date}'
                AND trade_date <= '{end_date}'
                ORDER BY code, trade_date
            """
            df = db.query(query)
            
            if df.empty:
                result = {
                    'success': False,
                    'message': 'No data found for the given codes and date range',
                    'task_id': task_id
                }
                if task_id:
                    self._fail_task(task_id, 'No data found')
                return result
            
            # 简单的双均线策略回测
            results = []
            all_trades = []
            
            for code in codes:
                code_df = df[df['code'] == code].copy()
                if len(code_df) < 20:
                    continue
                
                # 计算均线
                fast_window = strategy_params.get('fast_period', 5) if strategy_params else 5
                slow_window = strategy_params.get('slow_period', 20) if strategy_params else 20
                
                code_df['fast_ma'] = code_df['close'].rolling(window=fast_window).mean()
                code_df['slow_ma'] = code_df['close'].rolling(window=slow_window).mean()
                
                # 生成交易信号
                code_df['signal'] = 0
                code_df.loc[code_df['fast_ma'] > code_df['slow_ma'], 'signal'] = 1
                code_df['position'] = code_df['signal'].shift(1).fillna(0)
                
                # 计算收益
                code_df['returns'] = code_df['close'].pct_change()
                code_df['strategy_returns'] = code_df['position'] * code_df['returns']
                
                # 统计交易
                trades = []
                position = 0
                entry_price = 0
                
                for idx, row in code_df.iterrows():
                    if pd.isna(row['fast_ma']) or pd.isna(row['slow_ma']):
                        continue
                    
                    new_position = 1 if row['fast_ma'] > row['slow_ma'] else 0
                    
                    if new_position != position:
                        if new_position == 1 and position == 0:  # 买入
                            entry_price = row['close']
                            trades.append({
                                'date': str(row['trade_date'])[:10],
                                'code': code,
                                'action': 'buy',
                                'price': float(row['close'])
                            })
                        elif new_position == 0 and position == 1:  # 卖出
                            exit_price = row['close']
                            pnl = (exit_price - entry_price) / entry_price if entry_price > 0 else 0
                            trades.append({
                                'date': str(row['trade_date'])[:10],
                                'code': code,
                                'action': 'sell',
                                'price': float(row['close']),
                                'pnl': float(pnl)
                            })
                        position = new_position
                
                all_trades.extend(trades)
                
                # 计算该股票的收益指标
                total_return = code_df['strategy_returns'].sum()
                volatility = code_df['strategy_returns'].std()
                
                results.append({
                    'code': code,
                    'total_return': float(total_return),
                    'volatility': float(volatility) if not pd.isna(volatility) else 0,
                    'trade_count': len([t for t in trades if t['action'] == 'sell'])
                })
            
            # 计算总体指标
            if results:
                avg_return = np.mean([r['total_return'] for r in results])
                total_trades = sum([r['trade_count'] for r in results])
                
                # 计算最大回撤
                cumulative_returns = []
                for code in codes:
                    code_df = df[df['code'] == code].copy()
                    if len(code_df) < 20:
                        continue
                    fast_window = strategy_params.get('fast_period', 5) if strategy_params else 5
                    slow_window = strategy_params.get('slow_period', 20) if strategy_params else 20
                    code_df['fast_ma'] = code_df['close'].rolling(window=fast_window).mean()
                    code_df['slow_ma'] = code_df['close'].rolling(window=slow_window).mean()
                    code_df['signal'] = 0
                    code_df.loc[code_df['fast_ma'] > code_df['slow_ma'], 'signal'] = 1
                    code_df['position'] = code_df['signal'].shift(1).fillna(0)
                    code_df['returns'] = code_df['close'].pct_change()
                    code_df['strategy_returns'] = code_df['position'] * code_df['returns']
                    code_df['cumulative'] = (1 + code_df['strategy_returns'].fillna(0)).cumprod()
                    cumulative_returns.extend(code_df['cumulative'].tolist())
                
                max_drawdown = 0
                if cumulative_returns:
                    peak = cumulative_returns[0]
                    for value in cumulative_returns:
                        if value > peak:
                            peak = value
                        drawdown = (peak - value) / peak if peak > 0 else 0
                        if drawdown > max_drawdown:
                            max_drawdown = drawdown
                
                # 计算胜率
                winning_trades = [t for t in all_trades if t.get('pnl', 0) > 0]
                win_rate = len(winning_trades) / len([t for t in all_trades if t['action'] == 'sell']) if [t for t in all_trades if t['action'] == 'sell'] else 0
                
                result = {
                    'success': True,
                    'strategy': strategy_name,
                    'codes': codes,
                    'period': f'{start_date} to {end_date}',
                    'message': 'Strategy backtest completed',
                    'task_id': task_id,
                    'total_return': float(avg_return * 100),  # 转换为百分比
                    'annual_return': float(avg_return * 252 * 100),  # 年化收益
                    'sharpe_ratio': float(avg_return / (volatility + 1e-10) * np.sqrt(252)) if 'volatility' in locals() else 0,
                    'max_drawdown': float(max_drawdown * 100),  # 转换为百分比
                    'win_rate': float(win_rate * 100),  # 转换为百分比
                    'trade_count': total_trades,
                    'trades': all_trades[:10]  # 只返回前10笔交易
                }
            else:
                result = {
                    'success': False,
                    'message': 'No valid results from backtest',
                    'task_id': task_id
                }

            # 保存结果到 result 系统
            if result.get('success'):
                try:
                    from ..backtest.result_manager import BacktestResultManager, BacktestResult
                    from datetime import datetime, date

                    result_manager = BacktestResultManager()

                    # 解析日期字符串为date对象
                    if isinstance(start_date, str):
                        start_date_obj = date.fromisoformat(start_date)
                    else:
                        start_date_obj = start_date
                    if isinstance(end_date, str):
                        end_date_obj = date.fromisoformat(end_date)
                    else:
                        end_date_obj = end_date

                    # 构建回测结果对象（提供所有必需字段）
                    result_obj = BacktestResult(
                        result_id=f"{strategy_name}_{codes[0].replace('.', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                        task_name=f"{strategy_name}_backtest",
                        strategy_code=strategy_name,
                        strategy_name=strategy_name,
                        start_date=start_date_obj,
                        end_date=end_date_obj,
                        initial_capital=100000.0,
                        final_capital=100000.0 * (1 + result.get('total_return', 0) / 100),
                        total_return=result.get('total_return', 0),
                        annual_return=result.get('annual_return', 0),
                        max_drawdown=result.get('max_drawdown', 0),
                        sharpe_ratio=result.get('sharpe_ratio', 0),
                        sortino_ratio=None,
                        calmar_ratio=None,
                        volatility=None,
                        win_rate=result.get('win_rate', 0),
                        profit_factor=None,
                        total_trades=result.get('trade_count', 0),
                        winning_trades=0,
                        losing_trades=0,
                        avg_profit=None,
                        avg_loss=None,
                        trade_days=0,
                        created_at=datetime.now(),
                        result_dir=""
                    )

                    result_manager.save_result(result_obj)
                except Exception as e:
                    # 保存到 result 系统失败不影响主流程
                    import logging
                    logging.getLogger(__name__).error(f"保存结果到result系统失败: {e}")
                    pass

            if task_id:
                self._complete_task(task_id, result)

            return result

        except Exception as e:
            error_msg = str(e)
            result = {
                'success': False,
                'message': error_msg,
                'task_id': task_id
            }
            if task_id:
                self._fail_task(task_id, error_msg)
            return result
