# -*- coding: utf-8 -*-
"""
策略开发 CLI 子命令
提供基于 CLI 的策略开发功能
"""

import argparse
import json
import os
from datetime import datetime


# 策略模板定义
STRATEGY_TEMPLATES = [
    {
        "code": "DUAL_MA",
        "name": "双均线策略",
        "description": "基于快线和慢线交叉产生买卖信号的经典趋势跟踪策略",
        "category": "趋势策略",
        "params": {
            "fast_period": {"default": 5, "min": 2, "max": 30, "description": "快线周期"},
            "slow_period": {"default": 20, "min": 5, "max": 120, "description": "慢线周期"}
        }
    },
    {
        "code": "MACD_STRATEGY",
        "name": "MACD策略",
        "description": "基于MACD指标金叉死叉产生交易信号",
        "category": "趋势策略",
        "params": {
            "fast": {"default": 12, "min": 5, "max": 30, "description": "快线周期"},
            "slow": {"default": 26, "min": 10, "max": 60, "description": "慢线周期"},
            "signal": {"default": 9, "min": 3, "max": 20, "description": "信号周期"}
        }
    },
    {
        "code": "RSI_STRATEGY",
        "name": "RSI策略",
        "description": "基于RSI超买超卖产生交易信号",
        "category": "震荡策略",
        "params": {
            "period": {"default": 14, "min": 5, "max": 30, "description": "RSI周期"},
            "overbought": {"default": 70, "min": 50, "max": 90, "description": "超买阈值"},
            "oversold": {"default": 30, "min": 10, "max": 50, "description": "超卖阈值"}
        }
    },
    {
        "code": "BOLLINGER_BANDS",
        "name": "布林带策略",
        "description": "基于布林带上下轨突破产生交易信号",
        "category": "通道策略",
        "params": {
            "period": {"default": 20, "min": 10, "max": 50, "description": "布林带周期"},
            "std_dev": {"default": 2, "min": 1, "max": 4, "description": "标准差倍数"}
        }
    },
    {
        "code": "MOMENTUM",
        "name": "动量策略",
        "description": "基于价格动量产生交易信号",
        "category": "动量策略",
        "params": {
            "period": {"default": 10, "min": 5, "max": 30, "description": "动量周期"},
            "threshold": {"default": 0.02, "min": 0.001, "max": 0.1, "description": "动量阈值"}
        }
    }
]


def cmd_strategy_dev_create(args):
    """创建策略"""
    # 使用参数或交互式输入
    name = args.name if args.name else input("策略名称: ")
    template = args.template if args.template else input(f"选择模板 ({', '.join([t['code'] for t in STRATEGY_TEMPLATES])}): ")
    
    # 验证模板
    template_obj = None
    for t in STRATEGY_TEMPLATES:
        if t['code'] == template:
            template_obj = t
            break
    
    if not template_obj:
        print(json.dumps({
            "success": False,
            "message": f"未知模板: {template}"
        }, ensure_ascii=False, indent=2))
        return 1
    
    # 构建策略配置
    strategy_config = {
        "name": name,
        "template": template,
        "description": args.description if args.description else f"基于{template_obj['name']}的自定义策略",
        "params": {},
        "created_at": datetime.now().isoformat()
    }
    
    # 设置参数
    if args.params:
        try:
            strategy_config["params"] = json.loads(args.params)
        except json.JSONDecodeError:
            print(json.dumps({
                "success": False,
                "message": "参数格式错误，请使用JSON格式"
            }, ensure_ascii=False, indent=2))
            return 1
    else:
        # 使用模板默认参数
        for param_name, param_def in template_obj['params'].items():
            strategy_config["params"][param_name] = param_def['default']
    
    # 保存策略文件
    output_dir = args.output if args.output else "strategies"
    os.makedirs(output_dir, exist_ok=True)
    
    filename = f"{name.replace(' ', '_')}.json"
    filepath = os.path.join(output_dir, filename)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(strategy_config, f, ensure_ascii=False, indent=2)
    
    print(json.dumps({
        "success": True,
        "message": f"策略创建成功: {filepath}",
        "strategy": strategy_config
    }, ensure_ascii=False, indent=2))
    return 0


def cmd_strategy_dev_list(args):
    """列出策略模板"""
    print(json.dumps({
        "success": True,
        "count": len(STRATEGY_TEMPLATES),
        "templates": STRATEGY_TEMPLATES
    }, ensure_ascii=False, indent=2))
    return 0


def setup_strategy_dev_parser(subparsers):
    """设置 strategy-dev 子命令解析器"""
    dev_parser = subparsers.add_parser('strategy-dev', help='策略开发工具')
    dev_subparsers = dev_parser.add_subparsers(dest='dev_command', help='策略开发命令')
    
    # create 命令
    create_parser = dev_subparsers.add_parser('create', help='创建策略')
    create_parser.add_argument('--name', type=str, help='策略名称')
    create_parser.add_argument('--template', type=str, help='策略模板代码')
    create_parser.add_argument('--description', type=str, help='策略描述')
    create_parser.add_argument('--params', type=str, help='策略参数（JSON格式）')
    create_parser.add_argument('--output', type=str, help='输出目录')
    create_parser.set_defaults(func=cmd_strategy_dev_create)
    
    # list 命令
    list_parser = dev_subparsers.add_parser('list-templates', help='列出策略模板')
    list_parser.set_defaults(func=cmd_strategy_dev_list)
