# -*- coding: utf-8 -*-
"""
StockClaw CLI 命令行工具

提供命令行接口供Agent调用，封装所有对外API功能

使用方法:
    # 更新数据
    python -m agentquant.cli update --codes 000001.SZ --date 2026-04-20
    
    # 查询数据
    python -m agentquant.cli query --code 000001.SZ --start 2026-04-17 --end 2026-04-20
    
    # 获取最新日期
    python -m agentquant.cli latest
    
    # 获取股票列表
    python -m agentquant.cli stocks
    
    # 回测
    python -m agentquant.cli backtest --factor CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
    
    # 多引擎对比回测
    python -m agentquant.cli backtest --factor CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --compare
"""

import argparse
import json
import sys
import io
import os
from datetime import date, datetime
from typing import Optional, Dict, Any, List

# 设置 stdout 编码为 UTF-8（解决 Windows 中文乱码问题）
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

from .database.api import StockAPI
from .cli_data_source import cmd_source, parse_date as source_parse_date
from .cli_result import cmd_result
from .cli_data import setup_data_parser
from .cli_strategy import setup_strategy_parser
from .cli_strategy_dev import setup_strategy_dev_parser
from .api.task_api import TaskManager
from .api.backtest_api import BacktestToolAPI


def parse_date(date_str: str) -> date:
    """解析日期字符串"""
    try:
        return datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        raise argparse.ArgumentTypeError(f'无效的日期格式: {date_str}，请使用 YYYY-MM-DD 格式')


def format_output(data: dict) -> str:
    """格式化输出为JSON，处理日期对象和numpy类型"""
    import numpy as np
    from datetime import date, datetime
    
    def convert_value(obj):
        """递归转换值"""
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.bool_):
            return bool(obj)
        elif isinstance(obj, dict):
            return {k: convert_value(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_value(item) for item in obj]
        return obj
    
    # 先递归转换所有值
    converted_data = convert_value(data)
    
    def json_serial(obj):
        """JSON序列化辅助函数（处理剩余的特殊类型）"""
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.bool_):
            return bool(obj)
        raise TypeError(f"Type {type(obj)} not serializable")
    
    return json.dumps(converted_data, ensure_ascii=False, indent=2, default=json_serial)


# 动态因子代码模板
FACTOR_TEMPLATE = '''
from agentquant.factor.jqfactor_base import JQFactor, FactorMeta
import pandas as pd
import numpy as np

class MyCustomFactor(JQFactor):
    """
    【必填】因子功能描述
    
    请详细说明：
    1. 这个因子计算什么指标？（如：计算收盘价的N日移动平均）
    2. 因子的经济学/金融学逻辑是什么？（如：均线反映价格趋势）
    3. 因子值越大代表什么？（如：MA越大表示价格越高）
    4. 适用场景是什么？（如：趋势跟踪、均值回归等）
    5. 参数如何调整？（如：短期5-10日，长期60日）
    
    示例：
    """
    移动平均线(MA)因子
    
    功能：计算股票收盘价的N日简单移动平均
    
    逻辑：移动平均线是技术分析的基础指标，反映了一段时间内
          市场的平均持仓成本。价格高于均线表示强势，低于均线表示弱势。
    
    用法：
    - 因子值越大，表示近期价格越高
    - 短期均线上穿长期均线为买入信号（金叉）
    - 短期均线下穿长期均线为卖出信号（死叉）
    
    参数建议：
    - 短期趋势：5-10日
    - 中期趋势：20-30日
    - 长期趋势：60-120日
    """
    
    meta = FactorMeta(
        code='YOUR_FACTOR_CODE',      # 【必填】因子代码（唯一标识，建议大写下划线）
        name='因子名称',               # 【必填】显示名称（中文，简洁明了）
        category='技术',              # 【必填】分类：估值/质量/动量/技术/情绪/成长
        description='因子一句话描述',  # 【必填】一句话描述（用于列表展示）
        parameters={                  # 【可选】参数定义
            'window': {
                'default': 20, 
                'type': 'int', 
                'description': '计算窗口期，单位：交易日'
            }
        },
        dependencies=['close'],       # 【必填】依赖的数据字段：close/open/high/low/volume
        max_window=30                 # 【必填】最大回溯窗口（用于数据准备）
    )
    
    def calc(self, data):
        """
        【必填】计算因子值
        
        请详细说明：
        1. 计算逻辑是什么？
        2. 如何处理缺失值？
        3. 返回值的含义和单位？
        
        Args:
            data: 字典，包含所需数据字段
                  例如：{
                      'close': DataFrame,  # 收盘价，列名为股票代码
                      'volume': DataFrame   # 成交量
                  }
        
        Returns:
            float: 当前时间点的因子值（单值，不是序列）
                   例如：返回20.5 表示当前MA值为20.5
        """
        # 【必填】获取参数值（使用get提供默认值）
        window = self.params.get('window', 20)
        
        # 【必填】从data中获取数据
        close = data['close']
        
        # 【必填】实现计算逻辑
        # 示例：计算移动平均
        ma = close.rolling(window=window).mean()
        
        # 【必填】返回最新值（必须是标量）
        return ma.iloc[-1]
'''

# 动态策略代码模板
STRATEGY_TEMPLATE = '''
from agentquant.strategy.base import BaseStrategy
import pandas as pd
import numpy as np

class MyCustomStrategy(BaseStrategy):
    """
    【必填】策略功能描述
    
    请详细说明：
    1. 这个策略的核心思想是什么？（如：双均线金叉买入、死叉卖出）
    2. 策略类型是什么？（如：趋势跟踪、均值回归、突破策略）
    3. 适用市场环境是什么？（如：趋势明显的市场、震荡市等）
    4. 风险点有哪些？（如：震荡市频繁交易、滞后性等）
    5. 参数如何优化？（如：不同市场周期调整均线周期）
    
    示例：
    """
    双均线趋势跟踪策略
    
    核心思想：
    使用两条不同周期的移动平均线，短期均线上穿长期均线（金叉）时买入，
    短期均线下穿长期均线（死叉）时卖出。利用均线系统的趋势确认能力，
    捕捉中长期趋势行情。
    
    策略类型：趋势跟踪策略
    
    适用市场：
    - 适合有明显趋势的市场（牛市或熊市）
    - 不适合震荡市（会产生频繁假信号）
    
    风险点：
    1. 滞后性：均线是滞后指标，趋势反转时反应较慢
    2. 震荡市亏损：横盘震荡时频繁买卖，产生连续亏损
    3. 参数敏感：不同参数在不同市场周期表现差异大
    
    参数优化建议：
    - 短期趋势：5-10日
    - 中期趋势：20-30日
    - 长期趋势：50-60日
    """
    
    meta = {
        'code': 'YOUR_STRATEGY_CODE',      # 【必填】策略代码（唯一标识，建议大写下划线）
        'name': '策略名称',                   # 【必填】显示名称（中文，简洁明了）
        'description': '策略一句话描述',      # 【必填】一句话描述（用于列表展示）
        'category': '趋势',                  # 【必填】分类：趋势/均值回归/套利/事件驱动/组合
        'parameters': {                      # 【可选】参数定义
            'short_window': {
                'default': 5, 
                'type': 'int',
                'description': '短期均线窗口，建议5-10日'
            },
            'long_window': {
                'default': 20, 
                'type': 'int',
                'description': '长期均线窗口，建议20-60日'
            }
        },
        'factors': ['MA']                    # 【可选】依赖的因子代码列表
    }
    
    def init(self, context):
        """
        【必填】初始化策略
        
        请详细说明：
        1. 初始化哪些参数？
        2. 初始化哪些状态变量？
        3. 初始资金如何分配？
        
        Args:
            context: 回测上下文对象，包含：
                - account: 账户信息（cash现金, positions持仓, total_value总资产）
                - params: 策略参数（传入的自定义参数）
                - current_date: 当前日期
                - current_code: 当前股票代码
        """
        # 【必填】从context获取参数
        self.short_window = context.params.get('short_window', 5)
        self.long_window = context.params.get('long_window', 20)
        
        # 【必填】初始化状态变量
        self.holding = False           # 是否持仓
        self.entry_price = 0.0         # 入场价格（用于计算止损止盈）
        self.trade_count = 0           # 交易次数统计
        
        # 【可选】其他初始化
        # 如：加载历史数据、计算初始指标等
    
    def on_bar(self, context, data):
        """
        【必填】处理每根K线数据（核心交易逻辑）
        
        请详细说明：
        1. 信号生成逻辑是什么？
        2. 什么条件下买入/卖出？
        3. 仓位如何管理？
        4. 是否有止损止盈逻辑？
        
        Args:
            context: 回测上下文
            data: 当前bar数据，包含：
                - open: 开盘价
                - high: 最高价
                - low: 最低价
                - close: 收盘价
                - volume: 成交量
        
        Returns:
            dict: 交易信号，格式如下：
                - {'action': 'hold'} - 不操作
                - {'action': 'buy', 'price': float, 'amount': int} - 买入
                - {'action': 'sell', 'price': float, 'amount': int} - 卖出
                
                可选字段：
                - reason: 交易原因说明
                - stop_loss: 止损价格
                - take_profit: 止盈价格
        """
        # 【必填】获取历史数据计算指标
        history = context.get_history(
            field='close',
            count=self.long_window + 1
        )
        
        # 【必填】数据有效性检查
        if len(history) < self.long_window:
            return {'action': 'hold', 'reason': '数据不足'}
        
        # 【必填】计算交易信号
        short_ma = history[-self.short_window:].mean()
        long_ma = history[-self.long_window:].mean()
        
        # 【必填】交易逻辑
        # 金叉买入条件：短期均线上穿长期均线，且未持仓
        if short_ma > long_ma and not self.holding:
            self.holding = True
            self.entry_price = data['close']
            self.trade_count += 1
            return {
                'action': 'buy',
                'price': data['close'],
                'reason': f'金叉信号: 短期MA({short_ma:.2f}) > 长期MA({long_ma:.2f})'
            }
        
        # 死叉卖出条件：短期均线下穿长期均线，且已持仓
        elif short_ma < long_ma and self.holding:
            self.holding = False
            profit_pct = (data['close'] - self.entry_price) / self.entry_price * 100
            return {
                'action': 'sell',
                'price': data['close'],
                'reason': f'死叉信号: 短期MA({short_ma:.2f}) < 长期MA({long_ma:.2f}), 盈亏: {profit_pct:.2f}%'
            }
        
        # 【可选】止损逻辑示例
        # if self.holding and data['close'] < self.entry_price * 0.95:
        #     self.holding = False
        #     return {'action': 'sell', 'price': data['close'], 'reason': '止损: 亏损超过5%'}
        
        # 无信号，持有或空仓
        return {'action': 'hold'}
'''


def validate_factor_code(source_code: str) -> tuple[bool, str]:
    """
    验证因子代码格式
    
    Returns:
        (是否有效, 错误信息)
    """
    errors = []
    warnings = []
    
    # 检查是否继承 JQFactor
    if 'JQFactor' not in source_code:
        errors.append("因子类必须继承自 JQFactor")
    
    # 检查是否有 meta 定义
    if 'meta' not in source_code or 'FactorMeta' not in source_code:
        errors.append("必须定义 meta 属性（FactorMeta 类型）")
    
    # 检查是否有 calc 方法
    if 'def calc(' not in source_code:
        errors.append("必须实现 calc 方法")
    
    # 检查必要的导入
    if 'from agentquant.factor.jqfactor_base import' not in source_code:
        errors.append("必须导入 JQFactor 和 FactorMeta")
    
    # 检查类文档字符串（描述）- 改为警告而非错误
    import re
    class_pattern = r'class\s+\w+\s*\([^)]*\):\s*"""([^"]*)"""'
    class_match = re.search(class_pattern, source_code, re.DOTALL)
    if not class_match:
        warnings.append("建议：类定义添加文档字符串（三重引号描述），说明因子功能")
    else:
        docstring = class_match.group(1).strip()
        if len(docstring) < 30:
            warnings.append("建议：类文档字符串可以更长一些，详细描述因子功能")
    
    # 检查 calc 方法文档字符串 - 改为警告而非错误
    calc_pattern = r'def calc\([^)]*\):\s*"""([^"]*)"""'
    calc_match = re.search(calc_pattern, source_code, re.DOTALL)
    if not calc_match:
        warnings.append("建议：calc 方法添加文档字符串，说明计算逻辑")
    
    if errors:
        return False, "; ".join(errors)
    
    # 如果有警告，返回成功但附带警告信息
    if warnings:
        return True, "验证通过，但有建议改进：" + "; ".join(warnings)
    
    return True, ""


def validate_strategy_code(source_code: str) -> tuple[bool, str]:
    """
    验证策略代码格式
    
    Returns:
        (是否有效, 错误信息)
    """
    errors = []
    warnings = []
    
    # 检查是否继承 BaseStrategy
    if 'BaseStrategy' not in source_code:
        errors.append("策略类必须继承自 BaseStrategy")
    
    # 检查是否有 meta 定义
    if 'meta' not in source_code:
        errors.append("必须定义 meta 属性")
    
    # 检查是否有 init 方法
    if 'def init(' not in source_code:
        errors.append("必须实现 init 方法")
    
    # 检查是否有 on_bar 或 on_data 方法
    if 'def on_bar(' not in source_code and 'def on_data(' not in source_code:
        errors.append("必须实现 on_bar 或 on_data 方法")
    
    # 检查必要的导入
    if 'from agentquant.strategy.base import' not in source_code:
        errors.append("必须导入 BaseStrategy 基类")
    
    # 检查类文档字符串（描述）- 改为警告而非错误
    import re
    class_pattern = r'class\s+\w+\s*\([^)]*\):\s*"""([^"]*)"""'
    class_match = re.search(class_pattern, source_code, re.DOTALL)
    if not class_match:
        warnings.append("建议：类定义添加文档字符串，说明策略核心思想")
    else:
        docstring = class_match.group(1).strip()
        if len(docstring) < 30:
            warnings.append("建议：类文档字符串可以更长一些")
    
    # 检查 init 方法文档字符串 - 改为警告
    init_pattern = r'def init\([^)]*\):\s*"""([^"]*)"""'
    init_match = re.search(init_pattern, source_code, re.DOTALL)
    if not init_match:
        warnings.append("建议：init 方法添加文档字符串")
    
    # 检查 on_bar/on_data 方法文档字符串 - 改为警告
    onbar_pattern = r'def on_bar\([^)]*\):\s*"""([^"]*)"""'
    ondata_pattern = r'def on_data\([^)]*\):\s*"""([^"]*)"""'
    onbar_match = re.search(onbar_pattern, source_code, re.DOTALL)
    ondata_match = re.search(ondata_pattern, source_code, re.DOTALL)
    if not onbar_match and not ondata_match:
        warnings.append("建议：on_bar/on_data 方法添加文档字符串")
    
    if errors:
        return False, "; ".join(errors)
    
    # 如果有警告，返回成功但附带警告信息
    if warnings:
        return True, "验证通过，但有建议改进：" + "; ".join(warnings)
    
    return True, ""


def cmd_db(args) -> int:
    """数据库管理命令"""
    import subprocess
    import time
    import os
    import sys
    
    if args.action == 'start':
        # 启动数据库服务
        try:
            from .database.storage.db_client import DBClient, DEFAULT_HOST, DEFAULT_PORT
            
            # 检查数据库是否已在运行
            try:
                client = DBClient()
                # 数据库已在运行，返回详细状态供agent决策
                print(format_output({
                    'success': True,
                    'message': '数据库服务已在运行，无需重复启动',
                    'status': 'already_running',
                    'address': f'{DEFAULT_HOST}:{DEFAULT_PORT}',
                    'note': '数据库服务已经启动，可以直接使用。如需重启，请先执行 db stop'
                }))
                return 0
            except:
                pass  # 未运行，继续启动
            
            # 启动数据库服务进程
            db_service_module = 'agentquant.database.storage.db_service'
            
            print(format_output({
                'success': True,
                'message': '正在启动数据库服务...',
                'status': 'starting',
                'estimated_time': '3-5 seconds',
                'note': '数据库服务启动需要3-5秒，请稍候...'
            }))
            
            # 记录使用的 Python 版本信息
            python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
            python_exe = sys.executable
            
            # 默认使用后台静默模式（不弹窗）
            if sys.platform == 'win32':
                # Windows: 使用 CREATE_NO_WINDOW 避免弹窗，并创建独立进程
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE
                
                process = subprocess.Popen(
                    [python_exe, '-m', db_service_module],
                    creationflags=subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    startupinfo=startupinfo,
                    close_fds=True
                )
            else:
                # Linux/Mac: 使用 nohup 方式启动，脱离终端
                process = subprocess.Popen(
                    [python_exe, '-m', db_service_module],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                    close_fds=True
                )
            
            # 同步等待服务启动，最多等待10秒
            max_wait = 10
            wait_interval = 0.5
            elapsed = 0
            
            while elapsed < max_wait:
                time.sleep(wait_interval)
                elapsed += wait_interval
                
                try:
                    client = DBClient()
                    # 启动成功
                    print(format_output({
                        'success': True,
                        'message': f'数据库服务启动成功（用时 {elapsed:.1f} 秒）',
                        'status': 'running',
                        'address': f'{DEFAULT_HOST}:{DEFAULT_PORT}',
                        'pid': process.pid if hasattr(process, 'pid') else None,
                        'python_version': python_version,
                        'python_exe': python_exe,
                        'note': '数据库服务已启动并保持运行，可以正常使用。请确保后续命令使用相同Python版本'
                    }))
                    return 0
                except:
                    continue
            
            # 超时，启动失败
            print(format_output({
                'success': False,
                'message': f'数据库服务启动超时（等待 {max_wait} 秒）',
                'status': 'failed',
                'note': '服务可能正在启动中，请稍后检查状态: python -m agentquant.cli db status'
            }))
            return 1
                
        except Exception as e:
            print(format_output({
                'success': False,
                'message': f'启动数据库服务失败: {str(e)}',
                'status': 'failed'
            }))
            return 1
    
    elif args.action == 'stop':
        # 停止数据库服务
        import subprocess
        import os
        
        # 强制停止：查找并终止数据库服务进程
        try:
            # 使用netstat查找占用端口的进程
            result = subprocess.run(
                'netstat -ano | findstr :9528',
                capture_output=True,
                text=True,
                shell=True
            )
            
            if result.returncode == 0 and result.stdout:
                # 解析输出获取PID
                lines = result.stdout.strip().split('\n')
                pids = set()
                for line in lines:
                    if ':9528' in line:
                        parts = line.strip().split()
                        if len(parts) >= 5:
                            pid = parts[-1]
                            if pid.isdigit():
                                pids.add(pid)
                
                # 终止进程
                killed = []
                for pid in pids:
                    try:
                        subprocess.run(['taskkill', '/F', '/PID', pid], capture_output=True)
                        killed.append(pid)
                    except:
                        pass
                
                if killed:
                    print(format_output({
                        'success': True,
                        'message': f'已强制停止数据库服务（PID: {", ".join(killed)}）',
                        'status': 'stopped',
                        'note': '旧版本服务已被强制终止，现在可以启动新版本'
                    }))
                    return 0
                else:
                    # 找到了进程但终止失败
                    print(format_output({
                        'success': False,
                        'message': f'找到数据库服务进程但无法终止（PID: {", ".join(pids)}）',
                        'status': 'failed',
                        'note': '请手动在任务管理器中结束进程，或使用管理员权限运行命令'
                    }))
                    return 1
            else:
                # 没有找到占用端口的进程
                print(format_output({
                    'success': True,
                    'message': '数据库服务未运行（端口9528未被占用）',
                    'status': 'already_stopped',
                    'note': '可以直接启动新版本: python -m agentquant.cli db start'
                }))
                return 0
        except Exception as e:
            # 强制停止失败
            print(format_output({
                'success': False,
                'message': f'停止数据库服务失败: {str(e)}',
                'status': 'failed',
                'note': '请手动在任务管理器中结束python.exe进程'
            }))
            return 1
    
    elif args.action == 'status':
        # 检查数据库状态
        try:
            from .database.storage.db_client import DBClient, DEFAULT_HOST, DEFAULT_PORT
            
            client = DBClient()
            
            # 动态获取数据库信息
            db_info = client.get_info()
            
            if 'error' in db_info:
                error_msg = db_info["error"]
                # 检测是否是旧版本服务
                if '方法不存在' in error_msg and '__info__' in error_msg:
                    print(format_output({
                        'success': False,
                        'message': '数据库服务版本过旧，需要更新',
                        'status': 'outdated',
                        'current_error': error_msg,
                        'solution': '请执行以下步骤更新：',
                        'steps': [
                            '1. 强制停止旧服务: python -m agentquant.cli db stop',
                            '2. 更新包: pip install --user --upgrade agent-quant',
                            '3. 启动新服务: python -m agentquant.cli db start'
                        ],
                        'note': '旧版本数据库服务缺少新功能，必须更新后才能正常使用'
                    }))
                else:
                    print(format_output({
                        'success': False,
                        'message': f'获取数据库信息失败: {error_msg}',
                        'status': 'error',
                        'note': '数据库服务可能未完全启动'
                    }))
                return 1
            
            print(format_output({
                'success': True,
                'message': '数据库服务运行中',
                'status': 'running',
                'db_type': db_info.get('db_type', 'DuckDB'),
                'address': f'{DEFAULT_HOST}:{DEFAULT_PORT}',
                'db_path': db_info.get('db_path', 'unknown'),
                'db_exists': db_info.get('db_exists', False),
                'db_size_mb': db_info.get('db_size_mb', 0),
                'note': '数据库服务正常运行，可以使用'
            }))
            return 0
        except Exception as e:
            print(format_output({
                'success': False,
                'message': f'数据库服务未运行',
                'status': 'stopped',
                'note': '请先启动数据库服务: python -m agentquant.cli db start'
            }))
            return 1
    
    return 0


def cmd_update(args) -> int:
    """更新数据命令"""
    api = StockAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：python -m agentquant.cli db start',
            'saved_count': 0,
            'requested_date': args.date.strftime('%Y-%m-%d') if args.date else None,
            'actual_date': None,
            'is_mapping': False
        }))
        return 1
    
    codes = args.codes.split(',') if args.codes else None
    target_date = args.date
    
    result = api.update_daily(codes=codes, target_date=target_date)
    print(format_output(result))
    return 0 if result['success'] else 1


def _convert_to_json_serializable(data: list) -> list:
    """将数据中的date对象转换为字符串"""
    result = []
    for item in data:
        new_item = {}
        for key, value in item.items():
            if isinstance(value, date):
                new_item[key] = value.strftime('%Y-%m-%d')
            else:
                new_item[key] = value
        result.append(new_item)
    return result


def cmd_query(args) -> int:
    """查询数据命令"""
    api = StockAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：python -m agentquant.cli db start',
            'data': []
        }))
        return 1
    
    try:
        if args.codes:
            # 批量查询
            codes = args.codes.split(',')
            df = api.get_daily_multi(codes, args.start, args.end)
        else:
            # 单只股票查询
            df = api.get_daily(args.code, args.start, args.end)
        
        # 转换为字典列表，并处理date对象
        raw_data = df.to_dict(orient='records') if not df.empty else []
        data = _convert_to_json_serializable(raw_data)
        
        print(format_output({
            'success': True,
            'message': f'查询成功，返回 {len(data)} 条记录',
            'count': len(data),
            'data': data
        }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'查询失败: {str(e)}',
            'data': []
        }))
        return 1


def cmd_latest(args) -> int:
    """获取最新日期命令"""
    api = StockAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：python -m agentquant.cli db start',
            'latest_date': None
        }))
        return 1
    
    latest = api.get_latest_date()
    
    print(format_output({
        'success': True,
        'message': '查询成功',
        'latest_date': latest.strftime('%Y-%m-%d') if latest else None
    }))
    return 0


def cmd_stocks(args) -> int:
    """获取股票列表命令"""
    api = StockAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：python -m agentquant.cli db start',
            'count': 0,
            'stocks': []
        }))
        return 1
    
    try:
        df = api.get_all_stocks()
        raw_stocks = df.to_dict(orient='records') if not df.empty else []
        
        # 处理date对象
        stocks = _convert_to_json_serializable(raw_stocks)
        
        # 如果指定了limit，限制返回数量
        if args.limit and len(stocks) > args.limit:
            stocks = stocks[:args.limit]
        
        print(format_output({
            'success': True,
            'message': f'查询成功，返回 {len(stocks)} 只股票',
            'count': len(stocks),
            'stocks': stocks
        }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'查询失败: {str(e)}',
            'count': 0,
            'stocks': []
        }))
        return 1


def cmd_factor(args) -> int:
    """因子管理命令 - 根据子命令分发"""
    if args.factor_subcommand == 'list':
        return cmd_factor_list(args)
    elif args.factor_subcommand == 'info':
        return cmd_factor_info(args)
    elif args.factor_subcommand == 'calc':
        return cmd_factor_calc(args)
    elif args.factor_subcommand == 'backtest':
        return cmd_factor_backtest(args)
    else:
        # 默认列出所有因子
        return cmd_factor_list(args)


def cmd_factor_list(args) -> int:
    """列出所有因子"""
    from .api.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    factors = api.get_available_factors()
    print(format_output({
        'success': True,
        'count': len(factors),
        'factors': factors
    }))
    return 0


def cmd_factor_info(args) -> int:
    """查看因子详情"""
    from .api.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    info = api.get_factor_info(args.name)
    if info:
        # 如果有help文本，优先显示help
        if 'help' in info:
            print(info['help'])
        else:
            print(format_output({
                'success': True,
                'factor': info
            }))
    else:
        print(format_output({
            'success': False,
            'message': f'因子不存在: {args.name}'
        }))
    return 0


def cmd_factor_calc(args) -> int:
    """计算因子值"""
    from .api.backtest_api import BacktestToolAPI
    import json
    import re
    
    api = BacktestToolAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：python -m agentquant.cli db start'
        }))
        return 1
    
    try:
        # 解析股票代码
        codes = args.codes.split(',') if args.codes else ['000001.SZ']
        
        # 解析因子参数
        factor_params = {}
        if args.params:
            params_str = args.params.strip()
            
            # 尝试直接解析JSON
            try:
                factor_params = json.loads(params_str)
            except json.JSONDecodeError:
                # 尝试修复常见的JSON格式问题
                # 1. 将单引号替换为双引号
                params_str = params_str.replace("'", '"')
                # 2. 处理没有引号的key
                params_str = re.sub(r'([{,])\s*(\w+)\s*:', r'\1"\2":', params_str)
                
                try:
                    factor_params = json.loads(params_str)
                except json.JSONDecodeError as e:
                    print(format_output({
                        'success': False,
                        'message': f'参数解析失败: {str(e)}。请使用JSON格式，如: {{"short_window":10,"long_window":30}}'
                    }))
                    return 1
        
        # 计算因子值（将date对象转为字符串）
        calc_date_str = args.date.isoformat() if hasattr(args.date, 'isoformat') else str(args.date)
        result = api.calculate_factor_values(
            factor_code=args.name,
            codes=codes,
            calc_date=calc_date_str,
            factor_params=factor_params,
            limit=args.limit if args.limit > 0 else None
        )
        
        if not result.get('success', False):
            print(format_output({
                'success': False,
                'message': result.get('message', '计算失败')
            }))
            return 1
        
        print(format_output(result))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'计算失败: {str(e)}'
        }))
        return 1


def cmd_factor_backtest(args) -> int:
    """因子回测"""
    from .api.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：python -m agentquant.cli db start'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    
    # 解析因子参数
    factor_params = {}
    if args.params:
        try:
            factor_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    # 运行因子测试（将date对象转为字符串）
    try:
        start_date_str = args.start.isoformat() if hasattr(args.start, 'isoformat') else str(args.start)
        end_date_str = args.end.isoformat() if hasattr(args.end, 'isoformat') else str(args.end)
        result = api.run_factor_test(
            factor_name=args.name,
            codes=codes,
            start_date=start_date_str,
            end_date=end_date_str,
            factor_params=factor_params
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'回测失败: {str(e)}'
        }))
        return 1


def cmd_strategy(args) -> int:
    """策略管理命令 - 根据子命令分发"""
    if args.strategy_subcommand == 'list':
        return cmd_strategy_list(args)
    elif args.strategy_subcommand == 'info':
        return cmd_strategy_info(args)
    elif args.strategy_subcommand == 'backtest':
        return cmd_strategy_backtest(args)
    else:
        # 默认列出所有策略
        return cmd_strategy_list(args)


def cmd_strategy_list(args) -> int:
    """列出所有策略"""
    from .api.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    strategies = api.list_strategies()
    print(format_output({
        'success': True,
        'count': len(strategies),
        'strategies': strategies
    }))
    return 0


def cmd_strategy_info(args) -> int:
    """查看策略详情"""
    from .api.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    info = api.get_strategy_info(args.name)
    if info:
        print(format_output({
            'success': True,
            'strategy': info
        }))
    else:
        print(format_output({
            'success': False,
            'message': f'策略不存在: {args.name}'
        }))
    return 0


def cmd_strategy_backtest(args) -> int:
    """策略回测 - 支持多股票"""
    from .api.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：python -m agentquant.cli db start'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    
    # 解析策略参数
    strategy_params = {}
    if args.params:
        try:
            strategy_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    # 运行多股票策略回测（将date对象转为字符串）
    results = []
    errors = []
    start_date_str = args.start.isoformat() if hasattr(args.start, 'isoformat') else str(args.start)
    end_date_str = args.end.isoformat() if hasattr(args.end, 'isoformat') else str(args.end)

    for code in codes:
        try:
            result = api.run_strategy_backtest(
                strategy_name=args.name,
                codes=[code.strip()],
                start_date=start_date_str,
                end_date=end_date_str,
                strategy_params=strategy_params
            )
            if result.get('success'):
                results.append(result)
            else:
                errors.append({'code': code, 'error': result.get('message', '未知错误')})
        except Exception as e:
            errors.append({'code': code, 'error': str(e)})

    # 汇总结果
    if len(codes) == 1:
        # 单只股票直接返回结果
        print(format_output(results[0] if results else {'success': False, 'message': errors[0]['error'] if errors else '回测失败'}))
        return 0 if results else 1
    else:
        # 多只股票返回汇总
        output = {
            'success': len(results) > 0,
            'strategy_name': args.name,
            'codes': codes,
            'start_date': args.start.strftime('%Y-%m-%d') if hasattr(args.start, 'strftime') else str(args.start),
            'end_date': args.end.strftime('%Y-%m-%d') if hasattr(args.end, 'strftime') else str(args.end),
            'results_count': len(results),
            'errors_count': len(errors),
            'results': results,
            'errors': errors
        }
        print(format_output(output))
        return 0 if results else 1


def cmd_engines(args) -> int:
    """查看可用回测引擎"""
    from .api.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    engines = api.get_available_engines()
    
    print(format_output({
        'success': True,
        'count': len(engines),
        'engines': engines
    }))
    return 0


def cmd_doctor(args) -> int:
    """自我诊断命令 - 检查系统运行状态"""
    import platform
    import importlib.util
    from datetime import datetime
    
    diagnosis = {
        'success': True,
        'timestamp': datetime.now().isoformat(),
        'system': {},
        'package': {},
        'database': {},
        'qmt': {},
        'backtest_engines': {}
    }
    
    print("\n" + "="*60)
    print("系统自我诊断")
    print("="*60)
    
    # 1. 系统信息
    print("\n[1/5] 系统信息")
    diagnosis['system'] = {
        'platform': platform.system(),
        'platform_version': platform.version(),
        'python_version': platform.python_version(),
        'machine': platform.machine(),
        'processor': platform.processor()
    }
    print(f"  操作系统: {diagnosis['system']['platform']}")
    print(f"  Python版本: {diagnosis['system']['python_version']}")

    # 2. 包信息
    print("\n[2/5] 包信息")
    try:
        import agentquant
        package_path = agentquant.__file__
        version = agentquant.__version__
        diagnosis['package'] = {
            'path': package_path,
            'version': version
        }
        print(f"  安装路径: {package_path}")
        print(f"  版本: {version}")
    except Exception as e:
        diagnosis['package'] = {'error': str(e)}
        print(f"  错误: {e}")

    # 3. 数据库诊断
    print("\n[3/5] 数据库诊断")
    try:
        from .database.storage.db_client import DEFAULT_HOST, DEFAULT_PORT, DBClient
        
        diagnosis['database']['address'] = f'{DEFAULT_HOST}:{DEFAULT_PORT}'
        print(f"  服务地址: {DEFAULT_HOST}:{DEFAULT_PORT}")
        
        # 尝试连接并获取数据库信息
        try:
            client = DBClient()
            db_info = client.get_info()
            
            if 'error' not in db_info:
                diagnosis['database']['type'] = db_info.get('db_type', 'DuckDB')
                diagnosis['database']['path'] = db_info.get('db_path', 'unknown')
                diagnosis['database']['file_exists'] = db_info.get('db_exists', False)
                diagnosis['database']['file_size_mb'] = db_info.get('db_size_mb', 0)

                print(f"  数据库类型: {diagnosis['database']['type']}")
                print(f"  文件路径: {diagnosis['database']['path']}")
                print(f"  文件大小: {diagnosis['database']['file_size_mb']} MB")
            else:
                print(f"  获取数据库信息失败: {db_info['error']}")
        except Exception as e:
            print(f"  连接数据库获取信息失败: {e}")

        # 检查数据库是否运行
        from .database.api import StockAPI
        api = StockAPI()
        if api.ping():
            diagnosis['database']['status'] = 'running'
            diagnosis['database']['connection'] = 'ok'
            print("  运行状态: 运行中")
            print("  连接测试: 正常")
        else:
            diagnosis['database']['status'] = 'stopped'
            diagnosis['database']['connection'] = 'failed'
            print("  运行状态: 未运行")
            print("  连接测试: 失败")
    except Exception as e:
        diagnosis['database']['error'] = str(e)
        print(f"  错误: {e}")

    # 4. QMT客户端诊断
    print("\n[4/5] QMT客户端诊断")
    try:
        from .database.source.qmt import QMTDataSource
        client = QMTDataSource()
        if client.is_connected():
            diagnosis['qmt']['connection'] = 'ok'
            print("  连接状态: 正常")
            
            # 测试读取数据
            try:
                stock_list = client.get_stock_list('all')
                if stock_list and len(stock_list) > 0:
                    diagnosis['qmt']['read_test'] = 'ok'
                    print(f"  读取测试: 正常 (获取到 {len(stock_list)} 只股票)")
                else:
                    diagnosis['qmt']['read_test'] = 'failed'
                    print("  读取测试: 失败")
            except Exception as e:
                diagnosis['qmt']['read_test'] = f'error: {e}'
                print(f"  读取测试: 错误 - {e}")
        else:
            diagnosis['qmt']['connection'] = 'failed'
            print("  连接状态: 失败")
    except Exception as e:
        diagnosis['qmt']['error'] = str(e)
        print(f"  错误: {e}")
    
    # 5. 回测引擎依赖
    print("\n[5/5] 回测引擎依赖")
    engines = [
        ('vnpy', 'vnpy'),
        ('jqdata', 'jqdata'),
        ('backtrader', 'backtrader'),
        ('cskhquant', 'CSKhQuant')
    ]
    
    for module_name, display_name in engines:
        spec = importlib.util.find_spec(module_name)
        if spec is not None:
            diagnosis['backtest_engines'][display_name] = 'installed'
            print(f"  {display_name}: 已安装")
        else:
            diagnosis['backtest_engines'][display_name] = 'not_installed'
            print(f"  {display_name}: 未安装")
    
    print("\n" + "="*60)
    print(format_output(diagnosis))
    return 0


def cmd_gui(args) -> int:
    """启动或停止GUI命令"""
    import subprocess
    import sys as sys_module
    import os
    import platform
    
    # 检查是否是停止命令
    if hasattr(args, 'stop') and args.stop:
        return stop_gui()
    
    # 检查是否是前台运行模式
    foreground = hasattr(args, 'foreground') and args.foreground
    
    # 如果不是前台模式，则在后台启动GUI
    if not foreground:
        return start_gui_background()
    
    # 前台模式：启动GUI（阻塞当前进程）
    return start_gui_foreground()


def start_gui_foreground() -> int:
    """前台启动GUI（阻塞当前进程）"""
    import sys as sys_module
    
    try:
        from agentquant.gui.qt_compat import QApplication, QFont
        from agentquant.gui import MainWindow

        app = QApplication(sys_module.argv)
        app.setStyle('Fusion')

        # 设置应用程序字体
        font = QFont("Microsoft YaHei", 10)
        app.setFont(font)

        window = MainWindow()
        window.show()

        return app.exec_()

    except ImportError as e:
        error_msg = str(e)
        if 'DLL load failed' in error_msg:
            print(format_output({
                'success': False,
                'message': f'启动GUI失败: {e}',
                'error': 'PyQt5 DLL加载失败',
                'solution': 'Windows系统需要安装Visual C++ Redistributable。\n'
                           '请下载并安装: https://aka.ms/vs/17/release/vc_redist.x64.exe\n'
                           '或者尝试: pip install PySide6'
            }))
        else:
            print(format_output({
                'success': False,
                'message': f'启动GUI失败: {e}',
                'error': '缺少GUI依赖',
                'solution': '请安装PyQt5: pip install PyQt5\n或者: pip install PySide6'
            }))
        return 1
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'启动GUI失败: {e}',
            'error': str(e)
        }))
        return 1


def start_gui_background() -> int:
    """后台启动GUI（不阻塞当前进程）"""
    import subprocess
    import platform
    import sys
    import os
    
    try:
        # 构建启动GUI的命令
        python_exe = sys.executable
        
        # 使用subprocess在后台启动GUI
        if platform.system() == "Windows":
            # Windows: 使用python.exe启动，通过DETACHED_PROCESS分离进程
            # 这样不会显示控制台窗口，但GUI窗口会正常显示
            creation_flags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
            
            process = subprocess.Popen(
                [python_exe, '-m', 'agentquant.cli', 'gui', '--foreground'],
                creationflags=creation_flags,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                close_fds=True
            )
        else:
            # Linux/Mac: 使用nohup在后台运行
            process = subprocess.Popen(
                [python_exe, '-m', 'agentquant.cli', 'gui', '--foreground'],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )
        
        print(format_output({
            'success': True,
            'message': 'GUI已在后台启动',
            'pid': process.pid,
            'note': '使用 "agentquant cli gui --stop" 停止GUI'
        }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'后台启动GUI失败: {e}',
            'error': str(e)
        }))
        return 1


def stop_gui() -> int:
    """停止GUI进程"""
    import subprocess
    import platform
    
    system = platform.system()
    killed = False
    count = 0
    
    try:
        if system == "Windows":
            # Windows: 使用wmic查找Python GUI进程
            # 查找包含agentquant和gui的Python进程（包括python.exe和pythonw.exe）
            result = subprocess.run(
                ['wmic', 'process', 'where', 
                 'CommandLine like "%agentquant%gui%" and (Name="python.exe" or Name="pythonw.exe")',
                 'get', 'ProcessId,CommandLine,Name'],
                capture_output=True, text=True
            )
            lines = result.stdout.strip().split('\n')
            pids = []
            for line in lines[1:]:  # 跳过标题行
                parts = line.strip().split()
                if parts and parts[-1].isdigit():
                    pid = parts[-1]
                    # 检查是否包含foreground（排除后台启动器本身）
                    if 'foreground' in line.lower():
                        pids.append(pid)
            
            for pid in pids:
                try:
                    subprocess.run(['taskkill', '/F', '/PID', pid], 
                                 capture_output=True)
                    count += 1
                    killed = True
                except:
                    pass
        else:
            # Linux/Mac: 使用pkill
            result = subprocess.run(
                ['pgrep', '-f', 'agentquant.*gui.*foreground'],
                capture_output=True, text=True
            )
            pids = result.stdout.strip().split('\n')
            
            for pid in pids:
                if pid:
                    try:
                        subprocess.run(['kill', '-9', pid], capture_output=True)
                        count += 1
                        killed = True
                    except:
                        pass
        
        if killed:
            print(format_output({
                'success': True,
                'message': f'已停止 {count} 个GUI进程',
                'status': 'stopped'
            }))
            return 0
        else:
            print(format_output({
                'success': True,
                'message': '没有找到运行中的GUI进程',
                'status': 'not_running'
            }))
            return 0
            
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'停止GUI失败: {e}',
            'error': str(e)
        }))
        return 1


def cmd_selftest(args) -> int:
    """自我测试命令 - 完整的自动化测试流程"""
    import subprocess
    import time
    import sys as sys_module
    
    test_results = []
    test_code = '000001.SZ'
    test_date = '2024-06-01'
    test_start = '2024-01-01'
    test_end = '2024-06-01'
    
    python_exe = sys_module.executable
    
    def run_command(cmd, description, check_success=True):
        """运行命令并检查结果"""
        print(f"\n{'='*60}")
        print(f"[测试] {description}")
        print(f"{'='*60}")
        print(f"命令: {cmd}")
        
        try:
            env = os.environ.copy()
            env['PYTHONIOENCODING'] = 'utf-8'
            
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                timeout=60,
                env=env
            )
            
            if result.returncode != 0 and check_success:
                error_msg = result.stderr or result.stdout or "未知错误"
                print(f"[失败] {error_msg}")
                return False, error_msg
            
            try:
                output = json.loads(result.stdout)
                print(f"[成功] {output.get('message', '执行成功')}")
                return True, output
            except:
                print(f"[成功] {result.stdout[:200] if result.stdout else '执行成功'}")
                return True, result.stdout
                
        except subprocess.TimeoutExpired:
            error_msg = "命令执行超时"
            print(f"[失败] {error_msg}")
            return False, error_msg
        except Exception as e:
            error_msg = str(e)
            print(f"[失败] {error_msg}")
            return False, error_msg
    
    print("\n" + "="*60)
    print("开始自我测试")
    print("="*60)
    
    # 1. 测试所有 --help 命令
    help_commands = [
        (f'{python_exe} -m agentquant.cli --help', '主命令帮助'),
        (f'{python_exe} -m agentquant.cli update --help', 'update命令帮助'),
        (f'{python_exe} -m agentquant.cli query --help', 'query命令帮助'),
        (f'{python_exe} -m agentquant.cli factor --help', 'factor命令帮助'),
        (f'{python_exe} -m agentquant.cli strategy --help', 'strategy命令帮助'),
        (f'{python_exe} -m agentquant.cli engines --help', 'engines命令帮助'),
    ]
    
    for cmd, desc in help_commands:
        success, output = run_command(cmd, desc, check_success=False)
        test_results.append({'test': desc, 'success': success})
        if not success:
            print(f"\n[错误] {desc} 失败，终止测试")
            return 1
    
    print("\n" + "="*60)
    print("自我测试完成")
    print("="*60)
    print(format_output({
        'success': True,
        'message': '所有测试通过',
        'total': len(test_results),
        'passed': sum(1 for r in test_results if r['success']),
        'results': test_results
    }))
    return 0


def cmd_dynamic_factor(args) -> int:
    """动态因子管理命令"""
    # 处理 --template 参数
    if hasattr(args, 'template') and args.template:
        print("="*60)
        print("动态因子代码模板")
        print("="*60)
        print(FACTOR_TEMPLATE)
        print("="*60)
        print("\n使用说明:")
        print("1. 复制上述模板代码")
        print("2. 修改类名、meta 信息和 calc 逻辑")
        print("3. 通过以下命令保存到数据库:")
        print("   python -m agentquant.cli dynamic-factor save --code YOUR_CODE --name '名称' --file your_factor.py")
        return 0
    
    # 如果没有 action，显示帮助
    if not args.action:
        print("错误: 请指定操作 action")
        print("\n可用操作:")
        print("  list   - 列出所有动态因子")
        print("  get    - 查看因子详情")
        print("  save   - 保存因子")
        print("  delete - 删除因子")
        print("  test   - 测试因子编译")
        print("\n查看代码模板:")
        print("  python -m agentquant.cli dynamic-factor --template")
        return 1
    
    from .factor.dynamic import get_dynamic_factor_manager
    
    manager = get_dynamic_factor_manager()
    
    if args.action == 'list':
        # 列出所有动态因子 + 内置因子
        dynamic_factors = manager.list_factors(args.category)
        # 转换Timestamp为字符串
        for factor in dynamic_factors:
            if 'updated_at' in factor and hasattr(factor['updated_at'], 'strftime'):
                factor['updated_at'] = factor['updated_at'].strftime('%Y-%m-%d %H:%M:%S')
        
        # 获取内置因子
        from .factor.jqfactor_base import list_factors as list_builtin_factors
        builtin_factors = list_builtin_factors()
        
        print(format_output({
            'success': True,
            'count': {
                'builtin': len(builtin_factors),
                'dynamic': len(dynamic_factors)
            },
            'builtin_factors': builtin_factors,
            'dynamic_factors': dynamic_factors
        }))
        return 0
    
    elif args.action == 'get':
        # 获取因子详情
        record = manager.get_factor(args.code)
        if record:
            print(format_output({
                'success': True,
                'factor': {
                    'code': record.code,
                    'name': record.name,
                    'category': record.category,
                    'description': record.description,
                    'source_code': record.source_code,
                    'meta_json': record.meta_json,
                    'version': record.version,
                    'created_at': record.created_at,
                    'updated_at': record.updated_at
                }
            }))
            return 0
        else:
            print(format_output({
                'success': False,
                'message': f'因子不存储 {args.code}'
            }))
            return 1
    
    elif args.action == 'save':
        # 保存因子
        # 检查必要参数
        if not args.code:
            print(format_output({
                'success': False,
                'message': '缺少必要参数: --code (因子代码)'
            }))
            return 1
        
        if not args.name:
            print(format_output({
                'success': False,
                'message': '缺少必要参数: --name (因子名称)'
            }))
            return 1
        
        # 从文件或参数读取源代数
        if args.file:
            try:
                with open(args.file, 'r', encoding='utf-8') as f:
                    source_code = f.read()
            except FileNotFoundError:
                print(format_output({
                    'success': False,
                    'message': f'文件不存储 {args.file}'
                }))
                return 1
            except Exception as e:
                print(format_output({
                    'success': False,
                    'message': f'读取文件失败: {e}'
                }))
                return 1
        elif args.code_text:
            source_code = args.code_text
        else:
            print(format_output({
                'success': False,
                'message': '请提供源代码文件(--file)或直接代数--code-text)',
                'hint': '使用 --template 查看因子代码模板'
            }))
            return 1
        
        # 验证代码格式
        is_valid, error_msg = validate_factor_code(source_code)
        if not is_valid:
            print(format_output({
                'success': False,
                'message': f'代码格式验证失败: {error_msg}',
                'hint': '使用 --template 查看正确的因子代码模板'
            }))
            return 1
        
        # 解析元数组
        import json
        try:
            meta = json.loads(args.meta) if args.meta else {}
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'元数据解析失败 {e}'
            }))
            return 1
        
        success = manager.save_factor(
            code=args.code,
            name=args.name,
            category=args.category or '自定义',
            description=args.description or '',
            source_code=source_code,
            meta=meta
        )
        
        if success:
            result = {
                'success': True,
                'message': f'因子保存成功: {args.code}',
                'code': args.code,
                'name': args.name
            }
            # 如果有警告信息，添加到结果中
            if error_msg:
                result['warning'] = error_msg
            print(format_output(result))
        else:
            print(format_output({
                'success': False,
                'message': '因子保存失败，请检查代码格式'
            }))
        return 0 if success else 1
    
    elif args.action == 'delete':
        # 删除因子
        success = manager.delete_factor(args.code)
        print(format_output({
            'success': success,
            'message': '删除成功' if success else '删除失败'
        }))
        return 0 if success else 1
    
    elif args.action == 'test':
        # 测试因子编译
        record = manager.get_factor(args.code)
        if not record:
            print(format_output({
                'success': False,
                'message': f'因子不存储 {args.code}'
            }))
            return 1
        
        factor_class = manager.compile_factor(record)
        if factor_class:
            print(format_output({
                'success': True,
                'message': f'因子编译成功: {args.code}',
                'class_name': factor_class.__name__
            }))
            return 0
        else:
            print(format_output({
                'success': False,
                'message': f'因子编译失败: {args.code}'
            }))
            return 1
    
    return 0


def cmd_dynamic_strategy(args) -> int:
    """动态策略管理命令"""
    # 处理 --template 参数
    if hasattr(args, 'template') and args.template:
        print("="*60)
        print("动态策略代码模板")
        print("="*60)
        print(STRATEGY_TEMPLATE)
        print("="*60)
        print("\n使用说明:")
        print("1. 复制上述模板代码")
        print("2. 修改类名、meta 信息和交易逻辑")
        print("3. 通过以下命令保存到数据库:")
        print("   python -m agentquant.cli dynamic-strategy save --code YOUR_CODE --name '名称' --file your_strategy.py")
        return 0
    
    # 如果没有 action，显示帮助
    if not args.action:
        print("错误: 请指定操作 action")
        print("\n可用操作:")
        print("  list   - 列出所有动态策略")
        print("  get    - 查看策略详情")
        print("  save   - 保存策略")
        print("  delete - 删除策略")
        print("\n查看代码模板:")
        print("  python -m agentquant.cli dynamic-strategy --template")
        return 1
    
    from .strategy.dynamic import get_dynamic_strategy_manager
    
    manager = get_dynamic_strategy_manager()
    
    if args.action == 'list':
        # 列出所有动态策略
        strategies = manager.list_strategies()
        print(format_output({
            'success': True,
            'count': len(strategies),
            'strategies': strategies
        }))
        return 0
    
    elif args.action == 'get':
        # 获取策略详情
        record = manager.get_strategy(args.code)
        if record:
            print(format_output({
                'success': True,
                'strategy': {
                    'code': record.code,
                    'name': record.name,
                    'description': record.description,
                    'source_code': record.source_code,
                    'meta_json': record.meta_json,
                    'version': record.version,
                    'created_at': record.created_at,
                    'updated_at': record.updated_at
                }
            }))
            return 0
        else:
            print(format_output({
                'success': False,
                'message': f'策略不存储 {args.code}'
            }))
            return 1
    
    elif args.action == 'save':
        # 保存策略
        # 检查必要参数
        if not args.code:
            print(format_output({
                'success': False,
                'message': '缺少必要参数: --code (策略代码)'
            }))
            return 1
        
        if not args.name:
            print(format_output({
                'success': False,
                'message': '缺少必要参数: --name (策略名称)'
            }))
            return 1
        
        if args.file:
            try:
                with open(args.file, 'r', encoding='utf-8') as f:
                    source_code = f.read()
            except FileNotFoundError:
                print(format_output({
                    'success': False,
                    'message': f'文件不存储 {args.file}'
                }))
                return 1
            except Exception as e:
                print(format_output({
                    'success': False,
                    'message': f'读取文件失败: {e}'
                }))
                return 1
        elif args.code_text:
            source_code = args.code_text
        else:
            print(format_output({
                'success': False,
                'message': '请提供源代码文件(--file)或直接代数--code-text)',
                'hint': '使用 --template 查看策略代码模板'
            }))
            return 1
        
        # 验证代码格式
        is_valid, error_msg = validate_strategy_code(source_code)
        if not is_valid:
            print(format_output({
                'success': False,
                'message': f'代码格式验证失败: {error_msg}',
                'hint': '使用 --template 查看正确的策略代码模板'
            }))
            return 1
        
        import json
        try:
            meta = json.loads(args.meta) if args.meta else {}
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'元数据解析失败 {e}'
            }))
            return 1
        
        success = manager.save_strategy(
            code=args.code,
            name=args.name,
            description=args.description or '',
            source_code=source_code,
            meta=meta
        )
        
        if success:
            result = {
                'success': True,
                'message': f'策略保存成功: {args.code}',
                'code': args.code,
                'name': args.name
            }
            # 如果有警告信息，添加到结果中
            if error_msg:
                result['warning'] = error_msg
            print(format_output(result))
        else:
            print(format_output({
                'success': False,
                'message': '策略保存失败，请检查代码格式'
            }))
        return 0 if success else 1
    
    elif args.action == 'delete':
        # 删除策略
        success = manager.delete_strategy(args.code)
        print(format_output({
            'success': success,
            'message': '删除成功' if success else '删除失败'
        }))
        return 0 if success else 1
    
    return 0


def cmd_backtest(args) -> int:
    """回测命令 - 支持多引擎"""
    from .api.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    # 检查数据库连接
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：python -m agentquant.cli db start'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    code = codes[0]  # 目前只支持单只股票回测
    
    # 解析因子参数
    factor_params = {}
    if args.params:
        try:
            factor_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    # 多引擎对比模糊
    if args.compare:
        return _run_compare_backtest(api, args, code, factor_params)
    
    # 单引擎模糊
    return _run_single_backtest(api, args, code, factor_params)


def _run_single_backtest(api, args, code: str, factor_params: Dict[str, Any]) -> int:
    """运行单引擎回测"""
    try:
        # 运行回测
        result = api.run_backtest(
            factor_name=args.factor,
            code=code,
            start_date=args.start,
            end_date=args.end,
            init_capital=args.capital,
            factor_params=factor_params,
            engine=args.engine if args.engine else None
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'回测失败: {str(e)}'
        }))
        return 1


def _run_compare_backtest(api, args, code: str, factor_params: Dict[str, Any]) -> int:
    """运行多引擎对比回测"""
    # 获取可用引擎
    available_engines = api.get_available_engines()
    engines_to_test = []
    
    for e in available_engines:
        if e['available']:
            engines_to_test.append(e['type'])
    
    if len(engines_to_test) < 2:
        print(format_output({
            'success': False,
            'message': f'可用引擎不足2个，无法进行比对（当前可用 {engines_to_test}）'
        }))
        return 1
    
    print(format_output({
        'message': f'开始多引擎对比回测',
        'engines': engines_to_test,
        'factor': args.factor,
        'code': code,
        'start_date': args.start.strftime('%Y-%m-%d'),
        'end_date': args.end.strftime('%Y-%m-%d'),
        'factor_params': factor_params
    }))
    print("-" * 60)
    
    results = {}
    errors = {}
    
    for engine_name in engines_to_test:
        print(f"\n正在使用引擎 '{engine_name}' 运行回测...")
        try:
            result = api.run_backtest(
                factor_name=args.factor,
                code=code,
                start_date=args.start,
                end_date=args.end,
                init_capital=args.capital,
                factor_params=factor_params,
                engine=engine_name
            )
            
            if result.get('success'):
                results[engine_name] = result
                print(f"  回测成功 - 总收拢 {result['total_return']:.2%}")
            else:
                errors[engine_name] = result.get('error', '未知错误')
                print(f"  回测失败 - {result.get('error', '未知错误')}")
        except Exception as e:
            errors[engine_name] = str(e)
            print(f"  回测异常 - {e}")
    
    # 输出对比结果
    print("\n" + "=" * 60)
    print("多引擎回测结果对比")
    print("=" * 60)
    
    if len(results) > 0:
        # 构建对比表格
        comparison = {
            'success': True,
            'comparison': {},
            'summary': {}
        }
        
        # 详细结果
        for engine_name, result in results.items():
            comparison['comparison'][engine_name] = {
                'total_return': f"{result['total_return']:.2%}",
                'annual_return': f"{result['annual_return']:.2%}",
                'max_drawdown': f"{result['max_drawdown']:.2%}",
                'sharpe_ratio': f"{result['sharpe_ratio']:.2f}",
                'total_trades': result['total_trades'],
                'win_rate': f"{result['win_rate']:.2%}",
                'final_capital': f"{result['final_capital']:,.2f}"
            }
        
        # 汇总统一
        if len(results) > 1:
            returns = [r['total_return'] for r in results.values()]
            comparison['summary'] = {
                'engine_count': len(results),
                'max_return': f"{max(returns):.2%}",
                'min_return': f"{min(returns):.2%}",
                'avg_return': f"{sum(returns)/len(returns):.2%}",
                'return_std': f"{(sum((x-sum(returns)/len(returns))**2 for x in returns)/len(returns))**0.5:.2%}",
                'consistency': '高' if max(returns) - min(returns) < 0.01 else '中' if max(returns) - min(returns) < 0.05 else '低'
            }
        
        # 错误信息
        if errors:
            comparison['errors'] = errors
        
        print(format_output(comparison))
    else:
        print(format_output({
            'success': False,
            'message': '所有引擎回测均失败',
            'errors': errors
        }))
    
    return 0 if len(results) > 0 else 1


def cmd_factorbacktest(args) -> int:
    """因子回测 - 测试因子预测能力(IC,分层收益)"""
    from .api.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    # 检查数据库连接
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：python -m agentquant.cli db start'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    
    # 解析因子参数
    factor_params = {}
    if args.params:
        try:
            factor_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    try:
        # 运行因子测试
        result = api.run_factor_test(
            factor_name=args.factor,
            codes=codes,
            start_date=args.start,
            end_date=args.end,
            factor_params=factor_params,
            method=args.method
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'因子回测失败: {str(e)}'
        }))
        return 1


def cmd_strategybacktest(args) -> int:
    """策略回测 - 测试策略盈利能力(资金曲线,收益率等)"""
    from .api.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    # 检查数据库连接
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：python -m agentquant.cli db start'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    code = codes[0]  # 目前只支持单只股票回测
    
    # 解析策略参数
    strategy_params = {}
    if args.params:
        try:
            strategy_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    # 多引擎对比模糊
    if args.compare:
        return _run_strategy_compare_backtest(api, args, code, strategy_params)
    
    # 单引擎模糊
    return _run_single_strategy_backtest(api, args, code, strategy_params)


def _run_single_strategy_backtest(api, args, code: str, strategy_params: Dict[str, Any]) -> int:
    """运行单引擎策略回测"""
    try:
        result = api.run_strategy_backtest(
            strategy_name=args.strategy,
            code=code,
            start_date=args.start,
            end_date=args.end,
            init_capital=args.capital,
            strategy_params=strategy_params,
            engine=args.engine if args.engine else None
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'策略回测失败: {str(e)}'
        }))
        return 1


def _run_strategy_compare_backtest(api, args, code: str, strategy_params: Dict[str, Any]) -> int:
    """运行多引擎策略回测对比"""
    available_engines = api.get_available_engines()
    engines_to_test = [e['type'] for e in available_engines if e['available']]
    
    if len(engines_to_test) < 2:
        print(format_output({
            'success': False,
            'message': f'可用引擎不足2个，无法进行比对（当前可用 {engines_to_test}）'
        }))
        return 1
    
    print(format_output({
        'message': f'开始多引擎策略回测对比',
        'engines': engines_to_test,
        'strategy': args.strategy,
        'code': code,
        'start_date': args.start.strftime('%Y-%m-%d'),
        'end_date': args.end.strftime('%Y-%m-%d'),
        'strategy_params': strategy_params
    }))
    print("-" * 60)
    
    results = {}
    errors = {}
    
    for engine_name in engines_to_test:
        print(f"\n正在使用引擎 '{engine_name}' 运行策略回测...")
        try:
            result = api.run_strategy_backtest(
                strategy_name=args.strategy,
                code=code,
                start_date=args.start,
                end_date=args.end,
                init_capital=args.capital,
                strategy_params=strategy_params,
                engine=engine_name
            )
            
            if result.get('success'):
                results[engine_name] = result
                print(f"  回测成功 - 总收拢 {result['total_return']:.2%}")
            else:
                errors[engine_name] = result.get('error', '未知错误')
                print(f"  回测失败 - {result.get('error', '未知错误')}")
        except Exception as e:
            errors[engine_name] = str(e)
            print(f"  回测异常 - {e}")
    
    print("\n" + "=" * 60)
    print("多引擎策略回测结果对比")
    print("=" * 60)
    
    if len(results) > 0:
        comparison = {
            'success': True,
            'comparison': {},
            'summary': {}
        }
        
        for engine_name, result in results.items():
            comparison['comparison'][engine_name] = {
                'total_return': f"{result['total_return']:.2%}",
                'annual_return': f"{result['annual_return']:.2%}",
                'max_drawdown': f"{result['max_drawdown']:.2%}",
                'sharpe_ratio': f"{result['sharpe_ratio']:.2f}",
                'total_trades': result['total_trades'],
                'win_rate': f"{result['win_rate']:.2%}",
                'final_capital': f"{result['final_capital']:,.2f}"
            }
        
        if len(results) > 1:
            returns = [r['total_return'] for r in results.values()]
            comparison['summary'] = {
                'engine_count': len(results),
                'max_return': f"{max(returns):.2%}",
                'min_return': f"{min(returns):.2%}",
                'avg_return': f"{sum(returns)/len(returns):.2%}",
                'return_std': f"{(sum((x-sum(returns)/len(returns))**2 for x in returns)/len(returns))**0.5:.2%}",
                'consistency': '高' if max(returns) - min(returns) < 0.01 else '中' if max(returns) - min(returns) < 0.05 else '低'
            }
        
        if errors:
            comparison['errors'] = errors
        
        print(format_output(comparison))
    else:
        print(format_output({
            'success': False,
            'message': '所有引擎策略回测均失败',
            'errors': errors
        }))
    
    return 0 if len(results) > 0 else 1


def cmd_run_factor(args) -> int:
    """运行因子计算（自动创建任务记录）"""
    api = BacktestToolAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：python -m agentquant.cli db start'
        }))
        return 1
    
    try:
        codes = [c.strip() for c in args.codes.split(',')]
        factor_params = {}
        if args.window:
            factor_params['window'] = args.window
        
        result = api.calculate_factor_values(
            factor_code=args.factor,
            codes=codes,
            factor_params=factor_params
        )
        
        # 添加历史查询提示
        if result.get('success') and result.get('task_id'):
            result['history_query'] = f"python -m agentquant.cli run-factor --history --task-id {result['task_id']}"
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'因子计算失败: {str(e)}'
        }))
        return 1


def cmd_run_factor_history(args) -> int:
    """查询因子计算历史记录"""
    task_mgr = TaskManager()
    
    try:
        if args.task_id:
            # 查询指定任务
            task = task_mgr.get_task(args.task_id)
            if not task:
                print(format_output({
                    'success': False,
                    'message': f'任务不存在: {args.task_id}'
                }))
                return 1
            
            print(format_output({
                'success': True,
                'task': task
            }))
        else:
            # 查询历史列表
            tasks = task_mgr.list_tasks(
                task_type='factor_calc',
                limit=args.limit or 20
            )
            print(format_output({
                'success': True,
                'count': len(tasks),
                'tasks': tasks
            }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'查询历史失败: {str(e)}'
        }))
        return 1


def cmd_run_strategy(args) -> int:
    """运行策略回测（自动创建任务记录）"""
    api = BacktestToolAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：python -m agentquant.cli db start'
        }))
        return 1
    
    try:
        codes = [c.strip() for c in args.codes.split(',')]
        strategy_params = {}
        if args.fast:
            strategy_params['fast_period'] = args.fast
        if args.slow:
            strategy_params['slow_period'] = args.slow
        
        result = api.run_strategy_backtest(
            strategy_name=args.strategy,
            codes=codes,
            start_date=args.start,
            end_date=args.end,
            strategy_params=strategy_params
        )
        
        # 添加历史查询提示
        if result.get('success') and result.get('task_id'):
            result['history_query'] = f"python -m agentquant.cli run-strategy --history --task-id {result['task_id']}"
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'策略回测失败: {str(e)}'
        }))
        return 1


def cmd_run_strategy_history(args) -> int:
    """查询策略回测历史记录"""
    task_mgr = TaskManager()
    
    try:
        if args.task_id:
            # 查询指定任务
            task = task_mgr.get_task(args.task_id)
            if not task:
                print(format_output({
                    'success': False,
                    'message': f'任务不存在: {args.task_id}'
                }))
                return 1
            
            print(format_output({
                'success': True,
                'task': task
            }))
        else:
            # 查询历史列表
            tasks = task_mgr.list_tasks(
                task_type='strategy_backtest',
                limit=args.limit or 20
            )
            print(format_output({
                'success': True,
                'count': len(tasks),
                'tasks': tasks
            }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'查询历史失败: {str(e)}'
        }))
        return 1


def cmd_run_factor_main(args) -> int:
    """run-factor命令主入口"""
    if args.history:
        return cmd_run_factor_history(args)
    
    # 验证必要参数
    if not args.codes:
        print(format_output({
            'success': False,
            'message': '缺少必要参数: --codes'
        }))
        return 1
    
    if not args.factor:
        print(format_output({
            'success': False,
            'message': '缺少必要参数: --factor'
        }))
        return 1
    
    return cmd_run_factor(args)


def cmd_run_strategy_main(args) -> int:
    """run-strategy命令主入口"""
    if args.history:
        return cmd_run_strategy_history(args)
    
    # 验证必要参数
    if not args.codes:
        print(format_output({
            'success': False,
            'message': '缺少必要参数: --codes'
        }))
        return 1
    
    if not args.strategy:
        print(format_output({
            'success': False,
            'message': '缺少必要参数: --strategy'
        }))
        return 1
    
    if not args.start:
        print(format_output({
            'success': False,
            'message': '缺少必要参数: --start'
        }))
        return 1
    
    if not args.end:
        print(format_output({
            'success': False,
            'message': '缺少必要参数: --end'
        }))
        return 1
    
    return cmd_run_strategy(args)


def main():
    """主入口"""
    parser = argparse.ArgumentParser(
        description='StockClaw CLI - 股票数据管理与回测工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  # 更新单只股票数据
  python -m agentquant.cli update --codes 000001.SZ --date 2026-04-20
  
数据管理命令:
  # 更新数据（从QMT到本地数据库
  python -m agentquant.cli update --codes 000001.SZ --date 2024-06-01
  python -m agentquant.cli update --date 2024-06-01  # 更新所有股票
  
  # 查询数据
  python -m agentquant.cli query --code 000001.SZ --start 2024-01-01 --end 2024-06-01
  python -m agentquant.cli query --codes 000001.SZ,000002.SZ --start 2024-01-01 --end 2024-06-01
  
  # 获取最新交易日志
  python -m agentquant.cli latest
  
  # 获取股票列表
  python -m agentquant.cli stocks --limit 10

因子管理命令:
  # 查看可用因子
  python -m agentquant.cli factor list
  
  # 查看因子详情
  python -m agentquant.cli factor info CROSS
  
  # 计算因子
  python -m agentquant.cli factor calc CROSS --date 2024-06-01 --codes 000001.SZ
  
  # 因子回测（IC测试
  python -m agentquant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 因子回测（分层收益测试）
  python -m agentquant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --method layer

策略管理命令:
  # 查看可用策略
  python -m agentquant.cli strategy list
  
  # 查看策略详情
  python -m agentquant.cli strategy info CROSS_STRATEGY
  
  # 策略回测
  python -m agentquant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01

其他命令:
  # 查看可用回测引擎
  python -m agentquant.cli engines

数据源管理命
  # 列出可用数据源（自动检查连接状态）
  python -m agentquant.cli source list

  # 从数据源下载数据（自动选择可用数据源）
  python -m agentquant.cli data download --stocks 000001.SZ --start 2024-01-01 --end 2024-06-01

  # 指定数据源下拉框
  python -m agentquant.cli source download --type qmt --codes 000001.SZ --start 2024-01-01 --end 2024-06-01

  # 高Tushare 下载数据
  python -m agentquant.cli source download --type tushare --token YOUR_TOKEN --codes 000001.SZ --start 2024-01-01 --end 2024-06-01

回测结果管理命令:
  # 列出历史回测结果
  python -m agentquant.cli result list

  # 查看最新回测详细
  python -m agentquant.cli result show

  # 生成 HTML 报告
  python -m agentquant.cli result report --open

  # 对比多个回测
  python -m agentquant.cli result compare --ids ID1,ID2,ID3

使用说明:
  1. 所有日期格式为 YYYY-MM-DD
  2. 股票代码格式000001.SZ（深市）高600000.SH（沪市）
  3. 使用 --help 查看具体命令的详细参数，如：python -m agentquant.cli factor backtest --help
  4. 因子是纯数据计算，策略是完整交易系统（包含仓位管理、风控等）
        '''
    )
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令', metavar='COMMAND')
    
    # db 命令
    db_parser = subparsers.add_parser(
        'db',
        help='数据库管理',
        description='管理数据库服务，包括启动、停止、查看状态',
        epilog='''
示例:
  # 启动数据库服务（后台运行动态）
  python -m agentquant.cli db start --background
  
  # 启动数据库服务（前台运行，Windows高）
  python -m agentquant.cli db start
  
  # 停止数据库服务
  python -m agentquant.cli db stop
  
  # 查看数据库状态栏
  python -m agentquant.cli db status

说明:
  - start: 启动数据库服务
  - stop: 停止数据库服务
  - status: 查看数据库运行状态栏
  - --background: 在后台运行（Windows支持）
        '''
    )
    db_parser.add_argument('action', choices=['start', 'stop', 'status'],
                          help='操作: start=启动, stop=停止, status=查看状态')
    db_parser.add_argument('--background', action='store_true',
                          help='后台运行模式（仅Windows）')
    db_parser.set_defaults(func=cmd_db)
    
    # update 命令
    update_parser = subparsers.add_parser(
        'update',
        help='从QMT更新数据到数据库',
        description='从QMT获取实时行情数据并保存到本地DuckDB数据库',
        epilog='''
前提条件:
  1. QMT客户端已登录
  2. QMT已下载所需日期的数组
  3. DuckDB数据库服务已启动

示例:
  # 更新单只股票
  python -m agentquant.cli update --codes 000001.SZ --date 2024-06-01
  
  # 更新多只股票
  python -m agentquant.cli update --codes 000001.SZ,000002.SZ --date 2024-06-01
  
  # 更新所有股票（不指导-codes高）
  python -m agentquant.cli update --date 2024-06-01
  
  # 更新今日数据（默认日期）
  python -m agentquant.cli update

注意:
  - 股票代码格式：深高00001.SZ，沪高00000.SH
  - 不指导-codes时会更新所有股票，耗时较长
  - 重复更新同一日期会覆盖已有数组
        '''
    )
    update_parser.add_argument(
        '--codes',
        type=str,
        help='股票代码，多个用逗号分隔，如高00001.SZ,000002.SZ。不指定则更新所有股票'
    )
    update_parser.add_argument(
        '--date',
        type=parse_date,
        default=date.today(),
        help='目标日期，格式：YYYY-MM-DD，默认为今天'
    )
    update_parser.set_defaults(func=cmd_update)
    
    # query 命令
    query_parser = subparsers.add_parser(
        'query',
        help='查询数据库中的数组',
        description='从本地DuckDB数据库查询股票历史行情数据',
        epilog='''
前提条件:
  1. DuckDB数据库服务已启动
  2. 数据已存在于数据库（需先运行update命令更新数据）

示例:
  # 查询单只股票
  python -m agentquant.cli query --code 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 查询多只股票
  python -m agentquant.cli query --codes 000001.SZ,000002.SZ --start 2024-01-01 --end 2024-06-01

输出字段:
  - trade_date: 交易日期
  - code: 股票代码
  - open: 开盘价
  - high: 最高价
  - low: 最低价
  - close: 收盘高
  - volume: 成交高
  - amount: 成交金额

注意:
  - --code 高--codes 必须指定其中一致
  - 日期格式：YYYY-MM-DD
  - 查询前确保数据已更新
        '''
    )
    query_group = query_parser.add_mutually_exclusive_group(required=True)
    query_group.add_argument(
        '--code',
        type=str,
        help='单只股票代码，如高00001.SZ'
    )
    query_group.add_argument(
        '--codes',
        type=str,
        help='多只股票代码，用逗号分隔，如高00001.SZ,000002.SZ'
    )
    query_parser.add_argument(
        '--start',
        type=parse_date,
        required=True,
        help='开始日期，格式：YYYY-MM-DD'
    )
    query_parser.add_argument(
        '--end',
        type=parse_date,
        required=True,
        help='结束日期，格式：YYYY-MM-DD'
    )
    query_parser.set_defaults(func=cmd_query)
    
    # latest 命令
    latest_parser = subparsers.add_parser(
        'latest',
        help='获取数据库中最新的交易日期',
        description='查询本地数据库中已存储的最新交易日期。用于确认数据更新状态'
    )
    latest_parser.set_defaults(func=cmd_latest)
    
    # stocks 命令
    stocks_parser = subparsers.add_parser(
        'stocks',
        help='获取股票列表',
        description='获取系统中的股票列表，包括股票代码和名称',
        epilog='''
示例:
  # 获取所有股票
  python -m agentquant.cli stocks
  
  # 只获取前10只股票
  python -m agentquant.cli stocks --limit 10

输出字段:
  - code: 股票代码
  - name: 股票名称
  - industry: 所属行动
        '''
    )
    stocks_parser.add_argument(
        '--limit',
        type=int,
        help='限制返回数量，不指定则返回所有股票'
    )
    stocks_parser.set_defaults(func=cmd_stocks)
    
    # factor 命令 - 使用子命
    factor_parser = subparsers.add_parser(
        'factor',
        help='因子管理',
        description='因子管理命令。因子是纯数据计算，输出信号价值',
        epilog='''
示例:
  # 列出所有可用因子
  python -m agentquant.cli factor list
  
  # 查看CROSS因子详情
  python -m agentquant.cli factor info CROSS
  
  # 计算CROSS因子024-06-01的高
  python -m agentquant.cli factor calc CROSS --date 2024-06-01 --codes 000001.SZ
  
  # 对CROSS因子进行IC测试
  python -m agentquant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 对CROSS因子进行分层收益测试
  python -m agentquant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --method layer

说明:
  - factor list: 显示所有可用因子及其参数
  - factor info: 查看因子的详细说明和参数定义
  - factor calc: 计算指定日期的因子值，输出原始值、排名、百分位、Z-score
  - factor backtest: 测试因子的预测能力（IC值或分层收益高
        '''
    )
    factor_subparsers = factor_parser.add_subparsers(dest='factor_subcommand', help='因子子命', metavar='SUBCOMMAND')
    
    # factor list
    factor_list_parser = factor_subparsers.add_parser(
        'list',
        help='列出所有可用因子',
        description='列出系统中所有可用的因子，包括因子名称、描述和参数组'
    )
    factor_list_parser.set_defaults(func=cmd_factor)
    
    # factor info
    factor_info_parser = factor_subparsers.add_parser(
        'info',
        help='查看因子详情',
        description='查看指定因子的详细信息，包括描述、参数定义和默认价值'
    )
    factor_info_parser.add_argument('name', type=str, help='因子名称，如：CROSS, MACD, MA, RSI')
    factor_info_parser.set_defaults(func=cmd_factor)
    
    # factor calc
    factor_calc_parser = factor_subparsers.add_parser(
        'calc',
        help='计算因子',
        description='计算指定日期股票的因子值。输出包括原始值、排名、百分位和Z-score高',
        epilog='''
示例:
  # 计算单只股票的因子
  python -m agentquant.cli factor calc CROSS --date 2024-06-01 --codes 000001.SZ
  
  # 计算多只股票的因子
  python -m agentquant.cli factor calc CROSS --date 2024-06-01 --codes 000001.SZ,000002.SZ
  
  # 计算所有股票的因子值，只显示前50高
  python -m agentquant.cli factor calc CROSS --date 2024-06-01 --limit 50

输出字段:
  - calc_date: 计算日期
  - code: 股票代码
  - factor_code: 因子代码
  - value: 因子原始
  - rank_value: 排名（从高到低）
  - percentile: 百分位（0-1高
  - zscore: Z-score标准化
        '''
    )
    factor_calc_parser.add_argument('name', type=str, help='因子名称，如：CROSS, MACD, MA, RSI')
    factor_calc_parser.add_argument('--date', type=parse_date, required=True, help='计算日期，格式：YYYY-MM-DD')
    factor_calc_parser.add_argument('--codes', type=str, help='股票代码，多个用逗号分隔，如：00001.SZ,000002.SZ。不指定则计算所有股票')
    factor_calc_parser.add_argument('--params', type=str, help='因子参数，JSON格式，如：\'{"short_window":10,"long_window":30}\'')
    factor_calc_parser.add_argument('--limit', type=int, default=20, help='限制返回结果数量，默高0，设计返回全部')
    factor_calc_parser.set_defaults(func=cmd_factor)
    
    # factor backtest
    factor_backtest_parser = factor_subparsers.add_parser(
        'backtest',
        help='因子回测（IC测试、分层收益）',
        description='测试因子的预测能力。IC测试计算因子值与未来1日收益的相关系数；分层测试将股票按因子值分5层，观察各层收益差异步',
        epilog='''
示例:
  # IC测试（默认）
  python -m agentquant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 分层收益测试
  python -m agentquant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --method layer
  
  # 带参数的回测
  python -m agentquant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --params '{"short_window":10,"long_window":30}'

测试方法说明:
  ic: IC测试，计算因子值与未来1日收益的相关系数
      - IC > 0.03: 因子有一定预测能量
      - IC > 0.05: 因子预测能力较强
      - IC绝对值越大，预测能力越强
  
  layer: 分层收益测试，按因子值将股票分为5高
      - 观察各层收益是否单调（L1 < L2 < L3 < L4 < L5高
      - 单调性越好，因子越有理
      - 计算顶层与底层收益差（spread高
        '''
    )
    factor_backtest_parser.add_argument('name', type=str, help='因子名称，如：CROSS, MACD, MA, RSI')
    factor_backtest_parser.add_argument('--start', type=parse_date, required=True, help='开始日期，格式：YYYY-MM-DD')
    factor_backtest_parser.add_argument('--end', type=parse_date, required=True, help='结束日期，格式：YYYY-MM-DD')
    factor_backtest_parser.add_argument('--codes', type=str, default='000001.SZ', help='股票代码，多个用逗号分隔，如高00001.SZ,000002.SZ')
    factor_backtest_parser.add_argument('--params', type=str, help='因子参数，JSON格式，如：\'{"short_window":5,"long_window":20}\'')
    factor_backtest_parser.add_argument('--method', type=str, choices=['ic', 'layer'], default='ic', help='测试方法：ic=IC测试，layer=分层收益测试')
    factor_backtest_parser.set_defaults(func=cmd_factor)
    
    # strategy 命令 - 使用子命
    strategy_parser = subparsers.add_parser(
        'strategy',
        help='策略管理',
        description='策略管理命令。策略是完整的交易系统，包含信号生成、仓位管理、风控等级',
        epilog='''
示例:
  # 列出所有可用策略
  python -m agentquant.cli strategy list
  
  # 查看CROSS_STRATEGY策略详情
  python -m agentquant.cli strategy info CROSS_STRATEGY
  
  # 对CROSS_STRATEGY进行回测
  python -m agentquant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 指定初始资金和参数进行回高
  python -m agentquant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --capital 500000 --params '{"short_window":10,"long_window":30}'

说明:
  - strategy list: 显示所有可用策略及其参数
  - strategy info: 查看策略的详细说明、参数和默认配置
  - strategy backtest: 测试策略的盈利能力，输出资金曲线和各项指导

因子与策略的区别:
  - 因子：纯数据计算，输出信号值（如CROSS因子计算均线差值）
  - 策略：完整交易系统，使用因子生成信号，并执行买卖、仓位管理、风险
        '''
    )
    strategy_subparsers = strategy_parser.add_subparsers(dest='strategy_subcommand', help='策略子命', metavar='SUBCOMMAND')
    
    # strategy list
    strategy_list_parser = strategy_subparsers.add_parser(
        'list',
        help='列出所有可用策略',
        description='列出系统中所有可用的策略，包括策略名称、类型、描述和可调参数组'
    )
    strategy_list_parser.set_defaults(func=cmd_strategy)
    
    # strategy info
    strategy_info_parser = strategy_subparsers.add_parser(
        'info',
        help='查看策略详情',
        description='查看指定策略的详细信息，包括描述、使用的因子、参数定义、默认配置等级'
    )
    strategy_info_parser.add_argument('name', type=str, help='策略名称，如：CROSS_STRATEGY, MACD_STRATEGY')
    strategy_info_parser.set_defaults(func=cmd_strategy)
    
    # strategy backtest
    strategy_backtest_parser = strategy_subparsers.add_parser(
        'backtest',
        help='策略回测（资金曲线、收益率等）',
        description='测试策略的盈利能力。输出资金曲线、总收益率、年化收益、最大回撤、夏普比率、交易记录等级',
        epilog='''
示例:
  # 基本回测
  python -m agentquant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 指定初始资金
  python -m agentquant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --capital 500000
  
  # 自定义策略参数
  python -m agentquant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --params '{"short_window":10,"long_window":30}'
  
  # 指定回测引擎
  python -m agentquant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --engine vnpy

输出指标说明:
  - total_return: 总收益率
  - annual_return: 年化收益高
  - max_drawdown: 最大回撤（负数表示亏损高
  - sharpe_ratio: 夏普比率（风险调整后收益高1较好坏
  - total_trades: 总交易次数
  - win_rate: 胜率
  - trades: 详细交易记录（买高卖出时间、价格、数量、原因）
        '''
    )
    strategy_backtest_parser.add_argument('name', type=str, help='策略名称，如：CROSS_STRATEGY, MACD_STRATEGY')
    strategy_backtest_parser.add_argument('--start', type=parse_date, required=True, help='开始日期，格式：YYYY-MM-DD')
    strategy_backtest_parser.add_argument('--end', type=parse_date, required=True, help='结束日期，格式：YYYY-MM-DD')
    strategy_backtest_parser.add_argument('--codes', type=str, default='000001.SZ', help='股票代码，多个用逗号分隔，如高00001.SZ,000002.SZ')
    strategy_backtest_parser.add_argument('--capital', type=float, default=1000000.0, help='初始资金，默高000000')
    strategy_backtest_parser.add_argument('--params', type=str, help='策略参数，JSON格式，如：\'{"short_window":5,"long_window":20}\'')
    strategy_backtest_parser.add_argument('--engine', type=str, choices=['local', 'cskhquant', 'jqdata', 'vnpy'], help='指定回测引擎：local=本地引擎(默认), cskhquant=CSKhQuant, jqdata=聚宽, vnpy=VNPY')
    strategy_backtest_parser.set_defaults(func=cmd_strategy)
    
    # engines 命令
    engines_parser = subparsers.add_parser(
        'engines',
        help='查看可用回测引擎',
        description='显示所有可用的回测引擎及其状态'
    )
    engines_parser.set_defaults(func=cmd_engines)

    # dynamic-factor 命令
    dynamic_factor_parser = subparsers.add_parser(
        'dynamic-factor',
        help='动态因子管理（Agent开发因子入口）',
        description='''管理存储在数据库中的动态因子。Agent可以通过此命令创建、查看、删除自定义因子

因子代码规范围
  1. 类必须继承自 JQFactor
  2. 必须定义 meta 属性（FactorMeta类型
  3. 必须实现 calc 方法
  4. calc 方法接收 data 字典，返回标量

使用 --template 参数查看完整代码模板高''',
        epilog=f'''
示例:
  # 查看因子代码模板
  python -m agentquant.cli dynamic-factor --template

  # 列出所有动态因子
  python -m agentquant.cli dynamic-factor list

  # 查看因子详情
  python -m agentquant.cli dynamic-factor get --code MY_FACTOR

  # 从文件保存因子
  python -m agentquant.cli dynamic-factor save --code MY_FACTOR --name "我的因子" --file factor.py

  # 直接传入代码保存因子
  python -m agentquant.cli dynamic-factor save --code MY_FACTOR --name "我的因子" --code-text "..."

  # 测试因子编译
  python -m agentquant.cli dynamic-factor test --code MY_FACTOR

  # 删除因子
  python -m agentquant.cli dynamic-factor delete --code MY_FACTOR

因子代码模板示例:
{FACTOR_TEMPLATE}
        '''
    )
    dynamic_factor_parser.add_argument('--template', action='store_true', help='显示因子代码模板')
    dynamic_factor_parser.add_argument('action', choices=['list', 'get', 'save', 'delete', 'test'], nargs='?',
                                      help='操作: list=列出, get=查看, save=保存, delete=删除, test=测试编译')
    dynamic_factor_parser.add_argument('--code', type=str, help='因子代码（唯一标识）')
    dynamic_factor_parser.add_argument('--name', type=str, help='因子显示名称')
    dynamic_factor_parser.add_argument('--category', type=str, help='因子分类：估价质量/动量/技高情绪/成长')
    dynamic_factor_parser.add_argument('--description', type=str, help='因子详细描述')
    dynamic_factor_parser.add_argument('--file', type=str, help='源代码文件路径（Python文件）')
    dynamic_factor_parser.add_argument('--code-text', type=str, help='源代码文本（直接传入口）')
    dynamic_factor_parser.add_argument('--meta', type=str, help='元数据JSON字符串，如：\'{{"max_window": 30}}\'')
    dynamic_factor_parser.set_defaults(func=cmd_dynamic_factor)

    # dynamic-strategy 命令
    dynamic_strategy_parser = subparsers.add_parser(
        'dynamic-strategy',
        help='动态策略管理（Agent开发策略入口）',
        description='''管理存储在数据库中的动态策略。Agent可以通过此命令创建、查看、删除自定义策策略

策略代码规范围
  1. 类必须继承自 Strategy
  2. 必须定义 meta 属性（字典类型
  3. 必须实现 init 方法（初始化参数组
  4. 必须实现 on_bar 高on_data 方法（处理数据）
  5. 通过返回交易信号 dict 执行买卖

使用 --template 参数查看完整代码模板高''',
        epilog=f'''
示例:
  # 查看策略代码模板
  python -m agentquant.cli dynamic-strategy --template

  # 列出所有动态策略
  python -m agentquant.cli dynamic-strategy list

  # 查看策略详情
  python -m agentquant.cli dynamic-strategy get --code MY_STRATEGY

  # 从文件保存策略
  python -m agentquant.cli dynamic-strategy save --code MY_STRATEGY --name "我的策略" --file strategy.py

  # 直接传入代码保存策略
  python -m agentquant.cli dynamic-strategy save --code MY_STRATEGY --name "我的策略" --code-text "..."

  # 删除策略
  python -m agentquant.cli dynamic-strategy delete --code MY_STRATEGY

策略代码模板示例:
{STRATEGY_TEMPLATE}
        '''
    )
    dynamic_strategy_parser.add_argument('--template', action='store_true', help='显示策略代码模板')
    dynamic_strategy_parser.add_argument('action', choices=['list', 'get', 'save', 'delete'], nargs='?',
                                        help='操作: list=列出, get=查看, save=保存, delete=删除')
    dynamic_strategy_parser.add_argument('--code', type=str, help='策略代码（唯一标识）')
    dynamic_strategy_parser.add_argument('--name', type=str, help='策略显示名称')
    dynamic_strategy_parser.add_argument('--description', type=str, help='策略详细描述')
    dynamic_strategy_parser.add_argument('--file', type=str, help='源代码文件路径（Python文件）')
    dynamic_strategy_parser.add_argument('--code-text', type=str, help='源代码文本（直接传入口）')
    dynamic_strategy_parser.add_argument('--meta', type=str, help='元数据JSON字符串，如：\'{{"category": "趋势"}}\'')
    dynamic_strategy_parser.set_defaults(func=cmd_dynamic_strategy)

    # doctor 命令
    doctor_parser = subparsers.add_parser(
        'doctor',
        help='系统诊断',
        description='检查系统运行状态，包括版本、数据库、QMT、回测引擎等级等',
    )
    doctor_parser.set_defaults(func=cmd_doctor)

    # selftest 命令
    selftest_parser = subparsers.add_parser(
        'selftest',
        help='自我测试',
        description='运行完整的自动化测试流程，验证所高CLI 功能量'
    )
    selftest_parser.set_defaults(func=cmd_selftest)

    # gui 命令 - 启动/停止GUI
    gui_parser = subparsers.add_parser(
        'gui',
        help='启动或停止图形界面',
        description='启动或停止AgentQuant数据管理系统的图形界面',
        epilog='''
示例:
  # 启动GUI（后台运行，不阻塞命令行）
  python -m agentquant.cli gui

  # 启动GUI（前台运行，阻塞命令行）
  python -m agentquant.cli gui --foreground

  # 停止GUI
  python -m agentquant.cli gui --stop
        '''
    )
    gui_parser.add_argument(
        '--stop', '-s',
        action='store_true',
        help='停止正在运行的GUI进程'
    )
    gui_parser.add_argument(
        '--foreground', '-f',
        action='store_true',
        help='前台运行（阻塞当前命令行）'
    )
    gui_parser.set_defaults(func=cmd_gui)

    # source 命令 - 数据源管道
    source_parser = subparsers.add_parser(
        'source',
        help='数据源管道',
        description='管理多数据源，支持QMT、baostock、Tushare高',
        epilog='''
示例:
  # 列出可用数据高
  python -m agentquant.cli source list

  # 检查数据源
  python -m agentquant.cli source check --type baostock
  python -m agentquant.cli source check --type tushare --token YOUR_TOKEN

  # 高baostock 下载数据
  python -m agentquant.cli source download --type baostock --codes 000001.SZ --start 2024-01-01 --end 2024-06-01

  # 高Tushare 下载数据
  python -m agentquant.cli source download --type tushare --token YOUR_TOKEN --codes 000001.SZ --start 2024-01-01 --end 2024-06-01

  # 获取股票列表
  python -m agentquant.cli source stocks --type baostock --market sh
        '''
    )
    source_subparsers = source_parser.add_subparsers(dest='action', help='数据源操作')

    # source list
    source_list_parser = source_subparsers.add_parser('list', help='列出可用数据高')
    source_list_parser.set_defaults(func=cmd_source)

    # source check
    source_check_parser = source_subparsers.add_parser('check', help='检查数据源可用')
    source_check_parser.add_argument('--type', choices=['qmt', 'baostock', 'tushare'], help='数据源类型（可选，默认检查所有）')
    source_check_parser.add_argument('--token', help='Tushare Token（仅tushare需要）')
    source_check_parser.set_defaults(func=cmd_source)

    # source download
    source_download_parser = source_subparsers.add_parser('download', help='从数据源下载数据')
    source_download_parser.add_argument('--type', required=True, choices=['qmt', 'baostock', 'tushare'], help='数据源类型')
    source_download_parser.add_argument('--codes', help='股票代码，多个用逗号分隔')
    source_download_parser.add_argument('--all', action='store_true', help='下载所有股票')
    source_download_parser.add_argument('--market', choices=['sh', 'sz', 'bj', 'all'], help='市场过滤')
    source_download_parser.add_argument('--start', type=parse_date, required=True, help='开始日期')
    source_download_parser.add_argument('--end', type=parse_date, required=True, help='结束日期')
    source_download_parser.add_argument('--token', help='Tushare Token（仅tushare需要）')
    source_download_parser.add_argument('--dry-run', action='store_true', help='仅测试不保存')
    source_download_parser.set_defaults(func=cmd_source)

    # source stocks
    source_stocks_parser = source_subparsers.add_parser('stocks', help='获取股票列表')
    source_stocks_parser.add_argument('--type', required=True, choices=['qmt', 'baostock', 'tushare'], help='数据源类型')
    source_stocks_parser.add_argument('--market', choices=['sh', 'sz', 'bj', 'all'], help='市场过滤')
    source_stocks_parser.add_argument('--token', help='Tushare Token（仅tushare需要）')
    source_stocks_parser.add_argument('--limit', type=int, help='限制返回数量')
    source_stocks_parser.set_defaults(func=cmd_source)

    # run-factor 命令 - 运行因子计算（自动创建任务记录）
    run_factor_parser = subparsers.add_parser(
        'run-factor',
        help='运行因子计算',
        description='运行因子计算并自动记录任务历史',
        epilog='''
示例:
  # 运行因子计算
  python -m agentquant.cli run-factor --codes 000001.SZ --factor MA5 --window 5
  
  # 查询历史记录
  python -m agentquant.cli run-factor --history
  python -m agentquant.cli run-factor --history --limit 10
  
  # 查看指定任务详情
  python -m agentquant.cli run-factor --history --task-id TASK_ID
        '''
    )
    run_factor_parser.add_argument('--codes', help='股票代码，多个用逗号分隔')
    run_factor_parser.add_argument('--factor', help='因子代码')
    run_factor_parser.add_argument('--window', type=int, help='窗口期')
    run_factor_parser.add_argument('--history', action='store_true', help='查询历史记录')
    run_factor_parser.add_argument('--task-id', help='指定任务ID查询详情')
    run_factor_parser.add_argument('--limit', type=int, help='限制返回数量')
    run_factor_parser.set_defaults(func=cmd_run_factor_main)

    # run-strategy 命令 - 运行策略回测（自动创建任务记录）
    run_strategy_parser = subparsers.add_parser(
        'run-strategy',
        help='运行策略回测',
        description='运行策略回测并自动记录任务历史',
        epilog='''
示例:
  # 运行策略回测
  python -m agentquant.cli run-strategy --codes 000001.SZ --strategy CROSS --start 2024-01-01 --end 2024-06-01
  
  # 查询历史记录
  python -m agentquant.cli run-strategy --history
  python -m agentquant.cli run-strategy --history --limit 10
  
  # 查看指定任务详情
  python -m agentquant.cli run-strategy --history --task-id TASK_ID
        '''
    )
    run_strategy_parser.add_argument('--codes', help='股票代码，多个用逗号分隔')
    run_strategy_parser.add_argument('--strategy', help='策略代码')
    run_strategy_parser.add_argument('--start', help='开始日期')
    run_strategy_parser.add_argument('--end', help='结束日期')
    run_strategy_parser.add_argument('--capital', type=float, default=100000, help='初始资金')
    run_strategy_parser.add_argument('--fast', type=int, help='快线周期')
    run_strategy_parser.add_argument('--slow', type=int, help='慢线周期')
    run_strategy_parser.add_argument('--history', action='store_true', help='查询历史记录')
    run_strategy_parser.add_argument('--task-id', help='指定任务ID查询详情')
    run_strategy_parser.add_argument('--limit', type=int, help='限制返回数量')
    run_strategy_parser.set_defaults(func=cmd_run_strategy_main)

    # data 命令 - 数据管理
    setup_data_parser(subparsers)

    # strategy-dev 命令 - 策略开发工作
    setup_strategy_dev_parser(subparsers)

    # result 命令 - 回测结果管理
    result_parser = subparsers.add_parser(
        'result',
        help='回测结果管理',
        description='管理回测结果，支持列表、查看、对比、报告生成等操作',
        epilog='''
示例:
  # 列出历史回测结果
  python -m agentquant.cli result list
  python -m agentquant.cli result list --limit 10

  # 查看最新回测详细
  python -m agentquant.cli result show

  # 查看指定回测
  python -m agentquant.cli result show --id RESULT_ID

  # 生成 HTML 报告
  python -m agentquant.cli result report --id RESULT_ID --open

  # 对比多个回测
  python -m agentquant.cli result compare --ids ID1,ID2,ID3

  # 清理旧结算
  python -m agentquant.cli result clean --days 30

  # 删除结果
  python -m agentquant.cli result delete --id RESULT_ID
        '''
    )
    result_subparsers = result_parser.add_subparsers(dest='action', help='结果操作')

    # result list
    result_list_parser = result_subparsers.add_parser('list', help='列出历史回测结果')
    result_list_parser.add_argument('--limit', type=int, help='限制返回数量')
    result_list_parser.add_argument('--strategy', help='按策略过滤')
    result_list_parser.add_argument('--dir', help='结果目录')
    result_list_parser.set_defaults(func=cmd_result)

    # result show
    result_show_parser = result_subparsers.add_parser('show', help='查看回测详情')
    result_show_parser.add_argument('--id', help='结果ID')
    result_show_parser.add_argument('--dir', help='结果目录')
    result_show_parser.add_argument('--show-trades', action='store_true', help='显示交易记录')
    result_show_parser.set_defaults(func=cmd_result)

    # result report
    result_report_parser = result_subparsers.add_parser('report', help='生成 HTML 报告')
    result_report_parser.add_argument('--id', help='结果ID')
    result_report_parser.add_argument('--dir', help='结果目录')
    result_report_parser.add_argument('--open', action='store_true', help='自动打开报告')
    result_report_parser.set_defaults(func=cmd_result)

    # result compare
    result_compare_parser = result_subparsers.add_parser('compare', help='对比多个回测结果')
    result_compare_parser.add_argument('--ids', required=True, help='结果ID列表，用逗号分隔')
    result_compare_parser.add_argument('--dir', help='结果目录')
    result_compare_parser.set_defaults(func=cmd_result)

    # result clean
    result_clean_parser = result_subparsers.add_parser('clean', help='清理旧结算结果')
    result_clean_parser.add_argument('--days', type=int, default=30, help='保留天数')
    result_clean_parser.add_argument('--dir', help='结果目录')
    result_clean_parser.set_defaults(func=cmd_result)

    # result delete
    result_delete_parser = result_subparsers.add_parser('delete', help='删除回测结果')
    result_delete_parser.add_argument('--id', required=True, help='结果ID')
    result_delete_parser.add_argument('--dir', help='结果目录')
    result_delete_parser.set_defaults(func=cmd_result)

    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    return args.func(args)


if __name__ == '__main__':
    sys.exit(main())
