# -*- coding: utf-8 -*-
"""
聚宽风格因子基类
参考 jqfactor 设计
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, field
import pandas as pd
import numpy as np
import logging

# 从base导入以兼容旧代码
from .base import FactorRegistry, register_factor

logger = logging.getLogger(__name__)


@dataclass
class FactorMeta:
    """因子元数据"""
    code: str                           # 因子代码
    name: str                           # 因子名称
    category: str                       # 分类: 估值/质量/成长/动量/情绪/风险/技术
    description: str = ""               # 描述
    formula: str = ""                   # 计算公式
    unit: str = ""                      # 单位
    
    # 参数定义
    parameters: Dict[str, Dict] = field(default_factory=dict)
    
    # 数据依赖
    dependencies: List[str] = field(default_factory=list)
    
    # 最大回看窗口（交易日）
    max_window: int = 20
    
    # 是否支持动态参数
    support_params: bool = True


class JQFactor(ABC):
    """
    聚宽风格因子基类
    
    使用方式:
        class PE_TTM_Factor(JQFactor):
            meta = FactorMeta(
                code='PE_TTM',
                name='市盈率TTM',
                category='估值',
                dependencies=['pe_ratio'],
                max_window=1
            )
            
            def calc(self, data: Dict[str, pd.DataFrame]) -> pd.Series:
                pe = data['pe_ratio']
                return 1 / pe  # 低PE得高分
    """
    
    meta: FactorMeta = None
    
    def __init__(self, **params):
        """
        初始化因子
        
        Args:
            **params: 动态参数，覆盖meta中的默认值
        """
        if self.meta is None:
            raise ValueError(f"{self.__class__.__name__} 必须定义 meta 属性")
        
        self.params = self._get_default_params()
        self.params.update(params)
        self.logger = logging.getLogger(f"factor.{self.meta.code}")
    
    def _get_default_params(self) -> Dict[str, Any]:
        """获取默认参数"""
        defaults = {}
        for key, config in self.meta.parameters.items():
            defaults[key] = config.get('default')
        return defaults
    
    @abstractmethod
    def calc(self, data: Dict[str, pd.DataFrame]) -> pd.Series:
        """
        计算因子值
        
        Args:
            data: 依赖数据字典，key是dependency名称，value是DataFrame
                  DataFrame的index是日期，columns是股票代码
        
        Returns:
            因子值Series，index是股票代码，value是因子值
        """
        pass
    
    def pre_process(self, data: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
        """
        数据预处理
        
        子类可以重写此方法进行自定义预处理
        """
        return data
    
    def post_process(self, values: pd.Series) -> pd.Series:
        """
        结果后处理（去极值、标准化）
        
        1. MAD去极值
        2. Z-score标准化
        """
        if values.empty:
            return values
        
        # MAD去极值
        median = values.median()
        mad = (values - median).abs().median()
        
        if mad > 0:
            upper = median + 3 * 1.4826 * mad
            lower = median - 3 * 1.4826 * mad
            values = values.clip(lower, upper)
        
        # Z-score标准化
        std = values.std()
        if std > 0:
            values = (values - values.mean()) / std
        
        return values
    
    def calculate(self, data: Dict[str, pd.DataFrame]) -> pd.Series:
        """
        完整的计算流程
        
        Args:
            data: 原始数据字典
        
        Returns:
            处理后的因子值
        """
        # 预处理
        data = self.pre_process(data)
        
        # 计算因子值
        values = self.calc(data)
        
        # 后处理
        values = self.post_process(values)
        
        return values
    
    def get_info(self) -> Dict[str, Any]:
        """获取因子信息"""
        return {
            'code': self.meta.code,
            'name': self.meta.name,
            'category': self.meta.category,
            'description': self.meta.description,
            'formula': self.meta.formula,
            'parameters': self.meta.parameters,
            'dependencies': self.meta.dependencies,
            'max_window': self.meta.max_window
        }
    
    def get_help(self) -> str:
        """
        生成因子的help文本
        
        Returns:
            格式化的help字符串
        """
        lines = []
        lines.append(f"{'='*60}")
        lines.append(f"因子: {self.meta.code} - {self.meta.name}")
        lines.append(f"{'='*60}")
        lines.append("")
        lines.append(f"【分类】{self.meta.category}")
        lines.append("")
        lines.append(f"【描述】{self.meta.description}")
        lines.append("")
        
        if self.meta.formula:
            lines.append(f"【公式】{self.meta.formula}")
            lines.append("")
        
        if self.meta.unit:
            lines.append(f"【单位】{self.meta.unit}")
            lines.append("")
        
        lines.append(f"【数据依赖】{', '.join(self.meta.dependencies) if self.meta.dependencies else '无'}")
        lines.append("")
        lines.append(f"【最大回看窗口】{self.meta.max_window} 个交易日")
        lines.append("")
        
        if self.meta.parameters:
            lines.append("【参数说明】")
            for param_name, param_config in self.meta.parameters.items():
                param_type = param_config.get('type', 'unknown')
                default = param_config.get('default')
                desc = param_config.get('description', '')
                lines.append(f"  --{param_name}")
                lines.append(f"    类型: {param_type}")
                lines.append(f"    默认值: {default}")
                lines.append(f"    说明: {desc}")
                lines.append("")
        else:
            lines.append("【参数】无")
            lines.append("")
        
        lines.append("【使用示例】")
        lines.append(f"  # 使用默认参数")
        lines.append(f"  python -m agentquant.cli factor calc {self.meta.code} --date 2024-06-01 --codes 000001.SZ")
        lines.append("")
        
        if self.meta.parameters:
            lines.append("  # 使用自定义参数（Windows PowerShell 用双引号包裹）")
            param_examples = []
            for param_name, param_config in self.meta.parameters.items():
                default = param_config.get('default')
                if isinstance(default, str):
                    param_examples.append(f'{param_name}:{default}')
                else:
                    param_examples.append(f'{param_name}:{default}')
            lines.append(f"  python -m agentquant.cli factor calc {self.meta.code} --date 2024-06-01 --codes 000001.SZ --params \"{','.join(param_examples)}\"")
        
        return '\n'.join(lines)


# 内置因子示例

class MA5_Factor(JQFactor):
    """5日均线因子"""
    meta = FactorMeta(
        code='MA5',
        name='5日均线',
        category='技术指标',
        description='收盘价的5日移动平均',
        formula='MA5 = mean(close, 5)',
        dependencies=['close'],
        max_window=5
    )
    
    def calc(self, data: Dict[str, pd.DataFrame]) -> pd.Series:
        close = data['close']
        return close.iloc[-5:].mean()


class MA20_Factor(JQFactor):
    """20日均线因子"""
    meta = FactorMeta(
        code='MA20',
        name='20日均线',
        category='技术指标',
        description='收盘价的20日移动平均',
        formula='MA20 = mean(close, 20)',
        dependencies=['close'],
        max_window=20
    )
    
    def calc(self, data: Dict[str, pd.DataFrame]) -> pd.Series:
        close = data['close']
        return close.iloc[-20:].mean()


class RSI_Factor(JQFactor):
    """RSI相对强弱指标"""
    meta = FactorMeta(
        code='RSI',
        name='RSI指标',
        category='技术指标',
        description='相对强弱指标，衡量价格变动的速度和幅度',
        formula='RSI = 100 - 100/(1 + RS)',
        dependencies=['close'],
        max_window=20,
        parameters={
            'window': {
                'type': 'int',
                'default': 14,
                'description': '计算窗口期'
            }
        }
    )
    
    def calc(self, data: Dict[str, pd.DataFrame]) -> pd.Series:
        close = data['close']
        window = self.params.get('window', 14)
        
        delta = close.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi.iloc[-1]


class MACD_Factor(JQFactor):
    """MACD指标因子"""
    meta = FactorMeta(
        code='MACD',
        name='MACD指标',
        category='技术指标',
        description='指数平滑异同移动平均线',
        formula='MACD = EMA12 - EMA26',
        dependencies=['close'],
        max_window=30
    )
    
    def calc(self, data: Dict[str, pd.DataFrame]) -> pd.Series:
        close = data['close']
        exp1 = close.ewm(span=12, adjust=False).mean()
        exp2 = close.ewm(span=26, adjust=False).mean()
        macd = exp1 - exp2
        return macd.iloc[-1]


# 因子注册表
BUILTIN_FACTORS = {
    'MA5': MA5_Factor,
    'MA20': MA20_Factor,
    'RSI': RSI_Factor,
    'MACD': MACD_Factor,
}


def get_factor(factor_code: str, **params) -> Optional[JQFactor]:
    """
    获取因子实例
    
    Args:
        factor_code: 因子代码
        **params: 因子参数
    
    Returns:
        因子实例或None
    """
    factor_class = BUILTIN_FACTORS.get(factor_code)
    if factor_class:
        return factor_class(**params)
    return None


def list_factors() -> List[Dict[str, Any]]:
    """列出所有可用因子"""
    return [
        {
            'code': code,
            'name': factor_class.meta.name,
            'category': factor_class.meta.category,
            'description': factor_class.meta.description
        }
        for code, factor_class in BUILTIN_FACTORS.items()
    ]
