# -*- coding: utf-8 -*-
"""
动态因子管理模块

支持将因子代码存储在数据库中，运行时动态加载和执行
"""

import json
import logging
import hashlib
from typing import Dict, List, Optional, Any, Type
from datetime import datetime
from dataclasses import dataclass, asdict

from .jqfactor_base import JQFactor, FactorMeta
from .base import FactorRegistry

logger = logging.getLogger(__name__)


@dataclass
class DynamicFactorRecord:
    """动态因子记录"""
    id: str                          # 唯一ID (hash of code)
    code: str                        # 因子代码
    name: str                        # 因子名称
    category: str                    # 分类
    description: str                 # 描述
    source_code: str                 # 因子源代码
    meta_json: str                   # 元数据JSON
    created_at: str                  # 创建时间
    updated_at: str                  # 更新时间
    version: int                     # 版本号
    is_active: bool                  # 是否有效


class DynamicFactorManager:
    """
    动态因子管理器
    
    负责：
    1. 将因子代码存储到数据库
    2. 从数据库加载因子
    3. 动态编译执行因子代码
    """
    
    TABLE_NAME = 'dynamic_factors'
    
    def __init__(self, db_client=None):
        """
        初始化
        
        Args:
            db_client: 数据库客户端，如果为None则创建新连接
        """
        if db_client is None:
            from agentquant.database.storage.db_client import DBClient
            db_client = DBClient()
        self.db = db_client
        self._ensure_table()
        
    def _ensure_table(self):
        """确保表存在"""
        sql = f"""
        CREATE TABLE IF NOT EXISTS {self.TABLE_NAME} (
            id VARCHAR PRIMARY KEY,
            code VARCHAR UNIQUE NOT NULL,
            name VARCHAR NOT NULL,
            category VARCHAR NOT NULL,
            description VARCHAR,
            source_code TEXT NOT NULL,
            meta_json TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            version INTEGER DEFAULT 1,
            is_active BOOLEAN DEFAULT TRUE
        )
        """
        try:
            self.db.execute_query(sql)
            logger.info(f"确保表 {self.TABLE_NAME} 存在")
        except Exception as e:
            logger.error(f"创建表失败: {e}")
            raise
    
    def _generate_id(self, code: str) -> str:
        """生成唯一ID"""
        return hashlib.md5(code.encode()).hexdigest()[:16]
    
    def save_factor(self, code: str, name: str, category: str, 
                   description: str, source_code: str, 
                   meta: Dict[str, Any]) -> bool:
        """
        保存因子到数据库
        
        Args:
            code: 因子代码
            name: 因子名称
            category: 分类
            description: 描述
            source_code: Python源代码
            meta: 元数据字典
            
        Returns:
            是否成功
        """
        try:
            factor_id = self._generate_id(code)
            meta_json = json.dumps(meta, ensure_ascii=False)
            
            # 检查是否已存在
            existing = self.get_factor(code)
            
            if existing:
                # 更新 - 使用参数化查询
                sql = f"""
                UPDATE {self.TABLE_NAME}
                SET name = '{name.replace("'", "''")}', 
                    category = '{category.replace("'", "''")}', 
                    description = '{description.replace("'", "''")}',
                    source_code = '{source_code.replace("'", "''")}', 
                    meta_json = '{meta_json.replace("'", "''")}', 
                    updated_at = CURRENT_TIMESTAMP,
                    version = version + 1
                WHERE code = '{code}'
                """
                self.db.execute_query(sql)
                logger.info(f"更新因子: {code}")
            else:
                # 插入
                sql = f"""
                INSERT INTO {self.TABLE_NAME} 
                (id, code, name, category, description, source_code, meta_json)
                VALUES (
                    '{factor_id}', 
                    '{code}', 
                    '{name.replace("'", "''")}', 
                    '{category.replace("'", "''")}', 
                    '{description.replace("'", "''")}', 
                    '{source_code.replace("'", "''")}', 
                    '{meta_json.replace("'", "''")}'
                )
                """
                self.db.execute_query(sql)
                logger.info(f"创建因子: {code}")
            
            return True
        except Exception as e:
            logger.error(f"保存因子失败: {e}")
            return False
    
    def get_factor(self, code: str) -> Optional[DynamicFactorRecord]:
        """获取因子"""
        try:
            sql = f"""
            SELECT * FROM {self.TABLE_NAME} 
            WHERE code = '{code}' AND is_active = TRUE
            """
            df = self.db.execute_query(sql)
            
            if not df.empty:
                row = df.iloc[0]
                return DynamicFactorRecord(
                    id=row['id'],
                    code=row['code'],
                    name=row['name'],
                    category=row['category'],
                    description=row['description'],
                    source_code=row['source_code'],
                    meta_json=row['meta_json'],
                    created_at=str(row['created_at']),
                    updated_at=str(row['updated_at']),
                    version=int(row['version']),
                    is_active=bool(row['is_active'])
                )
            return None
        except Exception as e:
            logger.error(f"获取因子失败: {e}")
            return None
    
    def list_factors(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        """列出所有因子"""
        try:
            if category:
                sql = f"""
                SELECT code, name, category, description, updated_at, version
                FROM {self.TABLE_NAME}
                WHERE category = '{category}' AND is_active = TRUE
                ORDER BY updated_at DESC
                """
            else:
                sql = f"""
                SELECT code, name, category, description, updated_at, version
                FROM {self.TABLE_NAME}
                WHERE is_active = TRUE
                ORDER BY updated_at DESC
                """
            df = self.db.execute_query(sql)
            
            if not df.empty:
                return df.to_dict('records')
            return []
        except Exception as e:
            logger.error(f"列出因子失败: {e}")
            return []
    
    def delete_factor(self, code: str) -> bool:
        """删除因子（软删除）"""
        try:
            sql = f"""
            UPDATE {self.TABLE_NAME}
            SET is_active = FALSE, updated_at = CURRENT_TIMESTAMP
            WHERE code = '{code}'
            """
            self.db.execute_query(sql)
            logger.info(f"删除因子: {code}")
            return True
        except Exception as e:
            logger.error(f"删除因子失败: {e}")
            return False
    
    def compile_factor(self, record: DynamicFactorRecord) -> Optional[Type[JQFactor]]:
        """
        编译因子代码为可执行类
        
        Args:
            record: 因子记录
            
        Returns:
            因子类，如果编译失败返回None
        """
        try:
            # 创建命名空间
            namespace = {
                'JQFactor': JQFactor,
                'FactorMeta': FactorMeta,
                'pd': __import__('pandas'),
                'np': __import__('numpy'),
                'logging': __import__('logging'),
            }
            
            # 执行源代码
            exec(record.source_code, namespace)
            
            # 查找因子类（继承自JQFactor的类）
            factor_class = None
            for name, obj in namespace.items():
                if (isinstance(obj, type) and 
                    issubclass(obj, JQFactor) and 
                    obj is not JQFactor and
                    hasattr(obj, 'meta')):
                    factor_class = obj
                    break
            
            if factor_class is None:
                logger.error(f"未找到有效的因子类: {record.code}")
                return None
            
            # 验证元数据
            if factor_class.meta is None:
                logger.error(f"因子类缺少meta属性: {record.code}")
                return None
            
            logger.info(f"编译因子成功: {factor_class.meta.code if factor_class.meta else record.code}")
            return factor_class
            
        except Exception as e:
            logger.error(f"编译因子失败 {record.code}: {e}")
            return None
    
    def load_and_register_all(self):
        """加载并注册所有动态因子"""
        factors = self.list_factors()
        count = 0
        
        for factor_info in factors:
            record = self.get_factor(factor_info['code'])
            if record:
                factor_class = self.compile_factor(record)
                if factor_class:
                    # 注册到FactorRegistry
                    FactorRegistry.register(factor_class)
                    count += 1
        
        logger.info(f"加载并注册了 {count} 个动态因子")
        return count


# 全局管理器实例
_dynamic_factor_manager = None

def get_dynamic_factor_manager(db_client=None) -> DynamicFactorManager:
    """获取全局动态因子管理器"""
    global _dynamic_factor_manager
    if _dynamic_factor_manager is None:
        _dynamic_factor_manager = DynamicFactorManager(db_client)
    return _dynamic_factor_manager
