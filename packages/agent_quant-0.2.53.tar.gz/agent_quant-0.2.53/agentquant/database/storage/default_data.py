# -*- coding: utf-8 -*-
"""
默认因子和策略数据
在数据库初始化时自动插入
"""

# 默认因子定义
DEFAULT_FACTORS = [
    {
        "code": "MA5",
        "name": "5日均线",
        "category": "技术指标",
        "description": "收盘价的5日移动平均",
        "formula": "MA5 = mean(close, 5)",
        "parameters": {"window": 5},
        "frequency": "daily"
    },
    {
        "code": "MA20",
        "name": "20日均线",
        "category": "技术指标",
        "description": "收盘价的20日移动平均",
        "formula": "MA20 = mean(close, 20)",
        "parameters": {"window": 20},
        "frequency": "daily"
    },
    {
        "code": "RSI",
        "name": "RSI指标",
        "category": "技术指标",
        "description": "相对强弱指标，衡量价格变动的速度和幅度",
        "formula": "RSI = 100 - 100/(1 + RS)",
        "parameters": {"window": 14, "overbought": 70, "oversold": 30},
        "frequency": "daily"
    },
    {
        "code": "MACD",
        "name": "MACD指标",
        "category": "技术指标",
        "description": "指数平滑异同平均线，用于判断趋势和买卖时机",
        "formula": "MACD = EMA(12) - EMA(26), Signal = EMA(MACD, 9)",
        "parameters": {"fast": 12, "slow": 26, "signal": 9},
        "frequency": "daily"
    },
    {
        "code": "BOLL_UPPER",
        "name": "布林带上轨",
        "category": "技术指标",
        "description": "布林带的上轨线，基于移动平均和标准差计算",
        "formula": "Upper = MA(20) + 2 * STD(20)",
        "parameters": {"window": 20, "std_dev": 2},
        "frequency": "daily"
    },
    {
        "code": "BOLL_LOWER",
        "name": "布林带下轨",
        "category": "技术指标",
        "description": "布林带的下轨线，基于移动平均和标准差计算",
        "formula": "Lower = MA(20) - 2 * STD(20)",
        "parameters": {"window": 20, "std_dev": 2},
        "frequency": "daily"
    },
    {
        "code": "MOMENTUM",
        "name": "动量因子",
        "category": "动量",
        "description": "价格动量，反映价格变化的速度",
        "formula": "Momentum = (close - close[n]) / close[n]",
        "parameters": {"window": 10},
        "frequency": "daily"
    },
    {
        "code": "VOL_MA5",
        "name": "5日均量",
        "category": "成交量",
        "description": "成交量的5日移动平均",
        "formula": "VOL_MA5 = mean(volume, 5)",
        "parameters": {"window": 5},
        "frequency": "daily"
    },
    {
        "code": "PE_RATIO",
        "name": "市盈率",
        "category": "估值",
        "description": "股价与每股收益的比率",
        "formula": "PE = Price / EPS",
        "parameters": {},
        "frequency": "daily"
    },
    {
        "code": "PB_RATIO",
        "name": "市净率",
        "category": "估值",
        "description": "股价与每股净资产的比率",
        "formula": "PB = Price / Book Value",
        "parameters": {},
        "frequency": "daily"
    },
]

# 默认策略定义
DEFAULT_STRATEGIES = [
    {
        "code": "DUAL_MA",
        "name": "双均线策略",
        "strategy_type": "择时",
        "description": "基于快线和慢线交叉产生买卖信号的经典趋势跟踪策略",
        "factor_codes": ["MA5", "MA20"],
        "entry_conditions": {"condition": "MA5 > MA20", "description": "金叉买入"},
        "exit_conditions": {"condition": "MA5 < MA20", "description": "死叉卖出"},
        "position_sizing": {"type": "fixed", "amount": 1000},
        "status": "active"
    },
    {
        "code": "RSI_STRATEGY",
        "name": "RSI策略",
        "strategy_type": "择时",
        "description": "基于RSI超买超卖产生交易信号",
        "factor_codes": ["RSI"],
        "entry_conditions": {"condition": "RSI < 30", "description": "超卖买入"},
        "exit_conditions": {"condition": "RSI > 70", "description": "超买卖出"},
        "position_sizing": {"type": "fixed", "amount": 1000},
        "status": "active"
    },
    {
        "code": "MACD_STRATEGY",
        "name": "MACD策略",
        "strategy_type": "择时",
        "description": "基于MACD指标金叉死叉产生交易信号",
        "factor_codes": ["MACD"],
        "entry_conditions": {"condition": "MACD > Signal", "description": "MACD金叉买入"},
        "exit_conditions": {"condition": "MACD < Signal", "description": "MACD死叉卖出"},
        "position_sizing": {"type": "fixed", "amount": 1000},
        "status": "active"
    },
    {
        "code": "BOLLINGER_BANDS",
        "name": "布林带策略",
        "strategy_type": "择时",
        "description": "基于布林带上下轨突破产生交易信号",
        "factor_codes": ["BOLL_UPPER", "BOLL_LOWER"],
        "entry_conditions": {"condition": "close < BOLL_LOWER", "description": "跌破下轨买入"},
        "exit_conditions": {"condition": "close > BOLL_UPPER", "description": "突破上轨卖出"},
        "position_sizing": {"type": "fixed", "amount": 1000},
        "status": "active"
    },
    {
        "code": "MOMENTUM",
        "name": "动量策略",
        "strategy_type": "选股",
        "description": "基于价格动量产生交易信号，买入涨幅最大的股票",
        "factor_codes": ["MOMENTUM"],
        "entry_conditions": {"condition": "MOMENTUM > 0.02", "description": "动量大于2%买入"},
        "exit_conditions": {"condition": "MOMENTUM < -0.02", "description": "动量小于-2%卖出"},
        "position_sizing": {"type": "fixed", "amount": 1000},
        "status": "active"
    },
]
