Uni-Quant
========

Small library to quantize/dequantize Keras and XGBoost models using PyTorch CUDA kernels.

Notes
- This package compiles CUDA kernels at runtime using `torch.utils.cpp_extension.load_inline`.
- Installing and using the CUDA compilation requires a compatible PyTorch build and CUDA toolkit on the target machine.

Dependencies are listed in `requirements.txt` and synchronized with `pyproject.toml`.

Quick publish test

Build a source/wheel and check locally:

```
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
```

Upload (example):

```
python -m twine upload dist/*
```
