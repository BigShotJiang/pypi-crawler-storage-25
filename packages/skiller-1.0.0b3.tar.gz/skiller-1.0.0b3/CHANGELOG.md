# Changelog

All notable changes to this project should be summarized here before a version is cut from a `feature/*` branch into `main`.

## Unreleased

### Added
- Nothing yet.

### Changed
- Nothing yet.

### Fixed
- Nothing yet.

### Removed
- Nothing yet.

### Notes
- Update this section when a branch is ready for release.

## 1.0.0-beta.3 - 2026-05-17

### Added
- Added typed agent runtime configuration through `AgentConfigPort` and `agent.json`.
- Added agent context usage persistence, context stats, and `skiller agent stats`.
- Added live agent E2E coverage for final-answer and tool-call loop scenarios.

### Changed
- Changed Minimax to use the OpenAI-compatible client path via `openai_chat_completions`.
- Changed agent step execution to use typed `AgentStep` and `AgentRunnerConfig` contracts.
- Changed agent config resolution to select `AGENT_AGENT_CONFIG_FILE`, then `./agent.json`,
  then `~/.skiller/settings/agent.json`.

### Fixed
- Nothing yet.

### Removed
- Removed the legacy `llm_prompt` step and tests.
- Removed the legacy Minimax LLM client and legacy LLM config loader.
- Removed unused sanitizer classes and empty package `__init__.py` files.

### Notes
- This release consolidates the agent runtime config and context-statistics refactor from PR #29.

## 1.0.0-beta.2 - 2026-05-16

### Added
- Add history feature for agent conversation (PR #26)
- Add agent context and run event observer refactor (PR #25)
- Add WhatsApp channel runtime and bridge support (PR #23)
- Add chat mode and ESC to interrupt agent tools
- Add agent runtime and TUI integration

### Changed
- Clean tool executor and event publishers (PR #27)
- Restructure project into monorepo (PR #23)
- Improve event type tracking in polling observer


### Removed
- Nothing yet.

### Notes
- Release version bump.

## 1.0.0-beta.1 - 2026-04-26

### Added
- Added `agent` as a first-class runtime step with iterative turns, tool calls, and persisted agent context entries.
- Added the first application tools (`shell`, `notify`) under a shared domain tool contract and manager orchestration.
- Added a richer TUI stack (`interfaces/tui`) with dedicated adapter, viewmodel, and screen layers.
- Added `skiller delete <run_id>` to remove run state and associated persisted runtime artifacts.
- Added manual publish workflow dispatch support for repository release operations.

### Changed
- Reorganized runtime modules by bounded package structure (`run`, `render`, `execute`, `ingress`, `query`, `skill`, `webhook`) to keep use-case boundaries explicit.
- Changed agent execution flow to support plain-text final answers with tool-call JSON only when needed, improving provider compatibility.
- Changed MCP HTTP configuration to support inline values plus `env`/`file` resolution for URL and headers.
- Changed docs and examples to align with the new agent/tool architecture and MCP configuration model.

### Fixed
- Fixed repeated agent step failures caused by strict JSON terminal-response requirements when providers returned plain text.
- Fixed MCP configuration resolution errors with explicit support for file-based token loading in HTTP headers.
- Fixed repository lint conformance on current branch scope (`ruff` import ordering and line-length constraints).

### Removed
- Removed reliance on `.env` loading from runtime configuration flow; environment variables remain explicit process overrides.

### Notes
- This beta consolidates the new agent/tool architecture and TUI/runtime refactor into the first pre-release targeted for `1.0.0` stabilization.

## 1.0.0-alpha.8 - 2026-04-10

### Added
- Added WhatsApp channel tooling with pairing, bridge lifecycle management, and dedicated operator documentation.
- Added `wait_channel` and `channel receive` as first-class runtime primitives backed by normalized wait and external-event stores.
- Added the `send` step with WhatsApp bridge delivery, demo skills, and outbound bridge availability checks before run creation.
- Added `SkillServerCheckerUseCase` and server/channel availability guards so runs fail before creation when required local runtime pieces are missing.

### Changed
- Changed channel matching to the generic `key` / `channel_key` contract across runtime, persistence, and docs.
- Changed the WhatsApp bridge to deliver inbound messages through the shared local server and to apply a more human-like delay before outbound sends.
- Changed the TUI status polling path to tolerate missing persisted `body_ref` payloads instead of crashing the event loop.

### Fixed
- Fixed UI polling when an `execution_output` body could no longer be resolved from a stored `body_ref`.
- Fixed channel-related runtime and persistence contracts so waits, external events, and examples stay aligned around normalized matching fields.

### Removed
- Removed the last public `conversation` naming from the generic channel contract in favor of `key`.

### Notes
- This release establishes WhatsApp as the first end-to-end channel with inbound waits, outbound send, bridge lifecycle tooling, and pre-run runtime checks.

## 1.0.0-alpha.7 - 2026-04-03

### Added
- Added skill validation with dedicated error codes, built-in skill coverage, and operator-facing docs for the skill checker.
- Added a dedicated run query read side and `/runs` support for compact waiting views in the CLI and TUI.
- Added local `cloudflared` tooling with `login`, `ensure`, `start`, `status`, and `stop`, plus dedicated operator docs.
- Added local server lifecycle tooling with explicit Skiller ownership tracking and dedicated operator docs.

### Changed
- Changed the TUI `/run` flow to follow runs incrementally instead of staying on the initial snapshot.
- Changed the `cloudflared ensure` flow to generate a tunnel config and publish the public hostname through tunnel ingress.
- Changed CLI operator output to use explicit ownership reporting via `managed_by_skiller`.
- Changed docs and backlog structure to reflect the current CLI/tooling surfaces and progress status.

### Fixed
- Fixed stale or reused PID handling for local server management so Skiller does not stop unrelated processes.
- Fixed public tunnel publication so `skillerwh.<domain>` resolves through the generated tunnel config instead of DNS routing alone.
- Fixed pytest collection conflicts between tool test modules that shared the same basename.

### Removed
- Removed the legacy `cloudflared` skill path in favor of CLI/tooling flow.

### Notes
- This release closes the current operator tooling pass around run inspection, local server lifecycle, and Cloudflare tunnel management.

## 1.0.0-alpha.6 - 2026-03-30

### Added
- Added the new `shell` step with support for `command`, `cwd`, `env`, `timeout`, `check`, and `large_result`.
- Added the default shell runner and runtime wiring needed to execute shell commands and scripts from skills.
- Added the `repo_checks` internal skill as a practical example that runs `ruff`, `pytest`, and `build` through the new `shell` step.
- Added unit, integration, and shell-based E2E coverage for the new `shell` feature.

### Changed
- Changed the TUI `/run` flow so synchronous successful runs render their completed step transcript instead of only the final success line.
- Changed the docs, README, and skill schema references to include the new `shell` step and the updated examples.

### Fixed
- Fixed the TUI output for completed runs so users can see the executed steps immediately after `/run`.

### Removed
- Nothing notable.

### Notes
- This release extends the runtime with shell execution while keeping large-output handling, transcript rendering, and CLI examples aligned.

## 1.0.0-alpha.5 - 2026-03-17

### Added
- Added a dedicated `Feature PR` GitHub Actions workflow for `feature/*` pull requests.
- Added repository scripts to validate PR branch shape and release metadata in CI.
- Added a reusable internal `pull_request` skill for opening both feature and release pull requests.

### Changed
- Changed release validation to run on `release/*` pull requests instead of a manual workflow on `main`.
- Changed release tagging so CI creates `v<version>` only after the release PR is merged.
- Changed `skiller-dev` to use a single workflow reference with explicit `[Agent]`, `[User]`, `[Admin]`, and `[Workflow]` responsibilities.

### Fixed
- Fixed the release instructions so the documented flow matches the active CI and pull request process.

### Removed
- Removed obsolete split release references from `skiller-dev` in favor of the consolidated workflow guide.

### Notes
- This release focuses on CI and release-process coherence after `v1.0.0-alpha.4`.

## 1.0.0-alpha.4 - 2026-03-16

### Added
- Added a worker-based CLI lifecycle with `worker start`, `worker run`, and `worker resume`.
- Added live CLI watch output so `skiller run` reports progress while the worker executes.
- Added GitHub MCP HTTP auth support with rendered `headers` and `{{env.*}}` templates.
- Added a manual GitHub Actions `Release` workflow for post-merge validation and tag creation.

### Changed
- Changed `skiller run` to create the run, launch the worker flow, and report progress instead of executing the full loop inline.
- Changed the runtime to use `RunWorkerService` as the canonical owner of step execution.
- Changed active docs and skill examples to English and trimmed legacy documentation from the repo.

### Fixed
- Fixed the webhook CLI flow to wait for the resumed worker instead of reading a transient `RUNNING` state.

### Removed
- Removed explicit external `run_id` injection from `skiller run`.
- Removed `RuntimeBootstrapService` as a separate layer and folded bootstrap into `RuntimeApplicationService`.

### Notes
- Established the worker-based execution path and live CLI watch output as the base runtime flow.

## 1.0.0-alpha.3 - 2026-03-13

### Added
- Added explicit `--run-id` support to `skiller run` so external callers can choose the run identifier before execution starts.
- Added a manual CLI E2E flow `tests/e2e/cli_run_id.sh` and included it in `tests/e2e/cli_all.sh`.

### Changed
- Moved run-id generation and validation into `StartRunUseCase` so the runtime always persists a final UUID decided before hitting the store.
- Simplified the state store contract so run creation always receives an effective `run_id` instead of generating one internally.
- Refreshed README manual E2E listings to include the explicit run-id flow.

### Fixed
- Made `skiller run --run-id ...` fail with a clear CLI error when the UUID is invalid or already exists.

### Removed
- Nothing notable.

### Notes
- `--run-id` now accepts only UUID values; when omitted, the runtime generates a new UUID automatically.

## 1.0.0-alpha.2 - 2026-03-12

### Added
- Added `switch` as a runtime step for exact-value routing by `step_id`.
- Added `when` as a runtime step for ordered conditional branching over a single value.
- Added manual CLI flows for `switch` and `when`, both included in `tests/e2e/cli_all.sh`.
- Added demo skills to showcase branching and webhook resume.

### Changed
- Closed the control-flow spike around `if` by formalizing `switch` and `when` as the branching primitives for `1.0.x`.
- Refreshed backlog, runtime flow docs, feature matrix, and testing rules to match the current branching model and manual CLI policy.
- Clarified in `skiller-dev` guidance that new runtime steps should ship with at least one manual CLI flow and an entry in `cli_all.sh`.
- Refreshed README examples to separate demo skills from technical test fixtures.

### Fixed
- Rebuilt persisted runtime context correctly from `SWITCH_DECISION` and `WHEN_DECISION` events.
- Kept manual CLI aggregation aligned with the actual runtime surface so new branching steps are exercised from the real entry point.

### Removed
- Nothing notable.

### Notes
- `switch` persists minimal routing output as `{"value": ..., "next": ...}` and emits `SWITCH_DECISION`.
- `when` persists minimal routing output as `{"value": ..., "next": ...}` and emits `WHEN_DECISION` with branch/operator metadata for traceability.
- Webhook examples require registering the matching webhook channel before sending signed HTTP requests to the webhooks server.

## 1.0.0-alpha.1 - 2026-03-11

### Added
- Added runtime support for `assign` steps.
- Added manual shell-based E2E CLI flows for `notify`, `assign`, `mcp`, and `wait_webhook`.
- Added a focused store test to validate removal of the legacy `current_step` column.

### Changed
- Migrated runtime step progression to the `current` step-id pointer with explicit `start/next` flow.
- Unified step execution results across enabled runtime step types.
- Simplified manual MCP stdio validation to use an internal fixture instead of client-provided root overrides.
- Clarified sandbox test execution in the `skiller-dev` skill instructions.

### Fixed
- Restored reliable MCP `stdio` verification for local CLI flows.
- Tightened manual CLI behavior when provider credentials are missing.

### Removed
- Removed the legacy `current_step` field from runtime state and SQLite persistence.
- Removed old Python CLI E2E tests replaced by manual shell flows.
- Removed fake client-side MCP root overrides from examples and operator docs.

### Notes
- For `local_mcp.py`, filesystem roots are controlled by the MCP server configuration, not by `skiller` client env injection.
