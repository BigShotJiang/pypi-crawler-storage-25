import os
from dataclasses import dataclass
from pathlib import Path

from skiller.application.agent.agent_runner import AgentRunner
from skiller.application.agent.config.agent_step_mapper import AgentStepMapper
from skiller.application.agent.config.output_truncator import OutputTruncator
from skiller.application.agent.config.step_config_reader import AgentStepConfigReader
from skiller.application.agent.context.agent_context_manager import AgentContextManager
from skiller.application.agent.context.agent_context_publisher import (
    AgentContextPublisher,
)
from skiller.application.agent.event.agent_event_publisher import AgentEventPublisher
from skiller.application.agent.event.agent_event_truncator import (
    AgentEventOutputPolicy,
    AgentEventTruncator,
)
from skiller.application.agent.mapper.error_mapper import AgentErrorMapper
from skiller.application.agent.mapper.feedback import AgentRunnerFeedback
from skiller.application.agent.prompt.prompt_builder import AgentPromptBuilder
from skiller.application.agent.tools.agent_tool_executor import AgentToolExecutor
from skiller.application.agent.tools.tool_manager import ToolManager
from skiller.application.query_service import RunQueryService
from skiller.application.run_worker_service import RunWorkerService
from skiller.application.runtime_application_service import RuntimeApplicationService
from skiller.application.tools.notify import NotifyTool
from skiller.application.tools.shell import ShellProcessTool
from skiller.application.use_cases.agent.get_agent_stats import GetAgentStatsUseCase
from skiller.application.use_cases.agent.interrupt_agent import InterruptAgentUseCase
from skiller.application.use_cases.execute.execute_agent_step import (
    ExecuteAgentStepUseCase,
)
from skiller.application.use_cases.execute.execute_assign_step import ExecuteAssignStepUseCase
from skiller.application.use_cases.execute.execute_mcp_step import ExecuteMcpStepUseCase
from skiller.application.use_cases.execute.execute_notify_step import (
    ExecuteNotifyStepUseCase,
)
from skiller.application.use_cases.execute.execute_send_step import ExecuteSendStepUseCase
from skiller.application.use_cases.execute.execute_shell_step import ExecuteShellStepUseCase
from skiller.application.use_cases.execute.execute_switch_step import ExecuteSwitchStepUseCase
from skiller.application.use_cases.execute.execute_wait_channel_step import (
    ExecuteWaitChannelStepUseCase,
)
from skiller.application.use_cases.execute.execute_wait_input_step import (
    ExecuteWaitInputStepUseCase,
)
from skiller.application.use_cases.execute.execute_wait_webhook_step import (
    ExecuteWaitWebhookStepUseCase,
)
from skiller.application.use_cases.execute.execute_when_step import ExecuteWhenStepUseCase
from skiller.application.use_cases.ingress.handle_channel import HandleChannelUseCase
from skiller.application.use_cases.ingress.handle_input import HandleInputUseCase
from skiller.application.use_cases.ingress.handle_webhook import HandleWebhookUseCase
from skiller.application.use_cases.query.get_run_logs import GetRunLogsUseCase
from skiller.application.use_cases.query.get_run_status import GetRunStatusUseCase
from skiller.application.use_cases.query.get_runs import GetRunsUseCase
from skiller.application.use_cases.query.get_waiting_metadata import (
    GetWaitingMetadataUseCase,
)
from skiller.application.use_cases.query.list_webhooks import ListWebhooksUseCase
from skiller.application.use_cases.render.render_current_step import (
    RenderCurrentStepUseCase,
)
from skiller.application.use_cases.render.render_mcp_config import RenderMcpConfigUseCase
from skiller.application.use_cases.run.append_runtime_event import AppendRuntimeEventUseCase
from skiller.application.use_cases.run.bootstrap_runtime import BootstrapRuntimeUseCase
from skiller.application.use_cases.run.complete_run import CompleteRunUseCase
from skiller.application.use_cases.run.create_run import CreateRunUseCase
from skiller.application.use_cases.run.delete_run import DeleteRunUseCase
from skiller.application.use_cases.run.fail_run import FailRunUseCase
from skiller.application.use_cases.run.get_start_step import GetStartStepUseCase
from skiller.application.use_cases.run.resume_run import ResumeRunUseCase
from skiller.application.use_cases.skill.skill_checker import SkillCheckerUseCase
from skiller.application.use_cases.skill.skill_server_checker import (
    SkillServerCheckerUseCase,
)
from skiller.application.use_cases.webhook.register_webhook import RegisterWebhookUseCase
from skiller.application.use_cases.webhook.remove_webhook import RemoveWebhookUseCase
from skiller.domain.agent.agent_config_model import AgentLLMClientType
from skiller.domain.agent.agent_config_port import AgentConfigPort
from skiller.infrastructure.config.json_agent_config_provider import JsonAgentConfigProvider
from skiller.infrastructure.config.settings import Settings, get_settings
from skiller.infrastructure.db.sqlite_agent_context_store import SqliteAgentContextStore
from skiller.infrastructure.db.sqlite_agent_steering_store import SqliteAgentSteeringStore
from skiller.infrastructure.db.sqlite_external_event_store import SqliteExternalEventStore
from skiller.infrastructure.db.sqlite_run_query_store import SqliteRunQueryStore
from skiller.infrastructure.db.sqlite_runtime_event_store import SqliteRuntimeEventStore
from skiller.infrastructure.db.sqlite_state_store import SqliteStateStore
from skiller.infrastructure.db.sqlite_wait_store import SqliteWaitStore
from skiller.infrastructure.db.sqlite_webhook_registry import SqliteWebhookRegistry
from skiller.infrastructure.llm.fake_llm import FakeLLM
from skiller.infrastructure.llm.null_llm import NullLLM
from skiller.infrastructure.llm.openai_llm import OpenAILLM
from skiller.infrastructure.skills.filesystem_skill_runner import FilesystemSkillRunner
from skiller.infrastructure.tools.channels.default_channel_sender import DefaultChannelSender
from skiller.infrastructure.tools.mcp.default_mcp import DefaultMCP
from skiller.infrastructure.tools.process.default_tool_process import DefaultToolProcessRunner
from skiller.infrastructure.tools.webhooks.default_server_status import DefaultServerStatus


@dataclass(frozen=True)
class RuntimeContainer:
    settings: Settings
    runtime_service: RuntimeApplicationService
    query_service: RunQueryService


def build_runtime_container(
    settings: Settings | None = None,
    *,
    skills_dir: str | None = None,
) -> RuntimeContainer:
    cfg = settings or get_settings()
    store = SqliteStateStore(cfg.db_path)
    wait_store = SqliteWaitStore(cfg.db_path)
    external_event_store = SqliteExternalEventStore(cfg.db_path)
    runtime_event_store = SqliteRuntimeEventStore(cfg.db_path)
    agent_context_store = SqliteAgentContextStore(cfg.db_path)
    agent_steering_store = SqliteAgentSteeringStore(cfg.db_path)
    run_query = SqliteRunQueryStore(cfg.db_path)
    webhook_registry = SqliteWebhookRegistry(cfg.db_path)
    skill_runner = FilesystemSkillRunner(
        skills_dir=skills_dir,
    )
    agent_config = JsonAgentConfigProvider(
        config_path=Path(cfg.agent_config_path),
        env=os.environ,
    )
    llm = _build_llm(agent_config)
    mcp = DefaultMCP()
    shell_tool = _build_shell_tool(cfg)
    tool_process_runner = DefaultToolProcessRunner()
    server_status = DefaultServerStatus(cfg)
    channel_sender = DefaultChannelSender(cfg)
    tool_manager = _build_agent_tool_manager(cfg)

    bootstrap_runtime_use_case = BootstrapRuntimeUseCase(
        store=store,
        webhook_registry=webhook_registry,
    )

    create_run_use_case = CreateRunUseCase(store, skill_runner)
    delete_run_use_case = DeleteRunUseCase(store)
    append_runtime_event_use_case = AppendRuntimeEventUseCase(runtime_event_store)
    complete_run_use_case = CompleteRunUseCase(store)
    fail_run_use_case = FailRunUseCase(store)
    get_start_step_use_case = GetStartStepUseCase(store=store)
    handle_input_use_case = HandleInputUseCase(
        run_store=store,
        external_event_store=external_event_store,
        runtime_event_store=runtime_event_store,
    )
    handle_channel_use_case = HandleChannelUseCase(
        external_event_store=external_event_store,
        wait_store=wait_store,
    )
    handle_webhook_use_case = HandleWebhookUseCase(
        external_event_store=external_event_store,
        wait_store=wait_store,
    )
    list_webhooks_use_case = ListWebhooksUseCase(registry=webhook_registry)
    register_webhook_use_case = RegisterWebhookUseCase(registry=webhook_registry)
    remove_webhook_use_case = RemoveWebhookUseCase(registry=webhook_registry)
    interrupt_agent_use_case = InterruptAgentUseCase(
        store=store,
        steering=agent_steering_store,
    )
    skill_checker_use_case = SkillCheckerUseCase(skill_runner=skill_runner)
    skill_server_checker_use_case = SkillServerCheckerUseCase(
        skill_runner=skill_runner,
        server_status=server_status,
        channel_sender=channel_sender,
    )

    render_current_step_use_case = RenderCurrentStepUseCase(store=store, skill_runner=skill_runner)
    render_mcp_config_use_case = RenderMcpConfigUseCase(store=store, skill_runner=skill_runner)
    agent_event_output_policy = AgentEventOutputPolicy(
        truncate_enabled=cfg.agent_event_output_truncate_enabled,
        max_text_chars=cfg.agent_event_output_max_text_chars,
        max_json_chars=cfg.agent_event_output_max_json_chars,
        max_array_items=cfg.agent_event_output_max_array_items,
    )
    agent_feedback = AgentRunnerFeedback()
    agent_context_publisher = AgentContextPublisher(
        agent_context_store,
        store,
        agent_feedback,
    )
    agent_context_manager = AgentContextManager(
        agent_context_store=agent_context_store,
        prompt_builder=AgentPromptBuilder(),
    )
    get_agent_stats_use_case = GetAgentStatsUseCase(
        store=store,
        context_stats=agent_context_store,
    )
    agent_event_publisher = AgentEventPublisher(
        runtime_event_store,
        AgentEventTruncator(
            agent_event_output_policy,
            OutputTruncator(),
        ),
    )
    execute_agent_step_use_case = ExecuteAgentStepUseCase(
        store=store,
        runner=AgentRunner(
            agent_context_store=agent_context_store,
            llm=llm,
            tool_manager=tool_manager,
            context_manager=agent_context_manager,
            error_mapper=AgentErrorMapper(),
            feedback=agent_feedback,
            context_publisher=agent_context_publisher,
            event_publisher=agent_event_publisher,
            tool_execution=AgentToolExecutor(
                context_publisher=agent_context_publisher,
                event_publisher=agent_event_publisher,
                steering=agent_steering_store,
                tool_manager=tool_manager,
                process_runner=tool_process_runner,
                feedback=agent_feedback,
            ),
        ),
        step_mapper=AgentStepMapper(),
        config_reader=AgentStepConfigReader(
            agent_config=agent_config,
        ),
    )
    execute_assign_step_use_case = ExecuteAssignStepUseCase(store=store)
    execute_mcp_step_use_case = ExecuteMcpStepUseCase(
        store=store,
        mcp=mcp,
    )
    execute_notify_step_use_case = ExecuteNotifyStepUseCase(store=store)
    execute_send_step_use_case = ExecuteSendStepUseCase(
        store=store,
        channel_sender=channel_sender,
    )
    execute_shell_step_use_case = ExecuteShellStepUseCase(
        store=store,
        shell_tool=shell_tool,
        process_runner=tool_process_runner,
        agent_steering_store=agent_steering_store,
    )
    execute_switch_step_use_case = ExecuteSwitchStepUseCase(store=store)
    execute_when_step_use_case = ExecuteWhenStepUseCase(store=store)
    execute_wait_channel_step_use_case = ExecuteWaitChannelStepUseCase(
        run_store=store,
        wait_store=wait_store,
        external_event_store=external_event_store,
    )
    execute_wait_input_step_use_case = ExecuteWaitInputStepUseCase(
        run_store=store,
        wait_store=wait_store,
        external_event_store=external_event_store,
    )
    execute_wait_webhook_step_use_case = ExecuteWaitWebhookStepUseCase(
        run_store=store,
        wait_store=wait_store,
        external_event_store=external_event_store,
    )
    resume_run_use_case = ResumeRunUseCase(store=store)
    get_waiting_metadata_use_case = GetWaitingMetadataUseCase(
        store=store,
        skill_runner=skill_runner,
    )
    get_run_status_use_case = GetRunStatusUseCase(store)
    get_run_logs_use_case = GetRunLogsUseCase(runtime_event_store)
    get_runs_use_case = GetRunsUseCase(run_query)
    run_worker_service = RunWorkerService(
        complete_run_use_case=complete_run_use_case,
        fail_run_use_case=fail_run_use_case,
        append_runtime_event_use_case=append_runtime_event_use_case,
        render_current_step_use_case=render_current_step_use_case,
        render_mcp_config_use_case=render_mcp_config_use_case,
        execute_agent_step_use_case=execute_agent_step_use_case,
        execute_assign_step_use_case=execute_assign_step_use_case,
        execute_mcp_step_use_case=execute_mcp_step_use_case,
        execute_notify_step_use_case=execute_notify_step_use_case,
        execute_send_step_use_case=execute_send_step_use_case,
        execute_shell_step_use_case=execute_shell_step_use_case,
        execute_switch_step_use_case=execute_switch_step_use_case,
        execute_when_step_use_case=execute_when_step_use_case,
        execute_wait_channel_step_use_case=execute_wait_channel_step_use_case,
        execute_wait_input_step_use_case=execute_wait_input_step_use_case,
        execute_wait_webhook_step_use_case=execute_wait_webhook_step_use_case,
    )
    query_service = RunQueryService(
        get_run_status_use_case=get_run_status_use_case,
        get_run_logs_use_case=get_run_logs_use_case,
        get_runs_use_case=get_runs_use_case,
        get_waiting_metadata_use_case=get_waiting_metadata_use_case,
    )

    runtime_service = RuntimeApplicationService(
        bootstrap_runtime_use_case=bootstrap_runtime_use_case,
        append_runtime_event_use_case=append_runtime_event_use_case,
        create_run_use_case=create_run_use_case,
        delete_run_use_case=delete_run_use_case,
        fail_run_use_case=fail_run_use_case,
        get_start_step_use_case=get_start_step_use_case,
        skill_checker_use_case=skill_checker_use_case,
        skill_server_checker_use_case=skill_server_checker_use_case,
        handle_input_use_case=handle_input_use_case,
        handle_webhook_use_case=handle_webhook_use_case,
        handle_channel_use_case=handle_channel_use_case,
        list_webhooks_use_case=list_webhooks_use_case,
        register_webhook_use_case=register_webhook_use_case,
        remove_webhook_use_case=remove_webhook_use_case,
        resume_run_use_case=resume_run_use_case,
        interrupt_agent_use_case=interrupt_agent_use_case,
        get_agent_stats_use_case=get_agent_stats_use_case,
        get_run_status_use_case=get_run_status_use_case,
        run_worker_service=run_worker_service,
    )
    return RuntimeContainer(
        settings=cfg,
        runtime_service=runtime_service,
        query_service=query_service,
    )


def _build_llm(agent_config: AgentConfigPort) -> NullLLM | FakeLLM | OpenAILLM:
    provider = agent_config.get_config().llm.default()

    if provider.client_type == AgentLLMClientType.NULL:
        return NullLLM()

    if provider.client_type == AgentLLMClientType.FAKE:
        return FakeLLM(
            model=provider.model,
        )

    if provider.client_type == AgentLLMClientType.OPENAI_CHAT_COMPLETIONS:
        return OpenAILLM(
            api_key=provider.api_key,
            base_url=provider.base_url,
            model=provider.model,
            timeout_seconds=provider.timeout_seconds,
        )

    raise ValueError(
        f"Unsupported LLM client type='{provider.client_type.value}'. "
        "Use 'null', 'fake' or 'openai_chat_completions'."
    )


def _build_agent_tool_manager(settings: Settings) -> ToolManager:
    return ToolManager(
        tools=[
            _build_shell_tool(settings),
            NotifyTool(),
        ],
    )


def _build_shell_tool(settings: Settings) -> ShellProcessTool:
    return ShellProcessTool(
        workspace_root=settings.agent_shell_allowlist_workspace or None,
        allowlist_enabled=settings.agent_shell_allowlist_enabled,
        allowed_commands=list(settings.agent_shell_allowlist_allowed_commands),
        allow_env_prefix=settings.agent_shell_allowlist_allow_env_prefix,
        sandbox_enabled=settings.agent_shell_sandbox_enabled,
    )
