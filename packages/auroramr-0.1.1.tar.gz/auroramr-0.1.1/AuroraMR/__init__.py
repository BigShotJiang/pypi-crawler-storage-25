"""AuroraMR — autonomous mobile robotics helpers.

After ``pip install AuroraMR``, use ``import AuroraMR as amr`` (or ``import amr``).
"""

from amr.pose import Pose, pose

__all__ = ["Pose", "pose", "simulate"]


def __getattr__(name: str):
    if name == "simulate":
        from amr.simulate import simulate

        return simulate
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted({*globals(), "simulate"})
