from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Pose:
    """Planar pose.

    ``theta`` is in radians: ``0`` faces north (positive *y*), increasing
    counterclockwise (east is *π/2*).
    """

    x: float
    y: float
    theta: float


def pose(x: float, y: float, theta: float) -> Pose:
    """Build a 2D pose from position ``(x, y)`` and heading ``theta`` (radians)."""
    return Pose(x=x, y=y, theta=theta)
