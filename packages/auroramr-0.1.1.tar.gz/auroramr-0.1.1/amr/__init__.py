"""AuroraMR — autonomous mobile robotics helpers.

Use ``import amr`` or ``import AuroraMR as amr`` (same API).
"""

from .pose import Pose, pose

__all__ = ["Pose", "pose", "simulate"]


def __getattr__(name: str):
    if name == "simulate":
        from .simulate import simulate

        return simulate
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted({*globals(), "simulate"})
