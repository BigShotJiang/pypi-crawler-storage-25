use std::fs;
use std::path::Path;

const DEFINITION_REF_PREFIX: &str = "#/definitions/";

// ── Schema Document ──────────────────────────────────────────────────────

type JsonObject = serde_json::Map<String, serde_json::Value>;

/// Parsed JSON Schema with centralized navigation helpers.
/// Created once and shared across all generators so the schema is parsed
/// and its `definitions` map resolved in a single place.
struct SchemaDoc {
    root: serde_json::Value,
}

impl SchemaDoc {
    fn from_str(text: &str) -> Self {
        let root: serde_json::Value =
            serde_json::from_str(text).expect("Failed to parse schema JSON");
        SchemaDoc { root }
    }

    fn definitions(&self) -> Option<&JsonObject> {
        self.root.get("definitions").and_then(|d| d.as_object())
    }

    /// Resolve a `$ref` node to its target definition.
    /// Non-ref nodes pass through unchanged.
    /// Panics on malformed or unresolvable refs — those are schema-authoring
    /// errors that should fail the build loudly.
    fn resolve<'a>(&'a self, node: &'a serde_json::Value) -> &'a serde_json::Value {
        let Some(ref_path) = node.get("$ref").and_then(|r| r.as_str()) else {
            return node;
        };
        let def_name = ref_path
            .strip_prefix(DEFINITION_REF_PREFIX)
            .unwrap_or_else(|| panic!("Unsupported $ref format: {ref_path}"));
        self.definitions()
            .and_then(|d| d.get(def_name))
            .unwrap_or_else(|| panic!("Unresolved $ref: {ref_path}"))
    }

    /// Sorted property entries of a JSON Schema object node.
    /// Returns an empty vec for non-objects or objects without a `properties` key.
    fn sorted_properties<'a>(
        &'a self,
        node: &'a serde_json::Value,
    ) -> Vec<(&'a str, &'a serde_json::Value)> {
        let Some(properties) = node.get("properties").and_then(|p| p.as_object()) else {
            return Vec::new();
        };
        let mut entries: Vec<(&str, &serde_json::Value)> =
            properties.iter().map(|(k, v)| (k.as_str(), v)).collect();
        entries.sort_by(|(a, _), (b, _)| a.cmp(b));
        entries
    }

    /// Schema `type` keyword, defaulting to `"object"` when absent.
    fn node_type<'a>(&self, node: &'a serde_json::Value) -> &'a str {
        node.get("type")
            .and_then(|t| t.as_str())
            .unwrap_or("object")
    }

    fn root_properties(&self) -> Vec<(&str, &serde_json::Value)> {
        self.sorted_properties(&self.root)
    }
}

// ── Shared Object Tree Walker ────────────────────────────────────────────

/// Recursively visit every property of every reachable object node in the
/// schema, resolving `$ref` along the way.  Arrays and scalars are
/// intentionally skipped — the generated path constants are consumed by
/// object-only JSON navigation helpers that do not model array indices.
///
/// The `visit` callback receives the full segment path and the *resolved*
/// property value for every property of every reachable object.
fn walk_object_tree(
    doc: &SchemaDoc,
    current_path: &[String],
    node: &serde_json::Value,
    visit: &mut impl FnMut(&[String], &serde_json::Value),
) {
    let node = doc.resolve(node);
    if doc.node_type(node) != "object" {
        return;
    }

    for (name, raw_child) in doc.sorted_properties(node) {
        let child = doc.resolve(raw_child);
        let mut child_path = current_path.to_vec();
        child_path.push(name.to_string());
        visit(&child_path, child);
        walk_object_tree(doc, &child_path, child, visit);
    }
}

// ── Main ─────────────────────────────────────────────────────────────────

fn main() {
    println!("cargo:rerun-if-changed=./schemas/code-unit.schema.json");
    println!("cargo:rerun-if-changed=./schemas/query-reference.tmpl");
    println!("cargo:rerun-if-changed=./schemas/query-reference.rs.tmpl");

    let schema_path = Path::new("./schemas/code-unit.schema.json");
    let out_dir = Path::new("src/generated");

    // Create output directory if it doesn't exist
    fs::create_dir_all(out_dir).expect("Failed to create generated directory");

    if !schema_path.exists() {
        panic!(
            "Schema file not found at {:?}. \
             Ensure schemas/code-unit.schema.json exists before building.",
            schema_path
        );
    }

    let schema_content =
        fs::read_to_string(schema_path).expect("Failed to read code-unit.schema.json");

    // Typify needs its own parse (schemars::schema::RootSchema), so it
    // still receives the raw string.
    let generated_code = generate_with_typify(&schema_content);
    write_generated(out_dir, "types.rs", &generated_code, "types");

    let doc = SchemaDoc::from_str(&schema_content);

    let query_template = fs::read_to_string("./schemas/query-reference.tmpl")
        .expect("Failed to read schemas/query-reference.tmpl");
    let query_rs_template = fs::read_to_string("./schemas/query-reference.rs.tmpl")
        .expect("Failed to read schemas/query-reference.rs.tmpl");

    write_generated(
        out_dir,
        "query_reference.rs",
        &generate_query_reference(&doc, &query_template, &query_rs_template),
        "query reference",
    );

    write_generated(
        out_dir,
        "updated_at_paths.rs",
        &generate_updated_at_paths(&doc),
        "updated_at_paths",
    );

    write_generated(
        out_dir,
        "file_path_fields.rs",
        &generate_file_path_fields(&doc),
        "file_path_fields",
    );

    check_sibling_generated_files();
}

fn check_sibling_generated_files() {
    let siblings = [
        "../scai-state-python/python/snowflake_code_unit_registry/types.py",
        "../scai-state-csharp/dotnet/ScaiState/Types.cs",
        "../scai-state-csharp/dotnet/ScaiState/Interop.cs",
    ];

    let missing: Vec<&str> = siblings
        .iter()
        .filter(|p| !Path::new(p).exists())
        .copied()
        .collect();

    if !missing.is_empty() {
        println!(
            "cargo:warning=Generated type files are missing ({}). Run: ./scripts/generate-types.sh",
            missing.join(", ")
        );
    }
}

fn write_generated(out_dir: &Path, filename: &str, code: &str, label: &str) {
    let output_path = out_dir.join(filename);
    fs::write(&output_path, code).unwrap_or_else(|_| panic!("Failed to write {}", label));
    println!("cargo:warning=Generated {} to {:?}", label, output_path);
}

fn render_path_constant(const_name: &str, comment: &str, paths: &[Vec<String>]) -> String {
    let mut code = String::from("// AUTO-GENERATED FROM JSON SCHEMA - DO NOT EDIT MANUALLY\n");
    code.push_str(comment);
    code.push_str("\n\n");
    code.push_str(&format!("pub const {const_name}: &[&[&str]] = &[\n"));
    for path in paths {
        let segments: Vec<String> = path.iter().map(|s| format!("\"{}\"", s)).collect();
        code.push_str(&format!("    &[{}],\n", segments.join(", ")));
    }
    code.push_str("];\n");
    code
}

// ── Query Reference Generator ────────────────────────────────────────────

/// A flattened field descriptor extracted from the JSON Schema.
struct FieldInfo {
    path: String,
    type_name: String,
    enum_values: Option<String>,
    description: String,
}

/// Walk the JSON Schema and produce a Rust source file containing
/// `pub const QUERY_REFERENCE: &str` with the full flattened field reference.
///
/// This generator has its own recursive traversal (`collect_fields`) because
/// it handles arrays, enums, and `x-query-help` exclusion — none of which
/// apply to the path-oriented generators that share `walk_object_tree`.
fn generate_query_reference(doc: &SchemaDoc, template: &str, rs_template: &str) -> String {
    let mut fields = Vec::new();
    for (name, prop) in doc.root_properties() {
        collect_fields(&mut fields, name, prop, doc);
    }

    let fields_table = format_fields_table(&fields);
    let reference = template.replace("{fields_table}", &fields_table);
    let ref_literal = format!("r#\"{}\"#", reference);
    rs_template.replace("{ref_literal}", &ref_literal)
}

/// Returns true if the property is explicitly excluded from the query reference
/// via `"x-query-help": false`.
fn is_excluded(prop: &serde_json::Value) -> bool {
    prop.get("x-query-help")
        .and_then(|v| v.as_bool())
        .is_some_and(|v| !v)
}

/// Recursively walk the schema, collecting leaf and container field descriptors.
fn collect_fields(
    fields: &mut Vec<FieldInfo>,
    prefix: &str,
    prop: &serde_json::Value,
    doc: &SchemaDoc,
) {
    if is_excluded(prop) {
        return;
    }

    let prop = doc.resolve(prop);

    let type_str = doc.node_type(prop);
    let description = prop
        .get("description")
        .and_then(|d| d.as_str())
        .unwrap_or("")
        .to_string();

    match type_str {
        "object" => {
            fields.push(FieldInfo {
                path: prefix.to_string(),
                type_name: "object".to_string(),
                enum_values: None,
                description,
            });
            for (name, sub_prop) in doc.sorted_properties(prop) {
                let child_path = format!("{}.{}", prefix, name);
                collect_fields(fields, &child_path, sub_prop, doc);
            }
        }
        "array" => {
            let item_desc = prop
                .get("items")
                .map(|i| describe_array_items(i, doc))
                .unwrap_or_default();
            let full_desc = if description.is_empty() {
                item_desc
            } else if item_desc.is_empty() {
                description
            } else {
                format!("{}; items: {}", description, item_desc)
            };
            fields.push(FieldInfo {
                path: prefix.to_string(),
                type_name: "array".to_string(),
                enum_values: None,
                description: full_desc,
            });
        }
        _ => {
            let enum_values = prop.get("enum").and_then(|e| {
                e.as_array().map(|arr| {
                    arr.iter()
                        .filter_map(|v| v.as_str().map(String::from))
                        .collect::<Vec<_>>()
                        .join(", ")
                })
            });
            let display_type = if enum_values.is_some() {
                "enum".to_string()
            } else {
                type_str.to_string()
            };
            fields.push(FieldInfo {
                path: prefix.to_string(),
                type_name: display_type,
                enum_values,
                description,
            });
        }
    }
}

/// Produce a short description of array item shapes (for display only).
fn describe_array_items(items: &serde_json::Value, doc: &SchemaDoc) -> String {
    let resolved = doc.resolve(items);

    match resolved.get("type").and_then(|t| t.as_str()) {
        Some("string") => "string".to_string(),
        Some("object") => {
            let props = doc.sorted_properties(resolved);
            if props.is_empty() {
                "object".to_string()
            } else {
                let keys: Vec<&str> = props.iter().map(|(k, _)| *k).collect();
                format!("{{{}}}", keys.join(", "))
            }
        }
        Some(t) => t.to_string(),
        None => String::new(),
    }
}

/// Format the collected fields into an aligned table string.
fn format_fields_table(fields: &[FieldInfo]) -> String {
    let path_width = fields
        .iter()
        .map(|f| f.path.len())
        .max()
        .unwrap_or(20)
        .max(20);
    let type_width = 10;

    let mut out = String::new();
    out.push_str(&format!(
        "  {:<path_width$}  {:<type_width$}  {}\n",
        "Field", "Type", "Allowed Values / Description",
    ));
    out.push_str(&format!("  {}\n", "─".repeat(path_width + type_width + 40)));

    for f in fields {
        let detail = match (&f.enum_values, f.description.is_empty()) {
            (Some(vals), true) => vals.clone(),
            (Some(vals), false) => format!("{} ({})", vals, f.description),
            (None, false) => f.description.clone(),
            (None, true) => String::new(),
        };
        out.push_str(&format!(
            "  {:<path_width$}  {:<type_width$}  {}\n",
            f.path, f.type_name, detail,
        ));
    }

    out
}

// ── UpdatedAt Path Extraction ─────────────────────────────────────────────

/// Walk the JSON Schema and find all parent paths of `updatedAt` properties.
/// Generates a Rust source file with a constant array of those paths.
///
/// Uses `walk_object_tree` and simply records the parent path (all segments
/// except the last) whenever the walker visits a property named `updatedAt`.
fn generate_updated_at_paths(doc: &SchemaDoc) -> String {
    let mut parent_paths: Vec<Vec<String>> = Vec::new();

    walk_object_tree(doc, &[], &doc.root, &mut |path, _node| {
        if path.last().map(|s| s.as_str()) == Some("updatedAt") {
            parent_paths.push(path[..path.len() - 1].to_vec());
        }
    });

    parent_paths.sort();
    render_path_constant(
        "UPDATED_AT_PARENT_PATHS",
        "// Parent paths of all `updatedAt` properties in code-unit.schema.json",
        &parent_paths,
    )
}

// ── File Path Field Extraction ─────────────────────────────────────────────

/// Walk the JSON Schema and find all string properties whose description
/// starts with "Repo-root-relative".  Generates a constant array of
/// segment paths.
///
/// Uses `walk_object_tree` and inspects each visited node.
fn generate_file_path_fields(doc: &SchemaDoc) -> String {
    let mut paths: Vec<Vec<String>> = Vec::new();

    walk_object_tree(doc, &[], &doc.root, &mut |path, node| {
        if doc.node_type(node) == "string" {
            if let Some(desc) = node.get("description").and_then(|d| d.as_str()) {
                if desc.starts_with("Repo-root-relative") {
                    paths.push(path.to_vec());
                }
            }
        }
    });

    paths.sort();
    render_path_constant(
        "FILE_PATH_FIELDS",
        "// Segment paths of all file path properties in code-unit.schema.json",
        &paths,
    )
}

// ── Typify Code Generation ───────────────────────────────────────────────

fn generate_with_typify(schema: &str) -> String {
    use typify::{TypeSpace, TypeSpaceSettings};

    let schema: schemars::schema::RootSchema =
        serde_json::from_str(schema).expect("Failed to parse JSON schema");

    let mut settings = TypeSpaceSettings::default();
    settings.with_struct_builder(false);

    let mut type_space = TypeSpace::new(&settings);
    type_space
        .add_root_schema(schema)
        .expect("Failed to add schema to TypeSpace");

    let tokens = type_space.to_stream();

    // Typify emits `skip_serializing_if` for fields with empty defaults
    // (Vec::is_empty, Map::is_empty).  This causes empty containers to be
    // silently dropped during serialization, breaking round-trip fidelity.
    // Strip those attributes so that empty defaults are always written to
    // disk.  The `Option::is_none` variant is intentionally kept -- those
    // represent truly optional fields.
    let raw_code = tokens.to_string();

    let code = raw_code
        .replace(r#", skip_serializing_if = "Vec::is_empty""#, "")
        .replace(r#", skip_serializing_if = "::std::vec::Vec::is_empty""#, "")
        .replace(
            r#", skip_serializing_if = "::serde_json::Map::is_empty""#,
            "",
        );

    // Each pattern must match at least once.  If a typify or proc-macro2
    // update changes the token format, we want a loud build failure here
    // rather than a silent regression that drops empty containers.
    assert!(
        !code.contains("skip_serializing_if = \"Vec::is_empty\"")
            && !code.contains("skip_serializing_if = \"::std::vec::Vec::is_empty\"")
            && !code.contains("skip_serializing_if = \"::serde_json::Map::is_empty\""),
        "build.rs: skip_serializing_if stripping left residual matches. \
         The token format from typify may have changed — update the patterns above."
    );

    // Typify omits Default for structs with #[serde(flatten)] maps.
    // Inject it for CodeStatus since all fields implement Default.
    let code = if code.contains("pub struct CodeStatus") && !code.contains("Default for CodeStatus")
    {
        format!(
            "{code}\nimpl ::std::default::Default for CodeStatus {{\
            fn default() -> Self {{ Self {{\
            ai_verification: Default::default(),\
            assessment: Default::default(),\
            conversion: Default::default(),\
            registration: Default::default(),\
            extra: Default::default(),\
            }} }} }}\n"
        )
    } else {
        code
    };

    // Same treatment for CloudStatus which also has #[serde(flatten)].
    let code =
        if code.contains("pub struct CloudStatus") && !code.contains("Default for CloudStatus") {
            format!(
                "{code}\nimpl ::std::default::Default for CloudStatus {{\
            fn default() -> Self {{ Self {{\
            data_migration: Default::default(),\
            data_validation: Default::default(),\
            deployment: Default::default(),\
            testing: Default::default(),\
            extra: Default::default(),\
            }} }} }}\n"
            )
        } else {
            code
        };

    let preamble = "\
        // AUTO-GENERATED FROM JSON SCHEMA - DO NOT EDIT MANUALLY\n\
        // Generated by build.rs using typify from schemas/code-unit.schema.json\n\
        \n\
        #![allow(unused_imports)]\n\
        #![allow(clippy::clone_on_copy)]\n\
        #![allow(clippy::derivable_impls)]\n\
        \n\
        use serde::{Deserialize, Serialize};\n\
        \n";

    let raw = format!("{preamble}{code}\n");

    let syntax_tree = syn::parse_file(&raw).expect("Failed to parse generated code");
    prettyplease::unparse(&syntax_tree)
}
