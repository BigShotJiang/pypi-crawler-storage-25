"""
    1. 去https://pan.baidu.com/union 百度网盘开发平台注册创建
    2. 创建一个应用：测试
        记录
            AppKey
            ScretKey
    3. 获取access token
        https://openapi.baidu.com/oauth/2.0/authorize?response_type=code&client_id=ZS1kAXCy9xy20DjrBHO6gWDAEZwffYLI&redirect_uri=oob&scope=basic,netdisk
        点击同意授权
        得到授权码
    4. 用授权码 获取access token
    5. 计算文件分片md5 加密
    test 每小时只能使用·10次
"""
import requests
import os
import json
from requests import RequestException
import time
from .utils import *
from typing import Optional

class BaiduDiskClient:
    _TOKEN_URL = "https://openapi.baidu.com/oauth/2.0/token"
    _FILE_URL = "https://pan.baidu.com/rest/2.0/xpan/file"
    _MULTIMEDIA_URL = "https://pan.baidu.com/rest/2.0/xpan/multimedia"
    _UPLOAD_URL = "https://d.pcs.baidu.com/rest/2.0/pcs/superfile2"

    def __init__(self,
                 # 需要去百度网盘平台申请得到
                 app_name:str,
                 app_id: str,
                 app_key:str,
                 secret_key:str,
                 sign_key:str,
                 # 需要去百度网盘平台授权得到
                 grant_code:str,
                 # 个性化设定
                 upload_chuck_size:int=4*1024*1024,
                 config_path="bd_trans.json"
                 ):
        # self.__token_url = "https://openapi.baidu.com/oauth/2.0/token"
        # self.__file_url = "https://pan.baidu.com/rest/2.0/xpan/file"
        # self.__multimedia_url = "https://pan.baidu.com/rest/2.0/xpan/multimedia"
        # self.__upload_url = "https://d.pcs.baidu.com/rest/2.0/pcs/superfile2"
        self.app_name = app_name
        self.app_id = app_id
        self.app_key = app_key
        self.secret_key = secret_key
        self.sign_key = sign_key
        self.grant_code = grant_code
        self.upload_chuck_size = upload_chuck_size
        self.config_path = config_path
        self.__app_dir = f"/apps/{app_name}"
        self.__token_config = None
        self.__get_access_token()


    @property
    def token_url(self)->str:
        return self._TOKEN_URL

    @property
    def file_url(self)->str:
        return self._FILE_URL

    @property
    def upload_url(self)->str:
        return self._UPLOAD_URL

    @property
    def multimedia_url(self)->str:
        return self._MULTIMEDIA_URL

    @property
    def app_dir(self)->str:
        return self.__app_dir

    @property
    def token_config(self):
        """
            attn: dict 是一个可变对象
        :return:
        """
        return self.__token_config.copy()

    def save_conf(self,conf_json):
        with open(self.config_path, "w", encoding='utf-8') as f:
            f.write(json.dumps(conf_json, ensure_ascii=False, indent=2))

    def __get_access_token(self,timeout:int=60):
        """
         获取百度云盘 access token(只能维持30天)
        :return:
        """
        if os.path.exists(self.config_path):
           with open(self.config_path, "r") as f:
               json_data = json.load(f)
               required_keys = {"access_token", "refresh_token", "access_token_deadline"}
               if required_keys.issubset(json_data):
                   self.__token_config = json_data
                   return
               # if "access_token" in json_data.keys() and "refresh_token" in json_data.keys() and "access_token_deadline" in json_data.keys():
               #      self.__token_config = json_data
               #      return
        params = {
            "grant_type": "authorization_code",
            "code": self.grant_code,
            "client_id": self.app_key,
            "client_secret": self.secret_key,
            "redirect_uri": "oob"
        }
        try:
            res = requests.get(
                self.token_url,
                params=params,
                timeout=timeout
            )
            res.raise_for_status()
            res = res.json()
            if res.get("error",None): raise Exception(res.get("error description"))
            res["access_token_deadline"] = int(time.time()+res["expires_in"])
            self.__token_config = res
            self.save_conf(res)
        except RequestException as e:
            raise RuntimeError(e) from e
        except Exception as e:
            raise ValueError(e)

    def __refresh_access_token(self,timeout:int=60):
        """
        刷新 access token
        :return:
        """
        if time.time() <= self.__token_config["access_token_deadline"] - 24 * 3600:
            return
        params = {
            "grant_type": "refresh_token",
            "refresh_token": self.__token_config["refresh_token"],
            "client_id": self.app_key,
            "client_secret": self.secret_key,
        }

        try:
            res = requests.get(
                self.token_url,
                params=params,
                timeout=timeout
            )
            res.raise_for_status()
            res_json = res.json()
            if res_json.get("error"):
                raise RuntimeError(f"refresh token failed: {res_json}")
            res_json["access_token_deadline"] = int(time.time()+res_json["expires_in"])
            self.__token_config = res_json
            self.save_conf(res_json)
        except requests.RequestException as e:
            raise RuntimeError(f"request  failed: {e}")
        except Exception as e:
            raise ValueError(e)

    def __precreate(self,remote_path,file_size:int,md5_list:list,timeout:int=60):
        """
            预先上传
        :return:
        """
        params = {
            "method":"precreate",
            "access_token":self.__token_config["access_token"],
        }

        data = {
            "path": remote_path,
            "size": file_size,
            "isdir": 0,
            "autoinit": 1,
            "rtype": 3,
            "block_list": json.dumps(md5_list),
        }
        try:
            res = requests.post(
                self.file_url,
                params=params,
                data=data,
                timeout=timeout
            )
            res.raise_for_status()
            res = res.json()
            if res.get('errno') != 0:
                raise ValueError(res)
        except requests.RequestException as e:
            raise RuntimeError(e)
        except Exception as e:
            raise ValueError(e)

        return {
            "need_parts":res.get("block_list",list(range(len(md5_list)))),
            "upload_id":res.get("uploadid"),
        }

    def __upload_one_chunk(self,remote_path,file_path:str,part_seq:int,pre_creation:dict,timeout:int=60):
        params = {
            "method": "upload",
            "type": "tmpfile",  # 临时文件
            "access_token": self.__token_config["access_token"],
            "path": remote_path,
            "uploadid": pre_creation["upload_id"],
            "partseq": part_seq,
        }
        with open(file_path, "rb") as f:
            f.seek(part_seq * self.upload_chuck_size)
            data = f.read(self.upload_chuck_size)
        files = {'file': ("chunk", data)}
        try:
            res = requests.post(
                self.upload_url,
                params=params,
                files=files,
                timeout=timeout
            )
            res.raise_for_status()
            res = res.json()
        except requests.RequestException as e:
            raise RuntimeError(f"request error: {e}") from e
        except Exception as e:
            raise ValueError(e)
        if "md5" not in res:
            raise Exception(res)

    def __upload_chucks(self,remote_path:str,file_path:str,pre_creation:dict):
        """
            上传分片
        :return:
        """
        if pre_creation["need_parts"] is None:
            raise ValueError(f"[upload chucks]: need_parts is {pre_creation['need_parts']}")
        for part_seq in pre_creation["need_parts"]:
            self.__upload_one_chunk(
                remote_path=remote_path,
                file_path=file_path,
                part_seq=part_seq,
                pre_creation=pre_creation
            )
        print("[upload chucks] done")

    def __create(self,remote_path,file_size:int,md5_list:list,pre_creation:dict,timeout:int=60):
        """
        合并分片
        :return:
        """
        params = {
            "method": "create",
            "access_token": self.__token_config["access_token"],
        }
        data = {
            "path": remote_path,
            "size": file_size,
            "isdir": 0,
            "rtype": 3,
            "uploadid": pre_creation["upload_id"],
            "block_list": json.dumps(md5_list),
        }
        try:
            res = requests.post(
                self.file_url,
                params=params,
                data=data,
                timeout=timeout
            )
            res.raise_for_status()
            res = res.json()
            if res.get("errno") != 0:
                raise ValueError(res)
        except requests.RequestException as e:
            raise RuntimeError(f"request error: {e}") from e
        return res

    def upload(self,file_path:str,remote_dir_path:Optional[str]=None):

        """
        上传文件
        :param file_path:
        :return:
        """
        self.__refresh_access_token()
        if remote_dir_path is None:
            remote_path = build_remote_path(self.app_dir,file_path)
        else:
            remote_path = build_remote_path(remote_dir_path,file_path)
        size = os.path.getsize(file_path)
        md5_list = get_md5_list(file_path=file_path,chunk_size=self.upload_chuck_size)
        pre_creation = self.__precreate(
            remote_path=remote_path,
            file_size=size,
            md5_list=md5_list
        )

        self.__upload_chucks(remote_path=remote_path,file_path=file_path,pre_creation=pre_creation)
        return self.__create(remote_path=remote_path,file_size=size,md5_list=md5_list,pre_creation=pre_creation)

    def list_files(self,dir_path:str,timeout:int=60):
        """
            列出所有文件
        :param dir_path:
        :param timeout:
        :return:
        """
        dir_path = normalize_remote_dir(dir_path)
        self.__refresh_access_token()
        params = {
            "method": "list",
            "access_token": self.__token_config["access_token"],
            "dir": dir_path,
        }
        try:
            res = requests.get(
                self.file_url,
                params=params,
                timeout=timeout
            )
            res.raise_for_status()
            res = res.json()

            if res.get("errno") == -9:
                return []
            elif res.get("errno") != 0:
                raise ValueError(res)
        except  requests.RequestException as e:
            raise RuntimeError(f"request error: {e}") from e
        return res.get("list", [])

    def __get_fs_id_by_remote_path(self,remote_path:str):
        import posixpath
        """
            获取文件fs_id
        :param remote_path:
        :return:
        """
        remote_path = normalize_remote_dir(remote_path)
        dir_path = posixpath.dirname(remote_path)
        file_name = posixpath.basename(remote_path)
        files = self.list_files(dir_path=dir_path,timeout=60)
        for item in files:
            if item.get("server_filename",) == file_name:
                return item.get("fs_id")

        raise FileNotFoundError(f"未找到该文件{remote_path}")

    def __get_dlink(self,fs_id:int,timeout:int=60):
        """
        获取dlink 下载连接
        :param fs_id:
        :return:
        """
        params = {
            "method": "filemetas",
            "access_token": self.__token_config["access_token"],
            "fsids": json.dumps([fs_id]),
            "dlink": 1,
        }
        try:
            res = requests.get(
                self.multimedia_url,
                params=params,
                timeout=timeout
            )
            res.raise_for_status()
            res = res.json()
            if res.get("errno") != 0: raise RuntimeError(f"get dlink failed: {res}")
        except requests.RequestException as e:
            raise RuntimeError(f"request error: {e}") from e
        except Exception as e:
            raise ValueError(e)
        file_list = res.get("list", [])
        if not file_list:
            raise RuntimeError(f"filemetas 返回为空: {res}")
        dlink = file_list[0].get("dlink")
        if not dlink:
            raise RuntimeError(f"没有获取到 dlink: {res}")

        return dlink

    def __download_by_dlink(self,dlink:str,save_path:str,timeout:int=60):
        """
            根据dlinK 下载文件
        :return:
        """
        access_token = self.__token_config["access_token"]
        if "?" in dlink:
            download_url = dlink + "&access_token=" + access_token
        else:
            download_url = dlink + "?access_token=" + access_token

        headers = {
            "User-Agent":"pan.baidu.com"
        }
        with requests.get(
                download_url,
                headers=headers,
                stream=True,
                timeout=timeout
        ) as res:
            res.raise_for_status()
            dir_name = os.path.dirname(save_path)
            if dir_name:
                os.makedirs(dir_name, exist_ok=True)
            with open(save_path, "wb") as f:
                for chunk in res.iter_content(chunk_size=1024*1024):
                    if chunk: f.write(chunk)
        print("[download success]",save_path)

    def download_one_file(self,remote_file_path:str,save_path:str):
        self.__refresh_access_token()
        fs_id = self.__get_fs_id_by_remote_path(remote_file_path)
        dlink = self.__get_dlink(fs_id,timeout=60)
        self.__download_by_dlink(dlink,save_path,timeout=60)


