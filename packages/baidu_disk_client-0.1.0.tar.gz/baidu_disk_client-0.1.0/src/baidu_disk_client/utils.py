import hashlib
import os

def get_md5_list(file_path,chunk_size=4*1024*1024):
    """
    分片 md5 加密
    :param file_path:
    :param chunk_size:
    :return:
    """
    md5_list = []
    size = os.path.getsize(file_path)
    if size <= 0:
        raise ValueError("size <= 0,this file is invalid")
    with open(file_path, 'rb') as f:
        for i in range(0, size, chunk_size):
            data = f.read(chunk_size)
            md5_chunk = hashlib.md5(data).hexdigest()
            md5_list.append(md5_chunk)
    return md5_list

def normalize_remote_dir(remote_dir_path: str) -> str:
    remote_dir_path = remote_dir_path.replace("\\", "/")

    if not remote_dir_path.startswith("/"):
        remote_dir_path = "/" + remote_dir_path

    return remote_dir_path.rstrip("/") or "/"

def build_remote_path(remote_dir_path:str,file_path:str ):
    import posixpath
    file_name = os.path.basename(file_path)
    if not remote_dir_path:
        raise ValueError("remote_dir_path cannot be empty")
    remote_dir_path = normalize_remote_dir(remote_dir_path)
    return posixpath.join(remote_dir_path, file_name)