# baidu-disk-client

A simple Python client for Baidu Netdisk.

This package provides basic Baidu Netdisk operations, including:

- Upload files
- List remote files
- Download files
- Manage access token and refresh token locally

> This is an unofficial Baidu Netdisk client.

## Installation

For local development:

```bash
pip install -e .
```

After publishing to PyPI:

```bash
pip install baidu-disk-client
```

## Requirements
- Python 3.9+
- requests

## Authorization

Authorization

Before using this client, you need to create an application on Baidu Open Platform and get:
- app name
- app id
- app key 
- secret key 
- sign key
- authorization code

The authorization code is only used for the first token exchange. After the first successful authorization, token information will be saved locally in bd_trans.json.
Do not commit bd_trans.json, .env, access tokens, refresh tokens, app keys, or secret keys to Git.

## Usage
### upload file
```python
import os
from baidu_disk_client import BaiduDiskClient

client = BaiduDiskClient(
    app_name=os.environ["BAIDU_APP_NAME"],
    app_id=os.environ["BAIDU_APP_ID"],
    app_key=os.environ["BAIDU_APP_KEY"],
    secret_key=os.environ["BAIDU_SECRET_KEY"],
    sign_key=os.environ["BAIDU_SIGN_KEY"],
    grant_code=os.environ.get("BAIDU_GRANT_CODE"),
)

result = client.upload(
    file_path="demo.txt",
    remote_dir_path="/my_uploads",
)

print(result)


```

### list files
```python
import os
from baidu_disk_client import BaiduDiskClient
client = BaiduDiskClient(
    app_name=os.environ["BAIDU_APP_NAME"],
    app_id=os.environ["BAIDU_APP_ID"],
    app_key=os.environ["BAIDU_APP_KEY"],
    secret_key=os.environ["BAIDU_SECRET_KEY"],
    sign_key=os.environ["BAIDU_SIGN_KEY"],
    grant_code=os.environ.get("BAIDU_GRANT_CODE"),
)

files = client.list_files("/my_uploads")

for item in files:
    print(item["server_filename"], item["path"])

```

### Download file
```python
import os
from baidu_disk_client import BaiduDiskClient
client = BaiduDiskClient(
    app_name=os.environ["BAIDU_APP_NAME"],
    app_id=os.environ["BAIDU_APP_ID"],
    app_key=os.environ["BAIDU_APP_KEY"],
    secret_key=os.environ["BAIDU_SECRET_KEY"],
    sign_key=os.environ["BAIDU_SIGN_KEY"],
    grant_code=os.environ.get("BAIDU_GRANT_CODE"),
)

client.download_one_file(
    remote_file_path="/my_uploads/demo.txt",
    save_path="downloads/demo.txt",
)
```

## Notes
- remote_dir_path should be a Baidu Netdisk remote directory path.
- If remote_dir_path is not provided when uploading, the file will be uploaded to the app directory by default.
- Token configuration is saved in bd_trans.json. 
- Keep your credentials private.