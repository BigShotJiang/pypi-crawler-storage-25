from poetry.plugins.application_plugin import ApplicationPlugin
from .core import ALL, MainCommand


class CloversApplicationPlugin(ApplicationPlugin):
    def activate(self, application):
        for command in (MainCommand, *ALL):
            application.command_loader.register_factory(command.name, command)
