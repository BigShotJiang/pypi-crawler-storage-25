from .main import ADAPTER as ADAPTER


__version__ = "0.1.0"
__all__ = ["ADAPTER"]
