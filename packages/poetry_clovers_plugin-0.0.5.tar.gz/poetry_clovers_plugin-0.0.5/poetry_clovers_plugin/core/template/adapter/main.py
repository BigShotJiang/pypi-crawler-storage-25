from clovers import Adapter
from clovers_client.event import MemberInfo

ADAPTER = Adapter("SAMPLE")


@ADAPTER.send_method("text")
async def _(message: str, /): ...


@ADAPTER.property_method("user_id")
async def _() -> str: ...


@ADAPTER.call_method("group_member_list")
async def _(group_id: str, user_id: str, /, data: dict) -> list[MemberInfo]: ...
