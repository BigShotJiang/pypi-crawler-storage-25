from pathlib import Path

TEMPLATE_DIR = Path(__file__).parent
TEMPLATE_PLUGIN_DIR = TEMPLATE_DIR / "plugin"
TEMPLATE_ADAPTER_DIR = TEMPLATE_DIR / "adapter"
TEMPLATE_BOT_DIR = TEMPLATE_DIR / "bot"
