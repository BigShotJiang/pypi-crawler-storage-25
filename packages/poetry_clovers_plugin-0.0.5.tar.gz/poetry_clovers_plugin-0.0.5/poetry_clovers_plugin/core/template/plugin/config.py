from clovers_client import Config as BaseConfig


class Config(BaseConfig):
    hello: str = "Hello World!"
