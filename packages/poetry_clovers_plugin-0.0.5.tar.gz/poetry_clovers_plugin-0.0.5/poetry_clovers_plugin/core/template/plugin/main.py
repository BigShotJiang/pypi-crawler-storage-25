from clovers import Plugin
from clovers.logger import logger
from clovers_client import Event
from .utils import build_result
from .config import Config

if not __package__:
    raise RuntimeError("插件路径只能作为模块导入。")

CONFIG = Config.sync_config(__package__)
PLUGIN = Plugin[Event](build_result=build_result)
PLUGIN.protocol = Event


@PLUGIN.startup
def _():
    logger.info(CONFIG.hello)


@PLUGIN.handle(["测试", "test"], ["user_id", "group_id", "nickname", "to_me"], rule=lambda e: e.to_me)
async def _(event: Event):
    await event.send("text", f"Hello, {event.nickname}")
    return f"UID: {event.user_id}\nGID: {event.group_id}\n昵称: {event.nickname}"
