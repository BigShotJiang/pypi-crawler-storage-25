from .main import PLUGIN


__version__ = "0.1.0"
__all__ = ["PLUGIN"]
