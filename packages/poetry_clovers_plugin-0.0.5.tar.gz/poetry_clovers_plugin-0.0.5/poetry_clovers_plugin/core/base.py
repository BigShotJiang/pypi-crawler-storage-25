from typing import Any
from collections.abc import Iterable
from poetry.console.commands.command import Command


class CloversBaseCommand(Command):
    name: str

    def handle(self) -> int:
        self.add_style("info", fg="#00FFFF", options=["bold"])
        self.add_style("comment", fg="#FFFF00", options=["bold"])
        self.add_style("error", fg="#FF0000", options=["bold"])
        self.add_style("success", fg="#00FF00", options=["bold"])
        self.add_style("clovers", fg="#00CC33", options=["bold"])
        return self.exec()

    def exec(self) -> int:
        raise NotImplementedError


def dict_path(resorce_dict: dict, key_path: Iterable[str]) -> Any:
    target_dict = resorce_dict
    for key in key_path:
        if isinstance(target_dict, dict) and key in target_dict:
            target_dict = target_dict[key]
        else:
            return
    return target_dict
