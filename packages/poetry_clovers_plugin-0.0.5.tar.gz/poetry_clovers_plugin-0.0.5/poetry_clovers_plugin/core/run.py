from pathlib import Path
from cleo.helpers import argument
from .base import CloversBaseCommand


class RunCommand(CloversBaseCommand):
    name = "clovers run"
    description = "Launch the bot"
    arguments = [argument("name", description="bot script", optional=True)]

    def exec(self) -> int:
        name = self.argument("name")
        if name:
            return self.call("run", name)
        if not Path("bot.py").exists():
            self.line("Error: 'bot.py' not found in current directory.", style="error")
            return 1
        return self.call("run", "python bot.py")
