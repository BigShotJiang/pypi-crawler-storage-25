import sys
import subprocess
from pathlib import Path
from cleo.helpers import argument
from poetry.pyproject.toml import PyProjectTOML
from .base import CloversBaseCommand
from .template import TEMPLATE_BOT_DIR


def init_project(project_path: Path, package_name: str):
    import shutil

    shutil.copytree(TEMPLATE_BOT_DIR, project_path, dirs_exist_ok=True)
    INIT_COMMAND = (
        sys.executable,
        "-m",
        "poetry",
        "init",
        "--name",
        package_name,
        "--python",
        ">=3.12,<4.0.0",
        "--dependency",
        f"clovers_client",
        "--no-interaction",
    )

    p = subprocess.run(INIT_COMMAND, cwd=project_path)
    if p.returncode != 0:
        raise Exception("Failed to initialize project")
    pyproject = PyProjectTOML(project_path / "pyproject.toml")
    pyproject.data.setdefault("tool", {}).setdefault("poetry", {})["package-mode"] = False
    pyproject.save()
    INSTALL_COMMAND = (
        sys.executable,
        "-m",
        "poetry",
        "install",
        "--no-interaction",
    )
    p = subprocess.run(INSTALL_COMMAND, cwd=project_path)
    if p.returncode != 0:
        raise Exception("Failed to install dependencies")


def get_extras(project_path: Path) -> list[str]:
    from .scripts import get_extras

    result = subprocess.run(
        (sys.executable, "-m", "poetry", "run", "python", Path(get_extras.__file__).resolve().as_posix()),
        cwd=project_path,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    METADATA = result.stdout
    return [line.split(":")[1].strip() for line in METADATA.splitlines() if line.startswith("Provides-Extra:")]


def install_client(project_path: Path, client: str) -> None:
    INSTALL_CLIENT_COMMAND = (
        sys.executable,
        "-m",
        "poetry",
        "add",
        f"clovers_client[{client}]",
        "--no-interaction",
    )
    p = subprocess.run(INSTALL_CLIENT_COMMAND, cwd=project_path)
    if p.returncode != 0:
        raise RuntimeError("Failed to install client")


class CreateCommand(CloversBaseCommand):
    name = "clovers create"
    description = "Create a clovers bot based on `clovers_client`"
    arguments = [argument("name", optional=False, description="Your project name")]

    def exec(self) -> int:
        name: str = self.argument("name")
        path = Path(name)
        if path.exists():
            self.line(f'"{name}" already exists', style="error")
            return 1
        path.mkdir(parents=True)
        self.line(f"Creating project '{name}'...", style="info")
        init_project(path, name)
        clients = get_extras(path)
        if not clients:
            raise RuntimeError("No clients found")
        client = self.choice("Choose a client: ", clients)
        install_client(path, client)
        bot = path / "bot.py"
        bot.write_text(
            f"""
import asyncio
from clovers_client.{client.replace('-',".")} import Client

asyncio.run(Client().run())
"""
        )
        bot.chmod(0o755)
        return 0
