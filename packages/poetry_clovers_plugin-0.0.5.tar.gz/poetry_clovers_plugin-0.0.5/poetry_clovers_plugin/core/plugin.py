from typing import AbstractSet
from cleo.helpers import argument
from .base import CloversBaseCommand, dict_path


class PluginCommand(CloversBaseCommand):
    name = "clovers plugin"
    description = "Manage clovers-plugins."
    arguments = [
        argument("do", optional=True, description="[add,remove,update]"),
        argument("name", optional=True, multiple=True, description="package name"),
    ]

    def exec(self) -> int:
        self.group_plugins_sync()
        do = self.argument("do")
        if not do:
            return self.introduce()
        match do:
            case "add":
                return self.handle_add()
            case "remove":
                return self.handle_remove()
            case "update":
                return self.handle_update()
            case _:
                self.line(f'Invalid command "{do}" please use [add,remove,update]', style="error")
                return -1

    def introduce(self):
        self.line("<clovers>Clovers Plugin Manager</clovers>")
        self.line("\nUsage: clovers plugin <add|remove|update> [name...]")
        self.line("\nCommands:")
        self.line("  <comment>add</comment> <name...>     Add one or more plugins to the project.")
        self.line("  <comment>remove</comment> <name...>  Remove plugins from poetry group and clovers config.")
        self.line("  <comment>update</comment> <name...>  Update plugins (or all if no name specified) using poetry update.")
        self.line("\nExamples:")
        self.line("  clovers plugin <comment>add</comment> plugin-a plugin-b")
        self.line("  clovers plugin <comment>remove</comment> plugin-a")
        self.line("  clovers plugin <comment>update</comment> plugin-a")
        self.line("  clovers plugin <comment>update</comment>")
        self.line("")
        installed = self.clovers_plugins()
        if installed:
            self.line("Currently installed plugins:")
            for plugin in installed:
                self.line(f"  - {plugin}")
        else:
            self.line("No plugins installed.")
        return 0

    def group_plugins_sync(self):
        try:
            from clovers.config import Config as CloversConfig
        except ImportError:
            return
        clovers_config = CloversConfig.environ()
        plugins: list[str] = clovers_config.setdefault("clovers", {}).setdefault("plugins", [])
        if plugins:
            self.call(f"add", f"args {' '.join(plugins)} --group clovers-plugins")

    def clovers_plugins(self) -> AbstractSet[str]:
        dependencies = dict_path(self.poetry.pyproject.data, ("tool", "poetry", "group", "clovers-plugins", "dependencies"))
        return dependencies.keys() if dependencies else set[str]()

    def handle_add(self) -> int:
        name_arg = self.argument("name")
        if not name_arg:
            self.line("Please specify the plugin name.", style="error")
            return -1
        name = " ".join(name_arg)
        old_plugins = self.clovers_plugins()
        return_code = self.call(f"add", f"args {name} --group clovers-plugins")
        if return_code != 0:
            return return_code
        self.poetry.pyproject.reload()
        new_plugins = self.clovers_plugins()
        added_plugins = new_plugins - old_plugins
        if not added_plugins:
            self.line("No new plugins added.", style="error")
            return -1
        from clovers.config import Config as CloversConfig

        clovers_config = CloversConfig.environ()
        plugins: list[str] = clovers_config.setdefault("clovers", {}).setdefault("plugins", [])
        plugins.extend(plugin for plugin in added_plugins if plugin not in plugins)
        clovers_config.save()
        return 0

    def handle_remove(self) -> int:
        name_arg = self.argument("name")
        if not name_arg:
            self.line("Please specify the plugin name.", style="error")
            return -1
        name = " ".join(name_arg)
        old_plugins = self.clovers_plugins()
        return_code = self.call(f"remove", f"args {name}")
        if return_code != 0:
            return return_code
        self.poetry.pyproject.reload()
        new_plugins = self.clovers_plugins()
        removed_plugins = old_plugins - new_plugins
        from clovers.config import Config as CloversConfig

        clovers_config = CloversConfig.environ()
        plugins: list[str] = clovers_config.setdefault("clovers", {}).get("plugins", [])
        clovers_config["clovers"]["plugins"] = [plugin for plugin in plugins if plugin not in removed_plugins]
        clovers_config.save()
        return 0

    def handle_update(self) -> int:
        name_arg = self.argument("name")
        name = " ".join(name_arg) if name_arg else None
        return self.call("update", name)
