if __name__ == "__main__":
    import sys
    from importlib.metadata import distribution

    try:
        dist = distribution("clovers-client")
        METADATA = dist.read_text("METADATA")
        print(METADATA)
    except Exception as e:
        print(e, file=sys.stderr)
