from pathlib import Path
from poetry.pyproject.toml import PyProjectTOML
from .base import CloversBaseCommand, dict_path
from .run import RunCommand
from .plugin import PluginCommand
from .create import CreateCommand
from .new import NewCommand


ALL: list[type[CloversBaseCommand]] = [RunCommand, PluginCommand, CreateCommand, NewCommand]
WELCOME_BANNER = r"""
 ____    ___                                           ____     __     ______     
/\  _ `\/\_ \                                         /\  _ `\ /\ \   /\__  _\    
\ \ \/\_\//\ \     ___   __    __  __   _ __   ____   \ \ \/\_\\ \ \  \/_/\ \/    
 \ \ \/_/_\ \ \   / __`\/\ \  / // __`\/\` __\/` __\   \ \ \/_/_\ \ \  __\ \ \    
  \ \ \_\ \\_\ \_/\ \_\ \ \ \/ //\  __/\ \ \//\__, `\   \ \ \_\ \\ \ \_\ \\_\ \__ 
   \ \____//\____\ \____/\ \__/ \ \____\\ \_\\/\____/    \ \____/ \ \____//\_____\
    \/___/ \/____/\/___/  \/_/   \/____/ \/_/ \/___/      \/___/   \/___/ \/_____/"""
WELCOME_BANNER = WELCOME_BANNER[1:]


class MainCommand(CloversBaseCommand):
    name = "clovers"
    description = "Manage your Clovers project and plugins seamlessly."

    def exec(self) -> int:
        self.line(WELCOME_BANNER, style="clovers")
        name = dict_path(PyProjectTOML(Path("pyproject.toml")).data, ["project", "name"])
        if name:
            try:
                import clovers

                self.line(f"\nProject: <comment>{name}</comment> (<info>clovers v{clovers.__version__}</info>)")
            except ImportError:  # noqa: B902
                pass
        self.line("\nClovers CLI (<info>version 0.0.5</info>)")
        self.line("\nUsage:")
        self.line("  clovers <comment><command></comment> [options] [arguments]")
        self.line("\nAvailable commands:")
        max_length = max([len(command.name) for command in ALL])
        for command in ALL:
            self.line(f"  <comment>{command.name}</comment>{" "*((max_length+4)-len(command.name))}{command.description}")
        return 0
