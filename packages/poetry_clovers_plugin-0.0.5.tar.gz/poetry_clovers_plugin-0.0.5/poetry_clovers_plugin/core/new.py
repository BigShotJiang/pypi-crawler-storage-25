import sys
import subprocess
from pathlib import Path
from cleo.helpers import argument, option
from poetry.pyproject.toml import PyProjectTOML
from .base import CloversBaseCommand
from .template import TEMPLATE_PLUGIN_DIR, TEMPLATE_ADAPTER_DIR

TEMPLATE_DIRS = {
    "plugin": TEMPLATE_PLUGIN_DIR,
    "adapter": TEMPLATE_ADAPTER_DIR,
}


class NewCommand(CloversBaseCommand):
    name = "clovers new"
    description = "Create a clovers [plugin,adapter] project"
    arguments = [
        argument("type", optional=True, description="Type of template, can be one of [plugin,adapter] or not"),
        argument("name", optional=True, description="Your project name"),
    ]
    options = [
        option("namespace", None, "create a namespace package project", flag=False),
        option("flat", None, "use flat layout"),
    ]

    @staticmethod
    def name_arg(name: str) -> str:
        name = name.replace("_", "-")
        if not name.startswith("clovers-"):
            name = f"clovers-{name}"
        return name

    def introduce(self) -> int:
        self.line("<clovers>Create a clovers project</clovers>")
        self.line("\nUsage: clovers new [type] [name]")
        self.line("\nArguments:")
        self.line("  <comment>type</comment>      Type of template, can be one of [plugin, adapter]")
        self.line("  <comment>name</comment>      Your project name")
        self.line("\nOptions:")
        self.line("  <comment>--namespace</comment> <ns>   Create a namespace package project")
        self.line("  <comment>--flat</comment>             Use flat layout")
        self.line("\nExamples:")
        self.line("  clovers new plugin my-plugin")
        self.line("  clovers new adapter my-adapter")
        self.line("  clovers new plugin my-plugin --flat")
        self.line("")
        self.line("If no arguments are provided, this help message is shown.")
        return 0

    def exec(self) -> int:
        template_type: str = self.argument("type")
        name = self.argument("name")
        if not template_type and not name:
            return self.introduce()
        if template_type not in TEMPLATE_DIRS:
            self.line(f"Invalid template type: {template_type}", style="error")
            return -1
        if not name:
            self.line(f"Please provide a name for your {template_type}.", style="error")
            return -1
        name = self.name_arg(name)
        path = Path(name)
        src = Path()
        args = f"args {name} --python >=3.12,<4.0.0"
        if namespace := self.option("namespace"):
            args += f" --name {namespace}"
            src = src / namespace.replace(".", "/").replace("-", "_")
        else:
            src = src / name.replace("-", "_")
        if self.option("flat"):
            args = "--flat " + args
        else:
            src = "src" / src
        src = path / src
        return_code = self.call(f"new", args)
        if return_code != 0:
            return return_code
        pyproject = PyProjectTOML(path / "pyproject.toml")
        pyproject.data.setdefault("project", {})["name"] = name
        pyproject.save()
        self.line(f"Adding dependencies to the {name}...", style="info")
        try:
            subprocess.run((sys.executable, "-m", "poetry", "add", "clovers>=0.5.0,<0.6.0", "clovers-client"), cwd=path, check=True)
        except subprocess.CalledProcessError as e:
            self.line(f"Return code: {e.returncode}", "error")
            self.line(f"Error Output:\n{e.stderr}", "error")
            return 1
        import shutil

        try:
            shutil.copytree(TEMPLATE_DIRS[template_type], src, dirs_exist_ok=True)
        except Exception as e:
            self.line(f"copy template failed: {e}", "error")
            return 1
        return 0
