<div align="center">

<a href="https://clovers-project.github.io/"><img src="https://raw.githubusercontent.com/KarisAya/clovers/refs/heads/master/attachment/icon.svg" width="180" height="180" alt="clovers"></a>

# poetry-clovers-plugin

_✨ 官方 Clovers 机器人客户端 ✨_

[![Python](https://img.shields.io/badge/Python-3.12+-blue.svg)](https://www.python.org/)
[![pypi](https://img.shields.io/pypi/v/poetry-clovers-plugin.svg)](https://pypi.python.org/pypi/poetry-clovers-plugin)
[![pypi download](https://img.shields.io/pypi/dm/poetry-clovers-plugin)](https://pypi.python.org/pypi/poetry-clovers-plugin)
[![Poetry](https://img.shields.io/endpoint?url=https://python-poetry.org/badge/v0.json)](https://python-poetry.org/)
[![Github](https://img.shields.io/badge/GitHub-Clovers-00CC33?logo=github)](https://github.com/clovers-project/clovers)
[![LICENSE](https://img.shields.io/github/license/clovers-project/poetry-clovers-plugin.svg)](./LICENSE)

[使用文档](https://clovers-project.github.io/#/clovers-cli)

</div>

# 联系

如有建议，bug 反馈等可以加群

机器人 bug 研究中心（闲聊群） 744751179

永恒之城（测试群） 724024810

![群号](https://raw.githubusercontent.com/KarisAya/clovers/refs/heads/master/attachment/qrcode.svg)
