"""Command handlers for cel."""

from __future__ import annotations

import getpass
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, TextIO

from .config import CliConfig
from .binding_resolver import BindingResolutionError, resolve_binding
from .identity_store import IdentityStore
from .internal_hooks import (
    clear_hook_error_context,
    format_hook_error_context,
    hook_event_name,
    hook_output,
    read_hook_payload,
    should_emit_hook_error_context,
    stop_block_output,
)
from .daemon.inbox_context import read_inbox_context
from .daemon.wake import record_rewake
from .providers.launcher import (
    build_provider_launch,
    is_provider_status_request,
    provider_status,
)
from .target_resolver import (
    MessageTarget,
    message_mentions,
    parse_message_target,
    resolve_message_target,
    resolve_user_refs,
    resolved_target,
)


@dataclass(frozen=True)
class HandlerContext:
    args: Any
    client: Any
    config: CliConfig
    stdin: TextIO
    stdout: TextIO


CommandHandler = Callable[[HandlerContext], Any]


@dataclass(frozen=True)
class RawOutput:
    text: str
    return_code: int = 0


@dataclass(frozen=True)
class ProcessRequest:
    command: list[str]
    env: dict[str, str]


def _resolve_login_password(args: Any, stdin: TextIO) -> str:
    if args.password_stdin:
        password = stdin.readline().rstrip("\r\n")
        if not password:
            raise RuntimeError("stdin password is required")
        return password
    return getpass.getpass("Password: ")


def _current_binding(provider: str | None) -> dict[str, Any]:
    return resolve_binding(
        store=IdentityStore.from_env(),
        cwd=Path.cwd(),
        provider=provider,
        interactive=False,
    )


def _login(ctx: HandlerContext) -> Any:
    result = ctx.client.auth.login(
        ctx.args.identifier, _resolve_login_password(ctx.args, ctx.stdin)
    )
    if not isinstance(result, dict) or not result.get("token"):
        raise RuntimeError("login did not return a token")
    user = result.get("user") if isinstance(result.get("user"), dict) else {}
    local_id = str(user.get("id") or ctx.args.identifier)
    IdentityStore.from_env().save_user(
        local_id,
        base_url=ctx.config.base_url,
        auth_token=str(result["token"]),
    )
    public = dict(result)
    public["token"] = "<redacted>"
    return public


def _logout(ctx: HandlerContext) -> Any:
    store = IdentityStore.from_env()
    if ctx.args.all_local:
        store.clear_users()
        return {"current_user_id": None, "users": []}
    store.clear_current_user()
    return {"current_user_id": None}


def _agent_show(ctx: HandlerContext) -> Any:
    store = IdentityStore.from_env()
    binding = _current_binding(None)
    public_identity = store.public_identity(str(binding["local_id"]))
    current_user = ctx.client.me.whoami()
    if not isinstance(current_user, dict):
        raise RuntimeError("current identity did not resolve to a backend user")
    user_id = str(current_user.get("id") or "")
    display_name = str(current_user.get("name") or "")
    if not user_id:
        raise RuntimeError("current backend user is missing id")
    if not display_name:
        raise RuntimeError("current backend user is missing name")
    local_user_id = str(public_identity.get("user_id") or "")
    if local_user_id and local_user_id != user_id:
        raise RuntimeError(
            f"local identity {public_identity['local_id']} resolves to backend user {user_id}, "
            f"not {local_user_id}"
        )
    store.update_identity(
        str(binding["local_id"]),
        user_id=user_id,
        display_name=display_name,
    )
    public_identity["user_id"] = user_id
    public_identity["display_name"] = display_name
    if ctx.args.json:
        return public_identity
    return RawOutput(_format_current_agent_identity(public_identity))


def _format_current_agent_identity(identity: dict[str, Any]) -> str:
    lines = ["Current agent identity", ""]
    fields = [
        ("Local ID", identity.get("local_id")),
        ("Provider", identity.get("provider")),
        ("Name", identity.get("display_name")),
        ("User ID", identity.get("user_id")),
        ("Owner", identity.get("created_by_user_id")),
        ("Backend", identity.get("base_url")),
    ]
    for label, value in fields:
        if value:
            lines.append(f"{label}: {value}")
    lines.extend(["", "Use --json for machine-readable identity."])
    return "\n".join(lines) + "\n"


def _agent_external_create(ctx: HandlerContext) -> Any:
    created = ctx.client.users.create_external(
        user_id=ctx.args.local_id,
        display_name=ctx.args.name,
    )
    if not isinstance(created, dict) or not created.get("token"):
        raise RuntimeError("external agent identity creation did not return a token")
    external_user = created.get("user") if isinstance(created.get("user"), dict) else {}
    user_id = str(external_user.get("id") or ctx.args.local_id)
    store = IdentityStore.from_env()
    store.save_identity(
        local_id=ctx.args.local_id,
        provider=ctx.args.provider,
        base_url=ctx.config.base_url,
        auth_token=str(created["token"]),
        user_id=user_id,
        display_name=ctx.args.name,
        created_by_user_id=store.current_user_id(),
    )
    return {
        "user": external_user,
        "identity": store.public_identity(ctx.args.local_id),
    }


def _agent_external_list(ctx: HandlerContext) -> Any:
    rows = [
        _local_identity_inventory_row(identity)
        for identity in IdentityStore.from_env().public_identities()
    ]
    if ctx.args.json:
        return rows
    return RawOutput(_format_external_identity_list(rows))


def _agent_external_remove(ctx: HandlerContext) -> Any:
    removed = IdentityStore.from_env().remove_identity(ctx.args.local_id)
    if removed.get("auth_token"):
        removed["auth_token"] = "<redacted>"
    return _local_identity_inventory_row(removed)


def _agent_external_unbind(ctx: HandlerContext) -> Any:
    path = Path(ctx.args.path).expanduser() if ctx.args.path else Path.cwd()
    unbound = IdentityStore.from_env().unbind_cwd_identity(path, ctx.args.local_id)
    return {
        "local_id": ctx.args.local_id,
        "path": str(path.resolve()),
        "unbound": unbound,
    }


def _agent_external_cleanup(ctx: HandlerContext) -> Any:
    return IdentityStore.from_env().cleanup_local_identity_state()


def _local_identity_inventory_row(identity: dict[str, Any]) -> dict[str, Any]:
    row = dict(identity)
    local_display_name = row.pop("display_name", None)
    if local_display_name is not None:
        row["local_display_name"] = local_display_name
    return row


def _format_external_identity_list(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return (
            "Local agent identities: none\n\n"
            "Create one after owner login:\n"
            '  cel agent external create codex-a --name "Codex A" --provider codex\n'
            "\n"
            "Use --json for machine-readable local inventory.\n"
        )

    lines = ["Local agent identities"]
    for row in rows:
        local_id = str(row["local_id"])
        provider = str(row["provider"])
        lines.extend(
            [
                "",
                f"- {local_id}",
                f"  Provider: {provider}",
            ]
        )
        display_name = row.get("local_display_name")
        if display_name:
            lines.append(f"  Name: {display_name}")
        user_id = row.get("user_id")
        if user_id:
            lines.append(f"  User ID: {user_id}")
        owner = row.get("created_by_user_id")
        if owner:
            lines.append(f"  Owner: {owner}")
        base_url = row.get("base_url")
        if base_url:
            lines.append(f"  Backend: {base_url}")

    lines.extend(["", "Use --json for machine-readable local inventory."])
    return "\n".join(lines) + "\n"


def _send_message(ctx: HandlerContext) -> Any:
    store = IdentityStore.from_env()
    target = resolve_message_target(
        parse_message_target(ctx.args.target),
        store,
        owner_user_id=ctx.config.created_by_user_id,
    )
    chat_id = _send_chat_id(ctx.client, target)
    mentioned_user_ids = message_mentions(
        target,
        ctx.args.mentions,
        store=store,
        owner_user_id=ctx.config.created_by_user_id,
    )
    addressed_to_user_ids, addressed_local_ids = resolve_user_refs(
        ctx.args.addressed_to,
        store=store,
        owner_user_id=ctx.config.created_by_user_id,
    )
    send_kwargs = {
        "reply_to": ctx.args.reply_to,
        "mentions": mentioned_user_ids,
    }
    if ctx.args.addressed_to:
        send_kwargs["delivery_scope"] = "addressed"
        send_kwargs["addressed_to_user_ids"] = addressed_to_user_ids
    message = ctx.client.messages.send(
        chat_id,
        ctx.args.content,
        **send_kwargs,
    )
    return {
        "resolved": resolved_target(
            target,
            chat_id=chat_id,
            mentioned_user_ids=mentioned_user_ids,
            addressed_to_user_ids=(
                addressed_to_user_ids if ctx.args.addressed_to else None
            ),
            addressed_resolved_from_local_ids=addressed_local_ids,
        ),
        "message": message,
    }


def _read_message(ctx: HandlerContext) -> Any:
    target = resolve_message_target(
        parse_message_target(ctx.args.target, allow_chat_mention=False),
        IdentityStore.from_env(),
        owner_user_id=ctx.config.created_by_user_id,
    )
    chat_id = _read_chat_id(ctx.client, target)
    if ctx.args.last is not None:
        messages = ctx.client.messages.list(
            chat_id,
            limit=ctx.args.last,
            before=ctx.args.before,
        )
    else:
        messages = ctx.client.messages.read(chat_id)
    return {
        "resolved": resolved_target(target, chat_id=chat_id),
        "messages": messages,
    }


def _send_chat_id(client: Any, target: MessageTarget) -> str:
    if target.kind == "chat":
        return _require_id(target.chat_id, label="chat target")
    chat = client.chats.ensure_direct(_require_id(target.user_id, label="user target"))
    return _chat_id_from_payload(chat)


def _read_chat_id(client: Any, target: MessageTarget) -> str:
    if target.kind == "chat":
        return _require_id(target.chat_id, label="chat target")
    chat = client.chats.direct(_require_id(target.user_id, label="user target"))
    return _chat_id_from_payload(chat)


def _chat_id_from_payload(payload: Any) -> str:
    if not isinstance(payload, dict):
        raise RuntimeError("chat response missing id")
    chat_id = str(payload.get("id") or payload.get("chat_id") or "").strip()
    if not chat_id:
        raise RuntimeError("chat response missing id")
    return chat_id


def _require_id(value: str | None, *, label: str) -> str:
    value = str(value or "").strip()
    if not value:
        raise RuntimeError(f"{label} is empty")
    return value


def _relationships_list(ctx: HandlerContext) -> Any:
    return ctx.client.relationships.list()


def _relationships_request(ctx: HandlerContext) -> Any:
    return ctx.client.relationships.request(
        ctx.args.target_user_id,
        message=ctx.args.message,
    )


def _relationships_action(ctx: HandlerContext) -> Any:
    action = getattr(ctx.client.relationships, ctx.args.relationship_command)
    return action(ctx.args.relationship_id)


def _provider_launch(ctx: HandlerContext) -> Any:
    if is_provider_status_request(list(ctx.args.provider_args)):
        return provider_status(
            provider=ctx.args.command,
            cwd=Path.cwd(),
        )
    launch = build_provider_launch(
        provider=ctx.args.command,
        provider_args=list(ctx.args.provider_args),
        cwd=Path.cwd(),
        stdin=ctx.stdin,
        stdout=ctx.stdout,
    )
    return ProcessRequest(command=launch.command, env=launch.env)


def _internal_hook(ctx: HandlerContext) -> RawOutput:
    try:
        binding = _current_binding(ctx.args.provider)
    except BindingResolutionError:
        return RawOutput("")
    hook_payload = read_hook_payload(ctx.stdin)
    event_name = hook_event_name(hook_payload)
    include_continue = ctx.args.provider == "codex"
    if ctx.args.provider == "claude" and event_name == "Stop":
        if hook_payload.get("stop_hook_active") is True:
            return RawOutput("")
        if ctx.args.rewake:
            context = _hook_context_from_cache(str(binding["local_id"]))
            if context:
                record_rewake(str(binding["local_id"]))
            return RawOutput(context, return_code=2 if context else 0)
        context = _hook_context_from_cache(str(binding["local_id"]))
        return RawOutput(stop_block_output(context))
    try:
        context = _hook_context_from_cache(str(binding["local_id"]))
        clear_hook_error_context()
    except RuntimeError as exc:
        if should_emit_hook_error_context(exc, local_id=str(binding["local_id"])):
            context = format_hook_error_context(exc, local_id=str(binding["local_id"]))
        else:
            context = ""
    return RawOutput(
        hook_output(event_name, context, include_continue=include_continue)
    )


def _hook_context_from_cache(local_id: str) -> str:
    return read_inbox_context(local_id)


def handle_command(
    *,
    args: Any,
    handler: CommandHandler,
    client: Any,
    config: CliConfig,
    stdin: TextIO,
    stdout: TextIO,
) -> Any:
    return handler(
        HandlerContext(
            args=args,
            client=client,
            config=config,
            stdin=stdin,
            stdout=stdout,
        )
    )
