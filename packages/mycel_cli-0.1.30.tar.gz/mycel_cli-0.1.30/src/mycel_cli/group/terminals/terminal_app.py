"""macOS Terminal.app backend for mycel_cli.group.

Requires Accessibility permission:
    System Settings → Privacy & Security → Accessibility
    (grant permission to the terminal running cel)

Uses CGEventPostToPid for background text injection without focus steal.
Requires pyobjc-framework-Quartz (installed automatically on first use).

Group-container model
-----------------------
Terminal.app has no split-pane API. A group = one Terminal.app **window**
identified by its numeric id. Each role+instance is its own tab inside
that window:

  * supervisor+0 = window's first tab, titled ``supervisor``.
  * reviewer+0   = new tab in same window, titled ``reviewer``.
  * worker+N     = new tab in same window, titled ``worker-{N+1}``.

target_id for tabs is the **window** id string, while tab selection is implicit
on AppleScript (each new tab becomes selected
within the window).

Note: because every tab shares the same window id as target_id, ``send_text``
unavoidably targets whichever tab is selected in the window at injection
time; we set ``frontmost`` on the window to surface it before keystrokes —
AppleScript does not let you target a specific tab from outside.
"""

from __future__ import annotations
import base64
import subprocess
import sys
import time
import shlex


def _ensure_quartz():
    """Import Quartz, installing into the current Python env if necessary."""
    try:
        import Quartz

        return Quartz
    except ImportError:
        subprocess.run(
            [
                "uv",
                "pip",
                "install",
                "--python",
                sys.executable,
                "pyobjc-framework-Quartz",
            ],
            check=True,
        )
        import Quartz

        return Quartz


def _terminal_pid() -> int:
    result = subprocess.check_output(["pgrep", "-x", "Terminal"], text=True)
    return int(result.strip().split("\n")[0])


def _inject_text(pid: int, window_id: str, text: str) -> None:
    """Inject text into a specific Terminal.app window via CGEventPostToPid."""
    Quartz = _ensure_quartz()
    # Bring target window to front within Terminal.app (no app focus steal)
    script = f'tell application "Terminal" to set frontmost of (first window whose id is {window_id}) to true'
    subprocess.run(["osascript", "-e", script], capture_output=True)
    time.sleep(0.2)
    for char in text:
        kd = Quartz.CGEventCreateKeyboardEvent(None, 0, True)
        ku = Quartz.CGEventCreateKeyboardEvent(None, 0, False)
        Quartz.CGEventKeyboardSetUnicodeString(kd, len(char), char)
        Quartz.CGEventKeyboardSetUnicodeString(ku, len(char), char)
        Quartz.CGEventPostToPid(pid, kd)
        Quartz.CGEventPostToPid(pid, ku)
        time.sleep(0.015)


def _send_return(pid: int) -> None:
    """Send Return key (key code 36) via CGEvent."""
    Quartz = _ensure_quartz()
    kd = Quartz.CGEventCreateKeyboardEvent(None, 36, True)
    ku = Quartz.CGEventCreateKeyboardEvent(None, 36, False)
    Quartz.CGEventPostToPid(pid, kd)
    Quartz.CGEventPostToPid(pid, ku)


def _osascript(script: str) -> str:
    try:
        return subprocess.check_output(
            ["osascript", "-e", script],
            text=True,
            timeout=10,
        ).strip()
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("Terminal.app AppleScript timed out") from exc


def _apple_script_escape(text: str) -> str:
    return (
        text.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\r", "\\r")
        .replace("\n", "\\n")
    )


def _terminal_launch_cmd(cwd: str, cmd: str) -> str:
    full_cmd = f"cd {shlex.quote(cwd)} && {cmd}"
    encoded = base64.b64encode(full_cmd.encode("utf-8")).decode("ascii")
    # Avoid embedding raw shell payload in AppleScript source; the script only
    # contains base64-safe text and decodes it in the shell.
    return f"printf %s {shlex.quote(encoded)} | base64 -D | bash"


def _find_window_by_title(title: str) -> str | None:
    """Return the window id (as string) whose custom title matches, or None."""
    escaped_title = _apple_script_escape(title)
    script = f'''
tell application "Terminal"
    set out to ""
    repeat with w in windows
        try
            if (custom title of w) is "{escaped_title}" then
                set out to (id of w as string)
                exit repeat
            end if
        end try
    end repeat
    return out
end tell
'''
    out = _osascript(script).strip()
    return out or None


def _window_id_expr(window_id: str) -> str:
    if not str(window_id).isdigit():
        raise ValueError(f"Terminal.app window id must be numeric, got {window_id!r}")
    return str(window_id)


class TerminalAppTerminal:
    def ensure_group_container(self, group_id: str) -> str:
        """Create (or return) the Terminal.app window for this group.

        The container ref is the numeric window id as a string; we match
        existing windows by the ``cel-{group_id}`` custom title.
        """
        title = f"cel-{group_id}"
        existing = _find_window_by_title(title)
        if existing:
            return existing
        escaped_title = _apple_script_escape(title)

        script = f'''
tell application "Terminal"
    do script ""
    delay 0.3
    set w to front window
    set custom title of w to "{escaped_title}"
    return id of w as string
end tell
'''
        return _osascript(script).strip()

    def spawn_in_container(
        self,
        container_ref: str,
        role: str,
        role_index: int,
        cwd: str,
        cmd: str,
    ) -> str:
        """Open a tab in the group window (or reuse the first one for supervisor)
        and run ``cmd`` inside it. Returns the window id as target_id."""
        launch_cmd = _apple_script_escape(_terminal_launch_cmd(cwd, cmd))
        tab_title = _apple_script_escape(_tab_title(role, role_index))
        window_id = _window_id_expr(container_ref)

        if role == "supervisor" and role_index == 0:
            # Reuse the first tab (created by ensure_group_container).
            script = f'''
tell application "Terminal"
    set w to first window whose id is {window_id}
    set t to selected tab of w
    set custom title of t to "{tab_title}"
    do script "{launch_cmd}" in t
    return id of w as string
end tell
'''
        else:
            # Open a new tab in the same window. AppleScript's "do script"
            # with no `in <tab>` target creates a NEW tab in the frontmost
            # window, so we first make our window frontmost.
            script = f'''
tell application "Terminal"
    set w to first window whose id is {window_id}
    set frontmost of w to true
    delay 0.2
    tell application "System Events" to keystroke "t" using command down
    delay 0.3
    set t to selected tab of w
    set custom title of t to "{tab_title}"
    do script "{launch_cmd}" in t
    return id of w as string
end tell
'''
        return _osascript(script).strip()

    def close_group_container(self, container_ref: str) -> None:
        """Close the group window (and every tab inside)."""
        window_id = _window_id_expr(container_ref)
        script = f"""
tell application "Terminal"
    try
        close (first window whose id is {window_id}) saving no
    end try
end tell
"""
        subprocess.run(["osascript", "-e", script], capture_output=True)

    def send_text(self, target_id: str, text: str) -> None:
        """Send body then Return to Terminal.app without focus steal.

        CRITICAL: do NOT shorten the sleep. See cel/terminals/iterm2.py
        send_text() for the full root-cause writeup. Summary:

          Claude Code's TUI enables bracketed paste mode. Even with
          CGEvent-based per-character injection, back-to-back CGEvents
          can be coalesced by the input system into a single paste
          burst. If that burst ends with Return, Return lands inside
          the bracketed-paste envelope and is treated as a multi-line
          newline, NOT submit — the message stays stuck in the input
          buffer.

          Sleeping ~2s between the last character event and the Return
          keystroke lets the TUI close the paste envelope before Return
          arrives, so Return is interpreted as Enter. Matches
          cmux/kitty/tmux/iterm2.
        """
        pid = _terminal_pid()
        _inject_text(pid, target_id, text)
        time.sleep(2)
        _send_return(pid)

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key to Terminal.app window."""
        Quartz = _ensure_quartz()
        pid = _terminal_pid()
        # Key code map for macOS
        key_codes = {"escape": 53, "enter": 36, "ctrl-c": None}
        if key == "ctrl-c":
            # Send Ctrl+C via CGEvent with control modifier
            ev = Quartz.CGEventCreateKeyboardEvent(None, 8, True)  # 'c' key
            Quartz.CGEventSetFlags(ev, Quartz.kCGEventFlagMaskControl)
            Quartz.CGEventPostToPid(pid, ev)
            ev2 = Quartz.CGEventCreateKeyboardEvent(None, 8, False)
            Quartz.CGEventPostToPid(pid, ev2)
        else:
            code = key_codes.get(key, 36)
            kd = Quartz.CGEventCreateKeyboardEvent(None, code, True)
            ku = Quartz.CGEventCreateKeyboardEvent(None, code, False)
            Quartz.CGEventPostToPid(pid, kd)
            Quartz.CGEventPostToPid(pid, ku)

    def read_screen(self, target_id: str) -> str:
        script = f'tell application "Terminal" to contents of tab 1 of (first window whose id is {target_id})'
        return subprocess.check_output(["osascript", "-e", script], text=True)

    def close(self, target_id: str) -> None:
        # Step 1: get tty of the window so we can kill all processes without a dialog
        tty_script = f'tell application "Terminal" to tty of selected tab of (first window whose id is {target_id})'
        r = subprocess.run(
            ["osascript", "-e", tty_script], capture_output=True, text=True
        )
        tty = r.stdout.strip()
        if tty:
            # Kill all processes on the tty (avoids "Terminate running processes?" dialog)
            pids = subprocess.run(
                ["lsof", "-t", tty], capture_output=True, text=True
            ).stdout.split()
            for pid in pids:
                subprocess.run(["kill", "-9", pid], capture_output=True)
            time.sleep(0.5)
        # Step 2: close the now-empty window
        close_script = f'tell application "Terminal" to close (first window whose id is {target_id}) saving no'
        subprocess.run(["osascript", "-e", close_script], capture_output=True)

    def resolve_target_id(self, pid: int, *, local_id: str | None = None) -> str | None:
        # Terminal.app window id is assigned at spawn and stored in cache; no live discovery.
        return None


def _tab_title(role: str, role_index: int) -> str:
    if role == "supervisor" and role_index == 0:
        return "supervisor"
    if role == "reviewer" and role_index == 0:
        return "reviewer"
    if role == "worker":
        return f"worker-{role_index + 1}"
    raise ValueError(
        f"Terminal.app: unsupported role/index combo: {role!r}+{role_index}"
    )
