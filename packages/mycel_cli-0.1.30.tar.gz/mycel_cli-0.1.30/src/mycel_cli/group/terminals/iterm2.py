"""iTerm2 terminal backend for cel (Python API).

Uses the official iTerm2 Python API. AppleScript cannot force-close sessions
with a running process; it pops a "Terminate running processes?" dialog that
nobody clicks.

Two hard requirements for this backend to work at runtime:

1. iTerm2 Python API enabled. Open iTerm2 → Settings → General → Magic →
   Enable Python API. Or via defaults:

       defaults write com.googlecode.iterm2 EnableAPIServer -bool true

   then restart iTerm2.

2. Dependencies installed:

       uv add iterm2 pyobjc-framework-Cocoa

Group-container model
-----------------------
A group maps to **one iTerm2 Window**. The container ref is the window's
``window_id`` (a stable iTerm2-assigned string like ``pty-UUID``). Lookup is
via ``app.get_window_by_id(ref)``. The window is also titled ``cel-{group_id}``
for human display, but the title is NOT used as an identifier (iTerm2's
``async_set_title`` sets a display-only variable that is NOT readable via
``async_get_variable("title")``).

Layout inside the window:

  * supervisor+0 = the window's first tab's session, titled ``supervisor``.
  * reviewer+0   = right-split of the supervisor session, titled ``reviewer``.
  * worker+0     = bottom-split of the supervisor session, titled ``worker-1``.
  * worker+N>=1  = a new tab in the same window, titled ``worker-{N+1}``.

The per-session ``session_id`` (UUID string) is the target_id for subsequent
``send_text`` / ``close`` calls.

Design notes:
  * The iTerm2 Python API is async-only. Each sync Terminal method wraps a
    private ``_async_impl`` coroutine via ``asyncio.run``. One connection is
    established per call — cheap and avoids holding a long-lived websocket.
  * ``Window.async_create(connection, command=...)`` spawns the window with
    the command baked into argv, so there is zero typing race (unlike
    Terminal.app's ``do script`` which simulates keystrokes).
  * ``Session.async_close(force=True)`` closes even with a running process —
    no dialog.
  * Lazy imports: ``iterm2`` is imported inside functions so importing this
    module on a machine without the deps doesn't blow up; the
    ``RuntimeError`` is raised at first use with an install hint.
  * We do NOT auto-launch iTerm2. If it isn't running, surface a clear error
    (consistent with the kitty/cmux backends, which also fail loudly rather
    than implicitly launch their host).
  * We pass a fixed ``myname="cel"`` to iTerm2's auth layer so both the CLI
    and the daemon process share one Permissions-dialog authorization
    (iTerm2 keys its per-script permission by the ``myname`` string).
"""

from __future__ import annotations

import asyncio
import shlex


_KEY_MAP = {"escape": "\x1b", "enter": "\r", "ctrl-c": "\x03"}

# Fixed name so CLI invocations and the daemon share one iTerm2 Permissions
# authorization. Changing this string forces every user to re-approve the
# "Allow script to control iTerm2?" dialog.
_MYNAME = "cel"


def _container_title(group_id: str) -> str:
    return f"cel-{group_id}"


def _import_iterm2():
    """Lazy import of the iterm2 package. Raises RuntimeError with install hint."""
    try:
        import iterm2  # type: ignore

        return iterm2
    except ImportError as e:
        raise RuntimeError(
            "iterm2 package not installed. Run: uv add iterm2 pyobjc-framework-Cocoa"
        ) from e


async def _connect(iterm2_mod):
    """Open a Connection to iTerm2.

    Raises a friendly ``RuntimeError`` for the two common failure modes:

      * ``ConnectionRefusedError`` — iTerm2 isn't running, or its Python API
        server is not listening. We do NOT try to launch iTerm2.
      * ``AuthenticationException`` — the user has not enabled the Python API
        in Settings.

    All other exceptions bubble up unchanged (do not swallow).
    """
    # Pass myname via the auth layer so both the CLI and the daemon share one
    # iTerm2 Permissions authorization. authenticate() is idempotent — if a
    # cookie is already present in the environment it returns False and is
    # effectively a no-op.
    try:
        iterm2_mod.auth.authenticate(launch_if_needed=False, myname=_MYNAME)
    except iterm2_mod.auth.AuthenticationException as e:
        raise RuntimeError(
            "iTerm2 Python API authentication failed. Open iTerm2 → Settings "
            "→ General → Magic → Enable Python API. Or run: "
            "defaults write com.googlecode.iterm2 EnableAPIServer -bool true; "
            "then quit and restart iTerm2."
        ) from e

    # `iterm2.app.App` is a module-level singleton: the first call to
    # `async_get_app(connection)` caches the App bound to that connection.
    # We use a fresh `asyncio.run` per call (short connection lifetime), so
    # the next call would reuse the cached App with a now-closed websocket
    # and `App.async_refresh()` raises `ConnectionClosedError`. Reset the
    # singleton before each connect so the next `async_get_app` rebuilds it.
    iterm2_mod.app.App.instance = None

    try:
        return await iterm2_mod.Connection.async_create()
    except ConnectionRefusedError as e:
        raise RuntimeError(
            "iTerm2 Python API server is not reachable. Is iTerm2 running "
            "and the Python API enabled? (iTerm2 → Settings → General → "
            "Magic → Enable Python API)"
        ) from e
    except Exception as e:  # noqa: BLE001 — map the specific auth error; re-raise the rest
        if type(e).__name__ == "AuthenticationException":
            raise RuntimeError(
                "iTerm2 Python API not enabled. Open iTerm2 → Settings → "
                "General → Magic → Enable Python API. Or run: "
                "defaults write com.googlecode.iterm2 EnableAPIServer -bool true; "
                "then quit and restart iTerm2."
            ) from e
        raise


def _get_session_or_raise(app, target_id: str):
    s = app.get_session_by_id(target_id)
    if s is None:
        raise RuntimeError(f"iTerm2 session not found: {target_id!r}")
    return s


def _find_window_by_id(app, window_id: str):
    """Return the iTerm2 Window matching ``window_id`` or None."""
    return app.get_window_by_id(window_id)


class ITerm2Terminal:
    def ensure_group_container(self, group_id: str) -> str:
        """Create the iTerm2 window for this group, return its window_id.

        The container ref is ``window.window_id`` (stable iTerm2-assigned
        id). Caller stores this in group state and passes it to subsequent
        ``spawn_in_container`` / ``close_group_container`` calls. If the
        window was already created (e.g. restart), caller should have the
        ref in state and can look it up via ``app.get_window_by_id``.
        """
        iterm2 = _import_iterm2()
        title = _container_title(group_id)

        async def _impl() -> str:
            connection = await _connect(iterm2)
            window = await iterm2.Window.async_create(connection)
            if window is None:
                raise RuntimeError(
                    "iTerm2 Window.async_create returned None (window creation failed)"
                )
            await window.async_set_title(title)
            return window.window_id

        return asyncio.run(_impl())

    def spawn_in_container(
        self,
        container_ref: str,
        role: str,
        role_index: int,
        cwd: str,
        cmd: str,
    ) -> str:
        """Spawn a user surface inside the group's iTerm2 window.

        See module docstring for the role→location mapping.
        """
        iterm2 = _import_iterm2()

        # We feed the command to whichever session we place by typing it
        # via async_send_text. We do NOT use `Window.async_create(command=…)`
        # for the initial session because the window was created empty in
        # ensure_group_container; reusing it avoids spawning a second window.
        payload = f"cd {shlex.quote(cwd)} && {cmd}"

        async def _impl() -> str:
            connection = await _connect(iterm2)
            app = await iterm2.async_get_app(connection)
            window = _find_window_by_id(app, container_ref)
            if window is None:
                raise RuntimeError(
                    f"iTerm2 group container window not found: {container_ref!r}"
                )

            session = await _place_session(iterm2, window, role, role_index)
            await session.async_send_text(payload + "\n")
            return session.session_id

        return asyncio.run(_impl())

    def close_group_container(self, container_ref: str) -> None:
        """Close the group window (all sessions inside)."""
        iterm2 = _import_iterm2()

        async def _impl() -> None:
            connection = await _connect(iterm2)
            app = await iterm2.async_get_app(connection)
            window = _find_window_by_id(app, container_ref)
            if window is None:
                return
            await window.async_close(force=True)

        asyncio.run(_impl())

    def send_text(self, target_id: str, text: str) -> None:
        """Send text + Enter to the iTerm2 session."""
        iterm2 = _import_iterm2()

        async def _impl() -> None:
            connection = await _connect(iterm2)
            app = await iterm2.async_get_app(connection)
            session = _get_session_or_raise(app, target_id)
            # CRITICAL: do NOT collapse these two calls into one
            # `async_send_text(text + "\r")`, and do NOT shorten the sleep.
            #
            # Root cause (empirically reproduced on macOS 15, iTerm2 3.5,
            # Claude Code TUI v2.1):
            #   1. Claude Code's TUI (Ink) enables bracketed paste mode on
            #      startup — it tells the terminal "wrap pasted content in
            #      \e[200~ ... \e[201~ so I can tell pastes from typing".
            #   2. When iTerm2 receives an `async_send_text` payload while
            #      bracketed paste mode is active, iTerm2 itself wraps the
            #      payload in the \e[200~ ... \e[201~ envelope before
            #      feeding it to the PTY (it behaves like a real paste,
            #      matching the "Send text as though the user had typed it"
            #      doc).
            #   3. Inside a bracketed-paste envelope, the Ink input widget
            #      treats BOTH "\n" AND "\r" as multi-line newlines — NOT
            #      as submit. The message stays stuck in the input buffer,
            #      and you visibly see an extra blank line at the end.
            #   4. Further, iTerm2 coalesces API writes that arrive
            #      back-to-back on the same PTY into a single paste
            #      envelope. So `send_text(text)` immediately followed by
            #      `send_text("\r")` produces ONE envelope with the CR
            #      inside — still stuck.
            #
            # The fix has two parts and both are required:
            #   (a) Split body and CR into two `async_send_text` calls so
            #       they CAN be separate paste envelopes.
            #   (b) Sleep long enough between them that the TUI has
            #       processed the first envelope's \e[201~ (paste end)
            #       before the CR arrives. Once the TUI is back in
            #       typing mode, the lone "\r" is interpreted as submit.
            #
            # Why 2 seconds and not less:
            #   - 1s was empirically verified to work on a fast local mac,
            #     but the TUI's paste-end processing time depends on the
            #     payload size, the Claude process's load, and system I/O.
            #     A 2s margin absorbs worst-case jitter (large group
            #     prompts, Claude mid-thinking, macOS scheduling hiccups).
            #   - The cost is 2s of latency per Supervisor/Reviewer event,
            #     which is fine for our event cadence. Correctness >> speed.
            #
            # Why other backends don't need this:
            #   - tmux uses `send-keys text Enter`; tmux sends Enter as a
            #     raw keystroke OUTSIDE any paste envelope.
            #   - kitty's `send-text` on short content does not trigger
            #     bracketed paste wrapping.
            #   - cmux already has a 2s sleep + separate send_key(Enter).
            #
            # DO NOT "optimize" this. Removing the sleep or joining the
            # sends will silently regress the entire group→reviewer
            # and group→supervisor event loop.
            await session.async_send_text(text)
            await asyncio.sleep(2)
            await session.async_send_text("\r")

        asyncio.run(_impl())

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named control key. Raises ValueError for unsupported keys."""
        if key not in _KEY_MAP:
            raise ValueError(
                f"iTerm2: unsupported key {key!r}; valid: {sorted(_KEY_MAP)}"
            )
        char = _KEY_MAP[key]
        iterm2 = _import_iterm2()

        async def _impl() -> None:
            connection = await _connect(iterm2)
            app = await iterm2.async_get_app(connection)
            session = _get_session_or_raise(app, target_id)
            # Control chars go raw — no trailing newline.
            await session.async_send_text(char)

        asyncio.run(_impl())

    def read_screen(self, target_id: str) -> str:
        """Return current visible screen contents of the session."""
        iterm2 = _import_iterm2()

        async def _impl() -> str:
            connection = await _connect(iterm2)
            app = await iterm2.async_get_app(connection)
            session = _get_session_or_raise(app, target_id)
            contents = await session.async_get_screen_contents()
            lines = [contents.line(i).string for i in range(contents.number_of_lines)]
            return "\n".join(lines)

        return asyncio.run(_impl())

    def close(self, target_id: str) -> None:
        """Close the session, force-killing any running process (no dialog)."""
        iterm2 = _import_iterm2()

        async def _impl() -> None:
            connection = await _connect(iterm2)
            app = await iterm2.async_get_app(connection)
            session = _get_session_or_raise(app, target_id)
            await session.async_close(force=True)

        asyncio.run(_impl())

    def resolve_target_id(self, pid: int, *, local_id: str | None = None) -> str | None:
        # iTerm2 session_id is assigned at spawn and stored in cache; no live discovery.
        return None


async def _place_session(iterm2, window, role: str, role_index: int):
    """Return the iTerm2 Session for a given (role, role_index) inside ``window``.

    Creates splits / tabs as needed to realise the group layout described
    in the module docstring.
    """
    # First tab holds supervisor (left), reviewer (right-split), worker-1
    # (bottom-split of supervisor). Later workers live in their own new tab.
    first_tab = window.tabs[0] if window.tabs else window.current_tab
    sup_session = first_tab.sessions[0]

    if role == "supervisor" and role_index == 0:
        await sup_session.async_set_name("supervisor")
        return sup_session

    if role == "reviewer" and role_index == 0:
        # Right half split
        new_sessions = await sup_session.async_split_pane(vertical=True)
        new_session = (
            new_sessions[0] if isinstance(new_sessions, list) else new_sessions
        )
        await new_session.async_set_name("reviewer")
        return new_session

    if role == "worker" and role_index == 0:
        # Bottom half split
        new_sessions = await sup_session.async_split_pane(vertical=False)
        new_session = (
            new_sessions[0] if isinstance(new_sessions, list) else new_sessions
        )
        await new_session.async_set_name("worker-1")
        return new_session

    if role == "worker" and role_index >= 1:
        tab = await window.async_create_tab()
        if tab is None:
            raise RuntimeError("iTerm2 async_create_tab returned None")
        session = tab.sessions[0]
        title = f"worker-{role_index + 1}"
        await session.async_set_name(title)
        return session

    raise ValueError(f"iTerm2: unsupported role/index combo: {role!r}+{role_index}")
