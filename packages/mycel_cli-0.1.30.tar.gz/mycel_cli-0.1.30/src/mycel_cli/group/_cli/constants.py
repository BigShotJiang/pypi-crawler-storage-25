"""Static text and validation data for the CLI layer."""

from __future__ import annotations

import re


_HELP = "Mycel local service and group command families."

GROUP_HELP = """\b
Group orchestration

\b
Commands:
  create
  update
  remove
  list / ls
  show
  config
  start
  stop

start enables local event processing; stop halts it.

\b
First run rhythm:
  cel self start
  cel group create
  cel group update <group_id> <prompt>
  cel group <group_id> task create <subject>
  cel group <group_id> supervisor create
  cel group <group_id> reviewer create
  cel group start <group_id>
  cel group <group_id> worker create

\b
Group-scoped usage:
  cel group <group_id> task ...
  cel group <group_id> supervisor ...
  cel group <group_id> worker ...
  cel group <group_id> reviewer ...
  cel <group_id> task ...        # existing local groups only

\b
More help:
  cel group <group_id> task -h
  cel <group_id> task -h
  cel group <group_id> supervisor -h
  cel group <group_id> worker -h
  cel group <group_id> reviewer -h
"""

TASK_WORKFLOW_HELP = """\nWorkflow:\n  proposed -> pending -> in_progress -> completed\n  task create starts at proposed.\n  pending requires --rationale FILE for reviewer design review.\n  in_progress starts work after pending.\n  completed requires --rationale FILE for reviewer completion review.\n  reviewers decide with the same task update command.\n"""

GROUP_SCOPED_HELP = {
    "task": "Usage: cel group <group_id> task [OPTIONS] COMMAND [ARGS]...\nShortcut: cel <group_id> task [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n"
    + TASK_WORKFLOW_HELP,
    "supervisor": """Usage: cel group <group_id> supervisor [OPTIONS] COMMAND [ARGS]...\nShortcut: cel <group_id> supervisor [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n  send\n  read\n  inbox\n  mark-read\n  wake\n\nMessage files live under ${MYCEL_HOME:-$HOME/.mycel}/groups/<group_id>/messages/.\nWhen a group has a single worker, supervisor send/read/wake may omit worker_id.\n""",
    "worker": """Usage: cel group <group_id> worker [OPTIONS] COMMAND [ARGS]...\nShortcut: cel <group_id> worker [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n  read\n  inbox\n  mark-read\n  send\n""",
    "reviewer": """Usage: cel group <group_id> reviewer [OPTIONS] COMMAND [ARGS]...\nShortcut: cel <group_id> reviewer [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n""",
}

TASK_STATUS_ALLOWED = {
    "proposed",
    "pending",
    "in_progress",
    "completed",
    "deleted",
}

UUID_CANONICAL_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)
UUID_PREFIX_RE = re.compile(r"^[0-9a-fA-F-]{1,36}$")

CREATE_HELP = {
    "supervisor": """Usage: cel group <group_id> supervisor create [OPTIONS]\n\nOptions:\n  --agent TEXT\n  --name TEXT\n  --path TEXT\n  -h, --help

Identity is optional when this folder or the local store has exactly one matching identity; omit --agent in that case.
""",
    "worker": """Usage: cel group <group_id> worker create [OPTIONS]\n\nOptions:\n  --agent TEXT\n  --name TEXT\n  --path TEXT\n  --session TEXT\n  -h, --help

Identity is optional when this folder or the local store has exactly one matching identity; omit --agent in that case.
""",
    "reviewer": """Usage: cel group <group_id> reviewer create [OPTIONS]\n\nOptions:\n  --agent TEXT\n  --name TEXT\n  --prompt FILE      reviewer prompt file
                     Without --prompt, --name <name> reads reviewers/<name>.md.
  --path TEXT\n  -h, --help

Identity is optional when this folder or the local store has exactly one matching identity; omit --agent in that case.
""",
}

COMMAND_HELP = {
    "task": {
        "create": """Usage: cel group <group_id> task create <subject>\n""",
        "update": "Usage: cel group <group_id> task update --tasks CSV [--subject TEXT] [--description TEXT] [--status TEXT] [--owner TEXT] [--blocks CSV] [--blocked-by CSV] [--rationale FILE]\n"
        + TASK_WORKFLOW_HELP,
        "list": """Usage: cel group <group_id> task list [task_id|--tasks CSV] [--status TEXT]\n""",
        "show": """Usage: cel group <group_id> task show <task_id|--tasks CSV>\n""",
    },
    "supervisor": {
        "send": """Usage: cel group <group_id> supervisor send [worker_id] <file_path>\n\nSend one message file to a worker. Put new files in ${MYCEL_HOME:-$HOME/.mycel}/groups/<group_id>/messages/.\nIf there is a single worker, omit worker_id.\n""",
        "read": """Usage: cel group <group_id> supervisor read [worker_id]\n\nPeek at unread worker output. If there is a single worker, omit worker_id.\nUse mark-read after sweeping all relevant group views.\n""",
        "inbox": """Usage: cel group <group_id> supervisor inbox\n\nPeek at unread messages addressed to the supervisor outside worker-specific reads.\n""",
        "mark-read": """Usage: cel group <group_id> supervisor mark-read\n\nAdvance the supervisor's chat-wide read cursor after processing group messages.\n""",
        "wake": """Usage: cel group <group_id> supervisor wake [worker_id]\n\nWake a worker without sending a new message. If there is a single worker, omit worker_id.\n""",
    },
    "worker": {
        "read": """Usage: cel group <group_id> worker read\n\nPeek at unread supervisor messages for this group from the current worker session.\nUse mark-read after processing group messages.\n""",
        "inbox": """Usage: cel group <group_id> worker inbox\n\nPeek at unread messages addressed to this worker outside supervisor-specific reads.\n""",
        "mark-read": """Usage: cel group <group_id> worker mark-read\n\nAdvance the worker's chat-wide read cursor after processing group messages.\n""",
        "send": """Usage: cel group <group_id> worker send <message>\n\nReply to the supervisor from the current worker session.\n""",
    },
}
