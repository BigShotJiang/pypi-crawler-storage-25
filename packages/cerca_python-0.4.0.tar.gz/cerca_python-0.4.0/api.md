# Shared Types

```python
from cerca.types import ApprovalMode, ErrorResponse, JsonObject, ToolName, ToolSpec
```

# Auth

Types:

```python
from cerca.types import AuthContextResponse, AuthFleetsResponse
```

Methods:

- <code title="get /auth/context">client.auth.<a href="./src/cerca/resources/auth.py">context</a>() -> <a href="./src/cerca/types/auth_context_response.py">AuthContextResponse</a></code>
- <code title="get /auth/fleets">client.auth.<a href="./src/cerca/resources/auth.py">list_fleets</a>(\*\*<a href="src/cerca/types/auth_list_fleets_params.py">params</a>) -> <a href="./src/cerca/types/fleet.py">SyncFleetsCursorPage[Fleet]</a></code>

# OAuth

Types:

```python
from cerca.types import OAuthConnectResponse
```

Methods:

- <code title="post /oauth/connect/{provider}">client.oauth.<a href="./src/cerca/resources/oauth.py">connect</a>(provider, \*\*<a href="src/cerca/types/oauth_connect_params.py">params</a>) -> <a href="./src/cerca/types/oauth_connect_response.py">OAuthConnectResponse</a></code>

# Connections

Types:

```python
from cerca.types import (
    AttachedConnection,
    Connection,
    ConnectionOwner,
    CredentialProvider,
    CredentialType,
    ToolConnectionMetadata,
    ConnectionDeleteResponse,
    ConnectionDetachResponse,
    ConnectionListForAgentResponse,
)
```

Methods:

- <code title="post /connections/api-keys">client.connections.<a href="./src/cerca/resources/connections.py">create</a>(\*\*<a href="src/cerca/types/connection_create_params.py">params</a>) -> <a href="./src/cerca/types/connection.py">Connection</a></code>
- <code title="get /connections">client.connections.<a href="./src/cerca/resources/connections.py">list</a>(\*\*<a href="src/cerca/types/connection_list_params.py">params</a>) -> <a href="./src/cerca/types/connection.py">SyncConnectionsCursorPage[Connection]</a></code>
- <code title="delete /connections/{connectionId}">client.connections.<a href="./src/cerca/resources/connections.py">delete</a>(connection_id, \*\*<a href="src/cerca/types/connection_delete_params.py">params</a>) -> <a href="./src/cerca/types/connection_delete_response.py">ConnectionDeleteResponse</a></code>
- <code title="post /agents/{agentId}/connections">client.connections.<a href="./src/cerca/resources/connections.py">attach</a>(agent_id, \*\*<a href="src/cerca/types/connection_attach_params.py">params</a>) -> <a href="./src/cerca/types/attached_connection.py">AttachedConnection</a></code>
- <code title="delete /agents/{agentId}/connections/{connectionId}">client.connections.<a href="./src/cerca/resources/connections.py">detach</a>(agent_id, connection_id) -> <a href="./src/cerca/types/connection_detach_response.py">ConnectionDetachResponse</a></code>
- <code title="get /agents/{agentId}/connections">client.connections.<a href="./src/cerca/resources/connections.py">list_for_agent</a>(agent_id) -> <a href="./src/cerca/types/connection_list_for_agent_response.py">ConnectionListForAgentResponse</a></code>

# Fleets

Types:

```python
from cerca.types import Fleet
```

# Tools

Types:

```python
from cerca.types import (
    APIKeyToolSourceAuth,
    AuthInjection,
    HTTPEndpoint,
    HTTPToolDefinition,
    HTTPToolExecutionPolicy,
    HTTPToolSource,
    McpToolExecutionPolicy,
    McpToolSource,
    NoToolSourceAuth,
    OAuthConnectionToolSourceAuth,
    OAuthExchangeConfig,
    OAuthExchangeToolSourceAuth,
    ResponseNormalizationHint,
    ToolApprovalMode,
    ToolSource,
    ToolSourceAuth,
)
```

Methods:

- <code title="post /fleets/{fleetId}/tools">client.tools.<a href="./src/cerca/resources/tools.py">create</a>(fleet_id, \*\*<a href="src/cerca/types/tool_create_params.py">params</a>) -> <a href="./src/cerca/types/tool_source.py">ToolSource</a></code>
- <code title="get /fleets/{fleetId}/tools/{sourceId}">client.tools.<a href="./src/cerca/resources/tools.py">retrieve</a>(fleet_id, source_id) -> <a href="./src/cerca/types/tool_source.py">ToolSource</a></code>
- <code title="put /fleets/{fleetId}/tools/{sourceId}">client.tools.<a href="./src/cerca/resources/tools.py">update</a>(fleet_id, source_id, \*\*<a href="src/cerca/types/tool_update_params.py">params</a>) -> <a href="./src/cerca/types/tool_source.py">ToolSource</a></code>
- <code title="get /fleets/{fleetId}/tools">client.tools.<a href="./src/cerca/resources/tools.py">list</a>(fleet_id, \*\*<a href="src/cerca/types/tool_list_params.py">params</a>) -> <a href="./src/cerca/types/tool_source.py">SyncSourcesCursorPage[ToolSource]</a></code>
- <code title="delete /fleets/{fleetId}/tools/{sourceId}">client.tools.<a href="./src/cerca/resources/tools.py">delete</a>(fleet_id, source_id) -> None</code>

# Webhooks

Types:

```python
from cerca.types import (
    WebhookEventType,
    WebhookSubscription,
    WebhookSubscriptionCreated,
    WebhookSubscriptionEventType,
    WebhookTestResponse,
)
```

Methods:

- <code title="post /fleets/{fleetId}/webhooks">client.webhooks.<a href="./src/cerca/resources/webhooks.py">create</a>(fleet_id, \*\*<a href="src/cerca/types/webhook_create_params.py">params</a>) -> <a href="./src/cerca/types/webhook_subscription_created.py">WebhookSubscriptionCreated</a></code>
- <code title="get /fleets/{fleetId}/webhooks/{webhookId}">client.webhooks.<a href="./src/cerca/resources/webhooks.py">retrieve</a>(fleet_id, webhook_id) -> <a href="./src/cerca/types/webhook_subscription.py">WebhookSubscription</a></code>
- <code title="put /fleets/{fleetId}/webhooks/{webhookId}">client.webhooks.<a href="./src/cerca/resources/webhooks.py">update</a>(fleet_id, webhook_id, \*\*<a href="src/cerca/types/webhook_update_params.py">params</a>) -> <a href="./src/cerca/types/webhook_subscription.py">WebhookSubscription</a></code>
- <code title="get /fleets/{fleetId}/webhooks">client.webhooks.<a href="./src/cerca/resources/webhooks.py">list</a>(fleet_id, \*\*<a href="src/cerca/types/webhook_list_params.py">params</a>) -> <a href="./src/cerca/types/webhook_subscription.py">SyncSubscriptionsCursorPage[WebhookSubscription]</a></code>
- <code title="delete /fleets/{fleetId}/webhooks/{webhookId}">client.webhooks.<a href="./src/cerca/resources/webhooks.py">delete</a>(fleet_id, webhook_id) -> None</code>
- <code title="post /fleets/{fleetId}/webhooks/{webhookId}/rotate">client.webhooks.<a href="./src/cerca/resources/webhooks.py">rotate</a>(fleet_id, webhook_id) -> <a href="./src/cerca/types/webhook_subscription_created.py">WebhookSubscriptionCreated</a></code>
- <code title="post /fleets/{fleetId}/webhooks/{webhookId}/test">client.webhooks.<a href="./src/cerca/resources/webhooks.py">test</a>(fleet_id, webhook_id) -> <a href="./src/cerca/types/webhook_test_response.py">WebhookTestResponse</a></code>

# Events

Types:

```python
from cerca.types import RuntimeWebhookEvent, SubscriptionEvent, ThreadStreamEvent
```

Methods:

- <code title="get /agents/{agentId}/events">client.events.<a href="./src/cerca/resources/events.py">list_for_agent</a>(agent_id, \*\*<a href="src/cerca/types/event_list_for_agent_params.py">params</a>) -> <a href="./src/cerca/types/subscription_event.py">SyncEventsCursorPage[SubscriptionEvent]</a></code>
- <code title="get /fleets/{fleetId}/events">client.events.<a href="./src/cerca/resources/events.py">list_for_fleet</a>(fleet_id, \*\*<a href="src/cerca/types/event_list_for_fleet_params.py">params</a>) -> <a href="./src/cerca/types/subscription_event.py">SyncEventsCursorPage[SubscriptionEvent]</a></code>
- <code title="get /agents/{agentId}/threads/{threadId}/events">client.events.<a href="./src/cerca/resources/events.py">list_for_thread</a>(agent_id, thread_id, \*\*<a href="src/cerca/types/event_list_for_thread_params.py">params</a>) -> <a href="./src/cerca/types/subscription_event.py">SyncEventsCursorPage[SubscriptionEvent]</a></code>
- <code title="get /agents/{agentId}/events/stream">client.events.<a href="./src/cerca/resources/events.py">stream_for_agent</a>(agent_id, \*\*<a href="src/cerca/types/event_stream_for_agent_params.py">params</a>) -> <a href="./src/cerca/types/subscription_event.py">SubscriptionEvent</a></code>
- <code title="get /fleets/{fleetId}/events/stream">client.events.<a href="./src/cerca/resources/events.py">stream_for_fleet</a>(fleet_id, \*\*<a href="src/cerca/types/event_stream_for_fleet_params.py">params</a>) -> <a href="./src/cerca/types/subscription_event.py">SubscriptionEvent</a></code>
- <code title="get /agents/{agentId}/threads/{threadId}/stream">client.events.<a href="./src/cerca/resources/events.py">stream_for_thread</a>(agent_id, thread_id) -> <a href="./src/cerca/types/thread_stream_event.py">ThreadStreamEvent</a></code>
- <code title="get /agents/{agentId}/threads/{threadId}/events/stream">client.events.<a href="./src/cerca/resources/events.py">stream_for_thread_events</a>(agent_id, thread_id, \*\*<a href="src/cerca/types/event_stream_for_thread_events_params.py">params</a>) -> <a href="./src/cerca/types/subscription_event.py">SubscriptionEvent</a></code>

# Agents

Types:

```python
from cerca.types import (
    Agent,
    AgentSummary,
    ApprovalPolicy,
    Configuration,
    ConfigurationFieldName,
    DiscoveredTool,
    EffectiveConfiguration,
    ExecutionPrincipal,
    Metadata,
    SourceWarning,
    Tool,
    ToolDescriptor,
    AgentDeleteResponse,
    AgentListToolsResponse,
)
```

Methods:

- <code title="post /agents">client.agents.<a href="./src/cerca/resources/agents.py">create</a>(\*\*<a href="src/cerca/types/agent_create_params.py">params</a>) -> <a href="./src/cerca/types/agent.py">Agent</a></code>
- <code title="get /agents/{agentId}">client.agents.<a href="./src/cerca/resources/agents.py">retrieve</a>(agent_id) -> <a href="./src/cerca/types/agent.py">Agent</a></code>
- <code title="put /agents/{agentId}">client.agents.<a href="./src/cerca/resources/agents.py">update</a>(agent_id, \*\*<a href="src/cerca/types/agent_update_params.py">params</a>) -> <a href="./src/cerca/types/agent.py">Agent</a></code>
- <code title="get /agents">client.agents.<a href="./src/cerca/resources/agents.py">list</a>(\*\*<a href="src/cerca/types/agent_list_params.py">params</a>) -> <a href="./src/cerca/types/agent_summary.py">SyncAgentsCursorPage[AgentSummary]</a></code>
- <code title="delete /agents/{agentId}">client.agents.<a href="./src/cerca/resources/agents.py">delete</a>(agent_id) -> <a href="./src/cerca/types/agent_delete_response.py">AgentDeleteResponse</a></code>
- <code title="get /agents/{agentId}/tools">client.agents.<a href="./src/cerca/resources/agents.py">list_tools</a>(agent_id) -> <a href="./src/cerca/types/agent_list_tools_response.py">AgentListToolsResponse</a></code>
- <code title="get /agents/{agentId}/config">client.agents.<a href="./src/cerca/resources/agents.py">retrieve_config</a>(agent_id) -> <a href="./src/cerca/types/effective_configuration.py">EffectiveConfiguration</a></code>
- <code title="patch /agents/{agentId}/metadata">client.agents.<a href="./src/cerca/resources/agents.py">update_metadata</a>(agent_id, \*\*<a href="src/cerca/types/agent_update_metadata_params.py">params</a>) -> <a href="./src/cerca/types/agent.py">Agent</a></code>

# Threads

Types:

```python
from cerca.types import (
    ActivityDetail,
    ActivitySummary,
    CompiledContext,
    ContentBlock,
    Message,
    MessagePage,
    Status,
    SteerResult,
    SubThreadSummary,
    Thread,
    ThreadSummary,
    ThreadTurnSummary,
    TokenUsage,
    Turn,
)
```

Methods:

- <code title="post /agents/{agentId}/threads">client.threads.<a href="./src/cerca/resources/threads.py">create</a>(agent_id, \*\*<a href="src/cerca/types/thread_create_params.py">params</a>) -> <a href="./src/cerca/types/thread.py">Thread</a></code>
- <code title="get /agents/{agentId}/threads/{threadId}">client.threads.<a href="./src/cerca/resources/threads.py">retrieve</a>(agent_id, thread_id, \*\*<a href="src/cerca/types/thread_retrieve_params.py">params</a>) -> <a href="./src/cerca/types/thread.py">Thread</a></code>
- <code title="get /agents/{agentId}/threads">client.threads.<a href="./src/cerca/resources/threads.py">list</a>(agent_id, \*\*<a href="src/cerca/types/thread_list_params.py">params</a>) -> <a href="./src/cerca/types/thread_summary.py">SyncThreadsCursorPage[ThreadSummary]</a></code>
- <code title="get /agents/{agentId}/threads/{threadId}/activity">client.threads.<a href="./src/cerca/resources/threads.py">activity</a>(agent_id, thread_id, \*\*<a href="src/cerca/types/thread_activity_params.py">params</a>) -> <a href="./src/cerca/types/activity_detail.py">ActivityDetail</a></code>
- <code title="post /agents/{agentId}/threads/{threadId}/cancel">client.threads.<a href="./src/cerca/resources/threads.py">cancel</a>(agent_id, thread_id) -> <a href="./src/cerca/types/thread.py">Thread</a></code>
- <code title="post /agents/{agentId}/threads/{threadId}/close">client.threads.<a href="./src/cerca/resources/threads.py">close</a>(agent_id, thread_id) -> <a href="./src/cerca/types/thread.py">Thread</a></code>
- <code title="post /agents/{agentId}/threads/{threadId}/compact">client.threads.<a href="./src/cerca/resources/threads.py">compact</a>(agent_id, thread_id) -> <a href="./src/cerca/types/thread.py">Thread</a></code>
- <code title="get /agents/{agentId}/threads/{threadId}/messages">client.threads.<a href="./src/cerca/resources/threads.py">list_messages</a>(agent_id, thread_id, \*\*<a href="src/cerca/types/thread_list_messages_params.py">params</a>) -> <a href="./src/cerca/types/message.py">SyncThreadMessagesCursorPage[Message]</a></code>
- <code title="post /agents/{agentId}/threads/{threadId}/turns">client.threads.<a href="./src/cerca/resources/threads.py">start_turn</a>(agent_id, thread_id, \*\*<a href="src/cerca/types/thread_start_turn_params.py">params</a>) -> <a href="./src/cerca/types/turn.py">Turn</a></code>
- <code title="post /agents/{agentId}/threads/{threadId}/steer">client.threads.<a href="./src/cerca/resources/threads.py">steer</a>(agent_id, thread_id, \*\*<a href="src/cerca/types/thread_steer_params.py">params</a>) -> <a href="./src/cerca/types/steer_result.py">SteerResult</a></code>

# Context

Types:

```python
from cerca.types import Entry, EntrySummary, SearchResult, ContextDeleteResponse
```

Methods:

- <code title="get /agents/{agentId}/context/entry">client.context.<a href="./src/cerca/resources/context.py">retrieve</a>(agent_id, \*\*<a href="src/cerca/types/context_retrieve_params.py">params</a>) -> <a href="./src/cerca/types/entry.py">Entry</a></code>
- <code title="get /agents/{agentId}/context">client.context.<a href="./src/cerca/resources/context.py">list</a>(agent_id, \*\*<a href="src/cerca/types/context_list_params.py">params</a>) -> <a href="./src/cerca/types/entry_summary.py">SyncEntriesCursorPage[EntrySummary]</a></code>
- <code title="delete /agents/{agentId}/context/entry">client.context.<a href="./src/cerca/resources/context.py">delete</a>(agent_id, \*\*<a href="src/cerca/types/context_delete_params.py">params</a>) -> <a href="./src/cerca/types/context_delete_response.py">ContextDeleteResponse</a></code>
- <code title="get /agents/{agentId}/context/search">client.context.<a href="./src/cerca/resources/context.py">search</a>(agent_id, \*\*<a href="src/cerca/types/context_search_params.py">params</a>) -> <a href="./src/cerca/types/search_result.py">SyncResultsCursorPage[SearchResult]</a></code>
- <code title="put /agents/{agentId}/context/entry">client.context.<a href="./src/cerca/resources/context.py">write</a>(agent_id, \*\*<a href="src/cerca/types/context_write_params.py">params</a>) -> <a href="./src/cerca/types/entry.py">Entry</a></code>

# Schedules

Types:

```python
from cerca.types import (
    Schedule,
    ScheduleListResponse,
    ScheduleDeleteResponse,
    ScheduleTriggerResponse,
)
```

Methods:

- <code title="post /agents/{agentId}/schedules">client.schedules.<a href="./src/cerca/resources/schedules.py">create</a>(agent_id, \*\*<a href="src/cerca/types/schedule_create_params.py">params</a>) -> <a href="./src/cerca/types/schedule.py">Schedule</a></code>
- <code title="put /agents/{agentId}/schedules/{scheduleId}">client.schedules.<a href="./src/cerca/resources/schedules.py">update</a>(agent_id, schedule_id, \*\*<a href="src/cerca/types/schedule_update_params.py">params</a>) -> <a href="./src/cerca/types/schedule.py">Schedule</a></code>
- <code title="get /agents/{agentId}/schedules">client.schedules.<a href="./src/cerca/resources/schedules.py">list</a>(agent_id) -> <a href="./src/cerca/types/schedule_list_response.py">ScheduleListResponse</a></code>
- <code title="delete /agents/{agentId}/schedules/{scheduleId}">client.schedules.<a href="./src/cerca/resources/schedules.py">delete</a>(agent_id, schedule_id) -> <a href="./src/cerca/types/schedule_delete_response.py">ScheduleDeleteResponse</a></code>
- <code title="post /agents/{agentId}/schedules/{scheduleId}/trigger">client.schedules.<a href="./src/cerca/resources/schedules.py">trigger</a>(agent_id, schedule_id) -> <a href="./src/cerca/types/schedule_trigger_response.py">ScheduleTriggerResponse</a></code>

# ApprovalRequests

Types:

```python
from cerca.types import ApprovalRequest
```

Methods:

- <code title="get /agents/{agentId}/approvals">client.approval_requests.<a href="./src/cerca/resources/approval_requests.py">list</a>(agent_id, \*\*<a href="src/cerca/types/approval_request_list_params.py">params</a>) -> <a href="./src/cerca/types/approval_request.py">SyncApprovalRequestsCursorPage[ApprovalRequest]</a></code>
- <code title="post /agents/{agentId}/threads/{threadId}/approvals/{approvalId}">client.approval_requests.<a href="./src/cerca/resources/approval_requests.py">resolve</a>(agent_id, thread_id, approval_id, \*\*<a href="src/cerca/types/approval_request_resolve_params.py">params</a>) -> <a href="./src/cerca/types/approval_request.py">ApprovalRequest</a></code>

# ApprovalGrants

Types:

```python
from cerca.types import (
    ApprovalGrant,
    ApprovalGrantDeleteResponse,
    ApprovalGrantDeleteForThreadResponse,
    ApprovalGrantListForThreadResponse,
)
```

Methods:

- <code title="get /agents/{agentId}/approval-grants">client.approval_grants.<a href="./src/cerca/resources/approval_grants.py">list</a>(agent_id, \*\*<a href="src/cerca/types/approval_grant_list_params.py">params</a>) -> <a href="./src/cerca/types/approval_grant.py">SyncGrantsCursorPage[ApprovalGrant]</a></code>
- <code title="delete /agents/{agentId}/approval-grants/{grantId}">client.approval_grants.<a href="./src/cerca/resources/approval_grants.py">delete</a>(agent_id, grant_id) -> <a href="./src/cerca/types/approval_grant_delete_response.py">ApprovalGrantDeleteResponse</a></code>
- <code title="delete /agents/{agentId}/threads/{threadId}/approval-grants/{grantId}">client.approval_grants.<a href="./src/cerca/resources/approval_grants.py">delete_for_thread</a>(agent_id, thread_id, grant_id) -> <a href="./src/cerca/types/approval_grant_delete_for_thread_response.py">ApprovalGrantDeleteForThreadResponse</a></code>
- <code title="get /agents/{agentId}/threads/{threadId}/approval-grants">client.approval_grants.<a href="./src/cerca/resources/approval_grants.py">list_for_thread</a>(agent_id, thread_id) -> <a href="./src/cerca/types/approval_grant_list_for_thread_response.py">ApprovalGrantListForThreadResponse</a></code>

# Sandbox

Types:

```python
from cerca.types import ExecResult, ReadResponse, SandboxWriteResponse
```

Methods:

- <code title="post /agents/{agentId}/sandbox/exec">client.sandbox.<a href="./src/cerca/resources/sandbox.py">exec</a>(agent_id, \*\*<a href="src/cerca/types/sandbox_exec_params.py">params</a>) -> <a href="./src/cerca/types/exec_result.py">ExecResult</a></code>
- <code title="post /agents/{agentId}/sandbox/read">client.sandbox.<a href="./src/cerca/resources/sandbox.py">read</a>(agent_id, \*\*<a href="src/cerca/types/sandbox_read_params.py">params</a>) -> <a href="./src/cerca/types/read_response.py">ReadResponse</a></code>
- <code title="post /agents/{agentId}/sandbox/write">client.sandbox.<a href="./src/cerca/resources/sandbox.py">write</a>(agent_id, \*\*<a href="src/cerca/types/sandbox_write_params.py">params</a>) -> <a href="./src/cerca/types/sandbox_write_response.py">SandboxWriteResponse</a></code>

# Models

Types:

```python
from cerca.types import ModelDescriptor, ModelListResponse
```

Methods:

- <code title="get /models">client.models.<a href="./src/cerca/resources/models.py">list</a>() -> <a href="./src/cerca/types/model_list_response.py">ModelListResponse</a></code>
