# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Any, Iterable, cast
from typing_extensions import Literal, overload

import httpx

from ..types import (
    ToolApprovalMode,
    tool_list_params,
    tool_create_params,
    tool_update_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import path_template, required_args, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncSourcesCursorPage, AsyncSourcesCursorPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.tool_source import ToolSource
from ..types.tool_approval_mode import ToolApprovalMode
from ..types.tool_source_auth_param import ToolSourceAuthParam
from ..types.http_tool_definition_param import HTTPToolDefinitionParam
from ..types.mcp_tool_execution_policy_param import McpToolExecutionPolicyParam
from ..types.http_tool_execution_policy_param import HTTPToolExecutionPolicyParam

__all__ = ["ToolsResource", "AsyncToolsResource"]


class ToolsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ToolsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return ToolsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ToolsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return ToolsResourceWithStreamingResponse(self)

    @overload
    def create(
        self,
        fleet_id: str,
        *,
        auth: ToolSourceAuthParam,
        namespace: str,
        tools: Iterable[HTTPToolDefinitionParam],
        type: Literal["http"],
        approval: ToolApprovalMode | Omit = omit,
        enabled: bool | Omit = omit,
        execution: HTTPToolExecutionPolicyParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        """Create tool

        Args:
          auth: Tool source authentication configuration.

        The `kind` field selects one of
              `none`, `api_key`, `oauth_exchange`, or `oauth_connection`.

          execution: HTTP tool execution retry and timeout policy.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    def create(
        self,
        fleet_id: str,
        *,
        auth: ToolSourceAuthParam,
        namespace: str,
        type: Literal["mcp"],
        url: str,
        approval: ToolApprovalMode | Omit = omit,
        enabled: bool | Omit = omit,
        execution: McpToolExecutionPolicyParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        """Create tool

        Args:
          auth: Tool source authentication configuration.

        The `kind` field selects one of
              `none`, `api_key`, `oauth_exchange`, or `oauth_connection`.

          execution: MCP discovery and execution retry/timeout policy.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @required_args(["auth", "namespace", "tools", "type"], ["auth", "namespace", "type", "url"])
    def create(
        self,
        fleet_id: str,
        *,
        auth: ToolSourceAuthParam,
        namespace: str,
        tools: Iterable[HTTPToolDefinitionParam] | Omit = omit,
        type: Literal["http"] | Literal["mcp"],
        approval: ToolApprovalMode | Omit = omit,
        enabled: bool | Omit = omit,
        execution: HTTPToolExecutionPolicyParam | McpToolExecutionPolicyParam | Omit = omit,
        url: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        return cast(
            ToolSource,
            self._post(
                path_template("/fleets/{fleet_id}/tools", fleet_id=fleet_id),
                body=maybe_transform(
                    {
                        "auth": auth,
                        "namespace": namespace,
                        "tools": tools,
                        "type": type,
                        "approval": approval,
                        "enabled": enabled,
                        "execution": execution,
                        "url": url,
                    },
                    tool_create_params.ToolCreateParams,
                ),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(Any, ToolSource),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    def retrieve(
        self,
        fleet_id: str,
        source_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        """
        Retrieve tool source

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        if not source_id:
            raise ValueError(f"Expected a non-empty value for `source_id` but received {source_id!r}")
        return cast(
            ToolSource,
            self._get(
                path_template("/fleets/{fleet_id}/tools/{source_id}", fleet_id=fleet_id, source_id=source_id),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(Any, ToolSource),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    @overload
    def update(
        self,
        fleet_id: str,
        source_id: str,
        *,
        auth: ToolSourceAuthParam,
        namespace: str,
        tools: Iterable[HTTPToolDefinitionParam],
        type: Literal["http"],
        approval: ToolApprovalMode | Omit = omit,
        enabled: bool | Omit = omit,
        execution: HTTPToolExecutionPolicyParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        """Update tool source

        Args:
          auth: Tool source authentication configuration.

        The `kind` field selects one of
              `none`, `api_key`, `oauth_exchange`, or `oauth_connection`.

          execution: HTTP tool execution retry and timeout policy.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    def update(
        self,
        fleet_id: str,
        source_id: str,
        *,
        auth: ToolSourceAuthParam,
        namespace: str,
        type: Literal["mcp"],
        url: str,
        approval: ToolApprovalMode | Omit = omit,
        enabled: bool | Omit = omit,
        execution: McpToolExecutionPolicyParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        """Update tool source

        Args:
          auth: Tool source authentication configuration.

        The `kind` field selects one of
              `none`, `api_key`, `oauth_exchange`, or `oauth_connection`.

          execution: MCP discovery and execution retry/timeout policy.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @required_args(["auth", "namespace", "tools", "type"], ["auth", "namespace", "type", "url"])
    def update(
        self,
        fleet_id: str,
        source_id: str,
        *,
        auth: ToolSourceAuthParam,
        namespace: str,
        tools: Iterable[HTTPToolDefinitionParam] | Omit = omit,
        type: Literal["http"] | Literal["mcp"],
        approval: ToolApprovalMode | Omit = omit,
        enabled: bool | Omit = omit,
        execution: HTTPToolExecutionPolicyParam | McpToolExecutionPolicyParam | Omit = omit,
        url: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        if not source_id:
            raise ValueError(f"Expected a non-empty value for `source_id` but received {source_id!r}")
        return cast(
            ToolSource,
            self._put(
                path_template("/fleets/{fleet_id}/tools/{source_id}", fleet_id=fleet_id, source_id=source_id),
                body=maybe_transform(
                    {
                        "auth": auth,
                        "namespace": namespace,
                        "tools": tools,
                        "type": type,
                        "approval": approval,
                        "enabled": enabled,
                        "execution": execution,
                        "url": url,
                    },
                    tool_update_params.ToolUpdateParams,
                ),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(Any, ToolSource),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    def list(
        self,
        fleet_id: str,
        *,
        cursor: str | Omit = omit,
        limit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncSourcesCursorPage[ToolSource]:
        """
        List tools

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        return self._get_api_list(
            path_template("/fleets/{fleet_id}/tools", fleet_id=fleet_id),
            page=SyncSourcesCursorPage[ToolSource],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    tool_list_params.ToolListParams,
                ),
            ),
            model=cast(Any, ToolSource),  # Union types cannot be passed in as arguments in the type system
        )

    def delete(
        self,
        fleet_id: str,
        source_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete tool source

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        if not source_id:
            raise ValueError(f"Expected a non-empty value for `source_id` but received {source_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template("/fleets/{fleet_id}/tools/{source_id}", fleet_id=fleet_id, source_id=source_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncToolsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncToolsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return AsyncToolsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncToolsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return AsyncToolsResourceWithStreamingResponse(self)

    @overload
    async def create(
        self,
        fleet_id: str,
        *,
        auth: ToolSourceAuthParam,
        namespace: str,
        tools: Iterable[HTTPToolDefinitionParam],
        type: Literal["http"],
        approval: ToolApprovalMode | Omit = omit,
        enabled: bool | Omit = omit,
        execution: HTTPToolExecutionPolicyParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        """Create tool

        Args:
          auth: Tool source authentication configuration.

        The `kind` field selects one of
              `none`, `api_key`, `oauth_exchange`, or `oauth_connection`.

          execution: HTTP tool execution retry and timeout policy.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    async def create(
        self,
        fleet_id: str,
        *,
        auth: ToolSourceAuthParam,
        namespace: str,
        type: Literal["mcp"],
        url: str,
        approval: ToolApprovalMode | Omit = omit,
        enabled: bool | Omit = omit,
        execution: McpToolExecutionPolicyParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        """Create tool

        Args:
          auth: Tool source authentication configuration.

        The `kind` field selects one of
              `none`, `api_key`, `oauth_exchange`, or `oauth_connection`.

          execution: MCP discovery and execution retry/timeout policy.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @required_args(["auth", "namespace", "tools", "type"], ["auth", "namespace", "type", "url"])
    async def create(
        self,
        fleet_id: str,
        *,
        auth: ToolSourceAuthParam,
        namespace: str,
        tools: Iterable[HTTPToolDefinitionParam] | Omit = omit,
        type: Literal["http"] | Literal["mcp"],
        approval: ToolApprovalMode | Omit = omit,
        enabled: bool | Omit = omit,
        execution: HTTPToolExecutionPolicyParam | McpToolExecutionPolicyParam | Omit = omit,
        url: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        return cast(
            ToolSource,
            await self._post(
                path_template("/fleets/{fleet_id}/tools", fleet_id=fleet_id),
                body=await async_maybe_transform(
                    {
                        "auth": auth,
                        "namespace": namespace,
                        "tools": tools,
                        "type": type,
                        "approval": approval,
                        "enabled": enabled,
                        "execution": execution,
                        "url": url,
                    },
                    tool_create_params.ToolCreateParams,
                ),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(Any, ToolSource),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    async def retrieve(
        self,
        fleet_id: str,
        source_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        """
        Retrieve tool source

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        if not source_id:
            raise ValueError(f"Expected a non-empty value for `source_id` but received {source_id!r}")
        return cast(
            ToolSource,
            await self._get(
                path_template("/fleets/{fleet_id}/tools/{source_id}", fleet_id=fleet_id, source_id=source_id),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(Any, ToolSource),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    @overload
    async def update(
        self,
        fleet_id: str,
        source_id: str,
        *,
        auth: ToolSourceAuthParam,
        namespace: str,
        tools: Iterable[HTTPToolDefinitionParam],
        type: Literal["http"],
        approval: ToolApprovalMode | Omit = omit,
        enabled: bool | Omit = omit,
        execution: HTTPToolExecutionPolicyParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        """Update tool source

        Args:
          auth: Tool source authentication configuration.

        The `kind` field selects one of
              `none`, `api_key`, `oauth_exchange`, or `oauth_connection`.

          execution: HTTP tool execution retry and timeout policy.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    async def update(
        self,
        fleet_id: str,
        source_id: str,
        *,
        auth: ToolSourceAuthParam,
        namespace: str,
        type: Literal["mcp"],
        url: str,
        approval: ToolApprovalMode | Omit = omit,
        enabled: bool | Omit = omit,
        execution: McpToolExecutionPolicyParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        """Update tool source

        Args:
          auth: Tool source authentication configuration.

        The `kind` field selects one of
              `none`, `api_key`, `oauth_exchange`, or `oauth_connection`.

          execution: MCP discovery and execution retry/timeout policy.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @required_args(["auth", "namespace", "tools", "type"], ["auth", "namespace", "type", "url"])
    async def update(
        self,
        fleet_id: str,
        source_id: str,
        *,
        auth: ToolSourceAuthParam,
        namespace: str,
        tools: Iterable[HTTPToolDefinitionParam] | Omit = omit,
        type: Literal["http"] | Literal["mcp"],
        approval: ToolApprovalMode | Omit = omit,
        enabled: bool | Omit = omit,
        execution: HTTPToolExecutionPolicyParam | McpToolExecutionPolicyParam | Omit = omit,
        url: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolSource:
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        if not source_id:
            raise ValueError(f"Expected a non-empty value for `source_id` but received {source_id!r}")
        return cast(
            ToolSource,
            await self._put(
                path_template("/fleets/{fleet_id}/tools/{source_id}", fleet_id=fleet_id, source_id=source_id),
                body=await async_maybe_transform(
                    {
                        "auth": auth,
                        "namespace": namespace,
                        "tools": tools,
                        "type": type,
                        "approval": approval,
                        "enabled": enabled,
                        "execution": execution,
                        "url": url,
                    },
                    tool_update_params.ToolUpdateParams,
                ),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(Any, ToolSource),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    def list(
        self,
        fleet_id: str,
        *,
        cursor: str | Omit = omit,
        limit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[ToolSource, AsyncSourcesCursorPage[ToolSource]]:
        """
        List tools

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        return self._get_api_list(
            path_template("/fleets/{fleet_id}/tools", fleet_id=fleet_id),
            page=AsyncSourcesCursorPage[ToolSource],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    tool_list_params.ToolListParams,
                ),
            ),
            model=cast(Any, ToolSource),  # Union types cannot be passed in as arguments in the type system
        )

    async def delete(
        self,
        fleet_id: str,
        source_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete tool source

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        if not source_id:
            raise ValueError(f"Expected a non-empty value for `source_id` but received {source_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template("/fleets/{fleet_id}/tools/{source_id}", fleet_id=fleet_id, source_id=source_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class ToolsResourceWithRawResponse:
    def __init__(self, tools: ToolsResource) -> None:
        self._tools = tools

        self.create = to_raw_response_wrapper(
            tools.create,
        )
        self.retrieve = to_raw_response_wrapper(
            tools.retrieve,
        )
        self.update = to_raw_response_wrapper(
            tools.update,
        )
        self.list = to_raw_response_wrapper(
            tools.list,
        )
        self.delete = to_raw_response_wrapper(
            tools.delete,
        )


class AsyncToolsResourceWithRawResponse:
    def __init__(self, tools: AsyncToolsResource) -> None:
        self._tools = tools

        self.create = async_to_raw_response_wrapper(
            tools.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            tools.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            tools.update,
        )
        self.list = async_to_raw_response_wrapper(
            tools.list,
        )
        self.delete = async_to_raw_response_wrapper(
            tools.delete,
        )


class ToolsResourceWithStreamingResponse:
    def __init__(self, tools: ToolsResource) -> None:
        self._tools = tools

        self.create = to_streamed_response_wrapper(
            tools.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            tools.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            tools.update,
        )
        self.list = to_streamed_response_wrapper(
            tools.list,
        )
        self.delete = to_streamed_response_wrapper(
            tools.delete,
        )


class AsyncToolsResourceWithStreamingResponse:
    def __init__(self, tools: AsyncToolsResource) -> None:
        self._tools = tools

        self.create = async_to_streamed_response_wrapper(
            tools.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            tools.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            tools.update,
        )
        self.list = async_to_streamed_response_wrapper(
            tools.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            tools.delete,
        )
