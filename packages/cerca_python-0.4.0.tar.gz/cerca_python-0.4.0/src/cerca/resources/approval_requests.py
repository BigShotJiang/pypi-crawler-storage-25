# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import approval_request_list_params, approval_request_resolve_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncApprovalRequestsCursorPage, AsyncApprovalRequestsCursorPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.approval_request import ApprovalRequest

__all__ = ["ApprovalRequestsResource", "AsyncApprovalRequestsResource"]


class ApprovalRequestsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ApprovalRequestsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return ApprovalRequestsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ApprovalRequestsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return ApprovalRequestsResourceWithStreamingResponse(self)

    def list(
        self,
        agent_id: str,
        *,
        cursor: str | Omit = omit,
        limit: str | Omit = omit,
        thread_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncApprovalRequestsCursorPage[ApprovalRequest]:
        """
        List approvals

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          thread_id: Optional thread id filter.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/approvals", agent_id=agent_id),
            page=SyncApprovalRequestsCursorPage[ApprovalRequest],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "thread_id": thread_id,
                    },
                    approval_request_list_params.ApprovalRequestListParams,
                ),
            ),
            model=ApprovalRequest,
        )

    def resolve(
        self,
        agent_id: str,
        thread_id: str,
        approval_id: str,
        *,
        decision: Literal["approve", "deny", "cancel"],
        grant: Literal["thread", "agent"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ApprovalRequest:
        """
        Create approval

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        if not approval_id:
            raise ValueError(f"Expected a non-empty value for `approval_id` but received {approval_id!r}")
        return self._post(
            path_template(
                "/agents/{agent_id}/threads/{thread_id}/approvals/{approval_id}",
                agent_id=agent_id,
                thread_id=thread_id,
                approval_id=approval_id,
            ),
            body=maybe_transform(
                {
                    "decision": decision,
                    "grant": grant,
                },
                approval_request_resolve_params.ApprovalRequestResolveParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ApprovalRequest,
        )


class AsyncApprovalRequestsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncApprovalRequestsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return AsyncApprovalRequestsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncApprovalRequestsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return AsyncApprovalRequestsResourceWithStreamingResponse(self)

    def list(
        self,
        agent_id: str,
        *,
        cursor: str | Omit = omit,
        limit: str | Omit = omit,
        thread_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[ApprovalRequest, AsyncApprovalRequestsCursorPage[ApprovalRequest]]:
        """
        List approvals

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          thread_id: Optional thread id filter.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/approvals", agent_id=agent_id),
            page=AsyncApprovalRequestsCursorPage[ApprovalRequest],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "thread_id": thread_id,
                    },
                    approval_request_list_params.ApprovalRequestListParams,
                ),
            ),
            model=ApprovalRequest,
        )

    async def resolve(
        self,
        agent_id: str,
        thread_id: str,
        approval_id: str,
        *,
        decision: Literal["approve", "deny", "cancel"],
        grant: Literal["thread", "agent"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ApprovalRequest:
        """
        Create approval

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        if not approval_id:
            raise ValueError(f"Expected a non-empty value for `approval_id` but received {approval_id!r}")
        return await self._post(
            path_template(
                "/agents/{agent_id}/threads/{thread_id}/approvals/{approval_id}",
                agent_id=agent_id,
                thread_id=thread_id,
                approval_id=approval_id,
            ),
            body=await async_maybe_transform(
                {
                    "decision": decision,
                    "grant": grant,
                },
                approval_request_resolve_params.ApprovalRequestResolveParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ApprovalRequest,
        )


class ApprovalRequestsResourceWithRawResponse:
    def __init__(self, approval_requests: ApprovalRequestsResource) -> None:
        self._approval_requests = approval_requests

        self.list = to_raw_response_wrapper(
            approval_requests.list,
        )
        self.resolve = to_raw_response_wrapper(
            approval_requests.resolve,
        )


class AsyncApprovalRequestsResourceWithRawResponse:
    def __init__(self, approval_requests: AsyncApprovalRequestsResource) -> None:
        self._approval_requests = approval_requests

        self.list = async_to_raw_response_wrapper(
            approval_requests.list,
        )
        self.resolve = async_to_raw_response_wrapper(
            approval_requests.resolve,
        )


class ApprovalRequestsResourceWithStreamingResponse:
    def __init__(self, approval_requests: ApprovalRequestsResource) -> None:
        self._approval_requests = approval_requests

        self.list = to_streamed_response_wrapper(
            approval_requests.list,
        )
        self.resolve = to_streamed_response_wrapper(
            approval_requests.resolve,
        )


class AsyncApprovalRequestsResourceWithStreamingResponse:
    def __init__(self, approval_requests: AsyncApprovalRequestsResource) -> None:
        self._approval_requests = approval_requests

        self.list = async_to_streamed_response_wrapper(
            approval_requests.list,
        )
        self.resolve = async_to_streamed_response_wrapper(
            approval_requests.resolve,
        )
