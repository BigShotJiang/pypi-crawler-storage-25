# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import approval_grant_list_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncGrantsCursorPage, AsyncGrantsCursorPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.approval_grant import ApprovalGrant
from ..types.approval_grant_delete_response import ApprovalGrantDeleteResponse
from ..types.approval_grant_list_for_thread_response import ApprovalGrantListForThreadResponse
from ..types.approval_grant_delete_for_thread_response import ApprovalGrantDeleteForThreadResponse

__all__ = ["ApprovalGrantsResource", "AsyncApprovalGrantsResource"]


class ApprovalGrantsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ApprovalGrantsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return ApprovalGrantsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ApprovalGrantsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return ApprovalGrantsResourceWithStreamingResponse(self)

    def list(
        self,
        agent_id: str,
        *,
        cursor: str | Omit = omit,
        limit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncGrantsCursorPage[ApprovalGrant]:
        """
        List approval grants

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/approval-grants", agent_id=agent_id),
            page=SyncGrantsCursorPage[ApprovalGrant],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    approval_grant_list_params.ApprovalGrantListParams,
                ),
            ),
            model=ApprovalGrant,
        )

    def delete(
        self,
        agent_id: str,
        grant_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ApprovalGrantDeleteResponse:
        """
        Delete approval grant

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not grant_id:
            raise ValueError(f"Expected a non-empty value for `grant_id` but received {grant_id!r}")
        return self._delete(
            path_template("/agents/{agent_id}/approval-grants/{grant_id}", agent_id=agent_id, grant_id=grant_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ApprovalGrantDeleteResponse,
        )

    def delete_for_thread(
        self,
        agent_id: str,
        thread_id: str,
        grant_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ApprovalGrantDeleteForThreadResponse:
        """
        Delete approval grant

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        if not grant_id:
            raise ValueError(f"Expected a non-empty value for `grant_id` but received {grant_id!r}")
        return self._delete(
            path_template(
                "/agents/{agent_id}/threads/{thread_id}/approval-grants/{grant_id}",
                agent_id=agent_id,
                thread_id=thread_id,
                grant_id=grant_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ApprovalGrantDeleteForThreadResponse,
        )

    def list_for_thread(
        self,
        agent_id: str,
        thread_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ApprovalGrantListForThreadResponse:
        """
        List approval grants

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._get(
            path_template(
                "/agents/{agent_id}/threads/{thread_id}/approval-grants", agent_id=agent_id, thread_id=thread_id
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ApprovalGrantListForThreadResponse,
        )


class AsyncApprovalGrantsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncApprovalGrantsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return AsyncApprovalGrantsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncApprovalGrantsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return AsyncApprovalGrantsResourceWithStreamingResponse(self)

    def list(
        self,
        agent_id: str,
        *,
        cursor: str | Omit = omit,
        limit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[ApprovalGrant, AsyncGrantsCursorPage[ApprovalGrant]]:
        """
        List approval grants

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/approval-grants", agent_id=agent_id),
            page=AsyncGrantsCursorPage[ApprovalGrant],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    approval_grant_list_params.ApprovalGrantListParams,
                ),
            ),
            model=ApprovalGrant,
        )

    async def delete(
        self,
        agent_id: str,
        grant_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ApprovalGrantDeleteResponse:
        """
        Delete approval grant

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not grant_id:
            raise ValueError(f"Expected a non-empty value for `grant_id` but received {grant_id!r}")
        return await self._delete(
            path_template("/agents/{agent_id}/approval-grants/{grant_id}", agent_id=agent_id, grant_id=grant_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ApprovalGrantDeleteResponse,
        )

    async def delete_for_thread(
        self,
        agent_id: str,
        thread_id: str,
        grant_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ApprovalGrantDeleteForThreadResponse:
        """
        Delete approval grant

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        if not grant_id:
            raise ValueError(f"Expected a non-empty value for `grant_id` but received {grant_id!r}")
        return await self._delete(
            path_template(
                "/agents/{agent_id}/threads/{thread_id}/approval-grants/{grant_id}",
                agent_id=agent_id,
                thread_id=thread_id,
                grant_id=grant_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ApprovalGrantDeleteForThreadResponse,
        )

    async def list_for_thread(
        self,
        agent_id: str,
        thread_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ApprovalGrantListForThreadResponse:
        """
        List approval grants

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return await self._get(
            path_template(
                "/agents/{agent_id}/threads/{thread_id}/approval-grants", agent_id=agent_id, thread_id=thread_id
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ApprovalGrantListForThreadResponse,
        )


class ApprovalGrantsResourceWithRawResponse:
    def __init__(self, approval_grants: ApprovalGrantsResource) -> None:
        self._approval_grants = approval_grants

        self.list = to_raw_response_wrapper(
            approval_grants.list,
        )
        self.delete = to_raw_response_wrapper(
            approval_grants.delete,
        )
        self.delete_for_thread = to_raw_response_wrapper(
            approval_grants.delete_for_thread,
        )
        self.list_for_thread = to_raw_response_wrapper(
            approval_grants.list_for_thread,
        )


class AsyncApprovalGrantsResourceWithRawResponse:
    def __init__(self, approval_grants: AsyncApprovalGrantsResource) -> None:
        self._approval_grants = approval_grants

        self.list = async_to_raw_response_wrapper(
            approval_grants.list,
        )
        self.delete = async_to_raw_response_wrapper(
            approval_grants.delete,
        )
        self.delete_for_thread = async_to_raw_response_wrapper(
            approval_grants.delete_for_thread,
        )
        self.list_for_thread = async_to_raw_response_wrapper(
            approval_grants.list_for_thread,
        )


class ApprovalGrantsResourceWithStreamingResponse:
    def __init__(self, approval_grants: ApprovalGrantsResource) -> None:
        self._approval_grants = approval_grants

        self.list = to_streamed_response_wrapper(
            approval_grants.list,
        )
        self.delete = to_streamed_response_wrapper(
            approval_grants.delete,
        )
        self.delete_for_thread = to_streamed_response_wrapper(
            approval_grants.delete_for_thread,
        )
        self.list_for_thread = to_streamed_response_wrapper(
            approval_grants.list_for_thread,
        )


class AsyncApprovalGrantsResourceWithStreamingResponse:
    def __init__(self, approval_grants: AsyncApprovalGrantsResource) -> None:
        self._approval_grants = approval_grants

        self.list = async_to_streamed_response_wrapper(
            approval_grants.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            approval_grants.delete,
        )
        self.delete_for_thread = async_to_streamed_response_wrapper(
            approval_grants.delete_for_thread,
        )
        self.list_for_thread = async_to_streamed_response_wrapper(
            approval_grants.list_for_thread,
        )
