# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import (
    Status,
    thread_list_params,
    thread_steer_params,
    thread_create_params,
    thread_activity_params,
    thread_retrieve_params,
    thread_start_turn_params,
    thread_list_messages_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import (
    SyncThreadsCursorPage,
    AsyncThreadsCursorPage,
    SyncThreadMessagesCursorPage,
    AsyncThreadMessagesCursorPage,
)
from ..types.turn import Turn
from .._base_client import AsyncPaginator, make_request_options
from ..types.status import Status
from ..types.thread import Thread
from ..types.message import Message
from ..types.steer_result import SteerResult
from ..types.thread_summary import ThreadSummary
from ..types.activity_detail import ActivityDetail
from ..types.shared.tool_spec import ToolSpec

__all__ = ["ThreadsResource", "AsyncThreadsResource"]


class ThreadsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ThreadsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return ThreadsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ThreadsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return ThreadsResourceWithStreamingResponse(self)

    def create(
        self,
        agent_id: str,
        *,
        instructions: str | Omit = omit,
        message: str | Omit = omit,
        model: str | Omit = omit,
        system_prompt: str | Omit = omit,
        tools: SequenceNotStr[ToolSpec] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Thread:
        """
        Create thread

        Args:
          system_prompt: Deprecated alias for `instructions`; accepted for backwards compatibility.

          tools: Per-thread tool subset. Omit to inherit the agent's full effective tools; pass
              [] to run with no configurable tools. Provided entries can only narrow the
              agent's effective tools.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._post(
            path_template("/agents/{agent_id}/threads", agent_id=agent_id),
            body=maybe_transform(
                {
                    "instructions": instructions,
                    "message": message,
                    "model": model,
                    "system_prompt": system_prompt,
                    "tools": tools,
                },
                thread_create_params.ThreadCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Thread,
        )

    def retrieve(
        self,
        agent_id: str,
        thread_id: str,
        *,
        debug: Literal["true", "false"] | Omit = omit,
        include_messages: Literal["true", "false"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Thread:
        """
        Retrieve thread

        Args:
          debug: When true, includes debug-only compiled context fields.

          include_messages: Deprecated compatibility flag. Thread detail includes a bounded recent message
              page by default; pass `false` only to opt out when no message pagination params
              are present.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._get(
            path_template("/agents/{agent_id}/threads/{thread_id}", agent_id=agent_id, thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "debug": debug,
                        "include_messages": include_messages,
                    },
                    thread_retrieve_params.ThreadRetrieveParams,
                ),
            ),
            cast_to=Thread,
        )

    def list(
        self,
        agent_id: str,
        *,
        cursor: str | Omit = omit,
        limit: str | Omit = omit,
        schedule_id: str | Omit = omit,
        status: Status | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncThreadsCursorPage[ThreadSummary]:
        """
        List threads

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          schedule_id: Optional schedule id filter.

          status: Optional thread status filter.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/threads", agent_id=agent_id),
            page=SyncThreadsCursorPage[ThreadSummary],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "schedule_id": schedule_id,
                        "status": status,
                    },
                    thread_list_params.ThreadListParams,
                ),
            ),
            model=ThreadSummary,
        )

    def activity(
        self,
        agent_id: str,
        thread_id: str,
        *,
        fleet_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ActivityDetail:
        """
        Fetch compact current and recent activity for a thread without returning
        transcript content or runtime debug state.

        Args:
          fleet_id: Optional fleet id for index-backed authorization.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._get(
            path_template("/agents/{agent_id}/threads/{thread_id}/activity", agent_id=agent_id, thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"fleet_id": fleet_id}, thread_activity_params.ThreadActivityParams),
            ),
            cast_to=ActivityDetail,
        )

    def cancel(
        self,
        agent_id: str,
        thread_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Thread:
        """Cancel a running or awaiting thread.

        The underlying runtime treats repeat
        cancellation as an idempotent lifecycle operation when possible.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._post(
            path_template("/agents/{agent_id}/threads/{thread_id}/cancel", agent_id=agent_id, thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Thread,
        )

    def close(
        self,
        agent_id: str,
        thread_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Thread:
        """Close an idle thread.

        Closing a running, awaiting, or already-closed thread
        returns a lifecycle conflict.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._post(
            path_template("/agents/{agent_id}/threads/{thread_id}/close", agent_id=agent_id, thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Thread,
        )

    def compact(
        self,
        agent_id: str,
        thread_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Thread:
        """Force context compaction for an idle thread.

        Compacting a running thread returns
        a lifecycle conflict.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._post(
            path_template("/agents/{agent_id}/threads/{thread_id}/compact", agent_id=agent_id, thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Thread,
        )

    def list_messages(
        self,
        agent_id: str,
        thread_id: str,
        *,
        cursor: str | Omit = omit,
        fleet_id: str | Omit = omit,
        limit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncThreadMessagesCursorPage[Message]:
        """List a bounded page of transcript messages for a thread, newest first.

        Use the
        returned `cursor` to page older messages.

        Args:
          cursor: Cursor returned by a previous thread messages response.

          fleet_id: Optional fleet id for index-backed authorization.

          limit: Maximum number of messages to include, capped at 500.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/threads/{thread_id}/messages", agent_id=agent_id, thread_id=thread_id),
            page=SyncThreadMessagesCursorPage[Message],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "fleet_id": fleet_id,
                        "limit": limit,
                    },
                    thread_list_messages_params.ThreadListMessagesParams,
                ),
            ),
            model=Message,
        )

    def start_turn(
        self,
        agent_id: str,
        thread_id: str,
        *,
        message: str,
        model: str | Omit = omit,
        tools: SequenceNotStr[ToolSpec] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Turn:
        """Create turn

        Args:
          tools: Per-turn tool subset.

        Omit to inherit the thread's current tools; pass [] to run
              this turn with no configurable tools. Provided entries can only narrow the
              agent/thread effective tools.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._post(
            path_template("/agents/{agent_id}/threads/{thread_id}/turns", agent_id=agent_id, thread_id=thread_id),
            body=maybe_transform(
                {
                    "message": message,
                    "model": model,
                    "tools": tools,
                },
                thread_start_turn_params.ThreadStartTurnParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Turn,
        )

    def steer(
        self,
        agent_id: str,
        thread_id: str,
        *,
        message: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SteerResult:
        """Steer a thread with another user message.

        Steering a closed thread returns a
        conflict; steering a running or awaiting thread queues the message.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._post(
            path_template("/agents/{agent_id}/threads/{thread_id}/steer", agent_id=agent_id, thread_id=thread_id),
            body=maybe_transform({"message": message}, thread_steer_params.ThreadSteerParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SteerResult,
        )


class AsyncThreadsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncThreadsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return AsyncThreadsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncThreadsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return AsyncThreadsResourceWithStreamingResponse(self)

    async def create(
        self,
        agent_id: str,
        *,
        instructions: str | Omit = omit,
        message: str | Omit = omit,
        model: str | Omit = omit,
        system_prompt: str | Omit = omit,
        tools: SequenceNotStr[ToolSpec] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Thread:
        """
        Create thread

        Args:
          system_prompt: Deprecated alias for `instructions`; accepted for backwards compatibility.

          tools: Per-thread tool subset. Omit to inherit the agent's full effective tools; pass
              [] to run with no configurable tools. Provided entries can only narrow the
              agent's effective tools.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return await self._post(
            path_template("/agents/{agent_id}/threads", agent_id=agent_id),
            body=await async_maybe_transform(
                {
                    "instructions": instructions,
                    "message": message,
                    "model": model,
                    "system_prompt": system_prompt,
                    "tools": tools,
                },
                thread_create_params.ThreadCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Thread,
        )

    async def retrieve(
        self,
        agent_id: str,
        thread_id: str,
        *,
        debug: Literal["true", "false"] | Omit = omit,
        include_messages: Literal["true", "false"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Thread:
        """
        Retrieve thread

        Args:
          debug: When true, includes debug-only compiled context fields.

          include_messages: Deprecated compatibility flag. Thread detail includes a bounded recent message
              page by default; pass `false` only to opt out when no message pagination params
              are present.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return await self._get(
            path_template("/agents/{agent_id}/threads/{thread_id}", agent_id=agent_id, thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "debug": debug,
                        "include_messages": include_messages,
                    },
                    thread_retrieve_params.ThreadRetrieveParams,
                ),
            ),
            cast_to=Thread,
        )

    def list(
        self,
        agent_id: str,
        *,
        cursor: str | Omit = omit,
        limit: str | Omit = omit,
        schedule_id: str | Omit = omit,
        status: Status | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[ThreadSummary, AsyncThreadsCursorPage[ThreadSummary]]:
        """
        List threads

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          schedule_id: Optional schedule id filter.

          status: Optional thread status filter.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/threads", agent_id=agent_id),
            page=AsyncThreadsCursorPage[ThreadSummary],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "schedule_id": schedule_id,
                        "status": status,
                    },
                    thread_list_params.ThreadListParams,
                ),
            ),
            model=ThreadSummary,
        )

    async def activity(
        self,
        agent_id: str,
        thread_id: str,
        *,
        fleet_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ActivityDetail:
        """
        Fetch compact current and recent activity for a thread without returning
        transcript content or runtime debug state.

        Args:
          fleet_id: Optional fleet id for index-backed authorization.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return await self._get(
            path_template("/agents/{agent_id}/threads/{thread_id}/activity", agent_id=agent_id, thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"fleet_id": fleet_id}, thread_activity_params.ThreadActivityParams),
            ),
            cast_to=ActivityDetail,
        )

    async def cancel(
        self,
        agent_id: str,
        thread_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Thread:
        """Cancel a running or awaiting thread.

        The underlying runtime treats repeat
        cancellation as an idempotent lifecycle operation when possible.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return await self._post(
            path_template("/agents/{agent_id}/threads/{thread_id}/cancel", agent_id=agent_id, thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Thread,
        )

    async def close(
        self,
        agent_id: str,
        thread_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Thread:
        """Close an idle thread.

        Closing a running, awaiting, or already-closed thread
        returns a lifecycle conflict.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return await self._post(
            path_template("/agents/{agent_id}/threads/{thread_id}/close", agent_id=agent_id, thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Thread,
        )

    async def compact(
        self,
        agent_id: str,
        thread_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Thread:
        """Force context compaction for an idle thread.

        Compacting a running thread returns
        a lifecycle conflict.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return await self._post(
            path_template("/agents/{agent_id}/threads/{thread_id}/compact", agent_id=agent_id, thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Thread,
        )

    def list_messages(
        self,
        agent_id: str,
        thread_id: str,
        *,
        cursor: str | Omit = omit,
        fleet_id: str | Omit = omit,
        limit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[Message, AsyncThreadMessagesCursorPage[Message]]:
        """List a bounded page of transcript messages for a thread, newest first.

        Use the
        returned `cursor` to page older messages.

        Args:
          cursor: Cursor returned by a previous thread messages response.

          fleet_id: Optional fleet id for index-backed authorization.

          limit: Maximum number of messages to include, capped at 500.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/threads/{thread_id}/messages", agent_id=agent_id, thread_id=thread_id),
            page=AsyncThreadMessagesCursorPage[Message],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "fleet_id": fleet_id,
                        "limit": limit,
                    },
                    thread_list_messages_params.ThreadListMessagesParams,
                ),
            ),
            model=Message,
        )

    async def start_turn(
        self,
        agent_id: str,
        thread_id: str,
        *,
        message: str,
        model: str | Omit = omit,
        tools: SequenceNotStr[ToolSpec] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Turn:
        """Create turn

        Args:
          tools: Per-turn tool subset.

        Omit to inherit the thread's current tools; pass [] to run
              this turn with no configurable tools. Provided entries can only narrow the
              agent/thread effective tools.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return await self._post(
            path_template("/agents/{agent_id}/threads/{thread_id}/turns", agent_id=agent_id, thread_id=thread_id),
            body=await async_maybe_transform(
                {
                    "message": message,
                    "model": model,
                    "tools": tools,
                },
                thread_start_turn_params.ThreadStartTurnParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Turn,
        )

    async def steer(
        self,
        agent_id: str,
        thread_id: str,
        *,
        message: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SteerResult:
        """Steer a thread with another user message.

        Steering a closed thread returns a
        conflict; steering a running or awaiting thread queues the message.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return await self._post(
            path_template("/agents/{agent_id}/threads/{thread_id}/steer", agent_id=agent_id, thread_id=thread_id),
            body=await async_maybe_transform({"message": message}, thread_steer_params.ThreadSteerParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SteerResult,
        )


class ThreadsResourceWithRawResponse:
    def __init__(self, threads: ThreadsResource) -> None:
        self._threads = threads

        self.create = to_raw_response_wrapper(
            threads.create,
        )
        self.retrieve = to_raw_response_wrapper(
            threads.retrieve,
        )
        self.list = to_raw_response_wrapper(
            threads.list,
        )
        self.activity = to_raw_response_wrapper(
            threads.activity,
        )
        self.cancel = to_raw_response_wrapper(
            threads.cancel,
        )
        self.close = to_raw_response_wrapper(
            threads.close,
        )
        self.compact = to_raw_response_wrapper(
            threads.compact,
        )
        self.list_messages = to_raw_response_wrapper(
            threads.list_messages,
        )
        self.start_turn = to_raw_response_wrapper(
            threads.start_turn,
        )
        self.steer = to_raw_response_wrapper(
            threads.steer,
        )


class AsyncThreadsResourceWithRawResponse:
    def __init__(self, threads: AsyncThreadsResource) -> None:
        self._threads = threads

        self.create = async_to_raw_response_wrapper(
            threads.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            threads.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            threads.list,
        )
        self.activity = async_to_raw_response_wrapper(
            threads.activity,
        )
        self.cancel = async_to_raw_response_wrapper(
            threads.cancel,
        )
        self.close = async_to_raw_response_wrapper(
            threads.close,
        )
        self.compact = async_to_raw_response_wrapper(
            threads.compact,
        )
        self.list_messages = async_to_raw_response_wrapper(
            threads.list_messages,
        )
        self.start_turn = async_to_raw_response_wrapper(
            threads.start_turn,
        )
        self.steer = async_to_raw_response_wrapper(
            threads.steer,
        )


class ThreadsResourceWithStreamingResponse:
    def __init__(self, threads: ThreadsResource) -> None:
        self._threads = threads

        self.create = to_streamed_response_wrapper(
            threads.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            threads.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            threads.list,
        )
        self.activity = to_streamed_response_wrapper(
            threads.activity,
        )
        self.cancel = to_streamed_response_wrapper(
            threads.cancel,
        )
        self.close = to_streamed_response_wrapper(
            threads.close,
        )
        self.compact = to_streamed_response_wrapper(
            threads.compact,
        )
        self.list_messages = to_streamed_response_wrapper(
            threads.list_messages,
        )
        self.start_turn = to_streamed_response_wrapper(
            threads.start_turn,
        )
        self.steer = to_streamed_response_wrapper(
            threads.steer,
        )


class AsyncThreadsResourceWithStreamingResponse:
    def __init__(self, threads: AsyncThreadsResource) -> None:
        self._threads = threads

        self.create = async_to_streamed_response_wrapper(
            threads.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            threads.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            threads.list,
        )
        self.activity = async_to_streamed_response_wrapper(
            threads.activity,
        )
        self.cancel = async_to_streamed_response_wrapper(
            threads.cancel,
        )
        self.close = async_to_streamed_response_wrapper(
            threads.close,
        )
        self.compact = async_to_streamed_response_wrapper(
            threads.compact,
        )
        self.list_messages = async_to_streamed_response_wrapper(
            threads.list_messages,
        )
        self.start_turn = async_to_streamed_response_wrapper(
            threads.start_turn,
        )
        self.steer = async_to_streamed_response_wrapper(
            threads.steer,
        )
