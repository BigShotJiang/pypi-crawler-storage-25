# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import (
    context_list_params,
    context_write_params,
    context_delete_params,
    context_search_params,
    context_retrieve_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncEntriesCursorPage, SyncResultsCursorPage, AsyncEntriesCursorPage, AsyncResultsCursorPage
from ..types.entry import Entry
from .._base_client import AsyncPaginator, make_request_options
from ..types.entry_summary import EntrySummary
from ..types.search_result import SearchResult
from ..types.context_delete_response import ContextDeleteResponse

__all__ = ["ContextResource", "AsyncContextResource"]


class ContextResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ContextResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return ContextResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ContextResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return ContextResourceWithStreamingResponse(self)

    def retrieve(
        self,
        agent_id: str,
        *,
        key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Entry:
        """
        Retrieve context entry

        Args:
          key: Context entry key.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get(
            path_template("/agents/{agent_id}/context/entry", agent_id=agent_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"key": key}, context_retrieve_params.ContextRetrieveParams),
            ),
            cast_to=Entry,
        )

    def list(
        self,
        agent_id: str,
        *,
        cursor: str | Omit = omit,
        limit: str | Omit = omit,
        prefix: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncEntriesCursorPage[EntrySummary]:
        """
        List context entries

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          prefix: Optional key prefix filter.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/context", agent_id=agent_id),
            page=SyncEntriesCursorPage[EntrySummary],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "prefix": prefix,
                    },
                    context_list_params.ContextListParams,
                ),
            ),
            model=EntrySummary,
        )

    def delete(
        self,
        agent_id: str,
        *,
        key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ContextDeleteResponse:
        """
        Delete context entry

        Args:
          key: Context entry key.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._delete(
            path_template("/agents/{agent_id}/context/entry", agent_id=agent_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"key": key}, context_delete_params.ContextDeleteParams),
            ),
            cast_to=ContextDeleteResponse,
        )

    def search(
        self,
        agent_id: str,
        *,
        q: str,
        cursor: str | Omit = omit,
        limit: str | Omit = omit,
        prefix: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncResultsCursorPage[SearchResult]:
        """
        Search context

        Args:
          q: Search query.

          cursor: Opaque pagination cursor returned by a previous request.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          prefix: Optional key prefix filter.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/context/search", agent_id=agent_id),
            page=SyncResultsCursorPage[SearchResult],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "q": q,
                        "cursor": cursor,
                        "limit": limit,
                        "prefix": prefix,
                    },
                    context_search_params.ContextSearchParams,
                ),
            ),
            model=SearchResult,
        )

    def write(
        self,
        agent_id: str,
        *,
        content: str,
        key: str,
        expected_version: float | Omit = omit,
        mime_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Entry:
        """
        Update context entry

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._put(
            path_template("/agents/{agent_id}/context/entry", agent_id=agent_id),
            body=maybe_transform(
                {
                    "content": content,
                    "key": key,
                    "expected_version": expected_version,
                    "mime_type": mime_type,
                },
                context_write_params.ContextWriteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Entry,
        )


class AsyncContextResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncContextResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return AsyncContextResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncContextResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return AsyncContextResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        agent_id: str,
        *,
        key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Entry:
        """
        Retrieve context entry

        Args:
          key: Context entry key.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return await self._get(
            path_template("/agents/{agent_id}/context/entry", agent_id=agent_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"key": key}, context_retrieve_params.ContextRetrieveParams),
            ),
            cast_to=Entry,
        )

    def list(
        self,
        agent_id: str,
        *,
        cursor: str | Omit = omit,
        limit: str | Omit = omit,
        prefix: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[EntrySummary, AsyncEntriesCursorPage[EntrySummary]]:
        """
        List context entries

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          prefix: Optional key prefix filter.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/context", agent_id=agent_id),
            page=AsyncEntriesCursorPage[EntrySummary],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "prefix": prefix,
                    },
                    context_list_params.ContextListParams,
                ),
            ),
            model=EntrySummary,
        )

    async def delete(
        self,
        agent_id: str,
        *,
        key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ContextDeleteResponse:
        """
        Delete context entry

        Args:
          key: Context entry key.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return await self._delete(
            path_template("/agents/{agent_id}/context/entry", agent_id=agent_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"key": key}, context_delete_params.ContextDeleteParams),
            ),
            cast_to=ContextDeleteResponse,
        )

    def search(
        self,
        agent_id: str,
        *,
        q: str,
        cursor: str | Omit = omit,
        limit: str | Omit = omit,
        prefix: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[SearchResult, AsyncResultsCursorPage[SearchResult]]:
        """
        Search context

        Args:
          q: Search query.

          cursor: Opaque pagination cursor returned by a previous request.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          prefix: Optional key prefix filter.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/context/search", agent_id=agent_id),
            page=AsyncResultsCursorPage[SearchResult],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "q": q,
                        "cursor": cursor,
                        "limit": limit,
                        "prefix": prefix,
                    },
                    context_search_params.ContextSearchParams,
                ),
            ),
            model=SearchResult,
        )

    async def write(
        self,
        agent_id: str,
        *,
        content: str,
        key: str,
        expected_version: float | Omit = omit,
        mime_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Entry:
        """
        Update context entry

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return await self._put(
            path_template("/agents/{agent_id}/context/entry", agent_id=agent_id),
            body=await async_maybe_transform(
                {
                    "content": content,
                    "key": key,
                    "expected_version": expected_version,
                    "mime_type": mime_type,
                },
                context_write_params.ContextWriteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Entry,
        )


class ContextResourceWithRawResponse:
    def __init__(self, context: ContextResource) -> None:
        self._context = context

        self.retrieve = to_raw_response_wrapper(
            context.retrieve,
        )
        self.list = to_raw_response_wrapper(
            context.list,
        )
        self.delete = to_raw_response_wrapper(
            context.delete,
        )
        self.search = to_raw_response_wrapper(
            context.search,
        )
        self.write = to_raw_response_wrapper(
            context.write,
        )


class AsyncContextResourceWithRawResponse:
    def __init__(self, context: AsyncContextResource) -> None:
        self._context = context

        self.retrieve = async_to_raw_response_wrapper(
            context.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            context.list,
        )
        self.delete = async_to_raw_response_wrapper(
            context.delete,
        )
        self.search = async_to_raw_response_wrapper(
            context.search,
        )
        self.write = async_to_raw_response_wrapper(
            context.write,
        )


class ContextResourceWithStreamingResponse:
    def __init__(self, context: ContextResource) -> None:
        self._context = context

        self.retrieve = to_streamed_response_wrapper(
            context.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            context.list,
        )
        self.delete = to_streamed_response_wrapper(
            context.delete,
        )
        self.search = to_streamed_response_wrapper(
            context.search,
        )
        self.write = to_streamed_response_wrapper(
            context.write,
        )


class AsyncContextResourceWithStreamingResponse:
    def __init__(self, context: AsyncContextResource) -> None:
        self._context = context

        self.retrieve = async_to_streamed_response_wrapper(
            context.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            context.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            context.delete,
        )
        self.search = async_to_streamed_response_wrapper(
            context.search,
        )
        self.write = async_to_streamed_response_wrapper(
            context.write,
        )
