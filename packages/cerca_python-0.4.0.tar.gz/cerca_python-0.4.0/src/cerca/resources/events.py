# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Any, cast
from typing_extensions import Literal

import httpx

from ..types import (
    event_list_for_agent_params,
    event_list_for_fleet_params,
    event_list_for_thread_params,
    event_stream_for_agent_params,
    event_stream_for_fleet_params,
    event_stream_for_thread_events_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._streaming import Stream, AsyncStream
from ..pagination import SyncEventsCursorPage, AsyncEventsCursorPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.subscription_event import SubscriptionEvent
from ..types.thread_stream_event import ThreadStreamEvent

__all__ = ["EventsResource", "AsyncEventsResource"]


class EventsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> EventsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return EventsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> EventsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return EventsResourceWithStreamingResponse(self)

    def list_for_agent(
        self,
        agent_id: str,
        *,
        cursor: str | Omit = omit,
        events: str | Omit = omit,
        history: Literal["true", "false"] | Omit = omit,
        limit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncEventsCursorPage[SubscriptionEvent]:
        """
        List events

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          events: Comma-separated event type filter.

          history: When true, starts from the beginning of the retained buffer.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/events", agent_id=agent_id),
            page=SyncEventsCursorPage[SubscriptionEvent],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "events": events,
                        "history": history,
                        "limit": limit,
                    },
                    event_list_for_agent_params.EventListForAgentParams,
                ),
            ),
            model=SubscriptionEvent,
        )

    def list_for_fleet(
        self,
        fleet_id: str,
        *,
        cursor: str | Omit = omit,
        events: str | Omit = omit,
        history: Literal["true", "false"] | Omit = omit,
        limit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncEventsCursorPage[SubscriptionEvent]:
        """
        List events

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          events: Comma-separated event type filter.

          history: When true, starts from the beginning of the retained buffer.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        return self._get_api_list(
            path_template("/fleets/{fleet_id}/events", fleet_id=fleet_id),
            page=SyncEventsCursorPage[SubscriptionEvent],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "events": events,
                        "history": history,
                        "limit": limit,
                    },
                    event_list_for_fleet_params.EventListForFleetParams,
                ),
            ),
            model=SubscriptionEvent,
        )

    def list_for_thread(
        self,
        agent_id: str,
        thread_id: str,
        *,
        cursor: str | Omit = omit,
        events: str | Omit = omit,
        history: Literal["true", "false"] | Omit = omit,
        limit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncEventsCursorPage[SubscriptionEvent]:
        """
        List events

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          events: Comma-separated event type filter.

          history: When true, starts from the beginning of the retained buffer.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/threads/{thread_id}/events", agent_id=agent_id, thread_id=thread_id),
            page=SyncEventsCursorPage[SubscriptionEvent],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "events": events,
                        "history": history,
                        "limit": limit,
                    },
                    event_list_for_thread_params.EventListForThreadParams,
                ),
            ),
            model=SubscriptionEvent,
        )

    def stream_for_agent(
        self,
        agent_id: str,
        *,
        cursor: str | Omit = omit,
        events: str | Omit = omit,
        history: Literal["true", "false"] | Omit = omit,
        last_event_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Stream[SubscriptionEvent]:
        """Server-Sent Events stream.

        Each SSE data frame is JSON matching this response
        schema.

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          events: Comma-separated event type filter.

          history: When true, starts from the beginning of the retained buffer.

          last_event_id: Resume an event-log stream after the last received SSE event id.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        extra_headers = {"Accept": "text/event-stream", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Last-Event-ID": last_event_id}), **(extra_headers or {})}
        return self._get(
            path_template("/agents/{agent_id}/events/stream", agent_id=agent_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "events": events,
                        "history": history,
                    },
                    event_stream_for_agent_params.EventStreamForAgentParams,
                ),
            ),
            cast_to=SubscriptionEvent,
            stream=True,
            stream_cls=Stream[SubscriptionEvent],
        )

    def stream_for_fleet(
        self,
        fleet_id: str,
        *,
        cursor: str | Omit = omit,
        events: str | Omit = omit,
        history: Literal["true", "false"] | Omit = omit,
        last_event_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Stream[SubscriptionEvent]:
        """Server-Sent Events stream.

        Each SSE data frame is JSON matching this response
        schema.

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          events: Comma-separated event type filter.

          history: When true, starts from the beginning of the retained buffer.

          last_event_id: Resume an event-log stream after the last received SSE event id.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        extra_headers = {"Accept": "text/event-stream", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Last-Event-ID": last_event_id}), **(extra_headers or {})}
        return self._get(
            path_template("/fleets/{fleet_id}/events/stream", fleet_id=fleet_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "events": events,
                        "history": history,
                    },
                    event_stream_for_fleet_params.EventStreamForFleetParams,
                ),
            ),
            cast_to=SubscriptionEvent,
            stream=True,
            stream_cls=Stream[SubscriptionEvent],
        )

    def stream_for_thread(
        self,
        agent_id: str,
        thread_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Stream[ThreadStreamEvent]:
        """Server-Sent Events stream.

        Each SSE data frame is JSON matching this response
        schema.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        extra_headers = {"Accept": "text/event-stream", **(extra_headers or {})}
        return self._get(
            path_template("/agents/{agent_id}/threads/{thread_id}/stream", agent_id=agent_id, thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=cast(Any, ThreadStreamEvent),  # Union types cannot be passed in as arguments in the type system
            stream=True,
            stream_cls=Stream[ThreadStreamEvent],
        )

    def stream_for_thread_events(
        self,
        agent_id: str,
        thread_id: str,
        *,
        cursor: str | Omit = omit,
        events: str | Omit = omit,
        history: Literal["true", "false"] | Omit = omit,
        last_event_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Stream[SubscriptionEvent]:
        """Server-Sent Events stream.

        Each SSE data frame is JSON matching this response
        schema.

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          events: Comma-separated event type filter.

          history: When true, starts from the beginning of the retained buffer.

          last_event_id: Resume an event-log stream after the last received SSE event id.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        extra_headers = {"Accept": "text/event-stream", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Last-Event-ID": last_event_id}), **(extra_headers or {})}
        return self._get(
            path_template(
                "/agents/{agent_id}/threads/{thread_id}/events/stream", agent_id=agent_id, thread_id=thread_id
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "events": events,
                        "history": history,
                    },
                    event_stream_for_thread_events_params.EventStreamForThreadEventsParams,
                ),
            ),
            cast_to=SubscriptionEvent,
            stream=True,
            stream_cls=Stream[SubscriptionEvent],
        )


class AsyncEventsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncEventsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return AsyncEventsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncEventsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return AsyncEventsResourceWithStreamingResponse(self)

    def list_for_agent(
        self,
        agent_id: str,
        *,
        cursor: str | Omit = omit,
        events: str | Omit = omit,
        history: Literal["true", "false"] | Omit = omit,
        limit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[SubscriptionEvent, AsyncEventsCursorPage[SubscriptionEvent]]:
        """
        List events

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          events: Comma-separated event type filter.

          history: When true, starts from the beginning of the retained buffer.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/events", agent_id=agent_id),
            page=AsyncEventsCursorPage[SubscriptionEvent],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "events": events,
                        "history": history,
                        "limit": limit,
                    },
                    event_list_for_agent_params.EventListForAgentParams,
                ),
            ),
            model=SubscriptionEvent,
        )

    def list_for_fleet(
        self,
        fleet_id: str,
        *,
        cursor: str | Omit = omit,
        events: str | Omit = omit,
        history: Literal["true", "false"] | Omit = omit,
        limit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[SubscriptionEvent, AsyncEventsCursorPage[SubscriptionEvent]]:
        """
        List events

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          events: Comma-separated event type filter.

          history: When true, starts from the beginning of the retained buffer.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        return self._get_api_list(
            path_template("/fleets/{fleet_id}/events", fleet_id=fleet_id),
            page=AsyncEventsCursorPage[SubscriptionEvent],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "events": events,
                        "history": history,
                        "limit": limit,
                    },
                    event_list_for_fleet_params.EventListForFleetParams,
                ),
            ),
            model=SubscriptionEvent,
        )

    def list_for_thread(
        self,
        agent_id: str,
        thread_id: str,
        *,
        cursor: str | Omit = omit,
        events: str | Omit = omit,
        history: Literal["true", "false"] | Omit = omit,
        limit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[SubscriptionEvent, AsyncEventsCursorPage[SubscriptionEvent]]:
        """
        List events

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          events: Comma-separated event type filter.

          history: When true, starts from the beginning of the retained buffer.

          limit: Maximum number of items to return. Defaults to 20 and preserves parseInt
              semantics.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._get_api_list(
            path_template("/agents/{agent_id}/threads/{thread_id}/events", agent_id=agent_id, thread_id=thread_id),
            page=AsyncEventsCursorPage[SubscriptionEvent],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "events": events,
                        "history": history,
                        "limit": limit,
                    },
                    event_list_for_thread_params.EventListForThreadParams,
                ),
            ),
            model=SubscriptionEvent,
        )

    async def stream_for_agent(
        self,
        agent_id: str,
        *,
        cursor: str | Omit = omit,
        events: str | Omit = omit,
        history: Literal["true", "false"] | Omit = omit,
        last_event_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncStream[SubscriptionEvent]:
        """Server-Sent Events stream.

        Each SSE data frame is JSON matching this response
        schema.

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          events: Comma-separated event type filter.

          history: When true, starts from the beginning of the retained buffer.

          last_event_id: Resume an event-log stream after the last received SSE event id.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        extra_headers = {"Accept": "text/event-stream", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Last-Event-ID": last_event_id}), **(extra_headers or {})}
        return await self._get(
            path_template("/agents/{agent_id}/events/stream", agent_id=agent_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "events": events,
                        "history": history,
                    },
                    event_stream_for_agent_params.EventStreamForAgentParams,
                ),
            ),
            cast_to=SubscriptionEvent,
            stream=True,
            stream_cls=AsyncStream[SubscriptionEvent],
        )

    async def stream_for_fleet(
        self,
        fleet_id: str,
        *,
        cursor: str | Omit = omit,
        events: str | Omit = omit,
        history: Literal["true", "false"] | Omit = omit,
        last_event_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncStream[SubscriptionEvent]:
        """Server-Sent Events stream.

        Each SSE data frame is JSON matching this response
        schema.

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          events: Comma-separated event type filter.

          history: When true, starts from the beginning of the retained buffer.

          last_event_id: Resume an event-log stream after the last received SSE event id.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not fleet_id:
            raise ValueError(f"Expected a non-empty value for `fleet_id` but received {fleet_id!r}")
        extra_headers = {"Accept": "text/event-stream", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Last-Event-ID": last_event_id}), **(extra_headers or {})}
        return await self._get(
            path_template("/fleets/{fleet_id}/events/stream", fleet_id=fleet_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "events": events,
                        "history": history,
                    },
                    event_stream_for_fleet_params.EventStreamForFleetParams,
                ),
            ),
            cast_to=SubscriptionEvent,
            stream=True,
            stream_cls=AsyncStream[SubscriptionEvent],
        )

    async def stream_for_thread(
        self,
        agent_id: str,
        thread_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncStream[ThreadStreamEvent]:
        """Server-Sent Events stream.

        Each SSE data frame is JSON matching this response
        schema.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        extra_headers = {"Accept": "text/event-stream", **(extra_headers or {})}
        return await self._get(
            path_template("/agents/{agent_id}/threads/{thread_id}/stream", agent_id=agent_id, thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=cast(Any, ThreadStreamEvent),  # Union types cannot be passed in as arguments in the type system
            stream=True,
            stream_cls=AsyncStream[ThreadStreamEvent],
        )

    async def stream_for_thread_events(
        self,
        agent_id: str,
        thread_id: str,
        *,
        cursor: str | Omit = omit,
        events: str | Omit = omit,
        history: Literal["true", "false"] | Omit = omit,
        last_event_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncStream[SubscriptionEvent]:
        """Server-Sent Events stream.

        Each SSE data frame is JSON matching this response
        schema.

        Args:
          cursor: Opaque pagination cursor returned by a previous request.

          events: Comma-separated event type filter.

          history: When true, starts from the beginning of the retained buffer.

          last_event_id: Resume an event-log stream after the last received SSE event id.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        extra_headers = {"Accept": "text/event-stream", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Last-Event-ID": last_event_id}), **(extra_headers or {})}
        return await self._get(
            path_template(
                "/agents/{agent_id}/threads/{thread_id}/events/stream", agent_id=agent_id, thread_id=thread_id
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "events": events,
                        "history": history,
                    },
                    event_stream_for_thread_events_params.EventStreamForThreadEventsParams,
                ),
            ),
            cast_to=SubscriptionEvent,
            stream=True,
            stream_cls=AsyncStream[SubscriptionEvent],
        )


class EventsResourceWithRawResponse:
    def __init__(self, events: EventsResource) -> None:
        self._events = events

        self.list_for_agent = to_raw_response_wrapper(
            events.list_for_agent,
        )
        self.list_for_fleet = to_raw_response_wrapper(
            events.list_for_fleet,
        )
        self.list_for_thread = to_raw_response_wrapper(
            events.list_for_thread,
        )
        self.stream_for_agent = to_raw_response_wrapper(
            events.stream_for_agent,
        )
        self.stream_for_fleet = to_raw_response_wrapper(
            events.stream_for_fleet,
        )
        self.stream_for_thread = to_raw_response_wrapper(
            events.stream_for_thread,
        )
        self.stream_for_thread_events = to_raw_response_wrapper(
            events.stream_for_thread_events,
        )


class AsyncEventsResourceWithRawResponse:
    def __init__(self, events: AsyncEventsResource) -> None:
        self._events = events

        self.list_for_agent = async_to_raw_response_wrapper(
            events.list_for_agent,
        )
        self.list_for_fleet = async_to_raw_response_wrapper(
            events.list_for_fleet,
        )
        self.list_for_thread = async_to_raw_response_wrapper(
            events.list_for_thread,
        )
        self.stream_for_agent = async_to_raw_response_wrapper(
            events.stream_for_agent,
        )
        self.stream_for_fleet = async_to_raw_response_wrapper(
            events.stream_for_fleet,
        )
        self.stream_for_thread = async_to_raw_response_wrapper(
            events.stream_for_thread,
        )
        self.stream_for_thread_events = async_to_raw_response_wrapper(
            events.stream_for_thread_events,
        )


class EventsResourceWithStreamingResponse:
    def __init__(self, events: EventsResource) -> None:
        self._events = events

        self.list_for_agent = to_streamed_response_wrapper(
            events.list_for_agent,
        )
        self.list_for_fleet = to_streamed_response_wrapper(
            events.list_for_fleet,
        )
        self.list_for_thread = to_streamed_response_wrapper(
            events.list_for_thread,
        )
        self.stream_for_agent = to_streamed_response_wrapper(
            events.stream_for_agent,
        )
        self.stream_for_fleet = to_streamed_response_wrapper(
            events.stream_for_fleet,
        )
        self.stream_for_thread = to_streamed_response_wrapper(
            events.stream_for_thread,
        )
        self.stream_for_thread_events = to_streamed_response_wrapper(
            events.stream_for_thread_events,
        )


class AsyncEventsResourceWithStreamingResponse:
    def __init__(self, events: AsyncEventsResource) -> None:
        self._events = events

        self.list_for_agent = async_to_streamed_response_wrapper(
            events.list_for_agent,
        )
        self.list_for_fleet = async_to_streamed_response_wrapper(
            events.list_for_fleet,
        )
        self.list_for_thread = async_to_streamed_response_wrapper(
            events.list_for_thread,
        )
        self.stream_for_agent = async_to_streamed_response_wrapper(
            events.stream_for_agent,
        )
        self.stream_for_fleet = async_to_streamed_response_wrapper(
            events.stream_for_fleet,
        )
        self.stream_for_thread = async_to_streamed_response_wrapper(
            events.stream_for_thread,
        )
        self.stream_for_thread_events = async_to_streamed_response_wrapper(
            events.stream_for_thread_events,
        )
