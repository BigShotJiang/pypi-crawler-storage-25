# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..types import sandbox_exec_params, sandbox_read_params, sandbox_write_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.exec_result import ExecResult
from ..types.read_response import ReadResponse
from ..types.sandbox_write_response import SandboxWriteResponse

__all__ = ["SandboxResource", "AsyncSandboxResource"]


class SandboxResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> SandboxResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return SandboxResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SandboxResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return SandboxResourceWithStreamingResponse(self)

    def exec(
        self,
        agent_id: str,
        *,
        command: str,
        max_buffer: float | Omit = omit,
        execution_timeout: float | Omit = omit,
        workdir: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ExecResult:
        """Execute sandbox command

        Args:
          execution_timeout: Timeout in seconds.

        Runtime converts this to milliseconds.

          workdir: Optional sandbox working directory.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._post(
            path_template("/agents/{agent_id}/sandbox/exec", agent_id=agent_id),
            body=maybe_transform(
                {
                    "command": command,
                    "max_buffer": max_buffer,
                    "execution_timeout": execution_timeout,
                    "workdir": workdir,
                },
                sandbox_exec_params.SandboxExecParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ExecResult,
        )

    def read(
        self,
        agent_id: str,
        *,
        path: str,
        limit: float | Omit = omit,
        offset: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ReadResponse:
        """
        Read sandbox file

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._post(
            path_template("/agents/{agent_id}/sandbox/read", agent_id=agent_id),
            body=maybe_transform(
                {
                    "path": path,
                    "limit": limit,
                    "offset": offset,
                },
                sandbox_read_params.SandboxReadParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ReadResponse,
        )

    def write(
        self,
        agent_id: str,
        *,
        content: str,
        path: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SandboxWriteResponse:
        """
        Write sandbox file

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return self._post(
            path_template("/agents/{agent_id}/sandbox/write", agent_id=agent_id),
            body=maybe_transform(
                {
                    "content": content,
                    "path": path,
                },
                sandbox_write_params.SandboxWriteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SandboxWriteResponse,
        )


class AsyncSandboxResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncSandboxResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/matrices/cerca-python#accessing-raw-response-data-eg-headers
        """
        return AsyncSandboxResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSandboxResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/matrices/cerca-python#with_streaming_response
        """
        return AsyncSandboxResourceWithStreamingResponse(self)

    async def exec(
        self,
        agent_id: str,
        *,
        command: str,
        max_buffer: float | Omit = omit,
        execution_timeout: float | Omit = omit,
        workdir: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ExecResult:
        """Execute sandbox command

        Args:
          execution_timeout: Timeout in seconds.

        Runtime converts this to milliseconds.

          workdir: Optional sandbox working directory.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return await self._post(
            path_template("/agents/{agent_id}/sandbox/exec", agent_id=agent_id),
            body=await async_maybe_transform(
                {
                    "command": command,
                    "max_buffer": max_buffer,
                    "execution_timeout": execution_timeout,
                    "workdir": workdir,
                },
                sandbox_exec_params.SandboxExecParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ExecResult,
        )

    async def read(
        self,
        agent_id: str,
        *,
        path: str,
        limit: float | Omit = omit,
        offset: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ReadResponse:
        """
        Read sandbox file

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return await self._post(
            path_template("/agents/{agent_id}/sandbox/read", agent_id=agent_id),
            body=await async_maybe_transform(
                {
                    "path": path,
                    "limit": limit,
                    "offset": offset,
                },
                sandbox_read_params.SandboxReadParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ReadResponse,
        )

    async def write(
        self,
        agent_id: str,
        *,
        content: str,
        path: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SandboxWriteResponse:
        """
        Write sandbox file

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_id:
            raise ValueError(f"Expected a non-empty value for `agent_id` but received {agent_id!r}")
        return await self._post(
            path_template("/agents/{agent_id}/sandbox/write", agent_id=agent_id),
            body=await async_maybe_transform(
                {
                    "content": content,
                    "path": path,
                },
                sandbox_write_params.SandboxWriteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SandboxWriteResponse,
        )


class SandboxResourceWithRawResponse:
    def __init__(self, sandbox: SandboxResource) -> None:
        self._sandbox = sandbox

        self.exec = to_raw_response_wrapper(
            sandbox.exec,
        )
        self.read = to_raw_response_wrapper(
            sandbox.read,
        )
        self.write = to_raw_response_wrapper(
            sandbox.write,
        )


class AsyncSandboxResourceWithRawResponse:
    def __init__(self, sandbox: AsyncSandboxResource) -> None:
        self._sandbox = sandbox

        self.exec = async_to_raw_response_wrapper(
            sandbox.exec,
        )
        self.read = async_to_raw_response_wrapper(
            sandbox.read,
        )
        self.write = async_to_raw_response_wrapper(
            sandbox.write,
        )


class SandboxResourceWithStreamingResponse:
    def __init__(self, sandbox: SandboxResource) -> None:
        self._sandbox = sandbox

        self.exec = to_streamed_response_wrapper(
            sandbox.exec,
        )
        self.read = to_streamed_response_wrapper(
            sandbox.read,
        )
        self.write = to_streamed_response_wrapper(
            sandbox.write,
        )


class AsyncSandboxResourceWithStreamingResponse:
    def __init__(self, sandbox: AsyncSandboxResource) -> None:
        self._sandbox = sandbox

        self.exec = async_to_streamed_response_wrapper(
            sandbox.exec,
        )
        self.read = async_to_streamed_response_wrapper(
            sandbox.read,
        )
        self.write = async_to_streamed_response_wrapper(
            sandbox.write,
        )
