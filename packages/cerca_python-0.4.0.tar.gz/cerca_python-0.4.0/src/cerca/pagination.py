# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Generic, TypeVar, Optional
from typing_extensions import override

from pydantic import Field as FieldInfo

from ._base_client import BasePage, PageInfo, BaseSyncPage, BaseAsyncPage

__all__ = [
    "SyncAgentsCursorPage",
    "AsyncAgentsCursorPage",
    "SyncApprovalRequestsCursorPage",
    "AsyncApprovalRequestsCursorPage",
    "SyncConnectionsCursorPage",
    "AsyncConnectionsCursorPage",
    "SyncEntriesCursorPage",
    "AsyncEntriesCursorPage",
    "SyncEventsCursorPage",
    "AsyncEventsCursorPage",
    "SyncFleetsCursorPage",
    "AsyncFleetsCursorPage",
    "SyncGrantsCursorPage",
    "AsyncGrantsCursorPage",
    "SyncResultsCursorPage",
    "AsyncResultsCursorPage",
    "SyncSourcesCursorPage",
    "AsyncSourcesCursorPage",
    "SyncSubscriptionsCursorPage",
    "AsyncSubscriptionsCursorPage",
    "SyncThreadsCursorPage",
    "AsyncThreadsCursorPage",
    "SyncThreadMessagesCursorPage",
    "AsyncThreadMessagesCursorPage",
]

_T = TypeVar("_T")


class SyncAgentsCursorPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    agents: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        agents = self.agents
        if not agents:
            return []
        return agents

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class AsyncAgentsCursorPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    agents: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        agents = self.agents
        if not agents:
            return []
        return agents

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class SyncApprovalRequestsCursorPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    approvals: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        approvals = self.approvals
        if not approvals:
            return []
        return approvals

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class AsyncApprovalRequestsCursorPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    approvals: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        approvals = self.approvals
        if not approvals:
            return []
        return approvals

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class SyncConnectionsCursorPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    connections: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        connections = self.connections
        if not connections:
            return []
        return connections

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class AsyncConnectionsCursorPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    connections: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        connections = self.connections
        if not connections:
            return []
        return connections

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class SyncEntriesCursorPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    entries: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        entries = self.entries
        if not entries:
            return []
        return entries

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class AsyncEntriesCursorPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    entries: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        entries = self.entries
        if not entries:
            return []
        return entries

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class SyncEventsCursorPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    events: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        events = self.events
        if not events:
            return []
        return events

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class AsyncEventsCursorPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    events: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        events = self.events
        if not events:
            return []
        return events

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class SyncFleetsCursorPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    fleets: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        fleets = self.fleets
        if not fleets:
            return []
        return fleets

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class AsyncFleetsCursorPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    fleets: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        fleets = self.fleets
        if not fleets:
            return []
        return fleets

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class SyncGrantsCursorPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    grants: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        grants = self.grants
        if not grants:
            return []
        return grants

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class AsyncGrantsCursorPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    grants: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        grants = self.grants
        if not grants:
            return []
        return grants

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class SyncResultsCursorPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    results: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        results = self.results
        if not results:
            return []
        return results

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class AsyncResultsCursorPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    results: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        results = self.results
        if not results:
            return []
        return results

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class SyncSourcesCursorPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    sources: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        sources = self.sources
        if not sources:
            return []
        return sources

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class AsyncSourcesCursorPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    sources: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        sources = self.sources
        if not sources:
            return []
        return sources

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class SyncSubscriptionsCursorPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    subscriptions: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        subscriptions = self.subscriptions
        if not subscriptions:
            return []
        return subscriptions

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class AsyncSubscriptionsCursorPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    subscriptions: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        subscriptions = self.subscriptions
        if not subscriptions:
            return []
        return subscriptions

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class SyncThreadsCursorPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    threads: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        threads = self.threads
        if not threads:
            return []
        return threads

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class AsyncThreadsCursorPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    threads: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        threads = self.threads
        if not threads:
            return []
        return threads

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class SyncThreadMessagesCursorPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    messages: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        messages = self.messages
        if not messages:
            return []
        return messages

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})


class AsyncThreadMessagesCursorPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    messages: List[_T]
    cursor: Optional[str] = None
    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)

    @override
    def _get_page_items(self) -> List[_T]:
        messages = self.messages
        if not messages:
            return []
        return messages

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        cursor = self.cursor
        if not cursor:
            return None

        return PageInfo(params={"cursor": cursor})
