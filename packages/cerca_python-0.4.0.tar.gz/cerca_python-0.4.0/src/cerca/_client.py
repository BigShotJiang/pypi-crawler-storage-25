# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Mapping
from typing_extensions import Self, override

import httpx

from . import _exceptions
from ._qs import Querystring
from ._types import (
    Omit,
    Timeout,
    NotGiven,
    Transport,
    ProxiesTypes,
    RequestOptions,
    not_given,
)
from ._utils import (
    is_given,
    is_mapping_t,
    get_async_library,
)
from ._compat import cached_property
from ._version import __version__
from ._streaming import Stream as Stream, AsyncStream as AsyncStream
from ._exceptions import CercaError, APIStatusError
from ._base_client import (
    DEFAULT_MAX_RETRIES,
    SyncAPIClient,
    AsyncAPIClient,
)

if TYPE_CHECKING:
    from .resources import (
        auth,
        oauth,
        tools,
        agents,
        events,
        models,
        context,
        sandbox,
        threads,
        webhooks,
        schedules,
        connections,
        approval_grants,
        approval_requests,
    )
    from .resources.auth import AuthResource, AsyncAuthResource
    from .resources.oauth import OAuthResource, AsyncOAuthResource
    from .resources.tools import ToolsResource, AsyncToolsResource
    from .resources.agents import AgentsResource, AsyncAgentsResource
    from .resources.events import EventsResource, AsyncEventsResource
    from .resources.models import ModelsResource, AsyncModelsResource
    from .resources.context import ContextResource, AsyncContextResource
    from .resources.sandbox import SandboxResource, AsyncSandboxResource
    from .resources.threads import ThreadsResource, AsyncThreadsResource
    from .resources.webhooks import WebhooksResource, AsyncWebhooksResource
    from .resources.schedules import SchedulesResource, AsyncSchedulesResource
    from .resources.connections import ConnectionsResource, AsyncConnectionsResource
    from .resources.approval_grants import ApprovalGrantsResource, AsyncApprovalGrantsResource
    from .resources.approval_requests import ApprovalRequestsResource, AsyncApprovalRequestsResource

__all__ = ["Timeout", "Transport", "ProxiesTypes", "RequestOptions", "Cerca", "AsyncCerca", "Client", "AsyncClient"]


class Cerca(SyncAPIClient):
    # client options
    api_key: str

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#client) for more details.
        http_client: httpx.Client | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new synchronous Cerca client instance.

        This automatically infers the `api_key` argument from the `CERCA_API_KEY` environment variable if it is not provided.
        """
        if api_key is None:
            api_key = os.environ.get("CERCA_API_KEY")
        if api_key is None:
            raise CercaError(
                "The api_key client option must be set either by passing api_key to the client or by setting the CERCA_API_KEY environment variable"
            )
        self.api_key = api_key

        if base_url is None:
            base_url = os.environ.get("CERCA_BASE_URL")
        if base_url is None:
            base_url = f"https://api.cerca.dev"

        custom_headers_env = os.environ.get("CERCA_CUSTOM_HEADERS")
        if custom_headers_env is not None:
            parsed: dict[str, str] = {}
            for line in custom_headers_env.split("\n"):
                colon = line.find(":")
                if colon >= 0:
                    parsed[line[:colon].strip()] = line[colon + 1 :].strip()
            default_headers = {**parsed, **(default_headers if is_mapping_t(default_headers) else {})}

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

        self._default_stream_cls = Stream

    @cached_property
    def auth(self) -> AuthResource:
        from .resources.auth import AuthResource

        return AuthResource(self)

    @cached_property
    def oauth(self) -> OAuthResource:
        from .resources.oauth import OAuthResource

        return OAuthResource(self)

    @cached_property
    def connections(self) -> ConnectionsResource:
        from .resources.connections import ConnectionsResource

        return ConnectionsResource(self)

    @cached_property
    def tools(self) -> ToolsResource:
        from .resources.tools import ToolsResource

        return ToolsResource(self)

    @cached_property
    def webhooks(self) -> WebhooksResource:
        from .resources.webhooks import WebhooksResource

        return WebhooksResource(self)

    @cached_property
    def events(self) -> EventsResource:
        from .resources.events import EventsResource

        return EventsResource(self)

    @cached_property
    def agents(self) -> AgentsResource:
        from .resources.agents import AgentsResource

        return AgentsResource(self)

    @cached_property
    def threads(self) -> ThreadsResource:
        from .resources.threads import ThreadsResource

        return ThreadsResource(self)

    @cached_property
    def context(self) -> ContextResource:
        from .resources.context import ContextResource

        return ContextResource(self)

    @cached_property
    def schedules(self) -> SchedulesResource:
        from .resources.schedules import SchedulesResource

        return SchedulesResource(self)

    @cached_property
    def approval_requests(self) -> ApprovalRequestsResource:
        from .resources.approval_requests import ApprovalRequestsResource

        return ApprovalRequestsResource(self)

    @cached_property
    def approval_grants(self) -> ApprovalGrantsResource:
        from .resources.approval_grants import ApprovalGrantsResource

        return ApprovalGrantsResource(self)

    @cached_property
    def sandbox(self) -> SandboxResource:
        from .resources.sandbox import SandboxResource

        return SandboxResource(self)

    @cached_property
    def models(self) -> ModelsResource:
        from .resources.models import ModelsResource

        return ModelsResource(self)

    @cached_property
    def with_raw_response(self) -> CercaWithRawResponse:
        return CercaWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CercaWithStreamedResponse:
        return CercaWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @property
    @override
    def auth_headers(self) -> dict[str, str]:
        api_key = self.api_key
        return {"Authorization": f"Bearer {api_key}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": "false",
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.Client | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class AsyncCerca(AsyncAPIClient):
    # client options
    api_key: str

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultAsyncHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#asyncclient) for more details.
        http_client: httpx.AsyncClient | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new async AsyncCerca client instance.

        This automatically infers the `api_key` argument from the `CERCA_API_KEY` environment variable if it is not provided.
        """
        if api_key is None:
            api_key = os.environ.get("CERCA_API_KEY")
        if api_key is None:
            raise CercaError(
                "The api_key client option must be set either by passing api_key to the client or by setting the CERCA_API_KEY environment variable"
            )
        self.api_key = api_key

        if base_url is None:
            base_url = os.environ.get("CERCA_BASE_URL")
        if base_url is None:
            base_url = f"https://api.cerca.dev"

        custom_headers_env = os.environ.get("CERCA_CUSTOM_HEADERS")
        if custom_headers_env is not None:
            parsed: dict[str, str] = {}
            for line in custom_headers_env.split("\n"):
                colon = line.find(":")
                if colon >= 0:
                    parsed[line[:colon].strip()] = line[colon + 1 :].strip()
            default_headers = {**parsed, **(default_headers if is_mapping_t(default_headers) else {})}

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

        self._default_stream_cls = AsyncStream

    @cached_property
    def auth(self) -> AsyncAuthResource:
        from .resources.auth import AsyncAuthResource

        return AsyncAuthResource(self)

    @cached_property
    def oauth(self) -> AsyncOAuthResource:
        from .resources.oauth import AsyncOAuthResource

        return AsyncOAuthResource(self)

    @cached_property
    def connections(self) -> AsyncConnectionsResource:
        from .resources.connections import AsyncConnectionsResource

        return AsyncConnectionsResource(self)

    @cached_property
    def tools(self) -> AsyncToolsResource:
        from .resources.tools import AsyncToolsResource

        return AsyncToolsResource(self)

    @cached_property
    def webhooks(self) -> AsyncWebhooksResource:
        from .resources.webhooks import AsyncWebhooksResource

        return AsyncWebhooksResource(self)

    @cached_property
    def events(self) -> AsyncEventsResource:
        from .resources.events import AsyncEventsResource

        return AsyncEventsResource(self)

    @cached_property
    def agents(self) -> AsyncAgentsResource:
        from .resources.agents import AsyncAgentsResource

        return AsyncAgentsResource(self)

    @cached_property
    def threads(self) -> AsyncThreadsResource:
        from .resources.threads import AsyncThreadsResource

        return AsyncThreadsResource(self)

    @cached_property
    def context(self) -> AsyncContextResource:
        from .resources.context import AsyncContextResource

        return AsyncContextResource(self)

    @cached_property
    def schedules(self) -> AsyncSchedulesResource:
        from .resources.schedules import AsyncSchedulesResource

        return AsyncSchedulesResource(self)

    @cached_property
    def approval_requests(self) -> AsyncApprovalRequestsResource:
        from .resources.approval_requests import AsyncApprovalRequestsResource

        return AsyncApprovalRequestsResource(self)

    @cached_property
    def approval_grants(self) -> AsyncApprovalGrantsResource:
        from .resources.approval_grants import AsyncApprovalGrantsResource

        return AsyncApprovalGrantsResource(self)

    @cached_property
    def sandbox(self) -> AsyncSandboxResource:
        from .resources.sandbox import AsyncSandboxResource

        return AsyncSandboxResource(self)

    @cached_property
    def models(self) -> AsyncModelsResource:
        from .resources.models import AsyncModelsResource

        return AsyncModelsResource(self)

    @cached_property
    def with_raw_response(self) -> AsyncCercaWithRawResponse:
        return AsyncCercaWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCercaWithStreamedResponse:
        return AsyncCercaWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @property
    @override
    def auth_headers(self) -> dict[str, str]:
        api_key = self.api_key
        return {"Authorization": f"Bearer {api_key}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": f"async:{get_async_library()}",
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.AsyncClient | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class CercaWithRawResponse:
    _client: Cerca

    def __init__(self, client: Cerca) -> None:
        self._client = client

    @cached_property
    def auth(self) -> auth.AuthResourceWithRawResponse:
        from .resources.auth import AuthResourceWithRawResponse

        return AuthResourceWithRawResponse(self._client.auth)

    @cached_property
    def oauth(self) -> oauth.OAuthResourceWithRawResponse:
        from .resources.oauth import OAuthResourceWithRawResponse

        return OAuthResourceWithRawResponse(self._client.oauth)

    @cached_property
    def connections(self) -> connections.ConnectionsResourceWithRawResponse:
        from .resources.connections import ConnectionsResourceWithRawResponse

        return ConnectionsResourceWithRawResponse(self._client.connections)

    @cached_property
    def tools(self) -> tools.ToolsResourceWithRawResponse:
        from .resources.tools import ToolsResourceWithRawResponse

        return ToolsResourceWithRawResponse(self._client.tools)

    @cached_property
    def webhooks(self) -> webhooks.WebhooksResourceWithRawResponse:
        from .resources.webhooks import WebhooksResourceWithRawResponse

        return WebhooksResourceWithRawResponse(self._client.webhooks)

    @cached_property
    def events(self) -> events.EventsResourceWithRawResponse:
        from .resources.events import EventsResourceWithRawResponse

        return EventsResourceWithRawResponse(self._client.events)

    @cached_property
    def agents(self) -> agents.AgentsResourceWithRawResponse:
        from .resources.agents import AgentsResourceWithRawResponse

        return AgentsResourceWithRawResponse(self._client.agents)

    @cached_property
    def threads(self) -> threads.ThreadsResourceWithRawResponse:
        from .resources.threads import ThreadsResourceWithRawResponse

        return ThreadsResourceWithRawResponse(self._client.threads)

    @cached_property
    def context(self) -> context.ContextResourceWithRawResponse:
        from .resources.context import ContextResourceWithRawResponse

        return ContextResourceWithRawResponse(self._client.context)

    @cached_property
    def schedules(self) -> schedules.SchedulesResourceWithRawResponse:
        from .resources.schedules import SchedulesResourceWithRawResponse

        return SchedulesResourceWithRawResponse(self._client.schedules)

    @cached_property
    def approval_requests(self) -> approval_requests.ApprovalRequestsResourceWithRawResponse:
        from .resources.approval_requests import ApprovalRequestsResourceWithRawResponse

        return ApprovalRequestsResourceWithRawResponse(self._client.approval_requests)

    @cached_property
    def approval_grants(self) -> approval_grants.ApprovalGrantsResourceWithRawResponse:
        from .resources.approval_grants import ApprovalGrantsResourceWithRawResponse

        return ApprovalGrantsResourceWithRawResponse(self._client.approval_grants)

    @cached_property
    def sandbox(self) -> sandbox.SandboxResourceWithRawResponse:
        from .resources.sandbox import SandboxResourceWithRawResponse

        return SandboxResourceWithRawResponse(self._client.sandbox)

    @cached_property
    def models(self) -> models.ModelsResourceWithRawResponse:
        from .resources.models import ModelsResourceWithRawResponse

        return ModelsResourceWithRawResponse(self._client.models)


class AsyncCercaWithRawResponse:
    _client: AsyncCerca

    def __init__(self, client: AsyncCerca) -> None:
        self._client = client

    @cached_property
    def auth(self) -> auth.AsyncAuthResourceWithRawResponse:
        from .resources.auth import AsyncAuthResourceWithRawResponse

        return AsyncAuthResourceWithRawResponse(self._client.auth)

    @cached_property
    def oauth(self) -> oauth.AsyncOAuthResourceWithRawResponse:
        from .resources.oauth import AsyncOAuthResourceWithRawResponse

        return AsyncOAuthResourceWithRawResponse(self._client.oauth)

    @cached_property
    def connections(self) -> connections.AsyncConnectionsResourceWithRawResponse:
        from .resources.connections import AsyncConnectionsResourceWithRawResponse

        return AsyncConnectionsResourceWithRawResponse(self._client.connections)

    @cached_property
    def tools(self) -> tools.AsyncToolsResourceWithRawResponse:
        from .resources.tools import AsyncToolsResourceWithRawResponse

        return AsyncToolsResourceWithRawResponse(self._client.tools)

    @cached_property
    def webhooks(self) -> webhooks.AsyncWebhooksResourceWithRawResponse:
        from .resources.webhooks import AsyncWebhooksResourceWithRawResponse

        return AsyncWebhooksResourceWithRawResponse(self._client.webhooks)

    @cached_property
    def events(self) -> events.AsyncEventsResourceWithRawResponse:
        from .resources.events import AsyncEventsResourceWithRawResponse

        return AsyncEventsResourceWithRawResponse(self._client.events)

    @cached_property
    def agents(self) -> agents.AsyncAgentsResourceWithRawResponse:
        from .resources.agents import AsyncAgentsResourceWithRawResponse

        return AsyncAgentsResourceWithRawResponse(self._client.agents)

    @cached_property
    def threads(self) -> threads.AsyncThreadsResourceWithRawResponse:
        from .resources.threads import AsyncThreadsResourceWithRawResponse

        return AsyncThreadsResourceWithRawResponse(self._client.threads)

    @cached_property
    def context(self) -> context.AsyncContextResourceWithRawResponse:
        from .resources.context import AsyncContextResourceWithRawResponse

        return AsyncContextResourceWithRawResponse(self._client.context)

    @cached_property
    def schedules(self) -> schedules.AsyncSchedulesResourceWithRawResponse:
        from .resources.schedules import AsyncSchedulesResourceWithRawResponse

        return AsyncSchedulesResourceWithRawResponse(self._client.schedules)

    @cached_property
    def approval_requests(self) -> approval_requests.AsyncApprovalRequestsResourceWithRawResponse:
        from .resources.approval_requests import AsyncApprovalRequestsResourceWithRawResponse

        return AsyncApprovalRequestsResourceWithRawResponse(self._client.approval_requests)

    @cached_property
    def approval_grants(self) -> approval_grants.AsyncApprovalGrantsResourceWithRawResponse:
        from .resources.approval_grants import AsyncApprovalGrantsResourceWithRawResponse

        return AsyncApprovalGrantsResourceWithRawResponse(self._client.approval_grants)

    @cached_property
    def sandbox(self) -> sandbox.AsyncSandboxResourceWithRawResponse:
        from .resources.sandbox import AsyncSandboxResourceWithRawResponse

        return AsyncSandboxResourceWithRawResponse(self._client.sandbox)

    @cached_property
    def models(self) -> models.AsyncModelsResourceWithRawResponse:
        from .resources.models import AsyncModelsResourceWithRawResponse

        return AsyncModelsResourceWithRawResponse(self._client.models)


class CercaWithStreamedResponse:
    _client: Cerca

    def __init__(self, client: Cerca) -> None:
        self._client = client

    @cached_property
    def auth(self) -> auth.AuthResourceWithStreamingResponse:
        from .resources.auth import AuthResourceWithStreamingResponse

        return AuthResourceWithStreamingResponse(self._client.auth)

    @cached_property
    def oauth(self) -> oauth.OAuthResourceWithStreamingResponse:
        from .resources.oauth import OAuthResourceWithStreamingResponse

        return OAuthResourceWithStreamingResponse(self._client.oauth)

    @cached_property
    def connections(self) -> connections.ConnectionsResourceWithStreamingResponse:
        from .resources.connections import ConnectionsResourceWithStreamingResponse

        return ConnectionsResourceWithStreamingResponse(self._client.connections)

    @cached_property
    def tools(self) -> tools.ToolsResourceWithStreamingResponse:
        from .resources.tools import ToolsResourceWithStreamingResponse

        return ToolsResourceWithStreamingResponse(self._client.tools)

    @cached_property
    def webhooks(self) -> webhooks.WebhooksResourceWithStreamingResponse:
        from .resources.webhooks import WebhooksResourceWithStreamingResponse

        return WebhooksResourceWithStreamingResponse(self._client.webhooks)

    @cached_property
    def events(self) -> events.EventsResourceWithStreamingResponse:
        from .resources.events import EventsResourceWithStreamingResponse

        return EventsResourceWithStreamingResponse(self._client.events)

    @cached_property
    def agents(self) -> agents.AgentsResourceWithStreamingResponse:
        from .resources.agents import AgentsResourceWithStreamingResponse

        return AgentsResourceWithStreamingResponse(self._client.agents)

    @cached_property
    def threads(self) -> threads.ThreadsResourceWithStreamingResponse:
        from .resources.threads import ThreadsResourceWithStreamingResponse

        return ThreadsResourceWithStreamingResponse(self._client.threads)

    @cached_property
    def context(self) -> context.ContextResourceWithStreamingResponse:
        from .resources.context import ContextResourceWithStreamingResponse

        return ContextResourceWithStreamingResponse(self._client.context)

    @cached_property
    def schedules(self) -> schedules.SchedulesResourceWithStreamingResponse:
        from .resources.schedules import SchedulesResourceWithStreamingResponse

        return SchedulesResourceWithStreamingResponse(self._client.schedules)

    @cached_property
    def approval_requests(self) -> approval_requests.ApprovalRequestsResourceWithStreamingResponse:
        from .resources.approval_requests import ApprovalRequestsResourceWithStreamingResponse

        return ApprovalRequestsResourceWithStreamingResponse(self._client.approval_requests)

    @cached_property
    def approval_grants(self) -> approval_grants.ApprovalGrantsResourceWithStreamingResponse:
        from .resources.approval_grants import ApprovalGrantsResourceWithStreamingResponse

        return ApprovalGrantsResourceWithStreamingResponse(self._client.approval_grants)

    @cached_property
    def sandbox(self) -> sandbox.SandboxResourceWithStreamingResponse:
        from .resources.sandbox import SandboxResourceWithStreamingResponse

        return SandboxResourceWithStreamingResponse(self._client.sandbox)

    @cached_property
    def models(self) -> models.ModelsResourceWithStreamingResponse:
        from .resources.models import ModelsResourceWithStreamingResponse

        return ModelsResourceWithStreamingResponse(self._client.models)


class AsyncCercaWithStreamedResponse:
    _client: AsyncCerca

    def __init__(self, client: AsyncCerca) -> None:
        self._client = client

    @cached_property
    def auth(self) -> auth.AsyncAuthResourceWithStreamingResponse:
        from .resources.auth import AsyncAuthResourceWithStreamingResponse

        return AsyncAuthResourceWithStreamingResponse(self._client.auth)

    @cached_property
    def oauth(self) -> oauth.AsyncOAuthResourceWithStreamingResponse:
        from .resources.oauth import AsyncOAuthResourceWithStreamingResponse

        return AsyncOAuthResourceWithStreamingResponse(self._client.oauth)

    @cached_property
    def connections(self) -> connections.AsyncConnectionsResourceWithStreamingResponse:
        from .resources.connections import AsyncConnectionsResourceWithStreamingResponse

        return AsyncConnectionsResourceWithStreamingResponse(self._client.connections)

    @cached_property
    def tools(self) -> tools.AsyncToolsResourceWithStreamingResponse:
        from .resources.tools import AsyncToolsResourceWithStreamingResponse

        return AsyncToolsResourceWithStreamingResponse(self._client.tools)

    @cached_property
    def webhooks(self) -> webhooks.AsyncWebhooksResourceWithStreamingResponse:
        from .resources.webhooks import AsyncWebhooksResourceWithStreamingResponse

        return AsyncWebhooksResourceWithStreamingResponse(self._client.webhooks)

    @cached_property
    def events(self) -> events.AsyncEventsResourceWithStreamingResponse:
        from .resources.events import AsyncEventsResourceWithStreamingResponse

        return AsyncEventsResourceWithStreamingResponse(self._client.events)

    @cached_property
    def agents(self) -> agents.AsyncAgentsResourceWithStreamingResponse:
        from .resources.agents import AsyncAgentsResourceWithStreamingResponse

        return AsyncAgentsResourceWithStreamingResponse(self._client.agents)

    @cached_property
    def threads(self) -> threads.AsyncThreadsResourceWithStreamingResponse:
        from .resources.threads import AsyncThreadsResourceWithStreamingResponse

        return AsyncThreadsResourceWithStreamingResponse(self._client.threads)

    @cached_property
    def context(self) -> context.AsyncContextResourceWithStreamingResponse:
        from .resources.context import AsyncContextResourceWithStreamingResponse

        return AsyncContextResourceWithStreamingResponse(self._client.context)

    @cached_property
    def schedules(self) -> schedules.AsyncSchedulesResourceWithStreamingResponse:
        from .resources.schedules import AsyncSchedulesResourceWithStreamingResponse

        return AsyncSchedulesResourceWithStreamingResponse(self._client.schedules)

    @cached_property
    def approval_requests(self) -> approval_requests.AsyncApprovalRequestsResourceWithStreamingResponse:
        from .resources.approval_requests import AsyncApprovalRequestsResourceWithStreamingResponse

        return AsyncApprovalRequestsResourceWithStreamingResponse(self._client.approval_requests)

    @cached_property
    def approval_grants(self) -> approval_grants.AsyncApprovalGrantsResourceWithStreamingResponse:
        from .resources.approval_grants import AsyncApprovalGrantsResourceWithStreamingResponse

        return AsyncApprovalGrantsResourceWithStreamingResponse(self._client.approval_grants)

    @cached_property
    def sandbox(self) -> sandbox.AsyncSandboxResourceWithStreamingResponse:
        from .resources.sandbox import AsyncSandboxResourceWithStreamingResponse

        return AsyncSandboxResourceWithStreamingResponse(self._client.sandbox)

    @cached_property
    def models(self) -> models.AsyncModelsResourceWithStreamingResponse:
        from .resources.models import AsyncModelsResourceWithStreamingResponse

        return AsyncModelsResourceWithStreamingResponse(self._client.models)


Client = Cerca

AsyncClient = AsyncCerca
