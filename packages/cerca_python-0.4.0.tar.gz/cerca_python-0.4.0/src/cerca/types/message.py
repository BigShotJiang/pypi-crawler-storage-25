# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .content_block import ContentBlock

__all__ = ["Message"]


class Message(BaseModel):
    content: List[ContentBlock]

    created_at: str = FieldInfo(alias="createdAt")

    role: Literal["user", "assistant"]

    seq: float
