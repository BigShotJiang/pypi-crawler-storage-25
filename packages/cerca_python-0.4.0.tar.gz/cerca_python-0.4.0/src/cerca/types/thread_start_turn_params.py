# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

from .._types import SequenceNotStr
from .shared.tool_spec import ToolSpec

__all__ = ["ThreadStartTurnParams"]


class ThreadStartTurnParams(TypedDict, total=False):
    message: Required[str]

    model: str

    tools: SequenceNotStr[ToolSpec]
    """Per-turn tool subset.

    Omit to inherit the thread's current tools; pass [] to run this turn with no
    configurable tools. Provided entries can only narrow the agent/thread effective
    tools.
    """
