# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .activity_summary import ActivitySummary
from .thread_turn_summary import ThreadTurnSummary

__all__ = ["ActivityDetail"]


class ActivityDetail(ActivitySummary):
    error: Optional[str] = None

    recent_turns: List[ThreadTurnSummary] = FieldInfo(alias="recentTurns")
