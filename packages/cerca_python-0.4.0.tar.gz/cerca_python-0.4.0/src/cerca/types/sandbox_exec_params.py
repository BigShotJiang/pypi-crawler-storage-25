# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["SandboxExecParams"]


class SandboxExecParams(TypedDict, total=False):
    command: Required[str]

    max_buffer: Annotated[float, PropertyInfo(alias="maxBuffer")]

    execution_timeout: Annotated[float, PropertyInfo(alias="timeout")]
    """Timeout in seconds. Runtime converts this to milliseconds."""

    workdir: Optional[str]
    """Optional sandbox working directory."""
