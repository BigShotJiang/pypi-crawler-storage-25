# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["CredentialProvider"]

CredentialProvider: TypeAlias = Literal["google", "github", "slack", "linear", "notion", "custom", "webhook"]
