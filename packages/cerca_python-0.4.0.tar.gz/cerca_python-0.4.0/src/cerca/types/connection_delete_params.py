# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["ConnectionDeleteParams"]


class ConnectionDeleteParams(TypedDict, total=False):
    owner_type: Required[Annotated[Literal["organization", "fleet"], PropertyInfo(alias="ownerType")]]
    """Public connection owner type."""

    fleet_id: Annotated[str, PropertyInfo(alias="fleetId")]
    """Required when ownerType is fleet."""
