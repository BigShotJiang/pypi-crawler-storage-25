# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union
from typing_extensions import Literal, Required, Annotated, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["OAuthExchangeConfigParam", "ClientCredentialsOAuthExchange", "JwtBearerOAuthExchange"]


class ClientCredentialsOAuthExchange(TypedDict, total=False):
    client_id: Required[Annotated[str, PropertyInfo(alias="clientId")]]

    client_secret_connection_id: Required[Annotated[str, PropertyInfo(alias="clientSecretConnectionId")]]

    grant_type: Required[Annotated[Literal["client_credentials"], PropertyInfo(alias="grantType")]]

    token_url: Required[Annotated[str, PropertyInfo(alias="tokenUrl")]]

    audience: str

    extra_params: Annotated[Dict[str, str], PropertyInfo(alias="extraParams")]

    scopes: SequenceNotStr[str]


class JwtBearerOAuthExchange(TypedDict, total=False):
    assertion_connection_id: Required[Annotated[str, PropertyInfo(alias="assertionConnectionId")]]

    audience: Required[str]

    grant_type: Required[Annotated[Literal["jwt_bearer"], PropertyInfo(alias="grantType")]]

    issuer: Required[str]

    token_url: Required[Annotated[str, PropertyInfo(alias="tokenUrl")]]

    extra_params: Annotated[Dict[str, str], PropertyInfo(alias="extraParams")]

    scopes: SequenceNotStr[str]

    subject: str


OAuthExchangeConfigParam: TypeAlias = Union[ClientCredentialsOAuthExchange, JwtBearerOAuthExchange]
