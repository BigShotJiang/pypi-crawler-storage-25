# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["ErrorResponse"]


class ErrorResponse(BaseModel):
    error: str

    code: Optional[str] = None
    """Stable machine-readable error code when the API can provide one."""
