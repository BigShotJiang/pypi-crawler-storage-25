# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["ResponseNormalizationHint"]


class ResponseNormalizationHint(BaseModel):
    """How the HTTP response should be normalized for the agent."""

    mode: Literal["auto", "json", "markdown", "blob"]
