# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .metadata import Metadata
from .configuration import Configuration
from .execution_principal import ExecutionPrincipal
from .effective_configuration import EffectiveConfiguration

__all__ = ["Agent"]


class Agent(BaseModel):
    id: str

    configuration: Configuration

    created_at: str = FieldInfo(alias="createdAt")

    execution_principal: Optional[ExecutionPrincipal] = FieldInfo(alias="executionPrincipal", default=None)

    fleet_id: str = FieldInfo(alias="fleetId")

    metadata: Metadata
    """Arbitrary string metadata stored on an agent.

    Runtime enforces maximum key and value sizes.
    """

    org_id: str = FieldInfo(alias="orgId")

    updated_at: str = FieldInfo(alias="updatedAt")

    user_id: str = FieldInfo(alias="userId")

    effective: Optional[EffectiveConfiguration] = None
