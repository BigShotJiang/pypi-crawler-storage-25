# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .connection_owner_param import ConnectionOwnerParam

__all__ = ["ConnectionCreateParams"]


class ConnectionCreateParams(TypedDict, total=False):
    api_key: Required[Annotated[str, PropertyInfo(alias="apiKey")]]
    """API key secret. It is stored securely and is not returned."""

    owner: Required[ConnectionOwnerParam]
    """Public owner for a reusable connection.

    Organization owners use the authenticated organization; fleet owners add a
    fleetId.
    """

    provider: Required[str]
    """Credential provider to store an API key for."""

    account_label: Annotated[str, PropertyInfo(alias="accountLabel")]
    """Optional human-readable account label."""
