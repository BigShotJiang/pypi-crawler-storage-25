# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .tool_source_auth import ToolSourceAuth
from .tool_approval_mode import ToolApprovalMode
from .http_tool_definition import HTTPToolDefinition
from .http_tool_execution_policy import HTTPToolExecutionPolicy

__all__ = ["HTTPToolSource"]


class HTTPToolSource(BaseModel):
    id: str

    auth: ToolSourceAuth
    """Tool source authentication configuration.

    The `kind` field selects one of `none`, `api_key`, `oauth_exchange`, or
    `oauth_connection`.
    """

    created_at: str = FieldInfo(alias="createdAt")

    enabled: bool

    fleet_id: str = FieldInfo(alias="fleetId")

    namespace: str

    tools: List[HTTPToolDefinition]

    type: Literal["http"]

    updated_at: str = FieldInfo(alias="updatedAt")

    version: float

    approval: Optional[ToolApprovalMode] = None

    execution: Optional[HTTPToolExecutionPolicy] = None
    """HTTP tool execution retry and timeout policy."""
