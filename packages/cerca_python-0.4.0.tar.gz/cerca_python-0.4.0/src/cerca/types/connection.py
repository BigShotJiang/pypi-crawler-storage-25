# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .credential_type import CredentialType
from .connection_owner import ConnectionOwner
from .credential_provider import CredentialProvider

__all__ = ["Connection"]


class Connection(BaseModel):
    id: str

    account_label: Optional[str] = FieldInfo(alias="accountLabel", default=None)

    created_at: str = FieldInfo(alias="createdAt")

    owner: ConnectionOwner
    """Public owner for a reusable connection.

    Organization owners use the authenticated organization; fleet owners add a
    fleetId.
    """

    provider: CredentialProvider

    scopes: List[str]

    type: CredentialType

    updated_at: str = FieldInfo(alias="updatedAt")
