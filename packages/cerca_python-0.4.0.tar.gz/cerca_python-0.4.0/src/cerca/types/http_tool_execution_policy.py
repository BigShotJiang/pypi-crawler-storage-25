# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["HTTPToolExecutionPolicy"]


class HTTPToolExecutionPolicy(BaseModel):
    """HTTP tool execution retry and timeout policy."""

    idempotency_key_header: Optional[str] = FieldInfo(alias="idempotencyKeyHeader", default=None)

    max_attempts: Optional[float] = FieldInfo(alias="maxAttempts", default=None)

    retry_mode: Optional[Literal["disabled", "safe_only", "enabled"]] = FieldInfo(alias="retryMode", default=None)

    timeout_ms: Optional[float] = FieldInfo(alias="timeoutMs", default=None)
