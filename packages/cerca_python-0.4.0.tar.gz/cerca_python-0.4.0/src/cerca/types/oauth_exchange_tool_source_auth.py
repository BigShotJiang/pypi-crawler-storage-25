# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from .._models import BaseModel
from .auth_injection import AuthInjection
from .oauth_exchange_config import OAuthExchangeConfig

__all__ = ["OAuthExchangeToolSourceAuth"]


class OAuthExchangeToolSourceAuth(BaseModel):
    exchange: OAuthExchangeConfig
    """Source-owned OAuth exchange configuration.

    Public schemas use connection IDs for stored client secrets and assertions.
    """

    inject: AuthInjection
    """
    Where an API key or OAuth access token should be injected into outgoing
    tool-source requests.
    """

    kind: Literal["oauth_exchange"]
