# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .shared.tool_name import ToolName
from .shared.approval_mode import ApprovalMode
from .configuration_field_name import ConfigurationFieldName

__all__ = ["EffectiveConfiguration", "Approvals"]


class Approvals(BaseModel):
    timeout_ms: float = FieldInfo(alias="timeoutMs")

    tools: Dict[str, ApprovalMode]


class EffectiveConfiguration(BaseModel):
    approvals: Approvals

    approvals_writable_by_agent: bool = FieldInfo(alias="approvalsWritableByAgent")

    default_model: str = FieldInfo(alias="defaultModel")

    locked_by_fleet: List[ConfigurationFieldName] = FieldInfo(alias="lockedByFleet")

    resolved_from_fleet: List[ConfigurationFieldName] = FieldInfo(alias="resolvedFromFleet")

    tools: List[ToolName]
    """
    Effective internal runtime tools after applying fleet defaults, fleet locks, and
    the agent allowlist.
    """

    instructions: Optional[str] = None
