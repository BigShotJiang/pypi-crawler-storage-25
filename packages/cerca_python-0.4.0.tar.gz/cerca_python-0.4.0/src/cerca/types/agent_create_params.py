# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo
from .metadata_param import MetadataParam
from .configuration_param import ConfigurationParam

__all__ = ["AgentCreateParams"]


class AgentCreateParams(TypedDict, total=False):
    configuration: ConfigurationParam

    fleet_id: Annotated[str, PropertyInfo(alias="fleetId")]

    metadata: MetadataParam
    """Arbitrary string metadata stored on an agent.

    Runtime enforces maximum key and value sizes.
    """

    user_id: Annotated[str, PropertyInfo(alias="userId")]
