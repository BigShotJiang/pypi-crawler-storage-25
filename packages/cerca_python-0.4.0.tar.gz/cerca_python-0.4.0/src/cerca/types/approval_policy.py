# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .shared.approval_mode import ApprovalMode

__all__ = ["ApprovalPolicy"]


class ApprovalPolicy(BaseModel):
    timeout_ms: Optional[float] = FieldInfo(alias="timeoutMs", default=None)

    tools: Optional[Dict[str, ApprovalMode]] = None
