# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["SubThreadSummary"]


class SubThreadSummary(BaseModel):
    id: str

    completed_at: Optional[str] = FieldInfo(alias="completedAt", default=None)

    created_at: str = FieldInfo(alias="createdAt")

    message_count: float = FieldInfo(alias="messageCount")

    model: str

    parent_thread_id: Optional[str] = FieldInfo(alias="parentThreadId", default=None)

    result: Optional[str] = None

    schedule_id: Optional[str] = FieldInfo(alias="scheduleId", default=None)

    schedule_seq: Optional[float] = FieldInfo(alias="scheduleSeq", default=None)

    state: Literal["pending", "idle", "running", "awaiting", "closed"]
    """`pending` means the parent thread is still waiting on this sub-thread.

    Other values are the child thread lifecycle state.
    """

    step_count: float = FieldInfo(alias="stepCount")

    tool_use_id: Optional[str] = FieldInfo(alias="toolUseId", default=None)
