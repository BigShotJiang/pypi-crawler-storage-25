# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["EntrySummary"]


class EntrySummary(BaseModel):
    byte_length: float = FieldInfo(alias="byteLength")

    key: str

    updated_at: str = FieldInfo(alias="updatedAt")

    version: float

    mime_type: Optional[str] = FieldInfo(alias="mimeType", default=None)
