# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ApprovalGrant"]


class ApprovalGrant(BaseModel):
    id: str

    created_at: str = FieldInfo(alias="createdAt")

    created_by: Optional[str] = FieldInfo(alias="createdBy", default=None)

    expires_at: Optional[str] = FieldInfo(alias="expiresAt", default=None)

    grant_key: str = FieldInfo(alias="grantKey")

    scope: Literal["thread", "agent"]
