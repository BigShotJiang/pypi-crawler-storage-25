# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .status import Status
from .._utils import PropertyInfo

__all__ = ["ThreadListParams"]


class ThreadListParams(TypedDict, total=False):
    cursor: str
    """Opaque pagination cursor returned by a previous request."""

    limit: str
    """Maximum number of items to return.

    Defaults to 20 and preserves parseInt semantics.
    """

    schedule_id: Annotated[str, PropertyInfo(alias="scheduleId")]
    """Optional schedule id filter."""

    status: Status
    """Optional thread status filter."""
