# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["AgentListParams"]


class AgentListParams(TypedDict, total=False):
    active: Literal["true", "false"]
    """When set to true, lists only agents with active or awaiting threads."""

    cursor: str
    """Opaque pagination cursor returned by a previous request."""

    fleet_id: Annotated[str, PropertyInfo(alias="fleetId")]
    """Fleet to list agents from.

    Defaults to the API key's default fleet when omitted.
    """

    limit: str
    """Maximum number of items to return.

    Defaults to 20 and preserves parseInt semantics.
    """
