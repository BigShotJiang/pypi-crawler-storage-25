# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .shared.tool_name import ToolName

__all__ = ["ToolDescriptor"]


class ToolDescriptor(BaseModel):
    """A built-in or configurable runtime tool currently available to the agent."""

    approval_source: Literal["agent", "env", "catalog"] = FieldInfo(alias="approvalSource")

    category: Literal["builtIn", "configurable"]

    description: str

    input_schema: Dict[str, object] = FieldInfo(alias="inputSchema")
    """JSON Schema object describing tool input parameters."""

    name: ToolName

    requires_approval: bool = FieldInfo(alias="requiresApproval")
