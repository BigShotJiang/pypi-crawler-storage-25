# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["ApprovalRequestListParams"]


class ApprovalRequestListParams(TypedDict, total=False):
    cursor: str
    """Opaque pagination cursor returned by a previous request."""

    limit: str
    """Maximum number of items to return.

    Defaults to 20 and preserves parseInt semantics.
    """

    thread_id: Annotated[str, PropertyInfo(alias="threadId")]
    """Optional thread id filter."""
