# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["ContextSearchParams"]


class ContextSearchParams(TypedDict, total=False):
    q: Required[str]
    """Search query."""

    cursor: str
    """Opaque pagination cursor returned by a previous request."""

    limit: str
    """Maximum number of items to return.

    Defaults to 20 and preserves parseInt semantics.
    """

    prefix: str
    """Optional key prefix filter."""
