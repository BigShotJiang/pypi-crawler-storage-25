# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .shared.tool_spec import ToolSpec

__all__ = ["Schedule"]


class Schedule(BaseModel):
    id: str

    created_at: str = FieldInfo(alias="createdAt")

    enabled: bool

    message: str

    name: str

    next_at: Optional[str] = FieldInfo(alias="nextAt", default=None)

    timezone: str

    updated_at: str = FieldInfo(alias="updatedAt")

    cron: Optional[str] = None

    instructions: Optional[str] = None

    model: Optional[str] = None

    run_at: Optional[datetime] = FieldInfo(alias="runAt", default=None)

    tools: Optional[List[ToolSpec]] = None
    """Per-schedule tool subset.

    Scheduled threads inherit the agent's effective tools when omitted and can only
    narrow them when provided.
    """
