# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .tool_approval_mode import ToolApprovalMode
from .http_endpoint_param import HTTPEndpointParam
from .http_tool_execution_policy_param import HTTPToolExecutionPolicyParam
from .response_normalization_hint_param import ResponseNormalizationHintParam

__all__ = ["HTTPToolDefinitionParam"]


class HTTPToolDefinitionParam(TypedDict, total=False):
    """Definition for a single HTTP tool exposed by a tool source."""

    description: Required[str]

    endpoint: Required[HTTPEndpointParam]
    """HTTP endpoint invoked when the tool is called."""

    input_schema: Required[Annotated[Dict[str, object], PropertyInfo(alias="inputSchema")]]
    """JSON Schema object describing tool input parameters."""

    name: Required[str]

    approval: ToolApprovalMode

    execution: HTTPToolExecutionPolicyParam
    """HTTP tool execution retry and timeout policy."""

    response: ResponseNormalizationHintParam
    """How the HTTP response should be normalized for the agent."""
