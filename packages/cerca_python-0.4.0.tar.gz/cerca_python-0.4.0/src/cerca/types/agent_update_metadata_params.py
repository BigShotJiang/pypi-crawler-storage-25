# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

from .metadata_param import MetadataParam

__all__ = ["AgentUpdateMetadataParams"]


class AgentUpdateMetadataParams(TypedDict, total=False):
    metadata: Required[MetadataParam]
    """Arbitrary string metadata stored on an agent.

    Runtime enforces maximum key and value sizes.
    """
