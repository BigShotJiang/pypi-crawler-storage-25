# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ReadResponse"]


class ReadResponse(BaseModel):
    bytes_read: float = FieldInfo(alias="bytesRead")

    content: str
