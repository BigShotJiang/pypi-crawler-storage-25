# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .shared.tool_name import ToolName

__all__ = ["ApprovalRequest"]


class ApprovalRequest(BaseModel):
    id: str

    created_at: str = FieldInfo(alias="createdAt")

    input: object
    """Parsed JSON tool input from the original tool call.

    Generated SDKs may expose this as unknown or Any.
    """

    resolved_at: Optional[str] = FieldInfo(alias="resolvedAt", default=None)

    runtime_tool_name: ToolName = FieldInfo(alias="runtimeToolName")

    status: Literal["pending", "approved", "denied", "cancelled", "timed_out"]

    thread_id: str = FieldInfo(alias="threadId")

    timeout_at: Optional[str] = FieldInfo(alias="timeoutAt", default=None)

    timeout_ms: Optional[float] = FieldInfo(alias="timeoutMs", default=None)

    tool_index: float = FieldInfo(alias="toolIndex")

    tool_name: str = FieldInfo(alias="toolName")

    tool_use_id: str = FieldInfo(alias="toolUseId")

    turn_id: str = FieldInfo(alias="turnId")

    tool_source_id: Optional[str] = FieldInfo(alias="toolSourceId", default=None)

    tool_source_version: Optional[float] = FieldInfo(alias="toolSourceVersion", default=None)
