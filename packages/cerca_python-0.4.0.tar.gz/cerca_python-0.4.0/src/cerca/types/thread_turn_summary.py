# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ThreadTurnSummary"]


class ThreadTurnSummary(BaseModel):
    activity: Optional[str] = None

    completed_at: str = FieldInfo(alias="completedAt")

    message_count: float = FieldInfo(alias="messageCount")

    next_step: Optional[str] = FieldInfo(alias="nextStep", default=None)

    status: Literal["completed", "failed"]

    turn_seq: float = FieldInfo(alias="turnSeq")
