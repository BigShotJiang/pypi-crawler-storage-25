# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .fleet import Fleet
from .._models import BaseModel

__all__ = ["AuthFleetsResponse"]


class AuthFleetsResponse(BaseModel):
    cursor: Optional[str] = None

    fleets: List[Fleet]

    has_more: bool = FieldInfo(alias="hasMore")
