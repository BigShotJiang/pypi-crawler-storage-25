# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ExecResult"]


class ExecResult(BaseModel):
    exit_code: Optional[float] = FieldInfo(alias="exitCode", default=None)

    handle: str

    state: Literal["running", "exited"]

    stderr: str

    stderr_offset: float = FieldInfo(alias="stderrOffset")

    stdout: str

    stdout_offset: float = FieldInfo(alias="stdoutOffset")
