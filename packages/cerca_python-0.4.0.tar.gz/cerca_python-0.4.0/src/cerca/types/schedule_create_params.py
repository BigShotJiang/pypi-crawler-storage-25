# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo
from .shared.tool_spec import ToolSpec

__all__ = ["ScheduleCreateParams"]


class ScheduleCreateParams(TypedDict, total=False):
    message: Required[str]

    name: Required[str]

    cron: str

    instructions: str

    model: str

    run_at: Annotated[Union[str, datetime], PropertyInfo(alias="runAt", format="iso8601")]

    timezone: str

    tools: SequenceNotStr[ToolSpec]
    """Per-schedule tool subset.

    When the schedule starts a thread, these tools can only narrow the agent's
    effective tools.
    """
