# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo
from .shared.tool_spec import ToolSpec

__all__ = ["ScheduleUpdateParams"]


class ScheduleUpdateParams(TypedDict, total=False):
    cron: str

    enabled: bool

    instructions: str

    message: str

    model: str

    name: str

    run_at: Annotated[Union[str, datetime], PropertyInfo(alias="runAt", format="iso8601")]

    timezone: str

    tools: SequenceNotStr[ToolSpec]
    """Per-schedule tool subset.

    When updated, these tools can only narrow the agent's effective tools for future
    scheduled threads.
    """
