# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo
from .shared.approval_mode import ApprovalMode

__all__ = ["ApprovalPolicyParam"]


class ApprovalPolicyParam(TypedDict, total=False):
    timeout_ms: Annotated[float, PropertyInfo(alias="timeoutMs")]

    tools: Dict[str, ApprovalMode]
