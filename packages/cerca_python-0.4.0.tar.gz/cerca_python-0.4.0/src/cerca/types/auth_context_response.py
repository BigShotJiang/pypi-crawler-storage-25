# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["AuthContextResponse"]


class AuthContextResponse(BaseModel):
    key_id: str = FieldInfo(alias="keyId")

    org_id: str = FieldInfo(alias="orgId")
