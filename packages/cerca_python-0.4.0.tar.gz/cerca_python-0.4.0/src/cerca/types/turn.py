# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .token_usage import TokenUsage

__all__ = ["Turn"]


class Turn(BaseModel):
    id: str

    completed_at: Optional[str] = FieldInfo(alias="completedAt", default=None)

    end_message_seq: Optional[float] = FieldInfo(alias="endMessageSeq", default=None)

    error: Optional[str] = None

    message: str

    result: Optional[str] = None

    seq: float

    started_at: str = FieldInfo(alias="startedAt")

    start_message_seq: float = FieldInfo(alias="startMessageSeq")

    status: Literal["running", "completed", "failed"]

    thread_id: str = FieldInfo(alias="threadId")

    token_usage: Optional[TokenUsage] = FieldInfo(alias="tokenUsage", default=None)
