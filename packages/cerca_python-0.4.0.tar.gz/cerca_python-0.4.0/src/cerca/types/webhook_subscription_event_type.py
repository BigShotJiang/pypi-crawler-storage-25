# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["WebhookSubscriptionEventType"]

WebhookSubscriptionEventType: TypeAlias = Literal[
    "agent.created",
    "agent.updated",
    "agent.deleted",
    "thread.created",
    "thread.status.changed",
    "thread.completed",
    "thread.failed",
    "turn.created",
    "turn.completed",
    "turn.failed",
    "message.created",
    "approval.requested",
    "approval.resolved",
    "approval.granted",
    "schedule.created",
    "schedule.deleted",
    "schedule.triggered",
    "connection.attached",
    "connection.detached",
]
