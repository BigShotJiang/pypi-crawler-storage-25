# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .tool_connection_metadata import ToolConnectionMetadata

__all__ = ["DiscoveredTool"]


class DiscoveredTool(BaseModel):
    """An external provider or tool-source tool currently available to the agent."""

    approval: Literal["always", "never"]

    category: Literal["external"]

    description: str

    input_schema: Dict[str, object] = FieldInfo(alias="inputSchema")
    """JSON Schema object describing tool input parameters."""

    name: str

    origin: Literal["builtin", "tool_source"]

    source: str

    account_label: Optional[str] = FieldInfo(alias="accountLabel", default=None)

    connection_id: Optional[str] = FieldInfo(alias="connectionId", default=None)

    connection_metadata: Optional[ToolConnectionMetadata] = FieldInfo(alias="connectionMetadata", default=None)

    source_id: Optional[str] = FieldInfo(alias="sourceId", default=None)

    source_version: Optional[float] = FieldInfo(alias="sourceVersion", default=None)
