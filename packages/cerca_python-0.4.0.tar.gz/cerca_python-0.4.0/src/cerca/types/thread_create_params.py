# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo
from .shared.tool_spec import ToolSpec

__all__ = ["ThreadCreateParams"]


class ThreadCreateParams(TypedDict, total=False):
    instructions: str

    message: str

    model: str

    system_prompt: Annotated[str, PropertyInfo(alias="systemPrompt")]
    """Deprecated alias for `instructions`; accepted for backwards compatibility."""

    tools: SequenceNotStr[ToolSpec]
    """Per-thread tool subset.

    Omit to inherit the agent's full effective tools; pass [] to run with no
    configurable tools. Provided entries can only narrow the agent's effective
    tools.
    """
