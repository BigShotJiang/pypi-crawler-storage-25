# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["HTTPToolExecutionPolicyParam"]


class HTTPToolExecutionPolicyParam(TypedDict, total=False):
    """HTTP tool execution retry and timeout policy."""

    idempotency_key_header: Annotated[str, PropertyInfo(alias="idempotencyKeyHeader")]

    max_attempts: Annotated[float, PropertyInfo(alias="maxAttempts")]

    retry_mode: Annotated[Literal["disabled", "safe_only", "enabled"], PropertyInfo(alias="retryMode")]

    timeout_ms: Annotated[float, PropertyInfo(alias="timeoutMs")]
