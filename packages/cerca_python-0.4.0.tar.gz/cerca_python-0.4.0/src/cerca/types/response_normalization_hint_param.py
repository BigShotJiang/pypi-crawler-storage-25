# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["ResponseNormalizationHintParam"]


class ResponseNormalizationHintParam(TypedDict, total=False):
    """How the HTTP response should be normalized for the agent."""

    mode: Required[Literal["auto", "json", "markdown", "blob"]]
