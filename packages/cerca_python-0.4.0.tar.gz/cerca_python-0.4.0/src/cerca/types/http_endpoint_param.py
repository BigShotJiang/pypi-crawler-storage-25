# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Required, TypedDict

__all__ = ["HTTPEndpointParam"]


class HTTPEndpointParam(TypedDict, total=False):
    """HTTP endpoint invoked when the tool is called."""

    method: Required[Literal["GET", "POST", "PUT", "PATCH", "DELETE"]]

    url: Required[str]

    body: Literal["json_params"]

    headers: Dict[str, str]

    path: Dict[str, str]

    query: Dict[str, str]
