# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["ContextWriteParams"]


class ContextWriteParams(TypedDict, total=False):
    content: Required[str]

    key: Required[str]

    expected_version: Annotated[float, PropertyInfo(alias="expectedVersion")]

    mime_type: Annotated[str, PropertyInfo(alias="mimeType")]
