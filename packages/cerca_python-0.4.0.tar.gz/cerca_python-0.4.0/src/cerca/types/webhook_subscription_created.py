# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .webhook_event_type import WebhookEventType

__all__ = ["WebhookSubscriptionCreated"]


class WebhookSubscriptionCreated(BaseModel):
    """Webhook subscription response for create and rotate.

    Includes the one-time `secret` field.
    """

    id: str

    created_at: str = FieldInfo(alias="createdAt")

    enabled: bool

    events: List[WebhookEventType]

    fleet_id: str = FieldInfo(alias="fleetId")

    secret: str
    """One-time webhook signing secret returned only by create and rotate responses.

    The field name is `secret`.
    """

    updated_at: str = FieldInfo(alias="updatedAt")

    url: str
