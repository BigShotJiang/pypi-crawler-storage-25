# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .approval_policy import ApprovalPolicy
from .shared.tool_spec import ToolSpec

__all__ = ["Configuration"]


class Configuration(BaseModel):
    approvals: Optional[ApprovalPolicy] = None

    default_model: Optional[str] = FieldInfo(alias="defaultModel", default=None)

    instructions: Optional[str] = None

    tools: Optional[List[ToolSpec]] = None
    """Agent tool allowlist.

    These tools are subject to fleet defaults and locks, and thread or turn requests
    may only narrow the resulting effective tools.
    """
