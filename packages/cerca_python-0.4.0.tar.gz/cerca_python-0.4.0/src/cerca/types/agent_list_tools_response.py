# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .tool import Tool
from .._models import BaseModel
from .source_warning import SourceWarning

__all__ = ["AgentListToolsResponse"]


class AgentListToolsResponse(BaseModel):
    """Response for GET /agents/{agentId}/tools.

    The tools field is an inspection list, not a configuration request field.
    """

    tools: List[Tool]
    """Unified list of runtime and external tools currently available to the agent."""

    source_warnings: Optional[List[SourceWarning]] = FieldInfo(alias="sourceWarnings", default=None)
