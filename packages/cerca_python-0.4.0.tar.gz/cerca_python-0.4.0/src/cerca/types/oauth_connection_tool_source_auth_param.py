# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo
from .auth_injection_param import AuthInjectionParam

__all__ = ["OAuthConnectionToolSourceAuthParam"]


class OAuthConnectionToolSourceAuthParam(TypedDict, total=False):
    kind: Required[Literal["oauth_connection"]]

    provider: Required[str]

    inject: AuthInjectionParam
    """
    Where an API key or OAuth access token should be injected into outgoing
    tool-source requests.
    """

    required_scopes: Annotated[SequenceNotStr[str], PropertyInfo(alias="requiredScopes")]
