# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .metadata import Metadata

__all__ = ["AgentSummary"]


class AgentSummary(BaseModel):
    id: str

    active_thread_count: float = FieldInfo(alias="activeThreadCount")

    awaiting_thread_count: float = FieldInfo(alias="awaitingThreadCount")

    created_at: str = FieldInfo(alias="createdAt")

    default_model: Optional[str] = FieldInfo(alias="defaultModel", default=None)

    fleet_id: str = FieldInfo(alias="fleetId")

    metadata: Metadata
    """Arbitrary string metadata stored on an agent.

    Runtime enforces maximum key and value sizes.
    """

    org_id: str = FieldInfo(alias="orgId")

    updated_at: str = FieldInfo(alias="updatedAt")

    user_id: str = FieldInfo(alias="userId")
