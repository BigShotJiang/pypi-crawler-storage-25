# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .runtime_webhook_event import RuntimeWebhookEvent

__all__ = ["SubscriptionEvent"]


class SubscriptionEvent(BaseModel):
    event: RuntimeWebhookEvent

    seq: float
