# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["TokenUsage"]


class TokenUsage(BaseModel):
    input_tokens: float = FieldInfo(alias="inputTokens")

    output_tokens: float = FieldInfo(alias="outputTokens")
