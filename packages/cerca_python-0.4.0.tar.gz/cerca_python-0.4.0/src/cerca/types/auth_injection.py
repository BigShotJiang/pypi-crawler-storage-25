# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from .._utils import PropertyInfo
from .._models import BaseModel

__all__ = ["AuthInjection", "HeaderAuthInjection", "QueryAuthInjection"]


class HeaderAuthInjection(BaseModel):
    location: Literal["header"]

    name: str

    value: Optional[str] = None
    """Optional value template.

    For OAuth connection auth, use values such as `Bearer ${token}`.
    """


class QueryAuthInjection(BaseModel):
    location: Literal["query"]

    name: str


AuthInjection: TypeAlias = Annotated[
    Union[HeaderAuthInjection, QueryAuthInjection], PropertyInfo(discriminator="location")
]
