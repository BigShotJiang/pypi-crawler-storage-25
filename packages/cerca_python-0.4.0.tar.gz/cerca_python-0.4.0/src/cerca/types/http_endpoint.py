# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["HTTPEndpoint"]


class HTTPEndpoint(BaseModel):
    """HTTP endpoint invoked when the tool is called."""

    method: Literal["GET", "POST", "PUT", "PATCH", "DELETE"]

    url: str

    body: Optional[Literal["json_params"]] = None

    headers: Optional[Dict[str, str]] = None

    path: Optional[Dict[str, str]] = None

    query: Optional[Dict[str, str]] = None
