# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["EventStreamForAgentParams"]


class EventStreamForAgentParams(TypedDict, total=False):
    cursor: str
    """Opaque pagination cursor returned by a previous request."""

    events: str
    """Comma-separated event type filter."""

    history: Literal["true", "false"]
    """When true, starts from the beginning of the retained buffer."""

    last_event_id: Annotated[str, PropertyInfo(alias="Last-Event-ID")]
    """Resume an event-log stream after the last received SSE event id."""
