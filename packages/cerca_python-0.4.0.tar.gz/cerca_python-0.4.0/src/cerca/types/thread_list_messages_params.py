# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["ThreadListMessagesParams"]


class ThreadListMessagesParams(TypedDict, total=False):
    cursor: str
    """Cursor returned by a previous thread messages response."""

    fleet_id: Annotated[str, PropertyInfo(alias="fleetId")]
    """Optional fleet id for index-backed authorization."""

    limit: str
    """Maximum number of messages to include, capped at 500."""
