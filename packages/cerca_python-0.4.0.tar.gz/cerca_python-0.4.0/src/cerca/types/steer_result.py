# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .status import Status
from .._models import BaseModel

__all__ = ["SteerResult"]


class SteerResult(BaseModel):
    status: Literal["enqueued", "turn_started"]

    thread_status: Status = FieldInfo(alias="threadStatus")
    """`idle` threads can accept a new turn or be closed.

    `running` threads have an active turn. `awaiting` threads are paused on external
    input such as approvals. `closed` threads are terminal.
    """

    turn_id: str = FieldInfo(alias="turnId")
