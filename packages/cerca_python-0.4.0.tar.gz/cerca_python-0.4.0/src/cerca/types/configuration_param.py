# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo
from .shared.tool_spec import ToolSpec
from .approval_policy_param import ApprovalPolicyParam

__all__ = ["ConfigurationParam"]


class ConfigurationParam(TypedDict, total=False):
    approvals: ApprovalPolicyParam

    default_model: Annotated[str, PropertyInfo(alias="defaultModel")]

    instructions: str

    tools: SequenceNotStr[ToolSpec]
    """Agent tool allowlist.

    These tools are subject to fleet defaults and locks, and thread or turn requests
    may only narrow the resulting effective tools.
    """
