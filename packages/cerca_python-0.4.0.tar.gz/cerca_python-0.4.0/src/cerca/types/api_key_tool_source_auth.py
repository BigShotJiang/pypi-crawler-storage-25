# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .auth_injection import AuthInjection

__all__ = ["APIKeyToolSourceAuth"]


class APIKeyToolSourceAuth(BaseModel):
    connection_id: str = FieldInfo(alias="connectionId")

    inject: AuthInjection
    """
    Where an API key or OAuth access token should be injected into outgoing
    tool-source requests.
    """

    kind: Literal["api_key"]
