# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["ThreadRetrieveParams"]


class ThreadRetrieveParams(TypedDict, total=False):
    debug: Literal["true", "false"]
    """When true, includes debug-only compiled context fields."""

    include_messages: Annotated[Literal["true", "false"], PropertyInfo(alias="includeMessages")]
    """Deprecated compatibility flag.

    Thread detail includes a bounded recent message page by default; pass `false`
    only to opt out when no message pagination params are present.
    """
