# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["SourceWarning"]


class SourceWarning(BaseModel):
    message: str

    source: str

    source_id: Optional[str] = FieldInfo(alias="sourceId", default=None)
