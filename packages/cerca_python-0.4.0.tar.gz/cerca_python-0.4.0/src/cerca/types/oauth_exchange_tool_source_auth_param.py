# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

from .auth_injection_param import AuthInjectionParam
from .oauth_exchange_config_param import OAuthExchangeConfigParam

__all__ = ["OAuthExchangeToolSourceAuthParam"]


class OAuthExchangeToolSourceAuthParam(TypedDict, total=False):
    exchange: Required[OAuthExchangeConfigParam]
    """Source-owned OAuth exchange configuration.

    Public schemas use connection IDs for stored client secrets and assertions.
    """

    inject: Required[AuthInjectionParam]
    """
    Where an API key or OAuth access token should be injected into outgoing
    tool-source requests.
    """

    kind: Required[Literal["oauth_exchange"]]
