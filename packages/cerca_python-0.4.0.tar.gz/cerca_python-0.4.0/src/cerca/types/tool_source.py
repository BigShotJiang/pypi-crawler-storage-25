# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Union
from typing_extensions import Annotated, TypeAlias

from .._utils import PropertyInfo
from .mcp_tool_source import McpToolSource
from .http_tool_source import HTTPToolSource

__all__ = ["ToolSource"]

ToolSource: TypeAlias = Annotated[Union[HTTPToolSource, McpToolSource], PropertyInfo(discriminator="type")]
