# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from .._utils import PropertyInfo
from .._models import BaseModel

__all__ = ["ExecutionPrincipal", "UserExecutionPrincipal", "APIKeyExecutionPrincipal"]


class UserExecutionPrincipal(BaseModel):
    kind: Literal["user"]

    user_id: str = FieldInfo(alias="userId")


class APIKeyExecutionPrincipal(BaseModel):
    fleet_id: Optional[str] = FieldInfo(alias="fleetId", default=None)

    key_id: str = FieldInfo(alias="keyId")

    kind: Literal["apiKey"]


ExecutionPrincipal: TypeAlias = Annotated[
    Union[UserExecutionPrincipal, APIKeyExecutionPrincipal], PropertyInfo(discriminator="kind")
]
