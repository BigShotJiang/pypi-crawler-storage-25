# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["ContextListParams"]


class ContextListParams(TypedDict, total=False):
    cursor: str
    """Opaque pagination cursor returned by a previous request."""

    limit: str
    """Maximum number of items to return.

    Defaults to 20 and preserves parseInt semantics.
    """

    prefix: str
    """Optional key prefix filter."""
