# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Union
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from .._utils import PropertyInfo
from .._models import BaseModel

__all__ = ["ConnectionOwner", "OrganizationConnectionOwner", "FleetConnectionOwner"]


class OrganizationConnectionOwner(BaseModel):
    type: Literal["organization"]


class FleetConnectionOwner(BaseModel):
    fleet_id: str = FieldInfo(alias="fleetId")

    type: Literal["fleet"]


ConnectionOwner: TypeAlias = Annotated[
    Union[OrganizationConnectionOwner, FleetConnectionOwner], PropertyInfo(discriminator="type")
]
