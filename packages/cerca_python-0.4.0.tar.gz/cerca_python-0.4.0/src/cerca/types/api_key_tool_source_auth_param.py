# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .auth_injection_param import AuthInjectionParam

__all__ = ["APIKeyToolSourceAuthParam"]


class APIKeyToolSourceAuthParam(TypedDict, total=False):
    connection_id: Required[Annotated[str, PropertyInfo(alias="connectionId")]]

    inject: Required[AuthInjectionParam]
    """
    Where an API key or OAuth access token should be injected into outgoing
    tool-source requests.
    """

    kind: Required[Literal["api_key"]]
