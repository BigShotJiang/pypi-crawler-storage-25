# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["ApprovalRequestResolveParams"]


class ApprovalRequestResolveParams(TypedDict, total=False):
    decision: Required[Literal["approve", "deny", "cancel"]]

    grant: Literal["thread", "agent"]
