# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["SandboxReadParams"]


class SandboxReadParams(TypedDict, total=False):
    path: Required[str]

    limit: float

    offset: float
