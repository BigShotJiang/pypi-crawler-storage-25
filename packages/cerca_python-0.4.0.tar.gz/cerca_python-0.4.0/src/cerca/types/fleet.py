# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["Fleet"]


class Fleet(BaseModel):
    id: str

    created_at: str = FieldInfo(alias="createdAt")

    name: str

    org_id: str = FieldInfo(alias="orgId")

    updated_at: str = FieldInfo(alias="updatedAt")
