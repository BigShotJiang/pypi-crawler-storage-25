# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List
from typing_extensions import TypedDict

from .webhook_subscription_event_type import WebhookSubscriptionEventType

__all__ = ["WebhookUpdateParams"]


class WebhookUpdateParams(TypedDict, total=False):
    enabled: bool
    """Whether deliveries are enabled for this subscription."""

    events: List[WebhookSubscriptionEventType]
    """Event names to deliver. Omit to subscribe to all non-test events."""

    url: str
    """HTTPS endpoint that will receive webhook deliveries."""
