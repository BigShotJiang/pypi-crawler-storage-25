# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo
from .connection_owner_param import ConnectionOwnerParam

__all__ = ["OAuthConnectParams"]


class OAuthConnectParams(TypedDict, total=False):
    owner: Required[ConnectionOwnerParam]
    """Public owner for a reusable connection.

    Organization owners use the authenticated organization; fleet owners add a
    fleetId.
    """

    return_origin: Required[Annotated[str, PropertyInfo(alias="returnOrigin")]]
    """HTTP(S) origin that receives the OAuth completion message."""

    scopes: SequenceNotStr[str]
    """Provider-specific OAuth scopes. Empty entries are ignored after trimming."""
