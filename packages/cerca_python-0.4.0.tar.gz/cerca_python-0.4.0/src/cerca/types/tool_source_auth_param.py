# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import TypeAlias

from .no_tool_source_auth_param import NoToolSourceAuthParam
from .api_key_tool_source_auth_param import APIKeyToolSourceAuthParam
from .oauth_exchange_tool_source_auth_param import OAuthExchangeToolSourceAuthParam
from .oauth_connection_tool_source_auth_param import OAuthConnectionToolSourceAuthParam

__all__ = ["ToolSourceAuthParam"]

ToolSourceAuthParam: TypeAlias = Union[
    NoToolSourceAuthParam,
    APIKeyToolSourceAuthParam,
    OAuthExchangeToolSourceAuthParam,
    OAuthConnectionToolSourceAuthParam,
]
