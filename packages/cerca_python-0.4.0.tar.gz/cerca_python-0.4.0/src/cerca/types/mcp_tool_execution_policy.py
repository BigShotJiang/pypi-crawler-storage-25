# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["McpToolExecutionPolicy"]


class McpToolExecutionPolicy(BaseModel):
    """MCP discovery and execution retry/timeout policy."""

    discovery_timeout_ms: Optional[float] = FieldInfo(alias="discoveryTimeoutMs", default=None)

    execution_timeout_ms: Optional[float] = FieldInfo(alias="executionTimeoutMs", default=None)

    max_attempts: Optional[float] = FieldInfo(alias="maxAttempts", default=None)

    retry_mode: Optional[Literal["disabled", "connect_only", "enabled"]] = FieldInfo(alias="retryMode", default=None)
