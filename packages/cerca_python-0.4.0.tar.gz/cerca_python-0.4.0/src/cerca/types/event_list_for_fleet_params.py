# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, TypedDict

__all__ = ["EventListForFleetParams"]


class EventListForFleetParams(TypedDict, total=False):
    cursor: str
    """Opaque pagination cursor returned by a previous request."""

    events: str
    """Comma-separated event type filter."""

    history: Literal["true", "false"]
    """When true, starts from the beginning of the retained buffer."""

    limit: str
    """Maximum number of items to return.

    Defaults to 20 and preserves parseInt semantics.
    """
