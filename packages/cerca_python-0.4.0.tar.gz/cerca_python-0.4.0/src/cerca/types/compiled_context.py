# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .shared.tool_name import ToolName

__all__ = ["CompiledContext"]


class CompiledContext(BaseModel):
    enabled_tools: Optional[List[ToolName]] = FieldInfo(alias="enabledTools", default=None)

    system_prompt: Optional[str] = FieldInfo(alias="systemPrompt", default=None)

    turn_id: Optional[str] = FieldInfo(alias="turnId", default=None)
