# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Union
from typing_extensions import Annotated, TypeAlias

from .._utils import PropertyInfo
from .discovered_tool import DiscoveredTool
from .tool_descriptor import ToolDescriptor

__all__ = ["Tool"]

Tool: TypeAlias = Annotated[Union[ToolDescriptor, DiscoveredTool], PropertyInfo(discriminator="category")]
