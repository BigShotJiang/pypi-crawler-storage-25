# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .auth_injection import AuthInjection

__all__ = ["OAuthConnectionToolSourceAuth"]


class OAuthConnectionToolSourceAuth(BaseModel):
    kind: Literal["oauth_connection"]

    provider: str

    inject: Optional[AuthInjection] = None
    """
    Where an API key or OAuth access token should be injected into outgoing
    tool-source requests.
    """

    required_scopes: Optional[List[str]] = FieldInfo(alias="requiredScopes", default=None)
