# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from .connection import Connection
from .tool_connection_metadata import ToolConnectionMetadata

__all__ = ["AttachedConnection"]


class AttachedConnection(Connection):
    attached_at: str = FieldInfo(alias="attachedAt")

    metadata: Optional[ToolConnectionMetadata] = None
