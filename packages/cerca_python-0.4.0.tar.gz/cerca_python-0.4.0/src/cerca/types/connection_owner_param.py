# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Literal, Required, Annotated, TypeAlias, TypedDict

from .._utils import PropertyInfo

__all__ = ["ConnectionOwnerParam", "OrganizationConnectionOwner", "FleetConnectionOwner"]


class OrganizationConnectionOwner(TypedDict, total=False):
    type: Required[Literal["organization"]]


class FleetConnectionOwner(TypedDict, total=False):
    fleet_id: Required[Annotated[str, PropertyInfo(alias="fleetId")]]

    type: Required[Literal["fleet"]]


ConnectionOwnerParam: TypeAlias = Union[OrganizationConnectionOwner, FleetConnectionOwner]
