# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from .status import Status
from .._models import BaseModel

__all__ = ["ThreadSummary"]


class ThreadSummary(BaseModel):
    id: str

    completed_at: Optional[str] = FieldInfo(alias="completedAt", default=None)

    created_at: str = FieldInfo(alias="createdAt")

    message_count: float = FieldInfo(alias="messageCount")

    model: str

    parent_thread_id: Optional[str] = FieldInfo(alias="parentThreadId", default=None)

    result: Optional[str] = None

    schedule_id: Optional[str] = FieldInfo(alias="scheduleId", default=None)

    schedule_seq: Optional[float] = FieldInfo(alias="scheduleSeq", default=None)

    status: Status
    """`idle` threads can accept a new turn or be closed.

    `running` threads have an active turn. `awaiting` threads are paused on external
    input such as approvals. `closed` threads are terminal.
    """

    step_count: float = FieldInfo(alias="stepCount")
