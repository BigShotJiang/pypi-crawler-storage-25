# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .webhook_event_type import WebhookEventType

__all__ = ["WebhookSubscription"]


class WebhookSubscription(BaseModel):
    """Webhook subscription metadata returned by list, get, and update.

    The one-time signing secret is not returned here.
    """

    id: str

    created_at: str = FieldInfo(alias="createdAt")

    enabled: bool

    events: List[WebhookEventType]

    fleet_id: str = FieldInfo(alias="fleetId")

    updated_at: str = FieldInfo(alias="updatedAt")

    url: str
