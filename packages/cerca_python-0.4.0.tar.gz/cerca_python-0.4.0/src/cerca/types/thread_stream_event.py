# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from .status import Status
from .._utils import PropertyInfo
from .._models import BaseModel
from .shared.tool_name import ToolName

__all__ = [
    "ThreadStreamEvent",
    "ThreadStreamStatusMessage",
    "ThreadStreamContentMessage",
    "ThreadStreamContentMessageMessage",
    "ThreadStreamContentMessageMessageContent",
    "ThreadStreamContentMessageMessageContentThreadStreamTextContentBlock",
    "ThreadStreamContentMessageMessageContentThreadStreamToolUseContentBlock",
    "ThreadStreamContentMessageMessageContentThreadStreamToolResultContentBlock",
    "ThreadStreamContentMessageMessageContentThreadStreamServerToolUseContentBlock",
    "ThreadStreamContentMessageMessageContentThreadStreamWebSearchToolResultContentBlock",
    "ThreadStreamProgressMessage",
    "ThreadStreamTurnStartedMessage",
    "ThreadStreamTurnCompletedMessage",
    "ThreadStreamItemStartedMessage",
    "ThreadStreamItemCompletedMessage",
    "ThreadStreamTokenUsageMessage",
    "ThreadStreamApprovalRequestedMessage",
    "ThreadStreamApprovalRequestedMessageApproval",
    "ThreadStreamApprovalResolvedMessage",
]


class ThreadStreamStatusMessage(BaseModel):
    error: Optional[str] = None

    event_seq: float = FieldInfo(alias="eventSeq")

    result: Optional[str] = None

    status: Status
    """`idle` threads can accept a new turn or be closed.

    `running` threads have an active turn. `awaiting` threads are paused on external
    input such as approvals. `closed` threads are terminal.
    """

    step_seq: float = FieldInfo(alias="stepSeq")

    turn_id: str = FieldInfo(alias="turnId")

    type: Literal["status"]


class ThreadStreamContentMessageMessageContentThreadStreamTextContentBlock(BaseModel):
    text: str

    type: Literal["text"]

    provider_metadata: Optional[Dict[str, Dict[str, str]]] = FieldInfo(alias="providerMetadata", default=None)


class ThreadStreamContentMessageMessageContentThreadStreamToolUseContentBlock(BaseModel):
    id: str

    input: str
    """JSON-serialized tool input payload.

    Parse as JSON before reading tool-specific fields.
    """

    name: ToolName

    type: Literal["tool_use"]

    provider_metadata: Optional[Dict[str, Dict[str, str]]] = FieldInfo(alias="providerMetadata", default=None)


class ThreadStreamContentMessageMessageContentThreadStreamToolResultContentBlock(BaseModel):
    content: str

    is_error: bool = FieldInfo(alias="isError")

    tool_use_id: str = FieldInfo(alias="toolUseId")

    type: Literal["tool_result"]

    denied_by_user: Optional[bool] = FieldInfo(alias="deniedByUser", default=None)

    provider_metadata: Optional[Dict[str, Dict[str, str]]] = FieldInfo(alias="providerMetadata", default=None)


class ThreadStreamContentMessageMessageContentThreadStreamServerToolUseContentBlock(BaseModel):
    id: str

    input: str
    """JSON-serialized tool input payload.

    Parse as JSON before reading tool-specific fields.
    """

    name: str

    type: Literal["server_tool_use"]

    provider_metadata: Optional[Dict[str, Dict[str, str]]] = FieldInfo(alias="providerMetadata", default=None)


class ThreadStreamContentMessageMessageContentThreadStreamWebSearchToolResultContentBlock(BaseModel):
    content: object
    """Web search result payload.

    The runtime returns either an array of web search results or an error object.
    """

    tool_use_id: str = FieldInfo(alias="toolUseId")

    type: Literal["web_search_tool_result"]


ThreadStreamContentMessageMessageContent: TypeAlias = Annotated[
    Union[
        ThreadStreamContentMessageMessageContentThreadStreamTextContentBlock,
        ThreadStreamContentMessageMessageContentThreadStreamToolUseContentBlock,
        ThreadStreamContentMessageMessageContentThreadStreamToolResultContentBlock,
        ThreadStreamContentMessageMessageContentThreadStreamServerToolUseContentBlock,
        ThreadStreamContentMessageMessageContentThreadStreamWebSearchToolResultContentBlock,
    ],
    PropertyInfo(discriminator="type"),
]


class ThreadStreamContentMessageMessage(BaseModel):
    content: List[ThreadStreamContentMessageMessageContent]

    created_at: str = FieldInfo(alias="createdAt")

    role: Literal["user", "assistant"]

    seq: float


class ThreadStreamContentMessage(BaseModel):
    event_seq: float = FieldInfo(alias="eventSeq")

    message: ThreadStreamContentMessageMessage

    step_seq: float = FieldInfo(alias="stepSeq")

    turn_id: str = FieldInfo(alias="turnId")

    type: Literal["message"]


class ThreadStreamProgressMessage(BaseModel):
    event_seq: float = FieldInfo(alias="eventSeq")

    message_count: float = FieldInfo(alias="messageCount")

    step_count: float = FieldInfo(alias="stepCount")

    step_seq: float = FieldInfo(alias="stepSeq")

    turn_id: str = FieldInfo(alias="turnId")

    type: Literal["progress"]


class ThreadStreamTurnStartedMessage(BaseModel):
    event_seq: float = FieldInfo(alias="eventSeq")

    turn_id: str = FieldInfo(alias="turnId")

    turn_seq: float = FieldInfo(alias="turnSeq")

    type: Literal["turn/started"]


class ThreadStreamTurnCompletedMessage(BaseModel):
    error: Optional[str] = None

    event_seq: float = FieldInfo(alias="eventSeq")

    result: Optional[str] = None

    status: Literal["completed", "failed"]

    turn_id: str = FieldInfo(alias="turnId")

    turn_seq: float = FieldInfo(alias="turnSeq")

    type: Literal["turn/completed"]


class ThreadStreamItemStartedMessage(BaseModel):
    event_seq: float = FieldInfo(alias="eventSeq")

    item_id: str = FieldInfo(alias="itemId")

    item_type: Literal["tool_call", "agent_message", "llm_call", "sub_thread"] = FieldInfo(alias="itemType")

    turn_id: str = FieldInfo(alias="turnId")

    type: Literal["item/started"]

    requested_tool_name: Optional[str] = FieldInfo(alias="requestedToolName", default=None)

    sub_thread_id: Optional[str] = FieldInfo(alias="subThreadId", default=None)

    tool_name: Optional[ToolName] = FieldInfo(alias="toolName", default=None)


class ThreadStreamItemCompletedMessage(BaseModel):
    duration_ms: float = FieldInfo(alias="durationMs")

    event_seq: float = FieldInfo(alias="eventSeq")

    item_id: str = FieldInfo(alias="itemId")

    item_type: Literal["tool_call", "agent_message", "llm_call", "sub_thread"] = FieldInfo(alias="itemType")

    turn_id: str = FieldInfo(alias="turnId")

    type: Literal["item/completed"]

    is_error: Optional[bool] = FieldInfo(alias="isError", default=None)

    requested_tool_name: Optional[str] = FieldInfo(alias="requestedToolName", default=None)


class ThreadStreamTokenUsageMessage(BaseModel):
    cumulative_input_tokens: float = FieldInfo(alias="cumulativeInputTokens")

    cumulative_output_tokens: float = FieldInfo(alias="cumulativeOutputTokens")

    event_seq: float = FieldInfo(alias="eventSeq")

    input_tokens: float = FieldInfo(alias="inputTokens")

    output_tokens: float = FieldInfo(alias="outputTokens")

    turn_id: str = FieldInfo(alias="turnId")

    type: Literal["token_usage"]


class ThreadStreamApprovalRequestedMessageApproval(BaseModel):
    id: str

    created_at: str = FieldInfo(alias="createdAt")

    requested_tool_name: str = FieldInfo(alias="requestedToolName")

    resolved_at: Optional[str] = FieldInfo(alias="resolvedAt", default=None)

    status: Literal["pending", "approved", "denied", "cancelled", "timed_out"]

    thread_id: str = FieldInfo(alias="threadId")

    timeout_at: Optional[str] = FieldInfo(alias="timeoutAt", default=None)

    timeout_ms: Optional[float] = FieldInfo(alias="timeoutMs", default=None)

    tool_index: float = FieldInfo(alias="toolIndex")

    tool_input: str = FieldInfo(alias="toolInput")
    """JSON-serialized tool input payload.

    Parse as JSON before reading tool-specific fields.
    """

    tool_name: ToolName = FieldInfo(alias="toolName")

    tool_use_id: str = FieldInfo(alias="toolUseId")

    turn_id: str = FieldInfo(alias="turnId")

    tool_source_id: Optional[str] = FieldInfo(alias="toolSourceId", default=None)

    tool_source_version: Optional[float] = FieldInfo(alias="toolSourceVersion", default=None)


class ThreadStreamApprovalRequestedMessage(BaseModel):
    approval: ThreadStreamApprovalRequestedMessageApproval

    event_seq: float = FieldInfo(alias="eventSeq")

    turn_id: str = FieldInfo(alias="turnId")

    type: Literal["approval/requested"]


class ThreadStreamApprovalResolvedMessage(BaseModel):
    approval_id: str = FieldInfo(alias="approvalId")

    decision: Literal["approve", "deny", "cancel", "timeout"]

    event_seq: float = FieldInfo(alias="eventSeq")

    turn_id: str = FieldInfo(alias="turnId")

    type: Literal["approval/resolved"]


ThreadStreamEvent: TypeAlias = Annotated[
    Union[
        ThreadStreamStatusMessage,
        ThreadStreamContentMessage,
        ThreadStreamProgressMessage,
        ThreadStreamTurnStartedMessage,
        ThreadStreamTurnCompletedMessage,
        ThreadStreamItemStartedMessage,
        ThreadStreamItemCompletedMessage,
        ThreadStreamTokenUsageMessage,
        ThreadStreamApprovalRequestedMessage,
        ThreadStreamApprovalResolvedMessage,
    ],
    PropertyInfo(discriminator="type"),
]
