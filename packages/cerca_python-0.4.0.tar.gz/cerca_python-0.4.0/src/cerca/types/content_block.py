# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from .._utils import PropertyInfo
from .._models import BaseModel
from .shared.tool_name import ToolName

__all__ = [
    "ContentBlock",
    "TextContentBlock",
    "ToolUseContentBlock",
    "ToolResultContentBlock",
    "ServerToolUseContentBlock",
    "WebSearchToolResultContentBlock",
]


class TextContentBlock(BaseModel):
    text: str

    type: Literal["text"]

    provider_metadata: Optional[Dict[str, Dict[str, str]]] = FieldInfo(alias="providerMetadata", default=None)


class ToolUseContentBlock(BaseModel):
    id: str

    input: object
    """Any JSON value.

    Generated SDKs may expose this value boundary as unknown or Any.
    """

    name: ToolName

    type: Literal["tool_use"]

    provider_metadata: Optional[Dict[str, Dict[str, str]]] = FieldInfo(alias="providerMetadata", default=None)


class ToolResultContentBlock(BaseModel):
    content: str

    is_error: bool = FieldInfo(alias="isError")

    tool_use_id: str = FieldInfo(alias="toolUseId")

    type: Literal["tool_result"]

    denied_by_user: Optional[bool] = FieldInfo(alias="deniedByUser", default=None)

    provider_metadata: Optional[Dict[str, Dict[str, str]]] = FieldInfo(alias="providerMetadata", default=None)


class ServerToolUseContentBlock(BaseModel):
    id: str

    input: object
    """Any JSON value.

    Generated SDKs may expose this value boundary as unknown or Any.
    """

    name: str

    type: Literal["server_tool_use"]

    provider_metadata: Optional[Dict[str, Dict[str, str]]] = FieldInfo(alias="providerMetadata", default=None)


class WebSearchToolResultContentBlock(BaseModel):
    content: object
    """Web search result payload.

    The runtime returns either an array of web search results or an error object.
    """

    tool_use_id: str = FieldInfo(alias="toolUseId")

    type: Literal["web_search_tool_result"]


ContentBlock: TypeAlias = Annotated[
    Union[
        TextContentBlock,
        ToolUseContentBlock,
        ToolResultContentBlock,
        ServerToolUseContentBlock,
        WebSearchToolResultContentBlock,
    ],
    PropertyInfo(discriminator="type"),
]
