# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .http_endpoint import HTTPEndpoint
from .tool_approval_mode import ToolApprovalMode
from .http_tool_execution_policy import HTTPToolExecutionPolicy
from .response_normalization_hint import ResponseNormalizationHint

__all__ = ["HTTPToolDefinition"]


class HTTPToolDefinition(BaseModel):
    """Definition for a single HTTP tool exposed by a tool source."""

    description: str

    endpoint: HTTPEndpoint
    """HTTP endpoint invoked when the tool is called."""

    input_schema: Dict[str, object] = FieldInfo(alias="inputSchema")
    """JSON Schema object describing tool input parameters."""

    name: str

    approval: Optional[ToolApprovalMode] = None

    execution: Optional[HTTPToolExecutionPolicy] = None
    """HTTP tool execution retry and timeout policy."""

    response: Optional[ResponseNormalizationHint] = None
    """How the HTTP response should be normalized for the agent."""
