# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .attached_connection import AttachedConnection

__all__ = ["ConnectionListForAgentResponse"]


class ConnectionListForAgentResponse(BaseModel):
    connections: List[AttachedConnection]

    cursor: Optional[str] = None

    has_more: bool = FieldInfo(alias="hasMore")
