# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from .status import Status
from .._utils import PropertyInfo
from .._models import BaseModel
from .metadata import Metadata
from .token_usage import TokenUsage
from .configuration import Configuration
from .shared.tool_name import ToolName
from .effective_configuration import EffectiveConfiguration

__all__ = [
    "RuntimeWebhookEvent",
    "AgentCreatedWebhookEvent",
    "AgentCreatedWebhookEventData",
    "AgentCreatedWebhookEventDataAgent",
    "AgentUpdatedWebhookEvent",
    "AgentUpdatedWebhookEventData",
    "AgentUpdatedWebhookEventDataAgent",
    "AgentDeletedWebhookEvent",
    "AgentDeletedWebhookEventData",
    "ThreadCreatedWebhookEvent",
    "ThreadCreatedWebhookEventData",
    "ThreadStatusChangedWebhookEvent",
    "ThreadStatusChangedWebhookEventData",
    "ThreadCompletedWebhookEvent",
    "ThreadCompletedWebhookEventData",
    "ThreadFailedWebhookEvent",
    "ThreadFailedWebhookEventData",
    "TurnCreatedWebhookEvent",
    "TurnCreatedWebhookEventData",
    "TurnCompletedWebhookEvent",
    "TurnCompletedWebhookEventData",
    "TurnFailedWebhookEvent",
    "TurnFailedWebhookEventData",
    "MessageCreatedWebhookEvent",
    "MessageCreatedWebhookEventData",
    "ApprovalRequestedWebhookEvent",
    "ApprovalRequestedWebhookEventData",
    "ApprovalRequestedWebhookEventDataApproval",
    "ApprovalResolvedWebhookEvent",
    "ApprovalResolvedWebhookEventData",
    "ApprovalGrantedWebhookEvent",
    "ApprovalGrantedWebhookEventData",
    "ScheduleCreatedWebhookEvent",
    "ScheduleCreatedWebhookEventData",
    "ScheduleDeletedWebhookEvent",
    "ScheduleDeletedWebhookEventData",
    "ScheduleTriggeredWebhookEvent",
    "ScheduleTriggeredWebhookEventData",
    "ConnectionAttachedWebhookEvent",
    "ConnectionAttachedWebhookEventData",
    "ConnectionDetachedWebhookEvent",
    "ConnectionDetachedWebhookEventData",
    "WebhookTestWebhookEvent",
    "WebhookTestWebhookEventData",
]


class AgentCreatedWebhookEventDataAgent(BaseModel):
    id: str

    configuration: Configuration

    created_at: str = FieldInfo(alias="createdAt")

    fleet_id: str = FieldInfo(alias="fleetId")

    metadata: Metadata
    """Arbitrary string metadata stored on an agent.

    Runtime enforces maximum key and value sizes.
    """

    org_id: str = FieldInfo(alias="orgId")

    updated_at: str = FieldInfo(alias="updatedAt")

    user_id: str = FieldInfo(alias="userId")

    effective: Optional[EffectiveConfiguration] = None


class AgentCreatedWebhookEventData(BaseModel):
    agent: AgentCreatedWebhookEventDataAgent


class AgentCreatedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: AgentCreatedWebhookEventData

    event: Literal["agent.created"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class AgentUpdatedWebhookEventDataAgent(BaseModel):
    id: str

    configuration: Configuration

    created_at: str = FieldInfo(alias="createdAt")

    fleet_id: str = FieldInfo(alias="fleetId")

    metadata: Metadata
    """Arbitrary string metadata stored on an agent.

    Runtime enforces maximum key and value sizes.
    """

    org_id: str = FieldInfo(alias="orgId")

    updated_at: str = FieldInfo(alias="updatedAt")

    user_id: str = FieldInfo(alias="userId")

    effective: Optional[EffectiveConfiguration] = None


class AgentUpdatedWebhookEventData(BaseModel):
    agent: AgentUpdatedWebhookEventDataAgent

    trigger: Literal["configuration", "metadata"]


class AgentUpdatedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: AgentUpdatedWebhookEventData

    event: Literal["agent.updated"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class AgentDeletedWebhookEventData(BaseModel):
    agent_id: str = FieldInfo(alias="agentId")


class AgentDeletedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: AgentDeletedWebhookEventData

    event: Literal["agent.deleted"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class ThreadCreatedWebhookEventData(BaseModel):
    message: str

    model: str


class ThreadCreatedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: ThreadCreatedWebhookEventData

    event: Literal["thread.created"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class ThreadStatusChangedWebhookEventData(BaseModel):
    error: Optional[str] = None

    previous_status: Status = FieldInfo(alias="previousStatus")
    """`idle` threads can accept a new turn or be closed.

    `running` threads have an active turn. `awaiting` threads are paused on external
    input such as approvals. `closed` threads are terminal.
    """

    result: Optional[str] = None

    status: Status
    """`idle` threads can accept a new turn or be closed.

    `running` threads have an active turn. `awaiting` threads are paused on external
    input such as approvals. `closed` threads are terminal.
    """


class ThreadStatusChangedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: ThreadStatusChangedWebhookEventData

    event: Literal["thread.status.changed"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class ThreadCompletedWebhookEventData(BaseModel):
    previous_status: Status = FieldInfo(alias="previousStatus")
    """`idle` threads can accept a new turn or be closed.

    `running` threads have an active turn. `awaiting` threads are paused on external
    input such as approvals. `closed` threads are terminal.
    """

    result: str

    status: Status
    """`idle` threads can accept a new turn or be closed.

    `running` threads have an active turn. `awaiting` threads are paused on external
    input such as approvals. `closed` threads are terminal.
    """


class ThreadCompletedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: ThreadCompletedWebhookEventData

    event: Literal["thread.completed"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class ThreadFailedWebhookEventData(BaseModel):
    error: str

    previous_status: Status = FieldInfo(alias="previousStatus")
    """`idle` threads can accept a new turn or be closed.

    `running` threads have an active turn. `awaiting` threads are paused on external
    input such as approvals. `closed` threads are terminal.
    """

    status: Status
    """`idle` threads can accept a new turn or be closed.

    `running` threads have an active turn. `awaiting` threads are paused on external
    input such as approvals. `closed` threads are terminal.
    """


class ThreadFailedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: ThreadFailedWebhookEventData

    event: Literal["thread.failed"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class TurnCreatedWebhookEventData(BaseModel):
    message: str

    seq: float

    started_at: str = FieldInfo(alias="startedAt")

    turn_id: str = FieldInfo(alias="turnId")


class TurnCreatedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: TurnCreatedWebhookEventData

    event: Literal["turn.created"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class TurnCompletedWebhookEventData(BaseModel):
    completed_at: str = FieldInfo(alias="completedAt")

    error: Optional[str] = None

    result: Optional[str] = None

    seq: float

    status: Literal["completed"]

    token_usage: Optional[TokenUsage] = FieldInfo(alias="tokenUsage", default=None)

    turn_id: str = FieldInfo(alias="turnId")


class TurnCompletedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: TurnCompletedWebhookEventData

    event: Literal["turn.completed"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class TurnFailedWebhookEventData(BaseModel):
    completed_at: str = FieldInfo(alias="completedAt")

    error: Optional[str] = None

    result: Optional[str] = None

    seq: float

    status: Literal["failed"]

    token_usage: Optional[TokenUsage] = FieldInfo(alias="tokenUsage", default=None)

    turn_id: str = FieldInfo(alias="turnId")


class TurnFailedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: TurnFailedWebhookEventData

    event: Literal["turn.failed"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class MessageCreatedWebhookEventData(BaseModel):
    created_at: str = FieldInfo(alias="createdAt")

    role: Literal["user", "assistant"]

    seq: float

    turn_id: Optional[str] = FieldInfo(alias="turnId", default=None)


class MessageCreatedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: MessageCreatedWebhookEventData

    event: Literal["message.created"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class ApprovalRequestedWebhookEventDataApproval(BaseModel):
    id: str

    created_at: str = FieldInfo(alias="createdAt")

    input: object
    """JSON value payload. Generated SDKs may expose this as unknown or Any."""

    resolved_at: Optional[str] = FieldInfo(alias="resolvedAt", default=None)

    runtime_tool_name: ToolName = FieldInfo(alias="runtimeToolName")

    status: Literal["pending", "approved", "denied", "cancelled", "timed_out"]

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timeout_at: Optional[str] = FieldInfo(alias="timeoutAt", default=None)

    timeout_ms: Optional[float] = FieldInfo(alias="timeoutMs", default=None)

    tool_index: float = FieldInfo(alias="toolIndex")

    tool_name: str = FieldInfo(alias="toolName")

    tool_use_id: str = FieldInfo(alias="toolUseId")

    turn_id: str = FieldInfo(alias="turnId")

    tool_source_id: Optional[str] = FieldInfo(alias="toolSourceId", default=None)

    tool_source_version: Optional[float] = FieldInfo(alias="toolSourceVersion", default=None)


class ApprovalRequestedWebhookEventData(BaseModel):
    approval: ApprovalRequestedWebhookEventDataApproval


class ApprovalRequestedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: ApprovalRequestedWebhookEventData

    event: Literal["approval.requested"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class ApprovalResolvedWebhookEventData(BaseModel):
    approval_id: str = FieldInfo(alias="approvalId")

    decision: Literal["approved", "denied", "timed_out", "cancelled"]


class ApprovalResolvedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: ApprovalResolvedWebhookEventData

    event: Literal["approval.resolved"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class ApprovalGrantedWebhookEventData(BaseModel):
    grant_id: str = FieldInfo(alias="grantId")

    scope: Literal["thread", "agent"]

    tool_name: str = FieldInfo(alias="toolName")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)


class ApprovalGrantedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: ApprovalGrantedWebhookEventData

    event: Literal["approval.granted"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class ScheduleCreatedWebhookEventData(BaseModel):
    name: str

    schedule_id: str = FieldInfo(alias="scheduleId")

    cron: Optional[str] = None

    run_at: Optional[str] = FieldInfo(alias="runAt", default=None)


class ScheduleCreatedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: ScheduleCreatedWebhookEventData

    event: Literal["schedule.created"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class ScheduleDeletedWebhookEventData(BaseModel):
    schedule_id: str = FieldInfo(alias="scheduleId")


class ScheduleDeletedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: ScheduleDeletedWebhookEventData

    event: Literal["schedule.deleted"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class ScheduleTriggeredWebhookEventData(BaseModel):
    schedule_id: str = FieldInfo(alias="scheduleId")

    thread_id: str = FieldInfo(alias="threadId")


class ScheduleTriggeredWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: ScheduleTriggeredWebhookEventData

    event: Literal["schedule.triggered"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class ConnectionAttachedWebhookEventData(BaseModel):
    connection_id: str = FieldInfo(alias="connectionId")

    provider: str


class ConnectionAttachedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: ConnectionAttachedWebhookEventData

    event: Literal["connection.attached"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class ConnectionDetachedWebhookEventData(BaseModel):
    connection_id: str = FieldInfo(alias="connectionId")

    provider: str


class ConnectionDetachedWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: ConnectionDetachedWebhookEventData

    event: Literal["connection.detached"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


class WebhookTestWebhookEventData(BaseModel):
    pass


class WebhookTestWebhookEvent(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    data: WebhookTestWebhookEventData

    event: Literal["webhook.test"]

    fleet_id: str = FieldInfo(alias="fleetId")

    org_id: str = FieldInfo(alias="orgId")

    thread_id: Optional[str] = FieldInfo(alias="threadId", default=None)

    timestamp: str


RuntimeWebhookEvent: TypeAlias = Annotated[
    Union[
        AgentCreatedWebhookEvent,
        AgentUpdatedWebhookEvent,
        AgentDeletedWebhookEvent,
        ThreadCreatedWebhookEvent,
        ThreadStatusChangedWebhookEvent,
        ThreadCompletedWebhookEvent,
        ThreadFailedWebhookEvent,
        TurnCreatedWebhookEvent,
        TurnCompletedWebhookEvent,
        TurnFailedWebhookEvent,
        MessageCreatedWebhookEvent,
        ApprovalRequestedWebhookEvent,
        ApprovalResolvedWebhookEvent,
        ApprovalGrantedWebhookEvent,
        ScheduleCreatedWebhookEvent,
        ScheduleDeletedWebhookEvent,
        ScheduleTriggeredWebhookEvent,
        ConnectionAttachedWebhookEvent,
        ConnectionDetachedWebhookEvent,
        WebhookTestWebhookEvent,
    ],
    PropertyInfo(discriminator="event"),
]
