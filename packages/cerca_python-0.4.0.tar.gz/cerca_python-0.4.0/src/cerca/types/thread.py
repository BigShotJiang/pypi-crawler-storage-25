# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .turn import Turn
from .status import Status
from .message import Message
from .._models import BaseModel
from .compiled_context import CompiledContext
from .shared.tool_name import ToolName
from .sub_thread_summary import SubThreadSummary

__all__ = ["Thread"]


class Thread(BaseModel):
    id: str

    agent_id: str = FieldInfo(alias="agentId")

    compiled_context: Optional[CompiledContext] = FieldInfo(alias="compiledContext", default=None)

    completed_at: Optional[str] = FieldInfo(alias="completedAt", default=None)

    created_at: str = FieldInfo(alias="createdAt")

    depth: float

    error: Optional[str] = None

    has_more_messages: bool = FieldInfo(alias="hasMoreMessages")

    instructions: Optional[str] = None

    last_turn_status: Optional[Literal["completed", "failed"]] = FieldInfo(alias="lastTurnStatus", default=None)

    message: str

    message_cursor: Optional[float] = FieldInfo(alias="messageCursor", default=None)

    messages: List[Message]

    model: str

    parent_thread_id: Optional[str] = FieldInfo(alias="parentThreadId", default=None)

    result: Optional[str] = None

    schedule_id: Optional[str] = FieldInfo(alias="scheduleId", default=None)

    schedule_seq: Optional[float] = FieldInfo(alias="scheduleSeq", default=None)

    status: Status
    """`idle` threads can accept a new turn or be closed.

    `running` threads have an active turn. `awaiting` threads are paused on external
    input such as approvals. `closed` threads are terminal.
    """

    sub_threads: List[SubThreadSummary] = FieldInfo(alias="subThreads")

    tools: List[ToolName]

    turns: List[Turn]

    updated_at: str = FieldInfo(alias="updatedAt")

    external_tool_namespaces: Union[Literal["all"], List[str], None] = FieldInfo(
        alias="externalToolNamespaces", default=None
    )
