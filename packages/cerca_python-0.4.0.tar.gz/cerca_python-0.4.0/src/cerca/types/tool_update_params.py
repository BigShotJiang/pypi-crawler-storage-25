# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from typing_extensions import Literal, Required, TypeAlias, TypedDict

from .tool_approval_mode import ToolApprovalMode
from .tool_source_auth_param import ToolSourceAuthParam
from .http_tool_definition_param import HTTPToolDefinitionParam
from .mcp_tool_execution_policy_param import McpToolExecutionPolicyParam
from .http_tool_execution_policy_param import HTTPToolExecutionPolicyParam

__all__ = ["ToolUpdateParams", "UpdateHTTPToolSourceRequest", "UpdateMcpToolSourceRequest"]


class UpdateHTTPToolSourceRequest(TypedDict, total=False):
    auth: Required[ToolSourceAuthParam]
    """Tool source authentication configuration.

    The `kind` field selects one of `none`, `api_key`, `oauth_exchange`, or
    `oauth_connection`.
    """

    namespace: Required[str]

    tools: Required[Iterable[HTTPToolDefinitionParam]]

    type: Required[Literal["http"]]

    approval: ToolApprovalMode

    enabled: bool

    execution: HTTPToolExecutionPolicyParam
    """HTTP tool execution retry and timeout policy."""


class UpdateMcpToolSourceRequest(TypedDict, total=False):
    auth: Required[ToolSourceAuthParam]
    """Tool source authentication configuration.

    The `kind` field selects one of `none`, `api_key`, `oauth_exchange`, or
    `oauth_connection`.
    """

    namespace: Required[str]

    type: Required[Literal["mcp"]]

    url: Required[str]

    approval: ToolApprovalMode

    enabled: bool

    execution: McpToolExecutionPolicyParam
    """MCP discovery and execution retry/timeout policy."""


ToolUpdateParams: TypeAlias = Union[UpdateHTTPToolSourceRequest, UpdateMcpToolSourceRequest]
