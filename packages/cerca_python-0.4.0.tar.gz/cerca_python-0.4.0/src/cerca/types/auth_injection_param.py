# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Literal, Required, TypeAlias, TypedDict

__all__ = ["AuthInjectionParam", "HeaderAuthInjection", "QueryAuthInjection"]


class HeaderAuthInjection(TypedDict, total=False):
    location: Required[Literal["header"]]

    name: Required[str]

    value: str
    """Optional value template.

    For OAuth connection auth, use values such as `Bearer ${token}`.
    """


class QueryAuthInjection(TypedDict, total=False):
    location: Required[Literal["query"]]

    name: Required[str]


AuthInjectionParam: TypeAlias = Union[HeaderAuthInjection, QueryAuthInjection]
