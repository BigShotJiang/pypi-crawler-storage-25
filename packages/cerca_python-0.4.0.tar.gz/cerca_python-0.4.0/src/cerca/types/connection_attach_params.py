# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .tool_connection_metadata_param import ToolConnectionMetadataParam

__all__ = ["ConnectionAttachParams"]


class ConnectionAttachParams(TypedDict, total=False):
    connection_id: Required[Annotated[str, PropertyInfo(alias="connectionId")]]

    metadata: ToolConnectionMetadataParam
