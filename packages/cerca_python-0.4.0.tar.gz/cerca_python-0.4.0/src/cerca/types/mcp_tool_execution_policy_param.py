# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["McpToolExecutionPolicyParam"]


class McpToolExecutionPolicyParam(TypedDict, total=False):
    """MCP discovery and execution retry/timeout policy."""

    discovery_timeout_ms: Annotated[float, PropertyInfo(alias="discoveryTimeoutMs")]

    execution_timeout_ms: Annotated[float, PropertyInfo(alias="executionTimeoutMs")]

    max_attempts: Annotated[float, PropertyInfo(alias="maxAttempts")]

    retry_mode: Annotated[Literal["disabled", "connect_only", "enabled"], PropertyInfo(alias="retryMode")]
