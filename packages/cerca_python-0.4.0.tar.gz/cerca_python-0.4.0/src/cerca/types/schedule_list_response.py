# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .._models import BaseModel
from .schedule import Schedule

__all__ = ["ScheduleListResponse"]


class ScheduleListResponse(BaseModel):
    schedules: List[Schedule]
