# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ModelDescriptor"]


class ModelDescriptor(BaseModel):
    id: str

    capabilities: List[str]

    context_window_tokens: float = FieldInfo(alias="contextWindowTokens")

    default_max_output_tokens: float = FieldInfo(alias="defaultMaxOutputTokens")

    name: str

    provider: Literal["anthropic", "openai", "google", "fireworks"]

    request_headroom_tokens: float = FieldInfo(alias="requestHeadroomTokens")
