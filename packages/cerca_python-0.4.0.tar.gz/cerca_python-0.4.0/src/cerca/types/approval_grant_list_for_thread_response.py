# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from .approval_grant import ApprovalGrant

__all__ = ["ApprovalGrantListForThreadResponse"]

ApprovalGrantListForThreadResponse: TypeAlias = List[ApprovalGrant]
