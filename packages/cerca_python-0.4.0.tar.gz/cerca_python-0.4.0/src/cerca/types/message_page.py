# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .message import Message
from .._models import BaseModel

__all__ = ["MessagePage"]


class MessagePage(BaseModel):
    cursor: Optional[str] = None

    has_more: bool = FieldInfo(alias="hasMore")

    messages: List[Message]
