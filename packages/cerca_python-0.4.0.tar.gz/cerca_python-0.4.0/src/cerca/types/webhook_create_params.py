# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List
from typing_extensions import Required, TypedDict

from .webhook_subscription_event_type import WebhookSubscriptionEventType

__all__ = ["WebhookCreateParams"]


class WebhookCreateParams(TypedDict, total=False):
    url: Required[str]
    """HTTPS endpoint that will receive webhook deliveries."""

    events: List[WebhookSubscriptionEventType]
    """Event names to deliver. Omit to subscribe to all non-test events."""
