# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .._models import BaseModel
from .model_descriptor import ModelDescriptor

__all__ = ["ModelListResponse"]


class ModelListResponse(BaseModel):
    models: List[ModelDescriptor]
