# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["OAuthConnectResponse"]


class OAuthConnectResponse(BaseModel):
    authorization_url: str = FieldInfo(alias="authorizationUrl")
    """Provider authorization URL that the client should open."""

    callback_origin: str = FieldInfo(alias="callbackOrigin")
    """Origin hosting the OAuth callback endpoint."""

    expires_at: Optional[str] = FieldInfo(alias="expiresAt", default=None)
    """OAuth state expiration timestamp, when returned."""

    state_nonce: Optional[str] = FieldInfo(alias="stateNonce", default=None)
    """OAuth state nonce, when returned."""
