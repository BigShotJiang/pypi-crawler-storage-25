# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Union
from typing_extensions import Annotated, TypeAlias

from .._utils import PropertyInfo
from .no_tool_source_auth import NoToolSourceAuth
from .api_key_tool_source_auth import APIKeyToolSourceAuth
from .oauth_exchange_tool_source_auth import OAuthExchangeToolSourceAuth
from .oauth_connection_tool_source_auth import OAuthConnectionToolSourceAuth

__all__ = ["ToolSourceAuth"]

ToolSourceAuth: TypeAlias = Annotated[
    Union[NoToolSourceAuth, APIKeyToolSourceAuth, OAuthExchangeToolSourceAuth, OAuthConnectionToolSourceAuth],
    PropertyInfo(discriminator="kind"),
]
