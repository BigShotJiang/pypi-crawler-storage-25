# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from .._utils import PropertyInfo
from .._models import BaseModel

__all__ = ["OAuthExchangeConfig", "ClientCredentialsOAuthExchange", "JwtBearerOAuthExchange"]


class ClientCredentialsOAuthExchange(BaseModel):
    client_id: str = FieldInfo(alias="clientId")

    client_secret_connection_id: str = FieldInfo(alias="clientSecretConnectionId")

    grant_type: Literal["client_credentials"] = FieldInfo(alias="grantType")

    token_url: str = FieldInfo(alias="tokenUrl")

    audience: Optional[str] = None

    extra_params: Optional[Dict[str, str]] = FieldInfo(alias="extraParams", default=None)

    scopes: Optional[List[str]] = None


class JwtBearerOAuthExchange(BaseModel):
    assertion_connection_id: str = FieldInfo(alias="assertionConnectionId")

    audience: str

    grant_type: Literal["jwt_bearer"] = FieldInfo(alias="grantType")

    issuer: str

    token_url: str = FieldInfo(alias="tokenUrl")

    extra_params: Optional[Dict[str, str]] = FieldInfo(alias="extraParams", default=None)

    scopes: Optional[List[str]] = None

    subject: Optional[str] = None


OAuthExchangeConfig: TypeAlias = Annotated[
    Union[ClientCredentialsOAuthExchange, JwtBearerOAuthExchange], PropertyInfo(discriminator="grant_type")
]
