# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .tool_source_auth import ToolSourceAuth
from .tool_approval_mode import ToolApprovalMode
from .mcp_tool_execution_policy import McpToolExecutionPolicy

__all__ = ["McpToolSource"]


class McpToolSource(BaseModel):
    id: str

    auth: ToolSourceAuth
    """Tool source authentication configuration.

    The `kind` field selects one of `none`, `api_key`, `oauth_exchange`, or
    `oauth_connection`.
    """

    created_at: str = FieldInfo(alias="createdAt")

    enabled: bool

    fleet_id: str = FieldInfo(alias="fleetId")

    namespace: str

    type: Literal["mcp"]

    updated_at: str = FieldInfo(alias="updatedAt")

    url: str

    version: float

    approval: Optional[ToolApprovalMode] = None

    execution: Optional[McpToolExecutionPolicy] = None
    """MCP discovery and execution retry/timeout policy."""
