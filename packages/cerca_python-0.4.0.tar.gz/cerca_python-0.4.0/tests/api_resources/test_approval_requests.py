# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import ApprovalRequest
from tests.utils import assert_matches_type
from cerca.pagination import SyncApprovalRequestsCursorPage, AsyncApprovalRequestsCursorPage

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestApprovalRequests:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_list(self, client: Cerca) -> None:
        approval_request = client.approval_requests.list(
            agent_id="agent_abc123",
        )
        assert_matches_type(SyncApprovalRequestsCursorPage[ApprovalRequest], approval_request, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Cerca) -> None:
        approval_request = client.approval_requests.list(
            agent_id="agent_abc123",
            cursor="cursor_abc123",
            limit="20",
            thread_id="thread_abc123",
        )
        assert_matches_type(SyncApprovalRequestsCursorPage[ApprovalRequest], approval_request, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Cerca) -> None:
        response = client.approval_requests.with_raw_response.list(
            agent_id="agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        approval_request = response.parse()
        assert_matches_type(SyncApprovalRequestsCursorPage[ApprovalRequest], approval_request, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Cerca) -> None:
        with client.approval_requests.with_streaming_response.list(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            approval_request = response.parse()
            assert_matches_type(SyncApprovalRequestsCursorPage[ApprovalRequest], approval_request, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.approval_requests.with_raw_response.list(
                agent_id="",
            )

    @parametrize
    def test_method_resolve(self, client: Cerca) -> None:
        approval_request = client.approval_requests.resolve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            approval_id="approval_abc123",
            decision="approve",
        )
        assert_matches_type(ApprovalRequest, approval_request, path=["response"])

    @parametrize
    def test_method_resolve_with_all_params(self, client: Cerca) -> None:
        approval_request = client.approval_requests.resolve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            approval_id="approval_abc123",
            decision="approve",
            grant="thread",
        )
        assert_matches_type(ApprovalRequest, approval_request, path=["response"])

    @parametrize
    def test_raw_response_resolve(self, client: Cerca) -> None:
        response = client.approval_requests.with_raw_response.resolve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            approval_id="approval_abc123",
            decision="approve",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        approval_request = response.parse()
        assert_matches_type(ApprovalRequest, approval_request, path=["response"])

    @parametrize
    def test_streaming_response_resolve(self, client: Cerca) -> None:
        with client.approval_requests.with_streaming_response.resolve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            approval_id="approval_abc123",
            decision="approve",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            approval_request = response.parse()
            assert_matches_type(ApprovalRequest, approval_request, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_resolve(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.approval_requests.with_raw_response.resolve(
                agent_id="",
                thread_id="thread_abc123",
                approval_id="approval_abc123",
                decision="approve",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.approval_requests.with_raw_response.resolve(
                agent_id="agent_abc123",
                thread_id="",
                approval_id="approval_abc123",
                decision="approve",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `approval_id` but received ''"):
            client.approval_requests.with_raw_response.resolve(
                agent_id="agent_abc123",
                thread_id="thread_abc123",
                approval_id="",
                decision="approve",
            )


class TestAsyncApprovalRequests:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_list(self, async_client: AsyncCerca) -> None:
        approval_request = await async_client.approval_requests.list(
            agent_id="agent_abc123",
        )
        assert_matches_type(AsyncApprovalRequestsCursorPage[ApprovalRequest], approval_request, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncCerca) -> None:
        approval_request = await async_client.approval_requests.list(
            agent_id="agent_abc123",
            cursor="cursor_abc123",
            limit="20",
            thread_id="thread_abc123",
        )
        assert_matches_type(AsyncApprovalRequestsCursorPage[ApprovalRequest], approval_request, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncCerca) -> None:
        response = await async_client.approval_requests.with_raw_response.list(
            agent_id="agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        approval_request = await response.parse()
        assert_matches_type(AsyncApprovalRequestsCursorPage[ApprovalRequest], approval_request, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncCerca) -> None:
        async with async_client.approval_requests.with_streaming_response.list(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            approval_request = await response.parse()
            assert_matches_type(AsyncApprovalRequestsCursorPage[ApprovalRequest], approval_request, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.approval_requests.with_raw_response.list(
                agent_id="",
            )

    @parametrize
    async def test_method_resolve(self, async_client: AsyncCerca) -> None:
        approval_request = await async_client.approval_requests.resolve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            approval_id="approval_abc123",
            decision="approve",
        )
        assert_matches_type(ApprovalRequest, approval_request, path=["response"])

    @parametrize
    async def test_method_resolve_with_all_params(self, async_client: AsyncCerca) -> None:
        approval_request = await async_client.approval_requests.resolve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            approval_id="approval_abc123",
            decision="approve",
            grant="thread",
        )
        assert_matches_type(ApprovalRequest, approval_request, path=["response"])

    @parametrize
    async def test_raw_response_resolve(self, async_client: AsyncCerca) -> None:
        response = await async_client.approval_requests.with_raw_response.resolve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            approval_id="approval_abc123",
            decision="approve",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        approval_request = await response.parse()
        assert_matches_type(ApprovalRequest, approval_request, path=["response"])

    @parametrize
    async def test_streaming_response_resolve(self, async_client: AsyncCerca) -> None:
        async with async_client.approval_requests.with_streaming_response.resolve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            approval_id="approval_abc123",
            decision="approve",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            approval_request = await response.parse()
            assert_matches_type(ApprovalRequest, approval_request, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_resolve(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.approval_requests.with_raw_response.resolve(
                agent_id="",
                thread_id="thread_abc123",
                approval_id="approval_abc123",
                decision="approve",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.approval_requests.with_raw_response.resolve(
                agent_id="agent_abc123",
                thread_id="",
                approval_id="approval_abc123",
                decision="approve",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `approval_id` but received ''"):
            await async_client.approval_requests.with_raw_response.resolve(
                agent_id="agent_abc123",
                thread_id="thread_abc123",
                approval_id="",
                decision="approve",
            )
