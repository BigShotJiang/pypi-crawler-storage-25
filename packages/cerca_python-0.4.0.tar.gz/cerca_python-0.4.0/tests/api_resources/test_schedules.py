# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import (
    Schedule,
    ScheduleListResponse,
    ScheduleDeleteResponse,
    ScheduleTriggerResponse,
)
from tests.utils import assert_matches_type
from cerca._utils import parse_datetime

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSchedules:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Cerca) -> None:
        schedule = client.schedules.create(
            agent_id="agent_abc123",
            message="message",
            name="name",
        )
        assert_matches_type(Schedule, schedule, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: Cerca) -> None:
        schedule = client.schedules.create(
            agent_id="agent_abc123",
            message="message",
            name="name",
            cron="cron",
            instructions="instructions",
            model="model",
            run_at=parse_datetime("2019-12-27T18:11:19.117Z"),
            timezone="timezone",
            tools=["sandbox.*"],
        )
        assert_matches_type(Schedule, schedule, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Cerca) -> None:
        response = client.schedules.with_raw_response.create(
            agent_id="agent_abc123",
            message="message",
            name="name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = response.parse()
        assert_matches_type(Schedule, schedule, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Cerca) -> None:
        with client.schedules.with_streaming_response.create(
            agent_id="agent_abc123",
            message="message",
            name="name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = response.parse()
            assert_matches_type(Schedule, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_create(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.schedules.with_raw_response.create(
                agent_id="",
                message="message",
                name="name",
            )

    @parametrize
    def test_method_update(self, client: Cerca) -> None:
        schedule = client.schedules.update(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        )
        assert_matches_type(Schedule, schedule, path=["response"])

    @parametrize
    def test_method_update_with_all_params(self, client: Cerca) -> None:
        schedule = client.schedules.update(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
            cron="cron",
            enabled=True,
            instructions="instructions",
            message="message",
            model="model",
            name="name",
            run_at=parse_datetime("2019-12-27T18:11:19.117Z"),
            timezone="timezone",
            tools=["sandbox.*"],
        )
        assert_matches_type(Schedule, schedule, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: Cerca) -> None:
        response = client.schedules.with_raw_response.update(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = response.parse()
        assert_matches_type(Schedule, schedule, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: Cerca) -> None:
        with client.schedules.with_streaming_response.update(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = response.parse()
            assert_matches_type(Schedule, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.schedules.with_raw_response.update(
                agent_id="",
                schedule_id="schedule_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_id` but received ''"):
            client.schedules.with_raw_response.update(
                agent_id="agent_abc123",
                schedule_id="",
            )

    @parametrize
    def test_method_list(self, client: Cerca) -> None:
        schedule = client.schedules.list(
            "agent_abc123",
        )
        assert_matches_type(ScheduleListResponse, schedule, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Cerca) -> None:
        response = client.schedules.with_raw_response.list(
            "agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = response.parse()
        assert_matches_type(ScheduleListResponse, schedule, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Cerca) -> None:
        with client.schedules.with_streaming_response.list(
            "agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = response.parse()
            assert_matches_type(ScheduleListResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.schedules.with_raw_response.list(
                "",
            )

    @parametrize
    def test_method_delete(self, client: Cerca) -> None:
        schedule = client.schedules.delete(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        )
        assert_matches_type(ScheduleDeleteResponse, schedule, path=["response"])

    @parametrize
    def test_raw_response_delete(self, client: Cerca) -> None:
        response = client.schedules.with_raw_response.delete(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = response.parse()
        assert_matches_type(ScheduleDeleteResponse, schedule, path=["response"])

    @parametrize
    def test_streaming_response_delete(self, client: Cerca) -> None:
        with client.schedules.with_streaming_response.delete(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = response.parse()
            assert_matches_type(ScheduleDeleteResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.schedules.with_raw_response.delete(
                agent_id="",
                schedule_id="schedule_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_id` but received ''"):
            client.schedules.with_raw_response.delete(
                agent_id="agent_abc123",
                schedule_id="",
            )

    @parametrize
    def test_method_trigger(self, client: Cerca) -> None:
        schedule = client.schedules.trigger(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        )
        assert_matches_type(ScheduleTriggerResponse, schedule, path=["response"])

    @parametrize
    def test_raw_response_trigger(self, client: Cerca) -> None:
        response = client.schedules.with_raw_response.trigger(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = response.parse()
        assert_matches_type(ScheduleTriggerResponse, schedule, path=["response"])

    @parametrize
    def test_streaming_response_trigger(self, client: Cerca) -> None:
        with client.schedules.with_streaming_response.trigger(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = response.parse()
            assert_matches_type(ScheduleTriggerResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_trigger(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.schedules.with_raw_response.trigger(
                agent_id="",
                schedule_id="schedule_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_id` but received ''"):
            client.schedules.with_raw_response.trigger(
                agent_id="agent_abc123",
                schedule_id="",
            )


class TestAsyncSchedules:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncCerca) -> None:
        schedule = await async_client.schedules.create(
            agent_id="agent_abc123",
            message="message",
            name="name",
        )
        assert_matches_type(Schedule, schedule, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncCerca) -> None:
        schedule = await async_client.schedules.create(
            agent_id="agent_abc123",
            message="message",
            name="name",
            cron="cron",
            instructions="instructions",
            model="model",
            run_at=parse_datetime("2019-12-27T18:11:19.117Z"),
            timezone="timezone",
            tools=["sandbox.*"],
        )
        assert_matches_type(Schedule, schedule, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncCerca) -> None:
        response = await async_client.schedules.with_raw_response.create(
            agent_id="agent_abc123",
            message="message",
            name="name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = await response.parse()
        assert_matches_type(Schedule, schedule, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncCerca) -> None:
        async with async_client.schedules.with_streaming_response.create(
            agent_id="agent_abc123",
            message="message",
            name="name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = await response.parse()
            assert_matches_type(Schedule, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_create(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.schedules.with_raw_response.create(
                agent_id="",
                message="message",
                name="name",
            )

    @parametrize
    async def test_method_update(self, async_client: AsyncCerca) -> None:
        schedule = await async_client.schedules.update(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        )
        assert_matches_type(Schedule, schedule, path=["response"])

    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncCerca) -> None:
        schedule = await async_client.schedules.update(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
            cron="cron",
            enabled=True,
            instructions="instructions",
            message="message",
            model="model",
            name="name",
            run_at=parse_datetime("2019-12-27T18:11:19.117Z"),
            timezone="timezone",
            tools=["sandbox.*"],
        )
        assert_matches_type(Schedule, schedule, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncCerca) -> None:
        response = await async_client.schedules.with_raw_response.update(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = await response.parse()
        assert_matches_type(Schedule, schedule, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncCerca) -> None:
        async with async_client.schedules.with_streaming_response.update(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = await response.parse()
            assert_matches_type(Schedule, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.schedules.with_raw_response.update(
                agent_id="",
                schedule_id="schedule_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_id` but received ''"):
            await async_client.schedules.with_raw_response.update(
                agent_id="agent_abc123",
                schedule_id="",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncCerca) -> None:
        schedule = await async_client.schedules.list(
            "agent_abc123",
        )
        assert_matches_type(ScheduleListResponse, schedule, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncCerca) -> None:
        response = await async_client.schedules.with_raw_response.list(
            "agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = await response.parse()
        assert_matches_type(ScheduleListResponse, schedule, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncCerca) -> None:
        async with async_client.schedules.with_streaming_response.list(
            "agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = await response.parse()
            assert_matches_type(ScheduleListResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.schedules.with_raw_response.list(
                "",
            )

    @parametrize
    async def test_method_delete(self, async_client: AsyncCerca) -> None:
        schedule = await async_client.schedules.delete(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        )
        assert_matches_type(ScheduleDeleteResponse, schedule, path=["response"])

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncCerca) -> None:
        response = await async_client.schedules.with_raw_response.delete(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = await response.parse()
        assert_matches_type(ScheduleDeleteResponse, schedule, path=["response"])

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncCerca) -> None:
        async with async_client.schedules.with_streaming_response.delete(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = await response.parse()
            assert_matches_type(ScheduleDeleteResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.schedules.with_raw_response.delete(
                agent_id="",
                schedule_id="schedule_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_id` but received ''"):
            await async_client.schedules.with_raw_response.delete(
                agent_id="agent_abc123",
                schedule_id="",
            )

    @parametrize
    async def test_method_trigger(self, async_client: AsyncCerca) -> None:
        schedule = await async_client.schedules.trigger(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        )
        assert_matches_type(ScheduleTriggerResponse, schedule, path=["response"])

    @parametrize
    async def test_raw_response_trigger(self, async_client: AsyncCerca) -> None:
        response = await async_client.schedules.with_raw_response.trigger(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = await response.parse()
        assert_matches_type(ScheduleTriggerResponse, schedule, path=["response"])

    @parametrize
    async def test_streaming_response_trigger(self, async_client: AsyncCerca) -> None:
        async with async_client.schedules.with_streaming_response.trigger(
            agent_id="agent_abc123",
            schedule_id="schedule_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = await response.parse()
            assert_matches_type(ScheduleTriggerResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_trigger(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.schedules.with_raw_response.trigger(
                agent_id="",
                schedule_id="schedule_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_id` but received ''"):
            await async_client.schedules.with_raw_response.trigger(
                agent_id="agent_abc123",
                schedule_id="",
            )
