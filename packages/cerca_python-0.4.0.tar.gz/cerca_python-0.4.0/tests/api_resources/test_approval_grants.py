# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import (
    ApprovalGrant,
    ApprovalGrantDeleteResponse,
    ApprovalGrantListForThreadResponse,
    ApprovalGrantDeleteForThreadResponse,
)
from tests.utils import assert_matches_type
from cerca.pagination import SyncGrantsCursorPage, AsyncGrantsCursorPage

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestApprovalGrants:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_list(self, client: Cerca) -> None:
        approval_grant = client.approval_grants.list(
            agent_id="agent_abc123",
        )
        assert_matches_type(SyncGrantsCursorPage[ApprovalGrant], approval_grant, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Cerca) -> None:
        approval_grant = client.approval_grants.list(
            agent_id="agent_abc123",
            cursor="cursor_abc123",
            limit="20",
        )
        assert_matches_type(SyncGrantsCursorPage[ApprovalGrant], approval_grant, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Cerca) -> None:
        response = client.approval_grants.with_raw_response.list(
            agent_id="agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        approval_grant = response.parse()
        assert_matches_type(SyncGrantsCursorPage[ApprovalGrant], approval_grant, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Cerca) -> None:
        with client.approval_grants.with_streaming_response.list(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            approval_grant = response.parse()
            assert_matches_type(SyncGrantsCursorPage[ApprovalGrant], approval_grant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.approval_grants.with_raw_response.list(
                agent_id="",
            )

    @parametrize
    def test_method_delete(self, client: Cerca) -> None:
        approval_grant = client.approval_grants.delete(
            agent_id="agent_abc123",
            grant_id="grant_abc123",
        )
        assert_matches_type(ApprovalGrantDeleteResponse, approval_grant, path=["response"])

    @parametrize
    def test_raw_response_delete(self, client: Cerca) -> None:
        response = client.approval_grants.with_raw_response.delete(
            agent_id="agent_abc123",
            grant_id="grant_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        approval_grant = response.parse()
        assert_matches_type(ApprovalGrantDeleteResponse, approval_grant, path=["response"])

    @parametrize
    def test_streaming_response_delete(self, client: Cerca) -> None:
        with client.approval_grants.with_streaming_response.delete(
            agent_id="agent_abc123",
            grant_id="grant_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            approval_grant = response.parse()
            assert_matches_type(ApprovalGrantDeleteResponse, approval_grant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.approval_grants.with_raw_response.delete(
                agent_id="",
                grant_id="grant_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `grant_id` but received ''"):
            client.approval_grants.with_raw_response.delete(
                agent_id="agent_abc123",
                grant_id="",
            )

    @parametrize
    def test_method_delete_for_thread(self, client: Cerca) -> None:
        approval_grant = client.approval_grants.delete_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            grant_id="grant_abc123",
        )
        assert_matches_type(ApprovalGrantDeleteForThreadResponse, approval_grant, path=["response"])

    @parametrize
    def test_raw_response_delete_for_thread(self, client: Cerca) -> None:
        response = client.approval_grants.with_raw_response.delete_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            grant_id="grant_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        approval_grant = response.parse()
        assert_matches_type(ApprovalGrantDeleteForThreadResponse, approval_grant, path=["response"])

    @parametrize
    def test_streaming_response_delete_for_thread(self, client: Cerca) -> None:
        with client.approval_grants.with_streaming_response.delete_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            grant_id="grant_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            approval_grant = response.parse()
            assert_matches_type(ApprovalGrantDeleteForThreadResponse, approval_grant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete_for_thread(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.approval_grants.with_raw_response.delete_for_thread(
                agent_id="",
                thread_id="thread_abc123",
                grant_id="grant_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.approval_grants.with_raw_response.delete_for_thread(
                agent_id="agent_abc123",
                thread_id="",
                grant_id="grant_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `grant_id` but received ''"):
            client.approval_grants.with_raw_response.delete_for_thread(
                agent_id="agent_abc123",
                thread_id="thread_abc123",
                grant_id="",
            )

    @parametrize
    def test_method_list_for_thread(self, client: Cerca) -> None:
        approval_grant = client.approval_grants.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(ApprovalGrantListForThreadResponse, approval_grant, path=["response"])

    @parametrize
    def test_raw_response_list_for_thread(self, client: Cerca) -> None:
        response = client.approval_grants.with_raw_response.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        approval_grant = response.parse()
        assert_matches_type(ApprovalGrantListForThreadResponse, approval_grant, path=["response"])

    @parametrize
    def test_streaming_response_list_for_thread(self, client: Cerca) -> None:
        with client.approval_grants.with_streaming_response.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            approval_grant = response.parse()
            assert_matches_type(ApprovalGrantListForThreadResponse, approval_grant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_for_thread(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.approval_grants.with_raw_response.list_for_thread(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.approval_grants.with_raw_response.list_for_thread(
                agent_id="agent_abc123",
                thread_id="",
            )


class TestAsyncApprovalGrants:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_list(self, async_client: AsyncCerca) -> None:
        approval_grant = await async_client.approval_grants.list(
            agent_id="agent_abc123",
        )
        assert_matches_type(AsyncGrantsCursorPage[ApprovalGrant], approval_grant, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncCerca) -> None:
        approval_grant = await async_client.approval_grants.list(
            agent_id="agent_abc123",
            cursor="cursor_abc123",
            limit="20",
        )
        assert_matches_type(AsyncGrantsCursorPage[ApprovalGrant], approval_grant, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncCerca) -> None:
        response = await async_client.approval_grants.with_raw_response.list(
            agent_id="agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        approval_grant = await response.parse()
        assert_matches_type(AsyncGrantsCursorPage[ApprovalGrant], approval_grant, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncCerca) -> None:
        async with async_client.approval_grants.with_streaming_response.list(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            approval_grant = await response.parse()
            assert_matches_type(AsyncGrantsCursorPage[ApprovalGrant], approval_grant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.approval_grants.with_raw_response.list(
                agent_id="",
            )

    @parametrize
    async def test_method_delete(self, async_client: AsyncCerca) -> None:
        approval_grant = await async_client.approval_grants.delete(
            agent_id="agent_abc123",
            grant_id="grant_abc123",
        )
        assert_matches_type(ApprovalGrantDeleteResponse, approval_grant, path=["response"])

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncCerca) -> None:
        response = await async_client.approval_grants.with_raw_response.delete(
            agent_id="agent_abc123",
            grant_id="grant_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        approval_grant = await response.parse()
        assert_matches_type(ApprovalGrantDeleteResponse, approval_grant, path=["response"])

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncCerca) -> None:
        async with async_client.approval_grants.with_streaming_response.delete(
            agent_id="agent_abc123",
            grant_id="grant_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            approval_grant = await response.parse()
            assert_matches_type(ApprovalGrantDeleteResponse, approval_grant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.approval_grants.with_raw_response.delete(
                agent_id="",
                grant_id="grant_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `grant_id` but received ''"):
            await async_client.approval_grants.with_raw_response.delete(
                agent_id="agent_abc123",
                grant_id="",
            )

    @parametrize
    async def test_method_delete_for_thread(self, async_client: AsyncCerca) -> None:
        approval_grant = await async_client.approval_grants.delete_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            grant_id="grant_abc123",
        )
        assert_matches_type(ApprovalGrantDeleteForThreadResponse, approval_grant, path=["response"])

    @parametrize
    async def test_raw_response_delete_for_thread(self, async_client: AsyncCerca) -> None:
        response = await async_client.approval_grants.with_raw_response.delete_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            grant_id="grant_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        approval_grant = await response.parse()
        assert_matches_type(ApprovalGrantDeleteForThreadResponse, approval_grant, path=["response"])

    @parametrize
    async def test_streaming_response_delete_for_thread(self, async_client: AsyncCerca) -> None:
        async with async_client.approval_grants.with_streaming_response.delete_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            grant_id="grant_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            approval_grant = await response.parse()
            assert_matches_type(ApprovalGrantDeleteForThreadResponse, approval_grant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete_for_thread(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.approval_grants.with_raw_response.delete_for_thread(
                agent_id="",
                thread_id="thread_abc123",
                grant_id="grant_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.approval_grants.with_raw_response.delete_for_thread(
                agent_id="agent_abc123",
                thread_id="",
                grant_id="grant_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `grant_id` but received ''"):
            await async_client.approval_grants.with_raw_response.delete_for_thread(
                agent_id="agent_abc123",
                thread_id="thread_abc123",
                grant_id="",
            )

    @parametrize
    async def test_method_list_for_thread(self, async_client: AsyncCerca) -> None:
        approval_grant = await async_client.approval_grants.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(ApprovalGrantListForThreadResponse, approval_grant, path=["response"])

    @parametrize
    async def test_raw_response_list_for_thread(self, async_client: AsyncCerca) -> None:
        response = await async_client.approval_grants.with_raw_response.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        approval_grant = await response.parse()
        assert_matches_type(ApprovalGrantListForThreadResponse, approval_grant, path=["response"])

    @parametrize
    async def test_streaming_response_list_for_thread(self, async_client: AsyncCerca) -> None:
        async with async_client.approval_grants.with_streaming_response.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            approval_grant = await response.parse()
            assert_matches_type(ApprovalGrantListForThreadResponse, approval_grant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_for_thread(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.approval_grants.with_raw_response.list_for_thread(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.approval_grants.with_raw_response.list_for_thread(
                agent_id="agent_abc123",
                thread_id="",
            )
