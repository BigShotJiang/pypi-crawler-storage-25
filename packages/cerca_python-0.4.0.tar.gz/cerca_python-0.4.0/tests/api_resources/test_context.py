# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import (
    Entry,
    EntrySummary,
    SearchResult,
    ContextDeleteResponse,
)
from tests.utils import assert_matches_type
from cerca.pagination import (
    SyncEntriesCursorPage,
    SyncResultsCursorPage,
    AsyncEntriesCursorPage,
    AsyncResultsCursorPage,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestContext:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_retrieve(self, client: Cerca) -> None:
        context = client.context.retrieve(
            agent_id="agent_abc123",
            key="notes/project.md",
        )
        assert_matches_type(Entry, context, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Cerca) -> None:
        response = client.context.with_raw_response.retrieve(
            agent_id="agent_abc123",
            key="notes/project.md",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        context = response.parse()
        assert_matches_type(Entry, context, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Cerca) -> None:
        with client.context.with_streaming_response.retrieve(
            agent_id="agent_abc123",
            key="notes/project.md",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            context = response.parse()
            assert_matches_type(Entry, context, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.context.with_raw_response.retrieve(
                agent_id="",
                key="notes/project.md",
            )

    @parametrize
    def test_method_list(self, client: Cerca) -> None:
        context = client.context.list(
            agent_id="agent_abc123",
        )
        assert_matches_type(SyncEntriesCursorPage[EntrySummary], context, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Cerca) -> None:
        context = client.context.list(
            agent_id="agent_abc123",
            cursor="cursor_abc123",
            limit="20",
            prefix="notes/",
        )
        assert_matches_type(SyncEntriesCursorPage[EntrySummary], context, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Cerca) -> None:
        response = client.context.with_raw_response.list(
            agent_id="agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        context = response.parse()
        assert_matches_type(SyncEntriesCursorPage[EntrySummary], context, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Cerca) -> None:
        with client.context.with_streaming_response.list(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            context = response.parse()
            assert_matches_type(SyncEntriesCursorPage[EntrySummary], context, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.context.with_raw_response.list(
                agent_id="",
            )

    @parametrize
    def test_method_delete(self, client: Cerca) -> None:
        context = client.context.delete(
            agent_id="agent_abc123",
            key="notes/project.md",
        )
        assert_matches_type(ContextDeleteResponse, context, path=["response"])

    @parametrize
    def test_raw_response_delete(self, client: Cerca) -> None:
        response = client.context.with_raw_response.delete(
            agent_id="agent_abc123",
            key="notes/project.md",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        context = response.parse()
        assert_matches_type(ContextDeleteResponse, context, path=["response"])

    @parametrize
    def test_streaming_response_delete(self, client: Cerca) -> None:
        with client.context.with_streaming_response.delete(
            agent_id="agent_abc123",
            key="notes/project.md",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            context = response.parse()
            assert_matches_type(ContextDeleteResponse, context, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.context.with_raw_response.delete(
                agent_id="",
                key="notes/project.md",
            )

    @parametrize
    def test_method_search(self, client: Cerca) -> None:
        context = client.context.search(
            agent_id="agent_abc123",
            q="project notes",
        )
        assert_matches_type(SyncResultsCursorPage[SearchResult], context, path=["response"])

    @parametrize
    def test_method_search_with_all_params(self, client: Cerca) -> None:
        context = client.context.search(
            agent_id="agent_abc123",
            q="project notes",
            cursor="cursor_abc123",
            limit="20",
            prefix="notes/",
        )
        assert_matches_type(SyncResultsCursorPage[SearchResult], context, path=["response"])

    @parametrize
    def test_raw_response_search(self, client: Cerca) -> None:
        response = client.context.with_raw_response.search(
            agent_id="agent_abc123",
            q="project notes",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        context = response.parse()
        assert_matches_type(SyncResultsCursorPage[SearchResult], context, path=["response"])

    @parametrize
    def test_streaming_response_search(self, client: Cerca) -> None:
        with client.context.with_streaming_response.search(
            agent_id="agent_abc123",
            q="project notes",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            context = response.parse()
            assert_matches_type(SyncResultsCursorPage[SearchResult], context, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_search(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.context.with_raw_response.search(
                agent_id="",
                q="project notes",
            )

    @parametrize
    def test_method_write(self, client: Cerca) -> None:
        context = client.context.write(
            agent_id="agent_abc123",
            content="content",
            key="key",
        )
        assert_matches_type(Entry, context, path=["response"])

    @parametrize
    def test_method_write_with_all_params(self, client: Cerca) -> None:
        context = client.context.write(
            agent_id="agent_abc123",
            content="content",
            key="key",
            expected_version=0,
            mime_type="mimeType",
        )
        assert_matches_type(Entry, context, path=["response"])

    @parametrize
    def test_raw_response_write(self, client: Cerca) -> None:
        response = client.context.with_raw_response.write(
            agent_id="agent_abc123",
            content="content",
            key="key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        context = response.parse()
        assert_matches_type(Entry, context, path=["response"])

    @parametrize
    def test_streaming_response_write(self, client: Cerca) -> None:
        with client.context.with_streaming_response.write(
            agent_id="agent_abc123",
            content="content",
            key="key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            context = response.parse()
            assert_matches_type(Entry, context, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_write(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.context.with_raw_response.write(
                agent_id="",
                content="content",
                key="key",
            )


class TestAsyncContext:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncCerca) -> None:
        context = await async_client.context.retrieve(
            agent_id="agent_abc123",
            key="notes/project.md",
        )
        assert_matches_type(Entry, context, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncCerca) -> None:
        response = await async_client.context.with_raw_response.retrieve(
            agent_id="agent_abc123",
            key="notes/project.md",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        context = await response.parse()
        assert_matches_type(Entry, context, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncCerca) -> None:
        async with async_client.context.with_streaming_response.retrieve(
            agent_id="agent_abc123",
            key="notes/project.md",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            context = await response.parse()
            assert_matches_type(Entry, context, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.context.with_raw_response.retrieve(
                agent_id="",
                key="notes/project.md",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncCerca) -> None:
        context = await async_client.context.list(
            agent_id="agent_abc123",
        )
        assert_matches_type(AsyncEntriesCursorPage[EntrySummary], context, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncCerca) -> None:
        context = await async_client.context.list(
            agent_id="agent_abc123",
            cursor="cursor_abc123",
            limit="20",
            prefix="notes/",
        )
        assert_matches_type(AsyncEntriesCursorPage[EntrySummary], context, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncCerca) -> None:
        response = await async_client.context.with_raw_response.list(
            agent_id="agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        context = await response.parse()
        assert_matches_type(AsyncEntriesCursorPage[EntrySummary], context, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncCerca) -> None:
        async with async_client.context.with_streaming_response.list(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            context = await response.parse()
            assert_matches_type(AsyncEntriesCursorPage[EntrySummary], context, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.context.with_raw_response.list(
                agent_id="",
            )

    @parametrize
    async def test_method_delete(self, async_client: AsyncCerca) -> None:
        context = await async_client.context.delete(
            agent_id="agent_abc123",
            key="notes/project.md",
        )
        assert_matches_type(ContextDeleteResponse, context, path=["response"])

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncCerca) -> None:
        response = await async_client.context.with_raw_response.delete(
            agent_id="agent_abc123",
            key="notes/project.md",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        context = await response.parse()
        assert_matches_type(ContextDeleteResponse, context, path=["response"])

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncCerca) -> None:
        async with async_client.context.with_streaming_response.delete(
            agent_id="agent_abc123",
            key="notes/project.md",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            context = await response.parse()
            assert_matches_type(ContextDeleteResponse, context, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.context.with_raw_response.delete(
                agent_id="",
                key="notes/project.md",
            )

    @parametrize
    async def test_method_search(self, async_client: AsyncCerca) -> None:
        context = await async_client.context.search(
            agent_id="agent_abc123",
            q="project notes",
        )
        assert_matches_type(AsyncResultsCursorPage[SearchResult], context, path=["response"])

    @parametrize
    async def test_method_search_with_all_params(self, async_client: AsyncCerca) -> None:
        context = await async_client.context.search(
            agent_id="agent_abc123",
            q="project notes",
            cursor="cursor_abc123",
            limit="20",
            prefix="notes/",
        )
        assert_matches_type(AsyncResultsCursorPage[SearchResult], context, path=["response"])

    @parametrize
    async def test_raw_response_search(self, async_client: AsyncCerca) -> None:
        response = await async_client.context.with_raw_response.search(
            agent_id="agent_abc123",
            q="project notes",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        context = await response.parse()
        assert_matches_type(AsyncResultsCursorPage[SearchResult], context, path=["response"])

    @parametrize
    async def test_streaming_response_search(self, async_client: AsyncCerca) -> None:
        async with async_client.context.with_streaming_response.search(
            agent_id="agent_abc123",
            q="project notes",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            context = await response.parse()
            assert_matches_type(AsyncResultsCursorPage[SearchResult], context, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_search(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.context.with_raw_response.search(
                agent_id="",
                q="project notes",
            )

    @parametrize
    async def test_method_write(self, async_client: AsyncCerca) -> None:
        context = await async_client.context.write(
            agent_id="agent_abc123",
            content="content",
            key="key",
        )
        assert_matches_type(Entry, context, path=["response"])

    @parametrize
    async def test_method_write_with_all_params(self, async_client: AsyncCerca) -> None:
        context = await async_client.context.write(
            agent_id="agent_abc123",
            content="content",
            key="key",
            expected_version=0,
            mime_type="mimeType",
        )
        assert_matches_type(Entry, context, path=["response"])

    @parametrize
    async def test_raw_response_write(self, async_client: AsyncCerca) -> None:
        response = await async_client.context.with_raw_response.write(
            agent_id="agent_abc123",
            content="content",
            key="key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        context = await response.parse()
        assert_matches_type(Entry, context, path=["response"])

    @parametrize
    async def test_streaming_response_write(self, async_client: AsyncCerca) -> None:
        async with async_client.context.with_streaming_response.write(
            agent_id="agent_abc123",
            content="content",
            key="key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            context = await response.parse()
            assert_matches_type(Entry, context, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_write(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.context.with_raw_response.write(
                agent_id="",
                content="content",
                key="key",
            )
