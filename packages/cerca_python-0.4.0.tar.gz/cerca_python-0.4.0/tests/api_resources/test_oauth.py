# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import OAuthConnectResponse
from tests.utils import assert_matches_type

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestOAuth:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_connect(self, client: Cerca) -> None:
        oauth = client.oauth.connect(
            provider="google",
            owner={"type": "organization"},
            return_origin="https://app.example.com",
        )
        assert_matches_type(OAuthConnectResponse, oauth, path=["response"])

    @parametrize
    def test_method_connect_with_all_params(self, client: Cerca) -> None:
        oauth = client.oauth.connect(
            provider="google",
            owner={"type": "organization"},
            return_origin="https://app.example.com",
            scopes=["email", "profile"],
        )
        assert_matches_type(OAuthConnectResponse, oauth, path=["response"])

    @parametrize
    def test_raw_response_connect(self, client: Cerca) -> None:
        response = client.oauth.with_raw_response.connect(
            provider="google",
            owner={"type": "organization"},
            return_origin="https://app.example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        oauth = response.parse()
        assert_matches_type(OAuthConnectResponse, oauth, path=["response"])

    @parametrize
    def test_streaming_response_connect(self, client: Cerca) -> None:
        with client.oauth.with_streaming_response.connect(
            provider="google",
            owner={"type": "organization"},
            return_origin="https://app.example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            oauth = response.parse()
            assert_matches_type(OAuthConnectResponse, oauth, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_connect(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `provider` but received ''"):
            client.oauth.with_raw_response.connect(
                provider="",
                owner={"type": "organization"},
                return_origin="https://app.example.com",
            )


class TestAsyncOAuth:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_connect(self, async_client: AsyncCerca) -> None:
        oauth = await async_client.oauth.connect(
            provider="google",
            owner={"type": "organization"},
            return_origin="https://app.example.com",
        )
        assert_matches_type(OAuthConnectResponse, oauth, path=["response"])

    @parametrize
    async def test_method_connect_with_all_params(self, async_client: AsyncCerca) -> None:
        oauth = await async_client.oauth.connect(
            provider="google",
            owner={"type": "organization"},
            return_origin="https://app.example.com",
            scopes=["email", "profile"],
        )
        assert_matches_type(OAuthConnectResponse, oauth, path=["response"])

    @parametrize
    async def test_raw_response_connect(self, async_client: AsyncCerca) -> None:
        response = await async_client.oauth.with_raw_response.connect(
            provider="google",
            owner={"type": "organization"},
            return_origin="https://app.example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        oauth = await response.parse()
        assert_matches_type(OAuthConnectResponse, oauth, path=["response"])

    @parametrize
    async def test_streaming_response_connect(self, async_client: AsyncCerca) -> None:
        async with async_client.oauth.with_streaming_response.connect(
            provider="google",
            owner={"type": "organization"},
            return_origin="https://app.example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            oauth = await response.parse()
            assert_matches_type(OAuthConnectResponse, oauth, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_connect(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `provider` but received ''"):
            await async_client.oauth.with_raw_response.connect(
                provider="",
                owner={"type": "organization"},
                return_origin="https://app.example.com",
            )
