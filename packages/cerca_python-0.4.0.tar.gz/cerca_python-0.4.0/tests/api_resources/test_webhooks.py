# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import (
    WebhookSubscription,
    WebhookTestResponse,
    WebhookSubscriptionCreated,
)
from tests.utils import assert_matches_type
from cerca.pagination import SyncSubscriptionsCursorPage, AsyncSubscriptionsCursorPage

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestWebhooks:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Cerca) -> None:
        webhook = client.webhooks.create(
            fleet_id="fleet_abc123",
            url="https://example.com/webhook",
        )
        assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: Cerca) -> None:
        webhook = client.webhooks.create(
            fleet_id="fleet_abc123",
            url="https://example.com/webhook",
            events=["agent.created"],
        )
        assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Cerca) -> None:
        response = client.webhooks.with_raw_response.create(
            fleet_id="fleet_abc123",
            url="https://example.com/webhook",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = response.parse()
        assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Cerca) -> None:
        with client.webhooks.with_streaming_response.create(
            fleet_id="fleet_abc123",
            url="https://example.com/webhook",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = response.parse()
            assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_create(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.webhooks.with_raw_response.create(
                fleet_id="",
                url="https://example.com/webhook",
            )

    @parametrize
    def test_method_retrieve(self, client: Cerca) -> None:
        webhook = client.webhooks.retrieve(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )
        assert_matches_type(WebhookSubscription, webhook, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Cerca) -> None:
        response = client.webhooks.with_raw_response.retrieve(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = response.parse()
        assert_matches_type(WebhookSubscription, webhook, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Cerca) -> None:
        with client.webhooks.with_streaming_response.retrieve(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = response.parse()
            assert_matches_type(WebhookSubscription, webhook, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.webhooks.with_raw_response.retrieve(
                fleet_id="",
                webhook_id="webhook_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `webhook_id` but received ''"):
            client.webhooks.with_raw_response.retrieve(
                fleet_id="fleet_abc123",
                webhook_id="",
            )

    @parametrize
    def test_method_update(self, client: Cerca) -> None:
        webhook = client.webhooks.update(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )
        assert_matches_type(WebhookSubscription, webhook, path=["response"])

    @parametrize
    def test_method_update_with_all_params(self, client: Cerca) -> None:
        webhook = client.webhooks.update(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
            enabled=True,
            events=["agent.created"],
            url="https://example.com/webhook",
        )
        assert_matches_type(WebhookSubscription, webhook, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: Cerca) -> None:
        response = client.webhooks.with_raw_response.update(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = response.parse()
        assert_matches_type(WebhookSubscription, webhook, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: Cerca) -> None:
        with client.webhooks.with_streaming_response.update(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = response.parse()
            assert_matches_type(WebhookSubscription, webhook, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.webhooks.with_raw_response.update(
                fleet_id="",
                webhook_id="webhook_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `webhook_id` but received ''"):
            client.webhooks.with_raw_response.update(
                fleet_id="fleet_abc123",
                webhook_id="",
            )

    @parametrize
    def test_method_list(self, client: Cerca) -> None:
        webhook = client.webhooks.list(
            fleet_id="fleet_abc123",
        )
        assert_matches_type(SyncSubscriptionsCursorPage[WebhookSubscription], webhook, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Cerca) -> None:
        webhook = client.webhooks.list(
            fleet_id="fleet_abc123",
            cursor="cursor_abc123",
            limit="20",
        )
        assert_matches_type(SyncSubscriptionsCursorPage[WebhookSubscription], webhook, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Cerca) -> None:
        response = client.webhooks.with_raw_response.list(
            fleet_id="fleet_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = response.parse()
        assert_matches_type(SyncSubscriptionsCursorPage[WebhookSubscription], webhook, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Cerca) -> None:
        with client.webhooks.with_streaming_response.list(
            fleet_id="fleet_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = response.parse()
            assert_matches_type(SyncSubscriptionsCursorPage[WebhookSubscription], webhook, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.webhooks.with_raw_response.list(
                fleet_id="",
            )

    @parametrize
    def test_method_delete(self, client: Cerca) -> None:
        webhook = client.webhooks.delete(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )
        assert webhook is None

    @parametrize
    def test_raw_response_delete(self, client: Cerca) -> None:
        response = client.webhooks.with_raw_response.delete(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = response.parse()
        assert webhook is None

    @parametrize
    def test_streaming_response_delete(self, client: Cerca) -> None:
        with client.webhooks.with_streaming_response.delete(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = response.parse()
            assert webhook is None

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.webhooks.with_raw_response.delete(
                fleet_id="",
                webhook_id="webhook_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `webhook_id` but received ''"):
            client.webhooks.with_raw_response.delete(
                fleet_id="fleet_abc123",
                webhook_id="",
            )

    @parametrize
    def test_method_rotate(self, client: Cerca) -> None:
        webhook = client.webhooks.rotate(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )
        assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

    @parametrize
    def test_raw_response_rotate(self, client: Cerca) -> None:
        response = client.webhooks.with_raw_response.rotate(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = response.parse()
        assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

    @parametrize
    def test_streaming_response_rotate(self, client: Cerca) -> None:
        with client.webhooks.with_streaming_response.rotate(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = response.parse()
            assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_rotate(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.webhooks.with_raw_response.rotate(
                fleet_id="",
                webhook_id="webhook_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `webhook_id` but received ''"):
            client.webhooks.with_raw_response.rotate(
                fleet_id="fleet_abc123",
                webhook_id="",
            )

    @parametrize
    def test_method_test(self, client: Cerca) -> None:
        webhook = client.webhooks.test(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )
        assert_matches_type(WebhookTestResponse, webhook, path=["response"])

    @parametrize
    def test_raw_response_test(self, client: Cerca) -> None:
        response = client.webhooks.with_raw_response.test(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = response.parse()
        assert_matches_type(WebhookTestResponse, webhook, path=["response"])

    @parametrize
    def test_streaming_response_test(self, client: Cerca) -> None:
        with client.webhooks.with_streaming_response.test(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = response.parse()
            assert_matches_type(WebhookTestResponse, webhook, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_test(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.webhooks.with_raw_response.test(
                fleet_id="",
                webhook_id="webhook_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `webhook_id` but received ''"):
            client.webhooks.with_raw_response.test(
                fleet_id="fleet_abc123",
                webhook_id="",
            )


class TestAsyncWebhooks:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncCerca) -> None:
        webhook = await async_client.webhooks.create(
            fleet_id="fleet_abc123",
            url="https://example.com/webhook",
        )
        assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncCerca) -> None:
        webhook = await async_client.webhooks.create(
            fleet_id="fleet_abc123",
            url="https://example.com/webhook",
            events=["agent.created"],
        )
        assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncCerca) -> None:
        response = await async_client.webhooks.with_raw_response.create(
            fleet_id="fleet_abc123",
            url="https://example.com/webhook",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = await response.parse()
        assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncCerca) -> None:
        async with async_client.webhooks.with_streaming_response.create(
            fleet_id="fleet_abc123",
            url="https://example.com/webhook",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = await response.parse()
            assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_create(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.webhooks.with_raw_response.create(
                fleet_id="",
                url="https://example.com/webhook",
            )

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncCerca) -> None:
        webhook = await async_client.webhooks.retrieve(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )
        assert_matches_type(WebhookSubscription, webhook, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncCerca) -> None:
        response = await async_client.webhooks.with_raw_response.retrieve(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = await response.parse()
        assert_matches_type(WebhookSubscription, webhook, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncCerca) -> None:
        async with async_client.webhooks.with_streaming_response.retrieve(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = await response.parse()
            assert_matches_type(WebhookSubscription, webhook, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.webhooks.with_raw_response.retrieve(
                fleet_id="",
                webhook_id="webhook_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `webhook_id` but received ''"):
            await async_client.webhooks.with_raw_response.retrieve(
                fleet_id="fleet_abc123",
                webhook_id="",
            )

    @parametrize
    async def test_method_update(self, async_client: AsyncCerca) -> None:
        webhook = await async_client.webhooks.update(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )
        assert_matches_type(WebhookSubscription, webhook, path=["response"])

    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncCerca) -> None:
        webhook = await async_client.webhooks.update(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
            enabled=True,
            events=["agent.created"],
            url="https://example.com/webhook",
        )
        assert_matches_type(WebhookSubscription, webhook, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncCerca) -> None:
        response = await async_client.webhooks.with_raw_response.update(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = await response.parse()
        assert_matches_type(WebhookSubscription, webhook, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncCerca) -> None:
        async with async_client.webhooks.with_streaming_response.update(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = await response.parse()
            assert_matches_type(WebhookSubscription, webhook, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.webhooks.with_raw_response.update(
                fleet_id="",
                webhook_id="webhook_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `webhook_id` but received ''"):
            await async_client.webhooks.with_raw_response.update(
                fleet_id="fleet_abc123",
                webhook_id="",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncCerca) -> None:
        webhook = await async_client.webhooks.list(
            fleet_id="fleet_abc123",
        )
        assert_matches_type(AsyncSubscriptionsCursorPage[WebhookSubscription], webhook, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncCerca) -> None:
        webhook = await async_client.webhooks.list(
            fleet_id="fleet_abc123",
            cursor="cursor_abc123",
            limit="20",
        )
        assert_matches_type(AsyncSubscriptionsCursorPage[WebhookSubscription], webhook, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncCerca) -> None:
        response = await async_client.webhooks.with_raw_response.list(
            fleet_id="fleet_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = await response.parse()
        assert_matches_type(AsyncSubscriptionsCursorPage[WebhookSubscription], webhook, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncCerca) -> None:
        async with async_client.webhooks.with_streaming_response.list(
            fleet_id="fleet_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = await response.parse()
            assert_matches_type(AsyncSubscriptionsCursorPage[WebhookSubscription], webhook, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.webhooks.with_raw_response.list(
                fleet_id="",
            )

    @parametrize
    async def test_method_delete(self, async_client: AsyncCerca) -> None:
        webhook = await async_client.webhooks.delete(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )
        assert webhook is None

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncCerca) -> None:
        response = await async_client.webhooks.with_raw_response.delete(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = await response.parse()
        assert webhook is None

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncCerca) -> None:
        async with async_client.webhooks.with_streaming_response.delete(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = await response.parse()
            assert webhook is None

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.webhooks.with_raw_response.delete(
                fleet_id="",
                webhook_id="webhook_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `webhook_id` but received ''"):
            await async_client.webhooks.with_raw_response.delete(
                fleet_id="fleet_abc123",
                webhook_id="",
            )

    @parametrize
    async def test_method_rotate(self, async_client: AsyncCerca) -> None:
        webhook = await async_client.webhooks.rotate(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )
        assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

    @parametrize
    async def test_raw_response_rotate(self, async_client: AsyncCerca) -> None:
        response = await async_client.webhooks.with_raw_response.rotate(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = await response.parse()
        assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

    @parametrize
    async def test_streaming_response_rotate(self, async_client: AsyncCerca) -> None:
        async with async_client.webhooks.with_streaming_response.rotate(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = await response.parse()
            assert_matches_type(WebhookSubscriptionCreated, webhook, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_rotate(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.webhooks.with_raw_response.rotate(
                fleet_id="",
                webhook_id="webhook_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `webhook_id` but received ''"):
            await async_client.webhooks.with_raw_response.rotate(
                fleet_id="fleet_abc123",
                webhook_id="",
            )

    @parametrize
    async def test_method_test(self, async_client: AsyncCerca) -> None:
        webhook = await async_client.webhooks.test(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )
        assert_matches_type(WebhookTestResponse, webhook, path=["response"])

    @parametrize
    async def test_raw_response_test(self, async_client: AsyncCerca) -> None:
        response = await async_client.webhooks.with_raw_response.test(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        webhook = await response.parse()
        assert_matches_type(WebhookTestResponse, webhook, path=["response"])

    @parametrize
    async def test_streaming_response_test(self, async_client: AsyncCerca) -> None:
        async with async_client.webhooks.with_streaming_response.test(
            fleet_id="fleet_abc123",
            webhook_id="webhook_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            webhook = await response.parse()
            assert_matches_type(WebhookTestResponse, webhook, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_test(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.webhooks.with_raw_response.test(
                fleet_id="",
                webhook_id="webhook_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `webhook_id` but received ''"):
            await async_client.webhooks.with_raw_response.test(
                fleet_id="fleet_abc123",
                webhook_id="",
            )
