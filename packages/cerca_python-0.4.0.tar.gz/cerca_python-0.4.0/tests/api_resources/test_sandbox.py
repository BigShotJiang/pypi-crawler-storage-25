# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import (
    ExecResult,
    ReadResponse,
    SandboxWriteResponse,
)
from tests.utils import assert_matches_type

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSandbox:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_exec(self, client: Cerca) -> None:
        sandbox = client.sandbox.exec(
            agent_id="agent_abc123",
            command="command",
        )
        assert_matches_type(ExecResult, sandbox, path=["response"])

    @parametrize
    def test_method_exec_with_all_params(self, client: Cerca) -> None:
        sandbox = client.sandbox.exec(
            agent_id="agent_abc123",
            command="command",
            max_buffer=0,
            execution_timeout=30,
            workdir="/home/user",
        )
        assert_matches_type(ExecResult, sandbox, path=["response"])

    @parametrize
    def test_raw_response_exec(self, client: Cerca) -> None:
        response = client.sandbox.with_raw_response.exec(
            agent_id="agent_abc123",
            command="command",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sandbox = response.parse()
        assert_matches_type(ExecResult, sandbox, path=["response"])

    @parametrize
    def test_streaming_response_exec(self, client: Cerca) -> None:
        with client.sandbox.with_streaming_response.exec(
            agent_id="agent_abc123",
            command="command",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sandbox = response.parse()
            assert_matches_type(ExecResult, sandbox, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_exec(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.sandbox.with_raw_response.exec(
                agent_id="",
                command="command",
            )

    @parametrize
    def test_method_read(self, client: Cerca) -> None:
        sandbox = client.sandbox.read(
            agent_id="agent_abc123",
            path="path",
        )
        assert_matches_type(ReadResponse, sandbox, path=["response"])

    @parametrize
    def test_method_read_with_all_params(self, client: Cerca) -> None:
        sandbox = client.sandbox.read(
            agent_id="agent_abc123",
            path="path",
            limit=0,
            offset=0,
        )
        assert_matches_type(ReadResponse, sandbox, path=["response"])

    @parametrize
    def test_raw_response_read(self, client: Cerca) -> None:
        response = client.sandbox.with_raw_response.read(
            agent_id="agent_abc123",
            path="path",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sandbox = response.parse()
        assert_matches_type(ReadResponse, sandbox, path=["response"])

    @parametrize
    def test_streaming_response_read(self, client: Cerca) -> None:
        with client.sandbox.with_streaming_response.read(
            agent_id="agent_abc123",
            path="path",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sandbox = response.parse()
            assert_matches_type(ReadResponse, sandbox, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_read(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.sandbox.with_raw_response.read(
                agent_id="",
                path="path",
            )

    @parametrize
    def test_method_write(self, client: Cerca) -> None:
        sandbox = client.sandbox.write(
            agent_id="agent_abc123",
            content="content",
            path="path",
        )
        assert_matches_type(SandboxWriteResponse, sandbox, path=["response"])

    @parametrize
    def test_raw_response_write(self, client: Cerca) -> None:
        response = client.sandbox.with_raw_response.write(
            agent_id="agent_abc123",
            content="content",
            path="path",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sandbox = response.parse()
        assert_matches_type(SandboxWriteResponse, sandbox, path=["response"])

    @parametrize
    def test_streaming_response_write(self, client: Cerca) -> None:
        with client.sandbox.with_streaming_response.write(
            agent_id="agent_abc123",
            content="content",
            path="path",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sandbox = response.parse()
            assert_matches_type(SandboxWriteResponse, sandbox, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_write(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.sandbox.with_raw_response.write(
                agent_id="",
                content="content",
                path="path",
            )


class TestAsyncSandbox:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_exec(self, async_client: AsyncCerca) -> None:
        sandbox = await async_client.sandbox.exec(
            agent_id="agent_abc123",
            command="command",
        )
        assert_matches_type(ExecResult, sandbox, path=["response"])

    @parametrize
    async def test_method_exec_with_all_params(self, async_client: AsyncCerca) -> None:
        sandbox = await async_client.sandbox.exec(
            agent_id="agent_abc123",
            command="command",
            max_buffer=0,
            execution_timeout=30,
            workdir="/home/user",
        )
        assert_matches_type(ExecResult, sandbox, path=["response"])

    @parametrize
    async def test_raw_response_exec(self, async_client: AsyncCerca) -> None:
        response = await async_client.sandbox.with_raw_response.exec(
            agent_id="agent_abc123",
            command="command",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sandbox = await response.parse()
        assert_matches_type(ExecResult, sandbox, path=["response"])

    @parametrize
    async def test_streaming_response_exec(self, async_client: AsyncCerca) -> None:
        async with async_client.sandbox.with_streaming_response.exec(
            agent_id="agent_abc123",
            command="command",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sandbox = await response.parse()
            assert_matches_type(ExecResult, sandbox, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_exec(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.sandbox.with_raw_response.exec(
                agent_id="",
                command="command",
            )

    @parametrize
    async def test_method_read(self, async_client: AsyncCerca) -> None:
        sandbox = await async_client.sandbox.read(
            agent_id="agent_abc123",
            path="path",
        )
        assert_matches_type(ReadResponse, sandbox, path=["response"])

    @parametrize
    async def test_method_read_with_all_params(self, async_client: AsyncCerca) -> None:
        sandbox = await async_client.sandbox.read(
            agent_id="agent_abc123",
            path="path",
            limit=0,
            offset=0,
        )
        assert_matches_type(ReadResponse, sandbox, path=["response"])

    @parametrize
    async def test_raw_response_read(self, async_client: AsyncCerca) -> None:
        response = await async_client.sandbox.with_raw_response.read(
            agent_id="agent_abc123",
            path="path",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sandbox = await response.parse()
        assert_matches_type(ReadResponse, sandbox, path=["response"])

    @parametrize
    async def test_streaming_response_read(self, async_client: AsyncCerca) -> None:
        async with async_client.sandbox.with_streaming_response.read(
            agent_id="agent_abc123",
            path="path",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sandbox = await response.parse()
            assert_matches_type(ReadResponse, sandbox, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_read(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.sandbox.with_raw_response.read(
                agent_id="",
                path="path",
            )

    @parametrize
    async def test_method_write(self, async_client: AsyncCerca) -> None:
        sandbox = await async_client.sandbox.write(
            agent_id="agent_abc123",
            content="content",
            path="path",
        )
        assert_matches_type(SandboxWriteResponse, sandbox, path=["response"])

    @parametrize
    async def test_raw_response_write(self, async_client: AsyncCerca) -> None:
        response = await async_client.sandbox.with_raw_response.write(
            agent_id="agent_abc123",
            content="content",
            path="path",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sandbox = await response.parse()
        assert_matches_type(SandboxWriteResponse, sandbox, path=["response"])

    @parametrize
    async def test_streaming_response_write(self, async_client: AsyncCerca) -> None:
        async with async_client.sandbox.with_streaming_response.write(
            agent_id="agent_abc123",
            content="content",
            path="path",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sandbox = await response.parse()
            assert_matches_type(SandboxWriteResponse, sandbox, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_write(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.sandbox.with_raw_response.write(
                agent_id="",
                content="content",
                path="path",
            )
