# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import (
    ToolSource,
)
from tests.utils import assert_matches_type
from cerca.pagination import SyncSourcesCursorPage, AsyncSourcesCursorPage

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestTools:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create_overload_1(self, client: Cerca) -> None:
        tool = client.tools.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                }
            ],
            type="http",
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_method_create_with_all_params_overload_1(self, client: Cerca) -> None:
        tool = client.tools.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                        "body": "json_params",
                        "headers": {"foo": "string"},
                        "path": {"foo": "params.query"},
                        "query": {"foo": "params.query"},
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                    "approval": "always",
                    "execution": {
                        "idempotency_key_header": "idempotencyKeyHeader",
                        "max_attempts": 3,
                        "retry_mode": "safe_only",
                        "timeout_ms": 10000,
                    },
                    "response": {"mode": "auto"},
                }
            ],
            type="http",
            approval="always",
            enabled=True,
            execution={
                "idempotency_key_header": "idempotencyKeyHeader",
                "max_attempts": 3,
                "retry_mode": "safe_only",
                "timeout_ms": 10000,
            },
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_raw_response_create_overload_1(self, client: Cerca) -> None:
        response = client.tools.with_raw_response.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                }
            ],
            type="http",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = response.parse()
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_streaming_response_create_overload_1(self, client: Cerca) -> None:
        with client.tools.with_streaming_response.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                }
            ],
            type="http",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = response.parse()
            assert_matches_type(ToolSource, tool, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_create_overload_1(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.tools.with_raw_response.create(
                fleet_id="",
                auth={"kind": "none"},
                namespace="docs",
                tools=[
                    {
                        "description": "Search documents",
                        "endpoint": {
                            "method": "GET",
                            "url": "https://docs.example.com/search",
                        },
                        "input_schema": {"type": "bar"},
                        "name": "search",
                    }
                ],
                type="http",
            )

    @parametrize
    def test_method_create_overload_2(self, client: Cerca) -> None:
        tool = client.tools.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_method_create_with_all_params_overload_2(self, client: Cerca) -> None:
        tool = client.tools.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
            approval="always",
            enabled=True,
            execution={
                "discovery_timeout_ms": 5000,
                "execution_timeout_ms": 30000,
                "max_attempts": 2,
                "retry_mode": "connect_only",
            },
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_raw_response_create_overload_2(self, client: Cerca) -> None:
        response = client.tools.with_raw_response.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = response.parse()
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_streaming_response_create_overload_2(self, client: Cerca) -> None:
        with client.tools.with_streaming_response.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = response.parse()
            assert_matches_type(ToolSource, tool, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_create_overload_2(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.tools.with_raw_response.create(
                fleet_id="",
                auth={"kind": "none"},
                namespace="docs",
                type="mcp",
                url="https://mcp.example.com",
            )

    @parametrize
    def test_method_retrieve(self, client: Cerca) -> None:
        tool = client.tools.retrieve(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Cerca) -> None:
        response = client.tools.with_raw_response.retrieve(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = response.parse()
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Cerca) -> None:
        with client.tools.with_streaming_response.retrieve(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = response.parse()
            assert_matches_type(ToolSource, tool, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.tools.with_raw_response.retrieve(
                fleet_id="",
                source_id="toolsrc_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `source_id` but received ''"):
            client.tools.with_raw_response.retrieve(
                fleet_id="fleet_abc123",
                source_id="",
            )

    @parametrize
    def test_method_update_overload_1(self, client: Cerca) -> None:
        tool = client.tools.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                }
            ],
            type="http",
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_method_update_with_all_params_overload_1(self, client: Cerca) -> None:
        tool = client.tools.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                        "body": "json_params",
                        "headers": {"foo": "string"},
                        "path": {"foo": "params.query"},
                        "query": {"foo": "params.query"},
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                    "approval": "always",
                    "execution": {
                        "idempotency_key_header": "idempotencyKeyHeader",
                        "max_attempts": 3,
                        "retry_mode": "safe_only",
                        "timeout_ms": 10000,
                    },
                    "response": {"mode": "auto"},
                }
            ],
            type="http",
            approval="always",
            enabled=True,
            execution={
                "idempotency_key_header": "idempotencyKeyHeader",
                "max_attempts": 3,
                "retry_mode": "safe_only",
                "timeout_ms": 10000,
            },
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_raw_response_update_overload_1(self, client: Cerca) -> None:
        response = client.tools.with_raw_response.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                }
            ],
            type="http",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = response.parse()
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_streaming_response_update_overload_1(self, client: Cerca) -> None:
        with client.tools.with_streaming_response.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                }
            ],
            type="http",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = response.parse()
            assert_matches_type(ToolSource, tool, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update_overload_1(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.tools.with_raw_response.update(
                fleet_id="",
                source_id="toolsrc_abc123",
                auth={"kind": "none"},
                namespace="docs",
                tools=[
                    {
                        "description": "Search documents",
                        "endpoint": {
                            "method": "GET",
                            "url": "https://docs.example.com/search",
                        },
                        "input_schema": {"type": "bar"},
                        "name": "search",
                    }
                ],
                type="http",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `source_id` but received ''"):
            client.tools.with_raw_response.update(
                fleet_id="fleet_abc123",
                source_id="",
                auth={"kind": "none"},
                namespace="docs",
                tools=[
                    {
                        "description": "Search documents",
                        "endpoint": {
                            "method": "GET",
                            "url": "https://docs.example.com/search",
                        },
                        "input_schema": {"type": "bar"},
                        "name": "search",
                    }
                ],
                type="http",
            )

    @parametrize
    def test_method_update_overload_2(self, client: Cerca) -> None:
        tool = client.tools.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_method_update_with_all_params_overload_2(self, client: Cerca) -> None:
        tool = client.tools.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
            approval="always",
            enabled=True,
            execution={
                "discovery_timeout_ms": 5000,
                "execution_timeout_ms": 30000,
                "max_attempts": 2,
                "retry_mode": "connect_only",
            },
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_raw_response_update_overload_2(self, client: Cerca) -> None:
        response = client.tools.with_raw_response.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = response.parse()
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    def test_streaming_response_update_overload_2(self, client: Cerca) -> None:
        with client.tools.with_streaming_response.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = response.parse()
            assert_matches_type(ToolSource, tool, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update_overload_2(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.tools.with_raw_response.update(
                fleet_id="",
                source_id="toolsrc_abc123",
                auth={"kind": "none"},
                namespace="docs",
                type="mcp",
                url="https://mcp.example.com",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `source_id` but received ''"):
            client.tools.with_raw_response.update(
                fleet_id="fleet_abc123",
                source_id="",
                auth={"kind": "none"},
                namespace="docs",
                type="mcp",
                url="https://mcp.example.com",
            )

    @parametrize
    def test_method_list(self, client: Cerca) -> None:
        tool = client.tools.list(
            fleet_id="fleet_abc123",
        )
        assert_matches_type(SyncSourcesCursorPage[ToolSource], tool, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Cerca) -> None:
        tool = client.tools.list(
            fleet_id="fleet_abc123",
            cursor="cursor_abc123",
            limit="20",
        )
        assert_matches_type(SyncSourcesCursorPage[ToolSource], tool, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Cerca) -> None:
        response = client.tools.with_raw_response.list(
            fleet_id="fleet_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = response.parse()
        assert_matches_type(SyncSourcesCursorPage[ToolSource], tool, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Cerca) -> None:
        with client.tools.with_streaming_response.list(
            fleet_id="fleet_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = response.parse()
            assert_matches_type(SyncSourcesCursorPage[ToolSource], tool, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.tools.with_raw_response.list(
                fleet_id="",
            )

    @parametrize
    def test_method_delete(self, client: Cerca) -> None:
        tool = client.tools.delete(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
        )
        assert tool is None

    @parametrize
    def test_raw_response_delete(self, client: Cerca) -> None:
        response = client.tools.with_raw_response.delete(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = response.parse()
        assert tool is None

    @parametrize
    def test_streaming_response_delete(self, client: Cerca) -> None:
        with client.tools.with_streaming_response.delete(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = response.parse()
            assert tool is None

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.tools.with_raw_response.delete(
                fleet_id="",
                source_id="toolsrc_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `source_id` but received ''"):
            client.tools.with_raw_response.delete(
                fleet_id="fleet_abc123",
                source_id="",
            )


class TestAsyncTools:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create_overload_1(self, async_client: AsyncCerca) -> None:
        tool = await async_client.tools.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                }
            ],
            type="http",
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_method_create_with_all_params_overload_1(self, async_client: AsyncCerca) -> None:
        tool = await async_client.tools.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                        "body": "json_params",
                        "headers": {"foo": "string"},
                        "path": {"foo": "params.query"},
                        "query": {"foo": "params.query"},
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                    "approval": "always",
                    "execution": {
                        "idempotency_key_header": "idempotencyKeyHeader",
                        "max_attempts": 3,
                        "retry_mode": "safe_only",
                        "timeout_ms": 10000,
                    },
                    "response": {"mode": "auto"},
                }
            ],
            type="http",
            approval="always",
            enabled=True,
            execution={
                "idempotency_key_header": "idempotencyKeyHeader",
                "max_attempts": 3,
                "retry_mode": "safe_only",
                "timeout_ms": 10000,
            },
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_raw_response_create_overload_1(self, async_client: AsyncCerca) -> None:
        response = await async_client.tools.with_raw_response.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                }
            ],
            type="http",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = await response.parse()
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_streaming_response_create_overload_1(self, async_client: AsyncCerca) -> None:
        async with async_client.tools.with_streaming_response.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                }
            ],
            type="http",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = await response.parse()
            assert_matches_type(ToolSource, tool, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_create_overload_1(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.tools.with_raw_response.create(
                fleet_id="",
                auth={"kind": "none"},
                namespace="docs",
                tools=[
                    {
                        "description": "Search documents",
                        "endpoint": {
                            "method": "GET",
                            "url": "https://docs.example.com/search",
                        },
                        "input_schema": {"type": "bar"},
                        "name": "search",
                    }
                ],
                type="http",
            )

    @parametrize
    async def test_method_create_overload_2(self, async_client: AsyncCerca) -> None:
        tool = await async_client.tools.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_method_create_with_all_params_overload_2(self, async_client: AsyncCerca) -> None:
        tool = await async_client.tools.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
            approval="always",
            enabled=True,
            execution={
                "discovery_timeout_ms": 5000,
                "execution_timeout_ms": 30000,
                "max_attempts": 2,
                "retry_mode": "connect_only",
            },
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_raw_response_create_overload_2(self, async_client: AsyncCerca) -> None:
        response = await async_client.tools.with_raw_response.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = await response.parse()
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_streaming_response_create_overload_2(self, async_client: AsyncCerca) -> None:
        async with async_client.tools.with_streaming_response.create(
            fleet_id="fleet_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = await response.parse()
            assert_matches_type(ToolSource, tool, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_create_overload_2(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.tools.with_raw_response.create(
                fleet_id="",
                auth={"kind": "none"},
                namespace="docs",
                type="mcp",
                url="https://mcp.example.com",
            )

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncCerca) -> None:
        tool = await async_client.tools.retrieve(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncCerca) -> None:
        response = await async_client.tools.with_raw_response.retrieve(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = await response.parse()
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncCerca) -> None:
        async with async_client.tools.with_streaming_response.retrieve(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = await response.parse()
            assert_matches_type(ToolSource, tool, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.tools.with_raw_response.retrieve(
                fleet_id="",
                source_id="toolsrc_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `source_id` but received ''"):
            await async_client.tools.with_raw_response.retrieve(
                fleet_id="fleet_abc123",
                source_id="",
            )

    @parametrize
    async def test_method_update_overload_1(self, async_client: AsyncCerca) -> None:
        tool = await async_client.tools.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                }
            ],
            type="http",
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_method_update_with_all_params_overload_1(self, async_client: AsyncCerca) -> None:
        tool = await async_client.tools.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                        "body": "json_params",
                        "headers": {"foo": "string"},
                        "path": {"foo": "params.query"},
                        "query": {"foo": "params.query"},
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                    "approval": "always",
                    "execution": {
                        "idempotency_key_header": "idempotencyKeyHeader",
                        "max_attempts": 3,
                        "retry_mode": "safe_only",
                        "timeout_ms": 10000,
                    },
                    "response": {"mode": "auto"},
                }
            ],
            type="http",
            approval="always",
            enabled=True,
            execution={
                "idempotency_key_header": "idempotencyKeyHeader",
                "max_attempts": 3,
                "retry_mode": "safe_only",
                "timeout_ms": 10000,
            },
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_raw_response_update_overload_1(self, async_client: AsyncCerca) -> None:
        response = await async_client.tools.with_raw_response.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                }
            ],
            type="http",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = await response.parse()
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_streaming_response_update_overload_1(self, async_client: AsyncCerca) -> None:
        async with async_client.tools.with_streaming_response.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            tools=[
                {
                    "description": "Search documents",
                    "endpoint": {
                        "method": "GET",
                        "url": "https://docs.example.com/search",
                    },
                    "input_schema": {"type": "bar"},
                    "name": "search",
                }
            ],
            type="http",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = await response.parse()
            assert_matches_type(ToolSource, tool, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update_overload_1(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.tools.with_raw_response.update(
                fleet_id="",
                source_id="toolsrc_abc123",
                auth={"kind": "none"},
                namespace="docs",
                tools=[
                    {
                        "description": "Search documents",
                        "endpoint": {
                            "method": "GET",
                            "url": "https://docs.example.com/search",
                        },
                        "input_schema": {"type": "bar"},
                        "name": "search",
                    }
                ],
                type="http",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `source_id` but received ''"):
            await async_client.tools.with_raw_response.update(
                fleet_id="fleet_abc123",
                source_id="",
                auth={"kind": "none"},
                namespace="docs",
                tools=[
                    {
                        "description": "Search documents",
                        "endpoint": {
                            "method": "GET",
                            "url": "https://docs.example.com/search",
                        },
                        "input_schema": {"type": "bar"},
                        "name": "search",
                    }
                ],
                type="http",
            )

    @parametrize
    async def test_method_update_overload_2(self, async_client: AsyncCerca) -> None:
        tool = await async_client.tools.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_method_update_with_all_params_overload_2(self, async_client: AsyncCerca) -> None:
        tool = await async_client.tools.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
            approval="always",
            enabled=True,
            execution={
                "discovery_timeout_ms": 5000,
                "execution_timeout_ms": 30000,
                "max_attempts": 2,
                "retry_mode": "connect_only",
            },
        )
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_raw_response_update_overload_2(self, async_client: AsyncCerca) -> None:
        response = await async_client.tools.with_raw_response.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = await response.parse()
        assert_matches_type(ToolSource, tool, path=["response"])

    @parametrize
    async def test_streaming_response_update_overload_2(self, async_client: AsyncCerca) -> None:
        async with async_client.tools.with_streaming_response.update(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
            auth={"kind": "none"},
            namespace="docs",
            type="mcp",
            url="https://mcp.example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = await response.parse()
            assert_matches_type(ToolSource, tool, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update_overload_2(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.tools.with_raw_response.update(
                fleet_id="",
                source_id="toolsrc_abc123",
                auth={"kind": "none"},
                namespace="docs",
                type="mcp",
                url="https://mcp.example.com",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `source_id` but received ''"):
            await async_client.tools.with_raw_response.update(
                fleet_id="fleet_abc123",
                source_id="",
                auth={"kind": "none"},
                namespace="docs",
                type="mcp",
                url="https://mcp.example.com",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncCerca) -> None:
        tool = await async_client.tools.list(
            fleet_id="fleet_abc123",
        )
        assert_matches_type(AsyncSourcesCursorPage[ToolSource], tool, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncCerca) -> None:
        tool = await async_client.tools.list(
            fleet_id="fleet_abc123",
            cursor="cursor_abc123",
            limit="20",
        )
        assert_matches_type(AsyncSourcesCursorPage[ToolSource], tool, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncCerca) -> None:
        response = await async_client.tools.with_raw_response.list(
            fleet_id="fleet_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = await response.parse()
        assert_matches_type(AsyncSourcesCursorPage[ToolSource], tool, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncCerca) -> None:
        async with async_client.tools.with_streaming_response.list(
            fleet_id="fleet_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = await response.parse()
            assert_matches_type(AsyncSourcesCursorPage[ToolSource], tool, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.tools.with_raw_response.list(
                fleet_id="",
            )

    @parametrize
    async def test_method_delete(self, async_client: AsyncCerca) -> None:
        tool = await async_client.tools.delete(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
        )
        assert tool is None

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncCerca) -> None:
        response = await async_client.tools.with_raw_response.delete(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tool = await response.parse()
        assert tool is None

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncCerca) -> None:
        async with async_client.tools.with_streaming_response.delete(
            fleet_id="fleet_abc123",
            source_id="toolsrc_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tool = await response.parse()
            assert tool is None

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.tools.with_raw_response.delete(
                fleet_id="",
                source_id="toolsrc_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `source_id` but received ''"):
            await async_client.tools.with_raw_response.delete(
                fleet_id="fleet_abc123",
                source_id="",
            )
