# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import (
    Turn,
    Thread,
    Message,
    SteerResult,
    ThreadSummary,
    ActivityDetail,
)
from tests.utils import assert_matches_type
from cerca.pagination import (
    SyncThreadsCursorPage,
    AsyncThreadsCursorPage,
    SyncThreadMessagesCursorPage,
    AsyncThreadMessagesCursorPage,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestThreads:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Cerca) -> None:
        thread = client.threads.create(
            agent_id="agent_abc123",
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: Cerca) -> None:
        thread = client.threads.create(
            agent_id="agent_abc123",
            instructions="instructions",
            message="message",
            model="model",
            system_prompt="systemPrompt",
            tools=["sandbox.*"],
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Cerca) -> None:
        response = client.threads.with_raw_response.create(
            agent_id="agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = response.parse()
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Cerca) -> None:
        with client.threads.with_streaming_response.create(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = response.parse()
            assert_matches_type(Thread, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_create(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.threads.with_raw_response.create(
                agent_id="",
            )

    @parametrize
    def test_method_retrieve(self, client: Cerca) -> None:
        thread = client.threads.retrieve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    def test_method_retrieve_with_all_params(self, client: Cerca) -> None:
        thread = client.threads.retrieve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            debug="false",
            include_messages="true",
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Cerca) -> None:
        response = client.threads.with_raw_response.retrieve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = response.parse()
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Cerca) -> None:
        with client.threads.with_streaming_response.retrieve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = response.parse()
            assert_matches_type(Thread, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.threads.with_raw_response.retrieve(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.threads.with_raw_response.retrieve(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    def test_method_list(self, client: Cerca) -> None:
        thread = client.threads.list(
            agent_id="agent_abc123",
        )
        assert_matches_type(SyncThreadsCursorPage[ThreadSummary], thread, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Cerca) -> None:
        thread = client.threads.list(
            agent_id="agent_abc123",
            cursor="cursor_abc123",
            limit="20",
            schedule_id="schedule_abc123",
            status="idle",
        )
        assert_matches_type(SyncThreadsCursorPage[ThreadSummary], thread, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Cerca) -> None:
        response = client.threads.with_raw_response.list(
            agent_id="agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = response.parse()
        assert_matches_type(SyncThreadsCursorPage[ThreadSummary], thread, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Cerca) -> None:
        with client.threads.with_streaming_response.list(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = response.parse()
            assert_matches_type(SyncThreadsCursorPage[ThreadSummary], thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.threads.with_raw_response.list(
                agent_id="",
            )

    @parametrize
    def test_method_activity(self, client: Cerca) -> None:
        thread = client.threads.activity(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(ActivityDetail, thread, path=["response"])

    @parametrize
    def test_method_activity_with_all_params(self, client: Cerca) -> None:
        thread = client.threads.activity(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            fleet_id="fleetId",
        )
        assert_matches_type(ActivityDetail, thread, path=["response"])

    @parametrize
    def test_raw_response_activity(self, client: Cerca) -> None:
        response = client.threads.with_raw_response.activity(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = response.parse()
        assert_matches_type(ActivityDetail, thread, path=["response"])

    @parametrize
    def test_streaming_response_activity(self, client: Cerca) -> None:
        with client.threads.with_streaming_response.activity(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = response.parse()
            assert_matches_type(ActivityDetail, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_activity(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.threads.with_raw_response.activity(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.threads.with_raw_response.activity(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    def test_method_cancel(self, client: Cerca) -> None:
        thread = client.threads.cancel(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    def test_raw_response_cancel(self, client: Cerca) -> None:
        response = client.threads.with_raw_response.cancel(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = response.parse()
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    def test_streaming_response_cancel(self, client: Cerca) -> None:
        with client.threads.with_streaming_response.cancel(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = response.parse()
            assert_matches_type(Thread, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_cancel(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.threads.with_raw_response.cancel(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.threads.with_raw_response.cancel(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    def test_method_close(self, client: Cerca) -> None:
        thread = client.threads.close(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    def test_raw_response_close(self, client: Cerca) -> None:
        response = client.threads.with_raw_response.close(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = response.parse()
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    def test_streaming_response_close(self, client: Cerca) -> None:
        with client.threads.with_streaming_response.close(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = response.parse()
            assert_matches_type(Thread, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_close(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.threads.with_raw_response.close(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.threads.with_raw_response.close(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    def test_method_compact(self, client: Cerca) -> None:
        thread = client.threads.compact(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    def test_raw_response_compact(self, client: Cerca) -> None:
        response = client.threads.with_raw_response.compact(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = response.parse()
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    def test_streaming_response_compact(self, client: Cerca) -> None:
        with client.threads.with_streaming_response.compact(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = response.parse()
            assert_matches_type(Thread, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_compact(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.threads.with_raw_response.compact(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.threads.with_raw_response.compact(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    def test_method_list_messages(self, client: Cerca) -> None:
        thread = client.threads.list_messages(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(SyncThreadMessagesCursorPage[Message], thread, path=["response"])

    @parametrize
    def test_method_list_messages_with_all_params(self, client: Cerca) -> None:
        thread = client.threads.list_messages(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            cursor="42",
            fleet_id="fleetId",
            limit="100",
        )
        assert_matches_type(SyncThreadMessagesCursorPage[Message], thread, path=["response"])

    @parametrize
    def test_raw_response_list_messages(self, client: Cerca) -> None:
        response = client.threads.with_raw_response.list_messages(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = response.parse()
        assert_matches_type(SyncThreadMessagesCursorPage[Message], thread, path=["response"])

    @parametrize
    def test_streaming_response_list_messages(self, client: Cerca) -> None:
        with client.threads.with_streaming_response.list_messages(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = response.parse()
            assert_matches_type(SyncThreadMessagesCursorPage[Message], thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_messages(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.threads.with_raw_response.list_messages(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.threads.with_raw_response.list_messages(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    def test_method_start_turn(self, client: Cerca) -> None:
        thread = client.threads.start_turn(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
        )
        assert_matches_type(Turn, thread, path=["response"])

    @parametrize
    def test_method_start_turn_with_all_params(self, client: Cerca) -> None:
        thread = client.threads.start_turn(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
            model="model",
            tools=["sandbox.*"],
        )
        assert_matches_type(Turn, thread, path=["response"])

    @parametrize
    def test_raw_response_start_turn(self, client: Cerca) -> None:
        response = client.threads.with_raw_response.start_turn(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = response.parse()
        assert_matches_type(Turn, thread, path=["response"])

    @parametrize
    def test_streaming_response_start_turn(self, client: Cerca) -> None:
        with client.threads.with_streaming_response.start_turn(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = response.parse()
            assert_matches_type(Turn, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_start_turn(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.threads.with_raw_response.start_turn(
                agent_id="",
                thread_id="thread_abc123",
                message="message",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.threads.with_raw_response.start_turn(
                agent_id="agent_abc123",
                thread_id="",
                message="message",
            )

    @parametrize
    def test_method_steer(self, client: Cerca) -> None:
        thread = client.threads.steer(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
        )
        assert_matches_type(SteerResult, thread, path=["response"])

    @parametrize
    def test_raw_response_steer(self, client: Cerca) -> None:
        response = client.threads.with_raw_response.steer(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = response.parse()
        assert_matches_type(SteerResult, thread, path=["response"])

    @parametrize
    def test_streaming_response_steer(self, client: Cerca) -> None:
        with client.threads.with_streaming_response.steer(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = response.parse()
            assert_matches_type(SteerResult, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_steer(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.threads.with_raw_response.steer(
                agent_id="",
                thread_id="thread_abc123",
                message="message",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.threads.with_raw_response.steer(
                agent_id="agent_abc123",
                thread_id="",
                message="message",
            )


class TestAsyncThreads:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.create(
            agent_id="agent_abc123",
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.create(
            agent_id="agent_abc123",
            instructions="instructions",
            message="message",
            model="model",
            system_prompt="systemPrompt",
            tools=["sandbox.*"],
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncCerca) -> None:
        response = await async_client.threads.with_raw_response.create(
            agent_id="agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = await response.parse()
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncCerca) -> None:
        async with async_client.threads.with_streaming_response.create(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = await response.parse()
            assert_matches_type(Thread, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_create(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.threads.with_raw_response.create(
                agent_id="",
            )

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.retrieve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    async def test_method_retrieve_with_all_params(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.retrieve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            debug="false",
            include_messages="true",
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncCerca) -> None:
        response = await async_client.threads.with_raw_response.retrieve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = await response.parse()
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncCerca) -> None:
        async with async_client.threads.with_streaming_response.retrieve(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = await response.parse()
            assert_matches_type(Thread, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.threads.with_raw_response.retrieve(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.threads.with_raw_response.retrieve(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.list(
            agent_id="agent_abc123",
        )
        assert_matches_type(AsyncThreadsCursorPage[ThreadSummary], thread, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.list(
            agent_id="agent_abc123",
            cursor="cursor_abc123",
            limit="20",
            schedule_id="schedule_abc123",
            status="idle",
        )
        assert_matches_type(AsyncThreadsCursorPage[ThreadSummary], thread, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncCerca) -> None:
        response = await async_client.threads.with_raw_response.list(
            agent_id="agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = await response.parse()
        assert_matches_type(AsyncThreadsCursorPage[ThreadSummary], thread, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncCerca) -> None:
        async with async_client.threads.with_streaming_response.list(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = await response.parse()
            assert_matches_type(AsyncThreadsCursorPage[ThreadSummary], thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.threads.with_raw_response.list(
                agent_id="",
            )

    @parametrize
    async def test_method_activity(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.activity(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(ActivityDetail, thread, path=["response"])

    @parametrize
    async def test_method_activity_with_all_params(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.activity(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            fleet_id="fleetId",
        )
        assert_matches_type(ActivityDetail, thread, path=["response"])

    @parametrize
    async def test_raw_response_activity(self, async_client: AsyncCerca) -> None:
        response = await async_client.threads.with_raw_response.activity(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = await response.parse()
        assert_matches_type(ActivityDetail, thread, path=["response"])

    @parametrize
    async def test_streaming_response_activity(self, async_client: AsyncCerca) -> None:
        async with async_client.threads.with_streaming_response.activity(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = await response.parse()
            assert_matches_type(ActivityDetail, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_activity(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.threads.with_raw_response.activity(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.threads.with_raw_response.activity(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    async def test_method_cancel(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.cancel(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    async def test_raw_response_cancel(self, async_client: AsyncCerca) -> None:
        response = await async_client.threads.with_raw_response.cancel(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = await response.parse()
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    async def test_streaming_response_cancel(self, async_client: AsyncCerca) -> None:
        async with async_client.threads.with_streaming_response.cancel(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = await response.parse()
            assert_matches_type(Thread, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_cancel(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.threads.with_raw_response.cancel(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.threads.with_raw_response.cancel(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    async def test_method_close(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.close(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    async def test_raw_response_close(self, async_client: AsyncCerca) -> None:
        response = await async_client.threads.with_raw_response.close(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = await response.parse()
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    async def test_streaming_response_close(self, async_client: AsyncCerca) -> None:
        async with async_client.threads.with_streaming_response.close(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = await response.parse()
            assert_matches_type(Thread, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_close(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.threads.with_raw_response.close(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.threads.with_raw_response.close(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    async def test_method_compact(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.compact(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    async def test_raw_response_compact(self, async_client: AsyncCerca) -> None:
        response = await async_client.threads.with_raw_response.compact(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = await response.parse()
        assert_matches_type(Thread, thread, path=["response"])

    @parametrize
    async def test_streaming_response_compact(self, async_client: AsyncCerca) -> None:
        async with async_client.threads.with_streaming_response.compact(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = await response.parse()
            assert_matches_type(Thread, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_compact(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.threads.with_raw_response.compact(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.threads.with_raw_response.compact(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    async def test_method_list_messages(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.list_messages(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(AsyncThreadMessagesCursorPage[Message], thread, path=["response"])

    @parametrize
    async def test_method_list_messages_with_all_params(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.list_messages(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            cursor="42",
            fleet_id="fleetId",
            limit="100",
        )
        assert_matches_type(AsyncThreadMessagesCursorPage[Message], thread, path=["response"])

    @parametrize
    async def test_raw_response_list_messages(self, async_client: AsyncCerca) -> None:
        response = await async_client.threads.with_raw_response.list_messages(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = await response.parse()
        assert_matches_type(AsyncThreadMessagesCursorPage[Message], thread, path=["response"])

    @parametrize
    async def test_streaming_response_list_messages(self, async_client: AsyncCerca) -> None:
        async with async_client.threads.with_streaming_response.list_messages(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = await response.parse()
            assert_matches_type(AsyncThreadMessagesCursorPage[Message], thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_messages(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.threads.with_raw_response.list_messages(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.threads.with_raw_response.list_messages(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    async def test_method_start_turn(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.start_turn(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
        )
        assert_matches_type(Turn, thread, path=["response"])

    @parametrize
    async def test_method_start_turn_with_all_params(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.start_turn(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
            model="model",
            tools=["sandbox.*"],
        )
        assert_matches_type(Turn, thread, path=["response"])

    @parametrize
    async def test_raw_response_start_turn(self, async_client: AsyncCerca) -> None:
        response = await async_client.threads.with_raw_response.start_turn(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = await response.parse()
        assert_matches_type(Turn, thread, path=["response"])

    @parametrize
    async def test_streaming_response_start_turn(self, async_client: AsyncCerca) -> None:
        async with async_client.threads.with_streaming_response.start_turn(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = await response.parse()
            assert_matches_type(Turn, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_start_turn(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.threads.with_raw_response.start_turn(
                agent_id="",
                thread_id="thread_abc123",
                message="message",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.threads.with_raw_response.start_turn(
                agent_id="agent_abc123",
                thread_id="",
                message="message",
            )

    @parametrize
    async def test_method_steer(self, async_client: AsyncCerca) -> None:
        thread = await async_client.threads.steer(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
        )
        assert_matches_type(SteerResult, thread, path=["response"])

    @parametrize
    async def test_raw_response_steer(self, async_client: AsyncCerca) -> None:
        response = await async_client.threads.with_raw_response.steer(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thread = await response.parse()
        assert_matches_type(SteerResult, thread, path=["response"])

    @parametrize
    async def test_streaming_response_steer(self, async_client: AsyncCerca) -> None:
        async with async_client.threads.with_streaming_response.steer(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            message="message",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thread = await response.parse()
            assert_matches_type(SteerResult, thread, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_steer(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.threads.with_raw_response.steer(
                agent_id="",
                thread_id="thread_abc123",
                message="message",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.threads.with_raw_response.steer(
                agent_id="agent_abc123",
                thread_id="",
                message="message",
            )
