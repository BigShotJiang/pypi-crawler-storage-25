# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import Fleet, AuthContextResponse
from tests.utils import assert_matches_type
from cerca.pagination import SyncFleetsCursorPage, AsyncFleetsCursorPage

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAuth:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_context(self, client: Cerca) -> None:
        auth = client.auth.context()
        assert_matches_type(AuthContextResponse, auth, path=["response"])

    @parametrize
    def test_raw_response_context(self, client: Cerca) -> None:
        response = client.auth.with_raw_response.context()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = response.parse()
        assert_matches_type(AuthContextResponse, auth, path=["response"])

    @parametrize
    def test_streaming_response_context(self, client: Cerca) -> None:
        with client.auth.with_streaming_response.context() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = response.parse()
            assert_matches_type(AuthContextResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_list_fleets(self, client: Cerca) -> None:
        auth = client.auth.list_fleets()
        assert_matches_type(SyncFleetsCursorPage[Fleet], auth, path=["response"])

    @parametrize
    def test_method_list_fleets_with_all_params(self, client: Cerca) -> None:
        auth = client.auth.list_fleets(
            cursor="cursor_abc123",
            limit="20",
        )
        assert_matches_type(SyncFleetsCursorPage[Fleet], auth, path=["response"])

    @parametrize
    def test_raw_response_list_fleets(self, client: Cerca) -> None:
        response = client.auth.with_raw_response.list_fleets()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = response.parse()
        assert_matches_type(SyncFleetsCursorPage[Fleet], auth, path=["response"])

    @parametrize
    def test_streaming_response_list_fleets(self, client: Cerca) -> None:
        with client.auth.with_streaming_response.list_fleets() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = response.parse()
            assert_matches_type(SyncFleetsCursorPage[Fleet], auth, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncAuth:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_context(self, async_client: AsyncCerca) -> None:
        auth = await async_client.auth.context()
        assert_matches_type(AuthContextResponse, auth, path=["response"])

    @parametrize
    async def test_raw_response_context(self, async_client: AsyncCerca) -> None:
        response = await async_client.auth.with_raw_response.context()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = await response.parse()
        assert_matches_type(AuthContextResponse, auth, path=["response"])

    @parametrize
    async def test_streaming_response_context(self, async_client: AsyncCerca) -> None:
        async with async_client.auth.with_streaming_response.context() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = await response.parse()
            assert_matches_type(AuthContextResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_list_fleets(self, async_client: AsyncCerca) -> None:
        auth = await async_client.auth.list_fleets()
        assert_matches_type(AsyncFleetsCursorPage[Fleet], auth, path=["response"])

    @parametrize
    async def test_method_list_fleets_with_all_params(self, async_client: AsyncCerca) -> None:
        auth = await async_client.auth.list_fleets(
            cursor="cursor_abc123",
            limit="20",
        )
        assert_matches_type(AsyncFleetsCursorPage[Fleet], auth, path=["response"])

    @parametrize
    async def test_raw_response_list_fleets(self, async_client: AsyncCerca) -> None:
        response = await async_client.auth.with_raw_response.list_fleets()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = await response.parse()
        assert_matches_type(AsyncFleetsCursorPage[Fleet], auth, path=["response"])

    @parametrize
    async def test_streaming_response_list_fleets(self, async_client: AsyncCerca) -> None:
        async with async_client.auth.with_streaming_response.list_fleets() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = await response.parse()
            assert_matches_type(AsyncFleetsCursorPage[Fleet], auth, path=["response"])

        assert cast(Any, response.is_closed) is True
