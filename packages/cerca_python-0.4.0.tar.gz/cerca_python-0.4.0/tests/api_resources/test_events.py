# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import (
    SubscriptionEvent,
)
from tests.utils import assert_matches_type
from cerca.pagination import SyncEventsCursorPage, AsyncEventsCursorPage

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestEvents:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_list_for_agent(self, client: Cerca) -> None:
        event = client.events.list_for_agent(
            agent_id="agent_abc123",
        )
        assert_matches_type(SyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    def test_method_list_for_agent_with_all_params(self, client: Cerca) -> None:
        event = client.events.list_for_agent(
            agent_id="agent_abc123",
            cursor="cursor_abc123",
            events="thread.created,thread.completed",
            history="true",
            limit="20",
        )
        assert_matches_type(SyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    def test_raw_response_list_for_agent(self, client: Cerca) -> None:
        response = client.events.with_raw_response.list_for_agent(
            agent_id="agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = response.parse()
        assert_matches_type(SyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    def test_streaming_response_list_for_agent(self, client: Cerca) -> None:
        with client.events.with_streaming_response.list_for_agent(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = response.parse()
            assert_matches_type(SyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_for_agent(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.events.with_raw_response.list_for_agent(
                agent_id="",
            )

    @parametrize
    def test_method_list_for_fleet(self, client: Cerca) -> None:
        event = client.events.list_for_fleet(
            fleet_id="fleet_abc123",
        )
        assert_matches_type(SyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    def test_method_list_for_fleet_with_all_params(self, client: Cerca) -> None:
        event = client.events.list_for_fleet(
            fleet_id="fleet_abc123",
            cursor="cursor_abc123",
            events="thread.created,thread.completed",
            history="true",
            limit="20",
        )
        assert_matches_type(SyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    def test_raw_response_list_for_fleet(self, client: Cerca) -> None:
        response = client.events.with_raw_response.list_for_fleet(
            fleet_id="fleet_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = response.parse()
        assert_matches_type(SyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    def test_streaming_response_list_for_fleet(self, client: Cerca) -> None:
        with client.events.with_streaming_response.list_for_fleet(
            fleet_id="fleet_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = response.parse()
            assert_matches_type(SyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_for_fleet(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.events.with_raw_response.list_for_fleet(
                fleet_id="",
            )

    @parametrize
    def test_method_list_for_thread(self, client: Cerca) -> None:
        event = client.events.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(SyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    def test_method_list_for_thread_with_all_params(self, client: Cerca) -> None:
        event = client.events.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            cursor="cursor_abc123",
            events="thread.created,thread.completed",
            history="true",
            limit="20",
        )
        assert_matches_type(SyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    def test_raw_response_list_for_thread(self, client: Cerca) -> None:
        response = client.events.with_raw_response.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = response.parse()
        assert_matches_type(SyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    def test_streaming_response_list_for_thread(self, client: Cerca) -> None:
        with client.events.with_streaming_response.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = response.parse()
            assert_matches_type(SyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_for_thread(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.events.with_raw_response.list_for_thread(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.events.with_raw_response.list_for_thread(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    def test_method_stream_for_agent(self, client: Cerca) -> None:
        event_stream = client.events.stream_for_agent(
            agent_id="agent_abc123",
        )
        event_stream.response.close()

    @parametrize
    def test_method_stream_for_agent_with_all_params(self, client: Cerca) -> None:
        event_stream = client.events.stream_for_agent(
            agent_id="agent_abc123",
            cursor="cursor_abc123",
            events="thread.created,thread.completed",
            history="true",
            last_event_id="4711",
        )
        event_stream.response.close()

    @parametrize
    def test_raw_response_stream_for_agent(self, client: Cerca) -> None:
        response = client.events.with_raw_response.stream_for_agent(
            agent_id="agent_abc123",
        )

        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = response.parse()
        stream.close()

    @parametrize
    def test_streaming_response_stream_for_agent(self, client: Cerca) -> None:
        with client.events.with_streaming_response.stream_for_agent(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = response.parse()
            stream.close()

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_stream_for_agent(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.events.with_raw_response.stream_for_agent(
                agent_id="",
            )

    @parametrize
    def test_method_stream_for_fleet(self, client: Cerca) -> None:
        event_stream = client.events.stream_for_fleet(
            fleet_id="fleet_abc123",
        )
        event_stream.response.close()

    @parametrize
    def test_method_stream_for_fleet_with_all_params(self, client: Cerca) -> None:
        event_stream = client.events.stream_for_fleet(
            fleet_id="fleet_abc123",
            cursor="cursor_abc123",
            events="thread.created,thread.completed",
            history="true",
            last_event_id="4711",
        )
        event_stream.response.close()

    @parametrize
    def test_raw_response_stream_for_fleet(self, client: Cerca) -> None:
        response = client.events.with_raw_response.stream_for_fleet(
            fleet_id="fleet_abc123",
        )

        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = response.parse()
        stream.close()

    @parametrize
    def test_streaming_response_stream_for_fleet(self, client: Cerca) -> None:
        with client.events.with_streaming_response.stream_for_fleet(
            fleet_id="fleet_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = response.parse()
            stream.close()

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_stream_for_fleet(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            client.events.with_raw_response.stream_for_fleet(
                fleet_id="",
            )

    @parametrize
    def test_method_stream_for_thread(self, client: Cerca) -> None:
        event_stream = client.events.stream_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        event_stream.response.close()

    @parametrize
    def test_raw_response_stream_for_thread(self, client: Cerca) -> None:
        response = client.events.with_raw_response.stream_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = response.parse()
        stream.close()

    @parametrize
    def test_streaming_response_stream_for_thread(self, client: Cerca) -> None:
        with client.events.with_streaming_response.stream_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = response.parse()
            stream.close()

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_stream_for_thread(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.events.with_raw_response.stream_for_thread(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.events.with_raw_response.stream_for_thread(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    def test_method_stream_for_thread_events(self, client: Cerca) -> None:
        event_stream = client.events.stream_for_thread_events(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        event_stream.response.close()

    @parametrize
    def test_method_stream_for_thread_events_with_all_params(self, client: Cerca) -> None:
        event_stream = client.events.stream_for_thread_events(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            cursor="cursor_abc123",
            events="thread.created,thread.completed",
            history="true",
            last_event_id="4711",
        )
        event_stream.response.close()

    @parametrize
    def test_raw_response_stream_for_thread_events(self, client: Cerca) -> None:
        response = client.events.with_raw_response.stream_for_thread_events(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = response.parse()
        stream.close()

    @parametrize
    def test_streaming_response_stream_for_thread_events(self, client: Cerca) -> None:
        with client.events.with_streaming_response.stream_for_thread_events(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = response.parse()
            stream.close()

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_stream_for_thread_events(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.events.with_raw_response.stream_for_thread_events(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            client.events.with_raw_response.stream_for_thread_events(
                agent_id="agent_abc123",
                thread_id="",
            )


class TestAsyncEvents:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_list_for_agent(self, async_client: AsyncCerca) -> None:
        event = await async_client.events.list_for_agent(
            agent_id="agent_abc123",
        )
        assert_matches_type(AsyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    async def test_method_list_for_agent_with_all_params(self, async_client: AsyncCerca) -> None:
        event = await async_client.events.list_for_agent(
            agent_id="agent_abc123",
            cursor="cursor_abc123",
            events="thread.created,thread.completed",
            history="true",
            limit="20",
        )
        assert_matches_type(AsyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    async def test_raw_response_list_for_agent(self, async_client: AsyncCerca) -> None:
        response = await async_client.events.with_raw_response.list_for_agent(
            agent_id="agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = await response.parse()
        assert_matches_type(AsyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    async def test_streaming_response_list_for_agent(self, async_client: AsyncCerca) -> None:
        async with async_client.events.with_streaming_response.list_for_agent(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = await response.parse()
            assert_matches_type(AsyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_for_agent(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.events.with_raw_response.list_for_agent(
                agent_id="",
            )

    @parametrize
    async def test_method_list_for_fleet(self, async_client: AsyncCerca) -> None:
        event = await async_client.events.list_for_fleet(
            fleet_id="fleet_abc123",
        )
        assert_matches_type(AsyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    async def test_method_list_for_fleet_with_all_params(self, async_client: AsyncCerca) -> None:
        event = await async_client.events.list_for_fleet(
            fleet_id="fleet_abc123",
            cursor="cursor_abc123",
            events="thread.created,thread.completed",
            history="true",
            limit="20",
        )
        assert_matches_type(AsyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    async def test_raw_response_list_for_fleet(self, async_client: AsyncCerca) -> None:
        response = await async_client.events.with_raw_response.list_for_fleet(
            fleet_id="fleet_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = await response.parse()
        assert_matches_type(AsyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    async def test_streaming_response_list_for_fleet(self, async_client: AsyncCerca) -> None:
        async with async_client.events.with_streaming_response.list_for_fleet(
            fleet_id="fleet_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = await response.parse()
            assert_matches_type(AsyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_for_fleet(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.events.with_raw_response.list_for_fleet(
                fleet_id="",
            )

    @parametrize
    async def test_method_list_for_thread(self, async_client: AsyncCerca) -> None:
        event = await async_client.events.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        assert_matches_type(AsyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    async def test_method_list_for_thread_with_all_params(self, async_client: AsyncCerca) -> None:
        event = await async_client.events.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            cursor="cursor_abc123",
            events="thread.created,thread.completed",
            history="true",
            limit="20",
        )
        assert_matches_type(AsyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    async def test_raw_response_list_for_thread(self, async_client: AsyncCerca) -> None:
        response = await async_client.events.with_raw_response.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = await response.parse()
        assert_matches_type(AsyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

    @parametrize
    async def test_streaming_response_list_for_thread(self, async_client: AsyncCerca) -> None:
        async with async_client.events.with_streaming_response.list_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = await response.parse()
            assert_matches_type(AsyncEventsCursorPage[SubscriptionEvent], event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_for_thread(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.events.with_raw_response.list_for_thread(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.events.with_raw_response.list_for_thread(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    async def test_method_stream_for_agent(self, async_client: AsyncCerca) -> None:
        event_stream = await async_client.events.stream_for_agent(
            agent_id="agent_abc123",
        )
        await event_stream.response.aclose()

    @parametrize
    async def test_method_stream_for_agent_with_all_params(self, async_client: AsyncCerca) -> None:
        event_stream = await async_client.events.stream_for_agent(
            agent_id="agent_abc123",
            cursor="cursor_abc123",
            events="thread.created,thread.completed",
            history="true",
            last_event_id="4711",
        )
        await event_stream.response.aclose()

    @parametrize
    async def test_raw_response_stream_for_agent(self, async_client: AsyncCerca) -> None:
        response = await async_client.events.with_raw_response.stream_for_agent(
            agent_id="agent_abc123",
        )

        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = await response.parse()
        await stream.close()

    @parametrize
    async def test_streaming_response_stream_for_agent(self, async_client: AsyncCerca) -> None:
        async with async_client.events.with_streaming_response.stream_for_agent(
            agent_id="agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = await response.parse()
            await stream.close()

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_stream_for_agent(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.events.with_raw_response.stream_for_agent(
                agent_id="",
            )

    @parametrize
    async def test_method_stream_for_fleet(self, async_client: AsyncCerca) -> None:
        event_stream = await async_client.events.stream_for_fleet(
            fleet_id="fleet_abc123",
        )
        await event_stream.response.aclose()

    @parametrize
    async def test_method_stream_for_fleet_with_all_params(self, async_client: AsyncCerca) -> None:
        event_stream = await async_client.events.stream_for_fleet(
            fleet_id="fleet_abc123",
            cursor="cursor_abc123",
            events="thread.created,thread.completed",
            history="true",
            last_event_id="4711",
        )
        await event_stream.response.aclose()

    @parametrize
    async def test_raw_response_stream_for_fleet(self, async_client: AsyncCerca) -> None:
        response = await async_client.events.with_raw_response.stream_for_fleet(
            fleet_id="fleet_abc123",
        )

        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = await response.parse()
        await stream.close()

    @parametrize
    async def test_streaming_response_stream_for_fleet(self, async_client: AsyncCerca) -> None:
        async with async_client.events.with_streaming_response.stream_for_fleet(
            fleet_id="fleet_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = await response.parse()
            await stream.close()

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_stream_for_fleet(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `fleet_id` but received ''"):
            await async_client.events.with_raw_response.stream_for_fleet(
                fleet_id="",
            )

    @parametrize
    async def test_method_stream_for_thread(self, async_client: AsyncCerca) -> None:
        event_stream = await async_client.events.stream_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        await event_stream.response.aclose()

    @parametrize
    async def test_raw_response_stream_for_thread(self, async_client: AsyncCerca) -> None:
        response = await async_client.events.with_raw_response.stream_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = await response.parse()
        await stream.close()

    @parametrize
    async def test_streaming_response_stream_for_thread(self, async_client: AsyncCerca) -> None:
        async with async_client.events.with_streaming_response.stream_for_thread(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = await response.parse()
            await stream.close()

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_stream_for_thread(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.events.with_raw_response.stream_for_thread(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.events.with_raw_response.stream_for_thread(
                agent_id="agent_abc123",
                thread_id="",
            )

    @parametrize
    async def test_method_stream_for_thread_events(self, async_client: AsyncCerca) -> None:
        event_stream = await async_client.events.stream_for_thread_events(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )
        await event_stream.response.aclose()

    @parametrize
    async def test_method_stream_for_thread_events_with_all_params(self, async_client: AsyncCerca) -> None:
        event_stream = await async_client.events.stream_for_thread_events(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
            cursor="cursor_abc123",
            events="thread.created,thread.completed",
            history="true",
            last_event_id="4711",
        )
        await event_stream.response.aclose()

    @parametrize
    async def test_raw_response_stream_for_thread_events(self, async_client: AsyncCerca) -> None:
        response = await async_client.events.with_raw_response.stream_for_thread_events(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        )

        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = await response.parse()
        await stream.close()

    @parametrize
    async def test_streaming_response_stream_for_thread_events(self, async_client: AsyncCerca) -> None:
        async with async_client.events.with_streaming_response.stream_for_thread_events(
            agent_id="agent_abc123",
            thread_id="thread_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = await response.parse()
            await stream.close()

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_stream_for_thread_events(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.events.with_raw_response.stream_for_thread_events(
                agent_id="",
                thread_id="thread_abc123",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `thread_id` but received ''"):
            await async_client.events.with_raw_response.stream_for_thread_events(
                agent_id="agent_abc123",
                thread_id="",
            )
