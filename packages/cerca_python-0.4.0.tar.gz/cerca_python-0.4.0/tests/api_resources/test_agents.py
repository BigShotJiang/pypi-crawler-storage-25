# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import (
    Agent,
    AgentSummary,
    AgentDeleteResponse,
    AgentListToolsResponse,
    EffectiveConfiguration,
)
from tests.utils import assert_matches_type
from cerca.pagination import SyncAgentsCursorPage, AsyncAgentsCursorPage

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAgents:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Cerca) -> None:
        agent = client.agents.create()
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: Cerca) -> None:
        agent = client.agents.create(
            configuration={
                "approvals": {
                    "timeout_ms": 0,
                    "tools": {"foo": "always"},
                },
                "default_model": "defaultModel",
                "instructions": "instructions",
                "tools": ["sandbox.*"],
            },
            fleet_id="fleetId",
            metadata={"project": "alpha"},
            user_id="userId",
        )
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Cerca) -> None:
        response = client.agents.with_raw_response.create()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Cerca) -> None:
        with client.agents.with_streaming_response.create() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(Agent, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_retrieve(self, client: Cerca) -> None:
        agent = client.agents.retrieve(
            "agent_abc123",
        )
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Cerca) -> None:
        response = client.agents.with_raw_response.retrieve(
            "agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Cerca) -> None:
        with client.agents.with_streaming_response.retrieve(
            "agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(Agent, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_update(self, client: Cerca) -> None:
        agent = client.agents.update(
            agent_id="agent_abc123",
            configuration={},
        )
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    def test_method_update_with_all_params(self, client: Cerca) -> None:
        agent = client.agents.update(
            agent_id="agent_abc123",
            configuration={
                "approvals": {
                    "timeout_ms": 0,
                    "tools": {"foo": "always"},
                },
                "default_model": "defaultModel",
                "instructions": "instructions",
                "tools": ["sandbox.*"],
            },
        )
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: Cerca) -> None:
        response = client.agents.with_raw_response.update(
            agent_id="agent_abc123",
            configuration={},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: Cerca) -> None:
        with client.agents.with_streaming_response.update(
            agent_id="agent_abc123",
            configuration={},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(Agent, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.with_raw_response.update(
                agent_id="",
                configuration={},
            )

    @parametrize
    def test_method_list(self, client: Cerca) -> None:
        agent = client.agents.list()
        assert_matches_type(SyncAgentsCursorPage[AgentSummary], agent, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Cerca) -> None:
        agent = client.agents.list(
            active="true",
            cursor="cursor_abc123",
            fleet_id="fleet_abc123",
            limit="20",
        )
        assert_matches_type(SyncAgentsCursorPage[AgentSummary], agent, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Cerca) -> None:
        response = client.agents.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(SyncAgentsCursorPage[AgentSummary], agent, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Cerca) -> None:
        with client.agents.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(SyncAgentsCursorPage[AgentSummary], agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_delete(self, client: Cerca) -> None:
        agent = client.agents.delete(
            "agent_abc123",
        )
        assert_matches_type(AgentDeleteResponse, agent, path=["response"])

    @parametrize
    def test_raw_response_delete(self, client: Cerca) -> None:
        response = client.agents.with_raw_response.delete(
            "agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentDeleteResponse, agent, path=["response"])

    @parametrize
    def test_streaming_response_delete(self, client: Cerca) -> None:
        with client.agents.with_streaming_response.delete(
            "agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentDeleteResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.with_raw_response.delete(
                "",
            )

    @parametrize
    def test_method_list_tools(self, client: Cerca) -> None:
        agent = client.agents.list_tools(
            "agent_abc123",
        )
        assert_matches_type(AgentListToolsResponse, agent, path=["response"])

    @parametrize
    def test_raw_response_list_tools(self, client: Cerca) -> None:
        response = client.agents.with_raw_response.list_tools(
            "agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentListToolsResponse, agent, path=["response"])

    @parametrize
    def test_streaming_response_list_tools(self, client: Cerca) -> None:
        with client.agents.with_streaming_response.list_tools(
            "agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentListToolsResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_tools(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.with_raw_response.list_tools(
                "",
            )

    @parametrize
    def test_method_retrieve_config(self, client: Cerca) -> None:
        agent = client.agents.retrieve_config(
            "agent_abc123",
        )
        assert_matches_type(EffectiveConfiguration, agent, path=["response"])

    @parametrize
    def test_raw_response_retrieve_config(self, client: Cerca) -> None:
        response = client.agents.with_raw_response.retrieve_config(
            "agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(EffectiveConfiguration, agent, path=["response"])

    @parametrize
    def test_streaming_response_retrieve_config(self, client: Cerca) -> None:
        with client.agents.with_streaming_response.retrieve_config(
            "agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(EffectiveConfiguration, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve_config(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.with_raw_response.retrieve_config(
                "",
            )

    @parametrize
    def test_method_update_metadata(self, client: Cerca) -> None:
        agent = client.agents.update_metadata(
            agent_id="agent_abc123",
            metadata={"project": "alpha"},
        )
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    def test_raw_response_update_metadata(self, client: Cerca) -> None:
        response = client.agents.with_raw_response.update_metadata(
            agent_id="agent_abc123",
            metadata={"project": "alpha"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    def test_streaming_response_update_metadata(self, client: Cerca) -> None:
        with client.agents.with_streaming_response.update_metadata(
            agent_id="agent_abc123",
            metadata={"project": "alpha"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(Agent, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update_metadata(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.with_raw_response.update_metadata(
                agent_id="",
                metadata={"project": "alpha"},
            )


class TestAsyncAgents:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncCerca) -> None:
        agent = await async_client.agents.create()
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncCerca) -> None:
        agent = await async_client.agents.create(
            configuration={
                "approvals": {
                    "timeout_ms": 0,
                    "tools": {"foo": "always"},
                },
                "default_model": "defaultModel",
                "instructions": "instructions",
                "tools": ["sandbox.*"],
            },
            fleet_id="fleetId",
            metadata={"project": "alpha"},
            user_id="userId",
        )
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncCerca) -> None:
        response = await async_client.agents.with_raw_response.create()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncCerca) -> None:
        async with async_client.agents.with_streaming_response.create() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(Agent, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncCerca) -> None:
        agent = await async_client.agents.retrieve(
            "agent_abc123",
        )
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncCerca) -> None:
        response = await async_client.agents.with_raw_response.retrieve(
            "agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncCerca) -> None:
        async with async_client.agents.with_streaming_response.retrieve(
            "agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(Agent, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_update(self, async_client: AsyncCerca) -> None:
        agent = await async_client.agents.update(
            agent_id="agent_abc123",
            configuration={},
        )
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncCerca) -> None:
        agent = await async_client.agents.update(
            agent_id="agent_abc123",
            configuration={
                "approvals": {
                    "timeout_ms": 0,
                    "tools": {"foo": "always"},
                },
                "default_model": "defaultModel",
                "instructions": "instructions",
                "tools": ["sandbox.*"],
            },
        )
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncCerca) -> None:
        response = await async_client.agents.with_raw_response.update(
            agent_id="agent_abc123",
            configuration={},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncCerca) -> None:
        async with async_client.agents.with_streaming_response.update(
            agent_id="agent_abc123",
            configuration={},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(Agent, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.with_raw_response.update(
                agent_id="",
                configuration={},
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncCerca) -> None:
        agent = await async_client.agents.list()
        assert_matches_type(AsyncAgentsCursorPage[AgentSummary], agent, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncCerca) -> None:
        agent = await async_client.agents.list(
            active="true",
            cursor="cursor_abc123",
            fleet_id="fleet_abc123",
            limit="20",
        )
        assert_matches_type(AsyncAgentsCursorPage[AgentSummary], agent, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncCerca) -> None:
        response = await async_client.agents.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AsyncAgentsCursorPage[AgentSummary], agent, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncCerca) -> None:
        async with async_client.agents.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AsyncAgentsCursorPage[AgentSummary], agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_delete(self, async_client: AsyncCerca) -> None:
        agent = await async_client.agents.delete(
            "agent_abc123",
        )
        assert_matches_type(AgentDeleteResponse, agent, path=["response"])

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncCerca) -> None:
        response = await async_client.agents.with_raw_response.delete(
            "agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentDeleteResponse, agent, path=["response"])

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncCerca) -> None:
        async with async_client.agents.with_streaming_response.delete(
            "agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentDeleteResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.with_raw_response.delete(
                "",
            )

    @parametrize
    async def test_method_list_tools(self, async_client: AsyncCerca) -> None:
        agent = await async_client.agents.list_tools(
            "agent_abc123",
        )
        assert_matches_type(AgentListToolsResponse, agent, path=["response"])

    @parametrize
    async def test_raw_response_list_tools(self, async_client: AsyncCerca) -> None:
        response = await async_client.agents.with_raw_response.list_tools(
            "agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentListToolsResponse, agent, path=["response"])

    @parametrize
    async def test_streaming_response_list_tools(self, async_client: AsyncCerca) -> None:
        async with async_client.agents.with_streaming_response.list_tools(
            "agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentListToolsResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_tools(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.with_raw_response.list_tools(
                "",
            )

    @parametrize
    async def test_method_retrieve_config(self, async_client: AsyncCerca) -> None:
        agent = await async_client.agents.retrieve_config(
            "agent_abc123",
        )
        assert_matches_type(EffectiveConfiguration, agent, path=["response"])

    @parametrize
    async def test_raw_response_retrieve_config(self, async_client: AsyncCerca) -> None:
        response = await async_client.agents.with_raw_response.retrieve_config(
            "agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(EffectiveConfiguration, agent, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve_config(self, async_client: AsyncCerca) -> None:
        async with async_client.agents.with_streaming_response.retrieve_config(
            "agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(EffectiveConfiguration, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve_config(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.with_raw_response.retrieve_config(
                "",
            )

    @parametrize
    async def test_method_update_metadata(self, async_client: AsyncCerca) -> None:
        agent = await async_client.agents.update_metadata(
            agent_id="agent_abc123",
            metadata={"project": "alpha"},
        )
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    async def test_raw_response_update_metadata(self, async_client: AsyncCerca) -> None:
        response = await async_client.agents.with_raw_response.update_metadata(
            agent_id="agent_abc123",
            metadata={"project": "alpha"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(Agent, agent, path=["response"])

    @parametrize
    async def test_streaming_response_update_metadata(self, async_client: AsyncCerca) -> None:
        async with async_client.agents.with_streaming_response.update_metadata(
            agent_id="agent_abc123",
            metadata={"project": "alpha"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(Agent, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update_metadata(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.with_raw_response.update_metadata(
                agent_id="",
                metadata={"project": "alpha"},
            )
