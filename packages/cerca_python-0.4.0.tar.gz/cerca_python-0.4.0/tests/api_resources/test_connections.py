# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from cerca import Cerca, AsyncCerca
from cerca.types import (
    Connection,
    AttachedConnection,
    ConnectionDeleteResponse,
    ConnectionDetachResponse,
    ConnectionListForAgentResponse,
)
from tests.utils import assert_matches_type
from cerca.pagination import SyncConnectionsCursorPage, AsyncConnectionsCursorPage

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestConnections:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Cerca) -> None:
        connection = client.connections.create(
            api_key="sk_live_...",
            owner={"type": "organization"},
            provider="custom",
        )
        assert_matches_type(Connection, connection, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: Cerca) -> None:
        connection = client.connections.create(
            api_key="sk_live_...",
            owner={"type": "organization"},
            provider="custom",
            account_label="primary",
        )
        assert_matches_type(Connection, connection, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Cerca) -> None:
        response = client.connections.with_raw_response.create(
            api_key="sk_live_...",
            owner={"type": "organization"},
            provider="custom",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        connection = response.parse()
        assert_matches_type(Connection, connection, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Cerca) -> None:
        with client.connections.with_streaming_response.create(
            api_key="sk_live_...",
            owner={"type": "organization"},
            provider="custom",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            connection = response.parse()
            assert_matches_type(Connection, connection, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_list(self, client: Cerca) -> None:
        connection = client.connections.list(
            owner_type="fleet",
        )
        assert_matches_type(SyncConnectionsCursorPage[Connection], connection, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Cerca) -> None:
        connection = client.connections.list(
            owner_type="fleet",
            cursor="cursor_abc123",
            fleet_id="fleet_abc123",
            limit="20",
        )
        assert_matches_type(SyncConnectionsCursorPage[Connection], connection, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Cerca) -> None:
        response = client.connections.with_raw_response.list(
            owner_type="fleet",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        connection = response.parse()
        assert_matches_type(SyncConnectionsCursorPage[Connection], connection, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Cerca) -> None:
        with client.connections.with_streaming_response.list(
            owner_type="fleet",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            connection = response.parse()
            assert_matches_type(SyncConnectionsCursorPage[Connection], connection, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_delete(self, client: Cerca) -> None:
        connection = client.connections.delete(
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
            owner_type="fleet",
        )
        assert_matches_type(ConnectionDeleteResponse, connection, path=["response"])

    @parametrize
    def test_method_delete_with_all_params(self, client: Cerca) -> None:
        connection = client.connections.delete(
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
            owner_type="fleet",
            fleet_id="fleet_abc123",
        )
        assert_matches_type(ConnectionDeleteResponse, connection, path=["response"])

    @parametrize
    def test_raw_response_delete(self, client: Cerca) -> None:
        response = client.connections.with_raw_response.delete(
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
            owner_type="fleet",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        connection = response.parse()
        assert_matches_type(ConnectionDeleteResponse, connection, path=["response"])

    @parametrize
    def test_streaming_response_delete(self, client: Cerca) -> None:
        with client.connections.with_streaming_response.delete(
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
            owner_type="fleet",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            connection = response.parse()
            assert_matches_type(ConnectionDeleteResponse, connection, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `connection_id` but received ''"):
            client.connections.with_raw_response.delete(
                connection_id="",
                owner_type="fleet",
            )

    @parametrize
    def test_method_attach(self, client: Cerca) -> None:
        connection = client.connections.attach(
            agent_id="agent_abc123",
            connection_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(AttachedConnection, connection, path=["response"])

    @parametrize
    def test_method_attach_with_all_params(self, client: Cerca) -> None:
        connection = client.connections.attach(
            agent_id="agent_abc123",
            connection_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            metadata={"foo": "string"},
        )
        assert_matches_type(AttachedConnection, connection, path=["response"])

    @parametrize
    def test_raw_response_attach(self, client: Cerca) -> None:
        response = client.connections.with_raw_response.attach(
            agent_id="agent_abc123",
            connection_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        connection = response.parse()
        assert_matches_type(AttachedConnection, connection, path=["response"])

    @parametrize
    def test_streaming_response_attach(self, client: Cerca) -> None:
        with client.connections.with_streaming_response.attach(
            agent_id="agent_abc123",
            connection_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            connection = response.parse()
            assert_matches_type(AttachedConnection, connection, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_attach(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.connections.with_raw_response.attach(
                agent_id="",
                connection_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            )

    @parametrize
    def test_method_detach(self, client: Cerca) -> None:
        connection = client.connections.detach(
            agent_id="agent_abc123",
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
        )
        assert_matches_type(ConnectionDetachResponse, connection, path=["response"])

    @parametrize
    def test_raw_response_detach(self, client: Cerca) -> None:
        response = client.connections.with_raw_response.detach(
            agent_id="agent_abc123",
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        connection = response.parse()
        assert_matches_type(ConnectionDetachResponse, connection, path=["response"])

    @parametrize
    def test_streaming_response_detach(self, client: Cerca) -> None:
        with client.connections.with_streaming_response.detach(
            agent_id="agent_abc123",
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            connection = response.parse()
            assert_matches_type(ConnectionDetachResponse, connection, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_detach(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.connections.with_raw_response.detach(
                agent_id="",
                connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `connection_id` but received ''"):
            client.connections.with_raw_response.detach(
                agent_id="agent_abc123",
                connection_id="",
            )

    @parametrize
    def test_method_list_for_agent(self, client: Cerca) -> None:
        connection = client.connections.list_for_agent(
            "agent_abc123",
        )
        assert_matches_type(ConnectionListForAgentResponse, connection, path=["response"])

    @parametrize
    def test_raw_response_list_for_agent(self, client: Cerca) -> None:
        response = client.connections.with_raw_response.list_for_agent(
            "agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        connection = response.parse()
        assert_matches_type(ConnectionListForAgentResponse, connection, path=["response"])

    @parametrize
    def test_streaming_response_list_for_agent(self, client: Cerca) -> None:
        with client.connections.with_streaming_response.list_for_agent(
            "agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            connection = response.parse()
            assert_matches_type(ConnectionListForAgentResponse, connection, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_for_agent(self, client: Cerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.connections.with_raw_response.list_for_agent(
                "",
            )


class TestAsyncConnections:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncCerca) -> None:
        connection = await async_client.connections.create(
            api_key="sk_live_...",
            owner={"type": "organization"},
            provider="custom",
        )
        assert_matches_type(Connection, connection, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncCerca) -> None:
        connection = await async_client.connections.create(
            api_key="sk_live_...",
            owner={"type": "organization"},
            provider="custom",
            account_label="primary",
        )
        assert_matches_type(Connection, connection, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncCerca) -> None:
        response = await async_client.connections.with_raw_response.create(
            api_key="sk_live_...",
            owner={"type": "organization"},
            provider="custom",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        connection = await response.parse()
        assert_matches_type(Connection, connection, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncCerca) -> None:
        async with async_client.connections.with_streaming_response.create(
            api_key="sk_live_...",
            owner={"type": "organization"},
            provider="custom",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            connection = await response.parse()
            assert_matches_type(Connection, connection, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_list(self, async_client: AsyncCerca) -> None:
        connection = await async_client.connections.list(
            owner_type="fleet",
        )
        assert_matches_type(AsyncConnectionsCursorPage[Connection], connection, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncCerca) -> None:
        connection = await async_client.connections.list(
            owner_type="fleet",
            cursor="cursor_abc123",
            fleet_id="fleet_abc123",
            limit="20",
        )
        assert_matches_type(AsyncConnectionsCursorPage[Connection], connection, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncCerca) -> None:
        response = await async_client.connections.with_raw_response.list(
            owner_type="fleet",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        connection = await response.parse()
        assert_matches_type(AsyncConnectionsCursorPage[Connection], connection, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncCerca) -> None:
        async with async_client.connections.with_streaming_response.list(
            owner_type="fleet",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            connection = await response.parse()
            assert_matches_type(AsyncConnectionsCursorPage[Connection], connection, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_delete(self, async_client: AsyncCerca) -> None:
        connection = await async_client.connections.delete(
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
            owner_type="fleet",
        )
        assert_matches_type(ConnectionDeleteResponse, connection, path=["response"])

    @parametrize
    async def test_method_delete_with_all_params(self, async_client: AsyncCerca) -> None:
        connection = await async_client.connections.delete(
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
            owner_type="fleet",
            fleet_id="fleet_abc123",
        )
        assert_matches_type(ConnectionDeleteResponse, connection, path=["response"])

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncCerca) -> None:
        response = await async_client.connections.with_raw_response.delete(
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
            owner_type="fleet",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        connection = await response.parse()
        assert_matches_type(ConnectionDeleteResponse, connection, path=["response"])

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncCerca) -> None:
        async with async_client.connections.with_streaming_response.delete(
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
            owner_type="fleet",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            connection = await response.parse()
            assert_matches_type(ConnectionDeleteResponse, connection, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `connection_id` but received ''"):
            await async_client.connections.with_raw_response.delete(
                connection_id="",
                owner_type="fleet",
            )

    @parametrize
    async def test_method_attach(self, async_client: AsyncCerca) -> None:
        connection = await async_client.connections.attach(
            agent_id="agent_abc123",
            connection_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(AttachedConnection, connection, path=["response"])

    @parametrize
    async def test_method_attach_with_all_params(self, async_client: AsyncCerca) -> None:
        connection = await async_client.connections.attach(
            agent_id="agent_abc123",
            connection_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            metadata={"foo": "string"},
        )
        assert_matches_type(AttachedConnection, connection, path=["response"])

    @parametrize
    async def test_raw_response_attach(self, async_client: AsyncCerca) -> None:
        response = await async_client.connections.with_raw_response.attach(
            agent_id="agent_abc123",
            connection_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        connection = await response.parse()
        assert_matches_type(AttachedConnection, connection, path=["response"])

    @parametrize
    async def test_streaming_response_attach(self, async_client: AsyncCerca) -> None:
        async with async_client.connections.with_streaming_response.attach(
            agent_id="agent_abc123",
            connection_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            connection = await response.parse()
            assert_matches_type(AttachedConnection, connection, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_attach(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.connections.with_raw_response.attach(
                agent_id="",
                connection_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            )

    @parametrize
    async def test_method_detach(self, async_client: AsyncCerca) -> None:
        connection = await async_client.connections.detach(
            agent_id="agent_abc123",
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
        )
        assert_matches_type(ConnectionDetachResponse, connection, path=["response"])

    @parametrize
    async def test_raw_response_detach(self, async_client: AsyncCerca) -> None:
        response = await async_client.connections.with_raw_response.detach(
            agent_id="agent_abc123",
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        connection = await response.parse()
        assert_matches_type(ConnectionDetachResponse, connection, path=["response"])

    @parametrize
    async def test_streaming_response_detach(self, async_client: AsyncCerca) -> None:
        async with async_client.connections.with_streaming_response.detach(
            agent_id="agent_abc123",
            connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            connection = await response.parse()
            assert_matches_type(ConnectionDetachResponse, connection, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_detach(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.connections.with_raw_response.detach(
                agent_id="",
                connection_id="9f063c59-2775-4614-8a68-22e5f90f92f3",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `connection_id` but received ''"):
            await async_client.connections.with_raw_response.detach(
                agent_id="agent_abc123",
                connection_id="",
            )

    @parametrize
    async def test_method_list_for_agent(self, async_client: AsyncCerca) -> None:
        connection = await async_client.connections.list_for_agent(
            "agent_abc123",
        )
        assert_matches_type(ConnectionListForAgentResponse, connection, path=["response"])

    @parametrize
    async def test_raw_response_list_for_agent(self, async_client: AsyncCerca) -> None:
        response = await async_client.connections.with_raw_response.list_for_agent(
            "agent_abc123",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        connection = await response.parse()
        assert_matches_type(ConnectionListForAgentResponse, connection, path=["response"])

    @parametrize
    async def test_streaming_response_list_for_agent(self, async_client: AsyncCerca) -> None:
        async with async_client.connections.with_streaming_response.list_for_agent(
            "agent_abc123",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            connection = await response.parse()
            assert_matches_type(ConnectionListForAgentResponse, connection, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_for_agent(self, async_client: AsyncCerca) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.connections.with_raw_response.list_for_agent(
                "",
            )
