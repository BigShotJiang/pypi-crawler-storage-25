# Changelog

## 0.4.0 (2026-05-13)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/matrices/cerca-python/compare/v0.3.0...v0.4.0)

### Features

* **internal/types:** support eagerly validating pydantic iterators ([d504728](https://github.com/matrices/cerca-python/commit/d504728ce1d56bc20cecdfd1bdd45b6da06b6822))


### Bug Fixes

* **client:** add missing f-string prefix in file type error message ([1780180](https://github.com/matrices/cerca-python/commit/17801801b6884dc38d8fd2a5f3146283f345b15c))

## 0.3.0 (2026-05-07)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/matrices/cerca-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([4dd4810](https://github.com/matrices/cerca-python/commit/4dd48109c48c7698a0c58e1d72495b5625667d3f))

## 0.2.0 (2026-05-06)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/matrices/cerca-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** api update ([9eda8d3](https://github.com/matrices/cerca-python/commit/9eda8d390aff6867bc9924c795c1b7b4f9b281fc))

## 0.1.0 (2026-05-01)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/matrices/cerca-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([99fa28a](https://github.com/matrices/cerca-python/commit/99fa28a689db291c9a0394932c2c3a7179ec63dd))
* **api:** api update ([b923a3f](https://github.com/matrices/cerca-python/commit/b923a3fc328b3cad9f590deb3835585892fda1b1))
* **api:** api update ([45ca772](https://github.com/matrices/cerca-python/commit/45ca772504aae33a5723e9c7ecce538a1fa4b7fc))
* **api:** api update ([b431913](https://github.com/matrices/cerca-python/commit/b431913d2a07264d8b79292d831ce4a129d830ed))
* **api:** api update ([b2b2e37](https://github.com/matrices/cerca-python/commit/b2b2e3764d9e3e271f8cedac385e6680b23492bc))
* **api:** api update ([c6da2f5](https://github.com/matrices/cerca-python/commit/c6da2f5ea0549b5e8ae21feae44e15b7d74a4b6f))
* **api:** manual updates ([e90db8c](https://github.com/matrices/cerca-python/commit/e90db8c41eba81597a132889551acab79eca48aa))
* **api:** manual updates ([e281b3a](https://github.com/matrices/cerca-python/commit/e281b3a3abf90014fbb1d1ed4365feac4e9defe7))
* **api:** manual updates ([27b68e0](https://github.com/matrices/cerca-python/commit/27b68e02bfe64fbecf1c51a1f12674ec0659eabf))
* support setting headers via env ([e360997](https://github.com/matrices/cerca-python/commit/e360997bc1cf83d9ce1858cb404e64d171f552b3))


### Bug Fixes

* use correct field name format for multipart file arrays ([dd2c621](https://github.com/matrices/cerca-python/commit/dd2c6219cc128ea4e61bf27fa996f117ba45292c))


### Chores

* **internal:** more robust bootstrap script ([a9ed749](https://github.com/matrices/cerca-python/commit/a9ed7498becc285fccd020c8f3a3c8370d62e372))
* **internal:** reformat pyproject.toml ([7953e5d](https://github.com/matrices/cerca-python/commit/7953e5d75b3256ba51107d54877d26a2145e5fb4))
* **tests:** bump steady to v0.22.1 ([2df7a38](https://github.com/matrices/cerca-python/commit/2df7a3853d9b84e8e64a7992a3c716dfc74cf5e5))
* update SDK settings ([edd9e45](https://github.com/matrices/cerca-python/commit/edd9e450965ae556c5897987ec69976a09e9e56f))
* update SDK settings ([473d974](https://github.com/matrices/cerca-python/commit/473d9744cc98e13528e9c80e990b245b43e1159c))
* update SDK settings ([9159828](https://github.com/matrices/cerca-python/commit/9159828ad0bed59f114cccdc003b46a6ad7dbe99))
