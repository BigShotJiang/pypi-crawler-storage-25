"""Experimental fused compressed decode-attention research utilities.

v0.10.0 extends the Triton fused compressed decode-attention prototype with
CUDA Graph replay diagnostics on top of page-size/BLOCK_M sweep support for the affine safe-layout path.  The supported fast path remains intentionally narrow:
query_len=1, batch_size=1, key_bits=8, affine per-page/per-channel K, and
value_bits in {4, 6, 8}.  Unsupported configurations fall back to the
quality-safe PyTorch compressed-page reference path and label that mode
explicitly.  v0.10.0 reports normal fused timing, optional CUDA Graph replay timing, kernel block size, optional page-size sweep results, and speed/quality gaps
against dense attention, SDPA, and the Python compressed-page reference path.

This module does not claim production inference acceleration.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, List

import torch

try:  # optional dependency; Windows/CPU users should still import the package.
    import triton
    import triton.language as tl
except Exception:  # pragma: no cover - depends on runtime environment
    triton = None
    tl = None

from .attention import attention_similarity, dense_attention, sdpa_attention
from .attention_perf import _resolve_device, _resolve_dtype, _runtime_warnings, _sync, triton_status
from .layout import (
    CompressedKVPageTable,
    LayoutBenchConfig,
    compressed_page_attention_reference,
    resolve_layout_preset,
)


def _time_call(fn, *, device: str, warmup: int, repeats: int) -> Tuple[torch.Tensor, float]:
    out = None
    for _ in range(max(0, int(warmup))):
        out = fn()
    _sync(device)
    t0 = time.perf_counter()
    for _ in range(max(1, int(repeats))):
        out = fn()
    _sync(device)
    elapsed = (time.perf_counter() - t0) / max(1, int(repeats))
    assert out is not None
    return out, float(elapsed)


def _time_cuda_graph_call(fn, *, device: str, warmup: int, graph_replays: int) -> Tuple[Optional[torch.Tensor], Optional[float], Dict[str, Any]]:
    """Try to capture and replay a fixed-shape CUDA decode call.

    CUDA Graph replay is a benchmark mode, not a different algorithm. It can
    fail if the runtime, allocator, or called operators are not graph-safe. In
    that case the caller should keep the normal timing and report the reason.
    """
    if device != "cuda" or not torch.cuda.is_available():
        return None, None, {
            "attempted": False,
            "captured": False,
            "reason": "CUDA Graph replay requires a CUDA device",
        }
    if not hasattr(torch.cuda, "CUDAGraph"):
        return None, None, {
            "attempted": False,
            "captured": False,
            "reason": "torch.cuda.CUDAGraph is unavailable in this PyTorch build",
        }

    replays = max(1, int(graph_replays))
    try:
        out = None
        for _ in range(max(1, int(warmup))):
            out = fn()
        torch.cuda.synchronize()

        graph = torch.cuda.CUDAGraph()
        # Capture allocations into the graph memory pool. The captured output
        # tensor is reused on replay; the benchmark is valid for fixed-shape
        # decode microbenchmarks.
        with torch.cuda.graph(graph):
            out = fn()
        torch.cuda.synchronize()

        t0 = time.perf_counter()
        for _ in range(replays):
            graph.replay()
        torch.cuda.synchronize()
        seconds = (time.perf_counter() - t0) / replays
        assert out is not None
        return out, float(seconds), {
            "attempted": True,
            "captured": True,
            "replays": replays,
            "reason": "CUDA Graph capture and replay succeeded",
        }
    except Exception as exc:  # pragma: no cover - CUDA/runtime dependent
        try:
            torch.cuda.synchronize()
        except Exception:
            pass
        return None, None, {
            "attempted": True,
            "captured": False,
            "replays": replays,
            "reason": f"CUDA Graph capture/replay failed: {exc!r}",
        }


@dataclass
class FusedDecodeBenchConfig:
    """Configuration for experimental compressed decode-attention benchmarks."""

    batch_size: int = 1
    heads: int = 8
    query_len: int = 1
    seq_len: int = 2048
    head_dim: int = 64
    page_size: int = 128
    key_bits: int = 8
    value_bits: int = 6
    preset: Optional[str] = "safe-layout"
    quantization_mode: str = "affine"
    device: str = "auto"
    dtype: str = "auto"
    warmup: int = 1
    repeats: int = 3
    iters: Optional[int] = None
    seed: int = 123
    prefer_triton: bool = True
    kernel_block_m: int = 64
    tune_kernel: bool = False
    tune_block_m_values: Tuple[int, ...] = (8, 16, 32, 64, 128)
    tune_page_size: bool = False
    tune_page_size_values: Tuple[int, ...] = (64, 128, 256)
    cuda_graph: bool = False
    graph_replays: int = 100
    competitiveness_target: str = "sdpa"

    def __post_init__(self) -> None:
        if self.iters is not None:
            self.repeats = int(self.iters)
        if self.preset:
            cfg = resolve_layout_preset(self.preset)
            self.key_bits = int(cfg.get("key_bits", self.key_bits))
            self.value_bits = int(cfg.get("value_bits", self.value_bits))
            self.quantization_mode = str(cfg.get("quantization_mode", self.quantization_mode))
        if self.query_len != 1:
            # The v0.9 path is explicitly decode-only.  Keep this strict so
            # users do not confuse it with prefill attention.
            raise ValueError("FusedDecodeBenchConfig is decode-only: query_len must be 1")


def _triton_runtime_status() -> Dict[str, Any]:
    status = triton_status()
    # Keep a normalized field stable for reports.  v0.9.0 accidentally looked
    # for ``triton_available`` while triton_status() exposes ``available``.
    return {
        "available": bool(status.get("available", False)),
        "package_importable": bool(status.get("package_importable", False)),
        "cuda_available": bool(status.get("cuda_available", False)),
        "detail": status,
    }




if triton is not None and tl is not None:  # pragma: no cover - requires CUDA+Triton
    @triton.jit
    def _ttq_affine_decode_kernel(
        q_ptr,
        key_packed_ptr,
        value_packed_ptr,
        key_min_ptr,
        key_scale_ptr,
        value_min_ptr,
        value_scale_ptr,
        out_ptr,
        H: tl.constexpr,
        S: tl.constexpr,
        D: tl.constexpr,
        PAGE: tl.constexpr,
        PAGES: tl.constexpr,
        VALUE_BITS: tl.constexpr,
        BLOCK_M: tl.constexpr,
        BLOCK_D: tl.constexpr,
        SCALE: tl.constexpr,
    ):
        # One program computes one head for batch=1/query_len=1.  This is a
        # deliberately narrow v0.9.1 prototype, not a general serving kernel.
        h = tl.program_id(0)
        offs_d = tl.arange(0, BLOCK_D)
        mask_d = offs_d < D
        q = tl.load(q_ptr + h * D + offs_d, mask=mask_d, other=0.0).to(tl.float32)

        m = tl.full((), -3.4028234663852886e38, tl.float32)
        l = tl.full((), 0.0, tl.float32)
        acc = tl.zeros((BLOCK_D,), tl.float32)
        offs_m = tl.arange(0, BLOCK_M)

        # Packed sizes per page for flattened shape (1, H, PAGE, D).
        values_per_page = H * PAGE * D
        key_bytes_per_page = values_per_page  # key_bits=8 only in v0.9.1 Triton path.
        value_bytes_per_page = (values_per_page * VALUE_BITS + 7) // 8

        for p in range(0, PAGES):
            k_min = tl.load(key_min_ptr + (p * H + h) * D + offs_d, mask=mask_d, other=0.0).to(tl.float32)
            k_scale = tl.load(key_scale_ptr + (p * H + h) * D + offs_d, mask=mask_d, other=1.0).to(tl.float32)
            v_min = tl.load(value_min_ptr + (p * H + h) * D + offs_d, mask=mask_d, other=0.0).to(tl.float32)
            v_scale = tl.load(value_scale_ptr + (p * H + h) * D + offs_d, mask=mask_d, other=1.0).to(tl.float32)

            for start in range(0, PAGE, BLOCK_M):
                t = start + offs_m
                token_mask = t < PAGE
                flat = h * PAGE * D + t[:, None] * D + offs_d[None, :]
                mask = token_mask[:, None] & mask_d[None, :]

                # Key path: safe-layout uses key_bits=8, so packed bytes are indices.
                k_idx = tl.load(
                    key_packed_ptr + p * key_bytes_per_page + flat,
                    mask=mask,
                    other=0,
                ).to(tl.float32)
                k_val = k_idx * k_scale[None, :] + k_min[None, :]

                scores = tl.sum(k_val * q[None, :], axis=1) * SCALE
                scores = tl.where(token_mask, scores, -3.4028234663852886e38)
                block_m = tl.max(scores, axis=0)
                m_new = tl.maximum(m, block_m)
                alpha = tl.exp(m - m_new)
                probs = tl.exp(scores - m_new)

                if VALUE_BITS == 8:
                    v_idx = tl.load(
                        value_packed_ptr + p * value_bytes_per_page + flat,
                        mask=mask,
                        other=0,
                    ).to(tl.float32)
                else:
                    bit_pos = flat * VALUE_BITS
                    byte_pos = bit_pos // 8
                    shift = bit_pos - byte_pos * 8
                    b0 = tl.load(
                        value_packed_ptr + p * value_bytes_per_page + byte_pos,
                        mask=mask,
                        other=0,
                    ).to(tl.uint32)
                    b1 = tl.load(
                        value_packed_ptr + p * value_bytes_per_page + byte_pos + 1,
                        mask=mask & ((byte_pos + 1) < value_bytes_per_page),
                        other=0,
                    ).to(tl.uint32)
                    raw = b0 | (b1 << 8)
                    v_idx_i = (raw >> shift) & ((1 << VALUE_BITS) - 1)
                    v_idx = v_idx_i.to(tl.float32)

                v_val = v_idx * v_scale[None, :] + v_min[None, :]
                acc = acc * alpha + tl.sum(probs[:, None] * v_val, axis=0)
                l = l * alpha + tl.sum(probs, axis=0)
                m = m_new

        out = acc / l
        tl.store(out_ptr + h * D + offs_d, out, mask=mask_d)
else:  # pragma: no cover
    _ttq_affine_decode_kernel = None


def _is_supported_triton_config(query: torch.Tensor, page_table: CompressedKVPageTable) -> Tuple[bool, str]:
    if triton is None or tl is None or _ttq_affine_decode_kernel is None:
        return False, "triton package is not importable"
    if not query.is_cuda:
        return False, "query is not on CUDA"
    if query.ndim != 4 or query.shape[0] != 1 or query.shape[2] != 1:
        return False, "v0.10.0 Triton prototype supports batch=1 and query_len=1 only"
    if page_table.quantization_mode != "affine":
        return False, "v0.10.0 Triton prototype supports affine layout only"
    if page_table.page_count <= 0:
        return False, "page table is empty"
    if page_table.dense_shape[0] != 1:
        return False, "v0.10.0 Triton prototype supports batch=1 page tables only"
    if page_table.head_dim not in (32, 64, 128):
        return False, "v0.10.0 Triton prototype supports head_dim in {32,64,128}"
    if any(p.key_bits != 8 for p in page_table.pages):
        return False, "v0.10.0 Triton prototype supports key_bits=8 only"
    if any(p.value_bits not in (4, 6, 8) for p in page_table.pages):
        return False, "v0.10.0 Triton prototype supports value_bits in {4,6,8}"
    if len({p.value_bits for p in page_table.pages}) != 1:
        return False, "all pages must use the same value_bits"
    if len({p.page_length for p in page_table.pages}) != 1:
        return False, "all pages must have the same page length"
    if page_table.pages[0].page_length != page_table.page_size:
        return False, "v0.10.0 Triton prototype requires full pages; pad or use divisible seq_len"
    return True, "supported"


def _concat_page_payloads(page_table: CompressedKVPageTable) -> Dict[str, torch.Tensor]:
    pages = page_table.pages
    key_packed = torch.cat([p.key_packed.reshape(-1) for p in pages]).contiguous()
    value_packed = torch.cat([p.value_packed.reshape(-1) for p in pages]).contiguous()
    key_min = torch.cat([p.key_min.squeeze(0).squeeze(1) for p in pages], dim=0).contiguous()
    key_scale = torch.cat([p.key_scale.squeeze(0).squeeze(1) for p in pages], dim=0).contiguous()
    value_min = torch.cat([p.value_min.squeeze(0).squeeze(1) for p in pages], dim=0).contiguous()
    value_scale = torch.cat([p.value_scale.squeeze(0).squeeze(1) for p in pages], dim=0).contiguous()
    return {
        "key_packed": key_packed,
        "value_packed": value_packed,
        "key_min": key_min,
        "key_scale": key_scale,
        "value_min": value_min,
        "value_scale": value_scale,
    }


def _triton_fused_affine_decode_attention(
    query: torch.Tensor,
    page_table: CompressedKVPageTable,
    *,
    kernel_block_m: int = 64,
) -> torch.Tensor:
    ok, reason = _is_supported_triton_config(query, page_table)
    if not ok:
        raise RuntimeError(reason)
    if int(kernel_block_m) not in (8, 16, 32, 64, 128):
        raise RuntimeError("v0.10.0 Triton prototype supports kernel_block_m in {8,16,32,64,128}")
    q_rot = page_table.rotate_query(query).contiguous()
    payloads = _concat_page_payloads(page_table)
    b, h, s, d = page_table.dense_shape
    page_size = int(page_table.page_size)
    pages = int(page_table.page_count)
    value_bits = int(page_table.pages[0].value_bits)
    out = torch.empty((1, h, 1, d), device=query.device, dtype=query.dtype)
    # v0.10.0 exposes BLOCK_M so users can tune page-loop granularity.
    block_d = 1 << ((d - 1).bit_length())
    block_m = int(kernel_block_m)
    _ttq_affine_decode_kernel[(h,)](
        q_rot,
        payloads["key_packed"],
        payloads["value_packed"],
        payloads["key_min"],
        payloads["key_scale"],
        payloads["value_min"],
        payloads["value_scale"],
        out,
        H=h,
        S=s,
        D=d,
        PAGE=page_size,
        PAGES=pages,
        VALUE_BITS=value_bits,
        BLOCK_M=block_m,
        BLOCK_D=block_d,
        SCALE=float(d ** -0.5),
        num_warps=4,
    )
    return out

def experimental_fused_compressed_decode_attention(
    query: torch.Tensor,
    page_table: CompressedKVPageTable,
    *,
    prefer_triton: bool = True,
    kernel_block_m: int = 64,
) -> Tuple[torch.Tensor, Dict[str, Any]]:
    """Run the v0.10.0 experimental compressed decode-attention path.

    The function consumes the compressed page table directly and avoids full
    dense K/V reconstruction.  When the narrow Triton prototype supports the
    supplied configuration, it runs that kernel.  Otherwise it falls back to the
    verified PyTorch compressed-page reference and reports the fallback clearly.
    """

    if query.ndim != 4:
        raise ValueError("query must be shaped (B, H, 1, D)")
    if query.shape[2] != 1:
        raise ValueError("experimental fused decode attention supports query_len=1 only")

    runtime = _triton_runtime_status()
    supported, support_reason = _is_supported_triton_config(query, page_table)
    can_attempt_triton = bool(prefer_triton) and runtime["available"] and runtime["cuda_available"] and supported

    triton_error: Optional[str] = None
    if can_attempt_triton:
        try:
            out = _triton_fused_affine_decode_attention(query, page_table, kernel_block_m=kernel_block_m)
            meta = {
                "mode": "triton-fused-affine-decode",
                "triton_attempted": True,
                "triton_runtime": runtime,
                "reason": "minimal v0.10.0 Triton fused affine decode kernel executed",
                "support_check": support_reason,
                "query_len": int(query.shape[2]),
                "kernel_block_m": int(kernel_block_m),
                "uses_compressed_pages_directly": True,
                "constructs_full_dense_kv": False,
                "boundary": "experimental Triton prototype; not a production serving kernel",
            }
            return out, meta
        except Exception as exc:  # pragma: no cover - depends on Triton runtime/GPU
            triton_error = repr(exc)

    reason = support_reason
    if not prefer_triton:
        reason = "prefer_triton=False; using PyTorch compressed-page fallback"
    elif not runtime["available"] or not runtime["cuda_available"]:
        reason = "triton runtime unavailable"
    elif triton_error:
        reason = f"triton kernel failed; using fallback: {triton_error}"

    out = compressed_page_attention_reference(query, page_table, rotate_query=True)
    meta = {
        "mode": "torch-compressed-page-fallback",
        "triton_attempted": bool(can_attempt_triton),
        "triton_runtime": runtime,
        "reason": reason,
        "support_check": support_reason,
        "triton_error": triton_error,
        "query_len": int(query.shape[2]),
        "kernel_block_m": int(kernel_block_m),
        "uses_compressed_pages_directly": True,
        "constructs_full_dense_kv": False,
        "boundary": "experimental research path; fallback is not a production fused CUDA/Triton kernel",
    }
    return out, meta

def _build_random_qkv(config: FusedDecodeBenchConfig, device: str, dtype: torch.dtype):
    torch.manual_seed(int(config.seed))
    q = torch.randn(config.batch_size, config.heads, 1, config.head_dim, device=device, dtype=dtype)
    k = torch.randn(config.batch_size, config.heads, config.seq_len, config.head_dim, device=device, dtype=dtype)
    v = torch.randn_like(k)
    return q, k, v


def _quality_warning(metrics: Dict[str, float]) -> str:
    rel = float(metrics.get("relative_error", 999.0))
    cos = float(metrics.get("cosine_similarity", 0.0))
    if cos >= 0.99 and rel <= 0.05:
        return "ok: fused prototype output is close to dense in this benchmark."
    if cos >= 0.95:
        return "caution: fused prototype is directionally close, but error is still material."
    return "weak: fused prototype quality is not safe for kernel work with this layout."




def _safe_ratio(numerator: float, denominator: float) -> Optional[float]:
    if denominator is None or denominator <= 0:
        return None
    return float(numerator) / float(denominator)


def _candidate_block_values(config: FusedDecodeBenchConfig) -> List[int]:
    if config.tune_kernel:
        vals = [int(v) for v in config.tune_block_m_values]
    else:
        vals = [int(config.kernel_block_m)]
    out: List[int] = []
    for v in vals:
        if v in (8, 16, 32, 64, 128) and v not in out:
            out.append(v)
    if not out:
        out = [64]
    return out

def _run_fused_decode_benchmark_core(config: FusedDecodeBenchConfig) -> Dict[str, Any]:
    """Benchmark dense, SDPA, compressed-page reference, and v0.9 fused path for one page size."""

    requested_device = config.device
    requested_dtype = config.dtype
    device = _resolve_device(requested_device)
    dtype = _resolve_dtype(requested_dtype, device)
    warnings = _runtime_warnings(requested_device, device, requested_dtype, dtype)

    q, k, v = _build_random_qkv(config, device, dtype)

    t0 = time.perf_counter()
    table = CompressedKVPageTable.from_dense(
        k,
        v,
        key_bits=config.key_bits,
        value_bits=config.value_bits,
        page_size=config.page_size,
        seed=config.seed,
        dtype_bytes=torch.empty((), dtype=dtype).element_size(),
        quantization_mode=config.quantization_mode,
    )
    layout_build_seconds = time.perf_counter() - t0

    dense_out, dense_seconds = _time_call(
        lambda: dense_attention(q, k, v),
        device=device,
        warmup=config.warmup,
        repeats=config.repeats,
    )

    try:
        sdpa_out, sdpa_seconds = _time_call(
            lambda: sdpa_attention(q, k, v),
            device=device,
            warmup=config.warmup,
            repeats=config.repeats,
        )
        sdpa_report: Optional[Dict[str, Any]] = {
            "seconds": sdpa_seconds,
            "similarity_to_dense": attention_similarity(dense_out, sdpa_out),
        }
    except Exception as exc:  # pragma: no cover depends on torch build/backend
        sdpa_report = {"error": repr(exc)}

    reference_out, reference_seconds = _time_call(
        lambda: compressed_page_attention_reference(q, table, rotate_query=True),
        device=device,
        warmup=config.warmup,
        repeats=config.repeats,
    )

    fused_meta_holder: Dict[str, Any] = {}
    tuning_rows: List[Dict[str, Any]] = []
    selected_block_m = int(config.kernel_block_m)
    fused_out: Optional[torch.Tensor] = None
    fused_seconds: float = 0.0

    for block_m in _candidate_block_values(config):
        local_meta: Dict[str, Any] = {}

        def _run_fused(block_m=block_m):
            out, meta = experimental_fused_compressed_decode_attention(
                q,
                table,
                prefer_triton=config.prefer_triton,
                kernel_block_m=block_m,
            )
            local_meta.clear()
            local_meta.update(meta)
            return out

        out_i, sec_i = _time_call(
            _run_fused,
            device=device,
            warmup=config.warmup,
            repeats=config.repeats,
        )
        q_i = attention_similarity(dense_out, out_i)
        row = {
            "kernel_block_m": int(block_m),
            "seconds": float(sec_i),
            "mode": local_meta.get("mode"),
            "relative_error": q_i.get("relative_error"),
            "cosine_similarity": q_i.get("cosine_similarity"),
        }
        tuning_rows.append(row)

        if fused_out is None or sec_i < fused_seconds:
            fused_out = out_i
            fused_seconds = float(sec_i)
            selected_block_m = int(block_m)
            fused_meta_holder.clear()
            fused_meta_holder.update(local_meta)

    assert fused_out is not None
    fused_meta_holder["selected_kernel_block_m"] = int(selected_block_m)
    fused_meta_holder["tune_kernel"] = bool(config.tune_kernel)

    graph_report: Dict[str, Any] = {
        "enabled": bool(config.cuda_graph),
        "attempted": False,
        "captured": False,
        "seconds": None,
        "speedup_vs_normal_fused": None,
        "quality_vs_dense": None,
        "quality_vs_normal_fused": None,
        "reason": "CUDA Graph replay disabled",
    }
    if bool(config.cuda_graph):
        def _run_selected_fused():
            out, _meta = experimental_fused_compressed_decode_attention(
                q,
                table,
                prefer_triton=config.prefer_triton,
                kernel_block_m=selected_block_m,
            )
            return out

        graph_out, graph_seconds, graph_meta = _time_cuda_graph_call(
            _run_selected_fused,
            device=device,
            warmup=config.warmup,
            graph_replays=config.graph_replays,
        )
        graph_report.update(graph_meta)
        if graph_seconds is not None and graph_out is not None:
            graph_report["seconds"] = float(graph_seconds)
            graph_report["speedup_vs_normal_fused"] = _safe_ratio(fused_seconds, graph_seconds)
            graph_report["quality_vs_dense"] = attention_similarity(dense_out, graph_out)
            graph_report["quality_vs_normal_fused"] = attention_similarity(fused_out, graph_out)

    fused_meta_holder["cuda_graph_enabled"] = bool(config.cuda_graph)
    fused_meta_holder["cuda_graph_captured"] = bool(graph_report.get("captured", False))

    mem = table.memory_report().to_dict()
    fused_quality = attention_similarity(dense_out, fused_out)
    reference_quality = attention_similarity(dense_out, reference_out)
    warning = _quality_warning(fused_quality)
    if warning.startswith("weak"):
        warnings = list(warnings) + [warning]

    return {
        "version": "0.10.0",
        "benchmark": "experimental-fused-compressed-decode-attention",
        "config": {
            **asdict(config),
            "device": device,
            "dtype": str(dtype).replace("torch.", ""),
            "requested_device": requested_device,
            "requested_dtype": requested_dtype,
            "iters": int(config.repeats),
        },
        "warnings": warnings,
        "execution": fused_meta_holder,
        "layout": table.to_dict(include_pages=False),
        "memory": mem,
        "timing": {
            "layout_build_seconds": float(layout_build_seconds),
            "dense_attention_seconds": float(dense_seconds),
            "sdpa": sdpa_report,
            "compressed_page_reference_seconds": float(reference_seconds),
            "experimental_fused_seconds": float(fused_seconds),
            "selected_kernel_block_m": int(selected_block_m),
            "kernel_tuning": tuning_rows,
            "speedup_vs_compressed_page_reference": _safe_ratio(reference_seconds, fused_seconds),
            "speedup_vs_dense_manual": _safe_ratio(dense_seconds, fused_seconds),
            "speedup_vs_sdpa": (
                _safe_ratio(sdpa_report["seconds"], fused_seconds)
                if isinstance(sdpa_report, dict) and "seconds" in sdpa_report
                else None
            ),
            "cuda_graph": graph_report,
            "graph_fused_seconds": graph_report.get("seconds"),
            "graph_speedup_vs_normal_fused": graph_report.get("speedup_vs_normal_fused"),
            "note": (
                "Timing is diagnostic. v0.10.0 adds CUDA Graph replay diagnostics around the minimal fused-attention prototype; "
                "production acceleration is not claimed."
            ),
        },
        "quality": {
            "fused_vs_dense": fused_quality,
            "reference_vs_dense": reference_quality,
            "fused_vs_reference": attention_similarity(reference_out, fused_out),
            "quality_warning": warning,
        },
        "interpretation": (
            "v0.10.0 benchmarks an experimental compressed decode-attention path over the compressed page layout with optional BLOCK_M/page-size tuning and CUDA Graph replay diagnostics. "
            "It reads compressed pages without constructing full dense K/V. When a production Triton kernel is not "
            "available, the benchmark uses the verified PyTorch compressed-page fallback and reports that mode explicitly."
        ),
    }



def _candidate_page_sizes(config: FusedDecodeBenchConfig) -> List[int]:
    if config.tune_page_size:
        vals = [int(v) for v in config.tune_page_size_values]
    else:
        vals = [int(config.page_size)]
    out: List[int] = []
    for v in vals:
        if v > 0 and config.seq_len % v == 0 and v not in out:
            out.append(v)
    if not out:
        out = [int(config.page_size)]
    return out


def _add_competitiveness_summary(report: Dict[str, Any]) -> Dict[str, Any]:
    timing = report.get("timing", {})
    fused = float(timing.get("experimental_fused_seconds") or 0.0)
    graph = timing.get("cuda_graph") if isinstance(timing.get("cuda_graph"), dict) else {}
    graph_seconds = graph.get("seconds") if graph and graph.get("captured") else None
    effective_fused = float(graph_seconds) if graph_seconds is not None else fused
    effective_mode = "cuda-graph-replay" if graph_seconds is not None else "normal-fused-call"

    dense = float(timing.get("dense_attention_seconds") or 0.0)
    sdpa = timing.get("sdpa")
    sdpa_seconds = float(sdpa.get("seconds")) if isinstance(sdpa, dict) and "seconds" in sdpa else None
    ref = float(timing.get("compressed_page_reference_seconds") or 0.0)

    def ratio(a: Optional[float], b: Optional[float]) -> Optional[float]:
        if a is None or b is None or b <= 0:
            return None
        return float(a) / float(b)

    fused_over_dense = ratio(fused, dense)
    fused_over_sdpa = ratio(fused, sdpa_seconds)
    ref_over_fused = ratio(ref, fused)
    effective_over_dense = ratio(effective_fused, dense)
    effective_over_sdpa = ratio(effective_fused, sdpa_seconds)
    ref_over_effective = ratio(ref, effective_fused)

    competitive_dense = effective_over_dense is not None and effective_over_dense <= 1.0
    competitive_sdpa = effective_over_sdpa is not None and effective_over_sdpa <= 1.0

    summary = {
        "target": report.get("config", {}).get("competitiveness_target", "sdpa"),
        "effective_mode": effective_mode,
        "effective_fused_seconds": effective_fused,
        "fused_over_dense": fused_over_dense,
        "fused_over_sdpa": fused_over_sdpa,
        "reference_over_fused": ref_over_fused,
        "effective_over_dense": effective_over_dense,
        "effective_over_sdpa": effective_over_sdpa,
        "reference_over_effective": ref_over_effective,
        "cuda_graph_captured": bool(graph.get("captured", False)) if graph else False,
        "faster_than_dense_manual": competitive_dense,
        "faster_than_sdpa": competitive_sdpa,
        "faster_than_compressed_page_reference": ref_over_effective is not None and ref_over_effective > 1.0,
        "verdict": (
            "competitive-with-sdpa" if competitive_sdpa else
            "competitive-with-dense-manual" if competitive_dense else
            "faster-than-python-reference-only" if ref_over_effective is not None and ref_over_effective > 1.0 else
            "not-competitive-yet"
        ),
        "boundary": "This is a microbenchmark diagnostic, not production inference acceleration.",
    }
    report["competitiveness"] = summary
    report.setdefault("timing", {})["fused_over_dense_manual"] = fused_over_dense
    report.setdefault("timing", {})["fused_over_sdpa"] = fused_over_sdpa
    report.setdefault("timing", {})["effective_fused_seconds"] = effective_fused
    report.setdefault("timing", {})["effective_fused_mode"] = effective_mode
    report.setdefault("timing", {})["effective_over_dense_manual"] = effective_over_dense
    report.setdefault("timing", {})["effective_over_sdpa"] = effective_over_sdpa
    return report


def run_fused_decode_benchmark(config: FusedDecodeBenchConfig) -> Dict[str, Any]:
    """Benchmark dense, SDPA, compressed-page reference, and v0.9 fused path.

    v0.10.0 can optionally sweep page sizes in addition to BLOCK_M.  The returned
    report is always the fastest fused candidate, with all candidates recorded
    under ``page_size_tuning`` when page-size tuning is enabled.
    """
    page_sizes = _candidate_page_sizes(config)
    if len(page_sizes) <= 1:
        return _add_competitiveness_summary(_run_fused_decode_benchmark_core(config))

    reports: List[Dict[str, Any]] = []
    rows: List[Dict[str, Any]] = []
    for ps in page_sizes:
        cfg = FusedDecodeBenchConfig(**{**asdict(config), "page_size": int(ps), "tune_page_size": False})
        rep = _add_competitiveness_summary(_run_fused_decode_benchmark_core(cfg))
        reports.append(rep)
        q = rep.get("quality", {}).get("fused_vs_dense", {})
        rows.append({
            "page_size": int(ps),
            "selected_kernel_block_m": rep.get("timing", {}).get("selected_kernel_block_m"),
            "experimental_fused_seconds": rep.get("timing", {}).get("experimental_fused_seconds"),
            "graph_fused_seconds": rep.get("timing", {}).get("graph_fused_seconds"),
            "effective_fused_seconds": rep.get("timing", {}).get("effective_fused_seconds"),
            "effective_fused_mode": rep.get("timing", {}).get("effective_fused_mode"),
            "dense_attention_seconds": rep.get("timing", {}).get("dense_attention_seconds"),
            "sdpa_seconds": (rep.get("timing", {}).get("sdpa") or {}).get("seconds") if isinstance(rep.get("timing", {}).get("sdpa"), dict) else None,
            "effective_compression_ratio": rep.get("memory", {}).get("effective_compression_ratio"),
            "effective_memory_saved_pct": rep.get("memory", {}).get("effective_memory_saved_pct"),
            "relative_error": q.get("relative_error"),
            "cosine_similarity": q.get("cosine_similarity"),
            "competitiveness_verdict": rep.get("competitiveness", {}).get("verdict"),
        })

    best = min(reports, key=lambda r: float(r.get("timing", {}).get("effective_fused_seconds") or r.get("timing", {}).get("experimental_fused_seconds") or 1e30))
    best["version"] = "0.10.0"
    best["page_size_tuning"] = rows
    best["execution"]["selected_page_size"] = int(best.get("config", {}).get("page_size", config.page_size))
    best["execution"]["tune_page_size"] = True
    best["timing"]["selected_page_size"] = int(best.get("config", {}).get("page_size", config.page_size))
    best["timing"]["page_size_tuning"] = rows
    best["interpretation"] = (
        "v0.10.0 benchmarks an experimental compressed decode-attention path over the compressed page layout with optional "
        "BLOCK_M, page-size tuning, and CUDA Graph replay diagnostics. It reads compressed pages without constructing full dense K/V. The competitiveness "
        "verdict is a microbenchmark diagnostic and is not a production acceleration claim."
    )
    return _add_competitiveness_summary(best)

def fused_decode_markdown_report(report: Dict[str, Any]) -> str:
    mem = report["memory"]
    timing = report["timing"]
    quality = report["quality"]
    execution = report.get("execution", {})
    lines = [
        "# tiny-turboquant v0.10.0 fused decode-attention benchmark",
        "",
        "## Execution",
        f"- Mode: {execution.get('mode')}",
        f"- Triton attempted: {execution.get('triton_attempted')}",
        f"- Uses compressed pages directly: {execution.get('uses_compressed_pages_directly')}",
        f"- Constructs full dense K/V: {execution.get('constructs_full_dense_kv')}",
        f"- Reason: {execution.get('reason')}",
        "",
        "## Memory",
        f"- FP16 K/V bytes: {mem['fp16_kv_bytes']}",
        f"- Actual compressed-layout bytes: {mem['actual_total_bytes']}",
        f"- Effective compression: {mem['effective_compression_ratio']:.4f}x",
        f"- Effective memory saved: {mem['effective_memory_saved_pct']:.2f}%",
        "",
        "## Timing",
        f"- Dense attention seconds: {timing['dense_attention_seconds']:.6f}",
        f"- Compressed page reference seconds: {timing['compressed_page_reference_seconds']:.6f}",
        f"- Experimental fused seconds: {timing['experimental_fused_seconds']:.6f}",
        f"- CUDA Graph replay: {timing.get('cuda_graph')}",
        f"- Selected BLOCK_M: {timing.get('selected_kernel_block_m')}",
        f"- Selected page size: {timing.get('selected_page_size')}",
        f"- SDPA: {timing.get('sdpa')}",
        "",
        "## Competitiveness",
        f"- Summary: {report.get('competitiveness')}",
        "",
        "## Quality",
        f"- Fused vs dense: {quality['fused_vs_dense']}",
        f"- Reference vs dense: {quality['reference_vs_dense']}",
        f"- Fused vs reference: {quality['fused_vs_reference']}",
        f"- Warning: {quality['quality_warning']}",
        "",
        "## Boundary",
        "This is an experimental research benchmark. It does not claim production inference acceleration.",
    ]
    return "\n".join(lines) + "\n"


def save_fused_decode_json(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(json.dumps(report, indent=2), encoding="utf-8")


def save_fused_decode_markdown(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(fused_decode_markdown_report(report), encoding="utf-8")
