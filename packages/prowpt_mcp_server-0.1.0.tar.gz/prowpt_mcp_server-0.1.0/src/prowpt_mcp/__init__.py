"""Prowpt.ai MCP server — lets AI agents manage web apps via the Prowpt API."""
