"""
AXON Backends — Abstract Base Backend
=======================================
Defines the interface that every model-specific backend must implement.

A backend's job is to take model-agnostic AXON IR and produce
provider-specific prompt structures ready for execution.

The separation is intentional:
  - IR Generator produces WHAT to do (model-agnostic)
  - Backend produces HOW to say it (model-specific)
  - Runtime (Phase 3) will EXECUTE it

Design decisions:
  1. compile_program() produces the full compiled output.
  2. compile_step() handles individual step compilation with context.
  3. compile_system_prompt() builds the system prompt from persona + anchors.
  4. compile_tool_spec() produces provider-native tool declarations.
  5. CompilationContext carries state between step compilations.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from axon.compiler.ir_nodes import (
    IRAnchor,
    IRAgent,
    IRAggregate,
    IRAssociate,
    IRAxonStore,
    IRChannel,
    IRComputeApply,
    IRConsensus,
    IRContext,
    IRCorroborate,
    IRDaemon,
    IRDataSpace,
    IRDeliberate,
    IRDiscover,
    IREmit,
    IRExplore,
    IRFlow,
    IRFocus,
    IRForge,
    IRIngest,
    IRListen,
    IRMutate,
    IRNavigate,
    IRNode,
    IRPersist,
    IRPersona,
    IRProgram,
    IRPsycheSpec,
    IRPublish,
    IRPurge,
    IRRetrieve,
    IRRun,
    IRShield,
    IRShieldApply,
    IRStep,
    IRToolSpec,
    IRTransact,
    IROtsApply,
)

# IR types that represent Data Science operations
_DATA_SCIENCE_IR_TYPES = (IRDataSpace, IRIngest, IRFocus, IRAssociate, IRAggregate, IRExplore)

# IR types that represent compute budget / consensus / forge operations
_BUDGET_IR_TYPES = (IRDeliberate, IRConsensus, IRForge, IRAgent)

# IR types that represent Shield operations (security boundaries)
_SHIELD_IR_TYPES = (IRShieldApply,)

# IR types that represent MDN operations (multi-document navigation)
_MDN_IR_TYPES = (IRNavigate, IRCorroborate)

# IR types that represent Psyche operations (psychological-epistemic modeling)
_PSYCHE_IR_TYPES = (IRPsycheSpec,)

# IR types that represent OTS operations (ontological tool synthesis)
_OTS_IR_TYPES = (IROtsApply,)

# IR types that represent Compute operations (deterministic muscle)
_COMPUTE_IR_TYPES = (IRComputeApply,)

# IR types that represent Daemon operations (AxonServer π-calculus)
_DAEMON_IR_TYPES = (IRDaemon,)

# IR types that represent AxonStore operations (HoTT transactional persistence)
_AXONSTORE_IR_TYPES = (IRAxonStore, IRPersist, IRRetrieve, IRMutate, IRPurge, IRTransact)

# IR types that represent Typed Channel operations (Fase 13.i — π-calculus
# mobility runtime integration). emit/publish/discover bypass the model and
# route through the TypedEventBus held by the Executor at unit lifetime.
_CHANNEL_OP_IR_TYPES = (IREmit, IRPublish, IRDiscover)

# IR types that represent free-standing listen blocks inside a flow body
# (Fase 13.j — distinct from the daemon-internal listen which is part of
# IRDaemon.listeners). A listen-in-flow is a single-event receive: it
# subscribes to the named channel, awaits one event, binds it to the
# alias, and executes the children once. Looped reception belongs to a
# `daemon` declaration.
_LISTEN_IR_TYPES = (IRListen,)


# ═══════════════════════════════════════════════════════════════════
#  COMPILATION OUTPUT CONTAINERS
# ═══════════════════════════════════════════════════════════════════

@dataclass
class CompiledStep:
    """
    The compilation result for a single cognitive step.

    Contains the prompt(s) to send to the model, any tool
    declarations needed, and output format expectations.
    """
    step_name: str = ""
    system_prompt: str = ""
    user_prompt: str = ""
    tool_declarations: list[dict[str, Any]] = field(default_factory=list)
    output_schema: dict[str, Any] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to JSON-compatible dict."""
        result: dict[str, Any] = {
            "step_name": self.step_name,
            "system_prompt": self.system_prompt,
            "user_prompt": self.user_prompt,
        }
        if self.tool_declarations:
            result["tool_declarations"] = self.tool_declarations
        if self.output_schema:
            result["output_schema"] = self.output_schema
        if self.metadata:
            result["metadata"] = self.metadata
        return result


@dataclass
class CompiledProgram:
    """
    The complete compilation output for an AXON program.

    Contains all compiled execution units (one per run statement),
    plus global metadata about the compilation.
    """
    backend_name: str = ""
    execution_units: list[CompiledExecutionUnit] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to JSON-compatible dict."""
        return {
            "backend_name": self.backend_name,
            "execution_units": [u.to_dict() for u in self.execution_units],
            "metadata": self.metadata,
        }


@dataclass
class CompiledExecutionUnit:
    """
    A single execution unit — one run statement fully compiled.

    Contains the system prompt (persona + anchors), the ordered
    step prompts, and all tool declarations needed.
    """
    flow_name: str = ""
    persona_name: str = ""
    context_name: str = ""
    system_prompt: str = ""
    steps: list[CompiledStep] = field(default_factory=list)
    tool_declarations: list[dict[str, Any]] = field(default_factory=list)
    anchor_instructions: list[str] = field(default_factory=list)
    active_anchors: list[dict[str, Any]] = field(default_factory=list)
    effort: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to JSON-compatible dict."""
        result: dict[str, Any] = {
            "flow_name": self.flow_name,
            "system_prompt": self.system_prompt,
            "steps": [s.to_dict() for s in self.steps],
        }
        if self.persona_name:
            result["persona_name"] = self.persona_name
        if self.context_name:
            result["context_name"] = self.context_name
        if self.tool_declarations:
            result["tool_declarations"] = self.tool_declarations
        if self.anchor_instructions:
            result["anchor_instructions"] = self.anchor_instructions
        if self.active_anchors:
            result["active_anchors"] = self.active_anchors
        if self.effort:
            result["effort"] = self.effort
        if self.metadata:
            result["metadata"] = self.metadata
        return result


@dataclass
class CompilationContext:
    """
    Carries state through the step compilation process.

    Backends use this to track the current persona, active anchors,
    available tools, and any accumulated context from prior steps.
    """
    persona: IRPersona | None = None
    context: IRContext | None = None
    anchors: list[IRAnchor] = field(default_factory=list)
    tools: dict[str, IRToolSpec] = field(default_factory=dict)
    flow: IRFlow | None = None
    prior_step_names: list[str] = field(default_factory=list)
    effort: str = ""


# ═══════════════════════════════════════════════════════════════════
#  ABSTRACT BASE BACKEND
# ═══════════════════════════════════════════════════════════════════

class BaseBackend(ABC):
    """
    Abstract base class for all AXON model backends.

    Every backend must implement these four methods to compile
    AXON IR into provider-specific prompt structures.

    The default compile_program() implementation handles the
    orchestration logic (iterating runs, building context),
    delegating model-specific work to the abstract methods.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """The canonical name of this backend (e.g., 'anthropic')."""
        ...

    def compile_program(self, ir: IRProgram) -> CompiledProgram:
        """
        Compile a complete IR program into backend-specific output.

        The default implementation iterates over all run statements,
        resolves their dependencies, and delegates step compilation
        to the abstract methods. Subclasses may override for custom
        orchestration.
        """
        # Build tool lookup from program-level declarations
        tools = {tool.name: tool for tool in ir.tools}

        execution_units: list[CompiledExecutionUnit] = []

        for run in ir.runs:
            if run.resolved_flow is None:
                continue  # unresolved run — skip (should not happen post-IR gen)

            # Build compilation context for this run
            ctx = CompilationContext(
                persona=run.resolved_persona,
                context=run.resolved_context,
                anchors=list(run.resolved_anchors),
                tools=tools,
                flow=run.resolved_flow,
                effort=run.effort,
            )

            # Phase 1: Compile system prompt (persona + anchors)
            system_prompt = self.compile_system_prompt(
                persona=run.resolved_persona,
                context=run.resolved_context,
                anchors=list(run.resolved_anchors),
            )

            # Phase 2: Compile anchor enforcement instructions
            anchor_instructions = [
                self.compile_anchor_instruction(anchor)
                for anchor in run.resolved_anchors
            ]

            # Phase 3: Compile tool declarations
            tool_declarations = [
                self.compile_tool_spec(tools[name])
                for name in tools
                if name in tools
            ]

            # Phase 4: Compile each step in the flow
            compiled_steps: list[CompiledStep] = []

            # Phase 4a: Inject axonstore definitions as init steps
            for store_spec in ir.axonstore_specs:
                store_init = self._compile_axonstore_step(store_spec)
                compiled_steps.append(store_init)

            for step in run.resolved_flow.steps:
                # Data Science IR nodes bypass the model — compile as
                # metadata-only steps that the executor routes to the
                # DataScienceDispatcher.
                if isinstance(step, _DATA_SCIENCE_IR_TYPES):
                    ds_step = self._compile_data_science_step(step)
                    compiled_steps.append(ds_step)
                elif isinstance(step, _BUDGET_IR_TYPES):
                    budget_step = self._compile_budget_step(step, ctx)
                    compiled_steps.append(budget_step)
                elif isinstance(step, _SHIELD_IR_TYPES):
                    shield_step = self._compile_shield_step(step, ir)
                    compiled_steps.append(shield_step)
                elif isinstance(step, _MDN_IR_TYPES):
                    mdn_step = self._compile_mdn_step(step, ir)
                    compiled_steps.append(mdn_step)
                elif isinstance(step, _PSYCHE_IR_TYPES):
                    psyche_step = self._compile_psyche_step(step, ir)
                    compiled_steps.append(psyche_step)
                elif isinstance(step, _OTS_IR_TYPES):
                    ots_step = self._compile_ots_step(step, ir)
                    compiled_steps.append(ots_step)
                elif isinstance(step, _COMPUTE_IR_TYPES):
                    compute_step = self._compile_compute_step(step, ir)
                    compiled_steps.append(compute_step)
                elif isinstance(step, _DAEMON_IR_TYPES):
                    daemon_step = self._compile_daemon_step(step, ctx)
                    compiled_steps.append(daemon_step)
                elif isinstance(step, _AXONSTORE_IR_TYPES):
                    store_step = self._compile_axonstore_step(step)
                    compiled_steps.append(store_step)
                elif isinstance(step, _CHANNEL_OP_IR_TYPES):
                    channel_step = self._compile_channel_op_step(step)
                    compiled_steps.append(channel_step)
                elif isinstance(step, _LISTEN_IR_TYPES):
                    listen_step = self._compile_listen_step(step)
                    compiled_steps.append(listen_step)
                else:
                    compiled = self.compile_step(step, ctx)
                    compiled_steps.append(compiled)
                ctx.prior_step_names.append(
                    step.name if isinstance(step, IRStep) else ""
                )

            active_anchors = [
                {"name": anchor.name, "require": anchor.require, "reject": anchor.reject}
                for anchor in run.resolved_anchors
            ]

            # Serialise IRChannel declarations so the Executor can bootstrap
            # a TypedEventBus per-unit without holding a reference to the IR
            # itself. Same shape as TypedChannelHandle.from_ir(...) consumes.
            # (Fase 13.i — closes the gap where channel surface compiled but
            # the runtime had no way to materialise the bus from IR alone.)
            channel_specs = [
                {
                    "name": ch.name,
                    "message": ch.message,
                    "qos": ch.qos,
                    "lifetime": ch.lifetime,
                    "persistence": ch.persistence,
                    "shield_ref": ch.shield_ref,
                }
                for ch in ir.channels
            ]

            unit = CompiledExecutionUnit(
                flow_name=run.flow_name,
                persona_name=run.persona_name,
                context_name=run.context_name,
                system_prompt=system_prompt,
                steps=compiled_steps,
                tool_declarations=tool_declarations,
                anchor_instructions=anchor_instructions,
                active_anchors=active_anchors,
                effort=run.effort,
                metadata={"channel_specs": channel_specs} if channel_specs else {},
            )
            execution_units.append(unit)

        return CompiledProgram(
            backend_name=self.name,
            execution_units=execution_units,
        )

    @staticmethod
    def _compile_channel_op_step(step: IRNode) -> CompiledStep:
        """Compile a typed-channel operation (emit / publish / discover)
        into a metadata-only step (Fase 13.i).

        These steps bypass the model — the executor routes them through
        the per-unit ``TypedEventBus`` (held in ``ctx.typed_bus``).
        Naming convention for ``step_name`` mirrors the data_science /
        axonstore convention so the executor can keep its dispatch flat.
        """
        if isinstance(step, IREmit):
            return CompiledStep(
                step_name=f"emit:{step.channel_ref}",
                user_prompt="",
                metadata={
                    "emit_apply": {
                        "channel_ref": step.channel_ref,
                        "value_ref": step.value_ref,
                        "value_is_channel": step.value_is_channel,
                    },
                },
            )
        if isinstance(step, IRPublish):
            return CompiledStep(
                step_name=f"publish:{step.channel_ref}",
                user_prompt="",
                metadata={
                    "publish_apply": {
                        "channel_ref": step.channel_ref,
                        "shield_ref": step.shield_ref,
                    },
                },
            )
        if isinstance(step, IRDiscover):
            return CompiledStep(
                step_name=f"discover:{step.capability_ref}",
                user_prompt="",
                metadata={
                    "discover_apply": {
                        "capability_ref": step.capability_ref,
                        "alias": step.alias,
                    },
                },
            )
        # Defensive fallback — _CHANNEL_OP_IR_TYPES is a closed tuple, so
        # any miss here indicates a node added to the catalogue without a
        # matching compile branch. Surface it loudly rather than silently
        # producing a malformed step.
        raise TypeError(
            f"_compile_channel_op_step received unexpected IR node "
            f"{type(step).__name__} (not in _CHANNEL_OP_IR_TYPES)"
        )

    @staticmethod
    def _compile_listen_step(step: IRNode) -> CompiledStep:
        """Compile a free-standing ``listen ChannelName as alias { … }``
        flow statement (Fase 13.j) into a metadata-only ``CompiledStep``.

        Unlike a daemon-internal listener (which loops indefinitely
        reacting to events under the supervision of the AxonServer
        daemon supervisor), a listen-in-flow is a **single-event
        receive**: it subscribes to the channel, awaits one event,
        binds it to the alias, and runs the children exactly once
        before yielding to the next flow step. Looped semantics live
        in ``daemon`` declarations.

        The metadata payload carries:
          - ``channel`` and ``channel_is_ref`` (D4 dual-mode marker)
          - ``alias`` (the local name bound to the received event)
          - ``children`` (a tuple of pre-compiled inner CompiledStep
            instances) so the executor can run the listener body
            after the receive without recompiling.
        """
        if not isinstance(step, IRListen):
            raise TypeError(
                f"_compile_listen_step received unexpected IR node "
                f"{type(step).__name__} (expected IRListen)"
            )
        # Pre-compile children so the executor can iterate them in
        # sequence after the receive. Each child is itself an IR step
        # (emit, axonstore, compute, …) that goes through the same
        # isinstance dispatch.  We import inside the function to avoid
        # widening the module-level import surface — the children list
        # is small in practice and recompiling here keeps the listen
        # step self-contained.
        compiled_children: list[CompiledStep] = []
        for child in step.children:
            if isinstance(child, _CHANNEL_OP_IR_TYPES):
                compiled_children.append(BaseBackend._compile_channel_op_step(child))
            elif isinstance(child, _LISTEN_IR_TYPES):
                compiled_children.append(BaseBackend._compile_listen_step(child))
            elif isinstance(child, _AXONSTORE_IR_TYPES):
                compiled_children.append(BaseBackend._compile_axonstore_step(child))
            elif isinstance(child, _COMPUTE_IR_TYPES):
                # Compute steps need the parent IR for catalog lookups but
                # the listen body is constrained: nested compute inside a
                # listener is unusual. We materialise a metadata-only
                # placeholder; if real compute-in-listen surfaces, it gets
                # its own follow-up sub-phase.
                compiled_children.append(CompiledStep(
                    step_name=f"compute:listen-child:{getattr(child, 'name', '_anon')}",
                    user_prompt="",
                    metadata={"compute": {"deferred": True}},
                ))
            else:
                # Generic child — produce a stub that surfaces the IR
                # node type so the executor can decide what to do (or
                # raise if the type is not supported as a listener
                # child). Adopters who hit this in production telemetry
                # can request explicit support per child kind.
                compiled_children.append(CompiledStep(
                    step_name=f"listen-child:{type(child).__name__}",
                    user_prompt="",
                    metadata={"listen_child_unsupported": type(child).__name__},
                ))

        return CompiledStep(
            step_name=f"listen:{step.channel_topic}",
            user_prompt="",
            metadata={
                "listen_apply": {
                    "channel": step.channel_topic,
                    "channel_is_ref": step.channel_is_ref,
                    "alias": step.event_alias,
                    # Children carried as raw CompiledStep objects on the
                    # metadata dict — the executor's listen handler
                    # iterates them under the alias scope produced by
                    # the receive.
                    "children": compiled_children,
                },
            },
        )

    @staticmethod
    def _compile_data_science_step(step: IRNode) -> CompiledStep:
        """Compile a Data Science IR node into a metadata-only step.

        These steps bypass the model — the executor routes them
        directly to the ``DataScienceDispatcher``.
        """
        from axon.compiler.ir_nodes import (
            IRAggregate,
            IRAssociate,
            IRDataSpace,
            IRExplore,
            IRFocus,
            IRIngest,
        )

        op: str = "unknown"
        args: dict[str, Any] = {}

        match step:
            case IRDataSpace(name=name):
                op = "dataspace"
                args = {"name": name}
            case IRIngest(source=src, target=tgt):
                op = "ingest"
                args = {"source": src, "target": tgt}
            case IRFocus(expression=expr):
                op = "focus"
                args = {"expression": expr}
            case IRAssociate(left=l, right=r, using_field=f):
                op = "associate"
                args = {"left": l, "right": r, "using_field": f}
            case IRAggregate(target=tgt, group_by=gb, alias=alias):
                op = "aggregate"
                args = {"target": tgt, "group_by": list(gb), "alias": alias}
            case IRExplore(target=tgt, limit=lim):
                op = "explore"
                args = {"target": tgt, "limit": lim}

        return CompiledStep(
            step_name=f"ds:{op}",
            user_prompt="",
            metadata={
                "data_science": {
                    "operation": op,
                    "args": args,
                },
            },
        )

    @staticmethod
    def _compile_axonstore_step(step: IRNode) -> CompiledStep:
        """Compile an AxonStore IR node into a metadata-only step.

        These steps bypass the model — the executor routes them
        directly to the ``StoreDispatcher``.

        Formal basis:
          - HoTT univalence path (schema isomorphism)
          - Linear Logic token (A ⊸ B) for transact blocks
          - DbC on_breach policy for invariant violations
        """
        from axon.compiler.ir_nodes import (
            IRAxonStore,
            IRMutate,
            IRPersist,
            IRPurge,
            IRRetrieve,
            IRTransact,
        )

        op: str = "unknown"
        args: dict[str, Any] = {}

        match step:
            case IRAxonStore(name=name, backend=backend, connection=conn,
                             confidence_floor=cf, isolation=iso, on_breach=ob):
                op = "axonstore"
                schema_data: list[dict[str, Any]] = []
                if step.schema:
                    schema_data = [
                        {
                            "col_name": c.col_name,
                            "col_type": c.col_type,
                            "primary_key": c.primary_key,
                            "auto_increment": c.auto_increment,
                            "not_null": c.not_null,
                            "unique": c.unique,
                            "default_value": c.default_value,
                        }
                        for c in step.schema.columns
                    ]
                args = {
                    "name": name, "backend": backend,
                    "connection": conn, "schema": schema_data,
                    "confidence_floor": cf, "isolation": iso,
                    "on_breach": ob,
                }
                # Redact credentials from metadata to prevent exposure
                # in traces, logs, and serialized CompiledStep output.
                if conn and not conn.startswith("env:") and "://" in conn:
                    import re as _re
                    args["connection"] = _re.sub(
                        r"://[^@]+@", "://***:***@", conn,
                    )
            case IRPersist(store_name=sn, fields=fields):
                op = "persist"
                args = {"store_name": sn, "fields": [list(f) for f in fields]}
            case IRRetrieve(store_name=sn, where_expr=w, alias=a):
                op = "retrieve"
                args = {"store_name": sn, "where_expr": w, "alias": a}
            case IRMutate(store_name=sn, where_expr=w, fields=fields):
                op = "mutate"
                args = {"store_name": sn, "where_expr": w, "fields": [list(f) for f in fields]}
            case IRPurge(store_name=sn, where_expr=w):
                op = "purge"
                args = {"store_name": sn, "where_expr": w}
            case IRTransact(children=children):
                op = "transact"
                child_ops: list[dict[str, Any]] = []
                for child in children:
                    child_step = BaseBackend._compile_axonstore_step(child)
                    child_ops.append(child_step.metadata.get("axonstore", {}))
                args = {"children": child_ops}

        return CompiledStep(
            step_name=f"store:{op}",
            user_prompt="",
            metadata={
                "axonstore": {
                    "operation": op,
                    "args": args,
                },
            },
        )

    def _compile_budget_step(
        self, step: IRNode, ctx: CompilationContext,
    ) -> CompiledStep:
        """Compile a deliberate/consensus IR node into a metadata step.

        Unlike data science steps, budget steps may contain child
        IR nodes that need recursive compilation.
        """
        match step:
            case IRDeliberate(
                budget=budget, depth=depth,
                strategy=strategy, children=children,
            ):
                child_steps = [
                    self.compile_step(child, ctx)
                    for child in children
                ] if children else []
                return CompiledStep(
                    step_name="budget:deliberate",
                    user_prompt="",
                    metadata={
                        "deliberate": {
                            "budget": budget,
                            "depth": depth,
                            "strategy": strategy,
                            "child_steps": [
                                cs.to_dict() for cs in child_steps
                            ],
                        },
                    },
                )

            case IRConsensus(
                n_branches=n_branches, reward_anchor=reward_anchor,
                selection=selection, children=children,
            ):
                child_steps = [
                    self.compile_step(child, ctx)
                    for child in children
                ] if children else []
                return CompiledStep(
                    step_name="budget:consensus",
                    user_prompt="",
                    metadata={
                        "consensus": {
                            "n_branches": n_branches,
                            "reward_anchor": reward_anchor,
                            "selection": selection,
                            "child_steps": [
                                cs.to_dict() for cs in child_steps
                            ],
                        },
                    },
                )

            case IRForge(
                name=name, seed=seed, output_type=output_type,
                mode=mode, novelty=novelty, constraints=constraints,
                depth=depth, branches=branches, children=children,
            ):
                child_steps = [
                    self.compile_step(child, ctx)
                    for child in children
                ] if children else []
                return CompiledStep(
                    step_name=f"forge:{name}",
                    user_prompt="",
                    metadata={
                        "forge": {
                            "name": name,
                            "seed": seed,
                            "output_type": output_type,
                            "mode": mode,
                            "novelty": novelty,
                            "constraints": constraints,
                            "depth": depth,
                            "branches": branches,
                            "child_steps": [
                                cs.to_dict() for cs in child_steps
                            ],
                        },
                    },
                )

            case IRAgent(
                name=name, goal=goal, tools=tools,
                max_iterations=max_iter, max_tokens=max_tok,
                max_time=max_time, max_cost=max_cost,
                memory_ref=memory_ref,
                strategy=strategy, on_stuck=on_stuck,
                return_type=return_type, children=children,
            ):
                child_steps = [
                    self.compile_step(child, ctx)
                    for child in children
                ] if children else []
                return CompiledStep(
                    step_name=f"agent:{name}",
                    user_prompt="",
                    metadata={
                        "agent": {
                            "name": name,
                            "goal": goal,
                            "tools": list(tools),
                            "max_iterations": max_iter,
                            "max_tokens": max_tok,
                            "max_time": max_time,
                            "max_cost": max_cost,
                            "memory_ref": memory_ref,
                            "strategy": strategy,
                            "on_stuck": on_stuck,
                            "return_type": return_type,
                            "shield_ref": step.shield_ref if hasattr(step, 'shield_ref') else "",
                            "child_steps": [
                                cs.to_dict() for cs in child_steps
                            ],
                        },
                    },
                )

            case _:
                return CompiledStep(
                    step_name="budget:unknown",
                    user_prompt="",
                    metadata={},
                )

    def _compile_daemon_step(
        self, step: IRDaemon, ctx: CompilationContext,
    ) -> CompiledStep:
        """Compile a daemon IR node into a metadata-only step.

        Daemon steps carry all configuration for the runtime's
        co-inductive event loop. The executor uses this metadata
        to set up the EventBus, register listeners, and manage
        the auto-hibernate/resume CPS cycle.

        π-Calculus: Daemon ≡ !( Σᵢ cᵢ(xᵢ).Qᵢ )
        Each listener is compiled with its child steps.
        """
        compiled_listeners = []
        for listener in step.listeners:
            child_steps = [
                self.compile_step(child, ctx)
                for child in listener.children
            ] if listener.children else []
            compiled_listeners.append({
                "channel_type": listener.channel_type,
                "channel_topic": listener.channel_topic,
                "event_alias": listener.event_alias,
                "child_steps": [cs.to_dict() for cs in child_steps],
            })

        return CompiledStep(
            step_name=f"daemon:{step.name}",
            user_prompt="",
            metadata={
                "daemon": {
                    "name": step.name,
                    "goal": step.goal,
                    "tools": list(step.tools),
                    "max_tokens": step.max_tokens,
                    "max_time": step.max_time,
                    "max_cost": step.max_cost,
                    "memory_ref": step.memory_ref,
                    "strategy": step.strategy,
                    "on_stuck": step.on_stuck,
                    "return_type": step.return_type,
                    "shield_ref": step.shield_ref,
                    "continuation_id": step.continuation_id,
                    "listeners": compiled_listeners,
                },
            },
        )

    @staticmethod
    def _compile_shield_step(
        step: IRShieldApply, ir: IRProgram,
    ) -> CompiledStep:
        """Compile a shield application into a metadata-only step.

        Shield steps don't go to the model — the runtime's
        SecurityExecutor processes them inline, performing:
          1. Taint analysis (Untrusted → Sanitized)
          2. Pattern/classifier scanning
          3. Capability enforcement
          4. PII redaction
        """
        # Resolve the shield definition from the program
        shield_def: dict[str, Any] = {}
        for shield in ir.shields:
            if shield.name == step.shield_name:
                shield_def = {
                    "name": shield.name,
                    "scan": list(shield.scan),
                    "strategy": shield.strategy,
                    "on_breach": shield.on_breach,
                    "severity": shield.severity,
                    "quarantine": shield.quarantine,
                    "max_retries": shield.max_retries,
                    "confidence_threshold": shield.confidence_threshold,
                    "allow_tools": list(shield.allow_tools),
                    "deny_tools": list(shield.deny_tools),
                    "sandbox": shield.sandbox,
                    "redact": list(shield.redact),
                    "log": shield.log,
                    "deflect_message": shield.deflect_message,
                }
                break

        return CompiledStep(
            step_name=f"shield:{step.shield_name}",
            user_prompt="",
            metadata={
                "shield_apply": {
                    "shield_name": step.shield_name,
                    "target": step.target,
                    "output_type": step.output_type,
                    "shield_definition": shield_def,
                },
            },
        )

    @staticmethod
    def _compile_mdn_step(
        step: IRNode, ir: IRProgram,
    ) -> CompiledStep:
        """Compile an MDN IR node into a metadata-only step.

        MDN steps bypass the model — the executor routes them
        to the corpus navigator engine for graph-based retrieval
        and corroboration.

        Handles two IR types:
          - ``IRNavigate`` with ``corpus_ref`` — corpus-level navigation
          - ``IRCorroborate``                  — cross-path verification
        """
        # Helper: resolve corpus spec from program
        def _resolve_corpus(name: str) -> dict[str, Any]:
            for spec in ir.corpus_specs:
                if spec.name == name:
                    return {
                        "name": spec.name,
                        "documents": [
                            {
                                "pix_ref": d.pix_ref,
                                "doc_type": d.doc_type,
                                "role": d.role,
                            }
                            for d in spec.documents
                        ],
                        "edges": [
                            {
                                "source_ref": e.source_ref,
                                "target_ref": e.target_ref,
                                "relation_type": e.relation_type,
                            }
                            for e in spec.edges
                        ],
                        "weights": dict(spec.weights),
                    }
            return {}

        match step:
            case IRNavigate(
                corpus_ref=corpus_ref,
                query=query,
                trail_enabled=trail,
                output_name=out_name,
                budget_depth=depth,
                budget_nodes=nodes,
                edge_filter=edge_f,
            ) if corpus_ref:
                corpus_def = _resolve_corpus(corpus_ref)
                return CompiledStep(
                    step_name=f"mdn:navigate:{corpus_ref}",
                    user_prompt="",
                    metadata={
                        "corpus_navigate": {
                            "corpus_ref": corpus_ref,
                            "corpus_definition": corpus_def,
                            "query": query,
                            "trail_enabled": trail,
                            "output_name": out_name,
                            "budget_depth": depth,
                            "budget_nodes": nodes,
                            "edge_filter": list(edge_f) if edge_f else [],
                        },
                    },
                )

            case IRCorroborate(
                navigate_ref=nav_ref,
                output_name=out_name,
            ):
                return CompiledStep(
                    step_name=f"mdn:corroborate:{nav_ref}",
                    user_prompt="",
                    metadata={
                        "corroborate": {
                            "navigate_ref": nav_ref,
                            "output_name": out_name,
                        },
                    },
                )

            case _:
                # IRNavigate without corpus_ref (single-doc PIX mode)
                # falls through to regular step compilation
                return CompiledStep(
                    step_name="mdn:unknown",
                    user_prompt="",
                    metadata={},
                )

    @staticmethod
    def _compile_psyche_step(
        step: IRPsycheSpec, ir: IRProgram,
    ) -> CompiledStep:
        """Compile a psyche spec into a metadata-only step.

        Psyche steps don't go to the model directly — the runtime's
        PsycheExecutor processes them to initialize the PEM engine:
          1. Cognitive manifold construction (§1 — Riemannian dynamics)
          2. Density matrix allocation (§2 — quantum cognitive probability)
          3. Active inference loop setup (§3 — free energy minimization)
          4. Safety type enforcement (§4 — NonDiagnostic constraint)

        The compiled metadata carries all configuration needed to
        instantiate the PsycheEngine at runtime.
        """
        return CompiledStep(
            step_name=f"psyche:{step.name}",
            user_prompt="",
            metadata={
                "psyche_spec": {
                    "name": step.name,
                    "dimensions": list(step.dimensions),
                    "manifold": {
                        "curvature": dict(step.manifold_curvature),
                        "noise": step.manifold_noise,
                        "momentum": step.manifold_momentum,
                    },
                    "safety_constraints": list(step.safety_constraints),
                    "quantum_enabled": step.quantum_enabled,
                    "inference_mode": step.inference_mode,
                },
            },
        )

    @staticmethod
    def _compile_ots_step(
        step: IROtsApply, ir: IRProgram,
    ) -> CompiledStep:
        """Compile an OTS application into a metadata-only step.

        OTS steps don't go to the model directly during standard execution —
        the runtime's OtsDispatcher processes them via Just-In-Time synthesis.
        """
        # Resolve the OTS definition from the program
        ots_def: dict[str, Any] = {}
        for spec in ir.ots_specs:
            if spec.name == step.ots_name:
                ots_def = {
                    "name": spec.name,
                    "types": list(spec.types),
                    "teleology": spec.teleology,
                    "homotopy_search": spec.homotopy_search,
                    "linear_constraints": list(spec.linear_constraints),
                    "loss_function": spec.loss_function,
                }
                break

        return CompiledStep(
            step_name=f"ots:{step.ots_name}",
            user_prompt="",
            metadata={
                "ots_apply": {
                    "ots_name": step.ots_name,
                    "target": step.target,
                    "output_type": step.output_type,
                    "ots_definition": ots_def,
                },
            },
        )

    @staticmethod
    def _compile_compute_step(
        step: IRComputeApply, ir: IRProgram,
    ) -> CompiledStep:
        """Compile a compute application into a metadata-only step.

        Compute steps bypass the model entirely — the runtime's
        NativeComputeDispatcher executes them as deterministic
        Fast-Path operations (System 1).
        """
        compute_def: dict[str, Any] = {}
        for spec in ir.compute_specs:
            if spec.name == step.compute_name:
                compute_def = {
                    "name": spec.name,
                    "inputs": [
                        {"name": p.name, "type": p.type_name}
                        for p in spec.inputs
                    ],
                    "output_type": spec.output_type,
                    "logic_source": spec.logic_source,
                    "shield_ref": spec.shield_ref,
                    "verified": spec.verified,
                }
                break

        return CompiledStep(
            step_name=f"compute:{step.compute_name}",
            user_prompt="",
            metadata={
                "compute": {
                    "compute_name": step.compute_name,
                    "arguments": list(step.arguments),
                    "output_name": step.output_name,
                    "compute_definition": compute_def,
                },
            },
        )

    @abstractmethod
    def compile_step(
        self, step: IRNode, context: CompilationContext
    ) -> CompiledStep:
        """
        Compile a single IR step into a backend-specific prompt.

        Args:
            step: The IR node to compile (IRStep, IRProbe, etc.)
            context: The current compilation context.

        Returns:
            A CompiledStep with model-specific prompts.
        """
        ...

    @abstractmethod
    def compile_system_prompt(
        self,
        persona: IRPersona | None,
        context: IRContext | None,
        anchors: list[IRAnchor],
    ) -> str:
        """
        Build the system prompt from persona, context, and anchors.

        This is the Anchor Enforcer's injection point: all hard
        constraints are woven into the system-level instructions
        that the model receives before any user messages.
        """
        ...

    @abstractmethod
    def compile_tool_spec(self, tool: IRToolSpec) -> dict[str, Any]:
        """
        Compile a tool specification into the backend's native format.

        E.g., for Anthropic: {"name": ..., "description": ..., "input_schema": ...}
        E.g., for Gemini: {"function_declarations": [...]}
        """
        ...

    def compile_anchor_instruction(self, anchor: IRAnchor) -> str:
        """
        Compile a single anchor into a natural-language enforcement
        instruction for inclusion in the system prompt.

        The default implementation produces a structured constraint
        block. Backends may override for provider-specific formatting.
        """
        parts: list[str] = [f"[CONSTRAINT: {anchor.name}]"]

        if anchor.require:
            parts.append(f"  REQUIRE: {anchor.require}")
        if anchor.reject:
            parts.append(f"  REJECT: {', '.join(anchor.reject)}")
        if anchor.enforce:
            parts.append(f"  ENFORCE: {anchor.enforce}")
        if anchor.confidence_floor is not None:
            parts.append(
                f"  CONFIDENCE FLOOR: {anchor.confidence_floor}"
            )
        if anchor.unknown_response:
            parts.append(
                f"  WHEN UNCERTAIN: \"{anchor.unknown_response}\""
            )
        if anchor.on_violation:
            violation = anchor.on_violation
            if anchor.on_violation_target:
                violation += f" {anchor.on_violation_target}"
            parts.append(f"  ON VIOLATION: {violation}")

        return "\n".join(parts)

    # ═══════════════════════════════════════════════════════════════
    #  AGENT-SPECIFIC COMPILATION — BDI Prompt Engineering
    # ═══════════════════════════════════════════════════════════════

    @abstractmethod
    def compile_agent_system_prompt(
        self,
        agent_name: str,
        goal: str,
        strategy: str,
        tools: list[str],
        epistemic_state: str,
        iteration: int,
        max_iterations: int,
    ) -> str:
        """
        Build a provider-optimized system prompt for agent BDI cycles.

        This method is called by the executor during each BDI cycle
        to generate the system-level instructions that configure the
        LLM for the agent's current cognitive state.

        ╔══════════════════════════════════════════════════════════╗
        ║  FORMAL CONTRACT                                        ║
        ╠══════════════════════════════════════════════════════════╣
        ║  Input:                                                  ║
        ║    agent_name — identifier for the BDI entity            ║
        ║    goal — Davidson pro-attitude (desired state)          ║
        ║    strategy ∈ {react, reflexion, plan_and_execute,       ║
        ║               custom}                                    ║
        ║    tools — available tool names from plan library        ║
        ║    epistemic_state ∈ {doubt, speculate, believe, know}   ║
        ║    iteration — current cycle index (0-based)             ║
        ║    max_iterations — budget cap                           ║
        ║                                                          ║
        ║  Output:                                                 ║
        ║    Provider-native system prompt string encoding:        ║
        ║    - Agent identity and role framing                     ║
        ║    - BDI cognitive cycle instructions                    ║
        ║    - Strategy-specific reasoning protocol                ║
        ║    - Available capabilities enumeration                  ║
        ║    - Epistemic state awareness                           ║
        ║    - Convergence budget constraints                      ║
        ╚══════════════════════════════════════════════════════════╝

        Args:
            agent_name: The declared name of the agent.
            goal: The agent's goal statement (desire).
            strategy: The deliberation strategy to follow.
            tools: List of available tool names.
            epistemic_state: Current position on the Tarski lattice.
            iteration: Current BDI cycle number (0-based).
            max_iterations: Maximum cycles allowed by budget.

        Returns:
            A fully formatted system prompt string.
        """
        ...

    def compile_agent_tool_binding(
        self,
        tool_names: list[str],
        available_tools: dict[str, IRToolSpec],
    ) -> list[dict[str, Any]]:
        """
        Resolve agent tool references to compiled tool declarations.

        This default implementation iterates the agent's declared
        tool names, resolves each against the program-level tool
        registry, and compiles them using the backend's native
        ``compile_tool_spec()`` method.

        The resolution follows linear logic resource semantics:
        each tool binding is a resource allocated to the agent's
        plan library, available for consumption during BDI cycles.

        Args:
            tool_names: Tool names declared in the agent block.
            available_tools: Program-level tool registry (name → IRToolSpec).

        Returns:
            List of provider-native tool declarations (dicts).
        """
        bound: list[dict[str, Any]] = []
        for name in tool_names:
            if name in available_tools:
                bound.append(self.compile_tool_spec(available_tools[name]))
        return bound
