# Compressors

Compressors is a library of containing flexible implementations of state-of-the-art compression systems.

Compressors is early in development, but aims to include:

* Lossless compression systems, which can be used standalone or as part of a lossy compression system.
* Energy compacting transforms like the DCT, MCDCT, Wavelet transforms, and Wavelet packet transform.
* Differentiable soft quantizers for learned compression
* DNN autoencoder building blocks for standard modalities such as stereo audio, and RGB image/video
* DNN autoencoder building blocks for arbitrary signal shapes and dimensions, allowing users to easily create codecs for non-standard inputs (spatial audio arrays, hyperspectral images, 3d volumes, etc)
* End-to-end codec pipelines that combine the above techniques
* Conventional distortion metrics (e.g. PSNR, SSIM) for training and evaluation
* DNN-based distortion metrics (e.g. LPIPS, DISTS) for training and evaluation
* Tools for creating machine-oriented codecs, which can be optimized for downstream applications in addition to one or more distortion metrics

## Package

- Python package: `pip install compressors`
