"""Stage 2 FrameClassifier: Conv + Transformer + Linear -> per-frame 4-class logits."""

import math
from pathlib import Path

import torch
from torch import nn


class FrameClassifier(nn.Module):
    """Input: signal [B, 2500] @ 250Hz, lead_id [B] in {0..11}.
    Output: logits [B, 500, 4] (per-frame supercategory).
    """

    def __init__(
        self,
        n_leads=12,
        d_model=64,
        n_heads=4,
        n_layers=4,
        ff=256,
        n_classes=4,
        dropout=0.1,
        use_lead_emb=True,
    ):
        super().__init__()
        self.model_config = {
            "n_leads": n_leads,
            "d_model": d_model,
            "n_heads": n_heads,
            "n_layers": n_layers,
            "ff": ff,
            "n_classes": n_classes,
            "dropout": dropout,
            "use_lead_emb": use_lead_emb,
        }
        self.use_lead_emb = use_lead_emb
        self.conv1 = nn.Conv1d(1, 32, kernel_size=15, stride=5, padding=7)
        self.conv2 = nn.Conv1d(32, d_model, kernel_size=5, stride=1, padding=2)
        if use_lead_emb:
            self.lead_emb = nn.Embedding(n_leads, d_model)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=ff,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.head = nn.Linear(d_model, n_classes)

    def forward(self, x, lead_id):
        h = torch.nn.functional.gelu(self.conv1(x.unsqueeze(1)))
        h = torch.nn.functional.gelu(self.conv2(h))
        h = h.transpose(1, 2)
        if self.use_lead_emb:
            h = h + self.lead_emb(lead_id).unsqueeze(1)
        h = self.transformer(h)
        return self.head(h)


class FrameClassifierViT(nn.Module):
    """ViT-style: non-overlapping patch + Linear projection + positional encoding
    + Transformer + Linear head.

    Input:  signal [B, 2500] @ 250Hz, lead_id [B] in {0..11}.
    Output: logits [B, n_patches, n_classes] (per-frame supercategory).

    Options:
      pos_type: 'sinusoidal' (fixed), 'learnable' (nn.Embedding), or 'none'
      use_lead_emb: add per-lead embedding broadcast across all patches
      conv_stem: pre-patch Conv1d block to extract local features before
                 the linear patch embedding. Conv stem produces a richer
                 input than raw signal samples for the linear projection.
                 conv_stem=True applies: Conv1d(1->16, k=7, p=3) + GELU
                 + Conv1d(16->32, k=5, p=2) + GELU, length-preserving.
    """

    def __init__(
        self,
        patch_size=5,
        n_leads=12,
        d_model=64,
        n_heads=4,
        n_layers=4,
        ff=256,
        n_classes=4,
        dropout=0.1,
        use_lead_emb=True,
        pos_type="sinusoidal",
        conv_stem=False,
        max_seq_len=512,
    ):
        super().__init__()
        self.patch_size = patch_size
        self.use_lead_emb = use_lead_emb
        self.pos_type = pos_type
        self.conv_stem = conv_stem
        self.model_config = {
            "patch_size": patch_size,
            "n_leads": n_leads,
            "d_model": d_model,
            "n_heads": n_heads,
            "n_layers": n_layers,
            "ff": ff,
            "n_classes": n_classes,
            "dropout": dropout,
            "use_lead_emb": use_lead_emb,
            "pos_type": pos_type,
            "conv_stem": conv_stem,
            "arch": "vit",
        }
        if conv_stem:
            self.stem_conv1 = nn.Conv1d(1, 16, kernel_size=7, padding=3)
            self.stem_conv2 = nn.Conv1d(16, 32, kernel_size=5, padding=2)
            patch_in = 32 * patch_size
        else:
            patch_in = patch_size
        self.patch_embed = nn.Linear(patch_in, d_model)
        if use_lead_emb:
            self.lead_emb = nn.Embedding(n_leads, d_model)

        if pos_type == "sinusoidal":
            pe = torch.zeros(max_seq_len, d_model)
            position = torch.arange(0, max_seq_len, dtype=torch.float).unsqueeze(1)
            div_term = torch.exp(torch.arange(0, d_model, 2, dtype=torch.float)
                                  * (-math.log(10000.0) / d_model))
            pe[:, 0::2] = torch.sin(position * div_term)
            pe[:, 1::2] = torch.cos(position * div_term)
            self.register_buffer("pos_enc", pe.unsqueeze(0))
        elif pos_type == "learnable":
            self.pos_enc = nn.Parameter(torch.zeros(1, max_seq_len, d_model))
            nn.init.normal_(self.pos_enc, std=0.02)
        elif pos_type == "none":
            self.pos_enc = None
        else:
            raise ValueError(f"unknown pos_type: {pos_type}")

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=ff,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.head = nn.Linear(d_model, n_classes)

    def forward(self, x, lead_id):
        B, N = x.shape  # N=2500
        assert N % self.patch_size == 0, f"signal length {N} not divisible by patch {self.patch_size}"
        n_patches = N // self.patch_size  # 500
        if self.conv_stem:
            h = torch.nn.functional.gelu(self.stem_conv1(x.unsqueeze(1)))
            h = torch.nn.functional.gelu(self.stem_conv2(h))  # [B, 32, N]
            # Reshape into patches: [B, n_patches, 32 * patch_size]
            h = h.transpose(1, 2)  # [B, N, 32]
            patches = h.reshape(B, n_patches, self.patch_size * 32)
        else:
            patches = x.view(B, n_patches, self.patch_size)
        h = self.patch_embed(patches)  # [B, n_patches, d_model]
        if self.pos_enc is not None:
            h = h + self.pos_enc[:, :n_patches]
        if self.use_lead_emb:
            h = h + self.lead_emb(lead_id).unsqueeze(1)
        h = self.transformer(h)
        return self.head(h)


class FrameClassifierViTReg(FrameClassifierViT):
    """ViT backbone with parallel classification + boundary-regression heads.

    Forward returns (cls_logits[B, N_patches, n_classes],
                     reg_offsets[B, N_patches, n_reg]).
    n_reg defaults to 6: signed sample-offset to nearest GT boundary of each of
    {p_on, p_off, qrs_on, qrs_off, t_on, t_off}.
    """

    def __init__(self, n_reg=6, **kwargs):
        super().__init__(**kwargs)
        self.n_reg = int(n_reg)
        self.reg_head = nn.Linear(self.head.in_features, self.n_reg)
        self.model_config = dict(self.model_config)
        self.model_config["n_reg"] = self.n_reg
        self.model_config["arch"] = "vit_reg"

    def forward(self, x, lead_id):
        B, N = x.shape
        n_patches = N // self.patch_size
        if self.conv_stem:
            h = torch.nn.functional.gelu(self.stem_conv1(x.unsqueeze(1)))
            h = torch.nn.functional.gelu(self.stem_conv2(h))
            h = h.transpose(1, 2)
            patches = h.reshape(B, n_patches, self.patch_size * 32)
        else:
            patches = x.view(B, n_patches, self.patch_size)
        h = self.patch_embed(patches)
        if self.pos_enc is not None:
            h = h + self.pos_enc[:, :n_patches]
        if self.use_lead_emb:
            h = h + self.lead_emb(lead_id).unsqueeze(1)
        h = self.transformer(h)
        cls_logits = self.head(h)
        reg_offsets = self.reg_head(h)
        return cls_logits, reg_offsets


class FrameClassifierViTRegAux(FrameClassifierViTReg):
    """v13 Phase 1 / v16: ViT backbone with an auxiliary head tapped at an
    intermediate transformer layer.

    Splits the transformer into a lower stack (default 4 layers) and an upper
    stack (remaining layers). The aux head supervises the lower stack
    directly — turning the clinical workflow ("first identify QRS, then
    locate P/T relative to it") into an architectural inductive bias.

    `aux_target` controls what the lower stack is forced to commit to:
      * ``"all"`` (default, v13/v15 behaviour) — full 4-class supervision.
        The aux head is essentially deep supervision; the lower stack ends
        up learning the same task as the main head, just earlier.
      * ``"qrs_binary"`` (v16) — 2-class (QRS vs rest). The lower stack must
        commit to "is this frame inside a QRS?" *without* having to also
        decide P / T. This is the strict reading of the README's claim
        that aux is "QRS-aware".
      * ``"p_binary"`` — 2-class (P vs rest). Symmetric counterpart for
        atrial-activity-first hierarchies.

    For v15-style concat (FrameClassifierViTRegAuxConcat), the aux output
    dim flows into the upper stack's input projection, so changing
    `aux_target` also changes the projection's input width.

    Forward returns
        cls_logits  [B, n_patches, n_classes]        (final 4-class output)
        reg_offsets [B, n_patches, n_reg]            (boundary regression)
        aux_logits  [B, n_patches, aux_n_classes]    (intermediate output)
    """

    AUX_TARGETS = ("all", "qrs_binary", "p_binary")

    def __init__(self, aux_layer_split: int = 4, aux_target: str = "all", **kwargs):
        super().__init__(**kwargs)
        if aux_target not in self.AUX_TARGETS:
            raise ValueError(
                f"aux_target must be one of {self.AUX_TARGETS}, got {aux_target!r}"
            )
        d_model = self.model_config["d_model"]
        n_heads = self.model_config["n_heads"]
        ff = self.model_config["ff"]
        dropout = self.model_config["dropout"]
        n_total = self.model_config["n_layers"]
        n_main_classes = self.model_config["n_classes"]
        n_lower = int(aux_layer_split)
        n_upper = n_total - n_lower
        if not (0 < n_lower < n_total):
            raise ValueError(
                f"aux_layer_split={aux_layer_split} must be in (0, {n_total})"
            )

        def _make_stack(n: int) -> nn.TransformerEncoder:
            layer = nn.TransformerEncoderLayer(
                d_model=d_model, nhead=n_heads, dim_feedforward=ff,
                dropout=dropout, activation="gelu",
                batch_first=True, norm_first=True,
            )
            return nn.TransformerEncoder(layer, num_layers=n)

        self.lower_transformer = _make_stack(n_lower)
        self.upper_transformer = _make_stack(n_upper)
        del self.transformer
        aux_n_classes = n_main_classes if aux_target == "all" else 2
        self.aux_target = aux_target
        self.aux_n_classes = aux_n_classes
        self.aux_head = nn.Linear(d_model, aux_n_classes)
        self.model_config = dict(self.model_config)
        self.model_config["arch"] = "vit_reg_aux"
        self.model_config["aux_layer_split"] = n_lower
        self.model_config["aux_target"] = aux_target

    def forward(self, x, lead_id):
        B, N = x.shape
        n_patches = N // self.patch_size
        if self.conv_stem:
            h = torch.nn.functional.gelu(self.stem_conv1(x.unsqueeze(1)))
            h = torch.nn.functional.gelu(self.stem_conv2(h))
            h = h.transpose(1, 2)
            patches = h.reshape(B, n_patches, self.patch_size * 32)
        else:
            patches = x.view(B, n_patches, self.patch_size)
        h = self.patch_embed(patches)
        if self.pos_enc is not None:
            h = h + self.pos_enc[:, :n_patches]
        if self.use_lead_emb:
            h = h + self.lead_emb(lead_id).unsqueeze(1)
        h_lower = self.lower_transformer(h)
        aux_logits = self.aux_head(h_lower)
        h_upper = self.upper_transformer(h_lower)
        cls_logits = self.head(h_upper)
        reg_offsets = self.reg_head(h_upper)
        return cls_logits, reg_offsets, aux_logits


class FrameClassifierViTRegAuxConcat(FrameClassifierViTRegAux):
    """v15 Phase 2: aux output is fed forward into the upper transformer
    input via a learned projection.

    The aux head's QRS-aware logits (after softmax) are concatenated with
    the lower-stack features and projected back to d_model before entering
    the upper stack. The upper stack's attention can therefore use the
    explicit QRS-confidence channel as input — the architectural form of
    the clinical "find paced/wide QRS near where a QRS already is" hint.

    Forward returns (cls_logits, reg_offsets, aux_logits) just like the
    parent so existing trainers / inference helpers stay compatible.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        d_model = self.model_config["d_model"]
        # aux_n_classes is set by parent based on aux_target; binary aux
        # heads project a 2-D channel into the upper stack instead of 4.
        self.aux_to_upper_proj = nn.Linear(d_model + self.aux_n_classes, d_model)
        self.model_config = dict(self.model_config)
        self.model_config["arch"] = "vit_reg_aux_concat"

    def forward(self, x, lead_id):
        B, N = x.shape
        n_patches = N // self.patch_size
        if self.conv_stem:
            h = torch.nn.functional.gelu(self.stem_conv1(x.unsqueeze(1)))
            h = torch.nn.functional.gelu(self.stem_conv2(h))
            h = h.transpose(1, 2)
            patches = h.reshape(B, n_patches, self.patch_size * 32)
        else:
            patches = x.view(B, n_patches, self.patch_size)
        h = self.patch_embed(patches)
        if self.pos_enc is not None:
            h = h + self.pos_enc[:, :n_patches]
        if self.use_lead_emb:
            h = h + self.lead_emb(lead_id).unsqueeze(1)
        h_lower = self.lower_transformer(h)
        aux_logits = self.aux_head(h_lower)
        aux_probs = torch.softmax(aux_logits, dim=-1)
        h_upper_in = self.aux_to_upper_proj(torch.cat([h_lower, aux_probs], dim=-1))
        h_upper = self.upper_transformer(h_upper_in)
        cls_logits = self.head(h_upper)
        reg_offsets = self.reg_head(h_upper)
        return cls_logits, reg_offsets, aux_logits


class FrameClassifierViTRegMultiTask(FrameClassifierViTRegAuxConcat):
    """v17: v16 (QRS-binary aux + concat) augmented with window-level
    multi-task heads on top of the upper transformer features.

    Two backbone heads are always present (the divide-and-conquer pivots):
      * `rr_regular`  binary  — is the RR pattern regular?
      * `qrs_wide`    binary  — is the typical QRS ≥ 120 ms?

    Optional richer heads (off by default; enable with non-zero kwargs):
      * `rhythm` (n_rhythm_classes) — 3-class sinus / AF / other.
      * `avb`    (n_avb_classes)    — 4-class none / 1° / 2° / 3°.

    Each window-level head is a Linear over the time-mean of the upper
    transformer output (one prediction per 10 s window). Forward returns
    a 4-tuple (cls_logits, reg_offsets, aux_logits, window_logits) where
    `window_logits` is a dict keyed by task name; tasks with disabled
    heads are absent from the dict. Inference helpers that only read
    `out[:2]` (e.g. predict_frames_with_reg) keep working unchanged.
    """

    def __init__(self, n_rhythm_classes: int = 0, n_avb_classes: int = 0,
                 **kwargs):
        super().__init__(**kwargs)
        d = self.model_config["d_model"]
        self.head_rr_regular = nn.Linear(d, 2)
        self.head_qrs_wide = nn.Linear(d, 2)
        self.n_rhythm_classes = int(n_rhythm_classes)
        self.n_avb_classes = int(n_avb_classes)
        self.head_rhythm = (nn.Linear(d, self.n_rhythm_classes)
                            if self.n_rhythm_classes > 0 else None)
        self.head_avb = (nn.Linear(d, self.n_avb_classes)
                         if self.n_avb_classes > 0 else None)
        self.model_config = dict(self.model_config)
        self.model_config["arch"] = "vit_reg_multitask"
        self.model_config["n_rhythm_classes"] = self.n_rhythm_classes
        self.model_config["n_avb_classes"] = self.n_avb_classes

    def forward(self, x, lead_id):
        B, N = x.shape
        n_patches = N // self.patch_size
        if self.conv_stem:
            h = torch.nn.functional.gelu(self.stem_conv1(x.unsqueeze(1)))
            h = torch.nn.functional.gelu(self.stem_conv2(h))
            h = h.transpose(1, 2)
            patches = h.reshape(B, n_patches, self.patch_size * 32)
        else:
            patches = x.view(B, n_patches, self.patch_size)
        h = self.patch_embed(patches)
        if self.pos_enc is not None:
            h = h + self.pos_enc[:, :n_patches]
        if self.use_lead_emb:
            h = h + self.lead_emb(lead_id).unsqueeze(1)
        h_lower = self.lower_transformer(h)
        aux_logits = self.aux_head(h_lower)
        aux_probs = torch.softmax(aux_logits, dim=-1)
        h_upper_in = self.aux_to_upper_proj(torch.cat([h_lower, aux_probs], dim=-1))
        h_upper = self.upper_transformer(h_upper_in)
        cls_logits = self.head(h_upper)
        reg_offsets = self.reg_head(h_upper)
        h_window = h_upper.mean(dim=1)                     # [B, d_model]
        window_logits: dict[str, torch.Tensor] = {
            "rr_regular": self.head_rr_regular(h_window),  # [B, 2]
            "qrs_wide":   self.head_qrs_wide(h_window),    # [B, 2]
        }
        if self.head_rhythm is not None:
            window_logits["rhythm"] = self.head_rhythm(h_window)
        if self.head_avb is not None:
            window_logits["avb"] = self.head_avb(h_window)
        return cls_logits, reg_offsets, aux_logits, window_logits


class FrameClassifierViTRegMultiIn(FrameClassifierViTReg):
    """v22 input-channel-prior model.

    Identical to FrameClassifierViTReg except the ECG-sample input is
    extended from 1 channel to ``n_input_channels`` channels (signal +
    rule-based priors such as pacer slope and QRS-position indicator).
    The ViT patch embedding layer's input dimension is widened from
    ``patch_size`` to ``n_input_channels * patch_size`` (or the conv-stem
    first conv is widened from 1 to ``n_input_channels`` input channels).

    Forward expects ``x`` of shape [B, C, T] where C == n_input_channels.
    Returns the same (cls_logits, reg_offsets) tuple as the parent so
    downstream training and eval helpers stay compatible.
    """

    def __init__(self, n_input_channels: int = 2, **kwargs):
        super().__init__(**kwargs)
        self.n_input_channels = int(n_input_channels)
        if self.n_input_channels < 1:
            raise ValueError("n_input_channels must be >= 1")
        if self.n_input_channels != 1:
            patch_size = self.model_config["patch_size"]
            d_model = self.model_config["d_model"]
            if self.conv_stem:
                old = self.stem_conv1
                new = nn.Conv1d(
                    in_channels=self.n_input_channels,
                    out_channels=old.out_channels,
                    kernel_size=old.kernel_size[0],
                    padding=old.padding[0],
                )
                self.stem_conv1 = new
            else:
                self.patch_embed = nn.Linear(
                    self.n_input_channels * patch_size, d_model,
                )
        self.model_config = dict(self.model_config)
        self.model_config["arch"] = "vit_reg_multiin"
        self.model_config["n_input_channels"] = self.n_input_channels

    def forward(self, x, lead_id):
        if x.dim() == 2:
            # Backward compat path: [B, T] treated as 1-channel input.
            if self.n_input_channels != 1:
                raise ValueError(
                    f"model has n_input_channels={self.n_input_channels} but received "
                    f"x with shape {tuple(x.shape)} (no channel dim)"
                )
            x = x.unsqueeze(1)                              # [B, 1, T]
        elif x.dim() != 3:
            raise ValueError(f"expected 2D or 3D input, got shape {tuple(x.shape)}")
        B, C, T = x.shape
        if C != self.n_input_channels:
            raise ValueError(
                f"got C={C} but model has n_input_channels={self.n_input_channels}"
            )
        n_patches = T // self.patch_size
        if self.conv_stem:
            h = torch.nn.functional.gelu(self.stem_conv1(x))
            h = torch.nn.functional.gelu(self.stem_conv2(h))   # [B, 32, T]
            h = h.transpose(1, 2)
            patches = h.reshape(B, n_patches, self.patch_size * 32)
        else:
            # Each patch concatenates ``patch_size`` samples across all channels.
            x_p = x.reshape(B, C, n_patches, self.patch_size).transpose(1, 2)
            patches = x_p.reshape(B, n_patches, C * self.patch_size)
        h = self.patch_embed(patches)
        if self.pos_enc is not None:
            h = h + self.pos_enc[:, :n_patches]
        if self.use_lead_emb:
            h = h + self.lead_emb(lead_id).unsqueeze(1)
        h = self.transformer(h)
        cls_logits = self.head(h)
        reg_offsets = self.reg_head(h)
        return cls_logits, reg_offsets


_ARCH_REGISTRY: dict[str, type[nn.Module]] = {
    "frame_classifier":   FrameClassifier,
    "vit":                FrameClassifierViT,
    "vit_reg":            FrameClassifierViTReg,
    "vit_reg_aux":        FrameClassifierViTRegAux,
    "vit_reg_aux_concat": FrameClassifierViTRegAuxConcat,
    "vit_reg_multitask":  FrameClassifierViTRegMultiTask,
    "vit_reg_multiin":    FrameClassifierViTRegMultiIn,
}


def load_model_from_ckpt(ckpt_path, device: str = "cpu") -> tuple[nn.Module, dict]:
    """Construct the matching FrameClassifier* variant from a saved checkpoint.

    Reads `model_config['arch']` to dispatch to the correct class. Returns
    (model, blob) where blob is the full checkpoint dict so callers can
    inspect metrics/extra without reloading.

    Old FrameClassifier checkpoints (no `arch` field) are dispatched via
    presence of `lead_emb`/conv keys.
    """
    from openecg.stage2.train import load_checkpoint_blob
    blob = load_checkpoint_blob(Path(ckpt_path))
    cfg = dict(blob.get("model_config") or {})
    arch = cfg.pop("arch", "frame_classifier")
    if arch not in _ARCH_REGISTRY:
        raise ValueError(
            f"Unknown arch '{arch}' in {ckpt_path}; "
            f"known: {sorted(_ARCH_REGISTRY)}"
        )
    cls = _ARCH_REGISTRY[arch]
    model = cls(**cfg)
    model.load_state_dict(blob["model_state"])
    model = model.to(device).train(False)
    return model, blob
