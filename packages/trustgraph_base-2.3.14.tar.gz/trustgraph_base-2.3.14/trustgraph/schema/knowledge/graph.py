from dataclasses import dataclass, field

from ..core.primitives import Term, Triple
from ..core.metadata import Metadata

############################################################################

# Entity context are an entity associated with textual context

@dataclass
class EntityContext:
    entity: Term | None = None
    context: str = ""
    # Provenance: which chunk this entity context was derived from
    chunk_id: str = ""

# This is a 'batching' mechanism for the above data
@dataclass
class EntityContexts:
    metadata: Metadata | None = None
    entities: list[EntityContext] = field(default_factory=list)

############################################################################

# Graph triples

@dataclass
class Triples:
    metadata: Metadata | None = None
    triples: list[Triple] = field(default_factory=list)

############################################################################
