# update-version.ps1
# Syncs version strings across README.md from Cargo.toml source of truth

$VERSION = (Select-String -Path "Cargo.toml" -Pattern '^version\s*=\s*"([^"]+)"').Matches.Groups[1].Value

if (-not $VERSION) {
    Write-Error "Could not extract version from Cargo.toml"
    exit 1
}

Write-Host "Found version: $VERSION"

# Update README.md — replace any vX.Y.Z pattern
$readme = Get-Content README.md -Raw
$readme = $readme -replace "v\d+\.\d+\.\d+", "v$VERSION"

# Also catch "SDK for Phoenix vX.Y.Z" specifically if different format
$readme = $readme -replace "SDK for Phoenix v\d+\.\d+\.\d+", "SDK for Phoenix v$VERSION"

Set-Content README.md $readme -NoNewline
Write-Host "Updated README.md to v$VERSION"