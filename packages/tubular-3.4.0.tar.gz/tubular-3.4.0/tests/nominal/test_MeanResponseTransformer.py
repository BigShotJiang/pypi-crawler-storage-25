from copy import deepcopy
from itertools import product

import narwhals as nw
import numpy as np
import polars as pl
import pytest
from beartype.roar import BeartypeCallHintParamViolation
from sklearn.exceptions import NotFittedError
from sklearn.pipeline import Pipeline

from tests.base_tests import (
    ColumnStrListInitTests,
    DummyWeightColumnMixinTests,
    EmptyColumnsFitTransformPassTests,
    GenericFitTests,
    GenericTransformTests,
    OtherBaseBehaviourTests,
    WeightColumnFitMixinTests,
    WeightColumnInitMixinTests,
)
from tests.utils import (
    _check_if_skip_test,
    _collect_frame,
    _convert_to_lazy,
    _handle_from_json,
    assert_frame_equal_dispatch,
    dataframe_init_dispatch,
)
from tubular.mapping import BaseMappingTransformer
from tubular.nominal import MeanResponseTransformer


# Dataframe used exclusively in this testing script
def create_MeanResponseTransformer_test_df(library="pandas"):
    """Create DataFrame to use MeanResponseTransformer tests that correct values are.

    DataFrame column a is the response, the other columns are categorical columns
    of types; object, category, int, float, bool.

    """
    df_dict = {
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        "b": ["a", "b", "c", "d", "e", "f"],
        "c": ["a", "b", "c", "d", "e", "f"],
        "d": [1, 2, 3, 4, 5, 6],
        "e": [1, 2, 3, 4, 5, 6],
        "f": [False, False, False, True, True, True],
        "multi_level_response": [
            "blue",
            "blue",
            "yellow",
            "yellow",
            "green",
            "green",
        ],
    }

    df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)

    df = nw.from_native(df)
    df = df.with_columns(nw.col("c").cast(nw.Categorical))

    return df.to_native()


# Dataframe used exclusively in this testing script
def create_MeanResponseTransformer_test_df_unseen_levels(library="pandas"):
    """Create DataFrame to use in MeanResponseTransformer tests that check correct values are
    generated when using transform method on data with unseen levels.
    DataFrame column a is the response, the other columns are categorical columns
    of types; object, category, int, float, bool.

    """
    df_dict = {
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 3.0],
        "b": ["a", "b", "c", "d", "e", "f", "g", "h"],
        "c": ["a", "b", "c", "d", "e", "f", "g", "h"],
        "d": [1, 2, 3, 4, 5, 6, 7, 8],
        "e": [1, 2, 3, 4, 5, 6, 7, 8],
        "f": [False, False, False, True, True, True, True, False],
        "multi_level_response": [
            "blue",
            "blue",
            "yellow",
            "yellow",
            "green",
            "green",
            "yellow",
            "blue",
        ],
    }

    df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)
    df = nw.from_native(df)
    df = df.with_columns(nw.col("c").cast(nw.Categorical))

    return df.to_native()


@pytest.fixture
def learnt_mapping_dict():
    full_dict = {}

    b_dict = {
        "b": {"a": 1.0, "b": 2.0, "c": 3.0, "d": 4.0, "e": 5.0, "f": 6.0},
        "b_blue": {"a": 1.0, "b": 1.0, "c": 0.0, "d": 0.0, "e": 0.0, "f": 0.0},
        "b_yellow": {"a": 0.0, "b": 0.0, "c": 1.0, "d": 1.0, "e": 0.0, "f": 0.0},
        "b_green": {"a": 0.0, "b": 0.0, "c": 0.0, "d": 0.0, "e": 1.0, "f": 1.0},
    }

    # c matches b, but is categorical (see create_MeanResponseTransformer_test_df)
    c_dict = {
        "c" + suffix: b_dict["b" + suffix]
        for suffix in ["", "_blue", "_yellow", "_green"]
    }

    full_dict.update(b_dict)
    full_dict.update(c_dict)

    return full_dict


@pytest.fixture
def learnt_unseen_levels_encoding_dict_mean():
    return {
        "b": (1.0 + 2.0 + 3.0 + 4.0 + 5.0 + 6.0) / 6,
        "b_blue": (1.0 + 1.0 + 0.0 + 0.0 + 0.0 + 0.0) / 6,
        "b_yellow": (0.0 + 0.0 + 1.0 + 1.0 + 0.0 + 0.0) / 6,
        "b_green": (0.0 + 0.0 + 0.0 + 0.0 + 1.0 + 1.0) / 6,
    }


@pytest.fixture
def learnt_unseen_levels_encoding_dict_median():
    return {
        "b": 3.0,
        "b_blue": 0.0,
        "b_yellow": 0.0,
        "b_green": 0.0,
    }


@pytest.fixture
def learnt_unseen_levels_encoding_dict_highest():
    return {
        "b": 6.0,
        "b_blue": 1.0,
        "b_yellow": 1.0,
        "b_green": 1.0,
    }


@pytest.fixture
def learnt_unseen_levels_encoding_dict_lowest():
    return {
        "b": 1.0,
        "b_blue": 0.0,
        "b_yellow": 0.0,
        "b_green": 0.0,
    }


@pytest.fixture
def learnt_unseen_levels_encoding_dict_arbitrary():
    return {
        "b": 22.0,
        "b_blue": 22.0,
        "b_yellow": 22.0,
        "b_green": 22.0,
    }


class TestInit(ColumnStrListInitTests, WeightColumnInitMixinTests):
    """Tests for MeanResponseTransformer.init()."""

    @classmethod
    def setup_class(cls):
        cls.transformer_name = "MeanResponseTransformer"

    # overload inherited arg tests that have been replaced by beartype

    def test_weight_arg_errors(self):
        pass

    def test_prior_not_positive_int_error(self):
        """Test that an exception is raised if prior is not a positive int."""
        with pytest.raises(BeartypeCallHintParamViolation):
            MeanResponseTransformer(prior=-1)


class TestFit(GenericFitTests, WeightColumnFitMixinTests, DummyWeightColumnMixinTests):
    @classmethod
    def setup_class(cls):
        cls.transformer_name = "MeanResponseTransformer"

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    def test_weights_column_missing_error(self, library, lazy):
        """Test that an exception is raised if weights_column is specified but not present in data for fit."""
        df = create_MeanResponseTransformer_test_df(library=library)

        x = MeanResponseTransformer(weights_column="z", columns=["b", "d", "f"])

        if _check_if_skip_test(x, df, lazy=lazy):
            return

        with pytest.raises(
            ValueError,
            match=r"weight col \(z\) is not present in columns of data",
        ):
            x.fit(
                _convert_to_lazy(df, lazy=lazy),
                df["a"],
            )

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    @pytest.mark.parametrize(
        ("level", "target_column", "unseen_level_handling"),
        [
            (None, "a", "mean"),
            ("all", "multi_level_response", 32),
            (["yellow", "blue"], "multi_level_response", "max"),
        ],
    )
    def test_response_column_nulls_error(
        self,
        level,
        target_column,
        unseen_level_handling,
        library,
        lazy,
    ):
        """Test that an exception is raised if nulls are present in response_column."""
        df = create_MeanResponseTransformer_test_df(library=library)

        df = nw.from_native(df)
        df = df.with_columns(
            nw.new_series(
                name=target_column,
                values=[*[1.0] * (len(df) - 1), None],
                backend=library,
            ),
        )
        df = nw.to_native(df)

        x = MeanResponseTransformer(
            columns=["b"],
            level=level,
            unseen_level_handling=unseen_level_handling,
        )

        if _check_if_skip_test(x, df, lazy=lazy):
            return

        with pytest.raises(
            ValueError,
            match="MeanResponseTransformer: y has 1 null values",
        ):
            x.fit(_convert_to_lazy(df, lazy=lazy), df[target_column])

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    @pytest.mark.parametrize(
        ("level", "target_column", "unseen_level_handling"),
        [
            (None, "a", "mean"),
            (None, "a", "min"),
        ],
    )
    def test_correct_mappings_stored_numeric_response(
        self,
        learnt_mapping_dict,
        level,
        target_column,
        unseen_level_handling,
        library,
        lazy,
    ):
        "Test that the mapping dictionary created in fit has the correct keys and values."
        df = create_MeanResponseTransformer_test_df(library=library)
        columns = ["b", "c"]
        x = MeanResponseTransformer(
            columns=columns,
            level=level,
            unseen_level_handling=unseen_level_handling,
        )

        if _check_if_skip_test(x, df, lazy=lazy):
            return

        x.fit(_convert_to_lazy(df, lazy=lazy), df[target_column])

        assert x.columns == columns, "Columns attribute changed in fit"

        for column in x.columns:
            actual = x.mappings[column]
            expected = learnt_mapping_dict[column]
            assert actual == expected

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    @pytest.mark.parametrize(
        ("level", "target_column", "unseen_level_handling"),
        [
            (["blue"], "multi_level_response", "median"),
            ("all", "multi_level_response", 32),
            (["yellow", "blue"], "multi_level_response", "max"),
        ],
    )
    def test_correct_mappings_stored_categorical_response(
        self,
        learnt_mapping_dict,
        level,
        target_column,
        unseen_level_handling,
        library,
        lazy,
    ):
        "Test that the mapping dictionary created in fit has the correct keys and values."
        df = create_MeanResponseTransformer_test_df(library=library)
        columns = ["b", "c"]
        x = MeanResponseTransformer(
            columns=columns,
            level=level,
            unseen_level_handling=unseen_level_handling,
        )

        if _check_if_skip_test(x, df, lazy=lazy):
            return

        x.fit(_convert_to_lazy(df, lazy=lazy), df[target_column])

        df = nw.from_native(df)

        if level == "all":
            expected_created_cols = {
                prefix + "_" + suffix
                for prefix, suffix in product(
                    columns,
                    df[target_column].unique().to_list(),
                )
            }

        else:
            expected_created_cols = {
                prefix + "_" + suffix for prefix, suffix in product(columns, level)
            }
        assert set(x.encoded_columns) == expected_created_cols, (
            "Stored encoded columns are not as expected"
        )

        for column in x.encoded_columns:
            actual = x.mappings[column]
            expected = learnt_mapping_dict[column]
            assert actual == expected

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    @pytest.mark.parametrize(
        ("level", "target_column", "unseen_level_handling"),
        [
            (None, "a", "mean"),
            (None, "a", "median"),
            (None, "a", "min"),
            (None, "a", "max"),
            (None, "a", 22.0),
            ("all", "multi_level_response", "mean"),
            (["yellow", "blue"], "multi_level_response", "mean"),
        ],
    )
    def test_correct_unseen_levels_encoding_dict_stored(  # noqa: PLR0912
        self,
        learnt_unseen_levels_encoding_dict_mean,
        learnt_unseen_levels_encoding_dict_median,
        learnt_unseen_levels_encoding_dict_lowest,
        learnt_unseen_levels_encoding_dict_highest,
        learnt_unseen_levels_encoding_dict_arbitrary,
        level,
        target_column,
        unseen_level_handling,
        library,
        lazy,
    ):
        "Test that the unseen_levels_encoding_dict dictionary created in fit has the correct keys and values."
        df = create_MeanResponseTransformer_test_df(library=library)
        x = MeanResponseTransformer(
            columns=["b"],
            level=level,
            unseen_level_handling=unseen_level_handling,
        )

        if _check_if_skip_test(x, df, lazy=lazy):
            return

        x.fit(_convert_to_lazy(df, lazy=lazy), df[target_column])

        if level:
            if level == "all":
                assert set(x.unseen_levels_encoding_dict.keys()) == {
                    "b_blue",
                    "b_yellow",
                    "b_green",
                }, "Stored unseen_levels_encoding_dict keys are not as expected"

            else:
                assert set(x.unseen_levels_encoding_dict.keys()) == {
                    "b_blue",
                    "b_yellow",
                }, "Stored unseen_levels_encoding_dict keys are not as expected"

            for column in x.unseen_levels_encoding_dict:
                actual = x.unseen_levels_encoding_dict[column]
                expected = learnt_unseen_levels_encoding_dict_mean[column]
                assert actual == expected

        else:
            assert x.unseen_levels_encoding_dict.keys() == {
                "b",
            }, "Stored unseen_levels_encoding_dict key is not as expected"

            if unseen_level_handling == "mean":
                for column in x.unseen_levels_encoding_dict:
                    actual = x.unseen_levels_encoding_dict[column]
                    expected = learnt_unseen_levels_encoding_dict_mean[column]
                    assert actual == expected

            elif unseen_level_handling == "median":
                for column in x.unseen_levels_encoding_dict:
                    actual = x.unseen_levels_encoding_dict[column]
                    expected = learnt_unseen_levels_encoding_dict_median[column]
                    assert actual == expected

            elif unseen_level_handling == "min":
                for column in x.unseen_levels_encoding_dict:
                    actual = x.unseen_levels_encoding_dict[column]
                    expected = learnt_unseen_levels_encoding_dict_lowest[column]
                    assert actual == expected

            elif unseen_level_handling == "max":
                for column in x.unseen_levels_encoding_dict:
                    actual = x.unseen_levels_encoding_dict[column]
                    expected = learnt_unseen_levels_encoding_dict_highest[column]
                    assert actual == expected

            else:
                for column in x.unseen_levels_encoding_dict:
                    actual = x.unseen_levels_encoding_dict[column]
                    expected = learnt_unseen_levels_encoding_dict_arbitrary[column]
                    assert actual == expected

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    def test_missing_categories_ignored(self, library, lazy):
        "test that where a categorical column has missing levels, these do not make it into the encoding dict"

        df = create_MeanResponseTransformer_test_df(library=library)
        unobserved_value = "a"
        df = nw.from_native(df)
        df = df.filter(nw.col("c") == unobserved_value)
        df = nw.to_native(df)

        target_column = "e"
        x = MeanResponseTransformer(
            columns=["c"],
        )

        if _check_if_skip_test(x, df, lazy=lazy):
            return

        x.fit(_convert_to_lazy(df, lazy=lazy), df[target_column])

        assert unobserved_value not in x.mappings, (
            "MeanResponseTransformer should ignore unobserved levels"
        )

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    @pytest.mark.parametrize("with_invalid_weights", [True, False])
    @pytest.mark.parametrize(
        (
            "columns",
            "weights_values",
            "prior",
            "expected_mappings",
        ),
        [
            # no prior, no weight
            (
                ["b", "d", "f"],
                [1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
                0,
                {
                    "b": {"a": 1.0, "b": 2.0, "c": 3.0, "d": 4.0, "e": 5.0, "f": 6.0},
                    "d": {1: 1.0, 2: 2.0, 3: 3.0, 4: 4.0, 5: 5.0, 6: 6.0},
                    "f": {False: 2.0, True: 5.0},
                },
            ),
            # no weight, prior
            (
                ["b", "d", "f"],
                [1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
                5,
                {
                    "b": {
                        "a": 37 / 12,
                        "b": 13 / 4,
                        "c": 41 / 12,
                        "d": 43 / 12,
                        "e": 15 / 4,
                        "f": 47 / 12,
                    },
                    "d": {
                        1: 37 / 12,
                        2: 13 / 4,
                        3: 41 / 12,
                        4: 43 / 12,
                        5: 15 / 4,
                        6: 47 / 12,
                    },
                    "f": {False: 47 / 16, True: 65 / 16},
                },
            ),
            # weight, no prior
            (
                ["b", "d", "f"],
                [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
                0,
                {
                    "b": {"a": 1.0, "b": 2.0, "c": 3.0, "d": 4.0, "e": 5.0, "f": 6.0},
                    "d": {1: 1.0, 2: 2.0, 3: 3.0, 4: 4.0, 5: 5.0, 6: 6.0},
                    "f": {False: 14 / 6, True: 77 / 15},
                },
            ),
            # prior and weight
            (
                ["d", "f"],
                [1.0, 1.0, 1.0, 2.0, 2.0, 2.0],
                5,
                {
                    "d": {1: 7 / 2, 2: 11 / 3, 3: 23 / 6, 4: 4.0, 5: 30 / 7, 6: 32 / 7},
                    "f": {False: 13 / 4, True: 50 / 11},
                },
            ),
        ],
    )
    def test_learnt_values(
        self,
        library,
        columns,
        weights_values,
        prior,
        expected_mappings,
        with_invalid_weights,
        lazy,
    ):
        """Test that the mean response values learnt during fit are expected."""
        df_dict = {
            "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
            "b": ["a", "b", "c", "d", "e", "f"],
            "c": ["a", "b", "c", "d", "e", "f"],
            "d": [1, 2, 3, 4, 5, 6],
            "e": [1, 2, 3, 4, 5, 6],
            "f": [False, False, False, True, True, True],
            "multi_level_response": [
                "blue",
                "blue",
                "yellow",
                "yellow",
                "green",
                "green",
            ],
        }

        # use this argument to run the test again with
        # some extra rows which should just be filtered/have no
        # effect
        full_weights_values = deepcopy(
            weights_values
        )  # was having issues with fixture being overwritten
        if with_invalid_weights:
            extra_rows = {
                "a": [7.0, 8.0],
                "b": ["c", "b"],
                "c": ["d", "e"],
                "d": [1, 3],
                "e": [4, 5],
                "f": [False, True],
                "multi_level_response": ["yellow", "green"],
            }

            for key in df_dict:
                df_dict[key] += extra_rows[key]

            bad_weights = [-1, None]

            full_weights_values += bad_weights

        df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)

        df = nw.from_native(df)
        df = df.with_columns(nw.col("c").cast(nw.Categorical))

        df = nw.from_native(df)

        weights_column = "weights_column"
        df = df.with_columns(
            nw.new_series(
                name=weights_column, values=full_weights_values, backend=library
            ),
        ).to_native()

        x = MeanResponseTransformer(
            columns=columns,
            prior=prior,
            weights_column=weights_column,
        )

        if _check_if_skip_test(x, df, lazy=lazy):
            return

        x.mappings = {}

        x.fit(_convert_to_lazy(df, lazy=lazy), df["a"])

        assert x.mappings == expected_mappings, (
            f"mappings not learnt as expected, expected {expected_mappings} but got {x.mappings}"
        )


class TestFitBinaryResponse(GenericFitTests, WeightColumnFitMixinTests):
    """Tests for MeanResponseTransformer.fit()."""

    @classmethod
    def setup_class(cls):
        cls.transformer_name = "MeanResponseTransformer"

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    @pytest.mark.parametrize("prior", [1, 3, 5, 7, 9, 11, 100])
    def test_prior_logic(self, prior, library, lazy):
        "Test that for prior>0 encodings are closer to global mean than for prior=0."
        df = create_MeanResponseTransformer_test_df(library=library)

        df = nw.from_native(df)
        weights_column = "weights_column"
        native_backend = nw.get_native_namespace(df)
        df = df.with_columns(
            nw.new_series(
                name=weights_column,
                values=[1, 1, 1, 2, 2, 2],
                backend=native_backend.__name__,
            ),
        )

        x_prior = MeanResponseTransformer(
            columns=["d", "f"],
            prior=prior,
            weights_column=weights_column,
        )

        if _check_if_skip_test(x_prior, df, lazy=lazy):
            return

        x_no_prior = MeanResponseTransformer(
            columns=["d", "f"],
            prior=0,
            weights_column=weights_column,
        )

        x_prior.fit(_convert_to_lazy(df, lazy=lazy), df["a"])

        x_no_prior.fit(_convert_to_lazy(df, lazy=lazy), df["a"])

        prior_mappings = x_prior.mappings

        no_prior_mappings = x_no_prior.mappings

        global_mean = sum(df[weights_column] * df["a"]) / sum(df[weights_column])

        for col in prior_mappings:
            for value in prior_mappings[col]:
                prior_encoding = prior_mappings[col][value]
                no_prior_encoding = no_prior_mappings[col][value]

                prior_mean_dist = np.abs(prior_encoding - global_mean)
                no_prior_mean_dist = np.abs(no_prior_encoding - global_mean)

                assert prior_mean_dist <= no_prior_mean_dist, (
                    "encodings using priors should be closer to the global mean than without"
                )

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    @pytest.mark.parametrize(
        ("low_weight", "high_weight"),
        [(1, 2), (2, 3), (3, 4), (10, 20)],
    )
    def test_prior_logic_for_weights(self, low_weight, high_weight, library, lazy):
        "Test that for fixed prior a group with lower weight is moved closer to the global mean than one with higher weight."
        df = create_MeanResponseTransformer_test_df(library=library)

        df = nw.from_native(df)
        weights_column = "weights_column"
        native_backend = nw.get_native_namespace(df)

        # column f looks like [False, False, False, True, True, True]
        df = df.with_columns(
            nw.new_series(
                name=weights_column,
                values=[
                    low_weight,
                    low_weight,
                    low_weight,
                    high_weight,
                    high_weight,
                    high_weight,
                ],
                backend=native_backend.__name__,
            ),
        )

        x_prior = MeanResponseTransformer(
            columns=["f"],
            prior=5,
            weights_column=weights_column,
        )

        if _check_if_skip_test(x_prior, df, lazy=lazy):
            return

        x_no_prior = MeanResponseTransformer(
            columns=["f"],
            prior=0,
            weights_column=weights_column,
        )

        x_prior.fit(_convert_to_lazy(df, lazy=lazy), df["a"])

        x_no_prior.fit(_convert_to_lazy(df, lazy=lazy), df["a"])

        prior_mappings = x_prior.mappings

        no_prior_mappings = x_no_prior.mappings

        global_mean = sum(df["a"] * df[weights_column]) / sum(df[weights_column])

        low_weight_prior_encoding = prior_mappings["f"][False]
        high_weight_prior_encoding = prior_mappings["f"][True]

        low_weight_no_prior_encoding = no_prior_mappings["f"][False]
        high_weight_no_prior_encoding = no_prior_mappings["f"][True]

        low_weight_prior_mean_dist = np.abs(low_weight_prior_encoding - global_mean)
        high_weight_prior_mean_dist = np.abs(high_weight_prior_encoding - global_mean)

        low_weight_no_prior_mean_dist = np.abs(
            low_weight_no_prior_encoding - global_mean,
        )
        high_weight_no_prior_mean_dist = np.abs(
            high_weight_no_prior_encoding - global_mean,
        )

        # check low weight group has been moved further towards mean than high weight group by prior, i.e
        # that the distance remaining is a smaller proportion of the no prior distance
        low_ratio = low_weight_prior_mean_dist / low_weight_no_prior_mean_dist
        high_ratio = high_weight_prior_mean_dist / high_weight_no_prior_mean_dist
        assert low_ratio <= high_ratio, (
            "encodings for categories with lower weights should be moved closer to the global mean than those with higher weights, for fixed prior"
        )

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    @pytest.mark.parametrize("column_type", ["cat", "object", "default"])
    @pytest.mark.parametrize("prior", [3, 0])
    def test_simple_prior_cases(self, library, column_type, prior, lazy):
        "Test simple cases using prior logic (adapted from tests in old TestPriorRegularisation class)."

        column = "a"
        weights_column = "weight"
        x = MeanResponseTransformer(
            columns=column, weights_column=weights_column, prior=prior
        )

        column_values = ["a", "b"]
        target_values = [2, 3]
        weight_values = [1, 2]
        df_dict = {column: column_values, weights_column: weight_values}
        df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)

        if _check_if_skip_test(x, df, lazy=lazy):
            return

        y = nw.new_series(name="y", values=target_values, backend=library)

        if column_type == "cat":
            df = nw.from_native(df)
            df = df.with_columns(nw.col(column).cast(nw.Categorical))
            df = nw.to_native(df)
        elif column_type == "object" and library == "pandas":
            df["a"] = df["a"].astype("object")

        x.fit(X=_convert_to_lazy(df, lazy=lazy), y=y)

        global_mean = (
            (target_values[0] * weight_values[0])
            + (target_values[1] * weight_values[1])
        ) / sum(weight_values)

        # note, previously global mean was learnt during the fit
        # call above and used inside _prior_regularisation
        # now it is derived as an expression inside
        # _prior_regularisation
        # formula: (weight*value + prior*global_mean)/(weight + prior)
        expected1 = ((target_values[0] * weight_values[0]) + prior * (global_mean)) / (
            weight_values[0] + prior
        )

        expected2 = ((target_values[1] * weight_values[1]) + prior * (global_mean)) / (
            weight_values[1] + prior
        )

        expected = {column: {"a": expected1, "b": expected2}}

        output = x.mappings

        # polars doesn't guarantee complete precision, so will round
        # before assert
        # specify values here to fix dict order
        values = ["a", "b"]
        output = {
            col: {value: round(output[col][value], 2) for value in values}
            for col in output
        }

        assert output == expected, (
            f"output of _prior_regularisation not as expected, expected {expected} but got {output}"
        )


def expected_df_1(library="pandas"):
    """Expected output for single level response."""

    df_dict = {
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        "b": [1, 2, 3, 4, 5, 6],
        "c": ["a", "b", "c", "d", "e", "f"],
        "d": [1, 2, 3, 4, 5, 6],
        "e": [1, 2, 3, 4, 5, 6],
        "f": [2, 2, 2, 5, 5, 5],
        "multi_level_response": [
            "blue",
            "blue",
            "yellow",
            "yellow",
            "green",
            "green",
        ],
    }

    df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)

    df = nw.from_native(df)
    df = df.with_columns(nw.col("c").cast(nw.Categorical))

    return df.to_native()


def expected_df_2(library="pandas"):
    """Expected output for response with level = blue."""

    df_dict = {
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        "c": ["a", "b", "c", "d", "e", "f"],
        "d": [1, 2, 3, 4, 5, 6],
        "e": [1, 2, 3, 4, 5, 6],
        "multi_level_response": [
            "blue",
            "blue",
            "yellow",
            "yellow",
            "green",
            "green",
        ],
        "b_blue": [1, 1, 0, 0, 0, 0],
        "f_blue": [2 / 3, 2 / 3, 2 / 3, 0, 0, 0],
    }

    df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)

    df = nw.from_native(df)
    df = df.with_columns(nw.col("c").cast(nw.Categorical))

    return df.to_native()


def expected_df_3(library="pandas"):
    """Expected output for response with level = 'all'."""

    df_dict = {
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        "c": ["a", "b", "c", "d", "e", "f"],
        "d": [1, 2, 3, 4, 5, 6],
        "e": [1, 2, 3, 4, 5, 6],
        "multi_level_response": [
            "blue",
            "blue",
            "yellow",
            "yellow",
            "green",
            "green",
        ],
        "b_blue": [1, 1, 0, 0, 0, 0],
        "f_blue": [2 / 3, 2 / 3, 2 / 3, 0.0, 0.0, 0.0],
        "b_green": [0, 0, 0, 0, 1, 1],
        "f_green": [0.0, 0.0, 0.0, 2 / 3, 2 / 3, 2 / 3],
        "b_yellow": [0, 0, 1, 1, 0, 0],
        "f_yellow": [1 / 3, 1 / 3, 1 / 3, 1 / 3, 1 / 3, 1 / 3],
    }

    df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)

    df = nw.from_native(df)
    df = df.with_columns(nw.col("c").cast(nw.Categorical))

    return df.to_native()


def expected_df_4(library="pandas"):
    """Expected output for transform on dataframe with single level response and unseen levels,
    where unseen_level_handling = 'mean'.
    """
    df_dict = {
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 3.0],
        "b": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 3.5, 3.5],
        "c": ["a", "b", "c", "d", "e", "f", "g", "h"],
        "d": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 3.5, 3.5],
        "e": [1, 2, 3, 4, 5, 6, 7, 8],
        "f": [2.0, 2.0, 2.0, 5.0, 5.0, 5.0, 5.0, 2.0],
        "multi_level_response": [
            "blue",
            "blue",
            "yellow",
            "yellow",
            "green",
            "green",
            "yellow",
            "blue",
        ],
    }

    df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)
    df = nw.from_native(df)
    df = df.with_columns(nw.col("c").cast(nw.Categorical))

    return df.to_native()


def expected_df_5(library="pandas"):
    """Expected output for transform on dataframe with single level response and unseen levels,
    where unseen_level_handling = 'median'.
    """

    df_dict = {
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 3.0],
        "b": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 3.0, 3.0],
        "c": ["a", "b", "c", "d", "e", "f", "g", "h"],
        "d": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 3.0, 3.0],
        "e": [1, 2, 3, 4, 5, 6, 7, 8],
        "f": [2.0, 2.0, 2.0, 5.0, 5.0, 5.0, 5.0, 2.0],
        "multi_level_response": [
            "blue",
            "blue",
            "yellow",
            "yellow",
            "green",
            "green",
            "yellow",
            "blue",
        ],
    }

    df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)
    df = nw.from_native(df)
    df = df.with_columns(nw.col("c").cast(nw.Categorical))

    return df.to_native()


def expected_df_6(library="pandas"):
    """Expected output for transform on dataframe with single level response and unseen levels,
    where unseen_level_handling = 'min'.
    """
    df_dict = {
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 3.0],
        "b": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 1.0, 1.0],
        "c": ["a", "b", "c", "d", "e", "f", "g", "h"],
        "d": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 1.0, 1.0],
        "e": [1, 2, 3, 4, 5, 6, 7, 8],
        "f": [2.0, 2.0, 2.0, 5.0, 5.0, 5.0, 5.0, 2.0],
        "multi_level_response": [
            "blue",
            "blue",
            "yellow",
            "yellow",
            "green",
            "green",
            "yellow",
            "blue",
        ],
    }

    df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)
    df = nw.from_native(df)
    df = df.with_columns(nw.col("c").cast(nw.Categorical))

    return df.to_native()


def expected_df_7(library="pandas"):
    """Expected output for transform on dataframe with single level response and unseen levels,
    where unseen_level_handling = 'max'.
    """
    df_dict = {
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 3.0],
        "b": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 6.0, 6.0],
        "c": ["a", "b", "c", "d", "e", "f", "g", "h"],
        "d": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 6.0, 6.0],
        "e": [1, 2, 3, 4, 5, 6, 7, 8],
        "f": [2.0, 2.0, 2.0, 5.0, 5.0, 5.0, 5.0, 2.0],
        "multi_level_response": [
            "blue",
            "blue",
            "yellow",
            "yellow",
            "green",
            "green",
            "yellow",
            "blue",
        ],
    }

    df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)
    df = nw.from_native(df)
    df = df.with_columns(nw.col("c").cast(nw.Categorical))

    return df.to_native()


def expected_df_8(library="pandas"):
    """Expected output for transform on dataframe with single level response and unseen levels,
    where unseen_level_handling set to arbitrary int/float value.
    """
    df_dict = {
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 3.0],
        "b": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 21.6, 21.6],
        "c": ["a", "b", "c", "d", "e", "f", "g", "h"],
        "d": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 21.6, 21.6],
        "e": [1, 2, 3, 4, 5, 6, 7, 8],
        "f": [2.0, 2.0, 2.0, 5.0, 5.0, 5.0, 5.0, 2.0],
        "multi_level_response": [
            "blue",
            "blue",
            "yellow",
            "yellow",
            "green",
            "green",
            "yellow",
            "blue",
        ],
    }

    df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)
    df = nw.from_native(df)
    df = df.with_columns(nw.col("c").cast(nw.Categorical))

    return df.to_native()


def expected_df_9(library="pandas"):
    """Expected output for transform on dataframe with multi-level response with level = blue and unseen levels in data."""
    df_dict = {
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 3.0],
        "c": ["a", "b", "c", "d", "e", "f", "g", "h"],
        "d": [1, 2, 3, 4, 5, 6, 7, 8],
        "e": [1, 2, 3, 4, 5, 6, 7, 8],
        "multi_level_response": [
            "blue",
            "blue",
            "yellow",
            "yellow",
            "green",
            "green",
            "yellow",
            "blue",
        ],
        "b_blue": [1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 2 / 6, 2 / 6],
        "f_blue": [2 / 3, 2 / 3, 2 / 3, 0.0, 0.0, 0.0, 0, 2 / 3],
    }

    df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)
    df = nw.from_native(df)
    df = df.with_columns(nw.col("c").cast(nw.Categorical))

    return df.to_native()


def expected_df_10(library="pandas"):
    """Expected output for transform on dataframe with multi-level response with level = "all" and unseen levels in data."""
    df_dict = {
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 3.0],
        "c": ["a", "b", "c", "d", "e", "f", "g", "h"],
        "d": [1, 2, 3, 4, 5, 6, 7, 8],
        "e": [1, 2, 3, 4, 5, 6, 7, 8],
        "multi_level_response": [
            "blue",
            "blue",
            "yellow",
            "yellow",
            "green",
            "green",
            "yellow",
            "blue",
        ],
        "b_blue": [1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
        "f_blue": [2 / 3, 2 / 3, 2 / 3, 0, 0, 0, 0, 2 / 3],
        "b_yellow": [0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0],
        "f_yellow": [1 / 3, 1 / 3, 1 / 3, 1 / 3, 1 / 3, 1 / 3, 1 / 3, 1 / 3],
        "b_green": [0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0],
        "f_green": [0.0, 0.0, 0.0, 2 / 3, 2 / 3, 2 / 3, 2 / 3, 0],
    }

    df = dataframe_init_dispatch(dataframe_dict=df_dict, library=library)
    df = nw.from_native(df)
    df = df.with_columns(nw.col("c").cast(nw.Categorical))

    return df.to_native()


class TestTransform(GenericTransformTests):
    """Tests for MeanResponseTransformer.transform()."""

    @classmethod
    def setup_class(cls):
        cls.transformer_name = "MeanResponseTransformer"

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("from_json", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    @pytest.mark.parametrize(
        (
            "columns",
            "level",
            "mappings",
            "column_to_encoded_columns",
            "expected_getter",
        ),
        [
            # binary response
            (
                ["b", "d", "f"],
                None,
                {
                    "b": {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6},
                    "d": {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6},
                    "f": {False: 2, True: 5},
                },
                {"b": ["b"], "d": ["d"], "f": ["f"]},
                expected_df_1,
            ),
            # multi level, single level
            (
                ["b", "f"],
                ["blue"],
                {
                    "b_blue": {"a": 1, "b": 1, "c": 0, "d": 0, "e": 0, "f": 0},
                    "f_blue": {False: 2 / 3, True: 0.0},
                },
                {"b": ["b_blue"], "f": ["f_blue"]},
                expected_df_2,
            ),
            # multi level, all levels
            (
                ["b", "f"],
                "all",
                {
                    "b_blue": {"a": 1, "b": 1, "c": 0, "d": 0, "e": 0, "f": 0},
                    "b_yellow": {"a": 0, "b": 0, "c": 1, "d": 1, "e": 0, "f": 0},
                    "b_green": {"a": 0, "b": 0, "c": 0, "d": 0, "e": 1, "f": 1},
                    "f_blue": {False: 2 / 3, True: 0.0},
                    "f_yellow": {False: 1 / 3, True: 1 / 3},
                    "f_green": {False: 0.0, True: 2 / 3},
                },
                {
                    "b": ["b_blue", "b_yellow", "b_green"],
                    "f": ["f_blue", "f_yellow", "f_green"],
                },
                expected_df_3,
            ),
        ],
    )
    def test_expected_outputs(
        self,
        library,
        columns,
        level,
        mappings,
        column_to_encoded_columns,
        expected_getter,
        from_json,
        lazy,
    ):
        """Test that the output is expected from transform with various parametrized setups."""

        df = create_MeanResponseTransformer_test_df(library=library)
        expected = expected_getter(library=library)

        x = MeanResponseTransformer(columns=columns, level=level)

        if _check_if_skip_test(x, df, lazy=lazy, from_json=from_json):
            return

        # set the impute values dict directly rather than fitting x on df so test works with helpers
        x.mappings = mappings

        # mimic fit logics use of BaseMappingTransformer
        # use BaseMappingTransformer init to process args
        # extract null_mappings from mappings etc
        base_mapping_transformer = BaseMappingTransformer(
            mappings=mappings,
        )

        x.mappings = base_mapping_transformer.mappings
        x.mappings_from_null = base_mapping_transformer.mappings_from_null

        x.column_to_encoded_columns = column_to_encoded_columns
        x.response_levels = level
        x.encoded_columns = list(x.mappings.keys())
        x.return_dtypes = dict.fromkeys(x.encoded_columns, "Float32")

        x = _handle_from_json(x, from_json)

        df_transformed = x.transform(_convert_to_lazy(df, lazy=lazy))

        df_transformed = _collect_frame(df_transformed, lazy=lazy)

        expected = nw.from_native(expected)
        for col in x.encoded_columns:
            expected = expected.with_columns(
                nw.col(col).cast(getattr(nw, x.return_type)),
            )
        expected = nw.to_native(expected)

        column_order = nw.from_native(df_transformed).columns

        assert_frame_equal_dispatch(
            df_transformed,
            expected[column_order],
        )

        # also test single row transform
        df = nw.from_native(df)
        expected = nw.from_native(expected)

        for i in range(len(df)):
            df_transformed_row = x.transform(
                _convert_to_lazy(df[[i]].to_native(), lazy=lazy)
            )
            df_expected_row = expected[[i]].to_native()

            column_order = nw.from_native(df_transformed_row).columns

            assert_frame_equal_dispatch(
                _collect_frame(df_transformed_row, lazy=lazy),
                df_expected_row[column_order],
            )

    # NOTE - this currently is more of a Fit test imo, but will leave in place for now
    # as does also test Transform
    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("from_json", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    @pytest.mark.parametrize(
        ("columns", "target", "unseen_level_handling", "level", "expected_getter"),
        [
            (["b", "d", "f"], "a", "mean", None, expected_df_4),
            (["b", "d", "f"], "a", "median", None, expected_df_5),
            (["b", "d", "f"], "a", "min", None, expected_df_6),
            (["b", "d", "f"], "a", "max", None, expected_df_7),
            (["b", "d", "f"], "a", 21.6, None, expected_df_8),
            (["b", "f"], "multi_level_response", "mean", ["blue"], expected_df_9),
            (["b", "f"], "multi_level_response", "max", "all", expected_df_10),
        ],
    )
    def test_expected_outputs_with_unseen_level_handling(
        self,
        library,
        columns,
        target,
        unseen_level_handling,
        level,
        expected_getter,
        from_json,
        lazy,
    ):
        """Test that the output is expected from transform with various configs and unseen level handling"""

        df = create_MeanResponseTransformer_test_df_unseen_levels(library=library)
        expected = expected_getter(library=library)

        x = MeanResponseTransformer(
            columns=columns,
            level=level,
            unseen_level_handling=unseen_level_handling,
        )

        if _check_if_skip_test(x, df, lazy=lazy, from_json=from_json):
            return

        initial_df = create_MeanResponseTransformer_test_df()
        x.fit(_convert_to_lazy(initial_df, lazy=lazy), initial_df[target])

        x = _handle_from_json(x, from_json)

        df_transformed = x.transform(_convert_to_lazy(df, lazy=lazy))

        df_transformed = _collect_frame(df_transformed, lazy=lazy)

        expected = nw.from_native(expected)
        for col in x.encoded_columns:
            expected = expected.with_columns(
                nw.col(col).cast(getattr(nw, x.return_type)),
            )

        column_order = nw.from_native(df_transformed).columns

        assert_frame_equal_dispatch(
            df_transformed,
            expected[column_order].to_native(),
        )

        # also test single row transform
        df = nw.from_native(df)
        expected = nw.from_native(expected)

        for i in range(len(df)):
            df_transformed_row = x.transform(
                _convert_to_lazy(df[[i]].to_native(), lazy=lazy)
            )
            df_expected_row = expected[[i]].to_native()

            column_order = nw.from_native(df_transformed_row).columns

            assert_frame_equal_dispatch(
                _collect_frame(df_transformed_row, lazy=lazy),
                df_expected_row[column_order],
            )

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("from_json", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    @pytest.mark.parametrize(
        ("prior", "level", "target", "unseen_level_handling"),
        [
            (5, "all", "c", "mean"),
            (100, ["a", "b"], "c", "min"),
            (1, None, "a", "max"),
            (0, None, "a", "median"),
        ],
    )
    def test_return_type_can_be_changed(
        self,
        prior,
        level,
        target,
        unseen_level_handling,
        library,
        from_json,
        lazy,
    ):
        "Test that output return types are controlled by return_type param, this defaults to float32 so test float64 here"

        df = create_MeanResponseTransformer_test_df(library=library)

        columns = ["b", "d", "f"]
        x = MeanResponseTransformer(
            columns=columns,
            return_type="Float64",
            prior=prior,
            unseen_level_handling=unseen_level_handling,
            level=level,
        )

        if _check_if_skip_test(x, df, lazy=lazy, from_json=from_json):
            return

        x.fit(_convert_to_lazy(df, lazy=lazy), df[target])

        x = _handle_from_json(x, from_json)

        output_df = nw.from_native(x.transform(_convert_to_lazy(df, lazy=lazy)))

        output_df = _collect_frame(output_df, lazy=lazy)

        if target == "c":
            actual_levels = df[target].unique().to_list() if level == "all" else level
            expected_created_cols = [
                prefix + "_" + suffix
                for prefix, suffix in product(columns, actual_levels)
            ]

        else:
            expected_created_cols = columns

        for col in expected_created_cols:
            expected_type = x.return_type
            actual_type = str(output_df[col].dtype)
            assert actual_type == expected_type, (
                f"{x.classname} should output columns with type determine by the return_type param, expected {expected_type} but got {actual_type}"
            )

    @pytest.mark.parametrize("lazy", [True, False])
    @pytest.mark.parametrize("from_json", [True, False])
    @pytest.mark.parametrize("library", ["pandas", "polars"])
    def test_learnt_values_not_modified(self, library, from_json, lazy):
        """Test that the mappings from fit are not changed in transform."""
        df = create_MeanResponseTransformer_test_df(library=library)

        x = MeanResponseTransformer(columns="b")

        if _check_if_skip_test(x, df, lazy=lazy, from_json=from_json):
            return

        x.fit(_convert_to_lazy(df, lazy=lazy), df["a"])

        x2 = MeanResponseTransformer(columns="b")

        x2.fit(_convert_to_lazy(df, lazy=lazy), df["a"])

        x2 = _handle_from_json(x2, from_json)

        x2.transform(_convert_to_lazy(df, lazy=lazy))

        assert x.mappings == x2.mappings, (
            "Mean response values not changed in transform"
        )


class TestOtherBaseBehaviour(
    OtherBaseBehaviourTests, EmptyColumnsFitTransformPassTests
):
    """
        Class to run tests for BaseTransformerBehaviour outside the three standard methods.
    F
        May need to overwrite specific tests in this class if the tested transformer modifies this behaviour.
    """

    @classmethod
    def setup_class(cls):
        cls.transformer_name = "MeanResponseTransformer"

    @pytest.mark.parametrize("library", ["pandas", "polars"])
    def test_learnt_values_not_modified(self, library):
        """Test that the mappings from fit are not changed in transform."""
        df = create_MeanResponseTransformer_test_df(library=library)

        x = MeanResponseTransformer(columns="b")
        pipeline = Pipeline([("MeanResponseTransformer", x)])

        pipeline.fit(df, df["a"])

        pipeline.transform(df)
        # Transform should work
        result = pipeline.transform(df)
        assert result is not None

        # Delete is_fitted_ from the transformer
        del x.is_fitted_

        # Now transform should raise NotFittedError
        with pytest.raises(NotFittedError):
            pipeline.transform(df)


class TestLazyYSupport:
    """Tests for lazy y support in MeanResponseTransformer."""

    @pytest.mark.parametrize("library", ["polars"])
    def test_lazy_y_accepted(self, library):
        """Test that MeanResponseTransformer accepts LazyFrame for y parameter."""
        df_dict = {
            "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
            "b": ["x", "y", "x", "y", "x", "y"],
        }
        df = dataframe_init_dispatch(df_dict, library)

        y_lazy = pl.LazyFrame({"target": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]})

        transformer = MeanResponseTransformer(columns="b")

        # Fit should accept lazy y and not raise an error
        transformer.fit(df, y_lazy)

        assert transformer.is_fitted_
        assert transformer.mappings is not None
        assert "b" in transformer.mappings

    @pytest.mark.parametrize("library", ["polars"])
    def test_lazy_y_consistent_with_eager_y(self, library):
        """Test that LazyFrame y produces same results as eager Series y."""
        df_dict = {
            "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
            "b": ["x", "y", "x", "y", "x", "y"],
        }
        df = dataframe_init_dispatch(df_dict, library)
        y_series = df["a"]

        transformer_lazy = MeanResponseTransformer(columns="b")
        transformer_eager = MeanResponseTransformer(columns="b")

        y_lazy = pl.LazyFrame({"target": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]})

        # Fit with lazy y
        transformer_lazy.fit(df, y_lazy)

        # Fit with eager y
        transformer_eager.fit(df, y_series)

        # Mappings should be identical
        assert transformer_lazy.mappings == transformer_eager.mappings

    @pytest.mark.parametrize("library", ["polars"])
    def test_lazy_x_and_y_consistent_with_eager(self, library):
        """Test that LazyFrame X and lazy y produce same results as eager inputs."""
        df_dict = {
            "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
            "b": ["x", "y", "x", "y", "x", "y"],
        }
        df = dataframe_init_dispatch(df_dict, library)
        df_lazy = df.lazy()
        y_lazy = df[["a"]].lazy()

        transformer_lazy = MeanResponseTransformer(columns="b")
        transformer_eager = MeanResponseTransformer(columns="b")

        # Fit with lazy X and lazy y
        transformer_lazy.fit(df_lazy, y_lazy)

        # Fit with eager X and eager y
        transformer_eager.fit(df, df["a"])

        assert transformer_lazy.mappings == transformer_eager.mappings
