"""OpenAIVision converter"""

__version__ = "1.8.62"
