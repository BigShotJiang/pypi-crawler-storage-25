# Changelog

Todas las versiones notables se documentan aquí. El proyecto sigue [SemVer](https://semver.org/).

## [Unreleased]

## [0.8.0] — 2026-05-22

### Breaking — `datagrowth_common.auth.local` eliminado

Alias deprecated desde v0.3.0 (apuntaba a `auth.session_hmac` con `DeprecationWarning`). La promesa de eliminación en v0.4.0 nunca se cumplió; en v0.8.0 se elimina tras confirmar 0 consumidores en `app-backend` y todas las apps `app-*` del ecosistema. Si una app aún importa `from datagrowth_common.auth import local`, reemplaza por `from datagrowth_common.auth import session_hmac`.

### Security — 11 fixes pre-release (7 críticos/altos/medios del audit + 4 informativos)

Auditoría de seguridad pre-release identificó 11 bugs con escenarios de explotación concretos. Todos arreglados, **40 tests de regresión** en `tests/test_security_fixes.py` + tests actualizados en `test_auth_router.py`, `test_legal_router.py`, `test_session_hmac.py`. Apps que instalen 0.8.0 desde PyPI obtienen los fixes; no aplicable a versiones anteriores (los módulos `legal`, `me`, `retention`, `audit`, observability nacen en 0.8.0).

**INFO 9 — `/auth/register` no enumera emails** ([auth/router.py:124](src/datagrowth_common/auth/router.py#L124)). Antes devolvía `CONFLICT register-failed` si el email ya existía → atacante podía enumerar registrados. Ahora devuelve constante `{sent: True}` tanto si sign_up tuvo éxito como si Supabase lanzó (mismo patrón que `magic-link` y `password-reset`).

**INFO 12 — `/api/me` no expone `app_metadata`/`user_metadata`** ([auth/router.py:306](src/datagrowth_common/auth/router.py#L306)). Antes devolvía `SupabaseUser` completo (incluye metadata del JWT que la app puede haber poblado con tenant_id, hashes, secretos). Ahora devuelve `_PublicMe` (whitelist explícita de `id`/`email`/`role`). Si tu app necesita exponer metadata, añade un endpoint propio o extiende el modelo.

**INFO 7 — `apply_migrations` rechaza paths peligrosos** ([migrations.py:51](src/datagrowth_common/migrations.py#L51)). Defensa en profundidad: tras `resolve()`, el path no puede ser `/`, `/tmp`, `/var/tmp`, `/dev/shm`, `/root`, `/home`. Cierra el vector "atacante con write-access a `/tmp` deja `v999_evil.sql` esperando al siguiente reinicio".

**INFO 11 — `auth.local` eliminado** (ver Breaking arriba).

**CRÍTICO — XSS en parser markdown de páginas legales** ([legal/router.py](src/datagrowth_common/legal/router.py)).

- `html.escape(text, quote=False)` no escapaba `"`, y el regex `[txt](url)` metía la URL cruda en `<a href="\2">`. Permitía: (a) `[x](javascript:alert(1))` ejecutando JS al click; (b) `[x](#" autofocus onfocus=...)` ejecutando JS al cargar sin click (cerraba el atributo `href`).
- Fix: `quote=True` para escapar `"`/`'`; whitelist de esquemas (`https`/`http`/`mailto`/`tel`/relativos `/`/anchors `#`); `html.escape` aplicado a la URL antes de meterla en el `href`; URLs con esquema inválido se renderizan como texto plano (sin `<a>`); `rel="noopener noreferrer"` en todos los links generados.

**CRÍTICO — OAuth callback sin protección anti-CSRF** ([auth/router.py](src/datagrowth_common/auth/router.py)).

- `auth_oauth_callback` aceptaba `?code=` sin verificar que el flow viniera del mismo navegador que lo inició. Permitía login-CSRF: atacante capturaba su propio code, mandaba a víctima al callback, backend canjeaba el code por JWT del atacante y SETEABA la cookie de sesión del atacante en el navegador de la víctima. Víctima operaba "logueada" como atacante.
- Fix: `/start` setea cookie httpOnly `dg_oauth_state` con nonce + `SameSite=Lax` + `Path=/auth/oauth/{provider}/callback` + TTL 600s. `/callback` rechaza si la cookie no existe (redirect a `/login?error=oauth-state`). El atacante no puede setear cookies en el navegador de la víctima → CSRF cerrado. Además, whitelist regex `^[a-z][a-z0-9_-]{1,30}$` para el `provider` (defensa en profundidad contra inputs raros al SDK).

**ALTO — `/auth/password` exento de CSRF + `extra_exempt_prefixes` sin validación** ([middleware/csrf.py](src/datagrowth_common/middleware/csrf.py)).

- `/auth/password` estaba en `_DEFAULT_EXEMPT_PREFIXES`. Permitía login-CSRF clásico: formulario auto-submit desde sitio del atacante → víctima quedaba autenticada como atacante. La justificación "primer POST sin cookie" era falsa: el GET de `/login` ya setea la cookie CSRF.
- `extra_exempt_prefixes=("/",)` desactivaba CSRF entero sin warning.
- Fix: `/auth/password` removido del exempt list — HTMX adjunta el header automáticamente, forms HTML clásicos incluyen `<input name="csrf_token" hidden>` que `_extract_submitted_token` recoge del body. Nuevo `_validate_exempt_prefixes` rechaza `""`, `"/"` y prefixes no-absolutos con `ValueError` al construir el middleware.

**MEDIO — Sentry scrubbing incompleto** ([observability/sentry.py](src/datagrowth_common/observability/sentry.py)).

- `_default_before_send` cubría headers/cookies/extra/message/breadcrumbs.message pero NO `event.user` (`set_user()` pone email/username/ip_address), `event.tags`, `event.contexts`, `event.exception.values[].value` (mensaje de excepción es el sitio donde MÁS PII se cuela: `ValueError("invalid email user@example.com")` o errores de psycopg con `DETAIL: ...email...`), `event.request.query_string` (`?token=...`), `event.request.data` (body con password).
- Fix: scrubbing extendido a los 6 sitios. `event.user` pierde email/username/ip_address (conserva `id` uuid). `tags`/`contexts`/`data` pasan por `_scrub_value` recursivo. `exception.values[].value` y `query_string` pasan por `_scrub_strings` (regex emails). `breadcrumb.data` también scrubeado.

**MEDIO — `_client_ip` confiaba ciegamente en `X-Forwarded-For`** ([me/router.py](src/datagrowth_common/me/router.py)).

- Sin proxy de confianza, cualquier cliente podía setear `X-Forwarded-For: 1.2.3.4` y el audit log GDPR registraba la IP falseada. Las IPs son evidencia legal regulada — falsear destruye su valor.
- Fix: `make_me_router(..., trust_proxy=False)` — default `False` (ignora XFF). Apps detrás de proxy de confianza (Caddy/nginx/Easypanel que strippea XFF cliente-supplied) pasan `True` explícito.

**MEDIO — SQL identifier injection en `retention/purger.py`** ([retention/purger.py](src/datagrowth_common/retention/purger.py)).

- `extra_grant_tables` / `agent_log_table_name` / `agent_log_timestamp_column` / `schema` se f-stringeaban directo en queries. Uso normal seguro (tuples literales) pero refactor a env/YAML futuro → SQL injection.
- Fix: whitelist regex `^[a-z_][a-z0-9_]{0,62}$` aplicado a TODOS los identificadores en `make_retention_purger`. Falla con `ValueError` al construir el purger (fail-fast en boot, no en runtime).

**MEDIO — `audit.emit` no scrubeaba emails del `user_agent` + no validaba `schema`** ([audit.py](src/datagrowth_common/audit.py)).

- Clientes custom embeden email en UA (`MyApp/1.0 (admin@example.com)`). El UA va a `user_audit_log` que se devuelve en el GDPR export → leak de emails de admins a usuarios cualquiera que pidan export.
- `schema` se f-stringeaba sin validar.
- Fix: regex `_EMAIL_RE` aplicado al UA antes de truncar a 500 chars. `schema` validado contra el mismo whitelist regex de identificadores — `audit.emit` devuelve `(False, ValueError)` si schema inválido en lugar de ejecutar.

---

Release que consolida dos batches de trabajo: el auditor `qa` (que iba a ser 0.7.16, nunca llegó a publicarse) y todos los production-readiness helpers del Subplan H. Las apps generadas por el pipeline heredan health, observabilidad, middlewares de seguridad, endpoints GDPR, auditor de release y skills de desarrollo sin que el dev tenga que copiar/pegar.

### Added — Submódulo `qa` con auditor de production-readiness

Submódulo `datagrowth_common.qa` con el auditor determinista `run_audit(repo_root)` que ejecuta 19 checks sobre un repo Datagrowth y devuelve `(report, exc)` con blockers + warnings clasificados por severity. Aplicable a cualquier app generada por el pipeline y al backend interno.

**Uso**:

```python
from pathlib import Path
from datagrowth_common.qa import run_audit

report, exc = run_audit(Path("."))
# report["blockers"] == 0 → LISTO PARA RELEASE
# report["results"] lista cada check con name/passed/details/severity
```

**Checks cubiertos** (19 total):

- **Fundacionales (blocker)**: `no-print-in-src`, `structlog-initialized`, `env-example-exists`, `migrations-versioned`, `tests-dir`, `no-secrets-hardcoded`, `health-endpoint-public` cuando aplica.
- **Production-readiness (warning)**: `live-endpoint`, `ready-endpoint`, `env-declared:SENTRY_DSN`, `security-headers-middleware`, `csrf-middleware`, `rate-limit-auth`, `gdpr-export`, `gdpr-delete`, `privacy-doc`, `legal-routes`, `ci-workflow`, `runbook-present`.

Severities siguen el patrón "blocker = fundacional, warning = mejora incremental que un dev puede ir cerrando". Los checks son funciones puras sin red ni proceso externo: leen filesystem y devuelven `CheckResult` (`name`, `passed`, `details`, `severity`).

**Skill `prod-ready-checklist`** añadida al template (`template/.agents/skills/prod-ready-checklist/SKILL.md`): slash-command que invoca el auditor desde Claude Code y emite veredicto `LISTO PARA RELEASE / BLOQUEADO`. Cada app generada hereda la skill al regenerarse desde el template; las apps ya desplegadas la reciben via `update-common`.

**Tests**: 33 tests en `tests/test_prod_ready_audit.py` cubriendo cada check con repos fixture + test integrador. Patrón de error del proyecto (devuelve tuple, no raise cross-module). Cero dependencias externas (solo stdlib).

### Added — Production-readiness helpers compartidos

**Nuevos submódulos**:

- `datagrowth_common.observability`:
  - `init_sentry(component=..., dsn=None, environment=None, release=None, traces_sample_rate=None, extra_before_send=None) -> bool`. Inicializa Sentry si `SENTRY_DSN` está seteada. `before_send` por defecto redacta emails crudos, cabeceras sensibles (`Authorization`, `Cookie`, `X-CSRF-Token`, `X-Admin-Token`), cookies enteras del request, y cualquier key cuyo nombre contiene `password`/`token`/`secret`/`api_key`. No-op si `sentry-sdk` no está instalado (extra `[observability]` no presente).
  - `default_instrumentator(app, *, endpoint="/metrics", inprogress_name="dg_requests_inprogress", excluded_handlers=None) -> bool`. Registra el `prometheus_fastapi_instrumentator.Instrumentator` y expone `/metrics`. Excluye paths de salud + estáticos por defecto. No-op si la lib no está instalada.

- `datagrowth_common.middleware`:
  - `RequestIdMiddleware`: lee/genera `X-Request-Id`, lo bindea a `structlog.contextvars`, lo setea como tag Sentry y lo devuelve en la response.
  - `SecurityHeadersMiddleware`: HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy y CSP laxo configurable. Flag `DG_SECURITY_HEADERS_ENABLED`.
  - `CSRFMiddleware`: double-submit cookie. Exenta GET/HEAD/OPTIONS + webhooks + callback OAuth + `/auth/password`. Acepta `extra_exempt_prefixes`. Flag `DG_CSRF_ENABLED`.
  - `MetricsAuthMiddleware`: basic-auth para `/metrics` (default OFF — 404 sin credenciales). Compara con `secrets.compare_digest`. Acepta `metrics_path`/`user_env`/`pass_env` para apps con naming custom.
  - `build_limiter(*, redis_url=None, default_limits=("100/minute",)) -> tuple[Limiter|None, handler|None]`. Crea limiter de slowapi + handler 429 con cuerpo JSON consistente. Storage Redis cuando `REDIS_URL` está seteado, fallback `memory://`. Devuelve `(None, None)` si `slowapi` no está instalado. Flag `DG_RATE_LIMIT_ENABLED`.

- `datagrowth_common.me`:
  - `make_me_router(*, auth_dep, session_dep, extra_exporters=(), schema=None, tags=("me",)) -> APIRouter`. Tres endpoints GDPR self-service:
    - `GET    /me/data/export` — ZIP con `profile.json` + `audit_log.json` + cualquier blob extra que la app inyecte via `extra_exporters`.
    - `DELETE /me/data` — inserta fila en `user_deletion_request` con `purge_at = now + DG_DELETE_GRACE_DAYS` (default 30). Idempotente: si ya hay solicitud activa no reinicia la gracia.
    - `POST   /me/data/delete/cancel` — borra la fila si sigue en gracia.
  - `Exporter = Callable[[Session, user], tuple[str, bytes|str]]`. Cada app define exporters propios (runs, leads, etc.) sin que el paquete los conozca.

- `datagrowth_common.audit`:
  - `emit(session, *, actor_id, target_user_id, action, metadata=None, ip=None, user_agent=None, schema=None) -> tuple[bool, Exception|None]`. Inserta una fila en `user_audit_log` con patrón de error como valor (un fallo de logging nunca rompe el handler).

- `datagrowth_common.legal`:
  - `make_legal_router(*, docs_dir, pages=None, templates, template_name="dg/legal/page.html", md_to_html_fn=None, tags=("legal",)) -> APIRouter`. Endpoints públicos `/privacy`, `/terms`, `/security` (sin auth) que renderizan los `.md` de `docs_dir` como HTML. Parser markdown mínimo (h1-h6, listas, tablas GFM, párrafos, `**bold**`, `` `code` ``, `[link](url)`) con `html.escape` aplicado antes del replace inline para inmunidad XSS. Cada app inyecta su shell vía `template_name=` y opcionalmente un parser completo en `md_to_html_fn=`.
  - Template `ui/templates/dg/legal/page.html` empaquetado en el wheel (servido vía `register_ui` automáticamente).

- `datagrowth_common.retention`:
  - `make_retention_purger(*, session_factory, schema=None, extra_grant_tables=(), agent_log_table_name=None, agent_log_timestamp_column="created_at", ...)`. Devuelve `iteration() -> tuple[stats, Exception|None]` para schedulear con APScheduler / arq / cron. Tres responsabilidades: purga `user_deletion_request` vencido + emite audit `data-purged`, retención `user_audit_log` (default 365 días, env `DG_USER_AUDIT_LOG_RETENTION_DAYS`), retención opcional de tabla de logs operativos (env `DG_AGENT_LOG_RETENTION_DAYS`). Idempotente. Apps con grants RBAC propias pasan `extra_grant_tables=(("user_role", "user_id"), ("user_client_access", "user_id"))` para que el purger limpie cross-tabla.

**Template**:

- `template/infra/docker-compose.yml`: reescrito. Servicio `app` por defecto + tres servicios bajo `profiles:`:
  - `redis` (perfil `queue`): Redis 7-alpine con AOF + cap 256 MB LRU.
  - `app-worker` (perfil `queue`): worker ARQ que ejecuta `src.queue.worker.WorkerSettings`.
  - `app-backup` (perfil `prod`): alpine 3.19 con cron 03:15 UTC que ejecuta `infra/backup.sh`.
  - Red privada `app-net` para que app/worker/redis hablen sin exponer Redis a la red de Easypanel.
  - Activación: `COMPOSE_PROFILES=queue,prod` en el environment del compose.
- `template/pyproject.toml`: nueva extra `[queue]` (`arq>=0.26,<1` + `redis>=5,<6`). Apps sin jobs largos no la instalan.
- `template/src/queue/__init__.py`: nuevo. Skeleton documentado: el dev del paquete crea `src/queue/worker.py` con `WorkerSettings` y activa el perfil `queue`.
- `template/src/api/health.py`: nuevo. `/live` (heartbeat puro), `/ready` (verifica BD + `SUPABASE_JWT_SECRET`), `/healthz` (alias de `/live`). Router sin deps de auth para que healthchecks server-to-server respondan 200.
- `template/src/main.py`: actualizado para llamar a `init_sentry()`, `default_instrumentator()`, y registrar `RequestIdMiddleware` + `SecurityHeadersMiddleware` + `CSRFMiddleware` + `SlowAPIMiddleware` con los flags del paquete. Healthchecks van sin `populate_template_state`.
- `template/migrations/v3_access_event.sql`: nuevo. Tabla `user_deletion_request` + columnas `ip`/`user_agent` en `user_audit_log` (existente desde v2). Idempotente con `CREATE TABLE IF NOT EXISTS` + `ADD COLUMN IF NOT EXISTS`.
- `template/.github/workflows/ci.yml`: nuevo. Lint (ruff, `continue-on-error`), tests con cobertura, security-audit (`pip-audit`), y `prod-ready-audit` que invoca `datagrowth_common.qa.run_audit` en PRs `release/**`.
- `template/infra/backup.sh`: nuevo. Plantilla del cron nocturno (pg_dump del schema + opcional GPG + restic). Usa las vars `BACKUP_*` + `RESTIC_PASSWORD`.
- `template/docs/PRIVACY.md`: nuevo. Plantilla de política de privacidad interna (retenciones, contactos) con placeholders `{{ ... }}`.
- `template/docs/RUNBOOK.md`: nuevo. Plantilla de procedimientos operativos (deploy, restore, GDPR, troubleshooting).
- `template/docs/legal/{privacy,terms,security}.md`: nuevos. Plantillas de los textos legales públicos servidos por `make_legal_router(...)` en `/privacy`, `/terms`, `/security`. Cubren responsable del tratamiento, datos, bases legales, retenciones, derechos GDPR, condiciones del servicio, política de seguridad.
- `template/.github/CODEOWNERS`: nuevo. Placeholder `@<github-owner>` + paths sensibles (`infra/`, `migrations/`, `.github/`, `setup.json`).
- `template/src/main.py`: añade `MetricsAuthMiddleware` (antes de RequestId), `make_legal_router(docs_dir=docs/legal, templates=templates)` cuando el directorio existe.
- `template/infra/.env.example`: nuevas vars `DG_CSRF_ENABLED`, `DG_SECURITY_HEADERS_ENABLED`, `DG_RATE_LIMIT_ENABLED`, `REDIS_URL`, `SENTRY_DSN`, `DG_RELEASE`, `SENTRY_TRACES_SAMPLE`, `METRICS_USER`, `METRICS_PASS`, `DG_DELETE_GRACE_DAYS`, `DG_RETENTION_PURGE_INTERVAL_S`, `DG_USER_AUDIT_LOG_RETENTION_DAYS`, `DG_AGENT_LOG_RETENTION_DAYS`, `BACKUP_*`, `RESTIC_PASSWORD`, `BACKUP_DATA_DIR`.

**Optional extras**:

- `[observability]`: `sentry-sdk[fastapi]>=2.17`, `prometheus-fastapi-instrumentator>=7.0`.
- `[middleware]`: `slowapi>=0.1.9`.

Las apps deciden instalar las extras que necesiten. Una app sin las extras puede importar los módulos sin error (los inits devuelven `False` o `None`).

**Pin recomendado en apps consumidoras**: `datagrowth-common[supabase,observability,middleware]>=0.8.0,<0.9`.

### Added — Skills de desarrollo propagadas al template

El template `.agents/skills/` incluye ahora todas las skills universales de desarrollo que vivían solo en `app-backend/.claude/skills/`: `architecture-blueprint`, `autodoc`, `readme-blueprint`, `skill-creator`, `output-skill`, `pytest-coverage`, `taste-skill`, `ui-ux-pro-max`. Cada app generada las hereda automáticamente — el dev que abra Cursor/Claude Code en el repo recién scaffolded ya tiene las mismas slash-commands disponibles que en el control plane.

### Added — Regla `no-roadmap-comments`

`template/.claude/rules/no-roadmap-comments.md` + `template/.cursor/rules/no-roadmap-comments.mdc`. Codifica la convención de que comentarios en código no referencian fase/sprint/ticket/fecha — solo el "por qué" técnico. Aplica a todas las apps con la misma fuerza que en el backend.

### Added — Módulo `datagrowth_common.env` con helper canónico `DG_ENV`

Nuevo módulo `env` con `dg_env()`, `is_dev_env()`, `is_prod_env()` que normalizan `DG_ENV` a la convención canónica de Datagrowth: `prod` (default) o `dev`. Acepta legacy `production`/`development` por compatibilidad con apps ya desplegadas que tienen los valores largos en sus envs.

Refactor del paquete y template para usar el helper:

- `datagrowth_common/logger.py`: `is_dev = is_dev_env()` (antes comparaba con `"development"` directamente).
- `datagrowth_common/auth/session.py::_cookies_secure`: `return not is_dev_env()`.
- `datagrowth_common/middleware/csrf.py::_is_secure_cookie`: `return is_prod_env()`.
- `datagrowth_common/observability/sentry.py`: `environment=dg_env()` para Sentry.
- `template/src/lib/logger.py`: ahora es un thin re-export del paquete (`from datagrowth_common.logger import get_logger, setup_logging`) — elimina la duplicación con el paquete.
- `template/src/api/admin_users.py::_make_perm_dep`: `if is_dev_env(): return actor` (antes lookup directo a `"production"`).
- `template/src/api/deps.py::require_auth`: `if is_dev_env() and DG_DEV_BYPASS_AUTH != "false"` (antes hardcodeado a `"development"`).
- `template/infra/.env.example`: `DG_ENV=prod` (antes `production`) + comentario explicando la convención.
- `template/infra/docker-compose.yml`: `DG_ENV=prod` (antes `production`).
- `template/src/main.py`: `log.info("startup", env=os.getenv("DG_ENV", "prod"))`.
- Tests del paquete: `test_auth_session.py` y `test_auth_router.py` setean `DG_ENV=dev` (antes `development`).

13 tests nuevos en `tests/test_env.py` cubren el helper (default sin var, normalización de prod/PROD/production, normalización de dev/DEV/development, fallback a prod para valores desconocidos).

## [0.7.15] — 2026-05-19

### Changed — `.sidebar-link-active` sólido (lima + texto navy) en lugar de translúcido

`.sidebar-link-active` del paquete usaba `background-color: var(--color-sidebar-active-bg)` con `color-mix(... 22%, transparent)`. Eso daba un look pálido inconsistente con el del backend orquestador, que tenía su propia regla local en `src/styles/app.css` con `bg-brand-lime text-brand-dark` (lima sólido). Resultado: las apps generadas mostraban el item activo del sidebar con un verde clarito translúcido mientras el backend lo mostraba lima saturado — misma marca, dos looks.

Fix en `_tailwind.source.css` del paquete:

```css
.sidebar-link-active {
  @apply bg-brand-lime text-brand-dark font-semibold
         hover:bg-brand-lime-400 hover:text-brand-dark;
}
```

Resuelve via `var(--color-brand-primary-rgb)` / `var(--color-brand-secondary-rgb)` (los triplets que ya consume el resto de utilities desde 0.7.13), así cada cliente personaliza vía su `tokens-override.css`. Coherente con `.btn-primary` del mismo paquete: el mismo lima sólido + texto navy.

Las vars `--color-sidebar-active-bg` / `--color-sidebar-active-text` se conservan en `tokens.css` por compat (apps que las consuman directamente en CSS custom siguen funcionando) pero `.sidebar-link-active` ya no las usa.

Recompilado el `tailwind.compiled.css` del paquete con el cambio.

## [0.7.14] — 2026-05-18

### Fixed — Apps generadas no servían `src/static/brand/tokens-override.css`

Bug crónico del template descubierto al deployar una app fresh contra el nuevo `tailwind.compiled.css` de 0.7.13. El `main.py` del template solo monta `/static/dg-common/` (los assets del paquete via `register_ui`) y nunca declaró un mount para el directorio `src/static/` local. El deployer Datagrowth escribía correctamente `src/static/brand/{tokens-override.css, meta.json, logo.*}` al repo de cada app, pero el propio FastAPI de la app respondía **404** cuando el navegador pedía `/static/brand/tokens-override.css` — no había sub-app que sirviera ese path.

Hasta 0.7.13 el bug pasaba desapercibido: el `tailwind.compiled.css` del paquete bakeaba los hex Datagrowth literales, así que las utility classes brand seguían pintando lime aunque el override del cliente no cargara. Con el refactor de 0.7.13 que hace que las utilities consuman `var(--color-brand-*-rgb)`, el override pasa a ser indispensable — y el 404 silencioso se hizo visible: todos los elementos brand caían a gris.

Fix en `template/src/main.py`:

```python
from fastapi.staticfiles import StaticFiles
from pathlib import Path

# tras register_ui(...)
_LOCAL_STATIC_DIR = Path(__file__).resolve().parent / "static"
_LOCAL_STATIC_DIR.mkdir(parents=True, exist_ok=True)
app.mount(
    "/static",
    StaticFiles(directory=str(_LOCAL_STATIC_DIR)),
    name="local-static",
)
```

`register_ui` registra `/static/dg-common/` ANTES de este mount catch-all → requests a `/static/dg-common/...` matchean el sub-app del paquete; el resto (`/static/brand/*`, `/static/css/*`) cae al directorio local del repo.

Apps existentes (deployadas antes de 0.7.14): el patcher quirúrgico `_patch_main_for_local_static_mount` del backend Datagrowth añade el mount al `src/main.py` del repo al pulsar "Actualizar common". Idempotente con tres reasons:
- `patched`: añadido el mount + imports faltantes (`StaticFiles`, `Path`).
- `already-fixed`: el repo ya contiene `app.mount("/static"`.
- `structure-mismatch:no-register-ui`: el operador customizó el bootstrap del app — no tocamos, el PR del bump incluye snippet manual en el body.

## [0.7.13] — 2026-05-18

### Added — `setup.json` + `SETUP.md` en el skeleton

El template de apps trae ahora `template/setup.json` (vacío,
`{"version": 1, "fields": [], "groups": []}`) y `template/SETUP.md` con
la guía completa para devs del paquete. Al hacer `_flatten_template_scaffold`,
el publisher promueve ambos a la raíz del repo `app-*`.

`setup.json` es el manifest declarativo del orquestador (lee
[app-backend/src/packaging/setup_manifest.py](https://github.com/datagrowth/app-backend/blob/main/src/packaging/setup_manifest.py)
en `app-backend`): el dev del paquete declara campos extra (prompts de
agentes runtime, tokens externos, idiomas por defecto, flags) que el
cliente debe rellenar al instalar la app. Los valores rellenados se
inyectan como env vars al container desplegado en Easypanel. Tipos
soportados: text, textarea, password, select, number, boolean, url,
email. Secrets (`secret: true`) se cifran con Fernet en BD.

Por construcción, `setup.json` y `SETUP.md` son **propios de cada app**
y el sync "Actualizar common" del orquestador los respeta — solo se
añaden al esqueleto base; los edits del dev del paquete no se pisan.

### Changed — `tokens.css` neutral + utility classes Tailwind por CSS vars (RGB triplets)

Hasta esta versión, dos artefactos del paquete bakeaban la identidad Datagrowth y la propagaban a cualquier consumidor:

1. **`tokens.css`** declaraba `--color-brand-primary: #b5ff82` (lime) y `--color-brand-secondary: #263b4a` (navy) como **defaults literales** del `:root`. Si el `tokens-override.css` del cliente no cubría una variable, salía Datagrowth como leak silencioso.
2. **`tailwind-preset.cjs`** declaraba `brand.lime: '#b5ff82'`, `brand.dark: '#263b4a'`, etc. como hex **literales**. El `tailwind.compiled.css` bakeaba esos hex en cada utility class (`bg-brand-lime`, `text-brand-dark`, `badge-brand`, `border-brand-lime/30`, `ring-brand-lime`). Ningún `tokens-override.css` podía pisarlas — las utilities ignoraban las CSS variables.

Refactor de fondo en esta release:

- **`tokens.css` (paquete)** — Cada brand/semántico declara **dos formas paralelas**: triplet RGB sin envoltura (`--color-brand-primary-rgb: 71 85 105`) consumido por las utility classes con `<alpha-value>`, y forma funcional (`--color-brand-primary: rgb(var(--color-brand-primary-rgb))`) para CSS directo. Defaults gray-based neutrales. Vars funcionales (radii, shadows, spacing, motion, breakpoints) se conservan: son convencionales y no leak-ean identidad. La cabecera del archivo documenta el contrato.

- **`tailwind-preset.cjs`** — Colores brand/semánticos pasan de hex literales a `rgb(var(--color-X-rgb) / <alpha-value>)`. Soporta modificadores de opacity (`bg-brand-lime/15`, `border-brand-lime/30`) sin perder funcionalidad. Sub-tonos `-400`/`-600` redirigidos a las vars `*-dark` del set canónico (`brand-lime-400` → `--color-brand-primary-dark-rgb`). Sub-tonos `-100` quedan como alias del principal.

- **`tailwind.compiled.css` recompilado** — Cero hex Datagrowth en el output. Todas las utility classes (`.bg-brand-lime`, `.text-brand-dark`, `.badge-brand`, etc.) resuelven `rgb(var(--color-X-rgb) / var(--tw-bg-opacity,1))` dinámicamente. Validado con `grep -E "b5ff82|263b4a|bab8d0"` → 0 matches.

- **`sidebar_shell.html`** — Dos fallbacks `request.state.*`:
  - `{% set user = user or (request.state.dg_user if request.state else None) %}` antes del `<header>`. Sin esto el topbar de `/admin/users` (y cualquier página servida por un router del paquete que renderice con context propio) sale sin email/Admin/Salir.
  - `{% set _tokens_override_href = tokens_override_href or (request.state.dg_tokens_override_href if request.state else None) %}` antes del `<link>` al CSS override. Permite que la host app inyecte el override a TODAS sus páginas via dep global (`populate_template_state`), sin tener que repetir el campo en cada `TemplateResponse`. Patrón simétrico al fallback de `user` añadido en 0.7.11.

Cuando el consumidor es el backend del orquestador Datagrowth (`app-backend`), su `populate_template_state` pobla `request.state.dg_tokens_override_href = "/tools/branddesign/{slug}/tokens-override.css"` con un slug configurable por env var `DG_BACKEND_BRAND_DESIGN_SLUG` (default `datagrowth`). El backend consume su propia marca igual que cualquier app cliente — sin CSS hardcoded, sin acoplamiento. Cambiar la marca del backend = cambiar el env var o regenerar el `tokens-override.css` del slug actual.

Cuando el consumidor es una app generada para un cliente, su propio handler/dep pobla el `tokens_override_href` apuntando a su BrandDesign. Si el override es exhaustivo (set canónico completo de 46 variables — 5 brand-rgb + 5 brand funcionales + 2 on-*, 4 surfaces light/dark, 4 text, 2 link, 2 sidebar-active, 8 semánticos-rgb + 8 semánticos funcionales, 3 fonts, 1 ring-focus), nada del paquete leak-ea marca de otro cliente.

Impacto para apps existentes:

- Apps con `tokens-override.css` exhaustivo (generado por `design_to_tokens` con el nuevo prompt y el set de 46 vars incluyendo triplets `-rgb`): sin cambio visual.
- Apps con override generado por el prompt antiguo (23 vars, sin `-rgb` triplets): las utility classes con alpha caen a gray hasta que se regenere el override desde la galería. **Acción recomendada tras pullear esta release**: regenerar el `tokens-override.css` de cada `BrandDesign` desde `/tools/branddesign/<slug>` → "Regenerar tokens".

### Fixed — Topbar pierde email/Admin/Salir en páginas servidas por routers del paquete

Incluido como parte del refactor de `sidebar_shell.html` arriba.

## [0.7.12] — 2026-05-18

### Added — Onboarding para desarrolladores externos en apps generadas

Hasta ahora las apps generadas eran un repo que solo el control plane Datagrowth y Pablo entendían. Para abrirlas a desarrolladores externos hay que dejarles claro QUÉ pueden tocar libremente y QUÉ regenera el backend (Dockerfile, base.html, `tokens-override.css`, etc.). Sin ese contrato, cualquier dev acaba editando `src/api/deps.py` o `tokens-override.css` y pierde el trabajo en el siguiente "Actualizar common" o resync de marca.

Nuevos artefactos en `template/`:

- **`template/setup.sh`** — bootstrap one-shot tras clonar el repo: enlaza `.claude/skills/` y `.cursor/skills/` a `.agents/skills/` (única fuente de verdad de las skills compartidas). Idempotente, crea directorios padres si no existen. Requiere bash (Linux/macOS/WSL/Git Bash).
- **`template/.agents/skills/dg-customize/SKILL.md`** — nueva skill que codifica el contrato customizable vs gestionado. Lista exhaustiva de archivos en cada lado, alternativas seguras (CSS propio en `src/static/css/app.css`, helpers nuevos en `src/lib/`), patrones canónicos para añadir router/migración/página, qué hacer cuando el backend abre un PR de "Actualizar common".
- **`template/.claude/rules/managed-files.md`** — regla con frontmatter `paths:` que Claude Code carga AUTOMÁTICAMENTE cuando el dev (humano o agente) edita un archivo bajo `src/static/brand/**`, `infra/Dockerfile`, `src/api/{deps,auth,admin_users}.py`, `src/db.py`, `src/templates/base.html`, etc. Avisa antes de la edición y redirige a la skill.
- **`template/README.md` rewrite** — sección "Empezar a desarrollar" en la cabecera con: clonar + `setup.sh`, tabla completa de archivos gestionados con sus alternativas, qué SÍ es del dev, reglas de rebranding (no hardcodear hex), workflow cuando llega un PR de "Actualizar common".
- **`template/CLAUDE.md`** — bloque inicial "Esta es una app generada — lee esto antes de editar nada" apuntando a la skill `dg-customize` y a la regla `managed-files.md`.

Apps existentes reciben `setup.sh` y `managed-files.md` en el próximo "Actualizar common" (ambos añadidos a `_SYNC_FILES` en el backend Datagrowth). La skill `dg-customize` viaja sola por `_SYNC_DIRS_RECURSIVE`. El README de cada app es customizable — operadores que quieran portar la sección de dev-onboarding lo hacen manualmente.

### Fixed — `.sidebar-section-label` en compiled CSS

El header "Administración" del sidebar (sección admin) se renderizaba en apps generadas como texto inline plano sin uppercase, sin `tracking-wide`, sin jerarquía visual. La clase `.sidebar-section-label` estaba definida en el `app.css` del backend pero NO en el `tailwind.compiled.css` del paquete (el que sirve a las apps vía `register_ui`).

Causa raíz: el `tailwind.config.js` del paquete solo escaneaba `src/datagrowth_common/ui/templates/**/*.html`. Las clases usadas en `template/src/templates/**/*.html` (scaffold de las apps) no se detectaban → Tailwind las purgaba del compiled.

Fix en `tailwind.config.js`: añadido `./template/src/templates/**/*.html` a `content`. La clase se añade en `_tailwind.source.css` con `display: block` para que `mb-*` aplicado desde el HTML tenga efecto (en inline los márgenes verticales se ignoran).

### Changed — Sección admin del sidebar template

- Renombrada "Administración" → "Administrador" (más natural en castellano para el contexto de rol).
- Espaciado mejorado: `<hr class="my-2">` → `my-3`, `<span class="... mb-1">` → `mb-2`. El header tiene más aire visual ahora que `.sidebar-section-label` aplica uppercase + tracking.

Apps existentes: el backend Datagrowth añade un nuevo patcher quirúrgico `_patch_sidebar_admin_section` (idempotente: `patched` / `already-fixed` / `structure-mismatch`) que detecta el par exacto del template legacy y lo migra. Si el operador customizó el bloque, el patcher reporta `structure-mismatch` y el PR de "Actualizar common" incluye instrucciones para alinear manualmente.

## [0.7.11] — 2026-05-18

### Added — Sidebar consistente cross-pantalla (`populate_template_state`)

El partial `partials/sidebar_nav.html` solo recibía `user` cuando el handler que renderizaba la página lo pasaba explícitamente al context Jinja. Los routers del propio paquete (`users_router` que sirve `/admin/users`) solo conocen su context y NO pasan `user` — el sidebar se renderizaba sin estado y ocultaba el bloque "Administración" aunque el usuario fuera admin. El badge "Admin" de la topbar tenía el mismo problema, ya parcheado en 0.7.9 con el fallback `APP_ADMIN_EMAIL`. Esta versión cubre el caso general (no solo el bootstrap admin) y para CUALQUIER pantalla.

Solución (mismo patrón que `app-backend`):

- **`template/src/api/deps.py:populate_template_state`** — dep nueva que inyecta `request.state.dg_user` antes del handler. Reusa `require_auth` interno (cookie httpOnly + JWT Supabase + fallback `APP_ADMIN_EMAIL`).
- **`template/src/main.py`** — aplica `dependencies=[Depends(populate_template_state)]` a cada `include_router(...)` HTML autenticado (`dashboard`, `users_router`, `admin_users`). `auth.router` queda fuera (sus endpoints `/login` deben ser públicos).
- **`template/src/templates/partials/sidebar_nav.html`** — añade fallback `{% set user = user or request.state.dg_user %}` al inicio. Si el handler pasa `user` explícito, gana ese (compat con sidebars customizados).

Apps existentes: el patcher quirúrgico `_patch_main_for_template_state` en `app-backend/update_common_pr.py` añade el dep a cada `include_router(...)` del repo de la app sin tocar customizaciones. El patcher quirúrgico `_patch_sidebar_for_state_fallback` añade solo el bloque `{% set user = ... %}` al inicio del sidebar de la app sin tocar los links del operador. Ambos idempotentes (`already-fixed` si ya están parcheados, `structure-mismatch` si la estructura es customizada).

### Changed — `template/src/templates/partials/sidebar_nav.html`: estructura escalable

El sidebar antes era 15 líneas con "Dashboard" + bloque admin. Ahora documenta dónde el operador añade sus módulos (comentario inline con snippet) y mantiene el bloque "Administración" condicional al `is_admin`. Cero links nuevos por defecto — el contrato es "el operador rellena".

## [0.7.10] — 2026-05-16

### Added — Skills de auto-evolución y gobernanza en el template

Las apps cliente recién creadas ya viajaban con dos skills técnicas (`fastapi`, `supabase`) en `template/.agents/skills/`, pero NO con el aparato de gobernanza que sí tenía el repo principal (`.claude/skills/`). El operador de una app nueva no tenía a mano el motor de auto-aprendizaje ni los pipelines de pre-commit / fix-issue desde el primer commit.

Añadidas siete skills más al template, todas bajo `template/.agents/skills/` y sincronizadas vía "Actualizar common":

- `boot` — secuencia de arranque de sesión: carga `learned-rules.md`, ejecuta verificaciones y reporta violaciones.
- `evolution` — motor de aprendizaje: captura correcciones, verifica hipótesis, propone reglas testeables.
- `evolve` — revisión periódica: promueve correcciones recurrentes, gradúa reglas estables, poda obsoletas. Requiere aprobación humana antes de tocar `learned-rules.md`.
- `find-skills` — descubrimiento e instalación de skills externas via `npx skills find <query>` (skills.sh).
- `fix-issue` — pipeline end-to-end para corregir un bug desde un número de issue GitHub: causa raíz → fix mínimo → test → commit `fix(scope): ... (fixes #N)`.
- `modular-design` — contrato de modularidad para colores, tipografía, logo, copy y componentes Jinja. Cero estilos hardcodeados — todo via CSS tokens (`tokens.css` + `tokens-override.css` del cliente) o `branding.*`. Ya existía en el repo principal desde 0.7.5; ahora viaja en el template.
- `precommit` — pipeline pre-commit: tests + lint + typecheck + revisión del diff con veredicto LISTO PARA MERGE / NECESITA TRABAJO / BLOQUEADO.

`template/.agents/skills/README.md` actualizado con tabla de las nuevas skills agrupadas en dos secciones (convenciones técnicas + auto-evolución/gobernanza). Apps existentes recibirán las skills nuevas en el próximo "Actualizar common" (`update_common_pr` sincroniza `.agents/skills/` por defecto).

## [0.7.9] — 2026-05-16

### Added — Fallback de admin para `APP_ADMIN_EMAIL` y `.agents/skills/` heredadas

**Admin badge ausente tras primer arranque**: tras 0.7.8 el `bootstrap_admin_from_env` sincroniza `app_metadata.role="admin"` en Supabase Auth, pero los JWT existentes del usuario NO se invalidan ni regeneran — solo los nuevos logins traen el claim actualizado. El operador con sesión viva antes del arranque quedaba con `is_admin=False` hasta que su access_token expirara (1h default Supabase) o hiciera login fresh.

Fix en `template/src/api/deps.py`: si el email del JWT coincide con `APP_ADMIN_EMAIL` (el bootstrap ya le otorgó admin en Supabase), forzamos `is_admin=True` sin depender del claim del JWT. Cero impacto en roles asignados dinámicamente vía panel — solo cubre el admin bootstrap.

**Skills heredadas en `.agents/skills/`**: las apps cliente recién creadas no tenían skills útiles a mano (fastapi, supabase). Añadidas dos skills genéricas en `template/.agents/skills/` (`fastapi`, `supabase`) que viajan con cada repo nuevo y se sincronizan en cada "Actualizar common".

### Removed — `tmp/` desaparece del template

`template/tmp/.gitkeep` + la regla `tmp/* + !tmp/.gitkeep` del `.gitignore` venían del `app-backend` (la regla `.cursor/rules/scratch-files.mdc` exige que los artefactos de debug del backend vivan ahí). Las apps cliente productivas no necesitan ese directorio y aparecía vacío en cada repo `app-*` recién clonado.

Apps existentes: el sync de `update_common_pr` propagará el `.gitignore` nuevo en el próximo "Actualizar common". La carpeta `tmp/` existente en el repo de la app no se borra automáticamente (el flow es create/update-only); eliminarla manualmente o ignorar.

### Changed — Sidebar activo deriva del color de marca (tokens semánticos)

`.sidebar-link-active` hardcodeaba `bg-brand-lime/20 text-brand-dark` (lime + navy fijos): en dark mode el texto navy se fundía con la superficie y el botón activo quedaba ilegible; en light mode jamás se adaptaba al brand color del cliente.

Ahora usa dos tokens nuevos en `tokens.css`:

- `--color-sidebar-active-bg`: `color-mix(in srgb, var(--color-brand-primary) 18%, transparent)` en light, 22% en dark. Se deriva del primary del cliente automáticamente.
- `--color-sidebar-active-text`: `var(--color-on-primary)` en light (texto contrastado por la heurística WCAG del agente `design_to_tokens`); `var(--color-brand-primary)` en dark para que el label e icono resalten sobre superficie navy en vez de fundirse.

El cliente puede sobrescribir ambos tokens en su `tokens-override.css` si quiere customizar (default deriva del brand color). El prompt del agente `design_to_tokens` (en `app-backend/src/agents/prompts/design_to_tokens.md`) ahora lista estos dos tokens como **recomendados** (no obligatorios — el validator del CSS no los exige para no romper brand designs previos).

Recompilado `tailwind.compiled.css` para que la regla nueva viaje sin requerir build del consumidor (parche directo del bloque `.sidebar-link-active{...}`).

## [0.7.8] — 2026-05-16

### Fixed — Tres bugs visibles en la app desplegada

- **`/logout` daba 404**: el layout shared del paquete (`dg/layouts/sidebar_shell.html:78`) hace `POST` a `/logout` por default. El template solo tenía `POST /auth/logout`. Añadido alias `POST /logout` en `template/src/api/auth.py` que clear cookies + redirect a `/login`. Ambos endpoints ahora hacen `clear_session(response)` (antes el cookie sobrevivía al logout).
- **Dashboard renderizaba `{{ user.email }}` literal**: el template pasaba la interpolación como STRING al macro `page_header` (`subtitle="Bienvenido/a, {{ user.email }}"`), Jinja no re-evalúa el contenido de un parámetro string. Cambiado a concatenación: `subtitle="Bienvenido/a, " ~ user.email`.
- **Sidebar sin "Administración" y topbar sin icono admin para `APP_ADMIN_EMAIL`**: `bootstrap_admin_from_env` asignaba el rol `admin` en la tabla `app_role` pero NO sincronizaba `app_metadata.role` en Supabase Auth. `require_auth.is_admin` lee del JWT (que viene de `app_metadata`), así que el rol nunca llegaba. Ahora tras `set_user_roles` se invoca `update_user_role(user_id, "admin")` del paquete, que llama a `admin.update_user_by_id` de Supabase. El usuario debe relogearse para recibir el nuevo JWT con el rol.

## [0.7.7] — 2026-05-16

### Changed — Bundle de marca del cliente vive en `src/static/brand/` del repo

Antes el deployer inyectaba un `<link rel="stylesheet" href="https://backend.../branddesign/<slug>/tokens-override.css">` en `base.html` y `login.html`, fetch runtime al backend. Ahora el deployer COPIA el bundle al repo de la instance via GitHub Contents API:

- `src/static/brand/tokens-override.css` (desde `BrandDesign.tokens_override_css`).
- `src/static/brand/meta.json` con `{name, logo_url}` (logo_url es ruta local, no externa).
- `src/static/brand/logo.<ext>` desde `ClientAsset` kind=logo si existe.

El template `base.html` y `login.html` cargan `<link rel="stylesheet" href="/static/brand/tokens-override.css">` directo — sin marker `INSTANCE_TOKENS_OVERRIDE_LINK`, sin fetch al backend, cero runtime dependency. `auth.py:login_page` lee `meta.json` del filesystem para nombre y logo.

### Removed — Env vars `BRAND_*` y `SUPABASE_JWT_AUDIENCE`

Eliminadas del `.env.example` del template:

- `BRAND_CLIENT_NAME`, `BRAND_LOGO_URL`, `BRAND_PRIMARY_COLOR`: el branding viene íntegro del bundle (`meta.json` + `tokens-override.css` + `logo.<ext>`), no de envs.
- `SUPABASE_JWT_AUDIENCE`: el código usa `"authenticated"` por defecto. Solo override si tu proyecto Supabase usa audience custom (raro). Antes la env vacía rompía `jwt.decode(audience="")` con "Audience doesn't match".

Apps existentes con estas keys en su `.env.example`: `update_common_pr` (en `app-backend`) las filtra automáticamente al ejecutar "Actualizar common" — el PR drop-ea las obsoletas además de añadir las nuevas.

### Fixed — `verify_supabase_jwt` rechazaba todos los JWT con `audience=""`

Síntoma: login Supabase devuelve 200 (`sign_in_with_password` OK), cookies `dg_session`/`dg_session_refresh` se setean, pero el siguiente `GET /` cae con `verify_jwt_failed_access error="Audience doesn't match" audience="" has_secret=true`. El refresh también falla (`verify_jwt_failed_refreshed`), bucle 303 a `/login`.

Causa: `_get_audience()` usaba `os.getenv("SUPABASE_JWT_AUDIENCE", _DEFAULT_AUDIENCE)`. `os.getenv` aplica el default SOLO si la var no existe; si está definida pero vacía (caso típico cuando Easypanel materializa `SUPABASE_JWT_AUDIENCE=` sin valor en el `.env`), devuelve `""`. `jwt.decode(token, secret, algorithms=["HS256"], audience="")` rechaza cualquier JWT con `aud="authenticated"` (todos los JWTs de Supabase).

Fix: `_get_audience()` ahora trata cualquier valor vacío/whitespace como "no configurado" y cae al default `"authenticated"`. Mismo patrón aplicado a `_get_jwt_secret()` para robustez ante valores con whitespace.

## [0.7.6] — 2026-05-16

### Added — Tokens semánticos de contraste `--color-on-primary` / `--color-on-secondary`

`tokens.css` del paquete declara dos tokens nuevos para resolver el contraste de texto sobre los brand colors: `--color-on-primary` (default `#1e293b` navy, WCAG AA sobre el lime Datagrowth) y `--color-on-secondary` (default `#ffffff` sobre el navy Datagrowth). El template `login.html` usa `color: var(--color-on-primary, #1e293b)` en el botón primario — antes era `color: #fff` hardcoded, ilegible sobre lime.

El cliente sobrescribe estos tokens en su `tokens-override.css` cuando su primary es oscuro (texto blanco) o claro (texto navy). El prompt de `design_to_tokens` (en `app-backend`, no en el paquete) genera ambos tokens automáticamente con heurística de luminance. Variables **recomendadas, no obligatorias** — el validator no rechaza CSS sin ellas para no romper brand designs viejos.

## [0.7.5] — 2026-05-16

### Added — Skill `modular-design` en el template

Nueva skill `template/.claude/skills/modular-design/SKILL.md` que documenta el contrato de modularidad para todos los elementos de diseño que viven en una app generada (logos, colores, tipos, copy, layouts, componentes Jinja). Regla: cualquier asset visual debe ser sustituible sin tocar código, vía CSS tokens override (`tokens-override.css` del cliente) o vía env vars (`BRAND_*`). Cuando el control plane despliegue para un cliente, los assets del cliente machacan los del template sin requerir un build distinto.

### Changed — Defaults Datagrowth en `template/infra/.env.example`

Para que el desarrollo de la app NO se vea "gris sin colores" antes de cualquier deploy a cliente, los defaults van con valores Datagrowth:

- `BRAND_CLIENT_NAME=Datagrowth`
- `BRAND_LOGO_URL=https://datagrowth.es/favicon.ico`
- `BRAND_PRIMARY_COLOR` eliminado del flujo — el color primario se resuelve en CSS vía `var(--color-brand-primary)` del `tokens.css` del paquete (lime Datagrowth por defecto), no via env var. Cliente lo sobrescribe con su `tokens-override.css` que el deployer inyecta en `base.html`.

El control plane (`app-backend`) sobrescribe `BRAND_CLIENT_NAME` con `client_obj.name` cuando despliega para un cliente, así que el cliente NO ve "Datagrowth" en su login. `BRAND_LOGO_URL` queda vacío en deploy cliente hasta que se implemente resolución de logo desde `tool_logos`.

### Changed — `login.html` usa CSS tokens en vez de env vars para color

`--primary` ya no se interpola desde Jinja con la env var `BRAND_PRIMARY_COLOR`. Ahora es `var(--color-brand-primary, #b5ff82)`. El fallback `#b5ff82` (lime Datagrowth) cubre el caso edge en que `tokens.css` no haya cargado.

`BRAND_PRIMARY_COLOR` eliminada del flujo: el color del cliente viaja vía `tokens-override.css` (generado por el agente `design_to_tokens` desde el bundle de marca DESIGN.md + preview.html + tokensheet.html), no por env var.

### Added — Tokens semánticos de contraste `--color-on-primary` / `--color-on-secondary`

`tokens.css` del paquete declara dos tokens nuevos para resolver el contraste de texto sobre los brand colors: `--color-on-primary` (default `#1e293b` navy, contraste WCAG AA sobre el lime Datagrowth) y `--color-on-secondary` (default `#ffffff` sobre el navy Datagrowth). El template `login.html` usa `var(--color-on-primary, #1e293b)` en el botón primario — antes era `color: #fff` hardcoded, ilegible sobre lime.

El cliente sobrescribe estos tokens en su `tokens-override.css` cuando su primary es oscuro (texto blanco) o claro (texto navy). El agente `design_to_tokens` los genera automáticamente: el prompt incluye la heurística de luminance (>0.55 → texto oscuro, en otro caso → texto claro). Las dos variables son **recomendadas, no obligatorias** — el validator no rechaza CSS sin ellas para no romper brand designs viejos. Al regenerar el CSS de un cliente existente, el agente las añadirá.

### Added — Logging diagnóstico en `require_auth`

Antes, si `verify_supabase_jwt` fallaba (ej. `SUPABASE_JWT_SECRET` missing en el container), `require_auth` silenciaba la excepción y devolvía 401/redirect sin pista del motivo. Ahora cuando verify falla se emite `warning verify_jwt_failed_access` con el error truncado + flags `has_secret` y `audience`, y análogo para el path de refresh (`verify_jwt_failed_refreshed`, `refresh_session_failed`). El operador ve por qué el login no engancha sin tener que parchear código en el contenedor.

### Changed — Marker de tokens-override también en `login.html`

`login.html` lleva ahora el mismo bloque `<!-- INSTANCE_TOKENS_OVERRIDE_LINK_START/END -->` que `base.html`. El `instance_deployer` itera sobre ambos archivos y los patchea con el `<link>` al `tokens-override.css` del cliente. Resultado: el login del cliente se ve con SU paleta y tipografía, no las defaults Datagrowth. Para apps pre-0.7.5 (sin marker en login), el deployer salta el archivo sin bloquear el deploy (compatibilidad hacia atrás).

### Comentario explícito de modularidad en `template/src/templates/auth/login.html`

El template del login lleva un bloque de comentario apuntando a la skill `modular-design`: cualquier color hardcodeado, ruta de logo o string de marca debe ir vía `branding.*` o vía CSS custom property, nunca como literal.

## [0.7.4] — 2026-05-16

### Fixed — `login.html` envolvía las variables Jinja en `{% raw %}`

Todo el bloque interactivo del template (`{{ branding.client_name }}`, `{% if 'google' in providers %}`, etc.) estaba envuelto en `{% raw %}...{% endraw %}`, así que Jinja no lo procesaba y el navegador veía los tags literales. Reescrito sin `{% raw %}`, con import de tokens vía `<link href="/static/dg-common/css/tokens.css">` para que los colores corporativos lleguen al login standalone, y mensaje de error visible cuando `?error=invalid-credentials` aparece en la URL.

### Fixed — `auth_password` devolvía JSON al navegador en vez de hacer redirect

`POST /auth/password` desde el form clásico devolvía `ok_response(_session_payload(session))` (JSON con access/refresh tokens) y el navegador pintaba el blob en pantalla. Ahora distingue por `Accept`:

- `text/html` (form clásico): setea cookies httpOnly `dg_session` + `dg_refresh` con `datagrowth_common.auth.session.set_session` y redirige a `/` con 303. Si las credenciales fallan, redirige a `/login?error=invalid-credentials`.
- API/JSON: comportamiento previo, `ApiResponse` con tokens para que clientes móviles / fetch gestionen la sesión.

### Fixed — `require_auth` redirige a `/login` en lugar de devolver 401 JSON para navegadores

Cuando un usuario entraba a la raíz de una app generada sin cookie de sesión, `require_auth` lanzaba `HTTPException(401, detail={"code":"UNAUTHORIZED","message":"invalid-session"})` y FastAPI lo serializaba como JSON. El navegador mostraba un blob `{"detail":{"code":"UNAUTHORIZED",...}}` sin pantalla de login.

Fix en `template/src/api/deps.py`: si el header `Accept` incluye `text/html`, `require_auth` lanza `HTTPException(303)` con `Location: /login`. El navegador redirige al login. Clientes API (curl, fetch sin Accept HTML) siguen recibiendo el 401 JSON para parseo de error.

Propagación a apps existentes: `app-backend/src/control/update_common_pr.py` añade `src/api/deps.py` a `_SYNC_FILES`. El siguiente "Actualizar common" abre un PR con el deps.py al día.

### Fixed — race condition cross-process en `apply_migrations`

`apply_migrations` no protegía la lectura de `_dg_applied_migrations` ni
la ejecución de cada SQL contra ejecuciones paralelas. Cuando el
container de la app generada arrancaba con `--workers 2` (default
anterior del template), los dos procesos uvicorn entraban al lifespan
en paralelo, ambos leían la tabla de control vacía y ambos intentaban
aplicar v1 — el segundo cascaba con
`duplicate key ... pg_type_typname_nsp_index` en `CREATE TYPE app_role`
y dejaba el container en crash loop.

Fix: adquirir `pg_advisory_lock(_MIGRATION_LOCK_KEY)` session-level al
abrir la conexión, antes del bootstrap. El segundo worker queda
bloqueado en la llamada hasta que el primero libera el lock; cuando
entra, ve la tabla de control llena y skip-ea todo.

### Changed — `template/infra/Dockerfile` arranca con `--workers 1`

Defensa en profundidad: aunque el advisory lock resuelve la race, mover
el default a un solo worker elimina el problema de raíz para apps
generadas con versiones del template anteriores al fix. Para la carga
típica de una app generada un worker uvicorn async basta. Subir a >1
worker en una app concreta sigue siendo opt-in editando su
`infra/Dockerfile`.

## [0.7.2] — 2026-05-16

### Added — Auto-migration en startup de la app generada

Nuevo módulo `datagrowth_common.migrations` con
`apply_migrations(migrations_dir, *, db_url=None)`. El template (lifespan
de `src/main.py`) lo invoca al arrancar para aplicar `migrations/*.sql`
automáticamente contra el Postgres del cliente. Idempotente con tracking
en `dg_internal._dg_applied_migrations` (mismo esquema que ya usaba
`app-backend/src/lib/supabase_migrations.py` — apps con tablas ya
creadas saltan los archivos vía la tabla de tracking).

**Por qué**: hasta ahora el control plane (`app-backend`) aplicaba las
migrations contra el Postgres del cliente desde fuera. Eso requería
acceso TCP del backend al Postgres del cliente — viable solo si están
en el mismo VPS y misma red Docker. Mover las migrations al startup del
container generado:

- Habilita despliegues a clientes en Easypanels de **otros VPS**.
- Elimina la necesidad de exponer Postgres públicamente.
- Cada container resuelve `db:5432` en su propia red docker; sin
  conflictos DNS entre múltiples Supabase coexistentes.

### Fixed — Template del compose y Dockerfile alineados con el patrón del backend

- **`template/infra/Dockerfile`**: añadido `COPY migrations/ ./migrations/`.
  Sin esta línea el lifespan invocaba
  `apply_migrations(_MIGRATIONS_DIR)` apuntando a `/app/migrations`
  inexistente y log decía `migrations_dir_missing` silenciosamente.

- **`template/infra/docker-compose.yml`**: añadido `env_file: - ../.env`
  en el primer servicio. Easypanel materializa las env vars del modal
  Environment en `code/.env` (raíz del repo clonado) cuando
  `createDotEnv: True` (default del `services.compose.updateEnv`).
  El compose vive en `infra/`, por eso el path relativo correcto es
  `../.env`. Mismo patrón que `app-backend/infra/docker-compose.yml`
  (que funciona desde siempre). Sin esta línea el container arrancaba
  sin credenciales y el lifespan reventaba con
  `database-url-not-configured`.

### Changed
- `template/src/main.py`: el lifespan llama `apply_migrations` antes de
  `bootstrap_admin_from_env`. Si falla, `raise` para que el container
  entre en crash loop. Easypanel marca el container unhealthy y el
  operador inspecciona logs desde la UI.
- `template/src/db.py`: docstring actualizada — las migrations ya no
  las aplica el operador manualmente.
- `template/pyproject.toml`: pin `datagrowth-common[supabase]>=0.7.0,<0.8`
  (era `>=0.6.2,<0.7`).
- `pyproject.toml`: nueva optional dependency `[postgres]` con
  `psycopg[binary]>=3.2`. El template la trae directamente; las apps
  que solo usan auth/UI no necesitan psycopg.

### Module exports
- `datagrowth_common.apply_migrations` (nuevo, exportado en `__init__`).

### Migración para apps existentes

- Apps con tablas ya creadas: el primer arranque con 0.7.2 ve los
  archivos en `_dg_applied_migrations` y los salta. Sin acción manual
  sobre BD.
- "Actualizar common" en `/packages/<slug>` del control plane bumpea el
  pin + sincroniza archivos de infra (Dockerfile, docker-compose.yml) +
  añade migrations nuevas, **y** parchea `src/main.py` automáticamente
  para añadir el hook `apply_migrations(...)` al lifespan
  (`_patch_main_for_lifespan_migrations`).
- Si el `src/main.py` del package está customizado y el patcher no
  reconoce su estructura, el body del PR incluye el snippet exacto a
  añadir a mano.

**Migración del control plane (`app-backend`)**:
- En el release alineado: el deployer elimina su paso de migrations,
  añade polling al `/healthz` del deploy publicado para detectar
  fallos, normaliza `env_file: - ../.env` en el compose (idempotente
  contra apps generadas pre-0.7.2) y configura el dominio Easypanel
  con `composeService` + `port=8000` para que Traefik enrute al puerto
  correcto.

## [0.6.3] — 2026-05-15

### Changed — Template `infra/docker-compose.yml`: quitar `env_file: .env`

Easypanel inyecta las variables de entorno de los Compose services via
su propio `docker-compose.override.yml` (generado al guardar la pestaña
"Environment" / `services.compose.updateEnv`), no via un archivo `.env`
físico al lado del compose. Con `env_file: .env` declarado en el
template, `docker compose up` fallaba con:

```
env file /etc/easypanel/projects/<proj>/<svc>/code/infra/.env not found
Command failed with exit code 1
```

- **Eliminada** la directiva `env_file: .env` de
  `template/infra/docker-compose.yml`. El servicio sigue recibiendo
  todas sus env vars via el override de Easypanel.
- **Para deployment fuera de Easypanel** (bundle a cliente externo), el
  operador genera `.env` en la raíz y pasa `--env-file=../.env` al
  `docker compose` desde `infra/`.

Apps existentes (`app-*`) heredan este cambio al pulsar "Actualizar
common" en `/packages/<slug>` (ver skill `update-package-common`). Las
instances dev auto-desplegadas reciben además un parche idempotente en
`app-backend/src/control/instance_deployer.py:_patch_compose_env_file_via_api`
que elimina el `env_file:` del compose del repo de la instance en cada
deploy — cubre apps que no hayan corrido todavía el update-common.

## [0.6.2] — 2026-05-14

### Changed — Template `src/api/admin_users.py`: admin bypass + dev fall-through en `require_perm`

Paridad con `app-backend/src/api/admin_users.py:_make_perm_dep`. Hasta
ahora, el template usaba `make_require_permission` upstream directamente
para gatear los endpoints `/admin/users/*`. Eso obligaba a que el admin
estuviera sembrado en `user_role` con rol `admin` para acceder; si el
bootstrap (`bootstrap_admin_from_env`) fallaba por red/Supabase, el
admin recibía 403 hasta el siguiente arranque, y en tests/dev sin
bootstrap todo endpoint admin reventaba con `permissions-lookup-failed`.

- **Factory local `_make_perm_dep(permission)`** sustituye al
  `make_require_permission` upstream para los deps que usa
  `make_users_router`. Política:
  - `AuthUserModel.is_admin = True` → bypass (no consulta BD). El admin
    tiene todo el catálogo por construcción (`SYSTEM_ROLES["admin"]`).
  - `DG_ENV != production` → fall-through (devuelve `actor` sin
    consultar perms). Permite que tests y dev sin sembrar la tabla RBAC
    no revienten.
  - `DG_ENV = production` → query `effective_permissions` y deny con
    403 si falta el permiso o el lookup peta.
- La sección "Administración" del sidebar template
  (`template/src/templates/partials/sidebar_nav.html`) ya estaba gated
  por `user.is_admin` — sin cambios.
- Para forzar denegación en un test específico, override el dep en la
  fixture: `app.dependency_overrides[_require_users_manage] = _deny`.

## [0.6.1] — 2026-05-14

### Changed — Template `infra/docker-compose.yml`

Las apps generadas que se despliegan en Easypanel desde el `app-backend`
(flow auto-deploy del package recién scaffolded) necesitan que el
compose service arranque sin depender de una imagen Docker publicada en
GHCR. El workflow `template/.github/workflows/deploy.yml` solo se
dispara en `release: published`, así que un repo recién scaffolded sin
release todavía no tiene imagen y el compose `image: ghcr.io/...` fallaba.

- **`image: ghcr.io/datagrowth/${APP_SLUG}` → `build: {context: .., dockerfile: infra/Dockerfile}`.**
  Easypanel clona el repo y construye la imagen localmente con
  `docker compose build` antes de `up`. Funciona desde el primer commit
  scaffolded sin necesidad de release previa. El workflow `deploy.yml`
  sigue intacto: al publicar una release, la imagen se sube a GHCR y los
  bundles que entrega el `app-backend` a clientes externos sí la usan.
- **Red `n8n_supabase_default` declarada como `external: true`** y añadida
  al service `app`. Permite que el contenedor resuelva `db:5432` y
  `kong:8000` del Supabase self-hosted por hostname interno. Si el
  cliente usa Supabase Cloud, hay que quitar la red manualmente.
- **Eliminados los labels Traefik y la red `traefik_public`.** Easypanel
  gestiona su propio reverse proxy con el dominio que el deployer manda
  por `services.compose.createService(domains=[...])`. Tener labels Traefik
  manuales producía routing duplicado.
- **Nuevo `.dockerignore`** en la raíz del template para limitar el build
  context (excluye `.git`, `tests/`, `.pytest_cache/`, `.env`, etc.) y
  evitar enviar megabytes innecesarios al daemon Docker.

### Fixed — `__version__` desincronizado

`src/datagrowth_common/__init__.py` declaraba `__version__ = "0.5.0"`
mientras que `pyproject.toml` ya estaba en 0.6.0. Ambos quedan
alineados en 0.6.1.

## [0.6.0] — 2026-05-14

### Added — Fijar contraseña server-side a usuario existente

Regresión funcional respecto al panel viejo (pre-0.5.0): el nuevo panel solo permitía mandar email de reset, no fijar contraseña sin email. Útil cuando el cliente no tiene email accesible o el admin entrega credenciales en mano.

- **Nuevo endpoint** `POST /admin/users/{user_id}/password/set` con body `{password}`. Valida longitud 8-128 + una mayúscula + un dígito (mismo `_check_password` que en `create`).
- **`supabase_admin.set_user_password(user_id, password)`** — wrapper de `client.auth.admin.update_user_by_id({"password": ...})`. Devuelve `Result[None]`.
- **`service.set_user_password(db, *, actor, target_user_id, password, schema)`** — orquesta Supabase + audit log en la misma transacción del caller.
- **Audit action** `password_set` (constante `audit.ACTION_PASSWORD_SET`).
- **UI** — nuevo botón `contraseña` en cada fila de la tabla Usuarios + modal `dg-set-pwd` con input password validado. El handler postea al endpoint y avisa al admin de comunicar la contraseña por canal seguro.

### Added — UI: editor de permisos por rol

- **Modal "Editar permisos"** en `dg/admin/users_panel.html`: aparece en cada fila de la tabla Roles y abre un dialog con checkboxes del catálogo prellenados con los permisos actuales. Llama al endpoint existente `PATCH /admin/users/roles/{slug}/permissions`. Cierra el gap entre la API (que ya soportaba editar permisos desde 0.5.0) y la UI (que solo permitía crear y borrar).
- `renderPermissionPicker(selectedByDialogId)` ahora acepta preselección por dialog, mismo patrón que `renderRolePickers`.

### Changed — UI: refresh de estilos del panel

Hasta ahora los botones de fila (editar/reset/borrar/ver) eran `<button>` crudos sin clases — se renderizaban como texto, no como botones. Mismo problema en los modales (inputs sin estilos, cancel/submit sin variants).

- Tablas (Usuarios / Roles / Audit log) ahora usan los componentes `table-wrapper` / `table-base` / `table-thead` / `table-tr` / `table-td` del paquete, con hover y separadores correctos.
- Botones de fila usan `btn btn-sm btn-ghost` (`btn btn-sm btn-ghost text-semantic-danger` para borrar).
- Modales `<dialog>` reciben clase `.dg-dialog` con un bloque `<style>` local: padding, panel bg, border, sombra modal + `::backdrop` con blur. Antes solo tenían `rounded-xl p-6` y heredaban el bg del navegador.
- Inputs de los modales usan `form-input` / `form-input-mono`. Labels usan `form-label` y hints `form-hint`.
- Submit primary / Cancel ghost en todos los modales — antes solo el submit tenía `font-semibold`.
- Roles del usuario se muestran como `badge badge-brand` en lugar de texto separado por comas.
- Permisos de rol se muestran como chips `code` con fondo `surface-subtle` en lugar de listado separado por comas.
- Tabs con underline animado (clase `.dg-tab`).

### Changed — `template/` ahora usa el panel RBAC nuevo

El skeleton de apps generadas montaba un router custom contra `public.app_role` (single-tenant, email + is_admin). Ahora monta `make_users_router` igual que `app-backend`, dando a cada app gestión multi-rol + permisos + audit log de serie.

- **`template/src/api/admin_users.py`** reescrito: `PermissionCatalog({"users.manage": ...})`, system roles `admin` (todo) + `viewer` (vacío), `bootstrap_admin_from_env` ahora resuelve `APP_ADMIN_EMAIL` → user_id en Supabase Auth → asigna rol `admin` en `user_role` (aditivo, no revoca otros roles).
- **`template/src/db.py`** nuevo: engine SQLAlchemy + `get_session()`. Usa la misma convención de env vars que `app-backend` (`DG_DATABASE_URL` completa, o `POSTGRES_PASSWORD` + `DG_SUPABASE_DB_HOST/PORT/USER/NAME`).
- **`template/migrations/v2_users_rbac.sql`** nuevo: crea `role`, `user_role`, `role_permission`, `user_audit_log` + **backfill automático** desde `app_role` legacy cruzando email con `auth.users`.
- **`template/src/templates/admin/users_panel.html`** nuevo: wrapper que extiende `base.html` e incluye `dg/admin/users_panel.html`. Sin esto el panel se renderiza sin sidebar ni Tailwind.
- **`template/pyproject.toml`**: añadidas deps `sqlalchemy>=2.0` y `psycopg[binary]>=3.2`. Pin de `datagrowth-common[supabase]` movido a `>=0.6.0,<0.7`.
- **`template/infra/.env.example`**: documentadas las nuevas vars `DG_DATABASE_URL` / `POSTGRES_PASSWORD` / `DG_SUPABASE_DB_*` + `APP_ADMIN_EMAIL`.
- **`template/infra/docker-compose.yml`**: comentarios para sumar la red Docker de Supabase self-hosted (`n8n_supabase_default`) cuando el hostname `db` debe resolver desde el contenedor.

### Removed

- `template/src/templates/admin/users.html` y `users_new.html` (panel viejo basado en `app_role`).

### Migration guide — apps cliente que vienen de 0.5.x o anteriores

1. Aplicar `migrations/v2_users_rbac.sql` al Supabase del cliente. El backfill `DO $$` mueve los `is_admin=true` actuales a asignaciones del rol `admin` sin tocar datos manualmente. **Importante**: el bloque de backfill hace `JOIN auth.users`, así que aplícala desde el SQL Editor del Dashboard de Supabase (ejecuta como `postgres`) o vía `psql` con `service_role`. Con un rol normal el JOIN devuelve 0 filas y los admins legacy no migran.
2. Configurar las nuevas env vars de Postgres directo (`DG_DATABASE_URL` o las piezas). Hasta ahora las apps usaban solo REST (`SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY`); el panel nuevo necesita acceso TCP.
3. Rebuild + redeploy con `datagrowth-common>=0.6.0` y el template actualizado.
4. La tabla legacy `public.app_role` queda sin uso. Se puede borrar manualmente tras verificar que `user_role` tiene a los admins esperados.

### Notes

- Bump minor (0.5.0 → 0.6.0): la API pública del paquete sigue siendo compatible; lo que cambia (breaking) es el contrato del `template/` con las apps existentes (nuevas env vars + migración SQL).

## [0.5.0] — 2026-05-12

### Added — Módulo `datagrowth_common.users` (gestión de usuarios + RBAC reutilizable)

Sustituye al router limitado `datagrowth_common.api.users` por un módulo completo que las apps montan con `make_users_router(...)`. Permite que el backend Datagrowth y cualquier app generada compartan la misma sección de "Gestionar usuarios" contra su propio Supabase + tablas locales.

- **`PermissionCatalog`** — catálogo de permisos declarado en código (`{"runs.read": "Ver runs", ...}`). La BD solo guarda asignaciones, no el catálogo. Valida claves con regex `^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$`.
- **`make_users_router(catalog, deps, mount_prefix, schema, templates)`** — factory de `APIRouter` con 13 endpoints: HTML del panel, listado de usuarios con roles, invite + create con password, update roles, password reset, delete, permisos efectivos, CRUD de roles, audit log paginado. Commit/rollback explícito por handler.
- **`make_require_permission(perm, ...)`** — FastAPI dep que resuelve permisos efectivos (`user_role ⋈ role_permission`) con cache por request. Deniega por defecto.
- **`bootstrap_roles(db, system_roles, catalog)`** — idempotente: upserts roles del sistema + poda `role_permission` huérfanos. Refusa borrar si el catalog está vacío (defensa contra bug de import).
- **Audit log** — toda mutación escribe entrada en `user_audit_log` en la misma transacción del caller. Acciones canónicas: `invite`, `create_password`, `role_grant`, `role_revoke`, `password_reset_sent`, `delete`, `role_created`, `role_deleted`, `role_permissions_updated`.
- **Compensación Supabase ↔ BD** — si Supabase crea el usuario pero la BD falla, `_compensate_supabase_create` intenta borrarlo (best-effort, logueado). La operación no es atómica por naturaleza (side-effect externo).
- **Migración** — `datagrowth_common/users/migrations/001_users_rbac.sql` crea tablas `role`, `user_role`, `role_permission`, `user_audit_log` con FKs `ON DELETE CASCADE` e índices.
- **UI** — `dg/admin/users_panel.html` reescrita: 3 pestañas (Usuarios / Roles / Audit), multi-rol con pickers, modal de permisos efectivos, vanilla JS + `fetch` (sin HTMX). Sin innerHTML con interpolación de strings de usuario (defensa XSS por `createElement` + `textContent`).

### Changed

- **`datagrowth_common/api/users.py`** se conserva por compatibilidad pero queda deprecado. Las apps deben migrar a `datagrowth_common.users.make_users_router`.
- Nueva dep obligatoria: `sqlalchemy>=2.0`. El repository usa `text()` con bind params nombrados; compatible con `sqlmodel.Session` y `sqlalchemy.Connection`.

### Security

- Identificadores SQL (schema + tabla) compuestos en `_ident()` se validan con whitelist regex `^[a-z_][a-z0-9_]{0,62}$` antes de interpolar. Toda query usa bind params.
- `password` en `CreatePasswordBody` se valida con `field_validator` (pydantic v2 usa regex Rust, no soporta look-around): longitud 8-128 + al menos una mayúscula + al menos un dígito.

### Notes

- Bump minor (0.4.4 → 0.5.0): API pública nueva, nada se elimina. Apps con pin `>=0.4,<0.5` deben relajar a `>=0.5,<0.6` (o `>=0.4,<0.6` para coexistencia).
- Consumidores típicos:
  - `app-backend`: monta el router en `/admin/users` con schema `"backend"` (ver `migrations/v44.sql` que mapea `dev_role` legacy a la nueva estructura).
  - Apps cliente: aplican `001_users_rbac.sql` sobre su Supabase y montan el router con `schema=""` (default `public`).

## [0.4.4] — 2026-05-12

### Fixed — Componentes Jinja del paquete con texto ilegible en dark

- **`dg/components/page_header.html`**: `h1` era `text-slate-900` (ilegible 1.76:1 sobre `bg-surface` dark). Refactorizado a `text-fg`. Breadcrumb a `text-fg-muted`, last crumb a `text-fg`, subtitle a `text-fg-muted`.
- **`dg/components/modal.html`**: título `text-slate-900` → `text-fg`. Botón cerrar `text-slate-400 hover:text-slate-600` → `text-fg-muted hover:text-fg`.
- **`dg/components/empty_state.html`**: título `text-slate-700` → `text-fg`. Descripción `text-slate-400` → `text-fg-muted`. Icono container `bg-slate-100 text-slate-300` → `bg-surface-subtle text-fg-muted`.
- **`dg/components/data_table.html`**: empty row `text-slate-400` → `text-fg-muted`.
- **`dg/components/paginated_table.html`**: footer `text-slate-500` → `text-fg-muted`, `text-slate-700` → `text-fg`.
- **`dg/components/command_palette.html`**: iconos/placeholders/kbd `text-slate-400` → `text-fg-muted`. Input `text-slate-900` → `text-fg`. Lista `text-slate-700` → `text-fg`.
- **`dg/components/toast.html`**: contenido `text-slate-900` → `text-fg`. Botón cerrar `text-slate-400 hover:text-slate-600` → `text-fg-muted hover:text-fg`.
- **`dg/components/skeleton.html`**: `bg-slate-200` → `bg-border`.
- **`dg/admin/roles_panel.html`**: descripciones y keys a `text-fg-muted`.
- **`dg/components/sidebar_link.html`**: badge active `bg-brand-dark/20 text-brand-dark` → `bg-brand-lime text-brand-dark` (9.74:1 fijo, no depende del tema).

### Notes

- Bump patch (0.4.3 → 0.4.4). El problema afectaba a todo el chrome compartido: títulos de página, modales, toasts, empty states, tablas paginadas — todos heredaban `text-slate-*` hardcodeado. Apps consumidoras que extienden estos componentes recuperan dark mode legible sin tocar nada.

## [0.4.3] — 2026-05-12

### Added — Token `link` (accent text)

- **`--color-link` / `--color-link-hover`** en `tokens.css`: en light usa `brand-secondary` (navy), en dark usa `brand-primary` (lime). Da contraste WCAG AA en ambos temas para anchors, logos y badges con `bg-brand-lime/15`.
- **`link` / `link-hover`** en `tailwind-preset.cjs`: clases `text-link`, `hover:text-link-hover` disponibles para consumidores. Reemplaza el patrón `text-brand-dark hover:underline` que era ilegible (1.57:1) sobre superficies dark.

### Accessibility — Dark mode (continuación)

- **FOUC guard en `dg/layouts/empty.html`**: replica el patrón aplicado en 0.4.2 a `sidebar_shell.html`. Login, signup, password reset y errores también respetan la preferencia guardada antes del primer paint.
- **`text-fg` en body de `empty.html`**: era `text-slate-900` (ilegible en dark, 1.76:1 sobre `bg-surface`).

### Notes

- Bump patch (0.4.2 → 0.4.3): API Python sin cambios, solo CSS/preset/template. Pin `>=0.4,<0.5` lo coge automáticamente. Consumidores deben rebuildear su Tailwind local tras actualizar el wheel para que el preset actualizado (`link`/`link-hover`) se aplique a `app.css`.
- Apps consumidoras que usen `text-brand-dark hover:underline` como patrón de link **deben** migrar a `text-link hover:text-link-hover` para que dark mode sea legible. Sobre `bg-brand-lime` (botones/badges) seguir usando `text-brand-dark` — sigue dando 9.74:1.

## [0.4.2] — 2026-05-12

### Accessibility — Dark mode

- **FOUC eliminado**: script inline en `<head>` de `dg/layouts/sidebar_shell.html` aplica el `data-theme` antes del primer paint. Antes, con `theme.js` cargado en `defer`, los usuarios con preferencia "dark" guardada veían un flash light→dark en cada carga (problemático para fotosensibilidad).
- **`color-scheme` CSS**: declarado `color-scheme: light|dark` en `[data-theme="..."]` para que scrollbars, autofills y form controls nativos del navegador adapten al tema activo.
- **Botón toggle con estado anunciable**: añadido `data-theme-toggle` + `aria-pressed` dinámico. `theme.js` actualiza `aria-pressed` y `aria-label` ("Cambiar a tema claro" / "Cambiar a tema oscuro") en cada toggle. Antes el botón solo tenía `aria-label` estático y screen readers no anunciaban el cambio.
- **Hover del toggle legible sobre header dark**: el botón vive sobre `bg-brand-dark` (header siempre oscuro). `hover:text-slate-600` daba 2.41:1 (FAIL UI ≥3:1) — el icono se oscurecía sobre fondo oscuro. Cambiado a `text-white/60 hover:text-white hover:bg-white/10`.
- **Sync entre pestañas**: `theme.js` escucha `storage` events; cambiar el tema en una pestaña ahora actualiza el resto sin recargar.

### Fixed — Botón light/dark mode sin efecto visual

- **`tailwind-preset.cjs`**: los colores semánticos (`surface`, `panel`, `border`) estaban hardcodeados a hex (`#f8fafc`, `#ffffff`, `#e2e8f0`). Tailwind los compilaba a valores fijos en el CSS, así que `bg-surface`/`bg-panel`/`border-border` no respondían al cambio de `[data-theme="dark"]` aunque `theme.js` actualizara correctamente el atributo y los CSS vars de `tokens.css`. Ahora apuntan a `var(--color-*)`, de modo que la cascada CSS resuelve el valor según el tema activo en runtime.
- **Añadido `fg` y `surface-subtle`** al preset (`text-fg`, `text-fg-muted`, `bg-surface-subtle`) como tokens semánticos para texto y fondos sutiles. Permiten escribir `text-fg` en lugar de `text-slate-900` y obtener auto-switch light/dark.
- **`tokens.css`**: nuevo token `--color-surface-subtle` con valores para light (`#f1f5f9`) y dark (`#1a2e40`).
- **`_tailwind.source.css`**: component classes (`.card-title`, `.card-body`, `.btn-ghost`, `.badge-neutral`, `.table-thead`, `.table-tr:hover`, `.form-*`, `.sidebar-link`) refactorizadas a tokens semánticos (`text-fg`, `text-fg-muted`, `bg-surface-subtle`) en lugar de `text-slate-*`/`bg-slate-*`. Las apps consumidoras ven dark mode funcional sin tocar sus templates.
- **`dg/layouts/sidebar_shell.html`**: el `<body>` usa `text-fg` en vez de `text-slate-900`.

### Notes

- Bump patch (0.4.1 → 0.4.2): API Python sin cambios, solo CSS/preset/template. Pin `>=0.4,<0.5` lo coge automáticamente. Consumidores deben rebuildear su Tailwind local tras actualizar el wheel para que el preset actualizado se aplique a `app.css`.
- Alineado `__version__` con `pyproject.toml` (estaba en 0.3.2 desde antes de 0.4.0).

## [0.4.1] — 2026-05-12

### Changed — preset Tailwind dentro del wheel (PyPI = única fuente de verdad)

- **`src/datagrowth_common/ui/tailwind-preset.cjs`**: el fichero (introducido en 0.4.0 en la raíz del repo) se mueve dentro del paquete Python. Hatchling lo empaqueta en el wheel (verificado: `python -m zipfile -l` lista `datagrowth_common/ui/tailwind-preset.cjs` en el `.whl`). Los consumidores resuelven la ruta del fichero desde la instalación pip (`importlib.resources` o `os.path.dirname(datagrowth_common.ui.__file__)`).
- **Eliminado `package.json` raíz**: el paquete ya no se distribuye via npm. Consumirlo via `github:...#tag` resultaba inconsistente: `datagrowth-common` ya está en PyPI; tener una segunda fuente (GitHub) solo para un fichero JS introducía deps cross-channel innecesarias y requería `git` + reglas SSH→HTTPS dentro de imágenes Alpine.
- **`tailwind.config.js`**: ajustado el require para apuntar a `./src/datagrowth_common/ui/tailwind-preset.cjs`.

### Notes

- Bump patch (0.4.0 → 0.4.1) porque la API Python no cambia, solo la ubicación del asset JS. Consumidores con pin `>=0.4,<0.5` cogerán este release automáticamente.
- Consumir el preset en el frontend-build de Docker (node sin python) requiere un stage Python previo que pip-instale el paquete y `COPY` el `.cjs` al stage de node. Ver `app-backend/infra/Dockerfile` como referencia.

## [0.4.0] — 2026-05-12

### Added — Tailwind preset distribuido (`tailwind-preset.cjs`)

- **`tailwind-preset.cjs`** en la raíz del repo: contiene `theme.extend` (paleta brand, semantic, surfaces, fonts, radii, shadows, spacing) + `safelist` con las variantes responsive (`sm:block`, `sm:inline-flex`, `md:flex`, `md:grid-cols-2`, `md:px-6`, `lg:grid-cols-3`) que usan los layouts `dg/...`. Single source of truth para tokens y para las clases que de otro modo serían pisadas por la cascada CSS de un consumidor con Tailwind local.
- **`package.json`** en la raíz: expone el paquete como `datagrowth-common-ui` (instalable via `npm install github:datagrowth/datagrowth-common#0.4.0`) con `main: tailwind-preset.cjs`. Sin npm registry — los consumidores resuelven la dep desde GitHub.
- **`tailwind.config.js` del paquete**: refactorizado a `presets: [require('./tailwind-preset.cjs')]`. Deduplica el `theme.extend`.

### Fixed — Cascada CSS rota cuando un consumidor compila Tailwind localmente

- **Contexto**: el `app-backend` carga su `app.css` local (Tailwind sobre `src/templates/**`) DESPUÉS del `tailwind.compiled.css` del paquete vía `extra_head` de `backend_shell.html`. Al hacerlo, su `.hidden{display:none}` redefinida sin `.md\:flex` ganaba la cascada por orden de fuente, dejando `<aside class="hidden md:flex …">` permanentemente `display:none`. El preset incluye `safelist` con las responsive variants para que el `app.css` del consumidor también las emita y `md:flex` recupere la victoria a ≥768px.
- Fix puntual aplicado en paralelo en `app-backend/tailwind.config.js`; el preset hace el fix definitivo y reutilizable.

### Notes

- Bump menor (0.3.4 → 0.4.0): añade dist npm pero no rompe contratos Python (`register_ui`, models, auth). El pin `>=0.3.2,<0.4` en consumidores **debe ampliarse** a `>=0.4,<0.5` para coger este release.

## [0.3.4] — 2026-05-11

### Changed — tokens-override URL

- **`template/src/templates/base.html`**: el comentario explicativo del bloque `INSTANCE_TOKENS_OVERRIDE_LINK_*` ahora apunta a `https://backend.dev.datagrowth.es/branddesign/<slug>/tokens-override.css` (URL real del backend Datagrowth, router público separado de la galería admin `/tools/branddesign/`).
- **`docs/UI.md`**: ejemplo de `tokens_override_href` actualizado a la URL real.
- **`src/datagrowth_common/ui/static/css/tokens.css`**: comentario de override apunta a `/branddesign/<slug>/tokens-override.css` (sin `/tools/`).

> Acompaña el split del router en `app-backend` (`src/api/branddesign.py`): el endpoint runtime `tokens-override.css` queda en `/branddesign/{slug}/...` (público sin auth) separado del prefix admin `/tools/branddesign/` (CRUD, preview, comparar, regenerate).

## [0.3.3] — 2026-05-11

### Changed — instalación desde PyPI

- `template/infra/Dockerfile`: reescrito a un build multi-stage minimalista que instala `datagrowth-common[supabase]` desde PyPI en build-time. Sin Node, sin git, sin `GITHUB_TOKEN`.
- `template/infra/entrypoint.sh`: eliminado. Ya no es necesario instalar dependencias en runtime.
- `template/pyproject.toml`: pin `datagrowth-common[supabase]>=0.3.2,<0.4`. Eliminadas dependencias vestigiales (`aiofiles`, `httpx`, `python-multipart` — vienen via `datagrowth-common`).
- `template/infra/.env.example`: removida la variable `GITHUB_TOKEN`.
- `app-backend/templates/skeletons/app-fastapi-supabase/infra/entrypoint.sh`: bumpeado `DG_COMMON_REF` `v0.2.2` → `v0.3.2` (este skeleton aún lo usa el pipeline antiguo del backend; se eliminará cuando se reescriba).

## [0.3.2] — 2026-05-11

### Fixed

- **wheel**: eliminado bloque `force-include` redundante que duplicaba todos los archivos de `ui/static/*` y `ui/templates/*` dentro del wheel.
- **sdist**: anclados los patterns de `include` con `/` para evitar que `README.md` matchee recursivamente (antes arrastraba `template/.claude/memory/README.md` y `template/README.md`).
- **runtime dep**: añadido `python-multipart>=0.0.9` a `dependencies`. Sin él, `auth_router` (que usa `Form()`) lanzaba `RuntimeError` en la primera request.

### Added — repo dual: GitHub template

- **`template/`**: scaffold FastAPI listo para apps Datagrowth, instanciable con `gh repo create --template datagrowth/datagrowth-common`.
  - `src/main.py` que llama `register_ui(app, jinja_env)` y monta `auth_router`, `users_router`, `admin_users` y `dashboard`.
  - `src/jinja_env.py` usando `ChoiceLoader` (compatible con `register_ui`).
  - `src/templates/base.html` extiende `dg/layouts/sidebar_shell.html` con marcadores `INSTANCE_TOKENS_OVERRIDE_LINK_*` para que el deployer inyecte el `<link>` al `tokens-override.css` del cliente.
  - `pyproject.toml` con pin `datagrowth-common[supabase]~=0.3.1`.
  - `tests/test_smoke.py`: arranque `/healthz` + assets `/static/dg-common/css/tokens.css` y `/static/dg-common/js/theme.js`.
  - Governance migrada desde `app-backend`: `.claude/` (agents `architect`/`reviewer`/`security-reviewer`, rules core/api-design/performance/security/scratch-files, skills `boot`/`evolution`/`evolve`/`fix-issue`/`find-skills`/`precommit`, commands incluyendo `/remember`, settings.json, HOOKS.md), `.cursor/` (commands `/start`/`/pr`/`/gc`/`/review`, rules sin atlassian).
  - Documentación de onboarding en `README.md`, `PROJECT_SPEC.md`, `PROJECT_STATE.md`, `ARCHITECTURE.md` esqueletos.
- **`docs/VISUAL_LANGUAGE.md`**: migrado desde `datagrowth-ai-template/.impeccable.md`.
- **`.github/workflows/release.yml`**: compila Tailwind antes de buildear el wheel y añade job `verify-template` que instala el wheel recién publicado contra `template/` y corre los smoke tests.

### Deprecated

- `datagrowth-ai-template` queda obsoleto: su rol se asume aquí (template + governance). Archivar el repo antiguo en GitHub.

### Changed

- `app-backend/src/control/scaffolder.py`: eliminadas las constantes `TEMPLATE_REPO` y `_TEMPLATE_DOCS` que apuntaban a `datagrowth-ai-template`. Nadie las leía.

## [0.3.1] — 2026-05-11

### Added — subpaquete `datagrowth_common.ui`

- **`datagrowth_common.ui`** — subpaquete nuevo que distribuye toda la UI compartida (Jinja2 partials + CSS + JS) dentro del wheel.
- **`register_ui(app, jinja_env, mount_path="/static/dg-common")`** — helper que añade un `PackageLoader` al `ChoiceLoader` del Jinja Environment del host y monta los assets estáticos del paquete. Devuelve `tuple[None, Exception | None]`.
- **Constante `UI_VERSION`** exportada en raíz (alineada con `__version__`).
- **20 templates** con prefijo obligatorio `dg/...`:
  - Layouts: `dg/layouts/sidebar_shell.html`, `dg/layouts/empty.html`.
  - Componentes: `badge`, `button`, `card`, `command_palette`, `data_table`, `empty_state`, `form_field`, `icon` (Lucide SVGs inline), `modal`, `page_header`, `paginated_table`, `sidebar_link`, `skeleton`, `theme_toggle`, `toast`.
  - Admin: `users_panel`, `roles_panel`, `audit_panel`.
- **Static**:
  - `static/css/tokens.css` con tema light/dark via `[data-theme]` y aliases legacy (`--color-brand-lime` → `--color-brand-primary`).
  - `static/css/_tailwind.source.css` con `@layer components` para las clases `btn-*`, `card-*`, `badge-*`, `table-*`, `form-*`, `sidebar-link*`.
  - `static/css/tailwind.compiled.css` build artifact (regenerado con `bash scripts/build_tailwind.sh`).
  - `static/js/theme.js` — toggle light/dark + persistencia en `localStorage["dg-theme"]`.
  - `static/js/toasts.js` — auto-dismiss para `[data-toast]` con listener `htmx:afterSwap`.
  - `static/js/htmx-events.js` — modales (`openModal`/`closeModal`), atajo ⌘K/Ctrl+K para command palette y toast ante `htmx:responseError`.
- **`tailwind.config.js`** en raíz del paquete y **`scripts/build_tailwind.sh`** para compilar el CSS antes de tag.
- **`pyproject.toml`** — añade `jinja2>=3.1` como dependencia core y empaqueta `ui/static` + `ui/templates` en el wheel vía `[tool.hatch.build.targets.wheel.force-include]`.
- **Tests**: 24 nuevos en `tests/ui/test_register_ui.py` (smoke de mount + Jinja loader, error path, parametrizado sobre los 20 templates, smoke de assets servidos).
- **Doc**: `docs/UI.md` con quickstart, catálogo de componentes y guía para inyectar tokens del cliente via `tokens_override_href`.

### Notes

- Subir un MAJOR no aplica: la API pública de auth/core no cambia respecto a v0.3.0. Las apps que ya consumen v0.3.0 pueden migrar a v0.3.1 sin tocar imports existentes.
- Las apps que quieran adoptar el subpaquete UI solo añaden `register_ui(app, jinja_env=templates.env)` tras instanciar `Jinja2Templates`. Los templates `dg/...` se resuelven como fallback cuando el host no define los suyos.

## [0.3.0] — 2026-05-11

### BREAKING

- **Eliminado** `datagrowth_common.authentik` (parser de cabeceras forward-auth `X-authentik-*`). Importarlo ahora lanza `ImportError`. El archivo se conserva como sentinel hasta v0.4.0.
- **Eliminado** `datagrowth_common.auth_fastapi` (deps FastAPI `require_auth`, `require_admin`, `AuthUserDep`, `AdminUserDep` basadas en forward-auth). Importarlo lanza `ImportError`.
- **Renombrado** `datagrowth_common.auth.local` → `datagrowth_common.auth.session_hmac`. Se eliminó toda la integración con Authentik OIDC: `password_login`, `refresh_token`, `userinfo`, `start_oidc`, `oidc_callback`, `register_local`, `magic_link_request`, `password_reset`, `TokenPair`, `OidcStart`. Solo se conserva la cookie HMAC propia (`encode_session`, `decode_session`, `make_session`, `set_session_cookie`, `clear_session_cookie`, `require_session`, `require_group`, `SessionUser`).
- **Removido** del export de `datagrowth_common.testing`: `mock_authentik_responses`.
- **Removido** del export raíz: `AuthUser`, `require_auth`, `require_admin`.

### Compatibilidad

- `datagrowth_common.auth.local` se conserva como alias deprecated que re-exporta desde `auth.session_hmac` y emite `DeprecationWarning` en el import. Se eliminará físicamente en v0.4.0.
- Las apps que generaba el pipeline antiguo (`app-backend/src/agents/prompts/*.md`) seguían referenciando `auth.local`. Esos prompts se reescriben en la Fase I del pivote (apps empaquetadas).

### Migration guide

| Antes (≤ v0.2.x) | Ahora (v0.3.0) |
|---|---|
| `from datagrowth_common.authentik import AuthUser` | `from datagrowth_common.auth.supabase import SupabaseUser` |
| `from datagrowth_common.auth_fastapi import require_auth, require_admin, AuthUserDep, AdminUserDep` | `from datagrowth_common.auth.session import require_session, SessionUserDep` (cookie JWT) o `from datagrowth_common.auth.supabase import require_supabase_jwt, SupabaseUserDep` (`Authorization: Bearer`) |
| `from datagrowth_common.auth.local import SessionUser, require_session, encode_session, decode_session, make_session` | `from datagrowth_common.auth.session_hmac import SessionUser, require_session, encode_session, decode_session, make_session` |
| `from datagrowth_common.auth.local import password_login, oidc_callback, magic_link_request, password_reset, register_local` | Usar `datagrowth_common.auth.router.make_auth_router()` (login email/password + OAuth + magic link + reset via Supabase) |
| `from datagrowth_common.testing import mock_authentik_responses` | Eliminado. Mockear directamente `httpx.AsyncClient` en el test. |

El modelo único de autenticación end-user en v0.3.0 es Supabase Auth:

- `auth.supabase` — `verify_supabase_jwt`, `SupabaseUser`, `require_supabase_jwt`, `SupabaseUserDep`, `require_role(role)`.
- `auth.session` — cookie httpOnly server-rendered con access + refresh JWT (`set_session`, `clear_session`, `refresh_session_tokens`, `require_session`).
- `auth.router` — `make_auth_router()` con endpoints `POST /auth/password`, `POST /auth/register`, `POST /auth/magic-link/request`, `POST /auth/password/reset`, `GET /auth/oauth/{provider}/start|callback`, `POST /auth/refresh`, `POST /logout`, `GET /api/me`.
- `auth.session_hmac` — cookie HMAC propia (fallback para apps internas que no usan Supabase Auth).

### Notas de despliegue

- Apps consumidoras que aún tengan `from datagrowth_common.authentik import ...` o `from datagrowth_common.auth_fastapi import ...` tienen que migrar antes de instalar v0.3.0. El import falla en tiempo de carga del módulo.
- `DG_ADMIN_GROUP` y `DG_USERS_GROUP` (variables de entorno del legacy forward-auth) dejan de leerse. Borrar del `.env` y de la config de Easypanel.

## [0.2.2] — 2026-04-XX

- `auth.supabase_admin` añadidos `create_user_with_password` y `send_password_reset` para flujos de gestión de usuarios end-to-end desde paneles admin (backend interno + apps generadas).

## [0.2.1] — 2026-03-XX

- Añadido `auth.session` (cookie httpOnly server-rendered con refresh).
- Añadido `auth.router` con `auth_router` + `make_auth_router` (login propio + OAuth Microsoft/Google via Supabase + refresh + logout).
- `auth.local` marcado como deprecated.

## [0.2.0] — 2026-02-XX

- Añadido `auth.supabase` (`verify_supabase_jwt`).
- Añadido `auth.supabase_admin` (Admin API: list / invite / delete users).
- Añadido `api.users.users_router`.
- Añadido `get_supabase_admin_client`.

## [0.1.0] — 2026-01-XX

- Primera release pública: `auth.local`, `authentik`, `auth_fastapi`, `result`, `logger`, `supabase`, `shared_models`, `updater`.
