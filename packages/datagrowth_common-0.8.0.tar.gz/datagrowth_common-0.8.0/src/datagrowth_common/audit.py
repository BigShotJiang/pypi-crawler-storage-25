"""Helper para registrar eventos en `user_audit_log`.

Existe paralelamente a `datagrowth_common.users.repository.insert_audit`:
ese helper no escribe `ip`/`user_agent` (columnas anadidas por la
migracion `v3_access_event.sql` del template, posterior al v2 que crea
la tabla base). Para eventos GDPR (export, delete-requested,
delete-cancelled, purged) que requieren traza legal con IP y UA, usa
este wrapper. Para auditoria RBAC el helper del modulo `users` sigue
siendo el adecuado.

`schema` por defecto es `None` (tabla `user_audit_log` sin prefijo, como
queda en el template de apps generadas). Cada app que use un schema
distinto (como `backend.user_audit_log` del control plane) lo pasa
explicitamente. El schema se valida contra un whitelist regex para que
no se pueda inyectar SQL aunque el caller pase un valor de env var.
"""

from __future__ import annotations

import json
import re
from typing import Any

from sqlalchemy import text
from sqlalchemy.orm import Session

from .logger import get_logger

log = get_logger(__name__)


# Whitelist regex para `schema` — defensa en profundidad. En uso normal
# es siempre None o `"backend"` (literal). Si alguien lo expone a env vars
# en el futuro, evita SQL injection.
_SCHEMA_RE = re.compile(r"^[a-z_][a-z0-9_]{0,62}$")

# Regex para detectar emails en strings — usado para scrubbear el
# User-Agent antes de persistirlo (algunos clientes custom embeden el
# email del operador en el UA: `app/1.0 (admin@example.com)`).
_EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")


def emit(
    session: Session,
    *,
    actor_id: str,
    target_user_id: str,
    action: str,
    metadata: dict[str, Any] | None = None,
    ip: str | None = None,
    user_agent: str | None = None,
    schema: str | None = None,
) -> tuple[bool, Exception | None]:
    """Inserta una fila en `user_audit_log`. Patron de error como valor.

    `actor_id` es quien dispara la accion (uid del request). `target_user_id`
    es a quien afecta. Para acciones self-service (export, delete-requested)
    coinciden.

    `user_agent` se scrubbea (emails crudos -> `<email>`) antes de
    persistir — algunos clientes custom embeden el email del operador.

    Devuelve `(True, None)` en exito, `(False, exc)` si la INSERT falla
    — un fallo de logging nunca debe romper el handler que lo invoca.
    """
    if schema is not None and not _SCHEMA_RE.match(schema):
        log.warning("audit_emit_invalid_schema", schema=schema)
        return False, ValueError(f"invalid-schema: {schema!r}")
    table = f"{schema}.user_audit_log" if schema else "user_audit_log"
    sql = (
        f"insert into {table} "
        "(actor_id, target_user_id, action, metadata, ip, user_agent) "
        "values (:actor, :target, :action, cast(:meta as jsonb), :ip, :ua)"
    )
    safe_ua = None
    if user_agent:
        safe_ua = _EMAIL_RE.sub("<email>", user_agent)[:500] or None
    try:
        session.execute(
            text(sql),
            {
                "actor": actor_id,
                "target": target_user_id,
                "action": action,
                "meta": json.dumps(metadata or {}, default=str),
                "ip": ip,
                "ua": safe_ua,
            },
        )
        session.commit()
        return True, None
    except Exception as exc:
        log.warning(
            "audit_emit_failed",
            action=action,
            target=target_user_id,
            error=str(exc),
        )
        return False, exc


__all__ = ["emit"]
