"""Cron de retencion: GDPR delete diferido + retencion de tablas auditables.

`make_retention_purger(session_factory, schema=None)` devuelve una
funcion `iteration() -> tuple[dict, Exception|None]` lista para
schedulear con APScheduler / arq / cron del SO.

Tres responsabilidades en una sola pasada:

1. **GDPR delete**: filas en `user_deletion_request` con
   `purge_at <= now()` se ejecutan: borrar grants RBAC del usuario +
   la propia solicitud. Se emite `user_audit_log action='data-purged'`.

2. **Retencion `user_audit_log`**: filas mas viejas que
   `DG_USER_AUDIT_LOG_RETENTION_DAYS` se borran (default 365 dias).

3. **Retencion `agent_log`** (si la app la tiene): si pasas
   `agent_log_table_name=`, filas mas viejas que
   `DG_AGENT_LOG_RETENTION_DAYS` se borran (default 90 dias).

Idempotente. Patron de error como valor. Sin PII en logs (solo uid).
"""

from .purger import make_retention_purger

__all__ = ["make_retention_purger"]
