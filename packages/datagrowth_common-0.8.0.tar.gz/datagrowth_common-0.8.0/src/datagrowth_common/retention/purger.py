"""Factoria del purger de retencion + GDPR delete diferido.

Generico para apps Datagrowth. Cada app inyecta:

- `session_factory`: callable sin argumentos que devuelve un context
  manager de Session SQLAlchemy (`with session_factory() as session:`).
  Tipico: `lambda: Session(engine)`.
- `schema=None`: schema SQL donde viven `user_deletion_request` y
  `user_audit_log`. Default sin prefijo (apps generadas). El control
  plane pasa `"backend"`.
- `agent_log_table_name=None`: si tu app tiene una tabla de logs
  operativos (`agent_log` en el backend), pasa el nombre completo y
  se aplicara la retencion `DG_AGENT_LOG_RETENTION_DAYS`. Si None,
  solo se purga GDPR + audit log.
- `agent_log_timestamp_column="created_at"`: nombre de la columna
  timestamp en la tabla de logs.
- `extra_grant_tables=()`: tuplas `(tabla, columna_user_id)` de tablas
  RBAC propias (grants de cliente, accesos, etc.) que tambien hay que
  limpiar cuando se ejecuta un purge. El backend usa
  `("user_client_access", "user_id")` y `("user_role", "user_id")`.

Devuelve `iteration() -> tuple[stats, Exception|None]` lista para
schedulear. El stats devuelve cuantas filas purgo en cada categoria.
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timedelta
from typing import Any, Callable

from sqlalchemy import text

from ..audit import emit as audit_emit
from ..logger import get_logger

log = get_logger(__name__)


# Whitelist regex para identificadores SQL — defensa en profundidad para
# que `extra_grant_tables`/`agent_log_table_name`/`agent_log_timestamp_column`/
# `schema` no puedan inyectar SQL aunque vengan de env vars o YAMLs en
# refactors futuros. Postgres permite identificadores quoted con casi
# cualquier cosa, pero nuestros nombres son siempre snake_case ASCII.
_IDENT_RE = re.compile(r"^[a-z_][a-z0-9_]{0,62}$")


def _validate_ident(label: str, value: str) -> None:
    if not _IDENT_RE.match(value):
        raise ValueError(
            f"invalid-{label}: {value!r} "
            f"(must match {_IDENT_RE.pattern})"
        )


def _retention_days(env_var: str, default: int) -> int:
    try:
        return max(int(os.getenv(env_var, str(default))), 1)
    except ValueError:
        return default


def make_retention_purger(
    *,
    session_factory: Callable[[], Any],
    schema: str | None = None,
    extra_grant_tables: tuple[tuple[str, str], ...] = (),
    agent_log_table_name: str | None = None,
    agent_log_timestamp_column: str = "created_at",
    audit_log_retention_env: str = "DG_USER_AUDIT_LOG_RETENTION_DAYS",
    audit_log_retention_default: int = 365,
    agent_log_retention_env: str = "DG_AGENT_LOG_RETENTION_DAYS",
    agent_log_retention_default: int = 90,
) -> Callable[[], tuple[dict[str, int], Exception | None]]:
    """Construye el purger. Ver docstring del modulo para parametros."""

    # Validar identificadores ANTES de armar las queries f-stringeadas. Si
    # alguno no matchea el whitelist, lanzar al construir el purger
    # (fail-fast en boot, no en runtime cuando ya no hay quien escuche).
    if schema is not None:
        _validate_ident("schema", schema)
    for grant_table, grant_col in extra_grant_tables:
        _validate_ident("grant-table", grant_table)
        _validate_ident("grant-col", grant_col)
    if agent_log_table_name is not None:
        _validate_ident("agent-log-table-name", agent_log_table_name)
    _validate_ident("agent-log-timestamp-column", agent_log_timestamp_column)

    deletion_table = (
        f"{schema}.user_deletion_request" if schema else "user_deletion_request"
    )
    audit_table = (
        f"{schema}.user_audit_log" if schema else "user_audit_log"
    )

    def _purge_pending_deletions(session, now: datetime) -> int:
        rows = session.execute(
            text(
                f"select user_id, purge_at from {deletion_table} "
                f"where purge_at <= :now"
            ),
            {"now": now},
        ).fetchall()

        purged = 0
        for row in rows:
            uid = row[0]
            purge_at = row[1]
            for grant_table, grant_col in extra_grant_tables:
                qualified = (
                    f"{schema}.{grant_table}" if schema else grant_table
                )
                session.execute(
                    text(
                        f"delete from {qualified} where {grant_col} = :uid"
                    ),
                    {"uid": uid},
                )
            session.execute(
                text(f"delete from {deletion_table} where user_id = :uid"),
                {"uid": uid},
            )
            audit_emit(
                session,
                actor_id="system",
                target_user_id=str(uid),
                action="data-purged",
                metadata={
                    "original_purge_at": purge_at.isoformat() + "Z"
                    if purge_at
                    else None,
                },
                schema=schema,
            )
            purged += 1

        if purged:
            session.commit()
        return purged

    def _purge_old_audit_logs(session, now: datetime) -> int:
        days = _retention_days(audit_log_retention_env, audit_log_retention_default)
        cutoff = now - timedelta(days=days)
        result = session.execute(
            text(
                f"delete from {audit_table} where created_at < :cutoff"
            ),
            {"cutoff": cutoff},
        )
        session.commit()
        rowcount = getattr(result, "rowcount", 0) or 0
        return int(rowcount)

    def _purge_old_agent_logs(session, now: datetime) -> int:
        if not agent_log_table_name:
            return 0
        days = _retention_days(agent_log_retention_env, agent_log_retention_default)
        cutoff = now - timedelta(days=days)
        qualified = (
            f"{schema}.{agent_log_table_name}"
            if schema
            else agent_log_table_name
        )
        result = session.execute(
            text(
                f"delete from {qualified} "
                f"where {agent_log_timestamp_column} < :cutoff"
            ),
            {"cutoff": cutoff},
        )
        session.commit()
        rowcount = getattr(result, "rowcount", 0) or 0
        return int(rowcount)

    def iteration() -> tuple[dict[str, int], Exception | None]:
        stats = {
            "deletions_executed": 0,
            "user_audit_log_deleted": 0,
            "agent_log_deleted": 0,
        }
        try:
            now = datetime.utcnow()
            with session_factory() as session:
                stats["deletions_executed"] = _purge_pending_deletions(session, now)
                stats["user_audit_log_deleted"] = _purge_old_audit_logs(session, now)
                stats["agent_log_deleted"] = _purge_old_agent_logs(session, now)
            log.info("retention_purge_done", **stats)
            return stats, None
        except Exception as exc:
            log.warning("retention_purge_failed", error=str(exc))
            return stats, exc

    return iteration


__all__ = ["make_retention_purger"]
