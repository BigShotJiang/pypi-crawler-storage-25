"""Observabilidad compartida: Sentry + Prometheus.

Dos helpers opcionales:

- `init_sentry(component=...)`: inicializa Sentry si `SENTRY_DSN` esta
  seteada. No-op si vacia (dev local arranca sin Sentry).
- `default_instrumentator(app)`: registra el instrumentator de
  Prometheus contra una FastAPI app y expone `/metrics`. No-op si la
  dep `prometheus-fastapi-instrumentator` no esta instalada.

Ambos se importan de forma perezosa: si la app no instala las extras
`[observability]`, los imports siguen funcionando y devuelven False.
"""

from .sentry import init_sentry
from .metrics import default_instrumentator

__all__ = ["init_sentry", "default_instrumentator"]
