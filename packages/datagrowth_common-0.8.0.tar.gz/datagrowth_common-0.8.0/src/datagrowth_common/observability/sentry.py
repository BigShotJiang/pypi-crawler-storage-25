"""Inicializacion de Sentry generica para apps Datagrowth.

La funcion `init_sentry(component=...)` se llama una vez en el bootstrap
del proceso (api uvicorn, worker arq, scheduler suelto). Si
`SENTRY_DSN` esta vacia, no inicializa nada y devuelve `False` — permite
que dev local arranque sin la dep `sentry-sdk` instalada.

`before_send` redacta:
- Emails crudos en strings (mensajes, breadcrumbs, extra).
- Cabeceras sensibles del request: Authorization, Cookie, X-CSRF-Token,
  X-Admin-Token.
- Cookies enteras del request (sustituidas por `<redacted>`).
- Valores cuyo key contiene `password`, `token`, `secret`, `api_key`,
  `access_token`, `refresh_token` (case-insensitive).

Si tu app necesita scrubbing adicional, define tu propio `before_send`
y pasalo via `extra_before_send=...`. Se compone en cadena tras el
scrubber por defecto.
"""

from __future__ import annotations

import os
import re
from typing import Any, Callable


_EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
_SENSITIVE_HEADERS = ("authorization", "cookie", "x-csrf-token", "x-admin-token")
_SENSITIVE_KEYS = (
    "password",
    "token",
    "secret",
    "api_key",
    "access_token",
    "refresh_token",
)


def _scrub_strings(value: Any) -> Any:
    if isinstance(value, str):
        return _EMAIL_RE.sub("<email>", value)
    if isinstance(value, dict):
        return {k: _scrub_value(k, v) for k, v in value.items()}
    if isinstance(value, list):
        return [_scrub_strings(item) for item in value]
    return value


def _scrub_value(key: str, value: Any) -> Any:
    lowered = key.lower()
    if any(token in lowered for token in _SENSITIVE_KEYS):
        return "<redacted>"
    return _scrub_strings(value)


_USER_PII_FIELDS = ("email", "username", "ip_address")


def _default_before_send(event: dict, _hint: dict) -> dict | None:
    request = event.get("request") or {}
    headers = request.get("headers")
    if isinstance(headers, dict):
        # Sensitive matching es case-insensitive: HTTP no obliga a un casing
        # canonico y Sentry preserva el casing del cliente (`X-CSRF-Token`,
        # `x-csrf-token`, `X-Csrf-Token` son equivalentes para el servidor).
        to_pop = [
            key for key in list(headers.keys())
            if key.lower() in _SENSITIVE_HEADERS
        ]
        for key in to_pop:
            headers.pop(key, None)
    cookies = request.get("cookies")
    if isinstance(cookies, dict) and cookies:
        request["cookies"] = {k: "<redacted>" for k in cookies}
    # `query_string` y `data` pueden traer emails crudos (forms de login,
    # ?token=, etc.). Sentry los puebla automaticamente cuando captura un
    # error en un handler FastAPI.
    qs = request.get("query_string")
    if isinstance(qs, str):
        request["query_string"] = _scrub_strings(qs)
    data = request.get("data")
    if isinstance(data, str):
        request["data"] = _scrub_strings(data)
    elif isinstance(data, dict):
        request["data"] = {k: _scrub_value(k, v) for k, v in data.items()}

    extra = event.get("extra")
    if isinstance(extra, dict):
        event["extra"] = {k: _scrub_value(k, v) for k, v in extra.items()}

    # `event.user` lo puebla `FastApiIntegration` (incluso con
    # `send_default_pii=False` la app puede llamar `set_user()`). Borramos
    # email/username/ip — el id (uuid) se conserva como identificador no-PII.
    user = event.get("user")
    if isinstance(user, dict):
        for field in _USER_PII_FIELDS:
            user.pop(field, None)

    # `tags` y `contexts` se setean con `set_tag()`/`set_context()`. La app
    # puede meter email/uid sin pensarlo — scrubbear todos los values.
    tags = event.get("tags")
    if isinstance(tags, dict):
        event["tags"] = {k: _scrub_value(k, v) for k, v in tags.items()}
    contexts = event.get("contexts")
    if isinstance(contexts, dict):
        for ctx_name, ctx_val in list(contexts.items()):
            if isinstance(ctx_val, dict):
                contexts[ctx_name] = {
                    k: _scrub_value(k, v) for k, v in ctx_val.items()
                }

    # Excepciones — donde mas leak hay. `ValueError("invalid email
    # user@example.com")` o errores de psycopg con `DETAIL: ...email...` se
    # serializan en `event.exception.values[].value`.
    exc_values = (event.get("exception") or {}).get("values")
    if isinstance(exc_values, list):
        for exc in exc_values:
            if isinstance(exc, dict):
                if isinstance(exc.get("value"), str):
                    exc["value"] = _scrub_strings(exc["value"])
                # `module` y `type` son nombres de clase — no PII, no scrub.

    if isinstance(event.get("message"), str):
        event["message"] = _scrub_strings(event["message"])

    breadcrumbs = (event.get("breadcrumbs") or {}).get("values")
    if isinstance(breadcrumbs, list):
        for bc in breadcrumbs:
            if isinstance(bc, dict):
                if isinstance(bc.get("message"), str):
                    bc["message"] = _scrub_strings(bc["message"])
                # `data` del breadcrumb puede traer query_string/headers
                # del request — scrubbear como dict generico.
                bc_data = bc.get("data")
                if isinstance(bc_data, dict):
                    bc["data"] = {
                        k: _scrub_value(k, v) for k, v in bc_data.items()
                    }
    return event


def init_sentry(
    *,
    component: str,
    dsn: str | None = None,
    environment: str | None = None,
    release: str | None = None,
    traces_sample_rate: float | None = None,
    extra_before_send: Callable[[dict, dict], dict | None] | None = None,
) -> bool:
    """Inicializa Sentry si DSN esta seteado. Devuelve True si activo.

    `component` ("api", "worker", "scheduler") se setea como tag para
    distinguir en el dashboard de Sentry entre procesos del mismo deploy.

    Lee defaults de env vars:
    - `SENTRY_DSN`
    - `DG_ENV` (environment, default "prod")
    - `DG_RELEASE` (release tag, opcional)
    - `SENTRY_TRACES_SAMPLE` (default 0.1)

    Cualquier override explicito por argumento gana sobre la env var.
    `send_default_pii=False` siempre.
    """
    effective_dsn = (dsn or os.getenv("SENTRY_DSN", "")).strip()
    if not effective_dsn:
        return False

    try:
        import sentry_sdk
        from sentry_sdk.integrations.fastapi import FastApiIntegration
    except ImportError:
        return False

    if traces_sample_rate is None:
        try:
            traces_sample_rate = float(os.getenv("SENTRY_TRACES_SAMPLE", "0.1"))
        except ValueError:
            traces_sample_rate = 0.1

    integrations: list[Any] = [FastApiIntegration()]
    try:
        from sentry_sdk.integrations.sqlalchemy import SqlalchemyIntegration

        integrations.append(SqlalchemyIntegration())
    except ImportError:
        pass

    def _before_send(event: dict, hint: dict) -> dict | None:
        scrubbed = _default_before_send(event, hint)
        if scrubbed is None or extra_before_send is None:
            return scrubbed
        return extra_before_send(scrubbed, hint)

    from ..env import dg_env

    sentry_sdk.init(
        dsn=effective_dsn,
        environment=environment or dg_env(),
        release=release or os.getenv("DG_RELEASE", "").strip() or None,
        integrations=integrations,
        traces_sample_rate=traces_sample_rate,
        profiles_sample_rate=0.0,
        send_default_pii=False,
        before_send=_before_send,
        max_breadcrumbs=50,
    )
    sentry_sdk.set_tag("component", component)
    return True


__all__ = ["init_sentry"]
