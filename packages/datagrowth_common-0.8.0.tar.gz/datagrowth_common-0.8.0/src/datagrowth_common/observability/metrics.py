"""Instrumentator Prometheus generico para apps FastAPI.

Wrapper minimo sobre `prometheus_fastapi_instrumentator.Instrumentator`
que excluye los paths de salud + estaticos por defecto y registra el
endpoint `/metrics`. No-op si la libreria no esta instalada (extra
`[observability]`).

Las metricas custom de pipeline (por agente, coste, duracion) las
declara cada app en su propio modulo si las necesita.
"""

from __future__ import annotations

from typing import Any


_DEFAULT_EXCLUDED = (
    "/metrics",
    "/live",
    "/ready",
    "/health",
    "/healthz",
    "/static.*",
)


def default_instrumentator(
    app: Any,
    *,
    endpoint: str = "/metrics",
    inprogress_name: str = "dg_requests_inprogress",
    excluded_handlers: tuple[str, ...] | None = None,
) -> bool:
    """Registra el instrumentator y expone `/metrics`. True si activo.

    `excluded_handlers` extiende (no reemplaza) la lista por defecto. Si
    la app sirve assets adicionales con cardinalidad alta (UUIDs en path),
    pasalos aqui para que no exploten Prometheus.

    Devuelve False sin tocar la app si `prometheus_fastapi_instrumentator`
    no esta instalado.
    """
    try:
        from prometheus_fastapi_instrumentator import Instrumentator
    except ImportError:
        return False

    excluded = list(_DEFAULT_EXCLUDED)
    if excluded_handlers:
        excluded.extend(excluded_handlers)

    Instrumentator(
        should_group_status_codes=True,
        should_ignore_untemplated=True,
        inprogress_name=inprogress_name,
        inprogress_labels=True,
        excluded_handlers=excluded,
    ).instrument(app).expose(app, endpoint=endpoint, include_in_schema=False)
    return True


__all__ = ["default_instrumentator"]
