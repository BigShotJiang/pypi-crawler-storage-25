"""Router de autenticacion reutilizable: login propio + OAuth + refresh + logout.

La pagina HTML de `/login` la sirve la propia app (cada una con su branding);
este router solo expone los endpoints API y el OAuth callback.

Uso (en `src/main.py` de la app):

    from fastapi.templating import Jinja2Templates
    from datagrowth_common.auth.router import make_auth_router

    auth_router = make_auth_router(post_login_redirect="/")
    app.include_router(auth_router)

Endpoints expuestos:
    POST /auth/password                  -> form email+password, set cookie
    POST /auth/register                  -> sign-up (si AUTH_REGISTRATION=open)
    POST /auth/magic-link/request        -> sign_in_with_otp(email)
    POST /auth/password/reset            -> reset_password_for_email
    GET  /auth/oauth/{provider}/start    -> redirige a Supabase OAuth
    GET  /auth/oauth/{provider}/callback -> exchange code -> set cookie
    POST /auth/refresh                   -> refresca tokens si la cookie caduco
    POST /logout                         -> borra cookie y redirige
    GET  /api/me                         -> SupabaseUser actual (json)

Requiere las envvars:
    SUPABASE_URL, SUPABASE_KEY, SUPABASE_JWT_SECRET (+ optional AUTH_*).
"""
from __future__ import annotations

import os
import re
import secrets
from typing import Annotated, Any

from fastapi import APIRouter, Form, Query, Request, Response, status
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, EmailStr, Field

from ..api.errors import (
    ApiResponse,
    ErrorCode,
    err_response,
    ok_response,
)
from .session import (
    SessionUserDep,
    _cookies_secure,
    clear_session,
    get_session_tokens,
    refresh_session_tokens,
    set_session,
)
from .supabase import SupabaseUser


def _registration_open() -> bool:
    return os.getenv("AUTH_REGISTRATION", "invite_only") == "open"


def _magic_link_enabled() -> bool:
    return os.getenv("AUTH_MAGIC_LINK", "false").lower() == "true"


def _redirect_base() -> str:
    """URL publica de la app, para construir redirect_to del OAuth callback."""
    return os.getenv("DG_APP_URL", "").rstrip("/")


def _session_from_supabase(result: Any) -> dict[str, Any]:
    session = getattr(result, "session", None)
    if session is None:
        return {}
    return {
        "access_token": getattr(session, "access_token", ""),
        "refresh_token": getattr(session, "refresh_token", ""),
    }


class _RefreshBody(BaseModel):
    pass  # refresh lee de cookie, no de body


def make_auth_router(
    *,
    prefix: str = "",
    post_login_redirect: str = "/",
    post_logout_redirect: str = "/login",
    oauth_callback_path_prefix: str = "/auth/oauth",
) -> APIRouter:
    """Construye el APIRouter de auth con redirects configurables.

    El router NO sirve `/login` HTML — eso vive en la app (template propio).
    """
    router = APIRouter(prefix=prefix, tags=["auth"])

    # ── Password (Supabase email/password) ─────────────────────────────

    @router.post("/auth/password", response_class=RedirectResponse)
    async def auth_password(
        email: Annotated[str, Form(min_length=3, max_length=254)],
        password: Annotated[str, Form(min_length=8, max_length=200)],
    ) -> RedirectResponse:
        try:
            from ..supabase import get_supabase_client
            client = get_supabase_client()
            result = client.auth.sign_in_with_password(
                {"email": email, "password": password},
            )
        except Exception:
            return RedirectResponse("/login?error=invalid-credentials", status_code=303)
        tokens = _session_from_supabase(result)
        if not tokens.get("access_token"):
            return RedirectResponse("/login?error=invalid-credentials", status_code=303)
        redir = RedirectResponse(post_login_redirect, status_code=303)
        set_session(
            redir,
            access_token=tokens["access_token"],
            refresh_token=tokens.get("refresh_token"),
        )
        return redir

    # ── Register (sign-up) ────────────────────────────────────────────

    @router.post("/auth/register", response_model=ApiResponse)
    async def auth_register(
        email: Annotated[str, Form(min_length=3, max_length=254)],
        password: Annotated[str, Form(min_length=8, max_length=200)],
        name: Annotated[str, Form(min_length=1, max_length=120)] = "",
    ) -> ApiResponse:
        """Sign-up con respuesta CONSTANTE para evitar enumeracion de emails.

        Si el email ya existe Supabase lanza, antes devolviamos CONFLICT
        — leak de existencia. Ahora respondemos `{sent: True}` tanto en
        exito como en fallo del sign_up (mismo patron que magic-link y
        password reset). La activacion por email confirma al usuario
        legitimo si era nuevo; si ya existia, no recibe nada y el
        atacante no aprende nada.
        """
        if not _registration_open():
            return err_response(ErrorCode.FORBIDDEN, "registration-closed")
        try:
            from ..supabase import get_supabase_client
            client = get_supabase_client()
            client.auth.sign_up({
                "email": email, "password": password,
                "options": {"data": {"name": name}} if name else {},
            })
        except Exception:
            # No leak: tragar la excepcion silenciosamente. Posibles causas:
            # email ya existe, password debil, Supabase down. La rama de
            # exito y la de fallo devuelven lo mismo.
            pass
        return ok_response({"sent": True})

    # ── Magic link (OTP via email) ────────────────────────────────────

    @router.post("/auth/magic-link/request", response_model=ApiResponse)
    async def auth_magic_link(
        email: Annotated[str, Form(min_length=3, max_length=254)],
    ) -> ApiResponse:
        if not _magic_link_enabled():
            return err_response(ErrorCode.FORBIDDEN, "magic-link-disabled")
        try:
            from ..supabase import get_supabase_client
            client = get_supabase_client()
            client.auth.sign_in_with_otp({"email": email})
        except Exception:
            return err_response(ErrorCode.INTERNAL_ERROR, "magic-link-failed")
        return ok_response({"sent": True})

    # ── Password reset ────────────────────────────────────────────────

    @router.post("/auth/password/reset", response_model=ApiResponse)
    async def auth_password_reset(
        email: Annotated[str, Form(min_length=3, max_length=254)],
    ) -> ApiResponse:
        try:
            from ..supabase import get_supabase_client
            client = get_supabase_client()
            client.auth.reset_password_for_email(email)
        except Exception:
            return err_response(ErrorCode.INTERNAL_ERROR, "reset-failed")
        return ok_response({"sent": True})

    # ── OAuth (Microsoft/Google/etc. via Supabase) ───────────────────

    # Cookie httpOnly puesta por `start` y verificada por `callback`. Cierra el
    # OAuth-login-CSRF: la victima solo puede tener esta cookie si ella misma
    # inicio el flow desde su navegador (SameSite=Lax impide setearla cross-site).
    # Si el atacante manda a la victima a `/callback?code=<atacante>`, su
    # navegador no tiene la cookie y el callback aborta.
    _OAUTH_STATE_COOKIE = "dg_oauth_state"
    _OAUTH_STATE_TTL_S = 600
    # Whitelist regex para `provider` — evita inputs raros que el SDK podria
    # interpretar (no es un exploit conocido, pero defensa en profundidad).
    _OAUTH_PROVIDER_RE = re.compile(r"^[a-z][a-z0-9_-]{1,30}$")

    @router.get(f"{oauth_callback_path_prefix}/{{provider}}/start")
    async def auth_oauth_start(
        provider: str, request: Request,
    ) -> RedirectResponse:
        """Redirige al consent de Supabase para el provider OAuth indicado.

        Setea cookie httpOnly `dg_oauth_state` con un nonce aleatorio para
        que el callback pueda verificar que el flow viene del mismo navegador
        que lo inicio (anti-CSRF OAuth).
        """
        if not _OAUTH_PROVIDER_RE.match(provider):
            return RedirectResponse(url="/login?error=oauth-provider", status_code=303)
        base = _redirect_base() or str(request.base_url).rstrip("/")
        callback = f"{base}{oauth_callback_path_prefix}/{provider}/callback"
        try:
            from ..supabase import get_supabase_client
            client = get_supabase_client()
            result = client.auth.sign_in_with_oauth({
                "provider": provider,
                "options": {"redirect_to": callback},
            })
            url = getattr(result, "url", None)
        except Exception:
            return RedirectResponse(url="/login?error=oauth-start", status_code=303)
        if not url:
            return RedirectResponse(url="/login?error=oauth-start", status_code=303)
        redir = RedirectResponse(url=str(url), status_code=303)
        nonce = secrets.token_urlsafe(32)
        redir.set_cookie(
            _OAUTH_STATE_COOKIE,
            nonce,
            httponly=True,
            secure=_cookies_secure(),
            samesite="lax",
            max_age=_OAUTH_STATE_TTL_S,
            path=f"{oauth_callback_path_prefix}/{provider}/callback",
        )
        return redir

    @router.get(f"{oauth_callback_path_prefix}/{{provider}}/callback")
    async def auth_oauth_callback(
        provider: str,
        code: Annotated[str, Query(min_length=1, max_length=2048)],
        request: Request,
    ) -> RedirectResponse:
        """Canjea el `?code=` por session JWT y guarda cookies.

        Valida la cookie `dg_oauth_state` puesta por `start`. Sin ella,
        rechazamos: el flow no viene del mismo navegador que lo inicio
        (posible login-CSRF — un atacante manda a la victima al callback
        con su propio `code` para fijar la sesion del atacante en el
        navegador de la victima).
        """
        if not _OAUTH_PROVIDER_RE.match(provider):
            return RedirectResponse(url="/login?error=oauth-provider", status_code=303)
        if not request.cookies.get(_OAUTH_STATE_COOKIE):
            return RedirectResponse(url="/login?error=oauth-state", status_code=303)
        try:
            from ..supabase import get_supabase_client
            client = get_supabase_client()
            result = client.auth.exchange_code_for_session({"auth_code": code})
        except Exception:
            return RedirectResponse(url="/login?error=oauth-exchange", status_code=303)
        tokens = _session_from_supabase(result)
        if not tokens.get("access_token"):
            return RedirectResponse(url="/login?error=oauth-exchange", status_code=303)
        redir = RedirectResponse(post_login_redirect, status_code=303)
        set_session(
            redir,
            access_token=tokens["access_token"],
            refresh_token=tokens.get("refresh_token"),
        )
        # Borrar la cookie state — el flow OAuth ya cerro, no se reusa.
        redir.delete_cookie(
            _OAUTH_STATE_COOKIE,
            path=f"{oauth_callback_path_prefix}/{provider}/callback",
        )
        return redir

    # ── Refresh ───────────────────────────────────────────────────────

    @router.post("/auth/refresh", response_model=ApiResponse)
    async def auth_refresh(
        request: Request, response: Response,
    ) -> ApiResponse:
        tokens = get_session_tokens(request)
        if tokens is None or not tokens.refresh_token:
            return err_response(ErrorCode.UNAUTHORIZED, "no-refresh-token")
        new_tokens, exc = await refresh_session_tokens(tokens.refresh_token)
        if exc is not None or new_tokens is None:
            return err_response(ErrorCode.UNAUTHORIZED, "refresh-failed")
        set_session(
            response,
            access_token=new_tokens["access_token"],
            refresh_token=new_tokens.get("refresh_token"),
        )
        return ok_response({"refreshed": True})

    # ── Logout ────────────────────────────────────────────────────────

    @router.post("/logout", response_class=RedirectResponse)
    async def logout() -> RedirectResponse:
        redir = RedirectResponse(post_logout_redirect, status_code=303)
        clear_session(redir)
        return redir

    # ── Identity ──────────────────────────────────────────────────────

    class _PublicMe(BaseModel):
        """Subset publico de `SupabaseUser` expuesto en `/api/me`.

        `app_metadata` y `user_metadata` NO se incluyen — el JWT puede
        traer datos sensibles ahi (otros tenants, hashes, secretos de
        terceros). `aud` tampoco — es metadata del token, no del user.
        Si tu app necesita exponer un campo concreto de metadata, anade
        un campo explicito aqui o expon un endpoint propio.
        """

        id: str
        email: str | None = None
        role: str = "user"

    @router.get("/api/me", response_model=ApiResponse[_PublicMe])
    async def me(user: SessionUserDep) -> ApiResponse[_PublicMe]:
        return ok_response(_PublicMe(id=user.id, email=user.email, role=user.role))

    return router


# Router por defecto con redirects estandar (post_login → "/").
auth_router = make_auth_router()
