"""Helpers de variables de entorno compartidas entre apps Datagrowth.

`DG_ENV` es el discriminador canonico de entorno. Convencion:

- `prod` (default): produccion. Cookies con `Secure`, logs JSON, etc.
- `dev`: desarrollo local. Cookies sin `Secure`, logs consola legible.

Por compatibilidad con apps existentes que tienen `DG_ENV=production` o
`DG_ENV=development` en sus envs ya desplegados, los helpers aceptan
ambas variantes (production = prod, development = dev). Pero los
defaults canonicos son los cortos (`prod`/`dev`).
"""

from __future__ import annotations

import os


_DEV_VALUES = frozenset({"dev", "development"})
_PROD_VALUES = frozenset({"prod", "production"})


def dg_env() -> str:
    """Devuelve `DG_ENV` normalizado a `dev` o `prod`. Default `prod`."""
    raw = os.getenv("DG_ENV", "prod").strip().lower()
    if raw in _DEV_VALUES:
        return "dev"
    return "prod"


def is_dev_env() -> bool:
    return dg_env() == "dev"


def is_prod_env() -> bool:
    return dg_env() == "prod"


__all__ = ["dg_env", "is_dev_env", "is_prod_env"]
