"""Auditor determinista de production-readiness.

Aplicable a cualquier repo Datagrowth (backend interno o apps generadas
por el pipeline). Cada check es una funcion pura
`(repo_root: Path) -> CheckResult` que devuelve `passed`, `details` y
`severity`. Sin efectos laterales, sin red, sin proceso externo: todos
los checks leen el filesystem del repo.

Severities:

- `blocker`: si falla, bloquea release.
- `warning`: aviso, no bloquea.

El severity refleja si la pieza es regla fundacional del proyecto
(blocker) o si esta planificada como parte de un subplan del plan SaaS
productivo (warning). Subir un warning a blocker es trivial cuando la
pieza llega y se quiere imponer.

Patron de error del proyecto: las funciones publicas devuelven
`tuple[T, Exception | None]` sin lanzar excepciones cross-module.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


Severity = str  # "blocker" | "warning"


@dataclass(frozen=True)
class CheckResult:
    name: str
    passed: bool
    details: str
    severity: Severity


# ---------------------------------------------------------------------------
# Utilidades internas
# ---------------------------------------------------------------------------


def _read_text_safe(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def _any_match(root: Path, pattern: re.Pattern[str], *, glob: str = "*.py") -> bool:
    for f in root.rglob(glob):
        parts = set(f.parts)
        if parts & {".venv", "venv", "node_modules", "__pycache__", ".git", ".mypy_cache"}:
            continue
        if pattern.search(_read_text_safe(f)):
            return True
    return False


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------


def _check_no_print_in_src(repo: Path) -> CheckResult:
    """Llamadas a `print(...)` en codigo Python real (no en strings literales).

    Usa AST para distinguir una llamada real de un `print(` que viva dentro
    de una string multilinea (caso comun: scripts embebidos para subprocess
    que sin acceso al logger del backend usan `print(..., file=sys.stderr)`
    para comunicar errores fatales con `sys.exit(N)`).

    Lineas con `# noqa` siguen excluidas para casos puntuales donde el
    autor justifica el print real (ej. CLI tools, debug).
    """
    import ast

    src = repo / "src"
    if not src.exists():
        return CheckResult("no-print-in-src", True, "no src/ dir", "warning")
    matches: list[str] = []
    for f in src.rglob("*.py"):
        if any(p in {"__pycache__", ".mypy_cache"} for p in f.parts):
            continue
        text = _read_text_safe(f)
        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue
        lines = text.splitlines()
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            is_print = (
                (isinstance(func, ast.Name) and func.id == "print")
                or (isinstance(func, ast.Attribute) and func.attr == "print")
            )
            if not is_print:
                continue
            line_no = node.lineno
            line = lines[line_no - 1] if 0 < line_no <= len(lines) else ""
            if "noqa" in line:
                continue
            matches.append(f"{f.relative_to(repo).as_posix()}:{line_no}")
    passed = not matches
    details = "OK" if passed else f"{len(matches)} print() encontrados: " + ", ".join(matches[:5])
    return CheckResult("no-print-in-src", passed, details, "blocker")


def _check_structlog_initialized(repo: Path) -> CheckResult:
    main_py = repo / "src" / "main.py"
    if not main_py.exists():
        return CheckResult(
            "structlog-initialized", False,
            "src/main.py no existe; logger probablemente no inicializado", "blocker",
        )
    text = _read_text_safe(main_py)
    has_call = "setup_logging()" in text
    return CheckResult(
        "structlog-initialized", has_call,
        "OK" if has_call else "setup_logging() no se invoca en src/main.py", "blocker",
    )


def _check_env_example_exists(repo: Path) -> CheckResult:
    env_example = repo / "infra" / ".env.example"
    exists = env_example.exists()
    return CheckResult(
        "env-example-exists", exists,
        "OK" if exists else f"infra/.env.example no existe", "blocker",
    )


def _check_env_var_declared(repo: Path, var: str, severity: Severity) -> CheckResult:
    env_example = repo / "infra" / ".env.example"
    name = f"env-declared:{var}"
    if not env_example.exists():
        return CheckResult(name, False, "infra/.env.example no existe", severity)
    pat = re.compile(rf"^{re.escape(var)}=", re.MULTILINE)
    text = _read_text_safe(env_example)
    declared = bool(pat.search(text))
    return CheckResult(
        name, declared,
        "OK" if declared else f"{var} no declarada en infra/.env.example", severity,
    )


def _check_sentry_declared(repo: Path) -> CheckResult:
    return _check_env_var_declared(repo, "SENTRY_DSN", "warning")


def _check_migrations_versioned(repo: Path) -> CheckResult:
    migrations = repo / "migrations"
    if not migrations.exists():
        return CheckResult(
            "migrations-versioned", False,
            "migrations/ no existe", "blocker",
        )
    files = sorted(migrations.glob("v*.sql"))
    if not files:
        return CheckResult(
            "migrations-versioned", False,
            "0 ficheros migrations/v*.sql", "blocker",
        )
    # Huecos en numeracion son aceptables: migrations idempotentes pueden
    # saltar numeros (eliminadas en planning, reordenadas).
    nums = sorted({int(m.group(1)) for f in files
                   if (m := re.match(r"v(\d+)\.sql$", f.name))})
    expected = list(range(1, nums[-1] + 1)) if nums else []
    gaps = [n for n in expected if n not in nums]
    detail = f"{len(files)} migrations v1..v{nums[-1]}"
    if gaps:
        detail += f" (huecos: v{gaps[:5]})"
    return CheckResult("migrations-versioned", True, detail, "blocker")


def _check_live_endpoint(repo: Path) -> CheckResult:
    """`/live` debe responder sin auth (Docker/Easypanel healthcheck)."""
    api_dir = repo / "src" / "api"
    if not api_dir.exists():
        return CheckResult("live-endpoint", False, "src/api/ no existe", "warning")
    pat = re.compile(r'@router\.get\(\s*["\']\/live["\']')
    found = _any_match(api_dir, pat, glob="*.py")
    return CheckResult(
        "live-endpoint", found,
        "OK" if found else "Falta endpoint /live sin auth", "warning",
    )


def _check_ready_endpoint(repo: Path) -> CheckResult:
    api_dir = repo / "src" / "api"
    if not api_dir.exists():
        return CheckResult("ready-endpoint", False, "src/api/ no existe", "warning")
    pat = re.compile(r'@router\.get\(\s*["\']\/ready["\']')
    found = _any_match(api_dir, pat, glob="*.py")
    return CheckResult(
        "ready-endpoint", found,
        "OK" if found else "Falta endpoint /ready verificando deps", "warning",
    )


def _check_security_headers_middleware(repo: Path) -> CheckResult:
    main_py = repo / "src" / "main.py"
    text = _read_text_safe(main_py) if main_py.exists() else ""
    found = "SecurityHeadersMiddleware" in text
    return CheckResult(
        "security-headers-middleware", found,
        "OK" if found else "Falta SecurityHeadersMiddleware (HSTS/X-Frame/CSP)", "warning",
    )


def _check_csrf_middleware(repo: Path) -> CheckResult:
    main_py = repo / "src" / "main.py"
    text = _read_text_safe(main_py) if main_py.exists() else ""
    found = "CSRFMiddleware" in text
    return CheckResult(
        "csrf-middleware", found,
        "OK" if found else "Falta CSRFMiddleware", "warning",
    )


def _check_rate_limit_auth(repo: Path) -> CheckResult:
    api_dir = repo / "src" / "api"
    if not api_dir.exists():
        return CheckResult("rate-limit-auth", False, "src/api/ no existe", "warning")
    pat = re.compile(r"@limiter\.limit\(")
    found = _any_match(api_dir, pat, glob="*.py")
    return CheckResult(
        "rate-limit-auth", found,
        "OK" if found else "Falta @limiter.limit en endpoints sensibles", "warning",
    )


def _check_gdpr_export_endpoint(repo: Path) -> CheckResult:
    api_dir = repo / "src" / "api"
    if not api_dir.exists():
        return CheckResult("gdpr-export", False, "src/api/ no existe", "warning")
    pat = re.compile(r'/me/data/export')
    found = _any_match(api_dir, pat, glob="*.py")
    return CheckResult(
        "gdpr-export", found,
        "OK" if found else "Falta endpoint /me/data/export (GDPR)", "warning",
    )


def _check_gdpr_delete_endpoint(repo: Path) -> CheckResult:
    api_dir = repo / "src" / "api"
    if not api_dir.exists():
        return CheckResult("gdpr-delete", False, "src/api/ no existe", "warning")
    pat = re.compile(r'@router\.delete\(\s*["\']\/me\/data["\']')
    found = _any_match(api_dir, pat, glob="*.py")
    return CheckResult(
        "gdpr-delete", found,
        "OK" if found else "Falta endpoint DELETE /me/data (GDPR)", "warning",
    )


def _check_privacy_doc(repo: Path) -> CheckResult:
    privacy = repo / "docs" / "PRIVACY.md"
    exists = privacy.exists()
    return CheckResult(
        "privacy-doc", exists,
        "OK" if exists else "Falta docs/PRIVACY.md", "warning",
    )


def _check_legal_routes(repo: Path) -> CheckResult:
    api_dir = repo / "src" / "api"
    if not api_dir.exists():
        return CheckResult("legal-routes", False, "src/api/ no existe", "warning")
    has_priv = _any_match(api_dir, re.compile(r'["\']\/privacy["\']'), glob="*.py")
    has_terms = _any_match(api_dir, re.compile(r'["\']\/terms["\']'), glob="*.py")
    ok = has_priv and has_terms
    missing = [n for n, v in [("privacy", has_priv), ("terms", has_terms)] if not v]
    return CheckResult(
        "legal-routes", ok,
        "OK" if ok else f"Faltan rutas: {missing}", "warning",
    )


def _check_ci_workflow(repo: Path) -> CheckResult:
    ci = repo / ".github" / "workflows" / "ci.yml"
    if not ci.exists():
        return CheckResult(
            "ci-workflow", False,
            ".github/workflows/ci.yml no existe", "warning",
        )
    text = _read_text_safe(ci)
    has_pytest = "pytest" in text
    has_lint = "ruff" in text or "flake8" in text
    ok = has_pytest and has_lint
    return CheckResult(
        "ci-workflow", ok,
        "OK" if ok else "ci.yml existe pero falta pytest o ruff", "warning",
    )


def _check_tests_dir(repo: Path) -> CheckResult:
    tests = repo / "tests"
    if not tests.exists():
        return CheckResult("tests-dir", False, "tests/ no existe", "blocker")
    files = list(tests.rglob("test_*.py"))
    has_some = len(files) >= 3
    return CheckResult(
        "tests-dir", has_some,
        f"OK ({len(files)} test files)" if has_some else f"Solo {len(files)} test files; necesita >=3", "blocker",
    )


def _check_no_secrets_hardcoded(repo: Path) -> CheckResult:
    """Heuristica de secrets en src/. Captura asignaciones de variables cuyo
    nombre sugiere secreto, a string literal largo. Excluye variables que
    guardan METADATA (nombre de env var, nombre de header, prefijo, sufijo).
    """
    src = repo / "src"
    if not src.exists():
        return CheckResult("no-secrets-hardcoded", True, "no src/", "warning")
    pat = re.compile(
        r'^\s*([A-Z_]*(?:SECRET|TOKEN|PASSWORD|API_KEY|PRIVATE_KEY)[A-Z_]*)\s*=\s*["\']([^"\']{12,})["\']',
        re.MULTILINE,
    )
    metadata_suffixes = (
        "_ENV_VAR", "_ENV", "_NAME", "_HEADER", "_PREFIX", "_SUFFIX",
        "_KEY_HEADER", "_FIELD", "_LABEL", "_TAG", "_HINT",
    )
    matches: list[str] = []
    for f in src.rglob("*.py"):
        if any(p in {"__pycache__", ".mypy_cache"} for p in f.parts):
            continue
        text = _read_text_safe(f)
        for m in pat.finditer(text):
            var_name = m.group(1)
            value = m.group(2)
            if var_name.endswith(metadata_suffixes):
                continue
            if re.fullmatch(r"[A-Z][A-Z0-9_]+", value) or ("-" in value and value.islower()):
                continue
            if value.startswith(("<", "{", "your-", "dummy", "example", "changeme", "REPLACE")):
                continue
            line_start = text.rfind("\n", 0, m.start()) + 1
            line_end = text.find("\n", m.end())
            line = text[line_start:line_end if line_end > 0 else len(text)]
            if "getenv" in line or "environ" in line:
                continue
            matches.append(f"{f.relative_to(repo).as_posix()}: {line.strip()[:80]}")
    passed = not matches
    return CheckResult(
        "no-secrets-hardcoded", passed,
        "OK" if passed else f"{len(matches)} posibles secretos hardcodeados: " + " | ".join(matches[:3]),
        "blocker",
    )


def _check_runbook_present(repo: Path) -> CheckResult:
    runbook = repo / "docs" / "RUNBOOK.md"
    return CheckResult(
        "runbook-present", runbook.exists(),
        "OK" if runbook.exists() else "Falta docs/RUNBOOK.md", "warning",
    )


def _check_health_endpoint_public(repo: Path) -> CheckResult:
    """`/health` o `/live` no debe requerir auth.

    Heuristica: el handler de /health o /live no debe estar dentro de
    una ventana de 400 chars que contenga `Depends(require_auth)` o
    `Depends(require_perm(...))`.
    """
    api_dir = repo / "src" / "api"
    if not api_dir.exists():
        return CheckResult("health-endpoint-public", False, "src/api/ no existe", "warning")
    handler_re = re.compile(r'@router\.get\(\s*["\']\/(?:health|live)["\']')
    auth_re = re.compile(r"Depends\(\s*require_(auth|perm)")
    for f in api_dir.rglob("*.py"):
        if any(p in {"__pycache__"} for p in f.parts):
            continue
        text = _read_text_safe(f)
        for m in handler_re.finditer(text):
            window = text[m.start():m.end() + 400]
            if auth_re.search(window):
                return CheckResult(
                    "health-endpoint-public", False,
                    f"/health o /live en {f.relative_to(repo).as_posix()} requiere auth", "blocker",
                )
    return CheckResult("health-endpoint-public", True, "OK (o no encontrado, fallback)", "warning")


# ---------------------------------------------------------------------------
# Orquestador
# ---------------------------------------------------------------------------


CHECKS: list[Callable[[Path], CheckResult]] = [
    _check_no_print_in_src,
    _check_structlog_initialized,
    _check_env_example_exists,
    _check_sentry_declared,
    _check_migrations_versioned,
    _check_live_endpoint,
    _check_ready_endpoint,
    _check_security_headers_middleware,
    _check_csrf_middleware,
    _check_rate_limit_auth,
    _check_gdpr_export_endpoint,
    _check_gdpr_delete_endpoint,
    _check_privacy_doc,
    _check_legal_routes,
    _check_ci_workflow,
    _check_tests_dir,
    _check_no_secrets_hardcoded,
    _check_runbook_present,
    _check_health_endpoint_public,
]


def run_audit(repo: Path) -> tuple[dict, Exception | None]:
    """Ejecuta todos los checks contra el repo indicado.

    Devuelve `(report, None)` en exito o `(empty_report, exc)` en error.
    Sigue el patron de error de Datagrowth: nunca raise cross-module.
    """
    try:
        results = [c(repo) for c in CHECKS]
        failures = [r for r in results if not r.passed]
        blockers = [r for r in failures if r.severity == "blocker"]
        warnings = [r for r in failures if r.severity == "warning"]
        return {
            "checked": len(results),
            "passed": len(results) - len(failures),
            "blockers": len(blockers),
            "warnings": len(warnings),
            "results": [
                {"name": r.name, "passed": r.passed, "details": r.details, "severity": r.severity}
                for r in results
            ],
            "summary": {
                "blockers": [{"name": r.name, "details": r.details} for r in blockers],
                "warnings": [{"name": r.name, "details": r.details} for r in warnings],
            },
        }, None
    except Exception as exc:  # noqa: BLE001 — patron de error: nunca raise cross-module
        return {"checked": 0, "passed": 0, "blockers": 0, "warnings": 0, "results": [], "summary": {}}, exc
