"""QA helpers compartidos entre proyectos Datagrowth.

Submodulos:

- `prod_ready`: auditor determinista de production-readiness aplicable
  a cualquier repo Datagrowth (backend interno o app generada por el
  pipeline). Expone `run_audit(repo_root)` y `CheckResult`.
"""

from .prod_ready import CheckResult, run_audit

__all__ = ["CheckResult", "run_audit"]
