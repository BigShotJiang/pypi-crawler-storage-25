"""Paginas legales publicas (`/privacy`, `/terms`, `/security`).

Cada app sirve textos legales como HTML desde un directorio de archivos
markdown. La factory `make_legal_router(docs_dir, pages=...)` devuelve
un APIRouter listo para incluir en la app sin auth — la politica de
privacidad debe ser accesible antes de crear cuenta.

El parser de markdown es minimo (h1-h6, listas, tablas GFM, parrafos,
bold/code/links inline), suficiente para los .md de `docs/legal/`. Si
una app necesita markdown completo (footnotes, image alt text, code
blocks), pasa `md_to_html=` propio a la factory.
"""

from .router import make_legal_router, md_to_html

__all__ = ["make_legal_router", "md_to_html"]
