"""Router generico para paginas legales (`/privacy`, `/terms`, `/security`).

Cada app pasa el directorio donde viven sus `.md` y un mapping
`slug -> (filename, titulo humano)`. La factory devuelve un APIRouter
con un GET por cada slug. Sin auth — la politica debe ser visible
antes de crear cuenta.

El template HTML se sirve desde el paquete (subpaquete `ui`); cada app
puede sobrescribir pasando `template_name=` propio si quiere su shell.
"""

from __future__ import annotations

import html
import re
from functools import lru_cache
from pathlib import Path
from typing import Callable

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse


_DEFAULT_PAGES: dict[str, tuple[str, str]] = {
    "privacy": ("privacy.md", "Politica de privacidad"),
    "terms": ("terms.md", "Condiciones del servicio"),
    "security": ("security.md", "Seguridad"),
}


def make_legal_router(
    *,
    docs_dir: Path,
    pages: dict[str, tuple[str, str]] | None = None,
    templates,
    template_name: str = "dg/legal/page.html",
    md_to_html_fn: Callable[[str], str] | None = None,
    tags: tuple[str, ...] = ("legal",),
) -> APIRouter:
    """Construye un APIRouter con un GET por slug.

    `docs_dir`: directorio absoluto donde viven los `.md` (ej.
    `Path("docs/legal")`).

    `pages`: mapping `slug -> (filename, titulo)`. Default cubre
    `privacy`/`terms`/`security`.

    `templates`: instancia de `fastapi.templating.Jinja2Templates` (o
    compatible) ya configurada con el ChoiceLoader que incluye al
    paquete (`register_ui` lo cablea por defecto). Se llama
    `templates.TemplateResponse(request, template_name, context)`.

    `template_name`: nombre del template Jinja. Default `legal/page.html`
    — apps con shell propio pasan el suyo.

    `md_to_html_fn`: parser custom. Default el parser minimo del
    paquete (`md_to_html`).

    Cada GET responde 404 si el slug no existe en `pages`, o 503 si el
    `.md` no esta en disco.
    """
    effective_pages = pages or dict(_DEFAULT_PAGES)
    effective_parser = md_to_html_fn or md_to_html
    router = APIRouter(tags=list(tags))

    async def _render(request: Request, slug: str) -> HTMLResponse:
        page = effective_pages.get(slug)
        if page is None:
            raise HTTPException(status_code=404, detail="legal-page-not-found")
        filename, title = page
        md = _read_md_cached(str(docs_dir), filename)
        if md is None:
            raise HTTPException(status_code=503, detail="legal-doc-missing")
        body_html = effective_parser(md)
        return templates.TemplateResponse(
            request,
            template_name,
            {"title": title, "body_html": body_html, "slug": slug},
        )

    # Registramos un endpoint por slug. Paths literales (no `{slug}`) para
    # que el auditor `prod-ready-checklist` los detecte y para evitar
    # colisiones con cualquier otro `/something` del consumidor.
    for slug_value in effective_pages:
        path = f"/{slug_value}"

        async def _handler(request: Request, _slug: str = slug_value) -> HTMLResponse:
            return await _render(request, _slug)

        router.add_api_route(
            path,
            _handler,
            methods=["GET"],
            response_class=HTMLResponse,
            include_in_schema=False,
            name=f"legal-{slug_value}",
        )

    return router


@lru_cache(maxsize=64)
def _read_md_cached(docs_dir: str, filename: str) -> str | None:
    """Carga el `.md` una vez por proceso. Restart para recargar."""
    path = Path(docs_dir) / filename
    if not path.is_file():
        return None
    return path.read_text(encoding="utf-8", errors="replace")


# ---------------------------------------------------------------------------
# Parser markdown minimo (subset)
# ---------------------------------------------------------------------------


# Esquemas permitidos en `[txt](url)`. `javascript:`, `data:`, `vbscript:` quedan
# fuera deliberadamente — sin esta whitelist un .md malicioso podria inyectar
# `[x](javascript:fetch('/api/me')...)` y ejecutar JS al click en una pagina
# legal servida sin auth.
_SAFE_URL_RE = re.compile(r"^(?:https?:|mailto:|tel:|/|#)", re.IGNORECASE)

_BOLD_RE = re.compile(r"\*\*(.+?)\*\*")
_CODE_RE = re.compile(r"`([^`]+)`")
# El URL del link no puede contener `)` ni espacios — evita capturar texto
# adyacente que rompa el render.
_LINK_RE = re.compile(r"\[([^\]]+)\]\(([^)\s]+)\)")


def md_to_html(md: str) -> str:
    """Convierte un subset de markdown (headers, listas, tablas GFM,
    parrafos, `**bold**`, `` `code` ``, `[link](url)`).

    Inline se aplica tras `html.escape(quote=True)` — quote=True para que
    los `"`/`'` queden escapados y NO se pueda cerrar el atributo `href`
    inyectando handlers (`onfocus=`, `onload=`). Los links se renderizan
    pasando la URL por `html.escape(quote=True)` Y validando el esquema
    contra una whitelist (`https`, `http`, `mailto`, `tel`, relativos `/`
    y anchors `#`). Esquemas `javascript:` / `data:` / `vbscript:` se
    convierten en texto plano sin link.

    Solo cubre lo que necesitan los textos legales (`privacy`, `terms`,
    `security`). Para markdown completo, pasa `md_to_html_fn=` propio.
    """
    lines = md.splitlines()
    out: list[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if not stripped:
            i += 1
            continue

        m = re.match(r"^(#{1,6})\s+(.+?)\s*#*\s*$", stripped)
        if m:
            level = len(m.group(1))
            text = _inline(m.group(2))
            out.append(f"<h{level}>{text}</h{level}>")
            i += 1
            continue

        if "|" in stripped and i + 1 < len(lines) and re.match(
            r"^\s*\|?\s*[:\-]+\s*(\|\s*[:\-]+\s*)+\|?\s*$", lines[i + 1].strip(),
        ):
            table_html, consumed = _consume_table(lines, i)
            out.append(table_html)
            i += consumed
            continue

        if stripped.startswith(("- ", "* ")):
            list_html, consumed = _consume_list(lines, i)
            out.append(list_html)
            i += consumed
            continue

        para_lines: list[str] = []
        while i < len(lines) and lines[i].strip() and not _starts_block(lines[i]):
            para_lines.append(lines[i].strip())
            i += 1
        if para_lines:
            text = _inline(" ".join(para_lines))
            out.append(f"<p>{text}</p>")

    return "\n".join(out)


def _starts_block(line: str) -> bool:
    s = line.strip()
    return (
        s.startswith("#")
        or s.startswith("- ")
        or s.startswith("* ")
        or s.startswith("|")
    )


def _consume_list(lines: list[str], start: int) -> tuple[str, int]:
    items: list[str] = []
    i = start
    while i < len(lines):
        stripped = lines[i].strip()
        if stripped.startswith(("- ", "* ")):
            items.append(_inline(stripped[2:]))
            i += 1
            continue
        break
    inner = "".join(f"<li>{item}</li>" for item in items)
    return f"<ul>{inner}</ul>", i - start


def _consume_table(lines: list[str], start: int) -> tuple[str, int]:
    header_cells = _split_table_row(lines[start])
    rows: list[list[str]] = []
    i = start + 2
    while i < len(lines):
        if "|" not in lines[i] or not lines[i].strip():
            break
        rows.append(_split_table_row(lines[i]))
        i += 1

    thead = "<tr>" + "".join(f"<th>{_inline(c)}</th>" for c in header_cells) + "</tr>"
    tbody = "".join(
        "<tr>" + "".join(f"<td>{_inline(c)}</td>" for c in row) + "</tr>"
        for row in rows
    )
    table_html = f"<table><thead>{thead}</thead><tbody>{tbody}</tbody></table>"
    return table_html, i - start


def _split_table_row(line: str) -> list[str]:
    s = line.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|"):
        s = s[:-1]
    return [cell.strip() for cell in s.split("|")]


def _render_link(match: re.Match) -> str:
    """Renderiza `[txt](url)` validando el esquema de la URL. Si el esquema
    no esta en la whitelist, devuelve el texto plano (sin link)."""
    label = match.group(1)
    url = match.group(2)
    if not _SAFE_URL_RE.match(url):
        return label
    safe_url = html.escape(url, quote=True)
    # `rel=noopener noreferrer` defensa en profundidad para abrir externos
    # sin que el destino pueda manipular `window.opener`.
    return f'<a href="{safe_url}" rel="noopener noreferrer">{label}</a>'


def _inline(text: str) -> str:
    # quote=True escapa `"` y `'` — sin esto un .md malicioso puede cerrar
    # el `href="..."` de un link e inyectar `onfocus=`/`onload=`.
    escaped = html.escape(text, quote=True)
    escaped = _BOLD_RE.sub(r"<strong>\1</strong>", escaped)
    escaped = _CODE_RE.sub(r"<code>\1</code>", escaped)
    escaped = _LINK_RE.sub(_render_link, escaped)
    return escaped


__all__ = ["make_legal_router", "md_to_html"]
