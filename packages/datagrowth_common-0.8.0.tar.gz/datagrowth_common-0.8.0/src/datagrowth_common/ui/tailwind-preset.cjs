/**
 * Tailwind preset compartido del ecosistema Datagrowth.
 *
 * Los consumidores que compilan Tailwind localmente (ej. `app-backend` con
 * clases JIT propias como `shadow-card`, `ring-brand-lime`) deben usar
 * este preset para mantener una única fuente de verdad de tokens y
 * para incluir las variantes responsive que `dg/...` necesita.
 *
 * El preset viaja DENTRO del wheel pip `datagrowth-common` (PyPI), bajo
 * `datagrowth_common/ui/tailwind-preset.cjs`. PyPI es la única fuente de
 * verdad: ni paquete npm separado, ni dep github en `package.json`. El
 * consumidor pip-instala el paquete (que ya hace para `register_ui`,
 * auth, helpers, etc.) y resuelve la ruta del fichero hacia su
 * `tailwind.config.js`.
 *
 * Uso (consumidor con `.venv` o equivalente):
 *
 *   const path = require("path");
 *   const { execSync } = require("child_process");
 *   const presetPath = execSync(
 *     'python -c "import datagrowth_common.ui as m, os; ' +
 *     'print(os.path.join(os.path.dirname(m.__file__), ' +
 *     "'tailwind-preset.cjs'))\""
 *   ).toString().trim();
 *
 *   module.exports = {
 *     presets: [require(presetPath)],
 *     content: ["./src/templates/**\/*.html"],
 *   };
 *
 * En contenedores multi-stage (frontend-build de node sin python), el
 * stage Python que ya pip-instala el paquete debe `COPY` el fichero a
 * una ruta vendored en el stage de node.
 *
 * El preset NO declara `content` ni `darkMode`: cada consumidor define
 * su scope de templates. La `safelist` aquí cubre las variantes
 * responsive usadas por los layouts del paquete (`dg/layouts/*.html`)
 * que de otro modo serían pisadas por la `.hidden`/`.block` que cada
 * consumidor regenera en su propio Tailwind local (cargado DESPUÉS del
 * `tailwind.compiled.css` del paquete → cascada CSS gana el consumidor).
 *
 * Bug que motivó el preset (2026-05-12 app-backend):
 *   <aside class="hidden md:flex"> en sidebar_shell.html quedaba
 *   permanentemente `display:none` porque el `app.css` local del
 *   backend redefinía `.hidden` (sin emitir `.md:flex`) y al cargarse
 *   después ganaba la cascada.
 */
/** @type {Partial<import('tailwindcss').Config>} */
module.exports = {
  safelist: [
    'sm:block',
    'sm:inline-flex',
    'md:flex',
    'md:grid-cols-2',
    'md:px-6',
    'lg:grid-cols-3',
  ],
  theme: {
    extend: {
      // Colores brand/semánticos via CSS variables RGB triplet con
      // `<alpha-value>` para que Tailwind genere `bg-brand-lime/15`
      // y similares respetando el override del cliente. Cada consumidor
      // (backend, app cliente) declara los triplets en su `tokens.css`
      // / `tokens-override.css`:
      //   --color-brand-primary-rgb: 181 255 130;   (sin coma, sin alpha)
      // El paquete entrega defaults neutrales gray; el override del
      // cliente los pisa con sus colores reales.
      colors: {
        // Brand: principal + sub-tonos `-400` (hover oscuro) y `-600`
        // (énfasis sobre brand-secondary) mapeados a las vars `*-dark`
        // del set canónico. El resto de sub-tonos legacy (`-100`,
        // `-300`, `-500`...) caen al mismo valor que el principal —
        // los hosts no necesitan declarar una paleta de 10 tonos por
        // brand color. Si necesitas un alfa, usa el modificador de
        // Tailwind (`bg-brand-lime/15`) que respeta `<alpha-value>`.
        brand: {
          lime:        'rgb(var(--color-brand-primary-rgb)         / <alpha-value>)',
          'lime-400':  'rgb(var(--color-brand-primary-dark-rgb)    / <alpha-value>)',
          'lime-100':  'rgb(var(--color-brand-primary-rgb)         / <alpha-value>)',
          dark:        'rgb(var(--color-brand-secondary-rgb)       / <alpha-value>)',
          'dark-600':  'rgb(var(--color-brand-secondary-dark-rgb)  / <alpha-value>)',
          muted:       'rgb(var(--color-brand-muted-rgb)           / <alpha-value>)',
          'muted-100': 'rgb(var(--color-brand-muted-rgb)           / <alpha-value>)',
          'muted-600': 'rgb(var(--color-brand-muted-rgb)           / <alpha-value>)',
        },
        semantic: {
          success:      'rgb(var(--color-success-rgb)        / <alpha-value>)',
          'success-bg': 'rgb(var(--color-success-bg-rgb)     / <alpha-value>)',
          warning:      'rgb(var(--color-warning-rgb)        / <alpha-value>)',
          'warning-bg': 'rgb(var(--color-warning-bg-rgb)     / <alpha-value>)',
          danger:       'rgb(var(--color-danger-rgb)         / <alpha-value>)',
          'danger-bg':  'rgb(var(--color-danger-bg-rgb)      / <alpha-value>)',
          info:         'rgb(var(--color-info-rgb)           / <alpha-value>)',
          'info-bg':    'rgb(var(--color-info-bg-rgb)        / <alpha-value>)',
        },
        surface:          'var(--color-surface)',
        'surface-subtle': 'var(--color-surface-subtle)',
        panel:            'var(--color-panel)',
        border:           'var(--color-border)',
        fg: {
          DEFAULT: 'var(--color-text-primary)',
          muted:   'var(--color-text-muted)',
        },
        link: {
          DEFAULT: 'var(--color-link)',
          hover:   'var(--color-link-hover)',
        },
      },
      fontFamily: {
        sans: ['"DM Sans"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', '"Cascadia Code"', 'ui-monospace', 'Consolas', 'monospace'],
      },
      borderRadius: {
        sm:     '0.375rem',
        md:     '0.5rem',
        lg:     '0.75rem',
        xl:     '1rem',
        pill:   '9999px',
        button: '0.5rem',
        card:   '1rem',
      },
      boxShadow: {
        card:         '0 1px 3px 0 rgb(0 0 0 / 0.06), 0 1px 2px -1px rgb(0 0 0 / 0.04)',
        'card-hover': '0 4px 12px 0 rgb(0 0 0 / 0.10), 0 2px 4px -1px rgb(0 0 0 / 0.06)',
        popover:      '0 4px 16px 0 rgb(0 0 0 / 0.12), 0 2px 6px -2px rgb(0 0 0 / 0.08)',
        modal:        '0 20px 60px 0 rgb(0 0 0 / 0.25), 0 8px 24px -6px rgb(0 0 0 / 0.12)',
      },
      spacing: {
        18: '4.5rem',
        22: '5.5rem',
      },
    },
  },
};
