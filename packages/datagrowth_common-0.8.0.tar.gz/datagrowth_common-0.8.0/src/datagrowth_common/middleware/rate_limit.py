"""Rate-limit con slowapi + Redis.

Limites por defecto: 100/min globales. Cada app declara decoradores
especificos en endpoints sensibles (auth password, oauth, lanzar
pipelines, etc.).

Storage: Redis cuando `REDIS_URL` esta seteada. Si no, slowapi cae a
in-memory — compatible con dev local; en prod con N workers el contador
sera per-worker (aceptable para dev, no para prod multi-worker).

Flag env `DG_RATE_LIMIT_ENABLED` permite desactivar el middleware en
dev (default `1`).

`build_limiter()` devuelve `(limiter, exception_handler)`. La app los
registra:

    from datagrowth_common.middleware import build_limiter

    limiter, rate_limit_handler = build_limiter()
    if limiter is not None:
        from slowapi.errors import RateLimitExceeded
        from slowapi.middleware import SlowAPIMiddleware

        app.state.limiter = limiter
        app.add_exception_handler(RateLimitExceeded, rate_limit_handler)
        app.add_middleware(SlowAPIMiddleware)

`build_limiter()` devuelve `(None, None)` si slowapi no esta instalado
(extra `[middleware]` no presente).
"""

from __future__ import annotations

import os
from typing import Any, Callable


def is_rate_limit_enabled() -> bool:
    return os.getenv("DG_RATE_LIMIT_ENABLED", "1").lower() not in {
        "0",
        "false",
        "no",
    }


def build_limiter(
    *,
    redis_url: str | None = None,
    default_limits: tuple[str, ...] = ("100/minute",),
) -> tuple[Any | None, Callable | None]:
    """Crea limiter de slowapi + handler 429 con cuerpo JSON consistente.

    `redis_url` puede pasarse explicito; si None, se lee de `REDIS_URL`.
    Si la env esta vacia, el storage cae a `memory://` (per-worker).

    Devuelve `(None, None)` si slowapi no esta instalado.
    """
    try:
        from slowapi import Limiter
        from slowapi.errors import RateLimitExceeded
        from slowapi.util import get_remote_address
        from starlette.requests import Request
        from starlette.responses import JSONResponse
    except ImportError:
        return None, None

    storage_uri = (redis_url or os.getenv("REDIS_URL") or "").strip() or "memory://"

    limiter = Limiter(
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=list(default_limits),
        headers_enabled=True,
        enabled=is_rate_limit_enabled(),
    )

    def rate_limit_handler(request: Request, exc: RateLimitExceeded) -> JSONResponse:  # noqa: ARG001
        response = JSONResponse(
            status_code=429,
            content={
                "detail": {
                    "code": "RATE_LIMITED",
                    "message": "Too many requests. Retry later.",
                },
            },
        )
        if hasattr(exc, "headers") and exc.headers:
            for k, v in exc.headers.items():
                response.headers[k] = v
        return response

    return limiter, rate_limit_handler


__all__ = ["build_limiter", "is_rate_limit_enabled"]
