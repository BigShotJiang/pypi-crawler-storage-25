"""Asigna `X-Request-Id` por request y lo bindea a structlog + Sentry.

Encadena tres cosas en cada request:

1. Lee el header entrante `X-Request-Id` o genera uno nuevo (uuid4 hex,
   8-128 chars). Permite correlacionar requests HTTP con jobs ARQ cuando
   el caller propaga el id manualmente.
2. Lo bindea como contextvar de structlog para que cada log lo lleve sin
   pasarlo a mano.
3. Lo setea como tag Sentry (si esta instalado) y lo devuelve en la
   response como `X-Request-Id` — el cliente puede meterlo en su sistema
   de tracing.

`structlog.contextvars` usa `contextvars.ContextVar`, asi que es
asyncio-seguro: cada request tiene su propio scope.
"""

from __future__ import annotations

from uuid import uuid4

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


HEADER_NAME = "X-Request-Id"


class RequestIdMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        incoming = (request.headers.get(HEADER_NAME) or "").strip()
        rid = incoming if 8 <= len(incoming) <= 128 else uuid4().hex
        request.state.request_id = rid

        try:
            import structlog

            structlog.contextvars.bind_contextvars(request_id=rid)
            bound = True
        except ImportError:
            bound = False

        try:
            try:
                import sentry_sdk

                sentry_sdk.set_tag("request_id", rid)
            except ImportError:
                pass
            response: Response = await call_next(request)
        finally:
            if bound:
                import structlog

                structlog.contextvars.unbind_contextvars("request_id")

        response.headers[HEADER_NAME] = rid
        return response


__all__ = ["RequestIdMiddleware", "HEADER_NAME"]
