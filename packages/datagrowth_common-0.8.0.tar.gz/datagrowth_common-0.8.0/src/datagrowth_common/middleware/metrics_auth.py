"""Basic-auth para el endpoint `/metrics`.

Prometheus expone series internas (paths, runs en curso, coste por
agente). Sin proteccion, cualquier scraper externo puede ver el detalle
operativo. La proteccion es simple: usuario + password en envs
`METRICS_USER` / `METRICS_PASS`.

Si `METRICS_USER` (o el password) esta vacio, el endpoint responde 404
(`not found`). Es la mejor senal para Prometheus: "no scrapees aqui".
Sin esta proteccion, exponer 200 sin auth en produccion es un leak.

Comparacion con `secrets.compare_digest` para evitar timing attacks.
"""

from __future__ import annotations

import base64
import os
import secrets

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import PlainTextResponse, Response


_DEFAULT_METRICS_PATH = "/metrics"


def _expected_credentials(
    *, user_env: str = "METRICS_USER", pass_env: str = "METRICS_PASS",
) -> tuple[str, str] | None:
    user = os.getenv(user_env, "").strip()
    password = os.getenv(pass_env, "").strip()
    if not user or not password:
        return None
    return user, password


def is_metrics_enabled() -> bool:
    """`/metrics` solo se monta cuando hay credenciales. Default OFF."""
    return _expected_credentials() is not None


class MetricsAuthMiddleware(BaseHTTPMiddleware):
    """Bloquea o autoriza `/metrics`. Otros paths pasan inalterados.

    Acepta `metrics_path` para apps que sirvan las metricas en una ruta
    custom (raro). Acepta `user_env`/`pass_env` por si la app quiere
    nombres de env distintos.
    """

    def __init__(
        self,
        app,
        *,
        metrics_path: str = _DEFAULT_METRICS_PATH,
        user_env: str = "METRICS_USER",
        pass_env: str = "METRICS_PASS",
    ) -> None:
        super().__init__(app)
        self._metrics_path = metrics_path
        self._user_env = user_env
        self._pass_env = pass_env

    async def dispatch(self, request: Request, call_next):
        if request.url.path != self._metrics_path:
            return await call_next(request)

        creds = _expected_credentials(
            user_env=self._user_env, pass_env=self._pass_env,
        )
        if creds is None:
            return PlainTextResponse("not found", status_code=404)

        expected_user, expected_pass = creds
        auth = request.headers.get("authorization", "")
        if not auth.lower().startswith("basic "):
            return Response(
                "auth required",
                status_code=401,
                headers={"WWW-Authenticate": 'Basic realm="metrics"'},
            )

        try:
            decoded = base64.b64decode(auth[6:]).decode("utf-8")
            user, password = decoded.split(":", 1)
        except Exception:
            return PlainTextResponse("invalid auth", status_code=401)

        if not (
            secrets.compare_digest(user, expected_user)
            and secrets.compare_digest(password, expected_pass)
        ):
            return PlainTextResponse("invalid credentials", status_code=401)

        return await call_next(request)


__all__ = ["MetricsAuthMiddleware", "is_metrics_enabled"]
