"""Cabeceras de seguridad por defecto.

Aplica HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy,
Permissions-Policy y un CSP inicial laxo a toda response.

CSP: arranca con `'unsafe-inline'` en scripts/styles por compatibilidad
con HTMX y libs CDN populares. Cada app endurece su CSP en `csp=...` si
tiene control de su tooling frontend.

Flag env `DG_SECURITY_HEADERS_ENABLED` permite desactivar el middleware
en dev local (default `1`).
"""

from __future__ import annotations

import os

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


DEFAULT_CSP = (
    "default-src 'self'; "
    "img-src 'self' data: https:; "
    "style-src 'self' 'unsafe-inline'; "
    "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://unpkg.com; "
    "font-src 'self' data:; "
    "connect-src 'self'; "
    "frame-ancestors 'none'"
)

DEFAULT_PERMISSIONS_POLICY = "camera=(), microphone=(), geolocation=()"


def is_security_headers_enabled() -> bool:
    return os.getenv("DG_SECURITY_HEADERS_ENABLED", "1").lower() not in {
        "0",
        "false",
        "no",
    }


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Anade cabeceras de seguridad a cada response.

    `setdefault` para no pisar valores explicitos que algun handler haya
    seteado.
    """

    def __init__(
        self,
        app,
        *,
        csp: str | None = None,
        permissions_policy: str | None = None,
        hsts_max_age: int = 63072000,
    ) -> None:
        super().__init__(app)
        self._csp = csp or DEFAULT_CSP
        self._perm = permissions_policy or DEFAULT_PERMISSIONS_POLICY
        self._hsts = f"max-age={hsts_max_age}; includeSubDomains"

    async def dispatch(self, request: Request, call_next):
        response: Response = await call_next(request)
        response.headers.setdefault("Strict-Transport-Security", self._hsts)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault(
            "Referrer-Policy", "strict-origin-when-cross-origin",
        )
        response.headers.setdefault("Content-Security-Policy", self._csp)
        response.headers.setdefault("Permissions-Policy", self._perm)
        return response


__all__ = [
    "SecurityHeadersMiddleware",
    "is_security_headers_enabled",
    "DEFAULT_CSP",
    "DEFAULT_PERMISSIONS_POLICY",
]
