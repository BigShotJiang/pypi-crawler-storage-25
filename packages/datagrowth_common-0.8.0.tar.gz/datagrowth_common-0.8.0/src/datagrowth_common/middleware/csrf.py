"""CSRF double-submit cookie.

Patron: el servidor setea cookie `dg_csrf` no-httpOnly con un token
aleatorio. Cualquier request mutante (POST/PUT/PATCH/DELETE) debe enviar
el mismo token en el header `X-CSRF-Token`. El navegador adjunta la
cookie automaticamente con origen mismo-sitio, pero solo nuestro propio
JS lee la cookie y la mete en el header — un atacante cross-site no
puede forjar el header desde otro origen.

HTMX se cablea desde el template base: un script lee `dg_csrf` y la
inyecta en cada `htmx:configRequest`.

Endpoints exentos por defecto:
- Metodos seguros (GET/HEAD/OPTIONS).
- Webhooks (`/webhooks/...`): server-to-server con HMAC propio.
- Callback OAuth (`/auth/oauth/{provider}/callback`): el cliente no ha
  podido ver la cookie todavia, y el `dg_oauth_state` cookie + el `code`
  de Supabase ya cubren CSRF en ese flow.

**`/auth/password` NO esta exento** — es POST mutante con efecto
permanente en el estado del navegador (set cookie de sesion). Exemptarlo
abre login-CSRF: un atacante forja un POST desde su sitio, la victima
queda autenticada como el atacante y cualquier accion subsecuente
(subir documentos, anadir tarjetas) va a la cuenta del atacante. El
GET a `/login` ya setea la cookie CSRF, asi que el POST tiene token
disponible. Apps API-first que no rendericen `/login` HTML deben pedir
la cookie con un `GET /` inicial.

Para anadir exenciones propias, pasa `extra_exempt_prefixes=("/foo/",)`.
Se valida que cada prefix no sea `/` o vacio (footgun: desactivaria
CSRF entero).

Flag env `DG_CSRF_ENABLED` permite desactivar en dev (default `1`).
"""

from __future__ import annotations

import os
import secrets

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response


COOKIE_NAME = "dg_csrf"
HEADER_NAME = "X-CSRF-Token"
FORM_FIELD = "csrf_token"

_SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})
_DEFAULT_EXEMPT_PREFIXES: tuple[str, ...] = (
    "/webhooks/",
    "/auth/oauth/",
)


def is_csrf_enabled() -> bool:
    return os.getenv("DG_CSRF_ENABLED", "1").lower() not in {"0", "false", "no"}


def _is_secure_cookie() -> bool:
    """`Secure` cookie cuando el backend sirve por HTTPS. En dev local
    debe ir sin `Secure` o el navegador no la persiste.
    """
    from ..env import is_prod_env

    return is_prod_env()


_INVALID_EXEMPT_PREFIXES = frozenset({"", "/"})


def _validate_exempt_prefixes(prefixes: tuple[str, ...]) -> None:
    """Rechaza prefixes que desactivarian CSRF de facto.

    `("/",)` matchearia toda ruta -> CSRF off para todo el handler.
    `("",)` matchearia todo path con startswith. Cualquier prefix que no
    empiece por `/` indica error del consumidor (path relativo).
    """
    for prefix in prefixes:
        if prefix in _INVALID_EXEMPT_PREFIXES or not prefix.startswith("/"):
            raise ValueError(
                f"invalid-csrf-exempt-prefix: {prefix!r} "
                "(must start with '/', cannot be '/' or empty)"
            )


class CSRFMiddleware(BaseHTTPMiddleware):
    def __init__(
        self,
        app,
        *,
        extra_exempt_prefixes: tuple[str, ...] = (),
    ) -> None:
        super().__init__(app)
        _validate_exempt_prefixes(extra_exempt_prefixes)
        self._exempt_prefixes = _DEFAULT_EXEMPT_PREFIXES + tuple(extra_exempt_prefixes)

    def _is_exempt_path(self, path: str) -> bool:
        return any(path.startswith(prefix) for prefix in self._exempt_prefixes)

    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        method = request.method.upper()
        exempt = method in _SAFE_METHODS or self._is_exempt_path(path)

        if not exempt:
            cookie = request.cookies.get(COOKIE_NAME)
            submitted = await _extract_submitted_token(request)
            if (
                not cookie
                or not submitted
                or not secrets.compare_digest(cookie, submitted)
            ):
                return JSONResponse(
                    status_code=403,
                    content={
                        "detail": {
                            "code": "CSRF_TOKEN_MISMATCH",
                            "message": "csrf-token-mismatch",
                        },
                    },
                )

        response: Response = await call_next(request)

        if COOKIE_NAME not in request.cookies:
            token = secrets.token_urlsafe(32)
            response.set_cookie(
                COOKIE_NAME,
                token,
                secure=_is_secure_cookie(),
                httponly=False,
                samesite="lax",
                path="/",
            )
        return response


async def _extract_submitted_token(request: Request) -> str | None:
    """Devuelve el token enviado por el cliente, sea por header o por form.

    Prioridad: header `X-CSRF-Token`. Si ausente y el Content-Type es
    `application/x-www-form-urlencoded`, parsea el body crudo. Starlette
    cachea el body al llamar `request.body()`, asi que FastAPI lo puede
    releer luego en el handler.

    `multipart/form-data` queda fuera (consumir el stream sin reset es
    fragil). Para uploads sin HTMX, anadir el header `X-CSRF-Token` a
    mano desde JS.

    Cualquier excepcion devuelve `None` → 403 deny-by-default.
    """
    header = request.headers.get(HEADER_NAME)
    if header:
        return header

    content_type = (request.headers.get("content-type") or "").lower()
    if not content_type.startswith("application/x-www-form-urlencoded"):
        return None

    try:
        body = await request.body()
    except Exception:
        return None
    if not body:
        return None

    try:
        from urllib.parse import parse_qsl

        decoded = body.decode("utf-8", errors="ignore")
        for key, value in parse_qsl(decoded, keep_blank_values=True):
            if key == FORM_FIELD:
                return value
    except Exception:
        return None
    return None


__all__ = [
    "CSRFMiddleware",
    "is_csrf_enabled",
    "COOKIE_NAME",
    "HEADER_NAME",
    "FORM_FIELD",
]
