"""Middlewares de produccion compartidos entre apps Datagrowth.

Cuatro piezas opt-in que cada app monta segun sus necesidades:

- `RequestIdMiddleware`: asigna `X-Request-Id` por request y lo bindea
  a structlog + Sentry.
- `SecurityHeadersMiddleware`: HSTS, X-Frame-Options, CSP laxo,
  Referrer-Policy, Permissions-Policy.
- `CSRFMiddleware`: double-submit cookie para metodos mutantes.
- `build_limiter(redis_url)`: limiter de slowapi (rate-limit). Devuelve
  `(limiter, handler)` para registrar en la app.

Todos respetan flags `DG_*_ENABLED` para desactivacion granular en dev.
"""

from .request_id import RequestIdMiddleware
from .security import SecurityHeadersMiddleware, is_security_headers_enabled
from .csrf import CSRFMiddleware, is_csrf_enabled
from .rate_limit import build_limiter, is_rate_limit_enabled
from .metrics_auth import MetricsAuthMiddleware, is_metrics_enabled

__all__ = [
    "RequestIdMiddleware",
    "SecurityHeadersMiddleware",
    "is_security_headers_enabled",
    "CSRFMiddleware",
    "is_csrf_enabled",
    "build_limiter",
    "is_rate_limit_enabled",
    "MetricsAuthMiddleware",
    "is_metrics_enabled",
]
