"""Endpoints self-service GDPR: export ZIP, delete-request, cancel-delete.

Generico para apps Datagrowth. Cada app instancia el router con sus
deps de auth + DB y puede inyectar `extra_exporters` para anadir blobs
JSON propios al ZIP de exportacion (runs, leads, etc.).

Ver `make_me_router(...)` en `router.py`.
"""

from .router import make_me_router, Exporter

__all__ = ["make_me_router", "Exporter"]
