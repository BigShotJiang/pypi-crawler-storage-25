"""Router GDPR self-service generico.

Tres endpoints:

- `GET    /me/data/export`         - descarga ZIP con todos los datos
  asociados al uid en las tablas que registra la app.
- `DELETE /me/data`                - solicita borrado diferido (N dias de
  gracia legal). Un cron purga el grant y la solicitud tras `purge_at`.
- `POST   /me/data/delete/cancel`  - cancela la solicitud si sigue en
  gracia.

La fabrica `make_me_router(...)` permite a cada app inyectar:

- `auth_dep`: FastAPI dep que devuelve un objeto con `.uid` (UUID o
  string) y opcionalmente `.email`, `.is_admin`. Cada request pasa por
  este dep.
- `session_dep`: FastAPI dep que devuelve una `Session` de SQLAlchemy.
- `extra_exporters`: lista de funciones que reciben `(session, user)` y
  devuelven `(filename, content_bytes_or_str)` para sumarlos al ZIP.
  Permiten a cada app exportar tablas propias (AgentRun, leads, etc.)
  sin que el paquete las conozca.
- `schema`: schema SQL donde viven `user_audit_log` y
  `user_deletion_request`. Default `None` (sin prefijo, template apps).
- `trust_proxy`: si la app vive detras de un proxy de confianza
  (Caddy/nginx/Easypanel que strippea `X-Forwarded-For` cliente-supplied
  y lo reescribe con la IP real), pasa `True` para que el audit log GDPR
  registre la IP del cliente final en vez de la del proxy. Default
  `False` — sin esto, leer `X-Forwarded-For` sin proxy de confianza
  permite que cualquier cliente falsifique la IP de auditoria (atacante
  envia `X-Forwarded-For: 1.2.3.4` y queda registrado como esa IP).

Audit log: cada accion emite una fila en `user_audit_log` con IP + UA.
Si el audit falla, se loguea WARNING pero el handler responde 200 — el
delete-request o el export son la accion principal.
"""

from __future__ import annotations

import io
import json
import os
import zipfile
from datetime import datetime, timedelta
from typing import Any, Callable, Protocol

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, StreamingResponse
from sqlalchemy import text
from sqlalchemy.orm import Session

from ..audit import emit as audit_emit
from ..logger import get_logger

log = get_logger(__name__)


class _UserLike(Protocol):
    """Cualquier objeto con `.uid`. `.email`/`.is_admin` son opcionales."""

    uid: str


Exporter = Callable[[Session, Any], tuple[str, bytes | str]]
"""Firma de un exporter inyectado: recibe (session, user) y devuelve
`(filename, content)`. El contenido puede ser str (codificado UTF-8) o
bytes (escrito tal cual al ZIP).
"""


def _client_ip(request: Request, *, trust_proxy: bool = False) -> str | None:
    """Devuelve la IP del cliente. Si `trust_proxy=True`, honra
    `X-Forwarded-For` (primer hop, truncado a 64 chars). Si False, ignora
    el header (no confiar en input cliente-supplied)."""
    if trust_proxy:
        fwd = request.headers.get("x-forwarded-for")
        if fwd:
            return fwd.split(",")[0].strip()[:64] or None
    return request.client.host if request.client else None


def _grace_days() -> int:
    try:
        return max(int(os.getenv("DG_DELETE_GRACE_DAYS", "30")), 1)
    except ValueError:
        return 30


def make_me_router(
    *,
    auth_dep: Callable[..., Any],
    session_dep: Callable[..., Session],
    extra_exporters: tuple[Exporter, ...] = (),
    schema: str | None = None,
    tags: tuple[str, ...] = ("me",),
    trust_proxy: bool = False,
) -> APIRouter:
    """Construye un APIRouter con los 3 endpoints GDPR.

    `schema` aplica solo a `user_audit_log` y `user_deletion_request`. Si
    `None`, las tablas se referencian sin prefijo (caso template apps);
    si `"backend"`, como `backend.user_audit_log` (caso control plane).
    """
    router = APIRouter(tags=list(tags))

    deletion_table = (
        f"{schema}.user_deletion_request" if schema else "user_deletion_request"
    )
    audit_table = f"{schema}.user_audit_log" if schema else "user_audit_log"

    @router.get("/me/data/export")
    async def export_my_data(
        request: Request,
        user: Any = Depends(auth_dep),
        session: Session = Depends(session_dep),
    ) -> StreamingResponse:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            profile = {
                "uid": str(getattr(user, "uid", "")),
                "email": getattr(user, "email", None),
                "is_admin": getattr(user, "is_admin", None),
                "exported_at": datetime.utcnow().isoformat() + "Z",
            }
            zf.writestr("profile.json", json.dumps(profile, indent=2))

            try:
                rows = session.execute(
                    text(
                        f"select id, actor_id, target_user_id, action, metadata, "
                        f"ip, user_agent, created_at from {audit_table} "
                        f"where target_user_id = :uid or actor_id = :uid "
                        f"order by created_at desc limit 10000"
                    ),
                    {"uid": str(user.uid)},
                ).fetchall()
                zf.writestr(
                    "audit_log.json",
                    json.dumps(
                        [
                            {
                                "id": r[0],
                                "actor_id": str(r[1]) if r[1] else None,
                                "target_user_id": str(r[2]) if r[2] else None,
                                "action": r[3],
                                "metadata": r[4] if isinstance(r[4], dict) else {},
                                "ip": r[5],
                                "user_agent": r[6],
                                "created_at": r[7].isoformat() if r[7] else None,
                            }
                            for r in rows
                        ],
                        default=str,
                        indent=2,
                    ),
                )
            except Exception as exc:
                log.warning("export_audit_failed", error=str(exc), uid=str(user.uid))
                zf.writestr(
                    "audit_log.error.txt", f"could-not-fetch-audit: {exc}",
                )

            for exporter in extra_exporters:
                try:
                    name, content = exporter(session, user)
                    if isinstance(content, str):
                        zf.writestr(name, content)
                    else:
                        zf.writestr(name, content)
                except Exception as exc:
                    log.warning(
                        "export_extra_failed",
                        exporter=getattr(exporter, "__name__", "anonymous"),
                        error=str(exc),
                        uid=str(user.uid),
                    )

        audit_emit(
            session,
            actor_id=str(user.uid),
            target_user_id=str(user.uid),
            action="data-export",
            ip=_client_ip(request, trust_proxy=trust_proxy),
            user_agent=request.headers.get("user-agent"),
            schema=schema,
        )

        buf.seek(0)
        filename = f"datagrowth-export-{user.uid}.zip"
        return StreamingResponse(
            iter([buf.getvalue()]),
            media_type="application/zip",
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
            },
        )

    @router.delete("/me/data")
    async def delete_my_data(
        request: Request,
        user: Any = Depends(auth_dep),
        session: Session = Depends(session_dep),
    ) -> JSONResponse:
        grace = _grace_days()
        now = datetime.utcnow()
        purge_at = now + timedelta(days=grace)
        ip = _client_ip(request, trust_proxy=trust_proxy)
        ua = (request.headers.get("user-agent") or "")[:500] or None

        existing = session.execute(
            text(
                f"select requested_at, purge_at from {deletion_table} "
                f"where user_id = :uid"
            ),
            {"uid": str(user.uid)},
        ).first()
        if existing is not None:
            return JSONResponse(
                {
                    "status": "already-scheduled",
                    "requested_at": existing[0].isoformat() + "Z"
                    if existing[0]
                    else None,
                    "purge_at": existing[1].isoformat() + "Z" if existing[1] else None,
                }
            )

        session.execute(
            text(
                f"insert into {deletion_table} "
                f"(user_id, requested_at, purge_at, requested_ip, requested_ua) "
                f"values (:uid, :req, :purge, :ip, :ua)"
            ),
            {
                "uid": str(user.uid),
                "req": now,
                "purge": purge_at,
                "ip": ip,
                "ua": ua,
            },
        )
        session.commit()

        audit_emit(
            session,
            actor_id=str(user.uid),
            target_user_id=str(user.uid),
            action="data-delete-requested",
            metadata={
                "purge_at": purge_at.isoformat() + "Z",
                "grace_days": grace,
            },
            ip=ip,
            user_agent=request.headers.get("user-agent"),
            schema=schema,
        )

        return JSONResponse(
            {
                "status": "scheduled",
                "requested_at": now.isoformat() + "Z",
                "purge_at": purge_at.isoformat() + "Z",
            }
        )

    @router.post("/me/data/delete/cancel")
    async def cancel_delete_my_data(
        request: Request,
        user: Any = Depends(auth_dep),
        session: Session = Depends(session_dep),
    ) -> JSONResponse:
        existing = session.execute(
            text(
                f"select purge_at from {deletion_table} "
                f"where user_id = :uid"
            ),
            {"uid": str(user.uid)},
        ).first()
        if existing is None:
            return JSONResponse({"status": "no-request"}, status_code=404)

        session.execute(
            text(f"delete from {deletion_table} where user_id = :uid"),
            {"uid": str(user.uid)},
        )
        session.commit()

        audit_emit(
            session,
            actor_id=str(user.uid),
            target_user_id=str(user.uid),
            action="data-delete-cancelled",
            metadata={
                "original_purge_at": existing[0].isoformat() + "Z"
                if existing[0]
                else None,
            },
            ip=_client_ip(request, trust_proxy=trust_proxy),
            user_agent=request.headers.get("user-agent"),
            schema=schema,
        )

        return JSONResponse({"status": "cancelled"})

    return router


__all__ = ["make_me_router", "Exporter"]
