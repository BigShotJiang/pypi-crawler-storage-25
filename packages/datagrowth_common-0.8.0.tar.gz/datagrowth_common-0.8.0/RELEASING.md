# Release de datagrowth-common

## Pre-requisitos (una sola vez)

1. **Trusted publishing en PyPI** (`https://pypi.org/manage/account/publishing/`):
   - Owner: `Datagrowth`
   - Repository: `datagrowth-common`
   - Workflow: `release.yml`
   - Environment: (vacio)

   No hace falta `PYPI_TOKEN` con trusted publishing. Alternativa si no
   se puede usar trusted publishing: `gh secret set PYPI_TOKEN --body
   "<token>"` y cambiar el step `pypa/gh-action-pypi-publish` para usar
   `password: ${{ secrets.PYPI_TOKEN }}`.

2. **Permisos en el repo**:
   - Settings → Actions → General → Workflow permissions: Read & Write.
   - Branch protection en `main`: requerir PR reviews.

## Checklist de release

Antes de hacer el tag:

### 1. Bump de version coherente en 5 sitios

`datagrowth-common` mantiene el pin sincronizado en cinco lugares
(memoria `feedback_align_datagrowth_common_pins`):

```
datagrowth-common/pyproject.toml                       version = "X.Y.Z"
datagrowth-common/src/datagrowth_common/__init__.py    __version__ = "X.Y.Z"
datagrowth-common/template/pyproject.toml              datagrowth-common[supabase]>=X.Y.Z,<X.(Y+1)
app-backend/pyproject.toml                             datagrowth-common[supabase]>=X.Y.Z,<X.(Y+1)
app-backend/infra/Dockerfile                           datagrowth-common>=X.Y.Z,<X.(Y+1)  (vendor stage)
```

Si te saltas uno, las apps existentes no instalan la version nueva
o el backend usa una version vieja en vendor stage del Dockerfile.

### 2. Actualizar `CHANGELOG.md`

Nuevo header `## [X.Y.Z] — YYYY-MM-DD`. Si hubo fixes de seguridad,
abrir con seccion `### Security` antes de `### Added`/`### Fixed`.

### 3. Actualizar `README.md`

Si la release anade submodulos nuevos o cambia API publica, actualizar:
- Linea introductoria con la lista de funcionalidades (v0.8.0+, etc.).
- Tabla por modulo (`### Production-readiness helpers (vX.Y.Z+)`).
- Pin recomendado: `pip install "datagrowth-common[...]>=X.Y,<X.(Y+1)"`.

### 4. Validacion local

```bash
cd datagrowth-common
pip install -e ".[dev,supabase,observability,middleware]"
pytest -q                                # debe pasar todo
python -m build                          # builda sdist + wheel
twine check dist/*                       # valida que el wheel es publicable
```

### 5. Tag + push

```bash
git tag -a vX.Y.Z -m "Release X.Y.Z: <one-liner>"
git push origin vX.Y.Z
```

El workflow `.github/workflows/release.yml` se dispara al ver el tag y:
- Compila Tailwind del paquete (necesita node).
- Build wheel + sdist.
- Publica a PyPI via trusted publishing.
- Job `verify-template` instala el wheel recien publicado contra
  `template/` y corre los smoke tests.

## Tras el release publicado

### 6. Bump del backend

`app-backend` debe apuntar a la version recien publicada en dos sitios
(`pyproject.toml` runtime dep + `infra/Dockerfile` vendor stage). Si ya
hiciste el bump en el paso 1, este punto es solo abrir PR + merge a main
en `app-backend` y redeploy.

### 7. Propagar a apps `app-*` existentes

En la UI del backend, ir a `/packages/<slug>` y pulsar "Actualizar
common" en cada package. Esto abre un PR en cada repo `app-*` con:
- Bump del pin de `datagrowth-common`.
- Sync de archivos boilerplate (Dockerfile, deps, src/api/auth.py,
  src/api/health.py, .github/workflows/ci.yml, .claude/rules/*, etc.).
- Sync create-only de plantillas (docs/PRIVACY.md, docs/legal/*.md,
  docs/RUNBOOK.md, infra/backup.sh, .github/CODEOWNERS).
- Migraciones nuevas (`template/migrations/v*.sql`) create-only.
- Append de env vars nuevas en `.env.example`.
- Patchers quirurgicos sobre `src/main.py` y partials customizables
  (idempotentes; reportan `structure-mismatch` si el operador
  customizo el patron canonico).

Cada PR debe revisarse antes de mergear — la descripcion lista los
archivos modificados y alerta de cualquier patcher con mismatch.

### 8. Verificar prod

- `app-backend` redeploy: verificar `/live` y `/ready` 200.
- En al menos UNA app que recibio "Actualizar common": verificar
  `/live`, `/ready`, `/privacy`, `/me/data/export` (con login).
- `claude /prod-ready-checklist` en la app verificada: `blockers == 0`.

## Hotfix (release patch)

```bash
# 1. Fix en main.
# 2. Bump patch en los 5 sitios (X.Y.(Z+1)).
# 3. CHANGELOG con entrada `## [X.Y.Z+1] — YYYY-MM-DD`.
# 4. Tag + push (igual que release normal).
```

PyPI NO permite sobreescribir una version ya publicada — si el tag se
publico parcialmente (job verify-template fallo tras el upload), bumpa
a `X.Y.Z+1` con el fix.

## Rollback

```bash
# Si el tag falla antes de publicar a PyPI:
git tag -d vX.Y.Z
git push --delete origin vX.Y.Z

# Si ya se publico a PyPI: NO se puede yank facil. Bumpa a patch con
# el fix y publica X.Y.(Z+1). En PyPI puedes hacer `yank` (marca la
# version como no-instalable por nuevos resolvers) desde el UI:
# https://pypi.org/manage/project/datagrowth-common/release/X.Y.Z/
```

## Consumidores actuales

- `app-backend/pyproject.toml`: `datagrowth-common[supabase]>=X.Y.Z,<X.(Y+1)`.
- `app-backend/infra/Dockerfile` vendor stage: `datagrowth-common>=X.Y.Z,<X.(Y+1)`.
- `datagrowth-common/template/pyproject.toml`: `datagrowth-common[supabase]>=X.Y.Z,<X.(Y+1)` (apps generadas heredan).
- Cada `app-*` en GitHub: pin propio en su `pyproject.toml` — se actualiza via "Actualizar common".
