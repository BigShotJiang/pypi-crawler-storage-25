/**
 * Tailwind del paquete `datagrowth-common.ui`.
 *
 * Compila `_tailwind.source.css` → `static/css/tailwind.compiled.css` que
 * `register_ui()` sirve runtime. El `theme.extend` y la `safelist` viven
 * en `./tailwind-preset.cjs` para ser reutilizados por los consumidores
 * (backend Datagrowth y futuras apps con JIT propio).
 */
/** @type {import('tailwindcss').Config} */
module.exports = {
  presets: [require('./src/datagrowth_common/ui/tailwind-preset.cjs')],
  content: [
    './src/datagrowth_common/ui/templates/**/*.html',
    // El scaffold `template/` se copia a cada app generada y usa el
    // mismo `tailwind.compiled.css` del paquete. Hay que escanearlo
    // para que las clases referenciadas allí (p.ej. `sidebar-section-label`)
    // sobrevivan al purge y queden disponibles en la app runtime.
    './template/src/templates/**/*.html',
  ],
  darkMode: ['class', '[data-theme="dark"]'],
  plugins: [],
};
