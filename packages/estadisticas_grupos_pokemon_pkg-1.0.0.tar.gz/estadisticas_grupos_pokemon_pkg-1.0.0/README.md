# Librería de descarga de estadísticas de grupos de pokemons

##Funcionalidades básicas

###1. get_grupos_pokemon
Devuelve la lista de grupos de pokemons

###2. get_altura_media_grupo
Devuelve la altura media de un determinado grupo de pokemons

###3. get_peso_medio_grupo
Devuelve el peso medio de un determnado grupo de pokemons

###La forma de instalarlo es con:
pip install estadisticas_grupos_pokemon_pkg

###Ejemplos de importación en proyecto cliente:
from estadisticas_grupos_pokemon_pkg import get_grupos_pokemon, get_altura_media_grupo, get_peso_medio_grupo

###Ejemplo de uso en proyecto cliente:
    grupos = get_grupos_pokemon()
    print("Grupos disponibles:", grupos)

    for grupo in grupos:
        altura = get_altura_media_grupo(grupo)
        peso = get_peso_medio_grupo(grupo)
        print(f"Grupo: {grupo} -> Altura media: {altura}, Peso medio: {peso}")
