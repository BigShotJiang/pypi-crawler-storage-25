import pandas as pd
import os

CSV_PATH = os.path.join(os.path.dirname(__file__), '../carga_datos_pokemon_pkg/estadisticas_grupos.csv')

def get_grupos_pokemon():
    df = pd.read_csv(CSV_PATH)
    return df.index.tolist() if 'grupo' not in df.columns else df['grupo'].tolist()

def get_altura_media_grupo(grupo):
    df = pd.read_csv(CSV_PATH)
    if 'grupo' in df.columns:
        row = df[df['grupo'] == grupo]
        if not row.empty:
            return float(row['height'].values[0])
    else:
        if grupo in df.index:
            return float(df.loc[grupo, 'height'])
    return None

def get_peso_medio_grupo(grupo):
    df = pd.read_csv(CSV_PATH)
    if 'grupo' in df.columns:
        row = df[df['grupo'] == grupo]
        if not row.empty:
            return float(row['weight'].values[0])
    else:
        if grupo in df.index:
            return float(df.loc[grupo, 'weight'])
    return None
