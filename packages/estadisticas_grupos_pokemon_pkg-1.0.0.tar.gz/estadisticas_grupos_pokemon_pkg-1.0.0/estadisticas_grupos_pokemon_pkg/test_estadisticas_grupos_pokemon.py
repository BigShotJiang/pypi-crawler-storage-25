from estadisticas_grupos_pokemon_pkg import get_grupos_pokemon, get_altura_media_grupo, get_peso_medio_grupo

def test_get_grupos_pokemon():
    grupos = get_grupos_pokemon()
    assert isinstance(grupos, list)
    assert len(grupos) > 0

def test_get_altura_media_grupo():
    grupos = get_grupos_pokemon()
    for grupo in grupos:
        altura = get_altura_media_grupo(grupo)
        assert isinstance(altura, float) or altura is None

def test_get_peso_medio_grupo():
    grupos = get_grupos_pokemon()
    for grupo in grupos:
        peso = get_peso_medio_grupo(grupo)
        assert isinstance(peso, float) or peso is None