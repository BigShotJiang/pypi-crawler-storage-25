from estadisticas_grupos_pokemon_pkg import get_grupos_pokemon, get_altura_media_grupo, get_peso_medio_grupo

if __name__ == "__main__":
    grupos = get_grupos_pokemon()
    print("Grupos disponibles:", grupos)

    for grupo in grupos:
        altura = get_altura_media_grupo(grupo)
        peso = get_peso_medio_grupo(grupo)
        print(f"Grupo: {grupo} -> Altura media: {altura}, Peso medio: {peso}")
