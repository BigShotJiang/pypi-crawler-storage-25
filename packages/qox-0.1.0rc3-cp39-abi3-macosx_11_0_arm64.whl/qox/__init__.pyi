from datetime import date, datetime
from typing import Final, List, Optional, Self

class Compounding:
    """
    Represents the compounding method for interest rates.
    Use the static methods to create instances.
    """
    @staticmethod
    def simple() -> "Compounding": ...
    @staticmethod
    def continuous() -> "Compounding": ...
    @staticmethod
    def compounded(freq: Frequency) -> "Compounding": ...
    @staticmethod
    def simple_then_compounded(freq: Frequency) -> "Compounding": ...
    def __repr__(self) -> str: ...

class DayCountConvention:
    ACT_360: DayCountConvention
    ACT_365_FIXED: DayCountConvention
    ACT_ACT: type[ActAct]
    THIRTY_360: type[Thirty360]

    def __repr__(self) -> str: ...

class Thirty360:
    US_ISDA: DayCountConvention
    GERMAN_ISDA: DayCountConvention
    EUROBOND_ISMA: DayCountConvention

class ActAct:
    ISDA: DayCountConvention

class Frequency:
    Annual: Frequency
    SemiAnnual: Frequency
    Quarterly: Frequency
    Monthly: Frequency
    Once: Frequency
    Infinite: Frequency

    # Constructor with optional value
    def __init__(self, value: Optional[int] = None) -> None: ...

    # Expose the getter
    @property
    def value(self) -> Optional[int]: ...

    # @staticmethod
    # def from_int(value: int) -> "Frequency": ...

    def __repr__(self) -> str: ...

class Tenor:
    """
    A representation of a time tenor for financial calculations.
    """

    @staticmethod
    def days(n: int) -> "Tenor":
        """Creates a tenor of n days."""
        ...

    @staticmethod
    def weeks(n: int) -> "Tenor":
        """Creates a tenor of n weeks."""
        ...

    @staticmethod
    def months(n: int) -> "Tenor":
        """Creates a tenor of n months."""
        ...

    @staticmethod
    def years(n: int) -> "Tenor":
        """Creates a tenor of n years."""
        ...

    def advance(self, from_date: date) -> date:
        """Returns the date advanced by the tenor from the provided date."""
        ...

class InterestRate:
    def __init__(
        self,
        rate: float,
        compounding: Compounding,
        dcc: DayCountConvention,
    ) -> None: ...

    # @property
    # def rate(self) -> float: ...

    def discount_factor(self, t: float) -> float: ...

class RateCurve:
    """
    A unified wrapper for various rate curve types.
    """

    @staticmethod
    def flat(rate: InterestRate) -> RateCurve:
        """Creates a flat rate curve."""
        ...

    @staticmethod
    def continuous(value: float, day_count_convention: DayCountConvention) -> RateCurve:
        """Creates a continuous compounding rate curve."""
        ...

    @staticmethod
    def interpolated(
        reference_date: date, tenors: List[Tenor], rates: List[InterestRate]
    ) -> "RateCurve":
        """Creates an interpolated rate curve."""
        ...

    def zero_rate(self, t: float) -> float:
        """Returns the zero rate for a given time t."""
        ...

    def discount_factor(self, t: float) -> float:
        """Returns the discount factor for a given time t."""
        ...

class VolSurface:
    """
    A unified wrapper for flat and interpolated volatility surfaces.
    """

    @staticmethod
    def flat(vol: float, day_count_convention: DayCountConvention) -> "VolSurface":
        """Creates a flat volatility surface with a constant value."""
        ...

    # @staticmethod
    # def interpolated(
    #     reference_date: date, tenors: List[Tenor], vols: List[float]
    # ) -> "VolSurface":
    #     """Creates an interpolated volatility surface from tenors and values."""
    #     ...

    def volatility(self, strike: float, t: float) -> float:
        """Returns the volatility for a given strike and time t."""
        ...

class OptionMarketFrame:
    """
    A market framework containing spot price, rate curve, and volatility surface.
    """

    def __init__(
        self, spot: float, rate_curve: RateCurve, vol_surface: VolSurface
    ) -> None:
        """Initializes the market frame."""
        ...

    @property
    def spot_price(self) -> float:
        """Returns the current spot price."""
        ...

class OptionType:
    Call: Final["OptionType"]
    Put: Final["OptionType"]

    # Optional: If you want to support int-like behavior or names
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class ExerciseStyle:
    American: Final["ExerciseStyle"]
    European: Final["ExerciseStyle"]

    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class VanillaOption:
    def __init__(
        self,
        strike: float,
        expiry_time: datetime,
        option_type: OptionType,
        exercise_style: ExerciseStyle,
    ) -> None: ...
    def valuation(self) -> ValuationBuilder:
        """Starts a valuation workflow for this specific instrument."""
        ...

    @property
    def strike(self) -> float: ...
    @property
    def years_to_expiry(self) -> float: ...

class FdmConfig:
    """
    Python wrapper for the Rust FdmConfig.
    """

    def __init__(
        self,
        time_steps: int = 50,
        nodes: int = 1000,
        grid_std_devs: float = 6.0,
    ) -> None:
        """
        Initializes FdmConfig with optional parameters.
        """
        ...

class Greeks:
    @property
    def delta(self) -> float: ...
    @property
    def gamma(self) -> float: ...
    @property
    def theta(self) -> float: ...
    @property
    def vega(self) -> Optional[float]: ...
    @property
    def rho(self) -> Optional[float]: ...

class OptionResult:
    @property
    def price(self) -> float: ...
    @property
    def greeks(self) -> Greeks: ...
    def __repr__(self) -> str: ...

class ValuationBuilder:
    def __init__(self, instrument: VanillaOption) -> None: ...
    def market(self, market_frame: OptionMarketFrame) -> "ValuationBuilder": ...
    def at(self, valuation_time: Optional[datetime] = None) -> "ValuationBuilder": ...
    def config(self, config: Optional[Config] = None) -> Self:
        """
        Sets the configuration for the valuation.
        Pass None or leave empty to revert to system defaults.
        """
        ...
    def compute(self) -> OptionResult: ...

class InstrumentPolicy:
    """
    A builder-style class for defining instrument-specific pricing policies.
    """

    def __init__(self) -> None: ...
    def american(self) -> Self:
        """Applies this policy to American-style options."""
        ...

    def european(self) -> Self:
        """Applies this policy to European-style options."""
        ...

    def put(self) -> Self:
        """Applies this policy to Put options."""
        ...

    def call(self) -> Self:
        """Applies this policy to Call options."""
        ...

    def analytic(self) -> Self:
        """Sets the pricing method for this selection to Analytic."""
        ...

    def fdm(self, fdm_config: Optional[FdmConfig] = None) -> Self:
        """
        Sets the pricing method for this selection to Finite Difference Method (FDM).

        Args:
            fdm_config: Optional configuration settings for the FDM engine.
        """
        ...

class Config:
    """
    Main configuration container for option pricing policies.
    """

    def __init__(self) -> None:
        """Creates a new Config with default pricing policies (e.g., American Puts using FDM)."""
        ...

    def add_policy(self, policy: InstrumentPolicy) -> Self:
        """
        Applies an InstrumentPolicy to this configuration.

        This will override existing settings for any instrument types (Style/Type)
        covered by the provided policy.

        Args:
            policy: The policy definition to apply.
        """
        ...

class PeriodCalculator:
    @staticmethod
    def days_between(start: date, end: date, convention: DayCountConvention) -> int: ...
    @staticmethod
    def year_fraction(
        start: datetime, end: datetime, convention: DayCountConvention
    ) -> float: ...
