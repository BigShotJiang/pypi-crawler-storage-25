from __future__ import annotations

import os

try:
    from openai import AzureOpenAI
except Exception:  # pragma: no cover
    AzureOpenAI = None  # type: ignore[assignment]

from .openai import OpenAIProvider


class AzureOpenAIProvider(OpenAIProvider):
    """Azure OpenAI using the OpenAI-compatible client."""

    name = "azure"

    def __init__(
        self,
        api_key: str | None = None,
        *,
        endpoint: str | None = None,
        api_version: str | None = None,
        deployment: str | None = None,
        model: str | None = None,
        max_input_tokens: int | None = 2048,
    ) -> None:
        super().__init__(
            api_key=api_key or os.environ.get("AZURE_OPENAI_API_KEY"),
            model=model or deployment or os.environ.get("AZURE_OPENAI_DEPLOYMENT") or "gpt-4o-mini",
            max_input_tokens=max_input_tokens,
        )
        self._azure_endpoint = endpoint or os.environ.get("AZURE_OPENAI_ENDPOINT")
        self._azure_api_version = api_version or os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
        self._deployment = deployment or os.environ.get("AZURE_OPENAI_DEPLOYMENT")

    def _ensure_client(self) -> AzureOpenAI:
        if AzureOpenAI is None:
            raise ValueError('openai is not installed; install "pydefend[openai]"')
        if self._client is None:
            ep = self._azure_endpoint
            if not ep:
                raise ValueError("Azure OpenAI requires AZURE_OPENAI_ENDPOINT or endpoint=")
            key = self._api_key
            if not key:
                raise ValueError("Azure OpenAI requires AZURE_OPENAI_API_KEY or api_key=")
            self._client = AzureOpenAI(
                api_version=self._azure_api_version,
                azure_endpoint=ep,
                api_key=key,
            )
        return self._client  # type: ignore[return-value]
