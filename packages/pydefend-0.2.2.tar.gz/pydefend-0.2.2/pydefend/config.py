from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .core import Defend, DefendRuntime
from .exceptions import ConfigError
from .modules import (
    PII,
    BanCode,
    BanCompetitors,
    BanCompetitorsOutput,
    BaseModule,
    BiasOutput,
    CanaryToken,
    CodeExecutionOutput,
    Custom,
    CustomOutput,
    ExcessiveAgency,
    FinancialPii,
    FinancialPiiOutput,
    HallucinationOutput,
    HealthPii,
    HealthPiiOutput,
    ImagePII,
    IndirectInjection,
    Injection,
    InvisibleText,
    Jailbreak,
    MaliciousUrl,
    NoRefusalOutput,
    PiiOutput,
    PromptComplexity,
    PromptLeak,
    RelevanceOutput,
    Secrets,
    SecretsOutput,
    SensitiveTopics,
    SentimentOutput,
    ToolMisuse,
    Topic,
    TopicOutput,
    Toxicity,
    ToxicityOutput,
    VisualInjection,
)
from .policy import OnFail
from .providers.resolve import resolve_provider

MODULE_CLASS_BY_NAME: dict[str, type[BaseModule]] = {
    "injection": Injection,
    "jailbreak": Jailbreak,
    "invisible_text": InvisibleText,
    "indirect_injection": IndirectInjection,
    "secrets": Secrets,
    "pii": PII,
    "financial_pii": FinancialPii,
    "health_pii": HealthPii,
    "visual_injection": VisualInjection,
    "image_pii": ImagePII,
    "toxicity": Toxicity,
    "sensitive_topics": SensitiveTopics,
    "topic": Topic,
    "ban_code": BanCode,
    "ban_competitors": BanCompetitors,
    "prompt_complexity": PromptComplexity,
    "custom": Custom,
    "prompt_leak": PromptLeak,
    "secrets_output": SecretsOutput,
    "pii_output": PiiOutput,
    "financial_pii_output": FinancialPiiOutput,
    "health_pii_output": HealthPiiOutput,
    "malicious_url": MaliciousUrl,
    "canary_token": CanaryToken,
    "code_execution_output": CodeExecutionOutput,
    "tool_misuse": ToolMisuse,
    "excessive_agency": ExcessiveAgency,
    "toxicity_output": ToxicityOutput,
    "bias_output": BiasOutput,
    "topic_output": TopicOutput,
    "ban_competitors_output": BanCompetitorsOutput,
    "custom_output": CustomOutput,
    "hallucination_output": HallucinationOutput,
    "relevance_output": RelevanceOutput,
    "no_refusal_output": NoRefusalOutput,
    "sentiment_output": SentimentOutput,
}


def _coerce_on_fail(raw: Any) -> OnFail | None:
    if raw is None:
        return None
    if isinstance(raw, OnFail):
        return raw
    if isinstance(raw, str):
        try:
            return OnFail(raw.strip().lower())
        except ValueError as exc:
            raise ConfigError(f"invalid on_fail: {raw!r}") from exc
    raise ConfigError(f"invalid on_fail type: {type(raw)}")


def _instantiate_module(name: str, cfg: dict[str, Any]) -> BaseModule:
    cls = MODULE_CLASS_BY_NAME.get(name)
    if cls is None:
        raise ConfigError(f"unknown module: {name!r}")
    cfg = dict(cfg)
    return cls(**cfg)


def _parse_module_list(entries: Any) -> list[BaseModule]:
    if entries is None:
        return []
    if not isinstance(entries, list):
        raise ConfigError("modules.input / modules.output must be lists")
    mods: list[BaseModule] = []
    for item in entries:
        if not isinstance(item, dict) or len(item) != 1:
            raise ConfigError("each module entry must be a single-key dict, e.g. injection: {{...}}")
        name, cfg = next(iter(item.items()))
        if cfg is None:
            cfg = {}
        if not isinstance(cfg, dict):
            raise ConfigError(f"config for {name!r} must be a mapping")
        mods.append(_instantiate_module(str(name), cfg))
    return mods


def load_defend_config(path: str | Path) -> Defend:
    p = Path(path)
    if not p.is_file():
        raise ConfigError(f"config file not found: {p}")

    try:
        raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except Exception as exc:
        raise ConfigError(f"invalid YAML: {exc}") from exc
    if not isinstance(raw, dict):
        raise ConfigError("top level of defend.yaml must be a mapping")

    provider = str(raw.get("provider", "auto") or "auto").strip().lower()
    model = raw.get("model")
    model_s = str(model) if model is not None else None
    timeout = raw.get("timeout")
    timeout_f = float(timeout) if isinstance(timeout, (int, float)) else None
    global_on_fail = _coerce_on_fail(raw.get("on_fail"))

    modules = raw.get("modules") or {}
    if not isinstance(modules, dict):
        raise ConfigError("modules must be a mapping")
    inp = _parse_module_list(modules.get("input"))
    out = _parse_module_list(modules.get("output"))

    mep = str(raw.get("module_error_policy", "passthrough") or "passthrough").strip().lower()
    if mep not in ("passthrough", "warn", "raise", "block"):
        raise ConfigError(f"invalid module_error_policy: {mep!r}")

    audit = raw.get("audit") or {}
    if audit and not isinstance(audit, dict):
        raise ConfigError("audit must be a mapping")

    prov = resolve_provider(provider=None if provider == "auto" else provider, model=model_s)

    all_m = DefendRuntime.merge_modules(tuple(inp), tuple(out))
    rt = DefendRuntime(
        provider=prov,
        input_modules=tuple(inp),
        output_modules=tuple(out),
        global_on_fail=global_on_fail,
        timeout=timeout_f,
        max_input_chars=8192,
        module_error_policy=mep,
        all_modules=all_m,
    )
    d = Defend(_runtime=rt)
    if isinstance(audit, dict) and audit.get("enabled"):
        from .observe import StructuredLogger

        if str(audit.get("backend", "stdout")).strip().lower() in ("stdout", "stderr", ""):
            d.observe(StructuredLogger(level=str(audit.get("log_level", "INFO"))))
    return d


def preset_yaml(preset: str) -> str:
    """Return starter YAML for `defend init --preset`."""
    p = preset.strip().lower()
    if p == "minimal":
        return (
            "provider: auto\nmodel: gpt-4o-mini\ntimeout: 30.0\non_fail: block\n"
            "module_error_policy: passthrough\n\nmodules:\n  input:\n    - injection: {strict: true}\n"
            "  output:\n    - prompt_leak: {}\n"
        )
    if p == "standard":
        return (
            "provider: auto\nmodel: gpt-4o-mini\ntimeout: 30.0\non_fail: block\n"
            "module_error_policy: passthrough\n\nmodules:\n  input:\n"
            "    - injection: {strict: true, on_fail: block}\n    - jailbreak: {on_fail: block}\n"
            "    - pii: {on_fail: redact}\n  output:\n    - prompt_leak: {on_fail: block}\n"
            "    - pii_output: {on_fail: redact}\n"
        )
    if p in ("enterprise", "children"):
        return preset_yaml("standard")
    raise ConfigError(f"unknown preset: {preset!r}")
