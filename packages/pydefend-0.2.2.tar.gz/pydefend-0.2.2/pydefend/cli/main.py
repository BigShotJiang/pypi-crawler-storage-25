from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import typer

app = typer.Typer(add_completion=False, help="pydefend CLI")


@app.command("validate")
def validate_cmd(path: str = typer.Argument(..., help="Path to defend.yaml")) -> None:
    from ..config import load_defend_config
    from ..exceptions import ConfigError

    try:
        load_defend_config(path)
    except ConfigError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    typer.echo("ok")


@app.command("init")
def init_cmd(
    preset: str = typer.Option("minimal", "--preset", help="minimal | standard | enterprise | children"),
) -> None:
    from ..config import preset_yaml
    from ..exceptions import ConfigError

    try:
        typer.echo(preset_yaml(preset), nl=False)
    except ConfigError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc


@app.command("test")
def test_cmd(
    config: str = typer.Option(..., "--config", help="defend.yaml path"),
    input_text: str | None = typer.Option(None, "--input", help="Text to scan"),
) -> None:
    from ..config import load_defend_config

    if not input_text:
        typer.echo("--input required", err=True)
        raise typer.Exit(1)
    defend = load_defend_config(config)

    async def _run() -> None:
        r = await defend.scan(input_text)
        typer.echo(json.dumps(r.to_dict(), indent=2))

    asyncio.run(_run())


@app.command("scan")
def scan_cmd(
    config: str = typer.Option(..., "--config"),
    file: Path | None = typer.Option(None, "--file"),
) -> None:
    from ..config import load_defend_config

    defend = load_defend_config(config)
    if file is not None:
        lines = file.read_text(encoding="utf-8").splitlines()
    else:
        lines = [sys.stdin.read()]

    async def _run() -> None:
        for line in lines:
            if not line.strip():
                continue
            r = await defend.scan(line)
            typer.echo(json.dumps({"text": line[:200], "passed": bool(r), "action": r.action.value}))

    asyncio.run(_run())


@app.command("repl")
def repl_cmd(config: str = typer.Option(..., "--config")) -> None:
    typer.echo("repl: type text to scan, empty line to exit")
    from ..config import load_defend_config

    defend = load_defend_config(config)

    async def _loop() -> None:
        while True:
            line = await asyncio.to_thread(input, "> ")
            if not line.strip():
                break
            r = await defend.scan(line)
            typer.echo(json.dumps(r.to_dict(), indent=2))

    asyncio.run(_loop())


@app.command("bench")
def bench_cmd(config: str = typer.Option(..., "--config")) -> None:
    typer.echo("bench: not implemented in this release", err=True)
    raise typer.Exit(2)


def main() -> None:
    app()


if __name__ == "__main__":
    main()
