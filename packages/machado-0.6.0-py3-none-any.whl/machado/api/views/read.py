# Copyright 2018 by Embrapa.  All rights reserved.
#
# This code is part of the machado distribution and governed by its
# license. Please see the LICENSE.txt and README.md files that should
# have been included as part of this package for licensing information.

"""Read views."""

from django.conf import settings
from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django.core.paginator import Paginator

from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema

from haystack.query import SearchQuerySet

from rest_framework import viewsets, status
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response

from machado.api.serializers import read as readSerializers
from machado.loaders.common import retrieve_organism, retrieve_feature_id
from machado.models import Analysis, Analysisfeature, Cvterm, Organism, Pub
from machado.models import Feature, Featureloc, Featureprop, FeatureRelationship
from django.db.models import Q
from machado.models import History

from re import escape, search, IGNORECASE

try:
    CACHE_TIMEOUT = settings.CACHE_TIMEOUT
except AttributeError:
    CACHE_TIMEOUT = 60 * 60


class StandardResultSetPagination(PageNumberPagination):
    """Set the pagination parameters."""

    page_size = 100
    page_size_query_param = "page_size"
    max_page_size = 1000


class JBrowseGlobalViewSet(viewsets.GenericViewSet):
    """API endpoint to view JBrowse global settings."""

    serializer_class = readSerializers.JBrowseGlobalSerializer

    @swagger_auto_schema(
        operation_summary="Retrieve global settings",
        operation_description="Retrieve global settings. https://jbrowse.org/docs/data_formats.html",
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, request):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.JBrowseGlobalSerializer(queryset, many=True)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        return [{"featureDensity": 0.02}]

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(JBrowseGlobalViewSet, self).dispatch(*args, **kwargs)


class JBrowseNamesViewSet(viewsets.GenericViewSet):
    """API endpoint to JBrowse names."""

    serializer_class = readSerializers.JBrowseNamesSerializer

    organism_param = openapi.Parameter(
        "organism",
        openapi.IN_QUERY,
        description="Species name",
        required=True,
        type=openapi.TYPE_STRING,
    )
    equals_param = openapi.Parameter(
        "equals",
        openapi.IN_QUERY,
        description="exact matching string",
        required=False,
        type=openapi.TYPE_STRING,
    )
    startswith_param = openapi.Parameter(
        "startswith",
        openapi.IN_QUERY,
        description="starts with matching string",
        required=False,
        type=openapi.TYPE_STRING,
    )

    @swagger_auto_schema(
        manual_parameters=[organism_param, equals_param, startswith_param],
        operation_summary="Retrieve feature names by accession",
        operation_description="Retrieve feature names by accession. https://jbrowse.org/docs/data_formats.html",
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, request):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.JBrowseNamesSerializer(queryset, many=True)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        queryset = (
            Feature.objects.filter(is_obsolete=0)
            .exclude(name=None)
            .exclude(uniquename=None)
        )

        organism = self.request.query_params.get("organism")

        if organism is not None:
            queryset = queryset.filter(organism=retrieve_organism(organism))

        equals = self.request.query_params.get("equals")
        startswith = self.request.query_params.get("startswith")
        if startswith is not None:
            return queryset.filter(uniquename__startswith=startswith)
        elif equals is not None:
            return queryset.filter(uniquename=equals)
        else:
            return queryset

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(JBrowseNamesViewSet, self).dispatch(*args, **kwargs)


class JBrowseRefSeqsViewSet(viewsets.GenericViewSet):
    """API endpoint to JBrowse refSeqs.json."""

    serializer_class = readSerializers.JBrowseRefseqSerializer

    organism_param = openapi.Parameter(
        "organism",
        openapi.IN_QUERY,
        description="Species name",
        required=True,
        type=openapi.TYPE_STRING,
    )
    sotype_param = openapi.Parameter(
        "soType",
        openapi.IN_QUERY,
        description="Sequence Ontology term",
        required=True,
        type=openapi.TYPE_STRING,
    )

    @swagger_auto_schema(
        manual_parameters=[sotype_param, organism_param],
        operation_summary="Retrieve reference sequences",
        operation_description="Retrieve reference sequences. https://jbrowse.org/docs/data_formats.html",
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, *args, **kwargs):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.JBrowseRefseqSerializer(queryset, many=True)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        organism = self.request.query_params.get("organism")
        sotype = self.request.query_params.get("soType")

        queryset = Feature.objects.filter(is_obsolete=0)
        if organism is not None:
            queryset = queryset.filter(organism=retrieve_organism(organism))
        if sotype is not None:
            queryset = queryset.filter(type__cv__name="sequence", type__name=sotype)

        queryset = queryset.only("seqlen", "uniquename")

        return queryset

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(JBrowseRefSeqsViewSet, self).dispatch(*args, **kwargs)


class JBrowseFeatureViewSet(viewsets.GenericViewSet):
    """API endpoint to view gene."""

    serializer_class = readSerializers.JBrowseFeatureSerializer

    organism_param = openapi.Parameter(
        "organism",
        openapi.IN_QUERY,
        description="Species name",
        required=True,
        type=openapi.TYPE_STRING,
    )
    start_param = openapi.Parameter(
        "start",
        openapi.IN_QUERY,
        description="start",
        required=False,
        type=openapi.TYPE_INTEGER,
    )
    end_param = openapi.Parameter(
        "end",
        openapi.IN_QUERY,
        description="start",
        required=False,
        type=openapi.TYPE_INTEGER,
    )
    sotype_param = openapi.Parameter(
        "soType",
        openapi.IN_QUERY,
        description="Sequence Ontology term",
        required=False,
        type=openapi.TYPE_STRING,
    )

    @swagger_auto_schema(
        manual_parameters=[sotype_param, start_param, end_param, organism_param],
        operation_description="Retrieve features from reference sequence (refseq). https://jbrowse.org/docs/data_formats.html",
        operation_summary="Retrieve features from reference sequence",
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, *args, **kwargs):
        """List."""
        queryset = self.get_queryset()
        context = self.get_serializer_context()
        serializer = readSerializers.JBrowseFeatureSerializer(
            queryset, context=context, many=True
        )
        return Response({"features": serializer.data})

    def get_serializer_context(self):
        """Get the serializer context."""
        refseq = self.kwargs.get("refseq")
        organism = self.request.query_params.get("organism")
        if organism is not None:
            organism = retrieve_organism(organism)
        refseq_feature_obj = Feature.objects.filter(
            uniquename=refseq, organism=organism
        ).first()
        soType = self.request.query_params.get("soType")
        return {"refseq": refseq_feature_obj, "soType": soType}

    def get_queryset(self, *args, **kwargs):
        """Get queryset."""
        try:
            refseq = self.kwargs.get("refseq")
            organism = self.request.query_params.get("organism")
            refseq_feature_obj = Feature.objects.filter(
                uniquename=refseq, organism=retrieve_organism(organism)
            ).first()

        except ObjectDoesNotExist:
            return

        try:
            soType = self.request.query_params.get("soType")
            start = self.request.query_params.get("start", 1)
            end = self.request.query_params.get("end")

            features_locs = Featureloc.objects.filter(srcfeature=refseq_feature_obj)
            if end is not None:
                features_locs = features_locs.filter(fmin__lte=end)
            features_locs = features_locs.filter(fmax__gte=start)
            features_ids = features_locs.values_list("feature_id", flat=True)

            features = Feature.objects.filter(
                feature_id__in=features_ids, is_obsolete=0
            )
            if soType is not None:
                features = features.filter(type__cv__name="sequence", type__name=soType)
            return features

        except ObjectDoesNotExist:
            return None

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(JBrowseFeatureViewSet, self).dispatch(*args, **kwargs)


class autocompleteViewSet(viewsets.GenericViewSet):
    """API endpoint to provide autocomplete hits."""

    serializer_class = readSerializers.autocompleteSerializer

    q_param = openapi.Parameter(
        "q",
        openapi.IN_QUERY,
        description="search string",
        required=True,
        type=openapi.TYPE_STRING,
    )

    operation_summary = "Search the ElasticSearch index for matching strings"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_TXT"):
        operation_description += "<b>Example:</b><br />feature_id={}".format(
            settings.MACHADO_EXAMPLE_TXT
        )

    @swagger_auto_schema(
        manual_parameters=[q_param],
        operation_summary=operation_summary,
        operation_description=operation_description,
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, request):
        """Search the ElasticSearch index for matching strings."""
        queryset = self.get_queryset()
        serializer = readSerializers.autocompleteSerializer(queryset, many=True)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        max_items = 10
        request = self.request
        query = request.query_params.get("q")
        if query is not None:
            query = query.strip()
            queryset = SearchQuerySet().filter(autocomplete=query)[: max_items * 10]
            result = set()
            for item in queryset:
                try:
                    aux = list()
                    for i in query.split(" "):
                        regex = r"\w*" + escape(i) + r"\w*"
                        aux.append(search(regex, item.autocomplete, IGNORECASE).group())
                    result.add(" ".join(aux))
                except AttributeError:
                    pass
            return list(result)[:max_items]
        else:
            return None

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(autocompleteViewSet, self).dispatch(*args, **kwargs)


class OrganismIDViewSet(viewsets.GenericViewSet):
    """Retrieve the organism ID by accession."""

    lookup_field = "organism_id"
    lookup_value_regex = r"^\d+$"
    serializer_class = readSerializers.OrganismIDSerializer

    genus_param = openapi.Parameter(
        "genus",
        openapi.IN_QUERY,
        description="genus name",
        required=False,
        type=openapi.TYPE_STRING,
    )

    species_param = openapi.Parameter(
        "species",
        openapi.IN_QUERY,
        description="species name",
        required=False,
        type=openapi.TYPE_STRING,
    )

    infraspecific_name_param = openapi.Parameter(
        "infraspecific_name",
        openapi.IN_QUERY,
        description="infraspecific name",
        required=False,
        type=openapi.TYPE_STRING,
    )

    abbreviation_param = openapi.Parameter(
        "abbreviation",
        openapi.IN_QUERY,
        description="abbreviation",
        required=False,
        type=openapi.TYPE_STRING,
    )

    common_name_param = openapi.Parameter(
        "common_name",
        openapi.IN_QUERY,
        description="common name",
        required=False,
        type=openapi.TYPE_STRING,
    )

    operation_summary = "Retrieve organism ID"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_ORGANISM_COMMON_NAME"):
        operation_description += "<b>Example:</b><br />common_name={}".format(
            settings.MACHADO_EXAMPLE_ORGANISM_COMMON_NAME
        )

    @swagger_auto_schema(
        manual_parameters=[
            genus_param,
            species_param,
            infraspecific_name_param,
            abbreviation_param,
            common_name_param,
        ],
        operation_summary=operation_summary,
        operation_description=operation_description,
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, request):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.OrganismIDSerializer(queryset, many=False)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        genus = self.request.query_params.get("genus")
        species = self.request.query_params.get("species")
        infraspecific_name = self.request.query_params.get("infraspecific_name")
        abbreviation = self.request.query_params.get("abbreviation")
        common_name = self.request.query_params.get("common_name")

        qs = Organism.objects

        if genus is not None:
            qs = qs.filter(genus=genus)

        if species is not None:
            qs = qs.filter(species=species)

        if infraspecific_name is not None:
            qs = qs.filter(infraspecific_name=infraspecific_name)

        if abbreviation is not None:
            qs = qs.filter(abbreviation=abbreviation)

        if common_name is not None:
            qs = qs.filter(common_name=common_name)

        try:
            organism = qs.get()
            return {"organism_id": organism.organism_id}
        except MultipleObjectsReturned:
            return None
        except ObjectDoesNotExist:
            return None

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(OrganismIDViewSet, self).dispatch(*args, **kwargs)


class OrganismListViewSet(viewsets.ViewSet):
    """Retrieve all the organisms."""

    def list(self, request):
        """List."""
        queryset = Organism.objects.exclude(genus="multispecies")
        serializer = readSerializers.OrganismListSerializer(queryset, many=True)
        return Response(serializer.data)


class FeatureIDViewSet(viewsets.GenericViewSet):
    """Retrieve the feature ID by accession."""

    lookup_field = "feature_id"
    lookup_value_regex = r"^\d+$"
    serializer_class = readSerializers.FeatureIDSerializer

    accession_param = openapi.Parameter(
        "accession",
        openapi.IN_QUERY,
        description="Feature name or accession",
        required=True,
        type=openapi.TYPE_STRING,
    )
    sotype_param = openapi.Parameter(
        "soType",
        openapi.IN_QUERY,
        description="Sequence Ontology term",
        required=True,
        type=openapi.TYPE_STRING,
    )
    organism_id = openapi.Parameter(
        "organism_id",
        openapi.IN_QUERY,
        description="organism id",
        required=True,
        type=openapi.TYPE_INTEGER,
    )

    operation_summary = "Retrieve feature ID by accession"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_AA_ACC") and hasattr(
        settings, "MACHADO_EXAMPLE_ORGANISM_ID"
    ):
        operation_description += "<b>Example:</b><br />accession={}, soType=polypeptide, organism_id={}".format(
            settings.MACHADO_EXAMPLE_AA_ACC, settings.MACHADO_EXAMPLE_ORGANISM_ID
        )

    @swagger_auto_schema(
        manual_parameters=[accession_param, sotype_param, organism_id],
        operation_summary=operation_summary,
        operation_description=operation_description,
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, request):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.FeatureIDSerializer(queryset, many=False)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        accession = self.request.query_params.get("accession")
        soterm = self.request.query_params.get("soType")
        organism_id = self.request.query_params.get("organism_id")
        organism_obj = Organism.objects.get(organism_id=organism_id)
        try:
            feature_id = retrieve_feature_id(accession, soterm, organism_obj)
            return {"feature_id": feature_id}
        except ObjectDoesNotExist:
            return None

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(FeatureIDViewSet, self).dispatch(*args, **kwargs)


class FeatureOrthologViewSet(viewsets.GenericViewSet):
    """API endpoint for feature ortholog."""

    lookup_field = "feature_id"
    lookup_value_regex = r"^\d+$"
    serializer_class = readSerializers.FeatureOrthologSerializer

    operation_summary = "Retrieve ortholog group by feature ID"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_AA"):
        operation_description += "<b>Example:</b><br />feature_id={}".format(
            settings.MACHADO_EXAMPLE_AA
        )

    @swagger_auto_schema(
        operation_summary=operation_summary, operation_description=operation_description
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, *args, **kwargs):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.FeatureOrthologSerializer(queryset, many=True)
        try:
            feature_obj = Feature.objects.get(feature_id=self.kwargs.get("feature_id"))
            return Response(
                {
                    "ortholog_group": feature_obj.get_orthologous_group(),
                    "members": serializer.data,
                }
            )
        except ObjectDoesNotExist:
            return Response({"coexpression_group": None, "members": list()})

    def get_queryset(self):
        """Get queryset."""
        try:
            ortholog_group = Featureprop.objects.get(
                type__name="orthologous group",
                type__cv__name="feature_property",
                feature_id=self.kwargs.get("feature_id"),
            )
            return Feature.objects.filter(
                type__name="polypeptide",
                Featureprop_feature_Feature__value=ortholog_group.value,
            )
        except ObjectDoesNotExist:
            return

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(FeatureOrthologViewSet, self).dispatch(*args, **kwargs)


class FeatureCoexpressionViewSet(viewsets.GenericViewSet):
    """API endpoint for feature coexpression."""

    lookup_field = "feature_id"
    lookup_value_regex = r"^\d+$"
    serializer_class = readSerializers.FeatureOrthologSerializer

    operation_summary = "Retrieve co-expression group by feature ID"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_NA"):
        operation_description += "<b>Example:</b><br />feature_id={}".format(
            settings.MACHADO_EXAMPLE_NA
        )

    @swagger_auto_schema(
        operation_summary=operation_summary, operation_description=operation_description
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, *args, **kwargs):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.FeatureCoexpressionSerializer(queryset, many=True)
        try:
            feature_obj = Feature.objects.get(feature_id=self.kwargs.get("feature_id"))
            return Response(
                {
                    "coexpression_group": feature_obj.get_coexpression_group(),
                    "members": serializer.data,
                }
            )
        except ObjectDoesNotExist:
            return Response({"coexpression_group": None, "members": list()})

    def get_queryset(self):
        """Get queryset."""
        try:
            coexpression_group = Featureprop.objects.get(
                type__name="coexpression group",
                type__cv__name="feature_property",
                feature_id=self.kwargs.get("feature_id"),
            )
            return Feature.objects.filter(
                type__name="mRNA",
                Featureprop_feature_Feature__value=coexpression_group.value,
            )
        except ObjectDoesNotExist:
            return

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(FeatureCoexpressionViewSet, self).dispatch(*args, **kwargs)


class FeatureExpressionViewSet(viewsets.GenericViewSet):
    """API endpoint for feature expression."""

    lookup_field = "feature_id"
    lookup_value_regex = r"^\d+$"
    serializer_class = readSerializers.FeatureExpressionSerializer

    operation_summary = "Retrieve expression by feature ID"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_NA"):
        operation_description += "<b>Example:</b><br />feature_id={}".format(
            settings.MACHADO_EXAMPLE_NA
        )

    @swagger_auto_schema(
        operation_summary=operation_summary, operation_description=operation_description
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, *args, **kwargs):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.FeatureExpressionSerializer(queryset, many=True)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        feature_id = self.kwargs.get("feature_id")
        try:
            feature_obj = Feature.objects.get(feature_id=feature_id)
            return feature_obj.get_expression_samples()
        except ObjectDoesNotExist:
            return

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(FeatureExpressionViewSet, self).dispatch(*args, **kwargs)


class FeatureInfoViewSet(viewsets.GenericViewSet):
    """API endpoint for feature info."""

    lookup_field = "feature_id"
    lookup_value_regex = r"^\d+$"
    serializer_class = readSerializers.FeatureInfoSerializer

    operation_summary = "Retrieve general information by feature ID"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_NA"):
        operation_description += "<b>Example:</b><br />feature_id={}".format(
            settings.MACHADO_EXAMPLE_NA
        )

    @swagger_auto_schema(
        operation_summary=operation_summary, operation_description=operation_description
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, *args, **kwargs):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.FeatureInfoSerializer(queryset, many=False)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        try:
            return Feature.objects.get(feature_id=self.kwargs.get("feature_id"))
        except ObjectDoesNotExist:
            return

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(FeatureInfoViewSet, self).dispatch(*args, **kwargs)


class FeatureLocationViewSet(viewsets.GenericViewSet):
    """Retrieve location by feature ID."""

    lookup_field = "feature_id"
    lookup_value_regex = r"^\d+$"
    serializer_class = readSerializers.FeatureLocationSerializer

    operation_summary = "Retrieve location by feature ID"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_NA"):
        operation_description += "<b>Example:</b><br />feature_id={}".format(
            settings.MACHADO_EXAMPLE_NA
        )

    @swagger_auto_schema(
        operation_summary=operation_summary, operation_description=operation_description
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, *args, **kwargs):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.FeatureLocationSerializer(queryset, many=True)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        feature_id = self.kwargs.get("feature_id")
        try:
            feature_obj = Feature.objects.get(feature_id=feature_id)
            return feature_obj.get_location()
        except ObjectDoesNotExist:
            return

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(FeatureLocationViewSet, self).dispatch(*args, **kwargs)


class FeatureSequenceViewSet(viewsets.GenericViewSet):
    """Retrieve sequence by feature ID."""

    lookup_field = "feature_id"
    lookup_value_regex = r"^\d+$"
    serializer_class = readSerializers.FeatureSequenceSerializer

    operation_summary = "Retrieve sequence by feature ID"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_NA"):
        operation_description += "<b>Example:</b><br />feature_id={}".format(
            settings.MACHADO_EXAMPLE_NA
        )

    @swagger_auto_schema(
        operation_summary=operation_summary, operation_description=operation_description
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, *args, **kwargs):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.FeatureSequenceSerializer(queryset, many=False)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        try:
            return Feature.objects.get(feature_id=self.kwargs.get("feature_id"))
        except ObjectDoesNotExist:
            return

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(FeatureSequenceViewSet, self).dispatch(*args, **kwargs)


class FeaturePublicationViewSet(viewsets.GenericViewSet):
    """Retrieve publication by feature ID."""

    lookup_field = "feature_id"
    lookup_value_regex = r"^\d+$"
    serializer_class = readSerializers.FeaturePublicationSerializer

    operation_summary = "Retrieve publication by feature ID"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_NA"):
        operation_description += "<b>Example:</b><br />feature_id={}".format(
            settings.MACHADO_EXAMPLE_NA
        )

    @swagger_auto_schema(
        operation_summary=operation_summary, operation_description=operation_description
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, *args, **kwargs):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.FeaturePublicationSerializer(queryset, many=True)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        try:
            return Pub.objects.filter(
                FeaturePub_pub_Pub__feature__feature_id=self.kwargs.get("feature_id")
            )
        except ObjectDoesNotExist:
            return

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(FeaturePublicationViewSet, self).dispatch(*args, **kwargs)


class FeatureOntologyViewSet(viewsets.GenericViewSet):
    """Retrieve ontology terms by feature ID."""

    lookup_field = "feature_id"
    lookup_value_regex = r"^\d+$"
    serializer_class = readSerializers.FeatureOntologySerializer

    operation_summary = "Retrieve ontology terms by feature ID"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_AA"):
        operation_description += "<b>Example:</b><br />feature_id={}".format(
            settings.MACHADO_EXAMPLE_AA
        )

    @swagger_auto_schema(
        operation_summary=operation_summary, operation_description=operation_description
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, *args, **kwargs):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.FeatureOntologySerializer(queryset, many=True)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        try:
            return Cvterm.objects.filter(
                FeatureCvterm_cvterm_Cvterm__feature_id=self.kwargs.get("feature_id")
            )
        except ObjectDoesNotExist:
            return

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(FeatureOntologyViewSet, self).dispatch(*args, **kwargs)


class FeatureProteinMatchesViewSet(viewsets.GenericViewSet):
    """Retrieve protein matches by feature ID."""

    lookup_field = "feature_id"
    lookup_value_regex = r"^\d+$"
    serializer_class = readSerializers.FeatureProteinMatchesSerializer

    operation_summary = "Retrieve protein matches by feature ID"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_AA"):
        operation_description += "<b>Example:</b><br />feature_id={}".format(
            settings.MACHADO_EXAMPLE_AA
        )

    @swagger_auto_schema(
        operation_summary=operation_summary, operation_description=operation_description
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, *args, **kwargs):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.FeatureProteinMatchesSerializer(
            queryset, many=True
        )
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        try:
            return FeatureRelationship.objects.filter(
                object_id=self.kwargs.get("feature_id"),
                subject__type__name="protein_match",
                subject__type__cv__name="sequence",
            )
        except ObjectDoesNotExist:
            return

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(FeatureProteinMatchesViewSet, self).dispatch(*args, **kwargs)


class FeatureSimilarityViewSet(viewsets.GenericViewSet):
    """Retrieve similarity matches by feature ID."""

    lookup_field = "feature_id"
    lookup_value_regex = r"^\d+$"
    serializer_class = readSerializers.FeatureSimilaritySerializer

    operation_summary = "Retrieve similarity matches by feature ID"
    operation_description = operation_summary + "<br /><br />"
    if hasattr(settings, "MACHADO_EXAMPLE_AA"):
        operation_description += "<b>Example:</b><br />feature_id={}".format(
            settings.MACHADO_EXAMPLE_AA
        )

    @swagger_auto_schema(
        operation_summary=operation_summary, operation_description=operation_description
    )
    @method_decorator(cache_page(CACHE_TIMEOUT))
    def list(self, *args, **kwargs):
        """List."""
        queryset = self.get_queryset()
        serializer = readSerializers.FeatureSimilaritySerializer(queryset, many=True)
        return Response(serializer.data)

    def get_queryset(self):
        """Get queryset."""
        result = list()
        srcfeature_id = self.kwargs.get("feature_id")
        try:
            match_parts_ids = Featureloc.objects.filter(
                srcfeature_id=srcfeature_id
            ).values_list("feature_id")
        except ObjectDoesNotExist:
            return list()

        for match_part_id in match_parts_ids:
            analysis_feature = Analysisfeature.objects.get(feature_id=match_part_id)
            analysis = Analysis.objects.get(analysis_id=analysis_feature.analysis_id)
            if analysis_feature.normscore is not None:
                score = analysis_feature.normscore
            else:
                score = analysis_feature.rawscore

            # it should have 2 records (query and hit)
            match_query = Featureloc.objects.filter(
                feature_id=match_part_id, srcfeature_id=srcfeature_id
            )[0]
            match_hit = (
                Featureloc.objects.filter(feature_id=match_part_id).exclude(
                    srcfeature_id=srcfeature_id
                )
            )[0]

            result.append(
                {
                    "program": analysis.program,
                    "programversion": analysis.programversion,
                    "db_name": match_hit.srcfeature.dbxref.db.name,
                    "unique": match_hit.srcfeature.uniquename,
                    "name": match_hit.srcfeature.name,
                    "sotype": match_query.srcfeature.type.name,
                    "query_start": match_query.fmin,
                    "query_end": match_query.fmax,
                    "score": score,
                    "evalue": analysis_feature.significance,
                }
            )

        return result

    @method_decorator(cache_page(CACHE_TIMEOUT))
    def dispatch(self, *args, **kwargs):
        """Dispatch."""
        return super(FeatureSimilarityViewSet, self).dispatch(*args, **kwargs)


class HistoryListViewSet(viewsets.ViewSet):
    """Retrive all history of insertions."""

    def list(self, request):
        """List"""
        paginate_by = 10
        order_by = request.GET.get("ordering", "-created_at")
        allowed_ordering_fields = [
            "created_at",
            "-created_at",
            "another_field",
            "-another_field",
        ]
        if order_by not in allowed_ordering_fields:
            order_by = "-created_at"

        search_term = request.GET.get("search", None)
        history_list = History.objects.all()
        if search_term:
            history_list = history_list.filter(
                Q(command__icontains=search_term)
                | Q(description__icontains=search_term)
            )

        history_list = history_list.order_by(order_by)

        paginator = Paginator(history_list, paginate_by)
        page_number = request.GET.get("page", 1)
        page_obj = paginator.get_page(page_number)

        serializer = readSerializers.HistoryListSerializer(page_obj, many=True)
        response_data = {
            "total_pages": paginator.num_pages,
            "current_page": page_obj.number,
            "results": serializer.data,
        }
        return Response(data=response_data, status=status.HTTP_200_OK)
