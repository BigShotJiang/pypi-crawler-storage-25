from enum import StrEnum

from .mixins.filter import RangeFilters
from .mixins.identity import Identifier, IdentifierMixin
from .mixins.parameter import (
    MandatorySimpleDataStatusesMixin,
    Ordinal,
    Search,
    UseCache,
)
from .mixins.sort import SortColumns
from .operation.action.status import StatusUpdateOperationAction
from .pagination import BaseFlexiblePagination, BaseStrictPagination


class ReadSingleParameter[T: Identifier](
    UseCache,
    MandatorySimpleDataStatusesMixin,
    IdentifierMixin[T],
):
    pass


class ReadOrdinalParameter[T: StrEnum](
    UseCache,
    MandatorySimpleDataStatusesMixin,
    Ordinal[T],
):
    pass


class CountParameter(
    UseCache,
    Search,
    MandatorySimpleDataStatusesMixin,
    RangeFilters,
):
    pass


class ReadUnpaginatedMultipleParameter(
    BaseFlexiblePagination,
    SortColumns,
    CountParameter,
):
    pass


class ReadPaginatedMultipleParameter(
    BaseStrictPagination,
    SortColumns,
    CountParameter,
):
    pass


class StatusUpdateParameter[T: Identifier](
    StatusUpdateOperationAction,
    IdentifierMixin[T],
):
    pass


class DeleteSingleParameter[T: Identifier](
    IdentifierMixin[T],
):
    pass
