from typing import Annotated

from pydantic import BaseModel, Field

from .mixins.general import Descriptor, Other, Success


class MetadataMixin[T: BaseModel | None](BaseModel):
    metadata: Annotated[T, Field(..., description="Metadata")]


class FieldExpansionMetadata(Other, Descriptor[str], Success[bool]):
    pass


class FieldExpansionMetadataMixin(BaseModel):
    field_expansion: Annotated[
        str | dict[str, FieldExpansionMetadata] | None,
        Field(None, description="Field expansion metadata"),
    ] = None
