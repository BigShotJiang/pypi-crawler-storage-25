from enum import StrEnum

from nexo.types.string import ListOfStrs


class SuccessCode(StrEnum):
    ANY_DATA = "MAL-SCS-ADT"
    NO_DATA = "MAL-SCS-NDT"
    SINGLE_DATA = "MAL-SCS-SGD"
    SINGLE_DATA_PAIR = "MAL-SCS-SDP"
    MULTIPLE_DATA = "MAL-SCS-MTD"
    MULTIPLE_DATA_PAIR = "MAL-SCS-MDP"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]
