from typing import Annotated

from pydantic import Field

from ..mixins.general import Descriptor
from .enums import SuccessCode


class SuccessDescriptor(Descriptor[SuccessCode]):
    code: Annotated[
        SuccessCode, Field(SuccessCode.ANY_DATA, description="Success's code")
    ] = SuccessCode.ANY_DATA
    message: Annotated[
        str, Field("Any data response", description="Success's message")
    ] = "Any data response"
    description: Annotated[
        str, Field("Response with Any Data", description="Success's description")
    ] = "Response with Any Data"


class AnyDataSuccessDescriptor(SuccessDescriptor):
    code: SuccessCode = SuccessCode.ANY_DATA
    message: str = "Any data response"
    description: str = "Response with Any Data"


class NoDataSuccessDescriptor(SuccessDescriptor):
    code: SuccessCode = SuccessCode.NO_DATA
    message: str = "No data response"
    description: str = "Response with No Data"


class SingleDataSuccessDescriptor(SuccessDescriptor):
    code: SuccessCode = SuccessCode.SINGLE_DATA
    message: str = "Single data response"
    description: str = "Response with Single Data"


class SingleDataPairSuccessDescriptor(SuccessDescriptor):
    code: SuccessCode = SuccessCode.SINGLE_DATA_PAIR
    message: str = "Single data pair response"
    description: str = "Response with Single Data Pair"


class MultipleDataSuccessDescriptor(SuccessDescriptor):
    code: SuccessCode = SuccessCode.MULTIPLE_DATA
    message: str = "Multiple data response"
    description: str = "Response with Multiple Data"


class MultipleDataPairSuccessDescriptor(SuccessDescriptor):
    code: SuccessCode = SuccessCode.MULTIPLE_DATA_PAIR
    message: str = "Multiple data pair response"
    description: str = "Response with Multiple Data Pair"
