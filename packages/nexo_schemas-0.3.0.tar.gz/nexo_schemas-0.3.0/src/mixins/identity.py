from datetime import date
from enum import StrEnum
from typing import Annotated, Self
from uuid import UUID as PythonUUID

from nexo.enums.status import DataStatus, SimpleDataStatusMixin
from nexo.types.datetime import OptDate, OptListOfDates
from nexo.types.enum import OptStrEnum
from nexo.types.integer import OptInt, OptListOfInts
from nexo.types.misc import (
    OptIntOrUUID,
    OptListOfIntsOrUUIDs,
)
from nexo.types.string import OptListOfStrs, OptStr
from nexo.types.uuid import OptListOfUUIDs, OptUUID
from pydantic import BaseModel, Field, computed_field


class IdentifierType[T: StrEnum](BaseModel):
    type: Annotated[T, Field(..., description="Identifier's type")]


class IdentifierValue[T](BaseModel):
    value: Annotated[T, Field(..., description="Identifier's value")]


class Identifier[T: StrEnum, V](IdentifierValue[V], IdentifierType[T]):
    pass


class IdentifierMixin[T: Identifier](BaseModel):
    identifier: Annotated[T, Field(..., description="Identifier")]


# Id
class Id[T: OptIntOrUUID](BaseModel):
    id: Annotated[T, Field(..., description="Id")]


class IntId[T: OptInt](BaseModel):
    id: Annotated[T, Field(..., description="Id (Integer)", ge=1)]


class UUIDId[T: OptUUID](BaseModel):
    id: Annotated[T, Field(..., description="Id (UUID)")]


# Ids
class Ids[T: OptListOfIntsOrUUIDs](BaseModel):
    ids: Annotated[T, Field(..., description="Ids")]


class IntIds[T: OptListOfInts](BaseModel):
    ids: Annotated[T, Field(..., description="Ids (Integers)")]


class UUIDIds[T: OptListOfUUIDs](BaseModel):
    ids: Annotated[T, Field(..., description="Ids (UUIDs)")]


# UUID
class UUID[T: OptUUID](BaseModel):
    uuid: Annotated[T, Field(..., description="UUID")]


class UUIDs[T: OptListOfUUIDs](BaseModel):
    uuids: Annotated[T, Field(..., description="UUIDs")]


# Identifier
class SimpleDataIdentifier(UUIDId[PythonUUID]):
    pass


class DataIdentifier(UUID[PythonUUID], IntId[int]):
    pass


OptDataIdentifier = DataIdentifier | None


class EntityType[T: OptStrEnum](BaseModel):
    type: Annotated[T, Field(..., description="Entity's type")]


class EntityIdentifier[T: OptStrEnum](EntityType[T], DataIdentifier):
    pass


class RecordIdentifier(
    SimpleDataStatusMixin[DataStatus],
    DataIdentifier,
):
    pass


class TypedRecord[T: OptStrEnum](EntityType[T], RecordIdentifier):
    pass


class IdCard[T: OptStr](BaseModel):
    id_card: Annotated[T, Field(..., description="ID Card")]


class IdCards[T: OptListOfStrs](BaseModel):
    id_cards: Annotated[T, Field(..., description="ID Cards")]


class Passport[T: OptStr](BaseModel):
    passport: Annotated[T, Field(..., description="Passport")]


class Passports[T: OptListOfStrs](BaseModel):
    passports: Annotated[T, Field(..., description="Passports")]


class Key[T: OptStr](BaseModel):
    key: Annotated[T, Field(..., description="Key")]


class Keys[T: OptListOfStrs](BaseModel):
    keys: Annotated[T, Field(..., description="Keys")]


class FullName[T: OptStr](BaseModel):
    full_name: Annotated[T, Field(..., description="Full Name")]


class FullNames[T: OptListOfStrs](BaseModel):
    full_names: Annotated[T, Field(..., description="Full Names")]


class Name[T: OptStr](BaseModel):
    name: Annotated[T, Field(..., description="Name")]


class Names[T: OptListOfStrs](BaseModel):
    names: Annotated[T, Field(..., description="Names")]


class Age(BaseModel):
    raw: Annotated[float, Field(0, description="Age", ge=0.0)] = 0
    year: Annotated[int, Field(0, description="Year", ge=0)] = 0
    month: Annotated[int, Field(0, description="Month", ge=0)] = 0
    day: Annotated[int, Field(0, description="Day", ge=0)] = 0

    @classmethod
    def from_date_of_birth(cls, date_of_birth: OptDate) -> Self:
        if date_of_birth is None:
            return cls()

        today = date.today()

        # Compute Y/M/D difference
        y = today.year - date_of_birth.year
        m = today.month - date_of_birth.month
        d = today.day - date_of_birth.day

        # Normalize negative days/months
        if d < 0:
            m -= 1
            # Approx: last month's number of days
            # If precision needed you can use calendar.monthrange
            prev_month = (today.month - 1) or 12
            prev_year = today.year if today.month > 1 else today.year - 1
            from calendar import monthrange

            d += monthrange(prev_year, prev_month)[1]

        if m < 0:
            y -= 1
            m += 12

        raw = y + m / 12 + d / 365.25

        return cls(raw=raw, year=y, month=m, day=d)


OptAge = Age | None


class AgeMixin(BaseModel):
    age: Annotated[Age, Field(default_factory=Age, description="Age")]


class BirthDate[T: OptDate](BaseModel):
    birth_date: Annotated[T, Field(..., description="Birth Date")]

    @computed_field
    @property
    def age(self) -> Age:
        return Age.from_date_of_birth(self.birth_date)


class BirthDates[T: OptListOfDates](BaseModel):
    birth_dates: Annotated[T, Field(..., description="Birth Dates")]


class DateOfBirth[T: OptDate](BaseModel):
    date_of_birth: Annotated[T, Field(..., description="Date of Birth")]

    @computed_field
    @property
    def age(self) -> Age:
        return Age.from_date_of_birth(self.date_of_birth)


class DateOfBirths[T: OptListOfDates](BaseModel):
    date_of_births: Annotated[T, Field(..., description="Date of Births")]


class BirthPlace[T: OptStr](BaseModel):
    birth_place: Annotated[T, Field(..., description="Birth Place")]


class BirthPlaces[T: OptListOfStrs](BaseModel):
    birth_places: Annotated[T, Field(..., description="Birth Places")]


class PlaceOfBirth[T: OptStr](BaseModel):
    place_of_birth: Annotated[T, Field(..., description="Place of Birth")]


class PlaceOfBirths[T: OptListOfStrs](BaseModel):
    place_of_births: Annotated[T, Field(..., description="Place of Births")]


# ----- ----- ----- Client ID ----- ----- ----- #


class ClientId[T: OptIntOrUUID](BaseModel):
    client_id: Annotated[T, Field(..., description="Client's ID")]


class IntClientId[T: OptInt](BaseModel):
    client_id: Annotated[T, Field(..., description="Client's ID", ge=1)]


class UUIDClientId[T: OptUUID](BaseModel):
    client_id: Annotated[T, Field(..., description="Client's ID")]


class ClientIds[T: OptListOfIntsOrUUIDs](BaseModel):
    client_ids: Annotated[T, Field(..., description="Client's IDs")]


class IntClientIds[T: OptListOfInts](BaseModel):
    client_ids: Annotated[T, Field(..., description="Client's IDs")]


class UUIDClientIds[T: OptListOfUUIDs](BaseModel):
    client_ids: Annotated[T, Field(..., description="Client's IDs")]


# ----- ----- ----- Organization ID ----- ----- ----- #


class OrganizationId[T: OptIntOrUUID](BaseModel):
    organization_id: Annotated[T, Field(..., description="Organization's ID")]


class IntOrganizationId[T: OptInt](BaseModel):
    organization_id: Annotated[T, Field(..., description="Organization's ID", ge=1)]


class UUIDOrganizationId[T: OptUUID](BaseModel):
    organization_id: Annotated[T, Field(..., description="Organization's ID")]


class OrganizationIds[T: OptListOfIntsOrUUIDs](BaseModel):
    organization_ids: Annotated[T, Field(..., description="Organization's IDs")]


class IntOrganizationIds[T: OptListOfInts](BaseModel):
    organization_ids: Annotated[T, Field(..., description="Organization's IDs")]


class UUIDOrganizationIds[T: OptListOfUUIDs](BaseModel):
    organization_ids: Annotated[T, Field(..., description="Organization's IDs")]


# ----- ----- ----- Parent ID ----- ----- ----- #


class ParentId[T: OptIntOrUUID](BaseModel):
    parent_id: Annotated[T, Field(..., description="Parent's ID")]


class IntParentId[T: OptInt](BaseModel):
    parent_id: Annotated[T, Field(..., description="Parent's ID", ge=1)]


class UUIDParentId[T: OptUUID](BaseModel):
    parent_id: Annotated[T, Field(..., description="Parent's ID")]


class ParentIds[T: OptListOfIntsOrUUIDs](BaseModel):
    parent_ids: Annotated[T, Field(..., description="Parent's IDs")]


class IntParentIds[T: OptListOfInts](BaseModel):
    parent_ids: Annotated[T, Field(..., description="Parent's IDs")]


class UUIDParentIds[T: OptListOfUUIDs](BaseModel):
    parent_ids: Annotated[T, Field(..., description="Parent's IDs")]


# ----- ----- ----- Patient ID ----- ----- ----- #


class PatientId[T: OptIntOrUUID](BaseModel):
    patient_id: Annotated[T, Field(..., description="Patient's ID")]


class IntPatientId[T: OptInt](BaseModel):
    patient_id: Annotated[T, Field(..., description="Patient's ID", ge=1)]


class UUIDPatientId[T: OptUUID](BaseModel):
    patient_id: Annotated[T, Field(..., description="Patient's ID")]


class PatientIds[T: OptListOfIntsOrUUIDs](BaseModel):
    patient_ids: Annotated[T, Field(..., description="Patient's IDs")]


class IntPatientIds[T: OptListOfInts](BaseModel):
    patient_ids: Annotated[T, Field(..., description="Patient's IDs")]


class UUIDPatientIds[T: OptListOfUUIDs](BaseModel):
    patient_ids: Annotated[T, Field(..., description="Patient's IDs")]


# ----- ----- ----- Principal ID ----- ----- ----- #


class PrincipalId[T: OptIntOrUUID](BaseModel):
    principal_id: Annotated[T, Field(..., description="Principal's ID")]


class IntPrincipalId[T: OptInt](BaseModel):
    principal_id: Annotated[T, Field(..., description="Principal's ID", ge=1)]


class UUIDPrincipalId[T: OptUUID](BaseModel):
    principal_id: Annotated[T, Field(..., description="Principal's ID")]


class PrincipalIds[T: OptListOfIntsOrUUIDs](BaseModel):
    principal_ids: Annotated[T, Field(..., description="Principal's IDs")]


class IntPrincipalIds[T: OptListOfInts](BaseModel):
    principal_ids: Annotated[T, Field(..., description="Principal's IDs")]


class UUIDPrincipalIds[T: OptListOfUUIDs](BaseModel):
    principal_ids: Annotated[T, Field(..., description="Principal's IDs")]


# ----- ----- ----- Source ID ----- ----- ----- #


class SourceId[T: OptIntOrUUID](BaseModel):
    source_id: Annotated[T, Field(..., description="Source's ID")]


class IntSourceId[T: OptInt](BaseModel):
    source_id: Annotated[T, Field(..., description="Source's ID", ge=1)]


class UUIDSourceId[T: OptUUID](BaseModel):
    source_id: Annotated[T, Field(..., description="Source's ID")]


class SourceIds[T: OptListOfIntsOrUUIDs](BaseModel):
    source_ids: Annotated[T, Field(..., description="Source's IDs")]


class IntSourceIds[T: OptListOfInts](BaseModel):
    source_ids: Annotated[T, Field(..., description="Source's IDs")]


class UUIDSourceIds[T: OptListOfUUIDs](BaseModel):
    source_ids: Annotated[T, Field(..., description="Source's IDs")]


# ----- ----- ----- Target ID ----- ----- ----- #


class TargetId[T: OptIntOrUUID](BaseModel):
    target_id: Annotated[T, Field(..., description="Target's ID")]


class IntTargetId[T: OptInt](BaseModel):
    target_id: Annotated[T, Field(..., description="Target's ID", ge=1)]


class UUIDTargetId[T: OptUUID](BaseModel):
    target_id: Annotated[T, Field(..., description="Target's ID")]


class TargetIds[T: OptListOfIntsOrUUIDs](BaseModel):
    target_ids: Annotated[T, Field(..., description="Target's IDs")]


class IntTargetIds[T: OptListOfInts](BaseModel):
    target_ids: Annotated[T, Field(..., description="Target's IDs")]


class UUIDTargetIds[T: OptListOfUUIDs](BaseModel):
    target_ids: Annotated[T, Field(..., description="Target's IDs")]


# ----- ----- ----- User ID ----- ----- ----- #


class UserId[T: OptIntOrUUID](BaseModel):
    user_id: Annotated[T, Field(..., description="User's ID")]


class IntUserId[T: OptInt](BaseModel):
    user_id: Annotated[T, Field(..., description="User's ID", ge=1)]


class UUIDUserId[T: OptUUID](BaseModel):
    user_id: Annotated[T, Field(..., description="User's ID")]


class UserIds[T: OptListOfIntsOrUUIDs](BaseModel):
    user_ids: Annotated[T, Field(..., description="User's IDs")]


class IntUserIds[T: OptListOfInts](BaseModel):
    user_ids: Annotated[T, Field(..., description="User's IDs")]


class UUIDUserIds[T: OptListOfUUIDs](BaseModel):
    user_ids: Annotated[T, Field(..., description="User's IDs")]
