from typing import Annotated, Any

from nexo.types.boolean import OptBool
from nexo.types.enum import OptStrEnum
from nexo.types.misc import (
    OptFloatOrInt,
    OptIntOrStrEnum,
    OptListOfStrsOrStrEnums,
    OptStrOrStrEnum,
)
from nexo.types.string import OptStr
from pydantic import BaseModel, Field


class StatusCode(BaseModel):
    status_code: Annotated[int, Field(..., description="Status code", ge=100, le=600)]


class Success[T: OptBool](BaseModel):
    success: Annotated[T, Field(..., description="Success")]


class Code[T: OptStrOrStrEnum](BaseModel):
    code: Annotated[T, Field(..., description="Code")]


class Codes[T: OptListOfStrsOrStrEnums](BaseModel):
    codes: Annotated[T, Field(..., description="Codes")]


class Message(BaseModel):
    message: str = Field(..., description="Message")


class Description(BaseModel):
    description: str = Field(..., description="Description")


class Descriptor[T: OptStrOrStrEnum](Description, Message, Code[T]):
    pass


class Order[T: OptIntOrStrEnum](BaseModel):
    order: Annotated[T, Field(..., description="Order")]


class Level[T: OptStrEnum](BaseModel):
    level: Annotated[T, Field(..., description="Level")]


class Note[T: OptStr](BaseModel):
    note: Annotated[T, Field(..., description="Note")]


class IsDefault[T: OptBool](BaseModel):
    is_default: Annotated[T, Field(..., description="Whether is default")]


class Other(BaseModel):
    other: Annotated[Any, Field(None, description="Other")] = None


class Age[T: OptFloatOrInt](BaseModel):
    age: Annotated[T, Field(..., ge=0, description="Age")]
