from enum import StrEnum
from typing import Annotated

from nexo.enums.status import (
    FULL_DATA_STATUSES,
    ListOfDataStatuses,
    OptListOfDataStatuses,
    SimpleDataStatusesMixin,
)
from nexo.types.enum import OptListOfStrEnums
from nexo.types.string import OptStr
from pydantic import BaseModel, Field


class Ordinal[T: StrEnum](BaseModel):
    ordinal: Annotated[T, Field(..., description="Ordinal")]


class OptionalSimpleDataStatusesMixin(SimpleDataStatusesMixin[OptListOfDataStatuses]):
    statuses: Annotated[
        OptListOfDataStatuses,
        Field(None, description="Data statuses", min_length=1),
    ] = None


class MandatorySimpleDataStatusesMixin(SimpleDataStatusesMixin[ListOfDataStatuses]):
    statuses: Annotated[
        ListOfDataStatuses,
        Field(FULL_DATA_STATUSES, description="Data statuses", min_length=1),
    ] = FULL_DATA_STATUSES


class Search(BaseModel):
    search: Annotated[OptStr, Field(None, description="Search string")] = None


class UseCache(BaseModel):
    use_cache: Annotated[bool, Field(True, description="Whether to use cache")] = True


class IncludeURL(BaseModel):
    include_url: Annotated[bool, Field(False, description="Whether to include URL")] = (
        False
    )


class Include[T: OptListOfStrEnums](BaseModel):
    include: Annotated[T, Field(..., description="Included field(s)")]


class Exclude[T: OptListOfStrEnums](BaseModel):
    exclude: Annotated[T, Field(..., description="Excluded field(s)")]


class Expand[T: OptListOfStrEnums](BaseModel):
    expand: Annotated[T, Field(..., description="Expanded field(s)")]
