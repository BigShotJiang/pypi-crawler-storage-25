from enum import StrEnum
from typing import Annotated

from nexo.types.enum import SeqOfStrEnums
from pydantic import BaseModel, Field


class SimpleServiceKeyMixin[T: StrEnum](BaseModel):
    key: Annotated[T, Field(..., description="Service Key")]


class FullServiceKeyMixin[T: StrEnum](BaseModel):
    service_key: Annotated[T, Field(..., description="Service Key")]


class SimpleServiceKeysMixin[T: SeqOfStrEnums](BaseModel):
    keys: Annotated[T, Field(..., description="Service Keys")]


class FullServiceKeysMixin[T: SeqOfStrEnums](BaseModel):
    service_keys: Annotated[T, Field(..., description="Service Keys")]


class SimpleServiceNameMixin[T: StrEnum](BaseModel):
    name: Annotated[T, Field(..., description="Service Name")]


class FullServiceNameMixin[T: StrEnum](BaseModel):
    service_name: Annotated[T, Field(..., description="Service Name")]


class SimpleServiceNamesMixin[T: SeqOfStrEnums](BaseModel):
    names: Annotated[T, Field(..., description="Service Names")]


class FullServiceNamesMixin[T: SeqOfStrEnums](BaseModel):
    service_names: Annotated[T, Field(..., description="Service Names")]
