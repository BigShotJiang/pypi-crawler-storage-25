from typing import Annotated

from nexo.types.boolean import OptBool
from pydantic import BaseModel, Field


class IsRoot[T: OptBool](BaseModel):
    is_root: Annotated[T, Field(..., description="Whether is root")]


class IsParent[T: OptBool](BaseModel):
    is_parent: Annotated[T, Field(..., description="Whether is parent")]


class IsChild[T: OptBool](BaseModel):
    is_child: Annotated[T, Field(..., description="Whether is child")]


class IsLeaf[T: OptBool](BaseModel):
    is_leaf: Annotated[T, Field(..., description="Whether is leaf")]
