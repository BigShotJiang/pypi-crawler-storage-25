from typing import Annotated, Any, Literal

from pydantic import BaseModel, Field


class DataPair[O: Any, N: Any](BaseModel):
    old: Annotated[O, Field(..., description="Old data")]
    new: Annotated[N, Field(..., description="New data")]


class DataMixin[T: Any](BaseModel):
    data: Annotated[T, Field(..., description="Data")]


class HealthData(BaseModel):
    status: Annotated[Literal["ok"], Field("ok", description="Health data")] = "ok"


class PingData(BaseModel):
    ping: Annotated[Literal["pong"], Field("pong", description="Ping data")] = "pong"


class CheckData(BaseModel):
    check: Annotated[bool, Field(..., description="Check data")]


class CountData(BaseModel):
    count: Annotated[int, Field(0, description="Count data", ge=0)] = 0
