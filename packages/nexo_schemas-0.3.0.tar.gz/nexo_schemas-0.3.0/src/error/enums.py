from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class ErrorType(StrEnum):
    BAD_REQUEST = "client.bad_request"
    UNAUTHORIZED = "client.unauthorized"
    FORBIDDEN = "client.forbidden"
    NOT_FOUND = "client.not_found"
    CONFLICT = "client.conflict"
    METHOD_NOT_ALLOWED = "client.method_not_allowed"
    UNPROCESSABLE_ENTITY = "client.unprocessable_entity"
    TOO_MANY_REQUESTS = "client.too_many_requests"
    INTERNAL_SERVER_ERROR = "server.internal_server_error"
    NOT_IMPLEMENTED = "server.not_implemented"
    BAD_GATEWAY = "server.bad_gateway"
    SERVICE_UNAVAILABLE = "server.service_unavailable"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptErrorType = ErrorType | None


class SimpleErrorTypeMixin[T: OptErrorType](BaseModel):
    type: Annotated[T, Field(..., description="Error's Type")]


class FullErrorTypeMixin[T: OptErrorType](BaseModel):
    error_type: Annotated[T, Field(..., description="Error's Type")]


ListOfErrorTypes = list[ErrorType]
OptListOfErrorTypes = ListOfErrorTypes | None
SeqOfErrorTypes = Sequence[ErrorType]
OptSeqOfErrorTypes = SeqOfErrorTypes | None


class SimpleErrorTypesMixin[T: OptSeqOfErrorTypes](BaseModel):
    types: Annotated[T, Field(..., description="Error's Types", min_length=1)]


class FullErrorTypesMixin[T: OptSeqOfErrorTypes](BaseModel):
    error_types: Annotated[T, Field(..., description="Error's Types", min_length=1)]


class ErrorCode(StrEnum):
    BAD_REQUEST = "MAL-ERR-CLI-BDR"
    UNAUTHORIZED = "MAL-ERR-CLI-ATH"
    FORBIDDEN = "MAL-ERR-CLI-FBD"
    NOT_FOUND = "MAL-ERR-CLI-NTF"
    METHOD_NOT_ALLOWED = "MAL-ERR-CLI-MNA"
    CONFLICT = "MAL-ERR-CLI-CFL"
    UNPROCESSABLE_ENTITY = "MAL-ERR-CLI-UPE"
    TOO_MANY_REQUESTS = "MAL-ERR-CLI-TMR"
    INTERNAL_SERVER_ERROR = "MAL-ERR-SRV-ISE"
    NOT_IMPLEMENTED = "MAL-ERR-SRV-NIM"
    BAD_GATEWAY = "MAL-ERR-SRV-BDG"
    SERVICE_UNAVAILABLE = "MAL-ERR-SRV-SUN"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]
