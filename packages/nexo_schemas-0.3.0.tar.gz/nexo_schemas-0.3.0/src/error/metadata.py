from typing import Annotated, Any

from nexo.types.string import OptListOfStrs
from pydantic import BaseModel, Field


class ErrorMetadata(BaseModel):
    details: Annotated[Any, Field(None, description="Details")] = None
    traceback: Annotated[OptListOfStrs, Field(None, description="Traceback")] = None


class ErrorMetadataMixin(BaseModel):
    metadata: Annotated[
        ErrorMetadata, Field(ErrorMetadata(), description="Error's Metadata")
    ] = ErrorMetadata()
