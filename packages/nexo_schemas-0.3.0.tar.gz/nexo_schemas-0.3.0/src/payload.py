from typing import Annotated, Any

from pydantic import BaseModel, Field

from .data import DataMixin, DataPair
from .metadata import MetadataMixin
from .mixins.general import Other
from .pagination import AnyPagination, OptAnyPagination, PaginationMixin


class Payload[D: Any, P: OptAnyPagination, M: BaseModel | None](
    Other,
    MetadataMixin[M],
    PaginationMixin[P],
    DataMixin[D],
    BaseModel,
):
    pass


class PayloadMixin[T: Payload](BaseModel):
    payload: Annotated[T, Field(..., description="Payload")]


class NoDataPayload[M: BaseModel | None](Payload[None, None, M]):
    data: None = None
    pagination: None = None


class SingleDataPayload[D: Any, M: BaseModel | None](Payload[D, None, M]):
    pagination: None = None


class SingleDataPairPayload[D: Any, M: BaseModel | None](
    Payload[DataPair[D, D], None, M]
):
    pagination: None = None


class MultipleDataPayload[D: Any, P: AnyPagination, M: BaseModel | None](
    Payload[list[D], P, M]
):
    pass


class MultipleDataPairPayload[D: Any, P: AnyPagination, M: BaseModel | None](
    Payload[DataPair[list[D], list[D]], P, M]
):
    pass
