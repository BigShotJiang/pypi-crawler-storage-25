from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class IdSource(StrEnum):
    HEADER = "header"
    STATE = "state"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


class OperationType(StrEnum):
    RESOURCE = "resource"
    REQUEST = "request"
    SYSTEM = "system"
    WEBSOCKET = "websocket"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptOperationType = OperationType | None


class OperationTypeMixin[T: OptOperationType](BaseModel):
    type: Annotated[T, Field(..., description="Operation's Type")]


ListOfOperationTypes = list[OperationType]
OptListOfOperationTypes = ListOfOperationTypes | None
SeqOfOperationTypes = Sequence[OperationType]
OptSeqOfOperationTypes = SeqOfOperationTypes | None


class OperationTypesMixin[T: OptSeqOfOperationTypes](BaseModel):
    types: Annotated[T, Field(..., description="Operation's Types", min_length=1)]


class SystemOperationType(StrEnum):
    BACKGROUND_JOB = "background_job"
    CONFIGURATION_UPDATE = "configuration_update"
    CRON_JOB = "cron_job"
    DATABASE_CONNECTION = "database_connection"
    DISPOSAL = "disposal"
    HEALTH_CHECK = "health_check"
    HEARTBEAT = "heartbeat"
    METRIC_REPORT = "metric_report"
    INITIALIZATION = "initialization"
    STARTUP = "startup"
    SHUTDOWN = "shutdown"
    SYSTEM_ALERT = "system_alert"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptSystemOperationType = SystemOperationType | None


class WebSocketOperationType(StrEnum):
    CONNECT = "connect"
    DISCONNECT = "disconnect"
    ERROR = "error"
    RECEIVE = "receive"
    SEND = "send"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptWebSocketOperationType = WebSocketOperationType | None


class ResourceOperationType(StrEnum):
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptResourceOperationType = ResourceOperationType | None


class ResourceOperationReadType(StrEnum):
    DATA = "data"
    SUMMARY = "summary"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptResourceOperationReadType = ResourceOperationReadType | None


class ResourceOperationUpdateType(StrEnum):
    DATA = "data"
    STATUS = "status"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptResourceOperationUpdateType = ResourceOperationUpdateType | None


class ResourceOperationDataUpdateType(StrEnum):
    FULL = "full"
    PARTIAL = "partial"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptResourceOperationDataUpdateType = ResourceOperationDataUpdateType | None


class ResourceOperationStatusUpdateType(StrEnum):
    ACTIVATE = "activate"
    DEACTIVATE = "deactivate"
    RESTORE = "restore"
    DELETE = "delete"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptResourceOperationStatusUpdateType = ResourceOperationStatusUpdateType | None


class Origin(StrEnum):
    SERVICE = "service"
    CLIENT = "client"
    UTILITY = "utility"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptOrigin = Origin | None


class OriginMixin[T: OptOrigin](BaseModel):
    origin: Annotated[T, Field(..., description="Operation's Origin")]


ListOfOrigins = list[Origin]
OptListOfOrigins = ListOfOrigins | None
SeqOfOrigins = Sequence[Origin]
OptSeqOfOrigins = SeqOfOrigins | None


class OriginsMixin[T: OptSeqOfOrigins](BaseModel):
    origins: Annotated[T, Field(..., description="Operation's Origins", min_length=1)]


class Layer(StrEnum):
    INFRASTRUCTURE = "infrastructure"
    CONFIGURATION = "configuration"
    UTILITY = "utility"
    MIDDLEWARE = "middleware"
    CONTROLLER = "controller"
    SERVICE = "service"
    REPOSITORY = "repository"
    INTERNAL = "internal"
    OTHER = "other"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptLayer = Layer | None


class LayerMixin[T: OptLayer](BaseModel):
    layer: Annotated[T, Field(..., description="Operation's Layer")]


ListOfLayers = list[Layer]
OptListOfLayers = ListOfLayers | None
SeqOfLayers = Sequence[Layer]
OptSeqOfLayers = SeqOfLayers | None


class LayersMixin[T: OptSeqOfLayers](BaseModel):
    layers: Annotated[T, Field(..., description="Operation's Layers", min_length=1)]


class Target(StrEnum):
    MONITORING = "monitoring"
    CACHE = "cache"
    CONTROLLER = "controller"
    DATABASE = "database"
    INTERNAL = "internal"
    MICROSERVICE = "microservice"
    SERVICE = "service"
    REPOSITORY = "repository"
    THIRD_PARTY = "third_party"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptTarget = Target | None


class TargetMixin[T: OptTarget](BaseModel):
    target: Annotated[T, Field(..., description="Operation's Target")]


ListOfTargets = list[Target]
OptListOfTargets = ListOfTargets | None
SeqOfTargets = Sequence[Target]
OptSeqOfTargets = SeqOfTargets | None


class TargetsMixin[T: OptSeqOfTargets](BaseModel):
    targets: Annotated[T, Field(..., description="Operation's Targets", min_length=1)]
