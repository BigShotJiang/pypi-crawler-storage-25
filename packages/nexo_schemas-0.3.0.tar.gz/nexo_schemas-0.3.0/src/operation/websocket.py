from typing import Literal

from ..connection import OptConnectionContext
from ..error import AnyError, OptAnyError
from ..response import AnyErrorResponse, OptAnyResponse, OptAnySuccessResponse
from .action.websocket import WebSocketOperationAction
from .base import BaseOperation
from .enums import OperationType


class WebSocketOperation[S: bool, E: OptAnyError, R: OptAnyResponse](
    BaseOperation[WebSocketOperationAction, None, S, E, OptConnectionContext, R, None]
):
    type: OperationType = OperationType.WEBSOCKET
    resource: None = None
    response_context: None = None


class FailedWebSocketOperation[E: AnyError, R: AnyErrorResponse](
    WebSocketOperation[Literal[False], E, R]
):
    success: Literal[False] = False


class SuccessfulWebSocketOperation[R: OptAnySuccessResponse](
    WebSocketOperation[Literal[True], None, R]
):
    success: Literal[True] = True
    error: None = None
