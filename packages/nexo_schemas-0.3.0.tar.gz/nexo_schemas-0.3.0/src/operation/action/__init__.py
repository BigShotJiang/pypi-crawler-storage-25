from typing import Annotated

from pydantic import BaseModel, Field


class ActionMixin[T: BaseModel](BaseModel):
    action: Annotated[T, Field(..., description="Action")]
