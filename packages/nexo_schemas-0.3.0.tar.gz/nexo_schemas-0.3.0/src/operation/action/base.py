from enum import StrEnum
from typing import Annotated

from nexo.types.dict import OptStrToAnyDict
from pydantic import BaseModel, Field


class BaseOperationAction[T: StrEnum](BaseModel):
    type: Annotated[T, Field(..., description="Action's type")]


class SimpleOperationAction[T: StrEnum](BaseOperationAction[T]):
    details: Annotated[OptStrToAnyDict, Field(None, description="Action's details")] = (
        None
    )
