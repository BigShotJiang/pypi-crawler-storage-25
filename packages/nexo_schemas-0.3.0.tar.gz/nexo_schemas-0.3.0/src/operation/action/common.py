from collections.abc import Sequence
from typing import Annotated

from pydantic import BaseModel, Field

from ..enums import (
    ResourceOperationType,
    SystemOperationType,
    WebSocketOperationType,
)

OperationAction = ResourceOperationType | SystemOperationType | WebSocketOperationType
OptOperationAction = OperationAction | None


class OperationActionMixin[T: OptOperationAction](BaseModel):
    action: Annotated[T, Field(..., description="Operation's Action")]


ListOfOperationActions = list[OperationAction]
OptListOfOperationActions = ListOfOperationActions | None
SeqOfOperationActions = Sequence[OperationAction]
OptSeqOfOperationActions = SeqOfOperationActions | None


class OperationActionsMixin[T: OptSeqOfOperationActions](BaseModel):
    actions: Annotated[T, Field(..., description="Operation's Actions", min_length=1)]
