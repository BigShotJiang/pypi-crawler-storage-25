from copy import deepcopy
from typing import Annotated, Any, Literal, overload
from uuid import UUID

from pydantic import BaseModel, Field

from ..application import OptApplicationContext
from ..connection import OptConnectionContext
from ..error import AnyError, OptAnyError
from ..pagination import AnyPagination
from ..resource import Resource
from ..response import (
    AnyErrorResponse,
    AnyResponse,
    AnySuccessResponse,
    MultipleDataPairResponse,
    MultipleDataResponse,
    NoDataResponse,
    SingleDataPairResponse,
    SingleDataResponse,
)
from ..security.authentication import OptAnyAuthentication
from ..security.authorization import OptAnyAuthorization
from ..security.impersonation import OptImpersonation
from .action.resource import (
    AnyResourceOperationAction,
    CreateResourceOperationAction,
    DeleteResourceOperationAction,
    OptAnyResourceOperationAction,
    ReadResourceOperationAction,
    ResourceOperationActionFactory,
    ResourceOperationActions,
    UpdateResourceOperationAction,
)
from .base import BaseOperation
from .context import Context as OperationContext
from .enums import (
    OperationType,
    OptResourceOperationDataUpdateType,
    OptResourceOperationReadType,
    OptResourceOperationStatusUpdateType,
    OptResourceOperationType,
    OptResourceOperationUpdateType,
    ResourceOperationType,
)
from .mixins import Timestamp


class ResourceOperation[
    A: AnyResourceOperationAction,
    S: bool,
    E: OptAnyError,
    R: AnyResponse,
](BaseOperation[A, Resource, S, E, OptConnectionContext, R, None]):
    type: OperationType = OperationType.RESOURCE
    response_context: None = None


class FailedResourceOperation[
    A: AnyResourceOperationAction,
    E: AnyError,
    R: AnyErrorResponse,
](ResourceOperation[A, Literal[False], E, R]):
    success: Literal[False] = False


class CreateFailedResourceOperation[E: AnyError, R: AnyErrorResponse](
    FailedResourceOperation[CreateResourceOperationAction, E, R]
):
    action: Annotated[
        CreateResourceOperationAction,
        Field(CreateResourceOperationAction(), description="Action"),
    ] = CreateResourceOperationAction()


class ReadFailedResourceOperation[E: AnyError, R: AnyErrorResponse](
    FailedResourceOperation[ReadResourceOperationAction, E, R]
):
    action: Annotated[
        ReadResourceOperationAction,
        Field(ReadResourceOperationAction(), description="Action"),
    ] = ReadResourceOperationAction()


class UpdateFailedResourceOperation[E: AnyError, R: AnyErrorResponse](
    FailedResourceOperation[UpdateResourceOperationAction, E, R]
):
    action: Annotated[
        UpdateResourceOperationAction,
        Field(UpdateResourceOperationAction(), description="Action"),
    ] = UpdateResourceOperationAction()


class DeleteFailedResourceOperation[E: AnyError, R: AnyErrorResponse](
    FailedResourceOperation[DeleteResourceOperationAction, E, R]
):
    action: Annotated[
        DeleteResourceOperationAction,
        Field(DeleteResourceOperationAction(), description="Action"),
    ] = DeleteResourceOperationAction()


class SuccessfulResourceOperation[A: AnyResourceOperationAction, R: AnySuccessResponse](
    ResourceOperation[A, Literal[True], None, R]
):
    success: Literal[True] = True
    error: None = None


class NoDataResourceOperation[A: AnyResourceOperationAction, M: BaseModel | None](
    SuccessfulResourceOperation[A, NoDataResponse[M]],
):
    pass


class CreateSingleResourceOperation[D: Any, M: BaseModel | None](
    SuccessfulResourceOperation[
        CreateResourceOperationAction,
        SingleDataResponse[D, M],
    ],
):
    action: Annotated[
        CreateResourceOperationAction,
        Field(CreateResourceOperationAction(), description="Action"),
    ] = CreateResourceOperationAction()


class ReadSingleResourceOperation[D: Any, M: BaseModel | None](
    SuccessfulResourceOperation[
        ReadResourceOperationAction,
        SingleDataResponse[D, M],
    ],
):
    action: Annotated[
        ReadResourceOperationAction,
        Field(ReadResourceOperationAction(), description="Action"),
    ] = ReadResourceOperationAction()


class UpdateSingleResourceOperation[D: Any, M: BaseModel | None](
    SuccessfulResourceOperation[
        UpdateResourceOperationAction,
        SingleDataPairResponse[D, M],
    ],
):
    action: Annotated[
        UpdateResourceOperationAction,
        Field(UpdateResourceOperationAction(), description="Action"),
    ] = UpdateResourceOperationAction()


class DeleteSingleResourceOperation[D: Any, M: BaseModel | None](
    SuccessfulResourceOperation[
        DeleteResourceOperationAction,
        SingleDataResponse[D, M],
    ],
):
    action: Annotated[
        DeleteResourceOperationAction,
        Field(DeleteResourceOperationAction(), description="Action"),
    ] = DeleteResourceOperationAction()


class CreateMultipleResourceOperation[D: Any, P: AnyPagination, M: BaseModel | None](
    SuccessfulResourceOperation[
        CreateResourceOperationAction,
        MultipleDataResponse[D, P, M],
    ],
):
    action: Annotated[
        CreateResourceOperationAction,
        Field(CreateResourceOperationAction(), description="Action"),
    ] = CreateResourceOperationAction()


class ReadMultipleResourceOperation[D: Any, P: AnyPagination, M: BaseModel | None](
    SuccessfulResourceOperation[
        ReadResourceOperationAction,
        MultipleDataResponse[D, P, M],
    ],
):
    action: Annotated[
        ReadResourceOperationAction,
        Field(ReadResourceOperationAction(), description="Action"),
    ] = ReadResourceOperationAction()


class UpdateMultipleResourceOperation[D: Any, P: AnyPagination, M: BaseModel | None](
    SuccessfulResourceOperation[
        UpdateResourceOperationAction,
        MultipleDataPairResponse[D, P, M],
    ],
):
    action: Annotated[
        UpdateResourceOperationAction,
        Field(UpdateResourceOperationAction(), description="Action"),
    ] = UpdateResourceOperationAction()


class DeleteMultipleResourceOperation[D: Any, P: AnyPagination, M: BaseModel | None](
    SuccessfulResourceOperation[
        DeleteResourceOperationAction,
        MultipleDataResponse[D, P, M],
    ],
):
    action: Annotated[
        DeleteResourceOperationAction,
        Field(DeleteResourceOperationAction(), description="Action"),
    ] = DeleteResourceOperationAction()


class FailedResourceOperationFactory[E: AnyError, R: AnyErrorResponse]:
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: CreateResourceOperationAction
    ) -> type[CreateFailedResourceOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: ReadResourceOperationAction
    ) -> type[ReadFailedResourceOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: UpdateResourceOperationAction
    ) -> type[UpdateFailedResourceOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: DeleteResourceOperationAction
    ) -> type[DeleteFailedResourceOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: AnyResourceOperationAction
    ) -> (
        type[CreateFailedResourceOperation[E, R]]
        | type[ReadFailedResourceOperation[E, R]]
        | type[UpdateFailedResourceOperation[E, R]]
        | type[DeleteFailedResourceOperation[E, R]]
    ): ...
    @classmethod
    def operation_cls_from_action(
        cls, action: AnyResourceOperationAction
    ) -> (
        type[CreateFailedResourceOperation[E, R]]
        | type[ReadFailedResourceOperation[E, R]]
        | type[UpdateFailedResourceOperation[E, R]]
        | type[DeleteFailedResourceOperation[E, R]]
    ):
        if isinstance(action, CreateResourceOperationAction):
            operation_cls = CreateFailedResourceOperation[E, R]
        elif isinstance(action, ReadResourceOperationAction):
            operation_cls = ReadFailedResourceOperation[E, R]
        elif isinstance(action, UpdateResourceOperationAction):
            operation_cls = UpdateFailedResourceOperation[E, R]
        elif isinstance(action, DeleteResourceOperationAction):
            operation_cls = DeleteFailedResourceOperation[E, R]
        return operation_cls

    @overload
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: Literal[ResourceOperationType.CREATE],
    ) -> type[CreateFailedResourceOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: Literal[ResourceOperationType.READ],
    ) -> type[ReadFailedResourceOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: Literal[ResourceOperationType.UPDATE],
    ) -> type[UpdateFailedResourceOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: Literal[ResourceOperationType.DELETE],
    ) -> type[DeleteFailedResourceOperation[E, R]]: ...
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: ResourceOperationType,
    ) -> (
        type[CreateFailedResourceOperation[E, R]]
        | type[ReadFailedResourceOperation[E, R]]
        | type[UpdateFailedResourceOperation[E, R]]
        | type[DeleteFailedResourceOperation[E, R]]
    ):
        if type_ is ResourceOperationType.CREATE:
            operation_cls = CreateFailedResourceOperation[E, R]
        elif type_ is ResourceOperationType.READ:
            operation_cls = ReadFailedResourceOperation[E, R]
        elif type_ is ResourceOperationType.UPDATE:
            operation_cls = UpdateFailedResourceOperation[E, R]
        elif type_ is ResourceOperationType.DELETE:
            operation_cls = DeleteFailedResourceOperation[E, R]
        return operation_cls

    @overload
    @classmethod
    def generate(
        cls,
        action: CreateResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        resource: Resource,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
    ) -> CreateFailedResourceOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        action: ReadResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        resource: Resource,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
    ) -> ReadFailedResourceOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        action: UpdateResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        resource: Resource,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
    ) -> UpdateFailedResourceOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        action: DeleteResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        resource: Resource,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
    ) -> DeleteFailedResourceOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        action: AnyResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        resource: Resource,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
    ) -> (
        CreateFailedResourceOperation[E, R]
        | ReadFailedResourceOperation[E, R]
        | UpdateFailedResourceOperation[E, R]
        | DeleteFailedResourceOperation[E, R]
    ): ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: Literal[ResourceOperationType.CREATE],
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        resource: Resource,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
    ) -> CreateFailedResourceOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: Literal[ResourceOperationType.READ],
        read_type: OptResourceOperationReadType = ...,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        resource: Resource,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
    ) -> ReadFailedResourceOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: Literal[ResourceOperationType.UPDATE],
        update_type: OptResourceOperationUpdateType = ...,
        data_update_type: OptResourceOperationDataUpdateType = ...,
        status_update_type: OptResourceOperationStatusUpdateType = ...,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        resource: Resource,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
    ) -> UpdateFailedResourceOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: Literal[ResourceOperationType.DELETE],
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        resource: Resource,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
    ) -> DeleteFailedResourceOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: ResourceOperationType,
        read_type: OptResourceOperationReadType = None,
        update_type: OptResourceOperationUpdateType = None,
        data_update_type: OptResourceOperationDataUpdateType = None,
        status_update_type: OptResourceOperationStatusUpdateType = None,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        resource: Resource,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
    ) -> (
        CreateFailedResourceOperation[E, R]
        | ReadFailedResourceOperation[E, R]
        | UpdateFailedResourceOperation[E, R]
        | DeleteFailedResourceOperation[E, R]
    ): ...
    @classmethod
    def generate(
        cls,
        action: OptAnyResourceOperationAction = None,
        *,
        type_: OptResourceOperationType = None,
        read_type: OptResourceOperationReadType = None,
        update_type: OptResourceOperationUpdateType = None,
        data_update_type: OptResourceOperationDataUpdateType = None,
        status_update_type: OptResourceOperationStatusUpdateType = None,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        resource: Resource,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
    ) -> (
        CreateFailedResourceOperation[E, R]
        | ReadFailedResourceOperation[E, R]
        | UpdateFailedResourceOperation[E, R]
        | DeleteFailedResourceOperation[E, R]
    ):
        if (action is None and type_ is None) or (
            action is not None and type_ is not None
        ):
            raise ValueError("Only either 'action' or 'type' must be given")

        common_kwargs = {
            "id": id,
            "is_ai": is_ai,
            "context": context,
            "resource": resource,
            "timestamp": timestamp,
            "summary": summary,
            "error": error,
            "connection_context": connection_context,
            "authentication": authentication,
            "authorization": authorization,
            "impersonation": impersonation,
            "response": response,
        }

        if application_context is not None:
            common_kwargs["application_context"] = application_context

        if action is not None:
            if not isinstance(action, ResourceOperationActions):
                raise ValueError(f"Invalid 'action' type: '{type(action)}'")

            kwargs = deepcopy(common_kwargs)
            kwargs["action"] = action

            return cls.operation_cls_from_action(action).model_validate(kwargs)

        if type_ is not None:
            action = ResourceOperationActionFactory.generate(
                type_,
                read_type=read_type,
                update_type=update_type,
                data_update_type=data_update_type,
                status_update_type=status_update_type,
            )
            kwargs = deepcopy(common_kwargs)
            kwargs["action"] = action
            return cls.operation_cls_from_type(type_).model_validate(kwargs)

        # This should never happen due to initial validation,
        # but type checker needs to see all paths covered
        raise ValueError("Neither 'action' nor 'type' provided")
