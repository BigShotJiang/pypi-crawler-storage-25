from enum import Enum, StrEnum
from typing import Annotated

from nexo.types.dict import OptStrToAnyDict
from pydantic import BaseModel, Field

from .enums import Layer, Origin, Target


class Component[T: StrEnum](BaseModel):
    type: Annotated[T, Field(..., description="Component's type")]
    details: Annotated[
        OptStrToAnyDict, Field(None, description="Component's details")
    ] = None


class Context(BaseModel):
    origin: Annotated[Component[Origin], Field(..., description="Operation's origin")]
    layer: Annotated[Component[Layer], Field(..., description="Operation's layer")]
    target: Annotated[Component[Target], Field(..., description="Operation's target")]


class ContextMixin(BaseModel):
    context: Context = Field(..., description="Operation's context")


CLIENT_SERVICE_CACHE_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.CLIENT, details=None),
    layer=Component[Layer](type=Layer.SERVICE, details=None),
    target=Component[Target](type=Target.CACHE, details=None),
)


CLIENT_SERVICE_INTERNAL_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.CLIENT, details=None),
    layer=Component[Layer](type=Layer.SERVICE, details=None),
    target=Component[Target](type=Target.INTERNAL, details=None),
)


CLIENT_SERVICE_MICROSERVICE_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.CLIENT, details=None),
    layer=Component[Layer](type=Layer.SERVICE, details=None),
    target=Component[Target](type=Target.MICROSERVICE, details=None),
)


SERVICE_CONTROLLER_MONITORING_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.SERVICE, details=None),
    layer=Component[Layer](type=Layer.CONTROLLER, details=None),
    target=Component[Target](type=Target.MONITORING, details=None),
)


SERVICE_CONTROLLER_SERVICE_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.SERVICE, details=None),
    layer=Component[Layer](type=Layer.CONTROLLER, details=None),
    target=Component[Target](type=Target.SERVICE, details=None),
)


SERVICE_INFRASTRUCTURE_MONITORING_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.SERVICE, details=None),
    layer=Component[Layer](type=Layer.INFRASTRUCTURE, details=None),
    target=Component[Target](type=Target.MONITORING, details=None),
)


SERVICE_MIDDLEWARE_INTERNAL_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.SERVICE, details=None),
    layer=Component[Layer](type=Layer.MIDDLEWARE, details=None),
    target=Component[Target](type=Target.INTERNAL, details=None),
)


SERVICE_REPOSITORY_CACHE_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.SERVICE, details=None),
    layer=Component[Layer](type=Layer.REPOSITORY, details=None),
    target=Component[Target](type=Target.CACHE, details=None),
)


SERVICE_REPOSITORY_DATABASE_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.SERVICE, details=None),
    layer=Component[Layer](type=Layer.REPOSITORY, details=None),
    target=Component[Target](type=Target.DATABASE, details=None),
)


SERVICE_SERVICE_REPOSITORY_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.SERVICE, details=None),
    layer=Component[Layer](type=Layer.SERVICE, details=None),
    target=Component[Target](type=Target.REPOSITORY, details=None),
)


SERVICE_UTILITY_DATABASE_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.SERVICE, details=None),
    layer=Component[Layer](type=Layer.UTILITY, details=None),
    target=Component[Target](type=Target.DATABASE, details=None),
)


UTILITY_INTERNAL_INTERNAL_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.UTILITY, details=None),
    layer=Component[Layer](type=Layer.INTERNAL, details=None),
    target=Component[Target](type=Target.INTERNAL, details=None),
)


def generate(
    origin: Origin,
    layer: Layer,
    target: Target = Target.INTERNAL,
    origin_details: OptStrToAnyDict = None,
    layer_details: OptStrToAnyDict = None,
    target_details: OptStrToAnyDict = None,
) -> Context:
    return Context(
        origin=Component[Origin](type=origin, details=origin_details),
        layer=Component[Layer](type=layer, details=layer_details),
        target=Component[Target](type=target, details=target_details),
    )


class DefaultOperationContext(Enum):
    CLIENT_SERVICE_CACHE = CLIENT_SERVICE_CACHE_OPERATION_CONTEXT
    CLIENT_SERVICE_INTERNAL = CLIENT_SERVICE_INTERNAL_OPERATION_CONTEXT
    CLIENT_SERVICE_MICROSERVICE = CLIENT_SERVICE_MICROSERVICE_OPERATION_CONTEXT
    SERVICE_CONTROLLER_SERVICE = SERVICE_CONTROLLER_SERVICE_OPERATION_CONTEXT
    SERVICE_CONTROLLER_MONITORING = SERVICE_CONTROLLER_MONITORING_OPERATION_CONTEXT
    SERVICE_INFRASTRUCTURE_MONITORING = (
        SERVICE_INFRASTRUCTURE_MONITORING_OPERATION_CONTEXT
    )
    SERVICE_MIDDLEWARE_INTERNAL = SERVICE_MIDDLEWARE_INTERNAL_OPERATION_CONTEXT
    SERVICE_REPOSITORY_CACHE = SERVICE_REPOSITORY_CACHE_OPERATION_CONTEXT
    SERVICE_REPOSITORY_DATABASE = SERVICE_REPOSITORY_DATABASE_OPERATION_CONTEXT
    SERVICE_SERVICE_REPOSITORY = SERVICE_SERVICE_REPOSITORY_OPERATION_CONTEXT
    SERVICE_UTILITY_DATABASE = SERVICE_UTILITY_DATABASE_OPERATION_CONTEXT
    UTILITY_INTERNAL_INTERNAL = UTILITY_INTERNAL_INTERNAL_OPERATION_CONTEXT

    @property
    def template(self) -> Context:
        return self.value

    def new(
        self,
        origin_details: OptStrToAnyDict = None,
        layer_details: OptStrToAnyDict = None,
        target_details: OptStrToAnyDict = None,
    ) -> Context:
        original = self.template
        return generate(
            origin=original.origin.type,
            layer=original.layer.type,
            target=original.target.type,
            origin_details=origin_details,
            layer_details=layer_details,
            target_details=target_details,
        )
