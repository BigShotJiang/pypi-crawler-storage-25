from copy import deepcopy
from typing import Annotated, Any, Literal, overload
from uuid import UUID

from pydantic import Field

from ..application import OptApplicationContext
from ..connection import ConnectionContext
from ..error import AnyError, OptAnyError
from ..pagination import OptAnyPagination
from ..response import (
    AnyDataResponse,
    AnyErrorResponse,
    OptAnyResponse,
    ResponseContext,
)
from ..security.authentication import OptAnyAuthentication
from ..security.authorization import OptAnyAuthorization
from ..security.impersonation import OptImpersonation
from .action.resource import (
    AnyResourceOperationAction,
    CreateResourceOperationAction,
    DeleteResourceOperationAction,
    OptAnyResourceOperationAction,
    ReadResourceOperationAction,
    ResourceOperationActionFactory,
    ResourceOperationActions,
    UpdateResourceOperationAction,
)
from .base import BaseOperation
from .context import Context as OperationContext
from .enums import (
    OperationType,
    OptResourceOperationDataUpdateType,
    OptResourceOperationStatusUpdateType,
    OptResourceOperationType,
    OptResourceOperationUpdateType,
    ResourceOperationType,
)
from .mixins import Timestamp


class RequestOperation[
    A: AnyResourceOperationAction,
    S: bool,
    E: OptAnyError,
    R: OptAnyResponse,
](BaseOperation[A, None, S, E, ConnectionContext, R, ResponseContext]):
    type: OperationType = OperationType.REQUEST
    resource: None = None


class FailedRequestOperation[
    A: AnyResourceOperationAction,
    E: AnyError,
    R: AnyErrorResponse,
](RequestOperation[A, Literal[False], E, R]):
    success: Literal[False] = False
    summary: str = "Failed processing request"


class CreateFailedRequestOperation[E: AnyError, R: AnyErrorResponse](
    FailedRequestOperation[CreateResourceOperationAction, E, R]
):
    action: Annotated[
        CreateResourceOperationAction,
        Field(CreateResourceOperationAction(), description="Action"),
    ] = CreateResourceOperationAction()


class ReadFailedRequestOperation[E: AnyError, R: AnyErrorResponse](
    FailedRequestOperation[ReadResourceOperationAction, E, R]
):
    action: Annotated[
        ReadResourceOperationAction,
        Field(ReadResourceOperationAction(), description="Action"),
    ] = ReadResourceOperationAction()


class UpdateFailedRequestOperation[E: AnyError, R: AnyErrorResponse](
    FailedRequestOperation[UpdateResourceOperationAction, E, R]
):
    action: Annotated[
        UpdateResourceOperationAction,
        Field(UpdateResourceOperationAction(), description="Action"),
    ] = UpdateResourceOperationAction()


class DeleteFailedRequestOperation[E: AnyError, R: AnyErrorResponse](
    FailedRequestOperation[DeleteResourceOperationAction, E, R]
):
    action: Annotated[
        DeleteResourceOperationAction,
        Field(DeleteResourceOperationAction(), description="Action"),
    ] = DeleteResourceOperationAction()


class SuccessfulRequestOperationResponse(AnyDataResponse[Any, OptAnyPagination, Any]):
    pass


class SuccessfulRequestOperation[A: AnyResourceOperationAction](
    RequestOperation[A, Literal[True], None, SuccessfulRequestOperationResponse]
):
    success: Literal[True] = True
    error: None = None
    summary: str = "Successfully processed request"


class CreateSuccessfulRequestOperation(
    SuccessfulRequestOperation[CreateResourceOperationAction]
):
    action: Annotated[
        CreateResourceOperationAction,
        Field(CreateResourceOperationAction(), description="Action"),
    ] = CreateResourceOperationAction()


class ReadSuccessfulRequestOperation(
    SuccessfulRequestOperation[ReadResourceOperationAction]
):
    action: Annotated[
        ReadResourceOperationAction,
        Field(ReadResourceOperationAction(), description="Action"),
    ] = ReadResourceOperationAction()


class UpdateSuccessfulRequestOperation(
    SuccessfulRequestOperation[UpdateResourceOperationAction]
):
    action: Annotated[
        UpdateResourceOperationAction,
        Field(UpdateResourceOperationAction(), description="Action"),
    ] = UpdateResourceOperationAction()


class DeleteSuccessfulRequestOperation(
    SuccessfulRequestOperation[DeleteResourceOperationAction]
):
    action: Annotated[
        DeleteResourceOperationAction,
        Field(DeleteResourceOperationAction(), description="Action"),
    ] = DeleteResourceOperationAction()


AnySuccessfulRequestOperationType = (
    type[CreateSuccessfulRequestOperation]
    | type[ReadSuccessfulRequestOperation]
    | type[UpdateSuccessfulRequestOperation]
    | type[DeleteSuccessfulRequestOperation]
)


AnySuccessfulRequestOperation = (
    CreateSuccessfulRequestOperation
    | ReadSuccessfulRequestOperation
    | UpdateSuccessfulRequestOperation
    | DeleteSuccessfulRequestOperation
)


class FailedRequestOperationFactory[E: AnyError, R: AnyErrorResponse]:
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: CreateResourceOperationAction
    ) -> type[CreateFailedRequestOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: ReadResourceOperationAction
    ) -> type[ReadFailedRequestOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: UpdateResourceOperationAction
    ) -> type[UpdateFailedRequestOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: DeleteResourceOperationAction
    ) -> type[DeleteFailedRequestOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: AnyResourceOperationAction
    ) -> (
        type[CreateFailedRequestOperation[E, R]]
        | type[ReadFailedRequestOperation[E, R]]
        | type[UpdateFailedRequestOperation[E, R]]
        | type[DeleteFailedRequestOperation[E, R]]
    ): ...
    @classmethod
    def operation_cls_from_action(
        cls, action: AnyResourceOperationAction
    ) -> (
        type[CreateFailedRequestOperation[E, R]]
        | type[ReadFailedRequestOperation[E, R]]
        | type[UpdateFailedRequestOperation[E, R]]
        | type[DeleteFailedRequestOperation[E, R]]
    ):
        if isinstance(action, CreateResourceOperationAction):
            operation_cls = CreateFailedRequestOperation[E, R]
        elif isinstance(action, ReadResourceOperationAction):
            operation_cls = ReadFailedRequestOperation[E, R]
        elif isinstance(action, UpdateResourceOperationAction):
            operation_cls = UpdateFailedRequestOperation[E, R]
        elif isinstance(action, DeleteResourceOperationAction):
            operation_cls = DeleteFailedRequestOperation[E, R]
        return operation_cls

    @overload
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: Literal[ResourceOperationType.CREATE],
    ) -> type[CreateFailedRequestOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: Literal[ResourceOperationType.READ],
    ) -> type[ReadFailedRequestOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: Literal[ResourceOperationType.UPDATE],
    ) -> type[UpdateFailedRequestOperation[E, R]]: ...
    @overload
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: Literal[ResourceOperationType.DELETE],
    ) -> type[DeleteFailedRequestOperation[E, R]]: ...
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: ResourceOperationType,
    ) -> (
        type[CreateFailedRequestOperation[E, R]]
        | type[ReadFailedRequestOperation[E, R]]
        | type[UpdateFailedRequestOperation[E, R]]
        | type[DeleteFailedRequestOperation[E, R]]
    ):
        if type_ is ResourceOperationType.CREATE:
            operation_cls = CreateFailedRequestOperation[E, R]
        elif type_ is ResourceOperationType.READ:
            operation_cls = ReadFailedRequestOperation[E, R]
        elif type_ is ResourceOperationType.UPDATE:
            operation_cls = UpdateFailedRequestOperation[E, R]
        elif type_ is ResourceOperationType.DELETE:
            operation_cls = DeleteFailedRequestOperation[E, R]
        return operation_cls

    @overload
    @classmethod
    def generate(
        cls,
        action: CreateResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
        response_context: ResponseContext,
    ) -> CreateFailedRequestOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        action: ReadResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
        response_context: ResponseContext,
    ) -> ReadFailedRequestOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        action: UpdateResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
        response_context: ResponseContext,
    ) -> UpdateFailedRequestOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        action: DeleteResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
        response_context: ResponseContext,
    ) -> DeleteFailedRequestOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        action: AnyResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
        response_context: ResponseContext,
    ) -> (
        CreateFailedRequestOperation[E, R]
        | ReadFailedRequestOperation[E, R]
        | UpdateFailedRequestOperation[E, R]
        | DeleteFailedRequestOperation[E, R]
    ): ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: Literal[ResourceOperationType.CREATE],
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
        response_context: ResponseContext,
    ) -> CreateFailedRequestOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: Literal[ResourceOperationType.READ],
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
        response_context: ResponseContext,
    ) -> ReadFailedRequestOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: Literal[ResourceOperationType.UPDATE],
        update_type: OptResourceOperationUpdateType = ...,
        data_update_type: OptResourceOperationDataUpdateType = ...,
        status_update_type: OptResourceOperationStatusUpdateType = ...,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
        response_context: ResponseContext,
    ) -> UpdateFailedRequestOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: Literal[ResourceOperationType.DELETE],
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
        response_context: ResponseContext,
    ) -> DeleteFailedRequestOperation[E, R]: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: ResourceOperationType,
        update_type: OptResourceOperationUpdateType = None,
        data_update_type: OptResourceOperationDataUpdateType = None,
        status_update_type: OptResourceOperationStatusUpdateType = None,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
        response_context: ResponseContext,
    ) -> (
        CreateFailedRequestOperation[E, R]
        | ReadFailedRequestOperation[E, R]
        | UpdateFailedRequestOperation[E, R]
        | DeleteFailedRequestOperation[E, R]
    ): ...
    @classmethod
    def generate(
        cls,
        action: OptAnyResourceOperationAction = None,
        *,
        type_: OptResourceOperationType = None,
        update_type: OptResourceOperationUpdateType = None,
        data_update_type: OptResourceOperationDataUpdateType = None,
        status_update_type: OptResourceOperationStatusUpdateType = None,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        error: E,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: R,
        response_context: ResponseContext,
    ) -> (
        CreateFailedRequestOperation[E, R]
        | ReadFailedRequestOperation[E, R]
        | UpdateFailedRequestOperation[E, R]
        | DeleteFailedRequestOperation[E, R]
    ):
        if (action is None and type_ is None) or (
            action is not None and type_ is not None
        ):
            raise ValueError("Only either 'action' or 'type' must be given")

        common_kwargs = {
            "id": id,
            "is_ai": is_ai,
            "context": context,
            "timestamp": timestamp,
            "summary": summary,
            "error": error,
            "connection_context": connection_context,
            "authentication": authentication,
            "authorization": authorization,
            "impersonation": impersonation,
            "response": response,
            "response_context": response_context,
        }

        if application_context is not None:
            common_kwargs["application_context"] = application_context

        if action is not None:
            if not isinstance(action, ResourceOperationActions):
                raise ValueError(f"Invalid 'action' type: '{type(action)}'")

            kwargs = deepcopy(common_kwargs)
            kwargs["action"] = action

            return cls.operation_cls_from_action(action).model_validate(kwargs)

        elif type_ is not None:
            action = ResourceOperationActionFactory.generate(
                type_,
                update_type=update_type,
                data_update_type=data_update_type,
                status_update_type=status_update_type,
            )
            kwargs = deepcopy(common_kwargs)
            kwargs["action"] = action
            return cls.operation_cls_from_type(type_).model_validate(kwargs)

        # This should never happen due to initial validation,
        # but type checker needs to see all paths covered
        raise ValueError("Neither 'action' nor 'type' provided")


class SuccessfulRequestOperationFactory:
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: CreateResourceOperationAction
    ) -> type[CreateSuccessfulRequestOperation]: ...
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: ReadResourceOperationAction
    ) -> type[ReadSuccessfulRequestOperation]: ...
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: UpdateResourceOperationAction
    ) -> type[UpdateSuccessfulRequestOperation]: ...
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: DeleteResourceOperationAction
    ) -> type[DeleteSuccessfulRequestOperation]: ...
    @overload
    @classmethod
    def operation_cls_from_action(
        cls, action: AnyResourceOperationAction
    ) -> AnySuccessfulRequestOperationType: ...
    @classmethod
    def operation_cls_from_action(
        cls, action: AnyResourceOperationAction
    ) -> AnySuccessfulRequestOperationType:
        if isinstance(action, CreateResourceOperationAction):
            operation_cls = CreateSuccessfulRequestOperation
        elif isinstance(action, ReadResourceOperationAction):
            operation_cls = ReadSuccessfulRequestOperation
        elif isinstance(action, UpdateResourceOperationAction):
            operation_cls = UpdateSuccessfulRequestOperation
        elif isinstance(action, DeleteResourceOperationAction):
            operation_cls = DeleteSuccessfulRequestOperation
        return operation_cls

    @overload
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: Literal[ResourceOperationType.CREATE],
    ) -> type[CreateSuccessfulRequestOperation]: ...
    @overload
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: Literal[ResourceOperationType.READ],
    ) -> type[ReadSuccessfulRequestOperation]: ...
    @overload
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: Literal[ResourceOperationType.UPDATE],
    ) -> type[UpdateSuccessfulRequestOperation]: ...
    @overload
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: Literal[ResourceOperationType.DELETE],
    ) -> type[DeleteSuccessfulRequestOperation]: ...
    @classmethod
    def operation_cls_from_type(
        cls,
        type_: ResourceOperationType,
    ) -> AnySuccessfulRequestOperationType:
        if type_ is ResourceOperationType.CREATE:
            operation_cls = CreateSuccessfulRequestOperation
        elif type_ is ResourceOperationType.READ:
            operation_cls = ReadSuccessfulRequestOperation
        elif type_ is ResourceOperationType.UPDATE:
            operation_cls = UpdateSuccessfulRequestOperation
        elif type_ is ResourceOperationType.DELETE:
            operation_cls = DeleteSuccessfulRequestOperation
        return operation_cls

    @overload
    @classmethod
    def generate(
        cls,
        action: CreateResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: AnyDataResponse[Any, OptAnyPagination, Any],
        response_context: ResponseContext,
    ) -> CreateSuccessfulRequestOperation: ...
    @overload
    @classmethod
    def generate(
        cls,
        action: ReadResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: AnyDataResponse[Any, OptAnyPagination, Any],
        response_context: ResponseContext,
    ) -> ReadSuccessfulRequestOperation: ...
    @overload
    @classmethod
    def generate(
        cls,
        action: UpdateResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: AnyDataResponse[Any, OptAnyPagination, Any],
        response_context: ResponseContext,
    ) -> UpdateSuccessfulRequestOperation: ...
    @overload
    @classmethod
    def generate(
        cls,
        action: DeleteResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: AnyDataResponse[Any, OptAnyPagination, Any],
        response_context: ResponseContext,
    ) -> DeleteSuccessfulRequestOperation: ...
    @overload
    @classmethod
    def generate(
        cls,
        action: AnyResourceOperationAction,
        *,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: AnyDataResponse[Any, OptAnyPagination, Any],
        response_context: ResponseContext,
    ) -> AnySuccessfulRequestOperation: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: Literal[ResourceOperationType.CREATE],
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: AnyDataResponse[Any, OptAnyPagination, Any],
        response_context: ResponseContext,
    ) -> CreateSuccessfulRequestOperation: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: Literal[ResourceOperationType.READ],
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: AnyDataResponse[Any, OptAnyPagination, Any],
        response_context: ResponseContext,
    ) -> ReadSuccessfulRequestOperation: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: Literal[ResourceOperationType.UPDATE],
        update_type: OptResourceOperationUpdateType = ...,
        data_update_type: OptResourceOperationDataUpdateType = ...,
        status_update_type: OptResourceOperationStatusUpdateType = ...,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: AnyDataResponse[Any, OptAnyPagination, Any],
        response_context: ResponseContext,
    ) -> UpdateSuccessfulRequestOperation: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: Literal[ResourceOperationType.DELETE],
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: AnyDataResponse[Any, OptAnyPagination, Any],
        response_context: ResponseContext,
    ) -> DeleteSuccessfulRequestOperation: ...
    @overload
    @classmethod
    def generate(
        cls,
        *,
        type_: ResourceOperationType,
        update_type: OptResourceOperationUpdateType = None,
        data_update_type: OptResourceOperationDataUpdateType = None,
        status_update_type: OptResourceOperationStatusUpdateType = None,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: AnyDataResponse[Any, OptAnyPagination, Any],
        response_context: ResponseContext,
    ) -> AnySuccessfulRequestOperation: ...
    @classmethod
    def generate(
        cls,
        action: OptAnyResourceOperationAction = None,
        *,
        type_: OptResourceOperationType = None,
        update_type: OptResourceOperationUpdateType = None,
        data_update_type: OptResourceOperationDataUpdateType = None,
        status_update_type: OptResourceOperationStatusUpdateType = None,
        application_context: OptApplicationContext = None,
        id: UUID,
        is_ai: bool = False,
        context: OperationContext,
        timestamp: Timestamp,
        summary: str,
        connection_context: ConnectionContext,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        response: AnyDataResponse[Any, OptAnyPagination, Any],
        response_context: ResponseContext,
    ) -> AnySuccessfulRequestOperation:
        if (action is None and type_ is None) or (
            action is not None and type_ is not None
        ):
            raise ValueError("Only either 'action' or 'type' must be given")

        common_kwargs = {
            "id": id,
            "is_ai": is_ai,
            "context": context,
            "timestamp": timestamp,
            "summary": summary,
            "connection_context": connection_context,
            "authentication": authentication,
            "authorization": authorization,
            "impersonation": impersonation,
            "response": response,
            "response_context": response_context,
        }

        if application_context is not None:
            common_kwargs["application_context"] = application_context

        if action is not None:
            if not isinstance(action, ResourceOperationActions):
                raise ValueError(f"Invalid 'action' type: '{type(action)}'")

            kwargs = deepcopy(common_kwargs)
            kwargs["action"] = action

            return cls.operation_cls_from_action(action).model_validate(kwargs)

        if type_ is not None:
            action = ResourceOperationActionFactory.generate(
                type_,
                update_type=update_type,
                data_update_type=data_update_type,
                status_update_type=status_update_type,
            )
            kwargs = deepcopy(common_kwargs)
            kwargs["action"] = action
            return cls.operation_cls_from_type(type_).model_validate(kwargs)

        # This should never happen due to initial validation,
        # but type checker needs to see all paths covered
        raise ValueError("Neither 'action' nor 'type' provided")
