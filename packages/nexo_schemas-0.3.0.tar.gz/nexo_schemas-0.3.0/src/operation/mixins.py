from datetime import UTC, datetime
from typing import Annotated, Self
from uuid import UUID

from pydantic import BaseModel, Field, field_validator, model_validator

from ..mixins.identity import UUIDId
from ..mixins.timestamp import CompletionTimestamp, Duration, ExecutionTimestamp


class Id(UUIDId[UUID]):
    pass


class IsAI(BaseModel):
    is_ai: Annotated[bool, Field(False, description="Operation's AI flag")] = False


class Timestamp(
    Duration[float],
    CompletionTimestamp[datetime],
    ExecutionTimestamp[datetime],
):
    duration: Annotated[float, Field(0.0, ge=0.0, description="Duration")] = 0.0

    @field_validator("duration", mode="before")
    @classmethod
    def non_negative_duration(cls, v: float) -> float:
        if v is None:
            return 0.0
        return max(float(v), 0.0)

    @model_validator(mode="after")
    def calculate_duration(self) -> Self:
        computed = (self.completed_at - self.executed_at).total_seconds()
        self.duration = max(computed, 0.0)
        return self

    @classmethod
    def now(cls) -> "Timestamp":
        now = datetime.now(tz=UTC)
        return cls(executed_at=now, completed_at=now, duration=0)

    @classmethod
    def completed_now(cls, executed_at: datetime) -> "Timestamp":
        completed_at = datetime.now(tz=UTC)
        return cls(
            executed_at=executed_at,
            completed_at=completed_at,
            duration=(completed_at - executed_at).total_seconds(),
        )


OptTimestamp = Timestamp | None


class TimestampMixin(BaseModel):
    timestamp: Annotated[Timestamp, Field(..., description="Operation's timestamp")]


class Summary(BaseModel):
    summary: Annotated[str, Field(..., description="Operation's summary")]
