from typing import Literal

from ..connection import OptConnectionContext
from ..error import AnyError, OptAnyError
from ..response import AnyErrorResponse, OptAnyResponse, OptAnySuccessResponse
from .action.system import SystemOperationAction
from .base import BaseOperation
from .enums import OperationType


class SystemOperation[S: bool, E: OptAnyError, R: OptAnyResponse](
    BaseOperation[SystemOperationAction, None, S, E, OptConnectionContext, R, None]
):
    type: OperationType = OperationType.SYSTEM
    resource: None = None
    response_context: None = None


class FailedSystemOperation[E: AnyError, R: AnyErrorResponse](
    SystemOperation[Literal[False], E, R]
):
    success: Literal[False] = False


class SuccessfulSystemOperation[R: OptAnySuccessResponse](
    SystemOperation[Literal[True], None, R]
):
    success: Literal[True] = True
    error: None = None
